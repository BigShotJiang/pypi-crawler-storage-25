from __future__ import annotations

import json
from dataclasses import dataclass

from gitspy.ai.prompts import SYSTEM_PROMPT, format_batch_prompt, format_finding_for_prompt
from gitspy.ai.redactor import redact
from gitspy.config import AiConfig
from gitspy.core.models import Finding, Severity


@dataclass
class ClassificationResult:
    severity: str
    explanation: str
    recommendation: str


def _parse_response(raw: str) -> list[ClassificationResult]:
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        cleaned = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        return []

    if isinstance(data, dict):
        data = [data]

    results: list[ClassificationResult] = []
    for item in data:
        results.append(ClassificationResult(
            severity=item.get("severity", "medium"),
            explanation=item.get("explanation", ""),
            recommendation=item.get("recommendation", ""),
        ))
    return results


def _severity_from_str(s: str) -> Severity | None:
    mapping = {
        "critical": Severity.CRITICAL,
        "high": Severity.HIGH,
        "medium": Severity.MEDIUM,
        "low": Severity.LOW,
        "info": Severity.INFO,
    }
    return mapping.get(s.lower())


def _build_finding_text(f: Finding) -> str:
    return format_finding_for_prompt(
        finding_type=f.finding_type.value,
        title=f.title,
        file_path=f.file_path,
        line=f.line,
        match=redact(f.match),
        context=redact(f.context),
        commit_hash=f.commit_hash,
        confidence=f.module_confidence,
    )


def classify_findings(findings: list[Finding], config: AiConfig) -> list[Finding]:
    if config.provider == "none" or not findings:
        return findings

    provider = _get_provider(config)
    if provider is None:
        return findings

    texts = [_build_finding_text(f) for f in findings]
    prompt = format_batch_prompt(texts)
    prompt = redact(prompt)

    raw_response = provider.complete(SYSTEM_PROMPT, prompt)
    results = _parse_response(raw_response)

    for i, result in enumerate(results):
        if i >= len(findings):
            break

        idx = i
        if hasattr(result, "index"):
            idx = min(getattr(result, "index", i), len(findings) - 1)

        severity = _severity_from_str(result.severity)
        if result.severity == "false_positive":
            findings[idx].ai_severity = Severity.INFO
            findings[idx].ai_explanation = f"[False Positive] {result.explanation}"
        elif severity:
            findings[idx].ai_severity = severity
            findings[idx].ai_explanation = result.explanation

        findings[idx].ai_recommendation = result.recommendation

    return findings


class _Provider:
    def complete(self, system: str, user: str) -> str:
        raise NotImplementedError


class _OpenAIProvider(_Provider):
    def __init__(self, config: AiConfig) -> None:
        import os
        import openai
        api_key = os.environ.get(config.api_key_env, "")
        self._client = openai.OpenAI(api_key=api_key)
        self._model = config.model or "gpt-4o-mini"

    def complete(self, system: str, user: str) -> str:
        resp = self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0.1,
            max_tokens=4096,
        )
        return resp.choices[0].message.content or ""


class _AnthropicProvider(_Provider):
    def __init__(self, config: AiConfig) -> None:
        import os
        import anthropic
        api_key = os.environ.get(config.api_key_env, "")
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = config.model or "claude-sonnet-4-20250514"

    def complete(self, system: str, user: str) -> str:
        resp = self._client.messages.create(
            model=self._model,
            system=system,
            messages=[{"role": "user", "content": user}],
            temperature=0.1,
            max_tokens=4096,
        )
        return resp.content[0].text


class _OllamaProvider(_Provider):
    def __init__(self, config: AiConfig) -> None:
        import ollama
        self._client = ollama
        self._model = config.model or "llama3"

    def complete(self, system: str, user: str) -> str:
        resp = self._client.chat(
            model=self._model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            options={"temperature": 0.1},
        )
        return resp["message"]["content"]


def _get_provider(config: AiConfig) -> _Provider | None:
    providers = {
        "openai": _OpenAIProvider,
        "anthropic": _AnthropicProvider,
        "ollama": _OllamaProvider,
    }
    cls = providers.get(config.provider)
    if cls is None:
        return None
    try:
        return cls(config)
    except Exception:
        return None
