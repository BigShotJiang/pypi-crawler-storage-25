from __future__ import annotations

SYSTEM_PROMPT = (
    "You are a security analyst specializing in supply-chain security. "
    "You receive findings from an automated security scanner and classify their severity. "
    "Be concise. Respond ONLY with valid JSON."
)

CLASSIFY_TEMPLATE = (
    "Given this finding from a security scan, classify its severity and explain.\n\n"
    "Finding:\n"
    "  type: {finding_type}\n"
    "  title: {title}\n"
    "  file: {file_path}\n"
    "  line: {line}\n"
    "  match: {match}\n"
    "  context:\n{context}\n"
    "  commit: {commit_hash}\n"
    "  module_confidence: {confidence}\n\n"
    "Respond with JSON:\n"
    '{{\n'
    '  "severity": "critical|high|medium|low|false_positive",\n'
    '  "explanation": "1-2 sentences",\n'
    '  "recommendation": "1 sentence action item"\n'
    '}}'
)

BATCH_CLASSIFY_TEMPLATE = (
    "Classify the severity of each finding below. "
    "Respond with a JSON array of objects.\n\n"
    "Findings:\n{findings_block}\n\n"
    "For each finding, respond with:\n"
    '{{\n'
    '  "index": <number>,\n'
    '  "severity": "critical|high|medium|low|false_positive",\n'
    '  "explanation": "1-2 sentences",\n'
    '  "recommendation": "1 sentence action item"\n'
    '}}'
)


def format_finding_for_prompt(
    finding_type: str,
    title: str,
    file_path: str,
    line: int,
    match: str,
    context: str,
    commit_hash: str,
    confidence: float,
) -> str:
    return CLASSIFY_TEMPLATE.format(
        finding_type=finding_type,
        title=title,
        file_path=file_path,
        line=line,
        match=match,
        context=context[:500],
        commit_hash=commit_hash,
        confidence=confidence,
    )


def format_batch_prompt(findings_texts: list[str]) -> str:
    block = "\n---\n".join(
        f"[{i}] {text}" for i, text in enumerate(findings_texts)
    )
    return BATCH_CLASSIFY_TEMPLATE.format(findings_block=block)
