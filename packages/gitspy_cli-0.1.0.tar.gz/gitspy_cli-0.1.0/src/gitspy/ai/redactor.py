from __future__ import annotations

import re

REDACTION_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{36,}"),
    re.compile(r"github_pat_[A-Za-z0-9_]{22,}"),
    re.compile(r"glpat-[A-Za-z0-9\-_]{20,}"),
    re.compile(r"sk_live_[0-9a-zA-Z]{24,}"),
    re.compile(r"rk_live_[0-9a-zA-Z]{24,}"),
    re.compile(r"xox[bporas]-[0-9]+-[0-9]+-[a-zA-Z0-9]+"),
    re.compile(r"AIza[0-9A-Za-z\-_]{35}"),
    re.compile(r"-----BEGIN\s+(?:RSA|EC|DSA|OPENSSH|PGP)\s+PRIVATE\s+KEY-----[\s\S]*?-----END\s+\w+\s+PRIVATE\s+KEY-----"),
    re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+"),
    re.compile(r"SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}"),
    re.compile(r"npm_[A-Za-z0-9]{36}"),
    re.compile(r"pypi-[A-Za-z0-9_-]{50,}"),
    re.compile(r"sk-[A-Za-z0-9]{20}T3BlbkFJ[A-Za-z0-9]{20}"),
    re.compile(r"sk-ant-api03-[A-Za-z0-9_-]{90,}"),
    re.compile(r"dckr_pat_[A-Za-z0-9_-]{27,}"),
    re.compile(r"hvs\.[A-Za-z0-9_-]{24,}"),
    re.compile(r"(?:mongodb|postgres|mysql|redis|amqp)://[^\s\"']{10,}"),
    re.compile(r'(?i)(?:password|secret|token|apikey|api_key|access_key|auth_token)\s*[=:]\s*["\'][^\s"\']{8,}["\']'),
]


def redact(text: str) -> str:
    result = text
    for pattern in REDACTION_PATTERNS:
        result = pattern.sub("[REDACTED]", result)
    return result
