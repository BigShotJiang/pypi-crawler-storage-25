from __future__ import annotations

from collections import Counter

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from gitspy.core.models import Finding, FindingType, ScanResult, Severity

console = Console()

SEVERITY_COLORS: dict[Severity, str] = {
    Severity.CRITICAL: "bold red",
    Severity.HIGH: "red",
    Severity.MEDIUM: "yellow",
    Severity.LOW: "blue",
    Severity.INFO: "dim",
}

GRADE_COLORS: dict[str, str] = {
    "A+": "bold green",
    "A": "green",
    "B": "cyan",
    "C": "yellow",
    "D": "red",
    "F": "bold red",
}


def _score_bar(score: int, width: int = 40) -> Text:
    filled = int(score / 100 * width)
    empty = width - filled

    if score >= 85:
        color = "green"
    elif score >= 50:
        color = "yellow"
    else:
        color = "red"

    bar = Text()
    bar.append("█" * filled, style=color)
    bar.append("░" * empty, style="dim")
    bar.append(f" {score}/100", style="bold")
    return bar


def _summary_table(result: ScanResult) -> Table:
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="dim")
    table.add_column("Value")

    table.add_row("Repository", f"{result.repo.owner}/{result.repo.name}")
    table.add_row("Commits scanned", str(result.scanned_commits))
    table.add_row("Scan duration", f"{result.scan_duration_seconds:.1f}s")
    table.add_row("GitSpy version", result.gitspy_version)
    return table


def _module_counts(result: ScanResult) -> Table:
    table = Table(show_header=True, box=None, padding=(0, 1))
    table.add_column("Module", style="bold")
    table.add_column("Findings", justify="right")
    table.add_column("Errors", justify="right")

    for module in result.modules:
        error_text = Text(module.error, style="red") if module.error else Text("-", style="dim")
        table.add_row(
            module.module_name,
            str(len(module.findings)),
            error_text,
        )

    return table


def _findings_table(result: ScanResult) -> Table:
    table = Table(show_header=True, padding=(0, 1))
    table.add_column("Severity", width=10)
    table.add_column("Type", width=14)
    table.add_column("Title")
    table.add_column("File", max_width=40)
    table.add_column("Line", justify="right", width=5)
    table.add_column("Commit", width=12)

    sorted_findings = sorted(
        result.all_findings,
        key=lambda f: ["critical", "high", "medium", "low", "info"].index(f.severity.value),
    )

    for f in sorted_findings:
        color = SEVERITY_COLORS.get(f.severity, "white")
        dupes = f.metadata.get("duplicate_count", "")
        title = f.title
        if dupes and int(dupes) > 1:
            title += f" (x{dupes})"
        table.add_row(
            Text(f.severity.value.upper(), style=color),
            f.finding_type.value,
            title,
            f.file_path,
            str(f.line) if f.line else "-",
            f.commit_hash or "-",
        )

    return table


def _build_action_summary(result: ScanResult) -> list[str]:
    findings = result.all_findings
    if not findings:
        return []

    lines: list[str] = []

    counts: Counter[str] = Counter()
    for f in findings:
        counts[f.severity.value] += 1

    parts = []
    for sev in ("critical", "high", "medium", "low", "info"):
        if counts[sev]:
            parts.append(f"{counts[sev]} {sev}")
    if parts:
        lines.append(f"Found {', '.join(parts)}.")

    criticals = [f for f in findings if f.severity == Severity.CRITICAL]
    if criticals:
        for c in criticals[:3]:
            if c.finding_type == FindingType.SECRET_LEAK:
                lines.append(f"Rotate secret in {c.file_path} immediately.")
            elif c.finding_type == FindingType.VULNERABLE_DEPENDENCY:
                cve = c.metadata.get("cve_id", "")
                lines.append(f"Upgrade {c.match} ({cve}).")
            elif c.finding_type == FindingType.SUSPICIOUS_PATTERN:
                lines.append(f"Review suspicious code in {c.file_path}:{c.line}.")

    highs = [f for f in findings if f.severity == Severity.HIGH]
    secret_highs = [f for f in highs if f.finding_type == FindingType.SECRET_LEAK]
    if secret_highs:
        unique_files = {f.file_path for f in secret_highs}
        if len(unique_files) <= 3:
            lines.append(f"Secrets found in: {', '.join(sorted(unique_files))}.")
        else:
            lines.append(f"Secrets found in {len(unique_files)} files.")

    vuln_highs = [f for f in highs if f.finding_type == FindingType.VULNERABLE_DEPENDENCY]
    if vuln_highs:
        lines.append(f"{len(vuln_highs)} high-severity vulnerable dependencies.")

    return lines


def render_console(result: ScanResult) -> None:
    console.print()

    grade_color = GRADE_COLORS.get(result.grade.value, "white")
    header = Text()
    header.append("GitSpy Report: ", style="bold")
    header.append(f"{result.repo.owner}/{result.repo.name}")

    console.print(Panel(header, style="bold"))

    console.print()
    console.print(Text("Trust Score: ", style="bold"), end="")
    console.print(_score_bar(result.trust_score), end="  ")
    console.print(Text(f"[Grade: {result.grade.value}]", style=grade_color))
    console.print()

    console.print(_summary_table(result))
    console.print()

    console.print(Text("Module Summary", style="bold underline"))
    console.print(_module_counts(result))
    console.print()

    if result.all_findings:
        console.print(Text("Findings", style="bold underline"))
        console.print(_findings_table(result))
    else:
        console.print(Text("No findings.", style="green bold"))

    action_lines = _build_action_summary(result)
    if action_lines:
        console.print()
        summary = Text()
        summary.append("ACTION REQUIRED\n", style="bold red underline")
        for line in action_lines:
            summary.append(f"  {line}\n", style="bold")
        console.print(Panel(summary, border_style="red"))

    console.print()
