from __future__ import annotations

import json
import sys

from gitspy.core.models import ScanResult


def render_json(result: ScanResult, output: str = "") -> None:
    data = result.model_dump(mode="json")

    if output:
        with open(output, "w") as f:
            json.dump(data, f, indent=2, default=str)
    else:
        json.dump(data, sys.stdout, indent=2, default=str)
        sys.stdout.write("\n")
