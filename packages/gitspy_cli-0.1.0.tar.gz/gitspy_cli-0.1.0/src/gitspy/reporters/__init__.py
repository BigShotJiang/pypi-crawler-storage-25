from __future__ import annotations

from gitspy.config import GitSpyConfig
from gitspy.core.models import ScanResult


def render(result: ScanResult, config: GitSpyConfig) -> None:
    fmt = config.report.format.lower()

    if fmt == "console":
        from gitspy.reporters.console import render_console
        render_console(result)
    elif fmt == "json":
        from gitspy.reporters.json_report import render_json
        render_json(result, config.report.output)
    elif fmt == "html":
        from gitspy.reporters.html import render_html
        render_html(result, config.report.output)
    elif fmt == "sarif":
        from gitspy.reporters.sarif import render_sarif
        render_sarif(result, config.report.output)
    elif fmt == "badge":
        from gitspy.reporters.badge import render_badge
        render_badge(result, config.report.output)
    else:
        from gitspy.reporters.console import render_console
        render_console(result)
