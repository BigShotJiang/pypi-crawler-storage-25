from __future__ import annotations

import json
from pathlib import Path

from gitspy import __version__
from gitspy.core.models import Finding, ScanResult, Severity

SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json"

SEVERITY_TO_SARIF: dict[Severity, str] = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "note",
}


def _finding_to_result(finding: Finding, index: int) -> dict:
    severity = finding.ai_severity or finding.severity
    message_parts = [finding.title]
    if finding.ai_explanation:
        message_parts.append(finding.ai_explanation)
    if finding.ai_recommendation:
        message_parts.append(finding.ai_recommendation)

    result: dict = {
        "ruleId": finding.metadata.get("rule_id", f"gitspy/{finding.finding_type.value}"),
        "level": SEVERITY_TO_SARIF.get(severity, "warning"),
        "message": {"text": " | ".join(message_parts)},
    }

    if finding.file_path:
        location: dict = {
            "physicalLocation": {
                "artifactLocation": {"uri": finding.file_path},
            }
        }
        if finding.line > 0:
            location["physicalLocation"]["region"] = {
                "startLine": finding.line,
            }
        result["locations"] = [location]

    if finding.commit_hash:
        result["partialFingerprints"] = {
            "commitHash": finding.commit_hash,
        }

    properties: dict = {
        "severity": severity.value,
        "findingType": finding.finding_type.value,
        "confidence": finding.module_confidence,
    }
    if finding.ai_severity:
        properties["aiClassified"] = True
    result["properties"] = properties

    return result


def _build_rules(findings: list[Finding]) -> list[dict]:
    seen: dict[str, dict] = {}
    for f in findings:
        rule_id = f.metadata.get("rule_id", f"gitspy/{f.finding_type.value}")
        if rule_id not in seen:
            seen[rule_id] = {
                "id": rule_id,
                "shortDescription": {"text": f.title},
                "defaultConfiguration": {
                    "level": SEVERITY_TO_SARIF.get(f.severity, "warning"),
                },
            }
    return list(seen.values())


def render_sarif(result: ScanResult, output: str = "") -> None:
    findings = sorted(
        result.all_findings,
        key=lambda f: ["critical", "high", "medium", "low", "info"].index(
            (f.ai_severity or f.severity).value
        ),
    )

    sarif: dict = {
        "$schema": SARIF_SCHEMA,
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "GitSpy",
                        "version": __version__,
                        "informationUri": "https://github.com/gitspy/gitspy",
                        "rules": _build_rules(findings),
                    }
                },
                "results": [
                    _finding_to_result(f, i) for i, f in enumerate(findings)
                ],
                "invocations": [
                    {
                        "executionSuccessful": True,
                        "properties": {
                            "trustScore": result.trust_score,
                            "grade": result.grade.value,
                        },
                    }
                ],
            }
        ],
    }

    output_path = output or "gitspy-results.sarif"
    Path(output_path).write_text(
        json.dumps(sarif, indent=2, default=str),
        encoding="utf-8",
    )
