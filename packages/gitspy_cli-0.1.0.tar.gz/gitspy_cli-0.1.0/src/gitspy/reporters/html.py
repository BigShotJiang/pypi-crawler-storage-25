from __future__ import annotations

import math
from datetime import datetime, timezone
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from gitspy.core.models import ScanResult, Severity

TEMPLATES_DIR = Path(__file__).parent.parent / "templates"


def _score_color(score: int) -> str:
    if score >= 85:
        return "#3fb950"
    if score >= 50:
        return "#d29922"
    return "#f85149"


def _grade_class(grade_value: str) -> str:
    return grade_value.lower().replace("+", "-plus")


def _count_by_severity(result: ScanResult) -> dict[str, int]:
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in result.all_findings:
        sev = (f.ai_severity or f.severity).value
        if sev in ("low", "info"):
            counts["low"] += 1
        elif sev in counts:
            counts[sev] += 1
    return counts


def _modules_with_findings(result: ScanResult) -> list[str]:
    seen: set[str] = set()
    for f in result.all_findings:
        seen.add(f.finding_type.value)
    return sorted(seen)


def render_html(result: ScanResult, output: str = "") -> None:
    env = Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)), autoescape=True)
    template = env.get_template("report.html.j2")

    score = result.trust_score
    circumference = 2 * math.pi * 60

    sorted_findings = sorted(
        result.all_findings,
        key=lambda f: ["critical", "high", "medium", "low", "info"].index(
            (f.ai_severity or f.severity).value
        ),
    )

    html = template.render(
        result=result,
        findings=sorted_findings,
        counts=_count_by_severity(result),
        score_color=_score_color(score),
        score_dash=circumference * score / 100,
        score_gap=circumference * (100 - score) / 100,
        grade_class=_grade_class(result.grade.value),
        modules_with_findings=_modules_with_findings(result),
        generated_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    )

    output_path = output or "gitspy-report.html"
    Path(output_path).write_text(html, encoding="utf-8")
