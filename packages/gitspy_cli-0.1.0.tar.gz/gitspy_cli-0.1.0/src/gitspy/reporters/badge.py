from __future__ import annotations

from pathlib import Path

from gitspy.core.models import Grade, ScanResult

GRADE_COLORS: dict[Grade, str] = {
    Grade.A_PLUS: "#3fb950",
    Grade.A: "#3fb950",
    Grade.B: "#58a6ff",
    Grade.C: "#d29922",
    Grade.D: "#f0883e",
    Grade.F: "#f85149",
}

SVG_TEMPLATE = """\
<svg xmlns="http://www.w3.org/2000/svg" width="{total_width}" height="20" role="img" aria-label="GitSpy: {grade}">
  <title>GitSpy: {grade}</title>
  <linearGradient id="s" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <clipPath id="r">
    <rect width="{total_width}" height="20" rx="3" fill="#fff"/>
  </clipPath>
  <g clip-path="url(#r)">
    <rect width="{label_width}" height="20" fill="#555"/>
    <rect x="{label_width}" width="{value_width}" height="20" fill="{color}"/>
    <rect width="{total_width}" height="20" fill="url(#s)"/>
  </g>
  <g fill="#fff" text-anchor="middle" font-family="Verdana,Geneva,DejaVu Sans,sans-serif" text-rendering="geometricPrecision" font-size="110">
    <text aria-hidden="true" x="{label_center}" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="{label_text_width}">{label}</text>
    <text x="{label_center}" y="140" transform="scale(.1)" fill="#fff" textLength="{label_text_width}">{label}</text>
    <text aria-hidden="true" x="{value_center}" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="{value_text_width}">{value_text}</text>
    <text x="{value_center}" y="140" transform="scale(.1)" fill="#fff" textLength="{value_text_width}">{value_text}</text>
  </g>
</svg>"""


def render_badge(result: ScanResult, output: str = "") -> None:
    grade = result.grade.value
    score = result.trust_score
    color = GRADE_COLORS.get(result.grade, "#8b949e")

    label = "GitSpy"
    value_text = f"{grade} ({score}/100)"

    label_width = 50
    value_width = 90
    total_width = label_width + value_width

    svg = SVG_TEMPLATE.format(
        total_width=total_width,
        label_width=label_width,
        value_width=value_width,
        label_center=label_width * 5,
        value_center=label_width * 10 + value_width * 5,
        label_text_width=len(label) * 60,
        value_text_width=len(value_text) * 60,
        label=label,
        value_text=value_text,
        color=color,
        grade=grade,
    )

    output_path = output or "badge.svg"
    Path(output_path).write_text(svg, encoding="utf-8")
