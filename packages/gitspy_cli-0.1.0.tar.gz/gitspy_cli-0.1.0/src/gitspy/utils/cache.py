from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

DEFAULT_TTL = 86400
DEFAULT_DB_PATH = Path.home() / ".cache" / "gitspy" / "nvd_cache.db"


class VulnCache:
    def __init__(self, db_path: Path = DEFAULT_DB_PATH, ttl: int = DEFAULT_TTL) -> None:
        self._ttl = ttl
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path))
        self._init_schema()

    def _init_schema(self) -> None:
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS vuln_cache ("
            "  key TEXT PRIMARY KEY,"
            "  data TEXT NOT NULL,"
            "  created_at REAL NOT NULL"
            ")"
        )
        self._conn.commit()

    def get(self, key: str) -> list[dict] | None:
        row = self._conn.execute(
            "SELECT data, created_at FROM vuln_cache WHERE key = ?", (key,)
        ).fetchone()

        if row is None:
            return None

        data, created_at = row
        if time.time() - created_at > self._ttl:
            self._conn.execute("DELETE FROM vuln_cache WHERE key = ?", (key,))
            self._conn.commit()
            return None

        return json.loads(data)

    def set(self, key: str, data: list[dict]) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO vuln_cache (key, data, created_at) VALUES (?, ?, ?)",
            (key, json.dumps(data), time.time()),
        )
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()
