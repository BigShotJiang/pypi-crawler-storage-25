from __future__ import annotations

import math
from collections import Counter


def shannon_entropy(data: str) -> float:
    if not data:
        return 0.0

    counter = Counter(data)
    length = len(data)
    entropy = 0.0

    for count in counter.values():
        probability = count / length
        if probability > 0:
            entropy -= probability * math.log2(probability)

    return entropy
