from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field


class SecretsConfig(BaseModel):
    depth: int = 500
    entropy_threshold: float = 4.5
    ignore_paths: list[str] = Field(default_factory=lambda: [
        "**/*_test.go",
        "**/test_*.py",
        "**/fixtures/**",
    ])
    custom_rules: list[dict[str, Any]] = Field(default_factory=list)


class ScaConfig(BaseModel):
    nvd_api_key: str = ""
    ignore_cves: list[str] = Field(default_factory=list)
    severity_threshold: str = "medium"


class PatternsConfig(BaseModel):
    languages: list[str] = Field(default_factory=lambda: [
        "python", "javascript", "typescript",
    ])
    ignore_paths: list[str] = Field(default_factory=list)


class ModulesConfig(BaseModel):
    secrets: bool = True
    sca: bool = True
    patterns: bool = True
    repo_health: bool = True


class AiConfig(BaseModel):
    provider: str = "none"
    model: str = ""
    api_key_env: str = "OPENAI_API_KEY"


class ReportConfig(BaseModel):
    format: str = "console"
    output: str = ""


class GitSpyConfig(BaseModel):
    modules: ModulesConfig = Field(default_factory=ModulesConfig)
    secrets: SecretsConfig = Field(default_factory=SecretsConfig)
    sca: ScaConfig = Field(default_factory=ScaConfig)
    patterns: PatternsConfig = Field(default_factory=PatternsConfig)
    ai: AiConfig = Field(default_factory=AiConfig)
    report: ReportConfig = Field(default_factory=ReportConfig)

    @classmethod
    def from_yaml(cls, path: Path) -> GitSpyConfig:
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        return cls.model_validate(data)

    @classmethod
    def load(cls, config_path: Path | None = None) -> GitSpyConfig:
        if config_path and config_path.exists():
            return cls.from_yaml(config_path)

        default_path = Path(".gitspy.yml")
        if default_path.exists():
            return cls.from_yaml(default_path)

        return cls()
