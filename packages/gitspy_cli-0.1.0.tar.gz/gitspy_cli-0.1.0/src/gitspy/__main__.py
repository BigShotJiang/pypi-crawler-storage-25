from gitspy.cli import app

app()
