from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

from gitspy import __version__
from gitspy.config import GitSpyConfig

EXIT_CLEAN = 0
EXIT_FINDINGS = 1
EXIT_ERROR = 2

app = typer.Typer(
    name="gitspy",
    help="AI-powered supply-chain security scanner for GitHub repositories",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

_console = Console()


@app.command()
def scan(
    target: Annotated[str, typer.Argument(help="Repository URL or local path to scan")],
    modules: Annotated[Optional[str], typer.Option(
        "--modules", "-m", help="Comma-separated modules: secrets,sca,patterns,repo_health"
    )] = None,
    depth: Annotated[int, typer.Option("--depth", "-d", help="Max commits to scan")] = 500,
    format_: Annotated[str, typer.Option("--format", "-f", help="Output format")] = "console",
    output: Annotated[str, typer.Option("--output", "-o", help="Output file path")] = "",
    ai: Annotated[str, typer.Option("--ai", help="AI provider")] = "none",
    model: Annotated[str, typer.Option("--model", help="AI model name")] = "",
    config: Annotated[Optional[Path], typer.Option("--config", "-c", help="Config file")] = None,
    fail_on: Annotated[str, typer.Option(
        "--fail-on", help="Exit with code 1 if severity >= threshold"
    )] = "critical",
    exclude: Annotated[Optional[str], typer.Option(
        "--exclude", "-e", help="Comma-separated glob patterns to exclude"
    )] = None,
    quiet: Annotated[bool, typer.Option("--quiet", "-q", help="Minimal output")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-V", help="Verbose output")] = False,
) -> None:
    console = Console(quiet=quiet)

    try:
        cfg = GitSpyConfig.load(config)
    except Exception as e:
        _console.print(f"[red]Config error: {e}[/red]")
        raise typer.Exit(code=EXIT_ERROR)

    if modules:
        module_list = [m.strip() for m in modules.split(",")]
        cfg.modules.secrets = "secrets" in module_list
        cfg.modules.sca = "sca" in module_list
        cfg.modules.patterns = "patterns" in module_list
        cfg.modules.repo_health = "repo_health" in module_list

    if exclude:
        extra_paths = [p.strip() for p in exclude.split(",")]
        cfg.secrets.ignore_paths.extend(extra_paths)
        cfg.patterns.ignore_paths.extend(extra_paths)

    cfg.secrets.depth = depth
    cfg.report.format = format_
    cfg.report.output = output
    cfg.ai.provider = ai
    if model:
        cfg.ai.model = model

    try:
        from gitspy.core.orchestrator import run_scan
        result = run_scan(target, cfg, quiet=quiet, verbose=verbose)
    except SystemExit:
        raise
    except Exception as e:
        _console.print(f"[red]Scan error: {e}[/red]")
        raise typer.Exit(code=EXIT_ERROR)

    from gitspy.reporters import render
    if not (format_ == "console" and quiet):
        render(result, cfg)

    if output and format_ != "console":
        console.print(f"[green]Report saved to {output}[/green]")

    console.print(
        f"[bold]Trust Score: {result.trust_score}/100 [Grade: {result.grade.value}] "
        f"| {len(result.all_findings)} findings in {result.scan_duration_seconds:.1f}s[/bold]"
    )

    severity_order = ["critical", "high", "medium", "low", "info"]
    threshold_idx = severity_order.index(fail_on)
    for finding in result.all_findings:
        if severity_order.index(finding.severity.value) <= threshold_idx:
            raise typer.Exit(code=EXIT_FINDINGS)

    raise typer.Exit(code=EXIT_CLEAN)


@app.command()
def compare(
    before: Annotated[str, typer.Argument(help="Path to first JSON report (before)")],
    after: Annotated[str, typer.Argument(help="Path to second JSON report (after)")],
) -> None:
    try:
        with open(before) as f:
            data_before = json.load(f)
        with open(after) as f:
            data_after = json.load(f)
    except Exception as e:
        _console.print(f"[red]Cannot read reports: {e}[/red]")
        raise typer.Exit(code=EXIT_ERROR)

    findings_before = {
        f"{f['finding_type']}|{f['file_path']}|{f['title']}|{f['match']}"
        for f in _extract_findings(data_before)
    }
    findings_after = {
        f"{f['finding_type']}|{f['file_path']}|{f['title']}|{f['match']}"
        for f in _extract_findings(data_after)
    }
    findings_after_list = _extract_findings(data_after)
    findings_before_list = _extract_findings(data_before)

    new_keys = findings_after - findings_before
    fixed_keys = findings_before - findings_after

    score_before = data_before.get("trust_score", "?")
    score_after = data_after.get("trust_score", "?")
    grade_before = data_before.get("grade", "?")
    grade_after = data_after.get("grade", "?")

    _console.print()
    _console.print("[bold]GitSpy Compare[/bold]")
    _console.print()

    if isinstance(score_before, int) and isinstance(score_after, int):
        diff = score_after - score_before
        arrow = "[green]+{diff}[/green]" if diff > 0 else f"[red]{diff}[/red]" if diff < 0 else "[dim]0[/dim]"
        arrow = arrow.format(diff=diff)
        _console.print(f"  Score: {score_before} ({grade_before}) -> {score_after} ({grade_after})  {arrow}")
    else:
        _console.print(f"  Score: {score_before} -> {score_after}")

    _console.print(f"  Findings: {len(findings_before_list)} -> {len(findings_after_list)}")
    _console.print()

    if new_keys:
        _console.print(f"[red bold]  + {len(new_keys)} NEW findings:[/red bold]")
        for f in findings_after_list:
            key = f"{f['finding_type']}|{f['file_path']}|{f['title']}|{f['match']}"
            if key in new_keys:
                sev = f.get("severity", "?")
                _console.print(f"    [red][{sev.upper()}][/red] {f['title']}  {f['file_path']}")
    else:
        _console.print("[green]  + 0 new findings[/green]")

    _console.print()

    if fixed_keys:
        _console.print(f"[green bold]  - {len(fixed_keys)} FIXED findings:[/green bold]")
        for f in findings_before_list:
            key = f"{f['finding_type']}|{f['file_path']}|{f['title']}|{f['match']}"
            if key in fixed_keys:
                _console.print(f"    [green][FIXED][/green] {f['title']}  {f['file_path']}")
    else:
        _console.print("[dim]  - 0 fixed findings[/dim]")

    _console.print()

    if new_keys:
        raise typer.Exit(code=EXIT_FINDINGS)
    raise typer.Exit(code=EXIT_CLEAN)


def _extract_findings(data: dict) -> list[dict]:
    findings: list[dict] = []
    for module in data.get("modules", []):
        findings.extend(module.get("findings", []))
    return findings


@app.command()
def badge(
    target: Annotated[str, typer.Argument(help="Repository URL or local path")],
    output: Annotated[str, typer.Option("--output", "-o")] = "badge.svg",
    config: Annotated[Optional[Path], typer.Option("--config", "-c")] = None,
) -> None:
    cfg = GitSpyConfig.load(config)
    cfg.report.format = "badge"
    cfg.report.output = output

    from gitspy.core.orchestrator import run_scan
    result = run_scan(target, cfg)

    from gitspy.reporters.badge import render_badge
    render_badge(result, output)
    _console.print(f"[green]Badge saved to {output}[/green]")


@app.command()
def version() -> None:
    _console.print(f"GitSpy v{__version__}")
