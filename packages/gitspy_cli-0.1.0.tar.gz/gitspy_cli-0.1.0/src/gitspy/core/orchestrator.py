from __future__ import annotations

import time
from pathlib import Path

from git import Repo
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn

from gitspy import __version__
from gitspy.config import GitSpyConfig
from gitspy.core.git_walker import WalkerResult, cleanup_repo, resolve_target, walk_history
from gitspy.core.models import Finding, ModuleResult, RepoMeta, ScanResult
from gitspy.core.scoring import calculate_trust_score


def _build_repo_meta(repo_path: Path, target: str) -> RepoMeta:
    repo = Repo(str(repo_path))

    if target.startswith(("http://", "https://", "git@")):
        parts = target.rstrip("/").rstrip(".git").split("/")
        name = parts[-1] if parts else ""
        owner = parts[-2] if len(parts) >= 2 else ""
    else:
        name = repo_path.name
        owner = ""

    commits = list(repo.iter_commits(max_count=1))
    last_commit_date = commits[0].committed_datetime if commits else None

    contributors: set[str] = set()
    for c in repo.iter_commits(max_count=500):
        contributors.add(str(c.author))

    has_security = (repo_path / "SECURITY.md").exists()
    has_codeowners = (
        (repo_path / "CODEOWNERS").exists()
        or (repo_path / ".github" / "CODEOWNERS").exists()
    )
    has_ci = (
        (repo_path / ".github" / "workflows").exists()
        or (repo_path / ".gitlab-ci.yml").exists()
        or (repo_path / "Jenkinsfile").exists()
    )

    return RepoMeta(
        url=target,
        name=name,
        owner=owner,
        default_branch=_get_default_branch(repo),
        contributors_count=len(contributors),
        last_commit_date=last_commit_date,
        has_security_md=has_security,
        has_codeowners=has_codeowners,
        has_ci=has_ci,
    )


def _get_default_branch(repo: Repo) -> str:
    try:
        return str(repo.active_branch)
    except TypeError:
        return "main"


def _run_module(
    name: str,
    walker: WalkerResult,
    repo_path: Path,
    config: GitSpyConfig,
) -> ModuleResult:
    start = time.monotonic()

    try:
        if name == "secrets":
            from gitspy.scanners.secrets import scan_secrets
            result = scan_secrets(walker.diffs, config.secrets)
        elif name == "sca":
            from gitspy.scanners.sca import scan_sca
            result = scan_sca(repo_path, config.sca)
        elif name == "patterns":
            from gitspy.scanners.patterns import scan_patterns
            result = scan_patterns(repo_path, config.patterns)
        elif name == "repo_health":
            from gitspy.scanners.repo_health import scan_repo_health
            result = scan_repo_health(repo_path)
        else:
            result = ModuleResult(module_name=name)
    except Exception as e:
        result = ModuleResult(module_name=name, error=str(e))

    result.duration_seconds = time.monotonic() - start
    return result


def _dedup_findings(findings: list[Finding]) -> list[Finding]:
    seen: dict[str, Finding] = {}

    for f in findings:
        key = f"{f.finding_type.value}|{f.file_path}|{f.title}|{f.match}"

        if key in seen:
            existing = seen[key]
            commits = existing.metadata.get("seen_in_commits", existing.commit_hash)
            if f.commit_hash and f.commit_hash not in str(commits):
                existing.metadata["seen_in_commits"] = f"{commits}, {f.commit_hash}"
            count = int(existing.metadata.get("duplicate_count", 1))
            existing.metadata["duplicate_count"] = count + 1
        else:
            seen[key] = f

    return list(seen.values())


def run_scan(
    target: str,
    config: GitSpyConfig,
    quiet: bool = False,
    verbose: bool = False,
) -> ScanResult:
    start = time.monotonic()
    console = Console(quiet=quiet)

    progress = Progress(
        SpinnerColumn(style="green"),
        TextColumn("[bold green]{task.description}"),
        BarColumn(bar_width=30, style="green", complete_style="bold green"),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=not verbose,
    )

    with progress:
        clone_task = progress.add_task("Cloning repository...", total=None)
        repo_path, is_temp = resolve_target(target)
        progress.update(clone_task, completed=1, total=1, description="Repository ready")

        meta_task = progress.add_task("Analyzing repository metadata...", total=None)
        meta = _build_repo_meta(repo_path, target)
        progress.update(meta_task, completed=1, total=1, description="Metadata collected")

        walk_task = progress.add_task(
            f"Walking git history (up to {config.secrets.depth} commits)...", total=None,
        )
        walker = walk_history(repo_path, config.secrets.depth)
        meta.total_commits = walker.total_commits
        progress.update(
            walk_task, completed=1, total=1,
            description=f"History walked ({walker.total_commits} commits, {len(walker.diffs)} diffs)",
        )

        enabled = {
            "secrets": config.modules.secrets,
            "sca": config.modules.sca,
            "patterns": config.modules.patterns,
            "repo_health": config.modules.repo_health,
        }
        active_modules = [n for n, e in enabled.items() if e]
        scan_task = progress.add_task("Scanning...", total=len(active_modules))

        modules: list[ModuleResult] = []
        for module_name in active_modules:
            progress.update(scan_task, description=f"Scanning: {module_name}")
            result = _run_module(module_name, walker, repo_path, config)
            modules.append(result)
            if verbose:
                status = f"{len(result.findings)} findings" if not result.error else f"error: {result.error[:40]}"
                progress.console.print(
                    f"  [dim]> {module_name}: {status} ({result.duration_seconds:.1f}s)[/dim]"
                )
            progress.advance(scan_task)
        progress.update(scan_task, description="Scan complete")

        all_findings: list[Finding] = []
        for m in modules:
            all_findings.extend(m.findings)

        raw_count = len(all_findings)
        all_findings = _dedup_findings(all_findings)
        dedup_count = raw_count - len(all_findings)

        if verbose and dedup_count > 0:
            progress.console.print(
                f"  [dim]> Deduplicated: {raw_count} -> {len(all_findings)} "
                f"(-{dedup_count} duplicates)[/dim]"
            )

        if config.ai.provider != "none" and all_findings:
            ai_task = progress.add_task("AI classification...", total=None)
            from gitspy.ai.classifier import classify_findings
            all_findings = classify_findings(all_findings, config.ai)
            progress.update(ai_task, completed=1, total=1, description="AI classification done")

        score_task = progress.add_task("Computing trust score...", total=None)
        trust_score, grade = calculate_trust_score(all_findings)
        progress.update(score_task, completed=1, total=1, description="Score computed")

    if is_temp:
        cleanup_repo(repo_path)

    return ScanResult(
        repo=meta,
        modules=modules,
        trust_score=trust_score,
        grade=grade,
        scan_duration_seconds=time.monotonic() - start,
        scanned_commits=walker.total_commits,
        gitspy_version=__version__,
    )
