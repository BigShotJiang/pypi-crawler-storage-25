from __future__ import annotations

from gitspy.core.models import Finding, FindingType, Grade, Severity


PENALTY_MAP: dict[tuple[FindingType, Severity], int] = {
    (FindingType.SECRET_LEAK, Severity.CRITICAL): 30,
    (FindingType.SECRET_LEAK, Severity.HIGH): 15,
    (FindingType.SECRET_LEAK, Severity.MEDIUM): 8,
    (FindingType.SECRET_LEAK, Severity.LOW): 3,
    (FindingType.VULNERABLE_DEPENDENCY, Severity.CRITICAL): 25,
    (FindingType.VULNERABLE_DEPENDENCY, Severity.HIGH): 15,
    (FindingType.VULNERABLE_DEPENDENCY, Severity.MEDIUM): 8,
    (FindingType.SUSPICIOUS_PATTERN, Severity.CRITICAL): 25,
    (FindingType.SUSPICIOUS_PATTERN, Severity.HIGH): 20,
    (FindingType.SUSPICIOUS_PATTERN, Severity.MEDIUM): 10,
    (FindingType.REPO_HEALTH, Severity.MEDIUM): 10,
    (FindingType.REPO_HEALTH, Severity.LOW): 5,
    (FindingType.REPO_HEALTH, Severity.INFO): 3,
}


def compute_penalty(finding: Finding) -> int:
    key = (finding.finding_type, finding.ai_severity or finding.severity)
    return PENALTY_MAP.get(key, 2)


def score_to_grade(score: int) -> Grade:
    if score >= 95:
        return Grade.A_PLUS
    if score >= 85:
        return Grade.A
    if score >= 70:
        return Grade.B
    if score >= 50:
        return Grade.C
    if score >= 25:
        return Grade.D
    return Grade.F


def calculate_trust_score(findings: list[Finding]) -> tuple[int, Grade]:
    total_penalty = sum(compute_penalty(f) for f in findings)
    score = max(0, min(100, 100 - total_penalty))
    return score, score_to_grade(score)
