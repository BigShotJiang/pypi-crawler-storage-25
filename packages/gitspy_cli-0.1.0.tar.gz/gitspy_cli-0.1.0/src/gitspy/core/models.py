from __future__ import annotations

from enum import Enum
from datetime import datetime

from pydantic import BaseModel, Field


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class FindingType(str, Enum):
    SECRET_LEAK = "secret_leak"
    VULNERABLE_DEPENDENCY = "vulnerable_dependency"
    SUSPICIOUS_PATTERN = "suspicious_pattern"
    REPO_HEALTH = "repo_health"


class Finding(BaseModel):
    finding_type: FindingType
    severity: Severity
    title: str
    file_path: str = ""
    line: int = 0
    match: str = ""
    context: str = ""
    commit_hash: str = ""
    commit_date: datetime | None = None
    commit_author: str = ""
    module_confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    ai_severity: Severity | None = None
    ai_explanation: str = ""
    ai_recommendation: str = ""
    metadata: dict[str, str | int | float | bool] = Field(default_factory=dict)


class RepoMeta(BaseModel):
    url: str
    name: str
    owner: str = ""
    default_branch: str = "main"
    total_commits: int = 0
    contributors_count: int = 0
    last_commit_date: datetime | None = None
    created_date: datetime | None = None
    has_security_md: bool = False
    has_codeowners: bool = False
    has_ci: bool = False
    stars: int = 0
    is_fork: bool = False
    is_archived: bool = False


class ModuleResult(BaseModel):
    module_name: str
    findings: list[Finding] = Field(default_factory=list)
    duration_seconds: float = 0.0
    error: str = ""


class Grade(str, Enum):
    A_PLUS = "A+"
    A = "A"
    B = "B"
    C = "C"
    D = "D"
    F = "F"


class ScanResult(BaseModel):
    repo: RepoMeta
    modules: list[ModuleResult] = Field(default_factory=list)
    trust_score: int = Field(default=100, ge=0, le=100)
    grade: Grade = Grade.A_PLUS
    scan_duration_seconds: float = 0.0
    scanned_commits: int = 0
    gitspy_version: str = ""

    @property
    def all_findings(self) -> list[Finding]:
        findings: list[Finding] = []
        for module in self.modules:
            findings.extend(module.findings)
        return findings

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.all_findings if f.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.all_findings if f.severity == Severity.HIGH)
