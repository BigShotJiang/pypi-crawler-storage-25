from __future__ import annotations

import hashlib
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from git import NULL_TREE, Repo, Diff, Commit

CACHE_DIR = Path.home() / ".cache" / "gitspy" / "repos"


@dataclass
class DiffEntry:
    file_path: str
    content: str
    commit: CommitInfo


@dataclass
class CommitInfo:
    hash: str
    author: str
    date: str
    message: str


@dataclass
class WalkerResult:
    repo_path: Path
    is_temp: bool
    total_commits: int = 0
    diffs: list[DiffEntry] = field(default_factory=list)


def _url_to_cache_key(url: str) -> str:
    normalized = url.rstrip("/").rstrip(".git").lower()
    return hashlib.sha256(normalized.encode()).hexdigest()[:16]


def _cached_repo_path(url: str) -> Path:
    return CACHE_DIR / _url_to_cache_key(url)


def clone_repo(url: str) -> Path:
    cached = _cached_repo_path(url)

    if cached.exists() and (cached / ".git").exists():
        try:
            repo = Repo(str(cached))
            repo.remotes.origin.fetch()
            return cached
        except Exception:
            shutil.rmtree(cached, ignore_errors=True)

    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    try:
        Repo.clone_from(url, str(cached))
    except Exception as e:
        shutil.rmtree(cached, ignore_errors=True)
        error_msg = str(e)
        if "not found" in error_msg.lower():
            raise SystemExit(f"[!] Repository not found: {url}") from None
        if "authentication" in error_msg.lower() or "403" in error_msg:
            raise SystemExit(f"[!] Access denied: {url} (private or requires auth)") from None
        raise SystemExit(f"[!] Failed to clone {url}: {error_msg}") from None

    return cached


def cleanup_repo(path: Path) -> None:
    if str(path).startswith(str(CACHE_DIR)):
        return
    if path.exists() and str(path).startswith(tempfile.gettempdir()):
        shutil.rmtree(path, ignore_errors=True)


def _commit_info(commit: Commit) -> CommitInfo:
    return CommitInfo(
        hash=commit.hexsha[:12],
        author=str(commit.author),
        date=commit.committed_datetime.isoformat(),
        message=commit.message.strip().split("\n")[0],
    )


def _extract_diff_content(diff: Diff) -> str:
    try:
        if diff.b_blob:
            return diff.b_blob.data_stream.read().decode("utf-8", errors="replace")
        if diff.a_blob:
            return diff.a_blob.data_stream.read().decode("utf-8", errors="replace")
    except Exception:
        pass
    return ""


def _diff_file_path(diff: Diff) -> str:
    return diff.b_path or diff.a_path or ""


def walk_history(repo_path: Path, max_commits: int = 500) -> WalkerResult:
    repo = Repo(str(repo_path))
    is_cached = str(repo_path).startswith(str(CACHE_DIR))
    result = WalkerResult(repo_path=repo_path, is_temp=not is_cached)

    commits = list(repo.iter_commits(max_count=max_commits))
    result.total_commits = len(commits)

    for commit in commits:
        info = _commit_info(commit)

        if commit.parents:
            parent = commit.parents[0]
            diffs = parent.diff(commit)
        else:
            diffs = commit.diff(NULL_TREE)

        for diff in diffs:
            path = _diff_file_path(diff)
            if not path:
                continue

            content = _extract_diff_content(diff)
            if not content:
                continue

            result.diffs.append(DiffEntry(
                file_path=path,
                content=content,
                commit=info,
            ))

    return result


def resolve_target(target: str) -> tuple[Path, bool]:
    local = Path(target)
    if local.exists() and (local / ".git").exists():
        return local, False

    repo_path = clone_repo(target)
    is_cached = str(repo_path).startswith(str(CACHE_DIR))
    return repo_path, not is_cached
