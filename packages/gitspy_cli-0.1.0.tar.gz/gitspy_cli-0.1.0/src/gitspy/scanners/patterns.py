from __future__ import annotations

import re
from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path, PurePosixPath

from gitspy.config import PatternsConfig
from gitspy.core.models import Finding, FindingType, ModuleResult, Severity

try:
    import tree_sitter
    from tree_sitter import Language, Parser

    _TS_AVAILABLE = True
except ImportError:
    _TS_AVAILABLE = False


LANGUAGE_EXTENSIONS: dict[str, list[str]] = {
    "python": [".py"],
    "javascript": [".js", ".mjs", ".cjs"],
    "typescript": [".ts", ".tsx"],
    "go": [".go"],
    "java": [".java"],
    "rust": [".rs"],
    "ruby": [".rb"],
    "php": [".php"],
    "c": [".c", ".h"],
    "cpp": [".cpp", ".cc", ".cxx", ".hpp"],
}

INSTALL_SCRIPT_NAMES = {
    "setup.py", "setup.cfg", "postinstall.js", "preinstall.js",
    "install.js", "postinstall.sh", "preinstall.sh",
}

INIT_FILE_NAMES = {"__init__.py", "index.js", "index.ts", "mod.rs", "lib.rs"}


@dataclass
class PatternRule:
    id: str
    name: str
    severity: Severity
    pattern: re.Pattern[str]
    file_filter: re.Pattern[str] | None = None
    context_boost: bool = False


OBFUSCATION_RULES: list[PatternRule] = [
    PatternRule(
        "eval-concat", "eval() with string concatenation",
        Severity.HIGH,
        re.compile(r"""eval\s*\(\s*(?:['"]\s*\+|.*\+\s*['"])"""),
    ),
    PatternRule(
        "eval-decode", "eval() with base64 decode",
        Severity.HIGH,
        re.compile(r"""eval\s*\(\s*(?:atob|base64\.b64decode|Base64\.decode|Buffer\.from)\s*\("""),
    ),
    PatternRule(
        "exec-decode", "exec() with decoded content",
        Severity.HIGH,
        re.compile(r"""exec\s*\(\s*(?:base64\.b64decode|compile|codecs\.decode|bytes\.fromhex)\s*\("""),
    ),
    PatternRule(
        "fromcharcode-chain", "String.fromCharCode chain",
        Severity.MEDIUM,
        re.compile(r"""String\.fromCharCode\s*\([0-9,\s]{20,}\)"""),
    ),
    PatternRule(
        "hex-string-long", "Long hex-encoded string",
        Severity.MEDIUM,
        re.compile(r"""(?:0x[0-9a-fA-F]{2}[,\s]*){25,}"""),
    ),
    PatternRule(
        "dynamic-import-var", "Dynamic import with variable",
        Severity.MEDIUM,
        re.compile(r"""(?:__import__|importlib\.import_module|require)\s*\(\s*[a-zA-Z_]"""),
    ),
    PatternRule(
        "char-array-join", "Character array join pattern",
        Severity.MEDIUM,
        re.compile(r"""\[\s*['"][a-zA-Z]['"](?:\s*,\s*['"][a-zA-Z]['"]){15,}\s*\]\.join"""),
    ),
    PatternRule(
        "reverse-string-exec", "Reversed string execution",
        Severity.HIGH,
        re.compile(r"""(?:\[::-1\]|\.reverse\(\)|\.split\(''\)\.reverse\(\)\.join).*(?:eval|exec|Function)"""),
    ),
]

BACKDOOR_RULES: list[PatternRule] = [
    PatternRule(
        "http-in-install", "HTTP request in install script",
        Severity.CRITICAL,
        re.compile(r"""(?:urllib|requests|http\.get|https\.get|fetch|axios|curl|wget)\s*[\(.]"""),
        file_filter=re.compile(r"""(?:setup\.py|postinstall|preinstall|install\.)"""),
        context_boost=True,
    ),
    PatternRule(
        "subprocess-in-init", "subprocess/os.system in __init__",
        Severity.HIGH,
        re.compile(r"""(?:subprocess\.|os\.system|os\.popen|os\.exec)\s*\("""),
        file_filter=re.compile(r"""(?:__init__\.py|index\.[jt]s)"""),
        context_boost=True,
    ),
    PatternRule(
        "reverse-shell", "Reverse shell pattern",
        Severity.CRITICAL,
        re.compile(
            r"""(?:socket\.socket|net\.Socket|new\s+Socket).*?"""
            r"""(?:connect|\.pipe|subprocess|exec|spawn|sh\s+-i)"""
        , re.DOTALL),
    ),
    PatternRule(
        "dns-exfiltration", "DNS/HTTP exfiltration pattern",
        Severity.HIGH,
        re.compile(
            r"""(?:dns\.resolve|fetch|http\.request|urllib).*?"""
            r"""(?:os\.environ|process\.env|getenv|hostname|whoami|uname)"""
        , re.DOTALL),
    ),
    PatternRule(
        "system-path-write", "Write to system directory",
        Severity.CRITICAL,
        re.compile(r"""(?:open|write|mkdir|mkdirSync)\s*\(\s*['"](?:/etc/|/usr/|C:\\Windows|/tmp/\.)"""),
    ),
    PatternRule(
        "env-exfiltration", "Environment variable exfiltration",
        Severity.HIGH,
        re.compile(
            r"""(?:os\.environ|process\.env|ENV)\s*(?:\[|\.get).*?"""
            r"""(?:post|put|fetch|request|send|urllib|http)"""
        , re.DOTALL),
    ),
    PatternRule(
        "crypto-miner", "Cryptocurrency miner indicators",
        Severity.CRITICAL,
        re.compile(r"""(?:stratum\+tcp://|coinhive|cryptonight|xmrig|minerd)""", re.I),
    ),
    PatternRule(
        "data-uri-exec", "Data URI execution",
        Severity.HIGH,
        re.compile(r"""data:(?:text/javascript|application/javascript)[;,].*(?:eval|Function)"""),
    ),
]

TYPOSQUATTING_INSTALL_RULES: list[PatternRule] = [
    PatternRule(
        "install-script-network", "Network call in package install script",
        Severity.HIGH,
        re.compile(r"""(?:urlopen|requests\.get|http\.get|https\.get|fetch|axios\.get|wget|curl)"""),
        file_filter=re.compile(r"""(?:setup\.py|setup\.cfg|postinstall|preinstall)"""),
    ),
    PatternRule(
        "install-script-exec", "Code execution in install script",
        Severity.HIGH,
        re.compile(r"""(?:exec|eval|subprocess\.call|os\.system|child_process\.exec)"""),
        file_filter=re.compile(r"""(?:setup\.py|postinstall|preinstall)"""),
    ),
]


def _get_language_for_file(file_path: str) -> str | None:
    suffix = PurePosixPath(file_path).suffix.lower()
    for lang, extensions in LANGUAGE_EXTENSIONS.items():
        if suffix in extensions:
            return lang
    return None


def _is_install_script(file_path: str) -> bool:
    name = PurePosixPath(file_path).name
    return name in INSTALL_SCRIPT_NAMES


def _is_init_file(file_path: str) -> bool:
    name = PurePosixPath(file_path).name
    return name in INIT_FILE_NAMES


def _get_line_number(content: str, pos: int) -> int:
    return content[:pos].count("\n") + 1


def _get_context(content: str, pos: int, lines: int = 5) -> str:
    all_lines = content.splitlines(keepends=True)
    current = 0
    target_line = 0
    for i, line in enumerate(all_lines):
        current += len(line)
        if current >= pos:
            target_line = i
            break
    start = max(0, target_line - lines)
    end = min(len(all_lines), target_line + lines + 1)
    return "".join(all_lines[start:end])


def _scan_with_regex(
    file_path: str,
    content: str,
    rules: list[PatternRule],
    allowed_languages: list[str],
) -> list[Finding]:
    findings: list[Finding] = []
    lang = _get_language_for_file(file_path)

    if lang and lang not in allowed_languages:
        return findings

    for rule in rules:
        if rule.file_filter and not rule.file_filter.search(file_path):
            continue

        for match in rule.pattern.finditer(content):
            severity = rule.severity
            confidence = 0.8

            if rule.context_boost:
                if _is_install_script(file_path):
                    severity = Severity.CRITICAL
                    confidence = 0.95
                elif _is_init_file(file_path):
                    confidence = 0.9

            findings.append(Finding(
                finding_type=FindingType.SUSPICIOUS_PATTERN,
                severity=severity,
                title=rule.name,
                file_path=file_path,
                line=_get_line_number(content, match.start()),
                match=match.group(0)[:120],
                context=_get_context(content, match.start()),
                module_confidence=confidence,
                metadata={"rule_id": rule.id, "language": lang or "unknown"},
            ))

    return findings


def _scan_tree_sitter(
    file_path: str,
    content: str,
    lang_name: str,
) -> list[Finding]:
    if not _TS_AVAILABLE:
        return []

    findings: list[Finding] = []

    try:
        lang_module = _load_language(lang_name)
        if lang_module is None:
            return findings

        parser = Parser()
        parser.language = lang_module
        tree = parser.parse(content.encode("utf-8"))
        root = tree.root_node

        findings.extend(_detect_eval_patterns(root, content, file_path, lang_name))
        findings.extend(_detect_exec_patterns(root, content, file_path, lang_name))

    except Exception:
        pass

    return findings


def _load_language(lang_name: str) -> Language | None:
    module_map = {
        "python": "tree_sitter_python",
        "javascript": "tree_sitter_javascript",
        "typescript": "tree_sitter_typescript",
        "go": "tree_sitter_go",
        "java": "tree_sitter_java",
        "rust": "tree_sitter_rust",
    }

    module_name = module_map.get(lang_name)
    if not module_name:
        return None

    try:
        import importlib
        mod = importlib.import_module(module_name)
        if hasattr(mod, "language"):
            return Language(mod.language())
        return None
    except (ImportError, Exception):
        return None


def _node_text(node, source: bytes) -> str:
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _walk_tree(node):
    yield node
    for child in node.children:
        yield from _walk_tree(child)


def _detect_eval_patterns(root, content: str, file_path: str, lang: str) -> list[Finding]:
    findings: list[Finding] = []
    source = content.encode("utf-8")

    for node in _walk_tree(root):
        if node.type != "call":
            continue

        func_node = node.children[0] if node.children else None
        if func_node is None:
            continue

        func_name = _node_text(func_node, source)

        if func_name in ("eval", "exec"):
            if _is_init_file(file_path) or _is_install_script(file_path):
                severity = Severity.HIGH
                confidence = 0.9
            else:
                severity = Severity.MEDIUM
                confidence = 0.6

            args_text = _node_text(node, source)
            if any(kw in args_text for kw in ("base64", "decode", "fromhex", "atob", "Buffer.from")):
                severity = Severity.CRITICAL
                confidence = 0.95

            findings.append(Finding(
                finding_type=FindingType.SUSPICIOUS_PATTERN,
                severity=severity,
                title=f"AST: {func_name}() call detected",
                file_path=file_path,
                line=node.start_point[0] + 1,
                match=args_text[:120],
                context=_get_context(content, node.start_byte),
                module_confidence=confidence,
                metadata={"rule_id": f"ast-{func_name}", "language": lang},
            ))

    return findings


def _detect_exec_patterns(root, content: str, file_path: str, lang: str) -> list[Finding]:
    findings: list[Finding] = []
    source = content.encode("utf-8")

    dangerous_calls = {
        "os.system", "os.popen", "os.exec", "os.execvp",
        "subprocess.call", "subprocess.run", "subprocess.Popen",
        "child_process.exec", "child_process.spawn",
    }

    for node in _walk_tree(root):
        if node.type != "call":
            continue

        func_text = ""
        if node.children:
            func_text = _node_text(node.children[0], source)

        if func_text not in dangerous_calls:
            continue

        if not (_is_init_file(file_path) or _is_install_script(file_path)):
            continue

        findings.append(Finding(
            finding_type=FindingType.SUSPICIOUS_PATTERN,
            severity=Severity.HIGH,
            title=f"AST: {func_text}() in sensitive file",
            file_path=file_path,
            line=node.start_point[0] + 1,
            match=_node_text(node, source)[:120],
            context=_get_context(content, node.start_byte),
            module_confidence=0.85,
            metadata={"rule_id": "ast-dangerous-exec", "language": lang},
        ))

    return findings


def scan_patterns(repo_path: Path, config: PatternsConfig) -> ModuleResult:
    findings: list[Finding] = []
    all_rules = OBFUSCATION_RULES + BACKDOOR_RULES + TYPOSQUATTING_INSTALL_RULES

    all_extensions: set[str] = set()
    for lang in config.languages:
        all_extensions.update(LANGUAGE_EXTENSIONS.get(lang, []))

    skip_dirs = {".git", "node_modules", ".venv", "venv", "env", "__pycache__", "docs", "doc", "examples", "example"}
    test_patterns = ["test_*", "*_test.*", "tests", "__tests__", "fixtures", "testdata"]

    for ext in all_extensions:
        for file in repo_path.rglob(f"*{ext}"):
            if skip_dirs & set(file.parts):
                continue

            relative = str(file.relative_to(repo_path))

            if any(fnmatch(relative, pat) for pat in config.ignore_paths):
                continue

            if any(fnmatch(file.name, tp) for tp in test_patterns):
                continue
            if any(tp in file.parts for tp in ("tests", "__tests__", "test", "fixtures")):
                continue

            try:
                content = file.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            if len(content) > 1_000_000:
                continue

            findings.extend(_scan_with_regex(relative, content, all_rules, config.languages))

            lang = _get_language_for_file(relative)
            if lang and lang in config.languages:
                findings.extend(_scan_tree_sitter(relative, content, lang))

    return ModuleResult(module_name="patterns", findings=findings)
