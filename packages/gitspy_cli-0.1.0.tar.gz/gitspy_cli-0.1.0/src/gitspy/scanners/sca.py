from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass
from pathlib import Path

import httpx

from gitspy.config import ScaConfig
from gitspy.core.models import Finding, FindingType, ModuleResult, Severity
from gitspy.utils.cache import VulnCache
from gitspy.utils.levenshtein import distance as lev_distance

NVD_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
OSV_API_URL = "https://api.osv.dev/v1/query"

POPULAR_PACKAGES: dict[str, list[str]] = {
    "npm": [
        "lodash", "express", "react", "axios", "chalk", "debug", "commander",
        "moment", "request", "async", "bluebird", "underscore", "webpack",
        "babel-core", "typescript", "eslint", "jest", "mocha", "gulp", "grunt",
        "next", "vue", "angular", "jquery", "socket.io", "mongoose", "sequelize",
        "passport", "helmet", "cors", "dotenv", "uuid", "ramda", "rxjs",
    ],
    "pypi": [
        "requests", "flask", "django", "numpy", "pandas", "scipy", "boto3",
        "pillow", "sqlalchemy", "celery", "redis", "pytest", "setuptools",
        "cryptography", "pyyaml", "jinja2", "click", "httpx", "fastapi",
        "uvicorn", "pydantic", "aiohttp", "beautifulsoup4", "scrapy",
        "matplotlib", "tensorflow", "torch", "transformers", "openai",
    ],
}

SEVERITY_THRESHOLDS = {"critical": 9.0, "high": 7.0, "medium": 4.0, "low": 0.1}

MAX_CONCURRENT = 15
MAX_RETRIES = 3
RETRY_BACKOFF = [1.0, 3.0, 8.0]


@dataclass
class Dependency:
    name: str
    version: str
    ecosystem: str
    file_path: str


def _parse_requirements_txt(content: str, file_path: str) -> list[Dependency]:
    deps: list[Dependency] = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        match = re.match(r"([A-Za-z0-9_.-]+)\s*[=<>!~]+\s*([0-9][^\s,;]*)", line)
        if match:
            deps.append(Dependency(match.group(1).lower(), match.group(2), "pypi", file_path))
        elif re.match(r"^[A-Za-z0-9_.-]+$", line):
            deps.append(Dependency(line.lower(), "", "pypi", file_path))
    return deps


def _parse_pipfile_lock(content: str, file_path: str) -> list[Dependency]:
    deps: list[Dependency] = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps

    for section in ("default", "develop"):
        packages = data.get(section, {})
        for name, info in packages.items():
            version = info.get("version", "").lstrip("=")
            deps.append(Dependency(name.lower(), version, "pypi", file_path))
    return deps


def _parse_pyproject_toml(content: str, file_path: str) -> list[Dependency]:
    deps: list[Dependency] = []
    in_deps = False
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("dependencies") and "=" in stripped:
            in_deps = True
            continue
        if in_deps:
            if stripped == "]":
                in_deps = False
                continue
            match = re.match(r'"([A-Za-z0-9_.-]+)\s*[><=!~]+\s*([0-9][^"]*)"', stripped)
            if match:
                deps.append(Dependency(match.group(1).lower(), match.group(2), "pypi", file_path))
    return deps


def _parse_package_json(content: str, file_path: str) -> list[Dependency]:
    deps: list[Dependency] = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps

    for section in ("dependencies", "devDependencies", "peerDependencies"):
        packages = data.get(section, {})
        for name, ver_range in packages.items():
            version = re.sub(r"[^0-9.]", "", ver_range).strip(".")
            deps.append(Dependency(name.lower(), version, "npm", file_path))
    return deps


def _parse_package_lock_json(content: str, file_path: str) -> list[Dependency]:
    deps: list[Dependency] = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps

    packages = data.get("packages", data.get("dependencies", {}))
    for path_or_name, info in packages.items():
        name = path_or_name.split("node_modules/")[-1] if "node_modules/" in path_or_name else path_or_name
        if not name:
            continue
        version = info.get("version", "")
        deps.append(Dependency(name.lower(), version, "npm", file_path))
    return deps


def _parse_go_mod(content: str, file_path: str) -> list[Dependency]:
    deps: list[Dependency] = []
    in_require = False
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("require ("):
            in_require = True
            continue
        if in_require and stripped == ")":
            in_require = False
            continue
        if in_require or stripped.startswith("require "):
            parts = stripped.replace("require ", "").strip().split()
            if len(parts) >= 2:
                module = parts[0]
                version = parts[1].lstrip("v")
                deps.append(Dependency(module, version, "go", file_path))
    return deps


def _parse_cargo_toml(content: str, file_path: str) -> list[Dependency]:
    deps: list[Dependency] = []
    in_deps = False
    for line in content.splitlines():
        stripped = line.strip()
        if stripped in ("[dependencies]", "[dev-dependencies]", "[build-dependencies]"):
            in_deps = True
            continue
        if stripped.startswith("[") and in_deps:
            in_deps = False
            continue
        if in_deps:
            match = re.match(r'(\w[\w-]*)\s*=\s*"([^"]*)"', stripped)
            if match:
                deps.append(Dependency(match.group(1).lower(), match.group(2), "crates", file_path))
            match = re.match(r'(\w[\w-]*)\s*=\s*\{.*version\s*=\s*"([^"]*)"', stripped)
            if match:
                deps.append(Dependency(match.group(1).lower(), match.group(2), "crates", file_path))
    return deps


PARSERS: dict[str, callable] = {
    "requirements.txt": _parse_requirements_txt,
    "Pipfile.lock": _parse_pipfile_lock,
    "pyproject.toml": _parse_pyproject_toml,
    "package.json": _parse_package_json,
    "package-lock.json": _parse_package_lock_json,
    "go.mod": _parse_go_mod,
    "Cargo.toml": _parse_cargo_toml,
}


def parse_dependencies(repo_path: Path) -> list[Dependency]:
    deps: list[Dependency] = []
    for filename, parser in PARSERS.items():
        for filepath in repo_path.rglob(filename):
            if "node_modules" in str(filepath) or ".git" in str(filepath):
                continue
            try:
                content = filepath.read_text(encoding="utf-8", errors="replace")
                relative = str(filepath.relative_to(repo_path))
                deps.extend(parser(content, relative))
            except Exception:
                continue
    return deps


def _cvss_to_severity(cvss: float) -> Severity:
    if cvss >= 9.0:
        return Severity.CRITICAL
    if cvss >= 7.0:
        return Severity.HIGH
    if cvss >= 4.0:
        return Severity.MEDIUM
    return Severity.LOW


async def _request_with_retry(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    **kwargs,
) -> httpx.Response | None:
    for attempt in range(MAX_RETRIES):
        try:
            resp = await client.request(method, url, **kwargs)
            if resp.status_code == 429:
                wait = RETRY_BACKOFF[min(attempt, len(RETRY_BACKOFF) - 1)]
                await asyncio.sleep(wait)
                continue
            if resp.status_code == 503:
                await asyncio.sleep(RETRY_BACKOFF[min(attempt, len(RETRY_BACKOFF) - 1)])
                continue
            return resp
        except (httpx.TimeoutException, httpx.ConnectError):
            if attempt < MAX_RETRIES - 1:
                await asyncio.sleep(RETRY_BACKOFF[min(attempt, len(RETRY_BACKOFF) - 1)])
            continue
        except Exception:
            return None
    return None


async def _query_osv_async(client: httpx.AsyncClient, dep: Dependency) -> list[dict]:
    ecosystem_map = {"pypi": "PyPI", "npm": "npm", "go": "Go", "crates": "crates.io"}
    ecosystem = ecosystem_map.get(dep.ecosystem, dep.ecosystem)

    payload: dict = {"package": {"name": dep.name, "ecosystem": ecosystem}}
    if dep.version:
        payload["version"] = dep.version

    resp = await _request_with_retry(client, "POST", OSV_API_URL, json=payload, timeout=15.0)
    if resp is None or resp.status_code != 200:
        return []
    return resp.json().get("vulns", [])


async def _query_nvd_async(client: httpx.AsyncClient, dep: Dependency, api_key: str = "") -> list[dict]:
    params: dict[str, str] = {"keywordSearch": f"{dep.name} {dep.version}"}
    headers: dict[str, str] = {}
    if api_key:
        headers["apiKey"] = api_key

    resp = await _request_with_retry(client, "GET", NVD_API_URL, params=params, headers=headers, timeout=30.0)
    if resp is None or resp.status_code != 200:
        return []
    return resp.json().get("vulnerabilities", [])


def _osv_to_findings(dep: Dependency, vulns: list[dict]) -> list[Finding]:
    findings: list[Finding] = []
    for vuln in vulns:
        vuln_id = vuln.get("id", "unknown")
        summary = vuln.get("summary", "")
        severity_list = vuln.get("severity", [])

        cvss = 0.0
        for s in severity_list:
            score_str = s.get("score", "")
            if score_str:
                try:
                    cvss = float(score_str)
                except ValueError:
                    pass

        if cvss == 0.0:
            db_specific = vuln.get("database_specific", {})
            cvss = db_specific.get("cvss_score", 5.0)

        findings.append(Finding(
            finding_type=FindingType.VULNERABLE_DEPENDENCY,
            severity=_cvss_to_severity(cvss),
            title=f"{vuln_id} in {dep.name}@{dep.version}",
            file_path=dep.file_path,
            match=f"{dep.name}=={dep.version}",
            metadata={
                "cve_id": vuln_id,
                "cvss": cvss,
                "summary": summary[:200],
                "ecosystem": dep.ecosystem,
            },
        ))
    return findings


def _nvd_to_findings(dep: Dependency, vulns: list[dict]) -> list[Finding]:
    findings: list[Finding] = []
    for item in vulns:
        cve = item.get("cve", {})
        cve_id = cve.get("id", "unknown")
        descriptions = cve.get("descriptions", [])
        summary = ""
        for d in descriptions:
            if d.get("lang") == "en":
                summary = d.get("value", "")
                break

        cvss = 0.0
        metrics = cve.get("metrics", {})
        for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
            metric_list = metrics.get(key, [])
            if metric_list:
                cvss = metric_list[0].get("cvssData", {}).get("baseScore", 0.0)
                break

        findings.append(Finding(
            finding_type=FindingType.VULNERABLE_DEPENDENCY,
            severity=_cvss_to_severity(cvss),
            title=f"{cve_id} in {dep.name}@{dep.version}",
            file_path=dep.file_path,
            match=f"{dep.name}=={dep.version}",
            metadata={
                "cve_id": cve_id,
                "cvss": cvss,
                "summary": summary[:200],
                "ecosystem": dep.ecosystem,
            },
        ))
    return findings


def _check_typosquatting(dep: Dependency) -> Finding | None:
    popular = POPULAR_PACKAGES.get(dep.ecosystem, [])
    for known in popular:
        if dep.name == known:
            return None
        d = lev_distance(dep.name, known)
        if 0 < d <= 2:
            return Finding(
                finding_type=FindingType.SUSPICIOUS_PATTERN,
                severity=Severity.HIGH,
                title=f"Possible typosquatting: {dep.name} (similar to {known})",
                file_path=dep.file_path,
                match=dep.name,
                module_confidence=0.7,
                metadata={
                    "similar_to": known,
                    "levenshtein_distance": d,
                    "ecosystem": dep.ecosystem,
                },
            )
    return None


def _meets_threshold(severity: Severity, threshold: str) -> bool:
    order = ["critical", "high", "medium", "low", "info"]
    return order.index(severity.value) <= order.index(threshold)


async def _check_dep(
    sem: asyncio.Semaphore,
    client: httpx.AsyncClient,
    dep: Dependency,
    config: ScaConfig,
    cache: VulnCache,
) -> list[Finding]:
    findings: list[Finding] = []

    if not dep.version:
        typo = _check_typosquatting(dep)
        if typo:
            findings.append(typo)
        return findings

    cache_key = f"{dep.ecosystem}:{dep.name}:{dep.version}"
    cached = cache.get(cache_key)

    if cached is not None:
        for item in cached:
            f = Finding.model_validate(item)
            if f.metadata.get("cve_id") not in config.ignore_cves:
                if _meets_threshold(f.severity, config.severity_threshold):
                    findings.append(f)
        return findings

    async with sem:
        osv_vulns = await _query_osv_async(client, dep)
        dep_findings = _osv_to_findings(dep, osv_vulns)

        if not dep_findings:
            nvd_vulns = await _query_nvd_async(client, dep, config.nvd_api_key)
            dep_findings = _nvd_to_findings(dep, nvd_vulns)

    cache.set(cache_key, [f.model_dump(mode="json") for f in dep_findings])

    for f in dep_findings:
        if f.metadata.get("cve_id") not in config.ignore_cves:
            if _meets_threshold(f.severity, config.severity_threshold):
                findings.append(f)

    typo = _check_typosquatting(dep)
    if typo:
        findings.append(typo)

    return findings


async def _scan_sca_async(repo_path: Path, config: ScaConfig) -> ModuleResult:
    deps = parse_dependencies(repo_path)
    cache = VulnCache()
    sem = asyncio.Semaphore(MAX_CONCURRENT)

    try:
        async with httpx.AsyncClient() as client:
            tasks = [_check_dep(sem, client, dep, config, cache) for dep in deps]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        findings: list[Finding] = []
        for r in results:
            if isinstance(r, list):
                findings.extend(r)
    finally:
        cache.close()

    return ModuleResult(module_name="sca", findings=findings)


def scan_sca(repo_path: Path, config: ScaConfig) -> ModuleResult:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            future = pool.submit(asyncio.run, _scan_sca_async(repo_path, config))
            return future.result()

    return asyncio.run(_scan_sca_async(repo_path, config))
