from __future__ import annotations

import re
from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import PurePosixPath

from gitspy.config import SecretsConfig
from gitspy.core.git_walker import DiffEntry
from gitspy.core.models import Finding, FindingType, ModuleResult, Severity
from gitspy.utils.entropy import shannon_entropy

PLACEHOLDER_PATTERNS = [
    re.compile(r"\b(xxx+|your[_-]?key[_-]?here|placeholder|changeme|insert[_-]?here|dummy[_-]?(?:key|token|secret))\b", re.I),
    re.compile(r"<[A-Z_]+>"),
]

TEST_PATH_PATTERNS = [
    "**/test_*", "**/*_test.*", "**/tests/**", "**/__tests__/**",
    "**/__mocks__/**", "**/fixtures/**", "**/testdata/**",
    "**/*_test.go", "**/*.test.ts", "**/*.test.js", "**/*.spec.*",
    "**/docs/**", "**/*.md", "**/examples/**", "**/example/**",
]

EXAMPLE_FILE_PATTERNS = [
    "*.example", "*.sample", "*.template", ".env.example", ".env.sample",
]


@dataclass
class SecretRule:
    id: str
    name: str
    pattern: re.Pattern[str]
    severity: Severity = Severity.HIGH


SECRET_RULES: list[SecretRule] = [
    SecretRule("aws-access-key", "AWS Access Key", re.compile(r"AKIA[0-9A-Z]{16}")),
    SecretRule("aws-secret-key", "AWS Secret Key", re.compile(
        r"(?i)aws_?secret_?access_?key\s*[=:]\s*['\"]?([A-Za-z0-9/+=]{40})['\"]?"
    )),
    SecretRule("github-token", "GitHub Token", re.compile(
        r"gh[pousr]_[A-Za-z0-9_]{36,}"
    )),
    SecretRule("github-pat-fine", "GitHub Fine-grained PAT", re.compile(
        r"github_pat_[A-Za-z0-9_]{22,}"
    )),
    SecretRule("gitlab-token", "GitLab Token", re.compile(
        r"glpat-[A-Za-z0-9\-_]{20,}"
    )),
    SecretRule("slack-token", "Slack Token", re.compile(
        r"xox[bporas]-[0-9]+-[0-9]+-[a-zA-Z0-9]+"
    )),
    SecretRule("slack-webhook", "Slack Webhook", re.compile(
        r"https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[a-zA-Z0-9]+"
    )),
    SecretRule("stripe-secret", "Stripe Secret Key", re.compile(
        r"sk_live_[0-9a-zA-Z]{24,}"
    )),
    SecretRule("stripe-restricted", "Stripe Restricted Key", re.compile(
        r"rk_live_[0-9a-zA-Z]{24,}"
    )),
    SecretRule("google-api-key", "Google API Key", re.compile(
        r"AIza[0-9A-Za-z\-_]{35}"
    )),
    SecretRule("gcp-service-account", "GCP Service Account", re.compile(
        r"\"type\"\s*:\s*\"service_account\""
    ), severity=Severity.CRITICAL),
    SecretRule("heroku-api-key", "Heroku API Key", re.compile(
        r"(?i)heroku[_-]?api[_-]?key\s*[=:]\s*['\"]?([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"]?"
    )),
    SecretRule("private-key", "Private Key", re.compile(
        r"-----BEGIN\s+(RSA|EC|DSA|OPENSSH|PGP)\s+PRIVATE\s+KEY-----"
    ), severity=Severity.CRITICAL),
    SecretRule("jwt-token", "JWT Token", re.compile(
        r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+"
    )),
    SecretRule("sendgrid-api", "SendGrid API Key", re.compile(
        r"SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}"
    )),
    SecretRule("twilio-api", "Twilio API Key", re.compile(
        r"SK[a-f0-9]{32}"
    )),
    SecretRule("mailgun-api", "Mailgun API Key", re.compile(
        r"key-[0-9a-zA-Z]{32}"
    )),
    SecretRule("npm-token", "NPM Token", re.compile(
        r"npm_[A-Za-z0-9]{36}"
    )),
    SecretRule("pypi-token", "PyPI Token", re.compile(
        r"pypi-[A-Za-z0-9_-]{50,}"
    )),
    SecretRule("nuget-api-key", "NuGet API Key", re.compile(
        r"oy2[a-z0-9]{43}"
    )),
    SecretRule("dockerhub-pat", "Docker Hub PAT", re.compile(
        r"dckr_pat_[A-Za-z0-9_-]{27,}"
    )),
    SecretRule("telegram-bot", "Telegram Bot Token", re.compile(
        r"[0-9]{8,10}:[A-Za-z0-9_-]{35}"
    )),
    SecretRule("discord-webhook", "Discord Webhook", re.compile(
        r"https://discord(?:app)?\.com/api/webhooks/[0-9]+/[A-Za-z0-9_-]+"
    )),
    SecretRule("discord-bot-token", "Discord Bot Token", re.compile(
        r"[MN][A-Za-z\d]{23,}\.[\w-]{6}\.[\w-]{27,}"
    )),
    SecretRule("azure-storage", "Azure Storage Key", re.compile(
        r"DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[A-Za-z0-9+/=]{88}"
    )),
    SecretRule("firebase-key", "Firebase API Key", re.compile(
        r"(?i)firebase[_-]?api[_-]?key\s*[=:]\s*['\"]?AIza[0-9A-Za-z\-_]{35}['\"]?"
    )),
    SecretRule("shopify-token", "Shopify Access Token", re.compile(
        r"shpat_[a-fA-F0-9]{32}"
    )),
    SecretRule("shopify-secret", "Shopify Shared Secret", re.compile(
        r"shpss_[a-fA-F0-9]{32}"
    )),
    SecretRule("databricks-token", "Databricks Token", re.compile(
        r"dapi[a-f0-9]{32}"
    )),
    SecretRule("linear-api-key", "Linear API Key", re.compile(
        r"lin_api_[A-Za-z0-9]{40}"
    )),
    SecretRule("vault-token", "HashiCorp Vault Token", re.compile(
        r"hvs\.[A-Za-z0-9_-]{24,}"
    )),
    SecretRule("age-secret-key", "age Secret Key", re.compile(
        r"AGE-SECRET-KEY-1[QPZRY9X8GF2TVDW0S3JN54KHCE6MUA7L]{58}"
    )),
    SecretRule("generic-secret", "Generic Secret Assignment", re.compile(
        r'(?i)(password|secret|token|apikey|api_key|access_key|auth_token|credentials|passwd|secret_key)\s*[=:]\s*["\'][^\s"\']{8,}["\']'
    )),
    SecretRule("generic-bearer", "Bearer Token", re.compile(
        r"(?i)bearer\s+[A-Za-z0-9_\-.~+/]+=*"
    )),
    SecretRule("base64-high-entropy", "High Entropy Base64 String", re.compile(
        r"(?i)(secret|key|token|password|auth)\s*[=:]\s*['\"]?([A-Za-z0-9+/]{40,}={0,2})['\"]?"
    )),
    SecretRule("connection-string", "Database Connection String", re.compile(
        r"(?i)(mongodb|postgres|mysql|redis|amqp)://[^\s\"']{10,}"
    ), severity=Severity.CRITICAL),
    SecretRule("supabase-key", "Supabase Key", re.compile(
        r"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9\.[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}"
    )),
    SecretRule("openai-api-key", "OpenAI API Key", re.compile(
        r"sk-[A-Za-z0-9]{20}T3BlbkFJ[A-Za-z0-9]{20}"
    )),
    SecretRule("anthropic-api-key", "Anthropic API Key", re.compile(
        r"sk-ant-api03-[A-Za-z0-9_-]{90,}"
    )),
    SecretRule("vercel-token", "Vercel Token", re.compile(
        r"[A-Za-z0-9]{24}OiJ[A-Za-z0-9_-]+"
    )),
    SecretRule("doppler-token", "Doppler Token", re.compile(
        r"dp\.st\.[a-z0-9_-]+\.[A-Za-z0-9]{40,}"
    )),
    SecretRule("planetscale-token", "PlanetScale Token", re.compile(
        r"pscale_tkn_[A-Za-z0-9_-]{30,}"
    )),
    SecretRule("planetscale-password", "PlanetScale Password", re.compile(
        r"pscale_pw_[A-Za-z0-9_-]{30,}"
    )),
]


def _is_placeholder(match_text: str) -> bool:
    return any(p.search(match_text) for p in PLACEHOLDER_PATTERNS)


def _is_test_file(file_path: str) -> bool:
    posix = PurePosixPath(file_path)
    return any(fnmatch(str(posix), pat) for pat in TEST_PATH_PATTERNS)


def _is_example_file(file_path: str) -> bool:
    posix = PurePosixPath(file_path)
    return any(fnmatch(posix.name, pat) for pat in EXAMPLE_FILE_PATTERNS)


def _should_skip_path(file_path: str, ignore_paths: list[str]) -> bool:
    posix = PurePosixPath(file_path)
    return any(fnmatch(str(posix), pat) for pat in ignore_paths)


def _mask_secret(value: str) -> str:
    if len(value) <= 8:
        return value[:2] + "..." + "[REDACTED]"
    return value[:6] + "..." + "[REDACTED]"


def _get_context(content: str, match_start: int, lines_around: int = 5) -> str:
    lines = content.splitlines(keepends=True)
    current_pos = 0
    match_line = 0

    for i, line in enumerate(lines):
        current_pos += len(line)
        if current_pos >= match_start:
            match_line = i
            break

    start = max(0, match_line - lines_around)
    end = min(len(lines), match_line + lines_around + 1)
    return "".join(lines[start:end])


def _get_line_number(content: str, match_start: int) -> int:
    return content[:match_start].count("\n") + 1


def scan_secrets(diffs: list[DiffEntry], config: SecretsConfig) -> ModuleResult:
    findings: list[Finding] = []

    for diff in diffs:
        if _should_skip_path(diff.file_path, config.ignore_paths):
            continue

        is_test = _is_test_file(diff.file_path)
        is_example = _is_example_file(diff.file_path)

        for rule in SECRET_RULES:
            for match in rule.pattern.finditer(diff.content):
                matched_text = match.group(0)

                if _is_placeholder(matched_text):
                    continue

                if rule.id.startswith("generic") or rule.id == "base64-high-entropy":
                    if len(matched_text) > 20:
                        entropy = shannon_entropy(matched_text)
                        if entropy < config.entropy_threshold:
                            continue

                severity = rule.severity
                confidence = 1.0

                if is_test:
                    severity = Severity.LOW
                    confidence = 0.3
                elif is_example:
                    severity = Severity.LOW
                    confidence = 0.2

                line_num = _get_line_number(diff.content, match.start())
                context = _get_context(diff.content, match.start())

                findings.append(Finding(
                    finding_type=FindingType.SECRET_LEAK,
                    severity=severity,
                    title=f"{rule.name} detected",
                    file_path=diff.file_path,
                    line=line_num,
                    match=_mask_secret(matched_text),
                    context=context,
                    commit_hash=diff.commit.hash,
                    commit_date=None,
                    commit_author=diff.commit.author,
                    module_confidence=confidence,
                    metadata={"rule_id": rule.id},
                ))

    return ModuleResult(module_name="secrets", findings=findings)
