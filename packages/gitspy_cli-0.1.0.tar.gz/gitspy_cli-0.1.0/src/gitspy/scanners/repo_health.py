from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from fnmatch import fnmatch
from pathlib import Path

from git import Repo

from gitspy.core.models import Finding, FindingType, ModuleResult, Severity


BINARY_EXTENSIONS = {
    ".exe", ".dll", ".so", ".dylib", ".bin", ".dat", ".zip", ".tar",
    ".gz", ".bz2", ".7z", ".rar", ".jar", ".war", ".class", ".pyc",
    ".o", ".a", ".lib", ".obj", ".pdb", ".wasm",
}

SENSITIVE_WORKFLOW_PERMISSIONS = [
    "contents: write",
    "packages: write",
    "id-token: write",
    "actions: write",
    "security-events: write",
]


def _days_since(dt: datetime) -> int:
    now = datetime.now(timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return (now - dt).days


def _analyze_maintainers(repo: Repo, max_commits: int = 500) -> list[Finding]:
    findings: list[Finding] = []
    commits = list(repo.iter_commits(max_count=max_commits))

    if not commits:
        return findings

    authors: Counter[str] = Counter()
    for c in commits:
        authors[str(c.author)] += 1

    if len(authors) == 1:
        findings.append(Finding(
            finding_type=FindingType.REPO_HEALTH,
            severity=Severity.INFO,
            title="Single maintainer (bus factor = 1)",
            metadata={"contributors": 1},
        ))

    last_commit = commits[0]
    days = _days_since(last_commit.committed_datetime)
    if days > 365:
        findings.append(Finding(
            finding_type=FindingType.REPO_HEALTH,
            severity=Severity.LOW,
            title=f"No updates in {days} days (possibly abandoned)",
            metadata={"days_since_last_commit": days},
        ))

    if len(commits) >= 30:
        recent = commits[:30]
        recent_authors: Counter[str] = Counter()
        for c in recent:
            recent_authors[str(c.author)] += 1

        total_recent = sum(recent_authors.values())
        for author, count in recent_authors.items():
            if count / total_recent > 0.9 and author not in [
                a for a, _ in authors.most_common(3)
            ]:
                findings.append(Finding(
                    finding_type=FindingType.REPO_HEALTH,
                    severity=Severity.MEDIUM,
                    title=f"Maintainer takeover signal: {author} authored {count}/{total_recent} recent commits",
                    metadata={"new_author": author, "recent_ratio": round(count / total_recent, 2)},
                ))

    return findings


def _analyze_commit_hygiene(repo: Repo, max_commits: int = 500) -> list[Finding]:
    findings: list[Finding] = []
    commits = list(repo.iter_commits(max_count=max_commits))

    for commit in commits:
        try:
            stats = commit.stats
            total_files = stats.total.get("files", 0)
        except Exception:
            total_files = 0

        if total_files > 50:
            findings.append(Finding(
                finding_type=FindingType.REPO_HEALTH,
                severity=Severity.INFO,
                title=f"Large commit ({total_files} files) - {commit.hexsha[:12]}",
                commit_hash=commit.hexsha[:12],
                commit_author=str(commit.author),
                metadata={"files_changed": total_files},
            ))

    return findings


def _detect_binaries(repo_path: Path) -> list[Finding]:
    findings: list[Finding] = []

    skip_dirs = {".git", "node_modules", ".venv", "venv", "env", "__pycache__", ".tox", ".mypy_cache"}

    for ext in BINARY_EXTENSIONS:
        for f in repo_path.rglob(f"*{ext}"):
            if skip_dirs & set(f.parts):
                continue
            relative = str(f.relative_to(repo_path))
            findings.append(Finding(
                finding_type=FindingType.REPO_HEALTH,
                severity=Severity.INFO,
                title=f"Binary file in repository: {relative}",
                file_path=relative,
                metadata={"extension": ext},
            ))

    return findings


def _check_force_push(repo: Repo) -> list[Finding]:
    findings: list[Finding] = []
    try:
        reflogs = list(repo.head.log())
        for entry in reflogs:
            msg = entry.message or ""
            if "force" in msg.lower() or "reset" in msg.lower():
                findings.append(Finding(
                    finding_type=FindingType.REPO_HEALTH,
                    severity=Severity.MEDIUM,
                    title=f"Force-push detected: {msg[:80]}",
                    metadata={"reflog_message": msg[:200]},
                ))
    except Exception:
        pass
    return findings


def _check_workflow_permissions(repo_path: Path) -> list[Finding]:
    findings: list[Finding] = []
    workflows_dir = repo_path / ".github" / "workflows"

    if not workflows_dir.exists():
        return findings

    for wf in workflows_dir.glob("*.yml"):
        try:
            content = wf.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue

        relative = str(wf.relative_to(repo_path))

        for perm in SENSITIVE_WORKFLOW_PERMISSIONS:
            if perm in content:
                findings.append(Finding(
                    finding_type=FindingType.REPO_HEALTH,
                    severity=Severity.INFO,
                    title=f"Sensitive workflow permission: {perm}",
                    file_path=relative,
                    metadata={"permission": perm},
                ))

        if "curl " in content and ("| bash" in content or "| sh" in content):
            findings.append(Finding(
                finding_type=FindingType.REPO_HEALTH,
                severity=Severity.MEDIUM,
                title="CI/CD script pipes curl to shell",
                file_path=relative,
            ))


    return findings


def _check_supply_chain_signals(repo_path: Path) -> list[Finding]:
    findings: list[Finding] = []
    workflows_dir = repo_path / ".github" / "workflows"

    if workflows_dir.exists():
        for wf in workflows_dir.glob("*.yml"):
            try:
                content = wf.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            relative = str(wf.relative_to(repo_path))
            import re
            for match in re.finditer(r"uses:\s+([^@\s]+)@([^\s]+)", content):
                ref = match.group(2)
                if not re.match(r"^[a-f0-9]{40}$", ref) and not ref.startswith("v"):
                    continue
                if not re.match(r"^[a-f0-9]{40}$", ref):
                    findings.append(Finding(
                        finding_type=FindingType.REPO_HEALTH,
                        severity=Severity.LOW,
                        title=f"GitHub Action pinned by tag, not SHA: {match.group(0)}",
                        file_path=relative,
                        metadata={"action": match.group(1), "ref": ref},
                    ))

    maturity_files = [
        (".npmignore", "npm project maturity signal"),
        (".gitattributes", "git attributes configured"),
        ("SECURITY.md", "security policy present"),
        ("CODEOWNERS", "code ownership defined"),
        (".github/CODEOWNERS", "code ownership defined"),
    ]

    present_signals = []
    for filename, _ in maturity_files:
        if (repo_path / filename).exists():
            present_signals.append(filename)

    if not (repo_path / "SECURITY.md").exists():
        findings.append(Finding(
            finding_type=FindingType.REPO_HEALTH,
            severity=Severity.INFO,
            title="No SECURITY.md found",
        ))

    return findings


def scan_repo_health(repo_path: Path) -> ModuleResult:
    findings: list[Finding] = []
    repo = Repo(str(repo_path))

    findings.extend(_analyze_maintainers(repo))
    findings.extend(_analyze_commit_hygiene(repo))
    findings.extend(_detect_binaries(repo_path))
    findings.extend(_check_force_push(repo))
    findings.extend(_check_workflow_permissions(repo_path))
    findings.extend(_check_supply_chain_signals(repo_path))

    return ModuleResult(module_name="repo_health", findings=findings)
