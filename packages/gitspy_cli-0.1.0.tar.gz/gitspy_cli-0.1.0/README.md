<p align="center">
  <img src="docs/report-preview.png" alt="GitSpy Report" width="800">
</p>

<h1 align="center">GitSpy</h1>
<p align="center">
  AI-powered supply-chain security scanner for GitHub repositories
</p>

<p align="center">
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="License"></a>
  <img src="https://img.shields.io/badge/python-3.11+-blue.svg" alt="Python">
  <img src="https://img.shields.io/badge/version-0.1.0-green.svg" alt="Version">
  <img src="https://img.shields.io/badge/AI-optional-yellow.svg" alt="AI Optional">
</p>

## What is GitSpy?

GitSpy scans **third-party** repositories before you fork, accept a PR, or add as a dependency. It checks git history for leaked secrets, vulnerable dependencies, suspicious code patterns, and repository trust signals.

```bash
gitspy scan https://github.com/someone/library
```

Runs offline without API keys. AI classification is optional via `--ai openai|anthropic|ollama`.

## Quick Start

```bash
pip install gitspy
gitspy scan https://github.com/someone/library
```

HTML report:

```bash
gitspy scan https://github.com/someone/library --format html --output report.html
```

## Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                    CLI (Typer)                                    │
│              gitspy scan <repo-url> [options]                     │
└──────────────────────────┬───────────────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│                    Orchestrator                                   │
│       Manages pipeline, collects results, computes score         │
└───┬──────────┬───────────┬──────────────┬────────────────────────┘
    │          │           │              │
    ▼          ▼           ▼              ▼
┌────────┐ ┌────────┐ ┌──────────┐ ┌──────────┐
│Secrets │ │  SCA   │ │  Code    │ │  Repo    │
│Scanner │ │Scanner │ │ Patterns │ │  Health  │
│        │ │        │ │          │ │          │
│regex + │ │deps +  │ │tree-     │ │git       │
│entropy │ │NVD/OSV │ │sitter    │ │history   │
└───┬────┘ └───┬────┘ └────┬─────┘ └────┬─────┘
    │          │           │             │
    └──────────┴───────────┴─────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│                 AI Classifier (optional)                          │
│     OpenAI / Anthropic / Ollama - classifies severity            │
└──────────────────────────┬───────────────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│                  Report Generator                                │
│            HTML / JSON / SARIF / Badge SVG                        │
└──────────────────────────────────────────────────────────────────┘
```

## 4 Scan Modules

| Module | What it finds | How |
|--------|--------------|-----|
| **Secrets** | API keys, tokens, passwords in entire git history | 40+ regex patterns + Shannon entropy + context analysis |
| **SCA** | Vulnerable dependencies in package.json, requirements.txt, go.mod, Cargo.toml | OSV.dev + NVD API + typosquatting detection |
| **Patterns** | Backdoors, obfuscation, reverse shells, crypto miners | tree-sitter AST + regex matchers |
| **Repo Health** | Abandoned repos, maintainer takeover, force-push, curl\|bash in CI | Git history analysis + workflow inspection |

## Scoring System

```
Trust Score = 100 - sum(penalties)

  A+  :  95-100        D  :  25-49
  A   :  85-94         F  :  0-24
  B   :  70-84
  C   :  50-69
```

| Finding | Severity | Penalty |
|---------|----------|---------|
| Active secret (valid) | Critical | -30 |
| CVE (CVSS >= 9.0) | Critical | -25 |
| Suspicious pattern | High | -20 |
| Secret in history | High | -15 |
| CVE (CVSS 7.0-8.9) | High | -15 |
| Force-push on main | Medium | -10 |
| No updates > 1 year | Low | -5 |

## CLI Usage

```bash
# Basic scan
gitspy scan https://github.com/someone/library

# AI classification
gitspy scan https://github.com/someone/library --ai openai
gitspy scan https://github.com/someone/library --ai ollama --model llama3

# Local repo
gitspy scan ./path/to/local/repo

# Specific modules only
gitspy scan <url> --modules secrets,sca

# History depth
gitspy scan <url> --depth 1000

# Output formats
gitspy scan <url> --format html --output report.html
gitspy scan <url> --format json --output report.json
gitspy scan <url> --format sarif --output results.sarif

# Badge generation
gitspy badge <url> --output badge.svg

# Config file
gitspy scan <url> --config .gitspy.yml

# Fail threshold (for CI)
gitspy scan <url> --fail-on high
```

## AI Classification (Optional)

AI is optional. The base scan runs fully offline (except git clone).

```bash
# OpenAI
export OPENAI_API_KEY=sk-...
gitspy scan <url> --ai openai

# Anthropic
export ANTHROPIC_API_KEY=sk-ant-...
gitspy scan <url> --ai anthropic

# Ollama (local, free)
ollama pull llama3
gitspy scan <url> --ai ollama
```

Secrets are **redacted** before sending to LLM. `AKIA...` becomes `[REDACTED]`.

## GitHub Action

```yaml
# .github/workflows/security.yml
name: Security Scan
on: [push, pull_request]

jobs:
  gitspy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - uses: Qeyron/gitspy-action@v1
        with:
          fail_on: high
```

## Configuration

Create `.gitspy.yml` in your project root:

```yaml
modules:
  secrets: true
  sca: true
  patterns: true
  repo_health: true

secrets:
  depth: 500
  entropy_threshold: 4.5
  ignore_paths:
    - "**/test_*.py"
    - "**/fixtures/**"

sca:
  nvd_api_key: ""
  ignore_cves: []
  severity_threshold: "medium"

patterns:
  languages:
    - python
    - javascript
    - typescript

ai:
  provider: "none"
  model: ""
  api_key_env: "OPENAI_API_KEY"

report:
  format: "console"
  output: ""
```

## Development

```bash
git clone https://github.com/Qeyron/gitspy.git
cd gitspy
python -m venv .venv
source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -e ".[dev]"
pytest tests/ -v
ruff check src/ tests/
```

## Documentation

- [Architecture](docs/architecture.md)
- [Custom Rules](docs/custom-rules.md)
- [AI Setup](docs/ai-setup.md)
- [GitHub Action](docs/github-action.md)

## License

MIT
