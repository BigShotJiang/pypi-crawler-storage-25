from __future__ import annotations

from gitspy.core.models import Finding, FindingType, Grade, Severity
from gitspy.core.scoring import calculate_trust_score, compute_penalty, score_to_grade


def _make_finding(finding_type: FindingType, severity: Severity) -> Finding:
    return Finding(finding_type=finding_type, severity=severity, title="test")


def test_perfect_score_no_findings():
    score, grade = calculate_trust_score([])
    assert score == 100
    assert grade == Grade.A_PLUS


def test_critical_secret_penalty():
    findings = [_make_finding(FindingType.SECRET_LEAK, Severity.CRITICAL)]
    score, _ = calculate_trust_score(findings)
    assert score == 70


def test_multiple_findings_stack():
    findings = [
        _make_finding(FindingType.SECRET_LEAK, Severity.CRITICAL),
        _make_finding(FindingType.SECRET_LEAK, Severity.HIGH),
        _make_finding(FindingType.VULNERABLE_DEPENDENCY, Severity.HIGH),
    ]
    score, _ = calculate_trust_score(findings)
    assert score == 40


def test_score_floors_at_zero():
    findings = [_make_finding(FindingType.SECRET_LEAK, Severity.CRITICAL)] * 10
    score, grade = calculate_trust_score(findings)
    assert score == 0
    assert grade == Grade.F


def test_grade_boundaries():
    assert score_to_grade(100) == Grade.A_PLUS
    assert score_to_grade(95) == Grade.A_PLUS
    assert score_to_grade(94) == Grade.A
    assert score_to_grade(85) == Grade.A
    assert score_to_grade(84) == Grade.B
    assert score_to_grade(70) == Grade.B
    assert score_to_grade(69) == Grade.C
    assert score_to_grade(50) == Grade.C
    assert score_to_grade(49) == Grade.D
    assert score_to_grade(25) == Grade.D
    assert score_to_grade(24) == Grade.F
    assert score_to_grade(0) == Grade.F


def test_penalty_for_known_types():
    p1 = compute_penalty(_make_finding(FindingType.SECRET_LEAK, Severity.CRITICAL))
    assert p1 == 30

    p2 = compute_penalty(_make_finding(FindingType.VULNERABLE_DEPENDENCY, Severity.HIGH))
    assert p2 == 15

    p3 = compute_penalty(_make_finding(FindingType.SUSPICIOUS_PATTERN, Severity.MEDIUM))
    assert p3 == 10


def test_penalty_fallback():
    p = compute_penalty(_make_finding(FindingType.REPO_HEALTH, Severity.CRITICAL))
    assert p == 2
