from __future__ import annotations

from pathlib import Path

from gitspy.scanners.sca import (
    Dependency,
    _check_typosquatting,
    _parse_go_mod,
    _parse_package_json,
    _parse_requirements_txt,
    parse_dependencies,
)


def test_parse_requirements_txt():
    content = "requests==2.28.0\nflask>=2.0\n# comment\nnumpy\n"
    deps = _parse_requirements_txt(content, "requirements.txt")
    assert len(deps) >= 2
    assert any(d.name == "requests" and d.version == "2.28.0" for d in deps)
    assert any(d.name == "flask" and d.version == "2.0" for d in deps)


def test_parse_package_json():
    content = '{"dependencies": {"lodash": "^4.17.21", "express": "~4.18.0"}}'
    deps = _parse_package_json(content, "package.json")
    assert len(deps) == 2
    assert any(d.name == "lodash" for d in deps)
    assert any(d.name == "express" for d in deps)


def test_parse_go_mod():
    content = (
        "module example.com/mymod\n\n"
        "go 1.21\n\n"
        "require (\n"
        "\tgithub.com/gin-gonic/gin v1.9.1\n"
        "\tgithub.com/lib/pq v1.10.9\n"
        ")\n"
    )
    deps = _parse_go_mod(content, "go.mod")
    assert len(deps) == 2
    assert any(d.name == "github.com/gin-gonic/gin" and d.version == "1.9.1" for d in deps)


def test_typosquatting_detects_similar():
    dep = Dependency(name="lod-ash", version="1.0.0", ecosystem="npm", file_path="package.json")
    finding = _check_typosquatting(dep)
    assert finding is not None
    assert "typosquatting" in finding.title.lower()


def test_typosquatting_ignores_exact():
    dep = Dependency(name="lodash", version="4.17.21", ecosystem="npm", file_path="package.json")
    finding = _check_typosquatting(dep)
    assert finding is None


def test_parse_dependencies_from_repo(repo_with_package_json: Path):
    deps = parse_dependencies(repo_with_package_json)
    assert len(deps) >= 1
    assert any(d.name == "lodash" for d in deps)


def test_parse_invalid_json():
    deps = _parse_package_json("not json at all", "package.json")
    assert deps == []
