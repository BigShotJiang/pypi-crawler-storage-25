from __future__ import annotations

from gitspy.ai.classifier import _parse_response, _severity_from_str
from gitspy.ai.redactor import redact
from gitspy.core.models import Severity


def test_parse_single_json():
    raw = '{"severity": "high", "explanation": "Active key found", "recommendation": "Rotate key"}'
    results = _parse_response(raw)
    assert len(results) == 1
    assert results[0].severity == "high"
    assert results[0].explanation == "Active key found"


def test_parse_json_array():
    raw = '[{"severity":"critical","explanation":"a","recommendation":"b"},{"severity":"low","explanation":"c","recommendation":"d"}]'
    results = _parse_response(raw)
    assert len(results) == 2
    assert results[0].severity == "critical"
    assert results[1].severity == "low"


def test_parse_markdown_wrapped():
    raw = '```json\n{"severity":"medium","explanation":"test","recommendation":"fix"}\n```'
    results = _parse_response(raw)
    assert len(results) == 1
    assert results[0].severity == "medium"


def test_parse_invalid_json():
    results = _parse_response("not json at all")
    assert results == []


def test_severity_from_str():
    assert _severity_from_str("critical") == Severity.CRITICAL
    assert _severity_from_str("HIGH") == Severity.HIGH
    assert _severity_from_str("unknown") is None


def test_redactor_masks_aws_key():
    text = 'Found key AKIAIOSFODNN7EXAMPLE1 in config'
    result = redact(text)
    assert "AKIAIOSFODNN7EXAMPLE1" not in result
    assert "[REDACTED]" in result


def test_redactor_masks_github_token():
    text = 'token = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij"'
    result = redact(text)
    assert "ghp_" not in result


def test_redactor_masks_connection_string():
    text = 'db = "postgres://admin:secret@db.host:5432/prod"'
    result = redact(text)
    assert "postgres://" not in result


def test_redactor_preserves_safe_text():
    text = "This is a normal log message with no secrets"
    assert redact(text) == text
