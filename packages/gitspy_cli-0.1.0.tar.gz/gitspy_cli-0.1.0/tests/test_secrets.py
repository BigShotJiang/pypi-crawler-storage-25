from __future__ import annotations

from pathlib import Path

from gitspy.config import SecretsConfig
from gitspy.core.git_walker import DiffEntry, CommitInfo, walk_history
from gitspy.scanners.secrets import scan_secrets, _is_placeholder, _is_test_file, _mask_secret


def _make_diff(content: str, file_path: str = "config.py") -> DiffEntry:
    return DiffEntry(
        file_path=file_path,
        content=content,
        commit=CommitInfo(hash="abc123def456", author="test", date="2024-01-01", message="test"),
    )


def test_detects_aws_access_key():
    diff = _make_diff('key = "AKIAIOSFODNN7EXAMPLE1"')
    result = scan_secrets([diff], SecretsConfig())
    assert len(result.findings) >= 1
    assert any("AWS" in f.title for f in result.findings)


def test_detects_private_key():
    diff = _make_diff("-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAK...")
    result = scan_secrets([diff], SecretsConfig())
    assert any("Private Key" in f.title for f in result.findings)


def test_detects_github_token():
    diff = _make_diff('token = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij"')
    result = scan_secrets([diff], SecretsConfig())
    assert any("GitHub" in f.title for f in result.findings)


def test_detects_connection_string():
    diff = _make_diff('db = "postgres://user:pass@host:5432/mydb"')
    result = scan_secrets([diff], SecretsConfig())
    assert any("Connection String" in f.title for f in result.findings)


def test_ignores_placeholder():
    assert _is_placeholder("your-key-here") is True
    assert _is_placeholder("placeholder") is True
    assert _is_placeholder("xxxxxxxxxxxx") is True
    assert _is_placeholder("AKIAIOSFODNN7EXAMPLE1") is False
    assert _is_placeholder("sk_live_abc123def456ghi789") is False


def test_ignores_test_files():
    assert _is_test_file("tests/test_config.py") is True
    assert _is_test_file("src/__tests__/api.test.js") is True
    assert _is_test_file("src/config.py") is False


def test_masks_secrets():
    masked = _mask_secret("AKIAIOSFODNN7EXAMPLE1")
    assert "REDACTED" in masked
    assert "AKIAIOSFODNN7EXAMPLE1" not in masked


def test_reduces_severity_for_test_files():
    diff = _make_diff('key = "AKIAIOSFODNN7EXAMPLE1"', file_path="tests/test_auth.py")
    result = scan_secrets([diff], SecretsConfig())
    for f in result.findings:
        assert f.severity.value == "low"


def test_respects_ignore_paths():
    config = SecretsConfig(ignore_paths=["vendor/**", "**/vendor/**"])
    diff = _make_diff('key = "AKIAIOSFODNN7EXAMPLE1"', file_path="vendor/lib/config.py")
    result = scan_secrets([diff], config)
    assert len(result.findings) == 0


def test_entropy_filter():
    diff = _make_diff('secret = "aaaaaaaaaaaaaaaaaaaaaaaaa"')
    config = SecretsConfig(entropy_threshold=4.5)
    result = scan_secrets([diff], config)
    secrets_with_low_entropy = [
        f for f in result.findings if f.metadata.get("rule_id") == "generic-secret"
    ]
    assert len(secrets_with_low_entropy) == 0


def test_walks_real_repo(repo_with_secret: Path):
    walker = walk_history(repo_with_secret, max_commits=10)
    result = scan_secrets(walker.diffs, SecretsConfig())
    assert any("AWS" in f.title for f in result.findings)
