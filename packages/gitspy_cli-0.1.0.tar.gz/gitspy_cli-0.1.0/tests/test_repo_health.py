from __future__ import annotations

from pathlib import Path

from git import Repo

from gitspy.scanners.repo_health import (
    _analyze_maintainers,
    _detect_binaries,
    _check_workflow_permissions,
    scan_repo_health,
)


def test_single_maintainer(tmp_repo: Path):
    repo = Repo(str(tmp_repo))
    findings = _analyze_maintainers(repo)
    assert any("bus factor" in f.title.lower() or "single" in f.title.lower() for f in findings)


def test_detects_binaries(tmp_repo: Path):
    (tmp_repo / "malware.exe").write_bytes(b"\x00" * 100)
    findings = _detect_binaries(tmp_repo)
    assert any(".exe" in f.file_path for f in findings)


def test_no_binaries_in_clean_repo(tmp_repo: Path):
    findings = _detect_binaries(tmp_repo)
    assert len(findings) == 0


def test_workflow_permissions(tmp_repo: Path):
    wf_dir = tmp_repo / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "ci.yml").write_text(
        "name: CI\npermissions:\n  contents: write\n  id-token: write\n"
    )
    findings = _check_workflow_permissions(tmp_repo)
    assert len(findings) >= 1
    assert any("permission" in f.title.lower() for f in findings)


def test_curl_pipe_bash(tmp_repo: Path):
    wf_dir = tmp_repo / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "deploy.yml").write_text(
        "name: Deploy\nsteps:\n  - run: curl http://install.sh | bash\n"
    )
    findings = _check_workflow_permissions(tmp_repo)
    assert any("curl" in f.title.lower() for f in findings)


def test_scan_repo_health_returns_module_result(tmp_repo: Path):
    result = scan_repo_health(tmp_repo)
    assert result.module_name == "repo_health"
    assert isinstance(result.findings, list)
