"""signedge — reserved. Install modelreins-worker instead.

See https://modelreins.com/docs/sdk/python
"""
raise ImportError(
    "signedge is a reserved name guard. "
    "Install the real package: pip install modelreins-worker"
)
