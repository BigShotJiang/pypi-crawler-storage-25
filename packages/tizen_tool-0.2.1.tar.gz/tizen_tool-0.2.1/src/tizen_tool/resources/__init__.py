"""Bundled runtime resources."""
