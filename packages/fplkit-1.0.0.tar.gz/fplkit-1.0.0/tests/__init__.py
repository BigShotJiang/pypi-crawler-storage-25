"""FPL Agents test suite."""
