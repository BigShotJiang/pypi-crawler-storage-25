from .vedaksha import *

__doc__ = vedaksha.__doc__
if hasattr(vedaksha, "__all__"):
    __all__ = vedaksha.__all__