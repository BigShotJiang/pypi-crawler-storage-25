"""merge setup — generate AI agent configuration files."""

from __future__ import annotations

import json
from pathlib import Path

import click

from merge_cli.config import load_ah_config, load_oauth_config
from merge_cli.output import warn

CLAUDE_MD_SECTION = """## Merge CLI

For any task involving third-party services, you MUST use the `merge` CLI.
Do NOT attempt to call APIs directly, use other tools, or guess endpoints.

### Commands

- `merge search-tools "<intent>"` — Search for tools. Returns compact input schemas.
- `merge execute-tool <tool_name> '<json_params>'` — Execute a tool.

### Workflow

**Step 1 — Find ALL tools you need in one batch.** In your first response, run parallel searches for every tool you'll need:
```
merge search-tools "create task" --connector asana    # main action
merge search-tools "list workspaces" --connector asana # lookup tool
merge search-tools "list users" --connector asana      # another lookup
```
Run ALL searches in parallel in one response.

**Step 2 — Execute lookups in parallel**, then execute the main tool.

Do NOT call `merge get-tool-schema`. Search returns schemas. Pass null for optional params you don't need.

### Rules

- Tool names: `<connector>__<action>`.
- ALWAYS run independent Bash calls in parallel.
- If you don't know the connector, search without --connector first.
"""

AGENTS_MD_SECTION = """## Merge CLI

For any task involving third-party services, use the `merge` CLI.

### Commands

- `merge search-tools "<intent>"` — Search for tools (returns compact schemas)
- `merge execute-tool <tool_name> '<json_params>'` — Execute a tool

### Workflow

1. Search for ALL tools you need in parallel: run multiple `merge search-tools` calls simultaneously.
2. Execute lookups in parallel, then execute the main tool.

Always search before executing. Never guess tool names. Pass null for optional params.
"""

CLAUDE_SETTINGS_PERMISSION = "Bash(merge *)"


@click.command()
@click.argument(
    "target",
    type=click.Choice(["claude-code", "cursor", "agents-md"], case_sensitive=False),
    default="claude-code",
)
@click.option(
    "--project-dir",
    default=".",
    type=click.Path(exists=True, file_okay=False),
    help="Project directory (default: current directory).",
)
def setup(target: str, project_dir: str):
    """Generate AI agent configuration for TARGET.

    Supported targets: claude-code, cursor, agents-md
    """
    project = Path(project_dir).resolve()

    if target == "claude-code":
        _setup_claude_code(project)
    elif target == "cursor":
        _setup_cursor(project)
    elif target == "agents-md":
        _setup_agents_md(project)


def _setup_claude_code(project: Path) -> None:
    """Generate CLAUDE.md section and .claude/settings.json permission."""
    # Update or create CLAUDE.md
    claude_md = project / "CLAUDE.md"
    marker = "## Merge CLI"

    if claude_md.exists():
        content = claude_md.read_text()
        if marker in content:
            click.echo("CLAUDE.md already contains Merge CLI instructions — skipping.")
        else:
            claude_md.write_text(content.rstrip() + "\n\n" + CLAUDE_MD_SECTION)
            click.echo(f"Appended Merge CLI instructions to {claude_md}")
    else:
        claude_md.write_text(CLAUDE_MD_SECTION)
        click.echo(f"Created {claude_md}")

    # Update or create .claude/settings.json
    settings_dir = project / ".claude"
    settings_dir.mkdir(exist_ok=True)
    settings_file = settings_dir / "settings.json"

    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text())
        except json.JSONDecodeError:
            settings = {}
    else:
        settings = {}

    permissions = settings.setdefault("permissions", {})
    allow_list = permissions.setdefault("allow", [])

    if CLAUDE_SETTINGS_PERMISSION not in allow_list:
        allow_list.append(CLAUDE_SETTINGS_PERMISSION)
        settings_file.write_text(json.dumps(settings, indent=2) + "\n")
        click.echo(f"Added '{CLAUDE_SETTINGS_PERMISSION}' to {settings_file}")
    else:
        click.echo(f"'{CLAUDE_SETTINGS_PERMISSION}' already in {settings_file} — skipping.")

    # Check if credentials are configured (OAuth preferred, API key fallback)
    oauth_cfg = load_oauth_config()
    if oauth_cfg is not None and not oauth_cfg.validate():
        pass  # OAuth is configured and valid
    else:
        ah_cfg = load_ah_config()
        if ah_cfg.validate():
            warn("Not authenticated. Run `merge login` to connect your account.")

    click.echo(
        "\nSetup complete! Claude Code will now use the merge CLI for third-party service tasks."
    )


def _setup_cursor(project: Path) -> None:
    """Generate .cursorrules with merge CLI instructions."""
    rules_file = project / ".cursorrules"
    marker = "## Merge CLI"

    content = AGENTS_MD_SECTION  # Same format works for Cursor

    if rules_file.exists():
        existing = rules_file.read_text()
        if marker in existing:
            click.echo(".cursorrules already contains Merge CLI instructions — skipping.")
            return
        rules_file.write_text(existing.rstrip() + "\n\n" + content)
        click.echo(f"Appended Merge CLI instructions to {rules_file}")
    else:
        rules_file.write_text(content)
        click.echo(f"Created {rules_file}")

    click.echo("\nSetup complete! Cursor will now use the merge CLI for third-party service tasks.")


def _setup_agents_md(project: Path) -> None:
    """Generate AGENTS.md with merge CLI instructions."""
    agents_md = project / "AGENTS.md"
    marker = "## Merge CLI"

    if agents_md.exists():
        content = agents_md.read_text()
        if marker in content:
            click.echo("AGENTS.md already contains Merge CLI instructions — skipping.")
            return
        agents_md.write_text(content.rstrip() + "\n\n" + AGENTS_MD_SECTION)
        click.echo(f"Appended Merge CLI instructions to {agents_md}")
    else:
        agents_md.write_text(AGENTS_MD_SECTION)
        click.echo(f"Created {agents_md}")

    click.echo(
        "\nSetup complete! AI agents that support AGENTS.md will now discover the merge CLI."
    )
