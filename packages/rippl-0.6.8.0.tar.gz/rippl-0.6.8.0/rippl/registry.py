from rippl.core.config import _OPERATORS, _SOLVERS

def list_operators():
    return list(_OPERATORS.keys())

def list_models():
    # Since there's no central model registry, just return a static list based on rippl.nn
    return ["MLP", "SIREN", "DeepONet", "HamiltonianNN", "LagrangianNN", "NeuralODE"]

def list_solvers():
    return list(_SOLVERS.keys())
