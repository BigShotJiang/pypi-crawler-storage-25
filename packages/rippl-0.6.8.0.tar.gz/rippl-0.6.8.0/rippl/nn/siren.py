import torch
import torch.nn as nn
import numpy as np
from typing import List, Dict, Any

class SineLayer(nn.Module):
    """
    Linear layer with Sine activation and specialized initialization.
    """
    def __init__(
        self, 
        in_features: int, 
        out_features: int, 
        bias: bool = True,
        is_first: bool = False,
        omega_0: float = 30.0
    ):
        super().__init__()
        self.omega_0 = omega_0
        self.is_first = is_first
        self.in_features = in_features
        self.linear = nn.Linear(in_features, out_features, bias=bias)
        self.init_weights()

    def init_weights(self) -> None:
        with torch.no_grad():
            if self.is_first:
                self.linear.weight.uniform_(-1 / self.in_features, 1 / self.in_features)
            else:
                self.linear.weight.uniform_(-np.sqrt(6 / self.in_features) / self.omega_0, 
                                          np.sqrt(6 / self.in_features) / self.omega_0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.sin(self.omega_0 * self.linear(x))

class Siren(nn.Module):
    """
    Sinusoidal Representation Network (SIREN).
    """
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_layers: List[int],
        omega_0: float = 30.0,
        **kwargs: Any
    ):
        """
        Initialize SIREN.

        Args:
            input_dim (int): Input dimension.
            output_dim (int): Output dimension.
            hidden_layers (List[int]): List of hidden dimensions.
            omega_0 (float): Frequency scaling factor.
        """
        super().__init__()
        
        layers = []
        in_dim = input_dim
        
        # Hidden layers
        for i, h_dim in enumerate(hidden_layers):
            is_first = (i == 0)
            layers.append(SineLayer(in_dim, h_dim, is_first=is_first, omega_0=omega_0))
            in_dim = h_dim
            
        # Last layer is usually linear for regression tasks in SIREN papers
        # The prompt implies a general SIREN model. Usually the final layer is linear
        # to match the output range, but sometimes sine is used if we want bounded output.
        # Standard implementation (Sitzmann et al.) uses Linear for the last layer.
        self.net = nn.Sequential(*layers)
        self.last_linear = nn.Linear(in_dim, output_dim)
        
        # Init last linear layer
        with torch.no_grad():
            self.last_linear.weight.uniform_(-np.sqrt(6 / in_dim) / omega_0, 
                                           np.sqrt(6 / in_dim) / omega_0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            x (torch.Tensor): (B, N, F_in)
            
        Returns:
            torch.Tensor: (B, N, F_out)
        """
        out = self.net(x)
        return self.last_linear(out)


class SIREN(nn.Module):
    """
    Sinusoidal Representation Network (SIREN) with flexible config.
    Used for smooth periodic functions and high-frequency PDEs.
    
    Reference: Sitzmann et al. 2020, "Implicit Neural Representations
    with Periodic Activation Functions", NeurIPS.
    """
    def __init__(
        self,
        in_features: int,
        out_features: int,
        hidden_features: int = 256,
        hidden_layers: int = 5,
        outermost_linear: bool = True,
        first_omega_0: float = 30.0,
        hidden_omega_0: float = 30.0,
        bias: bool = True
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.hidden_features = hidden_features
        self.hidden_layers = hidden_layers
        self.outermost_linear = outermost_linear
        self.first_omega_0 = first_omega_0
        self.hidden_omega_0 = hidden_omega_0

        self.net = nn.ModuleList()
        
        # First layer
        self.net.append(
            SineLayer(
                in_features,
                hidden_features,
                bias=bias,
                is_first=True,
                omega_0=first_omega_0
            )
        )
        
        # Hidden layers
        for _ in range(hidden_layers - 1):
            self.net.append(
                SineLayer(
                    hidden_features,
                    hidden_features,
                    bias=bias,
                    is_first=False,
                    omega_0=hidden_omega_0
                )
            )
            
        # Outermost layer
        if outermost_linear:
            final_linear = nn.Linear(hidden_features, out_features, bias=bias)
            with torch.no_grad():
                final_linear.weight.uniform_(
                    -np.sqrt(6 / hidden_features) / hidden_omega_0,
                    np.sqrt(6 / hidden_features) / hidden_omega_0
                )
            self.final = final_linear
        else:
            self.final = SineLayer(
                hidden_features,
                out_features,
                bias=bias,
                is_first=False,
                omega_0=hidden_omega_0
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = x
        for layer in self.net:
            out = layer(out)
        out = self.final(out)
        return out


def HighFreqSIREN(
    in_dim: int,
    out_dim: int,
    hidden: int = 256,
    layers: int = 5,
    omega_0: float = 30.0,
) -> torch.nn.Module:
    """
    SIREN optimized for high-frequency PDEs.
    
    Standard SIREN uses omega_0=30 which handles frequencies up to ~10.
    For problems with higher spatial frequencies (wave equation with k>>1,
    Helmholtz with large k, turbulence), increase omega_0.
    
    Rule of thumb: omega_0 ≈ max_expected_frequency * π
    
    Examples:
        u = sin(10πx): use omega_0=30 (default handles this)
        u = sin(30πx): use omega_0=100
        Turbulence (Re=1000): use omega_0=300
    
    Reference: Sitzmann et al. 2020, "Implicit Neural Representations
    with Periodic Activation Functions", NeurIPS.
    """
    return SIREN(
        in_features=in_dim,
        out_features=out_dim,
        hidden_features=hidden,
        hidden_layers=layers,
        outermost_linear=True,
        first_omega_0=omega_0,
        hidden_omega_0=30.0,
    )

