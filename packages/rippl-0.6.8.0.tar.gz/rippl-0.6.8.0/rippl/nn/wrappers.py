import torch
import torch.nn as nn
import torch.nn.functional as F

class PDFWrapper(nn.Module):
    """
    Wraps any rippl architecture to guarantee its output is a valid 
    Probability Density Function (non-negative, integrates to 1.0).
    Assumes uniform sampling over a unit volume for normalization.
    """
    def __init__(self, base_model: nn.Module, eps: float = 1e-8):
        super().__init__()
        self.net = base_model
        self.eps = eps

    def forward(self, *args, **kwargs):
        # 1. Get raw network output
        raw = self.net(*args, **kwargs)
        
        # 2. Enforce strict non-negativity without dead gradients
        p_pos = F.softplus(raw) + self.eps
        
        # 3. Enforce dynamic normalization over the sampled batch
        # For a standard unit domain, dividing by the spatial mean enforces integral = 1
        volume_integral = p_pos.mean()
        
        return p_pos / volume_integral
