import torch
import torch.nn as nn
from typing import List, Union, Dict, Any, Optional, Tuple

class MLP(nn.Module):
    """
    Multi-Layer Perceptron (MLP) supporting (B, N, F) input.
    Operates on the last dimension F.
    """
    def __init__(
        self,
        in_dim: Optional[int] = None,
        out_dim: Optional[int] = None,
        hidden: Optional[int] = None,
        layers: Optional[Union[int, List[int]]] = None,
        input_dim: Optional[int] = None,
        output_dim: Optional[int] = None,
        hidden_layers: Optional[List[int]] = None,
        activation: str = "tanh",
        **kwargs: Any
    ):
        """
        Initialize the MLP. Supporting both new and old API signatures.
        """
        super().__init__()
        
        # Resolve dimensions and architecture
        final_in_dim = in_dim or input_dim
        final_out_dim = out_dim or output_dim
        
        if hidden_layers is not None:
            final_hidden_layers = hidden_layers
        elif isinstance(layers, list):
            final_hidden_layers = layers
        elif hidden is not None and layers is not None:
            final_hidden_layers = [hidden] * int(layers)
        else:
             # Fallback/Default
             final_hidden_layers = [64, 64]

        self.net_layers = []
        curr_in = final_in_dim
        
        # Resolve activation function
        act_fn = self._get_activation(activation)

        for h_dim in final_hidden_layers:
            self.net_layers.append(nn.Linear(curr_in, h_dim))
            self.net_layers.append(act_fn)
            curr_in = h_dim
        
        self.net_layers.append(nn.Linear(curr_in, final_out_dim))
        self.net = nn.Sequential(*self.net_layers)

    def _get_activation(self, name: str) -> nn.Module:
        """
        Get activation module by name.
        """
        acc = name.lower()
        if acc == "tanh":
            return nn.Tanh()
        elif acc == "relu":
            return nn.ReLU()
        elif acc == "gelu":
            return nn.GELU()
        elif acc == "sigmoid":
            return nn.Sigmoid()
        elif acc == "identity":
            return nn.Identity()
        else:
            raise ValueError(f"Unsupported activation: {name}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Args:
            x (torch.Tensor): Input tensor of shape (B, N, F_in).

        Returns:
            torch.Tensor: Output tensor of shape (B, N, F_out).
        """
        # Linear layers in PyTorch support arbitrary batch dimensions inputs (*, H_in)
        return self.net(x)
