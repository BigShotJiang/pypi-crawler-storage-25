"""
Generative Physics: text → System → rp.run()
Uses local Ollama LLM — no API key required.
LLM outputs operator composition JSON only.
Operator registry is the hard constraint — no hallucination possible.
"""
import json
import warnings
from rippl.core.config import _OPERATORS
from rippl.core.system import System, Domain
from rippl.core.equation import Equation

def list_operators():
    return list(_OPERATORS.keys())

SYSTEM_PROMPT = """You are a physics configuration generator for rippl.
Output ONLY valid JSON. No explanation. No markdown. No code blocks.

Available operators: {operators}

Output format:
{{
  "equation": [{{"type": "operator_name", "param1": value}}, ...],
  "domain": {{"spatial_dims": N, "bounds": [[lo,hi], ...]}},
  "fields": ["u"],
  "description": "brief description"
}}

Rules:
- equation is a list of operator objects
- each operator must have "type" matching available operators exactly
- spatial_dims determines coordinate dimensions (not including time)
- bounds includes time as last entry
- fields lists the solution field names"""


def ask(prompt: str, model: str = "llama3",
        max_retries: int = 3) -> dict:
    """
    Generate a rippl System from natural language.
    
    Args:
        prompt: natural language PDE description
        model: Ollama model name
        max_retries: validation retry attempts
    
    Returns:
        dict with keys: system, config, description
    
    Raises:
        GenerationError if validation fails after max_retries
        ImportError if ollama not installed
    
    Example:
        result = rp.ask("heat equation on unit square, alpha=0.1")
        rp.run(result["system"], model=rnn.MLP(in_dim=2, out_dim=1))
    """
    try:
        import ollama
    except ImportError:
        raise ImportError(
            "Generative physics requires ollama. "
            "Install: pip install ollama && ollama pull llama3"
        )
    
    ops = list_operators()
    system_prompt = SYSTEM_PROMPT.format(operators=ops)
    
    last_error = None
    for attempt in range(max_retries):
        messages = [{"role": "user", "content": prompt}]
        if last_error and attempt > 0:
            messages.append({
                "role": "user",
                "content": f"Previous attempt failed: {last_error}. Fix and retry."
            })
        
        response = ollama.chat(
            model=model,
            messages=messages,
            # system=system_prompt # system is passed as a separate argument in some ollama versions or in messages
        )
        # Note: ollama.chat API might vary. Usually system prompt is a message with role 'system'.
        response = ollama.chat(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ]
        )
        raw = response["message"]["content"].strip()
        
        try:
            config = _parse_json(raw)
            system = _build_and_validate(config)
            return {"system": system, "config": config,
                    "description": config.get("description", prompt)}
        except Exception as e:
            last_error = str(e)
            warnings.warn(f"Attempt {attempt+1} failed: {e}")
    
    raise GenerationError(
        f"Failed to generate valid System after {max_retries} attempts. "
        f"Last error: {last_error}"
    )


def _parse_json(raw: str) -> dict:
    raw = raw.strip()
    if raw.startswith("```"):
        # Remove code blocks if present
        lines = raw.split("\n")
        if lines[0].startswith("```"): lines = lines[1:]
        if lines[-1].startswith("```"): lines = lines[:-1]
        raw = "\n".join(lines)
    return json.loads(raw)


def _build_and_validate(config: dict) -> System:
    # Need a builder that can handle the simplified JSON from the LLM
    # For now, let's assume we have a basic builder or implement a simple one
    from rippl.core.equation import Equation
    from rippl.core.system import Domain, System
    from rippl.core.config import get_operator_class
    
    dom_cfg = config["domain"]
    domain = Domain(
        spatial_dims=dom_cfg["spatial_dims"],
        bounds=tuple(tuple(b) for b in dom_cfg["bounds"]),
        resolution=tuple([20] * len(dom_cfg["bounds"])) # Default resolution
    )
    
    terms = []
    for op_cfg in config["equation"]:
        op_type = op_cfg.pop("type")
        op_cls = get_operator_class(op_type)
        terms.append((1.0, op_cls(**op_cfg)))
    
    equation = Equation(terms)
    system = System(equation=equation, domain=domain, fields=config.get("fields", ["u"]))
    system.validate()
    return system


class GenerationError(ValueError):
    pass
