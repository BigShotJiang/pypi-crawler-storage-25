import torch
import torch.nn as nn
from typing import List, Optional

class FBPINNSolver(nn.Module):
    """
    Finite Basis Physics-Informed Neural Networks (FBPINN).
    Decomposes domain into subdomains with overlapping windows.
    Reference: Moseley et al. 2021
    """
    def __init__(self, domain, equation, n_subdomains: int = 10, 
                 overlap: float = 0.2, hidden_dim: int = 32):
        super().__init__()
        self.dom = domain
        self.eq = equation
        self.n_sub = n_subdomains
        self.overlap = overlap
        
        # Subdomain centers and widths
        # Assuming 1D for simplicity in decomposition, but can be extended
        self.bounds = domain.bounds[0]
        L = self.bounds[1] - self.bounds[0]
        self.dx = L / n_subdomains
        self.half = self.dx * (1 + overlap) / 2
        
        self.centers = torch.linspace(self.bounds[0] + self.dx/2, 
                                      self.bounds[1] - self.dx/2, 
                                      n_subdomains)
        
        # Networks for each subdomain
        self.nets = nn.ModuleList([
            nn.Sequential(
                nn.Linear(domain.spatial_dims, hidden_dim),
                nn.Tanh(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.Tanh(),
                nn.Linear(hidden_dim, 1)
            ) for _ in range(n_subdomains)
        ])

    def window_fn(self, x: torch.Tensor, center: float) -> torch.Tensor:
        """
        w(x) = (1 - |x-center|/half)² * (1 + 2|x-center|/half) clamped to [0,1].
        """
        dist = (x[:, 0:1] - center).abs()
        z = dist / self.half
        w = (1 - z).pow(2) * (1 + 2 * z)
        return w.clamp(min=0, max=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        total = torch.zeros(x.shape[0], 1, device=x.device)
        for i, net in enumerate(self.nets):
            w = self.window_fn(x, self.centers[i].to(x.device))
            total = total + w * net(x)
        return total

    def train_step(self, x: torch.Tensor, optimizer: torch.optim.Optimizer):
        optimizer.zero_grad()
        u = self.forward(x)
        flds = {"u": u}
        
        # PDE Loss
        res = self.eq.compute_pointwise_residual(flds, x)
        loss_pde = res.mean()
        
        # Continuity Loss (FBPINN usually enforces consistency between overlaps)
        # but the window function handles partition of unity.
        
        loss = loss_pde
        loss.backward()
        optimizer.step()
        return loss.item()

    def predict(self, x: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            return self.forward(x)

    def _continuity_loss(self, x: torch.Tensor) -> torch.Tensor:
        # Penalizes variance in overlapping regions if needed
        # Partition of unity usually makes this redundant for simple FBPINN
        return torch.tensor(0., device=x.device)
