from rippl_backend.ntk_weighting import *
