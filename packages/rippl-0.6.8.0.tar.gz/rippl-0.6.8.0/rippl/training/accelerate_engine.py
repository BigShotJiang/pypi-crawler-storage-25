"""
HuggingFace Accelerate training engine for rippl.

Replaces custom DDP boilerplate with Accelerate's unified interface.
Works identically across:
  - Single GPU (no changes needed)
  - Multi-GPU single node (DDP)
  - Multi-node cluster (FSDP or DDP)
  - CPU (for testing)
  - Mixed precision (fp16, bf16, fp32)

BYOC compatibility:
  - AWS (SageMaker, EC2)
  - GCP (Vertex AI, GKE)
  - Azure (AML)
  - On-premise Slurm
  - Kubernetes

Usage from rp.run():
    result = rp.run(..., strategy='ddp')
    # Internally uses AccelerateEngine when strategy != 'auto'

For manual use:
    from rippl.training.accelerate_engine import AccelerateEngine
    engine = AccelerateEngine(precision='bf16')
    engine.train(model, loader, loss_fn, epochs=5000)
"""

import torch
from typing import Optional, Any


try:
    from accelerate import Accelerator
    from accelerate.utils import set_seed
    HAS_ACCELERATE = True
except ImportError:
    HAS_ACCELERATE = False
    Accelerator = None


class AccelerateEngine:
    """
    Thin Accelerate wrapper that preserves rippl's three-phase training recipe.

    The key design constraint: we do NOT let Accelerate own the training loop.
    We use Accelerate only for:
    1. Device placement (model, optimizer, dataloader)
    2. Mixed precision (automatic scaling)
    3. Gradient synchronization across GPUs/nodes
    4. Checkpoint saving/loading

    rippl's Phase A/B/C recipe runs exactly as in single-GPU mode.
    Accelerate is invisible infrastructure.

    Args:
        precision: 'fp32', 'fp16', 'bf16', 'fp8'
        gradient_accumulation_steps: accumulate before sync (saves memory)
        log_with: 'wandb', 'tensorboard', None
    """

    def __init__(
        self,
        precision: str = "fp32",
        gradient_accumulation_steps: int = 1,
        log_with: Optional[str] = None,
        project_name: str = "rippl",
    ):
        if not HAS_ACCELERATE:
            raise ImportError(
                "HuggingFace Accelerate required for distributed training.\n"
                "Install: pip install rippl[distributed]"
            )

        # Map rippl precision strings to Accelerate's mixed_precision
        precision_map = {
            "fp32":   "no",
            "fp16":   "fp16",
            "bf16":   "bf16",
            "bf16-mixed": "bf16",
        }

        self.accelerator = Accelerator(
            mixed_precision=precision_map.get(precision, "no"),
            gradient_accumulation_steps=gradient_accumulation_steps,
            log_with=log_with if log_with else None,
            project_dir="./accelerate_logs" if log_with else None,
        )

        self.precision = precision
        self.device = self.accelerator.device
        self.is_main_process = self.accelerator.is_main_process

    def prepare(self, model, optimizer, loader):
        """
        Prepare model, optimizer, and dataloader for distributed training.
        Call once before the training loop.

        Returns accelerated versions — use these, not the originals.
        """
        return self.accelerator.prepare(model, optimizer, loader)

    def backward(self, loss: torch.Tensor):
        """
        Backward pass via Accelerate (handles mixed precision scaling).
        Replaces loss.backward() in training loop.
        """
        self.accelerator.backward(loss)

    def clip_grad_norm(self, parameters, max_norm: float = 1.0):
        """
        Gradient clipping compatible with mixed precision.
        Replaces torch.nn.utils.clip_grad_norm_()
        """
        if self.accelerator.sync_gradients:
            self.accelerator.clip_grad_norm_(parameters, max_norm)

    def is_gradient_sync_step(self) -> bool:
        """True when gradients will be synchronized this step."""
        return self.accelerator.sync_gradients

    def log_metrics(self, metrics: dict, step: int):
        """Log metrics to configured logger (W&B, tensorboard, etc.)"""
        if self.is_main_process:
            self.accelerator.log(metrics, step=step)

    def save_checkpoint(self, path: str, **state):
        """Save checkpoint in Accelerate-compatible format."""
        self.accelerator.save_state(path)

    def load_checkpoint(self, path: str):
        """Load checkpoint."""
        self.accelerator.load_state(path)

    def unwrap_model(self, model) -> torch.nn.Module:
        """
        Unwrap DDP/FSDP wrapper to get the base model.
        Call before saving model weights or running inference.
        """
        return self.accelerator.unwrap_model(model)

    def wait_for_everyone(self):
        """Barrier synchronization across all processes."""
        self.accelerator.wait_for_everyone()

    def print(self, *args, **kwargs):
        """Print only on main process."""
        self.accelerator.print(*args, **kwargs)

    @property
    def num_processes(self) -> int:
        return self.accelerator.num_processes

    @property
    def process_index(self) -> int:
        return self.accelerator.process_index
