"""
RipplLogger: experiment logging for rippl training runs.
Supports local JSON and optional W&B integration.
No required dependencies beyond rippl core.
"""
import json, os, time
from datetime import datetime
from typing import Optional

class RipplLogger:
    """
    Logs training metrics, hyperparameters, and results.
    
    Args:
        experiment_name: name for this run
        log_dir: directory to save logs (default: ./rippl_logs)
        use_wandb: enable W&B logging (requires wandb installed)
        project: W&B project name
    
    Usage:
        logger = RipplLogger("heat_1d_experiment")
        logger.log_config({"lr": 5e-4, "epochs": 5000, "causal": True})
        logger.log_step(epoch=100, loss=0.001, pde_loss=0.0008)
        logger.log_result({"l2_error": 3.8e-4, "status": "PASS"})
        logger.finish()
    """
    def __init__(self, experiment_name: str,
                 log_dir: str = "./rippl_logs",
                 use_wandb: bool = False,
                 project: str = "rippl"):
        self.name = experiment_name
        self.log_dir = log_dir
        self.use_wandb = use_wandb
        self.start_time = time.time()
        self._run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._data = {
            "experiment": experiment_name,
            "run_id": self._run_id,
            "started": datetime.now().isoformat(),
            "config": {},
            "steps": [],
            "result": {}
        }
        os.makedirs(log_dir, exist_ok=True)
        self._path = os.path.join(
            log_dir, f"{experiment_name}_{self._run_id}.json"
        )
        if use_wandb:
            try:
                import wandb
                self._wb = wandb.init(
                    project=project, name=experiment_name
                )
            except ImportError:
                print("W&B not installed. Logging locally only.")
                self.use_wandb = False

    def log_config(self, config: dict):
        """Log hyperparameters and experiment config."""
        self._data["config"] = config
        if self.use_wandb:
            import wandb
            wandb.config.update(config)
        self._save()

    def log_step(self, epoch: int, **metrics):
        """Log per-epoch metrics."""
        entry = {"epoch": epoch, "time": time.time() - self.start_time,
                 **metrics}
        self._data["steps"].append(entry)
        if self.use_wandb:
            import wandb
            wandb.log({"epoch": epoch, **metrics})
        if epoch % 500 == 0:
            self._save()

    def log_result(self, result: dict):
        """Log final evaluation results."""
        self._data["result"] = result
        self._data["elapsed"] = time.time() - self.start_time
        self._data["finished"] = datetime.now().isoformat()
        if self.use_wandb:
            import wandb
            wandb.summary.update(result)
        self._save()

    def log_physics_report(self, report: dict):
        """Log PhysicsValidator output."""
        self._data["physics_report"] = report
        self._save()

    def finish(self):
        self._save()
        if self.use_wandb:
            import wandb
            wandb.finish()
        print(f"Log saved: {self._path}")

    def _save(self):
        with open(self._path, "w") as f:
            json.dump(self._data, f, indent=2, default=str)

    @classmethod
    def load(cls, path: str) -> dict:
        """Load a saved experiment log."""
        with open(path) as f:
            return json.load(f)

    def loss_curve(self) -> list:
        """Return list of loss values over training."""
        return [s.get("loss") for s in self._data["steps"]
                if "loss" in s]

    def summary(self) -> dict:
        steps = self._data["steps"]
        return {
            "experiment": self.name,
            "epochs_run": len(steps),
            "final_loss": steps[-1].get("loss") if steps else None,
            "elapsed": self._data.get("elapsed"),
            "result": self._data.get("result", {})
        }
