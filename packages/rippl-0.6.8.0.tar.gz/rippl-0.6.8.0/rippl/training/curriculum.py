"""
rippl.training.curriculum — Temporal curriculum learning for PINNs.
"""
import torch

class TemporalCurriculum:
    """
    Temporal curriculum learning for time-dependent PDEs.
    
    Filters collocation points to the current time window and expands
    the window as training progresses.
    
    Reference: Krishnapriyan et al. 2021, "Characterizing possible
    failure modes in physics-informed neural networks."
    """
    def __init__(self, t_start: float, t_end: float, n_stages: int = 5, patience: int = 500):
        self.t_start = t_start
        self.t_end = t_end
        self.n_stages = n_stages
        self.patience = patience
        
        # Divide into stages
        # e.g. for t0=0, t1=1, stg=5, stages are [0.2, 0.4, 0.6, 0.8, 1.0]
        self.stages = torch.linspace(t_start, t_end, n_stages + 1)[1:]
        self.current_stage_idx = 0
        self.epoch_counter = 0

    def t_max(self) -> float:
        """Returns the current maximum time threshold."""
        return float(self.stages[self.current_stage_idx].item())

    def filter_coords(self, coords: torch.Tensor) -> torch.Tensor:
        """
        Filters collocation points to retain only those within the current time window.
        Assumes time is the last dimension of the coordinate tensor.
        """
        t_limit = self.t_max()
        mask = coords[:, -1] <= t_limit
        return coords[mask]

    def step(self, loss_value: float = 0.0):
        """
        Increments step counter. Advances to the next stage if epoch count
        reaches patience and we are not at the final stage.
        """
        self.epoch_counter += 1
        if self.epoch_counter >= self.patience:
            if self.current_stage_idx < len(self.stages) - 1:
                self.current_stage_idx += 1
                self.epoch_counter = 0
                print(f"  [Curriculum] Advancing to stage {self.current_stage_idx + 1}/{self.n_stages} (t_max={self.t_max():.3f})")
