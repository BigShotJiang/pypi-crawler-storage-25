__version__ = "0.6.8.0"
# from rippl.api import train, simulate, identify
from rippl.core.system import System, Domain, Constraint
from rippl.core.config import register_operator, register_solver
from rippl.core.api import compile, run, upscale, RipplProRequired
from rippl.describe import describe
from rippl.generate import ask
from rippl.migrate import migrate
from rippl.training.logger import RipplLogger
from rippl.training.fbpinn import FBPINNSolver

__all__ = ["System", "Domain", "Constraint", "register_operator", "register_solver", "compile", "run", "upscale", "RipplProRequired", "describe", "ask", "migrate", "RipplLogger", "FBPINNSolver"]

