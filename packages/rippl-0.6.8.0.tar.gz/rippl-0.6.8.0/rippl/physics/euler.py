import torch
from typing import Optional, Dict, Any
from rippl.physics.operators import Operator, register_operator

@register_operator("euler_mass")
class EulerMassOperator(Operator):
    """
    ∂ρ/∂t + ∂(ρu)/∂x = 0
    Conservative form of mass conservation.
    """
    def __init__(self, field_rho="rho", field_rhou="rhou"):
        super().__init__(field=field_rho)
        self.field_rho = field_rho
        self.field_rhou = field_rhou

    def signature(self):
        return {
            "inputs": [self.field_rho, self.field_rhou],
            "output": "euler_mass",
            "order": 1,
            "type": "fluid",
            "requires_derived": [f"{self.field_rho}_t", f"{self.field_rhou}_x"]
        }

    def forward(self, fields, coords, derived=None):
        return derived[f"{self.field_rho}_t"] + derived[f"{self.field_rhou}_x"]

@register_operator("euler_momentum")
class EulerMomentumOperator(Operator):
    """
    ∂(ρu)/∂t + ∂(ρu² + p)/∂x = 0
    p = (γ-1)(E - 0.5 * ρu²)
    """
    def __init__(self, gamma=1.4, field_rho="rho", field_rhou="rhou", field_E="E"):
        super().__init__(field=field_rhou)
        self.gamma = gamma
        self.field_rho = field_rho
        self.field_rhou = field_rhou
        self.field_E = field_E

    def signature(self):
        return {
            "inputs": [self.field_rho, self.field_rhou, self.field_E],
            "output": "euler_momentum",
            "order": 1,
            "type": "fluid",
            "requires_derived": [
                f"{self.field_rhou}_t", f"{self.field_rhou}_x",
                f"{self.field_rho}_x", f"{self.field_E}_x"
            ]
        }

    def forward(self, fields, coords, derived=None):
        rho = fields[self.field_rho]
        rhou = fields[self.field_rhou]
        
        rho_x = derived[f"{self.field_rho}_x"]
        rhou_x = derived[f"{self.field_rhou}_x"]
        E_x = derived[f"{self.field_E}_x"]
        rhou_t = derived[f"{self.field_rhou}_t"]
        
        # ∂(ρu²)/∂x = ∂((ρu)²/ρ)/∂x = [ 2(ρu)(ρu)_x * ρ - (ρu)² ρ_x ] / ρ²
        conv_x = (2 * rhou * rhou_x * rho - rhou**2 * rho_x) / (rho**2 + 1e-10)
        
        # p = (γ-1)(E - 0.5 * (ρu)²/ρ)
        # ∂p/∂x = (γ-1) [ E_x - 0.5 * [ 2(ρu)(ρu)_x * ρ - (ρu)² ρ_x ] / ρ² ]
        p_x = (self.gamma - 1) * (E_x - 0.5 * conv_x)
        
        return rhou_t + conv_x + p_x

@register_operator("euler_energy")
class EulerEnergyOperator(Operator):
    """
    ∂E/∂t + ∂((E+p)u)/∂x = 0
    """
    def __init__(self, gamma=1.4, field_rho="rho", field_rhou="rhou", field_E="E"):
        super().__init__(field=field_E)
        self.gamma = gamma
        self.field_rho = field_rho
        self.field_rhou = field_rhou
        self.field_E = field_E

    def signature(self):
        return {
            "inputs": [self.field_rho, self.field_rhou, self.field_E],
            "output": "euler_energy",
            "order": 1,
            "type": "fluid",
            "requires_derived": [
                f"{self.field_E}_t", f"{self.field_E}_x",
                f"{self.field_rhou}_x", f"{self.field_rho}_x"
            ]
        }

    def forward(self, fields, coords, derived=None):
        rho = fields[self.field_rho]
        rhou = fields[self.field_rhou]
        E = fields[self.field_E]
        
        E_t = derived[f"{self.field_E}_t"]
        E_x = derived[f"{self.field_E}_x"]
        rhou_x = derived[f"{self.field_rhou}_x"]
        rho_x = derived[f"{self.field_rho}_x"]
        
        # u = (ρu)/ρ
        # p = (γ-1)(E - 0.5 * (ρu)²/ρ)
        # (E+p)u = (E + (γ-1)(E - 0.5 * (ρu)²/ρ)) * (ρu)/ρ
        #        = (γE - 0.5(γ-1)(ρu)²/ρ) * (ρu)/ρ
        #        = γE(ρu)/ρ - 0.5(γ-1)(ρu)³/ρ²
        
        # We need ∂((E+p)u)/∂x
        # ∂(E(ρu)/ρ)/∂x = [ (E_x(ρu) + E(ρu)_x)ρ - E(ρu)ρ_x ] / ρ²
        term1_x = ((E_x * rhou + E * rhou_x) * rho - E * rhou * rho_x) / (rho**2 + 1e-10)
        
        # ∂((ρu)³/ρ²)/∂x = [ 3(ρu)²(ρu)_x * ρ² - (ρu)³ * 2ρρ_x ] / ρ⁴
        term2_x = (3 * rhou**2 * rhou_x * rho**2 - rhou**3 * 2 * rho * rho_x) / (rho**4 + 1e-10)
        
        flux_x = self.gamma * term1_x - 0.5 * (self.gamma - 1) * term2_x
        
        return E_t + flux_x

class EulerSystem:
    """
    Compressible Euler System (1D).
    
    WARNING: inviscid — shocks expected. Use ArtificialViscosity or 
    rippl-pro WENO for stable near-shock solutions.
    """
    def __init__(self, gamma=1.4):
        self.gamma = gamma

    def build_equation_system(self):
        from rippl.core.equation_system import EquationSystem
        from rippl.core.equation import Equation
        mass = EulerMassOperator()
        momentum = EulerMomentumOperator(gamma=self.gamma)
        energy = EulerEnergyOperator(gamma=self.gamma)
        return EquationSystem([
            Equation([(1.0, mass)]),
            Equation([(1.0, momentum)]),
            Equation([(1.0, energy)])
        ], weights=[1, 1, 1])

    def fields(self):
        return ["rho", "rhou", "E"]

    def pressure(self, rho, rhou, E):
        """p = (γ-1)(E - ½ρu²)"""
        return (self.gamma - 1) * (E - 0.5 * rhou**2 / (rho + 1e-10))

    def mach_number(self, rho, rhou, E):
        """M = |u|/c where c = sqrt(γp/ρ)"""
        u = rhou / (rho + 1e-10)
        p = self.pressure(rho, rhou, E)
        c = torch.sqrt(self.gamma * p / (rho + 1e-10))
        return torch.abs(u) / (c + 1e-10)
