"""
rippl: Physics Package
Defines PDE specifications, residuals, and boundary conditions.
"""
from rippl.physics.pde import PDESpec
from rippl.physics.residuals import build_residual_fn
from rippl_backend.boundary import BoundaryCondition, DirichletBC, NeumannBC, PeriodicBC
from rippl.physics import maxwell, euler, quantum
from rippl.physics.maxwell import MaxwellSystem, HelmholtzMaxwellSystem
from rippl.physics.euler import EulerSystem
from rippl.physics.quantum import GPESystem

__all__ = [
    "PDESpec",
    "build_residual_fn",
    "BoundaryCondition",
    "DirichletBC",
    "NeumannBC",
    "PeriodicBC",
    "maxwell",
    "euler",
    "quantum",
    "MaxwellSystem",
    "HelmholtzMaxwellSystem",
    "EulerSystem",
    "GPESystem"
]
