import torch
from typing import Optional, Callable
from rippl.physics.operators import Operator, register_operator

@register_operator("gross_pitaevskii")
class GrossPitaevskiiOperator(Operator):
    """
    Gross-Pitaevskii Equation (GPE):
    iℏ∂ψ/∂t = [-ℏ²/2m ∇² + V + g|ψ|²]ψ
    Split into real and imaginary parts.
    """
    def __init__(self, hbar=1.0, mass=1.0, g=1.0, potential_fn=None, 
                 field_real="psi_real", field_imag="psi_imag", spatial_dims=1):
        super().__init__(field=field_real)
        self.hbar = hbar
        self.m = mass
        self.g = g
        self.V = potential_fn or (lambda x: torch.zeros(x.shape[0], 1, device=x.device))
        self.field_real = field_real
        self.field_imag = field_imag
        self.spatial_dims = spatial_dims

    def signature(self):
        dims = ["x", "y", "z"]
        req = [f"{self.field_real}_t", f"{self.field_imag}_t"]
        for d in dims[:self.spatial_dims]:
            req.append(f"{self.field_real}_{d}{d}")
            req.append(f"{self.field_imag}_{d}{d}")
        return {
            "inputs": [self.field_real, self.field_imag],
            "output": "gpe",
            "order": 2,
            "type": "quantum",
            "requires_derived": req
        }

    def forward(self, fields, coords, derived=None):
        psi_r = fields[self.field_real]
        psi_i = fields[self.field_imag]
        
        # -ℏ²/2m ∇²ψ
        coeff_k = -(self.hbar**2) / (2 * self.m)
        dims = ["x", "y", "z"]
        lap_r = sum(derived[f"{self.field_real}_{d}{d}"] for d in dims[:self.spatial_dims])
        lap_i = sum(derived[f"{self.field_imag}_{d}{d}"] for d in dims[:self.spatial_dims])
        
        kin_r = coeff_k * lap_r
        kin_i = coeff_k * lap_i
        
        # (V + g|ψ|²)ψ
        V = self.V(coords)
        psi_sq = psi_r**2 + psi_i**2
        pot_term = V + self.g * psi_sq
        
        rhs_r = kin_r + pot_term * psi_r
        rhs_i = kin_i + pot_term * psi_i
        
        # iℏ ∂ψ/∂t = iℏ (∂ψr/∂t + i ∂ψi/∂t) = iℏ ∂ψr/∂t - ℏ ∂ψi/∂t
        # LHS_real = -ℏ ∂ψi/∂t
        # LHS_imag = ℏ ∂ψr/∂t
        
        lhs_r = -self.hbar * derived[f"{self.field_imag}_t"]
        lhs_i = self.hbar * derived[f"{self.field_real}_t"]
        
        res_r = lhs_r - rhs_r
        res_i = lhs_i - rhs_i
        
        return torch.cat([res_r, res_i], dim=-1)

class GPESystem:
    def __init__(self, hbar=1.0, mass=1.0, g=1.0, potential_fn=None, spatial_dims=1):
        self.hbar = hbar
        self.mass = mass
        self.g = g
        self.V = potential_fn
        self.spatial_dims = spatial_dims

    def build_equation_system(self):
        from rippl.core.equation_system import EquationSystem
        from rippl.core.equation import Equation
        op = GrossPitaevskiiOperator(
            hbar=self.hbar, mass=self.mass, g=self.g, 
            potential_fn=self.V, spatial_dims=self.spatial_dims
        )
        return EquationSystem([Equation([(1.0, op)])])

    def fields(self):
        return ["psi_real", "psi_imag"]

    def norm_conservation_loss(self, model, x_grid, dx):
        """|(∫|ψ|²dx) - 1|"""
        psi = model(x_grid)
        # Assuming psi returns cat([psi_r, psi_i], dim=-1)
        psi_r = psi[..., 0:1]
        psi_i = psi[..., 1:2]
        prob_density = psi_r**2 + psi_i**2
        integral = (prob_density * dx).sum()
        return (integral - 1.0).abs()
