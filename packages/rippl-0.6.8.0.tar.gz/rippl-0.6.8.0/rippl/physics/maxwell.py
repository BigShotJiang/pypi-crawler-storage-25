import torch
from typing import Optional, Callable, Dict, Any, List
from rippl.physics.operators import Operator, register_operator

@register_operator("faraday")
class FaradayOperator(Operator):
    """∂B/∂t = -∇×E"""
    def __init__(self, dims=3):
        super().__init__(field="Bx")
        self.dims = dims

    def signature(self):
        return {
            "inputs": ["Ex", "Ey", "Ez", "Bx", "By", "Bz"],
            "output": "faraday",
            "order": 1,
            "type": "maxwell",
            "requires_derived": [
                "Bx_t", "By_t", "Bz_t",
                "Ez_y", "Ey_z", "Ex_z", "Ez_x", "Ey_x", "Ex_y"
            ]
        }

    def forward(self, fields, coords, derived=None):
        # Faraday's Law: ∂B/∂t + ∇×E = 0
        # curlE_x = ∂Ez/∂y - ∂Ey/∂z
        # curlE_y = ∂Ex/∂z - ∂Ez/∂x
        # curlE_z = ∂Ey/∂x - ∂Ex/∂y
        
        res_x = derived["Bx_t"] + (derived["Ez_y"] - derived["Ey_z"])
        res_y = derived["By_t"] + (derived["Ex_z"] - derived["Ez_x"])
        res_z = derived["Bz_t"] + (derived["Ey_x"] - derived["Ex_y"])
        
        return torch.cat([res_x, res_y, res_z], dim=-1)

@register_operator("ampere")
class AmpereOperator(Operator):
    """∂E/∂t = ∇×B - J"""
    def __init__(self, current_fn=None, dims=3):
        super().__init__(field="Ex")
        self.current_fn = current_fn or (lambda x: torch.zeros(x.shape[0], 3, device=x.device))
        self.dims = dims

    def signature(self):
        return {
            "inputs": ["Ex", "Ey", "Ez", "Bx", "By", "Bz"],
            "output": "ampere",
            "order": 1,
            "type": "maxwell",
            "requires_derived": [
                "Ex_t", "Ey_t", "Ez_t",
                "Bz_y", "By_z", "Bx_z", "Bz_x", "By_x", "Bx_y"
            ]
        }

    def forward(self, fields, coords, derived=None):
        # Ampere's Law: ∂E/∂t - ∇×B + J = 0
        # curlB_x = ∂Bz/∂y - ∂By/∂z
        # curlB_y = ∂Bx/∂z - ∂Bz/∂x
        # curlB_z = ∂By/∂x - ∂Bx/∂y
        
        J = self.current_fn(coords)
        
        res_x = derived["Ex_t"] - (derived["Bz_y"] - derived["By_z"]) + J[:, 0:1]
        res_y = derived["Ey_t"] - (derived["Bx_z"] - derived["Bz_x"]) + J[:, 1:2]
        res_z = derived["Ez_t"] - (derived["By_x"] - derived["Bx_y"]) + J[:, 2:3]
        
        return torch.cat([res_x, res_y, res_z], dim=-1)

@register_operator("gauss_electric")
class GaussElectricOperator(Operator):
    """∇·E = ρ"""
    def __init__(self, charge_fn=None):
        super().__init__(field="Ex")
        self.charge_fn = charge_fn or (lambda x: torch.zeros(x.shape[0], 1, device=x.device))

    def signature(self):
        return {
            "inputs": ["Ex", "Ey", "Ez"],
            "output": "gauss_e",
            "order": 1,
            "type": "maxwell",
            "requires_derived": ["Ex_x", "Ey_y", "Ez_z"]
        }

    def forward(self, fields, coords, derived=None):
        rho = self.charge_fn(coords)
        divE = derived["Ex_x"] + derived["Ey_y"] + derived["Ez_z"]
        return divE - rho

@register_operator("gauss_magnetic")
class GaussMagneticOperator(Operator):
    """∇·B = 0"""
    def __init__(self):
        super().__init__(field="Bx")

    def signature(self):
        return {
            "inputs": ["Bx", "By", "Bz"],
            "output": "gauss_b",
            "order": 1,
            "type": "maxwell",
            "requires_derived": ["Bx_x", "By_y", "Bz_z"]
        }

    def forward(self, fields, coords, derived=None):
        divB = derived["Bx_x"] + derived["By_y"] + derived["Bz_z"]
        return divB

class MaxwellSystem:
    def __init__(self, charge_fn=None, current_fn=None, dims=3):
        self.charge_fn = charge_fn
        self.current_fn = current_fn
        self.dims = dims

    def build_equation_system(self):
        from rippl.core.equation_system import EquationSystem
        from rippl.core.equation import Equation
        faraday = FaradayOperator(dims=self.dims)
        ampere = AmpereOperator(current_fn=self.current_fn, dims=self.dims)
        gauss_e = GaussElectricOperator(charge_fn=self.charge_fn)
        gauss_b = GaussMagneticOperator()
        
        return EquationSystem(
            [Equation([(1.0, faraday)]), 
             Equation([(1.0, ampere)]), 
             Equation([(1.0, gauss_e)]), 
             Equation([(1.0, gauss_b)])],
            weights=[1.0, 1.0, 0.1, 0.1]
        )

    def fields(self):
        return ["Ex", "Ey", "Ez", "Bx", "By", "Bz"]

class HelmholtzMaxwellSystem:
    def __init__(self, k=1.0):
        self.k = k

    def build_equation_system(self):
        from rippl.physics.operators import HelmholtzOperator
        from rippl.core.equation_system import EquationSystem
        from rippl.core.equation import Equation
        flds = self.fields()
        eqs = []
        for f in flds:
            eqs.append(Equation([(1.0, HelmholtzOperator(k=self.k, field=f))]))
        return EquationSystem(eqs)

    def fields(self):
        return ["Ex_real", "Ex_imag", "Ey_real", "Ey_imag", "Ez_real", "Ez_imag",
                "Bx_real", "Bx_imag", "By_real", "By_imag", "Bz_real", "Bz_imag"]
