"""
Parametric PDEs: solve families of PDEs simultaneously.
PDE parameter λ is an additional input to the network.
Single model learns u(x, t; λ) for all λ in parameter space.
"""
import torch
import torch.nn as nn

class ParametricWrapper(nn.Module):
    """
    Wraps any model to accept PDE parameters as additional inputs.
    Model input: cat([coords, params]) → solution u
    
    Args:
        base_model: model expecting (N, coord_dim) input
        param_dim: number of PDE parameters
        param_bounds: list of (min, max) per parameter for normalization
    """
    def __init__(self, base_model: nn.Module, param_dim: int,
                 param_bounds: list = None):
        super().__init__()
        self.model = base_model
        self.param_dim = param_dim
        self.bounds = param_bounds

    def forward(self, coords: torch.Tensor,
                params: torch.Tensor) -> torch.Tensor:
        """
        Args:
            coords: (N, D) spatial-temporal coordinates
            params: (N, param_dim) or (1, param_dim) PDE parameters
        """
        if params.shape[0] == 1:
            params = params.expand(coords.shape[0], -1)
        if self.bounds:
            params = self._normalize_params(params)
        return self.model(torch.cat([coords, params], dim=-1))

    def _normalize_params(self, params):
        for i, (lo, hi) in enumerate(self.bounds):
            params = params.clone()
            params[:, i] = (params[:, i] - lo) / (hi - lo + 1e-8)
        return params


class ParametricSampler:
    """
    Samples (coords, params) pairs for parametric PINN training.
    Each batch contains multiple parameter values.
    """
    def __init__(self, domain, param_bounds: list,
                 n_params_per_batch: int = 8):
        self.domain = domain
        self.param_bounds = param_bounds
        self.n_params = n_params_per_batch

    def sample(self, batch_size: int = 2048) -> tuple:
        """Returns (coords, params) tensors."""
        # Using generate_loader to get coords
        ldr = self.domain.generate_loader(batch_size=batch_size)
        coords = next(iter(ldr))[0]
        
        params = torch.zeros(coords.shape[0], len(self.param_bounds), device=coords.device)
        for i, (lo, hi) in enumerate(self.param_bounds):
            params[:, i] = torch.rand(coords.shape[0], device=coords.device) * (hi-lo) + lo
        
        return coords, params
