"""
Stochastic PDE support.
Additive and multiplicative noise terms.
Fokker-Planck equation for probability density evolution.
"""
import torch
import torch.nn.functional as F

class StochasticTerm:
    """
    Noise term for stochastic PDEs.
    du = L[u]dt + σ(u,x,t) dW
    where dW is Wiener process increment.
    
    Args:
        sigma_fn: callable(u, coords) → noise magnitude (N,1)
                  None defaults to additive white noise with sigma=noise_level
        noise_level: scalar noise magnitude when sigma_fn is None
        noise_type: "additive" or "multiplicative"
    """
    def __init__(self, sigma_fn=None, noise_level: float = 0.01,
                 noise_type: str = "additive"):
        self.sigma_fn = sigma_fn
        self.sigma = noise_level
        self.noise_type = noise_type

    def sample(self, u: torch.Tensor, 
               coords: torch.Tensor) -> torch.Tensor:
        """Sample noise realization. Returns (N,1) noise tensor."""
        noise = torch.randn_like(u)
        if self.sigma_fn is not None:
            sigma = self.sigma_fn(u, coords)
        else:
            sigma = self.sigma
        if self.noise_type == "multiplicative":
            return sigma * u * noise
        return sigma * noise


class StochasticEquation:
    """
    Wraps deterministic Equation with stochastic noise term.
    Loss computed via Monte Carlo expectation over noise samples.
    """
    def __init__(self, base_equation, stochastic_term: StochasticTerm,
                 n_samples: int = 10):
        self.eq = base_equation
        self.noise = stochastic_term
        self.n_samples = n_samples

    def compute_loss(self, fields: dict, 
                     coords: torch.Tensor) -> torch.Tensor:
        """Monte Carlo estimate of stochastic residual."""
        u = fields.get("u", list(fields.values())[0])
        total = torch.tensor(0., device=coords.device)
        for _ in range(self.n_samples):
            noise_sample = self.noise.sample(u, coords)
            noisy_fields = {k: v + noise_sample 
                           for k, v in fields.items()}
            if hasattr(self.eq, "compute_loss"):
                l = self.eq.compute_loss(noisy_fields, coords)
            else:
                # Fallback to compute_residual
                res = self.eq.compute_residual(next(iter(noisy_fields.values())), coords)
                l = res.pow(2).mean()
            total = total + l
        return total / self.n_samples


class FokkerPlanckEquation:
    """
    Fokker-Planck equation for probability density p(x,t):
    ∂p/∂t = -∂/∂x[μ(x)p] + (σ²/2)∂²p/∂x²
    
    where μ(x) is drift and σ² is diffusion coefficient.
    Constraint: ∫p dx = 1 (normalization), p ≥ 0 (positivity)
    
    Args:
        drift_fn: callable(coords) → (N,1) drift μ(x)
        diffusion: scalar σ² diffusion coefficient
    """
    def __init__(self, drift_fn: callable, diffusion: float = 1.0):
        self.mu = drift_fn
        self.D = diffusion / 2

    def compute_loss(self, fields: dict,
                     coords: torch.Tensor) -> torch.Tensor:
        p = fields["p"]
        c = coords.requires_grad_(True) if not coords.requires_grad else coords
        mu = self.mu(c)
        
        # ∂p/∂t
        p_t = torch.zeros_like(p)
        dp = torch.autograd.grad(p.sum(), c, create_graph=True, allow_unused=True)[0]
        if dp is not None:
            p_t = dp[:, -1:]
        
        # -∂/∂x[μp]
        mu_p = mu * p
        d_mup = torch.zeros_like(p)
        d_mup_all = torch.autograd.grad(
            mu_p.sum(), c, create_graph=True, allow_unused=True
        )[0]
        if d_mup_all is not None:
            d_mup = d_mup_all[:, 0:1]
        
        # (σ²/2)∂²p/∂x²
        p_xx = torch.zeros_like(p)
        if dp is not None:
            p_x = dp[:, 0:1]
            if p_x.requires_grad:
                p_xx_all = torch.autograd.grad(
                    p_x.sum(), c, create_graph=True, allow_unused=True
                )[0]
                if p_xx_all is not None:
                    p_xx = p_xx_all[:, 0:1]
        
        residual = p_t + d_mup - self.D * p_xx
        
        # Positivity penalty
        pos_penalty = F.relu(-p).pow(2).mean()
        
        return residual.pow(2).mean() + 10.0 * pos_penalty

    def normalization_loss(self, model, x_grid: torch.Tensor,
                           dx: float) -> torch.Tensor:
        """Enforces ∫p dx = 1 via quadrature."""
        p = model(x_grid)
        integral = (p * dx).sum()
        return (integral - 1.0).pow(2)

class PDFWrapper(torch.nn.Module):
    """
    Enforces physical plausibility for probability density outputs.
    p(x) > 0 via Softplus. ∫p dx ≈ 1 via batch normalization.
    Required for Fokker-Planck and any PDF-valued PDE.
    """
    def __init__(self, model: torch.nn.Module,
                 domain_volume: float = 1.0):
        super().__init__()
        self.model = model
        self.vol = domain_volume

    def forward(self, coords: torch.Tensor) -> torch.Tensor:
        raw = self.model(coords)
        positive = torch.nn.functional.softplus(raw)
        return positive / (positive.mean() * self.vol + 1e-10)

    def normalization_error(self, coords: torch.Tensor,
                             dx: float) -> torch.Tensor:
        return ((self.forward(coords) * dx).sum() - 1.0).abs()
