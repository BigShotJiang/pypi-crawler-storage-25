def save_rpx(model, path: str, metadata: dict = None):
    import zipfile, tempfile, json, os
    from safetensors.torch import save_file
    import rippl
    
    card = {
        "rippl_version": getattr(rippl, "__version__", "0.6.0"),
        "architecture": type(model).__name__,
        **(metadata or {})
    }
    with tempfile.TemporaryDirectory() as tmp:
        weights_path = os.path.join(tmp, "weights.safetensors")
        card_path = os.path.join(tmp, "model_card.json")
        save_file(model.state_dict(), weights_path)
        with open(card_path, "w") as f:
            json.dump(card, f, indent=2)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(weights_path, "weights.safetensors")
            zf.write(card_path, "model_card.json")
    return path

def load_rpx(path: str) -> tuple:
    import zipfile, tempfile, json, os
    from safetensors.torch import load_file
    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(tmp)
        weights = load_file(os.path.join(tmp, "weights.safetensors"))
        card_path = os.path.join(tmp, "model_card.json")
        card = {}
        if os.path.exists(card_path):
            with open(card_path) as f:
                card = json.load(f)
    return weights, card
