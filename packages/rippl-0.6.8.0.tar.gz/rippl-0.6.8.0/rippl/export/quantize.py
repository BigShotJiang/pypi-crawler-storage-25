import torch
import zipfile
import json
import tempfile
import os
from typing import Any, Dict, Optional

def quantize_model(model: torch.nn.Module, calib_data: torch.Tensor, backend: str = "fbgemm"):
    """
    Performs INT8 static quantization on the PINN model.
    Fuses Linear and Tanh layers for edge deployment.
    """
    torch.backends.quantized.engine = backend
    model.eval()
    
    # Identify Linear+Tanh pairs for fusion
    fusions = []
    children = list(model.named_children())
    for i in range(len(children) - 1):
        name1, m1 = children[i]
        name2, m2 = children[i+1]
        if isinstance(m1, torch.nn.Linear) and isinstance(m2, torch.nn.Tanh):
            fusions.append([name1, name2])
    
    if fusions:
        model = torch.quantization.fuse_modules(model, fusions)
    
    model.qconfig = torch.quantization.get_default_qconfig(backend)
    torch.quantization.prepare(model, inplace=True)
    
    # Calibration pass
    with torch.no_grad():
        model(calib_data)
        
    return torch.quantization.convert(model, inplace=True)

def export_rpx(model: torch.nn.Module, path: str, calib_data: torch.Tensor, meta: Optional[Dict[str, Any]] = None):
    """
    Exports a quantized model as a .rpx (compressed JIT) artifact.
    """
    q_model = quantize_model(model, calib_data)
    scripted = torch.jit.script(q_model)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Save model
        model_path = os.path.join(tmpdir, "model.pt")
        scripted.save(model_path)
        
        # Save metadata
        meta_path = os.path.join(tmpdir, "metadata.json")
        with open(meta_path, "w") as f:
            json.dump(meta or {"version": "v0.6.0", "type": "quantized_pinn"}, f)
            
        # Zip to .rpx
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(model_path, "model.pt")
            zipf.write(meta_path, "metadata.json")
            
    return path
