"""
Hamiltonian Neural Networks.
Learns H(q, p) — the system Hamiltonian.
Equations of motion derived automatically via autograd:
    dq/dt =  ∂H/∂p
    dp/dt = -∂H/∂q
Preserves symplectic structure by construction.
Reference: Greydanus et al. 2019
"""
import torch
import torch.nn as nn

class HamiltonianNN(nn.Module):
    """
    Learns scalar Hamiltonian H(q, p).
    Input: concatenated (q, p) of dim 2*n_dof
    Output: scalar H
    
    Args:
        n_dof: degrees of freedom (q and p each have n_dof dims)
        hidden: hidden layer width
        layers: number of hidden layers
    """
    def __init__(self, n_dof: int, hidden: int = 64, layers: int = 4):
        super().__init__()
        dims = [2*n_dof] + [hidden]*layers + [1]
        mods = []
        for i in range(len(dims)-1):
            mods.append(nn.Linear(dims[i], dims[i+1]))
            if i < len(dims)-2:
                mods.append(nn.Tanh())
        self.net = nn.Sequential(*mods)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, q: torch.Tensor, p: torch.Tensor) -> torch.Tensor:
        """Returns scalar Hamiltonian H(q,p). Shape: (batch, 1)"""
        x = torch.cat([q, p], dim=-1)
        return self.net(x)

    def equations_of_motion(self, q: torch.Tensor, 
                             p: torch.Tensor) -> tuple:
        """
        Returns (dq_dt, dp_dt) via Hamilton's equations.
        dq/dt =  ∂H/∂p
        dp/dt = -∂H/∂q
        Gradients computed via autograd — symplectic by construction.
        """
        q = q.requires_grad_(True)
        p = p.requires_grad_(True)
        H = self.forward(q, p).sum()
        dH_dq = torch.autograd.grad(H, q, create_graph=True)[0]
        dH_dp = torch.autograd.grad(H, p, create_graph=True)[0]
        return dH_dp, -dH_dq  # dq_dt, dp_dt

    def energy_error(self, q: torch.Tensor, p: torch.Tensor,
                     H0: float) -> torch.Tensor:
        """
        Measures energy conservation: |H(q,p) - H0| / |H0|
        H0: initial Hamiltonian value
        """
        H = self.forward(q, p)
        return (H - H0).abs() / (abs(H0) + 1e-8)

    def loss(self, q: torch.Tensor, p: torch.Tensor,
             dq_dt_true: torch.Tensor, 
             dp_dt_true: torch.Tensor) -> torch.Tensor:
        """
        Training loss: MSE between predicted and true equations of motion.
        """
        dq_pred, dp_pred = self.equations_of_motion(q, p)
        return (
            torch.nn.functional.mse_loss(dq_pred, dq_dt_true) +
            torch.nn.functional.mse_loss(dp_pred, dp_dt_true)
        )
