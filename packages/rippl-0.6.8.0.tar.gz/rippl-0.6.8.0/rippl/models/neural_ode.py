"""
Neural ODEs: continuous-depth models for dynamical systems.
dz/dt = f(z, t; θ) solved via adaptive ODE integrator.
Reference: Chen et al. 2018
Requires: pip install rippl[dynamics]
"""
import torch
import torch.nn as nn

try:
    from torchdiffeq import odeint
    HAS_TORCHDIFFEQ = True
except ImportError:
    HAS_TORCHDIFFEQ = False
    odeint = None

class ODEFunc(nn.Module):
    """Right-hand side of ODE: dz/dt = f(z, t)"""
    def __init__(self, dim: int, hidden: int = 64, layers: int = 3):
        super().__init__()
        dims = [dim+1] + [hidden]*layers + [dim]  # +1 for time
        mods = []
        for i in range(len(dims)-1):
            mods.append(nn.Linear(dims[i], dims[i+1]))
            if i < len(dims)-2: mods.append(nn.Tanh())
        self.net = nn.Sequential(*mods)
        self.nfe = 0  # number of function evaluations

    def forward(self, t: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        self.nfe += 1
        # t can be a scalar or a tensor. Ensure it's (batch, 1) to match z
        if t.dim() == 0:
            t_expand = t.expand(z.shape[0], 1)
        elif t.dim() == 1 and t.shape[0] == 1:
            t_expand = t.expand(z.shape[0], 1)
        elif t.dim() == 1 and t.shape[0] == z.shape[0]:
            t_expand = t.unsqueeze(-1)
        else:
            t_expand = t
        return self.net(torch.cat([z, t_expand], dim=-1))


class NeuralODE(nn.Module):
    """
    Neural ODE wrapper.
    Integrates ODE from t_span[0] to t_span[1] using dopri5.
    
    Args:
        ode_func: ODEFunc or any callable (t, z) → dz/dt
        method: ODE solver ("dopri5", "rk4", "euler")
        rtol, atol: solver tolerances
    """
    def __init__(self, ode_func: nn.Module, 
                 method: str = "dopri5",
                 rtol: float = 1e-3,
                 atol: float = 1e-4):
        super().__init__()
        self.func = ode_func
        self.method = method
        self.rtol = rtol
        self.atol = atol

    def forward(self, z0: torch.Tensor, 
                t_span: torch.Tensor) -> torch.Tensor:
        """
        Args:
            z0: initial state (batch, dim)
            t_span: time points tensor (T,)
        Returns:
            trajectory (T, batch, dim)
        """
        if not HAS_TORCHDIFFEQ:
            raise ImportError(
                "Neural ODEs require torchdiffeq. "
                "Install: pip install rippl[dynamics]"
            )
        return odeint(self.func, z0, t_span,
                      method=self.method,
                      rtol=self.rtol, atol=self.atol)

    def loss(self, z0: torch.Tensor, t_span: torch.Tensor,
             z_true: torch.Tensor) -> torch.Tensor:
        """MSE loss against observed trajectory."""
        z_pred = self.forward(z0, t_span)
        return torch.nn.functional.mse_loss(z_pred, z_true)

    def forward_stiff(self, z0: torch.Tensor,
                   t_span: torch.Tensor,
                   method: str = "implicit_adams",
                   rtol: float = 1e-6,
                   atol: float = 1e-8) -> torch.Tensor:
        """
        Stiff ODE solver. Use for: chemical kinetics, stiff mechanics.
        WARNING: chaotic systems (Lorenz) fail at long times regardless
        of solver — fundamental sensitivity to initial conditions.
        """
        if not HAS_TORCHDIFFEQ:
            raise ImportError(
                "Neural ODEs require torchdiffeq. "
                "Install: pip install rippl[dynamics]"
            )
        return odeint(self.func, z0, t_span,
                      method=method, rtol=rtol, atol=atol)
