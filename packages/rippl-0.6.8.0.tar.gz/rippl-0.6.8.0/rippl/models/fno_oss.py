import torch
import torch.nn as nn
import torch.fft
from typing import Any

class SpectralConv1d(nn.Module):
    """
    1D Fourier Spectral Layer.
    """
    def __init__(self, in_channels: int, out_channels: int, modes: int):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes = modes
        
        scale = (1 / (in_channels * out_channels))
        self.weights = nn.Parameter(
            scale * torch.rand(in_channels, out_channels, modes, dtype=torch.cfloat)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (B, C, N)
        batchsize = x.shape[0]
        
        # Compute Fourier coeff
        x_ft = torch.fft.rfft(x)

        # Multiply relevant modes
        out_ft = torch.zeros(batchsize, self.out_channels, x.size(-1)//2 + 1, device=x.device, dtype=torch.cfloat)
        
        # Modes processing
        out_ft[:, :, :self.modes] = torch.einsum(
            "bix,iox->box", 
            x_ft[:, :, :self.modes], 
            self.weights
        )

        # Return to physical space
        x = torch.fft.irfft(out_ft, n=x.size(-1))
        return x

class FNO1d(nn.Module):
    """
    1D Fourier Neural Operator.
    Input: (B, N, F_in) -> Transpose to (B, F_in, N) -> FNO Layers -> (B, F_out, N) -> Transpose back
    """
    def __init__(
        self,
        *args,
        n_modes: int = None,
        width: int = None,
        input_dim: int = 1,
        output_dim: int = 1,
        depth: int = 4,
        **kwargs: Any
    ):
        super().__init__()
        
        # 1. Handle old positional arguments: (input_dim, output_dim, modes, width, depth=4)
        if len(args) >= 4:
            input_dim = args[0]
            output_dim = args[1]
            n_modes = args[2]
            width = args[3]
            if len(args) >= 5:
                depth = args[4]
        # Handle new positional arguments: (n_modes, width)
        elif len(args) == 2:
            n_modes = args[0]
            width = args[1]
        elif len(args) == 1:
            n_modes = args[0]
            
        # 2. Handle keyword arguments
        if "modes" in kwargs:
            n_modes = kwargs.pop("modes")
        if "input_dim" in kwargs:
            input_dim = kwargs.pop("input_dim")
        if "output_dim" in kwargs:
            output_dim = kwargs.pop("output_dim")
        if "depth" in kwargs:
            depth = kwargs.pop("depth")
        if "width" in kwargs:
            width = kwargs.pop("width")
            
        if n_modes is None or width is None:
            raise ValueError(f"FNO1d requires modes/n_modes and width to be specified. Got n_modes={n_modes}, width={width}")
            
        self.n_modes = n_modes
        self.width = width
        self.fc0 = nn.Linear(input_dim, width)
        
        self.conv_layers = nn.ModuleList()
        self.w_layers = nn.ModuleList()
        
        for _ in range(depth):
            self.conv_layers.append(SpectralConv1d(width, width, n_modes))
            self.w_layers.append(nn.Conv1d(width, width, 1))

        self.fc1 = nn.Linear(width, 128)
        self.fc2 = nn.Linear(128, output_dim)
        self.act = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x (torch.Tensor): (B, N, F_in)
        """
        # Lift to width
        x = self.fc0(x) # (B, N, width)
        x = x.permute(0, 2, 1) # (B, width, N)

        for conv, w in zip(self.conv_layers, self.w_layers):
            x1 = conv(x)
            x2 = w(x)
            x = x1 + x2
            x = self.act(x)

        x = x.permute(0, 2, 1) # (B, N, width)
        x = self.fc1(x)
        x = self.act(x)
        x = self.fc2(x) # (B, N, output_dim)
        
        return x
