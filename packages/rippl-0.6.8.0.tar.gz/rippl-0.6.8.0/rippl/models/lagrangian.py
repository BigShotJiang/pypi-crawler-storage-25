import torch
import torch.nn as nn

class LagrangianNN(nn.Module):
    """
    Learns the Lagrangian L(q, q_dot). 
    Computes acceleration via M(q)*q_ddot + C(q, q_dot) = dL/dq
    """
    def __init__(self, n_dof: int, hidden: int = 32, layers: int = 2):
        super().__init__()
        self.n_dof = n_dof
        modules = [nn.Linear(n_dof * 2, hidden), nn.Tanh()]
        for _ in range(layers - 1):
            modules.extend([nn.Linear(hidden, hidden), nn.Tanh()])
        modules.append(nn.Linear(hidden, 1))
        self.net = nn.Sequential(*modules)

    def forward(self, q, q_dot):
        x = torch.cat([q, q_dot], dim=-1)
        return self.net(x)

    def acceleration(self, q, q_dot):
        q = q.requires_grad_(True)
        q_dot = q_dot.requires_grad_(True)
        L = self.forward(q, q_dot).sum()
        
        # dL/dqdot — shape (batch, n_dof)
        dL_dqdot = torch.autograd.grad(L, q_dot, create_graph=True)[0]
        
        # Mass matrix M_ij = d²L/dqdot_i dqdot_j
        n = q.shape[0]
        M = torch.zeros(n, self.n_dof, self.n_dof, device=q.device)
        for i in range(self.n_dof):
            row = torch.autograd.grad(
                dL_dqdot[:, i].sum(), q_dot, create_graph=True, retain_graph=True
            )[0]
            M[:, i, :] = row

        # dL/dq — generalized forces
        dL_dq = torch.autograd.grad(L, q, create_graph=True)[0]

        # Coriolis/centrifugal: d²L/dqdot dq * q_dot
        C = torch.zeros(n, self.n_dof, device=q.device)
        for i in range(self.n_dof):
            row = torch.autograd.grad(
                dL_dqdot[:, i].sum(), q, create_graph=True, retain_graph=True
            )[0]
            C[:, i] = (row * q_dot).sum(dim=-1)

        # M * q_ddot = dL_dq - C
        rhs = (dL_dq - C).unsqueeze(-1)
        q_ddot = torch.linalg.solve(M, rhs).squeeze(-1)
        return q_ddot

    def loss(self, q, q_dot, q_ddot_true):
        q_ddot_pred = self.acceleration(q, q_dot)
        return torch.nn.functional.mse_loss(q_ddot_pred, q_ddot_true)
