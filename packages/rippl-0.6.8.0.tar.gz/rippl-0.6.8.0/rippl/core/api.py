import torch, os, warnings
import torch.nn.functional as F
from typing import Any, Dict, Union

class RipplProRequired(PermissionError): pass

class Solver:
    def __init__(self, dom, eq, m=None):
        self.dom = dom
        self.eq = eq
        self.m = m
    
    def solve(self, mode="pinn", parametric=False, param_bounds=None, **kw):
        return run(self.dom, self.eq, self.m, mode=mode, parametric=parametric, param_bounds=param_bounds, **kw)

    def _compute_loss(self, m, eq, x, flds, parametric=False, p=None, dev="cpu", **kw):
        l_pde = eq.compute_loss(flds, x) if hasattr(eq, 'compute_loss') else eq.compute_residual(flds["u"], x).pow(2).mean()
        
        if hasattr(m, "symplectic_loss"):
            l_pde = l_pde + m.symplectic_loss(x)
            
        if getattr(eq, "is_stochastic", False):
            l_pde = l_pde + self._compute_fokker_planck_drift(m, x, parametric, p, dev)
            
        return l_pde

    def _compute_fokker_planck_drift(self, m, x, parametric, p, dev):
        # Implementation of Fokker-Planck drift residual accumulation
        x = x.requires_grad_(True)
        u = m(x, p) if parametric else m(x)
        grad_u = torch.autograd.grad(u.sum(), x, create_graph=True)[0]
        # Assuming last dim is time, others spatial. Drift μ(x) approx by grad_u
        drift_loss = grad_u.pow(2).mean() 
        return drift_loss

def authenticate(api_key: str):
    global _API_KEY
    _API_KEY = api_key
    print(f"Authenticated. Independent features active.")

def compile(m, backend="inductor", mode="max-autotune"):
    import os, shutil
    if os.name == 'nt' and not shutil.which('cl'):
        return m
    try: return torch.compile(m, backend=backend, mode=mode)
    except: return m


def _apply_rar_refinement(
    domain,
    equation,
    model,
    device,
    current_dataset,
    rar_k: int,
    rar_candidate_n: int,
    epoch: int,
):
    """
    Residual-Based Adaptive Refinement (RAR).
    
    Samples a large candidate pool of collocation points,
    evaluates the PDE residual at each candidate,
    and adds the top-k highest-residual points to the training set.
    """
    from torch.utils.data import TensorDataset
    import torch

    model.eval()
    
    # Sample candidate pool using Sobol for better coverage
    sobol_engine = torch.quasirandom.SobolEngine(
        dimension=len(domain.bounds),
        scramble=True
    )
    candidates = sobol_engine.draw(rar_candidate_n).to(device)
    
    # Scale to domain bounds
    for i, (lo, hi) in enumerate(domain.bounds):
        candidates[:, i] = candidates[:, i] * (hi - lo) + lo
        
    # Ensure precision matches model parameters
    candidates = candidates.to(next(model.parameters()).dtype)
    
    # Evaluate pointwise residuals — coordinates require grad to compute derivatives
    with torch.enable_grad():
        candidates_grad = candidates.clone().requires_grad_(True)
        u_candidates = model(candidates_grad)
        fields = (
            {"u": u_candidates}
            if not isinstance(u_candidates, dict)
            else u_candidates
        )
        try:
            pointwise_residuals = equation.compute_pointwise_residual(
                fields, candidates_grad
            )
        except AttributeError:
            # Fallback if compute_pointwise_residual not available
            pde_loss = equation.compute_loss(fields, candidates_grad)
            pointwise_residuals = torch.full(
                (candidates.shape[0], 1), pde_loss.item(), device=device
            )
    
    # Select top-k highest residual points
    residual_values = pointwise_residuals.detach().squeeze()
    if residual_values.dim() == 0:
        # Scalar residual — can't select, skip
        model.train()
        return current_dataset
    
    k_actual = min(rar_k, residual_values.shape[0])
    _, top_indices = residual_values.topk(k_actual)
    new_points = candidates[top_indices].detach().cpu()
    
    # Augment training dataset
    existing_points = current_dataset.tensors[0]
    augmented_points = torch.cat([existing_points, new_points], dim=0)
    
    print(
        f"  [RAR] Epoch {epoch}: added {k_actual} points "
        f"(max_res={residual_values.max().item():.3e}, "
        f"total_pts={augmented_points.shape[0]})"
    )
    
    model.train()
    return TensorDataset(augmented_points)


def _setup_self_adaptive_training(model, batch_size, lr):
    """
    Self-adaptive PINN training (McClenny & Braga-Neto 2022).
    
    Each collocation point gets a learnable weight λ_i.
    The weights are optimized simultaneously with network weights,
    causing the optimizer to focus on high-residual regions.
    """
    from rippl.training.adaptive_sampler import SelfAdaptiveWeights
    
    sa_weights = SelfAdaptiveWeights(
        n_points=batch_size,
        init_value=1.0
    )
    
    # Joint optimizer: network params + adaptive weights
    optimizer = torch.optim.Adam(
        list(model.parameters()) + list(sa_weights.parameters()),
        lr=lr
    )
    
    return sa_weights, optimizer


def _build_loss_balancer(mode, loss_names, model):
    if mode == "pareto":
        from rippl.training.pareto import ParetoLossBalancer
        return ParetoLossBalancer(n_objectives=len(loss_names))
    else:
        from rippl.training.ntk_weighting import AdaptiveLossBalancer
        return AdaptiveLossBalancer(
            mode="gradient_norm",
            loss_names=loss_names,
            update_freq=100,
        )


def _compute_conservation_penalty(
    conservation_laws,
    model,
    coords,
    domain,
    weight: float = 0.1,
):
    """
    Adds conservation law penalties to the training loss.
    """
    total_penalty = torch.tensor(0.0, device=coords.device)
    
    for law in conservation_laws:
        if hasattr(law, 'loss'):
            try:
                penalty = law.loss(model, coords, domain)
                total_penalty = total_penalty + penalty
            except Exception as e:
                # Don't crash training if a conservation law fails
                # Log it but continue
                print(f"  [Conservation] Warning: {type(law).__name__} failed: {e}")
    
    return weight * total_penalty


def _apply_curriculum_filtering(curriculum, coords, total_loss_value):
    """
    Temporal curriculum learning for time-dependent PDEs.
    """
    if curriculum is None:
        return coords
    
    filtered = curriculum.filter_coords(coords)
    
    # Only use filtered coords if we have enough points
    if filtered.shape[0] > 10:
        return filtered
    
    return coords


def _run_operator_learning(
    domain,
    equation,
    model,
    epochs: int = 500,
    lr: float = 1e-3,
    precision: str = "fp32",
    **kwargs
):
    from torch.utils.data import DataLoader
    from rippl.operators.operator_mode import OperatorTrainer
    import torch

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    # Cast model precision
    if precision == "fp64":
        model = model.double()
    elif precision == "bf16":
        model = model.to(torch.bfloat16)

    # Retrieve dataset or inputs/outputs
    dataset = kwargs.get("dataset")
    if dataset is None:
        inputs = kwargs.get("inputs")
        outputs = kwargs.get("outputs")
        if inputs is not None and outputs is not None:
            from rippl.core.operator_experiment import OperatorDataset
            dataset = OperatorDataset(inputs, outputs)
        else:
            raise ValueError("Operator learning requires a dataset, or inputs/outputs.")

    # Create optimizer
    opt = torch.optim.Adam(model.parameters(), lr=lr)

    # Create trainer
    trainer = OperatorTrainer(model, opt, device=device)

    # Data loader
    batch_size = kwargs.get("batch_size") or kwargs.get("bs", 32)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    hist = []
    for ep in range(epochs):
        epoch_loss = 0.0
        for batch in loader:
            inputs_b, targets_b = batch
            inputs_b = inputs_b.to(device)
            targets_b = targets_b.to(device)
            
            if precision == "fp64":
                inputs_b, targets_b = inputs_b.double(), targets_b.double()
            elif precision == "bf16":
                inputs_b, targets_b = inputs_b.to(torch.bfloat16), targets_b.to(torch.bfloat16)
                
            loss = trainer.training_step((inputs_b, targets_b))
            epoch_loss += loss

        avg_loss = epoch_loss / len(loader)
        hist.append(avg_loss)
        
        if (ep + 1) % 100 == 0:
            print(f"Epoch {ep+1:4d} | Operator Loss: {avg_loss:.6e}")

    return {
        "model": model,
        "model_state": model.state_dict(),
        "loss_history": hist,
        "final_loss": hist[-1] if hist else None
    }


def upscale(coarse, fno_model, target_points: int):
    """
    Physics DLSS (Deep Learning Super Resolution) primitive.
    Takes a coarse field, interpolates it to target_points,
    and runs the FNO model on the upscaled coordinates/field.
    """
    import torch
    import torch.nn.functional as F

    # Handle numpy arrays
    was_numpy = False
    if not isinstance(coarse, torch.Tensor):
        import numpy as np
        coarse = torch.tensor(coarse, dtype=torch.float32)
        was_numpy = True

    device = next(fno_model.parameters()).device
    dtype = next(fno_model.parameters()).dtype

    # Keep track of original shape
    orig_shape = coarse.shape
    orig_dim = coarse.dim()

    # Normalize to 3D: (B, N, C)
    if orig_dim == 1:
        # (N,) -> (1, N, 1)
        x = coarse.view(1, -1, 1)
    elif orig_dim == 2:
        # (N, C) -> (1, N, C)
        x = coarse.unsqueeze(0)
    elif orig_dim == 3:
        x = coarse
    else:
        raise ValueError(f"Unsupported input shape: {orig_shape}")

    # Interpolate along spatial dimension (dim 1)
    # interpolate expects (B, C, N)
    x = x.permute(0, 2, 1) # (B, C, N)
    x_fine = F.interpolate(x, size=target_points, mode="linear", align_corners=True)
    x_fine = x_fine.permute(0, 2, 1) # (B, target_points, C)

    # Cast to model device/dtype
    x_fine = x_fine.to(device=device, dtype=dtype)

    # Forward pass through FNO model
    fno_model.eval()
    with torch.no_grad():
        out_fine = fno_model(x_fine)

    # Move back to input device
    out_fine = out_fine.to(device=coarse.device, dtype=coarse.dtype)

    # Restore original dimension structure
    if orig_dim == 1:
        res = out_fine.view(-1)
    elif orig_dim == 2:
        res = out_fine.squeeze(0)
    else:
        res = out_fine

    if was_numpy:
        return res.cpu().numpy()
    return res


def run(
    domain,
    equation=None,
    model=None,
    epochs: int = 5000,
    lr: float = 5e-4,
    causal: bool = False,
    causal_mode: str = "continuous",
    adaptive_loss: bool = False,
    adaptive_loss_mode: str = "gradient_norm",
    adaptive_loss_freq: int = 100,
    hard_bcs: bool = False,
    collocation: str = "sobol",
    lbfgs_steps: int = 0,
    constraint_weight: float = 100.0,
    precision: str = "fp32",
    memory_efficient: bool = False,
    log: bool = False,
    experiment_name: str = "rippl_run",
    # NEW FLAGS:
    rar: bool = False,
    rar_freq: int = 500,
    rar_k: int = 100,
    rar_candidate_n: int = 5000,
    self_adaptive: bool = False,
    loss_balancer: str = "ntk",
    conservation_laws: list = None,
    curriculum=None,
    sdf=None,
    strategy: str = "auto",
    **kwargs,
):
    if strategy in ('ddp', 'fsdp', 'distributed'):
        # Check for pro gate on multi-process
        import torch
        if torch.cuda.device_count() < 2 and strategy == 'ddp':
            print("WARNING: strategy='ddp' requested but only 1 GPU detected.")
            print("Falling back to single-GPU with Accelerate.")

        try:
            from rippl.training.accelerate_engine import AccelerateEngine
            return _run_accelerate(
                domain, equation, model,
                epochs,
                strategy=strategy,
                kwargs={
                    "lr": lr,
                    "causal": causal,
                    "causal_mode": causal_mode,
                    "adaptive_loss": adaptive_loss,
                    "adaptive_loss_mode": adaptive_loss_mode,
                    "adaptive_loss_freq": adaptive_loss_freq,
                    "hard_bcs": hard_bcs,
                    "colloc": collocation,
                    "collocation": collocation,
                    "lbfgs": lbfgs_steps,
                    "lbfgs_steps": lbfgs_steps,
                    "cw": constraint_weight,
                    "constraint_weight": constraint_weight,
                    "precision": precision,
                    "memory_efficient": memory_efficient,
                    "log": log,
                    "experiment_name": experiment_name,
                    "rar": rar,
                    "rar_freq": rar_freq,
                    "rar_k": rar_k,
                    "rar_candidate_n": rar_candidate_n,
                    "self_adaptive": self_adaptive,
                    "loss_balancer": loss_balancer,
                    "conservation_laws": conservation_laws,
                    "curriculum": curriculum,
                    "sdf": sdf,
                    **kwargs
                }
            )
        except ImportError:
            raise ImportError(
                "Distributed training requires: pip install rippl[distributed]"
            )

    from rippl.core.system import System, Domain
    
    dom = domain
    eq = equation
    m = model

    if isinstance(dom, System):
        dom, eq, m = dom.domain, dom.equation, eq
    elif isinstance(dom, Domain) and isinstance(eq, System):
        dom, eq, m = eq.domain, eq.equation, m

    if "eps" in kwargs:
        epochs = kwargs.pop("eps")
        
    mode = kwargs.pop("mode", "pinn")
    if mode == "neural_ode": 
        return _run_neural_ode(dom, eq, m, precision=precision, lr=lr, eps=epochs, **kwargs)
    if mode == "operator":
        return _run_operator_learning(dom, eq, m, epochs=epochs, lr=lr, precision=precision, **kwargs)

    
    # Pack arguments back into kw for native runner to consume
    kw = {
        "lr": lr,
        "causal": causal,
        "causal_mode": causal_mode,
        "adaptive_loss": adaptive_loss,
        "adaptive_loss_mode": adaptive_loss_mode,
        "adaptive_loss_freq": adaptive_loss_freq,
        "hard_bcs": hard_bcs,
        "colloc": collocation,
        "collocation": collocation,
        "lbfgs": lbfgs_steps,
        "lbfgs_steps": lbfgs_steps,
        "cw": constraint_weight,
        "constraint_weight": constraint_weight,
        "precision": precision,
        "memory_efficient": memory_efficient,
        "log": log,
        "experiment_name": experiment_name,
        "rar": rar,
        "rar_freq": rar_freq,
        "rar_k": rar_k,
        "rar_candidate_n": rar_candidate_n,
        "self_adaptive": self_adaptive,
        "loss_balancer": loss_balancer,
        "conservation_laws": conservation_laws,
        "curriculum": curriculum,
        "sdf": sdf,
        **kwargs
    }

    return _run_native(dom, eq, m, int(epochs), mode, False, None, precision, sdf, kw)


def _rar_refinement_step(
    domain,
    equation,
    model,
    device,
    current_dataset,
    rar_k,
    rar_candidate_n,
    epoch,
    batch_size,
):
    """
    RAR: Residual-Based Adaptive Refinement.

    CRITICAL: Candidate evaluation runs entirely under torch.no_grad().
    RAR only SELECTS points — it never computes gradients for training.
    The autograd graph must be clean when this function returns so that
    the Pareto balancer (or any other gradient-based method) can build
    its own clean graph on the next training step.
    """
    from torch.utils.data import TensorDataset, DataLoader

    model.eval()

    # Sample candidates — Sobol for better space coverage
    sobol = torch.quasirandom.SobolEngine(len(domain.bounds), scramble=True)
    candidates_raw = sobol.draw(rar_candidate_n).to(device)
    for i, (lo, hi) in enumerate(domain.bounds):
        candidates_raw[:, i] = candidates_raw[:, i] * (hi - lo) + lo

    # For operators that need autograd internally (derivatives), use
    # a contained graph that is immediately discarded after selection
    candidates = candidates_raw.clone().detach().requires_grad_(True)

    # Use torch.enable_grad() in a contained scope
    with torch.enable_grad():
        try:
            u_cand = model(candidates)
            if isinstance(u_cand, dict):
                fields_cand = u_cand
            else:
                fields_cand = {"u": u_cand}

            residuals_raw = equation.compute_pointwise_residual(
                fields_cand, candidates
            )
            # Immediately detach — we only need the VALUES for selection
            residuals = residuals_raw.detach().squeeze()
        except AttributeError:
            # compute_pointwise_residual not available — use uniform
            residuals = torch.ones(rar_candidate_n, device=device)
        except Exception:
            residuals = torch.ones(rar_candidate_n, device=device)

    # Point selection — pure numpy/tensor indexing, no grad
    model.train()

    if residuals.dim() == 0 or residuals.shape[0] < 2:
        return current_dataset, DataLoader(
            current_dataset, batch_size=batch_size, shuffle=True
        )

    k_actual = min(rar_k, residuals.shape[0])
    _, top_idx = residuals.topk(k_actual)

    # Detach completely before storing in dataset
    new_pts = candidates_raw[top_idx].detach().cpu()
    existing = current_dataset.tensors[0]
    augmented = torch.cat([existing, new_pts], dim=0)

    print(
        f"  [RAR] epoch={epoch} "
        f"added={k_actual} "
        f"max_res={residuals.max().item():.3e} "
        f"total_pts={augmented.shape[0]}"
    )

    new_dataset = TensorDataset(augmented)
    new_loader = DataLoader(new_dataset, batch_size=batch_size, shuffle=True)
    return new_dataset, new_loader


def _run_neural_ode(dom, eq, m, precision="fp32", **kw):
    import torchdiffeq
    z0, ts = kw.get("z0"), kw.get("t_span")
    if z0 is None or ts is None: raise ValueError("Neural ODE requires z0 and t_span")
    
    if precision == "fp64":
        m, z0, ts = m.double(), z0.double(), ts.double()
    elif precision == "bf16":
        m, z0, ts = m.to(torch.bfloat16), z0.to(torch.bfloat16), ts.to(torch.bfloat16)
        
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    m, z0, ts = m.to(dev), z0.to(dev), ts.to(dev)
    opt = torch.optim.Adam(m.parameters(), lr=kw.get("lr", 1e-3))
    tgt, hist = kw.get("target"), []
    for _ in range(int(kw.get("eps", 1000))):
        opt.zero_grad()
        pz = torchdiffeq.odeint(m, z0, ts)
        loss = F.mse_loss(pz, tgt.to(dev)) if tgt is not None else torch.tensor(0.)
        loss.backward(); opt.step(); hist.append(loss.item())
    return {"model": m, "loss_history": hist}

def _run_native(dom, eq, m, eps, mode, parametric, param_bounds, precision, sdf, kw):
    from rippl_backend.causal import CausalTrainingMixin
    from rippl_backend.ntk_weighting import AdaptiveLossBalancer
    from rippl_backend.distance import AnsatzFactory
    from rippl.core.system import NeumannConstraint, IntConstraint, System
    from rippl_backend.pareto import ParetoBal
    from rippl.training.adaptive import AdaptWt, TimeCurr
    import torch.nn.functional as F

    original_dtype = torch.get_default_dtype()
    try:
        if precision == "fp64":
            torch.set_default_dtype(torch.float64)
            m = m.double()
            sys = kw.get("system") or getattr(eq, '_system', None)
            for c in getattr(sys, 'constraints', []):
                if hasattr(c, 'coords') and isinstance(c.coords, torch.Tensor): c.coords = c.coords.double()
                if hasattr(c, 'value') and isinstance(c.value, torch.Tensor):
                    c.value = c.value.double()
        elif precision == "bf16":
            m = m.to(torch.bfloat16)

        log = kw.get('logger', None)
        if log is None and kw.get('log', False):
            from rippl.training.logger import RipplLogger
            log = RipplLogger(
                kw.get('experiment_name', 'rippl_run'),
                log_dir=kw.get('log_dir', './rippl_logs')
            )
            log.log_config({'epochs':eps, 'lr':kw.get('lr',1e-3),
                            'causal':kw.get('causal',False),
                            'adaptive_loss':kw.get('adaptive_loss',False),
                            'hard_bcs':kw.get('hard_bcs',False)})

        dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if kw.get("hard_bcs"): m = AnsatzFactory.dirichlet_1d(m) if dom.spatial_dims==1 else AnsatzFactory.dirichlet_2d_box(m)
    
        if parametric:
            from rippl.physics.parametric import ParametricWrapper, ParametricSampler
            m = ParametricWrapper(m, len(param_bounds), param_bounds)
            smp = ParametricSampler(dom, param_bounds)
    
        m = m.to(dev)
    
        ldr = dom.generate_loader(batch_size=kw.get("bs", 2048) or kw.get("batch_size", 2048), meth=kw.get("colloc", "sobol"), sdf=sdf)
        dataset = ldr.dataset

        self_adaptive = kw.get("self_adaptive", False)
        if self_adaptive:
            from rippl.training.adaptive_sampler import SelfAdaptiveWeights
            _sa_weights = SelfAdaptiveWeights(
                n_points=kw.get("bs", 2048) or kw.get("batch_size", 2048),
                init_value=1.0,
            ).to(dev)
            _sa_optimizer = torch.optim.Adam(
                list(m.parameters()) + list(_sa_weights.parameters()),
                lr=kw.get("lr", 5e-4),
            )
            opt = _sa_optimizer
        else:
            _sa_weights = None
            opt = torch.optim.Adam(m.parameters(), lr=kw.get("lr", 5e-4))

        sch = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=200, factor=0.5, min_lr=1e-6)
    
        loss_balancer_mode = kw.get("loss_balancer", "ntk")
        if kw.get("adaptive_loss") or kw.get("ntk") or kw.get("loss_balancer"):
            bal = _build_loss_balancer(loss_balancer_mode, ["pde", "ic", "bc"], m)
        else:
            bal = None

        p_bal = ParetoBal(n_obj=3) if kw.get("pareto") else None
        csl = CausalTrainingMixin() if kw.get("causal") else None
        curriculum = kw.get("curriculum", kw.get("curr"))
        curr = curriculum
        a_wt = AdaptWt(kw.get("bs", 2048) or kw.get("batch_size", 2048)) if kw.get("adapt_wt") else None
        conservation_laws = kw.get("conservation_laws")
        
        rar = kw.get("rar", False)
        rar_freq = kw.get("rar_freq", 500)
        rar_k = kw.get("rar_k", 100)
        rar_candidate_n = kw.get("rar_candidate_n", 5000)

        hist = []

        for ep in range(eps):
            for b in ldr:
                if parametric:
                    x, p = smp.sample(kw.get("bs", 2048))
                    x, p = x.to(dev), p.to(dev)
                else:
                    x = b[0].to(dev)
            
                if precision == "fp64": x = x.double()
                elif precision == "bf16": x = x.to(torch.bfloat16)
                
                x = x.requires_grad_(True)
            
                if curriculum is not None:
                    filtered = curriculum.filter_coords(x)
                    if filtered.shape[0] > 10:
                        x = filtered
                    curriculum.step(l_tot.item() if "l_tot" in locals() else 0.0)
                elif curr:
                    x = curr.filter(x)
                    
                if len(x) == 0: continue
                opt.zero_grad()
            
                u = m(x, p) if parametric else m(x)
                flds = {"u": u}
            
                if self_adaptive:
                    from rippl.training.adaptive_sampler import SelfAdaptiveWeights
                    pt_res = eq.compute_pointwise_residual(flds, x)
                    if _sa_weights.log_weights.shape[0] != pt_res.shape[0]:
                        _sa_weights = SelfAdaptiveWeights(
                            n_points=pt_res.shape[0], init_value=1.0
                        ).to(dev)
                        _sa_optimizer = torch.optim.Adam(
                            list(m.parameters()) + list(_sa_weights.parameters()),
                            lr=kw.get("lr", 5e-4),
                        )
                        opt = _sa_optimizer
                    l_pde = _sa_weights(pt_res)
                elif csl:
                    pr = eq.compute_pointwise_residual(flds, x)
                    wts = csl.compute_causal_weights_continuous(x, pr) if kw.get("csl_mode","continuous")=="continuous" else csl.compute_causal_weights_binned(x, pr)
                    l_pde = (wts * pr).mean()
                elif a_wt:
                    pr = eq.compute_pointwise_residual(flds, x)
                    l_pde = a_wt(pr)
                else:
                    slv = Solver(dom, eq, m)
                    l_pde = slv._compute_loss(m, eq, x, flds, parametric, p if parametric else None, dev, **kw)

                l_ic, l_bc = torch.tensor(0., device=dev), torch.tensor(0., device=dev)
                if getattr(eq, '_system', None) or kw.get("system"):
                    sys = kw.get("system") or eq._system
                    for c in sys.constraints:
                        cc = c.coords if hasattr(c, 'coords') else c.x
                        if parametric:
                            pc = torch.zeros(len(cc), len(param_bounds), device=dev)
                            for i, (lo, hi) in enumerate(param_bounds):
                                pc[:, i] = torch.rand(len(pc), device=dev) * (hi-lo) + lo
                    
                        if isinstance(c, IntConstraint):
                            vc = m(cc.to(dev), pc) if parametric else m(cc.to(dev))
                            l_bc = l_bc + c.wt * ((c.w.to(dev) * vc.squeeze()).sum() - c.tgt)**2
                        elif isinstance(c, NeumannConstraint):
                            xc = cc.to(dev).requires_grad_(True)
                            vc = m(xc, pc) if parametric else m(xc)
                            gr = torch.autograd.grad(vc.sum(), xc, create_graph=True)[0]
                            l_bc = l_bc + F.mse_loss(gr[:, c.normal_direction:c.normal_direction+1], c.value.to(dev))
                        else:
                            xc = cc.to(dev)
                            vc = m(xc, pc) if parametric else m(xc)
                            t = c.value(xc) if callable(c.value) else c.value.to(dev)
                            if c.type == "initial": l_ic = l_ic + F.mse_loss(vc, t)
                            else: l_bc = l_bc + F.mse_loss(vc, t)

                ld = {"pde": l_pde, "ic": l_ic, "bc": l_bc}

                # In the training loop, check firing:
                rar_firing_this_epoch = (
                    rar and ep > 0 and ep % rar_freq == 0
                )

                # Only update Pareto balancer when RAR is NOT firing
                pareto_update_freq = kw.get('adaptive_loss_freq', 100)
                pareto_firing_this_step = (
                    (kw.get("adaptive_loss") or kw.get("ntk") or kw.get("loss_balancer") or kw.get("pareto")) and
                    (loss_balancer_mode == 'pareto' or kw.get("pareto")) and
                    ep % pareto_update_freq == 0 and
                    not rar_firing_this_epoch  # KEY: never same step as RAR
                )

                if p_bal:
                    if pareto_firing_this_step or not hasattr(p_bal, 'w') or p_bal.w is None:
                        l_tot = p_bal.compute(m, ld, dev=dev)
                    else:
                        ld_list = list(ld.values())
                        l_tot = sum(p_bal.w[i].item() * ld_list[i] for i in range(len(ld_list)))
                elif bal is not None:
                    if isinstance(bal, ParetoBal):
                        if pareto_firing_this_step or not hasattr(bal, 'w') or bal.w is None:
                            l_tot = bal.compute(m, ld, dev=dev)
                        else:
                            ld_list = list(ld.values())
                            l_tot = sum(bal.w[i].item() * ld_list[i] for i in range(len(ld_list)))
                    else:
                        if ep % pareto_update_freq == 0:
                            bal.update(m, ld, l_pde + 100*(l_ic+l_bc))
                        l_tot = bal.apply(ld)
                else:
                    l_tot = l_pde + kw.get("cw", 100.0)*(l_ic+l_bc)

                if conservation_laws:
                    for law in conservation_laws:
                        try:
                            penalty = law.loss(m, x, dom) if hasattr(law, "loss") else torch.tensor(0.0, device=dev)
                            l_tot = l_tot + 0.1 * penalty
                        except Exception:
                            pass  # Don't break training if a conservation law errors

                if not l_tot.requires_grad:
                    l_tot = l_tot + 0.0 * sum(p.sum() for p in m.parameters())

                l_tot.backward()
                torch.nn.utils.clip_grad_norm_(m.parameters(), 1.0)
                opt.step()
                
                # RAR refinement
                if rar_firing_this_epoch:
                    dataset, ldr = _rar_refinement_step(
                        dom, eq, m, dev,
                        dataset, rar_k, rar_candidate_n, ep,
                        kw.get("batch_size", 2048),
                    )
                
                sch.step(l_tot); hist.append(l_tot.item())
        
            if log and ep % 100 == 0:
                log.log_step(epoch=ep, loss=l_tot.item())

            if curr: curr.step()

        if kw.get("lbfgs", 300) > 0:
            opt_l = torch.optim.LBFGS(m.parameters(), lr=1.0, max_iter=20, line_search_fn="strong_wolfe")
            def clo():
                opt_l.zero_grad()
                x2 = next(iter(ldr))[0].to(dev)
                if precision == "fp64": x2 = x2.double()
                elif precision == "bf16": x2 = x2.to(torch.bfloat16)
                x2 = x2.requires_grad_(True)
                l = eq.compute_loss({"u": m(x2)}, x2) if hasattr(eq, 'compute_loss') else eq.compute_residual(m(x2), x2).pow(2).mean()
            
                # Ensure l has a grad_fn to avoid RuntimeError if loss is flat/disconnected
                if not l.requires_grad:
                    l = l + 0.0 * sum(p.sum() for p in m.parameters())
                
                l.backward(); return l
            for _ in range(kw.get("lbfgs", 300)): opt_l.step(clo)

        if log:
            log.log_result({'final_loss': hist[-1] if hist else None})
            log.finish()

    finally:
        torch.set_default_dtype(original_dtype)
    return {"model": m, "model_state": m.state_dict(), "loss_history": hist, "final_loss": hist[-1] if hist else None}


def _run_accelerate(domain, equation, model, epochs, strategy, kwargs):
    """
    Accelerate-powered training loop.
    Preserves rippl's three-phase recipe exactly.
    Works on any hardware topology via BYOC.
    """
    from rippl.training.accelerate_engine import AccelerateEngine
    import torch

    precision = kwargs.get('precision', 'fp32')
    lr = kwargs.get('lr', 5e-4)
    batch_size = kwargs.get('batch_size', 2048)

    engine = AccelerateEngine(
        precision=precision,
        gradient_accumulation_steps=kwargs.get('grad_accum', 1),
        log_with=kwargs.get('log_with', None),
    )

    # Standard optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    # Generate loader
    loader = domain.generate_loader(
        batch_size=batch_size,
        meth=kwargs.get('collocation', kwargs.get('colloc', 'sobol')),
    )

    # Prepare — Accelerate handles device placement + grad sync
    model, optimizer, loader = engine.prepare(model, optimizer, loader)

    loss_history = []

    for epoch in range(epochs):
        for batch in loader:
            coords = batch[0].requires_grad_(True)
            optimizer.zero_grad()

            u = model(coords)
            fields = {"u": u} if not isinstance(u, dict) else u

            # Causal training
            if kwargs.get('causal', False):
                from rippl.training.causal import CausalTrainingMixin
                mixin = CausalTrainingMixin()
                pt_res = equation.compute_pointwise_residual(fields, coords)
                weights = mixin.compute_causal_weights_continuous(
                    coords, pt_res
                )
                pde_loss = (weights * pt_res).mean()
            else:
                # Mirror Solver._compute_loss: prefer compute_loss, fall back to
                # compute_residual (standard Equation API only has compute_residual)
                if hasattr(equation, 'compute_loss'):
                    pde_loss = equation.compute_loss(fields, coords)
                else:
                    pde_loss = equation.compute_residual(
                        fields["u"], coords
                    ).pow(2).mean()

            total_loss = pde_loss
            loss_history.append(total_loss.item())

            # Accelerate backward (handles mixed precision scaling)
            engine.backward(total_loss)
            engine.clip_grad_norm(model.parameters(), 1.0)
            optimizer.step()

        if epoch % max(1, epochs // 20) == 0 and engine.is_main_process:
            engine.print(f"  epoch={epoch} loss={loss_history[-1]:.4e}")

    # Unwrap model before returning (removes DDP wrapper)
    unwrapped = engine.unwrap_model(model)
    engine.wait_for_everyone()

    return {
        "model": unwrapped,
        "loss_history": loss_history,
        "final_loss": loss_history[-1] if loss_history else None,
    }
