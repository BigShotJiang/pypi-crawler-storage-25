import torch
from typing import Any, Dict, Union

def describe(target: Any):
    """
    Deterministic CLI profiler for Rippl objects.
    Replaces deprecated generative physics logic with structural introspection.
    """
    if hasattr(target, "equation") and hasattr(target, "domain"):
        print("\n=== RIPPL SYSTEM GRAPH ===")
        print(f"Spatial Dims: {target.domain.spatial_dims}")
        print(f"Bounds:       {target.domain.bounds}")
        print("Operators:")
        eq = target.equation
        from rippl.core.equation_system import EquationSystem
        equations = eq.equations if isinstance(eq, EquationSystem) else [eq]
        for i, e in enumerate(equations):
            if len(equations) > 1: print(f"  Equation {i}:")
            for coef, op in e.terms:
                print(f"    [{coef:+.4f}] {op.__class__.__name__}")
        print(f"Constraints:  {len(target.constraints)}")

    elif isinstance(target, torch.nn.Module):
        print("\n=== RIPPL MODEL PROFILE ===")
        params = sum(p.numel() for p in target.parameters())
        print(f"Type:       {target.__class__.__name__}")
        print(f"Parameters: {params:,}")
        print(f"Device:     {next(target.parameters()).device}")
        if hasattr(target, "symplectic_loss"): print("Features:   [Symplectic/Hamiltonian]")
        if "ParametricWrapper" in target.__class__.__name__: print("Features:   [Parametric]")

    elif isinstance(target, dict) and ("loss_history" in target or "final_loss" in target):
        print("\n=== RIPPL EXECUTION RESULT ===")
        print(f"Final Loss: {target.get('final_loss', 'N/A')}")
        hist = target.get("loss_history", [])
        if hist:
            print(f"Epochs:     {len(hist)}")
            print(f"Start Loss: {hist[0]:.6e}")
            print(f"End Loss:   {hist[-1]:.6e}")
    else:
        print(f"Unknown target type: {type(target)}")
