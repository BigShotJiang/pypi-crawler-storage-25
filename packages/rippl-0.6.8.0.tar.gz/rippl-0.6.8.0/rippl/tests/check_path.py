import sys
import rippl
def test_path():
    print(f"\nDEBUG: sys.path: {sys.path}")
    print(f"DEBUG: rippl.__file__: {rippl.__file__}")
    print(f"DEBUG: dir(rippl): {dir(rippl)}")
