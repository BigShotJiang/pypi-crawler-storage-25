import torch
from rippl.nn import MLP
from rippl.nn.wrappers import PDFWrapper

def test_pdf_wrapper_positivity():
    raw_net = MLP(input_dim=2, output_dim=1, hidden_layers=[32, 32])
    pdf_net = PDFWrapper(raw_net)
    
    # Generate coordinates
    coords = torch.rand(1000, 2)
    
    # Force the raw network to output massive negative numbers
    with torch.no_grad():
        for param in raw_net.parameters():
            param.fill_(-10.0)
            
    out = pdf_net(coords)
    
    # 1. Check strict positivity (no negative probabilities)
    assert (out >= 0).all(), "PDFWrapper failed: Negative probabilities detected."

def test_pdf_wrapper_normalization():
    raw_net = MLP(input_dim=2, output_dim=1, hidden_layers=[32, 32])
    pdf_net = PDFWrapper(raw_net)
    
    # Uniformly sample a unit domain [0,1]x[0,1]
    coords = torch.rand(5000, 2)
    out = pdf_net(coords)
    
    # 2. Check normalization (Integral over unit domain must = 1.0)
    # Using Monte Carlo integration: Volume * mean(values)
    # Since Volume = 1 for [0,1]^2, integral is just the mean
    integral = out.mean().item()
    
    assert abs(integral - 1.0) < 1e-4, f"PDFWrapper failed: Integral = {integral}, expected 1.0"
