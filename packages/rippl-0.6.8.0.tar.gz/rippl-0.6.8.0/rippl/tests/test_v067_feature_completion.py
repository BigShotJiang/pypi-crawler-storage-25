"""
Unit tests for rippl v0.6.7 feature completion sprint.
Verifies RAR, self-adaptive weights, Pareto loss balancing,
conservation laws, curriculum learning, and HighFreqSIREN models.
"""

import pytest
import torch
import torch.nn as nn
import math

import rippl as rp
import rippl.nn as rnn
from rippl.core.system import Domain, Constraint, System
from rippl.core.equation import Equation
from rippl.physics.operators import TimeDerivative, Diffusion
from rippl.physics.conservation import ConservationLaw


def make_heat_system():
    """Helper to construct a simple 1D Heat Equation system."""
    domain = Domain(spatial_dims=1, bounds=[(0.0, 1.0), (0.0, 1.0)])
    equation = Equation([
        TimeDerivative(order=1),
        Diffusion(alpha=0.05),
    ])
    
    # Initial and boundary conditions
    x_ic = torch.linspace(0, 1.0, 100).unsqueeze(1)
    c_ic = torch.cat([x_ic, torch.zeros(100, 1)], dim=1)
    u_ic = torch.sin(math.pi * x_ic)
    
    t_bc = torch.linspace(0, 1.0, 100).unsqueeze(1)
    c_bcl = torch.cat([torch.zeros(100, 1), t_bc], dim=1)
    c_bcr = torch.cat([torch.ones(100, 1), t_bc], dim=1)
    u_bc = torch.zeros(100, 1)
    
    constraints = [
        Constraint(type='initial',   field='u', coords=c_ic,  value=u_ic),
        Constraint(type='dirichlet', field='u', coords=c_bcl, value=u_bc),
        Constraint(type='dirichlet', field='u', coords=c_bcr, value=u_bc),
    ]
    
    # Link equation and system
    _ = System(domain, equation, constraints)
    
    return domain, equation, constraints


def test_rar_flag():
    """rp.run with rar=True expands training dataset and executes without error."""
    domain, equation, constraints = make_heat_system()
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=32, layers=3)
    
    # Run with small epochs to verify RAR step triggers
    result = rp.run(
        domain=domain,
        equation=equation,
        model=model,
        epochs=15,
        lr=1e-3,
        rar=True,
        rar_freq=5,
        rar_k=10,
        rar_candidate_n=100,
        lbfgs_steps=0,
        log=False,
    )
    
    assert result['final_loss'] is not None
    assert 'model' in result


def test_self_adaptive_flag():
    """rp.run with self_adaptive=True optimizes joint network+point weights."""
    domain, equation, constraints = make_heat_system()
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=32, layers=3)
    
    result = rp.run(
        domain=domain,
        equation=equation,
        model=model,
        epochs=20,
        lr=1e-3,
        self_adaptive=True,
        lbfgs_steps=0,
        log=False,
    )
    
    assert result['final_loss'] is not None


def test_pareto_balancer_flag():
    """rp.run with loss_balancer='pareto' and adaptive_loss=True."""
    domain, equation, constraints = make_heat_system()
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=32, layers=3)
    
    result = rp.run(
        domain=domain,
        equation=equation,
        model=model,
        epochs=10,
        lr=1e-3,
        adaptive_loss=True,
        loss_balancer='pareto',
        lbfgs_steps=0,
        log=False,
    )
    
    assert result['final_loss'] is not None


def test_conservation_law_flag():
    """rp.run with conservation_laws=[...] adds penalty."""
    domain, equation, constraints = make_heat_system()
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=32, layers=3)
    
    # Dummy conservation law that computes mean field
    def mean_quantity(m, coords):
        return m(coords).mean()
        
    law = ConservationLaw(
        name="mean_field",
        quantity_fn=mean_quantity,
        tolerance=1e-3
    )
    
    result = rp.run(
        domain=domain,
        equation=equation,
        model=model,
        epochs=10,
        lr=1e-3,
        conservation_laws=[law],
        conservation_weight=0.5,
        lbfgs_steps=0,
        log=False,
    )
    
    assert result['final_loss'] is not None
    assert law.reference is not None


def test_curriculum_flag():
    """rp.run with TemporalCurriculum runs without error."""
    from rippl.training.curriculum import TemporalCurriculum
    
    domain, equation, constraints = make_heat_system()
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=32, layers=3)
    curriculum = TemporalCurriculum(
        t_start=0.0,
        t_end=1.0,
        n_stages=3,
        patience=5
    )
    
    result = rp.run(
        domain=domain,
        equation=equation,
        model=model,
        epochs=20,
        lr=1e-3,
        curriculum=curriculum,
        lbfgs_steps=0,
        log=False,
    )
    
    assert result['final_loss'] is not None


def test_high_freq_siren():
    """rnn.HighFreqSIREN compiles, has correct parameters, forward pass works."""
    model = rnn.HighFreqSIREN(
        in_dim=2,
        out_dim=1,
        hidden=64,
        layers=3,
        omega_0=60.0
    )
    
    assert isinstance(model, nn.Module)
    
    # Verify forward pass
    x = torch.randn(10, 2)
    y = model(x)
    assert y.shape == (10, 1)
