"""
Tests for Phase A fixes:
- RAR/Pareto collision resolved
- Wave 1D L2 benchmark
- Burgers benchmark
- Accelerate engine
"""

import torch
import math
import pytest
import rippl as rp
import rippl.nn as rnn
from rippl.core.system import Domain, Constraint
from rippl.core.equation import Equation
from rippl.physics.operators import TimeDerivative, Diffusion, Laplacian


@pytest.fixture
def heat_domain_eq():
    domain = Domain(spatial_dims=1, bounds=[(0,1),(0,1)])
    equation = Equation([TimeDerivative(1), Diffusion(alpha=0.1)])
    x = torch.rand(100,1)
    c = torch.cat([x, torch.zeros(100,1)],1)
    return domain, equation


@pytest.fixture
def wave_domain_eq():
    domain = Domain(spatial_dims=1, bounds=[(0,1),(0,1)])
    equation = Equation([TimeDerivative(2), Laplacian(spatial_dims=1)])
    return domain, equation


def test_rar_and_pareto_no_runtime_error(heat_domain_eq):
    """RAR + Pareto must not raise RuntimeError."""
    domain, equation = heat_domain_eq
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=16, layers=2)
    # This was crashing before the fix
    result = rp.run(
        domain=domain, equation=equation, model=model,
        epochs=60, lr=1e-3, lbfgs_steps=0, log=False,
        rar=True, rar_freq=25, rar_k=5, rar_candidate_n=50,
        adaptive_loss=True, loss_balancer='pareto',
    )
    assert result['final_loss'] is not None
    assert not math.isnan(result['final_loss'])


def test_rar_candidate_eval_no_graph_leak(heat_domain_eq):
    """
    After RAR fires, the autograd graph must be clean.
    Subsequent backward() must succeed without 'freed graph' errors.
    """
    domain, equation = heat_domain_eq
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=16, layers=2)

    result = rp.run(
        domain=domain, equation=equation, model=model,
        epochs=80, lr=1e-3, lbfgs_steps=0, log=False,
        rar=True, rar_freq=30, rar_k=5, rar_candidate_n=50,
        adaptive_loss=True, loss_balancer='ntk',
    )
    assert result['final_loss'] is not None


def test_rar_and_ntk_coexist(heat_domain_eq):
    """RAR + NTK (not Pareto) must work together."""
    domain, equation = heat_domain_eq
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=16, layers=2)
    result = rp.run(
        domain=domain, equation=equation, model=model,
        epochs=80, lr=1e-3, lbfgs_steps=0, log=False,
        rar=True, rar_freq=30, rar_k=5, rar_candidate_n=50,
        adaptive_loss=True, loss_balancer='ntk',
    )
    assert result['final_loss'] is not None


def test_pareto_retain_graph_correct():
    """Pareto compute() must not raise on multi-objective backward."""
    import torch.nn as nn
    from rippl.training.pareto import ParetoLossBalancer

    model = nn.Linear(2, 1)
    x = torch.rand(20, 2)
    out = model(x)

    loss_dict = {
        "pde": out.mean() * 2.0,
        "ic":  out.std()  * 0.5,
        "bc":  (out**2).mean() * 0.1,
    }
    balancer = ParetoLossBalancer(n_objectives=3)
    # Must not raise RuntimeError: Trying to backward through graph twice
    combined = balancer.compute(model, loss_dict, device='cpu')
    combined.backward()
    assert model.weight.grad is not None


def test_wave_1d_convergence(wave_domain_eq):
    """Wave 1D must converge — verify L2 decreases substantially."""
    domain, equation = wave_domain_eq
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=32, layers=3)
    result = rp.run(
        domain=domain, equation=equation, model=model,
        epochs=200, lr=1e-3, lbfgs_steps=0, log=False,
        causal=True, adaptive_loss=True, hard_bcs=True,
    )
    history = result['loss_history']
    assert len(history) > 10
    # Loss must decrease — first 10 avg vs last 10 avg
    early = sum(history[:10]) / 10
    late  = sum(history[-10:]) / 10
    assert late < early, f"Loss not decreasing: early={early:.4e} late={late:.4e}"


def test_accelerate_engine_imports():
    """AccelerateEngine import must fail gracefully if not installed."""
    try:
        from rippl.training.accelerate_engine import AccelerateEngine, HAS_ACCELERATE
        # Either it works or HAS_ACCELERATE is False
        assert isinstance(HAS_ACCELERATE, bool)
    except ImportError:
        pass  # OK — accelerate not installed


def test_accelerate_engine_instantiates_if_available():
    """If accelerate is installed, engine must instantiate."""
    try:
        import accelerate
    except ImportError:
        pytest.skip("accelerate not installed")

    from rippl.training.accelerate_engine import AccelerateEngine
    engine = AccelerateEngine(precision='fp32')
    assert engine is not None
    assert engine.device is not None


def test_run_strategy_auto_unchanged(heat_domain_eq):
    """strategy='auto' must use existing path — no regression."""
    domain, equation = heat_domain_eq
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=16, layers=2)
    result = rp.run(
        domain=domain, equation=equation, model=model,
        epochs=20, lr=1e-3, strategy='auto', lbfgs_steps=0, log=False,
    )
    assert result['final_loss'] is not None


def test_run_strategy_ddp_with_single_gpu(heat_domain_eq):
    """strategy='ddp' on single GPU must warn and fall back gracefully."""
    try:
        import accelerate
    except ImportError:
        pytest.skip("accelerate not installed")

    domain, equation = heat_domain_eq
    model = rnn.MLP(in_dim=2, out_dim=1, hidden=16, layers=2)
    # Should not crash — should fall back with warning
    result = rp.run(
        domain=domain, equation=equation, model=model,
        epochs=10, lr=1e-3, strategy='ddp', lbfgs_steps=0, log=False,
    )
    assert result['final_loss'] is not None
