import torch
from rippl_backend.derivatives import compute_all_derivatives

def test_t_derivative():
    coords = torch.randn(10, 2, requires_grad=True) # x, t
    fields = {"u": coords[:, 1:2]**2} # u = t^2
    try:
        derived = compute_all_derivatives(fields, coords, ["u_t"])
        print(f"u_t: {derived['u_t']}")
    except ValueError as e:
        print(f"Caught expected error: {e}")

if __name__ == "__main__":
    test_t_derivative()
