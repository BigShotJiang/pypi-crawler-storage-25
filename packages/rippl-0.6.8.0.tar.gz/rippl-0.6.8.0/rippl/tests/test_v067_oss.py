import os
import torch
import pytest
import rippl as rp
from rippl.physics.stochastic import PDFWrapper
from rippl.physics.maxwell import MaxwellSystem, HelmholtzMaxwellSystem
from rippl.physics.quantum import GPESystem
from rippl.physics.euler import EulerSystem
from rippl.training.fbpinn import FBPINNSolver
from rippl.diagnostics.physics_validator import PhysicsValidator
from rippl.geometry.csg import Rectangle, CSGSampler, BoxSDF
from rippl.models.neural_ode import NeuralODE, ODEFunc
from rippl.migrate.transpiler import migrate

def test_pdf_wrapper():
    model = torch.nn.Linear(2, 1)
    pdf = PDFWrapper(model, domain_volume=1.0)
    x = torch.rand(10, 2)
    p = pdf(x)
    assert (p >= 0).all()
    # normalization is approximate via batch mean in PDFWrapper
    assert torch.allclose(p.mean(), torch.tensor(1.0/1.0), atol=1e-5)

def test_maxwell_builds():
    sys = MaxwellSystem()
    eq_sys = sys.build_equation_system()
    assert len(eq_sys.equations) == 4
    assert sys.fields() == ["Ex","Ey","Ez","Bx","By","Bz"]

def test_helmholtz_maxwell_builds():
    sys = HelmholtzMaxwellSystem(k=2.0)
    eq_sys = sys.build_equation_system()
    assert len(eq_sys.equations) == 12
    assert "Ex_real" in sys.fields()

def test_biharmonic_accuracy():
    from rippl.physics.operators import BiharmonicOperator
    # u = x^2 * y^2
    # u_x = 2xy^2, u_xx = 2y^2, u_xxx = 0, u_xxxx = 0
    # u_y = 2x^2y, u_yy = 2x^2, u_yyy = 0, u_yyyy = 0
    # u_xxyy = 4
    # Δ²u = u_xxxx + 2u_xxyy + u_yyyy = 0 + 2(4) + 0 = 8
    
    op = BiharmonicOperator(spatial_dims=2)
    x = torch.linspace(0, 1, 10, requires_grad=True).view(-1, 1)
    y = torch.linspace(0, 1, 10, requires_grad=True).view(-1, 1)
    coords = torch.cat([x, y], dim=-1)
    u = (coords[:, 0:1]**2 * coords[:, 1:2]**2)
    
    from rippl_backend.derivatives import compute_all_derivatives
    der = compute_all_derivatives({"u": u}, coords, op.signature()["requires_derived"])
    res = op.forward({"u": u}, coords, der)
    
    # In BiharmonicOperator, we sum u_iijj for all i, j
    # For 2D: u_xxxx + u_xxyy + u_yyxx + u_yyyy
    # u_xxxx = 0, u_xxyy = 4, u_yyxx = 4, u_yyyy = 0
    # Total = 8
    assert torch.allclose(res, torch.tensor(8.0), atol=1e-3)

def test_gpe_builds():
    sys = GPESystem()
    eq_sys = sys.build_equation_system()
    assert len(eq_sys.equations) == 1
    assert "psi_real" in sys.fields()

def test_euler_pressure():
    sys = EulerSystem()
    rho = torch.tensor([1.0])
    rhou = torch.tensor([0.5])
    E = torch.tensor([2.0])
    p = sys.pressure(rho, rhou, E)
    assert p > 0
    m = sys.mach_number(rho, rhou, E)
    assert m > 0

def test_fp64_support():
    dom = rp.Domain(spatial_dims=1, bounds=[(0, 1)], resolution=(10,))
    from rippl.physics.operators import Laplacian
    eq = rp.core.equation.Equation([(1.0, Laplacian())])
    model = torch.nn.Linear(1, 1)
    res = rp.run(dom, eq, model, precision="fp64", epochs=1)
    assert res["model"].weight.dtype == torch.float64

def test_fbpinn_forward():
    dom = rp.Domain(spatial_dims=1, bounds=[(0, 1)], resolution=(10,))
    from rippl.physics.operators import Laplacian
    eq = rp.core.equation.Equation([(1.0, Laplacian())])
    solver = FBPINNSolver(dom, eq, n_subdomains=5)
    x = torch.rand(10, 1)
    y = solver(x)
    assert y.shape == (10, 1)

def test_extrapolation_warning():
    dom = rp.Domain(spatial_dims=1, bounds=[(0, 1)], resolution=(10,))
    from rippl.physics.operators import Laplacian
    eq = rp.core.equation.Equation([(1.0, Laplacian())])
    model = torch.nn.Linear(1, 1)
    validator = PhysicsValidator(rp.System(eq, dom), model, torch.rand(10, 1))
    
    with pytest.warns(UserWarning, match="outside training domain"):
        warn_data = validator.extrapolation_warning(torch.tensor([[2.0]]))
        assert warn_data["warning"] is True

def test_csg_bbox_tree():
    rect = Rectangle(0, 1, 0, 1)
    sampler = CSGSampler(rect)
    pts = torch.tensor([[0.5, 0.5], [2.0, 2.0]])
    mask = sampler.bbox_tree.quick_reject(pts)
    assert mask[0].item() is True
    assert mask[1].item() is False

def test_stiff_ode_method():
    func = ODEFunc(dim=2)
    model = NeuralODE(func)
    z0 = torch.randn(1, 2)
    t = torch.linspace(0, 1, 10)
    # Just check if it runs without error (requires torchdiffeq)
    try:
        traj = model.forward_stiff(z0, t, method="implicit_adams")
        assert traj.shape == (10, 1, 2)
    except ImportError:
        pytest.skip("torchdiffeq not installed")

def test_logger_integration():
    import shutil
    log_dir = "./test_rippl_logs"
    if os.path.exists(log_dir): shutil.rmtree(log_dir)
    
    dom = rp.Domain(spatial_dims=1, bounds=[(0, 1)], resolution=(10,))
    from rippl.physics.operators import Laplacian
    eq = rp.core.equation.Equation([(1.0, Laplacian())])
    model = torch.nn.Linear(1, 1)
    
    rp.run(dom, eq, model, epochs=2, log=True, log_dir=log_dir, experiment_name="test_exp")
    
    assert len(os.listdir(log_dir)) > 0
    shutil.rmtree(log_dir)

def test_sdf_loader():
    class MockSDF:
        def adaptive_sample_interior(self, n):
            return torch.rand(n, 2)
    
    dom = rp.Domain(spatial_dims=2, bounds=[(0, 1), (0, 1)], resolution=(10, 10))
    ldr = dom.generate_loader(batch_size=10, sdf=MockSDF())
    batch = next(iter(ldr))
    assert batch[0].shape == (10, 2)

def test_transpilers():
    modulus_src = "import modulus\nPDE()"
    sciann_src = "import sciann\nConstraint()"
    
    script_mod = migrate(modulus_src, framework="modulus")
    script_sci = migrate(sciann_src, framework="sciann")
    
    assert "import rippl" in script_mod
    assert "Original Framework: Modulus" in script_mod
    assert "import rippl" in script_sci
    assert "Original Framework: SciANN" in script_sci

import os
