import torch, math
import pytest

def test_helmholtz_operator_shape():
    from rippl.physics.operators import HelmholtzOperator
    from rippl_backend.derivatives import compute_all_derivatives
    x = torch.rand(100, 1, requires_grad=True)
    u = torch.sin(x)
    derived = compute_all_derivatives({"u":u}, x, ["u_xx"])
    op = HelmholtzOperator(k=1.0, spatial_dims=1)
    out = op.forward({"u":u}, x, derived)
    assert out.shape == (100,1)

def test_helmholtz_analytic():
    from rippl.physics.operators import HelmholtzOperator
    from rippl_backend.derivatives import compute_all_derivatives
    # u=sin(x), k=1: u_xx + u = -sin(x) + sin(x) = 0
    x = torch.linspace(0,1,100).unsqueeze(1).requires_grad_(True)
    u = torch.sin(x)
    derived = compute_all_derivatives({"u":u}, x, ["u_xx"])
    op = HelmholtzOperator(k=1.0, spatial_dims=1)
    out = op.forward({"u":u}, x, derived)
    assert out.abs().max().item() < 0.1

def test_curl_2d_shape():
    from rippl.physics.operators import Curl
    from rippl_backend.derivatives import compute_all_derivatives
    coords = torch.rand(50, 2, requires_grad=True)
    u = coords[:,0:1]; v = coords[:,1:2]
    derived = compute_all_derivatives({"u":u,"v":v}, coords,
                                       ["u_y","v_x"])
    op = Curl(field_u="u", field_v="v", dims=2)
    out = op.forward({"u":u,"v":v}, coords, derived)
    assert out.shape == (50,1)

def test_curl_divergence_free_field():
    from rippl.physics.operators import Curl
    from rippl_backend.derivatives import compute_all_derivatives
    # u=sin(x)cos(y), v=-cos(x)sin(y): curl = 0
    coords = torch.rand(50,2,requires_grad=True)
    x,y = coords[:,0:1], coords[:,1:2]
    u = torch.sin(x)*torch.cos(y)
    v = torch.cos(x)*torch.sin(y)
    derived = compute_all_derivatives({"u":u,"v":v}, coords,
                                       ["u_y","v_x"])
    op = Curl(dims=2)
    out = op.forward({"u":u,"v":v}, coords, derived)
    assert out.abs().max().item() < 0.1

def test_vector_laplacian_shape():
    from rippl.physics.operators import VectorLaplacian
    from rippl_backend.derivatives import compute_all_derivatives
    coords = torch.rand(50,2,requires_grad=True)
    u = coords[:,0:1]; v = coords[:,1:2]
    derived = compute_all_derivatives(
        {"u":u,"v":v}, coords, ["u_xx","u_yy","v_xx","v_yy"]
    )
    op = VectorLaplacian(fields_list=["u","v"], spatial_dims=2)
    out = op.forward({"u":u,"v":v}, coords, derived)
    assert out.shape == (50,2)

def test_source_term_callable():
    from rippl.physics.operators import SourceTerm
    coords = torch.rand(50,2)
    op = SourceTerm(source_fn=lambda x: x[:,0:1]**2)
    out = op.forward({"u": coords[:,0:1]}, coords, {})
    assert out.shape == (50,1)
    expected = -coords[:,0:1]**2
    assert (out - expected).abs().max().item() < 1e-6

def test_source_term_constant():
    from rippl.physics.operators import SourceTerm
    coords = torch.rand(50,2)
    op = SourceTerm(value=1.0)
    out = op.forward({"u": coords[:,0:1]}, coords, {})
    assert (out + 1.0).abs().max().item() < 1e-6

def test_box_sdf_negative_inside():
    from rippl.geometry.csg import BoxSDF
    sdf = BoxSDF([(0,1),(0,1)])
    interior = torch.tensor([[0.5, 0.5]])
    assert sdf.sdf(interior).item() < 0

def test_box_sdf_positive_outside():
    from rippl.geometry.csg import BoxSDF
    sdf = BoxSDF([(0,1),(0,1)])
    exterior = torch.tensor([[2.0, 0.5]])
    assert sdf.sdf(exterior).item() > 0

def test_box_sdf_zero_on_boundary():
    from rippl.geometry.csg import BoxSDF
    sdf = BoxSDF([(0,1),(0,1)])
    boundary = torch.tensor([[0.0, 0.5]])
    assert sdf.sdf(boundary).abs().item() < 1e-5

def test_sphere_sdf_negative_inside():
    from rippl.geometry.csg import SphereSDF
    sdf = SphereSDF(center=(0,0), radius=1.0)
    pt = torch.tensor([[0.0, 0.0]])
    assert sdf.sdf(pt).item() < 0

def test_sphere_sdf_unit_normal():
    from rippl.geometry.csg import SphereSDF
    sdf = SphereSDF(center=(0,0), radius=1.0)
    pts = sdf.sample_boundary(100)
    normals = sdf.normal(pts)
    norms = normals.norm(dim=-1)
    assert (norms - 1.0).abs().max().item() < 1e-5

def test_rippl_logger_creates_file():
    from rippl.training.logger import RipplLogger
    import tempfile, os
    with tempfile.TemporaryDirectory() as tmp:
        logger = RipplLogger("test_exp", log_dir=tmp)
        logger.log_config({"lr": 1e-3, "epochs": 100})
        logger.log_step(epoch=0, loss=1.0)
        logger.log_step(epoch=1, loss=0.5)
        logger.log_result({"l2": 1e-3, "status": "PASS"})
        logger.finish()
        files = os.listdir(tmp)
        assert any("test_exp" in f for f in files)

def test_rippl_logger_loss_curve():
    from rippl.training.logger import RipplLogger
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        logger = RipplLogger("test", log_dir=tmp)
        for i in range(5):
            logger.log_step(epoch=i, loss=1.0/(i+1))
        curve = logger.loss_curve()
        assert len(curve) == 5
        assert curve[0] > curve[-1]

def test_describe_returns_dict():
    import rippl as rp
    result = rp.describe()
    assert isinstance(result, dict)
    assert "operators" in result
    assert "benchmarks" in result

def test_describe_heat_query():
    import rippl as rp
    result = rp.describe("heat")
    assert "pde" in result or "heat" in str(result)

def test_describe_operators_query():
    import rippl as rp
    result = rp.describe("operators")
    assert "operators" in result
    assert len(result["operators"]) > 10

def test_lagrangian_nn_acceleration_shape():
    from rippl.models.lagrangian import LagrangianNN
    lnn = LagrangianNN(n_dof=1, hidden=32, layers=2)
    q    = torch.tensor([[1.0]])
    qdot = torch.tensor([[0.5]])
    try:
        acc = lnn.acceleration(q, qdot)
        assert acc.shape == (1,1), f"Wrong shape: {acc.shape}"
        print("LagrangianNN: SOUND")
    except Exception as e:
        pytest.fail(f"LagrangianNN broken: {e}")

def test_save_load_rpx():
    from rippl.export import save_rpx, load_rpx
    import torch.nn as nn, tempfile, os
    model = nn.Linear(2,1)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "test.rpx")
        save_rpx(model, path, metadata={"pde":"heat","l2":1e-4})
        sd, card = load_rpx(path)
        assert "weight" in sd
        assert card.get("pde") == "heat"
        assert "rippl_version" in card
