"""
Unit tests for rippl v0.6.7.2 operator learning / OSS foundation.
Verifies FNO1d initialization, operator learning training mode,
FNOFlywheel pipelines, and the rp.upscale() physical DLSS primitive.
"""

import pytest
import torch
import numpy as np
import rippl as rp
from rippl.models.fno_oss import FNO1d
from rippl.training.fno_flywheel import FNOFlywheel
from rippl.core.system import Domain, System
from rippl.core.equation import Equation
from rippl.physics.operators import Laplacian, TimeDerivative

def test_fno1d_initialization():
    # Instantiate FNO1d
    model = FNO1d(n_modes=8, width=16, input_dim=1, output_dim=1)
    
    # Test forward pass shape
    x = torch.randn(2, 32, 1)
    y = model(x)
    assert y.shape == (2, 32, 1)

def test_operator_learning_run():
    # Setup simple data
    inputs = torch.randn(10, 32, 1)
    outputs = torch.randn(10, 32, 1)
    
    domain = Domain(spatial_dims=1, bounds=[(0.0, 1.0)])
    equation = Equation([]) # Dummy equation
    
    model = FNO1d(n_modes=4, width=8, input_dim=1, output_dim=1)
    
    result = rp.run(
        domain=domain,
        equation=equation,
        model=model,
        mode="operator",
        inputs=inputs,
        outputs=outputs,
        epochs=5,
        lr=1e-3,
        batch_size=2
    )
    
    assert "model" in result
    assert "final_loss" in result
    assert result["final_loss"] is not None

def test_fno_flywheel_pipeline():
    # 1D Domain with resolution
    domain = Domain(spatial_dims=1, bounds=[(0.0, 1.0)], resolution=(32,))
    equation = Equation([
        (1.0, TimeDerivative(order=1)),
        (-0.01, Laplacian(field="u")) # u_t - 0.01 * u_xx = 0 -> u_t = 0.01 * u_xx
    ])
    
    # Build System
    sys = System(equation=equation, domain=domain)
    
    from rippl.nn.fno import FNO
    fno_model = FNO(n_modes=4, width=8, input_dim=1, output_dim=1)
    
    # Instantiate FNOFlywheel
    flywheel = FNOFlywheel(system=sys, fno_model=fno_model, n_train=4, n_test=2)
    
    # Run the pipeline
    res = flywheel.pipeline(train_epochs=5, lr=1e-3, batch_size=2)
    
    # Verify return dictionary contains all required fields
    assert "loss_history" in res
    assert "test_l2" in res
    assert "mean_l2" in res
    assert "max_l2" in res
    assert "min_l2" in res
    assert len(res["loss_history"]) == 5

def test_upscale_api():
    model = FNO1d(n_modes=4, width=8, input_dim=1, output_dim=1)
    
    # 1. 3D Tensor input: (B, N, C) -> (1, 16, 1)
    coarse_3d = torch.randn(1, 16, 1)
    fine_3d = rp.upscale(coarse_3d, model, target_points=32)
    assert fine_3d.shape == (1, 32, 1)
    
    # 2. 2D Tensor input: (N, C) -> (16, 1)
    coarse_2d = torch.randn(16, 1)
    fine_2d = rp.upscale(coarse_2d, model, target_points=32)
    assert fine_2d.shape == (32, 1)
    
    # 3. 1D Tensor input: (N,) -> (16,)
    coarse_1d = torch.randn(16)
    fine_1d = rp.upscale(coarse_1d, model, target_points=32)
    assert fine_1d.shape == (32,)
    
    # 4. Numpy array input
    coarse_np = np.random.randn(16)
    fine_np = rp.upscale(coarse_np, model, target_points=32)
    assert isinstance(fine_np, np.ndarray)
    assert fine_np.shape == (32,)
