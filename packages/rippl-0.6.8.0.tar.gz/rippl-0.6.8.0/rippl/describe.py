"""
rp.describe(): deterministic framework introspection.
No LLM required. Returns structured info about rippl capabilities.
"""
from rippl.core.config import _OPERATORS, _SOLVERS
# We don't have a list_models function in rippl.core.config usually, but the prompt says to use from rippl.registry import list_operators... Wait, the prompt says:
# from rippl.registry import list_operators, list_models, list_solvers
# I'll just use what the prompt provided literally.
from rippl.registry import list_operators, list_models, list_solvers

def describe(query: str = None) -> dict:
    """
    Describe rippl capabilities. No LLM, no network calls.
    
    Args:
        query: optional filter ("operators", "models", "physics",
               "training", "benchmarks", or specific PDE name)
    
    Returns:
        dict of relevant framework information
    
    Examples:
        rp.describe()                    # full overview
        rp.describe("heat")             # heat equation info
        rp.describe("operators")        # all operators
        rp.describe("training")         # training features
    """
    full = {
        "version": _get_version(),
        "operators": list_operators(),
        "models": list_models(),
        "solvers": list_solvers(),
        "training_features": [
            "causal", "adaptive_loss", "hard_bcs",
            "spectral_collocation", "lbfgs_handoff",
            "rar", "conservation_laws", "pareto",
            "self_adaptive_weights", "curriculum",
            "vpinn", "uq_mc_dropout", "uq_ensemble"
        ],
        "pde_families": {
            "heat": "TimeDerivative(1) + Diffusion(alpha)",
            "wave": "TimeDerivative(2) + Laplacian(spatial_dims=1)",
            "burgers": "TimeDerivative(1) + BurgersAdvection() + Diffusion(nu)",
            "poisson": "Laplacian(spatial_dims=2)",
            "helmholtz": "HelmholtzOperator(k=1.0)",
            "stokes": "NavierStokesSystem(rho,mu).build_equation_system()",
            "navier_stokes": "NavierStokesSystem(rho,mu)",
            "elasticity": "LinearElasticitySystem(E,nu)",
            "schrodinger": "SchrodingerSystem(potential_fn)",
            "allen_cahn": "AllenCahnOperator(M,epsilon)",
            "cahn_hilliard": "CahnHilliardOperator(M,epsilon)",
            "turing": "TuringSystem(**TuringSystem.SPOTS)",
            "eikonal": "EikonalOperator(speed_fn)",
            "fractional": "FractionalLaplacian(alpha=0.5)",
            "fokker_planck": "FokkerPlanckEquation(drift_fn, diffusion)",
        },
        "benchmarks": {
            "heat_1d":    {"l2": 3.80e-4, "status": "PASS"},
            "wave_1d":    {"l2": 8.38e-5, "status": "PASS"},
            "burgers":    {"l2": 5.55e-4, "status": "PASS"},
            "schrodinger":{"l2": 3.04e-4, "status": "PASS"},
            "eikonal_2d": {"l2": 1.35e-4, "status": "PASS"},
            "stokes_1d":  {"l2_u": 7.64e-3, "l2_p": 8.13e-2, "status": "PASS"},
            "digital_twin":{"alpha_error": "3.21%", "status": "PASS"},
            "uq":         {"ci_coverage": "100%", "status": "PASS"},
            "csg_annulus":{"l2": 4.70e-5, "status": "PASS"},
        },
        "quick_start": '''
import rippl as rp
import rippl.nn as rnn
from rippl.core.system import System, Domain, Constraint
from rippl.core.equation import Equation
from rippl.physics.operators import TimeDerivative, Diffusion
import torch, math

domain = Domain(spatial_dims=1, bounds=[(0,1),(0,1)])
equation = Equation([TimeDerivative(1), Diffusion(alpha=0.1)])
x_ic = torch.rand(2000,1)
coords_ic = torch.cat([x_ic, torch.zeros(2000,1)], dim=1)
u_ic = torch.sin(math.pi*x_ic)
constraints = [Constraint(type="initial", field="u",
                           coords=coords_ic, value=u_ic)]
model = rp.compile(rnn.MLP(in_dim=2, out_dim=1))
result = rp.run(domain, equation, model,
                causal=True, adaptive_loss=True, hard_bcs=True)
'''
    }

    if query is None:
        return full

    query = query.lower()
    if query == "operators":
        return {"operators": full["operators"]}
    if query == "models":
        return {"models": full["models"],
                "note": "All return raw nn.Module — engine is architecture-blind"}
    if query == "training":
        return {"training_features": full["training_features"]}
    if query == "benchmarks":
        return {"benchmarks": full["benchmarks"]}

    # PDE lookup
    for name, recipe in full["pde_families"].items():
        if query in name or name in query:
            return {
                "pde": name,
                "recipe": recipe,
                "benchmark": full["benchmarks"].get(name, "not benchmarked"),
                "quick_start": full["quick_start"]
            }

    return {"query": query, "result": "not found",
            "available": list(full["pde_families"].keys())}


def _get_version():
    try:
        import rippl
        return getattr(rippl, "__version__", "0.6.0")
    except Exception:
        return "unknown"
