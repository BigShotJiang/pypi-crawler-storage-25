"""
rippl: Datasets Package
"""
from rippl.datasets.generators import generate_sine_wave, generate_gaussian_bump

__all__ = ["generate_sine_wave", "generate_gaussian_bump"]
