"""
Parser context and token stream abstractions.

Token types follow the minimal YANG grammar (meta-model-grammar.ebnf).
"""

from enum import Enum
from pathlib import Path
from types import SimpleNamespace
from typing import List, Tuple, Optional, TYPE_CHECKING, Union
from dataclasses import dataclass
from ..errors import YangSyntaxError

if TYPE_CHECKING:
    from ..module import YangModule
    from ..ast import (
        YangStatement,
        YangStatementList,
        YangTypeStmt,
        YangMustStmt,
        YangWhenStmt,
    )


# Type for parser context parent: statement lists or nested statement contexts (type/must/when)
_ParserParent = Union[
    "YangStatementList",
    "YangTypeStmt",
    "YangMustStmt",
    "YangWhenStmt",
    SimpleNamespace,
]


class YangTokenType(Enum):
    """Token types from the YANG grammar (meta-model-grammar.ebnf)."""

    # Punctuation
    LBRACE = "{"
    RBRACE = "}"
    SEMICOLON = ";"
    COLON = ":"
    EQUALS = "="
    PLUS = "+"
    SLASH = "/"

    # Literals (value is lexeme)
    STRING = "STRING"
    IDENTIFIER = "IDENTIFIER"
    INTEGER = "INTEGER"
    # Unquoted \d+(\.\d+)+ — e.g. yang-version 1.1; not an identifier per RFC 7950.
    DOTTED_NUMBER = "DOTTED_NUMBER"

def diagnostic_source_lines(content: str) -> List[str]:
    """Split source on newlines for error snippets (verbatim text, comments included)."""
    if not content:
        return []
    return [segment.rstrip("\r") for segment in content.split("\n")]


@dataclass
class Token:
    """A token with position information."""
    value: str
    line_num: int
    char_pos: int


@dataclass
class YangToken:
    """A YANG token: type (from grammar) and value (lexeme), with position."""
    type: YangTokenType
    value: str
    line_num: int
    char_pos: int


class TokenStream:
    """Abstraction over token list with position tracking."""

    def __init__(
        self,
        token_list: List[YangToken],
        source: str,
        filename: Optional[str] = None,
    ):
        self._token_list = token_list
        self.tokens = [t.value for t in token_list]
        self.positions = [(t.line_num, t.char_pos) for t in token_list]
        self._source = source
        self._diagnostic_lines: Optional[List[str]] = None
        self.filename = filename
        self.index = 0

    def peek_token(self) -> Optional[YangToken]:
        """Peek at current token without consuming."""
        if self.index < len(self._token_list):
            return self._token_list[self.index]
        return None

    def peek(self) -> Optional[str]:
        """Peek at current token value without consuming."""
        tok = self.peek_token()
        return tok.value if tok else None

    def consume(self, expected: Optional[str] = None) -> str:
        """Consume current token, optionally checking it matches expected."""
        if self.index >= len(self.tokens):
            raise self._make_error("Unexpected end of input")

        token_val = self.tokens[self.index]
        if expected is not None and token_val != expected:
            raise self._make_error(f"Expected {expected!r}, got {token_val!r}")

        self.index += 1
        return token_val

    def consume_if(self, expected: str) -> bool:
        """Consume token if it matches expected, return True if consumed."""
        if self.peek() == expected:
            self.consume()
            return True
        return False

    def peek_type(self) -> YangTokenType:
        """Peek at current token type without consuming. Raises at end of input."""
        if self.index >= len(self._token_list):
            raise self._make_error("Unexpected end of input")
        return self._token_list[self.index].type

    def peek_type_at(self, offset: int = 0) -> Optional[YangTokenType]:
        """Peek token type at ``index + offset`` without consuming."""
        i = self.index + offset
        if i < len(self._token_list):
            return self._token_list[i].type
        return None

    def consume_type(self, expected: Union[YangTokenType, str]) -> str:
        """Consume current token if token kind matches ``expected``; return value."""
        if self.index >= len(self._token_list):
            raise self._make_error("Unexpected end of input")
        tok = self._token_list[self.index]
        if isinstance(expected, str):
            if tok.type != YangTokenType.IDENTIFIER or tok.value != expected:
                got = tok.value if tok.type == YangTokenType.IDENTIFIER else tok.type.name
                raise self._make_error(f"Expected {expected!r}, got {got!r}")
        elif tok.type != expected:
            raise self._make_error(
                f"Expected {expected.name}, got {tok.type.name} ({tok.value!r})"
            )
        self.index += 1
        return tok.value

    def consume_if_type(self, expected: Union[YangTokenType, str]) -> bool:
        """Consume token if it matches ``expected``, return True if consumed."""
        if self.index >= len(self._token_list):
            return False
        tok = self._token_list[self.index]
        if isinstance(expected, str):
            if tok.type != YangTokenType.IDENTIFIER or tok.value != expected:
                return False
        elif tok.type != expected:
            return False
        self.consume_type(expected)
        return True

    def consume_oneof(
        self, allowed_types: List[Union[YangTokenType, str]]
    ) -> Tuple[str, Union[YangTokenType, str]]:
        """Consume current token if it matches one of allowed kinds; return (value, matched)."""
        if self.index >= len(self._token_list):
            raise self._make_error("Unexpected end of input")
        tok = self._token_list[self.index]
        for allowed in allowed_types:
            if isinstance(allowed, str):
                if tok.type == YangTokenType.IDENTIFIER and tok.value == allowed:
                    self.index += 1
                    return (tok.value, allowed)
            elif tok.type == allowed:
                self.index += 1
                return (tok.value, allowed)
        names = ", ".join(t if isinstance(t, str) else t.name for t in allowed_types)
        got = tok.value if tok.type == YangTokenType.IDENTIFIER else tok.type.name
        raise self._make_error(f"Expected one of ({names}), got {got!r}")

    def has_more(self) -> bool:
        """Check if there are more tokens."""
        return self.index < len(self.tokens)

    def position(self) -> Tuple[int, int]:
        """Get current position (line_num, char_pos)."""
        if self.index < len(self.positions):
            return self.positions[self.index]
        if self.positions:
            return self.positions[-1]
        return (1, 0)
    
    def _diagnostic_lines_once(self) -> List[str]:
        """Build per-line source text for errors (lazy, at most once per stream)."""
        if self._diagnostic_lines is None:
            self._diagnostic_lines = diagnostic_source_lines(self._source)
        return self._diagnostic_lines

    def make_error(self, message: str, context_lines: int = 3) -> YangSyntaxError:
        """Create a syntax error at current position."""
        return self._make_error(message, context_lines)

    def _make_error(self, message: str, context_lines: int = 3) -> YangSyntaxError:
        """Create a syntax error at current position (internal; prefer :meth:`make_error`)."""
        line_num, _ = self.position()
        lines = self._diagnostic_lines_once()

        context = []
        start_line = max(1, line_num - context_lines)
        end_line = min(len(lines), line_num + context_lines)

        for ctx_line_num in range(start_line, end_line + 1):
            if ctx_line_num <= len(lines):
                context.append((ctx_line_num, lines[ctx_line_num - 1]))

        line = lines[line_num - 1] if line_num <= len(lines) else ""
        
        return YangSyntaxError(
            message=message,
            line_num=line_num,
            line=line,
            context_lines=context,
            filename=self.filename
        )


@dataclass
class ParserContext:
    """Context for parsing, holds module and current state."""
    module: "YangModule"
    current_parent: _ParserParent
    # Directory of the file being parsed (for resolving include of submodules).
    source_dir: Optional[Path] = None

    def push_parent(self, parent: _ParserParent) -> "ParserContext":
        """Create new context with updated parent."""
        return ParserContext(
            module=self.module, current_parent=parent, source_dir=self.source_dir
        )
