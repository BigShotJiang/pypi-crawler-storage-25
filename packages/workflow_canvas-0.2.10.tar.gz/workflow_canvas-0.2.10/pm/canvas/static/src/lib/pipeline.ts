/**
 * Shared pipeline export, import, run, and polling logic.
 * Extracted from Toolbar.svelte so DevToolbar can reuse it.
 */
import { get } from 'svelte/store';
import { nodes, edges, runState, pipelineName, clearRunState, setNodeRunStatus, setPipelineError, resetNodeCounter, modules } from './stores.js';
import type { PipelineJSON, CanvasNodeData, MethodDef, PipelineError } from './types.js';
import type { Node, Edge } from '@xyflow/svelte';
// The pure compile/parse functions live in `compile.ts` so Node-based
// regression tests (tests/test_canvas_compile_ts.py) can import them
// without pulling in the svelte-store runtime.
import {
  compilePipelineToJSON as _compilePipelineToJSON,
  parsePipelineJSON as _parsePipelineJSON,
  type AuthoringState as _AuthoringState,
} from './compile.js';

// ---------- Poll timer (module-level) ----------
let pollTimer: ReturnType<typeof setInterval> | null = null;

// ---------- Re-exports from the pure compile module ----------

// Preserve the historical `pipeline.ts` import surface used elsewhere in
// the canvas.  The implementations live in `./compile.ts` so a Node-based
// regression test can import them without the svelte-store runtime.
export type AuthoringState = _AuthoringState;
export const compilePipelineToJSON = _compilePipelineToJSON;
export const parsePipelineJSON = _parsePipelineJSON;

// ---------- Export (svelte-store glue) ----------

export function exportPipeline(): PipelineJSON {
  const $nodes = get(nodes);
  const $edges = get(edges);
  const $name = get(pipelineName);
  const inputSelectorSamples = $nodes
    .filter(n => n.data.nodeType === 'input_selector')
    .flatMap(n => n.data.selectedSamples ?? []);
  const datasourceNode = $nodes.find(n => n.data.datasource);
  const samples = inputSelectorSamples.length > 0
    ? inputSelectorSamples
    : datasourceNode?.data.datasource ? [datasourceNode.data.datasource] : [];
  return compilePipelineToJSON({
    name: $name,
    nodes: $nodes,
    edges: $edges,
    samples,
  });
}

// ---------- Import / Load ----------

/** Look up a method's slot definitions from the modules store. */
function findMethodDef(moduleName: string, methodName: string): MethodDef | undefined {
  const $modules = get(modules);
  const mod = $modules.find(m => m.name === moduleName);
  return mod?.methods.find(m => m.name === methodName);
}

export function loadPipeline(pipeline: PipelineJSON): void {
  if (pipeline.name) pipelineName.set(pipeline.name);
  let maxId = 0;
  const { nodeVariants, nodeSampleOverrides, nodeSampleVariants } = parsePipelineJSON(pipeline);
  const newNodes: Node<CanvasNodeData>[] = pipeline.nodes.map(pn => {
    const numId = parseInt(pn.id.replace('node_', ''));
    if (!isNaN(numId) && numId > maxId) maxId = numId;
    const nodeType = pn.type || 'method';

    if (nodeType === 'input_selector') {
      return {
        id: pn.id,
        type: 'custom',
        position: pn.position ?? { x: Math.random() * 600, y: Math.random() * 400 },
        data: {
          label: 'Input Selector',
          method: '',
          module: '',
          color: '#1ABC9C',
          inputs: [],
          outputs: [{ name: 'output', type: 'csv' }],
          params: [],
          paramValues: {},
          runStatus: 'idle' as const,
          expanded: false,
          nodeType: 'input_selector' as const,
          selectedSamples: pn.samples ?? [],
          fanMode: ((pn as { fan_mode?: string }).fan_mode === 'in' ? 'in' : 'out') as 'in' | 'out',
          // Persist the per-selector keep-going toggle. Default true for
          // fan-out (per-sample independence), false for fan-in (single
          // bundled job — flag is a no-op). Missing value on the incoming
          // JSON is interpreted the same as "defaults to true for fan-out".
          keepGoing:
            (pn as { keep_going?: boolean }).keep_going !== undefined
              ? !!(pn as { keep_going?: boolean }).keep_going
              : ((pn as { fan_mode?: string }).fan_mode !== 'in'),
          inputCollapsed: false,
        },
      };
    } else if (nodeType === 'run_reference') {
      return {
        id: pn.id,
        type: 'custom',
        position: pn.position ?? { x: Math.random() * 600, y: Math.random() * 400 },
        data: {
          label: 'Run Reference',
          method: '',
          module: '',
          color: '#1ABC9C',
          inputs: [],
          outputs: [{ name: 'output', type: 'csv' }],
          params: [],
          paramValues: {},
          runStatus: 'idle' as const,
          expanded: false,
          nodeType: 'run_reference' as const,
          selectedRunId: pn.run_id,
          selectedOutputSlot: pn.output_slot,
        },
      };
    } else {
      // Method node — look up real slot definitions from modules store
      const methodDef = findMethodDef(pn.module ?? '', pn.method);
      return {
        id: pn.id,
        type: 'custom',
        position: pn.position ?? { x: Math.random() * 600, y: Math.random() * 400 },
        data: {
          label: pn.method || pn.id,
          method: pn.method,
          module: pn.module ?? '',
          color: methodDef?.color ?? '#2ecc71',
          inputs: methodDef?.inputs ?? [{ name: 'data', type: 'csv' }],
          outputs: methodDef?.outputs ?? [{ name: 'output', type: 'csv' }],
          params: methodDef?.params ?? [],
          paramValues: pn.params ?? {},
          runStatus: 'idle' as const,
          expanded: false,
          nodeType: 'method' as const,
          datasource: pipeline.samples?.[0],
          variants: nodeVariants[pn.id],
          sampleOverrides: nodeSampleOverrides[pn.id],
          sampleVariants: nodeSampleVariants[pn.id],
        },
      };
    }
  });
  const newEdges: Edge[] = pipeline.links.map((ln, i) => ({
    id: `e_${i}`,
    type: 'deletable',
    source: ln.source,
    target: ln.target,
    sourceHandle: ln.sourceHandle ?? null,
    targetHandle: ln.targetHandle ?? null,
  }));
  resetNodeCounter(maxId);
  nodes.set(newNodes);
  edges.set(newEdges);
  clearRunState();
}

// ---------- Run ----------

export async function runPipeline(): Promise<void> {
  const pipeline = exportPipeline();
  // Clear any stale pipeline-level error from a previous run so the banner
  // doesn't linger past the user clicking Run again.
  setPipelineError(null);
  // Validate first
  try {
    const vResp = await fetch('/api/workflow/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(pipeline),
    });
    const vResult = await vResp.json();
    if (!vResult.valid) {
      setPipelineError({
        message: 'Cannot run — validation errors:\n' + (vResult.errors ?? []).join('\n'),
        kind: 'not_found',
      });
      return;
    }
  } catch { /* skip validation if endpoint unavailable */ }

  // Set all nodes to pending
  get(nodes).forEach(n => setNodeRunStatus(n.id, 'pending'));
  runState.update(rs => ({ ...rs, running: true }));

  // keep_going lives on the input_selector (the sole fan-out mechanism in
  // this system). Read the first fan-out selector's toggle — default true
  // for fan-out, false for fan-in since there's no per-sample job to keep
  // going around when everything's bundled.
  let keepGoing = false;
  for (const n of get(nodes)) {
    if (n.data.nodeType !== 'input_selector') continue;
    const fanOut = (n.data.fanMode ?? 'out') === 'out';
    if (fanOut) {
      keepGoing = n.data.keepGoing ?? true;
      break;
    }
  }
  const body = { ...pipeline, keep_going: keepGoing };

  try {
    const resp = await fetch('/api/workflow/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const result = await resp.json();
    if (!resp.ok) {
      // 4xx/5xx before the job even launched — e.g. empty pipeline (400).
      // Surface it as a pipeline error so the canvas banner picks it up
      // instead of the old silent alert().
      runState.update(rs => ({ ...rs, running: false }));
      setPipelineError({
        message: typeof result?.detail === 'string'
          ? result.detail
          : `Run request failed (HTTP ${resp.status})`,
        kind: 'unknown',
      });
      return;
    }
    runState.update(rs => ({ ...rs, jobId: result.job_id }));
    startPolling(result.job_id);
  } catch (err) {
    runState.update(rs => ({ ...rs, running: false }));
    setPipelineError({ message: `Run request failed: ${String(err)}`, kind: 'unknown' });
  }
}

// ---------- Polling ----------

export function startPolling(jobId: string): void {
  stopPolling();
  pollTimer = setInterval(async () => {
    try {
      const resp = await fetch(`/api/workflow/status/${jobId}`);
      const result = await resp.json();

      if (result.node_states) {
        for (const [nodeId, state] of Object.entries(result.node_states)) {
          const s = state as { status: string; error?: string; tally?: any; run_ids?: string[] };
          setNodeRunStatus(nodeId, s.status as any, s.error, s.tally, s.run_ids);
        }
      }

      // Pipeline-level error from _run_in_background — surfaces DirtyRepo,
      // malformed env specs, missing methods, pixi-lock lookup failures, etc.
      // Backend stores these as {kind, message, hint}; legacy plain strings
      // (pre-structured) are accepted too so older code paths still render.
      if (result.error) {
        const raw = result.error;
        const err: PipelineError = typeof raw === 'string'
          ? { message: raw, kind: 'unknown' }
          : { message: raw.message ?? String(raw), kind: raw.kind, hint: raw.hint };
        setPipelineError(err);
      }

      const overall = result.overall_status;
      // completed_with_failures is terminal too: some fan-out samples
      // failed but nothing is still running. Stop polling and refresh.
      if (
        overall === 'completed' ||
        overall === 'failed' ||
        overall === 'completed_with_failures'
      ) {
        stopPolling();
        runState.update(rs => ({ ...rs, running: false }));
        try { await fetch('/api/pm/refresh', { method: 'POST' }); } catch {}
      }
    } catch {
      stopPolling();
      runState.update(rs => ({ ...rs, running: false }));
    }
  }, 2500);
}

export function stopPolling(): void {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}
