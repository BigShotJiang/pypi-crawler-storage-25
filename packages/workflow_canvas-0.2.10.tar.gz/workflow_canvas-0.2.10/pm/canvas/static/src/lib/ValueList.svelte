<script lang="ts">
  /**
   * Unified per-param value list for the Inspector.
   *
   * Replaces the old base-input + ChipEditor pair. Renders a single box
   * when the param has only its base value; morphs into a multi-row
   * table-ish layout when variants are added. Every row is semantically
   * equivalent — the "default" concept is gone from the UI. Internally,
   * variants still live in a `{v1: x, v2: y}` dict keyed by the shape
   * the engine expects; the UI hides those names.
   *
   * Each row has two states: locked (committed, 🔒) or editing (🔓).
   * Editing requires an explicit ✓ / Enter / Ctrl+Enter to commit;
   * blur-away discards the local edit. A global `commitAllSignal`
   * store triggers every mounted instance to commit its dirty rows.
   */
  import type { ContractType, ParamDef } from './types.js';
  import { commitAllSignal, markDirty } from './stores.js';

  let {
    nodeId,
    param,
    baseValue,
    variants = {},
    onBaseChange,
    onVariantsChange,
    singleValue = false,
    dirtyKeySuffix = '',
  }: {
    nodeId: string;
    param: ParamDef;
    baseValue: unknown;
    variants?: Record<string, unknown>;
    onBaseChange: (value: unknown) => void;
    onVariantsChange?: (next: Record<string, unknown>) => void;
    /** When true: no variants, no + variant button, no row delete. Used for per-sample overrides. */
    singleValue?: boolean;
    /** Disambiguate dirty-state keys when the same (node, param) is rendered twice (e.g. per-sample tab). */
    dirtyKeySuffix?: string;
  } = $props();

  // Type flags must be reactive. Svelte reuses this component instance across
  // {#each data.params} iterations when the selected node changes, so plain
  // `const` flags captured at mount would render a toggle for a boolean
  // param and validate it as a number when the inspector is later pointed
  // at a number param in the same slot.
  let ct = $derived<ContractType>((param.contractType ?? 'unknown') as ContractType);
  let isBoolean = $derived(param.type === 'boolean' || ct === 'bool');
  let isEnum = $derived(!!(param.constraints?.enum && param.constraints.enum.length > 0));
  let isNumber = $derived(param.type === 'number' || ct === 'int' || ct === 'float');
  let isJson = $derived(ct === 'list' || ct === 'dict' || param.type === 'list' || param.type === 'dict');
  let isString = $derived(!isBoolean && !isEnum && !isNumber && !isJson);
  let listDictDisabled = $derived(ct === 'list' || ct === 'dict');

  let dirtyKey = $derived(`${nodeId}::${param.name}${dirtyKeySuffix}`);

  type Row = { id: string; variantName: string | null; isBase: boolean };
  let variantOrder = $derived(singleValue ? [] : Object.keys(variants).sort(lexVariantCmp));
  let rows = $derived<Row[]>([
    { id: 'base', variantName: null, isBase: true },
    ...variantOrder.map(vn => ({ id: `v:${vn}`, variantName: vn, isBase: false })),
  ]);

  // Per-row edit state. Keyed by row id only ("base" / "v:<name>"), so these
  // maps must be wiped whenever the (node, param) identity changes — otherwise
  // the previous node's editing flag, in-progress text, and validation error
  // bleed onto the new node's param in the same slot.
  let editing = $state<Record<string, boolean>>({});
  let localValue = $state<Record<string, string | boolean>>({});
  let errorMsg = $state<Record<string, string | null>>({});
  let expanded = $state<Record<string, boolean>>({});

  let prevIdentity = '';
  $effect(() => {
    const cur = dirtyKey;
    if (cur !== prevIdentity) {
      prevIdentity = cur;
      editing = {};
      localValue = {};
      errorMsg = {};
      expanded = {};
    }
  });

  // Dirty = any row currently in edit mode.
  let isDirty = $derived(Object.values(editing).some(v => v));
  $effect(() => {
    const key = dirtyKey;
    markDirty(key, isDirty);
    return () => markDirty(key, false);
  });

  // React to global "commit all dirty rows" pulses.
  let lastSignal = 0;
  $effect(() => {
    const sig = $commitAllSignal;
    if (sig !== lastSignal) {
      lastSignal = sig;
      commitAllDirty();
    }
  });

  // Rows default to unlocked (editable) on first mount. Committing (✓) locks
  // them; re-editing requires an explicit unlock click. Using `=== undefined`
  // as the gate so committed/cancelled rows stay locked and aren't re-opened.
  $effect(() => {
    for (const row of rows) {
      if (editing[row.id] === undefined) startEdit(row);
    }
  });

  function committedValueFor(row: Row): unknown {
    if (row.isBase) return baseValue;
    return variants[row.variantName!];
  }

  function displayValue(v: unknown): string {
    if (v === undefined || v === null) return '';
    if (typeof v === 'boolean') return v ? 'true' : 'false';
    if (isJson || (typeof v === 'object' && v !== null)) {
      try { return JSON.stringify(v); } catch { return String(v); }
    }
    return String(v);
  }

  function coerce(raw: string | boolean): { ok: true; value: unknown } | { ok: false; error: string } {
    if (typeof raw === 'boolean') return { ok: true, value: raw };
    if (isBoolean) {
      const lc = String(raw).trim().toLowerCase();
      if (lc === 'true' || lc === '1') return { ok: true, value: true };
      if (lc === 'false' || lc === '0') return { ok: true, value: false };
      return { ok: false, error: `Expected bool; got "${raw}".` };
    }
    if (isNumber) {
      if (ct === 'int') {
        if (!/^-?\d+$/.test(String(raw).trim())) return { ok: false, error: `Expected int; got "${raw}".` };
        const n = parseInt(String(raw), 10);
        if (Number.isNaN(n)) return { ok: false, error: `Expected int; got "${raw}".` };
        return constrain(n);
      }
      const n = parseFloat(String(raw));
      if (Number.isNaN(n)) return { ok: false, error: `Expected number; got "${raw}".` };
      return constrain(n);
    }
    if (isJson) {
      const s = String(raw).trim();
      if (s === '') {
        if (param.required) return { ok: false, error: 'Value cannot be empty.' };
        return { ok: true, value: ct === 'list' || param.type === 'list' ? [] : {} };
      }
      try {
        const parsed = JSON.parse(s);
        const wantList = ct === 'list' || param.type === 'list';
        const wantDict = ct === 'dict' || param.type === 'dict';
        if (wantList && !Array.isArray(parsed)) return { ok: false, error: 'Expected JSON array.' };
        if (wantDict && (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed))) {
          return { ok: false, error: 'Expected JSON object.' };
        }
        return { ok: true, value: parsed };
      } catch (e) {
        return { ok: false, error: `Invalid JSON: ${(e as Error).message}` };
      }
    }
    // string / enum / unknown
    const s = String(raw);
    if (param.required && s === '') return { ok: false, error: 'Value cannot be empty.' };
    return { ok: true, value: s };
  }

  function constrain(n: number): { ok: true; value: number } | { ok: false; error: string } {
    const c = param.constraints ?? {};
    if (c.min !== undefined && n < c.min) return { ok: false, error: `Must be ≥ ${c.min}.` };
    if (c.max !== undefined && n > c.max) return { ok: false, error: `Must be ≤ ${c.max}.` };
    return { ok: true, value: n };
  }

  function nextVariantName(): string {
    const existing = Object.keys(variants);
    let n = existing.length + 1;
    while (existing.includes(`v${n}`)) n += 1;
    return `v${n}`;
  }

  function lexVariantCmp(a: string, b: string): number {
    // Natural sort for v1, v2, v10 so the UI row order matches what users expect.
    const am = a.match(/^v(\d+)$/);
    const bm = b.match(/^v(\d+)$/);
    if (am && bm) return parseInt(am[1], 10) - parseInt(bm[1], 10);
    return a.localeCompare(b);
  }

  function startEdit(row: Row): void {
    const committed = committedValueFor(row);
    editing[row.id] = true;
    if (isBoolean) {
      localValue[row.id] = typeof committed === 'boolean' ? committed : false;
    } else {
      localValue[row.id] = displayValue(committed);
    }
    errorMsg[row.id] = null;
  }

  function cancelEdit(row: Row): void {
    editing[row.id] = false;
    delete localValue[row.id];
    errorMsg[row.id] = null;
  }

  function commit(row: Row): boolean {
    const raw = localValue[row.id];
    const result = coerce(raw);
    if (!result.ok) {
      errorMsg[row.id] = result.error;
      return false;
    }
    errorMsg[row.id] = null;
    if (row.isBase) {
      onBaseChange(result.value);
    } else {
      const next = { ...variants, [row.variantName!]: result.value };
      onVariantsChange(next);
    }
    editing[row.id] = false;
    delete localValue[row.id];
    return true;
  }

  function commitAllDirty(): void {
    for (const row of rows) {
      if (editing[row.id]) commit(row); // failures stay dirty with errorMsg set
    }
  }

  function addVariant(): void {
    if (singleValue || listDictDisabled || !onVariantsChange) return;
    const vn = nextVariantName();
    const next = { ...variants, [vn]: '' };
    onVariantsChange(next);
    const rowId = `v:${vn}`;
    editing[rowId] = true;
    localValue[rowId] = isBoolean ? false : '';
    errorMsg[rowId] = null;
  }

  function deleteVariant(row: Row): void {
    if (row.isBase || !onVariantsChange) return;
    const next = { ...variants };
    delete next[row.variantName!];
    onVariantsChange(next);
    editing[row.id] = false;
    delete localValue[row.id];
    delete errorMsg[row.id];
    delete expanded[row.id];
  }

  function toggleExpand(row: Row): void {
    expanded[row.id] = !expanded[row.id];
  }

  function handleKeydown(row: Row, e: KeyboardEvent): void {
    const isTextarea = (e.currentTarget as HTMLElement).tagName === 'TEXTAREA';
    if (e.key === 'Enter' && (isTextarea ? e.ctrlKey : true)) {
      e.preventDefault();
      commit(row);
    } else if (e.key === 'Escape') {
      cancelEdit(row);
    }
  }

  function rowValueForDisplay(row: Row): string {
    return displayValue(committedValueFor(row));
  }

  // True when the layout should be the single-row simple box.
  let isSingleRow = $derived(rows.length === 1);
</script>

<div class="value-list">
  <div class:single-box={isSingleRow} class:multi-box={!isSingleRow}>
    {#each rows as row (row.id)}
      {@const isEditing = !!editing[row.id]}
      {@const isExpanded = !!expanded[row.id]}
      {@const rowError = errorMsg[row.id]}
      <div class="row" class:editing={isEditing} class:invalid={!!rowError}>
        <div class="gutter" title={isEditing ? 'unlocked' : 'locked in'}>
          {isEditing ? '🔓' : '🔒'}
        </div>

        <div class="widget">
          {#if isBoolean}
            {#if isEditing}
              <button type="button" class="toggle" class:on={localValue[row.id] === true}
                onclick={() => localValue[row.id] = !localValue[row.id]}
                aria-label="toggle">
                <span class="knob"></span>
              </button>
              <span class="toggle-label">{localValue[row.id] === true ? 'true' : 'false'}</span>
            {:else}
              <span class="toggle locked" class:on={committedValueFor(row) === true}>
                <span class="knob"></span>
              </span>
              <span class="toggle-label">{committedValueFor(row) === true ? 'true' : 'false'}</span>
            {/if}
          {:else if isEnum}
            {#if isEditing}
              <select class="enum"
                value={localValue[row.id] ?? ''}
                onchange={(e) => localValue[row.id] = (e.currentTarget as HTMLSelectElement).value}
                onkeydown={(e) => handleKeydown(row, e)}>
                <option value="" disabled>-- pick --</option>
                {#each param.constraints!.enum! as opt}
                  <option value={opt} selected={localValue[row.id] === opt}>{opt}</option>
                {/each}
              </select>
            {:else}
              <span class="readonly">{rowValueForDisplay(row) || '—'}</span>
            {/if}
          {:else if isString && isExpanded}
            {#if isEditing}
              <textarea class="multi"
                value={localValue[row.id] as string}
                oninput={(e) => localValue[row.id] = (e.currentTarget as HTMLTextAreaElement).value}
                onkeydown={(e) => handleKeydown(row, e)}
                rows="4" autofocus></textarea>
            {:else}
              <textarea class="multi" readonly value={rowValueForDisplay(row)} rows="4"></textarea>
            {/if}
          {:else}
            {#if isEditing}
              <input class="text"
                type={isNumber ? 'number' : 'text'}
                value={localValue[row.id] as string}
                oninput={(e) => localValue[row.id] = (e.currentTarget as HTMLInputElement).value}
                onkeydown={(e) => handleKeydown(row, e)}
                placeholder={param.default !== undefined ? displayValue(param.default) : (isNumber ? 'number' : 'value')}
                autofocus />
            {:else}
              <input class="text" readonly value={rowValueForDisplay(row)} />
            {/if}
          {/if}
        </div>

        <div class="actions">
          {#if isString}
            <button type="button" class="act expand" onclick={() => toggleExpand(row)}
              title={isExpanded ? 'collapse' : 'expand to multi-line'}>{isExpanded ? '⤡' : '⤢'}</button>
          {/if}
          {#if isEditing}
            <button type="button" class="act commit" onclick={() => commit(row)}
              title={rowError ?? 'commit (Enter)'}>✓</button>
          {:else}
            <button type="button" class="act edit" onclick={() => startEdit(row)}
              title="unlock to edit">✎</button>
          {/if}
          {#if !row.isBase}
            <button type="button" class="act delete" onclick={() => deleteVariant(row)}
              title="remove variant">×</button>
          {:else}
            <span class="act-spacer"></span>
          {/if}
        </div>
      </div>

      {#if rowError}
        <div class="row-error">{rowError}</div>
      {/if}
    {/each}

    {#if !isSingleRow && !singleValue}
      <button type="button" class="add-variant-inline" onclick={addVariant}
        disabled={listDictDisabled}
        title={listDictDisabled ? 'List/dict params cannot be swept' : 'add another value'}>+ variant</button>
    {/if}
  </div>

  {#if isSingleRow && !singleValue}
    <button type="button" class="add-variant-btn" onclick={addVariant}
      disabled={listDictDisabled}
      title={listDictDisabled ? 'List/dict params cannot be swept' : 'add another value'}>+ variant</button>
  {/if}
</div>

<style>
  .value-list { width: 100%; }

  .single-box, .multi-box {
    border: 1px solid #3e3e42;
    border-radius: 4px;
    overflow: hidden;
    background: #1e1e1e;
  }

  .row {
    display: grid;
    grid-template-columns: 28px 1fr auto;
    align-items: stretch;
  }
  .multi-box .row + .row { border-top: 1px solid #2a2a2d; }
  .row.invalid .gutter { color: #E74C3C; }

  .gutter {
    display: flex; align-items: center; justify-content: center;
    font-size: 12px; background: #1b1b1d;
    border-right: 1px solid #2a2a2d;
    color: #6aa84f;
  }
  .row.editing .gutter { color: #E0B040; }

  .widget {
    display: flex; align-items: center; gap: 8px;
    padding: 0 8px; min-height: 32px;
  }
  .widget .readonly {
    color: #aaa; font-family: Consolas, monospace; font-size: 12px;
  }

  input.text {
    background: transparent; border: none; outline: none;
    color: #ddd; width: 100%; padding: 6px 0;
    font-family: Consolas, monospace; font-size: 12px;
    box-sizing: border-box; min-height: 30px;
  }
  input.text:read-only { color: #aaa; }
  input.text[type=number]::-webkit-inner-spin-button,
  input.text[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none; margin: 0;
  }
  input.text[type=number] { -moz-appearance: textfield; }

  textarea.multi {
    background: transparent; border: none; outline: none;
    color: #ddd; width: 100%; padding: 6px 0;
    font-family: Consolas, monospace; font-size: 12px;
    box-sizing: border-box; resize: none; line-height: 1.4;
  }
  textarea.multi:read-only { color: #aaa; }

  select.enum {
    background: #1e1e1e; border: 1px solid #2a2a2d; outline: none;
    color: #ddd; width: 100%; padding: 5px 8px; min-height: 30px;
    font-family: Consolas, monospace; font-size: 12px;
    appearance: none; -webkit-appearance: none;
    padding-right: 22px;
    background-image:
      linear-gradient(45deg, transparent 50%, #888 50%),
      linear-gradient(135deg, #888 50%, transparent 50%);
    background-position: calc(100% - 12px) 50%, calc(100% - 7px) 50%;
    background-size: 5px 5px; background-repeat: no-repeat;
  }

  /* toggle */
  button.toggle, span.toggle {
    position: relative; display: inline-block;
    width: 32px; height: 18px; background: #3e3e42;
    border-radius: 10px; cursor: pointer; border: none; padding: 0;
    transition: background .15s;
  }
  button.toggle.on, span.toggle.on { background: #2d5a2d; }
  span.toggle.locked { cursor: default; }
  .toggle .knob {
    position: absolute; top: 2px; left: 2px;
    width: 14px; height: 14px; background: #888;
    border-radius: 50%; transition: .15s;
  }
  .toggle.on .knob { left: 16px; background: #6aa84f; }
  .toggle-label {
    color: #ccc; font-size: 12px; font-family: Consolas, monospace;
  }

  .actions {
    display: flex; align-items: stretch;
  }
  .act {
    display: flex; align-items: center; justify-content: center;
    background: transparent; border: none; cursor: pointer;
    font-size: 12px; color: #888; width: 28px; padding: 0;
  }
  .act.edit:hover { color: #4A90D9; }
  .act.commit { color: #6aa84f; font-size: 13px; }
  .act.commit:hover { color: #88c864; }
  .act.delete { color: #555; font-size: 14px; }
  .act.delete:hover { color: #E74C3C; }
  .act.expand:hover { color: #4A90D9; }
  .act-spacer { width: 28px; }

  .row-error {
    padding: 4px 8px 6px 36px;
    font-size: 11px; color: #E74C3C;
    background: #1e1e1e; border-top: 1px solid #2a2a2d;
  }

  .add-variant-btn {
    margin-top: 6px; background: transparent; color: #888;
    border: 1px dashed #3e3e42; border-radius: 4px;
    width: 100%; padding: 6px 8px; font-size: 11px;
    cursor: pointer; font-family: inherit;
  }
  .add-variant-btn:hover:not(:disabled) { color: #ccc; border-color: #555; }
  .add-variant-btn:disabled { color: #444; border-color: #2a2a2d; cursor: not-allowed; }

  .add-variant-inline {
    width: 100%; padding: 6px 8px; background: transparent; color: #888;
    border: none; border-top: 1px dashed #3e3e42;
    font-size: 11px; cursor: pointer; font-family: inherit; text-align: center;
  }
  .add-variant-inline:hover:not(:disabled) { color: #ccc; background: #202022; }
  .add-variant-inline:disabled { color: #444; cursor: not-allowed; }
</style>
