"""
Workflow Canvas -- FastAPI backend (pm-native).

All data comes from the live pm SQLite database -- no mock data, no MLflow.

Endpoints
---------
GET  /                            Serve the canvas SPA
GET  /api/modules                 All modules + methods + slot contracts (live DB)
GET  /api/types                   Data-type metadata for slot colouring
POST /api/workflow/validate       Validate a workflow graph against the DB
POST /api/workflow/run            Submit a workflow for execution
POST /api/workflow/save           Save a workflow definition

POST /api/pm/load                 (Re)load PmProvider from a project path
POST /api/pm/refresh              Reload from current project_root
GET  /api/pm/status               Provider status
GET  /api/pm/runs                 All pm runs in canvas format
GET  /api/pm/experiments          Pipelines as experiment groups
GET  /api/pm/run/{id}             Single run
GET  /api/pm/lineage/{id}         Full ancestor + descendant lineage
GET  /api/pm/tree/{id}            Run + all descendants
GET  /api/pm/modules              Module names (from provider cache)
GET  /api/pm/methods              Method list
GET  /api/pm/run/{id}/artifacts   List artifacts in a run archive dir
GET  /api/pm/run/{id}/artifact/*  Serve an artifact file

POST /api/pm/export-artifacts     Zip download (filtered by type)
POST /api/pm/preview-artifacts    Export preview (counts + sizes)
POST /api/pm/export-csvs          Zip download (CSV only)
POST /api/pm/preview-csvs         Preview CSVs
"""

from __future__ import annotations

import asyncio
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
import threading
import uuid
import zipfile
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlmodel import select

from ..database import get_session
from ..models import Method, MethodContract, Module, Run
from .pm_provider import PmProvider

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_STATIC_DIR = Path(__file__).parent / "static" / "dist"

# The frontend bundle lives in `static/dist/` after `npm run build`. In
# dev/test environments where the bundle has not been built, fall back to
# creating a minimal placeholder so `StaticFiles` can mount and tests can
# import `pm.canvas.server` without a prior build step. Production
# deployments should always ship a built bundle; this is purely a
# graceful-degradation fallback.
if not _STATIC_DIR.exists():
    try:
        _STATIC_DIR.mkdir(parents=True, exist_ok=True)
        _placeholder = _STATIC_DIR / "index.html"
        if not _placeholder.exists():
            _placeholder.write_text(
                "<!doctype html><title>pm canvas</title>"
                "<p>Frontend bundle not built. Run <code>npm run build</code> "
                "under <code>pm/canvas/static/</code>.</p>",
                encoding="utf-8",
            )
    except OSError:
        pass

# ---------------------------------------------------------------------------
# Provider state
# ---------------------------------------------------------------------------

_pm_provider: Optional[PmProvider] = None

# ---------------------------------------------------------------------------
# Active job tracking (single pipeline at a time)
# ---------------------------------------------------------------------------

_active_jobs: Dict[str, Dict[str, Any]] = {}


def _import_run_pipeline():
    """Lazy import of run_pipeline from pm.cli.

    Module-level reference so tests can mock ``pm.canvas.server.run_pipeline_fn``
    and have the mock remain active during background thread execution.
    """
    from ..cli import run_pipeline
    return run_pipeline


def _import_fail_pipeline():
    """Lazy import of fail_pipeline from pm.cli."""
    from ..cli import fail_pipeline
    return fail_pipeline


# Callable references -- overridden in tests via mock
run_pipeline_fn = _import_run_pipeline
fail_pipeline_fn = _import_fail_pipeline

# Extension mapping for slot_outputs (type -> file extension)
_TYPE_EXT_MAP: Dict[str, str] = {
    "CSV": ".csv",
    "csv": ".csv",
    "ANNDATA": ".h5ad",
    "PNG": ".png",
    "png": ".png",
    "MODEL": ".pkl",
    "model": ".pkl",
    "FIGURE": ".png",
    "LABELS": ".csv",
    "FEATURE_SET": ".csv",
    "JSON": ".json",
    "json": ".json",
    "directory": "",
    "DIRECTORY": "",
}


def _enrich_pipeline(pipeline: "PipelineInput") -> Dict[str, Any]:
    """Enrich a PipelineJSON payload with script paths and slot_outputs from the DB.

    The canvas sends minimal node data (id, method, module, params).
    This function looks up each method's contract to add script_path
    and slot_outputs so load_pipeline() has everything it needs.

    Args:
        pipeline: The PipelineInput model from the canvas frontend.

    Returns:
        A dict with ``nodes``, ``links``, and ``samples`` keys matching
        the PipelineJSON format that ``load_pipeline()`` expects.
    """
    contract_map: Dict[str, Dict[str, Any]] = {}
    with get_session() as session:
        modules_db = {m.name: m for m in session.exec(select(Module)).all()}
        for mod in modules_db.values():
            for meth in mod.methods:
                mc = meth.contract
                contract_map[f"{mod.name}.{meth.name}"] = {
                    "output_slots": mc.output_slots if mc else {},
                    "script_path": meth.script_path,
                    "env": meth.env,
                }

    nodes = []
    for node in pipeline.nodes:
        node_type = node.type or "method"

        # System nodes pass through without method enrichment
        if node_type in ("input_selector", "run_reference"):
            node_dict: Dict[str, Any] = {
                "id": node.id,
                "type": node_type,
                "method": "",
                "module": "",
                "params": node.params,
            }
            if node_type == "input_selector":
                node_dict["samples"] = node.samples or []
                node_dict["source"] = node.source or "registered"
                # Preserve fan_mode through to the engine; default "out"
                # keeps per-sample semantics intact for legacy pipelines.
                node_dict["fan_mode"] = node.fan_mode or "out"
            elif node_type == "run_reference":
                node_dict["run_id"] = node.run_id
                node_dict["output_slot"] = node.output_slot
            if node.label:
                node_dict["label"] = node.label
            nodes.append(node_dict)
            continue

        key = f"{node.module or ''}.{node.method}"
        info = contract_map.get(key, {})
        output_slots = info.get("output_slots", {})
        script_path = info.get("script_path", f"methods/{node.method}/{node.method}.py")

        slot_outputs: Dict[str, str] = {}
        slot_types: Dict[str, str] = {}
        for slot_name, slot_spec in output_slots.items():
            slot_type = slot_spec.get("type", "CSV") if isinstance(slot_spec, dict) else "CSV"
            ext = _TYPE_EXT_MAP.get(slot_type, ".csv")
            slot_outputs[slot_name] = f"{slot_name}{ext}"
            # ADR-010: emit parallel slot_types so both snakemake_gen and
            # run_step can consult the contract-declared type as the single
            # source of truth for directory-slot detection.
            slot_types[slot_name] = slot_type

        node_dict = {
            "id": node.id,
            "method": node.method,
            "module": node.module or "",
            "script": script_path or f"methods/{node.method}/{node.method}.py",
            "params": node.params,
            "slot_outputs": slot_outputs,
            "slot_types": slot_types,
            "env": info.get("env", "inherit"),
        }
        # Pass custom NID label through to pipeline JSON if set
        if node.label:
            node_dict["label"] = node.label
        nodes.append(node_dict)

    links = []
    for link in pipeline.links:
        l: Dict[str, str] = {"source": link.source, "target": link.target}
        if link.sourceHandle:
            l["source_slot"] = link.sourceHandle
        if link.targetHandle:
            l["target_slot"] = link.targetHandle
        links.append(l)

    result: Dict[str, Any] = {
        "nodes": nodes,
        "links": links,
        "samples": pipeline.samples,
    }
    # Pass through parameter-sweep fields when the canvas has authored any.
    # Both map 1:1 onto the engine's pipeline JSON schema — no transformation.
    if pipeline.param_sets:
        result["param_sets"] = pipeline.param_sets
    if pipeline.explicit_combos:
        result["explicit_combos"] = pipeline.explicit_combos
    return result


def _require_provider() -> PmProvider:
    if _pm_provider is None:
        raise HTTPException(
            status_code=400,
            detail="No pm project configured. Call POST /api/pm/load first.",
        )
    return _pm_provider


# ---------------------------------------------------------------------------
# Lifespan -- auto-load provider from cwd on startup
# ---------------------------------------------------------------------------


def _switch_db(project_root: Path) -> None:
    """Update DATABASE_URL env var and reset the SQLAlchemy engine to point at
    a different project's pm.db.  Called on auto-load and on POST /api/pm/load."""
    from ..database import reset_engine
    new_url = f"sqlite:///{project_root / '.pm' / 'pm.db'}"
    os.environ["DATABASE_URL"] = new_url
    reset_engine()


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _pm_provider
    # Prefer explicit project root from CLI (--project-root) over the resolved
    # workflow-canvas root.  Never use Path.cwd() directly — cwd may shift or
    # be rewritten (e.g. C:\Windows on Snakemake subprocess spawns).
    from ..database import project_root as _resolve_project_root
    env_root = os.environ.get("PM_CANVAS_PROJECT_ROOT")
    if env_root:
        project_root = Path(env_root)
    else:
        try:
            project_root = _resolve_project_root()
        except RuntimeError:
            project_root = Path.cwd()
    db_path = project_root / ".pm" / "pm.db"
    if db_path.exists():
        try:
            _pm_provider = PmProvider(str(project_root))
            _pm_provider.load()
            _switch_db(project_root)
            print(f"[canvas] Auto-loaded pm project from {project_root}")
        except Exception as exc:  # pragma: no cover
            print(f"[canvas] Warning: auto-load failed: {exc}")
    else:
        print(
            f"[canvas] No .pm/pm.db found in {project_root} "
            "-- use POST /api/pm/load to configure"
        )
    yield


app = FastAPI(title="Workflow Canvas", lifespan=lifespan)


# =============================================================================
# Data-type metadata  (slot colouring in the canvas UI)
# =============================================================================

DATA_TYPES = {
    "anndata":     {"color": "#4A90D9", "label": "AnnData"},
    "labels":      {"color": "#E9A847", "label": "Labels"},
    "feature_set": {"color": "#50C878", "label": "FeatureSet"},
    "array":       {"color": "#9B59B6", "label": "Array"},
    "figure":      {"color": "#E74C3C", "label": "Figure"},
    "dataframe":   {"color": "#F39C12", "label": "DataFrame"},
    "path":        {"color": "#1ABC9C", "label": "Path"},
    "string":      {"color": "#95A5A6", "label": "String"},
    "number":      {"color": "#95A5A6", "label": "Number"},
}


# =============================================================================
# Pydantic models
# =============================================================================


class PipelineNode(BaseModel):
    id: str
    type: Optional[str] = "method"  # "method" | "input_selector" | "run_reference"
    method: str = ""
    module: Optional[str] = None
    params: Dict[str, Any] = {}
    position: Optional[Dict[str, float]] = None
    label: Optional[str] = None  # custom NID from canvas node
    samples: Optional[List[str]] = None  # input_selector: selected samples
    run_id: Optional[str] = None  # run_reference: selected run ID
    output_slot: Optional[str] = None  # run_reference: selected output slot
    source: Optional[str] = None  # input_selector: source type
    fan_mode: Optional[str] = None  # input_selector: "out" (default, per-sample) | "in" (bundle)


class PipelineLink(BaseModel):
    source: str
    target: str
    sourceHandle: Optional[str] = None
    targetHandle: Optional[str] = None


class PipelineInput(BaseModel):
    name: Optional[str] = None
    nodes: List[PipelineNode]
    links: List[PipelineLink] = []
    samples: List[str] = []
    # Parameter-sweep fields carried through to the engine (pm/snakemake_gen.py).
    # The canvas compiles its richer authoring state (sample_overrides, etc.)
    # into these two fields before POSTing — see frontend pipeline.ts.
    param_sets: Optional[Dict[str, Dict[str, Dict[str, Any]]]] = None
    explicit_combos: Optional[List[Dict[str, Any]]] = None
    # When true, pass --keep-going to Snakemake so a failure in one job
    # doesn't cancel independent jobs. Useful for fan-out pipelines where
    # one bad sample shouldn't block the rest. Default off (fail-fast).
    keep_going: bool = False


class WorkflowResponse(BaseModel):
    status: str
    job_id: str
    message: str


class PmConfig(BaseModel):
    project_root: str


class ExportCSVsRequest(BaseModel):
    run_ids: Optional[List[str]] = None


class ExportArtifactsRequest(BaseModel):
    run_ids: Optional[List[str]] = None
    file_types: Optional[List[str]] = None


# =============================================================================
# Modules endpoint -- live DB query, no provider required
# =============================================================================


@app.get("/api/modules")
def get_modules():
    """Return modules as a nested dict keyed by module/method name for the builder UI.

    Shape: {moduleName: {description, methods: {methodName: {inputs, outputs, ...}}}}
    This matches what nodes.js / populateModulePalette() expect.
    """
    with get_session() as session:
        modules = session.exec(select(Module)).all()
        result: Dict[str, Any] = {}
        for mod in modules:
            methods_dict: Dict[str, Any] = {}
            for meth in mod.methods:
                mc: Optional[MethodContract] = meth.contract
                methods_dict[meth.name] = {
                    "inputs":        mc.input_slots   if mc else {},
                    "outputs":       mc.output_slots  if mc else {},
                    "version":       "1.0.0",
                    "description":   f"{mod.name} — {meth.name}",
                    "params_schema": mc.params_schema if mc else {},
                    "env":           meth.env,
                    "executor":      mc.executor      if mc else "python",
                }
            result[mod.name] = {
                "description": mod.description or mod.name,
                "methods": methods_dict,
            }
    return result


@app.get("/api/types")
def get_types():
    """Return data-type metadata for canvas UI slot colouring."""
    return DATA_TYPES


# =============================================================================
# Registry endpoints -- onboarding/registry UI (design_handoff_onboarding)
# =============================================================================


@app.get("/api/registry/modules")
def get_registry_modules():
    """List registered modules for the Registry tab.

    Shape matches design_handoff_onboarding/ENDPOINTS.md §2.1 (subset):
    `{modules: [{name, description, contracts[], methods, source}]}`.
    `color` is intentionally omitted -- the frontend assigns it from the
    `MOD_COLORS` cycle by registration order.
    """
    with get_session() as session:
        modules = session.exec(select(Module)).all()
        out: List[Dict[str, Any]] = []
        for mod in modules:
            contracts = [
                {
                    "type": c.contract_type,
                    "name": c.name,
                    "value_type": c.value_type,
                    "required": c.required,
                }
                for c in mod.contracts
            ]
            out.append({
                "name": mod.name,
                "description": mod.description or "",
                "contracts": contracts,
                "methods": len(mod.methods),
                "source": f"modules/{mod.name}/module.yaml",
            })
    return {"modules": out}


@app.get("/api/registry/methods")
def get_registry_methods():
    """List registered methods for the Registry tab.

    Shape (subset of ENDPOINTS.md §2.2): `{methods: [{name, module, env,
    validated, runCount, source}]}`.

    `validated` replaces the handoff's `status: "ok"|"stale"|"broken"` with
    a `bool | null` sourced from the dryRun cache (null = never checked).
    """
    from ..models import Run

    with get_session() as session:
        run_counts: Dict[int, int] = {}
        for row in session.exec(select(Run.method_id)).all():
            run_counts[row] = run_counts.get(row, 0) + 1

        modules = session.exec(select(Module)).all()
        out: List[Dict[str, Any]] = []
        for mod in modules:
            for meth in mod.methods:
                out.append({
                    "name": meth.name,
                    "module": mod.name,
                    "env": meth.env or "inherit",
                    "validated": None,
                    "runCount": run_counts.get(meth.id, 0),
                    "source": f"methods/{meth.name}/method.yaml",
                })
    return {"methods": out}


# ---- Method validation (env + import check) --------------------------------
#
# The design handoff's `status: "ok"|"stale"|"broken"` enum is replaced with
# `validated: bool | null`, populated from an in-memory cache keyed on
# `(method_id, script_fingerprint)`. POST /api/registry/methods/validate
# runs the check on demand; GET /api/registry/methods reads the cache.

_method_validate_cache: Dict[tuple, Dict[str, Any]] = {}


def _default_run_import_check(python_bin: str, script_path: str):
    """Load the script as a non-`__main__` module under the declared env.

    Uses importlib.util so any ``if __name__ == "__main__":`` guard inside the
    script does NOT fire — we want import-time side effects only (failed
    imports, syntax errors), not execution of the method's main() body.

    Returns (returncode, stdout, stderr). Overridable via
    ``_run_import_check_fn`` module-level attribute for tests.
    """
    code = (
        "import importlib.util, sys\n"
        f"spec = importlib.util.spec_from_file_location('_pm_validate_mod', {script_path!r})\n"
        "mod = importlib.util.module_from_spec(spec)\n"
        "sys.modules['_pm_validate_mod'] = mod\n"
        "spec.loader.exec_module(mod)\n"
    )
    result = subprocess.run(
        [python_bin, "-c", code],
        capture_output=True, text=True, timeout=60,
    )
    return (result.returncode, result.stdout, result.stderr)


_run_import_check_fn = _default_run_import_check


def _script_fingerprint(script_path: Path) -> Optional[str]:
    if not script_path.exists():
        return None
    return hashlib.sha256(script_path.read_bytes()).hexdigest()


def _project_root() -> Path:
    env_root = os.environ.get("PM_CANVAS_PROJECT_ROOT")
    if env_root:
        return Path(env_root)
    return Path.cwd()


class MethodValidateRequest(BaseModel):
    module: str
    method: str


_LANG_BY_EXT: Dict[str, str] = {
    ".py": "python",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".json": "json",
    ".toml": "toml",
    ".md": "markdown",
    ".sh": "shell",
    ".txt": "text",
}


@app.get("/api/registry/methods/{module_name}/{method_name}/detail")
def get_registry_method_detail(module_name: str, method_name: str):
    """Read-only view of a method's directory + its parsed contract.

    Lists every file in the method dir (no recursion) with its content and a
    language hint for syntax highlighting. Returns the DB-parsed contract
    (input_slots, output_slots, params_schema) alongside so the frontend can
    render it as structured tables without re-parsing YAML.
    """
    with get_session() as session:
        mod = session.exec(select(Module).where(Module.name == module_name)).first()
        if mod is None:
            raise HTTPException(status_code=404, detail=f"Module not found: {module_name}")
        meth = next((m for m in mod.methods if m.name == method_name), None)
        if meth is None:
            raise HTTPException(
                status_code=404,
                detail=f"Method not found: {module_name}.{method_name}",
            )
        contract = meth.contract
        contract_out = {
            "input_slots":   contract.input_slots   if contract else {},
            "output_slots":  contract.output_slots  if contract else {},
            "params_schema": contract.params_schema if contract else {},
            "executor":      contract.executor      if contract else "python",
        }
        script_rel = meth.script_path or f"methods/{meth.name}/{meth.name}.py"

    # Method dir = parent dir of the script path. Guard against DB poisoning:
    # the resolved dir must stay under the project root.
    project_root = _project_root().resolve()
    method_dir = (project_root / script_rel).parent.resolve()
    try:
        method_dir.relative_to(project_root)
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"method directory escapes project root (path traversal): {script_rel}",
        )
    if not method_dir.is_dir():
        return {"files": [], "contract": contract_out}

    files: List[Dict[str, Any]] = []
    for entry in sorted(method_dir.iterdir()):
        if not entry.is_file():
            continue
        if entry.name.startswith(".") or entry.name.endswith(".pyc"):
            continue
        try:
            content = entry.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue  # skip binaries / unreadable
        files.append({
            "name": entry.name,
            "language": _LANG_BY_EXT.get(entry.suffix, "text"),
            "content": content,
        })
    return {"files": files, "contract": contract_out}


@app.post("/api/registry/methods/validate")
def validate_registry_method(req: MethodValidateRequest):
    """Re-validate an existing method's env+import. Caches by fingerprint."""
    with get_session() as session:
        mod = session.exec(select(Module).where(Module.name == req.module)).first()
        if mod is None:
            raise HTTPException(status_code=404, detail=f"Module not found: {req.module}")
        meth = next((m for m in mod.methods if m.name == req.method), None)
        if meth is None:
            raise HTTPException(
                status_code=404,
                detail=f"Method not found: {req.module}.{req.method}",
            )
        method_id = meth.id
        script_rel = meth.script_path or f"methods/{meth.name}/{meth.name}.py"
        env_spec = meth.env or "inherit"

    script_path = _project_root() / script_rel
    fingerprint = _script_fingerprint(script_path)

    pre_checks: List[Dict[str, Any]] = []
    if fingerprint is None:
        pre_checks.append({
            "status": "fail",
            "label": "script file exists",
            "detail": f"not found: {script_rel}",
        })
        return {"validated": False, "preChecks": pre_checks}

    cache_key = (method_id, fingerprint)
    if cache_key in _method_validate_cache:
        return _method_validate_cache[cache_key]

    python_bin = sys.executable if env_spec == "inherit" else sys.executable
    rc, stdout, stderr = _run_import_check_fn(python_bin, str(script_path))

    validated = rc == 0
    pre_checks.append({
        "status": "ok" if validated else "fail",
        "label": "script imports under env",
        "detail": (stderr or "").strip()[:500] if not validated else f"env={env_spec}",
    })

    response = {"validated": validated, "preChecks": pre_checks}
    _method_validate_cache[cache_key] = response
    return response


# ---- Registry writes (module / method / sample) ----------------------------
#
# Route handlers wrap the existing pm.register / pm.cli registration helpers.
# Errors from the Python API are mapped to HTTP status codes:
#   FileNotFoundError       -> 404
#   ValueError              -> 400
#   DvcNotConfiguredError   -> 409
# Each hook is exposed as a module-level callable so tests can patch it.


def _default_register_sample(*args, **kwargs):
    from ..cli import register_sample
    return register_sample(*args, **kwargs)


_register_sample_fn = _default_register_sample


def _default_register_module(*args, **kwargs):
    from ..register import register_module
    return register_module(*args, **kwargs)


_register_module_fn = _default_register_module


class ContractSpec(BaseModel):
    type: str  # "output" | "metric" | "input" | "param"
    name: str
    value_type: Optional[str] = None
    required: bool = True


class ModuleRegisterRequest(BaseModel):
    name: str
    description: Optional[str] = None
    folder: Optional[str] = None
    contracts: List[ContractSpec] = []


def _module_pre_checks(req: ModuleRegisterRequest) -> List[Dict[str, Any]]:
    checks: List[Dict[str, Any]] = []
    with get_session() as session:
        existing = session.exec(
            select(Module).where(Module.name == req.name)
        ).first()
        if existing is not None:
            checks.append({
                "status": "fail",
                "label": "name available",
                "detail": f"already registered as {req.name}",
            })
        else:
            checks.append({"status": "ok", "label": "name available"})
    checks.append({"status": "ok", "label": "request parses"})
    return checks


@app.post("/api/registry/modules")
def register_module_endpoint(req: ModuleRegisterRequest, dryRun: bool = False):
    """Wrap ``pm.register.register_module`` with optional dry-run preflight."""
    checks = _module_pre_checks(req)
    ok = all(c["status"] != "fail" for c in checks)

    if dryRun or not ok:
        return {"ok": ok, "preChecks": checks}

    try:
        _register_module_fn(
            name=req.name,
            description=req.description,
            contracts=[c.model_dump() for c in req.contracts],
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except TypeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return {"ok": True, "preChecks": checks, "module": {"name": req.name}}


@app.get("/api/registry/samples")
def get_registry_samples():
    """List registered samples for the Registry tab.

    Shape (subset of ENDPOINTS.md §2.4): `{samples: [{name, source, size,
    hash, pushed, runCount, registered_at}]}`.

    `pushed` is `True` when a DVC content hash is present (indicates the sample
    is in the DVC cache and pushable to the remote); `False` otherwise.
    """
    from ..models import Run, Sample

    with get_session() as session:
        run_counts: Dict[str, int] = {}
        for row in session.exec(select(Run.sample)).all():
            if row:
                run_counts[row] = run_counts.get(row, 0) + 1

        samples = session.exec(select(Sample).order_by(Sample.name)).all()
        out: List[Dict[str, Any]] = [
            {
                "name": s.name,
                "source": s.source_path,
                "size": s.file_size,
                "hash": s.content_hash,
                "pushed": s.content_hash is not None,
                "runCount": run_counts.get(s.name, 0),
                "registered_at": s.registered_at.isoformat() if s.registered_at else None,
                "file_type": s.file_type,
            }
            for s in samples
        ]
    return {"samples": out}


# =============================================================================
# Envs registry endpoints
# =============================================================================
#
# Surfaces env specs referenced by registered methods plus the per-env
# env_fingerprint history captured at pre_run time by the env-fingerprint-
# provenance PEV cycle (2026-04-18). The snapshot endpoint lets the user
# refresh env content on demand without creating a Run row.

_HEX32 = set("0123456789abcdef")


def _valid_md5(md5: str) -> bool:
    """Return True if ``md5`` is a 32-char lowercase hex string."""
    return len(md5) == 32 and all(c in _HEX32 for c in md5)


@app.get("/api/registry/envs")
def get_registry_envs():
    """List distinct env specs referenced by registered methods.

    One row per ``Method.env`` value. Aggregates method names, distinct
    env_fingerprint count, total run count, and most-recent run timestamp
    (``Run.started_at``) across all methods sharing that env.
    """
    with get_session() as session:
        # Methods grouped by env spec.
        methods = session.exec(select(Method)).all()
        modules_by_id: Dict[int, str] = {
            m.id: m.name for m in session.exec(select(Module)).all()
        }

        by_env: Dict[str, Dict[str, Any]] = {}
        method_ids_by_env: Dict[str, List[int]] = {}
        for meth in methods:
            spec = meth.env or "inherit"
            row = by_env.setdefault(
                spec,
                {
                    "spec": spec,
                    "methods": [],
                    "fingerprint_count": 0,
                    "last_run_at": None,
                    "run_count": 0,
                },
            )
            mod_name = modules_by_id.get(meth.module_id, "?")
            row["methods"].append(f"{mod_name}.{meth.name}")
            method_ids_by_env.setdefault(spec, []).append(meth.id)

        # Aggregate Run stats per env spec.
        for spec, method_ids in method_ids_by_env.items():
            runs = session.exec(
                select(Run).where(Run.method_id.in_(method_ids))
            ).all()
            row = by_env[spec]
            row["run_count"] = len(runs)
            distinct_fps = {r.env_fingerprint for r in runs if r.env_fingerprint}
            row["fingerprint_count"] = len(distinct_fps)
            started = [r.started_at for r in runs if r.started_at is not None]
            if started:
                row["last_run_at"] = max(started).isoformat()

        # Sorted: most-recently-run first, then alphabetical for ties.
        envs = sorted(
            by_env.values(),
            key=lambda r: (r["last_run_at"] is None, -(len(r["methods"])), r["spec"]),
        )
    return {"envs": envs}


@app.get("/api/registry/envs/{spec:path}/fingerprints")
def get_registry_env_fingerprints(spec: str):
    """Per-env fingerprint history derived from Run.env_fingerprint rows.

    For each distinct env_fingerprint observed in Runs of methods whose
    ``env == spec``, return first-seen / last-seen timestamps and run count.
    A fingerprint only present in the DVC cache (e.g. from a manual
    snapshot) is NOT returned here — the snapshot endpoint returns it
    directly; the frontend merges.
    """
    with get_session() as session:
        methods = session.exec(
            select(Method).where(Method.env == spec)
        ).all()
        if not methods and spec != "inherit":
            raise HTTPException(
                status_code=404,
                detail=f"No methods registered with env '{spec}'",
            )
        method_ids = [m.id for m in methods]
        runs = (
            session.exec(select(Run).where(Run.method_id.in_(method_ids))).all()
            if method_ids
            else []
        )

        by_fp: Dict[str, Dict[str, Any]] = {}
        for r in runs:
            if not r.env_fingerprint:
                continue
            entry = by_fp.setdefault(
                r.env_fingerprint,
                {
                    "md5": r.env_fingerprint,
                    "first_seen": None,
                    "last_seen": None,
                    "run_count": 0,
                    "source": "run",
                },
            )
            entry["run_count"] += 1
            if r.started_at is not None:
                ts = r.started_at
                if entry["first_seen"] is None or ts < entry["first_seen"]:
                    entry["first_seen"] = ts
                if entry["last_seen"] is None or ts > entry["last_seen"]:
                    entry["last_seen"] = ts

        # Serialize datetimes.
        fps = []
        for e in by_fp.values():
            fps.append({
                **e,
                "first_seen": e["first_seen"].isoformat() if e["first_seen"] else None,
                "last_seen": e["last_seen"].isoformat() if e["last_seen"] else None,
            })
        # Most-recent first.
        fps.sort(key=lambda e: (e["last_seen"] is None, e["last_seen"]), reverse=True)
    return {"spec": spec, "fingerprints": fps}


@app.post("/api/registry/envs/{spec:path}/snapshot")
def snapshot_registry_env(spec: str):
    """Capture env content on demand and store it in the DVC cache.

    Runs ``capture_env_content`` + ``store_env_content`` against the live
    env and returns the resulting md5. No Run row is created; the only
    side effect is a (possibly no-op) write to the DVC content-addressed
    cache.

    Response ``is_new`` is True when the md5 does not already appear in
    any ``Run.env_fingerprint`` for this spec (i.e. this fingerprint has
    not been observed via an actual Run before).
    """
    from ..version import capture_env_content, store_env_content

    project_root = _project_root()
    try:
        content = capture_env_content(spec, project_root)
        md5 = store_env_content(content, project_root)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    observed_at = datetime.now(timezone.utc).isoformat()
    with get_session() as session:
        methods = session.exec(
            select(Method).where(Method.env == spec)
        ).all()
        method_ids = [m.id for m in methods]
        is_new = True
        if method_ids:
            existing = session.exec(
                select(Run).where(Run.method_id.in_(method_ids)).where(
                    Run.env_fingerprint == md5
                )
            ).first()
            is_new = existing is None

    return {
        "spec": spec,
        "md5": md5,
        "is_new": is_new,
        "observed_at": observed_at,
    }


@app.get("/api/registry/envs/blob/{md5}")
def get_registry_env_blob(md5: str):
    """Read an env-content blob from the DVC content-addressed cache.

    Returns the raw blob as ``text/plain`` so the frontend can render it
    directly in a code panel or compute a client-side diff against another
    blob.
    """
    from fastapi.responses import PlainTextResponse

    if not _valid_md5(md5):
        raise HTTPException(status_code=400, detail="malformed md5 (expect 32 lowercase hex)")

    project_root = _project_root().resolve()
    cache_root = (project_root / ".dvc" / "cache" / "files" / "md5").resolve()
    blob_path = (cache_root / md5[:2] / md5[2:]).resolve()

    # Path-traversal guard: the resolved path must stay under cache_root.
    try:
        blob_path.relative_to(cache_root)
    except ValueError:
        raise HTTPException(status_code=400, detail="path traversal rejected")

    if not blob_path.is_file():
        raise HTTPException(status_code=404, detail=f"blob not found: {md5}")

    return PlainTextResponse(blob_path.read_text(encoding="utf-8"))


def _default_register_method(*args, **kwargs):
    from ..register import register_method
    return register_method(*args, **kwargs)


_register_method_fn = _default_register_method


class MethodRegisterRequest(BaseModel):
    directory: str
    module: str
    env: Optional[str] = "inherit"
    method_name: Optional[str] = None


def _method_register_pre_checks(req: MethodRegisterRequest) -> List[Dict[str, Any]]:
    checks: List[Dict[str, Any]] = []

    # --- directory ---
    directory = (req.directory or "").strip()
    if not directory:
        checks.append({
            "status": "fail",
            "label": "directory provided",
            "detail": "required — pick a folder containing method.yaml",
        })
    else:
        method_dir = (_project_root() / directory).resolve()
        if not method_dir.exists():
            checks.append({
                "status": "fail",
                "label": "directory exists",
                "detail": f"not found: {directory}",
            })
        elif not method_dir.is_dir():
            checks.append({
                "status": "fail",
                "label": "directory is a folder",
                "detail": f"{directory} is a file, not a directory",
            })
        else:
            checks.append({"status": "ok", "label": "directory exists"})
            yaml_path = method_dir / "method.yaml"
            if yaml_path.is_file():
                checks.append({"status": "ok", "label": "method.yaml present"})
            else:
                checks.append({
                    "status": "fail",
                    "label": "method.yaml present",
                    "detail": f"missing method.yaml in {directory}",
                })

    # --- module ---
    module = (req.module or "").strip()
    if not module:
        checks.append({
            "status": "fail",
            "label": "module selected",
            "detail": "required — choose the module this method belongs to",
        })
    else:
        with get_session() as session:
            mod = session.exec(select(Module).where(Module.name == module)).first()
            if mod is None:
                checks.append({
                    "status": "fail",
                    "label": "module registered",
                    "detail": f"'{module}' is not a registered module",
                })
            else:
                checks.append({"status": "ok", "label": "module registered"})
    return checks


@app.post("/api/registry/methods")
def register_method_endpoint(req: MethodRegisterRequest, dryRun: bool = False):
    """Wrap ``pm.register.register_method`` with optional dry-run preflight."""
    checks = _method_register_pre_checks(req)
    ok = all(c["status"] != "fail" for c in checks)

    if dryRun or not ok:
        return {"ok": ok, "preChecks": checks}

    try:
        _register_method_fn(
            method_dir=Path(req.directory),
            module_name=req.module,
            method_name=req.method_name,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return {"ok": True, "preChecks": checks, "method": {"name": req.method_name or Path(req.directory).name}}


@app.get("/api/fs/browse")
def fs_browse(path: str = ""):
    """List directory contents under the project root.

    ``path`` is relative to the project root. Defaults to the root itself.
    Rejects any path that resolves outside the project root. Safe for a
    localhost single-user dev tool: the server is already scoped to the
    project the user chose to launch it against.
    """
    project_root = _project_root().resolve()
    target = (project_root / path).resolve()
    try:
        target.relative_to(project_root)
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"path escapes project root (path traversal): {path}",
        )
    if not target.exists():
        raise HTTPException(status_code=404, detail=f"not found: {path}")
    if not target.is_dir():
        raise HTTPException(status_code=400, detail=f"not a directory: {path}")

    entries: List[Dict[str, Any]] = []
    for entry in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        if entry.name.startswith("."):
            continue
        if entry.is_dir():
            entries.append({"name": entry.name, "kind": "dir"})
        elif entry.is_file():
            try:
                size = entry.stat().st_size
            except OSError:
                size = None
            entries.append({"name": entry.name, "kind": "file", "size": size})
    return {"path": path, "entries": entries}


@app.get("/api/project/status")
def get_project_status():
    """Onboarding-shaped project status.

    Subset of ENDPOINTS.md §1.1 — reports whether a project is loaded,
    its root, and quick counts. Always 200, never 404.
    """
    from ..models import Sample

    if _pm_provider is None:
        return {"initialized": False, "path": None}

    with get_session() as session:
        module_count = len(session.exec(select(Module)).all())
        methods_total = sum(
            len(mod.methods) for mod in session.exec(select(Module)).all()
        )
        sample_count = len(session.exec(select(Sample)).all())

    return {
        "initialized": True,
        "path": str(_pm_provider.project_root),
        "modules": module_count,
        "methods": methods_total,
        "samples": sample_count,
        "dbPath": str(Path(_pm_provider.project_root) / ".pm" / "pm.db"),
        "tomlPath": str(Path(_pm_provider.project_root) / ".pm" / "wf-canvas.toml"),
    }


class SampleRegisterRequest(BaseModel):
    name: str
    source: str
    registration_mode: Optional[str] = "copy"


@app.post("/api/registry/samples")
def register_sample_endpoint(req: SampleRegisterRequest):
    """Wrap ``pm.cli.register_sample`` behind an HTTP endpoint."""
    from ..provenance import DvcNotConfiguredError

    try:
        _register_sample_fn(
            name=req.name,
            source_path=Path(req.source),
            registration_mode=req.registration_mode or "copy",
        )
    except DvcNotConfiguredError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    return {"ok": True, "sample": {"name": req.name}}


# =============================================================================
# Canvas SPA
# =============================================================================


@app.get("/")
def root():
    """Serve the main SPA page."""
    return FileResponse(_STATIC_DIR / "index.html")


# =============================================================================
# Workflow builder endpoints
# =============================================================================


@app.post("/api/workflow/validate")
def validate_workflow(pipeline: PipelineInput):
    """Validate a pipeline graph against registered methods in the DB."""
    errors: List[str] = []
    warnings: List[str] = []

    if not pipeline.nodes:
        errors.append("Pipeline has no nodes")
        return {"valid": False, "errors": errors, "warnings": warnings}

    with get_session() as session:
        modules_db = {m.name: m for m in session.exec(select(Module)).all()}
        # Eagerly load methods and contracts within the session
        method_lookup: Dict[str, Any] = {}
        for mod in modules_db.values():
            for meth in mod.methods:
                key = f"{mod.name}.{meth.name}"
                method_lookup[key] = {
                    "contract": meth.contract,
                    "module": mod.name,
                    "method": meth.name,
                }

    for node in pipeline.nodes:
        # System nodes (input_selector, run_reference) are not registered
        # methods — skip method validation for them.
        node_type = getattr(node, "type", None) or "method"
        if node_type in ("input_selector", "run_reference"):
            continue
        mod_name = node.module or ""
        key = f"{mod_name}.{node.method}"
        info = method_lookup.get(key)
        if info is None:
            errors.append(f"Unknown method: {mod_name}.{node.method!r}")
            continue
        mc = info["contract"]
        if mc and mc.input_slots:
            for slot_name, slot_spec in mc.input_slots.items():
                if slot_spec.get("required", True):
                    connected = any(
                        l.target == node.id and l.targetHandle == slot_name
                        for l in pipeline.links
                    )
                    if not connected:
                        warnings.append(
                            f"{node.method}: required input slot {slot_name!r} is not connected"
                        )

    # Input-slot uniqueness: a single input slot on a method node must not
    # have more than one incoming edge. Multi-edge-per-slot has never worked
    # end-to-end (the engine hard-wires the sample axis per upstream), so
    # reject it at validate time instead of letting Snakemake fail silently.
    slot_edges: Dict[tuple, List[str]] = {}
    for lnk in pipeline.links:
        key = (str(lnk.target), str(lnk.targetHandle or ""))
        slot_edges.setdefault(key, []).append(str(lnk.source))
    for (tgt, slot), sources in slot_edges.items():
        if len(sources) > 1:
            slot_label = slot or "(default)"
            errors.append(
                f"Input slot '{slot_label}' on node '{tgt}' has "
                f"{len(sources)} incoming edges; only one edge per slot is "
                f"supported. Sources: {', '.join(sources)}."
            )

    # Fan-in shape checks (single-selector fan-in cycle): reject shapes the
    # engine does not yet support so the user sees a clear message instead
    # of a cryptic Snakemake failure.
    #
    # 1. Any input_selector with fan_mode="in" must have at least one sample.
    # 2. A method node whose upstreams include a fan-in selector must have
    #    exactly one upstream (the selector) -- multi-selector or
    #    mixed-kind upstreams on a fan-in consumer are out of scope.
    fan_in_selectors: Dict[str, "PipelineNode"] = {}
    for node in pipeline.nodes:
        node_type = getattr(node, "type", None) or "method"
        if node_type == "input_selector" and (node.fan_mode or "out") == "in":
            fan_in_selectors[str(node.id)] = node
            if not (node.samples or []):
                errors.append(
                    f"Input selector '{node.id}' has fan_mode='in' but no "
                    f"samples selected. Fan-in requires at least one sample."
                )

    if fan_in_selectors:
        # Group links by target for multi-upstream detection.
        upstreams_by_target: Dict[str, List[str]] = {}
        for lnk in pipeline.links:
            upstreams_by_target.setdefault(str(lnk.target), []).append(str(lnk.source))

        for node in pipeline.nodes:
            node_type = getattr(node, "type", None) or "method"
            if node_type != "method":
                continue
            tgt_id = str(node.id)
            ups = upstreams_by_target.get(tgt_id, [])
            fan_in_ups = [u for u in ups if u in fan_in_selectors]
            if fan_in_ups and len(ups) > 1:
                selector_id = fan_in_ups[0]
                errors.append(
                    f"Fan-in mode on '{selector_id}' is only supported when "
                    f"it is the sole upstream of its consumer. Consumer "
                    f"'{tgt_id}' has {len(ups)} upstreams."
                )

    # Structural check: method nodes cannot be DAG roots (no incoming edges).
    # Only system nodes (input_selector, run_reference) are valid roots.
    incoming = {str(l.target) for l in pipeline.links}
    for node in pipeline.nodes:
        node_type = getattr(node, "type", None) or "method"
        if node_type in ("input_selector", "run_reference"):
            continue  # system nodes are valid roots
        node_id = str(node.id)
        if node_id not in incoming:
            errors.append(
                f"Method node '{node_id}' cannot be a pipeline root. "
                f"Use an input_selector or run_reference system node as the root "
                f"and connect it to this method node."
            )

    return {"valid": len(errors) == 0, "errors": errors, "warnings": warnings}


def _classify_pipeline_error(exc: Exception) -> Dict[str, Any]:
    """Map a pre-run exception to a structured payload for the canvas UI.

    The UI shows the raw message by default (it's already human-readable —
    ``pixi_lock_section`` / ``DirtyRepositoryError`` / ``capture_env_content``
    build full sentences).  ``kind`` lets the frontend pick an icon/color or
    inline action (e.g. a "Commit changes" button for dirty_repo).  ``hint``
    is an optional follow-up sentence separated from the main message.
    """
    from ..version import DirtyRepositoryError

    message = str(exc) or exc.__class__.__name__

    if isinstance(exc, DirtyRepositoryError):
        return {
            "kind": "dirty_repo",
            "message": message,
            "hint": "Commit or stash your changes, then click Run again.",
        }
    # pixi env-spec parse error from capture_env_content — malformed env: field.
    if isinstance(exc, ValueError) and "Malformed pixi env spec" in message:
        return {
            "kind": "env_spec",
            "message": message,
            "hint": "Fix the method's env: field (e.g. method.yaml).",
        }
    # Lock missing / project dir missing — pixi install hasn't been run.
    if isinstance(exc, FileNotFoundError) and "pixi.lock" in message:
        return {"kind": "env_lock_missing", "message": message}
    # Env name not in lock (3-segment spec pointed at a non-existent env).
    if isinstance(exc, KeyError) and "no env named" in message:
        return {"kind": "env_name_missing", "message": message}
    # Module/method lookup miss from pre_run (pm/cli.py).
    if isinstance(exc, ValueError) and "not found" in message.lower():
        return {"kind": "not_found", "message": message}
    return {"kind": "unknown", "message": message}


@app.post("/api/workflow/run")
def run_workflow(pipeline: PipelineInput):
    """Submit a pipeline for execution via Snakemake.

    Enriches the PipelineJSON with script paths and slot_outputs from the DB,
    writes it to a temp file, and spawns a background thread running
    ``run_pipeline()``. Returns the pipeline_id as the job_id immediately.

    Rejects empty pipelines with HTTP 400.  Multiple pipelines may run
    concurrently — each gets its own pipeline_id-scoped workspace.
    """
    if not pipeline.nodes:
        raise HTTPException(status_code=400, detail="Pipeline has no nodes")

    # Enrich nodes with script paths and slot_outputs from DB
    pipeline_json = _enrich_pipeline(pipeline)
    pipeline_id = str(uuid.uuid4())

    from ..database import project_root as _resolve_project_root
    env_root = os.environ.get("PM_CANVAS_PROJECT_ROOT")
    if env_root:
        project_root = env_root
    else:
        try:
            project_root = str(_resolve_project_root())
        except RuntimeError:
            project_root = str(Path.cwd())
    pipeline_dir = Path(project_root) / ".runs" / "pipelines" / pipeline_id
    pipeline_dir.mkdir(parents=True, exist_ok=True)

    pipeline_path = pipeline_dir / "pipeline.json"
    pipeline_path.write_text(json.dumps(pipeline_json, indent=2), encoding="utf-8")

    # Build step mapping: node_id -> method_name (for frontend status tracking)
    step_map = {n.id: n.method for n in pipeline.nodes}

    def _run_in_background():
        """Execute the pipeline in a background thread."""
        try:
            _rp = run_pipeline_fn()
            _rp(
                pipeline_path=str(pipeline_path),
                project_root=project_root,
                pipeline_id=pipeline_id,
                capture_output=True,
                keep_going=pipeline.keep_going,
            )
        except Exception as exc:
            # Record failure -- fail_pipeline marks in-flight runs
            try:
                _fp = fail_pipeline_fn()
                _fp(pipeline_id)
            except Exception:
                pass  # Best-effort cleanup
            _active_jobs[pipeline_id]["error"] = _classify_pipeline_error(exc)

    thread = threading.Thread(target=_run_in_background, daemon=True)
    _active_jobs[pipeline_id] = {
        "thread": thread,
        "pipeline_id": pipeline_id,
        "step_map": step_map,
        "log_dir": str(pipeline_dir),
        "error": None,
    }
    thread.start()

    return {
        "status": "submitted",
        "job_id": pipeline_id,
        "message": f"Pipeline '{pipeline.name or 'unnamed'}' submitted ({len(pipeline.nodes)} nodes)",
        "step_map": step_map,
    }


@app.get("/api/workflow/status/{job_id}")
def get_workflow_status(job_id: str):
    """Return per-step and overall status for a running or completed pipeline.

    Queries the ``runs`` table by ``pipeline_id`` and derives overall status.
    Also returns whether the background thread is still alive and any captured
    log output.

    Args:
        job_id: The pipeline_id returned by the run endpoint.

    Returns:
        JSON with ``job_id``, ``overall_status``, ``steps``, ``thread_alive``,
        ``log``, and ``error`` fields.
    """
    if job_id not in _active_jobs:
        raise HTTPException(status_code=404, detail=f"Unknown job: {job_id}")

    job_info = _active_jobs[job_id]
    thread = job_info.get("thread")
    thread_alive = thread.is_alive() if thread else False
    log_dir = job_info.get("log_dir")
    job_error = job_info.get("error")

    # Tally per-sample statuses per method so the canvas can show a
    # "mixed" aggregate when fan-out samples diverge (one failed, rest
    # succeeded, etc.). A flat last-write-wins dict would hide this.
    from collections import defaultdict as _defaultdict
    method_tallies: Dict[str, Dict[str, int]] = _defaultdict(
        lambda: {"running": 0, "completed": 0, "failed": 0}
    )
    # Also collect run_ids per method so the canvas can point the Output tab
    # at a specific Run row for streaming. Ordered newest-first by started_at
    # so run_ids[0] is the most recent attempt.
    method_run_ids: Dict[str, List[Any]] = _defaultdict(list)
    # Most-recent failed/cancelled run per method so the canvas can show a
    # one-liner on the node without the user having to open the log stream.
    # run_message tail is capped so the Inspector panel stays compact.
    _ERROR_MESSAGE_CAP = 600
    method_error: Dict[str, Dict[str, Any]] = {}
    with get_session() as session:
        runs = session.exec(
            select(Run)
            .where(Run.pipeline_id == job_id)
            .order_by(Run.started_at.desc())
        ).all()
        for run in runs:
            method = run.method
            key = method.name if method else f"method_{run.method_id}"
            status = run.status or "unknown"
            if status not in method_tallies[key]:
                method_tallies[key][status] = 0
            method_tallies[key][status] += 1
            method_run_ids[key].append(str(run.id))
            # Record the newest failure per method.  Iteration is
            # started_at-DESC so the first hit is the most recent.
            if key not in method_error and status in ("failed", "cancelled"):
                raw_msg = (run.error_message or "").strip()
                if raw_msg:
                    msg = raw_msg
                    if len(msg) > _ERROR_MESSAGE_CAP:
                        msg = msg[:_ERROR_MESSAGE_CAP].rstrip() + "…"
                    method_error[key] = {
                        "message": msg,
                        "run_id": str(run.id),
                        "sample": run.sample,
                        "status": status,
                    }

    def _aggregate(tally: Dict[str, int]) -> str:
        """Collapse a per-sample tally into a single display state."""
        if tally.get("running", 0) > 0:
            return "running"
        completed = tally.get("completed", 0)
        failed = tally.get("failed", 0)
        if completed > 0 and failed > 0:
            return "mixed"
        if failed > 0:
            return "failed"
        if completed > 0:
            return "completed"
        return "unknown"

    method_status: Dict[str, str] = {
        name: _aggregate(t) for name, t in method_tallies.items()
    }

    # Build node_states keyed by canvas node ID using the step_map
    # (step_map is {node_id: method_name}, stored when the pipeline was submitted).
    # This handles cache hits (where the reused run has a different pipeline_id)
    # and multiple nodes using the same method.
    step_map: Dict[str, str] = job_info.get("step_map", {})
    node_states: Dict[str, Dict[str, Any]] = {}
    for node_id, method_name in step_map.items():
        if not method_name:
            continue  # skip system nodes
        status = method_status.get(method_name)
        if status:
            tally = method_tallies[method_name]
            entry: Dict[str, Any] = {
                "status": status,
                "tally": dict(tally),
                # run_ids newest-first so consumers can treat run_ids[0] as
                # "most recent attempt". Empty list when no Run rows exist
                # yet (pending / cache-hit-only nodes).
                "run_ids": list(method_run_ids.get(method_name, [])),
            }
            # Per-node error surface (ADR-004 error persistence).  Attached for
            # ``failed`` and ``mixed`` states so the Inspector can show the
            # newest failure without the user having to open the log stream;
            # also included for the rare ``completed`` state where an earlier
            # attempt carried an error_message (edge case, near-zero cost).
            err = method_error.get(method_name)
            if err and status in ("failed", "mixed"):
                entry["error"] = err["message"]
                entry["error_run_id"] = err["run_id"]
                if err.get("sample"):
                    entry["error_sample"] = err["sample"]
            node_states[node_id] = entry

    # Method nodes not yet in the DB haven't started — mark them pending
    # so the overall status doesn't flip to "completed" prematurely.
    for node_id, method_name in step_map.items():
        if method_name and node_id not in node_states:
            node_states[node_id] = {"status": "pending"}

    # If thread is dead and we still have pending nodes with no error,
    # they were likely cache hits — mark them completed.
    if not thread_alive and not job_error:
        for node_id, ns in node_states.items():
            if ns["status"] == "pending":
                node_states[node_id] = {"status": "completed"}

    # Derive overall status from node states. "mixed" is a terminal state
    # for a node — its per-sample runs finished but with partial failure.
    # At the pipeline level that maps to `completed_with_failures` when
    # nothing is still running; during execution it stays `running`.
    statuses = [ns["status"] for ns in node_states.values()] if node_states else []
    if not statuses:
        overall = "pending"
    elif any(s == "running" for s in statuses):
        overall = "running"
    elif any(s == "failed" for s in statuses):
        # Any fully-failed node fails the pipeline (same as before).
        overall = "failed"
    elif any(s == "mixed" for s in statuses):
        # Nothing running, nothing fully failed, but some node saw partial
        # failures across its fan-out samples. Keep-going enabled this.
        overall = "completed_with_failures"
    elif all(s == "completed" for s in statuses):
        overall = "completed"
    else:
        overall = "running"

    # If thread is dead and no runs exist or overall is pending,
    # and there was an error, mark as failed
    if not thread_alive and job_error and overall == "pending":
        overall = "failed"

    # Read log files if available
    log_content = ""
    if log_dir:
        log_path = Path(log_dir)
        stdout_log = log_path / "stdout.log"
        stderr_log = log_path / "stderr.log"
        if stdout_log.exists():
            log_content += stdout_log.read_text(encoding="utf-8", errors="replace")
        if stderr_log.exists():
            stderr_text = stderr_log.read_text(encoding="utf-8", errors="replace")
            if stderr_text:
                log_content += "\n--- STDERR ---\n" + stderr_text

    return {
        "job_id": job_id,
        "overall_status": overall,
        "steps": method_status,
        "node_states": node_states,
        "thread_alive": thread_alive,
        "log": log_content,
        "error": job_error,
    }


@app.post("/api/workflow/save")
def save_workflow(workflow: Workflow):
    """Save a workflow definition."""
    return {"status": "saved", "name": workflow.name}


# =============================================================================
# PM Provider -- configure / reload
# =============================================================================


@app.post("/api/pm/load")
def load_pm_data(config: PmConfig):
    """Load (or reload) the pm provider from a project path.

    Also updates DATABASE_URL and resets the SQLAlchemy engine so that
    GET /api/modules queries this project's DB, not the server's launch-cwd DB.
    """
    global _pm_provider
    try:
        _pm_provider = PmProvider(config.project_root)
        _pm_provider.load()
        # Point the SQLAlchemy session at the loaded project's DB
        _switch_db(Path(config.project_root))
        return {
            "status": "loaded",
            "path": config.project_root,
            "modules": len(_pm_provider.get_modules()),
            "methods": len(_pm_provider.get_methods()),
            "runs": len(_pm_provider.get_all_runs()),
        }
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/api/pm/refresh")
def refresh_pm_data():
    """Reload pm data from the current project root."""
    prov = _require_provider()
    try:
        prov.load()
        return {
            "status": "refreshed",
            "path": str(prov.project_root),
            "modules": len(prov.get_modules()),
            "runs": len(prov.get_all_runs()),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# =============================================================================
# PM History endpoints
# =============================================================================


@app.get("/api/pm/status")
def get_pm_status():
    if _pm_provider is None:
        return {"loaded": False, "path": None}
    return {
        "loaded": True,
        "path": str(_pm_provider.project_root),
        "modules": len(_pm_provider.get_modules()),
        "runs": len(_pm_provider.get_all_runs()),
    }


@app.get("/api/pm/runs")
def get_pm_runs():
    # Plain `def` (not `async def`) so FastAPI dispatches to a threadpool.
    # The provider method is sync (DB + filesystem I/O); under `async def`
    # it would block the event loop and queue every other request behind
    # it — felt most painfully by the history tab when the user clicks
    # between runs while a slow /artifacts call is in flight.
    return _require_provider().get_all_runs()


@app.get("/api/pm/experiments")
def get_pm_experiments():
    return _require_provider().get_experiments()


@app.get("/api/pm/run/{run_id}")
def get_pm_run(run_id: str):
    run = _require_provider().get_run(run_id)
    if run is None:
        raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")
    return run


@app.get("/api/pm/lineage/{run_id}")
def get_pm_lineage(run_id: str):
    return _require_provider().get_lineage(run_id)


@app.get("/api/pm/tree/{run_id}")
def get_pm_run_tree(run_id: str):
    return _require_provider().get_run_tree(run_id)


@app.get("/api/pm/modules")
def get_pm_modules():
    return _require_provider().get_modules()



@app.get("/api/pm/methods")
def get_pm_methods():
    return _require_provider().get_methods()


@app.get("/api/pm/samples")
def get_pm_samples():
    """Return detailed info for all registered samples."""
    return _require_provider().get_samples_detail()


@app.get("/api/pm/completed-runs")
def get_pm_completed_runs():
    """Return completed runs with output slots for Run Reference nodes."""
    return _require_provider().get_completed_runs()


@app.get("/api/pm/run/{run_id}/artifacts")
def list_pm_artifacts(run_id: str):
    # Plain `def` — `list_artifacts` walks the run dir and stats every
    # descendant file to compute per-directory totals. On a big run this
    # takes long enough to freeze the history tab; under `async def` it
    # also blocked every other request until it finished.
    return _require_provider().list_artifacts(run_id)


@app.get("/api/pm/run/{run_id}/cancelled-descendants")
def get_pm_cancelled_descendants(run_id: str):
    """Return runs cancelled because ``run_id`` (or its subtree) failed."""
    return _require_provider().get_cancelled_descendants(run_id)


# ---------------------------------------------------------------------------
# SSE log streaming — /api/pm/run/{run_id}/stream-logs
# ---------------------------------------------------------------------------

_LOG_TERMINAL_STATUSES = {"completed", "success", "failed", "cancelled"}
_LOG_LIVE_POLL_SECONDS = 0.2
_LOG_LIVE_MAX_WALL_SECONDS = 60 * 60


def _log_tail_lines(path: Path, n: int) -> List[str]:
    """Return the last ``n`` newline-separated lines from ``path`` via seek-from-end.

    Reads backward in 8 KiB chunks; never slurps the full file.
    """
    if not path.exists() or n <= 0:
        return []
    chunk_size = 8192
    buf = bytearray()
    newlines = 0
    with path.open("rb") as f:
        f.seek(0, os.SEEK_END)
        pos = f.tell()
        while pos > 0 and newlines <= n:
            read = min(chunk_size, pos)
            pos -= read
            f.seek(pos)
            chunk = f.read(read)
            newlines += chunk.count(b"\n")
            buf[:0] = chunk
    text = bytes(buf).decode("utf-8", errors="replace")
    return text.splitlines()[-n:]


def _log_read_full_lines(path: Path) -> List[str]:
    if not path.exists():
        return []
    return path.read_text(encoding="utf-8", errors="replace").splitlines()


def _log_map_terminal_status(db_status: str) -> str:
    return "success" if db_status == "completed" else db_status


def _log_sse(payload: Dict[str, Any]) -> str:
    return f"data: {json.dumps(payload)}\n\n"


@app.get("/api/pm/run/{run_id}/stream-logs")
async def stream_run_logs(run_id: str, full: int = 0, tail: int = 500):
    """Stream a run's stdout/stderr as SSE events, ending with a `terminal` event.

    - Terminal runs (status in {completed, success, failed, cancelled}):
      read the on-disk log files, emit each line as a `stdout`/`stderr`
      event, then emit the `terminal` event and close. ``?full=1`` returns
      the whole file; default tails the last ``tail`` lines (default 500).
    - Running runs: poll the log files every ~200 ms, emit new lines as they
      appear, stop when the DB status transitions off ``running`` and emit a
      final `terminal` event.
    """
    try:
        rid = int(run_id)
    except (TypeError, ValueError):
        raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")

    with get_session() as session:
        row = session.exec(select(Run).where(Run.id == rid)).first()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")

    status = row.status or "unknown"
    error_message = row.error_message
    error_traceback = row.error_traceback

    run_dir = _project_root() / ".runs" / f"{rid:08d}"
    stdout_path = run_dir / "stdout.log"
    stderr_path = run_dir / "stderr.log"

    is_terminal = status in _LOG_TERMINAL_STATUSES

    async def stream():
        if is_terminal:
            out_lines = (
                _log_read_full_lines(stdout_path)
                if full
                else _log_tail_lines(stdout_path, tail)
            )
            for line in out_lines:
                yield _log_sse({"type": "stdout", "data": line})
            err_lines = (
                _log_read_full_lines(stderr_path)
                if full
                else _log_tail_lines(stderr_path, tail)
            )
            for line in err_lines:
                yield _log_sse({"type": "stderr", "data": line})
            terminal_payload: Dict[str, Any] = {
                "type": "terminal",
                "status": _log_map_terminal_status(status),
            }
            if error_message is not None:
                terminal_payload["error_message"] = error_message
            if error_traceback is not None:
                terminal_payload["error_traceback"] = error_traceback
            yield _log_sse(terminal_payload)
            return

        # Live run: emit a tail snapshot first, then incremental new bytes.
        for line in _log_tail_lines(stdout_path, tail):
            yield _log_sse({"type": "stdout", "data": line})
        for line in _log_tail_lines(stderr_path, tail):
            yield _log_sse({"type": "stderr", "data": line})
        stdout_offset = stdout_path.stat().st_size if stdout_path.exists() else 0
        stderr_offset = stderr_path.stat().st_size if stderr_path.exists() else 0

        elapsed = 0.0
        while True:
            with get_session() as session:
                cur = session.exec(select(Run).where(Run.id == rid)).first()
            cur_status = cur.status if cur is not None else "unknown"

            for path, kind, offset_name in (
                (stdout_path, "stdout", "stdout_offset"),
                (stderr_path, "stderr", "stderr_offset"),
            ):
                if not path.exists():
                    continue
                size = path.stat().st_size
                offset = stdout_offset if kind == "stdout" else stderr_offset
                if size <= offset:
                    continue
                with path.open("rb") as f:
                    f.seek(offset)
                    chunk = f.read(size - offset)
                if kind == "stdout":
                    stdout_offset = size
                else:
                    stderr_offset = size
                for line in chunk.decode("utf-8", errors="replace").splitlines():
                    if line:
                        yield _log_sse({"type": kind, "data": line})

            if cur_status != "running":
                payload: Dict[str, Any] = {
                    "type": "terminal",
                    "status": _log_map_terminal_status(cur_status),
                }
                if cur is not None and cur.error_message is not None:
                    payload["error_message"] = cur.error_message
                if cur is not None and cur.error_traceback is not None:
                    payload["error_traceback"] = cur.error_traceback
                yield _log_sse(payload)
                return

            await asyncio.sleep(_LOG_LIVE_POLL_SECONDS)
            elapsed += _LOG_LIVE_POLL_SECONDS
            if elapsed >= _LOG_LIVE_MAX_WALL_SECONDS:
                yield _log_sse({"type": "terminal", "status": cur_status})
                return

    return StreamingResponse(stream(), media_type="text/event-stream")


class RunPatchRequest(BaseModel):
    """Partial update for a Run's user-editable metadata.

    All fields are optional; missing fields are left unchanged. `nid`
    writes through to `Run.nid` (provenance table); the rest upsert a
    `RunAnnotation` row.

    `archived` is a bool at the API boundary and maps to the nullable
    `archived_at` timestamp column: ``true`` sets it to now, ``false``
    clears it.
    """
    nid: Optional[str] = None
    favorite: Optional[bool] = None
    tags: Optional[List[str]] = None
    archived: Optional[bool] = None


@app.patch("/api/pm/run/{run_id}")
def patch_pm_run(run_id: str, patch: RunPatchRequest):
    """Partial-update a run's user-editable metadata."""
    from sqlmodel import select
    from pm.database import get_session
    from pm.models import Run, RunAnnotation

    try:
        rid_int = int(run_id)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid run id: {run_id}")

    with get_session() as session:
        run = session.get(Run, rid_int)
        if run is None:
            raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")

        if patch.nid is not None:
            run.nid = patch.nid or None  # empty string clears the override
            session.add(run)

        if (
            patch.favorite is not None
            or patch.tags is not None
            or patch.archived is not None
        ):
            ann = session.exec(
                select(RunAnnotation).where(RunAnnotation.run_id == rid_int)
            ).first()
            if ann is None:
                ann = RunAnnotation(run_id=rid_int)
            if patch.favorite is not None:
                ann.favorite = patch.favorite
            if patch.tags is not None:
                ann.tags = list(patch.tags)
            if patch.archived is not None:
                ann.archived_at = datetime.now(timezone.utc) if patch.archived else None
            ann.updated_at = datetime.now(timezone.utc)
            session.add(ann)

        session.commit()

    # Invalidate the in-memory cache so the next /api/pm/runs call reflects
    # the change. Skip silently if no provider is configured (e.g. during
    # tests or before a project is loaded) — the DB write already landed.
    try:
        _require_provider()._loaded = False
    except HTTPException:
        pass
    return {"ok": True}


@app.get("/api/pm/run/{run_id}/artifact/{artifact_path:path}")
def get_pm_artifact(run_id: str, artifact_path: str):
    file_path = _require_provider().get_artifact_path(run_id, artifact_path)
    if file_path is None or not file_path.exists():
        raise HTTPException(status_code=404, detail=f"Artifact not found: {artifact_path}")
    return FileResponse(file_path)


# =============================================================================
# Artifact export helpers
# =============================================================================


def _sanitize(name: str) -> str:
    for ch in ['<', '>', ':', '"', '|', '?', '*', '\\', '/']:
        name = name.replace(ch, '_')
    return name.strip().strip('.')


def _build_artifact_zip(artifacts: list) -> io.BytesIO:
    buf = io.BytesIO()
    seen: set = set()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for item in artifacts:
            method = _sanitize(item['method'])
            run_name = _sanitize(item['run_name'])
            aname = _sanitize(item['artifact_name'])
            zip_path = f"{method}/{run_name}/{aname}"
            if zip_path in seen:
                base, _, ext = aname.rpartition('.')
                zip_path = f"{method}/{run_name}/{base}_{item['run_id'][:8]}.{ext}"
            seen.add(zip_path)
            if os.path.exists(item['file_path']):
                zf.write(item['file_path'], zip_path)
    buf.seek(0)
    return buf


def _build_preview_response(artifacts: list) -> dict:
    methods: set = set()
    runs: set = set()
    total_size = 0
    by_type: dict = {}
    for item in artifacts:
        methods.add(item['method'])
        runs.add(item['run_id'])
        fp = item.get('file_path', '')
        if fp and os.path.exists(fp):
            size = item.get('size_bytes', os.path.getsize(fp))
            total_size += size
            ext = item.get('extension', item.get('artifact_name', '').rsplit('.', 1)[-1].lower())
            entry = by_type.setdefault(ext, {'count': 0, 'size_bytes': 0})
            entry['count'] += 1
            entry['size_bytes'] += size
    return {
        "total_count": len(artifacts),
        "run_count": len(runs),
        "method_count": len(methods),
        "total_size_bytes": total_size,
        "methods": sorted(methods),
        "by_type": [
            {"ext": e, "count": d["count"], "size_bytes": d["size_bytes"]}
            for e, d in sorted(by_type.items())
        ],
        "files": [
            {
                "method": a['method'],
                "run_name": a['run_name'],
                "artifact": a['artifact_name'],
                "ext": a.get('extension', a.get('artifact_name', '').rsplit('.', 1)[-1].lower()),
                "size_bytes": a.get('size_bytes', 0),
            }
            for a in artifacts
        ],
    }


@app.post("/api/pm/export-artifacts")
def export_pm_artifacts(request: ExportArtifactsRequest):
    """Zip download of pm run artifacts, optionally filtered by file type."""
    prov = _require_provider()
    artifacts = prov.get_artifacts(request.run_ids, extensions=request.file_types)
    if not artifacts:
        raise HTTPException(status_code=404, detail="No matching files found.")
    buf = _build_artifact_zip(artifacts)
    ts = datetime.now().strftime('%Y-%m-%d_%H%M%S')
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="pm_export_{ts}.zip"'},
    )


@app.post("/api/pm/preview-artifacts")
def preview_pm_artifacts(request: ExportArtifactsRequest):
    """Preview what would be exported (all file types) without downloading."""
    return _build_preview_response(_require_provider().get_artifacts(request.run_ids))


@app.post("/api/pm/export-csvs")
def export_pm_csvs(request: ExportCSVsRequest):
    """Zip download of CSV artifacts from pm runs."""
    prov = _require_provider()
    artifacts = prov.get_csv_artifacts(request.run_ids)
    if not artifacts:
        raise HTTPException(status_code=404, detail="No CSV files found.")
    buf = _build_artifact_zip(artifacts)
    ts = datetime.now().strftime('%Y-%m-%d_%H%M%S')
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="pm_export_{ts}.zip"'},
    )


@app.post("/api/pm/preview-csvs")
def preview_pm_csvs(request: ExportCSVsRequest):
    """Preview CSV export (counts + sizes) without downloading."""
    return _build_preview_response(_require_provider().get_csv_artifacts(request.run_ids))


# =============================================================================
# Static files -- must come last (acts as catch-all for the SPA)
# =============================================================================

app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="static")
