"""
pm CLI — the bridge between Snakemake rules and the database.

Commands (called by each Snakemake rule):
  register_run       — insert a runs row (status='running'), print run ID
  complete_run       — mark completed, hardlink archive → workspace, write sidecar
  check_cache        — check if identical run exists (method+sample+params+parent), print run ID or NONE
  restore_output     — hardlink a cached run's output into the workspace path
  finalize_pipeline  — clean up .runs/workspace/ after successful pipeline
  fail_pipeline      — mark in-flight runs as failed, keep workspace for debugging
  resolve_input      — given a run ID, print the archived output path
  lookup_run         — (legacy) find most-recent completed run for method+sample
"""

import argparse
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from sqlmodel import select

from dflow.core.decorators import workflow, task, Step, AutoStep

from .database import get_session, runs_dir, project_root as get_project_root
from .models import Method, MethodVersion, Module, Run, RunInput, RunOutput, Sample


# =============================================================================
# Helpers
# =============================================================================

def _publish_to_workspace(src: Path, dest: Path) -> None:
    """Copy a file or directory from archive/staging to the workspace.

    Non-destructive: the source is preserved so the archive remains
    intact for future restores and lineage queries (ADR-011).

    For a single file: uses shutil.copy2 (preserves metadata).
    For a directory: uses shutil.copytree.  Any existing destination
    is removed before copying.

    Args:
        src: Source path (archive/staging area).
        dest: Destination path in the workspace.
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    if src.is_file():
        if dest.exists():
            dest.unlink()
        shutil.copy2(str(src), str(dest))
    elif src.is_dir():
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(str(src), str(dest))


def _run_archive_dir(run_id: int) -> Path:
    """Return the archive directory for a run: .runs/{id:08d}/"""
    return runs_dir() / f"{run_id:08d}"


def _ensure_pm_shim() -> Path:
    """Build (idempotently) a directory that puts *only* ``pm`` on sys.path.

    Returns the shim root — a directory whose sole entry is a single-file
    ``pm/__init__.py`` stub containing one line:

        __path__ = [r"<absolute path to the real pm package dir>"]

    When this stub is loaded as a Python package, Python rewrites
    ``pm.__path__`` to the real location.  Subsequent submodule lookups
    (``pm.method``, ``pm.pm_context``, …) are resolved against the real
    package via the namespace-package machinery.  Top-level imports of
    *siblings* of pm (``pandas``, ``numpy``, ``sqlmodel``, …) are **not**
    satisfied by the shim dir — they fall through to the running
    interpreter's own ``site-packages``.

    Why this exists
    ---------------
    The naïve fix is ``pm_env["PYTHONPATH"] = parent_of_pm_init``.  When
    ``workflow-canvas`` is pip-installed, ``parent_of_pm_init`` is the
    *host venv's* ``site-packages`` directory.  Propagating that into a
    pixi-env subprocess (which runs a *different* CPython with a
    different numpy/pandas ABI) causes `ImportError: numpy … compiled
    module file is _multiarray_umath.cp312-win_amd64.pyd` — the host
    venv's ABI-tagged extensions win over the pixi env's own copies.

    ADR-008 planned to eliminate this PYTHONPATH hack entirely
    (see ``docs/adrs/008-run-step-execution-layer.json``, "Zero-dependency
    RunContext").  That plan regressed when the ``@pm_method`` decorator
    was introduced: method scripts now legitimately need ``from pm.method
    import pm_method`` to resolve in the pixi env.  The shim is the
    smallest possible resurrection of the PYTHONPATH hack — it exposes
    ``pm`` and **nothing else** — so the pixi env's own numpy/pandas win.

    Implementation notes
    --------------------
    * Cache location lives under ``<project_root>/.pm/cache/pm-shim/``.
      Earlier versions used ``platformdirs.user_cache_dir`` (i.e.
      ``%LOCALAPPDATA%\\workflow-canvas\\Cache``) but Microsoft Store
      Python runs inside a UWP sandbox that silently redirects writes to
      ``%LOCALAPPDATA%`` into a per-package ``LocalCache`` directory.
      The host venv's ``Path.exists()`` is redirected too, so the shim
      appears to exist from inside MS Store Python — but a non-Store
      child process (e.g. the pixi env's Python) sees only the literal
      non-virtualized path, which is empty, and raises
      ``ModuleNotFoundError: No module named 'pm'``.  Writing under the
      project root sidesteps every UWP filter driver and makes the path
      ground truth for every process, MS Store or not.
    * ``PM_SHIM_CACHE_DIR`` (env var) overrides the default location.
      Intended as an escape hatch for CI with a read-only project
      checkout — point it at a writable tmp path.
    * Cache key is ``<version>-<md5(real_pm_path)>`` so two venvs of the
      same workflow-canvas version (e.g. sibling projects) don't share a
      stale shim pointing at the wrong package directory.
    * First-run atomicity: write ``__init__.py.tmp`` then ``os.replace``.
      ``os.replace`` is atomic on Windows since Python 3.3, so racing
      Snakemake workers can't observe a half-written stub.
    * Called lazily from ``run_step`` (not at module-import time) so
      canvas startup stays cheap in the happy path.
    """
    import hashlib
    from importlib.metadata import PackageNotFoundError, version as _pkg_version

    import pm as _pm_pkg
    real_pm_dir = Path(_pm_pkg.__file__).parent.resolve()

    try:
        version = _pkg_version("workflow-canvas")
    except PackageNotFoundError:
        version = "unknown"
    path_key = hashlib.md5(str(real_pm_dir).encode("utf-8")).hexdigest()[:12]

    override = os.environ.get("PM_SHIM_CACHE_DIR")
    if override:
        cache_root = Path(override)
    else:
        cache_root = get_project_root() / ".pm" / "cache" / "pm-shim"
    try:
        cache_root.mkdir(parents=True, exist_ok=True)
    except (OSError, PermissionError) as exc:
        raise RuntimeError(
            f"Cannot create pm-shim cache at {cache_root}: {exc}. "
            f"workflow-canvas needs a writable .pm/cache/ under the project "
            f"root. If you're in CI with a read-only checkout, set "
            f"PM_SHIM_CACHE_DIR to a writable location."
        ) from exc
    shim_root = cache_root / f"pm-shim-{version}-{path_key}"
    shim_pm = shim_root / "pm"
    init_py = shim_pm / "__init__.py"

    if init_py.exists():
        return shim_root

    shim_pm.mkdir(parents=True, exist_ok=True)
    # Single-line stub: rewrite __path__ to the real pm package dir.
    # See _ensure_pm_shim() docstring above for the full rationale.
    content = (
        "# Auto-generated by pm._ensure_pm_shim — do not edit.\n"
        "# See pm/cli.py::_ensure_pm_shim for why this file exists.\n"
        f"__path__ = [r{str(real_pm_dir)!r}]\n"
    )
    tmp = init_py.with_suffix(".py.tmp")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, init_py)
    return shim_root


# =============================================================================
# register_run
# =============================================================================

@task(purpose="Register a new run in the database with status='running'")
def register_run(
    method_name: str,
    module_name: str,
    sample: str,
    params: dict | None = None,
    parent_run_id: int | None = None,
    parent_run_ids: list[int] | None = None,
    nf_process_name: str | None = None,
    pipeline_id: str | None = None,
) -> int:
    """Insert a new run (status='running') and return the run ID.

    ``parent_run_ids`` is a list of strings in the format ``"slot:id"`` for
    fan-in (e.g. ``["sources:5", "sources:8"]``) or plain ``"id"`` for
    single-input nodes.  The slot name is stored in ``RunInput.input_name``.
    """
    # Normalize to list of (slot, pid) tuples
    parent_entries: list[tuple[str, int]] = []
    if parent_run_ids:
        for entry in parent_run_ids:
            s = str(entry)
            if ":" in s:
                slot, pid_str = s.split(":", 1)
                parent_entries.append((slot, int(pid_str)))
            else:
                parent_entries.append(("upstream", int(s)))
    elif parent_run_id is not None:
        parent_entries.append(("upstream", int(parent_run_id)))

    with get_session() as session:
        from .models import Module
        mod = session.exec(
            select(Module).where(Module.name == module_name)
        ).first()
        if mod is None:
            print(f"ERROR: module '{module_name}' not found in DB", file=sys.stderr)
            sys.exit(1)
        stmt = select(Method).where(
            Method.name == method_name,
            Method.module_id == mod.id,
        )
        method = session.exec(stmt).first()
        if method is None:
            print(f"ERROR: method '{method_name}' not found in module '{module_name}'", file=sys.stderr)
            sys.exit(1)

        run = Run(
            method_id=method.id,
            params=params,
            sample=sample,
            status="running",
            pipeline_id=pipeline_id,
            nf_process_name=nf_process_name,
            started_at=datetime.now(timezone.utc),
        )
        session.add(run)
        session.commit()
        session.refresh(run)
        run_id_val: int = run.id  # type: ignore[assignment]

        for slot, pid in parent_entries:
            run_input = RunInput(
                run_id=run_id_val,
                source_run_id=pid,
                input_name=slot,
            )
            session.add(run_input)
        if parent_entries:
            session.commit()

        # Create the archive directory so the method can write to it
        _run_archive_dir(run_id_val).mkdir(parents=True, exist_ok=True)

    return run_id_val


# =============================================================================
# complete_run  (hardlink archive → workspace, write sidecar)
# =============================================================================

@task(purpose="Mark a run as finished, link outputs to workspace (no inline archiving)")
def complete_run(
    run_id: int,
    status: str = "completed",
    output_files: list[str] | None = None,
    workspace_outputs: list[str] | None = None,
    metrics: dict | None = None,
    error_message: str | None = None,
    error_traceback: str | None = None,
) -> None:
    """Mark a run as finished and link outputs to workspace.

    Deferred archiving: content hashing and DVC cache copying are NOT
    performed here.  RunOutput rows are written with content_hash=NULL.
    The post-pipeline archive pass (or ``pm cache archive``) handles
    hashing and caching later.

    The .runs/workspace/ structure is preserved for Snakemake compatibility.

    Args:
        run_id: The run to complete.
        status: Final status (usually 'completed').
        output_files: Paths to output files (in staging area or workspace).
        workspace_outputs: Corresponding workspace paths for hardlinks.
            Must match output_files in length.
        metrics: Optional dict of metrics to store.
        error_message: Error message for failed runs (ADR 004).
        error_traceback: Error traceback for failed runs (ADR 004).
    """
    with get_session() as session:
        run = session.get(Run, run_id)
        if run is None:
            print(f"ERROR: run {run_id} not found", file=sys.stderr)
            sys.exit(1)

        run.status = status
        run.finished_at = datetime.now(timezone.utc)
        if metrics:
            run.metrics = metrics
        # ADR 004: persist error information on failed runs
        if error_message is not None:
            run.error_message = error_message
        if error_traceback is not None:
            run.error_traceback = error_traceback

        # Record outputs and link to workspace (no content hashing)
        for i, fpath in enumerate(output_files or []):
            src = Path(fpath)
            if not src.exists():
                print(f"ERROR: output file not found: {fpath}", file=sys.stderr)
                sys.exit(1)

            # Upsert RunOutput: pm_context._record_output() may have already written
            # this row with a proper artifact_type. If so, patch it rather than
            # creating a duplicate.  If not, create with "method_file" as the default.
            # content_hash is left NULL (deferred archiving).
            existing_ro = session.exec(
                select(RunOutput).where(
                    RunOutput.run_id == run_id,
                    RunOutput.output_name == src.name,
                )
            ).first()
            if existing_ro is not None:
                existing_ro.artifact_path = str(src)
            else:
                ro = RunOutput(
                    run_id=run_id,
                    output_name=src.name,
                    artifact_path=str(src),
                    artifact_type="method_file",  # default; pm_context sets the precise type
                )
                session.add(ro)

            # Copy into workspace if workspace path provided (non-destructive)
            if workspace_outputs and i < len(workspace_outputs):
                ws_path = Path(workspace_outputs[i])
                _publish_to_workspace(src, ws_path)

                # Write run_id.txt sidecar next to workspace output
                sidecar = ws_path.parent / "run_id.txt"
                sidecar.write_text(str(run_id))

        session.commit()


# =============================================================================
# check_cache
# =============================================================================

def check_cache(
    method_name: str,
    sample: str,
    params: dict | None = None,
    parent_run_id: int | None = None,
    parent_run_ids: list | None = None,
) -> int | None:
    """Check if an identical completed run exists.

    Matches on: method + sample + params (JSON-equal) + the exact set of
    ``(input_name, source_run_id)`` pairs in ``RunInput``.

    ``parent_run_ids`` entries may be ``"slot:id"`` strings or plain ints.

    Returns the run ID if found, None otherwise.
    """
    # Normalize to set of expected (slot, pid) tuples
    expected_inputs: set[tuple[str, int]] = set()
    if parent_run_ids:
        for entry in parent_run_ids:
            s = str(entry)
            if ":" in s:
                slot, pid_str = s.split(":", 1)
                expected_inputs.add((slot, int(pid_str)))
            else:
                expected_inputs.add(("upstream", int(s)))
    elif parent_run_id is not None:
        expected_inputs.add(("upstream", int(parent_run_id)))

    # Normalize params for comparison
    params_json = json.dumps(params, sort_keys=True) if params else None

    with get_session() as session:
        stmt = (
            select(Run)
            .join(Method, Run.method_id == Method.id)
            .where(Method.name == method_name)
            .where(Run.sample == sample)
            .where(Run.status == "completed")
        )
        stmt = stmt.order_by(Run.finished_at.desc())  # type: ignore[union-attr]
        candidates = session.exec(stmt).all()

        for run in candidates:
            # Check params match (JSON-normalized comparison)
            run_params_json = json.dumps(run.params, sort_keys=True) if run.params else None
            if run_params_json != params_json:
                continue

            # Check (slot, parent_id) pairs match exactly
            input_stmt = select(RunInput).where(RunInput.run_id == run.id)
            run_inputs = session.exec(input_stmt).all()
            actual_inputs = {
                (ri.input_name or "upstream", ri.source_run_id)
                for ri in run_inputs
            }

            if actual_inputs != expected_inputs:
                continue

            # Verify archived output still exists
            run_dir = _run_archive_dir(run.id)
            if not run_dir.exists():
                continue

            return run.id

    return None


# =============================================================================
# pre_run  (Gap 15: versioning + cache check + run registration in one step)
# =============================================================================

@workflow(purpose="Version-aware pre-run hook: git commit check, cache lookup, run registration")
def pre_run(
    method_name: str,
    module_name: str,
    sample: str,
    params: dict | None = None,
    parent_run_ids: list | None = None,
    pipeline_id: str | None = None,
    nf_process_name: str | None = None,
    repo_path: str | None = None,
    git_commit: str | None = None,
    nid: str | None = None,
) -> tuple[str, int]:
    """Git-commit check, input fingerprinting, cache lookup, and run registration.

    Replaces the separate ``check_cache`` → ``register_run`` sequence in
    Snakemake rules with a single call that also enforces version discipline.

    Returns:
        ``("CACHED", source_run_id)`` — cache hit; source_run_id is the
        original completed run whose archive should be reused.  A new Run row
        with ``cache_source_run_id`` set is inserted for lineage.

        ``("NEW", new_run_id)`` — cache miss; a fresh Run row with
        ``version_id`` and ``cache_key`` is inserted with status='running'.

    Raises:
        DirtyRepositoryError: If the working tree has uncommitted changes and
            ``git_commit`` was not pre-supplied.
        ValueError: If the method or module is not found in the DB.
    """
    from .version import (
        DirtyRepositoryError,
        build_cache_key,
        build_code_fingerprint,
        build_input_fingerprint,
        capture_env_content,
        get_git_commit,
        get_or_create_version,
        store_env_content,
    )

    params = params or {}

    口 = Step(step_num=1, name="Resolve git commit",
             purpose="Check working tree is clean; raises DirtyRepositoryError if dirty")
    # git_commit is kept as audit metadata only — not part of cache key.
    if git_commit is None:
        git_commit = get_git_commit(repo_path)

    口 = Step(step_num=2, name="Look up method",
             purpose="Query database for module and method rows")
    with get_session() as session:
        mod = session.exec(
            select(Module).where(Module.name == module_name)
        ).first()
        if mod is None:
            raise ValueError(f"Module '{module_name}' not found in DB")

        method = session.exec(
            select(Method).where(
                Method.name == method_name,
                Method.module_id == mod.id,
            )
        ).first()
        if method is None:
            raise ValueError(
                f"Method '{method_name}' not found in module '{module_name}'"
            )
        method_id: int = method.id  # type: ignore[assignment]
        method_env: str = method.env or "inherit"

    口 = Step(step_num=3, name="Build code fingerprint and version",
             purpose="Compute code fingerprint from registered source copy, get or create MethodVersion")
    method_source_dir = get_project_root() / "methods" / method_name
    code_fingerprint = build_code_fingerprint(method_source_dir)

    version_id = get_or_create_version(method_id, code_fingerprint, git_commit=git_commit)

    口 = Step(step_num=4, name="Normalize parent entries",
             purpose="Parse slot:id pairs and collect upstream run IDs")
    parent_entries: list[tuple[str, int]] = []
    upstream_run_ids: list[int] = []
    if parent_run_ids:
        for entry in parent_run_ids:
            s = str(entry)
            if ":" in s:
                slot, pid_str = s.split(":", 1)
                pid = int(pid_str)
            else:
                slot, pid = "upstream", int(s)
            parent_entries.append((slot, pid))
            upstream_run_ids.append(pid)

    口 = Step(step_num=5, name="Build input fingerprint",
             purpose="Cache key chaining via upstream Run.cache_key or sample hash")
    sample_ids: list[int] = []
    if not upstream_run_ids:
        # Root node — fingerprint the registered sample file
        with get_session() as session:
            samp = session.exec(
                select(Sample).where(Sample.name == sample)
            ).first()
            if samp is not None:
                sample_ids = [samp.id]  # type: ignore[list-item]

    input_fingerprint = build_input_fingerprint(upstream_run_ids, sample_ids)

    口 = Step(step_num=6, name="Capture env content",
             purpose="Resolve the method's env backend and capture a deterministic "
                     "content blob (lock + pip freeze, or interpreter identity + freeze)")
    project_dir_for_env = get_project_root()
    env_content = capture_env_content(method_env, project_dir_for_env)

    口 = Step(step_num=7, name="Store env content in DVC cache",
             purpose="Hash the env blob and store it under .dvc/cache/files/md5/; "
                     "the returned md5 is the env_fingerprint persisted on the Run row")
    env_fingerprint = store_env_content(env_content, project_dir_for_env)

    口 = Step(step_num=8, name="Build cache key",
             purpose="Combine code_fingerprint + params + input_fingerprint + env_fingerprint into cache key")
    cache_key = build_cache_key(
        code_fingerprint, params, input_fingerprint, env_fingerprint
    )

    口 = Step(step_num=9, name="Cache lookup and registration",
             purpose="Query by cache_key; return CACHED:{id} on hit or register new run on miss")
    with get_session() as session:
        stmt = (
            select(Run)
            .join(Method, Run.method_id == Method.id)
            .where(Method.name == method_name)
            .where(Run.sample == sample)
            .where(Run.status == "completed")
            .where(Run.cache_key == cache_key)
            .where(Run.cache_source_run_id == None)  # noqa: E711  exclude audit rows
        )
        stmt = stmt.order_by(Run.finished_at.desc())  # type: ignore[union-attr]
        hit = session.exec(stmt).first()

        if hit is not None:
            # Verify archive still exists (deleted archive = miss)
            if not _run_archive_dir(hit.id).exists():
                hit = None

    if hit is not None:
        # -- Cache HIT: insert an audit Run row, return the AUDIT row's ID --
        # The return value is the newly-inserted audit row, not the cached
        # source. Callers (run_step, sidecar writer) then record lineage and
        # write workspace sidecars with the audit ID, so downstream nodes
        # wire their ``parent_run_ids`` to this pipeline's sibling audits
        # instead of the old pipeline's source runs. The cached source is
        # still reachable via ``Run.cache_source_run_id`` when a caller
        # actually needs it (e.g. to find the RunOutput rows for restore).
        source_run_id: int = hit.id  # type: ignore[assignment]
        with get_session() as session:
            audit_run = Run(
                method_id=method_id,
                params=params,
                sample=sample,
                status="completed",
                pipeline_id=pipeline_id,
                nf_process_name=nf_process_name,
                started_at=datetime.now(timezone.utc),
                finished_at=datetime.now(timezone.utc),
                version_id=version_id,
                cache_key=cache_key,
                cache_source_run_id=source_run_id,
                env_fingerprint=env_fingerprint,
                nid=nid,
            )
            session.add(audit_run)
            session.commit()
            session.refresh(audit_run)
            audit_run_id: int = audit_run.id  # type: ignore[assignment]

            # Record lineage for the audit row. Without these rows, PathsView
            # and the DescendantTree treat the audit run as disconnected —
            # every cache-hit branch of a fan-out pipeline shows up as an
            # orphan instead of as a terminal in its sample's sub-DAG.
            for slot, pid in parent_entries:
                session.add(RunInput(
                    run_id=audit_run_id,
                    source_run_id=pid,
                    input_name=slot,
                ))
            if parent_entries:
                session.commit()
        return ("CACHED", audit_run_id)

    # -- Cache MISS: register fresh run --
    with get_session() as session:
        mod = session.exec(
            select(Module).where(Module.name == module_name)
        ).first()
        run = Run(
            method_id=method_id,
            params=params,
            sample=sample,
            status="running",
            pipeline_id=pipeline_id,
            nf_process_name=nf_process_name,
            started_at=datetime.now(timezone.utc),
            version_id=version_id,
            cache_key=cache_key,
            env_fingerprint=env_fingerprint,
            nid=nid,
        )
        session.add(run)
        session.commit()
        session.refresh(run)
        new_run_id: int = run.id  # type: ignore[assignment]

        for slot, pid in parent_entries:
            session.add(RunInput(
                run_id=new_run_id,
                source_run_id=pid,
                input_name=slot,
            ))
        if parent_entries:
            session.commit()

        _run_archive_dir(new_run_id).mkdir(parents=True, exist_ok=True)

    return ("NEW", new_run_id)


# =============================================================================
# restore_output
# =============================================================================

@task(purpose="Restore a cached run's output from DVC cache into the workspace path")
def restore_output(run_id: int, workspace_output: str, output_name: str | None = None) -> None:
    """Restore a cached run's output into the workspace path.

    ADR-007 Phase 2: restores exclusively from the DVC content-addressed
    cache using ``RunOutput.content_hash``.  If content_hash is null
    (run predates content-hash integration), exits with a clear error.

    Idempotent: ``restore_from_cache`` handles integrity verification
    internally -- if the file already exists with matching content hash,
    the restore is skipped; if the hash mismatches, the file is replaced.

    Also writes run_id.txt sidecar so downstream rules can find the parent.

    Args:
        run_id: The run whose output to restore.
        workspace_output: Destination workspace path for the hardlink.
        output_name: Specific output filename to restore (for multi-output runs).
            If ``None``, restores the first output found (single-output compat).
    """
    project_dir = get_project_root()
    with get_session() as session:
        run = session.get(Run, run_id)
        if run is None:
            print(f"ERROR: run {run_id} not found", file=sys.stderr)
            sys.exit(1)

        # Find the output artifact (filter by name for multi-output runs)
        output_stmt = select(RunOutput).where(RunOutput.run_id == run_id)
        if output_name is not None:
            output_stmt = output_stmt.where(RunOutput.output_name == output_name)
        ro = session.exec(output_stmt).first()
        if ro is None:
            name_hint = f" with name {output_name!r}" if output_name else ""
            print(f"ERROR: no output found for run {run_id}{name_hint}", file=sys.stderr)
            sys.exit(1)

        ws_path = Path(workspace_output)
        ws_path.parent.mkdir(parents=True, exist_ok=True)

        if ro.content_hash:
            # Restore from DVC cache (handles idempotency: skips if dest
            # already exists with matching hash, replaces if mismatched)
            from .provenance import restore_from_cache, pull_cache
            restored = restore_from_cache(ro.content_hash, ws_path, project_dir)
            if not restored:
                # Try pulling from remote first, then restore again
                pull_cache([ro.content_hash], project_dir)
                restored = restore_from_cache(ro.content_hash, ws_path, project_dir)

            if not restored:
                print(
                    f"ERROR: cannot restore output for run {run_id} "
                    f"(content_hash={ro.content_hash} not found in DVC cache)",
                    file=sys.stderr,
                )
                sys.exit(1)
        elif ro.artifact_path and Path(ro.artifact_path).exists():
            # Deferred archiving: content_hash is NULL, copy from archive dir
            _publish_to_workspace(Path(ro.artifact_path), ws_path)
        else:
            print(
                f"ERROR: Run output has no content_hash and artifact not found "
                f"at {ro.artifact_path} — cannot restore run {run_id}.",
                file=sys.stderr,
            )
            sys.exit(1)

        # Write sidecar
        sidecar = ws_path.parent / "run_id.txt"
        sidecar.write_text(str(run_id))


# =============================================================================
# restore_sample (ADR-009)
# =============================================================================

@task(purpose="Restore a registered sample from DVC cache to data/samples/")
def restore_sample(
    name: str,
    content_hash: str | None = None,
    project_root: Path | None = None,
) -> None:
    """Restore a sample file from the DVC cache into ``data/samples/{name}/``.

    Called by Snakemake ``restore_sample`` rules to lazily materialize
    sample files before root pipeline steps execute.

    If the sample's ``content_hash`` is NULL (legacy sample registered
    before DVC integration), exits with an error directing the user to
    re-register the sample.

    Idempotent: ``restore_from_cache`` handles integrity verification
    internally -- if the file already exists with matching content hash,
    the restore is skipped; if the hash mismatches, the file is replaced.

    Args:
        name: Sample identifier.
        content_hash: Expected content hash (passed from Snakemake rule).
            If not provided, looked up from the database.
        project_root: Project root directory (defaults to cwd).

    Raises:
        SystemExit: If the sample is not found, has no content_hash, or
            the cache entry is missing.
    """
    if project_root is None:
        project_root = get_project_root()

    with get_session() as session:
        sample = session.exec(
            select(Sample).where(Sample.name == name)
        ).first()
        if sample is None:
            print(f"ERROR: sample '{name}' not found in the database.", file=sys.stderr)
            sys.exit(1)

        # Use DB content_hash if not passed explicitly
        hash_val = content_hash or sample.content_hash
        if not hash_val:
            print(
                f"ERROR: Sample '{name}' has no content_hash — it was registered "
                f"before DVC integration. Re-register it with: "
                f"pm register-sample --name {name} --source <path>",
                file=sys.stderr,
            )
            sys.exit(1)

        dest = Path(sample.registered_path)

        # Restore from DVC cache (handles idempotency: skips if dest
        # already exists with matching hash, replaces if mismatched)
        from .provenance import restore_from_cache, pull_cache
        restored = restore_from_cache(hash_val, dest, project_root)
        if not restored:
            # Try pulling from remote first, then restore again
            pull_cache([hash_val], project_root)
            restored = restore_from_cache(hash_val, dest, project_root)

        if not restored:
            print(
                f"ERROR: cannot restore sample '{name}' "
                f"(content_hash={hash_val} not found in DVC cache). "
                f"Try running: pm pull",
                file=sys.stderr,
            )
            sys.exit(1)

        # Touch the Snakemake sentinel marker. ADR-009 keeps sample files in
        # the DVC cache rather than under data/samples/<name>/, so Snakemake
        # can't use the sample file itself as the rule output. We use a
        # sentinel at <project_root>/data/samples/<name>/.sample_ready and
        # create the parent directory if missing — the path is absolute via
        # get_project_root() so it is cwd-independent (critical for Windows
        # UNC shell rules where cmd.exe rewrites cwd to C:\Windows).
        sentinel = project_root / "data" / "samples" / name / ".sample_ready"
        sentinel.parent.mkdir(parents=True, exist_ok=True)
        sentinel.touch()


# =============================================================================
# cleanup_workspace
# =============================================================================

def cleanup_workspace() -> None:
    """Delete .runs/workspace/ directory.

    Called before generating a new pipeline to ensure a clean slate.
    Safe because workspace only contains hardlinks -- real data lives
    in .runs/{id}/ archive directories.
    """
    workspace = runs_dir() / "workspace"
    if workspace.exists():
        shutil.rmtree(workspace)
        print("Cleaned up workspace")
    else:
        print("No workspace to clean up")


# =============================================================================
# finalize_pipeline
# =============================================================================

def finalize_pipeline(pipeline_id: str) -> None:
    """Log successful pipeline completion.

    Workspace is NOT deleted here -- it stays so re-runs of the same
    pipeline are instant ('Nothing to be done'). Cleanup happens at
    generation time via cleanup_workspace.
    """
    print(f"Pipeline {pipeline_id} completed successfully")


# =============================================================================
# fail_pipeline
# =============================================================================

def fail_pipeline(pipeline_id: str) -> None:
    """Mark any in-flight runs for this pipeline as 'failed'.

    Already-completed runs are left untouched (their data is safe in .runs/{id}/).
    Workspace is preserved for debugging.
    """
    with get_session() as session:
        stmt = (
            select(Run)
            .where(Run.pipeline_id == pipeline_id)
            .where(Run.status == "running")
        )
        in_flight = session.exec(stmt).all()
        for run in in_flight:
            run.status = "failed"
            run.finished_at = datetime.now(timezone.utc)
            # ADR 004: only set error fields if not already populated
            # (the try/except in the generated rule may have already called
            # complete_run with error details before fail_pipeline runs)
            if run.error_message is None:
                run.error_message = f"Pipeline {pipeline_id} failed (orphaned run)"
            if run.error_traceback is None:
                run.error_traceback = "No traceback available (run was still in-flight when pipeline failed)"
        session.commit()

        n = len(in_flight)
        if n > 0:
            print(f"Marked {n} in-flight run(s) as failed for pipeline {pipeline_id}")
        else:
            print(f"No in-flight runs to mark for pipeline {pipeline_id}")
        print("Workspace preserved for debugging")


# =============================================================================
# _write_cancelled_rows  (pipeline-end diff-and-walk)
# =============================================================================


def _write_cancelled_rows(pipeline_id: str, project_root: str) -> int:
    """Persist first-class 'cancelled' Run rows for targets that did not run.

    Called at pipeline-end (both success and failure paths) from
    ``run_pipeline``. For every expected ``(node_id, sample, variant)``
    triple produced by ``expand_variant_combos``, if the DB does not
    already contain a matching Run row, walk upstream through the frozen
    DAG (``StepDef.depends_on``) until we hit a run with
    ``status='failed'``. Write a Run row with ``status='cancelled'`` and
    ``cancelled_due_to_run_id`` pointing at that failed ancestor.

    Idempotent: triples that already have any Run row (any status) are
    skipped. Re-invocation writes no duplicates.

    Always-on (D-4): on a fully-successful pipeline this finds zero
    missing triples and writes zero rows -- the cost of the walk is
    O(steps * samples * variants) DB reads.

    Tiebreak when multiple failed ancestors are equidistant (D-3):
    lowest ``run.id``.

    Args:
        pipeline_id: The pipeline execution ID to reconcile.
        project_root: Absolute path to the pm project root (used to
            locate ``.runs/pipelines/<pid>/pipeline.json``).

    Returns:
        Number of cancelled rows written (useful for tests / logging).
    """
    from .snakemake_gen import load_pipeline, expand_variant_combos

    pipeline_json = (
        Path(project_root) / ".runs" / "pipelines" / pipeline_id / "pipeline.json"
    )
    if not pipeline_json.exists():
        # Nothing to reconcile -- no frozen pipeline doc means the run
        # never reached the snake-gen stage (or was cleaned up).
        return 0

    try:
        pipeline = load_pipeline(pipeline_json)
    except Exception as exc:
        print(
            f"[cancelled-walk] Failed to load pipeline.json for {pipeline_id}: {exc}",
            file=sys.stderr,
        )
        return 0

    steps = pipeline.steps
    if not steps:
        return 0

    # Build a map from StepDef.node_id → canvas label (stored as Run.nid
    # when present).  When a user labels a canvas node, that label is
    # persisted both into pipeline.json nodes (``label`` attribute) and
    # onto the Run row (``Run.nid``).  Using (nid, sample) as the triple
    # key avoids collisions when two canvas nodes share the same
    # method + sample + params (impossible in a normal pipeline, but
    # possible when the same method is parameter-swept in different
    # branches that happen to collapse identically).  Fall back to
    # (method_name, sample, params_fp) for steps without a label.
    node_id_to_nid: dict[str, str] = {}
    try:
        raw_pipeline_doc = json.loads(pipeline_json.read_text())
        for raw_node in raw_pipeline_doc.get("nodes", []):
            raw_id = str(raw_node.get("id", ""))
            label = raw_node.get("label") or None
            if raw_id and label:
                node_id_to_nid[raw_id] = str(label)
                # Legacy node_id == method_name fallback (see load_pipeline
                # line ~315): when pipeline uses plain int IDs and method
                # names are unique, StepDef.node_id collapses to method.
                method_name = raw_node.get("method")
                if method_name and raw_id.isdigit():
                    node_id_to_nid.setdefault(method_name, str(label))
    except (OSError, json.JSONDecodeError):
        # Malformed pipeline.json -- silently fall back to method-keyed
        # matching so the rest of the walk still functions.
        node_id_to_nid = {}

    # Build per-node variant→params map identical to generate_snakefile's
    # resolved_params (keyed by node_id; fall back to method_name; default
    # variant "default" when no param_sets entry exists).
    resolved_params: dict[str, dict[str, dict]] = {}
    for step in steps:
        resolved_params[step.node_id] = pipeline.param_sets.get(
            step.node_id,
            pipeline.param_sets.get(
                step.method_name, {"default": step.params}
            ),
        )

    # Pad: every node carries every variant name (matching snake-gen's
    # behaviour so expand_variant_combos enumerates exhaustively).
    all_variant_names: set[str] = set()
    for variants in resolved_params.values():
        all_variant_names.update(variants.keys())
    variant_names = sorted(all_variant_names) if all_variant_names else ["default"]
    for step in steps:
        for vname in variant_names:
            if vname not in resolved_params[step.node_id]:
                resolved_params[step.node_id][vname] = step.params

    combos = expand_variant_combos(
        steps=steps,
        samples=pipeline.samples,
        resolved_params=resolved_params,
        explicit_combos=pipeline.explicit_combos,
    )

    # DAG adjacency keyed by node_id (upstream parents for BFS).
    step_by_nid: dict[str, Any] = {s.node_id: s for s in steps}

    with get_session() as session:
        # Pre-load all Run rows for this pipeline_id plus the Method and
        # Module names we need for triple-matching and for writing new
        # cancelled rows.
        existing_runs = session.exec(
            select(Run).where(Run.pipeline_id == pipeline_id)
        ).all()

        # Build set of actual triples seen in the DB.
        # triple = (node_id, sample, params_fingerprint)
        method_by_id: dict[int, Method] = {}
        module_name_by_method_id: dict[int, str] = {}

        # Batch-load methods to resolve method_id -> (name, module_id)
        method_ids = {r.method_id for r in existing_runs if r.method_id is not None}
        if method_ids:
            for m in session.exec(select(Method).where(Method.id.in_(method_ids))).all():
                method_by_id[m.id] = m  # type: ignore[index]
            mod_ids = {m.module_id for m in method_by_id.values()}
            if mod_ids:
                mods = session.exec(select(Module).where(Module.id.in_(mod_ids))).all()
                mod_name_by_id = {m.id: m.name for m in mods}
                for mid, m in method_by_id.items():
                    module_name_by_method_id[mid] = mod_name_by_id.get(m.module_id, "")

        # Helper: normalised params fingerprint for equality matching.
        def _fp(params: dict | None) -> str:
            return json.dumps(params or {}, sort_keys=True, default=str)

        # Triples that already have a Run row (any status). The walk
        # uses this set for its presence check (idempotency + cache-hit
        # safety), so we include cancelled rows too.
        #
        # Preferred keying is (nid, sample, "") when the Run has a
        # non-empty ``nid`` and the pipeline carries a matching label --
        # this disambiguates two canvas nodes that share method+sample+
        # params but occupy distinct graph positions.  Falls back to the
        # original (method_name, sample, params_fingerprint) when no nid
        # is present (pre-existing pipelines without labels still work).
        actual_triples: set[tuple[str, str, str]] = set()
        for r in existing_runs:
            m = method_by_id.get(r.method_id)
            if m is None:
                continue
            if r.nid and r.nid in node_id_to_nid.values():
                # Nid-based keying: ("__nid__", nid, sample)
                actual_triples.add(("__nid__", r.nid, r.sample or ""))
            actual_triples.add((m.name, r.sample or "", _fp(r.params)))

        # Failed-run lookup keyed by triple -> lowest run.id (D-3 tiebreak).
        # Both keying styles are populated so the BFS walk can look up via
        # whichever discriminator is available on the ancestor step.
        failed_by_triple: dict[tuple[str, str, str], int] = {}
        for r in existing_runs:
            if r.status != "failed":
                continue
            m = method_by_id.get(r.method_id)
            if m is None:
                continue
            keys: list[tuple[str, str, str]] = [
                (m.name, r.sample or "", _fp(r.params))
            ]
            if r.nid and r.nid in node_id_to_nid.values():
                keys.append(("__nid__", r.nid, r.sample or ""))
            for key in keys:
                prior = failed_by_triple.get(key)
                if prior is None or (r.id is not None and r.id < prior):
                    failed_by_triple[key] = r.id  # type: ignore[assignment]

        # BFS upstream in the DAG from a given node to find the nearest
        # failed ancestor for a (sample, variant) combo. Same-depth hits
        # are collected together and tie-broken by lowest run id.
        def _find_failed_ancestor(
            start_nid: str, sample: str, variant: str
        ) -> int | None:
            from collections import deque

            seen: set[str] = set()
            # Frontier carries a list of node ids at the current depth;
            # BFS proceeds level-by-level so all equidistant hits land
            # in the same sweep.
            frontier: list[str] = list(step_by_nid.get(start_nid).depends_on) \
                if start_nid in step_by_nid else []
            while frontier:
                level_hits: list[int] = []
                next_frontier: list[str] = []
                for nid in frontier:
                    if nid in seen:
                        continue
                    seen.add(nid)
                    anc_step = step_by_nid.get(nid)
                    if anc_step is None:
                        continue
                    # Compute the sample this ancestor would have run on:
                    # collapsed ancestors always run as "__all__".
                    anc_sample = "__all__" if anc_step.sample_collapsed else sample
                    variants_for_anc = resolved_params.get(anc_step.node_id, {})
                    anc_params = variants_for_anc.get(variant, anc_step.params)
                    # Prefer nid-based lookup when the ancestor step has a
                    # canvas label -- disambiguates same-method collisions.
                    rid: int | None = None
                    anc_nid = node_id_to_nid.get(anc_step.node_id)
                    if anc_nid is not None:
                        rid = failed_by_triple.get(
                            ("__nid__", anc_nid, anc_sample)
                        )
                    if rid is None:
                        rid = failed_by_triple.get(
                            (anc_step.method_name, anc_sample, _fp(anc_params))
                        )
                    if rid is not None:
                        level_hits.append(rid)
                    # Always traverse through to upstream parents (a
                    # successful intermediate doesn't block finding the
                    # originating failure further upstream).
                    next_frontier.extend(anc_step.depends_on)
                if level_hits:
                    return min(level_hits)
                frontier = next_frontier
            return None

        # Modules/methods we need to look up for new rows. Group by
        # (module, method) so we only hit the DB once per unique pair.
        new_rows: list[Run] = []
        warned_missing_methods: set[tuple[str, str]] = set()

        for step in steps:
            for combo in combos:
                sample = combo["sample"]
                variant = combo["variant"]
                # Collapsed steps bake the sample axis to "__all__"; the
                # rest run once per sample.
                effective_sample = "__all__" if step.sample_collapsed else sample
                variants_for_step = resolved_params.get(step.node_id, {})
                params = variants_for_step.get(variant, step.params)
                # Presence check: prefer nid keying when the step has a
                # canvas label; fall back to method+sample+params_fp only
                # for steps without a label.  Falling back for labelled
                # steps would let a sibling branch's run mask a missing
                # same-method+params row here (the whole point of
                # nid-keying is to disambiguate that case).
                step_nid = node_id_to_nid.get(step.node_id)
                triple = (step.method_name, effective_sample, _fp(params))
                nid_triple: tuple[str, str, str] | None = (
                    ("__nid__", step_nid, effective_sample)
                    if step_nid is not None else None
                )
                if nid_triple is not None:
                    if nid_triple in actual_triples:
                        continue
                else:
                    if triple in actual_triples:
                        continue

                # Missing triple -- walk upstream to find the cause.
                cause_run_id = _find_failed_ancestor(
                    step.node_id, effective_sample, variant
                )
                if cause_run_id is None:
                    # No failed ancestor -- this can happen on a
                    # legitimately-skipped branch (shouldn't in practice).
                    # Architect guidance: write the row with NULL cause,
                    # log a warning. Choose to skip here to avoid
                    # polluting history with rows the user can't act on
                    # from the banner. Log for debugging.
                    print(
                        f"[cancelled-walk] no failed ancestor for "
                        f"({step.node_id}, {effective_sample}, {variant}) "
                        f"in pipeline {pipeline_id}; skipping",
                        file=sys.stderr,
                    )
                    continue

                # Look up method_id -- skip with a warning if the method
                # has been unregistered since the run was scheduled (D-1).
                method_key = (step.method_name, step.module_name)
                mod = session.exec(
                    select(Module).where(Module.name == step.module_name)
                ).first()
                if mod is None:
                    if method_key not in warned_missing_methods:
                        warned_missing_methods.add(method_key)
                        print(
                            f"[cancelled-walk] module '{step.module_name}' "
                            f"not registered; skipping cancelled rows for "
                            f"method '{step.method_name}'",
                            file=sys.stderr,
                        )
                    continue
                method_row = session.exec(
                    select(Method).where(
                        Method.name == step.method_name,
                        Method.module_id == mod.id,
                    )
                ).first()
                if method_row is None:
                    if method_key not in warned_missing_methods:
                        warned_missing_methods.add(method_key)
                        print(
                            f"[cancelled-walk] method "
                            f"'{step.module_name}.{step.method_name}' not "
                            f"registered; skipping cancelled row",
                            file=sys.stderr,
                        )
                    continue

                new_row = Run(
                    method_id=method_row.id,  # type: ignore[arg-type]
                    params=params,
                    sample=effective_sample,
                    status="cancelled",
                    pipeline_id=pipeline_id,
                    started_at=None,
                    finished_at=None,
                    cancelled_due_to_run_id=cause_run_id,
                    nid=step_nid,
                )
                new_rows.append(new_row)
                # Mark the triple as now present so repeated steps don't
                # double-write (paranoia against combo duplication).
                actual_triples.add(triple)
                if nid_triple is not None:
                    actual_triples.add(nid_triple)

        if new_rows:
            for r in new_rows:
                session.add(r)
            session.commit()
            print(
                f"[cancelled-walk] wrote {len(new_rows)} cancelled row(s) "
                f"for pipeline {pipeline_id}"
            )

    return len(new_rows)


# =============================================================================
# resolve_input
# =============================================================================

def resolve_input(run_id: int) -> str | None:
    """Return the output path for a given run ID, restoring from cache if needed.

    Three-tier resolution (ADR-011):
      HOT  -- artifact_path exists on disk, return immediately.
      WARM -- artifact missing but content_hash found in local DVC cache;
              restore to artifact_path, then return.
      COLD -- artifact and local cache both missing; pull from DVC remote,
              restore, then return.
      FAIL -- all restore attempts fail; return None.

    For runs predating content-hash integration (content_hash is None),
    the artifact_path is returned as-is (no restore attempt possible).

    Args:
        run_id: The run whose output to resolve.

    Returns:
        The artifact path string if the output exists (or was restored),
        or None if the run/output is not found or restoration failed.
    """
    project_dir = get_project_root()

    with get_session() as session:
        run = session.get(Run, run_id)
        if run is None:
            return None

        output_stmt = select(RunOutput).where(RunOutput.run_id == run_id)
        ro = session.exec(output_stmt).first()
        if ro is None:
            return None

        artifact = Path(ro.artifact_path)

        # HOT path: artifact exists on disk
        if artifact.exists():
            print(f"resolve_input: HOT (run {run_id})", file=sys.stderr)
            return ro.artifact_path

        # No content_hash -- backward compat: return path as-is
        if not ro.content_hash:
            return ro.artifact_path

        # WARM path: restore from local DVC cache
        from .provenance import restore_from_cache, pull_cache

        restored = restore_from_cache(ro.content_hash, artifact, project_dir)
        if restored:
            print(f"resolve_input: WARM (run {run_id})", file=sys.stderr)
            return ro.artifact_path

        # COLD path: pull from remote, then restore
        pull_cache([ro.content_hash], project_dir)
        restored = restore_from_cache(ro.content_hash, artifact, project_dir)
        if restored:
            print(f"resolve_input: COLD (run {run_id})", file=sys.stderr)
            return ro.artifact_path

        # FAIL: all attempts exhausted
        print(
            f"resolve_input: FAIL (run {run_id}, "
            f"content_hash={ro.content_hash} not found in any cache)",
            file=sys.stderr,
        )
        return None


# =============================================================================
# register_sample
# =============================================================================

@task(purpose="Register a data sample by copying it into the managed data directory")
def register_sample(
    name: str,
    source_path: Path,
    project_root: Path | None = None,
    registration_mode: str = "copy",
) -> Path:
    """Copy a data file into ``data/samples/{name}/``, content-hash it via
    DVC, store it in the DVC cache, and record it in the DB.

    DVC must be configured (``[dvc]`` section in ``wf-canvas.toml``).
    If DVC is not configured, raises ``DvcNotConfiguredError`` before any
    file copy or DB write occurs.

    If a sample with the same name already exists, raises an error.

    Args:
        name: Sample identifier (e.g. 'CFPAC_ERKi').
        source_path: Path to the source data file.
        project_root: Project root directory (defaults to cwd).
        registration_mode: Only ``"copy"`` is implemented. ``"link"`` is
            reserved for a future path-only registration mode.

    Returns:
        The path to the registered copy of the file.

    Raises:
        FileNotFoundError: If the source file does not exist.
        NotImplementedError: If ``registration_mode != "copy"``.
        ValueError: If a sample with this name is already registered.
        DvcNotConfiguredError: If DVC is not configured.
    """
    if registration_mode != "copy":
        raise NotImplementedError(
            f"registration_mode={registration_mode!r} is not implemented. "
            "Only 'copy' is supported."
        )
    source_path = Path(source_path).resolve()
    if not source_path.exists():
        raise FileNotFoundError(f"Source file not found: {source_path}")

    if project_root is None:
        project_root = get_project_root()

    # DVC gate: require [dvc] config before any file operations (ADR-009)
    from .provenance import ensure_dvc_ready, hash_path, cache_file, push_cache
    ensure_dvc_ready(project_root)

    # Per ADR-009: do NOT copy into data/samples/. The DVC cache is the sole
    # store; data/samples/ is ephemeral workspace, populated lazily by the
    # Snakemake restore_sample rule. registered_path is a contract (where the
    # file WILL be restored) not a claim that it exists there now.
    dest = project_root / "data" / "samples" / name / source_path.name

    # Capture size and mtime FROM THE SOURCE FILE.
    src_stat = source_path.stat()
    src_file_size = src_stat.st_size
    src_file_mtime = src_stat.st_mtime

    # Content-hash the source and store in DVC cache (ADR-009)
    content_hash = hash_path(source_path)
    cache_file(source_path, content_hash, project_root)

    # Push to DVC remote (best-effort — graceful skip if remote not configured)
    try:
        push_cache([content_hash], project_root)
    except Exception as exc:
        print(f"WARNING: DVC push failed ({exc}); sample is in local cache only.",
              file=sys.stderr)

    # Record in DB
    with get_session() as session:
        existing = session.exec(
            select(Sample).where(Sample.name == name)
        ).first()
        if existing is not None:
            raise ValueError(f"Sample '{name}' is already registered (id={existing.id})")

        sample = Sample(
            name=name,
            source_path=str(source_path),
            registered_path=str(dest),
            file_type=source_path.suffix.lstrip("."),
            file_size=src_file_size,
            file_mtime=src_file_mtime,
            registration_mode="copy",
            content_hash=content_hash,
        )
        session.add(sample)
        session.commit()

    return dest


# =============================================================================
# run-pipeline  — generate Snakefile + invoke snakemake
# =============================================================================

@workflow(
    purpose="Generate a Snakefile from a pipeline JSON and execute it via Snakemake",
    inputs="Pipeline JSON path, project root, cores",
    outputs="Completed pipeline; all run rows written to DB",
)
def run_pipeline(
    pipeline_path: str,
    project_root: str | None = None,
    pm_root: str | None = None,
    cores: int = 4,
    snakefile_path: str | None = None,
    pipeline_id: str | None = None,
    capture_output: bool = False,
    archive: bool = True,
    keep_going: bool = False,
) -> int:
    """Generate a Snakefile from a pipeline JSON and run it with Snakemake.

    This is the single entry-point the GUI (or any caller) uses to execute a
    pipeline.  It handles Snakefile generation, git-commit resolution, and
    Snakemake invocation internally -- callers never need to touch snakemake
    directly.

    After successful pipeline completion, an archive pass hashes and caches
    all un-archived outputs (deferred archiving).  Controlled by the
    ``archive`` parameter (default: True).

    Args:
        pipeline_path: Path to the pipeline JSON file.
        project_root: Root of the pm project (git repo with method commits).
            Defaults to the current working directory.
        pm_root: Path added to PYTHONPATH in worker processes so ``import pm``
            works.  Defaults to the directory containing the ``pm`` package
            (i.e. the location of this file's parent).
        cores: Number of Snakemake cores (default: 4).
        snakefile_path: Where to write the generated Snakefile.  Defaults to
            ``<project_root>/Snakefile``.
        pipeline_id: Optional caller-provided pipeline ID.  When provided,
            this ID is used instead of generating a new UUID.  This ensures
            the canvas server and run_pipeline share the same ID for status
            tracking.  When omitted (CLI usage), a new UUID is generated.
        capture_output: When True, redirect stdout/stderr to log files in the
            pipeline log directory (used by the canvas server for log capture).
            When False (default, CLI usage), leave stdout/stderr connected to
            the terminal.
        archive: When True (default), run the deferred archive pass after
            successful pipeline completion.  When False, leave outputs
            un-archived (content_hash=NULL).
        keep_going: When True, pass ``--keep-going`` to Snakemake so a
            failure in one job doesn't cancel jobs that have no dependency
            on the failed one.  Useful for fan-out pipelines where each
            sample is independent: one bad sample still lets the others
            complete.  Default False (Snakemake's default fail-fast).

    Returns:
        Snakemake exit code (0 = success).
    """
    import subprocess as _sp
    from pathlib import Path as _P

    from .snakemake_gen import load_pipeline, generate_snakefile

    _project_root = str(_P(project_root).resolve() if project_root else _P.cwd())

    # Resolve pm_root: caller can supply explicitly (test always should); in
    # production we discover it from pm's own __file__ (installed package).
    if pm_root is None:
        import pm as _pm_pkg
        pm_root = str(_P(_pm_pkg.__file__).parent.parent)

    import uuid as _uuid

    口 = AutoStep(step_num=1, name="Load pipeline")
    pipeline = load_pipeline(_P(pipeline_path))

    # ADR 004: Generate pipeline ID and create log directories before Snakemake
    _pipeline_id = pipeline_id if pipeline_id is not None else str(_uuid.uuid4())
    _pipeline_log_dir = _P(_project_root) / ".runs" / "pipelines" / _pipeline_id
    _pipeline_log_dir.mkdir(parents=True, exist_ok=True)
    (_pipeline_log_dir / "runs").mkdir(exist_ok=True)

    口 = AutoStep(step_num=2, name="Generate Snakefile")
    content = generate_snakefile(
        pipeline, pm_root, project_root=_project_root, pipeline_id=_pipeline_id,
        pipeline_json_path=str(_P(pipeline_path).resolve()),
    )

    口 = Step(
        step_num=3,
        name="Write Snakefile to disk",
        purpose="Serialize the generated Snakefile content to <project_root>/Snakefile",
        inputs="Generated Snakefile content string",
        outputs="Snakefile written to sf_path",
    )
    sf_path = _P(snakefile_path) if snakefile_path else _pipeline_log_dir / "Snakefile"
    sf_path.write_text(content, encoding="utf-8")
    print(f"Snakefile written to {sf_path}")

    口 = Step(
        step_num=4,
        name="Invoke Snakemake",
        purpose="Execute the generated Snakefile via snakemake subprocess to run all pipeline rule instances",
        inputs="Snakefile at sf_path, pm project cwd, cores count",
        outputs="All pipeline runs completed; Run rows written to DB",
        critical="Executes all pipeline rules; raises RuntimeError on non-zero exit",
    )
    import os as _os
    _snake_env = {**_os.environ, "PYTHONIOENCODING": "utf-8"}
    # ADR 004: pass pipeline log dir so generated Snakefile can find it
    _snake_env["PM_PIPELINE_ID"] = _pipeline_id
    _snake_env["PM_PIPELINE_LOG_DIR"] = str(_pipeline_log_dir)
    # Explicitly forward DATABASE_URL so isolated test databases (set via
    # monkeypatch.setenv) are always seen by Snakemake worker processes even
    # when the env-var inheritance chain is broken (e.g. CI, --forked workers).
    _db_url = _os.environ.get("DATABASE_URL")
    if _db_url:
        _snake_env["DATABASE_URL"] = _db_url
    # Capture stdout/stderr to log files only when requested (canvas server).
    # CLI users get normal terminal output (capture_output=False by default).
    _snake_cmd = ["snakemake", "--cores", str(cores), "--snakefile", str(sf_path)]
    if keep_going:
        _snake_cmd.append("--keep-going")
    if capture_output:
        _stdout_log = _pipeline_log_dir / "stdout.log"
        _stderr_log = _pipeline_log_dir / "stderr.log"
        with open(_stdout_log, "w", encoding="utf-8") as _out_f, \
             open(_stderr_log, "w", encoding="utf-8") as _err_f:
            result = _sp.run(
                _snake_cmd,
                cwd=_project_root,
                env=_snake_env,
                stdout=_out_f,
                stderr=_err_f,
            )
        if result.returncode != 0:
            # Flip in-flight rows to 'failed' BEFORE the walk so BFS can
            # find them as failed ancestors. Best-effort -- the walk is
            # still useful even if fail_pipeline hit an issue.
            try:
                fail_pipeline(_pipeline_id)
            except Exception as _fp_exc:
                print(
                    f"[run_pipeline] fail_pipeline raised: {_fp_exc}",
                    file=sys.stderr,
                )
            try:
                _write_cancelled_rows(_pipeline_id, _project_root)
            except Exception as _walk_exc:
                print(
                    f"[run_pipeline] _write_cancelled_rows raised: {_walk_exc}",
                    file=sys.stderr,
                )
            _err_content = _stderr_log.read_text(encoding="utf-8", errors="replace")
            raise RuntimeError(
                f"Snakemake pipeline failed (exit {result.returncode}). "
                f"See logs in {_pipeline_log_dir}.\n{_err_content}"
            )
    else:
        result = _sp.run(
            _snake_cmd,
            cwd=_project_root,
            env=_snake_env,
        )
        if result.returncode != 0:
            try:
                fail_pipeline(_pipeline_id)
            except Exception as _fp_exc:
                print(
                    f"[run_pipeline] fail_pipeline raised: {_fp_exc}",
                    file=sys.stderr,
                )
            try:
                _write_cancelled_rows(_pipeline_id, _project_root)
            except Exception as _walk_exc:
                print(
                    f"[run_pipeline] _write_cancelled_rows raised: {_walk_exc}",
                    file=sys.stderr,
                )
            raise RuntimeError(
                f"Snakemake pipeline failed (exit {result.returncode}). "
                f"See logs in {_pipeline_log_dir}."
            )

    # -- Pipeline-end cancelled-row walk (success path) --
    # Always-on (D-4): on a fully-successful pipeline this is an O(nodes)
    # no-op. When Snakemake's --keep-going skipped some targets, it fills
    # in cancelled rows for the un-run triples before the archive pass.
    try:
        _write_cancelled_rows(_pipeline_id, _project_root)
    except Exception as _walk_exc:
        print(
            f"[run_pipeline] _write_cancelled_rows raised on success path: "
            f"{_walk_exc}",
            file=sys.stderr,
        )

    # -- Deferred archive pass --
    if archive:
        from .provenance import archive_outputs as _archive_outputs

        def _progress(name: str, status: str) -> None:
            print(f"  {name}: {status}")

        print("Archiving pipeline outputs...")
        _results = _archive_outputs(_project_root, progress_fn=_progress)
        archived = sum(1 for r in _results if r["status"] == "archived")
        if archived:
            print(f"Archived {archived} output(s).")
        else:
            print("No outputs to archive.")


# =============================================================================
# lookup_run (legacy — kept for backward compatibility)
# =============================================================================

def lookup_run(method_name: str, sample: str, nf_process_name: str | None = None) -> int | None:
    """Find the most-recent completed run for a method + sample.

    Legacy command — new pipelines use sidecar run_id.txt and check_cache instead.
    """
    with get_session() as session:
        stmt = (
            select(Run)
            .join(Method, Run.method_id == Method.id)
            .where(Method.name == method_name)
            .where(Run.sample == sample)
            .where(Run.status == "completed")
        )
        if nf_process_name is not None:
            stmt = stmt.where(Run.nf_process_name == nf_process_name)
        stmt = stmt.order_by(Run.finished_at.desc())  # type: ignore[union-attr]
        run = session.exec(stmt).first()
        return run.id if run else None


# =============================================================================
# run_step (ADR 008 — single-command step execution)
# =============================================================================

def _run_method_subprocess(
    cmd: list,
    *,
    cwd: str,
    env: dict,
    stdout_log: Path,
    stderr_log: Path,
):
    """Run the method subprocess, tee'ing stdout/stderr to per-run log files
    AND the parent process's std streams.

    Per-run logs land at ``stdout_log`` / ``stderr_log`` (typically inside
    ``.runs/<run_id>/``).  Output is also forwarded to the parent's
    stdout/stderr so Snakemake's pipeline-level capture and live CLI
    users still see output in real time.

    Returns a CompletedProcess-like object so callers keep using
    ``.returncode`` unchanged.  ``stdout``/``stderr`` on the result are
    always ``None`` — read the per-run log files instead.
    """
    import subprocess as _sp
    import threading

    stdout_log.parent.mkdir(parents=True, exist_ok=True)

    proc = _sp.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdout=_sp.PIPE,
        stderr=_sp.PIPE,
        text=True,
        bufsize=1,
    )

    def _pump(src, log_file, parent_stream):
        try:
            for line in iter(src.readline, ""):
                log_file.write(line)
                log_file.flush()
                try:
                    parent_stream.write(line)
                    parent_stream.flush()
                except Exception:
                    pass  # parent stream may be closed/redirected; logs still captured
        finally:
            try:
                src.close()
            except Exception:
                pass

    with open(stdout_log, "w", encoding="utf-8") as out_f, \
         open(stderr_log, "w", encoding="utf-8") as err_f:
        t_out = threading.Thread(
            target=_pump, args=(proc.stdout, out_f, sys.stdout), daemon=True
        )
        t_err = threading.Thread(
            target=_pump, args=(proc.stderr, err_f, sys.stderr), daemon=True
        )
        t_out.start()
        t_err.start()
        proc.wait()
        t_out.join()
        t_err.join()

    return _sp.CompletedProcess(
        args=cmd, returncode=proc.returncode, stdout=None, stderr=None
    )


@workflow(purpose="Execute a single pipeline step: pre_run, method dispatch, complete_run")
def run_step(
    node_id: str,
    sample: str,
    variant: str = "default",
    method_name: str | None = None,
    module_name: str | None = None,
    script_path: str | None = None,
    params: dict | None = None,
    parent_run_ids: list | None = None,
    pipeline_id: str | None = None,
    pipeline_json: str | None = None,
    git_commit: str | None = None,
    ref_inputs: list[str] | None = None,
) -> int:
    """Execute a single pipeline step end-to-end.

    Implements the 7-step execution protocol from ADR 008 + ADR 007:
    1. Load step config (from pipeline JSON or inline args)
    2. Call pre_run() for cache check + run registration
    3. On CACHED: restore_output() and write outcome sidecar
    4. On NEW: set PM_* env vars, run method subprocess
    5. Read metrics.json, scan outputs, create RunOutput rows
    6. Call complete_run(), write outcome sidecar
    7. Push artifacts to DVC remote (non-fatal)

    Args:
        node_id: Unique node identity within the pipeline.
        sample: Sample identifier.
        variant: Parameter variant name (default: "default").
        method_name: Method name (inline fallback).
        module_name: Module name (inline fallback).
        script_path: Path to method script (inline fallback).
        params: Parameter dict (inline fallback).
        parent_run_ids: Parent run IDs as slot:id or plain id strings.
        pipeline_id: Pipeline execution ID.
        pipeline_json: Path to pipeline JSON file.
        git_commit: Pre-computed git commit SHA.

    Returns:
        0 on success, 1 on failure.
    """
    import subprocess as _sp
    import traceback as _tb

    口 = Step(step_num=1, name="Resolve step config",
             purpose="Load node config from pipeline JSON or inline args")
    if pipeline_json is None:
        pipeline_json = os.environ.get("PM_PIPELINE_JSON")

    if pipeline_id is None:
        pipeline_id = os.environ.get("PM_PIPELINE_ID", "standalone")

    if pipeline_json and Path(pipeline_json).exists():
        # Load from pipeline JSON
        raw = json.loads(Path(pipeline_json).read_text())
        node_map = {str(n["id"]): n for n in raw["nodes"]}
        # Also try matching by method name for legacy pipelines
        method_map = {n["method"]: n for n in raw["nodes"]}
        node = node_map.get(node_id) or method_map.get(node_id)
        if node is None:
            print(f"ERROR: node '{node_id}' not found in pipeline JSON", file=sys.stderr)
            return 1
        method_name = method_name or node["method"]
        module_name = module_name or node["module"]
        script_path = script_path or node.get("script", f"methods/{method_name}/{method_name}.py")
        if params is None:
            # Look up variant params from param_sets or node params
            ps = raw.get("param_sets", {})
            node_ps = ps.get(node_id, ps.get(method_name, {}))
            params = node_ps.get(variant, node.get("params", {}))

    # Validate required inline args
    if not method_name or not module_name or not script_path:
        print("ERROR: --method, --module, and --script are required "
              "when --pipeline-json is not provided", file=sys.stderr)
        return 1
    params = params or {}

    # Extract custom NID label from pipeline JSON node (if present).
    # Parse pipeline JSON once and reuse for both NID extraction and
    # parent run resolution below.
    nid_label: str | None = None
    pipeline_data: dict | None = None
    if pipeline_json and Path(pipeline_json).exists():
        pipeline_data = json.loads(Path(pipeline_json).read_text())
        nodes_by_id = {str(n["id"]): n for n in pipeline_data["nodes"]}
        nodes_by_method = {n["method"]: n for n in pipeline_data["nodes"]}
        current_node = nodes_by_id.get(node_id) or nodes_by_method.get(node_id) or {}
        nid_label = current_node.get("label") or None

    # Resolve parent run IDs from workspace sidecars if not provided
    if parent_run_ids is None:
        parent_run_ids = []
        # Check for upstream workspace outputs by reading sidecar files
        ws_dir = runs_dir() / "workspace"
        if pipeline_data is not None:
            links = pipeline_data.get("links", [])
            node_map_raw = {str(n["id"]): n for n in pipeline_data["nodes"]}
            for link in links:
                tgt = str(link["target"])
                src = str(link["source"])
                # Match target to our node_id
                tgt_node = node_map_raw.get(tgt)
                src_node = node_map_raw.get(src)
                if tgt_node and src_node:
                    tgt_nid = tgt if not tgt.isdigit() else tgt_node["method"]
                    src_nid = src if not src.isdigit() else src_node["method"]
                    if tgt_nid == node_id:
                        slot = link.get("target_slot", "data")
                        # Workspace outputs are scoped by pipeline_id (see
                        # ws_base below), so parent sidecar lookups must
                        # include pipeline_id too. Without this, the lookup
                        # reads from the legacy un-scoped path and either
                        # finds nothing or finds a stale sidecar from a
                        # prior session, leaving PM_INPUT_PATHS empty.
                        sidecar = (
                            ws_dir / pipeline_id / src_nid / sample / variant
                            / "run_id.txt"
                        )
                        if sidecar.exists():
                            pid = sidecar.read_text().strip()
                            parent_run_ids.append(f"{slot}:{pid}")

    口 = AutoStep(step_num=2, name="Pre-run")
    try:
        flag, run_id = pre_run(
            method_name=method_name,
            module_name=module_name,
            sample=sample,
            params=params,
            parent_run_ids=parent_run_ids if parent_run_ids else None,
            pipeline_id=pipeline_id,
            git_commit=git_commit,
            nid=nid_label,
        )
    except Exception as exc:
        print(f"ERROR: pre_run failed: {exc}", file=sys.stderr)
        return 1

    run_dir = _run_archive_dir(run_id)
    ws_base = runs_dir() / "workspace" / pipeline_id / node_id / sample / variant

    # ADR-010: Resolve workspace output paths via the single shared helper.
    # slot_outputs (filename per slot) and slot_types (type per slot) come
    # from the pipeline JSON emitted by _enrich_pipeline.  Empty slot_outputs
    # triggers the legacy single-output fallback inside resolve_node_outputs.
    slot_outputs: dict[str, str] = {}
    slot_types: dict[str, str] = {}
    node_cfg: dict = {}
    if pipeline_json and Path(pipeline_json).exists():
        raw = json.loads(Path(pipeline_json).read_text())
        node_map_raw = {str(n["id"]): n for n in raw["nodes"]}
        method_map_raw = {n["method"]: n for n in raw["nodes"]}
        node_cfg = node_map_raw.get(node_id) or method_map_raw.get(node_id) or {}
        slot_outputs = node_cfg.get("slot_outputs", {}) or {}
        slot_types = node_cfg.get("slot_types", {}) or {}

    from .node_outputs import resolve_node_outputs
    ws_outputs = resolve_node_outputs(node_cfg, ws_base)  # {slot: Path}

    # Outcome sidecar setup
    outcomes_dir = runs_dir() / "pipelines" / pipeline_id / "outcomes"
    outcomes_dir.mkdir(parents=True, exist_ok=True)
    outcome = {
        "node_id": node_id, "sample": sample, "variant": variant,
        "run_id": run_id, "status": "unknown", "error": None,
    }

    口 = Step(step_num=3, name="Handle cache hit",
             purpose="Restore cached outputs to workspace and write outcome sidecar")
    if flag == "CACHED":
        # ``run_id`` here is the AUDIT row's ID (pre_run's new contract on
        # CACHED). restore_output looks up RunOutput by run_id to find the
        # actual output files, so we need the original source run's ID —
        # read it back off the audit row we just inserted.
        with get_session() as session:
            audit = session.get(Run, run_id)
            if audit is None or audit.cache_source_run_id is None:
                print(f"ERROR: audit row {run_id} missing cache_source_run_id",
                      file=sys.stderr)
                return 1
            source_for_restore: int = int(audit.cache_source_run_id)
        try:
            ws_base.mkdir(parents=True, exist_ok=True)
            # ADR-010 D-2: iterate per slot, call restore_output once per
            # slot with the slot's filename as output_name.  Legacy
            # single-output pipelines degenerate to exactly one iteration.
            for slot_name, ws_path in ws_outputs.items():
                filename = slot_outputs.get(slot_name, ws_path.name)
                restore_output(
                    run_id=source_for_restore,
                    workspace_output=str(ws_path),
                    output_name=filename,
                )
                # restore_output writes the sidecar with the source run's
                # ID (what it considers "the run these outputs came from").
                # Overwrite with the audit row's ID so downstream nodes wire
                # lineage through this pipeline's sibling audits instead of
                # the old pipeline's source runs. Without this, every
                # cache-hit branch of a fan-out reconstructs as a cross-
                # pipeline chain in PathsView.
                sidecar = ws_path.parent / "run_id.txt"
                sidecar.write_text(str(run_id))
            outcome["status"] = "cached"
        except Exception as exc:
            outcome["status"] = "failed"
            outcome["error"] = str(exc)
            _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
            print(f"ERROR: restore failed: {exc}", file=sys.stderr)
            return 1
        _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
        return 0

    口 = Step(step_num=4, name="Execute method subprocess",
             purpose="Set PM_* env vars and run method script in isolated subprocess")
    # Resolve input path(s).  For fan-in nodes with multiple parents we
    # build a slot→paths dict so method.py can dispatch via PM_INPUT_PATHS.
    slot_paths: dict[str, list[str]] = {}  # slot → [resolved_path, ...]
    if parent_run_ids:
        for pid_entry in parent_run_ids:
            s = str(pid_entry)
            if ":" in s:
                slot, pid_str = s.split(":", 1)
            else:
                slot = "data"
                pid_str = s
            resolved = resolve_input(run_id=int(pid_str))
            if resolved:
                slot_paths.setdefault(slot, []).append(str(resolved))
    else:
        # Root node (e.g. downstream of input_selector): resolve sample
        # data from data/samples/{sample}/ when available.
        sample_dir = get_project_root() / "data" / "samples" / sample
        if sample_dir.exists():
            sample_files = [f for f in os.listdir(sample_dir) if not f.startswith(".")]
            if sample_files:
                resolved_path = str((sample_dir / sample_files[0]).resolve())
                # Honor the target_slot declared on the incoming canvas
                # link (e.g. input_selector → method) so the method sees
                # the sample under its declared input name instead of a
                # hardcoded "data". Input selectors don't produce a run
                # sidecar, so the parent_run_ids loop above skips their
                # edges — we pull the slot name straight from pipeline
                # links here. Falls back to "data" when no incoming link
                # is wired.
                slot = "data"
                if pipeline_data is not None:
                    raw_id = str(current_node.get("id", node_id))
                    for link in pipeline_data.get("links", []):
                        tgt = str(link.get("target", ""))
                        if tgt in (node_id, raw_id):
                            ts = link.get("target_slot")
                            if ts:
                                slot = ts
                                break
                slot_paths.setdefault(slot, []).append(resolved_path)

    # ADR-008 boundary rule: run_reference paths are resolved by the
    # orchestrator and passed via --ref-input.  Merge them into
    # slot_paths so the method receives them as normal
    # inputs without run_step needing to understand system node types.
    if ref_inputs:
        for entry in ref_inputs:
            if "=" not in entry:
                continue
            label, ref_path = entry.split("=", 1)
            slot_paths.setdefault(label, []).append(ref_path)

    # D-2: Enforce --ref-input for root nodes.  If we reach this point with
    # no parent_run_ids AND no ref_inputs resolved, the node is a root node
    # invoked without the required --ref-input flag.
    if not parent_run_ids and not slot_paths:
        print(
            f"ERROR: root node '{node_id}' has no input data.  "
            f"Provide --ref-input <slot>=<path> to supply input for root nodes.",
            file=sys.stderr,
        )
        return 1

    # Write _run_context.json
    context = {
        "run_id": int(run_id), "run_dir": str(run_dir), "sample": sample,
        "slot_paths": slot_paths, "params": params,
        "method_name": method_name, "module_name": module_name,
        "slot_outputs": slot_outputs,
        "slot_types": slot_types,
    }
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "_run_context.json").write_text(json.dumps(context, indent=2, default=str))

    # Set PM_* env vars
    pm_env = os.environ.copy()
    pm_env.update({
        "PM_RUN_ID": str(run_id),
        "PM_RUN_DIR": str(run_dir.resolve()),
        "PM_SAMPLE": sample,
        "PM_PARAMS": json.dumps(params),
        "PM_NODE_ID": node_id,
        "PM_PIPELINE_ID": pipeline_id,
        "PM_VARIANT": variant,
    })
    # Fan-in: expose all parent outputs grouped by slot so method.py can
    # load multi-input dicts via PM_INPUT_PATHS.
    if slot_paths:
        pm_env["PM_INPUT_PATHS"] = json.dumps(slot_paths)

    # Expose *only* the pm package to the method subprocess via a narrow
    # shim (see _ensure_pm_shim() for the rationale).  Overwrite — do NOT
    # append — any inherited PYTHONPATH: the Snakemake parent process or
    # the user's shell may have put the host venv's site-packages there,
    # which is exactly the ABI-mismatched numpy/pandas we are trying to
    # keep out of the pixi env.
    pm_env["PYTHONPATH"] = str(_ensure_pm_shim())
    pm_env["PYTHONUNBUFFERED"] = "1"

    # Resolve python executable (env dispatch)
    python_exe = sys.executable
    project_root = get_project_root()
    config_path = project_root / ".pm" / "wf-canvas.toml"
    if config_path.exists():
        try:
            from .init import read_config
            cfg = read_config(project_root)
            pixi_root = cfg.get("pixi_root", "")
            conda_root = cfg.get("conda_root", "")
            # Look up env for this node from pipeline JSON
            env_name = "inherit"
            if pipeline_json and Path(pipeline_json).exists():
                raw_pj = json.loads(Path(pipeline_json).read_text())
                nm = {str(n["id"]): n for n in raw_pj["nodes"]}
                mm = {n["method"]: n for n in raw_pj["nodes"]}
                nc = nm.get(node_id) or mm.get(node_id) or {}
                env_name = nc.get("env", nc.get("env_strategy", "inherit"))
            if env_name != "inherit":
                from .register import resolve_python_for_env
                try:
                    python_exe = str(resolve_python_for_env(
                        env_name, pixi_root=pixi_root, conda_root=conda_root,
                    ))
                except ValueError:
                    pass  # Fall back to sys.executable
        except Exception:
            pass  # Fall back to sys.executable

    # Prepend pixi env directories to PATH so Windows DLL loader finds the
    # correct native libs (e.g. libopenblas, jaxlib).  PYTHONPATH (handled
    # above via _ensure_pm_shim) controls Python imports; PATH controls
    # OS-level DLL search order.  Without this, the parent env's DLLs leak
    # into the subprocess and cause ABI-mismatch segfaults.  (See ADR-008.)
    if python_exe != sys.executable:
        env_root = Path(python_exe).resolve().parent
        if env_root.name.lower() == "scripts":
            env_root = env_root.parent
        path_dirs = [
            str(env_root),                # python.exe, python3XX.dll
            str(env_root / "Library" / "bin"),  # native lib DLLs
            str(env_root / "Scripts"),     # pip-installed entry points
            str(env_root / "DLLs"),        # Python extension modules
        ]
        pm_env["PATH"] = os.pathsep.join(path_dirs) + os.pathsep + pm_env.get("PATH", "")

    # Execute the method script.  stdout/stderr are tee'd to per-run log
    # files (.runs/<run_id>/{stdout,stderr}.log) while also being forwarded
    # to the parent's std streams so Snakemake's pipeline-level capture
    # still sees method output.
    cmd = [python_exe, str(script_path)]
    stdout_log = run_dir / "stdout.log"
    stderr_log = run_dir / "stderr.log"
    try:
        result = _run_method_subprocess(
            cmd,
            cwd=str(project_root),
            env=pm_env,
            stdout_log=stdout_log,
            stderr_log=stderr_log,
        )
    except Exception as exc:
        # Subprocess launch failure
        error_msg = str(exc)
        error_tb = _tb.format_exc()
        try:
            complete_run(run_id=run_id, status="failed",
                         error_message=error_msg, error_traceback=error_tb)
        except Exception:
            pass
        outcome["status"] = "failed"
        outcome["error"] = error_msg
        _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
        print(f"ERROR: method execution failed: {error_msg}", file=sys.stderr)
        return 1

    if result.returncode != 0:
        error_msg = f"Method exited with code {result.returncode}"
        try:
            complete_run(run_id=run_id, status="failed",
                         error_message=error_msg, error_traceback="")
        except Exception:
            pass
        outcome["status"] = "failed"
        outcome["error"] = error_msg
        _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
        print(f"ERROR: {error_msg}", file=sys.stderr)
        return 1

    口 = Step(step_num=5, name="Collect outputs",
             purpose="Read metrics.json, scan declared output slots, create RunOutput rows")
    metrics_path = run_dir / "metrics.json"
    metrics = {}
    if metrics_path.exists():
        try:
            metrics = json.loads(metrics_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass  # Default to empty metrics

    # ADR-010: Scan outputs slot-first.  For each declared slot in the
    # pipeline JSON, locate the file/dir under run_dir, verify it exists,
    # record a RunOutput row (content_hash=NULL -- deferred archiving),
    # and collect it for complete_run.  A missing declared slot fails the
    # run with a clear error naming the method and slot.
    # Deferred archiving: hash_path and cache_file are NOT called here.
    # Content hashing happens in the post-pipeline archive pass.

    output_files_in_archive: list[str] = []
    workspace_outputs: list[str] = []
    for slot_name, ws_path in ws_outputs.items():
        filename = slot_outputs.get(slot_name, ws_path.name)
        archive_entry = run_dir / filename
        if not archive_entry.exists():
            # Method honored pre_run but failed to produce a declared slot.
            error_msg = (
                f"Method '{method_name}' did not produce declared slot "
                f"'{slot_name}' (expected at {archive_entry})"
            )
            try:
                complete_run(run_id=run_id, status="failed",
                             error_message=error_msg, error_traceback=error_msg)
            except Exception:
                pass
            outcome["status"] = "failed"
            outcome["error"] = error_msg
            _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
            print(f"ERROR: {error_msg}", file=sys.stderr)
            return 1

        output_files_in_archive.append(str(archive_entry))
        workspace_outputs.append(str(ws_path))

        # Determine artifact_type: slot-declared files are module outputs.
        artifact_type = "module_file" if slot_outputs else "method_file"

        # Create RunOutput row keyed by the slot filename (content_hash=NULL)
        try:
            with get_session() as session:
                existing = session.exec(
                    select(RunOutput).where(
                        RunOutput.run_id == run_id,
                        RunOutput.output_name == archive_entry.name,
                    )
                ).first()
                if archive_entry.is_file():
                    stat = archive_entry.stat()
                    file_size = stat.st_size
                    file_mtime = stat.st_mtime
                else:
                    file_size = None
                    file_mtime = None
                if existing:
                    existing.artifact_path = str(archive_entry)
                    existing.artifact_type = artifact_type
                    existing.file_size = file_size
                    existing.file_mtime = file_mtime
                else:
                    session.add(RunOutput(
                        run_id=run_id, output_name=archive_entry.name,
                        artifact_path=str(archive_entry), artifact_type=artifact_type,
                        file_size=file_size, file_mtime=file_mtime,
                    ))
                session.commit()
        except Exception:
            pass  # Best-effort DB write

    口 = AutoStep(step_num=6, name="Complete run")
    ws_base.mkdir(parents=True, exist_ok=True)
    complete_run(
        run_id=run_id,
        status="completed",
        output_files=output_files_in_archive,
        workspace_outputs=workspace_outputs,
        metrics=metrics,
    )

    口 = Step(step_num=7, name="DVC provenance push",
             purpose="Push artifacts to DVC remote if configured (non-fatal)")
    # Push artifacts to DVC remote if configured. Non-fatal on failure.
    if output_files_in_archive:
        try:
            from .provenance import push_artifacts
            push_artifacts(
                run_id=run_id,
                paths=output_files_in_archive,
                project_dir=project_root,
            )
        except Exception as exc:
            print(f"WARNING: DVC provenance push failed: {exc}", file=sys.stderr)

    outcome["status"] = "completed"
    _write_outcome(outcomes_dir, node_id, sample, variant, outcome)
    return 0


def _write_outcome(outcomes_dir: Path, node_id: str, sample: str, variant: str, outcome: dict) -> None:
    """Write a JSON outcome sidecar file."""
    filename = f"{node_id}__{sample}__{variant}.json"
    (outcomes_dir / filename).write_text(json.dumps(outcome, indent=2, default=str))


# =============================================================================
# pipeline_summary (ADR 008 — outcome aggregation)
# =============================================================================

def pipeline_summary(pipeline_id: str) -> int:
    """Aggregate outcome sidecar JSONs into a pipeline summary.

    Reads all JSON files from ``.runs/pipelines/{pipeline_id}/outcomes/``
    and prints a summary table.

    Args:
        pipeline_id: Pipeline execution ID.

    Returns:
        0 on success.
    """
    outcomes_dir = runs_dir() / "pipelines" / pipeline_id / "outcomes"
    outcomes = []
    if outcomes_dir.exists():
        for f in sorted(outcomes_dir.glob("*.json")):
            try:
                outcomes.append(json.loads(f.read_text()))
            except (json.JSONDecodeError, OSError):
                pass

    completed = [o for o in outcomes if o.get("status") == "completed"]
    cached = [o for o in outcomes if o.get("status") == "cached"]
    failed = [o for o in outcomes if o.get("status") == "failed"]
    total = len(outcomes)

    print("=" * 60)
    print("PIPELINE SUMMARY")
    print("=" * 60)
    print(f"Pipeline ID: {pipeline_id}")
    print(f"Total runs: {total}  |  Passed: {len(completed)}  |  Failed: {len(failed)}  |  Cached: {len(cached)}")
    print()

    if failed:
        print("FAILED RUNS:")
        for o in failed:
            print(f"  - {o.get('node_id')} sample={o.get('sample')} variant={o.get('variant')}")
            if o.get("error"):
                print(f"    Error: {o['error']}")
        print()

    print("=" * 60)
    return 0


# =============================================================================
# cache management (ADR-011)
# =============================================================================

@task(purpose="Hash and cache un-archived outputs from completed runs")
def cache_archive(*, run_id: int | None = None) -> int:
    """Hash and cache un-archived outputs from completed runs.

    Queries RunOutput rows with NULL content_hash, hashes each file,
    copies into DVC cache, and updates the DB.  Prints per-file progress.

    Args:
        run_id: Optional filter to archive only outputs from a specific run.

    Returns:
        0 on success.
    """
    from .provenance import archive_outputs

    project_dir = get_project_root()

    def _progress(name: str, status: str) -> None:
        print(f"  {name}: {status}")

    print("Archiving un-archived outputs...")
    results = archive_outputs(project_dir, run_id=run_id, progress_fn=_progress)

    if not results:
        print("Nothing to archive.")
    else:
        archived = sum(1 for r in results if r["status"] == "archived")
        missing = sum(1 for r in results if r["status"] == "missing")
        errors = sum(1 for r in results if r["status"].startswith("error:"))
        print(f"Done: {archived} archived, {missing} missing, {errors} errors.")

    return 0


@task(purpose="Remove old run archives and optionally prune DVC local cache entries")
def cache_prune(
    *,
    prune_all: bool = False,
    include_local: bool = False,
    dry_run: bool = False,
    force: bool = False,
) -> int:
    """Remove old run archives and optionally DVC local cache entries.

    Args:
        prune_all: Remove all archives regardless of reference status.
        include_local: Also prune .dvc/cache/ entries for unreferenced hashes.
        dry_run: Print what would be deleted without deleting.
        force: Skip confirmation prompt.

    Returns:
        0 on success, 1 on user abort.
    """
    from .provenance import prune_run_archives, prune_dvc_cache, check_remote_reachable

    project_dir = get_project_root()

    # ADR-011 safety check: verify DVC remote is reachable before pruning
    if not dry_run:
        reachable, reason = check_remote_reachable(project_dir)
        if not reachable:
            if include_local and not force:
                print(
                    f"ERROR: DVC remote is unreachable ({reason}). "
                    f"With --include-local, pruning will make outputs unrecoverable. "
                    f"Use --force to override.",
                    file=sys.stderr,
                )
                return 1
            elif not force:
                print(
                    f"WARNING: DVC remote is unreachable ({reason}). "
                    f"Pruned archives may not be recoverable from remote. "
                    f"Use --force to override.",
                    file=sys.stderr,
                )
                return 1

    # Prune guard: refuse to prune runs with un-archived outputs
    from .models import RunOutput as _RunOutput
    _exclude_run_ids: set[int] = set()
    with get_session() as _guard_session:
        unarchived = _guard_session.exec(
            select(_RunOutput).where(_RunOutput.content_hash.is_(None))  # type: ignore[union-attr]
        ).all()
        if unarchived:
            _exclude_run_ids = {ro.run_id for ro in unarchived}
            print(
                f"WARNING: {len(unarchived)} output(s) from run(s) "
                f"{sorted(_exclude_run_ids)} have not been archived "
                f"(content_hash is NULL). Skipping those runs to prevent "
                f"data loss. Run 'pm cache archive' first.",
                file=sys.stderr,
            )

    # Compute what would be pruned (always dry_run first for summary)
    archive_paths = prune_run_archives(
        project_dir, all_archives=prune_all, dry_run=True,
        exclude_run_ids=_exclude_run_ids or None,
    )
    cache_paths = (
        prune_dvc_cache(project_dir, all_entries=prune_all, dry_run=True) if include_local else []
    )

    if not archive_paths and not cache_paths:
        print("Nothing to prune.")
        return 0

    # Summary
    print(f"Run archives to remove: {len(archive_paths)}")
    for p in archive_paths:
        print(f"  {p}")
    if include_local:
        print(f"DVC cache entries to remove: {len(cache_paths)}")
        for p in cache_paths:
            print(f"  {p}")

    if dry_run:
        print("(dry run -- no files deleted)")
        return 0

    # Confirmation prompt
    if not force:
        try:
            answer = input("Proceed? [y/N] ")
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return 1
        if answer.strip().lower() != "y":
            print("Aborted.")
            return 1

    # Actually prune
    prune_run_archives(
        project_dir, all_archives=prune_all, dry_run=False,
        exclude_run_ids=_exclude_run_ids or None,
    )
    if include_local:
        prune_dvc_cache(project_dir, all_entries=prune_all, dry_run=False)

    total = len(archive_paths) + len(cache_paths)
    print(f"Pruned {total} item(s).")
    return 0


# =============================================================================
# argparse entry-point
# =============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pm", description="Process Manager CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    # -- register_run --
    reg = sub.add_parser("register_run", help="Register a new run (status=running)")
    reg.add_argument("--method", required=True)
    reg.add_argument("--module", required=True, help="Module that owns this method")
    reg.add_argument("--sample", required=True)
    reg.add_argument("--params", default=None, help="JSON string of parameters")
    reg.add_argument("--parent-run-id", nargs="*", default=None,
                       help="Parent run ID(s) as 'slot:id' or plain 'id'. Repeat for fan-in.")
    reg.add_argument("--nf-process-name", default=None)
    reg.add_argument("--pipeline-id", default=None, help="Pipeline execution ID (UUID)")

    # -- pre_run --
    pr = sub.add_parser("pre_run",
                         help="Versioned pre-run hook: git check + cache lookup + run registration")
    pr.add_argument("--method", required=True)
    pr.add_argument("--module", required=True)
    pr.add_argument("--sample", required=True)
    pr.add_argument("--params", default=None, help="JSON string of parameters")
    pr.add_argument("--parent-run-id", nargs="*", default=None,
                    help="Parent run ID(s) as 'slot:id' or plain 'id'.")
    pr.add_argument("--pipeline-id", default=None)
    pr.add_argument("--nf-process-name", default=None)
    pr.add_argument("--git-commit", default=None,
                    help="Pre-computed commit SHA (skips git check; for testing).")

    # -- complete_run --
    comp = sub.add_parser("complete_run", help="Mark a run as completed")
    comp.add_argument("--run-id", type=int, required=True)
    comp.add_argument("--status", default="completed")
    comp.add_argument("--output", nargs="*", default=[], help="Output file paths (in archive)")
    comp.add_argument("--workspace-output", nargs="*", default=[],
                       help="Workspace paths to hardlink outputs into")
    comp.add_argument("--metrics", default=None, help="JSON string of metrics")
    comp.add_argument("--error", default=None, help="Error message for failed runs (ADR 004)")
    comp.add_argument("--traceback", default=None, dest="traceback_str",
                       help="Error traceback for failed runs (ADR 004)")

    # -- check_cache --
    cache = sub.add_parser("check_cache", help="Check for cached identical run")
    cache.add_argument("--method", required=True)
    cache.add_argument("--sample", required=True)
    cache.add_argument("--params", default=None, help="JSON string of parameters")
    cache.add_argument("--parent-run-id", nargs="*", default=None,
                        help="Parent run ID(s) as 'slot:id' or plain 'id'. Repeat for fan-in.")

    # -- restore_output --
    restore = sub.add_parser("restore_output", help="Hardlink cached output to workspace")
    restore.add_argument("--run-id", type=int, required=True)
    restore.add_argument("--workspace-output", required=True, help="Workspace path for hardlink")
    restore.add_argument("--output-name", default=None,
                         help="Specific output filename to restore (multi-output runs)")

    # -- restore-sample (ADR-009) --
    rss = sub.add_parser("restore-sample", help="Restore a sample from DVC cache to data/samples/")
    rss.add_argument("--name", required=True, help="Sample identifier")
    rss.add_argument("--hash", default=None, dest="content_hash",
                     help="Expected content hash (optional; looked up from DB if omitted)")

    # -- cleanup_workspace --
    sub.add_parser("cleanup_workspace", help="Delete workspace (run before generate)")

    # -- finalize_pipeline --
    finalize = sub.add_parser("finalize_pipeline", help="Log successful pipeline completion")
    finalize.add_argument("--pipeline-id", required=True)

    # -- fail_pipeline --
    fail = sub.add_parser("fail_pipeline", help="Mark in-flight runs as failed")
    fail.add_argument("--pipeline-id", required=True)

    # -- resolve_input --
    resolve = sub.add_parser("resolve_input", help="Get archived output path for a run")
    resolve.add_argument("--run-id", type=int, required=True)

    # -- lookup_run (legacy) --
    look = sub.add_parser("lookup_run", help="(Legacy) Find most-recent completed run")
    look.add_argument("--method", required=True)
    look.add_argument("--sample", required=True)
    look.add_argument("--nf-process-name", default=None)

    # -- init --
    init_p = sub.add_parser("init", help="Scaffold a new pm project directory")
    init_p.add_argument("--dir", default=".", help="Target directory (default: current dir)")
    init_p.add_argument("--git", action="store_true",
                        help="Run `git init` in the project directory if no repo is found")

    # -- seed --
    sub.add_parser("seed", help="Seed the database with demo methods")

    # -- register-sample --
    rs = sub.add_parser("register-sample", help="Register a data sample (copy into data/samples/)")
    rs.add_argument("--name", required=True, help="Sample identifier (e.g. CFPAC_ERKi)")
    rs.add_argument("--source", required=True, help="Path to the source data file")

    # -- register-module --
    rm = sub.add_parser("register-module", help="Create or update a module in the database")
    rm.add_argument("--name", required=True, help="Module name (e.g. data_preprocessing)")
    rm.add_argument("--description", default=None, help="Human-readable description")
    rm.add_argument("--contracts", default=None,
                    help='Contracts: path to a JSON file, or inline JSON string. '
                         'Optional if --module-dir has module.yaml. '
                         'Example: [{"type":"output","name":"x","value_type":".parquet"}]')
    rm.add_argument("--module-dir", default=None,
                    help="Path to module directory containing module.yaml (contracts loaded from file)")

    # -- register-method --
    rme = sub.add_parser("register-method", help="AST-scan method script and register method + params")
    rme.add_argument("method_dir", help="Path to the method directory containing the method script")
    rme.add_argument("--module", required=True, help="Module name this method belongs to")
    rme.add_argument("--name", default=None, help="Method name (defaults to directory name)")
    rme.add_argument("--script", default=None,
                     help="Script filename to scan (default: {method_name}.py)")

    # -- run-pipeline --
    rp = sub.add_parser("run-pipeline", help="Generate Snakefile and run the pipeline")
    rp.add_argument("--pipeline", required=True, help="Path to the pipeline JSON file")
    rp.add_argument("--project-root", default=None,
                    help="pm project directory (git repo with method commits). Defaults to cwd.")
    rp.add_argument("--pm-root", default=None,
                    help="Directory added to PYTHONPATH in workers for `import pm`. "
                         "Defaults to pm's installed location.")
    rp.add_argument("--cores", type=int, default=4, help="Snakemake cores (default: 4)")
    rp.add_argument("--snakefile", default=None, help="Where to write the Snakefile (default: <project-root>/Snakefile)")
    rp.add_argument("--archive", action="store_true", default=True, dest="archive",
                    help="Archive outputs after pipeline completion (default: on)")
    rp.add_argument("--no-archive", action="store_false", dest="archive",
                    help="Skip output archiving after pipeline completion")
    rp.add_argument("--keep-going", action="store_true", default=False, dest="keep_going",
                    help="Pass --keep-going to Snakemake: a failed job doesn't "
                         "cancel independent jobs (useful for fan-out pipelines)")

    # -- canvas --
    cv = sub.add_parser("canvas", help="Launch the workflow canvas web UI")
    cv.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    cv.add_argument("--port", type=int, default=8500, help="Bind port (default: 8500)")
    cv.add_argument("--reload", action="store_true", help="Enable auto-reload (development mode)")
    cv.add_argument("--project-root", default=None,
                    help="Path to pm project directory (default: cwd). "
                         "The directory must contain .pm/pm.db.")

    # -- run-step (ADR 008) --
    rs_cmd = sub.add_parser("run-step", help="Execute a single pipeline step end-to-end")
    rs_cmd.add_argument("--node-id", required=True, help="Unique node identity in the pipeline")
    rs_cmd.add_argument("--sample", required=True, help="Sample identifier")
    rs_cmd.add_argument("--variant", default="default", help="Parameter variant name")
    rs_cmd.add_argument("--method", default=None, help="Method name (inline fallback)")
    rs_cmd.add_argument("--module", default=None, help="Module name (inline fallback)")
    rs_cmd.add_argument("--script", default=None, help="Path to method script (inline fallback)")
    rs_cmd.add_argument("--params", default=None, help="JSON string of parameters")
    rs_cmd.add_argument("--parent-run-id", nargs="*", default=None,
                        help="Parent run ID(s) as 'slot:id' or plain 'id'.")
    rs_cmd.add_argument("--pipeline-id", default=None, help="Pipeline execution ID")
    rs_cmd.add_argument("--pipeline-json", default=None, help="Path to pipeline JSON file")
    rs_cmd.add_argument("--git-commit", default=None, help="Pre-computed git commit SHA")
    rs_cmd.add_argument("--ref-input", action="append", default=None,
                        help="Static ref input as 'label=path' from run_reference nodes. "
                             "Repeatable. Orchestrator resolves these; run-step stays "
                             "topology-agnostic (ADR-008 boundary rule).")

    # -- pipeline-summary (ADR 008) --
    ps_cmd = sub.add_parser("pipeline-summary", help="Aggregate outcome sidecars into summary")
    ps_cmd.add_argument("--pipeline-id", required=True, help="Pipeline execution ID")

    # -- cache (ADR-011) --
    cache_cmd = sub.add_parser("cache", help="Cache management commands")
    cache_sub = cache_cmd.add_subparsers(dest="cache_command", required=True)

    prune_cmd = cache_sub.add_parser(
        "prune",
        help="Remove old run archives and optionally DVC local cache entries",
    )
    prune_cmd.add_argument(
        "--all", action="store_true", dest="prune_all",
        help="Remove all run archives regardless of reference status",
    )
    prune_cmd.add_argument(
        "--include-local", action="store_true",
        help="Also prune the DVC local cache (.dvc/cache/) for unreferenced hashes",
    )
    prune_cmd.add_argument(
        "--dry-run", action="store_true",
        help="Print what would be deleted without actually deleting",
    )
    prune_cmd.add_argument(
        "--force", action="store_true",
        help="Skip the confirmation prompt",
    )

    # -- cache archive (deferred output archiving) --
    archive_cmd = cache_sub.add_parser(
        "archive",
        help="Hash and cache un-archived outputs from completed runs",
    )
    archive_cmd.add_argument(
        "--run-id", type=int, default=None,
        help="Archive only outputs from a specific run ID",
    )

    return parser


def cli_main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "register_run":
        params = json.loads(args.params) if args.params else None
        run_id = register_run(
            method_name=args.method,
            module_name=args.module,
            sample=args.sample,
            params=params,
            parent_run_ids=args.parent_run_id,
            nf_process_name=args.nf_process_name,
            pipeline_id=args.pipeline_id,
        )
        print(run_id)
        return 0

    elif args.command == "pre_run":
        params = json.loads(args.params) if args.params else None
        try:
            flag, run_id = pre_run(
                method_name=args.method,
                module_name=args.module,
                sample=args.sample,
                params=params,
                parent_run_ids=args.parent_run_id,
                pipeline_id=args.pipeline_id,
                nf_process_name=args.nf_process_name,
                git_commit=args.git_commit,
            )
        except Exception as exc:  # DirtyRepositoryError, ValueError, etc.
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        print(f"{flag}:{run_id}")
        return 0

    elif args.command == "complete_run":
        metrics = json.loads(args.metrics) if args.metrics else None
        complete_run(
            run_id=args.run_id,
            status=args.status,
            output_files=args.output,
            workspace_outputs=args.workspace_output,
            metrics=metrics,
            error_message=args.error,
            error_traceback=args.traceback_str,
        )
        return 0

    elif args.command == "check_cache":
        params = json.loads(args.params) if args.params else None
        run_id = check_cache(
            method_name=args.method,
            sample=args.sample,
            params=params,
            parent_run_ids=args.parent_run_id,
        )
        print(run_id if run_id is not None else "NONE")
        return 0

    elif args.command == "restore_output":
        restore_output(
            run_id=args.run_id,
            workspace_output=args.workspace_output,
            output_name=args.output_name,
        )
        return 0

    elif args.command == "finalize_pipeline":
        finalize_pipeline(pipeline_id=args.pipeline_id)
        return 0

    elif args.command == "cleanup_workspace":
        cleanup_workspace()
        return 0

    elif args.command == "fail_pipeline":
        fail_pipeline(pipeline_id=args.pipeline_id)
        return 0

    elif args.command == "resolve_input":
        path = resolve_input(run_id=args.run_id)
        if path is None:
            print("ERROR: no output found for run", file=sys.stderr)
            return 1
        print(path)
        return 0

    elif args.command == "lookup_run":
        run_id = lookup_run(args.method, args.sample, nf_process_name=args.nf_process_name)
        if run_id is None:
            print("ERROR: no completed run found", file=sys.stderr)
            return 1
        print(run_id)
        return 0

    elif args.command == "init":
        from .init import init_project
        target = Path(args.dir).resolve()
        created = init_project(target, init_git=args.git)
        print(f"Initialized pm project at {target}")
        for name, was_created in created.items():
            icon = "+" if was_created else "."
            print(f"  {icon} {name}")
        return 0

    elif args.command == "seed":
        from .seed import seed
        seed()
        return 0

    elif args.command == "register-sample":
        source = Path(args.source).resolve()
        try:
            registered = register_sample(
                name=args.name,
                source_path=source,
            )
        except Exception as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        print(f"Registered sample '{args.name}' -> {registered}")
        return 0

    elif args.command == "restore-sample":
        restore_sample(
            name=args.name,
            content_hash=args.content_hash,
        )
        return 0

    elif args.command == "register-module":
        from .register import register_module
        contracts = None
        if args.contracts is not None:
            # Accept a file path or inline JSON string
            contracts_path = Path(args.contracts)
            if contracts_path.exists():
                contracts = json.loads(contracts_path.read_text(encoding="utf-8"))
            else:
                contracts = json.loads(args.contracts)
        module_dir = Path(args.module_dir) if args.module_dir else None
        # Auto-discover module_dir from modules/{name} if not provided
        if module_dir is None:
            candidate = Path("modules") / args.name
            if candidate.is_dir():
                module_dir = candidate
        register_module(
            name=args.name,
            contracts=contracts,
            description=args.description,
            module_dir=module_dir,
        )
        return 0

    elif args.command == "register-method":
        from .register import register_method
        register_method(
            method_dir=Path(args.method_dir),
            module_name=args.module,
            method_name=args.name,
            script_name=args.script,
        )
        return 0

    elif args.command == "run-pipeline":
        rc = run_pipeline(
            pipeline_path=args.pipeline,
            project_root=args.project_root,
            pm_root=args.pm_root,
            cores=args.cores,
            snakefile_path=args.snakefile,
            archive=args.archive,
            keep_going=args.keep_going,
        )
        return rc

    elif args.command == "run-step":
        params = json.loads(args.params) if args.params else None
        rc = run_step(
            node_id=args.node_id,
            sample=args.sample,
            variant=args.variant,
            method_name=args.method,
            module_name=args.module,
            script_path=args.script,
            params=params,
            parent_run_ids=args.parent_run_id,
            pipeline_id=args.pipeline_id,
            pipeline_json=args.pipeline_json,
            git_commit=args.git_commit,
            ref_inputs=args.ref_input,
        )
        return rc

    elif args.command == "pipeline-summary":
        return pipeline_summary(pipeline_id=args.pipeline_id)

    elif args.command == "cache":
        if args.cache_command == "prune":
            return cache_prune(
                prune_all=args.prune_all,
                include_local=args.include_local,
                dry_run=args.dry_run,
                force=args.force,
            )
        elif args.cache_command == "archive":
            return cache_archive(run_id=args.run_id)
        return 1

    elif args.command == "canvas":
        try:
            import uvicorn
        except ImportError:
            print(
                "ERROR: uvicorn is required to run the canvas server.\n"
                "Install it with: pip install 'uvicorn[standard]'",
                file=sys.stderr,
            )
            return 1
        # Point DATABASE_URL at the chosen project before uvicorn starts
        if args.project_root:
            proj = Path(args.project_root).resolve()
            db = proj / ".pm" / "pm.db"
            if not db.exists():
                print(f"ERROR: No .pm/pm.db found in {proj}", file=sys.stderr)
                return 1
            os.environ["PM_CANVAS_PROJECT_ROOT"] = str(proj)
        print(f"Starting Workflow Canvas at http://{args.host}:{args.port}")
        uvicorn.run(
            "pm.canvas.server:app",
            host=args.host,
            port=args.port,
            reload=args.reload,
        )
        return 0

    return 1
