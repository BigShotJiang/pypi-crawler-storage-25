code = """
# =====================================
# Decision Tree using Gini Impurity
# =====================================

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score

# -------------------------------------
# DATASET
# -------------------------------------
data = {
'Weather':['Sunny','Cloudy','Sunny','Cloudy','Rainy','Rainy','Rainy','Sunny','Cloudy','Rainy'],
'Temperature':['Hot','Hot','Mild','Mild','Mild','Cool','Mild','Hot','Hot','Mild'],
'Humidity':['High','High','Normal','High','High','Normal','High','High','Normal','High'],
'Wind':['Weak','Weak','Strong','Strong','Strong','Strong','Weak','Strong','Weak','Strong'],
'Play':['No','Yes','Yes','Yes','No','No','Yes','No','Yes','No']
}

df = pd.DataFrame(data)
print("Dataset:\n",df)

# -------------------------------------
# ENCODE DATA
# -------------------------------------
df = pd.get_dummies(df)

X = df.drop('Play_Yes',axis=1)
y = df['Play_Yes']

# -------------------------------------
# TRAIN MODEL
# -------------------------------------
model = DecisionTreeClassifier(criterion='gini',max_depth=3)
model.fit(X,y)

# -------------------------------------
# TREE GRAPH
# -------------------------------------
plt.figure(figsize=(12,6))
plot_tree(model,feature_names=X.columns,class_names=['No','Yes'],filled=True)
plt.title("Decision Tree (Gini Impurity)")
plt.show()

# -------------------------------------
# PREDICTIONS
# -------------------------------------
y_pred = model.predict(X)

print("\nAccuracy:",accuracy_score(y,y_pred))
print("\nClassification Report:\n",classification_report(y,y_pred))

# -------------------------------------
# CONFUSION MATRIX (DIAGNOSTIC)
# -------------------------------------
cm = confusion_matrix(y,y_pred)

plt.figure(figsize=(5,4))
sns.heatmap(cm,annot=True,fmt='d',cmap='Blues',
            xticklabels=['No','Yes'],
            yticklabels=['No','Yes'])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()

# -------------------------------------
# FEATURE IMPORTANCE GRAPH
# -------------------------------------
importance = pd.Series(model.feature_importances_,index=X.columns)

importance.sort_values().plot(kind='barh',figsize=(8,5))
plt.title("Feature Importance (Gini Reduction)")
plt.xlabel("Importance")
plt.show()

END

"""