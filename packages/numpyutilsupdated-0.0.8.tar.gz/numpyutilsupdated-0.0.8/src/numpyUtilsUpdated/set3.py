code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 3 — SLR + Outlier Detection + Prediction Accuracy
# ============================================================

from sklearn.metrics import r2_score, mean_squared_error

# ---------- Step 1: Load & Build SLR (same as Q1) ----------
mba_df3 = pd.read_csv('MBA_salary.csv')
X3 = sm.add_constant(mba_df3['percentage in Grade 10'])
y3 = mba_df3['salary']

X3_train, X3_test, y3_train, y3_test = train_test_split(
    X3, y3, train_size=0.8, random_state=42)

mba_lm3 = sm.OLS(y3_train, X3_train).fit()
print('===== (i) SLR MODEL SUMMARY =====')
print(mba_lm3.summary2())

# ---------- Step 2 (ii): Outlier Detection — Z-score ----------
mba_df3['z_score_salary'] = zscore(mba_df3['salary'])
outliers_z = mba_df3[
    (mba_df3['z_score_salary'] > 3.0) | (mba_df3['z_score_salary'] < -3.0)
]
print('\n===== (ii) Outliers by Z-score (|z| > 3) =====')
print(outliers_z if not outliers_z.empty else 'No outliers found with |z| > 3 (dataset small, try |z|>2)')

# Try with 2 for small datasets
outliers_z2 = mba_df3[
    (mba_df3['z_score_salary'] > 2.0) | (mba_df3['z_score_salary'] < -2.0)
]
print('Outliers with |z| > 2:')
print(outliers_z2[['percentage in Grade 10', 'salary', 'z_score_salary']])

# ---------- Step 3 (ii): Outlier Detection — Cook's Distance ----------
mba_inf3    = mba_lm3.get_influence()
(cook_d, _) = mba_inf3.cooks_distance

plt.figure(figsize=(10, 5))
plt.stem(
    np.arange(len(X3_train)),
    np.round(cook_d, 3),
    markerfmt=','
)
n_train     = len(X3_train)
cutoff_cook = 4 / n_train
plt.axhline(y=cutoff_cook, color='red', linestyle='--',
            label=f"Cook's D cutoff (4/n = {cutoff_cook:.3f})")
plt.title("(ii) Cook's Distance for All Observations")
plt.xlabel('Row Index')
plt.ylabel("Cook's Distance")
plt.legend()
plt.show()

influential = np.where(cook_d > cutoff_cook)[0]
print(f"Influential observations (Cook's D > {cutoff_cook:.3f}): {influential}")

# ---------- Step 4 (iii): Predictions & Accuracy ----------
pred_y3  = mba_lm3.predict(X3_test)
r2_val   = np.abs(r2_score(y3_test, pred_y3))
rmse_val = np.sqrt(mean_squared_error(y3_test, pred_y3))

print('\n===== (iii) Prediction Accuracy =====')
print(f'R² Score : {round(r2_val, 4)}')
print(f'RMSE     : {round(rmse_val, 4)}')

print('''
EXPLANATION:
(ii) Z-score: standardizes salary values.
     Values with |z| > 3 are extreme outliers (>3 standard deviations from mean).
     For small datasets (n<50), use |z| > 2 as threshold.

     Cook's Distance: measures how much each data point influences model coefficients.
     Rule: Cook's D > 4/n = influential point (potential outlier).

(iii) R² (R-squared): proportion of variance in salary explained by the model.
      R² = 1.0 → perfect; R² = 0 → model explains nothing.
      RMSE: average prediction error in original salary units.
      Lower RMSE = more accurate predictions.
''')

END
"""