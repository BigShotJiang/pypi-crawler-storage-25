code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 13 — Imbalanced vs Balanced Logistic Regression
#               K-Fold CV (k=5) and ROC AUC Comparison
# ============================================================

from sklearn.model_selection import cross_val_score

# ---------- Step 1: Load Data ----------
bank_df13 = pd.read_csv('bank.csv')
bank_df13.rename(columns={'y': 'subscribed'}, inplace=True)
print('Class distribution (original - IMBALANCED):')
print(bank_df13['subscribed'].value_counts())

x_feat13 = [c for c in bank_df13.columns if c != 'subscribed']
enc13    = pd.get_dummies(bank_df13[x_feat13], drop_first=True)
y13      = bank_df13['subscribed'].map(lambda x: int(x == 'yes'))

# ---------- Step 2: IMBALANCED Model ----------
X13_tr, X13_te, y13_tr, y13_te = train_test_split(
    enc13, y13, test_size=0.3, random_state=42)

logit_imbal = LogisticRegression(max_iter=100000)
logit_imbal.fit(X13_tr, y13_tr)
pred_imbal  = logit_imbal.predict(X13_te)

print('\n===== IMBALANCED DATASET RESULTS =====')
print(metrics.classification_report(
    y13_te, pred_imbal, target_names=['Not Subscribed', 'Subscribed']))

cv_imbal = cross_val_score(logit_imbal, enc13, y13, cv=5, scoring='roc_auc')
print(f'K-Fold (k=5) AUC scores: {np.round(cv_imbal, 4)}')
print(f'Mean AUC (Imbalanced)  : {cv_imbal.mean():.4f}')

# ---------- Step 3: Create BALANCED Dataset ----------
subs_no13  = bank_df13[bank_df13.subscribed == 'no']
subs_yes13 = bank_df13[bank_df13.subscribed == 'yes']
df_up13    = resample(subs_yes13, replace=True, n_samples=2000)
balanced13 = shuffle(pd.concat([subs_no13, df_up13]))

print('\nClass distribution (BALANCED):')
print(balanced13['subscribed'].value_counts())

enc13_bal  = pd.get_dummies(balanced13[x_feat13], drop_first=True)
y13_bal    = balanced13['subscribed'].map(lambda x: int(x == 'yes'))

X13_b_tr, X13_b_te, y13_b_tr, y13_b_te = train_test_split(
    enc13_bal, y13_bal, test_size=0.3, random_state=42)

logit_bal13 = LogisticRegression(max_iter=100000)
logit_bal13.fit(X13_b_tr, y13_b_tr)
pred_bal13  = logit_bal13.predict(X13_b_te)

print('\n===== BALANCED DATASET RESULTS =====')
print(metrics.classification_report(
    y13_b_te, pred_bal13, target_names=['Not Subscribed', 'Subscribed']))

cv_bal13 = cross_val_score(logit_bal13, enc13_bal, y13_bal, cv=5, scoring='roc_auc')
print(f'K-Fold (k=5) AUC scores: {np.round(cv_bal13, 4)}')
print(f'Mean AUC (Balanced)    : {cv_bal13.mean():.4f}')

# ---------- Step 4: Side-by-Side ROC Comparison ----------
prob_imbal = logit_imbal.predict_proba(X13_te)[:, 1]
prob_bal   = logit_bal13.predict_proba(X13_b_te)[:, 1]

fpr_i, tpr_i, _ = metrics.roc_curve(y13_te, prob_imbal)
fpr_b, tpr_b, _ = metrics.roc_curve(y13_b_te, prob_bal)

auc_i = metrics.roc_auc_score(y13_te,  prob_imbal)
auc_b = metrics.roc_auc_score(y13_b_te, prob_bal)

plt.figure(figsize=(8, 6))
plt.plot(fpr_i, tpr_i, label=f'Imbalanced (AUC={auc_i:.2f})', color='red')
plt.plot(fpr_b, tpr_b, label=f'Balanced   (AUC={auc_b:.2f})', color='blue')
plt.plot([0, 1], [0, 1], 'k--', label='Random')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Comparison: Imbalanced vs Balanced')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

print(f'\n===== COMPARISON SUMMARY =====')
print(f'Imbalanced — Mean K-Fold AUC: {cv_imbal.mean():.4f}')
print(f'Balanced   — Mean K-Fold AUC: {cv_bal13.mean():.4f}')
print(f'Better model: {"Balanced" if cv_bal13.mean() > cv_imbal.mean() else "Imbalanced"}')

END

"""