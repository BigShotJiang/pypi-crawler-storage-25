code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 14 — KNN Algorithm
# ============================================================

# ---------- Step 1: Load & Balance Dataset ----------
bank_df14 = pd.read_csv('bank.csv')
bank_df14.rename(columns={'y': 'subscribed'}, inplace=True)

# Balance the dataset
b14_no  = bank_df14[bank_df14.subscribed == 'no']
b14_yes = bank_df14[bank_df14.subscribed == 'yes']
df14_up = resample(b14_yes, replace=True, n_samples=2000)
new14   = shuffle(pd.concat([b14_no, df14_up]))

x14_feat = [c for c in new14.columns if c != 'subscribed']
enc14    = pd.get_dummies(new14[x14_feat], drop_first=True)
y14      = new14['subscribed'].map(lambda x: int(x == 'yes'))

X14_tr, X14_te, y14_tr, y14_te = train_test_split(
    enc14, y14, test_size=0.3, random_state=42)

# ---------- Step 2: Train KNN with default k=5 ----------
knn14 = KNeighborsClassifier(n_neighbors=5)
knn14.fit(X14_tr, y14_tr)
pred14 = knn14.predict(X14_te)

# ---------- Step 3: Confusion Matrix ----------
cm14 = metrics.confusion_matrix(y14_te, pred14, labels=[1, 0])
plt.figure(figsize=(6, 5))
sns.heatmap(cm14, annot=True, fmt='.0f',
            xticklabels=['Subscribed', 'Not Subscribed'],
            yticklabels=['Subscribed', 'Not Subscribed'],
            cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('KNN Confusion Matrix (k=5)')
plt.show()

print('Classification Report (KNN k=5):')
print(metrics.classification_report(y14_te, pred14,
      target_names=['Not Subscribed', 'Subscribed']))

# ---------- Step 4: ROC Curve ----------
prob14       = knn14.predict_proba(X14_te)[:, 1]
fpr14, tpr14, _ = metrics.roc_curve(y14_te, prob14)
auc14        = metrics.roc_auc_score(y14_te, prob14)

plt.figure(figsize=(8, 6))
plt.plot(fpr14, tpr14, label=f'KNN ROC (AUC = {auc14:.2f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title(f'ROC Curve — KNN (AUC = {auc14:.2f})')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# ---------- Step 5: GridSearchCV — Tune k and Distance Metric ----------
print('\n===== GridSearchCV: Finding Best k and Metric =====')
tune_par = {
    'n_neighbors': range(5, 10),
    'metric'     : ['euclidean', 'canberra', 'minkowski']
}
clf_gs14 = GridSearchCV(
    KNeighborsClassifier(),
    tune_par,
    cv=10,
    scoring='roc_auc'
)
clf_gs14.fit(X14_tr, y14_tr)

print(f'Best AUC Score : {clf_gs14.best_score_:.4f}')
print(f'Best Parameters: {clf_gs14.best_params_}')
print(f'CV Results (mean AUC per combo):')
cv_results14 = pd.DataFrame(clf_gs14.cv_results_)
print(cv_results14[['params', 'mean_test_score']]
      .sort_values('mean_test_score', ascending=False)
      .head(10).to_string(index=False))

print('''
EXPLANATION:
KNN (K-Nearest Neighbours):
  For a new point, find the k closest training points.
  Predict the majority class among those k neighbours.

Distance Metrics:
  • Euclidean : √(Σ(x₁-x₂)²) — straight-line distance (most common)
  • Canberra  : Σ|x₁-x₂| / (|x₁|+|x₂|) — good for sparse/skewed data
  • Minkowski : generalizes Euclidean (p=2) and Manhattan (p=1)

Choosing k:
  • Small k (e.g. k=1): very sensitive, overfits to training data
  • Large k (e.g. k=50): too smooth, may underfit
  • GridSearchCV tries k=5,6,7,8,9 with each metric using 10-fold CV
    and picks the combination giving highest AUC.
''')

END

"""