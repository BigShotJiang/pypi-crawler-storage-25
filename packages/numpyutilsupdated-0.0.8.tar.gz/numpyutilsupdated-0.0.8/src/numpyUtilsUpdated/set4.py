code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 4 — MLR on IPL Dataset + Multicollinearity Check
# ============================================================

# ---------- Step 1: Load IPL Dataset ----------
IPL_df = pd.read_csv('IPL.csv')
print('Dataset Info:')
print(IPL_df.info())
print('\nFirst 5 rows (first 8 columns):')
print(IPL_df.iloc[0:5, 0:8])

# ---------- Step 2 (i): Build MLR Model ----------
# Encode categorical features
categorical_features = ['AGE', 'COUNTRY', 'PLAYING ROLE', 'CAPTAINCY EXP']
IPL_encoded_df = pd.get_dummies(
    IPL_df, columns=categorical_features, drop_first=True)

# Separate features and target
x_features = IPL_encoded_df.columns.tolist()
x_features.remove('SOLD PRICE')   # remove target column
# Remove non-numeric columns if any (like player names)
x_features = [col for col in x_features
               if IPL_encoded_df[col].dtype in ['int64','float64','uint8']]

X_ipl = sm.add_constant(IPL_encoded_df[x_features])
Y_ipl = IPL_df['SOLD PRICE']

X_ipl_train, X_ipl_test, y_ipl_train, y_ipl_test = train_test_split(
    X_ipl, Y_ipl, train_size=0.8, random_state=42)

IPL_model1 = sm.OLS(y_ipl_train, X_ipl_train).fit()

# ---------- Step 3 (ii): Model Summary ----------
print('\n===== (ii) MLR MODEL SUMMARY =====')
print(IPL_model1.summary2())

# ---------- Step 4 (iii): VIF — Multicollinearity Detection ----------
def get_VIF_factors(X_df):
    X_arr     = X_df.values
    vif_table = pd.DataFrame()
    vif_table['column'] = X_df.columns
    vif_table['VIF']    = [
        variance_inflation_factor(X_arr, i)
        for i in range(X_arr.shape[1])
    ]
    return vif_table

vif_table = get_VIF_factors(X_ipl_train[x_features])
print('\n===== (iii) VIF TABLE (sorted) =====')
print(vif_table.sort_values('VIF', ascending=False).to_string())

print('\n--- Features with HIGH multicollinearity (VIF > 10) ---')
high_vif = vif_table[vif_table['VIF'] > 10]
print(high_vif.to_string())
print(f'\nTotal features with VIF > 10: {len(high_vif)}')

print('''
EXPLANATION:
(i)  pd.get_dummies() converts categorical columns (AGE, COUNTRY etc.)
     into binary (0/1) columns — needed for regression.
     drop_first=True removes one dummy per category to avoid dummy trap.
     sm.OLS() with multiple features = Multiple Linear Regression (MLR).

(ii) Summary shows:
     • Adj. R-squared: overall model fit (higher = better)
     • Each feature's coefficient, std error, t-stat, p-value
     • AIC/BIC: model quality metrics (lower = better)

(iii) VIF (Variance Inflation Factor) measures multicollinearity:
     • VIF = 1      → No multicollinearity
     • VIF = 1-5    → Acceptable
     • VIF = 5-10   → Moderate (consider removing)
     • VIF > 10     → Severe multicollinearity → REMOVE this feature
     Features with VIF > 10 inflate standard errors and make coefficients unreliable.
''')

END

"""