code="""
# ============================================================
# COMMON IMPORTS — Run this cell FIRST before any question
# ============================================================
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample, shuffle
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.graphics.regressionplots import influence_plot
from scipy.cluster.hierarchy import dendrogram, linkage

print('All imports successful!')

# ============================================================
# QUESTION 9 — Gain & Lift Charts using bank.csv
# ============================================================

# ---------- Step 1: Load & Prepare Data ----------
bank_df9 = pd.read_csv('bank.csv')
bank_df9.rename(columns={'y': 'subscribed'}, inplace=True)
print('Class distribution:')
print(bank_df9['subscribed'].value_counts())

# ---------- Step 2: Upsample minority class (balance data) ----------
bank_no9  = bank_df9[bank_df9.subscribed == 'no']
bank_yes9 = bank_df9[bank_df9.subscribed == 'yes']

df_upsamp9  = resample(bank_yes9, replace=True, n_samples=2000)
new_bank9   = shuffle(pd.concat([bank_no9, df_upsamp9]))

# ---------- Step 3: Encode & Build Logistic Model ----------
x_feat9   = [c for c in new_bank9.columns if c != 'subscribed']
enc9      = pd.get_dummies(new_bank9[x_feat9], drop_first=True)
y9        = new_bank9['subscribed'].map(lambda x: int(x == 'yes'))

X9_tr, X9_te, y9_tr, y9_te = train_test_split(
    enc9, y9, test_size=0.3, random_state=42)

logit9 = LogisticRegression(max_iter=100000)
logit9.fit(X9_tr, y9_tr)

# ---------- Step 4: Gain & Lift Computation ----------
pred_prob9 = pd.DataFrame(
    logit9.predict_proba(X9_te), columns=[0, 1])

gain_df = pd.DataFrame({
    'actual': y9_te.values,
    'prob'  : pred_prob9[1].values
})

# Sort by predicted probability (highest first)
gain_df = gain_df.sort_values('prob', ascending=False).reset_index(drop=True)

# Create 10 equal deciles
gain_df['decile'] = pd.qcut(gain_df.index, q=10, labels=False)

total_events = gain_df['actual'].sum()
baseline_rate = total_events / len(gain_df)

lift_table = gain_df.groupby('decile').agg(
    count  = ('actual', 'count'),
    events = ('actual', 'sum')
).reset_index()

lift_table['cumulative_events'] = lift_table['events'].cumsum()
lift_table['cumulative_gain']   = (lift_table['cumulative_events'] / total_events) * 100
lift_table['lift']              = lift_table['events'] / (baseline_rate * lift_table['count'])

print('\n===== Gain & Lift Table =====')
print(lift_table.round(3).to_string())

# ---------- Step 5: Plot Gain Chart ----------
plt.figure(figsize=(14, 5))

plt.subplot(1, 2, 1)
plt.plot(range(1, 11), lift_table['cumulative_gain'],
         marker='o', color='blue', label='Model Gain')
plt.plot([1, 10], [10, 100], 'k--', label='Baseline (Random)')
plt.xlabel('Decile')
plt.ylabel('Cumulative Gain (%)')
plt.title('Gain Chart')
plt.xticks(range(1, 11))
plt.legend()
plt.grid(True, alpha=0.3)

# Plot Lift Chart
plt.subplot(1, 2, 2)
plt.plot(range(1, 11), lift_table['lift'],
         marker='o', color='green', label='Model Lift')
plt.axhline(y=1, color='red', linestyle='--', label='Baseline (Lift=1)')
plt.xlabel('Decile')
plt.ylabel('Lift')
plt.title('Lift Chart')
plt.xticks(range(1, 11))
plt.legend()
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

print('''
EXPLANATION:
Gain & Lift charts evaluate how well the model ranks customers.

Deciles: we sort all test records by predicted probability (high→low),
then divide into 10 equal groups (deciles).
Decile 1 = top 10% most likely to subscribe.

GAIN CHART:
• Shows cumulative % of actual subscribers captured as we contact more people.
• Steeper curve in early deciles = better model.
• If Decile 1 captures 40% of all subscribers, gain = 40% at 10% of population.

LIFT CHART:
• Lift = (% subscribers in decile) / (% subscribers overall = baseline).
• Lift = 3 in Decile 1 means model is 3× better than random.
• Lift should decrease as we go from Decile 1 to 10.
• Lift = 1 (red line) = no better than random.
''')

END

"""