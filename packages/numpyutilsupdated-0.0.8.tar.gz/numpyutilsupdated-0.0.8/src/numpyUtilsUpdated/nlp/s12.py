code="""
# input sentence
text = "The movie had great visuals but the story was bad."
# word lists
positive_words = ["great", "good", "excellent"]
negative_words = ["bad", "poor", "worst"]
# preprocessing
words = text.lower().replace(".", "").split()
# count
pos = 0
neg = 0
for w in words:
 if w in positive_words:
 pos += 1
 elif w in negative_words:
 neg += 1
# output
print("Positive words:", pos)
print("Negative words:", neg)
if pos > neg:
 print("Overall Sentiment: Positive")
elif neg > pos:
 print("Overall Sentiment: Negative")
else:
 print("Overall Sentiment: Neutral")


END
"""
def getCode():
    print(code)


