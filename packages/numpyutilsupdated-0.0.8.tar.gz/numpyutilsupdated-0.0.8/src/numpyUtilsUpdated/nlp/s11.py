code="""
from textblob import TextBlob
# input paragraph
text = '''The product quality is excellent and the delivery was very
fast.
I am satisfied with the service and would recommend it to others.'''
blob = TextBlob(text)
# sentiment
polarity = blob.sentiment.polarity
print("Polarity:", polarity)
if polarity > 0:
 print("Overall Sentiment: Positive")
elif polarity < 0:
 print("Overall Sentiment: Negative")
else:
 print("Overall Sentiment: Neutral")



END
"""
def getCode():
    print(code)


