code="""
 from nltk.stem import PorterStemmer
# input text
text = "Python is a powerful programming language and programmers love
programming"
# preprocessing
words = [w.strip('.,').lower() for w in text.split()]
# stemming
ps = PorterStemmer()
print("Original Words:")
print(words)
print("\nStemmed Words:")
print([ps.stem(w) for w in words])

END
"""
def getCode():
    print(code)

