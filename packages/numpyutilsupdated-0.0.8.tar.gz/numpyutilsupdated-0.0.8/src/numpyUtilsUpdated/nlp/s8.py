code="""
import stanza
stanza.download('en')
# load pipeline (with constituency parser)
nlp = stanza.Pipeline(lang='en', processors='tokenize,pos,constituency')
# input sentences
sentences = [
 "I skipped my breakfast today.",
 "I saw a boy with a telescope."
]
print("Constituency Parsing:")
for s in sentences:
 doc = nlp(s)
 print("\nSentence:", s)

 # print tree
 print(doc.sentences[0].constituency)


END
"""
def getCode():
    print(code)

