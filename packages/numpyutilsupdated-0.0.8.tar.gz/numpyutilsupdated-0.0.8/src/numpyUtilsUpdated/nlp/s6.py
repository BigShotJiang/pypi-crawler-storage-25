code="""
import nltk
nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger')
nltk.download('averaged_perceptron_tagger_eng')
from nltk import pos_tag
# input
sentences = [
 "I skipped my breakfast today",
 "I ate my breakfast today",
 "I ate my lunch yesterday",
 "I skipped my lunch today"
]
# -------- Statistical (SAFE) --------
print("Statistical POS Tagging:")
for s in sentences:
 words = s.split() # no tokenizer
 print(pos_tag(words))
# -------- Rule-Based --------
print("\nRule-Based POS Tagging:")
for s in sentences:
 words = s.lower().split()
 tags = []

 for w in words:
 if w in ["i", "my"]:
 tag = "PRON"
 elif w in ["skipped", "ate"]:
 tag = "VERB"
 elif w in ["breakfast", "lunch"]:
 tag = "NOUN"
 elif w in ["today", "yesterday"]:
 tag = "ADV"
 else:
 tag = "NOUN"

 tags.append((w, tag))

 print(tags)

END
"""
def getCode():
    print(code)

