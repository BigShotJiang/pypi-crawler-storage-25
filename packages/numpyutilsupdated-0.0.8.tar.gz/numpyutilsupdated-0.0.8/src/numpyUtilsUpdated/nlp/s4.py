code="""
import heapq
from collections import Counter
# actual dataset
text = '''I skipped my breakfast today
I ate my breakfast today
I ate my lunch yesterday
I skipped my lunch today'''
# preprocessing
words = text.lower().split()
# frequency
freq = Counter(words)
# sort for stable output (VERY IMPORTANT)
heap = [[wt, [word, ""]] for word, wt in sorted(freq.items())]
heapq.heapify(heap)
# build Huffman tree
while len(heap) > 1:
 lo = heapq.heappop(heap)
 hi = heapq.heappop(heap)
 for pair in lo[1:]:
 pair[1] = '0' + pair[1]
 for pair in hi[1:]:
 pair[1] = '1' + pair[1]
 heapq.heappush(heap, [lo[0] + hi[0]] + lo[1:] + hi[1:])
# output
print("Huffman Codes:")
for word, code in sorted(heap[0][1:]):
 print(word, ":", code, "(length =", len(code), ")")

END
"""
def getCode():
    print(code)

