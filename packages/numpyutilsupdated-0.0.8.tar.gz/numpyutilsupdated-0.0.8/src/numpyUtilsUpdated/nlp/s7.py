code="""

#pip install spacy
#python -m spacy download en_core_web_sm
import spacy
spacy.cli.download("en_core_web_sm")
# load model
nlp = spacy.load("en_core_web_sm")
# input sentences
sentences = [
 "I skipped my breakfast today.",
 "I saw a boy with a telescope."
]
print("Dependency Parsing:")
for s in sentences:
 doc = nlp(s)
 print("\nSentence:", s)

 for token in doc:
 print(token.text, "->", token.dep_, "->", token.head.text)


END
"""
def getCode():
    print(code)

