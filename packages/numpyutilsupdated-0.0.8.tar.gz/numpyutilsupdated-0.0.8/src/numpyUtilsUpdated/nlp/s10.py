code="""
# premise and hypothesis
premise = "I ate my breakfast today"
hypothesis = "I had breakfast"
print("Rule-Based NLI:")
p_words = set(premise.lower().split())
h_words = set(hypothesis.lower().split())
# -------- Rule-Based --------
if h_words.issubset(p_words):
 print("Entailment")
elif "not" in hypothesis.lower():
 print("Contradiction")
else:
 print("Neutral")
# -------- Word Alignment NLI --------
print("\nWord Alignment NLI:")
p_list = premise.lower().split()
h_list = hypothesis.lower().split()
aligned = 0
for w in h_list:
 if w in p_list:
 aligned += 1
# simple alignment score
if aligned == len(h_list):
 print("Entailment")
elif aligned > 0:
 print("Neutral")
else:
 print("Contradiction")


END
"""
def getCode():
    print(code)


