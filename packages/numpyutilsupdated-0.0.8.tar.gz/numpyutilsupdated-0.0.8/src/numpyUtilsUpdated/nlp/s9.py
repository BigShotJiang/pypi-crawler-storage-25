code="""
import re

persons = ["Narendra Modi", "Ravi"]
locations = ["New Delhi", "India", "Hyderabad", "London", "Washington"]
organizations = ["ISRO", "DRDO", "Microsoft", "IIT Delhi", "ACL Conference"]

text = '''Narendra Modi visited New Delhi on 26 January 2024.
He met officials from ISRO and DRDO in India.'''

words = text.split()

print(f"{'Word':12} -->  BIO Tag")

for word in words:
    word = word.strip(".,")
    if word in ["Narendra", "Modi", "Ravi"]:
        print(f"{word:12} -->  B-PER")
    
    elif word in ["Delhi", "India", "Hyderabad", "London", "Washington"]:
        print(f"{word:12} -->  B-LOC")

    elif word in ["ISRO", "DRDO", "Microsoft"]:
        print(f"{word:12} -->  B-ORG")

    elif re.match(r"\d{4}", word):
        print(f"{word:12} -->  B-DATE")

    else:
        print(f"{word:12} -->  O")
        

# !pip install sklearn-crfsuite
# import sklearn_crfsuite

# Training data
train_data = [
    [('Narendra','B-PER'), ('Modi','I-PER'), ('visited','O'),
     ('New','B-LOC'), ('Delhi','I-LOC')],
    [('Ravi','B-PER'), ('visited','O'), ('Hyderabad','B-LOC')]
]

# Feature function
def word_features(sent, i):
    w = sent[i][0]
    return {
        'w': w,
        'u': w.isupper(),
        't': w.istitle(),
        'd': w.isdigit()
    }

# Prepare data (compact)
X_train = [[word_features(s, i) for i in range(len(s))] for s in train_data]
y_train = [[tag for _, tag in s] for s in train_data]

# Train model
crf = sklearn_crfsuite.CRF()
crf.fit(X_train, y_train)

# Test sentence
test = [('Microsoft',''), ('collaborated',''), ('with',''), ('IIT',''), ('Delhi','')]

X_test = [[word_features(test, i) for i in range(len(test))]]

# Predict
print(crf.predict(X_test))


END
"""
def getCode():
    print(code)

