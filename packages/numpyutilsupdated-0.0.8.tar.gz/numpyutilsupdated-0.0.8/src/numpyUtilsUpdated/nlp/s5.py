code="""
# input sentences
sentences = [
 "I skipped my breakfast today",
 "I ate my breakfast today",
 "I ate my lunch yesterday",
 "I skipped my lunch today"
]
# preprocessing
words = []
for s in sentences:
 words.extend(s.lower().split())
# window size
w = 2
print("CBOW:")
for i in range(w, len(words)-w):
 context = words[i-w:i] + words[i+1:i+w+1]
 target = words[i]
 print(context, "->", target)
print("\nSkip-gram:")
for i in range(w, len(words)-w):
 target = words[i]
 context = [words[i-1], words[i+1]]
 for c in context:
 print(target, "->", c)

END
"""
def getCode():
    print(code)

