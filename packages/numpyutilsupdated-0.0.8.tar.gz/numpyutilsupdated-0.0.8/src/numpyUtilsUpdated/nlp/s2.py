code="""
from nltk.util import ngrams
# input corpus
text = "Python is a powerful programming language. It is widely used in
data science."
# preprocessing (clean + split)
words = [w.strip('.,').lower() for w in text.split()]
# i. corpus words
print("Corpus Words:")
print(words)
# ii. vocabulary
print("\nVocabulary:")
print(set(words))
# iii. unigrams
print("\nUnigrams:")
print(list(ngrams(words, 1)))
# iv. bigrams
print("\nBigrams:")
print(list(ngrams(words, 2)))
# v. n-grams (example: trigrams)
print("\nN-grams (3):")
print(list(ngrams(words, 3)))

END
"""
def getCode():
    print(code)

