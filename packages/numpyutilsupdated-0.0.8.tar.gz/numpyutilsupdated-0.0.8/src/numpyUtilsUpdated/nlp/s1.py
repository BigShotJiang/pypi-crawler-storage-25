code="""
from collections import Counter
import matplotlib.pyplot as plt
# create input.txt automatically
with open("input.txt", "w") as f:
 f.write("Python is a powerful programming language. It is widely
used in data science. Python is easy to learn. It also plays a major
role in natural language processing due to its rich set of libraries
like NLTK and spaCy. NLP has evolved through various generations,
starting from rule based systems to statistical models and now advanced
deep learning approaches. Modern NLP techniques powered by Python enable
machines to understand, interpret and generate human language
effectively.")
# read file
with open("input.txt", encoding="utf-8") as f:
 text = f.read()
# sentences
sentences = text.split('.')
print("a) Sentences:")
for i, s in enumerate(sentences):
 s = s.strip()
 if s:
 print(f"Sentence {i+1}: {s}")
# words in each sentence
print("\nb) Words in each sentence:")
all_words = []
for i, s in enumerate(sentences):
 words = [w.lower().strip('.,') for w in s.split()]
 if words:
 print(f"Sentence {i+1} words:", words)
 all_words.extend(words)
# word count in paragraph
print("\nc) Word count in paragraph:")
para_count = Counter(all_words)
print(dict(para_count))
# word count in each sentence
print("\nd) Word count in each sentence:")
for i, s in enumerate(sentences):
 words = [w.lower().strip('.,') for w in s.split()]
 if words:
 print(f"Sentence {i+1}:", dict(Counter(words)))
# top 10 words
print("\ne) Top 10 words:")
top = para_count.most_common(10)
words = [w for w, c in top]
counts = [c for w, c in top]
print(top)
3/23/26, 12:24 AM Jupyter Notebook — generated with runcell
about:blank 1/19
# bar chart
plt.bar(words, counts)
plt.title("Top words - Bar chart")
plt.xticks(rotation=45)
plt.show()
# pie chart
plt.pie(counts, labels=words, autopct='%1.1f%%')
plt.title("Top words - Pie chart")
plt.show()

END
"""
def getCode():
    print(code)

