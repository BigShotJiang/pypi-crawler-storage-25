# yh_olap

永辉 OLAP 数据查询与下载工具包。

## 安装

```bash
pip install yh_olap
```

## CLI 使用

### 登录

```bash
# 登录并保存凭据
yh_olap login login -u <用户名> -p <密码> -o <OTP密钥> --save --default

# 列出已保存的用户
yh_olap login list

# 删除用户凭据
yh_olap login logout <用户名>
yh_olap login logout --all  # 清除所有
```

### 执行 SQL

```bash
# 执行 SQL（默认 Impala 引擎）
yh_olap exec run "SELECT * FROM table LIMIT 10"

# 指定引擎
yh_olap exec run "SELECT 1" -e hive
yh_olap exec run "SELECT 1" -e clickhouse

# 从文件执行
yh_olap exec file query.sql

# 不等待执行完成
yh_olap exec run "SELECT * FROM large_table" --no-wait
```

### 获取结果

```bash
# 获取执行结果
yh_olap result get <request_id>

# 指定输出格式
yh_olap result get <request_id> -f json
yh_olap result get <request_id> -f csv

# 保存到文件
yh_olap result get <request_id> -o result.json

# 限制显示行数
yh_olap result get <request_id> -l 50
```

### 查询（执行+获取结果）

```bash
# 执行 SQL 并直接获取结果
yh_olap query run "SELECT * FROM table LIMIT 10"

# 指定引擎和格式
yh_olap query run "SELECT 1" -e hive -f csv

# 保存结果
yh_olap query run "SELECT * FROM table" -o result.json
```

### 下载

```bash
# 下载执行结果为 Excel
yh_olap download result <request_id> -o output.xlsx

# 执行 SQL 并下载
yh_olap download query "SELECT * FROM table" -o output.xlsx

# 从文件执行并下载
yh_olap download file query.sql -o output.xlsx
```

### 查看可用引擎

```bash
yh_olap engines list
```

### 交互模式

```bash
yh_olap i
```

交互模式内置命令：

| 命令 | 说明 |
|------|------|
| `help` | 显示帮助 |
| `exit` / `quit` | 退出 |
| `engine <name>` | 切换引擎 |
| `engines` | 列出可用引擎 |
| `result <id>` | 获取结果 |
| `download <id> [file]` | 下载结果 |
| `<SQL>` | 执行 SQL |

### 全局选项

```bash
yh_olap -v        # 显示版本
yh_olap -h        # 显示帮助
```

## Python API 使用

```python
from yh_olap import Client
from yh_olap.engine import Impala, Hive, Clickhouse

# 创建客户端并登录
client = Client()
client.login(username="xxx", password="xxx", otp_key="xxx")

# 执行 SQL
request_id = client.execute("SELECT * FROM table LIMIT 10", engine=Impala)

# 获取结果
result = client.sql_result(request_id, engine=Impala)
print(result["list"])  # 数据列表
print(result["columnNameList"])  # 列名

# 下载 Excel
client.download_excel(request_id, save_path="output.xlsx", engine=Impala)

# 切换引擎
client.execute("SELECT 1", engine=Hive)
client.execute("SELECT 1", engine=Clickhouse)
```

## 配置文件

用户凭据保存在 `~/.yh_olap/config.json`：

```json
{
  "users": {
    "<用户名>": {
      "password": "<base64编码>",
      "otp_key": "<base64编码>",
      "saved_at": "2026-04-05T22:31:56"
    }
  },
  "default_user": "<用户名>"
}
```

## License

MIT