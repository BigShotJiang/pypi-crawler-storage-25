import logging

logging.basicConfig(level=logging.WARNING)
import time
from yh_olap import Client
from yh_olap.engine import Hive, Impala

client = Client()
client.login(username="80858056", password="Zzwyh3142", otp_key="POAGVXQRRJF6ECMO")
print("=" * 20)
sql = """
select 
    m.shop_id
    ,g.manage_firm_id,g.manage_firm_name,g.dept_id,g.dept_name
    ,sum(restore_sales_amt) sales_amt
    ,sum(restore_gm_amt) gm_amt
from 
    dm.dm_sale_setl_dly_sum_1d s 
    inner join sjyy.sjyy_dim_shop m on s.shop_id = m.shop_id 
    inner join sjyy.sjyy_dim_goods g on s.goods_id = g.goods_id 
where 
    sdt between '20260404' and '20260404'
    and m.manage_dist_id <> ''
    and m.shop_biz_type_ud in ('1','2','4','5')
    and g.manage_firm_id <> '' 
    and g.bd_id between '10' and '12'
group by 
    m.shop_id,g.manage_firm_id,g.manage_firm_name,g.dept_id,g.dept_name
"""
# sql = 'select 1 xx'
# sql = """create table analyse_tmp.test_zzw_20260404 as
# select shop_id from dim.dim_shop"""
# sql = """drop table if exists analyse_tmp.test_zzw_20260404"""
executeId = client.execute(sql, wait_run_finish=True, engine=Impala)
a = client.sql_result(executeId,engine=Impala)
print(a)
print(client.to_dataframe(a))
