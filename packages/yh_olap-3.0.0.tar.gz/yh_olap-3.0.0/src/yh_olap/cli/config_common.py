"""CLI 公共配置"""

# 支持 -h 作为 --help 的别名
CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}