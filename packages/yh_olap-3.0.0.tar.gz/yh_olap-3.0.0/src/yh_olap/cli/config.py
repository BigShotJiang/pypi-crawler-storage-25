"""用户配置管理"""

import json
from pathlib import Path
from typing import Optional
from datetime import datetime

CONFIG_DIR = Path.home() / ".yh_olap"
CONFIG_FILE = CONFIG_DIR / "config.json"


class Config:
    """用户配置管理类"""

    def __init__(self) -> None:
        self._ensure_config_dir()

    def _ensure_config_dir(self) -> None:
        """确保配置目录存在"""
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_DIR.chmod(0o700)

    def save_user(
        self, username: str, password: str, otp_key: str, set_default: bool = False
    ) -> None:
        """保存用户凭据

        Args:
            username: 用户名
            password: 密码
            otp_key: OTP 密钥
            set_default: 是否设为默认用户
        """
        # 加密存储凭据
        from base64 import b64encode

        config = self._load_config()
        if "users" not in config:
            config["users"] = {}
        config["users"][username] = {
            "password": b64encode(password.encode()).decode(),
            "otp_key": b64encode(otp_key.encode()).decode(),
            "saved_at": datetime.now().isoformat(),
        }
        if set_default or "default_user" not in config:
            config["default_user"] = username
        self._save_config(config)

    def get_user(self, username: Optional[str] = None) -> tuple[str, str, str]:
        """获取用户凭据

        Args:
            username: 用户名，不指定则使用默认用户

        Returns:
            (username, password, otp_key)
        """
        from base64 import b64decode

        config = self._load_config()
        if username is None:
            username = config.get("default_user")
        if username is None:
            raise ValueError("未指定用户名且没有默认用户")

        user_data = config.get("users", {}).get(username)
        if user_data is None:
            raise ValueError(f"用户 {username} 的凭据不存在")

        password = b64decode(user_data["password"]).decode()
        otp_key = b64decode(user_data["otp_key"]).decode()

        return username, password, otp_key

    def list_users(self) -> list[str]:
        """列出所有保存的用户"""
        config = self._load_config()
        return list(config.get("users", {}).keys())

    def get_default_user(self) -> Optional[str]:
        """获取默认用户"""
        config = self._load_config()
        return config.get("default_user")

    def set_default_user(self, username: str) -> None:
        """设置默认用户"""
        config = self._load_config()
        if username not in config.get("users", {}):
            raise ValueError(f"用户 {username} 不存在")
        config["default_user"] = username
        self._save_config(config)

    def remove_user(self, username: str) -> None:
        """删除用户凭据"""
        config = self._load_config()
        if username in config.get("users", {}):
            del config["users"][username]
        if config.get("default_user") == username:
            config["default_user"] = None
        self._save_config(config)

    def clear_all_users(self) -> None:
        """清除所有用户凭据"""
        config = self._load_config()
        config["users"] = {}
        config["default_user"] = None
        self._save_config(config)

    def _load_config(self) -> dict:
        """加载配置文件"""
        if not CONFIG_FILE.exists():
            return {}
        try:
            return json.loads(CONFIG_FILE.read_text())
        except json.JSONDecodeError:
            return {}

    def _save_config(self, config: dict) -> None:
        """保存配置文件"""
        CONFIG_FILE.write_text(json.dumps(config, indent=2, ensure_ascii=False))
        CONFIG_FILE.chmod(0o600)