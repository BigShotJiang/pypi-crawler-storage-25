"""CLI 工具函数"""

from typing import Optional
from rich.console import Console

console = Console()

# 引擎映射
ENGINE_MAP = {
    "impala": "Impala",
    "hive": "Hive",
    "clickhouse": "Clickhouse",
}


def get_client(username: Optional[str] = None) -> "Client":
    """获取已登录的客户端实例

    Args:
        username: 用户名，不指定则使用默认用户

    Returns:
        已登录的 Client 实例
    """
    from yh_olap import Client
    from .config import Config

    config = Config()

    try:
        username, password, otp_key = config.get_user(username)
        client = Client()
        client.login(username, password, otp_key)
        return client
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        console.print("[yellow]请先使用 yh_olap login 登录[/yellow]")
        raise SystemExit(1)


def get_engine(engine_name: str = "impala") -> type:
    """根据名称获取引擎类

    Args:
        engine_name: 引擎名称，默认 impala

    Returns:
        引擎类
    """
    from yh_olap.engine import Hive, Impala, Clickhouse

    engines = {
        "impala": Impala,
        "hive": Hive,
        "clickhouse": Clickhouse,
    }

    engine_name = engine_name.lower()
    if engine_name not in engines:
        console.print(f"[red]未知引擎: {engine_name}[/red]")
        console.print(f"[yellow]可用引擎: {', '.join(engines.keys())}[/yellow]")
        raise SystemExit(1)

    return engines[engine_name]