"""CLI 主入口"""

import typer
from typing import Optional

from .commands import login_app, exec_app, result_app, query_app, download_app, engines_app
from .commands.interactive import start_interactive_mode
from .config_common import CONTEXT_SETTINGS

app = typer.Typer(
    name="yh_olap",
    help="YH OLAP 命令行工具 - OLAP 数据查询与下载",
    add_completion=False,
    context_settings=CONTEXT_SETTINGS,
)

# 注册子命令
app.add_typer(login_app, name="login", help="用户登录管理")
app.add_typer(exec_app, name="exec", help="执行 SQL")
app.add_typer(result_app, name="result", help="获取 SQL 执行结果")
app.add_typer(query_app, name="query", help="执行 SQL 并获取结果")
app.add_typer(download_app, name="download", help="下载查询结果")
app.add_typer(engines_app, name="engines", help="查询可用引擎")


@app.command(name="i")
def interactive() -> None:
    """启动交互模式"""
    start_interactive_mode()


@app.callback(invoke_without_command=True)
def main(
    version: bool = typer.Option(
        False, "--version", "-v", help="显示版本信息", is_eager=True
    ),
) -> None:
    """YH OLAP 命令行工具"""
    if version:
        typer.echo("yh_olap version 3.0.0")
        raise typer.Exit()