"""引擎查询命令"""

import typer
from rich.console import Console
from rich.table import Table

from ..config_common import CONTEXT_SETTINGS

app = typer.Typer(help="查询可用引擎", context_settings=CONTEXT_SETTINGS)
console = Console()


@app.command("list")
def list_engines() -> None:
    """列出所有可用的查询引擎"""
    from yh_olap.engine import Hive, Impala, Clickhouse

    table = Table(title="可用查询引擎")
    table.add_column("名称", style="cyan")
    table.add_column("引擎代码", style="green")
    table.add_column("数据源ID", style="yellow")
    table.add_column("默认", style="magenta")

    engines = [
        ("Impala", Impala, True),
        ("Hive", Hive, False),
        ("Clickhouse", Clickhouse, False),
    ]

    for name, cls, is_default in engines:
        default_mark = "✓" if is_default else ""
        table.add_row(name, cls.engine, str(cls.dsId), default_mark)

    console.print(table)
    console.print("[dim]使用 -e/--engine 参数指定引擎，默认为 impala[/dim]")