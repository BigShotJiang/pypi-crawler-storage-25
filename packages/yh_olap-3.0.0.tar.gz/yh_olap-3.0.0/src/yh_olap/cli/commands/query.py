"""查询命令（执行+获取结果）"""

import typer
from typing import Optional
from pathlib import Path
from rich.console import Console
from rich.table import Table
import json

from ..utils import get_client, get_engine
from ..config_common import CONTEXT_SETTINGS

app = typer.Typer(help="执行 SQL 并获取结果", context_settings=CONTEXT_SETTINGS)
console = Console()


@app.command()
def run(
    sql: str = typer.Argument(..., help="要执行的 SQL 语句"),
    engine: str = typer.Option("impala", "--engine", "-e", help="查询引擎 (impala/hive/clickhouse)"),
    username: Optional[str] = typer.Option(None, "--user", "-u", help="用户名"),
    format: str = typer.Option("table", "--format", "-f", help="输出格式 (table/json/csv)"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="输出文件路径"),
    limit: int = typer.Option(20, "--limit", "-l", help="显示行数限制"),
) -> dict:
    """执行 SQL 并获取结果"""
    client = get_client(username)
    engine_cls = get_engine(engine)

    try:
        with console.status("[bold blue]执行 SQL...[/bold blue]"):
            request_id = client.execute(sql, engine=engine_cls)

        console.print(f"[blue]Request ID: {request_id}[/blue]")

        with console.status("[bold blue]获取结果...[/bold blue]"):
            result = client.sql_result(request_id, engine=engine_cls)

        if format == "table":
            table = Table(title=f"查询结果 ({len(result['list'])} 行)")
            for col in result["columnNameList"]:
                table.add_column(col)

            for row in result["list"][:limit]:
                table.add_row(*[str(v) if v is not None else "NULL" for v in row.values()])

            console.print(table)
            if len(result["list"]) > limit:
                console.print(f"[dim]... 还有 {len(result['list']) - limit} 行[/dim]")

        elif format == "json":
            output_str = json.dumps(result, ensure_ascii=False, indent=2)
            console.print(output_str)

        elif format == "csv":
            import csv
            from io import StringIO
            buffer = StringIO()
            writer = csv.DictWriter(buffer, fieldnames=result["columnNameList"])
            writer.writeheader()
            writer.writerows(result["list"])
            console.print(buffer.getvalue())

        if output:
            output.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
            console.print(f"[green]已保存到: {output}[/green]")

        return result

    except Exception as e:
        console.print(f"[red]查询失败: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def file(
    sql_file: Path = typer.Argument(..., help="SQL 文件路径", exists=True),
    engine: str = typer.Option("impala", "--engine", "-e", help="查询引擎 (impala/hive/clickhouse)"),
    username: Optional[str] = typer.Option(None, "--user", "-u", help="用户名"),
    format: str = typer.Option("table", "--format", "-f", help="输出格式 (table/json/csv)"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="输出文件路径"),
    limit: int = typer.Option(20, "--limit", "-l", help="显示行数限制"),
) -> dict:
    """从文件执行 SQL 并获取结果"""
    sql = sql_file.read_text(encoding="utf-8")
    console.print(f"[blue]读取文件: {sql_file}[/blue]")
    return run(
        sql=sql,
        engine=engine,
        username=username,
        format=format,
        output=output,
        limit=limit,
    )