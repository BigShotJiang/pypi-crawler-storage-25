"""交互模式"""

from pathlib import Path
import shlex

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.lexers import PygmentsLexer
from prompt_toolkit.styles import Style
from pygments.lexers.sql import SqlLexer
from rich.console import Console
from rich.table import Table

from ..config import Config
from ..utils import get_engine

console = Console()
HISTORY_FILE = Path.home() / ".yh_olap" / "history"


def start_interactive_mode() -> None:
    """启动交互模式"""
    from yh_olap import Client

    config = Config()
    username = config.get_default_user()

    if not username:
        console.print("[red]请先使用 yh_olap login 登录[/red]")
        return

    username, password, otp_key = config.get_user(username)
    client = Client()
    client.login(username, password, otp_key)

    console.print(f"[green]已登录用户: {username}[/green]")
    console.print("输入 SQL 或命令。输入 'help' 查看帮助，'exit' 退出。")

    # 创建会话
    session: PromptSession = PromptSession(
        history=FileHistory(str(HISTORY_FILE)),
        auto_suggest=AutoSuggestFromHistory(),
        lexer=PygmentsLexer(SqlLexer),
        style=Style.from_dict({"prompt": "ansicyan bold"}),
    )

    current_engine = "impala"
    engine_cls = get_engine(current_engine)

    while True:
        try:
            user_input = session.prompt(
                f"yh_olap ({current_engine})> ", multiline=False
            ).strip()

            if not user_input:
                continue

            # 处理内置命令
            if user_input.lower() in ("exit", "quit"):
                console.print("[blue]再见！[/blue]")
                break

            elif user_input.lower() == "help":
                show_help()

            elif user_input.lower().startswith("engine "):
                # 切换引擎
                new_engine = user_input[7:].strip().lower()
                if new_engine in ("hive", "impala", "clickhouse"):
                    current_engine = new_engine
                    engine_cls = get_engine(current_engine)
                    console.print(f"[green]已切换到 {current_engine} 引擎[/green]")
                else:
                    console.print("[red]未知引擎，可选: hive, impala, clickhouse[/red]")

            elif user_input.lower() == "engines":
                # 显示可用引擎
                show_engines()

            elif user_input.lower().startswith("download "):
                # 下载结果
                parts = shlex.split(user_input[9:])
                if len(parts) >= 1:
                    request_id = parts[0]
                    output = parts[1] if len(parts) > 1 else f"{request_id}.xlsx"
                    try:
                        with console.status("[bold blue]下载中...[/bold blue]"):
                            file_path = client.download_excel(
                                request_id, save_path=output, engine=engine_cls
                            )
                        console.print(f"[green]已下载: {file_path}[/green]")
                    except Exception as e:
                        console.print(f"[red]下载失败: {e}[/red]")

            elif user_input.lower().startswith("result "):
                # 获取结果
                request_id = user_input[7:].strip()
                try:
                    with console.status("[bold blue]获取结果...[/bold blue]"):
                        result = client.sql_result(request_id, engine=engine_cls)
                    display_result(result)
                except Exception as e:
                    console.print(f"[red]获取结果失败: {e}[/red]")

            else:
                # 作为 SQL 执行
                try:
                    with console.status("[bold blue]执行中...[/bold blue]"):
                        request_id = client.execute(user_input, engine=engine_cls)

                    console.print(f"[blue]Request ID: {request_id}[/blue]")

                    # 尝试获取结果预览
                    try:
                        result = client.result_preview(request_id)
                        display_result(result, limit=10)
                    except Exception:
                        pass  # DDL 语句可能没有结果

                except Exception as e:
                    console.print(f"[red]执行失败: {e}[/red]")

        except KeyboardInterrupt:
            console.print("\n[yellow]已取消[/yellow]")
        except EOFError:
            console.print("\n[blue]再见！[/blue]")
            break


def show_help() -> None:
    """显示帮助信息"""
    help_table = Table(title="交互模式命令")
    help_table.add_column("命令", style="cyan")
    help_table.add_column("说明")

    commands = [
        ("help", "显示帮助信息"),
        ("exit / quit", "退出交互模式"),
        ("engine <name>", "切换引擎 (hive/impala/clickhouse)"),
        ("engines", "列出所有可用引擎"),
        ("result <request_id>", "获取指定请求的结果"),
        ("download <request_id> [file]", "下载结果到 Excel 文件"),
        ("<SQL>", "执行 SQL 语句"),
    ]

    for cmd, desc in commands:
        help_table.add_row(cmd, desc)

    console.print(help_table)


def show_engines() -> None:
    """显示可用引擎"""
    from yh_olap.engine import Hive, Impala, Clickhouse

    table = Table(title="可用查询引擎")
    table.add_column("名称", style="cyan")
    table.add_column("默认", style="magenta")

    engines = [("Impala", True), ("Hive", False), ("Clickhouse", False)]

    for name, is_default in engines:
        default_mark = "✓" if is_default else ""
        table.add_row(name, default_mark)

    console.print(table)


def display_result(result: dict, limit: int = 20) -> None:
    """显示查询结果"""
    table = Table(title=f"结果 ({len(result['list'])} 行)")

    for col in result["columnNameList"]:
        table.add_column(col)

    for row in result["list"][:limit]:
        table.add_row(*[str(v) if v is not None else "NULL" for v in row.values()])

    console.print(table)

    if len(result["list"]) > limit:
        console.print(f"[dim]... 还有 {len(result['list']) - limit} 行[/dim]")