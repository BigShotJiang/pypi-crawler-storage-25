"""下载命令"""

import typer
from typing import Optional
from pathlib import Path
from rich.console import Console

from ..utils import get_client, get_engine
from ..config_common import CONTEXT_SETTINGS

app = typer.Typer(help="下载查询结果", context_settings=CONTEXT_SETTINGS)
console = Console()


@app.command()
def result(
    request_id: str = typer.Argument(..., help="SQL 执行请求 ID"),
    output: Path = typer.Option(..., "--output", "-o", help="输出文件路径"),
    username: Optional[str] = typer.Option(None, "--user", "-u", help="用户名"),
    engine: str = typer.Option("impala", "--engine", "-e", help="查询引擎 (impala/hive/clickhouse)"),
) -> str:
    """下载 SQL 执行结果为 Excel"""
    client = get_client(username)
    engine_cls = get_engine(engine)

    try:
        with console.status("[bold blue]下载中...[/bold blue]"):
            file_path = client.download_excel(
                request_id, save_path=str(output), engine=engine_cls
            )
        console.print(f"[green]下载完成: {file_path}[/green]")
        return file_path

    except Exception as e:
        console.print(f"[red]下载失败: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def query(
    sql: str = typer.Argument(..., help="要执行的 SQL 语句"),
    output: Path = typer.Option(..., "--output", "-o", help="输出文件路径"),
    engine: str = typer.Option("impala", "--engine", "-e", help="查询引擎 (impala/hive/clickhouse)"),
    username: Optional[str] = typer.Option(None, "--user", "-u", help="用户名"),
) -> str:
    """执行 SQL 并下载结果"""
    client = get_client(username)
    engine_cls = get_engine(engine)

    try:
        with console.status("[bold blue]执行 SQL...[/bold blue]"):
            request_id = client.execute(sql, engine=engine_cls)

        console.print(f"[blue]Request ID: {request_id}[/blue]")

        with console.status("[bold blue]下载结果...[/bold blue]"):
            file_path = client.download_excel(
                request_id, save_path=str(output), engine=engine_cls
            )

        console.print(f"[green]下载完成: {file_path}[/green]")
        return file_path

    except Exception as e:
        console.print(f"[red]操作失败: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def file(
    sql_file: Path = typer.Argument(..., help="SQL 文件路径", exists=True),
    output: Path = typer.Option(..., "--output", "-o", help="输出文件路径"),
    engine: str = typer.Option("impala", "--engine", "-e", help="查询引擎 (impala/hive/clickhouse)"),
    username: Optional[str] = typer.Option(None, "--user", "-u", help="用户名"),
) -> str:
    """从文件执行 SQL 并下载结果"""
    sql = sql_file.read_text(encoding="utf-8")
    console.print(f"[blue]读取文件: {sql_file}[/blue]")
    return query(sql=sql, output=output, engine=engine, username=username)