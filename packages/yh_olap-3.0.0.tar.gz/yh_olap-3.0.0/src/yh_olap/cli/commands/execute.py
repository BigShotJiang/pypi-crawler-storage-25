"""执行 SQL 命令"""

import typer
from typing import Optional
from pathlib import Path
from rich.console import Console
from rich.syntax import Syntax

from ..utils import get_client, get_engine
from ..config_common import CONTEXT_SETTINGS

app = typer.Typer(help="执行 SQL", context_settings=CONTEXT_SETTINGS)
console = Console()


@app.command()
def run(
    sql: str = typer.Argument(..., help="要执行的 SQL 语句"),
    engine: str = typer.Option("impala", "--engine", "-e", help="查询引擎 (impala/hive/clickhouse)"),
    username: Optional[str] = typer.Option(None, "--user", "-u", help="用户名"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="等待执行完成"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="显示详细信息"),
) -> str:
    """执行 SQL 语句"""
    client = get_client(username)
    engine_cls = get_engine(engine)

    if verbose:
        console.print(f"[blue]引擎: {engine}[/blue]")
        syntax = Syntax(sql, "sql", theme="monokai")
        console.print(syntax)

    try:
        with console.status("[bold blue]执行中...[/bold blue]"):
            request_id = client.execute(sql, engine=engine_cls, wait_run_finish=wait)

        if wait:
            console.print("[green]执行完成[/green]")
        console.print(f"[blue]Request ID: {request_id}[/blue]")
        return request_id

    except Exception as e:
        console.print(f"[red]执行失败: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def file(
    sql_file: Path = typer.Argument(..., help="SQL 文件路径", exists=True),
    engine: str = typer.Option("impala", "--engine", "-e", help="查询引擎 (impala/hive/clickhouse)"),
    username: Optional[str] = typer.Option(None, "--user", "-u", help="用户名"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="等待执行完成"),
) -> str:
    """从文件执行 SQL"""
    sql = sql_file.read_text(encoding="utf-8")
    console.print(f"[blue]读取文件: {sql_file}[/blue]")
    return run(sql=sql, engine=engine, username=username, wait=wait, verbose=True)