"""CLI 命令模块"""

from .login import app as login_app
from .execute import app as exec_app
from .result import app as result_app
from .query import app as query_app
from .download import app as download_app
from .engines import app as engines_app

__all__ = [
    "login_app",
    "exec_app",
    "result_app",
    "query_app",
    "download_app",
    "engines_app",
]