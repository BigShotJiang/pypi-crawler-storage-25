"""登录命令"""

import typer
from typing import Optional
from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from ..config import Config
from ..config_common import CONTEXT_SETTINGS

app = typer.Typer(help="用户登录管理", context_settings=CONTEXT_SETTINGS)
console = Console()


@app.command()
def login(
    username: Optional[str] = typer.Option(None, "--user", "-u", help="用户名"),
    password: Optional[str] = typer.Option(None, "--password", "-p", help="密码"),
    otp_key: Optional[str] = typer.Option(None, "--otp", "-o", help="OTP 密钥"),
    save: bool = typer.Option(True, "--save/--no-save", help="是否保存凭据"),
    set_default: bool = typer.Option(False, "--default", "-d", help="设为默认用户"),
) -> None:
    """登录 OLAP 系统"""
    from yh_olap import Client

    config = Config()

    # 如果未提供用户名，尝试使用保存的用户
    if username is None:
        saved_users = config.list_users()
        if saved_users:
            default = config.get_default_user()
            console.print("[blue]已保存的用户:[/blue]")
            for user in saved_users:
                mark = " (默认)" if user == default else ""
                console.print(f"  - {user}{mark}")
            username = Prompt.ask("选择用户或输入新用户名", default=default or "")
            if username in saved_users:
                # 使用保存的凭据
                username, password, otp_key = config.get_user(username)
        else:
            username = Prompt.ask("请输入用户名")

    # 交互式输入缺失的凭据
    if password is None:
        password = typer.prompt("请输入密码", hide_input=True)
    if otp_key is None:
        otp_key = typer.prompt("请输入 OTP 密钥", hide_input=True)

    # 执行登录
    try:
        client = Client()
        client.login(username, password, otp_key)
        console.print("[green]登录成功！[/green]")

        # 保存凭据
        if save:
            config.save_user(username, password, otp_key, set_default=set_default)
            console.print("[blue]凭据已保存[/blue]")
            if set_default:
                console.print(f"[blue]已设为默认用户: {username}[/blue]")
    except Exception as e:
        console.print(f"[red]登录失败: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def logout(
    username: Optional[str] = typer.Argument(None, help="要登出的用户名"),
    all: bool = typer.Option(False, "--all", "-a", help="清除所有用户"),
) -> None:
    """删除保存的用户凭据"""
    config = Config()

    if all:
        config.clear_all_users()
        console.print("[green]已清除所有保存的凭据[/green]")
    elif username:
        config.remove_user(username)
        console.print(f"[green]已清除用户 {username} 的凭据[/green]")
    else:
        console.print("[red]请指定用户名或使用 --all[/red]")
        raise typer.Exit(1)


@app.command("list")
def list_users() -> None:
    """列出所有保存的用户"""
    config = Config()
    users = config.list_users()
    default = config.get_default_user()

    if not users:
        console.print("没有保存的用户")
        return

    table = Table(title="已保存的用户")
    table.add_column("用户名")
    table.add_column("默认")

    for user in users:
        is_default = "✓" if user == default else ""
        table.add_row(user, is_default)

    console.print(table)