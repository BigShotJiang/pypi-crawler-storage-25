import os

import httpx
import aiofiles
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yh_olap.client import Client


class Download:
    """下载管理 - 提供 SQL 结果下载功能。"""

    def __init__(self, client: 'Client') -> None:
        """初始化 Download。

        Args:
            client: OLAP 客户端实例。
        """
        self.__client = client

    def olapResultSimple(self, requestId: str, save_path: str | None = None) -> str:
        """快速下载 SQL 结果 (1000 条)。

        Args:
            requestId: SQL 执行请求 ID。
            save_path: 保存文件路径，默认为 {requestId}.xlsx。

        Returns:
            保存的文件路径。
        """
        if not save_path:
            save_path = f'{requestId}.xlsx'
        url = self.__client.base_url + '/download/olapResultSimple/' + requestId
        headers = self.__client.headers
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.get(url=url, headers=headers)

        save_dir = os.path.dirname(save_path)

        if save_dir:
            os.makedirs(save_dir, exist_ok=True)

        with open(save_path, 'wb') as f:
            f.write(response.content)
        return save_path

    async def olapResultSimple_async(self, requestId: str, save_path: str | None = None) -> str:
        """快速下载 SQL 结果 (1000 条) - 异步。

        Args:
            requestId: SQL 执行请求 ID。
            save_path: 保存文件路径，默认为 {requestId}.xlsx。

        Returns:
            保存的文件路径。
        """
        if not save_path:
            save_path = f'{requestId}.xlsx'
        url = self.__client.base_url + '/download/olapResultSimple/' + requestId
        headers = self.__client.headers
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.get(url=url, headers=headers)
        async with aiofiles.open(save_path, 'wb') as f:
            await f.write(response.content)
        return save_path

    def refresh(self, downloadId: int) -> dict:
        """刷新下载任务。

        Args:
            downloadId: 下载任务 ID。

        Returns:
            刷新结果。
        """
        url = self.__client.base_url + '/download/refresh?downloadId=%s' % downloadId
        headers = self.__client.headers
        data = {'downloadId': downloadId}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def refresh_async(self, downloadId: int) -> dict:
        """刷新下载任务 - 异步。

        Args:
            downloadId: 下载任务 ID。

        Returns:
            刷新结果。
        """
        url = self.__client.base_url + '/download/refresh?downloadId=%s' % downloadId
        headers = self.__client.headers
        data = {'downloadId': downloadId}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def olapResult(self, requestId: str, file_path: str | None = None) -> str:
        """下载 SQL 结果为 Excel 文件。

        Args:
            requestId: SQL 执行请求 ID。
            file_path: 保存文件路径，默认为 {requestId}.xlsx。

        Returns:
            保存的文件路径。
        """
        if not file_path:
            file_path = f'{requestId}.xlsx'
        url = self.__client.base_url + '/download/olapResult/' + requestId
        headers = self.__client.headers
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.get(url=url, headers=headers)
        with open(file_path, 'wb') as f:
            f.write(response.content)
        return file_path

    async def olapResult_async(self, requestId: str, file_path: str | None = None) -> str:
        """下载 SQL 结果为 Excel 文件 - 异步。

        Args:
            requestId: SQL 执行请求 ID。
            file_path: 保存文件路径，默认为 {requestId}.xlsx。

        Returns:
            保存的文件路径。
        """
        if not file_path:
            file_path = f'{requestId}.xlsx'
        url = self.__client.base_url + '/download/olapResult/' + requestId
        headers = self.__client.headers
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.get(url=url, headers=headers)
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(response.content)
        return file_path

    def downloadToExcel(self, requestId: str, fileName: str, file_path: str | None = None) -> str:
        """下载 SQL 结果为 Excel 文件 (Impala 引擎)。

        Args:
            requestId: SQL 执行请求 ID。
            fileName: 文件名。
            file_path: 保存文件路径，默认为 {requestId}.xlsx。

        Returns:
            保存的文件路径。
        """
        if not file_path:
            file_path = f'{requestId}.xlsx'
        url = f'https://prokongbigdata.yonghui.cn/yh-magpie-bridge-manager/open/api/downloadToExcel?requestId={requestId}&fileName={fileName}'
        headers = self.__client.headers
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.get(url=url, headers=headers)
        with open(file_path, 'wb') as f:
            f.write(response.content)
        return file_path

    async def downloadToExcel_async(self, requestId: str, fileName: str, file_path: str | None = None) -> str:
        """下载 SQL 结果为 Excel 文件 (Impala 引擎) - 异步。

        Args:
            requestId: SQL 执行请求 ID。
            fileName: 文件名。
            file_path: 保存文件路径，默认为 {requestId}.xlsx。

        Returns:
            保存的文件路径。
        """
        if not file_path:
            file_path = f'{requestId}.xlsx'
        url = f'https://prokongbigdata.yonghui.cn/yh-magpie-bridge-manager/open/api/downloadToExcel?requestId={requestId}&fileName={fileName}'
        headers = self.__client.headers
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.get(url=url, headers=headers)
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(response.content)
        return file_path