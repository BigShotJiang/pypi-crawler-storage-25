import httpx
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yh_olap.client import Client
from yh_olap.engine import Engine, Hive


class Approval:
    """审批管理 - 提供下载订单创建、查询等功能。"""

    def __init__(self, client: 'Client') -> None:
        """初始化 Approval。

        Args:
            client: OLAP 客户端实例。
        """
        self.__client = client

    def createMiddleDownloadOrder(self, requestId: str, engine: type[Engine] = Hive) -> dict:
        """创建下载数据订单 (50000 条)。

        Args:
            requestId: SQL 执行请求 ID。
            engine: 查询引擎，默认为 Hive。

        Returns:
            订单创建结果，包含订单 ID 等信息。
        """
        url = self.__client.base_url + '/approval/createMiddleDownloadOrder'
        headers = self.__client.headers
        data = {'requestId': requestId, 'engine': engine.engine}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.put(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def createMiddleDownloadOrder_async(self, requestId: str, engine: type[Engine] = Hive) -> dict:
        """创建下载数据订单 (50000 条) - 异步。

        Args:
            requestId: SQL 执行请求 ID。
            engine: 查询引擎，默认为 Hive。

        Returns:
            订单创建结果，包含订单 ID 等信息。
        """
        url = self.__client.base_url + '/approval/createMiddleDownloadOrder'
        headers = self.__client.headers
        data = {'requestId': requestId, 'engine': engine.engine}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.put(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def createSkipDownloadOrder(self, requestId: str, engine: type[Engine] = Hive) -> dict:
        """创建下载全量数据订单 (500000 条)。

        引擎使用 Impala 时不支持CTE,不支持结果最外层 select 使用 distinct,不支持最外层 select *。

        Args:
            requestId: SQL 执行请求 ID。
            engine: 查询引擎，默认为 Hive。

        Returns:
            订单创建结果，包含订单 ID 等信息。
        """
        url = self.__client.base_url + '/approval/createSkipDownloadOrder'
        headers = self.__client.headers
        data = {'requestId': requestId, 'engine': engine.engine}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.put(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def createSkipDownloadOrder_async(self, requestId: str, engine: type[Engine] = Hive) -> dict:
        """创建下载全量数据订单 (500000 条) - 异步。

        引擎使用 Impala 时不支持CTE,不支持结果最外层 select 使用 distinct,不支持最外层 select *。

        Args:
            requestId: SQL 执行请求 ID。
            engine: 查询引擎，默认为 Hive。

        Returns:
            订单创建结果，包含订单 ID 等信息。
        """
        url = self.__client.base_url + '/approval/createSkipDownloadOrder'
        headers = self.__client.headers
        data = {'requestId': requestId, 'engine': engine.engine}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.put(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def detail(self, approvalId: int) -> dict:
        """查看下载任务明细。

        Args:
            approvalId: 审批订单 ID。

        Returns:
            任务明细，包含任务状态、数据量等信息。
        """
        url = self.__client.base_url + '/approval/detail?approvalId=%s' % approvalId
        headers = self.__client.headers
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.get(url=url, headers=headers)
            result = response.json()
        return result

    async def detail_async(self, approvalId: int) -> dict:
        """查看下载任务明细 - 异步。

        Args:
            approvalId: 审批订单 ID。

        Returns:
            任务明细，包含任务状态、数据量等信息。
        """
        url = self.__client.base_url + '/approval/detail?approvalId=%s' % approvalId
        headers = self.__client.headers
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.get(url=url, headers=headers)
            result = response.json()
        return result