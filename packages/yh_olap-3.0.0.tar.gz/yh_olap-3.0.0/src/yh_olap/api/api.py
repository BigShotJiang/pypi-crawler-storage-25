from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yh_olap.client import Client
from .sql.sql import Sql
from .download.download import Download
from .approval.approval import Approval
from .hdfs.hdfs import Hdfs
from .cluster.cluster import Cluster


class Api:
    def __init__(self, client: 'Client') -> None:
        self.sql = Sql(client)
        self.download = Download(client)
        self.approval = Approval(client)
        self.hdfs = Hdfs(client)
        self.cluster = Cluster(client)
