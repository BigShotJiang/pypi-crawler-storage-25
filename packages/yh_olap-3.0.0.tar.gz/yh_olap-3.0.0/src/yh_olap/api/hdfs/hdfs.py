import os
import httpx
import aiofiles
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yh_olap.client import Client


class Hdfs:
    """HDFS 管理 - 提供文件上传、删除、目录查询等功能。"""

    def __init__(self, client: 'Client') -> None:
        """初始化 Hdfs。

        Args:
            client: OLAP 客户端实例。
        """
        self.__client = client

    def moveToTrash(self, path: list) -> dict:
        """删除文件（移动到回收站）。

        Args:
            path: 文件路径列表，如 ['/user/data/file1.txt', '/user/data/file2.txt']。

        Returns:
            删除结果。
        """
        url = self.__client.base_url + '/hdfs/moveToTrash'
        headers = self.__client.headers
        data = {'path': path}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def moveToTrash_async(self, path: list) -> dict:
        """删除文件（移动到回收站） - 异步。

        Args:
            path: 文件路径列表，如 ['/user/data/file1.txt', '/user/data/file2.txt']。

        Returns:
            删除结果。
        """
        url = self.__client.base_url + '/hdfs/moveToTrash'
        headers = self.__client.headers
        data = {'path': path}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def get_hdfs_dir(self, path: str, pageNum: int = 1) -> dict:
        """获取 HDFS 目录下的文件列表。

        Args:
            path: 目录路径，如 '/user/data/'。
            pageNum: 页码，默认 1。

        Returns:
            目录文件列表。
        """
        url = self.__client.base_url + '/hdfs/getHdfsDir'
        headers = self.__client.headers
        data = {'pageNum': pageNum, 'path': path}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def get_hdfs_dir_async(self, path: str, pageNum: int = 1) -> dict:
        """获取 HDFS 目录下的文件列表 - 异步。

        Args:
            path: 目录路径，如 '/user/data/'。
            pageNum: 页码，默认 1。

        Returns:
            目录文件列表。
        """
        url = self.__client.base_url + '/hdfs/getHdfsDir'
        headers = self.__client.headers
        data = {'pageNum': pageNum, 'path': path}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def upload_single_file(self, hdfsPath: str, file: str) -> dict:
        """上传单个文件到 HDFS。

        Args:
            hdfsPath: HDFS 目标目录路径，如 '/user/data/'。
            file: 本地文件路径，如 '/local/data/file.txt'。

        Returns:
            上传结果。
        """
        url = self.__client.base_url + '/file/uploadSingleFile'
        file_name = os.path.basename(file)
        headers = {'User-Agent': self.__client.UserAgent, 'token': self.__client.token, 'orgCode': self.__client.orgCode}
        with httpx.Client(
                timeout=self.__client.http_timeout if self.__client.http_timeout > 60 else 60) as client:
            with open(file, 'rb') as f:
                file_content = f.read()
                files = {
                    "hdfsPath": (None, hdfsPath),
                    "file": (file_name, file_content, "text/csv")
                }
                response = client.post(url=url, files=files, headers=headers)
                result = response.json()
        return result

    async def upload_single_file_async(self, hdfsPath: str, file: str) -> dict:
        """上传单个文件到 HDFS - 异步。

        Args:
            hdfsPath: HDFS 目标目录路径，如 '/user/data/'。
            file: 本地文件路径，如 '/local/data/file.txt'。

        Returns:
            上传结果。
        """
        url = self.__client.base_url + '/file/uploadSingleFile'
        file_name = os.path.basename(file)
        headers = {'User-Agent': self.__client.UserAgent, 'token': self.__client.token, 'orgCode': self.__client.orgCode}
        async with httpx.AsyncClient(
                timeout=self.__client.http_timeout if self.__client.http_timeout > 60 else 60) as client:
            async with aiofiles.open(file, 'rb') as f:
                file_content = await f.read()
                files = {
                    "hdfsPath": (None, hdfsPath),
                    "file": (file_name, file_content, "text/csv")
                }
                response = await client.post(url=url, files=files, headers=headers)
                result = response.json()
        return result