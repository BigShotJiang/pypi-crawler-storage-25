import httpx
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yh_olap.client import Client
from yh_olap.engine import Engine, Impala


class Cluster:
    """集群管理 - 提供任务管理等功能。"""

    def __init__(self, client: 'Client') -> None:
        """初始化 Cluster。

        Args:
            client: OLAP 客户端实例。
        """
        self.__client = client
        self.manager = self.Manager(self.__client)

    class Manager:
        """集群任务管理器。"""

        def __init__(self, client: 'Client') -> None:
            """初始化 Manager。

            Args:
                client: OLAP 客户端实例。
            """
            self.__client = client

        def killJob(self, requestId: str, engine: type[Engine] = Impala) -> dict:
            """终止任务。

            Args:
                requestId: 任务请求 ID。
                engine: 查询引擎，默认为 Impala。

            Returns:
                终止结果。
            """
            url = self.__client.base_url + '/cluster/manager/killJob'
            headers = self.__client.headers
            data = {'requestId': requestId, 'engine': engine.engine, 'dsId': engine.dsId}
            with httpx.Client(timeout=self.__client.http_timeout) as client:
                response = client.post(url=url, json=data, headers=headers)
                result = response.json()
            return result

        async def killJob_async(self, requestId: str, engine: type[Engine] = Impala) -> dict:
            """终止任务 - 异步。

            Args:
                requestId: 任务请求 ID。
                engine: 查询引擎，默认为 Impala。

            Returns:
                终止结果。
            """
            url = self.__client.base_url + '/cluster/manager/killJob'
            headers = self.__client.headers
            data = {'requestId': requestId, 'engine': engine.engine, 'dsId': engine.dsId}
            async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
                response = await client.post(url=url, json=data, headers=headers)
                result = response.json()
            return result