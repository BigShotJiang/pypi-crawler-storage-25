from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yh_olap.client import Client
import httpx
from yh_olap.engine import Engine, Impala


class Manager:
    """SQL 管理器 - 提供 SQL 执行、日志查询、结果查询等功能。"""

    def __init__(self, client: 'Client') -> None:
        """初始化 Manager。

        Args:
            client: OLAP 客户端实例。
        """
        self.__client = client

    def runSql(self, sql: str, engine: type[Engine] = Impala, params: list[dict] = [], execute_configs: dict = {}) -> dict:
        """运行 SQL。

        Args:
            sql: 要执行的 SQL 语句。
            engine: 查询引擎，默认为 Impala。
            params: sql 参数,格式[{'key':<参数名>,'type':<参数类型>,'value':<参数值>}, ...],type:1 -文本 2 -数值。
            execute_configs: execute_configs: 执行配置参数，如 session 变量等,{变量名:值}。

        Returns:
            执行结果，包含 requestId 等信息。
        """
        url = self.__client.base_url + '/sql/manager/runSql'
        data = {'engine': engine.engine,
                'dsId': engine.dsId,
                'sql': sql,
                'params': params,
                'executeConfigs': execute_configs
                }
        headers = self.__client.headers
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def runSql_async(self, sql: str, engine: type[Engine] = Impala, params: list[dict] = [], execute_configs: dict = {}) -> dict:
        """运行 SQL - 异步。

        Args:
            sql: 要执行的 SQL 语句。
            engine: 查询引擎，默认为 Impala。
            params: sql 参数,格式[{'key':<参数名>,'type':<参数类型>,'value':<参数值>}, ...],type:1 -文本 2 -数值。
            execute_configs: execute_configs: 执行配置参数，如 session 变量等,{变量名:值}。

        Returns:
            执行结果，包含 requestId 等信息。
        """
        url = self.__client.base_url + '/sql/manager/runSql'
        data = {'engine': engine.engine,
                'dsId': engine.dsId,
                'sql': sql,
                'params': params,
                'executeConfigs': execute_configs
                }
        headers = self.__client.headers
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def getLogResult(self, requestId: str) -> dict:
        """查看运行日志。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            日志结果，包含运行状态、错误信息等。
        """
        url = self.__client.base_url + '/sql/manager/getLogResult'
        headers = self.__client.headers
        data = {'requestId': requestId}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def getLogResult_async(self, requestId: str) -> dict:
        """查看运行日志 - 异步。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            日志结果，包含运行状态、错误信息等。
        """
        url = self.__client.base_url + '/sql/manager/getLogResult'
        headers = self.__client.headers
        data = {'requestId': requestId}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def getSqlResult(self, requestId: str, page_size: int = 200, page_no: int = 1) -> dict:
        """查看运行结果。

        Args:
            requestId: SQL 执行请求 ID。
            page_size: 每页条数，默认 200。
            page_no: 页码，默认 1。

        Returns:
            SQL 执行结果，包含数据列表、列名、总数等。
        """
        url = self.__client.base_url + '/sql/manager/getSqlResult'
        headers = self.__client.headers
        data = {'requestId': requestId, 'pageSize': page_size, 'pageNo': page_no}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def getSqlResult_async(self, requestId: str, page_size: int = 200, page_no: int = 1) -> dict:
        """查看运行结果 - 异步。

        Args:
            requestId: SQL 执行请求 ID。
            page_size: 每页条数，默认 200。
            page_no: 页码，默认 1。

        Returns:
            SQL 执行结果，包含数据列表、列名、总数等。
        """
        url = self.__client.base_url + '/sql/manager/getSqlResult'
        headers = self.__client.headers
        data = {'requestId': requestId, 'pageSize': page_size, 'pageNo': page_no}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def checkState(self, requestId: str) -> dict:
        """查看运行状态。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            运行状态，包含 finish 状态、错误信息等。
        """
        url = self.__client.base_url + '/sql/manager/checkState'
        headers = self.__client.headers
        data = {'requestId': requestId}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def checkState_async(self, requestId: str) -> dict:
        """查看运行状态 - 异步。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            运行状态，包含 finish 状态、错误信息等。
        """
        url = self.__client.base_url + '/sql/manager/checkState'
        headers = self.__client.headers
        data = {'requestId': requestId}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    def queryHisSqlResult(self, pageNum: int = 1, pageSize: int = 10, sqlKeywords: str = '') -> dict:
        """查询历史 SQL 执行记录。

        Args:
            pageNum: 页码，默认 1。
            pageSize: 每页条数，默认 10。
            sqlKeywords: SQL 关键词，用于模糊搜索，默认为空。

        Returns:
            历史记录列表。
        """
        url = self.__client.base_url + '/sql/manager/queryHisSqlResult'
        headers = self.__client.headers
        data = {'pageNum': pageNum, 'pageSize': pageSize, 'sqlKeywords': sqlKeywords}
        with httpx.Client(timeout=self.__client.http_timeout) as client:
            response = client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result

    async def queryHisSqlResult_async(self, pageNum: int = 1, pageSize: int = 10, sqlKeywords: str = '') -> dict:
        """查询历史 SQL 执行记录 - 异步。

        Args:
            pageNum: 页码，默认 1。
            pageSize: 每页条数，默认 10。
            sqlKeywords: SQL 关键词，用于模糊搜索，默认为空。

        Returns:
            历史记录列表。
        """
        url = self.__client.base_url + '/sql/manager/queryHisSqlResult'
        headers = self.__client.headers
        data = {'pageNum': pageNum, 'pageSize': pageSize, 'sqlKeywords': sqlKeywords}
        async with httpx.AsyncClient(timeout=self.__client.http_timeout) as client:
            response = await client.post(url=url, json=data, headers=headers)
            result = response.json()
        return result