from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yh_olap.client import Client
from .manager import Manager


class Sql:
    def __init__(self, client: 'Client') -> None:
        self.__client = client
        self.manager = Manager(self.__client)
