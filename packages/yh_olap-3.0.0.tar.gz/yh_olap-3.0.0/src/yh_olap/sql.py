"""SQL 处理工具模块。"""

import re


def strip_sql_comments_and_whitespace(sql: str) -> str:
    """清除 SQL 代码中的注释和多余空白字符。

    移除以下内容：
    - 单行注释 (-- 注释)
    - 多行注释 (/* 注释 */)
    - 字符串外的多余空白（保留字符串内的空格）

    Args:
        sql: 原始 SQL 字符串。

    Returns:
        清理后的 SQL 字符串。

    Examples:
        >>> strip_sql_comments_and_whitespace("SELECT * FROM t -- 这是注释")
        'SELECT * FROM t'
        >>> strip_sql_comments_and_whitespace("SELECT /* 注释 */ name FROM t")
        'SELECT name FROM t'
    """
    result = []
    i = 0
    n = len(sql)

    while i < n:
        # 检查是否进入字符串（单引号或双引号）
        if sql[i] in ('"', "'"):
            quote = sql[i]
            result.append(quote)
            i += 1
            # 处理字符串内容，保留内部所有字符
            while i < n:
                if sql[i] == quote:
                    # 检查是否是转义引号（两个连续引号）
                    if i + 1 < n and sql[i + 1] == quote:
                        result.append(quote)
                        result.append(quote)
                        i += 2
                    else:
                        result.append(quote)
                        i += 1
                        break
                else:
                    result.append(sql[i])
                    i += 1
            continue

        # 检查单行注释 --
        if i + 1 < n and sql[i:i + 2] == '--':
            # 跳过直到行尾
            while i < n and sql[i] != '\n':
                i += 1
            # 保留换行符
            if i < n:
                result.append('\n')
                i += 1
            continue

        # 检查多行注释 /* */
        if i + 1 < n and sql[i:i + 2] == '/*':
            i += 2
            # 跳过直到 */
            while i + 1 < n and sql[i:i + 2] != '*/':
                # 保留注释内的换行符，维持行号
                if sql[i] == '\n':
                    result.append('\n')
                i += 1
            if i + 1 < n:
                i += 2  # 跳过 */
            continue

        # 普通字符
        result.append(sql[i])
        i += 1

    # 合并结果并清理空白
    cleaned = ''.join(result)
    # 清理多余的空白：多个空格/制表符变成单个空格，去除首尾空白
    cleaned = re.sub(r'[ \t]+', ' ', cleaned)
    cleaned = re.sub(r'\n\s*\n', '\n', cleaned)  # 多个空行变成一个换行
    cleaned = cleaned.strip()

    return cleaned


def get_sql_type(sql: str) -> str | None:
    """获取 SQL 语句的类型。

    Args:
        sql: SQL 字符串。

    Returns:
        SQL 类型的大写字符串，如 'SELECT'、'INSERT' 等。
        如果无法识别则返回 None。

    Examples:
        >>> get_sql_type("SELECT * FROM t")
        'SELECT'
        >>> get_sql_type("-- 注释\\nINSERT INTO t VALUES (1)")
        'INSERT'
        >>> get_sql_type("WITH cte AS (SELECT 1) SELECT * FROM cte")
        'SELECT'
    """
    # 先清理注释和空白
    cleaned = strip_sql_comments_and_whitespace(sql)
    if not cleaned:
        return None

    # 如果以 WITH 开头，跳过 CTE 部分，找到真正的主查询类型
    if cleaned.upper().startswith('WITH '):
        # 跳过 WITH ... AS (...) 部分
        cleaned = _skip_with_clause(cleaned)

    if not cleaned:
        return None

    # 提取第一个关键字
    match = re.match(r'^([A-Za-z]+)', cleaned)
    if not match:
        return None

    sql_type = match.group(1).upper()

    # 支持的 SQL 类型
    supported_types = {
        'SELECT', 'INSERT', 'UPDATE', 'DELETE',
        'CREATE', 'ALTER', 'DROP', 'TRUNCATE',
        'MERGE', 'REPLACE',
        'EXEC', 'EXECUTE', 'CALL',
        'GRANT', 'REVOKE',
        'BEGIN', 'COMMIT', 'ROLLBACK', 'START',
        'SET', 'SHOW', 'DESC', 'DESCRIBE', 'EXPLAIN',
        'USE', 'ANALYZE', 'OPTIMIZE', 'REPAIR',
    }

    if sql_type in supported_types:
        return sql_type

    return None


def _skip_with_clause(sql: str) -> str:
    """跳过 WITH 子句，返回 CTE 之后的部分。

    Args:
        sql: 以 'WITH ' 开头的 SQL 字符串。

    Returns:
        CTE 定义之后的 SQL 字符串。
    """
    i = 4  # 跳过 'WITH'
    n = len(sql)

    while i < n:
        # 跳过空白
        while i < n and sql[i] in ' \t\n':
            i += 1

        if i >= n:
            break

        # 跳过 CTE 名称（直到 AS 或 左括号）
        while i < n:
            if sql[i] == '(':
                break
            if sql[i:i + 3].upper() == 'AS ':
                i += 2  # 跳过 'AS'
                break
            i += 1

        # 跳过空白
        while i < n and sql[i] in ' \t\n':
            i += 1

        # 跳过 AS 后面的内容
        if sql[i:i + 2].upper() == 'AS':
            i += 2
            while i < n and sql[i] in ' \t\n':
                i += 1

        # 找到并跳过匹配的括号
        if i < n and sql[i] == '(':
            paren_count = 1
            i += 1
            while i < n and paren_count > 0:
                if sql[i] == '(':
                    paren_count += 1
                elif sql[i] == ')':
                    paren_count -= 1
                i += 1

        # 跳过空白
        while i < n and sql[i] in ' \t\n':
            i += 1

        # 检查是否有更多 CTE（逗号分隔）
        if i < n and sql[i] == ',':
            i += 1
            continue

        # 没有逗号，说明到了主查询
        break

    return sql[i:]


def fill_sql_params(sql: str, **kwargs: str | int | float | None) -> str:
    """将 SQL 中的 ${param} 占位符替换为实际参数值。

    Args:
        sql: 包含 ${param} 占位符的 SQL 字符串。
        **kwargs: 参数，键为参数名，值为替换内容。

    Returns:
        替换后的 SQL 字符串。

    Raises:
        KeyError: 如果 SQL 中存在未提供的参数。

    Examples:
        >>> fill_sql_params("SELECT * FROM ${table} WHERE id = ${id}", table="users", id=1)
        'SELECT * FROM users WHERE id = 1'
        >>> fill_sql_params("SELECT '${name}' FROM t", name="John")
        'SELECT 'John' FROM t'
    """
    result = []
    i = 0
    n = len(sql)

    while i < n:
        # 检查是否进入字符串（单引号或双引号）
        if sql[i] in ('"', "'"):
            quote = sql[i]
            result.append(quote)
            i += 1
            while i < n:
                if sql[i] == quote:
                    if i + 1 < n and sql[i + 1] == quote:
                        result.append(quote)
                        result.append(quote)
                        i += 2
                    else:
                        result.append(quote)
                        i += 1
                        break
                # 字符串内也检查 ${...} 占位符
                elif sql[i] == '$' and i + 1 < n and sql[i + 1] == '{':
                    start = i + 2
                    end = start
                    while end < n and sql[end] != '}':
                        end += 1
                    if end < n:
                        param_name = sql[start:end]
                        if param_name not in kwargs:
                            raise KeyError(f"参数 '{param_name}' 未提供")
                        result.append(str(kwargs[param_name]))
                        i = end + 1
                        continue
                else:
                    result.append(sql[i])
                    i += 1
            continue

        # 检查 ${...} 占位符
        if sql[i] == '$' and i + 1 < n and sql[i + 1] == '{':
            # 找到占位符的结束位置
            start = i + 2
            end = start
            while end < n and sql[end] != '}':
                end += 1

            if end < n:
                param_name = sql[start:end]
                if param_name not in kwargs:
                    raise KeyError(f"参数 '{param_name}' 未提供")
                result.append(str(kwargs[param_name]))
                i = end + 1  # 跳过 }
                continue

        result.append(sql[i])
        i += 1

    return ''.join(result)