class Engine:
    engine = '0'
    dsId = 0

class Hive(Engine):
    engine = '1'
    dsId = 1


class Impala(Engine):
    engine = '2'
    dsId = 2


class Clickhouse(Engine):
    engine = '3'
    dsId = 14004