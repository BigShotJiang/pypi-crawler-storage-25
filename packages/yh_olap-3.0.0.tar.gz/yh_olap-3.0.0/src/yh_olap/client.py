import os
import time
import tempfile
import asyncio
import logging
import warnings
from collections.abc import Iterator, AsyncIterator

import pandas as pd
from yhlogin import Yhlogin
from yhlogin.service import Olap

# 禁用 httpx INFO 日志
logging.getLogger("httpx").setLevel(logging.WARNING)
# 禁用 openpyxl 警告
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

from .api import Api
from .engine import Engine, Hive, Impala
from .sql import strip_sql_comments_and_whitespace, get_sql_type, fill_sql_params


class Client:
    def __init__(self, token: str | None = None) -> None:
        """OLAP 客户端。

        Args:
            token: 登录后获取的 token。
        """
        self.token = token
        self.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"
        self.orgCode = "bgzt000004"
        self.ContentType = "application/json"
        self.headers = {
            "User-Agent": self.UserAgent,
            "token": self.token,
            "orgCode": self.orgCode,
            "Content-Type": self.ContentType,
        }
        self.base_url = "http://prokong.bigdata.yonghui.cn/yh-olap-web"

        # http 连接超时
        self.http_timeout = 30

        self.api = Api(client=self)

    def set_token(self, token) -> None:
        """设置 token。

        Args:
            token: 登录后获取的 token。
        """
        self.token = token
        self.headers["token"] = token

    def login(self, username, password, otp_key, skip_ad=True) -> None:
        """登录 OLAP。

        Args:
            username: 用户名。
            password: 密码。
            otp_key: OTP 密钥。
            skip_ad: 是否跳过域验证。
        """
        yl = Yhlogin()
        login_config = yl.login(
            username=username,
            password=password,
            otp_key=otp_key,
            service=Olap,
            skip_ad=skip_ad,
        )
        jsessionid = login_config.get("jsessionid")
        self.set_token(f"JSESSIONID={jsessionid}")

    async def login_async(self, username, password, otp_key, skip_ad=True) -> None:
        """异步登录 OLAP。

        Args:
            username: 用户名。
            password: 密码。
            otp_key: OTP 密钥。
            skip_ad: 是否跳过域验证。
        """
        yl = Yhlogin()
        login_config = await yl.login_async(
            username=username,
            password=password,
            otp_key=otp_key,
            service=Olap,
            skip_ad=skip_ad,
        )
        jsessionid = login_config.get("jsessionid")
        self.set_token(f"JSESSIONID={jsessionid}")

    def __get_api_result_data(self, api_result: dict) -> dict:
        """获取 API 响应结果。

        Args:
            api_result: API 响应字典。

        Returns:
            结果数据字典。
        """
        if api_result.get("success"):
            return api_result.get("data")  # type: ignore
        else:
            raise ValueError(api_result.get("message"))

    def get_log_result(
        self, requestId: str, interval: float = 0.5, timeout: float = 1800
    ) -> Iterator[dict]:
        """获取运行日志结果（迭代器）。

        Args:
            requestId: SQL 执行请求 ID。
            interval: 轮询间隔秒数，默认 0.5。
            timeout: 超时秒数，默认 1800（30分钟）。

        Returns:
            日志结果迭代器，每次 yield 包含运行状态、错误信息等。
        """
        finish = None
        start_time = time.time()
        while True:
            if time.time() - start_time > timeout:
                raise TimeoutError(f"获取日志结果超时（{timeout}秒）")
            if finish != "ok":
                log_result_res = self.api.sql.manager.getLogResult(requestId=requestId)
                log_result_data = self.__get_api_result_data(log_result_res)
                yield log_result_data
                finish = log_result_data.get("finish")
                time.sleep(interval)
            else:
                break

    async def get_log_result_async(
        self, requestId: str, interval: float = 0.5, timeout: float = 1800
    ) -> AsyncIterator[dict]:
        """获取运行日志结果（异步迭代器）。

        Args:
            requestId: SQL 执行请求 ID。
            interval: 轮询间隔秒数，默认 0.5。
            timeout: 超时秒数，默认 1800（30分钟）。

        Returns:
            日志结果异步迭代器，每次 yield 包含运行状态、错误信息等。
        """
        finish = None
        start_time = time.time()
        while True:
            if time.time() - start_time > timeout:
                raise TimeoutError(f"获取日志结果超时（{timeout}秒）")
            if finish != "ok":
                log_result_res = await self.api.sql.manager.getLogResult_async(requestId=requestId)
                log_result_data = self.__get_api_result_data(log_result_res)
                yield log_result_data
                finish = log_result_data.get("finish")
                await asyncio.sleep(interval)
            else:
                break

    def get_sql_result(
        self, requestId: str, interval: float = 0.5, timeout: float = 1800
    ) -> Iterator[dict]:
        """获取 SQL 执行结果（迭代器）。

        Args:
            requestId: SQL 执行请求 ID。
            interval: 轮询间隔秒数，默认 0.5。
            timeout: 超时秒数，默认 1800（30分钟）。

        Returns:
            SQL 执行结果迭代器，每次 yield 包含运行状态、数据等。
        """
        is_ready = None
        start_time = time.time()
        while True:
            if time.time() - start_time > timeout:
                raise TimeoutError(f"获取SQL结果超时（{timeout}秒）")
            if is_ready != "ok":
                sql_result_res = self.api.sql.manager.getSqlResult(requestId=requestId)
                sql_result_data = self.__get_api_result_data(sql_result_res)
                yield sql_result_data
                is_ready = sql_result_data.get("isReady")
                time.sleep(interval)
            else:
                break

    async def get_sql_result_async(
        self, requestId: str, interval: float = 0.5, timeout: float = 1800
    ) -> AsyncIterator[dict]:
        """获取 SQL 执行结果（异步迭代器）。

        Args:
            requestId: SQL 执行请求 ID。
            interval: 轮询间隔秒数，默认 0.5。
            timeout: 超时秒数，默认 1800（30分钟）。

        Returns:
            SQL 执行结果异步迭代器，每次 yield 包含运行状态、数据等。
        """
        is_ready = None
        start_time = time.time()
        while True:
            if time.time() - start_time > timeout:
                raise TimeoutError(f"获取SQL结果超时（{timeout}秒）")
            if is_ready != "ok":
                sql_result_res = await self.api.sql.manager.getSqlResult_async(requestId=requestId)
                sql_result_data = self.__get_api_result_data(sql_result_res)
                yield sql_result_data
                is_ready = sql_result_data.get("isReady")
                await asyncio.sleep(interval)
            else:
                break

    def wait_run_finish(self, requestId: str) -> tuple[dict | None, dict | None]:
        """等待 SQL 执行完成。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            (log_result, sql_result) 日志结果和 SQL 结果。
        """
        log_result = None
        sql_result = None
        for lr in self.get_log_result(requestId=requestId):
            log_result = lr
            if log_result.get("error"):
                raise ValueError(log_result.get("data"))
        for sr in self.get_sql_result(requestId=requestId):
            sql_result = sr
        return log_result, sql_result

    async def wait_run_finish_async(self, requestId: str) -> tuple[dict | None, dict | None]:
        """等待 SQL 执行完成（异步）。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            (log_result, sql_result)
        """
        log_result = None
        sql_result = None
        async for lr in self.get_log_result_async(requestId=requestId):
            log_result = lr
            if log_result.get("error"):
                raise ValueError(log_result.get("data"))
        async for sr in self.get_sql_result_async(requestId=requestId):
            sql_result = sr
        return log_result, sql_result

    def execute(
        self,
        sql: str,
        engine: type[Engine] = Impala,
        params: list = [],
        execute_configs: dict = {},
        wait_run_finish: bool = True,
    ) -> str:
        """执行 sql
        
        Args:
            sql: 要执行的 SQL 语句。
            engine: 查询引擎，默认为 Impala。
            params: sql 参数,格式[{'key':<参数名>,'type':<参数类型>,'value':<参数值>}, ...],type:1 -文本 2 -数值。
            execute_configs: execute_configs: 执行配置参数，如 session 变量等,{变量名:值}。
            
        Returns:
            requestId
        """
        run_sql_req = self.api.sql.manager.runSql(
            sql=sql, engine=engine, params=params, execute_configs=execute_configs
        )
        run_sql_data = self.__get_api_result_data(run_sql_req)
        if run_sql_data:
            executeId = run_sql_data.get("executeId")
        if wait_run_finish:
            self.wait_run_finish(executeId)  # type: ignore
        return executeId  # type: ignore

    async def execute_async(
        self,
        sql: str,
        engine: type[Engine] = Impala,
        params: list = [],
        execute_configs: dict = {},
        wait_run_finish: bool = True,
    ) -> str:
        """执行 sql（异步）
                
        Args:
            sql: 要执行的 SQL 语句。
            engine: 查询引擎，默认为 Impala。
            params: sql 参数,格式[{'key':<参数名>,'type':<参数类型>,'value':<参数值>}, ...],type:1 -文本 2 -数值。
            execute_configs: execute_configs: 执行配置参数，如 session 变量等,{变量名:值}。
            
        Returns:
            requestId
        """
        run_sql_req = await self.api.sql.manager.runSql_async(
            sql=sql, engine=engine, params=params, execute_configs=execute_configs
        )
        run_sql_data = self.__get_api_result_data(run_sql_req)
        if run_sql_data:
            executeId = run_sql_data.get("executeId")
        if wait_run_finish:
            await self.wait_run_finish_async(executeId)  # type: ignore
        return executeId  # type: ignore

    def result_preview(self, requestId: str) -> dict:
        """SQL 结果预览，只展示 200 条数据。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            SQL 执行结果，包含数据列表、列名等。
        """

        for sr in self.get_sql_result(requestId=requestId):
            sql_result = sr
        return sql_result  # type: ignore

    async def result_preview_async(self, requestId: str) -> dict:
        """SQL 结果预览，只展示 200 条数据（异步）。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            SQL 执行结果，包含数据列表、列名等。
        """
        async for sr in self.get_sql_result_async(requestId=requestId):
            sql_result = sr
        return sql_result  # type: ignore

    def download_result_simple(self, requestId: str, save_path: str | None = None):
        """快速下载 SQL 结果（最多 1000 条）。

        Args:
            requestId: SQL 执行请求 ID。
            save_path: 保存文件路径

        Returns:
            保存的文件路径。
        """
        file_path = self.api.download.olapResultSimple(
            requestId=requestId, save_path=save_path
        )
        return file_path

    async def download_result_simple_async(self, requestId: str, save_path: str | None = None):
        """快速下载 SQL 结果（最多 1000 条）- 异步。

        Args:
            requestId: SQL 执行请求 ID。
            save_path: 保存文件路径

        Returns:
            保存的文件路径。
        """
        file_path = await self.api.download.olapResultSimple_async(
            requestId=requestId, save_path=save_path
        )
        return file_path

    def sql_result_simple(self, requestId: str) -> dict:
        """获取简单 SQL 结果，最多支持 1000 条数据。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            {'columnNameList': [列名列表], 'list': [数据行列表]}。
        """

        file_path = os.path.join(tempfile.gettempdir(), f"yh_olap_{requestId}.xlsx")
        file_path = self.download_result_simple(
            requestId=requestId, save_path=file_path
        )
        df = pd.read_excel(file_path, index_col=False, dtype=str)
        df = df.replace(['null', 'NULL', 'Null'], None)
        non_id_cols = [col for col in df.columns if 'id' not in col.lower()]
        for col in non_id_cols:
            try:
                df[col] = pd.to_numeric(df[col])
            except:
                pass
        os.remove(file_path)
        data = {
            "columnNameList": df.columns.tolist(),
            "list": df.to_dict(orient="records"),
        }
        return data

    async def sql_result_simple_async(self, requestId: str) -> dict:
        """获取简单 SQL 结果，最多支持 1000 条数据（异步）。

        Args:
            requestId: SQL 执行请求 ID。

        Returns:
            {'columnNameList': [列名列表], 'list': [数据行列表]}。
        """
        file_path = os.path.join(tempfile.gettempdir(), f"yh_olap_{requestId}.xlsx")
        file_path = await self.download_result_simple_async(
            requestId=requestId, save_path=file_path
        )
        df = pd.read_excel(file_path, index_col=False, dtype=str)
        df = df.replace(['null', 'NULL', 'Null'], None)
        non_id_cols = [col for col in df.columns if 'id' not in col.lower()]
        for col in non_id_cols:
            try:
                df[col] = pd.to_numeric(df[col])
            except:
                pass
        os.remove(file_path)
        data = {
            "columnNameList": df.columns.tolist(),
            "list": df.to_dict(orient="records"),
        }
        return data

    def create_skip_download_order(
        self, requestId: str, engine: type[Engine] = Hive
    ) -> int:
        """创建下载全量数据订单（最多 500000 条）。

        Args:
            requestId: SQL 执行请求 ID。
            engine: 查询引擎，默认为 Hive。

        Returns:
            审批订单 ID。
        """
        create_order = self.api.approval.createSkipDownloadOrder(
            requestId=requestId, engine=engine
        )
        create_order_data = self.__get_api_result_data(create_order)
        id = create_order_data.get("id")
        return id  # type: ignore

    async def create_skip_download_order_async(
        self, requestId: str, engine: type[Engine] = Hive
    ) -> int:
        """创建下载全量数据订单（最多 500000 条）- 异步。

        Args:
            requestId: SQL 执行请求 ID。
            engine: 查询引擎，默认为 Hive。

        Returns:
            审批订单 ID。
        """
        create_order = await self.api.approval.createSkipDownloadOrder_async(
            requestId=requestId, engine=engine
        )
        create_order_data = self.__get_api_result_data(create_order)
        id = create_order_data.get("id")
        return id  # type: ignore

    def wait_task_finish(self, approvalId: int, interval=5, retry_num=0) -> dict:
        """等待下载任务完成。

        Args:
            approvalId: 审批订单 ID。
            interval: 轮询间隔秒数，默认 5。
            retry_num: 失败重试次数，默认 0。

        Returns:
            任务明细，包含任务状态。
        """

        while True:
            detail_result = self.api.approval.detail(approvalId=approvalId)
            detail_data = self.__get_api_result_data(detail_result)
            if detail_data:
                if detail_data.get("taskState") == 1:  # 数据生成中 一秒后刷新
                    time.sleep(interval)
                elif detail_data.get("taskState") == 2:  # 数据已生成 结束循环
                    time.sleep(0.5)  # 避免服务器文件生成延迟
                    return detail_data
                elif detail_data.get("taskState") == 3:
                    retry_num -= 1
                    if retry_num < 0:
                        raise ValueError(detail_data.get("taskStateName"))
                    else:
                        self.api.download.refresh(downloadId=approvalId)
                        time.sleep(interval)
                else:
                    time.sleep(interval)
            else:
                raise ValueError(detail_result.get("message"))

    async def wait_task_finish_async(self, approvalId: int, interval=5, retry_num=0) -> dict:
        """等待下载任务完成（异步）。

        Args:
            approvalId: 审批订单 ID。
            interval: 轮询间隔秒数，默认 5。
            retry_num: 失败重试次数，默认 0。

        Returns:
            任务明细，包含任务状态。
        """
        while True:
            detail_result = await self.api.approval.detail_async(approvalId=approvalId)
            detail_data = self.__get_api_result_data(detail_result)
            if detail_data:
                if detail_data.get("taskState") == 1:  # 数据生成中
                    await asyncio.sleep(interval)
                elif detail_data.get("taskState") == 2:  # 数据已生成
                    await asyncio.sleep(0.5)
                    return detail_data
                elif detail_data.get("taskState") == 3:
                    retry_num -= 1
                    if retry_num < 0:
                        raise ValueError(detail_data.get("taskStateName"))
                    else:
                        await self.api.download.refresh_async(downloadId=approvalId)
                        await asyncio.sleep(interval)
                else:
                    await asyncio.sleep(interval)
            else:
                raise ValueError(detail_result.get("message"))

    def download_excel(
        self,
        requestId: str,
        save_path: str | None = None,
        engine: type[Engine] = Impala,
    ) -> str:
        """下载 SQL 结果为 Excel 文件。

        自动根据数据量选择下载方式：
        - 数据量 <= 1000 条：直接下载
        - 数据量 > 1000 条：创建审批订单后下载

        Args:
            requestId: SQL 执行请求 ID。
            save_path: 保存文件路径。
            engine: 查询引擎，默认为 Impala。

        Returns:
            保存的文件路径。
        """
        sql_result_result = self.api.sql.manager.getSqlResult(requestId=requestId)
        sql_result_data = self.__get_api_result_data(sql_result_result)
        total = 100000
        if sql_result_data:
            if sql_result_data.get("total"):
                total = sql_result_data.get("total")
        if total <= 1000:  # type: ignore
            out_file_path = self.download_result_simple(
                requestId=requestId, save_path=save_path
            )
        else:
            approvalId = self.create_skip_download_order(
                requestId=requestId, engine=engine
            )
            detail_data = self.wait_task_finish(approvalId=approvalId)
            dl_engine = detail_data.get("engine")
            dl_requestId = detail_data.get("requestId")
            downLoadRequestId = detail_data.get("downLoadRequestId")
            if dl_engine == 1:
                out_file_path = self.api.download.olapResult(
                    requestId=dl_requestId, file_path=save_path  # type: ignore
                )
            elif dl_engine == 2:
                out_file_path = self.api.download.downloadToExcel(
                    requestId=downLoadRequestId,  # type: ignore
                    fileName=downLoadRequestId,  # type: ignore
                    file_path=save_path,
                )
        return out_file_path  # type: ignore

    async def download_excel_async(
        self,
        requestId: str,
        save_path: str | None = None,
        engine: type[Engine] = Impala,
    ) -> str:
        """下载 SQL 结果为 Excel 文件（异步）。

        自动根据数据量选择下载方式：
        - 数据量 <= 1000 条：直接下载
        - 数据量 > 1000 条：创建审批订单后下载

        Args:
            requestId: SQL 执行请求 ID。
            save_path: 保存文件路径。
            engine: 查询引擎，默认为 Impala。

        Returns:
            保存的文件路径。
        """
        sql_result_result = await self.api.sql.manager.getSqlResult_async(requestId=requestId)
        sql_result_data = self.__get_api_result_data(sql_result_result)
        total = 100000
        if sql_result_data:
            if sql_result_data.get("total"):
                total = sql_result_data.get("total")
        if total <= 1000:  # type: ignore
            out_file_path = await self.download_result_simple_async(
                requestId=requestId, save_path=save_path
            )
        else:
            approvalId = await self.create_skip_download_order_async(
                requestId=requestId, engine=engine
            )
            detail_data = await self.wait_task_finish_async(approvalId=approvalId)
            dl_engine = detail_data.get("engine")
            dl_requestId = detail_data.get("requestId")
            downLoadRequestId = detail_data.get("downLoadRequestId")
            if dl_engine == 1:
                out_file_path = await self.api.download.olapResult_async(
                    requestId=dl_requestId, file_path=save_path  # type: ignore
                )
            elif dl_engine == 2:
                out_file_path = await self.api.download.downloadToExcel_async(
                    requestId=downLoadRequestId,  # type: ignore
                    fileName=downLoadRequestId,  # type: ignore
                    file_path=save_path,
                )
        return out_file_path  # type: ignore

    def sql_result(self, requestId: str, engine: type[Engine] = Impala):
        """获取 SQL 结果，最多支持 500000 条数据。

        Args:
            requestId: SQL 执行请求 ID。
            engine: 查询引擎，默认为 Impala。

        Returns:
            {'columnNameList': [列名列表], 'list': [数据行列表]}。
        """

        file_path = os.path.join(tempfile.gettempdir(), f"yh_olap_{requestId}.xlsx")
        file_path = self.download_excel(
            requestId=requestId, save_path=file_path, engine=engine
        )
        df = pd.read_excel(file_path, index_col=False, dtype=str)
        df = df.replace(['null', 'NULL', 'Null'], None)
        non_id_cols = [col for col in df.columns if 'id' not in col.lower()]
        for col in non_id_cols:
            try:
                df[col] = pd.to_numeric(df[col])
            except:
                pass
        os.remove(file_path)
        data = {
            "columnNameList": df.columns.tolist(),
            "list": df.to_dict(orient="records"),
        }
        return data

    async def sql_result_async(self, requestId: str, engine: type[Engine] = Impala):
        """获取 SQL 结果，最多支持 500000 条数据（异步）。

        Args:
            requestId: SQL 执行请求 ID。
            engine: 查询引擎，默认为 Impala。

        Returns:
            {'columnNameList': [列名列表], 'list': [数据行列表]}。
        """
        file_path = os.path.join(tempfile.gettempdir(), f"yh_olap_{requestId}.xlsx")
        file_path = await self.download_excel_async(
            requestId=requestId, save_path=file_path, engine=engine
        )
        df = pd.read_excel(file_path, index_col=False, dtype=str)
        df = df.replace(['null', 'NULL', 'Null'], None)
        non_id_cols = [col for col in df.columns if 'id' not in col.lower()]
        for col in non_id_cols:
            try:
                df[col] = pd.to_numeric(df[col])
            except:
                pass
        os.remove(file_path)
        data = {
            "columnNameList": df.columns.tolist(),
            "list": df.to_dict(orient="records"),
        }
        return data

    @staticmethod
    def to_dataframe(data: dict) -> pd.DataFrame:
        """将 sql_result 返回的数据格式转换为 DataFrame。

        Args:
            data: {'columnNameList': [列名列表], 'list': [数据行列表]}。

        Returns:
            pandas DataFrame。
        """
        df = pd.DataFrame(data['list'])
        df = df[data['columnNameList']]
        return df