import pandas as pd
from pandas import DataFrame
import time
a = pd.read_excel('/Users/zhang3/yh_zhang3/tools/pypi/OLAP_V3.0(开发中)/a25bf743-6d96-4007-8094-13fcc2302034.xlsx',index_col=False)

print(a.to_dict(orient='records'))
print(a.columns.tolist())
timestamp_s = int(time.time())
print(timestamp_s)
