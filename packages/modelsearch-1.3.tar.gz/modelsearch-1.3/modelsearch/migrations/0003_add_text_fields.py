from django.db import connection, migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("modelsearch", "0002_customise_indexentry"),
    ]

    if connection.vendor == "postgresql":
        operations = [
            migrations.AddField(
                model_name="indexentry",
                name="title_text",
                field=models.TextField(default=""),
            ),
            migrations.AddField(
                model_name="indexentry",
                name="body_text",
                field=models.TextField(default=""),
            ),
            # GIN trigram indexes are created by the enable_trigram
            # management command, not here. The reverse SQL drops them on
            # migration rollback.
            migrations.RunSQL(
                sql=migrations.RunSQL.noop,
                reverse_sql="DROP INDEX IF EXISTS modelsearch_title_text_trgm;",
            ),
            migrations.RunSQL(
                sql=migrations.RunSQL.noop,
                reverse_sql="DROP INDEX IF EXISTS modelsearch_body_text_trgm;",
            ),
            migrations.RunSQL(
                sql=migrations.RunSQL.noop,
                reverse_sql="DROP INDEX IF EXISTS modelsearch_title_text_unaccent_trgm;",
            ),
            migrations.RunSQL(
                sql=migrations.RunSQL.noop,
                reverse_sql="DROP INDEX IF EXISTS modelsearch_body_text_unaccent_trgm;",
            ),
        ]
    else:
        operations = []
