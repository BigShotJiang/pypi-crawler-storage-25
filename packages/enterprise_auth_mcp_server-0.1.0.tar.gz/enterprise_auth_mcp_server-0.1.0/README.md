# enterprise-auth-mcp-server

[![PyPI version](https://badge.fury.io/py/enterprise-auth-mcp-server.svg)](https://badge.fury.io/py/enterprise-auth-mcp-server)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

MCP server for enterprise authentication and authorization — JWT validation, OIDC token inspection, OAuth 2.0 introspection, and role-based access control for AI agents.

## Features

- **JWT Decode** — Inspect token header, payload, and metadata without signature verification
- **JWT Validate** — Validate signature, expiry, audience, and issuer
- **Permission Check** — Verify if a token has required OAuth scopes and roles
- **User Roles** — Extract user identity, roles, and groups (supports Keycloak, Azure AD, Auth0, Okta)
- **OAuth Introspection** — RFC 7662 token introspection (remote endpoint or local fallback)
- **OIDC Claims Verify** — OpenID Connect Core 1.0 claims validation
- **Token Scope List** — List all scopes, roles, and permissions with provider auto-detection
- **OIDC Discovery** — Fetch provider endpoints from /.well-known/openid-configuration

## Installation

```bash
pip install enterprise-auth-mcp-server
```

## Claude Desktop Configuration

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "enterprise-auth": {
      "command": "enterprise-auth-mcp-server"
    }
  }
}
```

## Tools

| Tool | Description |
|------|-------------|
| `decode_jwt` | Decode JWT without signature verification |
| `validate_jwt` | Validate JWT signature, expiry, audience, issuer |
| `check_permissions` | Check if token has required scopes/roles |
| `get_user_roles` | Extract user identity and roles from token |
| `oauth_introspect` | OAuth 2.0 RFC 7662 token introspection |
| `verify_oidc_claims` | Validate OIDC Core 1.0 required claims |
| `list_token_scopes` | List all scopes and permissions with provider detection |
| `get_oidc_discovery` | Fetch OIDC provider discovery document |

## Usage Examples

### Decode a JWT token
```
decode_jwt(token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...")
```

### Validate a JWT with secret
```
validate_jwt(token="...", secret="my-secret", algorithms="HS256", audience="my-app")
```

### Check if user has admin role
```
check_permissions(token="...", required_roles="admin,manager")
```

### Verify OIDC claims
```
verify_oidc_claims(token="...", expected_issuer="https://accounts.google.com", expected_audience="my-client-id")
```

### Get OIDC provider endpoints
```
get_oidc_discovery(issuer_url="https://accounts.google.com")
```

## Supported Identity Providers

- **Azure AD / Microsoft Entra ID** — Azure roles, app roles, directory roles (wids)
- **Okta** — Groups, custom claims
- **Auth0** — Permissions, roles via Management API conventions
- **Keycloak** — realm_access, resource_access
- **Google Identity** — Standard OIDC claims
- **Any OIDC-compliant provider** — Standards-based JWT/OIDC support

## Use Cases

- **Enterprise MCP Deployments** — Validate agent identity before granting tool access
- **Zero Trust Architecture** — Verify every request has valid, unexpired credentials
- **API Gateway Integration** — Check OAuth scopes for fine-grained authorization
- **Audit & Compliance** — Extract and log user identity from authentication tokens
- **SSO Integration** — Verify tokens from any OIDC-compliant identity provider

## License

MIT License — see [LICENSE](LICENSE) for details.
