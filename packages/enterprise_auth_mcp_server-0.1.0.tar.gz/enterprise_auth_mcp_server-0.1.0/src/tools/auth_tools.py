"""
Enterprise Auth MCP Tools — JWT, OAuth, OIDC, RBAC
"""

import json
import base64
import hashlib
import re
from datetime import datetime, timezone
from typing import Any

import jwt
import httpx


def _decode_b64(data: str) -> str:
    """Base64url-Dekodierung mit Padding-Ergaenzung."""
    padding = 4 - len(data) % 4
    if padding != 4:
        data += "=" * padding
    # Base64url: - -> +, _ -> /
    data = data.replace("-", "+").replace("_", "/")
    return base64.b64decode(data).decode("utf-8", errors="replace")


def tool_decode_jwt(token: str) -> dict[str, Any]:
    """
    JWT-Token dekodieren (ohne Signaturvalidierung).
    Gibt Header, Payload und Signatur-Info zurueck.
    """
    try:
        parts = token.strip().split(".")
        if len(parts) != 3:
            return {"error": "Kein gueltiges JWT-Format (erwartet 3 Teile: header.payload.signature)"}

        header_raw = _decode_b64(parts[0])
        payload_raw = _decode_b64(parts[1])

        header = json.loads(header_raw)
        payload = json.loads(payload_raw)

        # Zeitstempel in lesbare Formate umwandeln
        exp_readable = None
        iat_readable = None
        nbf_readable = None
        is_expired = None

        if "exp" in payload:
            exp_dt = datetime.fromtimestamp(payload["exp"], tz=timezone.utc)
            exp_readable = exp_dt.isoformat()
            is_expired = datetime.now(tz=timezone.utc) > exp_dt

        if "iat" in payload:
            iat_dt = datetime.fromtimestamp(payload["iat"], tz=timezone.utc)
            iat_readable = iat_dt.isoformat()

        if "nbf" in payload:
            nbf_dt = datetime.fromtimestamp(payload["nbf"], tz=timezone.utc)
            nbf_readable = nbf_dt.isoformat()

        return {
            "header": header,
            "payload": payload,
            "algorithm": header.get("alg", "unbekannt"),
            "token_type": header.get("typ", "JWT"),
            "subject": payload.get("sub"),
            "issuer": payload.get("iss"),
            "audience": payload.get("aud"),
            "expires_at": exp_readable,
            "issued_at": iat_readable,
            "not_before": nbf_readable,
            "is_expired": is_expired,
            "signature_present": bool(parts[2]),
            "note": "Signatur wurde NICHT validiert — nur Dekodierung",
        }
    except json.JSONDecodeError as e:
        return {"error": f"JSON-Parsefehler im Token: {e}"}
    except Exception as e:
        return {"error": f"Fehler beim Dekodieren: {e}"}


def tool_validate_jwt(
    token: str,
    secret: str = "",
    algorithms: str = "HS256",
    audience: str = "",
    issuer: str = "",
) -> dict[str, Any]:
    """
    JWT-Token validieren (Signatur + Claims).
    Fuer HMAC-Algorithmen (HS256/384/512) wird der Secret-Key benoetigt.
    """
    try:
        algo_list = [a.strip() for a in algorithms.split(",")]

        decode_options: dict[str, Any] = {}
        if not secret:
            # Ohne Secret: nur Ablauf und Claims pruefen
            decode_options["verify_signature"] = False

        kwargs: dict[str, Any] = {
            "algorithms": algo_list,
            "options": decode_options,
        }
        if audience:
            kwargs["audience"] = audience
        if issuer:
            kwargs["issuer"] = issuer

        if secret:
            payload = jwt.decode(token, secret, **kwargs)
        else:
            payload = jwt.decode(token, options={"verify_signature": False}, algorithms=algo_list)

        return {
            "valid": True,
            "signature_verified": bool(secret),
            "payload": payload,
            "subject": payload.get("sub"),
            "issuer": payload.get("iss"),
            "audience": payload.get("aud"),
            "scopes": payload.get("scope", "").split() if payload.get("scope") else payload.get("scp", []),
            "roles": payload.get("roles", payload.get("role", [])),
            "message": "Token erfolgreich validiert",
        }
    except jwt.ExpiredSignatureError:
        return {"valid": False, "error": "Token abgelaufen (ExpiredSignatureError)"}
    except jwt.InvalidAudienceError:
        return {"valid": False, "error": f"Ungueltige Audience (erwartet: {audience})"}
    except jwt.InvalidIssuerError:
        return {"valid": False, "error": f"Ungueltiger Issuer (erwartet: {issuer})"}
    except jwt.InvalidSignatureError:
        return {"valid": False, "error": "Ungueltige Signatur — Token manipuliert oder falscher Secret"}
    except jwt.DecodeError as e:
        return {"valid": False, "error": f"JWT-Dekodierfehler: {e}"}
    except Exception as e:
        return {"valid": False, "error": f"Validierungsfehler: {e}"}


def tool_check_permissions(
    token: str,
    required_scopes: str = "",
    required_roles: str = "",
) -> dict[str, Any]:
    """
    Prueft ob ein JWT-Token die benoetigten Scopes und Rollen hat.
    required_scopes: kommagetrennte Liste (z.B. 'read:users,write:data')
    required_roles: kommagetrennte Liste (z.B. 'admin,manager')
    """
    try:
        decoded = tool_decode_jwt(token)
        if "error" in decoded:
            return {"authorized": False, "error": decoded["error"]}

        payload = decoded["payload"]

        # Scopes aus verschiedenen Claim-Formaten extrahieren
        token_scopes: set[str] = set()
        if payload.get("scope"):
            token_scopes.update(payload["scope"].split())
        if payload.get("scp"):
            scps = payload["scp"]
            if isinstance(scps, list):
                token_scopes.update(scps)
            else:
                token_scopes.update(scps.split())

        # Rollen extrahieren
        token_roles: set[str] = set()
        for role_claim in ("roles", "role", "groups", "authorities"):
            val = payload.get(role_claim, [])
            if isinstance(val, list):
                token_roles.update(val)
            elif isinstance(val, str):
                token_roles.update(val.split())

        # Vergleich
        required_scope_list = [s.strip() for s in required_scopes.split(",") if s.strip()]
        required_role_list = [r.strip() for r in required_roles.split(",") if r.strip()]

        missing_scopes = [s for s in required_scope_list if s not in token_scopes]
        missing_roles = [r for r in required_role_list if r not in token_roles]

        authorized = not missing_scopes and not missing_roles

        return {
            "authorized": authorized,
            "token_scopes": list(token_scopes),
            "token_roles": list(token_roles),
            "required_scopes": required_scope_list,
            "required_roles": required_role_list,
            "missing_scopes": missing_scopes,
            "missing_roles": missing_roles,
            "is_expired": decoded.get("is_expired"),
            "subject": decoded.get("subject"),
        }
    except Exception as e:
        return {"authorized": False, "error": f"Fehler bei Berechtigungspruefung: {e}"}


def tool_get_user_roles(token: str) -> dict[str, Any]:
    """
    Extrahiert Benutzerrollen und Identitaetsinformationen aus einem JWT.
    Unterstuetzt Standard-Claims: roles, role, groups, authorities, realm_access (Keycloak).
    """
    try:
        decoded = tool_decode_jwt(token)
        if "error" in decoded:
            return {"error": decoded["error"]}

        payload = decoded["payload"]
        roles: list[str] = []

        # Standard Rollen-Claims
        for claim in ("roles", "role", "groups", "authorities"):
            val = payload.get(claim)
            if val:
                if isinstance(val, list):
                    roles.extend(val)
                else:
                    roles.extend(val.split())

        # Keycloak realm_access
        realm_access = payload.get("realm_access", {})
        if isinstance(realm_access, dict) and realm_access.get("roles"):
            roles.extend(realm_access["roles"])

        # Keycloak resource_access
        resource_access = payload.get("resource_access", {})
        resource_roles: dict[str, list] = {}
        if isinstance(resource_access, dict):
            for resource, data in resource_access.items():
                if isinstance(data, dict) and data.get("roles"):
                    resource_roles[resource] = data["roles"]

        # Benutzerinfos
        name = payload.get("name") or payload.get("preferred_username") or payload.get("email") or payload.get("sub")
        email = payload.get("email")

        return {
            "subject": payload.get("sub"),
            "name": name,
            "email": email,
            "roles": list(set(roles)),
            "resource_roles": resource_roles,
            "scopes": payload.get("scope", "").split() if payload.get("scope") else [],
            "tenant_id": payload.get("tid") or payload.get("tenant_id"),
            "issuer": payload.get("iss"),
            "is_expired": decoded.get("is_expired"),
            "expires_at": decoded.get("expires_at"),
        }
    except Exception as e:
        return {"error": f"Fehler beim Extrahieren der Rollen: {e}"}


def tool_oauth_introspect(
    token: str,
    introspection_url: str = "",
    client_id: str = "",
    client_secret: str = "",
) -> dict[str, Any]:
    """
    OAuth 2.0 Token-Introspection (RFC 7662).
    Fragt den Authorization Server nach Token-Gueltigkeit.
    Ohne URL: lokale JWT-Dekodierung als Fallback.
    """
    if not introspection_url:
        # Lokaler Fallback: JWT dekodieren
        decoded = tool_decode_jwt(token)
        if "error" in decoded:
            return {"active": False, "error": decoded["error"]}
        payload = decoded["payload"]
        is_expired = decoded.get("is_expired")
        return {
            "active": not is_expired if is_expired is not None else True,
            "sub": payload.get("sub"),
            "iss": payload.get("iss"),
            "aud": payload.get("aud"),
            "exp": payload.get("exp"),
            "iat": payload.get("iat"),
            "scope": payload.get("scope", ""),
            "client_id": payload.get("client_id") or payload.get("azp"),
            "token_type": "Bearer",
            "note": "Lokale Dekodierung (kein Introspection-Endpoint angegeben)",
            "is_expired": is_expired,
        }

    # Remote Introspection
    try:
        data: dict[str, str] = {"token": token}
        auth = None
        if client_id and client_secret:
            auth = (client_id, client_secret)
        elif client_id:
            data["client_id"] = client_id

        with httpx.Client(timeout=10.0) as client:
            resp = client.post(introspection_url, data=data, auth=auth)
            resp.raise_for_status()
            result = resp.json()
            return result
    except httpx.HTTPStatusError as e:
        return {"active": False, "error": f"HTTP {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        return {"active": False, "error": f"Introspection-Fehler: {e}"}


def tool_verify_oidc_claims(
    token: str,
    expected_issuer: str = "",
    expected_audience: str = "",
    expected_nonce: str = "",
) -> dict[str, Any]:
    """
    OIDC-spezifische Claims validieren (OpenID Connect Core 1.0 §3.1.3.7).
    Prueft: iss, aud, exp, iat, sub, nonce.
    """
    decoded = tool_decode_jwt(token)
    if "error" in decoded:
        return {"valid": False, "error": decoded["error"]}

    payload = decoded["payload"]
    issues: list[str] = []
    warnings: list[str] = []

    # Pflicht-Claims nach OIDC Core
    for required in ("iss", "sub", "aud", "exp", "iat"):
        if required not in payload:
            issues.append(f"Pflicht-Claim fehlt: '{required}'")

    # Issuer
    if expected_issuer and payload.get("iss") != expected_issuer:
        issues.append(f"Issuer-Mismatch: erwartet '{expected_issuer}', erhalten '{payload.get('iss')}'")

    # Audience
    if expected_audience:
        aud = payload.get("aud", [])
        if isinstance(aud, str):
            aud = [aud]
        if expected_audience not in aud:
            issues.append(f"Audience-Mismatch: '{expected_audience}' nicht in {aud}")

    # Ablauf
    if decoded.get("is_expired") is True:
        issues.append("Token abgelaufen (exp-Claim)")

    # Nonce
    if expected_nonce:
        if payload.get("nonce") != expected_nonce:
            issues.append(f"Nonce-Mismatch: erwartet '{expected_nonce}'")
    elif "nonce" not in payload:
        warnings.append("Kein Nonce-Claim (empfohlen fuer Authorization Code Flow)")

    # OIDC-spezifische optionale Claims pruefen
    oidc_claims_present = {
        "name": payload.get("name"),
        "email": payload.get("email"),
        "email_verified": payload.get("email_verified"),
        "preferred_username": payload.get("preferred_username"),
        "picture": payload.get("picture"),
        "locale": payload.get("locale"),
    }

    at_hash = payload.get("at_hash")
    c_hash = payload.get("c_hash")

    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "warnings": warnings,
        "issuer": payload.get("iss"),
        "subject": payload.get("sub"),
        "audience": payload.get("aud"),
        "expires_at": decoded.get("expires_at"),
        "is_expired": decoded.get("is_expired"),
        "oidc_claims": {k: v for k, v in oidc_claims_present.items() if v is not None},
        "has_at_hash": bool(at_hash),
        "has_c_hash": bool(c_hash),
        "algorithm": decoded.get("algorithm"),
    }


def tool_list_token_scopes(token: str) -> dict[str, Any]:
    """
    Listet alle Scopes, Rollen und Berechtigungen aus einem JWT-Token auf.
    Unterstuetzt OAuth 2.0 'scope', OIDC 'scp', Azure AD, Keycloak, Auth0.
    """
    decoded = tool_decode_jwt(token)
    if "error" in decoded:
        return {"error": decoded["error"]}

    payload = decoded["payload"]
    all_scopes: list[str] = []
    all_roles: list[str] = []
    provider_hints: list[str] = []

    # OAuth 2.0 Standard-Scope
    scope_str = payload.get("scope", "")
    if scope_str:
        all_scopes.extend(scope_str.split())

    # Microsoft/Azure AD scp
    scp = payload.get("scp")
    if scp:
        if isinstance(scp, list):
            all_scopes.extend(scp)
        else:
            all_scopes.extend(scp.split())

    # Provider-Erkennung
    iss = payload.get("iss", "")
    if "microsoftonline.com" in iss or "microsoft.com" in iss:
        provider_hints.append("Azure AD / Microsoft Entra ID")
    elif "accounts.google.com" in iss:
        provider_hints.append("Google Identity")
    elif "auth0.com" in iss:
        provider_hints.append("Auth0")
    elif "okta.com" in iss:
        provider_hints.append("Okta")
    elif "keycloak" in iss.lower() or payload.get("realm_access"):
        provider_hints.append("Keycloak")

    # Rollen
    for claim in ("roles", "role", "groups", "authorities"):
        val = payload.get(claim)
        if val:
            if isinstance(val, list):
                all_roles.extend(val)
            else:
                all_roles.extend(val.split())

    # Keycloak realm_access
    realm = payload.get("realm_access", {})
    if isinstance(realm, dict):
        all_roles.extend(realm.get("roles", []))

    # Azure AD Permissions
    azure_perms = payload.get("wids", [])  # Azure AD Directory Roles
    azure_app_roles = payload.get("roles", [])  # Azure App Roles

    return {
        "scopes": list(set(all_scopes)),
        "roles": list(set(all_roles)),
        "azure_directory_roles": azure_perms,
        "subject": payload.get("sub"),
        "client_id": payload.get("client_id") or payload.get("azp") or payload.get("appid"),
        "issuer": payload.get("iss"),
        "detected_provider": provider_hints[0] if provider_hints else "Unbekannt/Generisch",
        "is_expired": decoded.get("is_expired"),
        "expires_at": decoded.get("expires_at"),
        "total_scopes": len(set(all_scopes)),
        "total_roles": len(set(all_roles)),
    }


def tool_get_oidc_discovery(issuer_url: str) -> dict[str, Any]:
    """
    OIDC Discovery Dokument abrufen (RFC 8414 / OIDC Core).
    Gibt Endpoints (authorization, token, userinfo, introspection, jwks_uri) zurueck.
    """
    try:
        # Standard Discovery URL
        discovery_url = issuer_url.rstrip("/") + "/.well-known/openid-configuration"

        with httpx.Client(timeout=10.0) as client:
            resp = client.get(discovery_url)
            resp.raise_for_status()
            doc = resp.json()

        return {
            "issuer": doc.get("issuer"),
            "authorization_endpoint": doc.get("authorization_endpoint"),
            "token_endpoint": doc.get("token_endpoint"),
            "userinfo_endpoint": doc.get("userinfo_endpoint"),
            "introspection_endpoint": doc.get("introspection_endpoint"),
            "revocation_endpoint": doc.get("revocation_endpoint"),
            "jwks_uri": doc.get("jwks_uri"),
            "end_session_endpoint": doc.get("end_session_endpoint"),
            "response_types_supported": doc.get("response_types_supported", []),
            "grant_types_supported": doc.get("grant_types_supported", []),
            "id_token_signing_alg_values_supported": doc.get("id_token_signing_alg_values_supported", []),
            "scopes_supported": doc.get("scopes_supported", []),
            "claims_supported": doc.get("claims_supported", []),
            "discovery_url": discovery_url,
        }
    except httpx.HTTPStatusError as e:
        return {"error": f"HTTP {e.response.status_code} bei {discovery_url}: {e.response.text[:200]}"}
    except Exception as e:
        return {"error": f"Discovery-Fehler: {e}"}
