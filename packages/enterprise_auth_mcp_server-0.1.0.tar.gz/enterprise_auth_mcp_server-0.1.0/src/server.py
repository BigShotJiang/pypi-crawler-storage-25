"""
Enterprise Auth MCP Server
JWT-Validierung, OIDC-Token-Inspektion, OAuth 2.0 Introspection, RBAC
"""

from mcp.server.fastmcp import FastMCP
from src.tools.auth_tools import (
    tool_decode_jwt,
    tool_validate_jwt,
    tool_check_permissions,
    tool_get_user_roles,
    tool_oauth_introspect,
    tool_verify_oidc_claims,
    tool_list_token_scopes,
    tool_get_oidc_discovery,
)

# Server initialisieren
mcp = FastMCP(
    "enterprise-auth-mcp-server",
    instructions=(
        "MCP server for enterprise authentication and authorization. "
        "Decode and validate JWT tokens, check OAuth 2.0 scopes, "
        "verify OIDC claims, extract user roles, and discover OIDC provider endpoints. "
        "Supports Azure AD, Okta, Keycloak, Auth0 and any standards-compliant identity provider."
    ),
)


@mcp.tool()
def decode_jwt(token: str) -> dict:
    """
    JWT-Token dekodieren (ohne Signaturvalidierung).
    Gibt Header, Payload und Metadaten zurueck.
    Nuetzlich fuer schnelle Inspektion von Token-Inhalten.
    """
    return tool_decode_jwt(token)


@mcp.tool()
def validate_jwt(
    token: str,
    secret: str = "",
    algorithms: str = "HS256",
    audience: str = "",
    issuer: str = "",
) -> dict:
    """
    JWT-Token validieren — Signatur, Ablauf und Claims pruefen.
    secret: HMAC-Secret oder leer fuer keine Signaturpruefung.
    algorithms: kommagetrennte Liste, z.B. 'HS256,RS256'.
    audience: erwartete Audience (optional).
    issuer: erwarteter Issuer (optional).
    """
    return tool_validate_jwt(token, secret, algorithms, audience, issuer)


@mcp.tool()
def check_permissions(
    token: str,
    required_scopes: str = "",
    required_roles: str = "",
) -> dict:
    """
    Prueft ob ein JWT-Token die benoetigten Scopes und Rollen besitzt.
    required_scopes: kommagetrennte Liste, z.B. 'read:users,write:data'.
    required_roles: kommagetrennte Liste, z.B. 'admin,manager'.
    """
    return tool_check_permissions(token, required_scopes, required_roles)


@mcp.tool()
def get_user_roles(token: str) -> dict:
    """
    Extrahiert Benutzerrollen und Identitaetsinformationen aus einem JWT.
    Unterstuetzt Standard-Claims und Keycloak realm_access/resource_access.
    """
    return tool_get_user_roles(token)


@mcp.tool()
def oauth_introspect(
    token: str,
    introspection_url: str = "",
    client_id: str = "",
    client_secret: str = "",
) -> dict:
    """
    OAuth 2.0 Token-Introspection (RFC 7662).
    introspection_url: Endpoint des Authorization Servers (optional).
    Ohne URL: lokale JWT-Dekodierung als Fallback.
    """
    return tool_oauth_introspect(token, introspection_url, client_id, client_secret)


@mcp.tool()
def verify_oidc_claims(
    token: str,
    expected_issuer: str = "",
    expected_audience: str = "",
    expected_nonce: str = "",
) -> dict:
    """
    OIDC-spezifische Claims validieren (OpenID Connect Core 1.0).
    Prueft: iss, sub, aud, exp, iat, nonce.
    Erkennt fehlende Pflicht-Claims und Audience/Issuer-Mismatches.
    """
    return tool_verify_oidc_claims(token, expected_issuer, expected_audience, expected_nonce)


@mcp.tool()
def list_token_scopes(token: str) -> dict:
    """
    Listet alle Scopes, Rollen und Berechtigungen aus einem JWT-Token auf.
    Erkennt automatisch den Identity Provider (Azure AD, Okta, Auth0, Keycloak).
    """
    return tool_list_token_scopes(token)


@mcp.tool()
def get_oidc_discovery(issuer_url: str) -> dict:
    """
    OIDC Discovery Dokument abrufen (/.well-known/openid-configuration).
    Gibt alle wichtigen Endpoints (authorization, token, userinfo, jwks_uri) zurueck.
    Beispiel issuer_url: https://accounts.google.com oder https://login.microsoftonline.com/tenant-id
    """
    return tool_get_oidc_discovery(issuer_url)


def main():
    """Server starten."""
    mcp.run()


if __name__ == "__main__":
    main()
