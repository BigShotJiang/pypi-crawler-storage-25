from __future__ import annotations

import asyncio
import json

from llm_input_harderning.middleware import StarlettePromptSanitizerMiddleware


def _run_middleware(body: bytes) -> tuple[dict[str, object], list[dict[str, object]]]:
    captured: dict[str, object] = {}
    sent_messages: list[dict[str, object]] = []

    async def app(scope, receive, send):
        chunks: list[bytes] = []
        while True:
            message = await receive()
            if message["type"] != "http.request":
                continue
            chunks.append(message.get("body", b""))
            if not message.get("more_body", False):
                break
        captured["scope"] = scope
        captured["body"] = b"".join(chunks)
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b"ok", "more_body": False})

    delivered = False

    async def receive():
        nonlocal delivered
        if delivered:
            return {"type": "http.request", "body": b"", "more_body": False}
        delivered = True
        return {"type": "http.request", "body": body, "more_body": False}

    async def send(message):
        sent_messages.append(message)

    scope = {
        "type": "http",
        "method": "POST",
        "path": "/",
        "headers": [
            (b"content-type", b"application/json"),
            (b"content-length", str(len(body)).encode("latin-1")),
        ],
    }
    middleware = StarlettePromptSanitizerMiddleware(
        app,
        field="prompt",
        policy="balanced_chat",
        limit_tokens=32,
    )
    asyncio.run(middleware(scope, receive, send))
    return captured, sent_messages


def test_middleware_rewrites_json_body_and_content_length() -> None:
    original = json.dumps({"prompt": "abc\u202Edef"}).encode("utf-8")
    captured, sent_messages = _run_middleware(original)

    rewritten = json.loads(captured["body"])
    assert rewritten["prompt"] == "abcdef"

    headers = dict(captured["scope"]["headers"])
    assert headers[b"content-length"] == str(len(captured["body"])).encode("latin-1")

    response_start = next(msg for msg in sent_messages if msg["type"] == "http.response.start")
    response_headers = dict(response_start["headers"])
    assert response_headers[b"x-sanitize-changed"] == b"true"
    assert int(response_headers[b"x-tokens-before"]) >= int(response_headers[b"x-tokens-after"])


def test_middleware_replays_original_body_when_field_missing() -> None:
    original = json.dumps({"other": "value"}).encode("utf-8")
    captured, sent_messages = _run_middleware(original)

    assert captured["body"] == original
    response_start = next(msg for msg in sent_messages if msg["type"] == "http.response.start")
    assert response_start["headers"] == []
