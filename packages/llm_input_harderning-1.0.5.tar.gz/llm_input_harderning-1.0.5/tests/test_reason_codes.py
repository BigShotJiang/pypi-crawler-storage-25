from __future__ import annotations

from llm_input_harderning import sanitize
from llm_input_harderning.reason_codes import REASON_CODE_REGISTRY


def test_reason_code_registry_stability() -> None:
    assert REASON_CODE_REGISTRY["bidi_control"] == "IH001_BIDI_CONTROL"
    assert REASON_CODE_REGISTRY["default_ignorable"] == "IH002_DEFAULT_IGNORABLE"
    assert REASON_CODE_REGISTRY["high_entropy"] == "IH010_HIGH_ENTROPY"
    assert REASON_CODE_REGISTRY["confusable_mixed_script"] == "IH020_CONFUSABLE_MIXED_SCRIPT"
    assert REASON_CODE_REGISTRY["base64ish_blob"] == "IH030_BASE64_LIKE_PAYLOAD"


def test_sanitize_report_includes_reason_codes() -> None:
    clean, rep = sanitize("abc\u202Edef", policy="balanced_chat")
    assert clean == "abcdef"
    assert rep["reason_codes"].get("IH001_BIDI_CONTROL", 0) == 1
