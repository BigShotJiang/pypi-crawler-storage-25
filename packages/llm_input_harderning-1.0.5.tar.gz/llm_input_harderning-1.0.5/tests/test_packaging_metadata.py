from __future__ import annotations

import json
import re
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]


def _match(pattern: str, text: str) -> str:
    matched = re.search(pattern, text, flags=re.MULTILINE)
    assert matched is not None
    return matched.group(1)


def test_python_and_rust_versions_match() -> None:
    pyproject = (REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8")
    cargo = (REPO_ROOT / "Cargo.toml").read_text(encoding="utf-8")
    assert _match(r'^version = "([^"]+)"$', pyproject) == _match(r'^version = "([^"]+)"$', cargo)


def test_python_source_layout_points_at_python_directory() -> None:
    pyproject = (REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert _match(r'^python-source = "([^"]+)"$', pyproject) == "python"
    assert (REPO_ROOT / "python" / "llm_input_harderning" / "__init__.py").exists()


def test_distribution_name_and_console_script_match_release_configuration() -> None:
    pyproject = (REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert _match(r'^name = "([^"]+)"$', pyproject) == "llm-input-harderning"
    assert (
        _match(r'^llm-input-harderning = "([^"]+)"$', pyproject)
        == "llm_input_harderning.cli:main"
    )


def test_only_supported_optional_extras_are_exposed() -> None:
    pyproject = (REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert _match(r'^ftfy = \["([^"]+)"\]$', pyproject) == "ftfy>=6.2.0"
    assert (
        _match(r'^security = \["([^"]+)"\]$', pyproject)
        == "confusable-homoglyphs>=3.3.1"
    )
    assert re.search(r"^tokens = ", pyproject, flags=re.MULTILINE) is None
    assert re.search(r"^web = ", pyproject, flags=re.MULTILINE) is None


def test_policy_registry_contains_public_aliases_and_presets() -> None:
    registry = json.loads(
        (REPO_ROOT / "python" / "llm_input_harderning" / "policy_registry.json").read_text(
            encoding="utf-8"
        )
    )
    assert set(registry["presets"]) == {"preserve", "balanced_chat", "strict_exec", "code_mode"}
    assert registry["aliases"] == {
        "balanced": "balanced_chat",
        "strict": "strict_exec",
        "code": "code_mode",
    }
