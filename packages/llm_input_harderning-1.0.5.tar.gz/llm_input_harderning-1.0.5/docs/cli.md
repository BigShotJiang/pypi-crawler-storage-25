# CLI

The project includes a CLI with three commands:

- `sanitize`: sanitize text and print JSON (`sanitized_text`, `report`, `timing_ms`)
- `inspect`: sanitize and print JSON plus a small summary
- `decide`: sanitize + enforcement decision (`allow`/`quarantine`/`reject`)

## Examples

```bash
uv run llm-input-harderning sanitize --text "abc\u202Edef"
uv run llm-input-harderning inspect --text "hello"
uv run llm-input-harderning decide --text "раypal"
```

Exit codes for `decide`:

- `0`: allow
- `2`: quarantine
- `3`: reject
