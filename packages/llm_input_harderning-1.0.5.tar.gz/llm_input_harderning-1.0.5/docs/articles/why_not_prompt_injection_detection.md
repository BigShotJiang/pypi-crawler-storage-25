# Why Not Prompt Injection Detection?

`llm-input-harderning` is intentionally not a prompt injection detector.

## Reason 1: Different problem class

This library solves text integrity issues:
- ambiguous characters
- invisible control channels
- deterministic normalization and reporting

Prompt injection is semantic and context-dependent.

## Reason 2: Determinism requirement

The project is designed for deterministic, low-latency behavior at the gateway boundary. Semantic detection would introduce model-level uncertainty and larger runtime cost.

## Reason 3: Better composition

A robust stack composes:
1. deterministic text integrity first
2. semantic policy and moderation second
3. output/tool controls third

This separation keeps responsibilities clear and observable.
