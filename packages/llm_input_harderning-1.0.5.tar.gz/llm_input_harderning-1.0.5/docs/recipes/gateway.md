# Gateway Recipe

Sanitize inbound JSON recursively and enforce on reason codes.

```python
from llm_input_harderning import sanitize_json
from llm_input_harderning.enforcement import decide_enforcement

clean_payload, report = sanitize_json(request_payload, policy="balanced_chat")
decision = decide_enforcement(report)
if decision["action"] == "reject":
    raise ValueError({"reason_codes": decision["reason_codes"]})
```

Recommended split:
- user chat content: `balanced_chat`
- tool args / privileged ops: `strict_exec`
