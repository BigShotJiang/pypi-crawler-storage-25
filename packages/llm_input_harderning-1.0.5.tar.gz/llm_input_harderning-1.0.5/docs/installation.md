# Installation

Install the base package:

```bash
pip install llm-input-harderning
```

Optional extras:

- `security`: `confusable_homoglyphs` backend for stronger confusable detection
- `ftfy`: pre-sanitize text repair

Examples:

```bash
pip install "llm-input-harderning[security]"
pip install "llm-input-harderning[ftfy]"
```

## From source

```bash
uv sync --all-extras
uv run maturin develop --release
```
