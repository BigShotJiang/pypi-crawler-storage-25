# Scope Boundaries

This library is intentionally **text-level** only.

## In scope

- Unicode normalization (`NFC`/`NFKC` by policy)
- Removal of risky invisible/ambiguous code points
- Removal of bidi/control characters that break prompt boundaries
- Heuristic flags for suspicious payload shape
- Structured reporting for enforcement/logging pipelines

## Out of scope

- Semantic jailbreak reasoning
- Emoji meaning interpretation
- HTML entity decoding
- URL decoding
- Tool sandboxing / model output policy enforcement

See [SCOPE.md](https://github.com/davidwebstar34/llm-input-harderning/blob/main/SCOPE.md) for the full contract.
