# Contributing

The contributor workflow lives in the repository root:

- [Contributing guide](https://github.com/davidwebstar34/llm-input-harderning/blob/main/CONTRIBUTING.md)
- [Security policy](https://github.com/davidwebstar34/llm-input-harderning/blob/main/SECURITY.md)
- [Scope](https://github.com/davidwebstar34/llm-input-harderning/blob/main/SCOPE.md)

In short:

```bash
uv sync --all-extras
uv run maturin develop --release
uv run pytest -q
```
