from __future__ import annotations

from typing import cast

from .confusables import detect_confusables
try:
    from ._core import sanitize as _sanitize_core
except ModuleNotFoundError as exc:  # pragma: no cover - import-time guard
    if exc.name == "llm_input_harderning._core":
        raise ModuleNotFoundError(
            "llm_input_harderning._core is missing. "
            "Build it with: `uv run maturin develop --release`."
        ) from exc
    raise
from .policies import resolve_policy_name
from .postprocess import looks_hex_blob, max_entropy_window
from .reason_codes import reason_code_counts
from .types import SanitizeReport


def sanitize_text(
    text: str,
    policy: str = "balanced_chat",
    *,
    return_spans: bool = False,
    normalization: str | None = None,
    tidy_whitespace: bool | None = None,
    use_ftfy: bool = False,
    confusables_backend: str | None = None,
) -> tuple[str, SanitizeReport]:
    """Sanitize untrusted text for safer prompt embedding."""

    if use_ftfy:
        try:
            import ftfy  # optional

            text = ftfy.fix_text(text)
        except Exception:
            pass

    canonical_policy = resolve_policy_name(policy)
    clean, report = _sanitize_core(
        text,
        canonical_policy,
        normalization,
        tidy_whitespace,
        return_spans,
    )
    if isinstance(report, dict) and "report_version" not in report:
        report["report_version"] = 1

    if isinstance(report, dict):
        report["policy"] = canonical_policy
        stats = report.setdefault("stats", {})
        removed = report.setdefault("removed_counts", {})
        flagged = report.setdefault("flagged_counts", {})

        if isinstance(stats, dict):
            hexb = looks_hex_blob(clean)
            stats["hexbish"] = hexb
            if hexb and isinstance(flagged, dict):
                flagged["hex_blob"] = int(flagged.get("hex_blob", 0)) + 1
                if int(flagged.get("base64ish_blob", 0)) > 0:
                    remaining = int(flagged.get("base64ish_blob", 0)) - 1
                    if remaining > 0:
                        flagged["base64ish_blob"] = remaining
                    else:
                        flagged.pop("base64ish_blob", None)

            ent_max = max_entropy_window(clean, window=256, stride=64)
            stats["entropy_window_max"] = ent_max
            if ent_max > 4.8 and len(clean) >= 256 and isinstance(flagged, dict):
                if int(flagged.get("high_entropy", 0)) == 0:
                    flagged["high_entropy"] = 1

        backend = confusables_backend
        if backend is None:
            backend = "confusable_homoglyphs" if canonical_policy == "code_mode" else "heuristic"
        signal = detect_confusables(clean, backend=backend)
        if isinstance(stats, dict) and isinstance(flagged, dict):
            stats["confusables_backend"] = signal["backend"]
            stats["confusables_available"] = signal["available"]
            stats["confusables_mixed_script"] = signal["mixed_script"]
            stats["confusables_dangerous"] = signal["dangerous"]
            stats["confusables_restriction_level"] = signal["restriction_level"]
            stats["confusables_scripts"] = signal["script_set"]
            stats["confusables_skeleton_stored"] = signal["skeleton_stored"]
            stats["confusable_count"] = signal["confusable_count"]
            stats["mixed_script_word_count"] = signal["mixed_word_count"]
            stats["mixed_script_words"] = signal["mixed_words"]
            if signal["error"] is not None:
                stats["confusables_error"] = signal["error"]
            if signal["mixed_script"]:
                flagged["mixed_script_word"] = int(flagged.get("mixed_script_word", 0)) + 1
            if signal["dangerous"]:
                flagged["confusable_mixed_script"] = int(
                    flagged.get("confusable_mixed_script", 0)
                ) + 1

        if isinstance(removed, dict) and isinstance(flagged, dict):
            report["reason_codes"] = reason_code_counts(removed, flagged)
        else:
            report["reason_codes"] = {}

    return clean, cast(SanitizeReport, report)
