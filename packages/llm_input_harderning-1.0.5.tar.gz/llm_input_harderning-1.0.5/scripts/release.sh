#!/usr/bin/env bash

set -euo pipefail

usage() {
  cat <<'EOF'
Usage: scripts/release.sh <version> [--dry-run]

Examples:
  scripts/release.sh 1.0.1
  scripts/release.sh v1.0.1 --dry-run
EOF
}

if [[ $# -lt 1 || $# -gt 2 ]]; then
  usage
  exit 1
fi

raw_version="$1"
dry_run=false

if [[ $# -eq 2 ]]; then
  if [[ "$2" != "--dry-run" ]]; then
    usage
    exit 1
  fi
  dry_run=true
fi

version="${raw_version#v}"
tag="v${version}"

if [[ ! "$version" =~ ^[0-9]+(\.[0-9]+){2}([.-][0-9A-Za-z.-]+)?$ ]]; then
  echo "error: version must look like 1.2.3 or 1.2.3-rc1" >&2
  exit 1
fi

branch="$(git branch --show-current)"
if [[ "$branch" != "main" ]]; then
  echo "error: release script must be run from the main branch; current branch is '$branch'" >&2
  exit 1
fi

if git rev-parse --verify --quiet "$tag" >/dev/null; then
  echo "error: git tag '$tag' already exists locally" >&2
  exit 1
fi

read_pyproject_version() {
  sed -nE 's/^version = "([^"]+)"$/\1/p' pyproject.toml | head -n1
}

read_cargo_toml_version() {
  sed -nE 's/^version = "([^"]+)"$/\1/p' Cargo.toml | head -n1
}

read_uv_lock_version() {
  if [[ ! -f uv.lock ]]; then
    return 0
  fi
  perl -0ne 'print "$1\n" if /\[\[package\]\]\nname = "llm-input-harderning"\nversion = "([^"]+)"/s' uv.lock
}

read_cargo_lock_version() {
  if [[ ! -f Cargo.lock ]]; then
    return 0
  fi
  perl -0ne 'print "$1\n" if /\[\[package\]\]\nname = "llm_input_harderning"\nversion = "([^"]+)"/s' Cargo.lock
}

set_top_level_version() {
  local file="$1"
  python3 - "$file" "$version" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
version = sys.argv[2]
text = path.read_text(encoding="utf-8")
updated, count = re.subn(
    r'(?m)^version = "[^"]+"$',
    f'version = "{version}"',
    text,
    count=1,
)
if count != 1:
    raise SystemExit(f"failed to update top-level version in {path}")
path.write_text(updated, encoding="utf-8")
PY
}

set_named_package_version() {
  local file="$1"
  local package_name="$2"
  python3 - "$file" "$package_name" "$version" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
package_name = sys.argv[2]
version = sys.argv[3]
text = path.read_text(encoding="utf-8")
pattern = re.compile(
    rf'(\[\[package\]\]\nname = "{re.escape(package_name)}"\nversion = )"[^"]+"',
    re.MULTILINE,
)
updated, count = pattern.subn(rf'\1"{version}"', text, count=1)
if count != 1:
    raise SystemExit(f"failed to update package version for {package_name} in {path}")
path.write_text(updated, encoding="utf-8")
PY
}

run() {
  printf '+'
  for arg in "$@"; do
    printf ' %q' "$arg"
  done
  printf '\n'

  if [[ "$dry_run" == false ]]; then
    "$@"
  fi
}

update_version_file() {
  local file="$1"
  local current="$2"
  printf '+ update %s: %s -> %s\n' "$file" "${current:-<missing>}" "$version"
}

set_versions() {
  local pyproject_version cargo_version uv_lock_version cargo_lock_version

  pyproject_version="$(read_pyproject_version)"
  cargo_version="$(read_cargo_toml_version)"
  uv_lock_version="$(read_uv_lock_version)"
  cargo_lock_version="$(read_cargo_lock_version)"

  if [[ -z "$pyproject_version" ]]; then
    echo "error: failed to read version from pyproject.toml" >&2
    exit 1
  fi

  if [[ -z "$cargo_version" ]]; then
    echo "error: failed to read version from Cargo.toml" >&2
    exit 1
  fi

  if [[ "$pyproject_version" != "$version" ]]; then
    update_version_file "pyproject.toml" "$pyproject_version"
    if [[ "$dry_run" == false ]]; then
      set_top_level_version pyproject.toml
    fi
  fi

  if [[ "$cargo_version" != "$version" ]]; then
    update_version_file "Cargo.toml" "$cargo_version"
    if [[ "$dry_run" == false ]]; then
      set_top_level_version Cargo.toml
    fi
  fi

  if [[ -f uv.lock && "$uv_lock_version" != "$version" ]]; then
    update_version_file "uv.lock" "$uv_lock_version"
    if [[ "$dry_run" == false ]]; then
      set_named_package_version uv.lock llm-input-harderning
    fi
  fi

  if [[ -f Cargo.lock && "$cargo_lock_version" != "$version" ]]; then
    update_version_file "Cargo.lock" "$cargo_lock_version"
    if [[ "$dry_run" == false ]]; then
      set_named_package_version Cargo.lock llm_input_harderning
    fi
  fi

  if [[ "$dry_run" == false ]]; then
    if [[ "$(read_pyproject_version)" != "$version" ]]; then
      echo "error: failed to update pyproject.toml to version $version" >&2
      exit 1
    fi
    if [[ "$(read_cargo_toml_version)" != "$version" ]]; then
      echo "error: failed to update Cargo.toml to version $version" >&2
      exit 1
    fi
    if [[ -f uv.lock && "$(read_uv_lock_version)" != "$version" ]]; then
      echo "error: failed to update uv.lock to version $version" >&2
      exit 1
    fi
    if [[ -f Cargo.lock && "$(read_cargo_lock_version)" != "$version" ]]; then
      echo "error: failed to update Cargo.lock to version $version" >&2
      exit 1
    fi
  fi
}

set_versions
run git add .
run git commit -m "Release ${version}"
run git tag "$tag"
run git push origin main
run git push origin "$tag"
