import argparse
import json
import os
TRACE_FILE = os.path.join(os.path.dirname(__file__), '..', 'trace.txt')

parser = argparse.ArgumentParser()
parser.add_argument("-S" , "--Status" , help = "Based on what status do filter" , choices = ["success" , "failed"])
parser.add_argument("-L" , "--Latency" , help = "Based on what latency do filter")
parser.add_argument("-M" , "--Model" , help = "Based on what model do filter")
parser.add_argument("-E" , "--Error" , help = "Based on what type of Error do filter")
parser.add_argument("-T" , "--Time" , help = "Based on what time do filter")
args = parser.parse_args()


conditions = []
if args.Status:
    conditions.append(lambda t : t.get('Status') == args.Status)
if args.Latency:
    conditions.append(lambda t : t.get('Latency') >= float(args.Latency))
if args.Model:
    conditions.append(lambda t : t.get('Model') == args.Model)
if args.Error:
    conditions.append(lambda t : t.get('Error Type' , None) == args.Error)
if args.Time:
    conditions.append(lambda t : t.get('Start Time') >= float(args.Time))
with open(TRACE_FILE , 'r') as trace_file:
    for line in trace_file:
        trace = json.loads(line)
        if all(condition(trace) for condition in conditions):
            print("\n--- Trace ---")
            for key, value in trace.items():
                print(f"  {key}: {value}")
            print("-------------")
