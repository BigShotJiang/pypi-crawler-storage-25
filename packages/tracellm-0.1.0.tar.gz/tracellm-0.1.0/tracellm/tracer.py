import json
import time
from datetime import datetime
import os
TRACE_FILE = os.path.join(os.path.dirname(__file__), '..', 'trace.txt')

class Tracer:
    def __init__(self):
        pass


    def start_trace(self , model , prompt ):
        self.start_time = time.time()
        self.prompt = prompt
        self.model = model
        self.timestamp = datetime.fromtimestamp(self.start_time).strftime('%Y-%m-%d %H:%M:%S')

    def end_trace(self, response):
        self.end_time = time.time()
        self.tokens_used = response.usage.total_tokens
        self.finish_reason = response.choices[0].finish_reason
        self.status = "success"
        self.latency =  self.end_time - self.start_time
        self.data = {"Model" : self.model , "Prompt" : self.prompt , "Response" : response.choices[0].message.content , "Tokens used" : self.tokens_used , "Finish reason" : self.finish_reason , "Latency" : round(self.latency , 3) , "Status" : self.status , "Timestamp" : self.timestamp }
        with open(TRACE_FILE , 'a') as trace_file:
            json.dump(self.data , trace_file)
            trace_file.write('\n')


    def record_error(self, error_type , error_message):
        self.end_time = time.time()
        self.error_type = error_type
        self.error_message = error_message
        self.status = "failed"
        self.latency =  self.end_time - self.start_time
        self.data = {"Model" : self.model , "Prompt" : self.prompt , "Latency" : round(self.latency , 3) , "Status" : self.status , "Error Type" : self.error_type , "Error Message" : self.error_message , "Timestamp" : self.timestamp }
        with open(TRACE_FILE , 'a') as trace_file:
            json.dump(self.data , trace_file)
            trace_file.write('\n')