# tracellm

Lightweight tracing for LLM applications. One import, three calls — 
every API interaction logged locally, queryable from your terminal.

No backend. No signup. Nothing leaves your machine.

## Install

pip install tracellm

## Usage

from tracellm import Tracer

tracer = Tracer()
tracer.start_trace(model="llama-3.1-8b-instant", prompt="your prompt")

try:
    response = client.chat.completions.create(...)
    tracer.end_trace(response)
except Exception as e:
    tracer.record_error(type(e).__name__, str(e))

## Query traces from terminal

python -m tracellm.cli --Status failed
python -m tracellm.cli --Latency 2.0
python -m tracellm.cli --Model llama-3.1-8b-instant
python -m tracellm.cli --Status failed --Latency 1.5

## What gets captured

- Model, prompt, response
- Tokens used, latency, finish reason
- Error type and message on failures
- Timestamp for every call

## Limitations

Storage is append-only JSON lines. Query supports >=  
for latency, exact match for everything else. Early days.

## Roadmap

- Binary storage for faster querying at scale
- Cost calculation per model
- Terminal dashboard