# src/nithinlang/cli.py
"""
NithinLang Command-Line Interface & Package Manager
=====================================================

Global command: `nithin`

Subcommands
-----------
  nithin run       <file.nl>       Run a NithinLang program
  nithin build     <file.nl>       Build a standalone EXE (Windows)
  nithin build-apk <file.nl>       Build an Android APK (Requires Linux/WSL)
  nithin check     <file.nl>       Syntax-check without running
  nithin new       <project_name>  Scaffold a new project
  nithin info      <file.nl>       Show parse metadata
  nithin version                   Print version info
  nithin langs                     List supported languages
  nithin bench     <file.nl>       Run + display execution timing
  nithin ai-status                 Check local AI brain status
  nithin repl                      Start the interactive NithinLang shell
"""

from __future__ import annotations

import os
import sys
import time
import textwrap
import subprocess
import platform
from typing import Optional

# ── Third-party ──────────────────────────────────────────────────────────
try:
    import click
    _CLICK = True
except ImportError:
    _CLICK = False

try:
    from rich.console   import Console
    from rich.panel     import Panel
    from rich.table     import Table
    from rich.text      import Text
    from rich.progress  import Progress, SpinnerColumn, TextColumn
    _RICH = True
except ImportError:
    _RICH = False

# ── NithinLang internals ──────────────────────────────────────────────────
from nithinlang             import __version__
from nithinlang.parser      import NithinParser
from nithinlang.compiler    import NithinCompiler
from nithinlang.dicts       import list_languages

try:
    from nithinlang.n_loader import NLoader
    _NLOADER_AVAILABLE = True
except ImportError:
    _NLOADER_AVAILABLE = False


# ---------------------------------------------------------------------------
# Console helper & Styling
# ---------------------------------------------------------------------------

if _RICH:
    _console = Console(highlight=True)
    def _print(msg: str, style: str = "") -> None:
        _console.print(msg, style=style)
    def _print_error(msg: str) -> None:
        _console.print(f"[bold red]✗[/bold red] {msg}")
    def _print_success(msg: str) -> None:
        _console.print(f"[bold green]✓[/bold green] {msg}")
    def _print_info(msg: str) -> None:
        _console.print(f"[bold cyan]ℹ[/bold cyan] {msg}")
    def _print_warning(msg: str) -> None:
        _console.print(f"[bold yellow]![/bold yellow] {msg}")
    def _print_banner() -> None:
        banner = Panel(
            f"[bold yellow]NithinLang CLI[/bold yellow] [white]v{__version__}[/white]\n"
            "[dim]100% Free · Open-Source · Zero-Cloud · Multi-Lingual · Ultra-Fast[/dim]\n"
            "[bold cyan]ENGINEERED BY NGI EMPIRE - POWERING BHARAT[/bold cyan]",
            border_style="bright_blue",
            expand=False,
        )
        _console.print(banner)
else:
    def _print(msg: str, style: str = "") -> None:       # type: ignore
        print(msg)
    def _print_error(msg: str) -> None:                  # type: ignore
        print(f"[ERROR] {msg}", file=sys.stderr)
    def _print_success(msg: str) -> None:                # type: ignore
        print(f"[OK] {msg}")
    def _print_info(msg: str) -> None:                   # type: ignore
        print(f"[INFO] {msg}")
    def _print_warning(msg: str) -> None:                # type: ignore
        print(f"[WARNING] {msg}")
    def _print_banner() -> None:                         # type: ignore
        print(f"NithinLang v{__version__} - NGI EMPIRE")

# ---------------------------------------------------------------------------
# CLI Commands
# ---------------------------------------------------------------------------

if _CLICK:

    @click.group(invoke_without_command=True)
    @click.version_option(__version__, "--version", "-V", prog_name="NithinLang")
    @click.pass_context
    def main(ctx: click.Context) -> None:
        """NithinLang V1.5 — The Multi-Lingual Ecosystem."""
        if ctx.invoked_subcommand is None:
            _print_banner()
            click.echo(ctx.get_help())

    # =======================================================================
    # 1. RUN COMMAND
    # =======================================================================
    @main.command("run")
    @click.argument("filepath")
    @click.option("--verbose", "-v", is_flag=True, help="Enable verbose engine output")
    @click.option("--no-jit", is_flag=True, help="Disable LLVM JIT compilation")
    def cmd_run(filepath: str, verbose: bool, no_jit: bool) -> None:
        """Run a NithinLang (.nl) file."""
        code = _execute_file(filepath, verbose=verbose, jit=not no_jit)
        sys.exit(code)

    # =======================================================================
    # 2. BENCHMARK COMMAND
    # =======================================================================
    @main.command("bench")
    @click.argument("filepath", type=click.Path(exists=True))
    @click.option("--no-jit", is_flag=True, help="Disable JIT to compare speeds")
    def cmd_bench(filepath: str, no_jit: bool) -> None:
        """Run + display execution timing."""
        _print_banner()
        _print_info(f"Benchmarking '{filepath}' (JIT: {'OFF' if no_jit else 'ON'})...")
        
        start_time = time.perf_counter()
        code = _execute_file(filepath, verbose=False, jit=not no_jit)
        end_time = time.perf_counter()
        
        if code == 0:
            elapsed = end_time - start_time
            _print_success(f"Execution finished successfully.")
            
            if _RICH:
                table = Table(title="Benchmark Results", border_style="cyan")
                table.add_column("Metric", style="white")
                table.add_column("Value", style="bold green")
                table.add_row("Total Time", f"{elapsed:.4f} seconds")
                table.add_row("Engine", "CPython" if no_jit else "LLVM + CPython")
                _console.print(table)
            else:
                _print_info(f"Total Time: {elapsed:.4f} seconds")
        else:
            _print_error("Execution failed during benchmark.")

    # =======================================================================
    # 3. CHECK COMMAND
    # =======================================================================
    @main.command("check")
    @click.argument("filepath", type=click.Path(exists=True))
    def cmd_check(filepath: str) -> None:
        """Syntax-check a .nl file without running it."""
        _print_banner()
        _print_info(f"Analyzing {filepath}...")
        
        parser = NithinParser()
        result = parser.parse_file(filepath)
        
        if not result.success:
            _print_error(f"Failed to parse {filepath}. Found {len(result.errors)} errors:")
            for err in result.errors:
                _print_error(str(err))
            sys.exit(1)
            
        compiler = NithinCompiler()
        syntax_errors = compiler.check_syntax(result.translated_src)
        
        if not syntax_errors:
            _print_success(f"Perfect! No syntax errors found in '{filepath}'.")
        else:
            _print_error(f"Found {len(syntax_errors)} Python syntax errors after translation:")
            for err in syntax_errors:
                _print_error(err)
            sys.exit(1)

    # =======================================================================
    # 4. INFO COMMAND
    # =======================================================================
    @main.command("info")
    @click.argument("filepath", type=click.Path(exists=True))
    def cmd_info(filepath: str) -> None:
        """Show parse metadata and file stats."""
        _print_banner()
        parser = NithinParser()
        
        with open(filepath, "r", encoding="utf-8") as f:
            raw_content = f.read()
            
        result = parser.parse_file(filepath)
        
        if not result.success:
            _print_error("Cannot show info. File has parsing errors.")
            return

        if _RICH:
            table = Table(title=f"File Info: {filepath}", border_style="magenta")
            table.add_column("Property", style="cyan")
            table.add_column("Value", style="white")
            
            table.add_row("Detected Language", f"[bold green]{result.lang_detected.upper()}[/bold green]")
            table.add_row("Original Lines", str(len(raw_content.splitlines())))
            table.add_row("Original Bytes", f"{len(raw_content)} B")
            table.add_row("Translated Lines", str(len(result.translated_src.splitlines())))
            table.add_row("Translation Success", "[bold green]True[/bold green]")
            
            _console.print(table)
        else:
            _print_info(f"File: {filepath}")
            _print_info(f"Language: {result.lang_detected}")
            _print_info(f"Original Lines: {len(raw_content.splitlines())}")

    # =======================================================================
    # 5. NEW COMMAND (Project Scaffolding)
    # =======================================================================
    @main.command("new")
    @click.argument("project_name")
    def cmd_new(project_name: str) -> None:
        """Scaffold a new NithinLang project."""
        _print_banner()
        if os.path.exists(project_name):
            _print_error(f"Directory '{project_name}' already exists.")
            sys.exit(1)
            
        os.makedirs(project_name)
        main_file = os.path.join(project_name, "main.nl")
        readme_file = os.path.join(project_name, "README.md")
        
        # Write default main file
        with open(main_file, "w", encoding="utf-8") as f:
            f.write(textwrap.dedent("""\
                nithin
                lang+ english

                # Welcome to your new NithinLang Project!
                print("====================================")
                print("🚀 NGI EMPIRE - Project Initialized")
                print("====================================")

                # Your logic goes here...
                print("Hello World from NithinLang!")

                end nithin
            """))
            
        # Write default README
        with open(readme_file, "w", encoding="utf-8") as f:
            f.write(f"# {project_name}\n\nBuilt with NithinLang V{__version__} by NGI Empire.\n")

        _print_success(f"Project '{project_name}' created successfully!")
        _print_info(f"Next steps:")
        _print_info(f"  cd {project_name}")
        _print_info(f"  nithin run main.nl")

    # =======================================================================
    # 6. BUILD COMMAND (Windows EXE)
    # =======================================================================
    @main.command("build")
    @click.argument("filepath", type=click.Path(exists=True))
    def cmd_build(filepath: str) -> None:
        """Compile a .nl file into a standalone .EXE executable."""
        _print_banner()
        _print_info(f"Initiating NGI Build System for: {filepath}")
        _print_info("Bundling dependencies and assets for Windows EXE...")
        
        wrapper_name = "ngi_temp_wrapper.py"
        try:
            with open(wrapper_name, "w", encoding="utf-8") as f:
                f.write(f"""
import sys
import os
from nithinlang.parser import NithinParser
from nithinlang.compiler import NithinCompiler

def run_app():
    # Handle PyInstaller temp paths
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    target_nl = os.path.join(base_path, "{filepath}")
    
    parser = NithinParser()
    res = parser.parse_file(target_nl)
    comp = NithinCompiler(jit_threshold=1)
    comp.compile_and_run(res)

if __name__ == "__main__":
    run_app()
                """)
            
            exe_name = os.path.splitext(os.path.basename(filepath))[0]
            cmd = [
                "pyinstaller", "--onefile", "--windowed",
                "--name", exe_name,
                "--add-data", f"{filepath}{';.' if platform.system() == 'Windows' else ':.'}",
                wrapper_name
            ]
            
            subprocess.check_call(cmd)
            _print_success(f"SUCCESS! Standalone EXE created in 'dist/{exe_name}.exe'")
            
        except Exception as e:
            _print_error(f"Build failed: {e}")
            _print_info("Make sure you have pyinstaller installed: pip install pyinstaller")
        finally:
            if os.path.exists(wrapper_name):
                os.remove(wrapper_name)

    # =======================================================================
    # 7. BUILD-APK COMMAND (Android App)
    # =======================================================================
    @main.command("build-apk")
    @click.argument("filepath", type=click.Path(exists=True))
    def cmd_build_apk(filepath: str) -> None:
        """Compile a .nl file into an Android APK using Buildozer (Linux/WSL only)."""
        _print_banner()
        _print_info(f"Initiating NGI Android Build System for: {filepath}")

        is_windows = platform.system() == "Windows"
        is_wsl = "microsoft-standard" in platform.release().lower()

        if is_windows and not is_wsl:
            _print_error("Android APK building requires Linux or WSL (Windows Subsystem for Linux).")
            _print_info("Please open your WSL terminal, run 'pip install buildozer', and try again.")
            return

        _print_info("Preparing Android wrapper...")
        wrapper_name = "main.py"
        try:
            with open(wrapper_name, "w", encoding="utf-8") as f:
                f.write(f"""
import sys
import os
from nithinlang.parser import NithinParser
from nithinlang.compiler import NithinCompiler

def run_app():
    target_nl = "{filepath}"
    if not os.path.exists(target_nl):
        print("Error: Target file not found.")
        sys.exit(1)
    parser = NithinParser()
    res = parser.parse_file(target_nl)
    comp = NithinCompiler(jit_threshold=1)
    comp.compile_and_run(res)

if __name__ == '__main__':
    run_app()
                """)

            _print_info("Checking for buildozer...")
            try:
                subprocess.run(["buildozer", "--version"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            except (subprocess.CalledProcessError, FileNotFoundError):
                _print_error("Buildozer not found! Please install it first: pip install buildozer")
                _print_info("Note: Building APKs requires system dependencies like Cython, OpenJDK, and Android NDK.")
                return

            if not os.path.exists("buildozer.spec"):
                _print_info("Initializing buildozer.spec...")
                subprocess.run(["buildozer", "init"], check=True)
                
                with open("buildozer.spec", "r", encoding="utf-8") as f:
                    spec_content = f.read()
                
                spec_content = spec_content.replace(
                    "requirements = python3,kivy", 
                    "requirements = python3,pygame-ce,nithinlang"
                )
                
                with open("buildozer.spec", "w", encoding="utf-8") as f:
                    f.write(spec_content)

            _print_info("Building Android APK... This will take a while (10-20 mins on first run). Grab a coffee! ☕")
            subprocess.run(["buildozer", "android", "debug"], check=True)
            _print_success("SUCCESS! Android APK created successfully in the 'bin/' directory.")

        except subprocess.CalledProcessError as e:
            _print_error(f"Buildozer process failed with exit code: {e.returncode}")
            _print_info("Check the buildozer logs above for missing dependencies (e.g., SDK/NDK).")
        except Exception as e:
            _print_error(f"Android Build failed: {e}")

    # =======================================================================
    # 8. LANGS COMMAND
    # =======================================================================
    @main.command("langs")
    def cmd_langs() -> None:
        """List supported languages."""
        _print_banner()
        langs = list_languages()
        if _RICH:
            table = Table(title="Supported Languages", border_style="green")
            table.add_column("Language Name", style="cyan", justify="center")
            table.add_column("Status", style="bold green", justify="center")
            
            for lang in langs:
                table.add_row(lang.capitalize(), "Active")
                
            _console.print(table)
        else:
            _print_info(f"Supported Languages: {', '.join(langs)}")

    # =======================================================================
    # 9. AI-STATUS COMMAND
    # =======================================================================
    @main.command("ai-status")
    def cmd_ai_status() -> None:
        """Check AI Brain status."""
        _print_banner()
        if _NLOADER_AVAILABLE:
            loader = NLoader()
            status = loader.get_model_status()
            
            if _RICH:
                table = Table(title="NGI Neural Net Status", border_style="cyan")
                table.add_column("Component", style="white")
                table.add_column("State", style="bold yellow")
                
                table.add_row("Brain Status", f"[bold {'green' if status['status'] == 'Ready' else 'red'}]{status['status']}[/]")
                table.add_row("Model Path", status['path'])
                table.add_row("Inference Engine", status['engine'])
                _console.print(table)
            else:
                _print_success(f"AI Brain Status: {status['status']}")
                _print_info(f"Model Path: {status['path']}")
                _print_info(f"Engine: {status['engine']}")
        else:
            _print_error("N-Loader not available. Ensure llama-cpp-python is installed.")

    # =======================================================================
    # 10. REPL COMMAND (Interactive Shell)
    # =======================================================================
    @main.command("repl")
    def cmd_repl() -> None:
        """Start the interactive NithinLang shell."""
        _print_banner()
        _print_info("Starting NGI Interactive Shell (REPL)... Type 'exit()' to quit.")
        
        try:
            import readline  # Provides history and advanced line editing on Unix
        except ImportError:
            pass
            
        print("\n[ NithinLang Shell Active ]")
        
        while True:
            try:
                line = input("nl> ")
                if line.strip() in ("exit()", "quit()", "exit", "quit"):
                    break
                if not line.strip():
                    continue
                    
                # Create a temporary file string representation
                wrapper = f"nithin\nlang+ english\n{line}\nend nithin"
                
                parser = NithinParser()
                # Hack to parse string directly for REPL
                parser.src = wrapper
                res = parser._parse()
                
                if res.success:
                    compiler = NithinCompiler()
                    compiler._compile_and_execute(res.translated_src)
                else:
                    for err in res.errors:
                        _print_error(str(err))
                        
            except KeyboardInterrupt:
                print("\nType 'exit()' to leave the console.")
            except EOFError:
                break
            except Exception as e:
                _print_error(str(e))
                
        _print_info("Shell closed.")

# ---------------------------------------------------------------------------
# Execution Logic (Runner helper)
# ---------------------------------------------------------------------------

def _execute_file(filepath: str, verbose: bool = False, jit: bool = True, dry_run: bool = False) -> int:
    if not os.path.isfile(filepath):
        if _RICH:
            _print_error(f"File not found: {filepath}")
        else:
            print(f"Error: File not found: {filepath}")
        return 1
    
    parser = NithinParser()
    result = parser.parse_file(filepath)
    
    if not result.success:
        for err in result.errors:
            if _RICH:
                _print_error(str(err))
            else:
                print(str(err))
        return 1
        
    compiler = NithinCompiler(verbose=verbose, jit_threshold=1 if jit else 999999)
    res = compiler.compile_and_run(result)
    return 0 if res.success else 1

if __name__ == "__main__":
    if _CLICK:
        main()
    else:
        print("Error: 'click' library is required to run NithinLang CLI.")
        sys.exit(1)