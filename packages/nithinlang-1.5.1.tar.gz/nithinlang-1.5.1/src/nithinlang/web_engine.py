# src/nithinlang/web_engine.py
"""
NGI Empire - Web Backend Engine
===============================
Allows NithinLang to host high-speed local web servers and REST APIs.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import json

class NGIWebHandler(BaseHTTPRequestHandler):
    routes = {}

    def _set_headers(self, content_type='text/html'):
        self.send_response(200)
        self.send_header('Content-type', content_type)
        self.end_headers()

    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        
        if path in self.routes:
            # Call the NithinLang function mapped to this route
            response = self.routes[path]()
            
            if isinstance(response, dict):
                self._set_headers('application/json')
                self.wfile.write(json.dumps(response).encode('utf-8'))
            else:
                self._set_headers('text/html')
                self.wfile.write(str(response).encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"<h1>404 - NGI Server: Route Not Found</h1>")

class WebEngine:
    def __init__(self):
        self.routes = {}

    def web_route(self, path: str, func) -> None:
        """Map a URL path to a NithinLang function."""
        self.routes[path] = func
        print(f"[NGI Web] Registered Route: {path}")

    def web_start(self, port: int = 8080) -> None:
        """Start the NGI Web Server."""
        NGIWebHandler.routes = self.routes
        server_address = ('0.0.0.0', port)
        httpd = HTTPServer(server_address, NGIWebHandler)
        print(f"\n========================================")
        print(f"🚀 NGI WEB SERVER ONLINE")
        print(f"🌐 Running on: http://localhost:{port}")
        print(f"========================================\n")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n[NGI Web] Server Shutting Down...")
            httpd.server_close()