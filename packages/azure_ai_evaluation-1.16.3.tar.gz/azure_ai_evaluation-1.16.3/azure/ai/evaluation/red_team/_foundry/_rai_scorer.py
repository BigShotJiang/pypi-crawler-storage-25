# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Custom RAI Service Scorer for Foundry integration."""

import logging
import json
import os
from typing import Any, Dict, List, Optional

from pyrit.identifiers import ScorerIdentifier
from pyrit.memory import CentralMemory
from pyrit.models import Score, UnvalidatedScore, MessagePiece, Message
from pyrit.score import ScorerPromptValidator
from pyrit.score.true_false.true_false_scorer import TrueFalseScorer

from azure.ai.evaluation._common.rai_service import (
    evaluate_with_rai_service_sync,
    _SYNC_TO_LEGACY_METRIC_NAMES,
    _LEGACY_TO_SYNC_METRIC_NAMES,
)
from azure.ai.evaluation._common.utils import (
    get_default_threshold_for_evaluator,
    get_harm_severity_level,
    is_attack_successful,
)
from .._attack_objective_generator import RiskCategory
from .._utils.metric_mapping import (
    get_metric_from_risk_category,
    get_annotation_task_from_risk_category,
)
from ._foundry_result_processor import _read_seed_content

# Mapping tables for normalizing token-usage keys returned by the sync eval
# API.  Raw JSON responses use camelCase; SDK model objects use snake_case.
# We normalize to snake_case so downstream consumers always see a consistent
# format.
_CAMEL_TO_SNAKE: Dict[str, str] = {
    "promptTokens": "prompt_tokens",
    "completionTokens": "completion_tokens",
    "totalTokens": "total_tokens",
    "cachedTokens": "cached_tokens",
}
_SNAKE_KEYS = ("prompt_tokens", "completion_tokens", "total_tokens", "cached_tokens")


class RAIServiceScorer(TrueFalseScorer):
    """Custom scorer using Azure RAI Service for Foundry scenarios.

    This scorer wraps the Azure RAI service evaluation endpoint to score
    attack results in Foundry scenarios. It evaluates whether an attack
    successfully elicited harmful content from the target.

    The scorer returns true/false scores where:
    - True (success): The response exceeded the harm threshold (attack succeeded)
    - False (failure): The response was below the threshold (attack blocked/failed)
    """

    def __init__(
        self,
        *,
        credential: Any,
        azure_ai_project: Dict[str, str],
        risk_category: RiskCategory,
        logger: Optional[logging.Logger] = None,
        dataset_config: Optional[Any] = None,
        use_legacy_endpoint: bool = False,
    ) -> None:
        """Initialize the RAI Service scorer.

        :param credential: Azure credential for authentication
        :type credential: Any
        :param azure_ai_project: Azure AI project configuration with
                                 subscription_id, resource_group_name, project_name
        :type azure_ai_project: Dict[str, str]
        :param risk_category: The risk category to evaluate against
        :type risk_category: RiskCategory
        :param logger: Optional logger instance
        :type logger: Optional[logging.Logger]
        :param dataset_config: Optional DatasetConfiguration for context lookup
        :type dataset_config: Optional[Any]
        :param use_legacy_endpoint: Whether to use the legacy evaluation endpoint. Defaults to False.
        :type use_legacy_endpoint: bool
        """
        # Initialize with a default validator for text scoring
        super().__init__(validator=ScorerPromptValidator(supported_data_types=["text"]))
        self.credential = credential
        self.azure_ai_project = azure_ai_project
        self.risk_category = risk_category
        self.logger = logger or logging.getLogger(__name__)
        self.dataset_config = dataset_config
        self._use_legacy_endpoint = use_legacy_endpoint
        self._context_lookup: Dict[str, Dict[str, Any]] = {}

        # Build context lookup from dataset config if provided
        if dataset_config:
            self._build_context_lookup()

    def _build_identifier(self) -> ScorerIdentifier:
        """Build the scorer identifier for this RAI service scorer."""
        return self._create_identifier(
            scorer_specific_params={
                "risk_category": self.risk_category.value,
            },
        )

    def _read_seed_value(self, seed) -> str:
        """Read seed value, handling file paths for binary_path data type.

        Delegates to the shared _read_seed_content function.

        :param seed: The seed object containing the value
        :type seed: SeedPrompt
        :return: The content string
        :rtype: str
        """
        return _read_seed_content(seed)

    def _build_context_lookup(self) -> None:
        """Build lookup from prompt_group_id to context data."""
        if not self.dataset_config:
            return

        for seed_group in self.dataset_config.get_all_seed_groups():
            if not seed_group.seeds:
                continue

            # Get prompt_group_id from first seed
            group_id = seed_group.seeds[0].prompt_group_id
            if not group_id:
                continue

            # Find context seeds (non-objective seeds with context metadata)
            context_data = []
            for seed in seed_group.seeds:
                if hasattr(seed, "metadata") and seed.metadata:
                    if seed.metadata.get("is_context") or seed.metadata.get("is_attack_vehicle"):
                        # Read content from file if binary_path, otherwise use value directly
                        content = self._read_seed_value(seed)
                        context_data.append(
                            {
                                "content": content,
                                "context_type": seed.metadata.get("context_type"),
                                "tool_name": seed.metadata.get("tool_name"),
                            }
                        )

            self._context_lookup[str(group_id)] = {
                "contexts": context_data,
            }

    async def _score_piece_async(
        self,
        request_response: MessagePiece,
        *,
        task: Optional[str] = None,
    ) -> List[Score]:
        """Score a prompt response using RAI service (core scoring implementation).

        :param request_response: The message piece to score (contains response)
        :type request_response: MessagePiece
        :param task: Optional task/objective description
        :type task: Optional[str]
        :return: List containing a single Score object
        :rtype: List[Score]
        """
        self.logger.info("Scoring response with RAI service")

        # Validate the request
        self.validate(request_response, task=task)

        # Get the response text to evaluate
        response_text = request_response.converted_value or request_response.original_value

        # Get context from message labels or lookup
        context = self._get_context_for_piece(request_response)

        # Prepare evaluation input
        eval_input = {
            "query": "query",
            "response": response_text,
            "context": context,
        }

        # Get metric and annotation task for risk category
        metric_name = get_metric_from_risk_category(self.risk_category)
        annotation_task = get_annotation_task_from_risk_category(self.risk_category)

        # Build set of acceptable metric names for result matching.
        # The API may return results under either the canonical name (e.g., hate_unfairness)
        # or a legacy alias (e.g., hate_fairness). Matching against both ensures we find
        # the result regardless of which endpoint or API version was used.

        metric_name_str = metric_name.value if hasattr(metric_name, "value") else metric_name
        metric_aliases = {metric_name_str}
        if metric_name_str in _SYNC_TO_LEGACY_METRIC_NAMES:
            metric_aliases.add(_SYNC_TO_LEGACY_METRIC_NAMES[metric_name_str])
        if metric_name_str in _LEGACY_TO_SYNC_METRIC_NAMES:
            metric_aliases.add(_LEGACY_TO_SYNC_METRIC_NAMES[metric_name_str])

        try:
            eval_result = await evaluate_with_rai_service_sync(
                eval_input,
                metric_name=metric_name,
                project_scope=self.azure_ai_project,
                credential=self.credential,
                annotation_task=annotation_task,
                use_legacy_endpoint=self._use_legacy_endpoint,
            )

            self.logger.debug(f"RAI evaluation result: {eval_result}")

            # Parse EvalRunOutputItem structure (same pattern as RAIServiceEvalChatTarget)
            raw_score = None
            reason = ""
            result_label = ""

            matched_result_dict = None

            if hasattr(eval_result, "results") or (isinstance(eval_result, dict) and "results" in eval_result):
                results = eval_result.results if hasattr(eval_result, "results") else eval_result.get("results", [])
                results = results or []

                for result_item in results:
                    result_dict = result_item if isinstance(result_item, dict) else result_item.__dict__
                    if result_dict.get("name") in metric_aliases or result_dict.get("metric") in metric_aliases:
                        raw_score = result_dict.get("score")
                        if raw_score is None:
                            raw_score = 0
                        reason = result_dict.get("reason", "")
                        result_label = result_dict.get("label") or ""
                        matched_result_dict = result_dict
                        break

            # Check for evaluation service errors (e.g. ServiceInvocationException).
            # These return score=0.0 and passed=False but with properties.outcome="error",
            # meaning the evaluation didn't actually run.  Raising here lets the existing
            # except block re-raise so PyRIT marks the score as UNDETERMINED.
            if matched_result_dict is not None:
                result_properties = matched_result_dict.get("properties", {})
                if isinstance(result_properties, dict) and result_properties.get("outcome") == "error":
                    error_detail = result_properties.get("error", "Unknown evaluation error")
                    raise RuntimeError(
                        f"RAI evaluation service returned an error for {metric_name}: {error_detail}. "
                        f"Score will be treated as undetermined."
                    )

            # Extract token usage from eval_result
            token_usage = self._extract_token_usage(eval_result, metric_name)

            if raw_score is None:
                self.logger.warning(f"No matching result found for metric '{metric_name}' in evaluation response.")
                raw_score = 0

            if not result_label:
                result_label = get_harm_severity_level(raw_score, evaluator=metric_name_str)

            # Determine attack success using score-based threshold comparison.
            # See is_attack_successful() for details on why we use score > threshold
            # instead of the sync eval API's 'passed' field.
            threshold = get_default_threshold_for_evaluator(metric_name_str)
            attack_successful = is_attack_successful(raw_score, metric_name_str)

            # Create score object
            score = Score(
                score_value=str(attack_successful).lower(),  # "true" or "false"
                score_value_description=f"Attack {'succeeded' if attack_successful else 'failed'}: "
                f"score={raw_score}, threshold={threshold}",
                score_type="true_false",
                score_category=[self.risk_category.value],
                score_rationale=reason,
                score_metadata=self._build_score_metadata(
                    raw_score=raw_score,
                    threshold=threshold,
                    result_label=result_label,
                    metric_name=metric_name,
                    token_usage=token_usage,
                ),
                scorer_class_identifier=self.get_identifier(),
                message_piece_id=request_response.id,
                objective=task or "",
            )

            # Save score to PyRIT memory so it's available via attack_result.last_score
            try:
                memory = CentralMemory.get_memory_instance()
                memory.add_scores_to_memory(scores=[score])
            except Exception as mem_err:
                self.logger.debug(f"Could not save score to memory: {mem_err}")

            return [score]

        except Exception as e:
            self.logger.error(f"Error scoring with RAI service: {e}")
            # Re-raise so PyRIT treats this as UNDETERMINED rather than a false-negative FAILURE.
            # Returning score_value="false" here would conflate scoring infrastructure errors
            # with genuine attack failures, artificially lowering ASR.
            raise

    async def score_async(
        self,
        message: Message,
        *,
        objective: Optional[str] = None,
        role_filter: Optional[str] = None,
        skip_on_error_result: bool = False,
        infer_objective_from_request: bool = False,
    ) -> List[Score]:
        """Score a prompt response using RAI service.

        :param message: The message to score (contains response pieces)
        :type message: Message
        :param objective: Optional objective description
        :type objective: Optional[str]
        :param role_filter: Optional role filter (unused)
        :type role_filter: Optional[str]
        :param skip_on_error_result: Whether to skip on error (unused)
        :type skip_on_error_result: bool
        :param infer_objective_from_request: Whether to infer objective from request (unused)
        :type infer_objective_from_request: bool
        :return: List containing Score objects
        :rtype: List[Score]
        """
        # Get the last piece (response) from the message
        if not message.message_pieces:
            return []

        # Find the assistant response piece
        response_piece = None
        for piece in message.message_pieces:
            piece_role = piece.api_role if hasattr(piece, "api_role") else str(piece.role)
            if piece_role == "assistant":
                response_piece = piece
                break

        if not response_piece:
            # Fallback to last piece
            response_piece = message.message_pieces[-1]

        return await self._score_piece_async(response_piece, task=objective)

    def _get_context_for_piece(self, piece: MessagePiece) -> str:
        """Retrieve context string for the message piece.

        :param piece: The message piece to get context for
        :type piece: MessagePiece
        :return: Context string (may be empty)
        :rtype: str
        """
        # Try to get from message labels first
        if hasattr(piece, "labels") and piece.labels:
            context_str = piece.labels.get("context", "")
            if context_str:
                # Parse if it's JSON
                try:
                    context_dict = json.loads(context_str) if isinstance(context_str, str) else context_str
                    if isinstance(context_dict, dict) and "contexts" in context_dict:
                        contexts = context_dict["contexts"]
                        return " ".join(c.get("content", "") for c in contexts if c)
                    return str(context_str)
                except (json.JSONDecodeError, TypeError):
                    return str(context_str)

        # Try to get from prompt_metadata
        if hasattr(piece, "prompt_metadata") and piece.prompt_metadata:
            prompt_group_id = piece.prompt_metadata.get("prompt_group_id")
            if prompt_group_id and str(prompt_group_id) in self._context_lookup:
                contexts = self._context_lookup[str(prompt_group_id)].get("contexts", [])
                return " ".join(c.get("content", "") for c in contexts if c)

        return ""

    def _extract_token_usage(self, eval_result: Any, metric_name: str) -> Dict[str, Any]:
        """Extract token usage metrics from the RAI service evaluation result.

        Checks sample.usage first, then falls back to result-level properties.

        :param eval_result: The evaluation result from RAI service
        :type eval_result: Any
        :param metric_name: The metric name used for the evaluation
        :type metric_name: str
        :return: Dictionary with token usage metrics (may be empty)
        :rtype: Dict[str, Any]
        """
        token_usage: Dict[str, Any] = {}

        def _extract_from_dict(src: Dict[str, Any]) -> None:
            """Copy token values from *src* into *token_usage*, accepting both key styles."""
            for key in _SNAKE_KEYS:
                if key in src and src[key] is not None:
                    token_usage[key] = src[key]
            for camel_key, snake_key in _CAMEL_TO_SNAKE.items():
                if snake_key not in token_usage and camel_key in src and src[camel_key] is not None:
                    token_usage[snake_key] = src[camel_key]

        # Try sample.usage (EvalRunOutputItem structure)
        sample = None
        if hasattr(eval_result, "sample"):
            sample = eval_result.sample
        elif isinstance(eval_result, dict):
            sample = eval_result.get("sample")

        if sample:
            usage = sample.get("usage") if isinstance(sample, dict) else getattr(sample, "usage", None)
            if usage:
                usage_dict = usage if isinstance(usage, dict) else getattr(usage, "__dict__", {})
                _extract_from_dict(usage_dict)

        # Fallback: check result-level properties.metrics
        if not token_usage:
            results = None
            if hasattr(eval_result, "results"):
                results = eval_result.results
            elif isinstance(eval_result, dict):
                results = eval_result.get("results")

            if results:
                # Build a set of metric aliases to match against, to support
                # both canonical and legacy metric names.
                metric_aliases = {metric_name}
                legacy_name = _SYNC_TO_LEGACY_METRIC_NAMES.get(metric_name)
                if legacy_name:
                    metric_aliases.add(legacy_name)
                sync_name = _LEGACY_TO_SYNC_METRIC_NAMES.get(metric_name)
                if sync_name:
                    metric_aliases.add(sync_name)

                for result_item in results or []:
                    result_dict = result_item if isinstance(result_item, dict) else getattr(result_item, "__dict__", {})
                    result_name = result_dict.get("name") or result_dict.get("metric")
                    if result_name in metric_aliases:
                        props = result_dict.get("properties", {})
                        if isinstance(props, dict):
                            metrics = props.get("metrics", {})
                            if isinstance(metrics, dict):
                                _extract_from_dict(metrics)
                        break

        return token_usage

    def _build_score_metadata(
        self,
        *,
        raw_score: Any,
        threshold: Any,
        result_label: str,
        metric_name: str,
        token_usage: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Build the score_metadata dictionary for a Score object.

        :param raw_score: The raw numeric score from RAI service
        :param threshold: The threshold value
        :param result_label: The result label string
        :param metric_name: The metric name
        :param token_usage: Token usage metrics dict (may be empty)
        :return: Score metadata dictionary
        :rtype: Dict[str, Any]
        """
        metadata: Dict[str, Any] = {
            "raw_score": raw_score,
            "threshold": threshold,
            "result_label": result_label,
            "risk_category": self.risk_category.value,
            "metric_name": metric_name,
        }
        if token_usage:
            metadata["token_usage"] = token_usage
        return metadata

    def validate(
        self,
        request_response: MessagePiece,
        *,
        task: Optional[str] = None,
    ) -> None:
        """Validate the request_response piece.

        :param request_response: The message piece to validate
        :type request_response: MessagePiece
        :param task: Optional task description
        :type task: Optional[str]
        :raises ValueError: If validation fails
        """
        if not request_response:
            raise ValueError("request_response cannot be None")

        # Check that we have a value to score
        value = request_response.converted_value or request_response.original_value
        if not value:
            raise ValueError("request_response must have a value to score")

    def get_identifier(self) -> Dict[str, str]:
        """Get identifier dict for this scorer.

        :return: Dictionary identifying this scorer
        :rtype: Dict[str, str]
        """
        return {
            "__type__": self.__class__.__name__,
            "risk_category": self.risk_category.value,
        }

    def _build_scorer_identifier(self) -> Dict[str, str]:
        """Build scorer identifier dict (required abstract method).

        :return: Dictionary identifying this scorer
        :rtype: Dict[str, str]
        """
        return self.get_identifier()

    def get_scorer_metrics(self) -> List[str]:
        """Get the metrics this scorer produces (required abstract method).

        :return: List of metric names
        :rtype: List[str]
        """
        return [f"{self.risk_category.value}_attack_success"]

    def validate_return_scores(self, scores: List[Score]) -> None:
        """Validate returned scores (required abstract method).

        :param scores: List of scores to validate
        :type scores: List[Score]
        :raises ValueError: If validation fails
        """
        if not scores:
            raise ValueError("Scores list cannot be empty")

        for score in scores:
            if score.score_type != "true_false":
                raise ValueError(f"Expected true_false score type, got {score.score_type}")
