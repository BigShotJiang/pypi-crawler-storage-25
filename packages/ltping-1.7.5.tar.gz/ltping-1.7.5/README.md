# ltping — HTTP/DNS/TCP latency tool

**ltping** is a command-line tool for measuring HTTP, DNS, and TCP latency with SLO validation and HDR histogram statistics.

Open-source edition (AGPL-3.0) by [LatenceTech](https://latencetech.com).

## Features

- **HTTP latency** with full percentile distribution (p50, p75, p90, p95, p99, p99.9)
- **DNS resolution** latency measurement
- **ICMP ping** — average, min, max (requires sudo)
- **HDR Histogram** with coordinated omission correction (Gil Tene)
- **SLO validation** — define thresholds in YAML, get pass/fail per site
- **Multi-language** output (EN, FR, ES, DE, JA, ZH, PT)
- **CSV export** with histogram blobs for offline analysis
- **Interval mode** (`--interval`) for continuous monitoring
- **Sites file** (`sites.yaml`) for batch multi-site testing

## Installation

```bash
pip install ltping
```

## Quick start

```bash
# Single site
ltping https://example.com

# Multiple sites from config file
ltping --sites-file sites.yaml

# Continuous monitoring every 60 s
ltping https://example.com --interval 60

# Export to CSV
ltping --sites-file sites.yaml --csv results.csv
```

## Configuration

Create a `ltping.yaml` file:

```yaml
nb_measures: 10
timeout: 10
language: EN
verbosity: full
```

Create a `sites.yaml` file:

```yaml
- url: https://example.com
  slo:
    http_p95_ms: 500
    dns_ms: 100

- url: https://github.com
  slo:
    http_p99_ms: 1000
    http_p95_ms: 500
```

## SLO keys

| Key | Description |
|-----|-------------|
| `http_p50_ms` … `http_p999_ms` | HTTP latency percentiles |
| `http_max_ms` | HTTP worst-case latency |
| `dns_ms` | DNS resolution time |
| `stability_ratio` | p99 / p50 ratio |

## PRO edition

The **ltping-pro** commercial edition adds:
- ICMP jitter and packet loss (+ MOS voice quality score)
- TCP handshake latency
- TLS handshake latency + certificate inspection
- CDN detection (Cloudflare, CloudFront, Fastly, Akamai…)
- MTU path discovery
- Traceroute with per-hop jitter/loss
- MOS voice-quality score (ITU-T G.107)
- Prometheus export
- Webhook alerts
- Baseline comparison

→ [latencetech.com](https://latencetech.com)

## License

AGPL-3.0 — see [LICENSE](LICENSE) for details.
