# -*- coding: utf-8 -*-
"""
ltping OSS core — HTTP/DNS/TCP latency measurement with SLO validation.

OSS edition (AGPL-3.0): HTTP, DNS, SLO, HDR histogram, CSV export.
PRO features (Prometheus, CDN, MTU, MOS, TLS, ICMP, traceroute, webhook):
    pip install ltping-pro  —  https://latencetech.com
"""
import urllib.request
import urllib.error
import socket
import ssl
import ipaddress
import time
import csv
import math
from datetime import datetime
from hdrh.histogram import HdrHistogram
from . import config


# ── Utilities ─────────────────────────────────────────────────────────────────

def est_adresse_ip(hostname: str) -> bool:
    """Return True if hostname is an IPv4 or IPv6 address."""
    try:
        ipaddress.ip_address(hostname)
        return True
    except ValueError:
        return False


def extraire_hostname(url: str) -> str:
    """Extract the hostname from a URL, even if the scheme is malformed."""
    if "//" in url:
        return url.split("//")[-1].split("/")[0]
    return url.split("/")[0]


# ── HDR Histogram ─────────────────────────────────────────────────────────────

# 1µs → 60 s, 3 significant digits
_HDR_MIN_US = 1
_HDR_MAX_US = 60_000_000


def creer_histogramme() -> HdrHistogram:
    return HdrHistogram(_HDR_MIN_US, _HDR_MAX_US, 3)


def hdr_enregistrer(hist: HdrHistogram, ms: float, intervalle_us: int | None = None) -> None:
    """Record a measurement (in ms) into the histogram.

    If intervalle_us is provided, applies coordinated omission correction
    (Gil Tene) via record_corrected_value() — use with --interval mode.
    """
    valeur_us = max(1, int(ms * 1000))
    if intervalle_us:
        hist.record_corrected_value(valeur_us, intervalle_us)
    else:
        hist.record_value(valeur_us)


def hdr_stats(hist: HdrHistogram) -> dict:
    """Extract key statistics from a histogram (in ms)."""
    return {
        "moyenne": round(hist.get_mean_value()              / 1000, 2),
        "min":     round(hist.get_min_value()               / 1000, 2),
        "max":     round(hist.get_max_value()               / 1000, 2),
        "p50":     round(hist.get_value_at_percentile(50)   / 1000, 2),
        "p75":     round(hist.get_value_at_percentile(75)   / 1000, 2),
        "p90":     round(hist.get_value_at_percentile(90)   / 1000, 2),
        "p95":     round(hist.get_value_at_percentile(95)   / 1000, 2),
        "p99":     round(hist.get_value_at_percentile(99)   / 1000, 2),
        "p999":    round(hist.get_value_at_percentile(99.9) / 1000, 2),
        "hdr_encode": hist.encode(),
    }


def _jitter(valeurs: list[float]) -> float | None:
    """Standard deviation of RTT values (network jitter). None if < 2 values."""
    n = len(valeurs)
    if n < 2:
        return None
    moy = sum(valeurs) / n
    return round(math.sqrt(sum((x - moy) ** 2 for x in valeurs) / n), 2)


# ── SLO validation ────────────────────────────────────────────────────────────

# Mapping: SLO key → result dict key
_SLO_VERS_RESULTAT: dict[str, str] = {
    "http_p50_ms":      "p50",
    "http_p75_ms":      "p75",
    "http_p90_ms":      "p90",
    "http_p95_ms":      "p95",
    "http_p99_ms":      "p99",
    "http_p999_ms":     "p999",
    "http_max_ms":      "max",
    "dns_ms":           "dns_moyenne",
    "stability_ratio":  "stability_ratio",
    "icmp_ms":          "icmp_ms",
    "icmp_jitter_ms":   "icmp_jitter_ms",
    "icmp_loss_pct":    "icmp_loss_pct",
    "tcp_ms":           "tcp_ms",
    "tcp_jitter_ms":    "tcp_jitter_ms",
    "tls_ms":           "tls_ms",
    "mos_min":          "mos",
    "http_keepalive_ms": "http_keepalive_ms",
    "nb_hops_max":      "nb_hops",
}

# SLO keys where higher is better (threshold = minimum acceptable value)
_SLO_MIN_KEYS: set[str] = {"mos_min"}

# Display unit per SLO key (default: "ms")
SLO_UNITES: dict[str, str] = {
    "stability_ratio": "x",
    "nb_hops_max":     "hops",
    "mos_min":         "",
}


def verifier_slo(resultat: dict, slo: dict) -> dict:
    """Compare a measured result against an SLO dict.

    Returns {slo_key: {seuil, valeur, ok, op}} for each SLO key.
    Keys in _SLO_MIN_KEYS use >= (higher value = better).
    Unknown SLO keys are silently ignored.
    """
    checks: dict = {}
    for cle_slo, seuil in slo.items():
        cle_res = _SLO_VERS_RESULTAT.get(cle_slo)
        if cle_res is None:
            continue
        valeur = resultat.get(cle_res)
        if valeur is None:
            continue
        if cle_slo in _SLO_MIN_KEYS:
            ok, op = valeur >= seuil, ">="
        else:
            ok, op = valeur <= seuil, "<="
        checks[cle_slo] = {"seuil": seuil, "valeur": valeur, "ok": ok, "op": op}
    return checks


# ── DNS ───────────────────────────────────────────────────────────────────────

def mesurer_dns(hostname: str) -> float | None:
    """Measure DNS resolution time. Returns ms or None on failure."""
    try:
        debut = time.perf_counter()
        socket.getaddrinfo(hostname, None)
        return round((time.perf_counter() - debut) * 1000, 2)
    except socket.gaierror:
        return None


# ── HTTP measurement ──────────────────────────────────────────────────────────

def mesurer_site(
    url: str,
    nb_mesures: int | None = None,
    timeout: int | None = None,
    verify_tls: bool = True,
) -> dict:
    """Measure HTTP + DNS response time for a site.

    Returns a result dict with HDR histogram statistics (p50, p95, p99, …),
    DNS latency, TTFB, and transfer time.
    """
    nb = nb_mesures or config.NB_MEASURES
    to = timeout    or config.TIMEOUT
    hist_http         = creer_histogramme()
    mesures_dns:  list[float] = []
    ttfb_mesures: list[float] = []
    transfert_mesures: list[float] = []

    hostname = extraire_hostname(url)
    ip_mode  = est_adresse_ip(hostname)

    for _ in range(nb):
        if not ip_mode:
            dns_ms = mesurer_dns(hostname)
            if dns_ms is None:
                return {
                    "url": url, "erreur": True, "type_erreur": "dns",
                    "message": f"Cannot resolve hostname: {url}",
                }
            mesures_dns.append(dns_ms)

        debut = time.perf_counter()
        try:
            if not verify_tls:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode    = ssl.CERT_NONE
                resp = urllib.request.urlopen(url, timeout=to, context=ctx)
            else:
                resp = urllib.request.urlopen(url, timeout=to)

            ttfb_ms      = round((time.perf_counter() - debut) * 1000, 2)
            t1           = time.perf_counter()
            resp.read()
            resp.close()
            transfert_ms = round((time.perf_counter() - t1) * 1000, 2)
            ms           = round(ttfb_ms + transfert_ms, 2)

            hdr_enregistrer(hist_http, ms)
            ttfb_mesures.append(ttfb_ms)
            transfert_mesures.append(transfert_ms)

        except urllib.error.URLError as e:
            raison = str(e.reason) if hasattr(e, "reason") else str(e)
            if isinstance(getattr(e, "reason", None), socket.timeout):
                return {"url": url, "erreur": True, "type_erreur": "timeout",
                        "message": f"Request timed out: {url}"}
            return {"url": url, "erreur": True, "type_erreur": "http",
                    "message": f"Network error: {raison}"}
        except Exception as e:
            return {"url": url, "erreur": True, "type_erreur": "inconnu",
                    "message": f"Unknown error: {e}"}

    stats = hdr_stats(hist_http)
    return {
        "url": url, "erreur": False, "type_erreur": None, "message": None,
        "ip_mode": ip_mode,
        **stats,
        "dns_moyenne":  round(sum(mesures_dns) / len(mesures_dns), 2) if mesures_dns else None,
        "dns_min":      min(mesures_dns)  if mesures_dns else None,
        "dns_max":      max(mesures_dns)  if mesures_dns else None,
        "ttfb_ms":      round(sum(ttfb_mesures) / len(ttfb_mesures), 2)           if ttfb_mesures else None,
        "transfert_ms": round(sum(transfert_mesures) / len(transfert_mesures), 2) if transfert_mesures else None,
    }


# ── CSV export ────────────────────────────────────────────────────────────────

def sauvegarder_csv(resultats: list[dict], fichier: str | None = None) -> str:
    """Save a list of results to a CSV file."""
    nom = fichier or "resultats_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".csv"
    fieldnames = [
        "url", "moyenne", "min", "max",
        "p50", "p75", "p90", "p95", "p99", "p999",
        "dns_moyenne", "dns_min", "dns_max",
        "ttfb_p50", "transfert_p50",
        "hdr_encode",
    ]
    with open(nom, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in resultats:
            if not r.get("erreur"):
                writer.writerow({k: r.get(k) for k in fieldnames})
    return nom
