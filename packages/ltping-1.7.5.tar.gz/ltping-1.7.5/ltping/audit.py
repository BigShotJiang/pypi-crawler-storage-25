# -*- coding: utf-8 -*-
"""
ltping — Configuration audit (`--audit`)

Analyses the ltping configuration file and reports issues based on
Gil Tene's principles of correct latency measurement:
  - "You can't average percentiles. Period."
  - "MOST page loads will experience the 99th percentile server response"
  - "Measure what you need to monitor"

Usage (OSS):
    ltping --audit
    ltping --audit --config-file custom.yaml

Usage (PRO):
    ltping-pro --audit
    ltping-pro --audit --config-file custom.yaml

Returns exit code 0 if no errors, 1 if at least one ERROR finding.
"""

from __future__ import annotations

# ── ANSI colours (same convention as main.py / main_pro.py) ──────────────────
VERT   = "\033[92m"
ROUGE  = "\033[91m"
JAUNE  = "\033[93m"
BLEU   = "\033[94m"
RESET  = "\033[0m"
GRAS   = "\033[1m"

# ── SLO key sets ─────────────────────────────────────────────────────────────
_PERCENTILE_KEYS = {
    "http_p50_ms", "http_p75_ms", "http_p90_ms",
    "http_p95_ms", "http_p99_ms", "http_p999_ms",
}
_MAX_KEYS = {"http_max_ms"}
_WEAK_PERCENTILES = {"http_p50_ms", "http_p75_ms"}   # statistically too weak for SLO
_STRONG_PERCENTILES = {"http_p99_ms", "http_p999_ms"}


# ── Finding levels ────────────────────────────────────────────────────────────

OK    = "ok"
WARN  = "warn"
ERROR = "error"


def _finding(level: str, titre: str, detail: str = "") -> dict:
    return {"level": level, "titre": titre, "detail": detail}


# ── Individual checks ─────────────────────────────────────────────────────────

def _check_nb_measures(cfg: dict) -> list[dict]:
    n = cfg.get("nb_measures", 10)
    if n < 10:
        return [_finding(ERROR,
            f"nb_measures={n} — trop faible pour capturer p99 de façon fiable",
            "Recommandé : ≥ 20 mesures pour p99, ≥ 50 pour p99.9. "
            "Avec peu de mesures, les percentiles élevés sont statistiquement instables."
        )]
    if n < 20:
        return [_finding(WARN,
            f"nb_measures={n} — acceptable pour p95, insuffisant pour p99 fiable",
            "Recommandé : ≥ 20 mesures pour p99 stable."
        )]
    return [_finding(OK, f"nb_measures={n} — suffisant pour des percentiles stables")]


def _check_slo(cfg: dict) -> list[dict]:
    findings = []
    slo = cfg.get("slo", {})

    if not slo:
        return [_finding(WARN,
            "Aucun SLO global défini",
            "Sans SLO, ltping mesure mais ne valide rien. "
            "Ajoutez par ex. `slo: {http_p95_ms: 400}` dans ltping.yaml."
        )]

    # Weak percentile as SLO
    weak = set(slo) & _WEAK_PERCENTILES
    for k in weak:
        findings.append(_finding(ERROR,
            f"SLO défini sur {k} — statistiquement insuffisant",
            f"Le {k.replace('http_','').replace('_ms','')} signifie que 50 % ou plus des "
            f"requêtes peuvent dépasser ce seuil sans déclencher de violation. "
            "Utilisez au minimum p95, idéalement p99."
        ))

    # Good percentile coverage
    strong = set(slo) & _STRONG_PERCENTILES
    if strong:
        findings.append(_finding(OK,
            f"SLO défini sur {', '.join(sorted(strong))} — bonne couverture de la queue"
        ))
    elif not weak:
        findings.append(_finding(WARN,
            "Aucun SLO sur p99 ou p99.9",
            "Les événements rares (1 % des requêtes) ne sont pas surveillés. "
            "Ajoutez `http_p99_ms` à votre SLO."
        ))

    # Missing Max
    if not (set(slo) & _MAX_KEYS):
        findings.append(_finding(WARN,
            "Aucun SLO sur le Max (http_max_ms)",
            "Les pics extrêmes sont invisibles. "
            "Un seul événement à 10× la médiane peut être révélateur d'un problème grave."
        ))
    else:
        findings.append(_finding(OK, "SLO sur le Max défini — pics extrêmes surveillés"))

    # Timeout vs SLO threshold
    timeout_ms = cfg.get("timeout", 10) * 1000
    for k, seuil in slo.items():
        if k in _PERCENTILE_KEYS and seuil > timeout_ms:
            findings.append(_finding(ERROR,
                f"SLO {k}={seuil} ms > timeout={timeout_ms} ms — violation impossible à détecter",
                "Le timeout coupe la requête avant d'atteindre le seuil SLO. "
                "Réduisez le SLO ou augmentez le timeout."
            ))
        elif k in _PERCENTILE_KEYS and seuil > timeout_ms * 0.8:
            findings.append(_finding(WARN,
                f"SLO {k}={seuil} ms proche du timeout ({timeout_ms} ms)",
                "Les violations proches du timeout risquent d'être masquées. "
                "Laissez une marge d'au moins 20 % entre le SLO et le timeout."
            ))

    return findings


def _check_requests_per_hour(cfg: dict) -> list[dict]:
    rph = cfg.get("requests_per_hour")
    if not rph:
        return [_finding(WARN,
            "requests_per_hour non défini",
            "Sans ce paramètre, ltping ne peut pas traduire les percentiles en "
            "utilisateurs affectés (ex. p99 = 1 % → ~100 users/h si 10 000 req/h). "
            "Ajoutez `requests_per_hour: 10000` dans ltping.yaml."
        )]
    slo = cfg.get("slo", {})
    findings = []
    for k in _PERCENTILE_KEYS:
        if k in slo:
            pct_str = k.replace("http_", "").replace("_ms", "")
            pct_val = {
                "p50": 50.0, "p75": 25.0, "p90": 10.0,
                "p95": 5.0,  "p99": 1.0,  "p999": 0.1,
            }.get(pct_str, 0)
            affected = int(rph * pct_val / 100)
            findings.append(_finding(OK,
                f"{pct_str} → ~{affected:,} utilisateurs/heure affectés "
                f"({pct_val}% × {rph:,} req/h)"
            ))
    if not findings:
        findings.append(_finding(OK,
            f"requests_per_hour={rph:,} défini — traduction percentiles → utilisateurs active"
        ))
    return findings


def _check_hdr(cfg: dict) -> list[dict]:
    # HDR histogram is always active in ltping — confirm to user
    return [_finding(OK,
        "HDR histogram actif — coordinated omission corrigé (Gil Tene / hdrhistogram)"
    )]


def _check_sites(cfg: dict) -> list[dict]:
    sites = cfg.get("sites", [])
    if not sites:
        return [_finding(WARN,
            "Aucun site configuré dans ltping.yaml",
            "Ajoutez des sites sous la clé `sites:` ou passez des URLs en argument."
        )]
    return [_finding(OK, f"{len(sites)} site(s) configuré(s)")]


def _check_language(cfg: dict) -> list[dict]:
    lang = cfg.get("language", "EN").upper()
    valid = {"FR", "EN", "ES", "DE", "JA", "ZH", "PT"}
    if lang not in valid:
        return [_finding(WARN,
            f"Langue inconnue : '{lang}'",
            f"Langues supportées : {', '.join(sorted(valid))}. Fallback sur FR."
        )]
    return []   # langue valide : pas besoin de polluer le rapport


# ── Main audit function ───────────────────────────────────────────────────────

def auditer(cfg: dict) -> list[dict]:
    """Run all audit checks on a config dict. Returns list of findings."""
    findings = []
    findings += _check_hdr(cfg)
    findings += _check_nb_measures(cfg)
    findings += _check_sites(cfg)
    findings += _check_slo(cfg)
    findings += _check_requests_per_hour(cfg)
    findings += _check_language(cfg)
    return findings


# ── Report formatter ──────────────────────────────────────────────────────────

def afficher_rapport(findings: list[dict], cfg: dict, config_file: str | None) -> int:
    """
    Print the audit report to stdout.
    Returns exit code: 0 = no errors, 1 = at least one ERROR.
    """
    errors = [f for f in findings if f["level"] == ERROR]
    warns  = [f for f in findings if f["level"] == WARN]
    oks    = [f for f in findings if f["level"] == OK]

    sep = "─" * 58

    print(f"\n{GRAS}── ltping --audit {sep[:41]}{RESET}")
    print()

    cfg_file  = config_file or "ltping.yaml (défaut)"
    nb        = cfg.get("nb_measures", "?")
    timeout   = cfg.get("timeout", "?")
    n_sites   = len(cfg.get("sites", []))
    slo_keys  = list(cfg.get("slo", {}).keys())

    print(f"  Fichier config  : {BLEU}{cfg_file}{RESET}")
    print(f"  nb_measures     : {nb}")
    print(f"  timeout         : {timeout}s")
    print(f"  Sites           : {n_sites}")
    print(f"  SLO             : {', '.join(slo_keys) if slo_keys else '—'}")
    print()

    icons = {OK: f"{VERT}✓{RESET}", WARN: f"{JAUNE}⚠{RESET}", ERROR: f"{ROUGE}✗{RESET}"}

    for f in findings:
        icon = icons[f["level"]]
        print(f"  {icon}  {f['titre']}")
        if f["detail"]:
            # Indent detail lines
            for line in f["detail"].split(". "):
                line = line.strip()
                if line:
                    print(f"      {GRAS}→{RESET} {line}.")
        print()

    # Summary line
    parts = []
    if errors: parts.append(f"{ROUGE}{len(errors)} erreur(s){RESET}")
    if warns:  parts.append(f"{JAUNE}{len(warns)} avertissement(s){RESET}")
    if oks:    parts.append(f"{VERT}{len(oks)} OK{RESET}")

    verdict = " · ".join(parts)
    print(f"  {GRAS}Bilan :{RESET} {verdict}")
    print(f"\n{sep}\n")

    return 1 if errors else 0
