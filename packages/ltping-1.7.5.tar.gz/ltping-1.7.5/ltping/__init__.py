"""
ltping — HTTP/DNS/TCP latency tool with SLO validation.
Open-source edition (AGPL-3.0) by LatenceTech.

PRO features (Prometheus, CDN, MTU, MOS, webhook, traceroute detail):
    pip install ltping-pro
    https://latencetech.com
"""
__version__ = "1.7.5"
__edition__ = "OSS"
