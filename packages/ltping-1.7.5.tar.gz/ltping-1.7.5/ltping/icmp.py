# -*- coding: utf-8 -*-
"""
ltping OSS — Basic ICMP ping measurement.

Returns average, min, max, and sample count.
Jitter and packet loss are PRO features (ltping-pro).

Requires raw socket access:
  - macOS/Linux: run with sudo or grant CAP_NET_RAW
  - Windows: not supported (uses system ping binary)
"""
import re
import subprocess


def mesurer_icmp(hostname: str, nb_mesures: int = 5) -> dict | None:
    """Send ICMP pings and return basic latency statistics.

    Returns:
        {moyenne, min, max, nb, _rtts}  — or None if ping fails.
        _rtts is a list of raw RTT values (ms), used internally by ltping-engine PRO
        to compute jitter and packet loss without running ping a second time.
    """
    try:
        result = subprocess.run(
            ["ping", "-c", str(nb_mesures), hostname],
            capture_output=True, text=True, timeout=nb_mesures * 3 + 5,
        )
        rtts = [
            float(m.group(1))
            for line in result.stdout.splitlines()
            for m in [re.search(r"time[=<](\d+\.?\d*)\s*ms", line)]
            if m
        ]
        if not rtts:
            return None
        return {
            "moyenne": round(sum(rtts) / len(rtts), 2),
            "min":     round(min(rtts), 2),
            "max":     round(max(rtts), 2),
            "nb":      len(rtts),
            "_rtts":   rtts,           # consumed by ltping-engine PRO
        }
    except Exception:
        return None
