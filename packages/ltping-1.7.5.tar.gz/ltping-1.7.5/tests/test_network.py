# -*- coding: utf-8 -*-
"""
ltping OSS — network tests (~20-40 s, real HTTP/DNS calls).

These tests require a working internet connection.
Run with:  pytest tests/test_network.py   (from packages/ltping/)
"""
import os
import pytest
from ltping.core import (
    mesurer_site,
    mesurer_dns,
    verifier_slo,
    creer_histogramme,
    hdr_enregistrer,
    hdr_stats,
)


# ── DNS ───────────────────────────────────────────────────────────────────────

def test_mesurer_dns_ok():
    """DNS resolution for a public hostname must succeed."""
    ms = mesurer_dns("google.com")
    assert ms is not None
    assert ms > 0

def test_mesurer_dns_hostname_invalide():
    """DNS resolution for an invalid hostname must return None."""
    assert mesurer_dns("ce-domaine-nexiste-absolument-pas-ltping.invalid") is None

def test_mesurer_dns_positive():
    ms = mesurer_dns("cloudflare.com")
    assert isinstance(ms, float) and ms >= 0


# ── HTTP measurement ──────────────────────────────────────────────────────────

def test_mesurer_site_ok():
    """A successful measurement must return expected keys without error."""
    r = mesurer_site("https://example.com", nb_mesures=3)
    assert not r.get("erreur"), r.get("message")
    assert r["url"] == "https://example.com"
    for key in ("p50", "p75", "p90", "p95", "p99", "p999", "moyenne", "min", "max"):
        assert key in r and r[key] is not None, f"Missing key: {key}"

def test_mesurer_site_hdr_encode():
    """Result must include a non-empty hdr_encode blob."""
    r = mesurer_site("https://example.com", nb_mesures=2)
    assert not r.get("erreur")
    assert "hdr_encode" in r and len(r["hdr_encode"]) > 0

def test_mesurer_site_dns():
    """DNS latency must be populated for domain names."""
    r = mesurer_site("https://example.com", nb_mesures=2)
    assert not r.get("erreur")
    assert r.get("dns_moyenne") is not None and r["dns_moyenne"] > 0

def test_mesurer_site_no_dns_for_ip():
    """IP-mode sites must not populate dns_moyenne."""
    r = mesurer_site("http://93.184.216.34", nb_mesures=1)
    # IP may be unreachable in CI — skip on error, only check dns field on success
    if not r.get("erreur"):
        assert r.get("ip_mode") is True
        assert r.get("dns_moyenne") is None

def test_mesurer_site_ttfb():
    """TTFB and transfer times must be present on success."""
    r = mesurer_site("https://example.com", nb_mesures=2)
    if not r.get("erreur"):
        assert r.get("ttfb_ms") is not None
        assert r.get("transfert_ms") is not None

def test_mesurer_site_percentiles_croissants():
    """Percentiles must be monotonically non-decreasing."""
    r = mesurer_site("https://example.com", nb_mesures=5)
    assert not r.get("erreur")
    assert r["p50"] <= r["p75"] <= r["p90"] <= r["p95"] <= r["p99"] <= r["p999"]

def test_mesurer_site_erreur_dns():
    """Unknown domain must return erreur=True with type_erreur='dns'."""
    r = mesurer_site("https://ce-domaine-nexiste-absolument-pas-ltping.invalid", nb_mesures=1)
    assert r["erreur"] is True
    assert r["type_erreur"] == "dns"

def test_mesurer_site_timeout():
    """Very short timeout on a slow host should return a timeout error or succeed quickly."""
    r = mesurer_site("https://example.com", nb_mesures=1, timeout=1)
    # Accept either success (fast CDN) or timeout error
    if r.get("erreur"):
        assert r["type_erreur"] in ("timeout", "http", "inconnu")

def test_mesurer_site_plusieurs_mesures():
    """With multiple measures, max >= p99 >= p50 >= min."""
    r = mesurer_site("https://example.com", nb_mesures=5)
    assert not r.get("erreur")
    assert r["min"] <= r["p50"] <= r["p99"] <= r["max"]

def test_mesurer_site_github():
    """Measurement on github.com must succeed without error."""
    r = mesurer_site("https://github.com", nb_mesures=3)
    assert not r.get("erreur"), r.get("message")


# ── SLO integration ───────────────────────────────────────────────────────────

def test_slo_integration_example_com():
    """A generous SLO on example.com should pass."""
    r = mesurer_site("https://example.com", nb_mesures=3)
    assert not r.get("erreur")
    slo = {"http_p95_ms": 5000, "dns_ms": 2000}
    checks = verifier_slo(r, slo)
    assert checks["http_p95_ms"]["ok"], f"p95={r['p95']} ms exceeds 5000 ms"
    assert checks["dns_ms"]["ok"], f"dns={r['dns_moyenne']} ms exceeds 2000 ms"

def test_slo_violation_seuil_impossible():
    """A 0 ms threshold must always fail."""
    r = mesurer_site("https://example.com", nb_mesures=2)
    if not r.get("erreur"):
        checks = verifier_slo(r, {"http_p50_ms": 0})
        assert not checks["http_p50_ms"]["ok"]
