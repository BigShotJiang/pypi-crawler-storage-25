# -*- coding: utf-8 -*-
"""
ltping OSS — unit tests (no network, < 3 s).

All tests use pure logic, tmp_path fixtures, or mocked calls.
Run with:  pytest tests/test_unit.py   (from packages/ltping/)
"""
import os
import pytest
from ltping.core import (
    est_adresse_ip,
    extraire_hostname,
    creer_histogramme,
    hdr_enregistrer,
    hdr_stats,
    _jitter,
    verifier_slo,
    sauvegarder_csv,
    _SLO_VERS_RESULTAT,
)
from ltping.i18n import get_translator, _TRANSLATIONS


# ── i18n ──────────────────────────────────────────────────────────────────────

def test_i18n_fr_header():
    t = get_translator("FR")
    assert "essais" in t("header", ver="1.7.0", n=5, cfg="ltping.yaml")

def test_i18n_en_header():
    t = get_translator("EN")
    assert "attempts" in t("header", ver="1.7.0", n=5, cfg="ltping.yaml")

def test_i18n_langue_inconnue_repli_fr():
    """Une langue inconnue doit utiliser le français par défaut."""
    t = get_translator("ZZ")
    assert "essais" in t("header", ver="1.7.0", n=5, cfg="ltping.yaml")

def test_i18n_es_header():
    t = get_translator("ES")
    assert "intentos" in t("header", ver="1.7.0", n=5, cfg="ltping.yaml")

def test_i18n_de_header():
    t = get_translator("DE")
    assert "Versuche" in t("header", ver="1.7.0", n=5, cfg="ltping.yaml")

def test_i18n_ja_header():
    t = get_translator("JA")
    assert "測定中" in t("header", ver="1.7.0", n=5, cfg="ltping.yaml")

def test_i18n_zh_header():
    t = get_translator("ZH")
    assert "测量" in t("header", ver="1.7.0", n=5, cfg="ltping.yaml")

def test_i18n_pt_header():
    t = get_translator("PT")
    assert "tentativas" in t("header", ver="1.7.0", n=5, cfg="ltping.yaml")

def test_i18n_cles_identiques():
    """Toutes les langues doivent avoir exactement les mêmes clés."""
    cles_fr = set(_TRANSLATIONS["FR"].keys())
    for lang in ("EN", "ES", "DE", "JA", "ZH", "PT"):
        assert cles_fr == set(_TRANSLATIONS[lang].keys()), \
            f"Clés manquantes ou en trop pour {lang}"


# ── Utilities ─────────────────────────────────────────────────────────────────

def test_est_adresse_ip_v4():
    assert est_adresse_ip("8.8.8.8") is True

def test_est_adresse_ip_v6():
    assert est_adresse_ip("2001:4860:4860::8888") is True

def test_est_adresse_ip_hostname():
    assert est_adresse_ip("google.com") is False

def test_est_adresse_ip_invalide():
    assert est_adresse_ip("192.168.x.x") is False

def test_extraire_hostname_https():
    assert extraire_hostname("https://example.com/path") == "example.com"

def test_extraire_hostname_http():
    assert extraire_hostname("http://example.com") == "example.com"

def test_extraire_hostname_sans_scheme():
    assert extraire_hostname("example.com/path") == "example.com"


# ── HDR Histogram ─────────────────────────────────────────────────────────────

def test_hdr_stats_percentiles_croissants():
    hist = creer_histogramme()
    for ms in [10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0, 100.0]:
        hdr_enregistrer(hist, ms)
    s = hdr_stats(hist)
    assert s["p50"] <= s["p75"] <= s["p90"] <= s["p95"] <= s["p99"] <= s["p999"]

def test_hdr_stats_valeur_unique():
    """Avec une seule mesure, p50 == p95 == p99."""
    hist = creer_histogramme()
    hdr_enregistrer(hist, 42.5)
    s = hdr_stats(hist)
    assert s["p50"] == s["p95"] == s["p99"]

def test_hdr_stats_contient_encode():
    hist = creer_histogramme()
    hdr_enregistrer(hist, 50.0)
    s = hdr_stats(hist)
    assert "hdr_encode" in s and len(s["hdr_encode"]) > 0

def test_hdr_enregistrer_count_simple():
    hist = creer_histogramme()
    hdr_enregistrer(hist, 100.0)
    hdr_enregistrer(hist, 200.0)
    assert hist.get_total_count() == 2

def test_hdr_enregistrer_correction_insere_extras():
    """La correction CO doit insérer > 1 entrée pour une mesure très lente."""
    hist = creer_histogramme()
    hdr_enregistrer(hist, 3500.0, intervalle_us=1_000_000)
    assert hist.get_total_count() >= 3

def test_hdr_correction_eleve_p99():
    """Avec correction, p99 >= version brute sur les mêmes données."""
    hist_brut = creer_histogramme()
    hist_corr = creer_histogramme()
    mesures   = [200.0] * 9 + [3000.0]
    for ms in mesures:
        hdr_enregistrer(hist_brut, ms)
        hdr_enregistrer(hist_corr, ms, intervalle_us=500_000)
    assert hdr_stats(hist_corr)["p99"] >= hdr_stats(hist_brut)["p99"]


# ── Jitter ────────────────────────────────────────────────────────────────────

def test_jitter_identiques():
    assert _jitter([10.0, 10.0, 10.0]) == 0.0

def test_jitter_deux_valeurs():
    assert _jitter([10.0, 20.0]) == 5.0

def test_jitter_une_valeur():
    assert _jitter([10.0]) is None

def test_jitter_vide():
    assert _jitter([]) is None

def test_jitter_insensible_ordre():
    assert _jitter([10.0, 20.0, 30.0]) == _jitter([30.0, 10.0, 20.0])


# ── SLO verification ──────────────────────────────────────────────────────────

def test_verifier_slo_respect():
    res = {"p50": 100.0, "p95": 200.0, "dns_moyenne": 10.0}
    slo = {"http_p50_ms": 200, "http_p95_ms": 400, "dns_ms": 50}
    assert all(c["ok"] for c in verifier_slo(res, slo).values())

def test_verifier_slo_violation():
    res = {"p50": 250.0, "p95": 200.0, "dns_moyenne": 10.0}
    slo = {"http_p50_ms": 200, "http_p95_ms": 400, "dns_ms": 50}
    checks = verifier_slo(res, slo)
    assert not checks["http_p50_ms"]["ok"]
    assert checks["http_p95_ms"]["ok"]
    assert checks["dns_ms"]["ok"]

def test_verifier_slo_stability_ratio():
    res = {"stability_ratio": 2.0}
    assert verifier_slo(res, {"stability_ratio": 3.0})["stability_ratio"]["ok"]
    assert not verifier_slo(res, {"stability_ratio": 1.5})["stability_ratio"]["ok"]

def test_verifier_slo_cle_inconnue():
    assert verifier_slo({"p50": 100.0}, {"cle_inexistante": 999}) == {}

def test_verifier_slo_vide():
    assert verifier_slo({"p50": 100.0}, {}) == {}

def test_verifier_slo_mos_min_ok():
    """mos_min : MOS >= seuil → ok=True, op='>='."""
    checks = verifier_slo({"mos": 4.1}, {"mos_min": 4.0})
    assert checks["mos_min"]["ok"] is True
    assert checks["mos_min"]["op"] == ">="

def test_verifier_slo_mos_min_violation():
    checks = verifier_slo({"mos": 3.5}, {"mos_min": 4.0})
    assert checks["mos_min"]["ok"] is False

def test_verifier_slo_op_standard():
    checks = verifier_slo({"p50": 100.0, "dns_moyenne": 30.0},
                          {"http_p50_ms": 200, "dns_ms": 50})
    assert checks["http_p50_ms"]["op"] == "<="
    assert checks["dns_ms"]["op"] == "<="

def test_verifier_slo_http_max_ms():
    assert "http_max_ms" in _SLO_VERS_RESULTAT
    assert _SLO_VERS_RESULTAT["http_max_ms"] == "max"

def test_verifier_slo_http_max_ms_ok():
    assert verifier_slo({"max": 150.0}, {"http_max_ms": 200})["http_max_ms"]["ok"]

def test_verifier_slo_http_max_ms_violation():
    assert not verifier_slo({"max": 500.0}, {"http_max_ms": 200})["http_max_ms"]["ok"]

def test_verifier_slo_valeur_absente_ignoree():
    """Une clé SLO dont la valeur est absente du résultat est ignorée."""
    checks = verifier_slo({}, {"http_p50_ms": 200})
    assert checks == {}


# ── Config / YAML loading ─────────────────────────────────────────────────────

def test_config_yaml(tmp_path):
    from ltping import config as _config
    f = tmp_path / "ltping.yaml"
    f.write_text("nb_measures: 5\ntimeout: 3\nlanguage: EN\n", encoding="utf-8")
    data = _config.charger(str(f))
    assert data["nb_measures"] == 5
    assert data["timeout"] == 3
    assert data["language"] == "EN"

def test_config_yaml_backward_compat(tmp_path):
    """Anciennes clés nb_mesures et langue doivent être migrées."""
    from ltping import config as _config
    f = tmp_path / "ltping.yaml"
    f.write_text("nb_mesures: 7\nlangue: FR\n", encoding="utf-8")
    data = _config.charger(str(f))
    assert data["nb_measures"] == 7
    assert data["language"] == "FR"

def test_config_fichier_absent_explicite(tmp_path):
    from ltping import config as _config
    with pytest.raises(FileNotFoundError):
        _config.charger(str(tmp_path / "inexistant.yaml"))

def test_config_defaut_si_absent():
    """Sans fichier, charger() retourne les valeurs par défaut."""
    from ltping import config as _config
    import unittest.mock as mock
    with mock.patch("os.path.exists", return_value=False):
        data = _config.charger()
    assert data["nb_measures"] == 10

def test_ltping_yaml_existe():
    assert os.path.exists("ltping.yaml"), "ltping.yaml non trouvé à la racine du package"

def test_ltping_yaml_structure():
    from ltping import config as _config
    data = _config.charger("ltping.yaml")
    assert isinstance(data.get("nb_measures"), int) and data["nb_measures"] > 0
    assert isinstance(data.get("timeout"), int)     and data["timeout"] > 0
    assert isinstance(data.get("language"), str)

def test_sites_yaml_existe():
    assert os.path.exists("sites.yaml"), "sites.yaml non trouvé à la racine du package"

def test_sites_yaml_structure():
    from ltping import config as _config
    sites = _config.charger_sites("sites.yaml")
    assert isinstance(sites, list) and len(sites) > 0
    for site in sites:
        assert "url" in site
        assert site["url"].startswith(("http://", "https://"))

_CLES_SLO_VALIDES = {
    "http_p50_ms", "http_p75_ms", "http_p90_ms",
    "http_p95_ms", "http_p99_ms", "http_p999_ms", "http_max_ms",
    "dns_ms", "stability_ratio", "icmp_ms", "icmp_jitter_ms", "icmp_loss_pct",
    "tcp_ms", "tcp_jitter_ms", "tls_ms",
    "http_keepalive_ms", "nb_hops_max", "mos_min",
}

def test_sites_yaml_slo_cles():
    from ltping import config as _config
    sites = _config.charger_sites("sites.yaml")
    for site in sites:
        slo = site.get("slo") or {}
        unknown = set(slo.keys()) - _CLES_SLO_VALIDES
        assert not unknown, f"Clés SLO inconnues pour {site['url']}: {unknown}"
        for key, val in slo.items():
            assert isinstance(val, (int, float)) and val > 0

def test_charger_sites_liste_directe(tmp_path):
    from ltping import config as _config
    f = tmp_path / "sites.yaml"
    f.write_text("- url: https://example.com\n- url: https://test.com\n", encoding="utf-8")
    sites = _config.charger_sites(str(f))
    assert len(sites) == 2
    assert sites[0]["url"] == "https://example.com"

def test_charger_sites_chaine_simple(tmp_path):
    """Une entrée chaîne simple doit être convertie en dict {url: ...}."""
    from ltping import config as _config
    f = tmp_path / "sites.yaml"
    f.write_text("- https://example.com\n", encoding="utf-8")
    sites = _config.charger_sites(str(f))
    assert sites[0] == {"url": "https://example.com"}

def test_charger_sites_absent_sans_chemin():
    from ltping import config as _config
    import unittest.mock as mock
    with mock.patch("os.path.exists", return_value=False):
        assert _config.charger_sites() == []

def test_charger_sites_explicite_absent(tmp_path):
    from ltping import config as _config
    with pytest.raises(FileNotFoundError):
        _config.charger_sites(str(tmp_path / "inexistant.yaml"))

def test_charger_sites_format_invalide(tmp_path):
    from ltping import config as _config
    f = tmp_path / "bad.yaml"
    f.write_text("sites:\n  - url: https://example.com\n", encoding="utf-8")
    with pytest.raises(ValueError):
        _config.charger_sites(str(f))


# ── CSV export ────────────────────────────────────────────────────────────────

def test_sauvegarder_csv(tmp_path):
    hist = creer_histogramme()
    hdr_enregistrer(hist, 100.0)
    stats = hdr_stats(hist)
    resultats = [{
        "url": "https://test.com", "erreur": False,
        "type_erreur": None, "message": None,
        "dns_moyenne": 8.5, "dns_min": 7.1, "dns_max": 9.8,
        **stats,
    }]
    fichier = sauvegarder_csv(resultats, str(tmp_path / "test.csv"))
    assert os.path.exists(fichier)
    contenu = open(fichier).read()
    for col in ["url", "p50", "p95", "p99", "hdr_encode", "dns_moyenne"]:
        assert col in contenu, f"Colonne manquante : {col}"
    assert "https://test.com" in contenu

def test_sauvegarder_csv_ignore_erreurs(tmp_path):
    """Les résultats en erreur ne doivent pas apparaître dans le CSV."""
    resultats = [{"url": "https://bad.com", "erreur": True}]
    fichier = sauvegarder_csv(resultats, str(tmp_path / "vide.csv"))
    contenu = open(fichier).read()
    assert "bad.com" not in contenu

def test_sauvegarder_csv_plusieurs_sites(tmp_path):
    """Deux sites doivent produire deux lignes."""
    hist = creer_histogramme()
    hdr_enregistrer(hist, 50.0)
    stats = hdr_stats(hist)
    resultats = [
        {"url": "https://alpha.com", "erreur": False, "type_erreur": None, "message": None,
         "dns_moyenne": 5.0, "dns_min": 4.0, "dns_max": 6.0, **stats},
        {"url": "https://beta.com",  "erreur": False, "type_erreur": None, "message": None,
         "dns_moyenne": 6.0, "dns_min": 5.0, "dns_max": 7.0, **stats},
    ]
    fichier = sauvegarder_csv(resultats, str(tmp_path / "deux.csv"))
    lignes = open(fichier).readlines()
    assert len(lignes) == 3  # header + 2 lignes


# ── Compound latency (page-level probability) ─────────────────────────────────

def test_compound_p50_10_ressources():
    """P(≥1 sur 10 ressources dépasse P50) = 1 - 0.5^10 ≈ 99.9%."""
    prob = (1.0 - 0.50 ** 10) * 100.0
    assert abs(prob - (1 - 0.5 ** 10) * 100) < 0.001

def test_compound_p99_40_ressources():
    """40 ressources + P99 → ~33% de probabilité de dépassement."""
    prob = (1.0 - 0.99 ** 40) * 100.0
    assert 32 < prob < 34

def test_compound_p999_40_ressources():
    """40 ressources + P99.9 → ~3.9% de probabilité."""
    prob = (1.0 - 0.999 ** 40) * 100.0
    assert 3 < prob < 5

def test_compound_probabilite_croissante_avec_n():
    """Plus il y a de ressources, plus la probabilité de dépassement augmente."""
    p_ok = 0.99
    probs = [(1.0 - p_ok ** n) for n in [1, 5, 10, 50]]
    assert probs == sorted(probs)


# ── User impact (requests/hour → users affected) ──────────────────────────────

def test_impact_users_p99():
    """P99 avec 10 000 req/h → ~100 utilisateurs affectés."""
    assert max(1, round((100.0 - 99.0) / 100.0 * 10_000)) == 100

def test_impact_users_p999():
    """P99.9 avec 10 000 req/h → ~10 utilisateurs affectés."""
    assert max(1, round((100.0 - 99.9) / 100.0 * 10_000)) == 10

def test_impact_users_minimum_un():
    """Même avec p999 et peu de trafic, le minimum est 1 utilisateur."""
    assert max(1, round((100.0 - 99.9) / 100.0 * 5)) == 1
