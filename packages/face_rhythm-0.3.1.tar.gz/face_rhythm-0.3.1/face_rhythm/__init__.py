"""face-rhythm: extract and decompose rhythmic facial movements from video.

The top-level package eagerly imports its submodules so that the public API
(e.g. ``face_rhythm.point_tracking``) is available directly after
``import face_rhythm``. The version string is kept in :mod:`face_rhythm._version`
so build-tooling and CI can read it without triggering the heavy imports here
(``torch``, ``cv2``).
"""

## On macOS, multiple deps (pytorch, opencv, etc.) ship their own
## libomp.dylib; importing them in the same process triggers OMP Error #15
## and aborts. All copies are LLVM libomp (same ABI), so allowing duplicates
## is safe in practice. Set before any heavy imports. Users can override by
## exporting KMP_DUPLICATE_LIB_OK=FALSE before importing face_rhythm.
import os as _os
_os.environ.setdefault('KMP_DUPLICATE_LIB_OK', 'TRUE')

from face_rhythm._version import __version__

## Import packages
__all__=[
    # 'analysis',
    # 'comparisons',
    'decomposition',
    'h5_handling',
    'helpers',
    # 'neural',
    # 'optic_flow',
    'pipelines',
    'point_tracking',
    'project',
    'rois',
    'spectral_analysis',
    'util',
    'visualization',
    'data_importing',
    'alignment',
    'alignment_multisession',
    # 'tests',
]

import torch  ## For some reason, it crashes if I don't import torch before other packages... RH 20221128


## Prepare cv2.imshow
import importlib.metadata
installed_packages = {dist.metadata['Name'] for dist in importlib.metadata.distributions()}
has_cv2_headless = 'opencv-contrib-python-headless' in installed_packages
has_cv2_normal = 'opencv-contrib-python' in installed_packages
if has_cv2_normal and not has_cv2_headless:
    run_cv2_imshow = True
elif has_cv2_headless and not has_cv2_normal:
    run_cv2_imshow = False
elif has_cv2_headless and has_cv2_normal:
    raise ValueError("Both opencv-contrib-python and opencv-contrib-python-headless are installed. Please uninstall one of them.")
elif not has_cv2_headless and not has_cv2_normal:
    run_cv2_imshow = False
    import warnings
    warnings.warn("Neither opencv-contrib-python nor opencv-contrib-python-headless are installed. Please install one of them to use cv2.imshow().")
else:
    raise ValueError("This should never happen. Please report this error to the developer.")

def prepare_cv2_imshow():
    """
    This function is necessary because cv2.imshow()
    can crash the kernel if called after importing
    other libraries that wrap libavcodec (e.g. torchcodec, av, decord).
    Calling it once at import time forces cv2 to initialize its GUI
    subsystem before those libraries can hijack the relevant symbols.
    RH 2022
    """
    import numpy as np
    import cv2
    test = np.zeros((1,300,400,3))
    for frame in test:
        cv2.putText(frame, "WELCOME TO FACE RHYTHM!", (10,50), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
        cv2.putText(frame, "Prepping CV2", (10,100), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
        cv2.putText(frame, "Calling this figure allows cv2.imshow ", (10,150), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        cv2.putText(frame, "to work without crashing if this function", (10,170), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        cv2.putText(frame, "is called before importing torchcodec/av", (10,190), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        cv2.imshow('startup', frame)
        cv2.waitKey(1000)
    cv2.destroyWindow('startup')


def _display_available():
    """True if a GUI display is available for cv2.imshow at runtime.

    Linux: requires X11 ($DISPLAY) or Wayland ($WAYLAND_DISPLAY).
    macOS / Windows: assume yes (cv2 generally works in those environments;
    truly headless macOS users typically install opencv-contrib-python-headless,
    which is detected separately above).
    """
    import sys, os
    if sys.platform.startswith('linux'):
        return bool(os.environ.get('DISPLAY')) or bool(os.environ.get('WAYLAND_DISPLAY'))
    return True


if run_cv2_imshow and _display_available():
    prepare_cv2_imshow()


for pkg in __all__:
    exec('from . import ' + pkg)
