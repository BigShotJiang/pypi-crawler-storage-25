# coding=utf-8
"""
TrendRadar CLI - 供 Agent 调用的命令行工具
"""
