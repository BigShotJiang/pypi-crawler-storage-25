# coding=utf-8
"""
CLI 输出格式化工具

统一将结果序列化为 JSON 输出到 stdout。
"""
import json
import sys


def output_json(data: dict, pretty: bool = True) -> None:
    """
    将结果输出为 JSON。

    Args:
        data: 要输出的字典
        pretty: True 时缩进 2 空格（默认），False 时输出紧凑单行
    """
    print(json.dumps(data, ensure_ascii=False, indent=2 if pretty else None))


def exit_with_error(result: dict) -> None:
    """
    输出错误 JSON 并以 exit code 1 退出。

    Args:
        result: 包含 success=False 的结果字典
    """
    output_json(result)
    sys.exit(1)
