# coding=utf-8
"""
TrendRadar CLI 入口

供 Agent 调用的命令行工具，所有子命令输出合法 JSON。
不集成 AI，专注数据查询与爬取触发。

用法示例：
    trendradar-cli news --limit 20
    trendradar-cli search 人工智能 --days 3
    trendradar-cli crawl --save
    trendradar-cli trending --top 10
    trendradar-cli status
    trendradar-cli rss --days 1
    trendradar-cli rss-search 特斯拉
    trendradar-cli news-by-date --date 2026-05-14
"""
import argparse
import sys
from pathlib import Path


def get_project_root() -> str:
    """自动推断项目根目录（cli/ 的上一级）"""
    return str(Path(__file__).parent.parent)


def _suppress_print(func):
    """
    包装函数，将内部 print 输出重定向到 stderr，
    避免污染 stdout 的 JSON 输出。
    """
    import functools
    import builtins

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        original_print = builtins.print

        def stderr_print(*a, **kw):
            kw["file"] = sys.stderr
            original_print(*a, **kw)

        builtins.print = stderr_print
        try:
            return func(*args, **kwargs)
        finally:
            builtins.print = original_print

    return wrapper


# ──────────────────────────────────────────────
# 子命令 handler
# ──────────────────────────────────────────────

@_suppress_print
def _cmd_news(args) -> dict:
    """获取最新热榜"""
    from mcp_server.tools.data_query import DataQueryTools
    tools = DataQueryTools(get_project_root())
    return tools.get_latest_news(
        platforms=args.platform or None,
        limit=args.limit,
        include_url=args.url,
    )


@_suppress_print
def _cmd_news_by_date(args) -> dict:
    """按日期查询热榜"""
    from mcp_server.tools.data_query import DataQueryTools
    tools = DataQueryTools(get_project_root())
    return tools.get_news_by_date(
        date_range=args.date,
        platforms=args.platform or None,
        limit=args.limit,
        include_url=args.url,
    )


@_suppress_print
def _cmd_search(args) -> dict:
    """关键词/模糊/实体搜索"""
    from mcp_server.tools.search_tools import SearchTools
    tools = SearchTools(get_project_root())
    # 构造日期范围：从今天往前 N 天
    from datetime import datetime, timedelta
    end = datetime.now()
    start = end - timedelta(days=args.days - 1)
    date_range = {
        "start": start.strftime("%Y-%m-%d"),
        "end": end.strftime("%Y-%m-%d"),
    }
    return tools.search_news_unified(
        query=args.keyword,
        search_mode=args.mode,
        date_range=date_range,
        platforms=args.platform or None,
        limit=args.limit,
        include_url=args.url,
        include_rss=args.rss,
    )


@_suppress_print
def _cmd_trending(args) -> dict:
    """热点话题频率统计"""
    from mcp_server.tools.data_query import DataQueryTools
    tools = DataQueryTools(get_project_root())
    return tools.get_trending_topics(
        top_n=args.top,
        mode=args.mode,
        extract_mode=args.extract,
        words_file=args.words or None,
    )


@_suppress_print
def _cmd_rss(args) -> dict:
    """获取最新 RSS 数据"""
    from mcp_server.tools.data_query import DataQueryTools
    tools = DataQueryTools(get_project_root())
    return tools.get_latest_rss(
        days=args.days,
        limit=args.limit,
        include_summary=args.summary,
    )


@_suppress_print
def _cmd_rss_search(args) -> dict:
    """搜索 RSS 数据"""
    from mcp_server.tools.data_query import DataQueryTools
    tools = DataQueryTools(get_project_root())
    return tools.search_rss(
        keyword=args.keyword,
        days=args.days,
        limit=args.limit,
        include_summary=args.summary,
    )


@_suppress_print
def _cmd_crawl(args) -> dict:
    """触发一次爬取任务"""
    from mcp_server.tools.system import SystemManagementTools
    tools = SystemManagementTools(get_project_root())
    return tools.trigger_crawl(
        platforms=args.platform or None,
        save_to_local=args.save,
        include_url=args.url,
    )


@_suppress_print
def _cmd_status(_args) -> dict:
    """查询系统状态"""
    from mcp_server.tools.system import SystemManagementTools
    tools = SystemManagementTools(get_project_root())
    return tools.get_system_status()


# ──────────────────────────────────────────────
# 参数解析
# ──────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    """构建顶层 + 子命令解析器"""
    parser = argparse.ArgumentParser(
        prog="trendradar-cli",
        description="TrendRadar CLI — 供 Agent 使用的热榜数据查询工具（JSON 输出）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
子命令示例：
  trendradar-cli news --limit 20
  trendradar-cli news-by-date --date 2026-05-14
  trendradar-cli search 人工智能 --days 3 --mode keyword
  trendradar-cli trending --top 10
  trendradar-cli rss --days 2
  trendradar-cli rss-search 特斯拉 --days 7
  trendradar-cli crawl --save
  trendradar-cli status
""",
    )
    parser.add_argument(
        "--compact", action="store_true",
        help="输出紧凑 JSON（单行，默认缩进格式）"
    )

    sub = parser.add_subparsers(dest="command", metavar="<subcmd>")
    sub.required = True

    # ── news ──────────────────────────────────
    p = sub.add_parser("news", help="获取最新一批热榜数据")
    p.add_argument("--platform", nargs="*", metavar="ID",
                   help="平台 ID，可多选，如 --platform zhihu weibo")
    p.add_argument("--limit", type=int, default=20, help="返回条数（默认 20）")
    p.add_argument("--url", action="store_true", help="包含 URL 字段")

    # ── news-by-date ───────────────────────────
    p = sub.add_parser("news-by-date", help="按日期查询热榜")
    p.add_argument("--date", default="今天",
                   help="日期，支持 YYYY-MM-DD / 今天 / 昨天 / 前天（默认今天）")
    p.add_argument("--platform", nargs="*", metavar="ID")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--url", action="store_true", help="包含 URL 字段")

    # ── search ────────────────────────────────
    p = sub.add_parser("search", help="搜索热榜（支持关键词/模糊/实体模式）")
    p.add_argument("keyword", help="搜索关键词")
    p.add_argument("--mode", default="keyword",
                   choices=["keyword", "fuzzy", "entity"],
                   help="搜索模式（默认 keyword）")
    p.add_argument("--days", type=int, default=1, help="搜索最近 N 天（默认 1）")
    p.add_argument("--platform", nargs="*", metavar="ID")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--url", action="store_true", help="包含 URL 字段")
    p.add_argument("--rss", action="store_true", help="同时搜索 RSS 数据")

    # ── trending ──────────────────────────────
    p = sub.add_parser("trending", help="热点话题频率统计")
    p.add_argument("--top", type=int, default=10, help="返回 TOP N（默认 10）")
    p.add_argument("--mode", default="current",
                   choices=["current", "daily"],
                   help="统计范围（默认 current）")
    p.add_argument("--extract", default="keywords",
                   choices=["keywords", "auto_extract"],
                   help="提取模式（默认 keywords）")
    p.add_argument("--words", metavar="FILE",
                   help="自定义关键词配置文件（仅 keywords 模式生效）。"
                        "支持绝对路径或短文件名（自动在 config/custom/keyword/ 下查找），"
                        "默认 config/frequency_words.txt")

    # ── rss ───────────────────────────────────
    p = sub.add_parser("rss", help="获取最新 RSS 订阅数据")
    p.add_argument("--days", type=int, default=1, help="最近 N 天（默认 1）")
    p.add_argument("--limit", type=int, default=30)
    p.add_argument("--summary", action="store_true", help="包含摘要字段")

    # ── rss-search ────────────────────────────
    p = sub.add_parser("rss-search", help="搜索 RSS 数据")
    p.add_argument("keyword", help="搜索关键词")
    p.add_argument("--days", type=int, default=7, help="最近 N 天（默认 7）")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--summary", action="store_true", help="包含摘要字段")

    # ── crawl ─────────────────────────────────
    p = sub.add_parser("crawl", help="触发一次爬取任务并返回结果")
    p.add_argument("--platform", nargs="*", metavar="ID",
                   help="指定平台，默认爬取全部")
    p.add_argument("--save", action="store_true",
                   help="持久化到本地 SQLite（默认不保存）")
    p.add_argument("--url", action="store_true", help="包含 URL 字段")

    # ── status ────────────────────────────────
    sub.add_parser("status", help="查询系统状态与数据统计")

    return parser


# ──────────────────────────────────────────────
# 路由分发
# ──────────────────────────────────────────────

_HANDLERS = {
    "news": _cmd_news,
    "news-by-date": _cmd_news_by_date,
    "search": _cmd_search,
    "trending": _cmd_trending,
    "rss": _cmd_rss,
    "rss-search": _cmd_rss_search,
    "crawl": _cmd_crawl,
    "status": _cmd_status,
}


def main() -> None:
    """CLI 主入口"""
    from cli.formatters import output_json, exit_with_error

    parser = build_parser()
    args = parser.parse_args()
    pretty = not args.compact

    handler = _HANDLERS.get(args.command)
    if handler is None:
        parser.print_help()
        sys.exit(1)

    result = handler(args)

    if not result.get("success", True):
        output_json(result, pretty=pretty)
        sys.exit(1)

    output_json(result, pretty=pretty)


if __name__ == "__main__":
    main()
