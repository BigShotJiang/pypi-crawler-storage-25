# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

TrendRadar is a trending news aggregation and analysis tool (v6.6.2). It fetches hot-topic lists from Chinese news platforms via the NewsNow API, supports RSS feed aggregation, performs AI-powered filtering/analysis/translation, and pushes notifications to multiple channels (Feishu, Telegram, DingTalk, WeWork, Email, ntfy, Bark, Slack, generic webhooks). It also exposes a FastMCP 2.0 server for AI assistant integration.

## Environment Setup

This project uses `uv` as the package manager (Python 3.12 required).

```bash
# Install dependencies and create .venv
uv sync
```

## Key Commands

```bash
# Run the main crawler/analyzer once (two equivalent forms)
uv run python -m trendradar
uv run trendradar

# Diagnostic commands
uv run python -m trendradar --doctor          # Environment and config health check
uv run python -m trendradar --show-schedule   # Show current scheduler state
uv run python -m trendradar --test-notification  # Test notification channel connectivity

# Start MCP server (stdio mode, for AI clients like Claude Desktop/Cherry Studio)
uv run python -m mcp_server.server
uv run trendradar-mcp

# Start MCP server (HTTP mode, port 3333)
uv run python -m mcp_server.server --transport http --host 0.0.0.0 --port 3333
# Or use the helper script:
./start-http.sh

# Docker: run once
docker run -e RUN_MODE=once -v ./config:/app/config -v ./output:/app/output wantcat/trendradar

# Docker: run on cron schedule (default */30 * * * *)
docker compose -f docker/docker-compose.yml up -d

# Build Docker image locally
docker compose -f docker/docker-compose-build.yml build
```

There are **no test files** in this project — the test suite has not been implemented.

## Configuration

The primary config file is `config/config.yaml`. It is loaded by `trendradar/core/loader.py` from the path set in `CONFIG_PATH` env var (default: `config/config.yaml`). All notification credentials can be overridden by environment variables (e.g. `FEISHU_WEBHOOK_URL`, `TELEGRAM_BOT_TOKEN`, `AI_API_KEY`, `S3_BUCKET_NAME`).

Key config sections:
- `app` — timezone, version check
- `platforms` — list of hot-topic sources to crawl (IDs correspond to NewsNow API IDs)
- `rss` — RSS feed list with freshness filtering
- `schedule` — timeline scheduler preset (`always_on`, `morning_evening`, `office_hours`, `night_owl`, `custom`)
- `report` — output mode (`daily` / `current` / `incremental`) and display grouping (`keyword` / `platform`)
- `filter` — filtering strategy: `keyword` (uses `config/frequency_words.txt`) or `ai` (uses `config/ai_interests.txt`)
- `ai_filter` — AI batch size, min_score threshold, reclassify threshold
- `display` — which notification regions to show and their order
- `notification` — per-channel webhook/token config (multi-account via `;` separator)
- `storage` — backend (`local` / `remote` / `auto`), SQLite + optional S3-compatible remote
- `ai` — shared LiteLLM model config for all AI features (model format: `provider/model_name`)

Timeline scheduling is defined separately in `config/timeline.yaml`. Custom keyword filter files live in `config/custom/keyword/`; custom AI interest files in `config/custom/ai/`.

## Architecture

### Two independent entry points

1. **`trendradar/`** — The crawler/notification pipeline, run via `python -m trendradar`
2. **`mcp_server/`** — The MCP server for AI assistant tool integration, run via `python -m mcp_server.server`

Both share the same `config/` directory and `output/` data directory.

### `trendradar/` package internals

The main flow in `trendradar/__main__.py` creates a `NewsAnalyzer` which orchestrates:

1. **`trendradar/core/`** — Config loading (`loader.py`), multi-account parsing (`config.py`), keyword frequency matching (`frequency.py`), timeline scheduling (`scheduler.py`), data utilities (`data.py`, `analyzer.py`)
2. **`trendradar/context.py`** — `AppContext` is the central dependency container. It wraps the loaded config dict and provides methods for time formatting, storage access, scheduling, and notification rendering. Eliminates global state.
3. **`trendradar/crawler/`** — `DataFetcher` hits the NewsNow API (`https://newsnow.busiyi.world/api/s?id=<platform_id>&latest`). `crawler/rss/` handles RSS feed fetching and parsing with `feedparser`.
4. **`trendradar/storage/`** — Storage abstraction: `StorageBackend` (ABC) → `LocalStorageBackend` (SQLite + files) or `RemoteStorageBackend` (boto3/S3). `StorageManager` auto-selects backend: remote when `GITHUB_ACTIONS=true` and S3 is configured, otherwise local. `SQLiteStorageMixin` provides the shared SQLite ORM logic. Data models: `NewsItem`, `RSSItem`, `NewsData`, `RSSData`.
5. **`trendradar/ai/`** — `AIClient` wraps LiteLLM for 100+ provider support. `AIAnalyzer` generates deep-dive reports. `AIFilter` classifies news items against user interests using batch processing. `AITranslator` translates notifications to other languages. Prompts loaded from `config/ai_analysis_prompt.txt` etc.
6. **`trendradar/report/`** — `generate_html_report()` builds the static HTML viewer saved to `output/`. `generator.py` formats structured report data; `html.py` is the large HTML template renderer.
7. **`trendradar/notification/`** — `NotificationDispatcher` sends to all configured channels. `senders.py` contains individual channel send functions. `splitter.py` handles byte-size-aware message splitting per channel limits. `renderer.py` renders Feishu/DingTalk card formats.

### `mcp_server/` package internals

`server.py` creates a `FastMCP` app named `trendradar-news`. Tools are grouped into class-based modules under `mcp_server/tools/`:
- `data_query.py` — `get_latest_news`, `get_news_by_date`, `get_trending_topics`, RSS queries
- `analytics.py` — trend analysis, sentiment analysis, aggregation, period comparison
- `search_tools.py` — keyword/fuzzy/entity search, related news finder
- `config_mgmt.py` — read current config
- `system.py` — system status, version check, manual crawl trigger
- `storage_sync.py` — sync from remote, list dates
- `article_reader.py` — fetch and return article content as Markdown
- `notification.py` — send test notifications via MCP

`mcp_server/services/` provides `DataService` (reads from local SQLite) and `ParserService` (content extraction). `mcp_server/utils/DateParser` resolves natural-language date expressions server-side for consistent date handling.

The MCP server exposes resources (`config://platforms`, `data://available-dates`, etc.) alongside tools. Tools are registered directly on the `mcp` FastMCP instance; tool instances use singleton pattern via `_tools_instances`.

### Shared utilities (`trendradar/utils/`)

- `time.py` — All timezone-aware time operations: `get_configured_time()`, `format_date_folder()`, `format_time_filename()`, `is_within_days()` (RSS freshness filter), `format_iso_time_friendly()`. Always use these rather than calling `datetime.now()` directly, so timezone config is respected.
- `url.py` — `normalize_url(url, platform_id)` strips dynamic tracking params (UTM, Weibo rank params) before deduplication.

### Storage layout

```
output/
  YYYY-MM-DD/
    news.db          # SQLite: news_items + rss_items tables
    news_HHMI.txt    # optional TXT snapshot
    report_HHMI.html # optional HTML report
```

### Environment detection

`NewsAnalyzer` detects `GITHUB_ACTIONS=true` (no proxy, use remote storage), Docker (`/.dockerenv` or `DOCKER_CONTAINER=true`), or local (may use proxy, opens browser).
