# goblin-cpu-features

Cross-platform CPU feature detection for packages that choose their own SIMD
backend at import time.

```python
import goblin_cpu_features as cpu

features = cpu.detect()
if {cpu.Feature.X86_AVX2, cpu.Feature.X86_FMA}.issubset(features):
    from mypkg import _avx2 as impl
elif cpu.Feature.ARM_SVE2 in features:
    from mypkg import _sve2 as impl
else:
    from mypkg import _generic as impl
```

`goblin_cpu_features` only reports host CPU features. It does not choose or
import application backends.

## Build

Local x86_64 manylinux and musllinux wheels are configured for Podman through
cibuildwheel:

```sh
python -m pip install '.[dev]'
python -m cibuildwheel --platform linux --output-dir wheelhouse .
```

The configured x86_64 build set is CPython 3.9 through 3.14 for both
`manylinux_x86_64` and `musllinux_x86_64`.

On non-x86 targets with pyenv-hosted interpreters, build one native wheel per
interpreter from the target environment:

```sh
for minor in 3.9 3.10 3.11 3.12 3.13 3.14; do
  for py in "$HOME"/.pyenv/versions/"$minor".*/bin/python; do
    [ -x "$py" ] || continue
    "$py" -m pip wheel --no-deps -w wheelhouse .
  done
done
```

For manylinux or musllinux tags on those targets, run the pyenv build inside
the corresponding compliant build environment or repair/tag the wheels using
the target platform's normal wheel policy tooling.
# goblin-cpu-features
