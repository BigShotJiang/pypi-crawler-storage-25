#pragma once

#include <cstdint>
#include <string_view>
#include <vector>

namespace goblin_cpu_features {

enum class Feature : std::uint16_t {
#define GOBLIN_CPU_FEATURE(name) name,
#include "features.def"
#undef GOBLIN_CPU_FEATURE
};

inline constexpr std::size_t feature_count() noexcept {
  std::size_t n = 0;
#define GOBLIN_CPU_FEATURE(name) ++n;
#include "features.def"
#undef GOBLIN_CPU_FEATURE
  return n;
}

std::string_view feature_name(Feature f) noexcept;

// Sorted, deduplicated. Empty when the running ISA is unsupported.
std::vector<Feature> detect_features();

}  // namespace goblin_cpu_features
