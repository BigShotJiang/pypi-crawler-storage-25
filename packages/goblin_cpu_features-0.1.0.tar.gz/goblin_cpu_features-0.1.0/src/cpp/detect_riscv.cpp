#include "detect_internal.hpp"

#include <cstdint>

#if defined(__riscv) && (__riscv_xlen == 64 || __riscv_xlen == 32)
  #define CPU_DISPATCH_RISCV 1
#endif

#if defined(CPU_DISPATCH_RISCV) && defined(__linux__)
  #include <sys/auxv.h>
  #include <sys/syscall.h>
  #include <unistd.h>
  #if __has_include(<asm/hwcap.h>)
    #include <asm/hwcap.h>
  #endif
#endif

namespace goblin_cpu_features {

#if defined(CPU_DISPATCH_RISCV) && defined(__linux__)

namespace {

// riscv_hwprobe(2) interface — declared inline so we don't depend on a
// particular kernel-headers version. The syscall was assigned number 258.
constexpr long CD_SYS_riscv_hwprobe = 258;

struct HwprobePair {
  std::int64_t key;
  std::uint64_t value;
};

constexpr std::int64_t KEY_MVENDORID                = 0;
constexpr std::int64_t KEY_MARCHID                  = 1;
constexpr std::int64_t KEY_MIMPID                   = 2;
constexpr std::int64_t KEY_BASE_BEHAVIOR            = 3;
constexpr std::int64_t KEY_IMA_EXT_0                = 4;
constexpr std::int64_t KEY_MISALIGNED_SCALAR_PERF   = 9;
constexpr std::int64_t KEY_MISALIGNED_VECTOR_PERF   = 10;

constexpr std::uint64_t BASE_BEHAVIOR_IMA           = 1ULL << 0;

// IMA_EXT_0 value bits.
constexpr std::uint64_t IMA_FD                      = 1ULL << 0;
constexpr std::uint64_t IMA_C                       = 1ULL << 1;
constexpr std::uint64_t IMA_V                       = 1ULL << 2;
constexpr std::uint64_t IMA_ZBA                     = 1ULL << 3;
constexpr std::uint64_t IMA_ZBB                     = 1ULL << 4;
constexpr std::uint64_t IMA_ZBS                     = 1ULL << 5;
constexpr std::uint64_t IMA_ZICBOZ                  = 1ULL << 6;
constexpr std::uint64_t IMA_ZBC                     = 1ULL << 7;
constexpr std::uint64_t IMA_ZBKB                    = 1ULL << 8;
constexpr std::uint64_t IMA_ZBKC                    = 1ULL << 9;
constexpr std::uint64_t IMA_ZBKX                    = 1ULL << 10;
constexpr std::uint64_t IMA_ZKND                    = 1ULL << 11;
constexpr std::uint64_t IMA_ZKNE                    = 1ULL << 12;
constexpr std::uint64_t IMA_ZKNH                    = 1ULL << 13;
constexpr std::uint64_t IMA_ZKSED                   = 1ULL << 14;
constexpr std::uint64_t IMA_ZKSH                    = 1ULL << 15;
constexpr std::uint64_t IMA_ZKT                     = 1ULL << 16;
constexpr std::uint64_t IMA_ZVBB                    = 1ULL << 17;
constexpr std::uint64_t IMA_ZVBC                    = 1ULL << 18;
constexpr std::uint64_t IMA_ZVKB                    = 1ULL << 19;
constexpr std::uint64_t IMA_ZVKG                    = 1ULL << 20;
constexpr std::uint64_t IMA_ZVKNED                  = 1ULL << 21;
constexpr std::uint64_t IMA_ZVKNHA                  = 1ULL << 22;
constexpr std::uint64_t IMA_ZVKNHB                  = 1ULL << 23;
constexpr std::uint64_t IMA_ZVKSED                  = 1ULL << 24;
constexpr std::uint64_t IMA_ZVKSH                   = 1ULL << 25;
constexpr std::uint64_t IMA_ZVKT                    = 1ULL << 26;
constexpr std::uint64_t IMA_ZFH                     = 1ULL << 27;
constexpr std::uint64_t IMA_ZFHMIN                  = 1ULL << 28;
constexpr std::uint64_t IMA_ZIHINTNTL               = 1ULL << 29;
constexpr std::uint64_t IMA_ZVFH                    = 1ULL << 30;
constexpr std::uint64_t IMA_ZVFHMIN                 = 1ULL << 31;
constexpr std::uint64_t IMA_ZFA                     = 1ULL << 32;
constexpr std::uint64_t IMA_ZTSO                    = 1ULL << 33;
constexpr std::uint64_t IMA_ZACAS                   = 1ULL << 34;
constexpr std::uint64_t IMA_ZICOND                  = 1ULL << 35;
constexpr std::uint64_t IMA_ZIHINTPAUSE             = 1ULL << 36;
constexpr std::uint64_t IMA_ZVE32X                  = 1ULL << 37;
constexpr std::uint64_t IMA_ZVE32F                  = 1ULL << 38;
constexpr std::uint64_t IMA_ZVE64X                  = 1ULL << 39;
constexpr std::uint64_t IMA_ZVE64F                  = 1ULL << 40;
constexpr std::uint64_t IMA_ZVE64D                  = 1ULL << 41;
constexpr std::uint64_t IMA_ZIMOP                   = 1ULL << 42;
constexpr std::uint64_t IMA_ZCA                     = 1ULL << 43;
constexpr std::uint64_t IMA_ZCB                     = 1ULL << 44;
constexpr std::uint64_t IMA_ZCD                     = 1ULL << 45;
constexpr std::uint64_t IMA_ZCF                     = 1ULL << 46;
constexpr std::uint64_t IMA_ZCMOP                   = 1ULL << 47;
constexpr std::uint64_t IMA_ZAWRS                   = 1ULL << 48;
constexpr std::uint64_t IMA_SUPM                    = 1ULL << 49;

constexpr std::uint64_t MISALIGNED_FAST             = 3;

// Hangzhou C-SKY / T-Head — the vendor that shipped RVV 0.7.x on the C906
// and C910 (Allwinner D1, Sipeed Lichee Pi 4A, etc.) before V was ratified.
constexpr std::uint64_t MVENDORID_THEAD             = 0x5b7;

long riscv_hwprobe(HwprobePair* pairs, std::size_t pair_count) noexcept {
  return ::syscall(CD_SYS_riscv_hwprobe, pairs, pair_count,
                   /*cpu_count=*/0, /*cpus=*/nullptr, /*flags=*/0u);
}

}  // namespace

void detect_riscv(std::vector<Feature>& out) {
  auto add = [&](Feature f) { out.push_back(f); };

  HwprobePair pairs[] = {
      {KEY_BASE_BEHAVIOR, 0},
      {KEY_IMA_EXT_0, 0},
      {KEY_MVENDORID, 0},
      {KEY_MARCHID, 0},
      {KEY_MIMPID, 0},
      {KEY_MISALIGNED_SCALAR_PERF, 0},
      {KEY_MISALIGNED_VECTOR_PERF, 0},
  };
  const long rc = riscv_hwprobe(pairs, sizeof(pairs) / sizeof(pairs[0]));
  const bool have_hwprobe = (rc == 0);

  std::uint64_t base = 0, ima = 0, mvendor = 0;
  std::uint64_t scalar_perf = 0, vector_perf = 0;
  if (have_hwprobe) {
    base = pairs[0].value;
    ima = pairs[1].value;
    mvendor = pairs[2].value;
    scalar_perf = pairs[5].value;
    vector_perf = pairs[6].value;
  }

  // BASE_BEHAVIOR_IMA implies the I, M, and A extensions are present.
  if (base & BASE_BEHAVIOR_IMA) {
    add(Feature::RV_I);
    add(Feature::RV_M);
    add(Feature::RV_A);
  }

  if (ima & IMA_FD) { add(Feature::RV_F); add(Feature::RV_D); }
  if (ima & IMA_C)  add(Feature::RV_C);

  // RVV ratified == 1.0. The hwprobe IMA_V bit is *only* set for 1.0.
  if (ima & IMA_V) {
    add(Feature::RV_V);
    add(Feature::RV_V_1_0);
  } else if (mvendor == MVENDORID_THEAD) {
    // T-Head C906/C910 ship RVV 0.7.x; the kernel never reports IMA_V for
    // them because the encoding is incompatible with the ratified spec.
    // Consumers should treat RV_V_0_7 as a wholly different ISA from RV_V_1_0.
    add(Feature::RV_V_0_7);
  }

  if (ima & IMA_ZBA)         add(Feature::RV_ZBA);
  if (ima & IMA_ZBB)         add(Feature::RV_ZBB);
  if (ima & IMA_ZBC)         add(Feature::RV_ZBC);
  if (ima & IMA_ZBS)         add(Feature::RV_ZBS);
  if (ima & IMA_ZBKB)        add(Feature::RV_ZBKB);
  if (ima & IMA_ZBKC)        add(Feature::RV_ZBKC);
  if (ima & IMA_ZBKX)        add(Feature::RV_ZBKX);
  if (ima & IMA_ZKND)        add(Feature::RV_ZKND);
  if (ima & IMA_ZKNE)        add(Feature::RV_ZKNE);
  if (ima & IMA_ZKNH)        add(Feature::RV_ZKNH);
  if (ima & IMA_ZKSED)       add(Feature::RV_ZKSED);
  if (ima & IMA_ZKSH)        add(Feature::RV_ZKSH);
  if (ima & IMA_ZKT)         add(Feature::RV_ZKT);
  if (ima & IMA_ZVBB)        add(Feature::RV_ZVBB);
  if (ima & IMA_ZVBC)        add(Feature::RV_ZVBC);
  if (ima & IMA_ZVKB)        add(Feature::RV_ZVKB);
  if (ima & IMA_ZVKG)        add(Feature::RV_ZVKG);
  if (ima & IMA_ZVKNED)      add(Feature::RV_ZVKNED);
  if (ima & IMA_ZVKNHA)      add(Feature::RV_ZVKNHA);
  if (ima & IMA_ZVKNHB)      add(Feature::RV_ZVKNHB);
  if (ima & IMA_ZVKSED)      add(Feature::RV_ZVKSED);
  if (ima & IMA_ZVKSH)       add(Feature::RV_ZVKSH);
  if (ima & IMA_ZVKT)        add(Feature::RV_ZVKT);
  if (ima & IMA_ZFH)         add(Feature::RV_ZFH);
  if (ima & IMA_ZFHMIN)      add(Feature::RV_ZFHMIN);
  if (ima & IMA_ZFA)         add(Feature::RV_ZFA);
  if (ima & IMA_ZVFH)        add(Feature::RV_ZVFH);
  if (ima & IMA_ZVFHMIN)     add(Feature::RV_ZVFHMIN);
  if (ima & IMA_ZICBOZ)      add(Feature::RV_ZICBOZ);
  if (ima & IMA_ZACAS)       add(Feature::RV_ZACAS);
  if (ima & IMA_ZICOND)      add(Feature::RV_ZICOND);
  if (ima & IMA_ZIHINTPAUSE) add(Feature::RV_ZIHINTPAUSE);
  if (ima & IMA_ZIHINTNTL)   add(Feature::RV_ZIHINTNTL);
  if (ima & IMA_ZAWRS)       add(Feature::RV_ZAWRS);
  if (ima & IMA_ZIMOP)       add(Feature::RV_ZIMOP);
  if (ima & IMA_ZCMOP)       add(Feature::RV_ZCMOP);
  if (ima & IMA_ZTSO)        add(Feature::RV_ZTSO);
  if (ima & IMA_ZCA)         add(Feature::RV_ZCA);
  if (ima & IMA_ZCB)         add(Feature::RV_ZCB);
  if (ima & IMA_ZCD)         add(Feature::RV_ZCD);
  if (ima & IMA_ZCF)         add(Feature::RV_ZCF);
  if (ima & IMA_ZVE32X)      add(Feature::RV_ZVE32X);
  if (ima & IMA_ZVE32F)      add(Feature::RV_ZVE32F);
  if (ima & IMA_ZVE64X)      add(Feature::RV_ZVE64X);
  if (ima & IMA_ZVE64F)      add(Feature::RV_ZVE64F);
  if (ima & IMA_ZVE64D)      add(Feature::RV_ZVE64D);
  if (ima & IMA_SUPM)        add(Feature::RV_SUPM);

  if (have_hwprobe && scalar_perf == MISALIGNED_FAST) {
    add(Feature::RV_MISALIGNED_SCALAR_FAST);
  }
  if (have_hwprobe && vector_perf == MISALIGNED_FAST) {
    add(Feature::RV_MISALIGNED_VECTOR_FAST);
  }

  // Fall back to HWCAP when hwprobe is unavailable (very old kernels).
  if (!have_hwprobe) {
#ifdef AT_HWCAP
    const unsigned long cap = ::getauxval(AT_HWCAP);
    // RISC-V HWCAP advertises base ISA letters as bit positions 'A'-'Z'.
    auto bit_for = [](char ch) -> unsigned long { return 1UL << (ch - 'A'); };
    if (cap & bit_for('I')) add(Feature::RV_I);
    if (cap & bit_for('M')) add(Feature::RV_M);
    if (cap & bit_for('A')) add(Feature::RV_A);
    if (cap & bit_for('F')) add(Feature::RV_F);
    if (cap & bit_for('D')) add(Feature::RV_D);
    if (cap & bit_for('C')) add(Feature::RV_C);
    if (cap & bit_for('H')) add(Feature::RV_H);
    if (cap & bit_for('V')) { add(Feature::RV_V); add(Feature::RV_V_1_0); }
#endif
  }

  // RV_P (packed SIMD draft) currently has no portable detection mechanism
  // in any released kernel — leave undetected; consumers that target known
  // chips can match on the enum value directly.
}

#else

void detect_riscv(std::vector<Feature>&) {}

#endif

}  // namespace goblin_cpu_features
