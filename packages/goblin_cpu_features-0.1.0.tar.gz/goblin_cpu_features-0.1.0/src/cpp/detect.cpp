#include "feature.hpp"

#include <algorithm>

#include "detect_internal.hpp"

namespace goblin_cpu_features {

std::vector<Feature> detect_features() {
  std::vector<Feature> v;
  v.reserve(64);

  detect_x86(v);
  detect_arm(v);
  detect_loongarch(v);
  detect_powerpc(v);
  detect_riscv(v);
  detect_sparc(v);

  std::sort(v.begin(), v.end());
  v.erase(std::unique(v.begin(), v.end()), v.end());
  return v;
}

}  // namespace goblin_cpu_features
