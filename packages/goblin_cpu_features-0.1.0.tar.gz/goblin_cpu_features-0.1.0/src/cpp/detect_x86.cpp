#include "detect_internal.hpp"

#include <algorithm>
#include <cstdint>
#include <cstring>

#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__) || defined(_M_IX86)
  #define CPU_DISPATCH_X86 1
  #if defined(_MSC_VER)
    #include <immintrin.h>
    #include <intrin.h>
  #else
    #include <cpuid.h>
  #endif
#endif

namespace goblin_cpu_features {

#if defined(CPU_DISPATCH_X86)

namespace {

struct Regs {
  std::uint32_t eax{};
  std::uint32_t ebx{};
  std::uint32_t ecx{};
  std::uint32_t edx{};
};

Regs cpuid(std::uint32_t leaf, std::uint32_t subleaf = 0) noexcept {
  Regs r{};
#if defined(_MSC_VER)
  int out[4]{};
  __cpuidex(out, static_cast<int>(leaf), static_cast<int>(subleaf));
  r.eax = static_cast<std::uint32_t>(out[0]);
  r.ebx = static_cast<std::uint32_t>(out[1]);
  r.ecx = static_cast<std::uint32_t>(out[2]);
  r.edx = static_cast<std::uint32_t>(out[3]);
#else
  __cpuid_count(leaf, subleaf, r.eax, r.ebx, r.ecx, r.edx);
#endif
  return r;
}

std::uint64_t xgetbv(std::uint32_t xcr) noexcept {
#if defined(_MSC_VER)
  return static_cast<std::uint64_t>(_xgetbv(xcr));
#else
  std::uint32_t lo = 0, hi = 0;
  __asm__ volatile(".byte 0x0f, 0x01, 0xd0" : "=a"(lo), "=d"(hi) : "c"(xcr));
  return (static_cast<std::uint64_t>(hi) << 32) | lo;
#endif
}

constexpr bool bit(std::uint32_t reg, unsigned b) noexcept {
  return (reg & (1u << b)) != 0;
}

struct VendorModel {
  char vendor[13]{};  // null-terminated
  std::uint32_t display_family{};
  std::uint32_t display_model{};
  std::uint32_t stepping{};
};

VendorModel read_vendor_model() noexcept {
  VendorModel v{};
  const auto l0 = cpuid(0);
  std::memcpy(v.vendor + 0, &l0.ebx, 4);
  std::memcpy(v.vendor + 4, &l0.edx, 4);
  std::memcpy(v.vendor + 8, &l0.ecx, 4);
  v.vendor[12] = '\0';

  const auto l1 = cpuid(1);
  const std::uint32_t family = (l1.eax >> 8) & 0xF;
  const std::uint32_t model = (l1.eax >> 4) & 0xF;
  const std::uint32_t ext_family = (l1.eax >> 20) & 0xFF;
  const std::uint32_t ext_model = (l1.eax >> 16) & 0xF;
  v.stepping = l1.eax & 0xF;
  v.display_family = (family == 0xF) ? (family + ext_family) : family;
  v.display_model =
      (family == 0x6 || family == 0xF) ? ((ext_model << 4) | model) : model;
  return v;
}

bool is_intel(const VendorModel& v) noexcept {
  return std::strcmp(v.vendor, "GenuineIntel") == 0;
}

bool is_amd(const VendorModel& v) noexcept {
  return std::strcmp(v.vendor, "AuthenticAMD") == 0 ||
         std::strcmp(v.vendor, "HygonGenuine") == 0;
}

// Intel SKUs known to trigger heavy AVX-512 license-2 frequency downshifts.
// Skylake-SP/X/W (0x55 stepping<=4), Cascade Lake (0x55 stepping 5-7),
// Cooper Lake (0x55 stepping 10-11), Ice Lake-SP (0x6A), Ice Lake-D (0x6C).
// Sapphire Rapids onward fixed the worst of it.
bool intel_downclocks_on_avx512(const VendorModel& v) noexcept {
  if (v.display_family != 0x6) return false;
  switch (v.display_model) {
    case 0x55:  // Skylake-SP, Cascade Lake, Cooper Lake
    case 0x6A:  // Ice Lake-SP
    case 0x6C:  // Ice Lake-D
      return true;
    default:
      return false;
  }
}

// AMD AVX-512 implementations whose 512-bit ops are double-pumped through a
// 256-bit datapath, giving ~AVX2 throughput. Zen 4 (family 0x19); Zen 5
// (family 0x1A) has a full-width unit and does NOT get this flag.
bool amd_slow_avx512(const VendorModel& v) noexcept {
  return v.display_family == 0x19;
}

}  // namespace

void detect_x86(std::vector<Feature>& out) {
  const auto leaf0 = cpuid(0);
  const std::uint32_t max_basic = leaf0.eax;
  if (max_basic < 1) {
    return;
  }

  const auto l1 = cpuid(1);
  auto add = [&](Feature f) { out.push_back(f); };

  // Leaf 1 — EDX
  if (bit(l1.edx, 0))  add(Feature::X86_FPU);
  if (bit(l1.edx, 8))  add(Feature::X86_CX8);
  if (bit(l1.edx, 15)) add(Feature::X86_CMOV);
  if (bit(l1.edx, 19)) add(Feature::X86_CLFLUSH);
  if (bit(l1.edx, 23)) add(Feature::X86_MMX);
  if (bit(l1.edx, 24)) add(Feature::X86_FXSR);
  if (bit(l1.edx, 25)) add(Feature::X86_SSE);
  if (bit(l1.edx, 26)) add(Feature::X86_SSE2);
  if (bit(l1.edx, 28)) add(Feature::X86_HTT);

  // Leaf 1 — ECX
  if (bit(l1.ecx, 0))  add(Feature::X86_SSE3);
  if (bit(l1.ecx, 1))  add(Feature::X86_PCLMULQDQ);
  if (bit(l1.ecx, 3))  add(Feature::X86_MONITOR);
  if (bit(l1.ecx, 9))  add(Feature::X86_SSSE3);
  if (bit(l1.ecx, 12)) add(Feature::X86_FMA);
  if (bit(l1.ecx, 13)) add(Feature::X86_CX16);
  if (bit(l1.ecx, 19)) add(Feature::X86_SSE4_1);
  if (bit(l1.ecx, 20)) add(Feature::X86_SSE4_2);
  if (bit(l1.ecx, 22)) add(Feature::X86_MOVBE);
  if (bit(l1.ecx, 23)) add(Feature::X86_POPCNT);
  if (bit(l1.ecx, 25)) add(Feature::X86_AES);
  if (bit(l1.ecx, 26)) add(Feature::X86_XSAVE);
  if (bit(l1.ecx, 27)) add(Feature::X86_OSXSAVE);
  if (bit(l1.ecx, 29)) add(Feature::X86_F16C);
  if (bit(l1.ecx, 30)) add(Feature::X86_RDRAND);
  if (bit(l1.ecx, 31)) add(Feature::X86_HYPERVISOR);

  // OS-visible state for wide vectors. Gate AVX / AVX-512 / AMX on XCR0.
  const bool osxsave = bit(l1.ecx, 27);
  const bool avx_cpuid = bit(l1.ecx, 28);
  const std::uint64_t xcr0 = osxsave ? xgetbv(0) : 0;
  const bool avx_os = osxsave && ((xcr0 & 0x6) == 0x6);          // XMM | YMM
  const bool zmm_os = avx_os && ((xcr0 & 0xE0) == 0xE0);         // OPMASK | ZMM_HI256 | HI16_ZMM
  const bool amx_os = osxsave && ((xcr0 & 0x60000) == 0x60000);  // TILECFG | TILEDATA

  if (avx_cpuid && avx_os) add(Feature::X86_AVX);

  // Leaf 7 / subleaf 0 + subleaf 1.
  Regs l7{}, l71{};
  if (max_basic >= 7) {
    l7 = cpuid(7, 0);
    l71 = cpuid(7, 1);

    // Subleaf 0 — EBX
    if (bit(l7.ebx, 0))                   add(Feature::X86_FSGSBASE);
    if (bit(l7.ebx, 3))                   add(Feature::X86_BMI1);
    if (bit(l7.ebx, 4))                   add(Feature::X86_HLE);
    if (avx_os && bit(l7.ebx, 5))         add(Feature::X86_AVX2);
    if (bit(l7.ebx, 8))                   add(Feature::X86_BMI2);
    if (bit(l7.ebx, 11))                  add(Feature::X86_RTM);
    if (zmm_os && bit(l7.ebx, 16))        add(Feature::X86_AVX512F);
    if (zmm_os && bit(l7.ebx, 17))        add(Feature::X86_AVX512DQ);
    if (bit(l7.ebx, 18))                  add(Feature::X86_RDSEED);
    if (bit(l7.ebx, 19))                  add(Feature::X86_ADX);
    if (zmm_os && bit(l7.ebx, 21))        add(Feature::X86_AVX512IFMA);
    if (bit(l7.ebx, 23))                  add(Feature::X86_CLFLUSHOPT);
    if (bit(l7.ebx, 24))                  add(Feature::X86_CLWB);
    if (zmm_os && bit(l7.ebx, 26))        add(Feature::X86_AVX512PF);
    if (zmm_os && bit(l7.ebx, 27))        add(Feature::X86_AVX512ER);
    if (zmm_os && bit(l7.ebx, 28))        add(Feature::X86_AVX512CD);
    if (bit(l7.ebx, 29))                  add(Feature::X86_SHA);
    if (zmm_os && bit(l7.ebx, 30))        add(Feature::X86_AVX512BW);
    if (zmm_os && bit(l7.ebx, 31))        add(Feature::X86_AVX512VL);

    // Subleaf 0 — ECX
    if (bit(l7.ecx, 0))                   add(Feature::X86_PREFETCHWT1);
    if (zmm_os && bit(l7.ecx, 1))         add(Feature::X86_AVX512VBMI);
    if (bit(l7.ecx, 3))                   add(Feature::X86_PKU);
    if (bit(l7.ecx, 4))                   add(Feature::X86_OSPKE);
    if (bit(l7.ecx, 5))                   add(Feature::X86_WAITPKG);
    if (zmm_os && bit(l7.ecx, 6))         add(Feature::X86_AVX512VBMI2);
    if (bit(l7.ecx, 7))                   add(Feature::X86_CET_SS);
    if (bit(l7.ecx, 8))                   add(Feature::X86_GFNI);
    if (bit(l7.ecx, 9))                   add(Feature::X86_VAES);
    if (bit(l7.ecx, 10))                  add(Feature::X86_VPCLMULQDQ);
    if (zmm_os && bit(l7.ecx, 11))        add(Feature::X86_AVX512VNNI);
    if (zmm_os && bit(l7.ecx, 12))        add(Feature::X86_AVX512BITALG);
    if (zmm_os && bit(l7.ecx, 14))        add(Feature::X86_AVX512VPOPCNTDQ);
    if (bit(l7.ecx, 16))                  add(Feature::X86_LA57);
    if (bit(l7.ecx, 22))                  add(Feature::X86_RDPID);
    if (bit(l7.ecx, 23))                  add(Feature::X86_KL);
    if (bit(l7.ecx, 25))                  add(Feature::X86_CLDEMOTE);
    if (bit(l7.ecx, 27))                  add(Feature::X86_MOVDIRI);
    if (bit(l7.ecx, 28))                  add(Feature::X86_MOVDIR64B);
    if (bit(l7.ecx, 29))                  add(Feature::X86_ENQCMD);

    // Subleaf 0 — EDX
    if (zmm_os && bit(l7.edx, 2))         add(Feature::X86_AVX512_4VNNIW);
    if (zmm_os && bit(l7.edx, 3))         add(Feature::X86_AVX512_4FMAPS);
    if (bit(l7.edx, 5))                   add(Feature::X86_UINTR);
    if (zmm_os && bit(l7.edx, 8))         add(Feature::X86_AVX512_VP2INTERSECT);
    if (bit(l7.edx, 14))                  add(Feature::X86_SERIALIZE);
    if (bit(l7.edx, 16))                  add(Feature::X86_TSXLDTRK);
    if (bit(l7.edx, 20))                  add(Feature::X86_CET_IBT);
    if (amx_os && bit(l7.edx, 22))        add(Feature::X86_AMX_BF16);
    if (zmm_os && bit(l7.edx, 23))        add(Feature::X86_AVX512_FP16);
    if (amx_os && bit(l7.edx, 24))        add(Feature::X86_AMX_TILE);
    if (amx_os && bit(l7.edx, 25))        add(Feature::X86_AMX_INT8);

    // Subleaf 1 — EAX
    if (bit(l71.eax, 0))                  add(Feature::X86_SHA512);
    if (bit(l71.eax, 1))                  add(Feature::X86_SM3);
    if (bit(l71.eax, 2))                  add(Feature::X86_SM4);
    if (bit(l71.eax, 3))                  add(Feature::X86_RAO_INT);
    if (avx_os && bit(l71.eax, 4))        add(Feature::X86_AVX_VNNI);
    if (zmm_os && bit(l71.eax, 5))        add(Feature::X86_AVX512_BF16);
    if (bit(l71.eax, 7))                  add(Feature::X86_CMPCCXADD);
    if (amx_os && bit(l71.eax, 21))       add(Feature::X86_AMX_FP16);
    if (bit(l71.eax, 22))                 add(Feature::X86_HRESET);
    if (avx_os && bit(l71.eax, 23))       add(Feature::X86_AVX_IFMA);

    // Subleaf 1 — EBX
    if (bit(l71.ebx, 1))                  add(Feature::X86_MSRLIST);

    // Subleaf 1 — EDX
    if (avx_os && bit(l71.edx, 4))        add(Feature::X86_AVX_VNNI_INT8);
    if (avx_os && bit(l71.edx, 5))        add(Feature::X86_AVX_NE_CONVERT);
    if (amx_os && bit(l71.edx, 8))        add(Feature::X86_AMX_COMPLEX);
    if (avx_os && bit(l71.edx, 10))       add(Feature::X86_AVX_VNNI_INT16);
    if (bit(l71.edx, 14))                 add(Feature::X86_PREFETCHI);
    if (bit(l71.edx, 15))                 add(Feature::X86_USER_MSR);
    if (avx_os && bit(l71.edx, 19))       add(Feature::X86_AVX10_1);
    if (bit(l71.edx, 21))                 add(Feature::X86_APX_F);
  }

  // Leaf 0x24 — AVX10 version and supported vector lengths.
  if (max_basic >= 0x24) {
    const auto l24 = cpuid(0x24, 0);
    const std::uint32_t version = l24.ebx & 0xFFu;
    if (version >= 2)                     add(Feature::X86_AVX10_2);
    if (avx_os && bit(l24.ebx, 17))       add(Feature::X86_AVX10_VL256);
    if (zmm_os && bit(l24.ebx, 18))       add(Feature::X86_AVX10_VL512);
  }

  // Leaf 0x1E subleaf 1 — newer AMX tile/data flavors.
  if (max_basic >= 0x1E) {
    const auto l1e1 = cpuid(0x1E, 1);
    if (amx_os && bit(l1e1.eax, 4))       add(Feature::X86_AMX_FP8);
    if (amx_os && bit(l1e1.eax, 5))       add(Feature::X86_AMX_TRANSPOSE);
    if (amx_os && bit(l1e1.eax, 6))       add(Feature::X86_AMX_TF32);
    if (amx_os && bit(l1e1.eax, 8))       add(Feature::X86_AMX_MOVRS);
  }

  // Leaf 0xD subleaf 1 — XSAVE extensions.
  if (max_basic >= 0xD) {
    const auto ld1 = cpuid(0xD, 1);
    if (bit(ld1.eax, 0))                  add(Feature::X86_XSAVEOPT);
    if (bit(ld1.eax, 1))                  add(Feature::X86_XSAVEC);
    if (bit(ld1.eax, 3))                  add(Feature::X86_XSAVES);
  }

  // Extended leaves (AMD + shared).
  const std::uint32_t max_ext = cpuid(0x80000000).eax;
  if (max_ext >= 0x80000001) {
    const auto e1 = cpuid(0x80000001);
    // ECX — bit 5 is LZCNT (Intel) / ABM (AMD), same instruction encoding.
    if (bit(e1.ecx, 5))                   { add(Feature::X86_LZCNT); add(Feature::X86_ABM); }
    if (bit(e1.ecx, 6))                   add(Feature::X86_SSE4A);
    if (avx_os && bit(e1.ecx, 11))        add(Feature::X86_XOP);
    if (avx_os && bit(e1.ecx, 16))        add(Feature::X86_FMA4);
    if (bit(e1.ecx, 21))                  add(Feature::X86_TBM);
    if (bit(e1.ecx, 29))                  add(Feature::X86_MWAITX);
    // EDX
    if (bit(e1.edx, 27))                  add(Feature::X86_RDTSCP);
    if (bit(e1.edx, 30))                  add(Feature::X86_3DNOWEXT);
    if (bit(e1.edx, 31))                  add(Feature::X86_3DNOW);
  }
  if (max_ext >= 0x80000008) {
    const auto e8 = cpuid(0x80000008);
    if (bit(e8.ebx, 9))                   add(Feature::X86_WBNOINVD);
    if (bit(e8.ebx, 10))                  add(Feature::X86_PTWRITE);
  }

  // Synthetic flags: derive from vendor/family/model when AVX-512 was found.
  const bool has_avx512f =
      std::find(out.begin(), out.end(), Feature::X86_AVX512F) != out.end();
  if (has_avx512f) {
    const VendorModel vm = read_vendor_model();
    if (is_intel(vm) && intel_downclocks_on_avx512(vm)) {
      add(Feature::X86_DOWNCLOCKS_ON_AVX512);
    }
    if (is_amd(vm) && amd_slow_avx512(vm)) {
      add(Feature::X86_SLOW_AVX512);
    }
  }
}

#else  // !CPU_DISPATCH_X86

void detect_x86(std::vector<Feature>&) {}

#endif

}  // namespace goblin_cpu_features
