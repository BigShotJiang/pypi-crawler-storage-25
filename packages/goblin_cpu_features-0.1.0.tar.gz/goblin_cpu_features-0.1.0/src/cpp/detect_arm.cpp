#include "detect_internal.hpp"

#include <cstdint>

#if defined(__aarch64__) || defined(_M_ARM64) || defined(__arm__) || defined(_M_ARM)
  #define CPU_DISPATCH_ARM 1
#endif

#if defined(CPU_DISPATCH_ARM)

#if defined(__linux__)
  #include <sys/auxv.h>
  #if __has_include(<asm/hwcap.h>)
    #include <asm/hwcap.h>
  #endif
#elif defined(__FreeBSD__)
  #include <sys/auxv.h>
  #include <sys/elf_common.h>
#elif defined(__APPLE__)
  #include <cstring>
  #include <sys/sysctl.h>
#elif defined(_WIN32)
  // Avoid pulling all of <windows.h> into a tiny TU.
  extern "C" __declspec(dllimport) int __stdcall IsProcessorFeaturePresent(unsigned long);
#endif

// Locally defined fallback values for HWCAP bits — kernels older than the
// header that introduced a flag will not define it; using local constants
// keeps the per-bit table dense without a forest of #ifdefs.
namespace {

#if defined(__linux__) && defined(__aarch64__)
constexpr unsigned long CD_HWCAP_FP         = 1UL << 0;
constexpr unsigned long CD_HWCAP_ASIMD      = 1UL << 1;
constexpr unsigned long CD_HWCAP_EVTSTRM    = 1UL << 2;
constexpr unsigned long CD_HWCAP_AES        = 1UL << 3;
constexpr unsigned long CD_HWCAP_PMULL      = 1UL << 4;
constexpr unsigned long CD_HWCAP_SHA1       = 1UL << 5;
constexpr unsigned long CD_HWCAP_SHA2       = 1UL << 6;
constexpr unsigned long CD_HWCAP_CRC32      = 1UL << 7;
constexpr unsigned long CD_HWCAP_ATOMICS    = 1UL << 8;
constexpr unsigned long CD_HWCAP_FPHP       = 1UL << 9;
constexpr unsigned long CD_HWCAP_ASIMDHP    = 1UL << 10;
constexpr unsigned long CD_HWCAP_CPUID      = 1UL << 11;
constexpr unsigned long CD_HWCAP_ASIMDRDM   = 1UL << 12;
constexpr unsigned long CD_HWCAP_JSCVT      = 1UL << 13;
constexpr unsigned long CD_HWCAP_FCMA       = 1UL << 14;
constexpr unsigned long CD_HWCAP_LRCPC      = 1UL << 15;
constexpr unsigned long CD_HWCAP_DCPOP      = 1UL << 16;
constexpr unsigned long CD_HWCAP_SHA3       = 1UL << 17;
constexpr unsigned long CD_HWCAP_SM3        = 1UL << 18;
constexpr unsigned long CD_HWCAP_SM4        = 1UL << 19;
constexpr unsigned long CD_HWCAP_ASIMDDP    = 1UL << 20;
constexpr unsigned long CD_HWCAP_SHA512     = 1UL << 21;
constexpr unsigned long CD_HWCAP_SVE        = 1UL << 22;
constexpr unsigned long CD_HWCAP_ASIMDFHM   = 1UL << 23;
constexpr unsigned long CD_HWCAP_DIT        = 1UL << 24;
constexpr unsigned long CD_HWCAP_USCAT      = 1UL << 25;
constexpr unsigned long CD_HWCAP_ILRCPC     = 1UL << 26;
constexpr unsigned long CD_HWCAP_FLAGM      = 1UL << 27;
constexpr unsigned long CD_HWCAP_SSBS       = 1UL << 28;
constexpr unsigned long CD_HWCAP_SB         = 1UL << 29;
constexpr unsigned long CD_HWCAP_PACA       = 1UL << 30;
constexpr unsigned long CD_HWCAP_PACG       = 1UL << 31;

constexpr unsigned long CD_HWCAP2_DCPODP        = 1UL << 0;
constexpr unsigned long CD_HWCAP2_SVE2          = 1UL << 1;
constexpr unsigned long CD_HWCAP2_SVEAES        = 1UL << 2;
constexpr unsigned long CD_HWCAP2_SVEPMULL      = 1UL << 3;
constexpr unsigned long CD_HWCAP2_SVEBITPERM    = 1UL << 4;
constexpr unsigned long CD_HWCAP2_SVESHA3       = 1UL << 5;
constexpr unsigned long CD_HWCAP2_SVESM4        = 1UL << 6;
constexpr unsigned long CD_HWCAP2_FLAGM2        = 1UL << 7;
constexpr unsigned long CD_HWCAP2_FRINT         = 1UL << 8;
constexpr unsigned long CD_HWCAP2_SVEI8MM       = 1UL << 9;
constexpr unsigned long CD_HWCAP2_SVEF32MM      = 1UL << 10;
constexpr unsigned long CD_HWCAP2_SVEF64MM      = 1UL << 11;
constexpr unsigned long CD_HWCAP2_SVEBF16       = 1UL << 12;
constexpr unsigned long CD_HWCAP2_I8MM          = 1UL << 13;
constexpr unsigned long CD_HWCAP2_BF16          = 1UL << 14;
constexpr unsigned long CD_HWCAP2_DGH           = 1UL << 15;
constexpr unsigned long CD_HWCAP2_RNG           = 1UL << 16;
constexpr unsigned long CD_HWCAP2_BTI           = 1UL << 17;
constexpr unsigned long CD_HWCAP2_MTE           = 1UL << 18;
constexpr unsigned long CD_HWCAP2_ECV           = 1UL << 19;
constexpr unsigned long CD_HWCAP2_AFP           = 1UL << 20;
constexpr unsigned long CD_HWCAP2_RPRES         = 1UL << 21;
constexpr unsigned long CD_HWCAP2_MTE3          = 1UL << 22;
constexpr unsigned long CD_HWCAP2_SME           = 1UL << 23;
constexpr unsigned long CD_HWCAP2_SME_I16I64    = 1UL << 24;
constexpr unsigned long CD_HWCAP2_SME_F64F64    = 1UL << 25;
constexpr unsigned long CD_HWCAP2_SME_I8I32     = 1UL << 26;
constexpr unsigned long CD_HWCAP2_SME_F16F32    = 1UL << 27;
constexpr unsigned long CD_HWCAP2_SME_B16F32    = 1UL << 28;
constexpr unsigned long CD_HWCAP2_SME_F32F32    = 1UL << 29;
constexpr unsigned long CD_HWCAP2_SME_FA64      = 1UL << 30;
constexpr unsigned long CD_HWCAP2_WFXT          = 1UL << 31;
constexpr unsigned long CD_HWCAP2_EBF16         = 1UL << 32;
constexpr unsigned long CD_HWCAP2_SVE_EBF16     = 1UL << 33;
constexpr unsigned long CD_HWCAP2_CSSC          = 1UL << 34;
constexpr unsigned long CD_HWCAP2_RPRFM         = 1UL << 35;
constexpr unsigned long CD_HWCAP2_SVE2P1        = 1UL << 36;
constexpr unsigned long CD_HWCAP2_SME2          = 1UL << 37;
constexpr unsigned long CD_HWCAP2_SME2P1        = 1UL << 38;
constexpr unsigned long CD_HWCAP2_SME_I16I32    = 1UL << 39;
constexpr unsigned long CD_HWCAP2_SME_BI32I32   = 1UL << 40;
constexpr unsigned long CD_HWCAP2_SME_B16B16    = 1UL << 41;
constexpr unsigned long CD_HWCAP2_SME_F16F16    = 1UL << 42;
constexpr unsigned long CD_HWCAP2_MOPS          = 1UL << 43;
constexpr unsigned long CD_HWCAP2_HBC           = 1UL << 44;
constexpr unsigned long CD_HWCAP2_LRCPC3        = 1UL << 46;
constexpr unsigned long CD_HWCAP2_LSE128        = 1UL << 47;
#endif

}  // namespace

#endif  // CPU_DISPATCH_ARM

namespace goblin_cpu_features {

#if defined(CPU_DISPATCH_ARM) && defined(__aarch64__) && (defined(__linux__) || defined(__FreeBSD__))

namespace {

unsigned long read_hwcap(int which) noexcept {
#if defined(__linux__)
  return ::getauxval(which == 2 ? AT_HWCAP2 : AT_HWCAP);
#elif defined(__FreeBSD__)
  unsigned long val = 0;
  ::elf_aux_info(which == 2 ? AT_HWCAP2 : AT_HWCAP, &val, sizeof(val));
  return val;
#else
  (void)which;
  return 0;
#endif
}

void map_linux_hwcap(unsigned long cap, std::vector<Feature>& out) {
  auto add = [&](Feature f) { out.push_back(f); };
  if (cap & CD_HWCAP_FP)        add(Feature::ARM_FP);
  if (cap & CD_HWCAP_ASIMD)     add(Feature::ARM_ASIMD);
  if (cap & CD_HWCAP_EVTSTRM)   add(Feature::ARM_EVTSTRM);
  if (cap & CD_HWCAP_AES)       add(Feature::ARM_AES);
  if (cap & CD_HWCAP_PMULL)     add(Feature::ARM_PMULL);
  if (cap & CD_HWCAP_SHA1)      add(Feature::ARM_SHA1);
  if (cap & CD_HWCAP_SHA2)      add(Feature::ARM_SHA2);
  if (cap & CD_HWCAP_CRC32)     add(Feature::ARM_CRC32);
  if (cap & CD_HWCAP_ATOMICS)   add(Feature::ARM_ATOMICS);
  if (cap & CD_HWCAP_FPHP)      add(Feature::ARM_FPHP);
  if (cap & CD_HWCAP_ASIMDHP)   add(Feature::ARM_ASIMDHP);
  if (cap & CD_HWCAP_CPUID)     add(Feature::ARM_CPUID);
  if (cap & CD_HWCAP_ASIMDRDM)  add(Feature::ARM_ASIMDRDM);
  if (cap & CD_HWCAP_JSCVT)     add(Feature::ARM_JSCVT);
  if (cap & CD_HWCAP_FCMA)      add(Feature::ARM_FCMA);
  if (cap & CD_HWCAP_LRCPC)     add(Feature::ARM_LRCPC);
  if (cap & CD_HWCAP_DCPOP)     add(Feature::ARM_DCPOP);
  if (cap & CD_HWCAP_SHA3)      add(Feature::ARM_SHA3);
  if (cap & CD_HWCAP_SM3)       add(Feature::ARM_SM3);
  if (cap & CD_HWCAP_SM4)       add(Feature::ARM_SM4);
  if (cap & CD_HWCAP_ASIMDDP)   add(Feature::ARM_ASIMDDP);
  if (cap & CD_HWCAP_SHA512)    add(Feature::ARM_SHA512);
  if (cap & CD_HWCAP_SVE)       add(Feature::ARM_SVE);
  if (cap & CD_HWCAP_ASIMDFHM)  add(Feature::ARM_ASIMDFHM);
  if (cap & CD_HWCAP_DIT)       add(Feature::ARM_DIT);
  if (cap & CD_HWCAP_USCAT)     add(Feature::ARM_USCAT);
  if (cap & CD_HWCAP_ILRCPC)    add(Feature::ARM_ILRCPC);
  if (cap & CD_HWCAP_FLAGM)     add(Feature::ARM_FLAGM);
  if (cap & CD_HWCAP_SSBS)      add(Feature::ARM_SSBS);
  if (cap & CD_HWCAP_SB)        add(Feature::ARM_SB);
  if (cap & CD_HWCAP_PACA)      add(Feature::ARM_PACA);
  if (cap & CD_HWCAP_PACG)      add(Feature::ARM_PACG);
}

void map_linux_hwcap2(unsigned long cap, std::vector<Feature>& out) {
  auto add = [&](Feature f) { out.push_back(f); };
  if (cap & CD_HWCAP2_DCPODP)        add(Feature::ARM_DCPODP);
  if (cap & CD_HWCAP2_SVE2)          add(Feature::ARM_SVE2);
  if (cap & CD_HWCAP2_SVEAES)        add(Feature::ARM_SVEAES);
  if (cap & CD_HWCAP2_SVEPMULL)      add(Feature::ARM_SVEPMULL);
  if (cap & CD_HWCAP2_SVEBITPERM)    add(Feature::ARM_SVEBITPERM);
  if (cap & CD_HWCAP2_SVESHA3)       add(Feature::ARM_SVESHA3);
  if (cap & CD_HWCAP2_SVESM4)        add(Feature::ARM_SVESM4);
  if (cap & CD_HWCAP2_FLAGM2)        add(Feature::ARM_FLAGM2);
  if (cap & CD_HWCAP2_FRINT)         add(Feature::ARM_FRINT);
  if (cap & CD_HWCAP2_SVEI8MM)       add(Feature::ARM_SVEI8MM);
  if (cap & CD_HWCAP2_SVEF32MM)      add(Feature::ARM_SVEF32MM);
  if (cap & CD_HWCAP2_SVEF64MM)      add(Feature::ARM_SVEF64MM);
  if (cap & CD_HWCAP2_SVEBF16)       add(Feature::ARM_SVEBF16);
  if (cap & CD_HWCAP2_I8MM)          add(Feature::ARM_I8MM);
  if (cap & CD_HWCAP2_BF16)          add(Feature::ARM_BF16);
  if (cap & CD_HWCAP2_DGH)           add(Feature::ARM_DGH);
  if (cap & CD_HWCAP2_RNG)           add(Feature::ARM_RNG);
  if (cap & CD_HWCAP2_BTI)           add(Feature::ARM_BTI);
  if (cap & CD_HWCAP2_MTE)           add(Feature::ARM_MTE);
  if (cap & CD_HWCAP2_ECV)           add(Feature::ARM_ECV);
  if (cap & CD_HWCAP2_AFP)           add(Feature::ARM_AFP);
  if (cap & CD_HWCAP2_RPRES)         add(Feature::ARM_RPRES);
  if (cap & CD_HWCAP2_MTE3)          add(Feature::ARM_MTE3);
  if (cap & CD_HWCAP2_SME)           add(Feature::ARM_SME);
  if (cap & CD_HWCAP2_SME_I16I64)    add(Feature::ARM_SME_I16I64);
  if (cap & CD_HWCAP2_SME_F64F64)    add(Feature::ARM_SME_F64F64);
  if (cap & CD_HWCAP2_SME_I8I32)     add(Feature::ARM_SME_I8I32);
  if (cap & CD_HWCAP2_SME_F16F32)    add(Feature::ARM_SME_F16F32);
  if (cap & CD_HWCAP2_SME_B16F32)    add(Feature::ARM_SME_B16F32);
  if (cap & CD_HWCAP2_SME_F32F32)    add(Feature::ARM_SME_F32F32);
  if (cap & CD_HWCAP2_SME_FA64)      add(Feature::ARM_SME_FA64);
  if (cap & CD_HWCAP2_WFXT)          add(Feature::ARM_WFXT);
  if (cap & CD_HWCAP2_EBF16)         add(Feature::ARM_EBF16);
  if (cap & CD_HWCAP2_SVE_EBF16)     add(Feature::ARM_SVE_EBF16);
  if (cap & CD_HWCAP2_CSSC)          add(Feature::ARM_CSSC);
  if (cap & CD_HWCAP2_RPRFM)         add(Feature::ARM_RPRFM);
  if (cap & CD_HWCAP2_SVE2P1)        add(Feature::ARM_SVE2P1);
  if (cap & CD_HWCAP2_SME2)          add(Feature::ARM_SME2);
  if (cap & CD_HWCAP2_SME2P1)        add(Feature::ARM_SME2P1);
  if (cap & CD_HWCAP2_SME_I16I32)    add(Feature::ARM_SME_I16I32);
  if (cap & CD_HWCAP2_SME_BI32I32)   add(Feature::ARM_SME_BI32I32);
  if (cap & CD_HWCAP2_SME_B16B16)    add(Feature::ARM_SME_B16B16);
  if (cap & CD_HWCAP2_SME_F16F16)    add(Feature::ARM_SME_F16F16);
  if (cap & CD_HWCAP2_MOPS)          add(Feature::ARM_MOPS);
  if (cap & CD_HWCAP2_HBC)           add(Feature::ARM_HBC);
  if (cap & CD_HWCAP2_LRCPC3)        add(Feature::ARM_LRCPC3);
  if (cap & CD_HWCAP2_LSE128)        add(Feature::ARM_LSE128);
}

}  // namespace

void detect_arm(std::vector<Feature>& out) {
  map_linux_hwcap(read_hwcap(1), out);
  map_linux_hwcap2(read_hwcap(2), out);
}

#elif defined(CPU_DISPATCH_ARM) && defined(__APPLE__) && defined(__aarch64__)

namespace {

bool sysctl_bool(const char* name) noexcept {
  int value = 0;
  std::size_t size = sizeof(value);
  if (::sysctlbyname(name, &value, &size, nullptr, 0) != 0) {
    return false;
  }
  return value != 0;
}

}  // namespace

void detect_arm(std::vector<Feature>& out) {
  auto check = [&](const char* name, Feature f) {
    if (sysctl_bool(name)) out.push_back(f);
  };

  // Baseline always-present on Apple silicon.
  out.push_back(Feature::ARM_FP);
  out.push_back(Feature::ARM_ASIMD);

  check("hw.optional.arm.FEAT_AES",        Feature::ARM_AES);
  check("hw.optional.arm.FEAT_PMULL",      Feature::ARM_PMULL);
  check("hw.optional.arm.FEAT_SHA1",       Feature::ARM_SHA1);
  check("hw.optional.arm.FEAT_SHA256",     Feature::ARM_SHA2);
  check("hw.optional.arm.FEAT_SHA512",     Feature::ARM_SHA512);
  check("hw.optional.arm.FEAT_SHA3",       Feature::ARM_SHA3);
  check("hw.optional.arm.FEAT_SM3",        Feature::ARM_SM3);
  check("hw.optional.arm.FEAT_SM4",        Feature::ARM_SM4);
  check("hw.optional.arm.FEAT_CRC32",      Feature::ARM_CRC32);
  check("hw.optional.arm.FEAT_LSE",        Feature::ARM_ATOMICS);
  check("hw.optional.arm.FEAT_LSE2",       Feature::ARM_USCAT);
  check("hw.optional.arm.FEAT_FP16",       Feature::ARM_FPHP);
  check("hw.optional.arm.FEAT_FP16",       Feature::ARM_ASIMDHP);
  check("hw.optional.arm.FEAT_RDM",        Feature::ARM_ASIMDRDM);
  check("hw.optional.arm.FEAT_DotProd",    Feature::ARM_ASIMDDP);
  check("hw.optional.arm.FEAT_JSCVT",      Feature::ARM_JSCVT);
  check("hw.optional.arm.FEAT_FCMA",       Feature::ARM_FCMA);
  check("hw.optional.arm.FEAT_DIT",        Feature::ARM_DIT);
  check("hw.optional.arm.FEAT_DPB",        Feature::ARM_DCPOP);
  check("hw.optional.arm.FEAT_DPB2",       Feature::ARM_DCPODP);
  check("hw.optional.arm.FEAT_LRCPC",      Feature::ARM_LRCPC);
  check("hw.optional.arm.FEAT_LRCPC2",     Feature::ARM_ILRCPC);
  check("hw.optional.arm.FEAT_FRINTTS",    Feature::ARM_FRINT);
  check("hw.optional.arm.FEAT_FlagM",      Feature::ARM_FLAGM);
  check("hw.optional.arm.FEAT_FlagM2",     Feature::ARM_FLAGM2);
  check("hw.optional.arm.FEAT_SSBS",       Feature::ARM_SSBS);
  check("hw.optional.arm.FEAT_SB",         Feature::ARM_SB);
  check("hw.optional.arm.FEAT_BTI",        Feature::ARM_BTI);
  check("hw.optional.arm.FEAT_FHM",        Feature::ARM_ASIMDFHM);
  check("hw.optional.arm.FEAT_BF16",       Feature::ARM_BF16);
  check("hw.optional.arm.FEAT_I8MM",       Feature::ARM_I8MM);
  check("hw.optional.arm.FEAT_ECV",        Feature::ARM_ECV);
  check("hw.optional.arm.FEAT_AFP",        Feature::ARM_AFP);
  check("hw.optional.arm.FEAT_RPRES",      Feature::ARM_RPRES);
  check("hw.optional.arm.FEAT_PAuth",      Feature::ARM_PACA);
  check("hw.optional.arm.FEAT_PAuth",      Feature::ARM_PACG);
  check("hw.optional.arm.FEAT_SME",        Feature::ARM_SME);
  check("hw.optional.arm.FEAT_SME2",       Feature::ARM_SME2);
  check("hw.optional.arm.FEAT_SME_F64F64", Feature::ARM_SME_F64F64);
  check("hw.optional.arm.FEAT_SME_I16I64", Feature::ARM_SME_I16I64);
}

#elif defined(CPU_DISPATCH_ARM) && defined(_WIN32) && (defined(_M_ARM64) || defined(__aarch64__))

namespace {
constexpr unsigned long PF_ARM_NEON                       = 19;
constexpr unsigned long PF_ARM_V8_INSTRUCTIONS            = 29;
constexpr unsigned long PF_ARM_V8_CRYPTO_INSTRUCTIONS     = 30;
constexpr unsigned long PF_ARM_V8_CRC32_INSTRUCTIONS      = 31;
constexpr unsigned long PF_ARM_V81_ATOMIC_INSTRUCTIONS    = 34;
constexpr unsigned long PF_ARM_V82_DP_INSTRUCTIONS        = 43;
constexpr unsigned long PF_ARM_V83_JSCVT_INSTRUCTIONS     = 44;
constexpr unsigned long PF_ARM_V83_LRCPC_INSTRUCTIONS     = 45;
constexpr unsigned long PF_ARM_SVE_INSTRUCTIONS           = 46;
constexpr unsigned long PF_ARM_SVE2_INSTRUCTIONS          = 47;
}  // namespace

void detect_arm(std::vector<Feature>& out) {
  auto add = [&](Feature f) { out.push_back(f); };
  auto have = [](unsigned long pf) { return IsProcessorFeaturePresent(pf) != 0; };

  if (have(PF_ARM_NEON)) { add(Feature::ARM_FP); add(Feature::ARM_ASIMD); }
  if (have(PF_ARM_V8_CRYPTO_INSTRUCTIONS)) {
    add(Feature::ARM_AES);
    add(Feature::ARM_PMULL);
    add(Feature::ARM_SHA1);
    add(Feature::ARM_SHA2);
  }
  if (have(PF_ARM_V8_CRC32_INSTRUCTIONS))   add(Feature::ARM_CRC32);
  if (have(PF_ARM_V81_ATOMIC_INSTRUCTIONS)) add(Feature::ARM_ATOMICS);
  if (have(PF_ARM_V82_DP_INSTRUCTIONS))     add(Feature::ARM_ASIMDDP);
  if (have(PF_ARM_V83_JSCVT_INSTRUCTIONS))  add(Feature::ARM_JSCVT);
  if (have(PF_ARM_V83_LRCPC_INSTRUCTIONS))  add(Feature::ARM_LRCPC);
  if (have(PF_ARM_SVE_INSTRUCTIONS))        add(Feature::ARM_SVE);
  if (have(PF_ARM_SVE2_INSTRUCTIONS))       add(Feature::ARM_SVE2);
}

#else

void detect_arm(std::vector<Feature>&) {}

#endif

}  // namespace goblin_cpu_features
