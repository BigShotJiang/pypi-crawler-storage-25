#include "detect_internal.hpp"

#include <cstdint>

#if defined(__sparc__) || defined(__sparc) || defined(__sparcv9) || defined(__sparcv8)
  #define CPU_DISPATCH_SPARC 1
#endif

#if defined(CPU_DISPATCH_SPARC)
  #if defined(__linux__)
    #include <sys/auxv.h>
    #if __has_include(<asm/elf.h>)
      #include <asm/elf.h>
    #endif
  #elif defined(__sun) || defined(__SVR4) || defined(__svr4__) || defined(__illumos__)
    #include <sys/auxv.h>
    #include <sys/auxv_SPARC.h>
  #endif
#endif

namespace goblin_cpu_features {

#if defined(CPU_DISPATCH_SPARC) && defined(__linux__)

namespace {

// Linux SPARC HWCAP bits (asm/elf.h). Hard-coded to survive missing headers.
constexpr unsigned long CD_SPARC_HWCAP_V9                 = 0x00000010UL;
constexpr unsigned long CD_SPARC_HWCAP_ULTRA3             = 0x00000020UL;
constexpr unsigned long CD_SPARC_HWCAP_BLKINIT            = 0x00000040UL;
constexpr unsigned long CD_SPARC_HWCAP_N2                 = 0x00000080UL;
constexpr unsigned long CD_SPARC_HWCAP_MUL32              = 0x00000100UL;
constexpr unsigned long CD_SPARC_HWCAP_DIV32              = 0x00000200UL;
constexpr unsigned long CD_SPARC_HWCAP_FSMULD             = 0x00000400UL;
constexpr unsigned long CD_SPARC_HWCAP_V8PLUS             = 0x00000800UL;
constexpr unsigned long CD_SPARC_HWCAP_POPC               = 0x00001000UL;
constexpr unsigned long CD_SPARC_HWCAP_VIS                = 0x00002000UL;
constexpr unsigned long CD_SPARC_HWCAP_VIS2               = 0x00004000UL;
constexpr unsigned long CD_SPARC_HWCAP_ASI_BLK_INIT       = 0x00008000UL;
constexpr unsigned long CD_SPARC_HWCAP_FMAF               = 0x00010000UL;
constexpr unsigned long CD_SPARC_HWCAP_VIS3               = 0x00020000UL;
constexpr unsigned long CD_SPARC_HWCAP_HPC                = 0x00040000UL;
constexpr unsigned long CD_SPARC_HWCAP_IMA                = 0x00400000UL;
constexpr unsigned long CD_SPARC_HWCAP_ASI_CACHE_SPARING  = 0x00800000UL;
constexpr unsigned long CD_SPARC_HWCAP_PAUSE              = 0x01000000UL;
constexpr unsigned long CD_SPARC_HWCAP_CBCOND             = 0x02000000UL;
constexpr unsigned long CD_SPARC_HWCAP_CRYPTO             = 0x04000000UL;

}  // namespace

void detect_sparc(std::vector<Feature>& out) {
  const unsigned long cap = ::getauxval(AT_HWCAP);
  auto add = [&](Feature f) { out.push_back(f); };

  if (cap & CD_SPARC_HWCAP_V9)                add(Feature::SPARC_V9);
  if (cap & CD_SPARC_HWCAP_V8PLUS)            add(Feature::SPARC_V8PLUS);
  if (cap & CD_SPARC_HWCAP_ULTRA3)            add(Feature::SPARC_ULTRA3);
  if (cap & CD_SPARC_HWCAP_BLKINIT)           add(Feature::SPARC_BLKINIT);
  if (cap & CD_SPARC_HWCAP_N2)                add(Feature::SPARC_N2);
  if (cap & CD_SPARC_HWCAP_MUL32)             add(Feature::SPARC_MUL32);
  if (cap & CD_SPARC_HWCAP_DIV32)             add(Feature::SPARC_DIV32);
  if (cap & CD_SPARC_HWCAP_FSMULD)            add(Feature::SPARC_FSMULD);
  if (cap & CD_SPARC_HWCAP_POPC)              add(Feature::SPARC_POPC);
  if (cap & CD_SPARC_HWCAP_VIS)               add(Feature::SPARC_VIS);
  if (cap & CD_SPARC_HWCAP_VIS2)              add(Feature::SPARC_VIS2);
  if (cap & CD_SPARC_HWCAP_VIS3)              add(Feature::SPARC_VIS3);
  if (cap & CD_SPARC_HWCAP_FMAF)              add(Feature::SPARC_FMAF);
  if (cap & CD_SPARC_HWCAP_HPC)               add(Feature::SPARC_HPC);
  if (cap & CD_SPARC_HWCAP_IMA)               add(Feature::SPARC_IMA);
  if (cap & CD_SPARC_HWCAP_ASI_BLK_INIT)      add(Feature::SPARC_ASI_BLK_INIT);
  if (cap & CD_SPARC_HWCAP_ASI_CACHE_SPARING) add(Feature::SPARC_ASI_CACHE_SPARING);
  if (cap & CD_SPARC_HWCAP_PAUSE)             add(Feature::SPARC_PAUSE);
  if (cap & CD_SPARC_HWCAP_CBCOND)            add(Feature::SPARC_CBCOND);

  // Linux exposes the full SPARC crypto block as one HWCAP bit; expand it
  // to the per-algorithm features so consumers don't have to special-case
  // Linux vs Solaris.
  if (cap & CD_SPARC_HWCAP_CRYPTO) {
    add(Feature::SPARC_AES);
    add(Feature::SPARC_DES);
    add(Feature::SPARC_KASUMI);
    add(Feature::SPARC_CAMELLIA);
    add(Feature::SPARC_MD5);
    add(Feature::SPARC_SHA1);
    add(Feature::SPARC_SHA256);
    add(Feature::SPARC_SHA512);
    add(Feature::SPARC_MPMUL);
    add(Feature::SPARC_MONT);
    add(Feature::SPARC_CRC32C);
  }
}

#elif defined(CPU_DISPATCH_SPARC) && (defined(__sun) || defined(__SVR4) || defined(__svr4__))

namespace {

// AV_SPARC_* bits in the first uint32_t returned by getisax(). Solaris's
// header exposes these; we fall back to constants if the macros vary.
constexpr std::uint32_t CD_AV_MUL32           = 0x00000001U;
constexpr std::uint32_t CD_AV_DIV32           = 0x00000002U;
constexpr std::uint32_t CD_AV_FSMULD          = 0x00000004U;
constexpr std::uint32_t CD_AV_V8PLUS          = 0x00000008U;
constexpr std::uint32_t CD_AV_POPC            = 0x00000010U;
constexpr std::uint32_t CD_AV_VIS             = 0x00000020U;
constexpr std::uint32_t CD_AV_VIS2            = 0x00000040U;
constexpr std::uint32_t CD_AV_ASI_BLK_INIT    = 0x00000080U;
constexpr std::uint32_t CD_AV_FMAF            = 0x00000100U;
constexpr std::uint32_t CD_AV_VIS3            = 0x00000400U;
constexpr std::uint32_t CD_AV_HPC             = 0x00000800U;
constexpr std::uint32_t CD_AV_IMA             = 0x00008000U;
constexpr std::uint32_t CD_AV_ASI_CACHE_SPAR  = 0x00010000U;
constexpr std::uint32_t CD_AV_AES             = 0x00020000U;
constexpr std::uint32_t CD_AV_DES             = 0x00040000U;
constexpr std::uint32_t CD_AV_KASUMI          = 0x00080000U;
constexpr std::uint32_t CD_AV_CAMELLIA        = 0x00100000U;
constexpr std::uint32_t CD_AV_MD5             = 0x00200000U;
constexpr std::uint32_t CD_AV_SHA1            = 0x00400000U;
constexpr std::uint32_t CD_AV_SHA256          = 0x00800000U;
constexpr std::uint32_t CD_AV_SHA512          = 0x01000000U;
constexpr std::uint32_t CD_AV_MPMUL           = 0x02000000U;
constexpr std::uint32_t CD_AV_MONT            = 0x04000000U;
constexpr std::uint32_t CD_AV_PAUSE           = 0x08000000U;
constexpr std::uint32_t CD_AV_CBCOND          = 0x10000000U;
constexpr std::uint32_t CD_AV_CRC32C          = 0x20000000U;

// AV2_SPARC_* bits in the second uint32_t.
constexpr std::uint32_t CD_AV2_VIS3B          = 0x00000002U;
constexpr std::uint32_t CD_AV2_OOORW          = 0x00020000U;
constexpr std::uint32_t CD_AV2_VIS4           = 0x00080000U;

}  // namespace

void detect_sparc(std::vector<Feature>& out) {
  std::uint32_t avs[4] = {0, 0, 0, 0};
  const unsigned int n = ::getisax(avs, 4);
  if (n == 0) return;
  const std::uint32_t a = avs[0];
  const std::uint32_t b = (n >= 2) ? avs[1] : 0;

  auto add = [&](Feature f) { out.push_back(f); };

  // V9 is implicit on every Solaris SPARC system we'd care about; getisax
  // doesn't expose a V9 bit, so we assert it directly.
  add(Feature::SPARC_V9);

  if (a & CD_AV_MUL32)          add(Feature::SPARC_MUL32);
  if (a & CD_AV_DIV32)          add(Feature::SPARC_DIV32);
  if (a & CD_AV_FSMULD)         add(Feature::SPARC_FSMULD);
  if (a & CD_AV_V8PLUS)         add(Feature::SPARC_V8PLUS);
  if (a & CD_AV_POPC)           add(Feature::SPARC_POPC);
  if (a & CD_AV_VIS)            add(Feature::SPARC_VIS);
  if (a & CD_AV_VIS2)           add(Feature::SPARC_VIS2);
  if (a & CD_AV_VIS3)           add(Feature::SPARC_VIS3);
  if (a & CD_AV_ASI_BLK_INIT)   add(Feature::SPARC_ASI_BLK_INIT);
  if (a & CD_AV_FMAF)           add(Feature::SPARC_FMAF);
  if (a & CD_AV_HPC)            add(Feature::SPARC_HPC);
  if (a & CD_AV_IMA)            add(Feature::SPARC_IMA);
  if (a & CD_AV_ASI_CACHE_SPAR) add(Feature::SPARC_ASI_CACHE_SPARING);
  if (a & CD_AV_AES)            add(Feature::SPARC_AES);
  if (a & CD_AV_DES)            add(Feature::SPARC_DES);
  if (a & CD_AV_KASUMI)         add(Feature::SPARC_KASUMI);
  if (a & CD_AV_CAMELLIA)       add(Feature::SPARC_CAMELLIA);
  if (a & CD_AV_MD5)            add(Feature::SPARC_MD5);
  if (a & CD_AV_SHA1)           add(Feature::SPARC_SHA1);
  if (a & CD_AV_SHA256)         add(Feature::SPARC_SHA256);
  if (a & CD_AV_SHA512)         add(Feature::SPARC_SHA512);
  if (a & CD_AV_MPMUL)          add(Feature::SPARC_MPMUL);
  if (a & CD_AV_MONT)           add(Feature::SPARC_MONT);
  if (a & CD_AV_PAUSE)          add(Feature::SPARC_PAUSE);
  if (a & CD_AV_CBCOND)         add(Feature::SPARC_CBCOND);
  if (a & CD_AV_CRC32C)         add(Feature::SPARC_CRC32C);

  if (b & CD_AV2_VIS3B)         add(Feature::SPARC_VIS3B);
  if (b & CD_AV2_VIS4)          add(Feature::SPARC_VIS4);
  if (b & CD_AV2_OOORW)         add(Feature::SPARC_OOORW);
}

#else

void detect_sparc(std::vector<Feature>&) {}

#endif

}  // namespace goblin_cpu_features
