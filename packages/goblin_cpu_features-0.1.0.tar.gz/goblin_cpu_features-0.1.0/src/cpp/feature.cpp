#include "feature.hpp"

namespace goblin_cpu_features {

std::string_view feature_name(Feature f) noexcept {
  switch (f) {
#define GOBLIN_CPU_FEATURE(name) \
  case Feature::name:              \
    return #name;
#include "features.def"
#undef GOBLIN_CPU_FEATURE
  }
  return "";
}

}  // namespace goblin_cpu_features
