#include "detect_internal.hpp"

#if defined(__loongarch__) || defined(__loongarch64)
  #define CPU_DISPATCH_LOONGARCH 1
#endif

#if defined(CPU_DISPATCH_LOONGARCH) && defined(__linux__)
  #include <sys/auxv.h>
  #if __has_include(<asm/hwcap.h>)
    #include <asm/hwcap.h>
  #endif
#endif

namespace goblin_cpu_features {

#if defined(CPU_DISPATCH_LOONGARCH) && defined(__linux__)

namespace {

constexpr unsigned long CD_HWCAP_LA_CPUCFG    = 1UL << 0;
constexpr unsigned long CD_HWCAP_LA_LAM       = 1UL << 1;
constexpr unsigned long CD_HWCAP_LA_UAL       = 1UL << 2;
constexpr unsigned long CD_HWCAP_LA_FPU       = 1UL << 3;
constexpr unsigned long CD_HWCAP_LA_LSX       = 1UL << 4;
constexpr unsigned long CD_HWCAP_LA_LASX      = 1UL << 5;
constexpr unsigned long CD_HWCAP_LA_CRC32     = 1UL << 6;
constexpr unsigned long CD_HWCAP_LA_COMPLEX   = 1UL << 7;
constexpr unsigned long CD_HWCAP_LA_CRYPTO    = 1UL << 8;
constexpr unsigned long CD_HWCAP_LA_LVZ       = 1UL << 9;
constexpr unsigned long CD_HWCAP_LA_LBT_X86   = 1UL << 10;
constexpr unsigned long CD_HWCAP_LA_LBT_ARM   = 1UL << 11;
constexpr unsigned long CD_HWCAP_LA_LBT_MIPS  = 1UL << 12;
constexpr unsigned long CD_HWCAP_LA_PTW       = 1UL << 13;

}  // namespace

void detect_loongarch(std::vector<Feature>& out) {
  const unsigned long cap = ::getauxval(AT_HWCAP);
  auto add = [&](Feature f) { out.push_back(f); };
  if (cap & CD_HWCAP_LA_CPUCFG)   add(Feature::LA_CPUCFG);
  if (cap & CD_HWCAP_LA_LAM)      add(Feature::LA_LAM);
  if (cap & CD_HWCAP_LA_UAL)      add(Feature::LA_UAL);
  if (cap & CD_HWCAP_LA_FPU)      add(Feature::LA_FPU);
  if (cap & CD_HWCAP_LA_LSX)      add(Feature::LA_LSX);
  if (cap & CD_HWCAP_LA_LASX)     add(Feature::LA_LASX);
  if (cap & CD_HWCAP_LA_CRC32)    add(Feature::LA_CRC32);
  if (cap & CD_HWCAP_LA_COMPLEX)  add(Feature::LA_COMPLEX);
  if (cap & CD_HWCAP_LA_CRYPTO)   add(Feature::LA_CRYPTO);
  if (cap & CD_HWCAP_LA_LVZ)      add(Feature::LA_LVZ);
  if (cap & CD_HWCAP_LA_LBT_X86)  add(Feature::LA_LBT_X86);
  if (cap & CD_HWCAP_LA_LBT_ARM)  add(Feature::LA_LBT_ARM);
  if (cap & CD_HWCAP_LA_LBT_MIPS) add(Feature::LA_LBT_MIPS);
  if (cap & CD_HWCAP_LA_PTW)      add(Feature::LA_PTW);
}

#else

void detect_loongarch(std::vector<Feature>&) {}

#endif

}  // namespace goblin_cpu_features
