#include <nanobind/nanobind.h>
#include <nanobind/stl/string.h>
#include <nanobind/stl/vector.h>

#include <string>
#include <string_view>

#include "feature.hpp"

namespace nb = nanobind;
using goblin_cpu_features::Feature;

NB_MODULE(_native, m) {
  m.doc() =
      "Internal CPU feature detection backend for the goblin_cpu_features package. "
      "Prefer the public API in `goblin_cpu_features` (detect(), Feature, "
      "feature_from_name()).";

  auto enum_builder = nb::enum_<Feature>(m, "Feature");
#define GOBLIN_CPU_FEATURE(name) enum_builder.value(#name, Feature::name);
#include "features.def"
#undef GOBLIN_CPU_FEATURE

  m.def(
      "detect_features",
      []() {
        const auto v = goblin_cpu_features::detect_features();
        return v;
      },
      "Return the deduplicated, sorted list of CPU features the running host "
      "supports.");

  m.def(
      "feature_name",
      [](Feature f) {
        const std::string_view sv = goblin_cpu_features::feature_name(f);
        return std::string(sv);
      },
      nb::arg("feature"),
      "Return the canonical name of a Feature value (e.g. 'X86_AVX2').");

  m.def(
      "feature_count",
      []() { return static_cast<std::uint64_t>(goblin_cpu_features::feature_count()); },
      "Number of Feature values exposed by this build.");
}
