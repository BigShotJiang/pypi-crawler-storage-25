#pragma once

#include <vector>

#include "feature.hpp"

namespace goblin_cpu_features {

void detect_x86(std::vector<Feature>& out);
void detect_arm(std::vector<Feature>& out);
void detect_loongarch(std::vector<Feature>& out);
void detect_powerpc(std::vector<Feature>& out);
void detect_riscv(std::vector<Feature>& out);
void detect_sparc(std::vector<Feature>& out);

}  // namespace goblin_cpu_features
