#include "detect_internal.hpp"

#if defined(__powerpc64__) || defined(__ppc64__) || defined(__PPC64__) || \
    defined(__powerpc__) || defined(__ppc__) || defined(__PPC__)
  #define CPU_DISPATCH_PPC 1
#endif

#if defined(CPU_DISPATCH_PPC) && defined(__linux__)
  #include <sys/auxv.h>
  #if __has_include(<asm/cputable.h>)
    #include <asm/cputable.h>
  #endif
#elif defined(CPU_DISPATCH_PPC) && defined(__FreeBSD__)
  #include <sys/auxv.h>
  #include <sys/elf_common.h>
#endif

namespace goblin_cpu_features {

#if defined(CPU_DISPATCH_PPC) && (defined(__linux__) || defined(__FreeBSD__))

namespace {

// AT_HWCAP / AT_HWCAP2 bit definitions for PowerPC (Linux). Hard-coding the
// values keeps us robust against headers that omit newer bits.
constexpr unsigned long CD_PPC_FEATURE_32                 = 0x80000000UL;
constexpr unsigned long CD_PPC_FEATURE_64                 = 0x40000000UL;
constexpr unsigned long CD_PPC_FEATURE_HAS_ALTIVEC        = 0x10000000UL;
constexpr unsigned long CD_PPC_FEATURE_HAS_FPU            = 0x08000000UL;
constexpr unsigned long CD_PPC_FEATURE_HAS_MMU            = 0x04000000UL;
constexpr unsigned long CD_PPC_FEATURE_NO_TB              = 0x00100000UL;
constexpr unsigned long CD_PPC_FEATURE_POWER4             = 0x00080000UL;
constexpr unsigned long CD_PPC_FEATURE_POWER5             = 0x00040000UL;
constexpr unsigned long CD_PPC_FEATURE_POWER5_PLUS        = 0x00020000UL;
constexpr unsigned long CD_PPC_FEATURE_CELL_BE            = 0x00010000UL;
constexpr unsigned long CD_PPC_FEATURE_BOOKE              = 0x00008000UL;
constexpr unsigned long CD_PPC_FEATURE_SMT                = 0x00004000UL;
constexpr unsigned long CD_PPC_FEATURE_ICACHE_SNOOP       = 0x00002000UL;
constexpr unsigned long CD_PPC_FEATURE_ARCH_2_05          = 0x00001000UL;
constexpr unsigned long CD_PPC_FEATURE_PA6T               = 0x00000800UL;
constexpr unsigned long CD_PPC_FEATURE_HAS_DFP            = 0x00000400UL;
constexpr unsigned long CD_PPC_FEATURE_POWER6_EXT         = 0x00000200UL;
constexpr unsigned long CD_PPC_FEATURE_ARCH_2_06          = 0x00000100UL;
constexpr unsigned long CD_PPC_FEATURE_HAS_VSX            = 0x00000080UL;
constexpr unsigned long CD_PPC_FEATURE_TRUE_LE            = 0x00000002UL;

constexpr unsigned long CD_PPC_FEATURE2_ARCH_2_07         = 0x80000000UL;
constexpr unsigned long CD_PPC_FEATURE2_HTM               = 0x40000000UL;
constexpr unsigned long CD_PPC_FEATURE2_DSCR              = 0x20000000UL;
constexpr unsigned long CD_PPC_FEATURE2_EBB               = 0x10000000UL;
constexpr unsigned long CD_PPC_FEATURE2_ISEL              = 0x08000000UL;
constexpr unsigned long CD_PPC_FEATURE2_TAR               = 0x04000000UL;
constexpr unsigned long CD_PPC_FEATURE2_VEC_CRYPTO        = 0x02000000UL;
constexpr unsigned long CD_PPC_FEATURE2_HTM_NOSC          = 0x01000000UL;
constexpr unsigned long CD_PPC_FEATURE2_ARCH_3_00         = 0x00800000UL;
constexpr unsigned long CD_PPC_FEATURE2_HAS_IEEE128       = 0x00400000UL;
constexpr unsigned long CD_PPC_FEATURE2_DARN              = 0x00200000UL;
constexpr unsigned long CD_PPC_FEATURE2_SCV               = 0x00100000UL;
constexpr unsigned long CD_PPC_FEATURE2_HTM_NO_SUSPEND    = 0x00080000UL;
constexpr unsigned long CD_PPC_FEATURE2_ARCH_3_1          = 0x00040000UL;
constexpr unsigned long CD_PPC_FEATURE2_MMA               = 0x00020000UL;

unsigned long read_aux(int which) noexcept {
#if defined(__linux__)
  return ::getauxval(which == 2 ? AT_HWCAP2 : AT_HWCAP);
#elif defined(__FreeBSD__)
  unsigned long val = 0;
  ::elf_aux_info(which == 2 ? AT_HWCAP2 : AT_HWCAP, &val, sizeof(val));
  return val;
#else
  (void)which;
  return 0;
#endif
}

}  // namespace

void detect_powerpc(std::vector<Feature>& out) {
  const unsigned long h1 = read_aux(1);
  const unsigned long h2 = read_aux(2);
  auto add = [&](Feature f) { out.push_back(f); };

  if (h1 & CD_PPC_FEATURE_HAS_ALTIVEC)   add(Feature::PPC_ALTIVEC);
  if (h1 & CD_PPC_FEATURE_HAS_VSX)       add(Feature::PPC_VSX);
  if (h1 & CD_PPC_FEATURE_ARCH_2_05)     add(Feature::PPC_ARCH_2_05);
  if (h1 & CD_PPC_FEATURE_ARCH_2_06)     add(Feature::PPC_ARCH_2_06);
  if (h1 & CD_PPC_FEATURE_HAS_DFP)       add(Feature::PPC_DFP);
  if (h1 & CD_PPC_FEATURE_ICACHE_SNOOP)  add(Feature::PPC_ICACHE_SNOOP);

  if (h2 & CD_PPC_FEATURE2_ARCH_2_07)    add(Feature::PPC_ARCH_2_07);
  if (h2 & CD_PPC_FEATURE2_ARCH_3_00)    add(Feature::PPC_ARCH_3_00);
  if (h2 & CD_PPC_FEATURE2_ARCH_3_1)     add(Feature::PPC_ARCH_3_1);
  if (h2 & CD_PPC_FEATURE2_HTM)          add(Feature::PPC_HTM);
  if (h2 & CD_PPC_FEATURE2_DSCR)         add(Feature::PPC_DSCR);
  if (h2 & CD_PPC_FEATURE2_EBB)          add(Feature::PPC_EBB);
  if (h2 & CD_PPC_FEATURE2_ISEL)         add(Feature::PPC_ISEL);
  if (h2 & CD_PPC_FEATURE2_TAR)          add(Feature::PPC_TAR);
  if (h2 & CD_PPC_FEATURE2_VEC_CRYPTO)   add(Feature::PPC_VCRYPTO);
  if (h2 & CD_PPC_FEATURE2_HAS_IEEE128)  add(Feature::PPC_IEEE128);
  if (h2 & CD_PPC_FEATURE2_DARN)         add(Feature::PPC_DARN);
  if (h2 & CD_PPC_FEATURE2_SCV)          add(Feature::PPC_SCV);
  if (h2 & CD_PPC_FEATURE2_MMA)          add(Feature::PPC_MMA);
}

#else

void detect_powerpc(std::vector<Feature>&) {}

#endif

}  // namespace goblin_cpu_features
