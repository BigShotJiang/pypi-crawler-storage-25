"""Cross-platform CPU feature detection.

The single entry point is :func:`detect`, which returns a ``frozenset`` of
:class:`Feature` values describing the CPU's actual hardware capabilities
(SIMD, crypto, atomics, microarchitectural quirks, etc.) on the running host.

Consumer packages use the result to choose which of their compiled backend
modules to import::

    import goblin_cpu_features as cpu

    features = cpu.detect()
    if {cpu.Feature.X86_AVX2, cpu.Feature.X86_FMA}.issubset(features):
        from mypkg import _avx2 as impl
    elif cpu.Feature.ARM_SVE2 in features:
        from mypkg import _sve2 as impl
    else:
        from mypkg import _generic as impl

goblin_cpu_features never chooses a backend itself; it only reports host CPU
features.
"""

from __future__ import annotations

from . import _native
from ._native import Feature

__all__ = ["Feature", "detect", "feature_from_name", "feature_count"]


def detect() -> frozenset[Feature]:
    """Return the set of CPU features supported by the running host."""
    return frozenset(_native.detect_features())


def feature_from_name(name: str) -> Feature:
    """Look up a :class:`Feature` by its canonical name (e.g. ``"X86_AVX2"``).

    Raises ``KeyError`` if no such feature exists in this build.
    """
    try:
        return Feature.__members__[name]
    except KeyError as exc:
        raise KeyError(f"unknown CPU feature name: {name!r}") from exc


def feature_count() -> int:
    """Number of distinct :class:`Feature` values this build knows about."""
    return int(_native.feature_count())
