from __future__ import annotations

import platform

import pytest

import goblin_cpu_features
from goblin_cpu_features import Feature


def test_detect_returns_frozenset_of_features():
    result = goblin_cpu_features.detect()
    assert isinstance(result, frozenset)
    for item in result:
        assert isinstance(item, Feature)


def test_detect_is_idempotent():
    assert goblin_cpu_features.detect() == goblin_cpu_features.detect()


def test_feature_count_matches_enum_members():
    assert goblin_cpu_features.feature_count() == len(Feature.__members__)


def test_feature_from_name_roundtrips():
    for name, value in Feature.__members__.items():
        assert goblin_cpu_features.feature_from_name(name) is value


def test_feature_from_name_unknown_raises():
    with pytest.raises(KeyError):
        goblin_cpu_features.feature_from_name("NOT_A_REAL_FEATURE")


def test_native_feature_name_matches_enum_name():
    from goblin_cpu_features import _native

    for name, value in Feature.__members__.items():
        assert _native.feature_name(value) == name


def test_no_isa_crosstalk():
    """A given machine should only report features from its actual ISA family.

    A real x86_64 host will not report ARM_* features, and vice versa. This
    catches bugs where a detection TU's #ifdef gate fails open.
    """
    feats = goblin_cpu_features.detect()
    machine = platform.machine().lower()

    prefix_families = {
        "x86": ("x86_64", "amd64", "i386", "i686"),
        "arm": ("aarch64", "arm64", "armv7l", "armv8"),
        "la": ("loongarch64",),
        "ppc": ("ppc64", "ppc64le", "powerpc64"),
        "rv": ("riscv64", "riscv32"),
        "sparc": ("sparc", "sparc64", "sun4v", "sun4u"),
    }

    expected_prefix = None
    for prefix, machines in prefix_families.items():
        if any(machine.startswith(m) or machine == m for m in machines):
            expected_prefix = prefix.upper() + "_"
            break

    if expected_prefix is None:
        pytest.skip(f"unrecognized platform.machine()={machine!r}")

    for f in feats:
        assert f.name.startswith(expected_prefix), (
            f"feature {f.name} reported on host with machine={machine!r}; "
            f"expected only {expected_prefix}* features"
        )


def test_avx512_quirk_flags_imply_avx512f():
    """Synthetic AVX-512 quirk flags must never be set without real AVX-512."""
    feats = goblin_cpu_features.detect()
    if Feature.X86_DOWNCLOCKS_ON_AVX512 in feats or Feature.X86_SLOW_AVX512 in feats:
        assert Feature.X86_AVX512F in feats


def test_rv_v_consistency():
    """RV_V is shorthand: present iff one of the version-specific flags is."""
    feats = goblin_cpu_features.detect()
    has_versioned = (Feature.RV_V_1_0 in feats) or (Feature.RV_V_0_7 in feats)
    has_generic = Feature.RV_V in feats
    # RV_V_1_0 implies RV_V; RV_V_0_7 does not (incompatible ISA).
    if Feature.RV_V_1_0 in feats:
        assert has_generic
    if not has_versioned:
        assert not has_generic
