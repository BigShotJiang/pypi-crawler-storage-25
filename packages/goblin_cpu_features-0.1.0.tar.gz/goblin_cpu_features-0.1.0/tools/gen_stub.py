#!/usr/bin/env python3
"""Generate src/goblin_cpu_features/_native.pyi from src/cpp/features.def.

Run during CMake configure so the Python stub never drifts from the C++
X-macro list.

Usage: gen_stub.py <features.def> <output.pyi>
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

PATTERN = re.compile(r"^\s*GOBLIN_CPU_FEATURE\(\s*([A-Za-z0-9_]+)\s*\)\s*$")


def read_features(path: Path) -> list[str]:
    names: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        m = PATTERN.match(line)
        if m:
            names.append(m.group(1))
    if not names:
        raise SystemExit(f"no GOBLIN_CPU_FEATURE entries found in {path}")
    return names


def render(names: list[str]) -> str:
    out: list[str] = []
    out.append('"""Auto-generated stubs for goblin_cpu_features._native — do not edit."""')
    out.append("")
    out.append("from __future__ import annotations")
    out.append("")
    out.append("import enum")
    out.append("")
    out.append("class Feature(enum.Enum):")
    for name in names:
        out.append(f"    {name}: Feature")
    out.append("")
    out.append("def detect_features() -> list[Feature]: ...")
    out.append("def feature_name(feature: Feature) -> str: ...")
    out.append("def feature_count() -> int: ...")
    out.append("")
    return "\n".join(out)


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print(__doc__, file=sys.stderr)
        return 2
    src = Path(argv[1])
    dst = Path(argv[2])
    names = read_features(src)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(render(names), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
