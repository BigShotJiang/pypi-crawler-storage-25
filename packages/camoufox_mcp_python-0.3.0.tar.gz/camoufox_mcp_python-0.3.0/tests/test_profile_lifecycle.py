import tempfile
import unittest
from pathlib import Path

from camoufox_mcp.__main__ import build_parser
from camoufox_mcp.config import CamoufoxConfig
from camoufox_mcp.context import AppContext


class ProfileConfigTests(unittest.TestCase):
    def test_default_cli_uses_ephemeral_profile(self) -> None:
        args = build_parser().parse_args([])

        config = CamoufoxConfig.from_cli_args(args)

        self.assertIsNone(config.user_data_dir)
        self.assertFalse(config.user_data_dir_explicit)

    def test_explicit_user_data_dir_is_preserved(self) -> None:
        args = build_parser().parse_args(["--user-data-dir", "/tmp/camoufox-profile"])

        config = CamoufoxConfig.from_cli_args(args)

        self.assertEqual(config.user_data_dir, Path("/tmp/camoufox-profile"))
        self.assertTrue(config.user_data_dir_explicit)


class AppContextProfileLifecycleTests(unittest.TestCase):
    def test_ephemeral_profile_dir_is_created_and_cleaned_up(self) -> None:
        config = CamoufoxConfig(user_data_dir=None, user_data_dir_explicit=False)
        app = AppContext(config)

        profile_dir = app._resolve_user_data_dir()

        self.assertTrue(profile_dir.exists())
        self.assertIsNotNone(app._ephemeral_user_data_dir)
        self.assertEqual(profile_dir, app._resolve_user_data_dir())

        app._cleanup_ephemeral_user_data_dir()

        self.assertFalse(profile_dir.exists())
        self.assertIsNone(app._ephemeral_user_data_dir)

    def test_explicit_profile_dir_is_reused_and_not_cleaned(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            explicit_dir = Path(temp_dir) / "profile"
            config = CamoufoxConfig(user_data_dir=explicit_dir, user_data_dir_explicit=True)
            app = AppContext(config)

            profile_dir = app._resolve_user_data_dir()
            app._cleanup_ephemeral_user_data_dir()

            self.assertEqual(profile_dir, explicit_dir)
            self.assertTrue(profile_dir.exists())
            self.assertIsNone(app._ephemeral_user_data_dir)


if __name__ == "__main__":
    unittest.main()
