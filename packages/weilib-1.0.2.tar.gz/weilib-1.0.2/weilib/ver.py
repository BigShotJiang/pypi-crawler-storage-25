class Ver:
    version = '1.0.0'
    
    def get_version():
        return Ver.version