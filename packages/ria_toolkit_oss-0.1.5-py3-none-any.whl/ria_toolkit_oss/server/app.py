"""FastAPI application factory for the RT-OSS HTTP server."""

from fastapi import Depends, FastAPI

from .auth import require_api_key
from .routers import inference, orchestrator


def create_app(api_key: str = "") -> FastAPI:
    """Create and configure the RT-OSS FastAPI application.

    Args:
        api_key: Secret key required in the ``X-API-Key`` request header.
            Pass an empty string to disable authentication (development only).

    Returns:
        Configured FastAPI application instance.
    """
    app = FastAPI(
        title="RIA Toolkit OSS Server",
        version="0.1.0",
        description=(
            "HTTP API for RT-OSS campaign orchestration and RF zone inference. "
            "All endpoints (except /health) require the X-API-Key header when "
            "an API key is configured."
        ),
    )
    app.state.api_key = api_key

    app.include_router(
        orchestrator.router,
        prefix="/orchestrator",
        tags=["Orchestrator"],
        dependencies=[Depends(require_api_key)],
    )
    app.include_router(
        inference.router,
        prefix="/inference",
        tags=["Inference"],
        dependencies=[Depends(require_api_key)],
    )

    @app.get("/health", tags=["Health"])
    async def health():
        """Health check — always returns 200."""
        return {"status": "ok"}

    return app
