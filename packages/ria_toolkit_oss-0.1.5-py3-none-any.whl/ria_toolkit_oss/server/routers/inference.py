"""Inference routes: model loading, inference loop control, and status polling."""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path

import numpy as np
from fastapi import APIRouter, HTTPException, status
from scipy.special import softmax

from ..models import (
    ConfigureRequest,
    ConfigureResponse,
    InferenceStatusResponse,
    LoadModelRequest,
    LoadModelResponse,
    StartInferenceRequest,
    StartInferenceResponse,
    StopInferenceResponse,
)
from ..state import InferenceState, get_inference, set_inference

router = APIRouter()
logger = logging.getLogger(__name__)

_INFERENCE_NUM_SAMPLES = 4096

# Prediction labels that mean "no signal detected" — UI should treat these as idle.
_IDLE_LABELS: frozenset[str] = frozenset({"noise", "idle", "no_signal", "unknown_protocol", "background"})


def _load_onnx_session(model_path: str):
    try:
        import onnxruntime as ort
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="onnxruntime not installed. Install with: pip install ria-toolkit-oss[server]",
        )
    resolved = Path(model_path).resolve()
    if not resolved.is_file():
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Model file not found: {model_path}",
        )
    try:
        return ort.InferenceSession(str(resolved), providers=["CPUExecutionProvider"])
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Failed to load ONNX model: {e}")


def _preprocess_samples(samples: np.ndarray, expected_shape: tuple) -> np.ndarray:
    """Reshape complex IQ samples to float32 matching the model's expected input.

    Supports ``(batch, 2*N)`` interleaved and ``(batch, 2, N)`` two-channel conventions.
    """
    iq = samples.astype(np.complex64)
    i_ch, q_ch = iq.real, iq.imag

    if len(expected_shape) == 2:
        n = expected_shape[1] // 2
        interleaved = np.empty(expected_shape[1], dtype=np.float32)
        interleaved[0::2] = i_ch[:n]
        interleaved[1::2] = q_ch[:n]
        return interleaved.reshape(1, -1)
    elif len(expected_shape) == 3:
        n = expected_shape[2]
        return np.stack([i_ch[:n], q_ch[:n]], axis=0).astype(np.float32).reshape(1, 2, n)
    else:
        raise ValueError(f"Unsupported model input shape: {expected_shape}")


def _stop_current_inference(state: InferenceState, timeout: float = 5.0) -> None:
    state.stop_event.set()
    if state.thread and state.thread.is_alive():
        state.thread.join(timeout=timeout)
        if state.thread.is_alive():
            logger.warning("Inference thread did not stop within %.1fs; SDR resources may not be released", timeout)


def _apply_sdr_config(sdr, config: dict) -> None:
    """Re-initialise the SDR receiver with updated parameters."""
    gain = config.get("gain")
    if gain == "auto":
        gain = None
    elif gain is not None:
        gain = float(gain)
    kwargs: dict = {}
    if config.get("center_freq") is not None:
        kwargs["center_frequency"] = float(config["center_freq"])
    if config.get("sample_rate") is not None:
        kwargs["sample_rate"] = float(config["sample_rate"])
    if gain is not None:
        kwargs["gain"] = gain
    if kwargs:
        sdr.init_rx(**kwargs, channel=0)


def _inference_loop(state: InferenceState, sdr) -> None:
    from ria_toolkit_oss.orchestration.qa import estimate_snr_db

    state.sdr = sdr
    state.set_running(True)
    session = state.session
    input_name = session.get_inputs()[0].name
    expected_shape = tuple(
        d if isinstance(d, int) and d > 0 else _INFERENCE_NUM_SAMPLES for d in session.get_inputs()[0].shape
    )

    try:
        while not state.stop_event.is_set():
            # Apply any pending SDR reconfiguration before the next capture.
            pending = state.pop_pending_config()
            if pending:
                try:
                    _apply_sdr_config(sdr, pending)
                except Exception as exc:
                    logger.warning("SDR reconfigure failed: %s", exc)

            recording = sdr.record(num_samples=_INFERENCE_NUM_SAMPLES)
            samples = recording.data[0] if recording.data.ndim > 1 else recording.data
            snr_db = estimate_snr_db(samples)

            try:
                model_input = _preprocess_samples(samples, expected_shape)
                logits = session.run(None, {input_name: model_input})[0][0].astype(np.float32)
                probs = softmax(logits)
                pred_idx = int(np.argmax(probs))
                prediction = state.index_to_label.get(pred_idx, str(pred_idx))
            except Exception as exc:
                logger.warning("Inference prediction failed: %s", exc)
                continue

            is_idle = prediction in _IDLE_LABELS

            state.set_latest(
                {
                    "timestamp": time.time(),
                    "idle": is_idle,
                    "device_id": prediction if not is_idle else None,
                    "confidence": round(float(probs[pred_idx]), 4),
                    "snr_db": round(snr_db, 2),
                }
            )
    finally:
        state.sdr = None
        try:
            sdr.close()
        except Exception:
            pass
        state.set_running(False)


@router.post("/load", response_model=LoadModelResponse)
async def load_model(request: LoadModelRequest):
    """Load an ONNX model. Stops any running inference first.

    ``label_map`` maps class names to integer indices (e.g. ``{"iphone13_wifi_001": 0}``).
    ``enrolled_devices`` enriches status responses with human names and authorization flags.
    """
    existing = get_inference()
    if existing and existing.get_running():
        _stop_current_inference(existing)

    session = _load_onnx_session(request.model_path)
    set_inference(
        InferenceState(
            model_path=request.model_path,
            label_map=request.label_map,
            index_to_label={v: k for k, v in request.label_map.items()},
            session=session,
        )
    )
    return LoadModelResponse(loaded=True, model_path=request.model_path, num_classes=len(request.label_map))


@router.post("/start", response_model=StartInferenceResponse)
async def start_inference(request: StartInferenceRequest):
    """Start continuous inference. Requires a model to be loaded first."""
    state = get_inference()
    if not state:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="No model loaded. Call POST /inference/load first."
        )
    if state.get_running():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Inference is already running.")

    try:
        from ria_toolkit_oss.orchestration.executor import _DEVICE_ALIASES
        from ria_toolkit_oss.sdr import get_sdr_device
    except ImportError as e:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=f"SDR import failed: {e}")

    sdr_cfg = request.sdr_config
    # Merge any pending configure request on top of the start config.
    pending = state.pop_pending_config() or {}
    center_freq = float(pending.get("center_freq") or sdr_cfg.center_freq)
    sample_rate = float(pending.get("sample_rate") or sdr_cfg.sample_rate)
    raw_gain = pending.get("gain") if "gain" in pending else sdr_cfg.gain
    gain = None if raw_gain == "auto" else float(raw_gain)
    try:
        sdr = get_sdr_device(_DEVICE_ALIASES.get(sdr_cfg.device.lower(), sdr_cfg.device.lower()))
        sdr.init_rx(sample_rate=sample_rate, center_frequency=center_freq, gain=gain, channel=0)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"SDR initialisation failed: {e}")

    state.stop_event.clear()
    state.thread = threading.Thread(target=_inference_loop, args=(state, sdr), daemon=True)
    state.thread.start()
    return StartInferenceResponse(running=True)


@router.post("/stop", response_model=StopInferenceResponse)
async def stop_inference():
    """Stop the running inference loop."""
    state = get_inference()
    if not state or not state.get_running():
        return StopInferenceResponse(stopped=False)
    _stop_current_inference(state)
    return StopInferenceResponse(stopped=True)


@router.post("/configure", response_model=ConfigureResponse)
async def configure_inference(request: ConfigureRequest):
    """Update SDR parameters (center_freq, sample_rate, gain) on the fly.

    If inference is running the change is applied at the next capture boundary.
    If inference is not running the config is stored and applied when it starts.
    Only fields present in the request body are updated.
    """
    state = get_inference()
    if not state:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="No model loaded. Call POST /inference/load first.",
        )
    pending = {k: v for k, v in request.model_dump().items() if v is not None}
    if pending:
        state.set_pending_config(pending)
    return ConfigureResponse(configured=bool(pending))


@router.get("/status", response_model=InferenceStatusResponse | None)
async def inference_status():
    """Return the latest inference result, or null if no model is loaded."""
    state = get_inference()
    if not state:
        return None
    latest = state.get_latest()
    return InferenceStatusResponse(**latest) if latest else None
