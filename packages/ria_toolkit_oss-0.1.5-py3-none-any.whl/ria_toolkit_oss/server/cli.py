"""CLI entry point for the RT-OSS HTTP server.

Usage:
    ria-server                          # default: 0.0.0.0:8080, no auth
    RT_OSS_API_KEY=secret ria-server    # enforce X-API-Key header
    RT_OSS_PORT=9000 ria-server         # custom port

Environment variables:
    RT_OSS_API_KEY   Shared secret for X-API-Key auth (empty = dev mode, no auth)
    RT_OSS_PORT      TCP port to listen on (default: 8080)
    RT_OSS_HOST      Bind address (default: 0.0.0.0)
"""

from __future__ import annotations

import os


def serve() -> None:
    try:
        import uvicorn
    except ImportError:
        raise SystemExit(
            "uvicorn is required to run the RT-OSS server.\n" "Install it with: pip install 'ria-toolkit-oss[server]'"
        )

    from .app import create_app

    api_key = os.environ.get("RT_OSS_API_KEY", "")
    host = os.environ.get("RT_OSS_HOST", "0.0.0.0")
    port = int(os.environ.get("RT_OSS_PORT", "8080"))

    app = create_app(api_key=api_key)

    if not api_key:
        print(
            "\n"
            "╔══════════════════════════════════════════════════════════════╗\n"
            "║  WARNING: RT_OSS_API_KEY is not set.                        ║\n"
            "║  The server is running with NO authentication.               ║\n"
            "║  Anyone who can reach this port has full API access.         ║\n"
            "║  Set RT_OSS_API_KEY=<secret> before exposing to a network.  ║\n"
            "╚══════════════════════════════════════════════════════════════╝\n",
            flush=True,
        )

    uvicorn.run(app, host=host, port=port)
