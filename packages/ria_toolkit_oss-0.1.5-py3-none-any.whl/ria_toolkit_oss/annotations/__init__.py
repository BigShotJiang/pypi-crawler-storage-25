"""
The annotations package contains tools and utilities for creating, managing, and processing annotations.

Provides automatic annotation generation using various signal detection algorithms:
- Energy-based detection (detect_signals_energy)
- CUSUM-based segmentation (annotate_with_cusum)
- Threshold-based qualification (threshold_qualifier)
- Signal isolation and extraction (isolate_signal)
- Occupied bandwidth analysis (calculate_occupied_bandwidth, calculate_nominal_bandwidth)

All detection functions return Recording objects with added annotations.
"""

__all__ = [
    # Energy-based detection
    "detect_signals_energy",
    "calculate_occupied_bandwidth",
    "calculate_nominal_bandwidth",
    "calculate_full_detected_bandwidth",
    "annotate_with_obw",
    # CUSUM detection
    "annotate_with_cusum",
    # Threshold detection
    "threshold_qualifier",
    # Parallel signal separation (Phase 2)
    "find_spectral_components",
    "split_annotation_by_components",
    "split_recording_annotations",
    # Signal isolation
    "isolate_signal",
    # Annotation transforms
    "remove_contained_boxes",
    "is_annotation_contained",
    # Dataset creation
    "qualify_slice_from_annotations",
]

from .annotation_transforms import is_annotation_contained, remove_contained_boxes
from .cusum_annotator import annotate_with_cusum
from .energy_detector import (
    annotate_with_obw,
    calculate_full_detected_bandwidth,
    calculate_nominal_bandwidth,
    calculate_occupied_bandwidth,
    detect_signals_energy,
)
from .parallel_signal_separator import (
    find_spectral_components,
    split_annotation_by_components,
    split_recording_annotations,
)
from .qualify_slice import qualify_slice_from_annotations
from .signal_isolation import isolate_signal
from .threshold_qualifier import threshold_qualifier
