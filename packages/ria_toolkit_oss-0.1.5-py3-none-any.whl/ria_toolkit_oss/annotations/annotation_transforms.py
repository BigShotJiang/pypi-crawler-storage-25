from ria_toolkit_oss.datatypes.annotation import Annotation

# TODO figure out how to transfer labels in the merge case


def remove_contained_boxes(annotations: list[Annotation]):
    """
    Remove all annotations (bounding boxes) that are entirely contained within other boxes in the list.

    :param annotations: A list of Annotation objects.
    :type annotations: list[Annotation]

    :returns: A new list of Annotation objects.
    :rtype: list[Annotation]"""

    output_boxes = []

    for i in range(len(annotations)):
        contained = False
        for j in range(len(annotations)):
            if i != j and is_annotation_contained(annotations[i], annotations[j]):
                contained = True
                break

        if not contained:
            output_boxes.append(annotations[i])

    return output_boxes


def is_annotation_contained(inner: Annotation, outer: Annotation) -> bool:
    """
    Check if an annotation box is entirely contained within another annotation bounding box.

    :param inner: The inner box.
    :type inner: Annotation.
    :param outer: The outer box.
    :type outer: Annotation.

    :returns: True if inner is within outer, false otherwise.
    :rtype: bool
    """

    inner_sample_stop = inner.sample_start + inner.sample_count
    outer_sample_stop = outer.sample_start + outer.sample_count

    if inner.sample_start > outer.sample_start and inner_sample_stop < outer_sample_stop:
        if inner.freq_lower_edge > outer.freq_lower_edge and inner.freq_upper_edge < outer.freq_upper_edge:
            return True

    return False


def merge_annotations(annotations: list[Annotation], overlap_threshold) -> list[Annotation]:
    raise NotImplementedError
