"""
The Signal Package provides a comprehensive suite of tools for signal generation and processing.
"""

from .recordable import Recordable

__all__ = ["Recordable"]
