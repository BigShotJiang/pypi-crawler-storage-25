from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class FrequencyShift(ProcessBlock, RecordableBlock):
    """
    Frequency Shift Block

    Applies a frequency shift the input signal.

    Input type: BASEBAND_SIGNAL
    Output type: BASEBAND_SIGNAL

    :param shift_frequency: The frequency to shift the signal by.
    :type shift_frequency: float
    :param sample_rate: The sample rate to use in frequency calculations.
    :type sample_rate: float.

    WARNING: This block does not include any anti-aliasing filters.
    It is the responsiblity of the user to ensure proper
    filtering is performed before/after this block to prevent aliasing.
    """

    def __init__(self, shift_frequency: Optional[float] = 100000, sampling_rate: Optional[float] = 1000000):
        self.shift_frequency = shift_frequency
        self.sampling_rate = sampling_rate
        super().__init__()

    @property
    def input_type(self) -> DataType:
        return [DataType.BASEBAND_SIGNAL]

    @property
    def output_type(self) -> DataType:
        return DataType.BASEBAND_SIGNAL

    def __call__(self, samples: list[np.array]):
        """
        Frequency shift input samples by the previously intialized shift frequency.

        :param samples: A list containing a single array of complex samples.
        :type samples: list of np.array

        :returns: Processed samples.
        :rtype: np.array
        """
        signal = samples[0]
        num_samples = len(signal)
        t = np.arange(num_samples) / self.sampling_rate
        carrier = np.exp(1j * 2 * np.pi * self.shift_frequency * t)
        return signal * carrier
