from typing import Optional

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class MultiplyConstant(ProcessBlock, RecordableBlock):
    """
    MultiplyConstant Block

    Multiply the input samples by a constant.

    Input Type: BASEBAND_SIGNAL
    Output Type: BASEBAND_SIGNAL

    :param multiplier: The value to multiply the samples by.
    :type multiplier: float.
    """

    def __init__(self, multiplier: Optional[float] = 0.5):
        self.multiplier = multiplier

    @property
    def input_type(self):
        return [DataType.BASEBAND_SIGNAL]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, samples):
        """
        Multiply an array of complex samples by the previously initialised value.

        :param samples: A list containing a single array of complex samples.
        :type samples: list of np.array

        :returns: Processed samples.
        :rtype: np.array"""
        return samples[0] * self.multiplier
