import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class Add(RecordableBlock, ProcessBlock):
    """
    Add Block

    Sums the input from two blocks.

    Input type: [BASEBAND_SIGNAL, BASEBAND_SIGNAL]

    Output type: BASEBAND_SIGNAL
    """

    def __init__(self):
        super().__init__()

    def connect_input(self, input):
        datatype = input[0].output_type
        for input_block in input:
            if input_block.output_type != datatype:
                print(input_block.output_type)
                raise ValueError(
                    f"'Add' block requires inputs to have the same datatype but got \
                    {'[' + ',' .join(f'{block.__class__.__name__}({block.output_type()})' for block in input) + ']'}"
                )  # TODO make this print the strings not numbers
        return super().connect_input(input)

    def _get_input_samples(self, block, num_samples):
        """
        Request n samples from a block and validate the correct shape of CxN samples was received.
        """

        samples = block.get_samples(num_samples)
        if len(samples) != num_samples:
            raise ValueError(f"Block {self.__class__.__name__} requested {num_samples} \
                    from block {block.__class__.__name__} but got {len(samples)}.")

        return samples

    @property
    def input_type(self):
        return [DataType.BASEBAND_SIGNAL, DataType.BASEBAND_SIGNAL]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, samples: list[np.array]):
        """
        Add two signals together.

        :param samples: A list containing two sample arrays of the same length.
        :type samples: list of np.array

        :returns: An array of output samples.
        :rtype: np.array"""

        if len(samples) != 2:
            raise ValueError("Input must be a list of two input arrays.")
        if len(samples[0]) != len(samples[1]):
            raise ValueError(f"Input arrays must be equal length but were {len(samples[0])} and {len(samples[1])}")
        return samples[0] + samples[1]
