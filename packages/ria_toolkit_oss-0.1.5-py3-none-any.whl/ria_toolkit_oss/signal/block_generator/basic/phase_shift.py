from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class PhaseShift(ProcessBlock, RecordableBlock):
    """
    PhaseShift Block

    Apply a complex phase shift to the input signal.

    :param phase: The complex phase shift in radians.
    :type phase: float."""

    def __init__(self, phase: Optional[float] = 0):
        self.phase = phase
        super().__init__()

    @property
    def input_type(self):
        return [DataType.BASEBAND_SIGNAL]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, samples):
        """
        Phase shift an array of complex samples by the previously initialised phase.

        :param samples: A list containing a single array of complex samples.
        :type samples: list of np.array

        :returns: Processed samples.
        :rtype: np.array"""
        return samples[0] * np.exp(1j * self.phase)
