from enum import IntEnum


class DataType(IntEnum):
    """
    Enumeration of different data types used in signal processing.
    """

    NONE = 0
    """Represents no input."""

    SYMBOLS = 1
    """Represents symbol data."""

    SOFT_SYMBOLS = 2
    """Represents soft symbol data."""

    UPSAMPLED_SYMBOLS = 3
    """Represents upsampled symbol data."""

    BITS = 4
    """Represents bit data."""

    SOFT_BITS = 5
    """Represents soft bit data."""

    BASEBAND_SIGNAL = 6
    """Represents baseband signal data."""

    PASSBAND_SIGNAL = 7
    """Represents passband signal data."""

    IQ_COMPONENTS = 8
    """Represents in-phase and quadrature components."""
