"""
RIA Miscellaneous Signal Processing Blocks Module

This module provides auxiliary blocks for use in signal processing chains within the RIA block-based signal generator
framework.

Key components:

- Downsampling: Reduces the sampling rate of a signal
- Upsampling: Increases the sampling rate of a signal

Features:

- Integration with other RIA blocks
- Configurable parameters for flexible signal manipulation
- Essential utilities for common signal processing tasks

Usage:

- Import specific blocks to incorporate into your signal processing chain.

For detailed parameters and methods, see individual block documentation.
"""

from ria_toolkit_oss.signal.block_generator.multirate.downsampling import Downsampling
from ria_toolkit_oss.signal.block_generator.multirate.upsampling import Upsampling

__all__ = ["Upsampling", "Downsampling"]
