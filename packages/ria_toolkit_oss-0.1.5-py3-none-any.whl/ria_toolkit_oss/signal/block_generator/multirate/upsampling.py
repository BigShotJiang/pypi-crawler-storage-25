import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.block_generator.data_types import DataType


class Upsampling(Block):
    """
    A class to perform upsampling on input signals.

    :param factor: The upsampling factor.
    :type factor: int

    Methods:
    __call__(signal: np.ndarray, axes: int = 0) -> np.ndarray:
        Upsamples the input signal by the specified factor along the given axes.

    Example:
    --------
    # Create an Upsampling instance with a factor of 3
    >>> upsampler = Upsampling(3)

    # Original signal
    >>> signal = np.array([[1, 2], [3, 4]])

    # Perform upsampling
    >>> upsampled_signal = upsampler(signal)
    >>> print(upsampled_signal)
    array([[1, 0, 0, 2, 0, 0],
           [3, 0, 0, 4, 0, 0]])
    """

    def __init__(self, factor: int):
        self.factor = factor

    @property
    def input_type(self) -> DataType:
        """Get the input data type for the upsampling operation.

        :return: The input data type.
        :rtype: DataType
        """
        return DataType.SYMBOLS

    @property
    def output_type(self) -> DataType:
        """Get the output data type for the upsampling operation.

        :return: The output data type.
        :rtype: DataType
        """
        return DataType.UPSAMPLED_SYMBOLS

    def get_samples(self, num_samples):
        raise NotImplementedError

    def __call__(self, signal: np.ndarray) -> np.ndarray:
        """Upsample the input signal by inserting zeros between samples.

        :param signal: The input signal to be upsampled. Shape should be (n_samples, n_bits).
        :type signal: numpy array

        :return: The upsampled signal. Shape will be (n_samples, n_bits * factor).
        :rtype: numpy array
        """
        n_samples, n_bits = signal.shape
        us_signal = np.zeros((n_samples, n_bits * self.factor), dtype=signal.dtype)
        us_signal[:, :: self.factor] = signal
        return us_signal
