from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.block_generator.data_types import DataType


class Downsampling(Block):
    """
    A class to perform downsampling on input signals.

    :param factor: The downsampling factor.
    :type factor: int

    Methods:
    __call__(signal: np.ndarray, delay: Optional[int] = 0, num_samples: Optional[int] = -1) -> np.ndarray:
        Downsamples the input signal by the specified factor along the given axes.
    """

    def __init__(self, factor: int):
        self.factor = factor

    def __call__(self, signal: np.ndarray, num_samples: Optional[int], delay: Optional[int] = 0) -> np.ndarray:
        """
        Downsamples the input signal by the specified factor along the given axes.

        :param signal: The input signal to be downsampled.
        :type signal: numpy array
        :param num_samples: The number of samples to return after downsampling.
        :type num_samples: int, optional
        :param delay: The delay to start downsampling, defaults to 0.
        :type delay: int, optional
        :return: The downsampled signal.
        :rtype: numpy array
        """
        if num_samples:
            return signal[:, delay : delay + self.factor * num_samples : self.factor]
        else:
            return signal[:, delay :: self.factor]

    @property
    def input_type(self) -> DataType:
        """
        Get the input data type for the downsampling operation.

        :return: The input data type.
        :rtype: DataType
        """
        return DataType.BASEBAND_SIGNAL

    @property
    def output_type(self) -> DataType:
        """
        Get the output data type for the downsampling operation.

        :return: The output data type.
        :rtype: DataType
        """
        return DataType.BASEBAND_SIGNAL

    def get_samples(self, num_samples):
        raise NotImplementedError
