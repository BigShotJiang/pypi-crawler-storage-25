import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.block_generator.data_types import DataType


class FrequencyDownConversion(Block):
    """
    A class to perform frequency down-conversion on passband signals.

    :param carrier_frequency: The carrier frequency in Hz.
    :type carrier_frequency: float
    :param sampling_rate: The sampling rate of the input signal in Hz.
    :type sampling_rate: float

    Methods:
    --------
    __call__(signal: np.ndarray) -> np.ndarray:
        Applies frequency down-conversion to the input passband signal.
    """

    def __init__(self, carrier_frequency: float, sampling_rate: float):
        self.carrier_frequency = carrier_frequency
        self.sampling_rate = sampling_rate

    @property
    def input_type(self) -> DataType:
        """Get the input data type for the frequency down-conversion operation."""
        return DataType.PASSBAND_SIGNAL

    @property
    def output_type(self) -> DataType:
        """Get the output data type for the frequency down-conversion operation."""
        return DataType.BASEBAND_SIGNAL

    def __call__(self, signal: np.ndarray) -> np.ndarray:
        """
        Apply frequency down-conversion to the input passband signal.

        :param signal: The input passband signal to be demodulated.
        :type signal: np.ndarray
        :return: The demodulated baseband signal.
        :rtype: np.ndarray
        """
        num_samples = signal.shape[1]
        t = np.arange(num_samples) / self.sampling_rate
        if np.iscomplexobj(signal):
            carrier = np.exp(-1j * 2 * np.pi * self.carrier_frequency * t)
        else:
            carrier = np.cos(2 * np.pi * self.carrier_frequency * t)
        return signal * carrier

    def __str__(self) -> str:
        """Return a string representation of the FrequencyDownConversion object."""
        return (
            f"FrequencyDownConversion(carrier_frequency={self.carrier_frequency}, sampling_rate={self.sampling_rate})"
        )
