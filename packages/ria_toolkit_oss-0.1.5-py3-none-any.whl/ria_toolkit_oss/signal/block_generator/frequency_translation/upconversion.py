import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.block_generator.data_types import DataType


class FrequencyUpConversion(Block):
    """
    A class to perform frequency up-conversion on baseband signals.

    :param carrier_frequency: The carrier frequency in Hz.
    :type carrier_frequency: float
    :param sampling_rate: The sampling rate of the input signal in Hz.
    :type sampling_rate: float

    Methods:
    --------
    __call__(signal: np.ndarray) -> np.ndarray:
        Applies frequency up-conversion to the input baseband signal.
    """

    def __init__(self, carrier_frequency: float, sampling_rate: float):
        self.carrier_frequency = carrier_frequency
        self.sampling_rate = sampling_rate

    @property
    def input_type(self) -> DataType:
        """Get the input data type for the frequency up-conversion operation."""
        return DataType.BASEBAND_SIGNAL

    @property
    def output_type(self) -> DataType:
        """Get the output data type for the frequency up-conversion operation."""
        return DataType.PASSBAND_SIGNAL

    def __call__(self, signal: np.ndarray) -> np.ndarray:
        """
        Apply frequency up-conversion to the input baseband signal.

        :param signal: The input baseband signal to be modulated.
        :type signal: np.ndarray
        :return: The modulated passband signal.
        :rtype: np.ndarray
        """
        num_samples = signal.shape[1]
        t = np.arange(num_samples) / self.sampling_rate
        if np.iscomplexobj(signal):
            carrier = np.exp(1j * 2 * np.pi * self.carrier_frequency * t)
        else:
            carrier = np.cos(2 * np.pi * self.carrier_frequency * t)

        return signal * carrier

    def __str__(self) -> str:
        """Return a string representation of the FrequencyUpConversion object."""
        return f"FrequencyUpConversion(carrier_frequency={self.carrier_frequency}, sampling_rate={self.sampling_rate})"
