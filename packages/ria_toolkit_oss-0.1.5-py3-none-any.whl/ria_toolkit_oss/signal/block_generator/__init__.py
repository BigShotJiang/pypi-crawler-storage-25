"""
RIA Block-Based Signal Generator Module

This module provides a flexible framework for simulating communication systems using configurable blocks. It includes:

- Various block types: filters, mappers, modulators, demodulators, and channels
- Easy-to-use classes for creating custom signal processing chains
- Pre-configured generators for common use cases

Key features:

- Modular design for building complex systems
- Customizable block parameters
- Ready-to-use generators for quick prototyping

Usage:

1. Import desired blocks
2. Configure block parameters
3. Connect blocks to create a processing chain
4. Run simulations with custom or provided input signals

For detailed examples and API reference, see the documentation.
"""

from .basic import Add, FrequencyShift, MultiplyConstant, PhaseShift
from .generators import PAMGenerator, PSKGenerator, QAMGenerator, SignalGenerator
from .mapping import Mapper, SymbolDemapper
from .process_block import ProcessBlock
from .pulse_shaping import (
    GaussianFilter,
    RaisedCosineFilter,
    RectFilter,
    RootRaisedCosineFilter,
    SincFilter,
    Upsampling,
)
from .recordable_block import RecordableBlock
from .siso_channel import AWGNChannel, FlatRayleigh
from .source import (
    AWGNSource,
    BinarySource,
    ConstantSource,
    LFMChirpSource,
    RecordingSource,
    SawtoothSource,
    SineSource,
    SquareSource,
)
from .source_block import SourceBlock
from .symbol_modulation import GMSKModulator, OOKModulator, OQPSKModulator

__all__ = [
    "Add",
    "FrequencyShift",
    "MultiplyConstant",
    "PhaseShift",
    "PAMGenerator",
    "PSKGenerator",
    "QAMGenerator",
    "SignalGenerator",
    "Mapper",
    "SymbolDemapper",
    "GMSKModulator",
    "OOKModulator",
    "OQPSKModulator",
    "RaisedCosineFilter",
    "RootRaisedCosineFilter",
    "SincFilter",
    "RectFilter",
    "GaussianFilter",
    "Upsampling",
    "AWGNChannel",
    "FlatRayleigh",
    "AWGNSource",
    "ConstantSource",
    "LFMChirpSource",
    "BinarySource",
    "RecordingSource",
    "SawtoothSource",
    "SineSource",
    "SquareSource",
]
