from abc import ABC, abstractmethod

import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.block_generator.data_types import DataType


class ProcessBlock(Block, ABC):
    def __init__(self):
        self.input: list[Block] = []

    def _validate_input(self, input) -> None:
        """
        Validate input block formats.
        Must be a list of Block object of the correct length.

        :raises ValueError: if block configuration is invalid.
        """
        if not isinstance(input, list):
            raise ValueError(
                f"Block '{self.__class__.__name__}' input must be a list of block objects but was {type(input)}."
            )

        elif not all(isinstance(item, Block) for item in input):
            raise ValueError(f"Invalid input to block '{self.__class__.__name__}'. \
                             Expected a list of Block objects but got \
                             {'[' + ',' .join(f'{item.__class__.__name__}({repr(item)})' for item in input) + ']'}")

        elif len(input) != len(self.input_type):
            raise ValueError(
                f"Block '{self.__class__.__name__}' requires {len(self.input_type)} input but got {len(input)}"
            )

    def connect_input(self, input: list[Block]) -> None:
        """
        Declare the input block(s) for this block.

        :param input: Input blocks.
        :type input: list of Block objects.
        """

        self._validate_input(input)
        self.input = input

    @property
    @abstractmethod
    def input_type(self) -> list[DataType]:
        """
        Get the input data types for the block.

        :return: The data type of each input.
        :rtype: list[DataType]
        """
        pass

    @abstractmethod
    def __call__(self, samples: list[np.array]):
        """
        Process input samples and return output samples.

        :param samples: A list of n input arrays, where length and datatypes are defined by block.input_type.
        :type samples: list of np.array

        :returns: The processed output array, where datatype is defined by block.output_type.
        :rtype: np.array"""
        pass

    def get_samples(self, num_samples: int):
        """
        Get num_samples samples from this block by recursively requesting samples from upstream blocks.

        :param num_samples: The number of samples to output.
        :type num_samples: int

        Note: If a new block implementation decimates or multiplies the number of samples from upstream blocks
        this method must be overridden to implement the correct sample requests from input blocks.
        """
        input_signals = [input.get_samples(num_samples) for input in self.input]
        output = self.__call__(samples=input_signals)
        if len(output) != num_samples:
            raise ValueError(
                f"Error in block {self.__class__.__name__}: requested {num_samples} samples but got {len(output)}."
            )
        return output
