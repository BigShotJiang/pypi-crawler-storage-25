from abc import abstractmethod

import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class SISOChannel(ProcessBlock, RecordableBlock):
    """
    Abstract base class for Single-Input Single-Output (SISO) communication channels.

    Methods:
    --------
    __call__(signal: np.ndarray) -> np.ndarray:
        Apply the channel effect to the input signal.
    """

    def __init__(self, input):
        super().__init__(input=input)

    @property
    def input_type(self) -> DataType:
        """
        Get the input data type for the SISO channel.

        :return: The input data type.
        :rtype: DataType
        """
        return [DataType.BASEBAND_SIGNAL]

    @property
    def output_type(self) -> DataType:
        """
        Get the output data type for the SISO channel.

        :return: The output data type.
        :rtype: DataType
        """
        return DataType.BASEBAND_SIGNAL

    @abstractmethod
    def __call__(self, signal: np.ndarray) -> np.ndarray:
        """
        Apply the channel effect to the input signal.

        :param signal: The input signal to be processed by the channel.
        :type signal: numpy array

        :returns: The output signal after applying the channel effect.
        :rtype: numpy array
        """
        raise NotImplementedError
