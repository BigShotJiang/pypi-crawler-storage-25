from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.siso_channel.siso_channel import SISOChannel


class FlatRayleigh(SISOChannel):
    """
    Flat Rayleigh Fading Channel Block

    :param path_gain_db: The path gain in decibels, defaults to 0.
    :type path_gain_db: float, optional

    Methods:
    --------
    __call__(signal: np.ndarray) -> np.ndarray:
        Applies the flat Rayleigh fading effect to the input signal.
    """

    def __init__(self, path_gain_db: Optional[float] = 0):
        self.path_gain_db = path_gain_db
        self.rng = np.random.default_rng()

    def __call__(self, samples: list[np.array]) -> np.ndarray:
        """
        Applies the flat Rayleigh fading effect to the input signal.

        :param samples: The input signal to be processed, as a list containing 1 numpy array.
        :type samples: numpy array
        :return: The signal after being affected by the flat Rayleigh fading.
        :rtype: numpy array
        """
        signal = np.array(samples)
        num_signals, sig_len = signal.shape
        path_gain = 10 ** (self.path_gain_db / 10)
        h = np.sqrt(path_gain / 2) * (
            self.rng.standard_normal((num_signals, 1)) + 1j * self.rng.standard_normal((num_signals, 1))
        )
        output = h * signal
        return output[0]
