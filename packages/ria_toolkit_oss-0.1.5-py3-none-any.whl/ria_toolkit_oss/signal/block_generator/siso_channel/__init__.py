"""
RIA Block-Based Signal Generator Module

This module provides a flexible framework for simulating communication systems using configurable blocks. It includes:

- Various block types: filters, mappers, modulators, demodulators, and channels
- Easy-to-use classes for creating custom signal processing chains
- Pre-configured generators for common use cases

Key features:

- Modular design for building complex systems
- Customizable block parameters
- Ready-to-use generators for quick prototyping

Usage:

1. Import desired blocks
2. Configure block parameters
3. Connect blocks to create a processing chain
4. Run simulations with custom or provided input signals

For detailed examples and API reference, see the documentation.
"""

from .awgn_channel import AWGNChannel
from .flat_rayleigh import FlatRayleigh
from .siso_channel import SISOChannel

__all__ = [AWGNChannel, FlatRayleigh, SISOChannel]
