from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.siso_channel.siso_channel import SISOChannel


class AWGNChannel(SISOChannel):
    """
    Additive White Gaussian Noise (AWGN) channel class.

    :param var: The noise variance.
    :type var: float

    Methods:
    --------
    __call__(signal: np.ndarray) -> np.ndarray:
        Adds AWGN to the input signal.
    """

    def __init__(self, var: Optional[float] = 0):
        self._var = var
        self.rng = np.random.default_rng()

    @property
    def var(self) -> float:
        """Get the noise variance."""
        return self._var

    @var.setter
    def var(self, var: float) -> None:
        """Set the noise variance."""
        self._var = var

    def __call__(self, samples: list[np.ndarray]) -> np.ndarray:
        """
        Add AWGN to the input signal.

        :param samples: The input signal to be processed as a list containing a single numpy array.
        :type samples: list[numpy array]

        :returns: The output signal with added noise.
        :rtype: numpy array

        Example:
        --------
        # Create an AWGN channel with variance 0.1
        awgn_channel = AWGN(0.1)

        # Original signal
        signal = np.array([1+1j, 2+2j, 3+3j])

        # Pass the signal through the AWGN channel
        noisy_signal = awgn_channel(signal)
        print(noisy_signal)
        """
        signal = samples[0]
        noise = np.sqrt(self._var / 2) * (
            self.rng.standard_normal(signal.shape) + 1j * self.rng.standard_normal(signal.shape)
        )
        return signal + noise
