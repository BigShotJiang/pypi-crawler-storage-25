import os
from datetime import datetime

import click
import numpy as np

from ria_toolkit_oss.datatypes.recording import Recording
from ria_toolkit_oss.signal.block_generator.mapping.mapper import Mapper
from ria_toolkit_oss.signal.block_generator.multirate.upsampling import Upsampling
from ria_toolkit_oss.signal.block_generator.pulse_shaping.raised_cosine_filter import (
    RaisedCosineFilter,
)
from ria_toolkit_oss.signal.block_generator.pulse_shaping.root_raised_cosine_filter import (
    RootRaisedCosineFilter,
)
from ria_toolkit_oss.signal.block_generator.pulse_shaping.sinc_filter import SincFilter
from ria_toolkit_oss.signal.block_generator.siso_channel.awgn_channel import AWGNChannel
from ria_toolkit_oss.signal.block_generator.siso_channel.flat_rayleigh import (
    FlatRayleigh,
)


@click.command()
@click.option("--num_samples", default=10, help="Number of samples.")
@click.option("--num_bits", default=40096, help="Number of bits.")
@click.option("--num_bits_per_symbol", default=4, help="Number of bits per symbol.")
@click.option("--modulation_list", multiple=True, default=["QAM", "PSK", "PAM"], help="List of modulation schemes.")
@click.option(
    "--filter_type", default="RRC", type=click.Choice(["SINC", "RC", "RRC"], case_sensitive=False), help="Filter type."
)
@click.option("--span_in_symbols", default=6, help="Span in symbols.")
@click.option("--samples_per_symbol", default=8, help="Samples per symbol.")
@click.option("--beta", default=0.25, help="Roll-off factor for RC and RRC filters.")
@click.option(
    "--channel_type",
    default="Rayleigh",
    type=click.Choice(["Rayleigh", "AWGN"], case_sensitive=False),
    help="Channel type.",
)
@click.option("--path_gain", default=0, help="Path gain in dB for Rayleigh channel.")
@click.option("--noise_power", multiple=True, default=[1e-5, 1e-4, 1e-3], help="Noise power for the AWGN channel.")
@click.option("--verbose", is_flag=True, help="Enable verbose output.")
def generate_signal(
    num_samples,
    num_bits,
    num_bits_per_symbol,
    modulation_list,
    filter_type,
    span_in_symbols,
    samples_per_symbol,
    beta,
    channel_type,
    path_gain,
    noise_power,
    verbose,
):

    now = datetime.now()
    formatted_time = now.strftime("%Y%m%d_%H%M%S")
    os.makedirs("recordings", exist_ok=True)
    recordings_dir_name = os.path.join("recordings", f"recording_set_{formatted_time}")
    os.makedirs(recordings_dir_name)

    if verbose:
        click.echo(f"Output directory: {recordings_dir_name}")
        click.echo("Starting signal generation...")

    for modulation in modulation_list:
        if verbose:
            click.echo(f"Processing modulation: {modulation}")

        f = _choose_filter(filter_type, span_in_symbols, samples_per_symbol, beta)
        us = Upsampling(samples_per_symbol)

        if modulation in ["QAM", "PSK", "PAM"]:
            mapper = Mapper(modulation, num_bits_per_symbol, normalize=True)
        else:
            raise ValueError("modulation must be QAM, PSK or PAM")

        if channel_type == "Rayleigh":
            chan = FlatRayleigh(path_gain)
            rx_noise = AWGNChannel()
        elif channel_type == "AWGN":
            chan = None
            rx_noise = AWGNChannel()
        else:
            raise ValueError("channel_type must be Rayleigh or AWGN")

        for no in noise_power:
            if verbose:
                click.echo(f"  Noise power: {np.round(10 * np.log10(no * 1000), 2)} dBm")

            metadata = {
                "modulation": modulation,
                "channel_type": channel_type,
                "noise_power": no,
                "filter_type": filter_type,
                "span_in_symbols": span_in_symbols,
                "samples_per_symbol": samples_per_symbol,
                "roll_off_factor": beta,
            }
            if chan:
                metadata["path_gain_db"] = path_gain

            rx_noise.var = no
            bits = np.random.randint(0, 2, (num_samples, num_bits))
            symbols = mapper(bits)
            sig = f(us(symbols))
            if chan:
                sig_chan = rx_noise(chan(sig))
            else:
                sig_chan = rx_noise(sig)

            total_samples_generated = 0

            for i, sig_chan_sample in enumerate(sig_chan):
                now = datetime.now()
                formatted_time = now.strftime("%Y%m%d_%H%M%S")
                file_name = f"{modulation}_{channel_type}_{filter_type}_{formatted_time}_{i}"

                recording = Recording(sig_chan_sample, metadata=metadata)
                recording.to_npy(filename=file_name, path=recordings_dir_name)
                total_samples_generated += 1

            if verbose:
                click.echo(f"Generated {total_samples_generated} recordings for {modulation} modulation.")


def _choose_filter(filter_type, span_in_symbols, samples_per_symbol, beta):
    if filter_type == "RRC":
        return RootRaisedCosineFilter(span_in_symbols, samples_per_symbol, beta)
    elif filter_type == "RC":
        return RaisedCosineFilter(span_in_symbols, samples_per_symbol, beta)
    elif filter_type == "SINC":
        return SincFilter(span_in_symbols, samples_per_symbol)
    else:
        raise ValueError("filter_type must be RRC or RC or Sinc")


if __name__ == "__main__":
    generate_signal()
