from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock
from ria_toolkit_oss.signal.block_generator.source_block import SourceBlock


class AWGNSource(SourceBlock, RecordableBlock):
    """
    AWGN Block

    Produces Additive White Gaussian Noise (AWGN) samples.

    Output Type: BASEBAND_SIGNAL

    :param variance: The variance of the AWGN.
    :type variance: float
    """

    def __init__(self, variance: Optional[float] = 1):
        self.input = []
        self.variance = variance
        pass

    @property
    def input_type(self):
        return [DataType.NONE]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, num_samples: int):
        """
        Create an array of complex noise samples.

        :param num_samples: The number of samples to return.
        :type num_samples: int

        :returns: Output samples.
        :rtype: np.array
        """
        real = np.random.normal(loc=0, scale=np.sqrt(self.variance), size=num_samples)
        imag = 1j * np.random.normal(loc=0, scale=np.sqrt(self.variance), size=num_samples)
        return np.array(real + imag)
