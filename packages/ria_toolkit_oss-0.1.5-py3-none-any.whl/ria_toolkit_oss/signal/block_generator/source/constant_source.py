from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock
from ria_toolkit_oss.signal.block_generator.source_block import SourceBlock


class ConstantSource(SourceBlock, RecordableBlock):
    """
    Constant Source Block

    Produces constant real samples and 0 imaginary samples.

    :param amplitude: The value of the real samples.
    :type amplitude: float.
    """

    def __init__(self, amplitude: Optional[float] = 1):

        self.amplitude = amplitude
        pass

    @property
    def input_type(self):
        return [DataType.NONE]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, num_samples):
        """
        Create an array of constant value samples with 0 imaginary component.

        :param num_samples: The number of samples to return.
        :type num_samples: int

        :returns: Output samples.
        :rtype: np.array
        """
        return np.ones(num_samples, dtype=np.complex64) * self.amplitude
