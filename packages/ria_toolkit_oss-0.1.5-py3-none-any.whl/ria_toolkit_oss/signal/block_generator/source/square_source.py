from typing import Optional

import numpy as np
import scipy

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock
from ria_toolkit_oss.signal.block_generator.source_block import SourceBlock


class SquareSource(RecordableBlock, SourceBlock):
    """
    Square Source Block

    Creates a square wave signal with a square shaped real part and 0 imaginary part.

    :param frequency: The frequency of the square wave.
    :type frequency: float.
    :param sample_rate: The sample rate.
    :type sample_rate: float
    :param amplitude: The maximum amplitude of the signal, defaults to 1.
    :type amplitude: float.
    :param duty_cycle: The ratio of positive to negative values in single period.
    :type duty_cycle: float
    :param phase_shift: The phase shift of the sine wave in radians
    relative to the wave period. NOT a complex phase shift.
    :type phase_shift: float.
    """

    def __init__(
        self,
        frequency: Optional[float] = 100e3,
        sample_rate: Optional[float] = 1e6,
        amplitude: Optional[int] = 1,
        duty_cycle: Optional[float] = 0.5,
        phase_shift: Optional[float] = 0,
    ):
        self.input = []
        self.frequency = frequency
        self.amplitude = amplitude
        self.sample_rate = sample_rate
        self.phase_shift = phase_shift
        self.duty_cycle = duty_cycle
        pass

    @property
    def input_type(self):
        return [DataType.NONE]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, num_samples):
        """
        Create a square wave signal.

        :param num_samples: The number of samples to return.
        :type num_samples: int

        :returns: Output samples.
        :rtype: np.array
        """
        t = np.arange(num_samples)
        square_wave = self.amplitude * scipy.signal.square(
            2 * np.pi * self.frequency * (t / self.sample_rate - (self.phase_shift / (2 * np.pi))),
            duty=self.duty_cycle,
        )
        square_wave = np.array(square_wave, dtype=np.complex64)
        return square_wave
