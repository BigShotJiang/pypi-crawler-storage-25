from typing import Optional

import numpy as np
from scipy.signal import chirp

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock
from ria_toolkit_oss.signal.block_generator.source_block import SourceBlock


class LFMChirpSource(SourceBlock, RecordableBlock):
    """
    LFM Chirp Source Block

    Produces Linear Frequency Modulation (LFM) Chirp signals.

    :param sample_rate: The sample rate.
    :type sample_rate: float
    :param bandwidth: The bandwidth of the chirp signal, must be < sample_rate/2.
    :type bandwidth: float.
    :param chirp_period: The chirp period in seconds.
    :type period: float.
    :param chirp_type: The direction (on a spectrogram) of the LFM chirps.
    Options: 'up','down', or 'up_down', defaults to 'up'.
    :type chirp_type: str."""

    def __init__(
        self,
        sample_rate: Optional[float] = 1e6,
        bandwidth: Optional[float] = 5e5,
        chirp_period: Optional[float] = 0.01,
        chirp_type: Optional[str] = "up",
    ):
        self.sample_rate = sample_rate
        self.bandwidth = bandwidth
        self.chirp_period = chirp_period
        self.chirp_type = chirp_type

    @property
    def input_type(self):
        return [DataType.NONE]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, num_samples):
        """
        Create an array of samples of an LFM signal with previously initialized parameters.

        :param num_samples: The number of samples to return.
        :type num_samples: int

        :returns: Output samples.
        :rtype: np.array
        """
        chirp_length = int(self.chirp_period * self.sample_rate)
        t_chirp = np.linspace(0, self.chirp_period, chirp_length)

        if len(t_chirp) > chirp_length:
            t_chirp = t_chirp[:chirp_length]

        # Generate one chirp from 0 Hz to the full width
        if self.chirp_type == "up":
            baseband_chirp = chirp(
                t_chirp,
                f0=1000,
                f1=self.bandwidth,
                t1=self.chirp_period,
                method="linear",
                complex=True,
            )
        elif self.chirp_type == "down":
            baseband_chirp = chirp(
                t_chirp,
                f0=self.bandwidth,
                f1=0,
                t1=self.chirp_period,
                method="linear",
                complex=True,
            )
        elif self.chirp_type == "up_down":
            half_duration = self.chirp_period / 2
            t_up_half, t_down_half = np.array_split(t_chirp, 2)

            up_part = chirp(
                t_up_half,
                f0=0,
                t1=half_duration,
                f1=self.bandwidth,
                method="linear",
                complex=True,
            )
            down_part = np.flip(up_part)
            baseband_chirp = np.concatenate([up_part, down_part])

        num_chirps = int(np.ceil(num_samples / chirp_length))
        full_signal = np.tile(baseband_chirp, num_chirps)
        trimmed_signal = full_signal[:num_samples]
        # Create an analytic signal (complex with no negative frequency components)
        # Shift the chirp to the signal center frequency
        total_time = num_samples / self.sample_rate
        t_full = np.linspace(0, total_time, len(trimmed_signal))
        complex_chirp = trimmed_signal * np.exp(1j * 2 * np.pi * (0 - self.bandwidth / 2) * t_full)
        if len(complex_chirp) != num_samples:
            raise ValueError("LFMJammer did not produce the correct number of samples.")
        return complex_chirp
