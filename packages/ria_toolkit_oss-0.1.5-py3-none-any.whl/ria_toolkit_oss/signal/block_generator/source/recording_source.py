from ria_toolkit_oss.datatypes import Recording
from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock
from ria_toolkit_oss.signal.block_generator.source_block import SourceBlock


class RecordingSource(SourceBlock, RecordableBlock):
    """
    Recording Source Block

    Passes samples from the provided recording to downstream blocks.

    :param recording: The :ref:`Recording <ria_toolkit_oss.data.Recording>` that provides samples.
    :type recording: :ref:`Recording <ria_toolkit_oss.data.Recording>`

    Warning: Only uses channel 0 of multi-channel recordings."""

    def __init__(self, recording: Recording):
        self.recording = recording

    @property
    def input_type(self):
        return [DataType.NONE]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, num_samples):
        """
        Return the first num_samples samples of the recording, channel 0.

        :param num_samples: The number of samples to return.
        :type num_samples: int

        :returns: Output samples.
        :rtype: np.array

        :raises ValueError: If num_samples is greater than the recording length.
        """
        if num_samples - 1 >= self.recording.data.shape[1]:
            raise ValueError(f"{num_samples} samples requested from recording source with \
                    {self.recording.data.shape[1]} samples available.")

        return self.recording.data[0, 0:num_samples]
