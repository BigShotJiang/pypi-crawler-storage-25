from pathlib import Path
from typing import Literal, Optional, Union

import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.source_block import SourceBlock


class BinarySource(SourceBlock):
    """
    Generates bit sequences either randomly or from a file's raw bytes.

    - Random mode (default): uses `p` as the probability of generating a 0.
    - File mode: if `file_path` is passed to __call__, the file is read as BYTES
      and converted to bits using numpy.unpackbits (no assumption of '0'/'1' chars).

    Args:
        p: Probability of outputting 0 in random mode (0..1).
        rng: Optional numpy Generator to control randomness.
    """

    def __init__(self, p: float = 0.5, rng: Optional[np.random.Generator] = None):
        self.p = float(p)
        self.rng = rng if rng is not None else np.random.default_rng()

    @property
    def input_type(self) -> DataType:
        return [DataType.NONE]

    @property
    def output_type(self) -> DataType:
        return DataType.BITS

    def __call__(
        self,
        num_samples: int = 1,
        num_bits: Optional[int] = None,
        file_path: Optional[Union[str, Path]] = None,
        *,
        cycle: bool = True,
        bitorder: Literal["big", "little"] = "big",
    ) -> np.ndarray:
        """
        Generate binary sequences.

        Args:
            num_samples: number of sequences (rows).
            num_bits: bits per sequence (columns).
            file_path: optional path to a file; if provided, read BYTES and convert to bits.
            cycle: if True and requested bits exceed available, repeat from start.
            bitorder: 'big' (MSB-first) or 'little' (LSB-first) for byte-to-bits conversion.

        Returns:
            Array shape (num_samples, num_bits), dtype float32 with values {0.0, 1.0}.
        """
        if file_path is None:
            # Random mode: 0 with prob p, 1 with prob (1-p)
            if num_bits:
                return (self.rng.random((num_samples, num_bits)) > self.p).astype(np.float32)
            else:
                return (self.rng.random((num_samples)) > self.p).astype(np.float32)

        # File mode: read raw bytes and unpack to bits
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        data = path.read_bytes()
        if not data:
            raise ValueError(f"File is empty: {path}")

        # Convert bytes -> bits (uint8 -> 8 bits each)
        byte_arr = np.frombuffer(data, dtype=np.uint8)
        bits_u8 = np.unpackbits(byte_arr, bitorder=bitorder)
        file_bits = bits_u8.astype(np.float32)  # {0., 1.}

        total_bits = num_samples * num_bits
        if total_bits > file_bits.size:
            if not cycle:
                raise ValueError(
                    f"Requested {total_bits} bits, but file provides {file_bits.size}. "
                    f"Set cycle=True (default) to repeat."
                )
            reps = int(np.ceil(total_bits / file_bits.size))
            out = np.tile(file_bits, reps)[:total_bits]
        else:
            out = file_bits[:total_bits]

        return out.reshape(num_samples, num_bits)
