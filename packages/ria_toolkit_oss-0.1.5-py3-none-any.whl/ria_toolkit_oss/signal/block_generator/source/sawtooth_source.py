from typing import Optional

import numpy as np
import scipy

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock
from ria_toolkit_oss.signal.block_generator.source_block import SourceBlock


class SawtoothSource(SourceBlock, RecordableBlock):
    """
    Sawtooth Source Block
    Creates a sawtooth signal real part and 0 imaginary part.

    :param frequency: The frequency of the saw wave.
    :type frequency: float.
    :param sample_rate: The sample rate.
    :type sample_rate: float
    :param amplitude: The maximum amplitude of the signal, defaults to 1.
    :type amplitude: float.
    :param phase_shift: The phase shift of the saw wave in radians
    relative to the wave period. NOT a complex phase shift.
    :type phase_shift: float.
    """

    def __init__(
        self,
        frequency: Optional[float] = 100e3,
        sample_rate: Optional[float] = 1e6,
        amplitude: Optional[float] = 1,
        phase_shift: Optional[float] = 0,
    ):
        self.input = []
        self.frequency = frequency
        self.amplitude = amplitude
        self.sample_rate = sample_rate
        self.phase_shift = phase_shift
        pass

    @property
    def input_type(self) -> DataType:
        return [DataType.NONE]

    @property
    def output_type(self):
        return DataType.BASEBAND_SIGNAL

    def __call__(self, num_samples):
        """
        Create a sawtooth signal.

        :param num_samples: The number of samples to return.
        :type num_samples: int

        :returns: Output samples.
        :rtype: np.array
        """

        t = np.arange(num_samples)

        saw_wave = self.amplitude * scipy.signal.sawtooth(
            2 * np.pi * self.frequency * (t / self.sample_rate - (self.phase_shift / (2 * np.pi)))
        )
        saw_wave = np.array(saw_wave, dtype=np.complex64)
        return saw_wave
