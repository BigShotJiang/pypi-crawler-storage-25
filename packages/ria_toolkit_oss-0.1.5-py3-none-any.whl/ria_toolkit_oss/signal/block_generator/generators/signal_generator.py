from abc import ABC
from typing import List

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.recordable import Recordable


class SignalGenerator(Recordable, ABC):
    """
    An abstract base class for signal generators that work with a sequence of blocks.

    This class provides a foundation for creating signal generators that operate on a
    series of processing blocks. It ensures type compatibility between consecutive
    blocks in the sequence by validating that the output type of each block matches
    the input type of the subsequent block.

    :param blocks: A list of processing blocks to be used in the signal generation.
    :type blocks: List of Blocks

    :raises ValueError: If there's a mismatch between block output and input types.
    """

    # TODO: Consider exposing 'blocks' through a property, and adding methods for adding to / manipulating the
    #  block sequence.

    def __init__(self, blocks: List[Block]):
        self.blocks = blocks
        self._validate_block_sequence()

    def _validate_block_sequence(self) -> None:
        for i in range(len(self.blocks) - 1):
            if self.blocks[i].output_type != self.blocks[i + 1].input_type:
                raise ValueError(
                    f"Block {i} output type {self.blocks[i].output_type} does not match "
                    f"block {i + 1} input type {self.blocks[i + 1].input_type}."
                )
