from ria_toolkit_oss.datatypes.recording import Recording
from ria_toolkit_oss.signal.block_generator.generators.signal_generator import (
    SignalGenerator,
)
from ria_toolkit_oss.signal.block_generator.mapping.mapper import Mapper
from ria_toolkit_oss.signal.block_generator.multirate.upsampling import Upsampling
from ria_toolkit_oss.signal.block_generator.pulse_shaping.pulse_shaping_filter import (
    PulseShapingFilter,
)
from ria_toolkit_oss.signal.block_generator.source.binary_source import BinarySource


class PSKGenerator(SignalGenerator):
    """
    A generator for Phase Shift Keying (PSK) modulated signals.

    This class generates PSK signals with configurable parameters such as
    bits per symbol, upsampling factor, and pulse shaping filter.

    :param num_bits_per_symbol: Number of bits per symbol in the PSK modulation.
    :type num_bits_per_symbol: int
    :param upsampling_factor: Factor by which to upsample the signal.
    :type upsampling_factor: int
    :param pulse_shaping_filter: The pulse shaping filter to apply to the signal.
    :type pulse_shaping_filter: PulseShapingFilter
    """

    def __init__(self, num_bits_per_symbol: int, upsampling_factor: int, pulse_shaping_filter: PulseShapingFilter):
        src = BinarySource()
        mapper = Mapper("PSK", num_bits_per_symbol)
        us = Upsampling(upsampling_factor)
        self.num_bits_per_symbol = num_bits_per_symbol
        super().__init__([src, mapper, us, pulse_shaping_filter])

    def record(self, batch_size: int = 1, num_bits: int = 1024) -> Recording:
        """
        Generate and record PSK signals.

        :param batch_size: Number of recordings to generate, defaults to 1.
        :type batch_size: int, optional
        :param num_bits: Number of bits per recording, defaults to 1024.
        :type num_bits: int, optional
        :return: A Recording object containing the generated signals and metadata.
        :rtype: Recording
        """
        x = self.blocks[0](batch_size, num_bits)
        for block in self.blocks[1:]:
            x = block(x)
        metadata = {
            "num_recordings": batch_size,
            "bits_per_recording:": num_bits,
            "modulation": f"{2**self.num_bits_per_symbol}PSK",
            "pulse_shaping_filter": str(self.blocks[-1]),
        }
        return Recording(x, metadata)
