"""
RIA Block-Based Signal Generator Module: Generators

This module provides high-level generator wrappers that utilize the RIA block-based signal generator.
These generators simplify the creation of common communication system signals by automatically
configuring and connecting the appropriate blocks.

Key components:

- SignalGenerator: Base class for all generators
- Specialized generators: PAMGenerator, PSKGenerator, QAMGenerator

Features:

- Easy-to-use interfaces for generating complex signals
- Built on top of RIA's modular block system
- Customizable parameters for each generator type

Usage:

- Import specific generators to quickly create signals without manually connecting individual blocks.
- For more control, use the underlying blocks directly.

See individual generator classes for detailed parameters and methods.
"""

from ria_toolkit_oss.signal.block_generator.generators.pam_generator import PAMGenerator
from ria_toolkit_oss.signal.block_generator.generators.psk_generator import PSKGenerator
from ria_toolkit_oss.signal.block_generator.generators.qam_generator import QAMGenerator
from ria_toolkit_oss.signal.block_generator.generators.signal_generator import (
    SignalGenerator,
)

__all__ = ["SignalGenerator", "PAMGenerator", "PSKGenerator", "QAMGenerator"]
