import json
from abc import ABC, abstractmethod

from ria_toolkit_oss.signal.block_generator.block import Block


class SourceBlock(Block, ABC):
    @abstractmethod
    def __call__(self, num_samples: int):
        """
        Create num_samples samples.

        :param num_samples: The number of samples to create.
        :type num_samples: int"""
        pass

    def get_samples(self, num_samples):
        """
        Return num_samples samples from this source block.

        :param num_samples: The number of samples to return.
        :type num_samples: int"""

        return self.__call__(num_samples=num_samples)

    def _get_metadata(self):
        metadata = {}
        for key, value in vars(self).items():
            try:
                # Try to serialize the value to check if it's JSON serializable
                json.dumps(value)
                metadata[f"BlockGenerator:{self.__class__.__name__}:{key}"] = value
            except (TypeError, ValueError):
                # If the value is not JSON serializable, skip it
                continue

        return metadata
