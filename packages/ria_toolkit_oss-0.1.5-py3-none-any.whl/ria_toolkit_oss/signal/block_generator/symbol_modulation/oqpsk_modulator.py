import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class OQPSKModulator(RecordableBlock):
    """Offset QPSK Modulator"""

    def __init__(self, input_block: Block, samples_per_symbol: int = 8):
        self.input = [input_block]
        self.sps = samples_per_symbol
        # QPSK: 2 bits per symbol
        self.bps = 2

    @property
    def input_type(self) -> DataType:
        return [DataType.BITS]

    @property
    def output_type(self) -> DataType:
        return DataType.BASEBAND_SIGNAL

    def get_samples(self, num_samples: int):
        # Need enough bits. 1 sample comes from 1 symbol? No, sps.
        # total symbols = num_samples / sps
        # total bits = total symbols * 2
        num_symbols = int(np.ceil(num_samples / self.sps))
        num_bits = num_symbols * 2

        bits = self.input[0].get_samples(num_bits)

        # Reshape to (N, 2)
        # Even bits -> I, Odd bits -> Q
        i_bits = bits[0::2]
        q_bits = bits[1::2]

        # Map 0->-1, 1->1
        i_syms = 2 * i_bits - 1
        q_syms = 2 * q_bits - 1

        # Upsample (Rectangular pulse for now, or should we use RRC?)
        # OQPSK usually implies pulse shaping, often RRC or Half-Sine.
        # User requested "OQPSK". Standard OQPSK often has rectangular or shaped pulses.
        # The prototype used "2*bits-1" and "roll".
        # We will implement rectangular pulse OQPSK (staggered).

        i_samples = np.repeat(i_syms, self.sps)
        q_samples = np.repeat(q_syms, self.sps)

        # Offset Q channel by T_sym / 2 (half symbol)
        offset = self.sps // 2

        # Pad I with offset zeros at start? Or pad Q?
        # Delay Q by half symbol.
        # Prepend offset zeros to Q, append offset zeros to I to match length?
        # To keep alignment simple for streaming, we just roll/shift.

        q_samples_delayed = np.roll(q_samples, offset)
        # Zero out the wrap-around part if non-circular?
        q_samples_delayed[:offset] = 0  # Initialize

        # Complex sum
        iq = i_samples + 1j * q_samples_delayed

        return iq[:num_samples]

    def __call__(self, num_samples):
        return self.get_samples(num_samples=num_samples)
