import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class GMSKModulator(RecordableBlock):
    """Gaussian Minimum Shift Keying Modulator"""

    def __init__(self, input_block: Block, samples_per_symbol: int = 8, bt: float = 0.3):
        self.input = [input_block]
        self.sps = samples_per_symbol
        self.bt = bt

        # Generate Gaussian filter

        # Let's use a simplified approximation or standard formula
        sigma = np.sqrt(np.log(2)) / (2 * np.pi * self.bt)
        # t is normalized by T (symbol period)
        t_norm = np.arange(-4 * self.sps, 4 * self.sps + 1) / self.sps

        # Gaussian shape
        g = (1 / (np.sqrt(2 * np.pi) * sigma)) * np.exp(-(t_norm**2) / (2 * sigma**2))
        # Normalize area to 0.5 (pulse area for MSK is 0.5)
        g = g / np.sum(g) * 0.5
        self.pulse = g

    @property
    def input_type(self) -> DataType:
        return [DataType.BITS]

    @property
    def output_type(self) -> DataType:
        return DataType.BASEBAND_SIGNAL

    def get_samples(self, num_samples: int):
        # Samples needed
        num_symbols = int(np.ceil(num_samples / self.sps))
        bits = self.input[0].get_samples(num_symbols)

        # NRZ: 0->-1, 1->1
        symbols = 2 * bits - 1

        # Upsample (Impulse train)
        upsampled = np.zeros(len(symbols) * self.sps)
        upsampled[:: self.sps] = symbols

        # Convolve with Gaussian pulse -> Frequency
        freq_signal = np.convolve(upsampled, self.pulse, mode="same")

        # Integrate Frequency -> Phase
        # Phase = 2 * pi * integral(freq)
        # Cumulative sum
        phase = np.cumsum(freq_signal) * np.pi  # scale factor?
        # MSK index h=0.5. Pulse area is 0.5.
        # phase(t) = 2*pi*h * integral(q(tau))
        # If pulse area is 0.5, total phase change per symbol is 0.5 * pi (90 deg). Correct for MSK.

        iq = np.exp(1j * phase)

        return iq[:num_samples]

    def __call__(self, num_samples):
        return self.get_samples(num_samples=num_samples)
