import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block
from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class OOKModulator(RecordableBlock):
    """On-Off Keying Modulator"""

    def __init__(self, input_block: Block, samples_per_symbol: int = 8):
        self.input = [input_block]
        self.sps = samples_per_symbol

    @property
    def input_type(self) -> DataType:
        return [DataType.BITS]

    @property
    def output_type(self) -> DataType:
        return DataType.BASEBAND_SIGNAL

    def get_samples(self, num_samples: int):
        # Needed bits = num_samples / sps
        num_symbols = int(np.ceil(num_samples / self.sps))
        bits = self.input[0].get_samples(num_symbols)

        # Map 0 -> 0, 1 -> 1
        # Upsample
        # Rectangular pulse shape (repeat)
        # bits is array of 0.0 and 1.0

        samples = np.repeat(bits, self.sps)
        # Convert to complex
        samples = samples.astype(np.complex64)

        return samples[:num_samples]

    def __call__(self, num_samples):
        return self.get_samples(num_samples=num_samples)
