from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.mapping.constellation_mapper import (
    ConstellationMapper,
)


class _PSKMapper(ConstellationMapper):
    """
    A class to map input bits to Phase Shift Keying (PSK) constellation points.

    :param num_bits_per_symbol: Number of bits per symbol. Must be an even number.
    :type num_bits_per_symbol: int
    :param normalize: Whether to normalize the constellation points, defaults to True.
    :type normalize: bool, optional
    :param use_gray_code: Whether to use gray code as constellation points, defaults to True.
    :type use_gray_code: bool, optional

    :raises ValueError: If num_bits_per_symbol is not an even number.
    """

    def __init__(
        self, num_bits_per_symbol: int, normalize: Optional[bool] = True, use_gray_code: Optional[bool] = True
    ):
        super().__init__(num_bits_per_symbol, normalize, use_gray_code)
        self.constellation = self._generate_constellation()
        if self.use_gray_code:
            self._reorder_for_gray()

    def _generate_constellation(self) -> np.ndarray:
        """
        Generate the PSK constellation points.

        :returns: The PSK constellation points.
        :rtype: numpy array
        """
        num_symbols = 2**self.num_bits_per_symbol
        symbol_indices = np.arange(0, num_symbols) + 1
        real_part = np.cos(2 * np.pi * symbol_indices / num_symbols)
        image_part = np.sin(2 * np.pi * symbol_indices / num_symbols)

        constellation = real_part + 1j * image_part
        if self.num_bits_per_symbol == 2:
            constellation *= np.exp(1j * np.pi / 4)  # rotate 45 degrees
        if self.normalize:
            return self._normalize(constellation)
        return constellation
