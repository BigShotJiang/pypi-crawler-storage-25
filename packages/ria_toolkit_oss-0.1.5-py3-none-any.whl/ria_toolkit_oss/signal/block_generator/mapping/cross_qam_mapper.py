from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.mapping.constellation_mapper import (
    ConstellationMapper,
)


class _CrossQAMMapper(ConstellationMapper):
    """
    A class to map input bits to Cross-QAM constellation points (Odd-order QAM).
    Supports 32QAM (5 bits) and 128QAM (7 bits) by removing corners from larger square constellations.
    """

    def __init__(
        self, num_bits_per_symbol: int, normalize: Optional[bool] = True, use_gray_code: Optional[bool] = True
    ):
        # Allow odd bits
        super().__init__(num_bits_per_symbol, normalize, use_gray_code)
        self.constellation = self._generate_constellation()
        # Use default bit mapping from base class (integer index -> symbol index)
        # For true gray coding on Cross QAM, we'd need a specific lookup table.
        # Using generic index mapping for now.

    def _generate_constellation(self) -> np.ndarray:
        M = 2**self.num_bits_per_symbol

        if M == 32:
            # 32-QAM: Subset of 6x6 (36 points) - remove 4 corners
            # Grid -2.5 to 2.5 (step 1) -> -5, -3, -1, 1, 3, 5 (scaled)
            axis = np.array([-5, -3, -1, 1, 3, 5])
            xv, yv = np.meshgrid(axis, axis)
            points = xv + 1j * yv
            points = points.flatten()

            # Remove corners: |I| > 3 AND |Q| > 3
            # axis ends are +/- 5. Inner are +/- 3, +/- 1.
            # Corners are (5,5), (5,-5), (-5,5), (-5,-5)
            mask = (np.abs(points.real) > 3) & (np.abs(points.imag) > 3)
            constellation = points[~mask]

        elif M == 128:
            # 128-QAM: Subset of 12x12 (144 points) - remove 16 points (4 from each corner)
            # 12x12 grid
            # axis length 12. -11, -9, ..., 9, 11
            axis = np.arange(-11, 12, 2)
            xv, yv = np.meshgrid(axis, axis)
            points = xv + 1j * yv
            points = points.flatten()

            # Remove corners. 144 - 128 = 16 points to remove.
            # 4 points per corner.
            # Corner region: |I| >= 9 AND |Q| >= 9 (points 9, 11) -> 2x2 = 4 points per corner
            # 9,9; 9,11; 11,9; 11,11 (and signs)
            mask = (np.abs(points.real) >= 9) & (np.abs(points.imag) >= 9)
            constellation = points[~mask]

        else:
            raise ValueError(f"Unsupported Cross-QAM order: {M}")

        if self.normalize:
            return self._normalize(constellation)
        return constellation
