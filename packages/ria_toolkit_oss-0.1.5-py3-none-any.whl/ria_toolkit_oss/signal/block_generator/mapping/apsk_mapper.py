from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.mapping.constellation_mapper import (
    ConstellationMapper,
)


class _APSKMapper(ConstellationMapper):
    """
    A class to map input bits to Amplitude Phase Shift Keying (APSK) constellation points.
    Follows DVB-S2 / DVB-S2X standard structures for rings and radii ratios where applicable,
    or generic concentric ring structures.
    """

    def __init__(
        self, num_bits_per_symbol: int, normalize: Optional[bool] = True, use_gray_code: Optional[bool] = True
    ):
        super().__init__(num_bits_per_symbol, normalize, use_gray_code)
        self.constellation = self._generate_constellation()
        # Re-generate bit mapping if needed, or assume default
        # Note: Base class calls _generate_bit_mapping() which does generic gray/binary
        # For APSK, generic gray might not match DVB standards, but is sufficient for synthetic generation.

    def _generate_constellation(self) -> np.ndarray:
        M = 2**self.num_bits_per_symbol

        # Define structures (rings and points per ring)
        # Based on common DVB standards
        if M == 16:  # 16APSK: 4+12
            radii = [1.0, 2.57]  # R2/R1 ratio approx 2.57 for DVB-S2 16APSK
            points = [4, 12]
            phase_offsets = [0, 0]
        elif M == 32:  # 32APSK: 4+12+16
            radii = [1.0, 2.53, 4.30]
            points = [4, 12, 16]
            phase_offsets = [0, 0, 0]
        elif M == 64:  # 64APSK: 4+12+20+28
            radii = [1.0, 2.5, 4.3, 6.0]  # Approximate
            points = [4, 12, 20, 28]
            phase_offsets = [0, 0, 0, 0]
        elif M == 128:  # 128APSK: 8+16+24+32+48? Or 4+12+28+36+48 (from prototype)
            # Proto: 4+12+28+36+48
            radii = [1.0, 2.5, 4.0, 5.5, 7.0]
            points = [4, 12, 20, 36, 56]  # Sum must be 128
            # 4+12+20+36+56 = 128
            phase_offsets = [0] * 5
        elif M == 256:  # 256APSK
            # Proto: 4+12+28+52+68+92 (Sum=256)
            radii = np.linspace(1, 6, 6)
            points = [4, 12, 28, 52, 68, 92]
            phase_offsets = [0] * 6
        else:
            # Fallback for other orders: single ring (PSK) or simple multi-ring
            # Just use PSK fallback if not specific APSK structure defined
            return self._generate_psk_fallback(M)

        constellation = []
        for r, p, phi in zip(radii, points, phase_offsets):
            angles = np.linspace(0, 2 * np.pi, p, endpoint=False) + phi
            ring = r * np.exp(1j * angles)
            constellation.extend(ring)

        constellation = np.array(constellation)

        if self.normalize:
            return self._normalize(constellation)
        return constellation

    def _generate_psk_fallback(self, M):
        # Fallback to PSK
        angles = np.linspace(0, 2 * np.pi, M, endpoint=False)
        return np.exp(1j * angles)
