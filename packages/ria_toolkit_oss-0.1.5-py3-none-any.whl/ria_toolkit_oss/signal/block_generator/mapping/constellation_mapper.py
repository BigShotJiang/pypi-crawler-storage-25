import os
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional

import matplotlib.pyplot as plt
import numpy as np


class ConstellationMapper(ABC):
    """
    Abstract base class for mapping input bits to constellation points.

    This class provides methods to generate constellation points, map input bits
    to constellation points, normalize constellation points, and display a
    constellation diagram.

    :param num_bits_per_symbol: Number of bits per symbol. To be used by subclasses.
    :type num_bits_per_symbol: int
    :param normalize: Whether to normalize the constellation points. To be used by subclasses.
    :type normalize: bool, optional
    :param use_gray_code: Whether to use gray code as constellation points. To be used by subclasses.
    :type use_gray_code: bool, optional

    Note:
    This is an abstract class and should not be instantiated directly.
    Subclasses should implement the `_generate_constellation` method.
    """

    def __init__(
        self, num_bits_per_symbol: int, normalize: Optional[bool] = True, use_gray_code: Optional[bool] = True
    ):
        self.num_bits_per_symbol = num_bits_per_symbol
        self.normalize = normalize
        self.use_gray_code = use_gray_code
        self.constellation = None
        self._generate_bit_mapping()

    def _generate_bit_mapping(self):
        """Generate bit mapping."""
        if self.use_gray_code:
            indices = self.gray_code(self.num_bits_per_symbol)
        else:
            indices = range(2**self.num_bits_per_symbol)
        self.bit_mapping = np.array(indices)

    @abstractmethod
    def _generate_constellation(self) -> np.ndarray:
        """
        Generate the constellation points.

        This method should be implemented by subclasses.

        :raises NotImplementedError: This method must be implemented by subclasses.
        """
        raise NotImplementedError

    @staticmethod
    def gray_code(n: int) -> List[int]:
        """
        Generate Gray code for a given number of bits.

        :param n: Number of bits
        :type n: int
        :return: List of Gray-encoded values
        :rtype: List of ints
        """
        return [i ^ (i >> 1) for i in range(2**n)]

    def _reorder_for_gray(self) -> None:
        """
        Physically reorder self.constellation so index = Gray-coded decimal index.

        If the base class set self.bit_mapping to a Gray code forward map fwd_map
        such that fwd_map[d] = g, then we do new_const[g] = old_const[d].
        """
        M = len(self.constellation)
        old_const = self.constellation.copy()
        new_const = np.zeros_like(old_const)

        # self.bit_mapping is your forward Gray map array (length M)
        # fwd_map[d] = g
        fwd_map = self.bit_mapping

        for d in range(M):
            g = fwd_map[d]
            new_const[g] = old_const[d]

        self.constellation = new_const
        # Once physically reordered, array index i is the Gray-coded decimal i
        # So we can simplify to an identity map
        self.bit_mapping = np.arange(M)

    def __call__(self, bits: np.ndarray) -> np.ndarray:
        """
        Map bits to constellation points.

        :param bits: Input bits to be mapped. Shape should be (num_batches, num_bits).
        :type bits: np.ndarray

        :return: Mapped constellation points. Shape will be (num_batches, num_symbols).
        :rtype: np.ndarray

        :raises ValueError: If the number of input bits is not divisible by the number of bits per symbol.
        """

        # Check if the number of input bits is divisible by the number of bits per symbol
        if bits.shape[1] % self.num_bits_per_symbol != 0:
            raise ValueError(
                f"Number of input bits ({bits.shape[1]}) "
                f"must be divisible by the number of bits per symbol ({self.num_bits_per_symbol})."
            )

        # Reshape the input bits to have one row per batch and one column per bit
        bits = bits.astype(np.int32).reshape((bits.shape[0], -1, self.num_bits_per_symbol))
        decimal_values = np.sum(bits * (1 << np.arange(self.num_bits_per_symbol)[::-1]), axis=2)

        # Map symbol indices to constellation points
        symbol_indices = self.bit_mapping[decimal_values]
        return self.constellation[symbol_indices]

    @staticmethod
    def _normalize(constellation: np.ndarray) -> np.ndarray:
        """
        Normalize the constellation points so that their average energy is 1.

        :param constellation: The constellation points to normalize.
        :type constellation: np.ndarray

        :return: Normalized constellation points.
        :rtype: np.ndarray
        """
        average_energy = np.mean(np.abs(constellation) ** 2)
        return constellation / np.sqrt(average_energy)

    def show_constellation(self) -> None:
        """
        Display the constellation diagram with bit labels.
        """
        real_part, imag_part = np.real(self.constellation), np.imag(self.constellation)

        # Determine if it's a PAM constellation
        is_pam = np.allclose(imag_part, 0)

        fig, ax = plt.subplots(figsize=(10, 10))
        ax.scatter(real_part, imag_part, color="b", s=100)

        # Add bit labels to each point
        if self.num_bits_per_symbol <= 6:
            for i, (x, y) in enumerate(zip(real_part, imag_part)):
                ax.annotate(
                    bin(self.bit_mapping[i])[2:].zfill(self.num_bits_per_symbol),
                    (x, y),
                    xytext=(5, 5),
                    textcoords="offset points",
                )

        # Set axis labels and title
        ax.set_xlabel("I (In-Phase)")
        ax.set_ylabel("Q (Quadrature)")
        ax.set_title(f"{self.__class__.__name__[1:-6]} Constellation Diagram")

        # Show grid
        ax.grid(True)

        # Make the plot square
        ax.set_aspect("equal", adjustable="box")

        if is_pam:
            # For PAM, set y-axis limits to make the constellation visible
            y_range = max(abs(np.max(real_part)), abs(np.min(real_part))) * 0.2
            ax.set_ylim([-y_range, y_range])
        else:
            # For non-PAM, set limits based on the constellation points
            max_val = max(np.max(np.abs(real_part)), np.max(np.abs(imag_part)))
            ax.set_xlim([-max_val * 1.2, max_val * 1.2])
            ax.set_ylim([-max_val * 1.2, max_val * 1.2])

        # Save the figure
        os.makedirs("images", exist_ok=True)
        now = datetime.now()
        formatted_time = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"images/constellation_{self.__class__.__name__}_{formatted_time}.png"
        fig.savefig(file_name, dpi=300, bbox_inches="tight")

        plt.show()
