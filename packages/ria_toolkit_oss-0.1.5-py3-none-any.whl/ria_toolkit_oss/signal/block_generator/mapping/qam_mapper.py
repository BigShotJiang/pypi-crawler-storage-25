from typing import Optional, Tuple

import numpy as np

from ria_toolkit_oss.signal.block_generator.mapping.constellation_mapper import (
    ConstellationMapper,
)

QAM16_GRAY_CODE = np.array([0, 1, 3, 2, 4, 5, 7, 6, 12, 13, 15, 14, 8, 9, 11, 10])


class _QAMMapper(ConstellationMapper):
    """
    A class to map input bits to Quadrature Amplitude Modulation (QAM) constellation points.

    :param num_bits_per_symbol: Number of bits per symbol. Must be an even number.
    :type num_bits_per_symbol: int
    :param normalize: Whether to normalize the constellation points, defaults to True.
    :type normalize: bool, optional
    :param use_gray_code: Whether to use gray code as constellation points, defaults to True.
    :type use_gray_code: bool, optional

    :raises ValueError: If num_bits_per_symbol is not an even number.
    """

    def __init__(
        self, num_bits_per_symbol: int, normalize: Optional[bool] = True, use_gray_code: Optional[bool] = True
    ):
        if num_bits_per_symbol % 2 != 0:
            raise ValueError("num_bits_per_symbol must be an even number")
        elif num_bits_per_symbol <= 2:
            raise ValueError("num_bits_per_symbol must more than two")
        super().__init__(num_bits_per_symbol, normalize, False)
        self.constellation = self._generate_constellation()
        self.use_gray_code = use_gray_code
        if self.use_gray_code:
            self.constellation, self.bit_mapping, _ = self._generate_gray_code(num_bits_per_symbol)
            self._reorder_for_gray()

    @staticmethod
    def _generate_indexing_scheme(n: int) -> np.ndarray:
        # Create an empty n x n matrix to store the result
        matrix = np.full((n, n), np.nan)

        index = 0

        # Fill 1st quadrant (bottom-left), but in reverse (flip up-down)
        for col in range(n // 2):
            for row in range(n // 2 - 1, -1, -1):
                matrix[n // 2 + row, col] = index
                index += 1

        # Fill 2nd quadrant (top-left)
        for col in range(n // 2):
            for row in range(n // 2):
                matrix[n // 2 - 1 - row, col] = index
                index += 1

        # Fill 3rd quadrant (top-right)
        for col in range(n // 2, n):
            for row in range(n // 2):
                matrix[n // 2 - 1 - row, col] = index
                index += 1

        # Fill 4th quadrant (bottom-right), but in reverse (flip up-down)
        for col in range(n // 2, n):
            for row in range(n // 2 - 1, -1, -1):
                matrix[n // 2 + row, col] = index
                index += 1

        return matrix.astype(np.int32)

    def _generate_gray_code(self, num_bits_per_symbol: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Recursively generate Gray code for higher-order QAM constellations. Base case is 16QAM.

        :param num_bits_per_symbol: Number of bits for the QAM constellation
        :return: Tuple of numpy arrays (constellation, bit_mapping and ref_bit_mapping)
        """
        if num_bits_per_symbol == 4:
            return self.constellation, QAM16_GRAY_CODE, QAM16_GRAY_CODE

        _, _, lower_mod_gray_code = self._generate_gray_code(num_bits_per_symbol - 2)
        grid_len = int(np.sqrt(2 ** (num_bits_per_symbol - 2)))
        lower_mod_gray_code = np.flipud(lower_mod_gray_code.reshape(grid_len, grid_len).T)

        # Generate quadrants
        quadrants = [
            lower_mod_gray_code,
            lower_mod_gray_code + 2 ** (num_bits_per_symbol - 2),
            lower_mod_gray_code + 3 * 2 ** (num_bits_per_symbol - 2),
            lower_mod_gray_code + 2 ** (num_bits_per_symbol - 1),
        ]

        # Combine quadrants
        left_side = np.vstack((np.flipud(quadrants[1]), quadrants[0]))
        right_side = np.vstack((np.flipud(np.fliplr(quadrants[2])), np.fliplr(quadrants[3])))
        ref_bit_mapping = np.hstack((left_side, right_side)).reshape(-1)

        # Apply indexing scheme
        indices = self._generate_indexing_scheme(int(np.sqrt(2**num_bits_per_symbol))).reshape(-1)
        constellation = self.constellation[indices]
        bit_mapping = ref_bit_mapping[indices]
        return constellation, bit_mapping, ref_bit_mapping

    def _generate_constellation(self) -> np.ndarray:
        """
        Generate the QAM constellation points.

        :returns: The QAM constellation points.
        :rtype: numpy array
        """
        num_pam_symbols = 2 ** (self.num_bits_per_symbol // 2)
        pam_constellation = np.arange(-num_pam_symbols + 1, num_pam_symbols, 2)
        constellation = np.array(np.meshgrid(pam_constellation, pam_constellation)).T.reshape((-1, 2))
        constellation = constellation[:, 0] + 1j * constellation[:, 1]
        if self.normalize:
            return self._normalize(constellation)
        return constellation
