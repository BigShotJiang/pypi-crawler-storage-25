from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.mapping.constellation_mapper import (
    ConstellationMapper,
)


class _PAMMapper(ConstellationMapper):
    """
    A class to map input bits to Pulse Amplitude Modulation (PAM) constellation points.

    :param num_bits_per_symbol: Number of bits per symbol. Must be an even number.
    :type num_bits_per_symbol: int
    :param normalize: Whether to normalize the constellation points, defaults to True.
    :type normalize: bool, optional
    :param use_gray_code: Whether to use gray code as constellation points, defaults to True.
    :type use_gray_code: bool, optional

    :raises ValueError: If num_bits_per_symbol is not an even number.
    """

    def __init__(
        self, num_bits_per_symbol: int, normalize: Optional[bool] = True, use_gray_code: Optional[bool] = True
    ):
        if num_bits_per_symbol % 2 != 0:
            raise ValueError("num_bits_per_symbol must be an even number")
        super().__init__(num_bits_per_symbol, normalize, use_gray_code)
        self.constellation = self._generate_constellation()
        if self.use_gray_code:
            self._reorder_for_gray()

    def _generate_constellation(self) -> np.ndarray:
        """
        Generate the PAM constellation points.

        :returns: The PAM constellation points.
        :rtype: numpy array
        """
        num_pam_symbols = 2**self.num_bits_per_symbol
        constellation = np.arange(-num_pam_symbols + 1, num_pam_symbols, 2).astype(np.complex128)

        if self.normalize:
            return self._normalize(constellation)
        return constellation
