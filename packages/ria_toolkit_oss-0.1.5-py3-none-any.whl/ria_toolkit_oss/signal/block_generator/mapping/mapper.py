from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.mapping.pam_mapper import _PAMMapper
from ria_toolkit_oss.signal.block_generator.mapping.psk_mapper import _PSKMapper
from ria_toolkit_oss.signal.block_generator.mapping.qam_mapper import _QAMMapper
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class Mapper(ProcessBlock, RecordableBlock):
    """
    A class to map input bits to constellation points using various modulation schemes.

    :param constellation_type: The type of constellation ('PSK', 'QAM', 'PAM').
    :type constellation_type: str
    :param num_bits_per_symbol: Number of bits per symbol.
    :type num_bits_per_symbol: int
    :param normalize: Whether to normalize the constellation points, defaults to True.
    :type normalize: bool, optional

    Methods:
    --------
    __call__(bits: np.ndarray) -> np.ndarray:
        Maps input bits to constellation points.
    show_constellation():
        Displays the constellation diagram.

    Example:
    --------
    # Create a QAM Mapper
    >>> qam_mapper = Mapper('QAM', 4, True)

    # Generate some random bits
    >>> bits = np.random.randint(0, 2, (10, 8))  # 10 batches of 8 bits each

    # Map bits to QAM constellation points
    >>> mapped_points = qam_mapper(bits)

    # Show the constellation diagram
    >>> qam_mapper.show_constellation()
    """

    def __init__(
        self,
        constellation_type: Optional[str] = "psk",
        num_bits_per_symbol: Optional[int] = 2,
        normalize: Optional[bool] = True,
        use_gray_code: Optional[bool] = True,
    ):
        """
        Initialize a mapper block to map bits to constellation symbols.

        :param constellation_type: The type of constellation ('PSK', 'QAM', 'PAM').
        :type constellation_type: str
        :param num_bits_per_symbol: Number of bits per symbol.
        :type num_bits_per_symbol: int
        :param normalize: Whether to normalize the constellation points, defaults to True.
        :type normalize: bool, optional
        """
        self.constellation_type = constellation_type
        self.num_bits_per_symbol = num_bits_per_symbol
        self.normalize = normalize
        self.use_gray_code = use_gray_code
        self.constellation_mapper = self._create_constellation_mapper()
        super().__init__()

    @property
    def input_type(self) -> DataType:
        """
        Get the input data type.

        :return: The input data type.
        :rtype: DataType
        """
        return [DataType.BITS]

    @property
    def output_type(self) -> DataType:
        """
        Get the output data type.

        :return: The output data type.
        :rtype: DataType
        """
        return DataType.SYMBOLS

    def _create_constellation_mapper(self):
        """
        Factory method to create the appropriate constellation mapper based on the type specified.

        :return: An instance of a specific constellation mapper.
        :rtype: ConstellationMapper
        :raises ValueError: If the constellation type is unsupported.
        """
        if self.constellation_type.upper() == "PSK":
            return _PSKMapper(self.num_bits_per_symbol, self.normalize, self.use_gray_code)
        elif self.constellation_type.upper() == "QAM":
            return _QAMMapper(self.num_bits_per_symbol, self.normalize, self.use_gray_code)
        elif self.constellation_type.upper() == "PAM":
            return _PAMMapper(self.num_bits_per_symbol, self.normalize, self.use_gray_code)
        else:
            raise ValueError("Unsupported constellation type")

    def get_constellation(self) -> np.ndarray:
        """
        Get the constellation points.

        :return: A numpy array of constellation points.
        :rtype: np.ndarray
        """
        return self.constellation_mapper.constellation

    def get_bit_mapping(self) -> np.ndarray:
        """
        Get the bit mapping.
        :return: A numpy array of symbol to bit mapping
        :rtype: np.ndarray
        """
        return self.constellation_mapper.bit_mapping

    def get_samples(self, num_samples: int):
        """
        Get num_samples samples from this block by recursively requesting samples from upstream blocks.

        :param num_samples: The number of samples to output.
        :type num_samples: int

        Note: If a new block implementation decimates or multiplies the number of samples from upstream blocks
        this method must be overridden to implement the correct sample requests from input blocks.
        """
        input_signals = [input.get_samples(num_samples * self.num_bits_per_symbol) for input in self.input]
        output = self.__call__(samples=input_signals)
        if len(output) != num_samples:
            raise ValueError(
                f"Error in block {self.__class__.__name__}: requested {num_samples} samples but got {len(output)}."
            )
        return output

    def __call__(self, samples):
        """
        Convert an array of bits into symbols.

        :param samples: A list containing a single array of bits, dtype = float.
        :type samples: list of np.array

        :returns: Output symbols, dtype = np.complex64.
        :rtype: np.array"""
        return self.constellation_mapper(np.array([samples[0]]))[0]

    def show_constellation(self) -> None:
        """
        Display the constellation diagram.

        :return: None
        """
        self.constellation_mapper.show_constellation()
