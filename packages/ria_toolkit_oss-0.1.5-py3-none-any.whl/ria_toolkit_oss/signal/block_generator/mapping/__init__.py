"""
RIA Symbol Mapping and Demapping Module

This module provides blocks for symbol mapping and demapping within the RIA block-based signal generator framework.

Key components:

- Mapper: Maps bits to constellation points for various modulation schemes (e.g., M-QAM, M-PSK, M-PAM)
- SymbolDemapper: Converts soft symbols back to original symbols using maximum likelihood estimation

Features:

- Support for multiple modulation schemes
- Configurable parameters for different constellation sizes

Usage:

- Import Mapper or SymbolDemapper to incorporate into your signal processing chain.

For detailed parameters and methods, see individual class documentation.
"""

from .constellation_mapper import ConstellationMapper
from .mapper import Mapper
from .symbol_demapper import SymbolDemapper

__all__ = ["ConstellationMapper", "Mapper", "SymbolDemapper"]
