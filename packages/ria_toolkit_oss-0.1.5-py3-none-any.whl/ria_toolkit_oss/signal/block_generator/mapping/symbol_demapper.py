from typing import Optional

import numpy as np
from scipy.special import logsumexp

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class SymbolDemapper(RecordableBlock, ProcessBlock):
    """
    A class to map received symbols back to their most likely symbols from a predefined constellation
    using Maximum Likelihood Detection.

    :param constellation: The array of constellation points.
    :type constellation: np.ndarray
    :param no: The noise power spectral density, defaults to 1.
    :type no: float, optional
    :param prior: The prior probabilities of the constellation points, defaults to None.
    :type prior: np.ndarray, optional
    :param bits_out: Whether to return bits or symbols, defaults to True.
    :type bits_out: bool, optional

    Methods:
    --------
    __call__(rx_symbols: np.ndarray) -> np.ndarray:
        Maps received symbols to their nearest constellation points based on the maximum likelihood estimation.

    """

    def __init__(
        self,
        constellation: np.ndarray,
        bit_mapping: np.ndarray,
        no: Optional[float] = 1e-6,
        prior: Optional[np.ndarray] = None,
        bits_out: Optional[bool] = True,
        llrs_out: Optional[bool] = False,
        gray_code: Optional[bool] = False,
    ):
        self.constellation = constellation
        self.bits_out = bits_out
        self.llrs_out = llrs_out
        if gray_code:
            self.bit_mapping = np.argsort(bit_mapping)
        else:
            self.bit_mapping = bit_mapping
        if prior is not None:
            self.prior = prior
        else:
            self.prior = np.zeros((len(constellation),))
        self.no = no

    @property
    def input_type(self) -> DataType:
        """
        Get the input data type for the SymbolDemapper.

        :return: The input data type.
        :rtype: DataType
        """
        return [DataType.SOFT_SYMBOLS]

    @property
    def output_type(self) -> DataType:
        """
        Get the output data type for the SymbolDemapper.

        :return: The output data type.
        :rtype: DataType
        """
        if self.bits_out:
            return DataType.BITS
        else:
            return DataType.SYMBOLS

    def _decimal_to_bits(self, decimal_arr: np.ndarray) -> np.ndarray:
        """
        Convert an array of decimal values to their binary representations.

        :param decimal_arr: 2D array of decimal values to be converted
        :type decimal_arr: numpy array
        :return: 2D array of binary representations
        :rtype: numpy array
        """
        num_bits_per_symbol = int(np.log2(len(self.constellation)))
        num_samples, num_symbols = decimal_arr.shape

        # Vectorized conversion of decimal to binary
        binary_arr = ((decimal_arr[:, :, np.newaxis] & (1 << np.arange(num_bits_per_symbol)[::-1])) > 0).astype(int)

        # Reshape to flatten the bits for each sample
        return binary_arr.reshape(num_samples, -1)

    def get_samples(self, num_samples):
        samples = self.input[0].get_samples(num_samples)
        return self.process(rx_symbols=samples)

    def __call__(self, rx_symbols: np.ndarray) -> np.ndarray:
        """
        Maps received symbols to their nearest constellation points based on the maximum likelihood estimation.

        :param rx_symbols: The received symbols to be demapped.
        :type rx_symbols: np.ndarray
        :return: The array of demapped constellation points.
        :rtype: numpy array
        """
        rx_symbols_extended = np.tile(
            rx_symbols.reshape((rx_symbols.shape[0], rx_symbols.shape[1], 1)), (1, 1, len(self.constellation))
        )
        constellation_extended = self.constellation.reshape((1, 1, -1))
        prior_extended = self.prior.reshape((1, 1, -1))
        minus_dist = -np.abs(rx_symbols_extended - constellation_extended) ** 2 / self.no + prior_extended

        if self.llrs_out:
            batches, num_symbols = rx_symbols.shape
            bits_per_sym = int(np.log2(len(self.constellation)))
            bit_mapping = np.asarray(self.bit_mapping, dtype=np.uint16)  # shape (M,)
            bit_table = ((bit_mapping[:, None] >> np.arange(bits_per_sym - 1, -1, -1)) & 1).astype(bool)

            neg_inf = -1e30
            llr = np.empty((batches, num_symbols, bits_per_sym), dtype=np.float32)

            for b in range(bits_per_sym):
                mask0 = ~bit_table[:, b]  # symbols where bit b == 0
                mask1 = bit_table[:, b]  # symbols where bit b == 1

                ll0 = np.where(mask0, minus_dist, neg_inf)  # (B,T,M)
                ll1 = np.where(mask1, minus_dist, neg_inf)

                llr[..., b] = logsumexp(ll0, axis=-1) - logsumexp(ll1, axis=-1)
            return llr.reshape(batches, num_symbols * bits_per_sym)

        elif self.bits_out:
            indices = np.argmax(minus_dist, axis=-1)
            return self._decimal_to_bits(self.bit_mapping[indices])

        else:
            indices = np.argmax(minus_dist, axis=-1)
            return self.constellation[indices]
