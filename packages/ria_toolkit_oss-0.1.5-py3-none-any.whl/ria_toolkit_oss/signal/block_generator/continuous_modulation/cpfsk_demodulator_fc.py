import warnings

import numpy as np
from scipy.signal import hilbert

from ria_toolkit_oss.signal.block_generator.continuous_modulation.demodulator import (
    Demodulator,
)
from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.mapping.mapper import Mapper
from ria_toolkit_oss.signal.block_generator.mapping.symbol_demapper import (
    SymbolDemapper,  # or implement your own
)
from ria_toolkit_oss.signal.block_generator.pulse_shaping.gaussian_filter import (
    GaussianFilter,
)
from ria_toolkit_oss.signal.block_generator.pulse_shaping.rect_filter import RectFilter


class CPFSKDemodulator(Demodulator):
    """
    A basic CPFSK demodulator that attempts to invert the CPFSKModulator logic:

    1) Convert real passband to complex baseband (Hilbert transform + mix down).
    2) Unwrap phase and differentiate to estimate instantaneous frequency offset.
    3) Match-filter that offset using the same shape (Rect or Gaussian).
    4) Sample once per symbol and map back to bits with an inverse of your PAM mapper.

    Note: For strongly filtered CPFSK/GFSK, a sequence detector (like Viterbi) is often
          required for best performance. This simple approach treats each symbol independently.
    """

    def __init__(
        self,
        num_bits_per_symbol: int,
        center_frequency: float,
        frequency_spacing: float,
        symbol_duration: float,
        sampling_frequency: float,
        gaussian: bool = False,
    ):
        self.num_bits_per_symbol = num_bits_per_symbol
        self.center_frequency = center_frequency
        self.frequency_spacing = frequency_spacing
        self.symbol_duration = symbol_duration
        self.sampling_frequency = sampling_frequency
        self.samples_per_symbol = int(round(self.symbol_duration * self.sampling_frequency))

        # Use the same filter type/params as the modulator for matched filtering in freq-domain
        if gaussian:
            self.filter = GaussianFilter(1, upsampling_factor=self.samples_per_symbol, bt=0.3, normalize=False)
        else:
            self.filter = RectFilter(1, upsampling_factor=self.samples_per_symbol, normalize=False)

        self.mapper = Mapper("pam", num_bits_per_symbol, normalize=False)
        constellation = self.mapper.get_constellation()
        bit_mapping = self.mapper.get_bit_mapping()
        self.demapper = SymbolDemapper(constellation, bit_mapping)

    @property
    def input_type(self) -> DataType:
        return DataType.PASSBAND_SIGNAL

    @property
    def output_type(self) -> DataType:
        return DataType.BITS

    def mixed_difference_derivative(self, x):
        """
        Computes the numerical derivative of multiple 1D signals x,
        where x has shape (num_signals, num_samples).

        The sampling period is computed as 1 / self.sampling_frequency.

        Derivative is returned in the same shape (num_signals, num_samples),
        using:
          - Forward difference at the first sample
          - Central difference for interior samples
          - Backward difference at the last sample
        """
        dt = 1.0 / self.sampling_frequency

        # Expect x to have shape (num_signals, num_samples)
        num_signals, num_samples = x.shape

        # If not enough samples to take a difference, just return zeros
        if num_samples < 2:
            return np.zeros_like(x)

        # Allocate output array
        dx_dt = np.zeros_like(x)

        # Forward difference at n=0
        # shape: (num_signals,)
        dx_dt[:, 0] = (x[:, 1] - x[:, 0]) / dt

        # Central difference for n in [1 ... num_samples-2]
        # shape: (num_signals, num_samples-2)
        dx_dt[:, 1:-1] = (x[:, 2:] - x[:, :-2]) / (2.0 * dt)

        # Backward difference at n = num_samples - 1
        dx_dt[:, -1] = (x[:, -1] - x[:, -2]) / dt

        return dx_dt

    def __call__(self, signal: np.ndarray) -> np.ndarray:
        """
        :param signal: Real passband CPFSK waveforms, shape (batch_size, total_samples).
        :return: Recovered bits, shape (batch_size, num_bits).
        """
        batch_size, total_samples = signal.shape
        num_symbols = total_samples // self.samples_per_symbol
        # Ensure total_samples is multiple of samples_per_symbol
        if total_samples % self.samples_per_symbol != 0:
            # Just truncate if needed
            excess = total_samples % self.samples_per_symbol
            signal = signal[:, : total_samples - excess]
            total_samples = signal.shape[1]
            warnings.warn("Truncated input signal to be multiple of samples_per_symbol.")

        # 1) Make an analytic signal along axis=1 (time axis)
        analytic = hilbert(signal, axis=1)

        # 2) Instantaneous phase in [-pi, +pi]
        phase = np.angle(analytic)  # shape => (batch_size, total_samples)

        # 3) Unwrap in time to remove 2*pi jumps
        phase_unwrapped = np.unwrap(phase, axis=1)

        # 4) Numerical derivative of phase -> ~ phi'(t)
        #    Because discrete difference is ~ [phi(n+1)-phi(n)] * fs
        diff_phase = np.diff(phase_unwrapped, axis=1)  # shape => (batch_size, total_samples-1)
        freq_est = (diff_phase * self.sampling_frequency) / (2 * np.pi)
        u_est = (freq_est - self.center_frequency) / (self.frequency_spacing / 2)
        u_matched = self.filter.apply_matched_filter(u_est) / self.filter.energy
        u_matched_ds = u_matched[
            :, self.samples_per_symbol : (num_symbols + 1) * self.samples_per_symbol : self.samples_per_symbol
        ]
        bits = self.demapper(u_matched_ds)
        return bits
