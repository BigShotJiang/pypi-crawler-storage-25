import itertools
import warnings
from typing import List, Tuple

import numpy as np

from ria_toolkit_oss.signal.block_generator.continuous_modulation.demodulator import (
    Demodulator,
)
from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.mapping.mapper import Mapper
from ria_toolkit_oss.signal.block_generator.mapping.symbol_demapper import (
    SymbolDemapper,
)
from ria_toolkit_oss.signal.block_generator.pulse_shaping.gaussian_filter import (
    GaussianFilter,
)
from ria_toolkit_oss.signal.block_generator.pulse_shaping.rect_filter import RectFilter


class CPFSKDemodulator(Demodulator):
    """
    M-ary CPFSK demodulator.

    Two operating modes
    -------------------
    • symbol_by_symbol = True   ⇢  identical to your original code
    • symbol_by_symbol = False  ⇢  runs an L-memory Viterbi detector
                                   (L set by `va_memory`)

    The Viterbi detector models the residual ISI introduced by the Gaussian/
    rectangular pulse as a *linear* partial-response channel whose taps are
    extracted automatically from the matched-filter output of an impulse.
    """

    def __init__(
        self,
        num_bits_per_symbol: int,
        frequency_spacing: float,
        symbol_duration: float,
        sampling_frequency: float,
        gaussian: bool = False,
        bt: float = 0.3,
        symbol_by_symbol: bool = False,
    ):
        super().__init__()
        self.M_bits = num_bits_per_symbol
        self.M = 1 << num_bits_per_symbol  # 2,4,8,…
        self.freq_sep = frequency_spacing
        self.Ts = symbol_duration
        self.Fs = sampling_frequency
        self.sps = int(self.Fs * self.Ts)  # samples / symbol
        if self.sps % 2 == 0:  # keep it odd
            self.sps += 1
        self.symbol_by_symbol = symbol_by_symbol

        # ------------------------------------------------------------------ #
        # front‑end filter (same as transmitter) and matched‑filter partner  #
        # ------------------------------------------------------------------ #
        if gaussian:
            self.filter = GaussianFilter(3, upsampling_factor=self.sps, bt=bt, normalize=False)
        else:
            self.filter = RectFilter(1, upsampling_factor=self.sps)
        self.va_mem = self.filter.span_in_symbols
        # Mapper / Demapper (PAM levels are −(M−1), …, +(M−1))
        self.mapper = Mapper("pam", num_bits_per_symbol, normalize=False)
        self.const = self.mapper.get_constellation()  # (M,)
        self.bit_map = self.mapper.get_bit_mapping()  # dict: sym→bits
        self.demapper = SymbolDemapper(self.const, self.bit_map)

        # ------------------------------------------------------------------ #
        # Pre‑compute symbol‑rate channel taps for the Viterbi branch        #
        # ------------------------------------------------------------------ #
        self.taps = self._symbol_rate_taps(self.va_mem)  # (L,)
        # NOTE: taps[0] is always 1 because of matched filtering normalisation

        # Build state mapping once (for VA)
        self._states, self._prev_lookup = self._enumerate_states()

    @property
    def input_type(self) -> DataType:
        return DataType.BASEBAND_SIGNAL

    @property
    def output_type(self) -> DataType:
        return DataType.BITS

    def __call__(self, signal: np.ndarray) -> np.ndarray:

        batches, total = signal.shape
        n_sym = total // self.sps
        if total % self.sps:
            signal = signal[:, : n_sym * self.sps]
            warnings.warn("Input truncated to an integer number of symbols.")

        # -------------------------------------------------------------- #
        # Phase → freq → matched‑filter (identical to your original)     #
        # -------------------------------------------------------------- #
        # phase = np.angle(signal)
        # phase_unwrap = np.unwrap(phase, axis=1)
        # diff_phase = np.diff(phase_unwrap, axis=1)
        dtheta = np.angle(signal[:, 1:] * np.conj(signal[:, :-1]))  # length N‑1
        freq_est = dtheta * self.Fs / (2 * np.pi)  # Hz
        u_est = freq_est / (self.freq_sep / 2)
        # freq_est = diff_phase * self.Fs / (2 * np.pi)  # Hz
        # u_est = freq_est / (self.freq_sep / 2)  # ±1,±3,±5…
        u_matched = self.filter.apply_matched_filter(u_est)

        start = self.filter.span_in_symbols * self.sps
        soft = u_matched[:, start :: self.sps][:, :n_sym]  # (B, K)

        if self.symbol_by_symbol or self.va_mem == 1:
            # ---------- legacy: slice & direct PAM demap --------------
            return self._pam_slice_demod(soft)

        # ---------- new: sequence detector on each burst --------------

        # Viterbi: iterate over bursts
        out = np.empty((batches, n_sym * self.M_bits), dtype=np.uint8)
        for b in range(batches):
            out[b] = self._viterbi_one_burst(soft[b])
        return out

    # ---------------------------------------------------------------------- #
    # Helpers                                                                #
    # ---------------------------------------------------------------------- #
    def _pam_slice_demod(self, soft_symbols: np.ndarray) -> np.ndarray:
        """Your original “single-symbol” flow."""
        return self.demapper(soft_symbols.astype(np.complex128))

    # ---- 1. obtain channel taps at symbol rate --------------------------- #
    def _symbol_rate_taps(self, L: int) -> np.ndarray:
        """
        Send a delta through the matched filter and sample once / symbol.
        Gives the *discrete partial-response channel* h[0..L-1].
        """
        span = self.filter.span_in_symbols
        N = (span + 1) * self.sps + 1
        delta = np.zeros(N)
        delta[span * self.sps] = 1.0  # impulse at t=0
        mf_out = self.filter.apply_matched_filter(delta[None, :])[0]
        taps = mf_out[span * self.sps : span * self.sps + L * self.sps : self.sps]
        taps /= taps[0]  # normalise so h[0]=1
        return taps  # shape (L,)

    # ---- 2. build state book for Viterbi --------------------------------- #
    def _enumerate_states(self) -> Tuple[List[Tuple[int, ...]], dict]:
        """
        Returns
        -------
        states : list of tuples of symbol indices (len = M^{L-1})
            State #i is a tuple of the (L-1) previous symbol *indices*.
        prev_lookup : dict[state_index] → list[(prev_state_index, sym_index)]
            For fast VA branch generation.
        """
        if self.va_mem == 1:
            return [()], {0: [(0, m) for m in range(self.M)]}

        states = list(itertools.product(range(self.M), repeat=self.va_mem - 1))  # (L-1)-tuple
        to_idx = {s: i for i, s in enumerate(states)}

        prev_lookup = {i: [] for i in range(len(states))}
        for i, s in enumerate(states):
            for m in range(self.M):
                new_s = (m,) + s[:-1]  # push current sym in, drop last
                prev_lookup[to_idx[new_s]].append((i, m))
        return states, prev_lookup

    # ---- 3. Viterbi over real partial‑response channel ------------------- #
    def _viterbi_one_burst(self, soft: np.ndarray) -> np.ndarray:
        """
        soft : shape (K,)  real matched-filter samples for one burst
        Returns hard-bit array length = K * M_bits
        """
        K = len(soft)
        L = self.va_mem
        h = self.taps  # (L,)

        n_states = self.M ** (L - 1) if L > 1 else 1
        big = 1e12
        metric = np.zeros(n_states) + big
        metric[0] = 0.0  # start from “all zeros”

        # For traceback
        surv_state = np.zeros((K, n_states), dtype=np.int32)
        surv_symbol = np.zeros((K, n_states), dtype=np.int32)

        const = self.const  # symbol amplitudes

        for k in range(K):
            yk = soft[k]
            mnew = np.zeros_like(metric) + big
            for s_cur in range(n_states):
                for s_prev, sym_idx in self._prev_lookup[s_cur]:
                    # predicted sample = h0 * a_k  + Σ_{i=1}^{L-1} h_i * a_{k-i}
                    pred = h[0] * const[sym_idx]
                    if L > 1:
                        prev_syms = self._states[s_prev]
                        for d, a_prev_idx in enumerate(prev_syms, 1):
                            pred += h[d] * const[a_prev_idx]
                    br_metric = (yk - pred) ** 2
                    cost = metric[s_prev] + br_metric
                    if cost < mnew[s_cur]:
                        mnew[s_cur] = cost
                        surv_state[k, s_cur] = s_prev
                        surv_symbol[k, s_cur] = sym_idx
            metric = mnew

        # ---------- traceback ----------
        s_hat = int(np.argmin(metric))
        sym_hat = np.zeros(K, dtype=int)
        for k in range(K - 1, -1, -1):
            sym_hat[k] = surv_symbol[k, s_hat]
            s_hat = surv_state[k, s_hat]

        # map to bits with your existing SymbolDemapper
        sym_amp = np.atleast_2d(const[sym_hat].astype(np.complex128))  # make it complex
        return self.demapper(sym_amp)
