import warnings

import numpy as np

from ria_toolkit_oss.signal.block_generator.continuous_modulation.coherent_correlator import (
    CoherentCorrelator,
)
from ria_toolkit_oss.signal.block_generator.continuous_modulation.demodulator import (
    Demodulator,
)
from ria_toolkit_oss.signal.block_generator.data_types import DataType


class FSKDemodulator(Demodulator):
    """
    A coherent FSK demodulator that uses a bank of correlators for symbol detection.

    The received baseband signal (assumed to be a 2D array of shape (batch_size, total_samples))
    is segmented into symbol intervals. Each correlator processes the signal over each symbol,
    returning a decision statistic. For each symbol period, the demodulator selects the candidate
    with the maximum absolute correlation output, converts that candidate index into a bit sequence,
    and outputs the recovered bit stream.

    Parameter constraints:
      - frequency_spacing * symbol_duration must be at least 0.5 (for coherent detection).
      - The lowest candidate frequency (when mapping symmetrically about center_frequency)
        must be positive.

    :param num_bits_per_symbol: Number of bits per symbol.
    :type num_bits_per_symbol: int
    :param frequency_spacing: The frequency spacing (Hz) between adjacent symbols.
                              Note: Effective frequency offsets are (frequency_spacing/2) times the
                              mapped odd integers.
    :type frequency_spacing: float
    :param symbol_duration: The duration (seconds) of one symbol period.
    :type symbol_duration: float
    :param sampling_frequency: The sampling frequency (Hz) of the received signal.
    :type sampling_frequency: float

    :raises AssertionError: If frequency_spacing * symbol_duration < 1, or if the lowest candidate frequency
                            is not positive.
    """

    def __init__(
        self, num_bits_per_symbol: int, frequency_spacing: float, symbol_duration: float, sampling_frequency: float
    ):
        # Assert that the frequency spacing and symbol duration are sufficient
        # to maintain orthogonality for coherent FSK.
        assert frequency_spacing * symbol_duration >= 0.5, (
            "For orthogonal coherent FSK, frequency_spacing * symbol_duration must be at least 0.5. "
            f"Received frequency_spacing={frequency_spacing} and symbol_duration={symbol_duration}"
        )

        # Calculate the largest possible carrier frequency from the candidate mapping.
        largest_carrier = (2**num_bits_per_symbol - 1) / 2 * frequency_spacing
        if sampling_frequency < 2 * largest_carrier:
            warnings.warn(
                f"Sampling frequency ({sampling_frequency} Hz) is less than twice the largest carrier frequency "
                f"({largest_carrier} Hz). This may violate the Nyquist criterion and cause aliasing.",
                UserWarning,
            )

        self.num_bits_per_symbol = num_bits_per_symbol
        self.frequency_spacing = frequency_spacing
        self.symbol_duration = symbol_duration
        self.sampling_frequency = sampling_frequency

        # Number of candidate symbols.
        self.num_candidates = 2**self.num_bits_per_symbol
        # Map candidate indices to odd integers:
        # For example, if num_candidates=4, candidate_indices = [-3, -1, 1, 3].
        self.candidate_indices = 2 * np.arange(self.num_candidates) - (self.num_candidates - 1)
        # Compute the candidate carrier frequencies.
        self.candidate_frequencies = (self.frequency_spacing / 2) * self.candidate_indices
        # Create a bank of correlators for each candidate frequency.
        self.correlators = [
            CoherentCorrelator(f_c, self.symbol_duration, self.sampling_frequency, False)
            for f_c in self.candidate_frequencies
        ]

    @property
    def input_type(self) -> DataType:
        """The demodulator expects a passband signal as input."""
        return DataType.PASSBAND_SIGNAL

    @property
    def output_type(self) -> DataType:
        """The demodulator produces a bit stream as output."""
        return DataType.BITS

    def __call__(self, signal: np.ndarray) -> np.ndarray:
        """
        Demodulate the received FSK signal using a bank of coherent correlators.

        The received signal is assumed to be a 2D numpy array of shape
        (batch_size, total_samples), where total_samples is an integer multiple of the
        number of samples per symbol (samples_per_symbol = symbol_duration * sampling_frequency).

        For each candidate frequency, the corresponding correlator processes the signal and
        returns decision statistics (one per symbol). The demodulator then selects, for each symbol,
        the candidate with the maximum absolute correlation value, and converts that candidate index
        into its corresponding bit representation.

        :param signal: The received passband signal (shape: (batch_size, total_samples)).
        :type signal: np.ndarray
        :return: A 2D numpy array of shape (batch_size, num_bits), where
                num_bits = (total_samples / samples_per_symbol) * num_bits_per_symbol.
        :rtype: np.ndarray
        :raises ValueError: If total_samples is not an integer multiple of samples_per_symbol.
        """
        batch_size, total_samples = signal.shape
        samples_per_symbol = int(self.symbol_duration * self.sampling_frequency)
        excess_samples = total_samples % samples_per_symbol
        if excess_samples != 0:
            signal = signal[:, : total_samples - excess_samples]

        # Process the signal with each correlator in the bank.
        # Each correlator returns an array of shape (batch_size, num_symbols).
        stats = [corr(signal) for corr in self.correlators]
        # Stack along a new axis: shape (num_candidates, batch_size, num_symbols)
        stats = np.stack(stats, axis=0)
        # For each symbol (per batch), select the candidate with the maximum absolute correlation.
        # decision_indices: shape (batch_size, num_symbols) with values in {0, ..., num_candidates - 1}.
        decision_indices = np.argmax(np.abs(stats), axis=0)

        # Convert candidate indices to bit sequences.
        # Each candidate index is in the range [0, num_candidates - 1] and is represented with num_bits_per_symbol bits
        # We convert each decision index into its binary representation.
        bits = ((decision_indices[..., None] >> np.arange(self.num_bits_per_symbol - 1, -1, -1)) & 1).astype(np.int32)
        # Reshape the bits to produce a bit stream of shape (batch_size, num_symbols * num_bits_per_symbol).
        bits = bits.reshape(batch_size, -1)
        return bits

    def __str__(self) -> str:
        """Return a string representation of the FSKDemodulator."""
        return (
            f"FSKDemodulator(num_bits_per_symbol={self.num_bits_per_symbol}, "
            f"frequency_spacing={self.frequency_spacing}, "
            f"symbol_duration={self.symbol_duration}, "
            f"sampling_frequency={self.sampling_frequency})"
        )
