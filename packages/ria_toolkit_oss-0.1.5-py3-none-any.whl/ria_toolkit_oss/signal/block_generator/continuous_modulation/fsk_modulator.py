import warnings

import numpy as np

from ria_toolkit_oss.signal.block_generator.continuous_modulation.modulator import (
    Modulator,
)
from ria_toolkit_oss.signal.block_generator.data_types import DataType


class FSKModulator(Modulator):
    """
    A modulator for Frequency Shift Keying (FSK) signals that converts binary sequences into
    baseband waveforms with frequencies mapped symmetrically about a given center frequency.

    This design yields carrier frequencies that are symmetrically distributed around the
    `fc=0`. A sinusoidal waveform at the corresponding frequency is generated over
    the symbol duration, and the complete modulated signal is obtained by concatenating the
    waveforms for all symbols.

    The modulator also enforces parameter constraints:
      - The product of `frequency_spacing` and `symbol_duration` must be at least 0.5 to ensure
        sufficient frequency separation for coherent FSK.
      - The lowest frequency, when mapping symbols symmetrically about the center, must be positive.

    :param num_bits_per_symbol: Number of bits per symbol.
    :type num_bits_per_symbol: int
    :param frequency_spacing: The frequency spacing (Hz) between adjacent symbols. Effective spacing
                              is half of this value when using the odd integer mapping.
    :type frequency_spacing: float
    :param symbol_duration: The duration (seconds) of each symbol.
    :type symbol_duration: float
    :param sampling_frequency: The sampling frequency (Hz) used to generate the waveform.
    :type sampling_frequency: float

    :raises AssertionError: If frequency_spacing * symbol_duration is less than 1, or if the
                            computed lowest frequency is not positive.
    """

    def __init__(
        self,
        num_bits_per_symbol: int,
        frequency_spacing: float,
        symbol_duration: float,
        sampling_frequency: float,
    ):
        # Assert that the frequency spacing and symbol duration are sufficient
        # to maintain orthogonality for coherent FSK.
        assert frequency_spacing * symbol_duration >= 0.5, (
            "For orthogonal discontinuous phase FSK, frequency_spacing * symbol_duration must be at least 0.5. "
            f"Received frequency_spacing={frequency_spacing} and symbol_duration={symbol_duration}"
        )

        # Calculate the largest possible carrier frequency from the candidate mapping.
        largest_carrier = ((2**num_bits_per_symbol - 1) / 2) * frequency_spacing
        if sampling_frequency < 2 * largest_carrier:
            warnings.warn(
                f"Sampling frequency ({sampling_frequency} Hz) is less than twice the largest carrier frequency "
                f"({largest_carrier} Hz). This may violate the Nyquist criterion and cause aliasing.",
                UserWarning,
            )
        self.num_bits_per_symbol = num_bits_per_symbol
        self.frequency_spacing = frequency_spacing
        self.symbol_duration = symbol_duration
        self.sampling_frequency = sampling_frequency

    @property
    def input_type(self) -> DataType:
        return DataType.BITS

    @property
    def output_type(self) -> DataType:
        return DataType.PASSBAND_SIGNAL

    def get_samples(self, num_samples):
        raise NotImplementedError

    def __call__(self, bits: np.ndarray) -> np.ndarray:
        """
        Modulate a batch of binary sequences into FSK waveforms in a vectorized manner.

        Each row of the input 2D numpy array is treated as an independent bit stream.
        The bits are grouped into symbols of length `num_bits_per_symbol`, converted to integer
        symbol indices using MSB-first ordering, and then mapped to odd integer values centered around zero.
        These symbol indices are used to compute the carrier frequencies for each symbol as:

            frequency = (frequency_spacing / 2) * symbol_indices

        A sinusoidal waveform is generated for each symbol over the symbol duration,
        and the waveforms for all symbols are concatenated to form the final modulated signal.

        :param bits: A 2D numpy array of shape (batch_size, num_bits), where each row is a separate bit stream.
        :type bits: np.ndarray
        :return: A 2D numpy array of shape (batch_size, total_samples) representing the modulated baseband signal,
                 where total_samples = (num_bits // num_bits_per_symbol) * (symbol_duration * sampling_frequency).
        :rtype: np.ndarray
        :raises ValueError: If the number of bits per row is not a multiple of num_bits_per_symbol.
        """
        batch_size, num_bits = bits.shape

        if num_bits % self.num_bits_per_symbol != 0:
            raise ValueError(
                f"The number of bits per row ({num_bits}) must be a multiple of "
                f"num_bits_per_symbol ({self.num_bits_per_symbol})."
            )

        # Calculate the number of symbols per bit stream.
        num_symbols = num_bits // self.num_bits_per_symbol

        # Reshape to (batch_size, num_symbols, num_bits_per_symbol) and convert bits to integers.
        bits_reshaped = bits.reshape(batch_size, num_symbols, self.num_bits_per_symbol).astype(np.int32)
        # Create a vector of powers for MSB-first conversion: [2^(n-1), ..., 2^0].
        powers_of_two = 1 << np.arange(self.num_bits_per_symbol)[::-1]
        raw_indices = np.sum(bits_reshaped * powers_of_two, axis=2)
        # Map raw indices to odd integers centered about zero.
        symbol_indices = 2 * (raw_indices + 1) - 2**self.num_bits_per_symbol - 1

        # Map symbols to carrier frequencies.
        frequencies = symbol_indices * self.frequency_spacing / 2

        # Compute the number of samples per symbol.
        samples_per_symbol = int(self.symbol_duration * self.sampling_frequency)
        total_samples = num_symbols * samples_per_symbol

        # Create a time vector for one symbol period and reshape for broadcasting.
        t = np.linspace(0, self.symbol_duration, samples_per_symbol, endpoint=False)[None, None, :]

        # Generate the sinusoidal waveform for each symbol in a vectorized manner.
        symbol_waveforms = np.exp(2j * np.pi * frequencies[:, :, None] * t)

        # Concatenate the symbol waveforms to form the final modulated waveform.
        waveform = symbol_waveforms.reshape(batch_size, total_samples)
        return waveform
