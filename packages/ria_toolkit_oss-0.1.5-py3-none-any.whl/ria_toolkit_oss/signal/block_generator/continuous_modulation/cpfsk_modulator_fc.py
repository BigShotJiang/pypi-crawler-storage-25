import warnings
from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.continuous_modulation.modulator import (
    Modulator,
)
from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.mapping.mapper import Mapper
from ria_toolkit_oss.signal.block_generator.multirate.upsampling import Upsampling
from ria_toolkit_oss.signal.block_generator.pulse_shaping.gaussian_filter import (
    GaussianFilter,
)
from ria_toolkit_oss.signal.block_generator.pulse_shaping.rect_filter import RectFilter


class CPFSKModulator(Modulator):
    def __init__(
        self,
        num_bits_per_symbol: int,
        center_frequency: float,
        frequency_spacing: float,
        symbol_duration: float,
        sampling_frequency: float,
        gaussian: Optional[bool] = False,
    ):
        # Assert that the frequency spacing and symbol duration are sufficient
        # to maintain orthogonality for coherent FSK.
        assert frequency_spacing * symbol_duration >= 0.5, (
            "For orthogonal coherent FSK, frequency_spacing * symbol_duration must be at least 0.5. "
            f"Received frequency_spacing={frequency_spacing} and symbol_duration={symbol_duration}"
        )
        # Ensure that the lowest frequency (when mapping symbols symmetrically about the center) is positive.
        assert center_frequency - ((2**num_bits_per_symbol - 1) / 2) * frequency_spacing > 0, (
            f"With center_frequency={center_frequency} Hz, frequency_spacing={frequency_spacing} Hz, "
            f"and num_bits_per_symbol={num_bits_per_symbol}, the lowest frequency would be "
            f"{center_frequency - ((2**num_bits_per_symbol - 1) / 2) * frequency_spacing} Hz, which must be positive."
        )

        # Calculate the largest possible carrier frequency from the candidate mapping.
        largest_carrier = center_frequency + ((2**num_bits_per_symbol - 1) / 2) * frequency_spacing
        if sampling_frequency < 2 * largest_carrier:
            warnings.warn(
                f"Sampling frequency ({sampling_frequency} Hz) is less than twice the largest carrier frequency "
                f"({largest_carrier} Hz). This may violate the Nyquist criterion and cause aliasing.",
                UserWarning,
            )

        self.num_bits_per_symbol = num_bits_per_symbol
        self.center_frequency = center_frequency
        self.frequency_spacing = frequency_spacing
        self.symbol_duration = symbol_duration
        self.sampling_frequency = sampling_frequency
        self.samples_per_symbol = int(self.sampling_frequency * self.symbol_duration)
        self.pam_mapper = Mapper("pam", num_bits_per_symbol, normalize=False)
        self.us = Upsampling(self.samples_per_symbol)
        if gaussian:
            self.filter = GaussianFilter(1, upsampling_factor=self.samples_per_symbol, bt=0.3, normalize=False)
        else:
            self.filter = RectFilter(1, upsampling_factor=self.samples_per_symbol, normalize=False)

    @property
    def input_type(self) -> DataType:
        return DataType.BITS

    @property
    def output_type(self) -> DataType:
        return DataType.PASSBAND_SIGNAL

    def get_samples(self, num_samples):
        raise NotImplementedError

    def __call__(self, bits: np.ndarray) -> np.ndarray:
        batch_size, num_bits = bits.shape

        # Validate bit length
        if num_bits % self.num_bits_per_symbol != 0:
            raise ValueError(
                f"The number of bits per row ({num_bits}) must be a multiple of "
                f"num_bits_per_symbol ({self.num_bits_per_symbol})."
            )

        # 1) Map bits to symbols (e.g., PAM), shape -> (batch_size, num_symbols)
        symbols = np.real(self.pam_mapper(bits))

        # 2) Upsample each row by 'samples_per_symbol', shape -> (batch_size, num_symbols * samples_per_symbol)
        x_upsampled = self.us(symbols)

        # 3) Filter (Rect or Gaussian), shape still -> (batch_size, total_samples)
        x_shaped = self.filter(x_upsampled)

        # For CPFSK, interpret x_shaped as a frequency offset around center_frequency.
        # A common convention is to let freq_dev = frequency_spacing / 2 if you want ± frequency_spacing/2 offset,
        # but you can also set freq_dev = frequency_spacing if that suits your design.
        freq_dev = self.frequency_spacing / 2.0

        # Compute the instantaneous frequency for all samples and all batches
        freq_inst = self.center_frequency + freq_dev * x_shaped  # shape: (batch_size, total_samples)

        # Compute the phase increment per sample and perform a cumulative sum along axis=1 (time axis)
        phase = np.cumsum(2 * np.pi * freq_inst / self.sampling_frequency, axis=1)

        # Generate the CPFSK waveform by taking the cosine of the phase
        total_samples = num_bits // self.num_bits_per_symbol * self.samples_per_symbol
        waveform = np.cos(phase)[:, :total_samples]

        return waveform
