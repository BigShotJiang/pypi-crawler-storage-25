from abc import ABC, abstractmethod

import numpy as np

from ria_toolkit_oss.signal.block_generator.block import Block


class Demodulator(Block, ABC):
    @abstractmethod
    def __call__(self, *args, **kwargs) -> np.ndarray:
        raise NotImplementedError
