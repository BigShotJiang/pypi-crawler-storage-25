import numpy as np

from ria_toolkit_oss.signal.block_generator.continuous_modulation.demodulator import (
    Demodulator,
)
from ria_toolkit_oss.signal.block_generator.data_types import DataType


class CoherentCorrelator(Demodulator):
    """
    A correlator for coherent detection that performs frequency downconversion via correlation.

    This class implements a coherent correlator by multiplying the received passband signal
    with a reference carrier and integrating (or convolving with an optional matched filter)
    over one symbol period. The reference carrier can be generated in one of two ways:
      - If 'per_symbol' is True, the carrier reference is generated for each symbol separately
        (i.e. a time vector that resets to zero for every symbol).
      - If 'per_symbol' is False, a continuous time vector is used over the entire signal.

    Optionally, a pulse-shaping filter (subclass of PulseShapingFilter) can be provided. When set,
    each symbol's downconverted product is first convolved with the matched filter (via its
    `apply_matched_filter` method) before integration. If not provided, a simple integration (sum)
    is performed.

    :param carrier_frequency: The carrier frequency (Hz) used for demodulation.
    :param symbol_duration: The duration (seconds) of one symbol period.
    :param sampling_rate: The sampling rate (Hz) of the received signal.
    :param per_symbol: If True, uses a per-symbol time vector; if False, uses a continuous time vector.
    """

    def __init__(
        self,
        carrier_frequency: float,
        symbol_duration: float,
        sampling_rate: float,
        per_symbol: bool = True,
    ):
        self.carrier_frequency = carrier_frequency
        self.symbol_duration = symbol_duration
        self.sampling_rate = sampling_rate
        self.samples_per_symbol = int(self.symbol_duration * self.sampling_rate)
        self.per_symbol = per_symbol

    @property
    def input_type(self) -> DataType:
        """The correlator expects a passband signal as input."""
        return DataType.PASSBAND_SIGNAL

    @property
    def output_type(self) -> DataType:
        """The correlator produces decision statistics (typically complex or real values)."""
        return DataType.BITS

    def __call__(self, signal: np.ndarray) -> np.ndarray:
        """
        Correlate the input passband signal with a reference carrier to produce decision statistics.

        The input signal is assumed to be a 2D numpy array of shape (batch_size, total_samples),
        where total_samples is an integer multiple of the number of samples per symbol.

        Depending on the 'per_symbol' flag, the reference carrier is generated as:
          - If True: a per-symbol time vector (from 0 to symbol_duration) is used.
          - If False: a continuous time vector for the entire signal is used.

        If a pulse shaping filter is provided (self.filter is not None), the symbol's product
        (signal multiplied by the reference carrier) is convolved with the filter via its
        `apply_matched_filter` method before integration.

        :param signal: The input passband signal (shape: (batch_size, total_samples)).
        :return: A 2D numpy array of decision statistics with shape (batch_size, num_symbols).
        :raises ValueError: If the total number of samples is not an integer multiple of samples_per_symbol.
        """
        batch_size, total_samples = signal.shape
        samples_per_symbol = self.samples_per_symbol

        if total_samples % samples_per_symbol != 0:
            raise ValueError(
                "The total number of samples in the signal must be an integer multiple of the samples per symbol."
            )

        num_symbols = total_samples // samples_per_symbol
        # Reshape the signal into symbols: shape (batch_size, num_symbols, samples_per_symbol)
        symbols = signal.reshape(batch_size, num_symbols, samples_per_symbol)

        if self.per_symbol:
            # Generate per-symbol time vector (from 0 to symbol_duration)
            t_symbol = np.arange(samples_per_symbol) / self.sampling_rate
            if np.iscomplexobj(signal):
                reference = np.exp(-1j * 2 * np.pi * self.carrier_frequency * t_symbol)
            else:
                reference = np.cos(2 * np.pi * self.carrier_frequency * t_symbol)
            # Multiply each symbol with the reference (broadcasted) to obtain the product.
            product = symbols * reference[None, None, :]
        else:
            # Use a continuous time vector for the entire signal.
            t_full = np.arange(total_samples) / self.sampling_rate
            if np.iscomplexobj(signal):
                reference_full = np.exp(-1j * 2 * np.pi * self.carrier_frequency * t_full)
            else:
                reference_full = np.cos(2 * np.pi * self.carrier_frequency * t_full)
            reference_full = reference_full.reshape(1, num_symbols, samples_per_symbol)
            product = symbols * reference_full

        decision_stats = np.sum(product, axis=2)
        return decision_stats

    def __str__(self) -> str:
        """Return a string representation of the CoherentCorrelator."""
        return (
            f"CoherentCorrelator(carrier_frequency={self.carrier_frequency}, "
            f"symbol_duration={self.symbol_duration}, sampling_rate={self.sampling_rate} "
        )
