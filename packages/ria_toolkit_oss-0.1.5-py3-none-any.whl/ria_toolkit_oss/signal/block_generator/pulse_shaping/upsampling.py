import math
from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class Upsampling(ProcessBlock, RecordableBlock):
    """
    Upsampling Block

    Upsample the input signal. This means that each input symbol will be followed by n-1 0 samples,
    where n is the upsampling factor. This process is performed before a pulse shaping filter to convert
    symbols into IQ samples. Ensure that the upsampling factor of both the upsampler and the filter are the same.

    For example, if factor = 4:
    Input = [1,1,1,1]

    Output = [1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0]

    Input Type: SYMBOLS
    Output Type: UPSAMPLED_SYMBOLS

    :param factor: The upsampling factor.
    :type factor: int
    """

    def __init__(self, factor: Optional[int] = 4):
        self.factor = factor

    @property
    def input_type(self) -> DataType:
        """Get the input data type for the upsampling operation.

        :return: The input data type.
        :rtype: DataType
        """
        return [DataType.SYMBOLS]

    @property
    def output_type(self) -> DataType:
        """Get the output data type for the upsampling operation.

        :return: The output data type.
        :rtype: DataType
        """
        return DataType.UPSAMPLED_SYMBOLS

    def get_samples(self, num_samples) -> np.ndarray:
        """Upsample the input signal by inserting zeros between samples.

        :param signal: The input signal to be upsampled. Shape should be (n_samples, n_bits).
        :type signal: numpy array

        :return: The upsampled signal. Shape will be (n_samples, n_bits * factor).
        :rtype: numpy array
        """
        return self.__call__([self.input[0].get_samples(int(math.ceil(num_samples / self.factor)))[:num_samples]])

    def __call__(self, samples):
        """
        Upsample an array of complex samples.

        :param samples: A list containing a single array of complex samples.
        :type samples: list of np.array

        :returns: Processed samples.
        :rtype: np.array"""
        signal = samples[0]
        us_signal = np.zeros(len(signal) * self.factor, dtype=signal.dtype)
        us_signal[:: self.factor] = signal
        return us_signal
