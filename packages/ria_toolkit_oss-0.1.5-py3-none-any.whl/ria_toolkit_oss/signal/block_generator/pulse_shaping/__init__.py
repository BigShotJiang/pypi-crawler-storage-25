"""
A set of blocks to pulse shape a modulated signal.

Pulse shaping is a signal processing technique
used in digital communications to modify the waveform
of transmitted pulses to improve efficiency and reduce
interference.
It helps control the bandwidth of the
transmitted signal and minimizes intersymbol
interference (ISI), which occurs when overlapping
pulses cause errors in symbol detection.
Common filters include Sinc, Raised Cosine and Root Raised Cosine.

Filters are applied to upsampled signal, which consists of
each input symbol followed by n-1 0 samples, where n is the
upsampling factor.

Example Usage:

    >>> from ria_toolkit_oss.signal.block_generator import BinarySource, Mapper, Upsampling, RaisedCosineFilter

    >>> # create digital modulaiton symbols
    >>> source = BinarySource()
    >>> mapper = Mapper(constellation_type='psk', num_bits_per_symbol=2)
    >>> mapper.connect_input([source])

    >>> # pulse shape the symbols
    >>> upsampling_factor = 4
    >>> upsampler = Upsampling(factor = upsampling_factor)
    >>> upsampler.connect_input([mapper])
    >>> filter = RaisedCosineFilter(span_in_symbols=100, upsampling_factor=upsampling_factor, beta=0.1)
    >>> filter.connect_input([upsampler])
    >>> filter.record(num_samples = 10000)
"""

from .gaussian_filter import GaussianFilter
from .pulse_shaping_filter import PulseShapingFilter
from .raised_cosine_filter import RaisedCosineFilter
from .rect_filter import RectFilter
from .root_raised_cosine_filter import RootRaisedCosineFilter
from .sinc_filter import SincFilter
from .upsampling import Upsampling

__all__ = [
    "PulseShapingFilter",
    "GaussianFilter",
    "RaisedCosineFilter",
    "RootRaisedCosineFilter",
    "RectFilter",
    "SincFilter",
    "Upsampling",
]
