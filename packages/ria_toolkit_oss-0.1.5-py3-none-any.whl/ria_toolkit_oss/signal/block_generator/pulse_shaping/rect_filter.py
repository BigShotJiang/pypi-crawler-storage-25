from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.pulse_shaping.pulse_shaping_filter import (
    PulseShapingFilter,
)


class RectFilter(PulseShapingFilter):
    r"""
    A class to implement the rectangular (boxcar) filter.

    The rectangular filter is defined by a constant amplitude over its span. In discrete time,
    this translates to filter coefficients that are all ones (or all some constant). If normalization
    is enabled, the base class's :meth:`_normalize_weights` method will apply the chosen normalization
    rule (e.g., unit energy or unit sum).

    :param span_in_symbols: The span of the filter in terms of symbols.
    :type span_in_symbols: int
    :param upsampling_factor: The number of samples per symbol.
    :type upsampling_factor: int
    :param normalize: Whether to normalize the filter coefficients, defaults to True.
    :type normalize: bool, optional
    """

    def __init__(self, span_in_symbols: int, upsampling_factor: int, normalize: Optional[bool] = True):
        # Calculate the total number of taps (ensure it's odd, similar to SincFilter)
        num_taps = span_in_symbols * upsampling_factor
        if num_taps % 2 == 0:
            num_taps += 1

        # Generate and optionally normalize the filter coefficients
        weights = self._generate_weights(num_taps)
        super().__init__(span_in_symbols, upsampling_factor, weights, normalize)

    def _generate_weights(self, num_taps) -> np.ndarray:
        """
        Generate the weights for the rectangular filter.

        :return: A 1D numpy array of ones of length `self.num_taps`.
        :rtype: np.ndarray
        """
        return np.ones(num_taps)

    def __str__(self) -> str:
        """
        Return a string representation of the RectFilter object.

        :return: A string describing the RectFilter with its parameters.
        :rtype: str
        """
        return f"RectFilter(span_in_symbols={self.span_in_symbols}, upsampling_factor={self.upsampling_factor})"
