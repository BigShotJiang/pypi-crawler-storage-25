from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.pulse_shaping.pulse_shaping_filter import (
    PulseShapingFilter,
)


class GaussianFilter(PulseShapingFilter):
    r"""
    A class to implement the Gaussian filter used in GMSK.

    The Gaussian filter impulse response in continuous time can be expressed as:

    .. math::
        h(t) = \frac{1}{\sqrt{2\pi}\,\sigma} \exp\!\Bigl(-\frac{t^2}{2\,\sigma^2}\Bigr),

    where :math:`\sigma` is related to the bandwidth-time product (BT). In many references, one sets
    :math:`BT` for the 3 dB bandwidth and the symbol period :math:`T=1`, leading to

    .. math::
        \sigma = \frac{\sqrt{\ln(2)}}{2\,\pi\,BT}.

    For discrete-time implementation, we sample :math:`h(t)` over a finite span in symbols (``span_in_symbols``)
    and at ``upsampling_factor`` samples per symbol. If ``normalize=True``, the filter coefficients are normalized
    according to the base class's :meth:`_normalize_weights` method (which might be unit-energy or unit-sum, depending
    on your implementation).

    :param span_in_symbols: The span of the filter in terms of symbols.
    :type span_in_symbols: int
    :param upsampling_factor: The number of samples per symbol.
    :type upsampling_factor: int
    :param bt: The bandwidth-time product, a key parameter for Gaussian filters.
    :type bt: float
    :param normalize: Whether to normalize the filter coefficients, defaults to True.
    :type normalize: bool, optional
    """

    def __init__(self, span_in_symbols: int, upsampling_factor: int, bt: float, normalize: Optional[bool] = True):
        self.bt = bt

        # Calculate the total number of taps; ensure it's odd (like in SincFilter).
        num_taps = span_in_symbols * upsampling_factor
        if num_taps % 2 == 0:
            num_taps += 1

        # Generate and optionally normalize the filter coefficients
        weights = self._generate_weights(num_taps, upsampling_factor)
        super().__init__(span_in_symbols, upsampling_factor, weights, normalize)

    def _generate_weights(self, num_taps, upsampling_factor) -> np.ndarray:
        r"""
        Generate the Gaussian filter coefficients for GMSK.

        In normalized units (symbol period :math:`T = 1`), we define:

        .. math::
            \sigma = \frac{\sqrt{\ln(2)}}{2\,\pi\,BT}

        and compute the discrete-time Gaussian:

        .. math::
            h[n] = \frac{1}{\sqrt{2\pi}\,\sigma} \exp\!\Bigl(-\frac{t^2}{2\,\sigma^2}\Bigr),

        where :math:`t = \frac{n}{\text{upsampling_factor}}` in the range
        :math:`\pm \frac{\text{span_in_symbols}}{2}` symbols.

        :return: A 1D numpy array of Gaussian filter taps.
        :rtype: np.ndarray
        """
        # Define sigma based on the bandwidth-time product (BT)
        sigma = np.sqrt(np.log(2)) / (2 * np.pi * self.bt)

        # Create a symmetric time axis in "symbol units".
        # Example: if num_taps=11, we get n from -5..5, so time from -5/upsamp..+5/upsamp
        half = num_taps // 2
        n = np.arange(-half, half + 1)
        t_axis = n / upsampling_factor  # in "symbol durations"

        # Compute the Gaussian pulse
        gauss = 1.0 / (np.sqrt(2.0 * np.pi) * sigma) * np.exp(-0.5 * (t_axis / sigma) ** 2)
        return gauss

    def __str__(self) -> str:
        """
        Return a string representation of the GaussianFilter object.

        :return: A string describing the GaussianFilter with its parameters.
        :rtype: str
        """
        return (
            f"GaussianFilter(span_in_symbols={self.span_in_symbols}, "
            f"upsampling_factor={self.upsampling_factor}, bt={self.bt})"
        )
