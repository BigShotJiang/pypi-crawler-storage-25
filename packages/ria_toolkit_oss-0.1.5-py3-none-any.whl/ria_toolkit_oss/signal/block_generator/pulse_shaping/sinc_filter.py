from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.pulse_shaping.pulse_shaping_filter import (
    PulseShapingFilter,
)


class SincFilter(PulseShapingFilter):
    r"""
    Sinc Filter Block

    Apply a sinc filter to an upsampled signal.

    Input Type: UPSAMPLED_SYMBOLS

    Output Type: BASEBAND_SIGNAL

    The sinc filter is defined by the following equation:

    .. math::

        h(t) = \frac{1}{T}\text{sinc}\left(\frac{t}{T}\right)

    where :math:`T` the symbol duration.

    :param span_in_symbols: The span of the filter in terms of symbols.
    :type span_in_symbols: int
    :param upsampling_factor: The number of samples per symbol.
    :type upsampling_factor: int
    :param normalize: Whether to normalize the filter coefficients, defaults to True.
    :type normalize: bool, optional
    """

    def __init__(
        self,
        span_in_symbols: Optional[int] = 100,
        upsampling_factor: Optional[int] = 4,
        normalize: Optional[bool] = True,
    ):
        super().__init__(span_in_symbols, upsampling_factor, None, normalize)

        num_taps = self.span_in_symbols * self.upsampling_factor
        if num_taps % 2 == 0:
            num_taps += 1
        self.num_taps = num_taps
        self.weights = self._generate_weights()
        if normalize:
            self._normalize_weights()

    def _generate_weights(self) -> np.ndarray:
        """
        Generate the weights for the sinc filter.

        :return: The filter coefficients.
        :rtype: np.ndarray
        """
        num_taps = self.num_taps
        t_symbol = self.upsampling_factor
        half = num_taps // 2
        n = np.arange(-half, half + 1)
        t_axis = n / t_symbol
        return np.sinc(t_axis)

    def __str__(self) -> str:
        """
        Return a string representation of the SincFilter object.

        :return: A string describing the SincFilter with its parameters.
        :rtype: str
        """
        return f"SincFilter(span_in_symbols={self.span_in_symbols}, " f"upsampling_factor={self.upsampling_factor})"
