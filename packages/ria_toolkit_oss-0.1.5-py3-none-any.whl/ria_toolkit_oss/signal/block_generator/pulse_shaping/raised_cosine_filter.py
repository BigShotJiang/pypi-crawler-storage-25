from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.pulse_shaping.pulse_shaping_filter import (
    PulseShapingFilter,
)


class RaisedCosineFilter(PulseShapingFilter):
    r"""
    Raised Cosine Filter Block

    Applies a raised cosine filter to an upsampled signal.

    Input Type: UPSAMPLED_SYMBOLS

    Output Type: BASEBAND_SIGNAL

    The raised cosine filter is defined by the following equation:

    .. math::
        h(t) =
        \begin{cases}
        \frac{\pi}{4T} \text{sinc}\left(\frac{1}{2\beta}\right), & \text { if }t = \pm \frac{T}{2\beta}\\
        \frac{1}{T}\text{sinc}\left(\frac{t}{T}\right)\
        \frac{\cos\left(\frac{\pi\beta t}{T}\right)}{1-\left(\frac{2\beta t}{T}\right)^2}, & \text{otherwise}
        \end{cases}

    where :math:`\beta` is the roll-off factor and :math:`T` the symbol duration.

    :param span_in_symbols: The span of the filter in terms of symbols.
    :type span_in_symbols: int
    :param upsampling_factor: The number of samples per symbol.
    :type upsampling_factor: int
    :param beta: The roll-off factor of the raised cosine filter. Must be between 0 and 1.
    :type beta: float
    :param normalize: Whether to normalize the filter coefficients, defaults to True.
    :type normalize: bool, optional
    """

    def __init__(
        self,
        span_in_symbols: Optional[int] = 100,
        upsampling_factor: Optional[int] = 4,
        beta: Optional[float] = 0.1,
        normalize: Optional[bool] = True,
    ):
        super().__init__(span_in_symbols, upsampling_factor, None, normalize)
        assert 0 < beta <= 1, "Beta must be between 0 and 1"
        self.beta = beta

        num_taps = self.span_in_symbols * self.upsampling_factor
        if num_taps % 2 == 0:
            num_taps += 1
        self.num_taps = num_taps
        self.weights = self._generate_weights()
        if normalize:
            self._normalize_weights()

    def _generate_weights(self) -> np.ndarray:
        """
        Generate the weights for the raised cosine filter.

        :return: The filter coefficients.
        :rtype: np.ndarray
        """
        num_taps = self.num_taps
        half = num_taps // 2
        t_axis = np.arange(-half, half + 1)
        return self._raised_cosine(t_axis)

    def _raised_cosine(self, t: np.ndarray) -> np.ndarray:
        """
        Calculate the raised cosine filter coefficients for a given time axis.

        This method implements the raised cosine filter equation, including
        handling the limit case where t = ±T/(2β).

        :param t: The time axis.
        :type t: np.ndarray

        :return: The raised cosine filter coefficients.
        :rtype: np.ndarray
        """
        t_symbol = self.upsampling_factor
        beta = self.beta
        with np.errstate(divide="ignore", invalid="ignore"):
            f_val = (
                1
                / t_symbol
                * np.sinc(t / t_symbol)
                * np.cos(np.pi * beta * t / t_symbol)
                / (1 - (2 * beta * t / t_symbol) ** 2)
            )
        idx_limit_case = np.where(np.abs(np.abs(t) - (t_symbol / (2 * beta))) < 1e-6)[0]
        if idx_limit_case.size > 0:
            f_val[idx_limit_case] = np.pi / (4 * t_symbol) * np.sinc(1 / (2 * beta))
        return f_val

    def __str__(self) -> str:
        """
        Return a string representation of the RaisedCosineFilter object.

        :returns: A string containing the class name and its main parameters.
        :rtype: str
        """
        return (
            f"RaisedCosineFilter(span_in_symbols={self.span_in_symbols}, "
            f"upsampling_factor={self.upsampling_factor}, beta={self.beta})"
        )
