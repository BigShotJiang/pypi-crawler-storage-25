from typing import Optional

import numpy as np

from ria_toolkit_oss.signal.block_generator.pulse_shaping.pulse_shaping_filter import (
    PulseShapingFilter,
)


class RootRaisedCosineFilter(PulseShapingFilter):
    r"""
    Root Raised Cosine Filter Block

    Applies a root raised cosine filter to an upsampled signal.

    Input Type: UPSAMPLED_SYMBOLS

    Output Type: BASEBAND_SIGNAL

    The root-raised cosine filter is defined by the following equation:

    .. math::
        h(t) =
        \begin{cases}
        \frac{1}{T} \left(1 + \beta\left(\frac{4}{\pi}-1\right) \right), & \text{if } t = 0 \\
        \frac{\beta}{T\sqrt{2}} \left[ \left(1+\frac{2}{\pi}\right)\sin\left(\frac{\pi}{4\beta}\right) +
        \left(1-\frac{2}{\pi}\right)\cos\left(\frac{\pi}{4\beta}\right) \right], & \text{if } t = \pm\frac{T}{4\beta}\\
        \frac{1}{T} \frac{\sin\left(\pi\frac{t}{T}(1-\beta)\right) + 4\beta\frac{t}{T}\cos\left(\pi\frac{t}{T}
        (1+\beta)\right)}{\pi\frac{t}{T}\left(1-\left(4\beta\frac{t}{T}\right)^2\right)}, & \text{otherwise}
        \end{cases}

    where :math:`\beta` is the roll-off factor and :math:`T` the symbol duration.

    :param span_in_symbols: The span of the filter in terms of symbols.
    :type span_in_symbols: int
    :param upsampling_factor: The number of samples per symbol.
    :type upsampling_factor: int
    :param beta: The roll-off factor of the raised cosine filter. Must be between 0 and 1.
    :type beta: float
    :param normalize: Whether to normalize the filter coefficients, defaults to True.
    :type normalize: bool, optional
    """

    def __init__(
        self,
        span_in_symbols: Optional[int] = 100,
        upsampling_factor: Optional[int] = 4,
        beta: Optional[float] = 0.1,
        normalize: Optional[bool] = True,
    ):
        super().__init__(span_in_symbols, upsampling_factor, None, normalize)
        assert 0 < beta <= 1, "Beta must be between 0 and 1"
        self.beta = beta

        num_taps = self.span_in_symbols * self.upsampling_factor
        if num_taps % 2 == 0:
            num_taps += 1
        self.num_taps = num_taps
        self.weights = self._generate_weights()
        if normalize:
            self._normalize_weights()

    def _generate_weights(self) -> np.ndarray:
        """
        Generate the weights for the root raised cosine filter.

        :return: The filter coefficients.
        :rtype: np.ndarray
        """
        num_taps = self.num_taps
        half = num_taps // 2
        t_axis = np.arange(-half, half + 1)
        return self._root_raised_cosine(t_axis)

    def _root_raised_cosine(self, t: np.ndarray) -> np.ndarray:
        """
        Calculate the root raised cosine filter coefficients for a given time axis.

        :param t: The time axis.
        :type t: np.ndarray
        :return: The root raised cosine filter coefficients.
        :rtype: np.ndarray
        """
        beta = self.beta
        t_symbol = self.upsampling_factor
        alpha = 4 * beta * t / t_symbol

        t[t == 0] = 1e9
        with np.errstate(divide="ignore", invalid="ignore"):
            f_val = (np.sin(np.pi * t / t_symbol * (1 - beta)) + alpha * np.cos(np.pi * t / t_symbol * (1 + beta))) / (
                np.pi * t * (1 - alpha**2)
            )
            f_val[t == 1e9] = (1 + beta * (4 / np.pi - 1)) / t_symbol

        idx_limit_case = np.where(np.abs(np.abs(t) - (t_symbol / (4 * beta))) < 1e-6)[0]
        if idx_limit_case.size > 0:
            f_val[idx_limit_case] = (beta / t_symbol / np.sqrt(2)) * (
                (1 + 2 / np.pi) * np.sin(np.pi / 4 / beta) + (1 - 2 / np.pi) * np.cos(np.pi / 4 / beta)
            )
        return f_val

    def __str__(self) -> str:
        """
        Return a string representation of the RootRaisedCosineFilter object.

        :return: A string describing the filter's parameters.
        :rtype: str
        """
        return (
            f"RootRaisedCosineFilter(span_in_symbols={self.span_in_symbols}, "
            f"upsampling_factor={self.upsampling_factor}, beta={self.beta})"
        )
