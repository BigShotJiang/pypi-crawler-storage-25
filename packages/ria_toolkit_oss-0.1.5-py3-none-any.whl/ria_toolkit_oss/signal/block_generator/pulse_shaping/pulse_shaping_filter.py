import os
from datetime import datetime
from typing import List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import scipy.signal as ss

from ria_toolkit_oss.signal.block_generator.data_types import DataType
from ria_toolkit_oss.signal.block_generator.process_block import ProcessBlock
from ria_toolkit_oss.signal.block_generator.recordable_block import RecordableBlock


class PulseShapingFilter(ProcessBlock, RecordableBlock):
    """
    Pulse Shaping Block

    Applies a pulse shaping filter to an upsampled signal.

    Input Type: UPSAMPLED_SYMBOLS

    Output Type: BASEBAND_SIGNAL

    :param span_in_symbols: The span of the filter in terms of symbols.
    :type span_in_symbols: int
    :param upsampling_factor: Number of samples per symbol.
    :type upsampling_factor: int
    :param weights: The filter coefficients, defaults to None.
    :type weights: np.ndarray | None
    :param normalize: Whether to normalize the filter coefficients, defaults to True.
    :type normalize: bool, optional
    """

    def __init__(
        self,
        span_in_symbols: Optional[int] = 100,
        upsampling_factor: Optional[int] = 4,
        weights: Optional[np.ndarray] = None,
        normalize: Optional[bool] = True,
    ):
        self.span_in_symbols = span_in_symbols
        self.upsampling_factor = upsampling_factor
        self.weights: Optional[np.ndarray] = weights
        self.num_taps: Optional[int] = len(self.weights) if self.weights is not None else None
        if normalize:
            self._normalize_weights()

        super().__init__()

    @property
    def input_type(self) -> DataType:
        """
        Get the input data type for the filter.

        :return: The input data type.
        :rtype: DataType
        """
        return [DataType.UPSAMPLED_SYMBOLS]

    @property
    def output_type(self) -> DataType:
        """
        Get the output data type for the filter.

        :return: The output data type.
        :rtype: DataType
        """
        return DataType.BASEBAND_SIGNAL

    def __str__(self) -> str:
        """
        Return a string representation of the PulseShapingFilter.

        :return: A string describing the filter's parameters.
        :rtype: str
        """
        return f"CustomFilter(span_in_symbols={self.span_in_symbols}, " f"upsampling_factor={self.upsampling_factor})"

    def _normalize_weights(self) -> None:
        """
        Normalize the filter weights so that their energy sums to 1.
        """
        if self.weights is not None:
            self.weights /= np.sqrt(np.sum(np.abs(self.weights) ** 2))

    def _pad_signals(self, signal: np.ndarray, padding_axis: int = -1) -> Tuple[np.ndarray, np.ndarray]:
        """
        Pad the upsampled signal and weights to the maximum length.

        :param signal: The signal to be padded.
        :type signal: np.ndarray
        :param padding_axis: The axis along which to perform the padding.
        :type padding_axis: int
        :return: The padded signal and weights as a tuple of numpy arrays.
        :rtype: tuple of np.ndarray
        """
        # Ensure weights are 1D array
        weights = self.weights
        # Determine the maximum length for padding
        max_len = max(weights.shape[0], signal.shape[1])

        # Pad the upsampled signal to the maximum length
        if signal.shape[1] < max_len:
            pad_width: List[Tuple[int, int]] = [(0, 0)] * signal.ndim
            pad_width[padding_axis] = (0, max_len - signal.shape[1])
            signal_padded = np.concatenate((signal, np.zeros(pad_width, dtype=signal.dtype)), axis=padding_axis)
        else:
            signal_padded = signal

        # Pad the weights if they are smaller than the signal
        if weights.shape[0] < max_len:
            weights_padded = np.concatenate((weights, np.zeros(max_len - weights.shape[0], weights.dtype)))
        else:
            weights_padded = weights
        weights_padded = np.tile(weights_padded.reshape((1, -1)), (signal_padded.shape[0], 1))
        return signal_padded, weights_padded

    def _trim_output(self, signal: np.ndarray, input_length: int) -> np.ndarray:
        """
        Trim the output signal to the expected length.

        :param signal: The filtered signal.
        :type signal: np.ndarray
        :param input_length: The length of the input signal.
        :type input_length: int
        :return: The trimmed signal.
        :rtype: np.ndarray
        """
        expected_length = input_length + self.num_taps - 1
        return signal[..., :expected_length]

    def __call__(self, samples):
        """
        Apply the filter to an upsampled signal using convolution and trim the output.

        :param samples: The signal to be filtered.
        :type samples: list of np.array, length = 1

        :return: The filtered and trimmed signal.
        :rtype: np.array
        """
        padding = "full"
        upsampled_signal = np.array([samples[0]])
        upsampled_signal_padded, weights_padded = self._pad_signals(upsampled_signal, 1)
        filtered_signal = ss.fftconvolve(upsampled_signal_padded, weights_padded, mode=padding, axes=-1)
        return self._trim_output(filtered_signal, upsampled_signal.shape[-1])[0, : len(samples[0])]

    def apply_matched_filter(
        self, upsampled_signal: np.ndarray, padding: str = "full", padding_axis: int = 0
    ) -> np.ndarray:
        """
        Apply the matched filter to an upsampled signal using convolution and trim the output.

        :param upsampled_signal: The signal to be filtered.
        :type upsampled_signal: np.ndarray
        :param padding: The type of padding to use, defaults to 'full'. Options are 'full', 'same', 'valid'.
        :type padding: str
        :param padding_axis: The axis along which to perform the padding, defaults to 0.
        :type padding_axis: int
        :return: The filtered and trimmed signal.
        :rtype: np.ndarray
        """
        upsampled_signal_padded, weights_padded = self._pad_signals(upsampled_signal, padding_axis)
        filtered_signal = ss.fftconvolve(upsampled_signal_padded, np.conj(weights_padded[::-1]), mode=padding, axes=-1)
        return self._trim_output(filtered_signal, upsampled_signal.shape[-1])

    def show(self) -> None:
        """
        Display the impulse response, phase response, and frequency response of the filter.
        """
        fft_size = 4096
        phase_response = np.angle(self.weights)
        freq_response = np.abs(np.fft.fftshift(np.fft.fft(self.weights, fft_size)))
        num_taps = self.num_taps

        fig, axs = plt.subplots(figsize=(10, 10), nrows=3, ncols=1)
        t_axis = np.linspace(-self.span_in_symbols // 2, self.span_in_symbols // 2, num_taps)
        f_axis = np.linspace(-fft_size // 2, fft_size // 2, fft_size)
        axs[0].plot(t_axis, self.weights, linewidth=3)
        axs[0].set_title("Impulse Response")
        axs[0].set_ylabel("Amplitude")
        axs[0].set_xlabel(r"Normalized time with respect to symbol duration $T_s$")

        axs[1].plot(t_axis, phase_response, linewidth=3)
        axs[1].set_title("Phase Response")
        axs[1].set_ylabel("Phase")
        axs[1].set_xlabel(r"Normalized time with respect to symbol duration $T_s$")

        axs[2].plot(f_axis, 10 * np.log10(freq_response), linewidth=3)
        axs[2].set_title("Frequency Response")
        axs[2].set_ylabel("Magnitude (dB)")
        axs[2].set_xlabel("Frequency bins")
        plt.tight_layout()
        # ToDo: this saving approach needs to change - not sure how yet :D
        os.makedirs("images", exist_ok=True)
        now = datetime.now()
        formatted_time = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"images/impulse_response_{formatted_time}.png"
        fig.savefig(file_name, dpi=800)
        plt.show()
