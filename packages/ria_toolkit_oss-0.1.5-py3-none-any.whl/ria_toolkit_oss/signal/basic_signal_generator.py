"""
.. todo:: Need to add some information here about signal generation and the signal generators in this module.
"""

import warnings
from typing import Optional

import numpy as np
import scipy.signal
from scipy.signal import butter
from scipy.signal import chirp as sci_chirp
from scipy.signal import hilbert, lfilter

from ria_toolkit_oss.datatypes.recording import Recording


def sine(
    sample_rate: Optional[int] = 1000,
    length: Optional[int] = 1000,
    frequency: Optional[float] = 1000,
    amplitude: Optional[float] = 1,
    baseband_phase: Optional[float] = 0,
    rf_phase: Optional[float] = 0,
    dc_offset: Optional[float] = 0,
) -> Recording:
    """Generate a basic sine wave signal.

    :param sample_rate: The number of samples per second (Hz). Defaults to 1,000.
    :type sample_rate: int, optional
    :param length: Number of samples in the recording. Defaults to 1,000.
    :type length: int, optional
    :param frequency: The frequency of the sine wave (Hz). Defaults to 1,000.
    :type frequency: float, optional
    :param amplitude: Amplitude of the sine wave. Defaults to 1.
    :type amplitude: float, optional
    :param baseband_phase: Phase offset in radians, relative to the sine wave frequency. Defaults to 0.
    :type baseband_phase: float, optional
    :param rf_phase: Phase offset in radians of the complex samples. Defaults to 0.
    :type rf_phase: float, optional
    :param dc_offset: DC offset (average of the sine wave). Defaults to 0.
    :type dc_offset: float, optional

    :return: A Recording object containing the generated sine wave signal.
    :rtype: Recording

    Examples:

    .. todo:: Usage examples coming soon!
    """

    if sample_rate < 1:
        raise ValueError("sample_rate must be > 1")

    total_time = length / sample_rate
    t = np.linspace(0, total_time, length, endpoint=False)
    sine_wave = amplitude * np.sin(2 * np.pi * frequency * t + baseband_phase) + dc_offset
    complex_sine_wave = sine_wave * np.exp(1j * rf_phase)

    metadata = {
        "signal": "sine",
        "source": "synth",
        "sample_rate": sample_rate,
        "length": length,
        "signal_frequency": frequency,
        "amplitude": amplitude,
        "baseband_phase": baseband_phase,
        "rf_phase": rf_phase,
        "dc_offset": dc_offset,
    }

    return Recording(data=complex_sine_wave, metadata=metadata)


def square(
    sample_rate: Optional[int] = 1000,
    length: Optional[int] = 1000,
    frequency: Optional[float] = 1,
    amplitude: Optional[float] = 1,
    duty_cycle: Optional[float] = 0.5,
    baseband_phase: Optional[float] = 0,
    rf_phase: Optional[float] = 0,
    dc_offset: Optional[float] = 0,
) -> Recording:
    """Generate a square wave signal.

    :param sample_rate: The number of samples per second (Hz). Defaults to 1,000.
    :type sample_rate: int, optional
    :param length: Number of samples in the recording. Defaults to 1,000.
    :type length: int, optional
    :param frequency: The frequency of the square wave (Hz). Defaults to 1.
    :type frequency: float, optional
    :param amplitude: The amplitude of the square wave. Defaults to 1.
    :type amplitude: float, optional
    :param duty_cycle: The duty cycle of the square wave as a decimal in the range [0, 1]. Defaults to 0.5.
    :param baseband_phase: Phase offset in radians, relative to the square wave frequency. Defaults to 0.
    :type baseband_phase: float, optional
    :param rf_phase: Phase offset in radians of the complex samples. Defaults to 0.
    :type rf_phase: float, optional
    :param dc_offset: DC offset. If dc_offset is 0 but duty_cycle is not 0.5, the actual dc offset may not be
    exactly 0. Defaults to 0.
    :type dc_offset: float, optional

    :return: A Recording object containing the generated square wave signal.
    :rtype: Recording

    Examples:

    .. todo:: Usage examples coming soon!
    """

    if sample_rate < 1:
        raise ValueError("sample_rate must be > 1")

    t = np.arange(length)
    square_wave = amplitude * scipy.signal.square(
        2 * np.pi * frequency * (t / sample_rate - (baseband_phase / (2 * np.pi))), duty=duty_cycle
    )
    square_wave = square_wave + dc_offset
    complex_square_wave = square_wave * np.exp(1j * rf_phase)

    metadata = {
        "signal": "square",
        "source": "synth",
        "sample_rate": sample_rate,
        "length": length,
        "signal_frequency": frequency,
        "amplitude": amplitude,
        "baseband_phase": baseband_phase,
        "duty_cycle": duty_cycle,
        "rf_phase": rf_phase,
        "dc_offset": dc_offset,
    }

    return Recording(data=complex_square_wave, metadata=metadata)


def sawtooth(
    sample_rate: Optional[int] = 1000,
    length: Optional[int] = 1000,
    frequency: Optional[float] = 1,
    amplitude: Optional[float] = 1,
    baseband_phase: Optional[float] = 0,
    rf_phase: Optional[float] = 0,
    dc_offset: Optional[float] = 0,
) -> Recording:
    """Generate a sawtooth wave signal.

    :param sample_rate: The number of samples per second (Hz). Defaults to 1,000.
    :type sample_rate: int, optional
    :param length: Number of samples in the recording. Defaults to 1,000.
    :type length: int, optional
    :param frequency: The frequency of the sawtooth wave (Hz). Defaults to 1.
    :type frequency: float, optional
    :param amplitude: Amplitude of the sawtooth wave. Defaults to 1.
    :type amplitude: float, optional
    :param baseband_phase: Phase offset in radians, relative to the wave frequency. Defaults to 0.
    :type baseband_phase: float, optional
    :param rf_phase: Phase offset in radians of the complex samples. Defaults to 0.
    :type rf_phase: float, optional
    :param dc_offset: DC offset (average of the wave). Defaults to 0.
    :type dc_offset: float, optional

    :return: A Recording object containing the generated sawtooth signal.
    :rtype: Recording

    Examples:

    .. todo:: Usage examples coming soon!
    """

    if sample_rate < 1:
        raise ValueError("sample_rate must be > 1")

    t = np.arange(length)

    saw_wave = amplitude * scipy.signal.sawtooth(
        2 * np.pi * frequency * (t / sample_rate - (baseband_phase / (2 * np.pi)))
    )
    saw_wave = saw_wave + dc_offset
    complex_sine_wave = saw_wave * np.exp(1j * rf_phase)

    metadata = {
        "signal": "sawtooth",
        "source": "synth",
        "sample_rate": sample_rate,
        "length": length,
        "signal_frequency": frequency,
        "amplitude": amplitude,
        "baseband_phase": baseband_phase,
        "rf_phase": rf_phase,
        "dc_offset": dc_offset,
    }

    return Recording(data=complex_sine_wave, metadata=metadata)


def noise(
    sample_rate: Optional[int] = 1000,
    length: Optional[int] = 1000,
    rms_power: Optional[float] = 0.2,
    dc_offset: Optional[float] = 0,
) -> Recording:
    """Generate a Gaussian white noise (GWN) wave signal.

    :param sample_rate: The number of samples per second (Hz). Defaults to 1,000.
    :type sample_rate: int, optional
    :param length: Number of samples in the recording. Defaults to 1,000.
    :type length: int, optional
    :param rms_power: Root-Mean-Square power of the generated signal. Defaults to 0.2.
    :type rms_power: float, optional
    :param dc_offset: DC offset (average of the wave). Defaults to 0.
    :type dc_offset: float, optional

    :return: A Recording object containing the generated noise signal.
    :rtype: Recording

    Examples:

    .. todo:: Usage examples coming soon!
    """

    if sample_rate < 1:
        raise ValueError("sample_rate must be > 1")

    variance = rms_power**2
    magnitude = np.random.normal(loc=0, scale=np.sqrt(variance), size=length)
    magnitude2 = np.clip(magnitude, -1, 1)

    # TODO figure out a better way to make it conform to [-1,1]
    if not np.array_equal(magnitude, magnitude2):
        warnings.warn("basic_signal_generator.noise: magnitude clipped to [-1, 1]")

    phase = np.random.uniform(low=0, high=2 * np.pi, size=length)
    complex_awgn = magnitude2 * np.exp(1j * phase)
    complex_awgn = complex_awgn + dc_offset
    metadata = {
        "signal": "awgn",
        "source": "synth",
        "sample_rate": sample_rate,
        "length": length,
        "amplitude": np.max(np.abs(complex_awgn)),
        "dc_offset": dc_offset,
    }

    return Recording(data=complex_awgn, metadata=metadata)


def chirp(sample_rate: int, num_samples: int, center_frequency: Optional[float] = 0) -> Recording:
    """Generator a sinusoidal waveform with a linear frequency sweep.

    Start and end frequencies are chosen based on the maximum frequency range that can be covered without aliasing,
    which is determined by the sample rate. To chirp over a larger frequency range, increase the sample rate.

    Chirps are often used in radar, sonar, and communication systems because they can effectively cover a wide
    frequency range and are useful for testing and measurement purposes.

    :param sample_rate: The number of samples per second (Hz).
    :type sample_rate: int
    :param num_samples: The number of samples in the chirp.
    :type num_samples: int
    :param center_frequency: The center frequency of the chirp.
    :type center_frequency: float, optional

    :return: A Recording object containing the generated noise signal.
    :rtype: Recording

    Examples:

    .. todo:: Usage examples coming soon!
    """
    # Ensure that the generated chirp signal remains within a safe frequency range to avoid aliasing.
    if num_samples < 2:
        raise ValueError("num_samples must be >= 2 for chirp generation")

    chirp_start_frequency = center_frequency - sample_rate / 4
    chirp_end_frequency = center_frequency + sample_rate / 4

    t = np.arange(num_samples) / int(sample_rate)

    f_t = chirp_start_frequency + (chirp_end_frequency - chirp_start_frequency) * t / t[-1]
    complex_samples = np.exp(2.0j * np.pi * f_t * t)

    metadata = {"sample_rate": sample_rate, "num_samples:": num_samples}

    return Recording(data=complex_samples, metadata=metadata)


def lfm_chirp_complex(
    sample_rate: int, width: int, chirp_period: float, sigfc: int | float, total_time: float, chirp_type: str
):
    """
    Generate a complex linearly frequency modulated chirp signal.

    :param sample_rate:
    """
    # Time vector for one chirp
    chirp_length = int(chirp_period * sample_rate)
    t_chirp = np.linspace(0, chirp_period, chirp_length)
    if len(t_chirp) > chirp_length:
        t_chirp = t_chirp[:chirp_length]
    # Generate one chirp from 0 Hz to the full width
    if chirp_type == "up":
        baseband_chirp = sci_chirp(t_chirp, f0=0, f1=width, t1=chirp_period, method="linear")
    elif chirp_type == "down":
        baseband_chirp = sci_chirp(t_chirp, f0=width, f1=0, t1=chirp_period, method="linear")
    elif chirp_type == "up_down":
        half_duration = chirp_period / 2
        t_up_half, t_down_half = np.array_split(t_chirp, 2)

        up_part = sci_chirp(t_up_half, f0=0, t1=half_duration, f1=width, method="linear")
        down_part = np.flip(up_part)
        baseband_chirp = np.concatenate([up_part, down_part])

    else:
        raise ValueError(f"Unknown chirp_type '{chirp_type}'. Must be 'up', 'down', or 'up_down'.")

    # Generate the full signal by tiling the windowed chirp
    num_chirps = round(total_time / chirp_period)
    full_signal = np.tile(baseband_chirp, num_chirps)
    # Create an analytic signal (complex with no negative frequency components)
    analytic_signal = hilbert(full_signal)
    # Shift the chirp to the signal center frequency
    t_full = np.linspace(0, total_time, len(analytic_signal))
    complex_chirp = analytic_signal * np.exp(1j * 2 * np.pi * (sigfc - width / 2) * t_full)

    nyquist = 0.5 * sample_rate  # Nyquist frequency
    normal_cutoff = width / nyquist  # Normalize cutoff
    b, a = butter(8, normal_cutoff, btype="low", analog=False)
    filtered_chirp = lfilter(b, a, complex_chirp)

    metadata = {
        "source": "basic_signal_generator",
        "sample_rate": sample_rate,
        "width": width,
        "chirp_period": chirp_period,
        "chirp_center_frequency": sigfc,
        "total_time": total_time,
        "filter": "low_pass",
    }

    return Recording(data=filtered_chirp, metadata=metadata)


def complex_sine(sample_rate, length, frequency):
    """
    Generates a complex sine wave.

    :param sample_rate: The number of samples per second (Hz). Defaults to 1,000.
    :type sample_rate: int, optional
    :param length: Number of samples in the recording. Defaults to 1,000.
    :type length: int, optional
    :param frequency: The frequency of the square wave (Hz). Defaults to 1.
    :type frequency: float, optional
    """

    if sample_rate < 1:
        raise ValueError("sample_rate must be > 1")

    total_time = length / sample_rate
    t = np.linspace(0, total_time, length, endpoint=False)
    power_factor = np.random.uniform(-8, 0)
    complex_sine_wave = (10**power_factor) * np.exp(1j * 2 * np.pi * frequency * t)

    metadata = {
        "signal": "complex_sine",
        "source": "synth",
        "sample_rate": sample_rate,
        "length": length,
        "signal_frequency": frequency,
        "power_factor": power_factor,
    }

    return Recording(data=complex_sine_wave, metadata=metadata)


def birdie(sample_rate, length, frequency):
    """
    Generates a complex sine wave for birdies in demos.

    :param sample_rate: The number of samples per second (Hz). Defaults to 1,000.
    :type sample_rate: int, optional
    :param length: Number of samples in the recording. Defaults to 1,000.
    :type length: int, optional
    :param frequency: The frequency of the square wave (Hz). Defaults to 1.
    :type frequency: float, optional
    """

    if sample_rate < 1:
        raise ValueError("sample_rate must be > 1")

    total_time = length / sample_rate
    t = np.linspace(0, total_time, length, endpoint=False)
    power_factor = np.random.uniform(-2.5, -0.5)
    complex_sine_wave = (10**power_factor) * np.exp(1j * 2 * np.pi * frequency * t)

    metadata = {
        "signal": "complex_sine",
        "source": "synth",
        "sample_rate": sample_rate,
        "length": length,
        "signal_frequency": frequency,
        "power_factor": power_factor,
    }

    return Recording(data=complex_sine_wave, metadata=metadata)
