from abc import ABC, abstractmethod

from ria_toolkit_oss.datatypes import Recording


class Recordable(ABC):
    """Base class for all recordables, including SDRs and synthetic signal generators, that produce ``Recording``
    objects.
    """

    @abstractmethod
    def record(self, *args, **kwargs) -> Recording:
        """Generate Recording object.

        :rtype: Recording
        """
        pass
