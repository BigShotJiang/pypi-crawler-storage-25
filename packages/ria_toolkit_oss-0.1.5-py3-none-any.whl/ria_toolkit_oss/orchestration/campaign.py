"""Campaign configuration schema and YAML parser for orchestrated RF captures."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml

# Allowed characters in campaign names when used as filename components.
_SAFE_NAME_RE = re.compile(r"[^a-zA-Z0-9_\-]")

# Reasonable RF bounds for consumer/research SDR hardware.
_FREQ_MIN_HZ = 1.0  # 1 Hz
_FREQ_MAX_HZ = 300e9  # 300 GHz
_GAIN_MIN_DB = -30.0
_GAIN_MAX_DB = 120.0

# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------


def parse_duration(value: str | float | int) -> float:
    """Parse a duration string to seconds.

    Accepts:
        "30s" → 30.0
        "1.5m" or "1.5min" → 90.0
        "2h" → 7200.0
        30 (numeric) → 30.0
    """
    if isinstance(value, (int, float)):
        return float(value)
    value = str(value).strip()
    match = re.fullmatch(r"([\d.]+)\s*(s|sec|m|min|h|hr)?", value, re.IGNORECASE)
    if not match:
        raise ValueError(f"Cannot parse duration: '{value}'")
    amount = float(match.group(1))
    unit = (match.group(2) or "s").lower()
    if unit in ("h", "hr"):
        return amount * 3600
    if unit in ("m", "min"):
        return amount * 60
    return amount


def parse_frequency(value: str | float | int) -> float:
    """Parse a frequency string to Hz.

    Accepts:
        "2.45GHz" → 2_450_000_000.0
        "40MHz" → 40_000_000.0
        "915e6" → 915_000_000.0
        2.45e9 (numeric) → 2_450_000_000.0
    """
    if isinstance(value, (int, float)):
        result = float(value)
        if not (_FREQ_MIN_HZ <= result <= _FREQ_MAX_HZ):
            raise ValueError(
                f"Frequency {result:.3g} Hz is outside the supported range "
                f"({_FREQ_MIN_HZ:.0f} Hz – {_FREQ_MAX_HZ:.3g} Hz)"
            )
        return result
    value = str(value).strip()

    # Try bare numeric first (handles scientific notation like "915e6")
    try:
        result = float(value)
    except ValueError:
        pass
    else:
        if not (_FREQ_MIN_HZ <= result <= _FREQ_MAX_HZ):
            raise ValueError(
                f"Frequency {result:.3g} Hz is outside the supported range "
                f"({_FREQ_MIN_HZ:.0f} Hz – {_FREQ_MAX_HZ:.3g} Hz): '{value}'"
            )
        return result

    # Handle suffix notation: "2.45GHz", "40MHz", "40M", "433k"
    match = re.fullmatch(r"([\d.]+)\s*(k|M|G)(?:\s*Hz?)?", value, re.IGNORECASE)
    if match:
        amount = float(match.group(1))
        suffix = match.group(2).upper()
        result = amount * {"K": 1e3, "M": 1e6, "G": 1e9}[suffix]
        if not (_FREQ_MIN_HZ <= result <= _FREQ_MAX_HZ):
            raise ValueError(
                f"Frequency {result:.3g} Hz is outside the supported range "
                f"({_FREQ_MIN_HZ:.0f} Hz – {_FREQ_MAX_HZ:.3g} Hz): '{value}'"
            )
        return result

    raise ValueError(f"Cannot parse frequency: '{value}'")


def parse_gain(value: str | float | int) -> float | str:
    """Parse a gain string.

    Accepts:
        "40dB" or "40 dB" → 40.0
        "auto" → "auto"
        40 (numeric) → 40.0
    """
    if isinstance(value, (int, float)):
        result = float(value)
        if not (_GAIN_MIN_DB <= result <= _GAIN_MAX_DB):
            raise ValueError(f"Gain {result} dB is outside the supported range ({_GAIN_MIN_DB} – {_GAIN_MAX_DB} dB)")
        return result
    value = str(value).strip()
    if value.lower() == "auto":
        return "auto"
    match = re.fullmatch(r"([\d.+\-]+)\s*dB?", value, re.IGNORECASE)
    if not match:
        raise ValueError(f"Cannot parse gain: '{value}'")
    result = float(match.group(1))
    if not (_GAIN_MIN_DB <= result <= _GAIN_MAX_DB):
        raise ValueError(
            f"Gain {result} dB is outside the supported range ({_GAIN_MIN_DB} – {_GAIN_MAX_DB} dB): '{value}'"
        )
    return result


def parse_bandwidth_mhz(value: str | float | int | None) -> Optional[float]:
    """Parse a bandwidth string to MHz.

    Accepts:
        "20MHz" → 20.0
        "40MHz" → 40.0
        20 (numeric, assumed MHz) → 20.0
        None → None
    """
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    value = str(value).strip()
    match = re.fullmatch(r"([\d.]+)\s*MHz?", value, re.IGNORECASE)
    if match:
        return float(match.group(1))
    match = re.fullmatch(r"([\d.]+)", value)
    if match:
        return float(match.group(1))
    raise ValueError(f"Cannot parse bandwidth: '{value}'")


# ---------------------------------------------------------------------------
# Config dataclasses
# ---------------------------------------------------------------------------


@dataclass
class RecorderConfig:
    """SDR recorder configuration."""

    device: str
    center_freq: float  # Hz
    sample_rate: float  # Hz
    gain: float | str  # dB float, or "auto"
    bandwidth: Optional[float] = None  # Hz, None = match sample_rate

    @classmethod
    def from_dict(cls, d: dict) -> "RecorderConfig":
        gain = parse_gain(d.get("gain", "auto"))
        bandwidth_raw = d.get("bandwidth") or d.get("bandwidth_hz")
        bandwidth = parse_frequency(bandwidth_raw) if bandwidth_raw else None
        return cls(
            device=str(d["device"]),
            center_freq=parse_frequency(d["center_freq"]),
            sample_rate=parse_frequency(d["sample_rate"]),
            gain=gain,
            bandwidth=bandwidth,
        )


@dataclass
class CaptureStep:
    """A single timed capture within a transmitter schedule."""

    duration: float  # seconds
    label: str  # used as filename component

    # WiFi-specific
    channel: Optional[int] = None
    bandwidth_mhz: Optional[float] = None  # MHz
    traffic: Optional[str] = None

    # Bluetooth-specific
    connection_interval_ms: Optional[float] = None

    # Power (dBm), optional
    power_dbm: Optional[float] = None

    @classmethod
    def from_dict(cls, d: dict, auto_label: bool = True) -> "CaptureStep":
        duration = parse_duration(d["duration"])
        label = d.get("label", "")
        if not label and auto_label:
            parts = []
            if d.get("channel"):
                parts.append(f"ch{d['channel']:02d}")
            if d.get("bandwidth"):
                bw = parse_bandwidth_mhz(d["bandwidth"])
                parts.append(f"{int(bw)}mhz")
            if d.get("traffic"):
                parts.append(str(d["traffic"]).replace(" ", "_"))
            label = "_".join(parts) if parts else "capture"
        return cls(
            duration=duration,
            label=label,
            channel=d.get("channel"),
            bandwidth_mhz=parse_bandwidth_mhz(d.get("bandwidth")),
            traffic=d.get("traffic"),
            connection_interval_ms=d.get("connection_interval_ms"),
            power_dbm=float(d["power"].removesuffix("dBm").strip()) if d.get("power") else None,
        )


@dataclass
class TransmitterConfig:
    """Configuration for a single transmitter device in the campaign."""

    id: str
    type: str  # "wifi", "bluetooth", "sdr", "external"
    control_method: str  # "external_script" | "sdr" | "sdr_remote"
    schedule: list[CaptureStep]

    # For external_script control
    script: Optional[str] = None  # path to control script
    device: Optional[str] = None  # e.g. "/dev/wlan0"

    # For sdr_remote control — keys: host, ssh_user, ssh_key_path, device_type, device_id, zmq_port
    sdr_remote: Optional[dict] = None

    @classmethod
    def from_dict(cls, d: dict) -> "TransmitterConfig":
        schedule = [CaptureStep.from_dict(s) for s in d.get("schedule", [])]
        return cls(
            id=str(d["id"]),
            type=str(d["type"]),
            control_method=str(d.get("control_method", "external_script")),
            schedule=schedule,
            script=d.get("script"),
            device=d.get("device"),
            sdr_remote=d.get("sdr_remote"),
        )


@dataclass
class QAConfig:
    """Quality assurance thresholds."""

    snr_threshold_db: float = 10.0
    min_duration_s: float = 25.0
    flag_for_review: bool = True

    @classmethod
    def from_dict(cls, d: dict) -> "QAConfig":
        return cls(
            snr_threshold_db=float(str(d.get("snr_threshold", "10")).rstrip("dB").strip()),
            min_duration_s=parse_duration(d.get("min_duration", "25s")),
            flag_for_review=bool(d.get("flag_for_review", True)),
        )


@dataclass
class OutputConfig:
    """Where to save captured recordings."""

    format: str = "sigmf"
    path: str = "recordings"
    device_id: Optional[str] = None  # for device-profile campaigns
    repo: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "OutputConfig":
        return cls(
            format=str(d.get("format", "sigmf")),
            path=str(d.get("path", "recordings")),
            device_id=d.get("device_id"),
            repo=d.get("repo"),
        )


@dataclass
class CampaignConfig:
    """Full campaign configuration parsed from YAML."""

    name: str
    recorder: RecorderConfig
    transmitters: list[TransmitterConfig]
    qa: QAConfig = field(default_factory=QAConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    mode: str = "controlled_testbed"

    # ---------------------------------------------------------------------------
    # Loaders
    # ---------------------------------------------------------------------------

    @classmethod
    def from_dict(cls, raw: dict) -> "CampaignConfig":
        """Build a CampaignConfig from a parsed dictionary.

        Accepts the same structure as the campaign YAML, already loaded into
        a Python dict (e.g. from a JSON HTTP request body).

        Raises:
            ValueError: If required fields are missing or malformed.
            KeyError: If ``recorder`` key is absent.
        """
        campaign_meta = raw.get("campaign", {})
        transmitters = [TransmitterConfig.from_dict(t) for t in raw.get("transmitters", [])]
        if not transmitters:
            raise ValueError("Campaign config must define at least one transmitter")
        if "recorder" not in raw:
            raise ValueError("Campaign config is missing required 'recorder' section")
        raw_name = str(campaign_meta.get("name", "unnamed"))
        safe_name = _SAFE_NAME_RE.sub("_", raw_name)
        return cls(
            name=safe_name,
            mode=str(campaign_meta.get("mode", "controlled_testbed")),
            recorder=RecorderConfig.from_dict(raw["recorder"]),
            transmitters=transmitters,
            qa=QAConfig.from_dict(raw.get("qa", {})),
            output=OutputConfig.from_dict(raw.get("output", {})),
        )

    @classmethod
    def from_yaml(cls, path: str | Path) -> "CampaignConfig":
        """Load a full campaign config YAML.

        Expected format::

            campaign:
              name: "wifi_capture_001"
              mode: "controlled_testbed"

            transmitters:
              - id: "laptop_wifi"
                type: "wifi"
                control_method: "external_script"
                script: "./scripts/wifi_control.sh"
                device: "/dev/wlan0"
                schedule:
                  - channel: 6
                    bandwidth: "20MHz"
                    traffic: "iperf_udp"
                    duration: "30s"

            recorder:
              device: "usrp_b210"
              center_freq: "2.45GHz"
              sample_rate: "40MHz"
              gain: "40dB"

            qa:
              snr_threshold: "10dB"
              min_duration: "25s"
              flag_for_review: true

            output:
              format: "sigmf"
              path: "./recordings"
        """
        path = Path(path)
        try:
            with open(path) as f:
                raw = yaml.safe_load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Campaign config not found: {path}")
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in {path}: {e}")

        campaign_meta = raw.get("campaign", {})
        transmitters = [TransmitterConfig.from_dict(t) for t in raw.get("transmitters", [])]
        if not transmitters:
            raise ValueError("Campaign config must define at least one transmitter")
        if "recorder" not in raw:
            raise ValueError(f"Campaign config is missing required 'recorder' section in {path}")
        raw_name = str(campaign_meta.get("name", path.stem))
        safe_name = _SAFE_NAME_RE.sub("_", raw_name)

        return cls(
            name=safe_name,
            mode=str(campaign_meta.get("mode", "controlled_testbed")),
            recorder=RecorderConfig.from_dict(raw["recorder"]),
            transmitters=transmitters,
            qa=QAConfig.from_dict(raw.get("qa", {})),
            output=OutputConfig.from_dict(raw.get("output", {})),
        )

    @classmethod
    def from_device_profile(cls, path: str | Path) -> "CampaignConfig":
        """Build a campaign config from an App 1 device profile YAML.

        Expected format::

            device:
              name: "iPhone_13_WiFi"
              type: "wifi"
              protocol: "wifi_24ghz"

            capture:
              channels: [1, 6, 11]          # WiFi only
              bandwidth: "20MHz"            # WiFi only
              traffic_patterns: ["idle", "ping", "iperf_udp"]
              duration_per_config: "30s"

            recorder:
              device: "usrp_b210"
              center_freq: "2.45GHz"
              sample_rate: "40MHz"
              gain: "auto"

            output:
              path: "./recordings"
              device_id: "iphone13_wifi_001"

        For WiFi devices, schedule is expanded as channels × traffic_patterns.
        For Bluetooth devices (no channels), schedule is traffic_patterns only.
        """
        path = Path(path)
        try:
            with open(path) as f:
                raw = yaml.safe_load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Device profile not found: {path}")
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in {path}: {e}")

        device = raw.get("device", {})
        capture = raw.get("capture", {})
        device_type = str(device.get("type", "wifi")).lower()
        device_name = str(device.get("name", path.stem))
        duration = parse_duration(capture.get("duration_per_config", "30s"))
        traffic_patterns = capture.get("traffic_patterns", ["idle"])

        # Build capture schedule
        schedule: list[CaptureStep] = []

        if device_type in ("wifi", "wifi_24ghz", "wifi_5ghz"):
            channels = capture.get("channels", [6])
            bw_str = capture.get("bandwidth", "20MHz")
            bw_mhz = parse_bandwidth_mhz(bw_str)
            for ch in channels:
                for traffic in traffic_patterns:
                    label = f"ch{ch:02d}_{int(bw_mhz)}mhz_{traffic}"
                    schedule.append(
                        CaptureStep(
                            duration=duration,
                            label=label,
                            channel=ch,
                            bandwidth_mhz=bw_mhz,
                            traffic=traffic,
                        )
                    )
        else:
            # Bluetooth / generic — no channels
            for traffic in traffic_patterns:
                schedule.append(
                    CaptureStep(
                        duration=duration,
                        label=traffic,
                        traffic=traffic,
                    )
                )

        device_id = raw.get("output", {}).get("device_id", device_name.lower().replace(" ", "_"))
        transmitter = TransmitterConfig(
            id=device_id,
            type=device_type,
            control_method=str(capture.get("control_method", "external_script")),
            schedule=schedule,
            script=capture.get("script"),
            device=capture.get("device"),
        )

        return cls(
            name=f"enroll_{device_id}",
            mode="controlled_testbed",
            recorder=RecorderConfig.from_dict(raw["recorder"]),
            transmitters=[transmitter],
            qa=QAConfig.from_dict(raw.get("qa", {})),
            output=OutputConfig.from_dict(raw.get("output", {})),
        )

    def total_capture_time_s(self) -> float:
        """Sum of all step durations across all transmitters."""
        return sum(step.duration for tx in self.transmitters for step in tx.schedule)

    def total_steps(self) -> int:
        """Total number of capture steps across all transmitters."""
        return sum(len(tx.schedule) for tx in self.transmitters)
