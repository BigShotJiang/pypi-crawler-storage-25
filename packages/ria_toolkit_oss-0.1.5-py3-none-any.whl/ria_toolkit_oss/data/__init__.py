"""
The Data package contains abstract data types tailored for radio machine learning, such as ``Recording``, as well
as the abstract interfaces for the radio dataset and radio dataset builder framework.
"""

__all__ = ["Annotation", "Recording"]
from .annotation import Annotation
from .recording import Recording
