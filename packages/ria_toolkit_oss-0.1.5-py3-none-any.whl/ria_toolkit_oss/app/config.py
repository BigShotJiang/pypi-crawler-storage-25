"""App runner configuration at ``~/.ria/toolkit.json``.

Schema::

    {
        "registry": "registry.riahub.ai",
        "namespace": "qoherent"
    }
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path

_DEFAULT_PATH = Path(os.environ.get("RIA_TOOLKIT_CONFIG", str(Path.home() / ".ria" / "toolkit.json")))


@dataclass
class AppConfig:
    registry: str = ""
    namespace: str = ""
    sudo: bool = False


def default_path() -> Path:
    return _DEFAULT_PATH


def load(path: Path | None = None) -> AppConfig:
    p = path or _DEFAULT_PATH
    if not p.exists():
        return AppConfig(
            registry=os.environ.get("RIA_REGISTRY", ""),
            namespace=os.environ.get("RIA_NAMESPACE", ""),
        )
    data = json.loads(p.read_text())
    return AppConfig(
        registry=data.get("registry", "") or os.environ.get("RIA_REGISTRY", ""),
        namespace=data.get("namespace", "") or os.environ.get("RIA_NAMESPACE", ""),
        sudo=bool(data.get("sudo", False)) or os.environ.get("RIA_DOCKER_SUDO", "") not in ("", "0", "false"),
    )


def save(cfg: AppConfig, path: Path | None = None) -> Path:
    p = path or _DEFAULT_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(asdict(cfg), indent=2))
    return p
