"""App runner: pull and run containerized RIA applications."""
