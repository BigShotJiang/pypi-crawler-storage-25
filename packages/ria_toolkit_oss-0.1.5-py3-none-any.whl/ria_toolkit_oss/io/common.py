"""
Utilities for common input/output operations.
"""

import os

import ria_toolkit_oss


def exists(fid: str | os.PathLike) -> bool:
    """Check if the file or directory exists.

    .. todo::

       This method is not yet implemented.

    :param fid: The path to the file or directory to check for existence.
    :type fid: str or os.PathLike

    :return: True if the file or directory exists, False otherwise.
    :rtype: bool
    """
    raise NotImplementedError


def validate(fid: str | os.PathLike) -> bool:
    """Validate the contents of the file or directory to ensure it is not corrupted,
    the correct format for its extension, and readable RIA.

    .. todo::

       This method is not yet implemented.

    :param fid: The path to the file or directory to validate.
    :type fid: str or os.PathLike

    :return: True if the file or directory is valid and readable, False otherwise.
    """
    raise NotImplementedError


def move(source_path: str | os.PathLike, destination_path: str | os.PathLike, copy: bool = False) -> None:
    """Recursively move a file or directory at source_path to destination_path.

    .. todo::

       This method is not yet implemented.

    :param source_path: The path to the source file or directory.
    :type source_path: str or os.PathLike
    :param destination_path: The path to the destination directory.
    :type destination_path: str or os.PathLike
    :param copy: If True, perform a copy instead of a move. Default is False.
    :type copy: bool, optional

    :raises RuntimeError: If the move was unsuccessful.

    :return: None
    """
    if copy:
        ria_toolkit_oss.io.common.copy(source_path=source_path, destination_path=destination_path)
        return

    raise NotImplementedError


def copy(source_path: str | os.PathLike, destination_path: str | os.PathLike) -> None:
    """Copy the file or directory at source_path to destination_path.

    .. todo::

       This function is not yet implemented.

    :param source_path: The path to the source file or directory.
    :type source_path: str or os.PathLike
    :param destination_path: The path to the destination directory.
    :type destination_path: str or os.PathLike

    :raises RuntimeError: If the copy was unsuccessful.

    :return: None
    """
    raise NotImplementedError
