"""Remote SDR transmitter control via SSH + ZMQ."""

from .remote_transmitter import RemoteTransmitter
from .remote_transmitter_controller import RemoteTransmitterController

__all__ = ["RemoteTransmitter", "RemoteTransmitterController"]
