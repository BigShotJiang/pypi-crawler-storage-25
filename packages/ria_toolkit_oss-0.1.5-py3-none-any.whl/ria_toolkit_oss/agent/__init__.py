"""RIA Toolkit agent package.

Provides two execution modes:

- **Legacy long-poll executor** (`NodeAgent` in :mod:`legacy_executor`) — an
  HTTP long-polling agent that runs ONNX inference locally on the host.
- **Streamer** (:mod:`streamer`) — a thin WebSocket client that opens an SDR
  and streams raw IQ to the RIA Hub server, which performs all inference.

Back-compat: ``from ria_toolkit_oss.agent import NodeAgent`` and the ``main``
entry point continue to work.
"""

from __future__ import annotations

from .legacy_executor import NodeAgent
from .legacy_executor import main as _legacy_main

__all__ = ["NodeAgent", "main"]


def main() -> None:
    """Unified CLI entry point. Dispatches to streamer/legacy subcommands."""
    from .cli import main as _cli_main

    _cli_main()
