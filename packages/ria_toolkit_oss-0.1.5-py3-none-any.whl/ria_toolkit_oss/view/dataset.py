import os

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages

from ria_toolkit_oss.io.recording import from_npy


def create_dataset_pdf(dataset_path, output_path, div=64, metadata_keys=None):
    i = 0
    with PdfPages(output_path) as pdf:
        for root, _, files in os.walk(dataset_path):
            for file in files:
                if file.endswith(".npy"):
                    i = i + 1

                    print(f"{i}/{len(files)}")

                    full_path = os.path.join(root, file)

                    recording = from_npy(full_path)

                    samples = recording.data[0]

                    metadata = recording.metadata

                    if metadata_keys is not None:
                        metadata_to_print = {}
                        for key in metadata_keys:
                            metadata_to_print[key] = metadata.get(key, "None")
                    else:
                        metadata_to_print = metadata

                    signal_length = len(samples)
                    nfft = max(2 ** int(np.log2(signal_length // div)), 64)

                    dict_text = dict_text = "\n".join([f"{key}: {value}" for key, value in metadata_to_print.items()])

                    fig, axs = plt.subplots(2, 1, figsize=(10, 10), gridspec_kw={"height_ratios": [4, 1]})

                    # Create the spectrogram in the first subplot
                    axs[0].specgram(samples, NFFT=nfft, Fs=metadata["sample_rate"], cmap="twilight", noverlap=128)
                    axs[0].set_title(file)
                    axs[0].set_xlabel("Time (s)")
                    axs[0].set_ylabel("Frequency (Hz)")
                    #    axs[0].colorbar(label='Intensity (dB)')

                    # Adjust layout so that there's enough space for the second subplot (text)
                    plt.subplots_adjust(hspace=0.5)

                    # Add the text in the second subplot
                    axs[1].text(0.1, 0.5, dict_text, ha="left", va="center", fontsize=10, color="black", wrap=True)
                    axs[1].axis("off")  # Turn off axes for the text subplot

                    # Save the figure (spectrogram and text) to the PDF
                    pdf.savefig(fig)
                    plt.close()


if __name__ == "__main__":

    create_dataset_pdf("/mnt/hddstorage/alec/qesa1_c4/nov15/low_mod2", "dataset.pdf")
