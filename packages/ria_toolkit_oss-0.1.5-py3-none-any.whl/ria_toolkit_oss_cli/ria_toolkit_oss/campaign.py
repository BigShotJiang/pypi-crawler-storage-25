"""Campaign orchestration CLI commands.

Usage examples::

    # Enroll a single device using a device profile YAML (App 1 workflow)
    ria campaign enroll --config iphone13.yml

    # Run a full custom campaign config
    ria campaign run --config my_campaign.yml

    # Validate a config file without running it
    ria campaign validate --config my_campaign.yml
"""

import sys

import click

from ria_toolkit_oss.orchestration.campaign import CampaignConfig
from ria_toolkit_oss.orchestration.executor import CampaignExecutor, StepResult


@click.group()
def campaign():
    """Orchestrate automated RF capture campaigns."""


# ---------------------------------------------------------------------------
# ria campaign validate
# ---------------------------------------------------------------------------


@campaign.command()
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Campaign YAML config or device profile YAML.",
)
@click.option(
    "--profile",
    is_flag=True,
    default=False,
    help="Parse as a device profile (App 1 style) rather than a full campaign config.",
)
def validate(config, profile):
    """Validate a campaign or device profile YAML without running it.

    \b
    Examples:
        ria campaign validate --config iphone13.yml --profile
        ria campaign validate --config campaign.yml
    """
    try:
        if profile:
            cfg = CampaignConfig.from_device_profile(config)
        else:
            cfg = CampaignConfig.from_yaml(config)
    except (FileNotFoundError, ValueError, KeyError) as e:
        raise click.ClickException(str(e))

    click.echo(click.style("✓ Config valid", fg="green", bold=True))
    click.echo(f"  Campaign name : {cfg.name}")
    click.echo(f"  Mode          : {cfg.mode}")
    click.echo(f"  Transmitters  : {len(cfg.transmitters)}")
    click.echo(f"  Total steps   : {cfg.total_steps()}")
    click.echo(f"  Capture time  : {cfg.total_capture_time_s():.0f}s")
    click.echo(f"  Recorder      : {cfg.recorder.device} @ {cfg.recorder.center_freq/1e6:.2f} MHz")
    click.echo(f"  Sample rate   : {cfg.recorder.sample_rate/1e6:.1f} MS/s")
    click.echo(f"  Output path   : {cfg.output.path}")
    click.echo()

    for tx in cfg.transmitters:
        click.echo(f"  Transmitter: {tx.id} ({tx.type}, {tx.control_method}, {len(tx.schedule)} steps)")
        for step in tx.schedule:
            extras = []
            if step.channel is not None:
                extras.append(f"ch={step.channel}")
            if step.bandwidth_mhz is not None:
                extras.append(f"{int(step.bandwidth_mhz)}MHz")
            if step.traffic:
                extras.append(step.traffic)
            suffix = f" [{', '.join(extras)}]" if extras else ""
            click.echo(f"    [{step.duration:.0f}s] {step.label}{suffix}")


# ---------------------------------------------------------------------------
# ria campaign enroll
# ---------------------------------------------------------------------------


@campaign.command()
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Device profile YAML (App 1 enrollment format).",
)
@click.option(
    "--output",
    "-o",
    default=None,
    help="Override output directory from config.",
)
@click.option(
    "--report",
    default="qa_report.json",
    show_default=True,
    help="Path for the JSON QA report.",
)
@click.option("--verbose", "-v", is_flag=True, help="Verbose output.")
@click.option("--dry-run", is_flag=True, help="Parse and validate config, then exit.")
def enroll(config, output, report, verbose, dry_run):
    """Enroll a single device by running its capture profile.

    Parses a device profile YAML (App 1 format), generates a capture
    campaign, and runs it. Outputs labelled SigMF recordings and a
    JSON QA report.

    \b
    Examples:
        ria campaign enroll --config iphone13.yml
        ria campaign enroll --config airpods.yml --output ./my_recordings
        ria campaign enroll --config iphone13.yml --dry-run
    """
    try:
        cfg = CampaignConfig.from_device_profile(config)
    except (FileNotFoundError, ValueError, KeyError) as e:
        raise click.ClickException(str(e))

    if output:
        cfg.output.path = output

    _print_campaign_summary(cfg)

    if dry_run:
        click.echo(click.style("Dry run — exiting before capture.", fg="yellow"))
        return

    result = _run_campaign(cfg, verbose=verbose)
    result.write_report(report)

    _print_result_summary(result, report)
    sys.exit(0 if result.failed == 0 else 1)


# ---------------------------------------------------------------------------
# ria campaign run
# ---------------------------------------------------------------------------


@campaign.command()
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Full campaign YAML config.",
)
@click.option(
    "--output",
    "-o",
    default=None,
    help="Override output directory from config.",
)
@click.option(
    "--report",
    default="qa_report.json",
    show_default=True,
    help="Path for the JSON QA report.",
)
@click.option("--verbose", "-v", is_flag=True, help="Verbose output.")
@click.option("--dry-run", is_flag=True, help="Parse and validate config, then exit.")
def run(config, output, report, verbose, dry_run):
    """Run a full campaign from a campaign config YAML.

    \b
    Examples:
        ria campaign run --config wifi_capture.yml
        ria campaign run --config campaign.yml --output ./data --dry-run
    """
    try:
        cfg = CampaignConfig.from_yaml(config)
    except (FileNotFoundError, ValueError, KeyError) as e:
        raise click.ClickException(str(e))

    if output:
        cfg.output.path = output

    _print_campaign_summary(cfg)

    if dry_run:
        click.echo(click.style("Dry run — exiting before capture.", fg="yellow"))
        return

    result = _run_campaign(cfg, verbose=verbose)
    result.write_report(report)

    _print_result_summary(result, report)
    sys.exit(0 if result.failed == 0 else 1)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _print_campaign_summary(cfg: CampaignConfig) -> None:
    click.echo()
    click.echo(click.style(f"Campaign: {cfg.name}", bold=True))
    click.echo(f"  Transmitters : {len(cfg.transmitters)}")
    click.echo(f"  Total steps  : {cfg.total_steps()}")
    click.echo(f"  Capture time : ~{cfg.total_capture_time_s():.0f}s")
    click.echo(f"  Output       : {cfg.output.path}")
    click.echo()


def _make_progress_cb(total: int):
    """Return a progress callback that prints step results to stderr."""

    def cb(idx: int, _total: int, step: StepResult) -> None:
        status = (
            click.style("✓", fg="green")
            if step.ok
            else (click.style("⚑", fg="yellow") if step.qa.flagged else click.style("✗", fg="red"))
        )
        snr_str = f"SNR {step.qa.snr_db:.1f} dB" if not step.error else f"ERROR: {step.error}"
        click.echo(
            f"  [{idx:>3}/{_total}] {status} {step.transmitter_id}/{step.step_label} — {snr_str}",
            err=True,
        )

    return cb


def _run_campaign(cfg: CampaignConfig, verbose: bool = False):
    executor = CampaignExecutor(
        config=cfg,
        progress_cb=_make_progress_cb(cfg.total_steps()),
        verbose=verbose,
    )
    return executor.run()


def _print_result_summary(result, report_path: str) -> None:
    click.echo()
    click.echo(click.style("Campaign complete", bold=True))
    click.echo(f"  Steps   : {result.total_steps}")
    click.echo(f"  Passed  : {click.style(str(result.passed), fg='green')}")
    if result.flagged:
        click.echo(f"  Flagged : {click.style(str(result.flagged), fg='yellow')} (review required)")
    if result.failed:
        click.echo(f"  Failed  : {click.style(str(result.failed), fg='red')}")
    click.echo(f"  Duration: {result.duration_s:.0f}s")
    click.echo(f"  Report  : {report_path}")
    click.echo()
