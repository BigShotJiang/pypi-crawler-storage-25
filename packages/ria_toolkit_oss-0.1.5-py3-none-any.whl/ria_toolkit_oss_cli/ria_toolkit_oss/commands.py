# flake8: noqa: F401
"""
This module contains all the CLI bindings for the ria package.
"""

from .annotate import annotate
from .campaign import campaign
from .capture import capture
from .combine import combine
from .convert import convert

# Import all command functions
from .discover import discover
from .generate import generate

# from .generate import generate
from .init import init
from .serve import serve
from .split import split
from .transform import transform
from .transmit import transmit
from .view import view

# Aliases
synth = generate

# All commands will be automatically registered by cli.py
# Commands must be click.Command instances
