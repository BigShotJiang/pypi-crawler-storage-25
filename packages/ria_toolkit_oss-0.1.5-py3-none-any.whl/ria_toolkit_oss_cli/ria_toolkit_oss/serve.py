"""``ria serve`` — start the RT-OSS HTTP server for RIA Hub integration."""

import click


@click.command()
@click.option("--host", default="0.0.0.0", show_default=True, help="Bind host.")
@click.option("--port", default=8080, show_default=True, type=int, help="Bind port.")
@click.option(
    "--api-key",
    envvar="RT_OSS_API_KEY",
    default="",
    help="Required X-API-Key value. Also reads RT_OSS_API_KEY. Empty = no auth (dev only).",
)
@click.option(
    "--log-level",
    default="info",
    show_default=True,
    type=click.Choice(["debug", "info", "warning", "error"], case_sensitive=False),
)
def serve(host: str, port: int, api_key: str, log_level: str):
    """Start the RT-OSS HTTP server.

    \b
    Endpoints:
        POST /orchestrator/deploy
        GET  /orchestrator/status/{campaign_id}
        POST /orchestrator/cancel/{campaign_id}
        POST /inference/load
        POST /inference/start
        POST /inference/stop
        GET  /inference/status
        GET  /health
    """
    try:
        import uvicorn

        from ria_toolkit_oss.server.app import create_app
    except ImportError as e:
        raise click.ClickException(
            f"Server dependencies missing: {e}\nInstall with: pip install ria-toolkit-oss[server]"
        )

    if not api_key:
        click.echo(
            click.style("Warning: ", fg="yellow", bold=True) + "no API key set — all requests unauthenticated.",
            err=True,
        )

    click.echo(f"Starting RT-OSS server on http://{host}:{port}")
    uvicorn.run(create_app(api_key=api_key), host=host, port=port, log_level=log_level.lower())
