"""
This module contains the main group for the ria toolkit oss CLI.
"""

import click

from ria_toolkit_oss_cli.ria_toolkit_oss import commands


@click.group()
@click.option("-v", "--verbose", is_flag=True, type=bool, help="Increase verbosity, especially useful for debugging.")
def cli(verbose):
    pass


# Loop through project commands, binding them all to the CLI.
for command_name in dir(commands):
    command = getattr(commands, command_name)
    if isinstance(command, click.Command):
        cli.add_command(command, name=command_name)
