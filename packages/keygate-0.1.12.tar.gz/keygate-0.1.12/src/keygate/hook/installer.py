from __future__ import annotations

import shlex
import subprocess
import sys
from pathlib import Path

import click


def _git_path(repo_root: Path, path_name: str) -> Path:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-path", path_name],
            capture_output=True,
            text=True,
            cwd=repo_root,
        )
    except FileNotFoundError as e:
        raise click.ClickException("git is required but was not found in PATH.") from e
    if result.returncode != 0:
        raise click.ClickException("Not a git repository.")
    return Path(result.stdout.strip())


def _build_hook_script() -> str:
    python_executable = shlex.quote(sys.executable)
    return f"""\
#!/bin/sh
# Installed by keygate

if [ -x {python_executable} ]; then
  exec {python_executable} -m keygate.cli scan
fi

if command -v keygate >/dev/null 2>&1; then
  exec keygate scan
fi

echo "keygate is not available. Reinstall it or update PATH." >&2
exit 1
"""


def install(repo_root: Path) -> None:
    hooks_dir = _git_path(repo_root, "hooks")
    if not hooks_dir.is_absolute():
        hooks_dir = repo_root / hooks_dir
    hooks_dir.mkdir(exist_ok=True)
    hook_path = hooks_dir / "pre-commit"

    if hook_path.exists():
        click.confirm(
            f"{hook_path} already exists. Overwrite?",
            abort=True,
        )

    hook_path.write_text(_build_hook_script())
    hook_path.chmod(0o755)
    click.echo(f"Installed pre-commit hook: {hook_path}")
