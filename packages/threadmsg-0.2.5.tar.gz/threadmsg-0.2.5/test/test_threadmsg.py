#!/usr/bin/env python3
"""Comprehensive pytest suite for threadmsg."""

import time
import asyncio
import threading
import pytest
import threadmsg as tm


def _wait(event, timeout=5):
    assert event.wait(timeout=timeout), "Timed out waiting for threading.Event"


# ===========================================================================
# findByType
# ===========================================================================

class TestFindByType:

    @pytest.fixture
    def sample(self):
        def f1():
            return 55
        return [11, 21, 'hi', [1, 2, 3], 31, {'a': 'b'}, 41, f1]

    def test_first_int(self, sample):
        assert tm.ThreadMsg.findByType(0, int, 0, sample) == 11

    def test_second_int(self, sample):
        assert tm.ThreadMsg.findByType(1, int, 0, sample) == 21

    def test_third_int(self, sample):
        assert tm.ThreadMsg.findByType(2, int, 0, sample) == 31

    def test_fourth_int(self, sample):
        assert tm.ThreadMsg.findByType(3, int, 0, sample) == 41

    def test_string(self, sample):
        assert tm.ThreadMsg.findByType(0, str, '', sample) == 'hi'

    def test_list(self, sample):
        assert tm.ThreadMsg.findByType(0, list, [], sample)[0] == 1

    def test_dict(self, sample):
        assert tm.ThreadMsg.findByType(0, dict, {}, sample)['a'] == 'b'

    def test_callable(self, sample):
        assert tm.ThreadMsg.findByType(0, callable, None, sample)() == 55

    def test_multi_type_at_index(self, sample):
        # Among [str, int]: 11(0), 21(1), 'hi'(2)
        assert tm.ThreadMsg.findByType(2, [str, int], '', sample) == 'hi'

    def test_callable_in_multi_type(self, sample):
        # Among [list, callable]: [1,2,3](0), f1(1)
        assert tm.ThreadMsg.findByType(1, [list, callable], None, sample)() == 55

    def test_default_when_type_missing(self):
        assert tm.ThreadMsg.findByType(0, str, 'nope', [1, 2, 3]) == 'nope'

    def test_default_when_index_exceeds(self):
        assert tm.ThreadMsg.findByType(99, int, -1, [1, 2, 3]) == -1

    def test_empty_list_returns_default(self):
        assert tm.ThreadMsg.findByType(0, int, 42, []) == 42


# ===========================================================================
# ThreadMsgReply
# ===========================================================================

class TestThreadMsgReply:

    def test_no_loop_no_event(self):
        r = tm.ThreadMsg.ThreadMsgReply(None)
        assert r.event is None

    def test_no_loop_default_params_empty(self):
        r = tm.ThreadMsg.ThreadMsgReply(None)
        assert r.getParams() == {}

    def test_no_loop_custom_params_stored(self):
        r = tm.ThreadMsg.ThreadMsgReply(None, {'x': 1})
        assert r.getParams() == {'x': 1}

    def test_mutable_default_not_shared_between_instances(self):
        r1 = tm.ThreadMsg.ThreadMsgReply(None)
        r2 = tm.ThreadMsg.ThreadMsgReply(None)
        r1.getParams()['x'] = 99
        assert 'x' not in r2.getParams()

    def test_is_data_false_initially(self):
        r = tm.ThreadMsg.ThreadMsgReply(None)
        assert not r.isData()

    def test_is_error_false_initially(self):
        r = tm.ThreadMsg.ThreadMsgReply(None)
        assert not r.isError()

    def test_set_data_no_loop(self):
        r = tm.ThreadMsg.ThreadMsgReply(None)
        r.setData(42)
        assert r.isData()
        assert not r.isError()

    def test_set_error_no_loop(self):
        r = tm.ThreadMsg.ThreadMsgReply(None)
        r.setError(Exception('boom'))
        assert r.isError()
        assert not r.isData()

    def test_get_data_without_loop_returns_none(self):
        # event is None when loop=None; getData() requires event confirmation
        r = tm.ThreadMsg.ThreadMsgReply(None)
        r.setData(42)
        assert r.getData() is None    # use isData() to poll in the no-loop case

    def test_get_error_without_loop_returns_none(self):
        r = tm.ThreadMsg.ThreadMsgReply(None)
        r.setError(ValueError('x'))
        assert r.getError() is None   # use isError() to poll in the no-loop case

    async def test_set_data_signals_event(self):
        loop = asyncio.get_running_loop()
        r = tm.ThreadMsg.ThreadMsgReply(loop)

        async def setter():
            await asyncio.sleep(0.02)
            r.setData('ok')

        asyncio.create_task(setter())
        assert await r.wait(3.0)
        assert r.getData() == 'ok'
        assert r.isData()

    async def test_set_error_signals_event(self):
        loop = asyncio.get_running_loop()
        r = tm.ThreadMsg.ThreadMsgReply(loop)

        async def setter():
            await asyncio.sleep(0.02)
            r.setError(RuntimeError('oops'))

        asyncio.create_task(setter())
        assert await r.wait(3.0)
        assert r.isError()
        assert isinstance(r.getError(), RuntimeError)

    async def test_wait_timeout_returns_false(self):
        loop = asyncio.get_running_loop()
        r = tm.ThreadMsg.ThreadMsgReply(loop)
        assert await r.wait(0.05) is False

    async def test_wait_already_set_returns_immediately(self):
        loop = asyncio.get_running_loop()
        r = tm.ThreadMsg.ThreadMsgReply(loop)
        r.setData('ready')
        assert await r.wait(3.0) is True

    def test_set_data_from_background_thread(self):
        r = tm.ThreadMsg.ThreadMsgReply(None)
        t = threading.Thread(target=lambda: (time.sleep(0.05), r.setData(7)))
        t.start()
        deadline = time.monotonic() + 5
        while not r.isData() and time.monotonic() < deadline:
            time.sleep(0.01)
        t.join()
        assert r.isData()


# ===========================================================================
# Thread lifecycle
# ===========================================================================

class TestThreadLifecycle:

    def test_start_stop_join(self):
        running = threading.Event()
        done = threading.Event()

        async def f(ctx):
            if not ctx.run:
                done.set()
                return
            running.set()

        t = tm.ThreadMsg(f)
        _wait(running)   # ensure at least one iteration before stopping
        t.stop()
        _wait(done)
        t.join()

    def test_start_false_delays_execution(self):
        started = threading.Event()

        async def f(ctx):
            started.set()
            return -1

        t = tm.ThreadMsg(f, start=False)
        assert not started.is_set()
        t.start()
        _wait(started)
        t.join()

    def test_extra_params_forwarded(self):
        received = []
        done = threading.Event()

        async def f(ctx, v1, v2):
            if not received:   # capture only on the first (non-exit) call
                received.extend([v1, v2])
                done.set()
            return -1

        t = tm.ThreadMsg(f, (10, 20))
        _wait(done)
        t.join(True)
        assert received == [10, 20]

    def test_negative_return_stops_thread(self):
        done = threading.Event()

        async def f(ctx):
            done.set()
            return -1

        t = tm.ThreadMsg(f)
        _wait(done)
        t.join()
        assert not t.thread.is_alive()

    def test_exit_call_made_with_run_false(self):
        # threadRun calls f one final time with ctx.run=False after inner loop exits
        exit_seen = threading.Event()

        async def f(ctx):
            if not ctx.run:
                exit_seen.set()
                return
            return -1

        t = tm.ThreadMsg(f)
        _wait(exit_seen)
        t.join()

    def test_loops_counter_increments(self):
        counts = []
        done = threading.Event()

        async def f(ctx):
            counts.append(ctx.loops)
            if ctx.loops >= 2:
                done.set()
                return -1
            return 0

        t = tm.ThreadMsg(f)
        _wait(done)
        t.join(True)
        assert counts[:3] == [0, 1, 2]

    def test_on_threadmsg_error_hook_called(self):
        errors = []
        done = threading.Event()

        async def f(ctx):
            raise RuntimeError('test error')

        t = tm.ThreadMsg(f, start=False)
        t.on_threadmsg_error = lambda e: (errors.append(e), done.set())
        t.start()
        _wait(done)
        t.join()
        # threadRun calls f twice (inner loop + exit call), so at least one error
        assert len(errors) >= 1
        assert all(isinstance(e, RuntimeError) for e in errors)

    def test_notify_interrupts_long_wait(self):
        notified = threading.Event()

        async def f(ctx):
            if ctx.loops >= 1:
                notified.set()
                return -1
            return 60  # would block without notify

        t = tm.ThreadMsg(f)
        time.sleep(0.05)
        t.notify()
        _wait(notified)
        t.join()

    def test_join_stop_true_terminates(self):
        async def f(ctx):
            return None  # wait forever

        t = tm.ThreadMsg(f)
        t.join(stop=True)
        assert not t.thread.is_alive()

    def test_want_run_true_during_run(self):
        seen = []
        done = threading.Event()

        async def f(ctx):
            seen.append(ctx.wantRun())
            done.set()
            return -1

        t = tm.ThreadMsg(f)
        _wait(done)
        t.join()
        assert seen[0] is True

    def test_delay_controls_call_timing(self):
        times = []
        done = threading.Event()

        async def f(ctx):
            if not ctx.run:   # skip the exit call — it has no preceding delay
                return
            times.append(time.monotonic())
            if len(times) >= 3:
                done.set()
                return -1
            return 0.05

        t = tm.ThreadMsg(f)
        _wait(done, timeout=10)
        t.join()
        assert len(times) == 3
        gaps = [times[i + 1] - times[i] for i in range(len(times) - 1)]
        for gap in gaps:
            assert gap >= 0.03, f"Gap {gap:.3f}s shorter than expected"


# ===========================================================================
# Message queue
# ===========================================================================

class TestMessageQueue:

    def test_add_get_msg_roundtrip(self):
        received = []
        done = threading.Event()

        async def f(ctx):
            msg = ctx.getMsg()
            if msg:
                received.append(msg['data'])
                done.set()
                return -1

        t = tm.ThreadMsg(f)
        t.addMsg('hello')
        _wait(done)
        t.join(True)
        assert received == ['hello']

    def test_get_msg_empty_returns_none(self):
        result = ['sentinel']
        done = threading.Event()

        async def f(ctx):
            result[0] = ctx.getMsg()
            done.set()
            return -1

        t = tm.ThreadMsg(f)
        _wait(done)
        t.join(True)
        assert result[0] is None

    def test_get_msg_data_roundtrip(self):
        received = []
        done = threading.Event()

        async def f(ctx):
            data = ctx.getMsgData()
            if data is not None:
                received.append(data)
                done.set()
                return -1

        t = tm.ThreadMsg(f)
        t.addMsg('world')
        _wait(done)
        t.join(True)
        assert received == ['world']

    def test_get_msg_data_empty_returns_none(self):
        result = ['sentinel']
        done = threading.Event()

        async def f(ctx):
            result[0] = ctx.getMsgData()
            done.set()
            return -1

        t = tm.ThreadMsg(f)
        _wait(done)
        t.join(True)
        assert result[0] is None

    def test_fifo_delivery_order(self):
        received = []
        done = threading.Event()

        async def f(ctx):
            while True:
                msg = ctx.getMsgData()
                if msg is None:
                    break
                received.append(msg)
            if len(received) == 3:
                done.set()
                return -1

        t = tm.ThreadMsg(f, start=False)
        t.addMsg('first')
        t.addMsg('second')
        t.addMsg('third')
        t.start()
        _wait(done)
        t.join(True)
        assert received == ['first', 'second', 'third']

    def test_addmsg_callback_invoked(self):
        callbacks = []
        done = threading.Event()

        async def f(ctx):
            msg = ctx.getMsg()
            if msg and callable(msg['cb']):
                msg['cb'](ctx, msg['data'], 'ret', None)
                done.set()
                return -1

        def cb(ctx, data, result, err):
            callbacks.append((data, result, err))

        t = tm.ThreadMsg(f)
        t.addMsg('payload', cb)
        _wait(done)
        t.join(True)
        assert callbacks == [('payload', 'ret', None)]

    def test_many_messages_all_processed(self):
        received = []
        done = threading.Event()
        total = 20

        async def f(ctx):
            msg = ctx.getMsgData()
            if msg is not None:
                received.append(msg)
            if len(received) == total:
                done.set()
                return -1

        t = tm.ThreadMsg(f)
        for i in range(total):
            t.addMsg(i)
        _wait(done)
        t.join(True)
        assert len(received) == total


# ===========================================================================
# mapCall
# ===========================================================================

class TestMapCall:

    @pytest.fixture(autouse=True)
    def cleanup(self):
        self._t = None
        yield
        if self._t:
            self._t.join(True)

    def _run(self, fn):
        """Run fn(ctx) synchronously inside a thread, return (result, error)."""
        result = [None]
        error = [None]
        done = threading.Event()

        async def f(ctx):
            try:
                result[0] = fn(ctx)
            except Exception as e:
                error[0] = e
            done.set()
            return -1

        self._t = tm.ThreadMsg(f)
        _wait(done)
        return result[0], error[0]

    def test_direct_callable(self):
        def add(a, b):
            return a + b
        r, e = self._run(lambda ctx: ctx.mapCall(add, {}, {'a': 3, 'b': 4}))
        assert e is None and r == 7

    def test_string_key_lookup(self):
        fm = {'add': lambda a, b: a + b}
        result = [None]
        done = threading.Event()

        async def f(ctx):
            result[0] = ctx.mapCall('_fn', fm, {'_fn': 'add', 'a': 10, 'b': 5})
            done.set()
            return -1

        self._t = tm.ThreadMsg(f, deffk='_fn')
        _wait(done)
        assert result[0] == 15

    def test_default_function_key_used_when_f_is_none(self):
        fm = {'mul': lambda a, b: a * b}
        result = [None]
        done = threading.Event()

        async def f(ctx):
            result[0] = ctx.mapCall(None, fm, {'_fn': 'mul', 'a': 3, 'b': 4})
            done.set()
            return -1

        self._t = tm.ThreadMsg(f, deffk='_fn')
        _wait(done)
        assert result[0] == 12

    def test_respects_param_defaults(self):
        def add_with_default(a, b=100):
            return a + b
        r, e = self._run(lambda ctx: ctx.mapCall(add_with_default, {}, {'a': 5}))
        assert e is None and r == 105

    def test_missing_required_param_raises(self):
        def needs_both(a, b):
            return a + b
        r, e = self._run(lambda ctx: ctx.mapCall(needs_both, {}, {'a': 1}))
        assert e is not None and 'b' in str(e)

    def test_does_not_mutate_caller_params(self):
        def add(a, b):
            return a + b
        original = {'a': 1, 'b': 2}
        snapshot = dict(original)
        self._run(lambda ctx: ctx.mapCall(add, {}, original, extra=99))
        assert original == snapshot

    def test_kwargs_merged_with_params(self):
        def add(a, b):
            return a + b
        r, e = self._run(lambda ctx: ctx.mapCall(add, {}, {'a': 1}, b=9))
        assert e is None and r == 10

    def test_function_not_in_map_raises(self):
        fm = {'add': lambda a, b: a + b}
        result = [None]
        error = [None]
        done = threading.Event()

        async def f(ctx):
            try:
                result[0] = ctx.mapCall('_fn', fm, {'_fn': 'missing', 'a': 1, 'b': 2})
            except Exception as e:
                error[0] = e
            done.set()
            return -1

        self._t = tm.ThreadMsg(f, deffk='_fn')
        _wait(done)
        assert error[0] is not None and 'missing' in str(error[0])

    def test_var_positional_args_skipped(self):
        def f_with_star(a, *args):
            return a
        r, e = self._run(lambda ctx: ctx.mapCall(f_with_star, {}, {'a': 7}))
        assert e is None and r == 7

    def test_var_keyword_args_skipped(self):
        def f_with_kwargs(a, **opts):
            return a
        r, e = self._run(lambda ctx: ctx.mapCall(f_with_kwargs, {}, {'a': 9}))
        assert e is None and r == 9

    def test_only_var_positional_skipped(self):
        def f_star_only(*args):
            return 42
        r, e = self._run(lambda ctx: ctx.mapCall(f_star_only, {}, {}))
        assert e is None and r == 42


# ===========================================================================
# mapCallAsync
# ===========================================================================

class TestMapCallAsync:

    @pytest.fixture(autouse=True)
    def cleanup(self):
        self._t = None
        yield
        if self._t:
            self._t.join(True)

    def _run(self, coro_fn):
        """Await coro_fn(ctx) inside a thread, return (result, error)."""
        result = [None]
        error = [None]
        done = threading.Event()

        async def f(ctx):
            try:
                result[0] = await coro_fn(ctx)
            except Exception as e:
                error[0] = e
            done.set()
            return -1

        self._t = tm.ThreadMsg(f)
        _wait(done)
        return result[0], error[0]

    def test_sync_function(self):
        def add(a, b):
            return a + b
        r, e = self._run(lambda ctx: ctx.mapCallAsync(add, {}, {'a': 3, 'b': 4}))
        assert e is None and r == 7

    def test_async_function(self):
        async def add(a, b):
            return a + b
        r, e = self._run(lambda ctx: ctx.mapCallAsync(add, {}, {'a': 3, 'b': 4}))
        assert e is None and r == 7

    def test_respects_param_defaults(self):
        async def add(a, b=100):
            return a + b
        r, e = self._run(lambda ctx: ctx.mapCallAsync(add, {}, {'a': 5}))
        assert e is None and r == 105

    def test_missing_required_param_raises(self):
        async def needs_both(a, b):
            return a + b
        r, e = self._run(lambda ctx: ctx.mapCallAsync(needs_both, {}, {'a': 1}))
        assert e is not None and 'b' in str(e)

    def test_does_not_mutate_caller_params(self):
        async def add(a, b):
            return a + b
        original = {'a': 1, 'b': 2}
        snapshot = dict(original)
        self._run(lambda ctx: ctx.mapCallAsync(add, {}, original, extra=99))
        assert original == snapshot

    def test_async_exception_propagates(self):
        async def boom(a):
            raise ValueError('async boom')
        r, e = self._run(lambda ctx: ctx.mapCallAsync(boom, {}, {'a': 1}))
        assert isinstance(e, ValueError)

    def test_var_positional_args_skipped(self):
        async def f_with_star(a, *args):
            return a
        r, e = self._run(lambda ctx: ctx.mapCallAsync(f_with_star, {}, {'a': 7}))
        assert e is None and r == 7

    def test_var_keyword_args_skipped(self):
        async def f_with_kwargs(a, **opts):
            return a
        r, e = self._run(lambda ctx: ctx.mapCallAsync(f_with_kwargs, {}, {'a': 9}))
        assert e is None and r == 9


# ===========================================================================
# mapMsg / mapMsgAsync  (shared funThread fixture)
# ===========================================================================

@pytest.fixture
def fun_thread():
    class FunThread(tm.ThreadMsg):
        def __init__(self):
            self.callMap = {
                'add':        self.add,
                'add_async':  self.add_async,
                'boom':       self.boom,
                'boom_async': self.boom_async,
            }
            super().__init__(self.msgThread, deffk='_fn')

        @staticmethod
        async def msgThread(ctx):
            while msg := ctx.getMsg():
                await ctx.mapMsgAsync(None, ctx.callMap, msg)

        def add(self, a, b):
            return a + b

        async def add_async(self, a, b):
            return a + b

        def boom(self, a):
            raise ValueError('sync error')

        async def boom_async(self, a):
            raise RuntimeError('async error')

    t = FunThread()
    yield t
    t.join(True)


class TestMapMsg:

    @pytest.fixture(autouse=True)
    def cleanup(self):
        self._t = None
        yield
        if self._t:
            self._t.join(True)

    def test_success_callback(self):
        results = []
        done = threading.Event()
        fm = {'add': lambda a, b: a + b}

        async def f(ctx):
            msg = ctx.getMsg()
            if msg:
                ctx.mapMsg(None, fm, msg)
                done.set()
                return -1

        def cb(ctx, data, ret, err):
            results.append((ret, err))

        self._t = tm.ThreadMsg(f, deffk='_fn')
        self._t.addMsg({'_fn': 'add', 'a': 2, 'b': 3}, cb)
        _wait(done)
        assert results == [(5, None)]

    def test_error_delivered_to_callback(self):
        errors = []
        done = threading.Event()

        def boom(a):
            raise ValueError('sync')

        fm = {'boom': boom}

        async def f(ctx):
            msg = ctx.getMsg()
            if msg:
                ctx.mapMsg(None, fm, msg)
                done.set()
                return -1

        def cb(ctx, data, ret, err):
            errors.append(err)

        self._t = tm.ThreadMsg(f, deffk='_fn')
        self._t.on_threadmsg_error = lambda e: None
        self._t.addMsg({'_fn': 'boom', 'a': 1}, cb)
        _wait(done)
        assert len(errors) == 1 and isinstance(errors[0], ValueError)


class TestMapMsgAsync:

    def test_sync_function_callback(self, fun_thread):
        results = []
        done = threading.Event()

        def cb(ctx, data, ret, err):
            results.append((ret, err))
            done.set()

        fun_thread.addMsg({'_fn': 'add', 'a': 2, 'b': 3}, cb)
        _wait(done)
        assert results == [(5, None)]

    def test_async_function_callback(self, fun_thread):
        results = []
        done = threading.Event()

        def cb(ctx, data, ret, err):
            results.append((ret, err))
            done.set()

        fun_thread.addMsg({'_fn': 'add_async', 'a': 6, 'b': 7}, cb)
        _wait(done)
        assert results == [(13, None)]

    def test_sync_error_to_callback(self, fun_thread):
        fun_thread.on_threadmsg_error = lambda e: None
        errors = []
        done = threading.Event()

        def cb(ctx, data, ret, err):
            errors.append(err)
            done.set()

        fun_thread.addMsg({'_fn': 'boom', 'a': 1}, cb)
        _wait(done)
        assert len(errors) == 1 and isinstance(errors[0], ValueError)

    def test_async_error_to_callback(self, fun_thread):
        fun_thread.on_threadmsg_error = lambda e: None
        errors = []
        done = threading.Event()

        def cb(ctx, data, ret, err):
            errors.append(err)
            done.set()

        fun_thread.addMsg({'_fn': 'boom_async', 'a': 1}, cb)
        _wait(done)
        assert len(errors) == 1 and isinstance(errors[0], RuntimeError)

    def test_no_callback_thread_survives(self, fun_thread):
        # A message with no callback and no error should not kill the thread
        alive = threading.Event()

        def cb(ctx, data, ret, err):
            alive.set()

        fun_thread.addMsg({'_fn': 'add', 'a': 1, 'b': 1})  # no callback
        fun_thread.addMsg({'_fn': 'add', 'a': 2, 'b': 2}, cb)
        _wait(alive)

    def test_multiple_messages_in_order(self, fun_thread):
        results = []
        done = threading.Event()

        def cb(ctx, data, ret, err):
            results.append(ret)
            if len(results) == 3:
                done.set()

        fun_thread.addMsg({'_fn': 'add', 'a': 1, 'b': 0}, cb)
        fun_thread.addMsg({'_fn': 'add', 'a': 2, 'b': 0}, cb)
        fun_thread.addMsg({'_fn': 'add', 'a': 3, 'b': 0}, cb)
        _wait(done)
        assert results == [1, 2, 3]


# ===========================================================================
# call()
# ===========================================================================

@pytest.fixture
def call_thread():
    class FunThread(tm.ThreadMsg):
        def __init__(self):
            self.callMap = {
                'add':  self.add,
                'boom': self.boom,
            }
            super().__init__(self.msgThread, deffk='_fn')

        @staticmethod
        async def msgThread(ctx):
            while msg := ctx.getMsg():
                await ctx.mapMsgAsync(None, ctx.callMap, msg)

        def add(self, a, b):
            return a + b

        def boom(self, a):
            raise ValueError('deliberate')

    t = FunThread()
    yield t
    t.join(True)


class TestCall:

    def test_call_with_callback(self, call_thread):
        results = []
        done = threading.Event()

        def cb(ctx, params, ret, err):
            results.append((ret, err))
            done.set()

        call_thread.call(cb, 'add', a=3, b=4)
        _wait(done)
        assert results == [(7, None)]

    async def test_call_returns_reply_object(self, call_thread):
        reply = call_thread.call('add', a=10, b=20)
        assert reply is not None
        assert await reply.wait(5)
        assert reply.getData() == 30

    async def test_call_error_reflected_in_reply(self, call_thread):
        call_thread.on_threadmsg_error = lambda e: None
        reply = call_thread.call('boom', a=1)
        assert await reply.wait(5)
        assert reply.isError()
        assert isinstance(reply.getError(), ValueError)

    async def test_call_with_dict_param(self, call_thread):
        reply = call_thread.call({'_fn': 'add', 'a': 5}, b=6)
        assert await reply.wait(5)
        assert reply.getData() == 11

    def test_call_does_not_mutate_caller_dict(self, call_thread):
        done = threading.Event()

        def cb(ctx, params, ret, err):
            done.set()

        my_params = {'_fn': 'add', 'a': 1, 'b': 2}
        original = dict(my_params)
        call_thread.call(cb, my_params)
        _wait(done)
        assert my_params == original

    def test_no_default_key_raises(self):
        async def f(ctx):
            return -1

        t = tm.ThreadMsg(f)
        try:
            with pytest.raises(Exception, match='Default function key not set'):
                t.call('somefunc', a=1)
        finally:
            t.join(True)

    async def test_multiple_sequential_calls(self, call_thread):
        r1 = call_thread.call('add', a=1, b=1)
        r2 = call_thread.call('add', a=2, b=2)
        r3 = call_thread.call('add', a=3, b=3)
        for reply, expected in [(r1, 2), (r2, 4), (r3, 6)]:
            assert await reply.wait(5)
            assert reply.getData() == expected

    def test_call_from_sync_context_uses_callback(self, call_thread):
        # In a purely sync context get_running_loop() → RuntimeError → loop=None.
        # Verify the callback path still works correctly.
        results = []
        done = threading.Event()

        def cb(ctx, params, ret, err):
            results.append(ret)
            done.set()

        call_thread.call(cb, 'add', a=7, b=8)
        _wait(done)
        assert results == [15]

    def test_call_deffk_kwarg(self, call_thread):
        results = []
        done = threading.Event()

        def cb(ctx, params, ret, err):
            results.append(ret)
            done.set()

        call_thread.call(cb, _fn='add', a=4, b=6)
        _wait(done)
        assert results == [10]


# ===========================================================================
# setDefaultFunctionKey
# ===========================================================================

class TestSetDefaultFunctionKey:

    def test_set_after_construction(self):
        result = [None]
        done = threading.Event()
        fm = {'greet': lambda name: f'hello {name}'}

        async def f(ctx):
            msg = ctx.getMsg()
            if msg:
                result[0] = ctx.mapCall(None, fm, msg['data'])
                done.set()
                return -1

        t = tm.ThreadMsg(f, start=False)
        t.setDefaultFunctionKey('_fn')
        t.start()
        t.addMsg({'_fn': 'greet', 'name': 'world'})
        _wait(done)
        t.join(True)
        assert result[0] == 'hello world'


# ===========================================================================
# Concurrent access
# ===========================================================================

class TestConcurrentAccess:

    def test_messages_from_multiple_sender_threads(self):
        received = []
        lock = threading.Lock()
        all_done = threading.Event()
        total = 60

        async def f(ctx):
            msg = ctx.getMsgData()
            if msg is not None:
                with lock:
                    received.append(msg)
                    if len(received) == total:
                        all_done.set()
                return 0
            return 0.001

        t = tm.ThreadMsg(f)

        def sender(values):
            for v in values:
                t.addMsg(v)

        senders = [
            threading.Thread(target=sender, args=(list(range(i * 20, (i + 1) * 20)),))
            for i in range(3)
        ]
        for s in senders:
            s.start()
        for s in senders:
            s.join()

        _wait(all_done, timeout=15)
        t.join(True)

        assert len(received) == total
        assert sorted(received) == list(range(total))

    def test_addmsg_and_getmsg_interleaved(self):
        # Hammer addMsg and getMsg from separate threads concurrently
        received = []
        lock = threading.Lock()
        done = threading.Event()
        total = 50

        async def consumer(ctx):
            msg = ctx.getMsgData()
            if msg is not None:
                with lock:
                    received.append(msg)
                    if len(received) == total:
                        done.set()
            return 0 if len(received) < total else -1

        t = tm.ThreadMsg(consumer)

        def producer():
            for i in range(total):
                t.addMsg(i)

        p = threading.Thread(target=producer)
        p.start()
        p.join()

        _wait(done, timeout=15)
        t.join(True)
        assert len(received) == total
