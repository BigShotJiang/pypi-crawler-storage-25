"""trim_messages_to_token_budget：优先收缩合成历史索引块再丢消息。"""

from __future__ import annotations

from aicd.agent.chat_context import trim_messages_to_token_budget
from aicd.agent.chat_serialize import estimate_message_tokens


def test_trim_shrinks_synthetic_preview_lines_before_dropping_message() -> None:
    previews = "\n".join(
        f"#{i} user tool=fs_read msg{i} body" for i in range(1, 30)
    )
    synthetic = (
        "[较早聊天记录 — 仅摘要；全文 chat_history_get]\n"
        + previews
    )
    tail = {"role": "user", "content": "current_turn"}
    msgs = [{"role": "user", "content": synthetic}, tail]
    # 预算略大于 tail，迫使先删掉最旧若干条 #id 预览行，而不是整段丢弃第一条 user。
    tight_budget = estimate_message_tokens(tail, vision_tokens_per_image=None) + 120
    out = trim_messages_to_token_budget(
        list(msgs),
        tight_budget,
        synthetic_preview_min_lines=4,
    )
    assert len(out) == 2
    first = out[0]["content"]
    assert isinstance(first, str)
    assert "较早聊天" in first
    assert first.count("#") < previews.count("#")


def test_trim_truncates_long_summary_block() -> None:
    big = "x" * 1200
    synthetic = f"[历史摘记 — 更早轮次]\n{big}\n\n[较早聊天记录 — x]\n#1 user a"
    tail = {"role": "user", "content": "z"}
    msgs = [{"role": "user", "content": synthetic}, tail]
    # 足够紧以触发多轮摘记截断，但仍保留 tail + 压缩后的首条 user
    tight_budget = estimate_message_tokens(tail, vision_tokens_per_image=None) + 220
    out = trim_messages_to_token_budget(
        list(msgs),
        tight_budget,
        synthetic_preview_min_lines=4,
    )
    assert len(out) == 2
    c = out[0]["content"]
    assert isinstance(c, str)
    assert len(c) < len(synthetic)
    assert c.split("\n", 1)[0] == "[历史摘记 — 更早轮次]"
