"""项目版本号（唯一真源）。小版本（第三位）每累计到 10 则进一位中版本，第三位归零。"""

from __future__ import annotations

VERSION = "0.5.8"


def parse_version(s: str) -> tuple[int, int, int]:
    parts = s.strip().split(".")
    if len(parts) != 3:
        raise ValueError(f"expected MAJOR.MINOR.PATCH, got: {s!r}")
    return int(parts[0]), int(parts[1]), int(parts[2])


def bump_version_string(current: str) -> str:
    """
    小版本 +1；若小版本 >= 10，则中版本 +1、小版本置 0。
    例：0.0.9 -> 0.1.0；0.1.0 -> 0.1.1；0.3.9 -> 0.4.0。
    """
    major, minor, patch = parse_version(current)
    patch += 1
    if patch >= 10:
        minor += 1
        patch = 0
    return f"{major}.{minor}.{patch}"
