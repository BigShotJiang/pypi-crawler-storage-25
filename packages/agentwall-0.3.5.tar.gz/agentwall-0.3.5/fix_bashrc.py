import pathlib, subprocess, re

p = pathlib.Path.home() / '.bashrc'
t = p.read_text()

# Remove all agentfirewall blocks
t = re.sub(r'# >>> agentfirewall.*?# <<< agentfirewall <<<\n?', '', t, flags=re.DOTALL)

# Remove any orphaned lines from previous bad cleanups
orphans = ('return 1', 'return 0', '# Exit code 2')
lines = t.splitlines()
clean = [l for l in lines if l.strip() not in orphans]
t = '\n'.join(clean) + '\n'

p.write_text(t)
print("Done — cleaned all agentfirewall blocks")

# Show what pyenv sets PROMPT_COMMAND to
r = subprocess.run(
    ['bash', '-c', 'source ~/.bashrc 2>/dev/null; echo "PROMPT_COMMAND=$PROMPT_COMMAND"'],
    capture_output=True, text=True
)
print(r.stdout.strip())
