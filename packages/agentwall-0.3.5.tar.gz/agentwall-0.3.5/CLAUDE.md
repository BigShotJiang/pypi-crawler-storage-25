# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**Agentwall** is a dotfile-driven security firewall that protects operating systems from destructive LLM agent tool calls. It works like `.git/` — drop a `.agentfirewall/` directory in a project and any LLM agent operating there is sandboxed and monitored.

- **Package name**: `agentwall` (on PyPI at `https://pypi.org/project/agentwall/`)
- **CLI command**: `agentfirewall`
- **Install**: `pip install agentwall`
- **Source**: `llm-security/` (old repo) or root of `agentwall` repo

## Development Commands

```bash
# Install in development mode
pip install -e ".[dev]"

# Install with optional FUSE sandbox support
pip install -e ".[dev,sandbox]"

# Run all tests
pytest -v

# Run a single test file
pytest tests/test_engine.py -v

# Run with coverage
pytest --cov=agentfirewall --cov-report=term-missing

# Run tests in Docker (sandboxed)
./test.sh
```

## Architecture

**Three-layer defense:**
1. **Shell hooks** (prevention) — `preexec` hooks in bash/zsh intercept commands before execution
2. **Filesystem watcher** (detection) — watchdog monitors files in real time and kills agent processes on violation
3. **FUSE sandbox** (kernel-level enforcement) — optional overlay filesystem that blocks syscalls at the OS level

**Core data flow**: User/agent action → `Engine.evaluate_*()` → `RuleResult` (ALLOW/DENY/WARN) → audit log + enforcement action.

### Key Modules

| Module | Role |
|--------|------|
| `schema.py` | `FirewallConfig` dataclass; `find_config()` walks up dirs like Git; `load_config()` parses YAML |
| `engine.py` | `Engine` class with `evaluate_command()`, `evaluate_file_operation()`, `evaluate_network()` |
| `presets/__init__.py` | Built-in configs: `standard`, `strict`, `permissive` |
| `audit.py` | `AuditLogger` writes one-line JSON entries to `.agentfirewall/logs/firewall.log` |
| `process.py` | `ProcessKiller` detects and terminates LLM agent processes (claude, cursor, aider, etc.) |
| `watchers/filesystem.py` | `FirewallObserver` wraps watchdog; maps file events to engine evaluations |
| `hooks/shell.py` | Generates bash `DEBUG` trap and zsh `preexec` hook scripts; handles idempotent install/uninstall |
| `sandbox.py` | `FirewallFS` FUSE passthrough filesystem; routes mutating syscalls through engine; returns `-EACCES` on deny |
| `cli.py` | Click-based CLI — see command list below |

### CLI Commands

| Command | What it does |
|---------|-------------|
| `agentfirewall protect` | One-command setup: init + install hooks + start background watcher |
| `agentfirewall unprotect` | One-command teardown: stop watcher + remove hooks |
| `agentfirewall init` | Create `.agentfirewall/` with a preset config |
| `agentfirewall check <cmd>` | Dry-run check a shell command |
| `agentfirewall check-file <path> -o <op>` | Dry-run check a file operation |
| `agentfirewall check-network <host>` | Dry-run check a network connection |
| `agentfirewall status` | Show current config, watcher state, and hooks state |
| `agentfirewall watch` | Start real-time filesystem monitoring |
| `agentfirewall install-hooks` | Install shell hooks (bash/zsh) |
| `agentfirewall uninstall-hooks` | Remove shell hooks |
| `agentfirewall sandbox` | Mount FUSE overlay |

### Configuration

User config lives at `.agentfirewall/config.yaml`. Key sections: `mode` (enforce/audit/off), `sandbox`, `filesystem.protected_paths`, `filesystem.deny_operations`, `commands.blocklist`, `network`, `logging`.

### Known Issues

- Shell hooks block `agentfirewall`/`agentwall` commands on older versions — fixed in v0.1.1
- FUSE sandbox requires `fuse3 libfuse-dev` system packages + `pip install agentwall[sandbox]`
- Windows: shell hooks and FUSE don't work — use WSL

## Current State (as of 2026-03-28)

### What's done
- All phases 1–2F complete and smoke tested on Linux
- `protect`/`unprotect` commands built, tested, merged to main
- Bug fixed: shell hook was blocking `agentfirewall` commands (infinite loop) — fixed in v0.1.1
- Published to PyPI as `agentwall` v0.1.1
- New repo: `https://github.com/Wissam-El-Labban/agentwall`
- Simple README written
- AWS VM set up for testing at IP `3.138.173.226` (key: `prad-linux.pem` in Downloads)

### What's in progress
- Testing with a real AI agent (Claude Code) on the AWS VM
- FUSE sandbox installed on VM (`fuse3`, `libfuse-dev`, `agentwall[sandbox]`)
- `agentfirewall protect` confirmed working on VM with v0.1.1

### What's next
1. Test with Claude Code agent on AWS VM — give it destructive tasks and verify blocking
2. Test FUSE sandbox — mount it and verify OS-level blocking
3. Build Phase 3 — Agent discovery (`agentfirewall scan`)
4. Build install.sh — one-line installer that handles FUSE setup automatically

### Repos
- Old repo (full history): `https://github.com/Wissam-El-Labban/llm-security`
- New repo (active): `https://github.com/Wissam-El-Labban/agentwall`
- PyPI: `https://pypi.org/project/agentwall/`

## Development Phases

- **Phase 1–2F** ✅ complete — static rule checker, audit logging, filesystem watcher, process killer, shell hooks, FUSE sandbox
- **Simplification** ✅ complete — `protect`/`unprotect` commands, published to PyPI as `agentwall`
- **Phase 3** (next) — Agent discovery (`agentfirewall scan`)
- **Phase 4** — Web UI dashboard
- **Phase 5** — Network interception (eBPF/iptables)
- **Phase 6** — Agent protocol integration (MCP, LangChain)

See `PLAN.md` for detailed per-phase task breakdowns.
