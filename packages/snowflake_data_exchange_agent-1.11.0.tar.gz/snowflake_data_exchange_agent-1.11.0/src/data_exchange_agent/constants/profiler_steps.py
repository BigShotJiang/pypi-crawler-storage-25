"""
Canonical names for :class:`ExecutionProfiler` steps.

Every step label emitted by the DEA into the profiler's JSON profile
lives here so callers share a single source of truth and downstream
consumers (dashboards, ``QUERY_HISTORY`` joins, analytics) can key on
stable identifiers.

Values are ``kebab-case`` — compact, URL/metric friendly, and easy to
group in log aggregators without quoting.

Usage::

    from data_exchange_agent.constants import profiler_steps

    profiler.step(profiler_steps.COMPARE)
    profiler.record(profiler_steps.FETCH_SOURCE_DATA, elapsed_ms)
"""

# Data export / upload (tasks/manager.py)
RESOLVE_DATA_SOURCE = "resolve-data-source"
EXPORT_DATA = "export-data"
UPLOAD_DATA = "upload-data"

# L1 / L2 schema & metrics validation, L3 cell validation
# (data_validation/handler.py, data_validation/cell_validation.py).
# The fetch steps here represent the single-shot ``SELECT`` that pulls the
# schema rows / metrics rows / cell rows for comparison -- one per side.
FETCH_SOURCE_DATA = "fetch-source-data"
FETCH_TARGET_DATA = "fetch-target-data"
COMPARE = "compare"
UPLOAD_RESULTS = "upload-results"

# L3 cell validation (data_validation/cell_validation.py)
CONVERT_TO_POLARS = "convert-to-polars"
CELL_COMPARISON = "cell-comparison"

# L3 row validation (data_validation/row_validation.py)
# Each label below corresponds to a distinct query site; when more than one
# query is issued at a site (e.g. several MD5-compute CTAS queries, one per
# partition, or one row-extract per chunk), the same label is recorded once
# per query via ``profiler.record`` so the profile preserves fan-out.
OPEN_SOURCE_CONNECTION = "open-source-connection"
FETCH_TARGET_COLUMN_METADATA = "fetch-target-column-metadata"
COUNT_SOURCE_ROWS = "count-source-rows"
COUNT_TARGET_ROWS = "count-target-rows"
COMPUTE_SOURCE_MD5 = "compute-source-md5"
COMPUTE_TARGET_MD5 = "compute-target-md5"
FETCH_SOURCE_CHUNK_ROWS = "fetch-source-chunk-rows"
FETCH_TARGET_CHUNK_ROWS = "fetch-target-chunk-rows"
COMPARE_CHUNKS = "compare-chunks"
