"""
Schema construction from a pyodbc-style ``cursor.description``.

Background
----------
DB-API 2.0 drivers (pyodbc, teradatasql) populate ``cursor.description``
with one 7-tuple per result column right after ``cursor.execute(sql)``::

    (name, type_code, display_size, internal_size, precision, scale, null_ok)

For DECIMAL/NUMERIC columns the ``precision`` and ``scale`` come straight
from the source DDL. For everything else, ``type_code`` is the Python class
the driver returns (``str``, ``bool``, ``int``, ``decimal.Decimal``,
``datetime.datetime``, ...).

The ODBC export path in :mod:`data_exchange_agent.data_sources.odbc_data_source`
uses this metadata to lock the parquet file's schema *before* the first batch
is fetched, instead of letting PyArrow infer types from whatever values
batch 1 happens to contain. That removes the data-dependent failure mode
where:

- a sparse column whose first batch is entirely NULL gets typed as
  ``pa.null()`` and rejects later batches with real values, and
- a DECIMAL column whose first batch only sees small values gets typed
  with narrower precision/scale than the source DDL declares.

Unknown type codes
------------------
Some driver-specific types (geography, hierarchyid, custom UDTs) don't have
a Python class we can map. The mapper signals "unknown" by returning
``None`` for that column so the caller can fall back to per-batch inference
*for that one column* rather than failing the whole table.
"""

from __future__ import annotations

import datetime as dt

from collections.abc import Callable, Sequence
from decimal import Decimal
from typing import Any

import pyarrow as pa


# A pyodbc-style cursor.description entry. The DB-API 2.0 spec defines the
# canonical form as (name, type_code, display_size, internal_size, precision,
# scale, null_ok); we accept any sequence whose first element is the column
# name and read remaining fields by index, so abbreviated forms (e.g. legacy
# unit-test mocks) parse cleanly with missing fields defaulting to None.
ODBCColumnDescription = Sequence[Any]


# Default DECIMAL precision when the driver reports precision=0/None.
# 38 is the maximum of decimal128 and matches the canonical SQL DECIMAL ceiling.
_DEFAULT_DECIMAL_PRECISION = 38


_TYPE_MAP: dict[type, Callable[..., pa.DataType]] = {
    Decimal: pa.decimal128,
    bool: pa.bool_,
    str: pa.string,
    int: pa.int64,
    float: pa.float64,
    bytes: pa.binary,
    dt.datetime: lambda: pa.timestamp("us"),
    dt.date: pa.date32,
    dt.time: lambda: pa.time64("us"),
}


def field_type_from_description(
    type_code: type | None,
    precision: int | None,
    scale: int | None,
) -> pa.DataType | None:
    """
    Resolve a single column's declared type to a ``pa.DataType``.

    Returns ``None`` when the type code is missing or has no mapping, so
    the caller can fall back to per-batch inference for that one column.
    """
    if type_code is None:
        return None

    factory = _TYPE_MAP.get(type_code)
    if factory is None:
        return None

    if type_code is Decimal:
        return factory(precision or _DEFAULT_DECIMAL_PRECISION, scale or 0)

    return factory()


def schema_from_description(
    description: Sequence[ODBCColumnDescription],
) -> tuple[list[pa.DataType | None], list[str]]:
    """
    Build PyArrow types and names from a cursor.description.

    Args:
        description: The ``cursor.description`` value populated by the driver.

    Returns:
        A pair ``(column_types, column_names)``:

        - ``column_types[i]`` is the ``pa.DataType`` for column *i*, or
          ``None`` when the type can't be resolved from description (in
          which case the caller should infer it per batch as a fallback).
        - ``column_names[i]`` is the column name.

    """
    column_types: list[pa.DataType | None] = []
    column_names: list[str] = []
    for entry in description:
        # DB-API 2.0 spec is 7-tuples, but we read defensively in case a
        # caller (e.g. a unit-test mock) passes an abbreviated form.
        # Missing fields fall back to None, which routes the column to
        # per-batch inference.
        name = entry[0]
        type_code = entry[1] if len(entry) > 1 else None
        precision = entry[4] if len(entry) > 4 else None
        scale = entry[5] if len(entry) > 5 else None
        column_names.append(name)
        column_types.append(field_type_from_description(type_code, precision, scale))
    return column_types, column_names
