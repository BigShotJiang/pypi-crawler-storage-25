"""
L3 row-by-row (MD5) validation handler.

Implements the MD5 row validation pipeline for comparing data between a source
database and Snowflake target.

Workflow:
    1. Setup: Parse payload, build table contexts, validate index columns
    2. Compute row-level MD5 hashes on both source and target (chunked for performance)
    3. For each chunk, extract and compare row-level MD5 hashes
    4. Build diff/summary CSV data from comparison results
    5. Upload results to Snowflake stage

The validation determines IS_VALID based on row-level outcomes:
    - No missing rows in either source or target
    - No MD5 hash mismatches between corresponding rows
"""

from __future__ import annotations

import tempfile
import time

from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Any

import pandas as pd

from data_exchange_agent.constants import profiler_steps, task_keys
from data_exchange_agent.tasks.data_validation.helpers import (
    PAYLOAD_CHUNK_NUMBER,
    PAYLOAD_COLUMNS_METADATA,
    PAYLOAD_INDEX_COLUMN_LIST,
    PAYLOAD_MAX_FAILED_ROWS_NUMBER,
    PAYLOAD_RESULT_PIPES,
    PAYLOAD_SOURCE_PLATFORM,
    PAYLOAD_SOURCE_TABLE_FQN,
    PAYLOAD_SOURCE_WHERE_CLAUSE,
    PAYLOAD_TABLE_METADATA_ID,
    PAYLOAD_TABLE_NAME,
    PAYLOAD_TARGET_ID,
    PAYLOAD_TARGET_INDEX_COLUMN_LIST,
    PAYLOAD_TARGET_TABLE_FQN,
    PAYLOAD_TARGET_WHERE_CLAUSE,
    PAYLOAD_WORKFLOW_ID,
    MD5PipelineParams,
    TaskResult,
    build_row_table_context,
    resolve_platform,
)
from data_exchange_agent.tasks.execution_profiler import ExecutionProfiler
from snowflake.snowflake_data_validation.public import (
    ColumnMetadata,
    Origin,
    Platform,
    QueryExecutionResult,
    compare_md5_rows_chunk,
    generate_compute_md5_queries,
    generate_extract_md5_rows_chunk_query,
)
from snowflake.snowflake_data_validation.utils.constants import (
    MAX_CONCAT_LENGTH,
)


if TYPE_CHECKING:
    from data_exchange_agent.tasks.data_validation.handler import (
        DataValidationHandler,
    )


class RowValidationHandler:
    """Encapsulates L3 row-by-row MD5 validation logic."""

    def __init__(self, parent: DataValidationHandler) -> None:
        """Initialize with a reference to the parent handler."""
        self._parent = parent

    @property
    def logger(self):
        """Return the parent handler's logger."""
        return self._parent.logger

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def handle(
        self,
        task: dict[str, Any],
        payload: dict[str, Any],
        *,
        profiler: ExecutionProfiler | None = None,
    ) -> TaskResult:
        """Execute the full MD5 chunk pipeline for row-by-row validation."""
        if profiler is None:
            profiler = ExecutionProfiler()

        table_name = payload.get(PAYLOAD_TABLE_NAME, "unknown")
        workflow_id = payload.get(PAYLOAD_WORKFLOW_ID, 0)
        table_metadata_id = payload.get(PAYLOAD_TABLE_METADATA_ID, 0)
        target_id = payload.get(PAYLOAD_TARGET_ID, "")
        source_platform_str = payload.get(PAYLOAD_SOURCE_PLATFORM, "")
        source_table_fqn = payload.get(PAYLOAD_SOURCE_TABLE_FQN, table_name)
        target_table_fqn = payload.get(PAYLOAD_TARGET_TABLE_FQN, table_name)
        index_column_list = payload.get(PAYLOAD_INDEX_COLUMN_LIST) or []
        target_index_column_list = (
            payload.get(PAYLOAD_TARGET_INDEX_COLUMN_LIST) or index_column_list
        )
        chunk_number = payload.get(PAYLOAD_CHUNK_NUMBER) or 1
        max_failed_rows = payload.get(PAYLOAD_MAX_FAILED_ROWS_NUMBER) or 100
        columns_metadata_raw = payload.get(PAYLOAD_COLUMNS_METADATA) or []
        source_where_clause = payload.get(PAYLOAD_SOURCE_WHERE_CLAUSE) or ""
        target_where_clause = payload.get(PAYLOAD_TARGET_WHERE_CLAUSE) or ""

        if not index_column_list:
            self.logger.error(
                f"Row validation requires index_column_list for {table_name}"
            )
            return {
                task_keys.STATUS: "error",
                task_keys.DETAILS: "Missing index_column_list",
            }

        source_platform = resolve_platform(source_platform_str)

        source_columns_unordered = [
            ColumnMetadata(
                name=c["name"],
                data_type=c["data_type"],
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            )
            for c in columns_metadata_raw
        ]

        profiler.step(profiler_steps.FETCH_TARGET_COLUMN_METADATA)
        target_columns = self._get_target_column_metadata(
            target_table_fqn, source_columns_unordered
        )

        # Reorder source columns to match the target's ordinal-position order
        # so both sides concatenate values in the same sequence.
        target_col_order = {col.name.upper(): i for i, col in enumerate(target_columns)}
        source_columns = sorted(
            source_columns_unordered,
            key=lambda c: target_col_order.get(c.name.upper(), len(target_col_order)),
        )

        self.logger.info(
            f"Starting MD5 row validation for {source_table_fqn} -> {target_table_fqn}"
        )

        profiler.step(profiler_steps.OPEN_SOURCE_CONNECTION)
        source_conn = self._parent._open_source_connection(task)

        # Row counts -- two separate ``SELECT COUNT(*)`` queries run
        # sequentially (target, then source), split so each side's wait is
        # visible as its own step.
        profiler.step(profiler_steps.COUNT_TARGET_ROWS)
        target_count = self._parent._get_target_row_count(
            target_table_fqn, where_clause=target_where_clause
        )
        profiler.step(profiler_steps.COUNT_SOURCE_ROWS)
        source_count = self._parent._get_row_count_on_conn(
            source_conn, source_table_fqn, where_clause=source_where_clause
        )

        if source_count != target_count:
            self.logger.warning(
                f"Row count mismatch: source {source_table_fqn} has {source_count} rows, "
                f"target {target_table_fqn} has {target_count} rows. "
                "Using the larger count for chunk sizing to avoid missing rows."
            )

        row_count = max(source_count, target_count)

        _default_limit = MAX_CONCAT_LENGTH.get(Platform.SNOWFLAKE, 13_421_773)
        effective_concat_limit = min(
            MAX_CONCAT_LENGTH.get(source_platform, _default_limit),
            MAX_CONCAT_LENGTH.get(Platform.SNOWFLAKE, _default_limit),
        )

        source_ctx = build_row_table_context(
            platform=source_platform,
            origin=Origin.SOURCE,
            table_fqn=source_table_fqn,
            columns=source_columns,
            index_column_list=index_column_list,
            chunk_number=chunk_number,
            max_failed_rows_number=max_failed_rows,
            row_count=row_count,
            where_clause=source_where_clause,
            max_concat_length=effective_concat_limit,
        )
        target_ctx = build_row_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.TARGET,
            table_fqn=target_table_fqn,
            columns=target_columns,
            index_column_list=target_index_column_list,
            chunk_number=chunk_number,
            max_failed_rows_number=max_failed_rows,
            row_count=row_count,
            where_clause=target_where_clause,
            max_concat_length=effective_concat_limit,
        )
        if not source_ctx.index_column_collection:
            available = ", ".join(sorted(c.name for c in source_columns)) or "(none)"
            self.logger.error(
                f"No index columns resolved for source {source_table_fqn}: "
                f"index_column_list={index_column_list} does not match any L1 schema "
                f"column. Available columns: {available}."
            )
            return {
                task_keys.STATUS: "error",
                task_keys.DETAILS: (
                    f"index_column_list {index_column_list!r} does not match L1 columns "
                    f"for {source_table_fqn}"
                ),
            }
        if not target_ctx.index_column_collection:
            available = ", ".join(sorted(c.name for c in target_columns)) or "(none)"
            self.logger.error(
                f"No index columns resolved for target {target_table_fqn}: "
                f"target_index_column_list={target_index_column_list}. "
                f"Available columns: {available}."
            )
            return {
                task_keys.STATUS: "error",
                task_keys.DETAILS: (
                    f"target_index_column_list {target_index_column_list!r} does not match "
                    f"target columns for {target_table_fqn}"
                ),
            }
        pipeline_params = MD5PipelineParams(
            source_conn=source_conn,
            source_ctx=source_ctx,
            target_ctx=target_ctx,
            index_column_list=index_column_list,
            target_index_column_list=target_index_column_list,
            source_table_fqn=source_table_fqn,
            target_table_fqn=target_table_fqn,
            table_name=table_name,
            workflow_id=workflow_id,
            table_metadata_id=table_metadata_id,
            target_id=target_id,
            max_failed_rows=max_failed_rows,
            result_pipes=payload.get(PAYLOAD_RESULT_PIPES),
        )
        try:
            return self._run_md5_pipeline(pipeline_params, profiler=profiler)
        finally:
            source_conn.close()

    # ------------------------------------------------------------------
    # MD5 pipeline
    # ------------------------------------------------------------------

    def _run_md5_pipeline(
        self,
        params: MD5PipelineParams,
        *,
        profiler: ExecutionProfiler | None = None,
    ) -> TaskResult:
        """
        Execute the full MD5 pipeline using a persistent source connection.

        Pipeline Steps:
            1. Compute row-level MD5 hashes on source and target (includes table creation)
            2. For each chunk, extract and compare row-level MD5 hashes
            3. Build diffs/summary CSV data
            4. Upload results to Snowflake stage

        Args:
            params: Pipeline parameters including connections, contexts, and metadata.
            profiler: Optional execution profiler for recording step durations.

        Returns:
            TaskResult with status, details, and total diff count.

        """
        if profiler is None:
            profiler = ExecutionProfiler()

        source_conn = params.source_conn
        source_ctx = params.source_ctx
        target_ctx = params.target_ctx
        index_column_list = params.index_column_list
        target_index_column_list = params.target_index_column_list
        source_table_fqn = params.source_table_fqn
        target_table_fqn = params.target_table_fqn
        table_name = params.table_name
        workflow_id = params.workflow_id
        table_metadata_id = params.table_metadata_id
        target_id = params.target_id
        max_failed_rows = params.max_failed_rows
        result_pipes = params.result_pipes

        src_idx_cols = [col.upper() + "_SOURCE" for col in index_column_list]
        tgt_idx_cols = [col.upper() + "_TARGET" for col in target_index_column_list]

        # Step 1: Compute MD5 hashes on both sides (includes table creation)
        num_cols = len(source_ctx.columns_to_validate)
        if source_ctx.use_column_groups:
            num_groups = len(source_ctx.column_groups)
            group_sizes = ", ".join(str(len(g)) for g in source_ctx.column_groups)
            self.logger.info(
                f"Chunked MD5 active for {table_name}: {num_cols} columns split "
                f"into {num_groups} groups [{group_sizes}] "
                f"(source={source_ctx.platform.value}, "
                f"target={target_ctx.platform.value})"
            )
        else:
            self.logger.info(
                f"Chunked MD5 not needed for {table_name}: {num_cols} columns "
                f"fit in a single group"
            )

        src_compute_queries = generate_compute_md5_queries(
            source_ctx,
            target_ctx.table_name,
        )
        tgt_compute_queries = generate_compute_md5_queries(
            target_ctx,
            source_ctx.table_name,
        )

        # Close any active step so the parallel MD5 compute block below
        # doesn't double-count each ``record`` against a wrapping ``step``.
        # Python-only work between here and the first ``record`` call
        # (query-string generation above) is negligible.
        profiler.finish()

        def _compute_source():
            for q in src_compute_queries:
                t0 = time.monotonic()
                self._parent._execute_source_statement_on_conn(
                    source_conn, q.query_string
                )
                profiler.record(
                    profiler_steps.COMPUTE_SOURCE_MD5,
                    int((time.monotonic() - t0) * 1000),
                )

        with ThreadPoolExecutor(max_workers=1) as pool:
            src_future = pool.submit(_compute_source)
            for q in tgt_compute_queries:
                t0 = time.monotonic()
                self._parent._execute_target_statement(q.query_string)
                profiler.record(
                    profiler_steps.COMPUTE_TARGET_MD5,
                    int((time.monotonic() - t0) * 1000),
                )
            try:
                src_future.result()
            except Exception as exc:
                self.logger.error(
                    f"Source MD5 computation failed for {table_name}: {exc}"
                )
                raise

        # Get chunk IDs computed during MD5 generation
        chunk_ids = source_ctx.computed_chunk_ids
        total_chunks = len(chunk_ids)

        if total_chunks == 0:
            self.logger.warning(
                f"No chunks computed for {table_name}, writing empty results"
            )
            self._write_empty_row_results(
                workflow_id,
                table_metadata_id,
                table_name,
                target_table_fqn,
                target_id,
                result_pipes=result_pipes,
            )
            return {
                task_keys.STATUS: "success",
                task_keys.DETAILS: f"Row validation: no chunk data for {table_name}",
            }

        self.logger.info(f"Comparing {total_chunks} chunks for {table_name}")

        # Per-chunk fetch durations are recorded individually below via
        # ``profiler.record`` (one entry per side per chunk). The accumulator
        # here captures only the in-memory diff work so ``COMPARE_CHUNKS`` is
        # a pure computation metric, not a mixed I/O+compute bucket.
        compare_ms_total = 0

        # Step 2: Compare rows for each chunk
        all_diffs: list[pd.DataFrame] = []
        total_rows_compared = 0
        rows_not_found_in_target = 0
        rows_not_found_in_source = 0
        rows_with_differences = 0
        chunks_with_differences = 0

        def _timed_source_fetch(query_string: str) -> tuple[pd.DataFrame, int]:
            """Run a source row-extract query, returning dataframe + elapsed ms."""
            t0 = time.monotonic()
            df = self._parent._run_source_query_on_conn(source_conn, query_string)
            return df, int((time.monotonic() - t0) * 1000)

        with ThreadPoolExecutor(max_workers=1) as pool:
            for chunk_id in chunk_ids:
                if not chunk_id:
                    continue

                self.logger.info(f"Comparing chunk {chunk_id}")
                src_rows_query = generate_extract_md5_rows_chunk_query(
                    chunk_id, source_ctx
                )
                tgt_rows_query = generate_extract_md5_rows_chunk_query(
                    chunk_id, target_ctx
                )

                src_future = pool.submit(
                    _timed_source_fetch, src_rows_query.query_string
                )

                tgt_t0 = time.monotonic()
                tgt_rows_df = self._parent._run_target_query(
                    tgt_rows_query.query_string
                )
                profiler.record(
                    profiler_steps.FETCH_TARGET_CHUNK_ROWS,
                    int((time.monotonic() - tgt_t0) * 1000),
                )

                try:
                    src_rows_df, src_ms = src_future.result()
                except Exception as exc:
                    self.logger.error(
                        f"Source row extraction failed for {table_name} chunk {chunk_id}: {exc}"
                    )
                    raise
                profiler.record(profiler_steps.FETCH_SOURCE_CHUNK_ROWS, src_ms)

                cmp_t0 = time.monotonic()
                src_rows_df = src_rows_df.convert_dtypes().rename(
                    columns=lambda x: x.upper() + "_SOURCE"
                )
                tgt_rows_df = tgt_rows_df.convert_dtypes().rename(
                    columns=lambda x: x.upper() + "_TARGET"
                )

                src_rows_result = QueryExecutionResult(dataframe=src_rows_df)
                tgt_rows_result = QueryExecutionResult(dataframe=tgt_rows_df)

                row_diff = compare_md5_rows_chunk(
                    src_rows_result,
                    tgt_rows_result,
                    src_idx_cols,
                    tgt_idx_cols,
                    source_ctx,
                )

                total_rows_compared += len(src_rows_df) + len(tgt_rows_df)

                reached_cap = False
                if not row_diff.results_dataframe.empty:
                    chunks_with_differences += 1
                    diff_df = row_diff.results_dataframe
                    counts = diff_df["RESULT"].value_counts()
                    rows_not_found_in_target += int(counts.get("NOT_FOUND_TARGET", 0))
                    rows_not_found_in_source += int(counts.get("NOT_FOUND_SOURCE", 0))
                    rows_with_differences += int(counts.get("FAILURE", 0))
                    all_diffs.append(diff_df)
                    if sum(len(d) for d in all_diffs) >= max_failed_rows:
                        reached_cap = True

                compare_ms_total += int((time.monotonic() - cmp_t0) * 1000)

                if reached_cap:
                    self.logger.info(
                        f"Reached max_failed_rows ({max_failed_rows}), stopping comparison"
                    )
                    break

        # Step 3: Build diffs CSV -- also in-memory compute, count it too.
        cmp_t0 = time.monotonic()
        diffs_data: list[list] = []
        if all_diffs:
            combined = pd.concat(all_diffs, ignore_index=True)
            src_parts = [
                combined[col]
                .fillna("N/A")
                .astype(str)
                .radd(f"{col.replace('_SOURCE', '')}=")
                for col in src_idx_cols
            ]
            tgt_parts = [
                combined[col]
                .fillna("N/A")
                .astype(str)
                .radd(f"{col.replace('_TARGET', '')}=")
                for col in tgt_idx_cols
            ]
            src_vals_series = (
                src_parts[0].str.cat(src_parts[1:], sep=", ")
                if src_parts
                else pd.Series("", index=combined.index)
            )
            tgt_vals_series = (
                tgt_parts[0].str.cat(tgt_parts[1:], sep=", ")
                if tgt_parts
                else pd.Series("", index=combined.index)
            )

            diffs_out = pd.DataFrame(
                {
                    "source_fqn": source_table_fqn,
                    "object_type": "TABLE",
                    "result": combined["RESULT"].fillna(""),
                    "src_vals": src_vals_series,
                    "tgt_vals": tgt_vals_series,
                    "target_fqn": target_table_fqn,
                }
            )
            diffs_data = diffs_out.values.tolist()

        total_diff_rows = sum(len(d) for d in all_diffs)
        matching_chunks = total_chunks - chunks_with_differences

        # IS_VALID is true when no row-level issues are found
        row_level_has_issues = (
            total_diff_rows > 0
            or rows_not_found_in_target > 0
            or rows_not_found_in_source > 0
        )
        summary_is_valid = not row_level_has_issues

        summary_data = [
            [
                table_name,
                total_chunks,
                matching_chunks,
                chunks_with_differences,
                total_rows_compared,
                rows_not_found_in_target,
                rows_not_found_in_source,
                rows_with_differences,
                summary_is_valid,
            ]
        ]

        compare_ms_total += int((time.monotonic() - cmp_t0) * 1000)
        profiler.record(profiler_steps.COMPARE_CHUNKS, compare_ms_total)

        # Step 4: Write and upload CSVs
        profiler.step(profiler_steps.UPLOAD_RESULTS)
        temp_dir = tempfile.mkdtemp()

        diffs_path = self._parent._write_l3_csv(
            temp_dir, "diffs.csv", diffs_data, workflow_id, table_metadata_id
        )
        summary_path = self._parent._write_l3_csv(
            temp_dir, "summary.csv", summary_data, workflow_id, table_metadata_id
        )

        self._parent._upload_to_stage(diffs_path, f"{target_id}/diffs")
        self._parent._upload_to_stage(summary_path, f"{target_id}/summary")
        self._parent._refresh_result_pipes(result_pipes)

        self._parent._cleanup_temp_dir(temp_dir)
        profiler.finish()

        self.logger.info(
            f"Row validation complete for {table_name}: "
            f"{total_chunks} chunks, {chunks_with_differences} with differences, "
            f"{total_diff_rows} row diffs"
        )
        return {
            task_keys.STATUS: "success",
            task_keys.DETAILS: (
                f"Row validation: {total_diff_rows} diffs in "
                f"{chunks_with_differences}/{total_chunks} chunks"
            ),
            task_keys.TOTAL: total_diff_rows,
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _write_empty_row_results(
        self,
        workflow_id: int,
        table_metadata_id: int,
        table_name: str,
        target_table_fqn: str,
        target_id: str,
        result_pipes: list[dict[str, Any]] | None = None,
    ) -> None:
        """Write empty CSV files for row validation when no data is available."""
        temp_dir = tempfile.mkdtemp()
        empty_diffs = self._parent._write_l3_csv(
            temp_dir, "diffs.csv", [], workflow_id, table_metadata_id
        )
        empty_summary = self._parent._write_l3_csv(
            temp_dir,
            "summary.csv",
            [[table_name, 0, 0, 0, 0, 0, 0, 0, True]],
            workflow_id,
            table_metadata_id,
        )

        self._parent._upload_to_stage(empty_diffs, f"{target_id}/diffs")
        self._parent._upload_to_stage(empty_summary, f"{target_id}/summary")
        self._parent._refresh_result_pipes(result_pipes)
        self._parent._cleanup_temp_dir(temp_dir)

    def _get_target_column_metadata(
        self,
        target_table_fqn: str,
        fallback_columns: list[ColumnMetadata],
    ) -> list[ColumnMetadata]:
        """Query Snowflake information_schema for the target table's native column types."""
        parts = target_table_fqn.split(".")
        if len(parts) == 3:
            tgt_db, tgt_schema, tgt_table = parts
        elif len(parts) == 2:
            tgt_db, tgt_schema, tgt_table = "", parts[0], parts[1]
        else:
            return fallback_columns

        prefix = f"{tgt_db}." if tgt_db else ""
        query = (
            f"SELECT column_name, data_type "
            f"FROM {prefix}information_schema.columns "
            f"WHERE table_schema = '{tgt_schema.upper()}' "
            f"AND table_name = '{tgt_table.upper()}' "
            f"ORDER BY ordinal_position"
        )
        try:
            df = self._parent._run_target_query(query)
            if df.empty:
                self.logger.warning(
                    f"No columns found in information_schema for {target_table_fqn}, "
                    "falling back to source column types"
                )
                return fallback_columns

            columns = []
            for _, row in df.iterrows():
                col_name = row.get("COLUMN_NAME", row.get("column_name", ""))
                data_type = row.get("DATA_TYPE", row.get("data_type", ""))
                if col_name and data_type:
                    columns.append(
                        ColumnMetadata(
                            name=col_name,
                            data_type=data_type,
                            nullable=True,
                            is_primary_key=False,
                            calculated_column_size_in_bytes=0,
                            properties={},
                        )
                    )
            return columns if columns else fallback_columns
        except Exception as e:
            self.logger.warning(
                f"Failed to get target column metadata for {target_table_fqn}: {e}, "
                "falling back to source column types"
            )
            return fallback_columns
