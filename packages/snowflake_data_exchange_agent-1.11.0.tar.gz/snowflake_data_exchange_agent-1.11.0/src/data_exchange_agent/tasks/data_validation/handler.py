"""
Main data validation handler for the DEA.

Routes incoming ``data_validation`` tasks to the appropriate validation
strategy (schema, metrics, row-by-row, cell-by-cell) and provides shared
utilities for query execution and result I/O.
"""

import csv
import os
import shutil
import tempfile
import time

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import pandas as pd

from data_exchange_agent.constants import profiler_steps, task_keys
from data_exchange_agent.data_sources.database_engines import (
    get_database_engine_from_string,
)
from data_exchange_agent.data_sources.odbc_output_converters import (
    register_output_converters,
)
from data_exchange_agent.data_sources.sf_connection import SnowflakeDataSource
from data_exchange_agent.data_sources.teradata_connection import (
    DBAPIConnection,
    is_pyodbc_connection,
    open_source_connection,
)
from data_exchange_agent.tasks.data_validation.helpers import (
    COL_COLUMN_VALIDATED,
    CSV_DELIMITER,
    PAYLOAD_COLUMN_MAPPINGS,
    PAYLOAD_DATATYPES_MAPPINGS,
    PAYLOAD_PARTITION_NUMBER,
    PAYLOAD_RESULT_PIPES,
    PAYLOAD_ROW_VALIDATION_MODE,
    PAYLOAD_SOURCE_PLATFORM,
    PAYLOAD_SOURCE_QUERY,
    PAYLOAD_SOURCE_QUERY_BATCHES,
    PAYLOAD_TABLE_METADATA_ID,
    PAYLOAD_TABLE_NAME,
    PAYLOAD_TARGET_ID,
    PAYLOAD_TARGET_QUERY,
    PAYLOAD_TARGET_QUERY_BATCHES,
    PAYLOAD_TOLERANCE,
    PAYLOAD_USE_DATABASE_COMMAND,
    PAYLOAD_VALIDATION_TYPE,
    PAYLOAD_WORKFLOW_ID,
    RESULT_PIPE_NAME_KEY,
    RESULT_PIPE_STAGE_PREFIX_KEY,
    VALIDATION_TYPE_METRICS,
    VALIDATION_TYPE_ROW,
    VALIDATION_TYPE_SCHEMA,
    TaskResult,
    adapt_sdv_result,
    build_table_context,
    load_datatypes_mappings,
    resolve_platform,
)
from data_exchange_agent.tasks.execution_profiler import ExecutionProfiler
from data_exchange_agent.utils.sf_logger import SFLogger
from snowflake.snowflake_data_validation.public import (
    QueryExecutionResult,
    validate_metrics,
    validate_schema,
)


_FETCH_BATCH_SIZE = 20_000

if TYPE_CHECKING:
    from data_exchange_agent.config.sections.connections.odbc.base import (
        BaseODBCConnectionConfig,
    )


@dataclass(frozen=True, slots=True)
class FetchResult:
    """
    Outcome of fetching one side (source or target) of a validation.

    ``elapsed_ms`` is measured inside the worker thread, so it reflects the
    actual fetch duration regardless of which side finishes first when
    source and target are fetched concurrently.
    """

    dataframe: pd.DataFrame
    elapsed_ms: int


class DataValidationHandler:
    """Handle ``data_validation`` tasks."""

    def __init__(
        self,
        logger: SFLogger,
        snowflake_datasource: SnowflakeDataSource,
        source_connections_config: dict[str, "BaseODBCConnectionConfig"],
        query_tag: str | None = None,
    ) -> None:
        """Initialize the handler with shared dependencies."""
        self.logger = logger
        self.snowflake_datasource = snowflake_datasource
        self.source_connections_config = source_connections_config
        self._query_tag = query_tag

        from data_exchange_agent.tasks.data_validation.cell_validation import (
            CellValidationHandler,
        )
        from data_exchange_agent.tasks.data_validation.row_validation import (
            RowValidationHandler,
        )

        self._row_validator = RowValidationHandler(self)
        self._cell_validator = CellValidationHandler(self)

    def _resolve_source_engine_config_key(self, engine_raw: str) -> str:
        """Map payload ``source_platform`` (e.g. ``Teradata``, ``SqlServer``) to TOML keys."""
        raw = (engine_raw or "").strip()
        if not raw:
            raise ValueError(
                "source_platform is empty; cannot select a source connection. "
                f"Available: {list(self.source_connections_config.keys())}"
            )
        try:
            key = get_database_engine_from_string(raw).value
        except ValueError as e:
            raise ValueError(
                f"Unsupported source_platform={raw!r}. "
                f"Configured sources: {list(self.source_connections_config.keys())}"
            ) from e
        if key not in self.source_connections_config:
            raise ValueError(
                f"Engine '{raw}' (normalized: '{key}') not found in source connections. "
                f"Available: {list(self.source_connections_config.keys())}"
            )
        return key

    def _ensure_query_tag(self) -> None:
        """
        Apply the task-level query tag on the current thread's connection.

        Called before every Snowflake query so that ThreadPoolExecutor
        threads (which get fresh connections) carry the correct tag.
        """
        if self._query_tag is not None:
            self.snowflake_datasource.set_query_tag(self._query_tag)

    # ------------------------------------------------------------------
    # Task routing
    # ------------------------------------------------------------------

    def handle(
        self, task: dict[str, Any], profiler: ExecutionProfiler | None = None
    ) -> TaskResult:
        """Process a data_validation task."""
        if profiler is None:
            profiler = ExecutionProfiler()

        payload = task.get(task_keys.PAYLOAD, task)
        validation_type = payload.get(PAYLOAD_VALIDATION_TYPE, "")
        table_name = payload.get(PAYLOAD_TABLE_NAME, "unknown")
        workflow_id = payload.get(PAYLOAD_WORKFLOW_ID, 0)
        table_metadata_id = payload.get(PAYLOAD_TABLE_METADATA_ID, 0)
        source_query = payload.get(PAYLOAD_SOURCE_QUERY, "")
        target_query = payload.get(PAYLOAD_TARGET_QUERY, "")
        target_id = payload.get(PAYLOAD_TARGET_ID, "")
        column_mappings = payload.get(PAYLOAD_COLUMN_MAPPINGS) or {}
        datatypes_mappings = payload.get(PAYLOAD_DATATYPES_MAPPINGS) or {}
        tolerance = payload.get(PAYLOAD_TOLERANCE, 0.001)
        source_platform_str = payload.get(PAYLOAD_SOURCE_PLATFORM, "")
        partition_number = payload.get(PAYLOAD_PARTITION_NUMBER)

        self.logger.info(
            f"Processing data_validation task: type={validation_type}, "
            f"table={table_name}, workflow={workflow_id}"
        )

        try:
            if validation_type == VALIDATION_TYPE_ROW:
                row_mode = payload.get(PAYLOAD_ROW_VALIDATION_MODE, "row")
                if row_mode == "cell":
                    return self._cell_validator.handle(task, payload, profiler=profiler)
                return self._row_validator.handle(task, payload, profiler=profiler)

            if validation_type not in (VALIDATION_TYPE_SCHEMA, VALIDATION_TYPE_METRICS):
                raise ValueError(f"Unknown validation_type: {validation_type}")

            source_batches = payload.get(PAYLOAD_SOURCE_QUERY_BATCHES)
            target_batches = payload.get(PAYLOAD_TARGET_QUERY_BATCHES)

            if source_batches and target_batches:
                source_fetch, target_fetch = self._run_batched_queries(
                    source_batches,
                    target_batches,
                    task,
                )
            else:
                with ThreadPoolExecutor(max_workers=2) as pool:
                    source_future = pool.submit(
                        self._timed_source_query, source_query, task
                    )
                    target_future = pool.submit(self._timed_target_query, target_query)
                    source_fetch = source_future.result()
                    target_fetch = target_future.result()
            profiler.record(profiler_steps.FETCH_SOURCE_DATA, source_fetch.elapsed_ms)
            profiler.record(profiler_steps.FETCH_TARGET_DATA, target_fetch.elapsed_ms)
            source_df = source_fetch.dataframe
            target_df = target_fetch.dataframe

            if COL_COLUMN_VALIDATED in source_df.columns:
                source_df = source_df.copy()
                source_df[COL_COLUMN_VALIDATED] = source_df[
                    COL_COLUMN_VALIDATED
                ].str.upper()
            if COL_COLUMN_VALIDATED in target_df.columns:
                target_df = target_df.copy()
                target_df[COL_COLUMN_VALIDATED] = target_df[
                    COL_COLUMN_VALIDATED
                ].str.upper()

            source_platform = resolve_platform(source_platform_str)
            table_ctx = build_table_context(source_platform, table_name)

            if not datatypes_mappings:
                datatypes_mappings = load_datatypes_mappings(source_platform)

            profiler.step(profiler_steps.COMPARE)
            if validation_type == VALIDATION_TYPE_SCHEMA:
                result_df = self._validate_schema_sdv(
                    source_df,
                    target_df,
                    table_ctx,
                    column_mappings,
                    datatypes_mappings,
                    table_name,
                )
            else:
                result_df = self._validate_metrics_sdv(
                    source_df,
                    target_df,
                    table_ctx,
                    column_mappings,
                    tolerance,
                    table_name,
                )

            profiler.step(profiler_steps.UPLOAD_RESULTS)
            csv_path = self._write_result_csv(
                result_df,
                workflow_id,
                table_metadata_id,
                partition_number=partition_number,
            )
            self._upload_to_stage(csv_path, target_id)
            self._refresh_result_pipes(payload.get(PAYLOAD_RESULT_PIPES))
            self._cleanup_temp_dir(os.path.dirname(csv_path))
            profiler.finish()

            self.logger.info(
                f"Validation complete for {table_name}: "
                f"{len(result_df)} result rows uploaded to {target_id}"
            )

            return {
                task_keys.STATUS: "success",
                task_keys.DETAILS: f"Validated {table_name} ({validation_type})",
                task_keys.TOTAL: len(result_df),
            }

        except Exception as e:
            profiler.finish()
            self.logger.error(
                f"Data validation failed for {table_name}: {e}",
                exception=e,
            )
            return {
                task_keys.STATUS: "error",
                task_keys.DETAILS: str(e),
            }

    # ------------------------------------------------------------------
    # Batched query execution (column-batching for wide tables)
    # ------------------------------------------------------------------

    def _run_batched_queries(
        self,
        source_batches: list[str],
        target_batches: list[str],
        task: dict[str, Any],
    ) -> tuple[FetchResult, FetchResult]:
        """
        Execute multiple query batches and concatenate results.

        Each (source, target) pair is executed in parallel, then all
        partial DataFrames are concatenated into one source and one target
        DataFrame for downstream validation.

        Returns aggregate ``FetchResult`` values for source and target, with
        ``elapsed_ms`` being the sum of per-batch durations on each side.
        Per-batch timing is measured inside each worker thread so the
        numbers reflect actual fetch durations regardless of which side
        finishes first.
        """
        source_frames: list[pd.DataFrame] = []
        target_frames: list[pd.DataFrame] = []
        total_source_ms = 0
        total_target_ms = 0

        for idx, (src_q, tgt_q) in enumerate(
            zip(source_batches, target_batches, strict=False),
        ):
            self.logger.info(f"Executing metrics batch {idx + 1}/{len(source_batches)}")
            with ThreadPoolExecutor(max_workers=2) as pool:
                src_future = pool.submit(self._timed_source_query, src_q, task)
                tgt_future = pool.submit(self._timed_target_query, tgt_q)
                src_fetch = src_future.result()
                tgt_fetch = tgt_future.result()
                source_frames.append(src_fetch.dataframe)
                target_frames.append(tgt_fetch.dataframe)
                total_source_ms += src_fetch.elapsed_ms
                total_target_ms += tgt_fetch.elapsed_ms

        source_df = (
            pd.concat(source_frames, ignore_index=True)
            if source_frames
            else pd.DataFrame()
        )
        target_df = (
            pd.concat(target_frames, ignore_index=True)
            if target_frames
            else pd.DataFrame()
        )
        return (
            FetchResult(dataframe=source_df, elapsed_ms=total_source_ms),
            FetchResult(dataframe=target_df, elapsed_ms=total_target_ms),
        )

    # ------------------------------------------------------------------
    # L1/L2 validation via SDV
    # ------------------------------------------------------------------

    def _validate_schema_sdv(
        self,
        source_df: pd.DataFrame,
        target_df: pd.DataFrame,
        table_ctx: Any,
        column_mappings: dict[str, str],
        datatypes_mappings: dict[str, str],
        table_name: str,
    ) -> pd.DataFrame:
        """Delegate schema validation to the SDV library."""
        if COL_COLUMN_VALIDATED in source_df.columns:
            source_df = source_df.copy()
            source_df[COL_COLUMN_VALIDATED] = source_df[
                COL_COLUMN_VALIDATED
            ].str.upper()
        if COL_COLUMN_VALIDATED in target_df.columns:
            target_df = target_df.copy()
            target_df[COL_COLUMN_VALIDATED] = target_df[
                COL_COLUMN_VALIDATED
            ].str.upper()

        src_result = QueryExecutionResult(dataframe=source_df)
        tgt_result = QueryExecutionResult(dataframe=target_df)

        validation = validate_schema(
            source_query_result=src_result,
            target_query_result=tgt_result,
            table_context=table_ctx,
            column_mappings=column_mappings,
            datatypes_mappings=datatypes_mappings,
        )

        self.logger.info(
            f"SDV schema validation for {table_name}: "
            f"is_valid={validation.is_valid}, rows={len(validation.results_dataframe)}"
        )
        return adapt_sdv_result(validation.results_dataframe, table_name)

    def _validate_metrics_sdv(
        self,
        source_df: pd.DataFrame,
        target_df: pd.DataFrame,
        table_ctx: Any,
        column_mappings: dict[str, str],
        tolerance: float,
        table_name: str,
    ) -> pd.DataFrame:
        """Delegate metrics validation to the SDV library."""
        src_result = QueryExecutionResult(dataframe=source_df)
        tgt_result = QueryExecutionResult(dataframe=target_df)

        validation = validate_metrics(
            source_query_result=src_result,
            target_query_result=tgt_result,
            table_context=table_ctx,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        self.logger.info(
            f"SDV metrics validation for {table_name}: "
            f"is_valid={validation.is_valid}, rows={len(validation.results_dataframe)}"
        )
        return adapt_sdv_result(validation.results_dataframe, table_name)

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    def _timed_source_query(self, query: str, task: dict[str, Any]) -> FetchResult:
        """
        Run a source query and return a :class:`FetchResult`.

        Timing is captured inside the worker thread so it reflects the
        actual fetch duration even when running concurrently with the
        target query.
        """
        t0 = time.monotonic()
        df = self._run_source_query(query, task)
        return FetchResult(
            dataframe=df,
            elapsed_ms=int((time.monotonic() - t0) * 1000),
        )

    def _timed_target_query(self, query: str) -> FetchResult:
        """
        Run a target query and return a :class:`FetchResult`.

        Timing is captured inside the worker thread so it reflects the
        actual fetch duration even when running concurrently with the
        source query.
        """
        t0 = time.monotonic()
        df = self._run_target_query(query)
        return FetchResult(
            dataframe=df,
            elapsed_ms=int((time.monotonic() - t0) * 1000),
        )

    def _run_source_query(self, query: str, task: dict[str, Any]) -> pd.DataFrame:
        """Run a query against the source database."""
        if not query:
            return pd.DataFrame()

        payload = task.get(task_keys.PAYLOAD, task)
        engine_raw = payload.get(PAYLOAD_SOURCE_PLATFORM, "")
        engine_key = self._resolve_source_engine_config_key(engine_raw)
        use_database_command = payload.get(PAYLOAD_USE_DATABASE_COMMAND)

        config = self.source_connections_config[engine_key]
        conn = open_source_connection(engine_key, config)

        if is_pyodbc_connection(conn):
            register_output_converters(conn)

        self.logger.info(
            f"Opening source connection for engine '{engine_raw}' (config key '{engine_key}')"
        )

        try:
            if use_database_command:
                cursor = conn.cursor()
                cursor.execute(use_database_command)
                cursor.close()

            cursor = conn.cursor()
            self.logger.info(f"Executing source query: {query[:200]}...")
            cursor.execute(query)
            columns = [desc[0].upper() for desc in cursor.description]

            batches: list[pd.DataFrame] = []
            while True:
                rows = cursor.fetchmany(_FETCH_BATCH_SIZE)
                if not rows:
                    break
                batches.append(pd.DataFrame.from_records(rows, columns=columns))
            cursor.close()

            if batches:
                return pd.concat(batches, ignore_index=True)
            return pd.DataFrame(columns=columns)
        finally:
            conn.close()

    def _run_target_query(self, query: str) -> pd.DataFrame:
        """Run a query against the target Snowflake database."""
        if not query:
            return pd.DataFrame()
        self._ensure_query_tag()
        with self.snowflake_datasource.get_cursor(dict_cursor=False) as cursor:
            self.logger.info(f"Executing target query: {query[:200]}...")
            cursor.execute(query)
            columns = [desc[0] for desc in cursor.description]

            batches: list[pd.DataFrame] = []
            while True:
                rows = cursor.fetchmany(_FETCH_BATCH_SIZE)
                if not rows:
                    break
                batches.append(pd.DataFrame(rows, columns=columns))

            result = (
                pd.concat(batches, ignore_index=True)
                if batches
                else pd.DataFrame(columns=columns)
            )
            self.logger.info(
                f"Target query returned {len(result)} rows, columns={columns}"
            )
            return result

    def _open_source_connection(self, task: dict[str, Any]) -> DBAPIConnection:
        """Open and return a persistent connection to the source database."""
        payload = task.get(task_keys.PAYLOAD, task)
        engine_raw = payload.get(PAYLOAD_SOURCE_PLATFORM, "")
        engine_key = self._resolve_source_engine_config_key(engine_raw)
        use_database_command = payload.get(PAYLOAD_USE_DATABASE_COMMAND)

        config = self.source_connections_config[engine_key]
        conn = open_source_connection(engine_key, config)

        if is_pyodbc_connection(conn):
            register_output_converters(conn)

        if use_database_command:
            cursor = conn.cursor()
            cursor.execute(use_database_command)
            cursor.close()

        return conn

    def _execute_source_statement_on_conn(
        self, conn: DBAPIConnection, statement: str
    ) -> None:
        """Execute a DDL/DML statement against the source using an existing connection."""
        cursor = conn.cursor()
        self.logger.info(f"Executing source statement: {statement[:200]}...")
        cursor.execute(statement)
        cursor.close()

    def _run_source_query_on_conn(
        self, conn: DBAPIConnection, query: str
    ) -> pd.DataFrame:
        """Run a query against the source using an existing connection."""
        cursor = conn.cursor()
        self.logger.info(f"Executing source query: {query[:200]}...")
        cursor.execute(query)
        columns = [desc[0].upper() for desc in cursor.description]

        batches: list[pd.DataFrame] = []
        while True:
            rows = cursor.fetchmany(_FETCH_BATCH_SIZE)
            if not rows:
                break
            batches.append(pd.DataFrame.from_records(rows, columns=columns))
        cursor.close()

        return (
            pd.concat(batches, ignore_index=True)
            if batches
            else pd.DataFrame(columns=columns)
        )

    def _execute_target_statement(self, statement: str) -> None:
        """Execute a DDL/DML statement against the Snowflake target."""
        self._ensure_query_tag()
        with self.snowflake_datasource.get_cursor(dict_cursor=False) as cursor:
            self.logger.info(f"Executing target statement: {statement[:200]}...")
            cursor.execute(statement)

    def _get_row_count_on_conn(
        self,
        conn: DBAPIConnection,
        table_fqn: str,
        where_clause: str = "",
    ) -> int:
        """Get the row count of a source table using an existing source connection."""
        query = f"SELECT COUNT(*) FROM {table_fqn}"
        if where_clause:
            query += f" WHERE {where_clause}"
        cursor = conn.cursor()
        cursor.execute(query)
        row = cursor.fetchone()
        cursor.close()
        return int(row[0]) if row else 0

    def _get_target_row_count(self, table_fqn: str, where_clause: str = "") -> int:
        """Get the row count of a target Snowflake table."""
        self._ensure_query_tag()
        query = f"SELECT COUNT(*) FROM {table_fqn}"
        if where_clause:
            query += f" WHERE {where_clause}"
        with self.snowflake_datasource.get_cursor(dict_cursor=False) as cursor:
            cursor.execute(query)
            row = cursor.fetchone()
            return int(row[0]) if row else 0

    # ------------------------------------------------------------------
    # Result output
    # ------------------------------------------------------------------

    def _write_result_csv(
        self,
        result_df: pd.DataFrame,
        workflow_id: int,
        table_metadata_id: int,
        *,
        partition_number: int | None = None,
    ) -> str:
        """Write results to CSV with orchestration columns prepended."""
        temp_dir = tempfile.mkdtemp()
        csv_path = os.path.join(temp_dir, "validation_result.csv")

        prefix = [workflow_id, table_metadata_id]
        if partition_number is not None:
            prefix.append(partition_number)

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f, delimiter=CSV_DELIMITER)
            for _, row in result_df.iterrows():
                writer.writerow([*prefix, *row.values])

        return csv_path

    def _write_l3_csv(
        self,
        temp_dir: str,
        filename: str,
        data_rows: list[list],
        workflow_id: int,
        table_metadata_id: int,
    ) -> str:
        """Write an L3 CSV file with workflow/table_metadata_id prepended to each row."""
        csv_path = os.path.join(temp_dir, filename)
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f, delimiter=CSV_DELIMITER)
            for row in data_rows:
                writer.writerow([workflow_id, table_metadata_id, *row])
        return csv_path

    @staticmethod
    def _cleanup_temp_dir(temp_dir: str) -> None:
        """Remove a temporary directory and all its contents."""
        shutil.rmtree(temp_dir, ignore_errors=True)

    def _upload_to_stage(self, local_path: str, stage_path: str) -> None:
        """Upload a local file to a Snowflake stage."""
        self._ensure_query_tag()
        with self.snowflake_datasource.get_cursor(dict_cursor=False) as cursor:
            put_command = f"PUT 'file://{local_path}' '{stage_path}/' AUTO_COMPRESS=TRUE OVERWRITE=TRUE"
            cursor.execute(put_command)
            self.logger.info(f"Uploaded validation results to {stage_path}")

    def _refresh_result_pipes(self, result_pipes: list[dict[str, Any]] | None) -> None:
        """
        Issue ``ALTER PIPE REFRESH PREFIX=...`` for each Snowpipe in the payload.

        When the orchestrator ran in Snowpipe mode, it attached one entry
        per destination results table. Each prefix is scoped to this DEA
        task's stage sub-directory so that the refresh only enqueues
        freshly uploaded files.

        Failures are logged but do not abort the task: the orchestrator's
        drain task will ultimately surface any Snowpipe-side problem, and
        duplicate REFRESH calls are safe because Snowpipe dedupes by file
        metadata.
        """
        if not result_pipes:
            return
        self._ensure_query_tag()
        with self.snowflake_datasource.get_cursor(dict_cursor=False) as cursor:
            for entry in result_pipes:
                pipe_name = entry.get(RESULT_PIPE_NAME_KEY)
                stage_prefix = entry.get(RESULT_PIPE_STAGE_PREFIX_KEY)
                if not pipe_name or stage_prefix is None:
                    self.logger.warning(
                        f"Skipping result pipe entry with missing fields: {entry!r}"
                    )
                    continue
                refresh_sql = f"ALTER PIPE {pipe_name} REFRESH PREFIX='{stage_prefix}'"
                try:
                    self.logger.info(
                        f"Refreshing Snowpipe {pipe_name} for prefix {stage_prefix}"
                    )
                    cursor.execute(refresh_sql)
                except Exception as e:
                    self.logger.error(
                        f"ALTER PIPE REFRESH failed for {pipe_name} "
                        f"(prefix={stage_prefix}): {e}",
                        exception=e,
                    )
