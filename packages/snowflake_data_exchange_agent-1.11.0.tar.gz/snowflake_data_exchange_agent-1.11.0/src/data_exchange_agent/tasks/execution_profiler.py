"""Lightweight step-level profiler for task execution profile."""

from __future__ import annotations

import json
import time


class ExecutionProfiler:
    """
    Records named step durations for task execution profile.

    Step names should come from
    :mod:`data_exchange_agent.constants.profiler_steps` — that module is the
    single source of truth for the kebab-case identifiers emitted into the
    JSON profile.

    Usage for sequential steps::

        from data_exchange_agent.constants import profiler_steps

        profiler = ExecutionProfiler()
        profiler.step(profiler_steps.EXPORT_DATA)
        export_data()
        profiler.step(profiler_steps.UPLOAD_DATA)
        upload_data()
        profiler.finish()
        print(profiler.to_json())
        # [["export-data", 1004], ["upload-data", 2153]]

    Usage for parallel steps (timed externally)::

        t0 = time.monotonic()
        result = fetch_source()
        profiler.record(
            profiler_steps.FETCH_SOURCE_DATA,
            int((time.monotonic() - t0) * 1000),
        )
    """

    def __init__(self) -> None:
        """Initialize an empty profiler with no recorded steps."""
        self._steps: list[tuple[str, int]] = []
        self._current_step: str | None = None
        self._step_start: float | None = None

    def step(self, name: str) -> ExecutionProfiler:
        """End the previous step (if any) and start a new one."""
        self._end_current()
        self._current_step = name
        self._step_start = time.monotonic()
        return self

    def _end_current(self) -> None:
        if self._current_step is not None and self._step_start is not None:
            elapsed_ms = int((time.monotonic() - self._step_start) * 1000)
            self._steps.append((self._current_step, elapsed_ms))
            self._current_step = None
            self._step_start = None

    def record(self, name: str, duration_ms: int) -> None:
        """Directly record a step with a known duration (for parallel steps)."""
        self._steps.append((name, duration_ms))

    def finish(self) -> None:
        """End the last open step, if any."""
        self._end_current()

    def to_json(self) -> str:
        """Serialize as JSON: ``[["Step Name", duration_ms], ...]``."""
        self.finish()
        return json.dumps(self._steps)
