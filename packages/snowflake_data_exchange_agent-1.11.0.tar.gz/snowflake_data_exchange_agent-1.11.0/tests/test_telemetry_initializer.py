"""Tests for telemetry_initializer module."""

import unittest
from unittest.mock import Mock, patch


class TestInitializeTelemetryIfNeeded(unittest.TestCase):
    """Tests for initialize_telemetry_if_needed."""

    @patch("data_exchange_agent.telemetry_initializer.get_telemetry_client")
    def test_skips_when_telemetry_already_enabled(self, mock_get_client):
        from data_exchange_agent.telemetry_initializer import (
            initialize_telemetry_if_needed,
        )

        mock_client = Mock()
        mock_client.is_enabled.return_value = True
        mock_get_client.return_value = mock_client

        initialize_telemetry_if_needed(Mock())

    @patch("data_exchange_agent.telemetry_initializer.initialize_telemetry")
    @patch("data_exchange_agent.telemetry_initializer.detect_runtime_environment")
    @patch("data_exchange_agent.telemetry_initializer.get_telemetry_client")
    def test_initializes_when_client_is_none(self, mock_get_client, mock_detect, mock_init):
        from data_exchange_agent.telemetry_initializer import (
            initialize_telemetry_if_needed,
        )

        mock_get_client.return_value = None
        mock_detect.return_value = Mock(value="local")

        mock_conn = Mock()
        initialize_telemetry_if_needed(mock_conn)

        mock_init.assert_called_once()

    @patch("data_exchange_agent.telemetry_initializer.get_telemetry_client")
    def test_swallows_exceptions(self, mock_get_client):
        from data_exchange_agent.telemetry_initializer import (
            initialize_telemetry_if_needed,
        )

        mock_get_client.side_effect = RuntimeError("telemetry broken")

        initialize_telemetry_if_needed(Mock())


if __name__ == "__main__":
    unittest.main()
