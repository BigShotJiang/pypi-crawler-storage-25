"""Unit tests for TaskManager worker self-pull and shared throttle logic."""

import threading
import time
import unittest
from unittest.mock import Mock, patch

from data_exchange_agent.constants import task_keys
from data_exchange_agent.tasks import manager as manager_mod


def _make_manager() -> manager_mod.TaskManager:
    """Create a TaskManager with mocked DI dependencies for unit testing."""
    with patch.object(manager_mod.TaskManager, "__init__", lambda self, **kwargs: None):
        m = manager_mod.TaskManager()
    m.logger = Mock()
    m.stop_workers = False
    m.task_source_adapter = Mock()
    m.task_fetch_interval = 5
    m._last_empty_pull_time = 0.0
    m._throttle_lock = threading.Lock()
    m._pull_lock = threading.Semaphore(2)
    m._stop_event = threading.Event()
    m._contention_counts: dict[str, int] = {}
    m.snowflake_datasource = Mock()
    return m


class TestThrottleHelpers(unittest.TestCase):
    """Tests for _should_throttle, _throttle_remaining_seconds, _record_empty_pull."""

    def test_should_throttle_false_when_no_recent_empty_pull(self) -> None:
        m = _make_manager()
        m._last_empty_pull_time = 0.0
        self.assertFalse(m._should_throttle())

    def test_should_throttle_true_after_record_empty_pull(self) -> None:
        m = _make_manager()
        m._record_empty_pull()
        self.assertTrue(m._should_throttle())

    def test_should_throttle_false_after_cooldown_elapses(self) -> None:
        m = _make_manager()
        m.task_fetch_interval = 0.05
        m._record_empty_pull()
        time.sleep(0.25)
        self.assertFalse(m._should_throttle())

    def test_record_empty_pull_updates_timestamp(self) -> None:
        m = _make_manager()
        before = time.monotonic()
        m._record_empty_pull()
        after = time.monotonic()
        self.assertGreaterEqual(m._last_empty_pull_time, before)
        self.assertLessEqual(m._last_empty_pull_time, after)

    def test_throttle_remaining_seconds_positive_within_cooldown(self) -> None:
        m = _make_manager()
        m.task_fetch_interval = 10
        m._record_empty_pull()
        remaining = m._throttle_remaining_seconds()
        self.assertGreater(remaining, 0)
        self.assertLessEqual(remaining, 10)

    def test_throttle_remaining_seconds_zero_after_cooldown(self) -> None:
        m = _make_manager()
        m.task_fetch_interval = 0.01
        m._record_empty_pull()
        time.sleep(0.15)
        self.assertEqual(m._throttle_remaining_seconds(), 0.0)


class TestWorkerSelfPull(unittest.TestCase):
    """Tests for the worker loop pulling tasks directly."""

    def test_worker_pulls_task_and_processes_it(self) -> None:
        """Worker should call get_tasks, then process_task, then loop again."""
        m = _make_manager()
        task = {task_keys.ID: "42"}
        call_count = 0

        def get_tasks_side_effect(max_tasks: int = 1) -> list[dict]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return [task]
            m.stop_workers = True
            return []

        m.task_source_adapter.get_tasks.side_effect = get_tasks_side_effect
        m.process_task = Mock()

        m._worker_loop(0)

        m.process_task.assert_called_once_with(task)

    def test_worker_records_empty_pull_when_no_tasks(self) -> None:
        """An empty pull should update the shared throttle timestamp."""
        m = _make_manager()
        m.task_fetch_interval = 0.01

        call_count = 0

        def get_tasks_side_effect(max_tasks: int = 1) -> list[dict]:
            nonlocal call_count
            call_count += 1
            if call_count <= 1:
                return []
            m.stop_workers = True
            return []

        m.task_source_adapter.get_tasks.side_effect = get_tasks_side_effect
        m.process_task = Mock()

        m._worker_loop(0)

        self.assertGreater(m._last_empty_pull_time, 0.0)

    def test_worker_throttled_skips_pull(self) -> None:
        """When throttled, the worker should not call get_tasks."""
        m = _make_manager()
        m.task_fetch_interval = 100
        m._record_empty_pull()

        # Stop after the throttle sleep
        def stop_after_short_wait() -> None:
            time.sleep(0.05)
            m.stop_workers = True
            m._stop_event.set()

        stopper = threading.Thread(target=stop_after_short_wait)
        stopper.start()

        m._worker_loop(0)
        stopper.join()

        m.task_source_adapter.get_tasks.assert_not_called()

    def test_worker_pulls_immediately_after_processing(self) -> None:
        """After processing a task, the worker should pull again without sleeping."""
        m = _make_manager()
        process_times: list[float] = []
        original_process = Mock()

        def tracking_process(task: dict) -> None:
            process_times.append(time.monotonic())
            original_process(task)

        tasks = [{task_keys.ID: "1"}, {task_keys.ID: "2"}]
        call_count = 0

        def get_tasks_side_effect(max_tasks: int = 1) -> list[dict]:
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                return [tasks[call_count - 1]]
            m.stop_workers = True
            m._stop_event.set()
            return []

        m.task_source_adapter.get_tasks.side_effect = get_tasks_side_effect
        m.process_task = tracking_process

        m._worker_loop(0)

        self.assertEqual(original_process.call_count, 2)
        gap = process_times[1] - process_times[0]
        self.assertLess(gap, 0.5, "Worker should pull again immediately after processing")

    def test_worker_retries_on_pull_error(self) -> None:
        """On get_tasks error, the worker should sleep then retry."""
        m = _make_manager()
        m.task_fetch_interval = 0.01
        call_count = 0

        def get_tasks_side_effect(max_tasks: int = 1) -> list[dict]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("connection lost")
            m.stop_workers = True
            return []

        m.task_source_adapter.get_tasks.side_effect = get_tasks_side_effect
        m.process_task = Mock()

        m._worker_loop(0)

        self.assertEqual(m.task_source_adapter.get_tasks.call_count, 2)
        m.process_task.assert_not_called()


class TestPullSemaphore(unittest.TestCase):
    """Tests for _pull_lock semaphore allowing up to 2 concurrent PULL_TASKS calls."""

    def test_two_concurrent_pulls_are_allowed(self) -> None:
        """Two workers should be able to call get_tasks at the same time."""
        m = _make_manager()
        m.task_fetch_interval = 0.01
        both_inside = threading.Event()
        barrier = threading.Barrier(2, timeout=5)

        def slow_get_tasks(max_tasks: int = 1) -> list[dict]:
            barrier.wait()
            both_inside.set()
            time.sleep(0.05)
            return [{task_keys.ID: "x"}]

        m.task_source_adapter.get_tasks.side_effect = slow_get_tasks

        results: list[dict | None] = [None, None]

        def pull_worker(idx: int) -> None:
            results[idx] = m._pull_one_task(f"Worker-{idx}")

        t0 = threading.Thread(target=pull_worker, args=(0,))
        t1 = threading.Thread(target=pull_worker, args=(1,))
        t0.start()
        t1.start()
        t0.join(timeout=5)
        t1.join(timeout=5)

        self.assertTrue(both_inside.is_set(), "Two pulls should run concurrently with Semaphore(2)")
        self.assertIsNotNone(results[0])
        self.assertIsNotNone(results[1])

    def test_third_concurrent_pull_is_blocked(self) -> None:
        """A third concurrent pull should block until one of the first two finishes."""
        m = _make_manager()
        m.task_fetch_interval = 0.01
        concurrent_count = []
        count_lock = threading.Lock()

        def slow_get_tasks(max_tasks: int = 1) -> list[dict]:
            with count_lock:
                concurrent_count.append(threading.active_count())
            time.sleep(0.15)
            return [{task_keys.ID: "x"}]

        m.task_source_adapter.get_tasks.side_effect = slow_get_tasks

        threads = []
        for i in range(3):
            t = threading.Thread(target=m._pull_one_task, args=(f"Worker-{i}",))
            threads.append(t)
            t.start()
            time.sleep(0.02)

        for t in threads:
            t.join(timeout=5)

        self.assertEqual(
            m.task_source_adapter.get_tasks.call_count,
            3,
            "All three pulls should eventually complete",
        )

    def test_pull_returns_none_when_throttled_inside_lock(self) -> None:
        """If throttle activates while waiting for _pull_lock, return None without pulling."""
        m = _make_manager()
        m.task_fetch_interval = 100
        m._record_empty_pull()

        result = m._pull_one_task("Worker-0")

        self.assertIsNone(result)
        m.task_source_adapter.get_tasks.assert_not_called()


class TestStopEvent(unittest.TestCase):
    """Tests for stop() waking sleeping workers via _stop_event."""

    def test_stop_sets_event_and_flags(self) -> None:
        m = _make_manager()
        m.lease_refresher = Mock()
        m.handling_tasks = True

        m.stop()

        self.assertTrue(m.stop_workers)
        self.assertFalse(m.handling_tasks)
        self.assertTrue(m._stop_event.is_set())
        m.lease_refresher.stop.assert_called_once()

    def test_stop_wakes_sleeping_worker(self) -> None:
        """A worker sleeping on throttle should exit promptly when stop() is called."""
        m = _make_manager()
        m.task_fetch_interval = 100
        m._record_empty_pull()
        m.lease_refresher = Mock()
        m.process_task = Mock()

        worker_done = threading.Event()

        def run_worker() -> None:
            m._worker_loop(0)
            worker_done.set()

        t = threading.Thread(target=run_worker)
        t.start()

        time.sleep(0.05)
        m.stop()

        finished = worker_done.wait(timeout=2.0)
        self.assertTrue(finished, "Worker did not exit promptly after stop()")
        t.join(timeout=2.0)


if __name__ == "__main__":
    unittest.main()
