"""Unit tests for LeaseRefresher."""

import threading
import unittest
from unittest.mock import Mock, patch

import pytest

from data_exchange_agent.tasks import lease_refresher as lr_mod


def _make_refresher() -> lr_mod.LeaseRefresher:
    """Create a LeaseRefresher with mocked DI dependencies."""
    with patch.object(lr_mod.LeaseRefresher, "__init__", lambda self, **kw: None):
        r = lr_mod.LeaseRefresher()
    r.logger = Mock()
    r.agent_id = "test-agent-123"
    r.refresh_interval = 0.01
    r._qualified_data_migration_metadata_schema = "DB.SCHEMA"
    r.snowflake_datasource = Mock()
    r._stop_event = threading.Event()
    r._thread = None
    return r


class TestLeaseRefresherStartStop(unittest.TestCase):
    """Tests for start() and stop() lifecycle."""

    def test_start_creates_and_starts_thread(self):
        r = _make_refresher()
        started = threading.Event()

        def signalling_loop():
            started.set()
            # Wait until stop is requested
            r._stop_event.wait()

        r._refresh_loop = signalling_loop

        r.start()
        try:
            started.wait(timeout=2)
            self.assertIsNotNone(r._thread)
            self.assertTrue(r._thread.is_alive())
            self.assertEqual(r._thread.name, "LeaseRefresher")
        finally:
            r._stop_event.set()
            r._thread.join(timeout=2)

    def test_start_when_already_running_logs_warning(self):
        r = _make_refresher()
        r._thread = Mock()
        r._thread.is_alive.return_value = True

        r.start()

        r.logger.warning.assert_called_once()

    def test_stop_signals_and_joins_thread(self):
        r = _make_refresher()
        mock_thread = Mock()
        mock_thread.is_alive.side_effect = [True, False]
        r._thread = mock_thread

        r.stop()

        self.assertTrue(r._stop_event.is_set())
        mock_thread.join.assert_called_once_with(timeout=5)
        self.assertIsNone(r._thread)
        r.snowflake_datasource.close_connection.assert_called_once()

    def test_stop_when_no_thread_is_noop(self):
        r = _make_refresher()
        r._thread = None

        r.stop()

        r.snowflake_datasource.close_connection.assert_not_called()

    def test_stop_warns_on_ungraceful_exit(self):
        r = _make_refresher()
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        r._thread = mock_thread

        r.stop()

        r.logger.warning.assert_called()


class TestRefreshLoop(unittest.TestCase):
    """Tests for _refresh_loop."""

    def test_calls_refresh_leases_until_stopped(self):
        r = _make_refresher()
        call_count = 0

        def counting_refresh():
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                r._stop_event.set()

        r._refresh_leases = counting_refresh
        r._refresh_loop()

        self.assertGreaterEqual(call_count, 2)

    def test_catches_exceptions_from_refresh_leases(self):
        r = _make_refresher()
        call_count = 0

        def failing_refresh():
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                r._stop_event.set()
            raise RuntimeError("boom")

        r._refresh_leases = failing_refresh
        r._refresh_loop()

        self.assertGreaterEqual(call_count, 2)
        r.logger.error.assert_called()


class TestRefreshLeases(unittest.TestCase):
    """Tests for _refresh_leases stored procedure call."""

    def test_calls_stored_procedure_with_agent_id(self):
        r = _make_refresher()
        r.snowflake_datasource.is_closed.return_value = False
        r.snowflake_datasource.execute_statement.return_value = iter([{"REFRESH_LEASES": True}])

        r._refresh_leases()

        r.snowflake_datasource.execute_statement.assert_called_once()
        call_args = r.snowflake_datasource.execute_statement.call_args
        self.assertIn("REFRESH_LEASES", call_args[0][0])
        self.assertEqual(call_args[0][1], ("test-agent-123",))

    def test_creates_connection_when_closed(self):
        r = _make_refresher()
        r.snowflake_datasource.is_closed.return_value = True
        r.snowflake_datasource.execute_statement.return_value = iter([{"REFRESH_LEASES": False}])

        r._refresh_leases()

        r.snowflake_datasource.create_connection.assert_called_once()

    def test_skips_create_when_not_closed(self):
        r = _make_refresher()
        r.snowflake_datasource.is_closed.return_value = False
        r.snowflake_datasource.execute_statement.return_value = iter([{"REFRESH_LEASES": False}])

        r._refresh_leases()

        r.snowflake_datasource.create_connection.assert_not_called()

    def test_handles_no_result_rows(self):
        r = _make_refresher()
        r.snowflake_datasource.is_closed.return_value = False
        r.snowflake_datasource.execute_statement.return_value = iter([])

        r._refresh_leases()

    def test_unknown_function_error_logs_warning_and_returns(self):
        from snowflake.connector.errors import ProgrammingError

        r = _make_refresher()
        r.snowflake_datasource.is_closed.return_value = False
        err = ProgrammingError(msg="Unknown function", errno=2141)
        r.snowflake_datasource.execute_statement.side_effect = err

        r._refresh_leases()

        r.logger.warning.assert_called()
        r.snowflake_datasource.close_connection.assert_not_called()

    def test_other_programming_error_closes_connection_and_raises(self):
        from snowflake.connector.errors import ProgrammingError

        r = _make_refresher()
        r.snowflake_datasource.is_closed.return_value = False
        err = ProgrammingError(msg="Some other error", errno=9999)
        r.snowflake_datasource.execute_statement.side_effect = err

        with pytest.raises((Exception, ProgrammingError), match="Failed to refresh leases"):
            r._refresh_leases()

        r.snowflake_datasource.close_connection.assert_called_once()

    def test_generic_exception_closes_connection_and_raises(self):
        r = _make_refresher()
        r.snowflake_datasource.is_closed.return_value = False
        r.snowflake_datasource.execute_statement.side_effect = RuntimeError("network")

        with pytest.raises((Exception, RuntimeError), match="Failed to refresh leases"):
            r._refresh_leases()

        r.snowflake_datasource.close_connection.assert_called_once()


if __name__ == "__main__":
    unittest.main()
