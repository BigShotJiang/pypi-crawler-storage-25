"""Tests for the chunk_column_names vertical partitioning utility in the DEA."""

import unittest

from data_exchange_agent.tasks.data_validation.cell_validation import (
    chunk_column_names,
)


class TestChunkColumnNames(unittest.TestCase):
    """Tests for chunk_column_names utility function."""

    def test_no_chunking_when_columns_fit(self):
        """Columns <= max_per_batch should return a single batch."""
        cols = [f"c{i}" for i in range(5)]
        result = chunk_column_names(cols, max_per_batch=10)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0], cols)

    def test_no_chunking_when_exactly_at_limit(self):
        """Columns == max_per_batch should return a single batch."""
        cols = [f"c{i}" for i in range(10)]
        result = chunk_column_names(cols, max_per_batch=10)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0], cols)

    def test_no_chunking_when_max_is_zero(self):
        """max_per_batch <= 0 disables chunking."""
        cols = [f"c{i}" for i in range(50)]
        result = chunk_column_names(cols, max_per_batch=0)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0], cols)

    def test_no_chunking_when_max_is_negative(self):
        """Negative max_per_batch disables chunking."""
        cols = [f"c{i}" for i in range(50)]
        result = chunk_column_names(cols, max_per_batch=-1)
        self.assertEqual(len(result), 1)

    def test_even_split(self):
        """30 columns with batch size 10 produces 3 batches of 10."""
        cols = [f"c{i}" for i in range(30)]
        result = chunk_column_names(cols, max_per_batch=10)
        self.assertEqual(len(result), 3)
        for batch in result:
            self.assertEqual(len(batch), 10)

    def test_remainder_batch(self):
        """25 columns with batch size 10 produces 3 batches (10, 10, 5)."""
        cols = [f"c{i}" for i in range(25)]
        result = chunk_column_names(cols, max_per_batch=10)
        self.assertEqual(len(result), 3)
        self.assertEqual(len(result[0]), 10)
        self.assertEqual(len(result[1]), 10)
        self.assertEqual(len(result[2]), 5)

    def test_all_columns_covered(self):
        """All columns appear exactly once across batches (no index columns)."""
        cols = [f"c{i}" for i in range(17)]
        result = chunk_column_names(cols, max_per_batch=5)
        flat = [c for batch in result for c in batch]
        self.assertEqual(len(flat), 17)

    def test_index_columns_in_every_batch(self):
        """Index columns appear in every batch."""
        cols = ["id", "a", "b", "c", "d", "e", "f"]
        result = chunk_column_names(cols, max_per_batch=4, index_columns=["id"])
        # 1 index + 6 non-index, effective batch = 3 non-index per batch
        # => ceil(6/3) = 2 batches
        self.assertEqual(len(result), 2)
        for batch in result:
            self.assertIn("id", batch, "Index column must be in every batch")
            self.assertLessEqual(len(batch), 4)

    def test_index_columns_not_duplicated_in_coverage(self):
        """Non-index columns appear exactly once across all batches."""
        cols = ["pk", "a", "b", "c", "d", "e"]
        result = chunk_column_names(cols, max_per_batch=3, index_columns=["pk"])
        # effective batch = 2 non-index per batch => 3 batches
        non_index_names: list[str] = []
        for batch in result:
            for c in batch:
                if c != "pk":
                    non_index_names.append(c)
        self.assertEqual(sorted(non_index_names), ["a", "b", "c", "d", "e"])

    def test_index_columns_case_insensitive(self):
        """Index column matching is case-insensitive."""
        cols = ["ID", "col_a", "col_b", "col_c"]
        result = chunk_column_names(cols, max_per_batch=3, index_columns=["id"])
        for batch in result:
            self.assertIn("ID", batch)

    def test_multiple_index_columns(self):
        """Multiple index columns are included in every batch."""
        cols = ["k1", "k2", "a", "b", "c", "d"]
        result = chunk_column_names(cols, max_per_batch=4, index_columns=["k1", "k2"])
        # 2 index + 4 non-index, effective batch = 2 => 2 batches
        self.assertEqual(len(result), 2)
        for batch in result:
            self.assertIn("k1", batch)
            self.assertIn("k2", batch)
            self.assertLessEqual(len(batch), 4)

    def test_index_columns_exceed_batch_size(self):
        """When index columns alone >= batch size, return single batch."""
        cols = ["k1", "k2", "k3", "a", "b"]
        result = chunk_column_names(
            cols, max_per_batch=2, index_columns=["k1", "k2", "k3"]
        )
        self.assertEqual(len(result), 1)
        self.assertEqual(len(result[0]), 5)

    def test_empty_columns(self):
        """Empty column list returns single empty batch."""
        result = chunk_column_names([], max_per_batch=10)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0], [])

    def test_single_column(self):
        """Single column returns single batch."""
        cols = ["a"]
        result = chunk_column_names(cols, max_per_batch=10)
        self.assertEqual(len(result), 1)
        self.assertEqual(len(result[0]), 1)


if __name__ == "__main__":
    unittest.main()
