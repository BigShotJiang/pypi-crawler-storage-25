"""Tests for TaskManager helper methods (_handle_success, _handle_error, etc.)."""

import os
import tempfile
import threading
import types
import unittest

from unittest.mock import Mock, patch

from data_exchange_agent.constants import task_keys
from data_exchange_agent.tasks import manager as manager_mod


def _build_mock_pyodbc():
    """Build a lightweight mock ``pyodbc`` module with a proper Error hierarchy."""
    mod = types.ModuleType("pyodbc")

    class Error(Exception):
        pass

    class OperationalError(Error):
        pass

    mod.Error = Error
    mod.OperationalError = OperationalError
    return mod


def _make_manager() -> manager_mod.TaskManager:
    """Create a TaskManager with mocked DI dependencies."""
    with patch.object(manager_mod.TaskManager, "__init__", lambda self, **kw: None):
        m = manager_mod.TaskManager()
    m.logger = Mock()
    m.task_source_adapter = Mock()
    m.snowflake_datasource = Mock()
    m.source_connections_config = {}
    m.target_connections_config = {}
    m.lease_refresher = Mock()
    m.stop_workers = False
    m._stop_event = threading.Event()
    m._pull_lock = threading.Semaphore(2)
    m._throttle_lock = threading.Lock()
    m._last_empty_pull_time = 0.0
    m.task_fetch_interval = 5
    m._contention_counts = {}
    m._local_results_directory = None
    return m


class TestHandleSuccess(unittest.TestCase):
    """Tests for TaskManager._handle_success."""

    def test_calls_complete_task(self):
        m = _make_manager()
        task = {task_keys.ID: "task-1"}

        m._handle_success(task)

        m.task_source_adapter.complete_task.assert_called_once_with(
            "task-1", execution_profile=None
        )

    def test_passes_execution_profile(self):
        m = _make_manager()
        task = {task_keys.ID: "task-1"}
        profile = '[["Step A", 100]]'

        m._handle_success(task, execution_profile=profile)

        m.task_source_adapter.complete_task.assert_called_once_with(
            "task-1", execution_profile=profile
        )

    def test_logs_completion(self):
        m = _make_manager()
        task = {task_keys.ID: "task-42"}

        m._handle_success(task)

        m.logger.info.assert_called()

    def test_handles_complete_task_failure(self):
        m = _make_manager()
        m.task_source_adapter.complete_task.side_effect = RuntimeError("network")
        task = {task_keys.ID: "task-1"}

        m._handle_success(task)

        m.logger.error.assert_called()


class TestHandleError(unittest.TestCase):
    """Tests for TaskManager._handle_error."""

    def test_calls_fail_task_with_message(self):
        m = _make_manager()
        task = {task_keys.ID: "task-1"}

        m._handle_error(task, "something went wrong")

        m.task_source_adapter.fail_task.assert_called_once()
        call_args = m.task_source_adapter.fail_task.call_args
        assert call_args[0][0] == "task-1"
        assert "something went wrong" in call_args[0][1]

    def test_includes_exception_details(self):
        m = _make_manager()
        task = {task_keys.ID: "task-2"}
        exc = ValueError("bad value")

        m._handle_error(task, "processing failed", exc)

        call_args = m.task_source_adapter.fail_task.call_args
        assert "ValueError" in call_args[0][1]
        assert "bad value" in call_args[0][1]

    def test_no_exception_passes_base_message(self):
        m = _make_manager()
        task = {task_keys.ID: "task-3"}

        m._handle_error(task, "simple failure")

        call_args = m.task_source_adapter.fail_task.call_args
        assert "simple failure" in call_args[0][1]

    def test_handles_fail_task_failure(self):
        m = _make_manager()
        m.task_source_adapter.fail_task.side_effect = RuntimeError("dead")
        task = {task_keys.ID: "task-1"}

        m._handle_error(task, "some error")

        assert m.logger.error.call_count >= 2


class TestBuildDetailedErrorMessage(unittest.TestCase):
    """Tests for TaskManager._build_detailed_error_message."""

    def test_includes_exception_type_and_message(self):
        m = _make_manager()
        result = m._build_detailed_error_message("base msg", ValueError("test err"))

        assert "ValueError" in result
        assert "test err" in result
        assert "base msg" in result

    def test_handles_empty_exception_message(self):
        m = _make_manager()
        result = m._build_detailed_error_message("base", RuntimeError())

        assert "RuntimeError" in result
        assert "base" in result


class TestProcessDataValidationTask(unittest.TestCase):
    """Tests for TaskManager._process_data_validation_task."""

    def test_success_calls_handle_success(self):
        m = _make_manager()
        with patch(
            "data_exchange_agent.tasks.manager.DataValidationHandler"
        ) as mock_handler_cls:
            mock_handler = mock_handler_cls.return_value
            mock_handler.handle.return_value = {"status": "success"}

            task = {task_keys.ID: "dv-1", task_keys.KIND: "data_validation"}
            m._process_data_validation_task(task)

            mock_handler.handle.assert_called_once()
            call_args = mock_handler.handle.call_args
            assert call_args[0][0] is task
            assert "profiler" in call_args[1]

    def test_error_result_calls_handle_error(self):
        m = _make_manager()
        with patch(
            "data_exchange_agent.tasks.manager.DataValidationHandler"
        ) as mock_handler_cls:
            mock_handler = mock_handler_cls.return_value
            mock_handler.handle.return_value = {
                "status": "error",
                "details": "validation fail",
            }

            task = {task_keys.ID: "dv-2", task_keys.KIND: "data_validation"}
            m._process_data_validation_task(task)

            m.task_source_adapter.fail_task.assert_called_once()

    def test_passes_query_tag_to_handler(self):
        m = _make_manager()
        with patch(
            "data_exchange_agent.tasks.manager.DataValidationHandler"
        ) as mock_handler_cls:
            mock_handler = mock_handler_cls.return_value
            mock_handler.handle.return_value = {"status": "success"}

            task = {task_keys.ID: "dv-3", task_keys.KIND: "data_validation"}
            m._process_data_validation_task(task, query_tag='{"tag": "value"}')

            call_kwargs = mock_handler_cls.call_args[1]
            assert call_kwargs["query_tag"] == '{"tag": "value"}'


class TestCalculateMetrics(unittest.TestCase):
    """Tests for TaskManager._calculate_metrics."""

    def test_returns_zeros_for_empty_dir(self):
        m = _make_manager()
        with tempfile.TemporaryDirectory() as d:
            rows, bytes_ = m._calculate_metrics(d)
            assert rows == 0
            assert bytes_ == 0

    def test_returns_zeros_for_nonexistent_dir(self):
        m = _make_manager()
        rows, bytes_ = m._calculate_metrics("/nonexistent/path/xyz")
        assert rows == 0
        assert bytes_ == 0

    def test_counts_parquet_file_bytes(self):
        m = _make_manager()
        with tempfile.TemporaryDirectory() as d:
            f = os.path.join(d, "data.parquet")
            with open(f, "wb") as fh:
                fh.write(b"x" * 2048)
            rows, bytes_ = m._calculate_metrics(d)
            assert bytes_ == 2048


class TestHandleCloudStorageError(unittest.TestCase):
    """Tests for TaskManager._handle_cloud_storage_error."""

    def test_handles_generic_exception(self):
        m = _make_manager()
        task = {task_keys.ID: "t1"}
        exc = RuntimeError("upload failed")

        m._handle_cloud_storage_error(task, "Cloud error", exc)

        m.task_source_adapter.fail_task.assert_called_once()


class TestProcessTask(unittest.TestCase):
    """Tests for TaskManager.process_task query tag integration."""

    def test_sets_and_restores_query_tag(self):
        m = _make_manager()
        m._process_data_movement_task = Mock()

        task = {
            task_keys.ID: "t-1",
            task_keys.WORKFLOW_ID: "w-1",
            task_keys.KIND: "data_movement",
        }
        m.process_task(task)

        tag_calls = m.snowflake_datasource.set_query_tag.call_args_list
        assert len(tag_calls) == 2
        first_tag = tag_calls[0][0][0]
        assert "w-1" in first_tag
        assert "t-1" in first_tag
        second_tag = tag_calls[1][0][0]
        assert "DMVF_VERSION" in second_tag

    def test_restores_query_tag_on_exception(self):
        m = _make_manager()
        m._process_data_movement_task = Mock(side_effect=RuntimeError("boom"))

        task = {
            task_keys.ID: "t-2",
            task_keys.WORKFLOW_ID: "w-2",
            task_keys.KIND: "data_movement",
        }
        with self.assertRaises(RuntimeError):
            m.process_task(task)

        tag_calls = m.snowflake_datasource.set_query_tag.call_args_list
        assert len(tag_calls) == 2

    def test_data_validation_task_dispatches_correctly(self):
        m = _make_manager()
        with patch(
            "data_exchange_agent.tasks.manager.DataValidationHandler"
        ) as mock_handler_cls:
            mock_handler = mock_handler_cls.return_value
            mock_handler.handle.return_value = {"status": "success"}

            task = {
                task_keys.ID: "dv-1",
                task_keys.WORKFLOW_ID: "w-1",
                task_keys.KIND: task_keys.DATA_VALIDATION,
            }
            m.process_task(task)

            mock_handler.handle.assert_called_once()
            call_args = mock_handler.handle.call_args
            assert call_args[0][0] is task
            m.task_source_adapter.complete_task.assert_called_once()
            complete_call = m.task_source_adapter.complete_task.call_args
            assert complete_call[0][0] == "dv-1"
            assert "execution_profile" in complete_call[1]


class TestHandleOdbcError(unittest.TestCase):
    """Tests for TaskManager._handle_odbc_error."""

    _mock_pyodbc = _build_mock_pyodbc()

    def test_generic_exception_adds_check_message(self):
        m = _make_manager()
        task = {task_keys.ID: "t-1"}
        exc = RuntimeError("some error")

        with patch.dict("sys.modules", {"pyodbc": self._mock_pyodbc}):
            m._handle_odbc_error(task, "ODBC error", exc)

        call_args = m.task_source_adapter.fail_task.call_args
        assert "check the database connection" in call_args[0][1]

    def test_pyodbc_connection_refused_adds_verify_message(self):
        m = _make_manager()
        task = {task_keys.ID: "t-2"}
        exc = self._mock_pyodbc.OperationalError("Connection refused")

        with patch.dict("sys.modules", {"pyodbc": self._mock_pyodbc}):
            m._handle_odbc_error(task, "ODBC error", exc)

        call_args = m.task_source_adapter.fail_task.call_args
        assert "Verify the connection properties" in call_args[0][1]

    def test_pyodbc_login_timeout_adds_verify_message(self):
        m = _make_manager()
        task = {task_keys.ID: "t-3"}
        exc = self._mock_pyodbc.OperationalError("Login timeout expired")

        with patch.dict("sys.modules", {"pyodbc": self._mock_pyodbc}):
            m._handle_odbc_error(task, "ODBC error", exc)

        call_args = m.task_source_adapter.fail_task.call_args
        assert "Verify the connection properties" in call_args[0][1]

    def test_pyodbc_other_error_adds_check_message(self):
        m = _make_manager()
        task = {task_keys.ID: "t-4"}
        exc = self._mock_pyodbc.OperationalError("Some other pyodbc error")

        with patch.dict("sys.modules", {"pyodbc": self._mock_pyodbc}):
            m._handle_odbc_error(task, "ODBC error", exc)

        call_args = m.task_source_adapter.fail_task.call_args
        assert "check the database connection" in call_args[0][1]


class TestHandleCloudStorageErrorDetailed(unittest.TestCase):
    """Detailed tests for _handle_cloud_storage_error."""

    def test_snowflake_database_error_includes_message(self):
        from snowflake.connector import errors as sf_errors

        m = _make_manager()
        task = {task_keys.ID: "t-1"}
        exc = sf_errors.DatabaseError("db error details")

        m._handle_cloud_storage_error(task, "Cloud error", exc)

        call_args = m.task_source_adapter.fail_task.call_args
        assert "db error details" in call_args[0][1]

    def test_snowflake_http_error_includes_message(self):
        from snowflake.connector import errors as sf_errors

        m = _make_manager()
        task = {task_keys.ID: "t-2"}
        exc = sf_errors.HttpError()
        exc.args = ("http error details",)

        m._handle_cloud_storage_error(task, "Cloud error", exc)

        call_args = m.task_source_adapter.fail_task.call_args
        assert "Cloud error" in call_args[0][1]


class TestCalculateMetricsDetailed(unittest.TestCase):
    """Detailed tests for _calculate_metrics including parquet files."""

    def test_counts_rows_from_valid_parquet(self):
        import pyarrow as pa
        import pyarrow.parquet as pq

        m = _make_manager()
        with tempfile.TemporaryDirectory() as d:
            table = pa.table({"id": [1, 2, 3], "name": ["a", "b", "c"]})
            path = os.path.join(d, "test.parquet")
            pq.write_table(table, path)

            rows, bytes_ = m._calculate_metrics(d)
            assert rows == 3
            assert bytes_ > 0

    def test_handles_corrupt_parquet_file(self):
        m = _make_manager()
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "corrupt.parquet")
            with open(path, "wb") as f:
                f.write(b"not a parquet file content")

            rows, bytes_ = m._calculate_metrics(d)
            assert bytes_ > 0


class TestRemoveExportArtifactsEmpty(unittest.TestCase):
    """Tests for edge cases in _remove_export_artifacts_after_success."""

    def test_empty_path_is_noop(self):
        m = _make_manager()
        m._remove_export_artifacts_after_success("")

    def test_nonexistent_dir_is_noop(self):
        m = _make_manager()
        m._remove_export_artifacts_after_success(
            os.path.join(tempfile.gettempdir(), "task_123", "nonexistent_ts")
        )


if __name__ == "__main__":
    unittest.main()
