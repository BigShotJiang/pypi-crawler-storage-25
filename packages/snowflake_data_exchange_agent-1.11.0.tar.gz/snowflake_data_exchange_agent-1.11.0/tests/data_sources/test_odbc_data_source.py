"""
Tests for ODBCDataSource's parquet schema-stability behavior.

These tests exercise the private ``_write_chunks_to_single_parquet`` path
because that's where the schema decision lives. The fake cursor mimics a
DB-API 2.0 driver: it exposes a ``description`` attribute and a
``fetchmany`` method that returns successive pre-loaded batches.

The first three tests reproduce the production failure modes
(``ValueError: Table schema does not match schema used to create file``)
and serve as regression tests for the fix.
"""

import os
import tempfile
import unittest

from decimal import Decimal
from typing import Any
from unittest.mock import Mock

import pyarrow as pa
import pyarrow.parquet as pq

from data_exchange_agent.constants import config_keys
from data_exchange_agent.data_sources.odbc_data_source import ODBCDataSource


class FakeCursor:
    """
    Minimal DB-API cursor stand-in for the parquet writer path.

    ``description`` follows the pyodbc 7-tuple shape and ``fetchmany``
    returns pre-loaded batches in order; ``size`` is ignored because the
    tests deliberately control batch contents to reproduce specific
    type-inference outcomes.
    """

    def __init__(
        self,
        description: list[
            tuple[str, type | None, Any, Any, int | None, int | None, bool | None]
        ],
        batches: list[list[tuple]],
    ) -> None:
        self.description = description
        self._remaining_batches = list(batches)

    def fetchmany(self, size: int) -> list[tuple]:
        if not self._remaining_batches:
            return []
        return self._remaining_batches.pop(0)


class TestODBCDataSourceWriteChunks(unittest.TestCase):
    """Regression tests for `_write_chunks_to_single_parquet` schema behavior."""

    def setUp(self) -> None:
        self.engine = "sqlserver_test"
        self.mock_logger = Mock()

        # The data source only needs `.connection_string` from the connection
        # config; the rest of __init__ doesn't touch the network.
        mock_connection_config = Mock(connection_string="dummy-connection-string")

        self.mock_program_config = Mock()
        self.mock_program_config.__getitem__ = Mock(
            side_effect=lambda key: (
                {self.engine: mock_connection_config}
                if key == config_keys.CONNECTIONS__SOURCE
                else None
            )
        )

        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def _make_data_source(self) -> ODBCDataSource:
        return ODBCDataSource(
            engine=self.engine,
            statement="SELECT 1",
            results_folder_path=self.tmp.name,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

    def _output_path(self, name: str = "out.parquet") -> str:
        return os.path.join(self.tmp.name, name)

    # ----- regression cases for the production bug ------------------------

    def test_sparse_null_first_batch_does_not_poison_schema(self):
        """
        A bool column that's all-NULL in batch 1 keeps its declared type.

        Reproduces the production `IS_ARCHIVEABLE: null vs bool` failure.
        """
        cursor = FakeCursor(
            description=[
                ("IS_ARCHIVEABLE", bool, None, None, None, None, True),
            ],
            batches=[
                [(None,)] * 5,
                [(True,), (False,), (True,), (False,), (True,)],
            ],
        )
        data_source = self._make_data_source()
        out = self._output_path()

        data_source._write_chunks_to_single_parquet(cursor, out, batch_size=5)

        table = pq.read_table(out)
        self.assertEqual(table.schema.field("IS_ARCHIVEABLE").type, pa.bool_())
        self.assertEqual(table.num_rows, 10)

    def test_decimal_magnitude_drift_uses_declared_precision(self):
        """
        A decimal column locks in the source DDL precision/scale.

        Reproduces the production `EXCHANGE_RATE: decimal128(7,6) vs (12,6)`
        failure.
        """
        cursor = FakeCursor(
            description=[
                ("EXCHANGE_RATE", Decimal, None, None, 38, 6, True),
            ],
            batches=[
                [(Decimal("0.123456"),)] * 5,
                [(Decimal("123456.789012"),)] * 5,
            ],
        )
        data_source = self._make_data_source()
        out = self._output_path()

        data_source._write_chunks_to_single_parquet(cursor, out, batch_size=5)

        table = pq.read_table(out)
        self.assertEqual(table.schema.field("EXCHANGE_RATE").type, pa.decimal128(38, 6))
        self.assertEqual(table.num_rows, 10)

    def test_decimal_scale_drift_uses_declared_scale(self):
        """Scale drift across batches is absorbed by the declared scale."""
        cursor = FakeCursor(
            description=[
                ("RATE", Decimal, None, None, 38, 6, True),
            ],
            batches=[
                [(Decimal("12.3"),)] * 5,
                [(Decimal("12.345678"),)] * 5,
            ],
        )
        data_source = self._make_data_source()
        out = self._output_path()

        data_source._write_chunks_to_single_parquet(cursor, out, batch_size=5)

        table = pq.read_table(out)
        self.assertEqual(table.schema.field("RATE").type, pa.decimal128(38, 6))
        self.assertEqual(table.num_rows, 10)

    def test_shipment_shaped_table_writes_cleanly(self):
        """End-to-end: SHIPMENT-shaped table with sparse NULLs + decimal drift."""
        cursor = FakeCursor(
            description=[
                ("EXCHANGE_RATE", Decimal, None, None, 38, 6, True),
                ("TOTAL_WEIGHT_STANDARD", Decimal, None, None, 38, 5, True),
                ("IS_ARCHIVEABLE", bool, None, None, None, None, True),
                ("AUDIT_CATEGORY", str, None, None, None, None, True),
                ("PAYMENT_TERMS", int, None, None, None, None, True),
            ],
            batches=[
                [(Decimal("0.123456"), Decimal("0.12345"), None, None, None)] * 5,
                [
                    (
                        Decimal("123456.789012"),
                        Decimal("12345.67890"),
                        True,
                        "STANDARD",
                        30,
                    ),
                    (
                        Decimal("999999.999999"),
                        Decimal("99999.99999"),
                        False,
                        "EXPRESS",
                        60,
                    ),
                ]
                * 2,
            ],
        )
        data_source = self._make_data_source()
        out = self._output_path()

        data_source._write_chunks_to_single_parquet(cursor, out, batch_size=5)

        table = pq.read_table(out)
        self.assertEqual(table.schema.field("EXCHANGE_RATE").type, pa.decimal128(38, 6))
        self.assertEqual(
            table.schema.field("TOTAL_WEIGHT_STANDARD").type,
            pa.decimal128(38, 5),
        )
        self.assertEqual(table.schema.field("IS_ARCHIVEABLE").type, pa.bool_())
        self.assertEqual(table.schema.field("AUDIT_CATEGORY").type, pa.string())
        self.assertEqual(table.schema.field("PAYMENT_TERMS").type, pa.int64())
        self.assertEqual(table.num_rows, 9)

    # ----- positive cases that should keep working ------------------------

    def test_single_batch_writes_successfully(self):
        """Single-batch writes still succeed (matches pre-fix behavior)."""
        cursor = FakeCursor(
            description=[
                ("ID", int, None, None, None, None, False),
                ("NAME", str, None, None, None, None, True),
            ],
            batches=[
                [(1, "alpha"), (2, "beta"), (3, None)],
            ],
        )
        data_source = self._make_data_source()
        out = self._output_path()

        data_source._write_chunks_to_single_parquet(cursor, out, batch_size=10)

        table = pq.read_table(out)
        self.assertEqual(table.num_rows, 3)
        self.assertEqual(table.schema.field("ID").type, pa.int64())
        self.assertEqual(table.schema.field("NAME").type, pa.string())

    def test_unmappable_type_falls_back_to_per_batch_inference(self):
        """Custom driver types fall back to inference *for that one column*."""

        class _CustomGeographyType:
            """Stand-in for a driver-specific type with no PyArrow mapping."""

        cursor = FakeCursor(
            description=[
                ("ID", int, None, None, None, None, False),
                # Unmappable type code -- mapper returns None, caller infers.
                ("LOCATION", _CustomGeographyType, None, None, None, None, True),
            ],
            batches=[
                [(1, "POINT(0 0)"), (2, "POINT(1 1)")],
            ],
        )
        data_source = self._make_data_source()
        out = self._output_path()

        data_source._write_chunks_to_single_parquet(cursor, out, batch_size=10)

        table = pq.read_table(out)
        self.assertEqual(table.num_rows, 2)
        self.assertEqual(table.schema.field("ID").type, pa.int64())
        # LOCATION's type was inferred from the actual values (string).
        self.assertEqual(table.schema.field("LOCATION").type, pa.string())


if __name__ == "__main__":
    unittest.main()
