"""Tests for small config modules to improve overall coverage."""

import unittest

from data_exchange_agent.config.base_config import BaseConfig
from data_exchange_agent.config.sections.connections.cloud_storages.snowflake.authenticator_type import (
    SnowflakeAuthenticatorType,
)
from data_exchange_agent.config.sections.task_sources.api import ApiConfig
from data_exchange_agent.config.sections.task_sources.snowflake_stored_procedure import (
    SnowflakeStoredProcedureConfig,
)
from data_exchange_agent.constants.connection_types import ConnectionType


class TestBaseConfig(unittest.TestCase):
    """Tests for BaseConfig.keys()."""

    def test_keys_returns_non_private_attrs(self):
        cfg = BaseConfig()
        cfg.some_attr = "val"
        keys = cfg.keys()
        assert "some_attr" in keys


class TestSnowflakeAuthenticatorType(unittest.TestCase):
    """Tests for SnowflakeAuthenticatorType."""

    def test_str_returns_value(self):
        assert str(SnowflakeAuthenticatorType.SNOWFLAKE) == "snowflake"
        assert str(SnowflakeAuthenticatorType.EXTERNAL_BROWSER) == "externalbrowser"


class TestConnectionType(unittest.TestCase):
    """Tests for ConnectionType enum."""

    def test_str_returns_value(self):
        assert str(ConnectionType.S3) == "s3"
        assert str(ConnectionType.BLOB) == "blob"


class TestApiConfig(unittest.TestCase):
    """Tests for ApiConfig."""

    def test_valid_key(self):
        cfg = ApiConfig(key="abc123")
        assert cfg.key == "abc123"

    def test_invalid_key_raises(self):
        from pydantic import ValidationError

        with self.assertRaises(ValidationError):
            ApiConfig(key="bad\x00key")

    def test_repr(self):
        cfg = ApiConfig(key="secret")
        assert "***" in repr(cfg)


class TestSnowflakeStoredProcedureConfig(unittest.TestCase):
    """Tests for SnowflakeStoredProcedureConfig."""

    def test_valid_connection_name(self):
        cfg = SnowflakeStoredProcedureConfig(connection_name="my_conn")
        assert cfg.connection_name == "my_conn"

    def test_spcs_connection_name(self):
        cfg = SnowflakeStoredProcedureConfig(connection_name="@SPCS_CONNECTION")
        assert cfg.connection_name == "@SPCS_CONNECTION"

    def test_invalid_connection_name_raises(self):
        from pydantic import ValidationError

        with self.assertRaises(ValidationError):
            SnowflakeStoredProcedureConfig(connection_name="bad\x00name")

    def test_repr(self):
        cfg = SnowflakeStoredProcedureConfig(connection_name="test_conn")
        assert "test_conn" in repr(cfg)


if __name__ == "__main__":
    unittest.main()
