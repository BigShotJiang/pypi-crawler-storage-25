"""Tests for the query tag helpers in sf_connection and task manager integration."""

import json
import threading
import unittest
from unittest.mock import MagicMock, Mock, patch

from data_exchange_agent.constants import task_keys
from data_exchange_agent.data_sources.sf_connection import (
    SnowflakeDataSource,
    build_query_tag,
)
from data_exchange_agent.tasks import manager as manager_mod

try:
    from data_exchange_agent.tasks.data_validation.handler import DataValidationHandler

    HANDLER_AVAILABLE = True
except ImportError:
    HANDLER_AVAILABLE = False


class TestBuildQueryTag(unittest.TestCase):
    """Tests for build_query_tag JSON construction."""

    def test_workflow_and_task_ids(self):
        tag = build_query_tag(workflow_id=42, task_id=1017)
        parsed = json.loads(tag)
        assert parsed == {"DMVF_WORKFLOW_ID": "42", "DMVF_TASK_ID": "1017"}

    def test_omits_none_values(self):
        tag = build_query_tag(workflow_id=None, task_id=None)
        assert json.loads(tag) == {}

    def test_extra_tags(self):
        tag = build_query_tag(DMVF_VERSION="1.10.0")
        parsed = json.loads(tag)
        assert parsed == {"DMVF_VERSION": "1.10.0"}

    def test_combined_task_and_worker_version(self):
        tag = build_query_tag(workflow_id=1, task_id=2, DMVF_WORKER_VERSION="1.10.0")
        parsed = json.loads(tag)
        assert parsed == {
            "DMVF_WORKFLOW_ID": "1",
            "DMVF_TASK_ID": "2",
            "DMVF_WORKER_VERSION": "1.10.0",
        }

    def test_coerces_ints_to_strings(self):
        tag = build_query_tag(workflow_id=99, task_id=100)
        parsed = json.loads(tag)
        assert parsed["DMVF_WORKFLOW_ID"] == "99"
        assert parsed["DMVF_TASK_ID"] == "100"

    def test_compact_json(self):
        tag = build_query_tag(workflow_id=1, task_id=2)
        assert " " not in tag


def _make_manager() -> manager_mod.TaskManager:
    """Create a TaskManager with mocked DI dependencies for unit testing."""
    with patch.object(manager_mod.TaskManager, "__init__", lambda self, **kwargs: None):
        m = manager_mod.TaskManager()
    m.logger = Mock()
    m.stop_workers = False
    m.task_source_adapter = Mock()
    m.task_fetch_interval = 5
    m._last_empty_pull_time = 0.0
    m._throttle_lock = threading.Lock()
    m._pull_lock = threading.Semaphore(2)
    m._stop_event = threading.Event()
    m._contention_counts: dict[str, int] = {}
    m.snowflake_datasource = Mock()
    m.source_connections_config = {}
    m.target_connections_config = {}
    m.lease_refresher = Mock()
    m._local_results_directory = None
    return m


class TestProcessTaskQueryTag(unittest.TestCase):
    """Verify that process_task sets and restores query tags."""

    def test_sets_task_tag_before_handler(self):
        m = _make_manager()
        task = {
            task_keys.ID: "77",
            task_keys.WORKFLOW_ID: "42",
            task_keys.KIND: task_keys.DATA_VALIDATION,
            task_keys.PAYLOAD: {},
        }

        with patch.object(m, "_process_data_validation_task"):
            m.process_task(task)

        calls = m.snowflake_datasource.set_query_tag.call_args_list
        assert len(calls) == 2

        # First call: task-level tag
        task_tag = json.loads(calls[0][0][0])
        assert task_tag["DMVF_WORKFLOW_ID"] == "42"
        assert task_tag["DMVF_TASK_ID"] == "77"
        assert "DMVF_WORKER_VERSION" in task_tag

        # Second call: baseline restore
        baseline_tag = json.loads(calls[1][0][0])
        assert "DMVF_VERSION" in baseline_tag
        assert "DMVF_WORKFLOW_ID" not in baseline_tag

    def test_restores_baseline_on_handler_error(self):
        m = _make_manager()
        task = {
            task_keys.ID: "88",
            task_keys.WORKFLOW_ID: "50",
            task_keys.KIND: task_keys.DATA_VALIDATION,
            task_keys.PAYLOAD: {},
        }

        with patch.object(m, "_process_data_validation_task", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                m.process_task(task)

        calls = m.snowflake_datasource.set_query_tag.call_args_list
        assert len(calls) == 2
        baseline_tag = json.loads(calls[1][0][0])
        assert "DMVF_VERSION" in baseline_tag

    def test_handles_missing_workflow_id(self):
        m = _make_manager()
        task = {
            task_keys.ID: "99",
            task_keys.KIND: task_keys.DATA_VALIDATION,
            task_keys.PAYLOAD: {},
        }

        with patch.object(m, "_process_data_validation_task"):
            m.process_task(task)

        task_tag = json.loads(m.snowflake_datasource.set_query_tag.call_args_list[0][0][0])
        assert "DMVF_WORKFLOW_ID" not in task_tag
        assert task_tag["DMVF_TASK_ID"] == "99"

    def test_passes_query_tag_to_validation_handler(self):
        """process_task passes the built tag to _process_data_validation_task."""
        m = _make_manager()
        task = {
            task_keys.ID: "55",
            task_keys.WORKFLOW_ID: "10",
            task_keys.KIND: task_keys.DATA_VALIDATION,
            task_keys.PAYLOAD: {},
        }

        with patch.object(m, "_process_data_validation_task") as mock_dv:
            m.process_task(task)

        mock_dv.assert_called_once()
        _, kwargs = mock_dv.call_args
        tag_json = kwargs["query_tag"]
        parsed = json.loads(tag_json)
        assert parsed["DMVF_WORKFLOW_ID"] == "10"
        assert parsed["DMVF_TASK_ID"] == "55"
        assert "DMVF_WORKER_VERSION" in parsed


@unittest.skipUnless(HANDLER_AVAILABLE, "handler not importable")
class TestHandlerEnsureQueryTag(unittest.TestCase):
    """Verify that DataValidationHandler applies the tag before Snowflake queries."""

    def _make_handler(self, tag=None):
        """Create a handler bypassing __init__ to avoid SDV transitive imports."""
        mock_sf = Mock()
        handler = object.__new__(DataValidationHandler)
        handler.logger = Mock()
        handler.snowflake_datasource = mock_sf
        handler.source_connections_config = {}
        handler._query_tag = tag
        handler._row_validator = Mock()
        handler._cell_validator = Mock()
        return handler, mock_sf

    def test_ensure_query_tag_calls_set_query_tag(self):
        tag = build_query_tag(workflow_id=1, task_id=2, DMVF_WORKER_VERSION="1.0.0")
        handler, mock_sf = self._make_handler(tag)
        handler._ensure_query_tag()
        mock_sf.set_query_tag.assert_called_once_with(tag)

    def test_ensure_query_tag_noop_when_no_tag(self):
        handler, mock_sf = self._make_handler(tag=None)
        handler._ensure_query_tag()
        mock_sf.set_query_tag.assert_not_called()

    def test_run_target_query_applies_tag(self):
        tag = build_query_tag(workflow_id=1, task_id=2, DMVF_WORKER_VERSION="1.0.0")
        handler, mock_sf = self._make_handler(tag)
        mock_cursor = Mock()
        mock_cursor.description = [("COL1",)]
        mock_cursor.fetchmany.return_value = []
        mock_sf.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_sf.get_cursor.return_value.__exit__ = Mock(return_value=False)

        handler._run_target_query("SELECT 1")
        mock_sf.set_query_tag.assert_called_with(tag)

    def test_upload_to_stage_applies_tag(self):
        tag = build_query_tag(workflow_id=5, task_id=6, DMVF_WORKER_VERSION="1.0.0")
        handler, mock_sf = self._make_handler(tag)
        mock_cursor = Mock()
        mock_sf.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_sf.get_cursor.return_value.__exit__ = Mock(return_value=False)

        handler._upload_to_stage("/tmp/file.csv", "@stage/path")
        mock_sf.set_query_tag.assert_called_with(tag)

    def test_execute_target_statement_applies_tag(self):
        tag = build_query_tag(workflow_id=7, task_id=8, DMVF_WORKER_VERSION="1.0.0")
        handler, mock_sf = self._make_handler(tag)
        mock_cursor = Mock()
        mock_sf.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_sf.get_cursor.return_value.__exit__ = Mock(return_value=False)

        handler._execute_target_statement("CREATE TABLE t (id INT)")
        mock_sf.set_query_tag.assert_called_with(tag)

    def test_get_target_row_count_applies_tag(self):
        tag = build_query_tag(workflow_id=9, task_id=10, DMVF_WORKER_VERSION="1.0.0")
        handler, mock_sf = self._make_handler(tag)
        mock_cursor = Mock()
        mock_cursor.fetchone.return_value = (42,)
        mock_sf.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_sf.get_cursor.return_value.__exit__ = Mock(return_value=False)

        count = handler._get_target_row_count("DB.SCHEMA.TABLE")
        assert count == 42
        mock_sf.set_query_tag.assert_called_with(tag)


class TestSetQueryTagStoresInThreadLocal(unittest.TestCase):
    """Verify that set_query_tag persists the tag in _local.current_tag."""

    def _make_datasource(self):
        with patch.object(SnowflakeDataSource, "__init__", lambda self, **kw: None):
            ds = SnowflakeDataSource()
        ds._local = threading.local()
        ds.logger = Mock()
        return ds

    def test_set_query_tag_stores_current_tag(self):
        ds = self._make_datasource()
        mock_cursor = Mock()
        mock_conn = Mock()
        mock_conn.cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = Mock(return_value=False)
        ds._local.connection = mock_conn

        tag = '{"DMVF_TASK_ID":"123"}'
        ds.set_query_tag(tag)
        assert ds._local.current_tag == tag

    def test_current_tag_survives_connection_reset(self):
        """When connection is set to None and recreated, current_tag persists."""
        ds = self._make_datasource()
        ds._local.current_tag = '{"DMVF_TASK_ID":"42"}'
        ds._local.connection = None

        assert getattr(ds._local, "current_tag", None) == '{"DMVF_TASK_ID":"42"}'


class TestSetQueryTagSwallowsException(unittest.TestCase):
    """set_query_tag should not raise even when the connection is broken."""

    def _make_datasource(self):
        with patch.object(SnowflakeDataSource, "__init__", lambda self, **kw: None):
            ds = SnowflakeDataSource()
        ds._local = threading.local()
        ds.logger = Mock()
        return ds

    def test_swallows_cursor_exception(self):
        ds = self._make_datasource()
        mock_conn = Mock()
        mock_conn.is_closed.return_value = False
        mock_conn.cursor.side_effect = RuntimeError("connection lost")
        ds._local.connection = mock_conn

        ds.set_query_tag('{"test":"tag"}')
        assert ds._local.current_tag == '{"test":"tag"}'


class TestClearQueryTag(unittest.TestCase):
    """Verify clear_query_tag sends ALTER SESSION UNSET."""

    def _make_datasource(self):
        with patch.object(SnowflakeDataSource, "__init__", lambda self, **kw: None):
            ds = SnowflakeDataSource()
        ds._local = threading.local()
        ds.logger = Mock()
        return ds

    def test_executes_unset(self):
        ds = self._make_datasource()
        mock_cursor = Mock()
        mock_conn = Mock()
        mock_conn.is_closed.return_value = False
        mock_conn.cursor.return_value = mock_cursor
        ds._local.connection = mock_conn

        ds.clear_query_tag()
        mock_cursor.execute.assert_called_once_with("ALTER SESSION UNSET QUERY_TAG")

    def test_swallows_exception(self):
        ds = self._make_datasource()
        mock_conn = Mock()
        mock_conn.is_closed.return_value = False
        mock_conn.cursor.side_effect = RuntimeError("dead")
        ds._local.connection = mock_conn

        ds.clear_query_tag()


class TestEscapeFunction(unittest.TestCase):
    """Tests for the _escape helper in sf_connection."""

    def test_no_quotes(self):
        from data_exchange_agent.data_sources.sf_connection import _escape

        assert _escape("hello") == "hello"

    def test_single_quote_doubled(self):
        from data_exchange_agent.data_sources.sf_connection import _escape

        assert _escape("it's") == "it''s"

    def test_empty_string(self):
        from data_exchange_agent.data_sources.sf_connection import _escape

        assert _escape("") == ""


class TestGetThreadConnectionAppliesTag(unittest.TestCase):
    """Verify that _get_thread_connection applies the baseline or current tag."""

    def _make_datasource(self):
        with patch.object(SnowflakeDataSource, "__init__", lambda self, **kw: None):
            ds = SnowflakeDataSource()
        ds._local = threading.local()
        ds.logger = Mock()
        return ds

    @patch("data_exchange_agent.data_sources.sf_connection.initialize_telemetry_if_needed")
    def test_applies_baseline_tag_on_new_connection(self, _mock_telemetry):
        ds = self._make_datasource()
        mock_conn = Mock()
        mock_cursor = Mock()
        mock_conn.cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = Mock(return_value=False)

        with patch.object(ds, "_create_connection", return_value=mock_conn):
            ds._get_thread_connection()

        sql = mock_cursor.execute.call_args[0][0]
        assert "ALTER SESSION SET QUERY_TAG" in sql
        tag = json.loads(sql.split("'", 1)[1].rsplit("'", 1)[0])
        assert "DMVF_VERSION" in tag

    @patch("data_exchange_agent.data_sources.sf_connection.initialize_telemetry_if_needed")
    def test_applies_current_tag_on_reconnect(self, _mock_telemetry):
        ds = self._make_datasource()
        ds._local.current_tag = '{"DMVF_TASK_ID":"42","DMVF_WORKFLOW_ID":"7"}'

        mock_conn = Mock()
        mock_cursor = Mock()
        mock_conn.cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = Mock(return_value=False)

        with patch.object(ds, "_create_connection", return_value=mock_conn):
            ds._get_thread_connection()

        sql = mock_cursor.execute.call_args[0][0]
        tag = json.loads(sql.split("'", 1)[1].rsplit("'", 1)[0])
        assert tag["DMVF_TASK_ID"] == "42"
        assert tag["DMVF_WORKFLOW_ID"] == "7"

    @patch("data_exchange_agent.data_sources.sf_connection.initialize_telemetry_if_needed")
    def test_tag_failure_does_not_prevent_connection(self, _mock_telemetry):
        ds = self._make_datasource()
        mock_conn = Mock()
        mock_conn.cursor.side_effect = RuntimeError("cursor failed")

        with patch.object(ds, "_create_connection", return_value=mock_conn):
            result = ds._get_thread_connection()

        assert result is mock_conn


class TestSnowflakeDataSourceIsClosedAndClose(unittest.TestCase):
    """Tests for is_closed() and close_connection() on SnowflakeDataSource."""

    def _make_datasource(self):
        with patch.object(SnowflakeDataSource, "__init__", lambda self, **kw: None):
            ds = SnowflakeDataSource()
        ds._local = threading.local()
        ds.logger = Mock()
        return ds

    def test_is_closed_true_when_no_connection(self):
        ds = self._make_datasource()
        assert ds.is_closed() is True

    def test_is_closed_true_when_connection_is_none(self):
        ds = self._make_datasource()
        ds._local.connection = None
        assert ds.is_closed() is True

    def test_is_closed_delegates_to_connection(self):
        ds = self._make_datasource()
        mock_conn = Mock()
        mock_conn.is_closed.return_value = False
        ds._local.connection = mock_conn
        assert ds.is_closed() is False

    def test_close_connection_closes_and_nullifies(self):
        ds = self._make_datasource()
        mock_conn = Mock()
        ds._local.connection = mock_conn

        ds.close_connection()

        mock_conn.close.assert_called_once()
        assert ds._local.connection is None

    def test_close_connection_noop_when_no_connection(self):
        ds = self._make_datasource()
        ds.close_connection()

    def test_close_connection_handles_close_exception(self):
        ds = self._make_datasource()
        mock_conn = Mock()
        mock_conn.close.side_effect = RuntimeError("close error")
        ds._local.connection = mock_conn

        ds.close_connection()

        assert ds._local.connection is None
        ds.logger.error.assert_called()


class TestSnowflakeDataSourceContextManager(unittest.TestCase):
    """Tests for __enter__/__exit__ on SnowflakeDataSource."""

    def _make_datasource(self):
        with patch.object(SnowflakeDataSource, "__init__", lambda self, **kw: None):
            ds = SnowflakeDataSource()
        ds._local = threading.local()
        ds.logger = Mock()
        return ds

    def test_enter_creates_connection_and_returns_self(self):
        ds = self._make_datasource()
        ds.create_connection = Mock()

        result = ds.__enter__()

        ds.create_connection.assert_called_once()
        assert result is ds

    def test_exit_closes_connection(self):
        ds = self._make_datasource()
        ds.close_connection = Mock()

        ds.__exit__(None, None, None)

        ds.close_connection.assert_called_once()


class TestSnowflakeDataSourceExecuteStatement(unittest.TestCase):
    """Tests for execute_statement on SnowflakeDataSource."""

    def _make_datasource(self):
        with patch.object(SnowflakeDataSource, "__init__", lambda self, **kw: None):
            ds = SnowflakeDataSource()
        ds._local = threading.local()
        ds.logger = Mock()
        return ds

    def test_executes_statement_and_yields_results(self):
        ds = self._make_datasource()
        mock_cursor = Mock()
        mock_cursor.execute.return_value = [{"A": 1}, {"A": 2}]
        mock_conn = Mock()
        mock_conn.is_closed.return_value = False
        mock_conn.cursor.return_value = mock_cursor
        ds._local.connection = mock_conn

        results = list(ds.execute_statement("SELECT 1"))

        assert len(results) == 2
        mock_cursor.execute.assert_called_once_with("SELECT 1")

    def test_executes_statement_with_params(self):
        ds = self._make_datasource()
        mock_cursor = Mock()
        mock_cursor.execute.return_value = [{"A": 1}]
        mock_conn = Mock()
        mock_conn.is_closed.return_value = False
        mock_conn.cursor.return_value = mock_cursor
        ds._local.connection = mock_conn

        list(ds.execute_statement("SELECT %s", ("val",)))

        mock_cursor.execute.assert_called_once_with("SELECT %s", ("val",))

    def test_retries_on_session_expired(self):
        from snowflake.connector import errors as sf_errors

        ds = self._make_datasource()
        ds.connection_name = "test"

        mock_cursor_bad = Mock()
        err = sf_errors.ProgrammingError(msg="session expired", errno=390111)
        mock_cursor_bad.execute.side_effect = err

        mock_cursor_good = Mock()
        mock_cursor_good.execute.return_value = [{"OK": True}]

        mock_conn_bad = Mock()
        mock_conn_bad.is_closed.return_value = False
        mock_conn_bad.cursor.return_value = mock_cursor_bad

        mock_conn_good = Mock()
        mock_conn_good.is_closed.return_value = False
        mock_conn_good.cursor.return_value = mock_cursor_good

        ds._local.connection = mock_conn_bad
        with patch.object(ds, "_create_connection", return_value=mock_conn_good):
            results = list(ds.execute_statement("SELECT 1"))

        assert len(results) == 1

    def test_propagates_non_session_error(self):
        from snowflake.connector import errors as sf_errors

        ds = self._make_datasource()
        mock_cursor = Mock()
        err = sf_errors.ProgrammingError(msg="syntax error", errno=1003)
        mock_cursor.execute.side_effect = err
        mock_conn = Mock()
        mock_conn.is_closed.return_value = False
        mock_conn.cursor.return_value = mock_cursor
        ds._local.connection = mock_conn

        with self.assertRaises(sf_errors.ProgrammingError):
            list(ds.execute_statement("BAD SQL"))


class TestSnowflakeDataSourceExecuteMultipleStatements(unittest.TestCase):
    """Tests for execute_multiple_statements."""

    def _make_datasource(self):
        with patch.object(SnowflakeDataSource, "__init__", lambda self, **kw: None):
            ds = SnowflakeDataSource()
        ds._local = threading.local()
        ds.logger = Mock()
        return ds

    def test_executes_multiple_statements(self):
        ds = self._make_datasource()
        mock_cursor = Mock()
        mock_cursor.execute.side_effect = [
            [{"A": 1}],
            [{"B": 2}],
        ]
        mock_conn = Mock()
        mock_conn.is_closed.return_value = False
        mock_conn.cursor.return_value = mock_cursor
        ds._local.connection = mock_conn

        results = ds.execute_multiple_statements(["SELECT 1", "SELECT 2"])

        assert len(results) == 2

    def test_retries_on_session_expired(self):
        from snowflake.connector import errors as sf_errors

        ds = self._make_datasource()
        ds.connection_name = "test"

        mock_cursor_bad = Mock()
        err = sf_errors.ProgrammingError(msg="expired", errno=390111)
        mock_cursor_bad.execute.side_effect = err

        mock_cursor_good = Mock()
        mock_cursor_good.execute.return_value = [{"OK": True}]

        mock_conn_bad = Mock()
        mock_conn_bad.is_closed.return_value = False
        mock_conn_bad.cursor.return_value = mock_cursor_bad

        mock_conn_good = Mock()
        mock_conn_good.is_closed.return_value = False
        mock_conn_good.cursor.return_value = mock_cursor_good

        ds._local.connection = mock_conn_bad
        with patch.object(ds, "_create_connection", return_value=mock_conn_good):
            results = ds.execute_multiple_statements(["SELECT 1"])

        assert len(results) == 1


class TestGetTasksPropagatesWorkflowId(unittest.TestCase):
    """Verify that get_tasks includes workflow_id in task dicts."""

    def _make_adapter(self):
        from data_exchange_agent.task_sources.snowflake_stored_procedure import (
            SnowflakeStoredProcedureTaskSourceAdapter,
        )

        mock_config = MagicMock()
        mock_config.__getitem__.side_effect = lambda key: {
            "application.agent_id": "test_agent",
        }[key]
        mock_config.get.side_effect = lambda key, default=None: default

        mock_sf = MagicMock()
        mock_sf.is_closed.return_value = False

        adapter = SnowflakeStoredProcedureTaskSourceAdapter(
            program_config=mock_config,
            snowflake_datasource=mock_sf,
        )
        return adapter, mock_sf

    def test_data_movement_task_has_workflow_id(self):
        adapter, mock_sf = self._make_adapter()
        mock_sf.execute_statement.return_value = [
            {
                "ID": "1",
                "WORKFLOW_ID": "42",
                "PAYLOAD": json.dumps(
                    {
                        "source_type": "sqlserver",
                        "database": "db",
                        "schema": "dbo",
                        "statement_location_id": "SELECT 1",
                        "target_type": "s3",
                        "target_id": "s3://bucket/path",
                    }
                ),
            }
        ]
        tasks = adapter.get_tasks()
        assert len(tasks) == 1
        assert tasks[0][task_keys.WORKFLOW_ID] == "42"

    def test_data_validation_task_has_workflow_id(self):
        adapter, mock_sf = self._make_adapter()
        mock_sf.execute_statement.return_value = [
            {
                "ID": "2",
                "WORKFLOW_ID": "99",
                "PAYLOAD": json.dumps(
                    {
                        "kind": "data_validation",
                        "some_key": "some_value",
                    }
                ),
            }
        ]
        tasks = adapter.get_tasks()
        assert len(tasks) == 1
        assert tasks[0][task_keys.WORKFLOW_ID] == "99"
