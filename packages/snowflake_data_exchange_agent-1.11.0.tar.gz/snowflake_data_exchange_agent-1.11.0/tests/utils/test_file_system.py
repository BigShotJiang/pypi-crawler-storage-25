"""Tests for file_system utility functions."""

import os
import tempfile
import unittest

from data_exchange_agent.utils.file_system import (
    delete_file,
    delete_folder_file,
    file_exists,
)


class TestDeleteFolderFile(unittest.TestCase):
    """Tests for delete_folder_file."""

    def test_deletes_single_file(self):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
            f.write(b"data")

        delete_folder_file(path)
        self.assertFalse(os.path.exists(path))

    def test_deletes_folder_with_files(self):
        d = tempfile.mkdtemp()
        open(os.path.join(d, "a.txt"), "w").close()
        open(os.path.join(d, "b.txt"), "w").close()

        delete_folder_file(d)
        self.assertFalse(os.path.exists(d))

    def test_deletes_nested_folders(self):
        d = tempfile.mkdtemp()
        sub = os.path.join(d, "sub")
        os.makedirs(sub)
        open(os.path.join(sub, "nested.txt"), "w").close()

        delete_folder_file(d)
        self.assertFalse(os.path.exists(d))

    def test_nonexistent_path_is_noop(self):
        delete_folder_file("/tmp/nonexistent_xyz_abc_123")


class TestDeleteFile(unittest.TestCase):
    """Tests for delete_file."""

    def test_deletes_existing_file(self):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name

        delete_file(path)
        self.assertFalse(os.path.exists(path))

    def test_nonexistent_file_is_noop(self):
        delete_file("/tmp/nonexistent_file_xyz_abc")


class TestFileExists(unittest.TestCase):
    """Tests for file_exists."""

    def test_returns_true_for_existing_file(self):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            path = f.name
        try:
            self.assertTrue(file_exists(path))
        finally:
            os.unlink(path)

    def test_returns_false_for_nonexistent_file(self):
        self.assertFalse(file_exists("/tmp/no_such_file_xyz"))


if __name__ == "__main__":
    unittest.main()
