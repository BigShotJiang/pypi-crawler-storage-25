"""Tests for BaseODBCConnectionConfig validation methods."""

import unittest

from pydantic import ValidationError

from data_exchange_agent.config.sections.connections.odbc.sqlserver import (
    SQLServerConnectionConfig,
)


def _make_config(**overrides):
    """Build a minimal SQLServerConnectionConfig (concrete subclass of BaseODBCConnectionConfig)."""
    defaults = dict(
        driver_name="ODBC Driver 18 for SQL Server",
        username="user",
        password="pass",
        database="testdb",
        host="127.0.0.1",
        port=1433,
        auto_detect_driver=False,
    )
    defaults.update(overrides)
    return SQLServerConnectionConfig(**defaults)


class TestHostValidation(unittest.TestCase):
    """Tests for _validate_host in BaseODBCConnectionConfig."""

    def test_valid_ip_address(self):
        cfg = _make_config(host="192.168.1.1")
        assert cfg.host == "192.168.1.1"

    def test_valid_dns_name(self):
        cfg = _make_config(host="mydb.example.com")
        assert cfg.host == "mydb.example.com"

    def test_valid_localdb_format(self):
        cfg = _make_config(host="(localdb)\\MSSQLLocalDB")
        assert cfg.host == "(localdb)\\MSSQLLocalDB"

    def test_valid_named_instance(self):
        cfg = _make_config(host="sql777snow\\SQLSERVER")
        assert cfg.host == "sql777snow\\SQLSERVER"

    def test_host_too_long_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(host="a" * 256)

    def test_empty_host_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(host="")

    def test_host_invalid_chars_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(host="host name with spaces")

    def test_host_leading_dot_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(host=".example.com")

    def test_host_trailing_dot_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(host="example.com.")

    def test_host_adjacent_dots_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(host="example..com")

    def test_host_label_starting_with_hyphen_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(host="-example.com")

    def test_host_label_ending_with_hyphen_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(host="example-.com")


class TestExtraOptionsValidation(unittest.TestCase):
    """Tests for _validate_extra_options in BaseODBCConnectionConfig."""

    def test_valid_extra_options(self):
        cfg = _make_config(extra_options={"TrustServerCertificate": "yes"})
        assert cfg.extra_options["TrustServerCertificate"] == "yes"

    def test_empty_key_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(extra_options={"": "value"})

    def test_whitespace_key_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(extra_options={"  ": "value"})

    def test_none_value_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(extra_options={"key": None})

    def test_empty_string_value_raises(self):
        with self.assertRaises(ValidationError):
            _make_config(extra_options={"key": "  "})


class TestValidateRequiredField(unittest.TestCase):
    """Tests for _validate_required_field in BaseODBCConnectionConfig."""

    def test_none_value_returns_error(self):
        cfg = _make_config()
        result = cfg._validate_required_field(None, "field")
        assert result is not None
        assert "None" in result

    def test_empty_string_returns_error(self):
        cfg = _make_config()
        result = cfg._validate_required_field("", "field")
        assert result is not None
        assert "empty" in result

    def test_whitespace_only_returns_error(self):
        cfg = _make_config()
        result = cfg._validate_required_field("   ", "field")
        assert result is not None
        assert "whitespace" in result

    def test_valid_value_returns_none(self):
        cfg = _make_config()
        result = cfg._validate_required_field("good", "field")
        assert result is None

    def test_non_string_value_returns_none(self):
        cfg = _make_config()
        result = cfg._validate_required_field(42, "field")
        assert result is None


if __name__ == "__main__":
    unittest.main()
