# ======================================== IMPORTS ========================================
from __future__ import annotations

from .._internal import expect, CallbackList

from ..abc import Component

from ._component import *

import uuid
from typing import Type, overload

# ======================================== CONSTANTS ========================================
_COMPONENTS: dict[Component, str] = {
    Transform: "_transform",
    Follow: "_follow",
    Collider: "_collider",
    RigidBody: "_rigid_body",
    GroundSensor: "_ground_sensor",
    ShapeRenderer: "_shape_renderer",
    SpriteRenderer: "_sprite_renderer",
    TextRenderer: "_text_renderer",
    Animator: "_animator",
    TrailRenderer: "_trail_renderer",
    SoundEmitter: "_sound_emitter",
    VideoPlayer: "_video_player",
}

# ======================================== OBJECT ========================================
class Entity:
    """
    Classe représentant les entités en accumulant des composants

    Args:
        components: ensemble des composants de l'entité
        tags: labels de l'entité
    """
    __slots__ = (
        "_id", "_tags", "_active", "_dead",
        "_on_activate", "_on_deactivate", "_on_kill",
        *_COMPONENTS.values()
        )

    def __init__(self, *components: Component, tags: tuple[str, ...] = ()):
        # Transtypage et vérifications
        tags = set(map(str, tags))

        if __debug__:
            expect(components, tuple[Component])

        # Attributs publiques
        self._tags: set[str] = set(tags)

        # Attributs internes
        self._id: str = str(uuid.uuid4())
        self._active: bool = True
        self._dead: bool = False

        # Callbacks
        self._on_activate: CallbackList = None
        self._on_deactivate: CallbackList = None
        self._on_kill: CallbackList = None

        # Composants
        self._transform: Transform = None
        self._follow: Follow = None
        self._shape_renderer: ShapeRenderer = None
        self._sprite_renderer: SpriteRenderer = None
        self._text_renderer: TextRenderer = None
        self._collider: Collider = None
        self._rigid_body: RigidBody = None
        self._ground_sensor: GroundSensor = None
        self._animator: Animator = None
        self._trail_renderer: TrailRenderer = None
        self._sound_emitter: SoundEmitter = None
        self._video_player: VideoPlayer = None

        for component in components:
            self.add(component)
    
    # ======================================== CONVERSIONS ========================================
    def __repr__(self) -> str:
        """Renvoie une représentation de l'entité"""
        components = ", ".join(str(component) for c in _COMPONENTS.values() if (component := getattr(self, c)) is not None)
        return f"Entity(id={self._id[:8]}..., tags={self._tags}, components=[{components}])"
    
    def __hash__(self) -> int:
        """Renvoie l'entier hashé de l'entité"""
        return hash(self._id)
    
    # ======================================== PROPERTIES ========================================
    @property
    def id(self) -> str:
        """Renvoie l'identifiant de l'entité *(lecture seule)*"""
        return self._id
    
    @property
    def tags(self) -> set[str]:
        """Renvoie les labels de l'entité *(lecture seule)*"""
        return self._tags
    
    @property
    def transform(self) -> Transform | None:
        """Composant ``Transform`` *(lecture seule)*"""
        return self._transform
    
    @property
    def follow(self) -> Follow | None:
        """Composant ``Follow`` *(lecture seule)*"""
        return self._follow
    
    @property
    def shape_renderer(self) -> ShapeRenderer | None:
        """Composant ``ShapeRenderer`` *(lecture seule)*"""
        return self._shape_renderer
    
    @property
    def sprite_renderer(self) -> SpriteRenderer | None:
        """Composant ``SpriteRenderer`` *(lecture seule)*"""
        return self._sprite_renderer
    
    @property
    def text_renderer(self) -> TextRenderer | None:
        """Composant ``TextRenderer`` *(lecture seule)*"""
        return self._text_renderer
    
    @property
    def collider(self) -> Collider | None:
        """Composant ``Collider`` *(lecture seule)*"""
        return self._collider
    
    @property
    def rigid_body(self) -> RigidBody | None:
        """Composant ``RigidBody`` *(lecture seule)*"""
        return self._rigid_body
    
    @property
    def ground_sensor(self) -> GroundSensor | None:
        """Composant ``GroundSensor`` *(lecture seule)*"""
        return self._ground_sensor
    
    @property
    def animator(self) -> Animator | None:
        """Composant ``Animator`` *(lecture seule)*"""
        return self._animator
    
    @property
    def trail_renderer(self) -> TrailRenderer | None:
        """Composant ``TrailRenderer`` *(lecture seule)*"""
    
    @property
    def sound_emitter(self) -> SoundEmitter | None:
        """Composant ``SoundEmitter`` *(lecture seule)*"""
        return self._sound_emitter
    
    @property
    def video_player(self) -> VideoPlayer | None:
        """Composant ``VideoPlayer`` *(lecture seule)*"""
        return self._video_player

    # ======================================== PREDICATES ========================================
    def __eq__(self, other: Entity) -> bool:
        """Vérifie la correspondance de deux entités"""
        if isinstance(other, Entity):
            return self._id == other._id
        return False
    
    def is_active(self) -> bool:
        """Vérifie l'activité de l'entité"""
        return self._active
    
    def is_dead(self) -> bool:
        """Vérifie l'état de l'entité"""
        return self._dead
    
    # ======================================== HOOKS ========================================
    @property
    def on_activate(self) -> CallbackList:
        """Hook d'activation"""
        if self._on_activate is None:
            self._on_activate = CallbackList()
        return self._on_activate
    
    @property
    def on_deactive(self) -> CallbackList:
        """Hook de désactivation"""
        if self._on_deactivate is None:
            self._on_deactivate = CallbackList()
        return self._on_deactivate
    
    @property
    def on_kill(self) -> CallbackList:
        """Hook de mort"""
        if self._on_kill is None:
            self._on_kill = CallbackList()
        return self._on_kill
    
    # ======================================== INTERFACE ========================================
    def activate(self):
        """Active l'entité"""
        if self._active:
            return
        self._active = True
        if self._on_activate:
            self._on_activate.trigger()

    def deactivate(self):
        """Désactive l'entité"""
        if not self._active:
            return
        self._active = False
        if self._on_deactivate:
            self._on_deactivate.trigger()

    def kill(self) -> None:
        """Détruit l'entité"""
        if self._dead:
            return
        self._active = False
        self.clear()
        self._dead = True
        if self._on_kill:
            self._on_kill.trigger()
    
    # ======================================== COMPONENTS ========================================
    def add(self, component: Component) -> Entity:
        """Ajoute un composant à l'entité

        Args:
            component: composant à ajouter
        """
        T = type(expect(component, Component))
        all_types = self.get_all_types()

        # Exclusivité
        if T in all_types:
            raise ValueError(f"Can only have 1 {T.__name__} component")

        # Prérequis
        for req in component._REQUIRES:
            if not any(c.__name__ == req for c in all_types):
                raise ValueError(f"{T.__name__} requires {req}")

        # Conflits
        for conflict in component._CONFLICTS:
            if any(c.__name__ == conflict for c in all_types):
                raise ValueError(f"{T.__name__} conflicts with {conflict}")
            
        setattr(self, _COMPONENTS[T], component)
        return self
    
    @overload
    def remove(self, component_type: Type[Component]) -> None: ...

    @overload
    def remove(self, component_id: str) -> None: ...
    
    def remove(self, component_type: Type[Component] | str) -> None:
        """Supprime un composant de l'entité

        Args:
            component_type: type du composant
        """
        if isinstance(component_type, str):
            if component_type not in _COMPONENTS:
                raise ValueError(f"Entity has no {component_type} component")
            setattr(self, f"_{component_type}", None)
        else:
            if component_type not in self.get_all_types():
                raise ValueError(f"Entity has no {component_type} component")
            setattr(self, _COMPONENTS[component_type], None)
    
    def clear(self) -> None:
        """Supprime l'ensemble des composants"""
        for component in _COMPONENTS.values():
            setattr(self, component, None)
    
    @overload
    def get(self, component_type: Type[Component]) -> Component: ...

    @overload
    def get(self, component_id: str) -> Component: ...
    
    def get(self, component_type: Type[Component] | str) -> Component:
        """Renvoie un composant de l'entité

        Args:
            component_type: type du composant
        """
        if isinstance(component_type, str):
            return getattr(self, component_type, None)
        return getattr(self, _COMPONENTS[component_type], None)
    
    def get_all(self) -> tuple[Component, ...]:
        """Renvoie l'ensemble des composants de l'entité"""
        return tuple(component for name in _COMPONENTS.values() if (component := getattr(self, name)) is not None)
    
    def get_all_types(self) -> tuple[Component, ...]:
        """Renvoie l'ensemble des types de composant possédés"""
        return tuple(T for T in _COMPONENTS if getattr(self, _COMPONENTS[T]) is not None)
    
    @overload
    def has(self, component_type: Type[Component]) -> bool: ...

    @overload
    def has(self, component_id: str) -> bool: ...
    
    def has(self, component_type: Type[Component] | str) -> bool:
        """Vérifie la possession d'un composant

        Args:
            component_type: type du composant
        """
        if type(component_type) is str:
            attr_name = f"_{component_type.lower()}"
        else:
            attr_name = _COMPONENTS.get(component_type)
            if attr_name is None:
                return False
        return getattr(self, attr_name) is not None
    
    # ======================================== TAGS ========================================
    def add_tag(self, tag: str) -> Entity:
        """Ajoute un label à l'entité

        Args:
            tag: label à ajouter
        """
        self._tags.add(expect(tag, str))
        return self
    
    def remove_tag(self, tag: str) -> Entity:
        """Supprime un label de l'entité

        Args:
            tag: label à supprimer
        """
        self._tags.discard(expect(tag, str))
        return self
    
    def has_tag(self, tag: str) -> bool:
        """Vérifie que l'entité possède un label

        Args:
            tag: label à vérifier
        """
        return expect(tag, str) in self._tags
    
# ======================================== EXPORTS ========================================
__all__ = [
    "Entity",
]