# Camerasourcesnapshot

> 1 nodes · cohesion 1.00

## Key Concepts

- **_CameraSourceSnapshot** (0 connections) — `src/homesec/app.py`

## Relationships

- No strong cross-community connections detected

## Source Files

- `src/homesec/app.py`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*