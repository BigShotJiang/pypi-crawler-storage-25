# Localstorage View Url

> 1 nodes · cohesion 1.00

## Key Concepts

- **LocalStorage.get_view_url** (0 connections) — `src/homesec/plugins/storage/local.py`

## Relationships

- No strong cross-community connections detected

## Source Files

- `src/homesec/plugins/storage/local.py`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*