# Clipsource Plugintype Source

> 2 nodes · cohesion 1.00

## Key Concepts

- **ClipSource** (1 connections) — `PLUGIN_DEVELOPMENT.md`
- **PluginType.SOURCE** (1 connections) — `PLUGIN_DEVELOPMENT.md`

## Relationships

- No strong cross-community connections detected

## Source Files

- `PLUGIN_DEVELOPMENT.md`

## Audit Trail

- EXTRACTED: 2 (100%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*