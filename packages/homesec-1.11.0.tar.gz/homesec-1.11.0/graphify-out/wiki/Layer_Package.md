# Layer Package

> 1 nodes · cohesion 1.00

## Key Concepts

- **HomeSec service-layer package** (0 connections) — `src/homesec/services/__init__.py`

## Relationships

- No strong cross-community connections detected

## Source Files

- `src/homesec/services/__init__.py`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*