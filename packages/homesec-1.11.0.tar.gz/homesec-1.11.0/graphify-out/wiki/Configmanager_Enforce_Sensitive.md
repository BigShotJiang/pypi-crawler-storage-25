# Configmanager Enforce Sensitive

> 1 nodes · cohesion 1.00

## Key Concepts

- **ConfigManager._enforce_sensitive_file_mode** (0 connections) — `src/homesec/config/manager.py`

## Relationships

- No strong cross-community connections detected

## Source Files

- `src/homesec/config/manager.py`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*