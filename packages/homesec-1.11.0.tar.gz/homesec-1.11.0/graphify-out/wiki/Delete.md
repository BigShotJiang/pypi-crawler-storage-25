# Delete

> 1 nodes · cohesion 1.00

## Key Concepts

- **delete** (0 connections) — `tests/homesec/mocks/storage.py`

## Relationships

- No strong cross-community connections detected

## Source Files

- `tests/homesec/mocks/storage.py`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*