# App

> 1 nodes · cohesion 1.00

## Key Concepts

- **get_homesec_app** (0 connections) — `src/homesec/api/routes/health.py`

## Relationships

- No strong cross-community connections detected

## Source Files

- `src/homesec/api/routes/health.py`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*