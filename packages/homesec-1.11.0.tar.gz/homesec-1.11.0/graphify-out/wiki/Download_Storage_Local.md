# Download Storage Local

> 1 nodes · cohesion 1.00

## Key Concepts

- **Download file from storage to local path.** (0 connections) — `src/homesec/interfaces.py`

## Relationships

- No strong cross-community connections detected

## Source Files

- `src/homesec/interfaces.py`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*