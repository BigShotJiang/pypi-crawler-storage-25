# Health Check Returns

> 1 nodes · cohesion 1.00

## Key Concepts

- **Test health check returns True when dir exists.** (0 connections) — `tests/homesec/test_clip_sources.py`

## Relationships

- No strong cross-community connections detected

## Source Files

- `tests/homesec/test_clip_sources.py`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*