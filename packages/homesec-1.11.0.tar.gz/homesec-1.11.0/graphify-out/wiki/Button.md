# Button

> 1 nodes · cohesion 1.00

## Key Concepts

- **Button** (0 connections) — `ui/src/features/setup/steps/ReviewStep.tsx`

## Relationships

- No strong cross-community connections detected

## Source Files

- `ui/src/features/setup/steps/ReviewStep.tsx`

## Audit Trail

- EXTRACTED: 0 (0%)
- INFERRED: 0 (0%)
- AMBIGUOUS: 0 (0%)

---

*Part of the graphify knowledge wiki. See [[index]] to navigate.*