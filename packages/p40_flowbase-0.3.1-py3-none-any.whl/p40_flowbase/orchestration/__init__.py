"""
MIT License

Copyright (c) 2025 Anton Tarasenko
"""
