from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.services import api_key as api_key_service
from app.services.auth_dependencies import get_current_user
from app.schemas.api_key import (
    APIKeyCreateRequest,
    APIKeyResponse,
    APIKeyRevealResponse,
    APIKeyUpdateRequest,
)
from app.models.api_key import APIKey

router = APIRouter(prefix="/auth/api-keys", tags=["auth"])


@router.post("", response_model=APIKeyRevealResponse, status_code=status.HTTP_201_CREATED)
def create_api_key(
    request: APIKeyCreateRequest,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Create a new API key for the current user.
    
    **Important:** The secret key is only shown once. Store it securely!
    
    - **name**: A descriptive name for the API key (e.g., "CI/CD Pipeline")
    - **scopes**: List of allowed scopes (default: ["read"])
    - **expires_at**: Optional expiration datetime
    """
    api_key, full_secret = api_key_service.create_api_key(
        db,
        current_user.id,
        request.name,
        request.scopes,
        request.expires_at,
    )
    
    return APIKeyRevealResponse(
        id=api_key.id,
        name=api_key.name,
        prefix=api_key.prefix,
        secret_key=full_secret,
        scopes=api_key.scopes,
        is_active=api_key.is_active,
        expires_at=api_key.expires_at,
        created_at=api_key.created_at,
    )


@router.get("", response_model=list[APIKeyResponse])
def list_api_keys(
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """List all API keys for the current user."""
    api_keys = api_key_service.get_user_api_keys(db, current_user.id)
    return api_keys


@router.get("/{key_id}", response_model=APIKeyResponse)
def get_api_key(
    key_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get a specific API key by ID."""
    api_key = api_key_service.get_api_key_by_id(db, key_id)
    
    if not api_key:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found")
    
    # Check that the key belongs to the current user
    if api_key.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to access this API key")
    
    return api_key


@router.put("/{key_id}", response_model=APIKeyResponse)
def update_api_key(
    key_id: int,
    request: APIKeyUpdateRequest,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Update an API key."""
    existing_key = api_key_service.get_api_key_by_id(db, key_id)
    
    if not existing_key:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found")
    
    # Check that the key belongs to the current user
    if existing_key.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to update this API key")
    
    api_key = api_key_service.update_api_key(
        db,
        key_id,
        request.name,
        request.scopes,
        request.expires_at,
    )
    
    return api_key


@router.delete("/{key_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_api_key(
    key_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Delete/revoke an API key."""
    existing_key = api_key_service.get_api_key_by_id(db, key_id)
    
    if not existing_key:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found")
    
    # Check that the key belongs to the current user
    if existing_key.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to delete this API key")
    
    api_key_service.delete_api_key(db, key_id)
    return None
