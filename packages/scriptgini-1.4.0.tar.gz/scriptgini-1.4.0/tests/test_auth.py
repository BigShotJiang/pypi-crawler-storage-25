import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from app.main import app as fastapi_app
from app.database import Base, get_db
from app.services.auth import create_user, authenticate_user
from app.services.api_key import create_api_key, verify_api_key
from app.models.user import User

# Ensure models are registered with Base.metadata for create_all/drop_all.
import app.models.user  # noqa: F401
import app.models.api_key  # noqa: F401

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

client = TestClient(fastapi_app)


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def db_session():
    """Create a test database session."""
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture
def test_user(db_session):
    """Create a test user."""
    user = create_user(db_session, "testuser@example.com", "TestPassword123!")
    return user


@pytest.fixture
def test_user_2(db_session):
    """Create another test user."""
    user = create_user(db_session, "testuser2@example.com", "TestPassword123!")
    return user


@pytest.fixture
def auth_headers(db_session, test_user):
    """Get authorization headers for test user."""
    response = client.post(
        "/api/v1/auth/login",
        json={"email": "testuser@example.com", "password": "TestPassword123!"},
    )
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


class TestUserRegistration:
    def test_register_user(self):
        """Test user registration."""
        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "newuser@example.com",
                "password": "SecurePassword123!",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert data["email"] == "newuser@example.com"
        assert data["is_active"] is True
        assert "created_at" in data

    def test_register_duplicate_email(self, db_session, test_user):
        """Test registration with duplicate email."""
        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "testuser@example.com",
                "password": "AnotherPassword123!",
            },
        )
        assert response.status_code == 400
        assert "already registered" in response.json()["detail"]

    def test_register_invalid_email(self):
        """Test registration with invalid email."""
        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "invalid-email",
                "password": "SecurePassword123!",
            },
        )
        assert response.status_code == 422  # Validation error


class TestUserLogin:
    def test_login_success(self, db_session, test_user):
        """Test successful login."""
        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "testuser@example.com",
                "password": "TestPassword123!",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"
        assert data["expires_in"] == 1800  # 30 minutes

    def test_login_invalid_password(self, db_session, test_user):
        """Test login with invalid password."""
        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "testuser@example.com",
                "password": "WrongPassword123!",
            },
        )
        assert response.status_code == 401
        assert "Invalid email or password" in response.json()["detail"]

    def test_login_nonexistent_user(self):
        """Test login with non-existent user."""
        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "nonexistent@example.com",
                "password": "SomePassword123!",
            },
        )
        assert response.status_code == 401
        assert "Invalid email or password" in response.json()["detail"]

    def test_login_inactive_user(self, db_session):
        """Test login with inactive user account."""
        user = create_user(db_session, "inactive@example.com", "TestPassword123!")
        user.is_active = False
        db_session.commit()

        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "inactive@example.com",
                "password": "TestPassword123!",
            },
        )
        assert response.status_code == 403
        assert "inactive" in response.json()["detail"].lower()


class TestTokenRefresh:
    def test_refresh_token_success(self, db_session, test_user):
        """Test successful token refresh."""
        # First login
        login_response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "testuser@example.com",
                "password": "TestPassword123!",
            },
        )
        refresh_token = login_response.json()["refresh_token"]

        # Refresh token
        response = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": refresh_token},
        )
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data

    def test_refresh_invalid_token(self):
        """Test refresh with invalid token."""
        response = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": "invalid-token"},
        )
        assert response.status_code == 401
        assert "Invalid or expired refresh token" in response.json()["detail"]

    def test_refresh_token_inactive_user(self, db_session, test_user):
        """Test refresh token fails if user is deactivated after login."""
        login_response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "testuser@example.com",
                "password": "TestPassword123!",
            },
        )
        refresh_token = login_response.json()["refresh_token"]

        test_user.is_active = False
        db_session.commit()

        response = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": refresh_token},
        )
        assert response.status_code == 401
        assert "inactive" in response.json()["detail"].lower()


class TestLogout:
    def test_logout(self, auth_headers):
        """Test logout endpoint."""
        response = client.post("/api/v1/auth/logout", headers=auth_headers)
        assert response.status_code == 204


class TestAPIKeyManagement:
    def test_create_api_key(self, db_session, test_user, auth_headers):
        """Test creating an API key."""
        response = client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={
                "name": "CI/CD Pipeline Key",
                "scopes": ["read", "execute"],
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "CI/CD Pipeline Key"
        assert data["scopes"] == ["read", "execute"]
        assert data["is_active"] is True
        assert "prefix" in data
        assert "secret_key" in data

    def test_list_api_keys(self, db_session, test_user, auth_headers):
        """Test listing API keys."""
        # Create two keys
        client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={"name": "Key 1", "scopes": ["read"]},
        )
        client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={"name": "Key 2", "scopes": ["write"]},
        )

        # List keys
        response = client.get("/api/v1/auth/api-keys", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 2

    def test_get_api_key(self, db_session, test_user, auth_headers):
        """Test getting a specific API key."""
        # Create key
        create_response = client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={"name": "Test Key", "scopes": ["read"]},
        )
        key_id = create_response.json()["id"]

        # Get key
        response = client.get(f"/api/v1/auth/api-keys/{key_id}", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Test Key"
        assert "secret_key" not in data  # Secret should not be in response

    def test_update_api_key(self, db_session, test_user, auth_headers):
        """Test updating an API key."""
        # Create key
        create_response = client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={"name": "Original Name", "scopes": ["read"]},
        )
        key_id = create_response.json()["id"]

        # Update key
        response = client.put(
            f"/api/v1/auth/api-keys/{key_id}",
            headers=auth_headers,
            json={"name": "Updated Name", "scopes": ["read", "write"]},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Updated Name"
        assert data["scopes"] == ["read", "write"]

    def test_update_api_key_not_found(self, auth_headers):
        """Test updating a missing API key returns 404."""
        response = client.put(
            "/api/v1/auth/api-keys/99999",
            headers=auth_headers,
            json={"name": "Updated Name", "scopes": ["read"]},
        )
        assert response.status_code == 404

    def test_update_api_key_not_accessible_by_other_user(
        self, db_session, test_user, test_user_2, auth_headers
    ):
        """Test that API key update is blocked for non-owner."""
        create_response = client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={"name": "Owner Key", "scopes": ["read"]},
        )
        key_id = create_response.json()["id"]

        login_response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "testuser2@example.com",
                "password": "TestPassword123!",
            },
        )
        other_user_headers = {
            "Authorization": f"Bearer {login_response.json()['access_token']}"
        }

        response = client.put(
            f"/api/v1/auth/api-keys/{key_id}",
            headers=other_user_headers,
            json={"name": "Hacked", "scopes": ["write"]},
        )
        assert response.status_code == 403

    def test_delete_api_key(self, db_session, test_user, auth_headers):
        """Test deleting an API key."""
        # Create key
        create_response = client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={"name": "Key to Delete", "scopes": ["read"]},
        )
        key_id = create_response.json()["id"]

        # Delete key
        response = client.delete(f"/api/v1/auth/api-keys/{key_id}", headers=auth_headers)
        assert response.status_code == 204

        # Verify it's gone
        response = client.get(f"/api/v1/auth/api-keys/{key_id}", headers=auth_headers)
        assert response.status_code == 404

    def test_delete_api_key_not_found(self, auth_headers):
        """Test deleting a missing API key returns 404."""
        response = client.delete("/api/v1/auth/api-keys/99999", headers=auth_headers)
        assert response.status_code == 404

    def test_delete_api_key_not_accessible_by_other_user(
        self, db_session, test_user, test_user_2, auth_headers
    ):
        """Test that API key deletion is blocked for non-owner."""
        create_response = client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={"name": "Owner Key", "scopes": ["read"]},
        )
        key_id = create_response.json()["id"]

        login_response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "testuser2@example.com",
                "password": "TestPassword123!",
            },
        )
        other_user_headers = {
            "Authorization": f"Bearer {login_response.json()['access_token']}"
        }

        response = client.delete(
            f"/api/v1/auth/api-keys/{key_id}",
            headers=other_user_headers,
        )
        assert response.status_code == 403

    def test_api_key_not_accessible_by_other_user(
        self, db_session, test_user, test_user_2, auth_headers
    ):
        """Test that API keys are only accessible to their owner."""
        # Create key as test_user
        create_response = client.post(
            "/api/v1/auth/api-keys",
            headers=auth_headers,
            json={"name": "Private Key", "scopes": ["read"]},
        )
        key_id = create_response.json()["id"]

        # Try to access as test_user_2
        login_response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "testuser2@example.com",
                "password": "TestPassword123!",
            },
        )
        other_user_headers = {
            "Authorization": f"Bearer {login_response.json()['access_token']}"
        }

        response = client.get(f"/api/v1/auth/api-keys/{key_id}", headers=other_user_headers)
        assert response.status_code == 403


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
