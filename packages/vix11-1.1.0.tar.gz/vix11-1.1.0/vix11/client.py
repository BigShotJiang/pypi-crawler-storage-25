"""Synchronous and asynchronous Vix11 API clients."""

from __future__ import annotations

from typing import Any

import httpx

from vix11.types import (
    CheckResponseResult,
    DetectResponse,
    ShieldResponse,
    TrustScoreResponse,
    Vix11Error,
)


def _build_check_response_body(
    default_agent_id: str,
    content: str,
    *,
    agent_id: str | None,
    request_id: str | None,
    model: str | None,
    content_type: str | None,
    mode: str | None,
    block_threshold: float | None,
    sanitize_threshold: float | None,
    thresholds: dict[str, float] | None,
) -> dict[str, Any]:
    """Assemble the request body for POST /v1/detect-response (shorthand form)."""
    response: dict[str, Any] = {"content": content}
    if model is not None:
        response["model"] = model
    if content_type is not None:
        response["contentType"] = content_type

    body: dict[str, Any] = {
        "agentId": agent_id or default_agent_id,
        "response": response,
    }
    if request_id is not None:
        body["requestId"] = request_id

    policy: dict[str, Any] = {}
    if mode is not None:
        policy["mode"] = mode
    if block_threshold is not None:
        policy["blockThreshold"] = block_threshold
    if sanitize_threshold is not None:
        policy["sanitizeThreshold"] = sanitize_threshold
    if thresholds:
        policy["thresholds"] = thresholds
    if policy:
        body["policy"] = policy
    return body


class Vix11Client:
    """Synchronous Vix11 client using httpx."""

    def __init__(
        self,
        base_url: str,
        agent_id: str,
        api_key: str | None = None,
        timeout: float = 5.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.agent_id = agent_id
        self.api_key = api_key
        headers: dict[str, str] = {"X-Vix11-Agent-Id": agent_id}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
        )

    # -- context manager --------------------------------------------------

    def __enter__(self) -> Vix11Client:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying httpx client."""
        self._client.close()

    # -- helpers -----------------------------------------------------------

    def _handle_response(self, resp: httpx.Response) -> dict[str, Any]:
        if resp.status_code < 200 or resp.status_code >= 300:
            try:
                body = resp.json()
                message = body.get("error", resp.text)
            except Exception:
                message = resp.text
            raise Vix11Error(resp.status_code, message)
        return resp.json()

    # -- API methods -------------------------------------------------------

    def detect(self, endpoint: str, payload: str, **params: Any) -> DetectResponse:
        """POST /v1/detect -- run the detection pipeline on a request."""
        body: dict[str, Any] = {
            "agentId": self.agent_id,
            "endpoint": endpoint,
            "payload": payload,
            **params,
        }
        resp = self._client.post("/v1/detect", json=body)
        data = self._handle_response(resp)
        return DetectResponse.from_dict(data)

    def shield(self, endpoint: str, payload: str, **params: Any) -> ShieldResponse:
        """POST /v1/shield -- protected request endpoint."""
        body: dict[str, Any] = {
            "agentId": self.agent_id,
            "endpoint": endpoint,
            "payload": payload,
            **params,
        }
        resp = self._client.post("/v1/shield", json=body)
        data = self._handle_response(resp)
        return ShieldResponse.from_dict(data)

    def check_response(
        self,
        content: str,
        *,
        mode: str | None = None,
        agent_id: str | None = None,
        request_id: str | None = None,
        model: str | None = None,
        content_type: str | None = None,
        block_threshold: float | None = None,
        sanitize_threshold: float | None = None,
        thresholds: dict[str, float] | None = None,
    ) -> CheckResponseResult:
        """POST /v1/detect-response -- Layer 12 scan of an outbound LLM response.

        Detects PII, leaked secrets, malicious URLs, and indirect prompt injection.
        Returns an action (``allow`` / ``sanitize`` / ``block``) plus a redacted
        ``sanitized_content`` when action is ``sanitize``.

        Example::

            result = client.check_response(llm_reply, mode="sanitize")
            if result.action == "block":
                raise RuntimeError("unsafe response")
            safe = result.sanitized_content or llm_reply
        """
        body = _build_check_response_body(
            self.agent_id,
            content,
            agent_id=agent_id,
            request_id=request_id,
            model=model,
            content_type=content_type,
            mode=mode,
            block_threshold=block_threshold,
            sanitize_threshold=sanitize_threshold,
            thresholds=thresholds,
        )
        resp = self._client.post("/v1/detect-response", json=body)
        data = self._handle_response(resp)
        return CheckResponseResult.from_dict(data)

    def get_detection_stats(self) -> dict[str, Any]:
        """GET /v1/detection/stats -- pipeline statistics."""
        resp = self._client.get("/v1/detection/stats")
        return self._handle_response(resp)

    def get_analytics_summary(
        self,
        from_ts: int | None = None,
        to_ts: int | None = None,
    ) -> dict[str, Any]:
        """GET /v1/analytics/summary -- analytics summary for a time range."""
        params: dict[str, int] = {}
        if from_ts is not None:
            params["from"] = from_ts
        if to_ts is not None:
            params["to"] = to_ts
        resp = self._client.get("/v1/analytics/summary", params=params)
        return self._handle_response(resp)

    def get_analytics_events(
        self,
        page: int = 1,
        limit: int = 50,
    ) -> dict[str, Any]:
        """GET /v1/analytics/events -- paginated detection events."""
        resp = self._client.get(
            "/v1/analytics/events",
            params={"page": page, "limit": limit},
        )
        return self._handle_response(resp)

    def get_compliance_report(self) -> dict[str, Any]:
        """GET /v1/compliance/owasp -- OWASP compliance report."""
        resp = self._client.get("/v1/compliance/owasp")
        return self._handle_response(resp)

    def get_trust_score(self, agent_id: str) -> TrustScoreResponse:
        """GET /v1/trust/:agentId -- agent trust score."""
        resp = self._client.get(f"/v1/trust/{agent_id}")
        data = self._handle_response(resp)
        return TrustScoreResponse.from_dict(data)

    def issue_passport(
        self,
        agent_id: str,
        owner_id: str,
        capabilities: dict[str, Any],
        ttl_seconds: int | None = None,
    ) -> dict[str, Any]:
        """POST /v1/passport/issue -- issue a KYA passport."""
        body: dict[str, Any] = {
            "agentId": agent_id,
            "ownerId": owner_id,
            "capabilities": capabilities,
        }
        if ttl_seconds is not None:
            body["ttlSeconds"] = ttl_seconds
        resp = self._client.post("/v1/passport/issue", json=body)
        return self._handle_response(resp)

    def verify_passport(self, passport: dict[str, Any]) -> dict[str, Any]:
        """POST /v1/passport/verify -- verify a signed passport."""
        resp = self._client.post("/v1/passport/verify", json=passport)
        return self._handle_response(resp)

    def revoke_passport(self, passport_id: str, reason: str) -> dict[str, Any]:
        """POST /v1/passport/revoke -- revoke a passport."""
        resp = self._client.post(
            "/v1/passport/revoke",
            json={"passportId": passport_id, "reason": reason},
        )
        return self._handle_response(resp)

    def health(self) -> dict[str, Any]:
        """GET /v1/health -- health check with KV probes."""
        resp = self._client.get("/v1/health")
        return self._handle_response(resp)


class AsyncVix11Client:
    """Asynchronous Vix11 client using httpx.AsyncClient."""

    def __init__(
        self,
        base_url: str,
        agent_id: str,
        api_key: str | None = None,
        timeout: float = 5.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.agent_id = agent_id
        self.api_key = api_key
        headers: dict[str, str] = {"X-Vix11-Agent-Id": agent_id}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
        )

    # -- context manager --------------------------------------------------

    async def __aenter__(self) -> AsyncVix11Client:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying httpx async client."""
        await self._client.aclose()

    # -- helpers -----------------------------------------------------------

    def _handle_response(self, resp: httpx.Response) -> dict[str, Any]:
        if resp.status_code < 200 or resp.status_code >= 300:
            try:
                body = resp.json()
                message = body.get("error", resp.text)
            except Exception:
                message = resp.text
            raise Vix11Error(resp.status_code, message)
        return resp.json()

    # -- API methods -------------------------------------------------------

    async def detect(self, endpoint: str, payload: str, **params: Any) -> DetectResponse:
        """POST /v1/detect -- run the detection pipeline on a request."""
        body: dict[str, Any] = {
            "agentId": self.agent_id,
            "endpoint": endpoint,
            "payload": payload,
            **params,
        }
        resp = await self._client.post("/v1/detect", json=body)
        data = self._handle_response(resp)
        return DetectResponse.from_dict(data)

    async def shield(self, endpoint: str, payload: str, **params: Any) -> ShieldResponse:
        """POST /v1/shield -- protected request endpoint."""
        body: dict[str, Any] = {
            "agentId": self.agent_id,
            "endpoint": endpoint,
            "payload": payload,
            **params,
        }
        resp = await self._client.post("/v1/shield", json=body)
        data = self._handle_response(resp)
        return ShieldResponse.from_dict(data)

    async def check_response(
        self,
        content: str,
        *,
        mode: str | None = None,
        agent_id: str | None = None,
        request_id: str | None = None,
        model: str | None = None,
        content_type: str | None = None,
        block_threshold: float | None = None,
        sanitize_threshold: float | None = None,
        thresholds: dict[str, float] | None = None,
    ) -> CheckResponseResult:
        """POST /v1/detect-response -- Layer 12 scan of an outbound LLM response.

        See :meth:`Vix11Client.check_response` for semantics and example usage.
        """
        body = _build_check_response_body(
            self.agent_id,
            content,
            agent_id=agent_id,
            request_id=request_id,
            model=model,
            content_type=content_type,
            mode=mode,
            block_threshold=block_threshold,
            sanitize_threshold=sanitize_threshold,
            thresholds=thresholds,
        )
        resp = await self._client.post("/v1/detect-response", json=body)
        data = self._handle_response(resp)
        return CheckResponseResult.from_dict(data)

    async def get_detection_stats(self) -> dict[str, Any]:
        """GET /v1/detection/stats -- pipeline statistics."""
        resp = await self._client.get("/v1/detection/stats")
        return self._handle_response(resp)

    async def get_analytics_summary(
        self,
        from_ts: int | None = None,
        to_ts: int | None = None,
    ) -> dict[str, Any]:
        """GET /v1/analytics/summary -- analytics summary for a time range."""
        params: dict[str, int] = {}
        if from_ts is not None:
            params["from"] = from_ts
        if to_ts is not None:
            params["to"] = to_ts
        resp = await self._client.get("/v1/analytics/summary", params=params)
        return self._handle_response(resp)

    async def get_analytics_events(
        self,
        page: int = 1,
        limit: int = 50,
    ) -> dict[str, Any]:
        """GET /v1/analytics/events -- paginated detection events."""
        resp = await self._client.get(
            "/v1/analytics/events",
            params={"page": page, "limit": limit},
        )
        return self._handle_response(resp)

    async def get_compliance_report(self) -> dict[str, Any]:
        """GET /v1/compliance/owasp -- OWASP compliance report."""
        resp = await self._client.get("/v1/compliance/owasp")
        return self._handle_response(resp)

    async def get_trust_score(self, agent_id: str) -> TrustScoreResponse:
        """GET /v1/trust/:agentId -- agent trust score."""
        resp = await self._client.get(f"/v1/trust/{agent_id}")
        data = self._handle_response(resp)
        return TrustScoreResponse.from_dict(data)

    async def issue_passport(
        self,
        agent_id: str,
        owner_id: str,
        capabilities: dict[str, Any],
        ttl_seconds: int | None = None,
    ) -> dict[str, Any]:
        """POST /v1/passport/issue -- issue a KYA passport."""
        body: dict[str, Any] = {
            "agentId": agent_id,
            "ownerId": owner_id,
            "capabilities": capabilities,
        }
        if ttl_seconds is not None:
            body["ttlSeconds"] = ttl_seconds
        resp = await self._client.post("/v1/passport/issue", json=body)
        return self._handle_response(resp)

    async def verify_passport(self, passport: dict[str, Any]) -> dict[str, Any]:
        """POST /v1/passport/verify -- verify a signed passport."""
        resp = await self._client.post("/v1/passport/verify", json=passport)
        return self._handle_response(resp)

    async def revoke_passport(self, passport_id: str, reason: str) -> dict[str, Any]:
        """POST /v1/passport/revoke -- revoke a passport."""
        resp = await self._client.post(
            "/v1/passport/revoke",
            json={"passportId": passport_id, "reason": reason},
        )
        return self._handle_response(resp)

    async def health(self) -> dict[str, Any]:
        """GET /v1/health -- health check with KV probes."""
        resp = await self._client.get("/v1/health")
        return self._handle_response(resp)
