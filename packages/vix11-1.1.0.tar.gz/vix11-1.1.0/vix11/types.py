"""Response types for the Vix11 SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


class Vix11Error(Exception):
    """Raised when the Vix11 API returns a non-2xx response."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"Vix11 API error {status_code}: {message}")


@dataclass
class LayerResult:
    """Score produced by a single detection layer."""

    id: str
    score: float
    reason: str
    duration_ms: float


@dataclass
class DetectResponse:
    """Response from the /v1/detect endpoint."""

    action: str
    score: float
    layers: list[dict[str, Any]]
    total_duration_ms: float
    trust_score: float | None = None
    trust_tier: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DetectResponse:
        detection = data.get("detection", data)
        return cls(
            action=detection["action"],
            score=detection["score"],
            layers=detection.get("layers", []),
            total_duration_ms=detection.get("totalDurationMs", 0.0),
            trust_score=detection.get("trustScore"),
            trust_tier=detection.get("trustTier"),
        )


@dataclass
class ShieldResponse:
    """Response from the /v1/shield endpoint."""

    status: str
    meta: dict[str, Any]

    @property
    def trust_score(self) -> float | None:
        """Trust score from shield response metadata."""
        return self.meta.get("trustScore")

    @property
    def trust_tier(self) -> str | None:
        """Trust tier from shield response metadata."""
        return self.meta.get("trustTier")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ShieldResponse:
        return cls(
            status=data.get("status", ""),
            meta=data.get("meta", {}),
        )


@dataclass
class ResponseDetection:
    """Aggregated Layer 12 detection — no raw content, safe to log."""

    type: str
    count: int
    severity: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResponseDetection:
        return cls(
            type=data["type"],
            count=int(data.get("count", 0)),
            severity=float(data.get("severity", 0.0)),
        )


@dataclass
class CheckResponseResult:
    """Response from POST /v1/detect-response (Layer 12 Response Output Rail)."""

    action: str  # 'allow' | 'sanitize' | 'block'
    score: float
    detections: list[ResponseDetection]
    duration_ms: float
    sanitized_content: str | None = None
    truncated: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CheckResponseResult:
        return cls(
            action=data["action"],
            score=float(data.get("score", 0.0)),
            detections=[ResponseDetection.from_dict(d) for d in data.get("detections", [])],
            duration_ms=float(data.get("durationMs", 0.0)),
            sanitized_content=data.get("sanitizedContent"),
            truncated=bool(data.get("truncated", False)),
        )


@dataclass
class TrustScoreResponse:
    """Response from the GET /v1/trust/:agentId endpoint."""

    agent_id: str
    trust_score: float
    trust_tier: str
    total_requests: int
    decisions: dict[str, int]
    last_action: str
    last_detection_score: float
    last_updated: str
    created_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TrustScoreResponse:
        return cls(
            agent_id=data["agentId"],
            trust_score=data["trustScore"],
            trust_tier=data["trustTier"],
            total_requests=data["totalRequests"],
            decisions=data.get("decisions", {}),
            last_action=data.get("lastAction", ""),
            last_detection_score=data.get("lastDetectionScore", 0.0),
            last_updated=data.get("lastUpdated", ""),
            created_at=data.get("createdAt", ""),
        )
