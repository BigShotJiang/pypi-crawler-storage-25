from setuptools import setup, find_packages

setup(
    name="vix11",
    version="1.0.2",
    description="Vix11 SDK - AI Agent Security",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.25.0",
    ],
    extras_require={
        "dev": ["pytest", "pytest-asyncio", "httpx"],
    },
)
