"""Tests for Vix11Client and AsyncVix11Client."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest

from vix11 import AsyncVix11Client, Vix11Client, Vix11Error
from vix11.types import CheckResponseResult, DetectResponse, ShieldResponse


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

DETECT_RESPONSE = {
    "detection": {
        "action": "allow",
        "score": 0.12,
        "layers": [
            {"id": "velocity", "score": 0.1, "reason": "OK", "durationMs": 1.5}
        ],
        "totalDurationMs": 5.0,
    }
}

SHIELD_RESPONSE_ALLOW = {
    "status": "allowed",
    "meta": {"action": "allow", "score": 0.05, "totalDurationMs": 3.0},
}

SHIELD_RESPONSE_BLOCKED = {
    "status": "blocked",
    "error": "Request denied by security policy",
    "meta": {"action": "block", "score": 0.95, "totalDurationMs": 2.0},
}

HEALTH_RESPONSE = {
    "status": "ok",
    "service": "vix11-edge",
    "version": "1.0.0",
    "timestamp": "2026-01-01T00:00:00Z",
}

STATS_RESPONSE = {
    "status": "ok",
    "layers": [{"id": "velocity", "status": "active", "version": "1.0"}],
    "thresholds": {"throttle": 0.3, "shadowBan": 0.6, "block": 0.85},
}


def _mock_response(status: int, json_data: dict) -> httpx.Response:
    resp = httpx.Response(
        status_code=status,
        json=json_data,
        request=httpx.Request("GET", "https://test"),
    )
    return resp


# ---------------------------------------------------------------------------
# Sync client tests
# ---------------------------------------------------------------------------


class TestVix11Client:
    def test_construction(self) -> None:
        client = Vix11Client("https://example.com", "agent-1")
        assert client.agent_id == "agent-1"
        assert client.base_url == "https://example.com"
        assert client.api_key is None
        client.close()

    def test_construction_with_api_key(self) -> None:
        client = Vix11Client("https://example.com", "agent-1", api_key="key-123")
        assert client.api_key == "key-123"
        client.close()

    def test_headers_include_agent_id(self) -> None:
        client = Vix11Client("https://example.com", "agent-1", api_key="key-123")
        headers = client._client.headers
        assert headers["X-Vix11-Agent-Id"] == "agent-1"
        assert headers["Authorization"] == "Bearer key-123"
        client.close()

    def test_headers_no_auth_without_api_key(self) -> None:
        client = Vix11Client("https://example.com", "agent-1")
        assert "Authorization" not in client._client.headers
        client.close()

    def test_trailing_slash_stripped(self) -> None:
        client = Vix11Client("https://example.com/", "agent-1")
        assert client.base_url == "https://example.com"
        client.close()

    def test_context_manager_calls_close(self) -> None:
        with Vix11Client("https://example.com", "agent-1") as client:
            assert isinstance(client, Vix11Client)
        # After exiting, client should be closed (no exception)

    @patch.object(httpx.Client, "post")
    def test_detect_sends_correct_post(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(200, DETECT_RESPONSE)

        with Vix11Client("https://example.com", "agent-1") as client:
            result = client.detect("/v1/chat", '{"prompt": "hello"}', model="gpt-4")

        assert isinstance(result, DetectResponse)
        assert result.action == "allow"
        assert result.score == 0.12
        assert len(result.layers) == 1
        assert result.total_duration_ms == 5.0

        call_kwargs = mock_post.call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert body["agentId"] == "agent-1"
        assert body["endpoint"] == "/v1/chat"
        assert body["payload"] == '{"prompt": "hello"}'
        assert body["model"] == "gpt-4"

    @patch.object(httpx.Client, "post")
    def test_shield_sends_correct_post(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(200, SHIELD_RESPONSE_ALLOW)

        with Vix11Client("https://example.com", "agent-1") as client:
            result = client.shield("/v1/chat", '{"prompt": "hello"}')

        assert isinstance(result, ShieldResponse)
        assert result.status == "allowed"
        assert result.meta["action"] == "allow"

    @patch.object(httpx.Client, "post")
    def test_shield_blocked_raises_error(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(403, SHIELD_RESPONSE_BLOCKED)

        with Vix11Client("https://example.com", "agent-1") as client:
            with pytest.raises(Vix11Error) as exc_info:
                client.shield("/v1/chat", '{"prompt": "bad"}')

        assert exc_info.value.status_code == 403
        assert "Request denied" in exc_info.value.message

    @patch.object(httpx.Client, "post")
    def test_check_response_sanitize(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(
            200,
            {
                "action": "sanitize",
                "score": 0.3,
                "detections": [{"type": "pii.email", "count": 1, "severity": 0.6}],
                "durationMs": 2.1,
                "sanitizedContent": "Contact [REDACTED:pii.email]",
            },
        )

        with Vix11Client("https://example.com", "agent-1") as client:
            result = client.check_response("Contact alice@example.com")

        assert isinstance(result, CheckResponseResult)
        assert result.action == "sanitize"
        assert result.sanitized_content == "Contact [REDACTED:pii.email]"
        assert result.detections[0].type == "pii.email"
        assert result.detections[0].count == 1

        call_kwargs = mock_post.call_args
        assert call_kwargs.args[0] == "/v1/detect-response"
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert body["agentId"] == "agent-1"
        assert body["response"]["content"] == "Contact alice@example.com"
        assert "policy" not in body

    @patch.object(httpx.Client, "post")
    def test_check_response_passes_policy(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(
            200, {"action": "block", "score": 1.0, "detections": [], "durationMs": 1.0}
        )

        with Vix11Client("https://example.com", "agent-1") as client:
            client.check_response(
                "x",
                mode="block",
                sanitize_threshold=0.2,
                model="gpt-4",
                request_id="req-99",
            )

        body = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
        assert body["requestId"] == "req-99"
        assert body["response"]["model"] == "gpt-4"
        assert body["policy"] == {"mode": "block", "sanitizeThreshold": 0.2}

    @patch.object(httpx.Client, "post")
    def test_check_response_error(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(400, {"error": "response.content exceeds 1 MB"})

        with Vix11Client("https://example.com", "agent-1") as client:
            with pytest.raises(Vix11Error) as exc_info:
                client.check_response("huge")

        assert exc_info.value.status_code == 400

    @patch.object(httpx.Client, "get")
    def test_health(self, mock_get: MagicMock) -> None:
        mock_get.return_value = _mock_response(200, HEALTH_RESPONSE)

        with Vix11Client("https://example.com", "agent-1") as client:
            result = client.health()

        assert result["status"] == "ok"

    @patch.object(httpx.Client, "get")
    def test_get_detection_stats(self, mock_get: MagicMock) -> None:
        mock_get.return_value = _mock_response(200, STATS_RESPONSE)

        with Vix11Client("https://example.com", "agent-1") as client:
            result = client.get_detection_stats()

        assert result["status"] == "ok"
        assert len(result["layers"]) == 1

    @patch.object(httpx.Client, "get")
    def test_get_analytics_summary(self, mock_get: MagicMock) -> None:
        summary = {"totalRequests": 100, "blockedRequests": 5}
        mock_get.return_value = _mock_response(200, summary)

        with Vix11Client("https://example.com", "agent-1") as client:
            result = client.get_analytics_summary(from_ts=1000, to_ts=2000)

        assert result["totalRequests"] == 100
        call_kwargs = mock_get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["from"] == 1000
        assert params["to"] == 2000

    @patch.object(httpx.Client, "get")
    def test_get_analytics_events(self, mock_get: MagicMock) -> None:
        events_data = {"events": [{"id": 1}], "total": 1}
        mock_get.return_value = _mock_response(200, events_data)

        with Vix11Client("https://example.com", "agent-1") as client:
            result = client.get_analytics_events(page=2, limit=10)

        assert result["total"] == 1
        call_kwargs = mock_get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["page"] == 2
        assert params["limit"] == 10

    @patch.object(httpx.Client, "get")
    def test_get_compliance_report(self, mock_get: MagicMock) -> None:
        report = {"framework": "OWASP", "categories": [], "overallScore": 85}
        mock_get.return_value = _mock_response(200, report)

        with Vix11Client("https://example.com", "agent-1") as client:
            result = client.get_compliance_report()

        assert result["framework"] == "OWASP"

    @patch.object(httpx.Client, "get")
    def test_error_handling_500(self, mock_get: MagicMock) -> None:
        mock_get.return_value = _mock_response(500, {"error": "Internal error"})

        with Vix11Client("https://example.com", "agent-1") as client:
            with pytest.raises(Vix11Error) as exc_info:
                client.health()

        assert exc_info.value.status_code == 500
        assert "Internal error" in exc_info.value.message


# ---------------------------------------------------------------------------
# Async client tests
# ---------------------------------------------------------------------------


class TestAsyncVix11Client:
    def test_construction(self) -> None:
        client = AsyncVix11Client("https://example.com", "agent-1")
        assert client.agent_id == "agent-1"
        assert client.base_url == "https://example.com"

    def test_headers_include_agent_id(self) -> None:
        client = AsyncVix11Client("https://example.com", "agent-1", api_key="key-abc")
        headers = client._client.headers
        assert headers["X-Vix11-Agent-Id"] == "agent-1"
        assert headers["Authorization"] == "Bearer key-abc"

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            assert isinstance(client, AsyncVix11Client)

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "post")
    async def test_detect(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(200, DETECT_RESPONSE)

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            result = await client.detect("/v1/chat", '{"prompt": "hi"}')

        assert isinstance(result, DetectResponse)
        assert result.action == "allow"

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "post")
    async def test_shield(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(200, SHIELD_RESPONSE_ALLOW)

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            result = await client.shield("/v1/chat", '{"prompt": "hi"}')

        assert isinstance(result, ShieldResponse)
        assert result.status == "allowed"

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "post")
    async def test_shield_blocked(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(403, SHIELD_RESPONSE_BLOCKED)

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            with pytest.raises(Vix11Error) as exc_info:
                await client.shield("/v1/chat", '{"prompt": "bad"}')

        assert exc_info.value.status_code == 403

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "post")
    async def test_check_response(self, mock_post: MagicMock) -> None:
        mock_post.return_value = _mock_response(
            200,
            {
                "action": "block",
                "score": 1.0,
                "detections": [{"type": "secret.openai_key", "count": 1, "severity": 1.0}],
                "durationMs": 3.0,
            },
        )

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            result = await client.check_response("oops sk-live-xxxx", mode="sanitize")

        assert isinstance(result, CheckResponseResult)
        assert result.action == "block"
        assert result.detections[0].type == "secret.openai_key"
        body = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
        assert body["policy"] == {"mode": "sanitize"}

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "get")
    async def test_health(self, mock_get: MagicMock) -> None:
        mock_get.return_value = _mock_response(200, HEALTH_RESPONSE)

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            result = await client.health()

        assert result["status"] == "ok"

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "get")
    async def test_get_detection_stats(self, mock_get: MagicMock) -> None:
        mock_get.return_value = _mock_response(200, STATS_RESPONSE)

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            result = await client.get_detection_stats()

        assert result["status"] == "ok"

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "get")
    async def test_get_analytics_summary(self, mock_get: MagicMock) -> None:
        summary = {"totalRequests": 50}
        mock_get.return_value = _mock_response(200, summary)

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            result = await client.get_analytics_summary(from_ts=100, to_ts=200)

        assert result["totalRequests"] == 50

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "get")
    async def test_get_analytics_events(self, mock_get: MagicMock) -> None:
        events_data = {"events": [], "total": 0}
        mock_get.return_value = _mock_response(200, events_data)

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            result = await client.get_analytics_events()

        assert result["total"] == 0

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "get")
    async def test_get_compliance_report(self, mock_get: MagicMock) -> None:
        report = {"framework": "OWASP", "overallScore": 90}
        mock_get.return_value = _mock_response(200, report)

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            result = await client.get_compliance_report()

        assert result["framework"] == "OWASP"

    @pytest.mark.asyncio
    @patch.object(httpx.AsyncClient, "get")
    async def test_error_handling(self, mock_get: MagicMock) -> None:
        mock_get.return_value = _mock_response(500, {"error": "Server error"})

        async with AsyncVix11Client("https://example.com", "agent-1") as client:
            with pytest.raises(Vix11Error) as exc_info:
                await client.health()

        assert exc_info.value.status_code == 500
