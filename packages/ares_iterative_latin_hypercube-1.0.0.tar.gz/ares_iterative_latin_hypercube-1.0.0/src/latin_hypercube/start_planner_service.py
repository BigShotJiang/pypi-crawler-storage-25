#!/usr/bin/env python3
# -*- coding:utf-8 -*-
###
# File: /PyPi Module Templates/PyPi Planner/start_planner_service.py
# Project: pyares-templates
# Created Date: Thursday, January 29th 2026, 12:24:17 pm
# Author(s): Arthur W. N. Sloan
# -----
# MIT License
# 
# Copyright (c) 2026 AFRL-ARES
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# 
###

"""
One of the key ideas behind PyAres is to allow users to reuse 
as much of their code as possible. This top level function serves 
only to define and start the service, calling a planner functon that is 
defined within the package
"""
from PyAres import AresPlannerService, AresDataType
import argparse
from .latin_hypercube import do_planning

def main():
    # 1. Set up the argument parser
    parser = argparse.ArgumentParser(description="Start the Iterative Latin Hypercube Planner Service for ARES.")
    
    parser.add_argument(
        "-p", "--port", 
        type=int, 
        default=1337, 
        help="The port number to run the service on (default: 1337)"
    )
    
    parser.add_argument(
        "--remote", 
        action="store_true", 
        help="Run the service on all network interfaces instead of strictly localhost"
    )
    
    args = parser.parse_args()

    name = "Latin Hypercube"
    description = "Iterative Latin hypercube DoE planner."
    version = "1.0.0"
    
    local = not args.remote

    planner = AresPlannerService(do_planning,
                                 service_name=name,
                                 service_version=version,
                                 service_description=description, 
                                 use_localhost=local, 
                                 port=args.port)
    
    planner.add_supported_type(AresDataType.NUMBER)
    
    planner.add_setting("total_points", AresDataType.NUMBER)
    planner.add_setting("random_seed", AresDataType.NUMBER)
    planner.add_setting("baz", AresDataType.NUMBER)

    planner.start()

if __name__ == "__main__":
    main()