# Iterative Latin Hypercube Planner for ARES

An iterative **Latin Hypercube Design of Experiments (DoE)** planner built for the **ARES OS 2.0** ecosystem. This package provides a service that dynamically populates hypercube bins based on experimental history, ensuring an even distribution of sampling points across the parameter space.

## Features
* **Iterative Binning:** Automatically tracks parameter history to identify and fill empty hypercube bins.
* **ARES Integration:** Native support for `PyAres` and the ARES OS planning request/response protocol.
* **Repeatable Results:** Supports global random seeding for reproducible research.
* **CLI Native:** Runs instantly from your terminal with configurable port and network settings.

---

## Installation

You can install the planner directly via `pip`. Ensure you have Python **3.10** or newer installed.

```bash
pip install ares-planner-iterative-latin-hypercube
```

### Dependencies
* `PyAres`
* `numpy >= 2.2.0`

---

## Command Line Interface (CLI)

Once installed, the planner service is automatically added to your system's PATH. You can start it from any terminal using the built-in command:

```bash
start-latin-hypercube
```

By default, the service starts on `localhost` and listens on port `1337`. 

### CLI Arguments

You can customize the service behavior using the following optional arguments:

| Argument | Short | Description |
| :--- | :--- | :--- |
| `--port <int>` | `-p` | Specifies the port number to run the service on. (Default: `1337`) |
| `--remote` | | Runs the service on all network interfaces (`0.0.0.0`) instead of strictly `localhost`. Required if ARES OS is on a different machine. |
| `--help` | `-h` | Displays the help menu and exits. |

### Usage Examples

**Run multiple