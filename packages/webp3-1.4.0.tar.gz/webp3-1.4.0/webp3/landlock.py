import os
import sys


def _add_ro(rs, path):
	from landlock import FSAccess

	if not os.access(path, os.F_OK):
		return

	access = FSAccess.READ_FILE
	if os.path.isdir(path):
		access |= FSAccess.READ_DIR
	rs.allow(path, rules=access)


def landlock_ro(dirs):
	try:
		from landlock import Ruleset
	except ModuleNotFoundError:
		return

	rs = Ruleset()
	for path in dirs:
		_add_ro(rs, str(path))
	for path in sys.path:
		_add_ro(rs, path)
	_add_ro(rs, "/etc/mime.types")

	rs.apply()
