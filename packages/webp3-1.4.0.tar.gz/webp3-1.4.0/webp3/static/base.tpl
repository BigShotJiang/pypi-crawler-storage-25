<!DOCTYPE html>
<html>
<head>
	<%!
		from urllib.parse import quote

		def q(u):
			return quote(u.encode('utf-8'))
	%>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<script src="${toroot}/_/player.js"></script>
	<link href="${toroot}/_/style.css" rel="stylesheet" />
	<link rel="icon" type="image/png" href="${toroot}/_/favicon.png" />
	<title>${relpath} - WebP3</title>
</head>
<body>
<div id="oldToolbar"><audio id="player" preload="true" controls="controls"></audio></div>

<div id="toolbar"><button id="toolPrev" onclick="pl_prev()">|&lt;&lt;</button><button id="toolPP" onclick="playPause(event)">&gt;</button><button id="toolNext" onclick="pl_next()">&gt;&gt;|</button><span id="song"></span><div id="time"><span id="timeText">--:--</span></div><div id="seekbar"> </div>
</div>

<h4 class="title">${relpath}</h4>

<ul id="listing">
	% if str(toroot) != ".":
	<li class="parent"><a href="..">Parent</a></li>
	% endif
	% for item in items:
		% if item['is_dir']:
			<li class="dir"><a href="${item['basename'] | q}/">${item['basename']}</a>/</li>
		% else:
			<li class="file ${item['is_audio'] and 'audio' or ''}"><a href="${item['basename'] | q}">${item['basename']}</a></li>
		% endif
	% endfor
</ul>

<div><a href="javascript:pl_playDir()">Play directory</a></div>
<div><a href="?m3u">Playlist</a></div>

<img id="albumCover" />

<label><input type="radio" name="theme" value="light"/>L</label>
<label><input type="radio" name="theme" value="auto" checked="checked"/>A</label>
<label><input type="radio" name="theme" value="dark"/>D</label>

</body>
</html>
