"""saransh-workflows — Indian financial statement parsers (CAMS, CDSL, NSDL)."""

from saransh_workflows.cams import parse_cams_pdf
from saransh_workflows.cdsl import parse_cdsl_pdf
from saransh_workflows.nsdl import parse_nsdl_pdf

__all__ = [
    "parse_cams_pdf",
    "parse_cdsl_pdf",
    "parse_nsdl_pdf",
]

__version__ = "0.1.0"
