"""NSDL e-CAS PDF parser."""
from __future__ import annotations

import argparse
import json
import logging
import re
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from pypdf import PdfReader


ISIN_RE = re.compile(r"^[A-Z0-9]{12}$")
DATE_RE = re.compile(r"^\d{2}-[A-Za-z]{3}-\d{4}$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Parse an NSDL e-CAS PDF into JSON")
    parser.add_argument("input_pdf", type=Path, help="Path to NSDL e-CAS PDF")
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        help="Optional output path. Defaults to input filename with .json suffix.",
    )
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output")
    parser.add_argument(
        "--password",
        default=None,
        help="Password to decrypt a password-protected PDF.",
    )
    return parser.parse_args()


def compact_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def parse_decimal(value: str | None) -> float | None:
    if value is None:
        return None
    cleaned = value.replace(",", "").strip()
    if cleaned in {"", "NA", "--"}:
        return None
    try:
        return float(Decimal(cleaned))
    except InvalidOperation:
        return None


def extract_pages(pdf_path: Path, password: str | None = None) -> list[list[str]]:
    reader = PdfReader(str(pdf_path), password=password)
    pages: list[list[str]] = []
    for page in reader.pages:
        text = page.extract_text() or ""
        lines: list[str] = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if line in {
                "Consolidated Account Statement",
                "Summary Holdings Transactions Your Account About NSDL",
            }:
                continue
            if line.startswith("Page ") and line[5:].isdigit():
                continue
            lines.append(line)
        pages.append(lines)
    return pages


def flatten_pages(pages: list[list[str]]) -> list[str]:
    merged: list[str] = []
    for page in pages:
        merged.extend(page)
    return merged


def parse_header(lines: list[str], full_text: str) -> dict[str, Any]:
    statement_period = None
    period_match = re.search(
        r"Statement for the period from\s+(?P<from>\d{2}-[A-Za-z]{3}-\d{4})\s+to\s+(?P<to>\d{2}-[A-Za-z]{3}-\d{4})",
        full_text,
    )
    if period_match:
        statement_period = {"from": period_match.group("from"), "to": period_match.group("to")}

    nsdl_id = None
    investor_name = None
    address: list[str] = []
    portfolio_value = None
    pan = None

    for idx, line in enumerate(lines):
        if line.startswith("NSDL ID:"):
            nsdl_id = line.split(":", 1)[1].strip()
            if idx + 1 < len(lines):
                investor_name = compact_spaces(lines[idx + 1])
            j = idx + 2
            while j < len(lines):
                if lines[j].startswith("YOUR CONSOLIDATED"):
                    break
                address.append(compact_spaces(lines[j]))
                j += 1
        if line.startswith("PORTFOLIO VALUE"):
            value_match = re.search(r"`\s*([\d,]+\.\d+)", line)
            if value_match:
                portfolio_value = parse_decimal(value_match.group(1))
        pan_match = re.search(r"\(PAN:([A-Z0-9X]+)\)", line)
        if pan_match:
            pan = pan_match.group(1)

    return {
        "nsdl_id": nsdl_id,
        "statement_period": statement_period,
        "investor": {
            "name": investor_name,
            "pan": pan,
            "address": address,
            "portfolio_value_inr": portfolio_value,
        },
    }


def parse_account_summary(lines: list[str]) -> dict[str, Any]:
    accounts: list[dict[str, Any]] = []
    total = None
    grand_total = None
    start = next(
        (i for i, line in enumerate(lines) if line.startswith("Account Type Account Details")), None
    )
    if start is None:
        return {"accounts": accounts, "total_inr": total, "grand_total_inr": grand_total}

    i = start + 1
    while i < len(lines):
        line = lines[i]
        if line.startswith("Total "):
            total = parse_decimal(line.split()[-1])
            i += 1
            continue
        if line.startswith("Grand Total"):
            grand_total = parse_decimal(line.split()[-1])
            break
        if line.startswith("Your e-Insurance Account"):
            break

        if line.startswith("NSDL Demat Account") or line.startswith("CDSL Demat Account"):
            account_type = "NSDL" if line.startswith("NSDL") else "CDSL"
            detail_parts = [
                line.replace("NSDL Demat Account", "", 1).replace("CDSL Demat Account", "", 1).strip()
            ]
            i += 1
            while i < len(lines) and not lines[i].startswith("DP ID:") and not lines[i].startswith("Total "):
                detail_parts.append(lines[i])
                i += 1
            if i >= len(lines) or not lines[i].startswith("DP ID:"):
                continue

            dp_line = lines[i]
            if i + 1 < len(lines) and re.fullmatch(r"\d+\s+[\d,]+\.\d+", lines[i + 1]):
                dp_line = f"{dp_line} {lines[i + 1]}"
                i += 1

            dp_match = re.search(
                r"DP ID:\s*(?P<dp_id>[A-Z0-9]+)\s+Client ID:\s*(?P<client_id>[A-Z0-9]+)\s+(?P<count>\d+)\s+(?P<value>[\d,]+\.\d+)",
                dp_line,
            )
            accounts.append(
                {
                    "account_type": account_type,
                    "account_details": compact_spaces(" ".join(part for part in detail_parts if part)),
                    "dp_id": dp_match.group("dp_id") if dp_match else None,
                    "client_id": dp_match.group("client_id") if dp_match else None,
                    "isin_or_scheme_count": int(dp_match.group("count")) if dp_match else None,
                    "value_inr": parse_decimal(dp_match.group("value")) if dp_match else None,
                }
            )
        i += 1

    return {"accounts": accounts, "total_inr": total, "grand_total_inr": grand_total}


def parse_portfolio_trend(lines: list[str]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    start = next(
        (i for i, line in enumerate(lines) if line.startswith("Month Consolidated Portfolio")), None
    )
    if start is None:
        return entries
    i = start + 1
    while i < len(lines):
        line = lines[i]
        if line.startswith("PORTFOLIO COMPOSITION"):
            break
        if re.match(r"^[A-Z]{3}\s+\d{4}", line):
            row = compact_spaces(line)
            if "NSDL CAS not" in row and i + 1 < len(lines) and lines[i + 1].startswith("generated"):
                row = compact_spaces(f"{row} {lines[i + 1]}")
                i += 1
            if "NSDL CAS not generated" in row:
                m = re.match(
                    r"^(?P<month>[A-Z]{3}\s+\d{4})\s+NSDL CAS not generated\s+NA\s+NA$", row
                )
                if m:
                    entries.append(
                        {
                            "month": m.group("month"),
                            "portfolio_value_inr": None,
                            "change_inr": None,
                            "change_percent": None,
                            "remark": "NSDL CAS not generated",
                        }
                    )
            else:
                m = re.match(
                    r"^(?P<month>[A-Z]{3}\s+\d{4})\s+(?P<value>[\d,]+\.\d+)\s+"
                    r"(?P<change>NA|[\-\d,]+\.\d+)\s+(?P<pct>NA|[\-\d.]+)$",
                    row,
                )
                if m:
                    entries.append(
                        {
                            "month": m.group("month"),
                            "portfolio_value_inr": parse_decimal(m.group("value")),
                            "change_inr": parse_decimal(m.group("change")),
                            "change_percent": parse_decimal(m.group("pct")),
                            "remark": None,
                        }
                    )
        i += 1
    return entries


def parse_asset_composition(lines: list[str]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    start = next(
        (i for i, line in enumerate(lines) if line.startswith("ASSET CLASS Value in")), None
    )
    if start is None:
        return entries
    i = start + 1
    while i < len(lines):
        line = compact_spaces(lines[i])
        if line.startswith("CDSL Demat Account"):
            break
        if line.startswith("TOTAL"):
            total_match = re.match(r"^TOTAL\s+([\d,]+\.\d+)$", line)
            entries.append(
                {
                    "asset_class": "TOTAL",
                    "value_inr": parse_decimal(total_match.group(1)) if total_match else None,
                    "percent": None,
                }
            )
            break
        m = re.match(r"^(?P<asset>.+?)\s+(?P<value>[\d,]+\.\d+)\s+(?P<pct>[\d.]+%)$", line)
        if m:
            entries.append(
                {
                    "asset_class": m.group("asset"),
                    "value_inr": parse_decimal(m.group("value")),
                    "percent": parse_decimal(m.group("pct").replace("%", "")),
                }
            )
        i += 1
    return entries


def parse_holdings(lines: list[str]) -> dict[str, Any]:
    account_match = re.search(
        r"CDSL Demat Account\s+(.+?)\s+DP ID:\s*([A-Z0-9]+)\s+Client ID:\s*([A-Z0-9]+)",
        " ".join(lines),
    )
    account = {
        "account_type": "CDSL",
        "account_details": account_match.group(1) if account_match else None,
        "dp_id": account_match.group(2) if account_match else None,
        "client_id": account_match.group(3) if account_match else None,
    }

    blocks: list[list[str]] = []
    current: list[str] = []
    in_table = False
    for line in lines:
        if line.startswith("ISIN SECURITY Current Bal."):
            in_table = True
            continue
        if not in_table:
            continue
        if line.startswith("Sub Total") or line.startswith("Total"):
            if current:
                blocks.append(current)
                current = []
            continue
        token = line.split()[0] if line.split() else ""
        if ISIN_RE.match(token):
            if current:
                blocks.append(current)
            current = [line]
        elif current:
            current.append(line)
    if current:
        blocks.append(current)

    securities: list[dict[str, Any]] = []
    for block in blocks:
        joined = " ".join(block)
        tokens = joined.split()
        if not tokens or not ISIN_RE.match(tokens[0]):
            continue
        isin = tokens[0]
        numeric_start = len(tokens)
        for idx in range(1, len(tokens)):
            if re.fullmatch(r"[\d,]+\.\d+", tokens[idx]):
                numeric_start = idx
                break
        security_name = compact_spaces(" ".join(tokens[1:numeric_start]))
        metrics = tokens[numeric_start:]
        if len(metrics) < 11:
            continue
        securities.append(
            {
                "isin": isin,
                "security": security_name,
                "current_balance": parse_decimal(metrics[0]),
                "free_balance": parse_decimal(metrics[1]),
                "lent_balance": parse_decimal(metrics[2]),
                "safekeep_balance": parse_decimal(metrics[3]),
                "locked_in_balance": parse_decimal(metrics[4]),
                "pledge_setup_balance": parse_decimal(metrics[5]),
                "pledged_balance": parse_decimal(metrics[6]),
                "earmarked_balance": parse_decimal(metrics[7]),
                "pledgee_balance": parse_decimal(metrics[8]),
                "market_price_or_face_value": parse_decimal(metrics[9]),
                "value_inr": parse_decimal(metrics[10]),
            }
        )

    return {"account": account, "securities": securities}


def parse_transaction_isin_sections(lines: list[str]) -> list[dict[str, Any]]:
    sections: list[dict[str, Any]] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.startswith("ISIN :"):
            i += 1
            continue

        header_match = re.match(r"ISIN\s*:\s*(?P<isin>[A-Z0-9]{12})\s+-\s+(?P<security>.+)$", line)
        section: dict[str, Any] = {
            "isin": header_match.group("isin") if header_match else None,
            "security": header_match.group("security") if header_match else None,
            "opening_balance": None,
            "closing_balance": None,
            "transactions": [],
        }
        i += 1

        tx_buffer: list[str] = []
        while i < len(lines):
            current = lines[i]
            if current.startswith("ISIN :") or current.startswith("Know more about your accounts"):
                break
            if DATE_RE.match(current.split()[0]):
                if tx_buffer:
                    parsed = parse_transaction_buffer(" ".join(tx_buffer), section)
                    if parsed:
                        section["transactions"].append(parsed)
                tx_buffer = [current]
            elif tx_buffer:
                tx_buffer.append(current)
            i += 1

        if tx_buffer:
            parsed = parse_transaction_buffer(" ".join(tx_buffer), section)
            if parsed:
                section["transactions"].append(parsed)
        sections.append(section)
    return sections


def parse_transaction_buffer(buffer_text: str, section: dict[str, Any]) -> dict[str, Any] | None:
    text = compact_spaces(buffer_text)
    date_match = re.match(r"^(?P<date>\d{2}-[A-Za-z]{3}-\d{4})\s+(?P<rest>.+)$", text)
    if not date_match:
        return None
    date = date_match.group("date")
    rest = date_match.group("rest")

    open_match = re.match(r"Opening Balance\s+(?P<bal>[\d,]+\.\d+)$", rest)
    if open_match:
        section["opening_balance"] = parse_decimal(open_match.group("bal"))
        return {
            "date": date,
            "particulars": "Opening Balance",
            "credit": None,
            "debit": None,
            "current_balance": parse_decimal(open_match.group("bal")),
        }

    close_match = re.match(r"Closing Balance\s+(?P<bal>[\d,]+\.\d+)$", rest)
    if close_match:
        section["closing_balance"] = parse_decimal(close_match.group("bal"))
        return {
            "date": date,
            "particulars": "Closing Balance",
            "credit": None,
            "debit": None,
            "current_balance": parse_decimal(close_match.group("bal")),
        }

    nums = re.findall(r"[\d,]+\.\d+", rest)
    particulars = rest
    if nums:
        tail = " ".join(nums)
        if particulars.endswith(tail):
            particulars = particulars[: -len(tail)].strip()

    credit = (
        parse_decimal(nums[-2])
        if len(nums) >= 2
        else (parse_decimal(nums[-1]) if len(nums) == 1 else None)
    )
    current = parse_decimal(nums[-1]) if nums else None

    return {
        "date": date,
        "particulars": particulars,
        "credit": credit,
        "debit": None,
        "current_balance": current,
    }


def parse_transactions(lines: list[str]) -> dict[str, Any]:
    joined = " ".join(lines)
    account_match = re.search(
        r"CDSL Demat Account\s+(.+?)\s+DP ID:\s*([A-Z0-9]+)\s+Client ID:\s*([A-Z0-9]+)",
        joined,
    )
    account = {
        "account_type": "CDSL",
        "account_details": account_match.group(1) if account_match else None,
        "dp_id": account_match.group(2) if account_match else None,
        "client_id": account_match.group(3) if account_match else None,
    }
    return {
        "account": account,
        "isin_sections": parse_transaction_isin_sections(lines),
    }


def parse_nsdl_pdf(pdf_path: Path, password: str | None = None) -> dict[str, Any]:
    """Parse an NSDL e-CAS PDF into a structured dict."""
    pages = extract_pages(pdf_path, password=password)
    all_lines = flatten_pages(pages)
    full_text = "\n".join(all_lines)

    header = parse_header(all_lines[:220], full_text)
    account_summary = parse_account_summary(all_lines[:260])
    portfolio_trend = parse_portfolio_trend(all_lines[:360])
    asset_composition = parse_asset_composition(all_lines[:420])
    holdings = parse_holdings(all_lines)
    transactions = parse_transactions(all_lines)

    return {
        "source_file": str(pdf_path),
        **header,
        "summary": {
            **account_summary,
            "portfolio_trend": portfolio_trend,
            "asset_composition": asset_composition,
        },
        "holdings": holdings,
        "transactions": transactions,
    }


def main() -> None:
    args = parse_args()
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    output = args.output or args.input_pdf.with_suffix(".json")
    payload = parse_nsdl_pdf(args.input_pdf, password=args.password)
    output.write_text(
        json.dumps(payload, indent=2 if args.pretty else None, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    print(output)


if __name__ == "__main__":
    main()
