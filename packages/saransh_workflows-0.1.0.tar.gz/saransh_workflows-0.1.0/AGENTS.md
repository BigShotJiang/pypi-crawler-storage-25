# AGENTS.md — Development Log & Change History

This file tracks all significant changes, decisions, and known behaviours for the `saransh-workflows` project.

---

## Project Overview

| Property | Value |
|----------|-------|
| Repo | `sagarchandagarwal/saransh-workflows` |
| Branch | `main` |
| Python | ≥ 3.11 |
| Core dependency | `pypdf >= 6.0.0` |
| Created | 2025-05-01 |

---

## Parsers

### `saransh_workflows/cams.py` — CAMS Consolidated Account Statement

**Sample validated against:** `cams-parser/cams-statements/cams_sample.pdf`

**Output:** 8 folios, 0 warnings

**Key design decisions:**
- PDF extraction uses `extraction_mode='layout'` (pypdf) to preserve column alignment on the first page.
- Investor fields on page 1 are isolated by splitting each raw line on two-or-more spaces and keeping only the left column (`re.split(r'\s{2,}', ...)`). This prevents narrative text from the right column bleeding into name/address fields.
- All numeric regexes use `\.\d+` (variable decimal places) rather than `\.\d{2}` to handle fund-house-specific precision (e.g. Canara Robeco uses 4 decimal places on unit prices).
- `split_sections()` / `is_section_start()` detect per-folio blocks by looking for lines ending with `"Mutual Fund"` followed by `"Folio No:"` within the next 5 lines.

**Edge cases fixed:**
- Two-column layout on page 1 leaked narrative text into investor fields → fixed with left-column isolation.
- Canara Robeco price field had 4 decimal places → widened regex to `\.\d+`.

---

### `saransh_workflows/cdsl.py` — CDSL Consolidated Account Statement

**Sample validated against:** `cdsl-parser/cdsl-statements/cdsl_sample.pdf` (26 pages)

**Output:** 13 MF folios, 5 CDSL accounts (4 nil), 2 NSDL accounts, 0 spurious entries

**Key design decisions:**
- `normalize_pages()` strips Hindi/bilingual characters (`"â€"` / `"â"` / `"�"` in lines), page headers, and navigation boilerplate before any regex work.
- Statement period regex is applied on the **raw** page text (before cleaning) because the bilingual header line is removed during normalisation.
- MF detail block scheme names may wrap across multiple lines; `parse_mf_detail_blocks()` loops until a `"Folio No :"` line to accumulate all parts.
- MF transaction scheme names may similarly wrap; `parse_mf_transactions()` loops until an `"ISIN :"` line.
- `"No Transaction during the period"` and `"Nil Holding"` are checked with `in` (not `startswith`) because they may be concatenated with Hindi text on the same line.
- `has_opening_balance_nearby()` guards against false-positive AMC header detection (e.g. SBI MF load-structure pages).
- `merge_mf_data()` skips transaction-only entries that have no material data (no transactions, no opening/closing balance) to prevent phantom folios.

**Edge cases fixed:**
- Statement period in bilingual line not extractable from cleaned text → switched to raw-page regex.
- Wrapped scheme names in detail and transaction blocks → accumulate-until-next-sentinel loop.
- `"No Transaction during the period"` concatenated with Hindi → `in` test.
- Spurious SBI MF folio from load-structure page → `has_opening_balance_nearby()` guard.

---

### `saransh_workflows/nsdl.py` — NSDL e-CAS

**Sample validated against:** `nsdl-parser/nsdl-statements/NSDLe-CAS_105037233_NOV_2024.PDF.pdf` (6 pages)

**Output:** 2 holdings, 2 ISIN transaction sections, 13 portfolio trend rows

**Key design decisions:**
- `extract_pages()` strips navigation bar lines (`"Summary Holdings Transactions…"`) and bare page-number lines (`"Page N"`).
- Statement period is extracted from the full joined text (not per-page) so it works when the period line is split across a page boundary.
- `parse_portfolio_trend()` uses a peek-ahead join: when `"NSDL CAS not"` is found in a row and the next line starts with `"generated"`, the two lines are joined before regex matching.
- Holdings and transactions both search for a CDSL account block identified by `"CDSL Demat Account … DP ID: … Client ID:"`.
- `parse_transaction_buffer()` distinguishes Opening/Closing Balance sentinel rows from regular transaction rows before extracting credit/current-balance numerics.

**Edge cases fixed:**
- `"NSDL CAS not generated"` split across two lines in trend table → peek-ahead join.
- Page-number lines like `"Page 3"` matched incorrectly → `line[5:].isdigit()` check (not `" of " in line`).

---

## Package History

### v0.1.0 — 2025-05-01

**Added:**
- `saransh_workflows/` Python package with three modules: `cams`, `cdsl`, `nsdl`.
- `saransh_workflows/__init__.py` re-exporting `parse_cams_pdf`, `parse_cdsl_pdf`, `parse_nsdl_pdf`.
- `pyproject.toml` using `hatchling` build backend; three `[project.scripts]` entry-points: `parse-cams`, `parse-cdsl`, `parse-nsdl`.
- `README.md` with installation, CLI usage, Python API, and JSON schema documentation.
- `.gitignore` ignoring `*-statements/` folders (PDFs + generated JSON), `.venv/`, build artefacts, and macOS/IDE noise.
- `AGENTS.md` (this file).

**Standalone scripts retained (no changes):**
- `cams-parser/parse_cams_pdf.py`
- `cdsl-parser/parse_cdsl_pdf.py`
- `nsdl-parser/parse_nsdl_pdf.py`

---

## Validation Commands

```bash
# CAMS
.venv/bin/python cams-parser/parse_cams_pdf.py \
  cams-parser/cams-statements/cams_sample.pdf \
  --pretty -o cams-parser/cams-statements/cams_sample.json

# CDSL
.venv/bin/python cdsl-parser/parse_cdsl_pdf.py \
  cdsl-parser/cdsl-statements/cdsl_sample.pdf \
  --pretty -o cdsl-parser/cdsl-statements/cdsl_sample.json

# NSDL
.venv/bin/python nsdl-parser/parse_nsdl_pdf.py \
  "nsdl-parser/nsdl-statements/NSDLe-CAS_105037233_NOV_2024.PDF.pdf" \
  --pretty -o nsdl-parser/nsdl-statements/nsdl_sample.json
```

---

## Known Limitations / Future Work

- [ ] CDSL: Asset allocation and monthly valuation sections may not parse correctly if the PDF uses a significantly different layout version.
- [ ] NSDL: Only CDSL demat holdings are extracted; NSDL demat accounts within the same e-CAS file are not yet parsed.
- [ ] All parsers: No test suite — validation is manual via sample PDFs.
- [ ] Bank statement parser (`bank-statements-parser/`) is scaffolded but not yet implemented.
- [ ] Publish to PyPI under `saransh-workflows`.
