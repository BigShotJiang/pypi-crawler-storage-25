from __future__ import annotations

import argparse
import json
import logging
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from pypdf import PdfReader


DATE_RE = re.compile(r"\d{2}-[A-Za-z]{3}-\d{4}")
AMOUNT_RE = re.compile(r"\(?[\d,]+(?:\.\d+)?\)?")
TRANSACTION_ROW_RE = re.compile(
    r"^(?P<date>\d{2}-[A-Za-z]{3}-\d{4})\s+"
    r"(?P<transaction>.+?)\s+"
    r"(?P<amount>\(?[\d,]+\.\d+\)?)\s+"
    r"(?P<units>\(?[\d,]+\.\d+\)?)\s+"
    r"(?P<price>\(?[\d,]+\.\d+\)?)\s+"
    r"(?P<balance>\(?[\d,]+\.\d+\)?)$"
)
CHARGE_ROW_RE = re.compile(
    r"^(?P<date>\d{2}-[A-Za-z]{3}-\d{4})\s+(?P<amount>\(?[\d,]+\.\d+\)?)$"
)
PORTFOLIO_ROW_RE = re.compile(
    r"^(?P<fund>.+?Mutual Fund)\s+(?P<cost>[\d,]+\.\d{2})\s+(?P<market>[\d,]+\.\d{2})$"
)
SUMMARY_RE = re.compile(
    r"Closing Unit Balance:\s*(?P<closing>[\d,]+\.\d+)\s+"
    r"NAV on (?P<nav_date>\d{2}-[A-Za-z]{3}-\d{4}): INR (?P<nav>[\d,]+\.\d+)\s+"
    r"Total Cost Value:\s*(?P<cost>[\d,]+\.\d+)\s+"
    r"Market Value on (?P<market_date>\d{2}-[A-Za-z]{3}-\d{4}): INR (?P<market>[\d,]+\.\d+)"
)


@dataclass
class SectionParseResult:
    data: dict[str, Any]
    warnings: list[str]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Parse a CAMS PDF statement into JSON.")
    parser.add_argument("input_pdf", type=Path, help="Path to the CAMS statement PDF")
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        help="Optional output JSON path. Defaults to the input path with a .json suffix.",
    )
    parser.add_argument(
        "--pretty",
        action="store_true",
        help="Pretty-print the generated JSON.",
    )
    parser.add_argument(
        "--password",
        default=None,
        help="Password to decrypt a password-protected PDF.",
    )
    return parser.parse_args()


def clean_numeric(value: str | None) -> str | None:
    if value is None:
        return None
    return value.replace(",", "").replace("(", "-").replace(")", "")


def parse_decimal(value: str | None) -> float | None:
    cleaned = clean_numeric(value)
    if not cleaned:
        return None
    try:
        return float(Decimal(cleaned))
    except InvalidOperation:
        return None


def compact_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def extract_pages(pdf_path: Path, password: str | None = None) -> list[str]:
    reader = PdfReader(str(pdf_path), password=password)
    return [page.extract_text(extraction_mode="layout") or "" for page in reader.pages]


def remove_page_noise(lines: list[str]) -> list[str]:
    filtered: list[str] = []
    skip_exact = {
        "Consolidated Account Statement",
        "PORTFOLIO SUMMARY",
        "Mutual Fund Cost Value Market Value",
        "(INR)",
    }
    for raw_line in lines:
        line = raw_line.rstrip()
        stripped = line.strip()
        if not stripped:
            continue
        if stripped in skip_exact:
            continue
        if stripped.startswith("Page ") and " of " in stripped:
            continue
        if stripped.startswith("Date") and "Transaction" in stripped:
            continue
        if stripped.startswith("(INR)") and "Balance" in stripped:
            continue
        if stripped in {
            "Date Transaction Amount Units Price Unit",
            "Balance",
        }:
            continue
        if stripped == "Date Transaction":
            continue
        if stripped == "Amount Units Price Unit":
            continue
        if stripped == "Balance":
            continue
        if re.fullmatch(r"\d{2}-[A-Za-z]{3}-\d{4} To \d{2}-[A-Za-z]{3}-\d{4}", stripped):
            continue
        filtered.append(stripped)
    return filtered


def parse_investor(first_page_text: str) -> dict[str, Any]:
    lines = []
    for raw_line in first_page_text.splitlines():
        if not raw_line.strip():
            continue
        left_column = re.split(r"\s{2,}", raw_line.strip(), maxsplit=1)[0].strip()
        if left_column:
            lines.append(left_column)
    summary_index = next((i for i, line in enumerate(lines) if line.strip() == "PORTFOLIO SUMMARY"), len(lines))
    info_lines = [line.strip() for line in lines[:summary_index]]

    email = None
    name = None
    name_index = None
    address: list[str] = []
    phone_res = None
    mobile = None

    for index, line in enumerate(info_lines):
        if line.startswith("Email Id:"):
            email = compact_spaces(line.split(":", 1)[1])
            for candidate_index in range(index + 1, len(info_lines)):
                candidate = compact_spaces(info_lines[candidate_index])
                if candidate.startswith("Phone Res:") or candidate.startswith("Mobile:"):
                    break
                if candidate and candidate[0].isupper() and " " in candidate:
                    name = candidate
                    name_index = candidate_index
                    break
        elif line.startswith("Phone Res:"):
            phone_res = compact_spaces(line.split(":", 1)[1])
        elif line.startswith("Mobile:"):
            mobile = compact_spaces(line.split(":", 1)[1])

    if name and name_index is not None:
        start = name_index + 1
        for line in info_lines[start:]:
            if line.startswith("Phone Res:") or line.startswith("Mobile:"):
                break
            if not line or line[0].islower():
                continue
            address.append(compact_spaces(line))

    return {
        "email": email,
        "name": name,
        "address": address,
        "phone_res": phone_res,
        "mobile": mobile,
    }


def parse_statement_period(text: str) -> dict[str, str] | None:
    match = re.search(
        r"Consolidated Account Statement\s+(?P<from>\d{2}-[A-Za-z]{3}-\d{4}) To (?P<to>\d{2}-[A-Za-z]{3}-\d{4})",
        text,
    )
    if not match:
        return None
    return {"from": match.group("from"), "to": match.group("to")}


def parse_portfolio_summary(first_page_text: str) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    lines = [line.strip() for line in first_page_text.splitlines() if line.strip()]
    in_summary = False
    for line in lines:
        if line == "PORTFOLIO SUMMARY":
            in_summary = True
            continue
        if not in_summary:
            continue
        if line.startswith("Date"):
            break
        match = PORTFOLIO_ROW_RE.match(compact_spaces(line))
        if match:
            entries.append(
                {
                    "fund_house": match.group("fund"),
                    "cost_value_inr": parse_decimal(match.group("cost")),
                    "market_value_inr": parse_decimal(match.group("market")),
                }
            )
    return entries


def is_section_start(lines: list[str], index: int) -> bool:
    if not lines[index].endswith("Mutual Fund"):
        return False
    window = lines[index + 1 : index + 6]
    return any("Folio No:" in line for line in window)


def split_sections(lines: list[str]) -> list[list[str]]:
    sections: list[list[str]] = []
    current: list[str] = []
    for index, line in enumerate(lines):
        if is_section_start(lines, index):
            if current:
                sections.append(current)
            current = [line]
            continue
        if current:
            current.append(line)
    if current:
        sections.append(current)
    return sections


def parse_nominees(line: str) -> list[str]:
    nominees = []
    for match in re.finditer(r"Nominee\s+\d+:\s*([^:]*?)(?=\s+Nominee\s+\d+:|$)", line):
        value = compact_spaces(match.group(1))
        if value:
            nominees.append(value)
    return nominees


def parse_section(lines: list[str]) -> SectionParseResult:
    warnings: list[str] = []
    data: dict[str, Any] = {
        "fund_house": lines[0],
        "folio_no": None,
        "pan": None,
        "kyc": None,
        "holder_name": None,
        "scheme_code": None,
        "scheme_name": None,
        "isin": None,
        "registrar": None,
        "nominees": [],
        "opening_unit_balance": None,
        "transactions": [],
        "closing_unit_balance": None,
        "nav": None,
        "total_cost_value_inr": None,
        "market_value": None,
        "notes": [],
    }

    transaction_lines_started = False
    last_transaction: dict[str, Any] | None = None

    for index, line in enumerate(lines[1:], start=1):
        compact = compact_spaces(line)

        if compact.startswith("Folio No:"):
            folio_match = re.search(r"Folio No:\s*(.*?)\s+PAN:\s*(\S+)", compact)
            if folio_match:
                data["folio_no"] = compact_spaces(folio_match.group(1))
                data["pan"] = folio_match.group(2)
            kyc_match = re.search(r"KYC:\s*([^\s]+(?:\s+PAN:\s*[^\s]+)?)", compact)
            if kyc_match:
                data["kyc"] = compact_spaces(kyc_match.group(1))
            continue

        if data["holder_name"] is None and "- ISIN:" not in compact and not compact.startswith("Nominee"):
            data["holder_name"] = compact
            continue

        if "- ISIN:" in compact:
            scheme_match = re.match(r"(?P<code>[^-]+)-(?P<name>.+?)\s+-\s+ISIN:\s*(?P<isin>\S+)", compact)
            if scheme_match:
                data["scheme_code"] = compact_spaces(scheme_match.group("code"))
                data["scheme_name"] = compact_spaces(scheme_match.group("name"))
                data["isin"] = scheme_match.group("isin")
            if compact.endswith("Registrar :") and index + 1 < len(lines):
                data["registrar"] = compact_spaces(lines[index + 1])
            continue

        if compact == "Registrar :" and index + 1 < len(lines):
            data["registrar"] = compact_spaces(lines[index + 1])
            continue

        if compact.startswith("Nominee"):
            data["nominees"] = parse_nominees(compact)
            continue

        if "Opening Unit Balance:" in compact:
            opening_match = re.search(r"Opening Unit Balance:\s*([\d,]+\.\d{3})", compact)
            if opening_match:
                data["opening_unit_balance"] = parse_decimal(opening_match.group(1))
            transaction_lines_started = True
            continue

        summary_match = SUMMARY_RE.search(compact)
        if summary_match:
            data["closing_unit_balance"] = parse_decimal(summary_match.group("closing"))
            data["nav"] = {
                "date": summary_match.group("nav_date"),
                "value_inr": parse_decimal(summary_match.group("nav")),
            }
            data["total_cost_value_inr"] = parse_decimal(summary_match.group("cost"))
            data["market_value"] = {
                "date": summary_match.group("market_date"),
                "value_inr": parse_decimal(summary_match.group("market")),
            }
            transaction_lines_started = False
            continue

        if transaction_lines_started:
            transaction_match = TRANSACTION_ROW_RE.match(compact)
            if transaction_match:
                last_transaction = {
                    "date": transaction_match.group("date"),
                    "transaction": compact_spaces(transaction_match.group("transaction")),
                    "amount_inr": parse_decimal(transaction_match.group("amount")),
                    "units": parse_decimal(transaction_match.group("units")),
                    "price_inr": parse_decimal(transaction_match.group("price")),
                    "unit_balance": parse_decimal(transaction_match.group("balance")),
                    "charges": [],
                }
                data["transactions"].append(last_transaction)
                continue

            charge_match = CHARGE_ROW_RE.match(compact)
            if charge_match and last_transaction is not None:
                last_transaction["charges"].append(
                    {
                        "date": charge_match.group("date"),
                        "amount_inr": parse_decimal(charge_match.group("amount")),
                    }
                )
                continue

            if DATE_RE.fullmatch(compact):
                continue

        if compact and compact != data.get("registrar"):
            data["notes"].append(compact)

    if data["folio_no"] is None:
        warnings.append(f"Missing folio number for section {data['fund_house']}")
    if data["scheme_name"] is None:
        warnings.append(f"Missing scheme details for section {data['fund_house']}")
    return SectionParseResult(data=data, warnings=warnings)


def parse_cams_pdf(pdf_path: Path, password: str | None = None) -> dict[str, Any]:
    pages = extract_pages(pdf_path, password=password)
    full_text = "\n".join(pages)
    first_page = pages[0] if pages else ""
    cleaned_lines = remove_page_noise(full_text.splitlines())
    sections = split_sections(cleaned_lines)

    parsed_sections = [parse_section(section) for section in sections]

    return {
        "source_file": str(pdf_path),
        "statement_period": parse_statement_period(full_text),
        "investor": parse_investor(first_page),
        "portfolio_summary": parse_portfolio_summary(first_page),
        "folios": [result.data for result in parsed_sections],
        "warnings": [warning for result in parsed_sections for warning in result.warnings],
    }


def main() -> None:
    args = parse_args()
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    output_path = args.output or args.input_pdf.with_suffix(".json")
    payload = parse_cams_pdf(args.input_pdf, password=args.password)

    output_path.write_text(
        json.dumps(payload, indent=2 if args.pretty else None, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    print(output_path)


if __name__ == "__main__":
    main()