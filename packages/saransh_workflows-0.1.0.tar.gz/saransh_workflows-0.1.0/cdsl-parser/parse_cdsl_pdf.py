from __future__ import annotations

import argparse
import json
import logging
import re
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from pypdf import PdfReader


ISIN_RE = re.compile(r"^[A-Z0-9]{12}\b")
DATE_RE = re.compile(r"^\d{2}-\d{2}-\d{4}\b")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Parse a CDSL CAS PDF into JSON.")
    parser.add_argument("input_pdf", type=Path, help="Path to the CDSL CAS PDF")
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        help="Optional output JSON path. Defaults to the input path with a .json suffix.",
    )
    parser.add_argument("--pretty", action="store_true", help="Pretty-print the output JSON.")
    parser.add_argument(
        "--password",
        default=None,
        help="Password to decrypt a password-protected PDF.",
    )
    return parser.parse_args()


def compact_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def parse_decimal(value: str | None) -> float | None:
    if value is None:
        return None
    cleaned = value.replace(",", "").replace("(`)", "").strip()
    if cleaned in {"", "--", "-"}:
        return None
    try:
        return float(Decimal(cleaned))
    except InvalidOperation:
        return None


def normalize_pages(pdf_path: Path, password: str | None = None) -> list[list[str]]:
    reader = PdfReader(str(pdf_path), password=password)
    pages: list[list[str]] = []
    for page in reader.pages:
        text = page.extract_text() or ""
        lines = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if "�" in line:
                continue
            if line.startswith("Central Depository Services"):
                continue
            if line.startswith("A Wing, 25th Floor"):
                continue
            if line.startswith("Lower Parel"):
                continue
            if line.startswith("CONSOLIDATED ACCOUNT STATEMENT"):
                continue
            if line.startswith("FORM AND INVESTMENTS"):
                continue
            if line.startswith("Page ") and " of " in line:
                continue
            if line in {
                "Summary of",
                "Investments",
                "Account Details",
                "CDSL Demat",
                "NSDL Demat",
                "MF Details",
                "Notes",
                "About CDSL",
                "Account Details CDSL Demat",
                "Account Details NSDL Demat",
            }:
                continue
            lines.append(line)
        pages.append(lines)
    return pages


def extract_raw_pages(pdf_path: Path, password: str | None = None) -> list[str]:
    reader = PdfReader(str(pdf_path), password=password)
    return [page.extract_text() or "" for page in reader.pages]


def flatten_pages(pages: list[list[str]]) -> list[str]:
    lines: list[str] = []
    for page in pages:
        lines.extend(page)
    return lines


def parse_header(lines: list[str], raw_text: str) -> dict[str, Any]:
    cas_id = None
    statement_period = None
    name = None
    pan = None
    address: list[str] = []

    period_match = re.search(
        r"Statement for the period from (?P<from>\d{2}-[A-Za-z]{3}-\d{4}) to (?P<to>\d{2}-[A-Za-z]{3}-\d{4})",
        raw_text,
    )
    if not period_match:
        period_match = re.search(
            r"FOR THE PERIOD FROM\s+(?P<from>\d{2}-\d{2}-\d{4})\s+TO\s+(?P<to>\d{2}-\d{2}-\d{4})",
            raw_text,
        )
    if period_match:
        statement_period = {"from": period_match.group("from"), "to": period_match.group("to")}

    for index, line in enumerate(lines):
        if line.startswith("CAS ID:"):
            cas_id = line.split(":", 1)[1].strip()
            if index + 1 < len(lines):
                name = compact_spaces(lines[index + 1]).rstrip(" .")
            for next_index in range(index + 2, len(lines)):
                candidate = lines[next_index]
                if candidate.startswith("Statement for the period"):
                    break
                if candidate.startswith("YOUR CONSOLIDATED"):
                    break
                if candidate.startswith("Your Demat Account and Mutual Fund Folios"):
                    break
                address.append(compact_spaces(candidate))
        pan_match = re.search(r"\( PAN\s*:(?P<pan>[A-Z0-9]+) \)", line)
        if pan_match:
            pan = pan_match.group("pan")

    return {
        "cas_id": cas_id,
        "statement_period": statement_period,
        "investor": {
            "name": name,
            "pan": pan,
            "address": address,
        },
    }


def parse_account_summary(lines: list[str]) -> dict[str, Any]:
    accounts: list[dict[str, Any]] = []
    total_portfolio_value = None
    grand_total = None
    start = next((i for i, line in enumerate(lines) if line.startswith("Account T ype")), None)
    if start is None:
        return {"accounts": accounts, "total_portfolio_value_inr": None, "grand_total_inr": None}

    index = start + 1
    while index < len(lines):
        line = lines[index]
        if line.startswith("T otal "):
            total_portfolio_value = parse_decimal(line.split()[-1])
            index += 1
            continue
        if line.startswith("Grand T otal"):
            grand_total = parse_decimal(line.split()[-1])
            break
        if line.startswith("CDSL Demat Account") or line.startswith("NSDL Demat Account"):
            account_type = "CDSL" if line.startswith("CDSL") else "NSDL"
            detail_parts = [line.replace("CDSL Demat Account", "", 1).replace("NSDL Demat Account", "", 1).strip()]
            index += 1
            while index < len(lines) and not lines[index].startswith("DP Id:"):
                detail_parts.append(lines[index])
                index += 1
            if index >= len(lines):
                break
            dp_line = lines[index]
            count_value_line = dp_line
            if not re.search(r"\s\d+\s+[\d,]+\.\d+$", dp_line) and index + 1 < len(lines):
                count_value_line = f"{dp_line} {lines[index + 1]}"
            dp_match = re.search(
                r"DP Id:\s*(?P<dp_id>[A-Z0-9]+)\s+Client Id\s*:\s*(?P<client_id>[A-Z0-9]+)\s+(?P<count>\d+)\s+(?P<value>[\d,]+\.\d+)",
                count_value_line,
            )
            accounts.append(
                {
                    "account_type": account_type,
                    "account_details": compact_spaces(" ".join(part for part in detail_parts if part)),
                    "dp_id": dp_match.group("dp_id") if dp_match else None,
                    "client_id": dp_match.group("client_id") if dp_match else None,
                    "isin_or_scheme_count": int(dp_match.group("count")) if dp_match else None,
                    "value_inr": parse_decimal(dp_match.group("value")) if dp_match else None,
                }
            )
            if count_value_line != dp_line:
                index += 2
            else:
                index += 1
            continue
        if line.startswith("Mutual Fund Folios"):
            match = re.search(r"Mutual Fund Folios\s+(?P<folios>\d+)\s+Folios\s+(?P<schemes>\d+)\s+(?P<value>[\d,]+\.\d+)", line)
            accounts.append(
                {
                    "account_type": "MUTUAL_FUND_FOLIOS",
                    "account_details": "Mutual Fund Folios",
                    "folio_count": int(match.group("folios")) if match else None,
                    "scheme_count": int(match.group("schemes")) if match else None,
                    "value_inr": parse_decimal(match.group("value")) if match else None,
                }
            )
        index += 1

    return {
        "accounts": accounts,
        "total_portfolio_value_inr": total_portfolio_value,
        "grand_total_inr": grand_total,
    }


def parse_monthly_valuation(lines: list[str]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    start = next((i for i, line in enumerate(lines) if line.startswith("Month-Year Portfolio Valuation")), None)
    if start is None:
        return entries
    for line in lines[start + 1 :]:
        if line.startswith("Consolidated Portfolio for Accounts for the Month"):
            break
        match = re.match(
            r"(?P<month>[A-Za-z]{3})\s+(?P<year>\d{4})\s+(?P<value>[\d,]+\.\d+)(?:\s+(?P<change>[\-\d,]+\.\d+)\s+(?P<percent>[\-\d.]+))?",
            line,
        )
        if match:
            entries.append(
                {
                    "month": f"{match.group('month')} {match.group('year')}",
                    "portfolio_value_inr": parse_decimal(match.group("value")),
                    "change_inr": parse_decimal(match.group("change")) if match.group("change") else None,
                    "change_percent": parse_decimal(match.group("percent")) if match.group("percent") else None,
                }
            )
    return entries


def parse_asset_allocation(lines: list[str]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    start = next((i for i, line in enumerate(lines) if line.startswith("Asset Class Value Percentage")), None)
    if start is None:
        return entries
    for line in lines[start + 1 :]:
        if line.startswith("T otal"):
            entries.append(
                {
                    "asset_class": "Total",
                    "value_inr": parse_decimal(line.split()[-2]),
                    "percentage": parse_decimal(line.split()[-1]),
                }
            )
            break
        match = re.match(r"(?P<asset>.+?)\s+(?P<value>[\d,]+\.\d+)\s+(?P<pct>[\d.]+)$", line)
        if match:
            entries.append(
                {
                    "asset_class": compact_spaces(match.group("asset")),
                    "value_inr": parse_decimal(match.group("value")),
                    "percentage": parse_decimal(match.group("pct")),
                }
            )
    return entries


def parse_mf_detail_blocks(lines: list[str]) -> dict[tuple[str | None, str | None], dict[str, Any]]:
    blocks: dict[tuple[str | None, str | None], dict[str, Any]] = {}
    start = next((i for i, line in enumerate(lines) if line == "MF Folios"), None)
    end = next((i for i, line in enumerate(lines) if line.startswith("DEMAT ACCOUNTS HELD WITH CDSL")), len(lines))
    if start is None:
        return blocks
    index = start + 1
    lines = lines[:end]
    while index < len(lines):
        if not lines[index].startswith("AMC Name :"):
            index += 1
            continue
        amc_name = compact_spaces(lines[index].split(":", 1)[1])
        index += 1
        scheme_parts: list[str] = []
        while index < len(lines) and not lines[index].startswith("Folio No :"):
            scheme_parts.append(lines[index])
            index += 1
        scheme_line = compact_spaces(" ".join(scheme_parts))
        folio_line = lines[index] if index < len(lines) else ""
        index += 1
        kyc_line = lines[index] if index < len(lines) else ""
        index += 1
        isin_line = lines[index] if index < len(lines) else ""

        scheme_match = re.match(r"Scheme Name\s*:\s*(?P<scheme>.+?)\s+Scheme Code\s*:\s*(?P<code>.+)$", scheme_line)
        folio_match = re.match(
            r"Folio No\s*:\s*(?P<folio>.+?)\s+Mode of Holding\s*:\s*(?P<holding>.+?)\s+Email id\s*:\s*(?P<email>.+)$",
            folio_line,
        )
        kyc_match = re.match(
            r"KYC of Investor/s\s*:\s*(?P<kyc>.+?)\s+Mobile No\s*:\s*(?P<mobile>.+?)\s+Nominee\s*:\s*(?P<nominee>.+)$",
            kyc_line,
        )
        isin_match = re.match(r"ISIN\s*:\s*(?P<isin>\S+)\s+UCC\s*:\s*(?P<ucc>.*?)\s+RTA\s*:\s*(?P<rta>.+)$", isin_line)

        block = {
            "amc_name": amc_name,
            "scheme_name": compact_spaces(scheme_match.group("scheme")) if scheme_match else None,
            "scheme_code": compact_spaces(scheme_match.group("code")) if scheme_match else None,
            "folio_no": compact_spaces(folio_match.group("folio")) if folio_match else None,
            "mode_of_holding": compact_spaces(folio_match.group("holding")) if folio_match else None,
            "email_id": compact_spaces(folio_match.group("email")) if folio_match else None,
            "kyc_status": compact_spaces(kyc_match.group("kyc")) if kyc_match else None,
            "mobile_no": compact_spaces(kyc_match.group("mobile")) if kyc_match else None,
            "nominee": compact_spaces(kyc_match.group("nominee")) if kyc_match else None,
            "isin": isin_match.group("isin") if isin_match else None,
            "ucc": compact_spaces(isin_match.group("ucc")) if isin_match else None,
            "rta": compact_spaces(isin_match.group("rta")) if isin_match else None,
            "transactions": [],
            "opening_balance": None,
            "closing_balance": None,
        }
        blocks[(block["scheme_code"], block["isin"])] = block
        index += 1
    return blocks


def parse_mf_transaction_row(row: str) -> dict[str, Any]:
    match = re.match(
        r"(?P<date>\d{2}-\d{2}-\d{4})\s+(?P<description>.+?)\s+(?P<amount>[\d,]+\.\d+)\s+(?P<nav>[\d,]+\.\d+)\s+(?P<price>[\d,]+\.\d+)\s+(?P<units>[\d,]+\.\d+)\s+(?P<stamp>[\d,]+\.\d+)\s+(?P<income>[\d,]+(?:\.\d+)?)\s+(?P<capital>[\d,]+(?:\.\d+)?)$",
        row,
    )
    if not match:
        return {"raw": compact_spaces(row)}
    return {
        "date": match.group("date"),
        "description": compact_spaces(match.group("description")),
        "amount_inr": parse_decimal(match.group("amount")),
        "nav_inr": parse_decimal(match.group("nav")),
        "price_inr": parse_decimal(match.group("price")),
        "units": parse_decimal(match.group("units")),
        "stamp_duty_inr": parse_decimal(match.group("stamp")),
        "income_distribution_inr": parse_decimal(match.group("income")),
        "capital_withdrawal_inr": parse_decimal(match.group("capital")),
    }


def parse_mf_transactions(lines: list[str]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    current_amc = None

    def has_opening_balance_nearby(start_index: int) -> bool:
        upper = min(start_index + 12, len(lines))
        return any(lines[idx].startswith("Opening Balance") for idx in range(start_index + 1, upper))

    start = next((i for i, line in enumerate(lines) if line.startswith("MUTUAL FUND UNITS HELD WITH MF/RTA")), None)
    if start is None:
        start = next(
            (
                i
                for i, line in enumerate(lines[:-1])
                if line.endswith("Mutual Fund")
                and not line.startswith("AMC Name :")
                and re.match(r"[A-Z0-9]+\s+-\s+", lines[i + 1])
                and has_opening_balance_nearby(i)
            ),
            None,
        )
    if start is None:
        return entries
    index = start + 1
    while index < len(lines):
        line = lines[index]
        if line.startswith("Load Structures") or line.startswith("NOTES TO CAS"):
            break
        if line.endswith("Mutual Fund") and has_opening_balance_nearby(index):
            current_amc = line
            index += 1
            continue
        scheme_match = re.match(r"(?P<code>[A-Z0-9]+)\s+-\s+(?P<scheme>.+)", line)
        if not scheme_match:
            index += 1
            continue

        scheme_parts = [line]
        index += 1
        while index < len(lines) and not lines[index].startswith("ISIN :"):
            scheme_parts.append(lines[index])
            index += 1
        scheme_line = compact_spaces(" ".join(scheme_parts))
        scheme_match = re.match(r"(?P<code>[A-Z0-9]+)\s+-\s+(?P<scheme>.+)", scheme_line)
        if not scheme_match:
            continue

        entry = {
            "amc_name": current_amc,
            "scheme_code": scheme_match.group("code"),
            "scheme_name": compact_spaces(scheme_match.group("scheme")),
            "isin": None,
            "ucc": None,
            "opening_balance": None,
            "closing_balance": None,
            "transactions": [],
        }
        if index < len(lines) and lines[index].startswith("ISIN :"):
            isin_match = re.match(r"ISIN\s*:\s*(?P<isin>\S+)\s+UCC\s*:\s*(?P<ucc>.*)", lines[index])
            if isin_match:
                entry["isin"] = isin_match.group("isin")
                entry["ucc"] = compact_spaces(isin_match.group("ucc"))
            index += 1

        while index < len(lines) and not lines[index].startswith("Opening Balance"):
            index += 1
        if index < len(lines) and lines[index].startswith("Opening Balance"):
            entry["opening_balance"] = parse_decimal(lines[index].split()[-1])
            index += 1

        buffer: list[str] = []
        while index < len(lines) and not lines[index].startswith("Closing Balance"):
            current_line = lines[index]
            if current_line.startswith("Date Transaction Description") or current_line in {
                "Duty (`)",
                "Income",
                "Distrib",
                "ution (`)",
                "Capital",
                "Withdr",
                "awal (`)",
            }:
                index += 1
                continue
            buffer.append(current_line)
            next_starts_new = index + 1 >= len(lines) or lines[index + 1].startswith("Closing Balance") or DATE_RE.match(lines[index + 1])
            if next_starts_new:
                entry["transactions"].append(parse_mf_transaction_row(" ".join(buffer)))
                buffer = []
            index += 1

        if index < len(lines) and lines[index].startswith("Closing Balance"):
            entry["closing_balance"] = parse_decimal(lines[index].split()[-1])
            index += 1
        entries.append(entry)
    return entries


def parse_holding_row(block: str) -> dict[str, Any]:
    tokens = block.split()
    if not tokens:
        return {"raw": compact_spaces(block)}
    isin = tokens[0]
    numeric_start = len(tokens)
    for idx in range(1, len(tokens)):
        if re.fullmatch(r"(?:--|[\d,]+(?:\.\d+)?)", tokens[idx]):
            numeric_start = idx
            break
    security = compact_spaces(" ".join(tokens[1:numeric_start]))
    metrics = tokens[numeric_start:]
    return {
        "isin": isin,
        "security": security,
        "metrics": metrics,
        "value_inr": parse_decimal(metrics[-1]) if metrics else None,
    }


def parse_cdsl_sections(lines: list[str]) -> list[dict[str, Any]]:
    accounts: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    index = 0
    while index < len(lines):
        line = lines[index]
        if line.startswith("BO ID :"):
            if current:
                accounts.append(current)
            bo_match = re.search(r"BO ID\s*: ?\s*(\d{16}).*?DP Name\s*:\s*(.+?)(?:DP|$)", line)
            current = {
                "bo_id": bo_match.group(1) if bo_match else None,
                "dp_name": compact_spaces(bo_match.group(2)) if bo_match else None,
                "transactions": [],
                "holdings": [],
                "holding_sections": [],
                "no_transaction": False,
                "nil_holding": False,
                "portfolio_values": [],
            }
            index += 1
            continue
        if current is None:
            index += 1
            continue
        if "No Transaction during the period" in line:
            current["no_transaction"] = True
        elif "Nil Holding" in line:
            current["nil_holding"] = True
        elif line.startswith("ISIN Security Transaction"):
            table_lines: list[str] = []
            index += 1
            while index < len(lines) and not lines[index].startswith("HOLDING STATEMENT") and not lines[index].startswith("Portfolio Value") and not lines[index].startswith("BO ID :"):
                if lines[index] not in {"Particulars Date Op. Bal Credit Debit Cl. Bal", "Stamp", "Duty (`)"}:
                    table_lines.append(lines[index])
                index += 1
            current["transactions"] = parse_grouped_isin_blocks(table_lines)
            continue
        elif line.startswith("HOLDING STATEMENT AS ON"):
            section_lines: list[str] = []
            section_title = line
            index += 1
            while index < len(lines) and not lines[index].startswith("Portfolio Value") and not lines[index].startswith("Portfolio Value for Bond") and not lines[index].startswith("BO ID :") and not lines[index].startswith("DPID :"):
                if lines[index] not in {
                    "ISIN Security Current",
                    "Bal",
                    "Frozen",
                    "Pledge",
                    "Setup",
                    "Free Bal",
                    "Market",
                    "Price /",
                    "Face",
                    "Value (`)",
                    "Date Balance Description Lockin Pending",
                    "Demat",
                    "Remat",
                }:
                    section_lines.append(lines[index])
                index += 1
            parsed_rows = parse_isin_blocks(section_lines)
            current["holding_sections"].append({"title": section_title, "rows": parsed_rows})
            current["holdings"].extend(parsed_rows)
            continue
        elif line.startswith("HOLDING STATEMENT OF BONDS AS ON"):
            bond_lines: list[str] = []
            index += 1
            while index < len(lines) and not lines[index].startswith("Portfolio Value for Bond") and not lines[index].startswith("BO ID :"):
                bond_lines.append(lines[index])
                index += 1
            current["bond_holdings"] = parse_isin_blocks(bond_lines)
            continue
        elif line.startswith("Portfolio Value"):
            current["portfolio_values"].append(parse_decimal(line.split()[-1]))
        index += 1
    if current:
        accounts.append(current)
    return accounts


def parse_grouped_isin_blocks(lines: list[str]) -> list[dict[str, Any]]:
    blocks: list[list[str]] = []
    current: list[str] = []
    for line in lines:
        if ISIN_RE.match(line):
            if current:
                blocks.append(current)
            current = [line]
        elif current:
            current.append(line)
    if current:
        blocks.append(current)

    entries: list[dict[str, Any]] = []
    for block in blocks:
        header = block[0]
        isin = header.split()[0]
        transactions = []
        for row in block[1:]:
            if DATE_RE.match(row):
                transactions.append(compact_spaces(row))
        entries.append(
            {
                "isin": isin,
                "security": compact_spaces(header[len(isin) :]),
                "transactions": transactions,
            }
        )
    return entries


def parse_isin_blocks(lines: list[str]) -> list[dict[str, Any]]:
    blocks: list[list[str]] = []
    current: list[str] = []
    for line in lines:
        if ISIN_RE.match(line):
            if current:
                blocks.append(current)
            current = [line]
        elif current:
            current.append(line)
    if current:
        blocks.append(current)
    return [parse_holding_row(" ".join(block)) for block in blocks]


def parse_nsdl_sections(lines: list[str]) -> list[dict[str, Any]]:
    accounts: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    index = 0
    while index < len(lines):
        line = lines[index]
        if line.startswith("DPID :"):
            if current:
                accounts.append(current)
            dp_match = re.search(r"DPID\s*:\s*([A-Z0-9]{16}).*?DP Name\s*:\s*(.+?)(?:DP|$)", line)
            combined = dp_match.group(1) if dp_match else None
            current = {
                "dpid_client_id": combined,
                "dp_id": combined[:8] if combined else None,
                "client_id": combined[8:] if combined else None,
                "dp_name": compact_spaces(dp_match.group(2)) if dp_match else None,
                "transactions": [],
                "holdings": [],
                "no_transaction": False,
            }
            index += 1
            continue
        if current is None:
            index += 1
            continue
        if "No Transaction during the period" in line:
            current["no_transaction"] = True
        elif line.startswith("HOLDING STATEMENT AS ON"):
            section_lines: list[str] = []
            index += 1
            while index < len(lines) and not lines[index].startswith("Portfolio Value") and not lines[index].startswith("DPID :") and not lines[index].startswith("MUTUAL FUND UNITS HELD WITH MF/RTA"):
                if not lines[index].startswith("ISIN Security"):
                    section_lines.append(lines[index])
                index += 1
            current["holdings"] = parse_isin_blocks(section_lines)
            continue
        elif line.startswith("Portfolio Value"):
            current["portfolio_value_inr"] = parse_decimal(line.split()[-1])
        index += 1
    if current:
        accounts.append(current)
    return accounts


def merge_mf_data(details: dict[tuple[str | None, str | None], dict[str, Any]], transactions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged = {key: value.copy() for key, value in details.items()}
    for value in merged.values():
        value["transactions"] = list(value.get("transactions", []))

    for entry in transactions:
        key = (entry.get("scheme_code"), entry.get("isin"))
        has_material_data = bool(entry.get("transactions")) or entry.get("opening_balance") is not None or entry.get("closing_balance") is not None
        if key not in merged and not has_material_data:
            continue
        if key not in merged:
            merged[key] = {
                "amc_name": entry.get("amc_name"),
                "scheme_name": entry.get("scheme_name"),
                "scheme_code": entry.get("scheme_code"),
                "folio_no": None,
                "mode_of_holding": None,
                "email_id": None,
                "kyc_status": None,
                "mobile_no": None,
                "nominee": None,
                "isin": entry.get("isin"),
                "ucc": entry.get("ucc"),
                "rta": None,
                "transactions": [],
                "opening_balance": None,
                "closing_balance": None,
            }
        merged[key]["amc_name"] = merged[key].get("amc_name") or entry.get("amc_name")
        merged[key]["scheme_name"] = merged[key].get("scheme_name") or entry.get("scheme_name")
        merged[key]["opening_balance"] = entry.get("opening_balance")
        merged[key]["closing_balance"] = entry.get("closing_balance")
        merged[key]["transactions"] = entry.get("transactions", [])
        if entry.get("ucc"):
            merged[key]["ucc"] = entry.get("ucc")
    return list(merged.values())


def parse_cdsl_pdf(pdf_path: Path, password: str | None = None) -> dict[str, Any]:
    raw_pages = extract_raw_pages(pdf_path, password=password)
    pages = normalize_pages(pdf_path, password=password)
    all_lines = flatten_pages(pages)
    header = parse_header(all_lines[:120], "\n".join(raw_pages[:3]))
    summary = parse_account_summary(all_lines[:220])
    monthly_valuation = parse_monthly_valuation(all_lines[:260])
    asset_allocation = parse_asset_allocation(all_lines[:260])

    mf_details = parse_mf_detail_blocks(all_lines)
    mf_transactions = parse_mf_transactions(all_lines)
    cdsl_accounts = parse_cdsl_sections(all_lines)
    nsdl_accounts = parse_nsdl_sections(all_lines)

    for account in cdsl_accounts:
        if not account.get("transactions") and not account.get("holdings") and not account.get("holding_sections"):
            account["no_transaction"] = True
            account["nil_holding"] = True
    for account in nsdl_accounts:
        if not account.get("transactions") and not account.get("holdings"):
            account["no_transaction"] = True

    return {
        "source_file": str(pdf_path),
        **header,
        "summary": {
            **summary,
            "monthly_portfolio_valuation": monthly_valuation,
            "asset_allocation": asset_allocation,
        },
        "cdsl_accounts": cdsl_accounts,
        "nsdl_accounts": nsdl_accounts,
        "mutual_fund_folios": merge_mf_data(mf_details, mf_transactions),
    }


def main() -> None:
    args = parse_args()
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    output_path = args.output or args.input_pdf.with_suffix(".json")
    payload = parse_cdsl_pdf(args.input_pdf, password=args.password)
    output_path.write_text(
        json.dumps(payload, indent=2 if args.pretty else None, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    print(output_path)


if __name__ == "__main__":
    main()