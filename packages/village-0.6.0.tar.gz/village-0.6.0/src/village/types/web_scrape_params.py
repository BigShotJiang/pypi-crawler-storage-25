# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["WebScrapeParams"]


class WebScrapeParams(TypedDict, total=False):
    url: Required[str]
    """HTTP(S) URL of the webpage to scrape."""

    max_age: int
    """Maximum cache age in milliseconds.

    If the cached scrape result is older than this, the page will be re-scraped.
    Defaults to 3,600,000 (1 hour).
    """

    min_age: Optional[int]
    """
    Minimum cache age in milliseconds before a cached result is eligible for
    re-scraping. When set, prevents re-fetching pages that were recently scraped.
    When omitted, no minimum age constraint is applied.
    """
