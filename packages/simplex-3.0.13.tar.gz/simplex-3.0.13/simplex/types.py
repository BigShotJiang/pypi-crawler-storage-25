"""
Type definitions for the Simplex SDK.

This module contains TypedDict classes used for type hinting throughout the SDK.
"""

from __future__ import annotations

from typing import Any, TypedDict


class FileMetadata(TypedDict):
    """
    Metadata for a file downloaded or created during a session.

    Attributes:
        filename: The filename
        download_url: The URL the file was downloaded from
        file_size: File size in bytes
        download_timestamp: ISO timestamp when the file was downloaded/created
    """

    filename: str
    download_url: str
    file_size: int
    download_timestamp: str


class SessionStatusResponse(TypedDict, total=False):
    """
    Response from polling session status.

    Attributes:
        in_progress: Whether the session is still running
        success: Whether the session completed successfully (None while in progress)
        metadata: Custom metadata provided when the session was started
        workflow_metadata: Metadata from the workflow definition
        file_metadata: Metadata for files downloaded during the session
        scraper_outputs: Scraper outputs collected during the session, keyed by output name
        structured_output: Structured output fields from workflow execution (None while in progress)
        final_message: A summary of what the agent accomplished (None while in progress)
        paused: Whether the session is currently paused
        paused_key: The pause key if the session is paused
    """

    in_progress: bool
    success: bool | None
    metadata: dict[str, Any]
    workflow_metadata: dict[str, Any]
    file_metadata: list[FileMetadata]
    scraper_outputs: dict[str, Any]
    structured_output: dict[str, Any] | None
    final_message: str | None
    paused: bool
    paused_key: str


class RunWorkflowResponse(TypedDict):
    """
    Response from running a workflow.

    Attributes:
        succeeded: Whether the workflow started successfully
        message: Human-readable status message
        session_id: Unique identifier for this workflow session
        vnc_url: URL for VNC access to the workflow session
        logs_url: URL for viewing session logs
    """

    succeeded: bool
    message: str
    session_id: str
    vnc_url: str
    logs_url: str


class PauseSessionResponse(TypedDict, total=False):
    """
    Response from pausing a session.

    Attributes:
        succeeded: Whether the pause operation succeeded
        action: The action that was performed
        pause_key: The key associated with the pause
        error: Error message if the operation failed
    """

    succeeded: bool
    action: str
    pause_key: str
    error: str


class ResumeSessionResponse(TypedDict, total=False):
    """
    Response from resuming a paused session.

    Attributes:
        succeeded: Whether the resume operation succeeded
        action: The action that was performed
        pause_type: The type of pause ('external' or 'internal')
        key: The key associated with the pause
        error: Error message if the operation failed
    """

    succeeded: bool
    action: str
    pause_type: str
    key: str
    error: str


class SearchWorkflowItem(TypedDict, total=False):
    """
    A single workflow item returned from a search.

    Attributes:
        workflow_id: The workflow's unique identifier
        workflow_name: The workflow's name
        variables: Variables defined in the workflow
        metadata: Optional metadata string
    """

    workflow_id: str
    workflow_name: str
    variables: dict[str, Any]
    metadata: str


class SearchWorkflowsResponse(TypedDict):
    """
    Response from searching workflows.

    Attributes:
        succeeded: Whether the search succeeded
        workflows: List of matching workflows
        count: Total number of matching workflows
    """

    succeeded: bool
    workflows: list[SearchWorkflowItem]
    count: int


class UpdateWorkflowMetadataResponse(TypedDict):
    """
    Response from updating workflow metadata.

    Attributes:
        succeeded: Whether the update succeeded
        message: Human-readable status message
        workflow_id: The workflow that was updated
        metadata: The updated metadata string
    """

    succeeded: bool
    message: str
    workflow_id: str
    metadata: str


class StartEditorSessionResponse(TypedDict, total=False):
    """
    Response from starting an editor session.

    Attributes:
        succeeded: Whether the session started successfully
        workflow_id: The newly created workflow ID
        session_id: The session ID
        vnc_url: URL for VNC access
        logs_url: URL for the SSE log stream
        message_url: URL for posting messages to the session
        filesystem_url: URL for filesystem events
    """

    succeeded: bool
    workflow_id: str
    session_id: str
    vnc_url: str
    logs_url: str
    message_url: str | None
    filesystem_url: str | None


class Add2FAConfigResponse(TypedDict, total=False):
    """
    Response from adding a 2FA configuration.

    Attributes:
        succeeded: Whether the operation succeeded
        added_config: The 2FA configuration that was added
        total_configs: Total number of 2FA configs for the organization
        all_configs: Array of all 2FA configurations
        error: Error message if the operation failed
    """

    succeeded: bool
    added_config: dict[str, Any]
    total_configs: int
    all_configs: list[dict[str, Any]]
    error: str


class WebhookPayload(TypedDict, total=False):
    """
    Payload received from a Simplex webhook.

    Attributes:
        success: Whether the session completed successfully
        final_message: The agent's final message summarizing what was accomplished
        session_id: The session identifier
        file_metadata: Metadata for files created during the session
        scraper_outputs: Scraper outputs collected during the session
        session_metadata: Custom metadata attached to the session
        workflow_id: The workflow identifier
        workflow_metadata: Metadata from the workflow definition
        workflow_result: The workflow execution result
        structured_output: Structured output from the workflow
        screenshot_url: URL to a screenshot taken during the session
    """

    success: bool
    final_message: str
    session_id: str
    file_metadata: list[FileMetadata]
    scraper_outputs: dict[str, Any]
    session_metadata: dict[str, Any]
    workflow_id: str
    workflow_metadata: dict[str, Any]
    workflow_result: dict[str, Any]
    structured_output: dict[str, Any]
    screenshot_url: str


class StartRecordingResponse(TypedDict, total=False):
    """
    Response from starting a recording.

    Attributes:
        succeeded: Whether the recording was started successfully
        status: Recording status ("recording" or "already_recording")
        error: Error message if the request failed
    """

    succeeded: bool
    status: str
    error: str


class StopRecordingResponse(TypedDict, total=False):
    """
    Response from stopping a recording.

    Attributes:
        succeeded: Whether the recording was stopped successfully
        status: Recording status ("stopped" or "not_recording")
        path: Path to the exported recording directory
        action_count: Number of actions captured
        network_count: Number of network events captured
        duration: Recording duration in milliseconds
        error: Error message if the request failed
    """

    succeeded: bool
    status: str
    path: str
    action_count: int
    network_count: int
    duration: int
    error: str


class ClinicalQuestionCitation(TypedDict, total=False):
    """
    Structured pointer back to the payer policy that justifies a clinical
    question. Present on a ClinicalQuestion when the LOB has been backfilled
    with per-question citations; otherwise the question's `citation` field
    will be None and callers fall back to the LOB-level `source`.

    Attributes:
        policy_url: Canonical policy URL on the payer's site.
        policy_id: Payer policy identifier (e.g. "CPB 0345", "5.01.621").
        section: Section reference within the policy (e.g. "§A Eligibility 1.a").
        quote: Verbatim policy snippet this question encodes.
        effective_date: Policy effective date (YYYY-MM-DD).
        evidence_path: Relative path to the evidence markdown file (LOB-level fallback).
    """

    policy_url: str
    policy_id: str
    section: str
    quote: str
    effective_date: str
    evidence_path: str


class ClinicalQuestion(TypedDict, total=False):
    """
    A single question on the payer's PA form, rendered from the LOB's
    clinical schema. Question order + presence are gated by `depends_on`.

    Attributes:
        id: Stable question identifier — pass back as the question key when filling a form.
        prompt: Question text as rendered to the reviewer.
        input_type: One of "boolean", "numeric", "date", "text", "select", "multiselect", "file_upload".
        required: Whether the question is required on the form.
        units: For numeric questions, the expected unit (e.g. "kg/m²", "mg/dL").
        options: For select/multiselect, the allowed answer values.
        depends_on: Question IDs that gate this one.
        source: Evidence markdown path the question was derived from (always populated).
        citation: Structured per-question citation, or None when the LOB hasn't been backfilled with one.
    """

    id: str
    prompt: str
    input_type: str
    required: bool
    units: str
    options: list[str]
    depends_on: list[str]
    source: str
    citation: ClinicalQuestionCitation | None


class ClinicalQuestionsRouting(TypedDict, total=False):
    """
    Payer routing resolved from the (BIN, PCN, state) tuple.

    Attributes:
        pbm_name: Pharmacy Benefit Manager name (e.g. "CVS Caremark").
        line_of_business: Line of business (e.g. "Aetna Commercial", "Humana Part D").
        plan_name_or_group: Plan / group name when distinguishable from LOB.
        confidence: Routing confidence — one of "high", "medium", "low", "ambiguous", "none".
    """

    pbm_name: str
    line_of_business: str
    plan_name_or_group: str
    confidence: str


class ClinicalQuestionsSource(TypedDict, total=False):
    """
    Upstream data source consulted during PA resolution.

    Attributes:
        source_name: Identifier for the source (e.g. "cms_part_d", "caremark_payer_sheet").
        source_url: URL the source was fetched from, when applicable.
        fetch_timestamp: ISO 8601 UTC timestamp of the fetch.
        version: Source version string, when the source exposes one.
    """

    source_name: str
    source_url: str
    fetch_timestamp: str
    version: str


class SearchDrugMatch(TypedDict, total=False):
    """
    One match returned by SimplexClient.search_drugs.

    Attributes:
        full_name: Canonical drug name (e.g. "Wegovy 1MG/0.5ML auto-injectors").
    """

    full_name: str


class SearchDrugsResponse(TypedDict, total=False):
    """
    Response from SimplexClient.search_drugs.

    Attributes:
        succeeded: Whether the search executed successfully.
        query: Echo of the query that was searched.
        matches: Ranked list of matching drugs (best match first).
            Empty list when no match clears the relevance threshold.
    """

    succeeded: bool
    query: str
    matches: list[SearchDrugMatch]


class GetClinicalQuestionsResponse(TypedDict, total=False):
    """
    Response from SimplexClient.get_clinical_questions.

    Attributes:
        matched: Whether the (BIN, PCN, state) tuple resolved to a known payer.
        routing: Resolved payer routing (PBM, LOB, plan).
        drug: Echoed drug_name from the request.
        icd_code: Echoed ICD-10 code from the request.
        coverage_status: One of "resolved", "ambiguous", "not_covered", "unknown_lob", "not_attempted".
        lob_id: Resolved line-of-business ID when coverage_status == "resolved"; None otherwise.
        rationale: Human-readable explanation of the resolution.
        questions: Rendered clinical questions in presentation order. Empty when not resolved.
        sources: Upstream data sources consulted during resolution.
    """

    matched: bool
    routing: ClinicalQuestionsRouting
    drug: str
    icd_code: str
    coverage_status: str
    lob_id: str | None
    rationale: str
    questions: list[ClinicalQuestion]
    sources: list[ClinicalQuestionsSource]


class PatientInfo(TypedDict, total=False):
    """
    Patient demographics for fill_pa.

    Attributes:
        first_name: Patient first name.
        last_name: Patient last name.
        dob: Date of birth as MM/DD/YYYY or YYYY-MM-DD.
        id: Member / cardholder ID from the insurance card.
        address: Street address (line 1).
        city: City.
        state: Two-letter USPS state code.
        zip: 5-digit ZIP.
        home_phone: Home phone number.
        gender: "M" or "F".
    """

    first_name: str
    last_name: str
    dob: str
    id: str
    address: str
    city: str
    state: str
    zip: str
    home_phone: str
    gender: str


class PrescriberInfo(TypedDict, total=False):
    """
    Prescriber information for fill_pa.

    Attributes:
        first_name: Prescriber first name.
        last_name: Prescriber last name.
        npi: National Provider Identifier (10 digits).
        address: Office address (line 1).
        city: City.
        state: Two-letter USPS state code.
        zip: 5-digit ZIP.
        office_phone: Office phone number.
    """

    first_name: str
    last_name: str
    npi: str
    address: str
    city: str
    state: str
    zip: str
    office_phone: str


class FillPaResponse(TypedDict, total=False):
    """
    Response from SimplexClient.fill_pa.

    Attributes:
        succeeded: True when the form was filled and uploaded to S3.
        form_id: UUID assigned to this PA submission.
        signed_url: Short-lived HTTPS URL where the filled PDF can be
            downloaded. Valid for ~24 hours.
        expires_at: ISO-8601 timestamp when signed_url expires.
    """

    succeeded: bool
    form_id: str
    signed_url: str
    expires_at: str
