"""MCP tool registration package."""
