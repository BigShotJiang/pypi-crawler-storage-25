"""Pipeline SDK exceptions."""


class PipelineException(Exception):
    """Base exception for pipeline errors."""

    pass


class ApprovalPendingException(PipelineException):
    """Raised when pipeline execution pauses for human approval.

    This exception is caught by the pipeline runtime to:
    1. Save the current execution state as a checkpoint
    2. Set the execution status to 'waiting_for_approval'
    3. Exit the sandbox cleanly

    When approval is granted and the pipeline is re-run, the decided checkpoint
    returns immediately and execution continues past the approval point.
    """

    def __init__(self, approval_key: str, prompt: str | None = None):
        self.approval_key = approval_key
        self.prompt = prompt
        super().__init__(f"Waiting for approval: {approval_key}")


class PipelineExecutionError(PipelineException):
    """Raised when pipeline execution fails."""

    def __init__(self, message: str, step_name: str | None = None):
        self.step_name = step_name
        super().__init__(message)


class CheckpointError(PipelineException):
    """Raised when checkpoint save/restore fails."""

    pass
