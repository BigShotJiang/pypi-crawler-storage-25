/*
 * // Copyright (c) Radzivon Bartoshyk 9/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#![allow(unused)]
use crate::complex_fma::c_mul_fast;
use crate::err::try_vec;
use crate::mla::fmla;
use crate::util::{
    bitreversed_transpose, compute_twiddle, int_logarithm, is_power_of_three,
    radixn_floating_twiddles_from_base, validate_oof_sizes, validate_scratch,
};
use crate::{FftDirection, FftExecutor, FftSample, ZaftError};
use num_complex::Complex;
use num_traits::{AsPrimitive, Zero};
use std::sync::Arc;

pub(crate) struct Radix3<T> {
    twiddles: Vec<Complex<T>>,
    execution_length: usize,
    twiddle: Complex<T>,
    direction: FftDirection,
    base_fft: Arc<dyn FftExecutor<T> + Send + Sync>,
    base_len: usize,
}

pub(crate) trait Radix3Twiddles {
    #[allow(unused)]
    fn make_twiddles_with_base(
        base: usize,
        size: usize,
        fft_direction: FftDirection,
    ) -> Result<Vec<Complex<Self>>, ZaftError>
    where
        Self: Sized;
}

impl Radix3Twiddles for f64 {
    fn make_twiddles_with_base(
        base: usize,
        size: usize,
        fft_direction: FftDirection,
    ) -> Result<Vec<Complex<Self>>, ZaftError>
    where
        Self: Sized,
    {
        radixn_floating_twiddles_from_base::<f64, 3>(base, size, fft_direction)
    }
}

impl Radix3Twiddles for f32 {
    fn make_twiddles_with_base(
        base: usize,
        size: usize,
        fft_direction: FftDirection,
    ) -> Result<Vec<Complex<Self>>, ZaftError>
    where
        Self: Sized,
    {
        radixn_floating_twiddles_from_base::<f32, 3>(base, size, fft_direction)
    }
}

#[allow(unused)]
impl<T: FftSample + Radix3Twiddles> Radix3<T>
where
    f64: AsPrimitive<T>,
{
    pub fn new(size: usize, fft_direction: FftDirection) -> Result<Radix3<T>, ZaftError> {
        assert!(
            is_power_of_three(size as u64),
            "Input length must be power of 3"
        );

        let exponent = int_logarithm::<3>(size)
            .unwrap_or_else(|| panic!("Radix3 length must be power of 3, but got {size}",));

        let base_fft = match exponent {
            0 => T::butterfly1(fft_direction)?,
            1 => T::butterfly3(fft_direction)?,
            2 => T::butterfly9(fft_direction)?,
            _ => T::butterfly27(fft_direction)?,
        };

        let base_len = base_fft.length();

        let twiddles = T::make_twiddles_with_base(base_len, size, fft_direction)?;

        Ok(Radix3 {
            execution_length: size,
            twiddles,
            twiddle: compute_twiddle::<T>(1, 3, fft_direction),
            direction: fft_direction,
            base_fft,
            base_len,
        })
    }
}

impl<T: FftSample> Radix3<T>
where
    f64: AsPrimitive<T>,
{
    fn base_run(&self, chunk: &mut [Complex<T>]) {
        let mut len = self.base_len;

        unsafe {
            let mut m_twiddles = self.twiddles.as_slice();

            while len < self.execution_length {
                let columns = len;
                len *= 3;
                let third = len / 3;

                for data in chunk.chunks_exact_mut(len) {
                    for j in 0..third {
                        let u0 = *data.get_unchecked(j);
                        let u1 = c_mul_fast(
                            *data.get_unchecked(j + third),
                            *m_twiddles.get_unchecked(2 * j),
                        );
                        let u2 = c_mul_fast(
                            *data.get_unchecked(j + 2 * third),
                            *m_twiddles.get_unchecked(2 * j + 1),
                        );

                        // Radix-3 butterfly
                        let xp = u1 + u2;
                        let xn = u1 - u2;
                        let sum = u0 + xp;

                        let w_1 = Complex {
                            re: fmla(self.twiddle.re, xp.re, u0.re),
                            im: fmla(self.twiddle.re, xp.im, u0.im),
                        };

                        let y0 = sum;
                        let y1 = Complex {
                            re: fmla(-self.twiddle.im, xn.im, w_1.re),
                            im: fmla(self.twiddle.im, xn.re, w_1.im),
                        }; //w_1 + w_2;
                        let y2 = Complex {
                            re: fmla(self.twiddle.im, xn.im, w_1.re),
                            im: fmla(-self.twiddle.im, xn.re, w_1.im),
                        }; //w_1 - w_2;

                        *data.get_unchecked_mut(j) = y0;
                        *data.get_unchecked_mut(j + third) = y1;
                        *data.get_unchecked_mut(j + 2 * third) = y2;
                    }
                }

                m_twiddles = &m_twiddles[columns * 2..];
            }
        }
    }
}

impl<T: FftSample> FftExecutor<T> for Radix3<T>
where
    f64: AsPrimitive<T>,
{
    fn execute(&self, in_place: &mut [Complex<T>]) -> Result<(), ZaftError> {
        let mut scratch = try_vec![Complex::zero(); self.scratch_length()];
        self.execute_with_scratch(in_place, scratch.as_mut_slice())
    }

    fn execute_with_scratch(
        &self,
        in_place: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) -> Result<(), ZaftError> {
        if !in_place.len().is_multiple_of(self.execution_length) {
            return Err(ZaftError::InvalidSizeMultiplier(
                in_place.len(),
                self.execution_length,
            ));
        }

        let scratch = validate_scratch!(scratch, self.scratch_length());

        for chunk in in_place.chunks_exact_mut(self.execution_length) {
            // Digit-reversal permutation
            bitreversed_transpose::<Complex<T>, 3>(self.base_len, chunk, scratch);
            self.base_fft.execute_out_of_place(scratch, chunk)?;
            self.base_run(chunk);
        }
        Ok(())
    }

    fn execute_out_of_place(
        &self,
        src: &[Complex<T>],
        dst: &mut [Complex<T>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, &mut [])
    }

    fn execute_out_of_place_with_scratch(
        &self,
        src: &[Complex<T>],
        dst: &mut [Complex<T>],
        _: &mut [Complex<T>],
    ) -> Result<(), ZaftError> {
        validate_oof_sizes!(src, dst, self.execution_length);

        for (dst, src) in dst
            .chunks_exact_mut(self.execution_length)
            .zip(src.chunks_exact(self.execution_length))
        {
            // Digit-reversal permutation
            bitreversed_transpose::<Complex<T>, 3>(self.base_len, src, dst);
            self.base_fft.execute(dst)?;
            self.base_run(dst);
        }
        Ok(())
    }

    fn execute_destructive_with_scratch(
        &self,
        src: &mut [Complex<T>],
        dst: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, scratch)
    }

    fn direction(&self) -> FftDirection {
        self.direction
    }

    #[inline]
    fn length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn scratch_length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn out_of_place_scratch_length(&self) -> usize {
        0
    }

    fn destructive_scratch_length(&self) -> usize {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::util::test_radix;

    test_radix!(test_radix3, f32, Radix3, 6, 3, 1e-3);
}
