/*
 * // Copyright (c) Radzivon Bartoshyk 6/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::mla::fmla;
use num_complex::Complex;
use num_traits::{MulAdd, Num};
use std::ops::{Mul, Neg};

#[inline(always)]
pub(crate) fn c_mul_fast<
    T: Copy + Clone + Num + Neg<Output = T> + Mul<T, Output = T> + MulAdd<T, Output = T>,
>(
    a: Complex<T>,
    b: Complex<T>,
) -> Complex<T> {
    let re = fmla(a.re, b.re, -a.im * b.im);
    let im = fmla(a.re, b.im, a.im * b.re);
    Complex::new(re, im)
}

// Multiplies a.conj() by b
#[inline(always)]
#[allow(unused)]
pub(crate) fn c_conj_mul_fast<
    T: Copy + Clone + Num + Neg<Output = T> + Mul<T, Output = T> + MulAdd<T, Output = T>,
>(
    a: Complex<T>,
    b: Complex<T>,
) -> Complex<T> {
    let re = fmla(a.re, b.re, a.im * b.im);
    let im = fmla(a.re, b.im, -a.im * b.re);
    Complex::new(re, im)
}

// Multiplies a by b.conj()
#[inline(always)]
pub(crate) fn c_mul_fast_conj<
    T: Copy + Clone + Num + Neg<Output = T> + Mul<T, Output = T> + MulAdd<T, Output = T>,
>(
    a: Complex<T>,
    b: Complex<T>,
) -> Complex<T> {
    let re = fmla(a.re, b.re, a.im * b.im);
    let im = fmla(a.re, -b.im, a.im * b.re);
    Complex::new(re, im)
}

#[inline(always)]
pub(crate) fn c_mul_add_fast<
    T: Copy + Clone + Num + Neg<Output = T> + Mul<T, Output = T> + MulAdd<T, Output = T>,
>(
    a: Complex<T>,
    b: Complex<T>,
    c: Complex<T>,
) -> Complex<T> {
    let re = fmla(a.re, b.re, fmla(-a.im, b.im, c.re));
    let im = fmla(a.im, b.re, fmla(a.re, b.im, c.im));
    Complex { re, im }
}
