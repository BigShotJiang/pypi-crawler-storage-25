/*
 * // Copyright (c) Radzivon Bartoshyk 9/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::avx::mixed::{AvxStoreD, AvxStoreF};
use crate::traits::FftTrigonometry;
use crate::util::{compute_twiddle, int_logarithm, reverse_bits};
use crate::{FftDirection, ZaftError};
use num_complex::Complex;
use num_traits::{AsPrimitive, Float, Zero};
use std::any::TypeId;
use std::arch::x86_64::*;

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_set_complexd(v: Complex<f64>) -> __m256d {
    _mm256_setr_pd(v.re, v.im, v.re, v.im)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm_set_complex(v: Complex<f32>) -> __m128 {
    _mm_setr_ps(v.re, v.im, v.re, v.im)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_set4_complex(
    v0: Complex<f32>,
    v1: Complex<f32>,
    v2: Complex<f32>,
    v3: Complex<f32>,
) -> __m256 {
    _mm256_setr_ps(v0.re, v0.im, v1.re, v1.im, v2.re, v2.im, v3.re, v3.im)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_set_complex(v0: Complex<f32>) -> __m256 {
    _mm256_setr_ps(v0.re, v0.im, v0.re, v0.im, v0.re, v0.im, v0.re, v0.im)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_set2_complexd(v0: Complex<f64>, v1: Complex<f64>) -> __m256d {
    _mm256_setr_pd(v0.re, v0.im, v1.re, v1.im)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_set2_complex(v0: Complex<f32>, v1: Complex<f32>) -> __m256 {
    _mm256_setr_ps(v0.re, v0.im, v0.re, v0.im, v1.re, v1.im, v1.re, v1.im)
}

#[inline(always)]
pub(crate) fn _mm_fcmul_pd(a: __m128d, b: __m128d) -> __m128d {
    unsafe {
        let temp1 = _mm_shuffle_pd::<0b00>(b, b);
        let mut temp2 = _mm_shuffle_pd::<0b11>(b, b);
        temp2 = _mm_mul_pd(temp2, a);
        temp2 = _mm_shuffle_pd::<0x01>(temp2, temp2);
        _mm_fmaddsub_pd(temp1, a, temp2)
    }
}

#[inline(always)]
pub(crate) fn _mm256_fcmul_pd(a: __m256d, b: __m256d) -> __m256d {
    unsafe {
        // Swap real and imaginary parts of 'a' for FMA
        let a_yx = _mm256_shuffle_pd::<0b0101>(a, a); // [a_im, a_re, b_im, b_re]

        // Duplicate real and imaginary parts of 'b'
        let b_xx = _mm256_shuffle_pd::<0b0000>(b, b); // [c_re, c_re, d_re, d_re]
        let b_yy = _mm256_shuffle_pd::<0b1111>(b, b); // [c_im, c_im, d_im, d_im]

        // Compute (a_re*b_re - a_im*b_im) + i(a_re*b_im + a_im*b_re)
        _mm256_fmaddsub_pd(a, b_xx, _mm256_mul_pd(a_yx, b_yy))
    }
}

#[inline(always)]
pub(crate) fn _mm_fcmul_ps(a: __m128, b: __m128) -> __m128 {
    unsafe {
        let temp1 = _mm_shuffle_ps::<0xA0>(b, b);
        let temp2 = _mm_shuffle_ps::<0xF5>(b, b);
        let mul2 = _mm_mul_ps(a, temp2);
        let mul2 = _mm_shuffle_ps::<0xB1>(mul2, mul2);
        _mm_fmaddsub_ps(a, temp1, mul2)
    }
}

#[inline]
#[target_feature(enable = "sse4.2")]
pub(crate) unsafe fn _m128s_load_f32x2(a: *const Complex<f32>) -> __m128 {
    unsafe { _mm_castsi128_ps(_mm_loadu_si64(a.cast())) }
}

#[inline]
#[target_feature(enable = "sse4.2")]
pub(crate) fn _m128s_store_f32x2(a: *mut Complex<f32>, b: __m128) {
    unsafe { _mm_storeu_si64(a.cast(), _mm_castps_si128(b)) }
}

#[inline]
#[target_feature(enable = "sse4.2")]
pub(crate) fn _m128s_storeh_f32x2(a: *mut Complex<f32>, b: __m128) {
    unsafe { _mm_storeh_pd(a.cast(), _mm_castps_pd(b)) }
}

#[inline(always)]
pub(crate) fn _mm256_fcmul_ps(a: __m256, b: __m256) -> __m256 {
    unsafe {
        // Extract real and imag parts from a
        let ar = _mm256_moveldup_ps(a); // duplicate even lanes (re parts)
        let ai = _mm256_movehdup_ps(a); // duplicate odd lanes (im parts)

        // Swap real/imag of b for cross terms
        let bswap = _mm256_shuffle_ps::<0b10110001>(b, b); // [im, re, im, re, ...]

        // re = ar*br - ai*bi
        // im = ar*bi + ai*br
        _mm256_fmaddsub_ps(ar, b, _mm256_mul_ps(ai, bswap))
    }
}

#[inline(always)]
pub(crate) const fn shuffle(z: u32, y: u32, x: u32, w: u32) -> i32 {
    // Checked: we want to reinterpret the bits
    ((z << 6) | (y << 4) | (x << 2) | w) as i32
}

#[inline]
#[target_feature(enable = "sse2")]
pub(crate) fn _mm_unpacklo_ps64(a: __m128, b: __m128) -> __m128 {
    _mm_shuffle_ps::<{ shuffle(1, 0, 1, 0) }>(a, b)
}

#[inline]
#[target_feature(enable = "sse2")]
pub(crate) fn _mm_unpacklohi_ps64(a: __m128, b: __m128) -> __m128 {
    _mm_shuffle_ps::<{ shuffle(3, 2, 1, 0) }>(a, b)
}

#[inline]
#[target_feature(enable = "sse2")]
pub(crate) fn _mm_unpackhilo_ps64(a: __m128, b: __m128) -> __m128 {
    _mm_shuffle_ps::<{ shuffle(1, 0, 3, 2) }>(a, b)
}

#[inline]
#[target_feature(enable = "sse2")]
pub(crate) fn _mm_unpackhi_ps64(a: __m128, b: __m128) -> __m128 {
    _mm_shuffle_ps::<{ shuffle(3, 2, 3, 2) }>(a, b)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_unpacklo_pd2(a: __m256d, b: __m256d) -> __m256d {
    _mm256_permute2f128_pd::<0x20>(a, b)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_unpackhi_pd2(a: __m256d, b: __m256d) -> __m256d {
    _mm256_permute2f128_pd::<0x31>(a, b)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256s_interleave4_epi64(
    a: __m256,
    b: __m256,
    c: __m256,
    d: __m256,
) -> (__m256, __m256, __m256, __m256) {
    let bg0 = _mm256_unpacklo_epi64(_mm256_castps_si256(a), _mm256_castps_si256(b));
    let bg1 = _mm256_unpackhi_epi64(_mm256_castps_si256(a), _mm256_castps_si256(b));
    let ra0 = _mm256_unpacklo_epi64(_mm256_castps_si256(c), _mm256_castps_si256(d));
    let ra1 = _mm256_unpackhi_epi64(_mm256_castps_si256(c), _mm256_castps_si256(d));

    let xy0 = _mm256_permute2x128_si256::<32>(bg0, ra0);
    let xy1 = _mm256_permute2x128_si256::<32>(bg1, ra1);
    let xy2 = _mm256_permute2x128_si256::<49>(bg0, ra0);
    let xy3 = _mm256_permute2x128_si256::<49>(bg1, ra1);
    (
        _mm256_castsi256_ps(xy0),
        _mm256_castsi256_ps(xy1),
        _mm256_castsi256_ps(xy2),
        _mm256_castsi256_ps(xy3),
    )
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256s_deinterleave4_epi64(
    a: __m256,
    b: __m256,
    c: __m256,
    d: __m256,
) -> (__m256, __m256, __m256, __m256) {
    let l02 = _mm256_permute2x128_si256::<32>(_mm256_castps_si256(a), _mm256_castps_si256(c));
    let h02 = _mm256_permute2x128_si256::<49>(_mm256_castps_si256(a), _mm256_castps_si256(c));
    let l13 = _mm256_permute2x128_si256::<32>(_mm256_castps_si256(b), _mm256_castps_si256(d));
    let h13 = _mm256_permute2x128_si256::<49>(_mm256_castps_si256(b), _mm256_castps_si256(d));

    let xy0 = _mm256_unpacklo_epi64(l02, l13);
    let xy1 = _mm256_unpackhi_epi64(l02, l13);
    let xy2 = _mm256_unpacklo_epi64(h02, h13);
    let xy3 = _mm256_unpackhi_epi64(h02, h13);
    (
        _mm256_castsi256_ps(xy0),
        _mm256_castsi256_ps(xy1),
        _mm256_castsi256_ps(xy2),
        _mm256_castsi256_ps(xy3),
    )
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_permute4x64_ps<const IMM: i32>(a: __m256) -> __m256 {
    _mm256_castpd_ps(_mm256_permute4x64_pd::<IMM>(_mm256_castps_pd(a)))
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256s_deinterleave3_epi64(
    a: __m256,
    b: __m256,
    c: __m256,
) -> (__m256, __m256, __m256) {
    let s01 = _mm256_blend_epi32::<0xf0>(_mm256_castps_si256(a), _mm256_castps_si256(b));
    let s12 = _mm256_blend_epi32::<0xf0>(_mm256_castps_si256(b), _mm256_castps_si256(c));
    let s20r = _mm256_permute4x64_epi64::<0x1b>(_mm256_blend_epi32::<0xf0>(
        _mm256_castps_si256(c),
        _mm256_castps_si256(a),
    ));
    let xy0 = _mm256_unpacklo_epi64(s01, s20r);
    let xy1 = _mm256_alignr_epi8::<8>(s12, s01);
    let xy2 = _mm256_unpackhi_epi64(s20r, s12);

    (
        _mm256_castsi256_ps(xy0),
        _mm256_castsi256_ps(xy1),
        _mm256_castsi256_ps(xy2),
    )
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256s_interleave3_epi64(
    a: __m256,
    b: __m256,
    c: __m256,
) -> (__m256, __m256, __m256) {
    {
        let s01 = _mm256_unpacklo_epi64(_mm256_castps_si256(a), _mm256_castps_si256(b));
        let s12 = _mm256_unpackhi_epi64(_mm256_castps_si256(b), _mm256_castps_si256(c));
        let s20 = _mm256_blend_epi32::<0xcc>(_mm256_castps_si256(c), _mm256_castps_si256(a));

        let xy0 = _mm256_permute2x128_si256::<32>(s01, s20);
        let xy1 = _mm256_blend_epi32(s01, s12, 0x0f);
        let xy2 = _mm256_permute2x128_si256::<49>(s20, s12);

        (
            _mm256_castsi256_ps(xy0),
            _mm256_castsi256_ps(xy1),
            _mm256_castsi256_ps(xy2),
        )
    }
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_load4_f32x2(
    a: &[Complex<f32>],
    b: &[Complex<f32>],
    c: &[Complex<f32>],
    d: &[Complex<f32>],
) -> __m256 {
    unsafe {
        _mm256_insertf128_ps::<1>(
            _mm256_castps128_ps256(_mm_unpacklo_ps64(
                _m128s_load_f32x2(a.as_ptr().cast()),
                _m128s_load_f32x2(b.as_ptr().cast()),
            )),
            _mm_unpacklo_ps64(
                _m128s_load_f32x2(c.as_ptr().cast()),
                _m128s_load_f32x2(d.as_ptr().cast()),
            ),
        )
    }
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_create_ps(a: __m128, b: __m128) -> __m256 {
    _mm256_insertf128_ps::<1>(_mm256_castps128_ps256(a), b)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_create_pd(a: __m128d, b: __m128d) -> __m256d {
    _mm256_insertf128_pd::<1>(_mm256_castpd128_pd256(a), b)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_unpacklo_ps64(a: __m256, b: __m256) -> __m256 {
    _mm256_shuffle_ps::<{ shuffle(1, 0, 1, 0) }>(a, b)
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_blend_ps64<const IMM8: i32>(a: __m256, b: __m256) -> __m256 {
    _mm256_castpd_ps(_mm256_blend_pd::<IMM8>(
        _mm256_castps_pd(a),
        _mm256_castps_pd(b),
    ))
}

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn _mm256_unpackhi_ps64(a: __m256, b: __m256) -> __m256 {
    _mm256_shuffle_ps::<{ shuffle(3, 2, 3, 2) }>(a, b)
}

// a.conj() * b
#[inline]
#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn _mm256_fcmul_ps_conj_a(a: __m256, b: __m256) -> __m256 {
    // Extract real and imag parts from a
    let ar = _mm256_moveldup_ps(a); // duplicate even lanes (re parts)
    let ai = _mm256_movehdup_ps(a); // duplicate odd lanes (im parts)

    // Swap real/imag of b for cross terms
    let bswap = _mm256_shuffle_ps::<0b10110001>(b, b); // [im, re, im, re, ...]

    // re = ar*br - -ai*bi
    // im = ar*bi - ai*br
    _mm256_fmsubadd_ps(ar, b, _mm256_mul_ps(ai, bswap))
}

// a * b.conj()
#[inline]
#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn _mm256_fcmul_ps_conj_b(a: __m256, b: __m256) -> __m256 {
    // Extract real and imag parts from a
    let ar = _mm256_moveldup_ps(b); // duplicate even lanes (re parts)
    let ai = _mm256_movehdup_ps(b); // duplicate odd lanes (im parts)

    // Swap real/imag of b for cross terms
    let bswap = _mm256_shuffle_ps::<0b10110001>(a, a); // [im, re, im, re, ...]

    // re = ar*br - -ai*bi
    // im = ar*bi - ai*br
    _mm256_fmsubadd_ps(ar, a, _mm256_mul_ps(ai, bswap))
}

// a.conj() * b
#[inline]
#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn _mm_fcmul_ps_conj_a(a: __m128, b: __m128) -> __m128 {
    let temp1 = _mm_shuffle_ps::<0xA0>(a, a);
    let temp2 = _mm_shuffle_ps::<0xF5>(a, a);
    let mul2 = _mm_mul_ps(b, temp2);
    let mul2 = _mm_shuffle_ps::<0xB1>(mul2, mul2);
    _mm_fmsubadd_ps(b, temp1, mul2)
}

// a * b.conj()
#[inline]
#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn _mm_fcmul_ps_conj_b(a: __m128, b: __m128) -> __m128 {
    let temp1 = _mm_shuffle_ps::<0xA0>(b, b);
    let temp2 = _mm_shuffle_ps::<0xF5>(b, b);
    let mul2 = _mm_mul_ps(a, temp2);
    let mul2 = _mm_shuffle_ps::<0xB1>(mul2, mul2);
    _mm_fmsubadd_ps(a, temp1, mul2)
}

// a.conj() * b
#[inline]
#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn _mm256_fcmul_pd_conj_a(a: __m256d, b: __m256d) -> __m256d {
    // Swap real and imaginary parts of 'a' for FMA
    let a_yx = _mm256_shuffle_pd::<0b0101>(a, a); // [a_im, a_re, b_im, b_re]

    // Duplicate real and imaginary parts of 'b'
    let b_xx = _mm256_shuffle_pd::<0b0000>(b, b); // [c_re, c_re, d_re, d_re]
    let b_yy = _mm256_shuffle_pd::<0b1111>(b, b); // [c_im, c_im, d_im, d_im]

    _mm256_fmsubadd_pd(a_yx, b_yy, _mm256_mul_pd(a, b_xx))
}

// a * b.conj()
#[inline]
#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn _mm256_fcmul_pd_conj_b(a: __m256d, b: __m256d) -> __m256d {
    // Swap real and imaginary parts of 'a' for FMA
    let a_yx = _mm256_shuffle_pd::<0b0101>(b, b); // [a_im, a_re, b_im, b_re]

    // Duplicate real and imaginary parts of 'b'
    let b_xx = _mm256_shuffle_pd::<0b0000>(a, a); // [c_re, c_re, d_re, d_re]
    let b_yy = _mm256_shuffle_pd::<0b1111>(a, a); // [c_im, c_im, d_im, d_im]

    _mm256_fmsubadd_pd(a_yx, b_yy, _mm256_mul_pd(b, b_xx))
}

// a.conj() * b
#[inline]
#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn _mm_fcmul_pd_conj_a(a: __m128d, b: __m128d) -> __m128d {
    let temp1 = _mm_shuffle_pd::<0b00>(a, a); // [b.re, b.re]
    let mut temp2 = _mm_shuffle_pd::<0b11>(a, a); // [b.im, b.im]
    temp2 = _mm_mul_pd(temp2, b); // [b.im * a.re, b.im * a.im]
    temp2 = _mm_shuffle_pd::<0x01>(temp2, temp2); // [b.im * a.im, b.im * a.im]
    _mm_fmsubadd_pd(temp1, b, temp2)
}

// a * b.conj()
#[inline]
#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn _mm_fcmul_pd_conj_b(a: __m128d, b: __m128d) -> __m128d {
    let temp1 = _mm_shuffle_pd::<0b00>(b, b); // [b.re, b.re]
    let mut temp2 = _mm_shuffle_pd::<0b11>(b, b); // [b.im, b.im]
    temp2 = _mm_mul_pd(temp2, a); // [b.im * a.re, b.im * a.im]
    temp2 = _mm_shuffle_pd::<0x01>(temp2, temp2); // [b.im * a.im, b.im * a.im]
    _mm_fmsubadd_pd(temp1, a, temp2)
}

pub(crate) fn create_avx4_twiddles<T: FftTrigonometry + 'static + Float + Sized, const N: usize>(
    base: usize,
    size: usize,
    fft_direction: FftDirection,
) -> Result<Vec<Complex<T>>, ZaftError>
where
    f64: AsPrimitive<T>,
{
    let mut twiddles = Vec::new();
    twiddles
        .try_reserve_exact(size - 1)
        .map_err(|_| ZaftError::OutOfMemory(size - 1))?;

    let mut cross_fft_len = base;
    while cross_fft_len < size {
        let num_columns = cross_fft_len;
        cross_fft_len *= N;

        let mut i = 0usize;

        if TypeId::of::<T>() == TypeId::of::<f32>() {
            while i + 4 <= num_columns {
                for k in 1..N {
                    let twiddle0 = compute_twiddle(i * k, cross_fft_len, fft_direction);
                    let twiddle1 = compute_twiddle((i + 1) * k, cross_fft_len, fft_direction);
                    let twiddle2 = compute_twiddle((i + 2) * k, cross_fft_len, fft_direction);
                    let twiddle3 = compute_twiddle((i + 3) * k, cross_fft_len, fft_direction);
                    twiddles.push(twiddle0);
                    twiddles.push(twiddle1);
                    twiddles.push(twiddle2);
                    twiddles.push(twiddle3);
                }
                i += 4;
            }
        }

        while i + 2 <= num_columns {
            for k in 1..N {
                let twiddle0 = compute_twiddle(i * k, cross_fft_len, fft_direction);
                let twiddle1 = compute_twiddle((i + 1) * k, cross_fft_len, fft_direction);
                twiddles.push(twiddle0);
                twiddles.push(twiddle1);
            }
            i += 2;
        }

        for i in i..num_columns {
            for k in 1..N {
                let twiddle = compute_twiddle(i * k, cross_fft_len, fft_direction);
                twiddles.push(twiddle);
            }
        }
    }
    Ok(twiddles)
}

#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn create_avx_twiddles_f<const N: usize>(
    base: usize,
    size: usize,
    fft_direction: FftDirection,
) -> Vec<AvxStoreF> {
    let mut twiddles = Vec::new();

    let mut cross_fft_len = base;
    while cross_fft_len < size {
        let num_columns = cross_fft_len;
        cross_fft_len *= N;

        let mut i = 0usize;

        let mut tw: [Complex<f32>; 4] = [Complex::zero(); 4];

        while i + 4 <= num_columns {
            for k in 1..N {
                let twiddle0 = compute_twiddle(i * k, cross_fft_len, fft_direction);
                let twiddle1 = compute_twiddle((i + 1) * k, cross_fft_len, fft_direction);
                let twiddle2 = compute_twiddle((i + 2) * k, cross_fft_len, fft_direction);
                let twiddle3 = compute_twiddle((i + 3) * k, cross_fft_len, fft_direction);
                tw[0] = twiddle0;
                tw[1] = twiddle1;
                tw[2] = twiddle2;
                tw[3] = twiddle3;
                twiddles.push(AvxStoreF::from_complex_ref(tw.as_slice()));
            }
            i += 4;
        }

        tw = [Complex::zero(); 4];

        while i + 2 <= num_columns {
            for k in 1..N {
                let twiddle0 = compute_twiddle(i * k, cross_fft_len, fft_direction);
                let twiddle1 = compute_twiddle((i + 1) * k, cross_fft_len, fft_direction);
                tw[0] = twiddle0;
                tw[1] = twiddle1;
                twiddles.push(AvxStoreF::from_complex_ref(tw.as_slice()));
            }
            i += 2;
        }

        tw = [Complex::zero(); 4];

        for i in i..num_columns {
            for k in 1..N {
                let twiddle = compute_twiddle(i * k, cross_fft_len, fft_direction);
                tw[0] = twiddle;
                twiddles.push(AvxStoreF::from_complex_ref(tw.as_slice()));
            }
        }
    }
    twiddles
}

#[target_feature(enable = "avx2", enable = "fma")]
pub(crate) fn create_avx_twiddles_d<const N: usize>(
    base: usize,
    size: usize,
    fft_direction: FftDirection,
) -> Vec<AvxStoreD> {
    let mut twiddles = Vec::new();

    let mut cross_fft_len = base;
    while cross_fft_len < size {
        let num_columns = cross_fft_len;
        cross_fft_len *= N;

        let mut i = 0usize;

        let mut tw: [Complex<f64>; 4] = [Complex::zero(); 4];

        while i + 2 <= num_columns {
            for k in 1..N {
                let twiddle0 = compute_twiddle(i * k, cross_fft_len, fft_direction);
                let twiddle1 = compute_twiddle((i + 1) * k, cross_fft_len, fft_direction);
                tw[0] = twiddle0;
                tw[1] = twiddle1;
                twiddles.push(AvxStoreD::from_complex_ref(tw.as_slice()));
            }
            i += 2;
        }

        tw = [Complex::zero(); 4];

        for i in i..num_columns {
            for k in 1..N {
                let twiddle = compute_twiddle(i * k, cross_fft_len, fft_direction);
                tw[0] = twiddle;
                twiddles.push(AvxStoreD::from_complex_ref(tw.as_slice()));
            }
        }
    }
    twiddles
}

#[target_feature(enable = "avx2")]
pub(crate) fn avx_bitreversed_transpose<T: Copy, const D: usize>(
    height: usize,
    input: &[T],
    output: &mut [T],
) {
    let width = input.len() / height;

    if width <= 1 {
        output.copy_from_slice(input);
        return;
    }

    // Let's make sure the arguments are ok
    assert!(D > 1 && input.len().is_multiple_of(height) && input.len() == output.len());

    let strided_width = width / D;
    let rev_digits = if D.is_power_of_two() {
        let width_bits = width.trailing_zeros();
        let d_bits = D.trailing_zeros();

        // verify that width is a power of d
        assert!(width_bits.is_multiple_of(d_bits));
        width_bits / d_bits
    } else {
        int_logarithm::<D>(width).unwrap()
    };

    if strided_width == 0 {
        output.copy_from_slice(input);
        return;
    }

    for x in 0..strided_width {
        let x_fwd: [usize; D] = std::array::from_fn(|i| D * x + i);
        let x_rev = x_fwd.map(|x| reverse_bits::<D>(x, rev_digits));

        let mut y = 0usize;

        while y + 6 < height {
            let y1 = y + 1;
            let y2 = y + 2;
            let y3 = y + 3;
            let y4 = y + 4;
            let y5 = y + 5;
            for (fwd, rev) in x_fwd.iter().zip(x_rev.iter()) {
                let input_index0 = *fwd + y * width;
                let output_index0 = y + *rev * height;

                let input_index1 = *fwd + y1 * width;
                let output_index1 = y1 + *rev * height;

                let input_index2 = *fwd + y2 * width;
                let output_index2 = y2 + *rev * height;

                let input_index3 = *fwd + y3 * width;
                let output_index3 = y3 + *rev * height;

                let input_index4 = *fwd + y4 * width;
                let output_index4 = y4 + *rev * height;

                let input_index5 = *fwd + y5 * width;
                let output_index5 = y5 + *rev * height;

                unsafe {
                    *output.get_unchecked_mut(output_index0) = *input.get_unchecked(input_index0);
                    *output.get_unchecked_mut(output_index1) = *input.get_unchecked(input_index1);
                    *output.get_unchecked_mut(output_index2) = *input.get_unchecked(input_index2);
                    *output.get_unchecked_mut(output_index3) = *input.get_unchecked(input_index3);
                    *output.get_unchecked_mut(output_index4) = *input.get_unchecked(input_index4);
                    *output.get_unchecked_mut(output_index5) = *input.get_unchecked(input_index5);
                }
            }

            y += 6;
        }

        while y + 4 < height {
            let y1 = y + 1;
            let y2 = y + 2;
            let y3 = y + 3;
            for (fwd, rev) in x_fwd.iter().zip(x_rev.iter()) {
                let input_index0 = *fwd + y * width;
                let output_index0 = y + *rev * height;

                let input_index1 = *fwd + y1 * width;
                let output_index1 = y1 + *rev * height;

                let input_index2 = *fwd + y2 * width;
                let output_index2 = y2 + *rev * height;

                let input_index3 = *fwd + y3 * width;
                let output_index3 = y3 + *rev * height;

                unsafe {
                    *output.get_unchecked_mut(output_index0) = *input.get_unchecked(input_index0);
                    *output.get_unchecked_mut(output_index1) = *input.get_unchecked(input_index1);
                    *output.get_unchecked_mut(output_index2) = *input.get_unchecked(input_index2);
                    *output.get_unchecked_mut(output_index3) = *input.get_unchecked(input_index3);
                }
            }

            y += 4;
        }

        for y in y..height {
            for (fwd, rev) in x_fwd.iter().zip(x_rev.iter()) {
                let input_index = *fwd + y * width;
                let output_index = y + *rev * height;

                unsafe {
                    let temp = *input.get_unchecked(input_index);
                    *output.get_unchecked_mut(output_index) = temp;
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::util::has_valid_avx;
    use num_complex::ComplexFloat;

    #[test]
    fn complex_muld() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f64, 5.0), Complex::new(5.0, -1.15)];
        let values_b = [Complex::new(-5.0f64, 3.0), Complex::new(-1.0, 1.15)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a * b)
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm256_loadu_pd(values_a.as_ptr().cast());
            let b0 = _mm256_loadu_pd(values_b.as_ptr().cast());
            let product = _mm256_fcmul_pd(a0, b0);
            let mut vec_b = vec![Complex::<f64>::default(); 2];
            _mm256_storeu_pd(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-10);
            });
        }
    }

    #[test]
    fn complexd_a_conj_to_b_avx() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f64, 5.0), Complex::new(5.0, -1.15)];
        let values_b = [Complex::new(-5.0f64, 3.0), Complex::new(-1.0, 1.15)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a.conj() * b)
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm256_loadu_pd(values_a.as_ptr().cast());
            let b0 = _mm256_loadu_pd(values_b.as_ptr().cast());
            let product = _mm256_fcmul_pd_conj_a(a0, b0);
            let mut vec_b = vec![Complex::<f64>::default(); 4];
            _mm256_storeu_pd(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-10);
            });
        }
    }

    #[test]
    fn complexd_a_conj_to_b_sse() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f64, 5.0)];
        let values_b = [Complex::new(-5.0f64, 3.0)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a.conj() * b)
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm_loadu_pd(values_a.as_ptr().cast());
            let b0 = _mm_loadu_pd(values_b.as_ptr().cast());
            let product = _mm_fcmul_pd_conj_a(a0, b0);
            let mut vec_b = vec![Complex::<f64>::default(); 2];
            _mm_storeu_pd(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-10, "a {a}, b {b}");
            });
        }
    }

    #[test]
    fn complex_a_conj_to_b_avx() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f32, 5.0), Complex::new(5.0, -1.15)];
        let values_b = [Complex::new(-5.0f32, 3.0), Complex::new(-1.0, 1.15)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a.conj() * b)
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm256_loadu_ps(values_a.as_ptr().cast());
            let b0 = _mm256_loadu_ps(values_b.as_ptr().cast());
            let product = _mm256_fcmul_ps_conj_a(a0, b0);
            let mut vec_b = vec![Complex::<f32>::default(); 4];
            _mm256_storeu_ps(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-5, "complex_a_to_b_conj_avx a {a}, b {b}");
            });
        }
    }

    #[test]
    fn complex_a_conj_to_b_sse() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f32, 5.0)];
        let values_b = [Complex::new(-5.0f32, 3.0)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a.conj() * b)
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm_loadu_ps(values_a.as_ptr().cast());
            let b0 = _mm_loadu_ps(values_b.as_ptr().cast());
            let product = _mm_fcmul_ps_conj_a(a0, b0);
            let mut vec_b = vec![Complex::<f32>::default(); 2];
            _mm_storeu_ps(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-5, "complex_a_to_b_conj_sse a {a}, b {b}");
            });
        }
    }

    #[test]
    fn complex_a_to_b_conj_sse() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f32, 5.0)];
        let values_b = [Complex::new(-5.0f32, 3.0)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a * b.conj())
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm_loadu_ps(values_a.as_ptr().cast());
            let b0 = _mm_loadu_ps(values_b.as_ptr().cast());
            let product = _mm_fcmul_ps_conj_b(a0, b0);
            let mut vec_b = vec![Complex::<f32>::default(); 2];
            _mm_storeu_ps(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-5, "complex_a_to_b_conj_sse a {a}, b {b}");
            });
        }
    }

    #[test]
    fn complex_a_to_b_conj_sse_f64() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f64, 5.0)];
        let values_b = [Complex::new(-5.0f64, 3.0)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a * b.conj())
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm_loadu_pd(values_a.as_ptr().cast());
            let b0 = _mm_loadu_pd(values_b.as_ptr().cast());
            let product = _mm_fcmul_pd_conj_b(a0, b0);
            let mut vec_b = vec![Complex::<f64>::default(); 1];
            _mm_storeu_pd(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-5, "complex_a_to_b_conj_sse a {a}, b {b}");
            });
        }
    }

    #[test]
    fn complexd_a_to_b_conj_avx() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f64, 5.0), Complex::new(5.0, -1.15)];
        let values_b = [Complex::new(-5.0f64, 3.0), Complex::new(-1.0, 1.15)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a * b.conj())
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm256_loadu_pd(values_a.as_ptr().cast());
            let b0 = _mm256_loadu_pd(values_b.as_ptr().cast());
            let product = _mm256_fcmul_pd_conj_b(a0, b0);
            let mut vec_b = vec![Complex::<f64>::default(); 4];
            _mm256_storeu_pd(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-10);
            });
        }
    }

    #[test]
    fn complexf_a_to_b_conj_avx() {
        if !has_valid_avx() {
            return;
        }
        let values_a = [Complex::new(7.0f32, 5.0), Complex::new(5.0, -1.15)];
        let values_b = [Complex::new(-5.0f32, 3.0), Complex::new(-1.0, 1.15)];
        let r = values_a
            .iter()
            .zip(values_b.iter())
            .map(|(a, b)| a * b.conj())
            .collect::<Vec<Complex<_>>>();
        unsafe {
            let a0 = _mm256_loadu_ps(values_a.as_ptr().cast());
            let b0 = _mm256_loadu_ps(values_b.as_ptr().cast());
            let product = _mm256_fcmul_ps_conj_b(a0, b0);
            let mut vec_b = vec![Complex::<f32>::default(); 4];
            _mm256_storeu_ps(vec_b.as_mut_ptr().cast(), product);
            vec_b.iter().zip(r.iter()).for_each(|(a, b)| {
                assert!((a - b).abs() < 1e-5);
            });
        }
    }
}
