/*
 * // Copyright (c) Radzivon Bartoshyk 11/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#![allow(clippy::needless_range_loop)]

use crate::avx::butterflies::shared::{boring_avx_butterfly, gen_butterfly_twiddles_f32};
use crate::avx::mixed::{AvxStoreF, ColumnButterfly11f};
use crate::avx::transpose::transpose_f32x2_4x4_aos;
use crate::store::BidirectionalStore;
use crate::{FftDirection, FftExecutor, ZaftError};
use num_complex::Complex;
use std::mem::MaybeUninit;

pub(crate) struct AvxButterfly121f {
    direction: FftDirection,
    bf11: ColumnButterfly11f,
    twiddles: [AvxStoreF; 30],
}

impl AvxButterfly121f {
    pub(crate) fn new(fft_direction: FftDirection) -> Self {
        unsafe { Self::new_init(fft_direction) }
    }

    #[target_feature(enable = "avx2")]
    pub(crate) fn new_init(fft_direction: FftDirection) -> Self {
        Self {
            direction: fft_direction,
            twiddles: gen_butterfly_twiddles_f32(11, 11, fft_direction, 121),
            bf11: ColumnButterfly11f::new(fft_direction),
        }
    }
}

boring_avx_butterfly!(AvxButterfly121f, f32, 121);

impl AvxButterfly121f {
    #[inline]
    #[target_feature(enable = "avx2", enable = "fma")]
    pub(crate) fn run<S: BidirectionalStore<Complex<f32>>>(&self, chunk: &mut S) {
        let mut rows: [AvxStoreF; 11] = [AvxStoreF::zero(); 11];
        let mut scratch = [MaybeUninit::<Complex<f32>>::uninit(); 121];
        unsafe {
            // columns
            for k in 0..2 {
                for i in 0..11 {
                    rows[i] = AvxStoreF::from_complex_ref(chunk.slice_from(i * 11 + k * 4..));
                }

                rows = self.bf11.exec(rows);

                let q1 = AvxStoreF::mul_by_complex(rows[1], self.twiddles[10 * k]);
                let q2 = AvxStoreF::mul_by_complex(rows[2], self.twiddles[10 * k + 1]);
                let q3 = AvxStoreF::mul_by_complex(rows[3], self.twiddles[10 * k + 2]);
                let t = transpose_f32x2_4x4_aos([rows[0], q1, q2, q3]);
                t[0].write_u(scratch.get_unchecked_mut(k * 4 * 11..));
                t[1].write_u(scratch.get_unchecked_mut((k * 4 + 1) * 11..));
                t[2].write_u(scratch.get_unchecked_mut((k * 4 + 2) * 11..));
                t[3].write_u(scratch.get_unchecked_mut((k * 4 + 3) * 11..));

                for i in 1..2 {
                    let q0 = AvxStoreF::mul_by_complex(
                        rows[i * 4],
                        self.twiddles[(i - 1) * 4 + 3 + 10 * k],
                    );
                    let q1 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 1],
                        self.twiddles[(i - 1) * 4 + 4 + 10 * k],
                    );
                    let q2 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 2],
                        self.twiddles[(i - 1) * 4 + 5 + 10 * k],
                    );
                    let q3 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 3],
                        self.twiddles[(i - 1) * 4 + 6 + 10 * k],
                    );
                    let t = transpose_f32x2_4x4_aos([q0, q1, q2, q3]);
                    t[0].write_u(scratch.get_unchecked_mut(k * 4 * 11 + i * 4..));
                    t[1].write_u(scratch.get_unchecked_mut((k * 4 + 1) * 11 + i * 4..));
                    t[2].write_u(scratch.get_unchecked_mut((k * 4 + 2) * 11 + i * 4..));
                    t[3].write_u(scratch.get_unchecked_mut((k * 4 + 3) * 11 + i * 4..));
                }

                {
                    let i = 2;
                    let q0 = AvxStoreF::mul_by_complex(
                        rows[i * 4],
                        self.twiddles[(i - 1) * 4 + 3 + 10 * k],
                    );
                    let q1 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 1],
                        self.twiddles[(i - 1) * 4 + 4 + 10 * k],
                    );
                    let q2 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 2],
                        self.twiddles[(i - 1) * 4 + 5 + 10 * k],
                    );
                    let t = transpose_f32x2_4x4_aos([q0, q1, q2, AvxStoreF::undefined()]);
                    t[0].write_lo3u(scratch.get_unchecked_mut(k * 4 * 11 + i * 4..));
                    t[1].write_lo3u(scratch.get_unchecked_mut((k * 4 + 1) * 11 + i * 4..));
                    t[2].write_lo3u(scratch.get_unchecked_mut((k * 4 + 2) * 11 + i * 4..));
                    t[3].write_lo3u(scratch.get_unchecked_mut((k * 4 + 3) * 11 + i * 4..));
                }
            }

            {
                let k = 2;
                for i in 0..11 {
                    rows[i] = AvxStoreF::from_complex3(chunk.slice_from(i * 11 + 8..));
                }

                rows = self.bf11.exec(rows);

                let q1 = AvxStoreF::mul_by_complex(rows[1], self.twiddles[10 * k]);
                let q2 = AvxStoreF::mul_by_complex(rows[2], self.twiddles[10 * k + 1]);
                let q3 = AvxStoreF::mul_by_complex(rows[3], self.twiddles[10 * k + 2]);
                let t = transpose_f32x2_4x4_aos([rows[0], q1, q2, q3]);
                t[0].write_u(scratch.get_unchecked_mut(k * 4 * 11..));
                t[1].write_u(scratch.get_unchecked_mut((k * 4 + 1) * 11..));
                t[2].write_u(scratch.get_unchecked_mut((k * 4 + 2) * 11..));

                for i in 1..2 {
                    let q0 = AvxStoreF::mul_by_complex(
                        rows[i * 4],
                        self.twiddles[(i - 1) * 4 + 3 + 10 * k],
                    );
                    let q1 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 1],
                        self.twiddles[(i - 1) * 4 + 4 + 10 * k],
                    );
                    let q2 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 2],
                        self.twiddles[(i - 1) * 4 + 5 + 10 * k],
                    );
                    let q3 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 3],
                        self.twiddles[(i - 1) * 4 + 6 + 10 * k],
                    );
                    let t = transpose_f32x2_4x4_aos([q0, q1, q2, q3]);
                    t[0].write_u(scratch.get_unchecked_mut(k * 4 * 11 + i * 4..));
                    t[1].write_u(scratch.get_unchecked_mut((k * 4 + 1) * 11 + i * 4..));
                    t[2].write_u(scratch.get_unchecked_mut((k * 4 + 2) * 11 + i * 4..));
                }

                {
                    let i = 2;
                    let q0 = AvxStoreF::mul_by_complex(
                        rows[i * 4],
                        self.twiddles[(i - 1) * 4 + 3 + 10 * k],
                    );
                    let q1 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 1],
                        self.twiddles[(i - 1) * 4 + 4 + 10 * k],
                    );
                    let q2 = AvxStoreF::mul_by_complex(
                        rows[i * 4 + 2],
                        self.twiddles[(i - 1) * 4 + 5 + 10 * k],
                    );
                    let t = transpose_f32x2_4x4_aos([q0, q1, q2, AvxStoreF::undefined()]);
                    t[0].write_lo3u(scratch.get_unchecked_mut(k * 4 * 11 + i * 4..));
                    t[1].write_lo3u(scratch.get_unchecked_mut((k * 4 + 1) * 11 + i * 4..));
                    t[2].write_lo3u(scratch.get_unchecked_mut((k * 4 + 2) * 11 + i * 4..));
                }
            }

            // rows

            for k in 0..2 {
                self.bf11.exec_streaming(
                    |i| AvxStoreF::from_complex_refu(scratch.get_unchecked(i * 11 + k * 4..)),
                    |i, v| v.write(chunk.slice_from_mut(i * 11 + k * 4..)),
                );
            }

            self.bf11.exec_streaming(
                |i| AvxStoreF::from_complex3u(scratch.get_unchecked(i * 11 + 8..)),
                |i, v| v.write_lo3(chunk.slice_from_mut(i * 11 + 8..)),
            );
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::avx::butterflies::{test_avx_butterfly, test_oof_avx_butterfly};

    test_avx_butterfly!(test_avx_butterfly121, f32, AvxButterfly121f, 121, 1e-3);
    test_oof_avx_butterfly!(test_oof_avx_butterfly121, f32, AvxButterfly121f, 121, 1e-3);
}
