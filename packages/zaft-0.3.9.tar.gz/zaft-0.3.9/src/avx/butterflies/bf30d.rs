/*
 * // Copyright (c) Radzivon Bartoshyk 12/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#![allow(clippy::needless_range_loop)]

use crate::avx::butterflies::bf35d::transpose_6x5;
use crate::avx::butterflies::shared::{boring_avx_butterfly, gen_butterfly_twiddles_f64};
use crate::avx::mixed::{AvxStoreD, ColumnButterfly5d, ColumnButterfly6d};
use crate::store::BidirectionalStore;
use crate::{FftDirection, FftExecutor, ZaftError};
use num_complex::Complex;

pub(crate) struct AvxButterfly30d {
    direction: FftDirection,
    bf5: ColumnButterfly5d,
    bf6: ColumnButterfly6d,
    twiddles: [AvxStoreD; 12],
}

impl AvxButterfly30d {
    pub(crate) fn new(fft_direction: FftDirection) -> Self {
        unsafe { Self::new_init(fft_direction) }
    }

    #[target_feature(enable = "avx2")]
    pub(crate) fn new_init(fft_direction: FftDirection) -> Self {
        Self {
            direction: fft_direction,
            twiddles: gen_butterfly_twiddles_f64(6, 5, fft_direction, 30),
            bf6: ColumnButterfly6d::new(fft_direction),
            bf5: ColumnButterfly5d::new(fft_direction),
        }
    }
}

boring_avx_butterfly!(AvxButterfly30d, f64, 30);

impl AvxButterfly30d {
    #[inline]
    #[target_feature(enable = "avx2", enable = "fma")]
    pub(crate) fn run<S: BidirectionalStore<Complex<f64>>>(&self, chunk: &mut S) {
        let mut rows0: [AvxStoreD; 5] = [AvxStoreD::zero(); 5];
        let mut rows1: [AvxStoreD; 5] = [AvxStoreD::zero(); 5];
        let mut rows2: [AvxStoreD; 5] = [AvxStoreD::zero(); 5];
        for i in 0..5 {
            rows0[i] = AvxStoreD::from_complex_ref(chunk.slice_from(i * 6..));
            rows1[i] = AvxStoreD::from_complex_ref(chunk.slice_from(i * 6 + 2..));
            rows2[i] = AvxStoreD::from_complex_ref(chunk.slice_from(i * 6 + 4..));
        }

        rows0 = self.bf5.exec(rows0);
        rows1 = self.bf5.exec(rows1);
        rows2 = self.bf5.exec(rows2);

        for i in 1..5 {
            rows0[i] = AvxStoreD::mul_by_complex(rows0[i], self.twiddles[i - 1]);
            rows1[i] = AvxStoreD::mul_by_complex(rows1[i], self.twiddles[i - 1 + 4]);
            rows2[i] = AvxStoreD::mul_by_complex(rows2[i], self.twiddles[i - 1 + 8]);
        }

        let t = transpose_6x5(rows0, rows1, rows2);

        let mut r0 = [t[0], t[1], t[2], t[3], t[4], t[5]];
        let mut r1 = [t[6], t[7], t[8], t[9], t[10], t[11]];
        let mut r2 = [t[12], t[13], t[14], t[15], t[16], t[17]];

        // rows

        r0 = self.bf6.exec(r0);
        r1 = self.bf6.exec(r1);
        r2 = self.bf6.exec(r2);

        for i in 0..6 {
            r0[i].write(chunk.slice_from_mut(i * 5..));
        }
        for i in 0..6 {
            r1[i].write(chunk.slice_from_mut(i * 5 + 2..));
        }
        for i in 0..6 {
            r2[i].write_lo(chunk.slice_from_mut(i * 5 + 4..));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::avx::butterflies::{test_avx_butterfly, test_oof_avx_butterfly};

    test_avx_butterfly!(test_avx_butterfly30_f64, f64, AvxButterfly30d, 30, 1e-3);
    test_oof_avx_butterfly!(test_avx_oof_butterfly30_f64, f64, AvxButterfly30d, 30, 1e-3);
}
