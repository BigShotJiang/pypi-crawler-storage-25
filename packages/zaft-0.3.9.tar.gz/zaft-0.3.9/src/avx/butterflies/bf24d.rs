/*
 * // Copyright (c) Radzivon Bartoshyk 12/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#![allow(clippy::needless_range_loop)]

use crate::avx::butterflies::shared::{boring_avx_butterfly, gen_butterfly_twiddles_f64};
use crate::avx::mixed::{AvxStoreD, ColumnButterfly3d, ColumnButterfly8d};
use crate::avx::transpose::avx_transpose_f64x2_4x4_impl;
use crate::store::BidirectionalStore;
use crate::{FftDirection, FftExecutor, ZaftError};
use num_complex::Complex;
use std::arch::x86_64::_mm256_undefined_pd;

pub(crate) struct AvxButterfly24d {
    direction: FftDirection,
    bf3: ColumnButterfly3d,
    bf8: ColumnButterfly8d,
    twiddles: [AvxStoreD; 8],
}

impl AvxButterfly24d {
    pub(crate) fn new(fft_direction: FftDirection) -> Self {
        unsafe { Self::new_init(fft_direction) }
    }

    #[target_feature(enable = "avx2")]
    pub(crate) fn new_init(fft_direction: FftDirection) -> Self {
        Self {
            direction: fft_direction,
            twiddles: gen_butterfly_twiddles_f64(8, 3, fft_direction, 24),
            bf3: ColumnButterfly3d::new(fft_direction),
            bf8: ColumnButterfly8d::new(fft_direction),
        }
    }
}

boring_avx_butterfly!(AvxButterfly24d, f64, 24);

#[inline]
#[target_feature(enable = "avx2")]
pub(crate) fn transpose_8x3(
    rows0: [AvxStoreD; 3],
    rows1: [AvxStoreD; 3],
    rows2: [AvxStoreD; 3],
    rows3: [AvxStoreD; 3],
) -> ([AvxStoreD; 8], [AvxStoreD; 8]) {
    let a0 = avx_transpose_f64x2_4x4_impl(
        (rows0[0].v, rows1[0].v),
        (rows0[1].v, rows1[1].v),
        (rows0[2].v, rows1[2].v),
        (_mm256_undefined_pd(), _mm256_undefined_pd()),
    );
    let b0 = avx_transpose_f64x2_4x4_impl(
        (rows2[0].v, rows3[0].v),
        (rows2[1].v, rows3[1].v),
        (rows2[2].v, rows3[2].v),
        (_mm256_undefined_pd(), _mm256_undefined_pd()),
    );
    (
        [
            // row 0
            AvxStoreD::raw(a0.0.0),
            AvxStoreD::raw(a0.1.0),
            AvxStoreD::raw(a0.2.0),
            AvxStoreD::raw(a0.3.0),
            AvxStoreD::raw(b0.0.0),
            AvxStoreD::raw(b0.1.0),
            AvxStoreD::raw(b0.2.0),
            AvxStoreD::raw(b0.3.0),
        ],
        [
            // row 0
            AvxStoreD::raw(a0.0.1),
            AvxStoreD::raw(a0.1.1),
            AvxStoreD::raw(a0.2.1),
            AvxStoreD::raw(a0.3.1),
            AvxStoreD::raw(b0.0.1),
            AvxStoreD::raw(b0.1.1),
            AvxStoreD::raw(b0.2.1),
            AvxStoreD::raw(b0.3.1),
        ],
    )
}

impl AvxButterfly24d {
    #[inline]
    #[target_feature(enable = "avx2", enable = "fma")]
    pub(crate) fn run<S: BidirectionalStore<Complex<f64>>>(&self, chunk: &mut S) {
        let mut rows0: [AvxStoreD; 3] = [AvxStoreD::zero(); 3];
        let mut rows1: [AvxStoreD; 3] = [AvxStoreD::zero(); 3];
        let mut rows2: [AvxStoreD; 3] = [AvxStoreD::zero(); 3];
        let mut rows3: [AvxStoreD; 3] = [AvxStoreD::zero(); 3];
        for i in 0..3 {
            rows0[i] = AvxStoreD::from_complex_ref(chunk.slice_from(i * 8..));
            rows1[i] = AvxStoreD::from_complex_ref(chunk.slice_from(i * 8 + 2..));
            rows2[i] = AvxStoreD::from_complex_ref(chunk.slice_from(i * 8 + 4..));
            rows3[i] = AvxStoreD::from_complex_ref(chunk.slice_from(i * 8 + 6..));
        }

        rows0 = self.bf3.exec(rows0);
        rows1 = self.bf3.exec(rows1);
        rows2 = self.bf3.exec(rows2);
        rows3 = self.bf3.exec(rows3);

        for i in 1..3 {
            rows0[i] = AvxStoreD::mul_by_complex(rows0[i], self.twiddles[i - 1]);
            rows1[i] = AvxStoreD::mul_by_complex(rows1[i], self.twiddles[i - 1 + 2]);
            rows2[i] = AvxStoreD::mul_by_complex(rows2[i], self.twiddles[i - 1 + 4]);
            rows3[i] = AvxStoreD::mul_by_complex(rows3[i], self.twiddles[i - 1 + 6]);
        }

        let transposed = transpose_8x3(rows0, rows1, rows2, rows3);

        let q0 = self.bf8.exec(transposed.0);
        let q1 = self.bf8.exec(transposed.1);

        for i in 0..8 {
            q0[i].write(chunk.slice_from_mut(i * 3..));
            q1[i].write_lo(chunk.slice_from_mut(i * 3 + 2..));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::avx::butterflies::test_avx_butterfly;

    test_avx_butterfly!(test_avx_butterfly24_f64, f64, AvxButterfly24d, 24, 1e-7);
}
