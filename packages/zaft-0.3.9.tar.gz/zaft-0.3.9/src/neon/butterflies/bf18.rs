/*
 * // Copyright (c) Radzivon Bartoshyk 11/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::neon::butterflies::NeonButterfly;
use crate::{FftDirection, FftExecutor, ZaftError};
use num_complex::Complex;
use std::arch::aarch64::*;

macro_rules! butterfly18d {
    ($name: ident, $features: literal, $bf_name: ident) => {
        use crate::neon::mixed::$bf_name;
        pub(crate) struct $name {
            direction: FftDirection,
            bf9: $bf_name,
        }

        impl $name {
            pub(crate) fn new(fft_direction: FftDirection) -> Self {
                Self {
                    direction: fft_direction,
                    bf9: $bf_name::new(fft_direction),
                }
            }
        }

        impl $name {
            #[inline]
            #[target_feature(enable = $features)]
            pub(crate) fn run<S: BidirectionalStore<Complex<f64>>>(&self, chunk: &mut S) {
                unsafe {
                    let u0 = vld1q_f64(chunk.slice_from(0..).as_ptr().cast());
                    let u3 = vld1q_f64(chunk.slice_from(1..).as_ptr().cast());
                    let u4 = vld1q_f64(chunk.slice_from(2..).as_ptr().cast());
                    let u7 = vld1q_f64(chunk.slice_from(3..).as_ptr().cast());

                    let u8 = vld1q_f64(chunk.slice_from(4..).as_ptr().cast());
                    let u11 = vld1q_f64(chunk.slice_from(5..).as_ptr().cast());
                    let u12 = vld1q_f64(chunk.slice_from(6..).as_ptr().cast());
                    let u15 = vld1q_f64(chunk.slice_from(7..).as_ptr().cast());

                    let u16 = vld1q_f64(chunk.slice_from(8..).as_ptr().cast());
                    let u1 = vld1q_f64(chunk.slice_from(9..).as_ptr().cast());
                    let u2 = vld1q_f64(chunk.slice_from(10..).as_ptr().cast());
                    let u5 = vld1q_f64(chunk.slice_from(11..).as_ptr().cast());

                    let u6 = vld1q_f64(chunk.slice_from(12..).as_ptr().cast());
                    let u9 = vld1q_f64(chunk.slice_from(13..).as_ptr().cast());
                    let u10 = vld1q_f64(chunk.slice_from(14..).as_ptr().cast());
                    let u13 = vld1q_f64(chunk.slice_from(15..).as_ptr().cast());

                    let u14 = vld1q_f64(chunk.slice_from(16..).as_ptr().cast());
                    let u17 = vld1q_f64(chunk.slice_from(17..).as_ptr().cast());

                    let (t0, t1) = NeonButterfly::butterfly2_f64(u0, u1);
                    let (t2, t3) = NeonButterfly::butterfly2_f64(u2, u3);
                    let (t4, t5) = NeonButterfly::butterfly2_f64(u4, u5);
                    let (t6, t7) = NeonButterfly::butterfly2_f64(u6, u7);
                    let (t8, t9) = NeonButterfly::butterfly2_f64(u8, u9);
                    let (t10, t11) = NeonButterfly::butterfly2_f64(u10, u11);
                    let (t12, t13) = NeonButterfly::butterfly2_f64(u12, u13);
                    let (t14, t15) = NeonButterfly::butterfly2_f64(u14, u15);
                    let (t16, t17) = NeonButterfly::butterfly2_f64(u16, u17);

                    let [u0, u2, u4, u6, u8, u10, u12, u14, u16] = self.bf9.exec([
                        NeonStoreD::raw(t0),
                        NeonStoreD::raw(t2),
                        NeonStoreD::raw(t4),
                        NeonStoreD::raw(t6),
                        NeonStoreD::raw(t8),
                        NeonStoreD::raw(t10),
                        NeonStoreD::raw(t12),
                        NeonStoreD::raw(t14),
                        NeonStoreD::raw(t16),
                    ]);
                    let [u9, u11, u13, u15, u17, u1, u3, u5, u7] = self.bf9.exec([
                        NeonStoreD::raw(t1),
                        NeonStoreD::raw(t3),
                        NeonStoreD::raw(t5),
                        NeonStoreD::raw(t7),
                        NeonStoreD::raw(t9),
                        NeonStoreD::raw(t11),
                        NeonStoreD::raw(t13),
                        NeonStoreD::raw(t15),
                        NeonStoreD::raw(t17),
                    ]);

                    vst1q_f64(chunk.slice_from_mut(0..).as_mut_ptr().cast(), u0.v);
                    vst1q_f64(chunk.slice_from_mut(1..).as_mut_ptr().cast(), u1.v);

                    vst1q_f64(chunk.slice_from_mut(2..).as_mut_ptr().cast(), u2.v);
                    vst1q_f64(chunk.slice_from_mut(3..).as_mut_ptr().cast(), u3.v);

                    vst1q_f64(chunk.slice_from_mut(4..).as_mut_ptr().cast(), u4.v);
                    vst1q_f64(chunk.slice_from_mut(5..).as_mut_ptr().cast(), u5.v);

                    vst1q_f64(chunk.slice_from_mut(6..).as_mut_ptr().cast(), u6.v);
                    vst1q_f64(chunk.slice_from_mut(7..).as_mut_ptr().cast(), u7.v);

                    vst1q_f64(chunk.slice_from_mut(8..).as_mut_ptr().cast(), u8.v);
                    vst1q_f64(chunk.slice_from_mut(9..).as_mut_ptr().cast(), u9.v);

                    vst1q_f64(chunk.slice_from_mut(10..).as_mut_ptr().cast(), u10.v);
                    vst1q_f64(chunk.slice_from_mut(11..).as_mut_ptr().cast(), u11.v);

                    vst1q_f64(chunk.slice_from_mut(12..).as_mut_ptr().cast(), u12.v);
                    vst1q_f64(chunk.slice_from_mut(13..).as_mut_ptr().cast(), u13.v);

                    vst1q_f64(chunk.slice_from_mut(14..).as_mut_ptr().cast(), u14.v);
                    vst1q_f64(chunk.slice_from_mut(15..).as_mut_ptr().cast(), u15.v);

                    vst1q_f64(chunk.slice_from_mut(16..).as_mut_ptr().cast(), u16.v);
                    vst1q_f64(chunk.slice_from_mut(17..).as_mut_ptr().cast(), u17.v);
                }
            }
        }

        boring_neon_butterfly!($name, $features, f64, 18);
    };
}

butterfly18d!(NeonButterfly18d, "neon", ColumnButterfly9d);

use crate::neon::butterflies::shared::{boring_neon_butterfly, gen_butterfly_twiddles_f32};
use crate::neon::mixed::{NeonStoreD, NeonStoreF};
use crate::neon::transpose::neon_transpose_f32x2_2x2_impl;

#[inline(always)]
pub(crate) fn transpose_9x2(
    rows0: [NeonStoreF; 2],
    rows1: [NeonStoreF; 2],
    rows2: [NeonStoreF; 2],
    rows3: [NeonStoreF; 2],
    rows4: [NeonStoreF; 2],
) -> [NeonStoreF; 9] {
    let a = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows0[0].v, rows0[1].v));
    let b = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows1[0].v, rows1[1].v));
    let c = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows2[0].v, rows2[1].v));
    let d = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows3[0].v, rows3[1].v));
    let e = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows4[0].v, rows4[1].v));
    [
        NeonStoreF::raw(a.0),
        NeonStoreF::raw(a.1),
        NeonStoreF::raw(b.0),
        NeonStoreF::raw(b.1),
        NeonStoreF::raw(c.0),
        NeonStoreF::raw(c.1),
        NeonStoreF::raw(d.0),
        NeonStoreF::raw(d.1),
        NeonStoreF::raw(e.0),
    ]
}

#[cfg(feature = "fcma")]
butterfly18d!(NeonFcmaButterfly18d, "fcma", ColumnFcmaButterfly9d);

use crate::neon::mixed::ColumnButterfly2f;
use crate::store::BidirectionalStore;

macro_rules! gen_bf18f {
    ($name: ident, $features: literal, $internal_bf9: ident, $internal_bf2: ident, $mul: ident) => {
        use crate::neon::mixed::$internal_bf9;
        pub(crate) struct $name {
            direction: FftDirection,
            bf2: $internal_bf2,
            bf9: $internal_bf9,
            twiddles: [NeonStoreF; 5],
        }

        impl $name {
            pub(crate) fn new(fft_direction: FftDirection) -> Self {
                Self {
                    direction: fft_direction,
                    twiddles: gen_butterfly_twiddles_f32(9, 2, fft_direction, 18),
                    bf2: $internal_bf2::new(fft_direction),
                    bf9: $internal_bf9::new(fft_direction),
                }
            }
        }

        boring_neon_butterfly!($name, $features, f32, 18);

        impl $name {
            #[inline]
            #[target_feature(enable = $features)]
            pub(crate) fn run<S: BidirectionalStore<Complex<f32>>>(&self, chunk: &mut S) {
                let mut rows0: [NeonStoreF; 2] = [NeonStoreF::default(); 2];
                let mut rows1: [NeonStoreF; 2] = [NeonStoreF::default(); 2];
                let mut rows2: [NeonStoreF; 2] = [NeonStoreF::default(); 2];
                let mut rows3: [NeonStoreF; 2] = [NeonStoreF::default(); 2];
                let mut rows4: [NeonStoreF; 2] = [NeonStoreF::default(); 2];
                // columns
                for i in 0..2 {
                    rows0[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 9..));
                    rows1[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 9 + 2..));
                    rows2[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 9 + 4..));
                    rows3[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 9 + 6..));
                    rows4[i] = NeonStoreF::load_complex(chunk.index(i * 9 + 8));
                }

                rows0 = self.bf2.exec(rows0);
                rows1 = self.bf2.exec(rows1);
                rows2 = self.bf2.exec(rows2);
                rows3 = self.bf2.exec(rows3);
                rows4 = self.bf2.exec(rows4);

                rows0[1] = NeonStoreF::$mul(rows0[1], self.twiddles[0]);
                rows1[1] = NeonStoreF::$mul(rows1[1], self.twiddles[1]);
                rows2[1] = NeonStoreF::$mul(rows2[1], self.twiddles[2]);
                rows3[1] = NeonStoreF::$mul(rows3[1], self.twiddles[3]);
                rows4[1] = NeonStoreF::$mul(rows4[1], self.twiddles[4]);

                let t = transpose_9x2(rows0, rows1, rows2, rows3, rows4);

                let q0 = self.bf9.exec(t);

                for i in 0..9 {
                    q0[i].write(chunk.slice_from_mut(i * 2..));
                }
            }
        }
    };
}

gen_bf18f!(
    NeonButterfly18f,
    "neon",
    ColumnButterfly9f,
    ColumnButterfly2f,
    mul_by_complex
);
#[cfg(feature = "fcma")]
gen_bf18f!(
    NeonFcmaButterfly18f,
    "fcma",
    ColumnFcmaButterfly9f,
    ColumnButterfly2f,
    fcmul_fcma
);

#[cfg(test)]
mod tests {
    use super::*;
    use crate::butterflies::test_butterfly;
    #[cfg(feature = "fcma")]
    use crate::neon::butterflies::test_fcma_butterfly;

    test_butterfly!(test_neon_butterfly18, f32, NeonButterfly18f, 18, 1e-5);
    test_butterfly!(test_neon_butterfly18_f64, f64, NeonButterfly18d, 18, 1e-7);

    #[cfg(feature = "fcma")]
    test_fcma_butterfly!(test_fcma_butterfly18, f32, NeonFcmaButterfly18f, 18, 1e-5);
    #[cfg(feature = "fcma")]
    test_fcma_butterfly!(
        test_fcma_butterfly18_f64,
        f64,
        NeonFcmaButterfly18d,
        18,
        1e-7
    );
}
