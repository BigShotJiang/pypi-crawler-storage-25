/*
 * // Copyright (c) Radzivon Bartoshyk 10/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::neon::butterflies::shared::{boring_neon_butterfly, gen_butterfly_twiddles_f32};
use crate::neon::mixed::NeonStoreF;
use crate::neon::transpose::neon_transpose_f32x2_2x2_impl;
use crate::store::{BidirectionalStore, InPlaceStore};
use crate::{FftDirection, FftExecutor, R2CFftExecutor, ZaftError};
use num_complex::Complex;
use std::arch::aarch64::*;

macro_rules! gen_bf32d {
    ($name: ident, $features: literal, $internal_bf32: ident) => {
        use crate::neon::mixed::$internal_bf32;
        pub(crate) struct $name {
            direction: FftDirection,
            bf32: $internal_bf32,
        }

        impl $name {
            pub(crate) fn new(fft_direction: FftDirection) -> Self {
                Self {
                    direction: fft_direction,
                    bf32: $internal_bf32::new(fft_direction),
                }
            }
        }

        boring_neon_butterfly!($name, $features, f64, 32);

        impl $name {
            #[inline]
            #[target_feature(enable = $features)]
            pub(crate) fn run<S: BidirectionalStore<Complex<f64>>>(&self, chunk: &mut S) {
                self.bf32.exec_store(chunk);
            }
        }

        impl $name {
            #[target_feature(enable = $features)]
            fn execute_r2c(&self, src: &[f64], dst: &mut [Complex<f64>]) -> Result<(), ZaftError> {
                if !src.len().is_multiple_of(32) {
                    return Err(ZaftError::InvalidSizeMultiplier(
                        src.len(),
                        self.real_length(),
                    ));
                }
                if !dst.len().is_multiple_of(17) {
                    return Err(ZaftError::InvalidSizeMultiplier(
                        dst.len(),
                        self.complex_length(),
                    ));
                }

                for (dst, src) in dst.chunks_exact_mut(17).zip(src.chunks_exact(32)) {
                    self.bf32.exec_store_r2c(src, &mut InPlaceStore::new(dst));
                }
                Ok(())
            }
        }

        impl R2CFftExecutor<f64> for $name {
            fn execute(&self, input: &[f64], output: &mut [Complex<f64>]) -> Result<(), ZaftError> {
                unsafe { self.execute_r2c(input, output) }
            }

            fn execute_with_scratch(
                &self,
                input: &[f64],
                output: &mut [Complex<f64>],
                _: &mut [Complex<f64>],
            ) -> Result<(), ZaftError> {
                unsafe { self.execute_r2c(input, output) }
            }

            fn real_length(&self) -> usize {
                32
            }

            fn complex_length(&self) -> usize {
                17
            }

            fn complex_scratch_length(&self) -> usize {
                0
            }
        }
    };
}

gen_bf32d!(NeonButterfly32d, "neon", ColumnButterfly32d);
#[cfg(feature = "fcma")]
gen_bf32d!(NeonFcmaButterfly32d, "fcma", ColumnFcmaButterfly32d);

#[inline(always)]
pub(crate) fn transpose_8x4_to_4x8_f32(
    rows0: [NeonStoreF; 4],
    rows1: [NeonStoreF; 4],
    rows2: [NeonStoreF; 4],
    rows3: [NeonStoreF; 4],
) -> ([NeonStoreF; 8], [NeonStoreF; 8]) {
    let output00 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows0[0].v, rows0[1].v));
    let output01 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows1[0].v, rows1[1].v));
    let output02 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows2[0].v, rows2[1].v));
    let output03 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows3[0].v, rows3[1].v));
    let output10 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows0[2].v, rows0[3].v));
    let output11 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows1[2].v, rows1[3].v));
    let output12 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows2[2].v, rows2[3].v));
    let output13 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows3[2].v, rows3[3].v));

    (
        [
            NeonStoreF::raw(output00.0),
            NeonStoreF::raw(output00.1),
            NeonStoreF::raw(output01.0),
            NeonStoreF::raw(output01.1),
            NeonStoreF::raw(output02.0),
            NeonStoreF::raw(output02.1),
            NeonStoreF::raw(output03.0),
            NeonStoreF::raw(output03.1),
        ],
        [
            NeonStoreF::raw(output10.0),
            NeonStoreF::raw(output10.1),
            NeonStoreF::raw(output11.0),
            NeonStoreF::raw(output11.1),
            NeonStoreF::raw(output12.0),
            NeonStoreF::raw(output12.1),
            NeonStoreF::raw(output13.0),
            NeonStoreF::raw(output13.1),
        ],
    )
}

macro_rules! gen_bf32f {
    ($name: ident, $features: literal, $internal_bf8: ident, $internal_bf4: ident, $mul: ident) => {
        use crate::neon::mixed::{$internal_bf4, $internal_bf8};
        pub(crate) struct $name {
            direction: FftDirection,
            bf8: $internal_bf8,
            bf4: $internal_bf4,
            twiddles: [NeonStoreF; 12],
        }

        impl $name {
            pub(crate) fn new(fft_direction: FftDirection) -> Self {
                Self {
                    direction: fft_direction,
                    bf8: $internal_bf8::new(fft_direction),
                    bf4: $internal_bf4::new(fft_direction),
                    twiddles: gen_butterfly_twiddles_f32(8, 4, fft_direction, 32),
                }
            }
        }

        boring_neon_butterfly!($name, $features, f32, 32);

        impl $name {
            #[inline]
            #[target_feature(enable = $features)]
            pub(crate) fn run<S: BidirectionalStore<Complex<f32>>>(&self, chunk: &mut S) {
                let mut rows0: [NeonStoreF; 4] = [NeonStoreF::default(); 4];
                let mut rows1: [NeonStoreF; 4] = [NeonStoreF::default(); 4];
                let mut rows2: [NeonStoreF; 4] = [NeonStoreF::default(); 4];
                let mut rows3: [NeonStoreF; 4] = [NeonStoreF::default(); 4];
                for i in 0..4 {
                    rows0[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 8..));
                    rows1[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 8 + 2..));
                    rows2[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 8 + 4..));
                    rows3[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 8 + 6..));
                }

                rows0 = self.bf4.exec(rows0);
                rows1 = self.bf4.exec(rows1);
                rows2 = self.bf4.exec(rows2);
                rows3 = self.bf4.exec(rows3);

                for i in 1..4 {
                    rows0[i] = NeonStoreF::$mul(rows0[i], self.twiddles[i - 1]);
                    rows1[i] = NeonStoreF::$mul(rows1[i], self.twiddles[i - 1 + 3]);
                    rows2[i] = NeonStoreF::$mul(rows2[i], self.twiddles[i - 1 + 6]);
                    rows3[i] = NeonStoreF::$mul(rows3[i], self.twiddles[i - 1 + 9]);
                }

                let (mut q0, mut q1) = transpose_8x4_to_4x8_f32(rows0, rows1, rows2, rows3);

                q0 = self.bf8.exec(q0);
                q1 = self.bf8.exec(q1);

                for i in 0..8 {
                    q0[i].write(chunk.slice_from_mut(i * 4..));
                    q1[i].write(chunk.slice_from_mut(i * 4 + 2..));
                }
            }
        }

        impl $name {
            #[target_feature(enable = $features)]
            fn execute_r2c(&self, src: &[f32], dst: &mut [Complex<f32>]) -> Result<(), ZaftError> {
                if !src.len().is_multiple_of(32) {
                    return Err(ZaftError::InvalidSizeMultiplier(src.len(), self.length()));
                }
                if !dst.len().is_multiple_of(17) {
                    return Err(ZaftError::InvalidSizeMultiplier(dst.len(), self.length()));
                }

                unsafe {
                    let mut rows0: [NeonStoreF; 4] = [NeonStoreF::default(); 4];
                    let mut rows1: [NeonStoreF; 4] = [NeonStoreF::default(); 4];
                    let mut rows2: [NeonStoreF; 4] = [NeonStoreF::default(); 4];
                    let mut rows3: [NeonStoreF; 4] = [NeonStoreF::default(); 4];

                    for (dst, src) in dst.chunks_exact_mut(17).zip(src.chunks_exact(32)) {
                        for i in 0..4 {
                            let s0 = NeonStoreF::load(src.get_unchecked(i * 8..));
                            let s1 = NeonStoreF::load(src.get_unchecked(i * 8 + 4..));
                            let [u0, u1] = s0.to_complex();
                            let [u2, u3] = s1.to_complex();
                            rows0[i] = u0;
                            rows1[i] = u1;
                            rows2[i] = u2;
                            rows3[i] = u3;
                        }

                        rows0 = self.bf4.exec(rows0);
                        rows1 = self.bf4.exec(rows1);
                        rows2 = self.bf4.exec(rows2);
                        rows3 = self.bf4.exec(rows3);

                        for i in 1..4 {
                            rows0[i] = NeonStoreF::$mul(rows0[i], self.twiddles[i - 1]);
                            rows1[i] = NeonStoreF::$mul(rows1[i], self.twiddles[i - 1 + 3]);
                            rows2[i] = NeonStoreF::$mul(rows2[i], self.twiddles[i - 1 + 6]);
                            rows3[i] = NeonStoreF::$mul(rows3[i], self.twiddles[i - 1 + 9]);
                        }

                        let (mut q0, mut q1) = transpose_8x4_to_4x8_f32(rows0, rows1, rows2, rows3);

                        q0 = self.bf8.exec(q0);
                        q1 = self.bf8.exec(q1);

                        for i in 0..4 {
                            q0[i].write(dst.get_unchecked_mut(i * 4..));
                            q1[i].write(dst.get_unchecked_mut(i * 4 + 2..));
                        }
                        q0[4].write_lo(dst.get_unchecked_mut(16..));
                    }
                }
                Ok(())
            }
        }

        impl R2CFftExecutor<f32> for $name {
            fn execute(&self, input: &[f32], output: &mut [Complex<f32>]) -> Result<(), ZaftError> {
                unsafe { self.execute_r2c(input, output) }
            }

            fn execute_with_scratch(
                &self,
                input: &[f32],
                output: &mut [Complex<f32>],
                _: &mut [Complex<f32>],
            ) -> Result<(), ZaftError> {
                unsafe { self.execute_r2c(input, output) }
            }

            fn real_length(&self) -> usize {
                32
            }

            fn complex_length(&self) -> usize {
                17
            }

            fn complex_scratch_length(&self) -> usize {
                0
            }
        }
    };
}

gen_bf32f!(
    NeonButterfly32f,
    "neon",
    ColumnButterfly8f,
    ColumnButterfly4f,
    mul_by_complex
);
#[cfg(feature = "fcma")]
gen_bf32f!(
    NeonFcmaButterfly32f,
    "fcma",
    ColumnFcmaButterfly8f,
    ColumnFcmaButterfly4f,
    fcmul_fcma
);

#[cfg(test)]
mod tests {
    use super::*;
    use crate::butterflies::{test_butterfly, test_oof_butterfly};
    #[cfg(feature = "fcma")]
    use crate::neon::butterflies::{test_fcma_butterfly, test_oof_fcma_butterfly};
    use crate::r2c::test_r2c_butterfly;

    test_r2c_butterfly!(test_neon_r2c_butterfly32, f32, NeonButterfly32f, 32, 1e-5);
    test_r2c_butterfly!(test_neon_r2c_butterfly32d, f64, NeonButterfly32d, 32, 1e-5);
    test_butterfly!(test_neon_butterfly32, f32, NeonButterfly32f, 32, 1e-5);
    #[cfg(feature = "fcma")]
    test_fcma_butterfly!(test_fcma_butterfly32, f32, NeonFcmaButterfly32f, 32, 1e-5);
    test_butterfly!(test_neon_butterfly32_f64, f64, NeonButterfly32d, 32, 1e-7);
    #[cfg(feature = "fcma")]
    test_fcma_butterfly!(
        test_fcma_butterfly32_f64,
        f64,
        NeonFcmaButterfly32d,
        32,
        1e-7
    );
    test_oof_butterfly!(test_oof_butterfly32, f32, NeonButterfly32f, 32, 1e-5);
    #[cfg(feature = "fcma")]
    test_oof_fcma_butterfly!(
        test_oof_fcma_butterfly32,
        f32,
        NeonFcmaButterfly32f,
        32,
        1e-5
    );
    test_oof_butterfly!(test_oof_butterfly32_f64, f64, NeonButterfly32d, 32, 1e-9);
    #[cfg(feature = "fcma")]
    test_oof_fcma_butterfly!(
        test_oof_fcma_butterfly32_f64,
        f64,
        NeonButterfly32d,
        32,
        1e-9
    );
}
