/*
 * // Copyright (c) Radzivon Bartoshyk 10/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::neon::butterflies::shared::{boring_neon_butterfly, gen_butterfly_twiddles_f32};
use crate::neon::mixed::{ColumnButterfly2d, NeonStoreD, NeonStoreF};
use crate::neon::transpose::neon_transpose_f32x2_2x2_impl;
use crate::{FftDirection, FftExecutor, ZaftError};
use num_complex::Complex;
use std::arch::aarch64::*;

macro_rules! gen_bf10d {
    ($name: ident, $features: literal, $internal_bf5: ident) => {
        use crate::neon::mixed::$internal_bf5;
        pub(crate) struct $name {
            direction: FftDirection,
            bf5: $internal_bf5,
            bf2: ColumnButterfly2d,
        }

        impl $name {
            pub(crate) fn new(fft_direction: FftDirection) -> Self {
                Self {
                    direction: fft_direction,
                    bf5: $internal_bf5::new(fft_direction),
                    bf2: ColumnButterfly2d::new(fft_direction),
                }
            }
        }

        boring_neon_butterfly!($name, $features, f64, 10);

        impl $name {
            #[inline]
            #[target_feature(enable = $features)]
            pub(crate) fn run<S: BidirectionalStore<Complex<f64>>>(&self, chunk: &mut S) {
                let u0 = NeonStoreD::from_complex_ref(chunk.slice_from(0..));
                let u1 = NeonStoreD::from_complex_ref(chunk.slice_from(1..));
                let u2 = NeonStoreD::from_complex_ref(chunk.slice_from(2..));
                let u3 = NeonStoreD::from_complex_ref(chunk.slice_from(3..));
                let u4 = NeonStoreD::from_complex_ref(chunk.slice_from(4..));
                let u5 = NeonStoreD::from_complex_ref(chunk.slice_from(5..));
                let u6 = NeonStoreD::from_complex_ref(chunk.slice_from(6..));
                let u7 = NeonStoreD::from_complex_ref(chunk.slice_from(7..));
                let u8 = NeonStoreD::from_complex_ref(chunk.slice_from(8..));
                let u9 = NeonStoreD::from_complex_ref(chunk.slice_from(9..));

                let mid0 = self.bf5.exec([u0, u2, u4, u6, u8]);
                let mid1 = self.bf5.exec([u5, u7, u9, u1, u3]);

                // Since this is good-thomas algorithm, we don't need twiddle factors
                let [y0, y1] = self.bf2.exec([mid0[0], mid1[0]]);
                let [y2, y3] = self.bf2.exec([mid0[1], mid1[1]]);
                let [y4, y5] = self.bf2.exec([mid0[2], mid1[2]]);
                let [y6, y7] = self.bf2.exec([mid0[3], mid1[3]]);
                let [y8, y9] = self.bf2.exec([mid0[4], mid1[4]]);

                unsafe {
                    vst1q_f64(chunk.slice_from_mut(0..).as_mut_ptr().cast(), y0.v);
                    vst1q_f64(chunk.slice_from_mut(1..).as_mut_ptr().cast(), y3.v);
                    vst1q_f64(chunk.slice_from_mut(2..).as_mut_ptr().cast(), y4.v);

                    vst1q_f64(chunk.slice_from_mut(3..).as_mut_ptr().cast(), y7.v);
                    vst1q_f64(chunk.slice_from_mut(4..).as_mut_ptr().cast(), y8.v);
                    vst1q_f64(chunk.slice_from_mut(5..).as_mut_ptr().cast(), y1.v);

                    vst1q_f64(chunk.slice_from_mut(6..).as_mut_ptr().cast(), y2.v);
                    vst1q_f64(chunk.slice_from_mut(7..).as_mut_ptr().cast(), y5.v);
                    vst1q_f64(chunk.slice_from_mut(8..).as_mut_ptr().cast(), y6.v);

                    vst1q_f64(chunk.slice_from_mut(9..).as_mut_ptr().cast(), y9.v);
                }
            }
        }
    };
}

gen_bf10d!(NeonButterfly10d, "neon", ColumnButterfly5d);
#[cfg(feature = "fcma")]
gen_bf10d!(NeonFcmaButterfly10d, "fcma", ColumnFcmaButterfly5d);

#[inline(always)]
pub(crate) fn transpose_f32x2_5x2(
    rows0: [NeonStoreF; 2],
    rows1: [NeonStoreF; 2],
    rows2: [NeonStoreF; 2],
) -> [NeonStoreF; 5] {
    let a0 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows0[0].v, rows0[1].v));

    let b0 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows1[0].v, rows1[1].v));

    let c0 = neon_transpose_f32x2_2x2_impl(float32x4x2_t(rows2[0].v, rows2[1].v));
    [
        NeonStoreF::raw(a0.0),
        NeonStoreF::raw(a0.1),
        NeonStoreF::raw(b0.0),
        NeonStoreF::raw(b0.1),
        NeonStoreF::raw(c0.0),
    ]
}

use crate::neon::mixed::ColumnButterfly2f;
use crate::store::BidirectionalStore;

macro_rules! gen_bf10f {
    ($name: ident, $features: literal, $internal_bf5: ident, $internal_bf2: ident, $mul: ident) => {
        use crate::neon::mixed::$internal_bf5;
        pub(crate) struct $name {
            direction: FftDirection,
            bf2: $internal_bf2,
            bf5: $internal_bf5,
            twiddles: [NeonStoreF; 6],
        }

        impl $name {
            pub(crate) fn new(fft_direction: FftDirection) -> Self {
                Self {
                    direction: fft_direction,
                    twiddles: gen_butterfly_twiddles_f32(5, 2, fft_direction, 10),
                    bf2: $internal_bf2::new(fft_direction),
                    bf5: $internal_bf5::new(fft_direction),
                }
            }
        }

        boring_neon_butterfly!($name, $features, f32, 10);

        impl $name {
            #[inline]
            #[target_feature(enable = $features)]
            pub(crate) fn run<S: BidirectionalStore<Complex<f32>>>(&self, chunk: &mut S) {
                let mut rows0: [NeonStoreF; 2] = [NeonStoreF::default(); 2];
                let mut rows1: [NeonStoreF; 2] = [NeonStoreF::default(); 2];
                let mut rows2: [NeonStoreF; 2] = [NeonStoreF::default(); 2];
                // columns
                for i in 0..2 {
                    rows0[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 5..));
                    rows1[i] = NeonStoreF::from_complex_ref(chunk.slice_from(i * 5 + 2..));
                    rows2[i] = NeonStoreF::load_complex(chunk.index(i * 5 + 4));
                }

                rows0 = self.bf2.exec(rows0);
                rows1 = self.bf2.exec(rows1);
                rows2 = self.bf2.exec(rows2);

                rows0[1] = NeonStoreF::$mul(rows0[1], self.twiddles[0]);
                rows1[1] = NeonStoreF::$mul(rows1[1], self.twiddles[1]);
                rows2[1] = NeonStoreF::$mul(rows2[1], self.twiddles[2]);

                let transposed = transpose_f32x2_5x2(rows0, rows1, rows2);

                // rows

                let q0 = self.bf5.exec(transposed);

                for i in 0..5 {
                    q0[i].write(chunk.slice_from_mut(i * 2..));
                }
            }
        }
    };
}

gen_bf10f!(
    NeonButterfly10f,
    "neon",
    ColumnButterfly5f,
    ColumnButterfly2f,
    mul_by_complex
);
#[cfg(feature = "fcma")]
gen_bf10f!(
    NeonFcmaButterfly10f,
    "fcma",
    ColumnFcmaButterfly5f,
    ColumnButterfly2f,
    fcmul_fcma
);

#[cfg(test)]
mod tests {
    use super::*;
    use crate::butterflies::{test_butterfly, test_oof_butterfly};
    #[cfg(feature = "fcma")]
    use crate::neon::butterflies::{test_fcma_butterfly, test_oof_fcma_butterfly};

    test_butterfly!(test_neon_butterfly10, f32, NeonButterfly10f, 10, 1e-5);
    #[cfg(feature = "fcma")]
    test_fcma_butterfly!(test_fcma_butterfly10, f32, NeonFcmaButterfly10f, 10, 1e-5);
    test_butterfly!(test_neon_butterfly10_f64, f64, NeonButterfly10d, 10, 1e-7);
    #[cfg(feature = "fcma")]
    test_fcma_butterfly!(
        test_fcma_butterfly10_f64,
        f64,
        NeonFcmaButterfly10d,
        10,
        1e-7
    );
    test_oof_butterfly!(test_oof_butterfly10, f32, NeonButterfly10f, 10, 1e-5);
    #[cfg(feature = "fcma")]
    test_oof_fcma_butterfly!(
        test_oof_fcma_butterfly10,
        f32,
        NeonFcmaButterfly10f,
        10,
        1e-5
    );
    test_oof_butterfly!(test_oof_butterfly10_f64, f64, NeonButterfly10d, 10, 1e-9);
    #[cfg(feature = "fcma")]
    test_oof_fcma_butterfly!(
        test_oof_fcma_butterfly10_f64,
        f64,
        NeonFcmaButterfly10d,
        10,
        1e-9
    );
}
