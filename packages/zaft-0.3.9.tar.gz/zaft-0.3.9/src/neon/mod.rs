/*
 * // Copyright (c) Radzivon Bartoshyk 9/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
mod butterflies;
mod c2r;
mod c2r_expand;
mod mixed;
mod r2c;
#[cfg(feature = "fcma")]
mod r2c_fcma;
mod raders;
mod radix10;
#[cfg(feature = "fcma")]
mod radix10_fcma;
mod radix3;
#[cfg(feature = "fcma")]
mod radix3_fcma;
mod radix4;
#[cfg(feature = "fcma")]
mod radix4_fcma;
mod radix5;
#[cfg(feature = "fcma")]
mod radix5_fcma;
mod radix6;
#[cfg(feature = "fcma")]
mod radix6_fcma;
mod radix7;
#[cfg(feature = "fcma")]
mod radix7_fcma;
mod spectrum_arithmetic;
#[cfg(feature = "fcma")]
mod spectrum_arithmetic_fcma;
mod transpose;
mod util;

pub(crate) use butterflies::{
    NeonButterfly2, NeonButterfly3, NeonButterfly4, NeonButterfly5, NeonButterfly6d,
    NeonButterfly6f, NeonButterfly7d, NeonButterfly7f, NeonButterfly8d, NeonButterfly8f,
    NeonButterfly9d, NeonButterfly9f, NeonButterfly10d, NeonButterfly10f, NeonButterfly11d,
    NeonButterfly11f, NeonButterfly12d, NeonButterfly12f, NeonButterfly13d, NeonButterfly13f,
    NeonButterfly14d, NeonButterfly14f, NeonButterfly15d, NeonButterfly15f, NeonButterfly16d,
    NeonButterfly16f, NeonButterfly17d, NeonButterfly17f, NeonButterfly18d, NeonButterfly18f,
    NeonButterfly19d, NeonButterfly19f, NeonButterfly20d, NeonButterfly20f, NeonButterfly21d,
    NeonButterfly21f, NeonButterfly23d, NeonButterfly23f, NeonButterfly24d, NeonButterfly24f,
    NeonButterfly25d, NeonButterfly25f, NeonButterfly27d, NeonButterfly27f, NeonButterfly28d,
    NeonButterfly28f, NeonButterfly30d, NeonButterfly30f, NeonButterfly32d, NeonButterfly32f,
    NeonButterfly35d, NeonButterfly35f, NeonButterfly36d, NeonButterfly36f, NeonButterfly40d,
    NeonButterfly40f, NeonButterfly42d, NeonButterfly42f, NeonButterfly48d, NeonButterfly48f,
    NeonButterfly49d, NeonButterfly49f, NeonButterfly54d, NeonButterfly54f, NeonButterfly63d,
    NeonButterfly63f, NeonButterfly64d, NeonButterfly64f, NeonButterfly66d, NeonButterfly66f,
    NeonButterfly70d, NeonButterfly70f, NeonButterfly72d, NeonButterfly72f, NeonButterfly78d,
    NeonButterfly78f, NeonButterfly81d, NeonButterfly81f, NeonButterfly88d, NeonButterfly88f,
    NeonButterfly96d, NeonButterfly96f, NeonButterfly100d, NeonButterfly100f, NeonButterfly108d,
    NeonButterfly108f, NeonButterfly121d, NeonButterfly121f, NeonButterfly125d, NeonButterfly125f,
    NeonButterfly128d, NeonButterfly128f, NeonButterfly144d, NeonButterfly144f, NeonButterfly169d,
    NeonButterfly169f, NeonButterfly192d, NeonButterfly192f, NeonButterfly216d, NeonButterfly216f,
    NeonButterfly243d, NeonButterfly243f, NeonButterfly256d, NeonButterfly256f, NeonButterfly512f,
    NeonButterfly576f, NeonButterfly1024f, NeonButterfly1152f, NeonButterfly1296f,
    NeonButterfly1536f, NeonButterfly1800f, NeonButterfly2048f,
};
#[cfg(feature = "fcma")]
pub(crate) use butterflies::{
    NeonFcmaButterfly4, NeonFcmaButterfly5, NeonFcmaButterfly6d, NeonFcmaButterfly6f,
    NeonFcmaButterfly7d, NeonFcmaButterfly7f, NeonFcmaButterfly8d, NeonFcmaButterfly8f,
    NeonFcmaButterfly9d, NeonFcmaButterfly9f, NeonFcmaButterfly10d, NeonFcmaButterfly10f,
    NeonFcmaButterfly11d, NeonFcmaButterfly11f, NeonFcmaButterfly12d, NeonFcmaButterfly12f,
    NeonFcmaButterfly13d, NeonFcmaButterfly13f, NeonFcmaButterfly14d, NeonFcmaButterfly14f,
    NeonFcmaButterfly15d, NeonFcmaButterfly15f, NeonFcmaButterfly16d, NeonFcmaButterfly16f,
    NeonFcmaButterfly17d, NeonFcmaButterfly17f, NeonFcmaButterfly18d, NeonFcmaButterfly18f,
    NeonFcmaButterfly19d, NeonFcmaButterfly19f, NeonFcmaButterfly20d, NeonFcmaButterfly20f,
    NeonFcmaButterfly21d, NeonFcmaButterfly21f, NeonFcmaButterfly23d, NeonFcmaButterfly23f,
    NeonFcmaButterfly24d, NeonFcmaButterfly24f, NeonFcmaButterfly25d, NeonFcmaButterfly25f,
    NeonFcmaButterfly27d, NeonFcmaButterfly27f, NeonFcmaButterfly28d, NeonFcmaButterfly28f,
    NeonFcmaButterfly30d, NeonFcmaButterfly30f, NeonFcmaButterfly32d, NeonFcmaButterfly32f,
    NeonFcmaButterfly35d, NeonFcmaButterfly35f, NeonFcmaButterfly36d, NeonFcmaButterfly36f,
    NeonFcmaButterfly40d, NeonFcmaButterfly40f, NeonFcmaButterfly42d, NeonFcmaButterfly42f,
    NeonFcmaButterfly48d, NeonFcmaButterfly48f, NeonFcmaButterfly49d, NeonFcmaButterfly49f,
    NeonFcmaButterfly54d, NeonFcmaButterfly54f, NeonFcmaButterfly63d, NeonFcmaButterfly63f,
    NeonFcmaButterfly64d, NeonFcmaButterfly64f, NeonFcmaButterfly66d, NeonFcmaButterfly66f,
    NeonFcmaButterfly70d, NeonFcmaButterfly70f, NeonFcmaButterfly72d, NeonFcmaButterfly72f,
    NeonFcmaButterfly78d, NeonFcmaButterfly78f, NeonFcmaButterfly81d, NeonFcmaButterfly81f,
    NeonFcmaButterfly88d, NeonFcmaButterfly88f, NeonFcmaButterfly96d, NeonFcmaButterfly96f,
    NeonFcmaButterfly100d, NeonFcmaButterfly100f, NeonFcmaButterfly108d, NeonFcmaButterfly108f,
    NeonFcmaButterfly121d, NeonFcmaButterfly121f, NeonFcmaButterfly125d, NeonFcmaButterfly125f,
    NeonFcmaButterfly128d, NeonFcmaButterfly128f, NeonFcmaButterfly144d, NeonFcmaButterfly144f,
    NeonFcmaButterfly169d, NeonFcmaButterfly169f, NeonFcmaButterfly192d, NeonFcmaButterfly192f,
    NeonFcmaButterfly216d, NeonFcmaButterfly216f, NeonFcmaButterfly243d, NeonFcmaButterfly243f,
    NeonFcmaButterfly256d, NeonFcmaButterfly256f, NeonFcmaButterfly512f, NeonFcmaButterfly576f,
    NeonFcmaButterfly1296f, NeonFcmaButterfly1800f, NeonFcmaForwardButterfly1024f,
    NeonFcmaForwardButterfly1152f, NeonFcmaForwardButterfly1536f, NeonFcmaForwardButterfly2048f,
    NeonFcmaInverseButterfly1024f, NeonFcmaInverseButterfly1152f, NeonFcmaInverseButterfly1536f,
    NeonFcmaInverseButterfly2048f,
};
pub(crate) use c2r::C2RNeonTwiddles;
pub(crate) use c2r_expand::NeonC2RExpanderF;
pub(crate) use mixed::{
    NeonC2RMixedRadix3d, NeonC2RMixedRadix3f, NeonC2RMixedRadix5d, NeonC2RMixedRadix5f,
    NeonC2RMixedRadix7d, NeonC2RMixedRadix7f, NeonC2RMixedRadix9d, NeonC2RMixedRadix9f,
    NeonC2RMixedRadix11d, NeonC2RMixedRadix11f, NeonMixedRadix2, NeonMixedRadix2f, NeonMixedRadix3,
    NeonMixedRadix3f, NeonMixedRadix4, NeonMixedRadix4f, NeonMixedRadix5, NeonMixedRadix5f,
    NeonMixedRadix6, NeonMixedRadix6f, NeonMixedRadix7, NeonMixedRadix7f, NeonMixedRadix8,
    NeonMixedRadix8f, NeonMixedRadix9, NeonMixedRadix9f, NeonMixedRadix10, NeonMixedRadix10f,
    NeonMixedRadix11, NeonMixedRadix11f, NeonMixedRadix12, NeonMixedRadix12f, NeonMixedRadix13,
    NeonMixedRadix13f,
};
#[cfg(feature = "fcma")]
pub(crate) use mixed::{
    NeonFcmaC2RMixedRadix3d, NeonFcmaC2RMixedRadix3f, NeonFcmaC2RMixedRadix5d,
    NeonFcmaC2RMixedRadix5f, NeonFcmaC2RMixedRadix7d, NeonFcmaC2RMixedRadix7f,
    NeonFcmaC2RMixedRadix9d, NeonFcmaC2RMixedRadix9f, NeonFcmaC2RMixedRadix11d,
    NeonFcmaC2RMixedRadix11f, NeonFcmaR2CMixedRadix3d, NeonFcmaR2CMixedRadix3f,
    NeonFcmaR2CMixedRadix5d, NeonFcmaR2CMixedRadix5f, NeonFcmaR2CMixedRadix7d,
    NeonFcmaR2CMixedRadix7f, NeonFcmaR2CMixedRadix9d, NeonFcmaR2CMixedRadix9f,
    NeonFcmaR2CMixedRadix11d, NeonFcmaR2CMixedRadix11f, NeonFcmaR2CMixedRadix13d,
    NeonFcmaR2CMixedRadix13f,
};
#[cfg(feature = "fcma")]
pub(crate) use mixed::{
    NeonFcmaForwardMixedRadix4f, NeonFcmaForwardMixedRadix8f, NeonFcmaInverseMixedRadix4f,
    NeonFcmaInverseMixedRadix8f, NeonFcmaMixedRadix2, NeonFcmaMixedRadix2f, NeonFcmaMixedRadix3,
    NeonFcmaMixedRadix3f, NeonFcmaMixedRadix4, NeonFcmaMixedRadix5, NeonFcmaMixedRadix5f,
    NeonFcmaMixedRadix6, NeonFcmaMixedRadix6f, NeonFcmaMixedRadix7, NeonFcmaMixedRadix7f,
    NeonFcmaMixedRadix8, NeonFcmaMixedRadix9, NeonFcmaMixedRadix9f, NeonFcmaMixedRadix10,
    NeonFcmaMixedRadix10f, NeonFcmaMixedRadix11, NeonFcmaMixedRadix11f, NeonFcmaMixedRadix12,
    NeonFcmaMixedRadix12f, NeonFcmaMixedRadix13, NeonFcmaMixedRadix13f,
};
pub(crate) use mixed::{
    NeonR2CMixedRadix3d, NeonR2CMixedRadix3f, NeonR2CMixedRadix5d, NeonR2CMixedRadix5f,
    NeonR2CMixedRadix7d, NeonR2CMixedRadix7f, NeonR2CMixedRadix9d, NeonR2CMixedRadix9f,
    NeonR2CMixedRadix11d, NeonR2CMixedRadix11f, NeonR2CMixedRadix13d, NeonR2CMixedRadix13f,
};
pub(crate) use r2c::R2CNeonTwiddles;
#[cfg(feature = "fcma")]
pub(crate) use r2c_fcma::R2CNeonTwiddlesFcma;
#[allow(unused_imports)]
pub(crate) use raders::{NeonRadersFft, NeonRadersIndicer, RadersIndicer};
pub(crate) use radix3::NeonRadix3;
#[cfg(feature = "fcma")]
pub(crate) use radix3_fcma::NeonFcmaRadix3;
pub(crate) use radix4::NeonRadix4;
#[cfg(feature = "fcma")]
pub(crate) use radix4_fcma::NeonFcmaRadix4;
pub(crate) use radix5::NeonRadix5;
#[cfg(feature = "fcma")]
pub(crate) use radix5_fcma::NeonFcmaRadix5;
pub(crate) use radix6::NeonRadix6;
#[cfg(feature = "fcma")]
pub(crate) use radix6_fcma::NeonFcmaRadix6;
pub(crate) use radix7::NeonRadix7;
#[cfg(feature = "fcma")]
pub(crate) use radix7_fcma::NeonFcmaRadix7;
pub(crate) use radix10::NeonRadix10;
#[cfg(feature = "fcma")]
pub(crate) use radix10_fcma::NeonFcmaRadix10;
#[allow(unused)]
pub(crate) use spectrum_arithmetic::NeonSpectrumArithmetic;
#[allow(unused)]
#[cfg(feature = "fcma")]
pub(crate) use spectrum_arithmetic_fcma::NeonFcmaSpectrumArithmetic;
pub(crate) use transpose::{
    NeonTranspose2x2F32, NeonTranspose2x2F64, NeonTranspose4x3F64, NeonTranspose4x4F32,
    NeonTranspose4x4F64, NeonTranspose5x7F32, NeonTranspose6x4F32, NeonTranspose6x5F32,
    NeonTranspose7x5F32, NeonTranspose7x6F32, NeonTranspose7x7F32, NeonTranspose9x2F32,
    NeonTranspose11x2F32, NeonTransposeDReal4x4, NeonTransposeNx2F32, NeonTransposeNx2F64,
    NeonTransposeNx3F32, NeonTransposeNx3F64, NeonTransposeNx4F32, NeonTransposeNx4F64,
    NeonTransposeNx5F32, NeonTransposeNx5F64, NeonTransposeNx6F32, NeonTransposeNx6F64,
    NeonTransposeNx7F32, NeonTransposeNx7F64, NeonTransposeNx8F32, NeonTransposeNx8F64,
    NeonTransposeNx9F32, NeonTransposeNx9F64, NeonTransposeNx10F32, NeonTransposeNx10F64,
    NeonTransposeNx11F32, NeonTransposeNx11F64, NeonTransposeNx12F32, NeonTransposeNx12F64,
    NeonTransposeNx13F32, NeonTransposeNx13F64, NeonTransposeNx14F32, NeonTransposeNx14F64,
    NeonTransposeNx15F32, NeonTransposeNx15F64, NeonTransposeNx16F32, NeonTransposeNx16F64,
    NeonTransposeNx17F32, NeonTransposeNx17F64, NeonTransposeNx18F32, NeonTransposeNx18F64,
    NeonTransposeNx19F32, NeonTransposeNx19F64, NeonTransposeNx20F32, NeonTransposeReal4x4,
    NeonTransposeRealInvNx3F32, NeonTransposeRealInvNx3F64, NeonTransposeRealInvNx5F32,
    NeonTransposeRealInvNx5F64, NeonTransposeRealInvNx7F32, NeonTransposeRealInvNx7F64,
    NeonTransposeRealInvNx9F32, NeonTransposeRealInvNx9F64, NeonTransposeRealInvNx11F32,
    NeonTransposeRealInvNx11F64, block_transpose_f32x2_2x2, neon_transpose_f32x2_4x4,
    neon_transpose_f64x2_2x2,
};

#[cfg(test)]
#[cfg(feature = "fcma")]
macro_rules! test_fcma_radix {
    ($method_name: ident, $data_type: ident, $butterfly: ident, $iters: expr, $scale: expr, $tol: expr) => {
        #[test]
        fn $method_name() {
            if !std::arch::is_aarch64_feature_detected!("fcma") {
                return;
            }
            use crate::FftDirection;
            use crate::FftExecutor;
            use num_complex::Complex;
            use rand::RngExt;
            for i in 1..$iters {
                let val = $scale as usize;
                let size = val.pow(i);
                let mut input = vec![Complex::<$data_type>::default(); size];
                for z in input.iter_mut() {
                    *z = Complex {
                        re: rand::rng().random(),
                        im: rand::rng().random(),
                    };
                }
                let src = input.to_vec();
                use crate::dft::Dft;
                let reference_forward = Dft::new(size, FftDirection::Forward).unwrap();

                let mut ref_src = src.to_vec();
                reference_forward.execute(&mut ref_src).unwrap();

                let radix_forward = $butterfly::new(size, FftDirection::Forward).unwrap();
                let radix_inverse = $butterfly::new(size, FftDirection::Inverse).unwrap();
                radix_forward.execute(&mut input).unwrap();

                input
                    .iter()
                    .zip(ref_src.iter())
                    .enumerate()
                    .for_each(|(idx, (a, b))| {
                        assert!(
                            (a.re - b.re).abs() < $tol,
                            "a_re {} != b_re {} for size {} at {idx}",
                            a.re,
                            b.re,
                            size
                        );
                        assert!(
                            (a.im - b.im).abs() < $tol,
                            "a_im {} != b_im {} for size {} at {idx}",
                            a.im,
                            b.im,
                            size
                        );
                    });

                radix_inverse.execute(&mut input).unwrap();

                input = input
                    .iter()
                    .map(|&x| x * (1.0 / size as $data_type))
                    .collect();

                input.iter().zip(src.iter()).for_each(|(a, b)| {
                    assert!(
                        (a.re - b.re).abs() < $tol,
                        "a_re {} != b_re {} for size {}",
                        a.re,
                        b.re,
                        size
                    );
                    assert!(
                        (a.im - b.im).abs() < $tol,
                        "a_im {} != b_im {} for size {}",
                        a.im,
                        b.im,
                        size
                    );
                });
            }
        }
    };
}

#[cfg(test)]
#[cfg(feature = "fcma")]
pub(crate) use test_fcma_radix;
