/*
 * // Copyright (c) Radzivon Bartoshyk 9/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::err::try_vec;
use crate::neon::butterflies::{NeonButterfly, NeonFastButterfly5};
use crate::neon::radix10::neon_bitreversed_transpose_f32_radix10;
use crate::neon::util::{
    create_neon_twiddles, vfcmul_fcma_f32, vfcmulq_fcma_f32, vfcmulq_fcma_f64,
};
use crate::radix10::Radix10Twiddles;
use crate::util::{
    bitreversed_transpose, int_logarithm, is_power_of_ten, validate_oof_sizes, validate_scratch,
};
use crate::{FftDirection, FftExecutor, FftSample, ZaftError};
use num_complex::Complex;
use num_traits::{AsPrimitive, Zero};
use std::arch::aarch64::*;
use std::sync::Arc;

pub(crate) struct NeonFcmaRadix10<T> {
    twiddles: Vec<Complex<T>>,
    execution_length: usize,
    bf5: NeonFastButterfly5<T>,
    direction: FftDirection,
    butterfly: Arc<dyn FftExecutor<T> + Send + Sync>,
    butterfly_length: usize,
}

impl<T: FftSample + Radix10Twiddles> NeonFcmaRadix10<T>
where
    f64: AsPrimitive<T>,
{
    pub fn new(size: usize, fft_direction: FftDirection) -> Result<NeonFcmaRadix10<T>, ZaftError> {
        assert!(
            is_power_of_ten(size as u64),
            "Input length must be a power of 10"
        );

        let log10 = int_logarithm::<10>(size).unwrap();
        let butterfly = match log10 {
            0 => T::butterfly1(fft_direction)?,
            1 => T::butterfly10(fft_direction)?,
            _ => {
                T::butterfly100(fft_direction).map_or_else(|| T::butterfly10(fft_direction), Ok)?
            }
        };

        let butterfly_length = butterfly.length();

        let twiddles = create_neon_twiddles::<T, 10>(butterfly_length, size, fft_direction)?;

        Ok(NeonFcmaRadix10 {
            execution_length: size,
            twiddles,
            bf5: NeonFastButterfly5::new(fft_direction),
            direction: fft_direction,
            butterfly,
            butterfly_length,
        })
    }
}

impl FftExecutor<f64> for NeonFcmaRadix10<f64> {
    fn execute(&self, in_place: &mut [Complex<f64>]) -> Result<(), ZaftError> {
        let mut scratch = try_vec![Complex::zero(); self.scratch_length()];
        unsafe { self.execute_f64(in_place, scratch.as_mut_slice()) }
    }

    fn execute_with_scratch(
        &self,
        in_place: &mut [Complex<f64>],
        scratch: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_f64(in_place, scratch) }
    }

    fn execute_out_of_place(
        &self,
        src: &[Complex<f64>],
        dst: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_oof_f64(src, dst) }
    }

    fn execute_out_of_place_with_scratch(
        &self,
        src: &[Complex<f64>],
        dst: &mut [Complex<f64>],
        _: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_oof_f64(src, dst) }
    }

    fn execute_destructive_with_scratch(
        &self,
        src: &mut [Complex<f64>],
        dst: &mut [Complex<f64>],
        scratch: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, scratch)
    }

    fn direction(&self) -> FftDirection {
        self.direction
    }

    #[inline]
    fn length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn scratch_length(&self) -> usize {
        self.execution_length
    }

    fn out_of_place_scratch_length(&self) -> usize {
        0
    }

    fn destructive_scratch_length(&self) -> usize {
        0
    }
}

impl NeonFcmaRadix10<f64> {
    #[target_feature(enable = "fcma")]
    fn base_run(&self, chunk: &mut [Complex<f64>]) {
        unsafe {
            let mut len = self.butterfly_length;

            let mut m_twiddles = self.twiddles.as_slice();

            while len < self.execution_length {
                let columns = len;
                len *= 10;
                let tenth = len / 10;

                for data in chunk.chunks_exact_mut(len) {
                    for j in 0..tenth {
                        let td = 9 * j;
                        let tw0 = vld1q_f64(m_twiddles.get_unchecked(td..).as_ptr().cast());
                        let tw1 = vld1q_f64(m_twiddles.get_unchecked(td + 1..).as_ptr().cast());
                        let tw2 = vld1q_f64(m_twiddles.get_unchecked(td + 2..).as_ptr().cast());
                        let tw3 = vld1q_f64(m_twiddles.get_unchecked(td + 3..).as_ptr().cast());
                        let tw4 = vld1q_f64(m_twiddles.get_unchecked(td + 4..).as_ptr().cast());
                        let tw5 = vld1q_f64(m_twiddles.get_unchecked(td + 5..).as_ptr().cast());
                        let tw6 = vld1q_f64(m_twiddles.get_unchecked(td + 6..).as_ptr().cast());
                        let tw7 = vld1q_f64(m_twiddles.get_unchecked(td + 7..).as_ptr().cast());
                        let tw8 = vld1q_f64(m_twiddles.get_unchecked(td + 8..).as_ptr().cast());

                        let u0 = vld1q_f64(data.get_unchecked(j..).as_ptr().cast());
                        let u1 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + tenth..).as_ptr().cast()),
                            tw0,
                        );
                        let u2 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 2 * tenth..).as_ptr().cast()),
                            tw1,
                        );
                        let u3 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 3 * tenth..).as_ptr().cast()),
                            tw2,
                        );
                        let u4 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 4 * tenth..).as_ptr().cast()),
                            tw3,
                        );
                        let u5 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 5 * tenth..).as_ptr().cast()),
                            tw4,
                        );
                        let u6 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 6 * tenth..).as_ptr().cast()),
                            tw5,
                        );
                        let u7 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 7 * tenth..).as_ptr().cast()),
                            tw6,
                        );
                        let u8 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 8 * tenth..).as_ptr().cast()),
                            tw7,
                        );
                        let u9 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 9 * tenth..).as_ptr().cast()),
                            tw8,
                        );

                        // Radix-10 butterfly

                        let mid0 = self.bf5.exec_fcma(u0, u2, u4, u6, u8);
                        let mid1 = self.bf5.exec_fcma(u5, u7, u9, u1, u3);

                        // Since this is good-thomas algorithm, we don't need twiddle factors
                        let (y0, y5) = NeonButterfly::butterfly2_f64(mid0.0, mid1.0);
                        let (y6, y1) = NeonButterfly::butterfly2_f64(mid0.1, mid1.1);
                        let (y2, y7) = NeonButterfly::butterfly2_f64(mid0.2, mid1.2);
                        let (y8, y3) = NeonButterfly::butterfly2_f64(mid0.3, mid1.3);
                        let (y4, y9) = NeonButterfly::butterfly2_f64(mid0.4, mid1.4);

                        // Store results
                        vst1q_f64(data.get_unchecked_mut(j..).as_mut_ptr().cast(), y0);
                        vst1q_f64(data.get_unchecked_mut(j + tenth..).as_mut_ptr().cast(), y1);
                        vst1q_f64(
                            data.get_unchecked_mut(j + 2 * tenth..).as_mut_ptr().cast(),
                            y2,
                        );
                        vst1q_f64(
                            data.get_unchecked_mut(j + 3 * tenth..).as_mut_ptr().cast(),
                            y3,
                        );
                        vst1q_f64(
                            data.get_unchecked_mut(j + 4 * tenth..).as_mut_ptr().cast(),
                            y4,
                        );
                        vst1q_f64(
                            data.get_unchecked_mut(j + 5 * tenth..).as_mut_ptr().cast(),
                            y5,
                        );
                        vst1q_f64(
                            data.get_unchecked_mut(j + 6 * tenth..).as_mut_ptr().cast(),
                            y6,
                        );
                        vst1q_f64(
                            data.get_unchecked_mut(j + 7 * tenth..).as_mut_ptr().cast(),
                            y7,
                        );
                        vst1q_f64(
                            data.get_unchecked_mut(j + 8 * tenth..).as_mut_ptr().cast(),
                            y8,
                        );
                        vst1q_f64(
                            data.get_unchecked_mut(j + 9 * tenth..).as_mut_ptr().cast(),
                            y9,
                        );
                    }
                }

                m_twiddles = &m_twiddles[columns * 9..];
            }
        }
    }

    #[target_feature(enable = "fcma")]
    fn execute_f64(
        &self,
        in_place: &mut [Complex<f64>],
        scratch: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        if !in_place.len().is_multiple_of(self.execution_length) {
            return Err(ZaftError::InvalidSizeMultiplier(
                in_place.len(),
                self.execution_length,
            ));
        }
        let scratch = validate_scratch!(scratch, self.scratch_length());

        for chunk in in_place.chunks_exact_mut(self.execution_length) {
            // Digit-reversal permutation
            bitreversed_transpose::<Complex<f64>, 10>(self.butterfly_length, chunk, scratch);
            self.butterfly.execute_out_of_place(scratch, chunk)?;
            self.base_run(chunk);
        }
        Ok(())
    }

    #[target_feature(enable = "fcma")]
    fn execute_oof_f64(
        &self,
        src: &[Complex<f64>],
        dst: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        validate_oof_sizes!(src, dst, self.execution_length);

        for (dst, src) in dst
            .chunks_exact_mut(self.execution_length)
            .zip(src.chunks_exact(self.execution_length))
        {
            // Digit-reversal permutation
            bitreversed_transpose::<Complex<f64>, 10>(self.butterfly_length, src, dst);
            self.butterfly.execute(dst)?;
            self.base_run(dst);
        }
        Ok(())
    }
}

impl FftExecutor<f32> for NeonFcmaRadix10<f32> {
    fn execute(&self, in_place: &mut [Complex<f32>]) -> Result<(), ZaftError> {
        let mut scratch = try_vec![Complex::zero(); self.scratch_length()];
        unsafe { self.execute_f32(in_place, scratch.as_mut_slice()) }
    }

    fn execute_with_scratch(
        &self,
        in_place: &mut [Complex<f32>],
        scratch: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_f32(in_place, scratch) }
    }

    fn execute_out_of_place(
        &self,
        src: &[Complex<f32>],
        dst: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_oof_f32(src, dst) }
    }

    fn execute_out_of_place_with_scratch(
        &self,
        src: &[Complex<f32>],
        dst: &mut [Complex<f32>],
        _: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_oof_f32(src, dst) }
    }

    fn execute_destructive_with_scratch(
        &self,
        src: &mut [Complex<f32>],
        dst: &mut [Complex<f32>],
        scratch: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, scratch)
    }

    fn direction(&self) -> FftDirection {
        self.direction
    }

    #[inline]
    fn length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn scratch_length(&self) -> usize {
        self.execution_length
    }

    fn out_of_place_scratch_length(&self) -> usize {
        0
    }

    fn destructive_scratch_length(&self) -> usize {
        0
    }
}

impl NeonFcmaRadix10<f32> {
    #[target_feature(enable = "fcma")]
    fn base_run(&self, chunk: &mut [Complex<f32>]) {
        unsafe {
            let mut len = self.butterfly_length;

            let mut m_twiddles = self.twiddles.as_slice();

            while len < self.execution_length {
                let columns = len;
                len *= 10;
                let tenth = len / 10;

                for data in chunk.chunks_exact_mut(len) {
                    let mut j = 0usize;

                    while j + 2 <= tenth {
                        let u0 = vld1q_f32(data.get_unchecked(j..).as_ptr().cast());

                        let tw = 9 * j;

                        let tw0 = vld1q_f32(m_twiddles.get_unchecked(tw..).as_ptr().cast());
                        let tw1 = vld1q_f32(m_twiddles.get_unchecked(tw + 2..).as_ptr().cast());
                        let tw2 = vld1q_f32(m_twiddles.get_unchecked(tw + 4..).as_ptr().cast());
                        let tw3 = vld1q_f32(m_twiddles.get_unchecked(tw + 6..).as_ptr().cast());
                        let tw4 = vld1q_f32(m_twiddles.get_unchecked(tw + 8..).as_ptr().cast());
                        let tw5 = vld1q_f32(m_twiddles.get_unchecked(tw + 10..).as_ptr().cast());
                        let tw6 = vld1q_f32(m_twiddles.get_unchecked(tw + 12..).as_ptr().cast());
                        let tw7 = vld1q_f32(m_twiddles.get_unchecked(tw + 14..).as_ptr().cast());
                        let tw8 = vld1q_f32(m_twiddles.get_unchecked(tw + 16..).as_ptr().cast());

                        let u1 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + tenth..).as_ptr().cast()),
                            tw0,
                        );
                        let u2 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 2 * tenth..).as_ptr().cast()),
                            tw1,
                        );
                        let u3 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 3 * tenth..).as_ptr().cast()),
                            tw2,
                        );
                        let u4 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 4 * tenth..).as_ptr().cast()),
                            tw3,
                        );
                        let u5 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 5 * tenth..).as_ptr().cast()),
                            tw4,
                        );
                        let u6 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 6 * tenth..).as_ptr().cast()),
                            tw5,
                        );
                        let u7 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 7 * tenth..).as_ptr().cast()),
                            tw6,
                        );
                        let u8 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 8 * tenth..).as_ptr().cast()),
                            tw7,
                        );
                        let u9 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 9 * tenth..).as_ptr().cast()),
                            tw8,
                        );

                        // Radix-10 butterfly

                        let mid0 = self.bf5.exec_fcma(u0, u2, u4, u6, u8);
                        let mid1 = self.bf5.exec_fcma(u5, u7, u9, u1, u3);

                        // Since this is good-thomas algorithm, we don't need twiddle factors
                        let (y0, y5) = NeonButterfly::butterfly2_f32(mid0.0, mid1.0);
                        let (y6, y1) = NeonButterfly::butterfly2_f32(mid0.1, mid1.1);
                        let (y2, y7) = NeonButterfly::butterfly2_f32(mid0.2, mid1.2);
                        let (y8, y3) = NeonButterfly::butterfly2_f32(mid0.3, mid1.3);
                        let (y4, y9) = NeonButterfly::butterfly2_f32(mid0.4, mid1.4);

                        // Store results
                        vst1q_f32(data.get_unchecked_mut(j..).as_mut_ptr().cast(), y0);
                        vst1q_f32(data.get_unchecked_mut(j + tenth..).as_mut_ptr().cast(), y1);
                        vst1q_f32(
                            data.get_unchecked_mut(j + 2 * tenth..).as_mut_ptr().cast(),
                            y2,
                        );
                        vst1q_f32(
                            data.get_unchecked_mut(j + 3 * tenth..).as_mut_ptr().cast(),
                            y3,
                        );
                        vst1q_f32(
                            data.get_unchecked_mut(j + 4 * tenth..).as_mut_ptr().cast(),
                            y4,
                        );
                        vst1q_f32(
                            data.get_unchecked_mut(j + 5 * tenth..).as_mut_ptr().cast(),
                            y5,
                        );
                        vst1q_f32(
                            data.get_unchecked_mut(j + 6 * tenth..).as_mut_ptr().cast(),
                            y6,
                        );
                        vst1q_f32(
                            data.get_unchecked_mut(j + 7 * tenth..).as_mut_ptr().cast(),
                            y7,
                        );
                        vst1q_f32(
                            data.get_unchecked_mut(j + 8 * tenth..).as_mut_ptr().cast(),
                            y8,
                        );
                        vst1q_f32(
                            data.get_unchecked_mut(j + 9 * tenth..).as_mut_ptr().cast(),
                            y9,
                        );

                        j += 2;
                    }

                    for j in j..tenth {
                        let u0 = vld1_f32(data.get_unchecked(j..).as_ptr().cast());

                        let ti = 9 * j;

                        let w0w1 = vld1q_f32(m_twiddles.get_unchecked(ti..).as_ptr().cast());
                        let w2w3 = vld1q_f32(m_twiddles.get_unchecked(ti + 2..).as_ptr().cast());
                        let w4w5 = vld1q_f32(m_twiddles.get_unchecked(ti + 4..).as_ptr().cast());
                        let w6w7 = vld1q_f32(m_twiddles.get_unchecked(ti + 6..).as_ptr().cast());
                        let w8 = vld1_f32(m_twiddles.get_unchecked(ti + 8..).as_ptr().cast());

                        let u1u2 = vfcmulq_fcma_f32(
                            vcombine_f32(
                                vld1_f32(data.get_unchecked(j + tenth..).as_ptr().cast()),
                                vld1_f32(data.get_unchecked(j + 2 * tenth..).as_ptr().cast()),
                            ),
                            w0w1,
                        );
                        let u3u4 = vfcmulq_fcma_f32(
                            vcombine_f32(
                                vld1_f32(data.get_unchecked(j + 3 * tenth..).as_ptr().cast()),
                                vld1_f32(data.get_unchecked(j + 4 * tenth..).as_ptr().cast()),
                            ),
                            w2w3,
                        );
                        let u5u6 = vfcmulq_fcma_f32(
                            vcombine_f32(
                                vld1_f32(data.get_unchecked(j + 5 * tenth..).as_ptr().cast()),
                                vld1_f32(data.get_unchecked(j + 6 * tenth..).as_ptr().cast()),
                            ),
                            w4w5,
                        );
                        let u7u8 = vfcmulq_fcma_f32(
                            vcombine_f32(
                                vld1_f32(data.get_unchecked(j + 7 * tenth..).as_ptr().cast()),
                                vld1_f32(data.get_unchecked(j + 8 * tenth..).as_ptr().cast()),
                            ),
                            w6w7,
                        );
                        let u9 = vfcmul_fcma_f32(
                            vld1_f32(data.get_unchecked(j + 9 * tenth..).as_ptr().cast()),
                            w8,
                        );

                        let u1 = vget_low_f32(u1u2);
                        let u2 = vget_high_f32(u1u2);
                        let u3 = vget_low_f32(u3u4);
                        let u4 = vget_high_f32(u3u4);
                        let u5 = vget_low_f32(u5u6);
                        let u6 = vget_high_f32(u5u6);
                        let u7 = vget_low_f32(u7u8);
                        let u8 = vget_high_f32(u7u8);

                        // Radix-10 butterfly

                        let mid0 = self.bf5.exec_fcma(
                            vcombine_f32(u0, u5),
                            vcombine_f32(u2, u7),
                            vcombine_f32(u4, u9),
                            vcombine_f32(u6, u1),
                            vcombine_f32(u8, u3),
                        );

                        // Since this is good-thomas algorithm, we don't need twiddle factors
                        let (y0, y5) = NeonButterfly::butterfly2h_f32(
                            vget_low_f32(mid0.0),
                            vget_high_f32(mid0.0),
                        );
                        let (y6, y1) = NeonButterfly::butterfly2h_f32(
                            vget_low_f32(mid0.1),
                            vget_high_f32(mid0.1),
                        );
                        let (y2, y7) = NeonButterfly::butterfly2h_f32(
                            vget_low_f32(mid0.2),
                            vget_high_f32(mid0.2),
                        );
                        let (y8, y3) = NeonButterfly::butterfly2h_f32(
                            vget_low_f32(mid0.3),
                            vget_high_f32(mid0.3),
                        );
                        let (y4, y9) = NeonButterfly::butterfly2h_f32(
                            vget_low_f32(mid0.4),
                            vget_high_f32(mid0.4),
                        );

                        // Store results
                        vst1_f32(data.get_unchecked_mut(j..).as_mut_ptr().cast(), y0);
                        vst1_f32(data.get_unchecked_mut(j + tenth..).as_mut_ptr().cast(), y1);
                        vst1_f32(
                            data.get_unchecked_mut(j + 2 * tenth..).as_mut_ptr().cast(),
                            y2,
                        );
                        vst1_f32(
                            data.get_unchecked_mut(j + 3 * tenth..).as_mut_ptr().cast(),
                            y3,
                        );
                        vst1_f32(
                            data.get_unchecked_mut(j + 4 * tenth..).as_mut_ptr().cast(),
                            y4,
                        );
                        vst1_f32(
                            data.get_unchecked_mut(j + 5 * tenth..).as_mut_ptr().cast(),
                            y5,
                        );
                        vst1_f32(
                            data.get_unchecked_mut(j + 6 * tenth..).as_mut_ptr().cast(),
                            y6,
                        );
                        vst1_f32(
                            data.get_unchecked_mut(j + 7 * tenth..).as_mut_ptr().cast(),
                            y7,
                        );
                        vst1_f32(
                            data.get_unchecked_mut(j + 8 * tenth..).as_mut_ptr().cast(),
                            y8,
                        );
                        vst1_f32(
                            data.get_unchecked_mut(j + 9 * tenth..).as_mut_ptr().cast(),
                            y9,
                        );
                    }
                }

                m_twiddles = &m_twiddles[columns * 9..];
            }
        }
    }

    #[target_feature(enable = "fcma")]
    fn execute_f32(
        &self,
        in_place: &mut [Complex<f32>],
        scratch: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        if !in_place.len().is_multiple_of(self.execution_length) {
            return Err(ZaftError::InvalidSizeMultiplier(
                in_place.len(),
                self.execution_length,
            ));
        }

        let scratch = validate_scratch!(scratch, self.scratch_length());

        for chunk in in_place.chunks_exact_mut(self.execution_length) {
            // Digit-reversal permutation
            neon_bitreversed_transpose_f32_radix10(self.butterfly_length, chunk, scratch);

            self.butterfly.execute_out_of_place(scratch, chunk)?;
            self.base_run(chunk);
        }
        Ok(())
    }

    #[target_feature(enable = "fcma")]
    fn execute_oof_f32(
        &self,
        src: &[Complex<f32>],
        dst: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        validate_oof_sizes!(src, dst, self.execution_length);

        for (dst, src) in dst
            .chunks_exact_mut(self.execution_length)
            .zip(src.chunks_exact(self.execution_length))
        {
            // Digit-reversal permutation
            neon_bitreversed_transpose_f32_radix10(self.butterfly_length, src, dst);
            self.butterfly.execute(dst)?;
            self.base_run(dst);
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::neon::test_fcma_radix;

    test_fcma_radix!(test_neon_radix10, f32, NeonFcmaRadix10, 4, 10, 1e-3);
    test_fcma_radix!(test_neon_radix10_f64, f64, NeonFcmaRadix10, 4, 10, 1e-8);
}
