/*
 * // Copyright (c) Radzivon Bartoshyk 9/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#![allow(clippy::modulo_one)]
use crate::err::try_vec;
use crate::neon::mixed::bf2::{ColumnButterfly2d, ColumnButterfly2f};
use crate::neon::mixed::bf3::*;
use crate::neon::mixed::bf4::{ColumnButterfly4d, ColumnButterfly4f};
use crate::neon::mixed::neon_store::{NeonStoreD, NeonStoreF};
use crate::transpose::{TransposeExecutor, TransposeFactory};
use crate::util::compute_twiddle;
use crate::{FftDirection, FftExecutor, ZaftError};
use num_complex::Complex;
use num_traits::Zero;
use std::sync::Arc;

macro_rules! define_mixed_radix_neon_d {
    ($radix_name: ident, $features: literal, $bf_name: ident, $row_count: expr, $mul: ident) => {
        pub(crate) struct $radix_name {
            execution_length: usize,
            direction: FftDirection,
            twiddles: Vec<NeonStoreD>,
            width_executor: Arc<dyn FftExecutor<f64> + Send + Sync>,
            width: usize,
            height: usize,
            transpose_executor: Box<dyn TransposeExecutor<f64> + Send + Sync>,
            inner_bf: $bf_name,
            width_scratch_length: usize,
            oof_width_scratch_length: usize,
        }

        impl $radix_name {
            pub(crate) fn new(
                width_executor: Arc<dyn FftExecutor<f64> + Send + Sync>,
            ) -> Result<Self, ZaftError> {
                let direction = width_executor.direction();

                let width = width_executor.length();

                const ROW_COUNT: usize = $row_count;
                const TWIDDLES_PER_COLUMN: usize = ROW_COUNT - 1;

                let len_per_row = width_executor.length();

                let len = len_per_row * ROW_COUNT;
                const COMPLEX_PER_VECTOR: usize = 1;

                let quotient = len_per_row / COMPLEX_PER_VECTOR;
                #[allow(clippy::modulo_one)]
                let remainder = len_per_row % COMPLEX_PER_VECTOR;

                let num_twiddle_columns = quotient + remainder.div_ceil(COMPLEX_PER_VECTOR);
                let mut twiddles = Vec::new();
                twiddles
                    .try_reserve_exact(num_twiddle_columns * TWIDDLES_PER_COLUMN)
                    .map_err(|_| {
                        ZaftError::OutOfMemory(num_twiddle_columns * TWIDDLES_PER_COLUMN)
                    })?;
                for x in 0..num_twiddle_columns {
                    for y in 1..ROW_COUNT {
                        let mut data: [Complex<f64>; COMPLEX_PER_VECTOR] =
                            [Complex::zero(); COMPLEX_PER_VECTOR];
                        for i in 0..COMPLEX_PER_VECTOR {
                            data[i] =
                                compute_twiddle(y * (x * COMPLEX_PER_VECTOR + i), len, direction);
                        }
                        twiddles.push(NeonStoreD::from_complex_ref(data.as_ref()));
                    }
                }

                let width_scratch_length = width_executor.out_of_place_scratch_length();
                let execution_length = width * ROW_COUNT;
                let oof_width_scratch_length = if execution_length >= width_executor.scratch_length() {
                    0
                } else {
                    width_executor.scratch_length()
                };

                Ok($radix_name {
                    execution_length,
                    width_executor,
                    width,
                    height: ROW_COUNT,
                    direction,
                    twiddles,
                    transpose_executor: f64::transpose_strategy(width, ROW_COUNT),
                    inner_bf: $bf_name::new(direction),
                    width_scratch_length,
                    oof_width_scratch_length,
                })
            }
        }

        impl FftExecutor<f64> for $radix_name {
            fn execute(&self, in_place: &mut [Complex<f64>]) -> Result<(), ZaftError> {
                let mut scratch = try_vec![Complex::zero(); self.scratch_length()];
                unsafe { self.execute_impl(in_place, scratch.as_mut_slice()) }
            }

            fn execute_with_scratch(
                &self,
                in_place: &mut [Complex<f64>],
                scratch: &mut [Complex<f64>],
            ) -> Result<(), ZaftError> {
                unsafe { self.execute_impl(in_place, scratch) }
            }

            fn execute_out_of_place(
                &self,
                src: &[Complex<f64>],
                dst: &mut [Complex<f64>],
            ) -> Result<(), ZaftError> {
                let mut scratch = try_vec![Complex::zero(); self.out_of_place_scratch_length()];
                self.execute_out_of_place_with_scratch(src, dst, scratch.as_mut_slice())
            }

            fn execute_out_of_place_with_scratch(
                &self,
                src: &[Complex<f64>],
                dst: &mut [Complex<f64>],
                scratch: &mut [Complex<f64>],
            ) -> Result<(), ZaftError> {
                unsafe { self.execute_oof_impl(src, dst, scratch) }
            }

            fn execute_destructive_with_scratch(
                &self,
                src: &mut [Complex<f64>],
                dst: &mut [Complex<f64>],
                scratch: &mut [Complex<f64>],
            ) -> Result<(), ZaftError> {
                unsafe { self.execute_d_oof_impl(src, dst, scratch) }
            }

            fn direction(&self) -> FftDirection {
                self.direction
            }

            #[inline]
            fn length(&self) -> usize {
                self.execution_length
            }

            #[inline]
            fn scratch_length(&self) -> usize {
                self.execution_length + self.width_scratch_length
            }

            #[inline]
            fn out_of_place_scratch_length(&self) -> usize {
                self.execution_length + self.oof_width_scratch_length
            }

            #[inline]
            fn destructive_scratch_length(&self) -> usize {
                self.oof_width_scratch_length
            }
        }

        impl $radix_name {
            #[target_feature(enable = $features)]
            fn execute_impl(
                &self,
                in_place: &mut [Complex<f64>],
                scratch: &mut [Complex<f64>],
            ) -> Result<(), ZaftError> {
                if !in_place.len().is_multiple_of(self.execution_length) {
                    return Err(ZaftError::InvalidSizeMultiplier(
                        in_place.len(),
                        self.execution_length,
                    ));
                }

                use crate::util::validate_scratch;
                let scratch = validate_scratch!(scratch, self.scratch_length());
                let (scratch, width_scratch) = scratch.split_at_mut(self.execution_length);

                for chunk in in_place.chunks_exact_mut(self.execution_length) {
                    self.process_columns_in_place(chunk);

                    self.width_executor.execute_destructive_with_scratch(
                        chunk,
                        scratch,
                        width_scratch,
                    )?;

                    self.transpose_executor
                        .transpose(&scratch, chunk, self.width, self.height);
                }
                Ok(())
            }

            #[target_feature(enable = $features)]
            fn process_columns_in_place(&self, chunk: &mut [Complex<f64>]) {
                const ROW_COUNT: usize = $row_count;
                const TWIDDLES_PER_COLUMN: usize = ROW_COUNT - 1;
                const COMPLEX_PER_VECTOR: usize = 1;

                let len_per_row = self.length() / ROW_COUNT;
                let chunk_count = len_per_row / COMPLEX_PER_VECTOR;
                // process the column FFTs
                for (c, twiddle_chunk) in self
                    .twiddles
                    .chunks_exact(TWIDDLES_PER_COLUMN)
                    .take(chunk_count)
                    .enumerate()
                {
                    let index_base = c * COMPLEX_PER_VECTOR;

                    let mut columns = [NeonStoreD::default(); ROW_COUNT];
                    for i in 0..ROW_COUNT {
                        unsafe {
                            columns[i] = NeonStoreD::from_complex_ref(
                                chunk.get_unchecked(index_base + len_per_row * i..),
                            );
                        }
                    }

                    let output = self.inner_bf.exec(columns);

                    unsafe {
                        output[0].write(chunk.get_unchecked_mut(index_base..));
                    }

                    // here LLVM doesn't "see" NeonStoreD as the same type returned by output
                    // so we need to force cast it onwards to the same type
                    let mut twiddles = [NeonStoreD::default(); ROW_COUNT - 1];
                    for i in 0..ROW_COUNT - 1 {
                        twiddles[i] = twiddle_chunk[i];
                    }

                    for i in 1..ROW_COUNT {
                        let twiddle = twiddles[i - 1];
                        let output = NeonStoreD::$mul(output[i], twiddle);
                        unsafe {
                            output.write(chunk.get_unchecked_mut(index_base + len_per_row * i..))
                        }
                    }
                }
            }

            #[target_feature(enable = $features)]
            fn execute_d_oof_impl(
                &self,
                src: &mut [Complex<f64>],
                dst: &mut [Complex<f64>],
                scratch: &mut [Complex<f64>],
            ) -> Result<(), ZaftError> {
                use crate::util::validate_oof_sizes;
                validate_oof_sizes!(src, dst, self.execution_length);

                use crate::util::validate_scratch;
                let scratch = validate_scratch!(scratch, self.destructive_scratch_length());
                let use_dst_as_scratch = self.execution_length >= self.oof_width_scratch_length;

                for (dst_chunk, src_chunk) in dst
                    .chunks_exact_mut(self.execution_length)
                    .zip(src.chunks_exact_mut(self.execution_length))
                {
                    self.process_columns_in_place(src_chunk);

                    self.width_executor
                        .execute_with_scratch(src_chunk, if use_dst_as_scratch { dst_chunk } else { scratch })?;

                    self.transpose_executor.transpose(
                        src_chunk,
                        dst_chunk,
                        self.width,
                        self.height,
                    );
                }
                Ok(())
            }

            #[target_feature(enable = $features)]
            fn process_oof_columns(&self, chunk: &[Complex<f64>], scratch: &mut [Complex<f64>]) {
                const ROW_COUNT: usize = $row_count;
                const TWIDDLES_PER_COLUMN: usize = ROW_COUNT - 1;
                const COMPLEX_PER_VECTOR: usize = 1;

                let len_per_row = self.length() / ROW_COUNT;
                let chunk_count = len_per_row / COMPLEX_PER_VECTOR;

                // process the column FFTs
                for (c, twiddle_chunk) in self
                    .twiddles
                    .as_chunks::<TWIDDLES_PER_COLUMN>().0.iter()
                    .take(chunk_count)
                    .enumerate()
                {
                    let index_base = c * COMPLEX_PER_VECTOR;

                    let mut columns = [NeonStoreD::default(); ROW_COUNT];
                    for i in 0..ROW_COUNT {
                        unsafe {
                            columns[i] = NeonStoreD::from_complex_ref(
                                chunk.get_unchecked(index_base + len_per_row * i..),
                            );
                        }
                    }

                    let output = self.inner_bf.exec(columns);

                    unsafe {
                        output[0].write(scratch.get_unchecked_mut(index_base..));
                    }

                    // here LLVM doesn't "see" NeonStoreD as the same type returned by output
                    // so we need to force cast it onwards to the same type
                    let mut twiddles = [NeonStoreD::default(); ROW_COUNT - 1];
                    for i in 0..ROW_COUNT - 1 {
                        twiddles[i] = twiddle_chunk[i];
                    }

                    for i in 1..ROW_COUNT {
                        let twiddle = twiddles[i - 1];
                        let output = NeonStoreD::$mul(output[i], twiddle);
                        unsafe {
                            output.write(scratch.get_unchecked_mut(index_base + len_per_row * i..))
                        }
                    }
                }
            }

            #[target_feature(enable = $features)]
            fn execute_oof_impl(
                &self,
                src: &[Complex<f64>],
                dst: &mut [Complex<f64>],
                scratch: &mut [Complex<f64>],
            ) -> Result<(), ZaftError> {
                use crate::util::validate_oof_sizes;
                validate_oof_sizes!(src, dst, self.execution_length);

                use crate::util::validate_scratch;
                let scratch = validate_scratch!(scratch, self.out_of_place_scratch_length());
                let (scratch, width_scratch) = scratch.split_at_mut(self.execution_length);
                let use_dst_as_scratch = self.execution_length >= self.oof_width_scratch_length;

                for (dst_chunk, chunk) in dst
                    .chunks_exact_mut(self.execution_length)
                    .zip(src.chunks_exact(self.execution_length))
                {
                    self.process_oof_columns(chunk, scratch);

                    self.width_executor
                        .execute_with_scratch(scratch, if use_dst_as_scratch { dst_chunk } else { width_scratch })?;

                    self.transpose_executor
                        .transpose(&scratch, dst_chunk, self.width, self.height);
                }
                Ok(())
            }
        }
    };
}

macro_rules! define_mixed_radix_neon_f {
    ($radix_name: ident, $features: literal, $bf_name: ident, $row_count: expr, $mul: ident) => {
        pub(crate) struct $radix_name {
            execution_length: usize,
            direction: FftDirection,
            twiddles: Vec<NeonStoreF>,
            width_executor: Arc<dyn FftExecutor<f32> + Send + Sync>,
            width: usize,
            height: usize,
            transpose_executor: Box<dyn TransposeExecutor<f32> + Send + Sync>,
            inner_bf: $bf_name,
            width_scratch_length: usize,
            oof_width_scratch_length: usize,
        }

        impl $radix_name {
            pub(crate) fn new(
                width_executor: Arc<dyn FftExecutor<f32> + Send + Sync>,
            ) -> Result<Self, ZaftError> {
                let direction = width_executor.direction();

                let width = width_executor.length();

                const ROW_COUNT: usize = $row_count;
                const TWIDDLES_PER_COLUMN: usize = ROW_COUNT - 1;

                // derive some info from our inner FFT
                let len_per_row = width_executor.length();

                let len = len_per_row * ROW_COUNT;
                const COMPLEX_PER_VECTOR: usize = 2;

                let quotient = len_per_row / COMPLEX_PER_VECTOR;
                let remainder = len_per_row % COMPLEX_PER_VECTOR;

                let num_twiddle_columns = quotient + remainder.div_ceil(COMPLEX_PER_VECTOR);
                let mut twiddles = Vec::new();
                twiddles
                    .try_reserve_exact(num_twiddle_columns * TWIDDLES_PER_COLUMN)
                    .map_err(|_| {
                        ZaftError::OutOfMemory(num_twiddle_columns * TWIDDLES_PER_COLUMN)
                    })?;
                for x in 0..num_twiddle_columns {
                    for y in 1..ROW_COUNT {
                        let mut data: [Complex<f32>; COMPLEX_PER_VECTOR] =
                            [Complex::zero(); COMPLEX_PER_VECTOR];
                        for i in 0..COMPLEX_PER_VECTOR {
                            data[i] =
                                compute_twiddle(y * (x * COMPLEX_PER_VECTOR + i), len, direction);
                        }
                        twiddles.push(NeonStoreF::from_complex_ref(data.as_ref()));
                    }
                }

                let width_scratch_length = width_executor.destructive_scratch_length();
                let execution_length = width * ROW_COUNT;
                let oof_width_scratch_length = if execution_length >= width_executor.scratch_length() {
                    0
                } else {
                    width_executor.scratch_length()
                };

                Ok($radix_name {
                    execution_length,
                    width_executor,
                    width,
                    height: ROW_COUNT,
                    direction,
                    twiddles,
                    transpose_executor: f32::transpose_strategy(width, ROW_COUNT),
                    inner_bf: $bf_name::new(direction),
                    width_scratch_length,
                    oof_width_scratch_length,
                })
            }
        }

        impl FftExecutor<f32> for $radix_name {
            fn execute(&self, in_place: &mut [Complex<f32>]) -> Result<(), ZaftError> {
                let mut scratch = try_vec![Complex::zero(); self.scratch_length()];
                unsafe { self.execute_impl(in_place, scratch.as_mut_slice()) }
            }

            fn execute_with_scratch(
                &self,
                in_place: &mut [Complex<f32>],
                scratch: &mut [Complex<f32>],
            ) -> Result<(), ZaftError> {
                unsafe { self.execute_impl(in_place, scratch) }
            }

            fn execute_out_of_place(
                &self,
                src: &[Complex<f32>],
                dst: &mut [Complex<f32>],
            ) -> Result<(), ZaftError> {
                let mut scratch = try_vec![Complex::zero(); self.out_of_place_scratch_length()];
                self.execute_out_of_place_with_scratch(src, dst, scratch.as_mut_slice())
            }

            fn execute_out_of_place_with_scratch(
                &self,
                src: &[Complex<f32>],
                dst: &mut [Complex<f32>],
                scratch: &mut [Complex<f32>],
            ) -> Result<(), ZaftError> {
                unsafe { self.execute_oof_impl(src, dst, scratch) }
            }

            fn execute_destructive_with_scratch(
                &self,
                src: &mut [Complex<f32>],
                dst: &mut [Complex<f32>],
                scratch: &mut [Complex<f32>],
            ) -> Result<(), ZaftError> {
                unsafe { self.execute_d_oof_impl(src, dst, scratch) }
            }

            fn direction(&self) -> FftDirection {
                self.direction
            }

            #[inline]
            fn length(&self) -> usize {
                self.execution_length
            }

            #[inline]
            fn scratch_length(&self) -> usize {
                self.execution_length + self.width_scratch_length
            }

            #[inline]
            fn out_of_place_scratch_length(&self) -> usize {
                self.execution_length + self.oof_width_scratch_length
            }

            #[inline]
            fn destructive_scratch_length(&self) -> usize {
                self.oof_width_scratch_length
            }
        }

        impl $radix_name {
            #[target_feature(enable = $features)]
            fn execute_impl(
                &self,
                in_place: &mut [Complex<f32>],
                scratch: &mut [Complex<f32>],
            ) -> Result<(), ZaftError> {
                if !in_place.len().is_multiple_of(self.execution_length) {
                    return Err(ZaftError::InvalidSizeMultiplier(
                        in_place.len(),
                        self.execution_length,
                    ));
                }

                use crate::util::validate_scratch;
                let scratch = validate_scratch!(scratch, self.scratch_length());
                let (scratch, width_scratch) = scratch.split_at_mut(self.execution_length);

                for chunk in in_place.chunks_exact_mut(self.execution_length) {
                    self.process_columns_in_place(chunk);

                    self.width_executor.execute_destructive_with_scratch(
                        chunk,
                        scratch,
                        width_scratch,
                    )?;

                    self.transpose_executor
                        .transpose(&scratch, chunk, self.width, self.height);
                }
                Ok(())
            }

            #[target_feature(enable = $features)]
            fn process_columns_in_place(&self, chunk: &mut [Complex<f32>]) {
                const ROW_COUNT: usize = $row_count;
                const TWIDDLES_PER_COLUMN: usize = ROW_COUNT - 1;
                const COMPLEX_PER_VECTOR: usize = 2;

                let len_per_row = self.length() / ROW_COUNT;
                let chunk_count = len_per_row / COMPLEX_PER_VECTOR;

                for (c, twiddle_chunk) in self
                    .twiddles
                    .as_chunks::<TWIDDLES_PER_COLUMN>().0.iter()
                    .take(chunk_count)
                    .enumerate()
                {
                    let index_base = c * COMPLEX_PER_VECTOR;

                    // Load columns from the input into registers
                    let mut columns = [NeonStoreF::default(); ROW_COUNT];
                    for i in 0..ROW_COUNT {
                        unsafe {
                            columns[i] = NeonStoreF::from_complex_ref(
                                chunk.get_unchecked(index_base + len_per_row * i..),
                            );
                        }
                    }

                    let output = self.inner_bf.exec(columns);

                    unsafe {
                        output[0].write(chunk.get_unchecked_mut(index_base..));
                    }

                    // here LLVM doesn't "see" NeonStoreF as the same type returned by output
                    // so we need to force cast it onwards to the same type
                    let mut twiddles = [NeonStoreF::default(); ROW_COUNT - 1];
                    for i in 0..ROW_COUNT - 1 {
                        twiddles[i] = twiddle_chunk[i];
                    }

                    for i in 1..ROW_COUNT {
                        let twiddle = twiddles[i - 1];
                        let output = NeonStoreF::$mul(output[i], twiddle);
                        unsafe {
                            output.write(chunk.get_unchecked_mut(index_base + len_per_row * i..))
                        }
                    }
                }

                let partial_remainder = len_per_row % COMPLEX_PER_VECTOR;
                if partial_remainder > 0 {
                    let partial_remainder_base = chunk_count * COMPLEX_PER_VECTOR;
                    let partial_remainder_twiddle_base = self.twiddles.len() - TWIDDLES_PER_COLUMN;
                    let final_twiddle_chunk = &self.twiddles[partial_remainder_twiddle_base..];

                    let mut columns = [NeonStoreF::default(); ROW_COUNT];
                    for i in 0..ROW_COUNT {
                        unsafe {
                            columns[i] = NeonStoreF::load_complex(
                                chunk.get_unchecked(partial_remainder_base + len_per_row * i),
                            );
                        }
                    }

                    // apply our butterfly function down the columns
                    let output = self.inner_bf.exec(columns);

                    // always write the first row without twiddles
                    unsafe {
                        output[0].write_lo(chunk.get_unchecked_mut(partial_remainder_base..));
                    }

                    // here LLVM doesn't "see" NeonStoreFh as the same type returned by output
                    // so we need to force cast it onwards to the same type
                    let mut twiddles = [NeonStoreF::default(); ROW_COUNT - 1];
                    for i in 0..ROW_COUNT - 1 {
                        twiddles[i] = final_twiddle_chunk[i];
                    }

                    // for the remaining rows, apply twiddle factors and then write back to memory
                    for i in 1..ROW_COUNT {
                        let twiddle = twiddles[i - 1];
                        let output = NeonStoreF::$mul(output[i], twiddle);
                        unsafe {
                            output.write_lo(
                                chunk.get_unchecked_mut(partial_remainder_base + len_per_row * i..),
                            );
                        }
                    }
                }
            }

            #[target_feature(enable = $features)]
            fn execute_d_oof_impl(
                &self,
                src: &mut [Complex<f32>],
                dst: &mut [Complex<f32>],
                scratch: &mut [Complex<f32>],
            ) -> Result<(), ZaftError> {
                use crate::util::validate_oof_sizes;
                validate_oof_sizes!(src, dst, self.execution_length);

                use crate::util::validate_scratch;
                let scratch = validate_scratch!(scratch, self.destructive_scratch_length());
                let use_dst_as_scratch = self.execution_length >= self.oof_width_scratch_length;

                for (dst_chunk, src_chunk) in dst
                    .chunks_exact_mut(self.execution_length)
                    .zip(src.chunks_exact_mut(self.execution_length))
                {
                    self.process_columns_in_place(src_chunk);

                    self.width_executor
                        .execute_with_scratch(src_chunk, if use_dst_as_scratch { dst_chunk } else { scratch })?;

                    self.transpose_executor.transpose(
                        src_chunk,
                        dst_chunk,
                        self.width,
                        self.height,
                    );
                }
                Ok(())
            }

            #[target_feature(enable = $features)]
            fn process_oof_columns(&self, chunk: &[Complex<f32>], scratch: &mut [Complex<f32>]) {
                const ROW_COUNT: usize = $row_count;
                const TWIDDLES_PER_COLUMN: usize = ROW_COUNT - 1;
                const COMPLEX_PER_VECTOR: usize = 2;

                let len_per_row = self.length() / ROW_COUNT;
                let chunk_count = len_per_row / COMPLEX_PER_VECTOR;
                for (c, twiddle_chunk) in self
                    .twiddles
                    .chunks_exact(TWIDDLES_PER_COLUMN)
                    .take(chunk_count)
                    .enumerate()
                {
                    let index_base = c * COMPLEX_PER_VECTOR;

                    // Load columns from the input into registers
                    let mut columns = [NeonStoreF::default(); ROW_COUNT];
                    for i in 0..ROW_COUNT {
                        unsafe {
                            columns[i] = NeonStoreF::from_complex_ref(
                                chunk.get_unchecked(index_base + len_per_row * i..),
                            );
                        }
                    }

                    let output = self.inner_bf.exec(columns);

                    unsafe {
                        output[0].write(scratch.get_unchecked_mut(index_base..));
                    }

                    // here LLVM doesn't "see" NeonStoreF as the same type returned by output
                    // so we need to force cast it onwards to the same type
                    let mut twiddles = [NeonStoreF::default(); ROW_COUNT - 1];
                    for i in 0..ROW_COUNT - 1 {
                        twiddles[i] = twiddle_chunk[i];
                    }

                    for i in 1..ROW_COUNT {
                        let twiddle = twiddles[i - 1];
                        let output = NeonStoreF::$mul(output[i], twiddle);
                        unsafe {
                            output.write(scratch.get_unchecked_mut(index_base + len_per_row * i..))
                        }
                    }
                }

                let partial_remainder = len_per_row % COMPLEX_PER_VECTOR;
                if partial_remainder > 0 {
                    let partial_remainder_base = chunk_count * COMPLEX_PER_VECTOR;
                    let partial_remainder_twiddle_base = self.twiddles.len() - TWIDDLES_PER_COLUMN;
                    let final_twiddle_chunk = &self.twiddles[partial_remainder_twiddle_base..];

                    let mut columns = [NeonStoreF::default(); ROW_COUNT];
                    for i in 0..ROW_COUNT {
                        unsafe {
                            columns[i] = NeonStoreF::load_complex(
                                chunk.get_unchecked(partial_remainder_base + len_per_row * i),
                            );
                        }
                    }

                    // apply our butterfly function down the columns
                    let output = self.inner_bf.exec(columns);

                    // always write the first row without twiddles
                    unsafe {
                        output[0].write_lo(scratch.get_unchecked_mut(partial_remainder_base..));
                    }

                    // here LLVM doesn't "see" NeonStoreFh as the same type returned by output
                    // so we need to force cast it onwards to the same type
                    let mut twiddles = [NeonStoreF::default(); ROW_COUNT - 1];
                    for i in 0..ROW_COUNT - 1 {
                        twiddles[i] = final_twiddle_chunk[i];
                    }

                    // for the remaining rows, apply twiddle factors and then write back to memory
                    for i in 1..ROW_COUNT {
                        let twiddle = twiddles[i - 1];
                        let output = NeonStoreF::$mul(output[i], twiddle);
                        unsafe {
                            output.write_lo(
                                scratch
                                    .get_unchecked_mut(partial_remainder_base + len_per_row * i..),
                            );
                        }
                    }
                }
            }

            #[target_feature(enable = $features)]
            fn execute_oof_impl(
                &self,
                src: &[Complex<f32>],
                dst: &mut [Complex<f32>],
                scratch: &mut [Complex<f32>],
            ) -> Result<(), ZaftError> {
                use crate::util::validate_oof_sizes;
                validate_oof_sizes!(src, dst, self.execution_length);

                use crate::util::validate_scratch;
                let scratch = validate_scratch!(scratch, self.out_of_place_scratch_length());
                let (scratch, width_scratch) = scratch.split_at_mut(self.execution_length);
                let use_dst_as_scratch = self.execution_length >= self.oof_width_scratch_length;

                for (dst_chunk, chunk) in dst
                    .chunks_exact_mut(self.execution_length)
                    .zip(src.chunks_exact(self.execution_length))
                {
                    self.process_oof_columns(chunk, scratch);

                    self.width_executor
                        .execute_with_scratch(scratch, if use_dst_as_scratch { dst_chunk } else { width_scratch })?;

                    self.transpose_executor
                        .transpose(&scratch, dst_chunk, self.width, self.height);
                }
                Ok(())
            }
        }
    };
}

use crate::neon::mixed::bf5::*;
use crate::neon::mixed::bf6::*;
use crate::neon::mixed::bf7::*;
use crate::neon::mixed::bf8::*;
use crate::neon::mixed::bf9::*;
use crate::neon::mixed::bf10::*;
use crate::neon::mixed::bf11::*;
use crate::neon::mixed::bf12::*;
use crate::neon::mixed::bf13::*;

define_mixed_radix_neon_d!(
    NeonMixedRadix2,
    "neon",
    ColumnButterfly2d,
    2,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix3,
    "neon",
    ColumnButterfly3d,
    3,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix4,
    "neon",
    ColumnButterfly4d,
    4,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix5,
    "neon",
    ColumnButterfly5d,
    5,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix6,
    "neon",
    ColumnButterfly6d,
    6,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix7,
    "neon",
    ColumnButterfly7d,
    7,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix8,
    "neon",
    ColumnButterfly8d,
    8,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix9,
    "neon",
    ColumnButterfly9d,
    9,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix10,
    "neon",
    ColumnButterfly10d,
    10,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix11,
    "neon",
    ColumnButterfly11d,
    11,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix12,
    "neon",
    ColumnButterfly12d,
    12,
    mul_by_complex
);
define_mixed_radix_neon_d!(
    NeonMixedRadix13,
    "neon",
    ColumnButterfly13d,
    13,
    mul_by_complex
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix2,
    "fcma",
    ColumnButterfly2d,
    2,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix3,
    "fcma",
    ColumnFcmaButterfly3d,
    3,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
use crate::neon::mixed::bf4::{
    ColumnFcmaButterfly4d, ColumnFcmaForwardButterfly4f, ColumnFcmaInverseButterfly4f,
};

#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix4,
    "fcma",
    ColumnFcmaButterfly4d,
    4,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix5,
    "fcma",
    ColumnFcmaButterfly5d,
    5,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix6,
    "fcma",
    ColumnFcmaButterfly6d,
    6,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix7,
    "fcma",
    ColumnFcmaButterfly7d,
    7,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix8,
    "fcma",
    ColumnFcmaButterfly8d,
    8,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix9,
    "fcma",
    ColumnFcmaButterfly9d,
    9,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix10,
    "fcma",
    ColumnFcmaButterfly10d,
    10,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix11,
    "fcma",
    ColumnFcmaButterfly11d,
    11,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix12,
    "fcma",
    ColumnFcmaButterfly12d,
    12,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_d!(
    NeonFcmaMixedRadix13,
    "fcma",
    ColumnFcmaButterfly13d,
    13,
    fcmul_fcma
);
define_mixed_radix_neon_f!(
    NeonMixedRadix2f,
    "neon",
    ColumnButterfly2f,
    2,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix3f,
    "neon",
    ColumnButterfly3f,
    3,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix4f,
    "neon",
    ColumnButterfly4f,
    4,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix5f,
    "neon",
    ColumnButterfly5f,
    5,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix6f,
    "neon",
    ColumnButterfly6f,
    6,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix7f,
    "neon",
    ColumnButterfly7f,
    7,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix8f,
    "neon",
    ColumnButterfly8f,
    8,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix9f,
    "neon",
    ColumnButterfly9f,
    9,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix10f,
    "neon",
    ColumnButterfly10f,
    10,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix11f,
    "neon",
    ColumnButterfly11f,
    11,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix12f,
    "neon",
    ColumnButterfly12f,
    12,
    mul_by_complex
);
define_mixed_radix_neon_f!(
    NeonMixedRadix13f,
    "neon",
    ColumnButterfly13f,
    13,
    mul_by_complex
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix2f,
    "fcma",
    ColumnButterfly2f,
    2,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix3f,
    "fcma",
    ColumnFcmaButterfly3f,
    3,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaForwardMixedRadix4f,
    "fcma",
    ColumnFcmaForwardButterfly4f,
    4,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaInverseMixedRadix4f,
    "fcma",
    ColumnFcmaInverseButterfly4f,
    4,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix5f,
    "fcma",
    ColumnFcmaButterfly5f,
    5,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix6f,
    "fcma",
    ColumnFcmaButterfly6f,
    6,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix7f,
    "fcma",
    ColumnFcmaButterfly7f,
    7,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaInverseMixedRadix8f,
    "fcma",
    ColumnFcmaInverseButterfly8f,
    8,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaForwardMixedRadix8f,
    "fcma",
    ColumnFcmaForwardButterfly8f,
    8,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix9f,
    "fcma",
    ColumnFcmaButterfly9f,
    9,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix10f,
    "fcma",
    ColumnFcmaButterfly10f,
    10,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix11f,
    "fcma",
    ColumnFcmaButterfly11f,
    11,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix12f,
    "fcma",
    ColumnFcmaButterfly12f,
    12,
    fcmul_fcma
);
#[cfg(feature = "fcma")]
define_mixed_radix_neon_f!(
    NeonFcmaMixedRadix13f,
    "fcma",
    ColumnFcmaButterfly13f,
    13,
    fcmul_fcma
);

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Zaft;

    #[test]
    fn test_neon_mixed_radix_f64() {
        let src: [Complex<f64>; 8] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
        ];
        let neon_mixed_rust =
            NeonMixedRadix2::new(Zaft::strategy(4, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(8, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        assert_eq!(reference_value, test_value);
    }

    #[test]
    fn test_neon_mixed_radix3_f64() {
        let src: [Complex<f64>; 12] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
        ];
        let neon_mixed_rust =
            NeonMixedRadix3::new(Zaft::strategy(4, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(12, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix4_f64() {
        let src: [Complex<f64>; 12] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
        ];
        let neon_mixed_rust =
            NeonMixedRadix4::new(Zaft::strategy(3, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(12, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[cfg(feature = "fcma")]
    #[test]
    fn test_neon_mixed_radix4_f64_fcma() {
        if std::arch::is_aarch64_feature_detected!("fcma") {
            let src: [Complex<f64>; 12] = [
                Complex::new(1.3, 1.6),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
                Complex::new(0.9, 0.13),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(-0.45, -0.4),
                Complex::new(0.45, -0.4),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(-0.45, -0.4),
                Complex::new(0.45, -0.4),
            ];
            let neon_mixed_rust =
                NeonMixedRadix4::new(Zaft::strategy(3, FftDirection::Forward).unwrap()).unwrap();
            let bf8 = Zaft::strategy(12, FftDirection::Forward).unwrap();
            let mut reference_value = src.to_vec();
            bf8.execute(&mut reference_value).unwrap();
            let mut test_value = src.to_vec();
            neon_mixed_rust.execute(&mut test_value).unwrap();
            reference_value
                .iter()
                .zip(test_value.iter())
                .enumerate()
                .for_each(|(idx, (a, b))| {
                    assert!(
                        (a.re - b.re).abs() < 1e-9,
                        "a_re {} != b_re {} for at {idx}",
                        a.re,
                        b.re,
                    );
                    assert!(
                        (a.im - b.im).abs() < 1e-9,
                        "a_im {} != b_im {} for at {idx}",
                        a.im,
                        b.im,
                    );
                });
        }
    }

    #[test]
    fn test_neon_mixed_radix5_f64() {
        let src: [Complex<f64>; 20] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
        ];
        let neon_mixed_rust =
            NeonMixedRadix5::new(Zaft::strategy(4, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(20, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix6_f64() {
        let src: [Complex<f64>; 18] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix6::new(Zaft::strategy(3, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(18, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix7_f64() {
        let src: [Complex<f64>; 14] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
        ];
        let neon_mixed_rust =
            NeonMixedRadix7::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(14, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix9_f64() {
        let src: [Complex<f64>; 18] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix9::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(18, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix10_f64() {
        let src: [Complex<f64>; 20] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix10::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(20, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix11_f64() {
        let src: [Complex<f64>; 22] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
        ];
        let neon_mixed_rust =
            NeonMixedRadix11::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(22, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix13_f64() {
        let src: [Complex<f64>; 26] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
        ];
        let neon_mixed_rust =
            NeonMixedRadix13::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(26, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-9,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-9,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix_f32() {
        let src: [Complex<f32>; 8] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(-0.45, -0.4),
            Complex::new(0.45, -0.4),
        ];
        let neon_mixed_rust =
            NeonMixedRadix2f::new(Zaft::strategy(4, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(8, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix_rem_f32() {
        let src: [Complex<f32>; 6] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix2f::new(Zaft::strategy(3, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(6, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix3_rem_f32() {
        let src: [Complex<f32>; 12] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix3f::new(Zaft::strategy(4, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(12, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix4_rem_f32() {
        let src: [Complex<f32>; 12] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix4f::new(Zaft::strategy(3, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(12, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[cfg(feature = "fcma")]
    #[test]
    fn test_neon_mixed_radix4_rem_f32_fcma() {
        if std::arch::is_aarch64_feature_detected!("fcma") {
            let src: [Complex<f32>; 12] = [
                Complex::new(1.3, 1.6),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
                Complex::new(0.9, 0.13),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(1.3, 1.6),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
                Complex::new(0.9, 0.13),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
            ];
            let neon_mixed_rust =
                NeonFcmaForwardMixedRadix4f::new(Zaft::strategy(3, FftDirection::Forward).unwrap())
                    .unwrap();
            let bf8 = Zaft::strategy(12, FftDirection::Forward).unwrap();
            let mut reference_value = src.to_vec();
            bf8.execute(&mut reference_value).unwrap();
            let mut test_value = src.to_vec();
            neon_mixed_rust.execute(&mut test_value).unwrap();
            reference_value
                .iter()
                .zip(test_value.iter())
                .enumerate()
                .for_each(|(idx, (a, b))| {
                    assert!(
                        (a.re - b.re).abs() < 1e-4,
                        "a_re {} != b_re {} for at {idx}",
                        a.re,
                        b.re,
                    );
                    assert!(
                        (a.im - b.im).abs() < 1e-4,
                        "a_im {} != b_im {} for at {idx}",
                        a.im,
                        b.im,
                    );
                });
        }
    }

    #[test]
    fn test_neon_mixed_radix5_rem_f32() {
        let src: [Complex<f32>; 20] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix5f::new(Zaft::strategy(4, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(20, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[cfg(feature = "fcma")]
    #[test]
    fn test_neon_mixed_radix20_rem_f32() {
        if std::arch::is_aarch64_feature_detected!("fcma") {
            let src: [Complex<f32>; 20] = [
                Complex::new(1.3, 1.6),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
                Complex::new(0.9, 0.13),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(1.3, 1.6),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
                Complex::new(0.9, 0.13),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(1.3, 1.6),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
                Complex::new(0.9, 0.13),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
            ];
            let neon_mixed_rust =
                NeonFcmaMixedRadix5f::new(Zaft::strategy(4, FftDirection::Forward).unwrap())
                    .unwrap();
            let bf8 = Zaft::strategy(20, FftDirection::Forward).unwrap();
            let mut reference_value = src.to_vec();
            bf8.execute(&mut reference_value).unwrap();
            let mut test_value = src.to_vec();
            neon_mixed_rust.execute(&mut test_value).unwrap();
            reference_value
                .iter()
                .zip(test_value.iter())
                .enumerate()
                .for_each(|(idx, (a, b))| {
                    assert!(
                        (a.re - b.re).abs() < 1e-4,
                        "a_re {} != b_re {} for at {idx}",
                        a.re,
                        b.re,
                    );
                    assert!(
                        (a.im - b.im).abs() < 1e-4,
                        "a_im {} != b_im {} for at {idx}",
                        a.im,
                        b.im,
                    );
                });
        }
    }

    #[test]
    fn test_neon_mixed_radix6_rem_f32() {
        let src: [Complex<f32>; 18] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
        ];
        let neon_mixed_rust =
            NeonMixedRadix6f::new(Zaft::strategy(3, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(18, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix7_rem_f32() {
        let src: [Complex<f32>; 14] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix7f::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(14, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix8_rem_f32() {
        let src: [Complex<f32>; 16] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
        ];
        let neon_mixed_rust =
            NeonMixedRadix8f::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(16, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    #[cfg(feature = "fcma")]
    fn test_neon_mixed_radix8_fcma_f32() {
        if std::arch::is_aarch64_feature_detected!("fcma") {
            let src: [Complex<f32>; 16] = [
                Complex::new(1.3, 1.6),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
                Complex::new(0.9, 0.13),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(1.3, 1.6),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
                Complex::new(0.9, 0.13),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(3.25, 2.7),
                Complex::new(0.654, 0.324),
                Complex::new(1.7, -0.4),
                Complex::new(8.2, -0.1),
            ];
            let neon_mixed_rust =
                NeonMixedRadix8f::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
            let bf8 = Zaft::strategy(16, FftDirection::Forward).unwrap();
            let mut reference_value = src.to_vec();
            bf8.execute(&mut reference_value).unwrap();
            let mut test_value = src.to_vec();
            neon_mixed_rust.execute(&mut test_value).unwrap();
            reference_value
                .iter()
                .zip(test_value.iter())
                .enumerate()
                .for_each(|(idx, (a, b))| {
                    assert!(
                        (a.re - b.re).abs() < 1e-4,
                        "a_re {} != b_re {} for at {idx}",
                        a.re,
                        b.re,
                    );
                    assert!(
                        (a.im - b.im).abs() < 1e-4,
                        "a_im {} != b_im {} for at {idx}",
                        a.im,
                        b.im,
                    );
                });
        }
    }

    #[test]
    fn test_neon_mixed_radix10_rem_f32() {
        let src: [Complex<f32>; 20] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
        ];
        let neon_mixed_rust =
            NeonMixedRadix10f::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(20, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix11_rem_f32() {
        let src: [Complex<f32>; 22] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
        ];
        let neon_mixed_rust =
            NeonMixedRadix11f::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(22, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }

    #[test]
    fn test_neon_mixed_radix13_rem_f32() {
        let src: [Complex<f32>; 26] = [
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(3.25, 2.7),
            Complex::new(3.25, 2.7),
            Complex::new(0.654, 0.324),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
            Complex::new(1.3, 1.6),
            Complex::new(1.7, -0.4),
            Complex::new(8.2, -0.1),
            Complex::new(0.9, 0.13),
        ];
        let neon_mixed_rust =
            NeonMixedRadix13f::new(Zaft::strategy(2, FftDirection::Forward).unwrap()).unwrap();
        let bf8 = Zaft::strategy(26, FftDirection::Forward).unwrap();
        let mut reference_value = src.to_vec();
        bf8.execute(&mut reference_value).unwrap();
        let mut test_value = src.to_vec();
        neon_mixed_rust.execute(&mut test_value).unwrap();
        reference_value
            .iter()
            .zip(test_value.iter())
            .enumerate()
            .for_each(|(idx, (a, b))| {
                assert!(
                    (a.re - b.re).abs() < 1e-4,
                    "a_re {} != b_re {} for at {idx}",
                    a.re,
                    b.re,
                );
                assert!(
                    (a.im - b.im).abs() < 1e-4,
                    "a_im {} != b_im {} for at {idx}",
                    a.im,
                    b.im,
                );
            });
    }
}
