/*
 * // Copyright (c) Radzivon Bartoshyk 10/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
mod bf10;
mod bf11;
mod bf12;
mod bf13;
mod bf16;
mod bf18;
mod bf2;
mod bf3;
mod bf32;
mod bf36;
mod bf4;
mod bf40;
mod bf45;
mod bf48;
mod bf5;
mod bf6;
mod bf7;
mod bf8;
mod bf9;
mod mixed_radix;
mod mixed_radix_c2r_d;
mod mixed_radix_c2r_f;
mod mixed_radix_r2c;
mod neon_store;

pub(crate) use bf2::{ColumnButterfly2d, ColumnButterfly2f};
pub(crate) use bf3::{
    ColumnButterfly3d, ColumnButterfly3f, ColumnRdftButterfly3d, ColumnRdftButterfly3f,
};
#[cfg(feature = "fcma")]
pub(crate) use bf3::{ColumnFcmaButterfly3d, ColumnFcmaButterfly3f};
pub(crate) use bf4::{ColumnButterfly4d, ColumnButterfly4f};
#[cfg(feature = "fcma")]
pub(crate) use bf4::{ColumnFcmaButterfly4d, ColumnFcmaButterfly4f};
pub(crate) use bf5::{
    ColumnButterfly5d, ColumnButterfly5f, ColumnRdftButterfly5d, ColumnRdftButterfly5f,
};
#[cfg(feature = "fcma")]
pub(crate) use bf5::{ColumnFcmaButterfly5d, ColumnFcmaButterfly5f};
pub(crate) use bf6::{ColumnButterfly6d, ColumnButterfly6f};
#[cfg(feature = "fcma")]
pub(crate) use bf6::{ColumnFcmaButterfly6d, ColumnFcmaButterfly6f};
pub(crate) use bf7::{
    ColumnButterfly7d, ColumnButterfly7f, ColumnRdftButterfly7d, ColumnRdftButterfly7f,
};
#[cfg(feature = "fcma")]
pub(crate) use bf7::{ColumnFcmaButterfly7d, ColumnFcmaButterfly7f};
pub(crate) use bf8::{ColumnButterfly8d, ColumnButterfly8f};
#[cfg(feature = "fcma")]
pub(crate) use bf8::{
    ColumnFcmaButterfly8d, ColumnFcmaButterfly8f, ColumnFcmaForwardButterfly8f,
    ColumnFcmaInverseButterfly8f,
};
pub(crate) use bf9::{
    ColumnButterfly9d, ColumnButterfly9f, ColumnRdftButterfly9d, ColumnRdftButterfly9f,
};
#[cfg(feature = "fcma")]
pub(crate) use bf9::{ColumnFcmaButterfly9d, ColumnFcmaButterfly9f};
pub(crate) use bf10::{ColumnButterfly10d, ColumnButterfly10f};
#[cfg(feature = "fcma")]
pub(crate) use bf10::{ColumnFcmaButterfly10d, ColumnFcmaButterfly10f};
pub(crate) use bf11::{
    ColumnButterfly11d, ColumnButterfly11f, ColumnRdftButterfly11d, ColumnRdftButterfly11f,
};
#[cfg(feature = "fcma")]
pub(crate) use bf11::{ColumnFcmaButterfly11d, ColumnFcmaButterfly11f};
pub(crate) use bf12::{ColumnButterfly12d, ColumnButterfly12f};
#[cfg(feature = "fcma")]
pub(crate) use bf12::{ColumnFcmaButterfly12d, ColumnFcmaButterfly12f};
pub(crate) use bf13::{
    ColumnButterfly13d, ColumnButterfly13f, ColumnRdftButterfly13d, ColumnRdftButterfly13f,
};
#[cfg(feature = "fcma")]
pub(crate) use bf13::{ColumnFcmaButterfly13d, ColumnFcmaButterfly13f};
pub(crate) use bf16::{ColumnButterfly16d, ColumnButterfly16f};
#[cfg(feature = "fcma")]
pub(crate) use bf16::{
    ColumnFcmaButterfly16d, ColumnFcmaButterfly16f, ColumnFcmaForwardButterfly16f,
    ColumnFcmaInverseButterfly16f,
};
pub(crate) use bf18::{ColumnButterfly18d, ColumnButterfly18f};
#[cfg(feature = "fcma")]
pub(crate) use bf18::{ColumnFcmaButterfly18d, ColumnFcmaButterfly18f};
pub(crate) use bf32::{ColumnButterfly32d, ColumnButterfly32f};
#[cfg(feature = "fcma")]
pub(crate) use bf32::{
    ColumnFcmaButterfly32d, ColumnFcmaButterfly32f, ColumnFcmaForwardButterfly32f,
    ColumnFcmaInverseButterfly32f,
};
pub(crate) use bf36::ColumnButterfly36f;
#[cfg(feature = "fcma")]
pub(crate) use bf36::ColumnFcmaButterfly36f;
pub(crate) use bf40::ColumnButterfly40f;
#[cfg(feature = "fcma")]
pub(crate) use bf40::ColumnFcmaButterfly40f;
pub(crate) use bf45::ColumnButterfly45f;
#[cfg(feature = "fcma")]
pub(crate) use bf45::ColumnFcmaButterfly45f;
pub(crate) use bf48::ColumnButterfly48f;
#[cfg(feature = "fcma")]
pub(crate) use bf48::ColumnFcmaButterfly48f;
#[cfg(feature = "fcma")]
pub(crate) use mixed_radix::{
    NeonFcmaForwardMixedRadix4f, NeonFcmaForwardMixedRadix8f, NeonFcmaInverseMixedRadix4f,
    NeonFcmaInverseMixedRadix8f, NeonFcmaMixedRadix2, NeonFcmaMixedRadix2f, NeonFcmaMixedRadix3,
    NeonFcmaMixedRadix3f, NeonFcmaMixedRadix4, NeonFcmaMixedRadix5, NeonFcmaMixedRadix5f,
    NeonFcmaMixedRadix6, NeonFcmaMixedRadix6f, NeonFcmaMixedRadix7, NeonFcmaMixedRadix7f,
    NeonFcmaMixedRadix8, NeonFcmaMixedRadix9, NeonFcmaMixedRadix9f, NeonFcmaMixedRadix10,
    NeonFcmaMixedRadix10f, NeonFcmaMixedRadix11, NeonFcmaMixedRadix11f, NeonFcmaMixedRadix12,
    NeonFcmaMixedRadix12f, NeonFcmaMixedRadix13, NeonFcmaMixedRadix13f,
};
pub(crate) use mixed_radix::{
    NeonMixedRadix2, NeonMixedRadix2f, NeonMixedRadix3, NeonMixedRadix3f, NeonMixedRadix4,
    NeonMixedRadix4f, NeonMixedRadix5, NeonMixedRadix5f, NeonMixedRadix6, NeonMixedRadix6f,
    NeonMixedRadix7, NeonMixedRadix7f, NeonMixedRadix8, NeonMixedRadix8f, NeonMixedRadix9,
    NeonMixedRadix9f, NeonMixedRadix10, NeonMixedRadix10f, NeonMixedRadix11, NeonMixedRadix11f,
    NeonMixedRadix12, NeonMixedRadix12f, NeonMixedRadix13, NeonMixedRadix13f,
};
pub(crate) use mixed_radix_c2r_d::{
    NeonC2RMixedRadix3d, NeonC2RMixedRadix5d, NeonC2RMixedRadix7d, NeonC2RMixedRadix9d,
    NeonC2RMixedRadix11d,
};
#[cfg(feature = "fcma")]
pub(crate) use mixed_radix_c2r_d::{
    NeonFcmaC2RMixedRadix3d, NeonFcmaC2RMixedRadix5d, NeonFcmaC2RMixedRadix7d,
    NeonFcmaC2RMixedRadix9d, NeonFcmaC2RMixedRadix11d,
};
pub(crate) use mixed_radix_c2r_f::{
    NeonC2RMixedRadix3f, NeonC2RMixedRadix5f, NeonC2RMixedRadix7f, NeonC2RMixedRadix9f,
    NeonC2RMixedRadix11f,
};
#[cfg(feature = "fcma")]
pub(crate) use mixed_radix_c2r_f::{
    NeonFcmaC2RMixedRadix3f, NeonFcmaC2RMixedRadix5f, NeonFcmaC2RMixedRadix7f,
    NeonFcmaC2RMixedRadix9f, NeonFcmaC2RMixedRadix11f,
};
#[cfg(feature = "fcma")]
pub(crate) use mixed_radix_r2c::{
    NeonFcmaR2CMixedRadix3d, NeonFcmaR2CMixedRadix3f, NeonFcmaR2CMixedRadix5d,
    NeonFcmaR2CMixedRadix5f, NeonFcmaR2CMixedRadix7d, NeonFcmaR2CMixedRadix7f,
    NeonFcmaR2CMixedRadix9d, NeonFcmaR2CMixedRadix9f, NeonFcmaR2CMixedRadix11d,
    NeonFcmaR2CMixedRadix11f, NeonFcmaR2CMixedRadix13d, NeonFcmaR2CMixedRadix13f,
};
pub(crate) use mixed_radix_r2c::{
    NeonR2CMixedRadix3d, NeonR2CMixedRadix3f, NeonR2CMixedRadix5d, NeonR2CMixedRadix5f,
    NeonR2CMixedRadix7d, NeonR2CMixedRadix7f, NeonR2CMixedRadix9d, NeonR2CMixedRadix9f,
    NeonR2CMixedRadix11d, NeonR2CMixedRadix11f, NeonR2CMixedRadix13d, NeonR2CMixedRadix13f,
};
pub(crate) use neon_store::{NeonStoreD, NeonStoreF};
