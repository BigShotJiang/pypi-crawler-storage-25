/*
 * // Copyright (c) Radzivon Bartoshyk 10/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::neon::mixed::neon_store::{NeonStoreD, NeonStoreF, NeonStoreFh};
use crate::util::compute_twiddle;
use crate::{FftDirection, FftSample};
use num_traits::MulAdd;
use std::arch::aarch64::*;

pub(crate) struct ColumnButterfly3d {
    tw_re: float64x2_t,
    tw_im: float64x2_t,
}

#[cfg(feature = "fcma")]
pub(crate) struct ColumnFcmaButterfly3d {
    tw_re: float64x2_t,
    tw_im: float64x2_t,
}

pub(crate) struct ColumnButterfly3f {
    tw_re: float32x4_t,
    tw_im: float32x4_t,
}

#[cfg(feature = "fcma")]
pub(crate) struct ColumnFcmaButterfly3f {
    tw_re: float32x4_t,
    tw_im: float32x4_t,
}

impl ColumnButterfly3d {
    pub(crate) fn new(direction: FftDirection) -> Self {
        let twiddle = compute_twiddle::<f64>(1, 3, direction);
        unsafe {
            Self {
                tw_re: vdupq_n_f64(twiddle.re),
                tw_im: vld1q_f64([-twiddle.im, twiddle.im].as_ptr().cast()),
            }
        }
    }

    #[inline(always)]
    pub(crate) fn exec(&self, store: [NeonStoreD; 3]) -> [NeonStoreD; 3] {
        unsafe {
            let xp = vaddq_f64(store[1].v, store[2].v);
            let xn = vsubq_f64(store[1].v, store[2].v);
            let sum = vaddq_f64(store[0].v, xp);

            let w_1 = vfmaq_f64(store[0].v, self.tw_re, xp);

            let xn_rot = vextq_f64::<1>(xn, xn);

            let y0 = sum;
            let y1 = vfmaq_f64(w_1, self.tw_im, xn_rot);
            let y2 = vfmsq_f64(w_1, self.tw_im, xn_rot);
            [
                NeonStoreD::raw(y0),
                NeonStoreD::raw(y1),
                NeonStoreD::raw(y2),
            ]
        }
    }
}

#[cfg(feature = "fcma")]
impl ColumnFcmaButterfly3d {
    pub(crate) fn new(direction: FftDirection) -> Self {
        let twiddle = compute_twiddle::<f64>(1, 3, direction);
        unsafe {
            let q = vld1q_f64([-twiddle.im, twiddle.im].as_ptr().cast());
            Self {
                tw_re: vdupq_n_f64(twiddle.re),
                tw_im: q,
            }
        }
    }

    #[inline]
    #[target_feature(enable = "fcma")]
    pub(crate) fn exec(&self, store: [NeonStoreD; 3]) -> [NeonStoreD; 3] {
        let xp = vaddq_f64(store[1].v, store[2].v);
        let xn = vsubq_f64(store[1].v, store[2].v);
        let sum = vaddq_f64(store[0].v, xp);

        let w_1 = vfmaq_f64(store[0].v, self.tw_re, xp);

        let y0 = sum;
        let y1 = vcmlaq_rot90_f64(w_1, self.tw_im, xn);
        let y2 = vcmlaq_rot270_f64(w_1, self.tw_im, xn);
        [
            NeonStoreD::raw(y0),
            NeonStoreD::raw(y1),
            NeonStoreD::raw(y2),
        ]
    }
}

impl ColumnButterfly3f {
    pub(crate) fn new(direction: FftDirection) -> Self {
        let twiddle = compute_twiddle::<f32>(1, 3, direction);
        unsafe {
            Self {
                tw_re: vdupq_n_f32(twiddle.re),
                tw_im: vld1q_f32(
                    [-twiddle.im, twiddle.im, -twiddle.im, twiddle.im]
                        .as_ptr()
                        .cast(),
                ),
            }
        }
    }

    #[inline]
    pub(crate) fn exec(&self, store: [NeonStoreF; 3]) -> [NeonStoreF; 3] {
        unsafe {
            let xp = vaddq_f32(store[1].v, store[2].v);
            let xn = vsubq_f32(store[1].v, store[2].v);
            let sum = vaddq_f32(store[0].v, xp);

            let w_1 = vfmaq_f32(store[0].v, self.tw_re, xp);

            let xn_rot = vrev64q_f32(xn);

            let y0 = sum;
            let y1 = vfmaq_f32(w_1, self.tw_im, xn_rot);
            let y2 = vfmsq_f32(w_1, self.tw_im, xn_rot);
            [
                NeonStoreF::raw(y0),
                NeonStoreF::raw(y1),
                NeonStoreF::raw(y2),
            ]
        }
    }

    #[inline]
    pub(crate) fn exech(&self, store: [NeonStoreFh; 3]) -> [NeonStoreFh; 3] {
        unsafe {
            let xp = vadd_f32(store[1].v, store[2].v);
            let xn = vsub_f32(store[1].v, store[2].v);
            let sum = vadd_f32(store[0].v, xp);

            let w_1 = vfma_f32(store[0].v, vget_low_f32(self.tw_re), xp);

            let xn_rot = vext_f32::<1>(xn, xn);

            let y0 = sum;
            let y1 = vfma_f32(w_1, vget_low_f32(self.tw_im), xn_rot);
            let y2 = vfms_f32(w_1, vget_low_f32(self.tw_im), xn_rot);
            [
                NeonStoreFh::raw(y0),
                NeonStoreFh::raw(y1),
                NeonStoreFh::raw(y2),
            ]
        }
    }
}

#[cfg(feature = "fcma")]
impl ColumnFcmaButterfly3f {
    pub(crate) fn new(direction: FftDirection) -> Self {
        let twiddle = compute_twiddle::<f32>(1, 3, direction);
        unsafe {
            let q = vld1q_f32(
                [-twiddle.im, twiddle.im, -twiddle.im, twiddle.im]
                    .as_ptr()
                    .cast(),
            );
            Self {
                tw_re: vdupq_n_f32(twiddle.re),
                tw_im: q,
            }
        }
    }

    #[inline]
    #[target_feature(enable = "fcma")]
    pub(crate) fn exec(&self, store: [NeonStoreF; 3]) -> [NeonStoreF; 3] {
        let xp = vaddq_f32(store[1].v, store[2].v);
        let xn = vsubq_f32(store[1].v, store[2].v);
        let sum = vaddq_f32(store[0].v, xp);

        let w_1 = vfmaq_f32(store[0].v, self.tw_re, xp);

        let y0 = sum;
        let y1 = vcmlaq_rot90_f32(w_1, self.tw_im, xn);
        let y2 = vcmlaq_rot270_f32(w_1, self.tw_im, xn);
        [
            NeonStoreF::raw(y0),
            NeonStoreF::raw(y1),
            NeonStoreF::raw(y2),
        ]
    }

    #[inline]
    #[target_feature(enable = "fcma")]
    pub(crate) fn exech(&self, store: [NeonStoreFh; 3]) -> [NeonStoreFh; 3] {
        let xp = vadd_f32(store[1].v, store[2].v);
        let xn = vsub_f32(store[1].v, store[2].v);
        let sum = vadd_f32(store[0].v, xp);

        let w_1 = vfma_f32(store[0].v, vget_low_f32(self.tw_re), xp);

        let y0 = sum;
        let y1 = vcmla_rot90_f32(w_1, vget_low_f32(self.tw_im), xn);
        let y2 = vcmla_rot270_f32(w_1, vget_low_f32(self.tw_im), xn);
        [
            NeonStoreFh::raw(y0),
            NeonStoreFh::raw(y1),
            NeonStoreFh::raw(y2),
        ]
    }
}

pub(crate) struct ColumnRdftButterfly3d {}

impl ColumnRdftButterfly3d {
    pub(crate) fn new() -> Self {
        Self {}
    }

    #[inline]
    #[target_feature(enable = "neon")]
    pub(crate) fn exec(&self, store: [NeonStoreD; 3]) -> [[NeonStoreD; 2]; 2] {
        let w1 = store[1] + store[2];
        let w2 = store[1] - store[2];
        let x0 = w1 + store[0];
        let x1 = w1.mul_add(NeonStoreD::dup(-f64::HALF), store[0]);

        let v0 = x0.zip_complex(NeonStoreD::zero());
        let im1 = w2 * -f64::SQRT_3_OVER_2;
        let v1 = x1.zip_complex(im1);

        [[v0[0], v1[0]], [v0[1], v1[1]]]
    }
}

pub(crate) struct ColumnRdftButterfly3f {}

impl ColumnRdftButterfly3f {
    pub(crate) fn new() -> Self {
        Self {}
    }

    #[inline]
    #[target_feature(enable = "neon")]
    pub(crate) fn exec(&self, store: [NeonStoreF; 3]) -> [[NeonStoreF; 2]; 2] {
        let w1 = store[1] + store[2];
        let w2 = store[1] - store[2];
        let x0 = w1 + store[0];
        let x1 = w1.mul_add(NeonStoreF::dup(-f32::HALF), store[0]);

        let v0 = x0.zip_complex(NeonStoreF::zero());
        let im1 = w2 * -f32::SQRT_3_OVER_2;
        let v1 = x1.zip_complex(im1);

        [[v0[0], v1[0]], [v0[1], v1[1]]]
    }
}
