/*
 * // Copyright (c) Radzivon Bartoshyk 9/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::err::try_vec;
use crate::neon::radix3::{
    neon_bitreversed_transpose_f32_radix3, neon_bitreversed_transpose_f64_radix3,
};
use crate::neon::util::{create_neon_twiddles, vfcmulq_fcma_f32, vfcmulq_fcma_f64};
use crate::radix3::Radix3Twiddles;
use crate::util::{
    bitreversed_transpose, compute_twiddle, int_logarithm, is_power_of_three, validate_oof_sizes,
    validate_scratch,
};
use crate::{FftDirection, FftExecutor, FftSample, ZaftError};
use num_complex::Complex;
use num_traits::{AsPrimitive, Zero};
use std::arch::aarch64::*;
use std::sync::Arc;

pub(crate) struct NeonFcmaRadix3<T> {
    twiddles: Vec<Complex<T>>,
    execution_length: usize,
    twiddle_re: T,
    twiddle_im: [T; 4],
    direction: FftDirection,
    base_fft: Arc<dyn FftExecutor<T> + Send + Sync>,
    base_len: usize,
}

impl<T: FftSample + Radix3Twiddles> NeonFcmaRadix3<T>
where
    f64: AsPrimitive<T>,
{
    pub fn new(size: usize, fft_direction: FftDirection) -> Result<NeonFcmaRadix3<T>, ZaftError> {
        assert!(
            is_power_of_three(size as u64),
            "Neon Fcma Radix3 length must be power of 3"
        );

        let exponent = int_logarithm::<3>(size).unwrap_or_else(|| {
            panic!("Neon Fcma Radix3 length must be power of 3, but got {size}",)
        });

        let base_fft = match exponent {
            0 => T::butterfly1(fft_direction)?,
            1 => T::butterfly3(fft_direction)?,
            2 => T::butterfly9(fft_direction)?,
            3 => T::butterfly27(fft_direction)?,
            4 => T::butterfly81(fft_direction).map_or_else(|| T::butterfly27(fft_direction), Ok)?,
            _ => T::butterfly243(fft_direction).map_or_else(
                || T::butterfly81(fft_direction).map_or_else(|| T::butterfly27(fft_direction), Ok),
                Ok,
            )?,
        };

        let twiddles = create_neon_twiddles::<T, 3>(base_fft.length(), size, fft_direction)?;

        let twiddle = compute_twiddle::<T>(1, 3, fft_direction);

        Ok(NeonFcmaRadix3 {
            execution_length: size,
            twiddles,
            twiddle_re: twiddle.re,
            twiddle_im: [-twiddle.im, twiddle.im, -twiddle.im, twiddle.im],
            direction: fft_direction,
            base_len: base_fft.length(),
            base_fft,
        })
    }
}

impl NeonFcmaRadix3<f64> {
    #[target_feature(enable = "fcma")]
    fn base_run(&self, chunk: &mut [Complex<f64>]) {
        unsafe {
            let twiddle_re = vdupq_n_f64(self.twiddle_re);
            let twiddle_w_2 = vld1q_f64(self.twiddle_im.as_ptr().cast());

            let mut len = self.base_len;

            let mut m_twiddles = self.twiddles.as_slice();

            while len < self.execution_length {
                let columns = len;
                len *= 3;
                let third = len / 3;

                for data in chunk.chunks_exact_mut(len) {
                    let mut j = 0usize;

                    while j + 2 < third {
                        let u0 = vld1q_f64(data.get_unchecked(j..).as_ptr().cast());
                        let u1 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + third..).as_ptr().cast()),
                            vld1q_f64(m_twiddles.get_unchecked(2 * j..).as_ptr().cast()),
                        );
                        let u2 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 2 * third..).as_ptr().cast()),
                            vld1q_f64(m_twiddles.get_unchecked(2 * j + 1..).as_ptr().cast()),
                        );

                        let u3 = vld1q_f64(data.get_unchecked(j + 1..).as_ptr().cast());
                        let u4 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + third + 1..).as_ptr().cast()),
                            vld1q_f64(m_twiddles.get_unchecked(2 * (j + 1)..).as_ptr().cast()),
                        );
                        let u5 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 1 + 2 * third..).as_ptr().cast()),
                            vld1q_f64(m_twiddles.get_unchecked(2 * (j + 1) + 1..).as_ptr().cast()),
                        );

                        // Radix-3 butterfly
                        let xp0 = vaddq_f64(u1, u2);
                        let xn0 = vsubq_f64(u1, u2);
                        let sum0 = vaddq_f64(u0, xp0);

                        let xp1 = vaddq_f64(u4, u5);
                        let xn1 = vsubq_f64(u4, u5);
                        let sum1 = vaddq_f64(u3, xp1);

                        let w_01 = vfmaq_f64(u0, twiddle_re, xp0);
                        let w_02 = vfmaq_f64(u3, twiddle_re, xp1);

                        let vy0 = sum0;
                        let vy1 = vcmlaq_rot90_f64(w_01, twiddle_w_2, xn0);
                        let vy2 = vcmlaq_rot270_f64(w_01, twiddle_w_2, xn0);

                        let vy3 = sum1;
                        let vy4 = vcmlaq_rot90_f64(w_02, twiddle_w_2, xn1);
                        let vy5 = vcmlaq_rot270_f64(w_02, twiddle_w_2, xn1);

                        vst1q_f64(data.get_unchecked_mut(j..).as_mut_ptr().cast(), vy0);
                        vst1q_f64(data.get_unchecked_mut(j + third..).as_mut_ptr().cast(), vy1);
                        vst1q_f64(
                            data.get_unchecked_mut(j + 2 * third..).as_mut_ptr().cast(),
                            vy2,
                        );
                        vst1q_f64(data.get_unchecked_mut(j + 1..).as_mut_ptr().cast(), vy3);
                        vst1q_f64(
                            data.get_unchecked_mut(j + 1 + third..).as_mut_ptr().cast(),
                            vy4,
                        );
                        vst1q_f64(
                            data.get_unchecked_mut(j + 1 + 2 * third..)
                                .as_mut_ptr()
                                .cast(),
                            vy5,
                        );
                        j += 2;
                    }

                    for j in j..third {
                        let u0 = vld1q_f64(data.get_unchecked(j..).as_ptr().cast());
                        let u1 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + third..).as_ptr().cast()),
                            vld1q_f64(m_twiddles.get_unchecked(2 * j..).as_ptr().cast()),
                        );
                        let u2 = vfcmulq_fcma_f64(
                            vld1q_f64(data.get_unchecked(j + 2 * third..).as_ptr().cast()),
                            vld1q_f64(m_twiddles.get_unchecked(2 * j + 1..).as_ptr().cast()),
                        );

                        // Radix-3 butterfly
                        let xp = vaddq_f64(u1, u2);
                        let xn = vsubq_f64(u1, u2);
                        let sum = vaddq_f64(u0, xp);

                        let w_1 = vfmaq_f64(u0, twiddle_re, xp);

                        let vy0 = sum;
                        let vy1 = vcmlaq_rot90_f64(w_1, twiddle_w_2, xn);
                        let vy2 = vcmlaq_rot270_f64(w_1, twiddle_w_2, xn);

                        vst1q_f64(data.get_unchecked_mut(j..).as_mut_ptr().cast(), vy0);
                        vst1q_f64(data.get_unchecked_mut(j + third..).as_mut_ptr().cast(), vy1);
                        vst1q_f64(
                            data.get_unchecked_mut(j + 2 * third..).as_mut_ptr().cast(),
                            vy2,
                        );
                    }
                }

                m_twiddles = &m_twiddles[columns * 2..];
            }
        }
    }

    #[target_feature(enable = "fcma")]
    fn execute_f64(
        &self,
        in_place: &mut [Complex<f64>],
        scratch: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        if !in_place.len().is_multiple_of(self.execution_length) {
            return Err(ZaftError::InvalidSizeMultiplier(
                in_place.len(),
                self.execution_length,
            ));
        }

        let scratch = validate_scratch!(scratch, self.scratch_length());

        for chunk in in_place.chunks_exact_mut(self.execution_length) {
            // Digit-reversal permutation
            neon_bitreversed_transpose_f64_radix3(self.base_len, chunk, scratch);

            self.base_fft.execute_out_of_place(scratch, chunk)?;
            self.base_run(chunk);
        }
        Ok(())
    }

    #[target_feature(enable = "fcma")]
    fn execute_oof_f64(
        &self,
        src: &[Complex<f64>],
        dst: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        validate_oof_sizes!(src, dst, self.execution_length);

        for (dst, src) in dst
            .chunks_exact_mut(self.execution_length)
            .zip(src.chunks_exact(self.execution_length))
        {
            // Digit-reversal permutation
            neon_bitreversed_transpose_f64_radix3(self.base_len, src, dst);
            self.base_fft.execute(dst)?;
            self.base_run(dst);
        }
        Ok(())
    }
}

impl FftExecutor<f64> for NeonFcmaRadix3<f64> {
    fn execute(&self, in_place: &mut [Complex<f64>]) -> Result<(), ZaftError> {
        let mut scratch = try_vec![Complex::zero(); self.scratch_length()];
        unsafe { self.execute_f64(in_place, scratch.as_mut_slice()) }
    }

    fn execute_with_scratch(
        &self,
        in_place: &mut [Complex<f64>],
        scratch: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_f64(in_place, scratch) }
    }

    fn execute_out_of_place(
        &self,
        src: &[Complex<f64>],
        dst: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, &mut [])
    }

    fn execute_out_of_place_with_scratch(
        &self,
        src: &[Complex<f64>],
        dst: &mut [Complex<f64>],
        _: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_oof_f64(src, dst) }
    }

    fn execute_destructive_with_scratch(
        &self,
        src: &mut [Complex<f64>],
        dst: &mut [Complex<f64>],
        scratch: &mut [Complex<f64>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, scratch)
    }

    fn direction(&self) -> FftDirection {
        self.direction
    }

    fn length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn scratch_length(&self) -> usize {
        self.execution_length
    }

    fn out_of_place_scratch_length(&self) -> usize {
        0
    }

    fn destructive_scratch_length(&self) -> usize {
        0
    }
}

impl NeonFcmaRadix3<f32> {
    #[target_feature(enable = "fcma")]
    fn base_run(&self, chunk: &mut [Complex<f32>]) {
        unsafe {
            let twiddle_re = vdupq_n_f32(self.twiddle_re);
            let twiddle_w_2 = vld1q_f32(self.twiddle_im.as_ptr().cast());

            let mut len = self.base_len;

            let mut m_twiddles = self.twiddles.as_slice();

            while len < self.execution_length {
                let columns = len;
                len *= 3;
                let third = len / 3;

                for data in chunk.chunks_exact_mut(len) {
                    let mut j = 0usize;

                    while j + 4 <= third {
                        let u0 = vld1q_f32(data.get_unchecked(j..).as_ptr().cast());

                        let tw0 = vld1q_f32(m_twiddles.get_unchecked(2 * j..).as_ptr().cast());
                        let tw1 = vld1q_f32(m_twiddles.get_unchecked(2 * j + 2..).as_ptr().cast());

                        let tw2 = vld1q_f32(m_twiddles.get_unchecked(2 * j + 4..).as_ptr().cast());
                        let tw3 = vld1q_f32(m_twiddles.get_unchecked(2 * j + 6..).as_ptr().cast());

                        let u1 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + third..).as_ptr().cast()),
                            tw0,
                        );

                        let u2 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 2 * third..).as_ptr().cast()),
                            tw1,
                        );

                        let u3 = vld1q_f32(data.get_unchecked(j + 2..).as_ptr().cast());

                        let u4 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + third + 2..).as_ptr().cast()),
                            tw2,
                        );
                        let u5 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 2 * third + 2..).as_ptr().cast()),
                            tw3,
                        );

                        // Radix-3 butterfly
                        let xp0 = vaddq_f32(u1, u2);
                        let xn0 = vsubq_f32(u1, u2);
                        let sum0 = vaddq_f32(u0, xp0);

                        let xp1 = vaddq_f32(u4, u5);
                        let xn1 = vsubq_f32(u4, u5);
                        let sum1 = vaddq_f32(u3, xp1);

                        let w_01 = vfmaq_f32(u0, twiddle_re, xp0);
                        let w_02 = vfmaq_f32(u3, twiddle_re, xp1);

                        let vy0 = sum0;
                        let vy1 = vcmlaq_rot90_f32(w_01, twiddle_w_2, xn0);
                        let vy2 = vcmlaq_rot270_f32(w_01, twiddle_w_2, xn0);

                        let vy3 = sum1;
                        let vy4 = vcmlaq_rot90_f32(w_02, twiddle_w_2, xn1);
                        let vy5 = vcmlaq_rot270_f32(w_02, twiddle_w_2, xn1);

                        vst1q_f32(data.get_unchecked_mut(j..).as_mut_ptr().cast(), vy0);
                        vst1q_f32(data.get_unchecked_mut(j + third..).as_mut_ptr().cast(), vy1);
                        vst1q_f32(
                            data.get_unchecked_mut(j + 2 * third..).as_mut_ptr().cast(),
                            vy2,
                        );

                        vst1q_f32(data.get_unchecked_mut(j + 2..).as_mut_ptr().cast(), vy3);
                        vst1q_f32(
                            data.get_unchecked_mut(j + 2 + third..).as_mut_ptr().cast(),
                            vy4,
                        );
                        vst1q_f32(
                            data.get_unchecked_mut(j + 2 + 2 * third..)
                                .as_mut_ptr()
                                .cast(),
                            vy5,
                        );

                        j += 4;
                    }

                    while j + 2 <= third {
                        let u0 = vld1q_f32(data.get_unchecked(j..).as_ptr().cast());

                        let tw0 = vld1q_f32(m_twiddles.get_unchecked(2 * j..).as_ptr().cast());
                        let tw1 = vld1q_f32(m_twiddles.get_unchecked(2 * j + 2..).as_ptr().cast());

                        let u1 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + third..).as_ptr().cast()),
                            tw0,
                        );
                        let u2 = vfcmulq_fcma_f32(
                            vld1q_f32(data.get_unchecked(j + 2 * third..).as_ptr().cast()),
                            tw1,
                        );

                        // Radix-3 butterfly
                        let xp = vaddq_f32(u1, u2);
                        let xn = vsubq_f32(u1, u2);
                        let sum = vaddq_f32(u0, xp);

                        let w_1 = vfmaq_f32(u0, twiddle_re, xp);

                        let vy0 = sum;
                        let vy1 = vcmlaq_rot90_f32(w_1, twiddle_w_2, xn);
                        let vy2 = vcmlaq_rot270_f32(w_1, twiddle_w_2, xn);

                        vst1q_f32(data.get_unchecked_mut(j..).as_mut_ptr().cast(), vy0);
                        vst1q_f32(data.get_unchecked_mut(j + third..).as_mut_ptr().cast(), vy1);
                        vst1q_f32(
                            data.get_unchecked_mut(j + 2 * third..).as_mut_ptr().cast(),
                            vy2,
                        );

                        j += 2;
                    }

                    for j in j..third {
                        let u0 = vld1_f32(data.get_unchecked(j..).as_ptr().cast());

                        let tw = vld1q_f32(m_twiddles.get_unchecked(2 * j..).as_ptr().cast());

                        let u1u2 = vfcmulq_fcma_f32(
                            vcombine_f32(
                                vld1_f32(data.get_unchecked(j + third..).as_ptr().cast()),
                                vld1_f32(data.get_unchecked(j + 2 * third..).as_ptr().cast()),
                            ),
                            tw,
                        );

                        let u1 = vget_low_f32(u1u2);
                        let u2 = vget_high_f32(u1u2);

                        // Radix-3 butterfly
                        let xp = vadd_f32(u1, u2);
                        let xn = vsub_f32(u1, u2);
                        let sum = vadd_f32(u0, xp);

                        let w_1 = vfma_f32(u0, vget_low_f32(twiddle_re), xp);

                        let vy0 = sum;
                        let vy1 = vcmla_rot90_f32(w_1, vget_low_f32(twiddle_w_2), xn);
                        let vy2 = vcmla_rot270_f32(w_1, vget_low_f32(twiddle_w_2), xn);

                        vst1_f32(data.get_unchecked_mut(j..).as_mut_ptr().cast(), vy0);
                        vst1_f32(data.get_unchecked_mut(j + third..).as_mut_ptr().cast(), vy1);
                        vst1_f32(
                            data.get_unchecked_mut(j + 2 * third..).as_mut_ptr().cast(),
                            vy2,
                        );
                    }
                }

                m_twiddles = &m_twiddles[columns * 2..];
            }
        }
    }

    #[target_feature(enable = "fcma")]
    fn execute_f32(
        &self,
        in_place: &mut [Complex<f32>],
        scratch: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        if !in_place.len().is_multiple_of(self.execution_length) {
            return Err(ZaftError::InvalidSizeMultiplier(
                in_place.len(),
                self.execution_length,
            ));
        }

        let scratch = validate_scratch!(scratch, self.scratch_length());

        for chunk in in_place.chunks_exact_mut(self.execution_length) {
            // Digit-reversal permutation
            neon_bitreversed_transpose_f32_radix3(self.base_len, chunk, scratch);

            self.base_fft.execute_out_of_place(scratch, chunk)?;
            self.base_run(chunk);
        }
        Ok(())
    }

    #[target_feature(enable = "fcma")]
    fn execute_oof_f32(
        &self,
        src: &[Complex<f32>],
        dst: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        validate_oof_sizes!(src, dst, self.execution_length);

        for (dst, src) in dst
            .chunks_exact_mut(self.execution_length)
            .zip(src.chunks_exact(self.execution_length))
        {
            // Digit-reversal permutation
            bitreversed_transpose::<Complex<f32>, 3>(self.base_len, src, dst);
            self.base_fft.execute(dst)?;
            self.base_run(dst);
        }
        Ok(())
    }
}

impl FftExecutor<f32> for NeonFcmaRadix3<f32> {
    fn execute(&self, in_place: &mut [Complex<f32>]) -> Result<(), ZaftError> {
        let mut scratch = try_vec![Complex::zero(); self.scratch_length()];
        unsafe { self.execute_f32(in_place, scratch.as_mut_slice()) }
    }

    fn execute_with_scratch(
        &self,
        in_place: &mut [Complex<f32>],
        scratch: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_f32(in_place, scratch) }
    }

    fn execute_out_of_place(
        &self,
        src: &[Complex<f32>],
        dst: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, &mut [])
    }

    fn execute_out_of_place_with_scratch(
        &self,
        src: &[Complex<f32>],
        dst: &mut [Complex<f32>],
        _: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        unsafe { self.execute_oof_f32(src, dst) }
    }

    fn execute_destructive_with_scratch(
        &self,
        src: &mut [Complex<f32>],
        dst: &mut [Complex<f32>],
        scratch: &mut [Complex<f32>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, scratch)
    }

    fn direction(&self) -> FftDirection {
        self.direction
    }

    fn length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn scratch_length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn out_of_place_scratch_length(&self) -> usize {
        0
    }

    fn destructive_scratch_length(&self) -> usize {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::neon::test_fcma_radix;

    test_fcma_radix!(test_neon_radix3, f32, NeonFcmaRadix3, 6, 3, 1e-3);
    test_fcma_radix!(test_neon_radix3_f64, f64, NeonFcmaRadix3, 6, 3, 1e-8);
}
