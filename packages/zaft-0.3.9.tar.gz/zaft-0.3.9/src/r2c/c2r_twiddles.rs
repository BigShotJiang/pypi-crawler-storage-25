/*
 * // Copyright (c) Radzivon Bartoshyk 10/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
use crate::FftSample;
use crate::r2c::C2RTwiddlesHandler;
use num_complex::Complex;
use num_traits::AsPrimitive;
use std::marker::PhantomData;
use std::sync::{Arc, OnceLock};

pub(crate) trait C2RTwiddlesFactory<T> {
    fn make_c2r_twiddles_handler() -> Arc<dyn C2RTwiddlesHandler<T> + Send + Sync>;
}

#[allow(unused)]
pub(crate) struct C2RHandler<T> {
    phantom_data: PhantomData<T>,
}

impl C2RTwiddlesFactory<f32> for f32 {
    fn make_c2r_twiddles_handler() -> Arc<dyn C2RTwiddlesHandler<f32> + Send + Sync> {
        static Q: OnceLock<Arc<dyn C2RTwiddlesHandler<f32> + Send + Sync>> = OnceLock::new();
        Q.get_or_init(|| {
            #[cfg(all(target_arch = "aarch64", feature = "neon"))]
            {
                use crate::neon::C2RNeonTwiddles;
                Arc::new(C2RNeonTwiddles {})
            }
            #[cfg(all(target_arch = "x86_64", feature = "avx"))]
            {
                use crate::util::has_valid_avx;
                if has_valid_avx() {
                    use crate::avx::C2RAvxTwiddles;
                    return Arc::new(C2RAvxTwiddles {});
                }
            }
            #[cfg(all(target_arch = "wasm32", feature = "wasm"))]
            {
                use crate::wasm::C2RWasmTwiddles;
                Arc::new(C2RWasmTwiddles {})
            }
            #[cfg(not(any(
                all(target_arch = "aarch64", feature = "neon"),
                all(target_arch = "wasm32", feature = "wasm")
            )))]
            {
                Arc::new(C2RHandler {
                    phantom_data: PhantomData::<f32>,
                })
            }
        })
        .clone()
    }
}

impl C2RTwiddlesFactory<f64> for f64 {
    fn make_c2r_twiddles_handler() -> Arc<dyn C2RTwiddlesHandler<f64> + Send + Sync> {
        static Q: OnceLock<Arc<dyn C2RTwiddlesHandler<f64> + Send + Sync>> = OnceLock::new();
        Q.get_or_init(|| {
            #[cfg(all(target_arch = "aarch64", feature = "neon"))]
            {
                use crate::neon::C2RNeonTwiddles;
                Arc::new(C2RNeonTwiddles {})
            }
            #[cfg(all(target_arch = "x86_64", feature = "avx"))]
            {
                use crate::util::has_valid_avx;
                if has_valid_avx() {
                    use crate::avx::C2RAvxTwiddles;
                    return Arc::new(C2RAvxTwiddles {});
                }
            }
            #[cfg(all(target_arch = "wasm32", feature = "wasm"))]
            {
                use crate::wasm::C2RWasmTwiddles;
                Arc::new(C2RWasmTwiddles {})
            }
            #[cfg(not(any(
                all(target_arch = "aarch64", feature = "neon"),
                all(target_arch = "wasm32", feature = "wasm")
            )))]
            {
                Arc::new(C2RHandler {
                    phantom_data: PhantomData::<f64>,
                })
            }
        })
        .clone()
    }
}

impl<T: FftSample> C2RTwiddlesHandler<T> for C2RHandler<T>
where
    f64: AsPrimitive<T>,
{
    fn handle(
        &self,
        twiddles: &[Complex<T>],
        left_input: &[Complex<T>],
        right_input: &[Complex<T>],
        left: &mut [Complex<T>],
        right: &mut [Complex<T>],
    ) {
        for ((((twiddle, fft_input), fft_input_rev), left_input), right_input) in twiddles
            .iter()
            .zip(left.iter_mut())
            .zip(right.iter_mut().rev())
            .zip(left_input.iter())
            .zip(right_input.iter().rev())
        {
            let sum = *left_input + *right_input;
            let diff = *left_input - *right_input;

            let twiddled_re_sum = sum.im * twiddle.re;
            let twiddled_im_sum = sum.im * twiddle.im;
            let twiddled_re_diff = diff.re * twiddle.re;
            let twiddled_im_diff = diff.re * twiddle.im;

            let output_twiddled_real = twiddled_re_sum + twiddled_im_diff;
            let output_twiddled_im = twiddled_im_sum - twiddled_re_diff;

            *fft_input = Complex {
                re: sum.re - output_twiddled_real,
                im: diff.im - output_twiddled_im,
            };
            *fft_input_rev = Complex {
                re: sum.re + output_twiddled_real,
                im: -output_twiddled_im - diff.im,
            }
        }
    }
}
