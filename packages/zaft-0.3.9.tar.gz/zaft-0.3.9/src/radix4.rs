/*
 * // Copyright (c) Radzivon Bartoshyk 9/2025. All rights reserved.
 * //
 * // Redistribution and use in source and binary forms, with or without modification,
 * // are permitted provided that the following conditions are met:
 * //
 * // 1.  Redistributions of source code must retain the above copyright notice, this
 * // list of conditions and the following disclaimer.
 * //
 * // 2.  Redistributions in binary form must reproduce the above copyright notice,
 * // this list of conditions and the following disclaimer in the documentation
 * // and/or other materials provided with the distribution.
 * //
 * // 3.  Neither the name of the copyright holder nor the names of its
 * // contributors may be used to endorse or promote products derived from
 * // this software without specific prior written permission.
 * //
 * // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * // DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * // FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * // DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * // SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * // CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * // OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#![allow(unused)]
use crate::butterflies::rotate_90;
use crate::complex_fma::c_mul_fast;
use crate::err::try_vec;
use crate::util::{
    bitreversed_transpose, radixn_floating_twiddles_from_base, validate_oof_sizes, validate_scratch,
};
use crate::{FftDirection, FftExecutor, FftSample, ZaftError};
use num_complex::Complex;
use num_traits::{AsPrimitive, Zero};
use std::sync::Arc;

pub(crate) struct Radix4<T> {
    twiddles: Vec<Complex<T>>,
    execution_length: usize,
    direction: FftDirection,
    base_len: usize,
    base_fft: Arc<dyn FftExecutor<T> + Send + Sync>,
}

pub(crate) trait Radix4Twiddles {
    fn make_twiddles(
        base_len: usize,
        size: usize,
        fft_direction: FftDirection,
    ) -> Result<Vec<Complex<Self>>, ZaftError>
    where
        Self: Sized;
}

impl Radix4Twiddles for f64 {
    fn make_twiddles(
        base_len: usize,
        size: usize,
        fft_direction: FftDirection,
    ) -> Result<Vec<Complex<f64>>, ZaftError> {
        radixn_floating_twiddles_from_base::<f64, 4>(base_len, size, fft_direction)
    }
}

impl Radix4Twiddles for f32 {
    fn make_twiddles(
        base_len: usize,
        size: usize,
        fft_direction: FftDirection,
    ) -> Result<Vec<Complex<f32>>, ZaftError> {
        radixn_floating_twiddles_from_base::<f32, 4>(base_len, size, fft_direction)
    }
}

#[allow(unused)]
impl<T: FftSample + Radix4Twiddles> Radix4<T> {
    pub fn new(size: usize, fft_direction: FftDirection) -> Result<Radix4<T>, ZaftError> {
        assert!(size.is_power_of_two(), "Input length must be a power of 2");

        let exponent = size.trailing_zeros();
        let base_fft = match exponent {
            0 => T::butterfly1(fft_direction)?,
            1 => T::butterfly2(fft_direction)?,
            2 => T::butterfly4(fft_direction)?,
            3 => T::butterfly8(fft_direction)?,
            _ => {
                if exponent % 2 == 1 {
                    (T::butterfly32(fft_direction)?)
                } else {
                    (T::butterfly16(fft_direction)?)
                }
            }
        };

        let twiddles = T::make_twiddles(base_fft.length(), size, fft_direction)?;

        Ok(Radix4 {
            execution_length: size,
            twiddles,
            direction: fft_direction,
            base_len: base_fft.length(),
            base_fft,
        })
    }
}

impl<T: FftSample> Radix4<T>
where
    f64: AsPrimitive<T>,
{
    fn base_run(&self, chunk: &mut [Complex<T>]) {
        let mut len = self.base_len;

        unsafe {
            let mut m_twiddles = self.twiddles.as_slice();

            while len < self.execution_length {
                let columns = len;
                len *= 4;
                let quarter = len / 4;

                for data in chunk.chunks_exact_mut(len) {
                    for j in 0..quarter {
                        let a = *data.get_unchecked(j);
                        let b = c_mul_fast(
                            *data.get_unchecked(j + quarter),
                            *m_twiddles.get_unchecked(3 * j),
                        );
                        let c = c_mul_fast(
                            *data.get_unchecked(j + 2 * quarter),
                            *m_twiddles.get_unchecked(3 * j + 1),
                        );
                        let d = c_mul_fast(
                            *data.get_unchecked(j + 3 * quarter),
                            *m_twiddles.get_unchecked(3 * j + 2),
                        );

                        // radix-4 butterfly
                        let t0 = a + c;
                        let t1 = a - c;
                        let t2 = b + d;
                        let t3 = rotate_90(b - d, self.direction);

                        *data.get_unchecked_mut(j) = t0 + t2;
                        *data.get_unchecked_mut(j + quarter) = t1 + t3;
                        *data.get_unchecked_mut(j + 2 * quarter) = t0 - t2;
                        *data.get_unchecked_mut(j + 3 * quarter) = t1 - t3;
                    }
                }

                m_twiddles = &m_twiddles[columns * 3..];
            }
        }
    }
}

impl<T: FftSample> FftExecutor<T> for Radix4<T>
where
    f64: AsPrimitive<T>,
{
    fn execute(&self, in_place: &mut [Complex<T>]) -> Result<(), ZaftError> {
        let mut scratch = try_vec![Complex::zero(); self.scratch_length()];
        self.execute_with_scratch(in_place, scratch.as_mut_slice())
    }

    fn execute_with_scratch(
        &self,
        in_place: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) -> Result<(), ZaftError> {
        if !in_place.len().is_multiple_of(self.execution_length) {
            return Err(ZaftError::InvalidSizeMultiplier(
                in_place.len(),
                self.execution_length,
            ));
        }

        let scratch = validate_scratch!(scratch, self.scratch_length());

        for chunk in in_place.chunks_exact_mut(self.execution_length) {
            // bit reversal first
            bitreversed_transpose::<Complex<T>, 4>(self.base_len, chunk, scratch);
            self.base_fft.execute_out_of_place(scratch, chunk)?;
            self.base_run(chunk);
        }
        Ok(())
    }

    fn execute_out_of_place(
        &self,
        src: &[Complex<T>],
        dst: &mut [Complex<T>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, &mut [])
    }

    fn execute_out_of_place_with_scratch(
        &self,
        src: &[Complex<T>],
        dst: &mut [Complex<T>],
        _: &mut [Complex<T>],
    ) -> Result<(), ZaftError> {
        validate_oof_sizes!(src, dst, self.execution_length);

        for (dst, src) in dst
            .chunks_exact_mut(self.execution_length)
            .zip(src.chunks_exact(self.execution_length))
        {
            // Digit-reversal permutation
            bitreversed_transpose::<Complex<T>, 4>(self.base_len, src, dst);
            self.base_fft.execute(dst)?;
            self.base_run(dst);
        }
        Ok(())
    }

    fn execute_destructive_with_scratch(
        &self,
        src: &mut [Complex<T>],
        dst: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) -> Result<(), ZaftError> {
        self.execute_out_of_place_with_scratch(src, dst, scratch)
    }

    fn direction(&self) -> FftDirection {
        self.direction
    }

    #[inline]
    fn length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn scratch_length(&self) -> usize {
        self.execution_length
    }

    #[inline]
    fn out_of_place_scratch_length(&self) -> usize {
        0
    }

    fn destructive_scratch_length(&self) -> usize {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::util::test_radix;

    test_radix!(test_radix4, f32, Radix4, 6, 4, 1e-3);
}
