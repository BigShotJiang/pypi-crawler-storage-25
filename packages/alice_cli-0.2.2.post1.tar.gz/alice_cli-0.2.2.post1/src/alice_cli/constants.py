"""Application-wide constants for alice-cli."""

from __future__ import annotations

# ── Model Invocation ──────────────────────────────────────────────────────────

# Default maximum tokens for model invocations via the Converse API
DEFAULT_MAX_TOKENS = 4096

# ── AWS Resource Naming ───────────────────────────────────────────────────────

# S3 bucket name template for Cloud Locker session storage
MEMORY_BUCKET_TEMPLATE = "jh-{namespace}-alice-memory"

# Bedrock access key alias prefix (service_credential_alias format)
BEDROCK_API_KEY_PREFIX = "BedrockAPIKey-"

# JHU email domain used in secret paths and JHED detection
JHU_EMAIL_DOMAIN = "@jhu.edu"

# ── Configuration Defaults ────────────────────────────────────────────────────

DEFAULT_REGION = "us-east-1"
DEFAULT_NAMESPACE = "drcc"
DEFAULT_ENVIRONMENT = "ai"

# ── File Locking ──────────────────────────────────────────────────────────────

# Timeout (seconds) for acquiring a filelock on the local index
FILELOCK_TIMEOUT = 10

# ── Helper Functions ──────────────────────────────────────────────────────────


def get_memory_bucket(namespace: str, environment: str) -> str:
    """Build the Cloud Locker S3 bucket name.

    Args:
        namespace: Resource namespace (e.g. "drcc").
        environment: Deployment environment (e.g. "ai"). Currently unused
            in the bucket name but kept for forward compatibility.

    Returns:
        S3 bucket name, e.g. "jh-drcc-alice-memory".

    Example:
        >>> get_memory_bucket("drcc", "ai")
        'jh-drcc-alice-memory'
    """
    return MEMORY_BUCKET_TEMPLATE.format(namespace=namespace)
