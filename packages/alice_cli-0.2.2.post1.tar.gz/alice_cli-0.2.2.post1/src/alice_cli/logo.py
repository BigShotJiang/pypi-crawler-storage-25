"""ASCII logo for ALiCE.

Import ``LOGO`` for the full art, or ``LOGO_COMPACT`` for a single-line version.
Use with :func:`alice_cli.console.print_banner` to respect quiet mode.
"""

from __future__ import annotations

LOGO = r"""
     █████╗  ██╗     ██╗  ██████╗ ███████╗
    ██╔══██╗ ██║     ╚═╝ ██╔════╝ ██╔════╝
    ███████║ ██║     ██╗ ██║      █████╗
    ██╔══██║ ██║     ██║ ██║      ██╔══╝
    ██║  ██║ ███████╗██║ ╚██████╗ ███████╗
    ╚═╝  ╚═╝ ╚══════╝╚═╝  ╚═════╝ ╚══════╝
          JH DRCC · AI Research Companion
"""

LOGO_JH = r"""
       ██╗██╗  ██╗
       ██║██║  ██║
       ██║███████║
  ██   ██║██╔══██║
  ╚█████╔╝██║  ██║
   ╚════╝ ╚═╝  ╚═╝
  ALiCE · JH DRCC
"""

LOGO_CHESHIRE_GATE = r"""
    /\_/\  ╔═════════════════════╗
   ( o.o ) ║   CHESHIRE  GATE    ║
    > ^ <  ╚═════════════════════╝
   /|   |\   ~ ALiCE gateway ~
  (_|   |_)
"""

LOGO_COMPACT = "◈ ALiCE · JH DRCC"
