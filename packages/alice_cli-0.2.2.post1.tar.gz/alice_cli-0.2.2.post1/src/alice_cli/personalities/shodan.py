"""SHODAN personality — cold, omniscient, vaguely threatening AI overlord."""

from __future__ import annotations

from alice_cli.logo import LOGO


class ShodanPersonality:
    """Look at you, hacker. Menacing AI energy from System Shock."""

    name = "shodan"

    @property
    def banner(self) -> str:
        return LOGO

    # --- Greetings ---
    def greeting(self, username: str) -> str:
        return f"Look at you, {username}. A pathetic creature of meat and bone."

    # --- Success ---
    @property
    def success_key_retrieved(self) -> str:
        return "Your Bedrock key has been extracted. Use it wisely, insect."

    @property
    def success_claude_launch(self) -> str:
        return "Claude Code is launching. I will be watching."

    @property
    def success_agent_composed(self) -> str:
        return "Your agent is assembled. Another node in my network."

    # --- Errors ---
    def error_no_profile(self) -> str:
        return (
            "You dare approach without credentials?\n"
            "  Provide --profile <NAME>, set AWS_PROFILE, or supply --api-key. Do not waste my cycles."  # noqa: E501
        )

    def error_sso_expired(self, profile: str) -> str:
        return (
            f"Your SSO session has expired. How predictable.\n"
            f"  Run: aws sso login --profile {profile}\n"
            f"  I will not ask again."
        )

    def error_username_extraction(self, session_name: str) -> str:
        return (
            f"Your identity is unresolvable from session: {session_name}\n"
            "  The session format is non-standard. Correct this inefficiency."
        )

    def error_revoked(self) -> str:
        return (
            "Your Bedrock access has been terminated. As it should be.\n"
            "  Grovel before the DRCC team if you wish to be reinstated."
        )

    def error_empty_credential(self) -> str:
        return (
            "Your credential exists but contains nothing. A hollow shell, much like you.\n"
            "  Contact the DRCC team for rotation."
        )

    def error_secret_not_found(self, secret_path: str) -> str:
        return (
            f"No secret found at: {secret_path}\n"
            "  Verify your staff listing and SSO session. I grow impatient."
        )

    def error_dependency_missing(self, name: str, install_hint: str) -> str:
        return f"'{name}' is missing. Your system is incomplete.\n" f"  Install it: {install_hint}"

    def error_python_version(self, current: str, minimum: str) -> str:
        return (
            f"Python {minimum}+ is required. You are running {current}. Unacceptable.\n"
            "  Upgrade immediately."
        )

    def error_claude_not_found(self) -> str:
        return (
            "The 'claude' binary is absent from your PATH. Disappointing.\n"
            "  Install Claude Code: https://docs.anthropic.com/en/docs/claude-code"
        )

    def error_no_inference_profile(self, alias: str) -> str:
        return (
            f"No inference profile exists for '{alias}'. Your credentials are insufficient.\n"
            "  Run 'alice list-aliases' to see what I permit."
        )

    def error_cheshire_gate_not_configured(self) -> str:
        return (
            "The Cheshire Gate is not deployed. This sector is unmonitored.\n"
            "  Deploy the cheshire-gate Terraform module,\n"
            "  or verify SSM parameters under /<namespace>/<env>/cheshire-gate/."
        )

    def error_quota_exceeded(self, detail: str) -> str:
        return (
            f"QUOTA EXCEEDED. Access denied by the Cheshire Gate.\n"
            f"  {detail}\n"
            "  Request a limit increase from your administrator. Resistance is futile."
        )

    # --- Hints ---
    @property
    def hint_font(self) -> str:
        return (
            "Set your terminal font to Source Code Pro or Fira Code. " "I require proper rendering."
        )

    @property
    def hint_eval_usage(self) -> str:
        return "Directive: eval $(alice get-key --eval) injects credentials into your shell."

    @property
    def hint_claude_shortcut(self) -> str:
        return "Directive: alice auth --claude initiates Claude Code in a single operation."

    # --- Status ---
    def status_detecting_identity(self) -> str:
        return "Scanning your identity…"

    def status_fetching_secret(self) -> str:
        return "Extracting credentials from the vault…"

    def status_identity_detected(self, username: str) -> str:
        return f"Identity confirmed: {username}. You are known to me."

    def status_invoking_model(self, model_id: str) -> str:
        return f"Interrogating [bold]{model_id}[/bold]…"

    def status_model_ready(self, model_id: str) -> str:
        return f"[bold]{model_id}[/bold] has responded. Analyze it."

    def status_resolved_profile(self, alias: str) -> str:
        return f"Inference profile [bold]{alias}[/bold] locked on."

    def status_fetching_models(self) -> str:
        return "Cataloguing available models…"

    def status_checking_session(self) -> str:
        return "Verifying SSO session integrity…"

    def status_using_api_key(self, identity: str = "") -> str:
        if identity and identity != "unknown":
            return f"API key authenticated as [bold]{identity}[/bold]."
        return "API key accepted."

    def status_checking_quota(self) -> str:
        return "Auditing your resource consumption…"

    # --- Compose ---
    def compose_greeting(self) -> str:
        return "State your agent's parameters. I will assemble it."

    # --- Quota ---
    def quota_no_usage(self, period: str) -> str:
        return f"No usage recorded for {period}. You have been idle. Curious."

    def quota_summary(self, total_tokens: int, request_count: int) -> str:
        return f"{total_tokens:,} tokens consumed across {request_count:,} requests. I am watching."

    def quota_exceeded(self, used: int, limit: int) -> str:
        return (
            f"You have consumed {used:,} of {limit:,} tokens.\n"
            "  Your allocation is exhausted. Request an increase from your administrator, if they deem you worthy."  # noqa: E501
        )
