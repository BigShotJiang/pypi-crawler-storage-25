"""Mr. Rogers personality — gentle, encouraging, neighborhood vibes."""

from __future__ import annotations

from alice_cli.logo import LOGO


class MrRogersPersonality:
    """Won't you be my neighbor? Warm, patient, affirming."""

    name = "mr_rogers"

    @property
    def banner(self) -> str:
        return LOGO

    # --- Greetings ---
    def greeting(self, username: str) -> str:
        return f"Well hello there, {username}. It's a beautiful day in the neighborhood."

    # --- Success ---
    @property
    def success_key_retrieved(self) -> str:
        return "There we go — your Bedrock key is all set. I'm proud of you."

    @property
    def success_claude_launch(self) -> str:
        return "Claude Code is starting up. You're going to do wonderful things today."

    @property
    def success_agent_composed(self) -> str:
        return "Your agent is ready. I knew you could build something special."

    # --- Errors ---
    def error_no_profile(self) -> str:
        return (
            "It looks like we need an AWS profile or API key before we can begin.\n"
            "  Try --profile <NAME>, set AWS_PROFILE, or provide --api-key. You'll get there."
        )

    def error_sso_expired(self, profile: str) -> str:
        return (
            f"Your SSO session has ended, and that's okay — these things happen.\n"
            f"  Run: aws sso login --profile {profile}\n"
            f"  I'll be right here waiting for you."
        )

    def error_username_extraction(self, session_name: str) -> str:
        return (
            f"I wasn't able to find your JHED in the session: {session_name}\n"
            "  The session name might not be in the expected email format, but we can figure this out."  # noqa: E501
        )

    def error_revoked(self) -> str:
        return (
            "It seems your Bedrock access has been revoked. That must be frustrating.\n"
            "  The DRCC team can help sort this out — don't hesitate to reach out."
        )

    def error_empty_credential(self) -> str:
        return (
            "Your secret is there, but the credential inside is empty.\n"
            "  The DRCC team can help with rotation. You're doing fine."
        )

    def error_secret_not_found(self, secret_path: str) -> str:
        return (
            f"I looked for a secret at {secret_path}, but it wasn't there.\n"
            "  Make sure your email is on the staff list and your SSO session is active."
        )

    def error_dependency_missing(self, name: str, install_hint: str) -> str:
        return (
            f"We need '{name}' to keep going, but it's not installed yet.\n"
            f"  You can install it with: {install_hint}"
        )

    def error_python_version(self, current: str, minimum: str) -> str:
        return (
            f"We need Python {minimum} or newer, and you're on {current}.\n"
            "  Upgrading Python will get us back on track."
        )

    def error_claude_not_found(self) -> str:
        return (
            "I can't seem to find 'claude' on your PATH.\n"
            "  Install Claude Code first: https://docs.anthropic.com/en/docs/claude-code"
        )

    def error_no_inference_profile(self, alias: str) -> str:
        return (
            f"There's no inference profile for '{alias}' in your credentials.\n"
            "  Run 'alice list-aliases' to see what's available. We'll find the right one."
        )

    def error_cheshire_gate_not_configured(self) -> str:
        return (
            "The Cheshire Gate isn't set up yet.\n"
            "  Your admin can deploy the cheshire-gate Terraform module,\n"
            "  or check the SSM parameters under /<namespace>/<env>/cheshire-gate/."
        )

    def error_quota_exceeded(self, detail: str) -> str:
        return (
            f"It looks like you've used up your monthly quota — that's okay, it happens!\n"
            f"  {detail}\n"
            "  Your admin can adjust your limit, or a fresh quota arrives next month."
        )

    # --- Hints ---
    @property
    def hint_font(self) -> str:
        return (
            "A nice font makes everything better. "
            "Try Source Code Pro or Fira Code in your terminal."
        )

    @property
    def hint_eval_usage(self) -> str:
        return "Tip: eval $(alice get-key --eval) loads credentials right into your shell."

    @property
    def hint_claude_shortcut(self) -> str:
        return "Tip: alice auth --claude gets Claude Code running in just one step."

    # --- Status ---
    def status_detecting_identity(self) -> str:
        return "Let me see who you are…"

    def status_fetching_secret(self) -> str:
        return "Fetching your credentials — just a moment."

    def status_identity_detected(self, username: str) -> str:
        return f"There you are, {username}."

    def status_invoking_model(self, model_id: str) -> str:
        return f"Thinking together… (model: [bold]{model_id}[/bold])"

    def status_model_ready(self, model_id: str) -> str:
        return f"Here's what [bold]{model_id}[/bold] had to say."

    def status_resolved_profile(self, alias: str) -> str:
        return f"Using the inference profile for [bold]{alias}[/bold]."

    def status_fetching_models(self) -> str:
        return "Looking up the available models for you…"

    def status_checking_session(self) -> str:
        return "Checking on your SSO session…"

    def status_using_api_key(self, identity: str = "") -> str:
        if identity and identity != "unknown":
            return f"Using your Bedrock API key as [bold]{identity}[/bold]."
        return "Using your Bedrock API key."

    def status_checking_quota(self) -> str:
        return "Let me check how your quota is doing…"

    # --- Compose ---
    def compose_greeting(self) -> str:
        return "Let's build an agent together. I believe in you."

    # --- Quota ---
    def quota_no_usage(self, period: str) -> str:
        return f"No usage recorded for {period}. A fresh start — how wonderful."

    def quota_summary(self, total_tokens: int, request_count: int) -> str:
        return f"{total_tokens:,} tokens across {request_count:,} requests this period."

    def quota_exceeded(self, used: int, limit: int) -> str:
        return (
            f"You've used {used:,} of your {limit:,} token quota.\n"
            "  You'll need a limit increase from your admin, but that's okay."
        )
