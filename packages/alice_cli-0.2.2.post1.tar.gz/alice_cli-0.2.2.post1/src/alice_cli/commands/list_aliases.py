"""alice list-aliases — Show available model aliases."""

from __future__ import annotations

import json

import click

from alice_cli.console import print_table
from alice_cli.models import DEFAULT_MODEL_ALIAS, MODEL_ALIASES


@click.command("list-aliases")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON to stdout")
@click.pass_context
def list_aliases(ctx: click.Context, output_json: bool) -> None:
    """List model aliases and their Bedrock IDs."""
    if output_json:
        data = [
            {
                "alias": m.alias,
                "description": m.description,
                "modelId": m.model_id,
                "default": m.alias == DEFAULT_MODEL_ALIAS,
            }
            for m in MODEL_ALIASES
        ]
        click.echo(json.dumps(data, indent=2))
        return

    rows: list[list[str]] = []
    for m in MODEL_ALIASES:
        default_marker = " (default)" if m.alias == DEFAULT_MODEL_ALIAS else ""
        rows.append([m.alias + default_marker, m.description, m.model_id])

    print_table(
        title="Model Aliases",
        columns=["Alias", "Description", "Model ID"],
        rows=rows,
    )
