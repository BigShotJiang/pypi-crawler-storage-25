"""Clipboard utility for copying text via platform-specific subprocess calls."""

from __future__ import annotations

import subprocess
import sys


def copy_to_clipboard(text: str) -> bool:
    """Copy text to the system clipboard using platform-specific subprocess calls.

    Returns True on success, False on failure. Never raises.
    Uses pbcopy (macOS), xclip/xsel (Linux), clip (Windows).
    """
    try:
        if sys.platform == "darwin":
            cmd = ["pbcopy"]
        elif sys.platform == "win32":
            cmd = ["clip"]
        elif sys.platform.startswith("linux"):
            cmd = ["xclip", "-selection", "clipboard"]
        else:
            return False

        subprocess.run(cmd, input=text.encode(), check=True)
        return True
    except Exception:
        # xclip not available — try xsel as fallback on Linux
        if sys.platform.startswith("linux"):
            try:
                subprocess.run(
                    ["xsel", "--clipboard", "--input"],
                    input=text.encode(),
                    check=True,
                )
                return True
            except Exception:
                return False
        return False
