"""Data models for the cite pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from pydantic import BaseModel


class IdentifierType(str, Enum):
    """Supported academic identifier types."""

    DOI = "doi"
    ARXIV = "arxiv"
    PMID = "pmid"
    ISBN = "isbn"
    GITHUB = "github"
    ZENODO = "zenodo"
    SEMANTIC_SCHOLAR = "semantic_scholar"
    DBLP = "dblp"
    ORCID = "orcid"


@dataclass
class Identifier:
    """A recognized academic identifier extracted from a reference string."""

    type: IdentifierType
    value: str


class CitationType(str, Enum):
    """Supported bibliographic entry types."""

    ARTICLE = "article"
    CONFERENCE = "conference"
    BOOK = "book"
    SOFTWARE = "software"
    DATASET = "dataset"
    THESIS = "thesis"
    PREPRINT = "preprint"


class CitationRecord(BaseModel):
    """Core bibliographic record used throughout the pipeline."""

    entry_type: str = "article"
    citation_key: str = ""
    title: str = ""
    authors: list[str] = []
    year: str = ""
    journal: str = ""
    volume: str = ""
    number: str = ""
    pages: str = ""
    publisher: str = ""
    doi: str = ""
    url: str = ""
    abstract: str = ""
    isbn: str = ""
    arxiv_id: str = ""
    pmid: str = ""
    citation_type: CitationType | None = None
    extra_fields: dict[str, str] = {}
    warnings: list[str] = []
    resolved_source: IdentifierType | None = None
    verification_status: str = ""
    confidence_score: float = 0.0

    model_config = {"frozen": False}


@dataclass
class CleanedReference:
    """Result of cleaning and parsing a raw reference string."""

    original: str
    cleaned_text: str
    identifier: Identifier | None = field(default=None)
