"""Academic citation management for the alice CLI."""
