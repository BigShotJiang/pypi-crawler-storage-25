from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _version

try:
    __version__ = _version("alice-cli")
except PackageNotFoundError:
    # Fallback when running directly from source without an installed package.
    # poetry-dynamic-versioning substitutes this string at build time.
    __version__ = "0.0.0"
