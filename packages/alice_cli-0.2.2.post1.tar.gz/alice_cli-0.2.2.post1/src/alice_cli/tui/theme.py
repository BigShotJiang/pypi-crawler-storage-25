"""Amber retro color palette for the ALiCE TUI."""

AMBER = "#FFB000"  # Primary text — warm amber
AMBER_DIM = "#CC8800"  # Secondary/dim text
AMBER_BRIGHT = "#FFD866"  # Highlights, selected items
AMBER_BG = "#1A1100"  # Background — near-black with warm tint
AMBER_BG_LIGHT = "#2A1F00"  # Elevated surfaces (panels, modals)
AMBER_BORDER = "#805800"  # Borders and dividers
AMBER_ERROR = "#FF6600"  # Errors — orange-amber
AMBER_SUCCESS = "#88CC00"  # Success indicators — yellow-green
RETRO_BLUE = "#0A1628"  # Output panel background — retro terminal blue
RETRO_BLUE_BORDER = "#1A3A5C"  # Output panel border

# ── Soft palette variant — reduced contrast for extended sessions ─────────
SOFT_AMBER = "#CC9933"
SOFT_AMBER_DIM = "#997722"
SOFT_AMBER_BRIGHT = "#DDBB66"
SOFT_AMBER_BG = "#1A1500"
SOFT_AMBER_BG_LIGHT = "#221A00"
SOFT_AMBER_BORDER = "#665522"
SOFT_AMBER_ERROR = "#CC6633"
SOFT_AMBER_SUCCESS = "#77AA33"
SOFT_RETRO_BLUE = "#0D1A28"
SOFT_RETRO_BLUE_BORDER = "#1A3050"

# ── JHU DOS-blue palette — WordPerfect-style white-on-blue ────────────────
JHU_BLUE = "#002D72"  # JHU Heritage Blue — primary background
JHU_BLUE_LIGHT = "#003D8F"  # Elevated surfaces (panels, modals)
JHU_BLUE_DIM = "#001A44"  # Darker shade for depth
JHU_WHITE = "#FFFFFF"  # Primary text — bright white
JHU_WHITE_DIM = "#B0C4DE"  # Secondary/dim text — light steel blue
JHU_WHITE_BRIGHT = "#FFFFFF"  # Highlights, selected items
JHU_BORDER = "#4A7CC9"  # Borders and dividers — medium blue
JHU_HIGHLIGHT = "#FFD100"  # JHU Spirit Gold — accents and selections
JHU_ERROR = "#FF6666"  # Errors — soft red on blue
JHU_SUCCESS = "#66FF66"  # Success indicators — green on blue
JHU_STATUS_BAR = "#001A44"  # Status bar / footer background
