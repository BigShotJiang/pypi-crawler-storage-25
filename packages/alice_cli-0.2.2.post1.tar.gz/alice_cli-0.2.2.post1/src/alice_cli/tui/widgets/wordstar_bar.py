"""WordStar-style status bar for the ALiCE TUI.

Mimics the iconic WordStar command-reference ruler that sat at the top of
the editing area in WordStar 3.x / 4.x.  Shows a retro status line with
the current "document" name, cursor position, and available ^K/^O/^Q
block commands — purely decorative, but it sells the vibe.
"""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static

# The original WordStar status line looked roughly like:
#   B:LETTER.DOC  PAGE 1  LINE 12  COL 34  INSERT ON
# We adapt it for ALiCE.

_WS_COMMANDS = "^KS Save  ^KD Done  ^KB Block  ^KK End  ^QR Top  ^QC End"


class WordStarBar(Static):
    """A decorative WordStar-style command/status ruler."""

    DEFAULT_CSS = """
    WordStarBar {
        dock: top;
        width: 100%;
        height: 1;
        background: #2A1F00;
        color: #88CC00;
        text-style: bold;
        padding: 0 1;
    }
    """

    document: reactive[str] = reactive("TERMINAL")
    line: reactive[int] = reactive(1)
    col: reactive[int] = reactive(1)
    insert_mode: reactive[bool] = reactive(True)

    def render(self) -> str:  # type: ignore[override]
        mode = "INSERT" if self.insert_mode else "OVERWRITE"
        return (
            f" {self.document:<16} "
            f"LN {self.line:<5} COL {self.col:<4} "
            f"{mode:<10} "
            f"│ {_WS_COMMANDS}"
        )
