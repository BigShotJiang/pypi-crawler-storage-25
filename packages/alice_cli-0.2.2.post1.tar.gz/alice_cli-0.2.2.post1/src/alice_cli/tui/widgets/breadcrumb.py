"""Breadcrumb trail widget for the ALiCE TUI."""

from __future__ import annotations

from textual.reactive import reactive
from textual.widgets import Static


class BreadcrumbBar(Static):
    """Displays the current screen path as a breadcrumb trail.

    The ``path`` reactive list is maintained by ``AliceTUIApp`` — it
    appends on screen push and pops on screen pop, so the breadcrumb
    always reflects the live navigation stack.
    """

    DEFAULT_CSS = """
    BreadcrumbBar {
        width: 100%;
        height: 1;
        background: #2A1F00;
        color: #FFD866;
        padding: 0 2;
    }
    """

    path: reactive[list[str]] = reactive(list, always_update=True)

    def render(self) -> str:
        if not self.path:
            return ""
        return " › ".join(f"[#FFD866]{segment}[/]" for segment in self.path)

    def push(self, screen_name: str) -> None:
        """Append a screen name to the breadcrumb trail."""
        self.path = [*self.path, screen_name]

    def pop(self) -> None:
        """Remove the last screen name from the breadcrumb trail."""
        if self.path:
            self.path = self.path[:-1]
