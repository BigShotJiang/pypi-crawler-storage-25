"""Quit confirmation screen for the ALiCE TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Static

if TYPE_CHECKING:
    from textual.app import ComposeResult

_QUIT_ART = """\
 ╔════════════════════════════════════════════════════╗
 ║                    ╱╲    ╱╲                        ║
 ║                   ╱  ╲  ╱  ╲                       ║
 ║                  │    ╲╱    │                      ║
 ║                  │  o    o  │   ┌──────┐           ║
 ║                  │    ▽▽    │  ╱ ╭────╮ \          ║
 ║                   ╲  ════  ╱  │  │13 7│  │         ║
 ║                    ╲▄▄▄▄▄▄╱   │  │Q +6│  │         ║
 ║                   ┌┴──────┴┐  │  │3  9│  │         ║
 ║                   │ ▓▓▓▓▓▓ │   ╲ ╰────╯  │         ║
 ║                   │ ▓▓▓▓▓▓ │    └───┬───┘          ║
 ║                   │ ▓▓▓▓▓▓ │  ╭─────╯              ║
 ║                   └┬──────┬┘  │                    ║
 ║                   ╱│      │╲──╯                    ║
 ║                  ╱ │      │ ╲                      ║
 ║                 ╱  └──────┘  ╲                     ║
 ║                ╱   ╱      ╲   ╲                    ║
 ║               ▕___╱        ╲___▏                   ║
 ║                                                    ║
 ║         "Oh dear! Oh dear! Time to go!"            ║
 ║                                                    ║
 ║          Terminate session?   ( Y / N )            ║
 ║                                                    ║
 ╚════════════════════════════════════════════════════╝"""


class QuitScreen(ModalScreen[None]):
    """Modal CRT-style quit confirmation dialog."""

    BINDINGS = [
        ("y", "confirm", "Yes"),
        ("n", "cancel", "No"),
    ]

    DEFAULT_CSS = """
    QuitScreen {
        align: center middle;
    }

    #quit-dialog {
        width: auto;
        height: auto;
        padding: 0;
        background: #1A1100;
        border: none;
    }

    #quit-art {
        color: #FFB000;
        text-style: bold;
        text-align: center;
        width: auto;
    }

    #quit-buttons {
        align: center middle;
        width: 100%;
        margin-top: 1;
    }

    #quit-buttons Button {
        margin: 0 2;
        min-width: 16;
    }

    #btn-quit-yes {
        background: #2A1F00;
        color: #FF6600;
        border: tall #FF6600;
    }

    #btn-quit-yes:hover {
        background: #805800;
        color: #FFD866;
    }

    #btn-quit-no {
        background: #2A1F00;
        color: #88CC00;
        border: tall #88CC00;
    }

    #btn-quit-no:hover {
        background: #805800;
        color: #FFD866;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="quit-dialog"):
            yield Static(_QUIT_ART, id="quit-art")
            with Horizontal(id="quit-buttons"):
                yield Button("[Y] Quit", id="btn-quit-yes", variant="error")
                yield Button("[N] Cancel", id="btn-quit-no")

    def action_confirm(self) -> None:
        self.app.exit()

    def action_cancel(self) -> None:
        self.app.pop_screen()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-quit-yes":
            self.app.exit()
        else:
            self.app.pop_screen()
