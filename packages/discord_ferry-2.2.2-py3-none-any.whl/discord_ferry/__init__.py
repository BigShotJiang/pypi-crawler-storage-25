"""Discord Ferry — Migrate Discord servers to Stoat."""

__version__ = "2.2.2"
