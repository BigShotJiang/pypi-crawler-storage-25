"""Tests for smoke-test orchestration (coord/smoke.py)."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from coord.config import Config, SmokeRule, SmokeTestsConfig, load
from coord.models import Assignment, Board, Machine, Repo
from coord.smoke import (
    SMOKE_SYSTEM_PROMPT,
    build_smoke_briefing,
    dispatch_smoke,
    match_rules,
    pick_smoke_machine,
)


# ── Fixtures ────────────────────────────────────────────────────────────────


@pytest.fixture
def repo() -> Repo:
    return Repo(
        name="api", github="acme/api", depends_on=[], default_branch="main",
        test_command="make test",
    )


def _machine(name: str, host: str, *, caps: list[str], path: str = "/work/api") -> Machine:
    return Machine(
        name=name, host=host, capabilities=caps, repos=["api"],
        repo_paths={"api": path},
    )


@pytest.fixture
def gtk_and_server_config(repo: Repo) -> Config:
    return Config(
        repos=[repo],
        machines=[
            _machine("server", "server.tail", caps=["python"], path="/srv/api"),
            _machine("desktop-a", "desktop-a.tail", caps=["python", "gtk"], path="/d/api"),
        ],
        smoke_tests=SmokeTestsConfig(
            auto_queue=True,
            capability_rules=[
                SmokeRule(files=["src/gtk/"], requires=["gtk"]),
                SmokeRule(files=["src/tui_main/"], requires=["terminal"]),
            ],
        ),
    )


def _completed(
    *, machine: str = "server", branch: str = "issue-1-fix", repo: str = "api",
) -> Assignment:
    return Assignment(
        machine_name=machine,
        repo_name=repo,
        issue_number=287,
        issue_title="GTK key routing fix",
        briefing="Worker briefing",
        assignment_id="abc123",
        status="done",
        branch=branch,
        dispatched_at=0.0,
        finished_at=1.0,
        type="work",
    )


# ── Rule matching ───────────────────────────────────────────────────────────


def test_match_rules_returns_required_capabilities() -> None:
    rules = [
        SmokeRule(files=["src/gtk/"], requires=["gtk"]),
        SmokeRule(files=["src/tui_main/"], requires=["terminal"]),
    ]
    caps = match_rules(["src/gtk/window.c", "src/lib/util.c"], rules)
    assert caps == ["gtk"]


def test_match_rules_unions_caps_across_rules() -> None:
    rules = [
        SmokeRule(files=["src/gtk/"], requires=["gtk"]),
        SmokeRule(files=["src/tui_main/"], requires=["terminal"]),
    ]
    caps = match_rules(["src/gtk/a.c", "src/tui_main/b.c"], rules)
    assert set(caps) == {"gtk", "terminal"}


def test_match_rules_returns_empty_for_no_match() -> None:
    rules = [SmokeRule(files=["src/gtk/"], requires=["gtk"])]
    assert match_rules(["docs/README.md", "src/core/util.c"], rules) == []


def test_match_rules_deduplicates_capabilities() -> None:
    rules = [
        SmokeRule(files=["src/gtk/"], requires=["gtk"]),
        SmokeRule(files=["app/gtk_main.c"], requires=["gtk"]),
    ]
    caps = match_rules(["src/gtk/x.c", "app/gtk_main.c"], rules)
    assert caps == ["gtk"]


def test_match_rules_no_trailing_slash_matches_files_too() -> None:
    """A rule `src/gtk` (no slash) is the loose form — catches gtk_helpers.c."""
    rules = [SmokeRule(files=["src/gtk"], requires=["gtk"])]
    assert match_rules(["src/gtk_helpers.c"], rules) == ["gtk"]


# ── Machine selection ───────────────────────────────────────────────────────


def test_pick_smoke_prefers_capable_machine_different_from_worker(
    gtk_and_server_config: Config,
) -> None:
    board = Board()
    choice = pick_smoke_machine(
        ["gtk"], "api", "server", board, gtk_and_server_config
    )
    assert choice is not None
    assert choice.machine.name == "desktop-a"
    assert choice.is_worker is False


def test_pick_smoke_returns_none_when_no_machine_has_capability(
    gtk_and_server_config: Config,
) -> None:
    cfg = replace(
        gtk_and_server_config,
        machines=[_machine("server", "server.tail", caps=["python"])],
    )
    choice = pick_smoke_machine(["gtk"], "api", "server", Board(), cfg)
    assert choice is None


def test_pick_smoke_falls_back_to_worker_machine_when_only_capable(
    repo: Repo,
) -> None:
    cfg = Config(
        repos=[repo],
        machines=[_machine("desktop-a", "d.tail", caps=["python", "gtk"])],
        smoke_tests=SmokeTestsConfig(auto_queue=True),
    )
    choice = pick_smoke_machine(["gtk"], "api", "desktop-a", Board(), cfg)
    assert choice is not None
    assert choice.machine.name == "desktop-a"
    assert choice.is_worker is True
    assert "same machine" in choice.rationale


def test_pick_smoke_picks_busy_different_over_idle_worker(repo: Repo) -> None:
    """Capability + different-machine wins over idle but worker."""
    cfg = Config(
        repos=[repo],
        machines=[
            _machine("server", "server.tail", caps=["python", "gtk"]),
            _machine("desktop-a", "d.tail", caps=["python", "gtk"]),
        ],
        smoke_tests=SmokeTestsConfig(auto_queue=True),
    )
    board = Board(active=[
        Assignment(
            machine_name="desktop-a", repo_name="api", issue_number=99,
            issue_title="other", status="running", assignment_id="x",
        )
    ])
    choice = pick_smoke_machine(["gtk"], "api", "server", board, cfg)
    assert choice is not None
    assert choice.machine.name == "desktop-a"
    assert "busy" in choice.rationale


# ── Config parsing ──────────────────────────────────────────────────────────


def test_smoke_config_defaults(tmp_path: Path) -> None:
    p = tmp_path / "coordinator.yml"
    p.write_text(
        "repos:\n  - name: api\n    github: acme/api\n"
        "machines:\n  - name: laptop\n    host: laptop.tail\n    repos: [api]\n"
    )
    cfg = load(p)
    assert cfg.smoke_tests.auto_queue is False
    assert cfg.smoke_tests.capability_rules == []


def test_smoke_config_parses_capability_rules(tmp_path: Path) -> None:
    p = tmp_path / "coordinator.yml"
    p.write_text(
        """\
repos:
  - name: api
    github: acme/api
machines:
  - name: laptop
    host: laptop.tail
    repos: [api]
smoke_tests:
  auto_queue: true
  default_command: "make smoke"
  timeout_seconds: 300
  capability_rules:
    - files: ["src/gtk/"]
      requires: [gtk]
    - files: ["src/tui_main/"]
      requires: [terminal]
"""
    )
    cfg = load(p)
    assert cfg.smoke_tests.auto_queue is True
    assert cfg.smoke_tests.default_command == "make smoke"
    assert cfg.smoke_tests.timeout_seconds == 300
    assert len(cfg.smoke_tests.capability_rules) == 2
    assert cfg.smoke_tests.capability_rules[0].requires == ["gtk"]


def test_smoke_config_rejects_empty_files_or_requires(tmp_path: Path) -> None:
    from coord.config import ConfigError

    p = tmp_path / "coordinator.yml"
    p.write_text(
        """\
repos:
  - name: api
    github: acme/api
machines:
  - name: laptop
    host: laptop.tail
    repos: [api]
smoke_tests:
  auto_queue: true
  capability_rules:
    - files: []
      requires: [gtk]
"""
    )
    with pytest.raises(ConfigError, match="files must be non-empty"):
        load(p)


# ── Briefing assembly ───────────────────────────────────────────────────────


def test_briefing_includes_branch_command_and_required_caps() -> None:
    briefing = build_smoke_briefing(
        repo_github="acme/api",
        repo_name="api",
        branch="issue-287-fix",
        issue_number=287,
        issue_title="GTK fix",
        smoke_command="make smoke",
        required_caps=["gtk"],
        timeout_seconds=600,
        is_worker=False,
    )
    assert "issue-287-fix" in briefing
    assert "make smoke" in briefing
    assert "gtk" in briefing
    assert "SMOKE: pass" in briefing
    assert "running on the same machine" not in briefing


def test_briefing_warns_when_run_on_worker_machine() -> None:
    briefing = build_smoke_briefing(
        repo_github="acme/api", repo_name="api", branch="b",
        issue_number=1, issue_title="X", smoke_command="cmd",
        required_caps=["gtk"], timeout_seconds=60, is_worker=True,
    )
    assert "running on the same machine" in briefing


# ── dispatch_smoke (HTTP mocked) ────────────────────────────────────────────


class _FakeResp:
    def __init__(self, payload: dict) -> None:
        self._p = payload

    def raise_for_status(self) -> None:
        return None

    def json(self) -> dict:
        return self._p


class _FakeClient:
    def __init__(self, payload: dict) -> None:
        self._p = payload
        self.calls: list[tuple[str, dict]] = []

    def post(self, url, *, json, timeout) -> _FakeResp:
        self.calls.append((url, json))
        return _FakeResp(self._p)


def test_dispatch_smoke_skipped_when_auto_queue_off(
    gtk_and_server_config: Config,
) -> None:
    cfg = replace(
        gtk_and_server_config,
        smoke_tests=replace(gtk_and_server_config.smoke_tests, auto_queue=False),
    )
    result = dispatch_smoke(
        _completed(), Board(), cfg,
        http_client=_FakeClient({"id": "x"}),
        diff_lookup=lambda repo, branch: ["src/gtk/window.c"],
    )
    assert result is None


def test_dispatch_smoke_skipped_when_no_rule_matches(
    gtk_and_server_config: Config,
) -> None:
    result = dispatch_smoke(
        _completed(), Board(), gtk_and_server_config,
        http_client=_FakeClient({"id": "x"}),
        diff_lookup=lambda repo, branch: ["docs/README.md"],
    )
    assert result is None


def test_dispatch_smoke_skipped_for_failed_or_review(
    gtk_and_server_config: Config,
) -> None:
    failed = replace(_completed(), status="failed")
    review = replace(_completed(), type="review")
    diff = lambda repo, branch: ["src/gtk/x.c"]
    assert dispatch_smoke(
        failed, Board(), gtk_and_server_config,
        http_client=_FakeClient({"id": "x"}), diff_lookup=diff,
    ) is None
    assert dispatch_smoke(
        review, Board(), gtk_and_server_config,
        http_client=_FakeClient({"id": "x"}), diff_lookup=diff,
    ) is None


def test_dispatch_smoke_sends_to_capable_different_machine(
    gtk_and_server_config: Config,
) -> None:
    board = Board()
    client = _FakeClient({"id": "smoke-1"})
    result = dispatch_smoke(
        _completed(machine="server"), board, gtk_and_server_config,
        http_client=client,
        diff_lookup=lambda repo, branch: ["src/gtk/window.c"],
        now=42.0,
    )
    assert result is not None
    assert result.type == "smoke"
    assert result.machine_name == "desktop-a"  # has gtk; server doesn't
    assert result.assignment_id == "smoke-1"
    assert result.review_of_assignment_id == "abc123"
    assert result.dispatched_at == 42.0
    assert board.active == [result]

    assert len(client.calls) == 1
    url, payload = client.calls[0]
    assert "desktop-a.tail" in url
    assert payload["type"] == "smoke"
    assert payload["system_prompt"] == SMOKE_SYSTEM_PROMPT
    assert payload["review_target"] == "issue-1-fix"
    assert payload["repo_path"] == "/d/api"
    # Briefing should mention the test_command fallback (make test).
    assert "make test" in payload["briefing"]


def test_dispatch_smoke_uses_default_command_when_set(
    gtk_and_server_config: Config,
) -> None:
    cfg = replace(
        gtk_and_server_config,
        smoke_tests=replace(
            gtk_and_server_config.smoke_tests,
            default_command="make smoke",
        ),
    )
    client = _FakeClient({"id": "s2"})
    result = dispatch_smoke(
        _completed(), Board(), cfg, http_client=client,
        diff_lookup=lambda repo, branch: ["src/gtk/x.c"],
    )
    assert result is not None
    assert "make smoke" in client.calls[0][1]["briefing"]


def test_dispatch_smoke_returns_none_on_http_failure(
    gtk_and_server_config: Config,
) -> None:
    import httpx

    class _Bad:
        def post(self, url, *, json, timeout):
            raise httpx.ConnectError("unreachable")

    board = Board()
    result = dispatch_smoke(
        _completed(), board, gtk_and_server_config,
        http_client=_Bad(),
        diff_lookup=lambda repo, branch: ["src/gtk/x.c"],
    )
    assert result is None
    assert board.active == []


def test_dispatch_smoke_returns_none_when_no_capable_machine(
    repo: Repo,
) -> None:
    cfg = Config(
        repos=[repo],
        machines=[_machine("server", "server.tail", caps=["python"])],
        smoke_tests=SmokeTestsConfig(
            auto_queue=True,
            capability_rules=[SmokeRule(files=["src/gtk/"], requires=["gtk"])],
        ),
    )
    result = dispatch_smoke(
        _completed(), Board(), cfg,
        http_client=_FakeClient({"id": "x"}),
        diff_lookup=lambda repo, branch: ["src/gtk/x.c"],
    )
    assert result is None
