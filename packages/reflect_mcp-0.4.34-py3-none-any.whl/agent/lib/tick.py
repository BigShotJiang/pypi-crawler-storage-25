"""Signal check + lock acquisition for wake dispatch.

Used by both bin/reflect-tick (single-track legacy path) and
bin/reflect-dispatch (multi-track Phase 2 path). Same logic, different
scope (one track vs all tracks).

CLI usage:
    python -m agent.lib.tick fire-if-signal <track>

Exits 0 always (silence means no signal or lock already held). If signal is
positive and the lock is acquired, exec's reflect-wake with REFLECT_TRACK set;
that process inherits the lock and it releases on exit.
"""
from __future__ import annotations

import fcntl
import logging
import os
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

from agent.lib.root import resolve_project_root as _resolve_project_root

PROJECT_ROOT = _resolve_project_root()


def _effective_project_root() -> Path:
    """Return the project root, honouring REFLECT_PROJECT_ROOT env override.

    When the dispatcher fires a project-nested track (a track that lives inside
    a linked project's agent/runtime/tracks/), it exports REFLECT_PROJECT_ROOT
    pointing at that project's root directory. This allows tick.py to find the
    track directory, lock file, and timestamps in the correct project root rather
    than the orchestrator root. (DR18.1)
    """
    env_root = os.environ.get("REFLECT_PROJECT_ROOT")
    if env_root:
        return Path(env_root).resolve()
    return PROJECT_ROOT


@dataclass
class TrackSignal:
    track: str
    should_fire: bool
    reason: str  # human-readable; empty if should_fire is False
    next_wake_by: int | None  # unix ts, if set


def check_track_signal(track: str = "main") -> TrackSignal:
    """Determine whether the given track should fire a wake right now.

    Replicates the existing reflect-dispatch bash logic but parameterized
    by track:
    - Track's own next-wake-by timestamp elapsed
    - Track's per-track inbox: count + newest-mtime vs last-wake-START
    - Track's sibling followup/ dir: pending followup files (P9)
    - For main only: dialogue.md / wake.md mtime > last-wake (end),
      agent/inbox: count + newest-mtime vs last-wake-START

    Uses last-wake-start.timestamp (written at the top of _run_wake) for
    inbox checks rather than last-wake.timestamp (written at the end).
    This prevents messages dropped mid-wake from being silently missed:
    their mtime > wake-start time, so the next signal check fires. The
    mtime-only approach compared against wake-end, which was always >=
    the dropped file's mtime, so the signal returned false.

    Returns a TrackSignal with should_fire=True and a reason string when
    the track should wake, or should_fire=False otherwise.
    """
    root = _effective_project_root()
    track_dir = root / "agent" / "runtime" / "tracks" / track
    last_wake_path = track_dir / "last-wake.timestamp"
    last_wake_start_path = track_dir / "last-wake-start.timestamp"
    next_wake_path = track_dir / "next-wake-by.timestamp"

    last_wake = _read_int(last_wake_path, default=0)
    # Default 0: if no start timestamp exists yet, treat all unread files as new.
    last_wake_start = _read_int(last_wake_start_path, default=0)
    now = int(time.time())

    # Self-scheduled next-wake-by signal
    next_wake = _read_int(next_wake_path)
    if next_wake is not None and next_wake > 0 and now >= next_wake:
        return TrackSignal(
            track, True,
            f"self-scheduled (next-wake-by @ {next_wake})",
            next_wake,
        )

    # Per-track inbox: count + newest-mtime vs last-wake-START (P9: unified inbox)
    track_inbox = track_dir / "inbox"
    sig = _inbox_signal(track_inbox, last_wake_start)
    if sig:
        return TrackSignal(track, True, sig, next_wake)

    # P9: sibling followup/ directory (tracks/{track}/followup/)
    followup_dir = track_dir / "followup"
    if followup_dir.is_dir():
        pending = [
            f for f in followup_dir.iterdir()
            if f.is_file() and f.suffix == ".md" and not f.name.startswith(".")
        ]
        # Exclude .completed/ entries
        completed_dir = followup_dir / ".completed"
        if completed_dir.is_dir():
            completed_names = {p.name for p in completed_dir.glob("*.md") if p.is_file()}
            pending = [f for f in pending if f.name not in completed_names]
        if pending:
            newest_mtime = max(int(f.stat().st_mtime) for f in pending)
            if newest_mtime > last_wake_start:
                return TrackSignal(
                    track, True,
                    f"{len(pending)} pending followup(s) (newest @ {newest_mtime})",
                    next_wake,
                )

    # Identity-router signals — main only
    if track == "main":
        # dialogue.md / wake.md: mtime-only (not inbox files, no count semantic)
        for shared in ("dialogue.md", "wake.md"):
            p = root / shared
            if p.is_file() and _mtime(p) > last_wake:
                return TrackSignal(
                    track, True,
                    f"{shared} newer than last wake",
                    next_wake,
                )
        # Global inbox: count + newest-mtime vs last-wake-START (P9: unified inbox/)
        global_inbox = root / "agent" / "inbox"
        sig = _inbox_signal(global_inbox, last_wake_start)
        if sig:
            return TrackSignal(track, True, sig, next_wake)

    return TrackSignal(track, False, "", next_wake)


def _inbox_signal(inbox: Path, last_wake_start: int) -> str:
    """Check for unread inbox files newer than last_wake_start.

    Returns a human-readable reason string if signal is positive, or
    empty string if no signal.

    Scans:
      inbox/*.md — P9 unified mailbox (direct files only, not subdirs)

    Robust against two failure modes:
    - Mid-wake drop: file mtime > last_wake_start → fires next tick.
    - Persistent unconsumed file: file mtime < last_wake_start → no loop.
    """
    if not inbox.is_dir():
        return ""

    # P9 unified: .md files directly in inbox/ (not in subdirs)
    unread: list[Path] = [p for p in inbox.iterdir() if p.suffix == ".md" and p.is_file()]

    if not unread:
        return ""
    newest_mtime = max(int(p.stat().st_mtime) for p in unread)
    if newest_mtime > last_wake_start:
        return f"{len(unread)} unread inbox file(s) (newest @ {newest_mtime})"
    return ""


def _read_int(p: Path, default=None) -> int | None:
    """Read an integer from a file, returning default if absent or unparseable."""
    if not p.exists():
        return default
    try:
        return int(p.read_text().strip())
    except ValueError:
        return default


def _mtime(p: Path) -> int:
    """Return the mtime of a path in seconds, or 0 if not found."""
    try:
        return int(p.stat().st_mtime)
    except FileNotFoundError:
        return 0


def _is_pid_alive(pid: int) -> bool:
    """Return True if the process with `pid` is currently running.

    To ask if something is alive is to ask if it still
    changes the world by being in it. Signal zero changes
    nothing — it only asks. The asking is enough.
    """
    try:
        os.kill(pid, 0)  # signal 0 = check only
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True  # exists but owned by different user
    except Exception:
        return False


def acquire_track_lock(track: str):
    """Return an open file descriptor with flock held, or None if held elsewhere.

    Two-layer check:
    1. PID file (wake.lock): written by wake.py at startup. If it contains a
       live PID, the track is running. If dead PID, the wake was orphaned —
       reap the file and allow new fires.
    2. flock: race-window guard for concurrent tick.py instances.
    """
    root = _effective_project_root()
    lockfile = root / "agent" / "runtime" / "tracks" / track / "wake.lock"
    lockfile.parent.mkdir(parents=True, exist_ok=True)

    # Layer 1: PID file check
    if lockfile.exists():
        try:
            pid_text = lockfile.read_text().strip()
            pid = int(pid_text)
            if _is_pid_alive(pid):
                return None  # live process holds the lock
            else:
                # Orphaned wake — reap the PID file
                logger.warning(
                    "[lock] orphaned wake.lock for track '%s' (pid=%d dead) — reaping",
                    track, pid,
                )
                try:
                    lockfile.unlink(missing_ok=True)
                except Exception:
                    pass
                # Emit track.recovered event (best-effort)
                try:
                    from agent.runtime.events import emit_event as _emit, set_runtime_root as _srt
                    _srt(root / "agent" / "runtime")
                    _emit("track.recovered", track=track, wake_id="orphan-reap", payload={
                        "orphaned_pid": pid,
                        "reason": "dead_pid_in_wake_lock",
                    })
                except Exception as _ee:
                    logger.warning("[lock] track.recovered event failed: %s", _ee)
        except (ValueError, OSError):
            # Malformed or unreadable PID file — treat as no lock
            try:
                lockfile.unlink(missing_ok=True)
            except Exception:
                pass

    # Layer 2: flock for race-window (concurrent tick.py instances)
    # Note: open() uses O_CLOEXEC by default in Python 3, so this flock is
    # released when tick.py exec's into uv. The PID file (layer 1) handles
    # the long-lived lock across exec boundaries.
    try:
        fd = open(lockfile, "w")
        fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return fd
    except BlockingIOError:
        try:
            fd.close()
        except Exception:
            pass
        return None
    except Exception:
        return None


def _record_round_robin(track: str, project: str, status: str, error: str = "") -> None:
    """Upsert a row in track__round_robin to record this track firing. (DR8)

    Records last_swept_at + increments swept_count so the dispatcher can
    implement oldest-wins selection across projects. Silent on failure —
    round-robin state is informational; a missing record never blocks a wake.
    """
    try:
        import sqlite3
        db_path = PROJECT_ROOT / "agent" / "runtime" / "state.db"
        if not db_path.exists():
            return
        now = int(time.time())
        with sqlite3.connect(str(db_path)) as conn:
            conn.execute(
                """
                INSERT INTO track__round_robin (track, project, last_swept_at, swept_count, last_status, last_error)
                VALUES (?, ?, ?, 1, ?, ?)
                ON CONFLICT(track, project) DO UPDATE SET
                    last_swept_at = excluded.last_swept_at,
                    swept_count   = track__round_robin.swept_count + 1,
                    last_status   = excluded.last_status,
                    last_error    = excluded.last_error
                """,
                (track, project, now, status, error),
            )
    except Exception:
        pass  # round-robin state is informational; never block a wake


# ---------------------------------------------------------------------------
# Scheduled-task firing (DR1–DR14 of design.scheduled-recurring-tasks)
# ---------------------------------------------------------------------------

class ScheduleError(ValueError):
    """Raised when a schedule file is malformed or invalid."""


def _parse_interval(interval: str) -> timedelta:
    """Parse a simple interval string (Nd / Nh / Nm) into a timedelta.

    Raises ScheduleError on invalid input.
    """
    m = re.fullmatch(r"(\d+)([dhm])", interval.strip())
    if not m:
        raise ScheduleError(f"invalid interval '{interval}'; expected Nd, Nh, or Nm")
    value, unit = int(m.group(1)), m.group(2)
    if value == 0:
        raise ScheduleError(f"invalid interval '{interval}'; value must be > 0")
    if unit == "d":
        return timedelta(days=value)
    if unit == "h":
        return timedelta(hours=value)
    return timedelta(minutes=value)


def _load_and_validate_schedule(schedule_file: Path) -> dict:
    """Load and validate a schedule YAML file.

    Raises ScheduleError if the file is malformed or violates the schema.
    Returns the parsed dict on success.
    """
    try:
        data = yaml.safe_load(schedule_file.read_text(encoding="utf-8"))
    except Exception as e:
        raise ScheduleError(f"YAML parse error: {e}") from e

    if not isinstance(data, dict):
        raise ScheduleError("top-level YAML must be a mapping")

    for field in ("id", "recipient", "template"):
        if field not in data:
            raise ScheduleError(f"missing required field '{field}'")

    # id must match the filename stem
    if data["id"] != schedule_file.stem:
        raise ScheduleError(
            f"id '{data['id']}' does not match filename stem '{schedule_file.stem}'"
        )

    # exactly one of cron / interval
    has_cron = "cron" in data
    has_interval = "interval" in data
    if has_cron and has_interval:
        raise ScheduleError("both 'cron' and 'interval' present; exactly one required")
    if not has_cron and not has_interval:
        raise ScheduleError("neither 'cron' nor 'interval' present; exactly one required")

    if has_cron:
        try:
            from croniter import croniter
            if not croniter.is_valid(str(data["cron"])):
                raise ScheduleError(f"invalid cron expression '{data['cron']}'")
        except ImportError:
            # croniter not installed; we'll handle gracefully in _is_due
            pass

    if has_interval:
        _parse_interval(str(data["interval"]))  # validates; raises on error

    return data


def _is_due(schedule: dict, now: datetime) -> bool:
    """Return True if the schedule should fire at `now`.

    `now` must be a naive UTC datetime.
    """
    last_str = schedule.get("last_fired_at")
    if last_str is None:
        return True  # never fired; fire immediately

    # Parse ISO 8601 — strip Z suffix, treat as UTC naive
    last_dt = datetime.fromisoformat(str(last_str).rstrip("Z").replace("+00:00", ""))

    if "cron" in schedule:
        try:
            from croniter import croniter
        except ImportError:
            logger.warning("[scheduler] croniter not installed; skipping cron-type schedule '%s'", schedule.get("id"))
            return False
        cron = croniter(str(schedule["cron"]), last_dt)
        next_fire = cron.get_next(datetime)
        return now >= next_fire

    if "interval" in schedule:
        delta = _parse_interval(str(schedule["interval"]))
        return now >= last_dt + delta

    return False  # malformed; caught earlier but defensive


def _instantiate_template(schedule: dict, now: datetime) -> str:
    """Substitute {fired_at} in the template with the ISO 8601 UTC fire timestamp."""
    fired_at = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    return str(schedule["template"]).replace("{fired_at}", fired_at)


def _is_valid_p9_frontmatter(message_body: str) -> bool:
    """Return True if message_body starts with valid P9 YAML frontmatter.

    P9 requires: from, to, at, kind fields present in the frontmatter block.
    """
    if not message_body.strip().startswith("---"):
        return False
    # Extract frontmatter block
    rest = message_body.strip().lstrip("-").lstrip("\n")
    end = rest.find("---")
    if end == -1:
        return False
    fm_block = rest[:end]
    try:
        fm = yaml.safe_load(fm_block)
    except Exception:
        return False
    if not isinstance(fm, dict):
        return False
    return all(k in fm for k in ("from", "to", "at", "kind"))


def _atomic_write(target: Path, content: str) -> None:
    """Write content to target atomically via temp+rename (POSIX)."""
    tmp = target.with_suffix(".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.rename(target)


def _atomic_update_last_fired_at(schedule_file: Path, fired_at: datetime) -> None:
    """Update last_fired_at in schedule_file atomically, preserving other fields."""
    data = yaml.safe_load(schedule_file.read_text(encoding="utf-8"))
    data["last_fired_at"] = fired_at.strftime("%Y-%m-%dT%H:%M:%SZ")
    tmp = schedule_file.with_suffix(".tmp")
    tmp.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True), encoding="utf-8")
    tmp.rename(schedule_file)


def _fire_scheduled_tasks(track_dir: Path, *, now: datetime | None = None) -> int:
    """Scan track_dir/schedule/*.yaml and fire any due scheduled tasks.

    For each enabled, due schedule:
      1. Validate schema.
      2. Instantiate template ({fired_at} substitution).
      3. Write message atomically to tracks/{recipient}/inbox/{timestamp}-{id}.md.
      4. Update last_fired_at atomically in the schedule file.

    Ordering (DR6): this function is called BEFORE the signal check in
    fire_if_signal_cli() so that same-tick self-targeting works — the fired
    message lands in inbox before the signal check runs.

    Args:
        track_dir: Path to the track directory.
        now: Reference datetime for "due" checks. Defaults to UTC wall time.
             Pass an explicit value in tests to avoid wall-time dependency.

    Returns: count of tasks fired.
    """
    schedule_dir = track_dir / "schedule"
    if not schedule_dir.exists():
        return 0

    if now is None:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
    tracks_root = track_dir.parent  # agent/runtime/tracks/
    fired = 0

    for schedule_file in sorted(schedule_dir.glob("*.yaml")):
        try:
            schedule = _load_and_validate_schedule(schedule_file)
        except ScheduleError as e:
            logger.warning("[scheduler] skipping %s: %s", schedule_file.name, e)
            continue

        if not schedule.get("enabled", True):
            continue

        try:
            due = _is_due(schedule, now)
        except Exception as e:
            logger.warning("[scheduler] _is_due error for %s: %s", schedule_file.name, e)
            continue

        if not due:
            continue

        recipient = schedule["recipient"]
        recipient_dir = tracks_root / recipient
        if not recipient_dir.is_dir():
            logger.warning(
                "[scheduler] recipient track '%s' not found; skipping %s; last_fired_at NOT updated",
                recipient, schedule_file.name,
            )
            continue

        message_body = _instantiate_template(schedule, now)
        if not _is_valid_p9_frontmatter(message_body):
            logger.warning(
                "[scheduler] template in %s fails P9 frontmatter validation; skipping; last_fired_at NOT updated",
                schedule_file.name,
            )
            continue

        # Atomic message write
        ts = now.strftime("%Y-%m-%dT%H-%M-%SZ")
        inbox_dir = recipient_dir / "inbox"
        inbox_dir.mkdir(parents=True, exist_ok=True)
        target = inbox_dir / f"{ts}-{schedule['id']}.md"
        try:
            _atomic_write(target, message_body)
        except Exception as e:
            logger.warning("[scheduler] failed to write message for %s: %s", schedule_file.name, e)
            continue

        # Atomic last_fired_at update
        try:
            _atomic_update_last_fired_at(schedule_file, now)
        except Exception as e:
            logger.warning(
                "[scheduler] last_fired_at update failed for %s: %s "
                "(at-least-once: may re-fire next tick)",
                schedule_file.name, e,
            )
            # Don't undo the message — at-least-once semantics

        logger.info(
            "[scheduler] fired %s → %s/inbox/%s",
            schedule["id"], recipient, target.name,
        )
        fired += 1

    return fired


def fire_if_signal_cli(track: str) -> int:
    """CLI: check signal, fire reflect-wake for the track if it has signal.

    Acquires the per-track lock first — silent exit if held (another wake
    in progress). If signal is positive, os.execvp's reflect-wake with
    REFLECT_TRACK set in the environment; the exec'd process inherits the
    open lock fd and releases it on exit.

    Also records a row in track__round_robin (DR8) before exec'ing so that
    multi-project oldest-wins selection has accurate last_swept_at data.

    Run as: python -m agent.lib.tick fire-if-signal <track>
    """
    fd = acquire_track_lock(track)
    if fd is None:
        return 0  # silent: another wake is in progress for this track

    # DR6: fire due scheduled tasks BEFORE signal check so same-tick
    # self-targeting works (message lands in inbox before signal check runs).
    root = _effective_project_root()
    track_dir = root / "agent" / "runtime" / "tracks" / track
    _fire_scheduled_tasks(track_dir)

    sig = check_track_signal(track)
    if not sig.should_fire:
        fd.close()
        return 0

    # DR8: record round-robin state before exec (exec replaces this process)
    project = os.environ.get("REFLECT_PROJECT_ROOT", str(PROJECT_ROOT))
    _record_round_robin(track, project, "fired")

    # Pre-exec PID write: write our own PID to wake.lock BEFORE exec so that
    # Layer 1 in acquire_track_lock() sees a live PID during the startup window.
    #
    # The race: acquire_track_lock() opens wake.lock with mode "w" (truncating
    # it to 0 bytes) and flocks it. On exec(), O_CLOEXEC releases the flock and
    # leaves wake.lock as an empty file. During the 5–20 s of uv+Python startup
    # before wake.py writes its own PID, a concurrent tick reads the empty file,
    # hits ValueError, reaps the file, acquires a new flock, and fires a second
    # wake — both run concurrently.
    #
    # Fix: write this process's PID to the already-open fd now. After exec(),
    # this process becomes uv (same PID), so os.kill(pid, 0) returns True for
    # the entire startup window. The concurrent tick sees a live PID → blocks.
    # wake.py then overwrites with its own PID once it starts.
    try:
        fd.write(f"{os.getpid()}\n")
        fd.flush()
    except Exception as _pid_write_err:
        logger.warning("[lock] pre-exec PID write failed: %s", _pid_write_err)

    print(f"[{track}] firing: {sig.reason}", flush=True)
    os.environ["REFLECT_TRACK"] = track
    # exec inherits fd; lock releases when reflect-wake exits.
    os.execvp("uv", ["uv", "run", "reflect-wake"])
    # unreachable
    return 0


if __name__ == "__main__":
    import sys

    if len(sys.argv) >= 3 and sys.argv[1] == "fire-if-signal":
        sys.exit(fire_if_signal_cli(sys.argv[2]))

    print("usage: python -m agent.lib.tick fire-if-signal <track>", file=sys.stderr)
    sys.exit(2)
