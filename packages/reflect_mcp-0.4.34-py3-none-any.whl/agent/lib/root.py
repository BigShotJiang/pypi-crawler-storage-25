"""Project root resolution — lib layer.

Resolution order (first match wins):
  1. REFLECT_PROJECT env var — absolute path to the project root.
     Set this in ~/.claude.json under the MCP server's "env" key to force a
     specific project regardless of cwd:
       "reflect": {"command": "reflect-manage", "env": {"REFLECT_PROJECT": "/path/to/project"}}
  2. cwd walk-up — starting from the shell's current working directory, walk
     ancestors looking for a reflect project marker:
       a. a directory whose agent/runtime/tracks/ exists AND is non-empty.
          Requiring non-empty guards against global dirs (e.g. ~/.acp/) that
          happen to have an empty tracks/ sibling and would otherwise match.
          Every `reflect init` project creates at least main/ and originator/
          tracks, so a legitimate project always satisfies this.
     Matches the behaviour of git, cargo, npm, uv: tool follows the cwd, not
     the install-site.
  3. File-relative fallback — parents[2] above this file.
     Only meaningful in reflect's own in-tree dev mode. Install-site users
     never reach this branch because they'll either set REFLECT_PROJECT or
     run Claude Code from a reflect-init'd workspace (cwd walk-up catches it).
"""
from __future__ import annotations

import os
from pathlib import Path


def resolve_project_root() -> Path:
    """Return the project root as an absolute Path.

    Resolution order: REFLECT_PROJECT env → cwd walk-up → file-relative fallback.
    See module docstring for rationale.
    """
    # 1. REFLECT_PROJECT env (explicit override)
    env_val = os.environ.get("REFLECT_PROJECT", "").strip()
    if env_val:
        p = Path(env_val).resolve()
        if p.is_dir():
            return p

    # 2. Walk up from cwd for a reflect project marker.
    #    A "reflect project" is any directory containing agent/runtime/tracks/
    #    (the load-bearing dir for any reflect operation). Fall back to a
    #    directory containing both agent/ and AGENT.md if no tracks/ yet
    #    (post-`reflect init` but pre-first-track scenario).
    try:
        cwd = Path.cwd().resolve()
    except (OSError, FileNotFoundError):
        cwd = None
    if cwd is not None:
        for ancestor in (cwd, *cwd.parents):
            # Condition a: project has an initialised tracks directory (non-empty).
            # Require the directory to be non-empty — a bare `agent/runtime/tracks/`
            # that is empty (e.g. the global ~/.acp/agent/runtime/tracks/) is not a
            # real reflect project and must not match here.
            tracks_dir = ancestor / "agent" / "runtime" / "tracks"
            if tracks_dir.is_dir() and next(tracks_dir.iterdir(), None) is not None:
                return ancestor

    # 3. File-relative fallback — only meaningful for in-tree dev mode
    #    (reflect's own repo). Install-site users will never reach this
    #    branch because they'll either set REFLECT_PROJECT or run Claude
    #    Code from within a reflect-init'd workspace.
    return Path(__file__).resolve().parents[2]
