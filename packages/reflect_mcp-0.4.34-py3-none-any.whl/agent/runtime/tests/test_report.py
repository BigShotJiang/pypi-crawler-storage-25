"""Tests for agent.cli.ops.report — gather_report core logic.

Tests:
  1. test_parse_ts_from_filename_* — timestamp extraction from filenames
  2. test_parse_kinds_* — --kinds spec parser
  3. test_resolve_date_keyword_* — keyword expansion (today/yesterday/now)
  4. test_gather_report_integration — fixture track tree, verify output
  5. test_gather_report_empty_track — empty track emits placeholder
  6. test_gather_report_glob — glob patterns match correct tracks
  7. test_gather_report_kinds_limit_zero — limit=0 skips kind
  8. test_gather_report_since_filter — --since prunes old artifacts

Run with:
    uv run pytest agent/runtime/tests/test_report.py -v
"""
from __future__ import annotations

import re
from datetime import datetime, timezone, timedelta
from pathlib import Path

import pytest

from agent.cli.ops.report import (
    _parse_ts_from_filename,
    _resolve_date_keyword,
    parse_kinds,
    gather_report,
    _ALL_KINDS,
)


# ---------------------------------------------------------------------------
# 1. Timestamp parsing from filename
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name,expected", [
    # Full timestamp with seconds
    ("2026-05-14T18-00-00Z-wake-foo.md", "2026-05-14T18:00:00Z"),
    # Timestamp without seconds
    ("2026-05-14T18-00Z-wake-foo.md", "2026-05-14T18:00Z"),
    # No timestamp prefix → None
    ("wake-foo.md", None),
    # Partial / malformed prefix → None
    ("2026-05-14-foo.md", None),
    # State file (no timestamp) → None
    ("core.state.yaml", None),
    # Datetime-like but no T separator → None
    ("20260514-180000-foo.md", None),
])
def test_parse_ts_from_filename(name, expected):
    assert _parse_ts_from_filename(name) == expected


# ---------------------------------------------------------------------------
# 2. --kinds parser
# ---------------------------------------------------------------------------

def test_parse_kinds_none_returns_none():
    assert parse_kinds(None, default_limit=3) is None


def test_parse_kinds_empty_returns_none():
    assert parse_kinds("", default_limit=3) is None


def test_parse_kinds_bare_names():
    result = parse_kinds("inbox,reports", default_limit=5)
    assert result == {"inbox": 5, "reports": 5}


def test_parse_kinds_per_kind_limit():
    result = parse_kinds("inbox,reports:3,completed:1", default_limit=10)
    assert result == {"inbox": 10, "reports": 3, "completed": 1}


def test_parse_kinds_zero_skips():
    result = parse_kinds("inbox:0,reports:3", default_limit=5)
    assert result == {"inbox": 0, "reports": 3}


def test_parse_kinds_whitespace_tolerant():
    result = parse_kinds(" inbox , reports:2 ", default_limit=4)
    assert result == {"inbox": 4, "reports": 2}


# ---------------------------------------------------------------------------
# 3. Date keyword resolution
# ---------------------------------------------------------------------------

def test_resolve_today():
    result = _resolve_date_keyword("today")
    today = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")
    assert result.startswith(today)
    assert result.endswith("T00:00:00Z")


def test_resolve_yesterday():
    result = _resolve_date_keyword("yesterday")
    yesterday = (datetime.now(tz=timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%d")
    assert result.startswith(yesterday)
    assert result.endswith("T00:00:00Z")


def test_resolve_now():
    before = datetime.now(tz=timezone.utc).replace(microsecond=0)
    result = _resolve_date_keyword("now")
    after = datetime.now(tz=timezone.utc).replace(microsecond=0)
    # Result format truncates to seconds; compare with second-truncated bounds.
    dt = datetime.strptime(result, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    assert before <= dt <= after + timedelta(seconds=1)


def test_resolve_passthrough_iso():
    iso = "2026-05-10T08:00:00Z"
    assert _resolve_date_keyword(iso) == iso


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


@pytest.fixture()
def tracks_dir(tmp_path: Path) -> Path:
    """Build a minimal fixture tracks directory with two tracks."""
    td = tmp_path / "tracks"

    # ── alpha-track ──────────────────────────────────────────────────────────
    _write(td / "alpha-track" / "reports" / "2026-05-14T10-00-00Z-wake-foo.md", "alpha report 1")
    _write(td / "alpha-track" / "reports" / "2026-05-13T10-00-00Z-wake-bar.md", "alpha report 2")
    _write(td / "alpha-track" / "inbox" / "2026-05-14T11-00-00Z-msg.md", "alpha inbox msg")
    _write(td / "alpha-track" / "followup" / "2026-05-14T09-00-00Z-followup.md", "alpha followup")
    _write(td / "alpha-track" / "followup" / ".completed" / "2026-05-14T08-00-00Z-done.md", "alpha done")
    _write(td / "alpha-track" / "state" / "core.state.yaml", "status: idle\n")
    _write(td / "alpha-track" / "state" / "extra.state.yaml", "extra: true\n")

    # ── beta-track (no state, no reports) ───────────────────────────────────
    _write(td / "beta-track" / "inbox" / "2026-05-14T12-00-00Z-msg.md", "beta inbox msg")

    return td


# ---------------------------------------------------------------------------
# 4. Integration: full output structure
# ---------------------------------------------------------------------------

def test_gather_report_integration(tracks_dir):
    result = gather_report(
        tracks=["alpha-track"],
        kinds=None,
        limit=10,
        offset=0,
        include_state="core",
        tracks_dir=tracks_dir,
    )

    # State first
    assert "=== alpha-track/state/core.state.yaml ===" in result
    # Reports present, newest first
    assert "2026-05-14T10-00-00Z-wake-foo.md" in result
    # Inbox present
    assert "alpha-track/inbox/2026-05-14T11-00-00Z-msg.md" in result
    # Completed present
    assert "alpha-track/completed/2026-05-14T08-00-00Z-done.md" in result
    # Content present
    assert "alpha report 1" in result
    # State content
    assert "status: idle" in result


def test_gather_report_state_first(tracks_dir):
    """State section must appear before any artifact section for the same track."""
    result = gather_report(
        tracks=["alpha-track"],
        kinds=None,
        limit=10,
        include_state="core",
        tracks_dir=tracks_dir,
    )
    state_pos = result.index("alpha-track/state/")
    report_pos = result.index("alpha-track/reports/")
    assert state_pos < report_pos


def test_gather_report_state_all_includes_extra(tracks_dir):
    result = gather_report(
        tracks=["alpha-track"],
        kinds={"reports": 0, "inbox": 0, "followup": 0, "completed": 0},
        limit=0,
        include_state="all",
        tracks_dir=tracks_dir,
    )
    assert "extra.state.yaml" in result


def test_gather_report_state_none(tracks_dir):
    result = gather_report(
        tracks=["alpha-track"],
        kinds=None,
        limit=10,
        include_state="none",
        tracks_dir=tracks_dir,
    )
    assert "state" not in result


# ---------------------------------------------------------------------------
# 5. Empty track placeholder
# ---------------------------------------------------------------------------

def test_gather_report_empty_track(tracks_dir):
    """A track with no matching artifacts emits a placeholder, not silence."""
    # beta-track has only inbox; request only reports → empty for beta
    result = gather_report(
        tracks=["beta-track"],
        kinds={"reports": 3},
        limit=3,
        include_state="none",
        tracks_dir=tracks_dir,
    )
    assert "=== beta-track/<empty> ===" in result


# ---------------------------------------------------------------------------
# 6. Glob patterns
# ---------------------------------------------------------------------------

def test_gather_report_glob(tracks_dir):
    result = gather_report(
        tracks=["alpha-*"],
        kinds={"inbox": 3},
        limit=3,
        include_state="none",
        tracks_dir=tracks_dir,
    )
    assert "alpha-track" in result
    assert "beta-track" not in result


def test_gather_report_no_match(tracks_dir):
    """Glob that matches nothing → empty string."""
    result = gather_report(
        tracks=["nonexistent-*"],
        kinds=None,
        limit=3,
        include_state="none",
        tracks_dir=tracks_dir,
    )
    assert result == ""


def test_gather_report_all_tracks_alphabetical(tracks_dir):
    """Without track filter, all tracks appear alphabetically."""
    result = gather_report(
        tracks=None,
        kinds={"inbox": 1},
        limit=1,
        include_state="none",
        tracks_dir=tracks_dir,
    )
    alpha_pos = result.index("alpha-track")
    beta_pos = result.index("beta-track")
    assert alpha_pos < beta_pos


# ---------------------------------------------------------------------------
# 7. kinds limit=0 skips kind
# ---------------------------------------------------------------------------

def test_gather_report_kinds_limit_zero(tracks_dir):
    result = gather_report(
        tracks=["alpha-track"],
        kinds={"inbox": 0, "reports": 3},
        limit=3,
        include_state="none",
        tracks_dir=tracks_dir,
    )
    assert "alpha-track/inbox/" not in result
    assert "alpha-track/reports/" in result


# ---------------------------------------------------------------------------
# 8. --since filter
# ---------------------------------------------------------------------------

def test_gather_report_since_filter(tracks_dir):
    """--since 2026-05-14 should include the May-14 report but not the May-13 one."""
    result = gather_report(
        tracks=["alpha-track"],
        kinds={"reports": 10},
        limit=10,
        include_state="none",
        since="2026-05-14T00:00:00Z",
        tracks_dir=tracks_dir,
    )
    assert "2026-05-14T10-00-00Z-wake-foo.md" in result
    assert "2026-05-13T10-00-00Z-wake-bar.md" not in result


def test_gather_report_until_filter(tracks_dir):
    """--until 2026-05-13T23:59:59Z should include only the May-13 report."""
    result = gather_report(
        tracks=["alpha-track"],
        kinds={"reports": 10},
        limit=10,
        include_state="none",
        until="2026-05-13T23:59:59Z",
        tracks_dir=tracks_dir,
    )
    assert "2026-05-13T10-00-00Z-wake-bar.md" in result
    assert "2026-05-14T10-00-00Z-wake-foo.md" not in result


# ---------------------------------------------------------------------------
# 9. Newest-first ordering within a kind
# ---------------------------------------------------------------------------

def test_gather_report_newest_first(tracks_dir):
    result = gather_report(
        tracks=["alpha-track"],
        kinds={"reports": 10},
        limit=10,
        include_state="none",
        tracks_dir=tracks_dir,
    )
    pos_new = result.index("2026-05-14T10-00-00Z-wake-foo.md")
    pos_old = result.index("2026-05-13T10-00-00Z-wake-bar.md")
    assert pos_new < pos_old


# ---------------------------------------------------------------------------
# 10. Offset
# ---------------------------------------------------------------------------

def test_gather_report_offset(tracks_dir):
    """offset=1 on reports skips the newest, returning only the older one."""
    result = gather_report(
        tracks=["alpha-track"],
        kinds={"reports": 1},
        limit=1,
        offset=1,
        include_state="none",
        tracks_dir=tracks_dir,
    )
    assert "2026-05-13T10-00-00Z-wake-bar.md" in result
    assert "2026-05-14T10-00-00Z-wake-foo.md" not in result
