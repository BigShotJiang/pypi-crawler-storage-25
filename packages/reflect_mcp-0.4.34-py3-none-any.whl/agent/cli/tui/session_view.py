"""reflect track session — interactive TUI for watching and directing a track.

Layout::

    ┌─────────────────────────────────────────────────────────┐
    │  [tail pane — RichLog; live wake transcript, auto-scroll]│
    │  (thinking blocks, assistant text, tool calls)           │
    │                                                          │
    ├──────────────────────────────────────────────────────── │
    │  [status bar — track badge, state, next-wake, ev tally] │
    ├──────────────────────────────────────────────────────── │
    │  > [input prompt]                                        │
    └─────────────────────────────────────────────────────────┘

Primary content: live wake transcript via TranscriptPoller.
Secondary signal: structured events (EventPoller) for status bar tally only.

Input routing:
    /command     → slash-command dispatch (local, never sent to track)
    other text   → track interrupt (degrades to inbox-drop when track is asleep)
"""
from __future__ import annotations

import os
import re
import subprocess
import time
import zlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.events import Key
from textual.widgets import Input, Label, RichLog

from agent.lib.root import resolve_project_root

from .commands import HELP_TEXT, CommandError, parse_command
from .event_stream import EventPoller, TranscriptPoller


# ── Path helpers ──────────────────────────────────────────────────────────────

_PROJECT_ROOT = resolve_project_root()
_TRACKS_DIR = _PROJECT_ROOT / "agent" / "runtime" / "tracks"


# ── Color helpers ─────────────────────────────────────────────────────────────

_TRACK_PALETTE: list[str] = [
    "#FF1744", "#FF4081", "#E91E63", "#9C27B0", "#673AB7",
    "#3F51B5", "#2196F3", "#00BCD4", "#009688", "#4CAF50",
    "#8BC34A", "#FF5722", "#FF9800",
    "#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A", "#98D8C8",
    "#7FB3D5", "#F1948A",
    "#FFB6C1", "#B5EAD7", "#C7CEEA", "#C2F0FC", "#E0BBE4",
    "#FEC8D8", "#FFDFD3", "#B3E5FC", "#80DEEA",
]


def _track_color(name: str) -> tuple[str, str]:
    """Return (bg_hex, fg_hex) stable for a given track name."""
    bucket = zlib.crc32(name.encode()) % len(_TRACK_PALETTE)
    bg = _TRACK_PALETTE[bucket]
    r, g, b = int(bg[1:3], 16), int(bg[3:5], 16), int(bg[5:7], 16)
    luminance = 0.299 * r + 0.587 * g + 0.114 * b
    fg = "#000000" if luminance > 140 else "#FFFFFF"
    return bg, fg


# ── Event rendering ───────────────────────────────────────────────────────────

_TYPE_MARKUP: dict[str, str] = {
    "wake.started": "green",
    "wake.completed": "yellow",
    "wake.failed": "bold red",
    "wake.scheduled": "dim green",
    "commit.made": "yellow",
    "tool.called": "dim",
    "inbox.delivered": "blue",
    "inbox.consumed": "blue",
    "track.running": "cyan",
    "track.idle": "cyan",
    "track.wedged": "bold red",
    "originator.requested": "magenta",
    "cost.threshold": "bold yellow",
}


def _event_markup(ev: dict) -> str:
    """Render a single event as a Rich markup string for RichLog."""
    at = ev.get("at", "")[:19].replace("T", " ")
    etype = ev.get("type", "?")
    p = ev.get("payload", {})
    color = _TYPE_MARKUP.get(etype, "default")

    # Type-specific payload summary
    if etype == "wake.started":
        detail = f"pid={p.get('pid','?')} src={p.get('kickoff_source','?')}"
    elif etype == "wake.completed":
        dur = p.get("duration_seconds", "?")
        cost = p.get("cost_usd", "?")
        turns = p.get("num_turns", "?")
        detail = f"dur={dur}s cost=${cost} turns={turns}"
    elif etype == "wake.failed":
        detail = f"reason={p.get('early_break_reason','?')}"
    elif etype == "wake.scheduled":
        detail = f"next_in={p.get('next_wake_in_seconds','?')}s"
    elif etype == "commit.made":
        sha = str(p.get("sha", "?"))[:8]
        msg = str(p.get("message", "?"))[:50]
        detail = f"[bold]{sha}[/bold] {msg}  → /diff {sha}"
    elif etype == "inbox.delivered":
        detail = f"to={p.get('to_track','?')} subj={p.get('subject','?')!r}"
    elif etype == "inbox.consumed":
        detail = str(Path(p.get("path", "?")).name)
    elif etype == "track.running":
        detail = f"pid={p.get('pid','?')}"
    elif etype == "track.idle":
        detail = f"unread={p.get('unread_count','?')}"
    elif etype == "track.wedged":
        violations = p.get("violations", [])
        detail = f"{len(violations)} violation(s)"
    elif etype == "originator.requested":
        detail = f"subj={p.get('subject','?')!r}"
    elif etype == "cost.threshold":
        detail = f"current=${p.get('current_usd','?')} threshold=${p.get('threshold_usd','?')}"
    else:
        detail = ""

    return f"[dim]{at}[/dim]  [{color}]{etype:<24}[/{color}]  {detail}"


def _event_grep_text(ev: dict) -> str:
    """Return a plain searchable string for an event (no markup)."""
    import json as _json
    parts = [
        ev.get("type", ""),
        ev.get("at", ""),
        _json.dumps(ev.get("payload", {}), default=str),
    ]
    return " ".join(parts)


# ── Track state helpers ───────────────────────────────────────────────────────


def _read_pid(lock_path: Path) -> Optional[int]:
    try:
        for line in lock_path.read_text().splitlines():
            line = line.strip()
            if line.isdigit():
                return int(line)
    except (OSError, ValueError):
        pass
    return None


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _track_state(name: str) -> dict:
    """Return {state, next_wake_delta, unread_count, lock_pid}."""
    track_dir = _TRACKS_DIR / name
    if not track_dir.exists():
        return {"state": "unknown", "next_wake_delta": "-", "unread_count": 0, "lock_pid": None}

    from agent.cli.ops.track import _resolve_track_state
    state = _resolve_track_state(track_dir)
    lock_path = track_dir / "wake.lock"
    lock_pid = None
    if lock_path.exists():
        lock_pid = _read_pid(lock_path)

    # next-wake-by delta
    next_delta = "-"
    try:
        from agent.cli.ops.track import _fmt_ts, _humanize_delta
        ts = int((track_dir / "next-wake-by.timestamp").read_text().strip())
        delta = ts - int(time.time())
        if delta <= 0:
            next_delta = "due now"
        else:
            next_delta = f"{_fmt_ts(ts)} - {_humanize_delta(delta)}"
    except (OSError, ValueError):
        pass

    # Unread inbox count
    inbox_dir = track_dir / "inbox"
    unread = 0
    if inbox_dir.exists():
        consumed_dir = inbox_dir / ".consumed"
        all_md = {p.name for p in inbox_dir.glob("*.md")}
        consumed_md = {p.name for p in consumed_dir.glob("*.md")} if consumed_dir.exists() else set()
        unread = len(all_md - consumed_md)

    return {
        "state": state,
        "next_wake_delta": next_delta,
        "unread_count": unread,
        "lock_pid": lock_pid,
    }


def _inbox_listing(name: str, n: Optional[int] = None) -> str:
    """Return formatted inbox listing or a specific message."""
    inbox_dir = _TRACKS_DIR / name / "inbox"
    if not inbox_dir.exists():
        return "(inbox directory not found)"
    consumed_dir = inbox_dir / ".consumed"
    consumed_names = {p.name for p in consumed_dir.glob("*.md")} if consumed_dir.exists() else set()
    msgs = sorted([p for p in inbox_dir.glob("*.md") if p.name not in consumed_names], reverse=True)
    if not msgs:
        return "(inbox empty)"
    if n is not None:
        try:
            msg = msgs[n - 1]
            content = msg.read_text(errors="replace")
            return f"[{n}] {msg.name}\n{content[:800]}"
        except (IndexError, OSError):
            return f"(no message at index {n})"
    lines = [f"  [{i+1}] {p.name}" for i, p in enumerate(msgs[:20])]
    return "\n".join(lines)


# ── Session App ───────────────────────────────────────────────────────────────


class SessionApp(App):
    """Interactive TUI session for a reflect track.

    Args:
        track_name: The track to watch and interact with.
        replay_last: How many historical events to show on startup.
    """

    CSS = """
    Screen {
        layout: vertical;
    }
    #tail {
        border: none;
        height: 1fr;
        min-height: 5;
        overflow-y: auto;
        scrollbar-size: 1 1;
        padding: 0 1;
    }
    #status-bar {
        height: 1;
        content-align: left middle;
        padding: 0 1;
        background: $panel;
        color: $text;
    }
    #input-row {
        height: 3;
        layout: horizontal;
        padding: 0 1;
    }
    #prompt-label {
        height: 3;
        content-align: left middle;
        width: 3;
    }
    #input {
        height: 3;
        width: 1fr;
        border: none;
    }
    """

    BINDINGS = [
        Binding("ctrl+d", "quit", "Quit"),
        Binding("escape", "quit", "Quit"),
    ]

    def __init__(self, track_name: str, replay_last: int = 20) -> None:
        super().__init__()
        self._track = track_name
        # Primary: transcript (live wake content)
        self._transcript_poller = TranscriptPoller(track=track_name, replay_last=150)
        # Secondary: events (status bar tally only)
        self._poller = EventPoller(track=track_name, replay_last=replay_last)
        self._send_history: list[str] = []
        self._history_idx: int = -1
        self._state_cache: dict = {}
        # Transcript line buffer for /grep
        self._transcript_lines: list[str] = []
        # Event tally for status bar
        self._ev_tool_count: int = 0
        self._ev_commit_count: int = 0
        self._last_commit_sha: Optional[str] = None
        # Context-window gauge (from wake.usage events; None = no data yet)
        self._ev_ctx_pct: Optional[float] = None
        self._ev_ctx_tokens: int = 0

    def compose(self) -> ComposeResult:
        yield RichLog(id="tail", highlight=True, markup=True, wrap=True)
        yield Label("", id="status-bar")
        with Vertical(id="input-row"):
            yield Label(">", id="prompt-label")
            yield Input(placeholder="Type a message or /help for commands", id="input")

    def _tally_event(self, ev: dict) -> None:
        """Update event tally counters (no display — events are secondary signal)."""
        etype = ev.get("type", "")
        p = ev.get("payload", {})
        if etype == "tool.called":
            self._ev_tool_count += 1
        elif etype == "commit.made":
            self._ev_commit_count += 1
            sha = str(p.get("sha", ""))
            if sha and sha != "?":
                self._last_commit_sha = sha
        elif etype == "wake.usage":
            ctx_pct = p.get("context_pct")
            if ctx_pct is not None:
                self._ev_ctx_pct = float(ctx_pct)
                self._ev_ctx_tokens = int(p.get("context_tokens", 0))

    def _append_transcript_line(self, line: str, tail: RichLog) -> None:
        """Render and append one transcript line to the tail pane and buffer."""
        self._transcript_lines.append(line)
        if not line:
            tail.write("")
            return
        # Thinking blocks
        if line.startswith("🧠 ") or line.startswith("   "):
            tail.write(f"[dim italic]{line}[/dim italic]")
        # Tool calls
        elif line.startswith("  🔧 "):
            tail.write(f"[dim]{line}[/dim]")
        # Wake separator
        elif line.startswith("── wake "):
            tail.write(f"[dim]{line}[/dim]")
        else:
            # Regular assistant text — render as-is (may contain markdown)
            tail.write(line)

    def _poll_transcript(self) -> None:
        """Timer callback: drain new transcript lines into the pane."""
        new_lines = self._transcript_poller.poll()
        if not new_lines:
            return
        tail = self.query_one("#tail", RichLog)
        for line in new_lines:
            self._append_transcript_line(line, tail)

    def on_mount(self) -> None:
        tail = self.query_one("#tail", RichLog)
        bg, fg = _track_color(self._track)
        tail.write(
            f"[on {bg} {fg}] {self._track} [/on {bg} {fg}]  "
            f"session started — type [bold]/help[/bold] for commands"
        )

        # ── Drain transcript (primary content) ──────────────────────────────
        initial_lines = self._transcript_poller.drain()
        if initial_lines:
            tail.write("[dim]── transcript tail ──[/dim]")
            for line in initial_lines:
                self._append_transcript_line(line, tail)
        else:
            tail.write("[dim]── no transcript yet — waiting for wake activity ──[/dim]")

        # ── Drain events (tally only, no display) ───────────────────────────
        for ev in self._poller.drain():
            self._tally_event(ev)

        # Start polling timers
        self.set_interval(0.2, self._poll_transcript)
        self.set_interval(0.5, self._poll_events)
        self.set_interval(1.0, self._refresh_status)
        self._refresh_status()
        self.query_one("#input", Input).focus()

    def _poll_events(self) -> None:
        """Timer callback: tally new events for status bar (no pane output)."""
        new = self._poller.poll()
        for ev in new:
            self._tally_event(ev)

    def _refresh_status(self) -> None:
        s = _track_state(self._track)
        self._state_cache = s
        state = s["state"]
        bg, fg = _track_color(self._track)

        state_colors = {
            "running": "green",
            "paused": "yellow",
            "idle": "dim",
            "sleeping": "dim",
            "disabled": "dim",
            "unknown": "dim",
        }
        sc = state_colors.get(state, "dim")

        next_str = f"  next: {s['next_wake_delta']}" if s["next_wake_delta"] not in ("-", "due now") else ""
        unread_str = f"  inbox: {s['unread_count']}" if s["unread_count"] else ""
        wedge_str = ""

        # Event tally (secondary signal)
        tally_parts = []
        if self._ev_tool_count:
            tally_parts.append(f"{self._ev_tool_count}🔧")
        if self._ev_commit_count:
            tally_parts.append(f"{self._ev_commit_count}📝")
        tally_str = f"  [{' '.join(tally_parts)}]" if tally_parts else ""

        # Context-window gauge — only meaningful when a wake is live.
        # state can be "running" or "disabled · running" (manual wake on a
        # disabled track), so check for substring rather than exact match.
        ctx_str = ""
        if "running" in state and self._ev_ctx_pct is not None:
            k = self._ev_ctx_tokens / 1000
            ctx_str = f"  ctx:{self._ev_ctx_pct:.1f}% | {k:.1f}k"

        label = (
            f"[on {bg} {fg}] {self._track} [/on {bg} {fg}]"
            f"  [{sc}]{state}[/{sc}]"
            f"{next_str}{unread_str}{tally_str}{ctx_str}{wedge_str}"
        )
        self.query_one("#status-bar", Label).update(label)

    # ── Input handling ─────────────────────────────────────────────────────────

    def on_input_submitted(self, event: Input.Submitted) -> None:
        text = event.value.strip()
        event.input.value = ""
        if not text:
            return

        tail = self.query_one("#tail", RichLog)

        if text.startswith("/"):
            try:
                cmd, arg = parse_command(text)
            except CommandError as e:
                tail.write(f"[red]{e}[/red]")
                return
            self._dispatch_command(cmd, arg, tail)
        else:
            # Record in send history
            if not self._send_history or self._send_history[-1] != text:
                self._send_history.append(text)
            self._history_idx = -1
            self._route_message(text, tail)

    def _dispatch_command(self, cmd: str, arg: str, tail: RichLog) -> None:
        if cmd == "quit":
            self.exit()

        elif cmd == "help":
            tail.write(f"[dim]── commands ──[/dim]\n{HELP_TEXT}")

        elif cmd == "clear":
            tail.clear()
            bg, fg = _track_color(self._track)
            tail.write(f"[on {bg} {fg}] {self._track} [/on {bg} {fg}]  [dim]pane cleared[/dim]")

        elif cmd == "status":
            s = self._state_cache or _track_state(self._track)
            lines = [
                f"  track:     {self._track}",
                f"  state:     {s['state']}",
                f"  next_wake: {s['next_wake_delta']}",
                f"  unread:    {s['unread_count']}",
                f"  lock_pid:  {s.get('lock_pid', '-')}",
            ]
            tail.write("[dim]── status ──[/dim]\n" + "\n".join(lines))

        elif cmd == "inbox":
            n = int(arg) if arg.isdigit() else None
            listing = _inbox_listing(self._track, n)
            tail.write(f"[dim]── inbox ──[/dim]\n{listing}")

        elif cmd == "wake":
            from agent.cli.ops.track import get_track_state
            s = get_track_state(self._track)
            if s.get("state") == "running":
                tail.write("[yellow]Track is already running. Use /stop first.[/yellow]")
                return
            tail.write(f"[dim]firing wake for {self._track}...[/dim]")
            try:
                result = subprocess.run(
                    ["reflect", "wake", "start", self._track],
                    capture_output=True, text=True, timeout=10,
                )
                if result.returncode == 0:
                    tail.write(f"[green]Wake started for {self._track}[/green]")
                else:
                    tail.write(f"[red]Failed to start wake: {result.stderr.strip()[:200]}[/red]")
            except (subprocess.TimeoutExpired, FileNotFoundError) as e:
                tail.write(f"[red]Error: {e}[/red]")

        elif cmd == "stop":
            tail.write(f"[dim]stopping wake for {self._track}...[/dim]")
            try:
                result = subprocess.run(
                    ["reflect", "wake", "stop", self._track],
                    capture_output=True, text=True, timeout=10,
                )
                if result.returncode == 0:
                    tail.write(f"[yellow]Stop signal sent to {self._track}[/yellow]")
                else:
                    tail.write(f"[red]Failed: {result.stderr.strip()[:200]}[/red]")
            except (subprocess.TimeoutExpired, FileNotFoundError) as e:
                tail.write(f"[red]Error: {e}[/red]")

        elif cmd == "pause":
            tail.write(f"[dim]pausing wake for {self._track}...[/dim]")
            try:
                result = subprocess.run(
                    ["reflect", "wake", "pause", self._track],
                    capture_output=True, text=True, timeout=10,
                )
                if result.returncode == 0:
                    tail.write(f"[yellow]Pause requested for {self._track}[/yellow]")
                else:
                    tail.write(f"[red]Failed: {result.stderr.strip()[:200]}[/red]")
            except (subprocess.TimeoutExpired, FileNotFoundError) as e:
                tail.write(f"[red]Error: {e}[/red]")

        elif cmd == "resume":
            tail.write(f"[dim]resuming wake for {self._track}...[/dim]")
            try:
                result = subprocess.run(
                    ["reflect", "wake", "resume", self._track],
                    capture_output=True, text=True, timeout=10,
                )
                if result.returncode == 0:
                    tail.write(f"[green]Resumed {self._track}[/green]")
                else:
                    tail.write(f"[red]Failed: {result.stderr.strip()[:200]}[/red]")
            except (subprocess.TimeoutExpired, FileNotFoundError) as e:
                tail.write(f"[red]Error: {e}[/red]")

        elif cmd == "cost":
            cost_path = Path(f"/tmp/reflect-wake-cost-{self._track}.json")
            try:
                import json
                data = json.loads(cost_path.read_text())
                usd = float(data.get("usd", 0.0))
                turns = data.get("turns", "?")
                tail.write(f"[dim]── cost ──[/dim]\n  current wake: ${usd:.4f}  turns: {turns}")
            except (OSError, ValueError, KeyError):
                tail.write("[dim]No cost data available yet for this wake.[/dim]")

        elif cmd == "diff":
            sha = arg if arg else self._last_commit_sha
            if not sha:
                tail.write("[dim]No recent commit sha detected. Use /diff <sha> explicitly.[/dim]")
                return
            try:
                result = subprocess.run(
                    ["git", "-C", str(_PROJECT_ROOT), "diff", f"{sha}^", sha, "--stat"],
                    capture_output=True, text=True, timeout=10,
                )
                output = result.stdout.strip() or result.stderr.strip()
                tail.write(f"[dim]── diff {sha[:8]} ──[/dim]\n{output[:2000]}")
            except (subprocess.TimeoutExpired, FileNotFoundError) as e:
                tail.write(f"[red]Error: {e}[/red]")

        elif cmd == "grep":
            self._cmd_grep(arg, tail)

    def _cmd_grep(self, pattern: str, tail: RichLog) -> None:
        """Filter or restore the transcript buffer by pattern.

        /grep          → restore full transcript view
        /grep <regex>  → show only transcript lines matching regex (case-insensitive)
        """
        bg, fg = _track_color(self._track)

        if not pattern:
            # Restore full transcript view
            tail.clear()
            tail.write(
                f"[on {bg} {fg}] {self._track} [/on {bg} {fg}]  "
                f"[dim]showing all {len(self._transcript_lines)} transcript lines[/dim]"
            )
            for line in self._transcript_lines:
                self._append_transcript_line(line, tail)
            return

        try:
            rx = re.compile(pattern, re.IGNORECASE)
        except re.error as e:
            tail.write(f"[red]Invalid pattern: {e}[/red]")
            return

        matches = [ln for ln in self._transcript_lines if rx.search(ln)]
        tail.clear()
        tail.write(
            f"[on {bg} {fg}] {self._track} [/on {bg} {fg}]  "
            f"[dim]grep {pattern!r}: {len(matches)} of {len(self._transcript_lines)} lines[/dim]"
        )
        if matches:
            for line in matches:
                self._append_transcript_line(line, tail)
        else:
            tail.write("[dim](no matches)[/dim]")

    def _route_message(self, text: str, tail: RichLog) -> None:
        """Route a plain message to the track via interrupt (runtime handles degradation).

        Always calls interrupt_track — the runtime degrades gracefully:
          - track running  → socket injection (received at next tool boundary)
          - track sleeping → inbox-drop (received on next wake)
        The pre-call state check is intentionally absent; routing is the runtime's call.
        """
        from agent.cli.ops.track import interrupt_track

        at = datetime.now(timezone.utc).strftime("%H:%M:%SZ")
        tail.write(f"[dim]{at}[/dim]  [bold]>[/bold] {text}")

        result = interrupt_track(self._track, text)
        if result["ok"]:
            how = result.get("delivered", "?")
            track_state = result.get("track_state", "?")
            wake_fired = result.get("wake_fired", False)
            wake_pid = result.get("wake_pid")
            if how == "socket":
                tail.write("[dim]  → injected (next tool boundary)[/dim]")
            elif track_state == "idle":
                if wake_fired:
                    tail.write(f"[dim]  → inbox-drop; wake fired (pid {wake_pid})[/dim]")
                else:
                    tail.write("[dim]  → inbox-drop; wake fire failed — next cron tick[/dim]")
            elif track_state == "disabled":
                tail.write("[yellow]  → inbox-drop; track disabled — wake NOT fired[/yellow]")
            else:
                tail.write("[dim]  → inbox-drop (next wake)[/dim]")
        else:
            tail.write(f"[red]  → error: {result['message']}[/red]")

    # ── Key bindings for history ───────────────────────────────────────────────

    def on_key(self, event: Key) -> None:
        inp = self.query_one("#input", Input)
        if event.key == "up":
            if self._send_history:
                if self._history_idx == -1:
                    self._history_idx = len(self._send_history) - 1
                elif self._history_idx > 0:
                    self._history_idx -= 1
                inp.value = self._send_history[self._history_idx]
                event.prevent_default()
        elif event.key == "down":
            if self._history_idx >= 0:
                self._history_idx += 1
                if self._history_idx >= len(self._send_history):
                    self._history_idx = -1
                    inp.value = ""
                else:
                    inp.value = self._send_history[self._history_idx]
                event.prevent_default()
