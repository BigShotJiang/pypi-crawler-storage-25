"""Pure report operations — no CLI formatting, no sys.exit, no stdout.

`gather_report` is the shared core used by both the CLI and MCP tool.
It aggregates track artifacts and state into a single concatenated string.
"""
from __future__ import annotations

import fnmatch
import re
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Literal, Optional

from agent.lib.root import resolve_project_root

PROJECT_ROOT = resolve_project_root()
TRACKS_DIR = PROJECT_ROOT / "agent" / "runtime" / "tracks"


# ── Timestamp helpers ──────────────────────────────────────────────────────────

_TS_RE = re.compile(
    r"^(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}(?:-\d{2})?Z)"
)


def _parse_ts_from_filename(name: str) -> Optional[str]:
    """Extract a sortable ISO timestamp from a filename prefix.

    Accepts: 2026-05-14T18-00Z-foo.md  → 2026-05-14T18:00Z
             2026-05-14T18-00-00Z-foo  → 2026-05-14T18:00:00Z
    Returns None if no parseable prefix.
    """
    m = _TS_RE.match(name)
    if not m:
        return None
    raw = m.group(1)  # e.g. 2026-05-14T18-00-00Z
    date_part, rest = raw.split("T", 1)
    # rest like 18-00-00Z — replace first two dashes with colons
    time_part = rest.replace("-", ":", 2)
    return f"{date_part}T{time_part}"


def _mtime_ts(path: Path) -> str:
    """Return mtime as a sortable ISO string (UTC)."""
    try:
        mtime = path.stat().st_mtime
        return datetime.fromtimestamp(mtime, tz=timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
    except OSError:
        return "1970-01-01T00:00:00Z"


def _artifact_ts(path: Path) -> str:
    """Return the best available timestamp for an artifact: filename prefix → mtime."""
    ts = _parse_ts_from_filename(path.name)
    return ts if ts is not None else _mtime_ts(path)


# ── Date keyword parsing ───────────────────────────────────────────────────────

_ISO_DATE_LIKE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}")


def _resolve_date_keyword(value: str) -> str:
    """Expand keywords (today, yesterday, now) to ISO strings; pass-through otherwise."""
    lower = value.strip().lower()
    today = datetime.now(tz=timezone.utc).date()
    if lower == "now":
        return datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    if lower == "today":
        return today.strftime("%Y-%m-%dT00:00:00Z")
    if lower == "yesterday":
        from datetime import timedelta
        yesterday = today - timedelta(days=1)
        return yesterday.strftime("%Y-%m-%dT00:00:00Z")
    # Already ISO — normalise dashes-in-time to colons if needed so string
    # comparisons work (the filename format uses dashes; --since/--until use colons).
    return value.strip()


def _normalise_iso(value: str) -> str:
    """Ensure ISO comparisons work regardless of format quirks.

    Just strip and return — we compare strings lexicographically, which works
    as long as both sides are ISO 8601 and the same format.  Callers that pass
    date-only strings (2026-05-14) get compared to timestamps (2026-05-14T…)
    correctly because '2026-05-14' < '2026-05-14T00:00:00Z' in lex order, so
    we bump date-only strings to midnight.
    """
    v = value.strip()
    if _ISO_DATE_LIKE_RE.match(v) and len(v) == 10:
        v = v + "T00:00:00Z"
    return v


# ── Kinds parser ───────────────────────────────────────────────────────────────

def parse_kinds(spec: Optional[str], default_limit: int) -> Optional[dict[str, int]]:
    """Parse a --kinds spec string into {kind: limit} dict.

    ``spec`` is comma-separated entries like: ``inbox,reports:3,completed:1``
    - Bare name → uses default_limit
    - ``name:N`` → uses N (0 means skip kind entirely)
    Returns None if spec is None/empty (= all kinds).
    """
    if not spec:
        return None
    result: dict[str, int] = {}
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" in part:
            name, _, n_str = part.partition(":")
            try:
                result[name.strip()] = int(n_str.strip())
            except ValueError:
                result[name.strip()] = default_limit
        else:
            result[part] = default_limit
    return result if result else None


# ── Track discovery ────────────────────────────────────────────────────────────

def _all_track_names(tracks_dir: Path) -> list[str]:
    if not tracks_dir.exists():
        return []
    return sorted(
        d.name for d in tracks_dir.iterdir()
        if d.is_dir() and not d.name.startswith(".")
    )


def _match_tracks(
    patterns: Optional[list[str]],
    tracks_dir: Optional[Path] = None,
) -> list[str]:
    """Return alphabetically sorted track names matching any of the glob patterns.

    None/empty patterns → all tracks.
    """
    td = tracks_dir or TRACKS_DIR
    all_names = _all_track_names(td)
    if not patterns:
        return all_names
    matched: set[str] = set()
    for pat in patterns:
        pat = pat.strip()
        if not pat:
            continue
        for name in all_names:
            if fnmatch.fnmatch(name, pat) or name == pat:
                matched.add(name)
    return sorted(matched)


# ── Artifact kinds layout ──────────────────────────────────────────────────────

# Maps kind name → subdirectory path relative to track dir.
_KIND_SUBDIR: dict[str, str] = {
    "inbox": "inbox",
    "reports": "reports",
    "followup": "followup",
    "completed": "followup/.completed",
}

# Default artifact file glob per kind (within the subdir).
_KIND_GLOB: dict[str, str] = {
    "inbox": "*.md",
    "reports": "*.md",
    "followup": "*.md",
    "completed": "*.md",
}

# All recognised kinds in the canonical sort order.
_ALL_KINDS = ["completed", "followup", "inbox", "reports"]


def _gather_kind_files(
    track_dir: Path,
    kind: str,
    limit: int,
    offset: int,
    since: Optional[str],
    until: Optional[str],
) -> list[tuple[str, Path]]:
    """Gather files for one kind under track_dir.

    Returns a list of (timestamp_str, path) pairs, newest first, after
    applying date filter and offset/limit.

    An empty list is returned when kind is unknown, the subdir doesn't exist,
    or limit == 0 (explicit skip).
    """
    if limit == 0:
        return []

    subdir = _KIND_SUBDIR.get(kind)
    if subdir is None:
        return []

    kind_dir = track_dir / subdir
    if not kind_dir.exists():
        return []

    # For inbox: only direct .md files (not .consumed/ or other subdirs).
    glob_pat = _KIND_GLOB.get(kind, "*.md")
    if kind == "inbox":
        candidates = [
            p for p in kind_dir.iterdir()
            if p.is_file() and p.suffix == ".md"
        ]
    else:
        candidates = list(kind_dir.glob(glob_pat))

    # Build (timestamp, path) and sort newest first.
    pairs: list[tuple[str, Path]] = [(_artifact_ts(p), p) for p in candidates]
    pairs.sort(key=lambda x: x[0], reverse=True)

    # Date filter.
    if since or until:
        filtered: list[tuple[str, Path]] = []
        for ts, p in pairs:
            if since and ts < since:
                continue
            if until and ts > until:
                continue
            filtered.append((ts, p))
        pairs = filtered

    # Offset + limit.
    pairs = pairs[offset:]
    if limit > 0:
        pairs = pairs[:limit]

    return pairs


# ── State file gathering ───────────────────────────────────────────────────────

def _gather_state_files(
    track_dir: Path,
    include_state: Literal["core", "all", "none"],
) -> list[Path]:
    """Return state files to include for a track."""
    if include_state == "none":
        return []
    state_dir = track_dir / "state"
    if not state_dir.exists():
        return []
    if include_state == "core":
        core = state_dir / "core.state.yaml"
        return [core] if core.exists() else []
    # "all"
    return sorted(state_dir.glob("*.state.yaml"))


# ── Output formatting ──────────────────────────────────────────────────────────

_SEP = "==="


def _section(label: str, content: Optional[str] = None) -> str:
    """Format one section with a separator header and optional body."""
    header = f"{_SEP} {label} {_SEP}"
    if content is None:
        return header
    return f"{header}\n{content}"


# ── Core gather ───────────────────────────────────────────────────────────────


def gather_report(
    tracks: Optional[list[str]],
    kinds: Optional[dict[str, int]],
    limit: int = 3,
    offset: int = 0,
    since: Optional[str] = None,
    until: Optional[str] = None,
    include_state: Literal["core", "all", "none"] = "core",
    tracks_dir: Optional[Path] = None,
) -> str:
    """Assemble a concatenated context report.

    Args:
        tracks:        list of track name globs (None = all).
        kinds:         {kind: limit} dict (None = all kinds, each capped at `limit`).
        limit:         default per-kind limit (used when kinds is None or kind has no explicit limit).
        offset:        skip N most recent before applying limit.
        since:         ISO8601/keyword; filter artifacts with ts >= this value.
        until:         ISO8601/keyword; filter artifacts with ts <= this value.
        include_state: "core" | "all" | "none".
        tracks_dir:    override for testing.
    Returns:
        Concatenated string suitable for stdout or LLM context injection.
    """
    td = tracks_dir or TRACKS_DIR

    # Normalise date bounds.
    since_norm = _normalise_iso(_resolve_date_keyword(since)) if since else None
    until_norm = _normalise_iso(_resolve_date_keyword(until)) if until else None

    matched = _match_tracks(tracks, td)

    # Determine which kinds to emit and their per-kind limits.
    if kinds is None:
        active_kinds: dict[str, int] = {k: limit for k in _ALL_KINDS}
    else:
        active_kinds = {}
        for k in _ALL_KINDS:
            if k in kinds:
                active_kinds[k] = kinds[k]

    sections: list[str] = []

    for track_name in matched:
        track_dir = td / track_name
        track_sections: list[str] = []

        # 1. State files (always first within a track).
        for state_path in _gather_state_files(track_dir, include_state):
            try:
                content = state_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                content = f"[error reading {state_path.name}]"
            label = f"{track_name}/state/{state_path.name}"
            track_sections.append(_section(label, content))

        # 2. Artifacts grouped by kind (in canonical order).
        for kind in _ALL_KINDS:
            per_kind_limit = active_kinds.get(kind)
            if per_kind_limit is None:
                continue  # kind not requested

            pairs = _gather_kind_files(
                track_dir,
                kind,
                per_kind_limit,
                offset,
                since_norm,
                until_norm,
            )

            for _ts, path in pairs:
                try:
                    content = path.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    content = f"[error reading {path.name}]"
                # Label relative to the kind subdir, not the raw filesystem path.
                label = f"{track_name}/{kind}/{path.name}"
                track_sections.append(_section(label, content))

        # If track matched but produced nothing, emit placeholder.
        if not track_sections:
            sections.append(_section(f"{track_name}/<empty>"))
        else:
            sections.extend(track_sections)

    return "\n\n".join(sections)
