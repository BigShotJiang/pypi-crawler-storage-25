"""Pure wake operations — no CLI formatting, no sys.exit, no stdout.

All functions return structured dicts. Callers (CLI, MCP) format as needed.
"""
from __future__ import annotations

import json as _json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone as _tz
from pathlib import Path
from typing import Optional

from agent.cli.ops.root import resolve_project_root

# Module-level path constants — computed at import time via resolve_project_root().
#
# Safe for both callers:
#   MCP server: server.py sets REFLECT_PROJECT before importing this module, so
#               resolve_project_root() returns the correct project root (step 1).
#   CLI: runs from the project directory; cwd walk-up (step 2) returns the correct root.
#
# These are exported for backward-compat with cost.py and other callers that
# import them directly.  Do NOT remove without updating those callers.
PROJECT_ROOT: Path = resolve_project_root()
TRACKS_DIR: Path = PROJECT_ROOT / "agent" / "runtime" / "tracks"
WAKES_TSV: Path = PROJECT_ROOT / "agent" / "runtime" / "wakes.tsv"
WAKES_DIR: Path = PROJECT_ROOT / "agent" / "runtime" / "wakes"


def _get_root() -> Path:
    """Resolve project root lazily at call time.

    Module-level constants bake in the MCP server's startup cwd. Per-call
    resolution respects REFLECT_PROJECT env and always finds the correct root.
    """
    return resolve_project_root()


def _is_pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _read_lock_pid(lock_path: Path) -> Optional[int]:
    try:
        content = lock_path.read_text().strip()
        for line in content.splitlines():
            line = line.strip()
            if line.isdigit():
                return int(line)
    except (OSError, ValueError):
        pass
    return None


def _track_names(tracks_dir: Optional[Path] = None) -> list[str]:
    td = tracks_dir or _get_root() / "agent" / "runtime" / "tracks"
    if not td.exists():
        return []
    return sorted(d.name for d in td.iterdir() if d.is_dir() and not d.name.startswith("."))


def list_running_wakes(tracks_dir: Optional[Path] = None) -> list[dict]:
    """Return list of currently running wakes.

    Each dict: {track, pid, runtime_secs, state}
    """
    td = tracks_dir or _get_root() / "agent" / "runtime" / "tracks"
    results = []
    for name in _track_names(td):
        track_dir = td / name
        lock_path = track_dir / "wake.lock"
        if not lock_path.exists():
            continue
        pid = _read_lock_pid(lock_path)
        if pid is None:
            continue
        if not _is_pid_alive(pid):
            continue

        runtime_secs: Optional[int] = None
        lws_path = track_dir / "last-wake-start.timestamp"
        try:
            start_ts = int(lws_path.read_text().strip())
            runtime_secs = int(time.time()) - start_ts
        except (OSError, ValueError):
            pass

        pause_file = track_dir / "pause.requested"
        state = "paused" if pause_file.exists() else "running"
        results.append({
            "track": name,
            "pid": pid,
            "runtime_secs": runtime_secs,
            "state": state,
        })
    return results


def get_wake_history(track: Optional[str] = None, limit: int = 20) -> list[dict]:
    """Return recent wake history rows from wakes.tsv.

    Each dict contains fields from TSV headers. Filtered by track name if provided.
    """
    if not (_get_root() / "agent" / "runtime" / "wakes.tsv").exists():
        return []

    rows = []
    try:
        lines = WAKES_TSV.read_text().splitlines()
        if not lines:
            return []
        headers = lines[0].split("\t")
        for line in lines[1:]:
            if not line.strip():
                continue
            parts = line.split("\t")
            row = dict(zip(headers, parts))
            rows.append(row)
    except OSError:
        return []

    if track:
        filtered = []
        for row in rows:
            wake_id = row.get("wake_id", "")
            wake_dir = PROJECT_ROOT / "agent" / "runtime" / "wakes" / wake_id
            track_name_file = wake_dir / "track.name"
            try:
                wake_track = track_name_file.read_text().strip()
            except OSError:
                wake_track = None
            if wake_track is None or wake_track == track:
                filtered.append(row)
        rows = filtered

    return rows[-limit:]


def start_wake(track: str) -> dict:
    """Spawn a wake for *track* as a background subprocess.

    Returns: {ok: bool, pid: int | None, message: str}

    Unlike the CLI's cmd_wake_start (which uses os.execvpe to replace the
    current process), this spawns a detached child so the MCP caller can
    receive a response immediately.
    """
    track_dir = TRACKS_DIR / track
    if not track_dir.exists():
        return {"ok": False, "pid": None, "message": f"track '{track}' not found"}

    lock_path = track_dir / "wake.lock"
    if lock_path.exists():
        pid = _read_lock_pid(lock_path)
        if pid is not None and _is_pid_alive(pid):
            return {
                "ok": False,
                "pid": pid,
                "message": f"wake already running for '{track}' (pid {pid})",
            }

    env = os.environ.copy()
    env["REFLECT_TRACK"] = track

    # Log file: captures startup errors that were previously swallowed by DEVNULL.
    # Truncated on each spawn so the file always reflects the most-recent attempt.
    log_path = Path(f"/tmp/reflect-wake-{track}.log")

    try:
        log_fh = log_path.open("w")
        proc = subprocess.Popen(
            [sys.executable, "-m", "agent.runtime.wake"],
            env=env,
            cwd=str(PROJECT_ROOT),
            start_new_session=True,   # detach from MCP server's session
            stdin=subprocess.DEVNULL,
            stdout=log_fh,
            stderr=log_fh,
        )
        log_fh.close()
        # Post-spawn PID write: immediately record the child PID so concurrent
        # dispatcher ticks see a live PID and don't fire a second wake during
        # the wake.py startup window.  wake.py will overwrite with its own PID
        # once it starts (same value on exec paths, correct child PID here).
        try:
            lock_path.write_text(f"{proc.pid}\n")
        except Exception:
            pass
        return {"ok": True, "pid": proc.pid, "message": f"wake started for '{track}' (pid {proc.pid}), log: {log_path}"}
    except Exception as exc:
        return {"ok": False, "pid": None, "message": f"failed to start wake: {exc}"}


def stop_wake(track: str) -> dict:
    """Request graceful stop of a running wake for *track*.

    Touches ``stop.requested`` in the track directory. The running wake checks
    this file between tool calls and winds down cleanly on next opportunity.

    Returns: {ok: bool, message: str}
    """
    track_dir = TRACKS_DIR / track
    if not track_dir.exists():
        return {"ok": False, "message": f"track '{track}' not found"}

    stop_file = track_dir / "stop.requested"
    stop_file.touch()
    return {
        "ok": True,
        "message": f"Stop requested for '{track}'. Wake will wind down gracefully.",
    }


def pause_wake(track: str) -> dict:
    """Request cooperative pause of a running wake for *track*.

    Touches ``pause.requested`` in the track directory. The running wake checks
    this file at each UserMessage boundary (end of LLM turn) and enters a
    poll-sleep loop without progressing until the file is removed.

    Returns: {ok: bool, message: str}
    """
    track_dir = TRACKS_DIR / track
    if not track_dir.exists():
        return {"ok": False, "message": f"track '{track}' not found"}

    lock_path = track_dir / "wake.lock"
    if not lock_path.exists():
        return {"ok": False, "message": f"no running wake for '{track}' — nothing to pause"}

    pid = _read_lock_pid(lock_path)
    if pid is None or not _is_pid_alive(pid):
        return {"ok": False, "message": f"no live wake process for '{track}'"}

    pause_file = track_dir / "pause.requested"
    if pause_file.exists():
        return {"ok": True, "message": f"wake for '{track}' is already paused", "state": "paused"}

    pause_file.touch()
    return {
        "ok": True,
        "message": f"Pause requested for '{track}'. Wake will pause at next turn boundary.",
        "state": "pausing",
    }


def resume_wake(track: str) -> dict:
    """Clear the pause flag for *track*, allowing the wake to continue.

    Returns: {ok: bool, message: str}
    """
    track_dir = TRACKS_DIR / track
    if not track_dir.exists():
        return {"ok": False, "message": f"track '{track}' not found"}

    pause_file = track_dir / "pause.requested"
    if not pause_file.exists():
        return {"ok": True, "message": f"wake for '{track}' is not paused (no-op)", "state": "running"}

    try:
        pause_file.unlink()
    except FileNotFoundError:
        pass  # race — already removed
    return {
        "ok": True,
        "message": f"Resumed '{track}'. Wake will continue from prior position.",
        "state": "running",
    }


def _read_timestamp_file(path: Path) -> Optional[int]:
    """Read an epoch integer from a timestamp file; return None on any failure."""
    try:
        return int(path.read_text().strip())
    except (OSError, ValueError):
        return None


def _wake_running_state(track_dir: Path) -> tuple[bool, int]:
    """Return (is_running, start_ts).

    A wake is considered running when last-wake-start.timestamp >
    last-wake.timestamp (or last-wake.timestamp doesn't exist).
    Returns start_ts=0 when the wake is not running.
    """
    lws_path = track_dir / "last-wake-start.timestamp"
    lwe_path = track_dir / "last-wake.timestamp"
    start_ts = _read_timestamp_file(lws_path) or 0
    end_ts = _read_timestamp_file(lwe_path) or 0
    running = start_ts > end_ts
    return running, (start_ts if running else 0)


def _final_state_from_tsv(track: str, start_ts: int) -> str:
    """Determine the terminal state of a completed wake from wakes.tsv.

    Returns 'idle' (slept_clean), 'wedged' (budget/error exit), or 'crashed'
    (no matching row found).
    """
    root = _get_root()
    tsv_path = root / "agent" / "runtime" / "wakes.tsv"
    if not tsv_path.exists():
        return "crashed"
    try:
        lines = tsv_path.read_text().splitlines()
    except OSError:
        return "crashed"

    for line in reversed(lines[1:]):
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 9:
            # 9-col: wake_id, track, started_at, ended_at, slept_clean, ...
            row_track = parts[1]
            row_start = parts[2]
            slept_clean = parts[4]
        elif len(parts) == 8:
            # 8-col legacy: no track field — check all
            row_track = None
            row_start = parts[1]
            slept_clean = parts[3]
        else:
            continue

        if row_track is not None and row_track != track:
            continue
        try:
            if abs(int(row_start) - start_ts) <= 5:
                return "idle" if slept_clean == "1" else "wedged"
        except ValueError:
            continue

    return "crashed"


def _find_report_from_heartbeat(project_root: Path, start_ts: int) -> Optional[str]:
    """Find the report path written during a wake that started at *start_ts*.

    Heartbeat format: {ISO_ts_dashes}\\t{slug}\\t1\\t{report_path}
    e.g. 2026-05-15T16-42-02Z\\tslug\\t1\\tagent/reports/....md
    """
    hb_log = (
        project_root
        / "agent"
        / "drivers"
        / "@local"
        / "scry"
        / "runtime"
        / "heartbeat.log"
    )
    if not hb_log.exists():
        return None
    try:
        lines = hb_log.read_text().splitlines()
    except OSError:
        return None

    best: Optional[str] = None
    for line in lines:
        parts = line.split("\t")
        if len(parts) < 4:
            continue
        ts_raw = parts[0]
        report = parts[3].strip()
        # Convert dashed time portion to colons for parsing:
        # "2026-05-15T16-42-02Z" → "2026-05-15T16:42:02Z"
        try:
            import re as _re
            ts_norm = _re.sub(
                r"T(\d{2})-(\d{2})-(\d{2})Z",
                lambda m: f"T{m.group(1)}:{m.group(2)}:{m.group(3)}Z",
                ts_raw,
            )
            from datetime import datetime as _dt
            ts = _dt.fromisoformat(ts_norm.replace("Z", "+00:00")).timestamp()
            if ts >= start_ts and report:
                best = report  # take the last match (most recent)
        except Exception:
            continue
    return best


def await_wake(
    track: str,
    *,
    timeout_secs: Optional[int] = None,
    next_wake: bool = False,
    _started_after: Optional[int] = None,
) -> dict:
    """Block until a wake for *track* completes.

    Returns a dict::

        {
            "state":        "idle" | "wedged" | "crashed" | "no-wake-running",
            "track":        str,
            "wake_id":      str | None,   # ISO timestamp derived ID
            "report_path":  str | None,
            "duration_secs": int,
        }

    Semantics
    ---------
    next_wake=False (default):
        Block until the *current* in-flight wake ends. If no wake is running,
        return immediately with state="no-wake-running".

    next_wake=True:
        Block until the *next* wake fires and completes. Even if a wake is
        running now, wait for it to finish *and then* for another one to start
        and finish — i.e. block until there is one clean start→finish cycle
        that begins after the call.

    _started_after (internal):
        Used by start_wake_await() to close the start-then-await race window.
        When set, treat any wake whose start_ts > _started_after as "the wake
        to await" rather than checking for a currently-running wake.

    timeout_secs:
        Cap the total blocking time. On expiry, return state="wedged".

    IMPORTANT: This call is blocking. For MCP callers expecting waits longer
    than a few seconds, use the backgrounded CLI form instead:
        Bash(run_in_background=True, command="reflect wake await <track> ...")
    """
    root = _get_root()
    td = root / "agent" / "runtime" / "tracks"
    track_dir = td / track
    if not track_dir.exists():
        return {
            "state": "no-wake-running",
            "track": track,
            "wake_id": None,
            "report_path": None,
            "duration_secs": 0,
            "error": f"track '{track}' not found",
        }

    lws_path = track_dir / "last-wake-start.timestamp"
    lwe_path = track_dir / "last-wake.timestamp"

    deadline: Optional[float] = time.time() + timeout_secs if timeout_secs else None
    wall_start = time.time()

    def _timed_out() -> bool:
        return deadline is not None and time.time() >= deadline

    def _elapsed() -> int:
        return int(time.time() - wall_start)

    # ── Phase 1: locate the target wake ─────────────────────────────────────
    # target_start_ts: the epoch of the wake we're waiting for.
    target_start_ts: Optional[int] = None

    if _started_after is not None:
        # start --await path: wait until a wake whose start_ts > _started_after
        while True:
            if _timed_out():
                return {
                    "state": "wedged",
                    "track": track,
                    "wake_id": None,
                    "report_path": None,
                    "duration_secs": _elapsed(),
                    "reason": "timeout waiting for wake to start",
                }
            start_ts = _read_timestamp_file(lws_path) or 0
            if start_ts > _started_after:
                target_start_ts = start_ts
                break
            time.sleep(0.3)

    elif next_wake:
        # --next: wait for any new wake to start after this call
        old_end_ts = _read_timestamp_file(lwe_path) or 0
        # Wait for the current wake (if any) to finish first, then for the next one
        # A new wake started when start_ts > old_end_ts (i.e. the timestamps crossed again)
        while True:
            if _timed_out():
                return {
                    "state": "wedged",
                    "track": track,
                    "wake_id": None,
                    "report_path": None,
                    "duration_secs": _elapsed(),
                    "reason": "timeout waiting for next wake to start",
                }
            start_ts = _read_timestamp_file(lws_path) or 0
            end_ts = _read_timestamp_file(lwe_path) or 0
            if start_ts > end_ts and start_ts > old_end_ts:
                target_start_ts = start_ts
                break
            time.sleep(0.3)

    else:
        # Default: check if a wake is currently running
        is_running, start_ts = _wake_running_state(track_dir)
        if not is_running:
            return {
                "state": "no-wake-running",
                "track": track,
                "wake_id": None,
                "report_path": None,
                "duration_secs": 0,
            }
        target_start_ts = start_ts

    # ── Phase 2: wait for the target wake to complete ───────────────────────
    assert target_start_ts is not None
    wake_id = datetime.fromtimestamp(target_start_ts, tz=_tz.utc).strftime(
        "%Y-%m-%dT%H-%M-%SZ"
    )

    while True:
        if _timed_out():
            return {
                "state": "wedged",
                "track": track,
                "wake_id": wake_id,
                "report_path": None,
                "duration_secs": _elapsed(),
                "reason": "timeout waiting for wake to complete",
            }

        end_ts = _read_timestamp_file(lwe_path) or 0
        if end_ts >= target_start_ts:
            # Wake completed — determine terminal state
            final_state = _final_state_from_tsv(track, target_start_ts)
            report_path = _find_report_from_heartbeat(root, target_start_ts)
            return {
                "state": final_state,
                "track": track,
                "wake_id": wake_id,
                "report_path": report_path,
                "duration_secs": _elapsed(),
            }

        time.sleep(0.5)


def start_wake_await(
    track: str,
    timeout_secs: Optional[int] = None,
) -> dict:
    """Start a wake for *track* and block until it completes.

    This is the atomic form that closes the start-then-await race window.
    Records the pre-start timestamp, spawns the wake, waits for the new
    wake to be detected, then awaits its completion.

    Returns the same dict as await_wake().
    """
    root = _get_root()
    track_dir = root / "agent" / "runtime" / "tracks" / track
    lws_path = track_dir / "last-wake-start.timestamp"

    # Record the current start timestamp before spawning
    old_start_ts = _read_timestamp_file(lws_path) or int(time.time())

    # Start the wake
    result = start_wake(track)
    if not result["ok"]:
        return {
            "state": "wedged",
            "track": track,
            "wake_id": None,
            "report_path": None,
            "duration_secs": 0,
            "error": result["message"],
        }

    # Wait until the new wake (start_ts > old_start_ts) and then for it to finish
    return await_wake(
        track,
        timeout_secs=timeout_secs,
        _started_after=old_start_ts,
    )


def latest_wake_for_track(track: str) -> Optional[dict]:
    """Return the most-recent wake (running or completed) for *track*.

    Returns a dict::

        {
            "wake_id":         str,
            "transcript_path": Path | None,
            "is_running":      bool,
            "num_turns":       int | None,   # None while running
            "cost_usd":        float | None, # None while running
        }

    Priority: a currently-running lock beats any wakes.tsv row.
    Returns None if no wake can be found for this track.

    Column layout for wakes.tsv data rows:
    * 9-col (current): wake_id, track, started_at, ended_at, slept_clean,
                        num_turns, cost_usd, early_break_reason, transcript_path
    * 8-col (legacy):  wake_id, started_at, ended_at, slept_clean, num_turns,
                        cost_usd, early_break_reason, transcript_path
                        (no track field — skipped)
    """
    track_dir = TRACKS_DIR / track
    lock_path = track_dir / "wake.lock"
    lws_path = track_dir / "last-wake-start.timestamp"

    # ── running wake ───────────────────────────────────────────────────────
    # Detection: last-wake-start.timestamp > last-wake.timestamp means the
    # wake started but hasn't written its end timestamp yet.  The lock file
    # holds an flock (no PID written), so we can't use _read_lock_pid here.
    lwe_path = track_dir / "last-wake.timestamp"
    if lws_path.exists():
        try:
            start_ts = int(lws_path.read_text().strip())
            try:
                end_ts = int(lwe_path.read_text().strip())
            except (OSError, ValueError):
                end_ts = 0  # no end timestamp → wake hasn't finished
            if start_ts > end_ts:
                wake_id = datetime.fromtimestamp(start_ts, tz=_tz.utc).strftime(
                    "%Y-%m-%dT%H-%M-%SZ"
                )
                # Per-track subfolders (current layout): WAKES_DIR/<track>/<id>/
                t_path = WAKES_DIR / track / wake_id / "transcript.jsonl"
                if not t_path.exists():
                    # Backward-compat: flat namespace (pre-fix wakes still in flight)
                    flat_path = WAKES_DIR / wake_id / "transcript.jsonl"
                    if flat_path.exists():
                        import sys as _sys
                        print(
                            f"[session] warn: falling back to flat wake path for {track}/{wake_id}",
                            file=_sys.stderr,
                        )
                        t_path = flat_path
                return {
                    "wake_id": wake_id,
                    "transcript_path": t_path if t_path.exists() else None,
                    "is_running": True,
                    "num_turns": None,
                    "cost_usd": None,
                }
        except (OSError, ValueError):
            pass  # fall through to wakes.tsv

    # ── last completed wake from wakes.tsv ─────────────────────────────────
    if not (_get_root() / "agent" / "runtime" / "wakes.tsv").exists():
        return None
    try:
        lines = WAKES_TSV.read_text().splitlines()
    except OSError:
        return None

    result: Optional[dict] = None
    for line in lines[1:]:  # skip header row
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 9:
            # 9-col layout (track field present)
            row_wake_id = parts[0]
            row_track = parts[1]
            num_turns_str = parts[5]
            cost_str = parts[6]
            transcript_rel = parts[8]
        elif len(parts) == 8:
            # 8-col legacy layout — no track info; skip
            continue
        else:
            continue

        if row_track != track:
            continue

        try:
            num_turns: Optional[int] = int(num_turns_str)
        except (ValueError, TypeError):
            num_turns = None
        try:
            cost_usd: Optional[float] = float(cost_str)
        except (ValueError, TypeError):
            cost_usd = None

        transcript_path = PROJECT_ROOT / transcript_rel if transcript_rel else None
        result = {
            "wake_id": row_wake_id,
            "transcript_path": transcript_path,
            "is_running": False,
            "num_turns": num_turns,
            "cost_usd": cost_usd,
        }

    return result


def parse_transcript_tail(
    transcript_path: Path,
    from_line: int = 0,
) -> tuple[list[str], int]:
    """Parse JSONL transcript events from *from_line* onwards.

    Returns ``(rendered_lines, new_from_line)`` where *new_from_line* is the
    total number of JSONL lines consumed so far (pass it back on the next call
    to resume where you left off).

    Only ``AssistantMessage`` events are rendered; ``UserMessage`` (tool
    results) and ``SystemMessage`` are skipped — they are too verbose for a
    tail view.

    Each content block becomes one or more display lines:
    * thinking block  → ``"🧠 <line1>"`` then ``"   <line2>"`` … (full content, multi-line)
    * text block      → the text as-is (may be multi-line)
    * tool-use block  → ``"  🔧 tool_name(<input preview>)"``
    """
    try:
        raw_bytes_lines = transcript_path.read_bytes().splitlines()
    except OSError:
        return [], from_line

    new_raw = raw_bytes_lines[from_line:]
    rendered: list[str] = []

    for raw_bytes in new_raw:
        raw = raw_bytes.strip()
        if not raw:
            continue
        try:
            event = _json.loads(raw)
        except (_json.JSONDecodeError, ValueError):
            continue

        if event.get("type") != "AssistantMessage":
            continue

        for block in event.get("data", {}).get("content", []):
            keys = set(block.keys())
            if "thinking" in keys and "text" not in keys and "name" not in keys:
                # Thinking block: {thinking, signature}
                # Render full content matching _print_event style: 🧠 on first line,
                # continuation indent on subsequent lines — no truncation.
                thinking = (block.get("thinking") or "").rstrip()
                lines = thinking.splitlines()
                if lines:
                    rendered.append(f"🧠 {lines[0]}")
                    for line in lines[1:]:
                        rendered.append(f"   {line}")
            elif "text" in keys and "name" not in keys:
                # Text block: {text}
                rendered.append(block["text"])
            elif "name" in keys and "input" in keys:
                # Tool-use block: {id, name, input}
                inp = str(block["input"])
                if len(inp) > 80:
                    inp = inp[:80] + "…"
                rendered.append(f"  🔧 {block['name']}({inp})")

    return rendered, from_line + len(new_raw)
