"""reflect report CLI command — context concatenator for agents."""
from __future__ import annotations

import sys
from types import SimpleNamespace

from agent.cli.ops.report import gather_report, parse_kinds


def cmd_report(args: SimpleNamespace) -> None:
    """Gather and print the concatenated report to stdout."""
    # Parse tracks from comma-separated string.
    tracks: list[str] | None = None
    if getattr(args, "tracks", None):
        tracks = [t.strip() for t in args.tracks.split(",") if t.strip()]

    # Parse kinds spec.
    kinds = parse_kinds(getattr(args, "kinds", None), default_limit=args.limit)

    # Parse include_state.
    include_state = getattr(args, "state", "core") or "core"

    result = gather_report(
        tracks=tracks,
        kinds=kinds,
        limit=args.limit,
        offset=args.offset,
        since=getattr(args, "since", None),
        until=getattr(args, "until", None),
        include_state=include_state,
    )

    if result:
        print(result)
    # Empty output = no tracks matched or all empty; no error, just silence.
