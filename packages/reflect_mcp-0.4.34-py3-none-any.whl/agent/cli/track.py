"""Track subcommands for the reflect CLI.

Thin adapter — all business logic lives in agent.cli.ops.track.
"""
from __future__ import annotations

import subprocess
import sys
import os
from pathlib import Path

from .output import OutputMode, print_list, print_record, print_table
from .ops.track import (
    list_tracks,
    get_track_state,
    enable_track,
    disable_track,
    create_track,
    create_from_template,
    create_from_family,
    send_to_track,
    interrupt_track,
    _template_uses_project,
    TEMPLATES,
)
# create_from_template and create_from_family are used by cmd_track_create routing.
# They are not exposed as separate CLI subcommands.


def cmd_track_list(args) -> None:
    mode = OutputMode(args.output)
    names = list_tracks()
    if not names:
        print("No tracks found.")
        return

    rows = []
    for name in names:
        s = get_track_state(name)
        if "error" in s:
            continue
        rows.append([
            s["name"],
            s["state"],
            s["last_wake_fmt"],
            s["unread_count"],
            s.get("backlog", "-"),
            s.get("next_wake_by_delta", "-"),
        ])

    print_table(["name", "state", "last_wake", "unread", "backlog", "next_wake"], rows, mode)


def cmd_track_status(args) -> None:
    mode = OutputMode(args.output)
    s = get_track_state(args.name)

    if "error" in s:
        print(s["error"], file=sys.stderr)
        sys.exit(1)

    record = {
        "name": s["name"],
        "state": s["state"],
        "last_wake": s["last_wake_fmt"],
        "last_wake_start": s["last_wake_start_fmt"],
        "unread_count": s["unread_count"],
        "lock_pid": s["lock_pid"] if s["lock_pid"] else "-",
        "pending_originator": s.get("pending_originator", "-"),
        "pending_followup": s.get("pending_followup", "-"),
        "backlog": s.get("backlog", "-"),
        "next_wake_by": (
            f"{s['next_wake_by_fmt']} - {s['next_wake_by_delta']}"
            if s.get('next_wake_by_fmt') not in (None, '-')
            else s.get('next_wake_by_delta', '-')
        ),
    }
    print_record(record, mode)

    # Recent inbox files (up to 5)
    from agent.cli.ops.root import resolve_project_root
    PROJECT_ROOT = resolve_project_root()
    TRACKS_DIR = PROJECT_ROOT / "agent" / "runtime" / "tracks"
    track_dir = TRACKS_DIR / args.name
    inbox_dir = track_dir / "inbox"
    consumed_dir = inbox_dir / ".consumed"
    if inbox_dir.exists():
        unread = sorted([p for p in inbox_dir.glob("*.md") if p.is_file()], reverse=True)
        consumed_names: set[str] = set()
        if consumed_dir.exists():
            consumed_names = set(p.name for p in consumed_dir.glob("*.md"))
        unread = [p for p in unread if p.name not in consumed_names][:5]

        if unread:
            if mode == OutputMode.HUMAN:
                print("\nRecent inbox (unread):")
                for p in unread:
                    print(f"  {p.name}")
            else:
                import json
                print(json.dumps({"recent_inbox": [p.name for p in unread]}, indent=2))

    # Last 3 wake IDs from wakes.tsv
    wakes_tsv = PROJECT_ROOT / "agent" / "runtime" / "wakes.tsv"
    if wakes_tsv.exists():
        try:
            lines = wakes_tsv.read_text().splitlines()
            wake_ids = [line.split("\t")[0] for line in lines[1:] if line]
            wake_ids = wake_ids[-3:]
            if wake_ids:
                if mode == OutputMode.HUMAN:
                    print("\nRecent wake IDs (global):")
                    for wid in wake_ids:
                        print(f"  {wid}")
                else:
                    import json
                    print(json.dumps({"recent_wake_ids": wake_ids}, indent=2))
        except OSError:
            pass


def cmd_track_tail(args) -> None:
    name = args.name
    log_path = f"/tmp/reflect-tick-{name}.log"
    follow = not getattr(args, "no_follow", False)

    # When following on an interactive TTY, prefer the TUI TailScreen — it
    # shows a hashed-color status bar identifying the track. Fall back to
    # bare `tail` when stdout isn't a TTY (pipes, redirects, --no-follow)
    # so existing scripts keep working.
    if follow and sys.stdout.isatty():
        if not os.path.exists(log_path):
            print(f"No log yet at {log_path}; waiting... (ctrl-c to exit)")
            import time
            while not os.path.exists(log_path):
                time.sleep(1)
        from textual.app import App, ComposeResult
        from textual.binding import Binding
        from .tui.dashboard_app import TailScreen

        class _SoloTailApp(App):
            BINDINGS = [Binding("q", "quit", "Quit", show=True)]

            def __init__(self, track: str) -> None:
                super().__init__()
                self._track = track

            def on_mount(self) -> None:
                self.push_screen(TailScreen(self._track))

        try:
            _SoloTailApp(name).run()
        except KeyboardInterrupt:
            pass
        return

    if not os.path.exists(log_path):
        print(f"No log found at {log_path}")
        return

    cmd = ["tail", "-n", "20", log_path]
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        pass


def cmd_track_logs(args) -> None:
    name = args.name
    log_path = f"/tmp/reflect-tick-{name}.log"

    if not os.path.exists(log_path):
        print(f"No log found at {log_path}")
        return

    try:
        with open(log_path) as f:
            print(f.read(), end="")
    except OSError as e:
        print(f"Error reading log: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_track_enable(args) -> None:
    result = enable_track(args.name)
    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)
    print(result["message"])


def cmd_track_disable(args) -> None:
    result = disable_track(args.name)
    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)
    print(result["message"])


def cmd_track_create(args) -> None:
    """Unified track create handler — routes to appropriate ops based on flags.

    Modes:
    - --from-template-family               → bulk create (scope determines project/global)
    - --template + --project               → single auditor track (create_from_template)
    - --template only                      → generic track (create_track)
    """
    from_template_family = getattr(args, "from_template_family", None)
    projects_str = getattr(args, "projects", None)
    project = getattr(args, "project", None)
    cadence_seconds = getattr(args, "cadence_seconds", None)
    filter_val = getattr(args, "filter", None)
    template_key = getattr(args, "template", None) or "blank"

    # Mutual exclusion: --template and --from-template-family are incompatible
    if from_template_family and template_key != "blank":
        print("Error: --template and --from-template-family are mutually exclusive.", file=sys.stderr)
        sys.exit(1)

    if from_template_family:
        # Bulk mode: let create_from_family enforce scope requirements
        project_list = [p.strip() for p in projects_str.split(",") if p.strip()] if projects_str else None
        result = create_from_family(
            family=from_template_family,
            projects=project_list,
            cadence_seconds=cadence_seconds,
            filter_override=filter_val,
        )
        if result["created"]:
            for entry in result["created"]:
                print(f"  Created: {entry['track_name']} → {entry['track_dir']}")
        if result["failed"]:
            for entry in result["failed"]:
                project_id = entry.get("project", "?")
                template_id = entry.get("template", "?")
                print(f"  Failed ({project_id}/{template_id}): {entry['message']}", file=sys.stderr)
        if not result["ok"]:
            sys.exit(1)

    elif project:
        # --project provided: validate that template actually uses {project}
        tmpl_str = TEMPLATES.get(template_key, "")
        if not _template_uses_project(tmpl_str):
            print(
                f"Error: --project='{project}' passed but template '{template_key}' does not use {{project}}. "
                f"Use a project-scoped template (e.g. smoke-test-auditor) or omit --project.",
                file=sys.stderr,
            )
            sys.exit(1)
        # Single auditor template mode: --template + --project
        result = create_from_template(
            template=template_key,
            project=project,
            cadence_seconds=cadence_seconds,
            filter_override=filter_val,
            name=args.name,
        )
        if not result["ok"]:
            print(result["message"], file=sys.stderr)
            sys.exit(1)
        print(result["message"])
        print(f"  Track dir: {result['track_dir']}")

    else:
        # Basic mode: generic template (blank, security-audit, etc.)
        extra_vars: dict = {}
        if cadence_seconds is not None:
            extra_vars["cadence_seconds"] = cadence_seconds
        if filter_val is not None:
            extra_vars["filter"] = filter_val
        result = create_track(args.name, template=template_key, **extra_vars)
        if not result["ok"]:
            print(result["message"], file=sys.stderr)
            sys.exit(1)
        print(result["message"])
        print(f"  Edit {result['track_dir']}/wake.md to define this track's identity.")


def cmd_track_send(args) -> None:
    """Drop a message into a track's inbox (soft delivery — next-wake)."""
    mode = OutputMode(args.output)
    result = send_to_track(args.name, args.message)

    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)

    if mode == OutputMode.HUMAN:
        print(result["message"])
        if result.get("inbox_path"):
            print(f"  → {result['inbox_path']}")
    else:
        import json
        print(json.dumps(result, indent=2))


def cmd_track_interrupt(args) -> None:
    """Inject a message into a running track's wake via interrupt socket.

    If the track is sleeping (no socket), degrades gracefully to inbox-drop.
    """
    mode = OutputMode(args.output)
    result = interrupt_track(args.name, args.message)

    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)

    if mode == OutputMode.HUMAN:
        print(result["message"])
        if result.get("inbox_path"):
            print(f"  → {result['inbox_path']}")
    else:
        import json
        print(json.dumps(result, indent=2))


def cmd_track_session(args) -> None:
    """Launch the interactive session TUI for a track."""
    from .tui.session_view import SessionApp

    replay = getattr(args, "replay", 20)
    try:
        SessionApp(track_name=args.name, replay_last=replay).run(mouse=False)
    except KeyboardInterrupt:
        pass
