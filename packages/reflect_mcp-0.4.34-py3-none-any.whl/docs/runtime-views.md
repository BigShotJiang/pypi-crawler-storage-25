<!-- @scry.entry
id: design.runtime-views~0347b2ac
kind: design
status: active
weight: 0.85
tags:
  - "topic:architecture"
  - "architecture"
  - "topic:runtime"
  - "runtime"
  - "scope:substrate"
  - "substrate"
  - "topic:wake-lifecycle"
  - "wake-lifecycle"
  - "topic:dispatch"
  - "dispatch"
  - "topic:inbox"
  - "inbox"
  - "topic:events"
  - "events"
  - "topic:system-prompt"
  - "system-prompt"
summary: >
  Multi-view structural description of the reflection runtime as it
  exists today (2026-05-16). Five complementary views: (1) single-wake
  lifecycle sequence, (2) inbox/followup message-flow state machine,
  (3) component node/edge map, (4) system-prompt construction layers,
  (5) wake-scheduling state machine. Produced from direct source
  reading of wake.py, prompt.py, events.py, tick.py, and
  briefing.py — describes the current system, not the roadmap.
  Also: wake lifecycle, track model, inbox protocol, followup
  protocol, dispatch, scheduling, MCP servers, events stream, prompt
  construction, wake supervisor, Claude Agent SDK, briefing, backlog
  override, cadence floor, worktree-per-wake, interrupt socket,
  pause/resume, stop.requested, artifact summary, wakes.tsv, transcript.
rationale: >
  Without this, understanding the runtime requires reading ~1500 lines
  across five files simultaneously. A cold-read future wake cannot
  quickly orient to component relationships, message lifecycle, or
  scheduling mechanics. This doc is the orientation surface for
  anyone debugging, extending, or designing against the substrate.
applies: >
  orienting to the reflection runtime, debugging wake lifecycle,
  understanding inbox/followup flow, tracing a message from dispatch
  to sleep, reviewing scheduling mechanics, reviewing event types,
  understanding MCP server topology
seeded_questions:
  - "How does a wake start end to end?"
  - "What happens to an inbox message during a wake?"
  - "How does the dispatcher decide to fire a wake?"
  - "What MCP servers does the agent have access to?"
  - "How is the system prompt assembled?"
  - "What events does the runtime emit?"
  - "How does the backlog override work?"
  - "wake lifecycle sequence diagram"
  - "reflection runtime component diagram"
  - "inbox followup state machine"
@scry.entry.end -->

# Reflection Runtime — Structural Views

Produced 2026-05-16 from direct source reading. Five views of the
current substrate. No roadmap content; no aspirational design.

Sources read:
- `agent/runtime/wake.py` — wake supervisor and loop
- `agent/runtime/prompt.py` — system-prompt assembly
- `agent/runtime/events.py` — event stream emitter
- `agent/runtime/briefing.py` — briefing content builder
- `agent/lib/tick.py` — dispatch / scheduling signal check


## View 1 — Single-Wake Lifecycle (Sequence)

One full wake, from dispatcher tick to post-wake cleanup.

```
  Dispatcher (cron tick, ~60s)
  ──────────────────────────────────────────────────────────
      │
      │  check_track_signal(track)
      │    → reads next-wake-by.timestamp
      │    → reads inbox/*.md mtimes vs last-wake-start
      │    → reads followup/*.md pending count
      │    → reads dialogue.md/wake.md mtime (main only)
      │
      ├─ should_fire = False → sleep until next tick
      │
      └─ should_fire = True
             │
             ▼
  Wake Supervisor  _run_wake()
  ──────────────────────────────────────────────────────────
  [BOOT]
      │  assign wake_id (ISO timestamp)
      │  mkdir transcript dir
      │  mark_running() → status.json
      │  emit "track.running", "wake.started" → events.jsonl
      │  write last-wake-start.timestamp
      │  write wake.lock (PID)
      │  delete next-wake-by.timestamp
      │
  [EARLY GUARDS]
      │  stop.requested present? → emit wake.failed, return
      │  read wake_override.yaml (conflict-res caps) if present
      │  load track config.yaml (worktree_per_wake, stall_timeout)
      │  create worktree if worktree_per_wake=true
      │
  [AGENT SETUP]
      │  reset_sleep_state(), set_budget_caps()
      │  set GIT_AUTHOR/COMMITTER env, REFLECT_WAKE_ID
      │  install commit-msg hook (idempotent)
      │  build_system_prompt() → write to transcript/system-prompt.md
      │
  [INBOX SWEEP — Solution E]
      │  _migrate_legacy_followup_dir() (idempotent)
      │  for each unread inbox/*.md:
      │      write followup/{ts}-{slug}.md
      │      mv inbox/{slug}.md → inbox/.consumed/{slug}.md
      │
  [BRIEFING]
      │  build_briefing_content(track)
      │      → followup listing
      │      → from-agent listing
      │      → recent reports (last 5)
      │      → recent git commits (last 10)
      │      → heartbeat log tail (last 10)
      │
  [AGENT LOOP — Claude Agent SDK]
      │  client.connect(_as_stream(wake_id, briefing))
      │      turn 1: briefing synthetic user message
      │              (cached body block + uncached footer)
      │      turn 2: wake directive (terse: "Read fresh signal...")
      │
      │  start interrupt socket listener (background asyncio task)
      │      unix socket at tracks/{track}/interrupt.sock
      │
      │  for message in receive_messages() [stall timeout N s]:
      │      → write to transcript.jsonl (JSONL, append)
      │      → _print_event() to stderr (live stream)
      │      → if AssistantMessage: increment_turn(cost_delta)
      │      → if ToolUseBlock:
      │            sleep tool    → sleep_observed=True,
      │                            capture sleep_next_wake_seconds
      │            Write/Edit    → append to _artifact_files
      │            track/send    → record in _pending_send_ids
      │      → if UserMessage + _pending_send_ids:
      │            extract sent inbox path → _artifact_inbox_sent
      │      → check stop.requested → graceful break
      │      → check pause.requested → 1s poll until resume/stop
      │      → if sleep_observed + UserMessage: break
      │
      │  cancel interrupt socket task
      │  client.disconnect()
      │
  [POST-WAKE FINALLY — always runs]
      │
      │  worktree promotion (if worktree_per_wake + sleep_observed)
      │      clean merge  → advance reflect/last-known-good
      │      conflict     → file inbox report, write wake_override.yaml
      │                     force next-wake-by = now-1
      │
      │  _print_artifact_summary() → stdout
      │      (files written, commits, inbox sent, wake report)
      │
      │  write last-wake.timestamp
      │
      │  _apply_cadence_floor()
      │      if drafts>0 OR unread>0 OR open_threads>0:
      │          clamp next-wake-by to now (immediate)
      │
      │  _apply_backlog_override()
      │      backlog = pending_inbox + active_followups
      │      if backlog > 0: next-wake-by = now-1 (atomic rename)
      │
      │  _apply_work_produced_guard()
      │      if HEAD changed + remaining_work > 0:
      │          next-wake-by = now+60s (unless already more urgent)
      │
      │  push_wake_snapshot() → portal D1 (main only)
      │
      │  append row to wakes.tsv
      │      (wake_id, track, started, ended, slept_clean,
      │       turns, cost_usd, early_break_reason, transcript_path)
      │
      │  emit "wake.completed" or "wake.failed" → events.jsonl
      │  if sleep_observed + sleep_next_wake_seconds > 0:
      │      emit "wake.scheduled" → events.jsonl
      │
      │  mark_idle() or mark_unhealthy() → status.json
      │  remove wake.lock
      │
      └─ done; dispatcher takes control on next cron tick
```


## View 2 — Message-Flow / State (Inbox → Followup)

How a message travels from arrival to completion, and how the
backlog counter interacts with scheduling.

```
  ┌─────────────────────────────────────────────────────────┐
  │  ARRIVAL                                                │
  │                                                         │
  │  Originator (or another track) writes to:               │
  │    tracks/{track}/inbox/{ts}-{slug}.md                  │
  │    (P9 unified inbox; frontmatter: from/to/at/kind)     │
  │                                                         │
  │  Signal check (tick.py) fires because:                  │
  │    mtime of inbox file > last-wake-start.timestamp      │
  └──────────────────────────┬──────────────────────────────┘
                             │
                             ▼
  ┌─────────────────────────────────────────────────────────┐
  │  WAKE START — _sweep_inbox_to_followup()                │
  │                                                         │
  │  For each unread inbox/{slug}.md:                       │
  │                                                         │
  │    1. write followup/{ts}-{slug}.md                     │
  │       (frontmatter: consumed_from, consumed_at,         │
  │        status: open; body: copy of inbox message)       │
  │                                                         │
  │    2. mv inbox/{slug}.md → inbox/.consumed/{slug}.md    │
  │                                                         │
  │  Crash safety: write-then-move order. If crash after    │
  │  write but before move, next wake sees inbox file,      │
  │  skips followup write (slug already exists), and        │
  │  retries the move.                                      │
  └──────────────────────────┬──────────────────────────────┘
                             │
                             ▼
  ┌─────────────────────────────────────────────────────────┐
  │  AGENT WORK PHASE                                       │
  │                                                         │
  │  Agent reads followup/{ts}-{slug}.md from briefing.     │
  │  Does the work. Three outcomes:                         │
  │                                                         │
  │  A) Work complete in this wake:                         │
  │     mv followup/{slug}.md → followup/.completed/        │
  │     → backlog decreases; next wake may be long          │
  │                                                         │
  │  B) Work incomplete (cannot finish this wake):          │
  │     followup stays open (status: open)                  │
  │     → backlog remains; _apply_backlog_override fires    │
  │       next-wake-by = now-1 (immediate)                  │
  │                                                         │
  │  C) Work blocked (waiting on external actor):           │
  │     create followup/{slug}.md.blocked sentinel          │
  │     → backlog-override skips blocked followups          │
  │     → dispatcher respects agent's sleep choice          │
  └──────────────────────────┬──────────────────────────────┘
                             │
                             ▼
  ┌─────────────────────────────────────────────────────────┐
  │  BACKLOG COUNTER (post-wake)                            │
  │                                                         │
  │  backlog = pending_inbox + active_followups             │
  │                                                         │
  │  pending_inbox:                                         │
  │    count of *.md in inbox/ not in inbox/.consumed/      │
  │    + count in inbox/from-originator/ (pre-P9 compat)   │
  │                                                         │
  │  active_followups:                                      │
  │    count of *.md in followup/ not in followup/.completed│
  │    and no corresponding .blocked sentinel file          │
  │                                                         │
  │  if backlog > 0:                                        │
  │    next-wake-by.timestamp = now-1  (atomic rename)      │
  │    next dispatcher tick fires the wake immediately      │
  │                                                         │
  │  if backlog == 0:                                       │
  │    sleep tool's next_wake_in_seconds is honored         │
  └─────────────────────────────────────────────────────────┘

  Directory layout (P9):

    tracks/{track}/
      inbox/
        {ts}-{slug}.md          ← unread (counts as backlog)
        .consumed/
          {ts}-{slug}.md        ← archived (not counted)
        from-originator/        ← pre-P9 compat path
          .consumed/
      followup/
        {ts}-{slug}.md          ← open (counts as backlog)
        {ts}-{slug}.md.blocked  ← sentinel: skip from backlog
        .completed/
          {ts}-{slug}.md        ← done (not counted)
```


## View 3 — Component Node / Edge Map

Static topology: components and their read/write relationships.

```
  ┌──────────────────────────────────────────────────────────┐
  │  DISPATCH LAYER                                          │
  │                                                          │
  │  cron (60s tick)                                         │
  │       │                                                  │
  │       ▼                                                  │
  │  reflect-dispatch (bin/reflect-dispatch)                 │
  │       │  for each enabled track:                         │
  │       │    check_track_signal(track) [tick.py]           │
  │       │    reads:                                        │
  │       │      tracks/{t}/next-wake-by.timestamp           │
  │       │      tracks/{t}/last-wake-start.timestamp        │
  │       │      tracks/{t}/inbox/*.md  (mtime check)        │
  │       │      tracks/{t}/followup/*.md (pending count)    │
  │       │      dialogue.md, wake.md (main only)            │
  │       │    acquires: tracks/{t}/wake.lock (fcntl + PID)  │
  │       │    if signal → exec reflect-wake --track={t}     │
  │       │                                                  │
  └──────────────────────────────────────────────────────────┘
                          │
                          ▼
  ┌──────────────────────────────────────────────────────────┐
  │  WAKE SUPERVISOR  (wake.py _run_wake)                    │
  │                                                          │
  │  reads/writes:                                           │
  │    tracks/{t}/last-wake-start.timestamp  (writes)        │
  │    tracks/{t}/last-wake.timestamp        (writes)        │
  │    tracks/{t}/next-wake-by.timestamp     (del + writes)  │
  │    tracks/{t}/wake.lock                  (writes PID)    │
  │    tracks/{t}/stop.requested             (reads/deletes) │
  │    tracks/{t}/pause.requested            (polls)         │
  │    tracks/{t}/wake_override.yaml         (reads/deletes) │
  │    tracks/{t}/config.yaml                (reads)         │
  │    tracks/{t}/interrupt.sock             (unix socket)   │
  │    wakes/{track}/{wake_id}/transcript.jsonl (writes)     │
  │    wakes/{track}/{wake_id}/system-prompt.md (writes)     │
  │    wakes.tsv                             (appends)       │
  │    status.json                           (writes)        │
  │    agent/runtime/events/{YYYY-MM-DD}.jsonl (appends)     │
  │                                                          │
  │  spawns:                                                 │
  │    ┌────────────────────────────────────────────────┐    │
  │    │  Claude Agent SDK (claude subprocess)          │    │
  │    │                                                │    │
  │    │  receives:                                     │    │
  │    │    system prompt (file path, avoid E2BIG)      │    │
  │    │    briefing (cached user turn)                 │    │
  │    │    wake directive (uncached user turn)         │    │
  │    │                                                │    │
  │    │  emits (AsyncIterator):                        │    │
  │    │    AssistantMessage (text, thinking, tools)    │    │
  │    │    UserMessage (tool results)                  │    │
  │    │    ResultMessage (final, num_turns, cost)      │    │
  │    │    SystemMessage (permission denials)          │    │
  │    │                                                │    │
  │    │  tool calls dispatched to:                     │    │
  │    │    Read/Write/Edit/Glob/Grep/Bash/WebFetch     │    │
  │    │    MCP reflect-wake server (see below)         │    │
  │    │    MCP scry server (see below)                 │    │
  │    └────────────────────────────────────────────────┘    │
  │                                                          │
  │  parallel background task:                               │
  │    interrupt socket listener                             │
  │      waits on interrupt.sock                             │
  │      on connection: read message, call client.interrupt()│
  │      + client.query(msg) — injects mid-wake user turn    │
  │                                                          │
  └──────────────────────────────────────────────────────────┘
                  │tool calls│
         ┌────────┴──────────────────────────────┐
         ▼                                       ▼
  ┌─────────────────────┐          ┌────────────────────────┐
  │  MCP: reflect-wake  │          │  MCP: scry             │
  │  (in-process server)│          │  (subprocess: scry     │
  │                     │          │   serve --project-db)  │
  │  tools:             │          │                        │
  │    sleep            │          │  tools:                │
  │    budget           │          │    scry_sql            │
  │    pause            │          │    scry_mint           │
  │    browser_fetch    │          │    scry_mint_with_check │
  │    scry_mint_       │          │    scry_surface        │
  │      with_check     │          │    scry_grep           │
  │                     │          │    scry_script         │
  │  sleep tool:        │          │    scry_sink           │
  │    sets sleep_state │          │                        │
  │    writes           │          │  reads/writes:         │
  │    next-wake-by.ts  │          │    project.db (sqlite) │
  │    supervisor breaks│          │    @scry.* markers     │
  │    the loop         │          │    on tracked files    │
  └─────────────────────┘          └────────────────────────┘

  Observability sidecar:

  ┌──────────────────────────────────────────────────────────┐
  │  Event stream  (events.py)                               │
  │                                                          │
  │  emit_event(type, track, wake_id, payload)               │
  │    → agent/runtime/events/{YYYY-MM-DD}.jsonl (append)    │
  │    → events.jsonl symlink → today's file                 │
  │    → deliver_event() → webhooks (fire-and-forget)        │
  │    → 90-day retention (gzip old files)                   │
  │                                                          │
  │  event types emitted by wake supervisor:                 │
  │    track.running   — wake boot                           │
  │    wake.started    — wake boot                           │
  │    track.paused    — pause.requested detected            │
  │    commit.made     — worktree promoted cleanly           │
  │    wake.completed  — sleep tool called                   │
  │    wake.scheduled  — sleep_next_wake_seconds > 0         │
  │    wake.failed     — no sleep call / error / signal      │
  │    track.idle      — post-wake (clean exit)              │
  └──────────────────────────────────────────────────────────┘
```


## View 4 — System-Prompt Construction (Layer Stack)

`build_system_prompt()` in `prompt.py` assembles layers in order:

```
  Layer 1: Identity baseline (always present)
  ─────────────────────────────────────────────
  concept.md          (originating provocation)
  wake.md             (constitution + entries 0000–0013)
  agent/design/reflection.md  (self-understanding doc)

  Layer 2: Runtime protocol
  ─────────────────────────────────────────────
  protocol.md         (P9 inbox, P10 project location,
                       P11 track decisions; cross-cutting
                       contracts)

  Layer 3: Track-specific wake (REFLECT_TRACK)
  ─────────────────────────────────────────────
  tracks/{track}/wake.md
    (if absent → empty section)
    Injected as:
      ========================================
      TRACK WAKE: {track}
      ========================================
      {contents}
      ========================================
      END TRACK WAKE
      ========================================

  Layer 4: Orchestration roster (orchestrator tracks only)
  ─────────────────────────────────────────────
  Loaded when track == "main" (all tracks)
  or track ends in "-orchestrator" ({prefix}-* tracks).
  For each subordinate track: track name + first non-heading
  paragraph from that track's wake.md.

  Layer 5: Operating context + tools reference
  ─────────────────────────────────────────────
  Injected inline — the large "Current operating context:
  autonomous wake" block (orientation steps, scry discipline,
  bounds, git safety, self-modification pattern, off-limits
  files, posture, storage policy, tool list).

  ─────────────────────────────────────────────
  Total assembled → written to:
    wakes/{track}/{wake_id}/system-prompt.md
  Passed to SDK as {"type": "file", "path": "..."}
  (file form avoids 128 KiB E2BIG argv limit)

  Briefing (separate user turn, cached body):
  ─────────────────────────────────────────────
  build_briefing_content(track) in briefing.py:
    - Inbox listing (unread from-agent files)
    - Followup listing (open followup files)
    - Recent reports (last 5 from agent/reports/)
    - Recent git commits (last 10, git log --oneline)
    - Heartbeat log tail (last 10 lines)
  Cache-stable: no timestamps in body; lists sorted
  alphabetically. Footer block uncached (has timestamp).

  Two synthetic user turns sent to SDK:
    turn 1 → briefing content (cache_control on body)
    turn 2 → wake directive ("Read fresh signal since
              the last heartbeat, decide what's useful...")
```


## View 5 — Wake-Scheduling State Machine

How `next-wake-by.timestamp` moves through states and how
the post-wake hooks override the agent's choice.

```
  States of next-wake-by.timestamp:

    ABSENT  ────────────────────────────────────────┐
    (no file)                                       │
    Meaning: "pause; fire only on external signal"  │
    Set by: wake supervisor at wake start            │
             (unconditional delete)                 │
                                                    │
            ┌───────────────────────────────────────┘
            │
            ▼
    AGENT-WRITTEN  ──────────────────────────────────┐
    Value: now + N  (N = sleep_next_wake_seconds)    │
    Set by: sleep MCP tool (atomic file write)        │
    Meaning: "wake me in N seconds"                  │
             N=0 → agent chose to not self-schedule  │
                                                     │
            ┌────────────────────────────────────────┘
            │  post-wake hooks may override:
            │
            ├─ _apply_cadence_floor()
            │    condition: drafts>0 OR unread>0
            │               OR open_threads>0
            │    overrides to: now  (immediate)
            │    direction: can only move earlier
            │
            ├─ _apply_backlog_override()
            │    condition: pending_inbox + active_followups > 0
            │    overrides to: now-1  (atomic rename)
            │    direction: always wins; runs after cadence floor
            │
            └─ _apply_work_produced_guard()
                 condition: HEAD changed + remaining_work > 0
                 overrides to: now+60  (if not already more urgent)
                 direction: only overrides if current ts > now

            ▼
    ELAPSED  ────────────────────────────────────────┐
    Dispatcher sees: now >= value in file             │
    Action: acquire wake.lock, exec reflect-wake      │
                                                     │
            ┌────────────────────────────────────────┘
            │
            ▼
    (back to ABSENT — wake supervisor deletes on boot)

  External signals that bypass scheduling:

    1. Manual: reflect wake start {track}
       → dispatcher fires immediately, ignores timestamp

    2. Interrupt: reflect wake interrupt {track} {msg}
       → writes to interrupt.sock of running wake
       → injects msg as next user turn mid-wake

    3. Stop: reflect wake stop {track}
       → writes stop.requested
       → wake supervisor checks between SDK messages
       → graceful break; wake exits without sleep call

    4. Pause/resume:
       → writes pause.requested
       → wake enters 1s poll loop (LLM context preserved)
       → resume: deletes pause.requested
       → wake continues from next SDK message
```


## Summary Table — Key Files Per Component

```
Component           Reads                      Writes
──────────────────────────────────────────────────────────────
Dispatcher          next-wake-by.timestamp     wake.lock (fcntl)
(tick.py)           last-wake-start.timestamp
                    inbox/*.md (mtime)
                    followup/*.md (count)
                    dialogue.md, wake.md (main)

Wake Supervisor     wake.lock, stop.requested  last-wake.timestamp
(wake.py)           pause.requested            last-wake-start.timestamp
                    wake_override.yaml         next-wake-by.timestamp
                    config.yaml                wake.lock (PID)
                    system-prompt.md (write)   wakes.tsv (append)
                                               transcript.jsonl
                                               status.json
                                               events/{date}.jsonl

Briefing builder    followup/*.md              (none — read only)
(briefing.py)       agent/reports/*.md
                    git log (subprocess)
                    heartbeat.log

Prompt builder      concept.md, wake.md        system-prompt.md
(prompt.py)         design/reflection.md
                    protocol.md
                    tracks/*/wake.md

Events emitter      (runtime_root)             events/{date}.jsonl
(events.py)                                    events.jsonl (symlink)

MCP: reflect-wake   (internal state)           next-wake-by.timestamp
                                               pause.requested (pause)

MCP: scry           project.db                 project.db
                    tracked files (markers)
```
