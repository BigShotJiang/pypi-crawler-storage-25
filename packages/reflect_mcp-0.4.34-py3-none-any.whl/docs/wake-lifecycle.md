<!-- @scry.entry
id: design.wake-lifecycle~ddd12bfa
kind: design
status: active
weight: 0.9
tags:
  - "topic:wake-lifecycle"
  - "wake-lifecycle"
  - "topic:runtime"
  - "runtime"
  - "scope:substrate"
  - "substrate"
  - "topic:inbox"
  - "inbox"
  - "topic:followup"
  - "followup"
  - "topic:boot-sequence"
  - "boot-sequence"
summary: >
  Compact wake lifecycle skeleton for agents. Covers the seven phases:
  BOOT, INBOX SWEEP, BRIEFING, WORK, REPORT, HEARTBEAT, SLEEP. Key
  teaching: inbox messages are consumed and followups are auto-minted
  during BOOT, before agent reasoning begins. A followup found at WORK
  time was created by THIS wake's own boot — it means NOT YET STARTED,
  not stalled prior work from a previous wake. Also: wake lifecycle,
  boot phase, inbox-sweep, auto-followup, agent loop, phase ordering,
  solution-E, before-reasoning, provenance.
rationale: >
  Without this, wakes misread auto-generated followups as evidence of
  prior incomplete work and burn reasoning budget reconstructing phantom
  timelines. The compressed skeleton with the inline callout stops that
  misread at first encounter.
applies: >
  reading followup files at wake start, debugging phantom-timeline
  reasoning, understanding why a followup exists, orienting to wake
  phase ordering, building anything that changes inbox/followup flow
seeded_questions:
  - "Why does a followup exist if I didn't create it?"
  - "When are auto-followups created?"
  - "What phase does agent reasoning start?"
  - "Is an empty followup stalled prior work?"
  - "wake lifecycle sequence"
  - "inbox sweep before agent reasoning"
  - "auto-followup provenance"
@scry.entry.end -->

# Wake Lifecycle

Compact reference for phase ordering. Full diagrams in
`docs/runtime-views.md`.

## Phase skeleton

```
[BOOT]        supervisor acquires lock, smoke-tests runtime

[INBOX SWEEP] for each unread inbox/*.md:             ← runs before
    │             write followup/{ts}-{slug}.md         agent reasons
    │             mv   inbox/{slug}.md → .consumed/
    │
    │         ╔═══════════════════════════════════════════════╗
    │         ║ AGENT REASONING HAS NOT STARTED YET          ║
    │         ╚═══════════════════════════════════════════════╝

[BRIEFING]    build briefing → synthetic user message

[WORK]        ← agent reasoning starts here
    │         inbox: already consumed
    │         followups: already minted by THIS boot
    │
    │         a followup found here was written by THIS wake's
    │         boot phase, not by a prior wake — empty Progress
    │         means NOT YET STARTED, not stalled prior work

[REPORT]      write wake report to agent/reports/
[HEARTBEAT]   append to heartbeat.log
[SLEEP]       call sleep tool → schedules next wake atomically
```

## The key invariant

By the time the agent reads its briefing, every inbox message is
already consumed and every corresponding followup is already minted.
A followup the agent "discovers" was most likely written 30 seconds
ago by its own boot, not days ago by a prior wake.

**Empty Progress + status: open = NOT yet started.**
This is the normal state at WORK time. It is not a warning.

## Closing a followup

When the work described in a followup is complete, move the file to
`followup/.completed/`. Do not delete it — the completed archive is
the audit record.

## Full reference

`docs/runtime-views.md` — five-view structural description of the
runtime: single-wake lifecycle (View 1), inbox/followup state machine
(View 2), component map (View 3), system-prompt layers (View 4),
wake-scheduling state machine (View 5).
