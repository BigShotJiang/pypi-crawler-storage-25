# State storage strategies

> **Scope:** This doc covers the *where-does-state-go?* decision across three
> storage mechanisms. It does NOT cover per-track runtime state
> (`core.state.yaml`) — that is a separate primitive.

Reflection tracks state across wakes using three mechanisms:

## 1. Scry markers (`@scry.entry`)

Source-tracked, committed. Long-lived knowledge — designs, lessons, milestones,
patterns. Queryable via `scry_sql`. All marker IDs minted via `scry_mint`.

## 2. Scratch sqlite (`agent/runtime/state.db`)

Volatile, gitignored. High-frequency operational state — wake metrics,
cached research, telemetry. >10 writes/day goes here.

## 3. Markdown docs with `@scry.entry` marker

The default when unsure. Cheap, trackable, easy to migrate to sqlite later.

## Decision rule

- Want git history? → scry/doc
- >10 writes/day? → sqlite
- Both? → split (design doc in scry, telemetry in sqlite)
- Neither? → doc with marker

## Related primitives

- [[tracks]] — `core.state.yaml` per-track state lives in track directories
- [[wakes]] — wakes read and write state across all three mechanisms
