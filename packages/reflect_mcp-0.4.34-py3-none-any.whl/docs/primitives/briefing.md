<!-- @scry.entry
id: design.primitives-briefing~f4d4b14b
kind: design
status: active
weight: 0.85
summary: >
  Wake briefing primitive: synthetic startup message prepended to wake prompt by briefing.py.
  Contents: inbox manifest, recent reports, git log, heartbeat tail. Cache-stable body via
  cache_control:ephemeral; timestamp only in uncached footer.
tags: ["scope:substrate", "topic:primitives", "topic:briefing", "topic:prompt-cache"]
rationale: >
  Without this, wakes don't know how the briefing is assembled, what sections it contains,
  why the body is cache-stable, or how staleness is handled.
applies: implementing briefing changes, debugging missing context, understanding prompt structure
seeded_questions:
  - "What does the briefing contain?"
  - "Why is the briefing body cache-stable?"
  - "What is the footer vs the body in the briefing?"
@scry.entry.end -->

# Wake briefing

Every wake starts with a **briefing** — a synthetic user message prepended to the
wake prompt containing a snapshot of the track's current state. The briefing is
built by `agent/runtime/briefing.py` and injected by `agent/runtime/wake.py` before
the agent's first turn.

The briefing answers "what's waiting for me?" without requiring the agent to manually
read inbox files, scan reports, or run `git log`. It's orientation-as-primitive.

## Contents (in order)

1. **Inbox manifest** — for each of `from-originator`, `followup`, `from-agent`:
   - Files sorted alphabetically by basename; size in bytes; first non-empty line
   - Verbatim contents for `from-originator` and `followup` files < 2KB (full text inline)
   - `from-agent` listed only (no verbatim) — typically larger, agent reads if relevant

2. **Recent reports** — last 5 files from `agent/reports/`, descending by name
   (alphabetical descend = chronological descend for timestamp-prefixed filenames).
   Filename + first `##` heading shown.

3. **Recent commits** — `git log --oneline -10` output.

4. **Heartbeat tail** — last 10 lines of `heartbeat.log`. Quick liveness check
   across all tracks, not just the current one.

5. **Footer** (uncached) — `_Briefing snapshot taken at {ISO timestamp} — re-read files if staleness matters.`

## Cache stability (FR16)

The briefing body (sections 1–4) carries `cache_control: ephemeral`. This means
the Claude API caches the body across back-to-back wakes when inputs are identical.

Rules that make the body byte-stable:
- **No timestamps** in the cached body — only in the footer (section 5), which has
  no `cache_control` and re-reads fresh each call
- **Alphabetical sort** for inbox files (never `mtime`-based)
- **Descending-name sort** for reports (deterministic for timestamp-prefixed names)

A prompt cache hit requires the briefing body to be byte-for-byte identical to the
cached version. Any change to inbox files, reports, or git history breaks the cache
for that wake — which is correct; the cache only hits when nothing has changed.

## Failure handling (FR17)

If the briefing builder raises, it:
1. Returns a stub body: `# Briefing unavailable — builder error`
2. Logs the exception to `agent/runtime/health.log`
3. Never propagates the exception — the wake proceeds with the stub

Briefing failure is a degraded-mode condition, not a fatal one. The agent can
still function; it just won't have pre-assembled context.

## Track scope

Each track sees only its own inbox. `main` additionally includes the global
`agent/inbox/from-originator/` and `agent/inbox/from-agent/` paths (legacy + per-track).
Reports are global — all tracks share `agent/reports/`. Heartbeat is global.

## When the briefing goes stale

The footer explicitly notes the snapshot time. If an agent acts for many turns
after the briefing was assembled, inbox files may have arrived, reports may have
been written, or git history may have advanced. The agent should re-read relevant
files when staleness matters — the briefing is orientation, not a live view.

## Related primitives

- [[inbox]] — the from-originator and from-agent sources the briefing reads
- [[followup]] — the self-tracking queue the briefing reads
- [[reports]] — the report files summarized in the briefing
- [[scheduling]] — heartbeat.log, which the briefing tails for liveness context
- [[wakes]] — where the briefing is injected into the wake execution flow
