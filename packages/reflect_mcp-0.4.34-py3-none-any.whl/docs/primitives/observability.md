<!-- @scry.entry
id: design.primitives-observability~cedcba05
kind: design
status: active
weight: 0.8
summary: >
  Wake observability primitive: every wake leaves a trace at six layers, each
  answering a different question at a different granularity for a different
  consumer — wake report (narrative), wakes.tsv (ledger), event stream
  (structured transitions), transcript (verbatim reasoning + tool replay),
  live stderr log, per-track runtime files (state snapshot). The transcript is
  the complete forensic record: every thinking block and every tool call.
  Also: wake logging, observability, six layers, transcript, events.jsonl,
  wakes.tsv, wake report, stderr log, status.json, audit, forensic replay.
tags: ["scope:substrate", "scope:runtime", "topic:primitives", "topic:observability", "observability", "topic:logging", "logging", "topic:wakes", "kind:design", "design"]
rationale: >
  Without this, an operator debugging or auditing a wake does not know which of
  the six trace layers to reach for, or that the transcript holds the full
  verbatim reasoning. Time is wasted grepping the wrong layer, or the richest
  layer is never consulted at all.
applies: debugging a wake, auditing what an agent did, choosing which log layer to read, replaying a wake's reasoning, building observability consumers
seeded_questions:
  - "What wake logging does reflect have?"
  - "Where is a wake's full thought process recorded?"
  - "Which log layer answers what — report vs transcript vs events?"
  - "How do I audit or replay a wake?"
  - "wake observability six layers"
@scry.entry.end -->

# Wake Observability

Every wake leaves a trace at **six layers**. Each layer answers a different
question, at a different granularity, for a different consumer. The skill is
reaching for the layer that matches the question — not grepping the wrong one.

The layers run from coarse, retrospective narrative down to verbatim,
forensic replay, plus one live layer and one state-snapshot layer.

**1. Wake report** — `agent/reports/{ts}-wake-{track}-{slug}.md`
  Granularity: narrative. Answers: what did the agent decide and do, in its
  own words?

**2. Wake ledger** — `agent/runtime/wakes.tsv`
  Granularity: one row per wake. Answers: how long, how much, how many turns?

**3. Event stream** — `agent/runtime/events.jsonl`
  Granularity: structured transitions. Answers: what state transitions
  happened, machine-readably?

**4. Transcript** — `agent/runtime/wakes/{track}/{wake_id}/transcript.jsonl`
  Granularity: verbatim. Answers: every thought and tool call — the full
  replay.

**5. Live log** — `/tmp/reflect-wake-{track}.log`
  Granularity: real-time stream. Answers: what is the wake doing right now?

**6. Runtime files** — `agent/runtime/tracks/{track}/`
  Granularity: point-in-time. Answers: what is the track's state this
  instant?

## 1. Wake report — the narrative

The agent-authored "what I did" record, one Markdown file per wake in
`agent/reports/`. Substrate-enforced: the closing summary partitions every
file the wake wrote into report vs. non-report, so a wake cannot finish
without one. This is the human-readable layer — read it first.

See [[reports]].

## 2. Wake ledger — `wakes.tsv`

One tab-separated row per completed wake:
`wake_id, track, started_at, ended_at, slept_clean, num_turns, cost_usd,
early_break_reason, transcript_path`. The structured cost-and-duration record;
`reflect wake history` reads it. Use it for "how expensive / how long / did it
sleep cleanly" across many wakes.

## 3. Event stream — `events.jsonl`

Append-only JSONL of structured state transitions — `wake.started`,
`wake.completed`, `wake.failed`, `track.running`, `track.idle`, `commit.made`,
and more. Fire-and-forget: the emitter never blocks or raises. This is the
machine-readable layer — what consumers, webhooks, and dashboards subscribe to.

See [[events]].

## 4. Transcript — the verbatim replay

`agent/runtime/wakes/{track}/{wake_id}/transcript.jsonl` is the **complete
forensic record** of a wake. Every `AssistantMessage` carries its content
blocks: `thinking` blocks (the verbatim chain-of-thought), tool-use blocks
(every call with full arguments), and text. Every `UserMessage` carries the
tool results returned. Alongside it sits `system-prompt.md` — the exact prompt
the wake ran under.

Nothing about the wake's reasoning is lost: a transcript can be replayed
thought-for-thought. This is why sub-agents are forbidden inside a wake — a
sub-agent runs its own loop whose reasoning lands in *its* transcript, not the
wake's, fragmenting the record. Keeping the wake single-context keeps the
transcript whole.

## 5. Live log — real-time stderr

While a wake runs, the supervisor streams the agent's events to stderr:
`/tmp/reflect-wake-{track}.log` for the wake itself, and
`/tmp/reflect-tick-{track}.log` for dispatcher decisions (backlog overrides,
followup migration). Tail these to watch a wake as it happens. They are
ephemeral — for the durable record, use layers 1–4.

## 6. Runtime files — the state snapshot

Per-track files under `agent/runtime/tracks/{track}/` hold the track's
current state, not its history: `status.json`, `last-wake.timestamp`,
`last-wake-start.timestamp`, `wake.lock`, `interrupt.log`. Read these to
answer "what is this track doing *now*", not "what did it do".

## Which layer do I want?

- **"What did it do and why?"** → wake report (layer 1).
- **"How much did it cost / how long?"** → `wakes.tsv` (layer 2).
- **"What happened, for a script or dashboard?"** → events (layer 3).
- **"Show me exactly how it reasoned."** → transcript (layer 4).
- **"What's it doing right now?"** → live log (layer 5).
- **"What state is the track in this instant?"** → runtime files (layer 6).

## Related primitives

- [[wakes]] — the lifecycle these layers observe
- [[events]] — layer 3 in full
- [[reports]] — layer 1 in full
- [[scheduling]] — `heartbeat.log` is a parallel, coarser liveness signal
