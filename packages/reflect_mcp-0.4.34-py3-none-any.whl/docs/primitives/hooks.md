<!-- @scry.entry
id: design.primitives-hooks~8884294f
kind: design
status: active
weight: 0.85
summary: >
  Hooks primitive: two distinct mechanisms. Permission gates (hooks.py can_use_tool) block
  forbidden bash patterns and identity-file writes. Lifecycle hooks (hooks/ dir scripts) inject
  context at UserPromptSubmit. orchestrator-status-injector.py is the primary lifecycle hook.
tags: ["scope:substrate", "topic:primitives", "topic:hooks", "topic:permissions", "topic:safety"]
rationale: >
  Without this, wakes may not understand why certain tools are blocked, how to extend the gate,
  or how lifecycle hooks work.
applies: adding permission rules, adding lifecycle hooks, understanding tool denials
seeded_questions:
  - "Why is a tool call being denied?"
  - "How do I add a new forbidden bash pattern?"
  - "What is the difference between permission gates and lifecycle hooks?"
@scry.entry.end -->

# Hooks

The reflect runtime uses two distinct hook mechanisms: **permission gates** and
**lifecycle hooks**. They share the word "hook" but solve different problems.

## Permission gates (`agent/runtime/hooks.py`)

A `can_use_tool()` function evaluated before every tool call. Returns
`PermissionResultAllow` or `PermissionResultDeny`. The SDK calls this for every
tool the agent invokes — it's the synchronous safety fence for autonomous wakes.

### What it blocks

**Bash patterns** — commands that are dangerous even within the working directory:

| Pattern | Why |
|---------|-----|
| `git push` | Affects shared remote state; pushes are the originator's call |
| `rm -rf /`, `rm -rf ~` | Destructive outside working dir |
| `sudo ` | Privilege escalation |

**Write paths** — identity files whose edit would cause runtime drift:

| Path | Why off-limits |
|------|----------------|
| `bin/reflect-wake` | Rollback shim; modifying it defeats the auto-rollback escape hatch |
| `concept.md`, `wake.md`, `agent/design/reflection.md` | Identity baseline; changes route through originator keystrokes |
| `agent/driver.yaml` | Driver bindings |

The path check matches direct hits and sandbox worktree paths (e.g.,
`agent/runtime/.sandbox-*/bin/reflect-wake`).

**Default stance:** everything else is allowed. The primary safety net is git history
(originator can `git revert`) plus per-wake token and iteration caps. The permission
gate is the narrow layer that prevents irreversible actions.

### Extending the gate

Add patterns to `_FORBIDDEN_BASH_PATTERNS` or `_FORBIDDEN_WRITE_PATHS` in
`agent/runtime/hooks.py`. The deny message surfaces in the wake transcript and
instructs the agent to surface the need in its report rather than abort silently.

## Lifecycle hooks (`agent/runtime/hooks/`)

Python scripts that fire at specific points in the wake's execution:

```
agent/runtime/hooks/
  orchestrator-status-injector.py   ← UserPromptSubmit hook
```

### orchestrator-status-injector.py

**Trigger:** `UserPromptSubmit` — fires on every user prompt in the Claude Code session.

**Purpose:** reads per-track `status.json` files, diffs against a snapshot, and injects
a concise system block only when there is news (state change, new error, progress advance,
hung track, or inbox count increase). Silent when all tracks are healthy and unchanged.

Design: `agent/design/design.orchestrator-status-channel~edc8302c.md` (DRs DR8–DR14).

Exit code is always 0 — hook failure must never block a user prompt.

### Adding a lifecycle hook

Drop a Python script in `agent/runtime/hooks/`. The hook is picked up automatically
by the Claude Code settings that reference the `hooks/` directory. Convention:
- Name it for its trigger + function (`{trigger}-{function}.py`)
- Always exit 0; log failures to stderr, don't raise
- Include a module-level docstring explaining trigger, purpose, and design doc refs

## Permission gate vs lifecycle hook — summary

| | Permission gate | Lifecycle hook |
|-|----------------|----------------|
| Location | `hooks.py` (single file) | `hooks/` (directory, one script each) |
| Trigger | Every tool call | Specific session events (UserPromptSubmit, etc.) |
| Return value | Allow / Deny | Stdout injection (or nothing) |
| Failure mode | Must decide; deny on ambiguity | Must exit 0; silent on failure |
| Purpose | Safety fencing | Context injection |

## Related primitives

- [[wakes]] — hooks fire within wake execution
- [[tracks]] — orchestrator-status-injector reads track `status.json` files
