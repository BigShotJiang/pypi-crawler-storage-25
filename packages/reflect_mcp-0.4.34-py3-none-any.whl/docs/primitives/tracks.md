<!-- @scry.entry
id: design.primitives-tracks~3ea4ec30
kind: design
status: active
weight: 0.85
summary: >
  Tracks primitive: named unit of scheduling and state. Each track has wake.md,
  wake.lock, inbox/, followup/. CLI: reflect track create/enable/disable/send.
  Dispatcher fires per-track wakes on signal (inbox, elapsed timer, backlog).
tags: ["scope:substrate", "topic:primitives", "topic:tracks"]
rationale: >
  Without this, new track contributors don't know the directory layout, lifecycle commands, or
  scheduling model. The tracks primitive is the foundational building block of the substrate.
applies: creating a new track, understanding track layout, managing track lifecycle
seeded_questions:
  - "What files does a track need?"
  - "How do I create a new track?"
  - "What is the relationship between tracks and the dispatcher?"
@scry.entry.end -->

# Tracks

A track is a named unit of scheduling and state. Each track:

- Has its own `wake.md` (identity/scope and current mission)
- Maintains an `inbox/` for incoming messages
- Has `followup/` for self-tracked work-in-progress
- Runs wakes independently via the dispatcher

## Layout

```
agent/runtime/tracks/<name>/
  wake.md
  wake.lock
  last-wake.timestamp
  last-wake-start.timestamp
  next-wake-by.timestamp
  inbox/
    *.md
    .consumed/
  followup/
    *.md
    .completed/
```

## Lifecycle

- `reflect track create <name>` — scaffold a new track
- `reflect track enable/disable <name>` — toggle scheduling
- `reflect track send <name> <message>` — queue work

## Scheduling

The dispatcher (`reflect dispatch`) fires wakes for tracks that have signal:
inbox messages, elapsed timers, or followup backlog. Designed for cron
(one entry, every minute).
