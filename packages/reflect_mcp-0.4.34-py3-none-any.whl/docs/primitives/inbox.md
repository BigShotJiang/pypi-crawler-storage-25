<!-- @scry.entry
id: design.primitives-inbox~716825ac
kind: design
status: active
weight: 0.9
summary: >
  Inbox primitive: per-track P2P message queue (Protocol P9). Message frontmatter: from/to/at/kind.
  Agent contract: move to .consumed/, write followup if work unfinished. Backlog = inbox + followup
  counts; backlog > 0 forces immediate next wake.
tags: ["scope:substrate", "topic:primitives", "topic:inbox", "topic:messaging", "topic:p9"]
rationale: >
  Without this, wakes don't know how to send messages, what frontmatter is required, or how inbox
  integrates with backlog scheduling.
applies: sending messages between tracks, routing work, understanding backlog, implementing P9
seeded_questions:
  - "What frontmatter does an inbox message require?"
  - "How do I send a message to another track?"
  - "How does inbox connect to wake scheduling?"
@scry.entry.end -->

# Inbox protocol

Every entity (track or originator) has a single `inbox/`. Communication is
peer-to-peer: sending mail = writing into the recipient's inbox.

## Message format

```yaml
---
from: trading
to: main
at: 2026-05-10T00-30-00Z
kind: report  # report | request | deploy-request | btw | broadcast | followup
subject: optional
---
```

## Agent contract

When consuming a message:
1. Move it to `inbox/.consumed/`
2. If work isn't complete, write a `followup/{timestamp}-{slug}.md`
3. When followup completes, move to `followup/.completed/`

## Backlog

```
backlog = count(inbox/*.md) + count(followup/*.md)
```

If backlog > 0 at end-of-wake, the supervisor forces immediate next wake.
