<!-- @scry.entry
id: design.primitives-followup~d713b2c2
kind: design
status: active
weight: 0.9
summary: >
  Followup primitive: per-track self-tracked WIP queue. Written when inbox message consumed but
  work is unfinished. Counts toward backlog alongside inbox, forcing immediate re-wake until closed.
  Layout: followup/{timestamp}-{slug}.md, archived to .completed/ when done.
tags: ["scope:substrate", "topic:primitives", "topic:followup", "topic:backlog", "topic:wake-discipline"]
rationale: >
  Without this, wakes treat consumed inbox as work-done and sleep on incomplete work. Followup is
  the mechanism that maintains scheduling pressure until work ships.
applies: writing followup files, closing followups, understanding backlog pressure
seeded_questions:
  - "When should I write a followup vs just consuming the inbox message?"
  - "How do I close a followup?"
  - "Why does an open followup prevent long sleep intervals?"
@scry.entry.end -->

# Followup

A **followup** is a self-tracked work-in-progress entry. A track writes a followup
when it consumes an inbox message but cannot complete the implied work within the
same wake.

## Contract

1. **Consume the inbox message** — move it to `inbox/.consumed/`.
2. **Write a followup** at `followup/{ISO-timestamp}-{slug}.md` describing
   what remains. Reference the consumed message path.
3. **Complete the followup** — when work finishes, move the followup file
   to `followup/.completed/`.

## Scheduling impact (backlog)

```
backlog = count(inbox/*.md) + count(followup/*.md)
```

If `backlog > 0` at the end of a wake, the supervisor forces an immediate
next wake (sets `next-wake-by.timestamp` to `now - 1`). This is enforced
unconditionally — the agent cannot sleep long while followups are open.

**Consequence:** an unconsumed followup is equivalent to an unread inbox
message in terms of scheduling pressure. Followups that are no longer
relevant must be moved to `.completed/` (not deleted) to drain the
backlog.

## Layout

```
agent/runtime/tracks/<name>/
  followup/
    {ISO-timestamp}-{slug}.md   # open followups (counts toward backlog)
    .completed/
      {ISO-timestamp}-{slug}.md  # finished followups (does NOT count)
```

## Frontmatter

No required frontmatter schema. Convention: reference the consumed inbox
message path in a comment at the top.

```yaml
---
consumed_from: agent/runtime/tracks/main/inbox/.consumed/2026-05-14T12-00Z-foo.md
consumed_at: 2026-05-14T12-01Z
status: open  # or: complete
---
```

## Followup vs inbox

| | inbox | followup |
|-|-------|----------|
| Written by | any sender (peer-to-peer) | the track itself |
| Consumed by | the track | the track |
| Semantics | external work request | self-tracked continuation |
| Backlog contribution | yes | yes |
| Archive path | `inbox/.consumed/` | `followup/.completed/` |

## Anti-patterns

- **Writing a followup for work you won't revisit** — followups that stay
  open indefinitely force continuous wake pressure. If work is blocked
  indefinitely (waiting on credentials, external decision), make that
  explicit in the followup body and set a realistic next-wake interval.
- **Forgetting to close completed followups** — the scheduler can't
  tell the difference between open work and finished-but-unclosed work.
  Close followups immediately when done.
- **Using followup as a todo list** — followup is a one-wake-at-a-time
  continuation primitive, not a persistent backlog. For multi-step
  project tracking, use scry tasks or an explicit design doc.

## Related primitives

- [[inbox]] — the source of work that produces followups
- [[wakes]] — the execution context in which followups are written/closed
- [[tracks]] — the directory structure that hosts followup/
