<!-- @scry.entry
id: design.primitives-events~a7d9b974
kind: design
status: active
weight: 0.85
summary: >
  Events primitive: append-only JSONL stream at agent/runtime/events.jsonl. Envelope schema v1.0
  with 13 event types covering wake lifecycle, inbox, track state, cost. Fire-and-forget
  observation — never use for coordination; use inbox for that.
tags: ["scope:substrate", "topic:primitives", "topic:events", "topic:observability"]
rationale: >
  Without this, wakes don't know how to emit events, what schema to follow, or which event types
  exist.
applies: emitting wake events, implementing event consumers, debugging wake history
seeded_questions:
  - "How do I emit a wake event?"
  - "What event types exist?"
  - "Where are events stored?"
@scry.entry.end -->

# Events

An **event** is a structured JSON record emitted by the runtime at a state transition.
Events form an append-only JSONL stream — the low-level observable heartbeat of the
reflect substrate.

Design doc: [`agent/design/events-schema.md`](../../agent/design/events-schema.md)  
Implementation: [`agent/runtime/events.py`](../../agent/runtime/events.py)

## When to use

Events are **fire-and-forget observation primitives** — they surface what the runtime
did without requiring a consumer to exist. The emitter never blocks or raises; event
failure must not break a wake. Consumers (CLI, webhooks, dashboard) are optional.

Do NOT use events as a coordination mechanism. Cross-track coordination uses
[[inbox]]; self-tracked work uses [[followup]].

## Storage layout

```
agent/runtime/
  events.jsonl              ← always today's file (symlink or write-target)
  events/
    2026-05-10.jsonl        ← daily rotation
    2026-05-11.jsonl
    ...
    2026-05-10.jsonl.gz     ← compressed after 90 days (configurable)
```

Mode 600 (owner read/write only). Events may contain paths, cost data, commit snippets.

## Envelope schema (v1.0)

Every event shares this envelope; `payload` varies by type.

```json
{
  "id": "evt_1747000000123_a1b2c3d4",
  "type": "wake.completed",
  "at": "2026-05-10T07:30:00.123Z",
  "track": "toilet-worker",
  "wake_id": "2026-05-10T07-25-00Z",
  "event_schema_version": "1.0",
  "payload": { "duration_seconds": 312, "cost_usd": 0.14, ... }
}
```

- **`id`**: `evt_{timestamp_ms}_{random_hex8}` — sortable, unique, no external dependency.
- **`at`**: ISO-8601 UTC, millisecond precision.
- **`event_schema_version`**: `"1.0"`. Adding optional fields is non-breaking. Removing
  or renaming a field bumps the version. Consumers must ignore unknown fields.

## Event types (v1.0)

| Type | When |
|------|------|
| `wake.started` | Wake fires |
| `wake.completed` | Wake exits cleanly (sleep called) |
| `wake.failed` | Wake exits non-zero or without sleep |
| `wake.scheduled` | Wake schedules its next firing |
| `commit.made` | Wake creates a git commit |
| `tool.called` | Agent invokes a tool (debug; opt-in) |
| `inbox.delivered` | Message lands in any track's inbox |
| `inbox.consumed` | Track consumes an inbox message |
| `track.idle` | Track transitions to idle |
| `track.running` | Track transitions to running |
| `track.wedged` | Protocol-violation detected |
| `originator.requested` | Agent files a from-agent blocker |
| `cost.threshold` | Wake cost crosses a threshold |

## Emitting events

```python
from agent.runtime.events import emit_event

emit_event("wake.started", track="main", wake_id=wake_id, payload={
    "pid": os.getpid(),
    "kickoff_source": "scheduled",
})
```

The function always returns the event `id` so callers can cross-reference follow-up
events (e.g., `wake.completed` can reference the `wake.started` id).

## Consumer interfaces (phased)

| Phase | Interface | Status |
|-------|-----------|--------|
| 1 | `emit_event()` emission from wake.py | Implemented |
| 2 | `reflect events tail/since/list` CLI | Planned |
| 3 | Webhook delivery with HMAC-SHA256 | Planned |
| 4 | `reflect_events_subscribe()` MCP tool | Planned |

## Related primitives

- [[wakes]] — the lifecycle events describe
- [[scheduling]] — heartbeat.log is a parallel, coarser liveness signal
- [[tracks]] — `track.running` / `track.idle` / `track.wedged` events map to track state
