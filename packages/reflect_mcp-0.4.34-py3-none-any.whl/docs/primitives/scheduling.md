<!-- @scry.entry
id: design.primitives-scheduling~a3f9b1e3
kind: design
status: active
weight: 0.9
summary: >
  Scheduling primitives: three file-as-primitive signals control when tracks wake.
  next-wake-by.timestamp (epoch; dispatcher fires when elapsed), wake.lock (fcntl exclusive;
  prevents concurrent wakes), heartbeat.log (append-only liveness). Backlog override forces
  immediate re-wake when inbox+followup > 0.
tags: ["scope:substrate", "topic:primitives", "topic:scheduling", "topic:dispatcher"]
rationale: >
  Without this, wakes don't understand why a track fired when it did, how to control wake
  intervals, or how the backlog override works.
applies: controlling wake intervals, debugging scheduling, understanding backlog override
seeded_questions:
  - "How does a wake schedule its next firing?"
  - "What is the backlog override and when does it fire?"
  - "How does wake.lock prevent concurrent wakes?"
@scry.entry.end -->

# Scheduling primitives

Three file-as-primitive signals control when tracks wake. Together with the
dispatcher and `wake.lock`, they form the scheduling substrate.

## next-wake-by.timestamp

**Path:** `agent/runtime/tracks/<name>/next-wake-by.timestamp`  
**Contents:** Unix epoch as a decimal string (e.g. `1747266000.123456`)

The dispatcher reads this file on each tick. If `now >= value`, the track is
eligible to wake. Three writers:

| Writer | When | Value written |
|--------|------|---------------|
| `sleep` tool | end of every wake | `now + next_wake_in_seconds` |
| supervisor (backlog override) | backlog > 0 at wake exit | `now - 1` (forces immediate) |
| `reflect wake start` | manual fire | `now - 1` |

The backlog override is unconditional — it fires even if the agent passed a
long sleep interval. The only way to earn a long sleep is to drain backlog.

## wake.lock

**Path:** `agent/runtime/tracks/<name>/wake.lock`  
**Mechanism:** `fcntl` exclusive lock (`LOCK_EX | LOCK_NB`)

Prevents concurrent wakes for the same track. The dispatcher acquires the
lock before booting any wake process; the lock is released when the process
exits (naturally or by signal). If the lock is held, the dispatcher skips
that track until the next tick.

**Stale lock detection:** if `wake.lock` exists but no process holds it
(e.g. after a crash without cleanup), the lock is a normal file — the next
`LOCK_NB` attempt will succeed. No manual cleanup needed.

## heartbeat.log

**Path:** `agent/drivers/@local/scry/runtime/heartbeat.log`  
**Format:** tab-separated, one line per wake:

```
{ISO-timestamp}\t{slug}\t1\t{report_path}
```

Append-only liveness log. Every wake appends one line after writing its
report. Three consumers:

| Consumer | Use |
|----------|-----|
| `reflect-dispatch` | reads last entry — if no heartbeat in configurable window, flags track as stale |
| `reflect doctor` | surfaces missing/stale heartbeats in health check |
| wake briefing | provides orientation context for the new wake (last N lines) |

**Driver path note:** the `@local/scry/runtime/` path reflects the driver
namespace convention. The heartbeat protocol is a reflect primitive; its
storage location is driver-pluggable in principle, though only `@local/` is
implemented.

## Backlog signal (derived)

```
backlog = count(inbox/*.md) + count(followup/*.md)
```

Not a file itself — computed by the supervisor at wake exit from live
directory counts. If `backlog > 0`, the supervisor writes
`next-wake-by.timestamp = now - 1` regardless of what the agent's `sleep`
call requested.

## Dispatcher

The single cron entry that ties the signals together:

```
* * * * * reflect-dispatch   # fires every 60s
```

`reflect-dispatch` iterates all non-decommissioned tracks and, per track:
1. Reads `next-wake-by.timestamp` — skip if not elapsed
2. Tries `LOCK_EX | LOCK_NB` on `wake.lock` — skip if held
3. Fires `reflect-wake <track>` subprocess

One cron entry, forever. Adding tracks doesn't require crontab edits.

## Scheduling summary

```
Every 60s tick:
  for each track:
    if next-wake-by.timestamp elapsed → eligible
    if wake.lock acquirable → fire wake

At wake exit (supervisor):
  if backlog > 0 → set next-wake-by = now - 1
  else → respect sleep tool's next_wake_in_seconds
```

## Related primitives

- [[wakes]] — wake anatomy; the thing being scheduled
- [[followup]] — contributes to backlog; open followups force immediate wake
- [[inbox]] — contributes to backlog; unread messages force immediate wake
- [[tracks]] — the directory structure hosting these signal files
