# Driver

A **driver** is a pluggable backend for reflect's core storage and memory
operations. The driver mechanism lets external MCP servers handle marker minting
and querying instead of the substrate's built-in defaults.

## Why drivers exist

Reflect's core loop depends on two primitive operations:
- **marker.mint** — generate a collision-free ID for a new knowledge artifact
- **query.run** — search the knowledge graph for prior state

The substrate ships defaults (grep-based, filesystem-backed), but they're weak:
no full-text indexing, no cross-session memory, no semantic query. Drivers let
you wire a better backend without modifying the substrate.

The `@local/scry/` driver is the only implementation today. It replaces the
defaults with scry's SQLite-backed knowledge graph, enabling `scry_sql` queries
and `scry_mint` IDs across all wakes.

## agent/driver.yaml

The project-level binding file. Lives at `agent/driver.yaml` relative to the
project root.

```yaml
driver: "@prmichaelsen/scry"   # which driver package
capabilities:
  watcher: true                # driver runs a file watcher (no polling needed)
bindings:
  marker.mint: scry_mint       # MCP tool that handles mint operations
  query.run: scry_sql          # MCP tool that handles query operations
```

**`driver`** — identifies the driver by package/scope name. Informational; not
used for dispatch at runtime.

**`capabilities.watcher`** — when `true`, the driver maintains a live file watcher
that indexes markers as files are written. The substrate skips polling intervals
and expects the driver's DB to be current.

**`bindings`** — maps ext-point names to MCP tool names. Two ext points:

| Ext point | Role | Default (no driver) |
|-----------|------|---------------------|
| `marker.mint` | Generate a new, collision-free marker ID | Internal ID generation |
| `query.run` | Query the knowledge graph | grep/awk over files |

## Driver namespace convention

Drivers live under `agent/drivers/` with a scoped path:

```
agent/drivers/@local/scry/     ← the @local/scry driver
```

The `@<scope>/<name>/` pattern mirrors npm's scoped-package convention.
`@local` means "this project's local driver instance." Named scopes (e.g.
`@prmichaelsen/`) are reserved for shared/published drivers.

Contents of `@local/scry/`:
```
agent/drivers/@local/scry/
  runtime/          ← driver runtime state (heartbeat.log, etc.)
  scripts/          ← scry_script atoms (worktree_create, etc.)
```

The driver directory is the substrate's "driver workspace" — state that belongs
to the driver runtime lives here, not in the reflect tree.

## How dispatch works

When `agent/driver.yaml` is present, ACP commands and substrate internals route
ext-point calls through the bound MCP tool:

```
marker.mint request
  → check agent/driver.yaml
  → binding: marker.mint = scry_mint
  → call scry_mint via MCP
  → return minted ID to caller

query.run request
  → check agent/driver.yaml
  → binding: query.run = scry_sql
  → call scry_sql with the query
  → return results to caller
```

Without `agent/driver.yaml`, the substrate falls back to built-in defaults. The
fallback is transparent to callers — same interface, weaker implementation.

## Constraints

- One driver per project. `agent/driver.yaml` defines a single driver; there is
  no multi-driver composition.
- Both `marker.mint` and `query.run` bindings must point to the **same** MCP
  server. Splitting them across servers is not supported.
- The bound MCP server must be reachable in the agent's tool environment. If the
  server is down, ext-point calls fail and the substrate does not automatically
  fall back.

## Limitations (current)

- Only `@local/scry/` is implemented. No published driver packages exist.
- `driver.yaml` itself is off-limits to agent edits (permission gate). Changes
  to driver configuration route through the originator.
- No per-track driver override — one project, one driver.

## Related primitives

- [[hooks]] — permission gate blocks agent writes to `agent/driver.yaml`
- [[wakes]] — wakes call ext-points; drivers are transparent to the agent's tool use
- [[state]] — scry is the storage strategy the driver enables
