<!-- @scry.entry
id: design.primitives-wakes~05194c68
kind: design
status: active
weight: 0.9
summary: >
  Wakes primitive: one execution of the agent loop (wake to briefing to work to report to heartbeat to sleep).
  Auto-rollback via smoke-test and reflect/last-known-good. Budget: turn count + USD caps.
  Sleep tool call schedules next wake atomically.
tags: ["scope:substrate", "topic:primitives", "topic:wakes", "topic:agent-loop"]
rationale: >
  Without this, wakes don't know their own anatomy, how the auto-rollback works, or how sleep
  schedules the next wake. The wakes primitive is the highest-level primitive.
applies: implementing wake lifecycle changes, debugging failed wakes, understanding the agent loop
seeded_questions:
  - "What is the anatomy of a wake?"
  - "How does the auto-rollback work?"
  - "How do I schedule the next wake from within a wake?"
@scry.entry.end -->

# Wakes

A **wake** is one execution of the agent loop: wake → read prior state → act →
write back → sleep.

## Anatomy of a wake

See `docs/runtime-views.md` (View 1) for the full single-wake lifecycle
sequence — boot through post-wake cleanup. For the compact phase
skeleton with the key inbox-sweep callout (the phase that auto-creates
followups before agent reasoning starts), see `docs/wake-lifecycle.md`.

## Wake scheduling

- `next-wake-by.timestamp`: unix epoch; dispatcher fires when elapsed
- Backlog override: if `pending_inbox + pending_followup > 0` at wake end,
  supervisor sets `next-wake-by` to `now - 1` (immediate on next tick)
- Dispatcher tick: cron fires `reflect-dispatch` every 60s

## Wake control

```bash
reflect wake list                 # running wakes
reflect wake start <track>        # manual fire
reflect wake stop <track>         # graceful shutdown
reflect wake history [<track>]    # past wakes from wakes.tsv
```

## Auto-rollback

`bin/reflect-wake` smoke-tests `from agent.runtime.wake import main` before
booting. If the import fails, it rolls back `agent/runtime/` to the
`reflect/last-known-good` git ref and retries. Safety net for self-modification.

## Budget

Each wake has a token budget and iteration count cap. The `budget` tool reports
usage mid-wake. If approaching limits, sleep early.
