<!-- @scry.entry
id: design.primitives-project-linking~ea0eabfc
kind: design
status: active
weight: 0.85
summary: >
  Project linking primitive (Protocol P10): reflect project link creates symlink at
  agent/projects/<name> pointing to standalone repo with mutual-exclusion orchestrator marker.
  Tracks must never write directly into reflection's projects/ directory.
tags: ["scope:substrate", "topic:primitives", "topic:project-linking", "topic:p10"]
rationale: >
  Without this, tracks may write project files into reflection's git tree instead of the standalone
  repo, creating wrong git history. Mutual-exclusion marker prevents two orchestrators from
  concurrently writing the same project.
applies: linking a new project, understanding reflect project list, debugging project access
seeded_questions:
  - "How do I link a project to reflection?"
  - "Why can't I write directly to agent/projects/?"
  - "What does reflect project list show?"
  - "What is the orchestrator marker?"
@scry.entry.end -->

# Primitive: project linking

## What it is

Project linking is how a reflection orchestrator gains access to a standalone
project repo. Linked projects appear at `agent/projects/<name>` and are
accessible to all tracks in the orchestrator. Linking does three things:
creates a symlink, writes a mutual-exclusion marker in the project, and syncs
Claude settings so the project directory is included in Claude Code's file
access.

## Why a separate primitive

Projects are standalone repos at `~/.acp/projects/<name>/`. They are NOT
subdirectories of reflection. Directly writing project files into reflection's
tree would commit them to reflection's git history, which is wrong — each
project has its own git history. The link is the seam that keeps them separate.

## Operations

### Link

```bash
reflect project link ~/.acp/projects/bark
```

What happens:
1. Creates symlink at `agent/projects/bark` → `~/.acp/projects/bark`
2. Writes orchestrator marker at `~/.acp/projects/bark/agent/runtime/orchestrators/<hash>.path`
   containing reflection's project root path. The hash is a 12-char SHA-256 of
   the reflection root — unique per orchestrator instance.
3. Validates the project isn't already linked by another orchestrator (mutual exclusion).

### List / audit

```bash
reflect project list
```

Returns all entries under `agent/projects/`, showing each entry's status:
- `ok / linked` — symlink pointing to a live directory
- `ok / nested` — real directory with its own `agent/` subtree (first-class peer)
- `dead` — symlink pointing to a directory that no longer exists
- `not-symlink` — real directory without an `agent/` subtree (drift; fix manually)

Any `not-symlink` or `dead` entry is drift; fix immediately.

### Unlink

```bash
reflect project unlink bark
```

Removes the symlink and the orchestrator marker from the project directory.

## Symlink convention

- Symlink path: `agent/projects/<name>` (relative to reflection root)
- Target: the absolute standalone repo path
- Tracks access the project via the linked path

Tracks **must never write files directly inside reflection's `projects/` directory** except
through the symlink. The symlink redirects writes to the standalone repo's real filesystem
location.

## Orchestrator marker

The marker file at `<project>/agent/runtime/orchestrators/<hash>.path` contains
the path of the reflection orchestrator that linked it. This is the
mutual-exclusion mechanism: before linking a project, `link_project()` reads
all `.path` files in the project's `orchestrators/` directory and rejects the
link if any other orchestrator has a valid back-reference.

This prevents two orchestrators from concurrently writing to the same project
directory, which would cause git history confusion and state corruption.

## Nested projects

A project that physically resides at `agent/projects/<name>/` as a real
directory (not a symlink) is called a nested project. `reflect project link`
detects this case and registers it without creating a symlink — it just writes
the orchestrator marker. `reflect project list` shows it as `ok / nested`.

Nested projects are appropriate when the project was initialized directly inside
reflection's tree. Linked projects (symlinks) are appropriate for projects at
`~/.acp/projects/<name>/` that have their own git history.

## Protocol P10

This primitive is the implementation of Protocol P10 (Project Location Protocol)
defined in `protocol.md`:

> Reflection-managed projects live as standalone repos at
> `~/.acp/projects/<name>/` and are linked into reflection via
> `reflect project link <path>`, which creates a symlink at
> `agent/projects/<name>` pointing to the standalone repo.

## Related primitives

- **tracks** — tracks access linked projects via the symlink path
- **scheduling** — per-project tracks (e.g. `bark-worker`) run as normal tracks;
  linking is a prerequisite for those tracks to reach their project files
