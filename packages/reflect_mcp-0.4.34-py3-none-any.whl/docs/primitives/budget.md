<!-- @scry.entry
id: design.primitives-budget~969f120d
kind: design
status: active
weight: 0.85
summary: >
  Budget primitive: per-wake turn count and USD cost caps enforced by the Claude Agent SDK.
  Default caps: 50 turns / $3.00. The budget tool returns mid-wake usage. Conflict-resolution
  wakes use reduced caps via wake_override.yaml.
tags: ["scope:substrate", "topic:primitives", "topic:budget", "topic:cost"]
rationale: >
  Without this, wakes don't know how budget caps are set, how to read mid-wake usage, or how
  conflict-resolution wakes get reduced caps. Misunderstanding budget causes premature aborts or
  unchecked cost overruns.
applies: managing wake cost, implementing conflict-resolution wakes, calling the budget tool
seeded_questions:
  - "What are the default wake budget caps?"
  - "How do I check remaining budget mid-wake?"
  - "What happens when a wake exceeds its budget?"
  - "How does conflict-resolution get a reduced budget?"
@scry.entry.end -->

# Budget

Every wake runs under two caps — **turn count** and **USD cost** — enforced by the
Claude Agent SDK. The `budget` primitive gives agents a mid-wake view of how much
they've consumed versus how much remains.

## Default caps

| Cap | Default | Conflict-resolution override |
|-----|---------|------------------------------|
| `max_turns` | 50 | 25 |
| `max_budget_usd` | $3.00 | $1.50 |

Defaults are defined in `agent/runtime/wake.py` as `MAX_TURNS` and `MAX_BUDGET_USD`.
Conflict-resolution wakes write a `wake_override.yaml` to the track directory before
sleeping; the next wake reads and deletes it before booting.

## The `budget` tool

Agents call `mcp__reflect-wake__budget` to inspect remaining capacity:

```
budget() → { turns_used, turns_max, cost_used_usd, cost_max_usd }
```

The tool reads from a shared in-process state object updated after every model call.
Each call costs one turn, so use it sparingly — at the start of ambitious work, or
when you sense the wake is running long.

**Typical uses:**
- Before starting a large write: "do I have headroom for this?"
- Partway through a multi-step task: "should I wrap up or continue?"
- After a surprising number of tool calls: "how much have I spent?"

## Turn tracking

`increment_turn()` is called after every `AssistantMessage` in the wake loop.
One `AssistantMessage` = one model call = one turn. Tool calls within a single
assistant turn do not add to the turn count.

The SDK enforces `max_turns` as a hard cap. When turns are exhausted, the wake exits
without calling the sleep tool (early_break_reason = "budget"). This is recorded
in the events log and health state as an unhealthy exit.

## Cost tracking

`cost_usd` accumulates `usage.input_tokens * INPUT_TOKEN_PRICE + usage.output_tokens * OUTPUT_TOKEN_PRICE`
across all assistant turns. The SDK also enforces `max_budget_usd` as a hard cap.

## Wake override (conflict-resolution)

When a wake encounters a worktree promotion conflict, it:
1. Writes `tracks/<track>/wake_override.yaml` with reduced caps
2. Fires an immediate next wake
3. The next wake reads + deletes the override before SDK init

This keeps conflict-resolution wakes narrowly scoped and cheap.

## Related primitives

- [[wakes]] — where caps are initialized and enforced
- [[hooks]] — budget tool is an allowed tool in `wake.py`'s `allowed_tools` list
- [[scheduling]] — unhealthy exits (budget exceeded) are recorded to health state
