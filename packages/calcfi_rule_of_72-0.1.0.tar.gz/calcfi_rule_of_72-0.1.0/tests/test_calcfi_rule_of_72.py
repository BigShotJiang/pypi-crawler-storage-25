from calcfi_rule_of_72 import rule_of_72, exact_doubling_time

def test_8pct():
    assert rule_of_72(8) == 9.0

def test_exact_8pct():
    assert abs(exact_doubling_time(8) - 9.006) < 0.01

def test_4pct():
    assert rule_of_72(4) == 18.0
