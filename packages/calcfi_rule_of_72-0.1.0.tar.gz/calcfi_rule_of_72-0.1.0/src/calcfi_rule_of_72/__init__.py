"""Public API for calcfi-rule-of-72."""
from .core import *  # noqa: F401,F403
