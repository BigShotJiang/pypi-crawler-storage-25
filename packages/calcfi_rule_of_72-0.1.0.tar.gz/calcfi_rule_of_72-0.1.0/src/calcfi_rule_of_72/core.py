"""calcfi-rule-of-72 — Doubling-time approximation and exact formula.

Rule of 72: years_to_double = 72 / rate%
Exact: years = ln(2) / ln(1 + r)

License: MIT. Author: Jere Salmisto. https://calcfi.app
"""
import math
from typing import Union

__version__ = "0.1.0"
Number = Union[int, float]

def rule_of_72(annual_rate_pct: Number) -> float:
    """Approximate years to double using Rule of 72.

    Args:
        annual_rate_pct: Annual return as percentage (e.g., 8 for 8%).

    Returns:
        Approximate years to double.

    Examples:
        >>> rule_of_72(8)
        9.0
        >>> rule_of_72(6)
        12.0
    """
    if annual_rate_pct <= 0:
        raise ValueError("annual_rate_pct must be positive")
    return 72.0 / float(annual_rate_pct)

def exact_doubling_time(annual_rate_pct: Number) -> float:
    """Exact doubling time using natural-log formula."""
    if annual_rate_pct <= 0:
        raise ValueError("annual_rate_pct must be positive")
    r = annual_rate_pct / 100.0
    return math.log(2) / math.log(1 + r)

def approximation_error(annual_rate_pct: Number) -> float:
    """Error in years between Rule of 72 and exact formula."""
    return rule_of_72(annual_rate_pct) - exact_doubling_time(annual_rate_pct)
