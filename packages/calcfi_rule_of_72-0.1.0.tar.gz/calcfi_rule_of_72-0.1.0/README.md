# calcfi-rule-of-72

> Rule of 72 — approximate years to double an investment at a given rate. Plus exact ln(2) version. MIT.

**CalcFi Rule of 72 Calculator** — a single-purpose, MIT-licensed helper for Compute years to double an investment using the classic Rule of 72 approximation (years = 72 / rate%) plus the exact natural-log formula. Useful for quick mental math on compound returns.

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![ORCID](https://img.shields.io/badge/ORCID-0009--0000--0916--8684-A6CE39)](https://orcid.org/0009-0000-0916-8684)
[![CalcFi](https://img.shields.io/badge/calcfi.app-Live%20Calculator-blue)](https://calcfi.app/calculators/rule-of-72)

## What this does

Compute years to double an investment using the classic Rule of 72 approximation (years = 72 / rate%) plus the exact natural-log formula. Useful for quick mental math on compound returns.

**Formula** — Approximate doubling time:

```
years = 72 / rate%   (approximation)   |   years = ln(2) / ln(1+r)   (exact)
```

**Primary source**: [Standard textbook (originally attributed to Luca Pacioli, 1494)](https://en.wikipedia.org/wiki/Rule_of_72)

## Install

```bash
pip install calcfi-rule-of-72
```

## Usage

```python
from calcfi_rule_of_72 import rule_of_72, exact_doubling_time

# At 8% return, years to double
rule_of_72(8)   # 9.0 (approximation)
exact_doubling_time(8)  # 9.006 (exact)
```

## Live calculator

Try the interactive web calculator with full UI at **[https://calcfi.app/calculators/rule-of-72](https://calcfi.app/calculators/rule-of-72)** — no signup required.

## Why this package exists

Most personal-finance calculators are buried in advertising-heavy lead-generation sites. The math is freely published by federal agencies and textbooks, but the implementations are wrapped in proprietary opaque code. **[CalcFi](https://calcfi.app)** publishes these utility libraries to make every formula:

1. **Reproducible** — show the math
2. **Cited** — link to primary sources
3. **Free** — MIT license, no paid tier
4. **Auditable** — every line of code is open source

The math here is undergraduate-level. The contribution is the citation discipline and the open distribution.


## Part of the CalcFi ecosystem

This package is one of 8 single-purpose helper utilities. Cross-mesh:

### Sibling Python packages

- [calcfi-mortgage-payment](https://pypi.org/project/calcfi-mortgage-payment/) — Standard amortizing-loan monthly payment formula. Free, cited, MIT.
- [calcfi-compound-interest](https://pypi.org/project/calcfi-compound-interest/) — Compound interest with periodic contributions. Future value, present value, time-to-target. Free, MIT.
- [calcfi-apr-apy](https://pypi.org/project/calcfi-apr-apy/) — Convert between APR (simple annual rate) and APY (effective annual yield including compounding). MIT.
- [calcfi-real-return](https://pypi.org/project/calcfi-real-return/) — Inflation-adjusted (real) return from nominal return. Formula: real = (1+nominal)/(1+inflation) − 1. MIT.
- [calcfi-amortization](https://pypi.org/project/calcfi-amortization/) — Generate a full amortization schedule for a fixed-rate loan: payment, principal, interest, balance per period. MIT.
- [calcfi-tax-bracket](https://pypi.org/project/calcfi-tax-bracket/) — US federal income tax bracket math — marginal rate, effective rate, total tax owed. 2024-2026 brackets per IRS Rev. Proc. MIT.
- [calcfi-debt-payoff](https://pypi.org/project/calcfi-debt-payoff/) — Snowball vs avalanche debt payoff strategies. Compute months and total interest. MIT.

### Sibling npm packages

- [calcfi-mortgage-payment](https://www.npmjs.com/package/calcfi-mortgage-payment) — Standard amortizing-loan monthly payment formula. Free, cited, MIT.
- [calcfi-compound-interest](https://www.npmjs.com/package/calcfi-compound-interest) — Compound interest with periodic contributions. Future value, present value, time-to-target. Free, MIT.
- [calcfi-apr-apy](https://www.npmjs.com/package/calcfi-apr-apy) — Convert between APR (simple annual rate) and APY (effective annual yield including compounding). MIT.
- [calcfi-real-return](https://www.npmjs.com/package/calcfi-real-return) — Inflation-adjusted (real) return from nominal return. Formula: real = (1+nominal)/(1+inflation) − 1. MIT.
- [calcfi-amortization](https://www.npmjs.com/package/calcfi-amortization) — Generate a full amortization schedule for a fixed-rate loan: payment, principal, interest, balance per period. MIT.
- [calcfi-tax-bracket](https://www.npmjs.com/package/calcfi-tax-bracket) — US federal income tax bracket math — marginal rate, effective rate, total tax owed. 2024-2026 brackets per IRS Rev. Proc. MIT.
- [calcfi-debt-payoff](https://www.npmjs.com/package/calcfi-debt-payoff) — Snowball vs avalanche debt payoff strategies. Compute months and total interest. MIT.

### Companion data

The mortgage rate, inflation, Treasury yield, and macro data used to validate
these calculators are published as **[CalcFi Open Data](https://calcfi-open-data-4a2bc1.gitlab.io/)** —
34 free CC BY 4.0 time series, 117,956 observations, 5 permanent DOIs.

- [CalcFi Open Data on Hugging Face](https://huggingface.co/datasets/iizy/calcfi-open-data)
- [Python `calcfidata` SDK](https://pypi.org/project/calcfidata/)
- [npm `calcfidata` SDK](https://www.npmjs.com/package/calcfidata)
- [Live SQL endpoint (Datasette)](https://calcfi-open-data.vercel.app/)
- [DOI 10.6084/m9.figshare.32332290](https://doi.org/10.6084/m9.figshare.32332290)

### Calculators on CalcFi (free, no signup)

Every formula in these packages has a live web calculator at [calcfi.app](https://calcfi.app):

- [Mortgage Payment](https://calcfi.app/calculators/mortgage-payment)
- [Compound Interest](https://calcfi.app/calculators/compound-interest)
- [Tax Bracket](https://calcfi.app/calculators/tax-bracket)
- [Amortization Schedule](https://calcfi.app/calculators/mortgage-amortization)
- [APR vs APY](https://calcfi.app/calculators/apr-vs-apy)
- [Rule of 72](https://calcfi.app/calculators/rule-of-72)
- [Inflation-Adjusted Return](https://calcfi.app/calculators/inflation-adjusted-return)
- [Debt Payoff](https://calcfi.app/calculators/debt-payoff)


## License

MIT. Author: **Jere Salmisto** ([ORCID 0009-0000-0916-8684](https://orcid.org/0009-0000-0916-8684)), founder of [CalcFi](https://calcfi.app). Based in Helsinki, Finland.

## Citation

If you cite this package in research:

```
Salmisto, J. (2026). calcfi-rule-of-72: CalcFi Rule of 72 Calculator.
DOI: 10.6084/m9.figshare.32332290 (parent CalcFi Open Data dataset).
Available: https://calcfi.app/calculators/rule-of-72
```

Or use the [CITATION.cff](https://calcfi-open-data-4a2bc1.gitlab.io/) on the parent dataset for the BibTeX entry.
