"""AppKit MCP Image component."""
