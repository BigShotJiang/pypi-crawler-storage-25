import os

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.core.management.base import CommandError

from forward_netbox.choices import forward_configured_models
from forward_netbox.choices import FORWARD_OPTIONAL_MODELS
from forward_netbox.choices import ForwardExecutionBackendChoices
from forward_netbox.choices import ForwardSourceDeploymentChoices
from forward_netbox.choices import ForwardSyncStatusChoices
from forward_netbox.models import ForwardSource
from forward_netbox.models import ForwardSync
from forward_netbox.utilities.branch_budget import DEFAULT_MAX_CHANGES_PER_BRANCH
from forward_netbox.utilities.multi_branch import ForwardMultiBranchExecutor
from forward_netbox.utilities.query_fetch import ForwardQueryFetcher


class Command(BaseCommand):
    help = "Run a live Forward smoke sync using local environment variables."

    def add_arguments(self, parser):
        parser.add_argument(
            "--source-name",
            default=os.getenv("FORWARD_SMOKE_SOURCE_NAME", "smoke-source"),
        )
        parser.add_argument(
            "--sync-name",
            default=os.getenv("FORWARD_SMOKE_SYNC_NAME", "smoke-sync"),
        )
        parser.add_argument(
            "--url",
            default=os.getenv("FORWARD_SMOKE_URL", "https://fwd.app"),
        )
        parser.add_argument(
            "--username",
            default=os.getenv("FORWARD_SMOKE_USERNAME"),
        )
        parser.add_argument(
            "--password",
            default=os.getenv("FORWARD_SMOKE_PASSWORD"),
        )
        parser.add_argument(
            "--network-id",
            default=os.getenv("FORWARD_SMOKE_NETWORK_ID"),
        )
        parser.add_argument(
            "--snapshot-id",
            default=os.getenv("FORWARD_SMOKE_SNAPSHOT_ID", "latestProcessed"),
        )
        parser.add_argument(
            "--models",
            default=os.getenv("FORWARD_SMOKE_MODELS", ""),
            help="Comma-separated NetBox models to enable. Defaults to the required supported models.",
        )
        parser.add_argument(
            "--validate-only",
            action="store_true",
            help="Validate snapshot resolution and built-in/custom query execution without running an ingestion.",
        )
        parser.add_argument(
            "--query-limit",
            type=int,
            default=int(os.getenv("FORWARD_SMOKE_QUERY_LIMIT", "5")),
            help="Maximum rows to fetch per query during --validate-only. Defaults to 5.",
        )
        parser.add_argument(
            "--plan-only",
            action="store_true",
            help="Print the native Branching shard plan without creating branches or applying changes.",
        )
        parser.add_argument(
            "--no-auto-merge",
            action="store_true",
            help="Stage one native Branching shard and pause for manual review/merge.",
        )
        parser.add_argument(
            "--execution-backend",
            choices=[
                ForwardExecutionBackendChoices.BRANCHING,
                ForwardExecutionBackendChoices.FAST_BOOTSTRAP,
            ],
            default=os.getenv(
                "FORWARD_SMOKE_EXECUTION_BACKEND",
                ForwardExecutionBackendChoices.BRANCHING,
            ),
            help="Sync execution backend to use for the smoke run.",
        )
        parser.add_argument(
            "--max-changes-per-branch",
            type=int,
            default=int(
                os.getenv(
                    "FORWARD_SMOKE_MAX_CHANGES_PER_BRANCH",
                    str(DEFAULT_MAX_CHANGES_PER_BRANCH),
                )
            ),
            help="Maximum estimated changes per native Branching shard.",
        )

    def handle(self, *args, **options):
        username = options["username"]
        password = options["password"]
        network_id = options["network_id"]
        if not username:
            raise CommandError("Set --username or FORWARD_SMOKE_USERNAME.")
        if not password:
            raise CommandError("Set --password or FORWARD_SMOKE_PASSWORD.")
        if not network_id:
            raise CommandError("Set --network-id or FORWARD_SMOKE_NETWORK_ID.")
        if options["query_limit"] < 1:
            raise CommandError("--query-limit must be at least 1.")
        if options["max_changes_per_branch"] < 1:
            raise CommandError("--max-changes-per-branch must be at least 1.")
        if options["validate_only"] and options["plan_only"]:
            raise CommandError("--validate-only and --plan-only cannot be combined.")
        if (
            options["plan_only"]
            and options["execution_backend"]
            == ForwardExecutionBackendChoices.FAST_BOOTSTRAP
        ):
            raise CommandError(
                "--plan-only is only supported for the Branching backend."
            )
        user_model = get_user_model()
        user = user_model.objects.filter(is_superuser=True).order_by("pk").first()
        if user is None:
            raise CommandError(
                "Create a NetBox superuser before running the smoke sync."
            )

        url = options["url"].rstrip("/")
        source_type = (
            ForwardSourceDeploymentChoices.SAAS
            if url == "https://fwd.app"
            else ForwardSourceDeploymentChoices.CUSTOM
        )

        selected_models = self._selected_models(options["models"])

        source = self._build_source(
            source_name=options["source_name"],
            source_type=source_type,
            url=url,
            username=username,
            password=password,
            network_id=network_id,
        )
        source.validate_connection()

        sync = self._build_sync(
            sync_name=options["sync_name"],
            source=source,
            user=user,
            snapshot_id=options["snapshot_id"],
            selected_models=selected_models,
            auto_merge=not options["no_auto_merge"],
            execution_backend=options["execution_backend"],
        )

        if options["validate_only"]:
            self._run_validation_only(sync, query_limit=options["query_limit"])
            return

        if options["plan_only"]:
            self._run_plan_only(
                sync,
                max_changes_per_branch=options["max_changes_per_branch"],
            )
            return

        self.stdout.write(
            self.style.NOTICE(
                f"Running smoke sync '{sync.name}' against source '{source.name}'"
            )
        )
        sync.sync(max_changes_per_branch=options["max_changes_per_branch"])
        sync.refresh_from_db()
        ingestion = sync.last_ingestion
        if ingestion is None:
            raise CommandError("Smoke sync finished without creating an ingestion.")

        self.stdout.write(
            f"Sync status: {sync.status}, snapshot: {ingestion.snapshot_id}, issues: {ingestion.issues.count()}"
        )
        self.stdout.write(f"Ingestion URL: {ingestion.get_absolute_url()}")

        if sync.status not in (
            ForwardSyncStatusChoices.READY_TO_MERGE,
            ForwardSyncStatusChoices.COMPLETED,
        ):
            raise CommandError(f"Smoke sync did not finish cleanly: {sync.status}")

        issue_count = ingestion.issues.count()
        if issue_count:
            messages = list(ingestion.issues.values_list("message", flat=True)[:5])
            raise CommandError(
                "Smoke sync completed with issues: "
                + "; ".join(messages)
                + ("" if issue_count <= 5 else f" (+{issue_count - 5} more)")
            )

        self.stdout.write(self.style.SUCCESS("Forward smoke sync completed cleanly."))

    def _run_plan_only(self, sync, *, max_changes_per_branch):
        executor = ForwardMultiBranchExecutor(
            sync,
            sync.source.get_client(),
            sync.logger,
            user=sync.user,
        )
        context, plan = executor.plan(max_changes_per_branch=max_changes_per_branch)
        self.stdout.write(
            self.style.NOTICE(
                f"Planning Forward multi-branch sync '{sync.name}' against "
                f"network '{context['network_id']}' and snapshot '{context['snapshot_id']}' "
                f"(selector: {context['snapshot_selector']})"
            )
        )
        if not plan:
            self.stdout.write("No branch work is needed.")
            return
        for item in plan:
            self.stdout.write(
                f"{item.index} | {item.model_string} | changes={item.estimated_changes} | "
                f"upserts={len(item.upsert_rows)} | deletes={len(item.delete_rows)} | "
                f"mode={item.sync_mode} | execution={item.execution_mode or 'unknown'} | "
                f"label={item.label}"
            )
        self.stdout.write(
            self.style.SUCCESS(
                f"Planned {len(plan)} branches; max planned branch size is "
                f"{max(item.estimated_changes for item in plan)}."
            )
        )

    def _build_source(
        self,
        *,
        source_name,
        source_type,
        url,
        username,
        password,
        network_id,
    ):
        source, _ = ForwardSource.objects.update_or_create(
            name=source_name,
            defaults={
                "type": source_type,
                "url": url,
                "parameters": {
                    "username": username,
                    "password": password,
                    "verify": True,
                    "network_id": network_id,
                },
            },
        )
        source.full_clean()
        source.save()
        return source

    def _build_sync(
        self,
        *,
        sync_name,
        source,
        user,
        snapshot_id,
        selected_models,
        auto_merge,
        execution_backend,
    ):
        sync_parameters = {
            "snapshot_id": snapshot_id,
            "auto_merge": auto_merge,
            "execution_backend": execution_backend,
        }
        for model_string in forward_configured_models():
            sync_parameters[model_string] = model_string in selected_models

        sync, _ = ForwardSync.objects.update_or_create(
            name=sync_name,
            defaults={
                "source": source,
                "user": user,
                "auto_merge": auto_merge,
                "parameters": sync_parameters,
            },
        )
        sync.full_clean()
        sync.save()
        return sync

    def _run_validation_only(self, sync, *, query_limit):
        fetcher = ForwardQueryFetcher(sync, sync.source.get_client(), sync.logger)
        context = fetcher.resolve_context()

        self.stdout.write(
            self.style.NOTICE(
                f"Validating Forward queries for sync '{sync.name}' against network '{context.network_id}' "
                f"and snapshot '{context.snapshot_id}' (selector: {context.snapshot_selector})"
            )
        )

        fetcher.fetch_sample_results(context, row_limit=query_limit)
        for result in fetcher.model_results:
            self.stdout.write(
                f"{result.model_string} | {result.query_name} | {result.execution_mode} | "
                f"rows={result.row_count} | deletes={result.delete_count} | "
                f"mode={result.sync_mode} | runtime_ms={result.runtime_ms}"
            )

        self.stdout.write(
            self.style.SUCCESS("Forward query validation completed cleanly.")
        )

    def _selected_models(self, raw_models):
        if not raw_models.strip():
            return set(forward_configured_models()) - set(FORWARD_OPTIONAL_MODELS)

        selected_models = {
            model.strip() for model in raw_models.split(",") if model.strip()
        }
        invalid_models = sorted(selected_models - set(forward_configured_models()))
        if invalid_models:
            raise CommandError(
                f"Unsupported smoke-sync models: {', '.join(invalid_models)}"
            )
        if not selected_models:
            raise CommandError("Smoke sync requires at least one NetBox model.")
        return selected_models
