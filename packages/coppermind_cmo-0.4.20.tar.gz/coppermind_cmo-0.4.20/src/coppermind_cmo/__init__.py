"""Coppermind CMO — AI memory for fractional CMOs."""

__version__ = "0.4.20"
