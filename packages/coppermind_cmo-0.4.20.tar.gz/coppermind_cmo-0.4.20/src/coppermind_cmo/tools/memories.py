"""Memory tools: store_memory, search_memory, quick_note, hide_memory.

Reference: docs/MCP_TOOLS.md — store_memory, search_memory, quick_note, hide_memory.
"""

import json
import os
import re
import uuid as _uuid
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.embedding_client import get_embedding
from coppermind_cmo.memory_store import MemoryStore
from coppermind_cmo.memory_types import VALID_MEMORY_TYPES
from coppermind_cmo.errors import (
    NO_ACTIVE_MIND, INVALID_INPUT, INVALID_MEMORY_TYPE,
    INVALID_QUERY, MEMORY_NOT_FOUND, tool_error,
)
from coppermind_cmo.utils import get_mind_cadence
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("memories")

MAX_CONTENT_CHARS = 10000
FALLBACK_CONFIDENCE = 0.8
MAX_LIMIT = 200
QUICK_NOTE_SUMMARY_LEN = 100
SIMILARITY_THRESHOLD = 0.3
BRAND_DNA_THRESHOLD = 0.45
COMMITMENT_MATCH_THRESHOLD = 0.25

VALID_SOURCE_TYPES = {
    'manual', 'quick_note', 'meeting', 'slack', 'session_extract', 'folder_ingest',
    'folder_watch', 'email',
}
# Map common non-standard values to valid types
_SOURCE_TYPE_ALIASES: dict[str, str] = {
    'transcript': 'meeting',
    'meeting_transcript': 'meeting',
    'interview': 'meeting',
    'notes': 'meeting',
    'document': 'folder_ingest',
    'file': 'folder_ingest',
    'slack_message': 'slack',
    'slack_export': 'slack',
    'folder_watch': 'folder_watch',
    'email': 'email',
    'gmail': 'email',
}
try:
    RECONSOLIDATION_THRESHOLD = float(os.environ.get("COPPERMIND_RECONSOLIDATION_THRESHOLD", "0.90"))
except ValueError:
    RECONSOLIDATION_THRESHOLD = 0.90


def _apply_recency_bias(
    results: list[dict],
    decay_overrides: dict[str, dict[str, float]] | None = None,
) -> list[dict]:
    """Apply per-type time-decay to similarity scores and re-sort.

    Each memory type has its own decay rate and floor:
    - Decisions/preferences decay slowly (high floor) — they persist
    - Commitments decay quickly (low floor) — action items go stale
    - Facts use the baseline rate

    Formula per type: adjusted_similarity = similarity * max(floor, 1.0 - (age_days / 365.0 * rate))

    Client-level overrides (from configure_mind) are passed via decay_overrides.
    Adds ``age_days`` and ``adjusted_similarity`` to each result dict.
    Original ``similarity`` is preserved unchanged.
    """
    from coppermind_cmo.parsing import parse_datetime
    from coppermind_cmo.memory_types import get_decay_config

    now = datetime.now(timezone.utc)
    for r in results:
        created_at_str = r.get("created_at")
        if created_at_str is not None:
            if isinstance(created_at_str, str):
                created_at = parse_datetime(created_at_str)
            else:
                created_at = created_at_str
            age_days = (now - created_at).days if created_at else 0
        else:
            age_days = 0

        memory_type = r.get("memory_type", "fact")
        rate, floor = get_decay_config(memory_type, decay_overrides)
        decay_factor = max(floor, 1.0 - (age_days / 365.0 * rate))

        r["age_days"] = age_days
        r["adjusted_similarity"] = round(r["similarity"] * decay_factor, 4)

    results.sort(key=lambda r: r["adjusted_similarity"], reverse=True)
    return results


def _keyword_fallback_search(
    db: Database,
    mind_id: str,
    query_text: str,
    memory_type: str | None = None,
    limit: int = 20,
    config: Config | None = None,
    access_filter_sql: str = "",
    access_filter_params: list | None = None,
) -> list[dict]:
    """Case-insensitive ILIKE keyword search as fallback when embeddings are unavailable.

    Searches content and summary columns. Returns results in the same shape as
    the vector search path in _search_memory.

    Delegates to MemoryStore.keyword_search().
    """
    if config is None:
        from coppermind_cmo.server import get_config
        config = get_config()
    store = MemoryStore(db, config)
    return store.keyword_search(
        mind_id, query_text, memory_type=memory_type, limit=limit,
        access_filter_sql=access_filter_sql, access_filter_params=access_filter_params,
    )


def _find_similar_memory(
    embedding: list[float] | None,
    db: Database,
    active_mind: tuple[str, str] | None,
    is_private: bool = False,
    config: Config | None = None,
) -> dict | None:
    """Search for an existing memory similar to the given embedding.

    Returns the best match above RECONSOLIDATION_THRESHOLD or None.
    When is_private column exists, only matches memories with the same
    privacy level to prevent cross-boundary reconsolidation.

    Delegates to MemoryStore.find_similar().
    """
    if embedding is None or active_mind is None:
        return None

    mind_id = active_mind[0]

    if config is None:
        from coppermind_cmo.server import get_config
        config = get_config()
    store = MemoryStore(db, config)
    # Known limitation: concurrent reconsolidation is not protected by row
    # locking. Database.fetch_one() auto-commits, so FOR UPDATE would release
    # immediately. Acceptable for Sprint 1 — single-user MCP server and
    # single-threaded watcher make races practically impossible.
    matches = store.find_similar(
        mind_id, embedding,
        threshold=RECONSOLIDATION_THRESHOLD,
        limit=1,
        is_private=is_private,
    )
    return matches[0] if matches else None


def _update_memory(
    memory_id: str,
    content: str,
    summary: str,
    embedding: list[float] | None,
    db: Database,
    active_mind: tuple[str, str] | None,
    quarter_year: int | None = None,
    quarter: int | None = None,
    sprint: int | None = None,
    is_private: bool = False,
    config: Config | None = None,
) -> None:
    """Update an existing memory's content, summary, and embedding.

    Includes mind_id in WHERE clause to enforce client isolation.
    Sets follows_tool_call to track which tool triggered the merge.

    Delegates to MemoryStore.update_content().
    """
    from coppermind_cmo.server import get_last_tool_call
    mind_id = active_mind[0] if active_mind else None
    follows_tool = get_last_tool_call()
    if config is None:
        from coppermind_cmo.server import get_config
        config = get_config()
    store = MemoryStore(db, config)
    store.update_content(
        mind_id=mind_id,
        memory_id=memory_id,
        content=content,
        summary=summary,
        embedding=embedding,
        quarter_year=quarter_year,
        quarter=quarter,
        sprint=sprint,
        is_private=is_private,
        follows_tool_call=follows_tool,
    )


# ---------------------------------------------------------------------------
# URL auto-capture utilities
# ---------------------------------------------------------------------------

# URL detection pattern — matches http/https URLs, stops at whitespace/quotes/brackets
_URL_PATTERN = re.compile(r'https?://[^\s<>"\')\]\}]+')

# Internal/system URLs to skip
_SKIP_DOMAINS = {"localhost", "127.0.0.1", "0.0.0.0", "api.coppermind.app"}


def _extract_urls(text: str) -> list[str]:
    """Extract URLs from text, filtering system URLs and code blocks.

    Returns deduplicated list of URLs found in the text.
    Skips URLs inside code blocks (``` fenced blocks) and inline code.
    """
    if not text:
        return []

    # Remove code blocks before scanning
    cleaned = re.sub(r'```[\s\S]*?```', '', text)
    cleaned = re.sub(r'`[^`]+`', '', cleaned)

    urls = _URL_PATTERN.findall(cleaned)

    # Filter and deduplicate
    seen: set[str] = set()
    result: list[str] = []
    for url in urls:
        # Strip trailing punctuation that's likely not part of the URL
        url = url.rstrip('.,;:!?')

        # Skip internal/system URLs
        try:
            domain = urlparse(url).hostname or ""
            if domain in _SKIP_DOMAINS:
                continue
        except Exception:
            continue

        # Truncate very long URLs (likely data URIs or encoded blobs)
        if len(url) > 500:
            url = url[:500]

        if url not in seen:
            seen.add(url)
            result.append(url)

    return result


def _extract_url_domain(url: str) -> str:
    """Extract the domain from a URL for grouping."""
    try:
        return urlparse(url).hostname or ""
    except Exception:
        return ""


def store_memory_core(
    content: str,
    memory_type: str | None,
    tags: list[str],
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
    skip_reconsolidation: bool = False,
    source_type: str = "manual",
    source_ref: str | None = None,
    source_tool: str | None = None,
    summary: str | None = None,
    is_private: bool = False,
    raw_document_id: str | None = None,
    sensitivity: str | None = None,
    access_level: str = "owner",
    caller_id: str | None = None,
    embedding: list[float] | None = None,
    confidence: float = 1.0,
    _skip_enqueue: bool = False,
) -> dict[str, Any]:
    """Shared memory storage API used by both MCP tools and the ingestion engine.

    This is the core storage function. The MCP-registered ``store_memory`` tool
    delegates to this after access-control checks.  ``ingest.py`` calls it
    directly for bulk extraction.

    Returns a dict with at minimum ``memory_id`` on success, or an error dict.
    """
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    if not content or not content.strip():
        return INVALID_INPUT("content cannot be empty")
    if len(content) > MAX_CONTENT_CHARS:
        return INVALID_INPUT(f"content exceeds {MAX_CONTENT_CHARS:,} character limit")

    if summary is not None and len(summary) > 500:
        return INVALID_INPUT("summary exceeds 500 character limit")

    # Normalize source_type — map aliases and fallback to "manual" for unknown values
    if source_type not in VALID_SOURCE_TYPES:
        normalized = _SOURCE_TYPE_ALIASES.get(source_type)
        if normalized:
            logger.info(
                f"Normalized source_type '{source_type}' → '{normalized}'",
                mind_id=mind_id,
            )
            source_type = normalized
        else:
            logger.warn(
                f"Unknown source_type '{source_type}', falling back to 'manual'",
                mind_id=mind_id,
            )
            source_type = "manual"

    if len(tags) > 20:
        return INVALID_INPUT("Maximum 20 tags allowed")
    if any(len(t) > 100 for t in tags):
        return INVALID_INPUT("Each tag must be 100 characters or fewer")

    # Preserve full document for long content (future re-extraction).
    # Skip if caller already supplied a raw_document_id (e.g. IngestEngine).
    if len(content) > 4000 and raw_document_id is None:
        from coppermind_cmo.ingest import _store_raw_document
        try:
            raw_document_id = _store_raw_document(content, mind_id, db, source_type=source_type)
        except Exception as e:
            logger.warn(f"Failed to store raw document for long content, continuing: {e}",
                        mind_id=mind_id)

    # Normalize user-provided memory_type (invalid types fall back to "fact")
    classified_by = "user"
    # Keep caller-provided confidence (e.g., from pending queue replay); default is 1.0 from signature
    if memory_type is not None:
        from coppermind_cmo.parsing import normalize_memory_type
        cleaned = normalize_memory_type(memory_type)
        if cleaned is None:
            logger.warn(
                f"Invalid memory_type '{memory_type}', falling back to 'fact'",
                mind_id=mind_id,
            )
            memory_type = "fact"
            classified_by = "default"
            confidence = FALLBACK_CONFIDENCE
        else:
            memory_type = cleaned

    if memory_type is None:
        # No LLM classification — default to "fact"
        memory_type = "fact"
        classified_by = "default"
        confidence = FALLBACK_CONFIDENCE

    # Auto-classify sensitivity when not explicitly provided
    if sensitivity is None:
        from coppermind_cmo.memory_types import classify_sensitivity
        sensitivity = classify_sensitivity(content)

    # Pending lifecycle for viewers
    status = "active"
    skip_viewer_reconsolidation = False
    if access_level == "viewer":
        status = "pending"
        skip_viewer_reconsolidation = True  # Don't merge VA pending into owner active

    created_by = caller_id  # Always set (backfilled for existing memories)

    # Use pre-computed embedding (from pending queue replay) or compute fresh
    if embedding is not None:
        has_embedding = True
    else:
        embedding = get_embedding(content, config)
        has_embedding = embedding is not None
        if not has_embedding:
            logger.warn(
                "Embedding service unavailable — memory saved but won't appear in semantic search until re-embedded.",
                mind_id=mind_id,
            )

    # Fetch cadence for quarter tagging
    cadence = get_mind_cadence(mind_id, db)
    quarter_year = cadence.get("year")
    quarter = cadence.get("quarter")
    sprint = cadence.get("sprint")

    # --- Reconsolidation: check for similar existing memory ---
    # NOTE: raw_document_id is not propagated during reconsolidation.
    # The reconsolidated memory keeps its existing raw_document_id (likely NULL).
    # This is acceptable for now — reconsolidation merges content, not provenance.
    if has_embedding and not skip_reconsolidation and not skip_viewer_reconsolidation:
        similar = _find_similar_memory(embedding, db, active_mind, is_private=is_private)
        if similar is not None:
            # Pure embedding-based reconsolidation — no LLM confirmation needed.
            # Replace old memory with new content directly.
            recon_summary = summary if summary else content[:100]
            # Reuse the embedding already computed above — no need to call
            # get_embedding a second time on the same content.
            _update_memory(
                similar["memory_id"],
                content,
                recon_summary,
                embedding,
                db,
                active_mind,
                quarter_year=quarter_year,
                quarter=quarter,
                sprint=sprint,
                is_private=is_private,
            )
            logger.info(
                f"Reconsolidated memory: {recon_summary}",
                mind_id=mind_id,
                original_id=similar["memory_id"],
                similarity=similar["similarity"],
            )
            return {
                "memory_id": similar["memory_id"],
                "summary": recon_summary,
                "memory_type": similar["memory_type"],
                "classified_by": classified_by,
                "has_embedding": has_embedding,
                "mind_id": mind_id,
                "is_private": is_private,
                "reconsolidated": True,
                "message": (
                    f"Replaced existing memory (similarity: "
                    f"{similar['similarity']:.0%}). Updated summary: {recon_summary}"
                ),
            }

    # Use provided summary or fall back to truncation
    if not summary:
        summary = content[:100]

    # Resolve follows_tool_call from server tracking
    from coppermind_cmo.server import get_last_tool_call
    follows_tool = get_last_tool_call()

    # Insert new memory via MemoryStore
    store = MemoryStore(db, config)
    stored = store.store(
        mind_id=mind_id,
        content=content,
        memory_type=memory_type,
        summary=summary,
        embedding=embedding,
        confidence=confidence,
        source_type=source_type,
        source_ref=source_ref,
        tags=tags,
        quarter_year=quarter_year,
        quarter=quarter,
        sprint=sprint,
        source_tool=source_tool,
        follows_tool_call=follows_tool,
        is_private=is_private,
        raw_document_id=raw_document_id,
        sensitivity=sensitivity,
        status=status,
        created_by=created_by,
        _skip_enqueue=_skip_enqueue,
    )

    # Handle locally-queued result (DB was down, memory saved to pending queue)
    if stored and stored.get("status") == "queued_locally":
        return {
            "memory_id": "pending",
            "status": "queued_locally",
            "message": stored["message"],
            "mind_id": mind_id,
            "memory_type": memory_type or "fact",
            "has_embedding": has_embedding,
        }

    if stored is None:
        return tool_error("INTERNAL_ERROR", "Couldn't save this memory — the database rejected it. Try again, or contact coppermind@volacci.com if the problem persists.")

    memory_id = stored["id"]
    logger.info(f"Stored memory: {summary}", mind_id=mind_id)

    result = {
        "memory_id": memory_id,
        "summary": summary,
        "memory_type": memory_type,
        "classified_by": classified_by,
        "has_embedding": has_embedding,
        "mind_id": mind_id,
        "is_private": is_private,
    }
    if not has_embedding:
        result["degraded"] = True
        result["degraded_reason"] = (
            "Embedding service unavailable — memory saved but invisible to "
            "semantic search until re-embedded."
        )

    # Auto-capture URLs found in content
    urls = _extract_urls(content)
    if urls:
        existing_tags = set(tags)
        if "url" not in existing_tags:
            try:
                db.execute(
                    "UPDATE memories SET tags = array_cat(tags, %s) WHERE id = %s::uuid AND mind_id = %s::uuid",
                    [["url", "shared_resource"], memory_id, mind_id],
                )
                result["urls_captured"] = len(urls)
                result["urls"] = urls[:5]  # Return first 5 for visibility
            except Exception as e:
                logger.warn(f"Failed to add URL tags: {e}", mind_id=mind_id)

    # Auto-populate email contacts when storing stakeholder memories
    if memory_type == "stakeholder":
        try:
            from coppermind_cmo.email_poller import auto_populate_email_contacts
            contacts_added = auto_populate_email_contacts(db, mind_id, content)
            if contacts_added:
                result["email_contacts_added"] = contacts_added
        except Exception as e:
            logger.debug(f"Email contact auto-population skipped: {e}", mind_id=mind_id)

    return result


def _match_stakeholders(query: str, stakeholders: list[dict], existing_content: list[str]) -> list[dict]:
    """Match query against stakeholder name/title/role via case-insensitive substring.

    Returns synthetic search results for matching stakeholders, excluding any
    whose name already appears in existing_content (dedup with vector results).
    """
    query_lower = query.lower()
    matches = []
    for s in stakeholders:
        name = s.get("name", "")
        title = s.get("title", "")
        role = s.get("role", "")
        searchable = f"{name} {title} {role}".lower()

        if not any(term in searchable for term in query_lower.split()):
            continue

        # Dedup: skip if this stakeholder's name already appears in vector results
        if any(name.lower() in c.lower() for c in existing_content if c):
            continue

        # Build content string from all stakeholder fields
        parts = [f"{name}"]
        if title:
            parts.append(f"Title: {title}")
        if role:
            parts.append(f"Role: {role}")
        for k, v in s.items():
            if k not in ("name", "title", "role") and v:
                parts.append(f"{k}: {v}")
        content = " | ".join(parts)

        matches.append({
            "memory_id": None,
            "content": content,
            "summary": f"{name} — {title}" if title else name,
            "memory_type": "stakeholder",
            "confidence": 1.0,
            "similarity": 1.0,
            "tags": [],
            "source_type": "brand_dna",
            "created_at": None,
        })
    return matches


def _search_memory(
    query: str,
    memory_type: str | None,
    limit: int,
    offset: int,
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
    include_private: bool = True,
    access_level: str = "owner",
    caller_id: str | None = None,
) -> dict | list:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    if not query or not query.strip():
        return INVALID_QUERY()

    limit = min(max(1, limit), MAX_LIMIT)
    offset = max(0, offset)

    if memory_type is not None:
        from coppermind_cmo.parsing import normalize_memory_type
        cleaned = normalize_memory_type(memory_type)
        if cleaned is None:
            logger.warn(
                f"Invalid memory_type filter '{memory_type}', ignoring filter",
                mind_id=mind_id,
            )
            memory_type = None  # search without type filter
        else:
            memory_type = cleaned

    # Build access-level-aware filters (type + sensitivity + status)
    from coppermind_cmo.tools.access import _access_filters, get_viewer_allowed_types
    config_row = db.fetch_one(
        "SELECT sharing_config FROM client_minds WHERE id = %s", [mind_id]
    )
    sharing_config = config_row[0] if config_row and config_row[0] else None
    allowed_types = get_viewer_allowed_types(sharing_config)
    filter_sql, filter_params = _access_filters(
        access_level, caller_id or "", allowed_types=allowed_types,
    )

    embedding = get_embedding(query, config)
    if embedding is None:
        logger.warn("Embedding service unreachable for search_memory — falling back to keyword search", mind_id=mind_id)
        fallback_results = _keyword_fallback_search(
            db, mind_id, query, memory_type, limit, config=config,
            access_filter_sql=filter_sql, access_filter_params=filter_params,
        )

        # Cross-reference brand DNA stakeholders for keyword fallback too
        should_check_brand_dna = (
            access_level == "owner"  # viewers don't get synthetic stakeholder results
            and (memory_type is None or memory_type == "stakeholder")
        )
        if should_check_brand_dna:
            if len(fallback_results) < limit:
                stakeholder_row = db.fetch_one(
                    "SELECT stakeholders FROM client_minds WHERE id = %s",
                    [mind_id],
                )
                raw = stakeholder_row[0] if stakeholder_row and stakeholder_row[0] else []
                stakeholders = raw if isinstance(raw, list) else []
                if stakeholders:
                    existing_content = [r["content"] for r in fallback_results]
                    brand_matches = _match_stakeholders(query, stakeholders, existing_content)
                    fallback_results.extend(brand_matches)

        _apply_recency_bias(fallback_results)
        return {
            "results": fallback_results[:limit],
            "degraded": True,
            "degraded_reason": (
                "Embedding service unavailable — results are keyword-matched, "
                "not semantic. Relevance may be lower."
            ),
        }

    # Check if is_private column exists (migration 015)
    has_private = _has_is_private(db)

    # Build query with CTE for single embedding computation
    private_col = ", is_private" if has_private else ""
    sql = (
        "WITH q AS (SELECT %s::vector AS qv) "
        "SELECT id, content, summary, memory_type, confidence, "
        "1 - (embedding <=> q.qv) AS similarity, "
        f"tags, source_type, created_at{private_col} "
        "FROM memories, q "
        "WHERE mind_id = %s AND is_current = true AND embedding IS NOT NULL "
        "AND 1 - (embedding <=> q.qv) >= %s "
    )
    params: list[Any] = [json.dumps(embedding), mind_id, SIMILARITY_THRESHOLD]

    if memory_type:
        sql += "AND memory_type = %s "
        params.append(memory_type)

    if not include_private and has_private:
        sql += "AND (is_private = false OR is_private IS NULL) "

    if filter_sql:
        sql += f"{filter_sql} "
        if filter_params:
            params.extend(filter_params)

    sql += "ORDER BY embedding <=> q.qv ASC LIMIT %s OFFSET %s"
    params.extend([limit, offset])

    rows = db.fetch_all(sql, params)

    results = [
        {
            "memory_id": str(r[0]),
            "content": r[1],
            "summary": r[2],
            "memory_type": r[3],
            "confidence": float(r[4]),
            "similarity": round(float(r[5]), 4),
            "tags": r[6] if r[6] else [],
            "source_type": r[7],
            "created_at": r[8].isoformat() if r[8] else None,
            **({"is_private": bool(r[9])} if has_private else {}),
        }
        for r in rows
    ]

    # Cross-reference brand DNA stakeholders when results are sparse or low quality
    should_check_brand_dna = (
        access_level == "owner"  # viewers don't get synthetic stakeholder results
        and (memory_type is None or memory_type == "stakeholder")
    ) and offset == 0
    if should_check_brand_dna:
        best_similarity = max((r["similarity"] for r in results), default=0.0)
        if len(results) < limit or best_similarity < BRAND_DNA_THRESHOLD:
            stakeholder_row = db.fetch_one(
                "SELECT stakeholders FROM client_minds WHERE id = %s",
                [mind_id],
            )
            raw = stakeholder_row[0] if stakeholder_row and stakeholder_row[0] else []
            stakeholders = raw if isinstance(raw, list) else []
            if stakeholders:
                existing_content = [r["content"] for r in results]
                brand_matches = _match_stakeholders(query, stakeholders, existing_content)
                results.extend(brand_matches)

    _apply_recency_bias(results)
    return results[:limit]


def _quick_note(
    content: str,
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
    is_private: bool = False,
    access_level: str = "owner",
    caller_id: str | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    if not content or not content.strip():
        return INVALID_INPUT("content cannot be empty")
    if len(content) > MAX_CONTENT_CHARS:
        return INVALID_INPUT(f"content exceeds {MAX_CONTENT_CHARS:,} character limit")

    summary = content[:QUICK_NOTE_SUMMARY_LEN]
    embedding = get_embedding(content, config)
    has_embedding = embedding is not None
    if not has_embedding:
        logger.warn(
            "Embedding service unavailable — quick note saved but won't appear in semantic search until re-embedded.",
            mind_id=mind_id,
        )

    # Fetch cadence for quarter tagging
    cadence = get_mind_cadence(mind_id, db)
    quarter_year = cadence.get("year")
    quarter = cadence.get("quarter")
    sprint = cadence.get("sprint")

    # Pending lifecycle for viewers
    status = "active"
    if access_level == "viewer":
        status = "pending"

    created_by = caller_id

    from coppermind_cmo.server import get_last_tool_call
    follows_tool = get_last_tool_call()

    # Classify sensitivity before storing
    from coppermind_cmo.memory_types import classify_sensitivity
    sensitivity = classify_sensitivity(content)

    # Insert via MemoryStore
    store = MemoryStore(db, config)
    stored = store.store(
        mind_id=mind_id,
        content=content,
        memory_type="fact",
        summary=summary,
        embedding=embedding,
        confidence=FALLBACK_CONFIDENCE,
        source_type="quick_note",
        quarter_year=quarter_year,
        quarter=quarter,
        sprint=sprint,
        source_tool="quick_note",
        follows_tool_call=follows_tool,
        is_private=is_private,
        sensitivity=sensitivity,
        status=status,
        created_by=created_by,
    )
    if stored is None:
        return tool_error("INTERNAL_ERROR", "Couldn't save this memory — the database rejected it. Try again, or contact coppermind@volacci.com if the problem persists.")

    result = {"memory_id": stored["id"], "mind_id": mind_id, "summary": summary, "memory_type": "fact", "is_private": is_private}
    if not has_embedding:
        result["degraded"] = True
        result["degraded_reason"] = (
            "Embedding service unavailable — memory saved but invisible to "
            "semantic search until re-embedded."
        )
    return result


def _hide_memory(
    memory_id: str,
    db: Database,
    active_mind: tuple[str, str] | None,
    config: Config | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    try:
        _uuid.UUID(memory_id)
    except ValueError:
        return INVALID_INPUT("Invalid memory_id format")

    # Verify memory exists and get summary for response
    row = db.fetch_one(
        "SELECT id, summary FROM memories WHERE id = %s AND mind_id = %s",
        [memory_id, mind_id],
    )
    if not row:
        return MEMORY_NOT_FOUND(memory_id)

    summary = row[1]

    # Set is_current = false via MemoryStore (trigger handles updated_at)
    if config is None:
        from coppermind_cmo.server import get_config
        config = get_config()
    store = MemoryStore(db, config)
    store.hide(mind_id, memory_id)

    logger.info(f"Hidden memory: {summary}", mind_id=mind_id)

    return {
        "memory_id": memory_id,
        "hidden": True,
        "summary": summary,
    }


_has_completed_col: bool | None = None


def _has_is_completed(db: Database) -> bool:
    """Check if is_completed column exists (migration 014). Only caches True."""
    global _has_completed_col
    if _has_completed_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'memories' AND column_name = 'is_completed' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_completed_col = True
            return row is not None
        except Exception:
            return False
    return _has_completed_col


_has_private_col: bool | None = None


def _has_is_private(db: Database) -> bool:
    """Check if is_private column exists (migration 015). Only caches True."""
    global _has_private_col
    if _has_private_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'memories' AND column_name = 'is_private' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_private_col = True
            return row is not None
        except Exception:
            return False
    return _has_private_col


def _done_commitment(
    search: str,
    pick: int | None,
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
) -> dict:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    if not search or not search.strip():
        return INVALID_INPUT("search cannot be empty")

    if not _has_is_completed(db):
        return tool_error(
            "MIGRATION_REQUIRED",
            "Run migration 014_commitment_completion.sql to enable commitment completion.",
        )

    embedding = get_embedding(search, config)
    degraded = embedding is None
    if degraded:
        logger.warn(
            "Embedding service unreachable for done — falling back to keyword search",
            mind_id=mind_id,
        )
        # Keyword fallback: ILIKE search on commitment content/summary
        from coppermind_cmo.parsing import escape_like
        words = search.strip().split()
        escaped = []
        for w in words:
            escaped.append(f"%{escape_like(w)}%")
        conditions = []
        params: list[Any] = [mind_id]
        for pattern in escaped:
            conditions.append("(content ILIKE %s OR summary ILIKE %s)")
            params.extend([pattern, pattern])
        where_clause = " AND ".join(conditions)
        rows = db.fetch_all(
            "SELECT id, content, summary, 0.0 AS similarity "
            "FROM memories "
            f"WHERE mind_id = %s AND memory_type = 'commitment' "
            f"AND is_current = true AND is_completed = false "
            f"AND ({where_clause}) "
            "ORDER BY created_at DESC LIMIT 3",
            params,
        )
    else:
        rows = db.fetch_all(
            "WITH q AS (SELECT %s::vector AS qv) "
            "SELECT id, content, summary, "
            "1 - (embedding <=> q.qv) AS similarity "
            "FROM memories, q "
            "WHERE mind_id = %s AND memory_type = 'commitment' "
            "AND is_current = true AND is_completed = false "
            "AND embedding IS NOT NULL "
            "AND 1 - (embedding <=> q.qv) >= %s "
            "ORDER BY embedding <=> q.qv ASC LIMIT 3",
            [json.dumps(embedding), mind_id, COMMITMENT_MATCH_THRESHOLD],
        )

    if not rows:
        return {"matched": 0, "message": f"No open commitments matching '{search}'."}

    if pick is not None:
        if pick < 1 or pick > len(rows):
            return INVALID_INPUT(f"pick must be between 1 and {len(rows)}")
        chosen = rows[pick - 1]
    elif len(rows) == 1:
        chosen = rows[0]
    else:
        # Multiple matches — return candidates for user to pick
        candidates = []
        for i, r in enumerate(rows, 1):
            candidates.append({
                "pick": i,
                "summary": r[2] or r[1][:100],
                "similarity": round(float(r[3]), 4),
            })
        result = {
            "matched": len(rows),
            "message": f"Found {len(rows)} open commitments matching '{search}'. Use pick= to select one.",
            "candidates": candidates,
        }
        if degraded:
            result["degraded"] = True
            result["degraded_reason"] = (
                "Embedding service unavailable — results are keyword-matched, "
                "not semantic. Relevance may be lower."
            )
        return result

    store = MemoryStore(db, config)
    store.mark_completed(mind_id, str(chosen[0]))
    logger.info(f"Completed commitment: {chosen[2]}", mind_id=mind_id)
    result = {"matched": 1, "done": True, "summary": chosen[2] or chosen[1][:100]}
    if degraded:
        result["degraded"] = True
        result["degraded_reason"] = (
            "Embedding service unavailable — results are keyword-matched, "
            "not semantic. Relevance may be lower."
        )
    return result


def register(mcp_server):
    """Register memory tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_config, get_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED
    from coppermind_cmo.resilience import safe_tool_call
    from coppermind_cmo.tools.access import _get_access_level

    @mcp_server.tool()
    @safe_tool_call("store_memory")
    def store_memory(
        content: str,
        memory_type: str | None = None,
        tags: list[str] | None = None,
        summary: str | None = None,
        private: bool = False,
        sensitivity: str | None = None,
    ) -> dict:
        """Store a piece of client knowledge as a memory.

        Recommended: provide memory_type and summary for best results.
        - memory_type: one of decision, preference, campaign_outcome, commitment, stakeholder, fact, question
        - summary: a concise 1-2 sentence summary of the memory
        - private: if true, this memory is excluded from client handoff exports and client-facing briefs
        If omitted, memory_type defaults to 'fact' and summary to the first 100 characters.

        When a user pastes a meeting transcript or long-form notes, extract individual
        memories yourself and call store_memory once per memory with type and summary.
        Do not store the raw transcript as a single memory.

        If the response includes `notifications`, share each one with the user before proceeding.
        """
        set_last_tool_call("store_memory")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        customer_id = get_customer_id()
        if not _verify_mind_access(active_mind[0], customer_id, get_db()):
            return ACCESS_DENIED()

        access_level = _get_access_level(active_mind[0], customer_id, get_db())

        result = store_memory_core(
            content, memory_type, tags or [], get_db(), get_config(), active_mind,
            source_tool="store_memory",
            summary=summary,
            is_private=private,
            sensitivity=sensitivity,
            access_level=access_level or "owner",
            caller_id=customer_id,
        )

        # Add pending message for viewers
        if access_level == "viewer":
            result["message"] = "Stored as pending \u2014 your CMO will review this."

        return attach_notifications(result, customer_id=customer_id, db=get_db())

    @mcp_server.tool()
    @safe_tool_call("search_memory")
    def search_memory(
        query: str,
        memory_type: str | None = None,
        limit: int = 10,
        offset: int = 0,
        include_private: bool = True,
    ) -> list | dict:
        """Semantic search across the active client's memories.

        Set include_private=false to exclude private memories (e.g. for client handoff exports).
        """
        set_last_tool_call("search_memory")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        customer_id = get_customer_id()
        if not _verify_mind_access(active_mind[0], customer_id, get_db()):
            return ACCESS_DENIED()
        access_level = _get_access_level(active_mind[0], customer_id, get_db())
        return _search_memory(
            query, memory_type, limit, offset, get_db(), get_config(), active_mind,
            include_private=include_private,
            access_level=access_level or "owner",
            caller_id=customer_id,
        )

    @mcp_server.tool()
    @safe_tool_call("quick_note")
    def quick_note(content: str, private: bool = False) -> dict:
        """Fast capture — no LLM call. For jotting down a thought during a session.

        Set private=true to exclude this note from client handoff exports and client-facing briefs.

        If the response includes `notifications`, share each one with the user before proceeding.
        """
        set_last_tool_call("quick_note")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        customer_id = get_customer_id()
        if not _verify_mind_access(active_mind[0], customer_id, get_db()):
            return ACCESS_DENIED()

        access_level = _get_access_level(active_mind[0], customer_id, get_db())

        result = _quick_note(
            content, get_db(), get_config(), active_mind,
            is_private=private,
            access_level=access_level or "owner",
            caller_id=customer_id,
        )

        # Add pending message for viewers
        if access_level == "viewer":
            result["message"] = "Stored as pending \u2014 your CMO will review this."

        return attach_notifications(result, customer_id=customer_id, db=get_db())

    @mcp_server.tool()
    @safe_tool_call("hide_memory")
    def hide_memory(memory_id: str) -> dict:
        """Hide a memory so it no longer appears in search, meeting prep, or campaign history.

        If the response includes `notifications`, share each one with the user before proceeding.
        """
        set_last_tool_call("hide_memory")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        access_level = _get_access_level(active_mind[0], get_customer_id(), get_db())
        if access_level != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _hide_memory(memory_id, get_db(), active_mind)
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("done")
    def done(search: str, pick: int | None = None) -> dict:
        """Mark a commitment as complete. Search by natural language fragment.

        Completed commitments show as checked off in meeting briefs instead of disappearing.
        If multiple commitments match, returns numbered candidates — call again with pick=N.
        """
        set_last_tool_call("done")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        access_level = _get_access_level(active_mind[0], get_customer_id(), get_db())
        if access_level != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _done_commitment(search, pick, get_db(), get_config(), active_mind)
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())
