"""Email connection tools: connect_gmail, disconnect_gmail, email_status.

Manages the Gmail OAuth connection for automatic email ingestion.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("email_connect")

_STATUS_FILE = Path.home() / ".coppermind" / "email_poller_status.json"


def register(mcp_server):
    """Register email connection tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_config, set_last_tool_call
    from coppermind_cmo.resilience import safe_tool_call

    @mcp_server.tool()
    @safe_tool_call("connect_gmail")
    def connect_gmail() -> dict:
        """Connect Gmail for automatic email ingestion.

        Generates a Google OAuth authorization URL. The CMO clicks the link
        to grant read-only Gmail access. After authorization, emails from
        known client contacts are automatically ingested into the correct
        client minds.

        Returns an authorization URL to open in a browser.
        """
        set_last_tool_call("connect_gmail")
        db = get_db()
        config = get_config()

        # Check if already connected
        existing = db.execute(
            "SELECT connected_at, auth_error FROM customer_google_tokens "
            "WHERE customer_id = %s",
            (config.customer_id,),
        )
        if existing and not existing[0].get("auth_error"):
            connected_at = existing[0]["connected_at"]
            return {
                "status": "already_connected",
                "message": f"Gmail is already connected (since {connected_at}). "
                    "Use disconnect_gmail first if you want to reconnect.",
            }

        # Request OAuth URL from gateway
        import httpx
        try:
            resp = httpx.post(
                f"{config.gateway_url.rstrip('/')}/v1/auth/google",
                headers={"Authorization": f"Bearer {config.api_key}"},
                timeout=10.0,
            )
            if resp.status_code != 200:
                return {
                    "error": f"Gateway returned {resp.status_code}",
                    "message": "Failed to initiate Gmail connection. Check gateway configuration.",
                }
            data = resp.json()
            return {
                "status": "authorization_required",
                "auth_url": data["auth_url"],
                "message": "Open this URL in your browser to connect Gmail. "
                    "After granting access, emails from your client contacts "
                    "will automatically appear in your briefs.",
            }
        except Exception as e:
            return {
                "error": str(e),
                "message": "Failed to reach the gateway. Check your internet connection.",
            }

    @mcp_server.tool()
    @safe_tool_call("disconnect_gmail")
    def disconnect_gmail() -> dict:
        """Disconnect Gmail and stop email ingestion.

        Removes the stored OAuth tokens. Email polling stops immediately.
        Previously ingested memories remain in place.
        """
        set_last_tool_call("disconnect_gmail")
        db = get_db()
        config = get_config()

        # Request disconnect from gateway
        import httpx
        try:
            resp = httpx.post(
                f"{config.gateway_url.rstrip('/')}/v1/disconnect/google",
                headers={"Authorization": f"Bearer {config.api_key}"},
                timeout=10.0,
            )
            if resp.status_code != 200:
                return {
                    "error": f"Gateway returned {resp.status_code}",
                    "message": "Failed to disconnect Gmail.",
                }
            return {
                "status": "disconnected",
                "message": "Gmail disconnected. Email ingestion has stopped. "
                    "Existing email-sourced memories are still available.",
            }
        except Exception as e:
            return {
                "error": str(e),
                "message": "Failed to reach the gateway.",
            }

    @mcp_server.tool()
    @safe_tool_call("email_status")
    def email_status() -> dict:
        """Check the status of Gmail email ingestion.

        Shows connection status, last poll time, emails ingested,
        and any errors or warnings.
        """
        set_last_tool_call("email_status")
        db = get_db()
        config = get_config()

        # Check token row
        row = db.execute(
            "SELECT connected_at, last_poll_at, consecutive_failures, auth_error, scopes "
            "FROM customer_google_tokens WHERE customer_id = %s",
            (config.customer_id,),
        )

        if not row:
            return {
                "status": "not_connected",
                "message": "Gmail is not connected. Use connect_gmail to set up email ingestion.",
            }

        token = row[0]
        result: dict[str, Any] = {
            "status": "error" if token.get("auth_error") else "connected",
            "connected_at": str(token.get("connected_at", "")),
            "last_poll_at": str(token.get("last_poll_at", "never")),
            "scopes": token.get("scopes", []),
        }

        if token.get("auth_error"):
            result["error"] = token["auth_error"]
            result["message"] = (
                f"Gmail connection has an error: {token['auth_error']}. "
                "Use connect_gmail to reconnect."
            )
        elif token.get("consecutive_failures", 0) > 0:
            result["warnings"] = f"{token['consecutive_failures']} consecutive poll failures"

        # Count email-sourced memories this week
        memory_count = db.execute(
            "SELECT COUNT(*) as count FROM memories "
            "WHERE mind_id IN (SELECT id FROM client_minds WHERE customer_id = %s) "
            "AND source_type = 'email' "
            "AND created_at > now() - interval '7 days'",
            (config.customer_id,),
        )
        if memory_count:
            result["memories_this_week"] = memory_count[0]["count"]

        # Count multi-match emails pending
        pending = db.execute(
            "SELECT COUNT(*) as count FROM email_attribution_log "
            "WHERE customer_id = %s AND status = 'multi_match'",
            (config.customer_id,),
        )
        if pending and pending[0]["count"] > 0:
            result["unattributed_emails"] = pending[0]["count"]
            result["message"] = (
                f"{pending[0]['count']} email(s) matched multiple clients "
                "and couldn't be auto-attributed."
            )

        # Read poller status file for last cycle info
        try:
            if _STATUS_FILE.exists():
                status_data = json.loads(_STATUS_FILE.read_text())
                if "last_cycle" in status_data:
                    result["last_cycle"] = status_data["last_cycle"]
        except Exception:
            pass

        if "message" not in result:
            result["message"] = "Gmail connected and email ingestion is active."

        return result
