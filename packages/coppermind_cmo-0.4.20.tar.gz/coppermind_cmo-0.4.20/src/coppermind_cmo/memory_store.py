"""Memory Layer: repository for all generic memory and mind SQL operations.

MemoryStore encapsulates every database interaction for the memories and
client_minds tables.  It is the single place where SQL touches these tables,
making it possible to swap storage backends or add caching without touching
product-level tool code.

Design rules:
- No CMO-specific concepts (no brand_voice, no campaign_outcome filtering,
  no EOS tables, no tips).  Those stay in the product tools.
- Constructor takes ``db: Database`` and ``config: Config``.
- Methods mirror what the tools currently do, just abstracted.
"""

from __future__ import annotations

import json
from typing import Any, TYPE_CHECKING

from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import parse_jsonb

if TYPE_CHECKING:
    from coppermind_cmo.config import Config
    from coppermind_cmo.db import Database

logger = ToolLogger("memory_store")


# ---------------------------------------------------------------------------
# Column-existence caches (only caches True, re-checks on each process start)
# ---------------------------------------------------------------------------
_has_private_col: bool | None = None
_has_completed_col: bool | None = None
_has_internal_col: bool | None = None
_has_raw_doc_id_col: bool | None = None
_has_sensitivity_col: bool | None = None
_has_status_col: bool | None = None


def _has_is_private(db: "Database") -> bool:
    """Check if is_private column exists (migration 015). Only caches True."""
    global _has_private_col
    if _has_private_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'memories' AND column_name = 'is_private' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_private_col = True
            return row is not None
        except Exception:
            return False
    return _has_private_col


def _has_is_completed(db: "Database") -> bool:
    """Check if is_completed column exists (migration 014). Only caches True."""
    global _has_completed_col
    if _has_completed_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'memories' AND column_name = 'is_completed' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_completed_col = True
            return row is not None
        except Exception:
            return False
    return _has_completed_col


def _has_is_internal(db: "Database") -> bool:
    """Check if is_internal column exists on client_minds (migration 007). Only caches True."""
    global _has_internal_col
    if _has_internal_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'client_minds' AND column_name = 'is_internal' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_internal_col = True
            return row is not None
        except Exception:
            return False
    return _has_internal_col


def _has_raw_document_id(db: "Database") -> bool:
    """Check if raw_document_id column exists on memories (migration 028). Only caches True."""
    global _has_raw_doc_id_col
    if _has_raw_doc_id_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'memories' AND column_name = 'raw_document_id' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_raw_doc_id_col = True
            return row is not None
        except Exception:
            return False
    return _has_raw_doc_id_col


def _has_sensitivity(db: "Database") -> bool:
    """Check if sensitivity column exists (migration 028). Only caches True."""
    global _has_sensitivity_col
    if _has_sensitivity_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'memories' AND column_name = 'sensitivity' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_sensitivity_col = True
            return row is not None
        except Exception:
            return False
    return _has_sensitivity_col


def _has_status(db: "Database") -> bool:
    """Check if status column exists on memories (migration 028). Only caches True."""
    global _has_status_col
    if _has_status_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'memories' AND column_name = 'status' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_status_col = True
            return row is not None
        except Exception:
            return False
    return _has_status_col


class MemoryStore:
    """Repository for all generic memory and mind SQL operations.

    Wraps a ``Database`` instance and provides typed methods for every
    query that touches the ``memories``, ``client_minds``,
    ``customer_mind_access``, ``ingest_sources``, and ``ingest_log`` tables.
    """

    def __init__(self, db: "Database", config: "Config"):
        self.db = db
        self.config = config

    # -----------------------------------------------------------------------
    # Column introspection helpers (delegate to module-level caches)
    # -----------------------------------------------------------------------

    def has_is_private(self) -> bool:
        """True if the memories table has the is_private column."""
        return _has_is_private(self.db)

    def has_is_completed(self) -> bool:
        """True if the memories table has the is_completed column."""
        return _has_is_completed(self.db)

    def has_is_internal(self) -> bool:
        """True if the client_minds table has the is_internal column."""
        return _has_is_internal(self.db)

    # ===================================================================
    # Core memory operations
    # ===================================================================

    def store(
        self,
        mind_id: str,
        content: str,
        memory_type: str,
        summary: str | None = None,
        embedding: list[float] | None = None,
        confidence: float = 1.0,
        source_type: str = "manual",
        source_ref: str | None = None,
        tags: list[str] | None = None,
        quarter_year: int | None = None,
        quarter: int | None = None,
        sprint: int | None = None,
        source_tool: str | None = None,
        follows_tool_call: str | None = None,
        is_private: bool = False,
        raw_document_id: str | None = None,
        sensitivity: str = "open",
        status: str = "active",
        created_by: str | None = None,
        _skip_enqueue: bool = False,
    ) -> dict | None:
        """INSERT a new row into the memories table. Returns the new row as a dict.

        Returns ``None`` if the database rejected the insert.
        """
        if tags is None:
            tags = []

        has_private = _has_is_private(self.db)
        has_sens = _has_sensitivity(self.db)

        if embedding is not None:
            cols = (
                "mind_id, content, summary, memory_type, embedding, confidence, "
                "source_type, source_ref, tags, quarter_year, quarter, sprint, "
                "source_tool, follows_tool_call"
            )
            vals = "%s, %s, %s, %s, %s::vector, %s, %s, %s, %s, %s, %s, %s, %s, %s"
            params: list[Any] = [
                mind_id, content, summary, memory_type, json.dumps(embedding),
                confidence, source_type, source_ref, tags, quarter_year, quarter, sprint,
                source_tool, follows_tool_call,
            ]
            if has_private:
                cols += ", is_private"
                vals += ", %s"
                params.append(is_private)
            if has_sens:
                cols += ", sensitivity"
                vals += ", %s"
                params.append(sensitivity)
            # Status and created_by (migration 028 — team sharing)
            if _has_status(self.db):
                cols += ", status"
                vals += ", %s"
                params.append(status)
                if created_by is not None:
                    cols += ", created_by"
                    vals += ", %s"
                    params.append(created_by)
        else:
            cols = (
                "mind_id, content, summary, memory_type, confidence, "
                "source_type, source_ref, tags, quarter_year, quarter, sprint, "
                "source_tool, follows_tool_call"
            )
            vals = "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s"
            params = [
                mind_id, content, summary, memory_type, confidence,
                source_type, source_ref, tags, quarter_year, quarter, sprint,
                source_tool, follows_tool_call,
            ]
            if has_private:
                cols += ", is_private"
                vals += ", %s"
                params.append(is_private)
            if has_sens:
                cols += ", sensitivity"
                vals += ", %s"
                params.append(sensitivity)
            # Status and created_by (migration 028 — team sharing)
            if _has_status(self.db):
                cols += ", status"
                vals += ", %s"
                params.append(status)
                if created_by is not None:
                    cols += ", created_by"
                    vals += ", %s"
                    params.append(created_by)

        if raw_document_id is not None and _has_raw_document_id(self.db):
            cols += ", raw_document_id"
            vals += ", %s::uuid"
            params.append(raw_document_id)

        try:
            row = self.db.execute_returning(
                f"INSERT INTO memories ({cols}) VALUES ({vals}) RETURNING id",
                params,
            )
        except Exception as db_error:
            import psycopg2
            if _skip_enqueue or not isinstance(db_error, (psycopg2.OperationalError, psycopg2.InterfaceError)):
                raise
            from coppermind_cmo import pending_queue
            payload = {
                "mind_id": mind_id,
                "content": content,
                "memory_type": memory_type,
                "summary": summary,
                "embedding": embedding,
                "confidence": confidence,
                "source_type": source_type,
                "source_ref": source_ref,
                "tags": tags,
                "is_private": is_private,
                "sensitivity": sensitivity,
            }
            queued = pending_queue.enqueue(payload)
            if queued:
                logger.info(f"Memory enqueued locally after DB failure: {db_error}")
                return {
                    "id": "pending",
                    "status": "queued_locally",
                    "message": "Memory saved locally. It will sync next time you start a new conversation.",
                    "pending_file": queued,
                }
            raise
        if row is None:
            return None

        return {
            "id": str(row[0]),
            "mind_id": mind_id,
            "content": content,
            "summary": summary,
            "memory_type": memory_type,
        }

    def search(
        self,
        mind_id: str,
        query_embedding: list[float],
        memory_type: str | None = None,
        limit: int = 50,
        similarity_threshold: float = 0.3,
        include_private: bool = True,
        access_filter_sql: str = "",
        access_filter_params: list | None = None,
    ) -> list[dict]:
        """Vector similarity search on memories WHERE mind_id AND is_current.

        Uses cosine distance via pgvector (``<=>`` operator).
        Returns results ordered by similarity descending.
        """
        has_private = _has_is_private(self.db)
        private_col = ", is_private" if has_private else ""

        sql = (
            "WITH q AS (SELECT %s::vector AS qv) "
            "SELECT id, content, summary, memory_type, confidence, "
            "1 - (embedding <=> q.qv) AS similarity, "
            f"tags, source_type, created_at{private_col} "
            "FROM memories, q "
            "WHERE mind_id = %s AND is_current = true AND embedding IS NOT NULL "
            "AND 1 - (embedding <=> q.qv) >= %s "
        )
        params: list[Any] = [json.dumps(query_embedding), mind_id, similarity_threshold]

        if memory_type:
            sql += "AND memory_type = %s "
            params.append(memory_type)

        if not include_private and has_private:
            sql += "AND (is_private = false OR is_private IS NULL) "

        if access_filter_sql:
            sql += f"{access_filter_sql} "
            if access_filter_params:
                params.extend(access_filter_params)

        sql += "ORDER BY embedding <=> q.qv ASC LIMIT %s"
        params.append(limit)

        rows = self.db.fetch_all(sql, params)

        return [
            {
                "memory_id": str(r[0]),
                "content": r[1],
                "summary": r[2],
                "memory_type": r[3],
                "confidence": float(r[4]),
                "similarity": round(float(r[5]), 4),
                "tags": r[6] if r[6] else [],
                "source_type": r[7],
                "created_at": r[8].isoformat() if r[8] else None,
                **({"is_private": bool(r[9])} if has_private else {}),
            }
            for r in rows
        ]

    def keyword_search(
        self,
        mind_id: str,
        query: str,
        memory_type: str | None = None,
        limit: int = 50,
        include_private: bool = True,
        access_filter_sql: str = "",
        access_filter_params: list | None = None,
    ) -> list[dict]:
        """Fallback text search using ILIKE on content and summary columns.

        Searches for each word independently (AND logic). Returns results
        ordered by created_at descending.
        """
        words = query.strip().split()
        if not words:
            return []

        from coppermind_cmo.parsing import escape_like
        escaped = []
        for w in words:
            escaped.append(f"%{escape_like(w)}%")

        conditions = []
        params: list[Any] = [mind_id]

        for pattern in escaped:
            conditions.append("(content ILIKE %s OR summary ILIKE %s)")
            params.extend([pattern, pattern])

        where_clause = " AND ".join(conditions)

        sql = (
            "SELECT id, content, summary, memory_type, confidence, "
            "tags, source_type, created_at "
            "FROM memories "
            f"WHERE mind_id = %s AND is_current = true AND ({where_clause}) "
        )

        if memory_type:
            sql += "AND memory_type = %s "
            params.append(memory_type)

        if not include_private and _has_is_private(self.db):
            sql += "AND (is_private = false OR is_private IS NULL) "

        if access_filter_sql:
            sql += f"{access_filter_sql} "
            if access_filter_params:
                params.extend(access_filter_params)

        sql += "ORDER BY created_at DESC LIMIT %s"
        params.append(limit)

        rows = self.db.fetch_all(sql, params)

        return [
            {
                "memory_id": str(r[0]),
                "content": r[1],
                "summary": r[2],
                "memory_type": r[3],
                "confidence": float(r[4]),
                "similarity": 0.0,
                "tags": r[5] if r[5] else [],
                "source_type": r[6],
                "created_at": r[7].isoformat() if r[7] else None,
            }
            for r in rows
        ]

    def hide(self, mind_id: str, memory_id: str) -> bool:
        """Set is_current=false for a memory. Returns True if the memory existed.

        Enforces client isolation: the memory must belong to the given mind_id.
        """
        row = self.db.fetch_one(
            "SELECT id FROM memories WHERE id = %s AND mind_id = %s",
            [memory_id, mind_id],
        )
        if not row:
            return False

        self.db.execute(
            "UPDATE memories SET is_current = false WHERE id = %s AND mind_id = %s",
            [memory_id, mind_id],
        )
        return True

    def get_by_id(self, mind_id: str, memory_id: str) -> dict | None:
        """Fetch a single memory by id, scoped to mind_id. Returns None if not found."""
        row = self.db.fetch_one(
            "SELECT id, content, summary, memory_type, confidence, "
            "tags, source_type, created_at, is_current "
            "FROM memories WHERE id = %s AND mind_id = %s",
            [memory_id, mind_id],
        )
        if not row:
            return None

        return {
            "memory_id": str(row[0]),
            "content": row[1],
            "summary": row[2],
            "memory_type": row[3],
            "confidence": float(row[4]),
            "tags": row[5] if row[5] else [],
            "source_type": row[6],
            "created_at": row[7].isoformat() if row[7] else None,
            "is_current": row[8],
        }

    def get_recent(
        self,
        mind_id: str,
        limit: int = 10,
        memory_type: str | None = None,
        include_private: bool = True,
    ) -> list[dict]:
        """Fetch the most recent current memories for a mind, ordered by created_at DESC.

        Used by type-balanced retrieval and backfill in intelligence tools.
        """
        has_private = _has_is_private(self.db)
        privacy_filter = ""
        if not include_private and has_private:
            privacy_filter = "AND (is_private = false OR is_private IS NULL) "

        sql = (
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint "
            "FROM memories "
            f"WHERE mind_id = %s AND is_current = true {privacy_filter}"
        )
        params: list[Any] = [mind_id]

        if memory_type:
            sql += "AND memory_type = %s "
            params.append(memory_type)

        sql += "ORDER BY created_at DESC LIMIT %s"
        params.append(limit)

        rows = self.db.fetch_all(sql, params)

        return [
            {
                "id": str(r[0]),
                "content": r[1],
                "summary": r[2],
                "memory_type": r[3],
                "created_at": r[4],
                "embedding": r[5],
                "quarter_year": r[6],
                "quarter": r[7],
                "sprint": r[8],
            }
            for r in rows
        ]

    def find_similar(
        self,
        mind_id: str,
        embedding: list[float],
        threshold: float = 0.85,
        limit: int = 5,
        is_private: bool = False,
    ) -> list[dict]:
        """Find memories similar to the given embedding for dedup/reconsolidation.

        Returns matches above the threshold, ordered by similarity descending.
        When the is_private column exists, only matches memories with the same
        privacy level to prevent cross-boundary reconsolidation.
        """
        has_private = _has_is_private(self.db)
        privacy_filter = ""
        params: list[Any] = [json.dumps(embedding), mind_id, threshold]
        if has_private:
            privacy_filter = "AND (is_private = %s) "
            params.append(is_private)

        rows = self.db.fetch_all(
            "WITH q AS (SELECT %s::vector AS qv) "
            "SELECT id, content, summary, memory_type, "
            "1 - (embedding <=> q.qv) AS similarity "
            "FROM memories, q "
            "WHERE mind_id = %s AND is_current = true AND embedding IS NOT NULL "
            "AND 1 - (embedding <=> q.qv) >= %s "
            f"{privacy_filter}"
            "ORDER BY embedding <=> q.qv ASC "
            f"LIMIT {limit}",
            params,
        )

        return [
            {
                "memory_id": str(r[0]),
                "content": r[1],
                "summary": r[2],
                "memory_type": r[3],
                "similarity": float(r[4]),
            }
            for r in rows
        ]

    def update_content(
        self,
        mind_id: str,
        memory_id: str,
        content: str,
        summary: str,
        embedding: list[float] | None = None,
        quarter_year: int | None = None,
        quarter: int | None = None,
        sprint: int | None = None,
        is_private: bool = False,
        follows_tool_call: str | None = None,
    ) -> None:
        """Update an existing memory's content, summary, and optionally embedding.

        Used during reconsolidation. Enforces mind_id isolation.
        """
        has_private = _has_is_private(self.db)

        if embedding is not None:
            private_set = ", is_private = %s" if has_private else ""
            sql = (
                "UPDATE memories SET content = %s, summary = %s, "
                "embedding = %s::vector, "
                "quarter_year = %s, quarter = %s, sprint = %s, "
                f"follows_tool_call = %s{private_set} "
                "WHERE id = %s AND mind_id = %s"
            )
            params: list[Any] = [
                content, summary, json.dumps(embedding),
                quarter_year, quarter, sprint, follows_tool_call,
            ]
            if has_private:
                params.append(is_private)
            params.extend([memory_id, mind_id])
            self.db.execute(sql, params)
        else:
            private_set = ", is_private = %s" if has_private else ""
            sql = (
                "UPDATE memories SET content = %s, summary = %s, "
                "quarter_year = %s, quarter = %s, sprint = %s, "
                f"follows_tool_call = %s{private_set} "
                "WHERE id = %s AND mind_id = %s"
            )
            params = [
                content, summary,
                quarter_year, quarter, sprint, follows_tool_call,
            ]
            if has_private:
                params.append(is_private)
            params.extend([memory_id, mind_id])
            self.db.execute(sql, params)

    def get_distinct_types(self, mind_id: str, include_private: bool = True) -> list[str]:
        """Return the list of distinct memory_type values for current memories in a mind.

        Used by type-balanced retrieval.
        """
        has_private = _has_is_private(self.db)
        privacy_filter = ""
        if not include_private and has_private:
            privacy_filter = "AND (is_private = false OR is_private IS NULL) "

        rows = self.db.fetch_all(
            "SELECT DISTINCT memory_type FROM memories "
            f"WHERE mind_id = %s AND is_current = true {privacy_filter}",
            [mind_id],
        )
        return [r[0] for r in rows]

    def get_by_tag(
        self,
        mind_id: str,
        tag: str,
        include_private: bool = True,
    ) -> list[dict]:
        """Fetch all current memories with a specific tag (e.g. 'agenda').

        Returns rows with embedding and quarter fields for use in meeting prep.
        """
        has_private = _has_is_private(self.db)
        privacy_filter = ""
        if not include_private and has_private:
            privacy_filter = "AND (is_private = false OR is_private IS NULL) "

        rows = self.db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint "
            "FROM memories "
            f"WHERE mind_id = %s AND is_current = true AND %s = ANY(tags) {privacy_filter}"
            "ORDER BY created_at DESC",
            [mind_id, tag],
        )

        return [
            {
                "id": str(r[0]),
                "content": r[1],
                "summary": r[2],
                "memory_type": r[3],
                "created_at": r[4],
                "embedding": r[5],
                "quarter_year": r[6],
                "quarter": r[7],
                "sprint": r[8],
            }
            for r in rows
        ]

    def get_by_type_for_quarter(
        self,
        mind_id: str,
        memory_type: str,
        year: int,
        quarter: int,
        prev_year: int | None = None,
        prev_quarter: int | None = None,
        limit: int = 10,
        include_private: bool = True,
    ) -> list[dict]:
        """Fetch memories of a specific type for the current and optionally previous quarter.

        Used to retrieve commitments for meeting prep. Includes is_completed
        when that column exists.
        """
        has_private = _has_is_private(self.db)
        has_completed = _has_is_completed(self.db)
        privacy_filter = ""
        if not include_private and has_private:
            privacy_filter = "AND (is_private = false OR is_private IS NULL) "

        completed_col = ", is_completed" if has_completed else ""

        if prev_year is not None and prev_quarter is not None:
            sql = (
                "SELECT id, content, summary, memory_type, created_at, embedding, "
                f"quarter_year, quarter, sprint{completed_col} "
                "FROM memories "
                "WHERE mind_id = %s AND is_current = true "
                f"AND memory_type = %s "
                f"AND ((quarter_year = %s AND quarter = %s) OR (quarter_year = %s AND quarter = %s)) {privacy_filter}"
                "ORDER BY created_at DESC LIMIT %s"
            )
            params: list[Any] = [mind_id, memory_type, year, quarter, prev_year, prev_quarter, limit]
        else:
            sql = (
                "SELECT id, content, summary, memory_type, created_at, embedding, "
                f"quarter_year, quarter, sprint{completed_col} "
                "FROM memories "
                f"WHERE mind_id = %s AND is_current = true AND memory_type = %s {privacy_filter}"
                "ORDER BY created_at DESC LIMIT %s"
            )
            params = [mind_id, memory_type, limit]

        rows = self.db.fetch_all(sql, params)

        results = []
        for r in rows:
            entry: dict[str, Any] = {
                "id": str(r[0]),
                "content": r[1],
                "summary": r[2],
                "memory_type": r[3],
                "created_at": r[4],
                "embedding": r[5],
                "quarter_year": r[6],
                "quarter": r[7],
                "sprint": r[8],
            }
            if has_completed and len(r) > 9:
                entry["is_completed"] = bool(r[9])
            results.append(entry)

        return results

    def get_excluding_ids(
        self,
        mind_id: str,
        exclude_ids: list[str],
        limit: int = 10,
        include_private: bool = True,
    ) -> list[dict]:
        """Fetch recent current memories excluding a set of IDs.

        Used for backfill/fill slots in type-balanced and meeting prep retrieval.
        """
        has_private = _has_is_private(self.db)
        privacy_filter = ""
        if not include_private and has_private:
            privacy_filter = "AND (is_private = false OR is_private IS NULL) "

        rows = self.db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint "
            "FROM memories "
            f"WHERE mind_id = %s AND is_current = true AND id != ALL(%s::uuid[]) {privacy_filter}"
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, exclude_ids, limit],
        )

        return [
            {
                "id": str(r[0]),
                "content": r[1],
                "summary": r[2],
                "memory_type": r[3],
                "created_at": r[4],
                "embedding": r[5],
                "quarter_year": r[6],
                "quarter": r[7],
                "sprint": r[8],
            }
            for r in rows
        ]

    def semantic_search_for_type(
        self,
        mind_id: str,
        query_embedding: list[float],
        similarity_threshold: float = 0.3,
        limit: int = 5,
        include_private: bool = True,
    ) -> list[dict]:
        """Semantic search returning rows with embedding and quarter fields.

        Used by meeting prep topic-driven search and commitment matching.
        Returns the raw row structure needed by intelligence tools.
        """
        has_private = _has_is_private(self.db)
        privacy_filter = ""
        if not include_private and has_private:
            privacy_filter = "AND (is_private = false OR is_private IS NULL) "

        emb_str = "[" + ",".join(str(x) for x in query_embedding) + "]"
        rows = self.db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint, "
            "1 - (embedding <=> %s::vector) as similarity "
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true "
            "AND embedding IS NOT NULL "
            f"AND 1 - (embedding <=> %s::vector) > %s {privacy_filter}"
            "ORDER BY similarity DESC LIMIT %s",
            [emb_str, mind_id, emb_str, similarity_threshold, limit],
        )

        return [
            {
                "id": str(r[0]),
                "content": r[1],
                "summary": r[2],
                "memory_type": r[3],
                "created_at": r[4],
                "embedding": r[5],
                "quarter_year": r[6],
                "quarter": r[7],
                "sprint": r[8],
                "similarity": float(r[9]),
            }
            for r in rows
        ]

    def count_current(self, mind_id: str) -> int:
        """Count of current (non-hidden) memories for a mind."""
        row = self.db.fetch_one(
            "SELECT COUNT(*) FROM memories WHERE mind_id = %s AND is_current = true",
            [mind_id],
        )
        return row[0] if row else 0

    def mark_completed(self, mind_id: str, memory_id: str) -> None:
        """Mark a commitment memory as completed (is_completed = true)."""
        self.db.execute(
            "UPDATE memories SET is_completed = true WHERE id = %s AND mind_id = %s",
            [memory_id, mind_id],
        )

    # ===================================================================
    # Mind operations
    # ===================================================================

    def get_mind(self, mind_id: str, customer_id: str | None = None) -> dict | None:
        """Fetch a mind by id, with optional customer_id access check.

        When customer_id is provided, verifies the customer owns the mind
        or has an explicit access mapping via customer_mind_access.
        Returns None if the mind does not exist or access is denied.
        """
        has_internal = _has_is_internal(self.db)

        if customer_id:
            # Verify access: owner or explicit mapping
            access_row = self.db.fetch_one(
                "SELECT 1 FROM client_minds WHERE id = %s AND customer_id = %s",
                [mind_id, customer_id],
            )
            if not access_row:
                access_row = self.db.fetch_one(
                    "SELECT 1 FROM customer_mind_access WHERE mind_id = %s AND customer_id = %s",
                    [mind_id, customer_id],
                )
            if not access_row:
                return None

        if has_internal:
            row = self.db.fetch_one(
                "SELECT id, name, slug, archived_at, is_internal, cadence, "
                "company_info, local_path, customer_id "
                "FROM client_minds WHERE id = %s",
                [mind_id],
            )
        else:
            row = self.db.fetch_one(
                "SELECT id, name, slug, archived_at, cadence, "
                "company_info, local_path, customer_id "
                "FROM client_minds WHERE id = %s",
                [mind_id],
            )

        if not row:
            return None

        if has_internal:
            return {
                "id": str(row[0]),
                "name": row[1],
                "slug": row[2],
                "archived_at": row[3],
                "is_internal": row[4],
                "cadence": parse_jsonb(row[5]),
                "company_info": parse_jsonb(row[6]),
                "local_path": row[7],
                "customer_id": row[8],
            }
        else:
            return {
                "id": str(row[0]),
                "name": row[1],
                "slug": row[2],
                "archived_at": row[3],
                "is_internal": False,
                "cadence": parse_jsonb(row[4]),
                "company_info": parse_jsonb(row[5]),
                "local_path": row[6],
                "customer_id": row[7],
            }

    def find_mind_by_name(
        self,
        name: str,
        customer_id: str,
    ) -> dict | None:
        """Find a mind by name or slug, scoped to a customer's access.

        Matches case-insensitively on name or exactly on slug.
        Checks ownership (customer_id on client_minds) and explicit access
        mappings (customer_mind_access).
        """
        import re
        slug = name.lower()
        slug = re.sub(r'[^a-z0-9]+', '-', slug)
        slug = slug.strip('-')
        slug = re.sub(r'-+', '-', slug)

        has_internal = _has_is_internal(self.db)

        access_filter = (
            "AND (cm.customer_id = %s OR EXISTS ("
            "    SELECT 1 FROM customer_mind_access cma "
            "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s"
            "))"
        )
        access_params = [customer_id, customer_id]

        if has_internal:
            row = self.db.fetch_one(
                "SELECT cm.id, cm.name, cm.slug, cm.archived_at, cm.is_internal, "
                "cm.cadence, cm.company_info, cm.local_path "
                "FROM client_minds cm "
                "WHERE (LOWER(cm.name) = LOWER(%s) OR cm.slug = %s) "
                + access_filter,
                [name, slug] + access_params,
            )
        else:
            row = self.db.fetch_one(
                "SELECT cm.id, cm.name, cm.slug, cm.archived_at, "
                "cm.cadence, cm.company_info, cm.local_path "
                "FROM client_minds cm "
                "WHERE (LOWER(cm.name) = LOWER(%s) OR cm.slug = %s) "
                + access_filter,
                [name, slug] + access_params,
            )

        if not row:
            return None

        if has_internal:
            return {
                "id": str(row[0]),
                "name": row[1],
                "slug": row[2],
                "archived_at": row[3],
                "is_internal": row[4],
                "cadence": parse_jsonb(row[5]),
                "company_info": parse_jsonb(row[6]),
                "local_path": row[7],
            }
        else:
            return {
                "id": str(row[0]),
                "name": row[1],
                "slug": row[2],
                "archived_at": row[3],
                "is_internal": False,
                "cadence": parse_jsonb(row[4]),
                "company_info": parse_jsonb(row[5]),
                "local_path": row[6],
            }

    def create_mind(
        self,
        name: str,
        slug: str,
        customer_id: str,
        is_internal: bool = False,
    ) -> dict:
        """INSERT a new mind and create the owner access mapping.

        Returns the new mind as a dict with id, name, slug.
        Raises on unique constraint violations.
        """
        has_internal = _has_is_internal(self.db)

        if has_internal:
            new_row = self.db.execute_returning(
                "INSERT INTO client_minds (name, slug, customer_id, is_internal) "
                "VALUES (%s, %s, %s, %s) RETURNING id, name, slug",
                [name, slug, customer_id, is_internal],
            )
        else:
            new_row = self.db.execute_returning(
                "INSERT INTO client_minds (name, slug, customer_id) "
                "VALUES (%s, %s, %s) RETURNING id, name, slug",
                [name, slug, customer_id],
            )

        mind_id = str(new_row[0])

        # Create access mapping for the owner
        self.db.execute(
            "INSERT INTO customer_mind_access (customer_id, mind_id, access_level) "
            "VALUES (%s, %s, 'owner') ON CONFLICT (customer_id, mind_id) DO NOTHING",
            [customer_id, mind_id],
        )

        return {
            "id": mind_id,
            "name": new_row[1],
            "slug": new_row[2],
        }

    def slug_exists(self, slug: str) -> bool:
        """Check if a slug already exists in client_minds."""
        row = self.db.fetch_one(
            "SELECT 1 FROM client_minds WHERE slug = %s", [slug]
        )
        return row is not None

    def list_minds(
        self,
        customer_id: str,
        limit: int = 50,
        offset: int = 0,
        include_internal: bool = False,
        include_archived: bool = False,
    ) -> list[dict]:
        """List minds accessible to a customer with memory counts.

        Joins against customer_mind_access for authorization.
        Orders by updated_at descending.
        """
        if not customer_id:
            return []

        where_clauses = [
            "(cm.customer_id = %s OR EXISTS ("
            "    SELECT 1 FROM customer_mind_access cma "
            "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s"
            "))"
        ]
        params: list[Any] = [customer_id, customer_id]

        if not include_internal and _has_is_internal(self.db):
            where_clauses.append("cm.is_internal = false")

        # include_archived is available for future use; currently client_minds
        # are returned regardless of archived_at (the caller filters).

        sql = (
            "SELECT cm.id, cm.name, cm.slug, cm.archived_at, "
            "COUNT(m.id) AS memory_count, cm.created_at, cm.updated_at "
            "FROM client_minds cm "
            "LEFT JOIN memories m ON m.mind_id = cm.id AND m.is_current = true "
            "WHERE " + " AND ".join(where_clauses) + " "
            "GROUP BY cm.id "
            "ORDER BY cm.updated_at DESC "
            "LIMIT %s OFFSET %s"
        )
        params.extend([limit, offset])

        rows = self.db.fetch_all(sql, params)

        return [
            {
                "mind_id": str(r[0]),
                "name": r[1],
                "slug": r[2],
                "archived_at": r[3].isoformat() if r[3] else None,
                "memory_count": r[4],
                "created_at": r[5].isoformat() if r[5] else None,
                "updated_at": r[6].isoformat() if r[6] else None,
            }
            for r in rows
        ]

    def update_mind(self, mind_id: str, **fields: Any) -> dict | None:
        """Update a mind using JSONB merge for dict fields and direct SET for scalars.

        Supported fields: cadence (dict), company_info (dict), local_path (str).
        Returns the updated cadence, company_info, local_path or None on failure.
        """
        set_clauses = []
        params: list[Any] = []
        updated_fields = []

        if "cadence" in fields and fields["cadence"]:
            set_clauses.append("cadence = COALESCE(cadence, '{}'::jsonb) || %s::jsonb")
            params.append(json.dumps(fields["cadence"]))
            updated_fields.append("cadence")

        if "company_info" in fields and fields["company_info"]:
            set_clauses.append("company_info = COALESCE(company_info, '{}'::jsonb) || %s::jsonb")
            params.append(json.dumps(fields["company_info"]))
            updated_fields.append("company_info")

        if "local_path" in fields and fields["local_path"] is not None:
            set_clauses.append("local_path = %s")
            params.append(fields["local_path"])
            updated_fields.append("local_path")

        if not set_clauses:
            return None

        set_clauses.append("updated_at = now()")
        params.append(mind_id)

        row = self.db.execute_returning(
            "UPDATE client_minds "
            "SET " + ", ".join(set_clauses) + " "
            "WHERE id = %s "
            "RETURNING cadence, company_info, local_path",
            params,
        )

        if not row:
            return None

        return {
            "cadence": parse_jsonb(row[0]),
            "company_info": parse_jsonb(row[1]),
            "local_path": row[2],
            "updated_fields": updated_fields,
        }

    def get_mind_cadence(self, mind_id: str) -> dict:
        """Fetch a mind's cadence JSONB. Returns {} if not set.

        Extracted from utils.get_mind_cadence — same SQL.
        """
        row = self.db.fetch_one(
            "SELECT cadence FROM client_minds WHERE id = %s",
            [mind_id],
        )
        if row and row[0]:
            return row[0] if isinstance(row[0], dict) else {}
        return {}

    def get_mind_context(self, mind_id: str) -> dict | None:
        """Fetch full mind context for meeting prep / intelligence tools.

        Returns name, brand DNA fields, cadence, and company_info.
        Used by prep_meeting to build structured briefs.
        """
        row = self.db.fetch_one(
            "SELECT name, brand_voice, brand_positioning, approved_messaging, "
            "stakeholders, content_themes, cadence, company_info "
            "FROM client_minds WHERE id = %s",
            [mind_id],
        )
        if not row:
            return None

        return {
            "name": row[0],
            "brand_voice": parse_jsonb(row[1]),
            "brand_positioning": parse_jsonb(row[2]),
            "approved_messaging": parse_jsonb(row[3]),
            "stakeholders": parse_jsonb(row[4]) if row[4] else [],
            "content_themes": row[5] if row[5] else [],
            "cadence": parse_jsonb(row[6]) if row[6] else {},
            "company_info": parse_jsonb(row[7]) if row[7] else {},
        }

    def verify_mind_access(self, mind_id: str, customer_id: str | None) -> bool:
        """Verify the customer has access to this mind. Returns True if allowed.

        Default-deny: customer_id must be set. The customer must own the mind
        OR have an explicit access mapping in customer_mind_access.
        """
        if not customer_id:
            return False
        row = self.db.fetch_one(
            "SELECT 1 FROM client_minds WHERE id = %s AND customer_id = %s",
            [mind_id, customer_id],
        )
        if row:
            return True
        row = self.db.fetch_one(
            "SELECT 1 FROM customer_mind_access WHERE mind_id = %s AND customer_id = %s",
            [mind_id, customer_id],
        )
        return row is not None

    # ===================================================================
    # Ingest tracking
    # ===================================================================

    def check_content_hash(self, mind_id: str, content_hash: str) -> bool:
        """Check if a content hash already exists in ingest_log for this mind.

        Used for dedup: returns True if the chunk has already been processed.
        """
        row = self.db.fetch_one(
            "SELECT id FROM ingest_log "
            "WHERE mind_id = %s AND content_hash = %s",
            [mind_id, content_hash],
        )
        return row is not None

    def log_ingest(
        self,
        mind_id: str,
        source_id: str,
        content_hash: str,
        raw_content: str,
        memories_extracted: int = 0,
    ) -> None:
        """Record a processed chunk in ingest_log.

        Uses ON CONFLICT to handle re-processing (refresh) gracefully.
        """
        self.db.execute(
            "INSERT INTO ingest_log (source_id, mind_id, raw_content, content_hash, "
            "processed, memories_extracted) "
            "VALUES (%s, %s, %s, %s, true, %s) "
            "ON CONFLICT (mind_id, content_hash) DO UPDATE SET "
            "processed = true, memories_extracted = %s, refreshed_at = now()",
            [source_id, mind_id, raw_content, content_hash,
             memories_extracted, memories_extracted],
        )

    def get_or_create_ingest_source(
        self,
        mind_id: str,
        source_type: str,
        source_ref: str,
    ) -> str:
        """Get or create an ingest_sources row. Returns source_id.

        Matches by mind_id, ingest_type, and source_ref in config JSONB.
        """
        row = self.db.fetch_one(
            "SELECT id FROM ingest_sources "
            "WHERE mind_id = %s AND ingest_type = %s AND config->>'source_ref' = %s",
            [mind_id, source_type, source_ref],
        )
        if row:
            return str(row[0])

        row = self.db.execute_returning(
            "INSERT INTO ingest_sources (mind_id, ingest_type, config) "
            "VALUES (%s, %s, %s) RETURNING id",
            [mind_id, source_type, json.dumps({"source_ref": source_ref})],
        )
        return str(row[0])
