"""Email poller daemon for Coppermind CMO.

Polls Gmail for new emails matching client contacts, attributes them
to the correct client minds, and ingests them via store_memory_core.

Uses historyId-based incremental sync for precision. Modeled on
folder_watch.py's proven polling daemon pattern.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from pathlib import Path
from typing import Any

import httpx

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("email_poller")

# --- Constants ---

DEFAULT_POLL_INTERVAL = 900  # 15 minutes
MAX_MESSAGES_PER_CYCLE = 20
MAX_THREAD_MESSAGES = 10
MAX_CONCURRENT_CUSTOMERS = 5
MIN_CONTENT_LENGTH = 50

# Circuit breaker thresholds
MAX_CONSECUTIVE_FAILURES = 6
BACKOFF_SCHEDULE = {0: 0, 1: 0, 2: 0, 3: 1, 4: 2, 5: 4}  # failures -> skip cycles

# Email addresses to skip during contact auto-population
SKIP_PREFIXES = frozenset({
    "no-reply", "noreply", "do-not-reply", "mailer-daemon",
    "notifications", "alerts", "support", "info",
})
SKIP_TLDS = frozenset({".internal", ".local", ".localhost"})

# Auto-skip email headers/MIME types
AUTO_SKIP_HEADERS = {
    "Auto-Submitted": None,  # any value = auto-reply
    "List-Unsubscribe": None,  # newsletter/marketing
}

# Status file
_STATUS_DIR = Path.home() / ".coppermind"
_STATUS_FILE = _STATUS_DIR / "email_poller_status.json"

# Gmail API base
GMAIL_API = "https://gmail.googleapis.com/gmail/v1/users/me"

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")


class EmailPoller:
    """Polls Gmail for client-related emails and ingests them as memories."""

    def __init__(self, config: Config, db: Database):
        self.config = config
        self.db = db
        self._running = False

    # ------------------------------------------------------------------
    # Gmail API helpers
    # ------------------------------------------------------------------

    async def _get_access_token(self, client: httpx.AsyncClient, customer_id: str) -> str | None:
        """Get a short-lived Gmail access token from the gateway."""
        try:
            resp = await client.post(
                f"{self.config.gateway_url.rstrip('/')}/v1/auth/google/token",
                headers={"Authorization": f"Bearer {self.config.poller_service_key}"},
                json={"customer_id": customer_id},
                timeout=10.0,
            )
            if resp.status_code == 200:
                return resp.json()["access_token"]
            logger.warn(
                "Token exchange failed",
                customer_id=customer_id,
                status=resp.status_code,
            )
            return None
        except Exception as e:
            logger.error("Token exchange error", customer_id=customer_id, error=str(e))
            return None

    async def _gmail_get(
        self,
        client: httpx.AsyncClient,
        access_token: str,
        path: str,
        params: dict[str, str] | None = None,
    ) -> dict[str, Any] | None:
        """Make a GET request to the Gmail API."""
        try:
            resp = await client.get(
                f"{GMAIL_API}/{path}",
                headers={"Authorization": f"Bearer {access_token}"},
                params=params or {},
                timeout=15.0,
            )
            if resp.status_code == 200:
                return resp.json()
            if resp.status_code == 404:
                return None
            logger.warn("Gmail API error", path=path, status=resp.status_code)
            return None
        except Exception as e:
            logger.error("Gmail API request failed", path=path, error=str(e))
            return None

    # ------------------------------------------------------------------
    # Known contacts builder
    # ------------------------------------------------------------------

    def _build_known_contacts(self, minds: list[dict[str, Any]]) -> tuple[set[str], set[str]]:
        """Build sets of known domains and email addresses from client minds.

        Returns (domains, emails) — both lowercased.
        """
        domains: set[str] = set()
        emails: set[str] = set()

        for mind in minds:
            # Domain from company_info
            company_info = mind.get("company_info") or {}
            domain = company_info.get("domain")
            if domain:
                domains.add(domain.lower())

            # Email contacts
            email_contacts = mind.get("email_contacts") or {}
            for addr in email_contacts:
                emails.add(addr.lower())

        return domains, emails

    def _matches_known_contacts(
        self,
        from_addr: str,
        to_addrs: list[str],
        cc_addrs: list[str],
        domains: set[str],
        emails: set[str],
    ) -> bool:
        """Check if any address in the email matches known contacts."""
        all_addrs = [from_addr] + to_addrs + cc_addrs
        for addr in all_addrs:
            addr_lower = addr.lower()
            if addr_lower in emails:
                return True
            # Check domain
            parts = addr_lower.split("@")
            if len(parts) == 2 and parts[1] in domains:
                return True
        return False

    # ------------------------------------------------------------------
    # Email-to-mind attribution
    # ------------------------------------------------------------------

    def _attribute_email(
        self,
        from_addr: str,
        to_addrs: list[str],
        cc_addrs: list[str],
        minds: list[dict[str, Any]],
    ) -> list[str]:
        """Return list of mind_ids that match this email's participants.

        Returns empty list if no match, single item for clean match,
        multiple items for multi-match.
        """
        all_addrs = {a.lower() for a in [from_addr] + to_addrs + cc_addrs}
        matched_minds: list[str] = []

        for mind in minds:
            mind_id = str(mind["id"])
            email_contacts = mind.get("email_contacts") or {}
            company_info = mind.get("company_info") or {}
            domain = (company_info.get("domain") or "").lower()
            contact_emails = {k.lower() for k in email_contacts}

            for addr in all_addrs:
                if addr in contact_emails:
                    if mind_id not in matched_minds:
                        matched_minds.append(mind_id)
                    break
                parts = addr.split("@")
                if len(parts) == 2 and domain and parts[1] == domain:
                    if mind_id not in matched_minds:
                        matched_minds.append(mind_id)
                    break

        return matched_minds

    # ------------------------------------------------------------------
    # Email header parsing
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_header(headers: list[dict[str, str]], name: str) -> str:
        """Extract a header value from Gmail message metadata."""
        for h in headers:
            if h.get("name", "").lower() == name.lower():
                return h.get("value", "")
        return ""

    @staticmethod
    def _parse_addresses(header_value: str) -> list[str]:
        """Extract email addresses from a header value like 'Name <email>, ...'."""
        return [m.group(0) for m in EMAIL_RE.finditer(header_value)]

    @staticmethod
    def _should_skip_message(headers: list[dict[str, str]], mime_type: str | None) -> bool:
        """Check auto-skip filters: auto-replies, calendar invites, newsletters."""
        for h in headers:
            name = h.get("name", "").lower()
            if name == "auto-submitted":
                return True
            if name == "list-unsubscribe":
                return True
        if mime_type and "calendar" in mime_type:
            return True
        return False

    # ------------------------------------------------------------------
    # Email content extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_text_from_parts(parts: list[dict[str, Any]] | None) -> str:
        """Recursively extract text/plain from MIME parts."""
        if not parts:
            return ""
        texts: list[str] = []
        for part in parts:
            mime = part.get("mimeType", "")
            if mime == "text/plain":
                body = part.get("body", {})
                data = body.get("data", "")
                if data:
                    import base64
                    try:
                        texts.append(base64.urlsafe_b64decode(data + "==").decode("utf-8", errors="replace"))
                    except Exception:
                        pass
            elif mime.startswith("multipart/"):
                texts.append(EmailPoller._extract_text_from_parts(part.get("parts")))
        return "\n".join(t for t in texts if t)

    @staticmethod
    def _clean_email_body(text: str) -> str:
        """Remove quoted replies, signatures, and disclaimers."""
        lines = text.split("\n")
        cleaned: list[str] = []
        for line in lines:
            # Stop at quoted reply markers
            stripped = line.strip()
            if stripped.startswith(">"):
                continue
            if re.match(r"^On .+ wrote:$", stripped):
                break
            if re.match(r"^-{2,}\s*$", stripped):
                break  # Signature delimiter
            if re.match(r"^_{3,}$", stripped):
                break  # Footer delimiter
            cleaned.append(line)
        return "\n".join(cleaned).strip()

    # ------------------------------------------------------------------
    # Thread processing
    # ------------------------------------------------------------------

    async def _fetch_and_process_thread(
        self,
        client: httpx.AsyncClient,
        access_token: str,
        thread_id: str,
        mind_id: str,
        customer_id: str,
    ) -> int:
        """Fetch a Gmail thread, extract content, and store via store_memory_core.

        Returns number of memories created.
        """
        from coppermind_cmo.tools.memories import store_memory_core

        # Check dedup — skip if thread already ingested AND no new messages
        source_ref = f"gmail:thread:{thread_id}"
        existing = self.db.execute(
            "SELECT id, created_at FROM ingest_log WHERE source_ref = %s AND mind_id = %s LIMIT 1",
            (source_ref, mind_id),
        )

        # Fetch full thread
        thread_data = await self._gmail_get(
            client, access_token,
            f"threads/{thread_id}",
            {"format": "full"},
        )
        if not thread_data:
            return 0

        messages = thread_data.get("messages", [])
        if not messages:
            return 0

        # If already ingested, check if thread has new messages since then
        if existing:
            last_ingested = existing[0].get("created_at")
            if last_ingested and hasattr(last_ingested, 'timestamp'):
                last_ts = last_ingested.timestamp() * 1000  # Gmail uses ms
                newest_msg_ts = max(
                    int(m.get("internalDate", "0")) for m in messages
                )
                if newest_msg_ts <= last_ts:
                    return 0  # No new messages since last ingestion

        # Cap at MAX_THREAD_MESSAGES (most recent)
        if len(messages) > MAX_THREAD_MESSAGES:
            messages = messages[-MAX_THREAD_MESSAGES:]

        # Build extraction context
        subject = ""
        participants: set[str] = set()
        thread_parts: list[str] = []

        for i, msg in enumerate(messages):
            headers = msg.get("payload", {}).get("headers", [])
            msg_subject = self._extract_header(headers, "Subject")
            if not subject and msg_subject:
                subject = msg_subject

            from_addr = self._extract_header(headers, "From")
            date = self._extract_header(headers, "Date")
            participants.update(self._parse_addresses(from_addr))

            # Extract body
            payload = msg.get("payload", {})
            body_text = ""
            if payload.get("parts"):
                body_text = self._extract_text_from_parts(payload["parts"])
            elif payload.get("body", {}).get("data"):
                import base64
                try:
                    body_text = base64.urlsafe_b64decode(
                        payload["body"]["data"] + "=="
                    ).decode("utf-8", errors="replace")
                except Exception:
                    pass

            cleaned = self._clean_email_body(body_text)
            if cleaned:
                thread_parts.append(
                    f"--- Message {i + 1} ({date}) ---\n"
                    f"From: {from_addr}\n{cleaned}"
                )

        if not thread_parts:
            return 0

        full_context = (
            f"Email Thread: {subject} ({len(messages)} messages)\n"
            f"Participants: {', '.join(sorted(participants))}\n\n"
            + "\n\n".join(thread_parts)
        )

        if len(full_context) < MIN_CONTENT_LENGTH:
            return 0

        # Get the active mind name for store_memory_core
        mind_row = self.db.execute(
            "SELECT name FROM client_minds WHERE id = %s", (mind_id,)
        )
        mind_name = mind_row[0]["name"] if mind_row else "Unknown"

        start = time.time()
        try:
            result = store_memory_core(
                content=full_context,
                memory_type=None,  # Let LLM classify
                tags=["email", "auto-ingested"],
                db=self.db,
                config=self.config,
                active_mind=(mind_id, mind_name),
                source_type="email",
                source_ref=source_ref,
            )
            duration_ms = int((time.time() - start) * 1000)
            memories_created = 1 if result.get("memory_id") else 0
            logger.info(
                "email_extraction",
                customer_id=customer_id,
                mind_id=mind_id,
                gmail_thread_id=thread_id,
                memories_created=memories_created,
                duration_ms=duration_ms,
            )
            return memories_created
        except Exception as e:
            logger.error(
                "email_extraction_failed",
                customer_id=customer_id,
                mind_id=mind_id,
                gmail_thread_id=thread_id,
                error=str(e),
            )
            return 0

    # ------------------------------------------------------------------
    # Per-customer polling
    # ------------------------------------------------------------------

    async def _poll_customer(
        self,
        client: httpx.AsyncClient,
        customer_id: str,
    ) -> dict[str, int]:
        """Poll Gmail for one customer. Returns stats dict."""
        stats = {"emails_processed": 0, "memories_created": 0}

        # Get access token
        access_token = await self._get_access_token(client, customer_id)
        if not access_token:
            raise RuntimeError("Failed to get access token")

        # Fetch customer's minds with email_contacts
        minds = self.db.execute(
            "SELECT id, name, email_contacts, company_info "
            "FROM client_minds WHERE customer_id = %s AND archived_at IS NULL",
            (customer_id,),
        )
        if not minds:
            logger.debug("No minds for customer", customer_id=customer_id)
            return stats

        domains, emails = self._build_known_contacts(minds)
        if not domains and not emails:
            logger.debug("No contacts configured", customer_id=customer_id)
            return stats

        logger.info(
            "email_poll_customer_start",
            customer_id=customer_id,
            minds_count=len(minds),
            domains_count=len(domains),
            contacts_count=len(emails),
        )

        # Get last_history_id
        token_row = self.db.execute(
            "SELECT last_history_id FROM customer_google_tokens WHERE customer_id = %s",
            (customer_id,),
        )
        if not token_row or not token_row[0].get("last_history_id"):
            logger.warn("No history_id for customer", customer_id=customer_id)
            return stats

        history_id = token_row[0]["last_history_id"]

        # Incremental sync via history.list
        history_data = await self._gmail_get(
            client, access_token,
            "history",
            {
                "startHistoryId": str(history_id),
                "historyTypes": "messageAdded",
            },
        )

        if history_data is None:
            # 404 = history expired (>30 days). Reset historyId from profile.
            logger.warn("History expired, resetting historyId", customer_id=customer_id)
            profile = await self._gmail_get(client, access_token, "profile")
            if profile and profile.get("historyId"):
                self.db.execute(
                    "UPDATE customer_google_tokens SET last_history_id = %s, updated_at = now() "
                    "WHERE customer_id = %s",
                    (int(profile["historyId"]), customer_id),
                )
            return stats

        new_history_id = history_data.get("historyId", history_id)
        message_ids: list[str] = []

        for record in history_data.get("history", []):
            for added in record.get("messagesAdded", []):
                msg = added.get("message", {})
                msg_id = msg.get("id")
                if msg_id and msg_id not in message_ids:
                    message_ids.append(msg_id)

        logger.info(
            "email_fetch",
            customer_id=customer_id,
            messages_fetched=len(message_ids),
            history_id=new_history_id,
        )

        # Local pre-filter: fetch metadata and match against known contacts
        matched: list[tuple[str, str, list[str]]] = []  # (msg_id, thread_id, mind_ids)

        for msg_id in message_ids[:MAX_MESSAGES_PER_CYCLE * 2]:  # Fetch more metadata than we'll process
            if len(matched) >= MAX_MESSAGES_PER_CYCLE:
                break

            msg_data = await self._gmail_get(
                client, access_token,
                f"messages/{msg_id}",
                {"format": "metadata", "metadataHeaders": "From,To,Cc,Content-Type,Auto-Submitted,List-Unsubscribe"},
            )
            if not msg_data:
                continue

            headers = msg_data.get("payload", {}).get("headers", [])
            mime_type = msg_data.get("payload", {}).get("mimeType")

            # Auto-skip filters
            if self._should_skip_message(headers, mime_type):
                continue

            from_header = self._extract_header(headers, "From")
            to_header = self._extract_header(headers, "To")
            cc_header = self._extract_header(headers, "Cc")

            from_addrs = self._parse_addresses(from_header)
            to_addrs = self._parse_addresses(to_header)
            cc_addrs = self._parse_addresses(cc_header)

            from_addr = from_addrs[0] if from_addrs else ""
            if not from_addr:
                continue

            if not self._matches_known_contacts(from_addr, to_addrs, cc_addrs, domains, emails):
                continue

            # Attribution
            mind_ids = self._attribute_email(from_addr, to_addrs, cc_addrs, minds)
            thread_id = msg_data.get("threadId", msg_id)

            if len(mind_ids) == 0:
                continue
            elif len(mind_ids) == 1:
                matched.append((msg_id, thread_id, mind_ids))
                logger.info(
                    "email_attribution",
                    customer_id=customer_id,
                    gmail_thread_id=thread_id,
                    result="matched",
                    mind_id=mind_ids[0],
                )
            else:
                # Multi-match — log to attribution table
                subject = self._extract_header(headers, "Subject")
                self._log_multi_match(
                    customer_id=customer_id,
                    gmail_message_id=msg_id,
                    gmail_thread_id=thread_id,
                    subject=subject,
                    sender=from_addr,
                    recipients=to_addrs + cc_addrs,
                    candidate_mind_ids=mind_ids,
                )
                logger.info(
                    "email_attribution",
                    customer_id=customer_id,
                    gmail_thread_id=thread_id,
                    result="multi_match",
                    candidate_count=len(mind_ids),
                )

        # Process matched emails (single-mind attribution only)
        for msg_id, thread_id, mind_ids in matched:
            memories = await self._fetch_and_process_thread(
                client, access_token, thread_id, mind_ids[0], customer_id,
            )
            stats["emails_processed"] += 1
            stats["memories_created"] += memories

        # Update polling state
        self.db.execute(
            "UPDATE customer_google_tokens SET last_history_id = %s, "
            "last_poll_at = now(), consecutive_failures = 0, updated_at = now() "
            "WHERE customer_id = %s",
            (new_history_id, customer_id),
        )

        return stats

    def _log_multi_match(
        self,
        customer_id: str,
        gmail_message_id: str,
        gmail_thread_id: str,
        subject: str,
        sender: str,
        recipients: list[str],
        candidate_mind_ids: list[str],
    ) -> None:
        """Log a multi-match email to the attribution log."""
        try:
            self.db.execute(
                "INSERT INTO email_attribution_log "
                "(customer_id, gmail_message_id, gmail_thread_id, subject, sender, recipients, candidate_mind_ids) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s) "
                "ON CONFLICT (gmail_message_id) DO NOTHING",
                (
                    customer_id,
                    gmail_message_id,
                    gmail_thread_id,
                    subject,
                    sender,
                    recipients,
                    candidate_mind_ids,
                ),
            )
        except Exception as e:
            logger.warn("Failed to log multi-match", error=str(e))

    # ------------------------------------------------------------------
    # Main poll cycle
    # ------------------------------------------------------------------

    async def _poll_cycle(self) -> dict[str, Any]:
        """Run one poll cycle across all eligible customers."""
        cycle_stats: dict[str, Any] = {
            "customers_polled": 0,
            "total_emails": 0,
            "total_memories": 0,
        }

        # Fetch eligible customers
        rows = self.db.execute(
            "SELECT customer_id, consecutive_failures FROM customer_google_tokens "
            "WHERE auth_error IS NULL"
        )
        if not rows:
            return cycle_stats

        logger.info("email_poll_started", eligible_customers_count=len(rows))

        # Filter by circuit breaker (time-based backoff)
        eligible: list[str] = []
        for row in rows:
            cid = row["customer_id"]
            failures = row.get("consecutive_failures", 0)
            if failures >= MAX_CONSECUTIVE_FAILURES:
                continue
            skip_cycles = BACKOFF_SCHEDULE.get(failures, 0)
            if skip_cycles > 0:
                # Check if enough time has passed since last attempt
                last_poll = self.db.execute(
                    "SELECT last_poll_at FROM customer_google_tokens WHERE customer_id = %s",
                    (cid,),
                )
                if last_poll and last_poll[0].get("last_poll_at"):
                    from datetime import datetime, timezone
                    last = last_poll[0]["last_poll_at"]
                    if hasattr(last, 'timestamp'):
                        elapsed_seconds = time.time() - last.timestamp()
                    else:
                        elapsed_seconds = 0
                    required_wait = skip_cycles * DEFAULT_POLL_INTERVAL
                    if elapsed_seconds < required_wait:
                        logger.info(
                            "email_poll_circuit_open",
                            customer_id=cid,
                            consecutive_failures=failures,
                            wait_remaining=int(required_wait - elapsed_seconds),
                        )
                        continue
            eligible.append(cid)

        semaphore = asyncio.Semaphore(MAX_CONCURRENT_CUSTOMERS)

        async def poll_with_semaphore(customer_id: str) -> dict[str, int]:
            async with semaphore:
                return await self._poll_customer_safe(customer_id)

        results = await asyncio.gather(
            *[poll_with_semaphore(cid) for cid in eligible],
            return_exceptions=True,
        )

        for result in results:
            if isinstance(result, dict):
                cycle_stats["customers_polled"] += 1
                cycle_stats["total_emails"] += result.get("emails_processed", 0)
                cycle_stats["total_memories"] += result.get("memories_created", 0)

        logger.info(
            "email_poll_done",
            customers_polled=cycle_stats["customers_polled"],
            total_emails=cycle_stats["total_emails"],
            total_memories=cycle_stats["total_memories"],
        )

        return cycle_stats

    async def _poll_customer_safe(self, customer_id: str) -> dict[str, int]:
        """Poll a customer with error handling and circuit breaker updates."""
        async with httpx.AsyncClient() as client:
            try:
                stats = await self._poll_customer(client, customer_id)
                logger.info(
                    "email_poll_customer_done",
                    customer_id=customer_id,
                    emails_processed=stats["emails_processed"],
                    memories_created=stats["memories_created"],
                )
                return stats
            except Exception as e:
                error_type = "transient"
                logger.error(
                    "email_poll_error",
                    customer_id=customer_id,
                    error=str(e),
                    error_type=error_type,
                )
                # Increment failure counter
                try:
                    self.db.execute(
                        "UPDATE customer_google_tokens "
                        "SET consecutive_failures = consecutive_failures + 1, updated_at = now() "
                        "WHERE customer_id = %s",
                        (customer_id,),
                    )
                except Exception:
                    pass
                return {"emails_processed": 0, "memories_created": 0}

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def write_status(self, cycle_stats: dict[str, Any] | None = None) -> None:
        """Write a JSON status file for /cmo-connect status to read."""
        try:
            _STATUS_DIR.mkdir(parents=True, exist_ok=True)
            status: dict[str, Any] = {"timestamp": time.time()}
            if cycle_stats:
                status["last_cycle"] = cycle_stats
            _STATUS_FILE.write_text(json.dumps(status, indent=2))
        except Exception as e:
            logger.warn("Failed to write status file", error=str(e))

    # ------------------------------------------------------------------
    # Daemon entry point
    # ------------------------------------------------------------------

    def run(self, poll_interval: float = DEFAULT_POLL_INTERVAL) -> None:
        """Main polling loop. Runs until the process is killed."""
        logger.info("Email poller starting", poll_interval=poll_interval)
        self._running = True

        while self._running:
            try:
                start = time.time()
                cycle_stats = asyncio.run(self._poll_cycle())
                duration = time.time() - start
                cycle_stats["duration_seconds"] = round(duration, 2)
                self.write_status(cycle_stats)
            except Exception as e:
                logger.error("Email poller cycle failed", error=str(e))

            time.sleep(poll_interval)

    def stop(self) -> None:
        """Signal the poller to stop."""
        self._running = False


# --- Contact auto-population helpers ---


def extract_emails_from_content(content: str) -> list[str]:
    """Extract email addresses from text, filtering out infrastructure addresses."""
    raw_emails = EMAIL_RE.findall(content)
    filtered: list[str] = []
    for email in raw_emails:
        email_lower = email.lower()
        local_part = email_lower.split("@")[0] if "@" in email_lower else ""
        domain = email_lower.split("@")[1] if "@" in email_lower else ""

        # Skip infrastructure prefixes
        if local_part in SKIP_PREFIXES or any(local_part.startswith(p + ".") for p in SKIP_PREFIXES):
            continue

        # Skip non-public TLDs
        if any(domain.endswith(tld) for tld in SKIP_TLDS):
            continue

        filtered.append(email)
    return filtered


def auto_populate_email_contacts(
    db: Database,
    mind_id: str,
    content: str,
) -> int:
    """Extract email addresses from content and add to mind's email_contacts.

    Called as a post-store hook when memory_type == 'stakeholder'.
    Returns number of new contacts added.
    """
    found_emails = extract_emails_from_content(content)
    if not found_emails:
        return 0

    added = 0
    for email in found_emails:
        # Try to extract name from surrounding text
        name = "Unknown"
        # Simple heuristic: look for "Name <email>" pattern
        pattern = rf"([\w\s]+?)\s*<?{re.escape(email)}>?"
        match = re.search(pattern, content)
        if match:
            candidate = match.group(1).strip()
            if candidate and len(candidate) < 60:
                name = candidate

        try:
            # Check if email already exists before writing
            existing = db.execute(
                "SELECT 1 FROM client_minds WHERE id = %s AND (COALESCE(email_contacts, '{}'::jsonb) ? %s)",
                (mind_id, email),
            )
            if existing:
                continue  # Already known
            db.execute(
                "UPDATE client_minds "
                "SET email_contacts = COALESCE(email_contacts, '{}'::jsonb) || %s::jsonb "
                "WHERE id = %s",
                (json.dumps({email: name}), mind_id),
            )
            added += 1
        except Exception as e:
            logger.debug("Failed to add email contact", email=email, error=str(e))

    if added:
        logger.info("auto_populated_contacts", mind_id=mind_id, contacts_added=added)
    return added


# --- CLI entry point ---

if __name__ == "__main__":
    import argparse
    import os

    parser = argparse.ArgumentParser(description="Coppermind email poller daemon")
    parser.add_argument("--interval", type=int, default=DEFAULT_POLL_INTERVAL)
    args = parser.parse_args()

    config = Config()
    config.poller_service_key = os.environ.get("COPPERMIND_POLLER_SERVICE_KEY", "")
    if not config.poller_service_key:
        logger.error("COPPERMIND_POLLER_SERVICE_KEY not set")
        raise SystemExit(1)

    db = Database(config)
    poller = EmailPoller(config, db)
    poller.run(poll_interval=args.interval)
