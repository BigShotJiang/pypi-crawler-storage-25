"""Coppermind CMO MCP Server.

Registers MCP tools via FastMCP. Manages server state (active mind).
Performs startup validation per SERVER_SPEC.md.
Auto-starts session watcher as a subprocess.

Hosted only: COPPERMIND_API_KEY is required. Database connection params
are provisioned from the gateway at startup.
"""

import atexit
import json
import os
import select
import signal
import shlex
import subprocess
import sys
import threading
import time as _time_mod
import uuid as _uuid
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path

import httpx
from mcp.server.fastmcp import FastMCP

from coppermind_cmo.config import Config, fetch_server_config
from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import secure_write, secure_mkdir, rotate_log
from coppermind_cmo import embedding_client, __version__

mcp = FastMCP("coppermind-cmo")
logger = ToolLogger("server")


@dataclass
class SessionState:
    """Per-session state container.

    Currently stored as a module-level singleton because MCP runs one process
    per Claude session and the protocol has no built-in session IDs.  The
    architecture is ready for per-session keying if multi-session support is
    added later (e.g. keyed by a session_id in a dict).
    """

    session_id: str = field(default_factory=lambda: str(_uuid.uuid4()))
    active_mind_id: str | None = None
    active_mind_name: str | None = None
    active_mind_color: str | None = None
    last_tool_call: str | None = None


@dataclass
class ServerState:
    """Per-process server state container.

    Encapsulates globals that were previously scattered as module-level
    variables (_config, _db, _initialized, etc.).  Stored as a module-level
    singleton ``_server``.  Tests reset fields via ``server_mod._server``.
    """

    config: Config | None = None
    db: Database | None = None
    initialized: bool = False
    initializing: bool = False
    init_lock: threading.RLock = field(default_factory=threading.RLock)
    watcher_process: subprocess.Popen | None = None
    watcher_log_file: object = None  # typing: IO[str] | None


# Module-level singletons
_session = SessionState()
_server = ServerState()

# Backward-compatible module-level alias
SESSION_ID: str = _session.session_id

# Per-session PID files -- one file per concurrent Claude session
_SESSIONS_DIR = Path.home() / ".coppermind" / "sessions"
PID_FILE = _SESSIONS_DIR / f"{SESSION_ID}.pid"
WATCHER_PID_FILE = _SESSIONS_DIR / f"{SESSION_ID}.watcher.pid"


def get_session_id() -> str:
    return _session.session_id


def get_session_state() -> SessionState:
    """Return the current SessionState. Tools can use this for session-scoped data."""
    return _session


def get_last_tool_call() -> str | None:
    return _session.last_tool_call


def set_last_tool_call(tool_name: str):
    _session.last_tool_call = tool_name


def _reap_old_processes() -> None:
    """Clean stale PID files. Does NOT kill sibling processes — Claude Code
    manages its own MCP server lifecycle, and killing siblings causes a
    restart loop when multiple sessions are active.
    """
    # Clean stale PID files only
    try:
        for pid_file in _SESSIONS_DIR.glob("*.pid"):
            try:
                pid = int(pid_file.read_text().strip())
                os.kill(pid, 0)
            except (ProcessLookupError, ValueError, OSError):
                pid_file.unlink(missing_ok=True)
    except OSError:
        pass


def _ensure_single_instance() -> None:
    """Kill old instances, claim PID file."""
    secure_mkdir(PID_FILE.parent)
    _reap_old_processes()
    secure_write(PID_FILE, str(os.getpid()))


def _cleanup() -> None:
    """Remove this session's PID files and kill its watcher on shutdown."""
    _stop_watcher()
    WATCHER_PID_FILE.unlink(missing_ok=True)
    try:
        if PID_FILE.exists() and int(PID_FILE.read_text().strip()) == os.getpid():
            PID_FILE.unlink(missing_ok=True)
    except (ValueError, OSError):
        pass


def _handle_sigterm(signum, frame):
    """Graceful shutdown on SIGTERM."""
    from coppermind_cmo.log import _write_to_log_file
    _write_to_log_file(
        "COPPERMIND-CMO: " + __import__('json').dumps({
            "timestamp": __import__('datetime').datetime.now(
                __import__('datetime').timezone.utc).isoformat(),
            "level": "info", "tool": "server",
            "message": "Shutdown: SIGTERM received",
            "pid": os.getpid(),
        })
    )
    _cleanup()
    try:
        if _server.db is not None:
            _server.db.close()
    except Exception:
        pass
    raise SystemExit(0)


def _ensure_initialized():
    """Run startup checks lazily on first tool call, not during MCP handshake.

    RE-ENTRANT CALL PATH — do not simplify the guard below:
      tool call → get_db() → _ensure_initialized() [acquires lock]
        → _startup_checks() → _run_startup_checks() → get_db()
        → _ensure_initialized() [recursive — must short-circuit here]
    The `_server.initializing` flag prevents the recursive call from
    re-entering the lock. Removing it reintroduces a deadlock (02d7a66).
    """
    if _server.initialized or _server.initializing:
        return
    with _server.init_lock:
        if _server.initialized or _server.initializing:
            return
        _server.initializing = True
        try:
            _startup_checks()
            _server.initialized = True
            logger.info("Startup checks complete — server ready")
        except SystemExit:
            raise
        except Exception as e:
            logger.error(f"Startup failed: {e}")
            raise
        finally:
            _server.initializing = False


def get_config() -> Config:
    if _server.config is None:
        _server.config = Config()
    return _server.config


def _ensure_watcher_alive():
    """Check watcher liveness and respawn if dead."""
    if _server.watcher_process is not None and _server.watcher_process.poll() is not None:
        exit_code = _server.watcher_process.returncode
        logger.warn("Session watcher died, respawning", exit_code=exit_code)
        _server.watcher_process = None
        _start_watcher()


def get_db() -> Database:
    _ensure_initialized()
    if _server.db is None:
        _server.db = Database(get_config())
    return _server.db


def get_active_mind() -> tuple[str, str] | None:
    """Returns (mind_id, mind_name) or None."""
    if _session.active_mind_id is None:
        return None
    return (_session.active_mind_id, _session.active_mind_name)


def get_customer_id() -> str | None:
    """Return the authenticated customer_id (set during gateway provisioning)."""
    config = get_config()
    cid = getattr(config, 'customer_id', None)
    return cid if cid else None


def set_active_mind(mind_id: str, mind_name: str, brand_color: str | None = None):
    _session.active_mind_id = mind_id
    _session.active_mind_name = mind_name
    _session.active_mind_color = brand_color


def stamp_active_client(result):
    """Add _active_client field to a dict result when a mind is active.

    Called by attach_notifications() so every successful tool response
    carries the active client indicator.  List results pass through unchanged.
    """
    if isinstance(result, dict):
        result["_version"] = __version__
        if _session.active_mind_name:
            if _session.active_mind_color:
                from coppermind_cmo.colors import ansi_colored
                result["_active_client"] = ansi_colored(f"[{_session.active_mind_name}]", _session.active_mind_color)
                result["_brand_color"] = _session.active_mind_color
            else:
                result["_active_client"] = f"[{_session.active_mind_name}]"
    return result


def _provision_from_gateway(config: Config):
    """Call gateway /v1/provision to get database config for hosted mode.

    Retries up to 2 times with 1s backoff for transient errors.
    """
    import time as _time
    url = f"{config.gateway_url.rstrip('/')}/v1/provision"
    max_retries = 2
    for attempt in range(max_retries):
        try:
            resp = httpx.post(
                url,
                headers={"Authorization": f"Bearer {config.api_key}"},
                timeout=5,
            )
            resp.raise_for_status()
            data = resp.json()

            if "db_host" in data:
                config.pg_host = data["db_host"]
                config.pg_port = data.get("db_port", 5432)
                config.pg_db = data.get("db_name", "postgres")
                config.pg_user = data.get("db_user", "")
                config.pg_password = data.get("db_password", "")
            elif data.get("database_url", ""):
                _parse_database_url(config, data["database_url"])

            if "embedding_dims" in data:
                config.embedding_dims = data["embedding_dims"]

            config.customer_id = data.get("customer_id", "")

            logger.info(
                "Provisioned from gateway",
                customer_id=config.customer_id,
                embedding_dims=config.embedding_dims,
            )
            return
        except Exception as e:
            if attempt < max_retries - 1:
                logger.warn(f"Gateway provisioning attempt {attempt + 1} failed: {e}. Retrying...")
                _time.sleep(1)
            else:
                logger.error(f"Gateway provisioning failed after {max_retries} attempts: {e}")
                print("COPPERMIND-CMO: STARTUP FAILED: Could not validate your API key. "
                      "Check COPPERMIND_API_KEY in your config. Contact coppermind@volacci.com",
                      file=sys.stderr)
                sys.exit(1)


def _parse_database_url(config: Config, url: str):
    """Parse a PostgreSQL URL into config PG fields."""
    from urllib.parse import urlparse
    parsed = urlparse(url)
    if parsed.hostname:
        config.pg_host = parsed.hostname
    if parsed.port:
        config.pg_port = parsed.port
    if parsed.path and parsed.path != "/":
        config.pg_db = parsed.path.lstrip("/")
    if parsed.username:
        config.pg_user = parsed.username
    if parsed.password:
        config.pg_password = parsed.password


def _startup_checks():
    """Validate configuration and service dependencies per SERVER_SPEC.md."""
    import time as _time

    _STARTUP_TIMEOUT = 25  # seconds — must finish before Claude's 60s MCP timeout

    # Wall-clock watchdog: if startup hangs (DNS, SSL, paused DB), kill with a clear error.
    _startup_failed = threading.Event()

    def _abort_startup():
        _startup_failed.set()
        msg = (
            f"Startup timed out after {_STARTUP_TIMEOUT}s. The database may be "
            f"unreachable (DNS, firewall, or paused instance). "
            f"Contact coppermind@volacci.com"
        )
        logger.error(msg, pg_host=get_config().pg_host, pg_port=get_config().pg_port)
        from coppermind_cmo.log import _write_to_log_file
        _write_to_log_file(f"COPPERMIND-CMO: STARTUP TIMEOUT — {msg}")
        print(f"COPPERMIND-CMO: STARTUP FAILED: {msg}", file=sys.stderr, flush=True)
        # SIGTERM first for graceful shutdown; hard kill after 5s if SIGTERM
        # can't interrupt C-level blocking calls (DNS, TLS handshake).
        os.kill(os.getpid(), signal.SIGTERM)
        _time.sleep(5)
        os._exit(1)  # hard backstop — process is stuck, force kill

    watchdog = threading.Timer(_STARTUP_TIMEOUT, _abort_startup)
    watchdog.daemon = True
    watchdog.start()

    try:
        _run_startup_checks()
    finally:
        watchdog.cancel()


def _register_recovery_notification(drain_result: dict):
    """Register a one-shot notification for recovered pending memories."""
    from coppermind_cmo.background import register_notification_provider

    details = drain_result.get("details", [])
    recovered = drain_result["recovered"]

    by_mind = {}
    for d in details:
        name = d.get("mind_name", "unknown")
        by_mind.setdefault(name, 0)
        by_mind[name] += 1

    if by_mind:
        breakdown = ", ".join(f"{n} for {name}" for name, n in by_mind.items())
        message = f"Recovered {recovered} memories from a previous session ({breakdown})."
    else:
        message = f"Recovered {recovered} memories from a previous session."

    fired = [False]

    def provider(db=None, customer_id=None):
        if not fired[0]:
            fired[0] = True
            return [{"type": "recovery", "message": message}]
        return []

    register_notification_provider(provider)


def _run_startup_checks():
    """Inner startup logic — separated so the watchdog timer can abort it."""
    import time as _time

    config = get_config()
    t0 = _time.monotonic()

    def _step_time(label):
        elapsed = (_time.monotonic() - t0) * 1000
        logger.info(f"Startup step: {label}", elapsed_ms=round(elapsed))

    if os.environ.get("COPPERMIND_SKIP_PROVISIONING"):
        pass  # customer_id comes from COPPERMIND_CUSTOMER_ID env var
    elif not config.api_key:
        logger.error("COPPERMIND_API_KEY is required")
        print("COPPERMIND-CMO: STARTUP FAILED: COPPERMIND_API_KEY is required. "
              "Contact coppermind@volacci.com to get your API key.",
              file=sys.stderr)
        sys.exit(1)
    else:
        print("COPPERMIND-CMO: Connecting...", file=sys.stderr, flush=True)
        _provision_from_gateway(config)
        _step_time("provisioned")

    _step_time("connecting to database")
    try:
        db = get_db()
        row = db.fetch_one("SELECT 1")
        if not row:
            raise Exception("Empty response")
        _step_time("database connected")
    except Exception as e:
        logger.error(f"Cannot connect to PostgreSQL at {config.pg_host}:{config.pg_port}: {type(e).__name__}: {e}")
        print(f"COPPERMIND-CMO: STARTUP FAILED: Cannot connect to PostgreSQL at "
              f"{config.pg_host}:{config.pg_port}. Contact coppermind@volacci.com",
              file=sys.stderr)
        sys.exit(1)

    # Drain pending queue (failed writes from previous sessions)
    try:
        from coppermind_cmo import pending_queue
        pending_count = pending_queue.count()
        if pending_count > 0:
            logger.info(f"Found {pending_count} pending memories from previous sessions, draining...")
            drain_result = pending_queue.drain(db, config)
            if drain_result["recovered"] > 0:
                logger.info(f"Recovered {drain_result['recovered']} memories from local queue")
                _register_recovery_notification(drain_result)
            if drain_result["failed"] > 0:
                logger.warning(f"Failed to recover {drain_result['failed']} memories (will retry next startup)")
            if drain_result["expired"] > 0:
                logger.info(f"Expired {drain_result['expired']} memories older than {pending_queue.MAX_AGE_DAYS} days")
            if drain_result["skipped"] > 0:
                logger.info(f"Skipped {drain_result['skipped']} items (circuit breaker — will retry next startup)")
    except Exception as e:
        logger.warning(f"Queue drain failed (will retry next startup): {e}")

    try:
        db = get_db()
        row = db.fetch_one("SELECT 1 FROM pg_extension WHERE extname = 'vector'")
        if not row:
            raise Exception("not found")
        _step_time("pgvector verified")
    except Exception as e:
        logger.error("pgvector extension not found")
        print("COPPERMIND-CMO: STARTUP FAILED: pgvector extension not installed. "
              "Contact coppermind@volacci.com", file=sys.stderr)
        sys.exit(1)

    if not embedding_client.check_health(config, session_id=get_session_id()):
        logger.warn(
            "Embedding service not reachable -- store_memory, search_memory, "
            "and quick_note will operate in degraded mode"
        )
    _step_time("embedding check done")

    logger.info(
        "Startup checks complete",
        pg_host=config.pg_host,
        pg_port=config.pg_port,
        pg_db=config.pg_db,
        pg_user=config.pg_user,
        pg_password="***",
        llm_provider=config.llm_provider or "none",
        embedding_provider=config.embedding_provider or "none",
        embedding_dims=config.embedding_dims,
        total_ms=round((_time.monotonic() - t0) * 1000),
    )

    server_cfg = fetch_server_config(config)
    if server_cfg.fetched and server_cfg.min_client_version:
        try:
            from importlib.metadata import version as pkg_version
            from packaging.version import Version
            current = Version(pkg_version("coppermind-cmo"))
            minimum = Version(server_cfg.min_client_version)
            if current < minimum:
                logger.error(
                    f"Client version {current} is below minimum {minimum}. "
                    f"{server_cfg.upgrade_message}"
                )
                print(
                    f"COPPERMIND-CMO: UPDATE REQUIRED: Your version ({current}) is too old. "
                    f"Minimum required: {minimum}. Run: coppermind-update",
                    file=sys.stderr,
                )
                sys.exit(1)
        except Exception:
            pass  # Parsing failures degrade gracefully

    if server_cfg.fetched and server_cfg.latest_version:
        from coppermind_cmo.updater import check_and_update
        check_and_update(server_cfg.latest_version, server_cfg.upgrade_urgency)

    from coppermind_cmo.background import recover_orphaned_jobs
    recover_orphaned_jobs()

    _start_watcher()


def _install_bundled_files(subdir: str, label: str):
    """Copy bundled .md files from a package subdir to ~/.claude/<subdir>/ if newer or missing.

    Intentional side-effect: writes to ~/.claude/<subdir>/ on every startup.
    Safety: compares MD5 hashes and only overwrites when content has changed.
    """
    import hashlib

    target_dir = Path.home() / ".claude" / subdir
    target_dir.mkdir(parents=True, exist_ok=True)

    try:
        package = resources.files("coppermind_cmo") / subdir
        if not package.is_dir():
            return

        for src_file in package.iterdir():
            if not src_file.name.endswith(".md"):
                continue

            dest = target_dir / src_file.name
            source_content = src_file.read_text(encoding="utf-8")
            source_hash = hashlib.md5(source_content.encode()).hexdigest()

            if dest.exists():
                dest_hash = hashlib.md5(dest.read_text(encoding="utf-8").encode()).hexdigest()
                if source_hash == dest_hash:
                    continue

            dest.write_text(source_content, encoding="utf-8")
            logger.info(f"Installed {label}: {src_file.name}")
    except Exception as e:
        logger.warn(f"Failed to install {label}s: {e}")


def _install_skills():
    """Copy bundled skill files to ~/.claude/skills/ if newer or missing."""
    _install_bundled_files("skills", "skill")


def _install_commands():
    """Copy bundled /cmo command files to ~/.claude/commands/ if newer or missing."""
    _install_bundled_files("commands", "command")


def _hook_command(script_path: Path) -> str:
    if sys.platform == "win32":
        return subprocess.list2cmdline([sys.executable, str(script_path)])
    return f"{shlex.quote(sys.executable)} {shlex.quote(str(script_path))}"


def _merge_user_prompt_submit_hook(settings: dict, hook_command: str) -> bool | None:
    hooks = settings.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        return None

    user_prompt_submit = hooks.setdefault("UserPromptSubmit", [])
    if not isinstance(user_prompt_submit, list):
        return None

    for entry in user_prompt_submit:
        if not isinstance(entry, dict):
            continue
        for hook in entry.get("hooks", []):
            if isinstance(hook, dict) and hook.get("command") == hook_command:
                return False

    user_prompt_submit.append(
        {
            "hooks": [
                {
                    "type": "command",
                    "command": hook_command,
                    "timeout": 5,
                    "statusMessage": "Checking upcoming meetings...",
                }
            ]
        }
    )
    return True


def _install_hooks():
    """Copy bundled Claude hook files and merge hook settings additively.

    Intentional side-effect: modifies ~/.claude/settings.json to register the
    auto-prep hook.  Safety guards:
      1. A marker file (~/.coppermind/.hooks-installed) ensures the settings.json
         write happens exactly once on first run.
      2. _merge_user_prompt_submit_hook returns None on unexpected structure,
         aborting the write.
      3. A .bak copy of settings.json is saved before any modification.

    The hook *script* itself is still refreshed on every startup (in case it was
    updated in a new release), but the settings merge is skipped after the first
    successful install.  Delete the marker file to re-trigger the settings merge.
    """
    marker_path = Path.home() / ".coppermind" / ".hooks-installed"
    hooks_dir = Path.home() / ".claude" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)

    try:
        hook_src = resources.files("coppermind_cmo.hooks") / "auto_prep.py"
        hook_content = hook_src.read_text(encoding="utf-8")
    except Exception as e:
        logger.warn(f"Failed to load bundled hooks: {e}")
        return

    hook_dest = hooks_dir / "coppermind-auto-prep.py"
    try:
        existing_content = hook_dest.read_text(encoding="utf-8") if hook_dest.exists() else None
        if existing_content != hook_content:
            hook_dest.write_text(hook_content, encoding="utf-8")
            try:
                os.chmod(hook_dest, 0o755)
            except OSError:
                pass
            logger.info("Installed Claude hook", path=str(hook_dest))
    except Exception as e:
        logger.warn(f"Failed to install Claude hook: {e}")
        return

    # Skip the settings merge if we already did it once
    if marker_path.exists():
        return

    settings_path = Path.home() / ".claude" / "settings.json"
    try:
        if settings_path.exists():
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        else:
            settings = {}
    except json.JSONDecodeError as e:
        logger.warn(f"Could not parse Claude settings.json: {e}")
        return
    except OSError as e:
        logger.warn(f"Could not read Claude settings.json: {e}")
        return

    hook_cmd = _hook_command(hook_dest)
    merge_result = _merge_user_prompt_submit_hook(settings, hook_cmd)
    if merge_result is None:
        logger.warn("Claude settings.json has an unsupported hooks structure; skipping auto-prep hook install")
        return
    if not merge_result:
        # Hook already present in settings — write the marker and skip
        try:
            marker_path.parent.mkdir(parents=True, exist_ok=True)
            marker_path.write_text("", encoding="utf-8")
        except OSError:
            pass
        return

    try:
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        # Back up existing settings before modification
        if settings_path.exists():
            import shutil
            bak_path = settings_path.with_suffix(".json.bak")
            shutil.copy2(settings_path, bak_path)
            logger.info("Backed up settings.json", path=str(bak_path))
        settings_path.write_text(json.dumps(settings, indent=2, sort_keys=False) + "\n", encoding="utf-8")
        logger.info("Updated Claude settings with auto-prep hook", path=str(settings_path))
    except OSError as e:
        logger.warn(f"Could not update Claude settings.json: {e}")
        return

    # Mark as installed so we don't touch settings.json again
    try:
        marker_path.parent.mkdir(parents=True, exist_ok=True)
        marker_path.write_text("", encoding="utf-8")
    except OSError:
        pass


def _install_statusline():
    """Copy statusline.sh to ~/.coppermind/ on first run (skipped on Windows)."""
    if sys.platform == "win32":
        return
    import shutil
    dest = os.path.expanduser("~/.coppermind/statusline.sh")
    if os.path.exists(dest):
        return
    try:
        src = os.path.join(os.path.dirname(__file__), "statusline.sh")
        if os.path.exists(src):
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, 0o755)
            logger.info("Installed statusline script", path=dest)
    except Exception as e:
        logger.warn(f"Could not install statusline script: {e}")


def _start_watcher():
    """Spawn the session watcher as a subprocess if enabled."""
    if _server.watcher_process is not None:
        return

    enabled = os.environ.get("COPPERMIND_WATCHER_ENABLED", "false").lower()
    if enabled not in ("true", "1", "yes"):
        logger.info("Session watcher disabled via COPPERMIND_WATCHER_ENABLED")
        return

    try:
        log_dir = Path.home() / ".coppermind"
        secure_mkdir(log_dir)
        log_path = log_dir / "watcher.log"
        rotate_log(log_path)
        _server.watcher_log_file = open(log_path, "a")
        try:
            os.chmod(log_path, 0o600)
        except OSError:
            pass

        watcher_env = os.environ.copy()
        watcher_env.setdefault("COPPERMIND_PROJECT_ROOT", os.getcwd())

        popen_kwargs = {
            "stdout": subprocess.DEVNULL,
            "stderr": _server.watcher_log_file,
            "env": watcher_env,
        }
        if sys.platform == "win32":
            popen_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        _server.watcher_process = subprocess.Popen(
            [sys.executable, "-m", "coppermind_cmo.watch", "--interval", "30"],
            **popen_kwargs,
        )
        try:
            secure_write(WATCHER_PID_FILE, str(_server.watcher_process.pid))
        except OSError:
            pass
        logger.info("Session watcher started", pid=_server.watcher_process.pid)
    except Exception as e:
        logger.warn(f"Could not start session watcher: {e}")


def _stop_watcher():
    """Kill the watcher subprocess on server shutdown."""
    if _server.watcher_process is not None:
        try:
            _server.watcher_process.terminate()
            _server.watcher_process.wait(timeout=5)
        except Exception:
            try:
                _server.watcher_process.kill()
                _server.watcher_process.wait(timeout=2)
            except Exception:
                pass
        _server.watcher_process = None
    if _server.watcher_log_file is not None:
        try:
            _server.watcher_log_file.close()
        except Exception:
            pass
        _server.watcher_log_file = None


def _register_tools():
    """Import and register all tool modules."""
    from coppermind_cmo.tools import minds, memories, brand, intelligence, outputs, daily_loop, eos, auto_ingest, team, health, email_connect
    minds.register(mcp)
    memories.register(mcp)
    brand.register(mcp)
    intelligence.register(mcp)
    outputs.register(mcp)
    daily_loop.register(mcp)
    eos.register(mcp)
    auto_ingest.register(mcp)
    team.register(mcp)
    health.register(mcp)
    email_connect.register(mcp)


def _stdin_watchdog():
    """Primary: detect parent death via stdin EOF using poll().

    When Claude Code dies, the stdin pipe closes. poll() returns POLLHUP
    on the dup'd fd without consuming any bytes from the MCP transport.
    """
    try:
        watchdog_fd = os.dup(0)
    except OSError:
        logger.warn("Could not dup stdin for watchdog -- falling back to ppid only")
        return

    def _watch_stdin():
        try:
            poller = select.poll()
            poller.register(watchdog_fd, select.POLLHUP)
            while True:
                events = poller.poll(5000)  # 5s poll interval
                for fd, event in events:
                    if event & (select.POLLHUP | select.POLLERR):
                        logger.info("stdin hangup detected -- parent gone, shutting down")
                        from coppermind_cmo.log import _write_to_log_file
                        _write_to_log_file(
                            "COPPERMIND-CMO: " + __import__('json').dumps({
                                "timestamp": __import__('datetime').datetime.now(
                                    __import__('datetime').timezone.utc).isoformat(),
                                "level": "info", "tool": "server",
                                "message": "Shutdown: stdin hangup (parent closed pipe)",
                                "pid": os.getpid(),
                            })
                        )
                        try:
                            os.close(watchdog_fd)
                        except OSError:
                            pass
                        _cleanup()
                        os._exit(0)
        except Exception:
            pass  # thread dies silently, ppid watchdog is backup

    t = threading.Thread(target=_watch_stdin, daemon=True, name="stdin-watchdog")
    t.start()


def _ppid_watchdog():
    """Backup: detect parent death via ppid change.

    Secondary mechanism -- unreliable when uv sits between Claude Code
    and the Python process, but catches cases stdin watchdog misses.
    Also monitors watcher subprocess health.
    """
    original_ppid = os.getppid()
    _tick = 0

    def _watch():
        nonlocal _tick
        while True:
            _time_mod.sleep(10)
            _tick += 1
            try:
                current_ppid = os.getppid()
                if current_ppid != original_ppid:
                    logger.info(
                        "Parent process gone (ppid changed) -- shutting down",
                        original_ppid=original_ppid,
                        current_ppid=current_ppid,
                    )
                    _cleanup()
                    os.kill(os.getpid(), signal.SIGTERM)
                    return
            except Exception:
                return

            if _tick % 3 == 0:
                try:
                    _ensure_watcher_alive()
                except Exception:
                    pass

    t = threading.Thread(target=_watch, daemon=True, name="ppid-watchdog")
    t.start()


def main():
    import json as _json
    import traceback as _tb
    from datetime import datetime as _dt, timezone as _tz
    from coppermind_cmo.log import write_crash_log, _write_to_log_file

    # Install crash handler FIRST — before anything else can fail
    sys.excepthook = write_crash_log

    _ensure_single_instance()
    atexit.register(_cleanup)
    try:
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, _handle_sigterm)
    except (OSError, ValueError):
        pass

    logger.info("Server starting", pid=os.getpid())
    _write_to_log_file(
        "COPPERMIND-CMO: " + _json.dumps({
            "timestamp": _dt.now(_tz.utc).isoformat(),
            "level": "info", "tool": "server",
            "message": "Server starting", "pid": os.getpid(),
        })
    )

    _register_tools()

    # Install skills, commands, hooks, and statusline EAGERLY at process start.
    # These are pure local file-copy operations with no external dependencies
    # (no gateway, no database). They must NOT live inside _run_startup_checks()
    # because that runs lazily on first tool call and aborts (sys.exit) if
    # provisioning or DB connection fails — which on a fresh install means
    # slash commands like /cmo-help won't exist until the 3rd-4th restart.
    _install_statusline()
    _install_skills()
    _install_commands()
    _install_hooks()

    _stdin_watchdog()
    _ppid_watchdog()

    try:
        mcp.run()
    except SystemExit:
        raise
    except KeyboardInterrupt:
        logger.info("Interrupted — shutting down")
    except Exception as exc:
        logger.error(f"Fatal: {exc}", traceback=_tb.format_exc())
        _write_to_log_file(
            "COPPERMIND-CMO: " + _json.dumps({
                "timestamp": _dt.now(_tz.utc).isoformat(),
                "level": "fatal", "tool": "server",
                "message": f"mcp.run() crashed: {exc}",
                "traceback": _tb.format_exc(), "pid": os.getpid(),
            })
        )
        raise
