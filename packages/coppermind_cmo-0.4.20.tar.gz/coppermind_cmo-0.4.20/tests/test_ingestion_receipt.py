"""Tests for ingestion receipt formatting and skip report remediation."""

import pytest
from unittest.mock import MagicMock, patch

from coppermind_cmo.tools.auto_ingest import (
    _format_ingestion_receipt,
    _format_skip_report,
    classify_skip_reason,
    SKIP_REMEDIATION,
    _auto_ingest_transcript,
)

CUSTOMER_ID = "test-customer-123"


class TestClassifySkipReason:
    """Tests for classify_skip_reason()."""

    def test_duplicate_detection(self):
        assert classify_skip_reason(reason="Already ingested") == "duplicate"
        assert classify_skip_reason(reason="duplicate content found") == "duplicate"

    def test_empty_file(self):
        assert classify_skip_reason(reason="empty file") == "empty"

    def test_too_large(self):
        assert classify_skip_reason(reason="File too large (150K chars)") == "too_large"

    def test_api_error(self):
        assert classify_skip_reason(reason="API timeout") == "api_error"
        assert classify_skip_reason(reason="Permission denied") == "api_error"

    def test_extraction_empty(self):
        assert classify_skip_reason(reason="No extractable content") == "extraction_empty"
        assert classify_skip_reason(reason="No memories found") == "extraction_empty"

    def test_by_extension_image(self):
        assert classify_skip_reason(file_ext=".jpg") == "image_file"
        assert classify_skip_reason(file_ext=".png") == "image_file"

    def test_by_extension_audio_video(self):
        assert classify_skip_reason(file_ext=".mp4") == "audio_video"
        assert classify_skip_reason(file_ext=".mp3") == "audio_video"

    def test_by_extension_document(self):
        assert classify_skip_reason(file_ext=".pdf") == "unsupported_format"
        assert classify_skip_reason(file_ext=".docx") == "unsupported_format"
        assert classify_skip_reason(file_ext=".xlsx") == "unsupported_format"

    def test_default_fallback(self):
        assert classify_skip_reason(reason="unknown issue") == "extraction_empty"

    def test_reason_takes_priority_over_extension(self):
        """Reason-based classification takes priority over extension."""
        assert classify_skip_reason(reason="Already ingested", file_ext=".pdf") == "duplicate"


class TestFormatSkipReport:
    """Tests for _format_skip_report()."""

    def test_empty_when_nothing_skipped(self):
        result = _format_skip_report()
        assert result == ""

    def test_file_level_skip_report(self):
        items = [
            {"filename": "deck.pptx", "reason": "Format not supported", "ext": ".pptx"},
            {"filename": "photo.jpg", "reason": "Image file", "ext": ".jpg"},
        ]
        result = _format_skip_report(skipped_items=items)
        assert "Next Steps for Skipped Files" in result
        assert "deck.pptx" in result
        assert "photo.jpg" in result

    def test_groups_by_action(self):
        items = [
            {"filename": "a.pdf", "reason": "", "ext": ".pdf"},
            {"filename": "b.docx", "reason": "", "ext": ".docx"},
            {"filename": "c.jpg", "reason": "", "ext": ".jpg"},
        ]
        result = _format_skip_report(skipped_items=items)
        assert "Download and share directly" in result
        assert "2 files" in result
        assert "Describe in chat" in result

    def test_chunk_level_skipped(self):
        result = _format_skip_report(chunks_skipped=5)
        assert "Skipped Sections (5)" in result

    def test_chunk_level_failed(self):
        result = _format_skip_report(chunks_failed=2)
        assert "Failed Sections (2)" in result
        assert "retried" in result.lower()

    def test_both_skipped_and_failed(self):
        result = _format_skip_report(chunks_skipped=3, chunks_failed=1)
        assert "Skipped Sections (3)" in result
        assert "Failed Sections (1)" in result

    def test_duplicate_files_no_reason_shown(self):
        items = [{"filename": "old.gdoc", "reason": "Already ingested March 15", "ext": ".gdoc"}]
        result = _format_skip_report(skipped_items=items)
        assert "No action needed" in result
        assert "old.gdoc" in result

    def test_tip_shown_for_unsupported_format(self):
        items = [{"filename": "budget.xlsx", "reason": "", "ext": ".xlsx"}]
        result = _format_skip_report(skipped_items=items)
        assert "Tip:" in result
        assert "Google Doc" in result


class TestFormatIngestionReceipt:
    """Tests for _format_ingestion_receipt()."""

    def test_basic_receipt(self):
        result = {
            "new": 5, "updated": 2, "skipped": 0,
            "chunks_succeeded": 3, "chunks_failed": 0,
            "by_type": {"fact": 4, "preference": 3}, "dedup_removed": 1,
            "estimate": {},
        }
        receipt = _format_ingestion_receipt("Acme Corp", "meeting-abc", result)
        assert "Acme Corp" in receipt
        assert "meeting-abc" in receipt
        assert "7" in receipt  # 5 new + 2 updated
        assert "5 new" in receipt
        assert "2 updated" in receipt
        assert "Duplicates removed" in receipt

    def test_zero_memories(self):
        result = {
            "new": 0, "updated": 0, "skipped": 3,
            "chunks_succeeded": 3, "chunks_failed": 0,
            "by_type": {}, "dedup_removed": 0,
            "estimate": {},
        }
        receipt = _format_ingestion_receipt("Empty Corp", "ref-1", result)
        assert "Empty Corp" in receipt
        assert "0" in receipt

    def test_document_source_label(self):
        result = {
            "new": 1, "updated": 0, "skipped": 0,
            "chunks_succeeded": 1, "chunks_failed": 0,
            "by_type": {"fact": 1}, "dedup_removed": 0,
            "estimate": {},
        }
        receipt = _format_ingestion_receipt("DocClient", "doc-1", result, is_meeting=False)
        assert "Document" in receipt

    def test_dedup_shown(self):
        result = {
            "new": 3, "updated": 0, "skipped": 0,
            "chunks_succeeded": 2, "chunks_failed": 0,
            "by_type": {"fact": 3}, "dedup_removed": 4,
            "estimate": {},
        }
        receipt = _format_ingestion_receipt("DedupClient", "ref-4", result)
        assert "Duplicates removed" in receipt
        assert "4" in receipt

    def test_skipped_sections_shown(self):
        result = {
            "new": 1, "updated": 0, "skipped": 5,
            "chunks_succeeded": 3, "chunks_failed": 0,
            "by_type": {"fact": 1}, "dedup_removed": 0,
            "estimate": {},
        }
        receipt = _format_ingestion_receipt("SkipClient", "ref-6", result)
        assert "skipped" in receipt.lower()
        assert "5" in receipt


class TestReceiptWithSkipReport:
    """Tests that the receipt integrates skip report correctly."""

    def test_receipt_includes_skip_report_for_chunks(self):
        result = {
            "new": 3, "updated": 0, "skipped": 2,
            "chunks_succeeded": 4, "chunks_failed": 1,
            "by_type": {"fact": 3}, "dedup_removed": 0,
            "estimate": {},
        }
        receipt = _format_ingestion_receipt("Client", "ref-1", result)
        assert "Skipped Sections (2)" in receipt
        assert "Failed Sections (1)" in receipt

    def test_receipt_includes_file_level_skip_report(self):
        result = {
            "new": 5, "updated": 0, "skipped": 0,
            "chunks_succeeded": 3, "chunks_failed": 0,
            "by_type": {"fact": 5}, "dedup_removed": 0,
            "estimate": {},
        }
        items = [{"filename": "photo.jpg", "reason": "Image", "ext": ".jpg"}]
        receipt = _format_ingestion_receipt("Client", "ref-2", result, skipped_items=items)
        assert "Next Steps for Skipped Files" in receipt
        assert "photo.jpg" in receipt

    def test_receipt_no_skip_report_when_clean(self):
        result = {
            "new": 3, "updated": 0, "skipped": 0,
            "chunks_succeeded": 3, "chunks_failed": 0,
            "by_type": {"fact": 3}, "dedup_removed": 0,
            "estimate": {},
        }
        receipt = _format_ingestion_receipt("Client", "ref-3", result)
        assert "Next Steps" not in receipt
        assert "Skipped Sections" not in receipt


class TestAutoIngestWithReceipt:
    """Tests that _auto_ingest_transcript includes receipt data."""

    def test_success_includes_receipt(self, mock_db, mock_config):
        """Successful ingestion includes receipt and by_type in response."""
        mock_db.fetch_one.side_effect = [
            (1,),              # table exists
            ("TestClient",),   # mind access check
        ]
        mock_db.execute_returning.return_value = ("meeting-id",)

        mock_engine = MagicMock()
        mock_engine.process_source.return_value = {
            "new": 3, "updated": 1, "skipped": 0,
            "chunks_succeeded": 2, "chunks_failed": 0,
            "by_type": {"decision": 2, "fact": 2},
            "dedup_removed": 0,
            "estimate": {"word_count": 2000},
        }

        with patch("coppermind_cmo.ingest.IngestEngine", return_value=mock_engine):
            result = _auto_ingest_transcript(
                mind_id="mind-1",
                mind_name="TestClient",
                meeting_log_id="meeting-1",
                transcript_text="Some transcript text here.",
                source_ref="granola-abc",
                db=mock_db, config=mock_config, customer_id=CUSTOMER_ID,
            )

        assert result["ingested"] is True
        assert "receipt" in result
        assert "by_type" in result
        assert result["by_type"]["decision"] == 2

    def test_zero_memories_includes_receipt(self, mock_db, mock_config):
        """Zero-memory result still includes receipt."""
        mock_db.fetch_one.side_effect = [
            (1,),              # table exists
            ("TestClient",),   # mind access check
        ]

        mock_engine = MagicMock()
        mock_engine.process_source.return_value = {
            "new": 0, "updated": 0, "skipped": 2,
            "chunks_succeeded": 2, "chunks_failed": 0,
            "by_type": {}, "dedup_removed": 0,
            "estimate": {"word_count": 300},
        }

        with patch("coppermind_cmo.ingest.IngestEngine", return_value=mock_engine):
            result = _auto_ingest_transcript(
                mind_id="mind-1",
                mind_name="TestClient",
                meeting_log_id="meeting-1",
                transcript_text="Short text.",
                source_ref="granola-xyz",
                db=mock_db, config=mock_config, customer_id=CUSTOMER_ID,
            )

        assert result["ingested"] is False
        assert "receipt" in result
        assert result["by_type"] == {}

    def test_backward_compatible(self, mock_db, mock_config):
        """Existing fields (memories_new, memories_updated, etc.) still present."""
        mock_db.fetch_one.side_effect = [
            (1,),            # table exists
            ("Client",),     # mind access check
        ]
        mock_db.execute_returning.return_value = ("meeting-id",)

        mock_engine = MagicMock()
        mock_engine.process_source.return_value = {
            "new": 5, "updated": 0, "skipped": 1,
            "chunks_succeeded": 3, "chunks_failed": 0,
            "by_type": {"fact": 5}, "dedup_removed": 0,
            "estimate": {},
        }

        with patch("coppermind_cmo.ingest.IngestEngine", return_value=mock_engine):
            result = _auto_ingest_transcript(
                mind_id="mind-1", mind_name="Client",
                meeting_log_id="m-1", transcript_text="Text.",
                source_ref="ref-1", db=mock_db, config=mock_config,
                customer_id=CUSTOMER_ID,
            )

        assert "memories_new" in result
        assert "memories_updated" in result
        assert "memories_skipped" in result
        assert "mind_id" in result
        assert result["memories_new"] == 5
