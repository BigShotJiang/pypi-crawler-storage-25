"""Tests for email poller: attribution, filtering, content extraction."""

import json
from unittest.mock import MagicMock, patch

import pytest

from coppermind_cmo.email_poller import (
    EMAIL_RE,
    EmailPoller,
    auto_populate_email_contacts,
    extract_emails_from_content,
)


# ---------------------------------------------------------------------------
# extract_emails_from_content
# ---------------------------------------------------------------------------

class TestExtractEmails:
    def test_basic_extraction(self):
        assert extract_emails_from_content("Contact sarah@acme.com for details") == [
            "sarah@acme.com"
        ]

    def test_multiple_emails(self):
        text = "From: sarah@acme.com and josh@betacorp.com"
        result = extract_emails_from_content(text)
        assert "sarah@acme.com" in result
        assert "josh@betacorp.com" in result

    def test_filters_noreply(self):
        text = "Reply to noreply@acme.com or no-reply@acme.com"
        assert extract_emails_from_content(text) == []

    def test_filters_mailer_daemon(self):
        assert extract_emails_from_content("mailer-daemon@acme.com bounced") == []

    def test_filters_notifications(self):
        assert extract_emails_from_content("notifications@github.com") == []

    def test_filters_local_tld(self):
        assert extract_emails_from_content("admin@server.local") == []
        assert extract_emails_from_content("dev@box.localhost") == []

    def test_allows_normal_prefixes(self):
        result = extract_emails_from_content("hello@acme.com and ceo@betacorp.com")
        assert "hello@acme.com" in result
        assert "ceo@betacorp.com" in result

    def test_empty_input(self):
        assert extract_emails_from_content("") == []
        assert extract_emails_from_content("no emails here") == []


# ---------------------------------------------------------------------------
# EmailPoller._matches_known_contacts
# ---------------------------------------------------------------------------

class TestMatchesKnownContacts:
    def test_email_match(self):
        assert EmailPoller._matches_known_contacts(
            None,
            "sarah@acme.com", [], [],
            set(), {"sarah@acme.com"},
        )

    def test_domain_match(self):
        assert EmailPoller._matches_known_contacts(
            None,
            "unknown@acme.com", [], [],
            {"acme.com"}, set(),
        )

    def test_to_address_match(self):
        assert EmailPoller._matches_known_contacts(
            None,
            "me@volacci.com", ["sarah@acme.com"], [],
            set(), {"sarah@acme.com"},
        )

    def test_cc_address_match(self):
        assert EmailPoller._matches_known_contacts(
            None,
            "me@volacci.com", [], ["josh@acme.com"],
            {"acme.com"}, set(),
        )

    def test_no_match(self):
        assert not EmailPoller._matches_known_contacts(
            None,
            "random@unknown.com", ["other@unknown.com"], [],
            {"acme.com"}, {"sarah@acme.com"},
        )

    def test_case_insensitive(self):
        assert EmailPoller._matches_known_contacts(
            None,
            "Sarah@ACME.COM", [], [],
            set(), {"sarah@acme.com"},
        )


# ---------------------------------------------------------------------------
# EmailPoller._attribute_email
# ---------------------------------------------------------------------------

class TestAttributeEmail:
    MINDS = [
        {
            "id": "mind-1",
            "name": "Acme Corp",
            "email_contacts": {"sarah@acme.com": "Sarah", "josh@acme.com": "Josh"},
            "company_info": {"domain": "acme.com"},
        },
        {
            "id": "mind-2",
            "name": "Beta Corp",
            "email_contacts": {"alice@betacorp.com": "Alice"},
            "company_info": {"domain": "betacorp.com"},
        },
    ]

    def test_single_match_by_email(self):
        result = EmailPoller._attribute_email(
            None, "sarah@acme.com", ["me@volacci.com"], [], self.MINDS,
        )
        assert result == ["mind-1"]

    def test_single_match_by_domain(self):
        result = EmailPoller._attribute_email(
            None, "unknown@acme.com", ["me@volacci.com"], [], self.MINDS,
        )
        assert result == ["mind-1"]

    def test_multi_match(self):
        result = EmailPoller._attribute_email(
            None,
            "sarah@acme.com",
            ["alice@betacorp.com"],
            [],
            self.MINDS,
        )
        assert len(result) == 2
        assert "mind-1" in result
        assert "mind-2" in result

    def test_no_match(self):
        result = EmailPoller._attribute_email(
            None, "random@unknown.com", ["other@unknown.com"], [], self.MINDS,
        )
        assert result == []

    def test_cc_attribution(self):
        result = EmailPoller._attribute_email(
            None,
            "me@volacci.com",
            [],
            ["alice@betacorp.com"],
            self.MINDS,
        )
        assert result == ["mind-2"]


# ---------------------------------------------------------------------------
# EmailPoller._should_skip_message
# ---------------------------------------------------------------------------

class TestShouldSkipMessage:
    def test_auto_reply(self):
        headers = [{"name": "Auto-Submitted", "value": "auto-replied"}]
        assert EmailPoller._should_skip_message(headers, None)

    def test_newsletter(self):
        headers = [{"name": "List-Unsubscribe", "value": "<mailto:unsub@list.com>"}]
        assert EmailPoller._should_skip_message(headers, None)

    def test_calendar_invite(self):
        headers = [{"name": "From", "value": "sarah@acme.com"}]
        assert EmailPoller._should_skip_message(headers, "text/calendar")

    def test_normal_email(self):
        headers = [
            {"name": "From", "value": "sarah@acme.com"},
            {"name": "Subject", "value": "Q3 budget"},
        ]
        assert not EmailPoller._should_skip_message(headers, "text/plain")


# ---------------------------------------------------------------------------
# EmailPoller._clean_email_body
# ---------------------------------------------------------------------------

class TestCleanEmailBody:
    def test_removes_quoted_lines(self):
        text = "Hello\n> This is quoted\n> More quoted\nGoodbye"
        result = EmailPoller._clean_email_body(text)
        assert "Hello" in result
        assert "Goodbye" in result
        assert "quoted" not in result

    def test_stops_at_reply_marker(self):
        text = "Main content here\n\nOn Mon, Jan 1, 2026 at 10:00 AM John wrote:\nOld stuff"
        result = EmailPoller._clean_email_body(text)
        assert "Main content" in result
        assert "Old stuff" not in result

    def test_stops_at_signature(self):
        text = "Important info\n--\nJohn Smith\nCEO, Acme Corp"
        result = EmailPoller._clean_email_body(text)
        assert "Important info" in result
        assert "John Smith" not in result

    def test_stops_at_footer_delimiter(self):
        text = "Real content\n___\nThis email is confidential"
        result = EmailPoller._clean_email_body(text)
        assert "Real content" in result
        assert "confidential" not in result

    def test_preserves_clean_email(self):
        text = "Hi Ben,\n\nLet's schedule a call for Thursday.\n\nBest,\nSarah"
        result = EmailPoller._clean_email_body(text)
        assert "schedule a call" in result


# ---------------------------------------------------------------------------
# EmailPoller._extract_header
# ---------------------------------------------------------------------------

class TestExtractHeader:
    def test_found(self):
        headers = [{"name": "From", "value": "sarah@acme.com"}]
        assert EmailPoller._extract_header(headers, "From") == "sarah@acme.com"

    def test_not_found(self):
        headers = [{"name": "From", "value": "sarah@acme.com"}]
        assert EmailPoller._extract_header(headers, "Subject") == ""

    def test_case_insensitive(self):
        headers = [{"name": "from", "value": "sarah@acme.com"}]
        assert EmailPoller._extract_header(headers, "From") == "sarah@acme.com"


# ---------------------------------------------------------------------------
# EmailPoller._parse_addresses
# ---------------------------------------------------------------------------

class TestParseAddresses:
    def test_simple(self):
        assert EmailPoller._parse_addresses("sarah@acme.com") == ["sarah@acme.com"]

    def test_with_name(self):
        result = EmailPoller._parse_addresses("Sarah Chen <sarah@acme.com>")
        assert "sarah@acme.com" in result

    def test_multiple(self):
        result = EmailPoller._parse_addresses("sarah@acme.com, josh@acme.com")
        assert len(result) == 2


# ---------------------------------------------------------------------------
# auto_populate_email_contacts
# ---------------------------------------------------------------------------

class TestAutoPopulateContacts:
    def test_adds_contacts(self):
        db = MagicMock()
        # First call: SELECT to check if email exists (returns empty = not found)
        # Second call: UPDATE to add it
        db.execute = MagicMock(side_effect=[[], None])

        count = auto_populate_email_contacts(
            db, "mind-123", "Contact Sarah Chen sarah@acme.com for details"
        )
        assert count >= 1
        assert db.execute.call_count == 2

    def test_skips_existing_contacts(self):
        db = MagicMock()
        # SELECT returns a row = email already known
        db.execute = MagicMock(return_value=[{"?column?": 1}])

        count = auto_populate_email_contacts(
            db, "mind-123", "Contact Sarah Chen sarah@acme.com for details"
        )
        assert count == 0

    def test_no_emails_found(self):
        db = MagicMock()
        count = auto_populate_email_contacts(db, "mind-123", "No emails here")
        assert count == 0
        assert not db.execute.called

    def test_filters_infrastructure(self):
        db = MagicMock()
        count = auto_populate_email_contacts(
            db, "mind-123", "Contact noreply@acme.com"
        )
        assert count == 0


# ---------------------------------------------------------------------------
# EmailPoller._build_known_contacts
# ---------------------------------------------------------------------------

class TestBuildKnownContacts:
    def test_builds_sets(self):
        minds = [
            {
                "email_contacts": {"sarah@acme.com": "Sarah"},
                "company_info": {"domain": "acme.com"},
            },
            {
                "email_contacts": {"alice@beta.com": "Alice"},
                "company_info": {},
            },
        ]
        poller = EmailPoller.__new__(EmailPoller)
        domains, emails = poller._build_known_contacts(minds)
        assert domains == {"acme.com"}
        assert emails == {"sarah@acme.com", "alice@beta.com"}

    def test_empty_minds(self):
        poller = EmailPoller.__new__(EmailPoller)
        domains, emails = poller._build_known_contacts([])
        assert domains == set()
        assert emails == set()

    def test_missing_fields(self):
        minds = [{"email_contacts": None, "company_info": None}]
        poller = EmailPoller.__new__(EmailPoller)
        domains, emails = poller._build_known_contacts(minds)
        assert domains == set()
        assert emails == set()
