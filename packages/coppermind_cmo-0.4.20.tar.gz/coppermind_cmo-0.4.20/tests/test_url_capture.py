"""Tests for auto-capture of shared URLs."""

import pytest
from coppermind_cmo.tools.memories import _extract_urls, _extract_url_domain


class TestExtractUrls:
    def test_basic_url(self):
        urls = _extract_urls("Check this: https://example.com/page")
        assert urls == ["https://example.com/page"]

    def test_multiple_urls(self):
        text = "Links: https://a.com and https://b.com/path"
        urls = _extract_urls(text)
        assert len(urls) == 2
        assert "https://a.com" in urls
        assert "https://b.com/path" in urls

    def test_no_urls(self):
        assert _extract_urls("Just plain text") == []

    def test_empty_text(self):
        assert _extract_urls("") == []
        assert _extract_urls(None) == []

    def test_skips_code_blocks(self):
        text = "Normal https://keep.com\n```\nhttps://skip.com\n```"
        urls = _extract_urls(text)
        assert "https://keep.com" in urls
        assert "https://skip.com" not in urls

    def test_skips_inline_code(self):
        text = "Use `https://skip.com` but also https://keep.com"
        urls = _extract_urls(text)
        assert "https://keep.com" in urls
        assert "https://skip.com" not in urls

    def test_skips_localhost(self):
        urls = _extract_urls("http://localhost:3000/api")
        assert urls == []

    def test_skips_coppermind_gateway(self):
        urls = _extract_urls("https://api.coppermind.app/v1/config")
        assert urls == []

    def test_strips_trailing_punctuation(self):
        urls = _extract_urls("See https://example.com/page.")
        assert urls == ["https://example.com/page"]

        urls = _extract_urls("Link: https://example.com/page,")
        assert urls == ["https://example.com/page"]

    def test_deduplicates(self):
        text = "https://same.com and again https://same.com"
        urls = _extract_urls(text)
        assert len(urls) == 1

    def test_truncates_long_urls(self):
        long_url = "https://example.com/" + "a" * 600
        urls = _extract_urls(f"Link: {long_url}")
        assert len(urls) == 1
        assert len(urls[0]) == 500

    def test_real_world_drive_url(self):
        text = "Here's the brand folder: https://drive.google.com/drive/folders/1abc2def3ghi"
        urls = _extract_urls(text)
        assert len(urls) == 1
        assert "drive.google.com" in urls[0]

    def test_http_and_https(self):
        text = "http://old.com and https://new.com"
        urls = _extract_urls(text)
        assert len(urls) == 2


class TestExtractUrlDomain:
    def test_simple_domain(self):
        assert _extract_url_domain("https://example.com/path") == "example.com"

    def test_subdomain(self):
        assert _extract_url_domain("https://drive.google.com/folder") == "drive.google.com"

    def test_invalid_url(self):
        assert _extract_url_domain("not-a-url") == ""
