"""Tests for auto_ingest tools: find_uningested_meetings, auto_ingest_transcript."""

from unittest.mock import MagicMock, patch
import pytest

from coppermind_cmo.tools.auto_ingest import (
    _find_uningested_meetings,
    _auto_ingest_transcript,
)
import coppermind_cmo.tools.daily_loop as daily_loop_mod

CUSTOMER_ID = "test-customer-123"


# ---------------------------------------------------------------------------
# find_uningested_meetings
# ---------------------------------------------------------------------------


class TestFindUningestedMeetings:
    def test_returns_uningested_meetings(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.fetch_all.return_value = [
            ("ml-1", "mind-a", "Weekly Sync", "2026-03-25T10:00:00", "cal-1", "confident", "Acme Corp"),
            ("ml-2", "mind-b", "Strategy Review", "2026-03-25T14:00:00", None, "confident", "Beta Inc"),
        ]

        result = _find_uningested_meetings(mock_db, CUSTOMER_ID)

        assert result["count"] == 2
        assert len(result["meetings"]) == 2
        assert result["meetings"][0]["meeting_log_id"] == "ml-1"
        assert result["meetings"][0]["mind_id"] == "mind-a"
        assert result["meetings"][0]["mind_name"] == "Acme Corp"
        assert result["meetings"][1]["meeting_log_id"] == "ml-2"
        assert result["meetings"][1]["mind_name"] == "Beta Inc"

    def test_returns_empty_when_none_found(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.fetch_all.return_value = []

        result = _find_uningested_meetings(mock_db, CUSTOMER_ID)

        assert result["count"] == 0
        assert result["meetings"] == []

    def test_no_table_returns_migration_error(self, mock_db):
        mock_db.fetch_one.return_value = None  # table doesn't exist

        result = _find_uningested_meetings(mock_db, CUSTOMER_ID)

        assert result["error"] is True
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_filters_by_customer_id(self, mock_db):
        mock_db.fetch_one.return_value = (1,)
        mock_db.fetch_all.return_value = []

        _find_uningested_meetings(mock_db, CUSTOMER_ID)

        sql_arg = mock_db.fetch_all.call_args[0][0]
        params = mock_db.fetch_all.call_args[0][1]
        assert "customer_id = %s" in sql_arg
        assert params == [CUSTOMER_ID]

    def test_only_finds_confident_matches(self, mock_db):
        mock_db.fetch_one.return_value = (1,)
        mock_db.fetch_all.return_value = []

        _find_uningested_meetings(mock_db, CUSTOMER_ID)

        sql_arg = mock_db.fetch_all.call_args[0][0]
        assert "match_confidence = 'confident'" in sql_arg
        assert "transcript_ingested = false" in sql_arg
        assert "mind_id IS NOT NULL" in sql_arg


# ---------------------------------------------------------------------------
# auto_ingest_transcript
# ---------------------------------------------------------------------------


class TestAutoIngestTranscript:
    def _make_mock_engine(self, new=5, updated=1, skipped=2):
        engine = MagicMock()
        engine.process_source.return_value = {"new": new, "updated": updated, "skipped": skipped}
        return engine

    def test_successful_ingestion(self, mock_db, mock_config):
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("Acme Corp",),          # mind access check
        ]
        mock_db.execute_returning.return_value = ("ml-1",)  # mark ingested

        mock_engine = self._make_mock_engine()
        with patch("coppermind_cmo.ingest.IngestEngine", return_value=mock_engine):
            result = _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="Acme Corp",
                meeting_log_id="ml-1",
                transcript_text="Meeting notes about Q2 strategy...",
                source_ref="granola-meeting-123",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )

        assert result["ingested"] is True
        assert result["mind_id"] == "mind-a"
        assert result["mind_name"] == "Acme Corp"
        assert result["meeting_log_id"] == "ml-1"
        assert result["source_ref"] == "granola-meeting-123"
        assert result["memories_new"] == 5
        assert result["memories_updated"] == 1
        assert result["memories_skipped"] == 2

        # Verify process_source was called correctly
        mock_engine.process_source.assert_called_once_with(
            source_type="meeting",
            source_ref="granola-meeting-123",
            content="Meeting notes about Q2 strategy...",
        )

        # Verify transcript was marked as ingested with mind_id in WHERE
        mark_sql = mock_db.execute_returning.call_args[0][0]
        mark_params = mock_db.execute_returning.call_args[0][1]
        assert "transcript_ingested = true" in mark_sql
        assert "mind_id = %s" in mark_sql
        assert mark_params == ["ml-1", CUSTOMER_ID, "mind-a"]

    def test_resolves_mind_name_from_db(self, mock_db, mock_config):
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("DB Resolved Name",),   # mind access check returns name
        ]
        mock_db.execute_returning.return_value = ("ml-1",)

        mock_engine = self._make_mock_engine()
        with patch("coppermind_cmo.ingest.IngestEngine", return_value=mock_engine):
            result = _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="",  # empty — should resolve from DB
                meeting_log_id="ml-1",
                transcript_text="Some transcript...",
                source_ref="granola-456",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )

        assert result["mind_name"] == "DB Resolved Name"

    def test_zero_memories_does_not_mark_ingested(self, mock_db, mock_config):
        """When no memories are extracted, the meeting should NOT be marked ingested."""
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("Acme Corp",),          # mind access check
        ]

        mock_engine = self._make_mock_engine(new=0, updated=0, skipped=3)
        with patch("coppermind_cmo.ingest.IngestEngine", return_value=mock_engine):
            result = _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="Acme Corp",
                meeting_log_id="ml-1",
                transcript_text="Some transcript...",
                source_ref="granola-789",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )

        assert result["ingested"] is False
        assert "warning" in result
        # Should NOT have called execute_returning (no mark)
        mock_db.execute_returning.assert_not_called()

    def test_meeting_log_not_found_after_ingest(self, mock_db, mock_config):
        """When the UPDATE RETURNING matches no rows, return an error."""
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("Acme Corp",),          # mind access check
        ]
        mock_db.execute_returning.return_value = None  # UPDATE matched nothing

        mock_engine = self._make_mock_engine()
        with patch("coppermind_cmo.ingest.IngestEngine", return_value=mock_engine):
            result = _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="Acme Corp",
                meeting_log_id="ml-wrong",
                transcript_text="Some transcript...",
                source_ref="granola-999",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )

        assert result["error"] is True
        assert result["code"] == "MEETING_LOG_NOT_FOUND"

    def test_empty_mind_id_returns_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_empty_meeting_log_id_returns_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Test",
            meeting_log_id="",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_empty_transcript_returns_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_empty_source_ref_returns_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_no_table_returns_migration_error(self, mock_db, mock_config):
        mock_db.fetch_one.return_value = None  # table doesn't exist

        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_mind_not_found_returns_error(self, mock_db, mock_config):
        mock_db.fetch_one.side_effect = [
            (1,),   # table exists
            None,   # mind not found
        ]

        result = _auto_ingest_transcript(
            mind_id="nonexistent-mind",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "MIND_NOT_FOUND"

    def test_whitespace_only_inputs_return_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="   ",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
