# Coppermind CMO

AI-powered memory for fractional CMOs. Never forget a client detail, never leak data between clients, always prep well for meetings.

Coppermind CMO is an [MCP server](https://modelcontextprotocol.io/) that gives Claude persistent, client-scoped memory across conversations. Store meeting notes, brand voice, campaign outcomes, and decisions — then search, prep, and recall instantly.

## Installation

```bash
pip install coppermind-cmo
```

## Setup

Add to your Claude Code settings (`~/.claude/settings.json`):

```json
{
  "mcpServers": {
    "coppermind-cmo": {
      "command": "python",
      "args": ["-m", "coppermind_cmo"],
      "env": {
        "COPPERMIND_API_KEY": "your-key-here"
      }
    }
  }
}
```

> **Note:** Use `python3` instead of `python` on Mac/Linux if `python` is not aliased to Python 3.

That's it. The API key handles everything — database access, embeddings, and extraction services are all managed for you.

## What it does

**46 tools across 6 categories:**

| Category | Tools | Purpose |
|----------|-------|---------|
| **Core** (15) | `switch_client`, `list_minds`, `configure_mind`, `store_memory`, `search_memory`, `quick_note`, `hide_memory`, `get_brand_voice`, `set_brand_voice`, `prep_meeting`, `get_last_brief`, `get_campaign_history`, `list_documents`, `save_output`, `done` | Client management, memory storage/search, brand DNA, meeting prep |
| **Daily Loop** (6) | `get_weekly_summary`, `get_cross_client_summary`, `get_meeting_context`, `log_meeting_event`, `mark_followup_sent`, `ensure_personal_mind` | Morning briefings, cross-client dashboard, meeting follow-ups |
| **EOS** (13) | `get_rocks`, `manage_rock`, `get_issues`, `manage_issue`, `get_agenda`, `manage_agenda`, `get_current_sprint`, `get_sprint_plan`, `import_sprint_plan`, `update_sprint_status`, `quarterly_pacing`, `start_quarter`, `prep_l10` | Rock tracking, sprint planning, L10 meeting prep, quarterly pacing |
| **Auto-Ingest** (2) | `auto_ingest_transcript`, `find_uningested_meetings` | Automatic meeting transcript ingestion from connected sources |
| **Email** (3) | `connect_gmail`, `disconnect_gmail`, `email_status` | Gmail OAuth connection, automatic email ingestion into client minds |
| **Team** (7) | `add_team_member`, `remove_team_member`, `list_team`, `list_pending`, `promote_pending`, `dismiss_pending`, `rollback_pending` | Share client minds with VAs/team members with approval workflows |

**Key properties:**

- **Client isolation** — every query is scoped to the active client. Zero cross-client data leakage.
- **Brand DNA** — store and retrieve brand voice, positioning, stakeholders, visual identity, anti-patterns, and platform-specific content guidance per client.
- **Meeting prep** — topic-aware retrieval across memories, commitments, and brand DNA, returned as a structured brief. Interactive follow-up questions supported.
- **Team sharing** — grant VAs and junior marketers filtered access to client minds. Viewer-created memories require CMO approval. Sensitive content auto-detected and hidden.
- **Client-colored output** — brand colors render in tool responses and terminal output for visual client context.
- **Resilient** — all tool calls are wrapped with structured error handling. Gateway calls retry with exponential backoff. Graceful degradation when services are temporarily unavailable.
- **EOS-native** — full EOS methodology support: rocks, sprints, L10 prep, quarterly pacing, and quarter transitions.

## Daily workflow

```
# Before a call — get briefed
"Switch to Acme Corp and prep me for our meeting about Q2 planning"
→ Switched to Acme Corp. 47 memories, last meeting Mar 20, brand voice: set (850 words), EOS: Q2 2026 active.

# Interactive meeting prep — ask follow-up questions
"Tell me more about their Q1 campaign results"
"What's the history with Sarah Chen?"
"Compare to last meeting"

# During/after a call — capture what happened
"Remember that Acme decided to pause LinkedIn ads through Q2"
"Quick note: Sarah mentioned the April budget review might affect Q3"

# Switching clients — change context
"Switch to Bluebell"
"What do we know about Bluebell's campaign performance?"

# Quarter transitions
"Transition Acme to Q2 — carry forward the partner portal rock"

# Team sharing
"Add my VA to Acme Corp as a viewer"
"Review pending memories from my team"
```

## Optional Extras

For local embedding or related infrastructure dependencies:

```bash
pip install coppermind-cmo[self-hosted]
```

See [full documentation](https://github.com/benfinklea/coppermind-cmo/blob/main/docs/QUICKSTART.md) for current setup details.

## Support

Contact Ben directly at ben@volacci.com.
