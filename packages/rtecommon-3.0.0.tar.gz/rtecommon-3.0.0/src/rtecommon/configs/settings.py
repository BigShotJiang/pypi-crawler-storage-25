from dotenv import load_dotenv
from pydantic_settings import BaseSettings

load_dotenv()


class EnvironmentSettings(BaseSettings):
    PROJECT_DIR: str = ""
    PROJECT_NAME: str = ""
    VENV_ENVIRONMENT: str = ""


class Settings(BaseSettings):
    env: EnvironmentSettings = EnvironmentSettings()


env_settings = EnvironmentSettings()
settings = Settings()
