from __future__ import annotations

import logging

from colorlog import ColoredFormatter

LEVEL_MAP = {
    "CRITICAL": "CRIT",
    "DEBUG": "DBUG",
    "ERROR": "ERRR",
    "INFO": "INFO",
    "TRACE": "TRCE",
    "WARNING": "WARN",
}
TRACE_LEVEL = 5


class ShortLevelFormatter(logging.Formatter):
    """Formatter that shortens standard logging level names."""

    def format(self, record: logging.LogRecord) -> str:
        original_levelname = record.levelname
        record.levelname = LEVEL_MAP.get(record.levelname, record.levelname)
        try:
            return super().format(record)
        finally:
            record.levelname = original_levelname


class ShortLevelColoredFormatter(ColoredFormatter):
    """Colour formatter that keeps the same shortened level names as the plain formatter."""

    def __init__(self, *args, **kwargs):
        """Initialise the formatter and keep colour mappings for original level names."""
        original_log_colors = kwargs.get("log_colors", {})
        if original_log_colors:
            extended_colors = dict(original_log_colors)
            for original, shortened in LEVEL_MAP.items():
                if shortened in original_log_colors and original != shortened:
                    extended_colors[original] = original_log_colors[shortened]
            kwargs["log_colors"] = extended_colors

        super().__init__(*args, **kwargs)

    def format(self, record: logging.LogRecord) -> str:
        original_levelname = record.levelname
        record.levelname = LEVEL_MAP.get(record.levelname, record.levelname)
        try:
            return super().format(record)
        finally:
            record.levelname = original_levelname
