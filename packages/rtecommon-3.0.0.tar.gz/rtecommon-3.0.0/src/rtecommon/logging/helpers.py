from __future__ import annotations

import logging
from collections.abc import Iterable


def _iter_settings_values(settings_object: object) -> Iterable[tuple[object, object]]:
    """Yield key-value pairs from a supported settings object shape."""
    if hasattr(settings_object, "model_dump"):
        return settings_object.model_dump().items()
    if hasattr(settings_object, "dict"):
        return settings_object.dict().items()
    if hasattr(settings_object, "items"):
        return dict(settings_object).items()
    return vars(settings_object).items()


def get_named_loggers(logger_names: tuple[str, ...] = ("all", "console", "file")) -> tuple[logging.Logger, ...]:
    """Return the configured named loggers in the requested order."""
    return tuple(logging.getLogger(logger_name) for logger_name in logger_names)


def log_environment_settings(*settings_objects: object) -> None:
    """Log startup settings while masking password-like values by length."""
    log_file = logging.getLogger("file")

    for settings_object in settings_objects:
        if settings_object is None:
            continue

        for key, value in _iter_settings_values(settings_object):
            key_name = str(key)
            if "PASSWORD" in key_name.upper() or "PWD" in key_name.upper() or "SECRET" in key_name.upper():
                masked_length = 0 if value is None else len(str(value))
                log_file.info(f"{key_name} length={masked_length}")
            else:
                log_file.info(f"{key_name}={value}")
