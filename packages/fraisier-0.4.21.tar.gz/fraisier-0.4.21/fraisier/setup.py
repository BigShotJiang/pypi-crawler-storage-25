"""Server setup — provisions infrastructure from fraises.yaml.

Creates directories, symlinks bare repos, installs systemd services,
generates webhook env files, installs nginx vhosts, and validates.
"""

from __future__ import annotations

import logging
import secrets
import socket
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from fraisier.config import FraisierConfig, NginxEnvConfig
from fraisier.scaffold.renderer import ScaffoldRenderer

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from collections.abc import Iterator

    from fraisier.runners import CommandRunner


@dataclass
class SetupAction:
    """A single provisioning step."""

    description: str
    command: list[str]
    category: str
    check: list[str] | None = None


class ServerSetup:
    """Provisions server-side infrastructure from fraises.yaml."""

    def __init__(
        self,
        config: FraisierConfig,
        runner: CommandRunner,
        *,
        environment: str | None = None,
        server: str | None = None,
    ) -> None:
        self.config = config
        self.runner = runner
        self.environment = environment
        self.server = server
        self._renderer = ScaffoldRenderer(config)

    def plan(self) -> list[SetupAction]:
        """Build the full ordered list of actions without side effects."""
        actions: list[SetupAction] = []
        actions.extend(self._plan_users())
        actions.extend(self._plan_directories())
        actions.extend(self._plan_app_permissions())
        actions.extend(self._plan_git_safe_directory())
        actions.extend(self._plan_symlinks())
        actions.extend(self._plan_sudoers())
        actions.extend(self._plan_app_services())
        actions.extend(self._plan_webhook_service())
        actions.extend(self._plan_env_files())
        actions.extend(self._plan_nginx())
        actions.extend(self._plan_systemd_reload())
        actions.extend(self._plan_validation())
        return actions

    def execute(self) -> list[tuple[SetupAction, bool]]:
        """Run scaffold, write env file, then execute all plan actions.

        Returns list of (action, success) tuples.
        """
        self._renderer.render()
        self._write_env_file()

        actions = self.plan()
        results: list[tuple[SetupAction, bool]] = []

        for action in actions:
            if action.check:
                try:
                    self.runner.run(action.check, check=True)
                    results.append((action, True))
                    continue
                except subprocess.CalledProcessError:
                    pass

            try:
                self.runner.run(action.command, check=True)
                results.append((action, True))
            except subprocess.CalledProcessError:
                results.append((action, False))

        return results

    # ------------------------------------------------------------------
    # Planning methods
    # ------------------------------------------------------------------

    def _plan_users(self) -> list[SetupAction]:
        """Create system accounts for deploy and app users."""
        users: dict[str, str] = {}

        # Global deploy user
        deploy_user = self.config.scaffold.deploy_user
        users[deploy_user] = "deploy user"

        # Per-environment users
        for fraise_name, env_name, env_config in self._iter_fraise_environments():
            env_deploy = env_config.get("deploy_user")
            if env_deploy and env_deploy not in users:
                users[env_deploy] = f"deploy user ({env_name})"

            svc = env_config.get("service", {})
            app_user = svc.get("user") if isinstance(svc, dict) else None
            if app_user and app_user not in users:
                users[app_user] = f"app user ({fraise_name}/{env_name})"

        actions: list[SetupAction] = []
        for user, desc in users.items():
            actions.append(
                SetupAction(
                    description=f"Create {desc}: {user}",
                    command=[
                        "sudo",
                        "useradd",
                        "--system",
                        "--create-home",
                        "--shell",
                        "/usr/sbin/nologin",
                        user,
                    ],
                    check=["id", "-u", user],
                    category="user",
                )
            )
        return actions

    def _plan_directories(self) -> list[SetupAction]:
        deploy_user = self.config.scaffold.deploy_user
        managed_dirs = [
            ("/var/lib/fraisier", deploy_user),
            ("/var/lib/fraisier/repos", deploy_user),
            ("/var/lib/fraisier/status", deploy_user),
            ("/run/fraisier", deploy_user),
        ]
        root_dirs = [
            ("/etc/fraisier", None),
        ]

        actions: list[SetupAction] = []
        for path, owner in [*managed_dirs, *root_dirs]:
            actions.append(
                SetupAction(
                    description=f"Create {path}",
                    command=["sudo", "mkdir", "-p", path],
                    check=["test", "-d", path],
                    category="directory",
                )
            )
            if owner:
                actions.append(
                    SetupAction(
                        description=f"Set ownership of {path} to {owner}",
                        command=["sudo", "chown", f"{owner}:{owner}", path],
                        category="directory",
                    )
                )
        return actions

    def _plan_app_permissions(self) -> list[SetupAction]:
        """Configure ownership when app_user differs from deploy_user."""
        actions: list[SetupAction] = []
        for _, _, env_config in self._iter_fraise_environments():
            app_path = env_config.get("app_path")
            if not app_path:
                continue

            svc = env_config.get("service", {})
            app_user = svc.get("user") if isinstance(svc, dict) else None
            deploy_user = env_config.get(
                "deploy_user", self.config.scaffold.deploy_user
            )

            if app_user and app_user != deploy_user:
                actions.append(
                    SetupAction(
                        description=f"Set {app_path} ownership to {app_user}",
                        command=[
                            "sudo",
                            "chown",
                            "-R",
                            f"{app_user}:{app_user}",
                            app_path,
                        ],
                        category="permissions",
                    )
                )
                actions.append(
                    SetupAction(
                        description=(f"Add {deploy_user} to {app_user} group"),
                        command=[
                            "sudo",
                            "usermod",
                            "-aG",
                            app_user,
                            deploy_user,
                        ],
                        category="permissions",
                    )
                )
                actions.append(
                    SetupAction(
                        description=f"Set group write on {app_path}",
                        command=["sudo", "chmod", "g+rwx", app_path],
                        category="permissions",
                    )
                )
            else:
                actions.append(
                    SetupAction(
                        description=(f"Set {app_path} ownership to {deploy_user}"),
                        command=[
                            "sudo",
                            "chown",
                            "-R",
                            f"{deploy_user}:{deploy_user}",
                            app_path,
                        ],
                        category="permissions",
                    )
                )
        return actions

    def _plan_git_safe_directory(self) -> list[SetupAction]:
        """Add git safe.directory entries for deploy user when users differ."""
        actions: list[SetupAction] = []
        seen: set[tuple[str, str]] = set()
        for _, _, env_config in self._iter_fraise_environments():
            svc = env_config.get("service", {})
            app_user = svc.get("user") if isinstance(svc, dict) else None
            deploy_user = env_config.get(
                "deploy_user", self.config.scaffold.deploy_user
            )

            if not app_user or app_user == deploy_user:
                continue

            git_repo = env_config.get("git_repo")
            if not git_repo:
                continue

            paths = [git_repo]
            app_path = env_config.get("app_path")
            if app_path:
                paths.append(app_path)

            for path in paths:
                key = (deploy_user, path)
                if key in seen:
                    continue
                seen.add(key)
                actions.append(
                    SetupAction(
                        description=(
                            f"Add {path} to git safe.directory for {deploy_user}"
                        ),
                        command=[
                            "sudo",
                            "-u",
                            deploy_user,
                            "git",
                            "config",
                            "--global",
                            "--add",
                            "safe.directory",
                            path,
                        ],
                        category="git",
                    )
                )
        return actions

    def _plan_symlinks(self) -> list[SetupAction]:
        actions: list[SetupAction] = []
        seen: set[str] = set()
        project = self.config.project_name
        for fraise_name, env_name, env_config in self._iter_fraise_environments():
            git_repo = env_config.get("git_repo")
            if not git_repo:
                continue
            repo_name = f"{project}_{fraise_name}_{env_name}"
            link_name = f"/var/lib/fraisier/repos/{repo_name}.git"
            if link_name in seen:
                continue
            seen.add(link_name)
            # Check if symlink already points to the correct target.
            # Prevents overwriting existing non-symlink directories
            # (e.g., bare repos) which would break existing deployments.
            actions.append(
                SetupAction(
                    description=f"Symlink {git_repo} -> {link_name}",
                    command=["sudo", "ln", "-sfn", git_repo, link_name],
                    check=[
                        "bash",
                        "-c",
                        f'[ -L "{link_name}" ] && '
                        f'[ "$(readlink "{link_name}")" = "{git_repo}" ]',
                    ],
                    category="symlink",
                )
            )
        return actions

    def _plan_sudoers(self) -> list[SetupAction]:
        output_dir = self.config.scaffold.output_dir
        project = self.config.project_name
        src = f"{output_dir}/sudoers"
        dst = f"/etc/sudoers.d/{project}"
        return [
            SetupAction(
                description="Install sudoers fragment for deploy user",
                command=["sudo", "install", "-m", "0440", src, dst],
                category="sudoers",
            ),
        ]

    def _plan_app_services(self) -> list[SetupAction]:
        output_dir = self.config.scaffold.output_dir
        project = self.config.project_name
        actions: list[SetupAction] = []
        for fraise_name, env_name, env_config in self._iter_fraise_environments():
            generated = f"{project}_{fraise_name}_{env_name}.service"
            svc = env_config.get("systemd_service", generated)
            src = f"{output_dir}/systemd/{generated}"
            dst = f"/etc/systemd/system/{svc}"
            actions.append(
                SetupAction(
                    description=f"Install {svc}",
                    command=["sudo", "cp", src, dst],
                    category="systemd",
                )
            )
        return actions

    def _plan_webhook_service(self) -> list[SetupAction]:
        output_dir = self.config.scaffold.output_dir
        project = self.config.project_name
        svc_name = f"fraisier-{project}-webhook.service"
        src = f"{output_dir}/{svc_name}"
        dst = f"/etc/systemd/system/{svc_name}"
        return [
            SetupAction(
                description=f"Install {svc_name}",
                command=["sudo", "cp", src, dst],
                category="systemd",
            )
        ]

    def _plan_env_files(self) -> list[SetupAction]:
        output_dir = self.config.scaffold.output_dir
        project = self.config.project_name
        env_file = f"fraisier-{project}.webhook.env"
        src = f"{output_dir}/{env_file}"
        dst = f"/etc/fraisier/{project}.webhook.env"
        return [
            SetupAction(
                description="Install webhook env file",
                command=["sudo", "install", "-m", "0640", src, dst],
                check=["test", "-f", dst],
                category="env",
            )
        ]

    def _plan_nginx(self) -> list[SetupAction]:
        output_dir = self.config.scaffold.output_dir
        actions: list[SetupAction] = []

        # Gateway config
        project_name = self._infer_project_name()
        gw_src = f"{output_dir}/nginx/gateway.conf"
        gw_dst = f"/etc/nginx/sites-available/{project_name}"
        actions.append(
            SetupAction(
                description="Install nginx gateway config",
                command=["sudo", "cp", gw_src, gw_dst],
                category="nginx",
            )
        )
        actions.append(
            SetupAction(
                description="Enable nginx gateway config",
                command=[
                    "sudo",
                    "ln",
                    "-sfn",
                    gw_dst,
                    f"/etc/nginx/sites-enabled/{project_name}",
                ],
                category="nginx",
            )
        )

        # Per-environment configs
        project = self.config.project_name
        for fraise_name, env_name, env_config in self._iter_fraise_environments():
            nginx_config = NginxEnvConfig.from_env_dict(env_config)
            if nginx_config is None:
                continue
            conf_name = f"{project}_{fraise_name}_{env_name}"
            src = f"{output_dir}/nginx/{conf_name}.conf"
            dst = f"/etc/nginx/sites-available/{conf_name}"
            actions.append(
                SetupAction(
                    description=f"Install nginx config for {conf_name}",
                    command=["sudo", "cp", src, dst],
                    category="nginx",
                )
            )
            actions.append(
                SetupAction(
                    description=f"Enable nginx config for {conf_name}",
                    command=[
                        "sudo",
                        "ln",
                        "-sfn",
                        dst,
                        f"/etc/nginx/sites-enabled/{conf_name}",
                    ],
                    category="nginx",
                )
            )

        return actions

    def _plan_systemd_reload(self) -> list[SetupAction]:
        project_name = self.config.project_name
        actions = [
            SetupAction(
                description="Reload systemd daemon",
                command=["sudo", "systemctl", "daemon-reload"],
                category="systemd",
            ),
            SetupAction(
                description=f"Enable fraisier-{project_name}-webhook.service",
                command=[
                    "sudo",
                    "systemctl",
                    "enable",
                    f"fraisier-{project_name}-webhook.service",
                ],
                category="systemd",
            ),
        ]
        project = self.config.project_name
        for fraise_name, env_name, env_config in self._iter_fraise_environments():
            generated = f"{project}_{fraise_name}_{env_name}.service"
            svc = env_config.get("systemd_service", generated)
            actions.append(
                SetupAction(
                    description=f"Enable {svc}",
                    command=["sudo", "systemctl", "enable", svc],
                    category="systemd",
                )
            )
        return actions

    def _plan_validation(self) -> list[SetupAction]:
        actions = [
            SetupAction(
                description="Test nginx configuration",
                command=["sudo", "nginx", "-t"],
                category="validate",
            ),
        ]
        for _, _, env_config in self._iter_fraise_environments():
            git_repo = env_config.get("git_repo")
            if git_repo:
                actions.append(
                    SetupAction(
                        description=f"Verify bare repo exists: {git_repo}",
                        command=["test", "-d", git_repo],
                        category="validate",
                    )
                )
        return actions

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _resolve_allowed_environments(self) -> set[str] | None:
        """Determine which environments to provision.

        Resolution order:
        1. Explicit ``--environment`` → single environment.
        2. Explicit ``--server`` → environments whose ``server`` field matches.
        3. Auto-detect via hostname/FQDN → environments whose ``server`` matches.
        4. No match → ``None`` (provision everything, backwards-compatible).
        """
        if self.environment:
            return {self.environment}

        if self.server:
            envs = self.config.get_environments_for_server(self.server)
            return set(envs) if envs else None

        # Auto-detect: try FQDN first, then short hostname.
        hostnames = list(dict.fromkeys([socket.getfqdn(), socket.gethostname()]))
        for hostname in hostnames:
            envs = self.config.get_environments_for_server(hostname)
            if envs:
                return set(envs)

        logger.warning(
            "No server match for hostname(s) %s — provisioning all environments. "
            "Use --server or --environment to filter, or set 'server' in your "
            "environments config.",
            hostnames,
        )
        return None

    def _iter_fraise_environments(
        self,
    ) -> Iterator[tuple[str, str, dict[str, Any]]]:
        """Yield (fraise_name, env_name, env_config), filtered by server/environment."""
        allowed = self._resolve_allowed_environments()
        for fraise_name in self.config.list_fraises():
            fraise = self.config.get_fraise(fraise_name)
            if not fraise:
                continue
            for env_name in fraise.get("environments", {}):
                if allowed is not None and env_name not in allowed:
                    continue
                env_config = self.config.get_fraise_environment(fraise_name, env_name)
                if env_config:
                    yield fraise_name, env_name, env_config

    def _infer_project_name(self) -> str:
        return self.config.project_name

    def _write_env_file(self) -> None:
        """Write webhook env file to scaffold output dir."""
        secret = secrets.token_urlsafe(32)
        config_path = self.config.config_path

        content = (
            "# Fraisier webhook environment\n"
            "# Generated by fraisier setup — edit secrets as needed\n"
            f"FRAISIER_WEBHOOK_SECRET={secret}\n"
            f"FRAISIER_CONFIG={config_path}\n"
            "FRAISIER_PORT=8080\n"
            "FRAISIER_DB_PATH=/var/lib/fraisier/fraisier.db\n"
        )
        project = self.config.project_name
        env_filename = f"fraisier-{project}.webhook.env"
        output = Path(self.config.scaffold.output_dir) / env_filename
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(content)
