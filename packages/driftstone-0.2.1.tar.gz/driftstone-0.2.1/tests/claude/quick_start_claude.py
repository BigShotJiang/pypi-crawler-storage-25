from pathlib import Path
from driftstone import Driftstone

CURRENT_USER = "stephen@pickaxe.co"

client = Driftstone(api_key="dk-661f7eb4-ee24-4f73-96c4-2dc0d283a236")

config_folder = str(Path(__file__).resolve().parent / ".claude")

# client.app.delete("app-1f632fd1-6cd0-4540-8999-a337aff24def")

# app = client.app.retrieve(slug="Chat_Z1H90")

# app = client.app.init("typedef-app", 
#     type="claude",
#     version_path=config_folder,
#     auto_update_version=False
# )

# app.version.clone(transform={
#     "agent.json": {
#         "description": "This is a modified description for the agent2.",
#     }
# })

# app.version.clone(transform={
#     "agent.json": {
#         "mcp_servers": {
#             "$by": "name",
#             "$patch": {
#                 "pickaxe": {
#                     "url": "https://new-url.example/mcp"
#                 }
#             }
#         },
#     }
# })

# app.version.sync()

# channel = app.channel.init("my-api", 
#     type="api",
# )

# channel = app.channel.init("my-api", 
#     type="imessage",
#     data={
#         "sendBlueAPIKey": "daf846bdbbd2d193ecc321162ab9ac4c",
#         "sendBlueSecretKey": "6f82d691172cb99fc3bb4ac2a639a242",
#         "fromNumber": "+17862139363",
#     },
# )

# profile = app.profile.init(
#     identifier=CURRENT_USER,
#     auto_update_state=False,
# )

# profile.state.clone(transform={
#     "agent.json": {
#         "description": "Test 3",
#     }
# })

# stream = channel.run(
#     session_id="my-custom-session-id",
#     user_id=CURRENT_USER, 
#     input="Hello"
# )

# for event in stream:
#     if event.done:
#         break

#     print(event)

# channel = app.channel.init("my-imessage", type="imessage", data={
#     "sendBlueAPIKey": "daf846bdbbd2d193ecc321162ab9ac4c",
#     "sendBlueSecretKey": "6f82d691172cb99fc3bb4ac2a639a242",
#     "fromNumber": "+17862139363",
# })
