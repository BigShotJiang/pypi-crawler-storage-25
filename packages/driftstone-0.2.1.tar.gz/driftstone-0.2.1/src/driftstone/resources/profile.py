from __future__ import annotations

import base64
from pathlib import Path
from typing import Any, Optional

from ..exceptions import DriftstoneError
from ..models.profile import DriftstoneProfileModel
from ._base import AppBase
from .state import DriftstoneState

class DriftstoneProfile(AppBase):
    def init(
        self, 
        identifier: str,
        *,
        state_path: Optional[str] = None,
        access_group_id: Optional[str] = None,
        auto_update_state: bool = True,
    ) -> DriftstoneProfileModel:
        trimmed_identifier = identifier.strip()
        if not trimmed_identifier:
            raise DriftstoneError("identifier must be a non-empty string")

        if state_path is not None and (not isinstance(state_path, str) or not state_path.strip()):
            raise DriftstoneError("state_path must be a non-empty string")
        
        if access_group_id is not None and (not isinstance(access_group_id, str) or not access_group_id.strip()):
            raise DriftstoneError("name must be a non-empty string")

        payload: dict[str, Any] = {
            "appId": self._app_id,
            "identifier": trimmed_identifier,
            "autoUpdateState": auto_update_state,
        }
        zip_path: Path | None = None
        if state_path is not None:
            path_data = DriftstoneState._validate_state_path(state_path)
            try:
                zip_path, _sha256 = DriftstoneState._build_zip(path_data["path"])
                payload["base64"] = base64.b64encode(zip_path.read_bytes()).decode("ascii")
            finally:
                if zip_path and zip_path.exists():
                    zip_path.unlink()

        if access_group_id is not None:
            payload["accessGroupId"] = access_group_id.strip()

        profile_res = self._client._request("POST", "/profile/init", payload)
        profile_id = profile_res["data"]["id"]
        state = DriftstoneState(self._client, self._app_id, profile_id)

        return DriftstoneProfileModel._from_api(
            profile_res["data"], 
            state=state,
        )
    
    def retrieve(self, profile_id: str) -> DriftstoneProfileModel:
        try:
            if not profile_id or not isinstance(profile_id, str):
                raise Exception("profile_id must be a non-empty string")
        
            profile_res = self._client._request("GET", f"/profile/{profile_id}")
            
            state = DriftstoneState(self._client, self._app_id, profile_res["data"]["id"])

            return DriftstoneProfileModel._from_api(
                profile_res["data"], 
                state=state,
            )
        except DriftstoneError:
            return None
        except Exception as e:
            raise e
     
    def state(self, profile_id: str) -> DriftstoneState:
        trimmed_profile_id = profile_id.strip()
        if not profile_id:
            raise DriftstoneError("profile_id must be a non-empty string")
        return DriftstoneState(self._client, self._app_id, trimmed_profile_id)
