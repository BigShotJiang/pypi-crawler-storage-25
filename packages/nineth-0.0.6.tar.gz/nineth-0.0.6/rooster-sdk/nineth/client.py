"""Python client for the 1984 model API."""

from __future__ import annotations

import json
import os
from typing import Any, AsyncIterator, Dict, Iterator, Optional

import httpx


DEFAULT_TIMEOUT = 60.0
DEFAULT_BASE_URL = "https://weirdpablo--rooster-api.modal.run"
API_KEY_HEADER = "X-API-Key"


class NinethAPIError(RuntimeError):
    """Raised when the Nineth API returns an unexpected response."""


def build_payload(
    task_input: str,
    *,
    model_name: Optional[str] = None,
    services: bool = True,
    service_names: Optional[list[str]] = None,
    cache: bool = True,
    max_iterations: int = 50,
    reasoning_effort: str = "low",
    process_id: Optional[str] = None,
    user_id: Optional[str] = None,
    debug: bool = False,
    continuous: bool = False,
    images: Optional[list[str]] = None,
    system_prompt: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "task_input": task_input,
        "model_name": model_name,
        "services": services,
        "service_names": service_names,
        "cache": cache,
        "max_iterations": max_iterations,
        "reasoning_effort": reasoning_effort,
        "process_id": process_id,
        "user_id": user_id,
        "debug": debug,
        "continuous": continuous,
        "images": images,
        "system_prompt": system_prompt,
    }
    if extra:
        payload.update(extra)
    return {key: value for key, value in payload.items() if value is not None}


def _raise_for_status(response: httpx.Response) -> None:
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        message = response.text.strip() or str(exc)
        raise NinethAPIError(message) from exc


def _parse_sse_lines(lines: Iterator[str]) -> Iterator[Dict[str, Any]]:
    event_type = "message"
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line.rstrip("\r")
        if not line:
            if data_lines:
                payload = json.loads("\n".join(data_lines))
                payload.setdefault("type", event_type)
                yield payload
            event_type = "message"
            data_lines = []
            continue

        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_type = line.split(":", 1)[1].strip()
            continue
        if line.startswith("data:"):
            data_lines.append(line.split(":", 1)[1].strip())

    if data_lines:
        payload = json.loads("\n".join(data_lines))
        payload.setdefault("type", event_type)
        yield payload


class NinethClient:
    """Synchronous client for the Nineth API."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        if not resolved_base_url:
            raise ValueError("A base_url or NINETH_BASE_URL environment variable is required.")

        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")
        request_headers = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=request_headers or None,
        )

    def _ensure_api_key(self) -> None:
        if not self.api_key and API_KEY_HEADER not in self._client.headers:
            raise ValueError("An api_key or NINETH_API_KEY environment variable is required.")

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "NinethClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def health(self) -> Dict[str, Any]:
        response = self._client.get("/health")
        _raise_for_status(response)
        return response.json()

    def invoke(self, task_input: str, **kwargs: Any) -> Dict[str, Any]:
        self._ensure_api_key()
        payload = build_payload(task_input, **kwargs)
        response = self._client.post("/model", json=payload)
        _raise_for_status(response)
        return response.json()

    def stream(self, task_input: str, **kwargs: Any) -> Iterator[Dict[str, Any]]:
        self._ensure_api_key()
        payload = build_payload(task_input, **kwargs)
        with self._client.stream("POST", "/model/stream", json=payload) as response:
            _raise_for_status(response)
            yield from _parse_sse_lines(response.iter_lines())


class AsyncNinethClient:
    """Asynchronous client for the Nineth API."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        if not resolved_base_url:
            raise ValueError("A base_url or NINETH_BASE_URL environment variable is required.")

        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")
        request_headers = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers=request_headers or None,
        )

    def _ensure_api_key(self) -> None:
        if not self.api_key and API_KEY_HEADER not in self._client.headers:
            raise ValueError("An api_key or NINETH_API_KEY environment variable is required.")

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncNinethClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    async def health(self) -> Dict[str, Any]:
        response = await self._client.get("/health")
        _raise_for_status(response)
        return response.json()

    async def invoke(self, task_input: str, **kwargs: Any) -> Dict[str, Any]:
        self._ensure_api_key()
        payload = build_payload(task_input, **kwargs)
        response = await self._client.post("/model", json=payload)
        _raise_for_status(response)
        return response.json()

    async def stream(self, task_input: str, **kwargs: Any) -> AsyncIterator[Dict[str, Any]]:
        self._ensure_api_key()
        payload = build_payload(task_input, **kwargs)
        async with self._client.stream("POST", "/model/stream", json=payload) as response:
            _raise_for_status(response)
            event_type = "message"
            data_lines: list[str] = []

            async for raw_line in response.aiter_lines():
                line = raw_line.rstrip("\r")
                if not line:
                    if data_lines:
                        payload = json.loads("\n".join(data_lines))
                        payload.setdefault("type", event_type)
                        yield payload
                    event_type = "message"
                    data_lines = []
                    continue

                if line.startswith(":"):
                    continue
                if line.startswith("event:"):
                    event_type = line.split(":", 1)[1].strip()
                    continue
                if line.startswith("data:"):
                    data_lines.append(line.split(":", 1)[1].strip())

            if data_lines:
                payload = json.loads("\n".join(data_lines))
                payload.setdefault("type", event_type)
                yield payload
