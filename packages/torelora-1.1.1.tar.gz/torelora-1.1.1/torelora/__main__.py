"""
TOREloRA v1.1.1 — Komut Satırı Arayüzü
TORE TEKNOLOJİ & ARAŞTIRMA — MIT Lisansı

Kullanım:
    torelora              → Ortam kontrolü + tüm demo'lar
    torelora-check        → Sadece ortam kontrolü
    python -m torelora    → Aynı (torelora ile)
"""
from __future__ import annotations

import sys


def check() -> None:
    """Sadece ortam ve bağımlılık kontrolü."""
    from torelora.core import check_environment
    check_environment(auto_install=False)


def main() -> None:
    """Tam demo: ortam + tüm bileşen testleri."""
    from torelora.core import (
        check_environment,
        demo_asgp_v2,
        demo_ssyp,
        demo_corap20,
        demo_omnisync,
        demo_bbgh,
        demo_simple_config,
        __version__,
    )

    args = sys.argv[1:]

    # --help / -h
    if any(a in ("-h", "--help") for a in args):
        print(f"""
TOREloRA v{__version__}  —  TORE TEKNOLOJİ & ARAŞTIRMA

Kullanım:
  torelora                  Ortam kontrolü + tüm demo'lar
  torelora --check          Sadece ortam/bağımlılık kontrolü
  torelora --demo asgp      Sadece ASGP v2 demo
  torelora --demo ssyp      Sadece SSYP demo
  torelora --demo corap20   Sadece CORAP20 demo
  torelora --demo omnisync  Sadece OmniSync demo
  torelora --demo bbgh      Sadece BBGH demo
  torelora --demo config    Sadece SimpleConfig demo
  torelora --version        Sürüm bilgisi
  torelora --help           Bu yardım mesajı

Python API:
  from torelora import TOREloRA, TOREloRAConfig, SimpleConfig
  tl = TOREloRA("mistralai/Mistral-7B-v0.3")
  model, tok = tl.load()
  trainer = tl.get_trainer(dataset)
  tl.train(trainer)
""")
        return

    # --version / -v
    if any(a in ("-v", "--version") for a in args):
        print(f"TOREloRA v{__version__}")
        return

    # --check
    if "--check" in args:
        check()
        return

    # --demo <name>
    if "--demo" in args:
        idx = args.index("--demo")
        name = args[idx + 1].lower() if idx + 1 < len(args) else ""
        _DEMOS = {
            "asgp":     demo_asgp_v2,
            "ssyp":     demo_ssyp,
            "corap20":  demo_corap20,
            "omnisync": demo_omnisync,
            "bbgh":     demo_bbgh,
            "config":   demo_simple_config,
        }
        fn = _DEMOS.get(name)
        if fn is None:
            print(f"[TOREloRA] Bilinmeyen demo: '{name}'. "
                  f"Seçenekler: {', '.join(_DEMOS)}")
            sys.exit(1)
        fn()
        return

    # Varsayılan: tam demo
    check_environment()
    demo_asgp_v2()
    demo_ssyp()
    demo_corap20()
    demo_omnisync()
    demo_bbgh()
    demo_simple_config()


if __name__ == "__main__":
    main()
