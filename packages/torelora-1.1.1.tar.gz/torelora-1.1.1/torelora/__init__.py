"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  TOREloRA  v1.1.1  "THE REAL AGI" 🌐⚡🧠                                   ║
║  TORE TEKNOLOJİ & ARAŞTIRMA  —  MIT Lisansı                                ║
║  Ömür Bera Işık & TORE Teknoloji Ekibi                                      ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from torelora.core import (
    # Sürüm bilgisi
    __version__,
    __author__,
    __license__,

    # Ana sınıflar
    TOREloRA,
    TOREloRAConfig,
    FastLoRA,
    FastLoRAConfig,

    # Teknoloji bileşenleri
    ASGPv2,
    ASGPv3,
    SSYP,
    SSYPDataset,
    CORAP20Engine,
    StreamingCORAP20Loader,
    T4TrillionEngine,
    ParamMesh,
    GeometricResonance,
    HolographicFold,
    AsyncSingularity,
    QuantumGradCollapse,
    OmniSync,
    BBGHEngine,
    BBGHMemoryCell,
    AGCoreEngine,
    MNJHEngine,
    BackpropEngine,

    # Yapılandırma & Yardımcılar
    SimpleConfig,
    ZeroFault,
    ErrorReport,
    AutoInstaller,
    DeviceManager,
    HFBridge,
    XLAHelper,

    # Formatlayıcılar
    format_alpaca,
    format_chatml,

    # Çevre kontrolü & Demo fonksiyonları
    check_environment,
    demo_asgp_v2,
    demo_ssyp,
    demo_corap20,
    demo_omnisync,
    demo_bbgh,
    demo_simple_config,
)

__all__ = [
    # Sürüm
    "__version__", "__author__", "__license__",

    # Ana
    "TOREloRA", "TOREloRAConfig", "FastLoRA", "FastLoRAConfig",

    # Teknoloji
    "ASGPv2", "ASGPv3",
    "SSYP", "SSYPDataset",
    "CORAP20Engine", "StreamingCORAP20Loader", "T4TrillionEngine",
    "ParamMesh",
    "GeometricResonance", "HolographicFold", "AsyncSingularity",
    "QuantumGradCollapse", "OmniSync",
    "BBGHEngine", "BBGHMemoryCell",
    "AGCoreEngine",
    "MNJHEngine",
    "BackpropEngine",

    # Yardımcılar
    "SimpleConfig", "ZeroFault", "ErrorReport", "AutoInstaller",
    "DeviceManager", "HFBridge", "XLAHelper",

    # Formatlayıcılar
    "format_alpaca", "format_chatml",

    # Fonksiyonlar
    "check_environment",
    "demo_asgp_v2", "demo_ssyp", "demo_corap20",
    "demo_omnisync", "demo_bbgh", "demo_simple_config",
]
