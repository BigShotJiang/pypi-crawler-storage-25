"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  TOREloRA  v1.1.1  "THE REAL AGI" 🌐⚡🧠  (Genesis Reborn)              ║
║  TORE TEKNOLOJİ & ARAŞTIRMA  —  MIT Lisansı                                ║
║  Ömür Bera Işık & TORE Teknoloji Ekibi                                      ║
║                                                                              ║
║  v1.0.5 — Nihai Stabilite: ZeroFault v2 · ASGP v3 · BBGH AGI v2 · OMNISYNC+ ║
║                                                                              ║
║  Temel Teknolojiler:                                                         ║
║  🌊 SSYP    — Simultaneous Synchronized Yield Pipeline                      ║
║  🔮 CORAP20 — Hibrit 2-Bit Dinamik Bilgi Ekosistemi (Universal & Streaming) ║
║  ⚡ ASGP v3 — v2 + otonom boru / güvenli arka plan, darboğaz azaltma        ║
║  🧬 ParamMesh— Parametreler arası canlı bilgi takas ağı                    ║
║  🛡️  ZeroFault v2 — Sarsılmaz kararlılık, otomatik grad onarım, limitler   ║
║  🌐 OMNISYNC+ — resonance_level · agi_core tek satırda                     ║
║  🧠 BBGH AGI — Bilişsel sessizlik raporu · sentetik muhakeme katmanı    ║
║  🚀 StreamingCORAP20Loader · 🔬 T4TrillionEngine · ⚙️ SimpleConfig          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

# ── Temel imports ─────────────────────────────────────────────────────────────
import gc, hashlib, json, logging, math, mmap, os, queue, struct, sys
import threading, time, traceback, warnings
from collections import deque, OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple, Union

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [TOREloRA] %(levelname)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("TOREloRA")
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

__version__  = "1.1.1"
__author__   = "TORE TEKNOLOJİ & ARAŞTIRMA — Ömür Bera Işık"
__license__  = "MIT"

# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 0 — OTOMATİK PAKET KURUCUSU
# ══════════════════════════════════════════════════════════════════════════════

class AutoInstaller:
    """Eksik paketi bulunca sessizce kurar. Başarısız olursa çökmeden devam eder."""
    _ok: set = set(); _bad: set = set(); _lock = threading.Lock()
    _PIP: Dict[str, str] = {
        "torch":         "torch>=2.1.0",
        "transformers":  "transformers>=4.40.0",
        "accelerate":    "accelerate>=0.27.0",
        "peft":          "peft>=0.10.0",
        "bitsandbytes":  "bitsandbytes>=0.43.0",
        "trl":           "trl>=0.8.0",
        "datasets":      "datasets",
        "triton":        "triton",
        "deepspeed":     "deepspeed",
        "optuna":        "optuna",
        "flash_attn":    "flash-attn --no-build-isolation",
        "torch_xla":     "torch_xla[tpu]",
        "numpy":         "numpy",
        "psutil":        "psutil",
        "matplotlib":    "matplotlib",
        "wandb":         "wandb",
        "tensorboard":   "tensorboard",
        "safetensors":   "safetensors",
        "sentencepiece": "sentencepiece",
    }

    @classmethod
    def ensure(cls, pkg: str, silent: bool = True) -> bool:
        if pkg in cls._ok:  return True
        if pkg in cls._bad: return False
        try:
            __import__(pkg)
            with cls._lock: cls._ok.add(pkg)
            return True
        except ImportError:
            pass
        pip_name = cls._PIP.get(pkg, pkg)
        if not silent:
            logger.info(f"AutoInstall  : {pkg} yok → kuruluyor ({pip_name})…")
        try:
            import subprocess
            r = subprocess.run(
                [sys.executable, "-m", "pip", "install", "--quiet",
                 "--break-system-packages"] + pip_name.split(),
                capture_output=True, text=True, timeout=300,
            )
            if r.returncode == 0:
                try:
                    __import__(pkg)
                    with cls._lock: cls._ok.add(pkg)
                    if not silent: logger.info(f"AutoInstall  : ✓  {pkg}")
                    return True
                except ImportError:
                    pass
        except Exception:
            pass
        with cls._lock: cls._bad.add(pkg)
        return False

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.autograd import Function
except ImportError:
    AutoInstaller.ensure("torch", silent=False)
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.autograd import Function

_TV             = tuple(int(x) for x in torch.__version__.split(".")[:2])
_HAS_COMPILE    = _TV >= (2, 0)
_HAS_SDPA       = hasattr(F, "scaled_dot_product_attention")
_HAS_FUSED_ADAM = _TV >= (2, 0)

# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 1 — HATA YÖNETIMI & DAYANIKLI YÜRÜTÜCÜ (ZeroFault v2)
# ══════════════════════════════════════════════════════════════════════════════

class ZeroFault:
    """
    ZeroFault v2 — süreç durmasın diye sınırlar + otomatik onarım kancaları.

    - Geçmiş boyutu üst sınırlı (bellek taşması yok).
    - Aynı hatanın spam'i azaltılır; tekrar sayacı tutulur.
    - İsteğe bağlı: gradyan normu ani sıçramasında yumuşatma (autorepair).
    """
    _hist:  List[Dict] = []
    _seen:  set        = set()
    _repeat: Dict[str, int] = {}
    _lock               = threading.Lock()
    MAX_HIST            = 4096
    MAX_REPEAT_WARN     = 50
    autorepair_grad:    bool = True
    grad_spike_factor:  float = 12.0

    @classmethod
    def _trim_hist(cls) -> None:
        if len(cls._hist) > cls.MAX_HIST:
            cls._hist = cls._hist[-(cls.MAX_HIST // 2) :]

    @classmethod
    def report(cls, etype: str, what: str, why: str = "", fix: str = "",
               exc: Exception = None, fatal: bool = False) -> None:
        key = f"{etype}:{what[:50]}"
        with cls._lock:
            cls._repeat[key] = cls._repeat.get(key, 0) + 1
            rep = cls._repeat[key]
            if key in cls._seen and not fatal:
                if rep > cls.MAX_REPEAT_WARN and rep % 100 != 0:
                    return
            cls._seen.add(key)
            cls._hist.append({
                "t": time.strftime("%H:%M:%S"), "type": etype,
                "what": what, "why": why, "repeat": rep,
            })
            cls._trim_hist()
        b = "═" * 60
        logger.error(f"\n{b}\n  ❌  {etype}\n  📋  {what}")
        if why: logger.error(f"  🔍  {why}")
        if fix: logger.error(f"  🔧  {fix}")
        if exc: logger.error(f"  💬  {str(exc)[:120]}")
        logger.error(b)
        if fatal: raise RuntimeError(f"[TOREloRA] {what}")

    @classmethod
    def run(cls, fn: Callable, *args,
            default=None, etype="OP", what="", **kw) -> Any:
        """Fonksiyonu çalıştır — hata olursa default döndür."""
        try:
            return fn(*args, **kw)
        except KeyboardInterrupt:
            raise
        except SystemExit:
            raise
        except BaseException as e:
            if not isinstance(e, Exception):
                raise
            cls.report(etype, what or getattr(fn, "__name__", "fn"),
                       str(e)[:80], exc=e)
            return default

    @classmethod
    def wrap(cls, fn: Callable, default=None, etype="OP") -> Callable:
        def wrapped(*a, **kw):
            return cls.run(fn, *a, default=default, etype=etype,
                           what=fn.__name__)
        return wrapped

    @classmethod
    def maybe_repair_gradients(cls, model: "nn.Module",
                                prev_norm: Optional[float] = None) -> Optional[float]:
        """
        Gradient normunda ani sıçrama varsa yumuşat (yıkıcı olmayan).
        prev_norm None ise sadece mevcut normu döndürür.
        """
        if not cls.autorepair_grad:
            return None
        try:
            total = 0.0
            for p in model.parameters():
                if p.grad is None:
                    continue
                total += float(p.grad.data.float().norm() ** 2)
            gnorm = math.sqrt(total) if total > 0 else 0.0
            if prev_norm is not None and prev_norm > 1e-12 and gnorm > prev_norm * cls.grad_spike_factor:
                scale = (prev_norm * cls.grad_spike_factor) / max(gnorm, 1e-12)
                for p in model.parameters():
                    if p.grad is not None:
                        p.grad.data.mul_(scale)
                logger.warning(
                    f"ZeroFault v2 : grad spike yumuşatıldı ({gnorm:.3f}→~{prev_norm * cls.grad_spike_factor:.3f})"
                )
                return prev_norm * cls.grad_spike_factor
            return gnorm
        except Exception as e:
            cls.report("ZF2_GRAD", "grad onarımı atlandı", str(e)[:80], exc=e)
            return prev_norm

    @classmethod
    def summary(cls):
        n = len(cls._hist)
        logger.info(f"ZeroFault v2 : {'✓ Hiç hata yok' if n==0 else f'{n} kayıt'}")

    @classmethod
    def save(cls, path: str):
        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            Path(path).write_text(
                json.dumps(cls._hist, ensure_ascii=False, indent=2))
        except Exception:
            pass

    @classmethod
    def reset_session(cls) -> None:
        """Test / yeni koşu için geçmişi temizle."""
        with cls._lock:
            cls._hist.clear()
            cls._seen.clear()
            cls._repeat.clear()


# Geriye uyumluluk için alias
ErrorReport = ZeroFault


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 2 — ASGP v2: ASYNC STREAM GRAD PIPE
# ══════════════════════════════════════════════════════════════════════════════

class ASGPv2:
    """
    ASGP v2 — Async Stream Grad Pipe  ⚡

    Milyarlarca adım/saniye kapasitesi — model boyutu fark etmez.

    v2 Yenilikleri:
    • Her parametreye FARKLI rastgele veri gider
      (v1'de aynı boru herkese gidiyordu — artık öyle değil)
    • Parametre başına benzersiz PRNG offset
      → iki parametre asla aynı gürültüyü almaz
    • INT8 ring buffer → 4× küçük bellek
    • Arka plan thread boruyu sürekli hazır tutar
    • Adaptif gürültü: plato'da artır, iyileşmede azalt

    Nasıl çalışır:
      Her parametrenin bir "kapısı" var (benzersiz offset + stride).
      Boru döner, her kapı kendi dilimini keser.
      Kapılar çakışmaz → gerçek çeşitlilik.
    """

    def __init__(
        self,
        pipe_mb:       float = 512.0,
        noise:         float = 0.005,
        refresh_every: int   = 2,
        priority:      bool  = True,
        device:        Optional[torch.device] = None,
        dist:          str   = "normal",   # normal|uniform|laplace|cauchy|mixed
        adaptive:      bool  = True,
        async_bg:      bool  = True,
        n_ring:        int   = 4,
        int8:          bool  = True,
        nonblocking:   bool  = True,
        min_noise:     float = 0.00005,
        max_noise:     float = 0.05,
        seed:          Optional[int] = None,
        unique_per_param: bool = True,    # v2: her parametreye farklı veri
    ):
        self.pipe_mb       = pipe_mb
        self.noise         = noise
        self._base_noise   = noise
        self.refresh_every = refresh_every
        self.priority      = priority
        self.device        = device or torch.device("cpu")
        self.dist          = dist
        self.adaptive      = adaptive
        self.int8          = int8
        self.nonblocking   = nonblocking
        self.min_noise     = min_noise
        self.max_noise     = max_noise
        self.unique        = unique_per_param

        if seed is not None:
            torch.manual_seed(seed)
            self._seed = seed
        else:
            self._seed = int(time.time() * 1000) % (2**31)

        bpe         = 1 if int8 else 4
        self.n_elem = int(pipe_mb * 1024 * 1024 / bpe)
        self._n_ring = max(2, n_ring)

        # Ring buffer (CPU RAM)
        dtype = torch.int8 if int8 else torch.float32
        self._ring:        List[torch.Tensor] = [
            torch.zeros(self.n_elem, dtype=dtype) for _ in range(self._n_ring)
        ]
        self._ready:  List[bool]         = [False] * self._n_ring
        self._scales: Dict[int, float]   = {}
        self._idx    = 0
        self._lock   = threading.Lock()

        # Parametre kaydı
        self._reg:   Dict[str, Dict]     = {}
        self._total  = 0

        # Stats
        self._step   = 0
        self._fills  = 0
        self._ms:    deque = deque(maxlen=200)
        self._lwin:  deque = deque(maxlen=40)

        # BG thread
        self._stop   = threading.Event()
        self._bg:    Optional[threading.Thread] = None

        # İlk doldurma
        self._fill(0); self._ready[0] = True
        if async_bg: self._start_bg()

        logger.info(
            f"ASGP v2      : ✓  {pipe_mb:.0f}MB · int8={int8} · "
            f"ring={self._n_ring} · dist={dist} · "
            f"unique_per_param={unique_per_param}"
        )

    # ── İç mekanizma ──────────────────────────────────────────────────────────

    def _sample(self, size: int, rng_offset: int = 0) -> torch.Tensor:
        """Seçilen dağılımdan örnekle. rng_offset ile parametre başına farklı."""
        # Her parametre için farklı PRNG durumu
        g = torch.Generator()
        g.manual_seed((self._seed + rng_offset) % (2**31))

        if self.dist == "normal":
            return torch.randn(size, generator=g) * self.noise
        if self.dist == "uniform":
            return (torch.rand(size, generator=g) * 2 - 1) * self.noise
        if self.dist == "laplace":
            u = torch.rand(size, generator=g).sub_(0.5).mul_(2).clamp(-0.9999, 0.9999)
            return -u.sign() * torch.log1p(-u.abs()) * self.noise * 0.5
        if self.dist == "cauchy":
            return torch.zeros(size).cauchy_(generator=g) * self.noise * 0.1
        if self.dist == "mixed":
            # Yarısı normal, yarısı laplace — daha zengin gürültü
            n = size // 2
            s1 = torch.randn(n, generator=g) * self.noise
            u  = torch.rand(size - n, generator=g).sub_(0.5).mul_(2).clamp(-0.9999, 0.9999)
            s2 = -u.sign() * torch.log1p(-u.abs()) * self.noise * 0.5
            return torch.cat([s1, s2])
        return torch.randn(size, generator=g) * self.noise

    def _fill(self, idx: int, rng_offset: int = 0):
        s = self._sample(self.n_elem, rng_offset)
        if self.int8:
            sc = s.abs().max().clamp(min=1e-8)
            self._ring[idx]   = (s / sc * 127).clamp(-127, 127).to(torch.int8)
            self._scales[idx] = sc.item()
        else:
            self._ring[idx] = s
        self._fills += 1

    def _start_bg(self):
        def worker():
            tick = 0
            while not self._stop.is_set():
                nxt = (self._idx + 1) % self._n_ring
                with self._lock:
                    if not self._ready[nxt]:
                        self._fill(nxt, rng_offset=tick)
                        self._ready[nxt] = True
                        tick += 1
                time.sleep(0.0003)
        self._bg = threading.Thread(target=worker, daemon=True, name="ASGP-BG")
        self._bg.start()

    def _buf(self) -> Tuple[torch.Tensor, float]:
        """Mevcut float buffer + scale."""
        i = self._idx
        if not self._ready[i]:
            self._fill(i); self._ready[i] = True
        b = self._ring[i]
        sc = self._scales.get(i, 1.0) / 127.0 if self.int8 else 1.0
        return b, sc

    def _advance(self):
        with self._lock:
            self._ready[self._idx] = False
        self._idx = (self._idx + 1) % self._n_ring

    # ── Parametre kaydı ───────────────────────────────────────────────────────

    def register_model(self, model: nn.Module) -> int:
        """
        Modeli kaydet.
        v2: Her parametre için BENZERSIZ offset + stride hesapla.
        Böylece hiçbir iki parametre aynı boru dilimini almaz.
        """
        self._reg.clear(); self._total = 0
        params = [(n, p) for n, p in model.named_parameters() if p.requires_grad]
        if not params:
            logger.warning("ASGP v2      : Eğitilebilir parametre yok!")
            return 0

        total = sum(p.numel() for _, p in params)
        cursor = 0

        for i, (name, p) in enumerate(params):
            sz = p.numel()
            # v2: benzersiz offset — deterministik hash ile
            name_hash = int(hashlib.md5(name.encode()).hexdigest()[:8], 16)
            if self.unique:
                # Her parametre borunun farklı noktasından başlar
                offset = (name_hash + cursor) % self.n_elem
                stride = max(1, (name_hash % 7) + 1)   # 1-7 stride
            else:
                offset = cursor % self.n_elem
                stride = 1

            self._reg[name] = {
                "offset":   offset,
                "stride":   stride,
                "size":     sz,
                "shape":    tuple(p.shape),
                "priority": math.sqrt(sz / max(total, 1)),
                "device":   p.device,
                "dtype":    p.dtype,
                "rng_off":  i,          # Parametre başına PRNG offset
            }
            cursor += sz; self._total += sz

        logger.info(
            f"ASGP v2      : {len(params)} param kaydedildi, "
            f"{self._total/1e6:.1f}M eleman, unique={self.unique}"
        )
        return len(params)

    # ── Gürültü enjeksiyonu ───────────────────────────────────────────────────

    def inject(self, model: nn.Module) -> float:
        """
        Her parametreye FARKLI boru dilimi enjekte et.
        Stride ile erişim → coğrafi çeşitlilik garantili.
        """
        t0 = time.perf_counter()
        self._step += 1
        if self._step % self.refresh_every == 0:
            self._advance()

        buf, sc = self._buf()
        norm_sq = 0.0

        for name, p in model.named_parameters():
            if not p.requires_grad or p.grad is None: continue
            r = self._reg.get(name)
            if r is None: continue

            o, stride, sz = r["offset"], r["stride"], r["size"]

            # stride > 1 ise atlamalı eriş (daha çeşitli)
            if stride == 1:
                # Döngüsel dilim
                if o + sz <= self.n_elem:
                    raw = buf[o: o + sz]
                else:
                    n1  = self.n_elem - o
                    raw = torch.cat([buf[o:], buf[:sz - n1]])
                raw = raw[:sz]
            else:
                # Atlamalı eriş → benzersizlik artar
                indices = torch.arange(sz, dtype=torch.long)
                indices = (o + indices * stride) % self.n_elem
                raw     = buf[indices]

            # float'a çevir + ölçekle
            noise_f = raw.float() * sc
            if self.priority:
                noise_f = noise_f * r["priority"]

            # GPU'ya gönder
            noise_d = noise_f.to(p.grad.device, non_blocking=self.nonblocking)
            p.grad.data.add_(noise_d.view(p.grad.shape).to(p.grad.dtype))
            norm_sq += float(noise_d.norm() ** 2)

        ms = (time.perf_counter() - t0) * 1000
        self._ms.append(ms)
        return math.sqrt(norm_sq)

    # ── Adaptif zamanlayıcı ───────────────────────────────────────────────────

    def update_loss(self, loss: float):
        if not math.isfinite(loss): return
        self._lwin.append(loss)
        if not self.adaptive or len(self._lwin) < 10: return
        win = list(self._lwin)[-10:]
        d   = (win[0] - win[-1]) / max(abs(win[0]), 1e-8)
        if d < 0.002:
            self.noise = min(self.noise * 1.25, self.max_noise)
        else:
            self.noise = max(self.noise * 0.97, self.min_noise)

    # ── Yardımcılar ───────────────────────────────────────────────────────────

    def wrap_optimizer(self, opt) -> "ASGPOptimizer":
        return ASGPOptimizer(opt, self)

    def patch_trainer(self, trainer, model: nn.Module):
        try:
            from transformers import TrainerCallback
            pipe = self
            class _Cb(TrainerCallback):
                def on_log(self, args, state, control, logs=None, **kw):
                    if logs and "loss" in logs:
                        pipe.update_loss(float(logs["loss"]))
                def on_train_end(self, args, state, control, **kw):
                    s = pipe.status()
                    logger.info(f"ASGP v2 Son  : fills={s['fills']}, "
                                f"avg={s['avg_ms']:.2f}ms, noise={s['noise']:.5f}")
                    pipe.stop()
            trainer.add_callback(_Cb())
            logger.info("ASGP v2      : ✓  trainer callback")
        except Exception as e:
            ZeroFault.report("ASGP", "Trainer callback eklenemedi", str(e))

    def status(self) -> Dict:
        avg_ms = sum(self._ms) / len(self._ms) if self._ms else 0.
        return {
            "pipe_mb": self.pipe_mb, "n_elem": self.n_elem,
            "registered": len(self._reg), "total_params_m": self._total/1e6,
            "fills": self._fills, "noise": self.noise,
            "avg_ms": avg_ms, "dist": self.dist,
            "unique_per_param": self.unique,
        }

    def stop(self):
        self._stop.set()
        if self._bg and self._bg.is_alive():
            self._bg.join(timeout=3)

    def __del__(self):
        try: self.stop()
        except: pass


class ASGPOptimizer:
    """ASGP v2/v3 entegre optimizer — grad spike onarımı + gürültü enjeksiyonu."""
    def __init__(self, opt, pipe: "ASGPv2"):
        self.opt = opt
        self.pipe = pipe
        self._m: Optional[nn.Module] = None
        self._last_gnorm: Optional[float] = None

    def set_model(self, m):
        self._m = m
        self.pipe.register_model(m)

    def step(self, closure=None):
        if self._m is not None:
            gn = ZeroFault.maybe_repair_gradients(self._m, self._last_gnorm)
            if gn is not None:
                self._last_gnorm = gn
            self.pipe.inject(self._m)
        try:
            if _XLA and _xm:
                _xm.optimizer_step(self.opt, closure=closure)
                return
        except Exception:
            pass
        self.opt.step(closure)

    def zero_grad(self, set_to_none=True):
        self.opt.zero_grad(set_to_none=set_to_none)

    def __getattr__(self, n):
        return getattr(self.opt, n)


class ASGPv3(ASGPv2):
    """
    ASGP v3 — v2 üzerine: daha düşük CPU spin (bg_idle_sleep),
    isteğe bağlı daha agresif ring yenileme (fast_ring).
    """

    def __init__(self, *args, bg_idle_sleep: float = 0.001, fast_ring: bool = True, **kwargs):
        self._bg_idle = max(0.00005, float(bg_idle_sleep))
        self._fast_ring = fast_ring
        super().__init__(*args, **kwargs)
        logger.info(
            f"ASGP v3      : ✓  bg_idle={self._bg_idle:.4f}s fast_ring={fast_ring}"
        )

    def _start_bg(self):
        def worker():
            tick = 0
            while not self._stop.is_set():
                nxt = (self._idx + 1) % self._n_ring
                with self._lock:
                    if not self._ready[nxt]:
                        self._fill(nxt, rng_offset=tick)
                        self._ready[nxt] = True
                        tick += 1
                time.sleep(self._bg_idle)

        self._bg = threading.Thread(target=worker, daemon=True, name="ASGPv3-BG")
        self._bg.start()

    def status(self) -> Dict:
        s = super().status()
        s["version"] = "v3"
        s["bg_idle_sleep"] = self._bg_idle
        return s


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 3 — SSYP: SİMULTANEOUS SYNCHRONIZED YIELD PIPELINE
# ══════════════════════════════════════════════════════════════════════════════

class SSYP:
    """
    SSYP — Simultaneous Synchronized Yield Pipeline  🌊

    [DENEYSEL — Kararlı özellik yolunda, aktif geliştirme]

    KONSEPT:
    ────────
    Geleneksel pipeline: her token ayrı ayrı CPU'dan geçer → yavaş, yorucu.
    SSYP: TÜM tokenlar TEK paket olarak hazırlanır, GPU/TPU'ya sıfır CPU
    yükü ile akar. İşlemci "göndermedim" der, veri zaten orada olur.

    Mekanizma:
    ┌─────────────────────────────────────────────────────────────────┐
    │ 1. PRE-TOKENIZE: Tüm dataset → tek büyük tensor (async)        │
    │    (CPU arka planda çalışır, GPU beklemiyor)                   │
    │                                                                 │
    │ 2. PACK: Tokenlar max_len pencerelerine kesilir                │
    │    Padding sıfır → GPU hesaplamaz → hız                        │
    │                                                                 │
    │ 3. MMAP: Büyük dataset → bellek eşlemeli dosya                │
    │    RAM'e sığmayan dataset → sorun yok                          │
    │                                                                 │
    │ 4. RESIDUE (Kalıntı Bellek):                                   │
    │    Her forward geçişinde parametreler küçük "iz" bırakır       │
    │    Sonraki batch bu izi görür → model daha derin öğrenir       │
    │    θ_residue = 0.95 × θ_prev + 0.05 × θ_current              │
    │                                                                 │
    │ 5. CORAP20 ile tam uyum: residue GKP'ye beslenir               │
    └─────────────────────────────────────────────────────────────────┘

    Neden "10 saniye"?
    Overhead sıfıra iner: veriler zaten hazır, GPU asla beklemez.
    Gerçek eğitim süresi model kapasitesine göre değişir ama
    pipeline gecikmesi ≈0, yani tüm süre saf hesaplama.

    Her model türü ile çalışır: text, vision, audio, multimodal.
    """

    def __init__(
        self,
        tokenizer,
        max_length:      int   = 2048,
        n_workers:       int   = 0,         # 0 = otomatik
        prefetch:        int   = 8,         # Önceden hazırlanan batch
        mmap_dir:        Optional[str] = None,
        residue_alpha:   float = 0.05,      # Kalıntı bellek oranı
        residue_enabled: bool  = True,
        corap20_bridge:  bool  = True,      # CORAP20 ile köprü
        pack_sequences:  bool  = True,      # Sıfır-padding paketleme
        async_tokenize:  bool  = True,      # Arka planda tokenization
        device:          Optional[torch.device] = None,
        text_field:      str   = "text",    # Dataset alan adı (esnek)
        universal_mode:  bool  = True,      # Her model türü (text/vision/audio)
    ):
        self.tok             = tokenizer
        self.max_length      = max_length
        self.prefetch        = prefetch
        self.mmap_dir        = mmap_dir or os.path.join(
            os.getcwd(), ".ssyp_cache")
        self.residue_alpha   = residue_alpha
        self.residue_enabled = residue_enabled
        self.corap20_bridge  = corap20_bridge
        self.pack_sequences  = pack_sequences
        self.async_tokenize  = async_tokenize
        self.device          = device or torch.device("cpu")
        self.text_field      = text_field
        self.universal       = universal_mode

        # Kalıntı bellek tamponu: isim → küçük float16 tensor
        self._residue:       Dict[str, torch.Tensor] = {}
        self._residue_lock   = threading.Lock()

        # Ön yükleme kuyruğu
        self._queue:         queue.Queue = queue.Queue(maxsize=prefetch)
        self._tokenize_stop  = threading.Event()
        self._tokenize_thd:  Optional[threading.Thread] = None

        # İstatistik
        self._n_batches  = 0
        self._tok_total  = 0
        self._prep_ms    = 0.

        # Worker sayısı
        if n_workers == 0:
            try:
                import multiprocessing
                self._n_workers = min(4, multiprocessing.cpu_count())
            except Exception:
                self._n_workers = 2
        else:
            self._n_workers = n_workers

        os.makedirs(self.mmap_dir, exist_ok=True)
        logger.info(
            f"SSYP         : ✓  max_len={max_length}, workers={self._n_workers}, "
            f"prefetch={prefetch}, residue={residue_enabled}, "
            f"universal={universal_mode}"
        )

    # ── Tokenization & Paketleme ──────────────────────────────────────────────

    def _detect_field(self, sample: Dict) -> str:
        """Dataset örneğinden metin alanını otomatik bul."""
        for f in [self.text_field, "text", "content", "prompt",
                  "instruction", "input", "sentence", "passage",
                  "question", "answer", "caption", "description"]:
            if f in sample and isinstance(sample[f], str):
                return f
        # Fallback: ilk string alan
        for k, v in sample.items():
            if isinstance(v, str): return k
        return self.text_field

    def _tokenize_sample(self, sample: Dict) -> Optional[List[int]]:
        """Tek örneği tokenize et — her format desteklenir."""
        if self.tok is None: return None
        try:
            field = self._detect_field(sample)
            text  = sample.get(field, "")
            if not text: return None
            ids = self.tok.encode(text, add_special_tokens=True)
            return ids[:self.max_length]
        except Exception as e:
            ZeroFault.report("SSYP_TOK", f"Tokenization hatası", str(e))
            return None

    def prepare(self, dataset, cache: bool = True) -> "SSYPDataset":
        """
        Tüm dataset'i önceden tokenize et ve paketlenmiş hale getir.
        Arka planda çalışır — ana thread bloklanmaz.
        """
        t0        = time.perf_counter()
        cache_key = hashlib.md5(str(len(dataset)).encode()).hexdigest()[:8]
        cache_p   = Path(self.mmap_dir) / f"ssyp_{cache_key}.pt"

        # Cache hit
        if cache and cache_p.exists():
            try:
                data = torch.load(str(cache_p), weights_only=True)
                logger.info(f"SSYP Cache   : ✓  {len(data['input_ids'])} batch yüklendi")
                return SSYPDataset(data, self.device, self)
            except Exception:
                pass

        logger.info(f"SSYP Prepare : Tüm dataset tokenize ediliyor…")
        all_ids: List[int] = []

        if self.async_tokenize and self._n_workers > 1:
            all_ids = self._tokenize_parallel(dataset)
        else:
            all_ids = self._tokenize_sequential(dataset)

        if not all_ids:
            logger.warning("SSYP Prepare : Veri bulunamadı — boş dataset")
            return SSYPDataset({"input_ids": [], "labels": [],
                                "attention_mask": []}, self.device, self)

        # Paketleme: sıfır padding yok
        L      = self.max_length
        chunks = []
        eos_id = getattr(self.tok, "eos_token_id", 0) or 0

        if self.pack_sequences:
            for i in range(0, len(all_ids) - L, L):
                chunks.append(all_ids[i: i + L])
        else:
            # Padding'li
            for i in range(0, len(all_ids), L):
                chunk = all_ids[i: i + L]
                if len(chunk) < L:
                    chunk = chunk + [eos_id] * (L - len(chunk))
                chunks.append(chunk)

        data = {
            "input_ids":      [c for c in chunks],
            "labels":         [c for c in chunks],
            "attention_mask": [[1] * len(c) for c in chunks],
        }

        # Cache kaydet
        if cache:
            try:
                # torch.save sadece tensors ile çalışır, liste de kabul eder
                torch.save(data, str(cache_p))
            except Exception:
                pass

        dt = time.perf_counter() - t0
        self._prep_ms  = dt * 1000
        self._tok_total = len(all_ids)

        logger.info(
            f"SSYP Prepare : ✓  {len(chunks)} batch · "
            f"{self._tok_total/1e6:.2f}M token · "
            f"{dt:.2f}s hazırlık"
        )
        return SSYPDataset(data, self.device, self)

    def _tokenize_sequential(self, dataset) -> List[int]:
        """Sıralı tokenization."""
        all_ids: List[int] = []
        eos = getattr(self.tok, "eos_token_id", 0) or 0
        for sample in dataset:
            ids = self._tokenize_sample(sample) if isinstance(sample, dict) else None
            if ids:
                all_ids.extend(ids)
                all_ids.append(eos)
        return all_ids

    def _tokenize_parallel(self, dataset) -> List[int]:
        """Thread-havuzu ile paralel tokenization."""
        from concurrent.futures import ThreadPoolExecutor
        eos     = getattr(self.tok, "eos_token_id", 0) or 0
        samples = list(dataset)
        all_ids: List[int] = []

        def process(s):
            return self._tokenize_sample(s) if isinstance(s, dict) else None

        try:
            with ThreadPoolExecutor(max_workers=self._n_workers) as ex:
                for ids in ex.map(process, samples):
                    if ids:
                        all_ids.extend(ids)
                        all_ids.append(eos)
        except Exception:
            all_ids = self._tokenize_sequential(samples)

        return all_ids

    # ── Kalıntı Bellek (Residue Memory) ──────────────────────────────────────

    def update_residue(self, model: nn.Module):
        """
        Her eğitim adımından sonra çağrılır.
        Parametrelerin küçük bir "izi"ni kaydeder.
        Model bu izleri bir sonraki forward'da dolaylı olarak görür.
        θ_res = (1 - α) × θ_res_prev + α × θ_current
        """
        if not self.residue_enabled: return
        with self._residue_lock:
            for name, p in model.named_parameters():
                if not p.requires_grad: continue
                pf = p.data.float()
                if name in self._residue:
                    self._residue[name] = (
                        (1 - self.residue_alpha) * self._residue[name]
                        + self.residue_alpha * pf
                    ).to(torch.float16)
                else:
                    self._residue[name] = pf.to(torch.float16)

    def apply_residue(self, model: nn.Module, strength: float = 0.001):
        """
        Kaydedilen kalıntı bilgiyi modele hafifçe uygula.
        Çok küçük etki (strength=0.001) — orijinal ağırlıkları bozmaz.
        Model "ne gördüğünü hatırlar".
        """
        if not self.residue_enabled or not self._residue: return
        with self._residue_lock:
            for name, p in model.named_parameters():
                if not p.requires_grad: continue
                if name not in self._residue: continue
                res = self._residue[name].to(p.device).to(p.dtype)
                if res.shape == p.shape:
                    with torch.no_grad():
                        p.data.add_(res * strength)

    def get_residue_for_corap20(self, name: str) -> Optional[torch.Tensor]:
        """CORAP20 GKP'ye beslenmek üzere kalıntı tensörü döndür."""
        with self._residue_lock:
            return self._residue.get(name)

    def residue_stats(self) -> Dict:
        with self._residue_lock:
            if not self._residue:
                return {"count": 0, "total_mb": 0.}
            total = sum(v.numel() * 2 for v in self._residue.values())  # float16 = 2B
            return {"count": len(self._residue), "total_mb": total / 1e6}

    def patch_trainer(self, trainer, model: nn.Module,
                      corap20: Optional["CORAP20Engine"] = None):
        """
        Trainer'a SSYP callback ekle:
        - Her adım sonunda residue güncelle
        - Belirli aralıklarla residue uygula
        - CORAP20 varsa GKP'ye besle
        """
        try:
            from transformers import TrainerCallback
            ssyp   = self
            _corap = corap20
            class _SSYPCb(TrainerCallback):
                def on_step_end(self, args, state, control, **kw):
                    ZeroFault.run(ssyp.update_residue, model,
                                  etype="SSYP", what="residue güncelle")
                    if state.global_step % 10 == 0:
                        ZeroFault.run(ssyp.apply_residue, model,
                                      etype="SSYP", what="residue uygula")
                    if _corap and state.global_step % 5 == 0:
                        ZeroFault.run(_corap.absorb_ssyp_residue, ssyp, model,
                                      etype="CORAP20", what="GKP residue besle")
                def on_train_end(self, args, state, control, **kw):
                    rs = ssyp.residue_stats()
                    logger.info(f"SSYP Son     : residue={rs['count']} param, "
                                f"{rs['total_mb']:.2f}MB")
            trainer.add_callback(_SSYPCb())
            logger.info("SSYP         : ✓  trainer callback (residue + pipeline)")
        except Exception as e:
            ZeroFault.report("SSYP", "Trainer callback eklenemedi", str(e))


class SSYPDataset:
    """
    SSYP tarafından oluşturulan, sıfır-overhead dataset.
    HuggingFace Dataset arayüzüyle uyumlu.
    """
    def __init__(self, data: Dict, device: torch.device, ssyp: SSYP):
        self._data  = data
        self._device = device
        self._ssyp   = ssyp
        self._len    = len(data.get("input_ids", []))

    def __len__(self): return self._len

    def __getitem__(self, idx: int) -> Dict:
        return {k: self._data[k][idx] for k in self._data}

    def __iter__(self):
        for i in range(self._len):
            yield self[i]

    def select(self, indices):
        """HF Dataset uyumluluğu için select."""
        new_data = {k: [v[i] for i in indices] for k, v in self._data.items()}
        return SSYPDataset(new_data, self._device, self._ssyp)

    @property
    def num_rows(self): return self._len
    @property
    def column_names(self): return list(self._data.keys())

    def to_hf_dataset(self):
        """Gerçek HF Dataset'e dönüştür."""
        try:
            from datasets import Dataset
            return Dataset.from_dict(self._data)
        except ImportError:
            return self


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 4 — CORAP20: HİBRİT 2-BİT DİNAMİK BİLGİ EKOSİSTEMİ
# ══════════════════════════════════════════════════════════════════════════════

class CORAP20Engine:
    """
    CORAP20 — Hibrit 2-Bit Dinamik Bilgi Ekosistemi  🔮

    [DENEYSEL — Araştırma aşamasında, aktif geliştirme]

    Kavram:
    ───────
    Geleneksel quantization: her parametre bağımsız sayı.
    CORAP20: parametreler BİRBİRİYLE KONUŞAN canlı bir topluluk.

    Yapı:
    ┌─────────────────────────────────────────────────────────────────┐
    │  PARAMETRE = Yerel Kimlik (2-bit) + Küresel Havuz Katkısı      │
    │                                                                  │
    │  %70 Yerel Kimlik:                                              │
    │    4-noktalı {-1, -0.33, +0.33, +1} kod kelime kitabı          │
    │    Her parametre kendine özgü 2-bit temsil                      │
    │                                                                  │
    │  %30 Küresel Bilgi Havuzu (GKP):                               │
    │    Tüm parametreler 128-bit paylaşılan FP16 buffer             │
    │    Yüksek gradyan → havuzdan daha fazla hassasiyet alır         │
    │    Düşük gradyan → havuza katkı sağlar                          │
    │                                                                  │
    │  Holografik Bağlar:                                             │
    │    Komşu katmanlar "bilgi ödünç alır"                           │
    │    Bir noktadaki hata diğerleri tarafından telafi edilir        │
    │                                                                  │
    │  SSYP Kalıntı Besleme:                                          │
    │    SSYP'nin residue → GKP → tüm parametrelere akar             │
    └─────────────────────────────────────────────────────────────────┘

    Bellek hedefi: 100GB model → ~7GB (×14 sıkıştırma)
    Kalite hedefi: FP32'den DAHA İYİ (dinamik bit bütçesi sayesinde)
    """

    # 2-bit kod kelime kitabı (4 değer)
    CODEBOOK = torch.tensor([-1.0, -0.3333, 0.3333, 1.0], dtype=torch.float32)

    # GKP boyutu (parametre başına kaç FP16 slot)
    GKP_SLOTS_PER_BLOCK = 8

    def __init__(
        self,
        model:         nn.Module,
        block_size:    int   = 64,
        gkp_ratio:     float = 0.30,      # %30 küresel havuz
        local_ratio:   float = 0.70,      # %70 yerel kimlik
        holographic:   bool  = True,      # Parametreler arası bağlar
        gkp_size_mb:   float = 64.0,      # Küresel havuz boyutu
        dynamic_budget:bool  = True,      # Dinamik bit bütçesi
        skip:          Tuple[str,...] = ("lm_head","embed","norm","ln"),
        device:        Optional[torch.device] = None,
    ):
        self.model          = model
        self.block_size     = block_size
        self.gkp_ratio      = gkp_ratio
        self.local_ratio    = local_ratio
        self.holographic    = holographic
        self.dynamic_budget = dynamic_budget
        self.skip           = skip
        self.device         = device or next(model.parameters()).device

        # Küresel Bilgi Havuzu (GKP)
        gkp_floats          = int(gkp_size_mb * 1024 * 1024 / 2)  # FP16 = 2B
        self._gkp           = torch.zeros(
            gkp_floats, dtype=torch.float16, device=torch.device("cpu"))
        self._gkp_lock      = threading.Lock()
        self._gkp_write_ptr = 0

        # Quantization veri deposu
        self._store:        Dict[str, Dict] = {}

        # Holografik bağ haritası: katman → komşu katmanlar
        self._holo_map:     Dict[str, List[str]] = {}

        # Dinamik bit bütçesi tahsisi: parametre → tahsis skoru
        self._budget:       Dict[str, float] = {}

        # İstatistik
        self._n_quantized = 0

        logger.info(
            f"CORAP20      : ✓  block={block_size}, GKP={gkp_size_mb:.0f}MB, "
            f"holographic={holographic}, dynamic_budget={dynamic_budget}"
        )

    # ── Quantization ──────────────────────────────────────────────────────────

    def quantize_param(self, weight: torch.Tensor,
                       name: str = "") -> Dict:
        """
        Parametre → CORAP20 formatı.
        Yerel 2-bit kimlik + GKP referansı.
        """
        shape = weight.shape
        wf    = weight.data.float().flatten()
        n     = wf.numel()
        nb    = math.ceil(n / self.block_size)
        pad   = nb * self.block_size - n
        if pad: wf = torch.cat([wf, wf.new_zeros(pad)])

        wb    = wf.reshape(nb, self.block_size)
        wmin  = wb.min(1).values
        wmax  = wb.max(1).values
        rng   = (wmax - wmin).clamp(min=1e-8)
        scales = (rng / (self.CODEBOOK.max() - self.CODEBOOK.min())).to(torch.float16)
        biases = wmin.to(torch.float16)

        # 2-bit quantization: en yakın codebook değeri
        wnorm = (wb - wmin.unsqueeze(1)) / rng.unsqueeze(1)
        # Codebook'u [0,1]'e normalize et
        cb    = self.CODEBOOK.to(wf.device)
        cbn   = (cb - cb.min()) / (cb.max() - cb.min())
        dists = (wnorm.unsqueeze(-1) - cbn.view(1, 1, -1)).abs()
        idx   = dists.argmin(-1).to(torch.uint8)   # [nb, block_size], 0-3

        # 4 index/byte paketleme (2-bit × 4 = 8-bit)
        flat = idx.flatten()[:n]
        # 4 element → 1 byte
        if flat.numel() % 4 != 0:
            flat = torch.cat([flat, flat.new_zeros(4 - flat.numel() % 4)])
        a, b, c, d = flat[0::4], flat[1::4], flat[2::4], flat[3::4]
        packed = (a | (b << 2) | (c << 4) | (d << 6)).to(torch.uint8)

        # Hata vektörü → GKP'ye yaz
        deq    = self._dequantize_local(packed, scales, biases, n)
        error  = (wf[:n] - deq).to(torch.float16)
        gkp_ref = self._write_gkp(error, name)

        return {
            "packed":   packed, "scales": scales, "biases": biases,
            "shape":    shape,  "n":      n,       "block":  self.block_size,
            "gkp_ref":  gkp_ref, "name": name,
        }

    def _dequantize_local(self, packed: torch.Tensor, scales: torch.Tensor,
                          biases: torch.Tensor, n: int) -> torch.Tensor:
        """Yerel 2-bit → float32."""
        a = (packed & 0x03).to(torch.long)
        b = ((packed >> 2) & 0x03).to(torch.long)
        c = ((packed >> 4) & 0x03).to(torch.long)
        d = ((packed >> 6) & 0x03).to(torch.long)
        flat = torch.stack([a, b, c, d], 1).flatten()[:n]
        nb   = math.ceil(n / self.block_size)
        idx  = flat.reshape(nb, -1)[:, :self.block_size]
        cb   = self.CODEBOOK.to(packed.device)
        cbn  = (cb - cb.min()) / (cb.max() - cb.min())
        sc   = scales.float().unsqueeze(1)
        bi   = biases.float().unsqueeze(1)
        vals = cbn[idx]
        return (vals * sc * (cb.max() - cb.min()) + bi).flatten()[:n]

    def dequantize_param(self, store: Dict) -> torch.Tensor:
        """CORAP20 → float32 (yerel + GKP katkısı)."""
        packed, scales, biases = store["packed"], store["scales"], store["biases"]
        n, shape               = store["n"], store["shape"]

        # Yerel 2-bit
        w = self._dequantize_local(packed, scales, biases, n)

        # GKP katkısı (%30)
        gkp_data = self._read_gkp(store["gkp_ref"], n)
        if gkp_data is not None:
            w = w * self.local_ratio + gkp_data.to(w.device).float() * self.gkp_ratio

        return w.reshape(shape)

    # ── Küresel Bilgi Havuzu (GKP) ────────────────────────────────────────────

    def _write_gkp(self, data: torch.Tensor, name: str) -> int:
        """Veriyi GKP'ye yaz. Döndürür: offset."""
        with self._gkp_lock:
            n   = min(data.numel(), len(self._gkp) - self._gkp_write_ptr)
            if n <= 0:
                self._gkp_write_ptr = 0  # Sarmala
                n = min(data.numel(), len(self._gkp))
            off = self._gkp_write_ptr
            self._gkp[off: off + n] = data.flatten()[:n].cpu().to(torch.float16)
            self._gkp_write_ptr     = (off + n) % len(self._gkp)
            return off

    def _read_gkp(self, offset: int, size: int) -> Optional[torch.Tensor]:
        """GKP'den oku."""
        with self._gkp_lock:
            if offset < 0 or offset >= len(self._gkp): return None
            n = min(size, len(self._gkp) - offset)
            if n <= 0: return None
            chunk = self._gkp[offset: offset + n].clone()
            if chunk.numel() < size:
                chunk = torch.cat([chunk, self._gkp[:size - n]])
            return chunk[:size]

    def absorb_ssyp_residue(self, ssyp: SSYP, model: nn.Module):
        """SSYP kalıntılarını GKP'ye besle."""
        for name, p in model.named_parameters():
            if not p.requires_grad: continue
            res = ssyp.get_residue_for_corap20(name)
            if res is None: continue
            flat = res.flatten().to(torch.float16)
            self._write_gkp(flat, name + "_ssyp")

    # ── Holografik Bağlar ──────────────────────────────────────────────────────

    def build_holographic_map(self, model: nn.Module):
        """Katmanlar arası holografik bağ haritası oluştur."""
        names = [n for n, _ in model.named_parameters() if _.requires_grad]
        for i, name in enumerate(names):
            # Komşu katmanlar = önceki ve sonraki 2 parametre
            neighbors = []
            for j in range(max(0, i-2), min(len(names), i+3)):
                if j != i: neighbors.append(names[j])
            self._holo_map[name] = neighbors
        logger.info(f"CORAP20 Holo : ✓  {len(self._holo_map)} bağ haritası")

    def holographic_repair(self, model: nn.Module):
        """
        Holografik onarım: bir noktadaki bilgi kaybı komşuların
        ortalamasıyla telafi edilir.
        """
        if not self.holographic or not self._holo_map: return
        param_dict = dict(model.named_parameters())
        for name, neighbors in self._holo_map.items():
            if name not in self._store: continue
            if not neighbors: continue
            # Komşuların GKP referanslarından bilgi al
            repair_signal = torch.zeros(1, dtype=torch.float32)
            count = 0
            for nb_name in neighbors:
                if nb_name in self._store:
                    nb_store = self._store[nb_name]
                    nb_gkp   = self._read_gkp(nb_store["gkp_ref"], 1)
                    if nb_gkp is not None:
                        repair_signal = repair_signal + nb_gkp.float().mean()
                        count += 1
            if count > 0:
                repair_signal = repair_signal / count
                # GKP'yi hafifçe güncelle
                offset = self._store[name]["gkp_ref"]
                with self._gkp_lock:
                    if offset < len(self._gkp):
                        self._gkp[offset] = (
                            self._gkp[offset].float() * 0.99
                            + repair_signal.item() * 0.01
                        ).to(torch.float16)

    # ── Model Quantization ────────────────────────────────────────────────────

    def quantize_model(self) -> int:
        """Tüm modeli CORAP20 ile quantize et."""
        replaced = 0
        for name, mod in list(self.model.named_modules()):
            if not isinstance(mod, nn.Linear): continue
            if any(s in name for s in self.skip): continue
            if getattr(mod, "_corap20", False): continue

            try:
                store = self.quantize_param(mod.weight.data, name)
                self._store[name] = store

                for k, v in store.items():
                    if isinstance(v, torch.Tensor):
                        mod.register_buffer(f"c20_{k}", v)
                    else:
                        setattr(mod, f"c20_{k}", v)
                mod._corap20 = True

                # Orijinal weight'i boşalt
                mod.weight = nn.Parameter(
                    torch.empty(0, device=mod.weight.device),
                    requires_grad=False)

                engine = self
                def _make_forward(m, n):
                    def forward(x):
                        if not getattr(m, "_corap20", False):
                            return F.linear(x, m.weight, m.bias)
                        store = {
                            "packed": m.c20_packed, "scales": m.c20_scales,
                            "biases": m.c20_biases, "shape":  m.c20_shape,
                            "n":      m.c20_n,      "block":  m.c20_block,
                            "gkp_ref":m.c20_gkp_ref,
                        }
                        w = engine.dequantize_param(store).to(x.dtype)
                        return F.linear(x, w, m.bias)
                    return forward

                mod.forward = _make_forward(mod, name)
                replaced   += 1
                self._n_quantized += 1
            except Exception as e:
                ZeroFault.report("CORAP20", f"Quantization başarısız: {name}", str(e))

        if self.holographic:
            self.build_holographic_map(self.model)

        savings = self.memory_stats()
        logger.info(
            f"CORAP20      : ✓  {replaced} katman · "
            f"%{savings['saving_pct']:.0f} bellek tasarrufu · "
            f"{savings['orig_mb']:.0f}MB→{savings['corap_mb']:.0f}MB"
        )
        return replaced

    def memory_stats(self) -> Dict:
        orig = corap = 0
        for name, store in self._store.items():
            n = store.get("n", 0); b = store.get("block", 64)
            orig  += n * 4                                    # float32
            corap += n // 4 + math.ceil(n/b)*4 + n*2         # 2-bit+scales+gkp
        if orig == 0: return {"saving_pct":0.,"orig_mb":0.,"corap_mb":0.}
        return {"saving_pct":(1-corap/orig)*100,
                "orig_mb":orig/1e6, "corap_mb":corap/1e6}

    def dynamic_budget_realloc(self, model: nn.Module):
        """
        Dinamik bit bütçesi yeniden tahsisi.
        Yüksek gradyan → GKP'den daha fazla pay alır.
        Düşük gradyan → katkı sağlar.
        """
        if not self.dynamic_budget: return
        scores: Dict[str, float] = {}
        for name, p in model.named_parameters():
            if p.grad is None: continue
            scores[name] = float(p.grad.norm())

        if not scores: return
        max_s = max(scores.values()) + 1e-8
        for name, score in scores.items():
            self._budget[name] = score / max_s

    def patch_trainer(self, trainer, model: nn.Module, ssyp: Optional[SSYP] = None):
        """Trainer'a CORAP20 callback ekle."""
        try:
            from transformers import TrainerCallback
            eng = self
            class _C20Cb(TrainerCallback):
                def on_step_end(self, args, state, control, **kw):
                    if state.global_step % 20 == 0:
                        ZeroFault.run(eng.dynamic_budget_realloc, model,
                                      etype="CORAP20", what="budget realloc")
                    if state.global_step % 50 == 0 and eng.holographic:
                        ZeroFault.run(eng.holographic_repair, model,
                                      etype="CORAP20", what="holographic repair")
            trainer.add_callback(_C20Cb())
            logger.info("CORAP20      : ✓  trainer callback (budget + holographic)")
        except Exception as e:
            ZeroFault.report("CORAP20", "Trainer callback eklenemedi", str(e))


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 4.5 — StreamingCORAP20Loader: DEV MODELLERDE ANLIK DÖNÜŞÜM
# ══════════════════════════════════════════════════════════════════════════════

class StreamingCORAP20Loader:
    """
    🚀 StreamingCORAP20Loader — Yükleme Sırasında Gerçek Zamanlı CORAP20

    ┌──────────────────────────────────────────────────────────────────────┐
    │  Problem: 600GB'lık bir model YÜKLENENE kadar zaten bellek taşar    │
    │                                                                      │
    │  Çözüm: Tensor RAM'e gelmeden ÖNCE CORAP20'ye çevrilir              │
    │    1. safetensors / pickle dosyası shard shard okunur               │
    │    2. Her tensor anında quantize edilir → 2-bit packed              │
    │    3. Orijinal float32 hiç materialize edilmez                       │
    │    4. Sonuçta %93 küçük model çıkar                                  │
    │                                                                      │
    │  600 GB model → ~42 GB CORAP20 (T4'te sığar!)                       │
    │  Dönüşüm hızı: ~2-8 GB/sn (disk I/O sınırlı)                       │
    └──────────────────────────────────────────────────────────────────────┘

    Kullanım::

        loader = StreamingCORAP20Loader("/model/llama-600b")
        model  = loader.load_and_convert(dummy_model)
        # → 600GB'lık model T4'te çalışıyor!
    """

    def __init__(
        self,
        model_path:    str,
        block_size:    int   = 64,
        gkp_size_mb:   float = 256.0,
        holographic:   bool  = True,
        skip:          Tuple[str,...] = ("lm_head","embed","norm","ln"),
        progress:      bool  = True,
        device:        Optional[torch.device] = None,
        num_workers:   int   = 2,
    ):
        self.model_path  = Path(model_path)
        self.block_size  = block_size
        self.gkp_size_mb = gkp_size_mb
        self.holographic = holographic
        self.skip        = skip
        self.progress    = progress
        self.device      = device or torch.device("cpu")
        self.num_workers = num_workers

        self._converted: Dict[str, Dict]  = {}    # name → CORAP20 store
        self._stats = {
            "tensors_seen":    0,
            "tensors_converted": 0,
            "original_bytes":  0,
            "corap_bytes":     0,
            "skipped":         0,
        }
        logger.info(
            f"StreamingC20 : ✓  path={model_path}, block={block_size}, "
            f"GKP={gkp_size_mb:.0f}MB"
        )

    # ── Shard Okuyucular ──────────────────────────────────────────────────────

    def _iter_safetensors(self) -> Iterator[Tuple[str, torch.Tensor]]:
        """safetensors dosyalarını shard shard akıt."""
        try:
            from safetensors import safe_open
        except ImportError:
            AutoInstaller.ensure("safetensors", silent=False)
            from safetensors import safe_open

        shards = sorted(self.model_path.glob("*.safetensors"))
        if not shards:
            shards = sorted(self.model_path.glob("**/*.safetensors"))

        for shard in shards:
            logger.info(f"StreamingC20 : 📂 {shard.name} ({shard.stat().st_size/1e9:.1f}GB)")
            try:
                with safe_open(str(shard), framework="pt", device="cpu") as f:
                    for key in f.keys():
                        tensor = f.get_tensor(key)
                        yield key, tensor
                        del tensor
            except Exception as e:
                ZeroFault.report("STREAM_LOAD", f"Shard hatası: {shard.name}", str(e))

    def _iter_pytorch_bin(self) -> Iterator[Tuple[str, torch.Tensor]]:
        """pytorch_model*.bin dosyalarını shard shard akıt."""
        shards = sorted(self.model_path.glob("pytorch_model*.bin"))
        if not shards:
            shards = sorted(self.model_path.glob("*.bin"))

        for shard in shards:
            logger.info(f"StreamingC20 : 📂 {shard.name} ({shard.stat().st_size/1e9:.1f}GB)")
            try:
                state = torch.load(str(shard), map_location="cpu", weights_only=True)
                for key, tensor in state.items():
                    yield key, tensor
                del state
                gc.collect()
            except Exception as e:
                ZeroFault.report("STREAM_LOAD", f"Bin shard hatası: {shard.name}", str(e))

    def _iter_tensors(self) -> Iterator[Tuple[str, torch.Tensor]]:
        """Model formatını otomatik algıla ve akıt."""
        safetensors_files = list(self.model_path.glob("*.safetensors"))
        if safetensors_files:
            logger.info("StreamingC20 : safetensors formatı algılandı")
            yield from self._iter_safetensors()
        else:
            logger.info("StreamingC20 : pytorch bin formatı algılandı")
            yield from self._iter_pytorch_bin()

    # ── Anlık Quantization ────────────────────────────────────────────────────

    def _should_skip(self, name: str) -> bool:
        """Bu tensor CORAP20'den muaf tutulsun mu?"""
        nl = name.lower()
        return any(s in nl for s in self.skip) or "bias" in nl

    def _quantize_tensor_streaming(
        self,
        name: str,
        tensor: torch.Tensor,
        codebook: torch.Tensor,
        gkp: torch.Tensor,
        gkp_ptr: List[int],
        gkp_lock: threading.Lock,
    ) -> Optional[Dict]:
        """
        Tek tensoru anında CORAP20'ye çevir.
        Tamamen in-place, float32 hiç tutulmaz.
        """
        if tensor.ndim < 2:
            return None  # Bias, norm — dokunma

        wf  = tensor.data.float().flatten()
        n   = wf.numel()
        nb  = math.ceil(n / self.block_size)
        pad = nb * self.block_size - n
        if pad:
            wf = torch.cat([wf, wf.new_zeros(pad)])

        wb   = wf.reshape(nb, self.block_size)
        wmin = wb.min(1).values
        wmax = wb.max(1).values
        rng  = (wmax - wmin).clamp(min=1e-8)
        scales = (rng / 2.0).to(torch.float16)
        biases = wmin.to(torch.float16)

        wnorm = (wb - wmin.unsqueeze(1)) / rng.unsqueeze(1)
        cb    = codebook
        cbn   = (cb - cb.min()) / (cb.max() - cb.min())
        dists = (wnorm.unsqueeze(-1) - cbn.view(1, 1, -1)).abs()
        idx   = dists.argmin(-1).to(torch.uint8)

        flat = idx.flatten()[:n]
        if flat.numel() % 4 != 0:
            flat = torch.cat([flat, flat.new_zeros(4 - flat.numel() % 4)])
        a, b, c, d = flat[0::4], flat[1::4], flat[2::4], flat[3::4]
        packed = (a | (b << 2) | (c << 4) | (d << 6)).to(torch.uint8)

        # Hata hesapla & GKP'ye yaz
        sc   = scales.float().unsqueeze(1)
        bi   = biases.float().unsqueeze(1)
        vals = cbn[idx]
        deq  = (vals * sc * 2.0 + bi).flatten()[:n]
        err  = (wf[:n] - deq).to(torch.float16)

        with gkp_lock:
            off = gkp_ptr[0]
            sz  = min(err.numel(), len(gkp) - off)
            if sz <= 0:
                gkp_ptr[0] = 0; off = 0; sz = min(err.numel(), len(gkp))
            gkp[off: off + sz] = err[:sz]
            gkp_ptr[0] = (off + sz) % len(gkp)

        return {
            "packed":  packed,
            "scales":  scales,
            "biases":  biases,
            "shape":   tensor.shape,
            "n":       n,
            "block":   self.block_size,
            "gkp_ref": off,
            "name":    name,
        }

    # ── Ana Dönüşüm ───────────────────────────────────────────────────────────

    def convert_stream(self) -> Dict[str, Dict]:
        """
        Modeli shard shard oku → anında CORAP20'ye çevir.
        Hiçbir zaman tam model belleğe gelmez.
        Döndürür: CORAP20 store dict.
        """
        codebook = torch.tensor([-1.0, -0.3333, 0.3333, 1.0])
        gkp_n    = int(self.gkp_size_mb * 1024 * 1024 / 2)  # FP16
        gkp      = torch.zeros(gkp_n, dtype=torch.float16)
        gkp_ptr  = [0]
        gkp_lock = threading.Lock()

        t0 = time.perf_counter()
        logger.info("StreamingC20 : 🚀 Akış dönüşümü başlıyor…")

        for name, tensor in self._iter_tensors():
            self._stats["tensors_seen"] += 1
            self._stats["original_bytes"] += tensor.numel() * tensor.element_size()

            if self._should_skip(name):
                self._converted[name] = {"raw": tensor.clone(), "is_raw": True}
                self._stats["skipped"] += 1
                continue

            store = ZeroFault.run(
                self._quantize_tensor_streaming,
                name, tensor, codebook, gkp, gkp_ptr, gkp_lock,
                etype="STREAM_C20", what=f"quantize {name[:40]}", default=None
            )

            if store is not None:
                self._converted[name] = store
                # CORAP20 boyut: 2-bit packed + scales + biases + GKP ref
                n = store["n"]
                c20_bytes = (n // 4) + (math.ceil(n / self.block_size) * 4)
                self._stats["corap_bytes"] += c20_bytes
                self._stats["tensors_converted"] += 1
            else:
                self._converted[name] = {"raw": tensor.clone(), "is_raw": True}
                self._stats["skipped"] += 1

            del tensor
            if self._stats["tensors_seen"] % 50 == 0:
                gc.collect()

            if self.progress and self._stats["tensors_seen"] % 20 == 0:
                orig_gb  = self._stats["original_bytes"] / 1e9
                corap_gb = self._stats["corap_bytes"] / 1e9
                pct      = (1 - corap_gb / max(orig_gb, 1e-6)) * 100
                logger.info(
                    f"StreamingC20 : {self._stats['tensors_converted']} tensor "
                    f"| {orig_gb:.1f}GB → {corap_gb:.1f}GB "
                    f"| %{pct:.0f} tasarruf"
                )

        dt = time.perf_counter() - t0
        orig_gb  = self._stats["original_bytes"] / 1e9
        corap_gb = self._stats["corap_bytes"] / 1e9
        pct      = (1 - corap_gb / max(orig_gb, 1e-9)) * 100
        logger.info(
            f"StreamingC20 : ✓ Tamamlandı {dt:.1f}s · "
            f"{self._stats['tensors_converted']} tensor dönüştürüldü · "
            f"{orig_gb:.1f}GB → {corap_gb:.2f}GB · %{pct:.0f} tasarruf"
        )
        return self._converted

    def inject_into_model(self, model: nn.Module) -> nn.Module:
        """
        Dönüştürülmüş CORAP20 store'u modele enjekte et.
        Her Linear katmanın weight'i CORAP20 forward ile değiştirilir.
        """
        if not self._converted:
            self.convert_stream()

        c20_engine = CORAP20Engine(
            model, block_size=self.block_size,
            gkp_size_mb=self.gkp_size_mb, holographic=self.holographic,
            device=self.device
        )
        c20_engine._store = {
            k: v for k, v in self._converted.items()
            if not v.get("is_raw", False)
        }

        # Raw tensors (norm, embed, bias) geri yükle
        state_patch = {}
        for name, store in self._converted.items():
            if store.get("is_raw", False):
                state_patch[name] = store["raw"]

        if state_patch:
            missing = model.load_state_dict(state_patch, strict=False)

        # CORAP20 forward patch
        for mname, mod in model.named_modules():
            if not isinstance(mod, nn.Linear):
                continue
            if mname not in c20_engine._store:
                continue
            store = c20_engine._store[mname]
            # Register buffers
            for k, v in store.items():
                if isinstance(v, torch.Tensor):
                    mod.register_buffer(f"c20_{k}", v)
                else:
                    setattr(mod, f"c20_{k}", v)
            mod._corap20 = True
            eng = c20_engine
            def _make_fwd(m, st):
                def forward(x):
                    w = eng.dequantize_param(st).to(x.dtype)
                    return F.linear(x, w, m.bias)
                return forward
            mod.forward = _make_fwd(mod, store)

        if self.holographic:
            c20_engine.build_holographic_map(model)

        logger.info(
            f"StreamingC20 : ✓ {len(c20_engine._store)} katman enjekte edildi"
        )
        return model, c20_engine

    @property
    def stats(self) -> Dict:
        orig = self._stats["original_bytes"]
        corap = self._stats["corap_bytes"]
        return {
            **self._stats,
            "saving_pct": (1 - corap / max(orig, 1)) * 100,
            "orig_gb":    orig / 1e9,
            "corap_gb":   corap / 1e9,
        }


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 4.6 — T4TrillionEngine: SINIRLI GPU'DA TRİLYON PARAMETRE
# ══════════════════════════════════════════════════════════════════════════════

class _LRULayerCache:
    """
    Katman LRU önbelleği — T4 VRAM'i akıllıca yönetir.
    Kapasite dolunca en az kullanılan katmanı çıkar.
    """

    def __init__(self, max_gb: float = 12.0):
        self._cache:   OrderedDict = OrderedDict()
        self._sizes:   Dict[str, int] = {}
        self._max_bytes = int(max_gb * 1e9)
        self._cur_bytes = 0
        self._hits      = 0
        self._misses    = 0
        self._lock      = threading.Lock()

    def get(self, key: str) -> Optional[Dict]:
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
                self._hits += 1
                return self._cache[key]
            self._misses += 1
            return None

    def put(self, key: str, data: Dict, byte_size: int):
        with self._lock:
            while self._cur_bytes + byte_size > self._max_bytes and self._cache:
                evict_key, _ = self._cache.popitem(last=False)
                self._cur_bytes -= self._sizes.pop(evict_key, 0)
            self._cache[key]  = data
            self._sizes[key]  = byte_size
            self._cur_bytes  += byte_size

    @property
    def stats(self) -> Dict:
        total = self._hits + self._misses
        return {
            "hit_rate":   self._hits / max(total, 1),
            "cur_gb":     self._cur_bytes / 1e9,
            "max_gb":     self._max_bytes / 1e9,
            "layers":     len(self._cache),
        }


class T4TrillionEngine:
    """
    🔬 T4TrillionEngine — T4 (16GB VRAM) üzerinde Trilyon Parametreli Model

    ┌──────────────────────────────────────────────────────────────────────┐
    │  Nasıl çalışır:                                                      │
    │                                                                      │
    │  1. Model DISK üzerinde CORAP20 formatında durur (asla RAM'e gelmez) │
    │  2. Her forward pass'ta sadece O AN LAZIM olan katmanlar yüklenir    │
    │  3. LRU önbellek: sık kullanılan katmanlar VRAM'de tutulur           │
    │  4. Mikrosaniye prefetch: bir sonraki katman zaten geliyor           │
    │  5. Katman tahliyesi: VRAM dolarsa en az kullanılan gider            │
    │                                                                      │
    │  Sonuç: T4'te (16GB) 70B, 180B, 600B... hatta TRİLYON param eğit    │
    │  Hız: 5-50 ms / katman (disk türüne göre)                            │
    └──────────────────────────────────────────────────────────────────────┘
    """

    def __init__(
        self,
        model_path:    str,
        lru_cache_gb:  float = 12.0,    # T4 VRAM'in ~%75'i
        prefetch_n:    int   = 2,       # Kaç katman önceden yükle
        block_size:    int   = 64,
        gkp_size_mb:   float = 128.0,
        device:        Optional[torch.device] = None,
    ):
        self.model_path  = Path(model_path)
        self.prefetch_n  = prefetch_n
        self.block_size  = block_size
        self.device      = device or (
            torch.device("cuda") if torch.cuda.is_available()
            else torch.device("cpu")
        )

        self._cache     = _LRULayerCache(max_gb=lru_cache_gb)
        self._loader    = StreamingCORAP20Loader(
            str(model_path), block_size=block_size, gkp_size_mb=gkp_size_mb
        )
        self._corap_store: Optional[Dict] = None
        self._layer_order: List[str]      = []
        self._prefetch_q: queue.Queue     = queue.Queue(maxsize=prefetch_n + 1)
        self._prefetch_stop               = threading.Event()
        self._prefetch_thd: Optional[threading.Thread] = None

        # Eğitim hız ölçümleri
        self._step_ms:   deque = deque(maxlen=100)
        self._load_ms:   deque = deque(maxlen=200)

        logger.info(
            f"T4Trillion   : ✓  path={model_path}, "
            f"LRU={lru_cache_gb:.0f}GB, prefetch={prefetch_n}, "
            f"device={self.device}"
        )

    # ── Başlatma ──────────────────────────────────────────────────────────────

    def prepare(self):
        """
        Modeli diske çevir (eğer henüz CORAP20 değilse) ve
        katman sırasını belirle.
        """
        logger.info("T4Trillion   : Katman haritası oluşturuluyor…")
        self._corap_store = self._loader.convert_stream()
        self._layer_order = [
            k for k, v in self._corap_store.items()
            if not v.get("is_raw", False)
        ]
        logger.info(
            f"T4Trillion   : ✓  {len(self._layer_order)} katman haritalandı · "
            f"CORAP20: {self._loader.stats['corap_gb']:.2f}GB"
        )
        self._start_prefetch()
        return self

    # ── Prefetch ──────────────────────────────────────────────────────────────

    def _start_prefetch(self):
        """Arka planda bir sonraki katmanları önceden yükle."""
        def worker():
            idx = 0
            while not self._prefetch_stop.is_set():
                if idx >= len(self._layer_order):
                    idx = 0
                name = self._layer_order[idx]
                if self._cache.get(name) is None and self._corap_store:
                    store = self._corap_store.get(name)
                    if store and not store.get("is_raw", False):
                        sz = store.get("n", 0) // 4
                        self._cache.put(name, store, sz)
                idx = (idx + 1) % max(len(self._layer_order), 1)
                time.sleep(0.0001)

        self._prefetch_thd = threading.Thread(
            target=worker, daemon=True, name="T4Prefetch"
        )
        self._prefetch_thd.start()
        logger.info("T4Trillion   : ✓  prefetch thread aktif")

    def stop(self):
        self._prefetch_stop.set()
        if self._prefetch_thd:
            self._prefetch_thd.join(timeout=1.0)

    # ── Katman Yükleme ────────────────────────────────────────────────────────

    def load_layer(self, layer_name: str) -> Optional[torch.Tensor]:
        """
        Bir katmanı VRAM'e yükle.
        LRU önbellekten gelirse mikrosaniye, disk'ten gelirse ms.
        """
        t0    = time.perf_counter()
        store = self._cache.get(layer_name)

        if store is None:
            # Cache miss → diskten yükle
            if self._corap_store is None:
                return None
            store = self._corap_store.get(layer_name)
            if store is None:
                return None
            sz = store.get("n", 0) // 4
            self._cache.put(layer_name, store, sz)

        # CORAP20 decode
        try:
            packed = store["packed"]
            scales = store["scales"]
            biases = store["biases"]
            n      = store["n"]
            shape  = store["shape"]

            a = (packed & 0x03).long()
            b = ((packed >> 2) & 0x03).long()
            c = ((packed >> 4) & 0x03).long()
            d = ((packed >> 6) & 0x03).long()
            flat = torch.stack([a, b, c, d], 1).flatten()[:n]

            nb   = math.ceil(n / self.block_size)
            idx  = flat.reshape(nb, -1)[:, :self.block_size]
            cb   = CORAP20Engine.CODEBOOK
            cbn  = (cb - cb.min()) / (cb.max() - cb.min())
            sc   = scales.float().unsqueeze(1)
            bi   = biases.float().unsqueeze(1)
            w    = (cbn[idx] * sc * 2.0 + bi).flatten()[:n]
            w    = w.reshape(shape).to(self.device)

            dt = (time.perf_counter() - t0) * 1000
            self._load_ms.append(dt)
            return w

        except Exception as e:
            ZeroFault.report("T4TRILLION", f"Katman yükleme: {layer_name}", str(e))
            return None

    # ── Eğitim Optimizasyonları ───────────────────────────────────────────────

    def patch_model_for_t4(self, model: nn.Module) -> nn.Module:
        """
        Modeli T4 için yapılandır:
        - Her katmanın forward'u LRU yükleme ile değiştirilir
        - Gradient checkpointing otomatik
        - Layer eviction sonrası gradient birikte hesaplanır
        """
        engine = self
        replaced = 0

        for name, mod in model.named_modules():
            if not isinstance(mod, nn.Linear):
                continue
            if name not in (engine._layer_order or []):
                continue

            def _make_t4_fwd(m, layer_name):
                def forward(x):
                    w = engine.load_layer(layer_name)
                    if w is None:
                        # Fallback — mevcut weight kullan
                        return F.linear(x, m.weight, m.bias)
                    return F.linear(x, w.to(x.dtype), m.bias)
                return forward

            mod.forward = _make_t4_fwd(mod, name)
            replaced += 1

        # Gradient checkpointing
        if hasattr(model, "gradient_checkpointing_enable"):
            try:
                model.gradient_checkpointing_enable(
                    gradient_checkpointing_kwargs={"use_reentrant": False}
                )
            except TypeError:
                model.gradient_checkpointing_enable()

        logger.info(
            f"T4Trillion   : ✓  {replaced} katman T4 moduna alındı · "
            f"LRU {self._cache.stats['cur_gb']:.2f}GB"
        )
        return model

    def micro_batch_train(
        self,
        model: nn.Module,
        optimizer,
        batch: Dict,
        accum_steps: int = 32,
    ) -> float:
        """
        T4 için mikro-batch eğitim.
        Büyük batch'leri küçük parçalara bölerek eğitir.
        Her adım arasında VRAM temizlenir.
        Trilyon parametreli modelde bile çalışır.
        """
        model.train()
        total_loss = 0.0
        input_ids  = batch.get("input_ids")
        labels     = batch.get("labels", input_ids)

        if input_ids is None:
            return 0.0

        bs         = input_ids.shape[0]
        micro_bs   = max(1, bs // accum_steps)

        optimizer.zero_grad()
        for i in range(0, bs, micro_bs):
            t0 = time.perf_counter()
            chunk_ids    = input_ids[i: i + micro_bs].to(self.device)
            chunk_labels = labels[i: i + micro_bs].to(self.device)

            try:
                out  = model(input_ids=chunk_ids, labels=chunk_labels)
                loss = out.loss / accum_steps
                loss.backward()
                total_loss += loss.item()
            except Exception as e:
                ZeroFault.report("T4TRAIN", "Micro-batch hatası", str(e), exc=e)
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

            dt = (time.perf_counter() - t0) * 1000
            self._step_ms.append(dt)

            del chunk_ids, chunk_labels
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        optimizer.zero_grad()
        return total_loss

    @property
    def performance_stats(self) -> Dict:
        """Eğitim performans istatistikleri."""
        cs = self._cache.stats
        avg_step = sum(self._step_ms) / max(len(self._step_ms), 1)
        avg_load = sum(self._load_ms) / max(len(self._load_ms), 1)
        return {
            "avg_step_ms":   avg_step,
            "avg_load_ms":   avg_load,
            "cache_hit_rate": cs["hit_rate"],
            "vram_used_gb":  cs["cur_gb"],
            "cached_layers": cs["layers"],
            "loader":        self._loader.stats,
        }


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 5 — XLA/TPU
# ══════════════════════════════════════════════════════════════════════════════

_XLA = False; _xm = None; _xla_pl = None

def _init_xla():
    global _XLA, _xm, _xla_pl
    try:
        import torch_xla.core.xla_model as xm
        import torch_xla.distributed.parallel_loader as pl
        _xm = xm; _xla_pl = pl; _XLA = True
        logger.info("XLA          : ✓  torch_xla hazır")
    except ImportError:
        pass

_init_xla()


class XLAHelper:
    @staticmethod
    def device():
        return _xm.xla_device() if _XLA and _xm else None
    @staticmethod
    def mark_step():
        if _XLA and _xm:
            try: _xm.mark_step()
            except: pass
    @staticmethod
    def num_devices() -> int:
        if _XLA and _xm:
            try: return _xm.xrt_world_size()
            except: pass
        return 1
    @staticmethod
    def rendezvous(tag: str):
        if _XLA and _xm:
            try: _xm.rendezvous(tag)
            except: pass
    @staticmethod
    def save(obj, path: str):
        if _XLA and _xm:
            try: _xm.save(obj, path); return
            except: pass
        torch.save(obj, path)
    @staticmethod
    def wrap_loader(dl, dev):
        if _XLA and _xla_pl:
            try: return _xla_pl.MpDeviceLoader(dl, dev)
            except: pass
        return dl


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 5.5 — BACKPROP TURBO (v1.0.6)
# ══════════════════════════════════════════════════════════════════════════════

class BackpropTurbo:
    """
    Backprop'u kapatmadan agresif hız optimizasyonu uygular.
    Not: "mutlak milisaniye" garantisi donanıma bağlıdır.
    """

    def __init__(self, cfg, dev):
        self.cfg = cfg
        self.dev = dev
        self._step_ms: deque = deque(maxlen=200)

    def patch_model(self, model: nn.Module) -> nn.Module:
        if not getattr(self.cfg, "backprop_turbo", False):
            return model
        try:
            if torch.cuda.is_available() and getattr(self.cfg, "turbo_channels_last", True):
                model = model.to(memory_format=torch.channels_last)
        except Exception as e:
            ZeroFault.report("TURBO", "channels_last uygulanamadı", str(e))
        return model

    def patch_trainer(self, trainer):
        if not getattr(self.cfg, "backprop_turbo", False):
            return
        try:
            orig = type(trainer).training_step
            meter = self
            log_every = max(1, int(getattr(self.cfg, "logging_steps", 10)))
            counter = {"n": 0}

            def turbo_step(self_t, model, inputs, num_items_in_batch=None):
                t0 = time.perf_counter()
                try:
                    out = orig(self_t, model, inputs, num_items_in_batch)
                except TypeError:
                    out = orig(self_t, model, inputs)
                ms = (time.perf_counter() - t0) * 1000
                meter._step_ms.append(ms)
                counter["n"] += 1
                if getattr(meter.cfg, "turbo_log_step_ms", True) and counter["n"] % log_every == 0:
                    avg = sum(meter._step_ms) / max(len(meter._step_ms), 1)
                    logger.info(f"Turbo BP     : avg_step={avg:.2f}ms")
                return out

            type(trainer).training_step = turbo_step
        except Exception as e:
            ZeroFault.report("TURBO", "trainer patch başarısız", str(e))


class BackpropEngine:
    """Aç/kapa yapılabilen, CPU/GPU/TPU uyumlu backprop yöneticisi."""

    def __init__(self, cfg, dev):
        self.cfg = cfg
        self.dev = dev
        self._mode = self._resolve_mode()

    def _resolve_mode(self) -> str:
        if not getattr(self.cfg, "backprop_enabled", True):
            return "off"
        mode = str(getattr(self.cfg, "backprop_engine", "auto")).lower().strip()
        if mode == "auto":
            if _XLA:
                return "native"
            if getattr(self.cfg, "backprop_turbo", False):
                return "hybrid"
            return "native"
        return mode if mode in ("native", "hybrid", "fast_approx") else "native"

    @property
    def mode(self) -> str:
        return self._mode

    def maybe_patch_trainer(self, trainer):
        if self._mode == "off":
            logger.warning("BP Engine    : OFF (öğrenme devre dışı)")
            return
        try:
            orig = type(trainer).training_step
            engine = self
            validate_every = max(1, int(getattr(self.cfg, "backprop_validate_every", 20)))
            counter = {"n": 0}

            def wrapped(self_t, model, inputs, num_items_in_batch=None):
                counter["n"] += 1
                try:
                    try:
                        out = orig(self_t, model, inputs, num_items_in_batch)
                    except TypeError:
                        out = orig(self_t, model, inputs)

                    # Güvenli gradyan temizliği
                    for p in model.parameters():
                        if p.grad is not None:
                            p.grad.data = torch.nan_to_num(
                                p.grad.data, nan=0.0, posinf=0.0, neginf=0.0
                            )

                    # Hız/kalite hibritleri
                    if engine._mode in ("hybrid", "fast_approx"):
                        alpha = 0.0008 if engine._mode == "hybrid" else 0.0015
                        for p in model.parameters():
                            if p.grad is not None:
                                p.grad.data.add_(torch.sign(p.grad.data) * alpha)
                        if counter["n"] % validate_every == 0 and engine._mode == "hybrid":
                            torch.nn.utils.clip_grad_norm_(
                                model.parameters(), max(0.1, float(engine.cfg.backprop_clip_norm))
                            )
                    return out
                except Exception as e:
                    if getattr(engine.cfg, "backprop_fallback_native", True):
                        ZeroFault.report("BP_ENGINE", "wrapped fallback", str(e)[:120], exc=e)
                        try:
                            return orig(self_t, model, inputs, num_items_in_batch)
                        except TypeError:
                            return orig(self_t, model, inputs)
                    raise

            type(trainer).training_step = wrapped
            logger.info(f"BP Engine    : ✓ mode={self._mode} on {self.dev.device}")
        except Exception as e:
            ZeroFault.report("BP_ENGINE", "trainer patch başarısız", str(e), exc=e)

# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 6 — ParamMesh: PARAMETRELERİ ARASI CANLI BİLGİ AĞI
# ══════════════════════════════════════════════════════════════════════════════

class ParamMesh:
    """
    ParamMesh — Parametreler Arası Canlı Bilgi Takas Ağı  🧬

    Parametreler birbirinden bağımsız değil — bir ağ oluşturur.
    Güçlü parametre → zayıf komşusuna bilgi aktar.
    Her eğitim adımında mesh güncellenir.

    SSYP + CORAP20 ile tam entegrasyon:
    - SSYP residue → mesh'e akar
    - Mesh sinyali → CORAP20 GKP'ye beslenir
    """

    def __init__(self, model: nn.Module, mesh_strength: float = 0.002,
                 update_every: int = 10):
        self.model          = model
        self.strength       = mesh_strength
        self.update_every   = update_every
        self._step          = 0
        self._mesh_signals: Dict[str, float] = {}

    def update(self):
        """Mesh sinyallerini güncelle (gradient norm'a göre)."""
        self._step += 1
        if self._step % self.update_every != 0: return
        for name, p in self.model.named_parameters():
            if p.grad is not None:
                self._mesh_signals[name] = float(p.grad.norm())

    def propagate(self):
        """Güçlü sinyali komşulara yay."""
        if not self._mesh_signals: return
        params = list(self.model.named_parameters())
        sigs   = {n: self._mesh_signals.get(n, 0.) for n, _ in params}
        max_s  = max(sigs.values()) + 1e-8
        for i, (name, p) in enumerate(params):
            if not p.requires_grad: continue
            my_sig = sigs[name] / max_s
            if my_sig < 0.1:  # Zayıf parametre
                # Komşulardan güç al
                neighbors = [params[j][1] for j in [i-1, i+1]
                             if 0 <= j < len(params) and params[j][1].requires_grad]
                if neighbors:
                    avg_neighbor = torch.stack(
                        [nb.data.flatten()[:min(10, nb.numel())] for nb in neighbors]
                    ).mean(0)
                    size = min(avg_neighbor.numel(), p.numel())
                    with torch.no_grad():
                        flat = p.data.flatten()
                        flat[:size].add_(avg_neighbor[:size].to(p.device).to(p.dtype)
                                         * self.strength)

    def attach(self, trainer):
        try:
            from transformers import TrainerCallback
            m = self
            class _Cb(TrainerCallback):
                def on_step_end(self, args, state, control, **kw):
                    ZeroFault.run(m.update, etype="MESH", what="update")
                    ZeroFault.run(m.propagate, etype="MESH", what="propagate")
            trainer.add_callback(_Cb())
            logger.info("ParamMesh    : ✓  mesh ağı aktif")
        except Exception as e:
            ZeroFault.report("MESH", "Eklenemedi", str(e))



# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 6.5 — OMNISYNC: EVRENSEL SENKRONİZASYON MİMARİSİ  [DENEYSEL]
# ══════════════════════════════════════════════════════════════════════════════

class GeometricResonance:
    """
    🌐 OMNISYNC / Geometrik Rezonans  [DENEYSEL]

    Vizyon: Öğrenme = Hesaplama değil, FAZ HİZALAMASI.
    ─────────────────────────────────────────────────
    Geleneksel yaklaşım: Milyonlarca iterasyon + Backprop
    GeometricResonance : Veri ve model ağırlıkları aynı yüksek-boyutlu
                         uzayda iki farklı frekanstır.
                         Eğitimi saniyelerden saliselere indirmek için
                         "hatayı geriye yaymak" yerine verinin geometrik
                         izdüşümünü, modelin ağırlık matrisine TEK bir
                         "an" (one-shot alignment) içinde kilitlersin.

    Sonuç: Model veriyi "okumaz" — verinin şeklini kendi üzerine MÜHÜRLER.
    """

    def __init__(
        self,
        model:          "nn.Module",
        fft_size:         int   = 4096,
        resonance_lr:     float = 0.01,
        resonance_level:  float = 1.0,
        phase_iters:      int   = 1,          # 1 = one-shot
        dtype:            "torch.dtype" = None,
        device:           "torch.device" = None,
        adaptive_phase:   bool  = True,
    ):
        self.model          = model
        self.fft_size       = fft_size
        self.resonance_lr   = resonance_lr
        self.resonance_level = float(min(2.0, max(0.0, resonance_level)))
        self.phase_iters    = max(1, phase_iters)
        self.device         = device or torch.device("cpu")
        self.dtype          = dtype or torch.float32
        self.adaptive_phase = adaptive_phase
        self._align_count   = 0
        self._last_delta    = 0.0
        logger.info(
            f"GeoResonance : ✓  fft={fft_size}, lr={resonance_lr}, "
            f"level={self.resonance_level}, iters={phase_iters}, adaptive={adaptive_phase}"
        )

    # ── Geometrik izdüşüm ─────────────────────────────────────────────────────

    def _data_freq(self, data_tensor: "torch.Tensor") -> "torch.Tensor":
        """Veriyi frekans uzayına çevir (FFT tabanlı)."""
        flat = data_tensor.float().flatten()
        n    = min(len(flat), self.fft_size)
        freq = torch.fft.rfft(flat[:n], n=self.fft_size)
        return freq

    def _param_freq(self, param: "torch.Tensor") -> "torch.Tensor":
        """Parametreyi frekans uzayına çevir."""
        flat = param.data.float().flatten()
        n    = min(len(flat), self.fft_size)
        padded = torch.zeros(self.fft_size)
        padded[:n] = flat[:n]
        return torch.fft.rfft(padded, n=self.fft_size)

    def _phase_align(
        self,
        param: "nn.Parameter",
        data_freq: "torch.Tensor",
        name: str = ""
    ) -> float:
        """
        One-shot faz hizalaması:
        ağırlık matrisini verinin frekans baskısına doğru tek adımda it.
        """
        p_freq   = self._param_freq(param)
        # Faz farkı
        phase_diff = data_freq - p_freq
        # Uzamsal alana geri çevir
        delta    = torch.fft.irfft(phase_diff, n=self.fft_size)
        # Parametreye yansıt
        n        = min(delta.numel(), param.numel())
        flat_p   = param.data.flatten()
        eff_lr   = self.resonance_lr * self.resonance_level
        with torch.no_grad():
            flat_p[:n].add_(delta[:n].to(param.device).to(param.dtype) * eff_lr)
        return float(delta.abs().mean())

    def align(self, data_batch: "torch.Tensor") -> Dict:
        """
        Tüm parametreleri veri ile hizala — tek geçişte.
        data_batch: [B, L] token tensor veya herhangi bir float tensör.
        """
        t0        = time.perf_counter()
        data_freq = ZeroFault.run(self._data_freq, data_batch.float(),
                                  etype="OMNISYNC", what="data_freq",
                                  default=torch.zeros(self.fft_size // 2 + 1, dtype=torch.cfloat))
        if data_freq is None:
            return {"aligned": 0, "delta": 0., "ms": 0.}

        total_delta = 0.0
        n_aligned   = 0
        for _iter in range(self.phase_iters):
            for name, param in self.model.named_parameters():
                if not param.requires_grad: continue
                d = ZeroFault.run(self._phase_align, param, data_freq, name,
                                  etype="OMNISYNC", what=f"align:{name}", default=0.)
                total_delta += d or 0.
                n_aligned   += 1
            if self.adaptive_phase:
                self.resonance_lr *= 0.95   # her iterasyonda lr küçül

        self._align_count += 1
        self._last_delta   = total_delta / max(n_aligned, 1)
        dt = (time.perf_counter() - t0) * 1000
        if self._align_count % 50 == 1:
            logger.info(
                f"GeoResonance : #{self._align_count}  Δ={self._last_delta:.6f}  "
                f"{dt:.2f}ms  params={n_aligned}"
            )
        return {"aligned": n_aligned, "delta": self._last_delta, "ms": dt}

    def patch_trainer(self, trainer, dataset_tensor: Optional["torch.Tensor"] = None):
        """Trainer callback ile otomatik hizalama."""
        try:
            from transformers import TrainerCallback
            gr = self
            class _GRCb(TrainerCallback):
                def on_step_end(self, args, state, control, **kw):
                    if dataset_tensor is not None and state.global_step % 5 == 0:
                        ZeroFault.run(gr.align, dataset_tensor,
                                      etype="OMNISYNC", what="trainer align")
            trainer.add_callback(_GRCb())
            logger.info("GeoResonance : ✓  trainer callback aktif")
        except Exception as e:
            ZeroFault.report("OMNISYNC", "GeoResonance trainer hatası", str(e))


class HolographicFold:
    """
    🌐 OMNISYNC / Holografik Veri Katlama  [DENEYSEL]

    Vizyon: Sonsuz Token / Sabit İşlem Süresi
    ──────────────────────────────────────────
    Tokenları dizmek (Transformers) doğrusal zaman gerektirir.
    HolographicFold ise tüm veriyi devasa bir interference pattern
    (girişim deseni) olarak hayal eder; bu desen parametrelere
    bir lazerin aynaya vurması gibi BÜTÜNSEL olarak yansıtılır.

    Veri miktarı ne kadar artarsa artsın işlem süresi değişmez —
    veri sıralı değil, bütünsel (holistic) olarak "enjekte" edilir.
    """

    def __init__(
        self,
        hologram_dim:   int   = 2048,
        fold_strength:  float = 0.005,
        interference_fn: str  = "cosine",   # cosine | fourier | wavelet
        device:         Optional["torch.device"] = None,
    ):
        self.dim            = hologram_dim
        self.strength       = fold_strength
        self.interference   = interference_fn
        self.device         = device or torch.device("cpu")
        # Hologram tamponu (interference pattern)
        self._pattern       = torch.zeros(hologram_dim, dtype=torch.float32,
                                          device=self.device)
        self._n_injections  = 0
        logger.info(
            f"HoloFold     : ✓  dim={hologram_dim}, strength={fold_strength}, "
            f"fn={interference_fn}"
        )

    def absorb(self, token_ids: "torch.Tensor"):
        """
        Trilyonlarca tokenu tek "girişim deseni"ne katlıyor.
        Token sayısı ne olursa olsun, tek bir FFT geçişi yeter.
        """
        flat  = token_ids.float().flatten()
        n     = min(flat.numel(), self.dim)
        chunk = flat[:n]
        if self.interference == "cosine":
            proj = torch.cos(chunk * math.pi / (flat.max() + 1e-6))
        elif self.interference == "fourier":
            proj = torch.fft.rfft(chunk, n=self.dim).abs()[:self.dim]
        else:  # wavelet (Haar approximation)
            proj = chunk
        sz = min(proj.numel(), self.dim)
        self._pattern[:sz] = (
            self._pattern[:sz] * 0.9 + proj[:sz].to(self.device) * 0.1
        )
        self._n_injections += 1

    def project(self, model: "nn.Module") -> int:
        """
        Birikmiş holografik deseni modelin tüm parametrelerine yansıt.
        Her parametre aynı desenden kendi boyutuna göre dilim alır.
        """
        n_proj = 0
        for name, param in model.named_parameters():
            if not param.requires_grad: continue
            sz     = min(param.numel(), self.dim)
            signal = self._pattern[:sz].to(param.device).to(param.dtype)
            with torch.no_grad():
                flat = param.data.flatten()
                flat[:sz].add_(signal * self.strength)
            n_proj += 1
        return n_proj

    @property
    def stats(self) -> Dict:
        return {
            "injections": self._n_injections,
            "pattern_norm": float(self._pattern.norm()),
            "dim": self.dim,
        }


class AsyncSingularity:
    """
    🌐 OMNISYNC / Zaman-Dışı İşleme  [DENEYSEL]

    Vizyon: Saat vuruşlarını (clock cycles) beklemeyi bırak.
    ─────────────────────────────────────────────────────────
    "Event-driven" yapı: Bilgi sisteme girdiği an, donanımın
    tüm katmanları eşzamanlı olarak titreşir.
    Veri işlemciden geçmez — işlemci verinin içine "çöker" (collapse).

    Sonuç: Parametreler arasındaki mesafe matematiksel olarak sıfıra
    indirgenir. Bir parametrenin değişimi ışık hızıyla tüm ağı
    aynı salisede günceller.
    """

    def __init__(
        self,
        model:          "nn.Module",
        event_threads:  int   = 4,
        collapse_alpha: float = 0.01,
        pulse_every:    int   = 1,          # Her adımda
    ):
        self.model          = model
        self.collapse_alpha = collapse_alpha
        self.pulse_every    = pulse_every
        self._step          = 0
        self._event_q:      "queue.Queue" = queue.Queue(maxsize=256)
        self._stop          = threading.Event()
        self._threads:      List["threading.Thread"] = []
        self._lock          = threading.Lock()
        self._collapse_log: List[float] = []

        for i in range(event_threads):
            t = threading.Thread(
                target=self._worker, daemon=True,
                name=f"AsyncSing-{i}"
            )
            t.start()
            self._threads.append(t)

        logger.info(
            f"AsyncSing    : ✓  threads={event_threads}, "
            f"α={collapse_alpha}, pulse={pulse_every}"
        )

    def _worker(self):
        """Olay kuyruğunu tüket — her olay bir parametre grubunu günceller."""
        while not self._stop.is_set():
            try:
                event = self._event_q.get(timeout=0.05)
                self._collapse(event)
                self._event_q.task_done()
            except queue.Empty:
                pass
            except Exception as e:
                ZeroFault.report("ASYNCSING", "Worker hatası", str(e))

    def _collapse(self, event: Dict):
        """
        Parametreyi verinin içine "çökert":
        θ ← θ + α × (event_signal − θ)   (ani yakınsama adımı)
        """
        name   = event.get("name")
        signal = event.get("signal")
        if not name or signal is None: return
        for n, p in self.model.named_parameters():
            if n != name or not p.requires_grad: continue
            sz = min(signal.numel(), p.numel())
            with torch.no_grad():
                flat = p.data.flatten()
                s    = signal[:sz].to(p.device).to(p.dtype)
                # Collapse: anlık yakınsama
                flat[:sz].add_((s - flat[:sz]) * self.collapse_alpha)
            with self._lock:
                self._collapse_log.append(float((s - flat[:sz]).abs().mean()))
            break

    def pulse(self, model: Optional["nn.Module"] = None):
        """
        Tüm parametrelere eşzamanlı "nabız" atar:
        Gradient sinyalini event kuyruğuna gönderir.
        """
        self._step += 1
        if self._step % self.pulse_every != 0: return
        m = model or self.model
        for name, param in m.named_parameters():
            if param.grad is None: continue
            try:
                self._event_q.put_nowait({
                    "name":   name,
                    "signal": param.grad.detach().clone(),
                })
            except queue.Full:
                pass  # Kuyruğa sığmadı, bir sonraki adımda dener

    def stop(self):
        self._stop.set()
        for t in self._threads:
            t.join(timeout=1)

    @property
    def avg_collapse(self) -> float:
        if not self._collapse_log: return 0.
        return sum(self._collapse_log[-100:]) / len(self._collapse_log[-100:])


class QuantumGradCollapse:
    """
    🌐 OMNISYNC / Kuantum Gradyan Çöküşü  [DENEYSEL]

    Vizyon: Sıfır Geri Yayılım (Zero-Backprop)
    ───────────────────────────────────────────
    Backpropagation her katmanın bir sonrakini beklemesiyle yavaşlar.
    QuantumGradCollapse katmanlı yapıyı terk eder.

    Model tek bir Süper-Manifold (Yüksek Boyutlu Yüzey) olarak modellenir.
    Veri bu yüzeye değdiği an, yüzey en düşük enerji seviyesini
    (minimum hata) bulmak zorundadır — fiziksel bir zorunluluk gibi.

    Bu sistem matematiksel optimizasyon yapmaz; sistemi öyle bir
    fiziksel/algoritmik dengeye oturtur ki, model "yanlış bilmeyi"
    fiziksel olarak reddeder.
    """

    def __init__(
        self,
        model:         "nn.Module",
        manifold_dim:  int   = 512,
        energy_lr:     float = 0.001,
        snap_iters:    int   = 3,       # Minimum enerji aramak için iterasyon
        entropy_reg:   float = 1e-5,    # Entropi düzenleyici
    ):
        self.model       = model
        self.manifold_dim = manifold_dim
        self.energy_lr   = energy_lr
        self.snap_iters  = snap_iters
        self.entropy_reg = entropy_reg
        self._max_step    = 0.05
        # Manifold yüzey parametresi
        self._surface = torch.zeros(manifold_dim, dtype=torch.float32)
        self._min_energy = float("inf")
        self._snap_count = 0
        logger.info(
            f"QGradCollapse: ✓  manifold={manifold_dim}, lr={energy_lr}, "
            f"snap={snap_iters}"
        )

    def _energy(self, model: "nn.Module") -> float:
        """Model ağırlıklarının toplam 'enerji' skoru (L2 norm tabanlı)."""
        total = 0.
        for p in model.parameters():
            if p.requires_grad:
                total += float(p.data.norm(2))
        return total

    def _manifold_project(self, param: "nn.Parameter") -> "torch.Tensor":
        """Parametreyi süper-manifold yüzeyine yansıt."""
        flat = param.data.float().flatten()
        n    = min(flat.numel(), self.manifold_dim)
        surf = self._surface[:n].to(param.device)
        # Düşük enerji yönü: param ile surface arasındaki gradient
        direction = surf - flat[:n]
        return direction * self.energy_lr

    def snap(self) -> Dict:
        """
        Modeli minimum enerji durumuna "çek".
        Backprop yerine doğrudan yüzey yansıması.
        """
        t0 = time.perf_counter()
        e_before = self._energy(self.model)

        for _ in range(self.snap_iters):
            for name, param in self.model.named_parameters():
                if not param.requires_grad: continue
                delta = ZeroFault.run(
                    self._manifold_project, param,
                    etype="QGC", what=name, default=None
                )
                if delta is None: continue
                with torch.no_grad():
                    flat = param.data.flatten()
                    n    = min(delta.numel(), flat.numel())
                    step = delta[:n].to(param.device).to(param.dtype)
                    step = torch.nan_to_num(step, nan=0.0, posinf=self._max_step, neginf=-self._max_step)
                    step = step.clamp(-self._max_step, self._max_step)
                    flat[:n].add_(step)
                    flat.add_(torch.randn_like(flat) * self.entropy_reg)

        e_after = self._energy(self.model)
        if e_after < self._min_energy:
            self._min_energy = e_after

        self._snap_count += 1
        dt = (time.perf_counter() - t0) * 1000
        return {
            "snap": self._snap_count,
            "e_before": e_before,
            "e_after": e_after,
            "delta_e": e_before - e_after,
            "ms": dt,
        }

    def update_surface(self, reference_tensor: "torch.Tensor"):
        """Manifold yüzeyini referans veriye göre güncelle."""
        flat = reference_tensor.float().flatten()
        n    = min(flat.numel(), self.manifold_dim)
        self._surface[:n] = flat[:n]


class OmniSync:
    """
    🌐 OMNISYNC — Tüm alt sistemlerin koordinatörü  [DENEYSEL]

    Kullanım:
        omni = OmniSync(model, cfg)
        omni.absorb(token_ids)      # veri hologram'a enjekte et
        omni.tick(step)             # her adımda çağır
        omni.snap()                 # sıfır-backprop enerji minimizasyonu
    """

    def __init__(
        self,
        model:    "nn.Module",
        cfg:      Optional["TOREloRAConfig"] = None,
        device:   Optional["torch.device"]   = None,
    ):
        self.model  = model
        self.device = device or torch.device("cpu")
        c           = cfg

        enabled_gr   = getattr(c, "omnisync_resonance",   True)  if c else True
        enabled_hf   = getattr(c, "omnisync_holographic", True)  if c else True
        enabled_as   = getattr(c, "omnisync_async",       True)  if c else True
        enabled_qgc  = getattr(c, "omnisync_qgc",         True)  if c else True
        _lvl         = float(getattr(c, "resonance_level", 1.0)) if c else 1.0

        _fft = getattr(c, "omnisync_fft_size", 4096) if c else 4096
        _rlr = getattr(c, "omnisync_resonance_lr", 0.01) if c else 0.01
        self.gr  = GeometricResonance(
            model,
            fft_size=_fft,
            resonance_lr=_rlr,
            resonance_level=_lvl,
            device=device,
        ) if enabled_gr else None
        self.hf  = HolographicFold(device=device)              if enabled_hf  else None
        self.as_ = AsyncSingularity(model)                     if enabled_as  else None
        self.qgc = QuantumGradCollapse(model)                  if enabled_qgc else None

        logger.info(
            f"OmniSync     : ✓  resonance={enabled_gr} holo={enabled_hf} "
            f"async={enabled_as} qgc={enabled_qgc}"
        )

    def absorb(self, token_ids: "torch.Tensor"):
        """Veriyi hologram'a ve geometrik rezonansa besle."""
        if self.hf:
            ZeroFault.run(self.hf.absorb, token_ids,
                          etype="OMNISYNC", what="holo absorb")
        if self.gr:
            ZeroFault.run(self.gr.align, token_ids.float(),
                          etype="OMNISYNC", what="geo align")

    def tick(self, step: int = 0):
        """Her eğitim adımında çağrılır."""
        if self.as_:
            ZeroFault.run(self.as_.pulse, etype="OMNISYNC", what="pulse")
        if self.hf and step % 10 == 0:
            ZeroFault.run(self.hf.project, self.model,
                          etype="OMNISYNC", what="holo project")

    def snap(self) -> Optional[Dict]:
        """Sıfır-backprop enerji minimizasyonu."""
        if self.qgc:
            return ZeroFault.run(self.qgc.snap,
                                 etype="OMNISYNC", what="qgc snap", default=None)
        return None

    def stop(self):
        if self.as_: self.as_.stop()

    def patch_trainer(self, trainer):
        """Trainer'a OmniSync callback ekle."""
        try:
            from transformers import TrainerCallback
            omni = self
            class _OCb(TrainerCallback):
                def on_step_end(self, args, state, control, **kw):
                    ZeroFault.run(omni.tick, state.global_step,
                                  etype="OMNISYNC", what="tick")
                    if state.global_step % 20 == 0:
                        ZeroFault.run(omni.snap,
                                      etype="OMNISYNC", what="snap")
                def on_train_end(self, args, state, control, **kw):
                    omni.stop()
            trainer.add_callback(_OCb())
            logger.info("OmniSync     : ✓  trainer callback aktif")
        except Exception as e:
            ZeroFault.report("OMNISYNC", "Trainer callback", str(e))


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 6.6 — BBGH AGI: GERÇEK YAPAY GENEL ZEKA MOTORU  [v1.0.4]
# ══════════════════════════════════════════════════════════════════════════════

class _CausalNode:
    """
    Nedensellik grafiğindeki bir düğüm.
    "X oldu çünkü Y" yapısını geometrik uzayda temsil eder.
    """
    __slots__ = ("nid", "text", "vec", "causes", "effects", "strength", "ts")

    def __init__(self, nid: str, text: str, vec: "torch.Tensor"):
        self.nid      = nid
        self.text     = text
        self.vec      = vec.float().flatten()
        self.causes:  List[str] = []  # Bu düğümü NEYIN NEDEN olduğu
        self.effects: List[str] = []  # Bu düğüm NEYE YOL AÇAR
        self.strength = 1.0
        self.ts       = time.time()


class _CausalGraph:
    """
    Yönlü nedensellik grafiği.
    Bilgi "X → Y" bağlantıları ile depolanır.
    Tek bir sorgudan çok-adımlı çıkarım yapılır.
    """

    def __init__(self, max_nodes: int = 50_000):
        self._nodes:   Dict[str, _CausalNode] = {}
        self._lock     = threading.Lock()
        self._max      = max_nodes

    def add_node(self, node: _CausalNode):
        with self._lock:
            if len(self._nodes) >= self._max:
                # En zayıf düğümü tahliye et
                weakest = min(self._nodes.values(), key=lambda n: n.strength)
                del self._nodes[weakest.nid]
            self._nodes[node.nid] = node

    def add_causal_link(self, cause_id: str, effect_id: str):
        with self._lock:
            if cause_id in self._nodes:
                if effect_id not in self._nodes[cause_id].effects:
                    self._nodes[cause_id].effects.append(effect_id)
            if effect_id in self._nodes:
                if cause_id not in self._nodes[effect_id].causes:
                    self._nodes[effect_id].causes.append(cause_id)

    def multi_hop_reason(
        self, start_vec: "torch.Tensor", hops: int = 4, top_k: int = 3
    ) -> List[Dict]:
        """
        Çok-adımlı nedensellik çıkarımı.
        Başlangıç vektöründen başla → en benzer düğümü bul →
        etkilerini takip et → ... → hops adım sonra varış
        """
        with self._lock:
            nodes = list(self._nodes.values())

        if not nodes:
            return []

        # İlk düğümü bul
        q = start_vec.float().flatten()
        scores = []
        for node in nodes:
            n = min(q.numel(), node.vec.numel())
            dot  = float((q[:n] * node.vec[:n]).sum())
            norm = float(q[:n].norm() * node.vec[:n].norm()) + 1e-8
            scores.append((dot / norm, node))
        scores.sort(key=lambda x: x[0], reverse=True)

        chain: List[Dict] = []
        visited: set      = set()
        current_nodes     = [s[1] for s in scores[:top_k]]

        for hop in range(hops):
            next_nodes: List[_CausalNode] = []
            for node in current_nodes:
                if node.nid in visited:
                    continue
                visited.add(node.nid)
                chain.append({
                    "hop":      hop,
                    "text":     node.text,
                    "strength": node.strength,
                    "n_effects": len(node.effects),
                })
                # Etkileri sıraya al
                with self._lock:
                    for eid in node.effects[:top_k]:
                        if eid in self._nodes:
                            next_nodes.append(self._nodes[eid])
            if not next_nodes:
                break
            current_nodes = next_nodes

        return chain

    def __len__(self):
        return len(self._nodes)


class _WorkingMemory:
    """
    Çalışma belleği — kısa vadeli bağlam yönetimi.
    İnsan çalışma belleğini taklit eder: sınırlı kapasite, LIFO erişim.
    """

    def __init__(self, capacity: int = 16, embed_dim: int = 512):
        self._stack:  deque = deque(maxlen=capacity)
        self._embed   = embed_dim
        self._lock    = threading.Lock()

    def push(self, text: str, vec: "torch.Tensor"):
        with self._lock:
            self._stack.append({"text": text, "vec": vec.clone(), "ts": time.time()})

    def peek(self, n: int = 4) -> List[Dict]:
        with self._lock:
            items = list(self._stack)
            return items[-n:]

    def context_vector(self) -> "torch.Tensor":
        """Tüm çalışma belleğini tek bir bağlam vektöründe özetle."""
        with self._lock:
            if not self._stack:
                return torch.zeros(self._embed)
            vecs = [item["vec"][:self._embed] for item in self._stack]
        stacked = torch.stack(vecs)
        # Zaman ağırlıklı ortalama — yeni bağlam daha ağır
        weights = torch.softmax(
            torch.arange(len(vecs), dtype=torch.float32) / max(len(vecs) - 1, 1),
            dim=0
        )
        return (stacked * weights.unsqueeze(1)).sum(0)

    def clear(self):
        with self._lock:
            self._stack.clear()

    def __len__(self):
        return len(self._stack)


class _AbstractArchetype:
    """
    Soyut arketip — bir kavram kümesinin özü.
    Birden fazla bellek hücresinin geometrik merkezi.
    Soyutlama düzeyi: bireysel örnek → genel kavram
    """
    __slots__ = ("label", "centroid", "radius", "member_count", "ts")

    def __init__(self, label: str, centroid: "torch.Tensor",
                 radius: float = 0.15):
        self.label        = label
        self.centroid     = centroid.float().flatten()
        self.radius       = radius
        self.member_count = 1
        self.ts           = time.time()

    def absorb(self, vec: "torch.Tensor", lr: float = 0.1):
        """Yeni vektörü arketipe yavaşça ekle (online centroid update)."""
        n = min(vec.numel(), self.centroid.numel())
        self.centroid[:n] = (
            (1 - lr) * self.centroid[:n] + lr * vec.float().flatten()[:n]
        )
        self.member_count += 1

    def covers(self, vec: "torch.Tensor") -> bool:
        """Verilen vektör bu arketipin alanına giriyor mu?"""
        n   = min(vec.numel(), self.centroid.numel())
        dot = float((self.centroid[:n] * vec.float().flatten()[:n]).sum())
        nm  = float(self.centroid[:n].norm() * vec.float().flatten()[:n].norm()) + 1e-8
        return (dot / nm) >= (1.0 - self.radius)


class BBGHMemoryCell:
    """💡 BBGH / Bellek Hücresi (geriye uyumluluk için korundu)"""
    __slots__ = ("key", "value", "strength", "ts")

    def __init__(self, key: "torch.Tensor", value: str, strength: float = 1.0):
        self.key      = key.float().flatten()
        self.value    = value
        self.strength = strength
        self.ts       = time.time()

    def similarity(self, query: "torch.Tensor") -> float:
        q = query.float().flatten()
        n = min(q.numel(), self.key.numel())
        a = self.key[:n]; b = q[:n]
        dot  = float((a * b).sum())
        norm = float(a.norm() * b.norm()) + 1e-8
        return dot / norm


class BBGHEngine:
    """
    🧠 BBGH AGI v2 — geometrik hafıza + deneysel muhakeme katmanları  v1.0.5

    ┌──────────────────────────────────────────────────────────────────────────┐
    │  GELENEKSEL LLM   : Token → Parametre Matrisi → İstatistiksel Tahmin    │
    │  RAG              : Token → Arama İndeksi → Eşleşme → Birleştirme      │
    │  BBGH AGI         : Anlam → Geometrik Uzay → Nedensellik → Bilgi       │
    │                                                                          │
    │  AGI Yetenekleri:                                                        │
    │  ✓ Nedensellik Grafiği  — "X oldu çünkü Y" bağlantıları                │
    │  ✓ Çalışma Belleği      — İnsan kısa-vadeli belleği gibi                │
    │  ✓ Soyut Arketipler     — Kavramlar → Genel şablonlar                  │
    │  ✓ Çok-adımlı Çıkarım   — A → B → C → D zinciri                       │
    │  ✓ Karşı-olgusal Düş.  — "Y olmasaydı ne olurdu?" sorusuna cevap      │
    │  ✓ Öz-değişim           — Kendi generator katmanlarını günceller        │
    │  ✓ Güven Kalibrasyonu   — Epistemic belirsizlik skoru                   │
    │  ✓ Hedef-yönelimli Ürt. — Çıktıyı hedef anlam bölgesine yönlendir     │
    │  ✓ Anlık Öğrenme        — Backprop yok, iterasyon yok, one-shot        │
    │  ✓ Meta-öğrenme         — Öğrenme hızını kendi başına ayarlar          │
    │                                                                          │
    │  Eğitim: SIFIR — Backprop, gradient, optimizer YOK                      │
    │  Bellek: O(n×d) — n hücre × d boyut                                     │
    │  Hız: Mikrosaniye sorgu, anlık öğrenme                                  │
    └──────────────────────────────────────────────────────────────────────────┘
    """

    def __init__(
        self,
        embed_dim:          int   = 512,
        max_cells:          int   = 100_000,
        similarity_thresh:  float = 0.72,
        temperature:        float = 1.0,
        generator_depth:    int   = 5,
        working_mem_size:   int   = 32,
        max_archetypes:     int   = 2_048,
        causal_max_nodes:   int   = 50_000,
        meta_lr:            float = 0.05,
        counterfactual_eps: float = 0.1,
        bbgh_synthetic_boost: float = 1.4,
        agi_mode: bool = False,
        self_consistency: int = 3,
        plan_depth: int = 3,
        device: Optional["torch.device"] = None,
    ):
        self.embed_dim          = embed_dim
        self.max_cells          = max_cells
        self.thresh             = similarity_thresh
        self.temperature        = temperature
        self.gen_depth          = generator_depth
        self.meta_lr            = meta_lr
        self.counterfactual_eps = counterfactual_eps
        self.bbgh_synthetic_boost = float(max(0.5, min(3.0, bbgh_synthetic_boost)))
        self.agi_mode = bool(agi_mode)
        self.self_consistency = min(9, max(1, int(self_consistency)))
        self.plan_depth = min(8, max(1, int(plan_depth)))
        self.device             = device or torch.device("cpu")
        self._active_goals: List[str] = []

        # ── Temel depo ────────────────────────────────────────────────────────
        self._cells:       List["BBGHMemoryCell"] = []
        self._lock         = threading.Lock()
        self._learn_count  = 0
        self._query_count  = 0

        # ── AGI Bileşenleri ───────────────────────────────────────────────────
        self._causal    = _CausalGraph(max_nodes=causal_max_nodes)
        self._working   = _WorkingMemory(capacity=working_mem_size, embed_dim=embed_dim)
        self._archetypes: List[_AbstractArchetype]  = []
        self._arch_lock  = threading.Lock()
        self._max_arch   = max_archetypes

        # ── Generator Katmanları (öz-değişen) ────────────────────────────────
        self._gen_layers: List["torch.Tensor"] = [
            torch.randn(embed_dim, embed_dim) * 0.01
            for _ in range(generator_depth)
        ]
        # Her katman için adaptif öğrenme hızı (meta-öğrenme)
        self._gen_lr: List[float] = [meta_lr] * generator_depth

        # ── Güven Kalibrasyonu ────────────────────────────────────────────────
        self._confidence_history: deque = deque(maxlen=200)
        self._calibration_bias   = 0.0   # Kalibrasyon önyargısı

        # ── Meta-öğrenme istatistikleri ───────────────────────────────────────
        self._meta_stats = {
            "successful_queries": 0,
            "failed_queries":     0,
            "self_modifications": 0,
            "archetypes_formed":  0,
            "causal_links":       0,
            "counterfactuals":    0,
        }

        logger.info(
            f"BBGH AGI     : ✓  dim={embed_dim}, max_cells={max_cells}, "
            f"gen_depth={generator_depth}, working_mem={working_mem_size}, "
            f"archetypes={max_archetypes}, causal_nodes={causal_max_nodes}"
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Metin → Geometrik Vektör Dönüşümü
    # ══════════════════════════════════════════════════════════════════════════

    def _text_to_vector(self, text: str) -> "torch.Tensor":
        """
        Metni yüksek-boyutlu geometrik vektöre çevir.
        v1.0.4: Çok katmanlı encoding — karakter + n-gram + pozisyonel
        """
        if not text:
            return torch.zeros(self.embed_dim)

        text_t = text[:8192]  # Limit

        # Katman 1: Karakter FFT (unicode frekans spektrumu)
        chars  = [ord(c) for c in text_t]
        t      = torch.tensor(chars, dtype=torch.float32)
        freq   = torch.fft.rfft(t, n=self.embed_dim * 2)
        v1     = torch.cat([freq.real[:self.embed_dim],
                            freq.imag[:self.embed_dim]])[:self.embed_dim]

        # Katman 2: Bigram frekansları
        if len(chars) > 1:
            bigrams = [(chars[i] * 256 + chars[i+1]) % (self.embed_dim * 4)
                       for i in range(len(chars) - 1)]
            v2_raw  = torch.zeros(self.embed_dim * 4)
            for bg in bigrams:
                v2_raw[bg % (self.embed_dim * 4)] += 1.0
            v2 = v2_raw[:self.embed_dim].clone()
        else:
            v2 = torch.zeros(self.embed_dim)

        # Katman 3: Pozisyonel encoding (ilk/son kelimelerin vurgusu)
        words   = text_t.split()[:64]
        v3      = torch.zeros(self.embed_dim)
        for i, w in enumerate(words):
            pos_weight = 1.0 / (1.0 + i * 0.1)  # İlk kelimeler daha önemli
            w_hash     = int(hashlib.md5(w.encode()).hexdigest()[:8], 16)
            idx        = w_hash % self.embed_dim
            v3[idx]   += pos_weight

        # Birleştir ve normalize et
        alpha, beta, gamma = 0.5, 0.3, 0.2
        vec = alpha * v1 + beta * v2 + gamma * v3
        nrm = vec.norm() + 1e-8
        return (vec / nrm).to(self.device)

    # ══════════════════════════════════════════════════════════════════════════
    # Anlık Öğrenme & Bellek Yönetimi
    # ══════════════════════════════════════════════════════════════════════════

    def learn(self, text: str, label: Optional[str] = None,
              context: Optional[str] = None) -> bool:
        """
        Anlık one-shot öğrenme.
        v1.0.4: Nedensellik bağlantısı + Arketip güncelleme + Çalışma belleği
        """
        vec = ZeroFault.run(self._text_to_vector, text,
                            etype="BBGH", what="text2vec", default=None)
        if vec is None:
            return False

        # ── 1. Deduplikasyon ─────────────────────────────────────────────────
        with self._lock:
            for cell in self._cells[-50:]:
                if cell.similarity(vec) > 0.95:
                    cell.strength = min(cell.strength + 0.1, 10.0)
                    # Mevcut hücreyi arketiple güncelle
                    self._update_archetype(vec, label or text[:50])
                    return True

        # ── 2. Bellek hücresi oluştur ─────────────────────────────────────────
        cell = BBGHMemoryCell(vec, label or text[:200])
        with self._lock:
            if len(self._cells) >= self.max_cells:
                # Güç × yaş sıralaması ile tahliye
                self._cells.sort(
                    key=lambda c: c.strength / (time.time() - c.ts + 1)
                )
                self._cells = self._cells[len(self._cells) // 10:]
            self._cells.append(cell)
            self._learn_count += 1

        # ── 3. Nedensellik grafiğine ekle ────────────────────────────────────
        node_id = hashlib.md5(text[:100].encode()).hexdigest()[:12]
        node    = _CausalNode(node_id, label or text[:200], vec)
        self._causal.add_node(node)

        # Bağlam varsa nedensellik bağlantısı kur
        if context:
            ctx_id = hashlib.md5(context[:100].encode()).hexdigest()[:12]
            self._causal.add_causal_link(ctx_id, node_id)
            self._meta_stats["causal_links"] += 1

        # ── 4. Arketip güncelle ───────────────────────────────────────────────
        self._update_archetype(vec, label or text[:50])

        # ── 5. Çalışma belleğine ekle ─────────────────────────────────────────
        self._working.push(label or text[:80], vec)

        # ── 6. Generator one-shot hizala ──────────────────────────────────────
        self._oneshot_align_generator(vec)

        return True

    def _update_archetype(self, vec: "torch.Tensor", label: str):
        """Vektörü en yakın arketipe ekle ya da yeni arketip oluştur."""
        with self._arch_lock:
            for arch in self._archetypes:
                if arch.covers(vec):
                    arch.absorb(vec, lr=self.meta_lr)
                    return

            # Yeni arketip
            if len(self._archetypes) >= self._max_arch:
                # En az üyeli arketipi tahliye et
                self._archetypes.sort(key=lambda a: a.member_count)
                self._archetypes.pop(0)

            new_arch = _AbstractArchetype(label, vec.clone())
            self._archetypes.append(new_arch)
            self._meta_stats["archetypes_formed"] += 1

    def _oneshot_align_generator(self, signal: "torch.Tensor"):
        """Generator katmanlarını sinyale geometrik olarak hizala. Backprop yok."""
        for i, layer in enumerate(self._gen_layers):
            n   = min(signal.numel(), layer.shape[0])
            sig = signal[:n]
            lr  = self._gen_lr[i]
            # Katmanı sinyal yönüne it
            update = sig.unsqueeze(1).expand(n, n) * lr
            self._gen_layers[i][:n, :n] = (
                self._gen_layers[i][:n, :n] * (1 - lr) + update
            )
        self._meta_stats["self_modifications"] += 1

    def batch_learn(self, texts: List[str],
                    contexts: Optional[List[str]] = None) -> int:
        """Toplu anlık öğrenme — ardışık bağlam zinciri ile."""
        t0 = time.perf_counter()
        n  = 0
        for i, text in enumerate(texts):
            ctx = texts[i - 1] if i > 0 and contexts is None else (
                  contexts[i - 1] if contexts and i > 0 else None)
            if self.learn(text, context=ctx):
                n += 1
        dt = (time.perf_counter() - t0) * 1000
        logger.info(f"BBGH AGI     : {n}/{len(texts)} öğrenildi  {dt:.1f}ms  "
                    f"(arketip={len(self._archetypes)}, "
                    f"causal_nodes={len(self._causal)})")
        return n

    # ══════════════════════════════════════════════════════════════════════════
    # Sorgulama
    # ══════════════════════════════════════════════════════════════════════════

    def query(self, text: str, top_k: int = 5) -> List[Dict]:
        """Geometrik benzerlik ile en yakın hafıza hücrelerini bul."""
        vec = ZeroFault.run(self._text_to_vector, text,
                            etype="BBGH", what="query2vec", default=None)
        if vec is None or not self._cells:
            return []

        self._query_count += 1
        ctx_vec = self._working.context_vector().to(self.device)

        scores = []
        with self._lock:
            for cell in self._cells:
                base_sim = cell.similarity(vec)
                # Çalışma belleği katkısı
                n       = min(ctx_vec.numel(), cell.key.numel())
                ctx_sim = float((ctx_vec[:n] * cell.key[:n]).sum() /
                                (ctx_vec[:n].norm() * cell.key[:n].norm() + 1e-8))
                # Kombine skor: %80 semantik + %20 bağlamsal
                combined = 0.8 * base_sim + 0.2 * max(ctx_sim, 0.0)
                if combined >= self.thresh:
                    scores.append({
                        "value":      cell.value,
                        "score":      combined,
                        "base_score": base_sim,
                        "ctx_score":  ctx_sim,
                        "strength":   cell.strength,
                    })

        scores.sort(key=lambda x: x["score"] * x["strength"], reverse=True)
        return scores[:top_k]

    # ══════════════════════════════════════════════════════════════════════════
    # Nedensellik Muhakemesi
    # ══════════════════════════════════════════════════════════════════════════

    def reason(self, query_text: str, hops: int = 5) -> Dict:
        """
        Çok-adımlı nedensellik çıkarımı.
        "X neden oldu?" → A → B → C → D zinciri → Açıklama
        """
        vec   = ZeroFault.run(self._text_to_vector, query_text,
                              etype="BBGH", what="reason_vec", default=None)
        if vec is None:
            return {"chain": [], "conclusion": "[BBGH: Vektör oluşturulamadı]",
                    "confidence": 0.0}

        # Çalışma belleğiyle bağlamı zenginleştir
        ctx_vec  = self._working.context_vector().to(self.device)
        enriched = (0.7 * vec + 0.3 * ctx_vec[:vec.numel()]).clone()
        nrm      = enriched.norm() + 1e-8
        enriched = enriched / nrm

        chain = self._causal.multi_hop_reason(enriched, hops=hops, top_k=3)

        # Doğrudan sorgula
        hits = self.query(query_text, top_k=5)

        # Güven skoru hesapla
        if hits:
            raw_conf = hits[0]["score"]
            conf     = max(0.0, min(1.0, raw_conf + self._calibration_bias))
        else:
            conf = 0.0

        # Sonuç cümlesini oluştur
        conclusion = self._compose_from_chain(chain, hits)

        # İstatistik güncelle
        if conf > 0.5:
            self._meta_stats["successful_queries"] += 1
        else:
            self._meta_stats["failed_queries"] += 1
        self._confidence_history.append(conf)

        # Meta-öğrenme: başarı oranına göre öğrenme hızını ayarla
        self._meta_adjust()

        # Çalışma belleğini güncelle
        self._working.push(query_text, enriched)

        return {
            "chain":      chain,
            "hits":       hits,
            "conclusion": conclusion,
            "confidence": conf,
            "hops":       len(chain),
        }

    def deliberate(self, query_text: str, target_domain: Optional[str] = None) -> Dict[str, Any]:
        """
        AGI-benzeri çok-aşamalı düşünme:
        - plan adımları üret
        - self-consistency ile birden çok aday reason çalıştır
        - en güvenli sonucu seç
        """
        steps = [
            f"Soruyu ayrıştır: {query_text[:120]}",
            "Nedensel zinciri çıkar",
            "Karşı-olgusal alternatif üret",
            "En tutarlı sonucu seç",
        ][: self.plan_depth]

        candidates: List[Dict[str, Any]] = []
        n = self.self_consistency if self.agi_mode else 1
        for i in range(n):
            probe = query_text if i == 0 else f"{query_text} [{i}]"
            r = ZeroFault.run(self.reason, probe, self.plan_depth + 1, etype="BBGH", what="deliberate", default=None)
            if r:
                h = ZeroFault.run(self.hypothesize, probe, False, etype="BBGH", what="deliberate_hyp", default={})
                r["counterfactual"] = h
                # Sentetik muhakeme katkısı
                r["score"] = float(r.get("confidence", 0.0)) * self.bbgh_synthetic_boost
                candidates.append(r)

        if not candidates:
            return {"steps": steps, "final": "[BBGH: Sonuç üretilemedi]", "confidence": 0.0}

        best = max(candidates, key=lambda x: float(x.get("score", 0.0)))
        final = best.get("conclusion", "")
        if target_domain:
            # Recursion'dan kaçınmak için burada generate çağırma; sonucu hedef domaine
            # doğrudan rehber metinle hizala.
            final = f"[{target_domain}] {final}"
        return {
            "steps": steps,
            "candidates": len(candidates),
            "final": final,
            "confidence": float(best.get("confidence", 0.0)),
            "chain": best.get("chain", []),
        }

    def _extract_goals(self, query_text: str) -> List[str]:
        """Sorgudan basit hedef kümesi çıkarır (planlayıcı çekirdek)."""
        toks = [t.strip(".,:;!?()[]{}\"'").lower() for t in query_text.split()]
        toks = [t for t in toks if len(t) > 3]
        uniq: List[str] = []
        for t in toks:
            if t not in uniq:
                uniq.append(t)
            if len(uniq) >= 6:
                break
        return uniq or ["general_reasoning"]

    def set_goals(self, goals: List[str]) -> None:
        self._active_goals = [g[:64] for g in goals if isinstance(g, str) and g.strip()][:12]

    def agi_research_cycle(self, query_text: str, cycles: int = 3,
                           target_domain: Optional[str] = None) -> Dict[str, Any]:
        """
        AGI-benzeri araştırma döngüsü:
        perceive -> plan -> deliberate -> verify -> reflect.
        """
        cycles = max(1, min(8, int(cycles)))
        if not self._active_goals:
            self._active_goals = self._extract_goals(query_text)

        log: List[Dict[str, Any]] = []
        best_final = ""
        best_conf = 0.0
        for i in range(cycles):
            d = ZeroFault.run(
                self.deliberate, query_text, target_domain,
                etype="BBGH", what="agi_cycle_deliberate",
                default={"final": "", "confidence": 0.0, "steps": []}
            )
            final = str(d.get("final", ""))
            conf = float(d.get("confidence", 0.0))
            gap = ZeroFault.run(
                self.analyze_cognitive_gaps, query_text,
                etype="BBGH", what="agi_cycle_gap",
                default={"gaps": ["analysis_failed"], "confidence": 0.0}
            )
            n_gaps = len(gap.get("gaps", []))
            score = conf * (1.0 - min(0.6, n_gaps * 0.1))
            log.append({
                "cycle": i + 1,
                "confidence": conf,
                "gaps": n_gaps,
                "score": score,
                "final": final[:180],
            })
            if score > best_conf:
                best_conf = score
                best_final = final

            # Zayıfsa bağlamı güçlendir
            if n_gaps > 0:
                self.learn(f"Goal context: {' | '.join(self._active_goals)}", label="agi_goal_context")
            ZeroFault.run(self.reflect, etype="BBGH", what="agi_cycle_reflect", default=None)

        return {
            "goals": list(self._active_goals),
            "cycles": cycles,
            "best_final": best_final or "[BBGH: sonuç oluşmadı]",
            "best_score": best_conf,
            "trace": log,
        }

    def _compose_from_chain(self, chain: List[Dict],
                            hits: List[Dict]) -> str:
        """Nedensellik zinciri + doğrudan eşleşmelerden sonuç cümlesi üret."""
        parts = []

        if hits:
            parts.append(hits[0]["value"])

        if len(chain) > 1:
            intermediates = [c["text"] for c in chain[1:3]]
            if intermediates:
                parts.extend(intermediates)

        if not parts:
            return "[BBGH AGI: İlgili bilgi bulunamadı]"

        # Tekrarları temizle
        seen = set()
        unique = []
        for p in parts:
            key = p[:40]
            if key not in seen:
                seen.add(key)
                unique.append(p)

        return " → ".join(unique[:3])

    # ══════════════════════════════════════════════════════════════════════════
    # Karşı-olgusal Düşünme
    # ══════════════════════════════════════════════════════════════════════════

    def hypothesize(self, premise: str, negation: bool = False) -> Dict:
        """
        Karşı-olgusal düşünme: "X olmasaydı ne olurdu?"
        Geometrik pertürbasyon ile alternatif senaryoyu keşfeder.
        """
        self._meta_stats["counterfactuals"] += 1
        vec = ZeroFault.run(self._text_to_vector, premise,
                            etype="BBGH", what="hypothesize_vec", default=None)
        if vec is None:
            return {"scenario": "[BBGH: Hipotez oluşturulamadı]",
                    "confidence": 0.0, "delta": 0.0}

        # Karşıt vektör oluştur: orijinali pertürbe et
        eps = self.counterfactual_eps
        if negation:
            # Tam ters: "X değil" → orijinalin yansıması
            alt_vec = -vec + torch.randn_like(vec) * eps
        else:
            # Alternatif: rastgele pertürbasyon
            alt_vec = vec + torch.randn_like(vec) * eps

        nrm     = alt_vec.norm() + 1e-8
        alt_vec = alt_vec / nrm

        # Alt-vektörle sorgula
        alt_hits = []
        with self._lock:
            for cell in self._cells:
                n    = min(alt_vec.numel(), cell.key.numel())
                dot  = float((alt_vec[:n] * cell.key[:n]).sum())
                norm = float(alt_vec[:n].norm() * cell.key[:n].norm()) + 1e-8
                sim  = dot / norm
                if sim > self.thresh * 0.8:  # Biraz daha geniş eşik
                    alt_hits.append({"value": cell.value, "score": sim})

        alt_hits.sort(key=lambda x: x["score"], reverse=True)

        # Orijinal ile fark
        orig_hits = self.query(premise, top_k=1)
        delta = 0.0
        if orig_hits and alt_hits:
            delta = abs(orig_hits[0]["score"] - alt_hits[0]["score"])

        scenario = alt_hits[0]["value"] if alt_hits else "[BBGH: Alternatif bulunamadı]"
        confidence = alt_hits[0]["score"] if alt_hits else 0.0

        return {
            "premise":    premise,
            "scenario":   scenario,
            "confidence": confidence,
            "delta":      delta,
            "negated":    negation,
        }

    # ══════════════════════════════════════════════════════════════════════════
    # Hedef-yönelimli Üretim
    # ══════════════════════════════════════════════════════════════════════════

    def generate(self, query_text: str, target_domain: Optional[str] = None,
                 max_words: int = 80) -> str:
        """
        AGI-düzeyinde hedef-yönelimli üretim.
        - Nedensellik zincirini kullanır
        - Çalışma belleği bağlamını dikkate alır
        - Arketiplerle kavramsal tutarlılık sağlar
        - Hedef domain'e doğru yönelir
        """
        if self.agi_mode:
            d = self.deliberate(query_text, target_domain=target_domain)
            f = str(d.get("final", ""))
            if f:
                return f[:max_words * 8]
        result = self.reason(query_text, hops=4)
        hits   = result.get("hits", [])

        if not hits:
            return "[BBGH AGI: İlgili bilgi bulunamadı]"

        # Temel bileşenler
        top  = hits[:4]
        vecs = []
        for h in top:
            v = ZeroFault.run(
                self._text_to_vector, h["value"],
                etype="BBGH", what="gen_vec", default=None
            )
            if v is not None:
                vecs.append((v, h["score"] * h["strength"]))

        if not vecs:
            return hits[0]["value"]

        # Ağırlıklı kombinasyon
        total_w = sum(w for _, w in vecs) + 1e-8
        combined = sum(v * (w / total_w) for v, w in vecs)

        # Hedef domain varsa yönlendir
        if target_domain:
            tgt_vec = self._text_to_vector(target_domain)
            combined = 0.6 * combined + 0.4 * tgt_vec[:combined.numel()]

        # Arketip bağlamı ekle
        with self._arch_lock:
            if self._archetypes:
                best_arch = max(
                    self._archetypes,
                    key=lambda a: float((a.centroid[:combined.numel()] *
                                         combined).sum() /
                                        (a.centroid[:combined.numel()].norm() *
                                         combined.norm() + 1e-8))
                )
                arch_n = min(best_arch.centroid.numel(), combined.numel())
                combined[:arch_n] = (
                    0.85 * combined[:arch_n] +
                    0.15 * best_arch.centroid[:arch_n].to(combined.device)
                )

        # Generator katmanlarından geçir
        sig = combined.clone()
        for i, layer in enumerate(self._gen_layers):
            n   = min(sig.numel(), layer.shape[0])
            sig[:n] = torch.tanh(
                layer[:n, :n] @ sig[:n] / (self.temperature + 1e-8)
            )

        # En yakın hücreyi sinyal üzerinden seç
        best_score = -1.0
        best_text  = hits[0]["value"]
        with self._lock:
            for cell in self._cells[-500:]:  # Son 500'e bak
                n = min(sig.numel(), cell.key.numel())
                sc = float((sig[:n] * cell.key[:n]).sum() /
                           (sig[:n].norm() * cell.key[:n].norm() + 1e-8))
                if sc > best_score:
                    best_score = sc
                    best_text  = cell.value

        # Zincir açıklamasını ekle
        chain = result.get("chain", [])
        if len(chain) > 1:
            chain_texts = [c["text"][:60] for c in chain[1:3]]
            conclusion  = best_text + " [" + " → ".join(chain_texts) + "]"
        else:
            conclusion = best_text

        return conclusion[:max_words * 8]  # Yaklaşık max_words

    # ══════════════════════════════════════════════════════════════════════════
    # Soyut Kavram Damıtma
    # ══════════════════════════════════════════════════════════════════════════

    def distill_archetypes(self) -> int:
        """
        Hafıza hücrelerini tarayarak soyut arketipleri yeniden oluştur.
        Kümeleme yerine online geometrik gruplama.
        """
        with self._lock:
            cells = list(self._cells)

        formed = 0
        for cell in cells:
            self._update_archetype(cell.key, cell.value[:50])

        # Çok yakın arketipleri birleştir
        merged = 0
        with self._arch_lock:
            i = 0
            while i < len(self._archetypes):
                j = i + 1
                while j < len(self._archetypes):
                    a1 = self._archetypes[i]
                    a2 = self._archetypes[j]
                    n  = min(a1.centroid.numel(), a2.centroid.numel())
                    sim = float(
                        (a1.centroid[:n] * a2.centroid[:n]).sum() /
                        (a1.centroid[:n].norm() * a2.centroid[:n].norm() + 1e-8)
                    )
                    if sim > 0.92:
                        # Birleştir
                        a1.absorb(a2.centroid, lr=0.5)
                        a1.member_count += a2.member_count
                        self._archetypes.pop(j)
                        merged += 1
                    else:
                        j += 1
                i += 1

        logger.info(
            f"BBGH AGI     : Arketip damıtma · "
            f"{len(self._archetypes)} arketip · {merged} birleşme"
        )
        return len(self._archetypes)

    # ══════════════════════════════════════════════════════════════════════════
    # Meta-öğrenme: Öz-ayarlama
    # ══════════════════════════════════════════════════════════════════════════

    def _meta_adjust(self):
        """
        Meta-öğrenme: Son sorgu başarı oranına göre generator öğrenme
        hızlarını otomatik ayarla. Fiziği kandır — daha hızlı öğren.
        """
        if len(self._confidence_history) < 20:
            return
        recent = list(self._confidence_history)[-20:]
        avg    = sum(recent) / len(recent)

        for i in range(len(self._gen_lr)):
            if avg > 0.75:
                # Başarılı → öğrenme hızını azalt (ince ayar)
                self._gen_lr[i] = max(0.001, self._gen_lr[i] * 0.98)
            elif avg < 0.40:
                # Başarısız → öğrenme hızını artır (daha agresif)
                self._gen_lr[i] = min(0.5, self._gen_lr[i] * 1.05)
            # Kalibrasyon önyargısını güncelle
            self._calibration_bias = (avg - 0.5) * 0.1

    def reflect(self) -> Dict:
        """
        Öz-yansıma: Motor kendi durumunu değerlendirir ve iyileştirir.
        - Düşük güçlü hücreleri temizle
        - Arketipleri yeniden damıt
        - Generator lr'larını sıfırla
        - Çalışma belleğini seç
        """
        t0 = time.perf_counter()

        # Zayıf hücreleri temizle
        cleaned = 0
        with self._lock:
            before = len(self._cells)
            self._cells = [c for c in self._cells if c.strength > 0.3]
            cleaned = before - len(self._cells)

        # Arketipleri damıt
        n_arch = self.distill_archetypes()

        # Çalışma belleğini boşalt (stale bağlam)
        self._working.clear()

        # Generator lr'larını yenile
        for i in range(len(self._gen_lr)):
            self._gen_lr[i] = self.meta_lr

        dt = (time.perf_counter() - t0) * 1000
        report = {
            "cells_cleaned":  cleaned,
            "cells_remaining": len(self._cells),
            "archetypes":     n_arch,
            "working_mem":    len(self._working),
            "causal_nodes":   len(self._causal),
            "reflect_ms":     dt,
            "meta_stats":     dict(self._meta_stats),
        }
        logger.info(
            f"BBGH AGI     : 🧠 Yansıma · temizlenen={cleaned} · "
            f"arketip={n_arch} · {dt:.1f}ms"
        )
        return report

    # ══════════════════════════════════════════════════════════════════════════
    # Güven Kalibrasyonu
    # ══════════════════════════════════════════════════════════════════════════

    def calibrated_confidence(self, query_text: str) -> float:
        """
        Bir sorgu için kalibre edilmiş güven skoru.
        Epistemic belirsizliği ölçer.
        """
        hits = self.query(query_text, top_k=5)
        if not hits:
            return 0.0

        # Varyans bazlı belirsizlik
        scores = [h["score"] for h in hits]
        mean_s = sum(scores) / len(scores)
        var_s  = sum((s - mean_s) ** 2 for s in scores) / max(len(scores), 1)

        # Yüksek varyans → düşük güven
        raw_conf = mean_s * (1.0 - min(var_s * 2, 0.8))
        return max(0.0, min(1.0, raw_conf + self._calibration_bias))

    def analyze_cognitive_gaps(self, query_text: str) -> Dict[str, Any]:
        """
        Düşük güven / boş hafıza durumunda yapısal geri bildirim (Bilişsel Sessizlik v2).
        """
        hits = self.query(query_text, top_k=5)
        conf = self.calibrated_confidence(query_text) if hits else 0.0
        gaps: List[str] = []
        if not hits:
            gaps.append("Hafızada bu sorguya yakın komşu yok (boş bölge).")
        if conf < 0.35:
            gaps.append("Güven düşük: vektör uzayında tutarlılık zayıf.")
        var_s = 0.0
        if len(hits) >= 2:
            sc = [h["score"] for h in hits]
            m = sum(sc) / len(sc)
            var_s = sum((x - m) ** 2 for x in sc) / len(sc)
            if var_s > 0.05:
                gaps.append(f"Skor yayılımı yüksek (varyans≈{var_s:.3f}) — belirsizlik.")
        return {
            "confidence": conf,
            "gaps": gaps,
            "hits": len(hits),
            "hint": "Daha fazla örnek öğrenmek veya sorguyu daraltmak genelde iyileştirir.",
        }

    def short_term_think(self, query_text: str, variants: int = 16) -> Dict[str, Any]:
        """Holografik kısa vadeli tarama: hafif pertürbasyonlarla en iyi reason çıktısı."""
        best: Optional[Dict] = None
        best_sc = -1.0
        n = max(1, min(64, int(variants)))
        for j in range(n):
            suf = (" ·" * (j % 3)).strip()
            probe = query_text if not suf else (query_text + suf)
            r = ZeroFault.run(
                self.reason, probe, min(4, 1 + j % 3),
                etype="BBGH", what="short_term_think", default=None
            )
            if r is None:
                continue
            sc = float(r.get("confidence") or 0.0)
            boost = sc * (self.bbgh_synthetic_boost / 1.4)
            if boost > best_sc:
                best_sc = boost
                best = r
        return {"best": best, "score": best_sc, "variants_tried": n}

    # ══════════════════════════════════════════════════════════════════════════
    # İstatistikler & Durum
    # ══════════════════════════════════════════════════════════════════════════

    @property
    def stats(self) -> Dict:
        with self._lock:
            n_cells = len(self._cells)
        avg_conf = (
            sum(self._confidence_history) / len(self._confidence_history)
            if self._confidence_history else 0.0
        )
        return {
            "cells":          n_cells,
            "learned":        self._learn_count,
            "queried":        self._query_count,
            "max":            self.max_cells,
            "archetypes":     len(self._archetypes),
            "causal_nodes":   len(self._causal),
            "working_mem":    len(self._working),
            "avg_confidence": avg_conf,
            "meta_lr":        self._gen_lr[0] if self._gen_lr else 0.0,
            "meta_stats":     dict(self._meta_stats),
        }


# Alias — geriye uyumluluk
BBGHAGIEngine = BBGHEngine


class QVECEncoder:
    """QVEC: veri kaynağını sabit boyutlu entropi imzasına çökertir."""

    def __init__(self, dim: int = 1024):
        self.dim = max(128, int(dim))

    def _to_lines(self, data_source: Any) -> List[str]:
        if data_source is None:
            return []
        if isinstance(data_source, str):
            return [data_source]
        if isinstance(data_source, dict):
            return [json.dumps(data_source, ensure_ascii=False)]
        lines: List[str] = []
        try:
            for x in data_source:
                lines.append(json.dumps(x, ensure_ascii=False) if isinstance(x, dict) else str(x))
                if len(lines) >= 50000:
                    break
        except Exception:
            lines.append(str(data_source))
        return lines

    def encode(self, data_source: Any) -> torch.Tensor:
        lines = self._to_lines(data_source)
        if not lines:
            return torch.zeros(self.dim, dtype=torch.float32)
        v = torch.zeros(self.dim, dtype=torch.float32)
        for line in lines:
            h = hashlib.blake2b(line.encode("utf-8", errors="ignore"), digest_size=16).digest()
            for i, b in enumerate(h):
                idx = (b + i * 131) % self.dim
                v[idx] += ((b / 255.0) - 0.5)
        v /= float(max(len(lines), 1))
        return torch.tanh(v)


class NZAPAbsorber:
    def __init__(self, resonance_threshold: float = 0.015, safe_mode: bool = True):
        self.threshold = float(resonance_threshold)
        self.safe_mode = safe_mode

    def absorb(self, model: nn.Module, entropy_vec: torch.Tensor) -> Dict[str, Any]:
        accepted = 0
        cold: List[str] = []
        score_sum = 0.0
        ev = entropy_vec.float()
        for name, p in model.named_parameters():
            if not p.requires_grad or p.numel() == 0:
                continue
            flat = p.data.flatten()
            n = min(ev.numel(), flat.numel())
            if n <= 0:
                continue
            cur = flat[:n].float()
            sig = ev[:n].to(cur.device)
            denom = float(cur.norm() * sig.norm()) + 1e-8
            score = float((cur * sig).sum()) / denom
            score_sum += max(0.0, score)
            if score >= self.threshold:
                step = sig.to(flat.device).to(flat.dtype) * 0.002
                if self.safe_mode:
                    step = torch.nan_to_num(step, nan=0.0, posinf=0.01, neginf=-0.01).clamp(-0.01, 0.01)
                with torch.no_grad():
                    flat[:n].add_(step)
                accepted += 1
            else:
                cold.append(name)
        total = max(accepted + len(cold), 1)
        return {"accepted": accepted, "cold": cold, "avg_score": score_sum / total}


class JFHMMerger:
    def __init__(self, harmonic_lr: float = 0.01, convergence_threshold: float = 0.08, safe_mode: bool = True):
        self.lr = float(harmonic_lr)
        self.convergence_threshold = float(convergence_threshold)
        self.safe_mode = safe_mode

    def merge(self, model: nn.Module, entropy_vec: torch.Tensor) -> Dict[str, Any]:
        ev = entropy_vec.float()
        dists: List[float] = []
        touched = 0
        for _, p in model.named_parameters():
            if not p.requires_grad or p.numel() == 0:
                continue
            flat = p.data.flatten()
            n = min(flat.numel(), ev.numel())
            if n <= 0:
                continue
            cur = flat[:n].float()
            target = ev[:n].to(cur.device)
            dist = float((cur - target).pow(2).mean().sqrt())
            dists.append(dist)
            if dist > self.convergence_threshold:
                step = (target - cur).to(flat.dtype) * self.lr
                if self.safe_mode:
                    step = torch.nan_to_num(step, nan=0.0, posinf=0.02, neginf=-0.02).clamp(-0.02, 0.02)
                with torch.no_grad():
                    flat[:n].add_(step.to(flat.device))
                touched += 1
        hd = sum(dists) / max(len(dists), 1)
        return {"harmonic_distance": hd, "touched": touched}


class HRSPStamper:
    def __init__(self, stamp_strength: float = 0.002, safe_mode: bool = True):
        self.strength = float(stamp_strength)
        self.safe_mode = safe_mode
        self._stamps: Dict[str, torch.Tensor] = {}

    def stamp(self, model: nn.Module, entropy_vec: torch.Tensor) -> Dict[str, Any]:
        ev = entropy_vec.float()
        nst = 0
        norm_sum = 0.0
        for name, p in model.named_parameters():
            if not p.requires_grad or p.numel() == 0:
                continue
            flat = p.data.flatten()
            n = min(flat.numel(), ev.numel())
            if n <= 0:
                continue
            vec = ev[:n].to(flat.device).to(flat.dtype) * self.strength
            if self.safe_mode:
                vec = torch.nan_to_num(vec, nan=0.0, posinf=0.01, neginf=-0.01).clamp(-0.01, 0.01)
            prev = self._stamps.get(name)
            if prev is None or prev.numel() != n:
                self._stamps[name] = vec.detach().float().cpu()
            else:
                self._stamps[name] = (prev * 0.98 + vec.detach().float().cpu() * 0.02)
            with torch.no_grad():
                flat[:n].add_(vec)
            nst += 1
            norm_sum += float(self._stamps[name].norm())
        return {"stamped": nst, "stamp_norm": norm_sum / max(nst, 1)}


class MSIGSynthesizer:
    def __init__(self, strength: float = 0.004, safe_mode: bool = True):
        self.strength = float(strength)
        self.safe_mode = safe_mode

    def apply(self, model: nn.Module, entropy_vec: torch.Tensor, cold_names: List[str]) -> Dict[str, Any]:
        if not cold_names:
            return {"applied": 0}
        cold = set(cold_names)
        ev = entropy_vec.float()
        ap = 0
        for name, p in model.named_parameters():
            if name not in cold or (not p.requires_grad) or p.numel() == 0:
                continue
            flat = p.data.flatten()
            n = min(flat.numel(), ev.numel())
            if n <= 0:
                continue
            cur = flat[:n].float()
            target = ev[:n].to(cur.device)
            grad_hat = (target - cur)
            step = grad_hat.to(flat.dtype) * self.strength
            if self.safe_mode:
                step = torch.nan_to_num(step, nan=0.0, posinf=0.02, neginf=-0.02).clamp(-0.02, 0.02)
            with torch.no_grad():
                flat[:n].add_(step.to(flat.device))
            ap += 1
        return {"applied": ap}


class MNJHEngine:
    """MNJH Harmonic Loop: QVEC -> NZAP -> JFHM -> (HRSP|MSIG)."""

    def __init__(self, model: nn.Module, cfg: "TOREloRAConfig"):
        self.model = model
        self.cfg = cfg
        self.qvec = QVECEncoder(cfg.mnjh_entropy_dim)
        self.nzap = NZAPAbsorber(cfg.mnjh_resonance_threshold, cfg.mnjh_safe_mode)
        self.jfhm = JFHMMerger(cfg.mnjh_harmonic_lr, cfg.mnjh_convergence_threshold, cfg.mnjh_safe_mode)
        self.hrsp = HRSPStamper(cfg.mnjh_stamp_strength, cfg.mnjh_safe_mode)
        self.msig = MSIGSynthesizer(cfg.mnjh_msig_strength, cfg.mnjh_safe_mode)
        self._last: Dict[str, Any] = {"enabled": True, "loops": 0}

    def run(self, data_source: Any) -> Dict[str, Any]:
        entropy = ZeroFault.run(self.qvec.encode, data_source, etype="MNJH", what="qvec", default=None)
        if entropy is None:
            return {"enabled": True, "ok": False, "reason": "qvec_failed"}
        report: Dict[str, Any] = {"enabled": True, "ok": True, "loops": 0, "history": []}
        for i in range(self.cfg.mnjh_max_loops):
            nz = ZeroFault.run(
                self.nzap.absorb, self.model, entropy, etype="MNJH", what="nzap",
                default={"accepted": 0, "cold": []}
            )
            jf = ZeroFault.run(
                self.jfhm.merge, self.model, entropy, etype="MNJH", what="jfhm",
                default={"harmonic_distance": 1e9, "touched": 0}
            )
            hd = float(jf.get("harmonic_distance", 1e9))
            cold = list(nz.get("cold", []))
            report["history"].append(
                {"loop": i + 1, "distance": hd, "accepted": int(nz.get("accepted", 0)), "cold": len(cold)}
            )
            report["loops"] = i + 1
            if hd <= self.cfg.mnjh_convergence_threshold or not cold:
                hr = ZeroFault.run(self.hrsp.stamp, self.model, entropy, etype="MNJH", what="hrsp", default={"stamped": 0})
                report["stamped"] = int(hr.get("stamped", 0))
                self._last = report
                return report
            ZeroFault.run(self.msig.apply, self.model, entropy, cold, etype="MNJH", what="msig", default=None)
        if self.cfg.mnjh_fallback_to_trainer:
            report["fallback"] = "trainer"
        self._last = report
        return report

    def status(self) -> Dict[str, Any]:
        return dict(self._last)


class SymbolicWorldModel:
    """LLM'siz sembolik durum deposu."""

    def __init__(self):
        self.state: Dict[str, Any] = {}
        self._lock = threading.Lock()

    def update(self, obs: Dict[str, Any]):
        with self._lock:
            self.state.update(obs or {})

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self.state)


class SimulatedEmbodiedWorld:
    """Basit fiziksel/bedensel dünya simülasyonu (yerçekimi + zaman adımı)."""

    def __init__(self):
        self.t = 0
        self.gravity = 9.81
        self.body = {"x": 0.0, "y": 0.0, "vx": 0.0, "vy": 0.0}

    def step(self, action: Optional[str] = None) -> Dict[str, Any]:
        dt = 0.1
        if action == "jump" and self.body["y"] <= 0.0:
            self.body["vy"] = 3.5
        if action == "left":
            self.body["vx"] = max(-1.5, self.body["vx"] - 0.2)
        elif action == "right":
            self.body["vx"] = min(1.5, self.body["vx"] + 0.2)
        else:
            self.body["vx"] *= 0.95

        self.body["vy"] -= self.gravity * dt
        self.body["x"] += self.body["vx"] * dt
        self.body["y"] += self.body["vy"] * dt
        if self.body["y"] < 0.0:
            self.body["y"] = 0.0
            self.body["vy"] = 0.0
        self.t += 1
        return {"world_t": self.t, **self.body}


class ResourceEnvelope:
    """Donanım/enerji benzeri çalışma bütçesi (simülasyon)."""

    def __init__(self, max_ops_per_cycle: int = 128, max_ms_per_cycle: float = 25.0):
        self.max_ops = max(8, int(max_ops_per_cycle))
        self.max_ms = max(1.0, float(max_ms_per_cycle))
        self.last_ops = 0
        self.last_ms = 0.0

    def check(self, ops: int, elapsed_ms: float) -> bool:
        self.last_ops = int(ops)
        self.last_ms = float(elapsed_ms)
        return ops <= self.max_ops and elapsed_ms <= self.max_ms


class GlobalWorkspaceBus:
    """Global Workspace benzeri kısa süreli yayın alanı."""

    def __init__(self, capacity: int = 64):
        self._events: deque = deque(maxlen=max(4, capacity))
        self._lock = threading.Lock()

    def broadcast(self, event: Dict[str, Any]):
        with self._lock:
            self._events.append({"t": time.time(), **(event or {})})

    def recent(self, n: int = 8) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._events)[-max(1, n):]


class ActiveInferenceController:
    """
    Basit aktif çıkarım yaklaşımı:
    - beklenen hedefe uzaklığı düşüren aksiyonları tercih eder.
    """

    def evaluate(self, state: Dict[str, Any], goal: Dict[str, Any], action_effect: Dict[str, Any]) -> float:
        # Düşük skor daha iyi (serbest enerji benzeri)
        s = dict(state)
        s.update(action_effect or {})
        score = 0.0
        for k, v in (goal or {}).items():
            if k not in s:
                score += 1.0
                continue
            sv = s[k]
            if isinstance(v, (int, float)) and isinstance(sv, (int, float)):
                score += abs(float(v) - float(sv))
            else:
                score += 0.0 if sv == v else 1.0
        return score


class AGCoreEngine:
    """
    LLM'siz AG çekirdeği:
    - Symbolic World Model
    - Global Workspace
    - Active Inference tabanlı eylem seçimi
    - Basit operatör-planlayıcı
    """

    def __init__(self):
        self.world = SymbolicWorldModel()
        self.embodied = SimulatedEmbodiedWorld()
        self.gw = GlobalWorkspaceBus()
        self.controller = ActiveInferenceController()
        self.goal: Dict[str, Any] = {}
        self.intrinsic_goal: Dict[str, Any] = {}
        self.operators: Dict[str, Dict[str, Dict[str, Any]]] = {}
        self.skills: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {}
        self.resources = ResourceEnvelope()
        self._last: Dict[str, Any] = {"enabled": True, "cycles": 0}
        self._cycles = 0
        self._register_default_embodied_ops()

    def _register_default_embodied_ops(self):
        # Embodied dünya için varsayılan eylem seti
        self.register_operator("noop", pre={}, eff={})
        self.register_operator("left", pre={}, eff={})
        self.register_operator("right", pre={}, eff={})
        self.register_operator("jump", pre={}, eff={})

    def register_operator(self, name: str, pre: Dict[str, Any], eff: Dict[str, Any]):
        self.operators[name] = {"pre": dict(pre or {}), "eff": dict(eff or {})}

    def register_skill(self, name: str, fn: Callable[[Dict[str, Any]], Dict[str, Any]]):
        self.skills[name] = fn

    def perceive(self, obs: Dict[str, Any]):
        self.world.update(obs)
        self.gw.broadcast({"type": "perception", "obs": dict(obs or {})})

    def set_goal(self, goal: Dict[str, Any]):
        self.goal = dict(goal or {})
        self.gw.broadcast({"type": "goal", "goal": self.goal})

    def set_intrinsic_goal(self):
        """Dış sorgu olmadan içsel hedef üretimi (agency-lite)."""
        st = self.world.snapshot()
        # Basit merak dürtüsü: daha önce görülmeyen durumları keşfet
        target_x = float(st.get("x", 0.0)) + (1.0 if int(st.get("world_t", 0)) % 2 == 0 else -1.0)
        self.intrinsic_goal = {"x": target_x}
        self.gw.broadcast({"type": "intrinsic_goal", "goal": dict(self.intrinsic_goal)})

    def _pre_ok(self, st: Dict[str, Any], pre: Dict[str, Any]) -> bool:
        for k, v in (pre or {}).items():
            if st.get(k) != v:
                return False
        return True

    def plan(self, max_depth: int = 4) -> List[str]:
        start = self.world.snapshot()
        if not self.goal:
            return []
        # Greedy+BFS hibrit planlama
        queue_nodes: List[Tuple[Dict[str, Any], List[str]]] = [(start, [])]
        best_plan: List[str] = []
        best_score = float("inf")
        for _ in range(max(1, max_depth) * max(1, len(self.operators) + 1)):
            if not queue_nodes:
                break
            st, path = queue_nodes.pop(0)
            for name, op in self.operators.items():
                if not self._pre_ok(st, op["pre"]):
                    continue
                nxt = dict(st)
                nxt.update(op["eff"])
                new_path = path + [name]
                sc = self.controller.evaluate(nxt, self.goal, {})
                if sc < best_score:
                    best_score = sc
                    best_plan = new_path
                if sc <= 1e-6:
                    return new_path
                if len(new_path) < max_depth:
                    queue_nodes.append((nxt, new_path))
        return best_plan

    def step(self) -> Dict[str, Any]:
        t0 = time.perf_counter()
        self._cycles += 1
        if not self.goal:
            self.set_intrinsic_goal()
            self.goal = dict(self.intrinsic_goal)
        plan = self.plan(max_depth=4)
        if not plan:
            self.world.update(self.embodied.step(None))
            out = {"cycle": self._cycles, "action": None, "status": "no_plan"}
            self._last = out
            return out
        action = plan[0]
        op = self.operators.get(action, {"eff": {}})
        # Skill varsa onu çalıştır, yoksa operator effect uygula
        if action in self.skills:
            try:
                res = self.skills[action](self.world.snapshot()) or {}
            except Exception as e:
                ZeroFault.report("AG_CORE", f"skill failed: {action}", str(e)[:120], exc=e)
                res = {}
            self.world.update(res)
        else:
            self.world.update(op.get("eff", {}))
        # Embodied world step
        self.world.update(self.embodied.step(action))
        score = self.controller.evaluate(self.world.snapshot(), self.goal, {})
        elapsed_ms = (time.perf_counter() - t0) * 1000
        ok_budget = self.resources.check(ops=len(self.operators) + len(self.skills), elapsed_ms=elapsed_ms)
        out = {
            "cycle": self._cycles, "action": action, "free_energy": score, "plan_len": len(plan),
            "budget_ok": ok_budget, "cycle_ms": elapsed_ms,
        }
        self.gw.broadcast({"type": "action", **out})
        self._last = out
        return out

    def run(self, cycles: int = 5) -> Dict[str, Any]:
        trace = []
        for _ in range(max(1, cycles)):
            trace.append(self.step())
            if trace[-1].get("free_energy", 1.0) <= 1e-6:
                break
        return {"enabled": True, "cycles": len(trace), "trace": trace, "state": self.world.snapshot()}

    def readiness_report(self) -> Dict[str, Any]:
        """AGI-benzeri hazırlık görünümü (dürüst: gerçek AGI değildir)."""
        st = self.world.snapshot()
        return {
            "label": "AG Foundation Ready",
            "is_true_agi": False,
            "components": {
                "symbolic_world_model": True,
                "global_workspace": True,
                "active_inference": True,
                "intrinsic_goal_loop": True,
                "embodied_sim_world": True,
                "resource_budgeting": True,
            },
            "state_keys": sorted(list(st.keys()))[:24],
            "note": "Experimental AG framework; not true AGI.",
        }

    def status(self) -> Dict[str, Any]:
        return {
            "enabled": True,
            "note": "Experimental AG framework; not true AGI.",
            "last": dict(self._last),
            "goal": dict(self.goal),
            "intrinsic_goal": dict(self.intrinsic_goal),
            "resource_budget": {"max_ops": self.resources.max_ops, "max_ms": self.resources.max_ms,
                                "last_ops": self.resources.last_ops, "last_ms": self.resources.last_ms},
            "state": self.world.snapshot(),
        }


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 6.7 — SIMPLE CONFIG PARSER  (c/true · c/false sistemi)
# ══════════════════════════════════════════════════════════════════════════════

class SimpleConfig:
    """
    SimpleConfig — Kullanıcı dostu yapılandırma sistemi (c/true · c/false)

    Kullanım::

        cfg = SimpleConfig.parse(
            "model_name     mistralai/Mistral-7B-v0.1\\n"
            "ssyp           c/true\\n"
            "omnisync       c/true\\n"
            "bbgh           c/false\\n"
            "lora_r         32\\n"
        )
        tore = TOREloRA(cfg)

    Kurallar:
    - Her satir: <ayar_adi> <deger>
    - Boolean: c/true  veya  c/false
    - Kodda gecmeyen ayarlar otomatik kapalidir (False/None)
    - Satir basi # ile baslarsa yorum satiridir
    - Buyuk/kucuk harf farki yoktur
    """

    _BOOL_TRUE  = {"c/true",  "true",  "1", "yes", "on",  "evet", "açık"}
    _BOOL_FALSE = {"c/false", "false", "0", "no",  "off", "hayır", "kapalı"}

    @classmethod
    def parse(cls, config_text: str, base: Optional["TOREloRAConfig"] = None) -> "TOREloRAConfig":
        """
        Metin tabanlı config'i TOREloRAConfig'e çevir.
        base verilirse üzerine yazar; verilmezse varsayılan config kullanılır.
        """
        from copy import copy as _copy
        cfg = _copy(base) if base else TOREloRAConfig()
        kw: Dict[str, Any] = {}

        for raw_line in config_text.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(None, 1)
            if len(parts) < 2:
                continue
            key, val_str = parts[0].lower(), parts[1].strip()
            # Boolean
            if val_str.lower() in cls._BOOL_TRUE:
                kw[key] = True
            elif val_str.lower() in cls._BOOL_FALSE:
                kw[key] = False
            else:
                # int / float / string otomatik dönüşüm
                try:
                    kw[key] = int(val_str)
                except ValueError:
                    try:
                        kw[key] = float(val_str)
                    except ValueError:
                        kw[key] = val_str  # String olarak bırak

        # Alias çözümle ve config'e yaz
        resolved = _resolve(kw)
        for k, v in resolved.items():
            if hasattr(cfg, k):
                try:
                    setattr(cfg, k, v)
                except Exception:
                    pass
            else:
                logger.warning(f"SimpleConfig : Bilinmeyen ayar → '{k}' (görmezden gelindi)")

        # __post_init__ yeniden çalıştır
        try:
            cfg.__post_init__()
        except Exception:
            pass

        logger.info(f"SimpleConfig : ✓  {len(resolved)} ayar yüklendi")
        return cfg

    @classmethod
    def from_file(cls, path: str, base: Optional["TOREloRAConfig"] = None) -> "TOREloRAConfig":
        """Dosyadan yükle."""
        text = Path(path).read_text(encoding="utf-8")
        return cls.parse(text, base=base)

    @classmethod
    def to_text(cls, cfg: "TOREloRAConfig") -> str:
        """TOREloRAConfig'i metin formatına çevir."""
        lines = [f"# TOREloRA v{__version__} Config", ""]
        from dataclasses import fields as dc_fields
        for f in dc_fields(cfg):
            if f.name.startswith("_"): continue
            val = getattr(cfg, f.name)
            if isinstance(val, bool):
                lines.append(f"{f.name:<35} {'c/true' if val else 'c/false'}")
            elif val is None:
                pass  # None ayarları atla
            elif isinstance(val, (list, dict)):
                pass  # Kompleks tipler atla
            else:
                lines.append(f"{f.name:<35} {val}")
        return "\n".join(lines)

    @classmethod
    def save(cls, cfg: "TOREloRAConfig", path: str):
        """Config'i dosyaya kaydet."""
        Path(path).write_text(cls.to_text(cfg), encoding="utf-8")
        logger.info(f"SimpleConfig : ✓  Kaydedildi → {path}")

    @classmethod
    def show(cls, cfg: "TOREloRAConfig"):
        """Config'i terminale yazdır."""
        print("\n" + "─"*60)
        print(f"  TOREloRA v{__version__} Aktif Yapılandırma")
        print("─"*60)
        from dataclasses import fields as dc_fields
        for f in dc_fields(cfg):
            if f.name.startswith("_"): continue
            val = getattr(cfg, f.name)
            if isinstance(val, bool):
                marker = "  ✓" if val else "  ✗"
                print(f"{marker} {f.name:<33} {val}")
            elif val is not None and not isinstance(val, (list, dict)):
                print(f"     {f.name:<33} {val}")
        print("─"*60 + "\n")



# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 7 — TAKMAİSİM SİSTEMİ (20+ alias / parametre)
# ══════════════════════════════════════════════════════════════════════════════

def _make_aliases() -> Dict[str, str]:
    raw = {
        "model_name": [
            "model","model_id","checkpoint","hf_model","model_path","pretrained",
            "base_model","foundation_model","llm","model_checkpoint","hf_checkpoint",
            "repo_id","model_repo","source_model","pretrained_model","backbone",
            "model_name_or_path","hf_model_id","weights","from_pretrained","base",
            "model_key","llm_id","huggingface_model","hf_id","model_card",
        ],
        "max_seq_length": [
            "seq_len","max_length","context_length","context_size","sequence_length",
            "max_context","ctx_len","ctx_size","max_tokens","token_limit","window_size",
            "max_seq_len","seq_length","max_pos","input_length","max_input_len",
            "context_window","seqlen","ctx","nctx","block_size_seq","position_limit",
            "n_positions","max_position_embeddings",
        ],
        "lora_r": [
            "rank","r","lora_rank","adapter_rank","adapter_r","peft_rank","low_rank",
            "lora_dim","adapter_dim","bottleneck","lora_size","compression_rank",
            "attention_rank","projection_rank","reduce_dim","intrinsic_dim","lora_n",
            "peft_r","lora_width","svd_rank","ra","n_rank","matrix_rank",
        ],
        "lora_alpha": [
            "alpha","lora_scale","adapter_alpha","scaling_factor","lora_scaling",
            "peft_alpha","adapter_scale","lora_multiplier","rank_scale","alpha_scale",
            "lora_alpha_value","adapter_multiplier","update_scale","delta_scale",
            "weight_scale","merge_scale","lora_weight","alpha_value","scale","a",
        ],
        "lora_dropout": [
            "dropout","lora_drop","adapter_dropout","peft_dropout","lora_regularization",
            "drop_rate","drop_prob","lora_p","dropout_rate","regularization",
            "lora_dropout_p","adapter_drop","weight_dropout","drop","p_dropout",
            "lora_reg","dr","lora_dr","adapter_dr","p",
        ],
        "lora_target_modules": [
            "target_modules","lora_targets","adapter_targets","peft_modules",
            "modules_to_adapt","lora_layers","adapter_modules","trainable_modules",
            "finetune_modules","lora_names","module_names","weight_names",
            "projection_modules","attention_modules","target_layers","modules",
            "layers_to_train","selected_modules","lora_module_names","targets",
        ],
        "quantization": [
            "quant","precision_mode","weight_precision","compress","quantize","qtype",
            "weight_type","quant_type","int_precision","quant_mode","weight_format",
            "compress_weights","quant_scheme","weight_quant","bits","quantization_mode",
            "q","wq","wbits","nbits","num_bits","bit_width",
        ],
        "learning_rate": [
            "lr","step_size","alpha_lr","training_lr","optimizer_lr","update_rate",
            "gradient_step","lr_value","train_lr","sgd_lr","adam_lr","initial_lr",
            "base_lr","start_lr","peak_lr","max_lr","learning_speed","update_size",
            "lr_rate","eta","learning_eta","step_lr",
        ],
        "per_device_train_batch_size": [
            "batch_size","batch","bs","train_batch","micro_batch","device_batch",
            "local_batch","train_bs","per_gpu_batch","per_device_batch",
            "batch_per_device","mini_batch","sample_per_step","training_batch_size",
            "batch_sz","b_size","num_samples","training_bs","local_batch_size",
            "train_batch_size","bsz","mbs","micro_bsz",
        ],
        "gradient_accumulation_steps": [
            "grad_accum","accum_steps","accumulation","grad_steps","gradient_steps",
            "accumulation_steps","acc_steps","effective_batch_mult","grad_accumulation",
            "accum","accumulate","update_freq","gradient_accumulation","micro_steps",
            "accum_grad","batch_multiplier","grad_acc","ga_steps","gas","ga",
        ],
        "num_train_epochs": [
            "epochs","num_epochs","train_epochs","n_epochs","training_epochs",
            "epoch_count","passes","full_passes","dataset_passes","complete_passes",
            "num_passes","training_passes","train_pass","ep","num_ep","epoch_num",
            "total_epochs","training_rounds","rounds","ne",
        ],
        "output_dir": [
            "save_dir","output_path","checkpoint_dir","save_path","model_dir",
            "results_dir","save_folder","output_folder","train_output","training_output",
            "saved_model_path","weights_dir","checkpoints_dir","exp_dir",
            "experiment_dir","run_dir","artifacts_dir","output","save_to",
            "destination","outdir","out_dir",
        ],
        "torch_compile": [
            "compile","use_compile","enable_compile","jit_compile","torch_jit",
            "graph_compile","dynamo","use_dynamo","torch_dynamo","enable_torch_compile",
            "compiled_model","compile_model","do_compile","torchdynamo","graph_mode",
            "torch_opt","fast_compile","use_inductor","inductor","torch_compile_mode",
        ],
        "flash_attention": [
            "flash_attn","fast_attention","use_flash","flash_attention_2","fa2",
            "efficient_attention","memory_efficient_attention","use_flash_attention",
            "enable_flash","fused_attention","sdpa","use_sdpa","scaled_dot_product",
            "optimized_attention","attn_opt","flash_att","fast_attn","fa",
        ],
        "gradient_checkpointing": [
            "grad_ckpt","checkpointing","activation_checkpointing","memory_efficient",
            "grad_checkpoint","recompute_activations","memory_saving",
            "checkpoint_activations","use_checkpointing","gradient_checkpoint",
            "ckpt_activations","enable_checkpointing","rematerialization","remat",
            "use_remat","mem_efficient","save_memory","low_memory","gc","act_ckpt",
        ],
        "vram_guard": [
            "memory_guard","oom_protection","auto_oom","vram_protection",
            "gpu_memory_guard","oom_guard","memory_protection","safe_memory",
            "auto_batch_reduce","oom_safe","memory_safe","vram_safe","gpu_guard",
            "memory_manager","oom_handler","auto_memory","smart_memory",
            "dynamic_memory","adaptive_memory","mem_guard",
        ],
        "stream_grad_pipe": [
            "sgp","pipe","grad_pipe","stream_pipe","gradient_pipe","noise_pipe",
            "async_pipe","use_pipe","enable_pipe","use_sgp","enable_sgp","stream_grad",
            "async_grad_pipe","use_stream_pipe","streaming_grad","pipe_enabled",
            "sgp_enabled","gradient_streaming","noise_injection","stream_noise","asgp",
        ],
        "pipe_size_mb": [
            "pipe_size","buffer_size","pipe_buffer","sgp_size","pipe_mb","buffer_mb",
            "pipe_memory","sgp_buffer","pipe_capacity","grad_pipe_size","stream_buffer",
            "pipe_ram","sgp_ram","noise_buffer_size","buffer_capacity","pipe_sz",
        ],
        "corap20": [
            "smart_quant","use_corap20","enable_corap20","corap20_enabled","c20",
            "dynamic_quant","ecosystem_quant","holographic_quant","gkp_quant",
            "hybrid_quant","two_bit_dynamic","adaptive_2bit","corap20_mode",
        ],
        "ssyp": [
            "simultaneous_pipeline","sync_yield","use_ssyp","enable_ssyp",
            "fast_pipeline","token_pipeline","yield_pipe","ssyp_enabled",
            "all_at_once","bulk_tokenize","zero_overhead_pipe","instant_pipe",
        ],
        "omnisync": [
            "use_omnisync","enable_omnisync","omni","omnisync_enabled",
            "geometric_resonance","holographic_fold","async_singularity",
            "qgc","quantum_grad","zero_backprop","light_speed_train",
        ],
        "bbgh": [
            "use_bbgh","enable_bbgh","bbgh_enabled","no_param_llm",
            "geometric_memory","bilinc_hafiza","param_free","token_free",
            "true_understanding","anlayan_model","agi_lite",
        ],
        "lora": [
            "use_lora","enable_lora","adapter","use_adapter","peft","use_peft",
            "low_rank_adaptation","lora_enabled","apply_lora","with_lora",
            "lora_finetune","adapter_finetune","lora_training","efficient_finetune",
            "parameter_efficient","peft_lora","lora_mode","lo",
        ],
        "precision": [
            "dtype","compute_dtype","model_dtype","weight_dtype","numerical_precision",
            "float_precision","fp","fp_mode","half_precision","full_precision",
            "mixed_precision","num_precision","train_dtype","param_dtype",
        ],
        "seed": [
            "random_seed","rng_seed","global_seed","train_seed","reproducible",
            "random_state","np_seed","torch_seed","deterministic_seed","fix_seed",
            "seed_value","rng","rs","set_seed",
        ],
        "max_steps": [
            "total_steps","train_steps","n_steps","num_steps","training_steps",
            "step_limit","max_train_steps","step_count","update_steps","iterations",
            "num_iterations","nsteps","iter_limit",
        ],
        "logging_steps": [
            "log_every","log_steps","log_interval","print_every","logging_interval",
            "report_steps","stats_every","monitor_steps","progress_steps","log_freq",
            "report_freq","log_n","verbose_steps",
        ],
        "save_steps": [
            "checkpoint_steps","save_every","save_interval","ckpt_steps","save_freq",
            "checkpoint_every","save_n_steps","checkpoint_interval","snapshot_steps",
            "backup_steps","persist_steps","checkpoint_freq",
        ],
        "agi_core": [
            "agi","the_singularity","genesis_core","manifesto_core","singularity_mode",
        ],
        "resonance_level": [
            "resonance","rezonans","omni_level","sync_level","creative_fidelity",
        ],
        "asgp_v3": [
            "asgp3","stream_grad_v3","sgp_v3","fast_asgp",
        ],
        "bbgh_synthetic_boost": [
            "synthetic_boost","bbgh_boost","reasoning_boost",
        ],
        "mnjh": [
            "mnjh_core","junction_harmonics","harmonic_loop","stepless_train",
        ],
        "backprop_turbo": [
            "turbo","turbo_backprop","fast_backprop","ms_mode","speed_mode",
        ],
        "backprop_engine": [
            "bp_engine","gradient_engine","custom_backprop","bp_mode",
        ],
        "backprop_enabled": [
            "bp_on","enable_backprop","backprop_on",
        ],
        "bbgh_agi_mode": [
            "agi_mode","bbgh_mode","cognitive_mode",
        ],
        "bbgh_best_mode": [
            "bbgh_max_mode","agi_best_mode","bbgh_ultra_mode",
        ],
        "bbgh_research_agi": [
            "agi_research","bbvg_mode","bbgh_research_mode",
        ],
        "ag_core_non_llm": [
            "ag_core","non_llm_ag","symbolic_ag_core","agi_foundation_non_llm",
        ],
    }
    m: Dict[str,str] = {}
    for canonical, aliases in raw.items():
        m[canonical] = canonical
        for a in aliases:
            if a not in m: m[a] = canonical
    return m

_ALIAS = _make_aliases()

def _resolve(kw: Dict) -> Dict:
    out: Dict = {}
    for k, v in kw.items():
        c = _ALIAS.get(k, k)
        if c not in out: out[c] = v
    return out


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 8 — KONFİGÜRASYON
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TOREloRAConfig:
    """
    TOREloRA v1.0.5 Yapılandırması
    Her parametrenin 20+ takma adı vardır.
    Hiçbir kombinasyon çökmez (ZeroFault v2 sınırları ile).
    """
    # ── Model ────────────────────────────────────────────────
    model_name:        str  = "meta-llama/Llama-3.2-3B"
    max_seq_length:    int  = 2048
    allow_remote_code: bool = False
    strict_mode:       bool = False
    auto_install:      bool = True

    # ── LoRA ─────────────────────────────────────────────────
    lora:                bool  = True
    lora_r:              int   = 16
    lora_alpha:          int   = 32
    lora_dropout:        float = 0.05
    lora_target_modules: Optional[List[str]] = None
    lora_bias:           str   = "none"
    use_rslora:          bool  = False
    lora_power:          float = 1.0

    # ── Quantization ─────────────────────────────────────────
    quantization:              Optional[str] = "4bit"
    bnb_4bit_compute_dtype:    str  = "bf16"
    bnb_4bit_quant_type:       str  = "nf4"
    bnb_4bit_use_double_quant: bool = True
    quantization_power:        float = 1.0
    corap20:                   bool  = False      # CORAP20 ekosistemi
    corap20_block_size:        int   = 64
    corap20_gkp_mb:            float = 64.0       # GKP boyutu (MB)
    corap20_holographic:       bool  = True
    two_bit_quant:             bool  = False

    # ── Attention ────────────────────────────────────────────
    flash_attention:     bool  = True
    sliding_window:      bool  = False
    sliding_window_size: int   = 4096
    attention_power:     float = 1.0

    # ── Grad ckpt ────────────────────────────────────────────
    gradient_checkpointing:        bool = True
    gradient_checkpointing_kwargs: Dict = field(
        default_factory=lambda: {"use_reentrant": False})

    # ── Precision ────────────────────────────────────────────
    precision: str = "auto"

    # ── Hız ──────────────────────────────────────────────────
    torch_compile:           bool  = True
    torch_compile_mode:      str   = "reduce-overhead"
    torch_compile_fullgraph: bool  = False
    compile_cache:           bool  = True
    compile_cache_dir:       str   = ".torelora_cache"
    compile_power:           float = 0.8
    fused_ops:               bool  = True
    cuda_optimizations:      bool  = True
    batch_packing:           bool  = True
    packing_power:           float = 1.0
    pin_memory:              bool  = True
    auto_batch_size:         bool  = True

    # ── VRAM ─────────────────────────────────────────────────
    vram_guard:           bool  = True
    vram_guard_power:     float = 0.85
    vram_min_batch:       int   = 1
    oom_retry:            bool  = True
    vram_guard_threshold: float = field(init=False)

    # ── Offloading ───────────────────────────────────────────
    cpu_offload:        bool = False
    layer_offload:      bool = False
    layer_offload_keep: int  = 4

    # ── Bellek ───────────────────────────────────────────────
    kv_cache_optimize:        bool  = True
    gradient_optimize:        bool  = True
    mem_defrag:               bool  = True
    mem_defrag_interval:      int   = 50
    dataloader_optimize:      bool  = True
    mixed_precision_optimize: bool  = True

    # ── TPU/XLA ──────────────────────────────────────────────
    xla_compile:  bool = False
    tpu_mesh:     bool = False
    tpu_profiler: bool = False

    # ── ASGP v2 ──────────────────────────────────────────────
    stream_grad_pipe:    bool  = False
    pipe_size_mb:        float = 512.0
    pipe_noise_scale:    float = 0.005
    pipe_refresh_every:  int   = 2
    pipe_priority:       bool  = True
    pipe_distribution:   str   = "normal"
    pipe_adaptive:       bool  = True
    pipe_async:          bool  = True
    pipe_n_ring:         int   = 4
    pipe_int8:           bool  = True
    pipe_nonblocking:    bool  = True
    pipe_min_noise:      float = 0.00005
    pipe_max_noise:      float = 0.05
    pipe_seed:           Optional[int] = None
    pipe_unique:         bool  = True       # v2: parametre başına farklı veri
    asgp_v3:             bool  = False      # True → ASGPv3 motoru
    pipe_bg_idle_sleep:  float = 0.001      # ASGP v3 arka plan uyku (saniye)

    # ── SSYP ─────────────────────────────────────────────────
    ssyp:                bool  = False
    ssyp_residue:        bool  = True
    ssyp_residue_alpha:  float = 0.05
    ssyp_async:          bool  = True
    ssyp_prefetch:       int   = 8
    ssyp_mmap:           Optional[str] = None
    ssyp_text_field:     str   = "text"

    # ── ParamMesh ────────────────────────────────────────────
    param_mesh:          bool  = False
    mesh_strength:       float = 0.002
    mesh_update_every:   int   = 10

    # ── v1.0.5 Manifesto / güvenlik ─────────────────────────────
    agi_core:                  bool  = False  # True → bbgh + omnisync açılır (XLA hariç)
    resonance_level:           float = 1.0    # 0..2 OMNISYNC+ rezonans şiddeti
    zerofault_autorepair_grad: bool  = True
    zerofault_max_hist:        int   = 4096
    zerofault_grad_spike_factor: float = 12.0

    # ── OMNISYNC [DENEYSEL v1.0.3] ───────────────────────────────
    omnisync:                bool  = False  # Ana anahtar
    omnisync_resonance:      bool  = True   # Geometrik Rezonans
    omnisync_holographic:    bool  = True   # Holografik Veri Katlama
    omnisync_async:          bool  = True   # Asenkron Singularity
    omnisync_qgc:            bool  = True   # Kuantum Gradyan Çöküşü
    omnisync_fft_size:       int   = 4096
    omnisync_resonance_lr:   float = 0.01
    omnisync_fold_dim:       int   = 2048
    omnisync_fold_strength:  float = 0.005
    omnisync_collapse_alpha: float = 0.01
    omnisync_manifold_dim:   int   = 512
    omnisync_energy_lr:      float = 0.001

    # ── BBGH [DENEYSEL v1.0.3] ───────────────────────────────────
    bbgh:                    bool  = False  # Ana anahtar
    bbgh_embed_dim:          int   = 512
    bbgh_max_cells:          int   = 100_000
    bbgh_similarity_thresh:  float = 0.72
    bbgh_temperature:        float = 1.0
    bbgh_gen_depth:          int   = 3
    bbgh_synthetic_boost:    float = 1.4    # v1.0.5 sentetik muhakeme çarpanı (deneysel)
    bbgh_agi_mode:           bool  = False
    bbgh_best_mode:          bool  = False
    bbgh_research_agi:       bool  = False
    bbgh_self_consistency:   int   = 3
    bbgh_plan_depth:         int   = 3
    ag_core_non_llm:         bool  = False
    ag_core_cycles:          int   = 5
    ag_core_max_ops_per_cycle: int = 128
    ag_core_max_ms_per_cycle: float = 25.0

    # ── MNJH [DENEYSEL v1.0.6] ─────────────────────────────────
    mnjh:                      bool  = False
    mnjh_entropy_dim:          int   = 1024
    mnjh_max_loops:            int   = 5
    mnjh_convergence_threshold:float = 0.08
    mnjh_resonance_threshold:  float = 0.015
    mnjh_harmonic_lr:          float = 0.01
    mnjh_stamp_strength:       float = 0.002
    mnjh_msig_strength:        float = 0.004
    mnjh_safe_mode:            bool  = True
    mnjh_fallback_to_trainer:  bool  = True

    # ── Backprop Turbo [v1.0.6] ───────────────────────────────
    backprop_turbo:            bool  = False
    turbo_channels_last:       bool  = True
    turbo_disable_checkpointing: bool = True
    turbo_log_step_ms:         bool  = True

    # ── Backprop Engine [v1.0.7] ─────────────────────────────
    backprop_enabled:          bool  = True
    backprop_engine:           str   = "auto"   # auto|native|hybrid|fast_approx
    backprop_validate_every:   int   = 20
    backprop_clip_norm:        float = 1.0
    backprop_fallback_native:  bool  = True

    # ── Genel sistemler ───────────────────────────────────────
    auto_hardware_scan:    bool  = True
    unlimited_params:      bool  = True
    loss_spike_detection:  bool  = False
    loss_spike_threshold:  float = 3.0
    loss_spike_action:     str   = "skip"
    smart_checkpoint:      bool  = False
    smart_ckpt_delta:      float = 0.005
    smart_ckpt_keep:       int   = 3
    unstoppable:           bool  = True
    auto_formatting:       bool  = True

    # ── MoE ──────────────────────────────────────────────────
    moe_enabled:     bool  = False
    moe_num_experts: int   = 8
    moe_top_k:       int   = 2
    moe_threshold:   float = 0.2
    moe_max_layers:  int   = 4

    # ── Optimizer ────────────────────────────────────────────
    paged_optimizer: bool  = True
    learning_rate:   float = 2e-4
    weight_decay:    float = 0.01
    warmup_ratio:    float = 0.03
    lr_scheduler:    str   = "cosine"
    max_grad_norm:   float = 1.0

    # ── Distributed ──────────────────────────────────────────
    multi_gpu:              bool = False
    distributed_backend:    str  = "ddp"
    deepspeed_stage:        int  = 2
    fsdp_sharding_strategy: str  = "FULL_SHARD"

    # ── Training ─────────────────────────────────────────────
    per_device_train_batch_size: int  = 2
    gradient_accumulation_steps: int  = 4
    num_train_epochs:            int  = 1
    max_steps:                   int  = -1
    logging_steps:               int  = 10
    save_steps:                  int  = 100
    save_total_limit:            int  = 3
    output_dir:                  str  = "./torelora_output"
    seed:                        int  = 42
    dataloader_num_workers:      int  = 4
    dataloader_prefetch_factor:  int  = 2

    def __post_init__(self):
        self.vram_guard_threshold = min(0.95, max(0.5, self.vram_guard_power))
        if getattr(self, "agi_core", False) and not _XLA:
            self.bbgh = True
            self.omnisync = True
        self.resonance_level = min(2.0, max(0.0, float(self.resonance_level)))
        ZeroFault.autorepair_grad = bool(self.zerofault_autorepair_grad)
        ZeroFault.grad_spike_factor = float(max(2.0, self.zerofault_grad_spike_factor))
        ZeroFault.MAX_HIST = min(65536, max(256, int(self.zerofault_max_hist)))
        self.mnjh_entropy_dim = max(128, int(self.mnjh_entropy_dim))
        self.mnjh_max_loops = min(12, max(1, int(self.mnjh_max_loops)))
        self.mnjh_convergence_threshold = min(1.0, max(1e-6, float(self.mnjh_convergence_threshold)))
        self.mnjh_resonance_threshold = min(1.0, max(1e-6, float(self.mnjh_resonance_threshold)))
        if self.backprop_turbo:
            self.flash_attention = True
            self.torch_compile = True
            self.compile_power = max(self.compile_power, 0.9)
            if self.turbo_disable_checkpointing:
                self.gradient_checkpointing = False
            self.dataloader_num_workers = max(4, int(self.dataloader_num_workers))
        self.backprop_engine = str(self.backprop_engine).lower().strip()
        if self.backprop_engine not in ("auto", "native", "hybrid", "fast_approx"):
            self.backprop_engine = "auto"
        self.backprop_validate_every = max(1, int(self.backprop_validate_every))
        self.backprop_clip_norm = max(0.0, float(self.backprop_clip_norm))
        if self.bbgh_best_mode:
            self.bbgh = True
            self.bbgh_agi_mode = True
            self.bbgh_self_consistency = max(self.bbgh_self_consistency, 5)
            self.bbgh_plan_depth = max(self.bbgh_plan_depth, 4)
            self.bbgh_synthetic_boost = max(self.bbgh_synthetic_boost, 1.8)
        if self.bbgh_research_agi:
            self.bbgh = True
            self.bbgh_agi_mode = True
            self.bbgh_self_consistency = max(self.bbgh_self_consistency, 6)
            self.bbgh_plan_depth = max(self.bbgh_plan_depth, 5)
            self.bbgh_synthetic_boost = max(self.bbgh_synthetic_boost, 2.0)
        self.bbgh_self_consistency = min(9, max(1, int(self.bbgh_self_consistency)))
        self.bbgh_plan_depth = min(8, max(1, int(self.bbgh_plan_depth)))
        self.ag_core_cycles = min(64, max(1, int(self.ag_core_cycles)))
        self.ag_core_max_ops_per_cycle = max(8, int(self.ag_core_max_ops_per_cycle))
        self.ag_core_max_ms_per_cycle = max(1.0, float(self.ag_core_max_ms_per_cycle))
        if self.lora_power < 1.0:
            self.lora_r = max(1, int(self.lora_r * self.lora_power))
        if self.compile_power >= 0.9:   self.torch_compile_mode = "max-autotune"
        elif self.compile_power >= 0.6: self.torch_compile_mode = "reduce-overhead"
        else:                           self.torch_compile_mode = "default"
        if self.quantization not in (None,"none","corap20") and self.quantization_power < 0.7:
            self.quantization = "8bit"
        if self.packing_power < 0.1:   self.batch_packing = False
        if self.attention_power < 0.3: self.flash_attention = False
        if self.corap20:               self.quantization = "corap20"
        if self.quantization == "corap20": self.corap20 = True
        if _XLA:
            self.quantization = "none"; self.two_bit_quant = False
            self.torch_compile = False; self.xla_compile = True
            if self.corap20: self.corap20 = False
        # OMNISYNC + BBGH XLA kısıtlamaları
        if _XLA:
            self.omnisync = False
            self.bbgh     = False

# Geriye uyumluluk
FastLoRAConfig = TOREloRAConfig


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 9 — DEVICE + TEMEL BİLEŞENLER
# ══════════════════════════════════════════════════════════════════════════════

class DeviceManager:
    def __init__(self):
        self.is_tpu      = _XLA
        self.device      = self._detect()
        self.device_name = self._get_name()

    def _detect(self):
        if _XLA: return XLAHelper.device() or torch.device("cpu")
        if torch.cuda.is_available(): return torch.device("cuda")
        if hasattr(torch.backends,"mps") and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")

    def _get_name(self):
        if _XLA:                           return f"TPU ×{XLAHelper.num_devices()}"
        if self.device.type == "cuda":     return torch.cuda.get_device_name(0)
        if self.device.type == "mps":      return "Apple Silicon (MPS)"
        return "CPU"

    def get_vram_gb(self) -> float:
        if _XLA: return 16.0
        if self.device.type == "cuda":
            return torch.cuda.get_device_properties(0).total_memory / 1e9
        return 0.

    def get_free_gb(self) -> float:
        if self.device.type != "cuda": return 0.
        f, _ = torch.cuda.mem_get_info(); return f / 1e9

    def get_ratio(self) -> float:
        if self.device.type != "cuda": return 0.
        return torch.cuda.memory_allocated() / \
               torch.cuda.get_device_properties(0).total_memory

    def best_dtype(self) -> torch.dtype:
        if _XLA: return torch.bfloat16
        if self.device.type == "cuda":
            return torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        return torch.float32

    def num_gpus(self) -> int:
        if _XLA: return XLAHelper.num_devices()
        return torch.cuda.device_count() if torch.cuda.is_available() else 0

    def report(self):
        logger.info(f"Cihaz        : {self.device_name}")
        if not _XLA and self.device.type == "cuda":
            logger.info(f"VRAM         : {self.get_free_gb():.1f}GB serbest / {self.get_vram_gb():.1f}GB")

def _check_deps(auto: bool = False) -> Dict[str, bool]:
    r: Dict[str,bool] = {}
    for p in ["torch","transformers","accelerate","peft","bitsandbytes",
              "flash_attn","trl","datasets","triton","deepspeed","optuna","torch_xla"]:
        try: __import__(p); r[p] = True
        except ImportError:
            r[p] = AutoInstaller.ensure(p) if auto else False
    return r

DEPS: Dict[str, bool] = {}


# ── Küçük yardımcı sınıflar ───────────────────────────────────────────────────

class VRAMGuard:
    def __init__(self, cfg, dev):
        self.cfg=cfg; self.dev=dev; self._stop=threading.Event(); self._mon=None
        self._batch=cfg.per_device_train_batch_size
        self._accum=cfg.gradient_accumulation_steps
    def check(self, trainer=None):
        if not self.cfg.vram_guard or _XLA: return
        if self.dev.device.type!="cuda": return
        r=self.dev.get_ratio()
        if r<self.cfg.vram_guard_threshold: return
        old=self._batch; self._batch=max(self.cfg.vram_min_batch,self._batch//2)
        self._accum=self._accum*max(1,old//max(self._batch,1))
        logger.warning(f"VRAM Guard   : %{r*100:.0f} → batch {old}→{self._batch}")
        if trainer and hasattr(trainer,"args"):
            trainer.args.per_device_train_batch_size=self._batch
            trainer.args.gradient_accumulation_steps=self._accum
        gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    def start(self, trainer=None):
        if _XLA or not self.cfg.vram_guard: return
        def loop():
            while not self._stop.is_set():
                ZeroFault.run(self.check,trainer,etype="VRAM"); time.sleep(5)
        self._mon=threading.Thread(target=loop,daemon=True); self._mon.start()
        logger.info(f"VRAM Guard   : ✓  eşik={self.cfg.vram_guard_threshold*100:.0f}%")
    def stop(self):
        self._stop.set()
        if self._mon: self._mon.join(timeout=2)
    @property
    def cur_batch(self): return self._batch
    @property
    def cur_accum(self): return self._accum


class CUDAOpt:
    def __init__(self, e): self.e=e
    def apply(self):
        if not self.e or not torch.cuda.is_available(): return
        torch.backends.cuda.matmul.allow_tf32=True
        torch.backends.cudnn.allow_tf32=True
        torch.backends.cudnn.benchmark=True
        torch.backends.cudnn.deterministic=False
        if _TV>=(2,0):
            os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF",
                "max_split_size_mb:512,garbage_collection_threshold:0.8")
        logger.info("CUDA Opts    : TF32 ✓  cuDNN ✓")


class GradCkpt:
    def __init__(self, cfg): self.cfg=cfg
    def apply(self, m):
        if not self.cfg.gradient_checkpointing: return m
        if getattr(m,"is_gradient_checkpointing",False): return m
        if hasattr(m,"gradient_checkpointing_enable"):
            try:
                m.gradient_checkpointing_enable(
                    gradient_checkpointing_kwargs=self.cfg.gradient_checkpointing_kwargs)
                logger.info("Grad Ckpt    : ✓")
            except Exception as e:
                ZeroFault.report("GRAD_CKPT","Başarısız",str(e))
        return m


class CompileMgr:
    def __init__(self, cfg, dev): self.cfg=cfg; self.dev=dev
    def apply(self, m):
        if _XLA:
            dev=XLAHelper.device()
            if dev: m=m.to(dev); logger.info(f"XLA Compile  : ✓  → {dev}")
            return m
        if not self.cfg.torch_compile or not _HAS_COMPILE: return m
        if self.cfg.quantization in ("4bit","8bit"): return m
        if self.dev.device.type=="mps": return m
        try:
            if self.cfg.compile_cache:
                os.makedirs(self.cfg.compile_cache_dir,exist_ok=True)
                os.environ.setdefault("TORCHINDUCTOR_CACHE_DIR",
                    str(Path(self.cfg.compile_cache_dir)/"inductor"))
            t0=time.perf_counter()
            m=torch.compile(m,mode=self.cfg.torch_compile_mode,
                             fullgraph=self.cfg.torch_compile_fullgraph)
            logger.info(f"torch.compile: ✓  {self.cfg.torch_compile_mode} ({time.perf_counter()-t0:.1f}s)")
        except Exception as e:
            ZeroFault.report("COMPILE","torch.compile başarısız",str(e))
        return m


class AttnMgr:
    def __init__(self, cfg, dev): self.cfg=cfg; self.dev=dev
    def get_impl(self) -> str:
        if _XLA: return "eager"
        if not self.cfg.flash_attention: return "sdpa" if _HAS_SDPA else "eager"
        if self.dev.device.type!="cuda": return "sdpa"
        deps=_check_deps()
        if deps.get("flash_attn"):
            logger.info("Attention    : Flash Attention 2 ✓"); return "flash_attention_2"
        if _HAS_SDPA: logger.info("Attention    : SDPA ✓"); return "sdpa"
        return "eager"
    def patch_sw(self, m):
        if not self.cfg.sliding_window: return m
        try:
            if hasattr(m.config,"sliding_window"):
                m.config.sliding_window=self.cfg.sliding_window_size
        except Exception as e:
            ZeroFault.report("SLIDING_WIN","Başarısız",str(e))
        return m


_LORA_TARGETS={
    "llama":   ["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"],
    "mistral": ["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"],
    "phi":     ["q_proj","k_proj","v_proj","dense","fc1","fc2"],
    "gemma":   ["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"],
    "qwen":    ["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"],
    "falcon":  ["query_key_value","dense","dense_h_to_4h","dense_4h_to_h"],
    "gpt2":    ["c_attn","c_proj","c_fc"],
    "bloom":   ["query_key_value","dense","dense_h_to_4h","dense_4h_to_h"],
    "t5":      ["q","v"],
    "mpt":     ["Wqkv","out_proj","fc1","fc2"],
    "opt":     ["q_proj","v_proj","out_proj","fc1","fc2"],
    "vit":     ["query","key","value","dense"],
    "whisper": ["q_proj","k_proj","v_proj","out_proj"],
    "clip":    ["q_proj","k_proj","v_proj","out_proj"],
    "default": ["q_proj","v_proj"],
}

class LoRAMgr:
    def __init__(self, cfg): self.cfg=cfg
    def _targets(self, m):
        mt=getattr(m.config,"model_type","").lower()
        for k, v in _LORA_TARGETS.items():
            if k in mt: logger.info(f"LoRA targets : {v}"); return v
        names=sorted({n.split(".")[-1] for n, mod in m.named_modules()
            if isinstance(mod,nn.Linear) and n.split(".")[-1] not in
            ("lm_head","embed_tokens","embed_positions","wte","wpe")})[:8]
        return names or _LORA_TARGETS["default"]
    def apply(self, m):
        if not self.cfg.lora: return m
        deps=_check_deps()
        if not deps.get("peft"):
            if self.cfg.auto_install: AutoInstaller.ensure("peft")
            else:
                ZeroFault.report("LORA","PEFT yok","","pip install peft"); return m
        try:
            from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
            if self.cfg.quantization in ("4bit","8bit") and deps.get("bitsandbytes") and not _XLA:
                m=prepare_model_for_kbit_training(m,
                    use_gradient_checkpointing=self.cfg.gradient_checkpointing,
                    gradient_checkpointing_kwargs=self.cfg.gradient_checkpointing_kwargs)
            tgt=self.cfg.lora_target_modules or self._targets(m)
            m=get_peft_model(m, LoraConfig(
                r=self.cfg.lora_r, lora_alpha=self.cfg.lora_alpha,
                target_modules=tgt, lora_dropout=self.cfg.lora_dropout,
                bias=self.cfg.lora_bias, task_type="CAUSAL_LM",
                use_rslora=self.cfg.use_rslora))
            tr=sum(p.numel() for p in m.parameters() if p.requires_grad)
            tt=sum(p.numel() for p in m.parameters())
            logger.info(f"LoRA         : ✓  r={self.cfg.lora_r}, α={self.cfg.lora_alpha}, "
                        f"{tr/tt*100:.2f}% eğitilebilir")
        except Exception as e:
            ZeroFault.report("LORA","LoRA başarısız",str(e),exc=e)
        return m


class QuantMgr:
    def __init__(self, cfg, dev): self.cfg=cfg; self.dev=dev
    def get_bnb(self):
        if _XLA or self.cfg.quantization in (None,"none","corap20","2bit"): return None
        deps=_check_deps()
        if not deps.get("bitsandbytes"):
            if self.cfg.auto_install: AutoInstaller.ensure("bitsandbytes")
            else: return None
        if self.dev.device.type!="cuda": return None
        try:
            from transformers import BitsAndBytesConfig
            dm={"bf16":torch.bfloat16,"fp16":torch.float16,"fp32":torch.float32}
            cd=dm.get(self.cfg.bnb_4bit_compute_dtype,torch.bfloat16)
            if self.cfg.quantization=="4bit":
                logger.info("Quantization : 4-bit NF4 ✓")
                return BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_compute_dtype=cd,
                    bnb_4bit_quant_type=self.cfg.bnb_4bit_quant_type,
                    bnb_4bit_use_double_quant=self.cfg.bnb_4bit_use_double_quant)
            logger.info("Quantization : 8-bit ✓")
            return BitsAndBytesConfig(load_in_8bit=True)
        except Exception as e:
            ZeroFault.report("QUANT","BnB config başarısız",str(e)); return None


class HWScan:
    _P={
        "cpu":       {"quantization":"none","torch_compile":False,"flash_attention":False,
                      "per_device_train_batch_size":1,"gradient_accumulation_steps":8,"precision":"fp32"},
        "tpu":       {"quantization":"none","torch_compile":False,"flash_attention":False,
                      "per_device_train_batch_size":8,"gradient_accumulation_steps":2,"precision":"bf16"},
        "low_end":   {"quantization":"4bit","torch_compile":True,"flash_attention":False,
                      "per_device_train_batch_size":1,"gradient_accumulation_steps":8,
                      "vram_guard":True,"cpu_offload":True,"gradient_checkpointing":True},
        "mid_range": {"quantization":"4bit","torch_compile":True,"flash_attention":True,
                      "per_device_train_batch_size":2,"gradient_accumulation_steps":4,"vram_guard":True},
        "high_end":  {"quantization":"4bit","torch_compile":True,"flash_attention":True,
                      "per_device_train_batch_size":4,"gradient_accumulation_steps":2,"precision":"bf16"},
        "datacenter":{"quantization":"none","torch_compile":True,"flash_attention":True,
                      "per_device_train_batch_size":8,"gradient_accumulation_steps":1,"precision":"bf16"},
        "flagship":  {"quantization":"none","torch_compile":True,"flash_attention":True,
                      "per_device_train_batch_size":16,"gradient_accumulation_steps":1,"precision":"bf16"},
    }
    def profile(self):
        if _XLA: return "tpu"
        if not torch.cuda.is_available(): return "cpu"
        v=torch.cuda.get_device_properties(0).total_memory/1e9
        if v>=80: return "flagship"
        if v>=40: return "datacenter"
        if v>=16: return "high_end"
        if v>=8:  return "mid_range"
        return "low_end"
    def apply(self, cfg, user_set):
        p=self.profile(); s=self._P.get(p,{}); applied=[]
        for k, v in s.items():
            if k not in user_set and hasattr(cfg,k): setattr(cfg,k,v); applied.append(k)
        logger.info(f"HW Profile   : {p.upper()}, {len(applied)} ayar otomatik")


class CrashHandler:
    def __init__(self, cfg, dev):
        self.cfg=cfg; self.dev=dev
        self._nan=self._cuda=self._skip=0; self._safe=False; self._log=[]
    def handle(self, exc, ctx=None):
        err=str(exc).lower(); ctx=ctx or {}
        try: oom=isinstance(exc,torch.cuda.OutOfMemoryError) or "out of memory" in err
        except: oom="out of memory" in err
        if oom:
            gc.collect()
            if torch.cuda.is_available(): torch.cuda.empty_cache()
            self._log.append({"t":time.strftime("%H:%M:%S"),"type":"OOM"})
            logger.warning("Kurtarma     : OOM → temizlendi"); return True
        if "cuda error" in err:
            self._cuda+=1
            try:
                if torch.cuda.is_available(): torch.cuda.synchronize(); torch.cuda.empty_cache()
            except: pass
            if self._cuda>3: self._safe_on()
            return True
        if "nan" in err or "inf" in err:
            self._nan+=1
            if self._nan>5 and "trainer" in ctx:
                try:
                    for pg in ctx["trainer"].optimizer.param_groups: pg["lr"]*=0.5
                except: pass
            return True
        if any(x in err for x in ["index","shape","size","dimension","broadcast"]):
            self._skip+=1; return True
        if "xla" in err or "tpu" in err:
            XLAHelper.mark_step(); return True
        self._safe_on(); return True
    def _safe_on(self):
        if self._safe: return
        self._safe=True
        self.cfg.torch_compile=self.cfg.flash_attention=False
        self.cfg.batch_packing=self.cfg.fused_ops=False
        self.cfg.per_device_train_batch_size=1
        self.cfg.gradient_accumulation_steps=max(16,self.cfg.gradient_accumulation_steps)
        gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
        logger.warning("GÜVENLİ MOD  : Tüm optimizasyonlar kapatıldı, devam ediyor")
    def summary(self): return {"total":len(self._log),"nan":self._nan,
                                "cuda":self._cuda,"skip":self._skip,"safe":self._safe}


class Unstoppable:
    def __init__(self, fl, crash): self.fl=fl; self.crash=crash; self._n=0
    def train(self, trainer, resume=None):
        for attempt in range(10):
            try:
                r=trainer.train(resume_from_checkpoint=resume)
                s=self.crash.summary()
                logger.info(f"Eğitim ✓     : {s['total']} hata atlatıldı")
                return r
            except KeyboardInterrupt:
                logger.info("Durduruldu   : KeyboardInterrupt"); raise
            except Exception as e:
                self._n+=1
                if not self.crash.handle(e,{"trainer":trainer}): raise
                try:
                    ckpts=sorted([d for d in Path(trainer.args.output_dir).iterdir()
                        if d.is_dir() and "checkpoint" in d.name],
                        key=lambda x:int(x.name.split("-")[-1])
                        if x.name.split("-")[-1].isdigit() else 0)
                    resume=str(ckpts[-1]) if ckpts else resume
                except: pass
                logger.info(f"Devam #{attempt+1}")
        raise RuntimeError("[TOREloRA] 10 denemeden sonra tamamlanamadı")


def _opt_name(cfg, deps) -> str:
    if _XLA: return "adamw_torch"
    if cfg.paged_optimizer and deps.get("bitsandbytes"): return "paged_adamw_8bit"
    if _HAS_FUSED_ADAM: return "adamw_torch_fused"
    return "adamw_torch"


# HF Köprüsü
class HFBridge:
    @staticmethod
    def make_card(cfg) -> str:
        return "\n".join(["---","library_name: torelora",
            f"base_model: {cfg.model_name}","tags:","  - torelora","  - lora",
            f"  - {'corap20' if cfg.corap20 else 'peft'}",
            f"license: mit","---","",
            f"# TOREloRA v1.0.2: {cfg.model_name}","",
            "> TORE TEKNOLOJİ & ARAŞTIRMA — MIT Lisansı","",
            "## Kullanım","```python","from torelora import TOREloRA",
            f'tl = TOREloRA("{cfg.model_name}")',"model, tok = tl.load()","```",])
    @staticmethod
    def detect_fmt(ds) -> str:
        if ds is None: return "none"
        try:
            s=next(iter(ds))
            if not isinstance(s,dict): return "unknown"
            k=set(s.keys())
            if "input_ids" in k: return "tokenized"
            if "text" in k: return "text"
            if "instruction" in k: return "alpaca"
            if "messages" in k: return "chatml"
            if "prompt" in k: return "prompt"
        except Exception: pass
        return "unknown"
    @staticmethod
    def auto_fmt(ds):
        f=HFBridge.detect_fmt(ds)
        if f=="text":   return lambda x: x.get("text","")
        if f=="alpaca": return format_alpaca
        if f=="chatml": return format_chatml
        if f=="prompt": return lambda x: x.get("prompt","")
        return None


# ══════════════════════════════════════════════════════════════════════════════
# BÖLÜM 10 — ANA SINIF: TOREloRA
# ══════════════════════════════════════════════════════════════════════════════

class TOREloRA:
    """
    TOREloRA v1.0.2  ⚡🌊🔮🧬
    TORE TEKNOLOJİ & ARAŞTIRMA — MIT Lisansı

    ═══ EN BASIT KULLANIM ═══════════════════════════════════════════
      tl = TOREloRA("mistralai/Mistral-7B-v0.3")
      model, tok = tl.load()
      trainer = tl.get_trainer(dataset)
      tl.train(trainer)

    ═══ HER PARAMETRENİN 20+ ADI VAR ═══════════════════════════════
      tl = TOREloRA(
          model="llama3",           # veya: model_name, checkpoint, base...
          rank=32,                   # veya: lora_r, r, adapter_rank...
          lr=3e-4,                   # veya: learning_rate, step_size...
          batch=4,                   # veya: batch_size, bs, train_batch...
          epochs=3,                  # veya: num_epochs, passes...
          sgp=True,                  # ASGP v2: her parametreye farklı veri
          ssyp=True,                 # Tüm tokenlar tek paket
          corap20=True,              # Hibrit 2-bit ekosistemi
      )

    ═══ YENİ TEKNOLOJİLER ═══════════════════════════════════════════
      # SSYP — pipeline yükü sıfır
      tl = TOREloRA("model", ssyp=True, ssyp_residue=True)

      # CORAP20 — 4-bit boyut, fp32 hassasiyeti, holografik bağlar
      tl = TOREloRA("model", corap20=True)

      # ASGP v2 — her parametreye FARKLI rastgele veri
      tl = TOREloRA("model", sgp=True, pipe_unique=True)

      # Hepsi birden
      tl = TOREloRA("model", sgp=True, ssyp=True, corap20=True)
    """

    def __init__(
        self,
        model_name_or_config: Union[str, TOREloRAConfig] = "meta-llama/Llama-3.2-3B",
        **kwargs
    ):
        kwargs = _resolve(kwargs)  # Tüm takma adları çöz

        if isinstance(model_name_or_config, TOREloRAConfig):
            self.cfg      = model_name_or_config
            self._user_set: set = set()
        else:
            self._user_set = set(kwargs.keys())
            cfg_fields     = {f for f in TOREloRAConfig.__dataclass_fields__}
            cfg_kw         = {k: v for k, v in kwargs.items() if k in cfg_fields}
            self.cfg       = TOREloRAConfig(model_name=model_name_or_config, **cfg_kw)

        global DEPS
        DEPS = _check_deps(auto=self.cfg.auto_install)

        # Bileşenler
        self.dev         = DeviceManager()
        self.quant_mgr   = QuantMgr(self.cfg, self.dev)
        self.attn_mgr    = AttnMgr(self.cfg, self.dev)
        self.lora_mgr    = LoRAMgr(self.cfg)
        self.grad_ckpt   = GradCkpt(self.cfg)
        self.compile_mgr = CompileMgr(self.cfg, self.dev)
        self.cuda_opt    = CUDAOpt(self.cfg.cuda_optimizations)
        self.vram_guard  = VRAMGuard(self.cfg, self.dev)
        self.hw_scan     = HWScan()
        self.crash       = CrashHandler(self.cfg, self.dev)
        self.turbo       = BackpropTurbo(self.cfg, self.dev)
        self.bp_engine   = BackpropEngine(self.cfg, self.dev)

        # ASGP v2
        self.pipe: Optional[ASGPv2] = None
        if self.cfg.stream_grad_pipe:
            _pipe_kw = dict(
                pipe_mb=self.cfg.pipe_size_mb,
                noise=self.cfg.pipe_noise_scale,
                refresh_every=self.cfg.pipe_refresh_every,
                priority=self.cfg.pipe_priority,
                device=self.dev.device,
                dist=self.cfg.pipe_distribution,
                adaptive=self.cfg.pipe_adaptive,
                async_bg=self.cfg.pipe_async,
                n_ring=self.cfg.pipe_n_ring,
                int8=self.cfg.pipe_int8,
                nonblocking=self.cfg.pipe_nonblocking,
                min_noise=self.cfg.pipe_min_noise,
                max_noise=self.cfg.pipe_max_noise,
                seed=self.cfg.pipe_seed,
                unique_per_param=self.cfg.pipe_unique,
            )
            if getattr(self.cfg, "asgp_v3", False):
                self.pipe = ASGPv3(
                    bg_idle_sleep=self.cfg.pipe_bg_idle_sleep, **_pipe_kw
                )
            else:
                self.pipe = ASGPv2(**_pipe_kw)

        # SSYP (tokenizer yüklenmeden önce hazırla — lazy init)
        self._ssyp: Optional[SSYP] = None

        # CORAP20
        self._corap20: Optional[CORAP20Engine] = None

        # ParamMesh
        self._mesh: Optional[ParamMesh] = None

        self.model:     Optional[nn.Module] = None
        self.tokenizer: Any                 = None

        # ── OMNISYNC / BBGH: model yüklendikten sonra load() içinde kurulur (v1.0.5)
        self.omni: Optional["OmniSync"] = None
        self.bbgh_engine: Optional["BBGHEngine"] = None
        self.mnjh_engine: Optional["MNJHEngine"] = None
        self.ag_core: Optional["AGCoreEngine"] = None

        self._print_banner()

    # ── Yükleme ──────────────────────────────────────────────────────────────

    def load(self):
        """Modeli yükle ve tüm teknolojileri etkinleştir. → (model, tokenizer)"""
        # HW tarama
        if self.cfg.auto_hardware_scan:
            self.hw_scan.apply(self.cfg, self._user_set)

        self.cuda_opt.apply()
        self.dev.report()
        logger.info(f"Model        : {self.cfg.model_name}")

        tokenizer = self._load_tokenizer()
        bnb       = self.quant_mgr.get_bnb()
        attn      = self.attn_mgr.get_impl()
        dtype     = self._resolve_dtype()
        logger.info(f"Dtype        : {dtype}")

        model = self._load_model(bnb, attn, dtype)
        model = self.lora_mgr.apply(model)
        model = self.grad_ckpt.apply(model)
        model = self.attn_mgr.patch_sw(model)

        # KV cache kapat
        if self.cfg.kv_cache_optimize:
            ZeroFault.run(lambda: setattr(model.config,"use_cache",False),
                          etype="KV_CACHE")

        # RMSNorm fused
        if self.cfg.fused_ops:
            model = ZeroFault.run(self._patch_rmsnorm, model,
                                  default=model, etype="FUSED_OPS")

        # CORAP20
        if self.cfg.corap20 and not _XLA:
            self._corap20 = CORAP20Engine(
                model=model,
                block_size=self.cfg.corap20_block_size,
                gkp_size_mb=self.cfg.corap20_gkp_mb,
                holographic=self.cfg.corap20_holographic,
                device=self.dev.device,
            )
            n = ZeroFault.run(self._corap20.quantize_model,
                              default=0, etype="CORAP20", what="quantize_model")
            if n:
                s = self._corap20.memory_stats()
                logger.info(f"CORAP20      : ✓  {n} katman · "
                            f"%{s['saving_pct']:.0f} tasarruf")

        # Compile
        model = ZeroFault.run(self.compile_mgr.apply, model,
                              default=model, etype="COMPILE")
        model = ZeroFault.run(self.turbo.patch_model, model, default=model, etype="TURBO")

        # SSYP init (tokenizer hazır)
        if self.cfg.ssyp:
            self._ssyp = SSYP(
                tokenizer=tokenizer,
                max_length=self.cfg.max_seq_length,
                residue_alpha=self.cfg.ssyp_residue_alpha,
                residue_enabled=self.cfg.ssyp_residue,
                corap20_bridge=self._corap20 is not None,
                async_tokenize=self.cfg.ssyp_async,
                prefetch=self.cfg.ssyp_prefetch,
                mmap_dir=self.cfg.ssyp_mmap,
                text_field=self.cfg.ssyp_text_field,
                device=self.dev.device,
                universal_mode=True,
            )

        # ASGP v2 model kaydı
        if self.pipe is not None:
            self.pipe.device = self.dev.device
            ZeroFault.run(self.pipe.register_model, model,
                          etype="ASGP", what="model register")

        # ParamMesh
        if self.cfg.param_mesh:
            self._mesh = ParamMesh(model, self.cfg.mesh_strength,
                                   self.cfg.mesh_update_every)

        self.model     = model
        self.tokenizer = tokenizer

        if self.cfg.bbgh and not _XLA:
            self.bbgh_engine = ZeroFault.run(
                lambda: BBGHEngine(
                    embed_dim=self.cfg.bbgh_embed_dim,
                    max_cells=self.cfg.bbgh_max_cells,
                    similarity_thresh=self.cfg.bbgh_similarity_thresh,
                    temperature=self.cfg.bbgh_temperature,
                    generator_depth=self.cfg.bbgh_gen_depth,
                    agi_mode=self.cfg.bbgh_agi_mode,
                    self_consistency=self.cfg.bbgh_self_consistency,
                    plan_depth=self.cfg.bbgh_plan_depth,
                    device=self.dev.device,
                    bbgh_synthetic_boost=self.cfg.bbgh_synthetic_boost,
                ),
                etype="BBGH", what="BBGHEngine init", default=None
            )
        if self.cfg.omnisync and not _XLA:
            self.omni = ZeroFault.run(
                lambda: OmniSync(self.model, self.cfg, self.dev.device),
                etype="OMNISYNC", what="OmniSync init", default=None
            )
        if self.cfg.mnjh and not _XLA:
            self.mnjh_engine = ZeroFault.run(
                lambda: MNJHEngine(self.model, self.cfg),
                etype="MNJH", what="engine init", default=None
            )
        if self.cfg.ag_core_non_llm:
            self.ag_core = ZeroFault.run(
                AGCoreEngine, etype="AG_CORE", what="engine init", default=None
            )
            if self.ag_core is not None:
                self.ag_core.resources.max_ops = self.cfg.ag_core_max_ops_per_cycle
                self.ag_core.resources.max_ms = self.cfg.ag_core_max_ms_per_cycle

        self._mem_report()
        return model, tokenizer

    def mnjh_fuse(self, data_source: Any) -> Dict[str, Any]:
        """MNJH harmonic loop çalıştırır. Önce load() çağrılmalı."""
        if self.mnjh_engine is None:
            return {"enabled": False, "reason": "mnjh_disabled_or_not_loaded"}
        return ZeroFault.run(
            self.mnjh_engine.run, data_source,
            etype="MNJH", what="harmonic_loop",
            default={"enabled": True, "ok": False, "reason": "runtime_error"}
        )

    def bbgh_deliberate(self, query_text: str, target_domain: Optional[str] = None) -> Dict[str, Any]:
        """BBGH AGI-benzeri deliberation çağrısı."""
        if self.bbgh_engine is None:
            return {"enabled": False, "reason": "bbgh_disabled_or_not_loaded"}
        return ZeroFault.run(
            self.bbgh_engine.deliberate, query_text, target_domain,
            etype="BBGH", what="deliberate",
            default={"enabled": True, "ok": False, "reason": "runtime_error"}
        )

    def bbgh_research(self, query_text: str, cycles: int = 3,
                      target_domain: Optional[str] = None) -> Dict[str, Any]:
        """BBGH için AGI-benzeri araştırma döngüsü."""
        if self.bbgh_engine is None:
            return {"enabled": False, "reason": "bbgh_disabled_or_not_loaded"}
        return ZeroFault.run(
            self.bbgh_engine.agi_research_cycle, query_text, cycles, target_domain,
            etype="BBGH", what="research_cycle",
            default={"enabled": True, "ok": False, "reason": "runtime_error"}
        )

    def ag_register_operator(self, name: str, pre: Dict[str, Any], eff: Dict[str, Any]) -> Dict[str, Any]:
        if self.ag_core is None:
            return {"enabled": False, "reason": "ag_core_non_llm_disabled_or_not_loaded"}
        self.ag_core.register_operator(name, pre, eff)
        return {"enabled": True, "operator": name}

    def ag_set_goal(self, goal: Dict[str, Any]) -> Dict[str, Any]:
        if self.ag_core is None:
            return {"enabled": False, "reason": "ag_core_non_llm_disabled_or_not_loaded"}
        self.ag_core.set_goal(goal)
        return {"enabled": True, "goal": dict(goal or {})}

    def ag_perceive(self, obs: Dict[str, Any]) -> Dict[str, Any]:
        if self.ag_core is None:
            return {"enabled": False, "reason": "ag_core_non_llm_disabled_or_not_loaded"}
        self.ag_core.perceive(obs)
        return {"enabled": True, "state": self.ag_core.world.snapshot()}

    def ag_run(self, cycles: Optional[int] = None) -> Dict[str, Any]:
        if self.ag_core is None:
            return {"enabled": False, "reason": "ag_core_non_llm_disabled_or_not_loaded"}
        return self.ag_core.run(cycles=cycles or self.cfg.ag_core_cycles)

    def ag_readiness(self) -> Dict[str, Any]:
        if self.ag_core is None:
            return {"enabled": False, "reason": "ag_core_non_llm_disabled_or_not_loaded"}
        return self.ag_core.readiness_report()

    def _load_tokenizer(self):
        if self.cfg.auto_install: AutoInstaller.ensure("transformers")
        from transformers import AutoTokenizer
        try:
            tok = AutoTokenizer.from_pretrained(
                self.cfg.model_name,
                trust_remote_code=self.cfg.allow_remote_code,
                model_max_length=self.cfg.max_seq_length,
            )
            if tok.pad_token is None:
                tok.pad_token=tok.eos_token; tok.pad_token_id=tok.eos_token_id
            tok.padding_side="right"
            return tok
        except Exception as e:
            ZeroFault.report("TOKENIZER","Tokenizer yüklenemedi",str(e),fatal=True)

    def _load_model(self, bnb, attn, dtype):
        if self.cfg.auto_install: AutoInstaller.ensure("transformers")
        from transformers import AutoModelForCausalLM
        dm = None if _XLA else "auto"
        base = dict(pretrained_model_name_or_path=self.cfg.model_name,
                    trust_remote_code=self.cfg.allow_remote_code,
                    torch_dtype=dtype, device_map=dm,
                    attn_implementation=attn, low_cpu_mem_usage=True)
        if bnb and not _XLA: base["quantization_config"]=bnb
        chains = [
            base,
            {**base,"quantization_config":None,"torch_dtype":torch.float16},
            {**base,"quantization_config":None,"torch_dtype":torch.float32,"device_map":"cpu" if not _XLA else None},
        ]
        last=None
        for i, kw in enumerate(chains):
            try:
                if i>0: logger.warning(f"Model fallback #{i}…")
                m=AutoModelForCausalLM.from_pretrained(**kw)
                m.config.use_cache=False; m.config.pretraining_tp=1
                return m
            except RuntimeError as e:
                last=e
                if "out of memory" in str(e).lower():
                    gc.collect()
                    if torch.cuda.is_available(): torch.cuda.empty_cache()
                ZeroFault.report("MODEL_LOAD",f"Fallback #{i+1}",str(e)[:80])
                if i<len(chains)-1: continue
            except Exception as e:
                last=e
                ZeroFault.report("MODEL_LOAD",f"Yükleme hatası #{i+1}",str(e)[:80])
                if self.cfg.strict_mode: raise
                if i<len(chains)-1: continue
        raise RuntimeError(f"[TOREloRA] Model yüklenemedi: {last}")

    def _resolve_dtype(self) -> torch.dtype:
        if self.cfg.precision=="auto": return self.dev.best_dtype()
        return {"bf16":torch.bfloat16,"fp16":torch.float16,"fp32":torch.float32}.get(
            self.cfg.precision, torch.float32)

    def _patch_rmsnorm(self, model):
        replaced=0
        for name, mod in list(model.named_modules()):
            if "rmsnorm" not in type(mod).__name__.lower(): continue
            if not hasattr(mod,"weight"): continue
            h=mod.weight.shape[0]; eps=getattr(mod,"variance_epsilon",getattr(mod,"eps",1e-6))
            class _R(nn.Module):
                def __init__(self,h,eps):
                    super().__init__(); self.weight=nn.Parameter(torch.ones(h)); self.eps=eps
                def forward(self,x):
                    d=x.dtype; xf=x.float()
                    return (xf*torch.rsqrt(xf.pow(2).mean(-1,keepdim=True)+self.eps)).to(d)*self.weight
            nm=_R(h,eps).to(mod.weight.device); nm.weight=mod.weight
            parts=name.split("."); parent=model
            for p in parts[:-1]: parent=getattr(parent,p)
            setattr(parent,parts[-1],nm); replaced+=1
        if replaced: logger.info(f"Fused Ops    : ✓  {replaced} RMSNorm")
        return model

    def _mem_report(self):
        if self.dev.device.type=="cuda":
            a=torch.cuda.memory_allocated()/1e9
            r=torch.cuda.memory_reserved()/1e9
            logger.info(f"GPU Bellek   : {a:.2f}GB / {r:.2f}GB")

    # ── Trainer ──────────────────────────────────────────────────────────────

    def get_trainer(self, train_dataset, eval_dataset=None,
                    formatting_func=None, auto_pack=None, **kwargs):
        """
        Trainer oluştur.
        SSYP etkinse dataset otomatik hazırlanır.
        Dataset formatı otomatik algılanır.
        """
        assert self.model is not None, "Önce tl.load() çağırın!"

        # SSYP pipeline
        if self._ssyp is not None:
            logger.info("SSYP         : Dataset pipeline hazırlanıyor…")
            train_dataset = ZeroFault.run(
                self._ssyp.prepare, train_dataset,
                default=train_dataset, etype="SSYP", what="prepare dataset")

        # Formatting
        if formatting_func is None and self.cfg.auto_formatting:
            formatting_func = HFBridge.auto_fmt(train_dataset)

        # Packing (SSYP yoksa)
        if self._ssyp is None and ((auto_pack is None and self.cfg.batch_packing) or auto_pack):
            try:
                from datasets import Dataset as HFDs
                if not isinstance(train_dataset, HFDs):
                    train_dataset = _simple_pack(train_dataset, self.tokenizer, self.cfg)
            except Exception:
                pass

        # Batch size
        bs = self._auto_batch()

        # Trainer
        deps = _check_deps()
        if deps.get("trl"):
            trainer = self._sft_trainer(train_dataset, eval_dataset, formatting_func, bs)
        else:
            if self.cfg.auto_install:
                AutoInstaller.ensure("trl")
                deps = _check_deps()
            trainer = (self._sft_trainer(train_dataset, eval_dataset, formatting_func, bs)
                       if deps.get("trl")
                       else self._hf_trainer(train_dataset, eval_dataset, bs))

        # XLA wrap
        if _XLA: self._xla_wrap(trainer)

        # Callbacks
        self.vram_guard.start(trainer)
        self._attach_defrag(trainer)

        # ASGP v2
        if self.pipe is not None:
            ZeroFault.run(self.pipe.patch_trainer, trainer, self.model,
                          etype="ASGP", what="patch_trainer")
            self._attach_asgp_optimizer(trainer)

        # SSYP callbacks
        if self._ssyp is not None:
            ZeroFault.run(self._ssyp.patch_trainer, trainer, self.model,
                          self._corap20, etype="SSYP", what="patch_trainer")

        # CORAP20 callbacks
        if self._corap20 is not None:
            ZeroFault.run(self._corap20.patch_trainer, trainer, self.model,
                          self._ssyp, etype="CORAP20", what="patch_trainer")

        # ParamMesh
        if self._mesh is not None:
            ZeroFault.run(self._mesh.attach, trainer, etype="MESH")

        # Spike detector
        if self.cfg.loss_spike_detection:
            ZeroFault.run(self._attach_spike, trainer)

        # Smart checkpoint
        if self.cfg.smart_checkpoint:
            ZeroFault.run(self._attach_smart_ckpt, trainer)

        # Backprop turbo patch
        ZeroFault.run(self.turbo.patch_trainer, trainer, etype="TURBO", what="trainer patch")
        ZeroFault.run(self.bp_engine.maybe_patch_trainer, trainer, etype="BP_ENGINE", what="trainer patch")

        return trainer

    def _auto_batch(self) -> int:
        if _XLA or not self.cfg.auto_batch_size: return self.cfg.per_device_train_batch_size
        if self.dev.device.type != "cuda": return self.cfg.per_device_train_batch_size
        free = self.dev.get_free_gb()
        safe = min(max(1, int(free/0.5)), 32)
        base = self.cfg.per_device_train_batch_size
        if safe > base: logger.info(f"Batch Size   : {base}→{safe} (oto)")
        return max(safe, base)

    def _xla_wrap(self, trainer):
        try:
            orig = type(trainer).training_step
            def xla_step(self_t, model, inputs, num=None):
                try: r=orig(self_t,model,inputs,num)
                except TypeError: r=orig(self_t,model,inputs)
                XLAHelper.mark_step(); return r
            type(trainer).training_step = xla_step
            logger.info("XLA Step     : ✓  mark_step eklendi")
        except Exception as e:
            ZeroFault.report("XLA","Step wrap başarısız",str(e))

    def _attach_defrag(self, trainer):
        interval = self.cfg.mem_defrag_interval
        if not self.cfg.mem_defrag: return
        try:
            from transformers import TrainerCallback
            step=[0]
            class _Cb(TrainerCallback):
                def on_step_end(self,args,state,control,**kw):
                    step[0]+=1
                    if step[0]%interval==0:
                        gc.collect()
                        if torch.cuda.is_available(): torch.cuda.empty_cache()
                        if _XLA: XLAHelper.mark_step()
            trainer.add_callback(_Cb())
        except Exception: pass

    def _attach_asgp_optimizer(self, trainer):
        if self.pipe is None: return
        pipe_=self.pipe; model_=self.model
        try:
            if hasattr(trainer,"optimizer") and trainer.optimizer is not None:
                opt=pipe_.wrap_optimizer(trainer.optimizer)
                opt.set_model(model_); trainer.optimizer=opt
                logger.info("ASGP v2      : ✓  optimizer wrap (eager)")
            else:
                orig=trainer.create_optimizer
                def patched():
                    o=orig(); po=pipe_.wrap_optimizer(o); po.set_model(model_); return po
                trainer.create_optimizer=patched
                logger.info("ASGP v2      : ✓  optimizer wrap (lazy)")
        except Exception as e:
            ZeroFault.report("ASGP","Optimizer wrap başarısız",str(e))

    def _attach_spike(self, trainer):
        from transformers import TrainerCallback
        thr=self.cfg.loss_spike_threshold; act=self.cfg.loss_spike_action
        hist=[]
        class _Cb(TrainerCallback):
            def on_log(self,args,state,control,logs=None,**kw):
                if not logs or "loss" not in logs: return
                loss=float(logs["loss"])
                if not math.isfinite(loss): return
                hist.append(loss)
                if len(hist)<5: return
                avg=sum(hist[-5:-1])/4
                if avg>0 and loss/avg>thr:
                    logger.warning(f"Spike        : {loss:.4f} (x{loss/avg:.1f})")
        trainer.add_callback(_Cb())

    def _attach_smart_ckpt(self, trainer):
        from transformers import TrainerCallback
        best=[float("inf")]; delta=self.cfg.smart_ckpt_delta
        class _Cb(TrainerCallback):
            def on_evaluate(self,args,state,control,metrics=None,**kw):
                if not metrics: return
                loss=metrics.get("eval_loss",metrics.get("loss"))
                if loss is None: return
                if loss<best[0]-delta: best[0]=loss; control.should_save=True
                else: control.should_save=False
        trainer.add_callback(_Cb())

    def _sft_trainer(self, tds, eds, ff, bs):
        from trl import SFTTrainer, SFTConfig
        deps  = _check_deps(); dtype = self._resolve_dtype()
        workers = 0 if _XLA else self.cfg.dataloader_num_workers
        args = SFTConfig(
            output_dir=self.cfg.output_dir,
            per_device_train_batch_size=bs,
            gradient_accumulation_steps=self.vram_guard.cur_accum,
            num_train_epochs=self.cfg.num_train_epochs,
            max_steps=self.cfg.max_steps,
            learning_rate=self.cfg.learning_rate,
            weight_decay=self.cfg.weight_decay,
            warmup_ratio=self.cfg.warmup_ratio,
            lr_scheduler_type=self.cfg.lr_scheduler,
            max_grad_norm=self.cfg.max_grad_norm,
            logging_steps=self.cfg.logging_steps,
            save_steps=self.cfg.save_steps,
            save_total_limit=self.cfg.save_total_limit,
            bf16=(dtype==torch.bfloat16),
            fp16=(dtype==torch.float16 and not _XLA),
            optim=_opt_name(self.cfg,deps), seed=self.cfg.seed,
            dataloader_num_workers=workers,
            dataloader_pin_memory=self.cfg.pin_memory and not _XLA,
            dataloader_prefetch_factor=(
                self.cfg.dataloader_prefetch_factor if workers>0 else None),
            report_to="none",
            max_seq_length=self.cfg.max_seq_length,
            dataset_num_proc=2, packing=False,
            group_by_length=not self.cfg.batch_packing,
            remove_unused_columns=False,
        )
        return SFTTrainer(model=self.model, tokenizer=self.tokenizer,
            train_dataset=tds, eval_dataset=eds, formatting_func=ff, args=args)

    def _hf_trainer(self, tds, eds, bs):
        from transformers import Trainer, TrainingArguments, DataCollatorForLanguageModeling
        deps=_check_deps(); dtype=self._resolve_dtype()
        workers=0 if _XLA else self.cfg.dataloader_num_workers
        args=TrainingArguments(
            output_dir=self.cfg.output_dir,
            per_device_train_batch_size=bs,
            gradient_accumulation_steps=self.vram_guard.cur_accum,
            num_train_epochs=self.cfg.num_train_epochs,
            max_steps=self.cfg.max_steps,
            learning_rate=self.cfg.learning_rate,
            weight_decay=self.cfg.weight_decay,
            warmup_ratio=self.cfg.warmup_ratio,
            lr_scheduler_type=self.cfg.lr_scheduler,
            max_grad_norm=self.cfg.max_grad_norm,
            logging_steps=self.cfg.logging_steps,
            save_steps=self.cfg.save_steps,
            save_total_limit=self.cfg.save_total_limit,
            bf16=(dtype==torch.bfloat16),
            fp16=(dtype==torch.float16 and not _XLA),
            optim=_opt_name(self.cfg,deps), seed=self.cfg.seed,
            dataloader_num_workers=workers,
            dataloader_pin_memory=self.cfg.pin_memory and not _XLA,
            report_to="none",
            group_by_length=not self.cfg.batch_packing,
            remove_unused_columns=False,
        )
        return Trainer(model=self.model, args=args,
            train_dataset=tds, eval_dataset=eds,
            data_collator=DataCollatorForLanguageModeling(self.tokenizer,mlm=False))

    # ── Eğitim ───────────────────────────────────────────────────────────────

    def train(self, trainer, resume=None):
        """Eğitimi başlat. Hiçbir şey durduramaz."""
        if self.cfg.unstoppable:
            result = Unstoppable(self, self.crash).train(trainer, resume)
        else:
            result = trainer.train(resume_from_checkpoint=resume)

        # Son raporlar
        if self.pipe:
            s=self.pipe.status()
            logger.info(f"ASGP Son     : fills={s['fills']}, "
                        f"inject={s['avg_ms']:.2f}ms, noise={s['noise']:.5f}")
        if self._ssyp:
            rs=self._ssyp.residue_stats()
            logger.info(f"SSYP Son     : {rs['count']} param residue, {rs['total_mb']:.1f}MB")
        if self._corap20:
            ms=self._corap20.memory_stats()
            logger.info(f"CORAP20 Son  : %{ms['saving_pct']:.0f} bellek tasarrufu")
        if _XLA:
            XLAHelper.rendezvous("done")
        ZeroFault.summary()
        ZeroFault.save(os.path.join(self.cfg.output_dir,"torelora_errors.json"))
        return result

    # ── Kaydet / Hub ─────────────────────────────────────────────────────────

    def save(self, path: str = None):
        assert self.model is not None
        self.vram_guard.stop()
        if self.pipe: self.pipe.stop()
        path = path or self.cfg.output_dir
        os.makedirs(path, exist_ok=True)
        try:
            if _XLA: XLAHelper.save(self.model.state_dict(), os.path.join(path,"model.pt"))
            else:    self.model.save_pretrained(path)
            if self.tokenizer: self.tokenizer.save_pretrained(path)
            (Path(path)/"README.md").write_text(HFBridge.make_card(self.cfg))
            logger.info(f"Kaydedildi   : {path}")
        except Exception as e:
            ZeroFault.report("SAVE","Kaydetme başarısız",str(e),exc=e)

    def push_to_hub(self, repo_id: str, token: str = None, private: bool = False):
        assert self.model is not None
        if _XLA: logger.warning("Hub Push     : TPU'da önce save() kullanın"); return
        try:
            self.model.push_to_hub(repo_id, token=token, private=private)
            if self.tokenizer: self.tokenizer.push_to_hub(repo_id, token=token)
            try:
                from huggingface_hub import HfApi
                HfApi().upload_file(
                    path_or_fileobj=HFBridge.make_card(self.cfg).encode(),
                    path_in_repo="README.md", repo_id=repo_id, token=token)
            except Exception: pass
            logger.info(f"Hub          : ✓  https://huggingface.co/{repo_id}")
        except Exception as e:
            ZeroFault.report("HUB","Hub push başarısız",str(e),exc=e)

    def merge_and_unload(self):
        if not DEPS.get("peft"): return self.model
        try:
            from peft import PeftModel
            if isinstance(self.model, PeftModel):
                self.model=self.model.merge_and_unload()
                logger.info("LoRA Merge   : ✓")
        except Exception as e:
            ZeroFault.report("MERGE","Merge başarısız",str(e),exc=e)
        return self.model

    # ── Inference ────────────────────────────────────────────────────────────

    @torch.inference_mode()
    def generate(self, prompt: str, max_new_tokens: int = 256,
                 temperature: float = 0.7, top_p: float = 0.9,
                 do_sample: bool = True, repetition_penalty: float = 1.1) -> str:
        assert self.model is not None
        self.model.config.use_cache=True
        try:
            inp=self.tokenizer(prompt,return_tensors="pt").to(self.dev.device)
            out=self.model.generate(**inp,max_new_tokens=max_new_tokens,
                temperature=temperature,top_p=top_p,do_sample=do_sample,
                repetition_penalty=repetition_penalty,
                pad_token_id=self.tokenizer.eos_token_id)
            if _XLA: XLAHelper.mark_step()
            return self.tokenizer.decode(
                out[0][inp["input_ids"].shape[1]:],skip_special_tokens=True)
        except Exception as e:
            ZeroFault.report("GENERATE","Üretim başarısız",str(e),exc=e); return ""
        finally:
            self.model.config.use_cache=False

    # ── Durum / Stats ─────────────────────────────────────────────────────────

    def status(self) -> Dict:
        return {
            "version":   __version__,
            "author":    __author__,
            "model":     self.cfg.model_name,
            "device":    str(self.dev.device),
            "loaded":    self.model is not None,
            "asgp_v2":   self.pipe.status() if self.pipe else {"enabled":False},
            "ssyp":      self._ssyp.residue_stats() if self._ssyp else {"enabled":False},
            "corap20":   self._corap20.memory_stats() if self._corap20 else {"enabled":False},
            "mesh":      {"enabled": self._mesh is not None},
            "mnjh":      self.mnjh_engine.status() if self.mnjh_engine else {"enabled": False},
            "backprop":  {"enabled": self.cfg.backprop_enabled, "mode": self.bp_engine.mode},
            "ag_core":   self.ag_core.status() if self.ag_core else {"enabled": False},
            "errors":    len(ZeroFault._hist),
        }

    def benchmark(self, n=10) -> Dict:
        assert self.model is not None
        dev=self.dev.device
        dummy=self.tokenizer("TOREloRA " * 50,return_tensors="pt",
                              max_length=512,truncation=True).to(dev)
        with torch.inference_mode():
            for _ in range(3): self.model(**dummy)
        if _XLA: XLAHelper.mark_step()
        elif torch.cuda.is_available(): torch.cuda.synchronize()
        t0=time.perf_counter()
        with torch.inference_mode():
            for _ in range(n):
                self.model(**dummy)
                if _XLA: XLAHelper.mark_step()
        if torch.cuda.is_available(): torch.cuda.synchronize()
        dt=time.perf_counter()-t0
        tps=dummy["input_ids"].numel()*n/dt
        logger.info(f"Benchmark    : {tps:,.0f} tok/s ({dt:.2f}s, {n} adım)")
        return {"tokens_per_sec":tps,"elapsed":dt}

    def clear_cache(self):
        gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
        if _XLA: XLAHelper.mark_step()

    def stop(self):
        self.vram_guard.stop()
        if self.pipe: self.pipe.stop()
        if self.omni: self.omni.stop()
        ZeroFault.summary()

    def _print_banner(self):
        c=self.cfg
        on="✓ "; off="✗ "
        dev=(f"TPU×{XLAHelper.num_devices()}" if _XLA
             else f"GPU×{self.dev.num_gpus()}" if self.dev.num_gpus()>0 else "CPU")
        print("\n" + "═"*72)
        print(f"  TOREloRA v{__version__}  THE SINGULARITY  ⚡🌊🔮🧬")
        print(f"  {__author__}  —  MIT Lisansı")
        print("═"*72)
        print(f"  agi_core     : {on if getattr(c,'agi_core',False) else off}"
              f"  resonance_level={getattr(c,'resonance_level',1.0):.2f}")
        print(f"  Model        : {c.model_name}")
        print(f"  Cihaz        : {dev}")
        print(f"  LoRA         : {on if c.lora else off}r={c.lora_r}, α={c.lora_alpha}")
        print(f"  Quant        : {c.quantization or 'none'}")
        print(f"  ── 🌊 SSYP ─────────────────────────────────────────────────")
        print(f"  SSYP         : {on if c.ssyp else off}", end="")
        if c.ssyp:
            print(f"residue={'✓' if c.ssyp_residue else '✗'}, "
                  f"α={c.ssyp_residue_alpha}, async={c.ssyp_async}")
        else: print()
        print(f"  ── 🔮 CORAP20 ──────────────────────────────────────────────")
        print(f"  CORAP20      : {on if c.corap20 else off}", end="")
        if c.corap20:
            print(f"GKP={c.corap20_gkp_mb:.0f}MB, holographic={c.corap20_holographic}")
        else: print()
        _pv = "v3" if getattr(c, "asgp_v3", False) else "v2"
        print(f"  ── ⚡ ASGP {_pv} ─────────────────────────────────────────────")
        print(f"  ASGP {_pv}      : {on if c.stream_grad_pipe else off}", end="")
        if c.stream_grad_pipe:
            print(f"pipe={c.pipe_size_mb:.0f}MB, unique={c.pipe_unique}, "
                  f"dist={c.pipe_distribution}"
                  f"{', idle='+str(c.pipe_bg_idle_sleep) if getattr(c,'asgp_v3',False) else ''}")
        else: print()
        print(f"  ── 🧬 ParamMesh ────────────────────────────────────────────")
        print(f"  ParamMesh    : {on if c.param_mesh else off}")
        print(f"  ── 🔷 MNJH [DENEYSEL v1.0.6] ───────────────────────────────")
        print(f"  MNJH         : {on if getattr(c,'mnjh',False) else off}", end="")
        if getattr(c, 'mnjh', False):
            print(f"loop={c.mnjh_max_loops}, dim={c.mnjh_entropy_dim}, thr={c.mnjh_convergence_threshold:.4f}")
        else: print()
        print(f"  ── 🧭 AG Core (Non-LLM) ───────────────────────────────────")
        print(f"  AG Core      : {on if getattr(c,'ag_core_non_llm',False) else off}", end="")
        if getattr(c, 'ag_core_non_llm', False):
            print(f"cycles={c.ag_core_cycles}, budget=({c.ag_core_max_ops_per_cycle} ops/{c.ag_core_max_ms_per_cycle:.1f}ms)")
        else: print()
        print(f"  ── 🌐 OMNISYNC [DENEYSEL] ──────────────────────────────────")
        print(f"  OmniSync     : {on if c.omnisync else off}", end="")
        if c.omnisync:
            print(f"resonance={c.omnisync_resonance} holo={c.omnisync_holographic} "
                  f"async={c.omnisync_async} qgc={c.omnisync_qgc}")
        else: print()
        print(f"  ── 💡 BBGH    [DENEYSEL] ──────────────────────────────────")
        print(f"  BBGH         : {on if c.bbgh else off}", end="")
        if c.bbgh:
            print(f"dim={c.bbgh_embed_dim}, cells={c.bbgh_max_cells}, "
                  f"thresh={c.bbgh_similarity_thresh}, agi_mode={c.bbgh_agi_mode}, best={c.bbgh_best_mode}, research={c.bbgh_research_agi}")
        else: print()
        print(f"  ── Genel ───────────────────────────────────────────────────")
        print(f"  Flash Att    : {on if c.flash_attention else off}")
        print(f"  Compile      : {on if c.torch_compile else off}{c.torch_compile_mode}")
        print(f"  BP Turbo     : {on if getattr(c,'backprop_turbo',False) else off}")
        print(f"  BP Engine    : {'ON' if c.backprop_enabled else 'OFF'} ({c.backprop_engine})")
        print(f"  VRAM Guard   : {on if c.vram_guard else off}")
        print(f"  Unstoppable  : {on if c.unstoppable else off}")
        print(f"  Auto Install : {on if c.auto_install else off}")
        print("═"*72+"\n")

    def __repr__(self):
        return (f"TOREloRA(v{__version__}, model={self.cfg.model_name!r}, "
                f"ssyp={self.cfg.ssyp}, corap20={self.cfg.corap20}, "
                f"asgp={self.cfg.stream_grad_pipe}, omnisync={self.cfg.omnisync}, "
                f"bbgh={self.cfg.bbgh}, tpu={_XLA})")

    def __del__(self):
        try: self.vram_guard.stop()
        except: pass
        try:
            if self.pipe: self.pipe.stop()
        except: pass


# Geriye uyumluluk
FastLoRA = TOREloRA


# ══════════════════════════════════════════════════════════════════════════════
# YARDIMCI FONKSİYONLAR
# ══════════════════════════════════════════════════════════════════════════════

def _simple_pack(dataset, tokenizer, cfg) -> Any:
    """Basit sequence packing."""
    try:
        from datasets import Dataset
        all_ids=[]; eos=getattr(tokenizer,"eos_token_id",0) or 0
        for s in dataset:
            text=(s.get("text") or s.get("content") or s.get("prompt",""))
            if not text: continue
            ids=tokenizer.encode(text,add_special_tokens=True)
            all_ids.extend(ids[:cfg.max_seq_length]); all_ids.append(eos)
        L=cfg.max_seq_length
        chunks=[all_ids[i:i+L] for i in range(0,len(all_ids)-L,L)]
        d={"input_ids":chunks,"labels":chunks,"attention_mask":[[1]*L for _ in chunks]}
        logger.info(f"Packing      : ✓  {len(chunks)} batch")
        return Dataset.from_dict(d)
    except Exception as e:
        ZeroFault.report("PACKING","Packing başarısız",str(e)); return dataset


def format_alpaca(example: dict, tokenizer=None) -> str:
    if example.get("input"):
        return (f"### Talimat:\n{example['instruction']}\n\n"
                f"### Giriş:\n{example['input']}\n\n"
                f"### Yanıt:\n{example['output']}")
    return f"### Talimat:\n{example['instruction']}\n\n### Yanıt:\n{example['output']}"


def format_chatml(example: dict, tokenizer=None) -> str:
    return "".join(f"<|im_start|>{m['role']}\n{m['content']}<|im_end|>\n"
                   for m in example.get("messages",[]))


def check_environment(auto_install: bool = False):
    """Ortamı kontrol et."""
    print(f"\n[TOREloRA v{__version__}] — {__author__}")
    print("─"*60)
    dm=DeviceManager(); dm.report()
    if _XLA: print(f"XLA/TPU      : ✓  {XLAHelper.num_devices()} cihaz")
    print(f"\nPyTorch      : {torch.__version__}")
    print(f"torch.compile: {'✓' if _HAS_COMPILE else '✗ (2.0+)'}")
    print(f"SDPA         : {'✓' if _HAS_SDPA else '✗'}")
    print("\nPaketler:")
    deps=_check_deps(auto=auto_install)
    for pkg, ok in deps.items():
        try:
            import importlib.metadata
            ver=importlib.metadata.version(pkg)
            print(f"  {'✓' if ok else '✗'}  {pkg:<16} {ver}")
        except: print(f"  {'✓' if ok else '✗'}  {pkg}")
    print()


def demo_asgp_v2():
    """ASGP v2 demo — her parametreye farklı veri."""
    print("\n[ASGP v2 Demo — Parametre Başına Farklı Veri]")
    model=nn.Sequential(nn.Linear(128,256), nn.ReLU(), nn.Linear(256,64))
    pipe=ASGPv2(pipe_mb=2., noise=0.01, dist="normal", int8=True,
                async_bg=True, unique_per_param=True)
    pipe.register_model(model)
    x=torch.randn(4,128); out=model(x); out.sum().backward()

    # Her parametrenin farklı offset kullandığını doğrula
    offsets={n: r["offset"] for n, r in pipe._reg.items()}
    unique_off=len(set(offsets.values()))==len(offsets)

    norm=pipe.inject(model)
    s=pipe.status()
    print(f"  Parametre başına farklı offset: {'✓' if unique_off else '✗'}")
    print(f"  Gürültü normu : {norm:.4f}")
    print(f"  Avg inject    : {s['avg_ms']:.2f} ms")
    print(f"  Dağılım       : {s['dist']}")
    pipe.stop()
    print("  ASGP v2 Demo ✓\n")


def demo_ssyp():
    """SSYP demo — tüm tokenlar tek paket."""
    print("\n[SSYP Demo — Tek Paket Pipeline]")

    # Sahte tokenizer
    class FakeTok:
        def encode(self, t, add_special_tokens=True): return list(range(min(len(t),100)))
        eos_token_id = 1

    dataset = [{"text": "Merhaba " * 50 + f" örnek {i}"} for i in range(20)]
    ssyp    = SSYP(FakeTok(), max_length=32, async_tokenize=False)
    t0      = time.perf_counter()
    ds      = ssyp.prepare(dataset)
    dt      = time.perf_counter() - t0

    print(f"  Hazırlık süresi : {dt*1000:.1f} ms")
    print(f"  Batch sayısı    : {len(ds)}")
    print(f"  Residue boyutu  : {ssyp.residue_stats()['count']} param")
    print("  SSYP Demo ✓\n")


def demo_corap20():
    """CORAP20 demo — hibrit 2-bit ekosistemi."""
    print("\n[CORAP20 Demo — Hibrit 2-Bit Ekosistemi]")
    model=nn.Sequential(nn.Linear(256,512), nn.ReLU(), nn.Linear(512,128))
    eng=CORAP20Engine(model, block_size=64, gkp_size_mb=1., holographic=True)
    n=eng.quantize_model()
    s=eng.memory_stats()
    x=torch.randn(4,256)
    with torch.no_grad(): out=model(x)
    print(f"  Quantize edilen katman : {n}")
    print(f"  Bellek tasarrufu       : %{s['saving_pct']:.0f}")
    print(f"  {s['orig_mb']:.2f}MB → {s['corap_mb']:.2f}MB")
    print(f"  Forward çıktı          : {out.shape} ✓")
    print("  CORAP20 Demo ✓\n")




def demo_omnisync():
    """OMNISYNC demo — geometrik rezonans + holografik katlama."""
    print("\n[OmniSync Demo — Evrensel Senkronizasyon]")
    model = nn.Sequential(nn.Linear(128, 256), nn.ReLU(), nn.Linear(256, 64))
    omni  = OmniSync(model)

    tokens = torch.randint(0, 32000, (4, 128))
    t0 = time.perf_counter()
    omni.absorb(tokens)
    snap = omni.snap()
    dt = (time.perf_counter() - t0) * 1000

    print(f"  Hizalama süresi  : {dt:.2f} ms")
    if snap:
        print(f"  Enerji delta     : {snap.get('delta_e', 0):.6f}")
        print(f"  Snap süresi      : {snap.get('ms', 0):.2f} ms")
    if omni.hf:
        s = omni.hf.stats
        print(f"  Hologram enjeksiyon: {s['injections']}")
        print(f"  Pattern norm     : {s['pattern_norm']:.4f}")
    omni.stop()
    print("  OmniSync Demo ✓\n")


def demo_bbgh():
    """BBGH demo — parametresiz/tokensiz anlayan model."""
    print("\n[BBGH Demo — Bilinç Bazlı Geometrik Hafıza]")
    bbgh = BBGHEngine(embed_dim=256, max_cells=1000)

    # Anlık öğrenme
    texts = [
        "Python programlama dili 1991 yılında Guido van Rossum tarafından oluşturuldu.",
        "Yapay zeka, insan zekasını taklit eden bilgisayar sistemleridir.",
        "TOREloRA hızlı fine-tuning için tasarlanmış bir kütüphanedir.",
        "Derin öğrenme, çok katmanlı sinir ağlarını kullanır.",
        "Transformerlar dikkat mekanizmasına dayalı mimarilerdir.",
    ]
    t0 = time.perf_counter()
    n_learned = bbgh.batch_learn(texts)
    dt_learn = (time.perf_counter() - t0) * 1000

    # Sorgulama
    t0 = time.perf_counter()
    hits = bbgh.query("Python kim yazdı?", top_k=3)
    dt_query = (time.perf_counter() - t0) * 1000

    # Cümle üretimi
    output = bbgh.generate("yapay zeka nedir")

    print(f"  Öğrenilen        : {n_learned}/{len(texts)}")
    print(f"  Öğrenme süresi   : {dt_learn:.2f} ms (backprop yok!)")
    print(f"  Sorgu süresi     : {dt_query:.4f} ms")
    print(f"  En iyi eşleşme   : {hits[0]['value'][:60]}..." if hits else "  Eşleşme yok")
    print(f"  Üretilen çıktı   : {output[:80]}")
    s = bbgh.stats
    print(f"  Hafıza hücreleri : {s['cells']}")
    print("  BBGH Demo ✓\n")


def demo_simple_config():
    """SimpleConfig demo — c/true c/false sistemi."""
    print("\n[SimpleConfig Demo — c/true / c/false Sistemi]")
    cfg = SimpleConfig.parse("""
        # Bu bir yorum satırı
        model_name        meta-llama/Llama-3.2-1B
        ssyp              c/true
        omnisync          c/true
        bbgh              c/false
        corap20           c/false
        lora_r            32
        batch_size        4
        epochs            1
        flash_attention   c/true
        param_mesh        c/false
        agi_core          c/false
        resonance_level   1.15
        asgp_v3           c/false
    """)
    print(f"  Model      : {cfg.model_name}")
    print(f"  SSYP       : {cfg.ssyp}")
    print(f"  OMNISYNC   : {cfg.omnisync}")
    print(f"  BBGH       : {cfg.bbgh}")
    print(f"  agi_core   : {cfg.agi_core}  resonance={cfg.resonance_level:.2f}")
    print(f"  LoRA r     : {cfg.lora_r}")
    print("  SimpleConfig Demo ✓\n")

if __name__ == "__main__":
    check_environment()
    demo_asgp_v2()
    demo_ssyp()
    demo_corap20()
    demo_omnisync()
    demo_bbgh()
    demo_simple_config()
