"""
TOREloRA v1.1.1 — Setup
TORE TEKNOLOJİ & ARAŞTIRMA — MIT Lisansı
"""
from setuptools import setup, find_packages
from pathlib import Path

# README
long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="torelora",
    version="1.1.1",
    author="Ömür Bera Işık — TORE TEKNOLOJİ & ARAŞTIRMA",
    author_email="info@toretekno.com",
    description=(
        "TOREloRA v1.1.1 — LoRA fine-tuning + "
        "ASGP v3 · CORAP20 · SSYP · OMNISYNC+ · BBGH AGI · ZeroFault v2"
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/toretekno/torelora",
    project_urls={
        "Bug Tracker": "https://github.com/toretekno/torelora/issues",
        "Documentation": "https://github.com/toretekno/torelora#readme",
    },
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "torch>=2.1.0",
        "transformers>=4.40.0",
        "accelerate>=0.27.0",
        "peft>=0.10.0",
        "trl>=0.8.0",
        "datasets>=2.18.0",
        "safetensors>=0.4.0",
        "numpy>=1.24.0",
        "psutil>=5.9.0",
    ],
    extras_require={
        "full": [
            "bitsandbytes>=0.43.0",
            "sentencepiece>=0.1.99",
            "triton",
            "flash-attn",
            "deepspeed",
            "optuna",
            "wandb",
            "tensorboard",
            "matplotlib",
        ],
        "dev": [
            "pytest>=7.0",
            "pytest-cov",
            "black",
            "isort",
            "mypy",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords=[
        "lora", "fine-tuning", "llm", "transformers", "peft",
        "quantization", "training", "deep-learning", "pytorch",
        "torelora", "asgp", "corap20", "ssyp", "omnisync", "bbgh",
    ],
    entry_points={
        "console_scripts": [
            "torelora=torelora.__main__:main",
            "torelora-check=torelora.__main__:check",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
