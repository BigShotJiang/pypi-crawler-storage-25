"""
TOREloRA v1.1.1 — Temel Testler
"""
import pytest
import torch
import torch.nn as nn


# ── Import testleri ────────────────────────────────────────────────────────────

def test_import_version():
    import torelora
    assert torelora.__version__ == "1.1.1"


def test_import_core_classes():
    from torelora import (
        TOREloRA, TOREloRAConfig, FastLoRA, FastLoRAConfig,
        SimpleConfig, ZeroFault, AutoInstaller, DeviceManager,
    )
    assert TOREloRA is not None


def test_import_tech_classes():
    from torelora import (
        ASGPv2, ASGPv3, SSYP, SSYPDataset,
        CORAP20Engine, StreamingCORAP20Loader,
        ParamMesh, OmniSync, BBGHEngine, AGCoreEngine,
    )
    assert ASGPv2 is not None


# ── ZeroFault ─────────────────────────────────────────────────────────────────

def test_zerofault_report_and_reset():
    from torelora import ZeroFault
    ZeroFault.reset_session()
    ZeroFault.report("TEST", "test hatası", "neden", fix="düzelt")
    assert len(ZeroFault._hist) >= 1
    ZeroFault.reset_session()
    assert len(ZeroFault._hist) == 0


def test_zerofault_run_success():
    from torelora import ZeroFault
    result = ZeroFault.run(lambda x, y: x + y, 3, 4, default=-1)
    assert result == 7


def test_zerofault_run_failure():
    from torelora import ZeroFault
    def boom():
        raise ValueError("test patladı")
    result = ZeroFault.run(boom, default="fallback")
    assert result == "fallback"


def test_zerofault_grad_repair():
    from torelora import ZeroFault
    model = nn.Linear(16, 16)
    x = torch.randn(4, 16)
    out = model(x)
    out.sum().backward()
    gnorm = ZeroFault.maybe_repair_gradients(model, prev_norm=None)
    assert gnorm is not None
    assert gnorm >= 0.0


# ── SimpleConfig ──────────────────────────────────────────────────────────────

def test_simple_config_parse():
    from torelora import SimpleConfig
    cfg = SimpleConfig.parse("""
        model_name  meta-llama/Llama-3.2-1B
        ssyp        c/true
        omnisync    c/false
        lora_r      64
        batch_size  8
        epochs      2
    """)
    assert cfg.model_name == "meta-llama/Llama-3.2-1B"
    assert cfg.ssyp is True
    assert cfg.omnisync is False
    assert cfg.lora_r == 64
    assert cfg.per_device_train_batch_size == 8
    assert cfg.num_train_epochs == 2


def test_simple_config_to_text():
    from torelora import SimpleConfig, TOREloRAConfig
    cfg = TOREloRAConfig(lora_r=16)
    txt = SimpleConfig.to_text(cfg)
    assert "lora_r" in txt
    assert "16" in txt


def test_simple_config_aliases():
    from torelora import SimpleConfig
    cfg = SimpleConfig.parse("""
        rank    32
        lr      1e-4
        batch   2
    """)
    assert cfg.lora_r == 32
    assert abs(cfg.learning_rate - 1e-4) < 1e-12
    assert cfg.per_device_train_batch_size == 2


# ── TOREloRAConfig ────────────────────────────────────────────────────────────

def test_config_defaults():
    from torelora import TOREloRAConfig
    cfg = TOREloRAConfig()
    assert cfg.lora_r == 16
    assert cfg.lora is True
    assert cfg.unstoppable is True
    assert cfg.resonance_level >= 0.0


def test_config_agi_core():
    from torelora import TOREloRAConfig
    cfg = TOREloRAConfig(agi_core=True)
    # agi_core → bbgh + omnisync (XLA yoksa)
    try:
        import torch_xla  # noqa
        # XLA varsa bbgh kapalı kalır
    except ImportError:
        assert cfg.bbgh is True
        assert cfg.omnisync is True


def test_config_bbgh_best_mode():
    from torelora import TOREloRAConfig
    cfg = TOREloRAConfig(bbgh_best_mode=True)
    assert cfg.bbgh is True
    assert cfg.bbgh_agi_mode is True
    assert cfg.bbgh_self_consistency >= 5


# ── ASGP v2 ───────────────────────────────────────────────────────────────────

def test_asgp_v2_basic():
    from torelora import ASGPv2
    model = nn.Sequential(nn.Linear(64, 128), nn.ReLU(), nn.Linear(128, 32))
    pipe = ASGPv2(pipe_mb=2., noise=0.01, int8=True, async_bg=False,
                  unique_per_param=True)
    pipe.register_model(model)
    x = torch.randn(4, 64)
    out = model(x)
    out.sum().backward()
    norm = pipe.inject(model)
    assert isinstance(norm, float)
    assert norm >= 0.0
    s = pipe.status()
    assert s["dist"] == "normal"
    pipe.stop()


def test_asgp_v2_unique_offsets():
    from torelora import ASGPv2
    model = nn.Sequential(nn.Linear(32, 64), nn.Linear(64, 16))
    pipe = ASGPv2(pipe_mb=1., noise=0.005, async_bg=False, unique_per_param=True)
    pipe.register_model(model)
    offsets = {n: r["offset"] for n, r in pipe._reg.items()}
    assert len(set(offsets.values())) == len(offsets), "Offsetler benzersiz olmalı"
    pipe.stop()


def test_asgp_v3_basic():
    from torelora import ASGPv3
    model = nn.Linear(16, 16)
    pipe = ASGPv3(pipe_mb=1., noise=0.01, async_bg=False, bg_idle_sleep=0.001)
    s = pipe.status()
    assert s["version"] == "v3"
    pipe.stop()


# ── SSYP ──────────────────────────────────────────────────────────────────────

def test_ssyp_prepare():
    from torelora import SSYP

    class FakeTok:
        eos_token_id = 1
        def encode(self, t, add_special_tokens=True):
            return list(range(min(len(t), 50)))

    dataset = [{"text": f"örnek metin {i} " * 10} for i in range(10)]
    ssyp = SSYP(FakeTok(), max_length=32, async_tokenize=False)
    ds = ssyp.prepare(dataset, cache=False)
    assert len(ds) > 0


def test_ssyp_residue():
    from torelora import SSYP

    class FakeTok:
        eos_token_id = 1
        def encode(self, t, add_special_tokens=True):
            return list(range(min(len(t), 50)))

    ssyp = SSYP(FakeTok(), max_length=32, async_tokenize=False)
    model = nn.Linear(16, 16)
    ssyp.update_residue(model)
    stats = ssyp.residue_stats()
    assert stats["count"] > 0


# ── CORAP20 ───────────────────────────────────────────────────────────────────

def test_corap20_quantize():
    from torelora import CORAP20Engine
    model = nn.Sequential(nn.Linear(128, 256), nn.ReLU(), nn.Linear(256, 64))
    engine = CORAP20Engine(model, block_size=64, gkp_size_mb=1., holographic=False)
    n = engine.quantize_model()
    assert n >= 1
    stats = engine.memory_stats()
    assert stats["saving_pct"] > 0
    # Forward hâlâ çalışmalı
    x = torch.randn(4, 128)
    with torch.no_grad():
        out = model(x)
    assert out.shape == (4, 64)


def test_corap20_dequantize():
    from torelora import CORAP20Engine
    model = nn.Linear(32, 64)
    engine = CORAP20Engine(model, block_size=32, gkp_size_mb=0.5)
    engine.quantize_model()
    # Store'dan bir tensor al ve dequantize et
    if engine._store:
        name = next(iter(engine._store))
        store = engine._store[name]
        w = engine.dequantize_param(store)
        assert isinstance(w, torch.Tensor)
        assert w.numel() > 0


# ── BBGH ──────────────────────────────────────────────────────────────────────

def test_bbgh_learn_query():
    from torelora import BBGHEngine
    bbgh = BBGHEngine(embed_dim=128, max_cells=500)
    texts = [
        "Python 1991'de oluşturuldu.",
        "Yapay zeka insan zekasını taklit eder.",
        "TOREloRA hızlı fine-tuning için tasarlanmıştır.",
    ]
    n = bbgh.batch_learn(texts)
    assert n == len(texts)
    assert bbgh.stats["cells"] == len(texts)


def test_bbgh_generate():
    from torelora import BBGHEngine
    bbgh = BBGHEngine(embed_dim=128, max_cells=500)
    bbgh.batch_learn(["Python programlama dili."])
    out = bbgh.generate("Python")
    assert isinstance(out, str)
    assert len(out) > 0


def test_bbgh_reason():
    from torelora import BBGHEngine
    bbgh = BBGHEngine(embed_dim=128, max_cells=500)
    bbgh.batch_learn([
        "A → B nedeni var.",
        "B → C nedeni var.",
    ])
    r = bbgh.reason("A nedeni ne?", hops=3)
    assert "conclusion" in r
    assert "confidence" in r


# ── OmniSync ──────────────────────────────────────────────────────────────────

def test_omnisync_absorb_snap():
    from torelora import OmniSync
    model = nn.Sequential(nn.Linear(32, 64), nn.ReLU(), nn.Linear(64, 16))
    omni = OmniSync(model)
    tokens = torch.randint(0, 1000, (2, 32))
    omni.absorb(tokens)
    snap = omni.snap()
    assert snap is not None
    omni.stop()


# ── AGCoreEngine ──────────────────────────────────────────────────────────────

def test_agcore_run():
    from torelora import AGCoreEngine
    ag = AGCoreEngine()
    ag.perceive({"x": 0.0, "y": 0.0})
    ag.set_goal({"x": 1.0})
    result = ag.run(cycles=3)
    assert result["enabled"] is True
    assert result["cycles"] >= 1


def test_agcore_readiness():
    from torelora import AGCoreEngine
    ag = AGCoreEngine()
    r = ag.readiness_report()
    assert r["is_true_agi"] is False
    assert r["components"]["symbolic_world_model"] is True


# ── DeviceManager ─────────────────────────────────────────────────────────────

def test_device_manager():
    from torelora import DeviceManager
    dm = DeviceManager()
    assert dm.device is not None
    assert isinstance(dm.get_vram_gb(), float)


# ── AutoInstaller ─────────────────────────────────────────────────────────────

def test_auto_installer_known_pkg():
    from torelora import AutoInstaller
    # torch zaten kurulu olmalı
    ok = AutoInstaller.ensure("torch")
    assert ok is True


def test_auto_installer_bad_pkg():
    from torelora import AutoInstaller
    ok = AutoInstaller.ensure("__torelora_nonexistent_pkg_xyz__")
    assert ok is False
