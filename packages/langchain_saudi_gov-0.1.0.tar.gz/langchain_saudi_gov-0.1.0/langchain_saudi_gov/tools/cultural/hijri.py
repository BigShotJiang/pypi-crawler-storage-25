"""Hijri/Gregorian date conversion — Aladhan API.

The Hijri calendar is the official calendar used in Saudi Arabia for
government, religious, and civil purposes. No auth required.
"""

from typing import Type

import httpx
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

ALADHAN_BASE = "https://api.aladhan.com/v1"


class HijriDateInput(BaseModel):
    date: str = Field(
        description="Date in DD-MM-YYYY format. Gregorian for to_hijri=True, Hijri for to_hijri=False."
    )
    to_hijri: bool = Field(default=True, description="True: Gregorian→Hijri. False: Hijri→Gregorian.")


class HijriDateTool(BaseTool):
    """Convert dates between Gregorian and Hijri (Islamic) calendars.

    The Hijri calendar is official in Saudi Arabia for government and
    civil purposes. No authentication required.

    See: https://aladhan.com/prayer-times-api

    Example:
        ```python
        from langchain_saudi_gov.tools.cultural import HijriDateTool

        tool = HijriDateTool()
        result = tool.invoke({"date": "25-12-2024", "to_hijri": True})
        ```
    """

    name: str = "hijri_date_converter"
    description: str = (
        "Convert dates between Gregorian and Hijri (Islamic) calendars. "
        "The Hijri calendar is official in Saudi Arabia. No API key required."
    )
    args_schema: Type[BaseModel] = HijriDateInput
    base_url: str = ALADHAN_BASE

    def _run(self, date: str, to_hijri: bool = True) -> str:
        endpoint = "gToH" if to_hijri else "hToG"
        try:
            resp = httpx.get(f"{self.base_url}/{endpoint}/{date}", timeout=10)
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as e:
            return f"Hijri conversion error: {e}"
        return self._format(data, to_hijri)

    async def _arun(self, date: str, to_hijri: bool = True) -> str:
        endpoint = "gToH" if to_hijri else "hToG"
        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(f"{self.base_url}/{endpoint}/{date}", timeout=10)
                resp.raise_for_status()
                data = resp.json()
            except httpx.HTTPError as e:
                return f"Hijri conversion error: {e}"
        return self._format(data, to_hijri)

    def _format(self, data: dict, to_hijri: bool) -> str:
        if data.get("code") != 200:
            return f"Conversion error: {data.get('status', 'unknown error')}"
        result = data.get("data", {})
        hijri = result.get("hijri", {})
        gregorian = result.get("gregorian", {})
        hijri_str = f"{hijri.get('day', '')} {hijri.get('month', {}).get('en', '')} {hijri.get('year', '')} AH"
        hijri_ar = f"{hijri.get('day', '')} {hijri.get('month', {}).get('ar', '')} {hijri.get('year', '')} هـ"
        greg_str = f"{gregorian.get('day', '')} {gregorian.get('month', {}).get('en', '')} {gregorian.get('year', '')} AD"
        if to_hijri:
            return f"Gregorian: {greg_str}\nHijri: {hijri_str}\nهجري: {hijri_ar}"
        else:
            return f"Hijri: {hijri_str}\nهجري: {hijri_ar}\nGregorian: {greg_str}"
