"""Prayer times for Saudi cities — Aladhan API.

Uses the Umm al-Qura University, Makkah calculation method (method=4),
the official standard used in Saudi Arabia. No auth required.
"""

from typing import Optional, Type

import httpx
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

ALADHAN_BASE = "https://api.aladhan.com/v1"
UMM_AL_QURA_METHOD = 4


class PrayerTimesInput(BaseModel):
    city: str = Field(description="City name in Saudi Arabia, e.g. 'Riyadh', 'Jeddah', 'الرياض'")
    date: Optional[str] = Field(default=None, description="Date in DD-MM-YYYY format. Defaults to today.")


class PrayerTimesTool(BaseTool):
    """Get Islamic prayer times for Saudi Arabian cities.

    Uses the Umm al-Qura University calculation method (the official
    Saudi standard). Returns Fajr, Sunrise, Dhuhr, Asr, Maghrib,
    and Isha times with Hijri date. No authentication required.

    See: https://aladhan.com/prayer-times-api

    Example:
        ```python
        from langchain_saudi_gov.tools.cultural import PrayerTimesTool

        tool = PrayerTimesTool()
        result = tool.invoke({"city": "Riyadh"})
        ```
    """

    name: str = "saudi_prayer_times"
    description: str = (
        "Get Islamic prayer times (Fajr, Sunrise, Dhuhr, Asr, Maghrib, Isha) "
        "for a Saudi city. Uses the official Umm al-Qura method. No API key required."
    )
    args_schema: Type[BaseModel] = PrayerTimesInput
    base_url: str = ALADHAN_BASE

    def _run(self, city: str, date: Optional[str] = None) -> str:
        params: dict = {"city": city, "country": "Saudi Arabia", "method": UMM_AL_QURA_METHOD}
        url = f"{self.base_url}/timingsByCity"
        if date:
            url = f"{self.base_url}/timingsByCity/{date}"
        try:
            resp = httpx.get(url, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as e:
            return f"Prayer times API error: {e}"
        return self._format(data, city)

    async def _arun(self, city: str, date: Optional[str] = None) -> str:
        params: dict = {"city": city, "country": "Saudi Arabia", "method": UMM_AL_QURA_METHOD}
        url = f"{self.base_url}/timingsByCity"
        if date:
            url = f"{self.base_url}/timingsByCity/{date}"
        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(url, params=params, timeout=10)
                resp.raise_for_status()
                data = resp.json()
            except httpx.HTTPError as e:
                return f"Prayer times API error: {e}"
        return self._format(data, city)

    def _format(self, data: dict, city: str) -> str:
        if data.get("code") != 200:
            return f"Prayer times error: {data.get('status', 'unknown error')}"
        result = data.get("data", {})
        timings = result.get("timings", {})
        date_info = result.get("date", {})
        hijri = date_info.get("hijri", {})
        hijri_date = f"{hijri.get('day', '')} {hijri.get('month', {}).get('en', '')} {hijri.get('year', '')}"
        return "\n".join([
            f"Prayer times for {city} — {date_info.get('readable', '')} ({hijri_date})",
            f"  Fajr:    {timings.get('Fajr', 'N/A')}",
            f"  Sunrise: {timings.get('Sunrise', 'N/A')}",
            f"  Dhuhr:   {timings.get('Dhuhr', 'N/A')}",
            f"  Asr:     {timings.get('Asr', 'N/A')}",
            f"  Maghrib: {timings.get('Maghrib', 'N/A')}",
            f"  Isha:    {timings.get('Isha', 'N/A')}",
        ])
