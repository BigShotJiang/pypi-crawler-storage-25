"""Balady (Ministry of Municipalities) municipal data tool.

Open data on building permits, municipal services, urban planning
zones, and infrastructure. Data sourced via data.gov.sa CKAN API.
No authentication required.
"""

from typing import Optional, Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool, CKANSearchInput


class BaladySearchInput(BaseModel):
    """Input for Balady municipal data search."""

    query: str = Field(
        description="Search term for municipal data: building permits, urban zones, infrastructure"
    )
    rows: int = Field(default=5, description="Number of results (1-20)")


class BaladyMunicipalTool(CKANBaseTool):
    """Search Balady (Ministry of Municipalities) open data.

    Provides building permits, municipal services, urban planning zones,
    and infrastructure data by region. Useful for real-estate,
    construction, and urban planning agents.

    See: https://balady.gov.sa | https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.location import BaladyMunicipalTool

        tool = BaladyMunicipalTool()
        result = tool.invoke({"query": "building permits Riyadh"})
        ```
    """

    name: str = "saudi_balady_municipal"
    description: str = (
        "Search Balady municipal open data: building permits, urban planning zones, "
        "infrastructure, and municipal services across Saudi regions. No API key required."
    )
    args_schema: Type[BaseModel] = BaladySearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "Balady (Municipal)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:balady")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows, fq="organization:balady")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
