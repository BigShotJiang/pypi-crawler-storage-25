"""National Address API tools — Saudi Post / SPL.

Base URL: https://apina.address.gov.sa/NationalAddress/v4
Auth: Free API key from api.address.gov.sa
"""

from typing import Optional, Type

import httpx
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from langchain_saudi_gov.utils.arabic import detect_language

NATIONAL_ADDRESS_BASE = "https://apina.address.gov.sa/NationalAddress/v4"


class AddressSearchInput(BaseModel):
    """Input for National Address free-text search."""

    query: str = Field(description="Address text to search, in Arabic or English")
    language: Optional[str] = Field(
        default=None,
        description="'A' for Arabic, 'E' for English. Auto-detected if omitted.",
    )
    page: int = Field(default=1, description="Page number for paginated results")


class NationalAddressSearchTool(BaseTool):
    """Search the Saudi National Address database by free text.

    Wraps the Saudi Post / SPL National Address API. Returns structured
    address records including building number, street, district, city,
    postcode, and GPS coordinates.

    See: https://api.address.gov.sa

    Args:
        api_key: National Address API key (free at api.address.gov.sa).

    Example:
        ```python
        from langchain_saudi_gov.tools.location import NationalAddressSearchTool

        tool = NationalAddressSearchTool(api_key="your-key")
        result = tool.invoke({"query": "مطار الملك عبدالعزيز جدة"})
        ```
    """

    name: str = "saudi_address_search"
    description: str = (
        "Search for a Saudi address by free text in Arabic or English. "
        "Returns building number, street, district, city, postcode, and GPS coordinates."
    )
    args_schema: Type[BaseModel] = AddressSearchInput
    api_key: str

    def _run(self, query: str, language: Optional[str] = None, page: int = 1) -> str:
        if language is None:
            language = detect_language(query)
        params = {
            "language": language,
            "format": "JSON",
            "page": page,
            "addressstring": query,
            "api_key": self.api_key,
        }
        try:
            resp = httpx.get(
                f"{NATIONAL_ADDRESS_BASE}/address/address-free-text",
                params=params,
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as e:
            return f"Address API error: {e}"
        return self._format(data)

    async def _arun(self, query: str, language: Optional[str] = None, page: int = 1) -> str:
        if language is None:
            language = detect_language(query)
        params = {
            "language": language,
            "format": "JSON",
            "page": page,
            "addressstring": query,
            "api_key": self.api_key,
        }
        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(
                    f"{NATIONAL_ADDRESS_BASE}/address/address-free-text",
                    params=params,
                    timeout=10,
                )
                resp.raise_for_status()
                data = resp.json()
            except httpx.HTTPError as e:
                return f"Address API error: {e}"
        return self._format(data)

    def _format(self, data: dict) -> str:
        if not data.get("success"):
            return f"No results: {data.get('statusdescription', 'unknown error')}"
        addresses = data.get("Addresses", [])
        if not addresses:
            return "No addresses found."
        results = []
        for addr in addresses[:5]:
            parts = [
                addr.get("Address1", ""),
                addr.get("Address2", ""),
                f"City: {addr.get('City', '')}",
                f"PostCode: {addr.get('PostCode', '')}",
                f"Building: {addr.get('BuildingNumber', '')}",
                f"GPS: {addr.get('Latitude', '')},{addr.get('Longitude', '')}",
            ]
            results.append(" | ".join(p for p in parts if p))
        return "\n".join(results)


class ReverseGeocodeInput(BaseModel):
    """Input for reverse geocoding."""

    lat: float = Field(description="Latitude coordinate")
    lng: float = Field(description="Longitude coordinate")
    language: str = Field(default="A", description="'A' for Arabic, 'E' for English")


class NationalAddressReverseGeocodeTool(BaseTool):
    """Convert GPS coordinates to a Saudi national address.

    See: https://api.address.gov.sa

    Args:
        api_key: National Address API key (free at api.address.gov.sa).

    Example:
        ```python
        from langchain_saudi_gov.tools.location import NationalAddressReverseGeocodeTool

        tool = NationalAddressReverseGeocodeTool(api_key="your-key")
        result = tool.invoke({"lat": 24.7136, "lng": 46.6753})
        ```
    """

    name: str = "saudi_reverse_geocode"
    description: str = (
        "Convert GPS latitude/longitude to a Saudi national address. "
        "Returns building number, street, district, city, and postcode."
    )
    args_schema: Type[BaseModel] = ReverseGeocodeInput
    api_key: str

    def _run(self, lat: float, lng: float, language: str = "A") -> str:
        params = {
            "lat": lat, "long": lng, "language": language,
            "format": "JSON", "api_key": self.api_key,
        }
        try:
            resp = httpx.get(f"{NATIONAL_ADDRESS_BASE}/address/geocode", params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as e:
            return f"Reverse geocode error: {e}"
        addresses = data.get("Addresses", [])
        if not addresses:
            return "No address found for these coordinates."
        a = addresses[0]
        return (
            f"{a.get('Address1', '')} | {a.get('Address2', '')} | "
            f"City: {a.get('City', '')} | PostCode: {a.get('PostCode', '')}"
        )

    async def _arun(self, lat: float, lng: float, language: str = "A") -> str:
        params = {
            "lat": lat, "long": lng, "language": language,
            "format": "JSON", "api_key": self.api_key,
        }
        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(
                    f"{NATIONAL_ADDRESS_BASE}/address/geocode", params=params, timeout=10,
                )
                resp.raise_for_status()
                data = resp.json()
            except httpx.HTTPError as e:
                return f"Reverse geocode error: {e}"
        addresses = data.get("Addresses", [])
        if not addresses:
            return "No address found for these coordinates."
        a = addresses[0]
        return (
            f"{a.get('Address1', '')} | {a.get('Address2', '')} | "
            f"City: {a.get('City', '')} | PostCode: {a.get('PostCode', '')}"
        )
