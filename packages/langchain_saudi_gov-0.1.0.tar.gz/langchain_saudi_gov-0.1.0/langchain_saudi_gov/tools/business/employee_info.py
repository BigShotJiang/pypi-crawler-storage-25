"""Employee information via Wathq — GOSI / MASDR (API 18)."""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import WathqBaseTool


class EmployeeInput(BaseModel):
    """Input for employee information lookup."""

    id_number: str = Field(description="Employee national ID or Iqama number")


class EmployeeInfoTool(WathqBaseTool):
    """Look up Saudi employee information via Wathq GOSI/MASDR API.

    Returns employment status, employer, wages, and GOSI subscription data.
    Useful for HR compliance and employment verification agents.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.business import EmployeeInfoTool

        tool = EmployeeInfoTool(api_key="your-wathq-key")
        result = tool.invoke({"id_number": "1xxxxxxxxx"})
        ```
    """

    name: str = "saudi_employee_info"
    description: str = (
        "Look up Saudi employee information by national ID. Returns employment "
        "status, employer name, wages, and GOSI data. For HR compliance checks."
    )
    args_schema: Type[BaseModel] = EmployeeInput

    def _run(self, id_number: str) -> str:
        try:
            data = self._wathq_get(f"/v5/employee/info/{id_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    async def _arun(self, id_number: str) -> str:
        try:
            data = await self._wathq_aget(f"/v5/employee/info/{id_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    def _format(self, data: dict) -> str:
        return "\n".join([
            f"Name: {data.get('employeeName', 'N/A')}",
            f"Employment status: {data.get('employmentStatus', 'N/A')}",
            f"Employer: {data.get('employerName', 'N/A')}",
            f"Wage: {data.get('wage', 'N/A')} SAR",
            f"GOSI subscribed: {data.get('gosiSubscribed', 'N/A')}",
            f"Sector: {data.get('sector', 'N/A')}",
        ])
