"""Corporate identity lookup via Wathq — API 11."""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import WathqBaseTool


class CorporateIdInput(BaseModel):
    """Input for corporate identity lookup."""

    entity_number: str = Field(description="Saudi entity/700 number (رقم المنشأة)")


class CorporateIdentityTool(WathqBaseTool):
    """Look up Saudi corporate identity via Wathq.

    Returns entity details, legal structure, and linked registrations.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.business import CorporateIdentityTool

        tool = CorporateIdentityTool(api_key="your-wathq-key")
        result = tool.invoke({"entity_number": "7001234567"})
        ```
    """

    name: str = "saudi_corporate_identity"
    description: str = (
        "Look up Saudi corporate identity by entity (700) number. "
        "Returns entity name, legal structure, and linked commercial registrations."
    )
    args_schema: Type[BaseModel] = CorporateIdInput

    def _run(self, entity_number: str) -> str:
        try:
            data = self._wathq_get(f"/v5/corporate/identity/{entity_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    async def _arun(self, entity_number: str) -> str:
        try:
            data = await self._wathq_aget(f"/v5/corporate/identity/{entity_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    def _format(self, data: dict) -> str:
        return "\n".join([
            f"Entity name: {data.get('entityName', 'N/A')}",
            f"Entity number: {data.get('entityNumber', 'N/A')}",
            f"Legal structure: {data.get('legalStructure', 'N/A')}",
            f"Status: {data.get('status', 'N/A')}",
            f"City: {data.get('city', 'N/A')}",
            f"Linked CRs: {data.get('linkedCRCount', 'N/A')}",
        ])
