"""Financial statements lookup via Wathq — API 12."""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import WathqBaseTool


class FinancialInput(BaseModel):
    """Input for financial statements lookup."""

    cr_number: str = Field(description="Commercial registration number")


class FinancialStatementsTool(WathqBaseTool):
    """Fetch Saudi company financial statements summary via Wathq.

    Returns filed financial data including revenue, assets, liabilities,
    and fiscal year information.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.business import FinancialStatementsTool

        tool = FinancialStatementsTool(api_key="your-wathq-key")
        result = tool.invoke({"cr_number": "1010123456"})
        ```
    """

    name: str = "saudi_financial_statements"
    description: str = (
        "Fetch a Saudi company's financial statements summary by CR number. "
        "Returns revenue, assets, liabilities, and fiscal year data."
    )
    args_schema: Type[BaseModel] = FinancialInput

    def _run(self, cr_number: str) -> str:
        try:
            data = self._wathq_get(f"/v5/financialstatements/info/{cr_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    async def _arun(self, cr_number: str) -> str:
        try:
            data = await self._wathq_aget(f"/v5/financialstatements/info/{cr_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    def _format(self, data: dict) -> str:
        return "\n".join([
            f"Company: {data.get('companyName', 'N/A')}",
            f"Fiscal year: {data.get('fiscalYear', 'N/A')}",
            f"Revenue: {data.get('revenue', 'N/A')} SAR",
            f"Net income: {data.get('netIncome', 'N/A')} SAR",
            f"Total assets: {data.get('totalAssets', 'N/A')} SAR",
            f"Total liabilities: {data.get('totalLiabilities', 'N/A')} SAR",
            f"Filing date: {data.get('filingDate', 'N/A')}",
        ])
