"""Real estate deeds lookup via Wathq — Ministry of Justice.

Query ownership deeds data. Wathq API 13.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import WathqBaseTool


class DeedInput(BaseModel):
    """Input for real estate deed lookup."""

    deed_number: str = Field(description="Real estate deed number (صك عقاري)")
    identity_number: str = Field(description="Owner's national ID or Iqama number")


class RealEstateDeedTool(WathqBaseTool):
    """Verify Saudi real estate ownership deeds via Wathq.

    Queries Ministry of Justice deed records to verify property ownership,
    deed status, and property details.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.business import RealEstateDeedTool

        tool = RealEstateDeedTool(api_key="your-wathq-key")
        result = tool.invoke({"deed_number": "310100123", "identity_number": "1xxxxxxxxx"})
        ```
    """

    name: str = "saudi_real_estate_deed"
    description: str = (
        "Verify a Saudi real estate ownership deed. Returns property details, "
        "ownership status, and deed validity from Ministry of Justice records."
    )
    args_schema: Type[BaseModel] = DeedInput

    def _run(self, deed_number: str, identity_number: str) -> str:
        try:
            data = self._wathq_get(
                f"/v5/realestate/deed/{deed_number}",
                params={"identityNumber": identity_number},
            )
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    async def _arun(self, deed_number: str, identity_number: str) -> str:
        try:
            data = await self._wathq_aget(
                f"/v5/realestate/deed/{deed_number}",
                params={"identityNumber": identity_number},
            )
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    def _format(self, data: dict) -> str:
        parts = [
            f"Deed number: {data.get('deedNumber', 'N/A')}",
            f"Status: {data.get('deedStatus', 'N/A')}",
            f"Property type: {data.get('propertyType', 'N/A')}",
            f"City: {data.get('city', 'N/A')}",
            f"District: {data.get('district', 'N/A')}",
            f"Area (sqm): {data.get('area', 'N/A')}",
            f"Issue date: {data.get('issueDate', 'N/A')}",
        ]
        owners = data.get("owners", [])
        if owners:
            for o in owners[:5]:
                parts.append(f"  Owner: {o.get('name', 'N/A')} — Share: {o.get('share', 'N/A')}")
        return "\n".join(parts)
