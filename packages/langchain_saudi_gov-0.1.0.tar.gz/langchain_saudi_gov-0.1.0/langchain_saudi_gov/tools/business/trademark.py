"""Trademark lookup via Wathq — API 10."""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import WathqBaseTool


class TrademarkInput(BaseModel):
    """Input for trademark lookup."""

    trademark_number: str = Field(description="Saudi trademark registration number")


class TrademarkLookupTool(WathqBaseTool):
    """Look up a Saudi trademark registration via Wathq.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.business import TrademarkLookupTool

        tool = TrademarkLookupTool(api_key="your-wathq-key")
        result = tool.invoke({"trademark_number": "1443012345"})
        ```
    """

    name: str = "saudi_trademark_lookup"
    description: str = (
        "Look up a Saudi trademark registration by number. "
        "Returns trademark name, status, owner, classes, and validity dates."
    )
    args_schema: Type[BaseModel] = TrademarkInput

    def _run(self, trademark_number: str) -> str:
        try:
            data = self._wathq_get(f"/v5/trademark/info/{trademark_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    async def _arun(self, trademark_number: str) -> str:
        try:
            data = await self._wathq_aget(f"/v5/trademark/info/{trademark_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    def _format(self, data: dict) -> str:
        return "\n".join([
            f"Trademark: {data.get('trademarkName', 'N/A')}",
            f"Status: {data.get('status', 'N/A')}",
            f"Owner: {data.get('ownerName', 'N/A')}",
            f"Class: {data.get('trademarkClass', 'N/A')}",
            f"Filing date: {data.get('filingDate', 'N/A')}",
            f"Expiry date: {data.get('expiryDate', 'N/A')}",
        ])
