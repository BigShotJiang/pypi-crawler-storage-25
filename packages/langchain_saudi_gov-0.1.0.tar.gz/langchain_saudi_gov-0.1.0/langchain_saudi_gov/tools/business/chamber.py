"""Chamber of Commerce verification via Wathq — API 15."""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import WathqBaseTool


class ChamberInput(BaseModel):
    """Input for chamber membership verification."""

    cr_number: str = Field(description="Commercial registration number to verify")


class ChamberVerificationTool(WathqBaseTool):
    """Verify Saudi Chamber of Commerce membership via Wathq.

    Checks chamber membership and subscription status for supplier
    verification and procurement workflows.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.business import ChamberVerificationTool

        tool = ChamberVerificationTool(api_key="your-wathq-key")
        result = tool.invoke({"cr_number": "1010123456"})
        ```
    """

    name: str = "saudi_chamber_verification"
    description: str = (
        "Verify a Saudi company's Chamber of Commerce membership and subscription "
        "status by CR number. Useful for supplier verification and procurement."
    )
    args_schema: Type[BaseModel] = ChamberInput

    def _run(self, cr_number: str) -> str:
        try:
            data = self._wathq_get(f"/v5/chamber/membership/{cr_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    async def _arun(self, cr_number: str) -> str:
        try:
            data = await self._wathq_aget(f"/v5/chamber/membership/{cr_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    def _format(self, data: dict) -> str:
        return "\n".join([
            f"Company: {data.get('companyName', 'N/A')}",
            f"Chamber: {data.get('chamberName', 'N/A')}",
            f"Membership status: {data.get('membershipStatus', 'N/A')}",
            f"Subscription expiry: {data.get('subscriptionExpiry', 'N/A')}",
            f"Membership number: {data.get('membershipNumber', 'N/A')}",
        ])
