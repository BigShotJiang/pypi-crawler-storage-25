"""Commercial contract / articles of association via Wathq.

Fetch company articles of association, manager authorities, and signing
rights. Wathq APIs 34 & 35 (new legislation).
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import WathqBaseTool


class ContractInput(BaseModel):
    """Input for commercial contract lookup."""

    cr_number: str = Field(description="Commercial registration number")


class CommercialContractTool(WathqBaseTool):
    """Fetch Saudi company articles of association via Wathq.

    Returns manager authorities, signing rights, and partnership details.
    Useful for legal due diligence agents.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.business import CommercialContractTool

        tool = CommercialContractTool(api_key="your-wathq-key")
        result = tool.invoke({"cr_number": "1010123456"})
        ```
    """

    name: str = "saudi_commercial_contract"
    description: str = (
        "Fetch a Saudi company's articles of association and commercial contract. "
        "Returns manager authorities, signing rights, and partnership structure."
    )
    args_schema: Type[BaseModel] = ContractInput

    def _run(self, cr_number: str) -> str:
        try:
            data = self._wathq_get(f"/v5/commercialregistration/contract/{cr_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    async def _arun(self, cr_number: str) -> str:
        try:
            data = await self._wathq_aget(f"/v5/commercialregistration/contract/{cr_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    def _format(self, data: dict) -> str:
        parts = [
            f"Company: {data.get('companyName', 'N/A')}",
            f"Contract type: {data.get('contractType', 'N/A')}",
            f"Contract date: {data.get('contractDate', 'N/A')}",
        ]
        managers = data.get("managers", [])
        if managers:
            for m in managers[:5]:
                parts.append(f"  Manager: {m.get('name', 'N/A')} — {m.get('authority', 'N/A')}")
        partners = data.get("partners", [])
        if partners:
            for p in partners[:5]:
                parts.append(f"  Partner: {p.get('name', 'N/A')} — Share: {p.get('share', 'N/A')}")
        return "\n".join(parts)
