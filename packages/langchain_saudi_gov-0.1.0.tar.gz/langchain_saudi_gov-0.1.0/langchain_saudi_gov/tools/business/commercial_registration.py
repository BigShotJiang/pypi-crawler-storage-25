"""Commercial Registration lookup via Wathq — Ministry of Commerce.

Query any Saudi CR number to get trade name, status, capital, owners,
managers, and registration dates. Supports both old and new legislation APIs.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import WathqBaseTool


class CRInput(BaseModel):
    """Input for commercial registration lookup."""

    cr_number: str = Field(description="Saudi commercial registration number (السجل التجاري)")


class CommercialRegistrationTool(WathqBaseTool):
    """Look up a Saudi commercial registration record.

    Returns trade name, status, capital, owners, managers, issue date,
    and business activities for any Saudi CR number.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.business import CommercialRegistrationTool

        tool = CommercialRegistrationTool(api_key="your-wathq-key")
        result = tool.invoke({"cr_number": "1010123456"})
        ```
    """

    name: str = "saudi_commercial_registration"
    description: str = (
        "Look up a Saudi company's commercial registration (CR) by number. "
        "Returns trade name, status, capital, owners, managers, and activities."
    )
    args_schema: Type[BaseModel] = CRInput

    def _run(self, cr_number: str) -> str:
        try:
            data = self._wathq_get(f"/v5/commercialregistration/info/{cr_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    async def _arun(self, cr_number: str) -> str:
        try:
            data = await self._wathq_aget(f"/v5/commercialregistration/info/{cr_number}")
        except Exception as e:
            return self._handle_wathq_error(e)
        return self._format(data)

    def _format(self, data: dict) -> str:
        parts = [
            f"Trade name: {data.get('crName', 'N/A')}",
            f"Status: {data.get('status', {}).get('name', data.get('crStatus', 'N/A'))}",
            f"Capital: {data.get('capital', 'N/A')} SAR",
            f"Issue date: {data.get('issueDate', 'N/A')}",
            f"Expiry date: {data.get('expiryDate', 'N/A')}",
            f"City: {data.get('location', {}).get('name', data.get('crCity', 'N/A'))}",
            f"Business type: {data.get('businessType', {}).get('name', 'N/A')}",
        ]
        activities = data.get("activities", [])
        if activities:
            parts.append(f"Activities: {', '.join(a.get('name', '') for a in activities[:5])}")
        return "\n".join(parts)
