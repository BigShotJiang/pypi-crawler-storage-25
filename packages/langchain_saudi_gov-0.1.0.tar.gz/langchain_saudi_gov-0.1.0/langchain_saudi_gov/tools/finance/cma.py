"""CMA (Capital Market Authority) financial market data.

Portal: opendata.cma.org.sa — listed companies, stock stats, fund data.
No authentication required.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class CMASearchInput(BaseModel):
    """Input for CMA financial data search."""

    query: str = Field(description="Search term: listed companies, stock data, mutual funds, regulatory filings")
    rows: int = Field(default=5, description="Number of results (1-20)")


class CMAFinancialDataTool(CKANBaseTool):
    """Search CMA (Capital Market Authority) financial market data.

    Provides listed company data, Tadawul stock statistics, mutual fund
    data, and regulatory filings. Useful for financial research agents.

    See: https://opendata.cma.org.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.finance import CMAFinancialDataTool

        tool = CMAFinancialDataTool()
        result = tool.invoke({"query": "listed companies financial reports"})
        ```
    """

    name: str = "saudi_cma_financial_data"
    description: str = (
        "Search CMA (Capital Market Authority) open data for Saudi stock market "
        "statistics, listed companies, mutual funds, and regulatory filings. No API key required."
    )
    args_schema: Type[BaseModel] = CMASearchInput
    base_url: str = "https://opendata.cma.org.sa/api/3/action"
    portal_name: str = "CMA (Capital Market)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows)
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows)
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
