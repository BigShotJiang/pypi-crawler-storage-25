"""Etimad government procurement and tenders data.

Portal: portal.etimad.sa — government tenders, awarded contracts.
Data available via Saudi Open Data Portal. No auth for search.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class EtimadSearchInput(BaseModel):
    """Input for Etimad procurement data search."""

    query: str = Field(description="Search term: tenders, procurement, government contracts")
    rows: int = Field(default=5, description="Number of results (1-20)")


class EtimadProcurementTool(CKANBaseTool):
    """Search Etimad government procurement and tenders data.

    Covers active government tenders, awarded contracts, and supplier data
    from the National Centre for Government Resource Systems.
    Useful for B2G agents.

    See: https://portal.etimad.sa | https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.finance import EtimadProcurementTool

        tool = EtimadProcurementTool()
        result = tool.invoke({"query": "IT infrastructure tenders 2024"})
        ```
    """

    name: str = "saudi_etimad_procurement"
    description: str = (
        "Search Etimad government procurement data for active tenders, "
        "awarded contracts, and supplier information. Useful for B2G workflows. No API key required."
    )
    args_schema: Type[BaseModel] = EtimadSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "Etimad (Procurement)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:etimad")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows, fq="organization:etimad")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
