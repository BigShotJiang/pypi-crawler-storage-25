"""ZATCA (Zakat, Tax and Customs Authority) open data.

Portal: data.zatca.gov.sa — CKAN-based, no auth required.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class ZATCASearchInput(BaseModel):
    """Input for ZATCA dataset search."""

    query: str = Field(description="Search term: VAT, customs, zakat, tax statistics")
    rows: int = Field(default=5, description="Number of results (1-20)")


class ZATCAOpenDataTool(CKANBaseTool):
    """Search ZATCA open data portal for tax and customs datasets.

    Covers zakat, VAT rates, customs tariff data, e-invoicing guidance,
    and trade statistics. No authentication required.

    See: https://data.zatca.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.finance import ZATCAOpenDataTool

        tool = ZATCAOpenDataTool()
        result = tool.invoke({"query": "VAT statistics 2024"})
        ```
    """

    name: str = "saudi_zatca_open_data"
    description: str = (
        "Search ZATCA (Saudi tax authority) open data for datasets on "
        "zakat, VAT, customs tariffs, e-invoicing, and trade statistics. No API key required."
    )
    args_schema: Type[BaseModel] = ZATCASearchInput
    base_url: str = "https://data.zatca.gov.sa/api/3/action"
    portal_name: str = "ZATCA"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows)
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows)
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
