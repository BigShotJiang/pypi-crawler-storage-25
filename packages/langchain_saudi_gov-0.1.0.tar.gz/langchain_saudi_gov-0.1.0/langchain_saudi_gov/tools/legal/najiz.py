"""Najiz judicial verification APIs — Ministry of Justice.

Launched June 2025. Unified developer portal for judicial services
including marriage contracts, title deeds, judicial licenses, and
power of attorney verification.
Portal: developers.najiz.sa
"""

from typing import Type

import httpx
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class NajizInput(BaseModel):
    """Input for Najiz judicial document verification."""

    document_number: str = Field(description="Judicial document number to verify")
    document_type: str = Field(
        default="deed",
        description="Document type: 'deed', 'power_of_attorney', 'marriage', or 'license'",
    )
    identity_number: str = Field(
        default="", description="Related party's national ID (optional for some queries)"
    )


class NajizVerificationTool(BaseTool):
    """Verify Saudi judicial documents via Najiz developer platform.

    Supports verification of real estate title deeds, power of attorney,
    marriage contracts, and judicial licenses via the Ministry of Justice.

    See: https://developers.najiz.sa

    Args:
        api_key: Najiz developer API key from developers.najiz.sa.

    Example:
        ```python
        from langchain_saudi_gov.tools.legal import NajizVerificationTool

        tool = NajizVerificationTool(api_key="your-najiz-key")
        result = tool.invoke({"document_number": "3101xxxxx", "document_type": "deed"})
        ```
    """

    name: str = "saudi_najiz_verification"
    description: str = (
        "Verify Saudi judicial documents via Najiz (Ministry of Justice). "
        "Supports title deeds, power of attorney, marriage contracts, and judicial licenses."
    )
    args_schema: Type[BaseModel] = NajizInput
    api_key: str
    base_url: str = "https://api.developers.najiz.sa/v1"

    _DOC_TYPE_MAP = {
        "deed": "realestate/deed",
        "power_of_attorney": "poa/verify",
        "marriage": "marriage/verify",
        "license": "license/verify",
    }

    def _run(self, document_number: str, document_type: str = "deed", identity_number: str = "") -> str:
        path = self._DOC_TYPE_MAP.get(document_type)
        if not path:
            return f"Unknown document type: {document_type}. Use: deed, power_of_attorney, marriage, license"
        headers = {"apiKey": self.api_key, "Accept": "application/json"}
        params = {"documentNumber": document_number}
        if identity_number:
            params["identityNumber"] = identity_number
        try:
            resp = httpx.get(f"{self.base_url}/{path}", headers=headers, params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPStatusError as e:
            return f"Najiz API error ({e.response.status_code}): {e.response.text[:200]}"
        except httpx.HTTPError as e:
            return f"Najiz API error: {e}"
        return self._format(data, document_type)

    async def _arun(self, document_number: str, document_type: str = "deed", identity_number: str = "") -> str:
        path = self._DOC_TYPE_MAP.get(document_type)
        if not path:
            return f"Unknown document type: {document_type}"
        headers = {"apiKey": self.api_key, "Accept": "application/json"}
        params = {"documentNumber": document_number}
        if identity_number:
            params["identityNumber"] = identity_number
        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(f"{self.base_url}/{path}", headers=headers, params=params, timeout=15)
                resp.raise_for_status()
                data = resp.json()
            except httpx.HTTPError as e:
                return f"Najiz API error: {e}"
        return self._format(data, document_type)

    def _format(self, data: dict, doc_type: str) -> str:
        parts = [
            f"Document type: {doc_type}",
            f"Status: {data.get('status', data.get('verificationStatus', 'N/A'))}",
            f"Document number: {data.get('documentNumber', 'N/A')}",
            f"Issue date: {data.get('issueDate', 'N/A')}",
        ]
        if doc_type == "deed":
            parts.extend([
                f"Property type: {data.get('propertyType', 'N/A')}",
                f"City: {data.get('city', 'N/A')}",
                f"Area: {data.get('area', 'N/A')} sqm",
            ])
        return "\n".join(parts)
