"""Ministry of Justice open data — judicial statistics.

Judicial indicators: case volumes, resolution rates, performance by court type.
Available via Saudi Open Data Portal. No authentication required.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class MoJSearchInput(BaseModel):
    """Input for MoJ judicial data search."""

    query: str = Field(description="Search term: case statistics, court data, judicial indicators")
    rows: int = Field(default=5, description="Number of results (1-20)")


class MoJOpenDataTool(CKANBaseTool):
    """Search Ministry of Justice open judicial data.

    Provides case filing volumes, resolution rates, court performance,
    and judicial indicators. Useful for legal analytics and research agents.

    See: https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.legal import MoJOpenDataTool

        tool = MoJOpenDataTool()
        result = tool.invoke({"query": "court case statistics 2024"})
        ```
    """

    name: str = "saudi_moj_judicial_data"
    description: str = (
        "Search Ministry of Justice open data for judicial statistics, "
        "case volumes, court performance, and legal indicators. No API key required."
    )
    args_schema: Type[BaseModel] = MoJSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "MoJ (Judicial)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:ministry-of-justice")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows, fq="organization:ministry-of-justice")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
