"""Monshaat — Small & Medium Enterprises General Authority.

SME registration data, support programs, licensing, growth indicators.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class MonshaatSearchInput(BaseModel):
    query: str = Field(description="Search term: SME, startup, licensing, small business, entrepreneurship")
    rows: int = Field(default=5, description="Number of results (1-20)")


class MonshaatSMETool(CKANBaseTool):
    """Search Monshaat (SME Authority) data.

    Provides SME registration data, support programs, licensing
    information, and growth indicators. Useful for startup advisory
    agents targeting Saudi founders.

    See: https://monshaat.gov.sa | https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.sector import MonshaatSMETool

        tool = MonshaatSMETool()
        result = tool.invoke({"query": "SME growth indicators 2024"})
        ```
    """

    name: str = "saudi_monshaat_sme"
    description: str = (
        "Search Monshaat SME data: small business statistics, startup programs, "
        "licensing data, and entrepreneurship indicators. No API key required."
    )
    args_schema: Type[BaseModel] = MonshaatSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "Monshaat (SME)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:monshaat")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows, fq="organization:monshaat")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
