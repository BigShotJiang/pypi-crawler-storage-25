"""MEWA — Ministry of Environment, Water & Agriculture (mewa.gov.sa).

Agriculture data, water resources, environmental indicators.
Genuinely unique datasets in any global LangChain toolkit.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class AgricultureSearchInput(BaseModel):
    query: str = Field(description="Search term: agriculture, water resources, farms, camels, environment")
    rows: int = Field(default=5, description="Number of results (1-20)")


class AgricultureDataTool(CKANBaseTool):
    """Search MEWA (Ministry of Environment, Water & Agriculture) data.

    Provides agriculture statistics, water resource data, environmental
    indicators, and unique datasets like camel counts, bee colonies,
    fishermen registrations, and farm inventories.

    See: https://mewa.gov.sa | https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.sector import AgricultureDataTool

        tool = AgricultureDataTool()
        result = tool.invoke({"query": "camel population by region"})
        ```
    """

    name: str = "saudi_agriculture_data"
    description: str = (
        "Search MEWA agriculture and environment data: farming statistics, water resources, "
        "livestock counts, environmental indicators. Unique Saudi datasets. No API key required."
    )
    args_schema: Type[BaseModel] = AgricultureSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "MEWA (Agriculture)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(
                query, rows, fq="organization:ministry-of-environment-water-and-agriculture"
            )
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(
                query, rows, fq="organization:ministry-of-environment-water-and-agriculture"
            )
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
