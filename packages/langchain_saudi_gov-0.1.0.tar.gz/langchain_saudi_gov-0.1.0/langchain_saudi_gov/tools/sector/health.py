"""Ministry of Health open data — moh.gov.sa.

Hospital capacity, physician counts, health insurance data.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class HealthSearchInput(BaseModel):
    query: str = Field(description="Search term: hospitals, physicians, health insurance, medical data")
    rows: int = Field(default=5, description="Number of results (1-20)")


class HealthDataTool(CKANBaseTool):
    """Search Ministry of Health open data.

    Provides hospital bed capacity, physician counts, health insurance
    subscriber data, and medical research datasets.

    See: https://moh.gov.sa | https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.sector import HealthDataTool

        tool = HealthDataTool()
        result = tool.invoke({"query": "hospital bed capacity by region"})
        ```
    """

    name: str = "saudi_health_data"
    description: str = (
        "Search Ministry of Health data: hospital capacity, physician counts, "
        "health insurance, and medical statistics. No API key required."
    )
    args_schema: Type[BaseModel] = HealthSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "Ministry of Health"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:ministry-of-health")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows, fq="organization:ministry-of-health")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
