"""CST — Communications, Space & Technology Commission (cst.gov.sa).

Telecom subscribers, broadband penetration, spectrum, 5G data.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class TelecomSearchInput(BaseModel):
    query: str = Field(description="Search term: telecoms, broadband, 5G, internet subscribers")
    rows: int = Field(default=5, description="Number of results (1-20)")


class TelecomDataTool(CKANBaseTool):
    """Search CST (Communications, Space & Technology Commission) data.

    Covers telecom subscriber counts, broadband penetration, spectrum
    allocation, and 5G rollout statistics.

    See: https://cst.gov.sa | https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.sector import TelecomDataTool

        tool = TelecomDataTool()
        result = tool.invoke({"query": "5G coverage statistics"})
        ```
    """

    name: str = "saudi_telecom_data"
    description: str = (
        "Search CST telecom data: subscriber counts, broadband penetration, "
        "5G coverage, and spectrum statistics. No API key required."
    )
    args_schema: Type[BaseModel] = TelecomSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "CST (Telecoms)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:communications-space-and-technology-commission")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(
                query, rows, fq="organization:communications-space-and-technology-commission"
            )
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
