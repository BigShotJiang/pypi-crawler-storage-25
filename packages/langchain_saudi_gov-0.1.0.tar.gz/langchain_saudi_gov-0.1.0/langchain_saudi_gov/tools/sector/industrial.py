"""NIIC — National Industrial & Mining Information Centre (niic.gov.sa).

Mining licenses, industrial zones, factory data, mineral resources.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class IndustrialSearchInput(BaseModel):
    query: str = Field(description="Search term: mining, industrial zones, factories, minerals")
    rows: int = Field(default=5, description="Number of results (1-20)")


class IndustrialDataTool(CKANBaseTool):
    """Search NIIC industrial and mining data.

    Covers mining licenses, industrial zones, factory data, and mineral
    resources. Relevant for Vision 2030 industrial diversification.

    See: https://niic.gov.sa | https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.sector import IndustrialDataTool

        tool = IndustrialDataTool()
        result = tool.invoke({"query": "mining licenses by region"})
        ```
    """

    name: str = "saudi_industrial_data"
    description: str = (
        "Search NIIC industrial and mining data: mining licenses, industrial zones, "
        "factory statistics, and mineral resources. No API key required."
    )
    args_schema: Type[BaseModel] = IndustrialSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "NIIC (Industrial)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:niic")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows, fq="organization:niic")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
