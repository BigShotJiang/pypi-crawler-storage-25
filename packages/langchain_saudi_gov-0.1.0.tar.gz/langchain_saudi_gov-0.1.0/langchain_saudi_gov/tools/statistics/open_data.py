"""Saudi Open Data Portal — data.gov.sa (SDAIA).

11,439+ datasets from 100+ ministries. CKAN API, no auth required.
"""

from typing import Optional, Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class OpenDataSearchInput(BaseModel):
    """Input for Saudi Open Data Portal search."""

    query: str = Field(description="Search term for government datasets")
    rows: int = Field(default=5, description="Number of results (1-20)")
    organization: Optional[str] = Field(
        default=None,
        description="Filter by organization/ministry slug, e.g. 'ministry-of-health'",
    )


class SaudiOpenDataSearchTool(CKANBaseTool):
    """Search the Saudi Open Data Portal (data.gov.sa).

    The national open data platform powered by CKAN with 11,000+ datasets
    from 100+ government ministries covering healthcare, education, economy,
    transportation, environment, and more.

    See: https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.statistics import SaudiOpenDataSearchTool

        tool = SaudiOpenDataSearchTool()
        result = tool.invoke({"query": "population statistics by region"})
        ```
    """

    name: str = "saudi_open_data"
    description: str = (
        "Search the Saudi Open Data Portal (data.gov.sa) with 11,000+ datasets from "
        "100+ government ministries. Covers health, education, economy, transport, and more. "
        "No API key required."
    )
    args_schema: Type[BaseModel] = OpenDataSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "Saudi Open Data Portal"

    def _run(self, query: str, rows: int = 5, organization: Optional[str] = None) -> str:
        fq = f"organization:{organization}" if organization else None
        try:
            data = self._ckan_search(query, rows, fq=fq)
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5, organization: Optional[str] = None) -> str:
        fq = f"organization:{organization}" if organization else None
        try:
            data = await self._ckan_asearch(query, rows, fq=fq)
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
