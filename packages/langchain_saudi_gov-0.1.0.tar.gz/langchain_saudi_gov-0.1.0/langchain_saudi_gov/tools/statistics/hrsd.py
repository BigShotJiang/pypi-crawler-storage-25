"""HRSD — Ministry of Human Resources & Social Development.

Labour market stats, Saudization (Nitaqat) data, workforce indicators.
Data available via Saudi Open Data Portal. No auth required.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class HRSDSearchInput(BaseModel):
    """Input for HRSD labour data search."""

    query: str = Field(description="Search term: labour market, Nitaqat, Saudization, workforce, employment")
    rows: int = Field(default=5, description="Number of results (1-20)")


class HRSDLabourTool(CKANBaseTool):
    """Search HRSD labour market and social development data.

    Provides labour market statistics, Saudization (Nitaqat) data,
    social insurance metrics, and workforce indicators. Useful for
    HR compliance and labour market analysis agents.

    See: https://hrsd.gov.sa | https://data.gov.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.statistics import HRSDLabourTool

        tool = HRSDLabourTool()
        result = tool.invoke({"query": "Saudization Nitaqat compliance rates"})
        ```
    """

    name: str = "saudi_hrsd_labour"
    description: str = (
        "Search HRSD labour data: Saudization (Nitaqat) rates, workforce indicators, "
        "employment statistics, and social development metrics. No API key required."
    )
    args_schema: Type[BaseModel] = HRSDSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "HRSD (Labour)"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:ministry-of-human-resources-and-social-development")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(
                query, rows, fq="organization:ministry-of-human-resources-and-social-development"
            )
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
