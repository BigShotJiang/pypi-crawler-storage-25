"""GASTAT — General Authority for Statistics (stats.gov.sa / datasaudi.sa).

Official Saudi statistics: GDP, CPI, unemployment, trade balance,
real estate index, PMI, population. No auth required.
"""

from typing import Type

from pydantic import BaseModel, Field

from langchain_saudi_gov.tools._base import CKANBaseTool


class GASTATSearchInput(BaseModel):
    """Input for GASTAT statistics search."""

    query: str = Field(description="Search term: GDP, CPI, unemployment, population, trade, PMI")
    rows: int = Field(default=5, description="Number of results (1-20)")


class GASTATTool(CKANBaseTool):
    """Search GASTAT (General Authority for Statistics) official data.

    Provides GDP, CPI, unemployment, trade balance, real estate price
    index, PMI, and population statistics. The definitive source for
    Saudi economic indicators.

    See: https://stats.gov.sa | https://datasaudi.sa

    Example:
        ```python
        from langchain_saudi_gov.tools.statistics import GASTATTool

        tool = GASTATTool()
        result = tool.invoke({"query": "GDP growth rate 2024"})
        ```
    """

    name: str = "saudi_gastat_statistics"
    description: str = (
        "Search GASTAT for official Saudi statistics: GDP, CPI, unemployment, "
        "trade balance, real estate index, PMI, and population data. No API key required."
    )
    args_schema: Type[BaseModel] = GASTATSearchInput
    base_url: str = "https://data.gov.sa/Data/api/3/action"
    portal_name: str = "GASTAT"

    def _run(self, query: str, rows: int = 5) -> str:
        try:
            data = self._ckan_search(query, rows, fq="organization:general-authority-for-statistics")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)

    async def _arun(self, query: str, rows: int = 5) -> str:
        try:
            data = await self._ckan_asearch(query, rows, fq="organization:general-authority-for-statistics")
            return self._format_ckan_results(data)
        except Exception as e:
            return self._handle_ckan_error(e)
