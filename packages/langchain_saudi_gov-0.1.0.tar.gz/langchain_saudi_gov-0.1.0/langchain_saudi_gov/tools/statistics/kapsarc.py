"""KAPSARC — King Abdullah Petroleum Studies and Research Center.

REST API at datasource.kapsarc.org/api/v2.1. Oil production, energy
consumption, renewables, Saudi energy balance, OPEC data. No auth required.
"""

from typing import Type

import httpx
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

KAPSARC_BASE = "https://datasource.kapsarc.org/api/v2.1"


class KAPSARCSearchInput(BaseModel):
    """Input for KAPSARC energy data search."""

    query: str = Field(description="Search term: oil production, energy consumption, OPEC, renewables")
    rows: int = Field(default=5, description="Number of results (1-20)")


class KAPSARCEnergyTool(BaseTool):
    """Search KAPSARC energy data portal.

    Provides oil production, energy consumption, renewables, Saudi energy
    balance, and OPEC data from King Abdullah Petroleum Studies center.
    Directly relevant for oil & gas, energy, and climate agents.

    See: https://datasource.kapsarc.org

    Example:
        ```python
        from langchain_saudi_gov.tools.statistics import KAPSARCEnergyTool

        tool = KAPSARCEnergyTool()
        result = tool.invoke({"query": "Saudi oil production 2024"})
        ```
    """

    name: str = "saudi_kapsarc_energy"
    description: str = (
        "Search KAPSARC energy data: oil production, energy consumption, "
        "renewables, OPEC data, and Saudi energy balance. No API key required."
    )
    args_schema: Type[BaseModel] = KAPSARCSearchInput
    base_url: str = KAPSARC_BASE

    def _run(self, query: str, rows: int = 5) -> str:
        rows = max(1, min(rows, 20))
        try:
            resp = httpx.get(
                f"{self.base_url}/catalog/datasets",
                params={"search": query, "limit": rows},
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as e:
            return f"KAPSARC API error: {e}"
        return self._format(data)

    async def _arun(self, query: str, rows: int = 5) -> str:
        rows = max(1, min(rows, 20))
        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(
                    f"{self.base_url}/catalog/datasets",
                    params={"search": query, "limit": rows},
                    timeout=15,
                )
                resp.raise_for_status()
                data = resp.json()
            except httpx.HTTPError as e:
                return f"KAPSARC API error: {e}"
        return self._format(data)

    def _format(self, data: dict) -> str:
        datasets = data.get("datasets", data.get("results", []))
        total = data.get("total_count", len(datasets))
        if not datasets:
            return "No KAPSARC energy datasets found for this query."
        lines = [f"Found {total} KAPSARC dataset(s). Showing top {len(datasets)}:\n"]
        for i, ds in enumerate(datasets, 1):
            meta = ds.get("metas", ds.get("dataset", {}))
            title = meta.get("title", meta.get("dataset_id", "Untitled"))
            desc = (meta.get("description", "") or "No description")[:200]
            theme = meta.get("theme", "N/A")
            lines.append(f"{i}. {title}")
            lines.append(f"   Theme: {theme}")
            lines.append(f"   Description: {desc}")
            lines.append("")
        return "\n".join(lines)
