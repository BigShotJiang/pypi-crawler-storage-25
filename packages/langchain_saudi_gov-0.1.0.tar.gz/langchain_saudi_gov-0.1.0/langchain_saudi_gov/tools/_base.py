"""Shared base classes for Saudi government API tools."""

from typing import Any, Dict, Optional, Type

import httpx
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class WathqBaseTool(BaseTool):
    """Base class for all Wathq (developer.wathq.sa) API tools.

    Provides shared HTTP client configuration, authentication, and error
    handling for the Wathq developer platform APIs.

    Args:
        api_key: Wathq subscription key from developer.wathq.sa.
        base_url: Wathq API base URL (override for testing).
        timeout: Request timeout in seconds.
    """

    api_key: str
    base_url: str = "https://api.wathq.sa"
    timeout: int = 15

    def _wathq_get(self, path: str, params: Optional[Dict[str, Any]] = None) -> dict:
        """Make authenticated GET request to Wathq API.

        Args:
            path: API endpoint path (appended to base_url).
            params: Optional query parameters.

        Returns:
            Parsed JSON response.

        Raises:
            httpx.HTTPStatusError: On 4xx/5xx responses.
        """
        headers = {"apiKey": self.api_key, "Accept": "application/json"}
        resp = httpx.get(
            f"{self.base_url}{path}",
            headers=headers,
            params=params,
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    async def _wathq_aget(self, path: str, params: Optional[Dict[str, Any]] = None) -> dict:
        """Make async authenticated GET request to Wathq API."""
        headers = {"apiKey": self.api_key, "Accept": "application/json"}
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.base_url}{path}",
                headers=headers,
                params=params,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return resp.json()

    def _handle_wathq_error(self, e: Exception) -> str:
        """Format Wathq API errors into user-friendly messages."""
        if isinstance(e, httpx.HTTPStatusError):
            code = e.response.status_code
            if code == 401:
                return "Wathq API error: Invalid or expired API key. Get one at developer.wathq.sa"
            if code == 404:
                return "Wathq API error: Record not found."
            if code == 429:
                return "Wathq API error: Rate limit exceeded. Please try again later."
            return f"Wathq API error ({code}): {e.response.text[:200]}"
        return f"Wathq API error: {e}"


class CKANSearchInput(BaseModel):
    """Shared input schema for CKAN-based open data portal searches."""

    query: str = Field(description="Search term for datasets, in Arabic or English")
    rows: int = Field(default=5, description="Number of results to return (1-20)")


class CKANBaseTool(BaseTool):
    """Base class for CKAN-based Saudi open data portal tools.

    Saudi government uses CKAN for several open data portals including
    data.gov.sa, data.zatca.gov.sa, and opendata.cma.org.sa. This base
    class provides shared search and formatting logic.

    Args:
        base_url: CKAN API base URL.
        portal_name: Human-readable portal name for output.
        timeout: Request timeout in seconds.
    """

    base_url: str
    portal_name: str = "Saudi Open Data"
    timeout: int = 15

    def _ckan_search(self, query: str, rows: int = 5, fq: Optional[str] = None) -> dict:
        """Execute CKAN package_search.

        Args:
            query: Search query string.
            rows: Max results to return.
            fq: Optional CKAN filter query.

        Returns:
            Parsed JSON response from CKAN.
        """
        rows = max(1, min(rows, 20))
        params: Dict[str, Any] = {"q": query, "rows": rows}
        if fq:
            params["fq"] = fq
        resp = httpx.get(
            f"{self.base_url}/package_search",
            params=params,
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    async def _ckan_asearch(self, query: str, rows: int = 5, fq: Optional[str] = None) -> dict:
        """Async execute CKAN package_search."""
        rows = max(1, min(rows, 20))
        params: Dict[str, Any] = {"q": query, "rows": rows}
        if fq:
            params["fq"] = fq
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.base_url}/package_search",
                params=params,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return resp.json()

    def _format_ckan_results(self, data: dict) -> str:
        """Format CKAN search results into readable text."""
        if not data.get("success"):
            return f"Search failed: {data.get('error', {}).get('message', 'unknown error')}"

        result = data.get("result", {})
        datasets = result.get("results", [])
        total = result.get("count", 0)

        if not datasets:
            return f"No datasets found on {self.portal_name} for this query."

        lines = [f"Found {total} dataset(s) on {self.portal_name}. Showing top {len(datasets)}:\n"]
        for i, ds in enumerate(datasets, 1):
            title = ds.get("title", "Untitled")
            org = ds.get("organization", {})
            org_name = org.get("title", "Unknown") if org else "Unknown"
            notes = (ds.get("notes") or "No description")[:200]
            resources = ds.get("resources", [])
            formats = ", ".join(sorted(set(r.get("format", "?") for r in resources))) or "N/A"

            lines.append(f"{i}. {title}")
            lines.append(f"   Source: {org_name}")
            lines.append(f"   Description: {notes}")
            lines.append(f"   Formats: {formats}")
            if resources:
                lines.append(f"   Download: {resources[0].get('url', 'N/A')}")
            lines.append("")

        return "\n".join(lines)

    def _handle_ckan_error(self, e: Exception) -> str:
        """Format CKAN API errors into user-friendly messages."""
        return f"{self.portal_name} API error: {e}"
