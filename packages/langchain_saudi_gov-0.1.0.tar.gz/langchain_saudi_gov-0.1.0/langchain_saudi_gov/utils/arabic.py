"""Arabic text normalization helpers for Saudi government API responses."""

import re
import unicodedata


def normalize_arabic(text: str) -> str:
    """Normalize Arabic text for consistent matching.

    Removes diacritics (tashkeel), normalizes alef variants, and strips whitespace.

    Args:
        text: Arabic text to normalize.

    Returns:
        Normalized Arabic text.

    Example:
        ```python
        from langchain_saudi_gov.utils.arabic import normalize_arabic

        normalize_arabic("الرِّيَاض")  # → "الرياض"
        ```
    """
    text = remove_diacritics(text)
    text = normalize_alef(text)
    return text.strip()


def remove_diacritics(text: str) -> str:
    """Remove Arabic diacritical marks (tashkeel) from text.

    Args:
        text: Arabic text possibly containing diacritics.

    Returns:
        Text with diacritics removed.
    """
    diacritics_pattern = re.compile(
        "[\u0610-\u061a\u064b-\u065f\u0670"
        "\u06d6-\u06dc\u06df-\u06e4\u06e7\u06e8\u06ea-\u06ed]"
    )
    return diacritics_pattern.sub("", text)


def normalize_alef(text: str) -> str:
    """Normalize alef variants (أ إ آ ٱ) to plain alef (ا).

    Args:
        text: Arabic text.

    Returns:
        Text with normalized alef characters.
    """
    alef_variants = {
        "\u0623": "\u0627",  # أ → ا
        "\u0625": "\u0627",  # إ → ا
        "\u0622": "\u0627",  # آ → ا
        "\u0671": "\u0627",  # ٱ → ا
    }
    for variant, replacement in alef_variants.items():
        text = text.replace(variant, replacement)
    return text


def normalize_teh_marbuta(text: str) -> str:
    """Normalize teh marbuta (ة) to heh (ه) for fuzzy matching.

    Args:
        text: Arabic text.

    Returns:
        Text with teh marbuta replaced by heh.
    """
    return text.replace("\u0629", "\u0647")


def is_arabic(text: str) -> bool:
    """Check if text contains Arabic characters.

    Args:
        text: Text to check.

    Returns:
        True if text contains at least one Arabic character.
    """
    for char in text:
        if unicodedata.category(char).startswith("L"):
            try:
                if "ARABIC" in unicodedata.name(char, ""):
                    return True
            except ValueError:
                continue
    return False


def detect_language(text: str) -> str:
    """Detect whether text is primarily Arabic or English.

    Args:
        text: Input text.

    Returns:
        ``'A'`` for Arabic, ``'E'`` for English. Defaults to ``'E'``.
    """
    return "A" if is_arabic(text) else "E"
