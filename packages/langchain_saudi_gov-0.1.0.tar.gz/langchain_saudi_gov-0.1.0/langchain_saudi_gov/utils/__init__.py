"""Arabic text utilities for Saudi government API responses."""
