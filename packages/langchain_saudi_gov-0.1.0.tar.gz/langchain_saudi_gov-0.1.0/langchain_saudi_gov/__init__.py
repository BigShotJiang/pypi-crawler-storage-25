"""LangChain toolkit for Saudi Arabian government and public APIs.

Provides 27 tools across 7 domains:

- **Location**: National Address search & reverse geocode, Balady municipal data
- **Business**: 8 Wathq tools — CR, contracts, real estate, trademark, corporate ID,
  financial statements, employee info, chamber verification
- **Legal**: Najiz judicial verification, MoJ open data
- **Finance**: ZATCA tax data, CMA capital markets, Etimad procurement
- **Statistics**: GASTAT, KAPSARC energy, Saudi Open Data Portal, HRSD labour
- **Sector**: Health, Telecom, Agriculture, Industrial, Monshaat SME
- **Cultural**: Prayer times, Hijri date conversion

Example:
    ```python
    from langchain_saudi_gov import SaudiGovToolkit

    toolkit = SaudiGovToolkit(national_address_key="your-key")
    tools = toolkit.get_tools()
    ```
"""

from langchain_saudi_gov.toolkit import SaudiGovToolkit

# Location
from langchain_saudi_gov.tools.location import (
    NationalAddressSearchTool,
    NationalAddressReverseGeocodeTool,
    BaladyMunicipalTool,
)

# Business (Wathq)
from langchain_saudi_gov.tools.business import (
    CommercialRegistrationTool,
    CommercialContractTool,
    RealEstateDeedTool,
    TrademarkLookupTool,
    CorporateIdentityTool,
    FinancialStatementsTool,
    EmployeeInfoTool,
    ChamberVerificationTool,
)

# Legal
from langchain_saudi_gov.tools.legal import NajizVerificationTool, MoJOpenDataTool

# Finance
from langchain_saudi_gov.tools.finance import (
    ZATCAOpenDataTool,
    CMAFinancialDataTool,
    EtimadProcurementTool,
)

# Statistics
from langchain_saudi_gov.tools.statistics import (
    GASTATTool,
    KAPSARCEnergyTool,
    SaudiOpenDataSearchTool,
    HRSDLabourTool,
)

# Sector
from langchain_saudi_gov.tools.sector import (
    HealthDataTool,
    TelecomDataTool,
    AgricultureDataTool,
    IndustrialDataTool,
    MonshaatSMETool,
)

# Cultural
from langchain_saudi_gov.tools.cultural import PrayerTimesTool, HijriDateTool

__all__ = [
    # Toolkit
    "SaudiGovToolkit",
    # Location
    "NationalAddressSearchTool",
    "NationalAddressReverseGeocodeTool",
    "BaladyMunicipalTool",
    # Business
    "CommercialRegistrationTool",
    "CommercialContractTool",
    "RealEstateDeedTool",
    "TrademarkLookupTool",
    "CorporateIdentityTool",
    "FinancialStatementsTool",
    "EmployeeInfoTool",
    "ChamberVerificationTool",
    # Legal
    "NajizVerificationTool",
    "MoJOpenDataTool",
    # Finance
    "ZATCAOpenDataTool",
    "CMAFinancialDataTool",
    "EtimadProcurementTool",
    # Statistics
    "GASTATTool",
    "KAPSARCEnergyTool",
    "SaudiOpenDataSearchTool",
    "HRSDLabourTool",
    # Sector
    "HealthDataTool",
    "TelecomDataTool",
    "AgricultureDataTool",
    "IndustrialDataTool",
    "MonshaatSMETool",
    # Cultural
    "PrayerTimesTool",
    "HijriDateTool",
]
