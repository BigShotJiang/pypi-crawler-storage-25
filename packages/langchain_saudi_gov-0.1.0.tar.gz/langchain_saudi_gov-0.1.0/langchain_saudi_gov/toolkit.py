"""SaudiGovToolkit — unified entry point for all Saudi government tools.

Bundles 27 tools across 7 domains. Tools requiring API keys are only
included when the corresponding key is provided. Tools that need no
authentication are always included.
"""

from typing import List, Optional

from langchain_core.tools import BaseTool

# Location
from langchain_saudi_gov.tools.location import (
    NationalAddressSearchTool,
    NationalAddressReverseGeocodeTool,
    BaladyMunicipalTool,
)

# Business (Wathq)
from langchain_saudi_gov.tools.business import (
    CommercialRegistrationTool,
    CommercialContractTool,
    RealEstateDeedTool,
    TrademarkLookupTool,
    CorporateIdentityTool,
    FinancialStatementsTool,
    EmployeeInfoTool,
    ChamberVerificationTool,
)

# Legal
from langchain_saudi_gov.tools.legal import NajizVerificationTool, MoJOpenDataTool

# Finance
from langchain_saudi_gov.tools.finance import (
    ZATCAOpenDataTool,
    CMAFinancialDataTool,
    EtimadProcurementTool,
)

# Statistics
from langchain_saudi_gov.tools.statistics import (
    GASTATTool,
    KAPSARCEnergyTool,
    SaudiOpenDataSearchTool,
    HRSDLabourTool,
)

# Sector
from langchain_saudi_gov.tools.sector import (
    HealthDataTool,
    TelecomDataTool,
    AgricultureDataTool,
    IndustrialDataTool,
    MonshaatSMETool,
)

# Cultural
from langchain_saudi_gov.tools.cultural import PrayerTimesTool, HijriDateTool


class SaudiGovToolkit:
    """Toolkit for Saudi Arabian government and public service APIs.

    Bundles 27 LangChain-compatible tools across 7 domains:
    location, business, legal, finance, statistics, sector-specific,
    and cultural. Supports selective tool loading based on available
    API keys and domain preferences.

    See: https://github.com/fouadmahmoud283-ai/langchain-saudi-gov

    Args:
        national_address_key: API key from api.address.gov.sa (free tier).
        wathq_key: Subscription key from developer.wathq.sa.
        najiz_key: Developer API key from developers.najiz.sa.
        include_open_data: Include no-auth open data tools (default True).
        include_cultural: Include prayer times and Hijri tools (default True).
        domains: Limit to specific domains. None = all available.
            Valid values: 'location', 'business', 'legal', 'finance',
            'statistics', 'sector', 'cultural'.

    Example:
        ```python
        from langchain_saudi_gov import SaudiGovToolkit
        from langchain_anthropic import ChatAnthropic
        from langgraph.prebuilt import create_react_agent

        # All tools with all available keys
        toolkit = SaudiGovToolkit(
            national_address_key="your-key",
            wathq_key="your-wathq-key",
        )
        agent = create_react_agent(
            model=ChatAnthropic(model="claude-sonnet-4-6"),
            tools=toolkit.get_tools(),
        )

        # Only open data tools (no keys needed)
        toolkit = SaudiGovToolkit()
        tools = toolkit.get_tools()  # 15 tools, all free

        # Only specific domains
        toolkit = SaudiGovToolkit(domains=["finance", "statistics"])
        ```
    """

    def __init__(
        self,
        national_address_key: Optional[str] = None,
        wathq_key: Optional[str] = None,
        najiz_key: Optional[str] = None,
        include_open_data: bool = True,
        include_cultural: bool = True,
        domains: Optional[List[str]] = None,
    ) -> None:
        self.national_address_key = national_address_key
        self.wathq_key = wathq_key
        self.najiz_key = najiz_key
        self.include_open_data = include_open_data
        self.include_cultural = include_cultural
        self.domains = set(domains) if domains else None

    def _domain_enabled(self, domain: str) -> bool:
        """Check if a domain is enabled."""
        return self.domains is None or domain in self.domains

    def get_tools(self) -> List[BaseTool]:
        """Return all available tools based on provided API keys and domain config.

        Returns:
            List of LangChain BaseTool instances.
        """
        tools: List[BaseTool] = []

        # === Location ===
        if self._domain_enabled("location"):
            if self.national_address_key:
                tools.append(NationalAddressSearchTool(api_key=self.national_address_key))
                tools.append(NationalAddressReverseGeocodeTool(api_key=self.national_address_key))
            if self.include_open_data:
                tools.append(BaladyMunicipalTool())

        # === Business (Wathq) ===
        if self._domain_enabled("business") and self.wathq_key:
            tools.extend([
                CommercialRegistrationTool(api_key=self.wathq_key),
                CommercialContractTool(api_key=self.wathq_key),
                RealEstateDeedTool(api_key=self.wathq_key),
                TrademarkLookupTool(api_key=self.wathq_key),
                CorporateIdentityTool(api_key=self.wathq_key),
                FinancialStatementsTool(api_key=self.wathq_key),
                EmployeeInfoTool(api_key=self.wathq_key),
                ChamberVerificationTool(api_key=self.wathq_key),
            ])

        # === Legal ===
        if self._domain_enabled("legal"):
            if self.najiz_key:
                tools.append(NajizVerificationTool(api_key=self.najiz_key))
            if self.include_open_data:
                tools.append(MoJOpenDataTool())

        # === Finance ===
        if self._domain_enabled("finance") and self.include_open_data:
            tools.extend([
                ZATCAOpenDataTool(),
                CMAFinancialDataTool(),
                EtimadProcurementTool(),
            ])

        # === Statistics ===
        if self._domain_enabled("statistics") and self.include_open_data:
            tools.extend([
                GASTATTool(),
                KAPSARCEnergyTool(),
                SaudiOpenDataSearchTool(),
                HRSDLabourTool(),
            ])

        # === Sector ===
        if self._domain_enabled("sector") and self.include_open_data:
            tools.extend([
                HealthDataTool(),
                TelecomDataTool(),
                AgricultureDataTool(),
                IndustrialDataTool(),
                MonshaatSMETool(),
            ])

        # === Cultural ===
        if self._domain_enabled("cultural") and self.include_cultural:
            tools.extend([
                PrayerTimesTool(),
                HijriDateTool(),
            ])

        return tools
