# SPDX-License-Identifier: MIT
# Copyright (c) 2021-2026
"""
Device query facade for centralized data point and event lookups.

This module extracts the query-oriented methods from CentralUnit into a
dedicated facade, reducing CentralUnit's responsibility surface and grouping
related read-only lookups in one place.

Public API of this module is defined by __all__.
"""

from dataclasses import dataclass
import logging
from typing import TYPE_CHECKING, Final, TypeVar

from aiohomematic.const import (
    IGNORE_FOR_UN_IGNORE_PARAMETERS,
    UN_IGNORE_WILDCARD,
    DataPointCategory,
    DataPointType,
    DeviceTriggerEventType,
    Interface,
    Operations,
    Parameter,
    ParamsetKey,
)
from aiohomematic.exceptions import AioHomematicException
from aiohomematic.interfaces.central import DeviceQueryFacadeProtocol
from aiohomematic.interfaces.model import (
    CallbackDataPointProtocol,
    ChannelEventGroupProtocol,
    CustomDataPointProtocol,
    DeviceProtocol,
    GenericDataPointProtocol,
    GenericDataPointProtocolAny,
    GenericEventProtocolAny,
)
from aiohomematic.support.address import get_channel_no, get_device_address

if TYPE_CHECKING:
    from aiohomematic.central.coordinators import CacheCoordinator, ClientCoordinator, DeviceCoordinator, HubCoordinator
    from aiohomematic.central.device_registry import DeviceRegistry

__all__ = ["DeviceQueryFacade", "ScheduleInfo"]


@dataclass(frozen=True, slots=True)
class ScheduleInfo:
    """Schedule capability metadata for a device."""

    device_address: str
    device_name: str
    schedule_channel_address: str | None
    has_schedule: bool


_LOGGER: Final = logging.getLogger(__name__)

_T = TypeVar("_T")


class DeviceQueryFacade(DeviceQueryFacadeProtocol):
    """
    Facade for querying devices, data points, and events.

    Aggregates the 12 query methods previously hosted directly on CentralUnit.
    All methods are read-only lookups; mutation is still handled by coordinators.

    Dependencies are injected via constructor to keep the facade decoupled
    from CentralUnit.
    """

    __slots__ = (
        "_cache_coordinator",
        "_client_coordinator",
        "_device_coordinator",
        "_device_registry",
        "_hub_coordinator",
    )

    def __init__(
        self,
        *,
        device_registry: DeviceRegistry,
        device_coordinator: DeviceCoordinator,
        cache_coordinator: CacheCoordinator,
        client_coordinator: ClientCoordinator,
        hub_coordinator: HubCoordinator,
    ) -> None:
        """Initialize the query facade."""
        self._device_registry: Final = device_registry
        self._device_coordinator: Final = device_coordinator
        self._cache_coordinator: Final = cache_coordinator
        self._client_coordinator: Final = client_coordinator
        self._hub_coordinator: Final = hub_coordinator

    @staticmethod
    def _resolve_channel_repr(
        *,
        channel_address: str,
        use_channel_wildcard: bool,
        channel_no_cache: dict[str, int | None],
    ) -> int | str | None:
        """Return cached or freshly computed channel representation for full-format output."""
        if use_channel_wildcard:
            return UN_IGNORE_WILDCARD
        if channel_address in channel_no_cache:
            return channel_no_cache[channel_address]
        channel_repr = get_channel_no(address=channel_address)
        channel_no_cache[channel_address] = channel_repr
        return channel_repr

    def get_custom_data_point(self, *, address: str, channel_no: int) -> CustomDataPointProtocol | None:
        """Return the hm custom_data_point."""
        if device := self._device_coordinator.get_device(address=address):
            return device.get_custom_data_point(channel_no=channel_no)
        return None

    def get_data_points(
        self,
        *,
        category: DataPointCategory | None = None,
        data_point_type: DataPointType | None = None,
        interface: Interface | None = None,
        exclude_no_create: bool = True,
        registered: bool | None = None,
    ) -> tuple[CallbackDataPointProtocol, ...]:
        """Return all externally registered data points."""
        all_data_points: list[CallbackDataPointProtocol] = []
        for device in self._device_registry.devices:
            if interface and interface != device.interface:
                continue
            all_data_points.extend(
                device.get_data_points(category=category, exclude_no_create=exclude_no_create, registered=registered)
            )
        if data_point_type is not None:
            return tuple(dp for dp in all_data_points if dp.data_point_type == data_point_type)
        return tuple(all_data_points)

    def get_data_points_by_type(
        self,
        *,
        data_point_class: type[_T],
        category: DataPointCategory | None = None,
        interface: Interface | None = None,
        exclude_no_create: bool = True,
        registered: bool | None = None,
    ) -> tuple[_T, ...]:
        """
        Return data points filtered by concrete class, with precise return type.

        This method eliminates the need for ``cast()`` when the caller
        knows which data point type is expected::

            # Before (requires cast):
            for dp in query_facade.get_data_points():
                adapter = cast(GenericDataPointProtocolAny, dp)

            # After (type-safe):
            for dp in query_facade.get_data_points_by_type(
                data_point_class=GenericDataPoint,
            ):
                adapter = dp  # already typed as GenericDataPoint

        Args:
            data_point_class: The class to filter by (isinstance check).
            category: Optional category filter.
            interface: Optional interface filter.
            exclude_no_create: Exclude data points with no_create flag.
            registered: Filter by registration status.

        Returns:
            Tuple of data points matching the given class.

        """
        return tuple(
            dp
            for dp in self.get_data_points(
                category=category,
                interface=interface,
                exclude_no_create=exclude_no_create,
                registered=registered,
            )
            if isinstance(dp, data_point_class)
        )

    def get_devices(
        self,
        *,
        interface: Interface | None = None,
        available: bool | None = None,
    ) -> tuple[DeviceProtocol, ...]:
        """Return devices matching the given filters."""
        devices: list[DeviceProtocol] = []
        for device in self._device_registry.devices:
            if interface is not None and device.interface != interface:
                continue
            if available is not None and device.available != available:
                continue
            devices.append(device)
        return tuple(devices)

    def get_event(
        self, *, channel_address: str | None = None, parameter: str | None = None, state_path: str | None = None
    ) -> GenericEventProtocolAny | None:
        """Return the hm event."""
        if channel_address is None:
            for dev in self._device_registry.devices:
                if event := dev.get_generic_event(parameter=parameter, state_path=state_path):
                    return event
            return None

        if device := self._device_coordinator.get_device(address=channel_address):
            return device.get_generic_event(channel_address=channel_address, parameter=parameter, state_path=state_path)
        return None

    def get_event_groups(
        self,
        *,
        event_type: DeviceTriggerEventType,
        registered: bool | None = None,
    ) -> tuple[ChannelEventGroupProtocol, ...]:
        """
        Return all channel event groups for the given event type.

        Each ChannelEventGroup is a virtual data point bound to its channel,
        providing unified access for Home Assistant entity creation.

        Args:
            event_type: The event type to filter by.
            registered: Filter by registration status (None = all).

        Returns:
            Tuple of ChannelEventGroup instances.

        """
        groups: list[ChannelEventGroupProtocol] = []
        for device in self._device_registry.devices:
            for channel in device.channels.values():
                if (event_group := channel.event_groups.get(event_type)) is None:
                    continue
                # Filter by registration status
                if registered is not None and event_group.is_registered != registered:
                    continue
                groups.append(event_group)
        return tuple(groups)

    def get_events(
        self, *, event_type: DeviceTriggerEventType, registered: bool | None = None
    ) -> tuple[tuple[GenericEventProtocolAny, ...], ...]:
        """Return all channel event data points."""
        hm_channel_events: list[tuple[GenericEventProtocolAny, ...]] = []
        for device in self._device_registry.devices:
            for channel_events in device.get_events(event_type=event_type).values():
                if registered is None or (channel_events[0].is_registered == registered):
                    hm_channel_events.append(channel_events)
                    continue
        return tuple(hm_channel_events)

    def get_generic_data_point(
        self,
        *,
        channel_address: str | None = None,
        parameter: str | None = None,
        paramset_key: ParamsetKey | None = None,
        state_path: str | None = None,
    ) -> GenericDataPointProtocolAny | None:
        """Get data_point by channel_address and parameter."""
        if channel_address is None:
            for dev in self._device_registry.devices:
                if dp := dev.get_generic_data_point(
                    parameter=parameter, paramset_key=paramset_key, state_path=state_path
                ):
                    return dp
            return None

        if device := self._device_coordinator.get_device(address=channel_address):
            return device.get_generic_data_point(
                channel_address=channel_address, parameter=parameter, paramset_key=paramset_key, state_path=state_path
            )
        return None

    async def get_install_mode(self, *, interface: Interface) -> int:
        """
        Return the remaining time in install mode for an interface.

        Args:
            interface: The interface to query (HMIP_RF or BIDCOS_RF).

        Returns:
            Remaining time in seconds, or 0 if not in install mode.

        """
        try:
            client = self._client_coordinator.get_client(interface=interface)
            return await client.get_install_mode()
        except AioHomematicException:
            return 0

    def get_parameters(
        self,
        *,
        paramset_key: ParamsetKey,
        operations: tuple[Operations, ...],
        full_format: bool = False,
        un_ignore_candidates_only: bool = False,
        use_channel_wildcard: bool = False,
    ) -> tuple[str, ...]:
        """
        Return all parameters from VALUES paramset.

        Performance optimized to minimize repeated lookups and computations
        when iterating over all channels and parameters.
        """
        parameters: set[str] = set()

        # Precompute operations mask to avoid repeated checks in the inner loop
        op_mask: int = 0
        for op in operations:
            op_mask |= int(op)

        raw_psd = self._cache_coordinator.paramset_descriptions.raw_paramset_descriptions
        ignore_set = IGNORE_FOR_UN_IGNORE_PARAMETERS

        # Prepare optional helpers only if needed
        get_model = self._cache_coordinator.device_descriptions.get_model if full_format else None
        model_cache: dict[str, str | None] = {}
        channel_no_cache: dict[str, int | None] = {}

        for channels in raw_psd.values():
            for channel_address, channel_paramsets in channels.items():
                # Resolve model lazily and cache per device address when full_format is requested
                model: str | None = None
                if get_model is not None:
                    dev_addr = get_device_address(address=channel_address)
                    if (model := model_cache.get(dev_addr)) is None:
                        model = get_model(device_address=dev_addr)
                        model_cache[dev_addr] = model

                if (paramset := channel_paramsets.get(paramset_key)) is None:
                    continue

                for parameter, parameter_data in paramset.items():
                    # Fast bitmask check: ensure all requested ops are present
                    if (int(parameter_data["OPERATIONS"]) & op_mask) != op_mask:
                        continue

                    if un_ignore_candidates_only and self._skip_un_ignore_candidate(
                        parameter=parameter,
                        channel_address=channel_address,
                        paramset_key=paramset_key,
                        ignore_set=ignore_set,
                    ):
                        continue

                    if not full_format:
                        parameters.add(parameter)
                        continue

                    channel_repr = self._resolve_channel_repr(
                        channel_address=channel_address,
                        use_channel_wildcard=use_channel_wildcard,
                        channel_no_cache=channel_no_cache,
                    )

                    # Build the full parameter string
                    if channel_repr is None:
                        parameters.add(f"{parameter}:{paramset_key}@{model}:")
                    else:
                        parameters.add(f"{parameter}:{paramset_key}@{model}:{channel_repr}")

        return tuple(parameters)

    def get_readable_generic_data_points(
        self, *, paramset_key: ParamsetKey | None = None, interface: Interface | None = None
    ) -> tuple[GenericDataPointProtocolAny, ...]:
        """Return the readable generic data points."""
        return tuple(
            ge
            for ge in self.get_data_points(interface=interface)
            if (
                isinstance(ge, GenericDataPointProtocol)
                and ge.is_readable
                and ((paramset_key and ge.paramset_key == paramset_key) or paramset_key is None)
            )
        )

    def get_schedule_capable_devices(self) -> tuple[ScheduleInfo, ...]:
        """Return schedule capability metadata for all devices with week profiles."""
        results: list[ScheduleInfo] = []
        for device in self._device_registry.devices:
            if not device.has_week_profile:
                continue
            if (wp := device.week_profile) is None:
                continue
            results.append(
                ScheduleInfo(
                    device_address=device.address,
                    device_name=device.name,
                    schedule_channel_address=wp.schedule_channel_address,
                    has_schedule=wp.has_schedule,
                )
            )
        return tuple(results)

    def get_state_paths(self, *, rpc_callback_supported: bool | None = None) -> tuple[str, ...]:
        """Return the data point paths."""
        data_point_paths: list[str] = []
        for device in self._device_registry.devices:
            if rpc_callback_supported is None or device.client.capabilities.rpc_callback == rpc_callback_supported:
                data_point_paths.extend(device.data_point_paths)
        data_point_paths.extend(self._hub_coordinator.data_point_paths)
        return tuple(data_point_paths)

    def get_un_ignore_candidates(self, *, include_master: bool = False) -> list[str]:
        """Return the candidates for un_ignore."""
        candidates = sorted(
            # 1. request simple parameter list for values parameters
            self.get_parameters(
                paramset_key=ParamsetKey.VALUES,
                operations=(Operations.READ, Operations.EVENT),
                un_ignore_candidates_only=True,
            )
            # 2. request full_format parameter list with channel wildcard for values parameters
            + self.get_parameters(
                paramset_key=ParamsetKey.VALUES,
                operations=(Operations.READ, Operations.EVENT),
                full_format=True,
                un_ignore_candidates_only=True,
                use_channel_wildcard=True,
            )
            # 3. request full_format parameter list for values parameters
            + self.get_parameters(
                paramset_key=ParamsetKey.VALUES,
                operations=(Operations.READ, Operations.EVENT),
                full_format=True,
                un_ignore_candidates_only=True,
            )
        )
        if include_master:
            # 4. request full_format parameter list for master parameters
            candidates += sorted(
                self.get_parameters(
                    paramset_key=ParamsetKey.MASTER,
                    operations=(Operations.READ,),
                    full_format=True,
                    un_ignore_candidates_only=True,
                )
            )
        return candidates

    def _skip_un_ignore_candidate(
        self,
        *,
        parameter: str,
        channel_address: str,
        paramset_key: ParamsetKey,
        ignore_set: frozenset[Parameter],
    ) -> bool:
        """Return True when a parameter should be skipped for un-ignore candidate filtering."""
        # Cheap check first to avoid expensive dp lookup when possible
        if parameter in ignore_set:
            return True
        dp = self.get_generic_data_point(
            channel_address=channel_address,
            parameter=parameter,
            paramset_key=paramset_key,
        )
        return bool(dp and dp.enabled_default and not dp.is_un_ignored)
