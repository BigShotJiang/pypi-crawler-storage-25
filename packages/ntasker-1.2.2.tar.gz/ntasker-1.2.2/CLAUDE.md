# ntasker — Workflow Rules

Lightweight local task tracker. Single-user, no auth, bound to `127.0.0.1:8766`.
**This file = workflow only.** API and schema knowledge live in
`~/.claude/skills/ntasker/SKILL.md`.

## Stack

- **Backend:** FastAPI + Python stdlib `sqlite3` (no ORM, no Alembic).
- **Frontend:** AlpineJS + Tabler.io, vendored to `src/ntasker/static/vendor/`. No build step, no CDN at runtime.
- **Templating:** Jinja2.
- **Layout:** PyPA src-layout; package = `src/ntasker/`. CLI entry `ntasker = ntasker.cli:main`.
- **Bind:** `127.0.0.1:8766` (default; overridable via `ntasker serve --host --port`).

## DB path -- precedence

1. CLI flag `--db <path>`.
2. ENV `NTASKER_DB`.
3. `platformdirs.user_data_dir("nTasker") / "tasks.db"` (Linux: `~/.local/share/nTasker/tasks.db`).

Resolution lives in `src/ntasker/paths.py`. Parent dir is created on demand.

## Versioning -- single source of truth

`__version__` in `src/ntasker/__init__.py` is canonical. Sources that read it:

1. FastAPI `version=` (OpenAPI / startup logs).
2. Jinja template context as `version`.
3. CLI `--version`.
4. `?v={{ version }}` cache-buster on every `<link>` / `<script>` URL in templates.

`pyproject.toml`'s `version` field MUST be kept in sync with `__version__`.

`templates/index.html` and `templates/settings.html` are served with
`Cache-Control: no-store` so a version bump reliably forces clients to refetch CSS/JS.

## Schema migrations

Idempotent on app boot inside `ntasker.db.init_db()`. Pattern: try the new column,
catch `sqlite3.OperationalError` on "no such column" / "duplicate column",
no-op. **No Alembic. No migration files.**

## Settings module

KV-store with validators (`src/ntasker/settings.py`). Validators registered
in `VALIDATORS` dict; unknown keys are still writable but bypass validation.
`get_setting(key, env_var=...)` checks ENV first, then DB, then `None`.

UI: `/settings` (Tabler page, AlpineJS).
API: `GET/PUT/DELETE /api/settings[/<key>]`.
CLI: `ntasker config (list|get|set|unset)`.

## Workflow for changes

1. Implement the feature or fix.
2. Ask user: **"shall I commit as v<x.y.z>?"** -- wait for explicit OK.
3. On OK:
   - Bump `__version__` in `src/ntasker/__init__.py`.
   - Bump `version` in `pyproject.toml`.
   - Prepend a one-liner to `CHANGELOG.md` under a new version section.
4. **Always invoke git as `git -C path/to/ntasker <cmd>`** --
   never `cd && git`. Permission rules in `.claude/settings.local.json` are
   pinned to this exact pattern.
5. Commit + tag sequence:
   ```
   git -C path/to/ntasker/ntasker add <files>
   git -C path/to/ntasker/ntasker commit -m "release: v<x.y.z> -- <one-liner>"
   git -C path/to/ntasker/ntasker tag -a v<x.y.z> -m "v<x.y.z>"
   ```
6. SemVer:
   - **PATCH** = bugfix.
   - **MINOR** = feature, no breaking change.
   - **MAJOR** = breaking change.

## Hard NOs

- Never `--no-verify`, `--no-gpg-sign`, force-push to main/master.
- Never `git config`, `git commit --amend`, `git rebase -i`.
- Never `cd path/to/ntasker/ntasker && git ...` -- permission pattern only matches `-C` form.
- `git push` to GitLab is allowed but **only on user's explicit OK** (Memory `feedback_tracker_repo_commits`).

## Skill crosslink

API endpoints, schema, sentinels, and tracker-specific UI conventions:
**`~/.claude/skills/ntasker/SKILL.md`**.
