# Everything in the Tick axes and Tick axis styling categories.
# Also the Color bars category.

# axshift
# textdist
# ticklen
# xaxis
# yaxis
# ytitlerot
# caxis
# overline
# xcaxis
# numformat
# overlinedist
# overlinemin

from . import qi
from . import style
from . import paper
from . import markup
from . import fig
from . import utils
from . import data
import numpy as np

def ytitlerot(phi=None):
    '''YTITLEROT - Specifies the rotation of y-axis titles
    
    YTITLEROT(phi) specifies the rotation of y-axis titles:
    Positive PHI means rotated 90 degrees counterclockwise.
    Negative PHI means rotated 90 degrees clockwise.
    Zero means upright.
    Rotation angles other than 0 and ±90° are not supported.
    
    PHI = YTITLEROT() returns current value.'''
    qi.ensure()
    if phi is None:
        phi = qi.f.ytitlerot
    else:
        qi.f.ytitlerot = np.sign(phi)*np.pi/2
    return phi


def axshift(shift=None):
    '''AXSHIFT - Specifies shift of drawn axis for XAXIS and YAXIS
    
    AXSHIFT(shift) specifies shift (in millimeters or points) for XAXIS and
    YAXIS. Positive means down or left, negative means up or right.
    
    shift = AXSHIFT() returns current setting.'''
    qi.ensure()
    if shift is None:
        return qi.f.axshift
    else:
        qi.f.axshift = shift

def textdist(lbldist=None, ttldist=None):
    '''TEXTDIST - Specify distance to text labels for XAXIS and YAXIS
    
    TEXTDIST(lbldist, ttldist) specifies distance between ticks and
    tick labels and between tick labels and axis title, in points.
    
    TEXTDIST(dist) uses DIST for both distances.
    
    Positive numbers are to the left and down; negative numbers are to the
    right and up.
    
    (LBLDIST, TTLDIST) = TEXTDIST() returns current settings.'''

    qi.ensure()
    if lbldist is None and ttldist is None:
        lbldist = qi.f.textdist[0]
        ttldist = qi.f.textdist[1]
        return (lbldist, ttldist)
    if lbldist is None:
        lbldist = qi.f.textdist[0]
    if ttldist is None:
        ttldist = lbldist
    qi.f.textdist = (lbldist, ttldist)


def ticklen(tlen=None):
    '''TICKLEN - Specifies length of ticks for XAXIS and YAXIS
    
    TICKLEN(tlen) specifies length of ticks (in millimeters or points)
    for XAXIS and YAXIS. Positive means down or left, negative means
    up or right.
    
    tlen = TICKLEN() returns current setting.

    '''
    qi.ensure()
    if tlen is None:
        tlen = qi.f.ticklen
        return tlen
    else:
        qi.f.ticklen = tlen

        
def _align(hori, dx, dy=None):
    if dy is None:
        dy = dx
    xa = 'center';
    ya = 'middle';
    if hori:
        if dy>0:
            ya = 'top';
        else:
            ya = 'bottom';
    else:
        if dx>0:
            xa = 'left';
        else:
            xa = 'right';
    return (xa, ya)


def _qaxis(orient='x', lim_d=None,
           tick_d=None, tick_p=None,
           tick_lbl=None, ttl='',
           ticklen=None, lbldist=None, ttldist=None,
           coord_d=None, coord_p=0,
           ttlrot=0,
           cbar=None,
           microshift=False):
    '''_QAXIS - Internal backend for axis rendering
    _QAXIS(...) draws an axis according to the parameters:
      orient: 'x' or 'y'
      lim_d (2) limits of the axis in data coordinates (in the direction
                of ORIENT)
      tick_d (N) data coordinates (in the direction of ORIENT) of ticks
      tick_p (N) shift of those coords in paper coordinates
      tick_lbl (N strings) labels to be placed at those ticks
      ttl (string) title
      ticklen (scalar) length of ticks, +ve is down/right
      lbldist (scalar) dist b/w labels and axis/ticks, +ve is down/right
      ttldist (scalar) dist b/w title and labels/axis/ticks, +ve is down/right
      coord_d (scalar) position of the axis in data coords (in the direction
                       orthogonal to ORIENT)
      coord_p (scalar) shift of that position in paper coordinates
      ttlrot (scalar) rotation of title: 0=normal +ve=CCW -ve=CW
      cbar (struct) optional reference to colorbar
      microshift (boolean or tuple of two booleans) shift ticks by half 
                       linewidth'''

    qi.ensure()
    if ticklen is None:
        ticklen = 3*qi.f.pt
    if lbldist is None:
        lbldist = 3*qi.f.pt
    if ttldist is None:
        ttldist = 3*qi.f.pt
    qi.f.lastax = { 'orient': orient,
                    'lim_d': lim_d,
                    'tick_d': tick_d,
                    'tick_p': tick_p,
                    'tick_lbl': tick_lbl,
                    'ttl': ttl,
                    'ticklen': ticklen,
                    'lbldist': lbldist,
                    'ttldist': ttldist,
                    'coord_d': coord_d,
                    'coord_p': coord_p,
                    'ttlrot': ttlrot,
                    'cbar': cbar,
                    'microshift': microshift }
    
    if orient=='x':
        ishori=1
        isvert=0
    elif orient=='y':
        ishori=0
        isvert=1
    else:
        qi.error("orient must be 'x' or 'y'")

    if type(microshift)==tuple or type(microshift)==list:
        pass
    else:
        microshift = [microshift, microshift]

    if callable(tick_d):
        tick_d = np.array([tick_d(lbl) for lbl in tick_lbl])
    if tick_d is None:
        tick_d = np.zeros(tick_p.shape) + np.nan
    else:
        tick_d = np.array(tick_d)
        if tick_p is None:
            tick_p = np.zeros(tick_d.shape)
            if microshift[0]:
                shf0 = .5*qi.f.linewidth
            else:
                shf0 = 0
            if microshift[1]:
                shf1 = -.5*qi.f.linewidth
            else:
                shf1 = 0
            if orient=='y':
                shf0, shf1 = -shf0, -shf1
            if len(tick_p)>1:    
                for k in range(len(tick_p)):
                    a = (tick_d[k] - tick_d[0]) / (tick_d[-1] - tick_d[0])
                    tick_p[k] += (1-a)*shf0 + a*shf1
                
    fig.group()
    
    tickdx = tick_d
    tickdy = np.zeros(tickdx.shape) + coord_d
    tickpx = tick_p
    tickpy = np.zeros(tickpx.shape) + coord_p
    ticklx = 0
    tickly = ticklen
    lbllx = 0
    lblly = lbldist
    
    if np.sign(tickly)==np.sign(lblly):
        lblly = lblly + tickly
        
    # Axis line position (x and y may be flipped later!)
    if ishori:
        xf, yf = qi.f.xtransform, qi.f.ytransform
    else:
        yf, xf = qi.f.xtransform, qi.f.ytransform
        
    limdx = lim_d
    limdy = coord_d + np.zeros((2))
    limpx = np.zeros((2))
    if microshift[0]:
        limpx[0] += qi.f.linewidth/2
    if microshift[1]:
        limpx[1] -= qi.f.linewidth/2
    limpy = coord_p + np.zeros((2))
    
    if lim_d is not None and len(lim_d):
        ttldx = np.mean(xf(limdx))
    elif tick_d is not None and len(tick_d):
        ttldx = np.mean(xf([tickdx[0], tickdx[-1]]))
    else:
        ttldx = np.nan
    ttldy = yf(coord_d)
        
    if tick_p is not None and len(tick_p):
        ttlpx = np.mean([tickpx[0], tickpx[-1]])
    else:
        ttlpx = 0
    ttlpy = coord_p
        
        
    # Draw an axis line if desired
    if lim_d is not None and len(lim_d)>0:
        if isvert:
            (limdx, limdy) = (limdy, limdx)
            (limpx, limpy) = (limpy, -limpx)
        paper.gline2([paper.AbsData(limdx, limdy),
                      paper.RelPaper(limpx, limpy)])
            
    # Draw ticks if desired
    if isvert:
        (tickdx, tickdy) = (tickdy, tickdx)
        (tickpx, tickpy) = (tickpy, tickpx)
        (ticklx, tickly) = (tickly, ticklx)
        (lbllx, lblly)   = (lblly, lbllx)
    if ticklen!=0:
        for k in range(len(tickdx)):
            paper.gline([[paper.AbsData(tickdx[k],
                                        tickdy[k]),
    	                 paper.RelPaper(tickpx[k],
                                        tickpy[k]*qi.Figure.ydown)],
                        [paper.AbsData(tickdx[k],
                                       tickdy[k]),
    	                 paper.RelPaper(tickpx[k]+ticklx,
                                        (tickpy[k]+tickly)*qi.Figure.ydown)]])
            
    # Draw labels if desired
    if callable(tick_lbl):
        tick_lbl = [ tick_lbl(x) for x in tick_d ]

    if not utils.isempty(tick_lbl):
        fig.group()
        [xa, ya] = _align(ishori, lbllx, lblly)
        markup.align(xa, ya)
        if ishori:
            reftxt=[]
            for lbl in tick_lbl:
                if type(lbl)!=str:
                    lbl = qi.f.numfmt % lbl
                try:
                    v = float(lbl)
                    if v<0:
                        lbl += ' '
                except:
                    pass
            reftxt.append(lbl)
            markup.reftext(' '.join(reftxt))
                    
        for k in range(len(tick_lbl)):
            markup.at(tickdx[k], tickdy[k]*qi.Figure.ydown)
            lbl = tick_lbl[k]
            if type(lbl)!=str:
                lbl = qi.f.numfmt % lbl
            markup.text(lbl, dx=tickpx[k] + lbllx,
                        dy=(tickpy[k] + lblly)*qi.Figure.ydown)
            
        markup.reftext('')
        fig.endgroup()
        
    # Draw title if desired
    if not utils.isempty(ttl):
        ttllx = 0
        ttlly = ttldist
        if isvert:
            (ttlpx, ttlpy) = (ttlpy, ttlpx)
            (ttllx, ttlly) = (ttlly, ttllx)
            (ttldx, ttldy) = (ttldy, ttldx)
            
        if utils.isempty(tick_lbl) or np.sign(ttldist)!=np.sign(lbldist):
            # Ignore labels when placing title: not on same side
            if np.sign(ttldist)==np.sign(ticklen):
                ttllx = ttllx + ticklx
                ttlly = ttlly + tickly
            markup.at(ttldx, ttldy, phi=-np.pi/2*np.sign(ttlrot),
                      notransform=True)
        else:
            if ishori:
                ttlpy = 0
            else:
                ttlpx = 0
            [xa, ya] = _align(ishori, -ttldist)
            if ishori:
                markup.at(ttldx, ya, phi=-np.pi/2*np.sign(ttlrot),
                          notransform=True)
            else:
                markup.at(xa, ttldy, phi=-np.pi/2*np.sign(ttlrot),
                          notransform=True)
        if ttlrot==0:
            xa, ya = _align(ishori, ttldist)
        else:
            xa, ya = _align(isvert, ttldist*np.sign(ttlrot))
        markup.align(xa, ya)
        markup.reftext("+Xj")
        if ttlrot:
            markup.text(ttl,
                 dx=-np.sign(ttlrot)*(ttlpy+ttlly), 
    	         dy=np.sign(ttlrot)*(ttlpx+ttllx))
        else:
            markup.text(ttl, dx=ttlpx + ttllx, dy=ttlpy + ttlly)
    fig.endgroup()

def xaxis(title='', ticks=None, labels=None, y=0, lim=None, flip=False,
          ticklen=None, axshift=None, lbldist=None, ttldist=None,
          microshift=False):
    '''XAXIS - Draw x-axis
    All arguments are optional.
      TITLE specifies title for axis.
      TICKS specifies positions of ticks along axis. If None, ticks are 
        inferred using SENSIBLETICKS. If [], no ticks are drawn.
      LABELS specifies labels to put by ticks. If None, tick coordinates
        are used. If [], no labels are drawn.
      Y specifies intersect with y-axis in data coordinates. Default is 
        zero. Set to None to automatically position below the data.
      LIM specifies left and right edges as a tuple or list. If None, LIM
        is determined from TICKS. If [], no line is drawn.
      FLIP, if True, inverts the sign of the settings from TICKLEN,
        TEXTDIST, and AXSHIFT.
      TICKLEN and AXSHIFT override the values from the 
        corresponding command.
      LBLDIST and TTLDIST override the values from TEXTDIST.
      MICROSHIFT, if True, specifies that the ticks are to be shifted by
        up to half a linewidth so they don't protrude horizontally past the
        ends of the range. This is useful when drawing an axis by an image.
        May also be a 2-ple specifying behavior for the left and right
        ends separately.
    Either TICKS or LABELS (but not both) may be a function, in which case
    the labels are calculated from the tick positions (or vice versa). For
    example:

      XAXIS('Value (%)', labels=np.arange(0,101,25), ticks=lambda x: x/100)

    Without any arguments or with just a title as an argument, XAXIS tries
    to determine sensible defaults based on previous calls to PLOT and
    friends. Your mileage may vary.'''
    
    qi.ensure()
    if y is None:
        if qi.f.datarange is None:
            y = 0
        else:
            y = utils.sensibleticks(qi.f.datarange[2:], 1, inc=True)[0]
    if lim is None and ticks is None:
        # If neither lim nor ticks given, lim is inclusive of range
        lim = qi.f.datarange[:2]
    if ticks is None:
        ticks = utils.sensibleticks(qi.f.datarange[:2])
    if lim is None:
        if callable(ticks):
            lim = [ticks(labels[0]), ticks(labels[-1])]
        else:
            lim = [ticks[0], ticks[-1]]
    if labels is None:
        labels = qi.f.format(ticks)
    if ticklen is None:
        ticklen = qi.f.ticklen
    if axshift is None:
        axshift = qi.f.axshift
    if lbldist is None:
        lbldist = qi.f.textdist[0]
    if ttldist is None:
        ttldist = qi.f.textdist[1]
    if flip:
        ticklen = -ticklen
        axshift = -axshift
        lbldist = -lbldist
        ttldist = -ttldist
    
    _qaxis(orient='x', lim_d=lim, tick_d=ticks, tick_lbl=labels, ttl=title, 
            ticklen=ticklen, lbldist=lbldist, ttldist=ttldist, 
            coord_d=y, coord_p=axshift, microshift=microshift)

def yaxis(title='', ticks=None, labels=None, x=0, lim=None, flip=False,
          ticklen=None, axshift=None, lbldist=None, ttldist=None,
          titlerot=None, microshift=False):
    '''YAXIS - Draw y-axis
    All arguments are optional.
      TITLE specifies title for axis.
      TICKS specifies positions of ticks along axis. If None, ticks are 
        inferred using SENSIBLETICKS. If [], no ticks are drawn.
      LABELS specifies labels to put by ticks. If None, tick coordinates
        are used. If [], no labels are drawn.
      X specifies intersect with x-axis in data coordinates. Default is 
        zero. Set to None to automatically position to the left of the data.
      LIM specifies bottom and top edges as a tuple or list. If None, LIM
        is determined from TICKS. If [], no line is drawn.
      FLIP, if nonzero, inverts the sign of the settings from TICKLEN,
        TEXTDIST, and AXSHIFT. If FLIP=2, the title is flipped as well.
      TICKLEN and AXSHIFT override the values from the 
        corresponding command.
      LBLDIST and TTLDIST override the values from TEXTDIST.
      TITLEROT overrides the value from YTITLEROT.
      MICROSHIFT, if True, specifies that the ticks are to be shifted by
        up to half a linewidth so they don't protrude vertically past the
        ends of an image. May also be a 2-ple specifying behavior for the
        bottom and top ends separately.
    Either TICKS or LABELS (but not both) may be a function, in which case
    the labels are calculated from the tick positions (or vice versa). For
    example:

      YAXIS('Value (%)', labels=np.arange(0,101,25), ticks=lambda x: x/100)

    Without any arguments or with just a title as an argument, YAXIS tries
    to determine sensible defaults based on previous calls to PLOT and
    friends. Your mileage may vary.'''
    qi.ensure()
    if x is None:
        if qi.f.datarange is None:
            x = 0
        else:
            x = utils.sensibleticks(qi.f.datarange[:2], 1, inc=True)[0]
    if lim is None and ticks is None:
        # If neither lim nor ticks given, lim is inclusive of range
        lim = qi.f.datarange[2:]
    if ticks is None:
        ticks = utils.sensibleticks(qi.f.datarange[2:])
    if lim is None:
        if callable(ticks):
            lim = [ticks(labels[0]), ticks(labels[-1])]
        else:
            lim = [ticks[0], ticks[-1]]
    if labels is None:
        labels = qi.f.format(ticks)
    if titlerot is None:
        lblrot = ytitlerot()
    else:
        lblrot = titlerot
    if ticklen is None:
        ticklen = qi.f.ticklen
    if axshift is None:
        axshift = qi.f.axshift
    if lbldist is None:
        lbldist = qi.f.textdist[0]
    if ttldist is None:
        ttldist = qi.f.textdist[1]
    
    if flip==False:
        ticklen = -ticklen
        axshift = -axshift
        lbldist = -lbldist
        ttldist = -ttldist
    elif flip==2:
        lblrot = -lblrot
    
    _qaxis(orient='y', lim_d=lim, tick_d=ticks, tick_lbl=labels, ttl=title, 
            ticklen=ticklen, lbldist=lbldist, ttldist=ttldist, 
            coord_d=x, coord_p=axshift, ttlrot=lblrot, microshift=microshift)

def minorticks(xx, ticklen=None):
    '''MINORTICKS - Add more ticks to an existing axis
    MINORTICK(xx, ticklen) adds minor ticks at XX. Must be called after a 
    call to XAXIS or YAXIS. Typically, you'd set TICKLEN to a smaller value
    than what was used for the major ticks. Defaults to 2/3 of the figure's
    TICKLEN setting.'''
    
    qi.ensure()
    if qi.f.lastax is None:
        qi.error('No previous axis')
    
    kv = qi.f.lastax
    if ticklen is None:
        ticklen = qi.f.lastax['ticklen'] * 2./3
    if kv['cbar'] is not None:
        xx = kv['cbar'].ctodat(xx)
    _qaxis(orient=kv['orient'], tick_d=xx, tick_lbl=[], ticklen=ticklen,
            coord_d=kv['coord_d'], coord_p=kv['coord_p'])

def caxis(title=None, ticks=None, labels=None, lim=None, flip=False,
          ticklen=None, axshift=None, lbldist=None, ttldist=None, titlerot=None,
          microshift=True):
    '''CAXIS - Plot colorbar axis
    CAXIS plots a colorbar axis alongside the most recent CBAR or HCBAR.
    All arguments are optional.
      TITLE specifies a title for the axis.
      TICKS specifies the locations of the ticks in terms of the data
        represented in the IMSC for which the colorbar was drawn.
      LABELS specifies labels to be written by those ticks. If None, 
        labels are derived from TICKS. If [], no labels are written.
      LIM specifies the ends of the axis, again in terms of the data
        represented in the IMSC.
      FLIP specifies that the axis is rendered to the left or above the
        bar rather than to the right or below.
      TICKLEN and AXSHIFT override the values from the 
        corresponding command.
      LBLDIST and TTLDIST override the values from TEXTDIST.
      TITLEROT overrides the value from YTITLEROT.
      MICROSHIFT (default true) specifies that the ticks are to be shifted
        by up to half a linewidth so they don't protrude past the bar's ends.

    CAXIS interprets settings from TICKLEN, TEXTDIST, and AXSHIFT
    differently from XAXIS and YAXIS: positive values are away from
    the colorbar.  Note that MINORTICKS currently doesn't understand
    about this convention, so MINORTICKS may produce unexpected
    results when used with CAXIS.'''

    qi.ensure()
    cb = qi.f.cbar
    if cb is None:
        qi.error('CAXIS needs a previous CBAR or HCBAR')
    if lim is None:
        lim = cb.clim
    if ticks is None:
        ticks = utils.sensibleticks(lim)
    if labels is None:
        labels = ticks

    if ticklen is None:
        ticklen = qi.f.ticklen
    if axshift is None:
        axshift = qi.f.axshift
    if lbldist is None:
        lbldist = qi.f.textdist[0]
    if ttldist is None:
        ttldist = qi.f.textdist[1]

    if cb.orient=='y':
        if titlerot is None:
            ttlrot = ytitlerot()
        else:
            ttlrot = titlerot
        coord_d = cb.drect[0]
        coord_p = cb.prect[0]
        if flip:
            ticklen = -ticklen
            ttlrot = -ttlrot
            coord_p -= axshift
        else:
            coord_p += cb.prect[2] + axshift
    elif cb.orient=='x':
        ttlrot = 0
        coord_d = cb.drect[1]
        coord_p = cb.prect[1]
        if flip:
            ticklen = -ticklen
            coord_p -= axshift
        else:
            coord_p += cb.prect[3] + axshift
    else:
        qi.error('Orientation not understood')

    lim = cb.ctodat(lim)
    ticks = cb.ctodat(ticks)
    
    _qaxis(orient=cb.orient, lim_d=lim, tick_d=ticks, tick_lbl=labels,
            ttl=title, 
            ticklen=ticklen, lbldist=lbldist, ttldist=ttldist, 
            coord_d=coord_d, coord_p=coord_p, ttlrot=ttlrot,
            microshift=microshift)
    qi.f.lastax['cbar'] = cb
        
def numformat(fmt=None):
    '''NUMFORMAT - Specifies the format of numbers as tick labels
    
    NUMFORMAT(fmt) specifies the format of numeric axis tick labels.
    FMT may be anything that python's "%" operator understands,
    for instance: "%.1f". The default is "%g".
    
    FMT = NUMFORMAT() returns current setting.'''
    qi.ensure()
    if fmt is not None:
        if utils.isempty(fmt):
            fmt = '%g'
        qi.f.numfmt = fmt
    return qi.f.numfmt

def overlinedist(dist=None):
    '''OVERLINEDIST - Distance between OVERLINEs and data
    
    OVERLINEDIST(dist) specifies the distance between OVERLINEs and 
    the data, (in millimeters or points).
    
    DIST = OVERLINEDIST() returns current setting.'''
    qi.ensure()
    if dist is None:
        return qi.f.overlinedist        
    qi.f.overlinedist = np.abs(dist)
   
    
def overlinemin(length=None):
    '''OVERLINEMIN - Specifies minimum vertical length for OVERLINEs
    
    OVERLINEMIN(length) specifies the minimum vertical length of OVERLINEs,
    (in millimeters or points).
    
    length = OVERLINEMIN() returns current setting.'''
    qi.ensure()
    if length is None:
        return qi.f.overlinemin
    qi.f.overlinemin = length


def overline(xx, yy, text=None, datadist=None, textdist=None, minlen=None):
    '''OVERLINE - Draw a line above data with a text above it
    
    OVERLINE([x1, x2], y, text), draws a horizontal line just above
    (X1, Y) to (X2, Y) and places the given TEXT over it.
    
    OVERLINE([x1, x2], [y1, y2], text), draws the line just above
    the larger y-value and extends a vertical line down to the
    smaller y-value.
    
    The whole thing is displaced by a distance OVERLINEDIST from the data,
    and the text placement uses the absolute value of TEXTDIST.
    
    If OVERLINEMIN is non-zero, a vertical line is drawn on both ends.
    
    The TEXT argument may be omitted.
    
    Optional arguments DATADIST, TEXTDIST, and MINLEN override global
    settings.

    '''
    qi.ensure()
    if datadist is None:
        datadist = qi.f.overlinedist
    if textdist is None:
        textdist = qi.f.textdist[0]
    if minlen is None:
        minlen = qi.f.overlinemin
    yy = np.array(utils.aslist(yy))
    ymax = np.max(yy)
    if len(yy)==2:
        paper.shiftedline(np.array([xx[0], xx[0], xx[1], xx[1]]),
                          np.array([yy[0], ymax, ymax, yy[1]]),
                          np.array([0,0,0,0]),
                          qi.Figure.yup*np.array([datadist,
                                                  datadist + minlen,
                                                  datadist + minlen,
                                                  datadist]))
    elif minlen>0:
        paper.shiftedline(np.array([xx[0], xx[0], xx[1], xx[1]]),
                          np.array([ymax, ymax, ymax, ymax]),
                          np.array([0,0,0,0]),
                          qi.Figure.yup*np.array([datadist,
                                                  datadist + minlen,
                                                  datadist + minlen,
                                                  datadist]))
    else:
        paper.shiftedline(np.array([xx[0], xx[1]]),
                          np.array([ymax, ymax]),
                          np.array([0,0]),
                          qi.Figure.yup*np.array([datadist + minlen,
                                                  datadist + minlen]))
    
    if text is not None:
        markup.at((xx[0]+xx[1])/2, ymax)
        td = np.abs(textdist)
        markup.align('center', 'bottom')
        markup.text(text, dy=qi.Figure.yup*(datadist + minlen + td))

def xcaxis(title='', ticks=None, labels=None, y=0, lim=None, flip=False,
           ticklen=None, axshift=None, lbldist=None, ttldist=None,
           microshift=False):
    '''XCAXIS - Plot x-axis with labels between ticks
    XCAXIS plots an x-axis with labels at specfied positions but ticks
    between the labels rather than at the label positions. First and
    last tick positions are extrapolated.
    All arguments are optional.
      TITLE specifies title for axis.
      TICKS specifies locations for the labels.
      LABELS specifies the label texts.
      Y specifies intersect with y-axis. Default is zero.
        If None, defaults to a reasonable position below the data.
      LIM overrides the default positions of the first and last ticks.
      FLIP, if True, inverts the sign of the settings from TICKLEN, 
        TEXTDIST, and AXSHIFT.
    XCAXIS obeys settings from TICKLEN, TEXTDIST, and AXSHIFT.'''
    qi.ensure()
    if y is None:
        yy = utils.sensibleticks(qi.f.datarange[2:4], 1)
        y = yy[0]
    if labels is None:
        labels = qi.f.format(ticks)
    if ticklen is None:
        ticklen = qi.f.ticklen
    if axshift is None:
        axshift = qi.f.axshift
    if lbldist is None:
        lbldist = qi.f.textdist[0]
    if ttldist is None:
        ttldist = qi.f.textdist[1]

    
    if flip:
        ticklen = -ticklen
        axshift = -axshift
        lbldist = -lbldist
        ttldist = -ttldist

    ticks = np.array(ticks)
    btwnx = (ticks[0:-1] + ticks[1:])/2
    if lim is None:
        avg = np.mean(np.diff(ticks))
        lim = (btwnx[0]-avg, btwnx[-1]+avg)

    tickx = np.concatenate(([lim[0]], btwnx, [lim[1]]))

    # Place labels, do not draw bar
    _qaxis(orient='x', tick_d=ticks, tick_lbl=labels, ttl=title,
            ticklen=0, lbldist=lbldist+ticklen, ttldist=ttldist,
            coord_d=y, coord_p=axshift)
    # Place ticks, draw bar
    _qaxis(orient='x', lim_d=lim, tick_d=tickx, tick_lbl='',
            ticklen=ticklen,
            coord_d=y, coord_p=axshift, microshift=microshift)

def ycaxis(title='', ticks=None, labels=None, x=0, lim=None, flip=False,
           ticklen=None, axshift=None, lbldist=None, ttldist=None,
           microshift=False):
    '''YCAXIS - Plot y-axis with labels between ticks
    YCAXIS plots an y-axis with labels at specfied positions but ticks
    between the labels rather than at the label positions. First and
    last tick positions are extrapolated.
    All arguments are optional.
      TITLE specifies title for axis.
      TICKS specifies locations for the labels.
      LABELS specifies the label texts.
      X specifies intersect with x-axis. Default is zero.
        If None, defaults to a reasonable position left of the data.
      LIM overrides the default positions of the first and last ticks.
      FLIP, if True, inverts the sign of the settings from TICKLEN, TEXTDIST,
        and AXSHIFT.
    YCAXIS obeys settings from TICKLEN, TEXTDIST, and AXSHIFT.'''
    qi.ensure()
    if x is None:
        xx = utils.sensibleticks(qi.f.datarange[0:2], 1)
        x = xx[0]

    if labels is None:
        labels = qi.f.format(ticks)
    if ticklen is None:
        ticklen = qi.f.ticklen
    if axshift is None:
        axshift = qi.f.axshift
    if lbldist is None:
        lbldist = qi.f.textdist[0]
    if ttldist is None:
        ttldist = qi.f.textdist[1]

    lblrot = ytitlerot()
    if flip==0:
        ticklen = -ticklen
        axshift = -axshift
        lbldist = -lbldist
        ttldist = -ttldist
    elif flip==2:
        lblrot = -lblrot

    ticks = np.array(ticks)
    btwnx = (ticks[0:-1] + ticks[1:])/2
    if lim is None:
        avg = np.mean(np.diff(ticks))
        lim = (btwnx[0]-avg, btwnx[-1]+avg)

    ticky = np.concatenate(([lim[0]], btwnx, [lim[1]]))

    # Place labels, do not draw bar
    _qaxis(orient='y', tick_d=ticks, tick_lbl=labels, ttl=title,
            ticklen=0, lbldist=lbldist+ticklen, ttldist=ttldist,
            coord_d=x, coord_p=axshift, ttlrot=lblrot)
    # Place ticks, draw bar
    _qaxis(orient='y', lim_d=lim, tick_d=ticky, tick_lbl='',
           ticklen=ticklen,
           coord_d=x, coord_p=axshift, ttlrot=lblrot,
           microshift=microshift)

    
def zaxis(title, ticks, proj, labels=None, x=0, y=0, lim=None, below=False):
    '''ZAXIS - Draw a z-axis.
    ZAXIS(title, ticks, proj) where PROJ=(x_z, y_z), draws a z-axis projected
    onto the paper plane by
      x' = x + x_z * z
      y' = y + y_z * z.
    Optional argument LABELS specifies axis labels.
    Optional arguments X and Y specify the X and Y intercept of the axis.
    Optional argument LIM specifies limits for the axis.
    Optional argument BELOW specifies ticks and labels go below rather than
    to the left.
    Unlike XAXIS and YAXIS, ZAXIS cannot by itself find reasonable defaults
    for its main arguments.
    ZAXIS supports TEXTDIST and TICKLEN, but not AXSHIFT.
    Caution: positioning of zaxis titles may well change in a future version.'''

    qi.ensure()
    if callable(ticks):
        ticks = np.array([ ticks(lbl) for lbl in labels ])
    if callable(labels):
        labels = [ labels(z) for z in ticks ]
    elif labels is None:
        labels = [ qi.f.numfmt % z for z in ticks ]
    if lim is None:
        lim = (ticks[0], ticks[-1])
    if not utils.isempty(lim):
        # Draw the line
        data.plot(x + proj[0]*np.array(lim), y + proj[1]*np.array(lim))
    if below:
        relp = paper.RelPaper([0, 0], [0, qi.Figure.ydown*qi.f.ticklen])
    else:
        relp = paper.RelPaper([0, qi.Figure.yup*qi.f.ticklen], [0, 0])
    if not utils.isempty(ticks):
        for z in ticks:
            paper.gline2([paper.AbsData([x + proj[0]*z, x + proj[0]*z],
                                        [y + proj[1]*z, y + proj[1]*z]),
                          relp])
                              
    if not utils.isempty(labels):
        (lbld, ttld) = textdist()
        if below:
            markup.align('center', 'top')
            dx = 0
            dy = qi.Figure.ydown*(lbld + qi.f.ticklen)
        else:
            markup.align('right', 'middle')
            dx = -(lbld + qi.f.ticklen)
            dy = 0
        for k in range(len(ticks)):
            markup.at(x + proj[0]*ticks[k], y + proj[1]*ticks[k])
            markup.text(labels[k], dx=dx, dy=dy)
    if not utils.isempty(title):
        if utils.isempty(lim):
            z = ticks[-1] + (ticks[-1] - ticks[-2])
        elif utils.isempty(ticks):
            z = lim[1] # Deeply suboptimal...
        else:
            z = lim[1] + (ticks[-1] - ticks[-2])
        markup.at(x + proj[0]*z, y + proj[1]*z)
        markup.align('center', 'middle')
        markup.text(title)
        

def arange(start, end, step=1):
    '''ARANGE - Return evenly spaced values within interval
    
    xx = ARANGE(start, end, step) returns numbers in the closed interval
    [START, END] with a step size of STEP.
    
    This is similar to numpy's arange, but care is taken that the end
    point is included if STEP divides the interval evenly.  Also, the
    number zero is protected from numerical imprecision.

    '''
    return utils.arange(start, end, step)

