#!/usr/bin/env python3
import os
import sys
import json
import time
import subprocess
import concurrent.futures
from datetime import datetime

# ANSI colors
COLOR_GREEN = "\033[92m"
COLOR_YELLOW = "\033[93m"
COLOR_RED = "\033[91m"
COLOR_CYAN = "\033[96m"
COLOR_MAGENTA = "\033[95m"
COLOR_GRAY = "\033[90m"
COLOR_BOLD = "\033[1m"
COLOR_RESET = "\033[0m"

TIERS = [
    ["coreason-manifest", "coreason-sensory-core"],
    ["coreason-urn-authority", "coreason-ecosystem", "coreason-isv-admin", "coreason-sensory-app", "coreason-sensory-embed"],
    ["coreason-runtime"],
    ["coreason-meta-engineering", "coreason-documentation"],
    ["coreason-release-healer"]
]

ALL_REPOS = [repo for tier in TIERS for repo in tier]

def run_cmd(cmd):
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", check=True)
        return res.stdout.strip()
    except Exception as e:
        return f"ERROR: {e}"

def get_repo_status(repo):
    cmd = [
        "gh", "run", "list",
        "--repo", f"CoReason-AI/{repo}",
        "--limit", "5",
        "--json", "databaseId,status,conclusion,name,headBranch,createdAt"
    ]
    out = run_cmd(cmd)
    if "ERROR" in out or not out:
        return repo, {"status": "Unknown", "conclusion": "N/A", "run_id": None, "branch": "N/A", "name": "N/A"}
    try:
        runs = json.loads(out)
        if not runs:
            return repo, {"status": "No Runs", "conclusion": "N/A", "run_id": None, "branch": "N/A", "name": "N/A"}
        
        # Prioritize release/publish run
        selected_run = runs[0]
        for run in runs:
            r_name = (run.get("name") or "").lower()
            if any(kw in r_name for kw in ["release", "publish", "container"]):
                selected_run = run
                break
        
        return repo, {
            "status": selected_run.get("status", "Unknown"),
            "conclusion": selected_run.get("conclusion") or "pending",
            "run_id": selected_run.get("databaseId"),
            "branch": selected_run.get("headBranch", "N/A"),
            "name": selected_run.get("name", "N/A")
        }
    except Exception:
        return repo, {"status": "Error Parsing", "conclusion": "N/A", "run_id": None, "branch": "N/A", "name": "N/A"}

def load_release_state(workspace_dir):
    state_path = os.path.join(workspace_dir, ".coreason", "release_state.json")
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return None

def get_workspace_dir():
    cwd = os.getcwd()
    if os.path.exists(os.path.join(cwd, "coreason-release-healer")):
        return cwd
    return os.path.dirname(cwd) if os.path.exists(os.path.join(os.path.dirname(cwd), "coreason-release-healer")) else cwd

def main():
    # Set env var fallback to allow keyring auth for gh cli
    if "GITHUB_TOKEN" in os.environ:
        del os.environ["GITHUB_TOKEN"]

    workspace_dir = get_workspace_dir()
    state = load_release_state(workspace_dir)
    
    current_level = 0
    completed_repos_state = []
    versions = {}
    if state:
        current_level = state.get("current_level", 0)
        completed_repos_state = state.get("completed_repos", [])
        versions = state.get("new_versions", {})
        
    print(f"{COLOR_CYAN}{COLOR_BOLD}=== COREASON SYNCHRONIZED RELEASE TELEMETRY FEED ==={COLOR_RESET}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    print(f"{COLOR_BOLD}Fetching GitHub Actions statuses in parallel...{COLOR_RESET}")
    start_time = time.time()
    
    repo_statuses = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=11) as executor:
        futures = {executor.submit(get_repo_status, repo): repo for repo in ALL_REPOS}
        for future in concurrent.futures.as_completed(futures):
            repo, status = future.result()
            repo_statuses[repo] = status
            
    # Calculate progress metrics
    total_repos = len(ALL_REPOS)
    completed_count = 0
    
    # Render layout
    print(f"\n{COLOR_CYAN}{COLOR_BOLD}RELEASE PROGRESS DASHBOARD{COLOR_RESET}")
    print("=" * 95)
    
    for idx, tier in enumerate(TIERS):
        level = idx + 1
        is_current_level = (idx == current_level)
        is_past_level = (idx < current_level)
        
        level_status_str = ""
        if is_current_level:
            level_status_str = f"{COLOR_YELLOW}{COLOR_BOLD}[IN PROGRESS]{COLOR_RESET}"
        elif is_past_level:
            level_status_str = f"{COLOR_GREEN}{COLOR_BOLD}[COMPLETED]{COLOR_RESET}"
        else:
            level_status_str = f"{COLOR_GRAY}[PENDING]{COLOR_RESET}"
            
        print(f"\n{COLOR_BOLD}Level {level}:{COLOR_RESET} {level_status_str}")
        
        for repo in tier:
            # Determine state from state file and gh status
            gh_info = repo_statuses.get(repo, {})
            gh_status = gh_info.get("status", "Unknown")
            gh_conclusion = gh_info.get("conclusion", "N/A")
            version_str = f"v{versions.get(repo)}" if repo in versions else "vX.Y.Z"
            
            # Icon and status color
            status_color = COLOR_GRAY
            status_symbol = "[-] "
            
            # Check if completed in the orchestrator workflow
            is_completed_orchestrator = False
            if is_past_level or (is_current_level and repo in completed_repos_state):
                is_completed_orchestrator = True
                
            if is_completed_orchestrator:
                completed_count += 1
                
            if gh_status.lower() == "completed" and gh_conclusion.lower() == "success":
                status_color = COLOR_GREEN
                status_symbol = "[OK] "
            elif gh_status.lower() in ["in_progress", "queued", "waiting"]:
                status_color = COLOR_YELLOW
                status_symbol = "[>>] "
            elif gh_conclusion.lower() in ["failure", "failed"]:
                status_color = COLOR_RED
                status_symbol = "[ERR]"
                
            repo_disp = f"{repo} ({version_str})"
            run_details = ""
            if gh_info.get("run_id"):
                run_details = f" [Run: {gh_info['run_id']} - {gh_info['name'][:30]}]"
                
            print(f"  {status_color}{status_symbol} {repo_disp:<45} {gh_status.upper():<15} {gh_conclusion.upper():<10}{run_details}{COLOR_RESET}")
            
    print("\n" + "=" * 95)
    
    # Progress Bar
    pct = (completed_count / total_repos) * 100
    bar_width = 30
    filled = int(bar_width * completed_count // total_repos)
    bar = "#" * filled + "-" * (bar_width - filled)
    
    print(f"{COLOR_BOLD}Overall Coordinated Progress:{COLOR_RESET} |{COLOR_CYAN}{bar}{COLOR_RESET}| {pct:.1f}% ({completed_count}/{total_repos} packages complete)")
    print(f"Diagnostic fetch duration: {time.time() - start_time:.2f} seconds\n")

if __name__ == "__main__":
    main()
