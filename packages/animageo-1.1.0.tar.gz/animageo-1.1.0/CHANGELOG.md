# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] — 2026-04-29

Style-system release: semantic presets, per-type defaults, overlay parity for
GGB and DSL scenes, and a rewritten style guide. This release completes the
transition to the canonical style schema and removes the temporary alias and
normalization layer.

### Added

- **Semantic `presets` registry** — canonical style constants now live under
  `presets`: `presets.color`, `presets.point_size`, `presets.line_width`,
  `presets.angle_radius`, `presets.tick`, `presets.arrow`, and
  `presets.font_size`. Names such as `main`, `bold`, and `aux` are conventions;
  user-defined names are valid and can be referenced from other blocks.
- **Generic style references** — values like `presets.color.main`,
  `presets.line_width.bold`, and `presets.arrow.main` are resolved
  recursively by `StyleConfig`.
- **Structural preset includes** — per-type style maps can use `$include` to
  merge reusable structured presets, for example vector arrows and segment
  tick marks.
- **Scene background styling** — `rendering.background` accepts a hex color or
  a preset reference such as `presets.color.background` and is applied to the
  Manim camera background.
- **Canonical tick/arrow style keys** — renderers now understand
  `tick_length_px`, `tick_width_px`, `tick_shift_px`, `arrow_length_px`, and
  `arrow_width_px` through the resolver.

### Changed

- **`presets.color` is the only color registry** — builtin styles, examples,
  docs, and runtime access now use `presets.color`.
- **`defaults` is now a per-type baseline** — defaults choose or include
  semantic presets for element types (`point`, `segment`, `vector`, `angle`,
  etc.) instead of storing scene-level `angle` / `tick` / `arrow` / `font`
  knobs directly.
- **Overlay application order** — `overlay.per_type` and `overlay.per_name`
  apply uniformly to GGB-imported and DSL-created elements, with `per_name`
  winning over `per_type`.
- **Style import maps** — `import.colors`, `import.point_size`, and
  `import.line_width` accept fully qualified preset refs as well as bare
  preset names.
- **Documentation and examples** — README, style docs, field-name reference,
  migration guide, policy examples, and the HTML style guide were updated to
  the canonical `presets` schema.

### Removed

- Removed top-level `palette` and `palette.*` reference resolution.
  Use `presets.color` and `presets.color.<name>` references.
- Removed normalization of old scene-level `defaults` blocks for tick, arrow,
  font, and angle-radius settings. Use `presets.tick`, `presets.arrow`,
  `presets.font_size`, `presets.angle_radius`, and per-type `defaults`.
- Removed `strich_*_px` per-element aliases. Use `tick_length_px`,
  `tick_width_px`, and `tick_shift_px`.
- Removed public support for automation settings under `rendering`; use
  `overlay.angle_radius` and `overlay.label_placement`.

### Tests

- Full suite: `1013 passed` with Manim Community `0.19.0`.

## [1.0.2] — 2026-04-24

Security, correctness, dead-code cleanup and manim 0.20 compatibility pass.
Driven by a full library audit; every item below has a regression test.

### Removed (breaking)

- **`Construction.update_alpha` alias** — drop after the 1.0.1 restoration.
  Use ``update_tparam`` directly. All doc examples and HTML guides migrated.
- **`ggb_parser.get_alpha_from_*`** deprecated aliases. Use ``get_tparam_from_*``.
- **``animageo/_stubs.py``** — 613-line orphan IDE-stub snapshot that
  referenced pre-1.0 field names (``Measure.x``, ``Angle.angle``).
  Unreferenced from package; deleted.
- **``mult_ff`` / ``mult_fm`` / ``mult_mf`` / ``mult_if``** — unreachable from
  dispatch (``f`` was never registered in ``type_to_shortcut``); deleted.
- **Unused Lark parser block in ``ggb_parser.py``** (~130 lines: grammar +
  ``GeoGebraTransformer`` + ``parse_geogebra_xml``). Never called.
  ``lark`` removed from ``pyproject.toml`` dependencies.
- **DSL sandbox**: ``type`` and ``getattr`` removed from ``SAFE_BUILTINS``
  (classic sandbox escape via ``type(x).__mro__[-1].__subclasses__()``).
  Use ``isinstance(x, Cls)`` and the new ``type_name(x)`` DSL helper.
- **CLI ``-d/--debug`` flag** — semantic reversed to ``action='store_true'``
  (intuitive: ``-d`` turns debug ON). Previously was ``store_false`` which
  meant ``-d`` silenced debug output.

### Added

- **``AnimaGeoScene.resetScene()``** — explicit state wipe for reusing one
  scene instance across render jobs. Called automatically by ``loadGGB``.
- **``setElementStyle(..., update=True)`` / ``setVisible(..., update=True)``**
  — auto-rerender by default so changes are visible immediately.
  ``update=False`` defers for bulk operations.
- **``COMMAND_REGISTRY`` + ``list_commands()``** in ``lib_commands``. Dispatch
  uses the explicit registry instead of ``globals()``. Emits a warning when
  a command name doesn't match any implementation (previously silent ``None``).
- **Pixel-invariant decoration overrides** — per-element opt-in keys in
  ``elem.style``: ``strich_len_px`` / ``strich_rshift_px`` / ``arrow_width_px``
  / ``arrow_length_px``. When set, rendered at an absolute pixel size
  regardless of canvas ``ptUnit``. Scene-level defaults keep legacy
  scale-with-canvas semantics (backward-compatible).
- **DSL helper ``type_name(x)``** — returns ``type(x).__name__`` as a string.
  Safe stand-in for the removed ``type(x).__name__`` pattern.

### Fixed

- **Shell / Python injection in ``python -m animageo``** — CLI used
  ``os.system`` with f-string interpolation of user-supplied arguments into
  generated Python source. Rewritten to ``subprocess.run`` with argv-list
  and ``repr()``-escaped placeholders.
- **ZIP slip + zip bomb in ``.ggb`` loader** — ``ZipFile.extractall`` ran
  without path validation. New ``_safe_extract_ggb`` rejects traversal
  paths, absolute paths, archives with >4096 members, and >256 MB
  uncompressed total.
- **``loadGGB`` state leakage** — a second ``loadGGB`` on the same scene
  instance stacked new geometry on top of the old (visible as leftover
  elements from the prior file). Now starts from a fresh ``Construction``.
- **Global ``_bbox_cache`` thread-safety** in ``label_placement`` — added
  ``threading.Lock``; extended cache key with ``tex_template`` identity.
- **``Angle.equivalent`` / ``AngleSize.equivalent``** — used the non-existent
  ``.angle`` attribute; would raise ``AttributeError``. Now use ``.value``.
- **``are_congruent_aa`` / ``are_complementary_aa``** (``lib_commands``) —
  same ``.angle`` bug; 100% crash on any invocation. Fixed.
- **``_apply_interp_value`` for Measure vars** — wrote to ``.x``, which
  doesn't exist on ``Measure`` (phantom attribute created; real ``.value``
  unchanged). Keyframe animations on Measure variables were silently no-ops.
- **``Element.value()`` for Measure/AngleSize/Boolean** — circular import
  between ``lib_vars`` and ``lib_elements`` left those classes unbound at
  method-call time → ``NameError``. Fixed with local imports.
- **``font_size_px`` dead key** — builtin defaults and overlay shipped the
  key, but the renderer only read ``font_size`` (manim units), silently
  dropping pixel-invariant font overrides. Renderer and label placement
  now prefer ``font_size_px`` through the resolver.
- **``label_radial_offset_px``** — name said pixels, code treated value as
  manim units. ``5`` meant 5 MU ≈ 500 px. Now honoured as actual pixels.
- **Sandbox hardening** — see "Removed" above for ``type``/``getattr``.
- **Marching-squares ``_edge_point``** — unguarded divisions by corner-
  difference could yield ``inf``/``nan`` for near-coincident corner values.
  Now collapses to mid-edge.
- **``intersect_*`` near-zero endpoint detection** — ``if a == 0`` on a
  float could miss a true zero rounded to ±1e-17, losing a valid root.
  Replaced with ``abs(a) < 1e-12`` + symmetric case at the other endpoint.
- **``play_keyframes`` on a missing element** — silently skipped via
  ``info is None``; now logs a warning with context so debug traces aren't
  lost.

### Changed

- **Python requirement** relaxed from ``>=3.13`` to ``>=3.10``. Code uses
  PEP 604 unions and PEP 585 generics; no newer syntax.
- **Dependency pins** — ``numpy<3.0``, ``manim<0.20`` upper bounds added
  (manim has had breaking API changes between minor versions).
- **CLAUDE.md**: stale statistics removed (test count, render-method
  count); ``update_alpha`` alias reference replaced with historical note.
- **``style/schema.py``** doc table split into pixel-invariant vs
  scale-with-canvas unit classes (previously mixed).

### Docs

- ``docs/style_guide/assets/examples/src/anim_scenes.py`` (served download)
  was using pre-1.0 API names (``show_label``, ``stroke_width``,
  ``technic``, ``ggb_export.import_policy``); synced with the current
  source in ``docs/style_guide/examples/``.
- ``examples/main.py``: 15 SyntaxWarnings from invalid escape sequences
  (``'$...\circ...$'``) fixed with raw-string prefix.

### Tests

- 937 → 988 (+51 new regression tests).
- 0 regressions; ``_safe_extract_ggb`` path traversal / bomb prevention,
  DSL sandbox escape vectors, state-reset on ``loadGGB``, overlay reaching
  renderer for stroke/font/size, ``Element.value()`` for each variable
  type, ``Angle.equivalent`` symmetry, float-tolerance edge cases, CLI
  injection payload lock-in, pixel-invariant decoration overrides.

### Compatibility

- Tested against manim 0.19.0 and 0.20.1. Upper bound in ``pyproject.toml``
  relaxed to ``manim>=0.19.0,<0.22``.
- Fixed manim 0.20 deprecations in our code:
  ``VMobject.get_cap_style()`` → direct ``cap_style`` attribute read.
- Fixed NumPy 2.0 deprecations in our code: replaced 2-D ``np.cross``
  calls (``lib_commands.area`` and ``are_concurrent_lll``) with explicit
  scalar ``x1*y2 − y1*x2`` expressions.
- Silenced the startup ``pytest-asyncio`` deprecation via
  ``[tool.pytest.ini_options]``.

## [1.0.1] — 2026-04-24

Patch release: reliability fixes in rendering and DSL re-definition.

### Fixed

- **Arc / CircleSector rendering** (`animageo.py`) — both renderers read `elem.data.sizes`, but the geometry classes expose the attribute as `angles`. Any scene containing Arc or CircleSector crashed during `CreateMObject`, cascading through dependents. Renamed to `elem.data.angles`.
- **`.contains` typos in `lib_commands.py`** — `arc.centerontains(...)` / `line.offsetontains(...)` were pre-1.0 search-and-replace artifacts with no matching method on the target classes. Broke `intersect_Cl` (arc∩line), `circumcircle_arc_ppp` / `circumcircle_sector_ppp`, `contained_by_pc` / `contained_by_pl`. All five call sites now use `.contains(...)`.
- **`Construction.update_alpha` alias** — documented in `CLAUDE.md` as legacy alias for `update_tparam` but missing from the class. Restored as `update_alpha = update_tparam`.
- **DSL command failure with forward-ref Vars** — when a command's inputs contain a forward-reference Var with no data yet, `Construction.apply()` only wrote `None` into outputs that *already existed* as elements. Phantom outputs (e.g., intermediate `_3` from `4 + x` arithmetic) were silently skipped, so `element(name)` later returned `None` and `styleGeometry`-style code raised `AttributeError`. Fix: `apply()` now creates placeholder elements for all outputs, including not-yet-existing phantoms.
- **`Construction.rename()` broke downstream dependency graph** — when a DSL file redefined a GGB-loaded element (e.g., `X = A + x * (B - A)` where `X` was already a Point in the GGB), the `_forget(X) + rename(phantom, X)` sequence cleared every `state[downstream].inputs` reference to `X`, but did not restore them for the new command using `X`. Symptom: animating the Var re-computed `X` itself, but `q1`/`g`/… that depended on `X` never rebuilt, so the animation was visually frozen. Fix: `rename()` now re-runs `updateStateLevels` on every command that references the new name.

### Notes

- All 937 unit tests continue to pass.
- No API surface changes.

## [1.0.0] — 2026-04-23

First stable release. Substantial rewrite of the style system, parsers, and geometry core, with three new element types and full animation/labeling pipelines.

### Added

- **Python DSL (`animageo.dsl`, `parsers/dsl/`)** — exec-based mini-DSL replacing the old short-parser. Supports `for`/`if`/`def`, keyword args, tuple unpacking, live `.field` access on elements, proxy arithmetic (`A-B`, `-v`, `abs(x)`), `f(x) = expr` sugar for functions, and auto-generated `.pyi` stubs per scene.
- **Style subsystem (`animageo/style/`)** — three-layer resolver architecture: package-shipped `builtin.json` defaults (pixels), user JSON defaults, `overlay.per_type` / `overlay.per_name` stylization, with explicit `elem.style[...]` writes always winning. Mini-DSL for policy values: `const:`, `scale:`, `quantize:`, `remap:`.
- **`ImportPolicy`** — configurable GGB-to-style mapping. Pass to `loadGGB` or embed under `import.policy` in the style JSON. Supports scalar, callable, DSL-string, and `per_type` / `per_name` rules. `scene.reloadPolicy()` reapplies a new policy without reparsing XML.
- **`Conic` element** — first-class conic stored as a 3×3 symmetric matrix with lazy classification into 9 types (circle / ellipse / parabola / hyperbola / intersecting / parallel / double lines / point / empty). Canonical parametrizations via eigendecomposition. Constructors: `Conic(matrix)`, `from_ggb_matrix`, `from_coeffs`, `from_string`.
- **`Function` element** — explicit `y = f(x)` with sympy parsing: `^` → `**`, Unicode `≤/≥`, chained comparisons, `If[...]` → `Piecewise`. numpy `lambdify` on the hot path.
- **`ImplicitCurve` element** — `F(x, y) = 0` for any sympy expression, rendered by marching squares.
- **Adaptive curve sampling (`geo/curve_sampling.py`)** — viewport-aware sampler with Liang–Barsky clipping, analytic t-ranges for parabola / hyperbola branches, marching squares for implicit curves. Hard `max_samples` caps guarantee no hangs on pathological curves.
- **Intersections across all type pairs** — analytic for `Kl` / `KK` / `Kc` (pencil method); numeric with sympy + `scipy.brentq` / `fsolve` fallbacks for `F*` and `I*`. 150+ commands in `lib_commands.py`.
- **Conic geometric constructors** — `Ellipse`/`Hyperbola` from foci + semi-axis, `Parabola` from focus + directrix, `Conic` from 5 points.
- **Conic properties** — `Center`, `Focus`, `Vertex`, `Axes`, `Directrix`, `Eccentricity`, `Polar`, `Tangent`.
- **Automatic label placement (`label_placement.py`)** — priority-ordered greedy solver with 8 candidate directions, analytic bisector placement for angles, EMA smoothing + anchor hysteresis for dynamic tracking, per-keyframe snapshots with interpolation.
- **Keyframe animation (`keyframes.py`)** — JSON-driven animation: free points, constrained (alpha) points, numbers, angles, booleans; linear / smooth / in / out / in\_out easing; per-keyframe `show` / `hide`.
- **Batch API** — `setElementStyle(names, **kwargs)`, `setVisible(names, visible)`, `animating(...)` context manager.
- **Pixel-invariant sizing** — all GGB sizes (point radius, line width, font, arc, label offset) stored in pixel units, divided by `ptUnit` at render time. Same pixel output across canvas sizes.
- **Angle arc auto-sizing** — opt-in `rendering.angle_radius` scales arc radius by `(π/2 / angle) ** exp`, clamped by arm-length fraction. Shared between renderer and label placement.
- **Z-index tiers** — named constants in `constants.py` (`Z_FILL`, `Z_LABEL`, …).
- **`CreateMObject` dispatch** — split into 13 per-type `_render_<typename>` methods plus a small context builder. `CreateMObject` itself is a 20-line dispatcher.
- **Structured logging** — all modules use `logging.getLogger(__name__)`; no stray `print` in library code.
- **`CHANGELOG.md`** (this file).

### Changed

- **Version:** 0.1.11 → 1.0.0.
- **Python requirement:** bumped to `>=3.13`.
- **Metadata:** added MIT license, `Development Status :: 5 - Production/Stable`, audience and topic classifiers. Homepage switched to `https://`.
- **Topological rebuild** — Construction now uses Kahn's algorithm with cycle detection and per-element error recovery, so one broken element no longer aborts the whole scene.
- **CLI entry point** — `animageo` console script remains, unchanged surface.

### Fixed

- **`intersect_cc`** — edge-case reliability (tangent / coincident circles).
- **Angle arc radius units** — no longer collapse to sub-pixel values when `elem.style` is empty (builtin default of 17 px now applies).
- **GGB label offsets** — now scale proportionally with canvas size via `ptUnit_ggb`.

### Removed

- **`animageo/style.py` / `animageo/style_schema.py`** — replaced by the `animageo/style/` subpackage.
- **`animageo/parsers/short_parser.py`** — replaced by the Python DSL.
- **`requests` dependency** — was unused.
- **Legacy `geodynamic/` package** — earlier rename; no longer shipped in the wheel after build hygiene fix.

### Packaging

- **`pyproject.toml`** is now the single source of truth; `setup.py` reduced to a one-line shim.
- **`package-data`** — `style/builtin.json` and `*.pyi` stub files now ship inside the wheel.
- **`find_packages`** — restricted to `animageo*`; `tests/` is no longer included in the distribution.
