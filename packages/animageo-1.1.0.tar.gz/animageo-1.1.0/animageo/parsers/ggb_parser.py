import logging
import os
import shutil
import re
import ast
import tempfile
from zipfile import ZipFile

logger = logging.getLogger(__name__)
from xml.etree import ElementTree
from xml.etree.ElementTree import Element as XElement

from ..geo.construction import Construction
from ..geo.lib_commands import Command
from ..geo.lib_vars import *
from ..geo.lib_elements import *
from ..geo.utils import is_number, is_angle_degrees
from ..style.scaling import (
    ggb_point_size_to_style,
    ggb_thickness_to_stroke_width,
    ggb_arc_size_px,
    ggb_label_offset_to_style,
)
from ..style.enums import ggb_point_style_to_elem_style
def _ggb_parse(constr, code, debug=False):
    """Thin wrapper around ``dsl.run`` so the two call sites below
    stay readable. Lazy-imports to avoid a module-load cycle (``dsl``
    imports ``lib_commands`` which indirectly loads this module)."""
    from .dsl import run as _dsl_run
    _dsl_run(constr, code, debug=debug)


temp_path = None  # created dynamically per call

#--------------------------------------------------------------------------

def rgb_to_hex(r, g, b):
    return '#{:02x}{:02x}{:02x}'.format(r, g, b)

_GGB_MAX_UNCOMPRESSED_BYTES = 256 * 1024 * 1024  # 256 MB hard cap against zip-bomb
_GGB_MAX_MEMBERS = 4096                           # reject bombs with millions of tiny files


def _safe_extract_ggb(ggb: ZipFile, dest_dir: str) -> None:
    """Extract a .ggb (ZIP) archive guarding against path traversal and zip-bomb.

    Raises ValueError on any member whose resolved path escapes ``dest_dir``,
    when the archive has too many entries, or when the total uncompressed size
    exceeds the cap. Only member paths are validated; content is written via
    ZipFile.extract which uses the already-sanitized sanitized name.
    """
    dest_real = os.path.realpath(dest_dir)
    infos = ggb.infolist()
    if len(infos) > _GGB_MAX_MEMBERS:
        raise ValueError(f"ggb archive has too many members ({len(infos)} > {_GGB_MAX_MEMBERS})")
    total = 0
    for info in infos:
        total += int(info.file_size)
        if total > _GGB_MAX_UNCOMPRESSED_BYTES:
            raise ValueError(
                f"ggb archive uncompressed size exceeds cap ({total} > {_GGB_MAX_UNCOMPRESSED_BYTES})"
            )
        name = info.filename
        if not name or name.endswith('/'):
            continue  # directory entry — ZipFile.extract handles creation
        # Reject absolute paths and any traversal that escapes dest_dir.
        if os.path.isabs(name) or name.startswith(('/', '\\')):
            raise ValueError(f"ggb archive member has absolute path: {name!r}")
        target = os.path.realpath(os.path.join(dest_real, name))
        if target != dest_real and not target.startswith(dest_real + os.sep):
            raise ValueError(f"ggb archive member escapes extraction directory: {name!r}")
    ggb.extractall(dest_dir)


def get_xelems(ggb_path: str):
    tmp_dir = tempfile.mkdtemp(prefix="animageo_")
    try:
        with ZipFile(ggb_path, 'r') as ggb:
            _safe_extract_ggb(ggb, tmp_dir)

        tree = ElementTree.parse(os.path.join(tmp_dir, "geogebra.xml"))
        root = tree.getroot()

        return root.find("construction"), root.find("euclidianView"), root.find("gui")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

def replace_with_point(expr_str):
    # Регулярное выражение для поиска нужных скобок
    pattern = r'''
        (?<!\w)           # Отрицательный просмотр назад: перед скобкой не должно быть символа слова
        \(                # Открывающая круглая скобка
        \s*               # Возможные пробелы после открывающей скобки
        [^(),]+           # Первый элемент (не содержит скобок или запятых)
        \s*               # Возможные пробелы
        ,                 # Запятая, разделяющая элементы
        \s*               # Возможные пробелы
        [^(),]+           # Второй элемент (не содержит скобок или запятых)
        \s*               # Возможные пробелы перед закрывающей скобкой
        \)                # Закрывающая круглая скобка
    '''
    
    # Замена: вставляем 'Point' перед найденными скобками
    return re.sub(pattern, r'Point\g<0>', expr_str, flags=re.VERBOSE)

 # Функция для извлечения идентификаторов из выражения
def extract_identifiers(expression):
    # Ищем идентификаторы, которые могут содержать фигурные скобки как часть имени
    # Это включает имена типа "M_{1}", "u_{1}" и т.д.
    identifier_pattern = r'[a-zA-Z_][a-zA-Z0-9_]*\{[^}]*\}|[a-zA-Z_][a-zA-Z0-9_]*'
    
    # Находим все совпадения
    identifiers = set()
    for match in re.finditer(identifier_pattern, expression):
        ident = match.group(0)
        # Проверяем, что это не часть числа и не оператор
        if not re.match(r'^\d', ident) and ident not in ['and', 'or', 'not']:
            identifiers.add(ident)
    
    # Также ищем идентификаторы с специальными символами, которые могут быть пропущены
    special_pattern = r'[a-zA-Z_][a-zA-Z0-9_{}\'&°]*'
    for match in re.finditer(special_pattern, expression):
        ident = match.group(0)
        # Исключаем чисто числовые значения и операторы
        if not re.match(r'^\d', ident) and ident not in ['and', 'or', 'not']:
            identifiers.add(ident)
    
    # Исключаем ключевые слова Python и стандартные функции
    python_keywords = {'and', 'as', 'assert', 'break', 'class', 'continue', 
                      'def', 'del', 'elif', 'else', 'except', 'False', 'finally', 
                      'for', 'from', 'global', 'if', 'import', 'in', 'is', 
                      'lambda', 'None', 'nonlocal', 'not', 'or', 'pass', 'raise', 
                      'return', 'True', 'try', 'while', 'with', 'yield'}
    
    math_functions = {'sin', 'cos', 'tan', 'sqrt', 'log', 'ln', 'exp', 'abs', 
                     'round', 'floor', 'ceil', 'min', 'max', 'sum'}
    
    excluded = python_keywords.union(math_functions)
    return identifiers - excluded

def convert_ggb_expr_to_python(constr, expr_str, expr_type=None):    
    # Извлекаем все идентификаторы из выражения
    identifiers = extract_identifiers(expr_str)
    # print("identifiers:", identifiers)
    
    # Добавляем новые идентификаторы в name_mapping, если они еще не там
    for identifier in identifiers:
        if identifier not in constr.name_mapping:
            constr.get_normalized_name(identifier)
    
    # Заменяем все имена согласно name_mapping
    for original, normalized in constr.name_mapping.items():
        expr_str = re.sub(r'\b' + re.escape(original), normalized, expr_str)
        
    # Проверяем, является ли выражение простым вектором в формате (x, y)
    vector_match = re.match(r'^\s*\(\s*([-\d.]+)\s*,\s*([-\d.]+)\s*\)\s*$', expr_str)
    if vector_match and expr_type == "vector":
        x, y = vector_match.groups()
        return f"Vector(Point({x}, {y}))"
    
    expr_str = replace_with_point(expr_str)
    
    # Заменяем квадратные скобки на круглые
    expr_str = expr_str.replace('[', '(').replace(']', ')')
    
    # Заменяем функции CamelCase на snake_case
    pattern = r'\b([A-Za-z_][A-Za-z0-9_]*)\('
    def camel_to_snake(match):
        name = match.group(1)
        s = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
        return s + '('
    
    expr_str = re.sub(pattern, camel_to_snake, expr_str)
    
    # Заменяем градусы
    pattern_deg = r'(\d+)°'
    expr_str = re.sub(pattern_deg, r'AngleSize("\1°")', expr_str)
    
    return expr_str

def is_simple_value(s):
    if s is None:
        return True
    if is_number(s):
        return True
    if is_angle_degrees(s):
        return True
    if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', s):
        return True
    return False

def get_tparam_from_point_and_circle(point, circle):
    """Compute the curve parameter (angle in radians) for a point on a circle."""
    vector = point.coords - circle.center
    theta = np.arctan2(vector[1], vector[0])
    return theta % (2*np.pi)

def get_tparam_from_point_and_line(point, line):
    """Compute the linear t-parameter for a point on a line."""
    base_point = line.offset * line.normal
    t = np.dot(point.coords - base_point, line.direction)
    return t

def get_tparam_from_point_and_segment(point, segment):
    """Compute the linear t-parameter (0..1 for interior) for a point on a segment."""
    A = segment.endpoints[0]
    B = segment.endpoints[1]
    AB = B - A
    AP = point.coords - A
    t = np.dot(AP, AB) / np.dot(AB, AB)
    return t


def parse_constr(constr: Construction, constr_xelem: XElement, debug = False):
    xelems_left_to_pass = 0
    fixed_element = False
    # Tracks the locus (Circle/Line/Ray/Segment) the next Point is
    # constrained to; used to compute its ``tparam``.
    tparam_locus = None
    name_mapping = {}
    style = {}
    raw = {}  # raw GGB values per element, for ImportPolicy (Phase 3+)

    for xelem in constr_xelem:                    
        if xelem.tag == "element":                    
            name = xelem.attrib['label']
            type = xelem.attrib['type']

            name_mapping[name] = constr.get_normalized_name(name)
            name = name_mapping[name]
            
            style[name] = {}
            raw[name] = {'elem_type': type}

            elem = xelem.find("decoration")
            if elem is not None:
                style[name]['tick_count'] = int(elem.attrib['type'])
                if type == 'angle':
                    style[name]['tick_count'] += 1
                raw[name]['decoration_lines'] = int(elem.attrib['type'])

            elem = xelem.find("show")
            if elem is not None:
                style[name]['visible'] = (elem.attrib['object'] == 'true')
                style[name]['label_visible'] = (elem.attrib['label'] == 'true')
                raw[name]['show_object'] = (elem.attrib['object'] == 'true')
                raw[name]['show_label'] = (elem.attrib['label'] == 'true')

            elem = xelem.find("labelMode")
            if elem is not None:
                caption = xelem.find("caption")
                if (elem.attrib['val'] == '3') & (caption is not None):
                    style[name]['label_text'] = '$' + caption.attrib['val'] + '$'
                    raw[name]['label_caption'] = caption.attrib['val']

            elem = xelem.find("angleStyle")
            if elem is not None:
                if type == 'angle':
                    ggb_angle_style = int(elem.attrib['val'])
                    style[name]['angle_range'] = 'reflex' if ggb_angle_style == 2 else 'minor'
                    raw[name]['angle_style'] = ggb_angle_style

            elem = xelem.find("pointStyle")
            if elem is not None:
                if type == 'point':
                    raw[name]['point_style'] = int(elem.attrib['val'])

            elem = xelem.find("pointSize")
            if elem is not None:
                if type == 'point':
                    psize = float(elem.attrib['val'])
                    raw[name]['point_size'] = psize
                    style[name]['size_px'] = ggb_point_size_to_style(psize)

            elem = xelem.find("labelOffset")
            if elem is not None:
                x, y = float(elem.attrib['x']), float(elem.attrib['y'])
                raw[name]['label_offset_px'] = [x, y]
                style[name]['label_offset_px'] = ggb_label_offset_to_style(x, y)
            else:
                style[name]['label_offset_px'] = [0, 0]

            elem = xelem.find("arcSize")
            if elem is not None:
                if xelem.attrib['type'] == 'angle':
                    asize = float(elem.attrib['val'])
                    raw[name]['arc_size'] = asize
                    style[name]['arc_size_px'] = ggb_arc_size_px(asize)

            elem = xelem.find("objColor")
            if elem is not None:
                r, g, b, a = int(elem.attrib['r']), int(elem.attrib['g']), int(elem.attrib['b']), float(elem.attrib['alpha'])
                raw[name]['obj_color'] = {'r': r, 'g': g, 'b': b, 'alpha': a}
                hex_color = rgb_to_hex(r, g, b)
                style[name]['label_color'] = hex_color
                if xelem.attrib['type'] in ['angle', 'polygon', 'arc', 'conic']:
                    style[name]['fill'] = hex_color
                    style[name]['fill_opacity'] = a
                if xelem.attrib['type'] == 'point':
                    # Decompose GGB pointStyle into (shape, fill, stroke) axes.
                    ggb_code = raw[name].get('point_style', 0)
                    style[name].update(ggb_point_style_to_elem_style(ggb_code, hex_color))

                lineStyle = xelem.find("lineStyle")
                if lineStyle is not None:
                    thick, tt = float(lineStyle.attrib['thickness']), float(lineStyle.attrib['type'])
                    op = float(lineStyle.attrib['opacity']) if 'opacity' in lineStyle.attrib else 255
                    raw[name]['line_thickness'] = thick
                    raw[name]['line_type'] = int(tt)
                    raw[name]['line_opacity'] = op
                    style[name]['stroke'] = hex_color
                    style[name]['stroke_opacity'] = op / 255
                    style[name]['stroke_width_px'] = ggb_thickness_to_stroke_width(thick)
                    if int(tt) > 0: style[name]['stroke_dash_ratio'] = 0.65
                        
        if xelems_left_to_pass:
            xelems_left_to_pass -= 1
            continue

        if xelem.tag == "expression":
            try:
                name = xelem.attrib['label']
                expr = xelem.attrib['exp']
                expr_type = xelem.attrib.get('type', None)
                name_mapping[name] = constr.get_normalized_name(name)
                converted_expr = convert_ggb_expr_to_python(constr, expr, expr_type)

                if expr.find('=') < 0:
                    logger.debug("Expression [%s]: %s >> %s", expr_type, expr, name)
                    _ggb_parse(constr, f"{name_mapping[name]} = {converted_expr}", debug=debug)
                    xelems_left_to_pass = 1
                    continue

                # Expression is an explicit equation (contains '='). For
                # GGB types that carry their geometric data in the
                # following <element>'s <matrix> / <coords>, defer to
                # the final element handler below (no xelems_left_to_pass
                # increment — we want the handler to run).
                if expr_type in ('conic', 'line'):
                    logger.debug("Deferred %s equation to element: %s",
                                 expr_type, expr)
                    continue

                if expr_type == 'function':
                    # Parse the function directly from the expression
                    # string — the companion <element> has only style,
                    # no geometric data.
                    from ..geo.lib_function import Function as _Function
                    try:
                        func_obj = _Function.from_string(expr)
                        constr.add(Element(name_mapping[name], func_obj, fixed=True))
                    except ValueError as fe:
                        logger.warning("Could not parse function '%s': %s", expr, fe)
                    xelems_left_to_pass = 1
                    continue

                if expr_type == 'implicitpoly':
                    from ..geo.lib_implicit import ImplicitCurve as _Implicit
                    try:
                        imp = _Implicit.from_string(expr)
                        constr.add(Element(name_mapping[name], imp, fixed=True))
                    except ValueError as ie:
                        logger.warning("Could not parse implicitpoly '%s': %s",
                                       expr, ie)
                    xelems_left_to_pass = 1
                    continue

                logger.warning("No implementation for expression '%s' (type=%s)",
                               expr, expr_type)
                xelems_left_to_pass = 1
                continue
            except Exception as e:
                logger.debug("Expression parse error: %s", e)
                continue
        
        if xelem.tag == "command":            
            comm_name = xelem.attrib["name"]                        
            input_xelem, output_xelem = xelem.find("input"), xelem.find("output")
            inputs, outputs = list(input_xelem.attrib.values()), list(output_xelem.attrib.values())
            outputs = [constr.get_normalized_name(output) for output in outputs]
            for i, inp in enumerate(inputs):
                if is_number(inp) or is_angle_degrees(inp):
                    inputs[i] = inp 
                else:
                    inputs[i] = constr.get_normalized_name(inp)
            
            # Обработка выражений во входных параметрах
            new_inputs = []
            for inp in inputs:
                if is_simple_value(inp):
                    new_inputs.append(inp)
                else:
                    # Создаем временную переменную для выражения
                    temp_name = constr.add_new_phantom()
                    converted_expr = convert_ggb_expr_to_python(constr, inp)
                    _ggb_parse(constr, f"{temp_name} = {converted_expr}", debug=debug)
                    new_inputs.append(temp_name)
            
            command = Command(comm_name, new_inputs, outputs)
            constr.add(command)
            constr.apply(command, debug = debug)
            
            if comm_name == "Point":
                if len(inputs) == 1:
                    if debug: print(f'Point FIXED by {inputs[0]}')
                    fixed_element = True
            
                    input0 = constr.element(inputs[0]).data if constr.element(inputs[0]) else None
                    if isinstance(input0, (Circle, Line, Ray, Segment)):
                        tparam_locus = input0

            xelems_left_to_pass = len(output_xelem.attrib) if not tparam_locus else 0

            continue

        # Here xelem has to be a commandless point or numeric (Var)

        if xelem.tag == "element":
            name = name_mapping[xelem.attrib["label"]]
            if xelem.attrib["type"] == "point":
                coords = list(xelem.find("coords").attrib.values())
                coords.pop(-1) #  removing z coordinate
                tparam = None
                if tparam_locus:
                    if isinstance(tparam_locus, Circle):
                        tparam = get_tparam_from_point_and_circle(Point(coords), tparam_locus)
                    elif isinstance(tparam_locus, Segment):
                        tparam = get_tparam_from_point_and_segment(Point(coords), tparam_locus)
                    elif isinstance(tparam_locus, (Line, Ray)):
                        tparam = get_tparam_from_point_and_line(Point(coords), tparam_locus)

                if tparam is not None:
                    fixed_element = False
                    constr.element(name).data = Point([float(x) for x in coords])
                    constr.element(name).tparam = tparam
                else:
                    constr.add(Element(name, Point([float(x) for x in coords]), fixed = fixed_element))

                fixed_element = False
                tparam_locus = None
                continue
            if xelem.attrib["type"] == "numeric":
                value_xelem = xelem.find("value")
                constr.add(Var(name, float(value_xelem.attrib["val"])))
                continue
            if xelem.attrib["type"] == "angle":
                value_xelem = xelem.find("value")
                constr.add(Var(name, AngleSize(float(value_xelem.attrib["val"]))))
                continue
            if xelem.attrib["type"] == "conic":
                if constr.element(name) is not None:
                    continue
                matrix_elem = xelem.find("matrix")
                if matrix_elem is None:
                    logger.warning("Conic element '%s' has no <matrix>", name)
                    continue
                a = matrix_elem.attrib
                try:
                    conic = Conic.from_ggb_matrix(
                        float(a['A0']), float(a['A1']), float(a['A2']),
                        float(a['A3']), float(a['A4']), float(a['A5']),
                    )
                except (KeyError, ValueError) as e:
                    logger.warning("Failed to parse conic matrix for '%s': %s", name, e)
                    continue
                constr.add(Element(name, conic, fixed=True))
                continue
            if xelem.attrib["type"] == "line":
                if constr.element(name) is not None:
                    continue
                coords_elem = xelem.find("coords")
                if coords_elem is None:
                    logger.warning("Line element '%s' has no <coords>", name)
                    continue
                try:
                    a = float(coords_elem.attrib['x'])
                    b = float(coords_elem.attrib['y'])
                    c = float(coords_elem.attrib['z'])
                except (KeyError, ValueError) as e:
                    logger.warning("Failed to parse line coords for '%s': %s", name, e)
                    continue
                if abs(a) < 1e-12 and abs(b) < 1e-12:
                    logger.warning("Degenerate line coords for '%s': (%s, %s, %s)",
                                   name, a, b, c)
                    continue
                # GGB: a·x + b·y + c·z = 0 with z = 1.
                # animageo Line: n·p = c_line, with n = (a, b), c_line = -c.
                constr.add(Element(name, Line([a, b], -c), fixed=True))
                continue

        logger.debug("Skipping unsupported XElement: <%s> %s", xelem.tag, xelem.attrib)

    constr.rebuild(debug = debug)

    #styling elements
    for name in style:
        if constr.element(name) is None: continue
        if isinstance(constr.element(name), Var): continue
        if name in raw:
            constr.element(name).ggb_raw = raw[name]
        for key in style[name]:
            if debug: logger.debug("STYLE >> %s >> %s = %s", name, key, style[name][key])
            if key == 'visible':
                if not constr.element(name):
                    logger.warning("Element '%s' is None during style application", name)
                constr.element(name).visible = style[name][key]
                continue
            constr.element(name).style[key] = style[name][key]

def FloatOrNone(txt):
    return float(txt) if txt is not None else None

def parse_view(view, view_xelem: XElement, debug = False):    
    for xelem in view_xelem:            
        if xelem.tag == "size":
            view['ptWidth'], view['ptHeight'] = FloatOrNone(xelem.attrib['width']), FloatOrNone(xelem.attrib['height'])

        if xelem.tag == "coordSystem":
            view['ptXZero'], view['ptYZero'] = FloatOrNone(xelem.attrib['xZero']), FloatOrNone(xelem.attrib['yZero'])
            view['ptUnit'] = FloatOrNone(xelem.attrib['scale'])
            view['ptUnit_ggb'] = view['ptUnit']

def parse_gui(view, gui_xelem: XElement, debug = False):
    """Parse GUI settings (font size, etc.) from GGB XML."""
    if gui_xelem is None:
        return
    font_elem = gui_xelem.find("font")
    if font_elem is not None:
        view['fontSize'] = int(font_elem.attrib.get('size', 16))

def load(constr: Construction, view, ggb_path: str, debug = False):
    if debug: logger.debug("Loading from GGB: %s", ggb_path)
    constr_xelem, view_xelem, gui_xelem = get_xelems(ggb_path)
    parse_constr(constr, constr_xelem, debug = debug)
    parse_view(view, view_xelem, debug = debug)
    parse_gui(view, gui_xelem, debug = debug)
