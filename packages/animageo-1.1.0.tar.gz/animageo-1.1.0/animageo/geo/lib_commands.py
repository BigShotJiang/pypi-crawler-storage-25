"""Geometric command implementations with dynamic dispatch.

Functions follow the naming convention: command_name + '_' + type_shortcuts.
Type shortcuts: p=Point, l=Line, r=Ray, s=Segment, c=Circle, C=Arc,
S=CircleSector, a=Angle, v=Vector, P=Polygon, i=int/float, m=Measure,
A=AngleSize, b=Boolean.

Example: midpoint_pp(p1, p2) computes midpoint of two Points.
"""
import logging
import numpy as np
import re
from typing import Iterable

from .lib_vars import *
from .lib_elements import *
from .lib_conic import Conic, ConicType
from .lib_function import Function
from .lib_implicit import ImplicitCurve

logger = logging.getLogger(__name__)

#--------------------------------------------------------------------------

class Command:
    def __init__(self, name, inputs, outputs = None):
        self.name = name
        self.inputs = toObjArray(inputs)        # могут храниться сами объекты, а также строки с именами или выражениями
        self.outputs = toObjArray(outputs)

    def __repr__(self):
        inputs_str = ' '.join([obj.name if hasattr(obj, "name") else str(obj) for obj in self.inputs])
        outputs_str = ' '.join([obj.name if hasattr(obj, "name") else str(obj) for obj in self.outputs])
        return "{}:\t{}\t>> {}".format(self.name, inputs_str, outputs_str)

    def checkParamsPrepaired(self, params):
        for obj in params:
            if type(obj) not in type_to_shortcut:
                #raise Exception("In command <{}> param ({} as {}) is not prepaired.".format(self.name, obj, type(obj)))
                return False
        return True

    def func(self):     # эта функция должна находить реализованную функцию в этом модуле и возвращать ссылку на нее
        #if not self.checkParamsPrepaired(self.inputs):
        #    raise Exception("In command <{}> inputs are not prepaired.".format(self.name))

        fname = strFullCommand(self.name, self.inputs)

        impl = COMMAND_REGISTRY.get(fname)
        if impl is not None:
            return impl
        # Loud failure: a command name that survives construction but has
        # no implementation dispatch almost always means a typo in a DSL
        # script (``Intersect(A, B)`` against unexpected types) or a new
        # element type without a matching operation. Before this warning,
        # the call just returned None and the resulting element stayed
        # unbuilt with no diagnostic. Outputs go to the standard logger;
        # web-service integrators can surface it to their own observability.
        input_types = ', '.join(type(x).__name__ for x in self.inputs)
        logger.warning(
            "Command '%s' has no implementation for inputs [%s] "
            "(looked up %r). Affected outputs: %s",
            self.name, input_types, fname,
            [getattr(o, 'name', str(o)) for o in self.outputs],
        )
        return None

#--------------------------------------------------------------------------        

def toObjArray(params):
    if not params: return []
    elif not isinstance(params, Iterable) or isinstance(params, str): return [params]
    else: return list(params)

#--------------------------------------------------------------------------   

type_to_shortcut = {
    Point           : 'p',
    Polygon         : 'P',
    Circle          : 'c',
    Arc             : 'C',
    Line            : 'l',
    Ray             : 'r',
    Segment         : 's',
    Angle           : 'a',
    Vector          : 'v',
    CircleSector    : 'S',
    Conic           : 'K',
    Function        : 'F',
    ImplicitCurve   : 'I',

    int             : 'i',
    float           : 'i',
    Boolean         : 'b',
    Measure         : 'm',
    AngleSize       : 'A',
    str             : 'T'   # for DSL string literals: Function("y = x^2"), Conic("..."), etc.
}

def strFullCommand(name, params): # "Polygon", [Point, Point, int] -> "polygon_ppi"
    # print(f"strFullCommand: {name} - {params}")
    if strCommand(name) == "polygon" and bool(re.match('^p*$', strParams(params))):
        return strCommand(name)
    else:
        return f"{strCommand(name)}_{strParams(params)}"

def strParams(params): # [Point, Point, int] -> "ppi"
    for x in params:
        if type(x) not in type_to_shortcut:
            if x is not None:
                logger.warning("No type shortcut for '%s'", type(x).__name__)
    return ''.join(type_to_shortcut[type(x)] if type(x) in type_to_shortcut else '?' for x in params)

def strCommand(name): # "AreCollinear" -> "are_collinear"
    altered_name = [name[0].lower()]
    for x in name[1:]:
        if x.isupper(): altered_name += ['_', x.lower()]
        else: altered_name.append(x)
    return ''.join(altered_name)

#--------------------------------------------------------------------------

def res_by_index(res, index, points_order=None):
    index = int(max(0, index - 1))
    
    if not hasattr(res, '__len__'):
        return res if index == 0 else None

    if points_order is None:
        return res[index] if index < len(res) else None

    # Создаем упорядоченный список точек
    ordered_points = []
    used = [False] * len(res)  # Отслеживаем использованные точки из res
    
    # Сначала добавляем точки из points_order в указанном порядке
    for order_point in points_order:
        for i, res_point in enumerate(res):
            if not used[i] and np.isclose(order_point.coords, res_point.coords).all():
                ordered_points.append(res_point)
                used[i] = True
                break

    # Затем добавляем оставшиеся точки из res в исходном порядке
    for i, res_point in enumerate(res):
        if not used[i]:
            ordered_points.append(res_point)

    return ordered_points[index] if index < len(ordered_points) else None
    
#--------------------------------------------------------------------------

def assign_p(x):
    return x
def assign_v(x):
    return x
def assign_i(x):
    return x

def angle_size_A(a):
    return AngleSize(a.value)

def angle_size_i(x):
    return AngleSize(x)

def angle_ppp(p1, p2, p3):
    return Angle(p2.coords, p1.coords-p2.coords, p3.coords-p2.coords)

def angle_size_ppp(p1, p2, p3):
    return AngleSize(np.angle(a_to_cpx(p3.coords-p2.coords) / a_to_cpx(p1.coords-p2.coords)))

def angular_bisector_ll(l1, l2):
    x = intersect_ll(l1, l2)
    n1, n2 = l1.normal, l2.normal
    if np.dot(n1, n2) > 0: n = n1 + n2
    else: n = n1 - n2
    return [
        Line(vec, np.dot(vec, x.coords))
        for vec in (n, vector_perp_rot(n))
    ]

def angular_bisector_ppp(p1, p2, p3):
    v1 = p2.coords - p1.coords
    v2 = p2.coords - p3.coords
    v1 /= np.linalg.norm(v1)
    v2 /= np.linalg.norm(v2)
    if np.dot(v1, v2) < 0: n = v1-v2
    else: n = vector_perp_rot(v1+v2)
    return Line(n, np.dot(p2.coords, n))

def angular_bisector_ss(l1, l2):
    return angular_bisector_ll(l1, l2)

def arc_cpp(circle, p1, p2):
    if np.isclose(circle.center, p1.coords).all(): return None
    if np.isclose(circle.center, p2.coords).all(): return None
    return Arc(circle.center, circle.radius, [np.arctan2(p.coords[1] - circle.center[1], p.coords[0] - circle.center[0]) for p in (p1, p2)])

def circumcircle_arc_ppp(p1, p2, p3):
    if np.isclose(p1.coords, p2.coords).all(): return None
    if np.isclose(p1.coords, p3.coords).all(): return None
    if np.isclose(p2.coords, p3.coords).all(): return None
    circle = circle_ppp(p1, p2, p3)
    arc = Arc(circle.center, circle.radius, [np.arctan2(p.coords[1] - circle.center[1], p.coords[0] - circle.center[0]) for p in (p1, p3)])
    return arc if arc.contains(p2.coords) else Arc(circle.center, circle.radius, [np.arctan2(p.coords[1] - circle.center[1], p.coords[0] - circle.center[0]) for p in (p3, p1)])

def circle_arc_ppp(p1, p2, p3):
    if np.isclose(p1.coords, p2.coords).all(): return None
    if np.isclose(p1.coords, p3.coords).all(): return None
    if np.isclose(p2.coords, p3.coords).all(): return None
    circle = circle_pp(p1, p2)
    return Arc(circle.center, circle.radius, [np.arctan2(p.coords[1] - circle.center[1], p.coords[0] - circle.center[0]) for p in (p2, p3)])

def circumcircle_sector_ppp(p1, p2, p3):
    if np.isclose(p1.coords, p2.coords).all(): return None
    if np.isclose(p1.coords, p3.coords).all(): return None
    if np.isclose(p2.coords, p3.coords).all(): return None
    circle = circle_ppp(p1, p2, p3)
    arc = Arc(circle.center, circle.radius, [np.arctan2(p.coords[1] - circle.center[1], p.coords[0] - circle.center[0]) for p in (p1, p3)])
    return CircleSector(arc.center, arc.radius, arc.angles) if arc.contains(p2.coords) else CircleSector(arc.center, arc.radius, list(reversed(arc.angles)))

def circle_sector_ppp(p1, p2, p3):
    if np.isclose(p1.coords, p2.coords).all(): return None
    if np.isclose(p1.coords, p3.coords).all(): return None
    if np.isclose(p2.coords, p3.coords).all(): return None
    circle = circle_pp(p1, p2)
    return CircleSector(circle.center, circle.radius, [np.arctan2(p.coords[1] - circle.center[1], p.coords[0] - circle.center[0]) for p in (p2, p3)])

def circle_sector_ppA(p1, p2, ang):
    if np.isclose(p1.coords, p2.coords).all(): return None
    circle = circle_pp(p1, p2)
    ang0 = np.arctan2(p2.coords[1] - circle.center[1], p2.coords[0] - circle.center[0])
    return CircleSector(circle.center, circle.radius, [ang0, ang0 + ang.value])

def circle_sector_ppi(p1, p2, value):
    if np.isclose(p1.coords, p2.coords).all(): return None
    circle = circle_pp(p1, p2)
    ang0 = np.arctan2(p2.coords[1] - circle.center[1], p2.coords[0] - circle.center[0])
    return CircleSector(circle.center, circle.radius, [ang0, ang0 + value])

def are_collinear_ppp(p1, p2, p3):
    return Boolean(np.linalg.matrix_rank([p1.coords-p2.coords, p1.coords-p3.coords]) <= 1)

def are_concurrent_lll(l1, l2, l3):
    lines = l1,l2,l3

    differences = []
    for i in range(3):
        remaining = [l.normal for l in lines[:i]+lines[i+1:]]
        # Scalar 2D cross (``x1*y2 − y1*x2``). NumPy 2.0 dropped support
        # for 2D vectors in ``np.cross``.
        n1, n2 = remaining
        prod = np.abs(n1[0] * n2[1] - n1[1] * n2[0])
        differences.append((prod, i, lines[i]))

    l1, l2, l3 = tuple(zip(*sorted(differences)))[2]
    x = intersect_ll(l1, l2)
    return Boolean(np.isclose(np.dot(x.coords, l3.normal), l3.offset))

def are_concurrent(o1, o2, o3):
    cand = []
    try:
        #if True:
        if isinstance(o1, Line) and isinstance(o2, Line):
            cand = intersect_ll(o1, o2)
        elif isinstance(o1, Line) and isinstance(o2, Circle):
            cand = intersect_lc(o1, o2)
        elif isinstance(o1, Circle) and isinstance(o2, Line):
            cand = intersect_cl(o1, o2)
        elif isinstance(o1, Circle) and isinstance(o2, Circle):
            cand = intersect_cc(o1, o2)
    except (ValueError, ZeroDivisionError, np.linalg.LinAlgError):
        pass

    if not isinstance(cand, Iterable) or isinstance(cand, str): cand = (cand,)

    for p in cand:
        for obj in (o1,o2,o3):
            if not obj.contains(p.coords): break
        else: return Boolean(True)

    return Boolean(False)

def are_concyclic_pppp(p1, p2, p3, p4):
    z1, z2, z3, z4 = (a_to_cpx(p.coords) for p in (p1, p2, p3, p4))
    cross_ratio = (z1-z3)*(z2-z4)*(((z1-z4)*(z2-z3)).conjugate())
    return Boolean(np.isclose(cross_ratio.imag, 0))

def are_congruent_aa(a1, a2):
    # ``.value`` is Angle's canonical accessor (== .size in radians).
    # The previous code used ``.angle`` which does not exist on Angle
    # → AttributeError → the command silently propagated a crash.
    result = np.isclose((a1.value - a2.value + 1) % (2 * np.pi), 1)
    result = (result or np.isclose((a1.value + a2.value + 1) % (2 * np.pi), 1))
    return Boolean(result)

def are_complementary_aa(a1, a2):
    result = np.isclose((a1.value - a2.value) % (2 * np.pi), np.pi)
    result = (result or np.isclose((a1.value + a2.value) % (2 * np.pi), np.pi))
    return Boolean(result)

def are_congruent_ss(s1, s2):
    l1, l2 = (
        np.linalg.norm(s.endpoints[1] - s.endpoints[0])
        for s in (s1, s2)
    )
    return Boolean(np.isclose(l1, l2))

def are_equal_mm(m1, m2):
    if m1.dimension != m2.dimension: return None
    return Boolean(np.isclose(m1.value, m2.value))

def are_equal_mi(m, i):
    if m.dimension != 0: return None
    return Boolean(np.isclose(m.value, i))

def are_equal_pp(p1, p2):
    return Boolean(np.isclose(p1.coords, p2.coords).all())

def are_parallel_ll(l1, l2):
    if np.isclose(l1.normal, l2.normal).all(): return Boolean(True)
    if np.isclose(l1.normal, -l2.normal).all(): return Boolean(True)
    return Boolean(False)

def are_parallel_ls(l, s):
    return are_parallel_ll(l, s)

def are_parallel_rr(r1, r2):
    return are_parallel_ll(r1, r2)

def are_parallel_sl(s, l):
    return are_parallel_ll(s, l)

def are_parallel_ss(s1, s2):
    return are_parallel_ll(s1, s2)

def are_perpendicular_ll(l1, l2):
    if np.isclose(l1.normal, l2.direction).all(): return Boolean(True)
    if np.isclose(l1.normal, -l2.direction).all(): return Boolean(True)
    return Boolean(False)

def are_perpendicular_lr(l, r):
    return are_perpendicular_ll(l, r)

def are_perpendicular_rl(r, l):
    return are_perpendicular_ll(r, l)

def are_perpendicular_sl(s, l):
    return are_perpendicular_ll(s, l)

def are_perpendicular_ls(l, s):
    return are_perpendicular_ll(l, s)

def are_perpendicular_ss(s1, s2):
    return are_perpendicular_ll(s1, s2)

def area(*points):
    # Triangulated area via 2D cross-product sum. ``np.cross`` on
    # 2-element arrays was deprecated in NumPy 2.0 (requires 3D input
    # now); we only need the z-component, which is ``x1*y2 − y1*x2``.
    p0 = points[0].coords
    vecs = [p.coords - p0 for p in points[1:]]
    cross_sum = sum(
        v1[0] * v2[1] - v1[1] * v2[0]
        for v1, v2 in zip(vecs, vecs[1:])
    )
    return Measure(abs(cross_sum) / 2, 2)

def area_P(polygon):
    points = [Point(p) for p in polygon.vertices]
    return area(*points)

def center_c(circle):
    return Point(circle.center)

def centroid_P(polygon):
    """Вычисляет центроид многоугольника и возвращает его как объект Point."""
    points = polygon.vertices
    n = len(points)
    
    # Если многоугольник имеет менее 3 точек, возвращаем среднее арифметическое
    if n < 3:
        centroid_coord = np.mean(points, axis=0)
        return Point(centroid_coord)
    
    # Вычисляем площадь по формуле шнурка
    area = 0
    for i in range(n):
        x1, y1 = points[i]
        x2, y2 = points[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    area /= 2
    
    # Если площадь близка к нулю, возвращаем среднее арифметическое точек
    if abs(area) < 1e-10:
        centroid_coord = np.mean(points, axis=0)
        return Point(centroid_coord)
    
    # Вычисляем центроид
    Cx = Cy = 0
    for i in range(n):
        x1, y1 = points[i]
        x2, y2 = points[(i + 1) % n]
        cross = x1 * y2 - x2 * y1
        Cx += (x1 + x2) * cross
        Cy += (y1 + y2) * cross
    
    Cx /= 6 * area
    Cy /= 6 * area
    
    return Point([Cx, Cy])

def circle_pp(center, passing_point):
    return Circle(center.coords, np.linalg.norm(center.coords - passing_point.coords))

def circle_ppp(p1, p2, p3):
    axis1 = line_bisector_pp(p1, p2)
    axis2 = line_bisector_pp(p1, p3)
    center = intersect_ll(axis1, axis2)
    return circle_pp(center, p1)

def circle_pm(p, m):
    if m.dimension != 1: return None
    return Circle(p.coords, m.value)

def circle_pi(p, i):
    return Circle(p.coords, i)

def circle_ps(p, s):
    return Circle(p.coords, s.length)

def contained_by_pc(point, by_circle):
    return Boolean(by_circle.contains(point.coords))

def contained_by_pl(point, by_line):
    return Boolean(by_line.contains(point.coords))

def distance_pp(p1, p2):
    return Measure(np.linalg.norm(p1.coords-p2.coords), 1)

def equality_aa(a1, a2):
    return are_congruent_aa(a1, a2)

def equality_mm(m1, m2):
    if m1.dimension != m2.dimension: return None
    return Boolean(np.isclose(m1.value, m2.value))

def equality_ms(m, s):
    if m.dimension != 1: return None
    return Boolean(np.isclose(m.value, s.length))

def equality_mi(m, i):
    if m.dimension != 0 and i != 0: return None
    return Boolean(np.isclose(m.value, i))

def equality_pp(p1, p2):
    return are_equal_pp(p1, p2)

def equality_Pm(polygon, m):
    if m.dimension != 2: return None
    return Boolean(np.isclose(area_P(polygon).x, m.value))

def equality_PP(poly1, poly2):
    return Boolean(np.isclose(area_P(poly1).x, area_P(poly2).x))

def equality_sm(s, m):
    return equality_ms(m,s)

def equality_ss(s1, s2):
    return Boolean(np.isclose(s1.length, s2.length))

def equality_si(seg, a):
    return Boolean(np.isclose(seg.length, a))

def intersect_ll(line1, line2):
    matrix = np.stack((line1.normal, line2.normal))
    b = np.array((line1.offset, line2.offset))
    if np.isclose(np.linalg.det(matrix), 0): return None
    return Point(np.linalg.solve(matrix, b))

def intersect_lc(line, circle):
    # shift circle to center
    y = line.offset - np.dot(line.normal, circle.center)
    x_squared = circle.radius_squared - y ** 2
    if np.isclose(x_squared, 0): return Point(y * line.normal + circle.center)
    if x_squared <= 0: return None

    x = np.sqrt(x_squared)
    return [
        Point(-x * line.direction + y * line.normal + circle.center),
        Point(x * line.direction + y * line.normal + circle.center)
    ]

def intersect_lci(line, circle, index, points_order=None):
    res = intersect_lc(line, circle)
    return res_by_index(res, index, points_order)

def intersect_cc(circle1, circle2):
    center_diff = circle2.center - circle1.center
    center_dist_squared = np.dot(center_diff, center_diff)
    if np.isclose(center_dist_squared, 0):
        return None  # concentric circles: no discrete intersection
    relative_center = (circle1.radius_squared - circle2.radius_squared) / center_dist_squared
    center = (circle1.center + circle2.center) / 2 + relative_center*center_diff / 2

    rad_sum  = circle1.radius + circle2.radius
    rad_diff = circle1.radius - circle2.radius
    det = (rad_sum ** 2 - center_dist_squared) * (center_dist_squared - rad_diff ** 2)
    if np.isclose(det, 0): return Point(center)
    if det <= 0: return None
    center_deviation = np.sqrt(det)
    center_deviation = np.array(((-center_deviation,),(center_deviation,)))

    return [
        Point(center + center_dev)
        for center_dev in center_deviation * 0.5 * vector_perp_rot(center_diff) / center_dist_squared
    ]

def intersect_cci(circle1, circle2, index, points_order=None):
    res = intersect_cc(circle1, circle2)
    return res_by_index(res, index, points_order)
    
def intersect_cl(circle, line):
    return intersect_lc(line, circle)

def intersect_cli(circle, line, index, points_order=None):
    return intersect_lci(line, circle, index, points_order)

def intersect_cr(circle, ray):
    return intersect_rc(ray, circle)

def intersect_cri(circle, ray, index, points_order=None):
    return intersect_rci(ray, circle, index, points_order)

def intersect_Cl(arc, line):
    results = intersect_lc(line,arc)
    if not isinstance(results, Iterable) or isinstance(results, str): results = (results,)
    return [p for p in results if arc.contains(p.coords)]

def intersect_lC(line, arc):
    return intersect_Cl(arc, line)

def intersect_Cli(arc, line, index, points_order=None):
    res = intersect_Cl(arc, line)
    return res_by_index(res, index, points_order)

def intersect_lCi(line, arc, index, points_order=None):
    return intersect_Cli(arc, line, index, points_order)

def intersect_Sl(sector, line):
    return intersect_Cl(Arc(sector.center, sector.radius, sector.angles), line)

def intersect_lS(line, sector):
    return intersect_Sl(sector, line)

def intersect_Sli(sector, line, index, points_order=None):
    res = intersect_Sl(sector, line)
    return res_by_index(res, index, points_order)

def intersect_lSi(line, sector, index, points_order=None):
    return intersect_Sli(sector, line, index, points_order)

def intersect_cs(circle, segment):
    results = intersect_lc(segment, circle)
    if (not isinstance(results, Iterable)) or isinstance(results, str): results = (results,)
    return [p for p in results if segment.contains(p.coords)]

def intersect_csi(circle, segment, index, points_order=None):
    res = intersect_cs(circle, segment)
    return res_by_index(res, index, points_order)

def intersect_rc(ray, circle):
    results = intersect_lc(ray, circle)
    if (not isinstance(results, Iterable)) or isinstance(results, str): results = (results,)
    return [p for p in results if ray.contains(p.coords)]

def intersect_rci(ray, circle, index, points_order=None):
    res = intersect_rc(ray, circle)
    return res_by_index(res, index, points_order)

def intersect_sc(segment, circle):
    return intersect_cs(circle, segment)

def intersect_sci(segment, circle, index, points_order=None):
    return intersect_csi(circle, segment, index, points_order)

def intersect_lr(line, ray):
    result = intersect_ll(line, ray)
    if result is None: return None
    return result if ray.contains(result.coords) else None

def intersect_ls(line, segment):
    result = intersect_ll(line, segment)
    if result is None: return None
    return result if segment.contains(result.coords) else None

def intersect_rl(ray, line):
    return intersect_lr(line, ray)

def intersect_rr(r1, r2):
    result = intersect_ll(r1, r2)
    if result is None: return None
    if not r1.contains(result.coords): return None
    if not r2.contains(result.coords): return None
    return result

def intersect_rs(ray, segment):
    result = intersect_ll(ray, segment)
    if result is None: return None
    if not ray.contains(result.coords): return None
    if not segment.contains(result.coords): return None
    return result

def intersect_sl(segment, line):
    return intersect_ls(line, segment)

def intersect_sr(segment, ray):
    return intersect_rs(ray, segment)

def intersect_ss(s1, s2):
    result = intersect_ll(s1, s2)
    if result is None: return None
    if not s1.contains(result.coords): return None
    if not s2.contains(result.coords): return None
    return result

# ── Conic intersections ───────────────────────────────────────────────

def _circle_to_conic(circle):
    """Lift a Circle (center c, radius r) to its Conic matrix form."""
    cx, cy = float(circle.center[0]), float(circle.center[1])
    return Conic.from_coeffs(
        a=1.0, c=1.0,
        d=-2.0 * cx, e=-2.0 * cy,
        f=cx * cx + cy * cy - circle.radius * circle.radius,
    )


def _point_on_both_conics(point, K1, K2, rel_tol=1e-6):
    """True when `point` satisfies both conic equations within tolerance.

    Tolerance is scaled by ``max|M|``: a point is on the curve when
    ``|xᵀMx| ≤ rel_tol · max|M|``. This rides out the rounding that
    accumulates in pencil solving without letting spurious candidates
    slip through.
    """
    v1 = abs(K1.evaluate(point.coords[0], point.coords[1]))
    v2 = abs(K2.evaluate(point.coords[0], point.coords[1]))
    s1 = max(float(np.max(np.abs(K1.matrix))), 1.0)
    s2 = max(float(np.max(np.abs(K2.matrix))), 1.0)
    return v1 <= rel_tol * s1 and v2 <= rel_tol * s2


def intersect_Kl(conic, line):
    """Conic ∩ Line.

    Substituting ``p(t) = p0 + t·v`` (where ``p0 = n·c`` is the closest
    point of the line to the origin and ``v = vector_perp_rot(n)`` —
    the same direction used elsewhere in lib_elements) into
    ``pᵀ M p = 0`` gives a quadratic in t. Returns None, a single Point
    (tangent), or a 2-element list.
    """
    M = conic.matrix
    n = line.normal
    c = line.offset
    p0 = np.array([n[0] * c, n[1] * c, 1.0])
    # Use the same perpendicular convention as Line.v — keeps the
    # intersection-order convention aligned with GGB's Intersect index.
    v = np.array([n[1], -n[0], 0.0])

    A = float(v @ M @ v)
    B = 2.0 * float(p0 @ M @ v)
    C = float(p0 @ M @ p0)

    tol = 1e-12

    if abs(A) > tol:
        disc = B * B - 4 * A * C
        if disc < -1e-9:
            return None
        if abs(disc) < 1e-9:
            t = -B / (2 * A)
            return Point([p0[0] + t * v[0], p0[1] + t * v[1]])
        sq = np.sqrt(disc)
        # Sort ascending: smaller-t point first, regardless of sign(A).
        # Matches GGB's "index 1 = leftmost along line direction" convention.
        t1, t2 = sorted(((-B - sq) / (2 * A), (-B + sq) / (2 * A)))
        return [
            Point([p0[0] + t1 * v[0], p0[1] + t1 * v[1]]),
            Point([p0[0] + t2 * v[0], p0[1] + t2 * v[1]]),
        ]
    if abs(B) > tol:
        t = -C / B
        return Point([p0[0] + t * v[0], p0[1] + t * v[1]])
    # A ≈ 0 and B ≈ 0: line is entirely on the conic, or parallel and outside.
    return None


def intersect_lK(line, conic):
    return intersect_Kl(conic, line)


def intersect_Kli(conic, line, index, points_order=None):
    res = intersect_Kl(conic, line)
    return res_by_index(res, index, points_order)


def intersect_lKi(line, conic, index, points_order=None):
    return intersect_Kli(conic, line, index, points_order)


def intersect_KK(K1, K2):
    """Intersect two conics using the pencil method.

    The family ``λ·M1 + M2`` (λ ∈ ℝ) contains every conic through the
    common points of K1 and K2. Pick λ so ``det(λM1 + M2) = 0`` — the
    resulting degenerate conic factors as a product of two (possibly
    coincident or imaginary) lines. Intersecting each real line with K1
    recovers the intersection points; tolerance-filtering against both
    originals strips any extraneous line ∩ K1 points.

    ``p(λ) = det(λM1 + M2)`` is a cubic. Its coefficients are recovered
    from 4 samples (λ → ±∞, 0, 1, −1) and the real roots via ``np.roots``.
    """
    M1, M2 = K1.matrix, K2.matrix
    a = float(np.linalg.det(M1))
    d = float(np.linalg.det(M2))
    p_plus = float(np.linalg.det(M1 + M2))
    p_minus = float(np.linalg.det(M2 - M1))
    b = (p_plus + p_minus) / 2 - d
    c = (p_plus - p_minus) / 2 - a

    coeffs = [a, b, c, d]
    while len(coeffs) > 1 and abs(coeffs[0]) < 1e-12:
        coeffs = coeffs[1:]
    if not coeffs or all(abs(x) < 1e-12 for x in coeffs):
        return None

    try:
        roots = np.roots(coeffs)
    except np.linalg.LinAlgError:
        return None

    real_roots = [float(r.real) for r in roots if abs(r.imag) < 1e-6]
    if not real_roots:
        return None

    candidates = []
    for lam in real_roots:
        K_deg = Conic(lam * M1 + M2)
        if not K_deg.is_degenerate():
            continue
        lines = K_deg.as_lines()
        if not lines:
            continue
        for line in lines:
            res = intersect_Kl(K1, line)
            if res is None:
                continue
            if isinstance(res, list):
                candidates.extend(res)
            else:
                candidates.append(res)
        if candidates:
            break

    if not candidates:
        return None

    # Deduplicate — a point lying on both decomposed lines appears twice.
    unique = []
    for p in candidates:
        if not any(np.allclose(p.coords, u.coords, atol=1e-6) for u in unique):
            unique.append(p)

    filtered = [p for p in unique if _point_on_both_conics(p, K1, K2)]
    if not filtered:
        return None
    if len(filtered) == 1:
        return filtered[0]
    return filtered


def intersect_KKi(K1, K2, index, points_order=None):
    res = intersect_KK(K1, K2)
    return res_by_index(res, index, points_order)


def intersect_Kc(conic, circle):
    return intersect_KK(conic, _circle_to_conic(circle))


def intersect_cK(circle, conic):
    return intersect_Kc(conic, circle)


def intersect_Kci(conic, circle, index, points_order=None):
    res = intersect_Kc(conic, circle)
    return res_by_index(res, index, points_order)


def intersect_cKi(circle, conic, index, points_order=None):
    return intersect_Kci(conic, circle, index, points_order)


def intersect_Kr(conic, ray):
    res = intersect_Kl(conic, ray)
    if res is None:
        return None
    if not isinstance(res, list):
        return res if ray.contains(res.coords) else None
    return [p for p in res if ray.contains(p.coords)] or None


def intersect_rK(ray, conic):
    return intersect_Kr(conic, ray)


def intersect_Kri(conic, ray, index, points_order=None):
    res = intersect_Kr(conic, ray)
    return res_by_index(res, index, points_order)


def intersect_rKi(ray, conic, index, points_order=None):
    return intersect_Kri(conic, ray, index, points_order)


def intersect_Ks(conic, segment):
    res = intersect_Kl(conic, segment)
    if res is None:
        return None
    if not isinstance(res, list):
        return res if segment.contains(res.coords) else None
    return [p for p in res if segment.contains(p.coords)] or None


def intersect_sK(segment, conic):
    return intersect_Ks(conic, segment)


def intersect_Ksi(conic, segment, index, points_order=None):
    res = intersect_Ks(conic, segment)
    return res_by_index(res, index, points_order)


def intersect_sKi(segment, conic, index, points_order=None):
    return intersect_Ksi(conic, segment, index, points_order)


# ── Function intersections ───────────────────────────────────────────

def intersect_Fl(func, line):
    """Function y = f(x) ∩ Line n·p = c_line.

    Substituting y = f(x) into the line equation reduces to
    ``n[0]·x + n[1]·f(x) = c_line`` — one scalar equation in x.
    Symbolic via ``sympy.solve`` first; if sympy returns nothing real,
    numerical fallback scans for sign changes and refines with Brent's
    method. Vertical lines (n[1]=0) short-circuit to ``x = c_line/n[0]``.
    """
    import sympy as sp

    n = line.normal
    c_line = line.offset

    # Vertical line.
    if abs(n[1]) < 1e-12:
        if abs(n[0]) < 1e-12:
            return None  # degenerate
        x_val = c_line / n[0]
        y_val = func(x_val)
        if not np.isfinite(y_val):
            return None
        return Point([x_val, float(y_val)])

    # Symbolic attempt.
    real_solutions: list = []
    try:
        equation = sp.nsimplify(n[0]) * func.var + sp.nsimplify(n[1]) * func.expr - sp.nsimplify(c_line)
        sym_sols = sp.solve(equation, func.var)
        for s in sym_sols:
            try:
                val = complex(s)
                if abs(val.imag) < 1e-9 and np.isfinite(val.real):
                    real_solutions.append(float(val.real))
            except (TypeError, ValueError):
                continue
    except Exception:
        pass

    # Numerical fallback if sympy found nothing.
    if not real_solutions:
        from scipy.optimize import brentq

        def g(xv):
            try:
                fv = float(func(xv))
                if not np.isfinite(fv):
                    return float('nan')
                return float(n[0]) * xv + float(n[1]) * fv - float(c_line)
            except Exception:
                return float('nan')

        search_range = (-100.0, 100.0)
        xs = np.linspace(search_range[0], search_range[1], 501)
        gs = np.array([g(float(xv)) for xv in xs])
        for i in range(len(xs) - 1):
            a_val, b_val = gs[i], gs[i + 1]
            if not (np.isfinite(a_val) and np.isfinite(b_val)):
                continue
            if a_val * b_val < 0:
                try:
                    root = brentq(
                        lambda v, g=g: g(float(v)),
                        xs[i], xs[i + 1], xtol=1e-12, maxiter=100,
                    )
                    real_solutions.append(float(root))
                except (ValueError, RuntimeError):
                    continue
            elif abs(a_val) < 1e-9:
                real_solutions.append(float(xs[i]))

    # Deduplicate nearby roots.
    dedup: list = []
    for x_sol in sorted(real_solutions):
        if not dedup or abs(x_sol - dedup[-1]) > 1e-6:
            dedup.append(x_sol)

    points = []
    for x_sol in dedup:
        y_sol = func(x_sol)
        if not np.isfinite(y_sol):
            continue
        points.append(Point([float(x_sol), float(y_sol)]))

    if not points:
        return None
    if len(points) == 1:
        return points[0]
    return points


def intersect_lF(line, func):
    return intersect_Fl(func, line)


def intersect_Fli(func, line, index, points_order=None):
    res = intersect_Fl(func, line)
    return res_by_index(res, index, points_order)


def intersect_lFi(line, func, index, points_order=None):
    return intersect_Fli(func, line, index, points_order)


# ── Numeric root-finding helpers ──────────────────────────────────────

def _find_roots_1d(g, x_range=(-50.0, 50.0), n_samples=401,
                   tol=1e-12, dedup_tol=1e-8):
    """Real roots of a scalar callable ``g`` on ``x_range``.

    Strategy: sample on a uniform grid, scan for sign changes or explicit
    zeros, refine with Brent's method. NaN values break continuity
    (skip the interval). Returns sorted, deduplicated roots.
    """
    from scipy.optimize import brentq
    lo, hi = float(x_range[0]), float(x_range[1])
    xs = np.linspace(lo, hi, n_samples)
    gs = np.empty(len(xs), dtype=float)
    for i, x in enumerate(xs):
        try:
            v = float(g(float(x)))
        except Exception:
            v = float('nan')
        gs[i] = v if np.isfinite(v) else float('nan')

    roots = []
    for i in range(len(xs) - 1):
        a, b = gs[i], gs[i + 1]
        if not (np.isfinite(a) and np.isfinite(b)):
            continue
        if a == 0:
            roots.append(float(xs[i]))
        elif a * b < 0:
            try:
                r = brentq(lambda v: float(g(float(v))),
                           xs[i], xs[i + 1], xtol=tol, maxiter=100)
                roots.append(float(r))
            except (ValueError, RuntimeError):
                continue
    if np.isfinite(gs[-1]) and gs[-1] == 0:
        roots.append(float(xs[-1]))

    roots.sort()
    dedup: list = []
    for r in roots:
        if not dedup or abs(r - dedup[-1]) > dedup_tol:
            dedup.append(r)
    return dedup


# ── Function ∩ Conic / Circle / Function ──────────────────────────────

def _g_func_vs_conic(func, M):
    """Return g(x) = pᵀ M p for p = (x, f(x), 1)."""
    A, B, D = M[0, 0], M[0, 1], M[0, 2]
    C, E = M[1, 1], M[1, 2]
    F_const = M[2, 2]

    def g(x_val):
        y_val = func(x_val)
        if not np.isfinite(y_val):
            return float('nan')
        return (A * x_val * x_val + 2.0 * B * x_val * y_val
                + C * y_val * y_val
                + 2.0 * D * x_val + 2.0 * E * y_val
                + F_const)
    return g


def intersect_FK(func, conic):
    """Function ∩ Conic via 1D numeric root-finding on ``pᵀMp = 0``."""
    g = _g_func_vs_conic(func, conic.matrix)
    xs = _find_roots_1d(g)
    points = []
    for x_sol in xs:
        y_sol = func(x_sol)
        if np.isfinite(y_sol):
            points.append(Point([float(x_sol), float(y_sol)]))
    if not points:
        return None
    if len(points) == 1:
        return points[0]
    return points


def intersect_KF(conic, func):
    return intersect_FK(func, conic)


def intersect_FKi(func, conic, index, points_order=None):
    res = intersect_FK(func, conic)
    return res_by_index(res, index, points_order)


def intersect_KFi(conic, func, index, points_order=None):
    return intersect_FKi(func, conic, index, points_order)


def intersect_Fc(func, circle):
    return intersect_FK(func, _circle_to_conic(circle))


def intersect_cF(circle, func):
    return intersect_Fc(func, circle)


def intersect_Fci(func, circle, index, points_order=None):
    res = intersect_Fc(func, circle)
    return res_by_index(res, index, points_order)


def intersect_cFi(circle, func, index, points_order=None):
    return intersect_Fci(func, circle, index, points_order)


def intersect_FF(func1, func2):
    """Function ∩ Function: roots of f₁(x) − f₂(x) = 0."""
    def g(x_val):
        a = func1(x_val)
        b = func2(x_val)
        if not (np.isfinite(a) and np.isfinite(b)):
            return float('nan')
        return a - b
    xs = _find_roots_1d(g)
    points = []
    for x_sol in xs:
        y_sol = func1(x_sol)
        if np.isfinite(y_sol):
            points.append(Point([float(x_sol), float(y_sol)]))
    if not points:
        return None
    if len(points) == 1:
        return points[0]
    return points


def intersect_FFi(func1, func2, index, points_order=None):
    res = intersect_FF(func1, func2)
    return res_by_index(res, index, points_order)


# ── ImplicitCurve intersections ───────────────────────────────────────

def _implicit_search_box():
    """Default 2D search range for implicit-curve intersections.

    Used when the caller doesn't supply one. Large enough to cover
    typical construction bounds while keeping the grid cheap.
    """
    return (-50.0, -50.0, 50.0, 50.0)


def intersect_Il(curve, line):
    """ImplicitCurve ∩ Line.

    Substitute the line parametrization ``p(t) = p0 + t·v`` into the
    implicit ``F(x, y)`` and root-find in t.
    """
    n = line.normal
    c_line = line.offset
    p0 = np.array([n[0] * c_line, n[1] * c_line])
    v = np.array([n[1], -n[0]])

    def g(t):
        x = p0[0] + t * v[0]
        y = p0[1] + t * v[1]
        try:
            val = float(curve(x, y))
            return val if np.isfinite(val) else float('nan')
        except Exception:
            return float('nan')

    ts = _find_roots_1d(g, x_range=(-100.0, 100.0), n_samples=801)
    points = []
    for t in ts:
        points.append(Point([float(p0[0] + t * v[0]),
                             float(p0[1] + t * v[1])]))
    if not points:
        return None
    if len(points) == 1:
        return points[0]
    return points


def intersect_lI(line, curve):
    return intersect_Il(curve, line)


def intersect_Ili(curve, line, index, points_order=None):
    res = intersect_Il(curve, line)
    return res_by_index(res, index, points_order)


def intersect_lIi(line, curve, index, points_order=None):
    return intersect_Ili(curve, line, index, points_order)


def intersect_Is(curve, segment):
    res = intersect_Il(curve, segment)
    if res is None:
        return None
    if not isinstance(res, list):
        return res if segment.contains(res.coords) else None
    return [p for p in res if segment.contains(p.coords)] or None


def intersect_sI(segment, curve):
    return intersect_Is(curve, segment)


def intersect_Isi(curve, segment, index, points_order=None):
    res = intersect_Is(curve, segment)
    return res_by_index(res, index, points_order)


def intersect_sIi(segment, curve, index, points_order=None):
    return intersect_Isi(curve, segment, index, points_order)


def intersect_Ir(curve, ray):
    res = intersect_Il(curve, ray)
    if res is None:
        return None
    if not isinstance(res, list):
        return res if ray.contains(res.coords) else None
    return [p for p in res if ray.contains(p.coords)] or None


def intersect_rI(ray, curve):
    return intersect_Ir(curve, ray)


def intersect_Iri(curve, ray, index, points_order=None):
    res = intersect_Ir(curve, ray)
    return res_by_index(res, index, points_order)


def intersect_rIi(ray, curve, index, points_order=None):
    return intersect_Iri(curve, ray, index, points_order)


def _intersect_two_zero_level_sets(F1, F2, viewport=None, grid_n=128):
    """Points where F₁ = 0 and F₂ = 0.

    Algorithm:
    1. Extract F₁'s zero contour as marching-squares line segments.
    2. Along each segment, find a point with F₂ = 0 via Brent on the
       [0, 1] parameter.
    3. Refine the candidate with a 2D Newton solve (``scipy.optimize.fsolve``)
       so the final accuracy isn't limited by the marching-squares grid.

    Works uniformly for ImplicitCurve ∩ Conic, ∩ Circle, ∩ Function,
    and ∩ ImplicitCurve.
    """
    from scipy.optimize import brentq, fsolve
    from .curve_sampling import marching_squares

    if viewport is None:
        viewport = _implicit_search_box()

    segments = marching_squares(F1, viewport, grid_n=grid_n)

    def _system(xy):
        try:
            v1 = float(F1(xy[0], xy[1]))
            v2 = float(F2(xy[0], xy[1]))
        except Exception:
            return [1e12, 1e12]
        if not np.isfinite(v1):
            v1 = 1e12
        if not np.isfinite(v2):
            v2 = 1e12
        return [v1, v2]

    raw = []
    for seg in segments:
        p1, p2 = seg[0], seg[1]

        def line_g(t, p1=p1, p2=p2):
            x = p1[0] + t * (p2[0] - p1[0])
            y = p1[1] + t * (p2[1] - p1[1])
            try:
                val = float(F2(x, y))
                return val if np.isfinite(val) else float('nan')
            except Exception:
                return float('nan')

        a, b = line_g(0.0), line_g(1.0)
        cand = None
        if not (np.isfinite(a) and np.isfinite(b)):
            continue
        # Tolerance-based near-zero tests. Exact float equality here used
        # to miss cases where rounding made a true zero read back as ±1e-17
        # — the segment endpoint was silently skipped as a valid root.
        _ZTOL = 1e-12
        if abs(a) < _ZTOL:
            cand = (p1[0], p1[1])
        elif abs(b) < _ZTOL:
            cand = (p2[0], p2[1])
        elif a * b < 0:
            try:
                t = brentq(line_g, 0.0, 1.0, xtol=1e-10, maxiter=100)
                cand = (p1[0] + t * (p2[0] - p1[0]),
                        p1[1] + t * (p2[1] - p1[1]))
            except (ValueError, RuntimeError):
                continue
        if cand is None:
            continue

        # 2D Newton refinement. fsolve returns the original guess if it
        # can't improve.
        try:
            sol, info, ier, _ = fsolve(
                _system, [cand[0], cand[1]], full_output=True, xtol=1e-12,
            )
            if ier == 1:
                cand = (float(sol[0]), float(sol[1]))
        except Exception:
            pass
        raw.append(cand)

    dedup: list = []
    for x, y in raw:
        if not any(abs(x - q[0]) < 1e-6 and abs(y - q[1]) < 1e-6 for q in dedup):
            dedup.append((x, y))
    return [Point([x, y]) for x, y in dedup]


def intersect_IK(curve, conic):
    """ImplicitCurve ∩ Conic."""
    def F2(x, y):
        return (conic.matrix[0, 0] * x * x
                + 2.0 * conic.matrix[0, 1] * x * y
                + conic.matrix[1, 1] * y * y
                + 2.0 * conic.matrix[0, 2] * x
                + 2.0 * conic.matrix[1, 2] * y
                + conic.matrix[2, 2])

    points = _intersect_two_zero_level_sets(curve, F2)
    if not points:
        return None
    if len(points) == 1:
        return points[0]
    return points


def intersect_KI(conic, curve):
    return intersect_IK(curve, conic)


def intersect_IKi(curve, conic, index, points_order=None):
    res = intersect_IK(curve, conic)
    return res_by_index(res, index, points_order)


def intersect_KIi(conic, curve, index, points_order=None):
    return intersect_IKi(curve, conic, index, points_order)


def intersect_Ic(curve, circle):
    return intersect_IK(curve, _circle_to_conic(circle))


def intersect_cI(circle, curve):
    return intersect_Ic(curve, circle)


def intersect_Ici(curve, circle, index, points_order=None):
    res = intersect_Ic(curve, circle)
    return res_by_index(res, index, points_order)


def intersect_cIi(circle, curve, index, points_order=None):
    return intersect_Ici(curve, circle, index, points_order)


def intersect_IF(curve, func):
    """ImplicitCurve ∩ Function via the two-level-set algorithm with
    F₂(x, y) = y − f(x).
    """
    def F2(x, y):
        fv = func(x)
        if not np.isfinite(fv):
            # Treat as "outside the domain": return a large value so
            # sign never flips there.
            return float('nan')
        return y - fv

    points = _intersect_two_zero_level_sets(curve, F2)
    if not points:
        return None
    if len(points) == 1:
        return points[0]
    return points


def intersect_FI(func, curve):
    return intersect_IF(curve, func)


def intersect_IFi(curve, func, index, points_order=None):
    res = intersect_IF(curve, func)
    return res_by_index(res, index, points_order)


def intersect_FIi(func, curve, index, points_order=None):
    return intersect_IFi(curve, func, index, points_order)


def intersect_II(curve1, curve2):
    points = _intersect_two_zero_level_sets(curve1, curve2)
    if not points:
        return None
    if len(points) == 1:
        return points[0]
    return points


def intersect_IIi(curve1, curve2, index, points_order=None):
    res = intersect_II(curve1, curve2)
    return res_by_index(res, index, points_order)


# ── Conic properties: Center, Focus, Vertex, Axes, Directrix ──────────

def center_K(conic):
    """Center of ellipse/hyperbola/circle; vertex of parabola (GGB convention);
    the single point of a point-type degenerate. Returns None for families
    with no geometrically meaningful center (double line, empty, etc.)."""
    t = conic.type
    if t == ConicType.CIRCLE:
        res = conic.as_circle()
        return Point(res[0]) if res else None
    if t == ConicType.ELLIPSE:
        p = conic.as_ellipse()
        return Point(p['center']) if p else None
    if t == ConicType.HYPERBOLA:
        p = conic.as_hyperbola()
        return Point(p['center']) if p else None
    if t == ConicType.PARABOLA:
        p = conic.as_parabola()
        return Point(p['vertex']) if p else None
    if t == ConicType.POINT:
        return conic.as_point()
    return None


def focus_K(conic):
    """Foci of the conic: 2 for ellipse/hyperbola, 1 for parabola,
    the center for circles (degenerate)."""
    t = conic.type
    if t == ConicType.CIRCLE:
        res = conic.as_circle()
        return Point(res[0]) if res else None
    if t == ConicType.ELLIPSE:
        p = conic.as_ellipse()
        if p is None:
            return None
        a, b = p['semi_axes']
        cc = np.sqrt(max(0.0, a * a - b * b))
        rot = p['rotation']
        u = np.array([np.cos(rot), np.sin(rot)])
        return [Point(p['center'] + cc * u), Point(p['center'] - cc * u)]
    if t == ConicType.HYPERBOLA:
        p = conic.as_hyperbola()
        if p is None:
            return None
        a, b = p['semi_axes']
        cc = np.sqrt(a * a + b * b)
        rot = p['rotation']
        u = np.array([np.cos(rot), np.sin(rot)])
        return [Point(p['center'] + cc * u), Point(p['center'] - cc * u)]
    if t == ConicType.PARABOLA:
        p = conic.as_parabola()
        if p is None:
            return None
        return Point(p['vertex'] + p['focal_parameter'] * p['axis'])
    return None


def vertex_K(conic):
    """Vertices on the principal axes: 4 for ellipse, 2 for hyperbola,
    1 for parabola, none for circle (any point is a vertex)."""
    t = conic.type
    if t == ConicType.ELLIPSE:
        p = conic.as_ellipse()
        if p is None:
            return None
        a, b = p['semi_axes']
        rot = p['rotation']
        u = np.array([np.cos(rot), np.sin(rot)])
        w = np.array([-np.sin(rot), np.cos(rot)])
        return [
            Point(p['center'] + a * u), Point(p['center'] - a * u),
            Point(p['center'] + b * w), Point(p['center'] - b * w),
        ]
    if t == ConicType.HYPERBOLA:
        p = conic.as_hyperbola()
        if p is None:
            return None
        a, _ = p['semi_axes']
        rot = p['rotation']
        u = np.array([np.cos(rot), np.sin(rot)])
        return [Point(p['center'] + a * u), Point(p['center'] - a * u)]
    if t == ConicType.PARABOLA:
        p = conic.as_parabola()
        return Point(p['vertex']) if p else None
    return None


def axes_K(conic):
    """Returns [major_axis, minor_axis] as Lines for ellipse/hyperbola;
    the single symmetry axis for parabola."""
    t = conic.type
    if t in (ConicType.ELLIPSE, ConicType.HYPERBOLA):
        p = (conic.as_ellipse() if t == ConicType.ELLIPSE
             else conic.as_hyperbola())
        if p is None:
            return None
        center = p['center']
        rot = p['rotation']
        u = np.array([np.cos(rot), np.sin(rot)])
        perp = np.array([-np.sin(rot), np.cos(rot)])
        # Major axis has direction u → normal is perp. Line equation:
        # perp · x = perp · center.
        major = Line(perp, float(np.dot(perp, center)))
        minor = Line(u, float(np.dot(u, center)))
        return [major, minor]
    if t == ConicType.PARABOLA:
        p = conic.as_parabola()
        if p is None:
            return None
        # Axis line through vertex along 'axis' direction → normal = perp.
        return Line(p['perp'], float(np.dot(p['perp'], p['vertex'])))
    return None


def major_axis_K(conic):
    res = axes_K(conic)
    if res is None:
        return None
    return res[0] if isinstance(res, list) else res


def minor_axis_K(conic):
    res = axes_K(conic)
    if res is None or not isinstance(res, list) or len(res) < 2:
        return None
    return res[1]


def semi_major_axis_length_K(conic):
    t = conic.type
    if t == ConicType.CIRCLE:
        res = conic.as_circle()
        return Measure(float(res[1]), 1) if res else None
    if t == ConicType.ELLIPSE:
        p = conic.as_ellipse()
        return Measure(float(p['semi_axes'][0]), 1) if p else None
    if t == ConicType.HYPERBOLA:
        p = conic.as_hyperbola()
        return Measure(float(p['semi_axes'][0]), 1) if p else None
    return None


def semi_minor_axis_length_K(conic):
    t = conic.type
    if t == ConicType.CIRCLE:
        res = conic.as_circle()
        return Measure(float(res[1]), 1) if res else None
    if t == ConicType.ELLIPSE:
        p = conic.as_ellipse()
        return Measure(float(p['semi_axes'][1]), 1) if p else None
    if t == ConicType.HYPERBOLA:
        p = conic.as_hyperbola()
        return Measure(float(p['semi_axes'][1]), 1) if p else None
    return None


def eccentricity_K(conic):
    t = conic.type
    if t == ConicType.CIRCLE:
        return Measure(0.0, 0)
    if t == ConicType.ELLIPSE:
        p = conic.as_ellipse()
        if p is None:
            return None
        a, b = p['semi_axes']
        if a <= 0:
            return None
        c = np.sqrt(max(0.0, a * a - b * b))
        return Measure(float(c / a), 0)
    if t == ConicType.HYPERBOLA:
        p = conic.as_hyperbola()
        if p is None:
            return None
        a, b = p['semi_axes']
        if a <= 0:
            return None
        c = np.sqrt(a * a + b * b)
        return Measure(float(c / a), 0)
    if t == ConicType.PARABOLA:
        return Measure(1.0, 0)
    return None


def linear_eccentricity_K(conic):
    t = conic.type
    if t == ConicType.CIRCLE:
        return Measure(0.0, 1)
    if t == ConicType.ELLIPSE:
        p = conic.as_ellipse()
        if p is None:
            return None
        a, b = p['semi_axes']
        return Measure(float(np.sqrt(max(0.0, a * a - b * b))), 1)
    if t == ConicType.HYPERBOLA:
        p = conic.as_hyperbola()
        if p is None:
            return None
        a, b = p['semi_axes']
        return Measure(float(np.sqrt(a * a + b * b)), 1)
    return None


def directrix_K(conic):
    """Directrix line(s): 1 for parabola, 2 for ellipse/hyperbola."""
    t = conic.type
    if t == ConicType.PARABOLA:
        p = conic.as_parabola()
        if p is None:
            return None
        # Directrix is perpendicular to the axis at distance p behind the vertex.
        point_on_directrix = p['vertex'] - p['focal_parameter'] * p['axis']
        n = p['axis']
        return Line(n, float(np.dot(n, point_on_directrix)))
    if t in (ConicType.ELLIPSE, ConicType.HYPERBOLA):
        p = (conic.as_ellipse() if t == ConicType.ELLIPSE
             else conic.as_hyperbola())
        if p is None:
            return None
        a, b = p['semi_axes']
        if t == ConicType.ELLIPSE:
            c = np.sqrt(max(0.0, a * a - b * b))
        else:
            c = np.sqrt(a * a + b * b)
        if c <= 0:
            return None
        # Directrix distance from center: a²/c = a/e.
        d = a * a / c
        rot = p['rotation']
        u = np.array([np.cos(rot), np.sin(rot)])
        pt1 = p['center'] + d * u
        pt2 = p['center'] - d * u
        return [
            Line(u, float(np.dot(u, pt1))),
            Line(u, float(np.dot(u, pt2))),
        ]
    return None


def coefficients_K(conic):
    """Returns (A, B, C, D, E, F) for A x² + B xy + C y² + D x + E y + F = 0,
    matching GGB's Coefficients() convention."""
    M = conic.matrix
    return [
        float(M[0, 0]),
        2.0 * float(M[0, 1]),
        float(M[1, 1]),
        2.0 * float(M[0, 2]),
        2.0 * float(M[1, 2]),
        float(M[2, 2]),
    ]


# ── Polar and Tangent ─────────────────────────────────────────────────

def polar_pK(point, conic):
    """Polar line of a point with respect to a conic: ``pᵀ M q = 0``."""
    M = conic.matrix
    p = np.array([point.coords[0], point.coords[1], 1.0])
    coeffs = p @ M
    n = coeffs[:2]
    if np.linalg.norm(n) < 1e-12:
        return None
    return Line(n, -float(coeffs[2]))


def polar_Kp(conic, point):
    return polar_pK(point, conic)


def tangent_pK(point, conic):
    """Tangent line(s) from a point to a conic.

    - Point on conic: polar line IS the tangent (single line).
    - Point outside conic: the polar intersects the conic in 2 points —
      the tangent chord's endpoints — and each of these is where a
      tangent from the external point meets the conic. The tangent at
      each such point is that point's own polar.
    - Point inside conic: no real tangents (returns None).
    """
    M = conic.matrix
    p = np.array([point.coords[0], point.coords[1], 1.0])
    val = float(p @ M @ p)
    polar = polar_pK(point, conic)
    if polar is None:
        return None

    scale = max(float(np.max(np.abs(M))), 1.0)
    if abs(val) < 1e-6 * scale:
        return polar

    touch_points = intersect_Kl(conic, polar)
    if touch_points is None:
        return None
    if not isinstance(touch_points, list):
        touch_points = [touch_points]

    tangents = []
    for tp in touch_points:
        tl = polar_pK(tp, conic)
        if tl is not None:
            tangents.append(tl)
    if not tangents:
        return None
    if len(tangents) == 1:
        return tangents[0]
    return tangents


def tangent_Kp(conic, point):
    return tangent_pK(point, conic)


# ── Conic(p1, p2, p3, p4, p5): conic through 5 points ─────────────────

def conic_ppppp(p1, p2, p3, p4, p5):
    """Unique (up to scale) conic through 5 points.

    Each point (xᵢ, yᵢ) gives a linear constraint on the coefficients
    (A, B, C, D, E, F) in ``A x² + B xy + C y² + D x + E y + F = 0``.
    The 5×6 system has a one-dimensional null space; the conic's
    coefficients are any non-trivial vector in that null space,
    recovered via SVD.
    """
    pts = [p1, p2, p3, p4, p5]
    A = np.array([
        [p.coords[0] ** 2, p.coords[0] * p.coords[1], p.coords[1] ** 2, p.coords[0], p.coords[1], 1.0]
        for p in pts
    ])
    try:
        _, _, V = np.linalg.svd(A)
    except np.linalg.LinAlgError:
        return None
    coeffs = V[-1]
    return Conic.from_coeffs(
        a=coeffs[0], b=coeffs[1], c=coeffs[2],
        d=coeffs[3], e=coeffs[4], f=coeffs[5],
    )


# ── Geometric conic constructors (GGB: Ellipse, Hyperbola, Parabola) ─

def _build_focal_conic(f1_arr, f2_arr, a, kind):
    """Construct ellipse / hyperbola from foci and semi-major axis.

    ``kind`` is 'ellipse' (a > c, real ellipse) or 'hyperbola'
    (a < c, real hyperbola). Builds the matrix in canonical form then
    applies the rigid motion ``A = [R | center]`` via the congruence
    ``M_world = A⁻ᵀ · M_canon · A⁻¹``.
    """
    center = (f1_arr + f2_arr) / 2.0
    focus_diff = f2_arr - f1_arr
    c_lin = float(np.linalg.norm(focus_diff)) / 2.0

    if kind == 'ellipse':
        if a <= c_lin:
            return None
        b_sq = a * a - c_lin * c_lin
        M_canon = np.diag([1.0 / (a * a), 1.0 / b_sq, -1.0])
    else:  # hyperbola
        if a >= c_lin:
            return None
        b_sq = c_lin * c_lin - a * a
        M_canon = np.diag([1.0 / (a * a), -1.0 / b_sq, -1.0])

    if c_lin < 1e-12:
        theta = 0.0
    else:
        theta = float(np.arctan2(focus_diff[1], focus_diff[0]))
    cs, sn = np.cos(theta), np.sin(theta)
    A = np.eye(3)
    A[:2, :2] = np.array([[cs, -sn], [sn, cs]])
    A[:2, 2] = center
    A_inv = np.linalg.inv(A)
    return Conic(A_inv.T @ M_canon @ A_inv)


def ellipse_ppi(f1, f2, a):
    return _build_focal_conic(np.asarray(f1.coords), np.asarray(f2.coords), float(a), 'ellipse')


def ellipse_ppm(f1, f2, m):
    return ellipse_ppi(f1, f2, m.value)


def ellipse_ppp(f1, f2, p):
    """Ellipse with foci ``f1``, ``f2`` and a third point on the curve.

    For an ellipse, ``2a = |f1p| + |f2p|`` for any point p on the curve
    (the focal-radii sum definition).
    """
    a = (np.linalg.norm(f1.coords - p.coords) + np.linalg.norm(f2.coords - p.coords)) / 2.0
    return ellipse_ppi(f1, f2, float(a))


def hyperbola_ppi(f1, f2, a):
    return _build_focal_conic(np.asarray(f1.coords), np.asarray(f2.coords), float(a), 'hyperbola')


def hyperbola_ppm(f1, f2, m):
    return hyperbola_ppi(f1, f2, m.value)


def hyperbola_ppp(f1, f2, p):
    """Hyperbola with foci ``f1``, ``f2`` and a third point on the curve.

    ``2a = ||f1p| − |f2p||``.
    """
    a = abs(np.linalg.norm(f1.coords - p.coords) - np.linalg.norm(f2.coords - p.coords)) / 2.0
    return hyperbola_ppi(f1, f2, float(a))


def parabola_pl(focus, directrix):
    """Parabola defined by focus + directrix line.

    vertex = midpoint of focus and its projection on the directrix.
    axis points from directrix to focus.
    focal parameter p = distance(vertex, focus).

    In the local frame ``(u, v)`` aligned with (perp, axis), the
    canonical equation is ``u² = 4 p v`` → matrix
    ``[[1, 0, 0], [0, 0, −2p], [0, −2p, 0]]``.
    """
    n = directrix.normal
    c_line = directrix.offset
    dist_signed = float(np.dot(n, focus.coords)) - c_line
    if abs(dist_signed) < 1e-12:
        return None  # focus on directrix → degenerate
    projection = focus.coords - dist_signed * n
    vertex = (focus.coords + projection) / 2.0
    axis_vec = focus.coords - projection
    axis_norm = float(np.linalg.norm(axis_vec))
    if axis_norm < 1e-12:
        return None
    axis_vec = axis_vec / axis_norm
    p_focal = abs(dist_signed) / 2.0

    M_canon = np.array([
        [1.0, 0.0, 0.0],
        [0.0, 0.0, -2.0 * p_focal],
        [0.0, -2.0 * p_focal, 0.0],
    ])

    perp = np.array([axis_vec[1], -axis_vec[0]])
    A = np.eye(3)
    A[:2, :2] = np.column_stack([perp, axis_vec])
    A[:2, 2] = vertex
    A_inv = np.linalg.inv(A)
    return Conic(A_inv.T @ M_canon @ A_inv)


def parabola_ps(focus, segment):
    """Parabola with focus and a directrix segment (uses the underlying line)."""
    return parabola_pl(focus, segment)


def parabola_pr(focus, ray):
    return parabola_pl(focus, ray)


def line_bisector_pp(p1, p2):
    p = (p1.coords + p2.coords) / 2
    n = p2.coords - p1.coords
    if (n == 0).all(): return None
    return Line(n, np.dot(n, p))

def line_bisector_s(segment):
    p1, p2 = segment.endpoints
    p = (p1 + p2) / 2
    n = p2 - p1
    return Line(n, np.dot(n, p))

def line_pl(point, line):
    return Line(line.normal, np.dot(line.normal, point.coords))

def line_pp(p1, p2):
    if (p1.coords == p2.coords).all(): return None
    n = vector_perp_rot(p1.coords - p2.coords)
    return Line(n, np.dot(p1.coords, n))

def line_pv(pt, vec):
    if (vec.direction == 0).all(): return None
    n = vector_perp_rot(vec.direction)
    return Line(n, np.dot(pt.coords, n))

def line_pr(point, ray):
    return line_pl(point, ray)

def line_ps(point, segment):
    return line_pl(point, segment)

def line_s(segment):
    return Line(segment.normal, segment.offset)

def midpoint_pp(p1, p2):
    return Point((p1.coords+p2.coords)/2)

def midpoint_s(segment):
    p1, p2 = segment.endpoints
    return Point((p1 + p2) / 2)

def mirror_cc(circle, by_circle):
    center_v = circle.center - by_circle.center
    denom = square_norm(center_v) - circle.radius_squared
    if np.isclose(denom, 0):
        return Line(center_v, circle.radius_squared / 2 + np.dot(center_v, by_circle.center))
    else:
        return Circle(
            center = (by_circle.radius_squared/denom) * center_v + by_circle.center,
            r = by_circle.radius_squared * circle.radius / abs(denom)
        )

def mirror_cl(circle, by_line):
    return Circle(
        center = circle.center + by_line.normal*2*(by_line.offset - np.dot(circle.center, by_line.normal)),
        r = circle.radius,
    )

def mirror_cp(circle, by_point):
    return Circle(
        center = 2 * by_point.coords - circle.center,
        r = circle.radius
    )

def mirror_ll(line, by_line):
    n = line.normal - by_line.normal * 2 * np.dot(line.normal, by_line.normal)
    return Line(n, line.offset + 2 * by_line.offset * np.dot(n, by_line.normal) )

def mirror_ls(line, by_segment):
    return mirror_ll(line, by_segment)

def mirror_lp(line, by_point):
    return Line(line.normal, 2 * np.dot(by_point.coords, line.normal) - line.offset)

def mirror_pc(point, by_circle):
    v = point.coords - by_circle.center
    if np.isclose(v, 0).all(): return None
    return Point(by_circle.center + v * (by_circle.radius_squared / square_norm(v)) )

def mirror_pl(point, by_line):
    return Point(point.coords + by_line.normal * 2 * (by_line.offset - np.dot(point.coords, by_line.normal)))

def mirror_pp(point, by_point):
    return Point(2 * by_point.coords - point.coords)

def mirror_ps(point, by_segment):
    return mirror_pl(point, by_segment)

def orthogonal_line_pl(point, line):
    return Line(-line.direction, np.dot(-line.direction, point.coords))

def orthogonal_line_pr(point, ray):
    return orthogonal_line_pl(point, ray)

def orthogonal_line_ps(point, segment):
    return orthogonal_line_pl(point, segment)

def point_():
    return Point(np.random.normal(size = 2))

def point_ii(x, y):
    return Point([x,y])

def point_c(circle, tparam = None):
    """Point on a circle. ``tparam`` is the angle in radians."""
    return Point(circle.center + circle.radius * get_direction(tparam))

def point_l(line, tparam = None):
    """Point on a line. ``tparam`` is the linear parameter along direction."""
    return Point(line.offset * line.normal + line.direction * (tparam if tparam is not None else np.random.normal()) )

def point_s(segment, tparam = None):
    """Point on a segment. ``tparam`` is the linear parameter (0..1 for interior)."""
    return Point(interpolate(segment.endpoints[0], segment.endpoints[1], tparam if tparam is not None else np.random.random()))

def polar_pc(point, circle):
    n = point.coords - circle.center
    if np.isclose(n, 0).all(): return None
    return Line(n, np.dot(n, circle.center) + circle.radius_squared)

def polygon_ppi(p1, p2, n):
    p1c, p2c = (a_to_cpx(p.coords) for p in (p1, p2))
    alpha = 2 * np.pi / n
    center = p2c + (p1c - p2c) / (1 - np.exp(-alpha * 1j))
    v = p2c - center
    points = [Point(cpx_to_a(center + v * np.exp(i * alpha * 1j))) for i in range(1, int(n) - 1)]
    raw_points = [p.coords for p in [p1, p2] + points]
    segments = [
        Segment(p1, p2)
        for p1, p2 in zip(raw_points, raw_points[1:] + raw_points[:1])
    ]
    return [Polygon(raw_points)] + segments + points

def polygon(*points):
    raw_points = [p.coords for p in points]
    segments = [
        Segment(p1, p2)
        for p1, p2 in zip(raw_points, raw_points[1:] + raw_points[:1])
    ]
    return [Polygon(raw_points)] + segments

def prove_b(x):
    logger.info("Prove: %s", x.value)
    return x

def radius_c(circle):
    return Measure(circle.radius, 1)

def ray_pp(p1, p2):
    return Ray(p1.coords, p2.coords - p1.coords)

def rotate_pap(point, angle, by_point):
    return Point(by_point.coords + rotate_vec(point.coords - by_point.coords, angle.size))

def rotate_pAp(point, angle_size, by_point):
    return Point(by_point.coords + rotate_vec(point.coords - by_point.coords, angle_size.value))

def rotate_pip(point, angle_value, by_point):
    return Point(by_point.coords + rotate_vec(point.coords - by_point.coords, angle_value))

def rotate_vAp(vec, angle_size, by_point):
    return Vector([vec.endpoints[0], vec.endpoints[0] + rotate_vec(vec.direction, angle_size.value)])

def rotate_lAp(line, angle_size, by_point):
    n_rotated = rotate_vec(line.normal, angle_size.value)
    
    point_on_line = line.normal * line.offset
    point_rotated = by_point.coords + rotate_vec(point_on_line - by_point.coords, angle_size.value)
    c_rotated = np.dot(point_rotated, n_rotated)
    
    return Line(n_rotated, c_rotated)

def segment_pp(p1, p2):
    return Segment(p1.coords, p2.coords)

def segment_pv(p, vec):
    return Segment(p.coords, p.coords + vec.direction)

def semicircle_pp(p1, p2):
    vec = a_to_cpx(p1.coords - p2.coords)
    return Arc(
        (p1.coords + p2.coords) / 2,
        abs(vec) / 2,
        [np.angle(v) for v in (-vec, vec)]
    )

def tangent_pc(point, circle):
    polar = polar_pc(point, circle)
    intersections = intersect_lc(polar, circle)
    if isinstance(intersections, Iterable) and not isinstance(intersections, str) and len(intersections) == 2:
        return [line_pp(point, x) for x in intersections]
    else: return polar

def tangent_pci(point, circle, index):
    res = tangent_pc(point, circle)
    index = int(max(0, index-1))
    
    if not hasattr(res, '__len__'):
        if index == 0: return res
        else: return None
        
    if len(res) > index: return res[len(res) - index - 1]
    else: return None

def touches_cc(c1, c2):
    lens = c1.radius, c2.radius, np.linalg.norm(c1.center-c2.center)
    return Boolean(np.isclose(sum(lens), 2 * max(lens)))

def touches_lc(line, circle):
    return Boolean(
        np.isclose(circle.radius, np.abs(np.dot(line.normal, circle.center) - line.offset) )
    )

def touches_cl(circle, line):
    return touches_lc(line, circle)

def translate_pv(point, vector):
    return Point(point.coords + vector.direction)

def translate_sv(segment, vector):
    return Segment(*(segment.endpoints + vector.direction))

def translate_cv(circle, vector):
    return Circle(circle.center + vector.direction, circle.radius)

def vector_pp(p1, p2):
    return Vector((p1.coords, p2.coords))

def vector_p(p1):
    return Vector(([0, 0], p1.coords))

def vector_ii(x, y):
    return Vector(([0, 0], [x, y]))

def vector_vi(vec, mod):
    k = mod / np.linalg.norm(vec.direction)
    return Vector(vec.endpoints * k)

#--------------------------------------------------------

def abs_i(a):
    return np.abs(a)

def abs_m(m):
    return Measure(np.abs(m.value), m.dimension)

def value_A(ang_size):
    return float(ang_size.value)

def u_sub_i(a):
    return float(-a)

def u_sub_v(vector):
    return Vector(-(vector.endpoints))

def u_sub_p(point):
    return Point(-(point.coords))

def u_sub_a(angle):
    return AngleSize(-angle.size)

def u_sub_A(anglesize):
    return AngleSize(-anglesize.value)

def u_sub_m(m):
    return Measure(-m.value, m.dimension)

def sub_ii(a, b):
    return float(a - b)

def sub_AA(a1, a2):
    return AngleSize(a1.value - a2.value)

def sub_aA(a, A):
    return AngleSize(a.size - A.value)

def sub_Aa(A, a):
    return AngleSize(A.value - a.size)

def sub_vv(v1, v2):
    return Vector(v1.endpoints - v2.endpoints)

def sub_pv(point, vector):
    return Point(point.coords - vector.direction)

def sub_pp(p1, p2):
    return Point(p1.coords - p2.coords)

def sub_mm(m1, m2):
    if m1.dimension != m2.dimension: return None
    return Measure(m1.value - m2.value, m1.dimension)

def sub_ms(m, s):
    if m.dimension != 1: return None
    return Measure(m.value - s.length, 1)

def sub_sm(s, m):
    if m.dimension != 1: return None
    return Measure(s.length - m.value, 1)

def sub_ss(s1, s2):
    return Measure(s1.length - s2.length, 1)

def pow_ii(a, b):
    return float(a ** b)

def pow_mi(m, i):
    if i != 2: return None
    return Measure(m.value ** i, m.dimension*i)

def pow_si(s, i):
    return Measure(s.length ** i, i)

def mult_mi(m, b):
    return float(m.value * b)

def mult_im(a, m):
    return float(a * m.value)

def mult_ii(a, b):
    return float(a * b)

def mult_vi(vector, a):
    return Vector(vector.endpoints * a)

def mult_iv(a, vector):
    return mult_vi(vector, a)

def mult_ip(a, point):
    return Point(point.coords * a)

def mult_pi(point, a):
    return Point(point.coords * a)

def mult_mm(m1, m2):
    return Measure(m1.value * m2.value, m1.dimension + m2.dimension)

def mult_ms(m, s):
    return Measure(m.value * s.length, m.dimension + 1)

def mult_sm(s, m):
    return mult_ms(m,s)

def mult_ss(s1, s2):
    return Measure(s1.length * s2.length, 2)

def mult_iA(i, angle_size):
    return AngleSize(angle_size.value * i)

def mult_Ai(a, i):
    return mult_iA(i, a)

def mult_is(i, s):
    return Measure(i * s.length, 1)

def div_ii(a, b):
    if b == 0: return None
    return float(a / b)

def div_Ai(angle_size, i):
    return AngleSize(angle_size.value / i)

def div_mm(m1, m2):
    if np.isclose(m2.value, 0): return None
    return Measure(m1.value / m2.value, m1.dimension - m2.dimension)

def div_ms(m, s):
    return Measure(m.value / s.length, m.dimension - 1)

def div_mi(m, i):
    if np.isclose(i, 0): return None
    return Measure(m.value / i, m.dimension)

def div_sm(s, m):
    if np.isclose(m.value, 0): return None
    return Measure(s.length / m.value, 1 - m.dimension)

def div_ss(s1, s2):
    return Measure(s1.length / s2.length, 0)

def div_si(s, i):
    if np.isclose(i, 0): return None
    return Measure(s.length / i, 1)

def div_vi(vector, a):
    return Vector(vector.endpoints / a)

def div_pi(point, a):
    return Point(point.coords / a)

def add_ii(a, b):
    return float(a + b)

def add_vv(v1, v2):
    return Vector(v1.endpoints + v2.endpoints)

def add_pv(point, vector):
    return Point(point.coords + vector.direction)

def add_vp(vector, point):
    return add_pv(point, vector)

def add_pp(p1, p2):
    return Point(p1.coords + p2.coords)

def add_mm(m1, m2):
    if m1.dimension != m2.dimension: return None
    return Measure(m1.value + m2.value, m1.dimension)

def add_ms(m, s):
    if m.dimension != 1: return None
    return Measure(m.value + s.length, 1)

def add_mi(m, i):
    if m.dimension != 0: return None
    return Measure(m.value + i, 0)

def add_ss(s1, s2):
    return Measure(s1.length + s2.length, 1)

#--------------------------------------------------------

def cos_i(x): return float(np.cos(x))
def sin_i(x): return float(np.sin(x))
def tan_i(x): return float(np.tan(x))
def ctan_i(x): return float(1 / np.tan(x))
def sqrt_i(x): return float(np.sqrt(x))

#--------------------------------------------------------
# String-argument constructors: enable DSL forms like
#     f = Function("y = x^2 + 1")
#     g = Conic("x^2 + y^2 = 4")
#     h = ImplicitCurve("sin(x) + cos(y) = 0.5")
# The `str` type is registered as shortcut 'T', so these dispatch by
# name as usual.

def function_T(expr_str):
    try:
        return Function.from_string(expr_str)
    except ValueError as e:
        logger.warning("Function parse failed for %r: %s", expr_str, e)
        return None


def conic_T(expr_str):
    try:
        return Conic.from_string(expr_str)
    except ValueError as e:
        logger.warning("Conic parse failed for %r: %s", expr_str, e)
        return None


def implicit_curve_T(expr_str):
    try:
        return ImplicitCurve.from_string(expr_str)
    except ValueError as e:
        logger.warning("ImplicitCurve parse failed for %r: %s", expr_str, e)
        return None


# ── Command registry ─────────────────────────────────────────────────────
#
# An explicit dict of ``{dispatch_name: impl}`` built once at module import
# from the functions defined in this module. Before this, ``Command.func``
# did a full ``globals()`` lookup per call — slower and, more importantly,
# gave no place to validate that command names use legal shortcut
# characters. A typo like ``intersect_Kf`` (lowercase f is not a type
# shortcut) previously only surfaced as a silent no-match at runtime.
#
# The registry is also exposed for introspection (stub generators, doc
# tooling, web-service auto-discovery) — see ``list_commands`` below.

def _build_command_registry():
    """Walk module globals, register functions whose name matches the
    dispatch naming convention. Validates shortcut characters against
    ``type_to_shortcut`` values; emits a warning on any mismatch."""
    valid_shortcuts = set(type_to_shortcut.values())
    registry: dict[str, object] = {}
    invalid: list[str] = []

    for name, obj in list(globals().items()):
        if not callable(obj) or name.startswith('_'):
            continue
        # Special no-suffix case for polygon(p, p, p, ...).
        if name == 'polygon':
            registry[name] = obj
            continue
        if '_' not in name:
            continue
        base, _, suffix = name.rpartition('_')
        if not base or not suffix:
            continue
        # A dispatch name has a snake_case base and a shortcut suffix of
        # single-character type codes.
        if not all(c in valid_shortcuts for c in suffix):
            # Non-dispatch helper (e.g. res_by_index, toObjArray) — skip
            # silently. Track it only if the base looks command-like so
            # a genuine typo in a future addition shows up in logs.
            if re.match(r'^[a-z][a-z0-9_]*$', base) and base not in {
                'res_by_index', 'to_obj_array', 'str_full_command',
                'str_params', 'str_command',
            }:
                invalid.append(name)
            continue
        registry[name] = obj

    if invalid:
        logger.debug(
            "lib_commands: %d function(s) match dispatch shape but use "
            "unregistered shortcut chars (unreachable from Command.func): %s",
            len(invalid), ', '.join(sorted(invalid)[:10]),
        )
    logger.debug("lib_commands: %d commands registered", len(registry))
    return registry


COMMAND_REGISTRY: dict = _build_command_registry()


def list_commands() -> list[str]:
    """Return sorted list of all dispatchable command names.

    Useful for stub generation, documentation, or web-service integrators
    who need to enumerate the available geometric operations.
    """
    return sorted(COMMAND_REGISTRY.keys())
