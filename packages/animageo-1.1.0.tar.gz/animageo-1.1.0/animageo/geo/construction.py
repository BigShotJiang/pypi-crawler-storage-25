import logging
import itertools
import re
from collections import deque

from .lib_vars import *
from .lib_elements import *
from .lib_commands import *
from .utils import is_number, is_angle_degrees, is_boolean, boolean

logger = logging.getLogger(__name__)

# Identifier pattern: pure name, no operators or whitespace.
# Anything else in a string input is treated as a literal (equations,
# DSL expressions) and passed through to the command unchanged.
_IDENTIFIER_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')

"""Construction state management: elements, variables, commands, dependency tracking."""

#--------------------------------------------------------------------------

def appendIfNew(elem, elemArray):
    for el in elemArray:
        if elem == el: return
    
    elemArray.append(elem)
    
def normalize_name(name):
    if not name:
        raise ValueError("Element name cannot be empty")
    # Заменяем HTML-сущности
    name = name.replace("&apos;", "_prime")
    # Заменяем нижние индексы в фигурных скобках
    name = re.sub(r'{(\w+)}', r'\1', name)
    # Заменяем любые другие недопустимые символы на подчеркивание
    name = re.sub(r'[\']', "_Prime", name)
    # Убедимся, что имя не начинается с цифры
    if name[0].isdigit():
        name = 'var_' + name
    return name

class Construction:
    """Manages geometric construction state: elements, variables, commands, and their dependencies.

    The construction maintains a dependency graph where each element has a level
    (0 = free input, N = depends on level N-1 elements). Commands are executed
    in dependency order. Supports incremental rebuild — only recomputes elements
    whose inputs have changed.

    Attributes:
        elements: List of Element objects (geometry: Points, Lines, Circles, etc.)
        vars: List of Var objects (numeric values: Measures, AngleSizes, Booleans)
        commands: List of Command objects defining how elements are computed
        state: Dict mapping element names to dependency info (level, inputs, outputs, built)
        name_mapping: Dict mapping GeoGebra names to normalized Python identifiers
        phantoms: Dict of temporary variables for complex subexpressions
    """

    def __init__(self):
        self.phantoms = {}
        self.vars = []
        self.elements = [
            Element("xAxis", Line((0, 1), 0), visible=False),
            Element("yAxis", Line((1, 0), 0), visible=False)
        ]
        self.commands = []
        self.state = {}
        self.name_mapping = {}
        # Per-base-name counters used by the exec-DSL registrar
        # (dsl.registrar.__reg_loop__) to uniquify names inside loops /
        # defs as ``p, p_2, p_3, ...``. Persisted across ``dsl.run``
        # calls so repeated loops don't collide.
        self.naming_counters = {}

    def __repr__(self):
        str_out = "--------------------------------\n[[construction]]:\n"

        str_out += "\n[{} phantoms]:".format(len(self.phantoms)) + '\n'
        for key in self.phantoms: str_out += str(key) + ': ' + str(self.phantoms[key]) + '\n'

        str_out += "\n[{} vars]:".format(len(self.vars)) + '\n'
        for var in self.vars: str_out += str(var) + '\n'
       
        str_out += "\n[{} elements]:".format(len(self.elements)) + '\n'
        for element in self.elements: str_out += str(element) + '\n'
        
        str_out += "\n[{} commands]:".format(len(self.commands)) + '\n'
        for command in self.commands: str_out += str(command) + '\n'

        str_out += "\n................................\n"
        str_out += "[[state]]:\n"

        state = []
        for name in self.state:
            level = self.state[name]['level']
            while level >= len(state): state.append([])
            state[level].append(name)

        for level in range(len(state)):
            str_out += f"\n[level {level}]:\n"
            for name in state[level]:
                str_out += name + ('' if self.state[name]['built'] else '*') + "\t"

        str_out += "\n--------------------------------\n"
        return str_out

    def new_repr(self):
        return "--------------------------------\n[[construction]]:\n" + \
            f"\n[{len(self.vars)} vars]:\n" + '\n'.join(map(str, self.vars)) + "\n" + \
                f"\n[{len(self.elements)} elements]:\n" + '\n'.join(map(str, self.elements)) + "\n" + \
                    f"\n[{len(self.commands)} commands]:\n" + '\n'.join(map(str, self.commands)) + "\n" + \
                        "--------------------------------\n"

    def add_new_phantom(self):
        num = 1
        while ('_' + str(num)) in self.phantoms: num += 1
        key = '_' + str(num)
        self.phantoms[key] = None
        return key

    def release_phantom(self, name):
        """Drop an unused phantom entry so the counter doesn't grow unbounded."""
        if name in self.phantoms:
            del self.phantoms[name]
    
    def get_normalized_name(self, name):
        normalized_name = normalize_name(name)
        self.name_mapping[name] = normalized_name
        return normalized_name

    def add(self, obj):
        if isinstance(obj, Var): 
            self.vars.append(obj)
            if obj.name not in self.state:
                self.state[obj.name] = { 'level': 0, 'inputs': [], 'outputs': [], 'input_commands': [], 'built': True }
        elif isinstance(obj, Element): 
            self.elements.append(obj)
            if obj.name not in self.state:
                self.state[obj.name] = { 'level': 0, 'inputs': [], 'outputs': [], 'input_commands': [], 'built': True }
        elif isinstance(obj, Command): 
            self.commands.append(obj)                    
            self.updateStateLevels(obj)

    def update(self, name, data, log = None):
        if isinstance(data, str):
            data_prepared = self.dataByStr(data)
            if data_prepared: data = data_prepared
        
        obj = self.objectByName(name)
        if obj is None:
            if name not in self.state:
                self.state[name] = { 'level': 0, 'inputs': [], 'outputs': [], 'input_commands': [], 'built': False }
            if isinstance(data, (Point, Line, Angle, Polygon, Circle, Vector,
                                  Conic, Function, ImplicitCurve)):
                self.add(Element(name, data, visible = (name[0] != '_')))
                self.state[name]['built'] = True
                if log is not None: log[name] = True
            elif isinstance(data, (int, float, bool, Measure, AngleSize, Boolean)):
                self.add(Var(name, data))
                self.state[name]['built'] = True
                if log is not None: log[name] = True
            elif data is not None:
                logger.warning("Construction.update(%s): unsupported data type %s", name, type(data).__name__)
            else:
                self.add(Element(name, None, visible = (name[0] != '_')))
                self.state[name]['built'] = False
                if log is not None: log[name] = True
        else:
            if isinstance(obj, Var) or isinstance(obj, Element):
                for output in self.state[name]['outputs']:
                    self.state[output]['built'] = False
                # ?здесь нужно ли проверить, что объект не имеет предшедствующих зависимостей
                if not isinstance(obj.data, type(data)):
                    if isinstance(obj, Var):
                        if isinstance(obj.data, AngleSize) and isinstance(data, (int, float)):
                            data = AngleSize(data)
                        elif isinstance(obj.data, (int, float)) and isinstance(data, AngleSize):
                            data = data.value
                    elif data is not None and obj.data is not None:
                        logger.warning("Construction.update('%s'): incompatible types %s != %s", name, type(obj.data).__name__, type(data).__name__)
                obj.data = data
                self.state[name]['built'] = True
                if log is not None: log[name] = True
            elif isinstance(obj, Command):
                logger.warning("Construction.update('%s'): command update not implemented", name)

    def rename(self, old_name, new_name):
        """Rename an element/var and all its references in commands + state.

        Used by the exec-DSL registrar to promote a phantom (``_3``) to
        the user's chosen name (``A``) without rebuilding. Idempotent
        when ``old_name == new_name``. Raises ``ValueError`` if
        ``new_name`` is already taken by a different object.
        """
        if old_name == new_name:
            return
        if self.objectByName(new_name) is not None:
            raise ValueError(
                f"rename: target name '{new_name}' already exists"
            )

        # Drop phantom bookkeeping — the name is a real binding now.
        if old_name in self.phantoms:
            del self.phantoms[old_name]

        # Rename on elements and vars (linear scan, same as element()).
        # When promoting a phantom (``_N``) to a real name, re-enable
        # visibility — the leading-underscore convention used by
        # :meth:`update` had defaulted it to False.
        was_phantom = old_name.startswith('_')
        is_phantom = new_name.startswith('_')
        for elem in self.elements:
            if elem.name == old_name:
                elem.name = new_name
                if was_phantom and not is_phantom:
                    elem.visible = True
        for var in self.vars:
            if var.name == old_name:
                var.name = new_name

        # Rewrite command inputs/outputs (stored as name strings).
        for cmd in self.commands:
            cmd.inputs = [new_name if x == old_name else x for x in cmd.inputs]
            cmd.outputs = [new_name if x == old_name else x for x in cmd.outputs]

        # Move state entry + rewrite cross-references.
        if old_name in self.state:
            self.state[new_name] = self.state.pop(old_name)
        for entry in self.state.values():
            entry['inputs'] = [new_name if x == old_name else x for x in entry['inputs']]
            entry['outputs'] = [new_name if x == old_name else x for x in entry['outputs']]

        # name_mapping: GGB-name → python-name indirection.
        for k, v in list(self.name_mapping.items()):
            if v == old_name:
                self.name_mapping[k] = new_name

        # Re-establish state cross-references for every command that uses
        # ``new_name``. A preceding ``_forget(new_name)`` (DSL overwrite
        # semantics) strips ``new_name`` from every state.inputs/outputs
        # list, but the commands themselves still reference the name —
        # so downstream elements would otherwise never mark themselves
        # dirty when the redefined element updates.
        for cmd in self.commands:
            if new_name in cmd.inputs or new_name in cmd.outputs:
                self.updateStateLevels(cmd)

    def add_and_build(self, cmd, debug=False):
        """Append a command and eagerly rebuild only the nodes it touches.

        Used by the exec-DSL factories so ``A.x`` reads made mid-exec
        see fresh values. The DSL emits commands in the order the user
        wrote them, which is already topological, so no re-sort is
        needed per call; a full ``sortCommands`` runs once at the end
        of :func:`animageo.parsers.dsl.run`.
        """
        self.add(cmd)
        self.rebuild(full=False, debug=debug)

    def _updateStateLevel(self, name, level):
        queue = deque()
        queue.append((name, level))
        
        while queue:
            current_name, current_level = queue.popleft()
            
            if self.state[current_name]['level'] < current_level:
                self.state[current_name]['level'] = current_level
                
                for output in self.state[current_name]['outputs']:
                    next_level = current_level + 1
                    if next_level > self.state[output]['level']:
                        queue.append((output, next_level))

    def sortCommands(self):
        """Sort commands in dependency order using Kahn's topological sort.

        Raises ValueError if a dependency cycle is detected.
        """
        n = len(self.commands)
        if n == 0:
            return

        # Build mapping: output_name -> command index
        producer = {}
        for idx, cmd in enumerate(self.commands):
            for output in cmd.outputs:
                producer[output] = idx

        # Build adjacency list and in-degree
        adj = [[] for _ in range(n)]
        in_degree = [0] * n

        for idx, cmd in enumerate(self.commands):
            deps_seen = set()
            for inp in cmd.inputs:
                inp_name = inp.name if hasattr(inp, 'name') else inp
                if isinstance(inp_name, str) and inp_name in producer:
                    dep_idx = producer[inp_name]
                    if dep_idx != idx and dep_idx not in deps_seen:
                        adj[dep_idx].append(idx)
                        in_degree[idx] += 1
                        deps_seen.add(dep_idx)

        # Kahn's algorithm
        queue = deque(i for i in range(n) if in_degree[i] == 0)
        sorted_indices = []

        while queue:
            i = queue.popleft()
            sorted_indices.append(i)
            for j in adj[i]:
                in_degree[j] -= 1
                if in_degree[j] == 0:
                    queue.append(j)

        if len(sorted_indices) != n:
            cycle_cmds = [str(self.commands[i]) for i in range(n) if in_degree[i] > 0]
            raise ValueError(f"Dependency cycle detected among commands: {cycle_cmds}")

        self.commands = [self.commands[i] for i in sorted_indices]

    def updateStateLevels(self, command):
        for output in command.outputs:
            if is_number(output): raise Exception(f'output could not be a number: {output}')
            if is_angle_degrees(output): raise Exception(f'output could not be an angle_size: {output}')    
            if output not in self.state:
                self.state[output] = { 'level': 0, 'inputs': [], 'outputs': [], 'input_commands': [], 'built': False }
            
            self.state[output]['built'] = False
            appendIfNew(command, self.state[output]['input_commands'])
            
            for input in command.inputs:
                if is_number(input): continue
                if is_angle_degrees(input): continue
                if input not in self.state:
                    self.state[input] = { 'level': 0, 'inputs': [], 'outputs': [], 'input_commands': [], 'built': False }

                appendIfNew(output, self.state[input]['outputs'])
                appendIfNew(input, self.state[output]['inputs'])
                
                self._updateStateLevel(output, max(self.state[output]['level'], self.state[input]['level'] + 1))


    def updateCommand(self, nameCommand, inputs, outputs = None):
        command = None if outputs is None else self.commandByElementName(outputs[0])
        if command is not None:
            command.name = nameCommand
            command.inputs = inputs
            command.outputs = outputs
            self.updateStateLevels(command)
        else:
            self.add(Command(nameCommand, inputs, outputs))

    def element(self, name: str): #) -> Element | None:
        result = list(filter(lambda elem: elem.name == name, self.elements))
        return result[0] if result else None

    def var(self, name: str): #) -> Var | None:
        result = list(filter(lambda var: var.name == name, self.vars))
        return result[0] if result else None

    def objectByName(self, name: str): #) -> Element | Var | None:
        for elem in self.elements:
            if elem.name == name: return elem
        for var in self.vars:
            if var.name == name: return var
        for key in self.phantoms:
            if key == name: return self.phantoms[key]   
        return None

    def commandByElementName(self, name: str): #) -> Command | None:
        result = list(filter(lambda comm: name in comm.outputs, self.commands))
        return result[0] if result else None

    def dataByStr(self, text):
        obj = self.objectByName(text)
        if obj is not None: return obj.data

        if is_number(text): return float(text)
        if is_angle_degrees(text): return AngleSizeFromStr(text)
        if is_boolean(text): return boolean(text)

        #raise Exception("Not found object(s) '{}' or not processing".format(text))
        return None

    def prepareInputs(self, command):
        for i in range(len(command.inputs)):
            value = command.inputs[i]
            if not isinstance(value, str):
                continue
            if _IDENTIFIER_RE.match(value) or is_number(value) \
                    or is_angle_degrees(value) or is_boolean(value):
                command.inputs[i] = self.dataByStr(value)
            # Otherwise: literal string (DSL expression, equation, etc.)
            # — leave as-is so string-arg commands like function_T /
            # conic_T / implicit_curve_T receive the raw text.

    def update_tparam(self, name, tparam, log=None):
        """Update the curve/locus parameter (``tparam``) of a
        constrained point and mark dependents for rebuild.

        For a point constrained to a circle, ``tparam`` is the angle
        in radians; for a segment/line/ray it's the linear parameter
        along the direction.
        """
        elem = self.element(name)
        if elem is None:
            logger.warning("update_tparam('%s'): element not found", name)
            return
        elem.tparam = tparam
        self.state[name]['built'] = False
        for output in self.state[name]['outputs']:
            self.state[output]['built'] = False
        if log is not None:
            log[name] = True

    def get_independents(self):
        """Return dict of independent (animatable) elements with their types and values.

        Returns dict: name -> {type, value/coords/alpha, ...}
        Types: 'free_point', 'alpha_point', 'number', 'measure', 'angle', 'boolean'
        """
        result = {}
        for name, st in self.state.items():
            elem = self.element(name)
            var = self.var(name)

            # Free point: level 0, is a Point, no input commands
            if elem and isinstance(elem.data, Point) and st['level'] == 0 and not st['input_commands']:
                result[name] = {
                    'type': 'free_point',
                    'coords': elem.data.coords.tolist()
                }
                continue

            # Parametrically-constrained point (was "alpha-point"):
            # has a curve/locus parameter and input commands.
            if elem and isinstance(elem.data, Point) and elem.tparam is not None and st['input_commands']:
                cmd = self.commandByElementName(name)
                constraint = 'unknown'
                if cmd:
                    for inp_name in cmd.inputs:
                        inp_obj = self.objectByName(inp_name) if isinstance(inp_name, str) else inp_name
                        inp_data = inp_obj.data if hasattr(inp_obj, 'data') else inp_obj
                        if isinstance(inp_data, Circle):
                            constraint = 'circle'
                            break
                        elif isinstance(inp_data, Segment):
                            constraint = 'segment'
                            break
                        elif isinstance(inp_data, Ray):
                            constraint = 'ray'
                            break
                        elif isinstance(inp_data, Line):
                            constraint = 'line'
                            break
                # Keep the legacy keys ``'alpha_point'``/``'alpha'`` in
                # the output dict — they're wire format for keyframe
                # JSON and external consumers rely on them.
                result[name] = {
                    'type': 'alpha_point',
                    'constraint': constraint,
                    'alpha': elem.tparam,
                    'coords': elem.data.coords.tolist()
                }
                continue

            # Free variable: level 0, no input commands
            if var and st['level'] == 0 and not st['input_commands']:
                if isinstance(var.data, Measure):
                    result[name] = {'type': 'measure',
                                    'value': var.data.value,
                                    'dim': var.data.dimension}
                elif isinstance(var.data, AngleSize):
                    result[name] = {'type': 'angle', 'value': var.data.value}
                elif isinstance(var.data, Boolean):
                    result[name] = {'type': 'boolean', 'value': var.data.value}
                elif isinstance(var.data, (int, float)):
                    result[name] = {'type': 'number', 'value': var.data}

        return result

    def rebuild(self, debug = False, full = False):
        if debug: logger.debug('rebuild(full=%s)', full)
        
        log = {}
        if full:
            for command in self.commands: self.apply(command, debug, log = log)
        else:
            state = []
            for name in self.state:
                level = self.state[name]['level']
                while level >= len(state): state.append([])
                state[level].append(name)

            for level in range(len(state)):
                for name in state[level]:
                    if not self.state[name]['built']:
                        for command in self.state[name]['input_commands']:
                            self.apply(command, debug = debug, log = log)
        
        return log

    def copy(self, command):
        assert(isinstance(command, Command))
        command_copy = Command(command.name, list(command.inputs).copy(), list(command.outputs).copy())
        return command_copy

    def apply(self, command_original, debug = False, log = None):
        command = self.copy(command_original)            
        self.prepareInputs(command)
        input_data = [obj.data if hasattr(obj,"data") else obj for obj in command.inputs]
        
        # Special case for Point on a curve: if ``.tparam`` is set,
        # pass it to the command as an extra input so the dispatcher
        # can compute the position along the locus (circle angle,
        # segment/line/ray linear parameter).
        if len(command.outputs) == 1 and self.element(command.outputs[0]):
            if isinstance(self.element(command.outputs[0]).data, Point):
                if self.element(command.outputs[0]).tparam is not None:
                    input_data.append(self.element(command.outputs[0]).tparam)
        
        # специальный случай для Intersect(Circle, ...): если уже были точки до этого, то используется порядок точек
        points_order = None
        if command.name == 'Intersect':
            circ, circ_name = None, None
            obj2, obj2_name = None, None
            for i, inp in enumerate(command_original.inputs):
                if isinstance(input_data[i], Circle):
                    circ, circ_name = input_data[i], inp.name if hasattr(inp,"name") else inp
                elif i < 2:
                    obj2, obj2_name = input_data[i], inp.name if hasattr(inp,"name") else inp
            
            if circ:
                points_order = []
                for name in self.state[circ_name]['inputs']:
                    elem = self.element(name)
                    if elem is not None:
                        if isinstance(elem.data, Point): points_order.append(elem.data)
                if obj2 is not None:
                    for name in self.state[obj2_name]['inputs']:
                        elem = self.element(name)
                        if elem is not None:
                            if isinstance(elem.data, Point): points_order.append(elem.data)
                            
                # for circ_output in self.state[circ_name]['outputs']:
                #     if self.element(circ_output):
                #         p = self.element(circ_output).data
                #         if isinstance(p, Point): points_order.append(p)

                if (len(points_order) > 0) and is_number(input_data[-1]):
                    input_data.append(points_order)
        
        f = command.func()

        if f is not None:
            try:
                output_data = f(*input_data)
                if not isinstance(output_data, list): output_data = [output_data]
                if debug:
                    str_inputs = [obj.name if hasattr(obj,"name") else obj for obj in command_original.inputs]
                    logger.debug("%s: %s >> %s", f.__name__, str_inputs, command_original.outputs)
                    logger.debug("    in:  %s", input_data)
                    logger.debug("    out: %s", output_data)

                for i in range(len(output_data)):
                    if (i < len(command.outputs)):
                        if self.element(command.outputs[i]) is not None:
                            if not self.element(command.outputs[i]).fixed:
                                self.update(command.outputs[i], output_data[i], log = log)
                        else:
                            self.update(command.outputs[i], output_data[i], log = log)
            except Exception as e:
                str_inputs = [obj.name if hasattr(obj,"name") else obj for obj in command_original.inputs]
                logger.warning("Command '%s(%s)' failed: %s", f.__name__, str_inputs, e)
                for i in range(len(command.outputs)):
                    obj = self.element(command.outputs[i])
                    if obj is None or not obj.fixed:
                        self.update(command.outputs[i], None, log = log)
        else:
            str_inputs = [obj.name if hasattr(obj,"name") else obj for obj in command_original.inputs]
                    
            has_none_attr = False
            for inp in input_data: 
                if inp is None: 
                    has_none_attr = True
                    break
            
            if has_none_attr:
                if debug:
                    logger.debug("%s: %s >> %s (undefined args)", strFullCommand(command.name, command.inputs), str_inputs, command_original.outputs)
            else:
                str_types = [type(x).__name__ for x in input_data]
                logger.warning("No implementation for '%s' with arguments %s", command.name, str_types)
                
            for i in range(len(command.outputs)):
                obj = self.element(command.outputs[i])
                if obj is None or not obj.fixed:
                    self.update(command.outputs[i], None, log = log)
