"""Automatic label placement — greedy solver with 8 candidate positions.

Places labels near their anchor points while minimizing overlaps with other
labels and with geometric objects. Enabled via overlay.label_placement.enabled.

Algorithm: priority-ordered greedy with 8 discrete candidate directions per
label. Most-constrained labels (fewest obstacle-free candidates) are placed
first. Preferred direction is computed per-label as the direction AWAY from
the local concentration of geometry. Deterministic.

Public API:
- ``auto_place_labels(scene)`` — legacy one-shot: compute + apply + rerender.
- ``compute_label_layout(scene, *, cfg=None, canonicalize=False)`` — pure:
  returns ``dict[str, LabelPlacement]`` without mutating anything.
- ``apply_label_layout(scene, layout, *, rerender=True)`` — writes layout
  into ``elem.style`` and optionally rerenders geometry.
- ``compute_angle_label_center(ang, angle_params, ptUnit)`` —
  pure analytical bisector-based angle label center. For per-frame dynamic
  updates during animation. The two gaps (arc-side vs angle-sides) live on
  ``angle_params`` so callers don't re-thread them frame-to-frame.
- ``clear_bbox_cache()`` — invalidate the Tex bbox measurement cache.
"""
import logging
import threading
import numpy as np
from dataclasses import dataclass, field
from math import pi, cos, sin, atan2
from typing import Optional

logger = logging.getLogger(__name__)


# ── Tex bbox measurement cache ────────────────────────────────────────
# Measuring a Tex bbox requires rendering via latex — the expensive step.
# The bbox depends only on (label_text, font_size, tex_template), so we
# cache aggressively. Keyframe snapshots reuse the same labels many times
# → cache is a big win.
#
# Thread-safety: the dict + its lock are module-level. Concurrent render
# jobs that share a Python process (e.g. web-service worker pools using
# threads) read/write through ``_bbox_lock``. The cache is not *scene-
# local*, so callers that want strict isolation should either use
# subprocesses or call ``clear_bbox_cache()`` between jobs.

_bbox_cache: dict = {}
_bbox_lock = threading.Lock()


def clear_bbox_cache():
    """Drop all cached Tex bbox measurements. Call after font or text changes
    (including between render jobs in a reused process)."""
    with _bbox_lock:
        _bbox_cache.clear()


def _measure_label_bbox(label_text: str, font_size: float) -> tuple[float, float]:
    """Return (width, height) of a Tex label in scene MU. Cached, thread-safe."""
    from .ui import correctedLabel, RusTex
    # Template identity is part of the key so a future per-scene template
    # swap won't silently reuse the wrong bbox.
    key = (label_text, float(font_size), id(RusTex))
    with _bbox_lock:
        hit = _bbox_cache.get(key)
    if hit is not None:
        return hit
    from manim import Tex
    tex = Tex(correctedLabel(label_text), tex_template=RusTex)
    tex.set(font_size=font_size)
    dims = (float(tex.width), float(tex.height))
    with _bbox_lock:
        _bbox_cache[key] = dims
    return dims


# ── Layout result dataclasses ─────────────────────────────────────────

@dataclass
class AngleParams:
    """Per-element parameters needed for bisector-based angle-label recompute.

    Captured at layout time; values depend only on Tex bbox and style (not
    on v1/v2/p which may change during animation), so they can be reused
    frame-to-frame to call ``compute_angle_label_center``.

    ``arc_r_px`` is the **effective** outer arc radius in pixels: it already
    includes the expansion from multiple concentric arcs
    (``arc_size_px + (lines - 1) * ang_rshift``), matching what the renderer
    draws in ``animageo.py:CreateMObject``.

    The two gaps are independent: ``gap_arc_px`` controls the clearance
    between the outer arc and the nearest edge of the label, and
    ``gap_sides_px`` enters the narrow-angle clamp that keeps the bbox clear
    of the two sides converging toward the vertex.

    ``angle_range`` mirrors ``elem.style['angle_range']`` ('minor' or 'reflex').
    The narrow-angle clamp uses it to derive the angle measure that is
    actually drawn, so reflex cases (raw > π rendered as supplementary on
    the narrow side) still get the correct clamp.
    """
    arc_r_px: float           # effective outer arc radius, pixels
    half_w: float             # half-width of label bbox in scene MU
    half_h: float             # half-height
    gap_arc_px: float         # gap between arc and label, pixels
    gap_sides_px: float       # gap between angle sides and label bbox, pixels
    angle_range: str = 'minor'  # 'minor' (non-reflex) or 'reflex'


@dataclass
class LabelPlacement:
    """Computed placement for a single label.

    ``offset_ggb`` is what goes into ``elem.style['label_offset_px']`` (ggb pixel units).
    ``label_anchor`` is one of TL/TC/TR/ML/MC/MR/BL/BC/BR.
    ``kind`` is 'static' (regular label) or 'dynamic_angle' (bisector tracked).
    ``angle_params`` is populated for ``kind='dynamic_angle'``.
    """
    name: str
    offset_ggb: tuple
    label_anchor: str
    kind: str = 'static'
    angle_params: Optional[AngleParams] = None

# 8 candidate directions (angle from positive-x, CCW):
# E, NE, N, NW, W, SW, S, SE
_DIRECTIONS = np.array([
    [cos(i * pi / 4), sin(i * pi / 4)]
    for i in range(8)
])

# For each direction index, the label anchor should be on the OPPOSITE side
# so the nearest edge of the label faces the anchor point.
# For cardinal directions: mid-edge anchor (ML, BC, MR, TC)
# For diagonals: also mid-edge of the side MOST perpendicular to offset,
# which gives uniform visual gap regardless of label width.
#  idx:  E    NE   N    NW   W    SW   S    SE
_DIR_TO_ANCHOR = ['ML', 'BC', 'BC', 'BC', 'MR', 'TC', 'TC', 'TC']


@dataclass
class LabelInfo:
    name: str
    anchor: np.ndarray       # 2D point in scene coords
    half_w: float            # half-width of label bbox (scene MU)
    half_h: float            # half-height
    margin: float = 0.0      # extra distance from anchor (e.g. point visual radius)
    preferred_dir: int = 1   # computed: direction away from geometry density
    fixed_center: np.ndarray = None  # exact position (bypasses 8-candidate solver)
    fixed_anchor: str = None         # anchor string for fixed_center (e.g. 'MC')
    locked: bool = False


# ── Geometry helpers ──────────────────────────────────────────────────

def _bbox_overlap_area(cx1, cy1, hw1, hh1, cx2, cy2, hw2, hh2):
    """Intersection area of two AABBs: center (cx,cy) + half-sizes (hw,hh)."""
    dx = min(cx1 + hw1, cx2 + hw2) - max(cx1 - hw1, cx2 - hw2)
    dy = min(cy1 + hh1, cy2 + hh2) - max(cy1 - hh1, cy2 - hh2)
    if dx <= 0 or dy <= 0:
        return 0.0
    return dx * dy


def _point_in_bbox(px, py, cx, cy, hw, hh):
    """Check if point (px,py) is inside bbox centered at (cx,cy) with half-sizes."""
    return abs(px - cx) <= hw and abs(py - cy) <= hh


def _segment_bbox_overlap(p1, p2, cx, cy, hw, hh):
    """Approximate length of segment p1→p2 inside bbox. Uses dense sampling."""
    n = max(4, int(np.linalg.norm(p2 - p1) / (min(hw, hh) * 0.5)) + 1)
    n = min(n, 60)
    t = np.linspace(0, 1, n).reshape(-1, 1)
    pts = p1 + t * (p2 - p1)
    inside_x = np.abs(pts[:, 0] - cx) <= hw
    inside_y = np.abs(pts[:, 1] - cy) <= hh
    count = int(np.sum(inside_x & inside_y))
    seg_len = float(np.linalg.norm(p2 - p1))
    return seg_len * count / n


def _circle_bbox_intersects(circle_cx, circle_cy, circle_r, bbox_cx, bbox_cy, hw, hh):
    """Check if a circle (or arc) intersects an axis-aligned bbox.

    Returns True if the circle's circumference passes through or touches the bbox.
    Uses the nearest-point-on-bbox approach: find the closest point on the bbox
    to the circle center, then check if it's within radius range.
    """
    # Clamp circle center to bbox to find the nearest point on bbox boundary
    nearest_x = max(bbox_cx - hw, min(circle_cx, bbox_cx + hw))
    nearest_y = max(bbox_cy - hh, min(circle_cy, bbox_cy + hh))
    dist_nearest = (nearest_x - circle_cx) ** 2 + (nearest_y - circle_cy) ** 2

    # Farthest corner of bbox from circle center
    far_x = bbox_cx + hw if circle_cx < bbox_cx else bbox_cx - hw
    far_y = bbox_cy + hh if circle_cy < bbox_cy else bbox_cy - hh
    dist_farthest = (far_x - circle_cx) ** 2 + (far_y - circle_cy) ** 2

    r2 = circle_r ** 2
    # Circle passes through bbox if: nearest point is inside circle AND
    # farthest point is outside circle (or the whole bbox is inside the circle)
    # Simplified: circle intersects bbox if nearest_dist <= r² AND farthest_dist >= r²
    # OR if the center is inside the bbox
    center_inside = abs(circle_cx - bbox_cx) <= hw and abs(circle_cy - bbox_cy) <= hh
    return (dist_nearest <= r2 and dist_farthest >= r2) or center_inside


def _sample_arc(center, radius, angle_start, angle_span, n=12):
    """Return n sample points along a circular arc."""
    angles = np.linspace(angle_start, angle_start + angle_span, n)
    return np.column_stack([
        center[0] + radius * np.cos(angles),
        center[1] + radius * np.sin(angles),
    ])


# ── Obstacle collection ──────────────────────────────────────────────

def _collect_obstacles(scene):
    """Collect obstacles: segments, circles (center+radius), and loose points."""
    from .geo import lib_elements as geo

    segments = []   # list of (p1, p2) as 2D arrays
    circles = []    # list of (center_2d, radius)
    arc_pts = []    # loose sample points (for points, angle arcs, etc.)

    for elem in scene.geo.elements:
        if not elem.visible:
            continue
        d = elem.data
        if isinstance(d, geo.Point):
            arc_pts.append(d.coords[:2])
        elif isinstance(d, geo.Segment):
            segments.append((d.endpoints[0][:2].copy(), d.endpoints[1][:2].copy()))
        elif isinstance(d, (geo.Line, geo.Ray)):
            if hasattr(d, 'endpoints') and d.endpoints is not None:
                segments.append((d.endpoints[0][:2].copy(), d.endpoints[1][:2].copy()))
        elif isinstance(d, geo.Circle):
            circles.append((d.center[:2].copy(), d.radius))
        elif isinstance(d, (geo.Arc, geo.CircleSector)):
            a_start, a_end = d.angles
            circles.append((d.center[:2].copy(), d.radius))  # treat as full circle for simplicity
        elif isinstance(d, geo.Angle):
            r_ang = min(np.linalg.norm(d.side1), np.linalg.norm(d.side2)) * 0.3
            pts = _sample_arc(d.vertex[:2], r_ang, d.start_angle, d.size, 12)
            for k in range(len(pts) - 1):
                segments.append((pts[k], pts[k + 1]))
        elif isinstance(d, geo.Polygon):
            pts = d.vertices
            for i in range(len(pts)):
                segments.append((pts[i][:2].copy(), pts[(i + 1) % len(pts)][:2].copy()))
        elif isinstance(d, geo.Vector):
            if hasattr(d, 'endpoints') and d.endpoints is not None:
                segments.append((d.endpoints[0][:2].copy(), d.endpoints[1][:2].copy()))

    arc_pts_arr = np.array(arc_pts) if arc_pts else np.empty((0, 2))
    return segments, circles, arc_pts_arr


def _all_obstacle_points(segments, arc_pts, density=30):
    """Flatten all obstacles into a point cloud (for density computation)."""
    pts = list(arc_pts) if len(arc_pts) > 0 else []
    for p1, p2 in segments:
        n = max(4, int(np.linalg.norm(p2 - p1) * density) + 1)
        n = min(n, 80)
        t = np.linspace(0, 1, n).reshape(-1, 1)
        pts.extend(p1 + t * (p2 - p1))
    return np.array(pts) if pts else np.empty((0, 2))


# ── Label collection ─────────────────────────────────────────────────

def _get_anchor(elem):
    """Return the 2D anchor point for a label based on element type."""
    from .geo import lib_elements as geo

    d = elem.data
    if isinstance(d, geo.Point):
        return d.coords[:2].copy()
    elif isinstance(d, geo.Segment):
        return ((d.endpoints[0] + d.endpoints[1]) / 2)[:2]
    elif isinstance(d, geo.Angle):
        return d.vertex[:2].copy()
    elif isinstance(d, (geo.Circle, geo.Arc, geo.CircleSector)):
        return d.center[:2].copy()
    elif isinstance(d, (geo.Line, geo.Ray)):
        if hasattr(d, 'endpoints') and d.endpoints is not None:
            return ((d.endpoints[0] + d.endpoints[1]) / 2)[:2]
        return np.zeros(2)
    elif isinstance(d, geo.Polygon):
        return np.mean(d.vertices[:, :2], axis=0)
    elif isinstance(d, geo.Vector):
        if hasattr(d, 'endpoints') and d.endpoints is not None:
            return ((d.endpoints[0] + d.endpoints[1]) / 2)[:2]
    return np.zeros(2)


def _compute_preferred_dir(anchor, obstacle_cloud, radius=2.0):
    """Compute preferred direction: AWAY from local geometry density.

    Finds the centroid of obstacle points within `radius` of the anchor,
    then returns the direction index (0-7) pointing away from that centroid.
    Falls back to NE (index 1) if no obstacles are nearby.
    """
    if len(obstacle_cloud) == 0:
        return 1  # default NE

    diffs = obstacle_cloud - anchor
    dists = np.linalg.norm(diffs, axis=1)
    mask = dists < radius
    if mask.sum() == 0:
        return 1

    # Weight by inverse distance (closer obstacles matter more)
    weights = 1.0 / (dists[mask] + 0.01)
    centroid = np.average(diffs[mask], axis=0, weights=weights)

    if np.linalg.norm(centroid) < 1e-6:
        return 1

    # Direction AWAY from centroid
    away_angle = atan2(-centroid[1], -centroid[0])
    if away_angle < 0:
        away_angle += 2 * pi

    # Snap to nearest of 8 directions
    idx = int(round(away_angle / (pi / 4))) % 8
    return idx


def compute_angle_label_center(ang, angle_params: AngleParams,
                               ptUnit: float) -> np.ndarray:
    """Analytical center of an angle label along the current bisector.

    Pure function of the Angle element's live fields (``ang.vertex, ang.side1, ang.side2,
    ang.size``) and cached ``AngleParams``. Safe to call every frame during
    animation — output is a continuous function of v1/v2/p, so no jumps.

    The two gap parameters on ``angle_params`` have independent roles:
    - ``gap_arc_px`` sets the clearance between the outer arc and the label:
      ``dist = arc_r + max(hw, hh) + gap_arc``.
    - ``gap_sides_px`` enters the narrow-angle clamp
      ``dist ≥ (half_diag + gap_sides) / sin(half_angle)`` which pushes the
      label further along the bisector as the two sides converge, keeping
      the bbox clear of both sides.

    ``arc_r_px`` is expected to be the **effective** outer radius — i.e.
    already inflated for multi-arc style (``lines > 1``) at layout time.

    Returns 2D center position in scene MU.
    """
    v1n = ang.side1[:2] / (np.linalg.norm(ang.side1[:2]) + 1e-12)
    v2n = ang.side2[:2] / (np.linalg.norm(ang.side2[:2]) + 1e-12)
    bisector = v1n + v2n
    bis_len = np.linalg.norm(bisector)
    if bis_len > 1e-6:
        bisector = bisector / bis_len
    else:
        bisector = v1n

    # For angle_range='reflex' (rendering the reflex side) the label lives on
    # the OPPOSITE side from the v1n+v2n bisector — flip direction.
    if angle_params.angle_range == 'reflex':
        bisector = -bisector

    arc_r = angle_params.arc_r_px / ptUnit
    hw = angle_params.half_w
    hh = angle_params.half_h
    gap_arc = angle_params.gap_arc_px / ptUnit
    dist = arc_r + max(hw, hh) + gap_arc

    # Narrow-angle clamp uses the ANGLE-AS-DRAWN. For angle_range='minor' this
    # is the supplementary when raw is reflex; for angle_range='reflex' the
    # angle is always wide, so the clamp effectively disables itself
    # (half_angle > π/2 → sin() still positive but large → min_dist small).
    effective_angle = _effective_render_angle(ang.size, angle_params.angle_range)
    half_angle = effective_angle / 2
    if 0.01 < half_angle < pi / 2:
        half_diag = np.sqrt(hw * hw + hh * hh)
        min_clearance = half_diag + angle_params.gap_sides_px / ptUnit
        min_dist = min_clearance / sin(half_angle)
        dist = max(dist, min_dist)

    return ang.vertex[:2] + bisector * dist


DEFAULT_ANGLE_RADIUS_CONFIG = {
    'enabled': False,
    'exp': 0.25,              # scale factor is (pivot / angle)**exp
    'pivot_rad': pi / 2,      # angle at which scale = 1 (no change)
    'min_px': 12,             # lower floor on arc radius
    'max_arm_fraction': 0.65, # upper cap as fraction of shortest arm (pixels)
    'apply_to_right': False,  # also scale right-angle markers
}


def _effective_render_angle(raw_angle: float, angle_range: str = 'minor') -> float:
    """Return the angle measure that the renderer actually draws.

    Mirrors the `angle_range` handling in `animageo.CreateMObject`:
    - angle_range='minor' (default): renders the non-reflex (≤π) sector.
      If raw angle is reflex, flips to the supplementary `2π - raw`.
    - angle_range='reflex': renders the reflex (>π) sector. If raw is
      non-reflex, flips to `2π - raw`.

    Both auto-radius scaling and the narrow-angle clamp in
    ``compute_angle_label_center`` need this "as-drawn" measure — not the
    raw CCW span — because the narrow-side geometry is what pinches the
    arc and pushes the label.
    """
    raw = float(raw_angle)
    if angle_range == 'minor' and raw > pi:
        return 2 * pi - raw
    if angle_range == 'reflex' and raw < pi:
        return 2 * pi - raw
    return raw


def compute_effective_arc_size_px(elem, ang_data, scene_style, *,
                                  base_px: float = None) -> float:
    """Resolve the base arc radius for an angle, with optional auto-scaling.

    When ``overlay.angle_radius.enabled=False`` (default), returns the raw
    ``elem.style['arc_size_px']`` unchanged — byte-for-byte identical to the
    previous behavior on GGB imports.

    When enabled, scales by ``(pivot / angle)**exp`` (narrower angles get a
    bigger radius so the arc doesn't disappear between close sides), then
    clamps to ``[min_px, max_arm_fraction * min(|v1|, |v2|) * ptUnit]``.

    Per-element ``elem.style['auto_radius'] = False`` opts out and returns
    the raw value, even when the global switch is on — escape hatch for
    manual overrides.

    ``base_px`` (optional): pre-resolved base radius, typically from the
    style resolver. When given, replaces the legacy ``elem.style`` lookup.
    This lets the renderer use builtin-defaults / overlay values for DSL
    angles whose ``elem.style`` is empty, without seeding elem.style.
    """
    base = float(base_px if base_px is not None
                 else elem.style.get('arc_size_px', 30))
    cfg = scene_style.rendering.get('angle_radius', {})
    if not cfg.get('enabled', DEFAULT_ANGLE_RADIUS_CONFIG['enabled']):
        return base
    if elem.style.get('auto_radius', True) is False:
        return base

    exp = float(cfg.get('exp', DEFAULT_ANGLE_RADIUS_CONFIG['exp']))
    pivot = float(cfg.get('pivot_rad', DEFAULT_ANGLE_RADIUS_CONFIG['pivot_rad']))
    min_px = float(cfg.get('min_px', DEFAULT_ANGLE_RADIUS_CONFIG['min_px']))
    max_frac = float(cfg.get('max_arm_fraction',
                             DEFAULT_ANGLE_RADIUS_CONFIG['max_arm_fraction']))

    # Scale against the ANGLE-AS-DRAWN (supplementary when renderer flips).
    # Using raw ang.size would under-scale reflex cases where the visible
    # arc actually lives on the narrow supplementary side.
    angle_range = elem.style.get('angle_range', 'minor') or 'minor'
    angle = max(_effective_render_angle(ang_data.size, angle_range), 0.01)
    scaled = base * (pivot / angle) ** exp

    ptUnit = scene_style.export.get('ptUnit', 1)
    arm_min = float(min(np.linalg.norm(ang_data.side1), np.linalg.norm(ang_data.side2)))
    max_px = max_frac * arm_min * ptUnit

    lo = min_px
    hi = max(max_px, lo)  # guard degenerate arm_min ≈ 0
    return float(np.clip(scaled, lo, hi))


def _angle_effective_arc_r_px(base_arc_px: float, lines: int,
                              ang_rshift_px: float) -> float:
    """Outer arc radius in pixels including multi-arc expansion.

    Mirrors the renderer in ``animageo.py:CreateMObject``: with ``lines`` N,
    the outer radius is ``base_arc_px + (N - 1) * ang_rshift``.
    ``ang_rshift_px`` is ``scene.style.ang_rshift`` — in the same unit as
    ``base_arc_px`` (both get divided by ``ptUnit`` at render time).
    """
    lines = int(lines or 1)
    if lines <= 1:
        return base_arc_px
    return base_arc_px + (lines - 1) * ang_rshift_px


def _collect_labels(scene, font_size, gap_arc_px=3, gap_sides_px=3):
    """Collect LabelInfo for all visible elements with label_visible=True."""
    from .geo import lib_elements as geo

    ptUnit = scene.style.export['ptUnit']
    default_dot_size = scene.style.dot_size
    ang_rshift_px = getattr(scene.style, 'ang_rshift', 0.0)
    scene_style = scene.style

    labels = []
    for elem in scene.geo.elements:
        if not elem.visible or elem.style.get('label_visible') != True:
            continue
        if elem.style.get('label_placement_locked'):
            continue

        label_text = elem.style.get('label_text', '$' + elem.name + '$')
        # Respect per-element font size (from ImportPolicy, builtin
        # defaults, or per_type/per_name overlay) so the bbox used for
        # placement matches what will actually be rendered. Mirror the
        # renderer's priority: pixel-invariant ``font_size_px`` first
        # (resolver-routed so overlay/defaults reach it), legacy manim-unit
        # ``font_size`` second, scene default last.
        from .style.resolver import resolve as _resolve
        fs_px = _resolve(scene, elem, 'font_size_px', default=None)
        if fs_px is not None:
            from .constants import GGB_FONT_SCALE
            font_px = fs_px * GGB_FONT_SCALE / ptUnit
        else:
            font_px = _resolve(scene, elem, 'font_size', default=font_size)
        tex_w, tex_h = _measure_label_bbox(label_text, font_px)
        hw = tex_w / 2
        hh = tex_h / 2

        # Compute margin and preferred direction per element type
        margin = 0.0

        if isinstance(elem.data, geo.Point):
            point_size = _resolve(scene, elem, 'size_px', default=default_dot_size)
            margin = point_size / 2 / ptUnit  # radius in scene MU

        elif isinstance(elem.data, geo.Angle):
            # Angle labels: exact position along bisector, past the arc.
            # Delegate to the extracted pure helper so the math stays in one
            # place and can be reused per-frame during animation.
            anchor_pt = _get_anchor(elem)
            base_arc = compute_effective_arc_size_px(elem, elem.data, scene_style)
            lines = int(elem.style.get('tick_count', 1) or 1)
            angle_range = elem.style.get('angle_range', 'minor') or 'minor'
            ap = AngleParams(
                arc_r_px=_angle_effective_arc_r_px(base_arc, lines, ang_rshift_px),
                half_w=hw,
                half_h=hh,
                gap_arc_px=gap_arc_px,
                gap_sides_px=gap_sides_px,
                angle_range=angle_range,
            )
            fc = compute_angle_label_center(elem.data, ap, ptUnit)

            labels.append(LabelInfo(
                name=elem.name,
                anchor=anchor_pt,
                half_w=hw,
                half_h=hh,
                fixed_center=fc,
                fixed_anchor='MC',
            ))
            continue

        labels.append(LabelInfo(
            name=elem.name,
            anchor=_get_anchor(elem),
            half_w=hw,
            half_h=hh,
            margin=margin,
        ))
    return labels


# ── Candidate generation & scoring ───────────────────────────────────

def _generate_candidates(anchor, distance):
    """Return 8 candidate label centers around the anchor."""
    return anchor + distance * _DIRECTIONS


def _score_candidate(center, hw, hh, padding,
                     placed, segments, circles, arc_pts,
                     preferred_dir, candidate_idx, weights):
    """Score a candidate position. Lower is better."""
    w_anchor, w_label, w_geom = weights
    cx, cy = center
    hw_p, hh_p = hw + padding, hh + padding

    # Direction penalty: angular distance from preferred direction
    dist = abs(candidate_idx - preferred_dir)
    dir_penalty = min(dist, 8 - dist)
    cost = w_anchor * dir_penalty

    # Label-label overlap
    for pc, phw, phh in placed:
        area = _bbox_overlap_area(cx, cy, hw_p, hh_p, pc[0], pc[1], phw, phh)
        if area > 0:
            cost += w_label * area

    # Label-geometry overlap: exact segment intersection
    for p1, p2 in segments:
        seg_inside = _segment_bbox_overlap(p1, p2, cx, cy, hw_p, hh_p)
        if seg_inside > 0:
            cost += w_geom * (1.0 + seg_inside)

    # Label-geometry overlap: circles (analytical)
    for cc, cr in circles:
        if _circle_bbox_intersects(cc[0], cc[1], cr, cx, cy, hw_p, hh_p):
            cost += w_geom * 2.0

    # Label-geometry overlap: loose point samples
    if len(arc_pts) > 0:
        inside_x = np.abs(arc_pts[:, 0] - cx) <= hw_p
        inside_y = np.abs(arc_pts[:, 1] - cy) <= hh_p
        hits = int(np.sum(inside_x & inside_y))
        cost += w_geom * hits

    return cost


# ── Greedy solver ─────────────────────────────────────────────────────

def _solve_greedy(labels, segments, circles, arc_pts, distance, padding, weights, ptUnit=1):
    """Place labels greedily. Returns list of (name, center, dir_idx) triples."""
    # Pre-compute difficulty: how many of 8 candidates have geometry overlaps
    # Fixed-center labels (angles) get highest priority (placed first)
    difficulties = []
    for lbl in labels:
        if lbl.fixed_center is not None:
            difficulties.append((-1, lbl.name))
            continue
        candidates = _generate_candidates(lbl.anchor, distance + lbl.margin)
        hw_p, hh_p = lbl.half_w + padding, lbl.half_h + padding
        free = 0
        for c in candidates:
            has_hit = False
            for p1, p2 in segments:
                if _segment_bbox_overlap(p1, p2, c[0], c[1], hw_p, hh_p) > 0:
                    has_hit = True
                    break
            if not has_hit:
                for cc, cr in circles:
                    if _circle_bbox_intersects(cc[0], cc[1], cr, c[0], c[1], hw_p, hh_p):
                        has_hit = True
                        break
            if not has_hit and len(arc_pts) > 0:
                inside_x = np.abs(arc_pts[:, 0] - c[0]) <= hw_p
                inside_y = np.abs(arc_pts[:, 1] - c[1]) <= hh_p
                if np.any(inside_x & inside_y):
                    has_hit = True
            if not has_hit:
                free += 1
        difficulties.append((8 - free, lbl.name))

    order = sorted(range(len(labels)), key=lambda i: difficulties[i])

    placed = []
    result = []

    for idx in order:
        lbl = labels[idx]

        # Fixed-center labels (angles): bypass candidate system entirely
        if lbl.fixed_center is not None:
            center = lbl.fixed_center
            # Use fixed_anchor direction for _DIR_TO_ANCHOR lookup
            bis_dir = center - lbl.anchor
            bis_angle = atan2(bis_dir[1], bis_dir[0])
            if bis_angle < 0:
                bis_angle += 2 * pi
            best = int(round(bis_angle / (pi / 4))) % 8
            placed.append((center, lbl.half_w + padding, lbl.half_h + padding))
            result.append((lbl.name, center, best))
            continue

        # Place at base distance. If overlaps, nudge outward in 2px steps.
        base_dist = distance + lbl.margin
        max_dir_penalty = weights[0] * 4
        step = 1 / ptUnit  # 1px nudge step

        best_center = None
        best_dir = 0
        best_prev = float('inf')

        for nudge in range(11):  # up to 10 nudge steps = +10px max
            d = base_dist + nudge * step
            candidates = _generate_candidates(lbl.anchor, d)
            scores = [
                _score_candidate(
                    candidates[i], lbl.half_w, lbl.half_h, padding,
                    placed, segments, circles, arc_pts,
                    lbl.preferred_dir, i, weights,
                )
                for i in range(8)
            ]
            best_i = int(np.argmin(scores))
            best_s = scores[best_i]

            if best_s < best_prev:
                best_center = candidates[best_i]
                best_dir = best_i
                best_prev = best_s

            if best_s <= max_dir_penalty:
                break

        placed.append((best_center, lbl.half_w + padding, lbl.half_h + padding))
        result.append((lbl.name, best_center, best_dir))

    return result


# ── Public API ────────────────────────────────────────────────────────

DEFAULT_CONFIG = {
    'distance_px': 6,           # distance from anchor to label center (pixels)
    'padding_px': 2,            # gap around label bbox (pixels)
    # Legacy unified gap — used as fallback when the two split keys below
    # are absent. New configs should prefer angle_gap_arc_px / angle_gap_sides_px.
    'angle_gap_px': 3,
    'angle_gap_arc_px': None,   # gap between arc and angle label (pixels)
    'angle_gap_sides_px': None, # gap between sides and angle label bbox (pixels)
    'w_anchor': 1.0,
    'w_label': 10.0,
    'w_geom': 8.0,
}


def compute_label_layout(scene, *, cfg=None, canonicalize: bool = False) -> dict:
    """Compute label placements for every visible labelled element. Pure.

    Does not mutate ``elem.style`` or the scene. Safe to call as part of
    keyframe snapshot passes (state is saved/restored by the caller) and
    for per-frame updates in animation-driven flows.

    Args:
        scene: AnimaGeoScene instance (read-only access to ``geo``/``style``).
        cfg: optional override for ``overlay.label_placement`` config dict.
            When ``None``, read from ``scene.style.rendering``.
        canonicalize: when ``True``, rewrite every non-angle placement to use
            ``label_anchor='MC'`` with an equivalent offset (bbox-corner
            displacement baked into the offset). This removes discrete anchor
            jumps when interpolating layouts between keyframes. Off by
            default so existing snapshot tests remain byte-for-byte stable.

    Returns:
        ``dict[name, LabelPlacement]`` — placements by element name. Angles
        are always ``kind='dynamic_angle'`` regardless of ``canonicalize``
        (they use MC anchor natively).
    """
    if cfg is None:
        cfg = scene.style.rendering.get('label_placement', {})
    ptUnit = scene.style.export['ptUnit']
    ptUnit_ggb = scene.style.export.get('ptUnit_ggb', ptUnit)
    font_size = scene.style.font_size

    distance = cfg.get('distance_px', DEFAULT_CONFIG['distance_px']) / ptUnit
    padding = cfg.get('padding_px', DEFAULT_CONFIG['padding_px']) / ptUnit
    # Backward-compatible gap resolution: legacy ``angle_gap_px`` is the
    # fallback for both split keys. New configs can set either gap
    # independently without touching the other.
    legacy_gap_px = cfg.get('angle_gap_px', DEFAULT_CONFIG['angle_gap_px'])
    gap_arc_px = cfg.get('angle_gap_arc_px') or legacy_gap_px
    gap_sides_px = cfg.get('angle_gap_sides_px') or legacy_gap_px
    weights = (
        cfg.get('w_anchor', DEFAULT_CONFIG['w_anchor']),
        cfg.get('w_label', DEFAULT_CONFIG['w_label']),
        cfg.get('w_geom', DEFAULT_CONFIG['w_geom']),
    )

    labels = _collect_labels(
        scene, font_size,
        gap_arc_px=gap_arc_px, gap_sides_px=gap_sides_px,
    )
    if not labels:
        return {}

    ang_rshift_px = getattr(scene.style, 'ang_rshift', 0.0)

    segments, circles, arc_pts = _collect_obstacles(scene)

    # Preferred direction per label (away from local geometry density).
    # Skip labels with fixed center (angle bisectors — already positioned).
    obstacle_cloud = _all_obstacle_points(segments, arc_pts, density=10)
    for lbl in labels:
        if lbl.fixed_center is None:
            lbl.preferred_dir = _compute_preferred_dir(lbl.anchor, obstacle_cloud)

    result = _solve_greedy(
        labels, segments, circles, arc_pts, distance, padding, weights, ptUnit,
    )

    from .geo import lib_elements as geo

    labels_by_name = {lbl.name: lbl for lbl in labels}
    placements: dict = {}

    for name, center, dir_idx in result:
        elem = scene.geo.element(name)
        if elem is None:
            continue
        lbl = labels_by_name[name]
        anchor_pt = _get_anchor(elem)
        offset_scene = center - anchor_pt

        is_angle = isinstance(elem.data, geo.Angle)
        if is_angle:
            label_anchor = lbl.fixed_anchor or 'MC'
            kind = 'dynamic_angle'
            base_arc = compute_effective_arc_size_px(elem, elem.data, scene.style)
            lines = int(elem.style.get('tick_count', 1) or 1)
            angle_range = elem.style.get('angle_range', 'minor') or 'minor'
            angle_params = AngleParams(
                arc_r_px=_angle_effective_arc_r_px(base_arc, lines, ang_rshift_px),
                half_w=lbl.half_w,
                half_h=lbl.half_h,
                gap_arc_px=gap_arc_px,
                gap_sides_px=gap_sides_px,
                angle_range=angle_range,
            )
            offset_ggb = (
                offset_scene[0] * ptUnit_ggb,
                offset_scene[1] * ptUnit_ggb,
            )
        else:
            label_anchor = _DIR_TO_ANCHOR[dir_idx]
            kind = 'static'
            angle_params = None
            offset_ggb = (
                offset_scene[0] * ptUnit_ggb,
                offset_scene[1] * ptUnit_ggb,
            )
            if canonicalize and label_anchor != 'MC':
                # MC canonicalization: rewrite (anchor=A, offset=O_A) to
                # (anchor=MC, offset=O_mc) producing the same visual center.
                # See ui.create_label: visual_center = pos - edge_A * halfExtent
                # + O_A / ptUnit_ggb. Setting anchor=MC gives visual_center =
                # pos + O_mc / ptUnit_ggb, so O_mc = O_A - edge_A * halfExtent
                # * ptUnit_ggb (all per-axis).
                from .ui import LABEL_ANCHORS
                edge = LABEL_ANCHORS[label_anchor]  # 3D manim vector
                offset_ggb = (
                    offset_ggb[0] - float(edge[0]) * lbl.half_w * ptUnit_ggb,
                    offset_ggb[1] - float(edge[1]) * lbl.half_h * ptUnit_ggb,
                )
                label_anchor = 'MC'

        placements[name] = LabelPlacement(
            name=name,
            offset_ggb=offset_ggb,
            label_anchor=label_anchor,
            kind=kind,
            angle_params=angle_params,
        )

    logger.debug("Computed layout for %d labels (canonicalize=%s)",
                 len(placements), canonicalize)
    return placements


def apply_label_layout(scene, layout: dict, *, rerender: bool = True) -> None:
    """Write a layout into ``elem.style`` and optionally rerender geometry.

    Args:
        scene: AnimaGeoScene instance.
        layout: dict returned by ``compute_label_layout``.
        rerender: when ``True`` (default), remove all mobjects and call
            ``scene.addAllGeometry(show=True)`` so labels pick up the new
            offsets. Callers that plan to rerender themselves later (e.g.
            keyframe snapshot pass) can pass ``False`` to skip the churn.
    """
    for name, pl in layout.items():
        elem = scene.geo.element(name)
        if elem is None:
            continue
        elem.style['label_offset_px'] = [pl.offset_ggb[0], pl.offset_ggb[1]]
        elem.style['label_anchor'] = pl.label_anchor
        elem.style['_auto_placed'] = True

    if rerender:
        for mobj in list(scene.mobjects):
            scene.remove(mobj)
        scene.addAllGeometry(show=True)


def apply_ema_step(prev_offset, target_offset, alpha: float) -> np.ndarray:
    """Exponential moving average step toward a target offset vector.

    Used by the dynamic LabelTracker to smooth per-frame solver output so
    small solver-score oscillations don't translate into visible jitter.
    ``alpha`` is the weight of the fresh target; smaller → smoother but
    slower convergence.
    """
    prev = np.asarray(prev_offset, dtype=float)
    target = np.asarray(target_offset, dtype=float)
    return (1.0 - alpha) * prev + alpha * target


def anchor_hysteresis_step(current_anchor: str, proposed_anchor: str,
                           counter: int, flip_frames: int):
    """Schmitt-trigger for discrete label-anchor flips.

    Returns ``(new_anchor, new_counter)``. The anchor switches only after
    ``flip_frames`` consecutive frames of the solver proposing a different
    anchor. Resets the counter whenever the proposal matches the current
    anchor or whenever a switch is committed.
    """
    if proposed_anchor == current_anchor:
        return current_anchor, 0
    counter = counter + 1
    if counter >= flip_frames:
        return proposed_anchor, 0
    return current_anchor, counter


def auto_place_labels(scene):
    """Automatically place all labels to minimize overlaps.

    Reads configuration from ``scene.style.rendering['label_placement']``.
    Writes computed offsets back to each element's ``style['offset']``
    and refreshes the scene geometry.

    Thin wrapper around ``compute_label_layout`` + ``apply_label_layout``.
    MC canonicalization is controlled by ``canonicalize_anchor`` in the
    config (default ``False`` — preserves byte-for-byte legacy behavior).
    """
    cfg = scene.style.rendering.get('label_placement', {})
    canonicalize = bool(cfg.get('canonicalize_anchor', False))
    layout = compute_label_layout(scene, cfg=cfg, canonicalize=canonicalize)
    if not layout:
        return
    apply_label_layout(scene, layout, rerender=True)
