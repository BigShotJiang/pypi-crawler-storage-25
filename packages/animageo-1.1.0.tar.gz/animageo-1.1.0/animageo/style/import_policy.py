"""ImportPolicy — configurable GGB → elem.style resolution.

An ImportPolicy decides, per property, how to derive the final rendered
style from a GeoGebra element's raw attributes. Each field can be:

- **None** — defer to the base mode (faithful → GGB, style_only → defaults).
- **scalar / bool / list / dict / tuple** — literal override.
- **Callable(raw, defaults, elem)** — user-supplied function.
- **str** — passed through `dsl.parse_directive` (``const:``, ``scale:``,
  ``quantize:``, ``remap:``, or a sentinel like ``match_element`` / ``auto``).

Resolution order, from lowest to highest precedence:
  1. ``base`` starting state (faithful or style_only).
  2. ``per_type`` sub-policy, if a policy exists for ``elem.ggb_raw['elem_type']``.
  3. Top-level field resolvers (``point_size``, ``line_width``, …).
  4. ``per_name`` direct dict overrides — a final word on a specific element.
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any, Callable, Dict, Optional

from ._legacy_adapter import legacy_resolve
from .dsl import parse_directive


# Mapping: policy field → (ggb_raw key, elem.style key).
# The ggb_raw key feeds callables; the elem.style key is where the resolved
# value lands. Field and elem.style names match one-to-one in the new schema.
_FIELD_MAP: Dict[str, tuple] = {
    'size_px':          ('point_size',      'size_px'),
    'stroke_width_px':  ('line_thickness',  'stroke_width_px'),
    'arc_size_px':      ('arc_size',        'arc_size_px'),
    'label_offset_px':  ('label_offset_px', 'label_offset_px'),
    'label_color':      ('obj_color',       'label_color'),
    'label_visible':    ('show_label',      'label_visible'),
    'font_size':        (None,              'font_size'),     # sourced from view, not ggb_raw
    'font_size_px':     (None,              'font_size_px'),  # pixel-invariant (preferred)
    'stroke':           ('obj_color',       'stroke'),
    'fill':             ('obj_color',       'fill'),
    'fill_opacity':     ('obj_color',       'fill_opacity'),
    'point_shape':      ('point_style',     'point_shape'),   # int→string mapping in enums
    'stroke_opacity':   (None,              'stroke_opacity'),
    'stroke_dash_ratio':(None,              'stroke_dash_ratio'),
    'stroke_linecap':   (None,              'stroke_linecap'),
}


@dataclass
class ImportPolicy:
    base: str = 'faithful'  # 'faithful' | 'style_only'

    size_px:         Any = None
    stroke_width_px: Any = None
    arc_size_px:     Any = None
    label_offset_px: Any = None
    label_color:     Any = None
    label_visible:   Any = None
    font_size:       Any = None
    stroke:          Any = None
    fill:            Any = None
    fill_opacity:    Any = None

    font_size_px:    Any = None
    point_shape:     Any = None
    stroke_opacity:  Any = None
    stroke_dash_ratio: Any = None
    stroke_linecap:  Any = None

    per_type: Dict[str, 'ImportPolicy'] = field(default_factory=dict)
    per_name: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def __post_init__(self):
        # Parse DSL strings eagerly so fields store resolved values (scalars
        # or callables) regardless of whether the policy came from Python or
        # JSON. Bare strings (hex colors, sentinels) pass through unchanged.
        for f in fields(self):
            if f.name in ('base', 'per_type', 'per_name'):
                continue
            setattr(self, f.name, parse_directive(getattr(self, f.name)))

    # ── Factories ─────────────────────────────────────────────────────

    @classmethod
    def faithful(cls) -> 'ImportPolicy':
        """All GGB values preserved via legacy_resolve (backward-compat default)."""
        return cls(base='faithful')

    @classmethod
    def style_only(cls) -> 'ImportPolicy':
        """Ignore GGB sizes/colors; caller supplies ``defaults`` in resolve()."""
        return cls(base='style_only')

    @classmethod
    def from_dict(cls, d: dict) -> 'ImportPolicy':
        """Build an ImportPolicy from a JSON-style dict.

        Keys matching dataclass fields are parsed through :func:`parse_directive`.
        ``per_type`` values are recursively parsed as sub-policies.
        ``per_name`` values are passed through as-is (direct style overrides).
        """
        policy_fields = {f.name for f in fields(cls)}
        kwargs: Dict[str, Any] = {}

        for key, value in d.items():
            if key == 'preset':
                # "preset": "faithful"|"style_only"|"custom" — translate to base
                if value in ('faithful', 'style_only'):
                    kwargs['base'] = value
                continue
            if key == 'base':
                kwargs['base'] = value
                continue
            if key == 'per_type':
                kwargs['per_type'] = {
                    t: cls.from_dict(sub) for t, sub in (value or {}).items()
                }
                continue
            if key == 'per_name':
                kwargs['per_name'] = dict(value or {})
                continue
            if key in policy_fields:
                kwargs[key] = parse_directive(value)
            # Unknown keys are silently ignored — tolerant loading.

        return cls(**kwargs)

    # ── Resolution ────────────────────────────────────────────────────

    def resolve(
        self,
        elem,
        defaults: Optional[dict] = None,
        ptUnit: float = 1.0,
    ) -> dict:
        """Compute the final elem.style dict for a single geometry element.

        The output is a fresh dict; the caller decides how to merge it into
        ``elem.style``.
        """
        defaults = defaults or {}

        # 1. Base starting state.
        if self.base == 'style_only':
            style = dict(defaults)
        else:
            style = legacy_resolve(getattr(elem, 'ggb_raw', {}) or {})

        # 2. Merge per_type sub-policy fields over top-level fields.
        effective = self._effective_for(elem)

        # 3. Field-by-field overrides.
        for field_name, (raw_key, style_key) in _FIELD_MAP.items():
            policy_value = getattr(effective, field_name)
            if policy_value is None:
                continue
            raw_value = None
            if raw_key is not None:
                raw_value = (elem.ggb_raw or {}).get(raw_key)
            resolved = _apply_resolver(policy_value, raw_value, defaults, elem)
            if resolved is _DROP:
                style.pop(style_key, None)
            else:
                style[style_key] = resolved

        # 4. Per-name direct overrides (final word).
        name = getattr(elem, 'name', None)
        if name and name in self.per_name:
            style.update(self.per_name[name])

        return style

    def resolve_overrides_only(
        self,
        elem,
        defaults: Optional[dict] = None,
        ptUnit: float = 1.0,
    ) -> dict:
        """Return only the style keys this policy actively overrides.

        Use when the caller already has a baseline ``elem.style`` (e.g. from
        the existing applyStyle pipeline) and wants to layer policy-driven
        overrides on top without destroying non-policy fields.
        """
        defaults = defaults or {}
        overrides: Dict[str, Any] = {}

        effective = self._effective_for(elem)
        for field_name, (raw_key, style_key) in _FIELD_MAP.items():
            policy_value = getattr(effective, field_name)
            if policy_value is None:
                continue
            raw_value = None
            if raw_key is not None:
                raw_value = (getattr(elem, 'ggb_raw', {}) or {}).get(raw_key)
            resolved = _apply_resolver(policy_value, raw_value, defaults, elem)
            if resolved is _DROP:
                continue
            overrides[style_key] = resolved

        name = getattr(elem, 'name', None)
        if name and name in self.per_name:
            overrides.update(self.per_name[name])

        return overrides

    # ── Internals ─────────────────────────────────────────────────────

    def _effective_for(self, elem) -> 'ImportPolicy':
        """Overlay per_type sub-policy onto this one for a specific element."""
        if not self.per_type:
            return self
        etype = (getattr(elem, 'ggb_raw', {}) or {}).get('elem_type')
        sub = self.per_type.get(etype)
        if sub is None:
            return self
        merged_kwargs: Dict[str, Any] = {'base': sub.base or self.base}
        for f in fields(ImportPolicy):
            if f.name in ('base', 'per_type', 'per_name'):
                continue
            sub_val = getattr(sub, f.name)
            top_val = getattr(self, f.name)
            # per_type value wins if not None; else fall back to top level.
            merged_kwargs[f.name] = sub_val if sub_val is not None else top_val
        merged_kwargs['per_type'] = {}
        merged_kwargs['per_name'] = dict(self.per_name)
        return ImportPolicy(**merged_kwargs)


# Sentinel for "remove this style key" — reserved for future callers that
# want to drop e.g. label_visible rather than set it to False.
_DROP = object()


def _apply_resolver(policy_value, raw_value, defaults, elem):
    """Coerce a policy field value into a resolved style value."""
    if callable(policy_value):
        return policy_value(raw_value, defaults, elem)
    if isinstance(policy_value, str):
        # Strings may still be literal pass-throughs (e.g. "#000000").
        # from_dict already called parse_directive, so bare strings here
        # are just values; return unchanged.
        return policy_value
    return policy_value
