"""StyleConfig — unified style configuration with three independent layers.

Three layers of per-element styling, each with a single responsibility:

1. **defaults** (``DefaultsProfile``) — per-type baseline values in pixels.
   Never writes to ``elem.style``. Consulted by the resolver when neither
   an explicit user write nor an overlay override is present.

2. **overlay** (``StyleOverlay``) — post-import stylization layer.
   Contains ``per_type``, ``per_name`` overrides plus automation flags
   (``angle_radius``, ``label_placement``). Applies uniformly to GGB-imported
   and DSL-built elements via direct assignment at ``addAllGeometry`` time;
   overlay values win over GGB parser and ImportPolicy (both run earlier).

3. **ggb** (``GGBImportPolicy``, pluggable) — GGB-only raw→style transforms.
   Used by the parser pipeline to convert ``elem.ggb_raw`` values into
   ``elem.style`` entries. Has no effect on DSL-built scenes.

Plus scene-level context:

- ``presets`` — semantic constants (colours, sizes, widths, structured tokens).
- ``rendering`` — low-level renderer flags (``line_cap``, ``right_angle_joint``…).

Loading merges a package-shipped ``builtin.json`` as the baseline with the
optional user JSON file on top — see :meth:`StyleConfig.load`.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional


__all__ = [
    'DefaultsProfile',
    'StyleOverlay',
    'StyleConfig',
    'deep_merge',
    'BUILTIN_STYLE_PATH',
]


BUILTIN_STYLE_PATH: Path = Path(__file__).parent / 'builtin.json'


# ── Helpers ──────────────────────────────────────────────────────────────

def deep_merge(base: dict, overlay: dict) -> dict:
    """Recursively merge ``overlay`` into a copy of ``base``.

    Dict values are merged key-by-key (recursively). Any other value type
    in ``overlay`` (scalar, list, None) replaces the corresponding value in
    ``base``. Lists are NOT concatenated — arrays are replacement values.

    Both inputs are treated as read-only; a fresh dict tree is returned.
    """
    result = _deep_copy_dict(base)
    for key, value in overlay.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, dict)
        ):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = _deep_copy_value(value)
    return result


def _deep_copy_dict(d: dict) -> dict:
    return {k: _deep_copy_value(v) for k, v in d.items()}


def _deep_copy_value(v):
    if isinstance(v, dict):
        return _deep_copy_dict(v)
    if isinstance(v, list):
        return [_deep_copy_value(x) for x in v]
    return v


# ── Sub-configs ──────────────────────────────────────────────────────────

@dataclass
class DefaultsProfile:
    """Per-element-type default style values in pixel units.

    Accessed via :meth:`get` by the resolver. Never mutated by consumers
    during a scene's lifetime; instances are logically immutable after
    :meth:`StyleConfig.load` returns.
    """
    by_type: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def get(self, type_name: str, key: str, fallback: Any = None) -> Any:
        return self.by_type.get(type_name, {}).get(key, fallback)

    def for_type(self, type_name: str) -> Dict[str, Any]:
        """Return the full dict of defaults for a type (empty if unknown)."""
        return self.by_type.get(type_name, {})


@dataclass
class StyleOverlay:
    """Post-import stylization layer — works for GGB and DSL equally.

    Attributes:
        per_type: ``{type_name: {style_key: value}}`` — override all elements
            of a type.
        per_name: ``{elem_name: {style_key: value}}`` — override a single
            named element (higher priority than ``per_type``).
        angle_radius: auto-scaling config for angle arc radii.
        label_placement: auto-placement config.
    """
    per_type: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    per_name: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    angle_radius: Dict[str, Any] = field(default_factory=dict)
    label_placement: Dict[str, Any] = field(default_factory=dict)

    def apply(self, scene) -> None:
        """Apply per_type / per_name overrides to scene elements.

        Works for both GGB-imported and DSL-built elements — distinguishes
        them only by ``type(elem.data)``. Overlay writes via direct
        assignment, so it wins over GGB parser values and ImportPolicy
        (both of which run before ``addAllGeometry``). Post-setup writes
        to ``elem.style`` (after ``addAllGeometry``) still win over overlay.

        This is a transitional API. In the final architecture the resolver
        consults the overlay lazily at render time and this mutation step
        goes away.
        """
        try:
            from ..geo import construction as _geo  # local to avoid cycles
            Var = _geo.Var
        except ImportError:
            Var = None

        for elem in getattr(scene.geo, 'elements', ()):
            if Var is not None and isinstance(elem, Var):
                continue
            if not getattr(elem, 'visible', True) and not hasattr(elem, 'data'):
                continue
            if not hasattr(elem, 'style') or not hasattr(elem, 'data'):
                continue
            etype = type(elem.data).__name__.lower()
            # Apply per_type FIRST, then per_name on top — last write wins,
            # so per_name beats per_type. Both layers use direct assignment,
            # giving overlay the final stylistic authority over GGB and
            # ImportPolicy.
            for key, value in self.per_type.get(etype, {}).items():
                elem.style[key] = value
            name = getattr(elem, 'name', None)
            if name and name in self.per_name:
                for key, value in self.per_name[name].items():
                    elem.style[key] = value


# ── Top-level config ─────────────────────────────────────────────────────

@dataclass
class StyleConfig:
    """Top-level style configuration loaded from JSON.

    Use :meth:`load` to construct an instance — it always merges the
    package ``builtin.json`` underneath any user-supplied JSON.

    Never construct directly unless you know that every downstream reader
    can tolerate empty ``defaults`` / ``presets`` / ``rendering``.
    """
    presets: Dict[str, Any] = field(default_factory=dict)
    rendering: Dict[str, Any] = field(default_factory=dict)
    defaults: DefaultsProfile = field(default_factory=DefaultsProfile)
    overlay: StyleOverlay = field(default_factory=StyleOverlay)
    ggb: Any = None  # Optional[GGBImportPolicy], populated in Phase 5.

    # Raw source dict kept for debugging / introspection; callers should
    # not depend on it for correctness.
    source: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def load(cls, user_path: Optional[str] = None) -> 'StyleConfig':
        """Load builtin defaults; if ``user_path`` is given, deep-merge on top.

        The returned config is the single source of truth for the new
        resolver path.
        """
        builtin = _read_json(BUILTIN_STYLE_PATH)
        if user_path is None:
            merged = builtin
        else:
            user = _read_json(user_path)
            merged = deep_merge(builtin, user)
        return cls.from_dict(merged)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'StyleConfig':
        presets = _deep_copy_dict(d.get('presets', {})) if isinstance(d.get('presets'), dict) else {}
        rendering = cls._resolve_refs_static(dict(d.get('rendering', {})), presets)

        defaults_raw = _expand_includes_in_type_map(d.get('defaults', {}), presets)
        defaults = DefaultsProfile(
            by_type=cls._resolve_refs_static(_coerce_type_map(defaults_raw), presets)
        )

        overlay_raw = d.get('overlay', {}) or {}
        overlay = StyleOverlay(
            per_type=cls._resolve_refs_static(
                _coerce_type_map(_expand_includes_in_type_map(overlay_raw.get('per_type', {}), presets)),
                presets,
            ),
            per_name=cls._resolve_refs_static(
                _coerce_type_map(_expand_includes_in_type_map(overlay_raw.get('per_name', {}), presets)),
                presets,
            ),
            angle_radius=cls._resolve_refs_static(dict(overlay_raw.get('angle_radius', {})), presets),
            label_placement=cls._resolve_refs_static(dict(overlay_raw.get('label_placement', {})), presets),
        )

        return cls(
            presets=presets,
            rendering=rendering,
            defaults=defaults,
            overlay=overlay,
            ggb=None,
            source=d,
        )

    def resolve_ref(self, value: Any) -> Any:
        """Resolve style-token references.

        References use ``"presets.<group>.<name>"``.
        """
        return self._resolve_refs_static(value, self.presets)

    @staticmethod
    def _resolve_refs_static(value: Any, presets: Dict[str, Any]) -> Any:
        return _resolve_refs(value, presets)


# ── Internals ────────────────────────────────────────────────────────────

def _read_json(path) -> Dict[str, Any]:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def _coerce_type_map(raw: Any) -> Dict[str, Dict[str, Any]]:
    """Normalise ``{type: {key: val}}`` dict, dropping non-dict entries.

    Defensive: tolerates ``None`` top-level and non-dict leaves (ignores
    them with no warning; schema validation is a separate concern).
    """
    if not isinstance(raw, dict):
        return {}
    out: Dict[str, Dict[str, Any]] = {}
    for type_name, entries in raw.items():
        if isinstance(entries, dict):
            out[str(type_name)] = dict(entries)
    return out


def _resolve_refs(value: Any, presets: Dict[str, Any], seen=None) -> Any:
    """Resolve ``presets.*`` refs recursively."""
    if seen is None:
        seen = set()

    if isinstance(value, dict):
        return {k: _resolve_refs(v, presets, seen) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_refs(v, presets, seen) for v in value]
    if not isinstance(value, str):
        return value

    if not value.startswith('presets.'):
        return value

    if value in seen:
        raise ValueError(f"Cyclic style preset reference: {value}")
    seen.add(value)
    resolved = _lookup_path({'presets': presets}, value.split('.'), fallback=value)
    if resolved is value:
        seen.remove(value)
        return value
    out = _resolve_refs(_deep_copy_value(resolved), presets, seen)
    seen.remove(value)
    return out


def _lookup_path(root: Dict[str, Any], parts: list[str], fallback: Any = None) -> Any:
    cur: Any = root
    for part in parts:
        if not isinstance(cur, dict) or part not in cur:
            return fallback
        cur = cur[part]
    return cur


def _expand_includes_in_type_map(raw: Any, presets: Dict[str, Any]) -> Dict[str, Any]:
    """Expand ``$include`` inside a ``{type: {key: value}}`` mapping."""
    if not isinstance(raw, dict):
        return {}
    return {
        str(type_name): _expand_includes(entries, presets)
        for type_name, entries in raw.items()
        if isinstance(entries, dict)
    }


def _expand_includes(entries: Dict[str, Any], presets: Dict[str, Any], seen=None) -> Dict[str, Any]:
    """Expand structural preset includes.

    ``{"$include": "presets.arrow.main", "x": 1}`` merges the referenced
    dict first, then local keys on top. Included dicts may include other
    dicts. Scalar refs are ignored here; they are handled by normal reference
    resolution later.
    """
    if seen is None:
        seen = set()

    merged: Dict[str, Any] = {}
    include = entries.get('$include')
    include_refs = include if isinstance(include, list) else ([include] if include else [])

    for ref in include_refs:
        if not isinstance(ref, str):
            continue
        if ref in seen:
            raise ValueError(f"Cyclic style preset include: {ref}")
        seen.add(ref)
        included = _lookup_path({'presets': presets}, ref.split('.'), fallback=None)
        if isinstance(included, dict):
            merged = deep_merge(merged, _expand_includes(included, presets, seen))
        seen.remove(ref)

    local = {k: v for k, v in entries.items() if k != '$include'}
    return deep_merge(merged, local)
