"""Style schema documentation and validation for AnimaGeo JSON style files.

Five top-level sections, each with a single responsibility:

- ``presets``   — semantic constants (colours, sizes, widths, structured tokens).
- ``defaults``  — per-element-type baseline, usually referencing ``presets``.
- ``rendering`` — pipeline/renderer settings (line caps, auto-radius, label placement…).
- ``import``    — how to translate GGB XML values into ``elem.style``, including
                  the embedded :class:`ImportPolicy` directive block.

JSON Style File Structure
=========================

{
    "name":    "style_name",
    "version": 0.1,

    "presets": {
        "color": {
            "main": "#hex", "bold": "#hex", "aux": "#hex",
            "background": "#hex", "strong": "#hex"
        },
        "point_size":   { "main": <float>, "bold": <float>, "aux": <float> },
        "line_width":   { "main": <float>, "bold": <float>, "aux": <float> },
        "angle_radius": { "main": <float>, "shift": <float>, "right": <float> },
        "tick": {
            "main": { "tick_length_px": <float>,
                      "tick_width_px":  <float>,
                      "tick_shift_px":  <float> }
        },
        "arrow": {
            "main": { "arrow_length_px": <float>,
                      "arrow_width_px":  <float> }
        },
        "font_size": { "main": <float>, "bold": <float>, "aux": <float> }
    },

    "defaults": {
        "point": {
            "size_px":      "presets.point_size.main",
            "fill":         "presets.color.strong",
            "font_size_px": "presets.font_size.main"
        },
        "segment": {
            "$include":        "presets.tick.main",
            "stroke_width_px": "presets.line_width.main"
        },
        "vector": {
            "$include": ["presets.tick.main", "presets.arrow.main"]
        }
    },

    "overlay": {
        "per_type": {
            "<type>": { "<key>": <value> }
        },
        "per_name": {
            "<name>": { "<key>": <value> }
        },

        "angle_radius": { "enabled":          <bool>,
                          "exp":              <float>,
                          "pivot_rad":        <float>,
                          "min_px":           <float>,
                          "max_arm_fraction": <float>,
                          "apply_to_right":   <bool> },

        "label_placement": { "enabled":           <bool>,
                             "distance_px":       <int>,
                             "padding_px":        <int>,
                             "angle_gap_px":      <int>,
                             "angle_gap_arc_px":  <int>,
                             "angle_gap_sides_px":<int>,
                             "w_anchor":          <float>,
                             "w_label":           <float>,
                             "w_geom":            <float>,
                             "dynamic_angles":       <bool>,
                             "keyframe_snapshots":   <bool>,
                             "canonicalize_anchor":  <bool>,
                             "interpolation":        "linear"|"smooth",
                             "ema_alpha":            <float>,
                             "anchor_flip_frames":   <int>,
                             "solver_every_n_frames":<int> }
    },

    "rendering": {
        "line_cap":               "butt"|"round"|"square",
        "background":             "presets.color.background",
        "right_angle_joint":      "auto"|"bevel"|"miter"|"round",
        "polygon_boundary_layer": "top"|null,
        "points_display":         "auto"|"only_labels"|"only_points",
        "label_anchor":           "TL"|"TC"|"TR"|"ML"|"MC"|"MR"|"BL"|"BC"|"BR",
        "scale_export":           <float>
    },

    "import": {
        "colors":     { "#hex [opacity]": "color_name [opacity]" },
        "point_size": { "N": "preset_name" },
        "line_width": { "N": "preset_name" },
        "policy": {
            "preset":          "faithful"|"style_only",
            "size_px":         <scalar|DSL-string>,
            "stroke_width_px": <scalar|DSL-string>,
            "arc_size_px":     <scalar|DSL-string>,
            "label_offset_px": <scalar|DSL-string>,
            "label_color":     <"#hex"|DSL-string>,
            "label_visible":   <bool|DSL-string>,
            "font_size":       <scalar|DSL-string>,
            "stroke":          <"#hex"|DSL-string>,
            "fill":            <"#hex"|DSL-string>,
            "fill_opacity":    <float|DSL-string>,
            "per_type": { "<type>": { ...sub-policy... } },
            "per_name": { "<name>": { ...elem.style overrides... } }
        }
    }
}


Units
=====
All visual ``*_px`` values in ``presets``, ``defaults``, ``overlay`` and
``elem.style`` are pixels. The renderer divides them by ``ptUnit`` at draw
time.

Per-element ``elem.style`` keys (set by parser or user code)
============================================================
See ``animageo/style/proxy.pyi`` for the canonical typed list. Summary:

Visibility / labels
- ``visible``, ``label_visible``, ``label_text``, ``label_color``,
  ``label_anchor``, ``label_placement_locked``

Stroke (SVG-compatible)
- ``stroke``, ``stroke_width_px``, ``stroke_opacity``,
  ``stroke_dash_ratio``, ``stroke_linecap``

Fill
- ``fill``, ``fill_opacity``

Points
- ``size_px`` (diameter, pixels)
- ``point_shape`` ("circle"|"square"|"triangle_up"|"triangle_down"|
                   "triangle_left"|"triangle_right"|"cross"|"plus")

Angles
- ``angle_range`` ("minor"|"reflex")
- ``arc_size_px`` (base arc radius, pixels)
- ``arc_shift_px`` (radial shift between concentric arcs)
- ``right_angle_size_px`` (right-angle marker size, pixels)
- ``right_angle_marker`` (bool)
- ``auto_radius`` (bool, opt-out from overlay.angle_radius)

Tick decorations (segments/vectors/angles)
- ``tick_count`` (int), ``tick_style`` ("line"|"wave"), ``tick_radius_px``
- ``tick_length_px``, ``tick_width_px``, ``tick_shift_px`` (pixels)

Arrow heads
- ``arrow_length_px``, ``arrow_width_px`` (pixels)

Positioning / layering
- ``label_offset_px`` ([dx, dy], GGB pixels)
- ``label_radial_offset_px`` (radial label offset for angles, pixels)
- ``font_size`` (manim font units, per-element override)
- ``font_size_px`` (pixel-invariant, preferred over ``font_size``)
- ``z_index``, ``z_index_fill`` (CircleSector)
"""

from __future__ import annotations


NEW_TOP_KEYS = frozenset({'presets', 'defaults', 'rendering', 'import', 'overlay'})
LEGACY_TOP_KEYS = frozenset({'style', 'technic', 'ggb_export'})


class LegacyStyleSchemaError(ValueError):
    """Raised when a style JSON uses the pre-refactor schema.

    Surfaces a clear migration path instead of silently loading into the
    wrong section. One-liner migration:

        python scripts/migrate_style_json.py --in-place path/to/style.json
    """


def _detect_legacy_schema(style_json: dict, file_hint: str | None = None) -> None:
    legacy = LEGACY_TOP_KEYS & style_json.keys()
    if not legacy:
        return
    where = f" in {file_hint!r}" if file_hint else ""
    keys = ', '.join(sorted(legacy))
    raise LegacyStyleSchemaError(
        f"Legacy style schema detected{where}: top-level key(s) {{{keys}}} "
        f"belong to the pre-refactor format. Migrate with:\n"
        f"    python scripts/migrate_style_json.py --in-place FILE\n"
        f"See docs/style_guide/migration.md for the full mapping."
    )


def validate_style_json(style_json: dict, file_hint: str | None = None) -> list[str]:
    """Validate a parsed style JSON dict.

    Raises :class:`LegacyStyleSchemaError` on the pre-refactor schema.
    Otherwise returns a list of non-fatal warnings (missing recommended
    sections, unknown top-level keys).
    """
    _detect_legacy_schema(style_json, file_hint)

    warnings: list[str] = []
    present = set(style_json.keys())

    unknown = present - NEW_TOP_KEYS - {'name', 'version'}
    for key in sorted(unknown):
        warnings.append(f"Unknown top-level key '{key}' — ignored")

    presets = style_json.get('presets', {})
    colors = presets.get('color', {}) if isinstance(presets, dict) else {}
    for key in ('main', 'light', 'accent', 'accent_light'):
        if not isinstance(colors, dict) or key not in colors:
            warnings.append(f"Missing 'presets.color.{key}'")

    return warnings
