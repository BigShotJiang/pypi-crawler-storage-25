"""Style resolver — single entry point for reading an element's visual properties.

The resolver walks a priority chain to answer "what is the value of style
key ``K`` for element ``E``?". The chain, from highest to lowest priority:

1. ``elem.style[K]``          — explicit user write (DSL assignment or GGB parser).
2. ``overlay.per_name[name][K]``  — point-override for a named element.
3. ``overlay.per_type[type][K]``  — all-of-type override.
4. ``defaults.by_type[type][K]``  — package / JSON per-type baseline.
5. Caller-supplied ``default``   — final fallback.

Consequence: DSL code like ``A.style.size_px = 99`` is never overridden by
``overlay.per_type.point.size_px`` in a style file, because step 1 wins.
If you want to force an overlay write to beat an explicit value, use
``GGBImportPolicy``'s ``drop:`` directive (Phase 5) to clear the key from
``elem.style`` first.

Style-token references (``"presets.color.main"``) are resolved transparently via
:meth:`StyleConfig.resolve_ref`.
"""
from __future__ import annotations

from typing import Any, Dict, Optional


__all__ = [
    'resolve',
    'resolved_style',
    'etype_of',
    'trace',
]


_SENTINEL = object()


def etype_of(elem) -> str:
    """Return the canonical element-type name used as the overlay/defaults key.

    Uses the lowercase class name of ``elem.data``. Matches how the
    parser-side ``ggb_raw['elem_type']`` values are encoded (``'point'``,
    ``'segment'``, ``'angle'``, …) for the common cases; DSL-built elements
    also land on the same names because the geometry classes follow the
    GGB naming convention (``Point``, ``Segment``, ``Angle``, …).

    Elements whose ``.data`` is missing or has no ``__class__`` fall back
    to ``'unknown'`` so callers don't have to branch on the malformed case.
    """
    data = getattr(elem, 'data', None)
    if data is None:
        return 'unknown'
    return type(data).__name__.lower()


def resolve(scene, elem, key: str, default: Any = None) -> Any:
    """Resolve a style key for an element, walking the priority chain.

    Args:
        scene: Scene or any object exposing ``style_config``. Accepts a
            bare ``StyleConfig`` too, for unit-testing the chain without a
            full scene.
        elem: Element with ``.style`` dict and (indirectly) ``.data``.
        key: Style-key name (e.g. ``'size_px'``, ``'stroke'``).
        default: Value returned when no layer has the key.

    Returns:
        The resolved value, with preset references expanded.
    """
    if key in elem.style:
        return _expand_ref(scene, elem.style[key])

    cfg = _config_of(scene)
    if cfg is None:
        return default

    name = getattr(elem, 'name', None)
    if name and name in cfg.overlay.per_name:
        if key in cfg.overlay.per_name[name]:
            return _expand_ref(cfg, cfg.overlay.per_name[name][key])

    etype = etype_of(elem)
    if etype in cfg.overlay.per_type and key in cfg.overlay.per_type[etype]:
        return _expand_ref(cfg, cfg.overlay.per_type[etype][key])

    default_val = cfg.defaults.get(etype, key, _SENTINEL)
    if default_val is not _SENTINEL:
        return _expand_ref(cfg, default_val)

    return default


def resolved_style(scene, elem) -> Dict[str, Any]:
    """Materialise the complete resolved style for an element.

    Useful for snapshot testing and debugging ("what is the renderer
    actually going to see?"). Result contains every key present in any
    layer, with preset references expanded.

    Write order (lowest to highest priority):
        defaults → per_type → per_name → elem.style

    so the final dict already reflects the :func:`resolve` priority chain.
    """
    cfg = _config_of(scene)
    merged: Dict[str, Any] = {}
    if cfg is not None:
        etype = etype_of(elem)
        merged.update(cfg.defaults.for_type(etype))
        merged.update(cfg.overlay.per_type.get(etype, {}))
        name = getattr(elem, 'name', None)
        if name:
            merged.update(cfg.overlay.per_name.get(name, {}))
    merged.update(elem.style)
    return {k: _expand_ref(cfg, v) for k, v in merged.items()}


def trace(scene, elem, key: str) -> tuple[str, Any]:
    """Return ``(source, value)`` for the key, or ``('missing', None)``.

    ``source`` is one of ``'elem.style'``, ``'overlay.per_name'``,
    ``'overlay.per_type'``, ``'defaults'``, ``'missing'``. Preset refs are
    expanded, just like :func:`resolve`.
    """
    if key in elem.style:
        return 'elem.style', _expand_ref(scene, elem.style[key])
    cfg = _config_of(scene)
    if cfg is None:
        return 'missing', None
    name = getattr(elem, 'name', None)
    if name and key in cfg.overlay.per_name.get(name, {}):
        return 'overlay.per_name', _expand_ref(cfg, cfg.overlay.per_name[name][key])
    etype = etype_of(elem)
    if key in cfg.overlay.per_type.get(etype, {}):
        return 'overlay.per_type', _expand_ref(cfg, cfg.overlay.per_type[etype][key])
    val = cfg.defaults.get(etype, key, _SENTINEL)
    if val is not _SENTINEL:
        return 'defaults', _expand_ref(cfg, val)
    return 'missing', None


# ── Internals ────────────────────────────────────────────────────────────

def _config_of(scene_or_cfg) -> Optional[Any]:
    """Return a StyleConfig from a scene, or pass through an already-bare config."""
    if scene_or_cfg is None:
        return None
    cfg = getattr(scene_or_cfg, 'style_config', None)
    if cfg is not None:
        return cfg
    # Allow passing a bare StyleConfig directly (useful for unit tests).
    if hasattr(scene_or_cfg, 'defaults') and hasattr(scene_or_cfg, 'overlay'):
        return scene_or_cfg
    return None


def _expand_ref(scene_or_cfg, value):
    """Expand style-token references via StyleConfig.resolve_ref."""
    if not isinstance(value, str) or not value.startswith('presets.'):
        return value
    cfg = _config_of(scene_or_cfg)
    if cfg is None:
        return value
    if hasattr(cfg, 'resolve_ref'):
        return cfg.resolve_ref(value)
    return value
