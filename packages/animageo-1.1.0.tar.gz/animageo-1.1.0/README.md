# AnimaGeo

## Installation

```bash
pip install --upgrade animageo
```

## Using in terminal

```bash
animageo test.ggb -s default.json -px 240 auto
```

*Description:*

```
usage: animageo [-h] [-o OUTPUT] [-px PX PX] [-s STYLE] [-d] ggbfile

Converting GeoGebra construction file into SVG image.

positional arguments:
  ggbfile              GeoGebra file to convert

options:
  -h, --help           show this help message and exit
  -o, --output OUTPUT  SVG file to export into
  -px PX PX            image width and height in px (values: num or auto)
  -s, --style STYLE    JSON file with style definitions
  -d, --debug          print options
```

## Using in code

1. Prepare code `scene.py`:

```python
from animageo import *

class TestScene(AnimaGeoScene):
    def construct(self):
        # ............................................................
        # Load geometric construction directly from GeoGebra-file     
        self.loadGGB('scene.ggb', style_file = 'default.json', px_size = [400, 'auto'])
        
        # ............................................................
        # Load your own simplified python-style Code-file for manipulations with geometric construction
        # - add new vars and elements
        # - change previous definitions
        self.loadCode('scene_code.py')

        # ............................................................
        # Stylize elements using their names from GeoGebra-file or from your Code-file
        # - use any predefined attributes from style_file or from Manim
        self.element('a').style['stroke'] = self.style.col 
        self.element('A_1').style['fill'] = self.style.col_accent

        # ............................................................
        # Export current scene to image with px_size width/height
        self.exportSVG('scene.svg')

        # ............................................................
        # Do whatever you do with Manim, but also specific things:

        # - add special ValueTracker and link it to Var in geometric construction
        x = self.addVar('x', 5)

        # - use predefined methods to Show, Hide and Update geometric elements without animation
        self.HideAll()
        self.Show(['A', 'B'])

        # - use predefined methods to Show, Hide and Update geometric elements with animation
        self.playShow(['a'])
        self.element('b').style['stroke_opacity'] = 0.5
        self.playUpdate(['b'])

        # - use tracker values for animation
        self.addUpdater(x)
        self.play(x.animate.set_value(10))
        self.clearUpdater(x)

        # - you may also want to change geometric elements as Manim objects (but without affecting geometric construction)
        a = self.mobject('a')
        b = self.mobject('b')
        self.play(VGroup(a, b).animate.arrange(buff=1).shift(DOWN))
        self.play(FadeOut(a, b))        
```

and code `scene_code.py`:

```python
from animageo.dsl import *   # IDE-only; dropped by DSL transform at runtime

A = Point(x, 0)
B = Intersect(b, c)
a = Segment(A, B)
```

2. Run compilation:

```bash
manim 'scene.py' TestScene
```


## Style definitions in JSON

JSON-стиль делится на пять верхнеуровневых секций:

- **`presets`** — semantic constants: цвета, размеры, толщины и структуры;
- **`defaults`** — per-type baseline, обычно ссылками на `presets`;
- **`overlay`** — post-import стилизация и автоматика;
- **`rendering`** — настройки рендера и пайплайна;
- **`import`** — правила импорта GGB-значений + встроенная `ImportPolicy`.

Полный пример:

```json
{
    "name": "default",
    "version": 0.1,

    "presets": {
        "color": {
            "main": "#2581b5",
            "bold": "#000000",
            "aux": "#808080",
            "accent": "#ef60ab",
            "background": "#ffffff",
            "strong": "#000000"
        },
        "point_size":  { "main": 7, "bold": 9,   "aux": 5 },
        "line_width":  { "main": 2, "bold": 2.5, "aux": 1.5 },
        "angle_radius": { "main": 20, "shift": 3, "right": 14 },
        "tick":  { "main": { "tick_width_px": 1, "tick_length_px": 12, "tick_shift_px": 4 } },
        "arrow": { "main": { "arrow_width_px": 7.5, "arrow_length_px": 10.5 } },
        "font_size": { "main": 17 }
    },

    "defaults": {
        "point": {
            "size_px": "presets.point_size.main",
            "fill": "presets.color.strong"
        },
        "segment": {
            "$include": "presets.tick.main",
            "stroke_width_px": "presets.line_width.main"
        },
        "vector": {
            "$include": ["presets.tick.main", "presets.arrow.main"]
        },
        "angle": {
            "arc_size_px": "presets.angle_radius.main",
            "arc_shift_px": "presets.angle_radius.shift",
            "stroke_width_px": "presets.line_width.aux"
        }
    },

    "rendering": {
        "background":             "presets.color.background",
        "line_cap":               "round",
        "right_angle_joint":      "miter",
        "polygon_boundary_layer": "top",
        "points_display":         "only_labels",
        "scale_export":           0.75
    },

    "import": {
        "colors": {
            "#1565c0":     "main",
            "#1565c0 0.1": "main 0",
            "#d32f2f":     "accent",
            "#d32f2f 0.1": "accent_light 1",
            "#616161":     "aux",
            "#000000 0.6": "main",
            "#000000 0.1": "light 1",
            "#1565c0 0":   "white 1",
            "#d32f2f 0":   "white 1"
        },
        "point_size": { "5": "main" },
        "line_width": { "5": "main", "3": "aux" }
    }
}
```

### `rendering` — настройки рендера

| Ключ | Значения | Эффект |
|---|---|---|
| `background` | hex или `presets.color.*` | фон canvas / camera background |
| `line_cap` | `"butt"` \| `"round"` \| `"square"` | окончания линий |
| `right_angle_joint` | `"auto"` \| `"bevel"` \| `"miter"` \| `"round"` | соединение сторон прямого угла |
| `polygon_boundary_layer` | `"top"` \| `null` | `"top"` — контур полигона поверх заливки (z-index=10). Касается сегментов-сторон, создаваемых автоматически GeoGebra |
| `points_display` | `"auto"` \| `"only_labels"` \| `"only_points"` | скрыть точки / надписи глобально |
| `label_anchor` | одна из 9 позиций (`"TL"`…`"BR"`, `"MC"` и т. д.) | default-якорь подписей |
| `scale_export` | число | множитель px_size и общего масштаба экспорта |
| `angle_radius` | объект | опциональное авто-скалирование радиуса дуги по мере угла |
| `label_placement` | объект | параметры автораскладки подписей |

### `import` — правила импорта из GeoGebra

| Ключ | Тип | Назначение |
|---|---|---|
| `colors` | dict `"#hex [opacity]" → "color_name [opacity]"` | ремап цветов из GGB на `presets.color` |
| `point_size` | dict `"N" → "preset_name"` | маппинг GGB-размера точек на пресет из `presets.point_size` |
| `line_width` | dict `"N" → "preset_name"` | маппинг GGB-толщины линий на пресет из `presets.line_width` |
| `policy` | объект `ImportPolicy` | гибкие правила конверсии (scalar/DSL/callable), `per_type`/`per_name`. См. `docs/import_policies.md` |

### Миграция со старой схемы

Если у вас стили в старом формате (`style.dot.*`, `technic`, `ggb_export` на верхнем уровне), прогоните скрипт:

```bash
python scripts/migrate_style_json.py --in-place path/to/style.json
```

Полная таблица «было → стало» — в `docs/style_guide/migration.md`. Полный справочник всех имён через 5 слоёв (GGB / animageo / JSON / manim / SVG) — в `docs/field_names.md`.
