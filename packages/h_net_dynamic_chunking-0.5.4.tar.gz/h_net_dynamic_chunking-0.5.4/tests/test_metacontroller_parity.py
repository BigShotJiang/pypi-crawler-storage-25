import torch
import pytest
from torch import allclose
from einops import rearrange

from train_metacontroller import DiscoveryModule, Metacontroller

def test_metacontroller_cache_parity():
    device = 'cpu'

    discovery_mod = DiscoveryModule(
        state_dim = 8,
        action_dim = 4,
        dim = 32,
        vq_codebook_size = 16,
        discrete_high_actions = True,
    ).to(device)

    meta = Metacontroller(
        discovery_mod = discovery_mod,
        state_dim = 8,
        action_dim = 4,
        dim = 32,
    ).to(device)

    meta.eval()
    discovery_mod.eval()

    batch = 2
    seq = 4

    states = torch.randn(batch, seq, 8, device=device)
    actions = torch.randint(0, 4, (batch, seq), device=device)

    # Run the logic from Metacontroller.forward to get the interleaved tokens
    with torch.no_grad():
        raw_target_high_actions, chunk_lens = discovery_mod(states, actions, extract_high_level_actions = True)

        flat_target_high_actions = rearrange(raw_target_high_actions, 'b c ... -> (b c) ...')
        flat_chunk_lens = rearrange(chunk_lens, 'b c -> (b c)')

        expanded = torch.repeat_interleave(flat_target_high_actions, flat_chunk_lens, dim = 0)
        pattern = '(b n) -> b n' if discovery_mod.discrete_high_actions else '(b n) d -> b n d'
        raw_target_high_actions = rearrange(expanded, pattern, b = batch)

        state_repr = meta.state_proj(states)
        action_tokens = meta.action_emb_proj(raw_target_high_actions)

        interleaved = torch.empty((batch, 2 * seq, meta.metacontroller.dim), device = device, dtype = states.dtype)
        interleaved[:, 0::2] = state_repr
        interleaved[:, 1::2] = action_tokens

        # PARALLEL PASS
        parallel_out = meta.metacontroller(interleaved)

        # SEQUENTIAL PASS
        sequential_out = []
        cache = None

        for step in range(2 * seq):
            token = interleaved[:, step:step+1, :]
            out, cache = meta.metacontroller(
                token,
                cache = cache,
                input_not_include_cache = True,
                return_hiddens = True
            )
            sequential_out.append(out)

        sequential_out = torch.cat(sequential_out, dim=1)

        assert allclose(parallel_out, sequential_out, atol=1e-5), "Metacontroller caching parity failed!"
