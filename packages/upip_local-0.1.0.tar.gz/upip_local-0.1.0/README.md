# upip-local

A lean, decentralized package manager for MicroPython. 

`upip` allows you to install packages from PyPI into a local directory, stripping out CPython bloat so they are ready to be flashed onto a microcontroller.

## Installation

Install locally in editable mode:
```bash
pip install -e upip
```