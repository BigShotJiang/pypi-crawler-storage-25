import shutil
import os
from pathlib import Path

def deploy_to_device(source_dir, device_path):
    """
    Moves the locally installed packages to the MicroPython device.
    Supports local mount points (like an E: drive) or specific paths.
    """
    src = Path(source_dir)
    dest = Path(device_path)

    if not src.exists():
        raise FileNotFoundError(f"Source directory {source_dir} not found. Run install first.")

    print(f"\033[32m[deploy]\033[0m Syncing to \033[92m{device_path}\033[0m...")

    try:
        # If the destination is a drive (like a Pico showing up as E:/)
        # we ensure the /lib folder exists there.
        lib_on_device = dest / "lib"
        if not lib_on_device.exists():
            lib_on_device.mkdir(parents=True)

        # Copying files
        for item in src.iterdir():
            dest_item = lib_on_device / item.name
            if item.is_dir():
                if dest_item.exists():
                    shutil.rmtree(dest_item)
                shutil.copytree(item, dest_item)
            else:
                shutil.copy2(item, dest_item)
                
        return True
    except Exception as e:
        raise RuntimeError(f"Deployment failed: {e}")

def list_local_packages(target_dir):
    """
    Scans the local lib folder to show the user what's currently 'installed'.
    """
    path = Path(target_dir)
    if not path.exists():
        return []
    
    # Filter for directories (packages) or .py files (modules)
    return [f.name for f in path.iterdir() if f.is_dir() or f.suffix == ".py"]