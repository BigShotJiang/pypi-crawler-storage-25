import argparse
import sys
from .core import install_to_local

def main():
    parser = argparse.ArgumentParser(
        prog="upip",
        description="upip: A lean, local-only pip wrapper for MicroPython"
    )

    # The package to install
    parser.add_argument(
        "package", 
        help="Name of the package to install (e.g., micropython-pico-lcd)"
    )

    # Custom target directory, defaulting to ./lib
    parser.add_argument(
        "-t", "--target", 
        default="./lib", 
        help="Target directory for local installation (default: ./lib)"
    )

    # Optional: A flag to prevent dependency resolution for even leaner installs
    parser.add_argument(
        "--no-deps", 
        action="store_true", 
        help="Install without dependencies to keep the footprint small"
    )

    args = parser.parse_args()

    # Green-accented terminal output for your Forest Dark aesthetic
    print(f"\033[32m[upip]\033[0m Preparing to install \033[92m{args.package}\033[0m...")
    
    try:
        install_to_local(args.package, args.target, args.no_deps)
        print(f"\033[32m[success]\033[0m Library ready in: {args.target}")
    except Exception as e:
        print(f"\033[31m[error]\033[0m {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()