"""
upip: A lean, local-first package manager for MicroPython.
"""

from .core import install_to_local
from .installer import deploy_to_device

__version__ = "0.1.0"
__author__ = "Your Name"

# This defines what is exported when someone does 'from upip import *'
__all__ = ["install_to_local", "deploy_to_device"]