import subprocess
import sys
import os
import shutil

def install_to_local(package, target, no_deps=False):
    """
    Core logic to fetch a package and clean it for MicroPython.
    """
    # 1. Expand the path to handle relative paths correctly
    target_path = os.path.abspath(target)
    
    # 2. Build the pip command
    # --no-compile: Prevents .pyc files (MicroPython uses its own bytecode)
    # --no-user: Avoids installing to the OS user directory
    command = [
        sys.executable, "-m", "pip", "install",
        package,
        "--target", target_path,
        "--no-compile",
        "--no-user",
        "--upgrade"
    ]
    
    if no_deps:
        command.append("--no-deps")

    try:
        # Run pip and suppress the wall of text unless there's an error
        subprocess.check_call(command, stdout=subprocess.DEVNULL)
        
        # 3. Post-install cleanup
        _cleanup_cpython_artifacts(target_path)
        
    except subprocess.CalledProcessError:
        raise RuntimeError(f"Pip failed to install {package}. Check your connection or package name.")

def _cleanup_cpython_artifacts(directory):
    """
    Removes files MicroPython doesn't need to save space.
    """
    for root, dirs, files in os.walk(directory):
        for item in dirs:
            # Remove __pycache__ and dist-info folders
            if item == "__pycache__" or item.endswith(".dist-info"):
                shutil.rmtree(os.path.join(root, item))
        
        for file in files:
            # Remove compiled C extensions MicroPython can't run
            if file.endswith((".so", ".pyd", ".pyc")):
                os.remove(os.path.join(root, file))