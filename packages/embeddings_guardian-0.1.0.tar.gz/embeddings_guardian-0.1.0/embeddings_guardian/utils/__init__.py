"""Utility modules: metrics, reporting, structured logging."""
