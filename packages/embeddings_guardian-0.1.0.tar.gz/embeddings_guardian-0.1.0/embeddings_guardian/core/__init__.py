"""Core detection engine, adapters, and scoring algorithms."""
