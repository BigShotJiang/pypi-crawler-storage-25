# Release runbook

Ten steps. Every step must complete green before the next starts. Do not skip;
do not reorder. If any step fails, stop and fix the root cause — do not force
the release through.

## 0. Prerequisites (once per machine)

- `gh` CLI authenticated as a maintainer of `dtchen07/mcp-stdio-test`.
- Git configured with a signing key; `git config commit.gpgsign true`.
- PyPI Trusted Publisher for this repo + `release.yml` workflow already
  configured. (Confirmed working if `v0.1.0-rc1` dry-run publishes cleanly
  to TestPyPI.)

## 1. Confirm `[Unreleased]` is ready

`CHANGELOG.md` must have entries under `## [Unreleased]` describing every
user-facing change since the last tag. If it is empty, stop — there is
nothing to release.

## 2. Pick the version

Follow SemVer preview rules while below `1.0.0`:
- Patch (`0.1.0 → 0.1.1`): bug fixes only.
- Minor (`0.1.x → 0.2.0`): new user-facing features; possible breakage.
- Pre-release suffix (`0.2.0rc1`): TestPyPI round-trip before prod cut.

## 3. Move `[Unreleased]` → `[X.Y.Z]`

In `CHANGELOG.md`, rename the section and add the release date in
`YYYY-MM-DD`. Update compare links at the bottom. Add an empty
`## [Unreleased]` block above it.

## 4. Bump `__version__`

Edit `src/mcp_stdio_test/__init__.py`. Bump to match `[X.Y.Z]`.

## 5. Update `CITATION.cff`

Update `version:` and `date-released:` to match.

## 6. Local green

```
pip install -e ".[test]"
pytest -q
mcp-stdio-test doctor
du -sh dist/*.whl 2>/dev/null || true
```

Tests must pass. Doctor must report PASS. Wheel must be < 1 MB.

## 7. Commit + tag

```
git add CHANGELOG.md CITATION.cff src/mcp_stdio_test/__init__.py
git commit -m "Release vX.Y.Z"
git tag -s vX.Y.Z -m "Release vX.Y.Z"
git push origin main --follow-tags
```

## 8. Watch `release.yml`

The tag push triggers the release workflow. It must:
- Build sdist + wheel on Linux.
- Attach PEP 740 provenance (`attest-build-provenance@v2`).
- Publish to PyPI via Trusted Publishing (OIDC).
- Create a GitHub Release with the `[X.Y.Z]` CHANGELOG excerpt.

If any step fails, stop. Do not attempt manual `twine upload`.

## 9. Post-publish verification

```
pip install --no-cache-dir "mcp-stdio-test==X.Y.Z"
mcp-stdio-test --version
mcp-stdio-test doctor
gh attestation verify mcp_stdio_test-X.Y.Z*.whl --owner dtchen07
```

## 10. Post-release housekeeping

- For minor releases: draft a Discord announcement in
  `Claude-Memory/Workstream-Checkpoints/` (do not post until reviewed).
- Capture a telemetry snapshot row in
  `mcp-stdio-test-telemetry-YYYY-MM-DD.md` per strategy §18.
- Close the GitHub milestone; open the next milestone.

## Hotfix path (S0/S1 bugs)

Branch from the failing tag, cherry-pick the fix, bump patch, follow steps 1-9
on that branch. Do not yank except for S0 (see strategy §17).
