# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html)
once it reaches `1.0.0`. Until then, minor version bumps may include breaking changes.

## [Unreleased]

## [0.1.0] - 2026-04-17

### Added

- `MCPClient` stdio context manager speaking JSON-RPC MCP `2024-11-05`.
- CLI `mcp-stdio-test <server>` with flags: `--list-tools`, `--call`, `--args`,
  `--expect-count`, `--expect-tool`, `--timeout`, `--pyexe`, `--json`.
- `mcp-stdio-test doctor` self-check subcommand (Python version, optional
  `mcp` SDK, bundled fixture handshake).
- Wall-clock timeout watchdog (default 30s) that terminates hung servers.
- Pre-commit hook integration via `.pre-commit-hooks.yaml`.
- PEP 740 build provenance attached to every release artifact.
- Bundled `echo_mcp.py` fixture with two tools (`add`, `echo`); reused by the
  companion `mcp-custom-template` repo.

### Compatibility

- Python 3.10, 3.11, 3.12, 3.13.
- MCP protocol revision `2024-11-05`.
- `mcp` SDK `>=1.2,<2` (test extra only; zero runtime dependencies).

### Evidence

- Build time per MCP: 90-120 min -> 50-55 min (55% reduction) across 8
  servers in the author's private MCP workspace; see the launch blog
  post evidence inventory for source rows.

[Unreleased]: https://github.com/dtchen07/mcp-stdio-test/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/dtchen07/mcp-stdio-test/releases/tag/v0.1.0
