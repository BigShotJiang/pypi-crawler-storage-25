"""Reference echo MCP fixture.

Minimal stdio MCP used by both mcp-stdio-test's test suite and the
mcp-custom-template starter. Two tools: ``add`` (int, int -> int) and
``echo`` (str -> str). Demonstrates the smallest useful tool surface.
"""
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("echo-mcp")


@mcp.tool()
def add(a: int, b: int) -> int:
    """Return the sum of two integers."""
    return a + b


@mcp.tool()
def echo(message: str) -> str:
    """Return the input message unchanged."""
    return message


if __name__ == "__main__":
    mcp.run()
