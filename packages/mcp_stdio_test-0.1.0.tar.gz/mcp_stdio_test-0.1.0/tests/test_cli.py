"""End-to-end subprocess tests for the mcp-stdio-test CLI.

Each test shells out to ``python -m mcp_stdio_test.cli`` against the bundled
echo fixture. This exercises the real wire protocol, not a mocked one.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest


FIXTURE = Path(__file__).parent / "fixtures" / "echo_mcp.py"
CLI = [sys.executable, "-m", "mcp_stdio_test.cli"]


def _run(*args: str, timeout: float = 30.0) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        CLI + list(args),
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def test_version_flag_prints_version() -> None:
    result = _run("--version")
    assert result.returncode == 0
    assert "mcp-stdio-test" in result.stdout


def test_help_flag_prints_usage() -> None:
    result = _run("--help")
    assert result.returncode == 0
    assert "CI-gate harness" in result.stdout


def test_doctor_passes_on_clean_env() -> None:
    result = _run("doctor")
    assert result.returncode == 0, result.stdout + result.stderr
    assert "PASS" in result.stdout


def test_list_tools_reports_two_tools() -> None:
    result = _run(str(FIXTURE), "--list-tools", "--json")
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["tool_count"] == 2
    assert set(payload["tools"]) == {"add", "echo"}


def test_expect_count_matches() -> None:
    result = _run(str(FIXTURE), "--list-tools", "--expect-count", "2")
    assert result.returncode == 0, result.stdout + result.stderr


def test_expect_count_mismatch_exits_4() -> None:
    result = _run(str(FIXTURE), "--list-tools", "--expect-count", "99")
    assert result.returncode == 4
    assert "ASSERT FAIL" in result.stdout


def test_expect_tool_matches() -> None:
    result = _run(str(FIXTURE), "--list-tools", "--expect-tool", "echo")
    assert result.returncode == 0


def test_expect_tool_missing_exits_4() -> None:
    result = _run(str(FIXTURE), "--list-tools", "--expect-tool", "does-not-exist")
    assert result.returncode == 4


def test_call_add_returns_sum() -> None:
    result = _run(
        str(FIXTURE), "--call", "add", "--args", '{"a": 2, "b": 3}', "--json"
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["call_result"] == 5


def test_missing_server_argument_exits_5() -> None:
    result = _run()
    assert result.returncode == 5


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
