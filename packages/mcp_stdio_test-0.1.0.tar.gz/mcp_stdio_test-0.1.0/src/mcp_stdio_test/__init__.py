"""mcp-stdio-test — a CI-gate harness for stdio MCPs.

Zero LLM, zero network, zero API keys.
"""
from mcp_stdio_test.client import MCPClient, MCPInitError, MCPToolsListError, MCPToolCallError

__version__ = "0.1.0"

__all__ = [
    "MCPClient",
    "MCPInitError",
    "MCPToolsListError",
    "MCPToolCallError",
    "__version__",
]
