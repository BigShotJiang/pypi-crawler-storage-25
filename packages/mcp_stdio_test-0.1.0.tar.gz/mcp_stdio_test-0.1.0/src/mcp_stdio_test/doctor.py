"""Self-check subcommand.

Verifies the host environment is ready to run mcp-stdio-test:
1. Python version >= 3.10.
2. The ``mcp`` SDK imports (informational; not required for runtime).
3. The bundled zero-dep doctor fixture can complete an stdio handshake.

Exit 0 on PASS, 1 on FAIL.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from mcp_stdio_test import __version__

MIN_PYTHON = (3, 10)


def _check_python() -> dict[str, Any]:
    ok = sys.version_info[:2] >= MIN_PYTHON
    return {
        "name": "python",
        "ok": ok,
        "detail": (
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        ),
        "required": f">={MIN_PYTHON[0]}.{MIN_PYTHON[1]}",
    }


def _check_mcp_sdk() -> dict[str, Any]:
    try:
        import mcp  # noqa: F401

        version = getattr(mcp, "__version__", None)
        if version:
            detail = str(version)
        else:
            try:
                from importlib.metadata import version as _pkg_version

                detail = _pkg_version("mcp")
            except Exception:
                detail = "installed"
        return {"name": "mcp_sdk", "ok": True, "detail": detail}
    except ImportError:
        return {
            "name": "mcp_sdk",
            "ok": False,
            "detail": "not installed (optional; only needed for user fixture servers)",
        }


def _check_fixture() -> dict[str, Any]:
    from mcp_stdio_test.client import MCPClient, MCPError

    fixture = Path(__file__).with_name("_doctor_fixture.py")
    if not fixture.exists():
        return {
            "name": "fixture",
            "ok": False,
            "detail": f"doctor fixture not found at {fixture}",
        }
    try:
        with MCPClient(str(fixture), timeout=15.0) as client:
            tools = client.list_tools()
        return {
            "name": "fixture",
            "ok": True,
            "detail": f"stdio handshake complete; {len(tools)} tool(s) listed",
        }
    except MCPError as exc:
        return {"name": "fixture", "ok": False, "detail": str(exc)}
    except Exception as exc:
        return {
            "name": "fixture",
            "ok": False,
            "detail": f"{type(exc).__name__}: {exc}",
        }


def run_doctor(json_mode: bool = False) -> int:
    checks = [_check_python(), _check_mcp_sdk(), _check_fixture()]
    required = {"python", "fixture"}
    passed = all(c["ok"] for c in checks if c["name"] in required)

    report = {"version": __version__, "passed": passed, "checks": checks}

    if json_mode:
        print(json.dumps(report, indent=2))
    else:
        print(f"mcp-stdio-test doctor  version {__version__}")
        for check in checks:
            mark = "PASS" if check["ok"] else "FAIL"
            print(f"  [{mark}] {check['name']}: {check['detail']}")
        print(f"Overall: {'PASS' if passed else 'FAIL'}")

    return 0 if passed else 1
