"""Minimal stdio MCP client.

Speaks JSON-RPC over subprocess stdin/stdout. No external dependencies; the
wire format is the whole contract. A watchdog timer kills the child if it
hangs past the configured timeout.
"""
from __future__ import annotations

import json
import subprocess
import sys
import threading
from typing import Any


class MCPError(RuntimeError):
    """Base class for MCP client errors."""


class MCPInitError(MCPError):
    """Raised when the initialize handshake fails."""


class MCPToolsListError(MCPError):
    """Raised when tools/list fails."""


class MCPToolCallError(MCPError):
    """Raised when tools/call fails."""


class MCPTimeoutError(MCPError):
    """Raised when the server exceeds the configured timeout."""


PROTOCOL_VERSION = "2024-11-05"


class MCPClient:
    """Context-managed stdio MCP client.

    Parameters
    ----------
    server_path : str
        Path to the MCP server script to spawn.
    pyexe : str, optional
        Python interpreter to use. Defaults to ``sys.executable``.
    timeout : float, optional
        Wall-clock deadline for the session, in seconds. Default 30.
        A watchdog thread kills the child process if exceeded.
    """

    def __init__(
        self,
        server_path: str,
        pyexe: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.server_path = server_path
        self.pyexe = pyexe or sys.executable
        self.timeout = timeout
        self.proc: subprocess.Popen[str] | None = None
        self._id = 0
        self._watchdog: threading.Timer | None = None
        self._timed_out = False

    def __enter__(self) -> "MCPClient":
        self.proc = subprocess.Popen(
            [self.pyexe, self.server_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        if self.timeout and self.timeout > 0:
            self._watchdog = threading.Timer(self.timeout, self._on_timeout)
            self._watchdog.daemon = True
            self._watchdog.start()
        self._send(
            {
                "jsonrpc": "2.0",
                "id": self._next_id(),
                "method": "initialize",
                "params": {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {},
                    "clientInfo": {"name": "mcp-stdio-test", "version": "0.1.0"},
                },
            }
        )
        init_resp = self._recv()
        if "error" in init_resp:
            raise MCPInitError(f"initialize failed: {init_resp['error']}")
        self._send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._watchdog is not None:
            self._watchdog.cancel()
        if self.proc is None:
            return
        try:
            if self.proc.stdin is not None:
                self.proc.stdin.close()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.proc.kill()

    def _on_timeout(self) -> None:
        self._timed_out = True
        if self.proc is not None:
            try:
                self.proc.kill()
            except Exception:
                pass

    def _next_id(self) -> int:
        self._id += 1
        return self._id

    def _send(self, msg: dict[str, Any]) -> None:
        assert self.proc is not None and self.proc.stdin is not None
        self.proc.stdin.write(json.dumps(msg) + "\n")
        self.proc.stdin.flush()

    def _recv(self) -> dict[str, Any]:
        assert self.proc is not None and self.proc.stdout is not None
        line = self.proc.stdout.readline()
        if not line:
            if self._timed_out:
                raise MCPTimeoutError(
                    f"server exceeded timeout of {self.timeout}s and was killed"
                )
            stderr = ""
            if self.proc.stderr is not None:
                try:
                    stderr = self.proc.stderr.read()[:500]
                except Exception:
                    pass
            raise MCPError(f"server closed unexpectedly: {stderr}")
        return json.loads(line)

    def list_tools(self) -> list[dict[str, Any]]:
        self._send(
            {"jsonrpc": "2.0", "id": self._next_id(), "method": "tools/list"}
        )
        resp = self._recv()
        if "error" in resp:
            raise MCPToolsListError(f"tools/list failed: {resp['error']}")
        return resp["result"].get("tools", [])

    def call_tool(self, name: str, args: dict[str, Any] | None = None) -> Any:
        self._send(
            {
                "jsonrpc": "2.0",
                "id": self._next_id(),
                "method": "tools/call",
                "params": {"name": name, "arguments": args or {}},
            }
        )
        resp = self._recv()
        if "error" in resp:
            raise MCPToolCallError(f"tools/call failed: {resp['error']}")
        result = resp.get("result", {})
        structured = result.get("structuredContent")
        if structured is not None:
            return structured.get("result", structured)
        content = result.get("content", [])
        if content and isinstance(content, list):
            first = content[0]
            if first.get("type") == "text":
                try:
                    return json.loads(first["text"])
                except (json.JSONDecodeError, KeyError):
                    return first.get("text")
        return result
