"""Command-line entry point for mcp-stdio-test.

Exit codes
----------
0: OK
1: initialize / handshake failed
2: tools/list failed
3: tools/call failed
4: assertion failed
5: usage error
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from mcp_stdio_test import __version__
from mcp_stdio_test.assertions import assert_tool_count, assert_tool_exists
from mcp_stdio_test.client import (
    MCPClient,
    MCPError,
    MCPInitError,
    MCPTimeoutError,
    MCPToolCallError,
    MCPToolsListError,
)
from mcp_stdio_test.doctor import run_doctor


EXIT_OK = 0
EXIT_INIT = 1
EXIT_LIST = 2
EXIT_CALL = 3
EXIT_ASSERT = 4
EXIT_USAGE = 5


def _build_main_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mcp-stdio-test",
        description=(
            "CI-gate harness for stdio MCPs. "
            "Zero LLM, zero network, zero API keys."
        ),
        epilog=(
            "Subcommands: doctor  (self-check). "
            "Run 'mcp-stdio-test doctor --help' for details."
        ),
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    parser.add_argument(
        "server", nargs="?", help="Path to MCP server.py"
    )
    parser.add_argument(
        "--pyexe",
        help="Python interpreter to spawn the server with (default: sys.executable)",
    )
    parser.add_argument(
        "--list-tools", action="store_true", help="Print tool inventory"
    )
    parser.add_argument("--call", metavar="TOOL", help="Call a tool by name")
    parser.add_argument(
        "--args",
        default="{}",
        help='JSON-encoded arguments for --call (default: {})',
    )
    parser.add_argument(
        "--expect-count",
        type=int,
        help="Assert tools/list returns exactly N tools",
    )
    parser.add_argument(
        "--expect-tool",
        action="append",
        default=[],
        metavar="NAME",
        help="Assert a tool with NAME is registered (repeatable)",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=30.0,
        help="Wall-clock deadline in seconds (default 30)",
    )
    parser.add_argument(
        "--json", action="store_true", help="Emit JSON output instead of text"
    )
    return parser


def _build_doctor_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mcp-stdio-test doctor",
        description=(
            "Self-check: Python version, optional mcp SDK, stdio handshake."
        ),
    )
    parser.add_argument(
        "--json", action="store_true", help="Emit JSON report instead of text"
    )
    return parser


def _emit(data: dict[str, Any], json_mode: bool) -> None:
    if json_mode:
        print(json.dumps(data, indent=2, default=str))
        return
    print(f"Server:     {data['server']}")
    print(f"Init:       {data.get('init', '?')}")
    if "tool_count" in data:
        tools = ", ".join(data.get("tools", []))
        print(f"Tools:      {data['tool_count']} -> {tools}")
    if "call" in data:
        print(f"Call:       {data['call']}")
        if "call_error" in data:
            print(f"Call FAIL:  {data['call_error']}")
        else:
            cr = data.get("call_result")
            preview = (
                json.dumps(cr, default=str)[:300] if cr is not None else "(empty)"
            )
            print(f"Result:     {preview}")
    if "assertion_error" in data:
        print(f"ASSERT FAIL: {data['assertion_error']}")


def _run_test(args: argparse.Namespace) -> int:
    if not args.server:
        print(
            "ERROR: server path required (or run 'mcp-stdio-test doctor' for a self-check)",
            file=sys.stderr,
        )
        return EXIT_USAGE
    if not Path(args.server).exists():
        print(f"ERROR: server not found: {args.server}", file=sys.stderr)
        return EXIT_USAGE

    try:
        call_args = json.loads(args.args)
    except json.JSONDecodeError as exc:
        print(f"ERROR: --args is not valid JSON: {exc}", file=sys.stderr)
        return EXIT_USAGE

    results: dict[str, Any] = {"server": args.server, "init": "OK"}

    try:
        with MCPClient(args.server, args.pyexe, args.timeout) as client:
            need_list = (
                args.list_tools
                or args.expect_count is not None
                or bool(args.expect_tool)
            )
            if need_list:
                tools = client.list_tools()
                names = [t["name"] for t in tools]
                results["tool_count"] = len(tools)
                results["tools"] = names
                if args.expect_count is not None:
                    err = assert_tool_count(tools, args.expect_count)
                    if err:
                        results["assertion_error"] = err
                        _emit(results, args.json)
                        return EXIT_ASSERT
                for expected in args.expect_tool:
                    err = assert_tool_exists(tools, expected)
                    if err:
                        results["assertion_error"] = err
                        _emit(results, args.json)
                        return EXIT_ASSERT

            if args.call:
                try:
                    results["call"] = args.call
                    results["call_result"] = client.call_tool(args.call, call_args)
                except MCPToolCallError as exc:
                    results["call_error"] = str(exc)
                    _emit(results, args.json)
                    return EXIT_CALL

            _emit(results, args.json)
            return EXIT_OK
    except MCPInitError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return EXIT_INIT
    except MCPToolsListError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return EXIT_LIST
    except MCPTimeoutError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return EXIT_INIT
    except MCPError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return EXIT_INIT


def main(argv: list[str] | None = None) -> int:
    raw = list(argv if argv is not None else sys.argv[1:])

    if raw and raw[0] == "doctor":
        doctor_args = _build_doctor_parser().parse_args(raw[1:])
        return run_doctor(json_mode=bool(doctor_args.json))

    args = _build_main_parser().parse_args(raw)
    return _run_test(args)


if __name__ == "__main__":
    sys.exit(main())
