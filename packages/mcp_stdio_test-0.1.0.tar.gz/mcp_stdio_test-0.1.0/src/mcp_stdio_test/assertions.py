"""Assertion helpers for tool-count and tool-name checks."""
from __future__ import annotations

from typing import Any


def assert_tool_count(tools: list[dict[str, Any]], expected: int) -> str | None:
    """Return None if ``len(tools) == expected``, else an error message."""
    if len(tools) == expected:
        return None
    return f"expected {expected} tools, got {len(tools)}"


def assert_tool_exists(tools: list[dict[str, Any]], name: str) -> str | None:
    """Return None if a tool with ``name`` is present, else an error message."""
    names = [t.get("name") for t in tools]
    if name in names:
        return None
    return f"expected tool '{name}' not found (have: {', '.join(n for n in names if n)})"
