"""Ultra-minimal MCP stdio server for the doctor self-check.

Speaks JSON-RPC directly over stdin/stdout with no external dependencies. It
ships inside the installed package so ``mcp-stdio-test doctor`` works on a
clean ``pip install`` without pulling in the MCP SDK.
"""
from __future__ import annotations

import json
import sys


def _send(obj: dict) -> None:
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


def _main() -> int:
    for line in sys.stdin:
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        method = msg.get("method")
        msg_id = msg.get("id")
        if method == "initialize":
            _send(
                {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "doctor-fixture", "version": "0"},
                    },
                }
            )
        elif method == "notifications/initialized":
            continue
        elif method == "tools/list":
            _send({"jsonrpc": "2.0", "id": msg_id, "result": {"tools": []}})
        elif method == "tools/call":
            _send(
                {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "error": {"code": -32601, "message": "doctor fixture has no tools"},
                }
            )
        else:
            _send(
                {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "error": {"code": -32601, "message": f"unhandled method: {method}"},
                }
            )
    return 0


if __name__ == "__main__":
    sys.exit(_main())
