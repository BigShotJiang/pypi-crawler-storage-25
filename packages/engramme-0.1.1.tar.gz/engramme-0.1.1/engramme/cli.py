"""Command-line interface for Engramme auth helpers."""

import argparse
import getpass
import sys

from .auth import list_profiles, login, logout, set_active_profile, whoami


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="engramme",
        description="Engramme CLI",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    login_parser = subparsers.add_parser("login", help="Save API key to config file")
    login_parser.add_argument(
        "--token",
        "-t",
        help="API key. If omitted, you will be prompted securely.",
    )
    login_parser.add_argument(
        "--profile",
        "-p",
        default="default",
        help="Profile name (default: 'default')",
    )

    logout_parser = subparsers.add_parser("logout", help="Remove API key from config")
    logout_parser.add_argument(
        "--profile",
        "-p",
        help="Profile to remove. Removes all profiles if omitted.",
    )

    subparsers.add_parser("whoami", help="Show current authentication status")
    subparsers.add_parser("profiles", help="List all configured profiles")

    use_parser = subparsers.add_parser("use", help="Switch active profile")
    use_parser.add_argument("profile", help="Profile name to activate")

    args = parser.parse_args()

    if args.command == "login":
        token = args.token or getpass.getpass("Enter your Engramme API key: ")
        if not token:
            print("Error: No token provided", file=sys.stderr)
            sys.exit(1)
        login(token=token, profile=args.profile)
    elif args.command == "logout":
        logout(profile=args.profile)
    elif args.command == "whoami":
        whoami()
    elif args.command == "profiles":
        profiles = list_profiles()
        if not profiles:
            print("No profiles configured. Run `engramme login` first.")
        else:
            for name, info in profiles.items():
                marker = " (active)" if info["active"] else ""
                print(f"  {name}{marker}")
    elif args.command == "use":
        try:
            set_active_profile(args.profile)
        except (FileNotFoundError, ValueError) as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
