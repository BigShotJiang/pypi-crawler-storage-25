"""Engramme API client."""

from pathlib import Path
from typing import Any, Dict, Optional, Union

import requests

from .auth import get_token
from .exceptions import (
    APIError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)

DEFAULT_BASE_URL = "https://memorymachines-gateway-prod-btf57kda.uc.gateway.dev"
DEFAULT_TIMEOUT_SECONDS = 30


class Engramme:
    """Python client for the Engramme memory API."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        profile: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ):
        """
        Initialize the Engramme client.

        API key resolution order:
        1. Explicit ``api_key`` parameter
        2. ``ENGRAMME_API_KEY`` environment variable
        3. ``~/.engramme/config.yaml`` active profile
        """
        if api_key is None:
            api_key = get_token(profile=profile)

        if api_key is None:
            raise AuthenticationError(
                "No API key found. Either:\n"
                "  1. Pass api_key='...' to Engramme()\n"
                "  2. Set ENGRAMME_API_KEY environment variable\n"
                "  3. Run `engramme login` or `login(token='...')`"
            )

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()

    def _headers(self) -> Dict[str, str]:
        return {"x-api-key": self.api_key}

    def _handle_response(self, response: requests.Response) -> Any:
        try:
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            response_obj = e.response
            status_code = response_obj.status_code if response_obj is not None else None
            error_msg = self._extract_error_message(response_obj)

            if status_code == 401:
                raise AuthenticationError(f"Invalid or expired API key: {error_msg}") from e
            if status_code == 403:
                raise AuthenticationError(f"Forbidden: {error_msg}") from e
            if status_code == 404:
                raise NotFoundError(f"Resource not found: {error_msg}") from e
            if status_code == 409:
                raise ValidationError(f"Conflict: {error_msg}") from e
            if status_code == 429:
                raise RateLimitError("Rate limit exceeded. Please try again later.") from e
            if status_code == 400:
                raise ValidationError(f"Invalid request: {error_msg}") from e
            if status_code == 422:
                raise ValidationError(f"Invalid request: {error_msg}") from e

            raise APIError(f"API error ({status_code}): {error_msg}") from e
        except ValueError as e:
            raise APIError("API returned a non-JSON response") from e

    def _extract_error_message(self, response: Optional[requests.Response]) -> str:
        if response is None:
            return "Unknown error"

        try:
            error_data = response.json()
        except ValueError:
            return response.text or "Unknown error"

        detail = error_data.get("detail")
        if isinstance(detail, list):
            return "; ".join(str(item.get("msg", item)) if isinstance(item, dict) else str(item) for item in detail)
        if detail:
            return str(detail)
        return str(error_data.get("message") or response.text or "Unknown error")

    def memorize(
        self,
        file: Union[str, Path, bytes],
        user_name: str,
        item_id: Optional[str] = None,
        source_type: Optional[str] = None,
        source_metadata: Optional[str] = None,
        filename: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Upload content for memory extraction and indexing."""
        if not user_name or not user_name.strip():
            raise ValidationError("user_name is required")

        file_tuple = self._prepare_file(file=file, filename=filename)
        data = {"user_name": user_name}
        if item_id:
            data["item_id"] = item_id
        if source_type:
            data["source_type"] = source_type
        if source_metadata:
            data["source_metadata"] = source_metadata

        try:
            response = self.session.post(
                f"{self.base_url}/v1/memorize",
                headers=self._headers(),
                files={"file": file_tuple},
                data=data,
                timeout=self.timeout,
            )
            return self._handle_response(response)
        finally:
            if isinstance(file, (str, Path)) and hasattr(file_tuple[1], "close"):
                file_tuple[1].close()

    def _prepare_file(self, file: Union[str, Path, bytes], filename: Optional[str]):
        if isinstance(file, bytes):
            return (filename or "upload.txt", file)

        if isinstance(file, (str, Path)):
            file_path = Path(file)
            if not file_path.exists():
                raise ValidationError(f"File not found: {file}")
            return (file_path.name, open(file_path, "rb"))

        raise ValidationError("file must be a path string, Path object, or bytes")

    def recall(
        self,
        text: str,
        source: Optional[str] = None,
        enable_trace: bool = False,
        alpha: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Retrieve memories based on semantic similarity."""
        if not text or not text.strip():
            raise ValidationError("Query text is required")
        if len(text) > 1000:
            raise ValidationError("Query text must be 1000 characters or less")
        if alpha is not None and (alpha < 0.0 or alpha > 1.0):
            raise ValidationError("alpha must be between 0.0 and 1.0")

        data: Dict[str, Any] = {"text": text}
        if source:
            data["source"] = source
        if enable_trace:
            data["enable_trace"] = "true"
        if alpha is not None:
            data["alpha"] = str(alpha)

        response = self.session.post(
            f"{self.base_url}/v1/memories/recall",
            headers=self._headers(),
            data=data,
            timeout=self.timeout,
        )
        return self._handle_response(response)

    def enrich_feedback(self, feedback_id: str, trace_id: str) -> Dict[str, Any]:
        """
        Trigger feature enrichment for an existing feedback document.

        This maps to the Core API's current public feedback-related endpoint,
        ``POST /v1/feedback/enrich``. It does not create feedback.
        """
        if not feedback_id or not feedback_id.strip():
            raise ValidationError("feedback_id is required")
        if not trace_id or not trace_id.strip():
            raise ValidationError("trace_id is required")

        response = self.session.post(
            f"{self.base_url}/v1/feedback/enrich",
            headers=self._headers(),
            data={"feedback_id": feedback_id, "trace_id": trace_id},
            timeout=self.timeout,
        )
        return self._handle_response(response)

    def health_check(self) -> bool:
        """Return True when the API health endpoint is reachable."""
        try:
            response = self.session.get(
                f"{self.base_url}/v1/health",
                timeout=self.timeout,
            )
            return response.status_code == 200
        except requests.exceptions.RequestException:
            return False

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
