"""
Engramme Python SDK for human memory.

Quick start:
    >>> from engramme import Engramme
    >>> client = Engramme(api_key="eng_sk_...")
    >>> client.recall("product launch meetings")
"""

from .auth import (
    get_token,
    list_profiles,
    login,
    logout,
    set_active_profile,
    whoami,
)
from .client import Engramme
from .exceptions import (
    APIError,
    AuthenticationError,
    EngrammeError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)

__version__ = "0.1.1"

__all__ = [
    "Engramme",
    "login",
    "logout",
    "whoami",
    "get_token",
    "list_profiles",
    "set_active_profile",
    "EngrammeError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "APIError",
]
