"""Authentication helpers for the Engramme SDK."""

import os
from pathlib import Path
from typing import Optional

import yaml

DEFAULT_CONFIG_DIR = Path.home() / ".engramme"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.yaml"
CONFIG_ENV_VAR_NAME = "ENGRAMME_CONFIG_PATH"
ENV_VAR_NAME = "ENGRAMME_API_KEY"


def get_config_path() -> Path:
    """Return the Engramme config path, respecting ENGRAMME_CONFIG_PATH."""
    custom_path = os.environ.get(CONFIG_ENV_VAR_NAME)
    if custom_path:
        return Path(custom_path)
    return DEFAULT_CONFIG_FILE


def login(token: str, profile: str = "default") -> None:
    """Save an API key to the local Engramme config file."""
    config_path = get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    config = {}
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

    config.setdefault("profiles", {})
    config["profiles"][profile] = {"api_key": token}

    if "active_profile" not in config:
        config["active_profile"] = profile

    with open(config_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False)

    os.chmod(config_path, 0o600)
    print(f"Token saved to {config_path}")


def logout(profile: Optional[str] = None) -> None:
    """Remove all saved API keys, or a single profile when provided."""
    config_path = get_config_path()

    if not config_path.exists():
        print("No config file found. Already logged out.")
        return

    if profile is None:
        config_path.unlink()
        print(f"Removed {config_path}")
        return

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    profiles = config.get("profiles", {})
    if profile not in profiles:
        print(f"Profile '{profile}' not found")
        return

    del profiles[profile]
    if config.get("active_profile") == profile:
        remaining = list(profiles.keys())
        config["active_profile"] = remaining[0] if remaining else None

    with open(config_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False)

    print(f"Removed profile '{profile}'")


def get_token(profile: Optional[str] = None) -> Optional[str]:
    """Resolve an API key from ENGRAMME_API_KEY or the local config file."""
    env_token = os.environ.get(ENV_VAR_NAME)
    if env_token:
        return env_token

    config_path = get_config_path()
    if not config_path.exists():
        return None

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    profiles = config.get("profiles", {})
    profile_name = profile or config.get("active_profile", "default")
    profile_data = profiles.get(profile_name, {})
    return profile_data.get("api_key")


def set_active_profile(profile: str) -> None:
    """Set the active local config profile."""
    config_path = get_config_path()

    if not config_path.exists():
        raise FileNotFoundError(f"No config file found at {config_path}. Run login() first.")

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    profiles = config.get("profiles", {})
    if profile not in profiles:
        raise ValueError(f"Profile '{profile}' not found. Available: {list(profiles.keys())}")

    config["active_profile"] = profile

    with open(config_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False)

    print(f"Active profile set to '{profile}'")


def list_profiles() -> dict:
    """Return configured profile names and active status."""
    config_path = get_config_path()

    if not config_path.exists():
        return {}

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    active = config.get("active_profile")
    profiles = config.get("profiles", {})
    return {name: {"active": name == active} for name in profiles.keys()}


def whoami() -> Optional[str]:
    """Print and return the active auth source."""
    token = get_token()
    if not token:
        print("Not logged in. Run `engramme login` or `login(token=...)`")
        return None

    config_path = get_config_path()
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
        profile = config.get("active_profile", "default")
        print(f"Logged in as profile '{profile}'")
        return profile

    print("Logged in via ENGRAMME_API_KEY environment variable")
    return "env"
