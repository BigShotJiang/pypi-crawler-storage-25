"""Exception hierarchy for the Engramme SDK."""


class EngrammeError(Exception):
    """Base exception for Engramme SDK errors."""


class AuthenticationError(EngrammeError):
    """Raised when an API key is missing, invalid, or expired."""


class RateLimitError(EngrammeError):
    """Raised when the API rate limit is exceeded."""


class NotFoundError(EngrammeError):
    """Raised when a requested resource is not found."""


class ValidationError(EngrammeError):
    """Raised when request data is invalid."""


class APIError(EngrammeError):
    """Raised when the API returns an unexpected error."""
