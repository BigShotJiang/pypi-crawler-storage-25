"""Integration tests for the Engramme SDK."""

import os
import tempfile

import pytest

from engramme import Engramme
from engramme.exceptions import AuthenticationError, EngrammeError

pytestmark = pytest.mark.integration

TEST_BASE_URL = os.environ.get(
    "ENGRAMME_TEST_BASE_URL",
    "https://memorymachines-gateway-prod-btf57kda.uc.gateway.dev",
)


@pytest.fixture
def client():
    api_key = os.environ.get("ENGRAMME_TEST_API_KEY")
    if not api_key:
        pytest.skip("ENGRAMME_TEST_API_KEY not set")

    return Engramme(api_key=api_key, base_url=TEST_BASE_URL)


class TestHealthCheckIntegration:
    def test_health_check_returns_true(self, client):
        assert client.health_check() is True


class TestRecallIntegration:
    def test_recall_returns_dict(self, client):
        result = client.recall("test query")

        assert isinstance(result, dict)
        assert "memories" in result
        assert isinstance(result["memories"], list)


class TestMemorizeIntegration:
    def test_memorize_text_file(self, client):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("This is a test document for SDK integration testing.\n")
            temp_path = f.name

        try:
            result = client.memorize(
                file=temp_path,
                user_name="SDK Test User",
                item_id=f"engramme_sdk_test_{os.urandom(4).hex()}",
                source_type="text",
            )

            assert isinstance(result, dict)
            assert result.get("status") == "success"
            assert "item_id" in result
        finally:
            os.unlink(temp_path)


class TestErrorHandlingIntegration:
    def test_invalid_api_key_raises_error(self):
        client = Engramme(api_key="invalid_key_12345", base_url=TEST_BASE_URL)

        with pytest.raises(AuthenticationError):
            client.recall("test")

    def test_empty_query_raises_sdk_error(self, client):
        with pytest.raises(EngrammeError):
            client.recall("")


class TestClientContextManager:
    def test_context_manager_usage(self):
        api_key = os.environ.get("ENGRAMME_TEST_API_KEY")
        if not api_key:
            pytest.skip("ENGRAMME_TEST_API_KEY not set")

        with Engramme(api_key=api_key, base_url=TEST_BASE_URL) as client:
            assert client.health_check() is True
