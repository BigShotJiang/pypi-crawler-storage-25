"""Unit tests for the Engramme client."""

from pathlib import Path
from unittest.mock import Mock, patch

import pytest
import requests

from engramme import Engramme
from engramme.client import DEFAULT_BASE_URL
from engramme.exceptions import (
    APIError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)


class TestEngrammeInit:
    def test_init_with_explicit_api_key(self):
        client = Engramme(api_key="test_key_123")

        assert client.api_key == "test_key_123"
        assert client.base_url == DEFAULT_BASE_URL

    def test_init_with_custom_base_url(self):
        client = Engramme(api_key="test_key", base_url="https://custom.api.com")

        assert client.base_url == "https://custom.api.com"

    def test_init_strips_trailing_slash(self):
        client = Engramme(api_key="test_key", base_url="https://api.com/")

        assert client.base_url == "https://api.com"

    def test_init_without_api_key_raises_error(self):
        with patch("engramme.client.get_token", return_value=None):
            with pytest.raises(AuthenticationError) as exc_info:
                Engramme()

        assert "No API key found" in str(exc_info.value)

    def test_init_discovers_api_key(self):
        with patch("engramme.client.get_token", return_value="env_key_123"):
            client = Engramme()

        assert client.api_key == "env_key_123"

    def test_init_with_profile(self):
        with patch("engramme.client.get_token", return_value="profile_key") as mock_get:
            client = Engramme(profile="work")

        mock_get.assert_called_once_with(profile="work")
        assert client.api_key == "profile_key"


class TestHealthCheck:
    def test_health_check_success(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.get.return_value = mock_response(200)

        assert client_with_mock_session.health_check() is True
        call_url = client_with_mock_session.session.get.call_args[0][0]
        assert "/v1/health" in call_url

    def test_health_check_failure(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.get.return_value = mock_response(500)

        assert client_with_mock_session.health_check() is False

    def test_health_check_connection_error(self, client_with_mock_session):
        client_with_mock_session.session.get.side_effect = requests.exceptions.ConnectionError()

        assert client_with_mock_session.health_check() is False


class TestRecall:
    def test_recall_success(self, client_with_mock_session, mock_response, sample_recall_response):
        client_with_mock_session.session.post.return_value = mock_response(
            200,
            sample_recall_response,
        )

        result = client_with_mock_session.recall("test query")

        assert result["trace_id"] == "trace_123"
        assert len(result["memories"]) == 1

    def test_recall_sends_correct_data(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(200, {"memories": []})

        client_with_mock_session.recall(
            "my test query",
            source="text",
            enable_trace=True,
            alpha=0.5,
        )

        call_kwargs = client_with_mock_session.session.post.call_args[1]
        assert call_kwargs["data"]["text"] == "my test query"
        assert call_kwargs["data"]["source"] == "text"
        assert call_kwargs["data"]["enable_trace"] == "true"
        assert call_kwargs["data"]["alpha"] == "0.5"
        assert call_kwargs["headers"]["x-api-key"] == client_with_mock_session.api_key

    def test_recall_validates_query_length(self, client_with_mock_session):
        with pytest.raises(ValidationError) as exc_info:
            client_with_mock_session.recall("x" * 1001)

        assert "1000 characters" in str(exc_info.value)

    def test_recall_requires_text(self, client_with_mock_session):
        with pytest.raises(ValidationError) as exc_info:
            client_with_mock_session.recall("")

        assert "Query text is required" in str(exc_info.value)

    def test_recall_validates_alpha(self, client_with_mock_session):
        with pytest.raises(ValidationError) as exc_info:
            client_with_mock_session.recall("test", alpha=1.5)

        assert "alpha" in str(exc_info.value)


class TestMemorize:
    def test_memorize_with_file_path(
        self,
        client_with_mock_session,
        mock_response,
        sample_memorize_response,
        tmp_path,
    ):
        client_with_mock_session.session.post.return_value = mock_response(
            200,
            sample_memorize_response,
        )
        test_file = tmp_path / "test.txt"
        test_file.write_text("Test content")

        result = client_with_mock_session.memorize(str(test_file), user_name="Test User")

        assert result["status"] == "success"
        assert "item_id" in result

    def test_memorize_with_path_object(
        self,
        client_with_mock_session,
        mock_response,
        sample_memorize_response,
        tmp_path,
    ):
        client_with_mock_session.session.post.return_value = mock_response(
            200,
            sample_memorize_response,
        )
        test_file = tmp_path / "test.txt"
        test_file.write_text("Test content")

        result = client_with_mock_session.memorize(Path(test_file), user_name="Test User")

        assert result["status"] == "success"

    def test_memorize_with_bytes(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            200,
            {"status": "success"},
        )

        result = client_with_mock_session.memorize(
            b"Test content bytes",
            user_name="Test User",
            filename="test.txt",
        )

        assert result["status"] == "success"

    def test_memorize_with_optional_params(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            200,
            {"status": "success"},
        )

        client_with_mock_session.memorize(
            b"Test content",
            user_name="Test User",
            item_id="custom_id_123",
            source_type="text",
            source_metadata='{"origin":"test"}',
        )

        call_kwargs = client_with_mock_session.session.post.call_args[1]
        assert call_kwargs["data"]["user_name"] == "Test User"
        assert call_kwargs["data"]["item_id"] == "custom_id_123"
        assert call_kwargs["data"]["source_type"] == "text"
        assert call_kwargs["data"]["source_metadata"] == '{"origin":"test"}'

    def test_memorize_file_not_found(self, client_with_mock_session):
        with pytest.raises(ValidationError) as exc_info:
            client_with_mock_session.memorize("/nonexistent/file.txt", user_name="Test")

        assert "File not found" in str(exc_info.value)

    def test_memorize_requires_user_name(self, client_with_mock_session):
        with pytest.raises(ValidationError) as exc_info:
            client_with_mock_session.memorize(b"test", user_name="")

        assert "user_name is required" in str(exc_info.value)

    def test_memorize_url_correct(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            200,
            {"status": "success"},
        )

        client_with_mock_session.memorize(b"test", user_name="Test")

        call_url = client_with_mock_session.session.post.call_args[0][0]
        assert "/v1/memorize" in call_url


class TestEnrichFeedback:
    def test_enrich_feedback_success(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            202,
            {"status": "accepted", "feedback_id": "fb_1", "trace_id": "trace_1"},
        )

        result = client_with_mock_session.enrich_feedback("fb_1", "trace_1")

        assert result["status"] == "accepted"
        call_url = client_with_mock_session.session.post.call_args[0][0]
        call_kwargs = client_with_mock_session.session.post.call_args[1]
        assert "/v1/feedback/enrich" in call_url
        assert call_kwargs["data"]["feedback_id"] == "fb_1"
        assert call_kwargs["data"]["trace_id"] == "trace_1"

    def test_enrich_feedback_requires_feedback_id(self, client_with_mock_session):
        with pytest.raises(ValidationError):
            client_with_mock_session.enrich_feedback("", "trace_1")

    def test_enrich_feedback_requires_trace_id(self, client_with_mock_session):
        with pytest.raises(ValidationError):
            client_with_mock_session.enrich_feedback("fb_1", "")


class TestNoAskSurface:
    def test_client_does_not_expose_ask(self):
        client = Engramme(api_key="test")

        assert not hasattr(client, "ask")


class TestErrorHandling:
    def test_401_raises_authentication_error(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            401,
            {"detail": "Invalid API key"},
        )

        with pytest.raises(AuthenticationError) as exc_info:
            client_with_mock_session.recall("test")

        assert "Invalid" in str(exc_info.value)

    def test_403_raises_authentication_error(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            403,
            {"detail": "Forbidden"},
        )

        with pytest.raises(AuthenticationError):
            client_with_mock_session.recall("test")

    def test_404_raises_not_found_error(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            404,
            {"detail": "Not found"},
        )

        with pytest.raises(NotFoundError):
            client_with_mock_session.enrich_feedback("fb_1", "trace_1")

    def test_409_raises_validation_error(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            409,
            {"detail": "Item already exists"},
        )

        with pytest.raises(ValidationError):
            client_with_mock_session.memorize(b"test", user_name="Test")

    def test_429_raises_rate_limit_error(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            429,
            {"detail": "Too many requests"},
        )

        with pytest.raises(RateLimitError):
            client_with_mock_session.recall("test")

    def test_422_raises_validation_error(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            422,
            {"detail": [{"msg": "Field required"}]},
        )

        with pytest.raises(ValidationError) as exc_info:
            client_with_mock_session.recall("test")

        assert "Field required" in str(exc_info.value)

    def test_500_raises_api_error(self, client_with_mock_session, mock_response):
        client_with_mock_session.session.post.return_value = mock_response(
            500,
            {"detail": "Internal error"},
        )

        with pytest.raises(APIError):
            client_with_mock_session.recall("test")

    def test_error_with_text_fallback(self, client_with_mock_session):
        response = Mock(spec=requests.Response)
        response.status_code = 400
        response.text = "Plain text error"
        response.json.side_effect = ValueError("No JSON")
        response.raise_for_status.side_effect = requests.exceptions.HTTPError(
            response=response
        )
        client_with_mock_session.session.post.return_value = response

        with pytest.raises(ValidationError) as exc_info:
            client_with_mock_session.recall("test")

        assert "Plain text error" in str(exc_info.value)
