"""Unit tests for Engramme auth helpers."""

import os
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from engramme.auth import (
    CONFIG_ENV_VAR_NAME,
    DEFAULT_CONFIG_DIR,
    ENV_VAR_NAME,
    get_config_path,
    get_token,
    list_profiles,
    login,
    logout,
    set_active_profile,
    whoami,
)


class TestGetConfigPath:
    def test_default_path(self):
        with patch.dict(os.environ, {}, clear=True):
            path = get_config_path()

        assert path == DEFAULT_CONFIG_DIR / "config.yaml"

    def test_custom_path_from_env(self):
        with patch.dict(os.environ, {CONFIG_ENV_VAR_NAME: "/custom/path/config.yaml"}):
            path = get_config_path()

        assert path == Path("/custom/path/config.yaml")


class TestLogin:
    def test_login_creates_config_dir(self, tmp_path):
        config_file = tmp_path / ".engramme" / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("test_token_123")

        assert config_file.parent.exists()
        assert config_file.exists()

    def test_login_saves_token(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("my_api_key_xyz")

        with open(config_file, encoding="utf-8") as f:
            config = yaml.safe_load(f)

        assert config["profiles"]["default"]["api_key"] == "my_api_key_xyz"

    def test_login_with_profile(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("work_key", profile="work")

        with open(config_file, encoding="utf-8") as f:
            config = yaml.safe_load(f)

        assert config["profiles"]["work"]["api_key"] == "work_key"

    def test_login_preserves_existing_profiles(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("token1", profile="profile1")
            login("token2", profile="profile2")

        with open(config_file, encoding="utf-8") as f:
            config = yaml.safe_load(f)

        assert "profile1" in config["profiles"]
        assert "profile2" in config["profiles"]

    def test_login_sets_file_permissions(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("token")

        mode = config_file.stat().st_mode & 0o777
        assert mode == 0o600


class TestLogout:
    def test_logout_removes_config_file(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("token")
            logout()

        assert not config_file.exists()

    def test_logout_specific_profile(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("token1", profile="work")
            login("token2", profile="personal")
            logout(profile="work")

        with open(config_file, encoding="utf-8") as f:
            config = yaml.safe_load(f)

        assert "work" not in config["profiles"]
        assert "personal" in config["profiles"]

    def test_logout_no_config_file(self, tmp_path, capsys):
        config_file = tmp_path / "nonexistent.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            logout()

        captured = capsys.readouterr()
        assert "Already logged out" in captured.out


class TestGetToken:
    def test_get_token_from_env(self):
        with patch.dict(os.environ, {ENV_VAR_NAME: "env_token_123"}):
            token = get_token()

        assert token == "env_token_123"

    def test_get_token_from_config(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch.dict(os.environ, {}, clear=True):
            with patch("engramme.auth.get_config_path", return_value=config_file):
                login("config_token")
                token = get_token()

        assert token == "config_token"

    def test_get_token_env_takes_precedence(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("config_token")

        with patch.dict(os.environ, {ENV_VAR_NAME: "env_token"}):
            with patch("engramme.auth.get_config_path", return_value=config_file):
                token = get_token()

        assert token == "env_token"

    def test_get_token_specific_profile(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch.dict(os.environ, {}, clear=True):
            with patch("engramme.auth.get_config_path", return_value=config_file):
                login("default_token", profile="default")
                login("work_token", profile="work")
                token = get_token(profile="work")

        assert token == "work_token"

    def test_get_token_returns_none_when_not_found(self, tmp_path):
        config_file = tmp_path / "nonexistent.yaml"

        with patch.dict(os.environ, {}, clear=True):
            with patch("engramme.auth.get_config_path", return_value=config_file):
                token = get_token()

        assert token is None


class TestProfiles:
    def test_set_active_profile(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("token1", profile="profile1")
            login("token2", profile="profile2")
            set_active_profile("profile2")

        with open(config_file, encoding="utf-8") as f:
            config = yaml.safe_load(f)

        assert config["active_profile"] == "profile2"

    def test_set_active_profile_nonexistent(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("token", profile="default")
            with pytest.raises(ValueError):
                set_active_profile("nonexistent")

    def test_list_profiles_empty(self, tmp_path):
        config_file = tmp_path / "nonexistent.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            profiles = list_profiles()

        assert profiles == {}

    def test_list_profiles_multiple(self, tmp_path):
        config_file = tmp_path / "config.yaml"

        with patch("engramme.auth.get_config_path", return_value=config_file):
            login("token1", profile="default")
            login("token2", profile="work")
            profiles = list_profiles()

        assert profiles["default"]["active"] is True
        assert profiles["work"]["active"] is False


class TestWhoami:
    def test_whoami_logged_in(self, tmp_path, capsys):
        config_file = tmp_path / "config.yaml"

        with patch.dict(os.environ, {}, clear=True):
            with patch("engramme.auth.get_config_path", return_value=config_file):
                login("token", profile="myprofile")
                result = whoami()

        assert result == "myprofile"
        captured = capsys.readouterr()
        assert "myprofile" in captured.out

    def test_whoami_not_logged_in(self, tmp_path, capsys):
        config_file = tmp_path / "nonexistent.yaml"

        with patch.dict(os.environ, {}, clear=True):
            with patch("engramme.auth.get_config_path", return_value=config_file):
                result = whoami()

        assert result is None
        captured = capsys.readouterr()
        assert "Not logged in" in captured.out

    def test_whoami_env_var(self, capsys):
        with patch.dict(os.environ, {ENV_VAR_NAME: "env_token"}):
            with patch("engramme.auth.get_config_path") as mock_path:
                mock_path.return_value.exists.return_value = False
                result = whoami()

        assert result == "env"
        captured = capsys.readouterr()
        assert "ENGRAMME_API_KEY" in captured.out
