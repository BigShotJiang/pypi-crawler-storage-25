# SPDX-FileCopyrightText: (c) 2026 Tenstorrent AI ULC
#
# SPDX-License-Identifier: Apache-2.0

#
# Tutorial Step 2: Single Node, Multi-Tile Block
# ===============================================
# Builds on Step 1 by processing multiple tiles per dataflow buffer entry
# instead of one tile at a time.
#
# New concept introduced:
#   - Multi-tile blocks: each DFB entry holds a GRANULARITY×GRANULARITY patch
#     of tiles.  Fewer, larger memory transfers reduce per-transfer overhead and
#     give the compute kernel more work per synchronization round-trip.
#
# Everything else (single node, same operation structure, same three-kernel model)
# is identical to Step 1.

import ttnn
import torch


def from_torch(tensor: torch.Tensor):
    return ttnn.from_torch(
        tensor,
        dtype=ttnn.bfloat16,
        layout=ttnn.TILE_LAYOUT,
        device=device,
        memory_config=ttnn.DRAM_MEMORY_CONFIG,
    )


import ttl

TILE_SIZE = 32

# GRANULARITY controls how many tiles fit along each dimension of one block.
# With GRANULARITY=4 each block is a 4×4 patch of 32×32 tiles = 128×128 elements.

GRANULARITY = 4


@ttl.operation(grid=(1, 1))
def __tutorial_operation(
    a: ttnn.Tensor, b: ttnn.Tensor, c: ttnn.Tensor, y: ttnn.Tensor
):
    row_tiles_per_block = GRANULARITY
    col_tiles_per_block = GRANULARITY

    # rows/cols now count blocks, not individual tiles.

    rows = a.shape[0] // TILE_SIZE // row_tiles_per_block
    cols = a.shape[1] // TILE_SIZE // col_tiles_per_block

    # shape=(row_tiles_per_block, col_tiles_per_block) makes each DFB entry
    # large enough to hold the entire multi-tile block.

    a_dfb = ttl.make_dataflow_buffer_like(
        a, shape=(row_tiles_per_block, col_tiles_per_block), block_count=2
    )
    b_dfb = ttl.make_dataflow_buffer_like(
        b, shape=(row_tiles_per_block, col_tiles_per_block), block_count=2
    )
    c_dfb = ttl.make_dataflow_buffer_like(
        c, shape=(row_tiles_per_block, col_tiles_per_block), block_count=2
    )
    y_dfb = ttl.make_dataflow_buffer_like(
        y, shape=(row_tiles_per_block, col_tiles_per_block), block_count=2
    )

    # The compute kernel is unchanged in structure: it still iterates over
    # blocks and applies the fused operation.  The hardware now operates on
    # a full multi-tile block per iteration rather than a single tile.

    @ttl.compute()
    def tutorial_compute():
        for _ in range(rows):
            for _ in range(cols):
                with (
                    a_dfb.wait() as a_blk,
                    b_dfb.wait() as b_blk,
                    c_dfb.wait() as c_blk,
                    y_dfb.reserve() as y_blk,
                ):
                    y_blk.store(a_blk * b_blk + c_blk)

    @ttl.datamovement()
    def tutorial_read():
        for row in range(rows):

            # Convert block index to tile index range for the tensor slice.

            start_row_tile = row * row_tiles_per_block
            end_row_tile = (row + 1) * row_tiles_per_block

            for col in range(cols):
                start_col_tile = col * col_tiles_per_block
                end_col_tile = (col + 1) * col_tiles_per_block

                with (
                    a_dfb.reserve() as a_blk,
                    b_dfb.reserve() as b_blk,
                    c_dfb.reserve() as c_blk,
                ):
                    # Slice with a range to copy the entire block in one transfer.

                    tx_a = ttl.copy(
                        a[
                            start_row_tile:end_row_tile,
                            start_col_tile:end_col_tile,
                        ],
                        a_blk,
                    )
                    tx_b = ttl.copy(
                        b[
                            start_row_tile:end_row_tile,
                            start_col_tile:end_col_tile,
                        ],
                        b_blk,
                    )
                    tx_c = ttl.copy(
                        c[
                            start_row_tile:end_row_tile,
                            start_col_tile:end_col_tile,
                        ],
                        c_blk,
                    )

                    tx_a.wait()
                    tx_b.wait()
                    tx_c.wait()

    @ttl.datamovement()
    def tutorial_write():
        for row in range(rows):
            start_row_tile = row * row_tiles_per_block
            end_row_tile = (row + 1) * row_tiles_per_block

            for col in range(cols):
                start_col_tile = col * col_tiles_per_block
                end_col_tile = (col + 1) * col_tiles_per_block

                with y_dfb.wait() as y_blk:
                    tx = ttl.copy(
                        y_blk,
                        y[
                            start_row_tile:end_row_tile,
                            start_col_tile:end_col_tile,
                        ],
                    )
                    tx.wait()


def tutorial_operation(a: ttnn.Tensor, b: ttnn.Tensor, c: ttnn.Tensor):
    y = from_torch(torch.zeros((a.shape[0], a.shape[1]), dtype=torch.bfloat16))
    __tutorial_operation(a, b, c, y)
    return y


torch.manual_seed(42)

device = ttnn.open_device(device_id=0)

try:
    shape = (2048, 2048)

    a = torch.rand(shape, dtype=torch.bfloat16)
    b = torch.rand(shape, dtype=torch.bfloat16)
    c = torch.rand(shape, dtype=torch.bfloat16)
    d = torch.rand(shape, dtype=torch.bfloat16)

    expected_y = (a * b + c) * d

    a = from_torch(a)
    b = from_torch(b)
    c = from_torch(c)
    d = from_torch(d)

    y = ttnn.multiply(tutorial_operation(a, b, c), d)

    y = ttnn.to_torch(y)
    print(y)
    print(expected_y)

    assert torch.allclose(y, expected_y, rtol=1e-2, atol=1e-2), "Tensors do not match"

finally:
    ttnn.close_device(device)
