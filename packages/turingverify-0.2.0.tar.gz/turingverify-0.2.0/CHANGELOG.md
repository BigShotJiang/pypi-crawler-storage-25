# Changelog

All notable changes to the `turingverify` Python SDK are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-04-17

### Added
- Initial release of the official Turing Verify Python SDK.
- Sync `TuringVerify` and async `AsyncTuringVerify` clients.
- `verifications.create/retrieve/list/batch`, `webhooks.create/list/verify_signature`,
  `account.retrieve/usage`.
- Typed Pydantic models mirroring the `/v1` schema.
- Error hierarchy (`TuringVerifyError`, `APIError`, `AuthenticationError`,
  `RateLimitError`, `InvalidRequestError`, `IdempotencyConflictError`,
  `SignatureVerificationError`).
- Exponential-backoff retry with `Retry-After` support.
- Automatic UUID4 `Idempotency-Key` on every `POST /v1/verifications`.
- `turingverify` CLI (verify, tokens, webhooks) with `--json` flag.
