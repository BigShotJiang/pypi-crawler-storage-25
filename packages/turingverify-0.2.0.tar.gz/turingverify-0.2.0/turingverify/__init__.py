"""turingverify — official Python SDK for the Turing Verify API.

Quickstart::

    from turingverify import TuringVerify

    client = TuringVerify(api_key="tv_live_sk_...")
    with open("diploma.pdf", "rb") as f:
        ver = client.verifications.create(file=f, filename="diploma.pdf")
    print(ver.verdict, ver.confidence)

See https://api.verify.turingcerts.com/v1/docs/reference for the full docs.
"""

from turingverify._errors import (
    APIError,
    AuthenticationError,
    IdempotencyConflictError,
    InvalidRequestError,
    RateLimitError,
    SignatureVerificationError,
    TuringVerifyError,
)
from turingverify._models import (
    Account,
    BatchResult,
    Credits,
    Page,
    Plan,
    Usage,
    UsageBucket,
    VerdictEnum,
    Verification,
    WebhookEndpoint,
    WebhookEndpointWithSecret,
)
from turingverify._version import __version__
from turingverify._webhooks import verify_signature
from turingverify.client import AsyncTuringVerify, TuringVerify

__all__ = [
    "__version__",
    "TuringVerify",
    "AsyncTuringVerify",
    "VerdictEnum",
    "Verification",
    "BatchResult",
    "WebhookEndpoint",
    "WebhookEndpointWithSecret",
    "Account",
    "Plan",
    "Credits",
    "Usage",
    "UsageBucket",
    "Page",
    "verify_signature",
    "TuringVerifyError",
    "APIError",
    "AuthenticationError",
    "RateLimitError",
    "InvalidRequestError",
    "IdempotencyConflictError",
    "SignatureVerificationError",
]
