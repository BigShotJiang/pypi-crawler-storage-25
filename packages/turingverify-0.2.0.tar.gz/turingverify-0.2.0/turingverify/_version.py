"""Package version — isolated so client.py can import without the full package."""

__version__ = "0.2.0"
