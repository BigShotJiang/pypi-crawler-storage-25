"""Typed models mirrored from backend/app/schemas/v1/*.py.

We intentionally keep ``extra="allow"`` so additive server changes don't
crash older SDK clients; strict mode is opt-in per model.
"""

from __future__ import annotations

import enum
from typing import Any, Dict, Generic, List, Literal, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field


T = TypeVar("T")


class _SDKModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    def dict(self, **kwargs: Any) -> Dict[str, Any]:  # type: ignore[override]
        # Pydantic v1 interop — some integrations still call .dict().
        return self.model_dump(**kwargs)


# ─── Verification ─────────────────────────────────────────────────────


class VerdictEnum(str, enum.Enum):
    ACCEPT = "ACCEPT"
    REJECT = "REJECT"
    SUSPECT = "SUSPECT"


class Verification(_SDKModel):
    id: str
    status: str
    verdict: Optional[VerdictEnum] = None
    confidence: Optional[float] = None
    doc_type: Optional[str] = None
    livemode: bool = False
    created_at: str
    poll_url: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class Page(_SDKModel, Generic[T]):
    """Cursor-paginated list response."""

    data: List[T] = Field(default_factory=list)
    has_more: bool = False
    next_cursor: Optional[str] = None
    object: Optional[str] = None


class BatchResult(_SDKModel):
    id: str
    object: str = "batch"
    verifications: List[Verification] = Field(default_factory=list)


# ─── Webhooks ─────────────────────────────────────────────────────────


class WebhookEndpoint(_SDKModel):
    id: str
    url: str
    events: List[str]
    description: Optional[str] = None
    status: str = "active"
    active: bool = True
    secret_prefix: str = "whsec_"
    secret_last4: str = ""
    created_at: str
    last_success_at: Optional[str] = None
    last_failure_at: Optional[str] = None
    consecutive_failures: int = 0


class WebhookEndpointWithSecret(WebhookEndpoint):
    """One-time create/rotate response including the raw signing secret."""

    secret: str


# ─── Account & Usage ──────────────────────────────────────────────────


class Plan(_SDKModel):
    tier: str
    billing_interval: Optional[str] = None
    api_access: bool = False
    rate_limit_burst: Optional[int] = None
    rate_limit_sustained: Optional[int] = None


class Credits(_SDKModel):
    included: int = 0
    used: int = 0
    remaining: int = 0
    reset_at: Optional[str] = None
    overage_opt_in: bool = False


class Account(_SDKModel):
    user_id: str
    email: str
    plan: Plan
    credits: Credits


class UsageBucket(_SDKModel):
    key: str
    requests: int = 0
    credits_charged: int = 0
    errors: int = 0


class Usage(_SDKModel):
    period_start: str
    period_end: str
    group_by: str = "day"
    data: List[UsageBucket] = Field(default_factory=list)


__all__ = [
    "VerdictEnum",
    "Verification",
    "Page",
    "BatchResult",
    "WebhookEndpoint",
    "WebhookEndpointWithSecret",
    "Plan",
    "Credits",
    "Account",
    "UsageBucket",
    "Usage",
]
