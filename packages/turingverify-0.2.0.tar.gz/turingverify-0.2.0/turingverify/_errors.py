"""Error hierarchy.

Every exception raised by the SDK is a subclass of :class:`TuringVerifyError`
so callers can ``except TuringVerifyError`` as a blanket rescue without
accidentally catching unrelated runtime exceptions.

Mapping from the server error envelope::

    {"error": {"code": "<machine>", "message": "<human>", ...}}

is handled in :func:`raise_for_response`.
"""

from __future__ import annotations

from typing import Any, Mapping, Optional


class TuringVerifyError(Exception):
    """Base class for every error this SDK raises."""

    def __init__(
        self,
        message: str,
        *,
        code: Optional[str] = None,
        status_code: Optional[int] = None,
        request_id: Optional[str] = None,
        response_body: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.request_id = request_id
        self.response_body = response_body

    def __str__(self) -> str:  # pragma: no cover — trivial
        base = super().__str__()
        bits = [base]
        if self.code:
            bits.append(f"code={self.code!r}")
        if self.status_code is not None:
            bits.append(f"status={self.status_code}")
        if self.request_id:
            bits.append(f"request_id={self.request_id!r}")
        return " ".join(bits)


class APIError(TuringVerifyError):
    """Generic non-2xx response that doesn't fit a more specific class."""


class AuthenticationError(APIError):
    """401 — missing / invalid / revoked API token."""


class InvalidRequestError(APIError):
    """400 / 422 — the server rejected the request shape or parameters."""


class RateLimitError(APIError):
    """429 — token bucket exhausted OR credit quota exhausted."""

    def __init__(
        self,
        message: str,
        *,
        retry_after: Optional[float] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class IdempotencyConflictError(APIError):
    """409 — the same Idempotency-Key was reused with a different body."""


class SignatureVerificationError(TuringVerifyError):
    """Webhook signature could not be verified (tampered, stale, or wrong secret)."""


# ─── Response → exception mapping ─────────────────────────────────────


_STATUS_TO_EXC: Mapping[int, type[APIError]] = {
    400: InvalidRequestError,
    401: AuthenticationError,
    403: APIError,  # plan_required / insufficient_scope both land here
    404: APIError,
    409: IdempotencyConflictError,
    422: InvalidRequestError,
    429: RateLimitError,
}


def raise_for_response(
    status_code: int,
    body: Any,
    *,
    request_id: Optional[str] = None,
    retry_after: Optional[float] = None,
) -> None:
    """Translate an error envelope into the right exception type.

    ``body`` may already be decoded JSON, a str, or None.
    """
    envelope = body.get("error", {}) if isinstance(body, dict) else {}
    code = envelope.get("code") if isinstance(envelope, dict) else None
    message = (
        envelope.get("message")
        if isinstance(envelope, dict) and envelope.get("message")
        else f"HTTP {status_code} from Turing Verify API"
    )
    # Prefer the envelope's request_id over the header when the server
    # includes both — the envelope copy is authoritative.
    if isinstance(envelope, dict) and envelope.get("request_id"):
        request_id = envelope["request_id"]
    exc_cls = _STATUS_TO_EXC.get(status_code, APIError)
    if exc_cls is RateLimitError:
        raise RateLimitError(
            message,
            code=code,
            status_code=status_code,
            request_id=request_id,
            response_body=body,
            retry_after=retry_after,
        )
    raise exc_cls(
        message,
        code=code,
        status_code=status_code,
        request_id=request_id,
        response_body=body,
    )
