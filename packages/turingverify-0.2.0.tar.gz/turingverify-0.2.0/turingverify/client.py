"""Sync and async clients built on httpx.

``TuringVerify`` / ``AsyncTuringVerify`` expose four resource namespaces
(:class:`Verifications`, :class:`Webhooks`, :class:`Account`, and
``raw.request`` as an escape hatch). Both share the retry / idempotency
logic via :class:`_Transport`.
"""

from __future__ import annotations

import asyncio
import random
import time
import uuid
from typing import (
    Any,
    Awaitable,
    BinaryIO,
    Callable,
    Dict,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Union,
)

import httpx

from turingverify._version import __version__
from turingverify._errors import (
    APIError,
    RateLimitError,
    TuringVerifyError,
    raise_for_response,
)
from turingverify._models import (
    Account,
    BatchResult,
    Page,
    Usage,
    Verification,
    WebhookEndpoint,
    WebhookEndpointWithSecret,
)
from turingverify._webhooks import verify_signature as _verify_signature

DEFAULT_BASE_URL = "https://api.verify.turingcerts.com"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
_USER_AGENT = f"turingverify-python/{__version__}"

FileLike = Union[bytes, BinaryIO]


# ─── Transport core ───────────────────────────────────────────────────


def _compute_backoff(attempt: int, retry_after: Optional[float]) -> float:
    """Exponential backoff with jitter; prefer ``Retry-After`` when set."""
    if retry_after is not None and retry_after > 0:
        return min(float(retry_after), 60.0)
    base = 0.5 * (2 ** attempt)
    return min(base + random.random() * 0.25, 30.0)


def _parse_retry_after(value: Optional[str]) -> Optional[float]:
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def _should_retry(exc_or_status: Union[Exception, int]) -> bool:
    if isinstance(exc_or_status, int):
        return exc_or_status >= 500 or exc_or_status == 429
    # httpx raises TransportError for network issues.
    return isinstance(exc_or_status, (httpx.TransportError, httpx.TimeoutException))


class _TransportBase:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        timeout: float,
        max_retries: int,
    ) -> None:
        if not api_key or not api_key.startswith(("tv_live_sk_", "tv_test_sk_")):
            raise ValueError(
                "api_key must be a tv_live_sk_... or tv_test_sk_... bearer token."
            )
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max(0, int(max_retries))

    def _default_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": _USER_AGENT,
            "Accept": "application/json",
        }

    def _full_url(self, path: str) -> str:
        if path.startswith(("http://", "https://")):
            return path
        return f"{self.base_url}{path if path.startswith('/') else '/' + path}"

    def _decode(self, resp: httpx.Response) -> Any:
        if not resp.content:
            return None
        ctype = (resp.headers.get("content-type") or "").lower()
        if "json" in ctype:
            try:
                return resp.json()
            except Exception:
                return resp.text
        return resp.text

    def _raise_if_error(self, resp: httpx.Response) -> None:
        if 200 <= resp.status_code < 300:
            return
        body = self._decode(resp)
        retry_after = _parse_retry_after(resp.headers.get("Retry-After"))
        raise_for_response(
            resp.status_code,
            body,
            request_id=resp.headers.get("X-Request-ID"),
            retry_after=retry_after,
        )


class _SyncTransport(_TransportBase):
    def __init__(self, *, client: Optional[httpx.Client] = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._client_external = client is not None
        self._client = client or httpx.Client(timeout=self.timeout)

    def close(self) -> None:
        if not self._client_external:
            self._client.close()

    def __enter__(self) -> "_SyncTransport":
        return self

    def __exit__(self, *a: Any) -> None:
        self.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        params: Any = None,
        headers: Optional[Mapping[str, str]] = None,
    ) -> Any:
        url = self._full_url(path)
        merged_headers = self._default_headers()
        if headers:
            merged_headers.update(headers)

        attempt = 0
        last_exc: Optional[Exception] = None
        while True:
            try:
                resp = self._client.request(
                    method,
                    url,
                    json=json,
                    data=data,
                    files=files,
                    params=params,
                    headers=merged_headers,
                    timeout=self.timeout,
                )
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                last_exc = exc
                if attempt >= self.max_retries:
                    raise APIError(
                        f"Network error after {attempt + 1} attempts: {exc}",
                        code="network_error",
                    ) from exc
                delay = _compute_backoff(attempt, None)
                attempt += 1
                time.sleep(delay)
                continue

            if resp.status_code >= 500 or resp.status_code == 429:
                if attempt < self.max_retries:
                    retry_after = _parse_retry_after(resp.headers.get("Retry-After"))
                    delay = _compute_backoff(attempt, retry_after)
                    attempt += 1
                    time.sleep(delay)
                    continue

            self._raise_if_error(resp)
            return self._decode(resp)


class _AsyncTransport(_TransportBase):
    def __init__(self, *, client: Optional[httpx.AsyncClient] = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._client_external = client is not None
        self._client = client or httpx.AsyncClient(timeout=self.timeout)

    async def aclose(self) -> None:
        if not self._client_external:
            await self._client.aclose()

    async def __aenter__(self) -> "_AsyncTransport":
        return self

    async def __aexit__(self, *a: Any) -> None:
        await self.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        params: Any = None,
        headers: Optional[Mapping[str, str]] = None,
    ) -> Any:
        url = self._full_url(path)
        merged_headers = self._default_headers()
        if headers:
            merged_headers.update(headers)

        attempt = 0
        while True:
            try:
                resp = await self._client.request(
                    method,
                    url,
                    json=json,
                    data=data,
                    files=files,
                    params=params,
                    headers=merged_headers,
                    timeout=self.timeout,
                )
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                if attempt >= self.max_retries:
                    raise APIError(
                        f"Network error after {attempt + 1} attempts: {exc}",
                        code="network_error",
                    ) from exc
                delay = _compute_backoff(attempt, None)
                attempt += 1
                await asyncio.sleep(delay)
                continue

            if resp.status_code >= 500 or resp.status_code == 429:
                if attempt < self.max_retries:
                    retry_after = _parse_retry_after(resp.headers.get("Retry-After"))
                    delay = _compute_backoff(attempt, retry_after)
                    attempt += 1
                    await asyncio.sleep(delay)
                    continue

            self._raise_if_error(resp)
            return self._decode(resp)


# ─── Sync resources ───────────────────────────────────────────────────


def _read_file(
    file: FileLike,
) -> bytes:
    if hasattr(file, "read"):
        data = file.read()
        if isinstance(data, str):
            data = data.encode("utf-8")
        return data  # type: ignore[return-value]
    if isinstance(file, (bytes, bytearray)):
        return bytes(file)
    raise TypeError(
        "file must be bytes or a binary file object (with a .read() method)."
    )


def _auto_idempotency_key(provided: Optional[str]) -> str:
    return provided or f"idem_{uuid.uuid4().hex}"


class _VerificationsSync:
    def __init__(self, transport: _SyncTransport) -> None:
        self._t = transport

    def create(
        self,
        file: FileLike,
        *,
        filename: Optional[str] = None,
        mime_type: Optional[str] = None,
        document_type: Optional[str] = None,
        test_mode: bool = False,
        idempotency_key: Optional[str] = None,
    ) -> Verification:
        data = _read_file(file)
        resolved_filename = filename or getattr(file, "name", None) or "document"
        key = _auto_idempotency_key(idempotency_key)
        files = {"file": (resolved_filename, data, mime_type or "application/octet-stream")}
        form: Dict[str, Any] = {}
        if document_type:
            form["document_type"] = document_type
        if test_mode:
            form["test_mode"] = "true"
        headers = {"Idempotency-Key": key}
        body = self._t.request(
            "POST",
            "/v1/verifications",
            files=files,
            data=form or None,
            headers=headers,
        )
        return Verification.model_validate(body)

    def retrieve(self, id: str) -> Verification:
        body = self._t.request("GET", f"/v1/verifications/{id}")
        return Verification.model_validate(body)

    def list(
        self,
        *,
        limit: int = 20,
        cursor: Optional[str] = None,
        verdict: Optional[str] = None,
    ) -> Page[Verification]:
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["starting_after"] = cursor
        if verdict:
            params["verdict"] = verdict
        body = self._t.request("GET", "/v1/verifications", params=params)
        raw_items = body.get("data", []) if isinstance(body, dict) else []
        return Page[Verification](
            data=[Verification.model_validate(i) for i in raw_items],
            has_more=bool(body.get("has_more", False)) if isinstance(body, dict) else False,
            next_cursor=body.get("next_cursor") if isinstance(body, dict) else None,
            object=body.get("object") if isinstance(body, dict) else None,
        )

    def batch(
        self,
        files: Sequence[Tuple[FileLike, str]],
        *,
        test_mode: bool = False,
    ) -> BatchResult:
        # The server's batch accepts JSON {documents:[{url|base64}]} — map
        # each file's bytes to a base64 item.
        import base64 as _b64

        documents = []
        for f, name in files:
            blob = _read_file(f)
            documents.append(
                {
                    "base64": _b64.b64encode(blob).decode("ascii"),
                    "content_type": "application/octet-stream",
                    "filename": name,
                }
            )
        payload = {"documents": documents}
        if test_mode:
            payload["test_mode"] = True  # type: ignore[assignment]
        body = self._t.request("POST", "/v1/verifications/batch", json=payload)
        if not isinstance(body, dict):
            raise APIError("Unexpected batch response shape.")
        return BatchResult.model_validate(body)


class _WebhooksSync:
    def __init__(self, transport: _SyncTransport) -> None:
        self._t = transport

    def create(
        self,
        url: str,
        events: List[str],
        *,
        description: Optional[str] = None,
    ) -> WebhookEndpointWithSecret:
        body = self._t.request(
            "POST",
            "/v1/webhooks",
            json={"url": url, "events": events, "description": description},
        )
        return WebhookEndpointWithSecret.model_validate(body)

    def list(
        self,
        *,
        event_types: Optional[List[str]] = None,
    ) -> List[WebhookEndpoint]:
        params: Dict[str, Any] = {}
        if event_types:
            params["event_types"] = ",".join(event_types)
        body = self._t.request("GET", "/v1/webhooks", params=params or None)
        if isinstance(body, list):
            return [WebhookEndpoint.model_validate(i) for i in body]
        # Some servers wrap lists in {data: [...]} — be tolerant.
        if isinstance(body, dict) and isinstance(body.get("data"), list):
            return [WebhookEndpoint.model_validate(i) for i in body["data"]]
        return []

    def retrieve(self, id: str) -> WebhookEndpoint:
        body = self._t.request("GET", f"/v1/webhooks/{id}")
        return WebhookEndpoint.model_validate(body)

    def update(
        self,
        id: str,
        *,
        url: Optional[str] = None,
        events: Optional[List[str]] = None,
        description: Optional[str] = None,
        active: Optional[bool] = None,
    ) -> WebhookEndpoint:
        payload: Dict[str, Any] = {}
        if url is not None:
            payload["url"] = url
        if events is not None:
            payload["events"] = events
        if description is not None:
            payload["description"] = description
        if active is not None:
            payload["active"] = active
        body = self._t.request("PATCH", f"/v1/webhooks/{id}", json=payload)
        return WebhookEndpoint.model_validate(body)

    def delete(self, id: str) -> None:
        self._t.request("DELETE", f"/v1/webhooks/{id}")

    def rotate_secret(self, id: str) -> WebhookEndpointWithSecret:
        body = self._t.request("POST", f"/v1/webhooks/{id}/rotate-secret")
        return WebhookEndpointWithSecret.model_validate(body)

    def test(self, id: str) -> None:
        self._t.request("POST", f"/v1/webhooks/{id}/test")

    def replay(self, webhook_id: str, delivery_id: str) -> None:
        self._t.request("POST", f"/v1/webhooks/{webhook_id}/deliveries/{delivery_id}/replay")

    @staticmethod
    def verify_signature(
        body: Union[bytes, str],
        header: str,
        secret: str,
        *,
        tolerance: int = 300,
    ) -> None:
        _verify_signature(body, header, secret, tolerance=tolerance)


class _AccountSync:
    def __init__(self, transport: _SyncTransport) -> None:
        self._t = transport

    def retrieve(self) -> Account:
        body = self._t.request("GET", "/v1/account")
        return Account.model_validate(body)

    def get(self) -> Account:
        return self.retrieve()

    def usage(
        self,
        *,
        period: Optional[str] = None,
        group_by: str = "day",
        period_start: Optional[str] = None,
        period_end: Optional[str] = None,
    ) -> Usage:
        params: Dict[str, Any] = {"group_by": group_by}
        if period:
            params["period"] = period
        if period_start:
            params["period_start"] = period_start
        if period_end:
            params["period_end"] = period_end
        body = self._t.request("GET", "/v1/account/usage", params=params)
        return Usage.model_validate(body)


class _TokensSync:
    def __init__(self, transport: _SyncTransport) -> None:
        self._t = transport

    def list(self) -> List[Dict[str, Any]]:
        body = self._t.request("GET", "/v1/tokens")
        if isinstance(body, list):
            return body  # type: ignore[return-value]
        if isinstance(body, dict) and isinstance(body.get("data"), list):
            return body["data"]  # type: ignore[return-value]
        return []

    def create(self, name: str, *, environment: str = "live") -> Dict[str, Any]:
        body = self._t.request(
            "POST",
            "/v1/tokens",
            json={"name": name, "environment": environment},
        )
        return body  # type: ignore[return-value]

    def delete(self, id: str) -> None:
        self._t.request("DELETE", f"/v1/tokens/{id}")

    def rotate(self, id: str) -> Dict[str, Any]:
        body = self._t.request("POST", f"/v1/tokens/{id}/rotate")
        return body  # type: ignore[return-value]


class TuringVerify:
    """Synchronous client.

    All methods are thread-safe provided the underlying ``httpx.Client``
    is. Pass ``client=...`` to reuse an externally-managed httpx client
    (recommended in long-running services).
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        client: Optional[httpx.Client] = None,
    ) -> None:
        self._transport = _SyncTransport(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            client=client,
        )
        self.verifications = _VerificationsSync(self._transport)
        self.webhooks = _WebhooksSync(self._transport)
        self.account = _AccountSync(self._transport)
        self.tokens = _TokensSync(self._transport)

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> "TuringVerify":
        return self

    def __exit__(self, *a: Any) -> None:
        self.close()


# ─── Async resources ──────────────────────────────────────────────────


class _VerificationsAsync:
    def __init__(self, transport: _AsyncTransport) -> None:
        self._t = transport

    async def create(
        self,
        file: FileLike,
        *,
        filename: Optional[str] = None,
        mime_type: Optional[str] = None,
        document_type: Optional[str] = None,
        test_mode: bool = False,
        idempotency_key: Optional[str] = None,
    ) -> Verification:
        data = _read_file(file)
        resolved_filename = filename or getattr(file, "name", None) or "document"
        key = _auto_idempotency_key(idempotency_key)
        files = {"file": (resolved_filename, data, mime_type or "application/octet-stream")}
        form: Dict[str, Any] = {}
        if document_type:
            form["document_type"] = document_type
        if test_mode:
            form["test_mode"] = "true"
        headers = {"Idempotency-Key": key}
        body = await self._t.request(
            "POST",
            "/v1/verifications",
            files=files,
            data=form or None,
            headers=headers,
        )
        return Verification.model_validate(body)

    async def retrieve(self, id: str) -> Verification:
        body = await self._t.request("GET", f"/v1/verifications/{id}")
        return Verification.model_validate(body)

    async def list(
        self,
        *,
        limit: int = 20,
        cursor: Optional[str] = None,
        verdict: Optional[str] = None,
    ) -> Page[Verification]:
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["starting_after"] = cursor
        if verdict:
            params["verdict"] = verdict
        body = await self._t.request("GET", "/v1/verifications", params=params)
        raw_items = body.get("data", []) if isinstance(body, dict) else []
        return Page[Verification](
            data=[Verification.model_validate(i) for i in raw_items],
            has_more=bool(body.get("has_more", False)) if isinstance(body, dict) else False,
            next_cursor=body.get("next_cursor") if isinstance(body, dict) else None,
            object=body.get("object") if isinstance(body, dict) else None,
        )

    async def batch(
        self,
        files: Sequence[Tuple[FileLike, str]],
        *,
        test_mode: bool = False,
    ) -> BatchResult:
        import base64 as _b64

        documents = []
        for f, name in files:
            blob = _read_file(f)
            documents.append(
                {
                    "base64": _b64.b64encode(blob).decode("ascii"),
                    "content_type": "application/octet-stream",
                    "filename": name,
                }
            )
        payload = {"documents": documents}
        if test_mode:
            payload["test_mode"] = True  # type: ignore[assignment]
        body = await self._t.request("POST", "/v1/verifications/batch", json=payload)
        if not isinstance(body, dict):
            raise APIError("Unexpected batch response shape.")
        return BatchResult.model_validate(body)


class _WebhooksAsync:
    def __init__(self, transport: _AsyncTransport) -> None:
        self._t = transport

    async def create(
        self,
        url: str,
        events: List[str],
        *,
        description: Optional[str] = None,
    ) -> WebhookEndpointWithSecret:
        body = await self._t.request(
            "POST",
            "/v1/webhooks",
            json={"url": url, "events": events, "description": description},
        )
        return WebhookEndpointWithSecret.model_validate(body)

    async def list(
        self,
        *,
        event_types: Optional[List[str]] = None,
    ) -> List[WebhookEndpoint]:
        params: Dict[str, Any] = {}
        if event_types:
            params["event_types"] = ",".join(event_types)
        body = await self._t.request("GET", "/v1/webhooks", params=params or None)
        if isinstance(body, list):
            return [WebhookEndpoint.model_validate(i) for i in body]
        if isinstance(body, dict) and isinstance(body.get("data"), list):
            return [WebhookEndpoint.model_validate(i) for i in body["data"]]
        return []

    async def retrieve(self, id: str) -> WebhookEndpoint:
        body = await self._t.request("GET", f"/v1/webhooks/{id}")
        return WebhookEndpoint.model_validate(body)

    async def update(
        self,
        id: str,
        *,
        url: Optional[str] = None,
        events: Optional[List[str]] = None,
        description: Optional[str] = None,
        active: Optional[bool] = None,
    ) -> WebhookEndpoint:
        payload: Dict[str, Any] = {}
        if url is not None:
            payload["url"] = url
        if events is not None:
            payload["events"] = events
        if description is not None:
            payload["description"] = description
        if active is not None:
            payload["active"] = active
        body = await self._t.request("PATCH", f"/v1/webhooks/{id}", json=payload)
        return WebhookEndpoint.model_validate(body)

    async def delete(self, id: str) -> None:
        await self._t.request("DELETE", f"/v1/webhooks/{id}")

    async def rotate_secret(self, id: str) -> WebhookEndpointWithSecret:
        body = await self._t.request("POST", f"/v1/webhooks/{id}/rotate-secret")
        return WebhookEndpointWithSecret.model_validate(body)

    async def test(self, id: str) -> None:
        await self._t.request("POST", f"/v1/webhooks/{id}/test")

    async def replay(self, webhook_id: str, delivery_id: str) -> None:
        await self._t.request("POST", f"/v1/webhooks/{webhook_id}/deliveries/{delivery_id}/replay")

    @staticmethod
    def verify_signature(
        body: Union[bytes, str],
        header: str,
        secret: str,
        *,
        tolerance: int = 300,
    ) -> None:
        _verify_signature(body, header, secret, tolerance=tolerance)


class _AccountAsync:
    def __init__(self, transport: _AsyncTransport) -> None:
        self._t = transport

    async def retrieve(self) -> Account:
        body = await self._t.request("GET", "/v1/account")
        return Account.model_validate(body)

    async def get(self) -> Account:
        return await self.retrieve()

    async def usage(
        self,
        *,
        period: Optional[str] = None,
        group_by: str = "day",
        period_start: Optional[str] = None,
        period_end: Optional[str] = None,
    ) -> Usage:
        params: Dict[str, Any] = {"group_by": group_by}
        if period:
            params["period"] = period
        if period_start:
            params["period_start"] = period_start
        if period_end:
            params["period_end"] = period_end
        body = await self._t.request("GET", "/v1/account/usage", params=params)
        return Usage.model_validate(body)


class _TokensAsync:
    def __init__(self, transport: _AsyncTransport) -> None:
        self._t = transport

    async def list(self) -> List[Dict[str, Any]]:
        body = await self._t.request("GET", "/v1/tokens")
        if isinstance(body, list):
            return body  # type: ignore[return-value]
        if isinstance(body, dict) and isinstance(body.get("data"), list):
            return body["data"]  # type: ignore[return-value]
        return []

    async def create(self, name: str, *, environment: str = "live") -> Dict[str, Any]:
        body = await self._t.request(
            "POST",
            "/v1/tokens",
            json={"name": name, "environment": environment},
        )
        return body  # type: ignore[return-value]

    async def delete(self, id: str) -> None:
        await self._t.request("DELETE", f"/v1/tokens/{id}")

    async def rotate(self, id: str) -> Dict[str, Any]:
        body = await self._t.request("POST", f"/v1/tokens/{id}/rotate")
        return body  # type: ignore[return-value]


class AsyncTuringVerify:
    """Asynchronous client — mirrors :class:`TuringVerify`."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        self._transport = _AsyncTransport(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            client=client,
        )
        self.verifications = _VerificationsAsync(self._transport)
        self.webhooks = _WebhooksAsync(self._transport)
        self.account = _AccountAsync(self._transport)
        self.tokens = _TokensAsync(self._transport)

    async def aclose(self) -> None:
        await self._transport.aclose()

    async def __aenter__(self) -> "AsyncTuringVerify":
        return self

    async def __aexit__(self, *a: Any) -> None:
        await self.aclose()


__all__ = ["TuringVerify", "AsyncTuringVerify"]
