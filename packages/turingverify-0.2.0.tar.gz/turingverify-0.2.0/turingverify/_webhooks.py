"""HMAC-SHA256 webhook signature verification.

Mirrors the scheme implemented in
``backend/app/webhook_delivery_engine.py``::

    X-TuringVerify-Signature: t=<unix_ts>,v1=<hex_digest>

Where the digest is ``HMAC-SHA256(secret, f"{ts}.{body}")``.
"""

from __future__ import annotations

import hashlib
import hmac
import time
from typing import Mapping, Union

from turingverify._errors import SignatureVerificationError


DEFAULT_TOLERANCE_SECONDS = 300
# Starlette / some Flask configs use the header name without the X- prefix.
_SIGNATURE_HEADERS = ("x-turingverify-signature", "turingverify-signature")


def _parse_header(header: str) -> Mapping[str, str]:
    """Turn ``t=<ts>,v1=<hex>[,v1=<alt>]`` into a dict.

    Multiple ``v1=`` entries are supported during secret rotation — we
    treat them as a list but return only the first for simplicity; the
    caller can compare via ``hmac.compare_digest`` in a loop if needed.
    """
    out: dict[str, str] = {}
    for part in header.split(","):
        part = part.strip()
        if "=" not in part:
            continue
        k, v = part.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def _coerce_body(body: Union[bytes, str]) -> bytes:
    if isinstance(body, str):
        return body.encode("utf-8")
    return body


def verify_signature(
    body: Union[bytes, str],
    header: str,
    secret: str,
    *,
    tolerance: int = DEFAULT_TOLERANCE_SECONDS,
    _now: Union[float, None] = None,
) -> None:
    """Verify a webhook signature or raise ``SignatureVerificationError``.

    Parameters
    ----------
    body
        The *raw* request body (bytes preferred — frameworks often re-parse
        JSON and mutate whitespace, which would break HMAC).
    header
        The ``X-TuringVerify-Signature`` header value.
    secret
        The endpoint's raw signing secret (``whsec_...``).
    tolerance
        Maximum age of the signature in seconds. Defaults to 300s, matching
        the server's production clock-skew allowance.
    """
    if not header:
        raise SignatureVerificationError("Missing signature header.")
    if not secret:
        raise SignatureVerificationError("Missing webhook secret.")

    parsed = _parse_header(header)
    ts_raw = parsed.get("t")
    sig_hex = parsed.get("v1")
    if not ts_raw or not sig_hex:
        raise SignatureVerificationError(
            "Signature header missing 't=' or 'v1=' segment."
        )
    try:
        ts = int(ts_raw)
    except ValueError as exc:
        raise SignatureVerificationError("Signature timestamp is not an integer.") from exc

    now = _now if _now is not None else time.time()
    if tolerance > 0 and abs(now - ts) > tolerance:
        raise SignatureVerificationError(
            f"Signature timestamp is outside the {tolerance}s tolerance window."
        )

    body_bytes = _coerce_body(body)
    payload = f"{ts}.".encode("utf-8") + body_bytes
    expected = hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()
    # Support comma-separated multi-sig (rotation window) — header may
    # contain multiple v1= entries joined by ',' that parse_header
    # collapses to the last. Fall back to searching the raw header too.
    signatures = [
        part.split("=", 1)[1].strip()
        for part in header.split(",")
        if part.strip().startswith("v1=")
    ]
    for cand in signatures or [sig_hex]:
        if hmac.compare_digest(expected, cand):
            return
    raise SignatureVerificationError("Signature does not match expected value.")


__all__ = ["verify_signature", "SignatureVerificationError", "DEFAULT_TOLERANCE_SECONDS"]
