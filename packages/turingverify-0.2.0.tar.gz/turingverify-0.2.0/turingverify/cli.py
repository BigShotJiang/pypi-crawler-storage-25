"""``turingverify`` command-line tool.

Installed as a console_script via pyproject::

    turingverify verify diploma.pdf
    turingverify tokens list
    turingverify tokens create --name ci --env live
    turingverify webhooks list
    turingverify webhooks send-test whk_123

``TURING_VERIFY_API_KEY`` (or ``--api-key``) supplies the bearer token.
Session-authed endpoints (tokens.create, webhooks.send-test) reuse the
same bearer — the server infers the account from the token's user_id.

Pass ``--json`` to get machine-readable output; the default is a tidy
human format.
"""

from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sys
from typing import Any, Optional

from turingverify import TuringVerify, TuringVerifyError
from turingverify._version import __version__


DEFAULT_BASE_URL = os.environ.get(
    "TURING_VERIFY_BASE_URL", "https://api.verify.turingcerts.com"
)


def _client(api_key: Optional[str], base_url: str) -> TuringVerify:
    key = api_key or os.environ.get("TURING_VERIFY_API_KEY")
    if not key:
        print(
            "error: no API key supplied. Set TURING_VERIFY_API_KEY or pass --api-key.",
            file=sys.stderr,
        )
        raise SystemExit(2)
    return TuringVerify(api_key=key, base_url=base_url)


def _dump(obj: Any, as_json: bool) -> str:
    if as_json:
        if hasattr(obj, "model_dump"):
            return json.dumps(obj.model_dump(), indent=2, default=str)
        return json.dumps(obj, indent=2, default=str)
    if hasattr(obj, "model_dump"):
        d = obj.model_dump()
        return "\n".join(f"{k}: {v}" for k, v in d.items())
    if isinstance(obj, list):
        lines = []
        for i, item in enumerate(obj):
            lines.append(f"[{i}]")
            if hasattr(item, "model_dump"):
                for k, v in item.model_dump().items():
                    lines.append(f"  {k}: {v}")
            else:
                lines.append(f"  {item}")
        return "\n".join(lines)
    return str(obj)


def _cmd_verify(args: argparse.Namespace) -> int:
    client = _client(args.api_key, args.base_url)
    path = args.file
    if not os.path.isfile(path):
        print(f"error: file not found: {path}", file=sys.stderr)
        return 2
    mime, _ = mimetypes.guess_type(path)
    with open(path, "rb") as f:
        ver = client.verifications.create(
            file=f,
            filename=os.path.basename(path),
            mime_type=mime,
            test_mode=args.test_mode,
        )
    print(_dump(ver, args.json))
    return 0


def _cmd_tokens_list(args: argparse.Namespace) -> int:
    # The /v1/tokens surface is session-authed — but the SDK's api_key
    # path still carries a bearer, which the server accepts at the
    # session-cookie layer when it includes an admin/session cookie.
    # For the Phase 5 CLI we hit the /v1 transport; unsupported by
    # bearer auth → explain and bail gracefully.
    client = _client(args.api_key, args.base_url)
    try:
        body = client._transport.request("GET", "/v1/tokens")  # noqa: SLF001
    except TuringVerifyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(_dump(body, args.json))
    return 0


def _cmd_tokens_create(args: argparse.Namespace) -> int:
    client = _client(args.api_key, args.base_url)
    payload = {"name": args.name, "environment": args.env}
    if args.scopes:
        payload["scopes"] = args.scopes.split(",")
    try:
        body = client._transport.request("POST", "/v1/tokens", json=payload)  # noqa: SLF001
    except TuringVerifyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(_dump(body, args.json))
    return 0


def _cmd_webhooks_list(args: argparse.Namespace) -> int:
    client = _client(args.api_key, args.base_url)
    try:
        items = client.webhooks.list()
    except TuringVerifyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(_dump(items, args.json))
    return 0


def _cmd_webhooks_send_test(args: argparse.Namespace) -> int:
    client = _client(args.api_key, args.base_url)
    try:
        body = client._transport.request(  # noqa: SLF001
            "POST", f"/v1/webhooks/{args.id}/test"
        )
    except TuringVerifyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(_dump(body, args.json))
    return 0


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="turingverify",
        description="Turing Verify command-line interface.",
    )
    p.add_argument("--api-key", help="Bearer token (defaults to $TURING_VERIFY_API_KEY).")
    p.add_argument("--base-url", default=DEFAULT_BASE_URL)
    p.add_argument("--json", action="store_true", help="Machine-readable output.")
    p.add_argument("--version", action="version", version=f"turingverify {__version__}")

    sub = p.add_subparsers(dest="command", required=True)

    verify = sub.add_parser("verify", help="Submit a document for verification.")
    verify.add_argument("file", help="Path to the document.")
    verify.add_argument(
        "--test-mode", action="store_true", help="Force test mode (tv_test_sk_ token)."
    )
    verify.set_defaults(func=_cmd_verify)

    tokens = sub.add_parser("tokens", help="Manage API tokens.")
    tok_sub = tokens.add_subparsers(dest="subcommand", required=True)
    tok_ls = tok_sub.add_parser("list", help="List your tokens.")
    tok_ls.set_defaults(func=_cmd_tokens_list)
    tok_new = tok_sub.add_parser("create", help="Create a new token.")
    tok_new.add_argument("--name", required=True)
    tok_new.add_argument("--env", choices=("live", "test"), default="live")
    tok_new.add_argument("--scopes", help="Comma-separated scopes.")
    tok_new.set_defaults(func=_cmd_tokens_create)

    hooks = sub.add_parser("webhooks", help="Manage webhook endpoints.")
    hk_sub = hooks.add_subparsers(dest="subcommand", required=True)
    hk_ls = hk_sub.add_parser("list", help="List endpoints.")
    hk_ls.set_defaults(func=_cmd_webhooks_list)
    hk_test = hk_sub.add_parser("send-test", help="Fire a synthetic ping.")
    hk_test.add_argument("id", help="Endpoint id (whk_...).")
    hk_test.set_defaults(func=_cmd_webhooks_send_test)

    return p


def main(argv: Optional[list[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
