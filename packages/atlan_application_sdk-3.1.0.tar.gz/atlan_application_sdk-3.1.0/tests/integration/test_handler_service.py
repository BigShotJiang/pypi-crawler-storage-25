"""G6: Integration tests for the Handler HTTP layer.

Verifies the handler service works end-to-end with real (in-memory)
infrastructure, local obstore for file uploads, and a real Temporal dev
server for workflow lifecycle endpoints.

Requires a running Temporal dev server (see conftest.py).
"""

import asyncio
from uuid import UUID

import httpx
import pytest

from application_sdk.app.base import App
from application_sdk.app.task import task
from application_sdk.contracts.base import Input, Output
from application_sdk.handler.base import DefaultHandler, Handler, HandlerError
from application_sdk.handler.contracts import (
    AuthInput,
    AuthOutput,
    AuthStatus,
    MetadataInput,
    MetadataOutput,
    PreflightInput,
    PreflightOutput,
    PreflightStatus,
)

# ---------------------------------------------------------------------------
# Global reset fixture
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_service_globals():
    """Reset handler service module globals and infrastructure context before/after each test."""
    from application_sdk.handler import service as svc
    from application_sdk.infrastructure.context import _infrastructure_ctx

    svc._temporal_client = None
    svc._workflow_config = svc.WorkflowClientConfig()
    svc._secret_store = None
    svc._storage = None
    _infrastructure_ctx.set(None)

    yield

    svc._temporal_client = None
    svc._workflow_config = svc.WorkflowClientConfig()
    svc._secret_store = None
    svc._storage = None
    _infrastructure_ctx.set(None)


# ---------------------------------------------------------------------------
# Infrastructure fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_infra():
    """Set up mock infrastructure with seeded secret store."""
    from application_sdk.infrastructure.context import (
        InfrastructureContext,
        set_infrastructure,
    )
    from application_sdk.testing.mocks import MockSecretStore, MockStateStore

    state = MockStateStore()
    secrets = MockSecretStore(secrets={"my-secret": "secret-value-abc"})
    set_infrastructure(InfrastructureContext(state_store=state, secret_store=secrets))
    yield state, secrets


# ---------------------------------------------------------------------------
# Handler Context & Infrastructure (tests 1–4)
# ---------------------------------------------------------------------------


class _ContextCapturingHandler(Handler):
    """Handler that records context details during test_auth."""

    def __init__(self) -> None:
        self.captured_app_name: str = ""
        self.captured_request_ids: list[UUID] = []
        self.captured_credential: str | None = None
        self.captured_secret: str | None = None

    async def test_auth(self, input: AuthInput) -> AuthOutput:
        ctx = self.context
        self.captured_app_name = ctx.app_name
        self.captured_request_ids.append(ctx.request_id)
        self.captured_credential = ctx.get_credential("api_key")
        if ctx._secret_store is not None:
            self.captured_secret = await ctx.get_secret("my-secret")
        return AuthOutput(status=AuthStatus.SUCCESS)

    async def preflight_check(self, input: PreflightInput) -> PreflightOutput:
        return PreflightOutput(status=PreflightStatus.READY)

    async def fetch_metadata(self, input: MetadataInput) -> MetadataOutput:
        return MetadataOutput(objects=[], total_count=0)


class _ErrorHandler(Handler):
    """Handler that raises HandlerError with a custom http_status."""

    async def test_auth(self, input: AuthInput) -> AuthOutput:
        raise HandlerError("forbidden", http_status=403)

    async def preflight_check(self, input: PreflightInput) -> PreflightOutput:
        return PreflightOutput(status=PreflightStatus.READY)

    async def fetch_metadata(self, input: MetadataInput) -> MetadataOutput:
        return MetadataOutput(objects=[], total_count=0)


@pytest.fixture
def context_handler():
    """Create a handler service with the context-capturing handler."""
    from application_sdk.handler.service import create_app_handler_service

    handler = _ContextCapturingHandler()
    app = create_app_handler_service(handler, app_name="ctx-test-app")
    return app, handler


@pytest.fixture
def context_handler_with_secrets(mock_infra):
    """Create a handler service with secret_store passed directly (not via ContextVar)."""
    from application_sdk.handler.service import create_app_handler_service

    _, secrets = mock_infra
    handler = _ContextCapturingHandler()
    app = create_app_handler_service(
        handler, app_name="ctx-test-app", secret_store=secrets
    )
    return app, handler


@pytest.fixture
async def context_client(context_handler):
    app, handler = context_handler
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as c:
        yield c, handler


@pytest.fixture
async def context_client_with_secrets(context_handler_with_secrets):
    app, handler = context_handler_with_secrets
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as c:
        yield c, handler


@pytest.mark.integration
async def test_handler_context_wiring(context_client):
    """G6.1: HandlerContext has correct app_name, UUID request_id, and credentials."""
    client, handler = context_client

    resp = await client.post(
        "/workflows/v1/auth",
        json={"credentials": [{"key": "api_key", "value": "secret123"}]},
    )

    assert resp.status_code == 200
    assert handler.captured_app_name == "ctx-test-app"
    assert len(handler.captured_request_ids) == 1
    # Verify it's a valid UUID
    UUID(str(handler.captured_request_ids[0]))
    assert handler.captured_credential == "secret123"


@pytest.mark.integration
async def test_handler_context_secret_store_access(context_client_with_secrets):
    """G6.2: HandlerContext.get_secret() reads from secret_store passed directly to create_app_handler_service."""
    client, handler = context_client_with_secrets

    resp = await client.post(
        "/workflows/v1/auth",
        json={"credentials": []},
    )

    assert resp.status_code == 200
    assert handler.captured_secret == "secret-value-abc"


@pytest.mark.integration
async def test_handler_context_cleanup_between_requests(context_client):
    """G6.3: Each request gets an independent request_id; _context is None between requests."""
    client, handler = context_client

    body = {"credentials": []}
    resp1 = await client.post("/workflows/v1/auth", json=body)
    assert resp1.status_code == 200
    # After the first request, context should be cleared
    assert handler._context is None

    resp2 = await client.post("/workflows/v1/auth", json=body)
    assert resp2.status_code == 200
    assert handler._context is None

    # Each request got a distinct request_id
    assert len(handler.captured_request_ids) == 2
    assert handler.captured_request_ids[0] != handler.captured_request_ids[1]


@pytest.mark.integration
async def test_handler_error_custom_http_status():
    """G6.4: HandlerError with http_status=403 returns HTTP 403 (not 500)."""
    from application_sdk.handler.service import create_app_handler_service

    error_handler = _ErrorHandler()
    app = create_app_handler_service(error_handler, app_name="error-app")

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post("/workflows/v1/auth", json={"credentials": []})

    assert resp.status_code == 403


# ---------------------------------------------------------------------------
# Config & File Upload (tests 5–7)
# ---------------------------------------------------------------------------


@pytest.fixture
def config_app(tmp_path):
    """Create a handler service backed by a local object store for config."""
    from application_sdk.handler.service import create_app_handler_service
    from application_sdk.storage.factory import create_local_store

    store = create_local_store(tmp_path / "config-store")
    handler = DefaultHandler()
    app = create_app_handler_service(handler, app_name="config-app", storage=store)
    return app, store


@pytest.fixture
async def config_client(config_app):
    app, store = config_app
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as c:
        yield c, store


@pytest.mark.integration
async def test_config_round_trip(config_client):
    """G6.5: POST /config/{id} saves to object store; GET /config/{id} returns it."""
    client, store = config_client

    payload = {"host": "db.example.com", "port": 5432, "database": "mydb"}

    post_resp = await client.post("/workflows/v1/config/test-cfg", json=payload)
    assert post_resp.status_code == 200

    get_resp = await client.get("/workflows/v1/config/test-cfg")
    assert get_resp.status_code == 200
    data = get_resp.json()["data"]
    assert data["host"] == "db.example.com"
    assert data["port"] == 5432


@pytest.mark.integration
async def test_config_not_found(config_client):
    """G6.6: GET /config/{id} returns 404 when key is not in object store."""
    client, _ = config_client

    resp = await client.get("/workflows/v1/config/nonexistent")
    assert resp.status_code == 404


@pytest.mark.integration
async def test_file_upload_end_to_end(tmp_path):
    """G6.7: POST /file uploads a file to local obstore and returns FileUploadResponse shape."""
    from application_sdk.handler.service import create_app_handler_service
    from application_sdk.storage.factory import create_local_store
    from application_sdk.storage.ops import exists

    store = create_local_store(tmp_path / "uploads")
    handler = DefaultHandler()
    app = create_app_handler_service(handler, app_name="upload-app", storage=store)

    file_content = b"hello, integration test!"
    file_name = "test_data.txt"

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/workflows/v1/file",
            files={"file": (file_name, file_content, "text/plain")},
        )

    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True

    data = body["data"]
    assert data["isUploaded"] is True
    assert data["fileSize"] == len(file_content)
    assert data["rawName"] == file_name
    assert data["extension"] == "txt"
    key = data["key"]
    assert key  # non-empty

    # Verify the file actually exists in the local store
    assert await exists(key, store=store, normalize=False)


# ---------------------------------------------------------------------------
# Workflow Lifecycle via HTTP (tests 8–11)
# ---------------------------------------------------------------------------
# These App/Input/Output classes must live at module level so Temporal's
# sandboxed workflow runner can import them by module path.  They are
# registered in AppRegistry/TaskRegistry at import time; clean_registries
# (autouse) resets both registries before each test, so fixtures call
# _reregister_app() to restore the entries before spinning up a worker.


class TrivialInput(Input):
    name: str = "world"


class TrivialOutput(Output):
    greeting: str = ""


class TrivialApp(App):
    async def run(self, input: TrivialInput) -> TrivialOutput:
        return TrivialOutput(greeting=f"Hello, {input.name}!")


class CredentialAwareInput(Input):
    """Input for G6.12: carries credential_guid so we can verify it reaches Temporal."""

    name: str = "world"
    credential_guid: str = ""


class CredentialAwareApp(App):
    async def run(self, input: CredentialAwareInput) -> TrivialOutput:
        return TrivialOutput(greeting=f"Hello, {input.name}!")


class LongInput(Input):
    pass


class LongOutput(Output):
    done: bool = False


class LongRunningApp(App):
    @task(heartbeat_timeout_seconds=None, auto_heartbeat_seconds=None)
    async def long_sleep(self, input: LongInput) -> LongOutput:
        await asyncio.sleep(60)
        return LongOutput(done=True)

    async def run(self, input: LongInput) -> LongOutput:
        return await self.long_sleep(input)


@pytest.fixture
async def trivial_workflow_app(temporal_client, task_queue, reregister_app):
    """Handler service configured with TrivialApp for workflow lifecycle tests."""
    from application_sdk.handler import service as svc
    from application_sdk.handler.service import create_app_handler_service

    reregister_app(TrivialApp)

    handler = DefaultHandler()
    app = create_app_handler_service(
        handler,
        app_name="trivial",
        app_class=TrivialApp,
        temporal_host="localhost:7233",
        task_queue=task_queue,
    )
    # Inject the already-connected client to avoid a second connection
    svc._temporal_client = temporal_client

    return app, TrivialApp


@pytest.fixture
async def trivial_wf_client(trivial_workflow_app):
    app, app_cls = trivial_workflow_app
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as c:
        yield c, app_cls


@pytest.fixture
async def long_running_workflow_app(temporal_client, task_queue, reregister_app):
    """Handler service configured with LongRunningApp for the stop test."""
    from application_sdk.handler import service as svc
    from application_sdk.handler.service import create_app_handler_service

    reregister_app(LongRunningApp)

    handler = DefaultHandler()
    app = create_app_handler_service(
        handler,
        app_name="long-running",
        app_class=LongRunningApp,
        temporal_host="localhost:7233",
        task_queue=task_queue,
    )
    svc._temporal_client = temporal_client

    return app


@pytest.mark.integration
async def test_start_workflow_via_http(run_worker, trivial_wf_client):
    """G6.8: POST /start returns workflow_id and run_id."""
    client, _ = trivial_wf_client

    async with run_worker():
        resp = await client.post("/workflows/v1/start", json={"name": "integration"})

    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    data = body["data"]
    assert "workflow_id" in data
    assert "run_id" in data
    assert data["workflow_id"]
    assert data["run_id"]


@pytest.mark.integration
async def test_start_and_get_result(run_worker, trivial_wf_client):
    """G6.9: Start workflow then GET /result with wait=true returns completed status."""
    client, _ = trivial_wf_client

    async with run_worker():
        start_resp = await client.post(
            "/workflows/v1/start", json={"name": "result-test"}
        )
        assert start_resp.status_code == 200
        wf_id = start_resp.json()["data"]["workflow_id"]

        result_resp = await client.get(
            f"/workflows/v1/result/{wf_id}", params={"wait": "true"}
        )

    assert result_resp.status_code == 200
    result_body = result_resp.json()
    assert result_body["success"] is True
    assert result_body["data"]["status"] == "completed"
    assert result_body["data"]["result"]["greeting"] == "Hello, result-test!"


@pytest.mark.integration
async def test_start_and_stop(run_worker, long_running_workflow_app):
    """G6.10: Start a long-running workflow, stop it, verify TERMINATED status."""
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=long_running_workflow_app),
        base_url="http://test",
    ) as client:
        async with run_worker():
            start_resp = await client.post("/workflows/v1/start", json={})
            assert start_resp.status_code == 200
            wf_id = start_resp.json()["data"]["workflow_id"]
            run_id = start_resp.json()["data"]["run_id"]

            # Poll until RUNNING to avoid race with terminate
            for _ in range(20):
                status_resp = await client.get(f"/workflows/v1/status/{wf_id}/{run_id}")
                if status_resp.json().get("data", {}).get("status") == "RUNNING":
                    break
                await asyncio.sleep(0.25)

            stop_resp = await client.post(f"/workflows/v1/stop/{wf_id}/{run_id}")
            assert stop_resp.status_code == 200
            assert stop_resp.json()["success"] is True

        # Check status after worker shuts down
        final_resp = await client.get(f"/workflows/v1/status/{wf_id}/{run_id}")
        assert final_resp.status_code == 200
        assert final_resp.json()["data"]["status"] == "TERMINATED"


@pytest.fixture
async def credential_wf_client(temporal_client, task_queue, reregister_app):
    """Handler service configured with CredentialAwareApp for credential stripping tests."""
    from application_sdk.handler import service as svc
    from application_sdk.handler.service import create_app_handler_service

    reregister_app(CredentialAwareApp)

    handler = DefaultHandler()
    app = create_app_handler_service(
        handler,
        app_name="cred-aware",
        app_class=CredentialAwareApp,
        temporal_host="localhost:7233",
        task_queue=task_queue,
    )
    svc._temporal_client = temporal_client

    return app


@pytest.mark.integration
async def test_start_strips_inline_credentials(
    run_worker, credential_wf_client, temporal_client
):
    """G6.12: POST /start with inline credentials strips them from the body
    before dispatching to Temporal.

    Verifies:
    - credentials are NOT present in the Temporal start event payload
    - the workflow starts successfully despite credentials being stripped
    """

    app = credential_wf_client

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        async with run_worker():
            resp = await client.post(
                "/workflows/v1/start",
                json={
                    "name": "cred-test",
                    "credentials": [{"key": "password", "value": "s3cr3t"}],
                },
            )

    assert resp.status_code == 200
    wf_id = resp.json()["data"]["workflow_id"]
    assert wf_id

    # Confirm the Temporal workflow start event does not carry raw credentials.
    handle = temporal_client.get_workflow_handle(wf_id)
    history = await handle.fetch_history()
    start_payload_data = b"".join(
        p.data
        for p in history.events[
            0
        ].workflow_execution_started_event_attributes.input.payloads
    )
    assert b'"credentials"' not in start_payload_data


# ---------------------------------------------------------------------------
# Prometheus /metrics endpoint
# ---------------------------------------------------------------------------


@pytest.mark.integration
async def test_prometheus_metrics_endpoint():
    """G6.13: GET /metrics returns Prometheus exposition format with HTTP metrics."""
    from unittest import mock

    from application_sdk.handler.service import create_app_handler_service

    handler = DefaultHandler()
    with mock.patch("application_sdk.handler.service.ENABLE_PROMETHEUS_METRICS", True):
        app = create_app_handler_service(handler, app_name="prom-test-app")

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        # Verify /metrics endpoint exists and returns 200
        resp = await client.get("/metrics")
        assert resp.status_code == 200
        assert "text/plain" in resp.headers["content-type"]

        body = resp.text
        # Should contain standard prometheus_client metrics
        assert "python_info" in body


@pytest.mark.integration
async def test_prometheus_metrics_not_exposed_when_disabled():
    """G6.14: GET /metrics returns 404 when Prometheus is disabled."""
    from unittest import mock

    from application_sdk.handler.service import create_app_handler_service

    handler = DefaultHandler()
    with mock.patch("application_sdk.handler.service.ENABLE_PROMETHEUS_METRICS", False):
        app = create_app_handler_service(handler, app_name="no-prom-app")

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        resp = await client.get("/metrics")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# G6.15–G6.17: Multi-entry-point HTTP routing
# ---------------------------------------------------------------------------
# App/Input/Output at module level so Temporal's sandboxed runner can import
# them.  Routing validation (workflow_type checks) fires before the Temporal
# call, so G6.16 and G6.17 don't require a running worker.

from application_sdk.app.entrypoint import entrypoint  # noqa: E402


class RouteAInput(Input):
    value: int = 0


class RouteAOutput(Output):
    doubled: int = 0


class RouteBInput(Input):
    value: int = 0


class RouteBOutput(Output):
    tripled: int = 0


class MultiRouteApp(App):
    @entrypoint
    async def route_a(self, input: RouteAInput) -> RouteAOutput:
        return RouteAOutput(doubled=input.value * 2)

    @entrypoint
    async def route_b(self, input: RouteBInput) -> RouteBOutput:
        return RouteBOutput(tripled=input.value * 3)


@pytest.fixture
async def multi_route_wf_client(temporal_client, task_queue, reregister_app):
    """Handler service configured with MultiRouteApp for multi-EP routing tests."""
    from application_sdk.handler import service as svc
    from application_sdk.handler.service import create_app_handler_service

    reregister_app(MultiRouteApp)

    handler = DefaultHandler()
    app = create_app_handler_service(
        handler,
        app_name="multi-route",
        app_class=MultiRouteApp,
        temporal_host="localhost:7233",
        task_queue=task_queue,
    )
    svc._temporal_client = temporal_client

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as c:
        yield c


@pytest.mark.integration
async def test_multi_ep_http_routes_correctly(run_worker, multi_route_wf_client):
    """G6.15: POST /start with workflow_type dispatches to the correct @entrypoint."""
    client = multi_route_wf_client

    async with run_worker():
        resp = await client.post(
            "/workflows/v1/start",
            json={"workflow_type": "route-a", "value": 7},
        )

    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert body["data"]["workflow_id"]


@pytest.mark.integration
async def test_multi_ep_missing_workflow_type_returns_400(multi_route_wf_client):
    """G6.16: POST /start without workflow_type on a multi-EP app returns HTTP 400."""
    client = multi_route_wf_client

    resp = await client.post("/workflows/v1/start", json={"value": 1})

    assert resp.status_code == 400


@pytest.mark.integration
async def test_multi_ep_invalid_workflow_type_returns_400(multi_route_wf_client):
    """G6.17: POST /start with an unknown workflow_type returns HTTP 400."""
    client = multi_route_wf_client

    resp = await client.post(
        "/workflows/v1/start",
        json={"workflow_type": "nonexistent-ep", "value": 1},
    )

    assert resp.status_code == 400
