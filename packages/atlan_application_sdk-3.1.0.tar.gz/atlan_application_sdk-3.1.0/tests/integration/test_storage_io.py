"""Integration tests for storage.ops and io/ module working together.

Verifies the full flow: upload → list → download_prefix (concurrent)
using a real local obstore (no mocks, no Temporal).
"""

from __future__ import annotations

import pytest

import application_sdk.constants as constants
from application_sdk.storage.batch import (
    delete_prefix,
    download_prefix,
    list_keys,
    upload_file_from_bytes,
    upload_prefix,
)
from application_sdk.storage.factory import create_local_store
from application_sdk.storage.ops import download_file, upload_file


@pytest.fixture
def store(tmp_path):
    """Create a real local object store backed by a temp directory."""
    return create_local_store(tmp_path / "store")


@pytest.fixture
def staging(tmp_path, monkeypatch):
    """Create a staging directory and set TEMPORARY_PATH to it."""
    staging_dir = tmp_path / "staging"
    staging_dir.mkdir()
    monkeypatch.setenv("ATLAN_TEMPORARY_PATH", str(staging_dir))
    monkeypatch.setattr(constants, "TEMPORARY_PATH", str(staging_dir))
    return staging_dir


# ------------------------------------------------------------------
# Upload + download roundtrip
# ------------------------------------------------------------------


@pytest.mark.integration
async def test_upload_download_roundtrip(store, tmp_path):
    """Upload a file, download it back, verify contents match."""
    src = tmp_path / "input.txt"
    src.write_text("hello integration test")

    sha = await upload_file("roundtrip/input.txt", src, store)
    assert len(sha) == 64

    dest = tmp_path / "output.txt"
    dl_sha = await download_file("roundtrip/input.txt", dest, store, compute_hash=True)
    assert dest.read_text() == "hello integration test"
    assert dl_sha == sha


# ------------------------------------------------------------------
# upload_file retain_local_copy
# ------------------------------------------------------------------


@pytest.mark.integration
async def test_upload_retain_local_copy_false_deletes_file(store, staging):
    """Upload with retain_local_copy=False should delete the local file."""
    src = staging / "ephemeral.txt"
    src.write_text("delete me after upload")

    await upload_file("retain/ephemeral.txt", src, store, retain_local_copy=False)
    assert not src.exists(), "File should be deleted after upload"

    # Verify the file was actually uploaded
    assert await list_keys("retain", store) == ["retain/ephemeral.txt"]


@pytest.mark.integration
async def test_upload_retain_local_copy_true_keeps_file(store, staging):
    """Upload with retain_local_copy=True (default) should keep the local file."""
    src = staging / "persistent.txt"
    src.write_text("keep me")

    await upload_file("retain/persistent.txt", src, store, retain_local_copy=True)
    assert src.exists(), "File should still exist after upload"


# ------------------------------------------------------------------
# download_prefix (concurrent)
# ------------------------------------------------------------------


@pytest.mark.integration
async def test_download_prefix_concurrent_roundtrip(store, tmp_path):
    """Upload multiple files, download_prefix them concurrently, verify all."""
    file_count = 12
    for i in range(file_count):
        src = tmp_path / f"src_{i}.parquet"
        src.write_bytes(f"data-{i}".encode())
        await upload_file(f"batch/file_{i}.parquet", src, store)

    # Also upload a non-parquet file to test suffix filtering
    meta = tmp_path / "meta.json"
    meta.write_text("{}")
    await upload_file("batch/meta.json", meta, store)

    dest = tmp_path / "downloaded"
    paths = await download_prefix(
        "batch", dest, store, suffix=".parquet", max_concurrency=3
    )

    assert len(paths) == file_count
    for i in range(file_count):
        downloaded = dest / f"batch/file_{i}.parquet"
        assert downloaded.exists()
        assert downloaded.read_bytes() == f"data-{i}".encode()


@pytest.mark.integration
async def test_download_prefix_empty_prefix(store, tmp_path):
    """download_prefix with no matching keys returns empty list."""
    paths = await download_prefix("nonexistent", tmp_path, store)
    assert paths == []


# ------------------------------------------------------------------
# list_keys with suffix filter
# ------------------------------------------------------------------


@pytest.mark.integration
async def test_list_keys_suffix_filter(store, tmp_path):
    """list_keys with suffix filters by file extension."""
    for name in ["a.parquet", "b.parquet", "c.json", "d.csv"]:
        src = tmp_path / name
        src.write_bytes(b"x")
        await upload_file(f"mixed/{name}", src, store)

    parquet = await list_keys("mixed", store, suffix=".parquet")
    assert len(parquet) == 2
    assert all(k.endswith(".parquet") for k in parquet)

    json_keys = await list_keys("mixed", store, suffix=".json")
    assert json_keys == ["mixed/c.json"]

    all_keys = await list_keys("mixed", store)
    assert len(all_keys) == 4


# ------------------------------------------------------------------
# upload_prefix (parallel directory upload)
# ------------------------------------------------------------------


@pytest.mark.integration
async def test_upload_prefix_roundtrip(store, tmp_path):
    """Upload a directory, list keys, download and verify."""
    src_dir = tmp_path / "upload_src"
    src_dir.mkdir()
    for i in range(5):
        (src_dir / f"file_{i}.txt").write_text(f"content-{i}")

    uploaded = await upload_prefix(local_dir=src_dir, prefix="batch/run1", store=store)
    assert len(uploaded) == 5

    keys = await list_keys("batch/run1", store)
    assert len(keys) == 5

    dest_dir = tmp_path / "download_dest"
    paths = await download_prefix("batch/run1", dest_dir, store)
    assert len(paths) == 5
    for i in range(5):
        downloaded = dest_dir / f"batch/run1/file_{i}.txt"
        assert downloaded.read_text() == f"content-{i}"


@pytest.mark.integration
async def test_upload_prefix_with_retain_local_false(store, staging):
    """Upload with retain_local_copy=False deletes source files."""
    src_dir = staging / "ephemeral_dir"
    src_dir.mkdir()
    (src_dir / "a.txt").write_text("aaa")
    (src_dir / "b.txt").write_text("bbb")

    await upload_prefix(
        local_dir=src_dir, prefix="ephemeral", store=store, retain_local_copy=False
    )

    # Local files should be deleted
    assert not (src_dir / "a.txt").exists()
    assert not (src_dir / "b.txt").exists()

    # But they should exist in the store
    keys = await list_keys("ephemeral", store)
    assert len(keys) == 2


# ------------------------------------------------------------------
# upload_file_from_bytes
# ------------------------------------------------------------------


@pytest.mark.integration
async def test_upload_file_from_bytes_roundtrip(store, tmp_path):
    """Upload bytes directly, then download and verify."""
    content = b"hello from bytes upload"
    sha = await upload_file_from_bytes("bytes/test.bin", content, store)
    assert len(sha) == 64  # hex SHA-256

    dest = tmp_path / "downloaded.bin"
    await download_file("bytes/test.bin", dest, store)
    assert dest.read_bytes() == content


@pytest.mark.integration
async def test_upload_file_from_bytes_empty(store, tmp_path):
    """Upload empty bytes."""
    sha = await upload_file_from_bytes("bytes/empty.bin", b"", store)
    assert len(sha) == 64

    dest = tmp_path / "empty.bin"
    await download_file("bytes/empty.bin", dest, store)
    assert dest.read_bytes() == b""


# ------------------------------------------------------------------
# delete_prefix
# ------------------------------------------------------------------


@pytest.mark.integration
async def test_delete_prefix_removes_all(store, tmp_path):
    """Upload files, delete by prefix, verify all gone."""
    for i in range(3):
        src = tmp_path / f"file_{i}.txt"
        src.write_text(f"data-{i}")
        await upload_file(f"to-delete/file_{i}.txt", src, store)

    keys_before = await list_keys("to-delete", store)
    assert len(keys_before) == 3

    deleted = await delete_prefix("to-delete", store)
    assert deleted == 3

    keys_after = await list_keys("to-delete", store)
    assert keys_after == []


@pytest.mark.integration
async def test_delete_prefix_empty(store):
    """delete_prefix on nonexistent prefix returns 0."""
    deleted = await delete_prefix("nonexistent-prefix", store)
    assert deleted == 0


# ------------------------------------------------------------------
# transfer.upload / download — concurrent directory path
# ------------------------------------------------------------------


@pytest.mark.integration
async def test_transfer_upload_directory_concurrent(store, tmp_path):
    """transfer.upload handles multi-file directories via asyncio.gather."""
    from application_sdk.storage.transfer import upload

    src = tmp_path / "src"
    src.mkdir()
    for i in range(15):
        (src / f"part_{i}.csv").write_text(f"row-{i}")

    out = await upload(str(src), "transfer-conc/", store=store)

    assert out.ref.file_count == 15
    assert out.synced is True
    assert out.reason == "uploaded"

    # Verify all data keys exist in the store (excludes .sha256 sidecars)
    keys = await list_keys("transfer-conc", store, suffix=".csv")
    assert len(keys) == 15


@pytest.mark.integration
async def test_transfer_upload_download_directory_roundtrip(store, tmp_path):
    """Full roundtrip: upload a directory concurrently, download and verify."""
    from application_sdk.storage.transfer import download, upload

    src = tmp_path / "src"
    src.mkdir()
    sub = src / "nested"
    sub.mkdir()
    (src / "root.txt").write_bytes(b"root-content")
    (sub / "child.txt").write_bytes(b"child-content")

    await upload(str(src), "rt-dir/", store=store)

    dest = tmp_path / "dest"
    dl = await download("rt-dir/", str(dest), store=store)

    assert dl.ref.file_count == 2
    assert dl.synced is True
    assert (dest / "root.txt").read_bytes() == b"root-content"
    assert (dest / "nested" / "child.txt").read_bytes() == b"child-content"


@pytest.mark.integration
async def test_transfer_upload_directory_skip_partial(store, tmp_path):
    """skip_if_exists skips unchanged files and re-uploads changed ones."""
    from application_sdk.storage.transfer import upload

    src = tmp_path / "src"
    src.mkdir()
    (src / "stable.txt").write_bytes(b"same")
    (src / "changing.txt").write_bytes(b"v1")

    out1 = await upload(str(src), "partial/", store=store, skip_if_exists=True)
    assert out1.synced is True

    # Second upload with same content → all skipped
    out2 = await upload(str(src), "partial/", store=store, skip_if_exists=True)
    assert out2.synced is False
    assert out2.reason == "skipped:hash_match"

    # Change one file → partial transfer
    (src / "changing.txt").write_bytes(b"v2")
    out3 = await upload(str(src), "partial/", store=store, skip_if_exists=True)
    assert out3.synced is True
    assert out3.reason == "uploaded"


@pytest.mark.integration
async def test_transfer_upload_directory_max_concurrency(store, tmp_path):
    """max_concurrency parameter is respected (runs with low concurrency)."""
    from application_sdk.storage.transfer import upload

    src = tmp_path / "src"
    src.mkdir()
    for i in range(8):
        (src / f"f{i}.bin").write_bytes(f"data-{i}".encode())

    out = await upload(str(src), "low-conc/", store=store, max_concurrency=2)

    assert out.ref.file_count == 8
    assert out.synced is True
