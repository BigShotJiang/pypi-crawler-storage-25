from __future__ import annotations

from rich.text import Text

LOGO = """███████╗ ███████╗ ███╗   ██╗ ██╗   ██╗ ███████╗
╚══███╔╝ ██╔════╝ ████╗  ██║ ██║   ██║ ██╔════╝
  ███╔╝  █████╗   ██╔██╗ ██║ ██║   ██║ █████╗
 ███╔╝   ██╔══╝   ██║╚██╗██║ ╚██╗ ██╔╝ ██╔══╝
███████╗ ███████╗ ██║ ╚████║  ╚████╔╝  ███████╗
╚══════╝ ╚══════╝ ╚═╝  ╚═══╝   ╚═══╝   ╚══════╝"""


def print_logo(version: str | None = None) -> None:
    from rich.console import Console

    from zenve_cli import __version__

    console = Console()
    console.print()
    console.print(Text(LOGO, style="bold cyan"))
    v = version or __version__
    console.print(Text(f"  v{v}  —  autonomous agents in your repo", style="dim cyan"))
    console.print()
