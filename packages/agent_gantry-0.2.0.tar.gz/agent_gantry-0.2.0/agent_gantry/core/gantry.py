"""
Main AgentGantry facade.

Primary entry point for the Agent-Gantry library.
"""

from __future__ import annotations

import asyncio
import importlib
import logging
import uuid
from collections.abc import Callable, Sequence
from datetime import datetime, timezone
from time import perf_counter
from typing import TYPE_CHECKING, Any, cast

from agent_gantry.adapters.embedders.openai import AzureOpenAIEmbedder, OpenAIEmbedder
from agent_gantry.adapters.embedders.simple import SimpleEmbedder
from agent_gantry.adapters.vector_stores.memory import InMemoryVectorStore
from agent_gantry.core.executor import ExecutionEngine
from agent_gantry.core.registry import ToolRegistry
from agent_gantry.core.router import RoutingWeights, SemanticRouter
from agent_gantry.core.security import SecurityPolicy
from agent_gantry.observability.console import ConsoleTelemetryAdapter, NoopTelemetryAdapter
from agent_gantry.observability.opentelemetry_adapter import (
    OpenTelemetryAdapter,
    PrometheusTelemetryAdapter,
)
from agent_gantry.schema.config import (
    A2AAgentConfig,
    AgentGantryConfig,
    EmbedderConfig,
    MCPServerConfig,
    RerankerConfig,
    TelemetryConfig,
    VectorStoreConfig,
)
from agent_gantry.schema.introspection import build_parameters_schema
from agent_gantry.schema.mcp import MCPServerDefinition
from agent_gantry.schema.query import RetrievalResult, ScoredTool, ToolQuery
from agent_gantry.schema.tool import ToolCapability, ToolDefinition
from agent_gantry.utils.fingerprint import compute_tool_fingerprint

if TYPE_CHECKING:
    from agent_gantry.adapters.embedders.base import EmbeddingAdapter
    from agent_gantry.adapters.rerankers.base import RerankerAdapter
    from agent_gantry.adapters.vector_stores.base import VectorStoreAdapter
    from agent_gantry.observability.telemetry import TelemetryAdapter
    from agent_gantry.schema.execution import BatchToolCall, BatchToolResult, ToolCall, ToolResult


logger = logging.getLogger(__name__)


class AgentGantry:
    """
    Main facade for Agent-Gantry.

    Provides intelligent, secure tool orchestration for LLM-based agent systems.

    Example:
        gantry = AgentGantry()

        @gantry.register
        def my_tool(x: int) -> str:
            '''Does something useful.'''
            return str(x * 2)

        tools = await gantry.retrieve_tools("double a number")
    """

    def __init__(
        self,
        config: AgentGantryConfig | None = None,
        vector_store: VectorStoreAdapter | None = None,
        embedder: EmbeddingAdapter | None = None,
        reranker: RerankerAdapter | None = None,
        telemetry: TelemetryAdapter | None = None,
        security_policy: SecurityPolicy | None = None,
        modules: Sequence[str] | None = None,
        module_attr: str = "tools",
    ) -> None:
        """
        Initialize AgentGantry.

        Args:
            config: Configuration for the gantry instance
            vector_store: Custom vector store adapter
            embedder: Custom embedding adapter
            reranker: Custom reranker adapter
            telemetry: Custom telemetry adapter
            security_policy: Security policy for permission checks
        """
        self._config = config or AgentGantryConfig()
        self._vector_store = vector_store or self._build_vector_store(self._config.vector_store)
        self._embedder = embedder or self._build_embedder(self._config.embedder)
        self._reranker = reranker or self._build_reranker(self._config.reranker)
        self._telemetry = telemetry or self._build_telemetry(self._config.telemetry)
        self._security_policy = security_policy or SecurityPolicy()
        self._registry = ToolRegistry()

        # Initialize MCP registry and router for dynamic server selection.
        # These imports are kept inside __init__ to avoid requiring the 'mcp'
        # package at module level (it's an optional dependency).
        from agent_gantry.core.sync_manager import SyncManager

        self._mcp_registry = None
        self._mcp_router = None
        self._mcp_manager = None

        try:
            from agent_gantry.core.mcp_manager import MCPManager
            from agent_gantry.core.mcp_registry import MCPRegistry
            from agent_gantry.core.mcp_router import MCPRouter

            self._mcp_registry = MCPRegistry()
            self._mcp_router = MCPRouter(
                vector_store=self._vector_store,
                embedder=self._embedder,
                registry=self._mcp_registry,
            )
        except ImportError:
            logger.debug("MCP support not available (install 'mcp' package to enable)")

        # Managers for decomposed responsibilities
        self._sync_manager = SyncManager(
            vector_store=self._vector_store,
            embedder=self._embedder,
            registry=self._registry,
        )
        if self._mcp_registry and self._mcp_router:
            from agent_gantry.core.mcp_manager import MCPManager

            self._mcp_manager = MCPManager(
                vector_store=self._vector_store,
                embedder=self._embedder,
                registry=self._mcp_registry,
                router=self._mcp_router,
                get_embedder_id=self._sync_manager.get_embedder_id,
            )

        # Initialize LLM client for intent classification if enabled
        self._llm_client = None
        if self._config.routing.use_llm_for_intent:
            from agent_gantry.adapters.llm_client import LLMClient

            try:
                self._llm_client = LLMClient(self._config.routing.llm)
            except Exception as e:
                logger.warning(f"Failed to initialize LLM client for intent classification: {e}")

        routing_weights = RoutingWeights(**self._config.routing.weights)
        self._router = SemanticRouter(
            vector_store=self._vector_store,
            embedder=self._embedder,
            reranker=self._reranker,
            weights=routing_weights,
            llm_client=self._llm_client,
            use_llm_for_intent=self._config.routing.use_llm_for_intent,
        )
        # Build rate limiter from config
        from agent_gantry.core.rate_limiter import RateLimiter

        self._rate_limiter: RateLimiter | None = None
        if self._config.execution.rate_limit.enabled:
            self._rate_limiter = RateLimiter(self._config.execution.rate_limit)

        self._executor = ExecutionEngine(
            registry=self._registry,
            default_timeout_ms=self._config.execution.default_timeout_ms,
            max_retries=self._config.execution.max_retries,
            circuit_breaker_threshold=self._config.execution.circuit_breaker_threshold,
            circuit_breaker_timeout_s=self._config.execution.circuit_breaker_timeout_s,
            security_policy=self._security_policy,
            telemetry=self._telemetry,
            rate_limiter=self._rate_limiter,
        )
        self._pending_tools: list[ToolDefinition] = []
        self._pending_mcp_servers: list[MCPServerDefinition] = []
        self._tool_handlers: dict[str, Callable[..., Any]] = {}
        self._initialized = False
        self._synced = False  # Track if we've done initial sync check
        self._mcp_synced = False  # Track if MCP servers are synced
        self._modules: Sequence[str] | None = None
        self._module_attr: str | None = None

        if modules:
            # Store modules configuration for explicit async initialization.
            # Users should call `collect_tools_from_modules` in an async context
            # or use `AgentGantry.from_modules(...)` if available.
            self._modules = modules
            self._module_attr = module_attr

    async def close(self) -> None:
        """
        Release all resources held by this AgentGantry instance.

        Closes vector store connections, MCP clients, and any other resources.
        Safe to call multiple times.
        """
        # Close vector store if it has a close method
        close_method = getattr(self._vector_store, "close", None)
        if close_method:
            if asyncio.iscoroutinefunction(close_method):
                await close_method()
            else:
                close_method()

        # Close telemetry if it has a close method
        if self._telemetry:
            telemetry_close = getattr(self._telemetry, "close", None)
            if telemetry_close:
                if asyncio.iscoroutinefunction(telemetry_close):
                    await telemetry_close()
                else:
                    telemetry_close()

        self._initialized = False

    async def __aenter__(self) -> AgentGantry:
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        """Exit async context manager, releasing resources."""
        await self.close()
        return False

    @classmethod
    def from_config(cls, path: str) -> AgentGantry:
        """
        Create an AgentGantry instance from a YAML config file.

        Args:
            path: Path to the YAML configuration file

        Returns:
            Configured AgentGantry instance
        """
        config = AgentGantryConfig.from_yaml(path)
        return cls(config=config)

    @classmethod
    def quick_start(
        cls,
        embedder: str = "auto",
        dimension: int = 256,
        **kwargs: Any,
    ) -> AgentGantry:
        """
        Quick setup with sensible defaults for getting started.

        Automatically detects the best available embedder and sets up
        an in-memory vector store for immediate use.

        Args:
            embedder: Embedder type - "auto", "nomic", "openai", or "simple"
            dimension: Embedding dimension (for Nomic, default 256)
            **kwargs: Additional AgentGantry constructor arguments

        Returns:
            Ready-to-use AgentGantry instance

        Example:
            >>> gantry = AgentGantry.quick_start()
            >>>
            >>> @gantry.register
            ... def my_tool(x: int) -> int:
            ...     '''Double a number.'''
            ...     return x * 2
            >>>
            >>> await gantry.sync()
            >>> tools = await gantry.retrieve_tools("double a number")
        """
        import warnings

        config = AgentGantryConfig()
        embedder_instance: EmbeddingAdapter

        if embedder == "auto":
            # Try Nomic first (best for local use)
            try:
                # Test that sentence-transformers is actually available
                import sentence_transformers  # noqa: F401

                from agent_gantry.adapters.embedders.nomic import NomicEmbedder

                embedder_instance = NomicEmbedder(dimension=dimension)
            except ImportError:
                warnings.warn(
                    "Nomic embedder not available. Using SimpleEmbedder (hash-based, low accuracy). "
                    "For better semantic search: pip install agent-gantry[nomic]",
                    UserWarning,
                    stacklevel=2,
                )
                embedder_instance = SimpleEmbedder()
        elif embedder == "nomic":
            try:
                from agent_gantry.adapters.embedders.nomic import NomicEmbedder
            except ImportError as exc:
                raise ImportError(
                    "Nomic embedder is not available. To enable it, install the optional "
                    "dependencies:\n"
                    "  pip install agent-gantry[nomic]"
                ) from exc

            try:
                import sentence_transformers  # noqa: F401
            except ImportError as exc:
                raise ImportError(
                    "sentence-transformers is required for the Nomic embedder. Install it with:\n"
                    "  pip install agent-gantry[nomic]"
                ) from exc

            embedder_instance = NomicEmbedder(dimension=dimension)
        elif embedder == "openai":
            api_key = kwargs.pop("openai_api_key", None)
            if not api_key:
                raise ValueError(
                    "OpenAI embedder requires a valid API key. "
                    "Pass openai_api_key=... to quick_start() or configure AgentGantryConfig."
                )
            embedder_config = EmbedderConfig(type="openai", api_key=api_key)
            try:
                embedder_instance = OpenAIEmbedder(embedder_config)
            except Exception as exc:
                raise RuntimeError(
                    "Failed to initialize OpenAI embedder. Ensure optional dependencies are "
                    'installed with "pip install agent-gantry[openai]" and that your OpenAI '
                    "API key is valid."
                ) from exc
        else:  # "simple" or unknown
            embedder_instance = SimpleEmbedder()

        return cls(config=config, embedder=embedder_instance, **kwargs)

    @classmethod
    async def from_modules(
        cls,
        modules: Sequence[str],
        *,
        attr: str = "tools",
        config: AgentGantryConfig | None = None,
        vector_store: VectorStoreAdapter | None = None,
        embedder: EmbeddingAdapter | None = None,
        reranker: RerankerAdapter | None = None,
        telemetry: TelemetryAdapter | None = None,
        security_policy: SecurityPolicy | None = None,
    ) -> AgentGantry:
        """
        Build a Gantry instance and populate it by importing tool-bearing modules.

        Args:
            modules: Iterable of module paths (dot-notation) to import.
            attr: Attribute on each module that holds an AgentGantry instance (default "tools").
            config/vector_store/embedder/reranker/telemetry/security_policy: Optional overrides
                for the constructed gantry instance.

        Returns:
            A populated AgentGantry instance.
        """

        gantry = cls(
            config=config,
            vector_store=vector_store,
            embedder=embedder,
            reranker=reranker,
            telemetry=telemetry,
            security_policy=security_policy,
        )
        await gantry.collect_tools_from_modules(modules, module_attr=attr)
        return gantry

    def register(
        self,
        func: Callable[..., Any] | None = None,
        *,
        name: str | None = None,
        namespace: str = "default",
        capabilities: list[ToolCapability] | None = None,
        requires_confirmation: bool = False,
        tags: list[str] | None = None,
        examples: list[str] | None = None,
    ) -> Callable[..., Any]:
        """
        Decorator to register Python functions as tools.

        Args:
            func: The function to register (when used without parentheses)
            name: Custom name for the tool (defaults to function name)
            namespace: Namespace for organizing tools
            capabilities: List of capabilities this tool has
            requires_confirmation: Whether to require human confirmation
            tags: Tags for categorizing the tool
            examples: Example queries that this tool handles

        Returns:
            The decorated function
        """

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            tool_name = name or fn.__name__
            tool_description = fn.__doc__ or f"Tool: {tool_name}"

            # Build parameters schema from function signature
            parameters_schema = build_parameters_schema(fn)

            tool = ToolDefinition(
                name=tool_name,
                namespace=namespace,
                description=tool_description.strip(),
                parameters_schema=parameters_schema,
                capabilities=capabilities or [],
                requires_confirmation=requires_confirmation,
                tags=tags or [],
                examples=examples or [],
            )

            self._pending_tools.append(tool)
            self._tool_handlers[tool_name] = fn

            # Register both tool definition and handler in the registry
            key = f"{namespace}.{tool_name}"
            self._registry.register_tool(tool)
            self._registry.register_handler(key, fn)

            return fn

        if func is not None:
            return decorator(func)
        return decorator

    async def _ensure_initialized(self) -> None:
        """Initialize backing services once."""
        if not self._initialized:
            await self._vector_store.initialize()
            self._initialized = True

    async def add_tool(self, tool: ToolDefinition) -> None:
        """
        Add a tool definition directly.

        Args:
            tool: The tool definition to add
        """
        self._pending_tools.append(tool)
        if self._config.auto_sync:
            await self.sync()

    async def _detect_changes(self, all_tools: list[ToolDefinition], force: bool) -> list[ToolDefinition]:
        """Detect which tools need to be synced. Delegates to SyncManager."""
        return await self._sync_manager.detect_changes(all_tools, force)

    async def _sync_batches(self, tools_to_sync: list[ToolDefinition], batch_size: int) -> int:
        """Embed and save tools in batches. Delegates to SyncManager."""
        return await self._sync_manager.sync_batches(tools_to_sync, batch_size)

    async def sync(self, batch_size: int = 100, force: bool = False) -> int:
        """
        Sync pending registrations to vector store with smart change detection.

        This method uses fingerprinting to detect which tools have actually changed
        and only re-embeds those tools. On subsequent runs with the same tools,
        this operation is nearly instant.

        Args:
            batch_size: Number of tools to embed and sync in each batch
            force: If True, re-embed all tools regardless of fingerprints

        Returns:
            Number of tools synced (0 if nothing changed)
        """
        # If modules were provided in constructor but not yet loaded, load them now
        if self._modules is not None:
            await self.collect_tools_from_modules(
                self._modules, module_attr=self._module_attr or "tools"
            )
            self._modules = None
            self._module_attr = None

        await self._ensure_initialized()

        # Get all registered tools (pending + already registered)
        all_tools = self.export_tools()
        if not all_tools:
            self._synced = True
            return 0

        # Determine which tools need syncing
        tools_to_sync = await self._detect_changes(all_tools, force)

        # Nothing to sync
        if not tools_to_sync:
            logger.debug(f"All {len(all_tools)} tools up-to-date, skipping sync")
            self._synced = True

            # Ensure handlers are registered even if tools are already in DB
            for tool in all_tools:
                self._registry.register_tool(tool)

            return 0

        logger.info(f"Syncing {len(tools_to_sync)}/{len(all_tools)} tools to vector store...")

        # Clear pending tools since we're processing them
        self._pending_tools = []

        total_synced = await self._sync_batches(tools_to_sync, batch_size)

        # Update sync metadata (if supported)
        await self._sync_manager.update_metadata()

        # Ensure all tools are registered (even those not synced)
        for tool in all_tools:
            if tool not in tools_to_sync:
                self._registry.register_tool(tool)

        self._synced = True
        logger.info(f"Synced {total_synced} tools")
        return total_synced

    def _get_embedder_id(self) -> str:
        """Get a unique identifier for the current embedder configuration."""
        return self._sync_manager.get_embedder_id()

    async def ensure_synced(self) -> None:
        """
        Ensure tools are synced to the vector store.

        This is called automatically before retrieval operations.
        Uses smart fingerprinting to avoid unnecessary re-embedding.
        """
        if not self._synced:
            await self.sync()

    async def _ensure_mcp_synced(self) -> None:
        """
        Ensure MCP servers are synced to the vector store.

        Similar to ensure_synced() but for MCP server metadata.
        """
        if not self._mcp_synced:
            await self.sync_mcp_servers()

    async def sync_mcp_servers(self, batch_size: int = 100, force: bool = False) -> int:
        """
        Sync pending MCP server registrations to vector store.

        Uses smart fingerprinting to avoid unnecessary re-embedding.

        Args:
            batch_size: Number of servers to embed and sync in each batch
            force: If True, re-embed all servers regardless of fingerprints

        Returns:
            Number of servers synced
        """
        await self._ensure_initialized()

        if self._mcp_registry is None:
            self._mcp_synced = True
            return 0

        # Get all registered servers
        all_servers = self._mcp_registry.list_servers()
        if not all_servers:
            self._mcp_synced = True
            return 0

        # Transform all MCP servers into pseudo-tools to calculate fingerprints
        pseudo_tools_map: dict[str, ToolDefinition] = {}
        for server in all_servers:
            pseudo_name = f"mcp_server_{server.namespace}_{server.name}".replace("-", "_")
            pseudo_tool = ToolDefinition(
                name=pseudo_name,
                namespace="__mcp_servers__",
                description=server.to_searchable_text(),
                parameters_schema={"type": "object", "properties": {}},
                metadata={
                    "entity_type": "mcp_server",
                    "server_name": server.name,
                    "server_namespace": server.namespace,
                    "server_tags": server.tags,
                    "server_capabilities": server.capabilities,
                    "server_command": server.command,
                },
            )
            pseudo_tools_map[f"{server.namespace}.{server.name}"] = pseudo_tool

        # Compute fingerprints for current servers (using their pseudo-tool representations)
        current_fingerprints = {
            f"{server.namespace}.{server.name}": compute_tool_fingerprint(pseudo_tool)
            for server in all_servers
            for pseudo_tool in [pseudo_tools_map[f"{server.namespace}.{server.name}"]]
        }

        # Get stored fingerprints from vector store
        embedder_id = self._get_embedder_id()
        needs_full_resync = force

        stored_fingerprints = await self._vector_store.get_stored_fingerprints()

        # Check if embedder changed (requires full re-embed)
        stored_embedder = await self._vector_store.get_metadata("embedder_id")
        stored_dim = await self._vector_store.get_metadata("dimension")

        if stored_embedder and stored_embedder != embedder_id:
            logger.info(
                f"Embedder changed from '{stored_embedder}' to '{embedder_id}'. "
                "Full re-sync required for MCP servers."
            )
            needs_full_resync = True
        elif stored_dim and int(stored_dim) != self._vector_store.dimension:
            logger.info(
                f"Dimension changed from {stored_dim} to {self._vector_store.dimension}. "
                "Full re-sync required for MCP servers."
            )
            needs_full_resync = True

        # Determine which servers need syncing
        if needs_full_resync:
            servers_to_sync = all_servers
        else:
            servers_to_sync = []
            for server in all_servers:
                server_id = f"{server.namespace}.{server.name}"
                pseudo_name = f"mcp_server_{server.namespace}_{server.name}".replace("-", "_")
                pseudo_tool_id = f"__mcp_servers__.{pseudo_name}"

                current_fp = current_fingerprints[server_id]
                # Stored fingerprint uses the pseudo_tool_id
                stored_fp = stored_fingerprints.get(pseudo_tool_id, "")

                if current_fp != stored_fp:
                    servers_to_sync.append(server)
                    if stored_fp:
                        logger.debug(f"MCP server '{server_id}' changed, will re-embed")
                    else:
                        logger.debug(f"MCP server '{server_id}' is new, will embed")

        # Clear pending servers since we're handling sync via fingerprints now
        self._mcp_registry.clear_pending()

        # Nothing to sync
        if not servers_to_sync:
            logger.debug(f"All {len(all_servers)} MCP servers up-to-date, skipping sync")
            self._mcp_synced = True
            return 0

        logger.info(f"Syncing {len(servers_to_sync)}/{len(all_servers)} MCP servers to vector store...")

        total_synced = 0
        for i in range(0, len(servers_to_sync), batch_size):
            batch = servers_to_sync[i : i + batch_size]
            texts = [s.to_searchable_text() for s in batch]
            embeddings = await self._embedder.embed_batch(texts)

            # Get the pre-created pseudo-tools for the batch
            pseudo_tools = [pseudo_tools_map[f"{server.namespace}.{server.name}"] for server in batch]

            # Use the existing add_tools method with upsert=True
            count = await self._vector_store.add_tools(pseudo_tools, embeddings, upsert=True)
            total_synced += count

        # Update sync metadata (if supported)
        await self._vector_store.update_sync_metadata(
            embedder_id=embedder_id,
            dimension=self._vector_store.dimension,
        )

        self._mcp_synced = True
        logger.info(f"Synced {total_synced} MCP servers")
        return total_synced

    async def collect_tools_from_modules(
        self,
        modules: Sequence[str],
        module_attr: str = "tools",
    ) -> int:
        """
        Import AgentGantry instances from other modules and register their tools locally.

        This is useful when you split tools across multiple files (e.g., a tools/ package). The
        tools are re-embedded with this gantry's embedder and added to its vector store and
        registry so they can be retrieved and executed without sharing vector stores.

        Args:
            modules: Iterable of module paths (dot-notation) to import.
            module_attr: Attribute name on each module that holds an AgentGantry instance (default "tools").

        Returns:
            Number of tools imported into this gantry.

        Raises:
            ValueError: If a module doesn't expose an AgentGantry at the specified attribute.
        """

        imported = 0
        seen: set[str] = set()
        tools_to_add: list[ToolDefinition] = []

        for module_path in modules:
            module = importlib.import_module(module_path)
            other = getattr(module, module_attr, None)
            if not isinstance(other, AgentGantry):
                raise ValueError(
                    f"Module '{module_path}' does not expose an AgentGantry instance at '{module_attr}'. "
                    f"Found: {type(other).__name__ if other else 'None'}"
                )

            # Collect tools from the source gantry using the public API
            all_tools = other.export_tools()

            for tool in all_tools:
                key = f"{tool.namespace}.{tool.name}"

                # Check for duplicates across modules
                if key in seen:
                    logger.warning(
                        f"Skipping duplicate tool '{key}' from module '{module_path}'. "
                        f"A tool with this name was already imported from another module."
                    )
                    continue

                # Get the tool handler from the source gantry
                handler = other._registry.get_handler(key)

                # Add to batch for efficient processing
                tools_to_add.append(tool)

                # Register the handler if available
                if handler:
                    self._registry.register_handler(key, handler)
                    self._tool_handlers[tool.name] = handler
                else:
                    logger.debug(f"No handler found for tool '{key}' in module '{module_path}'")

                seen.add(key)
                imported += 1

            logger.info(f"Imported {len(all_tools)} tools from module '{module_path}'")

        if tools_to_add:
            await self._ensure_initialized()
            batch_size = 100
            for i in range(0, len(tools_to_add), batch_size):
                batch = tools_to_add[i : i + batch_size]
                texts = [t.to_searchable_text() for t in batch]
                embeddings = await self._embedder.embed_batch(texts)
                await self._vector_store.add_tools(batch, embeddings, upsert=True)
                for tool in batch:
                    self._registry.register_tool(tool)

        return imported

    async def retrieve(self, query: ToolQuery) -> RetrievalResult:
        """
        Core semantic routing function.

        Automatically ensures tools are synced before retrieval using smart
        fingerprint-based change detection.

        Args:
            query: The tool query with context and filters

        Returns:
            RetrievalResult with scored tools
        """
        await self._ensure_initialized()

        # Auto-sync with smart change detection
        await self.ensure_synced()

        overall_start = perf_counter()
        if self._config.reranker.enabled and self._reranker is not None:
            if query.enable_reranking is None:
                query.enable_reranking = True

        # Use telemetry span if available, otherwise use a no-op async context manager
        from agent_gantry.utils.async_utils import AsyncNoopContext

        span_cm = (
            self._telemetry.span("tool_retrieval", {"query": query.context.query})
            if self._telemetry else AsyncNoopContext()
        )
        async with span_cm:
            routing_result = await self._router.route(query)

        # routing_result.tools is a list of (tool, semantic_score) tuples
        scored = []
        for tool, semantic_score in routing_result.tools:
            scored.append(
                ScoredTool(
                    tool=tool,
                    semantic_score=semantic_score,
                    rerank_score=None,  # Rerank scores handled separately if needed
                )
            )

        total_time_ms = (perf_counter() - overall_start) * 1000
        retrieval = RetrievalResult(
            tools=scored,
            query_embedding_time_ms=routing_result.query_embedding_time_ms,
            vector_search_time_ms=routing_result.vector_search_time_ms,
            rerank_time_ms=routing_result.rerank_time_ms,
            total_time_ms=total_time_ms,
            candidate_count=routing_result.candidate_count,
            filtered_count=routing_result.filtered_count,
            trace_id=str(uuid.uuid4()),
        )
        if self._telemetry:
            await self._telemetry.record_retrieval(query, retrieval)
        return retrieval

    async def retrieve_tools(
        self,
        query: str,
        limit: int = 5,
        dialect: str = "openai",
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """
        Convenience wrapper: returns provider-specific tool schemas.

        Args:
            query: The natural language query
            limit: Maximum number of tools to return
            dialect: Target dialect/provider name (default: 'openai')
                Supported: 'openai', 'openai_responses', 'anthropic', 'gemini',
                'mistral', 'groq', 'agent_framework', 'auto'
            **kwargs: Additional query parameters (e.g., score_threshold)

        Returns:
            List of provider-specific tool schemas
        """
        from agent_gantry.schema.query import ConversationContext, ToolQuery

        context = ConversationContext(query=query)
        tool_query = ToolQuery(context=context, limit=limit, **kwargs)
        result = await self.retrieve(tool_query)
        return result.to_dialect(dialect)

    async def execute(self, call: ToolCall) -> ToolResult:
        """
        Execute a tool call with full protections.

        Args:
            call: The tool call to execute

        Returns:
            Result of the tool execution
        """
        await self._ensure_initialized()

        # Auto-sync to ensure handlers are registered
        await self.ensure_synced()

        if self._telemetry:
            async with self._telemetry.span("tool_execution", {"tool_name": call.tool_name}):
                return await self._executor.execute(call)
        else:
            return await self._executor.execute(call)

    async def search_and_execute(
        self,
        query: str,
        arguments: dict[str, Any] | None = None,
        limit: int = 1,
        **kwargs: Any,
    ) -> ToolResult:
        """
        One-shot convenience: search for a tool and execute it.

        Combines retrieve_tools() and execute() into a single operation.
        Useful for simple scripting and quick tool invocation.

        Args:
            query: Natural language query to find the tool
            arguments: Arguments to pass to the tool (optional)
            limit: Number of tools to retrieve (default: 1, uses best match)
            **kwargs: Additional retrieval parameters (score_threshold, etc.)

        Returns:
            Result of executing the best matching tool

        Raises:
            ValueError: If no matching tools found

        Example:
            >>> result = await gantry.search_and_execute(
            ...     "calculate tax on 100",
            ...     arguments={"amount": 100.0}
            ... )
            >>> print(result.result)
            8.0
        """
        from agent_gantry.schema.execution import ToolCall
        from agent_gantry.schema.query import ConversationContext, ToolQuery

        # Retrieve best matching tool
        context = ConversationContext(query=query)
        tool_query = ToolQuery(context=context, limit=limit, **kwargs)
        result = await self.retrieve(tool_query)

        if not result.tools:
            raise ValueError(
                f"No tools found matching query: '{query}'. "
                f"Try a different query or check registered tools."
            )

        # Use the best scoring tool
        best_tool = result.tools[0].tool
        tool_name = best_tool.name

        # Use provided arguments or empty dict
        if arguments is None:
            arguments = {}

        # Execute the tool
        return await self.execute(ToolCall(tool_name=tool_name, arguments=arguments))

    async def execute_batch(self, batch: BatchToolCall) -> BatchToolResult:
        """
        Execute multiple tool calls.

        Args:
            batch: The batch of tool calls

        Returns:
            Results of all tool executions
        """
        await self._ensure_initialized()

        # Auto-sync to ensure handlers are registered
        await self.ensure_synced()

        if self._telemetry:
            async with self._telemetry.span("batch_execution", {"count": len(batch.calls)}):
                return await self._executor.execute_batch(batch)
        else:
            return await self._executor.execute_batch(batch)

    async def add_mcp_server(self, config: MCPServerConfig) -> int:
        """
        Add an MCP server to discover and register its tools.

        Note: This method immediately discovers and registers ALL tools from the server.
        For dynamic server selection, use register_mcp_server() instead.

        Args:
            config: Configuration for the MCP server

        Returns:
            Number of tools discovered and registered
        """
        from agent_gantry.adapters.executors.mcp_client import MCPClient

        await self._ensure_initialized()

        # Create MCP client
        client = MCPClient(config)

        # Discover tools from the server
        tools = await client.list_tools()

        # Add tools to the gantry
        for tool in tools:
            await self.add_tool(tool)

        return len(tools)

    def register_mcp_server(
        self,
        name: str,
        command: list[str],
        *,
        description: str,
        namespace: str = "default",
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        tags: list[str] | None = None,
        examples: list[str] | None = None,
        capabilities: list[str] | None = None,
    ) -> None:
        """
        Register an MCP server for dynamic selection via semantic routing.

        Unlike add_mcp_server(), this method does NOT immediately connect to the server.
        Instead, it registers the server metadata for semantic search, and tools are
        discovered on-demand when the server is selected.

        Args:
            name: Unique name for the server
            command: Command to start the MCP server (e.g., ["npx", "@modelcontextprotocol/server-filesystem"])
            description: Description of what the server provides
            namespace: Namespace for organizing servers
            args: Additional command-line arguments
            env: Environment variables for the server process
            tags: Tags for categorizing the server
            examples: Example queries this server handles
            capabilities: Server capabilities (e.g., "read_files", "write_files")

        Example:
            >>> gantry.register_mcp_server(
            ...     name="filesystem",
            ...     command=["npx", "-y", "@modelcontextprotocol/server-filesystem"],
            ...     description="Provides tools for reading and writing files on the local filesystem",
            ...     args=["--path", "/tmp"],
            ...     tags=["filesystem", "files", "io"],
            ...     examples=["read a file", "write to a file", "list directory contents"],
            ...     capabilities=["read_files", "write_files", "list_directory"],
            ... )
        """
        from agent_gantry.schema.mcp import MCPServerDefinition

        server_def = MCPServerDefinition(
            name=name,
            namespace=namespace,
            description=description,
            command=command,
            args=args or [],
            env=env or {},
            tags=tags or [],
            examples=examples or [],
            capabilities=capabilities or [],
        )

        # Register in MCP registry and mark as pending for sync
        self._mcp_registry.register_server(server_def)
        self._mcp_registry.add_pending(server_def)

        logger.info(f"Registered MCP server: {server_def.qualified_name}")

    async def retrieve_mcp_servers(
        self,
        query: str,
        limit: int = 3,
        score_threshold: float | None = None,
        namespaces: list[str] | None = None,
    ) -> list[MCPServerDefinition]:
        """
        Retrieve relevant MCP servers based on a query using semantic search.

        Args:
            query: Natural language query describing needed functionality
            limit: Maximum number of servers to return
            score_threshold: Minimum similarity score (0-1)
            namespaces: Filter by server namespaces

        Returns:
            List of relevant MCP server definitions

        Example:
            >>> servers = await gantry.retrieve_mcp_servers(
            ...     "read and write files",
            ...     limit=2
            ... )
            >>> for server in servers:
            ...     print(f"Server: {server.name} - {server.description}")
        """
        await self._ensure_initialized()
        await self._ensure_mcp_synced()

        result = await self._mcp_router.route(
            query=query,
            limit=limit,
            score_threshold=score_threshold,
            namespaces=namespaces,
        )

        return [scored.server for scored in result.servers]

    async def discover_tools_from_server(
        self,
        server_name: str,
        namespace: str = "default",
        timeout: float = 30.0,
    ) -> int:
        """
        Dynamically discover and register tools from a previously registered MCP server.

        This method connects to the server, discovers its tools, and adds them to
        the gantry's tool registry.

        Args:
            server_name: Name of the registered MCP server
            namespace: Server namespace
            timeout: Connection timeout in seconds (default: 30.0)

        Returns:
            Number of tools discovered and registered

        Raises:
            ValueError: If the server is not registered
            TimeoutError: If the connection or tool discovery times out
            Exception: If tool discovery fails

        Example:
            >>> # First register the server metadata
            >>> gantry.register_mcp_server(...)
            >>> await gantry.sync()
            >>>
            >>> # Later, discover tools on-demand
            >>> count = await gantry.discover_tools_from_server("filesystem")
            >>> print(f"Discovered {count} tools")
        """
        await self._ensure_initialized()

        # Get the MCP client for this server
        client = self._mcp_registry.get_client(server_name, namespace)
        if not client:
            raise ValueError(
                f"MCP server '{namespace}.{server_name}' not found. "
                f"Register it first with register_mcp_server()."
            )

        try:
            # Discover tools from the server with timeout protection
            tools = await asyncio.wait_for(client.list_tools(), timeout=timeout)

            # Add tools to the gantry
            for tool in tools:
                await self.add_tool(tool)

            # Update server health
            self._mcp_registry.update_health(
                server_name,
                namespace,
                available=True,
                last_success=datetime.now(timezone.utc),
                consecutive_failures=0,
            )

            logger.info(f"Discovered {len(tools)} tools from MCP server: {namespace}.{server_name}")
            return len(tools)

        except asyncio.TimeoutError:
            # Update server health on timeout
            server = self._mcp_registry.get_server(server_name, namespace)
            consecutive_failures = server.health.consecutive_failures + 1 if server else 1

            self._mcp_registry.update_health(
                server_name,
                namespace,
                available=False,
                last_failure=datetime.now(timezone.utc),
                consecutive_failures=consecutive_failures,
            )

            logger.error(
                f"Timeout while discovering tools from MCP server {namespace}.{server_name} "
                f"(timeout: {timeout}s)"
            )
            raise TimeoutError(
                f"MCP server {namespace}.{server_name} did not respond within {timeout}s"
            )

        except Exception as e:
            # Update server health on failure
            server = self._mcp_registry.get_server(server_name, namespace)
            consecutive_failures = server.health.consecutive_failures + 1 if server else 1

            self._mcp_registry.update_health(
                server_name,
                namespace,
                available=False,
                last_failure=datetime.now(timezone.utc),
                consecutive_failures=consecutive_failures,
            )

            logger.error(f"Failed to discover tools from MCP server {namespace}.{server_name}: {e}")
            raise

    async def serve_mcp(
        self, transport: str = "stdio", mode: str = "dynamic", name: str = "agent-gantry"
    ) -> None:
        """
        Start serving as an MCP server.

        Args:
            transport: Transport type ("stdio" or "sse")
            mode: Server mode ("dynamic", "static", or "hybrid")
            name: Server name for identification
        """
        from agent_gantry.servers.mcp_server import create_mcp_server

        await self._ensure_initialized()
        await self.ensure_synced()

        server = create_mcp_server(self, mode=mode, name=name)

        if transport == "stdio":
            await server.run_stdio()
        elif transport == "sse":
            await server.run_sse()
        else:
            raise ValueError(f"Unsupported transport: {transport}")

    async def add_a2a_agent(self, config: A2AAgentConfig) -> int:
        """
        Add an A2A agent to discover and register its skills as tools.

        Args:
            config: Configuration for the A2A agent

        Returns:
            Number of skills discovered and registered as tools
        """
        from agent_gantry.providers.a2a_client import A2AClient

        await self._ensure_initialized()

        # Create A2A client
        client = A2AClient(config)

        # Discover agent and its skills
        await client.discover()
        tools = await client.list_tools()

        # Add tools to the gantry
        for tool in tools:
            await self.add_tool(tool)

        return len(tools)

    def serve_a2a(self, host: str = "0.0.0.0", port: int = 8080) -> None:
        """
        Start serving as an A2A agent.

        Args:
            host: Host to bind to
            port: Port to listen on

        Note:
            This method requires FastAPI and uvicorn to be installed.
            Install with: pip install fastapi uvicorn
        """
        try:
            import uvicorn
        except ImportError as e:
            raise ImportError(
                "uvicorn is required for A2A server. Install with: pip install fastapi uvicorn"
            ) from e

        from agent_gantry.servers.a2a_server import create_a2a_server

        # Create FastAPI app
        base_url = f"http://{host}:{port}"
        app = create_a2a_server(self, base_url=base_url)

        # Run server
        uvicorn.run(app, host=host, port=port)

    @property
    def tool_count(self) -> int:
        """Return the number of registered tools."""
        return len(self._tool_handlers)

    async def get_tool(self, name: str, namespace: str = "default") -> ToolDefinition | None:
        """
        Get a tool by name.

        Args:
            name: Tool name
            namespace: Tool namespace

        Returns:
            The tool definition if found
        """
        await self._ensure_initialized()
        await self.ensure_synced()
        return await self._vector_store.get_by_name(name, namespace)

    async def list_tools(
        self,
        namespace: str | None = None,
    ) -> list[ToolDefinition]:
        """
        List all registered tools.

        Args:
            namespace: Filter by namespace

        Returns:
            List of tool definitions
        """
        await self._ensure_initialized()
        await self.ensure_synced()
        return await self._vector_store.list_all(namespace=namespace)

    def export_tools(self) -> list[ToolDefinition]:
        """
        Export all registered and pending tools.

        Useful for importing tools into another AgentGantry instance
        without accessing private attributes.

        Returns:
            List of all tool definitions (registered + pending)
        """
        registered = self._registry.list_tools()
        pending = self._pending_tools.copy()

        # Deduplicate by qualified name
        seen: set[str] = set()
        result: list[ToolDefinition] = []

        for tool in registered + pending:
            key = f"{tool.namespace}.{tool.name}"
            if key not in seen:
                seen.add(key)
                result.append(tool)

        return result

    async def delete_tool(self, name: str, namespace: str = "default") -> bool:
        """
        Delete a tool.

        Args:
            name: Tool name
            namespace: Tool namespace

        Returns:
            True if tool was deleted
        """
        await self._ensure_initialized()
        return await self._vector_store.delete(name, namespace)

    async def health_check(self) -> dict[str, bool]:
        """
        Check health of all components.

        Returns:
            Dictionary of component health status
        """
        import asyncio

        await self._ensure_initialized()

        results = {
            "vector_store": await self._vector_store.health_check(),
            "embedder": await self._embedder.health_check(),
        }

        if self._telemetry is not None:
            try:
                health_method = getattr(self._telemetry, "health_check", None)
                if health_method is not None:
                    if asyncio.iscoroutinefunction(health_method):
                        results["telemetry"] = await health_method()
                    else:
                        results["telemetry"] = bool(health_method())
                else:
                    results["telemetry"] = True
            except Exception:
                results["telemetry"] = False

        return results

    def _build_vector_store(self, config: VectorStoreConfig) -> VectorStoreAdapter:
        """Construct a vector store adapter from configuration."""
        if config.type == "qdrant":
            from agent_gantry.adapters.vector_stores.remote import QdrantVectorStore

            if not config.url:
                raise ValueError("Qdrant requires 'url' in configuration")
            return cast(
                "VectorStoreAdapter",
                QdrantVectorStore(
                    url=config.url,
                    api_key=config.api_key,
                    collection_name=config.collection_name,
                    dimension=config.dimension or 1536,
                ),
            )
        if config.type == "chroma":
            from agent_gantry.adapters.vector_stores.remote import ChromaVectorStore

            return cast(
                "VectorStoreAdapter",
                ChromaVectorStore(
                    url=config.url,
                    collection_name=config.collection_name,
                    persist_directory=config.db_path,
                ),
            )
        if config.type == "pgvector":
            from agent_gantry.adapters.vector_stores.remote import PGVectorStore

            if not config.url:
                raise ValueError("PGVector requires 'url' (connection string) in configuration")
            return cast(
                "VectorStoreAdapter",
                PGVectorStore(
                    url=config.url,
                    table_name=config.collection_name,
                    dimension=config.dimension or 1536,
                ),
            )
        if config.type == "lancedb":
            from agent_gantry.adapters.vector_stores.lancedb import LanceDBVectorStore

            return cast(
                "VectorStoreAdapter",
                LanceDBVectorStore(
                    db_path=config.db_path,
                    tools_table=config.collection_name,
                    dimension=config.dimension or 768,
                ),
            )
        return InMemoryVectorStore()

    def _build_embedder(self, config: EmbedderConfig) -> EmbeddingAdapter:
        """Construct an embedder from configuration."""
        if config.type == "openai" and config.api_key:
            return OpenAIEmbedder(config)
        if config.type == "azure" and config.api_key:
            return AzureOpenAIEmbedder(config)
        if config.type == "nomic":
            from agent_gantry.adapters.embedders.nomic import NomicEmbedder

            return NomicEmbedder(
                model=config.model or "nomic-ai/nomic-embed-text-v1.5",
                dimension=config.dimension,
                task_type=config.task_type or "search_document",
            )
        if config.type == "sentence_transformers":
            try:
                import sentence_transformers as _st  # noqa: F401

                from agent_gantry.adapters.embedders.sentence_transformers import (
                    SentenceTransformersEmbedder,
                )

                return SentenceTransformersEmbedder(
                    model=config.model or "all-MiniLM-L6-v2",
                    dimension=config.dimension,
                )
            except ImportError:
                logger.debug(
                    "sentence-transformers not available, falling back to SimpleEmbedder"
                )
        return SimpleEmbedder()

    def _build_reranker(self, config: RerankerConfig) -> RerankerAdapter | None:
        """Construct a reranker from configuration."""
        if not config.enabled:
            return None
        if config.type == "cohere":
            from agent_gantry.adapters.rerankers.cohere import CohereReranker

            return CohereReranker(model=config.model)
        if config.type == "cross_encoder":
            from agent_gantry.adapters.rerankers.cross_encoder import CrossEncoderReranker

            return CrossEncoderReranker(
                model=config.model or "cross-encoder/ms-marco-MiniLM-L-6-v2",
            )
        return None

    def _build_telemetry(self, config: TelemetryConfig) -> TelemetryAdapter:
        """Construct telemetry adapter from configuration."""
        if not config.enabled:
            return NoopTelemetryAdapter()
        if config.type == "opentelemetry":
            return OpenTelemetryAdapter(
                service_name=config.service_name,
                otlp_endpoint=config.otlp_endpoint,
            )
        if config.type == "prometheus":
            return PrometheusTelemetryAdapter(
                service_name=config.service_name,
                prometheus_port=config.prometheus_port,
            )
        return ConsoleTelemetryAdapter()


def create_default_gantry(dimension: int = 256) -> AgentGantry:
    """
    Factory function to create a pre-configured AgentGantry instance.

    This provides a convenient way to create an AgentGantry instance with
    sensible defaults, automatically selecting the best available embedder:
    - NomicEmbedder (if sentence-transformers is available)
    - SimpleEmbedder (fallback, hash-based)

    This avoids module-level instantiation which can cause issues with
    testing, cleanup, or if multiple instances are needed.

    Args:
        dimension: Embedding dimension for Nomic embedder (default: 256).
                   Ignored if NomicEmbedder is not available.

    Returns:
        A configured AgentGantry instance ready for tool registration.

    Example:
        >>> from agent_gantry import create_default_gantry
        >>>
        >>> tools = create_default_gantry()
        >>>
        >>> @tools.register(tags=["math"])
        ... def add(a: int, b: int) -> int:
        ...     '''Add two numbers.'''
        ...     return a + b

    Note:
        For better semantic search quality, install the Nomic dependencies:
        `pip install agent-gantry[nomic]`
    """
    return AgentGantry.quick_start(embedder="auto", dimension=dimension)
