"""Verbumia MCP server (MIT)."""

__version__ = "0.12.1"
