"""Async HTTP client wrapping the Verbumia REST API.

The MCP tools are thin adapters over this client — they translate MCP
arguments to API calls and shape the response. Authentication is the
`Authorization: ApiKey vrb_live_<prefix>.<secret>` header read from
`VERBUMIA_API_KEY` (or `VERBUMIA_TOKEN` for back-compat).
"""

from __future__ import annotations

from typing import Any

import httpx

from .config import Config


class VerbumiaApiError(Exception):
    """Raised when the API returns a non-2xx response."""

    def __init__(self, status: int, body: str | dict[str, Any]) -> None:
        self.status = status
        self.body = body
        super().__init__(f"Verbumia API error {status}: {body}")


class VerbumiaClient:
    """Tiny async REST client. Reuse across tool calls — open once at startup."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._http = httpx.AsyncClient(
            base_url=config.api_base,
            headers={
                "Authorization": f"ApiKey {config.token}",
                "User-Agent": config.user_agent,
                "Accept": "application/json",
            },
            timeout=httpx.Timeout(15.0, connect=5.0),
        )

    async def aclose(self) -> None:
        await self._http.aclose()

    @property
    def config(self) -> Config:
        return self._config

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        r = await self._http.get(path, params=params)
        return _unpack(r)

    async def post(self, path: str, json: dict[str, Any]) -> Any:
        r = await self._http.post(path, json=json)
        return _unpack(r)

    async def put(self, path: str, json: dict[str, Any]) -> Any:
        r = await self._http.put(path, json=json)
        return _unpack(r)

    async def health(self) -> dict[str, Any]:
        return await self.get("/health")


def _unpack(r: httpx.Response) -> Any:
    if r.status_code >= 400:
        try:
            body: str | dict[str, Any] = r.json()
        except ValueError:
            body = r.text
        raise VerbumiaApiError(r.status_code, body)
    if r.status_code == 204 or not r.content:
        return None
    return r.json()
