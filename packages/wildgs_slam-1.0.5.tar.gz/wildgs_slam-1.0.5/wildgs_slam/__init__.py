"""WildGS-SLAM: Monocular SLAM in Dynamic Environments (CVPR 2025)."""

__version__ = "1.0.0"

import os as _os
import sysconfig as _sysconfig

# Ensure PyTorch shared libraries are on LD_LIBRARY_PATH so CUDA extensions
# (droid_backends, lietorch_backends, etc.) can resolve libtorch*.so at runtime.
_torch_lib = _os.path.join(_sysconfig.get_path("purelib"), "torch", "lib")
if _os.path.isdir(_torch_lib):
    _current = _os.environ.get("LD_LIBRARY_PATH", "")
    if _torch_lib not in _current.split(":"):
        _os.environ["LD_LIBRARY_PATH"] = _torch_lib + (":" + _current if _current else "")
