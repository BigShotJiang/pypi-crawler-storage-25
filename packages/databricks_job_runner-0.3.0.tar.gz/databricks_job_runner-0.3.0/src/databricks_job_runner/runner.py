"""Runner: orchestration for upload, submit, validate, logs, and clean operations.

Each project creates a :class:`Runner` instance with its config, then
calls :meth:`Runner.main` to dispatch CLI subcommands.  The Runner's
orchestration methods (``upload_file``, ``submit``, ``validate``,
``logs``, ``clean``, etc.) are also callable directly as a library API.

Example usage in a consuming project::

    # cli/__init__.py
    from databricks_job_runner import Runner, RunnerConfig

    def build_params(config: RunnerConfig, script: str) -> list[str]:
        params: list[str] = []
        if config.extras.get("NEO4J_URI") and config.extras.get("NEO4J_PASSWORD"):
            params += [
                "--neo4j-uri", config.extras["NEO4J_URI"],
                "--neo4j-password", config.extras["NEO4J_PASSWORD"],
            ]
        return params

    runner = Runner(
        run_name_prefix="graph_validation",
        build_params=build_params,
        wheel_package="augmentation_agent",  # optional
    )

    # cli/__main__.py
    from . import runner
    runner.main()

Then invoke as::

    python -m cli upload --all
    python -m cli submit test_hello.py
    python -m cli clean --yes
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from databricks.sdk import WorkspaceClient

from databricks_job_runner.clean import clean_runs, clean_workspace
from databricks_job_runner.compute import ClassicCluster, Compute, Serverless
from databricks_job_runner.config import RunnerConfig, make_client
from databricks_job_runner.errors import RunnerError
from databricks_job_runner.logs import find_latest_run, get_run_logs
from databricks_job_runner.submit import submit_job
from databricks_job_runner.upload import (
    build_and_upload_wheel,
    ensure_remote_dirs,
    find_latest_wheel,
    upload_agent_modules,
    upload_file,
)
from databricks_job_runner.validate import check_file_exists, list_workspace

#: Type for the ``build_params`` callback passed to :class:`Runner`.
#: The second argument is the script name being submitted, allowing
#: per-script parameter injection.
type BuildParamsFn = Callable[[RunnerConfig, str], list[str]]


class Runner:
    """Reusable Databricks job runner configured per-project.

    Args:
        run_name_prefix: Prefix for job run names (e.g. ``"graph_validation"``).
            Also used to filter runs during cleanup (matches ``"prefix:"``).
        build_params: Callable that receives the :class:`RunnerConfig` and
            returns a list of CLI args to inject into the submitted job.
            ``None`` means no extra parameters are injected.
        project_dir: Root directory of the consuming project (where ``.env``
            and ``agent_modules/`` live).  Defaults to the caller's working
            directory.
        wheel_package: Optional package name for wheel building (e.g.
            ``"augmentation_agent"``).  Enables the ``upload --wheel``
            subcommand.  Wheels are uploaded to ``<DATABRICKS_VOLUME_PATH>/wheels/``.
    """

    def __init__(
        self,
        run_name_prefix: str,
        build_params: BuildParamsFn | None = None,
        project_dir: Path | str | None = None,
        wheel_package: str | None = None,
    ) -> None:
        self.run_name_prefix = run_name_prefix
        self._build_params_fn = build_params
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.wheel_package = wheel_package

        # Lazy-initialized
        self._config: RunnerConfig | None = None
        self._ws: WorkspaceClient | None = None

    # -- Properties (lazy) ---------------------------------------------------

    @property
    def config(self) -> RunnerConfig:
        """Parsed ``.env`` values as a typed :class:`RunnerConfig`."""
        if self._config is None:
            self._config = RunnerConfig.from_env_file(self.project_dir / ".env")
        return self._config

    @property
    def ws(self) -> WorkspaceClient:
        """Databricks workspace client.  Created once on first access.

        Uses ``DATABRICKS_PROFILE`` when set; otherwise falls back to the
        SDK's unified auth (env vars, Azure CLI, etc.).
        """
        if self._ws is None:
            self._ws = make_client(self.config.databricks_profile)
        return self._ws

    @property
    def agent_modules_dir(self) -> Path:
        return self.project_dir / "agent_modules"

    @property
    def wheel_volume_dir(self) -> str:
        vol = self.config.databricks_volume_path
        return f"{vol}/wheels" if vol else ""

    # -- Public helpers ------------------------------------------------------

    def get_params(self, script: str) -> list[str]:
        """Build CLI parameters for job submission via the callback."""
        if self._build_params_fn is None:
            return []
        return self._build_params_fn(self.config, script)

    def find_wheel(self) -> str | None:
        """Find the latest built wheel in ``dist/``.  Returns the filename."""
        if not self.wheel_package:
            return None
        whl = find_latest_wheel(self.project_dir / "dist", self.wheel_package)
        return whl.name if whl else None

    def _compute(self) -> Compute:
        """Build the :class:`Compute` strategy from config."""
        if self.config.databricks_compute_mode == "serverless":
            return Serverless(
                environment_version=self.config.databricks_serverless_env_version,
            )
        # Config validation guarantees databricks_cluster_id is set when
        # compute_mode == "cluster".
        assert self.config.databricks_cluster_id is not None
        return ClassicCluster(cluster_id=self.config.databricks_cluster_id)

    # -- Orchestration methods ----------------------------------------------

    def upload_file(self, filename: str) -> None:
        """Upload a single file from ``agent_modules/`` to the workspace."""
        local_path = self.agent_modules_dir / filename
        if not local_path.exists():
            raise RunnerError(f"{local_path} not found")
        workspace_dir = self.config.databricks_workspace_dir
        ensure_remote_dirs(self.ws, workspace_dir)
        print(f"Uploading to {workspace_dir}/agent_modules")
        print("---")
        upload_file(
            self.ws,
            local_path,
            f"{workspace_dir}/agent_modules/{local_path.name}",
        )
        print()
        print("Upload complete.")

    def upload_all(self) -> None:
        """Upload all ``agent_modules/*.py`` files to the workspace."""
        workspace_dir = self.config.databricks_workspace_dir
        print(f"Uploading all agent_modules/ to {workspace_dir}/agent_modules")
        print("---")
        upload_agent_modules(self.ws, self.agent_modules_dir, workspace_dir)
        print()
        print("Upload complete.")

    def upload_wheel(self) -> None:
        """Build a wheel with ``uv build`` and upload to the UC Volume."""
        if not self.wheel_package:
            raise RunnerError("wheel_package not configured for this runner.")
        print(f"Building and uploading wheel to {self.wheel_volume_dir}")
        print("---")
        build_and_upload_wheel(
            self.ws, self.project_dir, self.wheel_volume_dir, self.wheel_package
        )
        print()
        print("Upload complete.")

    def submit(self, script: str, *, no_wait: bool = False) -> None:
        """Submit a script as a one-time Databricks job.

        Builds the compute strategy from ``DATABRICKS_COMPUTE_MODE`` and
        delegates readiness checks to it (classic starts the cluster if
        terminated; serverless is a no-op).  When submitting a script
        named ``run_{wheel_package}.py``, the latest wheel from ``dist/``
        is attached automatically — as a :class:`Library` on classic, or
        as an ``Environment.dependencies`` entry on serverless.
        """
        params = self.get_params(script)
        run_name = f"{self.run_name_prefix}: {script}"

        if params:
            print("  Params:   injected from .env")

        # Resolve the wheel path when submitting its runner script
        wheel_path: str | None = None
        if self.wheel_package and script == f"run_{self.wheel_package}.py":
            whl_name = self.find_wheel()
            if not whl_name:
                raise RunnerError(
                    "No wheel found in dist/. "
                    "Run `python -m cli upload --wheel` first."
                )
            wheel_path = f"{self.wheel_volume_dir}/{whl_name}"
            print(f"  Wheel:    {wheel_path}")

        submit_job(
            self.ws,
            compute=self._compute(),
            workspace_dir=self.config.databricks_workspace_dir,
            script_name=script,
            run_name=run_name,
            params=params,
            wheel_path=wheel_path,
            no_wait=no_wait,
        )

    def logs(self, run_id: int | None = None) -> None:
        """Print stdout/stderr and error trace for a submitted run.

        When *run_id* is ``None``, finds the most recent SUBMIT_RUN whose
        name starts with ``{run_name_prefix}:`` (matches the same filter
        used by ``clean --runs``).  Output comes from the Jobs API's
        ``get_run_output`` endpoint, which returns the tail 5 MB of
        stdout/stderr captured by Databricks.
        """
        if run_id is None:
            prefix = f"{self.run_name_prefix}:"
            print(f"Finding latest run matching '{prefix}*'...")
            run_id = find_latest_run(self.ws, prefix)
            print(f"  Found run {run_id}")
            print()
        get_run_logs(self.ws, run_id)

    def validate(self, file: str | None = None) -> None:
        """Check compute readiness, list remote workspace, verify a file.

        Runs the compute strategy's ``validate`` — on classic that
        auto-starts the cluster if it is not already RUNNING; on
        serverless it is a no-op.  If *file* is given, verifies it exists
        under ``agent_modules/`` and raises :class:`RunnerError` otherwise.
        """
        self._compute().validate(self.ws)
        print()
        list_workspace(self.ws, self.config.databricks_workspace_dir)
        if file:
            check_file_exists(
                self.ws, self.config.databricks_workspace_dir, file
            )
        print()
        print("Validation complete.")

    def clean(
        self,
        *,
        workspace: bool = True,
        runs: bool = True,
        confirm: bool = True,
    ) -> None:
        """Delete the remote workspace directory and/or matching job runs."""
        print(f"{self.run_name_prefix}: cleanup")
        print("---")
        if workspace:
            print(
                f"  Workspace:  {self.config.databricks_workspace_dir} "
                f"(will be deleted recursively)"
            )
        if runs:
            print(
                f"  Job runs:   all one-time runs matching "
                f"'{self.run_name_prefix}:*'"
            )
        print()

        if confirm:
            answer = input("Proceed? [y/N] ").strip().lower()
            if answer not in ("y", "yes"):
                print("Cancelled.")
                return
            print()

        if workspace:
            clean_workspace(self.ws, self.config.databricks_workspace_dir)
            print()
        if runs:
            clean_runs(self.ws, f"{self.run_name_prefix}:")
            print()

        print("Cleanup complete.")

    # -- Main CLI entry point ------------------------------------------------

    def main(self, argv: list[str] | None = None) -> None:
        """Parse args and dispatch to the appropriate orchestration method."""
        from databricks_job_runner.cli import run_cli

        run_cli(self, argv)
