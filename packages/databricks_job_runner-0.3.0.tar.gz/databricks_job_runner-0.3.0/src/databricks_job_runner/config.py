"""Typed runner configuration and Databricks client initialization."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Literal, Self

from databricks.sdk import WorkspaceClient
from pydantic import BaseModel, ConfigDict, Field

from databricks_job_runner.errors import RunnerError

# Env keys that map directly onto RunnerConfig fields.  Everything else
# goes into ``extras`` for project-specific use via build_params.
CORE_KEYS = frozenset({
    "DATABRICKS_PROFILE",
    "DATABRICKS_COMPUTE_MODE",
    "DATABRICKS_CLUSTER_ID",
    "DATABRICKS_SERVERLESS_ENV_VERSION",
    "DATABRICKS_WORKSPACE_DIR",
    "DATABRICKS_VOLUME_PATH",
})

# Keys required regardless of compute mode.
_REQUIRED_ALWAYS = ("DATABRICKS_WORKSPACE_DIR",)

# Keys required only when DATABRICKS_COMPUTE_MODE=cluster (the default).
_REQUIRED_CLUSTER = ("DATABRICKS_CLUSTER_ID",)

ComputeMode = Literal["cluster", "serverless"]


class RunnerConfig(BaseModel):
    """Typed, immutable configuration loaded from a project's ``.env``.

    Core fields map to well-known env keys.  Any other keys found in the
    .env file are captured in :attr:`extras` for the ``build_params``
    callback to read.

    ``databricks_profile`` is optional: when unset, the SDK's unified auth
    falls back to env vars (``DATABRICKS_HOST``/``DATABRICKS_TOKEN``),
    Azure CLI, service principals, etc.

    ``databricks_cluster_id`` is conditionally required: only when
    ``databricks_compute_mode == "cluster"`` (the default).  On serverless
    it stays ``None``.
    """

    model_config = ConfigDict(frozen=True)

    databricks_profile: str | None = None
    databricks_compute_mode: ComputeMode = "cluster"
    databricks_cluster_id: str | None = None
    databricks_serverless_env_version: str = "3"
    databricks_workspace_dir: str
    databricks_volume_path: str | None = None
    extras: dict[str, str] = Field(default_factory=dict)

    @classmethod
    def from_env_file(cls, env_file: Path) -> Self:
        """Parse *env_file* and return a validated RunnerConfig.

        Side-effect: each parsed key is written into ``os.environ`` via
        ``setdefault`` so the Databricks SDK and other env-reading
        libraries can pick them up.  Pre-existing env vars take precedence
        over values from the file (standard 12-factor .env semantics:
        shell/CI env overrides the file, even when set to empty).

        Raises :class:`RunnerError` if the file is missing or required
        fields are not set.
        """
        if not env_file.exists():
            raise RunnerError(
                f"{env_file} not found.\n"
                "Copy .env.example to .env and fill in values."
            )

        parsed = _parse_env_file(env_file)
        for key, value in parsed.items():
            os.environ.setdefault(key, value)

        def pick(key: str) -> str:
            # After setdefault, os.environ holds either the pre-existing
            # shell/CI value or the .env value — whichever was set first.
            return os.environ.get(key, "")

        compute_mode_raw = pick("DATABRICKS_COMPUTE_MODE") or "cluster"
        if compute_mode_raw not in ("cluster", "serverless"):
            raise RunnerError(
                f"DATABRICKS_COMPUTE_MODE must be 'cluster' or 'serverless' "
                f"(got {compute_mode_raw!r})."
            )

        required = list(_REQUIRED_ALWAYS)
        if compute_mode_raw == "cluster":
            required.extend(_REQUIRED_CLUSTER)

        missing = [k for k in required if not pick(k)]
        if missing:
            raise RunnerError(
                f"required variables missing from {env_file}:\n"
                + "".join(f"  - {k}\n" for k in missing)
                + "Add them to .env and try again."
            )

        extras = {k: v for k, v in parsed.items() if k not in CORE_KEYS}

        return cls(
            databricks_profile=pick("DATABRICKS_PROFILE") or None,
            databricks_compute_mode=compute_mode_raw,
            databricks_cluster_id=pick("DATABRICKS_CLUSTER_ID") or None,
            databricks_serverless_env_version=(
                pick("DATABRICKS_SERVERLESS_ENV_VERSION") or "3"
            ),
            databricks_workspace_dir=pick("DATABRICKS_WORKSPACE_DIR"),
            databricks_volume_path=pick("DATABRICKS_VOLUME_PATH") or None,
            extras=extras,
        )


def _parse_env_file(env_file: Path) -> dict[str, str]:
    """Parse key=value pairs from a .env file.

    Handles ``#`` comments, blank lines, and surrounding single/double
    quotes (bash ``source`` does this automatically).
    """
    parsed: dict[str, str] = {}
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, sep, value = line.partition("=")
        if not sep:
            continue
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        parsed[key] = value
    return parsed


def make_client(profile: str | None = None) -> WorkspaceClient:
    """Create a WorkspaceClient.

    If *profile* is set, uses that Databricks CLI profile (the common case).
    Otherwise delegates to the SDK's unified auth, which auto-detects
    credentials from env vars (``DATABRICKS_HOST``/``DATABRICKS_TOKEN``),
    Azure CLI, service principals, etc.
    """
    if profile:
        return WorkspaceClient(profile=profile)
    return WorkspaceClient()
