"""CLI argparse setup and dispatch for :class:`Runner`.

This module owns the command-line interface.  :class:`Runner` exposes
orchestration methods; this module translates argparse results into
calls on them, and formats :class:`RunnerError` into friendly CLI
output before exiting non-zero.
"""

from __future__ import annotations

import argparse
import sys
from typing import TYPE_CHECKING

from databricks_job_runner.errors import RunnerError

if TYPE_CHECKING:
    from databricks_job_runner.runner import Runner


def run_cli(runner: "Runner", argv: list[str] | None = None) -> None:
    """Parse *argv* and dispatch to the matching method on *runner*.

    Catches :class:`RunnerError` from orchestration methods and exits
    with code 1 after printing a friendly message to stderr.
    """
    try:
        _dispatch(runner, argv)
    except RunnerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


def _dispatch(runner: "Runner", argv: list[str] | None) -> None:
    parser = _build_parser(runner)
    args = parser.parse_args(argv)

    if args.command == "upload":
        _dispatch_upload(runner, args)
    elif args.command == "submit":
        runner.submit(args.script, no_wait=args.no_wait)
    elif args.command == "validate":
        runner.validate(args.file)
    elif args.command == "logs":
        runner.logs(args.run_id)
    elif args.command == "clean":
        # If neither flag is set, clean both
        if not args.workspace and not args.runs:
            do_workspace, do_runs = True, True
        else:
            do_workspace, do_runs = args.workspace, args.runs
        runner.clean(
            workspace=do_workspace,
            runs=do_runs,
            confirm=not args.yes,
        )


def _build_parser(runner: "Runner") -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=f"Databricks job runner ({runner.run_name_prefix})",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # -- upload --------------------------------------------------------------
    p_upload = sub.add_parser(
        "upload", help="Upload scripts/wheels to Databricks"
    )
    p_upload.add_argument(
        "file",
        nargs="?",
        default="test_hello.py",
        help="File in agent_modules/ to upload (default: test_hello.py)",
    )
    p_upload.add_argument(
        "--all",
        action="store_true",
        help="Upload all agent_modules/*.py files",
    )
    wheel_help = (
        f"Build and upload the {runner.wheel_package} wheel"
        if runner.wheel_package
        else "Build and upload wheel (requires wheel_package to be configured)"
    )
    p_upload.add_argument("--wheel", action="store_true", help=wheel_help)

    # -- submit --------------------------------------------------------------
    p_submit = sub.add_parser(
        "submit", help="Submit a script as a Databricks job"
    )
    p_submit.add_argument(
        "script",
        nargs="?",
        default="test_hello.py",
        help="Script name in agent_modules/ (default: test_hello.py)",
    )
    p_submit.add_argument(
        "--no-wait",
        action="store_true",
        help="Submit without waiting for completion",
    )

    # -- validate ------------------------------------------------------------
    p_validate = sub.add_parser(
        "validate",
        help="List remote workspace contents and verify uploads",
    )
    p_validate.add_argument(
        "file",
        nargs="?",
        default=None,
        help="Optional agent_modules/ file to check for existence",
    )

    # -- logs ----------------------------------------------------------------
    p_logs = sub.add_parser(
        "logs",
        help="Print stdout/stderr from a submitted run",
    )
    p_logs.add_argument(
        "run_id",
        nargs="?",
        type=int,
        default=None,
        help=(
            "Parent run ID to fetch logs for. Defaults to the latest run "
            f"matching '{runner.run_name_prefix}:*'."
        ),
    )

    # -- clean ---------------------------------------------------------------
    p_clean = sub.add_parser(
        "clean", help="Clean up remote workspace and job runs"
    )
    p_clean.add_argument(
        "--workspace",
        action="store_true",
        help="Clean only remote workspace",
    )
    p_clean.add_argument(
        "--runs",
        action="store_true",
        help="Clean only job runs",
    )
    p_clean.add_argument(
        "--yes", "-y",
        action="store_true",
        help="Skip confirmation prompt",
    )

    return parser


def _dispatch_upload(runner: "Runner", args: argparse.Namespace) -> None:
    if args.wheel:
        runner.upload_wheel()
    elif args.all:
        runner.upload_all()
    else:
        runner.upload_file(args.file)
