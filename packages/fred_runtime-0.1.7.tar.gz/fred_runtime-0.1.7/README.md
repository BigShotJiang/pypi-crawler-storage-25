# Fred Runtime

`fred-runtime` provides platform adapters and infrastructure wiring for Fred v2 agents.

It is the missing middle layer between:
- `fred-sdk` (authoring + runtime contracts), and
- backend implementations (databases, Knowledge Flow, MCP, tracing, checkpointers).

## Why this package exists

- Keep `fred-sdk` pure and portable.
- Share runtime adapters across agentic backends and standalone agent apps.
- Make it easy for external agent repos (like `rags-v2`) to run v2 agents with
  consistent checkpointing and tool infrastructure.

## Scope (initial)

- SQL-backed checkpointer for LangGraph runtimes.
- Runtime helper utilities extracted from agentic-backend.

More runtime adapters will move here as the migration continues.
