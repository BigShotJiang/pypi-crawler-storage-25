from contextlib import contextmanager
from typing import NamedTuple

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

__all__ = [
    "VQOutput",
    "VectorQuantizer",
    "SoftVectorQuantizer",
]


class VQOutput(NamedTuple):
    q_z: torch.Tensor
    z_quantized: torch.Tensor
    dictionary_loss: torch.Tensor
    commitment_loss: torch.Tensor
    kl_loss: torch.Tensor
    num_samples: int


class VectorQuantizer(nn.Module):
    """Learnable quantized codebook. This is the 'z' stage of a VQ-VAE. That is, one can construct
    a VQ-VAE from this using some encoder and decoder, like

        z_e = encoder(x)
        q = vq(z_e)
        x_hat = decoder(quantized.z_quantized)

        loss = F.mse_loss(x_hat, x) + q.dictionary_loss + beta * q.commitment_loss

    where vq is an instance of this VectorQuantizer class.
    """

    # TODO - allow EMA update instead of dictionary loss.

    def __init__(self, feature_dim: int, num_tokens: int):
        super().__init__()
        self.d = feature_dim
        self.n = num_tokens

        self.codebook = nn.Embedding(num_embeddings=num_tokens, embedding_dim=feature_dim)

    def forward(self, z_encoded: torch.Tensor) -> VQOutput:
        z_encoded = torch.flatten(z_encoded, start_dim=1)

        diff = z_encoded[:, None, :] - self.codebook.weight[None, :, :]  # shape (batch, n, d)
        sqdiff = torch.sum(diff**2, dim=2)  # shape (batch, n)
        idx = torch.argmin(sqdiff, dim=1)  # Best codeword for each input, shape (batch,)
        q_z = F.one_hot(idx, self.n).float()
        z_quantized = self.codebook(idx)  # shape (batch, d)

        # Apply the straight-through trick so grad of z_encoded is copied to the output. This
        # provides a bridge between encoder and decoder so that any loss downstream of z_quantized
        # will also backpropagate through the encoder.
        z_quantized_but_encoder_grad = z_quantized + z_encoded - z_encoded.detach()

        # Add a dummy samples dimension so the interface is the same as SoftVectorQuantizer.
        z_quantized_but_encoder_grad = z_quantized_but_encoder_grad.unsqueeze(1)

        # Note: losses are calculated with a mean over the feature dim but no reduction applied
        # over the batch.
        return VQOutput(
            q_z=q_z,
            z_quantized=z_quantized_but_encoder_grad,
            dictionary_loss=torch.mean((z_encoded.detach() - z_quantized) ** 2, dim=-1),
            commitment_loss=torch.mean((z_encoded - z_quantized.detach()) ** 2, dim=-1),
            kl_loss=-np.log(self.n) * torch.ones(z_encoded.shape[0], device=z_encoded.device),
            num_samples=1,
        )


class SoftVectorQuantizer(nn.Module):
    """Like VectorQuantizer but where q_z is inferred with nonzero entropy. Assumes a generative
    model where z_e ~ normal(mean=z_q, cov=sigma**2 * eye(d)). Updates are now based on EM.

    See Roy, Aurko, Ashish Vaswani, Arvind Neelakantan, and Niki Parmar. “Theory and Experiments on
        Vector Quantized Autoencoders.” arXiv, July 20, 2018.
        https://doi.org/10.48550/arXiv.1805.11063.

    Unlike VectorQuantizer, qo use this class, q.kl_loss should be minimized as well.
    """

    # TODO - this class is broken. The conceptual error I made was first thinking of the encoder
    #  as producing a variational posterior over z, which led to confusion about how the discrete
    #  tokens k are sampled and used, and how to train the encoder with or without the STE. Then
    #  I tried again (current version) with the encoder as whatever function and no-grad on the
    #  E/M steps. This then decouples the encoder from the decoder but at least (I think) makes
    #  the EM update better encapsulated. The error is that q(k,z) here does not depend on x! The
    #  NEXT version cannot treat the quantizer as separate from the decoder. The quantizer must
    #  be responsible for computing q(k, z), and the decoder provides the necessary p(x|z). I'm
    #  not sure yet whether this will involve VBEM, STE, or something else.

    def __init__(self, feature_dim: int, num_tokens: int):
        super().__init__()
        self.d = feature_dim
        self.n = num_tokens

        self.codebook = nn.Embedding(num_embeddings=num_tokens, embedding_dim=feature_dim)
        self.sigma2 = nn.Parameter(torch.tensor([feature_dim], dtype=torch.float32))

    @contextmanager
    def no_params_grad(self):
        """Context manager in which model parameters have no grads but input/output tensors may."""
        status = {}
        for k, v in self.named_parameters():
            status[k] = v.requires_grad
            v.requires_grad_(False)

        yield

        for k, v in self.named_parameters():
            v.requires_grad_(status[k])

    def e_step(self, z_encoded: torch.Tensor):
        with self.no_params_grad():
            z_encoded = torch.flatten(z_encoded, start_dim=1)

            diff = z_encoded[:, None, :] - self.codebook.weight[None, :, :]  # shape (batch, n, d)
            sqdiff = torch.sum(diff**2, dim=2)  # shape (batch, n)
            log_q_z = -0.5 * sqdiff / self.sigma2.abs()  # shape (batch, n)
            q_z = torch.softmax(log_q_z, dim=-1)  # shape (batch, n)
            return q_z, log_q_z

    def m_step(self, z_encoded: torch.Tensor, k_samples: torch.Tensor):
        with self.no_params_grad():
            z_encoded = torch.flatten(z_encoded, start_dim=1)

            # Index into codebook, shape (b, num_samples, d)
            z_assignment = self.codebook.weight[k_samples]

            # Measure the mean squared error so we can update sigma.
            new_sigma2 = torch.mean((z_encoded[:, None, :] - z_assignment) ** 2, dim=0)

            # Calculate new values for the codebook vectors
            batch_size, num_samples = k_samples.shape

            # Create one-hot encoding for k_samples
            one_hot = torch.zeros(batch_size, num_samples, self.n, device=z_encoded.device)
            one_hot.scatter_(2, k_samples.unsqueeze(-1), 1)

            # Expand z_encoded to match one_hot shape (shape (batch, num_samples, d))
            z_expanded = z_encoded.unsqueeze(1).expand(-1, num_samples, -1)

            # Compute sum
            z_sum = torch.einsum("bsn,bsd->nd", one_hot, z_expanded)

            # Divide by count per index (shape (n,))
            counts = one_hot.sum(dim=(0, 1)) + 1e-9

            new_codebook = z_sum / counts[:, None]

            return new_codebook, counts, new_sigma2

    def em_update_as_loss(self, z_encoded: torch.Tensor, k_samples: torch.Tensor):
        # Do E and M steps without calculating any loss or grads.
        new_codebook, counts, new_sigma2 = self.m_step(z_encoded, k_samples)

        # Create pseudo 'losses' so that the parameter gradients point in the direction of the new
        # values calculated in the M-step. That is, these losses are such that loss.backward() will
        # populate the codebook.grad and sigma2.grad tensors with values pointing in the direction
        # of the M-step values.
        sigma2_loss = torch.sum((self.sigma2 - new_sigma2) ** 2)
        weighted_average = counts[:, None] / torch.sum(counts)
        codebook_loss = torch.sum(weighted_average * (self.codebook.weight - new_codebook) ** 2)

        return codebook_loss, sigma2_loss

    def forward(self, z_encoded: torch.Tensor, num_samples: int = 1) -> VQOutput:
        q_z, log_q_z = self.e_step(z_encoded)
        k_samples = torch.multinomial(q_z, num_samples=num_samples)  # shape (batch, num_samples)

        # Instead of dictionary loss, we detach z_encoded and generate a pseudo-loss from the EM
        # update. Importantly, neither the E-step nor the M-step generates any torch gradients.
        codebook_loss, sigma2_loss = self.em_update_as_loss(z_encoded.detach(), k_samples)

        # Index into codebook, shape (b, num_samples, d)
        z_assignment = self.codebook.weight[k_samples]

        # Straight-through connection between encoder and decoder
        z_assignment_with_encoder_grad = (
            z_assignment + z_encoded[:, None, :] - z_encoded[:, None, :].detach()
        )

        # Reparameterization trick so that z_assignment also depends on self.sigma2
        z_assignment_noised = (
            z_assignment_with_encoder_grad
            + torch.randn_like(z_assignment_with_encoder_grad) * self.sigma2.sqrt()
        )

        # Instead of commitment loss, we use the inferred posterior mean over z from the E-step
        # as a target for training the encoder. This decouples the encoder from the decoder, but
        # has a cleaner interpretation of (1) fitting the decoder as a generative model with EM, and
        # (2) training the encoder to produce a posterior mean that is close to the codebook, just
        # for the purposes of 'seeding' the EM algorithm. We no longer have a strong interpretation
        # of the encoder output *as* a variational posterior, but the E-step *is*.
        comm_loss = torch.sum((z_encoded[:, None, :] - z_assignment.detach()) ** 2, dim=(-1, -2))

        # Calculate KL(q||p), where p(k) = 1/n for all k.
        log_p = torch.tensor([-np.log(self.n)] * self.n, device=z_encoded.device)
        kl_q_p = torch.sum(q_z * (log_q_z - log_p), dim=1)

        return VQOutput(
            q_z=q_z,
            z_quantized=z_assignment_noised,
            dictionary_loss=codebook_loss + sigma2_loss,
            commitment_loss=comm_loss,
            kl_loss=kl_q_p,
            num_samples=num_samples,
        )


class VQVAE(nn.Module):
    def __init__(self, encoder: nn.Module, decoder: nn.Module, vq: nn.Module):
        super().__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.vq = vq

        self.vmap_decoder = torch.vmap(decoder, in_dims=1, out_dims=1)

    def forward(self, x: torch.Tensor):
        z = self.encoder(x)
        q = self.vq(z)
        x_hat = self.vmap_decoder(q.z_quantized)

        return x_hat, q
