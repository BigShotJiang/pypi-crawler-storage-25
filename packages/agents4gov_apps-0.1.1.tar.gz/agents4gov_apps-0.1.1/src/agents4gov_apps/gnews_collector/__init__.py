"""GNews Collector tools."""
