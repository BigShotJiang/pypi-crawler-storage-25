class AmongAPIError(Exception):
  pass

class InvalidTokenError(AmongAPIError):
  pass

class AccountBannedError(AmongAPIError):
  pass

class RateLimitedError(AmongAPIError):
  pass

class LobbyJoinError(AmongAPIError):
  pass

class ChatMessageNotFound(AmongAPIError):
  pass