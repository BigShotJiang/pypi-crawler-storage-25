import asyncio
from typing import Optional, Dict, List, Callable, Awaitable
from .client import AmongUsClient

class gamePhase:
  lobby = 'lobby'
  tasks = 'tasks'
  discussion = 'discussion'
  voting = 'voting'
  
class gameTracker:
  def __init__(self, region: str = 'North America', bot_name: str = 'AmongMute'):
    self.client = AmongUsClient(name=bot_name, region=region)
    self.phase = gamePhase.lobby
    self.players: Dict[str, dict] = {}
    self._phase_callbacks: List[Callable[[str], Awaitable]] = []
    self._player_callbacks: List[Callable[[str, bool], Awaitable]] = []
    
    self.client.set_chat_callback(None)
    original_process = self.client.process_packet
    
    async def new_process(data):
      await original_process(data)
      self.phase = self.client.phase
      
    self.client.process_packet = new_process
  
  async def connect(self):
    await self.client.connect()
  
  async def join_lobby(self, code: str) -> bool:
    return await self.client.join_lobby(code)
  
  async def close(self):
    await self.client.close()
  
  def get_players_snapshot(self) -> List[dict]:
    return [{'name': n, 'is_alive': d.get('is_alive', True)} for n, d in self.players.items()]
