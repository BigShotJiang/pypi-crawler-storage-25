import asyncio
import socket
import struct
import time
from typing import Optional, Callable, Dict, List, Tuple
from .exceptions import LobbyJoinError

master_servers = {
  'North America': ('35.208.131.228', 22023),
  'Europe': ('34.105.159.187', 22023),
  'Asia': ('34.92.171.177', 22023),
}

op_hello = 0x01
op_redirect = 0x02
op_game_join = 0x03 # we do our own join request
op_game_state = 0x04 # incoming game state update
op_player_info = 0x05 # incoming player info
op_chat_message = 0x06 # incoming chat message

class AmongUsClient:
  def __init__(self, name: str = 'AmongVerify', region: str = 'North America'):
    self.name = name
    self.region = region
    self.sock: Optional[socket.socket] = None
    self.client_id = int(time.time() * 1000) & 0xFFFFFFFF
    self.connected = False
    self.game_server: Optional[Tuple[str, int]] = None
    self.phase = 'lobby'
    self.players: Dict[str, dict] = {}
    self.chat_queue = asyncio.Queue()
    self.recv_task = None
    self.on_chat_cb: Optional[Callable] = None
  async def connect(self):
    host, port = master_servers.get(self.region, master_servers['North America'])
    self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    self.sock.setblocking(False)
    self.sock.bind(('0.0.0.0', 0))
    
    await self.send_raw(struct.pack('<B I', op_hello, self.client_id), host, port)
    
    loop = asyncio.get_event_loop()
    
    data, addr = await loop.sock_recvfrom(self.sock, 4096)
    if len(data) < 2 or data[0] != op_redirect:
      raise LobbyJoinError('Did not receive a valid redirect from master server')
    
    ip_bytes = data[1:5]
    port = struct.unpack_from('>H', data, 5)[0]
    self.game_server = (socket.inet_ntoa(ip_bytes), port)
    
    self.connected = True
    self.recv_task = asyncio.create_task(self.recv_loop())
    
  async def send_raw(self, data: bytes, host: str, port: int):
    loop = asyncio.get_event_loop()
    await loop.sock_sendto(self.sock, data, (host, port))
  
  async def recv_loop(self):
    loop = asyncio.get_event_loop()
    while True:
      try:
        data, addr = await loop.sock_recvfrom(self.sock, 4096)
        self.process_packet(data)
      except Exception:
        pass
      
  def process_packet(self, data: bytes):
    if len(data) < 1:
      return
    op = data[0]
    if op == op_game_state:
      self.handle_game_state(data[1:])
    elif op == op_player_info:
      self.handle_player_info(data[1:])
    elif op == op_chat_message:
      self.handle_chat(data[1:])
      
  def handle_game_state(self, data):
    if len(data) >= 1:
      phase_id = data[0]
      phases = {0: 'lobby', 1: 'tasks', 2: 'discussion', 3: 'voting'}
      self.phase = phases.get(phase_id, 'lobby')
  
  def handle_player_info(self, data):
    pass
  
  def handle_chat(self, data):
    if len(data) < 2:
      return
    try:
      msg_len = data[0]
      msg = data[1:1+msg_len].decode('utf-8', errors='ignore')
      if self.on_chat_cb:
        asyncio.create_task(self.on_chat_cb(msg))
      self.chat_queue.put_nowait(msg)
    except:
      pass
  
  def set_chat_callback(self, callback: Callable):
    self.on_chat_cb = callback
  
  async def join_lobby(self, code: str) -> bool:
    if not self.game_server:
      raise LobbyJoinError('No game server, call connect() first :3')
    packet = struct.pack('<B I 6s', op_game_join, self.client_id, code.upper().encode())
    host, port = self.game_server
    await self.send_raw(packet, host, port)
    
    try:
      await asyncio.wait_for(asyncio.sleep(0.5), timeout=10.0)
      return True
    except asyncio.TimeoutError:
      return False
      
  async def close(self):
    if self.recv_task:
      self.recv_task.cancel()
    if self.sock:
      self.sock.close()
    self.connected = False
