import requests
import time
import threading
import random
from dataclasses import dataclass
from typing import Optional, Dict, Any
from queue import Queue, Empty
from .exceptions import *

api_base = 'https://api.innersloth.com'
user_agent = 'AmongUs/2024.11.26 (Windows; Steam)'

last_request_time = 0
min_interval = 1.0
working_proxies = Queue()
proxy_fetch_interval = 7200
proxy_refresh_list = []

def rate_limit():
  global last_request_time
  elapsed = time.time() - last_request_time
  if elapsed < min_interval:
    time.sleep(min_interval - elapsed)
  last_request_time = time.time()

def free_proxies():
  try:
    resp = requests.get(
      'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=protocolipport&format=json',
      timeout=10
    )
    if resp.status_code == 200:
      data = resp.json()
      return [
        p['proxy'] for p in data['proxies']
        if p['protocol'] == 'http'
      ]
  except:
    pass
  return []

def test_proxy(addr):
  proxy = {'http': f'http://{addr}', 'https': f'http://{addr}'}
  try:
    resp = requests.get(
      'https://api.innersloth.com/api/v1/public/player/apple-orange-banana',
      proxies=proxy,
      timeout=5,
      headers={'User-Agent': user_agent}
    )
    return resp.status_code == 200
  except:
    return False

def proxy_refresh():
  while True:
    fresh = free_proxies()
    random.shuffle(fresh)
    good = []
    for addr in fresh:
      if test_proxy(addr):
        good.append(addr)
        if len(good) >= 3:
          break
    if good:
      while not working_proxies.empty():
        try:
          working_proxies.get_nowait()
        except Empty:
          break
      for addr in good:
        working_proxies.put(addr)
    else:
      pass
    
    if working_proxies.empty() and proxy_refresh_list:
      for addr in proxy_refresh_list:
        working_proxies.put(addr)
    
    time.sleep(proxy_fetch_interval)

thread = threading.Thread(target=proxy_refresh, daemon=True)
thread.start()

@dataclass
class tokenVerificationResult:
  valid: bool
  puid: Optional[str] = None
  name: Optional[str] = None
  level: Optional[int] = None
  friend_code: Optional[str] = None
  platform: Optional[str] = None
  cosmetics: Optional[list] = None
  raw_data: Optional[Dict] = None
  error: Optional[str] = None
  
def verify_token(token: str, timeout: int = 15, proxies: Optional[Dict] = None) -> tokenVerificationResult:
  rate_limit()
  session = requests.Session()
  session.headers.update({
    'User-Agent': user_agent,
    'Accept': 'application/json',
    'Authorization': f'Bearer {token}'
  })
  if proxies is None:
    try:
      addr = working_proxies.get_nowait()
      proxies = {'http': f'http://{addr}', 'https': f'http://{addr}'}
      working_proxies.put(addr)
    except Empty:
      proxies = None
  
  if proxies:
    session.proxies.update(proxies)
    
  try:
    resp = session.get(f'{api_base}/api/v1/user', timeout=timeout)
    if resp.status_code == 200:
      data = resp.json()
      return tokenVerificationResult(
        valid = True,
        puid=data.get('puid'),
        name=data.get('name'),
        level=data.get('level'),
        friend_code=data.get('friendCode'),
        platform=data.get('lastPlatform'),
        cosmetics=data.get('cosmetics', []),
        raw_data=data,
      )
    elif resp.status_code == 401:
      raise InvalidTokenError('Token invalid or expired')
    elif resp.status_code == 403:
      raise AccountBannedError('Account banned or cloudflare block')
    elif resp.status_code == 429:
      raise RateLimitedError('Rate limit exceeded')
    else:
      raise AmongAPIError(f'HTTP {resp.status_code}')
  except requests.exceptions.Timeout:
    return tokenVerificationResult(valid=False, error='Connection timeout')
  except requests.exceptions.ConnectionError:
    return tokenVerificationResult(valid=False, error='Network error')
  except AmongAPIError as e:
    return tokenVerificationResult(valid=False, error=str(e))
  except Exception as e:
    return tokenVerificationResult(valid=False, error=f'Unexpected: {e}')
    
def get_public_profile(puid: str, proxies: Optional[Dict] = None) -> Optional[Dict]:
  rate_limit()
  headers = {'User-Agent': user_agent}
  try:
    resp = requests.get(
      f'{api_base}/api/v1/player/public/{puid}',
      headers=headers,
      proxies=proxies,
      timeout=10
    )
    return resp.json() if resp.status_code == 200 else None
  except:
    return None
    
def send_friend_request(token: str, target_puid: str, timeout: int = 10) -> bool:
  rate_limit()
  headers = {
    'Authorization': f'Bearer {token}',
    'User-Agent': user_agent,
    'Content-Type': 'application/json'
  }
  payload = {'puid': target_puid}
  try:
    resp = requests.post(
      f'{api_base}/api/v1/friendlist',
      headers=headers,
      json=payload,
      timeout=timeout
    )
    return resp.status_code == 200
  except:
    return False
