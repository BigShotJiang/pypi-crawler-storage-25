import asyncio
from .client import AmongUsClient
from .exceptions import LobbyJoinError, ChatMessageNotFound

class lobbyValidator:
  def __init__(self, region: str = 'North America', bot_name: str = 'AmongVerify'):
    self.client = AmongUsClient(name=bot_name, region=region)
    self.chat_messages: List[str] = []
    self._target_username: Optional[str] = None
    self.chat_found = asyncio.Event()
    
  async def _on_chat(self, message: str):
    if self._target_username and self._target_username.lower() in message.lower():
      self.chat_found.set()
      
  async def connect(self):
    self.client.set_chat_callback(self._on_chat)
    await self.client.connect()
    
  async def join_lobby(self, code: str) -> bool:
    return await self.client.join_lobby(code)
      
  async def wait_for_chat_message(self, expected_text: str, timeout: float = 30.0) -> bool:
    self._target_username = expected_text
    try:
      await asyncio.wait_for(self.chat_found.wait(), timeout=timeout)
      return True
    except asyncio.TimeoutError:
      return False
      
  async def close(self):
    await self.client.close()
      
