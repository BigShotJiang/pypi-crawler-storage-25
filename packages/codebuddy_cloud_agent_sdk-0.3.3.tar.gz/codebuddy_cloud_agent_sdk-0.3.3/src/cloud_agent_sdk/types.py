"""
公共数据类型（CodeBuddy 控制面契约）

字段命名策略：
- Python 代码侧：snake_case（``runtime_name``）
- JSON 传输侧：camelCase（``runtimeName``）
- Pydantic 透明处理：``ConfigDict(alias_generator=to_camel, populate_by_name=True)``
  → 写代码用 snake_case，序列化自动变 camelCase；反序列化支持两种

**只定义 CodeBuddy 自己的控制面类型**（Runtime / Session / Manifest 等）。
ACP 协议类型（``ContentBlock`` / ``SessionNotification`` / ``PromptResponse``）
不二次封装，用户直接 ``from acp.schema import ...``。
"""

from __future__ import annotations

from typing import Annotated, Any, Generic, Literal, TypeVar

from pydantic import BaseModel, BeforeValidator, ConfigDict
from pydantic.alias_generators import to_camel


def _coerce_int64_str(value: Any) -> Any:
    """服务端对 ``id`` / ``current_version_id`` / ``origin_runtime_id`` 返回 int64（数字），
    Python 端统一声明为 ``str`` 保持跨语言契约一致。这里把 int 自动转 str。

    Node SDK 通过 JSON 文本正则把 17+ 位纯数字加引号（避免 JS 大数精度丢失）。
    Python int 无精度问题，直接在反序列化阶段把 ``int`` 转 ``str`` 即可。
    """
    if isinstance(value, int) and not isinstance(value, bool):
        return str(value)
    return value


Int64Str = Annotated[str, BeforeValidator(_coerce_int64_str)]

__all__ = [
    # Manifest
    "ManifestRule",
    "ManifestSkill",
    "ManifestSubagent",
    "ManifestSlashCommand",
    "ManifestPlugin",
    "ManifestMcp",
    "ManifestWorkspace",
    "ManifestEnv",
    "ManifestSecret",
    "AgentManifest",
    # Runtime
    "RuntimeStatus",
    "AcpLink",
    "SandboxLink",
    "RuntimeLinks",
    "RuntimeBrief",
    "RuntimeInfo",
    "SandboxSpec",
    # Session
    "SessionStatus",
    "SessionBrief",
    "SessionInfo",
    # 控制面请求体
    "CreateRuntimeRequest",
    "UpdateRuntimeRequest",
    "CreateSessionRequest",
    "UpdateSessionRequest",
    # 通用
    "Pagination",
    "PageResult",
    "DeleteResult",
    "OpenApiHealth",
]


# ─── Pydantic 基类 ────────────────────────────────


class _Model(BaseModel):
    """SDK 内部所有 DTO 的基类。

    - ``alias_generator=to_camel`` → 序列化输出 camelCase
    - ``populate_by_name=True`` → 反序列化同时接受 snake_case / camelCase
    - ``extra="allow"`` → 允许服务端返回未知字段（前向兼容，对齐 Node 的 ``[k]: unknown``）
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        extra="allow",
    )


# ============================================================
# Agent Manifest
# ============================================================


class ManifestRule(_Model):
    """规则配置。"""

    name: str
    download_url: str
    scope: Literal["USER", "PROJECT"] | None = None


class ManifestSkill(_Model):
    """技能配置。"""

    name: str
    download_url: str | None = None
    scope: Literal["USER", "PROJECT"] | None = None


class ManifestSubagent(_Model):
    """子代理配置。"""

    name: str
    download_url: str | None = None
    scope: Literal["USER", "PROJECT"] | None = None


class ManifestSlashCommand(_Model):
    """Slash Command 配置。"""

    name: str
    download_url: str | None = None
    scope: Literal["USER", "PROJECT"] | None = None


class ManifestPlugin(_Model):
    """插件配置。"""

    name: str
    marketplace: str | None = None
    marketplace_url: str | None = None
    download_url: str | None = None


class ManifestMcp(_Model):
    """MCP 配置。"""

    name: str
    download_url: str
    scope: Literal["USER", "PROJECT"] | None = None


class ManifestWorkspace(_Model):
    """工作空间配置。"""

    name: str
    # 代码来源（三选一）
    repository: str | None = None
    ref: str | None = None
    depth: int | None = None
    include_submodules: bool | None = None
    download_url: str | None = None
    local_path: str | None = None
    # 模板
    templates_download_url: str | None = None
    # 初始化
    init_shell_command: str | None = None
    init_command: str | None = None


class ManifestEnv(_Model):
    """环境变量。"""

    key: str
    value: str


class ManifestSecret(_Model):
    """密钥。SDK 日志中 ``value`` 字段自动脱敏（见 internal/redact.py）。"""

    key: str
    value: str


class AgentManifest(_Model):
    """Agent Manifest 完整类型（按 manifest-spec.md v1.0）。"""

    # ─── 必填 ────────────────────────────────────
    id: str
    name: str
    manifest_version: str  # "1.0"

    # ─── 基础配置 ────────────────────────────────
    system_prompt: str | None = None
    system_prompt_file: str | None = None
    use_workspace_root: bool | None = None
    isolate_config_dir: bool | None = None
    settings: str | None = None  # settings.json 下载地址

    # ─── 能力与规范 ──────────────────────────────
    rules: list[ManifestRule] | None = None
    skills: list[ManifestSkill] | None = None
    subagents: list[ManifestSubagent] | None = None
    slash_commands: list[ManifestSlashCommand] | None = None
    plugins: list[ManifestPlugin] | None = None
    mcp: list[ManifestMcp] | None = None

    # ─── 工作空间 ────────────────────────────────
    workspaces: list[ManifestWorkspace] | None = None

    # ─── 环境配置 ────────────────────────────────
    secrets: list[ManifestSecret] | None = None
    envs: list[ManifestEnv] | None = None


# ============================================================
# Runtime
# ============================================================

RuntimeStatus = Literal["CREATING", "RUNNING", "PRE-STOPPED", "STOPPED", "FAILED"]


class AcpLink(_Model):
    """数据面 ACP 连接信息。"""

    url: str
    token: str
    token_expires_at: int  # Unix seconds（0 表示随沙箱生命周期）


class SandboxLink(_Model):
    """沙箱直连端点（E2B / AGS）。"""

    endpoint: str
    data_plane_endpoint: str
    sandbox_id: str


class RuntimeLinks(_Model):
    """Runtime 的数据面连接集合。仅 ``RUNNING`` 状态返回。"""

    acp_link: AcpLink | None = None
    sandbox_link: SandboxLink | None = None
    cluster_domain_suffix: str | None = None


class SandboxSpec(_Model):
    """Sandbox 规格配置（CPU / 内存 / 其他厂商扩展）。允许任意扩展字段。"""

    cpu: str | None = None
    memory: str | None = None


# ============================================================
# Session
# ============================================================

SessionStatus = Literal["CREATING", "ACTIVE", "IDLE", "TERMINATED"]


class SessionBrief(_Model):
    """Session 摘要（嵌在 RuntimeInfo.sessions 里）。"""

    session_id: Int64Str
    session_status: SessionStatus
    session_name: str | None = None


class SessionInfo(_Model):
    """Session 完整信息。"""

    runtime_id: Int64Str
    session_id: Int64Str
    session_name: str | None = None
    session_status: SessionStatus
    last_activity_at: str | None = None
    created_at: str
    updated_at: str


class RuntimeBrief(_Model):
    """Runtime 简要信息（列表接口返回，仅含 id/runtime_name/created_at）。"""

    id: Int64Str
    runtime_name: str
    created_at: str


class RuntimeInfo(_Model):
    """Runtime 完整信息。

    注意：服务端对 ``id`` / ``current_version_id`` / ``origin_runtime_id`` 返回 int64，
    Python 端统一声明为 ``str`` 保持跨语言契约一致（``Int64Str`` 会把 int 自动转 str）。
    """

    id: Int64Str
    runtime_name: str
    sandbox_template_id: str | None = None
    sandbox_spec: SandboxSpec | None = None
    status: RuntimeStatus
    current_version_id: Int64Str | None = None
    origin_runtime_id: Int64Str | None = None
    metadata: dict[str, str] | None = None
    failure_reason: str | None = None
    links: RuntimeLinks | None = None  # 仅 RUNNING 返回
    sessions: list[SessionBrief] = []
    created_at: str
    updated_at: str


# ============================================================
# 控制面请求体（REST API 契约镜像）
# ============================================================


class CreateRuntimeRequest(_Model):
    """``POST /runtimes`` 请求体。"""

    runtime_name: str
    agent_manifest: AgentManifest | None = None
    sandbox_template_id: str | None = None
    sandbox_spec: SandboxSpec | None = None
    sandbox_type: str | None = None
    visibility: Literal["PRIVATE", "PUBLIC"] | None = None
    metadata: dict[str, str] | None = None


class UpdateRuntimeRequest(_Model):
    """``POST /runtimes/{id}/update`` 请求体。"""

    runtime_name: str | None = None
    visibility: Literal["PRIVATE", "PUBLIC"] | None = None
    metadata: dict[str, str] | None = None


class CreateSessionRequest(_Model):
    """``POST /runtimes/{id}/sessions`` 请求体。"""

    session_id: str | None = None
    session_name: str | None = None
    agent_manifest: AgentManifest | None = None


class UpdateSessionRequest(_Model):
    """``POST /runtimes/{id}/sessions/{sid}/update`` 请求体。"""

    session_name: str | None = None
    agent_manifest: AgentManifest | None = None


# ============================================================
# 通用
# ============================================================


class Pagination(_Model):
    """分页元信息。"""

    page: int
    page_size: int
    total: int
    total_pages: int


T = TypeVar("T")


class PageResult(_Model, Generic[T]):
    """分页列表结果。"""

    items: list[T]
    pagination: Pagination


class DeleteResult(_Model):
    """软删除结果。"""

    code: str
    message: str
    runtime_id: Int64Str | None = None
    session_id: Int64Str | None = None


class OpenApiHealth(_Model):
    """ACP ``/acp/health`` 端点响应。"""

    session_alive: bool
    connection_alive: bool
    agent_id: str
    session_state: str | None = None
    recovered: bool
    recovery_action: Literal["load", "rebuild", "none"]
    queue_size: int
    capabilities: dict[str, Any]
