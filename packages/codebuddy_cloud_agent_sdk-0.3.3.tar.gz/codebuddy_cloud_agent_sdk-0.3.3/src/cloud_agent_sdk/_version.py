"""单一版本来源。

构建系统（hatchling）和运行时（``cloud_agent_sdk.__version__``）都从这里读取，
避免两处分叉。更新发布版本只需改此文件 + CHANGELOG.md。
"""

__version__ = "0.3.3"
