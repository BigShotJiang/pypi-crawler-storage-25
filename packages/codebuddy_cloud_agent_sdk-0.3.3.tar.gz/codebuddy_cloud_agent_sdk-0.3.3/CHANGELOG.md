# 更新日志

codebuddy-cloud-agent-sdk 的所有重要更新都会记录在这里。

遵循 [语义化版本](https://semver.org/spec/v2.0.0.html)。

## [未发布]

## [0.3.3] - 2026-05-09

### 🐛 修复

- **`runtimes.list()` 返回类型修正**：返回类型从 `PageResult[RuntimeInfo]` 改为 `PageResult[RuntimeBrief]`（仅含 `id` / `runtime_name` / `created_at`），与服务端实际返回保持一致
- **`source_app` 默认值**：未传 `source_app` 时统一 fallback 到 `'cloud-agent'`，避免服务端 fallback 到 `'default-app'` 导致 list 返回空

### 🎉 新功能

- **新增 `RuntimeBrief` 类型**：列表接口专用的轻量类型，需要完整信息（含 `status`）请使用 `runtimes.get(id)`

## [0.3.2] - 2026-05-07

### 🔧 功能改进

- **支持业务 API Key 认证**：开放平台创建的 API Key 现可直接用于 SDK 鉴权

## [0.3.1] - 2026-05-03

### 🎉 新功能

- **`RuntimeConnectOptions.headers` 透传到 ACP 连接**：自定义 header（如 `traceparent`、业务灰度 tag）现会随 ACP SSE GET 一起发出，支持分布式追踪跨数据面传播

### 🐛 问题修复

- **ACP 重连时不会丢失连接 ID**：重连中间态不会让正在等待 `_ready` 的 POST 请求使用旧 connection ID

### 兼容性

- Python 3.10+（3.10 / 3.11 / 3.12 / 3.13 / 3.14）
- 依赖：`httpx>=0.27` / `pydantic>=2.6` / `agent-client-protocol>=0.9,<1.0`

