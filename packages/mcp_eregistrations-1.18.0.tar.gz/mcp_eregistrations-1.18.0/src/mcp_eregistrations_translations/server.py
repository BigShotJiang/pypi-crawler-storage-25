from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-translations",
    instructions=(
        "Translation tools for eRegistrations services. "
        "Authoring: translation_status, translation_context, translate_batch. "
        "Governance: translation_instance_status, translation_rollback, "
        "translation_history, translation_audit_detail, translation_settings_*. "
        "Safety: ds_system_translate_batch requires confirm_affects_global_catalog. "
        "Introspection: translation_categories, translation_global_status."
    ),
)

import mcp_eregistrations_translations.tools.audit_check  # noqa: F401, E402
import mcp_eregistrations_translations.tools.audit_detail  # noqa: F401, E402
import mcp_eregistrations_translations.tools.categories  # noqa: F401, E402
import mcp_eregistrations_translations.tools.context  # noqa: F401, E402
import mcp_eregistrations_translations.tools.delete  # noqa: F401, E402
import mcp_eregistrations_translations.tools.diff  # noqa: F401, E402
import mcp_eregistrations_translations.tools.ds_system  # noqa: F401, E402
import mcp_eregistrations_translations.tools.ds_system_write  # noqa: F401, E402
import mcp_eregistrations_translations.tools.global_sync  # noqa: F401, E402
import mcp_eregistrations_translations.tools.glossary  # noqa: F401, E402
import mcp_eregistrations_translations.tools.history  # noqa: F401, E402
import mcp_eregistrations_translations.tools.instance_status  # noqa: F401, E402
import mcp_eregistrations_translations.tools.replace_or_create  # noqa: F401, E402
import mcp_eregistrations_translations.tools.rollback  # noqa: F401, E402
import mcp_eregistrations_translations.tools.search  # noqa: F401, E402
import mcp_eregistrations_translations.tools.settings  # noqa: F401, E402
import mcp_eregistrations_translations.tools.status  # noqa: F401, E402
import mcp_eregistrations_translations.tools.write  # noqa: F401, E402
