"""Pydantic models for translation tools."""

from __future__ import annotations

from pydantic import BaseModel


class TranslationEntry(BaseModel):
    """A single translatable string with context."""

    key: str
    english: str
    reference: str | None = None
    location: str
    context: str
    field_type: str | None = None
    gdb_source: str | None = None
    current: str | None = None


class PaginationInfo(BaseModel):
    page: int
    page_size: int
    total_strings: int
    total_pages: int


class GlobalTranslationStatus(BaseModel):
    """Sync status between an instance and the Global Translation Service.

    Produced by translation_global_status. Callers decide whether to run
    translation_global_reload based on reload_recommended.
    """

    instance: str
    language: str
    reload_recommended: bool
    probed_keys: list[str]
    missing_keys: list[str]
    sample_resolved: dict[str, str]
    cache_size: int
    recommendation: str


class GlobalTranslationReloadResult(BaseModel):
    """Result of a translation_global_reload execution.

    `created` / `updated` / `duration_ms` are parsed from the upstream
    message string. `raw_message` preserves the original for traceability.
    """

    instance: str
    created: int
    updated: int
    duration_ms: int
    status: str
    raw_message: str
    audit_id: str
    forced: bool
