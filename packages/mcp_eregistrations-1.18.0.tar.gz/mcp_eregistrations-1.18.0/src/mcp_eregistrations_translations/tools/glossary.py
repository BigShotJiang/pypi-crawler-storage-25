"""Glossary tool -- instance-wide term frequency."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.context.glossary import extract_glossary
from mcp_eregistrations_translations.server import mcp


@mcp.tool()
async def translation_glossary(
    target_lang: str,
    limit: int = 50,
    instance: str | None = None,
) -> dict[str, Any]:
    """Instance-wide translation term frequency for consistency.

    Uses pseudo-service-id "general" to query system-wide translations.

    Args:
        target_lang: Language code (e.g., "fr").
        limit: Max terms to return (default: 50, max: 200).
        instance: Instance profile name.

    Returns:
        dict with target_lang, terms, total_terms, showing.
    """
    limit = min(limit, 200)
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            rows = await client.get_all_translations("general", types=["DS", "BPA"])
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error fetching glossary: {e}") from e

    terms = extract_glossary(rows, target_lang, limit)
    return {
        "target_lang": target_lang,
        "terms": terms,
        "total_terms": len(terms),
        "showing": min(limit, len(terms)),
    }
