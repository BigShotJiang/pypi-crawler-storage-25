"""translation_delete — delete translation entries by ID. Audited."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import (
    get_audit_logger,
    get_current_user_email,
)
from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.server import mcp


@mcp.tool()
async def translation_delete(
    translation_ids: list[str],
    dry_run: bool = False,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete translation entries. Audited write.

    Wraps POST /translation/delete. Some locations require the
    TRANSLATION_MANAGER right; disallowed IDs come back in unauthorized_ids
    (NOT an error).

    Args:
        translation_ids: Translation entry IDs to delete.
        dry_run: Enumerate without writing (default: False).
        instance: Instance profile name.

    Returns:
        dict with requested_ids, deleted_ids, unauthorized_ids, audit_id, dry_run.
    """
    if not translation_ids:
        raise ToolError("translation_ids cannot be empty.")

    if dry_run:
        return {
            "dry_run": True,
            "requested_ids": translation_ids,
            "would_delete": len(translation_ids),
        }

    user_email = await get_current_user_email(instance)
    logger = await get_audit_logger(instance)
    audit_id = await logger.record_pending(
        user_email=user_email,
        operation_type="TRANSLATION_DELETE",
        object_type="TRANSLATION",
        params={"count": len(translation_ids), "ids": translation_ids},
    )

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            resp = await client.delete_translations(translation_ids)
    except TranslationBPAClientError as e:
        await logger.mark_failed(audit_id, error_message=str(e))
        raise ToolError(f"BPA API error during delete: {e}") from e

    deleted = resp.get("deletedIds", []) if isinstance(resp, dict) else []
    unauthorized = resp.get("unauthorizedIds", []) if isinstance(resp, dict) else []

    await logger.mark_success(
        audit_id,
        result={"deleted": len(deleted), "unauthorized": len(unauthorized)},
    )

    return {
        "requested_ids": translation_ids,
        "deleted_ids": deleted,
        "unauthorized_ids": unauthorized,
        "audit_id": audit_id,
        "dry_run": False,
    }
