"""translation_categories — expose the location → category taxonomy."""

from __future__ import annotations

from typing import Any

from mcp_eregistrations_translations.keys import CATEGORY_MAP, location_to_category
from mcp_eregistrations_translations.server import mcp

# Canonical location list is derived from CATEGORY_MAP (keys.py) so the
# taxonomy stays in sync with the mapping used by every other tool.
_LOCATIONS: list[str] = sorted(
    {loc for locations in CATEGORY_MAP.values() for loc in locations}
)


@mcp.tool()
async def translation_categories() -> dict[str, Any]:
    """List translation location to category mapping. Read-only.

    Useful before calling translation_context with a category filter,
    and for analysts asking "what can I filter on?".

    Returns:
        dict with categories (sorted list), location_map (location to category).
    """
    location_map = {loc: location_to_category(loc) for loc in _LOCATIONS}
    categories = sorted(set(location_map.values()))
    return {"categories": categories, "location_map": location_map}
