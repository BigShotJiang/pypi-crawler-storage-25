"""Translation audit / quality check tool."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.keys import count_coverage, location_to_category
from mcp_eregistrations_translations.server import mcp


@mcp.tool()
async def translation_audit_check(
    service_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Post-translation quality check.

    Args:
        service_id: BPA service UUID.
        instance: Instance profile name.

    Returns:
        dict with inconsistencies, missing, length_warnings, duplicate_sources.
    """
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            rows = await client.get_all_translations(service_id)
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error for service '{service_id}': {e}") from e

    inconsistencies = _find_inconsistencies(rows)
    missing = _count_missing(rows)
    length_warnings = _find_length_warnings(rows)
    duplicate_sources = _find_duplicate_sources(rows)

    return {
        "service_id": service_id,
        "inconsistencies": inconsistencies,
        "missing": missing,
        "length_warnings": length_warnings,
        "duplicate_sources": duplicate_sources,
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _find_inconsistencies(
    rows: list[dict[str, dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Find rows sharing the same English text but divergent translations."""
    # Group rows by English source text
    by_english: dict[str, list[dict[str, dict[str, Any]]]] = defaultdict(list)
    for row in rows:
        en_entry = row.get("en")
        if not en_entry:
            continue
        en_text = en_entry.get("localName") or ""
        if not en_text:
            continue
        by_english[en_text].append(row)

    results: list[dict[str, Any]] = []
    for en_text, group in by_english.items():
        if len(group) < 2:
            continue

        # For each non-English language, collect distinct non-empty translations
        lang_translations: dict[str, set[str]] = defaultdict(set)
        for row in group:
            for lang, gt in row.items():
                if lang == "en":
                    continue
                local_name = gt.get("localName") or ""
                if local_name:
                    lang_translations[lang].add(local_name)

        # Flag languages with 2+ distinct translations for the same English source
        divergent: dict[str, list[str]] = {}
        for lang, translations in lang_translations.items():
            if len(translations) >= 2:
                divergent[lang] = sorted(translations)

        if divergent:
            results.append(
                {
                    "english": en_text,
                    "occurrences": len(group),
                    "translations": divergent,
                    "note": (
                        f"Same English text has {len(group)} "
                        f"occurrences with divergent translations"
                        f" in: {', '.join(sorted(divergent))}"
                    ),
                }
            )

    return results


def _count_missing(
    rows: list[dict[str, dict[str, Any]]],
) -> dict[str, dict[str, Any]]:
    """Count missing translations per language per category."""
    coverage = count_coverage(rows)
    result: dict[str, dict[str, Any]] = {}

    # Per-language per-category breakdown
    cat_counts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for row in rows:
        sample = next(iter(row.values()))
        cat = location_to_category(sample.get("location", ""))
        for lang, gt in row.items():
            if not gt.get("localName"):
                cat_counts[lang][cat] += 1

    for lang, counts in coverage.items():
        total_missing = counts["missing"]
        if total_missing > 0:
            result[lang] = {
                "total": total_missing,
                "by_category": dict(cat_counts.get(lang, {})),
            }

    return result


def _find_length_warnings(
    rows: list[dict[str, dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Flag translations with ratio > 3.0 or < 0.3 vs English."""
    warnings: list[dict[str, Any]] = []

    for row in rows:
        en_entry = row.get("en")
        if not en_entry:
            continue
        en_text = en_entry.get("localName") or ""
        if not en_text:
            continue
        en_len = len(en_text)

        for lang, gt in row.items():
            if lang == "en":
                continue
            target_text = gt.get("localName") or ""
            if not target_text:
                continue
            target_len = len(target_text)
            ratio = target_len / en_len if en_len else 0.0
            if ratio > 3.0 or ratio < 0.3:
                sample = next(iter(row.values()))
                warnings.append(
                    {
                        "key": sample.get("fieldId", ""),
                        "english": en_text,
                        "english_len": en_len,
                        "lang": lang,
                        "translation": target_text,
                        "translation_len": target_len,
                        "ratio": round(ratio, 2),
                    }
                )

    return warnings


def _find_duplicate_sources(
    rows: list[dict[str, dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Find rows sharing the same fieldName across different locations."""
    # Group by fieldName
    by_field: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        sample = next(iter(row.values()))
        field_name = sample.get("fieldName", "")
        if not field_name:
            continue
        location = sample.get("location", "")
        by_field[field_name].append({"location": location})

    results: list[dict[str, Any]] = []
    for field_name, entries in by_field.items():
        locations = [e["location"] for e in entries]
        unique_locations = set(locations)
        if len(entries) > 1 and len(unique_locations) > 1:
            results.append(
                {
                    "fieldName": field_name,
                    "locations": sorted(unique_locations),
                    "count": len(entries),
                    "note": (
                        f"fieldName '{field_name}' appears in "
                        f"{len(unique_locations)} different locations"
                    ),
                }
            )

    return results
