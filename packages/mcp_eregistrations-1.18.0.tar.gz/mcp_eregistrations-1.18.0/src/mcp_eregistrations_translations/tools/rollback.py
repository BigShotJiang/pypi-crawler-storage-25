"""translation_rollback — undo a prior translate_batch using the audit snapshot."""

from __future__ import annotations

import asyncio
import contextlib
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import (
    get_audit_logger,
    get_current_user_email,
)
from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
)
from mcp_eregistrations_translations.keys import parse_composite_key
from mcp_eregistrations_translations.server import mcp

# Per-instance write fan-out cap. Intentionally separate from the read-fanout
# constant in instance_status.py — write path shouldn't inherit read's bounds.
_MAX_CONCURRENT = 10


@mcp.tool()
async def translation_rollback(
    audit_id: str,
    dry_run: bool = False,
    instance: str | None = None,
) -> dict[str, Any]:
    """Undo a translate_batch using its persisted snapshot. Audited write.

    Restores each entry's previous_value via update_local_translation, or
    deletes it if the original write was a creation (previous_value=None).

    Args:
        audit_id: ID of the TRANSLATE_BATCH audit entry to reverse.
        dry_run: Validate + enumerate without writing (default: False).
        instance: Instance profile name.

    Returns:
        dict with audit_id, source_audit_id, restored, failed, errors, dry_run.
    """
    logger = await get_audit_logger(instance)
    entry = await logger.get_entry(audit_id)
    if entry is None:
        raise ToolError(f"Audit entry not found: {audit_id}")
    if entry.operation_type != "TRANSLATE_BATCH":
        raise ToolError(
            f"Audit entry {audit_id} is not a TRANSLATE_BATCH "
            f"(got {entry.operation_type}) — cannot rollback."
        )

    state = await logger.get_rollback_state(audit_id)
    if state is None:
        raise ToolError(
            f"No rollback snapshot stored for audit {audit_id}. "
            f"Only translate_batch calls made after the snapshot-persistence "
            f"change support rollback."
        )

    entries: list[dict[str, Any]] = state.get("entries", [])
    if dry_run:
        return {
            "dry_run": True,
            "source_audit_id": audit_id,
            "would_restore": len(entries),
        }

    user_email = await get_current_user_email(instance)
    new_audit_id = await logger.record_pending(
        user_email=user_email,
        operation_type="TRANSLATION_ROLLBACK",
        object_type="TRANSLATION",
        params={"source_audit_id": audit_id, "count": len(entries)},
    )

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            semaphore = asyncio.Semaphore(_MAX_CONCURRENT)

            async def _revert_one(e: dict[str, Any]) -> tuple[bool, str | None]:
                async with semaphore:
                    try:
                        if e.get("previous_value") is None and e.get("gt_id"):
                            resp = await client.delete_translations([e["gt_id"]])
                            deleted_ids = (
                                resp.get("deletedIds", [])
                                if isinstance(resp, dict)
                                else []
                            )
                            if e["gt_id"] not in deleted_ids:
                                return False, (
                                    f"Delete did not confirm id {e['gt_id']}: {resp}"
                                )
                        else:
                            field_id, type_str, location = parse_composite_key(e["key"])
                            body = {
                                "id": e.get("gt_id"),
                                "languageCode": e["target_lang"],
                                "fieldId": field_id,
                                "fieldName": e.get("field_name", ""),
                                "location": location,
                                "type": type_str,
                                "localName": (
                                    e["previous_value"]
                                    if e.get("previous_value") is not None
                                    else ""
                                ),
                                "serviceId": e["service_id"],
                            }
                            await client.update_local_translation(e["service_id"], body)
                        return True, None
                    except Exception as exc:
                        return False, str(exc)

            results = await asyncio.gather(*[_revert_one(e) for e in entries])

        restored = sum(1 for ok, _ in results if ok)
        errors = [
            {"key": e["key"], "reason": err}
            for e, (ok, err) in zip(entries, results)
            if not ok
        ]
        failed = len(errors)

        await logger.mark_success(
            new_audit_id,
            result={
                "restored": restored,
                "failed": failed,
                "source_audit_id": audit_id,
            },
        )
    except Exception as exc:
        with contextlib.suppress(Exception):
            await logger.mark_failed(new_audit_id, error_message=str(exc))
        raise ToolError(f"Rollback aborted: {exc}") from exc

    return {
        "audit_id": new_audit_id,
        "source_audit_id": audit_id,
        "restored": restored,
        "failed": failed,
        "errors": errors,
        "dry_run": False,
    }
