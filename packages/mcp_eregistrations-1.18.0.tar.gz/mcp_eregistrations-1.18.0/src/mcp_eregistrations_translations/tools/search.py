"""Translation search tool."""

from __future__ import annotations

import asyncio
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.keys import extract_row_key
from mcp_eregistrations_translations.server import mcp


@mcp.tool()
async def translation_search(
    query: str,
    service_id: str | None = None,
    exact_match: bool = False,
    form_id: str | None = None,
    form_type: str | None = None,
    type_filter: list[str] | None = None,
    page: int = 1,
    page_size: int = 25,
    instance: str | None = None,
) -> dict[str, Any]:
    """Search translations by text.

    Args:
        service_id: BPA service UUID. Omit for instance-wide search.
        query: Search text (required, non-empty).
        exact_match: Exact match vs substring (default: False).
        form_id: Filter to specific form.
        form_type: Filter by form type.
        type_filter: Filter by TranslationType (default: ["DS", "BPA"]).
        page: Page number (default: 1).
        page_size: Results per page (default: 25).
        instance: Instance profile name.

    Returns:
        dict with results, total, pagination.
    """
    if service_id is None:
        return await _search_instance_wide(
            query=query,
            exact_match=exact_match,
            form_id=form_id,
            form_type=form_type,
            type_filter=type_filter,
            page=page,
            page_size=page_size,
            instance=instance,
        )

    if not query or not query.strip():
        raise ToolError("query parameter is required and cannot be empty")

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            kwargs: dict[str, Any] = {
                "exactMatch": exact_match,
                "pageNo": page,
                "pageSize": page_size,
            }
            if form_id:
                kwargs["formId"] = form_id
            if form_type:
                kwargs["formType"] = form_type
            if type_filter:
                kwargs["type"] = type_filter

            raw = await client.search_translations(service_id, query.strip(), **kwargs)
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error searching translations: {e}") from e

    # Transform matrix rows to flat results with composite keys
    results = []
    for row in raw.get("items", []):
        key = extract_row_key(row)
        entry: dict[str, Any] = {"key": key}
        for lang, gt in row.items():
            entry[f"{lang}_localName"] = gt.get("localName")
            if lang == "en":
                entry["english"] = gt.get("localName") or gt.get("fieldName")
                entry["location"] = gt.get("location")
        results.append(entry)

    return {
        "service_id": service_id,
        "query": query,
        "results": results,
        "total": raw.get("totalResults", 0),
        "page": page,
        "page_size": page_size,
    }


async def _search_instance_wide(
    query: str,
    exact_match: bool,
    form_id: str | None,
    form_type: str | None,
    type_filter: list[str] | None,
    page: int,
    page_size: int,
    instance: str | None,
) -> dict[str, Any]:
    if not query or not query.strip():
        raise ToolError("query parameter is required and cannot be empty")

    sem = asyncio.Semaphore(10)
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            services = await client.list_services()
            services = [s for s in services if s.get("active", True)]

            async def _one(svc: dict[str, Any]) -> list[dict[str, Any]]:
                async with sem:
                    # Pull everything matching from each service (pagination
                    # happens MCP-side across the union of results). Without
                    # this, a page_size cap per service would silently
                    # truncate service contributions and misreport `total`.
                    raw = await client.search_translations(
                        svc["id"],
                        query.strip(),
                        exactMatch=exact_match,
                        pageNo=1,
                        pageSize=1000,
                        **({"formId": form_id} if form_id else {}),
                        **({"formType": form_type} if form_type else {}),
                        **({"type": type_filter} if type_filter else {}),
                    )
                    out = []
                    for row in raw.get("items", []):
                        key = extract_row_key(row)
                        entry: dict[str, Any] = {
                            "service_id": svc["id"],
                            "service_name": svc.get("name", ""),
                            "key": key,
                        }
                        for lang, gt in row.items():
                            entry[f"{lang}_localName"] = gt.get("localName")
                            if lang == "en":
                                entry["english"] = gt.get("localName") or gt.get(
                                    "fieldName"
                                )
                                entry["location"] = gt.get("location")
                        out.append(entry)
                    return out

            all_rows = await asyncio.gather(*[_one(s) for s in services])
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error searching translations: {e}") from e

    flat = [r for chunk in all_rows for r in chunk]
    start = (page - 1) * page_size
    paged = flat[start : start + page_size]
    return {
        "service_id": None,
        "query": query,
        "results": paged,
        "total": len(flat),
        "page": page,
        "page_size": page_size,
    }
