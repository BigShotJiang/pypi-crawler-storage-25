"""GDB system tools — status, tag listing, instance listing, and authentication."""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

import httpx
from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_gdb.gdb_client import GDBClient, GDBClientError, translate_error
from mcp_eregistrations_gdb.server import mcp

logger = logging.getLogger(__name__)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_auth_token(instance: str | None = None) -> dict[str, Any]:
    """Get a raw bearer token for external integrations.

    Returns a short-lived access token (~5 min) for use in Node,
    shell, cron, or other non-Python runtimes that need GDB access.
    Requires prior authentication via gdb_auth_login.

    Args:
        instance: Instance name (default: auto-select).

    Returns:
        dict with access_token, token_endpoint, client_id, instance.
    """
    from mcp_eregistrations_common.auth import get_or_refresh_token
    from mcp_eregistrations_common.auth_store import get_refresh_context
    from mcp_eregistrations_common.config import resolve_auth_key

    inst = resolve_auth_key(instance)

    token = await get_or_refresh_token(inst)
    if not token:
        raise ToolError(
            f"No valid token for '{inst}'. Run gdb_auth_login first to authenticate."
        )

    # Include metadata so consumers can refresh independently
    ctx = get_refresh_context(inst)
    result: dict[str, Any] = {
        "access_token": token,
        "instance": inst,
    }
    if ctx:
        result["token_endpoint"] = ctx.get("token_endpoint", "")
        result["client_id"] = ctx.get("client_id", "")

    return result


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_status(
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Get GDB server health and version.

    Args:
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with version, status, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            result: dict[str, Any] = await client.get("/api/v1/status")
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="status") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_tag_list(
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """List all GDB tags.

    Args:
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with count, tags, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            data = await client.get("/api/v1/tags")
            raw = data if isinstance(data, list) else data.get("results", [])
            tags = [
                {
                    "id": t.get("id"),
                    "name": t.get("name"),
                }
                for t in raw
            ]
            return {
                "count": len(tags),
                "tags": tags,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="tag") from e


@mcp.tool()
async def gdb_auth_login(
    username: str | None = None,
    password: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Authenticate with eRegistrations. Shared across BPA/GDB/DS.

    Tries silent auto-login from stored credentials/tokens first.
    Only asks for credentials when no stored auth is available.

    Args:
        username: Username (email). Required on first login.
        password: Password. Required on first login.
        instance: Instance name (default: auto-select).

    Returns:
        dict with success, user_email, session_expires_in_minutes.
    """
    from mcp_eregistrations_common.auth import (
        get_or_refresh_token,
        keycloak_password_grant,
    )
    from mcp_eregistrations_common.auth_store import (
        get_credentials,
        store_credentials,
        store_refresh_context,
    )
    from mcp_eregistrations_common.config import (
        get_instance_config,
        resolve_auth_key,
    )

    inst = resolve_auth_key(instance)

    # 1. Try silent auto-login (stored tokens/credentials from BPA login)
    if not username:
        token = await get_or_refresh_token(inst)
        if token:
            creds = get_credentials(inst)
            return {
                "success": True,
                "message": f"Authenticated as {creds[0] if creds else 'stored user'}.",
                "user_email": creds[0] if creds else "stored user",
                "instance": inst,
            }

    # 2. Try provided credentials, fall back to stored
    if not username or not password:
        creds = get_credentials(inst)
        if creds:
            username, password = creds
    if not username or not password:
        return {
            "action_required": "ask_credentials",
            "message": (
                f"No stored credentials for '{inst}'. "
                "Provide username and password, or login via BPA MCP first."
            ),
            "instance": inst,
        }

    # 3. Keycloak password grant
    config = get_instance_config(inst)
    keycloak_url = config.get("keycloak_url")
    if not keycloak_url:
        raise ToolError(
            f"No keycloak_url for '{inst}'. "
            "For CAS instances, login via BPA MCP first — GDB will auto-authenticate."
        )

    try:
        result = await keycloak_password_grant(
            keycloak_url=keycloak_url,
            realm=config["keycloak_realm"],
            client_id=config.get("keycloak_client_id", "mcp-eregistrations-bpa"),
            username=username,
            password=password,
        )
    except Exception as e:
        raise ToolError(f"Authentication failed for '{inst}': {e}") from e

    store_credentials(
        inst,
        username,
        password,
        keycloak_url=keycloak_url,
        keycloak_realm=config["keycloak_realm"],
        client_id=config.get("keycloak_client_id", "mcp-eregistrations-bpa"),
    )
    store_refresh_context(
        inst,
        refresh_token=result.get("refresh_token", ""),
        token_endpoint=result["token_endpoint"],
        client_id=config.get("keycloak_client_id", "mcp-eregistrations-bpa"),
    )

    return {
        "success": True,
        "message": f"Authenticated as {username}.",
        "user_email": username,
        "instance": inst,
    }


# TODO(issue-84-followup): extract probe + diagnose pattern into
# common/auth_diagnose.py when BPA/DS/Keycloak mirror this tool.
async def _probe_gdb_status(
    *, gdb_url: str, token: str, trace_id: str
) -> dict[str, Any]:
    """Probe GET /api/v1/status with the given token, bypassing GDBClient.

    Uses a direct httpx call so the client's retry-on-401 cannot mask the
    diagnostic signal. Always returns a dict — on failure, ``error`` is set
    to ``"timeout"`` or ``"network"`` and ``status_code`` is None. Never raises.
    """
    url = f"{gdb_url.rstrip('/')}/api/v1/status"
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "X-Trace-Id": trace_id,
    }
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(url, headers=headers)
    except httpx.TimeoutException:
        logger.debug("gdb_auth_diagnose probe timeout")
        return {
            "status_code": None,
            "ok": False,
            "backend_version": None,
            "trace_id": trace_id,
            "error": "timeout",
        }
    except httpx.RequestError as exc:
        logger.debug("gdb_auth_diagnose probe network error: %s", type(exc).__name__)
        return {
            "status_code": None,
            "ok": False,
            "backend_version": None,
            "trace_id": trace_id,
            "error": "network",
        }

    backend_version: str | None = None
    if resp.status_code == 200:
        try:
            body = resp.json()
            if isinstance(body, dict):
                backend_version = body.get("version")
        except ValueError:
            pass

    return {
        "status_code": resp.status_code,
        "ok": resp.status_code == 200,
        "backend_version": backend_version,
        "trace_id": trace_id,
        "error": None,
    }


def _infer_auth_type(config: dict[str, Any]) -> str:
    """Derive auth_type from an instance config dict.

    Precedence: cas_url wins over keycloak (matches the auth path the MCP
    would actually take — if cas_url is set, CAS is used regardless of any
    keycloak_url also present).
    """
    if config.get("cas_url"):
        return "cas"
    if config.get("keycloak_url") and config.get("keycloak_realm"):
        return "keycloak"
    return "unknown"


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_auth_diagnose(
    instance: str | None = None,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Diagnose the current GDB auth state without mutating it.

    Reads the cached bearer token, decodes its claims (if JWT), and probes
    GET /api/v1/status directly to see whether the backend currently accepts
    the token. Safe, read-only, no re-authentication.

    Args:
        instance: Instance name (default: auto-select).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).

    Returns:
        dict with instance, auth_type, token_present, token_format,
        token_claims, refresh_context, probe, hints, trace_id.
    """
    from mcp_eregistrations_common.auth import (
        decode_jwt_claims,
        get_cached_token,
        get_last_refresh_failure,
    )
    from mcp_eregistrations_common.auth_store import get_refresh_context
    from mcp_eregistrations_common.config import get_instance_config, resolve_auth_key

    inst = resolve_auth_key(instance)
    tid = trace_id or uuid.uuid4().hex[:24]
    config = get_instance_config(inst)
    auth_type = _infer_auth_type(config)
    gdb_url = config.get("gdb_url", "")

    # Read cached token directly — no get_or_refresh_token, no mutations.
    token = get_cached_token(inst)
    token_present = bool(token)

    token_format: str | None = None
    token_claims_out: dict[str, Any] | None = None
    if token_present:
        raw_claims = decode_jwt_claims(token)  # type: ignore[arg-type]
        if raw_claims is None:
            token_format = "opaque"
        else:
            token_format = "jwt"
            exp_unix = (
                raw_claims.get("exp")
                if isinstance(raw_claims.get("exp"), int)
                else None
            )
            exp_remaining: int | None = None
            expired: bool | None = None
            if exp_unix is not None:
                exp_remaining = int(exp_unix - time.time())
                expired = exp_remaining < 0
            token_claims_out = {
                "iss": raw_claims.get("iss"),
                "sub": str(raw_claims.get("sub"))
                if raw_claims.get("sub") is not None
                else None,
                "email": raw_claims.get("email"),
                "roles": raw_claims.get("roles"),
                "exp_unix": exp_unix,
                "exp_seconds_remaining": exp_remaining,
                "expired": expired,
                "jti": raw_claims.get("jti"),
            }

    refresh_ctx = get_refresh_context(inst)
    refresh_out: dict[str, Any] | None = None
    if refresh_ctx is not None:
        refresh_out = {
            "token_endpoint": refresh_ctx.get("token_endpoint", ""),
            "client_id": refresh_ctx.get("client_id", ""),
            "has_refresh_token": bool(refresh_ctx.get("refresh_token")),
        }

    probe_out: dict[str, Any] | None = None
    probe_error_kind: str | None = None  # "timeout" | "network" | None
    if token_present and gdb_url and token is not None:
        raw_probe = await _probe_gdb_status(
            gdb_url=gdb_url,
            token=token,
            trace_id=tid,
        )
        probe_error_kind = raw_probe.get("error")
        if probe_error_kind is None:
            probe_out = {
                "status_code": raw_probe["status_code"],
                "ok": raw_probe["ok"],
                "backend_version": raw_probe["backend_version"],
                "trace_id": raw_probe["trace_id"],
            }

    refresh_failure = get_last_refresh_failure(inst)

    hints: list[str] = []
    if refresh_failure is not None:
        if auth_type == "cas":
            hints.append(
                f"Refresh failed: {refresh_failure}. CAS does not support "
                "unattended password re-authentication — re-run `auth_login` "
                "with browser flow via BPA MCP to obtain a fresh session."
            )
        else:
            hints.append(
                f"Refresh failed: {refresh_failure}. Run `gdb_auth_login` or "
                "`auth_login` via BPA MCP with credentials to re-authenticate."
            )
    if not token_present:
        if refresh_failure is None:
            hints.append(
                "No auth token cached. Run `gdb_auth_login` (Keycloak) or "
                "`auth_login` via BPA MCP (CAS) to acquire one."
            )
    elif token_format == "opaque":
        hints.append(
            "Token is present but not JWT-decodable. MCP will still send it as Bearer."
        )

    expired_flag = (
        token_claims_out.get("expired") if token_claims_out is not None else None
    )
    probe_ok = probe_out is not None and probe_out.get("ok") is True
    probe_status = probe_out.get("status_code") if probe_out is not None else None

    if expired_flag is True and probe_ok:
        hints.append(
            "Token claim says expired, but backend accepted it. Possible "
            "clock drift on this machine."
        )
    elif expired_flag is True and not probe_ok and probe_error_kind is None:
        remaining = token_claims_out["exp_seconds_remaining"]  # type: ignore[index]
        hints.append(
            f"Token expired {-remaining}s ago. Run `gdb_auth_login` to refresh."
        )

    if probe_status == 401 and expired_flag is not True:
        hints.append(
            "Token decodes OK and is not expired per claims, but "
            "`/api/v1/status` rejected it. Likely: revoked session, profile "
            "drift (run `instance_list`), or backend issuer/audience mismatch."
        )

    if probe_status == 404:
        hints.append(
            "Backend `/api/v1/status` endpoint missing at this version. "
            "Cannot live-probe auth."
        )

    if probe_ok and expired_flag is not True and token_format != "opaque":
        hints.append(
            "Authentication is working. If a specific write still 401s, "
            "open an issue with the trace_id."
        )

    if probe_error_kind == "timeout":
        hints.append(
            "Probe timed out after 5s. Network slow or backend unreachable — "
            "retry in a moment or check `gdb_url`."
        )
    elif probe_error_kind == "network":
        hints.append(
            "Could not reach `/api/v1/status` (network error). "
            "Check connectivity and `gdb_url`."
        )

    return {
        "instance": inst,
        "auth_type": auth_type,
        "token_present": token_present,
        "token_format": token_format,
        "token_claims": token_claims_out,
        "refresh_context": refresh_out,
        "refresh_failure": refresh_failure,
        "probe": probe_out,
        "hints": hints,
        "trace_id": tid,
    }
