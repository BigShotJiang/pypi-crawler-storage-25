/*
 * Ellipsoids.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEO_ELLIPSOID_HPP
#define FUNKTIONSKLEMPNER_GEO_ELLIPSOID_HPP

#include <funktionsklempner/concepts/rational.hpp>
#include <funktionsklempner/unit/units.hpp>
#include <funktionsklempner/cdecl.hpp>


/*
 * Can perform distance calculations with GeographicLib.
 */
#ifdef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
#include <memory>
#include <GeographicLib/Geodesic.hpp>
#endif


namespace funktionsklempner::geo {

/*
 * Support Boost.Units if possible:
 */
#ifndef FUNKTIONSKLEMPNER_NO_BOOST
    using half_axis_t = boost::units::quantity<boost::units::si::length>;

    template<concepts::Ratio R>
    constexpr half_axis_t half_axis_from_ratio()
    {
        return concepts::ratio_to_double<R>() * boost::units::si::meters;
    }

    /*
     * Support transform of half axis to GeographicLib expected meter distance:
     */
    #ifdef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
    namespace _gl {
        constexpr double to_meters(half_axis_t x)
        {
            return x / boost::units::si::meters;
        }
    }
    #endif

#else
    using half_axis_t = double;

    template<concepts::Ratio R>
    constexpr half_axis_t half_axis_from_ratio()
    {
        return concepts::ratio_to_double<R>;
    }

    /*
     * Support transform of half axis to GeographicLib expected meter distance:
     */
    #ifdef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
    namespace _gl {
        constexpr double to_meters(double x)
        {
            return x;
        }
    }
    #endif
#endif



template<
    concepts::Ratio large_half_axis,
    concepts::Ratio flattening
>
class Ellipsoid
{
public:
    constexpr static bool is_static = true;

    constexpr static half_axis_t a = half_axis_from_ratio<large_half_axis>();
    constexpr static double f = concepts::ratio_to_double<flattening>();

#ifdef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
public:
    static const GeographicLib::Geodesic& geodesic()
    {
        return geod;
    }

private:
    inline static const GeographicLib::Geodesic geod
        = GeographicLib::Geodesic(_gl::to_meters(a), f);
#endif
};



/*
 * Defining some well-known ellipsoids:
 */
namespace ellipsoids {

/* Based on:
 *   The Defense Mapping Agency (1991). Department of Defense World Geodetic
 *   System 1984 -- Its Definition and Relationships With Local Geodetic Systems.
 *   DMA Technical Report 8350.2. Second Edition.
 *   */
using WGS84 = Ellipsoid<
    std::ratio<6378137, 1>,
    std::ratio<1000000000, 298257223563> // 1 / 298.257223563
>;

/*
 * Based on:
 *   IOGP (2022). Geomatics guidance note number 7, Part 2.
 *   International Association of Oil & Gas Producers, Tech. Rep. 373-7-2.
 *
 * Note the 2 mm difference of this customary definition to Bessel's original
 * definition (see von Specht & Ziebarth, 2025. The Data-Optimized Oblique
 * Mercator Projection).
 */
using Bessel1841 = Ellipsoid<
    std::ratio<6377397155, 1000>,
    std::ratio<10000000, 2991528128> // 1.0 / 299.1528128
>;

}

/*
 * For user-defined ellipsoids:
 */
class UserEllipsoid
{
public:
    constexpr static bool is_static = false;

    /*
     * Constructor (depends on whether we support GeographicLib, in which
     * case we add a shared_ptr to a Geodesic, which allows us to compute
     * distances):
     */
#ifndef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
    constexpr UserEllipsoid(const half_axis_t& a, double f) noexcept : _a(a), _f(f)
    {}

    constexpr UserEllipsoid(UserEllipsoid&&) noexcept = default;
    constexpr UserEllipsoid(const UserEllipsoid&) noexcept = default;

    constexpr UserEllipsoid& operator=(const UserEllipsoid&) noexcept = default;
    constexpr UserEllipsoid& operator=(UserEllipsoid&&) noexcept = default;
#else

    UserEllipsoid(const half_axis_t& a, double f)
       : _a(a),
         _f(f),
         geod(std::make_shared<GeographicLib::Geodesic>(_gl::to_meters(a), f))
    {}


    UserEllipsoid() = delete;
    UserEllipsoid(UserEllipsoid&&) noexcept = default;
    UserEllipsoid(const UserEllipsoid&) noexcept = default;

    UserEllipsoid& operator=(const UserEllipsoid&) noexcept = default;
    UserEllipsoid& operator=(UserEllipsoid&&) noexcept = default;
#endif

    constexpr half_axis_t a() const noexcept
    {
        return _a;
    }

    constexpr double f() const noexcept
    {
        return _f;
    }

private:
    half_axis_t _a;
    double _f;

/*
 * Support for GeographicLib geodesics:
 */
#ifdef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
public:
    const GeographicLib::Geodesic& geodesic() const
    {
        return *geod;
    }

private:
    std::shared_ptr<const GeographicLib::Geodesic> geod;
#endif
};



/*
 * Concept capturing the Ellipsoid type:
 */
template<typename T>
constexpr static bool is_ellipsoid = false;

template<concepts::Ratio a, concepts::Ratio f>
constexpr static bool is_ellipsoid<Ellipsoid<a,f>> = true;

template<>
constexpr inline bool is_ellipsoid<UserEllipsoid> = true;


template<typename T>
concept Ellipsoid_t = is_ellipsoid<T>;


/*
 * Using the different ellipsoid classes to provide access to
 * GeographicLib Geodesics:
 */
template<geo::Ellipsoid_t ellps>
class GeodesicProvider
{
public:
    constexpr GeodesicProvider() noexcept = default;
    constexpr GeodesicProvider(const ellps&) noexcept {};

#ifdef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
    const GeographicLib::Geodesic& geodesic() const
    {
        return ellps::geodesic();
    }
#endif

    constexpr half_axis_t a() const
    {
        return ellps::a;
    }

    constexpr double f() const
    {
        return ellps::f;
    }
};

template<>
class GeodesicProvider<UserEllipsoid>
{
public:
    inline GeodesicProvider(GeodesicProvider&&) noexcept = default;
    inline GeodesicProvider(const GeodesicProvider&) noexcept = default;

    inline GeodesicProvider(UserEllipsoid&& ue) noexcept : ellps(std::move(ue))
    {}
    inline GeodesicProvider(const UserEllipsoid& ue) noexcept : ellps(ue)
    {}

    inline GeodesicProvider& operator=(const GeodesicProvider&) noexcept = default;
    inline GeodesicProvider& operator=(GeodesicProvider&&) noexcept = default;

#ifdef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
    inline const GeographicLib::Geodesic& geodesic() const
    {
        return ellps.geodesic();
    }
#endif

    constexpr half_axis_t a() const
    {
        return ellps.a();
    }

    constexpr double f() const
    {
        return ellps.f();
    }

    constexpr const UserEllipsoid& ellipsoid() const noexcept
    {
        return ellps;
    }

private:
    UserEllipsoid ellps;
};


/*
 * Parsing ellipsoids:
 */
using EllipsoidVariant = std::variant<
    ellipsoids::WGS84,
    ellipsoids::Bessel1841,
    UserEllipsoid
>;

using EllipsoidParameter = std::variant<
    std::u8string_view,
    std::pair<half_axis_t, double>
>;

EllipsoidVariant parse_ellipsoid(const EllipsoidParameter& param);


EllipsoidParameter make_ellipsoid_parameter(
    double ellipsoid_a,
    const char* ellipsoid_a_unit,
    double ellipsoid_f
);

EllipsoidParameter make_ellipsoid_parameter(
    const char* ellipsoid_identifier
);

EllipsoidVariant ellipsoid_object(size_t oid);

} // namespace funktionsklempner::geo


/*
 * The interface to the Python world:
 */
extern "C" {

FUNKTIONSKLEMPNER_DLLEXPORT
int FUNKTIONSKLEMPNER_CDECL funktionsklempner_create_ellipsoid_by_id(
    const char* identifier,
    size_t* oid,
    size_t* err_id
);

FUNKTIONSKLEMPNER_DLLEXPORT
int FUNKTIONSKLEMPNER_CDECL funktionsklempner_create_ellipsoid_by_parameter(
    double a,
    const char* a_unit,
    double f,
    size_t* oid,
    size_t* err_id
);

FUNKTIONSKLEMPNER_DLLEXPORT
int FUNKTIONSKLEMPNER_CDECL funktionsklempner_delete_ellipsoid(
    size_t oid
);




}

#endif