/*
 * Points on an ellipsoid of revolution (i.e., geographic points).
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */


#ifndef FUNKTIONSKLEMPNER_GEO_POINT_GEOGRAPHIC_HPP
#define FUNKTIONSKLEMPNER_GEO_POINT_GEOGRAPHIC_HPP

/*
 * Tie the use of geographic points to the availability of SI length
 * and plane angle units from Boost.Units
 */
#ifndef FUNKTIONSKLEMPNER_NO_BOOST

#include <funktionsklempner/geo/point/base.hpp>
#include <funktionsklempner/geo/point/euclidean.hpp>
#include <funktionsklempner/geo/ellipsoid.hpp>
#include <funktionsklempner/geo/distancecontext.hpp>
#include <funktionsklempner/concepts/geographic.hpp>
#include <funktionsklempner/util/macros.hpp>
#include <funktionsklempner/util/unit2quantity.hpp>
#include <funktionsklempner/wrapper/vectorview.hpp>

#include <boost/units/systems/si/plane_angle.hpp>
#include <boost/units/systems/si/length.hpp>


namespace funktionsklempner::geo {

/*
 * Arcdegrees:
 */
constexpr boost::units::quantity<boost::units::si::plane_angle>
    degrees = std::numbers::pi_v<double> / 180 * boost::units::si::radian;


template<
    concepts::GeographicCoordinateUnitTuple GeoCoords
>
constexpr static size_t dimensions
    = std::tuple_size_v<GeoCoords>;




using _GeoCoordinateArray = CoordinateArray<
    boost::units::quantity<boost::units::si::plane_angle>,
    2
>;


template<
    geo::Ellipsoid_t Ellipsoid,
    concepts::GeographicCoordinateUnitTuple CoordinateUnits,
    concepts::CoordinateTupleOfUnits<
        util::units_to_quantities<CoordinateUnits>
    > Coordinates
>
class GeographicPoint
   : public Point<
        Coordinates
     >,
     private GeodesicProvider<Ellipsoid>
{
public:
    constexpr static bool has_height = (std::tuple_size_v<CoordinateUnits> == 3);

    constexpr static bool has_user_ellipsoid
        = std::is_same_v<Ellipsoid, UserEllipsoid>;

    constexpr static bool is_view = wrapper::is_vector_quantity_view<Coordinates>;

    using Base = Point<Coordinates>;

    using QuantityTuple = util::units_to_quantities<CoordinateUnits>;

    template<size_t i>
    using reference = typename Coordinates::template reference<i>;

    template<size_t i>
    using const_reference = typename Base::template const_reference<i>;

    using Angle = boost::units::quantity<boost::units::si::plane_angle>;
    using Length = boost::units::quantity<boost::units::si::length>;

#ifndef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
    using Base::Point;
#else
    /*
     * Constructors with user-defined ellipsoid:
     */
    template<
        std::convertible_to<Angle> Latitude,
        std::convertible_to<Angle> Longitude,
        FUNKTIONSKLEMPNER_ENABLE_IF(has_user_ellipsoid && !has_height && !is_view)
    >
    GeographicPoint(
        Latitude&& lat,
        Longitude&& lon,
        const Ellipsoid& ellps
    )
       : Base(std::forward<Latitude>(lat), std::forward<Longitude>(lon)),
         GeodesicProvider<Ellipsoid>(ellps)
    {}


    template<
        std::convertible_to<Angle> Latitude,
        std::convertible_to<Angle> Longitude,
        std::convertible_to<Length> Height,
        FUNKTIONSKLEMPNER_ENABLE_IF(has_user_ellipsoid && has_height && !is_view)
    >
    GeographicPoint(
        Latitude&& lat,
        Longitude&& lon,
        Height&& height,
        const Ellipsoid& ellps
    )
       : Base(
            std::forward<Latitude>(lat),
            std::forward<Longitude>(lon),
            std::forward<Height>(height)
         ),
         GeodesicProvider<Ellipsoid>(ellps)
    {}


    template<
        typename Iterator,
        concepts::TupleOfBoostQuantities QT,
        FUNKTIONSKLEMPNER_ENABLE_IF(has_user_ellipsoid && is_view)
    >
    GeographicPoint(
        Iterator&& it,
        QT&& qt,
        const Ellipsoid& ellps
    )
       : Base(
            std::forward<Iterator>(it),
            std::forward<QT>(qt)
        ),
        GeodesicProvider<Ellipsoid>(ellps)
    {}



    template<
        FUNKTIONSKLEMPNER_ENABLE_IF(has_user_ellipsoid)
    >
    GeographicPoint(
        const Base& p,
        const Ellipsoid& ellps
    )
       : Base(p),
         GeodesicProvider<Ellipsoid>(ellps)
    {}


    /*
     * Constructors with constexpr, statically defined ellipsoids:
     */
    template<
        std::convertible_to<Angle> Latitude,
        std::convertible_to<Angle> Longitude,
        FUNKTIONSKLEMPNER_ENABLE_IF(!has_user_ellipsoid && !has_height && !is_view)
    >
    constexpr GeographicPoint(
        Latitude&& lat,
        Longitude&& lon
    ) noexcept
       : Base(std::forward<Latitude>(lat), std::forward<Longitude>(lon))
    {}


    template<
        std::convertible_to<Angle> Latitude,
        std::convertible_to<Angle> Longitude,
        std::convertible_to<Length> Height,
        FUNKTIONSKLEMPNER_ENABLE_IF(!has_user_ellipsoid && has_height && !is_view)
    >
    constexpr GeographicPoint(
        Latitude&& lat,
        Latitude&& lon,
        Height&& height
    ) noexcept
       : Base(
            std::forward<Latitude>(lat),
            std::forward<Longitude>(lon),
            std::forward<Height>(height)
        )
    {}


    template<
        typename It,
        concepts::TupleOfBoostQuantities QT,
        FUNKTIONSKLEMPNER_ENABLE_IF(!has_user_ellipsoid && is_view)
    >
    GeographicPoint(
        It&& it,
        QT&& qt
    )
       : Base(
            std::forward<It>(it),
            std::forward<QT>(qt)
        )
    {}


    template<
        typename E = Ellipsoid,
        FUNKTIONSKLEMPNER_ENABLE_IF(!has_user_ellipsoid)
    >
    constexpr GeographicPoint(
        const Base& p
    ) noexcept
       : Base(p)
    {}


    /*
     * Common constructor:
     */
    template<
        FUNKTIONSKLEMPNER_ENABLE_IF(has_user_ellipsoid)
    >
    GeographicPoint(
        const Base& p,
        const GeodesicProvider<Ellipsoid>& gp
    )
       : Base(p),
         GeodesicProvider<Ellipsoid>(gp)
    {}


    /*
     * Default constructors:
     */
    GeographicPoint(GeographicPoint&&) noexcept = default;
    GeographicPoint(const GeographicPoint&) noexcept = default;
#endif

    constexpr const_reference<0> lat() const noexcept
    {
        return this->template get<0>();
    }

    constexpr const_reference<1> lon() const noexcept
    {
        return this->template get<1>();
    }

    /*
     * Enable height if given:
     */
    template<
        size_t zid = 2,
        FUNKTIONSKLEMPNER_ENABLE_IF(has_height && zid == 2)
    >
    constexpr const_reference<zid> height() const noexcept
    {
        return this->template get<2>();
    }

#ifdef FUNKTIONSKLEMPNER_GEOGRAPHICLIB

    template<
        concepts::CoordinateTupleOfUnits<QuantityTuple> _Coordinates,
        FUNKTIONSKLEMPNER_ENABLE_IF(!has_height)
    >
    boost::units::quantity<boost::units::si::length>
    distance(
        const GeographicPoint<Ellipsoid, CoordinateUnits, _Coordinates>& other
    ) const
    {
        const GeographicLib::Geodesic& geod = this->geodesic();
        /* Outputs from the GeographicLib API: */
        double s12=0, azi1=0, azi2=0, m12=0, M12=0, M21=0, S12=0;

        /* Solve the inverse problem: */
        geod.Inverse(
            lat() / degrees,
            lon() / degrees,
            other.lat() / degrees,
            other.lon() / degrees,
            s12,
            azi1,
            azi2,
            m12,
            M12,
            M21,
            S12
        );

        /* Return the distance (GeographicLib returns s12 in meters): */
        return s12 * boost::units::si::meters;
    }


    template<
        concepts::CoordinateTupleOfUnits<QuantityTuple> _Coordinates,
        FUNKTIONSKLEMPNER_ENABLE_IF(!has_height)
    >
    boost::units::quantity<boost::units::si::length>
    distance(
        const GeographicPoint<Ellipsoid, CoordinateUnits, _Coordinates>& other,
        const DistanceContext& ctx
    ) const
    {
        return distance(other);
    }

#endif

    constexpr Point3D to_ECEF() const
    {
        using Length = boost::units::quantity<boost::units::si::length>;
        auto a2 = this->a() * this->a();
        double cphi = math::cos(lat());
        double sphi = math::sin(lat());
        // f = 1 - b/a -> b/a = 1-f -> (b/a)^2 = (f-1)^2
        double f_m_1 = this->f() - 1.0;
        double fm1_sq = f_m_1 * f_m_1;
        Length N = this->a() / math::sqrt(
            cphi * cphi + fm1_sq * sphi * sphi
        );
        return Point3D(
            N * cphi * math::cos(lon()),
            N * cphi * math::sin(lon()),
            fm1_sq * N * sphi
        );
    }

    template<
        concepts::CoordinateTupleOfUnits<
            boost::units::quantity<boost::units::si::length>,
            boost::units::quantity<boost::units::si::length>,
            boost::units::quantity<boost::units::si::length>
        > _Coordinates
    >
    constexpr static GeographicPoint
    from_ECEF(
        const EuclideanPoint<3, _Coordinates>& point,
        const Ellipsoid& ellps
    )
    {
        using Length = boost::units::quantity<boost::units::si::length>;
        using Angle = boost::units::quantity<
            boost::units::si::plane_angle
        >;

        /* Uses the method of Fukushima (2006), variant a),
         * which can be iterated to desired precision if needed.
         * Typically, as Fukushima has noted, this needs a maximum
         * of one iteration.
         */
        GeodesicProvider<Ellipsoid> gp(ellps);
        double f = gp.f();
        double e2 = 2.0 * f - f*f;
        double ec = math::sqrt(1.0 - e2);
        Length p = math::sqrt(
            point.x() * point.x() + point.y() * point.y()
        );
        double P = p / gp.a();
        double Z = ec * math::abs(point.z() / gp.a());

        /* Initial values for the iteration variables: */
        double T = Z / (ec * ec * P);

        /* Iterate: */
        double delta;
        int i;
        for (i=0; i<10; ++i){
            double G = math::sqrt(1 + T*T);
            double iG = 1.0 / G;

            double g = P * T - Z - e2 * T * iG;
            double g1 = P - e2 * iG * iG * iG;

            double T_next = T - g / g1;
            delta = math::abs(T_next - T);
            T = T_next;
            if (delta < 1e-14 * math::abs(T))
                break;
        }

        Angle lambda = math::atan2(point.y(), point.x());
        Angle phi = math::atan(T / ec)
            * ((point.z() < math::ZERO<Length>) ? -1.0 : 1.0);

        if constexpr (std::is_same_v<Ellipsoid, UserEllipsoid>)
            return GeographicPoint(phi, lambda, ellps);
        else
            return GeographicPoint(phi, lambda);
    }


    /*
     * If the ellipsoid is one of the static ones (e.g. WGS84),
     * create a shortcut function signature that eliminates the
     * need for a dummy instance (by creating it itself).
     */
    template<
        concepts::CoordinateTupleOfUnits<
            boost::units::quantity<boost::units::si::length>,
            boost::units::quantity<boost::units::si::length>,
            boost::units::quantity<boost::units::si::length>
        > _Coordinates,
        FUNKTIONSKLEMPNER_ENABLE_IF(!has_user_ellipsoid)
    >
    constexpr static GeographicPoint
    from_ECEF(
        const EuclideanPoint<3, _Coordinates>& point
    )
    {
        return from_ECEF(point, Ellipsoid());
    }
};



template<
    geo::Ellipsoid_t Ellipsoid
>
using GeographicPoint2D = GeographicPoint<
    Ellipsoid,
    concepts::geographic::_GeographicUnits,
    CoordinateTuple<
        boost::units::quantity<boost::units::si::plane_angle>,
        boost::units::quantity<boost::units::si::plane_angle>
    >
>;

template<
    geo::Ellipsoid_t Ellipsoid
>
using GeographicPoint3D = GeographicPoint<
    Ellipsoid,
    concepts::geographic::_GeographicUnitsWithHeight,
    CoordinateTuple<
        boost::units::quantity<boost::units::si::plane_angle>,
        boost::units::quantity<boost::units::si::plane_angle>,
        boost::units::quantity<boost::units::si::length>
    >
>;

} // namespace funktionsklempner::geo

#endif
#endif