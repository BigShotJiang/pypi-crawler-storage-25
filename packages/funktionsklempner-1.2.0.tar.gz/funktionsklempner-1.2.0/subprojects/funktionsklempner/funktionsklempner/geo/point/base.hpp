/*
 * Base class for points.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEO_POINT_BASE_HPP
#define FUNKTIONSKLEMPNER_GEO_POINT_BASE_HPP


#include <funktionsklempner/concepts/quantity.hpp>
#include <funktionsklempner/concepts/sametype.hpp>
#include <funktionsklempner/math.hpp>
#include <funktionsklempner/geo/point/provider.hpp>
#include <gcem.hpp>
#include <cmath>
#include <array>



namespace funktionsklempner::geo {

/*
 * If a coordinate provider class provides its own
 * `equal` method, that one takes precedence over
 * the general purpose coordinate comparison:
 */
template<typename T>
concept has_equality_check = requires(T t)
{
    { t.equal(t) } -> std::convertible_to<bool>;
};





/*
 * Forward declare the point class
 */
template<
    concepts::CoordinateTuple Provider
>
class Point;






template<
    concepts::Quantity Coordinate,
    size_t ndim
>
class CoordinateArray
{
public:
    /*
     * The CoordinateProvider type API:
     */
    template<size_t i>
    using value = Coordinate;

    template<size_t i>
    using reference = Coordinate&;

    template<size_t i>
    using const_reference = const Coordinate&;

    /*
     * The constructor, custom to this implementation of a
     * CoordinateProvider:
     */
    template<
        concepts::Type<Coordinate>... C
    >
    constexpr CoordinateArray(C... c) noexcept
       : coordinates { c... }
    {
        static_assert(
            sizeof...(C) == ndim,
            "Initialized point with wrong number of coordinates."
        );
    }

    constexpr CoordinateArray(const std::array<Coordinate, ndim>& crd) noexcept
       : coordinates(crd)
    {}

    constexpr CoordinateArray(std::array<Coordinate, ndim>&& crd) noexcept
       : coordinates(std::move(crd))
    {}

    /*
     * Member access, the heart of the CoordinateProvider
     * API:
     */
    template<size_t i>
    constexpr const Coordinate& get() const noexcept
    {
        static_assert(i < ndim);
        return coordinates[i];
    }


    constexpr const Coordinate& get(size_t i) const
    {
        return coordinates[i];
    }

    constexpr bool equal(const CoordinateArray& other) const noexcept
    {
        return coordinates == other.coordinates;
    }

private:
    std::array<Coordinate, ndim> coordinates;
};




template<
    concepts::CoordinateTuple Coordinates
>
class Point
   : public Coordinates
{
protected:
    using This = Point<Coordinates>;
    using Properties = CoordinateProviderProperties<Coordinates>;
public:
    constexpr static size_t ndim = Properties::ndim;
    using CoordinateTuple = typename Properties::coordinate_types;
protected:
    using Indices = std::make_integer_sequence<size_t, ndim>;
public:
    static_assert(ndim > 0);

    using Coordinates::Coordinates;

    /* General purpose comparison algorithm for
     *  - points of this dimension and same coordinate unit, and
     *     - either not derived from this class, or
     *     - derived from this class if `Coordinates` does not
     *       implement an equality comparison with itself.
     */
    template<
        concepts::CoordinateTupleOfUnits<CoordinateTuple> CProv,
        std::enable_if_t<
            (
                !std::derived_from<Point<CProv>, This>
                || !has_equality_check<Coordinates>
            ),
            bool
        > = true
    >
    constexpr bool
    operator==(const Point<CProv>& other) const noexcept
    {
        auto compare =
        [this, &other]<size_t... i>
        (std::integer_sequence<size_t, i...>) -> bool
        {
            return (
                (this->template get<i>() == other.template get<i>())
                && ...
            );
        };
        return compare(Indices());
    }


    /*
     * Use the custom equality check routine if available.
     */
    template<
        concepts::CoordinateTupleOfUnits<CoordinateTuple> CProv,
        std::enable_if_t<
            (
                std::derived_from<Point<CProv>, This>
                && !has_equality_check<Coordinates>
            ),
            bool
        > = true
    >
    constexpr bool
    operator==(const Point<CProv>& other) const noexcept
    {
        return Coordinates::equal(other);
    }

};



} // namespace funktionsklempner::geo



/*
 * Concept for filtering points.
 * This is based on the code in wrapper/vectorview.hpp.
 */
namespace funktionsklempner::concepts {

constexpr bool _is_point(const void*)
{
    return false;
}


template<
    concepts::CoordinateTuple Coordinates
>
constexpr bool _is_point(
    const geo::Point<Coordinates>* p
)
{
    return true;
}


template<typename T>
concept Point = _is_point(static_cast<const T*>(nullptr));
}



/*
 * Specialize the vector_dimension:
 */
namespace funktionsklempner::coordinates {

/*
 * Specializations for CoordinateArray:
 */
template<
    concepts::Quantity Coordinate,
    size_t ndim
>
struct the_tuple_dimension<geo::CoordinateArray<Coordinate, ndim>>
{
    using value = std::integral_constant<size_t, ndim>;
};


template<
    concepts::Quantity Coordinate,
    size_t ndim,
    size_t i
>
struct get_coordinate_type<geo::CoordinateArray<Coordinate, ndim>, i>
{
    using type = Coordinate;
};


/*
 * Specializations for Point:
 */
template<
    concepts::Point P
>
struct the_tuple_dimension<P>
{
    using value = std::integral_constant<size_t, P::ndim>;
};




}


/*
 * Specialize the coordinate type for points:
 */
namespace funktionsklempner::coordinates {

template<
    concepts::Point P,
    size_t i
>
struct get_coordinate_type<P, i>
{
    using type = std::tuple_element_t<i, typename P::CoordinateTuple>;
};


}

#endif