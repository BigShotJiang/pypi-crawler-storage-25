/*
 * Points in Euclidean space, using Boost.Units
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */



#ifndef FUNKTIONSKLEMPNER_GEO_POINT_EUCLIDEAN_HPP
#define FUNKTIONSKLEMPNER_GEO_POINT_EUCLIDEAN_HPP


/*
 * Optionally enable support for Boost.Geometry:
 */
#ifdef FUNKTIONSKLEMPNER_BOOST_GEOMETRY
#ifdef __has_include
    #if __has_include(<boost/geometry.hpp>)
        #include <boost/geometry.hpp>
    #endif
#else
    /* If __has_include is not available, simply include.
     * The user may have to disable the feature if Boost.Geometry is
     * not available.
     */
    #include <boost/geometry.hpp>
#endif
#endif


/*
 * Tie the use of Euclidean points to the availability of SI length
 * units from Boost.Units
 */
#ifndef FUNKTIONSKLEMPNER_NO_BOOST

#include <funktionsklempner/geo/point/base.hpp>
#include <funktionsklempner/geo/distancecontext.hpp>
#include <funktionsklempner/util/typelist.hpp>

#include <boost/units/systems/si/length.hpp>
#include <boost/units/systems/si/area.hpp>
#include <funktionsklempner/math.hpp>



namespace funktionsklempner::geo {


template<
    size_t ndim,
    concepts::CoordinateTupleOfUnits<
        repeat_type<
            boost::units::quantity<boost::units::si::length>,
            ndim
        >
    > Coordinates
>
class EuclideanPoint
   : public Point<
        Coordinates
     >
{
    using Length = boost::units::quantity<boost::units::si::length>;
    using CoordinateUnits = repeat_type<Length, ndim>;
    using Base = Point<
        Coordinates
    >;
    using Indices = Base::Indices;

public:
    using Coordinate = Length;
    using Base::Point;


    template<
        concepts::CoordinateTupleOfUnits<CoordinateUnits> OC
    >
    constexpr boost::units::quantity<boost::units::si::area>
    squared_distance(const EuclideanPoint<ndim, OC>& other) const noexcept
    {
        using Area = boost::units::quantity<boost::units::si::area>;
        auto squared_sum_of_differences =
        [this, &other]<size_t... i>
        (std::integer_sequence<size_t, i...>) -> Area
        {
            auto square = [](const Coordinate& l) -> Area
            {
                return l*l;
            };
            return (
                square(this->template get<i>() - other.template get<i>())
                + ...
            );
        };
        return squared_sum_of_differences(Indices());
    }


    template<
        concepts::CoordinateTupleOfUnits<CoordinateUnits> OC
    >
    constexpr Length
    distance(const EuclideanPoint<ndim, OC>& other) const
    {
        return math::sqrt(squared_distance(other));
    }



    template<
        concepts::CoordinateTupleOfUnits<CoordinateUnits> OC
    >
    constexpr Length
    distance(
        const EuclideanPoint<ndim, OC>& other,
        const DistanceContext&
    ) const
    {
        /* Distance context is not used for Euclidean distances. */
        return math::sqrt(squared_distance(other));
    }


    /*
     * Add the following typical coordinate names:
     *  - x    (if ndim <= 3)
     *  - y    (if 2 <= ndim <= 3)
     *  - z    (if ndim == 3)
     */
    template<
        size_t j=0,
        std::enable_if_t<
            ((j == 0) && (ndim <= 3)),
            bool
        > = true
    >
    constexpr typename Base::template const_reference<j> x() const noexcept
    {
        return this->template get<0>();
    }


    template<
        size_t j=1,
        std::enable_if_t<
            ((j == 1) && (2 <= ndim) && (ndim <= 3)),
            bool
        > = true
    >
    constexpr typename Base::template const_reference<j> y() const noexcept
    {
        return this->template get<1>();
    }


    template<
        size_t j=2,
        std::enable_if_t<
            ((j == 2) && (ndim == 3)),
            bool
        > = true
    >
    constexpr Base::template const_reference<j> z() const noexcept
    {
        return this->template get<2>();
    }


    /*
     * Conditionally on Boost.Geometry availability, allow conversion
     * to boost::geometry::model::point of corresponding dimension
     * and with a selected length unit.
     */
    #ifdef BOOST_GEOMETRY_HPP

    /* First decide which point model to use. In d=2 and d=3, we can use
     * the specializations point_xy and point_xyz.
     * Otherwise, use the templated point. */
    template<typename Real>
    using BoostPoint = std::conditional_t<
        (ndim == 2),
        boost::geometry::model::d2::point_xy<
            Real, boost::geometry::cs::cartesian
        >,
        std::conditional_t<
            (ndim == 3),
            boost::geometry::model::d3::point_xyz<
                Real, boost::geometry::cs::cartesian
            >,
            boost::geometry::model::point<
                Real, ndim, boost::geometry::cs::cartesian
            >
        >
    >;

    template<typename Real=double>
    constexpr BoostPoint<Real>
    to_boost_geometry(
        const Length& length_scale
    ) const noexcept
    {
        /* This function is designed around the available constructors
         * of boost::geometry::model::point.
         * For the case of general dimensionality, only the empty constructor
         * is generally available. We use this and then set the coordinates
         * using the templated ::set() method over an index_sequence expansion.
         * */
        using BGPoint = BoostPoint<Real>;
        auto init =
        [this, length_scale]<size_t... i>(std::index_sequence<i...>) -> BGPoint
        {
            BGPoint res;
            (
                res.template set<i>(this->template get<i>() / length_scale), ...
            );
            return res;
        };
        return init.template operator()(
            std::make_index_sequence<ndim>()
        );
    }
    #endif

};


/*
 * Define some shorthands:
 */
using Point2D = EuclideanPoint<
    2,
    CoordinateArray<
        boost::units::quantity<boost::units::si::length>,
        2
    >
>;

using Point3D = EuclideanPoint<
    3,
    CoordinateArray<
        boost::units::quantity<boost::units::si::length>,
        3
    >
>;



} // namespace funktionsklempner::geo

#endif
#endif