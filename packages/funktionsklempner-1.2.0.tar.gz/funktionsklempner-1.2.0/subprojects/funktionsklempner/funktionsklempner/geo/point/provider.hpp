/*
 * The interface for coordinate providers.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEO_POINT_PROVIDER_HPP
#define FUNKTIONSKLEMPNER_GEO_POINT_PROVIDER_HPP

#include <funktionsklempner/util/typelist.hpp>
#include <funktionsklempner/concepts/coordinates.hpp>

namespace funktionsklempner::geo {


template<concepts::CoordinateTuple CP>
struct CoordinateProviderProperties
{
    using coordinate_types = coordinates::assemble_coordinate_tuple<CP>;

    constexpr static size_t ndim = std::tuple_size_v<coordinate_types>;
};



/*
 * Simple std::tuple-based implementation:
 */
template<typename... Coordinates>
class CoordinateTuple : public std::tuple<Coordinates...>
{
    using Base = std::tuple<Coordinates...>;
public:
    template<size_t i>
    using reference = std::add_lvalue_reference_t<std::tuple_element_t<i, Base>>;

    template<size_t i>
    using const_reference = std::add_lvalue_reference_t<
        std::add_const_t<std::tuple_element_t<i, Base>>
    >;

    /* Constructor forwarding. */
    using Base::Base;

    template<size_t i>
    constexpr reference<i> get() noexcept
    {
        return std::get<i>(*this);
    }

    template<size_t i>
    constexpr const_reference<i> get() const noexcept
    {
        return std::get<i>(*this);
    }
};

}


namespace funktionsklempner::coordinates {

template<typename... Coordinates>
struct the_tuple_dimension<geo::CoordinateTuple<Coordinates...>>
{
    using value = std::integral_constant<size_t, sizeof...(Coordinates)>;
};

}


#endif