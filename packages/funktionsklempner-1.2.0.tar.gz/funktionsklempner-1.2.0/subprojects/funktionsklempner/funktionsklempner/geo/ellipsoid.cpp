/*
 * Ellipsoids.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#include <funktionsklempner/geo/ellipsoid.hpp>
#include <funktionsklempner/strings.hpp>
#include <objektbuch/objectbook.hpp>



/*
 * Define the object book instance:
 */
namespace geo = funktionsklempner::geo;


using ObjectBook = objektbuch::ObjectBook<
    size_t,
    geo::EllipsoidVariant
>;

static ObjectBook objects;


/*
 * Functions from the funktionsklempner::geo namespace (the C++ side):
 */
namespace funktionsklempner::geo {


EllipsoidVariant
parse_ellipsoid(const EllipsoidParameter& param)
{
    return std::visit(
        [](auto&& param) -> EllipsoidVariant
        {
            /* Depending on the variant of the ellipsoid parameter */
            using T = std::decay_t<decltype(param)>;
            if constexpr (std::is_same_v<T, std::u8string_view>)
            {
                if (param == u8"WGS84" || param == u8"EPSG:7030")
                    return ellipsoids::WGS84();
                else if (param == u8"Bessel 1841" || param == u8"EPSG:7004")
                    return ellipsoids::Bessel1841();
                std::string msg("Unknown ellipsoid: '");
                msg += reinterpret_cast<const char*>(param.data());
                msg += "'.";
                throw std::runtime_error(msg);
            } else {
                return UserEllipsoid(param.first, param.second);
            }
        },
        param
    );
}


/*
 * Handle the ellipsoid input arguments and convert them into
 * the compound type "EllipsoidParameter"
 */
EllipsoidParameter make_ellipsoid_parameter(
    const char* ellipsoid_identifier
)
{
    return std::u8string_view(
        reinterpret_cast<const char8_t*>(ellipsoid_identifier)
    );
}

EllipsoidParameter
make_ellipsoid_parameter(
    double ellipsoid_a,
    const char* ellipsoid_a_unit,
    double ellipsoid_f
)
{
#ifndef FUNKTIONSKLEMPNER_NO_BOOST
    auto a_unit = parse_si_unit<boost::units::si::length>(ellipsoid_a_unit);
    if (!a_unit)
        throw std::runtime_error(a_unit.error());
    half_axis_t a = ellipsoid_a * a_unit.value();
#else
    half_axis_t a = ellipsoid_a;
#endif
    return std::make_pair(a, ellipsoid_f);
}


EllipsoidVariant ellipsoid_object(size_t oid)
{
    return *objects.get<EllipsoidVariant>(oid);
}

} // namespace funktionsklempner::geo




/*
 * Function interface to the Python world:
 */

int funktionsklempner_create_ellipsoid_by_id(
    const char* identifier,
    size_t* oid,
    size_t* err_id
)
{
    /* Need to be able to output object and error ID: */
    if (!oid || !err_id)
        return -1;

    try {
        *oid = objects.emplace(
            geo::parse_ellipsoid(
                geo::make_ellipsoid_parameter(identifier)
            )
        );
        return 0;
    } catch (std::exception& e){
        *err_id = funktionsklempner::create_string(e.what());
        return -2;
    }
}



int funktionsklempner_create_ellipsoid_by_parameter(
    double a,
    const char* a_unit,
    double f,
    size_t* oid,
    size_t* err_id
)
{

    /* Need to be able to output object and error ID: */
    if (!oid || !err_id)
        return -1;

    try {
        *oid = objects.emplace(
            geo::parse_ellipsoid(
                geo::make_ellipsoid_parameter(a, a_unit, f)
            )
        );
        return 0;
    } catch (std::exception& e){
        *err_id = funktionsklempner::create_string(e.what());
        return -2;
    }
}



int funktionsklempner_delete_ellipsoid(
    size_t oid
)
{
    try {
        /* Make sure that this is actually an ellipsoid: */
        objects.get<geo::EllipsoidVariant>(oid);

        /* Then delete: */
        objects.erase(oid);

        return 0;
    } catch (...){
        return -1;
    }
}