/*
 * Factory methods for creating geographic and Euclidean point ranges.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEO_VIEW_FACTORY_HPP
#define FUNKTIONSKLEMPNER_GEO_VIEW_FACTORY_HPP

#ifndef FUNKTIONSKLEMPNER_NO_BOOST

#include <utility>
#include <funktionsklempner/geo/view/euclidean.hpp>
#include <funktionsklempner/geo/view/geographic.hpp>
#include <funktionsklempner/wrapper/ndarray.hpp>
#include <funktionsklempner/util/unit2quantity.hpp>

namespace funktionsklempner::geo {


/*
 * 1. Creating a Euclidean point range from a double buffer.
 * =========================================================
 */
template<
    size_t ndim,
    NumPyDType T
>
constexpr
EuclideanPointRange<
    ndim,
    std::is_const_v<T>,
    ndarray::NDArray<T>
>
create_euclidean_point_range(
    ndarray::NDArray<T> array,
    const std::array<const char*, ndim>& unit
)
{
    using UnitTuple = repeat_type<
        boost::units::si::length,
        ndim
    >;
    auto parsed = parse_si_units<std::decay_t<T>>(
        unit,
        static_cast<const UnitTuple*>(nullptr)
    );
    if (parsed){
        return EuclideanPointRange<ndim, std::is_const_v<T>, ndarray::NDArray<T>>(
            array,
            parsed.value()
        );
    }
    throw std::runtime_error(parsed.error());
}




/*
 * 2. Creating a geographic point range from a double buffer.
 * ==========================================================
 */

template<
    bool with_height,
    geo::Ellipsoid_t Ellipsoid,
    NumPyDType T
>
using GeographicPointRange_t = GeographicPointRange<
    Ellipsoid,
    std::is_const_v<T>,
    std::conditional_t<
        with_height,
        concepts::geographic::_GeographicUnitsWithHeight,
        concepts::geographic::_GeographicUnits
    >,
    ndarray::NDArray<T>
>;





template<
    bool height,
    geo::Ellipsoid_t E,
    NumPyDType T
>
GeographicPointRange_t<height, E, T>
create_geographic_point_range(
    ndarray::NDArray<T> array,
    const typename GeographicPointRange_t<height, E, T>::QuantityTuple& unit,
    EllipsoidVariant ellipsoid
)
{
    return std::visit(
        [&array, &unit](auto&& ellps) -> GeographicPointRange_t<height, E, T>
        {
            /* Determine the return type: */
            using ParsedEllipsoid = std::decay_t<decltype(ellps)>;
            if constexpr (std::is_same_v<E, ParsedEllipsoid>){
                /* Return the range: */
                return GeographicPointRange_t<height, E, T>(
                    array,
                    unit,
                    ellps
                );
            } else if constexpr (std::is_same_v<E, UserEllipsoid>){
                /* We can create a user ellipsoid from a static one (just not
                 * the other way round):
                 */
                return GeographicPointRange_t<height, E, T>(
                    array,
                    unit,
                    UserEllipsoid(
                        ParsedEllipsoid::a,
                        ParsedEllipsoid::f
                    )
                );
            }
            throw std::runtime_error(
                "Wrong ellipsoid given for create_geographic_point_range."
            );
        },
        ellipsoid
    );
}



template<
    bool with_height,
    geo::Ellipsoid_t Ellipsoid,
    NumPyDType T
>
GeographicPointRange_t<with_height, Ellipsoid, T>
create_geographic_point_range(
    ndarray::NDArray<T> array,
    const std::array<const char*, ((with_height) ? 3 : 2)>& unit,
    EllipsoidVariant ellipsoid
)
{
    using UnitTuple = std::conditional_t<
        with_height,
        concepts::geographic::_GeographicUnitsWithHeight,
        concepts::geographic::_GeographicUnits
    >;

    /* Parse the unit: */
    auto parsed = parse_si_units<std::decay_t<T>>(
        unit,
        static_cast<const UnitTuple*>(nullptr)
    );
    if (!parsed)
        throw std::runtime_error(parsed.error());


    return create_geographic_point_range<with_height, Ellipsoid, T>(
        array, parsed.value(), ellipsoid
    );
}




template<
    bool with_height,
    Ellipsoid_t Ellipsoid,
    NumPyDType T
>
GeographicPointRange_t<with_height, Ellipsoid, T>
create_geographic_point_range(
    ndarray::NDArray<T> array,
    const std::array<const char*, ((with_height) ? 3 : 2)>& unit,
    const char* ellipsoid_identifier
)
{
    return create_geographic_point_range<with_height, Ellipsoid, T>(
        array,
        unit,
        parse_ellipsoid(make_ellipsoid_parameter(ellipsoid_identifier))
    );
}


template<
    bool with_height,
    concepts::Type<UserEllipsoid> Ellipsoid,
    NumPyDType T
>
GeographicPointRange_t<with_height, Ellipsoid, T>
create_geographic_point_range(
    ndarray::NDArray<T> array,
    const std::array<const char*, ((with_height) ? 3 : 2)>& unit,
    double ellipsoid_a,
    const char* ellipsoid_a_unit,
    double ellipsoid_f
)
{
    return create_geographic_point_range<with_height, Ellipsoid, T>(
        array,
        unit,
        parse_ellipsoid(
            make_ellipsoid_parameter(ellipsoid_a, ellipsoid_a_unit, ellipsoid_f)
        )
    );
}



template<
    bool height,
    concepts::Type<UserEllipsoid> E,
    NumPyDType T
>
GeographicPointRange_t<height, E, T>
create_geographic_point_range(
    ndarray::NDArray<T> array,
    const typename GeographicPointRange_t<height, E, T>::QuantityTuple& unit,
    double ellipsoid_a,
    const char* ellipsoid_a_unit,
    double ellipsoid_f
)
{
    return create_geographic_point_range<height, E, T>(
        array,
        unit,
        parse_ellipsoid(
            make_ellipsoid_parameter(ellipsoid_a, ellipsoid_a_unit, ellipsoid_f)
        )
    );
}



template<
    bool height,
    Ellipsoid_t E,
    NumPyDType T
>
GeographicPointRange_t<height, E, T>
create_geographic_point_range(
    ndarray::NDArray<T> array,
    const typename GeographicPointRange_t<height, E, T>::QuantityTuple& unit,
    const char* ellipsoid_identifier
)
{
    return create_geographic_point_range<height, E, T>(
        array,
        unit,
        parse_ellipsoid(
            make_ellipsoid_parameter(ellipsoid_identifier)
        )
    );
}



} // namespace funktionsklempner::geo


#endif
#endif