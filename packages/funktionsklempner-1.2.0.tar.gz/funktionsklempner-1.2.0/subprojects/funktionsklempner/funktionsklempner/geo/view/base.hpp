/*
 * Base class for an iterator of points that interprets the buffer of
 * an NDArray / QuantityArray as consecutive tuples of coordinates.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEO_VIEW_BASE_HPP
#define FUNKTIONSKLEMPNER_GEO_VIEW_BASE_HPP


#include <ranges>
#include <concepts>
#include <funktionsklempner/geo/point.hpp>
#include <funktionsklempner/concepts/unitrange.hpp>
#include <funktionsklempner/wrapper/vectorview.hpp>


/*
 * Concept for filtering point views.
 * Here we check that a type `T` inherits from geo::Point<VQV>,
 * where 'VQV' is both a VectorQuantityView (meaning the point is
 * a view of underlying data) and a CoordinateProvider.
 */
namespace funktionsklempner::concepts {

constexpr bool _is_point_view(const void*){
    return false;
};

template<
    concepts::VectorQuantityView VQV
> requires concepts::CoordinateTuple<VQV>
constexpr bool _is_point_view(const geo::Point<VQV>*)
{
    return true;
}

template<typename T>
concept PointView = _is_point_view(static_cast<const T*>(nullptr));


}


namespace funktionsklempner::geo {

/*
 * Declare the iterator:
 */


template<
    concepts::NPTypeRandomAccessIterator Iterator,
    typename Specialized, // Specialization of the iterator for CRTP
    concepts::PointView PointView,
    typename UnitTuple,
    typename... ExtraParameters
>
class PointIterator;



template<
    concepts::NPTypeRandomAccessIterator Iterator,
    typename Specialized, // Specialization of the iterator for CRTP
    concepts::PointView PointView,
    Unit... U
>
class PointIterator<Iterator, Specialized, PointView, std::tuple<U...>>
{
    /* Ensure that 'Specialized' is actually a specialization of this class: */
    using ThisType = PointIterator<
        Iterator,
        Specialized,
        PointView,
        std::tuple<U...>
    >;
public:
    /* std::tuple of quantities. These quantities will, for instance,
     * represent the units of the individual dimensions: */
    using QuantityTuple = typename wrapper::VectorQuantityProperties<
        Iterator, U...
    >::QuantityTuple;

    constexpr static size_t ndim = sizeof...(U);


    /*
     * Iterator interface:
     */
    using iterator_category = std::random_access_iterator_tag;
    using value_type = PointView;
    using reference = value_type;
    using difference_type = std::ptrdiff_t;
    using pointer = value_type*;

    /* Some static asserts: */
    static_assert(noexcept(Iterator(std::declval<Iterator>())));
    static_assert(noexcept(Iterator(std::declval<Iterator&>())));
    static_assert(noexcept(Iterator()));
    static_assert(noexcept(
        std::declval<Iterator&>() = std::declval<const Iterator&>()
    ));
    static_assert(noexcept(
        std::declval<Iterator&>() = std::declval<Iterator>()
    ));


public:
    /*
     * Constructor:
     */
    template<
        std::convertible_to<Iterator> It,
        std::convertible_to<QuantityTuple> QT
    >
    constexpr PointIterator(
            It&& it,
            QT&& units
        ) noexcept
       : it(std::forward<It>(it)),
         units(std::forward<QT>(units))
    {
    }

    /* This is a fallback iterator to accept (and digest) the
     * `*this` final argument in operator+ and operator-. */
    template<
        std::convertible_to<Iterator> It,
        std::convertible_to<QuantityTuple> QT
    >
    constexpr PointIterator(
            It&& it,
            QT&& units,
            const PointIterator&
        ) noexcept
       : it(std::forward<It>(it)),
         units(std::forward<QT>(units))
    {
    }


    constexpr PointIterator() noexcept = default;
    constexpr PointIterator(PointIterator&&) noexcept = default;
    constexpr PointIterator(const PointIterator&) noexcept = default;


    /*
     * Assignment:
     */
    constexpr Specialized& operator=(const PointIterator& other) noexcept
    {
        it = other.it;
        return *static_cast<Specialized*>(this);
    }

    constexpr Specialized& operator=(PointIterator&& other) noexcept
    {
        it = std::move(other.it);
        return *static_cast<Specialized*>(this);
    }


    /*
     * Dereference:
     */
    constexpr PointView operator*() const
    {
        static_assert(std::derived_from<Specialized, ThisType>);
        return static_cast<const Specialized*>(this)
            ->create_point_view(it, units);
    }

    constexpr PointView operator->() const
    {
        static_assert(std::derived_from<Specialized, ThisType>);
        return static_cast<const Specialized*>(this)
            ->create_point_view(it, units);
    }

    constexpr PointView operator[](size_t j) const
    {
        static_assert(std::derived_from<Specialized, ThisType>);
        return static_cast<const Specialized*>(this)
            ->create_point_view(it + ndim * j, units);
    }


    /*
     * Advancement:
     */
    constexpr Specialized& operator++()
    {
        it += ndim;
        return *static_cast<Specialized*>(this);
    }

    constexpr Specialized operator++(int)
    {
        Specialized res(*this);
        it += ndim;
        return res;
    }

    constexpr Specialized& operator--()
    {
        it -= ndim;
        return *static_cast<Specialized*>(this);
    }

    constexpr Specialized operator--(int)
    {
        Specialized res(*this);
        it -= ndim;
        return res;
    }

    constexpr Specialized& operator+=(std::ptrdiff_t i)
    {
        it += i * ndim;
        return *static_cast<Specialized*>(this);
    }

    constexpr Specialized& operator-=(std::ptrdiff_t i)
    {
        it -= i * ndim;
        return *this;
    }

    constexpr Specialized operator+(std::ptrdiff_t i) const
    {
        return Specialized(
            it + ndim * i,
            units,
            *static_cast<const Specialized*>(this)
        );
    }

    constexpr Specialized operator-(std::ptrdiff_t i) const
    {
        return Specialized(
            it - ndim * i,
            units,
            *static_cast<const Specialized*>(this)
        );
    }


    constexpr std::ptrdiff_t operator-(const PointIterator& other) const noexcept
    {
        /* Here we boldly expect the iterator difference to be noexcept. */
        static_assert(
            noexcept(it - other.it),
            "Funktionsklempner requires iterator difference to be noexcept."
        );
        return (it - other.it) / ndim;
    }


    /*
     * Comparison:
     */
    template<std::sentinel_for<Iterator> Sentinel>
    constexpr bool operator==(const Sentinel& s) const noexcept
    {
        static_assert(noexcept(it == s));
        return it == s;
    }

    constexpr bool operator==(const PointIterator& other) const noexcept
    {
        static_assert(noexcept(it == other.it));
        return it == other.it;
    }

    constexpr auto
    operator<=>(const PointIterator& other) const noexcept
    {
        static_assert(noexcept(it <=> other.it));
        return it <=> other.it;
    }

    template<std::sentinel_for<Iterator> Sentinel>
    constexpr auto operator<=>(const Sentinel& sentinel) const noexcept
    {
        static_assert(noexcept(it <=> sentinel));
        return it <=> sentinel;
    }

private:
    /*
     * The pointer to the start of the data:
     */
    Iterator it;

    /*
     * The units:
     */
    QuantityTuple units;
};



/*
 * Utility function for selecting the iterator based on constness
 * requirement:
 */
template<
    bool is_const,
    concepts::NPTypeRandomAccessRange R
>
using select_iterator = std::conditional_t<
    is_const,
    decltype(std::ranges::cbegin(std::declval<const R&>())), // std::ranges::const_iterator_t
    std::ranges::iterator_t<R>
>;





/*
 * Forward declare to be able to specialize for std::tuple of units:
 */
template<
    concepts::NPTypeRandomAccessRange R,
    std::random_access_iterator Iterator,
    typename Specialized, // Specialization of the iterator.
    concepts::PointView PointView, // View of the buffer as grouped coordinates
    typename UnitTuple,
    typename... ExtraParameters
>
class PointRange;


template<
    concepts::NPTypeRandomAccessRange R,
    std::random_access_iterator Iterator,
    typename Specialized, // Specialization of the iterator.
    concepts::PointView PointView, // View of the buffer as grouped coordinates
    Unit... U,
    typename... ExtraParameters
>
class PointRange<
    R,
    Iterator,
    Specialized,
    PointView,
    std::tuple<U...>,
    ExtraParameters...
>
{
    /*
     * Since PointIterator is a CRTP, we will ensure here that the
     * Iterator is actually a derived class of PointIterator:
     */
    static_assert(
        std::derived_from<
            Specialized,
            PointIterator<
                Iterator,
                Specialized,
                PointView,
                std::tuple<U...>
            >
        >
    );
public:
    /*
     * Types.
     * Relay the derivation of relevant value types to the PointIterator class.
     */
    using _PointIterator = geo::PointIterator<
        Iterator, Specialized, PointView, std::tuple<U...>
    >;

    using QuantityTuple = typename _PointIterator::QuantityTuple;
    constexpr static size_t ndim = _PointIterator::ndim;

    constexpr static bool is_const = !std::output_iterator<
        Iterator,
        std::decay_t<decltype(*std::declval<Iterator>())>
    >;


    using Sentinel = decltype(std::ranges::cend(std::declval<R&>()));

    /*
     * Constructors from parsed units given as a QuantityTuple:
     */

    template<
        std::convertible_to<QuantityTuple> QT,
        FUNKTIONSKLEMPNER_ENABLE_IF(is_const),
        typename... EP
    > requires (std::convertible_to<EP, ExtraParameters> && ...)
    constexpr PointRange(
        const R& r,
        QT&& units,
        EP&&... args
    )
       : _begin(std::ranges::cbegin(r)),
         _end(std::ranges::cend(r)),
         units(std::forward<QT>(units)),
         extra_args(std::forward<EP>(args)...)
    {
        init_size(r);
    }


    template<
        std::convertible_to<QuantityTuple> QT,
        std::convertible_to<R> R_,
        FUNKTIONSKLEMPNER_ENABLE_IF(!is_const),
        typename... EP
    > requires (std::convertible_to<EP, ExtraParameters> && ...)
    constexpr PointRange(
        R_&& r,
        QT&& units,
        EP&&... args
    )
       : _begin(std::ranges::begin(r)),
         _end(std::ranges::end(r)),
         units(std::forward<QT>(units)),
         extra_args(std::forward<EP>(args)...)
    {
        init_size(r);
    }


    constexpr Specialized begin() const
    {
        /* The specialized iterator might need extra parameters
         * (e.g. the ellipsoid being passed to the GeographicIterator)
         */
        auto make_iter = [this](const ExtraParameters&... args) -> Specialized
        {
            return Specialized(_begin, units, args...);
        };
        return std::apply(make_iter, extra_args);
    }

    constexpr Sentinel end() const
    {
        return _end;
    }


    template<
        typename T = R,
        std::enable_if_t<
            std::ranges::sized_range<T>,
            bool
        > = true
    >
    constexpr size_t size() const noexcept
    {
        return _maybe_size;
    }


private:
    Iterator _begin;
    Sentinel _end;
    QuantityTuple units;
    size_t _maybe_size;
    std::tuple<ExtraParameters...> extra_args;


    /* Conditionally init the size: */
    constexpr void init_size(const R& r)
    {
        if constexpr (std::ranges::sized_range<R>){
            _maybe_size = std::ranges::size(r);

            /* Size must be a multiple of the point dimension: */
            if ((_maybe_size % ndim) != 0){
                std::string msg(
                    "The underlying coordinate range of a point range "
                    "has size "
                );
                msg += std::to_string(_maybe_size);
                msg += ", which is not a multiple of the point "
                    "dimension ";
                msg += std::to_string(ndim);
                msg += ".";
                throw std::runtime_error(msg);
            }

            /* If the size is correctly mod ndim, compute the
             * actual number of points:
             */
            _maybe_size /= ndim;
        }
    }
};


}


/*
 * Point range is borrowed if the underlying container is borrowed.
 */
template<
    funktionsklempner::concepts::NPTypeRandomAccessRange R,
    std::random_access_iterator Iterator,
    typename Specialized, // Specialization of the iterator.
    funktionsklempner::Unit... U
>
constexpr bool std::ranges::enable_borrowed_range<
    funktionsklempner::geo::PointRange<
        R, Iterator, Specialized, U...
    >
> = true;


#endif