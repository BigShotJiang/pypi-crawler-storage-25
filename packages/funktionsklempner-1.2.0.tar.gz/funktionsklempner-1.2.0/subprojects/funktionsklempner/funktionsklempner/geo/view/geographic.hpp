/*
 * Interpreting consecutive quantities of a range as multiplexed coordinates
 * of a sequence of geographic points.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEO_VIEW_GEOGRAPHIC_HPP
#define FUNKTIONSKLEMPNER_GEO_VIEW_GEOGRAPHIC_HPP

#ifndef FUNKTIONSKLEMPNER_NO_BOOST

#include <funktionsklempner/geo/view/base.hpp>
#include <funktionsklempner/geo/point/geographic.hpp>
#include <funktionsklempner/util/macros.hpp>

namespace funktionsklempner::geo {


template<
    geo::Ellipsoid_t Ellipsoid,
    concepts::NPTypeRandomAccessIterator Iterator,
    concepts::GeographicCoordinateUnitTuple CoordinateUnits
>
class GeographicPointView
    : public GeographicPoint<
        Ellipsoid,
        CoordinateUnits,
        wrapper::VectorQuantityView<
            Iterator,
            CoordinateUnits
        >
    >
{
    using Base = GeographicPoint<
        Ellipsoid,
        CoordinateUnits,
        wrapper::VectorQuantityView<
            Iterator,
            CoordinateUnits
        >
    >;
public:

    using Base::GeographicPoint;

    /*
     * Overload the arrow operator to allow arrow-dereferencing
     * of the iterator through chained arrow:
     */
    constexpr const GeographicPointView*
    operator->() const noexcept
    {
        return this;
    }
};


template<
    geo::Ellipsoid_t Ellipsoid,
    concepts::NPTypeRandomAccessIterator Iterator,
    concepts::GeographicCoordinateUnitTuple CoordinateUnits
>
class MutableGeographicPointView
    : public GeographicPoint<
        Ellipsoid,
        CoordinateUnits,
        wrapper::MutableVectorQuantityView<
            /* Iterator to the underlying floating point buffer (coordinates) */
            Iterator,
            /* The tuple of units: */
            CoordinateUnits
        >
    >
{
    using MVQV = wrapper::MutableVectorQuantityView<
        Iterator,
        CoordinateUnits
    >;
    using Base = GeographicPoint<
        Ellipsoid, CoordinateUnits, MVQV
    >;

    static_assert(Base::is_view);
public:
    using Base::GeographicPoint;

    /*
     * Inherit the base class assignment:
     */
    template<
        concepts::CompatibleToCoordinateTuple<Base> Coordinates
    >
    const MutableGeographicPointView&
    operator=(const Point<Coordinates>& p) const
    {
        MVQV::operator=(p);
        return *this;
    }


    /*
     * Overload the arrow operator to allow arrow-dereferencing
     * of the iterator through chained arrow:
     */
    constexpr const MutableGeographicPointView*
    operator->() const noexcept
    {
        return this;
    }

    constexpr MutableGeographicPointView*
    operator->() noexcept
    {
        return this;
    }
};


/*
 * Type computations for Geographic points.
 */
namespace geographic_point_view {

template<
    geo::Ellipsoid_t Ellipsoid,
    concepts::NPTypeRandomAccessIterator Iterator,
    concepts::GeographicCoordinateUnitTuple CoordinateUnits
>
using select = std::conditional_t<
    std::output_iterator<
        Iterator,
        std::decay_t<decltype(*std::declval<Iterator>())>
    >,
    MutableGeographicPointView<Ellipsoid, Iterator, CoordinateUnits>,
    GeographicPointView<Ellipsoid, Iterator, CoordinateUnits>
>;

}

/*
 * Geographic specialization of the base PointIterator.
 */
template<
    Ellipsoid_t Ellipsoid,
    concepts::GeographicCoordinateUnitTuple CoordinateUnits,
    concepts::NPTypeRandomAccessIterator Iterator
>
class GeographicIterator
   : public PointIterator<
        Iterator,
        GeographicIterator<Ellipsoid, CoordinateUnits, Iterator>,
        geographic_point_view::select<Ellipsoid, Iterator, CoordinateUnits>,
        CoordinateUnits
     >,
     GeodesicProvider<Ellipsoid>
{
    using PointView = geographic_point_view::select<
        Ellipsoid, Iterator, CoordinateUnits
    >;
    using Specialized = GeographicIterator<Ellipsoid, CoordinateUnits, Iterator>;
    using Base = PointIterator<
        Iterator,
        Specialized,
        PointView,
        CoordinateUnits
    >;

    friend Base;
public:
    /*
     * Typedefs and properties:
     */
    constexpr static bool has_height = (std::tuple_size_v<CoordinateUnits> == 3);
    constexpr static bool is_user_ellipsoid
        = std::is_same_v<Ellipsoid, UserEllipsoid>;

    using QuantityTuple = typename Base::QuantityTuple;

    static_assert(concepts::TupleOfBoostQuantities<QuantityTuple>);

    /*
     * Iterator interface:
     */
    using Base::iterator_category;
    using Base::value_type;
    using Base::reference;
    using Base::difference_type;
    using Base::pointer;

    /* We potentially need to append the ellipsoid to the iterator: */
    template<
        std::convertible_to<Iterator> It,
        std::convertible_to<QuantityTuple> QT
    >
    constexpr GeographicIterator(
            It&& it,
            QT&& units,
            const GeodesicProvider<Ellipsoid>& gp
        ) noexcept
       : Base(std::forward<It>(it), std::forward<QT>(units)),
         GeodesicProvider<Ellipsoid>(gp)
    {
    }

    /* If we have a static ellipsoid, we can also construct without a
     * reference object: */
    template<
        std::convertible_to<Iterator> It,
        std::convertible_to<QuantityTuple> QT,
        FUNKTIONSKLEMPNER_ENABLE_IF(!is_user_ellipsoid)
    >
    constexpr GeographicIterator(
            It&& it,
            QT&& units
        ) noexcept
       : Base(std::forward<It>(it), std::forward<QT>(units))
    {
    }

    /* Need a default constructor (albeit invalid): */
    template<
        FUNKTIONSKLEMPNER_ENABLE_IF(is_user_ellipsoid)
    >
    constexpr GeographicIterator() noexcept
       : Base(),
         GeodesicProvider<Ellipsoid>(
            UserEllipsoid(half_axis_t::from_value(0.0), 0.0)
         )
    {}

    template<
        FUNKTIONSKLEMPNER_ENABLE_IF(!is_user_ellipsoid)
    >
    constexpr GeographicIterator() noexcept
    {}

    constexpr GeographicIterator(GeographicIterator&&) = default;
    constexpr GeographicIterator(const GeographicIterator&) = default;

    constexpr GeographicIterator& operator=(const GeographicIterator&) = default;
    constexpr GeographicIterator& operator=(GeographicIterator&) = default;


    /* Using the default comparison: */
    constexpr bool operator==(const Base& b) const
    {
        return *static_cast<const Base*>(this) == b;
    }

    template<std::sentinel_for<Iterator> Sentinel>
    constexpr bool operator==(const Sentinel& s) const
    {
        return *static_cast<const Base*>(this) == s;
    }

private:
    constexpr PointView create_point_view(
        const Iterator& it,
        const QuantityTuple& units
    ) const
    {
        static_assert(concepts::TupleOfBoostQuantities<QuantityTuple>);
        if constexpr (std::is_same_v<Ellipsoid, UserEllipsoid>)
            return PointView(
                it, units, this->ellipsoid()
            );
        else
            return PointView(
                it, units
            );
    }

};


template<
    Ellipsoid_t Ellipsoid,
    bool is_const,
    concepts::GeographicCoordinateUnitTuple CoordinateUnits,
    concepts::NPTypeRandomAccessRange R
>
class GeographicPointRange
   : public PointRange<
        R,
        select_iterator<is_const, R>,
        GeographicIterator<
            Ellipsoid,
            CoordinateUnits,
            select_iterator<is_const, R>
        >,
        geographic_point_view::select<
            Ellipsoid,
            select_iterator<is_const, R>,
            CoordinateUnits
        >,
        CoordinateUnits,
        GeodesicProvider<Ellipsoid>
     >,
     public GeodesicProvider<Ellipsoid>
{
public:
    using Base = PointRange<
        R,
        select_iterator<is_const, R>,
        GeographicIterator<
            Ellipsoid,
            CoordinateUnits,
            select_iterator<is_const, R>
        >,
        geographic_point_view::select<
            Ellipsoid,
            select_iterator<is_const, R>,
            CoordinateUnits
        >,
        CoordinateUnits,
        GeodesicProvider<Ellipsoid>
    >;
    using QuantityTuple = Base::QuantityTuple;

    constexpr static bool has_static_ellipsoid = Ellipsoid::is_static;

    /* Cannot always forward constructors since we might need to
     * initialize the Ellipsoid. */
    template<
        std::convertible_to<QuantityTuple> QT,
        FUNKTIONSKLEMPNER_ENABLE_IF(is_const && has_static_ellipsoid)
    >
    constexpr GeographicPointRange(
        const R& r,
        QT&& units
    )
       : Base(r, std::forward<QT>(units), Ellipsoid())
    {}


    template<
        std::convertible_to<QuantityTuple> QT,
        std::convertible_to<R> R_,
        FUNKTIONSKLEMPNER_ENABLE_IF(!is_const && has_static_ellipsoid)
    >
    constexpr GeographicPointRange(
        R_&& r,
        QT&& units
    )
       : Base(std::forward<R_>(r), std::forward<QT>(units), Ellipsoid())
    {}

    template<
        std::convertible_to<QuantityTuple> QT,
        FUNKTIONSKLEMPNER_ENABLE_IF(is_const)
    >
    constexpr GeographicPointRange(
        const R& r,
        QT&& units,
        const Ellipsoid& ellps
    )
       : Base(r, std::forward<QT>(units), ellps),
         GeodesicProvider<Ellipsoid>(ellps)
    {}


    template<
        std::convertible_to<QuantityTuple> QT,
        std::convertible_to<R> R_,
        FUNKTIONSKLEMPNER_ENABLE_IF(!is_const)
    >
    constexpr GeographicPointRange(
        R_&& r,
        QT&& units,
        const Ellipsoid& ellps
    )
       : Base(std::forward<R_>(r), std::forward<QT>(units), ellps),
         GeodesicProvider<Ellipsoid>(ellps)
    {}
};

}

#endif
#endif