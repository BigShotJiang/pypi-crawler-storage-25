/*
 * Interpreting consecutive quantities of a range as multiplexed coordinates
 * of a sequence of Euclidean points.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEO_VIEW_EUCLIDEAN_HPP
#define FUNKTIONSKLEMPNER_GEO_VIEW_EUCLIDEAN_HPP

#ifndef FUNKTIONSKLEMPNER_NO_BOOST

#include <utility>
#include <funktionsklempner/concepts/numpybuffer.hpp>
#include <funktionsklempner/util/homogeneoustuple.hpp>
#include <funktionsklempner/util/typelist.hpp>
#include <funktionsklempner/geo/view/base.hpp>
#include <funktionsklempner/geo/point/euclidean.hpp>

namespace funktionsklempner::geo {


template<
    size_t ndim,
    concepts::NPTypeRandomAccessIterator Iterator
>
class EuclideanPointView
    : public EuclideanPoint<
        ndim,
        wrapper::VectorQuantityView<
            Iterator,
            repeat_type<boost::units::si::length, ndim>
        >
    >
{
    /*
     * All we have to do here is to forward the constructor to
     * EuclideanPoint (which will, in turn, forward to VectorQuantityView)
     */
    using Base = EuclideanPoint<
        ndim,
        wrapper::VectorQuantityView<
            Iterator,
            repeat_type<boost::units::si::length, ndim>
        >
    >;
public:
    using Base::EuclideanPoint;


    /*
     * Overload the arrow operator to allow arrow-dereferencing
     * of the iterator through chained arrow:
     */
    constexpr const EuclideanPointView*
    operator->() const noexcept
    {
        return this;
    }
};


template<
    size_t ndim,
    concepts::NPTypeRandomAccessIterator Iterator
>
class MutableEuclideanPointView
    : public EuclideanPoint<
        ndim,
        wrapper::MutableVectorQuantityView<
            Iterator,
            repeat_type<boost::units::si::length, ndim>
        >
    >
{
    using MVQV = wrapper::MutableVectorQuantityView<
        Iterator,
        repeat_type<boost::units::si::length, ndim>
    >;
    using Base = EuclideanPoint<
        ndim, MVQV
    >;
public:
    using Base::EuclideanPoint;

    template<
        concepts::CompatibleToCoordinateTuple<Base> Coordinates
    >
    const MutableEuclideanPointView&
    operator=(const Point<Coordinates>& p) const
    {
        /* Call the point view implementation of the assignment: */
        MVQV::operator=(p);
        return *this;
    }


    /*
     * Overload the arrow operator to allow arrow-dereferencing
     * of the iterator through chained arrow:
     */
    constexpr MutableEuclideanPointView*
    operator->() noexcept
    {
        return this;
    }

    constexpr const MutableEuclideanPointView*
    operator->() const noexcept
    {
        return this;
    }

};


/*
 * Type computations for Euclidean points.
 */
namespace euclidean_point_view {

template<
    size_t ndim
>
using coordinate_unit_tuple = repeat_type<
    boost::units::si::length,
    ndim
>;

template<
    size_t ndim,
    concepts::NPTypeRandomAccessIterator Iterator
>
using select = std::conditional_t<
    std::output_iterator<
        Iterator,
        std::decay_t<decltype(*std::declval<Iterator>())>
    >,
    MutableEuclideanPointView<ndim, Iterator>,
    EuclideanPointView<ndim, Iterator>
>;


}


/*
 * Euclidean specialization of the base PointIterator.
 */
template<
    size_t ndim,
    concepts::NPTypeRandomAccessIterator Iterator
>
class EuclideanIterator
   : public PointIterator<
        Iterator,
        EuclideanIterator<ndim, Iterator>, // Specialization of the iterator.
        euclidean_point_view::select<ndim, Iterator>,
        euclidean_point_view::coordinate_unit_tuple<ndim>
    >
{
    using PointView = euclidean_point_view::select<ndim, Iterator>;
    using Specialized = EuclideanIterator<ndim, Iterator>;
    using Base = PointIterator<
        Iterator,
        Specialized, // Specialization of the iterator.
        PointView,
        euclidean_point_view::coordinate_unit_tuple<ndim>
    >;

    using Length = boost::units::quantity<boost::units::si::length>;

    friend Base;
public:
    /*
     * Iterator interface:
     */
    using Base::iterator_category;
    using Base::value_type;
    using Base::reference;
    using Base::difference_type;
    using Base::pointer;

    /* Further typedefs: */
    using QuantityTuple = typename Base::QuantityTuple;

    /* Forward the constructor: */
    using Base::PointIterator;


    /*
     * Simplified constructor:
     */
    template<
        typename It,
        std::enable_if_t<std::convertible_to<It,Iterator>, bool> = true
    >
    constexpr EuclideanIterator(
        It&& it,
        Length unit
    )
       : Base::PointIterator(
            std::forward<It>(it),
            util::make_homogeneous_unit_tuple<ndim, Length>(unit)
        )
    {}

    /* Using the default comparison: */
    constexpr bool operator==(const Base& b) const
    {
        return *static_cast<const Base*>(this) == b;
    }

    template<std::sentinel_for<Iterator> Sentinel>
    constexpr bool operator==(const Sentinel& s) const
    {
        return *static_cast<const Base*>(this) == s;
    }

private:
    constexpr PointView create_point_view(
        const Iterator& it,
        const QuantityTuple& units
    ) const noexcept
    {
        return PointView(
            it, units
        );
    }


};


/* This free function creates an EuclideanIterator. It can be useful
 * for less type clutter (only `ndim` needs to be specified, Iterator
 * can be inferred).
 */
template<
    size_t ndim,
    concepts::NPTypeRandomAccessIterator Iterator
>
EuclideanIterator<ndim, Iterator>
make_euclidean_iterator(
    Iterator&& it,
    boost::units::quantity<boost::units::si::length> unit
)
{
    return EuclideanIterator<ndim, Iterator>(it, unit);
}




template<
    size_t ndim,
    bool is_const,
    concepts::NPTypeRandomAccessRange R
>
class EuclideanPointRange
   : public PointRange<
        R,
        select_iterator<is_const, R>,
        EuclideanIterator<ndim, select_iterator<is_const, R>>,
        euclidean_point_view::select<
            ndim,
            select_iterator<is_const, R>
        >,
        euclidean_point_view::coordinate_unit_tuple<ndim>
     >
{
public:
    using Base = PointRange<
        R,
        select_iterator<is_const, R>,
        EuclideanIterator<ndim, select_iterator<is_const, R>>,
        euclidean_point_view::select<
            ndim,
            select_iterator<is_const, R>
        >,
        euclidean_point_view::coordinate_unit_tuple<ndim>
     >;

    /* Constructor forwarding: */
    using Base::PointRange;
};

}


/*
 * Point range, and thereby Euclidean point range, is borrowed if the
 * underlying container is borrowed.
 */
template<
    size_t ndim,
    bool is_const,
    funktionsklempner::concepts::RandomAccessRangeOfUnit<boost::units::si::length> R
>
constexpr bool std::ranges::enable_borrowed_range<
    funktionsklempner::geo::EuclideanPointRange<ndim, is_const, R>
> = true;

#endif
#endif