/*
 * Scalar input and output.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_SCALAR_HPP
#define FUNKTIONSKLEMPNER_SCALAR_HPP

#include <type_traits>
#include <string>

namespace funktionsklempner {

/*
 * Ensure that a type is not const:
 */
template<typename T>
concept mutable_type = !std::is_const_v<T>;


/*
 * Mark a variable as an input variable with automatic
 * Python type deduction and conversion.
 */
template<mutable_type T>
using input = T;

/*
 * Mark a variable as an input variable whose Python type
 * will be the ctypes representation of `T`.
 */
template<mutable_type T>
using pure_input = T;


/*
 * Mark a variable as output variable with automatic
 * Python type deduction and conversion.
 */
namespace _type_deduction {
    template<mutable_type T>
    struct output {
        using type = T*;
    };
}

template<mutable_type T>
using output = typename _type_deduction::output<T>::type;


/*
 * Mark a variable as output variable whose Python type
 * will be the ctypes representation of `T`.
 */
template<mutable_type T>
using pure_output = T*;


/*
 * Specializations:
 */
namespace _type_deduction {
    template<>
    struct output<const char*> {
        using type = std::string&;
    };

    template<>
    struct output<std::string> {
        using type = std::string&;
    };

}


} // namepace funktionsklempner


#endif