/*
 * A quantity such as real numbers or scalar physical quantities.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_CONCEPTS_QUANTITY_HPP
#define FUNKTIONSKLEMPNER_CONCEPTS_QUANTITY_HPP

#include <concepts>


/*
 * If we use Boost.Units, we can also have the concept of a
 * physical quantity:
 */
#ifndef FUNKTIONSKLEMPNER_NO_BOOST

#include <boost/units/quantity.hpp>
#include <funktionsklempner/concepts/unit.hpp>
#include <funktionsklempner/concepts/numpybuffer.hpp>

namespace funktionsklempner::wrapper {

template<
    Unit U,
    concepts::NPTypeRandomAccessIterator Iterator
>
class QuantityView;

}
#endif



namespace funktionsklempner::concepts {

template<typename Real>
constexpr Real _ONE = static_cast<Real>(1.0);


template<typename T, typename Real>
constexpr bool _QuantityArithmetics = requires(T t)
{
    /* Since physical quantities have dimensions and we cannot
     * generally specify the result of a multiplication operation,
     * we check division and multiplication at the same time: */
    { (t * t) / (t * t) } -> std::convertible_to<double>;
    { (t * t) / t } -> std::convertible_to<T>;
    { t + t } -> std::convertible_to<T>;
    { t - t } -> std::convertible_to<T>;
    { t / _ONE<Real> } -> std::convertible_to<T>;
    { _ONE<Real> * t } -> std::convertible_to<T>;
    { t * _ONE<Real> } -> std::convertible_to<T>;
    { _ONE<Real> / (_ONE<Real> / t) } -> std::convertible_to<T>;
    { t *= _ONE<Real> } -> std::convertible_to<T>;
    { t /= _ONE<Real> } -> std::convertible_to<T>;
    { t += t } -> std::convertible_to<T>;
    { t -= t } -> std::convertible_to<T>;
};


template<typename T>
concept Quantity = std::totally_ordered<T>
    && (
        /* We split the above arithmetics code off since, for instance,
         * boost::unit::quantity multiplication and division is defined
         * only for scalars of the underlying floating point type.
         */
           _QuantityArithmetics<T, double>
        || _QuantityArithmetics<T, float>
        || _QuantityArithmetics<T, long double>
    );


/*
 * A physical quantity.
 */
namespace _physquant {

template<typename T>
constexpr bool is_physical_quantity = false;

template<typename T>
constexpr bool is_boost_quantity = false;

template<typename T, typename U>
constexpr bool is_physical_quantity_of_unit = false;

template<typename T>
constexpr bool is_tuple_of_boost_quantities = false;

#ifndef FUNKTIONSKLEMPNER_NO_BOOST

template<typename U, typename R>
constexpr bool is_physical_quantity<
    boost::units::quantity<U, R>
> = true;

template<Unit U, NPTypeRandomAccessIterator Iterator>
constexpr bool is_physical_quantity<
    wrapper::QuantityView<U, Iterator>
> = true;


template<typename U, typename R>
constexpr bool is_boost_quantity<
    boost::units::quantity<U, R>
> = true;


template<typename R, Unit U>
constexpr bool is_physical_quantity_of_unit<
    boost::units::quantity<U, R>, U
> = true;

template<NPTypeRandomAccessIterator Iterator, Unit U>
constexpr bool is_physical_quantity_of_unit<
    wrapper::QuantityView<U, Iterator>, U
> = true;


template<typename T>
concept _BoostQuantity = is_boost_quantity<T>;


template<
    _BoostQuantity... Q
>
constexpr bool is_tuple_of_boost_quantities<
    std::tuple<Q...>
> = true;

#endif

}

template<typename T>
concept PhysicalQuantity = _physquant::is_physical_quantity<
    std::decay_t<T>
>;

template<typename T, typename U>
concept PhysicalQuantityOfUnit
    = _physquant::is_physical_quantity_of_unit<std::decay_t<T>, U>;


template<typename T>
concept TupleOfBoostQuantities = _physquant::is_tuple_of_boost_quantities<
    std::decay_t<T>
>;


}

#endif