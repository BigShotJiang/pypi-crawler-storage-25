/*
 * A coordinate tuple.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_CONCEPTS_COORDINATES_HPP
#define FUNKTIONSKLEMPNER_CONCEPTS_COORDINATES_HPP

#include <type_traits>
#include <funktionsklempner/util/typelist.hpp>
#include <funktionsklempner/concepts/quantity.hpp>

namespace funktionsklempner::coordinates {

/*
 * Coordinate tuple: a structure or class `T` that adheres
 * to the following interface:
 *
 * 1) coordinates::dimension<T>() is defined (let it be `ndim`).
 *
 * 2) Typedef mutable references to coordinate `i` with 0 <= i < ndim:
 *
 *       template<size_t i>
 *       using reference = ...;
 *
 *    This can be used to define custom variable reference classes
 *    (e.g. used in the unit-aware wrappers over floating point buffers).
 *
 * 3) Typedef constant reference to coordinate `i`:
 *
 *        template<size_t i>
 *        using const_reference = ...;
 *
 * 4) Implement a `get<i>()` method that is convertible to the `i`th coordinate
 *    type (the main coordinate tuple functionality).
 */


/*
 * A type to determine the size of a coordinate tuple.
 */
struct no_size {};

/*
 * This template can be specialized to an std::integral_constant for any
 * compile-time fixed-size container to provide the size of the container.
 */
template<typename T>
struct the_tuple_dimension {
    using value = no_size;
};



/*
 * A type to determine the type of the individual coordinates of a
 * coordinate tuple.
 * This implementation here uses decltype to determine the type automatically
 * (which is reasonable for classic containers).
 * The struct can also be specialized for specific implementations where
 * tighter control over the coordinate type is required (e.g. if there
 * are intermediate reference classes).
 */
template<typename T, size_t i>
struct get_coordinate_type
{
    /*
     * The default: use get<i>() to get a reference, then std::decay_t the
     * resulting value to obtain a value. This works for containers of the
     * coordinates---but it does fail for things like the quantity views.
     */
    using type = std::decay_t<decltype(std::declval<T>().template get<i>())>;
};





template<typename T>
constexpr bool is_integral_constant = false;

template<typename T, T v>
constexpr bool is_integral_constant<std::integral_constant<T, v>> = true;


template<typename T>
constexpr size_t tuple_dimension()
{
    using dim = the_tuple_dimension<T>::value;
    static_assert(
        is_integral_constant<dim>,
        "funktionsklempner::coordinates::the_tuple_dimension has not been "
        "properly defined for requested type."
    );
    /* If all good typewise, return the integral value: */
    return dim::value;
}




template<typename T, size_t i, typename... Coordinates>
struct is_coordinate_tuple_iter;

template<typename T, size_t i, typename C, typename... Coordinates>
struct is_coordinate_tuple_iter<T, i, C, Coordinates...>
{
    constexpr static bool value
        = concepts::Quantity<C>
        && requires(T x)
        {
            { std::declval<typename T::template reference<i>>() }
                -> std::convertible_to<C>;
            { std::declval<typename T::template const_reference<i>>() }
                -> std::convertible_to<C>;
            { x.template get<i>() } -> std::convertible_to<C>;
        }
        && is_coordinate_tuple_iter<T, i+1, Coordinates...>::value;
};

template<typename T, size_t i, typename C>
struct is_coordinate_tuple_iter<T, i, C>
{
    constexpr static bool value
        = concepts::Quantity<C>
        && requires(T x)
        {
            { std::declval<typename T::template reference<i>>() }
                -> std::convertible_to<C>;
            { std::declval<typename T::template const_reference<i>>() }
                -> std::convertible_to<C>;
            { x.template get<i>() } -> std::convertible_to<C>;
        };
};

/*
 * Check whether a class is a coordinate tuple of a specific unit:
 */
template<typename T, typename... Coordinates>
struct is_coordinate_tuple_of_unit
{
    constexpr static bool value =
        is_coordinate_tuple_iter<T, 0, Coordinates...>::value
        && (
            tuple_dimension<T>() == sizeof...(Coordinates)
        );
};

template<typename T, typename... Coordinates>
struct is_coordinate_tuple_of_unit<T, std::tuple<Coordinates...>>
{
    constexpr static bool value
        = is_coordinate_tuple_of_unit<T, Coordinates...>::value;
};

/*
 * Assemble the coordinate type tuple of a coordinate tuple:
 */
template<typename T, size_t i>
struct assemble_coordinate_tuple_iter
{
    /* Assert that the initial tuple dimension is finite: */
    static_assert(i != static_cast<size_t>(-1));

    using type = tuple_cat<
        typename assemble_coordinate_tuple_iter<T, i-1>::type,
        std::tuple<typename get_coordinate_type<T, i>::type>
    >;

};

template<typename T>
struct assemble_coordinate_tuple_iter<T, 0>
{
    using type = std::tuple<typename get_coordinate_type<T, 0>::type>;
};


template<typename T>
using assemble_coordinate_tuple = typename
    assemble_coordinate_tuple_iter<
        T,
        tuple_dimension<T>() - 1
    >::type;


/*
 * Checking whether a coordinate tuple is compatible to another
 * coordinate tuple.
 */
template<typename T, typename CV>
struct is_compatible_to
{
    constexpr static bool value = is_compatible_to<
        T,
        assemble_coordinate_tuple<CV>
    >::value;
};

template<typename T, typename... Coordinates>
struct is_compatible_to<T, std::tuple<Coordinates...>>
{
    constexpr static bool value
        = is_coordinate_tuple_of_unit<T, Coordinates...>::value;
};


} // namespace funktionsklempner::coordinates




/*
 * The coordinate tuple concepts.
 * ==============================
 */
namespace funktionsklempner::concepts {

/*
 * CoordinateTuple
 * ---------------
 */
template<typename T>
concept CoordinateTuple = coordinates::is_coordinate_tuple_of_unit<
    T,
    coordinates::assemble_coordinate_tuple<T>
>::value;


/*
 * CoordinateTupleOfUnits
 * ----------------------
 *
 * A coordinate tuple `T` of a specific list of units `U...`
 */
template<typename T, typename... U>
concept CoordinateTupleOfUnits
    = coordinates::is_coordinate_tuple_of_unit<T, U...>::value;



/*
 * CompatibleToCoordinateTuple
 * ------------------
 *
 * A coordinate tuple `T` whose dimensions are compatible to a
 * coordinate tuple `Reference`.
 */
template<typename T, typename Reference>
concept CompatibleToCoordinateTuple
    = coordinates::is_compatible_to<T, Reference>::value;


}


#endif