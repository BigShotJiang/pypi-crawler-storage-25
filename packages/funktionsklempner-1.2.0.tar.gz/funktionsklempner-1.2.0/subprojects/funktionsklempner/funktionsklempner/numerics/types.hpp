/*
 * Result and quantity type inference.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_NUMERICS_RESULTTYPE_HPP
#define FUNKTIONSKLEMPNER_NUMERICS_RESULTTYPE_HPP

#include <funktionsklempner/concepts/quantity.hpp>

namespace funktionsklempner::types {

/*
 * Infer the underlying floating point type of a physical quantity:
 */
template<concepts::PhysicalQuantity T>
struct _infer_fp_type;

template<typename U, typename R>
struct _infer_fp_type<boost::units::quantity<U, R>>
{
    using type = R;
};

template<Unit U, concepts::NPTypeRandomAccessIterator It>
struct _infer_fp_type<wrapper::QuantityView<U, It>>
{
    using type = std::iter_value_t<It>;
};

template<typename T>
using floating_point_type = typename _infer_fp_type<T>::type;


/*
 * Infer the underlying unit of a physical quantity:
 */
template<concepts::PhysicalQuantity T>
struct _infer_unit;

template<typename U, typename R>
struct _infer_unit<boost::units::quantity<U, R>>
{
    using type = U;
};

template<Unit U, concepts::NPTypeRandomAccessIterator It>
struct _infer_unit<wrapper::QuantityView<U, It>>
{
    using type = U;
};

template<typename T>
using unit = typename _infer_unit<T>::type;




}

/*
 * 2. Result types.
 */

namespace funktionsklempner::resulttype {


template<typename Real1, typename Real2>
struct result_type
{
    using type = double;
};

template<typename Real2>
struct result_type<long double, Real2>
{
    using type = long double;
};

template<typename Real1>
struct result_type<Real1, long double>
{
    using type = long double;
};

template<>
struct result_type<float,float>
{
    using type = float;
};



/*
 *     sqrt
 *     ====
 */
template<typename Real>
struct sqrt_result_type {
    using type = Real;
};

#ifndef FUNKTIONSKLEMPNER_NO_BOOST
template<typename U, typename R>
struct sqrt_result_type<boost::units::quantity<U, R>> {
    using TWO = boost::units::static_rational<2,1>;
    using root_unit = typename boost::units::root_typeof_helper<U, TWO>::type;
    using type = boost::units::quantity<root_unit, R>;
};
#endif



/*
 *     sin
 *     ===
 */
template<typename Real>
struct sin_result_type;

template<std::floating_point Real>
struct sin_result_type<Real>{
    using type = Real;
};

#ifndef FUNKTIONSKLEMPNER_NO_BOOST
template<typename U, typename R>
struct sin_result_type<boost::units::quantity<U, R>> {
    using type = R;
};

template<Unit U, concepts::NPTypeRandomAccessIterator It>
struct sin_result_type<wrapper::QuantityView<U, It>>
{
    using type = std::iter_value_t<It>;
};
#endif

/*
 *     asin
 *     ====
 */
#ifdef FUNKTIONSKLEMPNER_NO_BOOST
template<typename Real>
struct asin_result_type
{
    using type = Real;
};

#else
template<typename Real>
struct asin_result_type;

template<std::floating_point Real>
struct asin_result_type<Real>
{
    using type = boost::units::quantity<
        boost::units::si::plane_angle,
        Real
    >;
};

template<std::integral Int>
struct asin_result_type<Int>
{
    using type = boost::units::quantity<
        boost::units::si::plane_angle,
        double
    >;
};

#endif


}





#endif