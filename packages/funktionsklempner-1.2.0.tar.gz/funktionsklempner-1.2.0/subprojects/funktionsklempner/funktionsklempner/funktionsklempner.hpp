/*
 * Funktionsklempner API.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_FUNKTIONSKLEMPNER_HPP
#define FUNKTIONSKLEMPNER_FUNKTIONSKLEMPNER_HPP

#include <funktionsklempner/cdecl.hpp>
#include <funktionsklempner/wrapper/ndarray.hpp>
#include <funktionsklempner/scalar.hpp>
#include <funktionsklempner/quantity.hpp>
#include <funktionsklempner/wrapper/quantityarray.hpp>
#include <funktionsklempner/wrapper/vectorview.hpp>
#include <funktionsklempner/geo/pointview.hpp>

/*
 * Macros for marking exports:
 */
#define FUNKTIONSKLEMPNER_EXPORT_FUNCTION
#define FUNKTIONSKLEMPNER_EXPORT_STRUCT
#define FUNKTIONSKLEMPNER_SIZE_CONTROL(controlled, controller)
#define FUNKTIONSKLEMPNER_ELLIPSOID_CONTROL(controlled, controller)



/*
 * Funktions for use with Funktionsklempner parsing.
 *
 * _These names are the Funktionsklempner API._
 */
namespace funktionsklempner {

/*
 * Specialize the NDArray for input and output.
 * This allows specifying input and output arguments
 * via type names.
 *
 * InputNDArray: for input to the C++ world from the Python world
 *               (i.e. just read access in C++).
 * OutputNDArray: for output from the C++ world to the Python world
 *                (i.e. read and write access in C++).
 */
template<NonConstNumPyDType T>
using InputNDArray = ndarray::NDArray<const T>;

template<NonConstNumPyDType T>
using OutputNDArray = ndarray::NDArray<T>;



/*
 * Specialize the QuantityArray for input and output.
 * This allows specifying input and output arguments
 * via type names.
 *
 * InputQuantityArray:
 *    for input to the C++ world from the Python world
 *    (i.e. just read access in C++).
 * OutputQuantityArray:
 *    for output from the C++ world to the Python world
 *    (i.e. read and write access in C++).
 */
template<Unit U, NonConstNumPyDType T, bool bounds_check=true>
using InputQuantityArray = wrapper::QuantityArray<U, const T, bounds_check>;

template<Unit U, NonConstNumPyDType T, bool bounds_check=true>
using OutputQuantityArray = wrapper::QuantityArray<U, T, bounds_check>;




template<size_t ndim, NonConstNumPyDType T>
using InputEuclideanPointArray = geo::EuclideanPointRange<
    ndim,
    true,
    InputNDArray<T>
>;

template<size_t ndim, NonConstNumPyDType T>
using OutputEuclideanPointArray = geo::EuclideanPointRange<
    ndim,
    false,
    OutputNDArray<T>
>;

template<
    NonConstNumPyDType T,
    geo::Ellipsoid_t ellipsoid,
    bool with_height
>
using InputGeographicPointArray = geo::GeographicPointRange<
    ellipsoid,
    true,
    std::conditional_t<
        with_height,
        concepts::geographic::_GeographicUnitsWithHeight,
        concepts::geographic::_GeographicUnits
    >,
    InputNDArray<T>
>;

template<
    NonConstNumPyDType T,
    geo::Ellipsoid_t ellipsoid,
    bool with_height
>
using OutputGeographicPointArray = geo::GeographicPointRange<
    ellipsoid,
    false,
    std::conditional_t<
        with_height,
        concepts::geographic::_GeographicUnitsWithHeight,
        concepts::geographic::_GeographicUnits
    >,
    OutputNDArray<T>
>;

}

#endif