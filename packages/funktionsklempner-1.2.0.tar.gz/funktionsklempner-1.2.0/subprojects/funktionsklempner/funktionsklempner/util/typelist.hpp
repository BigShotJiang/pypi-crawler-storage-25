/*
 * List of types based on std::tuple as a type container.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_UTIL_TYPELIST_HPP
#define FUNKTIONSKLEMPNER_UTIL_TYPELIST_HPP

#include <utility>

namespace funktionsklempner {

namespace util {

/*
 * Tuple cat:
 */
template<typename T0, typename T1>
struct tuple_cat;

template<typename... T0, typename... T1>
struct tuple_cat<std::tuple<T0...>, std::tuple<T1...>>
{
    using type = std::tuple<T0..., T1...>;
};


/*
 * Repeat a type:
 */
template<typename T, size_t n>
struct repeat_type {
    using type = typename tuple_cat<
        std::tuple<T>,
        typename repeat_type<T, n-1>::type
    >::type;
};
template<typename T>
struct repeat_type<T, 1> {
    using type = std::tuple<T>;
};

template<typename T>
struct repeat_type<T, 0> {
    using type = std::tuple<>;
};




} // namespace util


/*
 * Shorthands:
 */
template<typename T0, typename T1>
using tuple_cat = typename util::tuple_cat<T0, T1>::type;

template<typename T, size_t n>
using repeat_type = typename util::repeat_type<T, n>::type;


}


#endif