/*
 * Making a homogeneous tuple of n repetitions of the same value.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_UTIL_HOMOGENEOUSTUPLE_HPP
#define FUNKTIONSKLEMPNER_UTIL_HOMOGENEOUSTUPLE_HPP

#include <utility>
#include <funktionsklempner/util/typelist.hpp>

namespace funktionsklempner::util {

template<
    size_t ndim,
    typename T
>
constexpr
funktionsklempner::repeat_type<T, ndim>
make_homogeneous_unit_tuple(const T& val)
{
    using result_type = funktionsklempner::repeat_type<T, ndim>;
    /*
     * A function that always maps to the same value regardless of index:
     */
    auto the_value =
    [&val](size_t i) -> const T&
    {
        return val;
    };

    /*
     * Creating the loop indices:
     */
    using I = std::make_index_sequence<ndim>;

    /*
     * Loop over the indices:
     */
    auto the_loop =
    [the_value]<size_t... I>(std::index_sequence<I...>&&) -> result_type
    {
        return result_type(the_value(I)...);
    };

    return the_loop.template operator()(I());
}


}

#endif