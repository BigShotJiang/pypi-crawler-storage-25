/*
 * NumPy arrays in which the last dimension iterates vector data.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_NO_BOOST

#ifndef FUNKTIONSKLEMPNER_VECTORVIEW_HPP
#define FUNKTIONSKLEMPNER_VECTORVIEW_HPP

#include <funktionsklempner/concepts/numpybuffer.hpp>
#include <funktionsklempner/concepts/coordinates.hpp>
#include <funktionsklempner/wrapper/quantityview.hpp>
#include <funktionsklempner/util/typelist.hpp>
#include <funktionsklempner/util/unit2quantity.hpp>


namespace funktionsklempner::wrapper {

/*
 * Some properties that will be used by all classes involved with
 * iterating vector quantities:
 */
template<
    concepts::NPTypeRandomAccessIterator Iterator,
    Unit... U
>
struct VectorQuantityProperties
{
    using Value = std::iter_value_t<Iterator>;

    /*
     * Singling out the data type of a value of the `i`th dimension,
     * either as boost::units::quantity or as a QuantityView:
     */
    template<size_t i>
    using Quantity = boost::units::quantity<
        std::tuple_element_t<i, std::tuple<U...>>,
        Value
    >;

    template<size_t i>
    using QView = QuantityView<
        std::tuple_element_t<i, std::tuple<U...>>,
        Iterator
    >;

    /*
     * This is an std::tuple of the units of the dimensions, i.e.,
     * std::tuple<Q0, Q1, Q2, ...>, where Q0 is a Boost quantity
     * specifying the unit of dimension (or axis) 0; Q1 is a quantity
     * specifying the unit of dimension 1, and so on.
     * The tuple type is computed from `U...` with the tuple_cat
     * code further up in this header.
     */
    using QuantityTuple = util::units_to_quantities<std::tuple<U...>, Value>;

};


template<
    concepts::NPTypeRandomAccessIterator Iterator,
    typename T
>
class VectorQuantityView;



template<
    concepts::NPTypeRandomAccessIterator Iterator,
    Unit... U
>
class VectorQuantityView<Iterator, std::tuple<U...>>
{
public:
    /*
     * Number of dimensions:
     */
    constexpr static size_t ndim = sizeof...(U);

    /*
     * Types:
     */
    template<size_t i>
    using Quantity = typename VectorQuantityProperties<
        Iterator, U...
    >::template Quantity<i>;

    template<size_t i>
    using QView = typename VectorQuantityProperties<
        Iterator, U...
    >::template QView<i>;

    using QuantityTuple = typename VectorQuantityProperties<
        Iterator, U...
    >::QuantityTuple;

    /*
     * CoordinateProvider typedefs:
     */
    template<size_t i>
    using reference = QView<i>;

    template<size_t i>
    using const_reference = QView<i>;

    /*
     * Constructors:
     */
    template<
        std::convertible_to<Iterator> It
    >
    constexpr VectorQuantityView(
        It&& it_,
        QuantityTuple&& qt
    ) noexcept
       : it(std::forward<It>(it)), units(std::move(qt))
    {}


    template<
        std::convertible_to<Iterator> It
    >
    constexpr VectorQuantityView(
        It&& it_,
        const QuantityTuple& qt
    ) noexcept
       : it(std::forward<It>(it_)), units(qt)
    {}


    /*
     * Get a view into the `i`th dimension:
     */
    template<size_t i>
    requires (i < ndim)
    QView<i> get() const
    {
        return QView<i>(it+i, std::get<i>(units));
    }

private:
    /*
     * The pointer to the start of the data:
     */
    Iterator it;

    /*
     * The units:
     */
    QuantityTuple units;

};



/*
 * Mutable version:
 */
template<
    concepts::NPTypeRandomAccessIterator Iterator,
    typename T
> requires std::output_iterator<
    Iterator,
    std::decay_t<decltype(*std::declval<Iterator>())>
>
class MutableVectorQuantityView;


template<
    concepts::NPTypeRandomAccessIterator Iterator,
    Unit... U
> requires std::output_iterator<
    Iterator,
    std::decay_t<decltype(*std::declval<Iterator>())>
>
class MutableVectorQuantityView<Iterator, std::tuple<U...>> :
    public VectorQuantityView<Iterator, std::tuple<U...>>
{
    using Base = VectorQuantityView<Iterator, std::tuple<U...>>;
public:
    using Base::VectorQuantityView;
    using QuantityTuple = typename Base::QuantityTuple;


    /*
     * Assignment as an addon:
     */
    template<
        concepts::CompatibleToCoordinateTuple<QuantityTuple> V
    >
    const MutableVectorQuantityView&
    operator=(const V& v) const
    {
        // Use a fold over an index sequence to assign all coordinates.
        constexpr size_t ndim = sizeof...(U);
        auto copy = [this,&v]<size_t... i>(std::index_sequence<i...>)
        {
            ([this,&v](){this->template get<i>() = v.template get<i>();}(), ...);
        };
        copy(std::make_index_sequence<ndim>());


        return *this;
    }
};




/*
 * Checking for that class in a concept.
 * We use a constexpr function here to match both VectorQuantityView
 * and MutableVectorQuantityView through function argument overloading.
 *
 * First the 'catch-all' argument through implicit conversion to void
 * pointer:
 */
constexpr bool _is_vector_quantity_view(const void*)
{
    return false;
}


template<
    std::random_access_iterator Iterator,
    Unit... U
> requires NumPyDType<
    decltype(*std::declval<Iterator>())
>
constexpr bool _is_vector_quantity_view(
    const VectorQuantityView<Iterator, std::tuple<U...>>* vqv
)
{
    return true;
}


template<typename T>
constexpr bool is_vector_quantity_view
    = _is_vector_quantity_view(static_cast<const T*>(nullptr));



}



/*
 * Specialize the vector_dimension:
 */
namespace funktionsklempner::coordinates {

template<
    concepts::NPTypeRandomAccessIterator Iterator,
    Unit... U
>
struct the_tuple_dimension<
    wrapper::VectorQuantityView<Iterator, std::tuple<U...>>
>
{
    using value = std::integral_constant<size_t, sizeof...(U)>;
};


template<
    concepts::NPTypeRandomAccessIterator Iterator,
    Unit... U
>
struct the_tuple_dimension<
    wrapper::MutableVectorQuantityView<Iterator, std::tuple<U...>>
>
{
    using value = std::integral_constant<size_t, sizeof...(U)>;
};


/*
 * Specialize the coordinate type for when this is used as a
 * coordinate provider:
 */

template<typename T, size_t i>
struct get_coordinate_type;


template<
    concepts::NPTypeRandomAccessIterator Iterator,
    Unit... U,
    size_t i
>
struct get_coordinate_type<
    wrapper::VectorQuantityView<
        Iterator,
        std::tuple<U...>
    >,
    i
>
{
    using QuantityTuple = typename wrapper::VectorQuantityView<
        Iterator,
        std::tuple<U...>
    >::QuantityTuple;

    using type = std::tuple_element_t<i, QuantityTuple>;
};


template<
    concepts::NPTypeRandomAccessIterator Iterator,
    Unit... U,
    size_t i
>
struct get_coordinate_type<
    wrapper::MutableVectorQuantityView<
        Iterator,
        std::tuple<U...>
    >,
    i
>
{
    using QuantityTuple = typename wrapper::MutableVectorQuantityView<
        Iterator,
        std::tuple<U...>
    >::QuantityTuple;

    using type = std::tuple_element_t<i, QuantityTuple>;
};


}


/*
 * Concept VectorQuantityView:
 */
namespace funktionsklempner::concepts {


template<typename T>
concept VectorQuantityView = wrapper::is_vector_quantity_view<T>;


}

#endif
#endif