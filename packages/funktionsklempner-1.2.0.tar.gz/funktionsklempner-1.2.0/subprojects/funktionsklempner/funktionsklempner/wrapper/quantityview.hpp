/*
 * A proxy reference class to a Quantity.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */


/*
 * Can also use Funktionsklempner without Boost as a requirement;
 * this can be done by defining NO_BOOST.
 */
#ifndef FUNKTIONSKLEMPNER_NO_BOOST

#ifndef FUNKTIONSKLEMPNER_QUANTITYVIEW_HPP
#define FUNKTIONSKLEMPNER_QUANTITYVIEW_HPP

#include <funktionsklempner/unit/units.hpp>
#include <funktionsklempner/concepts/numpybuffer.hpp>
#include <funktionsklempner/concepts/iterator.hpp>
#include <funktionsklempner/util/macros.hpp>

#include <boost/units/quantity.hpp>
#include <boost/units/systems/si.hpp>


namespace funktionsklempner::wrapper {


template<
    Unit U,
    concepts::NPTypeRandomAccessIterator Iterator
>
class QuantityView
{
public:
    /*
     * Types and properties
     */
    using T = std::iter_value_t<Iterator>;

    using Quantity = boost::units::quantity<U, T>;

    /* `T` decays the constness of the iterator.
     * Check here whether we can assign to the iterator: */
    constexpr static bool assignable = std::is_assignable_v<
        decltype(*std::declval<Iterator>()),
        T
    >;


    /*
     * Constructor
     */
    template<
        std::convertible_to<Iterator> It
    >
    constexpr QuantityView(It&& ptr, const Quantity& unit)
       : ptr(std::forward<It>(ptr)), unit(unit)
    {
        if constexpr (std::is_pointer_v<Iterator>){
            if (ptr == nullptr)
                throw std::runtime_error(
                    "Found nullptr in QuantityView initialization."
                );
        }
    }

    constexpr operator Quantity() const noexcept
    {
        return *ptr * unit;
    }

    /* Mimic boost::units::quantity's `value()` method: */
    constexpr const T& value() const noexcept
    {
        return *ptr;
    }

    /*
     * To be able to let this be used in place of a
     * Quantity&, implement assignment and increment
     * operators.
     */
    template<
        FUNKTIONSKLEMPNER_ENABLE_IF(assignable)
    >
    constexpr const QuantityView& operator=(const Quantity& q) const
    {
        *ptr = q / unit;
        return *this;
    }


    template<
        FUNKTIONSKLEMPNER_ENABLE_IF(assignable)
    >
    constexpr const QuantityView& operator+=(const Quantity& q) const
    {
        *ptr += q / unit;
        return *this;
    }


    template<
        FUNKTIONSKLEMPNER_ENABLE_IF(assignable)
    >
    constexpr const QuantityView& operator-=(const Quantity& q) const
    {
        *ptr -= q / unit;
        return *this;
    }


    constexpr auto operator<=>(const Quantity& q) const noexcept
    {
        return *ptr <=> q.value();
    }

    constexpr bool operator==(const Quantity& q) const noexcept
    {
        return *ptr * unit == q;
    }

    constexpr Quantity operator+(const Quantity& q) const noexcept
    {
        return (*ptr * unit) + q;
    }

    constexpr Quantity operator-(const Quantity& q) const noexcept
    {
        return (*ptr * unit) - q;
    }

    constexpr Quantity operator*(double d) const noexcept
    {
        return (*ptr * d) * unit;
    }

    constexpr Quantity operator/(double d) const noexcept
    {
        return (*ptr / d) * unit;
    }

    constexpr double operator/(const U& u) const noexcept
    {
        return *ptr * (unit / u);
    }

    constexpr double operator/(const Quantity& q) const noexcept
    {
        return *ptr * (unit / q);
    }

private:
    Iterator ptr;
    Quantity unit;
};


/*
 * Operators with boost quantities as LHS:
 */
template<
    Unit U,
    NumPyDType Tl,
    concepts::NPTypeRandomAccessIterator Iter
>
constexpr auto
operator+(
    const boost::units::quantity<U, Tl>& l,
    const QuantityView<U, Iter>& r
) noexcept
{
    using Tr = std::iter_value_t<Iter>;
    return l + static_cast<boost::units::quantity<U, Tr>>(r);
}


template<
    Unit U,
    NumPyDType Tl,
    concepts::NPTypeRandomAccessIterator Iter
>
constexpr auto
operator-(
    const boost::units::quantity<U, Tl>& l,
    const QuantityView<U, Iter>& r) noexcept
{
    using Tr = std::iter_value_t<Iter>;
    return l - static_cast<boost::units::quantity<U, Tr>>(r);
}


template<
    Unit Ul,
    NumPyDType Tl,
    Unit Ur,
    concepts::NPTypeRandomAccessIterator Iter_r
>
constexpr auto
operator*(
    const boost::units::quantity<Ul, Tl>& l,
    const QuantityView<Ur, Iter_r>& r
)
{
    using Tr = std::iter_value_t<Iter_r>;
    return l * static_cast<boost::units::quantity<Ur, Tr>>(r);
}


template<
    Unit Ul,
    concepts::NPTypeRandomAccessIterator Iter_l,
    Unit Ur,
    NumPyDType Tr
>
constexpr auto
operator*(
    const QuantityView<Ul, Iter_l>& l,
    const boost::units::quantity<Ur, Tr>& r
)
{
    using Tl = std::iter_value_t<Iter_l>;
    return static_cast<boost::units::quantity<Ul, Tl>>(l) * r;
}


template<
    Unit Ul,
    concepts::NPTypeRandomAccessIterator Iter_l,
    Unit Ur,
    concepts::NPTypeRandomAccessIterator Iter_r
>
constexpr auto
operator*(
    const QuantityView<Ul, Iter_l>& l,
    const QuantityView<Ur, Iter_r>& r
)
{
    using Tl = std::iter_value_t<Iter_l>;
    using Tr = std::iter_value_t<Iter_r>;
    using Ql = boost::units::quantity<Ul, Tl>;
    using Qr = boost::units::quantity<Ur, Tr>;
    return static_cast<Ql>(l) * static_cast<Qr>(r);
}


template<
    Unit U,
    concepts::NPTypeRandomAccessIterator Iter
>
constexpr auto
operator*(double d, const QuantityView<U, Iter>& qv)
{
    return qv * d;
}


template<
    Unit Ul,
    NumPyDType Tl,
    Unit Ur,
    concepts::NPTypeRandomAccessIterator Iter_r
>
constexpr auto
operator/(
    const boost::units::quantity<Ul, Tl>& l,
    const QuantityView<Ur, Iter_r>& r
)
{
    using Tr = std::iter_value_t<Iter_r>;
    return l / static_cast<boost::units::quantity<Ur, Tr>>(r);
}


template<
    Unit Ul,
    concepts::NPTypeRandomAccessIterator Iter_l,
    Unit Ur,
    NumPyDType Tr
>
constexpr auto
operator/(
    const QuantityView<Ul, Iter_l>& l,
    const boost::units::quantity<Ur, Tr>& r
)
{
    using Tl = std::iter_value_t<Iter_l>;
    return static_cast<boost::units::quantity<Ul, Tl>>(l) / r;
}


template<
    Unit Ul,
    concepts::NPTypeRandomAccessIterator Iter_l,
    Unit Ur,
    concepts::NPTypeRandomAccessIterator Iter_r
>
constexpr auto
operator/(
    const QuantityView<Ul, Iter_l>& l,
    const QuantityView<Ur, Iter_r>& r
)
{
    using Tl = std::iter_value_t<Iter_l>;
    using Tr = std::iter_value_t<Iter_r>;
    using Ql = boost::units::quantity<Ul, Tl>;
    using Qr = boost::units::quantity<Ur, Tr>;
    return static_cast<Ql>(l) / static_cast<Qr>(r);
}


template<
    Unit U,
    concepts::NPTypeRandomAccessIterator Iter
>
constexpr auto
operator/(double d, const QuantityView<U, Iter>& qv)
{
    namespace bu = boost::units;
    return bu::quantity<bu::si::dimensionless>::from_value(d) / qv;
}




} // namespace funktionsklempner::wrapper

#endif
#endif