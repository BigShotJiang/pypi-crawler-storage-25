/*
 * Constexpr / non-constexpr math.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_MATH_HPP
#define FUNKTIONSKLEMPNER_MATH_HPP

#include <cmath>
#include <array>
#include <gcem.hpp>
#include <funktionsklempner/concepts/quantity.hpp>

#ifndef FUNKTIONSKLEMPNER_NO_BOOST
#include <boost/units/quantity.hpp>
#include <boost/units/systems/si/plane_angle.hpp>
#include <funktionsklempner/concepts/unit.hpp>
#include <funktionsklempner/numpytypes.hpp>
#include <funktionsklempner/numerics/types.hpp>

#endif

namespace funktionsklempner::math {

/*
 * Type used for representing precision:
 */

template<typename Real1, typename Real2>
using result_type
    = typename resulttype::result_type<Real1,Real2>::type;

template<typename Real>
using sqrt_result_type = typename resulttype::sqrt_result_type<Real>::type;

template<typename Real>
using sin_result_type = typename resulttype::sin_result_type<Real>::type;

template<typename Real>
using asin_result_type
    = typename resulttype::asin_result_type<Real>::type;


template<typename Real1, typename Real2>
constexpr result_type<Real1,Real2> pow(Real1 base, Real2 exponent)
{
    if (std::is_constant_evaluated()){
        return gcem::pow(base, exponent);
    } else {
        return std::pow(base, exponent);
    }
}


template<typename Real>
constexpr Real exp(Real x)
{
    if (std::is_constant_evaluated()){
        return gcem::exp(x);
    } else {
        return std::exp(x);
    }
}


/*
 * Specializations of sqrt for
 *  - constexpr vs runtime
 *  - standard floating point types vs boost quantities.
 */
namespace _sqrt {

template<typename Real>
constexpr sqrt_result_type<Real> constexpr_sqrt(const Real& x)
{
    return gcem::sqrt(x);
}

template<typename Real>
sqrt_result_type<Real> runtime_sqrt(const Real& x)
{
    return std::sqrt(x);
}


#ifndef FUNKTIONSKLEMPNER_NO_BOOST
template<concepts::PhysicalQuantity Q>
constexpr sqrt_result_type<Q>
constexpr_sqrt(const Q& x)
{
    using Qout = sqrt_result_type<Q>;
    using R = types::floating_point_type<Qout>;
    return Qout::from_value(
        gcem::sqrt(boost::units::quantity_cast<const R&>(x))
    );
}

template<concepts::PhysicalQuantity Q>
sqrt_result_type<Q>
runtime_sqrt(const Q& x)
{
    using Qout = sqrt_result_type<Q>;
    using R = types::floating_point_type<Qout>;
    return Qout::from_value(
        std::sqrt(boost::units::quantity_cast<const R&>(x))
    );
}
#endif


}


template<typename Real>
constexpr sqrt_result_type<Real>
sqrt(const Real& x)
{
    if (std::is_constant_evaluated()){
        return _sqrt::constexpr_sqrt(x);
    } else {
        return _sqrt::runtime_sqrt(x);
    }
}



/*
 * For comparison with zero (which is a bit tricky with quantities):
 */
template<typename Real>
constexpr Real ZERO = 0;

#ifndef FUNKTIONSKLEMPNER_NO_BOOST
template<typename U>
constexpr boost::units::quantity<U> ZERO<boost::units::quantity<U>>
    = boost::units::quantity<U>::from_value(0.0);
#endif


template<typename Real>
constexpr Real abs(Real x)
{
    if (x >= ZERO<Real>)
        return x;
    return -x;
}


/*
 * An implementation of 10^x with look-up table support.
 */
namespace _pow10 {
    /* Size of the look-up table (has to be odd!) */
    constexpr size_t N_LUP = 61;
        static_assert(
            N_LUP % 2 == 1, "Exponent to scale look-up table has to be of odd size."
        );
    constexpr static std::array<double, N_LUP> lup{
        1e-30, 1e-29, 1e-28, 1e-27, 1e-26, 1e-25, 1e-24, 1e-23, 1e-22, 1e-21,
        1e-20, 1e-19, 1e-18, 1e-17, 1e-16, 1e-15, 1e-14, 1e-13, 1e-12, 1e-11,
        1e-10,  1e-9,  1e-8,  1e-7,  1e-6,  1e-5,  1e-4,  1e-3,  1e-2,  1e-1,
        1.0,
         1e1,  1e2,  1e3,  1e4,  1e5,  1e6,  1e7,  1e8,  1e9, 1e10,
        1e11, 1e12, 1e13, 1e14, 1e15, 1e16, 1e17, 1e18, 1e19, 1e20,
        1e21, 1e22, 1e23, 1e24, 1e25, 1e26, 1e27, 1e28, 1e29, 1e30
    };
}

constexpr double pow10(int exponent)
{
    constexpr int max_lup_exp = (_pow10::N_LUP - 1) / 2;
    if (exponent >= -max_lup_exp && exponent <= max_lup_exp)
        return _pow10::lup[exponent + max_lup_exp];

    return pow(10.0, exponent);

}



/*
 * Specializations of   sin   for
 *                      ^^^
 *  - constexpr vs runtime
 *  - standard floating point types vs boost quantities.
 */
namespace _sin_cos {

template<std::floating_point Real>
constexpr sin_result_type<Real> constexpr_sin(const Real& x)
{
    return gcem::sin(x);
}

template<std::floating_point Real>
sin_result_type<Real> runtime_sin(const Real& x)
{
    return std::sin(x);
}


#ifndef FUNKTIONSKLEMPNER_NO_BOOST

template<
    concepts::PhysicalQuantityOfUnit<boost::units::si::plane_angle> Q
>
constexpr
sin_result_type<Q>
constexpr_sin(
    const Q& x
)
{
    return gcem::sin(x / boost::units::si::radian);
}



template<
    concepts::PhysicalQuantityOfUnit<boost::units::si::plane_angle> Q
>
sin_result_type<Q>
runtime_sin(
    const Q& x
)
{
    return std::sin(x / boost::units::si::radian);
}
#endif

/*
 * cosine
 */
template<std::floating_point Real>
constexpr sin_result_type<Real> constexpr_cos(const Real& x)
{
    return gcem::cos(x);
}

template<std::floating_point Real>
sin_result_type<Real> runtime_cos(const Real& x)
{
    return std::cos(x);
}


#ifndef FUNKTIONSKLEMPNER_NO_BOOST
template<
    concepts::PhysicalQuantityOfUnit<boost::units::si::plane_angle> Q
>
constexpr
sin_result_type<Q>
constexpr_cos(
    const Q& x
)
{
    return gcem::cos(x / boost::units::si::radian);
}

template<
    concepts::PhysicalQuantityOfUnit<boost::units::si::plane_angle> Q
>
sin_result_type<Q>
runtime_cos(const Q& x)
{
    return std::cos(x / boost::units::si::radian);
}

#endif


}


template<typename Real>
constexpr sin_result_type<Real>
sin(const Real& x)
{
    if (std::is_constant_evaluated()){
        return _sin_cos::constexpr_sin(x);
    } else {
        return _sin_cos::runtime_sin(x);
    }
}

template<typename Real>
constexpr sin_result_type<Real>
cos(const Real& x)
{
    if (std::is_constant_evaluated()){
        return _sin_cos::constexpr_cos(x);
    } else {
        return _sin_cos::runtime_cos(x);
    }
}


/*
 * Inverse trigonometric functions.
 */
namespace _trig_inverse {

#ifndef FUNKTIONSKLEMPNER_NO_BOOST

/*
 * asin
 */
template<typename Real>
constexpr asin_result_type<Real> constexpr_asin(const Real& x)
{
    return gcem::asin(x) * boost::units::si::radians;
}

template<typename Real>
asin_result_type<Real> runtime_asin(const Real& x)
{
    return std::asin(x) * boost::units::si::radians;
}

/*
 * atan
 */
template<typename Real>
constexpr asin_result_type<Real> constexpr_atan(const Real& x)
{
    return gcem::atan(x) * boost::units::si::radians;
}

template<typename Real>
asin_result_type<Real> runtime_atan(const Real& x)
{
    return std::atan(x) * boost::units::si::radians;
}

/*
 * atan2
 */
template<std::floating_point Real0, std::floating_point Real1>
constexpr
asin_result_type<result_type<Real0, Real1>>
constexpr_atan2(const Real0& y, const Real1& x)
{
    return gcem::atan2(y, x) * boost::units::si::radians;
}

/* Specialization for two physical quantities of the same unit
 * (which cancels out): */
template<
    concepts::PhysicalQuantity Q0,
    concepts::PhysicalQuantityOfUnit<types::unit<Q0>> Q1
>
constexpr
asin_result_type<
    result_type<
        types::floating_point_type<Q0>,
        types::floating_point_type<Q1>
    >
>
constexpr_atan2(const Q0& y, const Q1& x)
{
    /* Quantities of same unit: unit cancels out. */
    return gcem::atan2(y.value(), x.value())
        * boost::units::si::radians;
}




template<
    concepts::PhysicalQuantity Q0,
    concepts::PhysicalQuantityOfUnit<types::unit<Q0>> Q1
>
asin_result_type<
    result_type<
        types::floating_point_type<Q0>,
        types::floating_point_type<Q1>
    >
>
runtime_atan2(const Q0& y, const Q1& x)
{
    return std::atan2(y.value(), x.value())
        * boost::units::si::radians;
}

#else

template<typename Real>
constexpr asin_result_type<Real> constexpr_asin(const Real& x)
{
    return gcem::asin(x);
}

template<typename Real>
asin_result_type<Real> runtime_asin(const Real& x)
{
    return std::asin(x);
}

#endif

}


template<typename Real>
constexpr asin_result_type<Real>
asin(const Real& x)
{
    if (std::is_constant_evaluated()){
        return _trig_inverse::constexpr_asin(x);
    } else {
        return _trig_inverse::runtime_asin(x);
    }
}


template<typename Real>
constexpr asin_result_type<Real>
atan(const Real& x)
{
    if (std::is_constant_evaluated()){
        return _trig_inverse::constexpr_atan(x);
    } else {
        return _trig_inverse::runtime_atan(x);
    }
}


template<typename Real0, typename Real1>
constexpr
auto
atan2(const Real0& y, const Real1& x)
{
    if (std::is_constant_evaluated()){
        return _trig_inverse::constexpr_atan2(y,x);
    } else {
        return _trig_inverse::runtime_atan2(y,x);
    }
}


}


#endif