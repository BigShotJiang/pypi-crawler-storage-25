# Funkybadger
An example project for how to use the Funktionsklempner toolkit for interfacing C++ code to the Python world via ctypes (*in an automated fashion!*).