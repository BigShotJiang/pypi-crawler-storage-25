# This script runs the test functions defined in cpp/example.hpp.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2025 Technische Universität München

import pytest
from funkybadger.example import test_function, test_function_2, test_function_3, \
    test_function_4, test_function_5, test_function_6, test_function_7, \
    test_function_8, test_function_9, test_function_10, test_function_11, \
    test_function_12, test_function_13
from funkybadger._funktionsklempner.quantityarray import QuantityArray
from funkybadger._funktionsklempner.pointarray import EuclideanPointArray, \
    GeographicPointArray

import numpy as np

def test0():
    """
    Tests test_function
    """
    name = "testname"
    i = 0
    result = test_function(name, i)
    assert result == 1.7281
    print("test0 result =", test_function(name, i))


def test1():
    """
    Tests test_function_2
    """
    result = test_function_2()
    assert result == "test test"
    print("test1 result =",test_function_2())


def test2():
    """
    Tests test_function_3
    """
    x = np.random.random(10)
    y = test_function_3(x)
    assert np.allclose(2.0 * x, y)


def test3():
    """
    Test test_function_4
    """
    array = np.random.random(38)
    qa = QuantityArray(array, 'm')
    out = test_function_4(qa)

    # Computes the potential energy of lifting
    # an object of 1 kg by 'qa':
    print("out.unit:", out.unit)
    assert out.unit == "J"

    for xin,xout in zip(qa.array, out.array):
        assert xout == 9.81 * xin


def test4():
    """
    Test test_function_5
    """
    rng = np.random.default_rng(283928)
    a0 = rng.random(5)
    a1 = rng.random(7)
    a2 = rng.random((2,3))
    qa0 = QuantityArray(a0, 'm')
    qa1 = QuantityArray(a1, 'kg')
    qa2 = QuantityArray(a2, 'kg')
    out = test_function_5(qa0, qa1)

    # Check that shape and unit matches our expectation.
    # Inside test_function_5, we compute 'm*g*h', potential
    # energy.
    assert out.shape == (a0.size, a1.size)
    assert out.unit == "J"

    # Check the quantitative results:
    assert np.allclose(out.array, 9.81 * a0[:,np.newaxis] * a1[np.newaxis,:])

    # Check the advanced shape computation:
    out2 = test_function_5(qa0, qa2)
    assert out2.shape == (a0.size, *a2.shape)
    assert out2.unit == "J"

    assert np.allclose(
        out2.array, 9.81 * a0[:,np.newaxis, np.newaxis] * a2[np.newaxis,:,:]
    )


def test5():
    """
    Test test_function_6
    """
    rng = np.random.default_rng(283928)
    xyz = rng.random((10,3))
    xyz_array = EuclideanPointArray(xyz, 'cm')

    out = test_function_6(xyz_array)
    print("out unit:", out.raw()[1])
    # assert out.raw()[1] == 'cm'
    print("out:", out.raw()[0])
    print("cmp:", np.linalg.norm(xyz, axis=1))

    assert np.allclose(
        100 * out.raw()[0],
        np.linalg.norm(xyz, axis=1)
    )


def test6():
    """
    Test test_function_7
    """
    rng = np.random.default_rng(3238)
    r = rng.random(10)
    theta = 180.0 * (0.5 - rng.random(10))

    out = test_function_7(
        QuantityArray(r, 'm'),
        QuantityArray(theta, '°')
    )

    print("out unit:", out.raw()[1])
    # assert out.raw()[1] == 'cm'
    print("out:", r)
    print("cmp:", np.linalg.norm(out.raw()[0], axis=1))

    assert np.allclose(
        r,
        np.linalg.norm(out.raw()[0], axis=1)
    )


def test7():
    """
    Test test_function_8
    """
    lat = [
        74.21651895,   44.53245597, -38.85848749,  56.11115053, -33.83703324,
        -57.63849623,  -1.48738322, -57.77854783,   7.12722098,  82.0215663
    ]
    lon = [
        140.46154807, -142.72550789,  111.7582639,   -91.04689049,  93.35741144,
        30.74317758,  104.11022308,  110.41893138,   96.31073347,   85.27963591
    ]


    out = test_function_8(
        (
            np.stack((lat, lon), axis=1),
            ('°', '°'),
            ((6378137., 'm'), 1 / 298.257223563)
        )
    )

    # Computed with Python GeographicLib package:
    assert out.raw()[1] == 'm'
    d_ref_m = [
        5904943.614268792, 9436020.523296934, 13773210.116428928,
        6416625.159075531, 12168923.475459244, 11857124.956979157,
        10320443.245826146, 14793391.978291376, 9032806.015268983,
        4485353.364817245
    ]
    assert np.allclose(out.raw()[0], d_ref_m)

    print("succeeded Python test7")


def test8():
    """
    Test test_function_9 and test_function_10
    """
    lat = [
        74.21651895,   44.53245597, -38.85848749,  56.11115053, -33.83703324,
        -57.63849623,  -1.48738322, -57.77854783,   7.12722098,  82.0215663
    ]
    lon = [
        140.46154807, -142.72550789,  111.7582639,   -91.04689049,  93.35741144,
        30.74317758,  104.11022308,  110.41893138,   96.31073347,   85.27963591
    ]


    out = test_function_9(
        (
            np.stack((lat, lon), axis=1),
            ('°', '°'),
            ((6378137., 'm'), 1 / 298.257223563)
        ),
        "WGS84"
    )


    out1 = test_function_10(
        (
            np.stack((lat, lon), axis=1),
            ('°', '°'),
            ((6378137., 'm'), 1 / 298.257223563)
        )
    )

    # Mimic the algorithm implemented in test_function_10
    # in Python:
    hi = 782.
    h: list[float] = []
    for _ in range(len(lat)):
        h.append(hi)
        hi *= 1.73
        if hi > 1500.0:
            hi = hi % 500.0

    # Ensure the shapes are correct:
    assert out.shape == out1.shape == (len(lat),)
    assert out1.array.shape == out1.array.shape == (len(lat), 3)

    # Ensure correct types:
    assert isinstance(out, GeographicPointArray)
    assert isinstance(out1, GeographicPointArray)


    # Compare to C++ version:
    for o in (out, out1):
        print("o.raw():", o.raw())
        assert o.raw()[1] == ('°', '°', 'm')
        assert np.allclose(o.raw()[0][:,0], lat)
        assert np.allclose(o.raw()[0][:,1], lon)
        assert np.allclose(o.raw()[0][:,2], h)

    print("succeeded Python test8")


def test9():
    """
    Test test_function_11
    """
    lat = [
        74.21651895,   44.53245597, -38.85848749,  56.11115053, -33.83703324,
        -57.63849623,  -1.48738322, -57.77854783,   7.12722098,  82.0215663
    ]
    lon = [
        140.46154807, -142.72550789,  111.7582639,   -91.04689049,  93.35741144,
        30.74317758,  104.11022308,  110.41893138,   96.31073347,   85.27963591
    ]


    # test_function_11 expects geographic input in WGS84 ellipsoid.
    out1 = test_function_11(
        (
            np.stack((lat, lon), axis=1),
            ('°', '°'),
            "WGS84"
        )
    )

    # EPSG:7030 is the WGS84 ellipsoid:
    out2 = test_function_11(
        (
            np.stack((lat, lon), axis=1),
            ('°', '°'),
            "EPSG:7030"
        )
    )

    # Ensure that passing UserEllipsoid input raises:
    with pytest.raises(RuntimeError):
        test_function_11(
            (
                np.stack((lat, lon), axis=1),
                ('°', '°'),
                ((6378137., 'm'), 1 / 298.257223563)
            )
        )

    # Ensure that passing a Bessel ellipsoid input raises:
    with pytest.raises(RuntimeError):
        test_function_11(
            (
                np.stack((lat, lon), axis=1),
                ('°', '°'),
                "Bessel 1841"
            )
        )

    # Ensure the shapes are correct:
    assert out1.shape == out2.shape == (len(lat),)
    assert out1.array.shape == out2.array.shape == (len(lat), 2)
    assert out1.ellipsoid == "WGS84"
    assert out2.ellipsoid == "EPSG:7030"

    # Ensure correct types:
    assert isinstance(out1, GeographicPointArray)
    assert isinstance(out2, GeographicPointArray)


    # Compare to C++ version:
    for o in (out1, out2):
        print("o.raw():", o.raw())
        assert o.raw()[1] == ('°', '°')
        assert np.allclose(o.raw()[0][:,0], lat)
        assert np.allclose(o.raw()[0][:,1], lon)

    print("succeeded Python test9")


def test10():
    """
    Test test_function_12
    """
    lat = [
        74.21651895,   44.53245597, -38.85848749,  56.11115053, -33.83703324,
        -57.63849623,  -1.48738322, -57.77854783,   7.12722098,  82.0215663
    ]
    lon = [
        140.46154807, -142.72550789,  111.7582639,   -91.04689049,  93.35741144,
        30.74317758,  104.11022308,  110.41893138,   96.31073347,   85.27963591
    ]


    # test_function_12 expects geographic input in WGS84 ellipsoid.
    out1 = test_function_12(
        (
            np.stack((lat, lon), axis=1),
            ('°', '°'),
            "WGS84"
        )
    )

    # EPSG:7030 is the WGS84 ellipsoid:
    out2 = test_function_12(
        (
            np.stack((lat, lon), axis=1),
            ('°', '°'),
            "EPSG:7030"
        )
    )

    print("out1:", out1)
    print("out2:", out2)

    # Ensure correct types:
    assert isinstance(out1, GeographicPointArray)
    assert isinstance(out2, GeographicPointArray)

    # Ensure the shapes are correct:
    assert out1.shape == out2.shape == (len(lat),)
    assert out1.array.shape == out2.array.shape == (len(lat), 2)
    assert out1.ellipsoid == "WGS84"
    assert out2.ellipsoid == "WGS84"



    # Compare to C++ version:
    for o in (out1, out2):
        print("o.raw():", o.raw())
        assert o.raw()[1] == ('°', '°')
        assert np.allclose(o.raw()[0][:,0], lat)
        assert np.allclose(o.raw()[0][:,1], lon)

    print("succeeded Python test10")


def test11():
    """
    Test test_function_13.
    """
    test_function_13((1.0, "m"))
    y = test_function_13((100.0, "cm"))

    assert y.value == 0.25 and y.unit == "s"

    with pytest.raises(RuntimeError):
        test_function_13((.982, "cm"))


test0()
test1()
test2()
test3()
test4()
test5()
test6()
test7()
test8()
test9()
test10()
test11()