/*
 * Example header.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2025 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2025 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 */


#ifndef FUNKTIONSKLEMPNER_EXAMPLE_HPP
#define FUNKTIONSKLEMPNER_EXAMPLE_HPP

#include <cstddef>
#include <funktionsklempner/funktionsklempner.hpp>

namespace fk = funktionsklempner;

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
int test_function(
    fk::input<const char*> name,
    fk::input<size_t> i,
    fk::output<double> result
);


FUNKTIONSKLEMPNER_EXPORT_FUNCTION
int test_function_2(
    fk::output<const char*> result
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in_")
int test_function_3(
    fk::InputNDArray<double> in_,
    fk::OutputNDArray<double> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in_")
int test_function_4(
    fk::InputQuantityArray<boost::units::si::length, double> in_,
    fk::OutputQuantityArray<boost::units::si::energy, double> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in0_,in1_")
int test_function_5(
    fk::InputQuantityArray<boost::units::si::length, double> in0_,
    fk::InputQuantityArray<boost::units::si::mass, double> in1_,
    fk::OutputQuantityArray<boost::units::si::energy, double> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in_")
int test_function_6(
    fk::InputEuclideanPointArray<3, double> in_,
    fk::OutputQuantityArray<boost::units::si::length, double> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "r")
int test_function_7(
    fk::InputQuantityArray<boost::units::si::length, double> r,
    fk::InputQuantityArray<boost::units::si::plane_angle, double> theta,
    fk::OutputEuclideanPointArray<2, double> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in_")
int test_function_8(
    fk::InputGeographicPointArray<double, fk::geo::UserEllipsoid, false> in_,
    fk::OutputQuantityArray<boost::units::si::length, double> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in_")
FUNKTIONSKLEMPNER_ELLIPSOID_CONTROL("out", "out_ellipsoid")
int test_function_9(
    fk::InputGeographicPointArray<double, fk::geo::UserEllipsoid, false> in_,
    fk::OutputGeographicPointArray<double, fk::geo::UserEllipsoid, true> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in_")
FUNKTIONSKLEMPNER_ELLIPSOID_CONTROL("out", "in_")
int test_function_10(
    fk::InputGeographicPointArray<double, fk::geo::UserEllipsoid, false> in_,
    fk::OutputGeographicPointArray<double, fk::geo::UserEllipsoid, true> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in_")
FUNKTIONSKLEMPNER_ELLIPSOID_CONTROL("out", "in_")
int test_function_11(
    fk::InputGeographicPointArray<double, fk::geo::ellipsoids::WGS84, false> in_,
    fk::OutputGeographicPointArray<double, fk::geo::UserEllipsoid, false> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
FUNKTIONSKLEMPNER_SIZE_CONTROL("out", "in_")
int test_function_12(
    fk::InputGeographicPointArray<double, fk::geo::ellipsoids::WGS84, false> in_,
    fk::OutputGeographicPointArray<double, fk::geo::ellipsoids::WGS84, false> out
);

FUNKTIONSKLEMPNER_EXPORT_FUNCTION
int test_function_13(
    fk::InputQuantity<boost::units::si::length, double> x,
    fk::OutputQuantity<boost::units::si::time, double> y
);

#endif