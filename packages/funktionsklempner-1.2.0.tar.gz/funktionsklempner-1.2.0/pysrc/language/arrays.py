# Funktionsklempner array types.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2025-2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2025-2026 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>

from typing import Any, Literal, get_args, overload, Type
from .fundamental import FundamentalBaseType, CTypeBaseType
from .conversion import TYPE_MAP
from .abstract import Const


ArrayType = Type[
    "NDArray | QuantityArray | EuclideanPointArray | GeographicPointArray"
]


class NDArray:
    dtype: FundamentalBaseType | Const[FundamentalBaseType]
    size_control: "ArrayType | None"

    def __init__(self,
            dtype: FundamentalBaseType | Const[FundamentalBaseType]
        ):
        self.dtype = dtype
        self.size_control = None

    def __repr__(self):
        return "NDArray(" + self.dtype.__repr__() + ")"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, NDArray):
            return self.dtype == other.dtype # pyright: ignore
        return False

    def ctypes_type(self) -> CTypeBaseType:
        if isinstance(self.dtype, Const):
            return TYPE_MAP[self.dtype.val]
        return TYPE_MAP[self.dtype]



class QuantityArray:
    dtype: FundamentalBaseType | Const[FundamentalBaseType]
    boost_unit: str
    size_control: "ArrayType | None"

    def __init__(self,
            dtype: FundamentalBaseType | Const[FundamentalBaseType],
            boost_unit: str
        ):
        self.dtype = dtype
        self.boost_unit = boost_unit
        self.size_control = None

    def __repr__(self):
        return f"QuantityArray({self.dtype.__repr__()}, {self.boost_unit})"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, QuantityArray):
            return (
                self.dtype == other.dtype # pyright: ignore
                and self.boost_unit == other.boost_unit
            )
        return False

    def ctypes_type(self) -> CTypeBaseType:
        if isinstance(self.dtype, Const):
            return TYPE_MAP[self.dtype.val]
        return TYPE_MAP[self.dtype]



class EuclideanPointArray:
    dtype: FundamentalBaseType | Const[FundamentalBaseType]
    ndim: int
    size_control: "ArrayType | None"

    def __init__(self,
            dtype: FundamentalBaseType | Const[FundamentalBaseType],
            ndim: int
        ):
        self.dtype = dtype
        self.ndim = ndim

    def __repr__(self):
        return f"EuclideanPointArray({self.dtype.__repr__()}, {self.ndim})"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, EuclideanPointArray):
            return (
                self.dtype == other.dtype # pyright: ignore
                and self.ndim == other.ndim
            )
        return False

    def ctypes_type(self) -> CTypeBaseType:
        if isinstance(self.dtype, Const):
            return TYPE_MAP[self.dtype.val]
        return TYPE_MAP[self.dtype]


Ellipsoid = Literal[
    "UserEllipsoid", "WGS84", "EPSG:7030", "Bessel 1841", "EPSG:7004"
]

_ELLIPSOID_MAP: dict[str,Ellipsoid] = {
    s : s for s in get_args(Ellipsoid)
}

def parse_ellipsoid(input_: str, fk_namespace: str) -> Ellipsoid:
    err_msg = f"Unknown ellipsoid '{input_}'"
    if input_ == f"{fk_namespace}::geo::UserEllipsoid":
        return "UserEllipsoid"

    # Find the named static ellipsoids in namespace
    # funktionsklempner::geo::ellipsoids:
    prefix = f"{fk_namespace}::geo::ellipsoids::"
    if not input_.startswith(prefix):
        raise ValueError(err_msg)

    ellps = _ELLIPSOID_MAP.get(input_[len(prefix):])
    if ellps is not None:
        return ellps
    raise ValueError(
        f"Unknown ellipsoid '{input_}'"
    )


def ellipsoid_cpp_type(ellipsoid: Ellipsoid, fk_namespace: str) -> str:
    match ellipsoid:
        case "UserEllipsoid":
            return f"{fk_namespace}::geo::UserEllipsoid"
        case "WGS84" | "EPSG:7030":
            return f"{fk_namespace}::geo::ellipsoids::WGS84"
        case  "Bessel 1841" | "EPSG:7004":
            return f"{fk_namespace}::geo::ellipsoids::Bessel1841"

    raise ValueError(f"Invalid ellipsoid '{ellipsoid}'")


@overload
def is_static_ellipsoid(ellipsoid: Literal["UserEllipsoid"]) -> Literal[False]:
    pass

@overload
def is_static_ellipsoid(
        ellipsoid: Literal["WGS84", "EPSG:7030", "Bessel 1841", "EPSG:7004"]
    ) -> Literal[True]:
    pass

def is_static_ellipsoid(ellipsoid: Ellipsoid) -> bool:
    if ellipsoid == "UserEllipsoid":
        return False
    assert ellipsoid in _ELLIPSOID_MAP
    return True




class GeographicPointArray:
    dtype: FundamentalBaseType | Const[FundamentalBaseType]
    with_height: bool
    ellipsoid: Ellipsoid
    size_control: "ArrayType | None"

    def __init__(self,
            dtype: FundamentalBaseType | Const[FundamentalBaseType],
            with_height: bool,
            ellipsoid: Ellipsoid
        ):
        self.dtype = dtype
        self.with_height = with_height
        self.ellipsoid = ellipsoid

    def __repr__(self):
        return f"GeographicPointArray({self.dtype.__repr__()}, "\
            f"{"with_height" if self.with_height else "no_height"}, " \
            f"{self.ellipsoid})"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, GeographicPointArray):
            return (
                self.dtype == other.dtype # pyright: ignore
                and self.with_height == other.with_height
                and self.ellipsoid == other.ellipsoid
            )
        return False

    def ellipsoid_template_parameter(self, fk_namespace: str) -> str:
        """
        Get the correct value of the `ellispoid` template
        parameter.
        """
        match self.ellipsoid:
            case "UserEllipsoid":
                return f"{fk_namespace}::geo::UserEllipsoid"
            case "WGS84" | "EPSG:7030":
                return f"{fk_namespace}::geo::ellipsoids::WGS84"
            case "Bessel 1841" | "EPSG:7004":
                return f"{fk_namespace}::geo::ellipsoids::Bessel1841"

        raise ValueError(
            f"Unexpected ellipsoid parameter '{self.ellipsoid}'"
        )

    def ctypes_type(self) -> CTypeBaseType:
        if isinstance(self.dtype, Const):
            return TYPE_MAP[self.dtype.val]
        return TYPE_MAP[self.dtype]


ARRAY_CLASS_TYPE = (
    NDArray, QuantityArray, EuclideanPointArray, GeographicPointArray
)