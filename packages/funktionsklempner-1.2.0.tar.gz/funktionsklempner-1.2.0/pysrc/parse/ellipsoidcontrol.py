# Ellipsoid control: reference ellipsoid controlled by other geographic arrays.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2026 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>


class EllipsoidControl:
    """
    A class to define how ellipsoids are controlled.
    """
    _dep2control: dict[str, str]

    def __init__(self):
        self._dep2control = {}


    def __contains__(self, controlled: str) -> bool:
        return controlled in self._dep2control


    def controlled(self) -> set[str]:
        return set(self._dep2control.keys())


    def controllers(self) -> set[str]:
        return set(self._dep2control.values())


    def set_control(self,
            controlled: str,
            controller: str
        ):
        if controlled in self._dep2control:
            raise RuntimeError(
                f"Providing two ellipsoid controls for array {controlled}"
            )
        self._dep2control[controlled] = controller


    def get_control(self, controlled: str) -> str:
        res = self._dep2control.get(controlled)
        if res is None:
            raise RuntimeError(
                "No ellipsoid control has been defined for output geographic array "
                f"'{controlled}'"
            )
        return res