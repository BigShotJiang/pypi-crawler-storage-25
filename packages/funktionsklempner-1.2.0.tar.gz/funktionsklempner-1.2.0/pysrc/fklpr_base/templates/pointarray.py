# Arrays of points
#
# Authors: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (c) 2026 Technical University of Munich
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#
#    1. Redistributions of source code must retain the above copyright notice, this
#       list of conditions and the following disclaimer.
#    2. Redistributions in binary form must reproduce the above copyright notice,
#       this list of conditions and the following disclaimer in the documentation
#       and/or other materials provided with the distribution.
#    3. Neither the name of the copyright holder nor the names of its contributors
#       may be used to endorse or promote products derived from this software
#       without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
# OF THE POSSIBILITY OF SUCH DAMAGE.
#
# SPDX-FileCopyrightText: 2026 Technical University of Munich
# SPDX-License-Identifier: BSD-3-Clause

import numpy as np
from typing import Sequence, Literal, get_args
from itertools import repeat

class EuclideanPointArray:
    """
    A NumPy array with a physical unit representing an array of
    Euclidean points.
    """
    array: np.ndarray
    unit: tuple[str, ...]

    def __init__(self,
            array: np.ndarray,
            unit: str | tuple[str, ...]
        ):
        self.array = np.asarray(array)
        ndim: int = self.array.shape[-1]
        if isinstance(unit, tuple):
            # If a tuple is given, it has to coincide with
            # the point dimension (i.e. the last dimension of
            # the array):
            assert len(unit) == ndim

        else:
            # If it's a single string, create a corresponding
            # tuple:
            unit = tuple(repeat(unit, ndim))

        self.unit = unit


    def raw(self) -> tuple[np.ndarray, tuple[str, ...]]:
        """
        Returns this Euclidean point vector as a tuple of is numerical
        values and its unit.
        """
        return self.array, self.unit


    def __repr__(self) -> str:
        return f"EuclideanPointArray(shape={self.array.shape[:-1]}, " \
            f"ndim={self.array.shape[-1]})"

    @property
    def shape(self) -> tuple[int, ...]:
        return self.array.shape[:-1]


# Typing for coordinate arrays:
EllipsoidIdentifier = Literal['WGS84', 'EPSG:7030', 'Bessel 1841', 'EPSG:7004']
_ELLIPSOIDS = set(get_args(EllipsoidIdentifier))
Ellipsoid = tuple[tuple[float,str], float] | EllipsoidIdentifier

_CoordinateArray2D = np.ndarray | Sequence[tuple[float,float]]
_CoordinateArray3D = np.ndarray | Sequence[tuple[float,float,float]]
GeographicPoints = tuple[_CoordinateArray2D, tuple[str, str], Ellipsoid] \
    | tuple[_CoordinateArray3D, tuple[str, str, str], Ellipsoid]



class GeographicPointArray:
    """
    A NumPy array with physical unit(s) representing an array of
    Geographic points.
    """
    array: np.ndarray
    unit: tuple[str, str] | tuple[str, str, str]
    ellipsoid: Ellipsoid

    def __init__(self,
            array_unit_ellipsoid: GeographicPoints
                | tuple[np.ndarray, str, Ellipsoid]
        ):
        assert len(array_unit_ellipsoid) == 3
        array, unit, ellipsoid = array_unit_ellipsoid
        self.array = np.asarray(array, order='C')
        ndim: int = self.array.shape[-1]

        # Validate the dimension of the array:
        if ndim not in (2,3):
            raise ValueError(
                "The last axis numeric array underlying a "
                "GeographicPointArray has to be two- or three-dimensional."
            )

        if isinstance(unit, tuple):
            # If a tuple is given, it has to coincide with
            # the point dimension (i.e. the last dimension of
            # the array):
            assert len(unit) == ndim

        else:
            # If it's a single string, it has to be geographic without height
            # (otherwise we would need both an angle and a length unit).
            if ndim != 2:
                raise RuntimeError(
                    "Passing a single unit as string works only for geographic "
                    "coordinates without height. Otherwise, you need to pass "
                    "a height unit as well. Use a unit tuple "
                    "`(u_lat, u_lon, u_height)` to specify units for geographic "
                    "coordinates with height."
                )

            # Create a corresponding tuple.
            unit = (unit, unit)

        self.unit = unit

        # Validate Ellipsoid:
        if isinstance(ellipsoid, str):
            assert ellipsoid in _ELLIPSOIDS
        else:
            assert isinstance(ellipsoid, tuple) and len(ellipsoid) == 2
            a, f = ellipsoid
            a_num_s, a_unit_s = a
            a_num = float(a_num_s)
            a_unit = str(a_unit_s)
            f = float(f)
            # Make sure the numbers are a proper ellipsoid:
            assert a_num > 0
            assert 0 <= f < 1
            ellipsoid = ((a_num, a_unit), f)

        self.ellipsoid = ellipsoid



    def raw(self) -> tuple[
            np.ndarray, tuple[str,str] | tuple[str, str, str], Ellipsoid
        ]:
        """
        Returns this Euclidean point vector as a tuple of is numerical
        values and its unit.
        """
        # This if-clause exists solely to allow the type checker to
        # deduce that the return type is, indeed, correct.
        if len(self.unit) == 2:
            return (self.array, self.unit, self.ellipsoid)
        return (self.array, self.unit, self.ellipsoid)


    def __repr__(self) -> str:
        return f"GeographicPointArray(shape={self.array.shape[:-1]}, " \
            f"height={"True" if self.array.shape[-1] == 3 else "False"}, " \
            f"ellipsoid={self.ellipsoid})"


    @property
    def shape(self) -> tuple[int, ...]:
        return self.array.shape[:-1]



def to_geographic_point_array(
        args: GeographicPoints | GeographicPointArray
    ) -> GeographicPointArray:
    """
    Convert geographic point arguments to a GeographicPointArray.
    """
    if isinstance(args, GeographicPointArray):
        return args

    return GeographicPointArray(args)
