# Wrapping quantities.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2026 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>

from ..language.abstract import Input, Const, Output
from ..language.quantity import Quantity
from ..language.strings import cpp_type_string
from ..language.conversion import equivalent_ctypes_type
from .variablegraph import VariableGraph, VariableGraphNode
from .parameter import CTypeParameterByValue, PythonInputParameter, \
    CppParameter, CTypeParameterByRef, PythonOutputParameter
from .string import OutputStringBuilder


def generate_unit_tuple_parameters(
        root_name: str,
        root: VariableGraphNode,
        unit_string_access_expressions: tuple[str, ...],
        vargraph: VariableGraph
    ) -> tuple[VariableGraphNode, list[str]]:
    """
    Generate the ctypes parameters required to pipe the string elements
    of a Python (unit) tuple to a C++ tuple of `const char*`.

    Parameters
    ----------
    root_name:
        Name of the root variable (e.g. a EuclideanInputRange)
        from which the names shall be derived.
    root:
        Node of the variable graph corresponding to the root variable.
    unit_string_access_expressions:
        Tuple of (Python) code expressions that return the unit
        strings.


    Returns
    -------
    last_node:
        Last node added to the variable graph. If anything was inserted,
        this corresponds to the last element of `cpp_variables`.
    variable_names:
        Names of all variable graph nodes added to the graph, corresponding to
        the string variables in order passed in `unit_string_access_expressions`.
    """
    last_node = root
    variable_names: list[str] = []
    for i,access in enumerate(unit_string_access_expressions):
        # Generate a CTypeInputParameter:
        charp_name = vargraph.get_temporary_name(root_name, f"char_p__unit_{i}__")
        variable_names.append(charp_name)
        c_in = CTypeParameterByValue(
            charp_name,
            Const("c_char_p"),
            [
                f"    {charp_name} = c_char_p({access}.encode('utf-8'))"
            ]
        )
        last_node = vargraph.insert(c_in, last_node)

    return last_node, variable_names



def wrap_input_quantity(
        name: str,
        parameter_type: Input[Quantity],
        vargraph: VariableGraph,
        fk_namespace: str,
        cpp_argument_id: int
    ):
    py = PythonInputParameter(
        name,
        parameter_type,
        [
            f"    if not isinstance({name}, Quantity):",
            f"        assert isinstance({name}, tuple) and len({name}) == 2",
            f"        {name} = Quantity(*{name})"
        ]
    )
    last_node = vargraph.insert(py)

    # Unpack the parameter type:
    quantity_type = parameter_type.val
    bu = quantity_type.boost_unit
    dtype = quantity_type.dtype

    # The numerical value:
    c_in_name = vargraph.get_temporary_name(name, prefix='val_')
    ctype_base_type = equivalent_ctypes_type(dtype)
    c_in = CTypeParameterByValue(
        c_in_name,
        ctype_base_type,
        [
            f"    {c_in_name} = {ctype_base_type}(float({name}.value))"
        ]
    )
    last_node = vargraph.insert(c_in, last_node)


    # The unit tuple parameter
    # ========================
    last_node, unit_cpp_variables = generate_unit_tuple_parameters(
        name,
        last_node,
        (f"{name}.unit",),
        vargraph
    )

    # Get the initializer code to initialize fk::wrapper::Quantity
    # from the rvalue expression (for the NDArray) and the lvalue one for
    # the unit string:
    cpp_type_str = cpp_type_string(dtype, fk_namespace)
    init_code = [
         "            "
        f"auto {name} = "
        f"{fk_namespace}::parse_input_quantity<{bu}, {cpp_type_str}>(\n"
         "            "
        f"    {c_in_name},\n"
         "            "
        f"    {unit_cpp_variables[0]}\n"
         "            "
         ");\n"
    ]

    # Assemble the Quantity input parameter to the wrapped
    # C++ function:
    cpp_name = vargraph.get_temporary_name(name, prefix='c++_')
    cpp = CppParameter(
        cpp_name,
        parameter_type,
        init_code,
        None,
        name,
        cpp_argument_id
    )
    vgn_last = vargraph.insert(cpp, last_node)
    return vgn_last



def wrap_output_quantity(
        name: str,
        parameter_type: Output[Quantity],
        vargraph: VariableGraph,
        fk_namespace: str,
        cpp_argument_id: int
    ) -> VariableGraphNode:

    # Get temporary variables
    #  - to generate the QuantityArray's ndarray,
    #  - to obtain the QuantityArray's unit.
    value_type = parameter_type.val.dtype
    value_name = vargraph.get_temporary_name(name, "val_")
    value_tmp_name = vargraph.get_temporary_name(name, "val_tmp_")
    unit_name = vargraph.get_temporary_name(name, "unit_")
    cpp_name = vargraph.get_temporary_name(name, prefix='c++_')

    if isinstance(value_type, Const):
        raise TypeError(
            f"The value type of the output quantity '{name}' is Const -- which "
            "it shall not be."
        )

    # Create a temporary real value:
    value_ctype = equivalent_ctypes_type(value_type)
    c_val = CTypeParameterByRef(
        value_name,
        value_ctype,
        [
            f"    {value_name} = {value_ctype}(0)"
        ]
    )
    vgn_last = vargraph.insert(c_val)


    # Output string:
    osb = OutputStringBuilder(unit_name, vargraph, vgn_last, 0)
    _, vgn_str = osb.create_ctypes()
    post_call = osb.ctypes_post_call_code()
    unit_id_name = osb.id_name


    # After we have read the string, we need to assemble the final
    # Quantity:
    post_call.append(
        f"    {name} = Quantity({value_name}.value, {unit_name})"
    )

    # Finally (Python side): generate the QuantityArray.
    # This happens purely post-call.
    py_qty = PythonOutputParameter(
        name,
        parameter_type,
        [],
        post_call
    )
    vgn_last = vargraph.insert(py_qty, vgn_str)

    # Finally (C++ side):
    bu = parameter_type.val.boost_unit
    post_call_code = [
        f"*{unit_id_name} = "
        f"{fk_namespace}::create_string("
        f"{fk_namespace}::default_unit<{bu}>"
            ")",
        f"*{value_name} = {value_tmp_name}.value()"
    ]
    init_code = [
            "            "
        f"if ({unit_id_name} == nullptr)\n",
            "            "
        f"    throw std::runtime_error(\n"
            "            "
        f"        \"Internal error: output quantity '{name}' \"\n"
            "            "
        f"        \"has been passed a nullptr as output size parameter.\"\n"
            "            "
            "    );\n"
    ]
    cpp_type_str = cpp_type_string(value_type, fk_namespace)
    init_code.append(
         "            "
        f"boost::units::quantity<{bu}, {cpp_type_str}> {value_tmp_name};\n"
    )
    init_code.append(
         "            "
        f"{fk_namespace}::OutputQuantity<{bu}, {cpp_type_str}> {name} = "
        f"&{value_tmp_name};\n"
    )

    cpp = CppParameter(
        cpp_name,
        parameter_type,
        init_code,
        post_call_code,
        name,
        cpp_argument_id
    )
    vgn_last = vargraph.insert(cpp, vgn_str)

    return vgn_last