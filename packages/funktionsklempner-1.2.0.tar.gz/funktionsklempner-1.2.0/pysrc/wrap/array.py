# Wrapping NumPy arrays and QuantityArrays.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2026 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>





from typing import Callable, Literal
from warnings import warn
from ..language.abstract import Pointer, Output, Input, Temporary, Const
from .parameter import CTypeParameterByValue, PythonInputParameter, \
    PythonOutputParameter, TemporaryPythonVariable, CppParameter
from .quantity import generate_unit_tuple_parameters
from ..language.arrays import NDArray, QuantityArray, EuclideanPointArray,\
    GeographicPointArray, ARRAY_CLASS_TYPE, Ellipsoid, ellipsoid_cpp_type, \
    is_static_ellipsoid
from ..language.conversion import NUMPY_DTYPE_MAP
from ..language.strings import cpp_type_string
from ..language.python import CTypeType, CTypeBaseType
from .variablegraph import VariableGraph, VariableGraphNode
from .string import OutputStringBuilder
from ..parse.sizecontrol import SizeControl
from ..parse.ellipsoidcontrol import EllipsoidControl
from ..tools.views import append


#
# 1. NumPy ndarray
# ================
#
# Wrap a `funktionsklempner::ndarray::NDArray` into a NumPy ndarray.
# This consists of two main functions:
#
#   - `wrap_output_ndarray`, to create an output `ndarray`
#   - `wrap_input_ndarray`, to create an `ndarray` input parameter
#
# The following helpers are used:
#
#   - `_InitParams`: an argument struct for assembling the init code
#     of an `ndarray` parameter.
#   - `_wrap_ndarray`: the workhorse function for assembling all
#     Python, ctypes, and intermediary parameters, and inserting them
#     in right order into the variable graph.

class _InitParams:
    name: str
    np_dtype: str
    shape: str

    def __init__(self, name: str, np_dtype: str, shape: str):
        self.name = name
        self.np_dtype = np_dtype
        self.shape = shape

class NewArrayInitializer:
    """
    Helper class for obtaining the shape of an array.
    """
    sc_name: tuple[str, ...]
    vargraph: VariableGraph
    data_ndim: int | None

    def __init__(self,
            controlled: str,
            size_control: SizeControl,
            vargraph: VariableGraph,
            data_ndim: int | None = None
        ):
        self.sc_name = size_control.get_control(controlled)
        self.vargraph = vargraph
        self.data_ndim = data_ndim


    def shape(self) -> tuple[str, tuple[VariableGraphNode, ...]] | None:
        sc_vgn: list[VariableGraphNode] = []
        get_shape: list[str] = []
        for sc_name in self.sc_name:
            if sc_name not in self.vargraph:
                # Size control shall be a new variable.
                size_control = PythonInputParameter(
                    sc_name, Input("int"),
                    [
                        f"    {sc_name} = int({sc_name})"
                    ]
                )
                sc_vgn.append(self.vargraph.insert(size_control))
                get_shape.append(sc_name)
                warn(
                    f"Created a new size parameter '{sc_name}', which was given "
                    "as an argument to the FUNKTIONSKLEMPNER_SIZE_CONTROL macro, "
                    "because no parameter of this name was found in the "
                    "argument list."
                )
            else:
                # The size control is an existing parameter.
                # It has to be an array parameter!
                sc_vgn.append(self.vargraph.get_node(sc_name))
                size_control = sc_vgn[-1].parameter
                if not isinstance(size_control, PythonInputParameter):
                    raise RuntimeError(
                        f"Size control parameter '{sc_name}' has to be a "
                        "Python input parameter."
                    )
                size_control_type = size_control.dtype.val
                if not isinstance(size_control_type, ARRAY_CLASS_TYPE):
                    raise RuntimeError(
                        f"Size control parameter '{sc_name}' has to be a "
                        "NDArray, QuantityArray, EuclideanPointArray, "
                        "or GeographicPointArray instance."
                    )

                # Note here why the following simple line works to obtain
                # the correct shape of these data types:
                #  - NumPy ndarrays and QuantityArrays represent scalar data.
                #    Hence their `shape` attribute retrieves the expected size.
                #  - EuclideanPointArray and GeographicPointArray represent
                #    multidimensional data. Their internal ndarray has a shape
                #    `(*S, d)`, where `d` is the dimension of the points and
                #    `S=(s0, ..., sn)` is the shape of the array that we would
                #    like to obtain (since on the C++ side, this determines the
                #    size of the flat point range).
                #    The shape atttributes of EuclideanPointArray and
                #    GeographicPointArray adhere to this idea of array size and
                #    data dimension by returning only `S` in their `shape`
                #    attributes---exactly what we need.
                get_shape.append(f"*{sc_name}.shape")

        # Finally, we might have vector data (e.g. EuclideanPointArray),
        # where the size control should control the number of data
        # entries---not the dimensionality of the data.
        # Hence, add the data dimension here:
        if self.data_ndim:
            get_shape.append(str(self.data_ndim))


        return f"({"".join(append(get_shape, ","))})", tuple(sc_vgn)



class ForwardInitializer:
    def shape(self) -> None:
        return None


def empty_init_code(ip: _InitParams) -> list[str]:
    return [
        f"    {ip.name} = np.empty({ip.shape}, {ip.np_dtype}, 'C')"
    ]

def forward_init_code(ip: _InitParams) -> list[str]:
    return [
        f"    {ip.name} = np.asarray({ip.name}, {ip.np_dtype}, 'C')"
    ]


#
# Different ways to pass NumPy arrays to the C++ side
#
def _ndarray_ctypes_buffer_and_size(
        ndarray_name: str,
        buffer_name: str,
        buffer_ptr: Pointer[CTypeType],
        buffer_ctype: CTypeBaseType,
        size_name: str | None,
        vargraph: VariableGraph,
        root: VariableGraphNode
    ) -> tuple[
        tuple[CTypeParameterByValue, VariableGraphNode],
        tuple[CTypeParameterByValue, VariableGraphNode]
    ]:
    """
    Generate the ctypes parameters to transfer buffer pointer
    and buffer size of an existing NDArray Python variable
    to the C++ size.

    Returns
    -------
    buffer_parameter:
        A tuple `(c_buffer, vgn_c_buffer)` of a ctypes parameter
        and a variable graph node corresponding to passing the
        _buffer pointer_.
    size_parameter:
        A tuple `(c_buffer, vgn_c_buffer)` of a ctypes parameter
        and a variable graph node corresponding to passing the
        _buffer size_.
    """
    # The buffer ctypes parameter
    # ---------------------------
    c_buffer = CTypeParameterByValue(
        buffer_name,
        buffer_ptr,
        [
            f"    {buffer_name} = {ndarray_name}.ctypes.data_as(POINTER({buffer_ctype}))",
        ]
    )
    vgn_c_buffer = vargraph.insert(c_buffer, root)
    buffer_parameter = (c_buffer, vgn_c_buffer)


    # The buffer size ctypes parameter
    # --------------------------------
    if size_name is None:
        size_name = vargraph.get_temporary_name(ndarray_name, prefix='size_')
    c_size = CTypeParameterByValue(
        size_name,
        "c_size_t",
        [
            f"    {size_name} = c_size_t({ndarray_name}.size)"
        ]
    )
    vgn_size = vargraph.insert(c_size, vgn_c_buffer)
    size_parameter = (c_size, vgn_size)

    return buffer_parameter, size_parameter


def ndarray_attribute_input_to_rvalue(
        main_parameter_name: str,
        python_ndarray_access: str,
        parameter_type: Input[NDArray],
        vargraph: VariableGraph,
        root: VariableGraphNode,
        fk_namespace: str,
    ) -> tuple[str, VariableGraphNode, VariableGraphNode]:
    """
    This passes a NumPy array attribute from the Python side to
    an rvalue expression in the C++ side.
    """
    # Intermediary variable names:
    ndarray_name = vargraph.get_temporary_name(main_parameter_name, 'ndarray_')
    buffer_name = vargraph.get_temporary_name(main_parameter_name, 'buf_')
    size_name = vargraph.get_temporary_name(main_parameter_name, 'size_')

    # Variable types:
    array_type = parameter_type.val
    buffer_ctype = array_type.ctypes_type()
    buffer_ptr: Pointer[CTypeType] = Pointer(Const(buffer_ctype))
    np_dtype = NUMPY_DTYPE_MAP[buffer_ctype]

    # The temporary Python parameter to access the NDArray:
    py = TemporaryPythonVariable(
        ndarray_name,
        parameter_type.val,
        [
            f"    {ndarray_name} = np.asarray({python_ndarray_access}, {np_dtype}, 'C')"
        ]
    )
    vgn_py = vargraph.insert(py, root)

    # The ctypes parameters to pass buffer pointer and buffer size
    # to the C++ side:
    buffer_parameter, size_parameter = _ndarray_ctypes_buffer_and_size(
        ndarray_name,
        buffer_name,
        buffer_ptr,
        buffer_ctype,
        size_name,
        vargraph,
        vgn_py
    )

    vgn_buf = buffer_parameter[1]
    vgn_size = size_parameter[1]

    # The rvalue expression to access the NDArray as a C++
    # parameter:
    cpp_type = cpp_type_string(array_type.dtype, fk_namespace)
    rvalue_expr = f"{fk_namespace}::InputNDArray<{cpp_type}>("\
        f"{buffer_name}, {size_name}, \"{cpp_type}\"" \
    ")"

    return rvalue_expr, vgn_buf, vgn_size




def ndarray_attribute_output(
        main_parameter_name: str,
        parameter_type: Temporary[NDArray],
        size_control_dict: SizeControl,
        vargraph: VariableGraph,
        fk_namespace: str,
        data_ndim: int | None
    ) -> tuple[str, VariableGraphNode, str]:
    """
    This passes a NumPy array attribute from the Python side to
    an rvalue expression in the C++ side.
    """
    # Intermediary variable names:
    ndarray_name = vargraph.get_temporary_name(main_parameter_name, 'ndarray_')
    buffer_name = vargraph.get_temporary_name(main_parameter_name, 'buf_')
    size_name = vargraph.get_temporary_name(main_parameter_name, 'size_')

    # Set the size control for the NDArray to the same controller
    # as the quantity array:
    size_control_dict.set_control(
        ndarray_name,
        size_control_dict.get_control(main_parameter_name)
    )

    # The new array initializer:
    initializer = NewArrayInitializer(
        main_parameter_name,
        size_control_dict,
        vargraph,
        data_ndim
    )

    # Variable types:
    array_type = parameter_type.val
    buffer_ctype = array_type.ctypes_type()
    buffer_ptr: Pointer[CTypeType] = Pointer(buffer_ctype)
    np_dtype = NUMPY_DTYPE_MAP[buffer_ctype]
    cpp_type = cpp_type_string(array_type.dtype, fk_namespace)

    # Array shape:
    shape_node = initializer.shape()
    assert shape_node is not None
    shape, sc_vgn = shape_node

    # The temporary Python parameter to access the NDArray:
    py = TemporaryPythonVariable(
        ndarray_name,
        parameter_type.val,
        [
            f"    {ndarray_name} = np.empty({shape}, {np_dtype}, 'C')"
        ]
    )
    vgn_py = vargraph.insert(py, *sc_vgn)


    # 3. The buffer ctypes parameter
    c_buffer = CTypeParameterByValue(
        buffer_name,
        buffer_ptr,
        [
            f"    {buffer_name} = {ndarray_name}.ctypes.data_as(POINTER({buffer_ctype}))",
        ]
    )
    vgn_c_buffer = vargraph.insert(c_buffer, vgn_py)


    # 4. The buffer size ctypes parameter
    c_size = CTypeParameterByValue(
        size_name,
        "c_size_t",
        [
            f"    {size_name} = c_size_t({ndarray_name}.size)"
        ]
    )
    vgn_last = vargraph.insert(c_size, vgn_c_buffer)

    # 5. The rvalue expression composing the NDArray:
    ndarray_rvalue = (
        f"{fk_namespace}::OutputNDArray<{cpp_type}>({buffer_name}, "
        f"{size_name}, \"{cpp_type}\")"
    )

    return ndarray_rvalue, vgn_last, ndarray_name





class NDArrayWrapper:
    """
    Helper class for wrapping an NDArray.
    """
    name: str
    buffer_name: str

    python_parameter: tuple[
        PythonInputParameter |PythonOutputParameter | TemporaryPythonVariable,
        VariableGraphNode
    ]
    buffer_parameter: tuple[CTypeParameterByValue, VariableGraphNode]
    size_parameter: tuple[CTypeParameterByValue, VariableGraphNode]
    cpp_parameter: tuple[CppParameter, VariableGraphNode] | None

    def __init__(
            self,
            name: str,
            parameter_type: Output[NDArray] | Input[NDArray] | Temporary[NDArray],
            vargraph: VariableGraph,
            initializer: NewArrayInitializer | ForwardInitializer,
            get_init_code: Callable[[_InitParams], list[str]],
            fk_namespace: str,
            cpp_argument_id: int | None,
            size_name: str | None = None
        ):
        self.name = name
        # 0. Get the buffer type:
        array_type = parameter_type.val
        self.buffer_name = vargraph.get_temporary_name(name, 'buf_')
        buffer_ctype = array_type.ctypes_type()
        np_dtype = NUMPY_DTYPE_MAP[buffer_ctype]

        # 1. Get the shape of the array.
        shape_node = initializer.shape()
        if shape_node is None:
            # No shape (output parameter.)
            shape = ""
            sc_vgn = tuple()
        else:
            shape, sc_vgn = shape_node

        # 2. The Python output parameter
        init_code: list[str] = get_init_code(
            _InitParams(name=name, np_dtype=np_dtype, shape=shape)
        )
        buffer_ptr: Pointer[CTypeType]
        if isinstance(parameter_type, Output):
            py = PythonOutputParameter(
                name, parameter_type, init_code, None
            )

            # Output parameters need to be initialized:
            assert shape != ""
            assert len(sc_vgn) > 0

            # Buffer type:
            buffer_ptr = Pointer(buffer_ctype)

        elif isinstance(parameter_type, Input):
            py = PythonInputParameter(
                name, parameter_type, init_code
            )

            # Input parameters shall not be initialized:
            assert shape == ""
            assert len(sc_vgn) == 0

            # Buffer type:
            buffer_ptr = Pointer(Const(buffer_ctype))

        else:
            py = TemporaryPythonVariable(
                name, parameter_type.val, init_code
            )

            # Buffer type:
            buffer_ptr = Pointer(buffer_ctype)

        vgn_py = vargraph.insert(py, *sc_vgn)
        self.python_parameter = (py, vgn_py)

        # 3. The buffer ctypes parameter
        # Now that we know the name, create the initialization.
        # First assert that we have a numpy array of correct data type
        # given as input:
        init_code = [
            f"    {self.buffer_name} = {name}.ctypes.data_as(POINTER({buffer_ctype}))",
        ]
        c_buffer = CTypeParameterByValue(
            self.buffer_name,
            buffer_ptr,
            init_code
        )
        vgn_c_buffer = vargraph.insert(c_buffer, vgn_py)
        self.buffer_parameter = (c_buffer, vgn_c_buffer)


        # 4. The buffer size ctypes parameter
        if size_name is None:
            size_name = vargraph.get_temporary_name(name, prefix='size_')
        init_code = [
            f"    {size_name} = c_size_t({name}.size)"
        ]
        c_size = CTypeParameterByValue(
            size_name,
            "c_size_t",
            init_code
        )
        vgn_last = vargraph.insert(c_size, vgn_c_buffer)
        self.size_parameter = (c_size, vgn_last)


        # 5. The C++ parameter that collects the two ctypes arguments:
        if not isinstance(parameter_type, Temporary):
            assert cpp_argument_id is not None
            cpp_name = vargraph.get_temporary_name(name, prefix='c++_')
            cpp_type = cpp_type_string(array_type.dtype, fk_namespace)
            if isinstance(parameter_type, Input):
                ndtype = "InputNDArray"
            else:
                ndtype = "OutputNDArray"
            init_code = [
                "            "
                f"auto {name} = {fk_namespace}::{ndtype}<{cpp_type}>(\n"
                "            "
                f"    {self.buffer_name},\n"
                "            "
                f"    {size_name},\n"
                "            "
                f"    \"{cpp_type}\"\n"
                "            "
                ");\n"
            ]
            cpp = CppParameter(
                cpp_name,
                parameter_type,
                init_code,
                None,
                name,
                cpp_argument_id
            )
            vgn_last = vargraph.insert(cpp, vgn_last)
            self.cpp_parameter = (cpp, vgn_last)

        else:
            self.cpp_parameter = None


    def last_variable_graph_node(self) -> VariableGraphNode:
        if self.cpp_parameter is None:
            return self.size_parameter[1]
        return self.cpp_parameter[1]






def wrap_output_ndarray(
        name: str,
        parameter_type: Output[NDArray],
        vargraph: VariableGraph,
        size_control_dict: SizeControl,
        fk_namespace: str,
        cpp_argument_id: int,
        size_name: str | None = None
    ) -> VariableGraphNode:

    # 2. The Python output parameter
    array = NDArrayWrapper(
        name,
        parameter_type,
        vargraph,
        NewArrayInitializer(name, size_control_dict, vargraph),
        empty_init_code,
        fk_namespace,
        cpp_argument_id,
        size_name=size_name
    )
    assert array.cpp_parameter is not None
    return array.cpp_parameter[1]




def wrap_input_ndarray(
        name: str,
        parameter_type: Input[NDArray],
        vargraph: VariableGraph,
        fk_namespace: str,
        cpp_argument_id: int
    ):
    """
    Wraps a Python input NDArray.
    """
    # Heavy lifting in the backend:
    NDArrayWrapper(
        name,
        parameter_type,
        vargraph,
        ForwardInitializer(),
        forward_init_code,
        fk_namespace,
        cpp_argument_id
    )




#
# 2. QuantityArray
# ================
#
# Here we do the same for the `QuantityArray` class.
# We use the facility for wrapping the ndarray and augment
# it by passing the unit string.


def wrap_input_quantityarray(
        name: str,
        parameter_type: Input[QuantityArray],
        vargraph: VariableGraph,
        fk_namespace: str,
        cpp_argument_id: int
    ):
    """
    Generate the code and variable graph nodes to wrap a QuantityArray
    parameter from Python to C++ input parameter.

    Parameters
    ----------
    name:
        Name of the Python QuantityArray variable
    parameter_type:
        Type of the input variable (specifies the dimension and buffer data
        type of the quantity array)
    vargraph:
        Variable graph of the wrapped function
    fk_namespace:
        Namespace (alias of) `funktionsklempner`
    cpp_argument_id:
        ID of the C++ argument in the wrapped function.

    Returns
    -------
    vgn_last:
        The last node added to the variable graph.
    """
    py = PythonInputParameter(
        name,
        parameter_type,
        [
            f"    assert isinstance({name}, QuantityArray)"
        ]
    )
    vgn_qa = vargraph.insert(py)


    # Input NDArrays have a datatype `const T`, where `T` is the
    # fundamental type. Drop the `const` here since we will
    # get `const` again from the InputNDArray:
    array_type = parameter_type.val
    bu = array_type.boost_unit
    dtype = array_type.dtype
    if not isinstance(dtype, Const):
        raise TypeError(
            "Data type of input array is not Const[T] (as it shall be)."
        )
    dtype = dtype.val


    # 2. Pipe the NDArray from Python to C++
    # ======================================
    #
    # Now pipe the NDArray from a Python variable's attribute
    # (QuantityArray.array) to an rvalue funktionsklempner::ndarray::NDArray
    # in the C++ world:
    nd_type = NDArray(dtype)

    ndarray_rvalue, _, vgn_size = ndarray_attribute_input_to_rvalue(
        name,
        f"{name}.array",
        Input(nd_type),
        vargraph,
        vgn_qa,
        fk_namespace
    )


    # 2) Create the unit tuple parameter
    # ==================================
    last_node, unit_cpp_variables = generate_unit_tuple_parameters(
        name,
        vgn_size,
        (f"{name}.unit",),
        vargraph
    )


    # Get the initializer code to initialize fk::wrapper::QuantityArray
    # from the rvalue expression (for the NDArray) and the lvalue one for
    # the unit string:
    cpp_type_str = cpp_type_string(dtype, fk_namespace)
    unit_initializer = (
        f"\n                {unit_cpp_variables[0]}\n"
    )
    init_code = [
         "            "
        f"{fk_namespace}::InputQuantityArray<{bu}, {cpp_type_str}> {name}(\n"
         "            "
        f"    {ndarray_rvalue},"
        f"{unit_initializer}"
         "            "
         ");\n"
    ]

    # Assemble the QuantityArray input parameter to the wrapped
    # C++ function:
    cpp_name = vargraph.get_temporary_name(name, prefix='c++_')
    cpp = CppParameter(
        cpp_name,
        parameter_type,
        init_code,
        None,
        name,
        cpp_argument_id
    )
    vgn_last = vargraph.insert(cpp, last_node)
    return vgn_last








def wrap_output_quantityarray(
        name: str,
        parameter_type: Output[QuantityArray],
        vargraph: VariableGraph,
        size_control_dict: SizeControl,
        fk_namespace: str,
        cpp_argument_id: int
    ) -> VariableGraphNode:
    """
    Generate the code and variable graph nodes to generate an output
    QuantityArray in Python and pipe it to the corresponding C++
    output parameter.

    Parameters
    ----------
    name:
        Name of the Python QuantityArray return variable
    parameter_type:
        Type of the output variable (specifies unit, data type, and
        size control---i.e. how do we determine the size of the newly
        generated buffer?)
    vargraph:
        Variable graph of the wrapped function
    size_control_dict:
        The dictionary of size controls. Needs to contain a size control
        for the parent variable `name`.
    fk_namespace:
        Namespace (alias of) `funktionsklempner`
    cpp_argument_id:
        ID of the C++ argument in the wrapped function.

    Returns
    -------
    vgn_last:
        The last node added to the variable graph.
    """
    # Get temporary variables
    #  - to generate the QuantityArray's ndarray,
    #  - to obtain the QuantityArray's unit.
    nd_type = NDArray(parameter_type.val.dtype)
    unit_name = vargraph.get_temporary_name(name, "unit_")
    cpp_name = vargraph.get_temporary_name(name, prefix='c++_')

    # Create a temporary NDArray:
    ndarray_rvalue, vgn_last, ndarray_name = ndarray_attribute_output(
        name,
        Temporary(nd_type),
        size_control_dict,
        vargraph,
        fk_namespace,
        None
    )


    # Output string:
    osb = OutputStringBuilder(unit_name, vargraph, vgn_last, 0)
    _, vgn_str = osb.create_ctypes()
    post_call = osb.ctypes_post_call_code()
    unit_id_name = osb.id_name


    # After we have read the string, we need to assemble the final
    # QuantityArray:
    post_call.append(
        f"    {name} = QuantityArray({ndarray_name}, {unit_name})"
    )

    # Finally (Python side): generate the QuantityArray.
    # This happens purely post-call.
    py_qa = PythonOutputParameter(
        name,
        parameter_type,
        [],
        post_call
    )
    vgn_last = vargraph.insert(py_qa, vgn_str)


    # Finally (C++ side):
    array_type = parameter_type.val
    cpp_type = array_type.dtype
    bu = array_type.boost_unit
    post_call_code = [
        f"*{unit_id_name} = "
        f"{fk_namespace}::create_string("
        f"{fk_namespace}::default_unit<{bu}>"
            ")"
    ]
    init_code = [
            "            "
        f"if ({unit_id_name} == nullptr)\n",
            "            "
        f"    throw std::runtime_error(\n"
            "            "
        f"        \"Internal error: output array '{name}' \"\n"
            "            "
        f"        \"has been passed a nullptr as output size parameter.\"\n"
            "            "
            "    );\n"
    ]
    cpp_type_str = cpp_type_string(cpp_type, fk_namespace)
    init_code.append(
         "            "
        f"auto {name} = {fk_namespace}::OutputQuantityArray<{bu}, {cpp_type_str}>(\n"
         "            "
        f"    {ndarray_rvalue}\n"
         "            "
         ");\n"
    )
    cpp = CppParameter(
        cpp_name,
        parameter_type,
        init_code,
        post_call_code,
        name,
        cpp_argument_id
    )
    vgn_last = vargraph.insert(cpp, vgn_str)

    return vgn_last



#
# 3. EuclideanPointArray
# ======================
#


def _generate_output_unit_tuple_parameters(
        root_name: str,
        root: VariableGraphNode,
        ndim: int,
        vargraph: VariableGraph
    ) -> tuple[VariableGraphNode, list[tuple[str,str]], list[str]]:
    """
    Generate the ctypes parameters required to pipe the string elements
    of a Python (unit) tuple to a C++ tuple of `const char*`.

    Parameters
    ----------
    root_name:
        Name of the root variable (e.g. a EuclideanInputRange)
        from which the names shall be derived.
    root:
        Node of the variable graph corresponding to the root variable.
    unit_string_access_expressions:
        Tuple of (Python) code expressions that return the unit
        strings.


    Returns
    -------
    last_node:
        Last node added to the variable graph. If anything was inserted,
        this corresponds to the last element of `cpp_variables`.
    unit_id_variable_names:
        Names of all variable graph nodes added to the graph, corresponding to
        the string variables in order passed in `unit_string_access_expressions`.
    post_call:
        Post call code.
    """
    last_node = root
    unit_id_variable_names: list[tuple[str,str]] = []
    post_call: list[str] = []
    for _ in range(ndim):
        # Output string:
        name = vargraph.get_temporary_name(root_name, 'unit_')
        osb = OutputStringBuilder(name, vargraph, last_node, 0)
        _, last_node = osb.create_ctypes()
        post_call.extend(osb.ctypes_post_call_code())
        if osb.id_name is None:
            raise RuntimeError(
                "Encountered obs.id_name == None."
            )
        unit_id_variable_names.append((name, osb.id_name))

    return last_node, unit_id_variable_names, post_call




def wrap_input_euclidean_point_array(
        name: str,
        parameter_type: Input[EuclideanPointArray],
        vargraph: VariableGraph,
        fk_namespace: str,
        cpp_argument_id: int
    ):
    """
    Generate the code and variable graph nodes to wrap an EuclideanPointArray
    parameter from Python to C++ input parameter.

    Parameters
    ----------
    name:
        Name of the Python EuclideanPointArray variable
    parameter_type:
        Type of the input variable (specifies the dimension and buffer data
        type of the Euclidean point array)
    vargraph:
        Variable graph of the wrapped function
    fk_namespace:
        Namespace (alias of) `funktionsklempner`
    cpp_argument_id:
        ID of the C++ argument in the wrapped function.

    Returns
    -------
    vgn_last:
        The last node added to the variable graph.
    """
    # 1. Create the Python input parameter
    # ====================================
    py = PythonInputParameter(
        name,
        parameter_type,
        [
            f"    assert isinstance({name}, EuclideanPointArray)"
        ]
    )
    vgn_epa = vargraph.insert(py)

    # Input NDArrays have a datatype `const T`, where `T` is the
    # fundamental type. Drop the `const` here since we will
    # get `const` again from the InputNDArray:
    dtype = parameter_type.val.dtype
    if not isinstance(dtype, Const):
        raise TypeError(
            "Data type of input array is not Const[T] (as it shall be)."
        )
    dtype = dtype.val

    # 2. Pipe the NDArray from Python to C++
    # ======================================
    #
    # Now pipe the NDArray from a Python variable's attribute
    # (EuclideanPointArray.array) to an rvalue
    # funktionsklempner::ndarray::NDArray
    # in the C++ world:
    nd_type = NDArray(dtype)
    ndim: int = parameter_type.val.ndim

    ndarray_rvalue, _, vgn_size = ndarray_attribute_input_to_rvalue(
        name,
        f"{name}.array",
        Input(nd_type),
        vargraph,
        vgn_epa,
        fk_namespace
    )

    # 2) Create the unit tuple parameter
    # ==================================
    last_node, unit_cpp_variables = generate_unit_tuple_parameters(
        name,
        vgn_size,
        tuple(f"{name}.unit[{i}]" for i in range(ndim)),
        vargraph
    )


    # Get the initializer code that fk::geo::create_euclidean_point_range
    # to assemble the EuclideanPointRange from the two rvalue expressions
    # (one for the NDArray and one for the unit tuple):
    unit_initializer = (
        f"\n                std::array<const char*, {ndim}>{{\n"
            "                    "
        f"{",\n                    ".join(unit_cpp_variables)}\n"
            "                }\n"
    )
    init_code = [
         "            "
        f"auto {name} = {fk_namespace}::geo::create_euclidean_point_range(\n"
         "            "
        f"    {ndarray_rvalue},"
        f"{unit_initializer}"
         "            "
         ");\n"
    ]

    # Assemble the EuclideanPointRange input parameter to the wrapped
    # C++ function:
    cpp_name = vargraph.get_temporary_name(name, prefix='c++_')
    cpp = CppParameter(
        cpp_name,
        parameter_type,
        init_code,
        None,
        name,
        cpp_argument_id
    )
    vgn_last = vargraph.insert(cpp, last_node)
    return vgn_last


def wrap_output_euclidean_point_array(
        name: str,
        parameter_type: Output[EuclideanPointArray],
        vargraph: VariableGraph,
        size_control_dict: SizeControl,
        fk_namespace: str,
        cpp_argument_id: int
    ):
    # Get temporary variables
    #  - to generate the EuclideanPointArray's ndarray,
    #  - to obtain the EuclideanPointArray's unit.
    nd_type = NDArray(parameter_type.val.dtype)
    ndim: int = parameter_type.val.ndim
    cpp_name = vargraph.get_temporary_name(name, prefix='c++_')

    # Create a temporary NDArray:
    ndarray_rvalue, vgn_last, ndarray_name = ndarray_attribute_output(
        name,
        Temporary(nd_type),
        size_control_dict,
        vargraph,
        fk_namespace,
        ndim
    )


    # Output string:
    vgn_last, variable_names, post_call \
        = _generate_output_unit_tuple_parameters(
        name,
        vgn_last,
        ndim,
        vargraph
    )


    # After we have read the string, we need to assemble the final
    # EuclideanPointArray:
    post_call.append(
        f"    {name} = EuclideanPointArray({ndarray_name}, ("
        f"{",".join(v[0] for v in variable_names)}))"
    )

    # Finally (Python side): generate the QuantityArray.
    # This happens purely post-call.
    py_qa = PythonOutputParameter(
        name,
        parameter_type,
        [],
        post_call
    )
    vgn_last = vargraph.insert(py_qa, vgn_last)


    # Finally (C++ side):
    array_type = parameter_type.val
    cpp_type = array_type.dtype
    post_call_code = [
        f"*{unit_id_name} = "
        f"{fk_namespace}::create_string("
        f"{fk_namespace}::default_unit<boost::units::si::length>"
         ")"
        for _,unit_id_name in variable_names
    ]
    init_code = [
            "            "
        f"if ({" || ".join(f"!{uid}" for _,uid in variable_names)})\n",
            "            "
        f"    throw std::runtime_error(\n"
            "            "
        f"        \"Internal error: output array '{name}' \"\n"
            "            "
        f"        \"has been passed a nullptr as output size parameter.\"\n"
            "            "
            "    );\n"
    ]
    cpp_type_str = cpp_type_string(cpp_type, fk_namespace)
    unit_tuple = f"{fk_namespace}::util::make_homogeneous_unit_tuple<{ndim}>("\
        "1.0 * boost::units::si::meters)"
    init_code.append(
         "            "
        f"auto {name} = {fk_namespace}::OutputEuclideanPointArray<{ndim}, {cpp_type_str}>(\n"
         "            "
        f"    {ndarray_rvalue},\n"
         "            "
        f"    {unit_tuple}\n"
         "            "
         ");\n"
    )
    cpp = CppParameter(
        cpp_name,
        parameter_type,
        init_code,
        post_call_code,
        name,
        cpp_argument_id
    )
    vgn_last = vargraph.insert(cpp, vgn_last)

    return vgn_last



#
# 4. GeographicPointArray
# =======================
#

def _generate_ellipsoid_parameters(
        root_name: str,
        ellipsoid_access: str,
        root: VariableGraphNode,
        ellipsoid: Ellipsoid,
        vargraph: VariableGraph
    ) -> tuple[VariableGraphNode, str]:
    """
    Generates code to pass an ellipsoid.
    """
    c_eid_name = vargraph.get_temporary_name(root_name, "ellipsoid_id__")
    c_eid = CTypeParameterByValue(
        c_eid_name,
        "c_size_t",
        [
            f"    {c_eid_name} = _create_ellipsoid({ellipsoid_access})"
        ]
    )
    last_node = vargraph.insert(c_eid, root)
    return last_node, c_eid_name



def wrap_input_geographic_point_array(
        name: str,
        parameter_type: Input[GeographicPointArray],
        vargraph: VariableGraph,
        fk_namespace: str,
        cpp_argument_id: int
    ):
    # 1. Create the Python input parameter
    # ====================================
    py = PythonInputParameter(
        name,
        parameter_type,
        [
            f"    {name} = to_geographic_point_array({name})"
        ]
    )
    vgn_epa = vargraph.insert(py)

    # Input NDArrays have a datatype `const T`, where `T` is the
    # fundamental type. Drop the `const` here since we will
    # get `const` again from the InputNDArray:
    dtype = parameter_type.val.dtype
    if not isinstance(dtype, Const):
        raise TypeError(
            "Data type of input array is not Const[T] (as it shall be)."
        )
    dtype = dtype.val

    # 2. Pipe the NDArray from Python to C++
    # ======================================
    #
    # Now pipe the NDArray from a Python variable's attribute
    # (EuclideanPointArray.array) to an rvalue
    # funktionsklempner::ndarray::NDArray
    # in the C++ world:
    nd_type = NDArray(dtype)
    with_height: bool = parameter_type.val.with_height
    ndim: Literal[2,3] = 3 if with_height else 2
    ellipsoid = parameter_type.val.ellipsoid

    ndarray_rvalue, _, vgn_size = ndarray_attribute_input_to_rvalue(
        name,
        f"{name}.array",
        Input(nd_type),
        vargraph,
        vgn_epa,
        fk_namespace
    )

    # 2) Create the unit tuple parameter
    # ==================================
    last_node, unit_cpp_variables = generate_unit_tuple_parameters(
        name,
        vgn_size,
        tuple(f"{name}.unit[{i}]" for i in range(ndim)),
        vargraph
    )


    # Ellipsoid:
    last_node, ellipsoid_variable= _generate_ellipsoid_parameters(
        name, f"{name}.ellipsoid", last_node, ellipsoid, vargraph
    )



    # Get the initializer code that fk::geo::create_geographic_point_range
    # uses to assemble the GeographicPointRange from the two rvalue expressions
    # (one for the NDArray and one for the unit tuple):
    unit_initializer = (
        f"\n                std::array<const char*, {ndim}>{{\n"
            "                    "
        f"{",\n                    ".join(unit_cpp_variables)}\n"
            "                }"
    )
    ellipsoid_initializer = (
        f"{fk_namespace}::geo::ellipsoid_object({ellipsoid_variable})"
    )
    init_code = [
         "            "
        f"auto {name} = {fk_namespace}::geo::create_geographic_point_range"
        f"<{"true" if with_height else "false"}, "
        f"{ellipsoid_cpp_type(ellipsoid, fk_namespace)}>(\n"
         "            "
        f"    {ndarray_rvalue},"
        f"{unit_initializer},\n"
         "            "
        f"    {ellipsoid_initializer}\n"
         "            "
         ");\n"
    ]

    # Assemble the EuclideanPointRange input parameter to the wrapped
    # C++ function:
    cpp_name = vargraph.get_temporary_name(name, prefix='c++_')
    cpp = CppParameter(
        cpp_name,
        parameter_type,
        init_code,
        None,
        name,
        cpp_argument_id
    )
    vgn_last = vargraph.insert(cpp, last_node)
    return vgn_last



def wrap_output_geographic_point_array(
        name: str,
        parameter_type: Output[GeographicPointArray],
        vargraph: VariableGraph,
        size_control_dict: SizeControl,
        ellipsoid_control_dict: EllipsoidControl,
        fk_namespace: str,
        cpp_argument_id: int,
        function_name: str
    ):
    # Get temporary variables
    #  - to generate the GeographicPointArray's ndarray,
    #  - to obtain the GeographicPointArray's units.
    nd_type = NDArray(parameter_type.val.dtype)
    with_height: bool = parameter_type.val.with_height
    ndim: Literal[2,3] = 3 if with_height else 2
    ellipsoid = parameter_type.val.ellipsoid
    cpp_name = vargraph.get_temporary_name(name, prefix='c++_')

    # Create a temporary NDArray:
    ndarray_rvalue, vgn_last, ndarray_name = ndarray_attribute_output(
        name,
        Temporary(nd_type),
        size_control_dict,
        vargraph,
        fk_namespace,
        ndim
    )


    # Output string(s):
    vgn_last, variable_names, post_call \
        = _generate_output_unit_tuple_parameters(
        name,
        vgn_last,
        ndim,
        vargraph
    )


    # Ellipsoid:
    if is_static_ellipsoid(ellipsoid):
        # For output geographic point arrays with named ellipsoid,
        # we simply use the corresponding string literal as a
        # value for the ellipsoid argument:
        ellipsoid_access = f"\"{ellipsoid}\""
    else:
        if name not in ellipsoid_control_dict:
            raise RuntimeError(
                "The ellipsoid control was not set for the output "
                f"geographic point array '{name}'. Please add a macro "
                f"FUNKTIONSKLEMPNER_ELLIPSOID_CONTROL(\"{name}\", \"Y\"), "
                "where \"Y\" is the name of a geographic point array---or "
                "a newly generated---input variable whose ellipsoid shall "
                f"be transferred to '{name}'. In function '{function_name}.'"
            )
        controller = ellipsoid_control_dict.get_control(name)
        if controller not in vargraph:
            # Generate an input parameter for the ellipsoid with name
            # as given in the FUNKTIONSKLEMPNER_ELLIPSOID_CONTROL macro.
            py_ellps_in = PythonInputParameter(
                controller,
                Input("Ellipsoid"),
                []
            )
            vgn_last = vargraph.insert(py_ellps_in, vgn_last)
            ellipsoid_access = py_ellps_in.name

        else:
            # Otherwise, ellipsoid can just be
            ellipsoid_access = f"{controller}.ellipsoid"


    vgn_last, ellipsoid_variable = _generate_ellipsoid_parameters(
        name, ellipsoid_access, vgn_last, ellipsoid, vargraph
    )


    # After we have read the string, we need to assemble the final
    # GeographicPointArray:
    post_call.append(
        f"    {name} = GeographicPointArray(\n"
        f"        (\n"
        f"            {ndarray_name},\n"
         "            ("
        f"{",".join(v[0] for v in variable_names)}),\n"
        f"            {ellipsoid_access}\n"
         "        )\n"
         "    )"
    )

    # Finally (Python side): generate the Python output parameter
    # This happens purely post-call.
    py_qa = PythonOutputParameter(
        name,
        parameter_type,
        [],
        post_call
    )
    vgn_last = vargraph.insert(py_qa, vgn_last)




    # Finally (C++ side):
    dimension = ('"°"', '"°"', '"m"')
    post_call_code = [
        f"*{unit_id_name} = "
        f"{fk_namespace}::create_string({dim})"
        for (_,unit_id_name), dim in zip(variable_names, dimension)
    ]
    init_code = [
         "            "
        f"if ({" || ".join(f"!{uid}" for _,uid in variable_names)})\n",
         "            "
        f"    throw std::runtime_error(\n"
         "            "
        f"        \"Internal error: output array '{name}' \"\n"
         "            "
        f"        \"has been passed a nullptr as output size parameter.\"\n"
         "            "
         "    );\n",
         "            "
         "constexpr auto degrees = 0.0174532925199432957692 "
            "* boost::units::si::radians;\n",
    ]
    if ndim == 3:
        init_code.append(
            "            "
            "constexpr auto meters = 1.0 * boost::units::si::meters;\n"
        )
    if ndim == 2:
        unit_tuple = "std::make_tuple(degrees, degrees)"
    else:
        unit_tuple = "std::make_tuple(degrees, degrees, meters)"
    ellipsoid_initializer = (
        f"{fk_namespace}::geo::ellipsoid_object({ellipsoid_variable})"
    )
    init_code.append(
         "            "
        f"auto {name} = {fk_namespace}::geo::create_geographic_point_range"
        f"<{"true" if with_height else "false"}, "
        f"{ellipsoid_cpp_type(ellipsoid, fk_namespace)}>(\n"
         "            "
        f"    {ndarray_rvalue},\n"
         "            "
        f"    {unit_tuple},\n"
         "            "
        f"    {ellipsoid_initializer}\n"
         "            "
         ");\n"
    )
    cpp = CppParameter(
        cpp_name,
        parameter_type,
        init_code,
        post_call_code,
        name,
        cpp_argument_id
    )
    vgn_last = vargraph.insert(cpp, vgn_last)

    return vgn_last