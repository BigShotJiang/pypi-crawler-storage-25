# Tests funktionsklempner.tools.

from funktionsklempner.tools import join, append, prepend, enclose


def test_join():
    assert "".join(join(("123","345"), ";")) == "123;345"
    assert "".join(join(("123",), ";")) == "123"
    assert "".join(join(tuple(), ";")) == ""

    assert "".join(append(("123","345"), ";")) == "123;345;"
    assert "".join(append(("123",), ";")) == "123;"
    assert "".join(append(tuple(), ";")) == ""

    assert "".join(prepend(("123","345"), ";")) == ";123;345"
    assert "".join(prepend(("123",), ";")) == ";123"
    assert "".join(prepend(tuple(), ";")) == ""

    assert "".join(enclose(("123","345"), ":", ";")) == ":123;:345;"
    assert "".join(enclose(("123",), ":", ";")) == ":123;"
    assert "".join(enclose(tuple(), ":", ";")) == ""