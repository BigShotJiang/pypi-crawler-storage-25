/*
 * Testing points.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
 * the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 *
 * https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: EUPL-1.2
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
static_assert(false, "Testing Funktionsklempner requires GeographicLib.");
#endif

#include <iostream>
#include <funktionsklempner/geo/point.hpp>
#include <boost/geometry.hpp>

using namespace funktionsklempner;
namespace geo = funktionsklempner::geo;
namespace si = boost::units::si;
namespace bu = boost::units;

/*
 * Type checks for the CoordinateTuple default coordinate provider:
 */
using TestCoordinates = geo::CoordinateTuple<
    bu::quantity<si::plane_angle>,
    bu::quantity<si::plane_angle>,
    bu::quantity<si::length, float>
>;
static_assert(concepts::Quantity<bu::quantity<si::length, float>>);
static_assert(concepts::CoordinateTuple<TestCoordinates>);





/* Statically evaluate the distance between two points
 * and compare to known value:
 */
constexpr static geo::Point2D c_p0(0.0 * si::meters, 0.0 * si::meters);
constexpr static geo::Point2D c_p2(1.0 * si::meters, -1.0 * si::meters);
constexpr static double c_distance_p0_p2 = c_p0.distance(c_p2) / si::meters;
constexpr static double sqrt_2 = 1.414213562373095048801688724209;
constexpr static double diff = c_distance_p0_p2 - sqrt_2;
static_assert(math::abs(diff) <= 1e-15);

/*
 * Constexpr geographic points:
 */
constexpr static geo::GeographicPoint2D<geo::ellipsoids::WGS84>
    c_gp0(0.0 * geo::degrees, 73.0 * geo::degrees);
constexpr static geo::GeographicPoint2D<geo::ellipsoids::WGS84>
    c_gp1(0.3 * geo::degrees, 71.0 * geo::degrees);


int test_pointview();

int test_point()
{
    geo::Point2D p0(0.0 * si::meters, 0.0 * si::meters);
    geo::Point2D p1(1.0 * si::meters, 0.0 * si::meters);
    geo::Point2D p2(1.0 * si::meters, -1.0 * si::meters);

    if (p0.distance(p1) != 1.0 * si::meters){
        std::cerr << "Distance from (0, 0) to (1,0) differs from 1.0 m by "
            << p0.distance(p1) / si::meters - 1.0 << " m\n";
        return 1;
    }
    if (std::abs((p0.distance(p2)/si::meters - std::sqrt(2))) > 1e-15){
        std::cerr << "Distance from (0,0) to (1,-1) differs from sqrt(2) by "
            << p0.distance(p1) / si::meters - std::sqrt(2) << "\n";
        return 1;
    }

    /*
     * Check the conversion to Boost.Geometry point model:
     */
    using BP2D = boost::geometry::model::point<
        double,
        2,
        boost::geometry::cs::cartesian
    >;
    BP2D boost_p1(p1.to_boost_geometry<double>(1.0 * si::meters));
    auto dx = (p1.x() / si::meters - boost_p1.get<0>());
    auto dy = (p1.y() / si::meters - boost_p1.get<1>());
    if (std::abs(dx * dx + dy*dy) > 1e-15){
        std::cerr << "Distance from p1 to its boost representation is "
            << std::abs(dx * dx + dy*dy) << " > 1e-15\n";
        return 1;
    }
    std::cout << "Successfully checked conversion to the Boost.Geometry point "
        "model.\n";


    /*
     * Check the geographic distance:
     */
    bu::quantity<si::length> dist = c_gp0.distance(c_gp1);
    // Reference value computed with Python bindings of GeographicLib:
    double diff = dist / si::meters - 225095.68339229978;
    if (std::abs(diff) > 1e-15){
        std::cerr << "Distance from (0°, 73°) to (0.3°, 71°) differs from "
            "reference solution by " << diff << " m\n";
        return 1;
    }

    /* Now the same for 'UserEllipsoid' version of WGS84: */
    geo::UserEllipsoid wgs84(
        6378137. * si::meters,
        1.0 / 298.257223563
    );
    geo::GeographicPoint2D<geo::UserEllipsoid>
        gp0(0.0 * geo::degrees, 73.0 * geo::degrees, wgs84);
    geo::GeographicPoint2D<geo::UserEllipsoid>
        gp1(0.3 * geo::degrees, 71.0 * geo::degrees, wgs84);
    dist = gp0.distance(gp1);
    diff = dist / si::meters - 225095.68339229978;
    if (std::abs(diff) > 1e-15){
        std::cerr << "Distance from (0°, 73°) to (0.3°, 71°) differs from "
            "reference solution by " << diff << " m\n";
        return 1;
    }

    return 0;
}


int main(){
    try {
        /* Test points: */
        if (test_point())
            return 1;

        std::cout << "test_point() completed.\n";

        /* Now test the pointview: */
        if (test_pointview())
            return 1;

        std::cout << "test_pointview() completed.\n";

    } catch (std::exception& e){
        std::cerr << "Exception: " << e.what() << "\n";
        return 1;
    } catch (...) {
        return 1;
    }

    return 0;
}