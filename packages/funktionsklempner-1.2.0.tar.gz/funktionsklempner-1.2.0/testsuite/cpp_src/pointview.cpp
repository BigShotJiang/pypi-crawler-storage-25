/*
 * Testing point views.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
 * the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 *
 * https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: EUPL-1.2
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_GEOGRAPHICLIB
static_assert(false, "Testing Funktionsklempner requires GeographicLib.");
#endif

#include <iostream>
#include <random>
#include <funktionsklempner/funktionsklempner.hpp>

#include <funktionsklempner/util/homogeneoustuple.hpp>
#include <funktionsklempner/geo/view/factory.hpp>

using namespace funktionsklempner;
namespace geo = funktionsklempner::geo;
namespace si = boost::units::si;
namespace bu = boost::units;

/*
 * Test the `make_homogeneous_unit_tuple` facility:
 */
using TU = bu::quantity<si::length>;
constexpr static std::tuple<TU,TU,TU> test_tuple
    = funktionsklempner::util::make_homogeneous_unit_tuple<3,TU>(1.0 * si::meters);

static_assert(std::get<0>(test_tuple) == 1.0 * si::meters);
static_assert(std::get<1>(test_tuple) == 1.0 * si::meters);
static_assert(std::get<2>(test_tuple) == 1.0 * si::meters);

/*
 * Test the `concepts::VectorQuantityView` concept:
 */
using MVQV = wrapper::MutableVectorQuantityView<
        double*,
        funktionsklempner::repeat_type<boost::units::si::length, 3>
    >;
using VQV = wrapper::VectorQuantityView<
        double*,
        funktionsklempner::repeat_type<boost::units::si::length, 3>
    >;

class TestVQV : public VQV
{};

static_assert(concepts::VectorQuantityView<MVQV>);
static_assert(concepts::VectorQuantityView<VQV>);
static_assert(concepts::VectorQuantityView<TestVQV>);
static_assert(!concepts::VectorQuantityView<double>);


/*
 * The example functions from the README:
 */

namespace README {

struct README_Euclidean_functionality {

//using E = funktionsklempner::geo::UserEllipsoid;
using T = double;
constexpr static size_t ndim = 3;
using R = funktionsklempner::OutputEuclideanPointArray<ndim, T>;
using EP = funktionsklempner::geo::Point3D;

void Euclidean_functionality(R r, const EP& p)
{
    /* Coordinates are quantities of length dimension: */
    using Coordinate = boost::units::quantity<boost::units::si::length, T>;

   /* Loop over all points of the range: */
   for (auto&& v : r){
      /* Access coordinate of index i < ndim: */
      Coordinate c = v.template get<0>();

        /* Compute distance.
         * d will be the Euclidean distance of length unit L.
         * d2 will skip sqrt computation and be of unit L^2
         */
        auto d2 = v.squared_distance(p);
        auto d = v.distance(p);

        /* If 1 <= ndim <= 3 */
        Coordinate x = v.x();

        /* If 2 <= ndim <= 3 */
        Coordinate y = v.y();

        /* If 3 == ndim */
        Coordinate z = v.z();

      /* If the storage class `Buf` is mutable: */
      v = p;
      v.template get<0>() = p.template get<0>();
   }
}

};


template<
    bool h
>
struct README_Geographic_functionality {

using E = funktionsklempner::geo::UserEllipsoid;
using T = double;
using R = funktionsklempner::OutputGeographicPointArray<T, E, h>;
using GP = funktionsklempner::geo::GeographicPoint3D<E>;


static
void Geographic_functionality(R r, const GP& p, const E& ellps)
{
    /* Coordinates are quantities of length dimension: */
    using Length = boost::units::quantity<boost::units::si::length, T>;
    using Angle = boost::units::quantity<boost::units::si::plane_angle, T>;

    /* Loop over all points of the range: */
    for (auto&& v : r){
        /* Access coordinates: */
        Angle lat = v.template get<0>();
        Angle lon = v.template get<1>();

        /* Equivalently: */
        lat = v.lat();
        lon = v.lon();

        /* If height switch has been set: */
        if constexpr (h){
            Length height = v.template get<2>();
            height = v.height();
        }

        /* Compute geodetic distance. This uses (and requires) GeographicLib
        * under the hood. d will be the Euclidean distance of length unit L.
        * This does not work if the coordinates have height:
        */
        if constexpr (!h){
            auto d = v.distance(p);
        }

        /* If the storage class `Buf` is mutable: */
        v = p;
        v.template get<0>() = p.template get<0>();

        /* Conversion from geographic coordinates to Euclidean coordinates
        * in an earth-centered earth-fixed coordinate system, and vice versa: */
        funktionsklempner::geo::Point3D xyz = v.to_ECEF();
        v = GP::from_ECEF(xyz, ellps);
    }
}
};

README_Geographic_functionality<true> with_height;
README_Geographic_functionality<false> without_height;

} // namespace README



int test_pointview(){
    /*
     * Test Euclidean arrays:
     */
    using LengthArray
        = funktionsklempner::InputQuantityArray<
            boost::units::si::length, double
          >;
    using EIt3 = geo::EuclideanIterator<3, double*>;
    using LengthTuple = repeat_type<
        bu::quantity<si::length, double>,
        3
    >;

    using TestT = std::decay_t<decltype(*std::declval<const double*>())>;
    using TestT = std::iter_value_t<const double*>;
    static_assert(std::input_or_output_iterator<EIt3>);


    std::array<double, 27> coordinates {
        0.57352976, 0.21818984, 0.97368777,
        0.90614226, 0.0220061,  0.68241739,
        0.15046309, 0.89358772, 0.81009426,
        0.69141849, 0.88175373, 0.97253586,
        0.10553318, 0.75429252, 0.96174592,
        0.34981342, 0.32737113, 0.79056086,
        0.8289327 , 0.56874547, 0.98359657,
        0.37226618, 0.29900859, 0.03630249,
        0.96282129, 0.87189019, 0.99113596
    };

    /* Wrap the array as meter data: */
    LengthArray _coordinates_m(
        coordinates.data(), coordinates.size(), "double"
    );


    LengthTuple R3_units = std::make_tuple(1.0 * si::meters, 1.0 * si::meters, 1.0 * si::meters);
    EIt3 it(
        coordinates.data(),
        R3_units
    );
    if (it[2].get<1>() != coordinates[7] * si::meters){
        std::cout << "Random access to point 2, coordinate 1 failed.\n"
            "is:        " << it[2].get<1>() / si::meters << "\n"
            "should be: " << coordinates[7] << "\n";
        return 1;
    }
    std::cout << "Euclidean point view random access check succeeded.\n";

    for (size_t i=0; i<coordinates.size() / 3; ++i){
        bool equal =
               ((*it).get<0>() == coordinates[3*i] * si::meters)
            && ((*it).get<1>() == coordinates[3*i+1] * si::meters)
            && ((*it).get<2>() == coordinates[3*i+2] * si::meters);
        if (!equal){
            std::cout << "incorrect point at index " << i << ":\n"
                << "should be: (" << coordinates[3*i] << ", "
                    << coordinates[3*i+1] << ", " << coordinates[3*i+2] << ")\n"
                << "but is:    (" << (*it).get<0>() / si::meters << ", "
                    << (*it).get<1>() / si::meters << ", "
                    << (*it).get<2>() / si::meters << ")\n";
            return 1;
        }
        ++it;
    }
    std::cout << "Euclidean point view comparison loop 1 succeeded.\n";

    size_t i=0;


    for (
        auto it = geo::make_euclidean_iterator<3>(coordinates.begin(), 1.0*si::meters);
        it != coordinates.end();
        ++it
    )
    {
        bool equal =
               ((*it).get<0>() == coordinates[3*i] * si::meters)
            && ((*it).get<1>() == coordinates[3*i+1] * si::meters)
            && ((*it).get<2>() == coordinates[3*i+2] * si::meters);
        auto test = (*it).get<0>() / si::meters;
        if (!equal){
            std::cout << "incorrect point at index " << i << ":\n"
                << "should be: (" << coordinates[3*i] << ", "
                    << coordinates[3*i+1] << ", " << coordinates[3*i+2] << ")\n"
                << "but is:    (" << it->get<0>() / si::meters << ", "
                    << (*it).get<1>() / si::meters << ", "
                    << (*it).get<2>() / si::meters << ")\n";
            return 1;
        }
        ++i;
    }
    std::cout << "Euclidean point view comparison loop 2 succeeded.\n";

    /*
     * Geographic:
     */
    using _AngleArray
        = funktionsklempner::InputQuantityArray<
            boost::units::si::plane_angle, double
          >;
    using GeoIt = geo::GeographicIterator<
        geo::ellipsoids::WGS84,
        concepts::geographic::_GeographicUnits,
        std::array<double, 16>::const_iterator
    >;
    std::array<double, 16> lalo_deg_orig = {
        -59.69935188,    8.16320657,
         36.54374188,   93.09985826,
        -72.26002444,   47.85757329,
         37.45710959,  144.69681312,
        -25.84511956,    80.0948955,
         60.51607813,  -98.15555466,
         21.04939383,  -85.38517277,
         25.00059441, -152.83208321
    };
    std::array<double, 16> lalo_deg {lalo_deg_orig};

    auto lalo_units = std::make_tuple(geo::degrees, geo::degrees);

    i=0;
    for (GeoIt it(lalo_deg.begin(), lalo_units); it != lalo_deg.end(); ++it)
    {
        bool equal =
               ((*it).get<0>() == lalo_deg[2*i] * geo::degrees)
            && ((*it).get<1>() == lalo_deg[2*i+1] * geo::degrees);
        if (!equal){
            std::cout << "incorrect point at index " << i << ":\n"
                << "should be: (" << lalo_deg[2*i] << ", "
                    << lalo_deg[2*i+1] << ")\n"
                << "but is:    (" << (*it).get<0>() / geo::degrees << ", "
                    << (*it).get<1>() / geo::degrees << ")\n";
            return 1;
        }
        ++i;
    }
    std::cout << "Geographic point view comparison loop 1 succeeded.\n";

    /*
     * Output to geographic:
     */
    using GeoPoint = geo::GeographicPoint2D<geo::ellipsoids::WGS84>;
    GeoPoint p_new(
        -7.3972782 * geo::degrees,
        61.732823 * geo::degrees
    );
    using AngleOutputArray
        = funktionsklempner::OutputQuantityArray<
            boost::units::si::plane_angle, double
          >;
    using GeoOutIt = geo::GeographicIterator<
        geo::ellipsoids::WGS84,
        concepts::geographic::_GeographicUnits,
        std::array<double, 16>::iterator
    >;

    using OutIter_t = std::ranges::iterator_t<AngleOutputArray>;
    using OutVal_t = std::iter_value_t<OutIter_t>;
    static_assert(std::input_or_output_iterator<OutIter_t>);
    static_assert(
        std::indirectly_writable<
            OutIter_t,
            boost::units::quantity<boost::units::si::plane_angle>
        >
    );
    static_assert(
        std::output_iterator<
            OutIter_t,
            boost::units::quantity<boost::units::si::plane_angle>
        >
    );

    for (GeoOutIt it(lalo_deg.begin(), lalo_units); it != lalo_deg.end(); ++it)
    {
        *it = p_new;
    }
    std::cout << "Geographic point view assignment loop succeeded.\n";


    /*
     * Validate the assignment:
     */
    i = 0;
    for (GeoIt it(lalo_deg.begin(), lalo_units); it != lalo_deg.end(); ++it)
    {
        if (*it != p_new)
        {
            std::cout << "incorrect point at index " << i << ":\n"
                << "should be: (" << p_new.lat() / geo::degrees << ", "
                    << p_new.lon() / geo::degrees << ")\n"
                << "but is:    (" << it->get<0>() / geo::degrees << ", "
                    << (*it).get<1>() / geo::degrees << ")\n";
            return 1;
        }
    }

    std::cout << "Geographic point view comparison loop 2 succeeded.\n";

    /*
     * Check the range interface:
     */

    using EuclideanInputRange = funktionsklempner::geo::EuclideanPointRange<
        3,
        true,
        std::array<double, 27>
    >;


    EuclideanInputRange eir(coordinates, R3_units);
    auto check_euclidean_input_range =
    [&coordinates](auto&& eir) -> bool
    {
        size_t i = 0;
        for (auto p : eir){
            double x = p.x() / si::meters;
            double y = p.y() / si::meters;
            double z =  p.z() / si::meters;
            std::cout << "p[" << i << "] = (" << x << ", "
                << y << ", " << z << ")\n";
            size_t j = 3*i;
            if (j + 2 >= coordinates.size()){
                std::cerr << "Range exceeds number of indices; trying to access index "
                    << j << " of " << coordinates.size() << " element array.\n";
                return false;
            }
            if (p.x() != coordinates[j] * si::meters){
                std::cerr << "Incorrect x coordinate returned from EuclideanInputRange at "
                    "element " << i << ". Have " << p.x() / si::meters << " m, differing by "
                    << p.x() / si::meters  - coordinates[j] << " m from the true value "
                    << coordinates[j] << " m.\n";
                return false;
            }
            if (p.y() != coordinates[j+1] * si::meters){
                std::cerr << "Incorrect y coordinate returned from EuclideanInputRange at "
                    "element " << i << ". Have " << p.y() / si::meters << " m, differing by "
                    << p.y() / si::meters  - coordinates[j+1] << " m from the true value "
                    << coordinates[j+1] << " m.\n";
                return false;
            }
            if (p.z() != coordinates[j+2] * si::meters){
                std::cerr << "Incorrect z coordinate returned from EuclideanInputRange at "
                    "element " << i << ". Have " << p.z() / si::meters << " m, differing by "
                    << p.z() / si::meters  - coordinates[j+2] << " m from the true value "
                    << coordinates[j+2] << " m.\n";
                return false;
            }
            ++i;
        }
        return true;
    };

    if (!check_euclidean_input_range(eir))
        return 1;


    /* Now check the factory method: */
    auto eir2 = geo::create_euclidean_point_range(
        ndarray::NDArray<double>(
            coordinates.data(),
            coordinates.size(),
            "double"
        ),
        std::array<const char*, 3> {"m", "m", "m"}
    );
    if (!check_euclidean_input_range(eir2))
        return 1;

    std::cout << "Euclidean input range checks succeeded.\n";

    using GeographicInputRange = funktionsklempner::geo::GeographicPointRange<
        geo::ellipsoids::WGS84,
        true,
        concepts::geographic::_GeographicUnits,
        std::array<double, 16>
    >;
    GeographicInputRange gir(lalo_deg, lalo_units);
    lalo_deg = lalo_deg_orig;

    auto check_geographic_input_range =
    [&lalo_deg](auto&& gir) -> bool
    {
        size_t i = 0;
        for (auto p : gir){
            std::cout << "p[" << i << "] = (" << p.lat() / geo::degrees << ", "
                << p.lon() / geo::degrees << ")\n";
            size_t j = 2*i;
            if (j + 1 >= lalo_deg.size()){
                std::cerr << "Range exceeds number of indices; trying to access index "
                    << j << " of " << lalo_deg.size() << " element array.\n";
                return false;
            }
            if (p.lat() != lalo_deg[j] * geo::degrees){
                std::cerr << "Incorrect latitude coordinate returned from GeographicInputRange "
                    "at element " << i << ". Have " << p.lat() / geo::degrees << " °, differing by "
                    << p.lat() / geo::degrees  - lalo_deg[j] << " ° from the true value "
                    << lalo_deg[j] << " °.\n";
                return false;
            }
            if (p.lon() != lalo_deg[j+1] * geo::degrees){
                std::cerr << "Incorrect longitude coordinate returned from GeographicInputRange "
                    "at element " << i << ". Have " << p.lat() / geo::degrees << " °, differing by "
                    << p.lon() / geo::degrees  - lalo_deg[j+1] << " ° from the true value "
                    << lalo_deg[j+1] << " °.\n";
                return false;
            }
            ++i;
        }
        return true;
    };


    if (!check_geographic_input_range(gir))
        return 1;


    /* Now check the factory method: */
    auto gir2 = geo::create_geographic_point_range<false, geo::ellipsoids::WGS84>(
        ndarray::NDArray<const double>(
            lalo_deg.data(),
            lalo_deg.size(),
            "double"
        ),
        std::array<const char*, 2> {"°", "°"},
        "WGS84"
    );
    if (!check_geographic_input_range(gir2))
        return 1;

    std::cout << "Geographic input range checks succeeded.\n";

    /*
     * Transform geographic coordinates to xyz:
     */
    using _LengthOutputArray
        = funktionsklempner::OutputQuantityArray<
            boost::units::si::length, double
          >;
    using EuclideanOutputRange = funktionsklempner::geo::EuclideanPointRange<
        3,
        false,
        std::array<double, 27>
    >;

    using Length = boost::units::quantity<si::length>;
    i = 0;
    std::ranges::transform(
        gir.begin(),
        gir.end(),
        EuclideanOutputRange(coordinates, R3_units).begin(),
        [&](auto&& geo) -> geo::Point3D
        {
            std::cout << "transforming geographical point " << i++ << "\n";
            return geo.to_ECEF();
        }
    );


    /* Check the result of this transformation: */
    i = 0;
    for (auto p : eir){
        if (i == gir.size())
            break;
        std::cout << "p[" << i << "] = (" << p.x() / si::meters << ", "
            << p.y() / si::meters << ", " << p.z() / si::meters << ")\n";
        auto p_cmp = gir.begin()[i].to_ECEF();
        if (p != p_cmp){
            std::cerr << "Incorrectly transformed point to Earth-centered, Earth-fixed CRS "
                "at index " << i << ". "
                << "Have (" << p.x() / si::meters << ", " << p.y() / si::meters << ", "
                    << p.z() / si::meters << ")\n"
                   "vs (" << p_cmp.x() / si::meters << ", " << p_cmp.y() / si::meters << ", "
                    << p_cmp.z() / si::meters << ")\n";
            return 1;
        }
        ++i;
    }

    /*
     * Transform xyz to geographic coordinates:
     */
    using GeographicOutputRange = funktionsklempner::geo::GeographicPointRange<
        geo::ellipsoids::WGS84,
        false,
        concepts::geographic::_GeographicUnits,
        std::vector<double>
    >;

    static_assert(
        std::ranges::output_range<
            GeographicOutputRange,
            GeoPoint
        >
    );

    /* Create an output array: */
    std::vector<double> lalo_deg_out(16);
    AngleOutputArray lalo_out_vec(
        lalo_deg_out.data(),
        lalo_deg_out.size(),
        "double",
        "°"
    );
    i = 0;
    std::cout << "number of geographic points: "
        << GeographicOutputRange(lalo_deg_out, lalo_units).size() << "\n";
    std::ranges::transform(
        eir.begin(),
        eir.begin() + GeographicOutputRange(lalo_deg_out, lalo_units).size(),
        GeographicOutputRange(lalo_deg_out, lalo_units).begin(),
        [&](auto&& p) -> GeoPoint
        {
            GeoPoint gp(GeoPoint::from_ECEF(p, geo::ellipsoids::WGS84()));
            std::cout << "   transforming geographical point " << i++
                << " to (" << gp.lat() / geo::degrees
                << ", " << gp.lon() / geo::degrees  << ")\n";
            return gp;
        }
    );

    double max_diff = 0.0;
    for (i=0; i<lalo_deg_out.size()/2; ++i){
        size_t j = 2*i;
        max_diff = std::max(max_diff, std::abs(lalo_deg[j] - lalo_deg_out[j]));
        if (max_diff > 2e-14)
        {
            std::cerr << "found difference in projection chain geo -> ECEF -> geo at point "
                "index " << i << " (latitude): difference is "
                << std::abs(lalo_deg[j] - lalo_deg_out[j]) << ".\n   "
                "(" << lalo_deg[j] << ", " << lalo_deg[j+1] << ")\nvs ("
            << lalo_deg_out[j] << ", " << lalo_deg_out[j+1] << ")\n";
            return 1;
        }
        max_diff = std::max(max_diff, std::abs(lalo_deg[j+1] - lalo_deg_out[j+1]));
        if (max_diff > 2e-14)
        {
            std::cerr << "found difference in projection chain geo -> ECEF -> geo at point "
                "index " << i << " (longitude): difference is "
                << std::abs(lalo_deg[j+1] - lalo_deg_out[j+1]) << ".\n   "
                "(" << lalo_deg[j] << ", " << lalo_deg[j+1] << ")\nvs ("
            << lalo_deg_out[j] << ", " << lalo_deg_out[j+1] << ")\n";
            return 1;
        }
    }
    std::cout << "all " << lalo_deg_out.size() / 2 << " points were successfully recovered "
        "in the [geo -> ECEF -> geo] transformation loop to coordinate precision "
        << max_diff << ".\n";


    /* Test the `create_geographic_point_range` function: */
    std::array<double, 24> lalo_deg_h_m{};
    auto out_test = geo::create_geographic_point_range<
        true,
        geo::UserEllipsoid
    >(
        funktionsklempner::OutputNDArray<double>(
            lalo_deg_h_m.data(),
            lalo_deg_h_m.size(),
            "double"
        ),
        std::make_tuple(
            geo::degrees,
            geo::degrees,
            1.0 * boost::units::si::meters
        ),
        geo::ellipsoids::WGS84::a.value(),
        "m",
        geo::ellipsoids::WGS84::f
    );

    auto it_geo3_out = out_test.begin();
    std::mt19937_64 rng(28928);
    std::uniform_real_distribution dist(-2000.0, 289.0);
    std::vector<double> heights;
    geo::UserEllipsoid userWGS84(
        geo::ellipsoids::WGS84::a,
        geo::ellipsoids::WGS84::f
    );
    std::ranges::transform(
        gir.begin(),
        gir.begin() + gir.size(),
        out_test.begin(),
        [&](auto&& p) -> geo::GeographicPoint3D<geo::UserEllipsoid>
        {
            auto lat = p.lat();
            auto lon = p.lon();
            auto h = dist(rng);
            heights.push_back(h);
            return geo::GeographicPoint3D<geo::UserEllipsoid>(
                lat, lon, h * boost::units::si::meters, userWGS84
            );
        }
    );

    auto in_geo3 = geo::create_geographic_point_range<
        true,
        geo::UserEllipsoid
    >(
        funktionsklempner::InputNDArray<double>(
            lalo_deg_h_m.data(),
            lalo_deg_h_m.size(),
            "double"
        ),
        std::make_tuple(
            geo::degrees,
            geo::degrees,
            1.0 * boost::units::si::meters
        ),
        geo::ellipsoids::WGS84::a.value(),
        "m",
        geo::ellipsoids::WGS84::f
    );
    i = 0;
    for (auto&& p : in_geo3)
    {
        if (p.height() != heights.at(i) * boost::units::si::meters)
        {
            std::cerr << "Difference in assigned height at index " << i << ": "
                << p.height() / boost::units::si::meters << " m vs "
                << heights.at(i) << "m.\n";
            return 1;
        }
        ++i;
    }
    std::cout << "Checked height assignment to geographic points successfully.\n";




    return 0;
}