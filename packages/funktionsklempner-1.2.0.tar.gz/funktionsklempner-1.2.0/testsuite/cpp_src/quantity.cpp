/*
 * Quantities
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
 * the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 *
 * https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and
 * limitations under the Licence.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: EUPL-1.2
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#include <funktionsklempner/quantity.hpp>
#include <iostream>

using funktionsklempner::InputQuantity;
using funktionsklempner::parse_input_quantity;
namespace si = boost::units::si;
namespace bu = boost::units;


int main(){

    constexpr double d0 = 2.0;
    InputQuantity<si::length, double> q0(
        parse_input_quantity<si::length>(d0, "m")
    );

    if (q0 != bu::quantity<si::length>::from_value(d0)){
        auto d0__ = q0 / si::meters;
        std::cerr << "q0 = " << q0 / si::meters << " is not equal to "
            << d0 << " m.\n";
        return 1;
    }


    return 0;
}