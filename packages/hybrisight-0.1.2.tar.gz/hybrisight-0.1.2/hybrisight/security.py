# SPDX-License-Identifier: Apache-2.0
import logging

logger = logging.getLogger(__name__)

SUSPICIOUS_PATTERNS = [
    b"/bin/bash",
    b"reverse_shell",
    b"nc -e /bin/sh",
    b"sh -i >& /dev/tcp/",
    b"exec(base64.b64decode",
    b"eval(base64_decode",
    b"curl http://",
    b"wget http://",
    b"powershell -nop -exec bypass",
]

def scan_payload_for_malware(payload: bytes) -> bool:
    """
    Lightweight pattern matcher for JSON artifacts.
    Checks for high-risk strings that should not exist in a valid ScanResult.
    Returns True if clean, False if suspicious.
    """
    lowered = payload.lower()
    for pattern in SUSPICIOUS_PATTERNS:
        if pattern in lowered:
            logger.warning(f"Malware scan triggered: detected suspicious pattern {pattern}")
            return False
    return True
