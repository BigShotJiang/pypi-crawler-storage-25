# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from collections import Counter

from hybrisight.checks.builtin import EVALUATORS
from hybrisight.checks.loader import RuleDefinition, load_rules
from hybrisight.config import RULES_DIR
from hybrisight.cost_estimator import ESTIMATORS
from hybrisight.models import Asset, Category, CoverageLevel, Effort, Finding, ScanResult, Severity
from hybrisight.scoring import SCORING_VERSION, calculate_snapshot_scores as _calculate_snapshot_scores, prioritize_findings
from hybrisight.scoring_projection import build_cumulative_phase_projection


def evaluate_assets(provider: str, assets: list[Asset], rules: list[RuleDefinition]) -> tuple[list[Finding], dict[str, int]]:
    findings: list[Finding] = []
    cost_sources: dict[str, int] = {"billing_api": 0, "pricing_table": 0, "static_default": 0}
    for asset in assets:
        for rule in rules:
            if rule.provider not in {provider, "*"}:
                continue
            if rule.service not in {asset.service, "*"}:
                continue
            evaluator = EVALUATORS.get(rule.evaluator)
            if evaluator and evaluator(asset, rule.config):
                annual_cost = None
                cost_source = "static_default"
                signal_override = asset.metadata.get("estimated_annual_cost_impact_gbp_signal")
                if isinstance(signal_override, (int, float)) and signal_override > 0:
                    annual_cost = float(signal_override)
                    cost_source = "billing_api"
                else:
                    estimator = ESTIMATORS.get(rule.evaluator)
                    if estimator:
                        pricing = estimator(asset.metadata, asset.region)
                        if pricing is not None and pricing > 0:
                            annual_cost = pricing
                            cost_source = "pricing_table"
                if annual_cost is None or annual_cost <= 0:
                    annual_cost = rule.estimated_annual_cost_impact_gbp
                if not annual_cost or annual_cost <= 0:
                    annual_cost = None
                if annual_cost:
                    cost_sources[cost_source] = cost_sources.get(cost_source, 0) + 1
                findings.append(
                    Finding(
                        id=rule.id,
                        provider=asset.provider,
                        service=asset.service,
                        resource_id=asset.resource_id,
                        title=rule.title,
                        category=Category(rule.category),
                        severity=Severity(rule.severity),
                        description=rule.description,
                        business_impact=rule.business_impact,
                        estimated_annual_cost_impact_gbp=annual_cost,
                        remediation_guidance=rule.remediation_guidance,
                        remediation_effort=Effort(rule.remediation_effort),
                    )
                )
    return findings, cost_sources


def calculate_snapshot_scores(findings: list[Finding], coverage_level: CoverageLevel, asset_count: int = 1) -> dict[str, float | str]:
    return _calculate_snapshot_scores(findings, asset_count=asset_count, coverage_level=coverage_level)


def apply_scoring(result: ScanResult) -> ScanResult:
    if (
        result.scoring_version == SCORING_VERSION
        and result.risk_index is not None
        and result.posture_score is not None
        and result.confidence_adjusted_score is not None
        and result.top_finding_ids is not None
    ):
        return result

    scores = _calculate_snapshot_scores(result.findings, result.asset_count, result.coverage_level)
    prioritized = prioritize_findings(result.findings)
    result.scoring_version = str(scores["scoring_version"])
    result.risk_index = float(scores["risk_index"])
    result.posture_score = float(scores["posture_score"])
    result.confidence_adjusted_score = float(scores["confidence_adjusted_score"])
    result.top_finding_ids = [finding.id for finding in prioritized[:10]]
    return result


COLLECTED_SERVICES = {
    "ec2", "network", "ebs", "snapshot", "elb", "rds",
    "iam", "s3", "trustedadvisor", "guardduty",
    "cloudtrail", "cloudwatch", "costexplorer",
    "kms", "log_group", "ecs", "eks",
    "vm", "disk", "storage", "resource", "azure_lb", "iam_account",
    "advisor", "defender", "costmanagement",
    "azure_sql", "azure_monitor",
}


def _build_collection_manifest(assets: list[Asset], rules: list[RuleDefinition]) -> dict[str, dict[str, object]]:
    service_counts = Counter(a.service for a in assets)
    rule_services: set[str] = set()
    for r in rules:
        if r.service != "*" and r.service:
            rule_services.add(r.service)
        for s in r.config.get("service_in", []):
            if isinstance(s, str) and s.strip():
                rule_services.add(s.strip())
    manifest = {}
    for svc in sorted(COLLECTED_SERVICES | rule_services):
        count = service_counts.get(svc, 0)
        if count > 0:
            manifest[svc] = {"status": "collected", "count": count}
        elif svc in COLLECTED_SERVICES:
            manifest[svc] = {"status": "empty", "count": 0}
        else:
            manifest[svc] = {"status": "not_collected", "count": 0}
    return manifest


def run_scan(
    provider: str,
    assets: list[Asset],
    rules_dir: Path = RULES_DIR,
    coverage_level: CoverageLevel = CoverageLevel.full,
) -> ScanResult:
    rules = load_rules(rules_dir)
    findings, cost_sources = evaluate_assets(provider=provider, assets=assets, rules=rules)
    diagnostics: dict[str, object] = {}
    if any(v > 0 for v in cost_sources.values()):
        diagnostics["cost_sources"] = cost_sources
    diagnostics["collection_manifest"] = _build_collection_manifest(assets, rules)
    result = ScanResult(
        scanned_provider=provider,
        coverage_level=coverage_level,
        asset_count=len(assets),
        finding_count=len(findings),
        findings=findings,
        generated_at_utc=datetime.now(UTC).isoformat(),
        collection_diagnostics=diagnostics,
    )
    return apply_scoring(result)


def build_report_context(result: ScanResult, trend_summary: dict[str, Any] | None = None, client_name: str | None = None) -> dict[str, Any]:
    import hybrisight.engine_context as _engine_context

    # Keep legacy monkeypatch contract on hybrisight.engine for projection tests.
    _engine_context.build_cumulative_phase_projection = build_cumulative_phase_projection
    return _engine_context.build_report_context(result, trend_summary=trend_summary, client_name=client_name)


def save_json_report(result: ScanResult, output: Path) -> None:
    from hybrisight.engine_output import save_json_report as _save

    _save(result, output)


def save_pdf_ready_summary(result: ScanResult, output: Path, trend_summary: dict[str, Any] | None = None, client_name: str | None = None) -> None:
    from hybrisight.engine_output import save_pdf_ready_summary as _save

    _save(result, output, trend_summary=trend_summary, client_name=client_name)


def save_html_report(result: ScanResult, output: Path, trend_summary: dict[str, Any] | None = None, client_name: str | None = None, gated_compliance: bool = True) -> None:
    from hybrisight.engine_output import save_html_report as _save
    _save(result, output, trend_summary=trend_summary, client_name=client_name, gated_compliance=gated_compliance)
