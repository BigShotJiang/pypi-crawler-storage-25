# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from hybrisight.web.db import Base


class Tenant(Base):
    __tablename__ = "tenants"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    slug: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    status: Mapped[str] = mapped_column(String(32), default="active", index=True)
    status_reason: Mapped[str | None] = mapped_column(Text, default=None)
    status_updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    status_updated_by_user_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))

    users: Mapped[list[User]] = relationship("User", back_populates="tenant")
    uploads: Mapped[list[ScanUpload]] = relationship("ScanUpload", back_populates="tenant")
    audit_logs: Mapped[list[AuditLog]] = relationship("AuditLog", back_populates="tenant")
    signing_keys: Mapped[list[TenantSigningKey]] = relationship("TenantSigningKey", back_populates="tenant")
    execution_tickets: Mapped[list[ExecutionTicket]] = relationship("ExecutionTicket", back_populates="tenant")
    settings: Mapped[list[TenantSetting]] = relationship("TenantSetting", back_populates="tenant")
    playbook_overrides: Mapped[list[TenantPlaybookOverride]] = relationship("TenantPlaybookOverride", back_populates="tenant")


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(512))
    role: Mapped[str] = mapped_column(String(50), default="analyst")
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    failed_login_attempts: Mapped[int] = mapped_column(Integer, default=0)
    login_locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None, index=True)
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    mfa_secret: Mapped[str | None] = mapped_column(String(64), default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))

    tenant: Mapped[Tenant] = relationship("Tenant", back_populates="users")
    uploads: Mapped[list[ScanUpload]] = relationship("ScanUpload", back_populates="uploaded_by")


class ScanUpload(Base):
    __tablename__ = "scan_uploads"
    __table_args__ = (UniqueConstraint("tenant_id", "tenant_upload_seq", name="uq_scan_uploads_tenant_seq"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_upload_seq: Mapped[int] = mapped_column(Integer, default=0, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    uploaded_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    assessment_scope_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    reassessment_series_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    baseline_upload_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    continuity_metadata_json: Mapped[str | None] = mapped_column(Text, default=None)
    continuity_metadata_source: Mapped[str | None] = mapped_column(String(32), default=None, index=True)
    artifact_continuity_digest: Mapped[str | None] = mapped_column(String(64), default=None, index=True)
    source_type: Mapped[str] = mapped_column(String(100), default="scanresult")
    source_detail: Mapped[str | None] = mapped_column(String(100), default=None)
    provider: Mapped[str] = mapped_column(String(50), index=True)
    schema_version: Mapped[str] = mapped_column(String(32), default="1.1")
    coverage_level: Mapped[str] = mapped_column(String(32), default="unknown")
    signature_valid: Mapped[bool | None] = mapped_column(Boolean, default=None)
    signature_source: Mapped[str | None] = mapped_column(String(32), default=None)
    asset_count: Mapped[int] = mapped_column(Integer)
    finding_count: Mapped[int] = mapped_column(Integer)
    generated_at_utc: Mapped[str] = mapped_column(String(64))
    artifact_path: Mapped[str | None] = mapped_column(String(1024), default=None)
    artifact_sha256: Mapped[str | None] = mapped_column(String(64), default=None, index=True)
    raw_json: Mapped[str] = mapped_column(Text)
    execution_state: Mapped[str] = mapped_column(String(24), default="hold", index=True)
    execution_state_updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    execution_state_updated_by_user_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))

    tenant: Mapped[Tenant] = relationship("Tenant", back_populates="uploads")
    uploaded_by: Mapped[User] = relationship("User", back_populates="uploads")
    execution_tickets: Mapped[list[ExecutionTicket]] = relationship("ExecutionTicket", back_populates="upload")


class ExecutionTicket(Base):
    __tablename__ = "execution_tickets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    upload_id: Mapped[int | None] = mapped_column(ForeignKey("scan_uploads.id"), index=True, default=None)
    assessment_scope_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    reassessment_series_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    origin_upload_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    last_seen_upload_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    matched_from_ticket_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    continuity_status: Mapped[str] = mapped_column(String(32), default="new", index=True)
    finding_id: Mapped[str] = mapped_column(String(128), index=True)
    title: Mapped[str] = mapped_column(String(255))
    theme: Mapped[str] = mapped_column(String(128), index=True)
    phase: Mapped[str] = mapped_column(String(32), index=True)
    severity: Mapped[str] = mapped_column(String(32), index=True)
    business_impact: Mapped[str] = mapped_column(Text, default="")
    affected_resource_count: Mapped[int] = mapped_column(Integer, default=0)
    occurrence_count: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(32), default="new", index=True)
    owner: Mapped[str | None] = mapped_column(String(255), default=None)
    due_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    blocked_reason: Mapped[str | None] = mapped_column(Text, default=None)
    accepted_risk_reason: Mapped[str | None] = mapped_column(Text, default=None)
    depends_on_ticket_id: Mapped[int | None] = mapped_column(Integer, default=None, index=True)
    lane_order: Mapped[int] = mapped_column(Integer, default=0, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        index=True,
    )

    tenant: Mapped[Tenant] = relationship("Tenant", back_populates="execution_tickets")
    upload: Mapped[ScanUpload | None] = relationship("ScanUpload", back_populates="execution_tickets")
    evidence_items: Mapped[list[TicketEvidence]] = relationship("TicketEvidence", back_populates="ticket")
    comments: Mapped[list[TicketComment]] = relationship("TicketComment", back_populates="ticket")


class TenantSetting(Base):
    __tablename__ = "tenant_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    key: Mapped[str] = mapped_column(String(128), index=True)
    value: Mapped[str] = mapped_column(String(512), default="")
    updated_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        index=True,
    )

    tenant: Mapped[Tenant] = relationship("Tenant", back_populates="settings")


class RemediationPlaybook(Base):
    __tablename__ = "remediation_playbooks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    finding_id: Mapped[str] = mapped_column(String(128), index=True)
    provider: Mapped[str] = mapped_column(String(32), index=True)
    theme: Mapped[str] = mapped_column(String(128), index=True)
    version: Mapped[str] = mapped_column(String(32), default="1.0")
    objective: Mapped[str] = mapped_column(Text)
    practical_steps_json: Mapped[str] = mapped_column(Text, default="[]")
    validation_checks_json: Mapped[str] = mapped_column(Text, default="[]")
    rollback_steps_json: Mapped[str] = mapped_column(Text, default="[]")
    required_evidence_json: Mapped[str] = mapped_column(Text, default="[]")
    owner_role: Mapped[str] = mapped_column(String(64), default="platform_engineer")
    estimated_effort: Mapped[str] = mapped_column(String(32), default="medium")
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        index=True,
    )


class TenantPlaybookOverride(Base):
    __tablename__ = "tenant_playbook_overrides"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    playbook_id: Mapped[int] = mapped_column(ForeignKey("remediation_playbooks.id"), index=True)
    practical_steps_json: Mapped[str | None] = mapped_column(Text, default=None)
    validation_checks_json: Mapped[str | None] = mapped_column(Text, default=None)
    rollback_steps_json: Mapped[str | None] = mapped_column(Text, default=None)
    required_evidence_json: Mapped[str | None] = mapped_column(Text, default=None)
    tenant_notes: Mapped[str | None] = mapped_column(Text, default=None)
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        index=True,
    )

    tenant: Mapped[Tenant] = relationship("Tenant", back_populates="playbook_overrides")


class TicketEvidence(Base):
    __tablename__ = "ticket_evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("execution_tickets.id"), index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    evidence_key: Mapped[str] = mapped_column(String(128), index=True)
    evidence_value: Mapped[str] = mapped_column(Text)
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)

    ticket: Mapped[ExecutionTicket] = relationship("ExecutionTicket", back_populates="evidence_items")


class TicketComment(Base):
    __tablename__ = "ticket_comments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("execution_tickets.id"), index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    comment_text: Mapped[str] = mapped_column(Text)
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)

    ticket: Mapped[ExecutionTicket] = relationship("ExecutionTicket", back_populates="comments")


class ScanJobToken(Base):
    __tablename__ = "scan_job_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used: Mapped[bool] = mapped_column(Boolean, default=False)
    scope: Mapped[str] = mapped_column(String(64), default="scan_job:upload")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))


class ApiKey(Base):
    __tablename__ = "api_keys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String(255), default="default")
    key_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    scope: Mapped[str] = mapped_column(String(64), default="scan_job:create")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None, index=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None, index=True)
    soft_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))


class TenantSigningKey(Base):
    __tablename__ = "tenant_signing_keys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    key_id: Mapped[str] = mapped_column(String(128), index=True)
    algorithm: Mapped[str] = mapped_column(String(64), default="ed25519")
    public_key_pem: Mapped[str] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)

    tenant: Mapped[Tenant] = relationship("Tenant", back_populates="signing_keys")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int | None] = mapped_column(ForeignKey("tenants.id"), index=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(120), index=True)
    path: Mapped[str] = mapped_column(String(512), default="")
    method: Mapped[str] = mapped_column(String(16), default="")
    ip_address: Mapped[str | None] = mapped_column(String(100), default=None)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    tenant: Mapped[Tenant | None] = relationship("Tenant", back_populates="audit_logs")


class ReportShareToken(Base):
    __tablename__ = "report_share_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    token: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    upload_id: Mapped[int] = mapped_column(ForeignKey("scan_uploads.id"), index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    accessed_count: Mapped[int] = mapped_column(Integer, default=0)
    last_accessed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    token: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))
