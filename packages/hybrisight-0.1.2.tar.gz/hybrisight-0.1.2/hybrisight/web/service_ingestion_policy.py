# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any


_NATIVE_EXPORT_PROFILES: dict[str, dict[str, str]] = {
    "aws_security_hub": {
        "label": "AWS Security Hub Export",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Partial coverage from approved native export.",
    },
    "aws_trusted_advisor_export": {
        "label": "AWS Trusted Advisor Export",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Partial coverage from approved native export.",
    },
    "aws_iam_credential_report": {
        "label": "AWS IAM Credential Report",
        "quality": "identity_partial",
        "quality_label": "Identity Only",
        "coverage_note": "Identity-only signal. Not a full baseline replacement.",
    },
    "aws_iam_authorization_details": {
        "label": "AWS IAM Authorization Details Export",
        "quality": "identity_partial",
        "quality_label": "Identity Only",
        "coverage_note": "Identity-only signal. Not a full baseline replacement.",
    },
    "aws_cost_export": {
        "label": "AWS Cost Export",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Cost-only partial coverage from approved native export.",
    },
    "aws_guardduty_export": {
        "label": "AWS GuardDuty Export",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Security-only partial coverage from approved native export.",
    },
    "aws_prowler_json_v4": {
        "label": "Prowler JSON v4 (AWS)",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Security-focused partial coverage from approved native export.",
    },
    "aws_prowler_ocsf_json": {
        "label": "Prowler OCSF JSON (AWS)",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Security-focused partial coverage from approved native export (OCSF schema).",
    },
    "azure_defender_summary": {
        "label": "Azure Defender Export",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Partial coverage from approved native export.",
    },
    "azure_advisor_recommendations": {
        "label": "Azure Advisor Export",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Partial coverage from approved native export.",
    },
    "azure_cost_export": {
        "label": "Azure Cost Export",
        "quality": "approved_partial",
        "quality_label": "Approved Fallback",
        "coverage_note": "Cost-only partial coverage from approved native export.",
    },
}


def describe_ingestion_profile(source_type: str, source_detail: str | None = None) -> dict[str, str]:
    normalized_source = str(source_type or "scanresult").strip().lower()
    detail = str(source_detail or "").strip().lower()
    if normalized_source.startswith("scanresult"):
        return {
            "label": "HybriSight CLI Artifact",
            "quality": "canonical_full",
            "quality_label": "Canonical",
            "coverage_note": "Full-fidelity HybriSight artifact. Recommended authoritative input.",
        }
    profile = _NATIVE_EXPORT_PROFILES.get(detail)
    if profile:
        return dict(profile)
    return {
        "label": "Unknown Input Profile",
        "quality": "unknown",
        "quality_label": "Unknown",
        "coverage_note": "Input profile could not be classified. Review upload source selection.",
    }


def build_upload_ingestion_summary(row: Any) -> dict[str, str]:
    profile = describe_ingestion_profile(getattr(row, "source_type", ""), getattr(row, "source_detail", None))
    return {
        "source_type": str(getattr(row, "source_type", "") or ""),
        "source_detail": str(getattr(row, "source_detail", "") or ""),
        **profile,
    }
