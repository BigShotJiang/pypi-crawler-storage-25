# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
import os
import traceback
from contextlib import asynccontextmanager
from typing import Any

import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from starlette.middleware.sessions import SessionMiddleware

from hybrisight.engine import save_html_report, save_pdf_ready_summary
from hybrisight.web import db as web_db
from hybrisight.web.app_session import (
    ensure_csrf_session,
    get_theme,
    normalized_tenant_status,
    optional_user_from_session,
    tenant_is_active,
    tenant_state_message,
    validate_csrf,
)
from hybrisight.web.app_home import render_app_home, render_landing_home, render_public_home, render_share_view
from hybrisight.web.app_internal_ops import (
    DEFAULT_EXECUTION_WIP_LIMIT,
    EXECUTION_PHASE_LABELS,
    EXECUTION_STATUSES,
    EXECUTION_WIP_LIMIT_SETTING_KEY,
    INTERNAL_RULE_TOGGLE_KEY_PREFIX,
    effective_internal_ops_allowlist,
    enforce_internal_ops_access,
    internal_ops_pending_count,
    internal_ops_root_tenant_slug,
    internal_rule_setting_key,
    is_valid_company_name,
    is_valid_email,
    load_lockstep_health,
    parse_bool_like,
    sanitize_onboarding_reason,
    show_internal_ops_nav,
    slugify_tenant_slug,
    validate_tenant_password,
)
from hybrisight.web.app_key_helpers import create_api_key_row, get_api_key_actor as _get_api_key_actor, tenant_api_key_or_404
from hybrisight.web.app_paths import cli_info, ensure_pdf_renderer_available, env_bool, resolve_frontend_dist_dir, resolve_project_root, resolve_static_dir
from hybrisight.web.app_requests import build_audit_middleware, frontend_asset_urls, get_client_ip, hash_token, log_event, log_route_registry_check
from hybrisight.web.app_security_posture import security_posture_checks
from hybrisight.web.auth import generate_totp_secret, get_session_secret, hash_password, needs_password_rehash, verify_password, verify_totp_code
from hybrisight.web.auth_routes import register_auth_routes
from hybrisight.web.auth_reset_routes import register_auth_reset_routes
from hybrisight.web.docs_routes import register_docs_routes
from hybrisight.web.baseline_tenant_routes import router as baseline_tenant_router
from hybrisight.web.auth import has_role
from hybrisight.web.bootstrap import ensure_bootstrap_data
from hybrisight.web.constants import PRODUCT_TAXONOMY
from hybrisight.web.engagement_routes import register_engagement_routes
from hybrisight.web.execution_board_playbooks import json_list as _json_list, parse_json_list as _parse_json_list
from hybrisight.web.execution_board_routes import register_execution_board_routes
from hybrisight.web.internal_ops_api_routes import register_internal_ops_api_routes
from hybrisight.web.internal_ops_page_routes import register_internal_ops_page_routes
from hybrisight.web.key_management_routes import register_key_management_routes
from hybrisight.web.logging_config import configure_logging
from hybrisight.web.models import ApiKey, ExecutionTicket, ScanUpload, Tenant, User
from hybrisight.web.notifications import (
    deliver_contact_feedback_notifications,
    send_onboarding_request_notification,
    send_ticket_blocked_notification,
    send_upload_summary_notification,
)
from hybrisight.web.public_routes import register_public_routes
from hybrisight.web.remediation_playbook_routes import register_remediation_playbook_routes
from hybrisight.web.route_helpers import build_execution_progress, parse_optional_signature_file, parse_uploaded_scan_payload, summary_display
from hybrisight.web.scan_job_routes import register_scan_job_routes
from hybrisight.web.schema_migrations import ensure_schema_ready
from hybrisight.web.security import sign_command_payload, verify_command_payload_signature
from hybrisight.web.reassessment_series import continuity_context_payload
from hybrisight.web.service import build_dashboard_payload, delete_artifact, enforce_rate_limit, infer_native_export_type, normalize_native_export, safe_store_artifact, validate_scan_payload, validate_upload_basics, verify_signature_status
from hybrisight.web.service_ingestion_policy import build_upload_ingestion_summary
from hybrisight.web.service_signature import extract_signature_metadata
from hybrisight.web.trend_analysis import build_trend_summary
from hybrisight.web.share_token_routes import register_share_token_routes
from hybrisight.web.upload_reporting_routes import register_upload_reporting_routes
from hybrisight.web.retainer_routes import register_retainer_routes

logger = logging.getLogger(__name__)
configure_logging()
web_db.reconfigure_from_env()
Base = web_db.Base
SessionLocal = web_db.SessionLocal
engine = web_db.engine
get_db = web_db.get_db

STATIC_DIR = resolve_static_dir()
FRONTEND_DIST_DIR = resolve_frontend_dist_dir()
FAVICON_PATH = STATIC_DIR / "favicon.ico"
LOGIN_MAX_FAILED_ATTEMPTS = max(3, int(os.getenv("HYBRISIGHT_WEB_LOGIN_MAX_ATTEMPTS", "5")))
LOGIN_LOCKOUT_MINUTES = max(1, int(os.getenv("HYBRISIGHT_WEB_LOGIN_LOCKOUT_MINUTES", "15")) )


def theme_phase_map(roadmap: dict[str, Any]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for phase in ("30_days", "60_days", "90_days"):
        for item in roadmap.get(phase, []) if isinstance(roadmap.get(phase, []), list) else []:
            if isinstance(item, dict):
                theme = str(item.get("theme") or "").strip()
                if theme and theme not in mapping:
                    mapping[theme] = phase
    return mapping


def execution_ticket_title(theme: str, rule_title: str) -> str:
    return f"{theme.strip() or 'Unmapped Theme'}: {rule_title.strip() or 'Remediation Task'}"[:255]


@asynccontextmanager
async def lifespan(app: FastAPI):
    ensure_schema_ready(
        database_url=web_db.DATABASE_URL,
        auto_migrate=env_bool("HYBRISIGHT_WEB_AUTO_MIGRATE", False),
    )
    with SessionLocal() as db:
        ensure_bootstrap_data(db)
    log_route_registry_check(app, internal_ops_root_tenant_slug=internal_ops_root_tenant_slug(), internal_ops_allowlist_count=len(effective_internal_ops_allowlist(env_bool)), internal_ops_key_enforced=env_bool("HYBRISIGHT_INTERNAL_OPS_KEY_ENFORCED", False))
    yield


app = FastAPI(title="HybriSight Web", version="0.2.0", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(SessionMiddleware, secret_key=get_session_secret(), same_site="strict", https_only=env_bool("HYBRISIGHT_WEB_HTTPS_ONLY", False), session_cookie="hybrisight_session")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
if FRONTEND_DIST_DIR.exists():
    app.mount("/ui-static", StaticFiles(directory=str(FRONTEND_DIST_DIR)), name="ui_static")
app.middleware("http")(build_audit_middleware(SessionLocal=SessionLocal, enforce_rate_limit=enforce_rate_limit))


@app.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/app", response_class=HTMLResponse)
def home(request: Request, db: Session = Depends(get_db)) -> HTMLResponse:
    return render_app_home(request=request, db=db, ensure_csrf_session=ensure_csrf_session, frontend_asset_urls=lambda: frontend_asset_urls(FRONTEND_DIST_DIR), show_internal_ops_nav=lambda user: show_internal_ops_nav(user, SessionLocal, env_bool), internal_ops_pending_count=lambda user: internal_ops_pending_count(user, SessionLocal, env_bool), cli_info=cli_info, get_theme=get_theme, tenant_is_active=tenant_is_active)


@app.get("/share/{token}", response_class=HTMLResponse)
def shared_report_view(token: str, request: Request) -> HTMLResponse:
    return render_share_view(request=request, token=token, ensure_csrf_session=ensure_csrf_session, frontend_asset_urls=lambda: frontend_asset_urls(FRONTEND_DIST_DIR), get_theme=get_theme)


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
    user_id = request.session.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid session")
    tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
    if tenant is None:
        raise HTTPException(status_code=401, detail="Invalid session tenant")
    if not tenant_is_active(tenant):
        request.session.clear()
        raise HTTPException(status_code=403, detail=tenant_state_message(tenant))
    return user


def require_role(required_role: str):
    def _check(user: User = Depends(get_current_user)) -> User:
        if not has_role(user.role, required_role):
            raise HTTPException(status_code=403, detail="Insufficient role")
        return user

    return _check


def get_api_key_actor(request: Request, db: Session = Depends(get_db)) -> tuple[ApiKey, Tenant, bool]:
    return _get_api_key_actor(db, request.headers.get("X-HybriSight-Api-Key"), tenant_is_active, tenant_state_message)


# Route module registrations
register_public_routes(
    app,
    get_db=get_db,
    optional_user_from_session=optional_user_from_session,
    tenant_is_active=tenant_is_active,
    validate_csrf=validate_csrf,
    is_valid_email=is_valid_email,
    deliver_contact_feedback_notifications=deliver_contact_feedback_notifications,
    favicon_path=FAVICON_PATH,
    render_landing_home=lambda request: render_landing_home(
        request=request,
        ensure_csrf_session=ensure_csrf_session,
        frontend_asset_urls=lambda: frontend_asset_urls(FRONTEND_DIST_DIR, entry_name="landing.html"),
        get_theme=get_theme,
    ),
    render_public_home=lambda request, page: render_public_home(
        request=request,
        ensure_csrf_session=ensure_csrf_session,
        frontend_asset_urls=lambda: frontend_asset_urls(FRONTEND_DIST_DIR, entry_name="landing.html"),
        get_theme=get_theme,
        page=page,
    ),
)
register_execution_board_routes(app, get_db=get_db, require_role=require_role, validate_csrf=validate_csrf, log_event=log_event, execution_phase_labels=EXECUTION_PHASE_LABELS, execution_statuses=EXECUTION_STATUSES, execution_wip_limit_setting_key=EXECUTION_WIP_LIMIT_SETTING_KEY, default_execution_wip_limit=DEFAULT_EXECUTION_WIP_LIMIT, theme_phase_map=theme_phase_map, execution_ticket_title=execution_ticket_title, notify_ticket_blocked=send_ticket_blocked_notification)
register_remediation_playbook_routes(app, get_db=get_db, require_role=require_role, enforce_internal_ops_access=lambda request, user: enforce_internal_ops_access(request, user, SessionLocal, env_bool), validate_csrf=validate_csrf, parse_json_list=_parse_json_list, json_list=_json_list)
register_auth_routes(app, get_db=get_db, get_current_user=get_current_user, require_role=require_role, validate_csrf=validate_csrf, log_event=log_event, slugify_tenant_slug=slugify_tenant_slug, is_valid_company_name=is_valid_company_name, is_valid_email=is_valid_email, validate_tenant_password=validate_tenant_password, tenant_is_active=tenant_is_active, tenant_state_message=tenant_state_message, normalized_tenant_status=normalized_tenant_status, hash_password=hash_password, verify_password=verify_password, needs_password_rehash=needs_password_rehash, generate_totp_secret=generate_totp_secret, verify_totp_code=verify_totp_code, login_max_failed_attempts=LOGIN_MAX_FAILED_ATTEMPTS, login_lockout_minutes=LOGIN_LOCKOUT_MINUTES, send_onboarding_request_notification=send_onboarding_request_notification)
register_auth_reset_routes(app, get_db=get_db, hash_password=hash_password, is_valid_email=is_valid_email, validate_tenant_password=validate_tenant_password, render_public_home=lambda request, page, **kw: render_public_home(request=request, page=page, ensure_csrf_session=ensure_csrf_session, frontend_asset_urls=lambda: frontend_asset_urls(FRONTEND_DIST_DIR), get_theme=get_theme))
register_key_management_routes(app, get_db=get_db, require_role=require_role, validate_csrf=validate_csrf, log_event=log_event, show_internal_ops_nav=lambda user: show_internal_ops_nav(user, SessionLocal, env_bool), security_posture_checks=security_posture_checks, create_api_key_row=create_api_key_row, tenant_api_key_or_404=tenant_api_key_or_404, get_api_key_actor=get_api_key_actor)
register_docs_routes(app, get_db=get_db, require_role=require_role)
register_upload_reporting_routes(app, get_db=get_db, require_role=require_role, validate_csrf=validate_csrf, log_event=log_event, parse_uploaded_scan_payload=lambda payload_text, source_type, provider, export_type: parse_uploaded_scan_payload(payload_text, source_type, provider, export_type, validate_scan_payload=validate_scan_payload, infer_native_export_type=infer_native_export_type, normalize_native_export=normalize_native_export), parse_optional_signature_file=lambda signature_file: parse_optional_signature_file(signature_file, validate_upload_basics=validate_upload_basics), verify_signature_status=verify_signature_status, validate_upload_basics=validate_upload_basics, validate_scan_payload=validate_scan_payload, safe_store_artifact=safe_store_artifact, delete_artifact=delete_artifact, save_pdf_ready_summary=save_pdf_ready_summary, save_html_report=save_html_report, build_dashboard_payload=build_dashboard_payload, build_trend_summary=lambda db, tenant_id, upload, current_result: build_trend_summary(db, tenant_id, upload, current_result, scan_upload_model=ScanUpload, validate_scan_payload=validate_scan_payload), summary_display=summary_display, build_execution_progress=lambda db, tenant_id, upload_id: build_execution_progress(db, tenant_id, upload_id, execution_ticket_model=ExecutionTicket, phase_labels=EXECUTION_PHASE_LABELS, execution_statuses=EXECUTION_STATUSES), taxonomy=PRODUCT_TAXONOMY, notify_upload_summary=send_upload_summary_notification)
register_share_token_routes(app, get_db=get_db, require_role=require_role, validate_csrf=validate_csrf, log_event=log_event, validate_scan_payload=validate_scan_payload, build_dashboard_payload=build_dashboard_payload, build_trend_summary=lambda db, tenant_id, upload, current_result: build_trend_summary(db, tenant_id, upload, current_result, scan_upload_model=ScanUpload, validate_scan_payload=validate_scan_payload), build_execution_progress=lambda db, tenant_id, upload_id: build_execution_progress(db, tenant_id, upload_id, execution_ticket_model=ExecutionTicket, phase_labels=EXECUTION_PHASE_LABELS, execution_statuses=EXECUTION_STATUSES), summary_display=summary_display, build_upload_ingestion_summary=build_upload_ingestion_summary, continuity_context_payload=continuity_context_payload, extract_signature_metadata=extract_signature_metadata)
register_scan_job_routes(app, get_db=get_db, require_role=require_role, validate_csrf=validate_csrf, log_event=log_event, sign_command_payload=sign_command_payload, verify_command_payload_signature=verify_command_payload_signature, validate_upload_basics=validate_upload_basics, validate_scan_payload=validate_scan_payload, parse_optional_signature_file=lambda signature_file: parse_optional_signature_file(signature_file, validate_upload_basics=validate_upload_basics), verify_signature_status=verify_signature_status, safe_store_artifact=safe_store_artifact, tenant_is_active=tenant_is_active, tenant_state_message=tenant_state_message, get_api_key_actor=get_api_key_actor, hash_token=hash_token)
register_internal_ops_api_routes(app, get_db=get_db, require_role=require_role, enforce_internal_ops_access=lambda request, user: enforce_internal_ops_access(request, user, SessionLocal, env_bool), security_posture_checks=security_posture_checks, load_lockstep_health=lambda: load_lockstep_health(resolve_project_root), validate_csrf=validate_csrf, parse_bool_like=parse_bool_like, internal_rule_setting_key=internal_rule_setting_key, internal_rule_toggle_key_prefix=INTERNAL_RULE_TOGGLE_KEY_PREFIX, sanitize_onboarding_reason=sanitize_onboarding_reason, normalized_tenant_status=normalized_tenant_status, get_client_ip=get_client_ip, log_event=log_event)
register_internal_ops_page_routes(app, get_db=get_db, require_role=require_role, enforce_internal_ops_access=lambda request, user: enforce_internal_ops_access(request, user, SessionLocal, env_bool), validate_csrf=validate_csrf, normalized_tenant_status=normalized_tenant_status, sanitize_onboarding_reason=sanitize_onboarding_reason, slugify_tenant_slug=slugify_tenant_slug, is_valid_company_name=is_valid_company_name, is_valid_email=is_valid_email, validate_tenant_password=validate_tenant_password, hash_password=hash_password, get_client_ip=get_client_ip, log_event=log_event)
app.include_router(baseline_tenant_router)
register_engagement_routes(app, get_db=get_db, require_role=require_role, enforce_internal_ops_access=lambda request, user: enforce_internal_ops_access(request, user, SessionLocal, env_bool), validate_csrf=validate_csrf, log_event=log_event)
register_retainer_routes(app, get_db=get_db, require_role=require_role)


def run() -> None:
    debug_traceback = env_bool("HYBRISIGHT_WEB_DEBUG_TRACEBACK", False)
    try:
        get_session_secret()
        ensure_pdf_renderer_available()
    except RuntimeError as exc:
        logger.error("Startup preflight failed: %s", exc)
        logger.error("HINT: Set required env vars, for example:")
        logger.error('HINT: export HYBRISIGHT_WEB_SESSION_SECRET="$(openssl rand -hex 32)"')
        logger.error('HINT: export HYBRISIGHT_WEB_COMMAND_SIGNING_KEY="$(openssl rand -hex 32)"')
        logger.error("HINT: Ensure PDF export dependencies are installed (default package includes WeasyPrint).")
        logger.error("HINT: If running from source, reinstall with: pip install .")
        raise SystemExit(1)
    try:
        uvicorn.run("hybrisight.web.app:app", host="0.0.0.0", port=8080, reload=False)
    except KeyboardInterrupt:
        logger.info("Shutdown requested.")
        raise SystemExit(0)
    except Exception as exc:
        logger.error("Hybrisight Web failed to start: %s", exc)
        logger.error("HINT: Run with HYBRISIGHT_WEB_DEBUG_TRACEBACK=true to include traceback output.")
        if debug_traceback:
            traceback.print_exc()
        raise SystemExit(1)
