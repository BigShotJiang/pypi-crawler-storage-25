# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy.orm import Session

from hybrisight.web.client_journey_schema import ALL_BRANCH_STEP_KEYS, JOURNEY_STAGE_KEYS, stage_step_keys_for_mode
from hybrisight.web.models import ClientJourney, ClientJourneyStage, ClientJourneyStep


def create_client_journey(
    db: Session,
    *,
    journey_type: str,
    journey_status: str = "active",
    delivery_mode: str | None = None,
    package_type: str | None = None,
    tenant_id: int | None = None,
    onboarding_request_id: int | None = None,
    baseline_request_id: int | None = None,
    contact_request_id: int | None = None,
    engagement_id: int | None = None,
    owner_user_id: int | None = None,
    coordinator_user_id: int | None = None,
    internal_notes: str | None = None,
) -> ClientJourney:
    now = datetime.now(UTC)
    journey = ClientJourney(
        journey_type=journey_type,
        journey_status=journey_status,
        delivery_mode=delivery_mode,
        package_type=package_type,
        tenant_id=tenant_id,
        onboarding_request_id=onboarding_request_id,
        baseline_request_id=baseline_request_id,
        contact_request_id=contact_request_id,
        engagement_id=engagement_id,
        owner_user_id=owner_user_id,
        coordinator_user_id=coordinator_user_id,
        current_stage_key=JOURNEY_STAGE_KEYS[0],
        started_at=now,
        internal_notes=internal_notes,
    )
    db.add(journey)
    db.flush()
    _seed_stages_and_steps(db, journey_id=journey.id, delivery_mode=delivery_mode)
    db.flush()
    first_step = (
        db.query(ClientJourneyStep)
        .filter(ClientJourneyStep.journey_id == journey.id, ClientJourneyStep.stage_key == JOURNEY_STAGE_KEYS[0])
        .order_by(ClientJourneyStep.display_order.asc(), ClientJourneyStep.id.asc())
        .first()
    )
    if first_step is not None:
        journey.current_step_key = first_step.step_key
    return journey


def update_client_journey(
    db: Session,
    *,
    journey: ClientJourney,
    delivery_mode: str | None = None,
    package_type: str | None = None,
    owner_user_id: int | None = None,
    coordinator_user_id: int | None = None,
    internal_notes: str | None = None,
    blocked_reason: str | None = None,
) -> ClientJourney:
    if delivery_mode != journey.delivery_mode:
        journey.delivery_mode = delivery_mode
        sync_journey_steps_for_mode(db, journey_id=journey.id, delivery_mode=delivery_mode)
    if package_type is not None:
        journey.package_type = package_type
    if owner_user_id is not None:
        journey.owner_user_id = owner_user_id
    if coordinator_user_id is not None:
        journey.coordinator_user_id = coordinator_user_id
    if internal_notes is not None:
        journey.internal_notes = internal_notes
    if blocked_reason is not None:
        journey.blocked_reason = blocked_reason or None
    refresh_journey_progress(db, journey_id=journey.id)
    db.flush()
    return journey


def update_client_journey_step(
    db: Session,
    *,
    journey: ClientJourney,
    step: ClientJourneyStep,
    status: str | None = None,
    notes: str | None = None,
    blocking: bool | None = None,
    owner_user_id: int | None = None,
    completed_by_user_id: int | None = None,
) -> ClientJourneyStep:
    now = datetime.now(UTC)
    if status is not None:
        step.status = status
        if status == "completed":
            step.completed_at = now
            step.completion_source = "manual"
            step.completed_by_user_id = completed_by_user_id
        elif status != "completed":
            step.completed_at = None
            step.completed_by_user_id = None
    if notes is not None:
        step.notes = notes or None
    if blocking is not None:
        step.blocking = blocking
    if owner_user_id is not None:
        step.owner_user_id = owner_user_id
    refresh_journey_progress(db, journey_id=journey.id)
    db.flush()
    return step
def _seed_stages_and_steps(db: Session, *, journey_id: int, delivery_mode: str | None) -> None:
    for stage_index, stage_key in enumerate(JOURNEY_STAGE_KEYS):
        db.add(
            ClientJourneyStage(
                journey_id=journey_id,
                stage_key=stage_key,
                display_order=stage_index,
                status="in_progress" if stage_index == 0 else "not_started",
            )
        )
        for step_index, step_key in enumerate(stage_step_keys_for_mode(stage_key, delivery_mode)):
            db.add(
                ClientJourneyStep(
                    journey_id=journey_id,
                    stage_key=stage_key,
                    step_key=step_key,
                    display_order=step_index,
                    status="in_progress" if stage_index == 0 and step_index == 0 else "not_started",
                )
            )


def sync_journey_steps_for_mode(db: Session, *, journey_id: int, delivery_mode: str | None) -> None:
    rows = (
        db.query(ClientJourneyStep)
        .filter(ClientJourneyStep.journey_id == journey_id)
        .order_by(ClientJourneyStep.stage_key.asc(), ClientJourneyStep.display_order.asc(), ClientJourneyStep.id.asc())
        .all()
    )
    for stage_key in JOURNEY_STAGE_KEYS:
        desired = stage_step_keys_for_mode(stage_key, delivery_mode)
        stage_rows = [row for row in rows if row.stage_key == stage_key]
        existing_by_key = {row.step_key: row for row in stage_rows}
        for row in stage_rows:
            if row.step_key not in desired and row.step_key in ALL_BRANCH_STEP_KEYS:
                db.delete(row)
        for index, step_key in enumerate(desired):
            row = existing_by_key.get(step_key)
            if row is None:
                db.add(
                    ClientJourneyStep(
                        journey_id=journey_id,
                        stage_key=stage_key,
                        step_key=step_key,
                        display_order=index,
                    )
                )
            else:
                row.display_order = index


def refresh_journey_progress(db: Session, *, journey_id: int) -> None:
    journey = db.query(ClientJourney).filter(ClientJourney.id == journey_id).first()
    if journey is None:
        return
    stages = (
        db.query(ClientJourneyStage)
        .filter(ClientJourneyStage.journey_id == journey_id)
        .order_by(ClientJourneyStage.display_order.asc(), ClientJourneyStage.id.asc())
        .all()
    )
    steps = (
        db.query(ClientJourneyStep)
        .filter(ClientJourneyStep.journey_id == journey_id)
        .order_by(ClientJourneyStep.stage_key.asc(), ClientJourneyStep.display_order.asc(), ClientJourneyStep.id.asc())
        .all()
    )
    steps_by_stage: dict[str, list[ClientJourneyStep]] = {}
    for step in steps:
        steps_by_stage.setdefault(step.stage_key, []).append(step)

    for stage in stages:
        stage_steps = steps_by_stage.get(stage.stage_key, [])
        stage.status = _derive_stage_status(stage_steps)
        if stage.status == "in_progress" and stage.started_at is None:
            stage.started_at = datetime.now(UTC)
        if stage.status == "completed" and stage.completed_at is None:
            stage.completed_at = datetime.now(UTC)
        if stage.status != "completed":
            stage.completed_at = None
        stage.blocked_reason = _derive_stage_blocked_reason(stage_steps)

    journey.journey_status = _derive_journey_status(stages)
    current_stage = next((stage for stage in stages if stage.status not in ("completed", "not_applicable")), stages[-1] if stages else None)
    if current_stage is not None:
        journey.current_stage_key = current_stage.stage_key
        current_steps = steps_by_stage.get(current_stage.stage_key, [])
        current_step = next((step for step in current_steps if step.status not in ("completed", "not_applicable")), current_steps[-1] if current_steps else None)
        journey.current_step_key = current_step.step_key if current_step is not None else None
        journey.blocked_reason = current_stage.blocked_reason
    if journey.journey_status == "completed":
        journey.completed_at = journey.completed_at or datetime.now(UTC)
    elif journey.journey_status != "completed":
        journey.completed_at = None


def _derive_stage_status(steps: list[ClientJourneyStep]) -> str:
    if not steps:
        return "not_started"
    statuses = {step.status for step in steps}
    if "blocked" in statuses or any(step.blocking for step in steps):
        return "blocked"
    if all(status in ("completed", "not_applicable") for status in statuses):
        return "completed"
    if any(status in ("in_progress", "completed") for status in statuses):
        return "in_progress"
    if all(status == "not_applicable" for status in statuses):
        return "not_applicable"
    return "not_started"


def _derive_stage_blocked_reason(steps: list[ClientJourneyStep]) -> str | None:
    blocked = next((step for step in steps if step.status == "blocked" or step.blocking), None)
    return blocked.notes if blocked and blocked.notes else None


def _derive_journey_status(stages: list[ClientJourneyStage]) -> str:
    if not stages:
        return "draft"
    statuses = {stage.status for stage in stages}
    if "blocked" in statuses:
        return "blocked"
    if all(status in ("completed", "not_applicable") for status in statuses):
        return "completed"
    if any(status in ("in_progress", "completed") for status in statuses):
        return "active"
    return "draft"
