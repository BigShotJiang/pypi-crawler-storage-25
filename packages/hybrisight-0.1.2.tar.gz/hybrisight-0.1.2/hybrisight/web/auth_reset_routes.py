# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import secrets
from datetime import UTC, datetime, timedelta
from typing import Any, Callable

from fastapi import Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from hybrisight.web.models import PasswordResetToken, User


def register_auth_reset_routes(
    app: Any,
    *,
    get_db: Callable[..., Session],
    hash_password: Callable[[str], str],
    is_valid_email: Callable[[str], bool],
    validate_tenant_password: Callable[[str], str | None],
    render_public_home: Callable[..., HTMLResponse],
) -> None:
    @app.get("/forgot-password", response_class=HTMLResponse)
    def forgot_password_page(request: Request) -> HTMLResponse:
        return render_public_home(request=request, page="forgot-password")

    @app.post("/api/v1/auth/forgot-password")
    def forgot_password_submit(
        request: Request,
        email: str = Form(""),
        db: Session = Depends(get_db),
    ) -> dict:
        normalized_email = email.strip().lower()
        if not normalized_email or not is_valid_email(normalized_email):
            raise HTTPException(status_code=400, detail="Enter a valid email address.")

        user = db.query(User).filter(User.email == normalized_email).first()
        if user is None:
            return {"ok": True, "message": "If that email is registered, a reset link has been sent."}

        existing = (
            db.query(PasswordResetToken)
            .filter(
                PasswordResetToken.user_id == user.id,
                PasswordResetToken.used == False,
                PasswordResetToken.expires_at > datetime.now(UTC),
            )
            .first()
        )
        if existing is not None:
            return {"ok": True, "message": "If that email is registered, a reset link has been sent."}

        token = secrets.token_urlsafe(48)
        reset_token = PasswordResetToken(
            user_id=user.id,
            token=token,
            expires_at=datetime.now(UTC) + timedelta(hours=1),
        )
        db.add(reset_token)
        db.commit()

        try:
            from hybrisight.web.notifications import _send_email

            _send_email(
                [normalized_email],
                "HybriSight password reset",
                f"A password reset was requested for your HybriSight account.\n\n"
                f"Reset link: {request.base_url}reset-password?token={token}\n\n"
                f"This link expires in 1 hour.\n"
                f"If you did not request this reset, you can safely ignore this email.\n",
            )
        except Exception:
            pass

        return {"ok": True, "message": "If that email is registered, a reset link has been sent."}

    @app.get("/reset-password", response_class=HTMLResponse)
    def reset_password_page(request: Request, token: str = "") -> HTMLResponse:
        return render_public_home(request=request, page="reset-password")

    @app.post("/api/v1/auth/reset-password")
    def reset_password_submit(
        request: Request,
        token: str = Form(""),
        password: str = Form(""),
        db: Session = Depends(get_db),
    ) -> dict:
        if not token.strip():
            raise HTTPException(status_code=400, detail="Reset token is required.")

        reset_token = (
            db.query(PasswordResetToken)
            .filter(
                PasswordResetToken.token == token.strip(),
                PasswordResetToken.used == False,
                PasswordResetToken.expires_at > datetime.now(UTC),
            )
            .first()
        )
        if reset_token is None:
            raise HTTPException(status_code=400, detail="This reset link is invalid or has expired.")

        password_error = validate_tenant_password(password)
        if password_error:
            raise HTTPException(status_code=400, detail=password_error)

        user = db.query(User).filter(User.id == reset_token.user_id).first()
        if user is None:
            raise HTTPException(status_code=400, detail="User not found.")

        user.password_hash = hash_password(password)
        user.failed_login_attempts = 0
        user.login_locked_until = None
        reset_token.used = True
        db.commit()

        return {"ok": True, "message": "Password has been reset. You can now sign in."}

    @app.post("/api/v1/auth/verify-password")
    def verify_password_endpoint(
        request: Request,
        password: str = Form(""),
        db: Session = Depends(get_db),
    ) -> dict:
        from hybrisight.web.auth import verify_password as _verify_password

        user_id = request.session.get("user_id")
        if not user_id:
            raise HTTPException(status_code=401, detail="Not authenticated.")
        user = db.query(User).filter(User.id == user_id).first()
        if user is None:
            raise HTTPException(status_code=401, detail="User not found.")
        if not password.strip():
            raise HTTPException(status_code=400, detail="Password is required.")
        if _verify_password(password, user.password_hash):
            return {"ok": True}
        raise HTTPException(status_code=403, detail="Password is incorrect.")
