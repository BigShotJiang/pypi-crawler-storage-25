# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations
from datetime import UTC, datetime
from typing import Any, Callable

from fastapi import Body, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.engagement_service import (
    ENGAGEMENT_ACCESS_STATES,
    ENGAGEMENT_BILLING_PROVIDERS,
    ENGAGEMENT_DELIVERY_MODES,
    ENGAGEMENT_INVOICE_STATUSES,
    ENGAGEMENT_PACKAGE_TYPES,
    ENGAGEMENT_REPORT_DELIVERY_FORMATS,
    ENGAGEMENT_REPORT_RELEASE_STATES,
    ENGAGEMENT_WORKFLOW_STATES,
    append_engagement_event,
    parse_datetime,
    parse_money,
    serialize_engagement,
    serialize_event,
    normalize_choice,
)
from hybrisight.web.engagement_billing import create_stripe_invoice, stripe_enabled
from hybrisight.web.engagement_policy import enforce_release_gate
from hybrisight.web.engagement_quality import latest_client_upload_quality, resolve_client_tenant
from hybrisight.web.models import Tenant, User
from hybrisight.web.models_engagements import Engagement, EngagementEvent

def register_engagement_routes(app: Any, *, get_db: Callable[..., Any], require_role: Callable[[str], Any], enforce_internal_ops_access: Callable[[Request, User], None], validate_csrf: Callable[[Request, str | None], None], log_event: Callable[..., None]) -> None:
    def _engagement_or_404(db: Session, *, tenant_id: int, engagement_id: int) -> Engagement:
        row = db.query(Engagement).filter(Engagement.id == engagement_id, Engagement.tenant_id == tenant_id).first()
        if row is None:
            raise HTTPException(status_code=404, detail="Engagement not found")
        return row

    @app.get("/api/v1/engagements")
    def list_engagements(request: Request, user: User = Depends(require_role("tenant_admin")), db: Session = Depends(get_db)) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        rows = db.query(Engagement).filter(Engagement.tenant_id == user.tenant_id).order_by(Engagement.updated_at.desc(), Engagement.id.desc()).all()
        return {
            "items": [serialize_engagement(row, latest_client_upload_quality(db, row.client_tenant_id, row.client_name)) for row in rows],
            "workflow_states": list(ENGAGEMENT_WORKFLOW_STATES),
            "package_types": list(ENGAGEMENT_PACKAGE_TYPES),
            "billing_providers": list(ENGAGEMENT_BILLING_PROVIDERS),
            "invoice_statuses": list(ENGAGEMENT_INVOICE_STATUSES),
            "delivery_modes": list(ENGAGEMENT_DELIVERY_MODES),
            "access_states": list(ENGAGEMENT_ACCESS_STATES),
            "report_release_states": list(ENGAGEMENT_REPORT_RELEASE_STATES),
            "report_delivery_formats": list(ENGAGEMENT_REPORT_DELIVERY_FORMATS),
            "stripe_enabled": stripe_enabled(),
            "client_tenants": [{"id": row.id, "name": row.name, "slug": row.slug} for row in db.query(Tenant).order_by(Tenant.name.asc()).limit(200).all()],
        }

    @app.get("/api/v1/engagements/{engagement_id}")
    def get_engagement(engagement_id: int, request: Request, user: User = Depends(require_role("tenant_admin")), db: Session = Depends(get_db)) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        item = _engagement_or_404(db, tenant_id=user.tenant_id, engagement_id=engagement_id)
        events = (
            db.query(EngagementEvent)
            .filter(EngagementEvent.engagement_id == item.id, EngagementEvent.tenant_id == user.tenant_id)
            .order_by(EngagementEvent.created_at.desc(), EngagementEvent.id.desc())
            .all()
        )
        return {"item": serialize_engagement(item, latest_client_upload_quality(db, item.client_tenant_id, item.client_name)), "events": [serialize_event(row) for row in events]}

    @app.post("/api/v1/engagements")
    def create_engagement(request: Request, payload: dict[str, Any] = Body(...), user: User = Depends(require_role("tenant_admin")), db: Session = Depends(get_db)) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))
        title = str(payload.get("title", "")).strip()
        client_name = str(payload.get("client_name", "")).strip()
        if len(title) < 3:
            raise HTTPException(status_code=400, detail="Title must be at least 3 characters")
        if len(client_name) < 2:
            raise HTTPException(status_code=400, detail="Client name must be at least 2 characters")
        client_tenant = resolve_client_tenant(db, payload.get("client_tenant_id"), client_name)
        try:
            item = Engagement(
                tenant_id=user.tenant_id,
                client_tenant_id=client_tenant.id if client_tenant is not None else None,
                created_by_user_id=user.id,
                title=title[:255],
                client_name=client_name[:255],
                contact_email=str(payload.get("contact_email", "")).strip().lower() or None,
                package_type=normalize_choice(payload.get("package_type"), ENGAGEMENT_PACKAGE_TYPES, field_name="package type"),
                workflow_state=normalize_choice(payload.get("workflow_state") or "lead", ENGAGEMENT_WORKFLOW_STATES, field_name="workflow state"),
                delivery_mode=normalize_choice(payload.get("delivery_mode") or "consultant_led", ENGAGEMENT_DELIVERY_MODES, field_name="delivery mode"),
                access_state=normalize_choice(payload.get("access_state") or "not_provisioned", ENGAGEMENT_ACCESS_STATES, field_name="access state"),
                payment_required_before_release=bool(payload.get("payment_required_before_release", True)),
                billing_provider=normalize_choice(payload.get("billing_provider") or "none", ENGAGEMENT_BILLING_PROVIDERS, field_name="billing provider"),
                invoice_status=normalize_choice(payload.get("invoice_status") or "none", ENGAGEMENT_INVOICE_STATUSES, field_name="invoice status"),
                billing_customer_external_id=str(payload.get("billing_customer_external_id", "")).strip() or None,
                currency=(str(payload.get("currency", "GBP")).strip().upper() or "GBP")[:8],
                fixed_fee_amount=parse_money(payload.get("fixed_fee_amount"), field_name="fixed fee amount"),
                quoted_amount=parse_money(payload.get("quoted_amount"), field_name="quoted amount"),
                paid_amount=parse_money(payload.get("paid_amount"), field_name="paid amount"),
                proposal_sent_at=parse_datetime(payload.get("proposal_sent_at"), field_name="proposal sent time"),
                invoice_issued_at=parse_datetime(payload.get("invoice_issued_at"), field_name="invoice issued time"),
                invoice_paid_at=parse_datetime(payload.get("invoice_paid_at"), field_name="invoice paid time"),
                delivery_due_at=parse_datetime(payload.get("delivery_due_at"), field_name="delivery due time"),
                invoice_external_id=str(payload.get("invoice_external_id", "")).strip() or None,
                invoice_external_url=str(payload.get("invoice_external_url", "")).strip() or None,
                next_step=str(payload.get("next_step", "")).strip() or None,
                notes=str(payload.get("notes", "")).strip() or None,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        db.add(item)
        db.flush()
        db.add(
            append_engagement_event(
                engagement_id=item.id,
                tenant_id=user.tenant_id,
                actor_user_id=user.id,
                event_type="created",
                summary=f"Engagement created in state {item.workflow_state.replace('_', ' ')}",
                detail=item.next_step,
                metadata={"package_type": item.package_type, "billing_provider": item.billing_provider, "delivery_mode": item.delivery_mode, "access_state": item.access_state},
            )
        )
        db.commit()
        db.refresh(item)
        log_event(db, request, event_type="engagement_created", user=user, metadata={"engagement_id": item.id, "workflow_state": item.workflow_state})
        return {"ok": True, "item": serialize_engagement(item)}

    @app.post("/api/v1/engagements/{engagement_id}/state")
    def update_engagement_state(engagement_id: int, request: Request, payload: dict[str, Any] = Body(...), user: User = Depends(require_role("tenant_admin")), db: Session = Depends(get_db)) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))
        item = _engagement_or_404(db, tenant_id=user.tenant_id, engagement_id=engagement_id)
        try:
            next_state = normalize_choice(payload.get("workflow_state"), ENGAGEMENT_WORKFLOW_STATES, field_name="workflow state")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        previous_state = item.workflow_state
        item.workflow_state = next_state
        item.next_step = str(payload.get("next_step", "")).strip() or item.next_step
        note = str(payload.get("note", "")).strip() or None
        db.add(
            append_engagement_event(
                engagement_id=item.id,
                tenant_id=user.tenant_id,
                actor_user_id=user.id,
                event_type="workflow_state_changed",
                summary=f"Workflow moved from {previous_state.replace('_', ' ')} to {next_state.replace('_', ' ')}",
                detail=note,
                metadata={"previous_state": previous_state, "next_state": next_state},
            )
        )
        db.commit()
        db.refresh(item)
        log_event(db, request, event_type="engagement_state_updated", user=user, metadata={"engagement_id": item.id, "previous_state": previous_state, "workflow_state": next_state})
        return {"ok": True, "item": serialize_engagement(item)}

    @app.post("/api/v1/engagements/{engagement_id}/billing")
    def update_engagement_billing(engagement_id: int, request: Request, payload: dict[str, Any] = Body(...), user: User = Depends(require_role("tenant_admin")), db: Session = Depends(get_db)) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))
        item = _engagement_or_404(db, tenant_id=user.tenant_id, engagement_id=engagement_id)
        try:
            client_tenant = resolve_client_tenant(db, payload.get("client_tenant_id"), item.client_name)
            item.billing_provider = normalize_choice(payload.get("billing_provider"), ENGAGEMENT_BILLING_PROVIDERS, field_name="billing provider")
            item.invoice_status = normalize_choice(payload.get("invoice_status"), ENGAGEMENT_INVOICE_STATUSES, field_name="invoice status")
            item.delivery_mode = normalize_choice(payload.get("delivery_mode") or item.delivery_mode, ENGAGEMENT_DELIVERY_MODES, field_name="delivery mode")
            item.access_state = normalize_choice(payload.get("access_state") or item.access_state, ENGAGEMENT_ACCESS_STATES, field_name="access state")
            item.payment_required_before_release = bool(payload.get("payment_required_before_release", item.payment_required_before_release))
            item.client_tenant_id = client_tenant.id if client_tenant is not None else None
            item.billing_customer_external_id = str(payload.get("billing_customer_external_id", "")).strip() or None
            item.fixed_fee_amount = parse_money(payload.get("fixed_fee_amount"), field_name="fixed fee amount")
            item.quoted_amount = parse_money(payload.get("quoted_amount"), field_name="quoted amount")
            item.paid_amount = parse_money(payload.get("paid_amount"), field_name="paid amount")
            item.invoice_issued_at = parse_datetime(payload.get("invoice_issued_at"), field_name="invoice issued time")
            item.invoice_paid_at = parse_datetime(payload.get("invoice_paid_at"), field_name="invoice paid time")
            item.delivery_due_at = parse_datetime(payload.get("delivery_due_at"), field_name="delivery due time")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        item.invoice_external_id = str(payload.get("invoice_external_id", "")).strip() or None
        item.invoice_external_url = str(payload.get("invoice_external_url", "")).strip() or None
        item.currency = (str(payload.get("currency", item.currency)).strip().upper() or "GBP")[:8]
        db.add(
            append_engagement_event(
                engagement_id=item.id,
                tenant_id=user.tenant_id,
                actor_user_id=user.id,
                event_type="billing_updated",
                summary=f"Billing mirror updated via {item.billing_provider}",
                detail=str(payload.get("note", "")).strip() or None,
                metadata={"invoice_status": item.invoice_status, "invoice_external_id": item.invoice_external_id, "delivery_mode": item.delivery_mode, "access_state": item.access_state, "payment_required_before_release": item.payment_required_before_release},
            )
        )
        db.commit()
        db.refresh(item)
        log_event(db, request, event_type="engagement_billing_updated", user=user, metadata={"engagement_id": item.id, "billing_provider": item.billing_provider, "invoice_status": item.invoice_status})
        return {"ok": True, "item": serialize_engagement(item)}

    @app.post("/api/v1/engagements/{engagement_id}/billing/stripe-invoice")
    def create_engagement_stripe_invoice(engagement_id: int, request: Request, payload: dict[str, Any] = Body(...), user: User = Depends(require_role("tenant_admin")), db: Session = Depends(get_db)) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))
        item = _engagement_or_404(db, tenant_id=user.tenant_id, engagement_id=engagement_id)
        if not stripe_enabled():
            raise HTTPException(status_code=400, detail="Stripe billing is not configured")
        if not item.contact_email:
            raise HTTPException(status_code=400, detail="Contact email is required before creating a Stripe invoice")
        amount = item.quoted_amount or item.fixed_fee_amount or parse_money(payload.get("quoted_amount"), field_name="quoted amount")
        if amount is None or amount <= 0:
            raise HTTPException(status_code=400, detail="Quoted amount is required before creating a Stripe invoice")
        try:
            stripe_payload = create_stripe_invoice(
                title=item.title,
                client_name=item.client_name,
                contact_email=item.contact_email,
                amount=amount,
                currency=item.currency,
                engagement_id=item.id,
                tenant_id=item.tenant_id,
                days_until_due=int(payload.get("days_until_due") or 14),
            )
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Stripe invoice creation failed: {exc}") from exc
        item.billing_provider = "stripe"
        item.invoice_status = "issued"
        item.quoted_amount = amount
        item.billing_customer_external_id = str(stripe_payload.get("customer_id", "")).strip() or item.billing_customer_external_id
        item.invoice_external_id = str(stripe_payload.get("invoice_id", "")).strip() or item.invoice_external_id
        item.invoice_external_url = str(stripe_payload.get("invoice_url", "")).strip() or item.invoice_external_url
        if item.invoice_issued_at is None:
            item.invoice_issued_at = datetime.now(UTC)
        db.add(
            append_engagement_event(
                engagement_id=item.id,
                tenant_id=user.tenant_id,
                actor_user_id=user.id,
                event_type="stripe_invoice_created",
                summary="Stripe invoice link created",
                detail=str(payload.get("note", "")).strip() or None,
                metadata={"invoice_external_id": item.invoice_external_id, "billing_customer_external_id": item.billing_customer_external_id},
            )
        )
        db.commit()
        db.refresh(item)
        log_event(db, request, event_type="engagement_stripe_invoice_created", user=user, metadata={"engagement_id": item.id, "invoice_external_id": item.invoice_external_id})
        return {"ok": True, "item": serialize_engagement(item)}

    @app.post("/api/v1/engagements/{engagement_id}/release")
    def update_engagement_release(engagement_id: int, request: Request, payload: dict[str, Any] = Body(...), user: User = Depends(require_role("tenant_admin")), db: Session = Depends(get_db)) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))
        item = _engagement_or_404(db, tenant_id=user.tenant_id, engagement_id=engagement_id)
        try:
            item.report_release_state = normalize_choice(payload.get("report_release_state"), ENGAGEMENT_REPORT_RELEASE_STATES, field_name="report release state")
            item.report_delivery_format = normalize_choice(payload.get("report_delivery_format") or "none", ENGAGEMENT_REPORT_DELIVERY_FORMATS, field_name="report delivery format")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        if item.report_release_state == "released":
            enforce_release_gate(item)
        item.report_delivery_url = str(payload.get("report_delivery_url", "")).strip() or None
        item.report_released_at = parse_datetime(payload.get("report_released_at"), field_name="report released time") if payload.get("report_released_at") not in (None, "") else item.report_released_at
        if item.report_release_state == "released" and item.report_released_at is None:
            item.report_released_at = datetime.now(UTC)
        note = str(payload.get("note", "")).strip() or None
        db.add(
            append_engagement_event(
                engagement_id=item.id,
                tenant_id=user.tenant_id,
                actor_user_id=user.id,
                event_type="report_release_updated",
                summary=f"Report release moved to {item.report_release_state.replace('_', ' ')}",
                detail=note,
                metadata={"report_delivery_format": item.report_delivery_format, "report_delivery_url": item.report_delivery_url},
            )
        )
        db.commit()
        db.refresh(item)
        log_event(db, request, event_type="engagement_report_release_updated", user=user, metadata={"engagement_id": item.id, "report_release_state": item.report_release_state})
        return {"ok": True, "item": serialize_engagement(item)}
