# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from hybrisight.web.internal_ops_page_redirect_routes import register_internal_ops_page_redirect_routes
from hybrisight.web.internal_ops_page_request_routes import register_internal_ops_page_request_routes
from hybrisight.web.internal_ops_page_tenant_routes import register_internal_ops_page_tenant_routes
from hybrisight.web.models import Tenant, User


def register_internal_ops_page_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Any, User], None],
    validate_csrf: Callable[[Any, str | None], None],
    normalized_tenant_status: Callable[[Tenant], str],
    sanitize_onboarding_reason: Callable[[str], str],
    slugify_tenant_slug: Callable[[str], str],
    is_valid_company_name: Callable[[str], bool],
    is_valid_email: Callable[[str], bool],
    validate_tenant_password: Callable[[str], str | None],
    hash_password: Callable[[str], str],
    get_client_ip: Callable[[Any], str | None],
    log_event: Callable[..., None],
) -> None:
    register_internal_ops_page_redirect_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
        validate_csrf=validate_csrf,
        slugify_tenant_slug=slugify_tenant_slug,
        is_valid_company_name=is_valid_company_name,
        is_valid_email=is_valid_email,
        validate_tenant_password=validate_tenant_password,
        hash_password=hash_password,
        log_event=log_event,
    )
    register_internal_ops_page_tenant_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
        validate_csrf=validate_csrf,
        normalized_tenant_status=normalized_tenant_status,
        sanitize_onboarding_reason=sanitize_onboarding_reason,
        get_client_ip=get_client_ip,
        log_event=log_event,
    )
    register_internal_ops_page_request_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
        validate_csrf=validate_csrf,
        sanitize_onboarding_reason=sanitize_onboarding_reason,
        log_event=log_event,
    )
