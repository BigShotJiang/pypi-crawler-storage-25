# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

from hybrisight.continuity_metadata import build_continuity_metadata, continuity_metadata_digest, continuity_metadata_from_result


def continuity_override_fields(
    *,
    engagement_label: str | None = None,
    engagement_key: str | None = None,
    scope_label: str | None = None,
    scope_fingerprint: str | None = None,
    series_label: str | None = None,
    series_key: str | None = None,
    series_cadence: str | None = None,
) -> dict[str, str]:
    values = {
        "engagement_label": (engagement_label or "").strip(),
        "engagement_key": (engagement_key or "").strip(),
        "scope_label": (scope_label or "").strip(),
        "scope_fingerprint": (scope_fingerprint or "").strip(),
        "series_label": (series_label or "").strip(),
        "series_key": (series_key or "").strip(),
        "series_cadence": (series_cadence or "").strip(),
    }
    return {key: value for key, value in values.items() if value}


def continuity_metadata_for_upload(
    result: Any,
    *,
    engagement_label: str | None,
    engagement_key: str | None,
    scope_label: str | None,
    scope_fingerprint: str | None,
    series_label: str | None,
    series_key: str | None,
    series_cadence: str | None,
) -> tuple[dict[str, Any] | None, str | None, str | None]:
    artifact_meta = continuity_metadata_from_result(result)
    has_override = any(value and value.strip() for value in [engagement_label, engagement_key, scope_label, scope_fingerprint, series_label, series_key, series_cadence])
    artifact_digest = continuity_metadata_digest(artifact_meta)
    if not has_override:
        return artifact_meta, ("artifact" if artifact_meta else None), artifact_digest
    identifiers: list[str] = []
    if artifact_meta and isinstance(artifact_meta.get("scope"), dict):
        raw_identifiers = artifact_meta["scope"].get("identifiers")
        if isinstance(raw_identifiers, list):
            identifiers = [str(item) for item in raw_identifiers]
    return (
        build_continuity_metadata(
            provider=result.scanned_provider.value,
            engagement_label=engagement_label or (artifact_meta or {}).get("engagement", {}).get("label"),
            engagement_key=engagement_key or (artifact_meta or {}).get("engagement", {}).get("key"),
            scope_label=scope_label or (artifact_meta or {}).get("scope", {}).get("label"),
            scope_fingerprint=scope_fingerprint or (artifact_meta or {}).get("scope", {}).get("fingerprint"),
            identifiers=identifiers,
            series_label=series_label or (artifact_meta or {}).get("series", {}).get("label"),
            series_key=series_key or (artifact_meta or {}).get("series", {}).get("key"),
            cadence=series_cadence or (artifact_meta or {}).get("series", {}).get("cadence"),
        ),
        "upload_override",
        artifact_digest,
    )
