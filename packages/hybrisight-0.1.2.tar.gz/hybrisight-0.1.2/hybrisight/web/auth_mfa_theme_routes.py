# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import io
from typing import Any, Callable
from urllib.parse import quote

import segno
from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import RedirectResponse, Response
from sqlalchemy.orm import Session

from hybrisight.web.models import User


def register_auth_mfa_theme_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    generate_totp_secret: Callable[[], str],
    verify_totp_code: Callable[[str, str], bool],
    verify_password: Callable[[str, str], bool],
) -> None:
    def _totp_otpauth_uri(*, secret: str, email: str) -> str:
        issuer = 'HybriSight'
        label = quote(f'{issuer}:{email}')
        issuer_param = quote(issuer)
        return f'otpauth://totp/{label}?secret={secret}&issuer={issuer_param}&algorithm=SHA1&digits=6&period=30'

    @app.get('/api/v1/account/mfa/status')
    def account_mfa_status(request: Request, user: User = Depends(require_role('viewer'))) -> dict:
        pending_secret = (request.session.get('pending_mfa_secret') or '').strip()
        if not pending_secret and not user.mfa_enabled:
            pending_secret = generate_totp_secret(); request.session['pending_mfa_secret'] = pending_secret
        otpauth_uri = _totp_otpauth_uri(secret=pending_secret, email=user.email) if not user.mfa_enabled else ''
        return {'enabled': bool(user.mfa_enabled), 'pending_secret': pending_secret if not user.mfa_enabled else '', 'otpauth_uri': otpauth_uri}

    @app.get('/api/v1/account/mfa/qrcode')
    def account_mfa_qrcode(request: Request, user: User = Depends(require_role('viewer'))) -> Response:
        pending_secret = (request.session.get('pending_mfa_secret') or '').strip()
        if user.mfa_enabled:
            raise HTTPException(status_code=400, detail='MFA already enabled for this account')
        if not pending_secret:
            pending_secret = generate_totp_secret(); request.session['pending_mfa_secret'] = pending_secret
        qr = segno.make(_totp_otpauth_uri(secret=pending_secret, email=user.email))
        svg = io.BytesIO(); qr.save(svg, kind='svg', scale=4, border=2, dark='#0f172a', light='#ffffff')
        return Response(content=svg.getvalue(), media_type='image/svg+xml', headers={'Cache-Control': 'no-store'})

    @app.post('/api/v1/account/mfa/enable')
    def account_mfa_enable_api(request: Request, mfa_code: str = Form(''), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        if user.mfa_enabled: return {'ok': True, 'message': 'MFA is already enabled.'}
        pending_secret = (request.session.get('pending_mfa_secret') or '').strip()
        if not pending_secret: raise HTTPException(status_code=400, detail='No pending MFA setup session')
        code = mfa_code.strip()
        if not code: raise HTTPException(status_code=400, detail='Authenticator code is required')
        if not verify_totp_code(pending_secret, code): raise HTTPException(status_code=400, detail='Invalid authenticator code')
        user.mfa_secret = pending_secret; user.mfa_enabled = True; db.commit(); request.session.pop('pending_mfa_secret', None)
        log_event(db, request, event_type='mfa_enabled', user=user, metadata={'user_id': user.id})
        return {'ok': True, 'message': 'MFA enabled successfully.'}

    @app.post('/api/v1/account/mfa/disable')
    def account_mfa_disable_api(request: Request, current_password: str = Form(...), mfa_code: str = Form(''), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        if not user.mfa_enabled: return {'ok': True, 'message': 'MFA is already disabled.'}
        if not verify_password(current_password.strip(), user.password_hash): raise HTTPException(status_code=400, detail='Current password is incorrect')
        code = mfa_code.strip()
        if not code: raise HTTPException(status_code=400, detail='Authenticator code is required')
        secret = (user.mfa_secret or '').strip()
        if not secret or not verify_totp_code(secret, code): raise HTTPException(status_code=400, detail='Invalid authenticator code')
        user.mfa_enabled = False; user.mfa_secret = None; db.commit(); request.session.pop('pending_mfa_secret', None)
        log_event(db, request, event_type='mfa_disabled', user=user, metadata={'user_id': user.id})
        return {'ok': True, 'message': 'MFA disabled.'}

    @app.get('/account/mfa')
    def account_mfa_page(user: User = Depends(require_role('viewer'))) -> RedirectResponse:
        return RedirectResponse(url='/app?page=account', status_code=302)

    @app.post('/account/mfa/enable')
    def account_mfa_enable(request: Request, mfa_code: str = Form(...), csrf_token: str = Form(...), db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        if user.mfa_enabled: return RedirectResponse(url='/app?page=account&message=MFA+is+already+enabled', status_code=302)
        pending_secret = (request.session.get('pending_mfa_secret') or '').strip()
        if not pending_secret: return RedirectResponse(url='/app?page=account&message=No+pending+MFA+setup+session', status_code=302)
        if not verify_totp_code(pending_secret, mfa_code.strip()): return RedirectResponse(url='/app?page=account&message=Invalid+authenticator+code', status_code=302)
        user.mfa_secret = pending_secret; user.mfa_enabled = True; db.commit(); request.session.pop('pending_mfa_secret', None)
        log_event(db, request, event_type='mfa_enabled', user=user, metadata={'user_id': user.id})
        return RedirectResponse(url='/app?page=account&message=MFA+enabled+successfully', status_code=302)

    @app.post('/account/mfa/disable')
    def account_mfa_disable(request: Request, current_password: str = Form(...), mfa_code: str = Form(...), csrf_token: str = Form(...), db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        if not user.mfa_enabled: return RedirectResponse(url='/app?page=account&message=MFA+is+already+disabled', status_code=302)
        if not verify_password(current_password.strip(), user.password_hash): return RedirectResponse(url='/app?page=account&message=Current+password+is+incorrect', status_code=302)
        secret = (user.mfa_secret or '').strip()
        if not secret or not verify_totp_code(secret, mfa_code.strip()): return RedirectResponse(url='/app?page=account&message=Invalid+authenticator+code', status_code=302)
        user.mfa_enabled = False; user.mfa_secret = None; db.commit(); request.session.pop('pending_mfa_secret', None)
        log_event(db, request, event_type='mfa_disabled', user=user, metadata={'user_id': user.id})
        return RedirectResponse(url='/app?page=account&message=MFA+disabled', status_code=302)

    @app.post('/theme')
    def set_theme(request: Request, theme: str = Form(...), csrf_token: str = Form(...)) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        if theme not in {'light', 'dark', 'board'}:
            raise HTTPException(status_code=400, detail='Unsupported theme')
        request.session['theme'] = theme
        referer = request.headers.get('referer') or '/'
        response = RedirectResponse(url=referer, status_code=302)
        response.set_cookie(key='hybrisight_theme', value=theme, max_age=31536000, samesite='lax', path='/')
        return response
