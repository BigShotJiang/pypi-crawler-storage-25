# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
import struct
import time

ROLE_ORDER = {
    "viewer": 10,
    "analyst": 20,
    "tenant_admin": 30,
}

PBKDF2_ALGO = "pbkdf2_sha256"
PBKDF2_ITERATIONS = 310_000
PASSWORD_MAX_LENGTH = 128


def _password_pepper() -> str:
    # Optional server-side secret appended to every password before hashing.
    # CRITICAL: If this is set on a deployment that already has users, ALL logins
    # will fail because existing hashes were computed without a pepper.
    # Do NOT set HYBRISIGHT_WEB_PASSWORD_PEPPER to a non-empty value on a live
    # deployment unless you have implemented a migration to re-hash passwords on
    # first login. See docs/ops/kubernetes-stage-helm.md for full explanation.
    return os.getenv("HYBRISIGHT_WEB_PASSWORD_PEPPER", "")


def _pbkdf2_digest(password: str, salt: str, iterations: int) -> str:
    payload = f"{password}{_password_pepper()}"
    digest = hashlib.pbkdf2_hmac("sha256", payload.encode("utf-8"), salt.encode("utf-8"), iterations)
    return digest.hex()


def hash_password(password: str, salt: str | None = None) -> str:
    if len(password) > PASSWORD_MAX_LENGTH:
        raise ValueError(f"Password must be at most {PASSWORD_MAX_LENGTH} characters.")
    salt = salt or secrets.token_hex(16)
    digest_hex = _pbkdf2_digest(password, salt, PBKDF2_ITERATIONS)
    return f"{PBKDF2_ALGO}${PBKDF2_ITERATIONS}${salt}${digest_hex}"


def verify_password(password: str, password_hash: str) -> bool:
    parts = password_hash.split("$")
    if len(parts) == 4 and parts[0] == PBKDF2_ALGO:
        _, iterations_raw, salt, digest_hex = parts
        try:
            iterations = int(iterations_raw)
        except ValueError:
            return False
        expected = _pbkdf2_digest(password, salt, iterations)
        return secrets.compare_digest(expected, digest_hex)

    return False


def needs_password_rehash(password_hash: str) -> bool:
    parts = password_hash.split("$")
    if len(parts) != 4:
        return True
    if parts[0] != PBKDF2_ALGO:
        return True
    try:
        iterations = int(parts[1])
    except ValueError:
        return True
    return iterations < PBKDF2_ITERATIONS


def generate_totp_secret() -> str:
    raw = secrets.token_bytes(20)
    return base64.b32encode(raw).decode("utf-8").rstrip("=")


def _totp_code(secret: str, for_time: int, *, step_seconds: int = 30, digits: int = 6) -> str:
    padded_secret = secret.upper() + "=" * ((8 - len(secret) % 8) % 8)
    key = base64.b32decode(padded_secret.encode("utf-8"), casefold=True)
    counter = int(for_time // step_seconds)
    msg = struct.pack(">Q", counter)
    digest = hmac.new(key, msg, hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    value = ((digest[offset] & 0x7F) << 24) | ((digest[offset + 1] & 0xFF) << 16) | ((digest[offset + 2] & 0xFF) << 8) | (digest[offset + 3] & 0xFF)
    code = value % (10**digits)
    return str(code).zfill(digits)


def verify_totp_code(secret: str, code: str, *, now: int | None = None, window_steps: int = 1) -> bool:
    cleaned = "".join(ch for ch in code.strip() if ch.isdigit())
    if len(cleaned) != 6:
        return False
    ts = int(now if now is not None else time.time())
    for shift in range(-window_steps, window_steps + 1):
        if hmac.compare_digest(_totp_code(secret, ts + (shift * 30)), cleaned):
            return True
    return False


def current_totp_code(secret: str, *, now: int | None = None) -> str:
    ts = int(now if now is not None else time.time())
    return _totp_code(secret, ts)


def get_session_secret() -> str:
    secret = os.getenv("HYBRISIGHT_WEB_SESSION_SECRET")
    if not secret:
        raise RuntimeError(
            "HYBRISIGHT_WEB_SESSION_SECRET environment variable is not set. "
            "A secure secret is required for production deployments."
        )
    return secret


def has_role(user_role: str, required_role: str) -> bool:
    return ROLE_ORDER.get(user_role, 0) >= ROLE_ORDER.get(required_role, 999)


def generate_csrf_token() -> str:
    return secrets.token_urlsafe(24)
