# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
from typing import Any

SENSITIVE_KEY_MARKERS = {
    "authorization",
    "cookie",
    "set-cookie",
    "password",
    "secret",
    "token",
    "api_key",
    "apikey",
    "api-key",
    "signature",
    "credential",
}


def has_role(role: str, required_role: str) -> bool:
    """Check if a user's role meets the required role, with tenant_admin being the highest."""
    if role == "tenant_admin":
        return True
    return role == required_role


def _is_sensitive_key(key: str) -> bool:
    lowered = key.lower()
    return any(marker in lowered for marker in SENSITIVE_KEY_MARKERS)


def redact_sensitive_data(value: Any, key_hint: str | None = None) -> Any:
    if key_hint and _is_sensitive_key(key_hint):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {k: redact_sensitive_data(v, key_hint=k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_sensitive_data(item, key_hint=key_hint) for item in value]
    return value


def hash_api_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


def generate_api_key() -> str:
    return secrets.token_urlsafe(40)


def _command_signing_key() -> bytes:
    key = os.getenv("HYBRISIGHT_WEB_COMMAND_SIGNING_KEY")
    if not key:
        raise RuntimeError(
            "HYBRISIGHT_WEB_COMMAND_SIGNING_KEY environment variable is not set. "
            "A secure key is required for command signing."
        )
    return key.encode("utf-8")


def sign_command_payload(payload: dict) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hmac.new(_command_signing_key(), canonical, hashlib.sha256).hexdigest()


def verify_command_payload_signature(payload: dict, signature: str) -> bool:
    expected = sign_command_payload(payload)
    return hmac.compare_digest(expected, signature)
