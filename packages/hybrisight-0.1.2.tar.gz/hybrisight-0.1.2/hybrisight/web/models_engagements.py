# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import DateTime, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from hybrisight.web.db import Base


class Engagement(Base):
    __tablename__ = "engagements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    client_tenant_id: Mapped[int | None] = mapped_column(ForeignKey("tenants.id"), index=True, default=None)
    created_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    title: Mapped[str] = mapped_column(String(255), index=True)
    client_name: Mapped[str] = mapped_column(String(255), default="")
    contact_email: Mapped[str | None] = mapped_column(String(255), default=None)
    package_type: Mapped[str] = mapped_column(String(32), index=True, default="baseline")
    workflow_state: Mapped[str] = mapped_column(String(48), index=True, default="lead")
    delivery_mode: Mapped[str] = mapped_column(String(32), index=True, default="consultant_led")
    access_state: Mapped[str] = mapped_column(String(32), index=True, default="not_provisioned")
    payment_required_before_release: Mapped[bool] = mapped_column(default=True)
    billing_provider: Mapped[str] = mapped_column(String(32), default="none")
    invoice_status: Mapped[str] = mapped_column(String(32), index=True, default="none")
    billing_customer_external_id: Mapped[str | None] = mapped_column(String(255), default=None)
    invoice_external_id: Mapped[str | None] = mapped_column(String(255), default=None)
    invoice_external_url: Mapped[str | None] = mapped_column(String(1024), default=None)
    currency: Mapped[str] = mapped_column(String(8), default="GBP")
    fixed_fee_amount: Mapped[float | None] = mapped_column(Numeric(12, 2), default=None)
    quoted_amount: Mapped[float | None] = mapped_column(Numeric(12, 2), default=None)
    paid_amount: Mapped[float | None] = mapped_column(Numeric(12, 2), default=None)
    proposal_sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    invoice_issued_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    invoice_paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    delivery_due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    report_release_state: Mapped[str] = mapped_column(String(32), index=True, default="not_started")
    report_delivery_format: Mapped[str] = mapped_column(String(32), default="none")
    report_delivery_url: Mapped[str | None] = mapped_column(String(1024), default=None)
    report_released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    next_step: Mapped[str | None] = mapped_column(Text, default=None)
    notes: Mapped[str | None] = mapped_column(Text, default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        index=True,
    )


class EngagementEvent(Base):
    __tablename__ = "engagement_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    engagement_id: Mapped[int] = mapped_column(ForeignKey("engagements.id"), index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    event_type: Mapped[str] = mapped_column(String(48), index=True)
    summary: Mapped[str] = mapped_column(String(255), default="")
    detail: Mapped[str | None] = mapped_column(Text, default=None)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
