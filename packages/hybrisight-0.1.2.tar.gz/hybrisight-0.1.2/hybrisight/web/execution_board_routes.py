# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from hybrisight.web.execution_board_evidence_comment_routes import register_execution_board_evidence_comment_routes
from hybrisight.web.execution_board_helpers import _tenant_execution_wip_limit_metadata
from hybrisight.web.execution_board_ticket_routes import register_execution_board_ticket_routes
from hybrisight.web.execution_board_workspace_routes import register_execution_board_workspace_routes


def register_execution_board_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[..., None],
    log_event: Callable[..., None],
    execution_phase_labels: dict[str, str],
    execution_statuses: set[str],
    execution_wip_limit_setting_key: str,
    default_execution_wip_limit: int,
    theme_phase_map: Callable[[dict[str, Any]], dict[str, str]],
    execution_ticket_title: Callable[[str, str], str],
    notify_ticket_blocked: Callable[[str, str, str], bool] | None = None,
) -> None:
    register_execution_board_workspace_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        validate_csrf=validate_csrf,
        log_event=log_event,
        execution_phase_labels=execution_phase_labels,
        execution_statuses=execution_statuses,
        theme_phase_map=theme_phase_map,
        execution_ticket_title=execution_ticket_title,
    )
    register_execution_board_ticket_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        validate_csrf=validate_csrf,
        log_event=log_event,
        execution_phase_labels=execution_phase_labels,
        execution_statuses=execution_statuses,
        execution_wip_limit_setting_key=execution_wip_limit_setting_key,
        default_execution_wip_limit=default_execution_wip_limit,
        tenant_execution_wip_limit_metadata=_tenant_execution_wip_limit_metadata,
        notify_ticket_blocked=notify_ticket_blocked,
    )
    register_execution_board_evidence_comment_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        validate_csrf=validate_csrf,
    )
