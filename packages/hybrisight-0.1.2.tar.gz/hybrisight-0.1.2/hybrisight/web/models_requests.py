# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from hybrisight.web.db import Base


class ClientOnboardingRequest(Base):
    __tablename__ = "client_onboarding_requests"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    company_name: Mapped[str] = mapped_column(String(255), index=True)
    desired_slug: Mapped[str] = mapped_column(String(100), index=True)
    admin_email: Mapped[str] = mapped_column(String(255), index=True)
    admin_password_hash: Mapped[str] = mapped_column(String(512))
    terms_version: Mapped[str] = mapped_column(String(64), default="2026-03-22")
    terms_accepted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    terms_acceptance_ip: Mapped[str | None] = mapped_column(String(100), default=None)
    status: Mapped[str] = mapped_column(String(32), default="pending", index=True)
    reviewed_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    rejection_reason: Mapped[str | None] = mapped_column(String(500), default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)


class BaselineRequest(Base):
    __tablename__ = "baseline_requests"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    company_name: Mapped[str] = mapped_column(String(255), index=True)
    contact_email: Mapped[str] = mapped_column(String(255), index=True)
    full_name: Mapped[str | None] = mapped_column(String(255), default=None)
    role_title: Mapped[str | None] = mapped_column(String(255), default=None)
    cloud_providers: Mapped[str] = mapped_column(String(255), default="aws")
    estimated_monthly_spend_band: Mapped[str] = mapped_column(String(64), default="unknown")
    regulated_environment: Mapped[bool] = mapped_column(Boolean, default=False)
    primary_objective: Mapped[str] = mapped_column(String(64), default="security")
    context_notes: Mapped[str | None] = mapped_column(Text, default=None)
    ops_notification_status: Mapped[str | None] = mapped_column(String(32), default=None)
    ops_notification_error: Mapped[str | None] = mapped_column(Text, default=None)
    requester_notification_status: Mapped[str | None] = mapped_column(String(32), default=None)
    requester_notification_error: Mapped[str | None] = mapped_column(Text, default=None)
    status: Mapped[str] = mapped_column(String(32), default="pending", index=True)
    reviewed_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    rejection_reason: Mapped[str | None] = mapped_column(String(500), default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)


class ContactFeedbackRequest(Base):
    __tablename__ = "contact_feedback_requests"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    full_name: Mapped[str] = mapped_column(String(255), index=True)
    work_email: Mapped[str] = mapped_column(String(255), index=True)
    company_name: Mapped[str | None] = mapped_column(String(255), default=None)
    enquiry_type: Mapped[str] = mapped_column(String(64), default="commercial")
    subject: Mapped[str] = mapped_column(String(255))
    message: Mapped[str] = mapped_column(Text)
    ops_notification_status: Mapped[str | None] = mapped_column(String(32), default=None)
    ops_notification_error: Mapped[str | None] = mapped_column(Text, default=None)
    requester_notification_status: Mapped[str | None] = mapped_column(String(32), default=None)
    requester_notification_error: Mapped[str | None] = mapped_column(Text, default=None)
    status: Mapped[str] = mapped_column(String(32), default="pending", index=True)
    reviewed_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)


class CliDownloadCount(Base):
    __tablename__ = "cli_download_counts"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    script_name: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    count: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC))


class ComplianceLog(Base):
    """High-level compliance event log (GDPR fulfillment, etc)."""

    __tablename__ = "compliance_logs"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    event_type: Mapped[str] = mapped_column(String(120), index=True)
    identifier: Mapped[str] = mapped_column(String(255), index=True)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")
    ip_address: Mapped[str | None] = mapped_column(String(100), default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
