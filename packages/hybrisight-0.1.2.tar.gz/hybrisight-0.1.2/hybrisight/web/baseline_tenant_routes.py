# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import secrets
from datetime import UTC, datetime
from urllib.parse import quote_plus

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from hybrisight.web.app_internal_ops import slugify_tenant_slug
from hybrisight.web.app_key_helpers import create_api_key_row
from hybrisight.web.auth import hash_password
from hybrisight.web.dependencies import get_client_ip, get_db, log_event, require_role
from hybrisight.web.engagement_billing import create_stripe_invoice, stripe_enabled
from hybrisight.web.models import ApiKey, AuditLog, BaselineRequest, ComplianceLog, ScanJobToken, ScanUpload, Tenant, User
from hybrisight.web.models_engagements import Engagement
from hybrisight.web.service_storage import delete_artifact as _delete_artifact

from hybrisight.web.pricing_config import BASELINE_FIXED_FEE_GBP

router = APIRouter(tags=["baseline_tenant"])


def _normalize_cloud_providers(raw: str) -> list[str]:
    return [p.strip() for p in raw.replace(",", " ").split() if p.strip() in {"aws", "azure"}]


def _is_valid_company_name(name: str) -> bool:
    return 2 <= len(name) <= 255


def _is_valid_email(email: str) -> bool:
    return "@" in email and "." in email.split("@")[-1] and len(email) <= 255


def _baseline_success_redirect(
    success_message: str,
    *,
    warning_message: str | None = None,
    provisioned: dict[str, str] | None = None,
) -> RedirectResponse:
    parts = [f"message={quote_plus(success_message)}"]
    if warning_message:
        parts.append(f"warning={quote_plus(warning_message)}")
    if provisioned:
        import json
        parts.append(f"provisioned={quote_plus(json.dumps(provisioned))}")
    return RedirectResponse(url=f"/request-baseline?{'&'.join(parts)}", status_code=302)


@router.post("/request-baseline")
def request_baseline_submit(
    request: Request,
    company_name: str = Form(""),
    contact_email: str = Form(""),
    cloud_provider: str = Form(""),
    estimated_monthly_spend_band: str = Form("unknown"),
    regulated_environment: str = Form("no"),
    primary_objective: str = Form("governance"),
    full_name: str = Form(""),
    role_title: str = Form(""),
    context_notes: str = Form(""),
    csrf_token: str = Form(...),
    db: Session = Depends(get_db),
) -> RedirectResponse:
    from hybrisight.web.app_session import validate_csrf
    validate_csrf(request, csrf_token)

    from hybrisight.web.notifications import send_baseline_provisioned_notification

    normalized_name = company_name.strip()
    normalized_email = contact_email.strip().lower()
    provider_value = cloud_provider.strip().lower()
    if provider_value == "hybrid":
        provider_value = "aws,azure"
    providers = _normalize_cloud_providers(provider_value)
    spend_band = estimated_monthly_spend_band.strip().lower()
    objective = primary_objective.strip().lower()
    regulated = regulated_environment.strip().lower() in {"1", "true", "yes", "y"}
    normalized_full_name = full_name.strip()
    normalized_role_title = role_title.strip()
    normalized_context_notes = context_notes.strip()

    allowed_spend = {"under-5k", "5k-20k", "20k-100k", "100k-plus", "unknown"}
    allowed_objectives = {"security", "cost", "governance", "all_three"}

    if not normalized_name or not normalized_email:
        return RedirectResponse(url="/request-baseline?error=Company+name+and+contact+email+are+required.", status_code=302)
    if not _is_valid_company_name(normalized_name):
        return RedirectResponse(url="/request-baseline?error=Company+name+must+be+between+2+and+255+characters.", status_code=302)
    if not _is_valid_email(normalized_email):
        return RedirectResponse(url="/request-baseline?error=Enter+a+valid+contact+email.", status_code=302)
    if spend_band not in allowed_spend or objective not in allowed_objectives:
        return RedirectResponse(url="/request-baseline?error=Invalid+form+selection.+Refresh+and+submit+again.", status_code=302)

    pending = (
        db.query(BaselineRequest)
        .filter(BaselineRequest.status == "pending", BaselineRequest.contact_email == normalized_email)
        .first()
    )
    if pending is not None:
        return RedirectResponse(url="/request-baseline?error=A+pending+baseline+request+already+exists+for+this+contact+email.", status_code=302)

    baseline = BaselineRequest(
        company_name=normalized_name,
        contact_email=normalized_email,
        full_name=normalized_full_name or None,
        role_title=normalized_role_title or None,
        cloud_providers=providers,
        estimated_monthly_spend_band=spend_band,
        regulated_environment=regulated,
        primary_objective=objective,
        context_notes=normalized_context_notes or None,
        status="pending",
    )
    db.add(baseline)
    db.commit()
    db.refresh(baseline)

    log_event(request, db, event_type="baseline_requested", user=None, metadata={
        "request_id": baseline.id,
        "company_name": normalized_name,
        "contact_email": normalized_email,
        "full_name": normalized_full_name or None,
        "role_title": normalized_role_title or None,
        "cloud_providers": providers,
        "spend_band": spend_band,
        "regulated_environment": regulated,
        "primary_objective": objective,
        "context_notes": normalized_context_notes or None,
    })

    password = secrets.token_urlsafe(18)
    slug = slugify_tenant_slug(normalized_name)
    tenant = Tenant(name=normalized_name, slug=slug)
    db.add(tenant)
    db.flush()

    user = User(
        email=normalized_email,
        password_hash=hash_password(password),
        role="tenant_admin",
        tenant_id=tenant.id,
    )
    db.add(user)
    db.flush()

    api_key_row, api_key_value = create_api_key_row(
        db, user, name="Baseline Self-Serve", scope="scan_job:create"
    )

    engagement = Engagement(
        tenant_id=tenant.id,
        client_tenant_id=tenant.id,
        created_by_user_id=user.id,
        title=f"Baseline Assessment — {normalized_name}",
        client_name=normalized_name,
        contact_email=normalized_email,
        package_type="baseline",
        workflow_state="lead",
        delivery_mode="client_run",
        access_state="provisioned",
        payment_required_before_release=stripe_enabled(),
        billing_provider="stripe" if stripe_enabled() else "none",
        currency="GBP",
        fixed_fee_amount=BASELINE_FIXED_FEE_GBP,
        quoted_amount=BASELINE_FIXED_FEE_GBP,
        report_release_state="not_started",
    )
    db.add(engagement)
    db.flush()

    invoice_url: str | None = None
    if stripe_enabled():
        try:
            invoice = create_stripe_invoice(
                title=f"Baseline Assessment — {normalized_name}",
                client_name=normalized_name,
                contact_email=normalized_email,
                amount=BASELINE_FIXED_FEE_GBP,
                currency="GBP",
                engagement_id=engagement.id,
                tenant_id=tenant.id,
                days_until_due=30,
            )
            engagement.billing_provider = "stripe"
            engagement.billing_customer_external_id = invoice.get("customer_id", "")
            engagement.invoice_external_id = invoice.get("invoice_id", "")
            engagement.invoice_external_url = invoice.get("invoice_url", "")
            engagement.invoice_status = invoice.get("invoice_status", "draft")
            engagement.invoice_issued_at = datetime.now(UTC)
            invoice_url = invoice.get("invoice_url", None)
        except Exception as exc:
            log_event(request, db, event_type="baseline_invoice_failed", user=None, metadata={"error": str(exc)})

    baseline.status = "provisioned"
    baseline.reviewed_at = datetime.now(UTC)
    db.commit()

    log_event(request, db, event_type="baseline_auto_provisioned", user=None, metadata={
        "request_id": baseline.id,
        "company_name": normalized_name,
        "contact_email": normalized_email,
        "tenant_id": tenant.id,
        "user_id": user.id,
        "engagement_id": engagement.id,
    })

    send_baseline_provisioned_notification(
        contact_email=normalized_email,
        company_name=normalized_name,
        login_url="/login",
        api_key=api_key_value,
        invoice_url=invoice_url,
    )

    return _baseline_success_redirect(
        "Your Baseline Assessment is ready.",
        provisioned={
            "email": normalized_email,
            "login_url": "/login",
            "password": password,
            "api_key": api_key_value,
        },
    )


@router.post("/api/v1/tenant/delete")
def delete_tenant_api(
    request: Request,
    csrf_token: str | None = Form(None),
    db: Session = Depends(get_db),
    user: User = Depends(require_role("tenant_admin")),
) -> dict:
    from hybrisight.web.app_session import validate_csrf
    validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))

    tenant_id = user.tenant_id

    uploads = db.query(ScanUpload).filter(ScanUpload.tenant_id == tenant_id).all()
    for upload in uploads:
        _delete_artifact(upload.artifact_path)

    db.query(AuditLog).filter(AuditLog.tenant_id == tenant_id).delete()
    db.query(ApiKey).filter(ApiKey.tenant_id == tenant_id).delete()
    db.query(ScanJobToken).filter(ScanJobToken.tenant_id == tenant_id).delete()
    db.query(ScanUpload).filter(ScanUpload.tenant_id == tenant_id).delete()
    db.query(User).filter(User.tenant_id == tenant_id).delete()

    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    tenant_name = tenant.name if tenant else "Unknown"

    comp_log = ComplianceLog(
        event_type="GDPR_ERASURE_FULFILLED",
        identifier=f"Tenant: {tenant_name} (ID: {tenant_id})",
        ip_address=get_client_ip(request),
        metadata_json=json.dumps({"reason": "User-initiated tenant deletion"}),
    )
    db.add(comp_log)

    db.delete(tenant)
    db.commit()

    try:
        from hybrisight.web.notifications import _ops_recipients, _send_email
        _send_email(
            _ops_recipients(),
            f"HybriSight tenant deleted: {tenant_name}",
            f"Tenant '{tenant_name}' (ID: {tenant_id}) has been self-deleted by {user.email}.\n\n"
            f"All associated data (uploads, users, API keys, audit logs) have been permanently erased.\n"
            f"Compliance event recorded: GDPR_ERASURE_FULFILLED\n\n"
            f"IP address: {get_client_ip(request)}",
        )
    except Exception:
        pass

    request.session.clear()
    return {"ok": True, "message": "Tenant and all associated data has been permanently erased."}
