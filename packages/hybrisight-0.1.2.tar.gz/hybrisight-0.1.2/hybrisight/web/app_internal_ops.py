# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import os
import re
import secrets
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

from fastapi import HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.scoring import SCORING_VERSION
from hybrisight.web.models import AuditLog, BaselineRequest, ClientOnboardingRequest, ContactFeedbackRequest, Tenant, User

EXECUTION_PHASE_LABELS: dict[str, str] = {
    "30_days": "0-30 Days (Urgent)",
    "60_days": "31-60 Days (Tactical)",
    "90_days": "61-90 Days (Strategic)",
}
EXECUTION_WIP_LIMIT_SETTING_KEY = "execution.wip_limit.in_progress"
DEFAULT_EXECUTION_WIP_LIMIT = 6
EXECUTION_STATUSES: set[str] = {"new", "triaged", "in_progress", "blocked", "ready_for_validation", "validated", "deferred", "accepted_risk", "closed"}
INTERNAL_RULE_TOGGLE_KEY_PREFIX = "internal.rule.enabled."


def internal_ops_allowlist() -> set[str]:
    raw = os.getenv("HYBRISIGHT_INTERNAL_OPS_EMAILS", "")
    return {item.strip().lower() for item in raw.split(",") if item.strip()}


def allow_insecure_bootstrap_defaults(env_bool: Any) -> bool:
    env = os.getenv("HYBRISIGHT_ENV", "development").strip().lower()
    default = env not in {"prod", "production"}
    return env_bool("HYBRISIGHT_WEB_ALLOW_INSECURE_BOOTSTRAP_DEFAULTS", default)


def effective_internal_ops_allowlist(env_bool: Any) -> set[str]:
    allowlist = internal_ops_allowlist()
    if allowlist:
        return allowlist
    if allow_insecure_bootstrap_defaults(env_bool):
        bootstrap_admin = os.getenv("HYBRISIGHT_WEB_ADMIN_EMAIL", "shawnthompson66@gmail.com").strip().lower()
        if bootstrap_admin:
            return {bootstrap_admin}
    return set()


def internal_ops_root_tenant_slug() -> str:
    configured = os.getenv("HYBRISIGHT_INTERNAL_OPS_ROOT_TENANT_SLUG")
    if configured and configured.strip():
        return configured.strip()
    return os.getenv("HYBRISIGHT_WEB_DEFAULT_TENANT_SLUG", "default").strip() or "default"


def is_internal_ops_root_tenant(user: User, SessionLocal: Any) -> bool:
    root_slug = internal_ops_root_tenant_slug().lower()
    if not root_slug:
        return False
    try:
        with SessionLocal() as db:
            tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
            return bool(tenant and (tenant.slug or "").strip().lower() == root_slug)
    except Exception:
        return False


def show_internal_ops_nav(user: Any | None, SessionLocal: Any, env_bool: Any) -> bool:
    if user is None or getattr(user, "role", "") != "tenant_admin":
        return False
    if not is_internal_ops_root_tenant(user, SessionLocal):
        return False
    allowlist = effective_internal_ops_allowlist(env_bool)
    return bool(allowlist and str(getattr(user, "email", "")).lower() in allowlist)


def internal_ops_pending_count(user: Any | None, SessionLocal: Any, env_bool: Any) -> int:
    if not show_internal_ops_nav(user, SessionLocal, env_bool):
        return 0
    try:
        with SessionLocal() as db:
            return (
                db.query(ClientOnboardingRequest).filter(ClientOnboardingRequest.status == "pending").count()
                + db.query(BaselineRequest).filter(BaselineRequest.status == "pending").count()
                + db.query(ContactFeedbackRequest).filter(ContactFeedbackRequest.status == "pending").count()
            )
    except Exception:
        return 0


def lockstep_file_path(resolve_project_root: Any) -> Path:
    configured = os.getenv("HYBRISIGHT_LOCKSTEP_FILE")
    if configured:
        return Path(configured).expanduser().resolve()
    project_root = resolve_project_root()
    if project_root:
        candidate = project_root / "governance" / "lockstep.json"
        if candidate.exists():
            return candidate
    cwd = Path.cwd().resolve()
    for base in [cwd, *cwd.parents]:
        candidate = base / "governance" / "lockstep.json"
        if candidate.exists():
            return candidate
    return Path(__file__).resolve().parents[2] / "governance" / "lockstep.json"


def load_lockstep_health(resolve_project_root: Any) -> dict[str, Any]:
    expected = {"schema_version": "1.1", "scoring_version": SCORING_VERSION, "roadmap_model": "theme_grouped_hybrid_v1"}
    path = lockstep_file_path(resolve_project_root)
    if not path.exists():
        return {"file_path": str(path), "status": "missing", "expected": expected, "declared": {}, "checks": {k: False for k in expected}}
    try:
        declared = json.loads(path.read_text())
    except Exception:
        return {"file_path": str(path), "status": "invalid", "expected": expected, "declared": {}, "checks": {k: False for k in expected}}
    checks = {key: str(declared.get(key, "")) == str(expected[key]) for key in expected}
    return {"file_path": str(path), "status": "ok" if all(checks.values()) else "drift", "expected": expected, "declared": declared, "checks": checks}


def enforce_internal_ops_access(request: Request, user: User, SessionLocal: Any, env_bool: Any) -> None:
    if not is_internal_ops_root_tenant(user, SessionLocal):
        raise HTTPException(status_code=404, detail="Not found")
    allowlist = effective_internal_ops_allowlist(env_bool)
    if not allowlist or user.email.lower() not in allowlist:
        raise HTTPException(status_code=404, detail="Not found")
    required_key = (os.getenv("HYBRISIGHT_INTERNAL_OPS_KEY") or "").strip()
    if required_key and env_bool("HYBRISIGHT_INTERNAL_OPS_KEY_ENFORCED", False):
        presented_key = request.headers.get("x-hybrisight-internal-key", "")
        if not secrets.compare_digest(presented_key, required_key):
            raise HTTPException(status_code=404, detail="Not found")


def parse_bool_like(raw: Any, *, default: bool = False) -> bool:
    if isinstance(raw, bool):
        return raw
    if raw is None:
        return default
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def internal_rule_setting_key(rule_id: str) -> str:
    return f"{INTERNAL_RULE_TOGGLE_KEY_PREFIX}{rule_id}"


def slugify_tenant_slug(raw: str) -> str:
    candidate = "".join(ch.lower() if ch.isalnum() else "-" for ch in raw.strip())
    while "--" in candidate:
        candidate = candidate.replace("--", "-")
    return candidate.strip("-")


def sanitize_onboarding_reason(raw: str) -> str:
    return " ".join(raw.strip().split())[:500]


def is_valid_email(value: str) -> bool:
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value.strip()))


def is_valid_company_name(value: str) -> bool:
    cleaned = value.strip()
    return 2 <= len(cleaned) <= 255


def validate_tenant_password(password: str) -> str | None:
    if password != password.strip():
        return "Password cannot start or end with spaces."
    cleaned = password.strip()
    if len(cleaned) > 128:
        return "Password must be at most 128 characters."
    if len(cleaned) < 12:
        return "Password must be at least 12 characters."
    if not any(ch.isalpha() for ch in cleaned):
        return "Password must include at least one letter."
    if not any(ch.isdigit() for ch in cleaned):
        return "Password must include at least one number."
    weak_blocklist = {"password", "password123", "admin123", "123456", "12345678", "qwerty", "letmein", "changeme"}
    if cleaned.lower() in weak_blocklist:
        return "Password is too weak. Choose a stronger passphrase."
    if cleaned.isdigit() or cleaned.isalpha():
        return "Password must combine letters and numbers."
    if any(ch * 4 in cleaned for ch in set(cleaned)):
        return "Password cannot contain repeated characters 4+ times in sequence."
    return None


def normalize_cloud_providers(raw: str) -> str:
    selected = [provider for provider in ("aws", "azure") if provider in raw.lower()]
    return ",".join(selected) if selected else "aws"


def parse_datetime_filter(value: str | None) -> datetime | None:
    raw = (value or "").strip()
    if not raw:
        return None
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        return None
    return parsed.astimezone(UTC).replace(tzinfo=None) if parsed.tzinfo is not None else parsed


def build_internal_ops_audit_view_model(db: Session, **kwargs: Any) -> dict[str, Any]:
    audit_event = kwargs.get("audit_event")
    audit_path = kwargs.get("audit_path")
    audit_tenant = kwargs.get("audit_tenant")
    audit_user_email = kwargs.get("audit_user_email")
    audit_request_id = kwargs.get("audit_request_id")
    audit_from = kwargs.get("audit_from")
    audit_to = kwargs.get("audit_to")
    include_http = bool(kwargs.get("audit_include_http_requests", False))
    limit = max(20, min(int(kwargs.get("audit_limit", 100) or 100), 500))
    page = max(1, int(kwargs.get("audit_page", 1) or 1))

    audit_query = db.query(AuditLog)
    if audit_event and str(audit_event).strip():
        audit_query = audit_query.filter(AuditLog.event_type.ilike(f"%{str(audit_event).strip()}%"))
    if audit_path and str(audit_path).strip():
        audit_query = audit_query.filter(AuditLog.path.ilike(f"%{str(audit_path).strip()}%"))
    if audit_tenant and str(audit_tenant).strip():
        tenant_matches = db.query(Tenant.id).filter((Tenant.name.ilike(f"%{str(audit_tenant).strip()}%")) | (Tenant.slug.ilike(f"%{str(audit_tenant).strip()}%"))).all()
        tenant_ids = [row[0] for row in tenant_matches]
        audit_query = audit_query.filter(AuditLog.tenant_id.in_(tenant_ids)) if tenant_ids else audit_query.filter(AuditLog.id == -1)
    if audit_user_email and str(audit_user_email).strip():
        user_ids = [row[0] for row in db.query(User.id).filter(User.email.ilike(f"%{str(audit_user_email).strip()}%")).all()]
        audit_query = audit_query.filter(AuditLog.user_id.in_(user_ids)) if user_ids else audit_query.filter(AuditLog.id == -1)
    if audit_request_id and str(audit_request_id).strip():
        audit_query = audit_query.filter(AuditLog.metadata_json.ilike(f"%{str(audit_request_id).strip()}%"))

    from_dt = parse_datetime_filter(audit_from)
    to_dt = parse_datetime_filter(audit_to)
    if from_dt is not None:
        audit_query = audit_query.filter(AuditLog.created_at >= from_dt)
    if to_dt is not None:
        audit_query = audit_query.filter(AuditLog.created_at <= to_dt + timedelta(minutes=1))
    if not include_http:
        audit_query = audit_query.filter(AuditLog.event_type != "http_request")

    total = audit_query.count()
    total_pages = max(1, (total + limit - 1) // limit)
    page = min(page, total_pages)
    rows = audit_query.order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).offset((page - 1) * limit).limit(limit).all()
    tenant_labels = {t.id: f"{t.name} ({t.slug})" for t in db.query(Tenant).all()}
    user_labels = {u.id: u.email for u in db.query(User).all()}

    logs = []
    for row in rows:
        request_id = ""
        try:
            meta_obj = json.loads(row.metadata_json or "{}")
            if isinstance(meta_obj, dict):
                request_id = str(meta_obj.get("request_id") or "")
        except Exception:
            pass
        logs.append({"id": row.id, "event_type": row.event_type, "path": row.path, "method": row.method, "tenant": tenant_labels.get(row.tenant_id, "platform"), "user_email": user_labels.get(row.user_id, "system"), "ip_address": row.ip_address or "unknown", "metadata_json": row.metadata_json or "{}", "metadata_preview": (row.metadata_json or "{}")[:160], "request_id": request_id or "—", "created_at": row.created_at.strftime("%Y-%m-%d %H:%M:%S") if row.created_at else ""})

    query_string = urlencode({
        "audit_event": audit_event or "",
        "audit_path": audit_path or "",
        "audit_tenant": audit_tenant or "",
        "audit_user_email": audit_user_email or "",
        "audit_request_id": audit_request_id or "",
        "audit_from": audit_from or "",
        "audit_to": audit_to or "",
        "audit_include_http_requests": "true" if include_http else "false",
        "audit_limit": limit,
    })
    return {
        "audit_logs": logs,
        "audit_filters": {"event": audit_event or "", "path": audit_path or "", "tenant": audit_tenant or "", "user_email": audit_user_email or "", "request_id": audit_request_id or "", "from": audit_from or "", "to": audit_to or "", "limit": limit, "page": page, "include_http_requests": include_http},
        "audit_pagination": {"page": page, "limit": limit, "total": total, "total_pages": total_pages, "has_prev": page > 1, "has_next": page < total_pages, "query_string": query_string},
    }
