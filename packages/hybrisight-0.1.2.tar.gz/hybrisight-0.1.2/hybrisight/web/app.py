# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import importlib
import os
import sys
import traceback
from pathlib import Path

import uvicorn


def _load_local_env() -> None:
    cwd = Path.cwd().resolve()
    for base in (cwd, *cwd.parents):
        env_path = base / ".env"
        if not env_path.exists():
            continue
        for raw_line in env_path.read_text().splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
        return


_load_local_env()

from hybrisight.web import app_factory as _app_factory
from hybrisight.web.app_paths import ensure_pdf_renderer_available as _ensure_pdf_renderer_available
from hybrisight.web.app_paths import resolve_frontend_dist_dir as _resolve_frontend_dist_dir
from hybrisight.web.app_requests import frontend_asset_bundle_info as _frontend_asset_bundle_info
from hybrisight.web.auth import get_session_secret, hash_password
from hybrisight.web.db import DATABASE_URL as _DATABASE_URL
from hybrisight.web.models import (
    ApiKey,
    AuditLog,
    BaselineRequest,
    ClientOnboardingRequest,
    ComplianceLog,
    ContactFeedbackRequest,
    ExecutionTicket,
    RemediationPlaybook,
    ScanJobToken,
    ScanUpload,
    Tenant,
    TenantPlaybookOverride,
    TenantSetting,
    TenantSigningKey,
    TicketComment,
    TicketEvidence,
    User,
)
from hybrisight.web.schema_migrations import alembic_head_revision as _alembic_head_revision
from hybrisight.web.schema_migrations import migrate_to_head as _migrate_to_head

# Re-resolve app wiring on module reload so test env overrides apply.
_app_factory = importlib.reload(_app_factory)

Base = _app_factory.Base
SessionLocal = _app_factory.SessionLocal
app = _app_factory.app
engine = _app_factory.engine
get_db = _app_factory.get_db


def _reset_db() -> None:
    """Wipe all tenant data and re-seed bootstrap defaults. Preserves schema."""
    import importlib
    from hybrisight.web import app_factory as _af
    _af = importlib.reload(_af)
    from hybrisight.web.bootstrap import ensure_bootstrap_data
    from hybrisight.web.models import (
        AuditLog, BaselineRequest, ClientOnboardingRequest, ComplianceLog,
        ContactFeedbackRequest, ExecutionTicket, RemediationPlaybook, ScanJobToken,
        ScanUpload, TenantPlaybookOverride, TenantSetting, TenantSigningKey,
        TicketComment, TicketEvidence, ApiKey,
    )
    from hybrisight.web.db import SessionLocal, initialize_schema

    initialize_schema()
    print(f"[INFO] Database: {_DATABASE_URL}")
    confirm = input("[WARN] This will DELETE all scan uploads, users, and tenant data. Type 'yes' to confirm: ").strip()
    if confirm.lower() != "yes":
        print("[INFO] Aborted.")
        return

    db = SessionLocal()
    try:
        for model in [
            TicketComment, TicketEvidence, ExecutionTicket, RemediationPlaybook,
            TenantPlaybookOverride, ScanJobToken, ApiKey, AuditLog, ComplianceLog,
            ContactFeedbackRequest, BaselineRequest, ClientOnboardingRequest,
            TenantSetting, TenantSigningKey, ScanUpload,
        ]:
            deleted = db.query(model).delete()
            print(f"[INFO] Deleted {deleted} rows from {model.__tablename__}")
        from hybrisight.web.models import User, Tenant
        db.query(User).delete()
        db.query(Tenant).delete()
        db.flush()
        ensure_bootstrap_data(db)
        db.commit()
        print("[INFO] Database reset complete. Bootstrap admin re-seeded.")
    except Exception as exc:
        db.rollback()
        print(f"[ERROR] Reset failed: {exc}")
        raise
    finally:
        db.close()


def run() -> None:
    debug_traceback = _app_factory.env_bool("HYBRISIGHT_WEB_DEBUG_TRACEBACK", False)
    if len(sys.argv) > 1 and sys.argv[1] == "migrate":
        try:
            revision = _migrate_to_head()
            print(f"[INFO] Database migrated to revision: {revision}")
            raise SystemExit(0)
        except Exception as exc:
            print("[ERROR] Hybrisight Web migration failed.")
            print(f"[DETAIL] {exc}")
            if debug_traceback:
                traceback.print_exc()
            raise SystemExit(1)
    if len(sys.argv) > 1 and sys.argv[1] == "reset-db":
        _reset_db()
        raise SystemExit(0)
    try:
        get_session_secret()
        _ensure_pdf_renderer_available()
        frontend_dist = _resolve_frontend_dist_dir()
        landing_bundle = _frontend_asset_bundle_info(frontend_dist, entry_name="landing.html")
        app_bundle = _frontend_asset_bundle_info(frontend_dist, entry_name="index.html")
        print(f"[INFO] Frontend dist: {frontend_dist}")
        print(f"[INFO] Landing bundle: {landing_bundle.get('js_file') or 'missing'}")
        print(f"[INFO] App bundle: {app_bundle.get('js_file') or 'missing'}")
        print(f"[INFO] Database URL: {_DATABASE_URL}")
        print(f"[INFO] Schema head revision: {_alembic_head_revision()}")
    except RuntimeError as exc:
        print("[ERROR] Startup preflight failed.")
        print(f"[DETAIL] {exc}")
        print("[HINT] Set required env vars, for example:")
        print('export HYBRISIGHT_WEB_SESSION_SECRET="$(openssl rand -hex 32)"')
        print('export HYBRISIGHT_WEB_COMMAND_SIGNING_KEY="$(openssl rand -hex 32)"')
        print("[HINT] Ensure PDF export dependencies are installed (default package includes WeasyPrint).")
        print("       If running from source, reinstall with: pip install .")
        raise SystemExit(1)
    try:
        uvicorn.run("hybrisight.web.app:app", host="0.0.0.0", port=8080, reload=False)
    except KeyboardInterrupt:
        print("[INFO] Shutdown requested.")
        raise SystemExit(0)
    except Exception as exc:
        print("[ERROR] Hybrisight Web failed to start.")
        print(f"[DETAIL] {exc}")
        print("[HINT] Run with HYBRISIGHT_WEB_DEBUG_TRACEBACK=true to include traceback output.")
        if debug_traceback:
            traceback.print_exc()
        raise SystemExit(1)


__all__ = [
    "app",
    "run",
    "Base",
    "SessionLocal",
    "engine",
    "get_db",
    "get_session_secret",
    "hash_password",
    "_ensure_pdf_renderer_available",
    "uvicorn",
    "ApiKey",
    "AuditLog",
    "BaselineRequest",
    "ClientOnboardingRequest",
    "ComplianceLog",
    "ContactFeedbackRequest",
    "ExecutionTicket",
    "RemediationPlaybook",
    "ScanJobToken",
    "ScanUpload",
    "Tenant",
    "TenantPlaybookOverride",
    "TenantSetting",
    "TenantSigningKey",
    "TicketComment",
    "TicketEvidence",
    "User",
]
