# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from hybrisight.web.execution_board_playbooks import (
    build_playbook_view as _build_playbook_view,
    json_list as _json_list,
    parse_json_list as _parse_json_list,
    resolve_playbook_for_ticket as _resolve_playbook_for_ticket,
)
from hybrisight.web.models import (
    ExecutionTicket,
    TenantSetting,
    User,
)

# Re-exported for consumers that import from this module
__all__ = [
    "_build_playbook_view",
    "_json_list",
    "_parse_json_list",
    "_resolve_playbook_for_ticket",
]

def _serialize_execution_ticket(
    ticket: ExecutionTicket,
    phase_labels: dict[str, str],
    depends_on: ExecutionTicket | None = None,
    recent_events: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return {
        "id": ticket.id,
        "ticket_code": f"HBS-{ticket.id}",
        "upload_id": ticket.upload_id,
        "origin_upload_id": ticket.origin_upload_id,
        "last_seen_upload_id": ticket.last_seen_upload_id,
        "matched_from_ticket_id": ticket.matched_from_ticket_id,
        "continuity_status": ticket.continuity_status,
        "assessment_scope_id": ticket.assessment_scope_id,
        "reassessment_series_id": ticket.reassessment_series_id,
        "finding_id": ticket.finding_id,
        "title": ticket.title,
        "theme": ticket.theme,
        "phase": ticket.phase,
        "phase_label": phase_labels.get(ticket.phase, ticket.phase),
        "severity": ticket.severity,
        "business_impact": ticket.business_impact,
        "affected_resource_count": ticket.affected_resource_count,
        "occurrence_count": ticket.occurrence_count,
        "status": ticket.status,
        "owner": ticket.owner,
        "due_date": ticket.due_date.isoformat() if ticket.due_date else None,
        "blocked_reason": ticket.blocked_reason,
        "accepted_risk_reason": ticket.accepted_risk_reason,
        "depends_on_ticket_id": ticket.depends_on_ticket_id,
        "depends_on": (
            {
                "id": depends_on.id,
                "ticket_code": f"HBS-{depends_on.id}",
                "title": depends_on.title,
                "status": depends_on.status,
                "resolved": depends_on.status in {"validated", "closed"},
            }
            if depends_on is not None
            else None
        ),
        "lane_order": ticket.lane_order,
        "recent_events": recent_events or [],
        "created_at": ticket.created_at.isoformat(),
        "updated_at": ticket.updated_at.isoformat() if ticket.updated_at else ticket.created_at.isoformat(),
    }


def _next_lane_order(db: Session, tenant_id: int, phase: str, status: str) -> int:
    current = (
        db.query(func.max(ExecutionTicket.lane_order))
        .filter(
            ExecutionTicket.tenant_id == tenant_id,
            ExecutionTicket.phase == phase,
            ExecutionTicket.status == status,
        )
        .scalar()
    )
    if current is None:
        return 1
    return int(current) + 1


def _rebalance_lane_orders(db: Session, tenant_id: int, phase: str, status: str) -> list[ExecutionTicket]:
    lane_rows = (
        db.query(ExecutionTicket)
        .filter(
            ExecutionTicket.tenant_id == tenant_id,
            ExecutionTicket.phase == phase,
            ExecutionTicket.status == status,
        )
        .order_by(ExecutionTicket.lane_order.asc(), ExecutionTicket.created_at.asc(), ExecutionTicket.id.asc())
        .all()
    )
    for idx, item in enumerate(lane_rows, start=1):
        item.lane_order = idx
    return lane_rows

def _tenant_execution_wip_limit_metadata(
    db: Session,
    tenant_id: int,
    setting_key: str,
    default_wip_limit: int,
) -> dict[str, Any]:
    row = (
        db.query(TenantSetting)
        .filter(TenantSetting.tenant_id == tenant_id, TenantSetting.key == setting_key)
        .first()
    )
    if row is None:
        return {
            "wip_limit_in_progress": default_wip_limit,
            "updated_at": None,
            "updated_by": None,
        }
    updated_by = None
    if row.updated_by_user_id:
        user = db.query(User).filter(User.id == row.updated_by_user_id).first()
        if user is not None:
            updated_by = user.email
    try:
        parsed = int((row.value or "").strip())
    except (TypeError, ValueError):
        parsed = default_wip_limit
    return {
        "wip_limit_in_progress": max(1, min(parsed, 50)),
        "updated_at": row.updated_at.isoformat() if row.updated_at else row.created_at.isoformat(),
        "updated_by": updated_by,
    }
