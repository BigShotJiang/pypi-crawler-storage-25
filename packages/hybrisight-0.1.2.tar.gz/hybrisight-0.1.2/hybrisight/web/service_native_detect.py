# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from typing import Any


def _norm_key(item: dict[str, Any], key: str) -> Any:
    key_l = key.lower()
    for candidate, value in item.items():
        if candidate.lower() == key_l:
            return value
    return None


def looks_like_prowler_finding(item: dict[str, Any]) -> bool:
    check_id = _norm_key(item, "CheckID") or _norm_key(item, "CheckId") or _norm_key(item, "check_id")
    status = _norm_key(item, "Status") or _norm_key(item, "status")
    severity = _norm_key(item, "Severity") or _norm_key(item, "severity")
    return bool(check_id and status and severity)


def looks_like_prowler_ocsf_finding(item: dict[str, Any]) -> bool:
    metadata = item.get("metadata") or {}
    product = metadata.get("product") or {}
    if product.get("name") != "Prowler":
        return False
    # OCSF specific fields
    return bool(metadata.get("event_code") and item.get("status_code") and item.get("severity"))


def infer_native_export_type(payload: str) -> tuple[str, str] | None:
    payload = payload.strip()
    if not payload:
        return None

    if payload.startswith("user,") and "mfa_active" in payload.splitlines()[0]:
        return ("aws", "aws_iam_credential_report")
    if payload.startswith("Policies:") or payload.startswith("GroupDetailList:") or payload.startswith("RoleDetailList:") or payload.startswith("UserDetailList:"):
        return ("aws", "aws_iam_authorization_details")
    if "\n" in payload:
        header = payload.splitlines()[0].lower()
        if "check" in header and "status" in header and ("trusted" in header or "advisor" in header):
            return ("aws", "aws_trusted_advisor_export")
        if "category" in header and "impact" in header and "recommend" in header:
            return ("azure", "azure_advisor_recommendations")
        if "recommend" in header and "resource" in header and "subscription" in header:
            return ("azure", "azure_defender_summary")
        if "costinbillingcurrency" in header or "pretaxcost" in header:
            return ("azure", "azure_cost_export")

    try:
        raw = json.loads(payload)
    except json.JSONDecodeError:
        return None

    if isinstance(raw, dict):
        if any(isinstance(raw.get(key), list) for key in ("Policies", "RoleDetailList", "UserDetailList", "GroupDetailList")):
            return ("aws", "aws_iam_authorization_details")
        if isinstance(raw.get("Findings"), list):
            return ("aws", "aws_security_hub")
        if isinstance(raw.get("checks"), list):
            first = raw["checks"][0] if raw["checks"] else {}
            if isinstance(first, dict) and ("checkId" in first or "check_id" in first or ("name" in first and "status" in first)):
                return ("aws", "aws_trusted_advisor_export")
        if "ResultsByTime" in raw or "rows" in raw:
            return ("aws", "aws_cost_export")
        if isinstance(raw.get("recommendations"), list):
            return ("azure", "azure_defender_summary")
        if isinstance(raw.get("value"), list):
            return ("azure", "azure_advisor_recommendations")
        if isinstance(raw.get("findings"), list):
            first = raw["findings"][0] if raw["findings"] else {}
            if isinstance(first, dict) and {"finding_id", "type", "severity"}.issubset(first.keys()):
                return ("aws", "aws_guardduty_export")
            if isinstance(first, dict) and looks_like_prowler_finding(first):
                return ("aws", "aws_prowler_json_v4")
            if isinstance(first, dict) and looks_like_prowler_ocsf_finding(first):
                return ("aws", "aws_prowler_ocsf_json")
        return None

    if not isinstance(raw, list) or not raw:
        return None
    first = raw[0]
    if not isinstance(first, dict):
        return None

    if "GeneratorId" in first or "ProductArn" in first or "AwsAccountId" in first:
        return ("aws", "aws_security_hub")
    if {"finding_id", "type", "severity"}.issubset(first.keys()):
        return ("aws", "aws_guardduty_export")
    if {"checkId", "status"}.issubset(first.keys()) or {"check_id", "status"}.issubset(first.keys()) or {"name", "status", "category"}.issubset(first.keys()):
        return ("aws", "aws_trusted_advisor_export")
    if looks_like_prowler_finding(first):
        return ("aws", "aws_prowler_json_v4")
    if looks_like_prowler_ocsf_finding(first):
        return ("aws", "aws_prowler_ocsf_json")
    if "recommendationType" in first or "impact" in first:
        return ("azure", "azure_advisor_recommendations")
    if "cost" in first or "Total" in first or "service" in first:
        return ("aws", "aws_cost_export")
    return None
