# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os

from sqlalchemy.orm import Session

from hybrisight.web.auth import hash_password
from hybrisight.web.models import Tenant, User


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _allow_insecure_bootstrap_defaults() -> bool:
    env = os.getenv("HYBRISIGHT_ENV", "development").strip().lower()
    default = env not in {"prod", "production"}
    return _env_bool("HYBRISIGHT_WEB_ALLOW_INSECURE_BOOTSTRAP_DEFAULTS", default)


def _ensure_tenant_user(db: Session, *, tenant_name: str, tenant_slug: str, email: str, password: str, role: str) -> None:
    tenant = db.query(Tenant).filter(Tenant.slug == tenant_slug).first()
    if tenant is None:
        tenant = Tenant(name=tenant_name, slug=tenant_slug)
        db.add(tenant)
        db.flush()
    user = db.query(User).filter(User.email == email).first()
    if user is None:
        db.add(User(email=email, password_hash=hash_password(password), role=role, tenant_id=tenant.id))


def ensure_bootstrap_data(db: Session) -> None:
    tenant_slug = os.getenv("HYBRISIGHT_WEB_DEFAULT_TENANT_SLUG", "default")
    tenant_name = os.getenv("HYBRISIGHT_WEB_DEFAULT_TENANT_NAME", "Default Tenant")
    admin_email_env = os.getenv("HYBRISIGHT_WEB_ADMIN_EMAIL")
    admin_password_env = os.getenv("HYBRISIGHT_WEB_ADMIN_PASSWORD")

    if admin_email_env and not admin_password_env:
        raise RuntimeError("HYBRISIGHT_WEB_ADMIN_PASSWORD must be set when HYBRISIGHT_WEB_ADMIN_EMAIL is provided.")
    if admin_password_env and not admin_email_env:
        raise RuntimeError("HYBRISIGHT_WEB_ADMIN_EMAIL must be set when HYBRISIGHT_WEB_ADMIN_PASSWORD is provided.")

    if admin_email_env and admin_password_env:
        admin_email = admin_email_env
        admin_password = admin_password_env
    elif _allow_insecure_bootstrap_defaults():
        # Dev/test fallback only; never rely on this for production.
        admin_email = "shawnthompson66@gmail.com"
        admin_password = "admin123"
    else:
        raise RuntimeError(
            "Default admin bootstrap is disabled. Set HYBRISIGHT_WEB_ADMIN_EMAIL and "
            "HYBRISIGHT_WEB_ADMIN_PASSWORD before startup."
        )

    tenant = db.query(Tenant).filter(Tenant.slug == tenant_slug).first()
    if tenant is None:
        tenant = Tenant(name=tenant_name, slug=tenant_slug)
        db.add(tenant)
        db.flush()

    user = db.query(User).filter(User.email == admin_email).first()
    if user is None:
        user = User(
            email=admin_email,
            password_hash=hash_password(admin_password),
            role="tenant_admin",
            tenant_id=tenant.id,
        )
        db.add(user)

    seeded_tenant_name = (os.getenv("HYBRISIGHT_WEB_SEEDED_TENANT_NAME") or "").strip()
    seeded_tenant_slug = (os.getenv("HYBRISIGHT_WEB_SEEDED_TENANT_SLUG") or "").strip()
    seeded_admin_email = (os.getenv("HYBRISIGHT_WEB_SEEDED_ADMIN_EMAIL") or "").strip().lower()
    seeded_admin_password = os.getenv("HYBRISIGHT_WEB_SEEDED_ADMIN_PASSWORD") or ""
    if seeded_tenant_name and seeded_tenant_slug and seeded_admin_email and seeded_admin_password:
        _ensure_tenant_user(
            db,
            tenant_name=seeded_tenant_name,
            tenant_slug=seeded_tenant_slug,
            email=seeded_admin_email,
            password=seeded_admin_password,
            role="tenant_admin",
        )

    db.commit()
