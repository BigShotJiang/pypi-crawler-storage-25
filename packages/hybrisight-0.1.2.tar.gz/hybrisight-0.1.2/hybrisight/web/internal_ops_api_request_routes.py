# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Callable

from fastapi import Body, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.models import BaselineRequest, ClientOnboardingRequest, ContactFeedbackRequest, Tenant, User
from hybrisight.web.notifications import send_onboarding_decision_notification

PUBLIC_EMAIL_DOMAINS = {"gmail.com", "googlemail.com", "outlook.com", "hotmail.com", "live.com", "icloud.com", "yahoo.com", "proton.me", "protonmail.com"}
PLACEHOLDER_COMPANY_TOKENS = {"test", "demo", "sample", "acme", "example", "foo", "bar"}


def _baseline_signal(baseline: BaselineRequest) -> tuple[str, list[str]]:
    reasons: list[str] = []
    company_tokens = {token for token in baseline.company_name.lower().replace("-", " ").split() if token}
    email_domain = baseline.contact_email.split("@", 1)[1].lower() if "@" in baseline.contact_email else ""
    if company_tokens & PLACEHOLDER_COMPANY_TOKENS:
        reasons.append("Placeholder or test-like company name")
    if email_domain in PUBLIC_EMAIL_DOMAINS:
        reasons.append("Personal email domain")
    if not (baseline.context_notes or "").strip():
        reasons.append("No free-text context supplied")
    if not (baseline.role_title or "").strip():
        reasons.append("Role/title missing")
    return ("needs_review", reasons) if reasons else ("likely_business", [])


def _serialize_baseline(baseline: BaselineRequest) -> dict[str, Any]:
    signal, reasons = _baseline_signal(baseline)
    return {
        'id': baseline.id,
        'company_name': baseline.company_name,
        'contact_email': baseline.contact_email,
        'full_name': baseline.full_name,
        'role_title': baseline.role_title,
        'cloud_providers': baseline.cloud_providers,
        'estimated_monthly_spend_band': baseline.estimated_monthly_spend_band,
        'regulated_environment': bool(baseline.regulated_environment),
        'primary_objective': baseline.primary_objective,
        'context_notes': baseline.context_notes,
        'ops_notification_status': baseline.ops_notification_status,
        'ops_notification_error': baseline.ops_notification_error,
        'requester_notification_status': baseline.requester_notification_status,
        'requester_notification_error': baseline.requester_notification_error,
        'submission_signal': signal,
        'signal_reasons': reasons,
        'status': baseline.status,
        'created_at': baseline.created_at.isoformat() if baseline.created_at else None,
        'reviewed_at': baseline.reviewed_at.isoformat() if baseline.reviewed_at else None,
        'rejection_reason': baseline.rejection_reason,
    }


def _serialize_contact_request(item: ContactFeedbackRequest) -> dict[str, Any]:
    return {
        "id": item.id,
        "full_name": item.full_name,
        "work_email": item.work_email,
        "company_name": item.company_name,
        "enquiry_type": item.enquiry_type,
        "subject": item.subject,
        "message": item.message,
        "ops_notification_status": item.ops_notification_status,
        "ops_notification_error": item.ops_notification_error,
        "requester_notification_status": item.requester_notification_status,
        "requester_notification_error": item.requester_notification_error,
        "status": item.status,
        "created_at": item.created_at.isoformat() if item.created_at else None,
        "reviewed_at": item.reviewed_at.isoformat() if item.reviewed_at else None,
    }


def register_internal_ops_api_request_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    validate_csrf: Callable[[Request, str | None], None],
    sanitize_onboarding_reason: Callable[[str], str],
    log_event: Callable[..., None],
) -> None:
    @app.get('/api/v1/internal/onboarding')
    def api_internal_onboarding(request: Request, db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        rows = db.query(ClientOnboardingRequest).order_by(ClientOnboardingRequest.created_at.desc()).limit(200).all()
        return {'items': [{'id': r.id, 'company_name': r.company_name, 'desired_slug': r.desired_slug, 'admin_email': r.admin_email, 'terms_version': r.terms_version, 'terms_accepted_at': r.terms_accepted_at.isoformat() if r.terms_accepted_at else None, 'terms_acceptance_ip': r.terms_acceptance_ip, 'status': r.status, 'created_at': r.created_at.isoformat() if r.created_at else None} for r in rows]}

    @app.post('/api/v1/internal/onboarding/{request_id}/approve')
    def api_internal_approve_onboarding(request: Request, request_id: int, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        onboarding = db.query(ClientOnboardingRequest).filter(ClientOnboardingRequest.id == request_id).first()
        if onboarding is None or onboarding.status != 'pending':
            raise HTTPException(status_code=404, detail='Onboarding request not found or already processed')
        if db.query(Tenant).filter(Tenant.slug == onboarding.desired_slug).first() is not None:
            raise HTTPException(status_code=409, detail='Tenant slug already exists')
        if db.query(User).filter(User.email == onboarding.admin_email).first() is not None:
            raise HTTPException(status_code=409, detail='Admin email already exists')

        tenant = Tenant(name=onboarding.company_name, slug=onboarding.desired_slug)
        db.add(tenant)
        db.flush()
        admin_user = User(email=onboarding.admin_email, password_hash=onboarding.admin_password_hash, role='tenant_admin', tenant_id=tenant.id)
        db.add(admin_user)
        onboarding.status = 'approved'
        onboarding.reviewed_by_user_id = user.id
        onboarding.reviewed_at = datetime.now(UTC)
        onboarding.rejection_reason = None
        db.commit()
        log_event(db, request, event_type='onboarding_approved', user=user, metadata={'request_id': onboarding.id, 'tenant_id': tenant.id, 'tenant_slug': tenant.slug, 'admin_email': admin_user.email})
        send_onboarding_decision_notification(admin_user.email, onboarding.company_name, approved=True)
        return {'ok': True, 'id': onboarding.id, 'status': onboarding.status}

    @app.get('/api/v1/internal/baseline')
    def api_internal_baseline_requests(request: Request, db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        rows = db.query(BaselineRequest).order_by(BaselineRequest.created_at.desc()).limit(200).all()
        return {'items': [_serialize_baseline(r) for r in rows]}

    @app.post('/api/v1/internal/baseline/{request_id}/reject')
    def api_internal_reject_legacy_baseline(request: Request, request_id: int, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        baseline = db.query(BaselineRequest).filter(BaselineRequest.id == request_id).first()
        if baseline is None:
            raise HTTPException(status_code=404, detail='Baseline request not found')
        baseline.status = 'rejected'
        baseline.reviewed_by_user_id = user.id
        baseline.reviewed_at = datetime.now(UTC)
        baseline.rejection_reason = sanitize_onboarding_reason(str(payload.get('reason', '')))
        db.commit()
        log_event(db, request, event_type='baseline_rejected_by_operator', user=user, metadata={'request_id': baseline.id, 'company_name': baseline.company_name})
        return {'ok': True, 'id': baseline.id, 'status': baseline.status}

    @app.get('/api/v1/internal/contact')
    def api_internal_contact_requests(request: Request, db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        rows = db.query(ContactFeedbackRequest).order_by(ContactFeedbackRequest.created_at.desc()).limit(200).all()
        return {'items': [_serialize_contact_request(r) for r in rows]}

    @app.post('/api/v1/internal/contact/{request_id}/review')
    def api_internal_review_contact_request(request: Request, request_id: int, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        item = db.query(ContactFeedbackRequest).filter(ContactFeedbackRequest.id == request_id).first()
        if item is None or item.status != 'pending':
            raise HTTPException(status_code=404, detail='Contact request not found or already processed')
        item.status = 'reviewed'
        item.reviewed_by_user_id = user.id
        item.reviewed_at = datetime.now(UTC)
        db.commit()
        log_event(db, request, event_type='contact_feedback_reviewed', user=user, metadata={'request_id': item.id, 'work_email': item.work_email, 'subject': item.subject})
        return {'ok': True, 'id': item.id, 'status': item.status}
