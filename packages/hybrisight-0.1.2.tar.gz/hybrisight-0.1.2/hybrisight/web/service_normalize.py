# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import csv
import json
from datetime import UTC, datetime
from io import StringIO
from typing import Any

import yaml

from hybrisight.engine import apply_scoring
from hybrisight.models import CoverageLevel, Provider, ScanResult, Severity
from hybrisight.web.service_constants import NATIVE_EXPORT_TYPE_ALIASES, UploadValidationError
from hybrisight.web.service_normalize_iam import normalize_iam_authorization_details
from hybrisight.web.service_parse import (
    _sanitize_rule_suffix,
    _finding,
    normalize_prowler_findings,
    normalize_prowler_ocsf_findings,
    summarize_prowler_findings,
    summarize_prowler_ocsf_findings,
    normalize_trusted_advisor_csv,
    normalize_trusted_advisor_items,
    severity_from_text,
)


def _to_float_or_none(value: Any) -> float | None:
    try:
        text = str(value).replace(",", "").strip()
        if not text:
            return None
        return float(text)
    except (TypeError, ValueError):
        return None


def _load_json_or_csv_rows(payload: str) -> tuple[Any | None, list[dict[str, str]]]:
    try:
        return json.loads(payload), []
    except json.JSONDecodeError:
        reader = csv.DictReader(StringIO(payload))
        return None, [dict(row) for row in reader]


def _load_json_or_yaml(payload: str) -> Any:
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        try:
            return yaml.safe_load(payload)
        except yaml.YAMLError as exc:
            raise UploadValidationError(f"Invalid JSON/YAML payload: {exc}") from exc


def _normalize_security_hub_items(data: Any) -> list:
    if isinstance(data, dict):
        if isinstance(data.get("Findings"), list):
            return data["Findings"]
        if isinstance(data.get("Controls"), list):
            return data["Controls"]
        return []
    if isinstance(data, list):
        return data
    return []


def normalize_native_export(provider: str, export_type: str, payload: str) -> ScanResult:
    provider_enum = Provider(provider)
    export_type = str(export_type or "").strip().lower().replace("-", "_")
    export_type = NATIVE_EXPORT_TYPE_ALIASES.get(export_type, export_type)
    generated_at = datetime.now(UTC).isoformat()
    findings = []
    collection_diagnostics: dict[str, Any] | None = None
    if payload.lstrip().startswith("%PDF-"):
        raise UploadValidationError("PDF exports are not supported for native export ingestion. Upload JSON or CSV.")

    if export_type == "aws_security_hub":
        data = _load_json_or_yaml(payload)
        items = _normalize_security_hub_items(data)
        for item in items:
            if not isinstance(item, dict):
                continue
            if item.get("ControlId") or item.get("StandardsControlArn"):
                control_id = str(item.get("ControlId") or item.get("StandardsControlArn") or "CONTROL").strip()
                sev = severity_from_text(item.get("SeverityRating") or item.get("Severity"), fallback=Severity.medium)
                findings.append(_finding(
                    rule_id=f"AWS.SECURITYHUB.CONTROL.{_sanitize_rule_suffix(control_id)}",
                    provider=Provider.aws,
                    service="securityhub",
                    resource_id=str(item.get("StandardsControlArn") or control_id),
                    title=str(item.get("Title", control_id)),
                    category="security",
                    severity=sev,
                    description=str(item.get("Description", "Imported Security Hub control export row.")),
                    business_impact="Imported Security Hub control signal indicates a cloud security posture gap requiring triage.",
                    remediation=str(item.get("RemediationUrl") or "Review the Security Hub control and implement the documented remediation."),
                ))
                continue
            severity_value = item.get("Severity")
            sev = severity_from_text(
                severity_value.get("Label") if isinstance(severity_value, dict) else severity_value,
                fallback=Severity.low,
            )
            findings.append(_finding(
                rule_id=f"AWS.SECURITYHUB.{item.get('GeneratorId', 'GEN').replace(':', '.')}",
                provider=Provider.aws,
                service="securityhub",
                resource_id=str(item.get("Id", "unknown")),
                title=str(item.get("Title", "Security Hub Finding")),
                category="security",
                severity=sev,
                description=str(item.get("Description", "Imported Security Hub finding")),
                business_impact="Imported cloud-native security signal requiring triage.",
                remediation="Review finding details in Security Hub and implement control remediation.",
            ))

    elif export_type in {"aws_cost_export", "azure_cost_export"}:
        data, csv_rows = _load_json_or_csv_rows(payload)
        rows = (data.get("ResultsByTime") or data.get("rows") or []) if isinstance(data, dict) else data if isinstance(data, list) else csv_rows
        total = 0.0
        for row in rows:
            if not isinstance(row, dict):
                continue
            amount = row.get("Total", {}).get("UnblendedCost", {}).get("Amount") if isinstance(row.get("Total"), dict) else None
            amount = amount or row.get("cost") or row.get("CostInBillingCurrency") or row.get("PreTaxCost") or row.get("Cost")
            parsed = _to_float_or_none(amount)
            if parsed is not None:
                total += parsed
        findings.append(_finding(
            rule_id=f"{provider.upper()}.COST.IMPORT.001",
            provider=provider_enum,
            service="cost",
            resource_id="cost-export",
            title="Imported cost management signal",
            category="cost",
            severity=Severity.medium,
            description="Cost export ingested from cloud-native source.",
            business_impact="Cost data indicates optimization opportunities across workload portfolio.",
            remediation="Review top spend drivers and apply rightsizing/scheduling controls.",
            annual_cost=round(total, 2),
        ))

    elif export_type == "aws_guardduty_export":
        data = json.loads(payload)
        items = data if isinstance(data, list) else data.get("findings", []) if isinstance(data, dict) else []
        for item in items:
            if not isinstance(item, dict):
                continue
            sev_num = float(item.get("severity", 1) or 1)
            sev = Severity.high if sev_num >= 7 else Severity.medium if sev_num >= 4 else Severity.low if sev_num >= 1 else Severity.info
            findings.append(_finding(
                rule_id=f"AWS.GUARDDUTY.{str(item.get('type', 'FINDING')).replace(':', '.')}",
                provider=Provider.aws,
                service="guardduty",
                resource_id=str(item.get("finding_id") or item.get("id") or "unknown"),
                title=str(item.get("title") or item.get("type") or "GuardDuty Finding"),
                category="security",
                severity=sev,
                description="Imported GuardDuty finding.",
                business_impact="GuardDuty signal indicates potential malicious activity requiring security triage.",
                remediation="Investigate the finding in GuardDuty and apply containment/remediation controls.",
            ))

    elif export_type == "aws_iam_credential_report":
        reader = csv.DictReader(StringIO(payload))
        if "mfa_active" not in (reader.fieldnames or []):
            raise UploadValidationError(
                "AWS IAM Credential Report must be the native credential report CSV with headers such as user, arn, and mfa_active. "
                "If you exported IAM policies/roles/users instead, choose 'AWS IAM Authorization Details Export'."
            )
        for row in reader:
            if row.get("mfa_active", "true").lower() != "true":
                findings.append(_finding(
                    rule_id="AWS.IAM.CREDREPORT.001",
                    provider=Provider.aws,
                    service="iam",
                    resource_id=row.get("user", "unknown"),
                    title="IAM user without MFA",
                    category="security",
                    severity=Severity.high,
                    description="Credential report shows IAM user without MFA.",
                    business_impact="Increases identity compromise risk for operational accounts.",
                    remediation="Enable MFA for all IAM users or migrate to SSO.",
                ))

    elif export_type == "aws_iam_authorization_details":
        data = _load_json_or_yaml(payload)
        if not isinstance(data, dict) or not any(key in data for key in ("Policies", "RoleDetailList", "UserDetailList", "GroupDetailList")):
            raise UploadValidationError(
                "AWS IAM Authorization Details export must be JSON or YAML containing Policies/RoleDetailList/UserDetailList/GroupDetailList. "
                "If you intended to upload the credential report, choose 'AWS IAM Credential Report (CSV)'."
            )
        findings.extend(normalize_iam_authorization_details(data, finding_builder=_finding, suffix_builder=_sanitize_rule_suffix))

    elif export_type == "azure_defender_summary":
        data, csv_rows = _load_json_or_csv_rows(payload)
        items = data.get("recommendations", data if isinstance(data, list) else []) if data is not None else [{
            "id": row.get("Recommendation ID") or row.get("id") or row.get("recommendation_id") or "REC",
            "resourceId": row.get("Resource ID") or row.get("resourceId") or row.get("resource_id") or "unknown",
            "title": row.get("Recommendation") or row.get("title") or "Defender Recommendation",
            "description": row.get("Description") or row.get("details") or "Imported Defender recommendation",
        } for row in csv_rows]
        for item in items:
            if not isinstance(item, dict):
                continue
            findings.append(_finding(
                rule_id=f"AZURE.DEFENDER.{item.get('id', 'REC')}", provider=Provider.azure, service="defender", resource_id=str(item.get("resourceId", "unknown")),
                title=str(item.get("title", "Defender Recommendation")), category="security", severity=Severity.medium,
                description=str(item.get("description", "Imported Defender recommendation")),
                business_impact="Defender recommendation highlights policy or configuration exposure.", remediation="Implement Defender recommendation and validate control effectiveness.",
            ))

    elif export_type == "azure_advisor_recommendations":
        data, csv_rows = _load_json_or_csv_rows(payload)
        items = data.get("value", data if isinstance(data, list) else []) if data is not None else [{
            "name": row.get("Recommendation ID") or row.get("name") or "REC",
            "id": row.get("Resource ID") or row.get("id") or "unknown",
            "properties": {
                "category": row.get("Category") or row.get("category") or "HighAvailability",
                "shortDescription": {
                    "problem": row.get("Recommendation") or row.get("Problem") or "Advisor Recommendation",
                    "solution": row.get("Description") or row.get("Solution") or "Imported Advisor recommendation",
                },
            },
        } for row in csv_rows]
        for item in items:
            if not isinstance(item, dict):
                continue
            cat = str(item.get("properties", {}).get("category", "HighAvailability")).lower()
            mapped_category = "cost" if cat == "cost" else "resilience"
            findings.append(_finding(
                rule_id=f"AZURE.ADVISOR.{item.get('name', 'REC')}", provider=Provider.azure, service="advisor", resource_id=str(item.get("id", "unknown")),
                title=str(item.get("properties", {}).get("shortDescription", {}).get("problem", "Advisor Recommendation")),
                category=mapped_category, severity=Severity.medium,
                description=str(item.get("properties", {}).get("shortDescription", {}).get("solution", "Imported Advisor recommendation")),
                business_impact="Advisor recommendation indicates improvement opportunity in cloud posture.", remediation="Apply recommendation with workload owner approval.",
            ))

    elif export_type == "aws_prowler_json_v4":
        counts = summarize_prowler_findings(payload)
        findings.extend(normalize_prowler_findings(payload))
        collection_diagnostics = {
            "provider": "aws",
            "summary": {
                "quality": "partial",
                "label": "Approved Fallback",
                "summary": f"Prowler import captured {counts['total']} observed checks; {counts['failed']} failed checks contribute to scoring and prioritization.",
                "observed_checks_total": counts["total"],
                "failed_checks_total": counts["failed"],
                "passed_checks_total": counts["passed"],
                "manual_checks_total": counts["manual"],
            },
        }
    elif export_type == "aws_prowler_ocsf_json":
        counts = summarize_prowler_ocsf_findings(payload)
        findings.extend(normalize_prowler_ocsf_findings(payload))
        collection_diagnostics = {
            "provider": "aws",
            "summary": {
                "quality": "partial",
                "label": "Approved Fallback",
                "summary": f"Prowler import captured {counts['total']} observed checks; {counts['failed']} failed checks contribute to scoring and prioritization.",
                "observed_checks_total": counts["total"],
                "failed_checks_total": counts["failed"],
                "passed_checks_total": counts["passed"],
                "manual_checks_total": counts["manual"],
            },
        }
    elif export_type == "aws_trusted_advisor_export":
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            findings.extend(normalize_trusted_advisor_csv(payload))
        else:
            items = data.get("checks") if isinstance(data, dict) and isinstance(data.get("checks"), list) else data if isinstance(data, list) else []
            findings.extend(normalize_trusted_advisor_items(items))
    else:
        raise UploadValidationError(f"Unsupported native export type: {export_type}")

    result = ScanResult(
        schema_version="1.1",
        coverage_level=CoverageLevel.partial,
        scanned_provider=provider_enum,
        asset_count=0,
        finding_count=int((((collection_diagnostics or {}).get("summary") or {}).get("observed_checks_total")) or len(findings)),
        findings=findings,
        generated_at_utc=generated_at,
        collection_diagnostics=collection_diagnostics,
        signature=None,
    )
    return apply_scoring(result)
