# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import Depends, Form, HTTPException, Request
from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from hybrisight.web.execution_board_playbooks import resolve_ticket_guide
from hybrisight.web.execution_board_route_helpers import ensure_ticket_in_active_workspace
from hybrisight.web.models import ExecutionTicket, TicketComment, TicketEvidence, User
from hybrisight.web.reassessment_series import record_ticket_event


def register_execution_board_evidence_comment_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
) -> None:
    def _ensure_ticket_comments_table(db: Session) -> None:
        bind = db.get_bind()
        with bind.begin() as conn:
            conn.execute(text('CREATE TABLE IF NOT EXISTS ticket_comments (id INTEGER PRIMARY KEY, ticket_id INTEGER NOT NULL, tenant_id INTEGER NOT NULL, comment_text TEXT NOT NULL, created_by_user_id INTEGER, created_at TIMESTAMP)'))
            conn.execute(text('CREATE INDEX IF NOT EXISTS ix_ticket_comments_ticket_id ON ticket_comments (ticket_id)'))
            conn.execute(text('CREATE INDEX IF NOT EXISTS ix_ticket_comments_tenant_id ON ticket_comments (tenant_id)'))
            conn.execute(text('CREATE INDEX IF NOT EXISTS ix_ticket_comments_created_at ON ticket_comments (created_at)'))

    @app.get('/api/v1/execution-tickets/{ticket_id}/remediation-guide')
    def get_execution_ticket_remediation_guide(ticket_id: int, db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        ticket = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if ticket is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, ticket)
        guide, guide_status = resolve_ticket_guide(db, user.tenant_id, ticket)
        return {'ticket_id': ticket.id, 'guide_status': guide_status, 'guide': guide}

    @app.get('/api/v1/execution-tickets/{ticket_id}/evidence')
    def list_execution_ticket_evidence(ticket_id: int, db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        ticket = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if ticket is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, ticket)
        rows = db.query(TicketEvidence).filter(TicketEvidence.ticket_id == ticket.id, TicketEvidence.tenant_id == user.tenant_id).order_by(TicketEvidence.created_at.desc()).all()
        return {'items': [{'id': row.id, 'evidence_key': row.evidence_key, 'evidence_value': row.evidence_value, 'created_at': row.created_at.isoformat()} for row in rows]}

    @app.post('/api/v1/execution-tickets/{ticket_id}/evidence')
    def add_execution_ticket_evidence(ticket_id: int, request: Request, evidence_key: str = Form(...), evidence_value: str = Form(...), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        ticket = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if ticket is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, ticket)
        row = TicketEvidence(ticket_id=ticket.id, tenant_id=user.tenant_id, evidence_key=evidence_key.strip(), evidence_value=evidence_value.strip(), created_by_user_id=user.id)
        db.add(row)
        db.flush()
        record_ticket_event(db, tenant_id=user.tenant_id, ticket_id=ticket.id, upload_id=ticket.upload_id, actor_user_id=user.id, event_type='evidence_added', next_status=ticket.status, next_continuity_status=ticket.continuity_status, details={'evidence_key': row.evidence_key})
        db.commit(); db.refresh(row)
        return {'id': row.id}

    @app.get('/api/v1/execution-tickets/{ticket_id}/comments')
    def list_execution_ticket_comments(ticket_id: int, db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        ticket = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if ticket is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, ticket)
        try:
            rows = db.query(TicketComment).filter(TicketComment.ticket_id == ticket.id, TicketComment.tenant_id == user.tenant_id).order_by(TicketComment.created_at.desc()).all()
        except OperationalError as exc:
            if 'no such table: ticket_comments' not in str(exc).lower(): raise
            _ensure_ticket_comments_table(db)
            rows = db.query(TicketComment).filter(TicketComment.ticket_id == ticket.id, TicketComment.tenant_id == user.tenant_id).order_by(TicketComment.created_at.desc()).all()
        return {'items': [{'id': row.id, 'comment_text': row.comment_text, 'created_at': row.created_at.isoformat()} for row in rows]}

    @app.post('/api/v1/execution-tickets/{ticket_id}/comments')
    def add_execution_ticket_comment(ticket_id: int, request: Request, comment_text: str = Form(...), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        ticket = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if ticket is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, ticket)
        value = comment_text.strip()
        if not value: raise HTTPException(status_code=400, detail='Comment cannot be empty')
        row = TicketComment(ticket_id=ticket.id, tenant_id=user.tenant_id, comment_text=value, created_by_user_id=user.id)
        db.add(row)
        try:
            record_ticket_event(db, tenant_id=user.tenant_id, ticket_id=ticket.id, upload_id=ticket.upload_id, actor_user_id=user.id, event_type='comment_added', next_status=ticket.status, next_continuity_status=ticket.continuity_status, details={})
            db.commit(); db.refresh(row)
        except OperationalError as exc:
            db.rollback()
            if 'no such table: ticket_comments' not in str(exc).lower(): raise
            _ensure_ticket_comments_table(db)
            db.add(row)
            db.flush()
            record_ticket_event(db, tenant_id=user.tenant_id, ticket_id=ticket.id, upload_id=ticket.upload_id, actor_user_id=user.id, event_type='comment_added', next_status=ticket.status, next_continuity_status=ticket.continuity_status, details={})
            db.commit(); db.refresh(row)
        return {'id': row.id}

    @app.post('/api/v1/execution-tickets/{ticket_id}/comments/{comment_id}/edit')
    def edit_execution_ticket_comment(ticket_id: int, comment_id: int, request: Request, comment_text: str = Form(...), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        ticket = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if ticket is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, ticket)
        value = comment_text.strip()
        if not value: raise HTTPException(status_code=400, detail='Comment cannot be empty')
        row = db.query(TicketComment).filter(TicketComment.id == comment_id, TicketComment.ticket_id == ticket.id, TicketComment.tenant_id == user.tenant_id).first()
        if row is None: raise HTTPException(status_code=404, detail='Comment not found')
        row.comment_text = value
        record_ticket_event(db, tenant_id=user.tenant_id, ticket_id=ticket.id, upload_id=ticket.upload_id, actor_user_id=user.id, event_type='comment_edited', next_status=ticket.status, next_continuity_status=ticket.continuity_status, details={'comment_id': row.id})
        db.commit(); db.refresh(row)
        return {'id': row.id}
