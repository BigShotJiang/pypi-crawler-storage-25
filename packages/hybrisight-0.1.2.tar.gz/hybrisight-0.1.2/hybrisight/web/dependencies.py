# SPDX-License-Identifier: Apache-2.0
"""
Central dependency injection module.

Route handlers use these via FastAPI Depends() instead of receiving
dependencies through parameterised registration functions.
"""

from collections.abc import Callable
from typing import Any

from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.app_key_helpers import get_api_key_actor as _get_api_key_actor
from hybrisight.web.app_requests import get_client_ip as _get_client_ip
from hybrisight.web.app_requests import log_event as _log_event
from hybrisight.web.app_session import tenant_is_active, tenant_state_message
from hybrisight.web.auth import has_role
from hybrisight.web.db import get_db as _get_db
from hybrisight.web.models import ApiKey, Tenant, User


def get_db() -> Session:
    yield from _get_db()


def get_current_user(
    request: Request,
    db: Session = Depends(get_db),
) -> User:
    user_id = request.session.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid session")
    tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
    if tenant is None:
        raise HTTPException(status_code=401, detail="Invalid session tenant")
    if not tenant_is_active(tenant):
        request.session.clear()
        raise HTTPException(status_code=403, detail=tenant_state_message(tenant))
    return user


def role_required(required_role: str) -> Callable[[User], User]:
    def _check(user: User = Depends(get_current_user)) -> User:
        if not has_role(user.role, required_role):
            raise HTTPException(status_code=403, detail="Insufficient role")
        return user
    return _check


def require_role(required_role: str) -> Callable[[User], User]:
    return role_required(required_role)


def get_api_key_actor(
    request: Request,
    db: Session = Depends(get_db),
) -> tuple[ApiKey, Tenant, bool]:
    return _get_api_key_actor(
        db,
        request.headers.get("X-HybriSight-Api-Key"),
        tenant_is_active,
        tenant_state_message,
    )


def get_client_ip(request: Request) -> str:
    return _get_client_ip(request)


def log_event(
    request: Request,
    db: Session,
    event_type: str,
    user: User | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    _log_event(db, request, event_type, user=user, metadata=metadata)
