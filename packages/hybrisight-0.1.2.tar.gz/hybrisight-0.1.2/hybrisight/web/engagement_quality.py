# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from sqlalchemy import func
from sqlalchemy.orm import Session

from hybrisight.web.internal_ops_upload_quality import extract_collection_quality
from hybrisight.web.models import ScanUpload, Tenant
from hybrisight.web.service_ingestion_policy import build_upload_ingestion_summary


def resolve_client_tenant(db: Session, client_tenant_id: int | None, client_name: str) -> Tenant | None:
    if client_tenant_id:
        return db.query(Tenant).filter(Tenant.id == client_tenant_id).first()
    normalized_name = (client_name or "").strip().lower()
    if not normalized_name:
        return None
    return db.query(Tenant).filter(func.lower(Tenant.name) == normalized_name).first()


def latest_client_upload_quality(db: Session, client_tenant_id: int | None, client_name: str) -> dict[str, object] | None:
    tenant = resolve_client_tenant(db, client_tenant_id, client_name)
    if tenant is None:
        return None
    upload = (
        db.query(ScanUpload)
        .filter(ScanUpload.tenant_id == tenant.id)
        .order_by(ScanUpload.created_at.desc(), ScanUpload.id.desc())
        .first()
    )
    if upload is None:
        return {
            "tenant_id": tenant.id,
            "tenant_name": tenant.name,
            "tenant_slug": tenant.slug,
            "warning_level": "warn",
            "message": "No tenant uploads found for this client yet.",
        }
    ingestion = build_upload_ingestion_summary(upload)
    collection = extract_collection_quality(upload.raw_json)
    needs_warning = ingestion["quality"] != "canonical_full" or collection["quality"] != "full"
    if not needs_warning:
        return None
    return {
        "tenant_id": tenant.id,
        "tenant_name": tenant.name,
        "tenant_slug": tenant.slug,
        "upload_id": upload.id,
        "tenant_upload_seq": upload.tenant_upload_seq,
        "ingestion": ingestion,
        "collection_quality": collection,
        "warning_level": "warn" if collection["quality"] in {"partial", "demo"} else "critical",
        "message": f"Latest baseline for {tenant.name} is {ingestion['quality_label'].lower()} input with {collection['label'].lower()} signal completeness.",
    }
