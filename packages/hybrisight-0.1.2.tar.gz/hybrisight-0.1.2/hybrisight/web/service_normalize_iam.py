# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from hybrisight.models import Provider, Severity


def _iter_policy_documents(data: dict[str, Any]) -> list[tuple[str, str, Any]]:
    docs: list[tuple[str, str, Any]] = []
    for policy in data.get("Policies") or []:
        if not isinstance(policy, dict):
            continue
        name = str(policy.get("PolicyName") or policy.get("Arn") or "policy")
        for version in policy.get("PolicyVersionList") or []:
            if isinstance(version, dict):
                docs.append((name, str(policy.get("Arn") or name), version.get("Document")))
    for key in ("RoleDetailList", "UserDetailList", "GroupDetailList"):
        for entity in data.get(key) or []:
            if not isinstance(entity, dict):
                continue
            entity_name = str(entity.get("RoleName") or entity.get("UserName") or entity.get("GroupName") or "entity")
            for inline in entity.get("RolePolicyList") or entity.get("UserPolicyList") or entity.get("GroupPolicyList") or []:
                if isinstance(inline, dict):
                    docs.append((f"{entity_name}:{inline.get('PolicyName', 'inline')}", entity_name, inline.get("PolicyDocument")))
    return docs


def _statements(document: Any) -> list[dict[str, Any]]:
    if not isinstance(document, dict):
        return []
    stmts = document.get("Statement") or []
    if isinstance(stmts, dict):
        return [stmts]
    return [item for item in stmts if isinstance(item, dict)]


def _has_admin_access(statement: dict[str, Any]) -> bool:
    if str(statement.get("Effect", "")).lower() != "allow":
        return False
    if "NotAction" in statement:
        return False
    actions = statement.get("Action")
    if isinstance(actions, str):
        actions = [actions]
    return any(str(action).strip() == "*" for action in (actions or []))


def _has_wildcard_permissions(statement: dict[str, Any]) -> bool:
    if str(statement.get("Effect", "")).lower() != "allow":
        return False
    actions = statement.get("Action")
    resources = statement.get("Resource")
    if isinstance(actions, str):
        actions = [actions]
    if isinstance(resources, str):
        resources = [resources]
    if "NotAction" in statement:
        return any(str(resource).strip() == "*" for resource in (resources or []))
    return any(str(action).strip().endswith(":*") or str(action).strip() == "*" for action in (actions or [])) or any(str(resource).strip() == "*" for resource in (resources or []))


def normalize_iam_authorization_details(
    data: dict[str, Any],
    *,
    finding_builder: Callable[..., Any],
    suffix_builder: Callable[[str], str],
) -> list[Any]:
    findings = []
    for name, resource_id, document in _iter_policy_documents(data):
        statements = _statements(document)
        if any(_has_admin_access(stmt) for stmt in statements):
            findings.append(finding_builder(
                rule_id=f"AWS.IAM.AUTHZ.ADMIN.{suffix_builder(name)}",
                provider=Provider.aws,
                service="iam",
                resource_id=resource_id,
                title=f"IAM policy grants administrative access: {name}",
                category="security",
                severity=Severity.critical,
                description="IAM authorization details show broad administrative permissions.",
                business_impact="Administrative access materially increases privilege-escalation and compromise blast radius.",
                remediation="Replace administrator-style permissions with scoped least-privilege policies and approval-controlled break-glass access.",
            ))
        elif any(_has_wildcard_permissions(stmt) for stmt in statements):
            findings.append(finding_builder(
                rule_id=f"AWS.IAM.AUTHZ.WILDCARD.{suffix_builder(name)}",
                provider=Provider.aws,
                service="iam",
                resource_id=resource_id,
                title=f"IAM policy uses wildcard permissions: {name}",
                category="security",
                severity=Severity.high,
                description="IAM authorization details show wildcard actions or resources.",
                business_impact="Wildcard IAM permissions weaken least-privilege boundaries and increase operational risk.",
                remediation="Refactor IAM policies to explicit allowed actions and resources, then validate policy diff before rollout.",
            ))
    return findings
