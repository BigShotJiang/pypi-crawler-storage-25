# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime

from fastapi import HTTPException
from sqlalchemy.orm import Session

from hybrisight.web.models import ExecutionTicket, ScanUpload


def active_upload(db: Session, tenant_id: int) -> ScanUpload | None:
    return (
        db.query(ScanUpload)
        .filter(ScanUpload.tenant_id == tenant_id, ScanUpload.execution_state == 'active')
        .order_by(ScanUpload.created_at.desc(), ScanUpload.id.desc())
        .first()
    )


def set_upload_state(db: Session, upload: ScanUpload, state: str, user_id: int) -> None:
    upload.execution_state = state
    upload.execution_state_updated_at = datetime.now(UTC)
    upload.execution_state_updated_by_user_id = user_id


def ensure_ticket_in_active_workspace(db: Session, tenant_id: int, ticket: ExecutionTicket) -> None:
    active = active_upload(db, tenant_id)
    if active is None:
        raise HTTPException(status_code=409, detail='No active report selected. Activate a report first.')
    if ticket.upload_id != active.id:
        raise HTTPException(status_code=409, detail=f'Ticket belongs to upload #{ticket.upload_id}. Active upload is #{active.id}.')
