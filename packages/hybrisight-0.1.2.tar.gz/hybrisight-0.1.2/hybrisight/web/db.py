# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
import os
import threading
from collections.abc import Generator
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, declarative_base, sessionmaker

from hybrisight.web.app_paths import resolve_project_root

logger = logging.getLogger(__name__)
_config_lock = threading.Lock()


def _default_sqlite_url() -> str:
    project_root = resolve_project_root() or Path.cwd().resolve()
    return f"sqlite:///{project_root / 'hybrisight_web.db'}"


DATABASE_URL = os.getenv("HYBRISIGHT_WEB_DATABASE_URL", _default_sqlite_url())

def _engine_kwargs(database_url: str) -> dict:
    if database_url.startswith("sqlite"):
        return {"connect_args": {"check_same_thread": False}}
    return {
        "pool_pre_ping": True,
        "pool_size": int(os.getenv("HYBRISIGHT_DB_POOL_SIZE", "5")),
        "max_overflow": int(os.getenv("HYBRISIGHT_DB_MAX_OVERFLOW", "10")),
    }


engine = create_engine(DATABASE_URL, **_engine_kwargs(DATABASE_URL))
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def reconfigure_from_env() -> None:
    global DATABASE_URL, engine
    with _config_lock:
        next_url = os.getenv("HYBRISIGHT_WEB_DATABASE_URL", _default_sqlite_url())
        if next_url == DATABASE_URL:
            return
        logger.info("Reconfiguring database from %s to %s", DATABASE_URL, next_url)
        try:
            engine.dispose()
        except Exception:
            pass
        DATABASE_URL = next_url
        engine = create_engine(DATABASE_URL, **_engine_kwargs(DATABASE_URL))
        SessionLocal.configure(bind=engine)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def initialize_schema() -> None:
    Base.metadata.create_all(bind=engine)
