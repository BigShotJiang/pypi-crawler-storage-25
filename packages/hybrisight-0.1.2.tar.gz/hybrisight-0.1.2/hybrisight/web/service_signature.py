# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from typing import Any

from hybrisight.models import ScanResult, SignatureBlock
from hybrisight.signing import verify_scan_result_signature, verify_scan_result_signature_with_public_key


def extract_signature_metadata(raw_json: str) -> dict[str, str | None]:
    try:
        payload = json.loads(raw_json)
    except Exception:
        return {"key_id": None, "algorithm": None}
    signature = payload.get("signature")
    if not isinstance(signature, dict):
        return {"key_id": None, "algorithm": None}
    return {
        "key_id": str(signature.get("key_id") or "").strip() or None,
        "algorithm": str(signature.get("algorithm") or "").strip() or None,
    }


def verify_signature_status(
    result: ScanResult,
    provided_signature: dict[str, Any] | None = None,
    *,
    db: Any | None = None,
    tenant_id: int | None = None,
) -> tuple[bool | None, str | None]:
    if provided_signature:
        merged = result.model_copy(deep=True)
        merged.signature = SignatureBlock.model_validate(provided_signature)
        sig = merged.signature
        if sig and sig.algorithm == "ed25519":
            if db is None or tenant_id is None:
                return False, "sidecar"
            from hybrisight.web.models import TenantSigningKey

            key_row = (
                db.query(TenantSigningKey)
                .filter(
                    TenantSigningKey.tenant_id == tenant_id,
                    TenantSigningKey.key_id == sig.key_id,
                    TenantSigningKey.algorithm == "ed25519",
                    TenantSigningKey.active.is_(True),
                )
                .first()
            )
            if key_row is None:
                return False, "sidecar"
            return verify_scan_result_signature_with_public_key(merged, sig, key_row.public_key_pem), "sidecar"
        return verify_scan_result_signature(merged), "sidecar"

    if result.signature:
        sig = result.signature
        if sig.algorithm == "ed25519":
            if db is None or tenant_id is None:
                return False, "embedded"
            from hybrisight.web.models import TenantSigningKey

            key_row = (
                db.query(TenantSigningKey)
                .filter(
                    TenantSigningKey.tenant_id == tenant_id,
                    TenantSigningKey.key_id == sig.key_id,
                    TenantSigningKey.algorithm == "ed25519",
                    TenantSigningKey.active.is_(True),
                )
                .first()
            )
            if key_row is None:
                return False, "embedded"
            return verify_scan_result_signature_with_public_key(result, sig, key_row.public_key_pem), "embedded"
        return verify_scan_result_signature(result), "embedded"

    return None, None
