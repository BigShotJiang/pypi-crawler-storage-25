# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any, Callable

from fastapi import Body, Depends, Request
from sqlalchemy import func
from sqlalchemy.orm import Session

from hybrisight.web.models import ExecutionTicket, ScanUpload, Tenant, TenantSetting, TicketComment, TicketEvidence, User
from hybrisight.web.service import delete_artifact

INTERNAL_STORAGE_POLICY_ENABLED_KEY = 'internal.storage.policy.enabled'
INTERNAL_STORAGE_POLICY_RETENTION_DAYS_KEY = 'internal.storage.policy.retention_days'
INTERNAL_STORAGE_POLICY_MAX_UPLOADS_KEY = 'internal.storage.policy.max_uploads_per_tenant'
INTERNAL_STORAGE_POLICY_MAX_RAW_BYTES_KEY = 'internal.storage.policy.max_raw_json_bytes_per_tenant'
INTERNAL_STORAGE_POLICY_AUTO_PURGE_KEY = 'internal.storage.policy.auto_purge'
INTERNAL_STORAGE_POLICY_LAST_RUN_AT_KEY = 'internal.storage.policy.last_run_at'


def register_internal_ops_api_storage_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    validate_csrf: Callable[[Request, str | None], None],
    parse_bool_like: Callable[[Any, bool], bool],
    normalized_tenant_status: Callable[[Tenant], str],
    log_event: Callable[..., None],
) -> None:
    def _int_env(name: str, default: int, minimum: int, maximum: int) -> int:
        import os
        try:
            parsed = int(os.getenv(name, str(default)))
        except (TypeError, ValueError):
            parsed = default
        return max(minimum, min(parsed, maximum))

    default_policy_enabled = parse_bool_like(__import__('os').getenv('HYBRISIGHT_INTERNAL_STORAGE_POLICY_ENABLED'), default=False)
    default_retention_days = _int_env('HYBRISIGHT_INTERNAL_STORAGE_POLICY_RETENTION_DAYS', 180, 1, 3650)
    default_max_uploads_per_tenant = _int_env('HYBRISIGHT_INTERNAL_STORAGE_POLICY_MAX_UPLOADS_PER_TENANT', 500, 1, 1000000)
    default_max_raw_json_bytes_per_tenant = _int_env('HYBRISIGHT_INTERNAL_STORAGE_POLICY_MAX_RAW_BYTES_PER_TENANT', 256 * 1024 * 1024, 1024, 1024 * 1024 * 1024 * 1024)
    default_auto_purge = parse_bool_like(__import__('os').getenv('HYBRISIGHT_INTERNAL_STORAGE_POLICY_AUTO_PURGE'), default=False)
    policy_interval_minutes = _int_env('HYBRISIGHT_INTERNAL_STORAGE_POLICY_INTERVAL_MINUTES', 60, 1, 1440)

    def _setting_row(db: Session, tenant_id: int, key: str) -> TenantSetting | None:
        return db.query(TenantSetting).filter(TenantSetting.tenant_id == tenant_id, TenantSetting.key == key).first()

    def _get_setting_str(db: Session, tenant_id: int, key: str, default: str) -> str:
        row = _setting_row(db, tenant_id, key)
        return default if row is None or row.value is None or not str(row.value).strip() else str(row.value).strip()

    def _get_setting_bool(db: Session, tenant_id: int, key: str, default: bool) -> bool:
        row = _setting_row(db, tenant_id, key)
        return default if row is None else parse_bool_like(row.value, default=default)

    def _get_setting_int(db: Session, tenant_id: int, key: str, default: int, minimum: int, maximum: int) -> int:
        row = _setting_row(db, tenant_id, key)
        if row is None:
            return default
        try:
            parsed = int(str(row.value).strip())
        except (TypeError, ValueError):
            return default
        return max(minimum, min(parsed, maximum))

    def _upsert_setting(db: Session, tenant_id: int, user_id: int, key: str, value: str) -> None:
        row = _setting_row(db, tenant_id, key)
        if row is None:
            db.add(TenantSetting(tenant_id=tenant_id, key=key, value=value, updated_by_user_id=user_id))
        else:
            row.value = value
            row.updated_by_user_id = user_id

    def _storage_rows(db: Session, stale_days: int, limit: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        stale_cutoff = datetime.now(UTC) - timedelta(days=stale_days)
        tenants = db.query(Tenant).order_by(Tenant.name.asc()).limit(limit).all()
        rows: list[dict[str, Any]] = []
        total_uploads = 0
        total_raw_json_bytes = 0
        for tenant in tenants:
            upload_count = db.query(ScanUpload.id).filter(ScanUpload.tenant_id == tenant.id).count()
            raw_json_bytes = db.query(func.coalesce(func.sum(func.length(ScanUpload.raw_json)), 0)).filter(ScanUpload.tenant_id == tenant.id).scalar() or 0
            latest_upload = db.query(ScanUpload.created_at).filter(ScanUpload.tenant_id == tenant.id).order_by(ScanUpload.created_at.desc(), ScanUpload.id.desc()).first()
            stale_uploads = db.query(ScanUpload.id).filter(ScanUpload.tenant_id == tenant.id, ScanUpload.created_at.is_not(None), ScanUpload.created_at < stale_cutoff).count()
            total_uploads += int(upload_count)
            total_raw_json_bytes += int(raw_json_bytes)
            rows.append({'tenant_id': tenant.id, 'tenant_name': tenant.name, 'tenant_slug': tenant.slug, 'tenant_status': normalized_tenant_status(tenant), 'upload_count': int(upload_count), 'raw_json_bytes': int(raw_json_bytes), 'avg_upload_bytes': int(raw_json_bytes // upload_count) if upload_count else 0, 'stale_upload_count': int(stale_uploads), 'last_upload_at': latest_upload[0].isoformat() if latest_upload and latest_upload[0] else ''})
        return rows, {'tenant_count': len(rows), 'total_upload_count': total_uploads, 'total_raw_json_bytes': total_raw_json_bytes, 'stale_days': stale_days}

    def _storage_policy_config(db: Session, tenant_id: int) -> dict[str, Any]:
        return {'enabled': _get_setting_bool(db, tenant_id, INTERNAL_STORAGE_POLICY_ENABLED_KEY, default_policy_enabled), 'retention_days': _get_setting_int(db, tenant_id, INTERNAL_STORAGE_POLICY_RETENTION_DAYS_KEY, default_retention_days, 1, 3650), 'max_uploads_per_tenant': _get_setting_int(db, tenant_id, INTERNAL_STORAGE_POLICY_MAX_UPLOADS_KEY, default_max_uploads_per_tenant, 1, 1000000), 'max_raw_json_bytes_per_tenant': _get_setting_int(db, tenant_id, INTERNAL_STORAGE_POLICY_MAX_RAW_BYTES_KEY, default_max_raw_json_bytes_per_tenant, 1024, 1024 * 1024 * 1024 * 1024), 'auto_purge': _get_setting_bool(db, tenant_id, INTERNAL_STORAGE_POLICY_AUTO_PURGE_KEY, default_auto_purge), 'interval_minutes': policy_interval_minutes, 'last_run_at': _get_setting_str(db, tenant_id, INTERNAL_STORAGE_POLICY_LAST_RUN_AT_KEY, '')}

    def _storage_policy_violations(rows: list[dict[str, Any]], policy: dict[str, Any]) -> list[dict[str, Any]]:
        violations: list[dict[str, Any]] = []
        max_uploads = int(policy['max_uploads_per_tenant']); max_bytes = int(policy['max_raw_json_bytes_per_tenant'])
        for row in rows:
            reasons = [*( [f'uploads>{max_uploads}'] if int(row['upload_count']) > max_uploads else [] ), *( [f'bytes>{max_bytes / (1024 * 1024):.0f} MB'] if int(row['raw_json_bytes']) > max_bytes else [] )]
            if reasons:
                violations.append({'tenant_id': row['tenant_id'], 'tenant_name': row['tenant_name'], 'tenant_slug': row['tenant_slug'], 'upload_count': row['upload_count'], 'raw_json_bytes': row['raw_json_bytes'], 'reasons': reasons})
        return violations

    def _run_storage_purge(db: Session, *, older_than_days: int, tenant_id: int | None, dry_run: bool) -> dict[str, Any]:
        cutoff = datetime.now(UTC) - timedelta(days=older_than_days)
        upload_query = db.query(ScanUpload).filter(ScanUpload.created_at < cutoff)
        if tenant_id is not None:
            upload_query = upload_query.filter(ScanUpload.tenant_id == tenant_id)
        uploads = upload_query.order_by(ScanUpload.created_at.asc(), ScanUpload.id.asc()).all()
        candidate_ids = [row.id for row in uploads]
        candidate_bytes = sum(len((row.raw_json or '').encode('utf-8')) for row in uploads)
        if dry_run:
            return {'dry_run': True, 'older_than_days': older_than_days, 'tenant_id': tenant_id, 'candidate_upload_count': len(candidate_ids), 'candidate_raw_json_bytes': candidate_bytes}
        ticket_ids = [row[0] for row in db.query(ExecutionTicket.id).filter(ExecutionTicket.upload_id.in_(candidate_ids)).all()] if candidate_ids else []
        artifacts_removed = sum(1 for row in uploads if row.artifact_path and delete_artifact(row.artifact_path))
        if ticket_ids:
            db.query(TicketComment).filter(TicketComment.ticket_id.in_(ticket_ids)).delete(synchronize_session=False)
            db.query(TicketEvidence).filter(TicketEvidence.ticket_id.in_(ticket_ids)).delete(synchronize_session=False)
            db.query(ExecutionTicket).filter(ExecutionTicket.id.in_(ticket_ids)).delete(synchronize_session=False)
        if candidate_ids:
            db.query(ScanUpload).filter(ScanUpload.id.in_(candidate_ids)).delete(synchronize_session=False)
        db.commit()
        return {'dry_run': False, 'older_than_days': older_than_days, 'tenant_id': tenant_id, 'deleted_upload_count': len(candidate_ids), 'deleted_raw_json_bytes': candidate_bytes, 'artifacts_removed': artifacts_removed, 'tickets_removed': len(ticket_ids)}

    @app.get('/api/v1/internal/storage')
    def api_internal_storage_usage(request: Request, limit: int = 200, stale_days: int = 90, db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        safe_limit = max(1, min(int(limit or 200), 500)); safe_stale_days = max(1, min(int(stale_days or 90), 3650))
        rows, summary = _storage_rows(db, stale_days=safe_stale_days, limit=safe_limit)
        policy = _storage_policy_config(db, user.tenant_id)
        violations = _storage_policy_violations(rows, policy) if policy['enabled'] else []
        auto_result: dict[str, Any] | None = None
        if policy['enabled'] and policy['auto_purge']:
            should_run = True
            last_run_raw = str(policy.get('last_run_at') or '').strip()
            if last_run_raw:
                try:
                    last_run = datetime.fromisoformat(last_run_raw.replace('Z', '+00:00'))
                    if last_run.tzinfo is None: last_run = last_run.replace(tzinfo=UTC)
                    should_run = datetime.now(UTC) - last_run >= timedelta(minutes=policy_interval_minutes)
                except Exception:
                    should_run = True
            if should_run:
                auto_result = _run_storage_purge(db, older_than_days=int(policy['retention_days']), tenant_id=None, dry_run=False)
                _upsert_setting(db, user.tenant_id, user.id, INTERNAL_STORAGE_POLICY_LAST_RUN_AT_KEY, datetime.now(UTC).isoformat())
                db.commit(); log_event(db, request, event_type='internal_storage_policy_auto_purge_run', user=user, metadata=auto_result)
                rows, summary = _storage_rows(db, stale_days=safe_stale_days, limit=safe_limit)
                violations = _storage_policy_violations(rows, policy) if policy['enabled'] else []
        return {'items': rows, 'summary': summary, 'policy': policy, 'violations': violations, 'auto_run': auto_result}

    @app.post('/api/v1/internal/storage/policy')
    def api_internal_storage_policy_update(request: Request, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        enabled = parse_bool_like(payload.get('enabled'), default=default_policy_enabled); auto_purge = parse_bool_like(payload.get('auto_purge'), default=default_auto_purge)
        retention_days = max(1, min(int(payload.get('retention_days', default_retention_days) or default_retention_days), 3650))
        max_uploads = max(1, min(int(payload.get('max_uploads_per_tenant', default_max_uploads_per_tenant) or default_max_uploads_per_tenant), 1000000))
        max_bytes = max(1024, min(int(payload.get('max_raw_json_bytes_per_tenant', default_max_raw_json_bytes_per_tenant) or default_max_raw_json_bytes_per_tenant), 1024 * 1024 * 1024 * 1024))
        _upsert_setting(db, user.tenant_id, user.id, INTERNAL_STORAGE_POLICY_ENABLED_KEY, '1' if enabled else '0')
        _upsert_setting(db, user.tenant_id, user.id, INTERNAL_STORAGE_POLICY_AUTO_PURGE_KEY, '1' if auto_purge else '0')
        _upsert_setting(db, user.tenant_id, user.id, INTERNAL_STORAGE_POLICY_RETENTION_DAYS_KEY, str(retention_days))
        _upsert_setting(db, user.tenant_id, user.id, INTERNAL_STORAGE_POLICY_MAX_UPLOADS_KEY, str(max_uploads))
        _upsert_setting(db, user.tenant_id, user.id, INTERNAL_STORAGE_POLICY_MAX_RAW_BYTES_KEY, str(max_bytes))
        db.commit(); policy = _storage_policy_config(db, user.tenant_id)
        log_event(db, request, event_type='internal_storage_policy_updated', user=user, metadata=policy)
        return {'ok': True, 'policy': policy}

    @app.post('/api/v1/internal/storage/policy/run')
    def api_internal_storage_policy_run(request: Request, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        dry_run = parse_bool_like(payload.get('dry_run'), default=True)
        policy = _storage_policy_config(db, user.tenant_id)
        result = _run_storage_purge(db, older_than_days=int(policy['retention_days']), tenant_id=None, dry_run=dry_run)
        if not dry_run:
            _upsert_setting(db, user.tenant_id, user.id, INTERNAL_STORAGE_POLICY_LAST_RUN_AT_KEY, datetime.now(UTC).isoformat())
            db.commit(); log_event(db, request, event_type='internal_storage_policy_run', user=user, metadata=result)
        return {'ok': True, 'result': result, 'policy': policy}

    @app.post('/api/v1/internal/storage/purge')
    def api_internal_storage_purge(request: Request, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        older_than_days = max(1, min(int(payload.get('older_than_days', 180) or 180), 3650))
        dry_run = parse_bool_like(payload.get('dry_run'), default=False)
        tenant_id = payload.get('tenant_id'); parsed_tenant_id = int(tenant_id) if tenant_id is not None else None
        result = _run_storage_purge(db, older_than_days=older_than_days, tenant_id=parsed_tenant_id, dry_run=dry_run)
        if not dry_run:
            log_event(db, request, event_type='internal_storage_purged', user=user, metadata=result)
        return {'ok': True, **result}
