# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Callable
from urllib.parse import quote_plus

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from hybrisight.web.key_management_helpers import (
    env_bool,
    purge_revoked_api_keys_for_tenant,
    revoked_retention_days,
)
from hybrisight.web.key_management_signing_routes import register_signing_key_routes
from hybrisight.web.models import ApiKey, Tenant, User


def register_key_management_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    show_internal_ops_nav: Callable[[User], bool],
    security_posture_checks: Callable[[Session | None], list[dict[str, str]]],
    create_api_key_row: Callable[[Session, User, str, str, int], tuple[ApiKey, str]],
    tenant_api_key_or_404: Callable[[Session, User, int], ApiKey],
    get_api_key_actor: Callable[..., tuple[ApiKey, Tenant, bool]],
) -> None:
    @app.get("/admin/api-keys", response_class=HTMLResponse)
    def api_keys_admin_page(
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> HTMLResponse:
        return RedirectResponse(url="/app?page=api-keys", status_code=302)

    @app.post("/admin/api-keys/create")
    def api_keys_admin_create(
        request: Request,
        name: str = Form("runner-exchange-key"),
        scope: str = Form("scan_job:create"),
        soft_expires_days: int = Form(90),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        if scope != "scan_job:create":
            raise HTTPException(status_code=400, detail="Unsupported scope for MVP")
        _, raw_key = create_api_key_row(db, user, name, scope, soft_expires_days=soft_expires_days)
        log_event(db, request, event_type="api_key_created", user=user, metadata={"scope": scope, "via": "admin_ui"})
        message = quote_plus(f"New API key created. Copy it now: {raw_key}")
        return RedirectResponse(url=f"/app?page=api-keys&message={message}", status_code=302)

    @app.post("/admin/api-keys/{api_key_id}/revoke", response_class=HTMLResponse)
    def api_keys_admin_revoke(
        api_key_id: int,
        request: Request,
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> HTMLResponse:
        validate_csrf(request, csrf_token)
        row = tenant_api_key_or_404(db, user, api_key_id)
        row.active = False
        row.revoked_at = datetime.now(UTC)
        db.commit()
        log_event(db, request, event_type="api_key_revoked", user=user, metadata={"api_key_id": row.id, "via": "admin_ui"})
        return RedirectResponse(url="/admin/api-keys", status_code=302)

    @app.post("/admin/api-keys/{api_key_id}/rotate")
    def api_keys_admin_rotate(
        api_key_id: int,
        request: Request,
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        row = tenant_api_key_or_404(db, user, api_key_id)
        row.active = False
        row.revoked_at = datetime.now(UTC)
        db.commit()
        _, raw_key = create_api_key_row(db, user, name=f"{row.name}-rotated", scope=row.scope, soft_expires_days=90)
        log_event(db, request, event_type="api_key_rotated", user=user, metadata={"api_key_id": row.id, "via": "admin_ui"})
        message = quote_plus(f"API key rotated. New key: {raw_key}")
        return RedirectResponse(url=f"/app?page=api-keys&message={message}", status_code=302)

    @app.post("/api/v1/api-keys")
    def create_api_key(
        request: Request,
        name: str = Form("runner-exchange-key"),
        scope: str = Form("scan_job:create"),
        soft_expires_days: int = Form(90),
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        if scope != "scan_job:create":
            raise HTTPException(status_code=400, detail="Unsupported scope for MVP")

        row, raw_key = create_api_key_row(db, user, name, scope, soft_expires_days=soft_expires_days)
        log_event(db, request, event_type="api_key_created", user=user, metadata={"api_key_id": row.id, "scope": scope})
        return {
            "api_key": raw_key,
            "api_key_id": row.id,
            "scope": row.scope,
            "name": row.name,
            "soft_expires_at": row.soft_expires_at.isoformat() if row.soft_expires_at else None,
            "warning": "This key is shown once. Store securely.",
        }

    @app.get("/api/v1/api-keys")
    def list_api_keys(
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        purged_count = 0
        if env_bool("HYBRISIGHT_API_KEY_AUTO_PURGE_REVOKED", True):
            purged_count = purge_revoked_api_keys_for_tenant(db, user, older_than_days=revoked_retention_days())
            if purged_count > 0:
                log_event(
                    db,
                    request,
                    event_type="api_key_revoked_auto_purged",
                    user=user,
                    metadata={"purged_count": purged_count, "retention_days": revoked_retention_days()},
                )

        rows = (
            db.query(ApiKey)
            .filter(ApiKey.tenant_id == user.tenant_id)
            .order_by(ApiKey.created_at.desc())
            .all()
        )
        response: dict[str, Any] = {
            "items": [
                {
                    "id": row.id,
                    "name": row.name,
                    "scope": row.scope,
                    "active": bool(row.active),
                    "revoked_at": row.revoked_at.isoformat() if row.revoked_at else None,
                    "last_used_at": row.last_used_at.isoformat() if row.last_used_at else None,
                    "soft_expires_at": row.soft_expires_at.isoformat() if row.soft_expires_at else None,
                    "created_at": row.created_at.isoformat(),
                    "key_preview": f"{row.key_hash[:8]}...",
                }
                for row in rows
            ]
        }
        if purged_count > 0:
            response["purged_revoked_count"] = purged_count
            response["revoked_retention_days"] = revoked_retention_days()
        if show_internal_ops_nav(user):
            response["security_checks"] = security_posture_checks(db)
            response["platform_scope_note"] = (
                "These controls apply to the HybriSight portal platform only. "
                "They are not findings from your cloud environment and are not part of your customer assessment report."
            )
        return response

    @app.post("/api/v1/api-keys/{api_key_id}/revoke")
    def revoke_api_key(
        api_key_id: int,
        request: Request,
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        row = tenant_api_key_or_404(db, user, api_key_id)
        row.active = False
        row.revoked_at = datetime.now(UTC)
        db.commit()
        log_event(db, request, event_type="api_key_revoked", user=user, metadata={"api_key_id": row.id})
        return {"revoked": True, "api_key_id": row.id}

    @app.post("/api/v1/api-keys/{api_key_id}/rotate")
    def rotate_api_key(
        api_key_id: int,
        request: Request,
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        row = tenant_api_key_or_404(db, user, api_key_id)
        row.active = False
        row.revoked_at = datetime.now(UTC)
        db.commit()
        new_row, raw_key = create_api_key_row(db, user, name=f"{row.name}-rotated", scope=row.scope, soft_expires_days=90)
        log_event(db, request, event_type="api_key_rotated", user=user, metadata={"old_api_key_id": row.id, "new_api_key_id": new_row.id})
        return {
            "api_key": raw_key,
            "api_key_id": new_row.id,
            "scope": new_row.scope,
            "warning": "This key is shown once. Store securely.",
        }

    @app.post("/api/v1/api-keys/{api_key_id}/delete")
    def delete_api_key(
        api_key_id: int,
        request: Request,
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        row = tenant_api_key_or_404(db, user, api_key_id)
        if row.active:
            raise HTTPException(status_code=400, detail="Only revoked API keys can be deleted")
        deleted_name = row.name
        db.delete(row)
        db.commit()
        log_event(db, request, event_type="api_key_deleted", user=user, metadata={"api_key_id": api_key_id, "name": deleted_name})
        return {"deleted": True, "api_key_id": api_key_id}

    @app.post("/api/v1/api-keys/purge-revoked")
    def purge_revoked_api_keys(
        request: Request,
        older_than_days: int = Form(0),
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        days = older_than_days if older_than_days > 0 else revoked_retention_days()
        purged = purge_revoked_api_keys_for_tenant(db, user, older_than_days=days)
        log_event(db, request, event_type="api_key_revoked_purged", user=user, metadata={"purged_count": purged, "older_than_days": days})
        return {"ok": True, "purged_count": purged, "older_than_days": days}
    register_signing_key_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        validate_csrf=validate_csrf,
        log_event=log_event,
        get_api_key_actor=get_api_key_actor,
    )
