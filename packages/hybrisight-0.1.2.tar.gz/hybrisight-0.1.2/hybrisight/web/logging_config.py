# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import logging
import logging.config
import logging.handlers
import os
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import Any

_REQUEST_CONTEXT: ContextVar[dict[str, Any]] = ContextVar("hybrisight_request_context", default={})
_LOGGING_CONFIGURED = False


def set_request_context(**fields: Any) -> None:
    current = dict(_REQUEST_CONTEXT.get())
    current.update({key: value for key, value in fields.items() if value is not None})
    _REQUEST_CONTEXT.set(current)


def clear_request_context() -> None:
    _REQUEST_CONTEXT.set({})


class RequestContextFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        context = _REQUEST_CONTEXT.get()
        for key, value in context.items():
            setattr(record, key, value)
        return True


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key in ("request_id", "method", "path", "client_ip", "status_code", "duration_ms", "tenant_id", "user_id"):
            value = getattr(record, key, None)
            if value is not None:
                payload[key] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


class TextFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        base = super().format(record)
        extras: list[str] = []
        for key in ("request_id", "method", "path", "status_code", "duration_ms"):
            value = getattr(record, key, None)
            if value is not None:
                extras.append(f"{key}={value}")
        return f"{base} [{' '.join(extras)}]" if extras else base


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def configure_logging() -> None:
    global _LOGGING_CONFIGURED
    if _LOGGING_CONFIGURED:
        return

    level = os.getenv("HYBRISIGHT_WEB_LOG_LEVEL", "INFO").upper()
    log_format = os.getenv("HYBRISIGHT_WEB_LOG_FORMAT", "json").strip().lower()
    log_file = os.getenv("HYBRISIGHT_WEB_LOG_FILE", "").strip()
    include_uvicorn = _env_bool("HYBRISIGHT_WEB_LOG_INCLUDE_UVICORN", True)

    formatter_name = "json" if log_format == "json" else "text"
    handlers: dict[str, dict[str, Any]] = {
        "console": {
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout",
            "level": level,
            "formatter": formatter_name,
            "filters": ["request_context"],
        }
    }
    root_handlers = ["console"]

    if log_file:
        handlers["file"] = {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": log_file,
            "maxBytes": int(os.getenv("HYBRISIGHT_WEB_LOG_MAX_BYTES", str(10 * 1024 * 1024))),
            "backupCount": int(os.getenv("HYBRISIGHT_WEB_LOG_BACKUP_COUNT", "5")),
            "encoding": "utf-8",
            "level": level,
            "formatter": formatter_name,
            "filters": ["request_context"],
        }
        root_handlers.append("file")

    config: dict[str, Any] = {
        "version": 1,
        "disable_existing_loggers": False,
        "filters": {
            "request_context": {
                "()": "hybrisight.web.logging_config.RequestContextFilter",
            }
        },
        "formatters": {
            "json": {"()": "hybrisight.web.logging_config.JsonFormatter"},
            "text": {
                "()": "hybrisight.web.logging_config.TextFormatter",
                "format": "%(asctime)s %(levelname)s %(name)s: %(message)s",
            },
        },
        "handlers": handlers,
        "root": {
            "level": level,
            "handlers": root_handlers,
        },
        "loggers": {
            "hybrisight": {"level": level, "propagate": True},
        },
    }

    if include_uvicorn:
        config["loggers"].update(
            {
                "uvicorn": {"level": level, "handlers": root_handlers, "propagate": False},
                "uvicorn.error": {"level": level, "handlers": root_handlers, "propagate": False},
                "uvicorn.access": {"level": level, "handlers": root_handlers, "propagate": False},
            }
        )

    logging.config.dictConfig(config)
    _LOGGING_CONFIGURED = True


def reset_logging_for_tests() -> None:
    global _LOGGING_CONFIGURED
    _LOGGING_CONFIGURED = False
    logging.shutdown()
    root = logging.getLogger()
    root.handlers = []
    root.setLevel(logging.NOTSET)
