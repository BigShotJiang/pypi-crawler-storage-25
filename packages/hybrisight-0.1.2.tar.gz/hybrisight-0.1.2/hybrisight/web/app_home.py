# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import html
import json
import os
from typing import Any
from urllib.parse import urlencode

from fastapi.responses import HTMLResponse, RedirectResponse

from hybrisight.web.constants import PRODUCT_TAXONOMY
from hybrisight.web.recaptcha import recaptcha_site_key
from hybrisight.web.service_constants import MAX_UPLOAD_BYTES
from sqlalchemy.orm import Session

from hybrisight.web.models import Tenant, User

APP_PUBLIC_REDIRECT_PATHS = {
    "landing": "/",
    "login": "/login",
    "signup": "/signup",
    "request-baseline": "/request-baseline",
}

PUBLIC_PAGE_PATHS = {
    **APP_PUBLIC_REDIRECT_PATHS,
    "security": "/security-data-handling",
    "delivery-options": "/help/dual-delivery-options",
    "help-aws": "/help/access-setup/aws-readonly-access",
    "help-azure": "/help/access-setup/azure-readonly-access",
    "help-credential": "/help/access-setup/credential-handling",
    "terms": "/terms",
    "privacy": "/privacy",
    "sample-executive-brief": "/sample-executive-brief",
    "about": "/about",
    "support": "/support-us",
    "contact": "/contact-feedback",
}


def _theme_document_paint(theme: str) -> tuple[str, str]:
    if theme == "dark":
        return "#020617", "#e2e8f0"
    if theme == "board":
        return "#0b1220", "#dbeafe"
    return "#f8fafc", "#0f172a"


def _render_spa_document(
    *,
    title: str,
    theme: str,
    authenticated: bool,
    css_urls: list[str],
    js_url: str,
    body: str,
    build_info: dict[str, Any] | None = None,
    show_build_badge: bool = False,
) -> HTMLResponse:
    links = "".join(f'<link rel="stylesheet" href="{html.escape(href)}" />' for href in css_urls)
    script = f'<script type="module" src="{html.escape(js_url)}"></script>' if js_url else ""
    build_info = build_info or {}
    meta = "".join(
        (
            f'<meta name="hybrisight-ui-entry" content="{html.escape(str(build_info.get("entry_name") or ""))}" />',
            f'<meta name="hybrisight-ui-bundle" content="{html.escape(str(build_info.get("js_file") or ""))}" />',
            f'<meta name="hybrisight-ui-dist" content="{html.escape(str(build_info.get("dist_dir") or ""))}" />',
        )
    )
    bg, ink = _theme_document_paint(theme)
    inline_paint = (
        "<style>"
        f"html{{background:{bg};color:{ink};color-scheme:{'light' if theme == 'light' else 'dark'};}}"
        f"body{{margin:0;background:{bg};color:{ink};}}"
        "</style>"
    )
    badge = ""
    if show_build_badge:
        badge_label = " | ".join(
            part
            for part in (
                str(build_info.get("entry_name") or "").strip(),
                str(build_info.get("js_file") or "").strip(),
            )
            if part
        )
        badge_detail = str(build_info.get("dist_dir") or "").strip()
        badge = (
            "<div id=\"hybrisight-ui-build-badge\" "
            "style=\"position:fixed;right:12px;bottom:12px;z-index:9999;max-width:min(48rem,calc(100vw - 24px));"
            "padding:8px 10px;border-radius:999px;border:1px solid rgba(148,163,184,.28);"
            "background:rgba(15,23,42,.88);color:#e2e8f0;font:500 12px/1.3 ui-monospace,SFMono-Regular,Menlo,monospace;"
            "box-shadow:0 12px 32px rgba(15,23,42,.24);backdrop-filter:blur(8px)\">"
            f"{html.escape(badge_label)}"
            f"{'<br />' + html.escape(badge_detail) if badge_detail else ''}"
            "</div>"
        )
    doc = (
        "<!doctype html><html><head><meta charset=\"utf-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />"
        f"<title>{html.escape(title)}</title><link rel=\"icon\" href=\"/favicon.ico\" sizes=\"any\" />{meta}{inline_paint}{links}</head>"
        f"<body class=\"theme-{html.escape(theme)}\" data-authenticated=\"{'true' if authenticated else 'false'}\">{body}{badge}{script}</body></html>"
    )
    response = HTMLResponse(doc)
    response.headers["Cache-Control"] = "no-store, max-age=0"
    response.headers["Pragma"] = "no-cache"
    return response


def _show_build_badge(request: Any) -> bool:
    return os.getenv("HYBRISIGHT_WEB_SHOW_BUILD_INFO", "").strip().lower() in {"1", "true", "yes", "on"}


def render_app_home(
    *,
    request: Any,
    db: Session,
    ensure_csrf_session: Any,
    frontend_asset_urls: Any,
    show_internal_ops_nav: Any,
    internal_ops_pending_count: Any,
    cli_info: Any,
    get_theme: Any,
    tenant_is_active: Any,
) -> HTMLResponse:
    page = request.query_params.get("page", "").strip().lower()
    public_pages = set(PUBLIC_PAGE_PATHS)
    if page in APP_PUBLIC_REDIRECT_PATHS:
        params = [(key, value) for key, value in request.query_params.multi_items() if key != "page"]
        target = PUBLIC_PAGE_PATHS[page]
        if params:
            target = f"{target}?{urlencode(params, doseq=True)}"
        return RedirectResponse(url=target, status_code=302)
    protected_pages = {"dashboard", "report", "upload", "api-keys", "finding", "board", "operations", "download-cli", "knowledge-base"}
    requested_public = False if page in protected_pages else page in public_pages

    user_id = request.session.get("user_id")
    if not user_id and not requested_public:
        return RedirectResponse(url="/login", status_code=302)

    user = db.query(User).filter(User.id == user_id).first() if user_id else None
    if user_id and not user:
        return RedirectResponse(url="/login", status_code=302)
    if user:
        tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
        if tenant is None or not tenant_is_active(tenant):
            request.session.clear()
            return RedirectResponse(url="/login", status_code=302)

    csrf_token = ensure_csrf_session(request)
    css_urls, js_url, build_info = frontend_asset_urls()
    pending_count = internal_ops_pending_count(user) if user and show_internal_ops_nav(user) else 0
    ui_bootstrap = {}
    if user:
        protected_view_enabled = os.getenv("HYBRISIGHT_WEB_PROTECTED_VIEW", "false").strip().lower() in {"1", "true", "yes", "on"}
        ui_bootstrap = {
            "user": {"email": user.email, "role": user.role},
            "internal_ops": {"visible": show_internal_ops_nav(user), "pending_count": pending_count},
            "cli": cli_info(),
            "protected_view": {"enabled": protected_view_enabled},
            "taxonomy": PRODUCT_TAXONOMY,
            "upload": {"max_bytes": MAX_UPLOAD_BYTES},
        }

    message_input = f'<input type="hidden" id="server-message" value="{html.escape(request.query_params.get("message", ""))}" />' if request.query_params.get("message") else ""
    ui_bootstrap_json = json.dumps(ui_bootstrap).replace("</", "<\\/")
    body = f'<input type="hidden" id="csrf_token" name="csrf_token" value="{html.escape(csrf_token)}" />{message_input}<script id="ui-bootstrap" type="application/json">{ui_bootstrap_json}</script><div id="root"></div>'
    return _render_spa_document(
        title="HybriSight Portal",
        theme=get_theme(request),
        authenticated=bool(user),
        css_urls=css_urls,
        js_url=js_url,
        body=body,
        build_info=build_info,
        show_build_badge=_show_build_badge(request),
    )


def render_public_home(
    *,
    request: Any,
    ensure_csrf_session: Any,
    frontend_asset_urls: Any,
    get_theme: Any,
    page: str = "landing",
) -> HTMLResponse:
    csrf_token = ensure_csrf_session(request)
    css_urls, js_url, build_info = frontend_asset_urls()
    bootstrap = {
        "csrf_token": csrf_token,
        "theme": get_theme(request),
        "page": page,
        "taxonomy": PRODUCT_TAXONOMY,
        "recaptcha_site_key": recaptcha_site_key(),
        "build": {
            "entry_name": build_info.get("entry_name"),
            "js_file": build_info.get("js_file"),
            "dist_dir": build_info.get("dist_dir"),
        },
    }
    bootstrap_json = json.dumps(bootstrap).replace("</", "<\\/")
    body = f'<script id="landing-bootstrap" type="application/json">{bootstrap_json}</script><div id="root"></div>'
    return _render_spa_document(
        title="HybriSight",
        theme=get_theme(request),
        authenticated=False,
        css_urls=css_urls,
        js_url=js_url,
        body=body,
        build_info=build_info,
        show_build_badge=_show_build_badge(request),
    )


def render_landing_home(
    *,
    request: Any,
    ensure_csrf_session: Any,
    frontend_asset_urls: Any,
    get_theme: Any,
) -> HTMLResponse:
    return render_public_home(
        request=request,
        ensure_csrf_session=ensure_csrf_session,
        frontend_asset_urls=frontend_asset_urls,
        get_theme=get_theme,
        page="landing",
    )


def render_share_view(
    *,
    request: Any,
    token: str,
    ensure_csrf_session: Any,
    frontend_asset_urls: Any,
    get_theme: Any,
) -> HTMLResponse:
    """Render the SPA for a public shared report link. No login required."""
    csrf_token = ensure_csrf_session(request)
    css_urls, js_url, build_info = frontend_asset_urls()
    ui_bootstrap = {"share_token": token}
    ui_bootstrap_json = json.dumps(ui_bootstrap).replace("</", "<\\/")
    body = (
        f'<input type="hidden" id="csrf_token" name="csrf_token" value="{html.escape(csrf_token)}" />'
        f'<script id="ui-bootstrap" type="application/json">{ui_bootstrap_json}</script>'
        f'<div id="root"></div>'
    )
    return _render_spa_document(
        title="HybriSight Shared Report",
        theme=get_theme(request),
        authenticated=False,
        css_urls=css_urls,
        js_url=js_url,
        body=body,
        build_info=build_info,
        show_build_badge=False,
    )
