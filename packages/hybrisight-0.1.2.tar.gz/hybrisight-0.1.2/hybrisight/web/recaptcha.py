# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
import os

import httpx

RECAPTCHA_VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify"

logger = logging.getLogger(__name__)


def recaptcha_enabled() -> bool:
    return bool(os.getenv("RECAPTCHA_SECRET_KEY"))


def recaptcha_site_key() -> str:
    return os.getenv("RECAPTCHA_SITE_KEY", "")


def verify_recaptcha(token: str | None) -> bool:
    secret = os.getenv("RECAPTCHA_SECRET_KEY")
    if not secret:
        return True
    if not token:
        logger.warning("reCAPTCHA token is missing")
        return False
    try:
        resp = httpx.post(
            RECAPTCHA_VERIFY_URL,
            data={"secret": secret, "response": token},
            timeout=10,
        )
        result = resp.json()
        if not result.get("success"):
            codes = result.get("error-codes", [])
            logger.warning("reCAPTCHA verification failed: %s", codes)
            return False
        return True
    except Exception as exc:
        logger.error("reCAPTCHA verification error: %s", exc)
        return False
