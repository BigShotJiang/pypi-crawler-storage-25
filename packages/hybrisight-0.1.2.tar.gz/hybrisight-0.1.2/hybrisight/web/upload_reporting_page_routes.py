# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import logging
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote_plus

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlalchemy.orm import Session

from hybrisight.web.continuity_overrides import continuity_metadata_for_upload
from hybrisight.web.models import ScanUpload, Tenant, User
from hybrisight.web.reassessment_series import ensure_upload_reassessment_context
from hybrisight.web.service import UploadValidationError
from hybrisight.web.app_paths import ensure_pdf_renderer_available
from hybrisight.pdf import render_pdf_report
from hybrisight.web.upload_locks import new_upload_execution_state, next_tenant_upload_seq, tenant_upload_lock


def register_upload_reporting_page_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    parse_uploaded_scan_payload: Callable[[str, str, str | None, str | None], tuple[Any, str]],
    parse_optional_signature_file: Callable[..., Any],
    verify_signature_status: Callable[..., tuple[bool | None, str | None]],
    validate_upload_basics: Callable[..., None],
    validate_scan_payload: Callable[..., Any],
    safe_store_artifact: Callable[[str, bytes], str],
    delete_artifact: Callable[[str], bool],
    save_pdf_ready_summary: Callable[..., None],
    save_html_report: Callable[..., None],
    build_dashboard_payload: Callable[[Any], dict[str, Any]],
    build_trend_summary: Callable[[Session, int, ScanUpload, Any], dict[str, Any]],
) -> None:
    def _split_source_detail(value: str) -> tuple[str, str | None]:
        if value.startswith("native_export:"):
            return "native_export", value.split(":", 1)[1] or None
        return value, None

    @app.get("/upload", response_class=HTMLResponse)
    def upload_page(request: Request, user: User = Depends(require_role("analyst"))) -> HTMLResponse:
        return RedirectResponse(url="/app?page=upload", status_code=302)

    @app.post("/upload")
    async def upload_scan(
        request: Request,
        file: UploadFile = File(...),
        signature_file: UploadFile | None = File(None),
        source_type: str = Form("scanresult"),
        provider: str | None = Form(None),
        export_type: str | None = Form(None),
        engagement_label: str | None = Form(None),
        engagement_key: str | None = Form(None),
        scope_label: str | None = Form(None),
        scope_fingerprint: str | None = Form(None),
        series_label: str | None = Form(None),
        series_key: str | None = Form(None),
        series_cadence: str | None = Form(None),
        allow_duplicate: bool = Form(False),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("analyst")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        payload = await file.read()
        artifact_sha256 = hashlib.sha256(payload).hexdigest()

        try:
            validate_upload_basics(file.content_type, payload)
            result, resolved_source_type = parse_uploaded_scan_payload(
                payload_text=payload.decode("utf-8"),
                source_type=source_type,
                provider=provider,
                export_type=export_type,
            )
            stored_source_type, source_detail = _split_source_detail(resolved_source_type)
            sidecar_signature = await parse_optional_signature_file(signature_file)
            signature_valid, signature_source = verify_signature_status(result, sidecar_signature, db=db, tenant_id=user.tenant_id)
            with tenant_upload_lock(user.tenant_id):
                existing = (
                    db.query(ScanUpload)
                    .filter(ScanUpload.tenant_id == user.tenant_id, ScanUpload.artifact_sha256 == artifact_sha256)
                    .order_by(ScanUpload.id.desc())
                    .first()
                )
                if existing is not None and not allow_duplicate:
                    log_event(db, request, event_type="upload_duplicate_blocked", user=user, metadata={"existing_upload_id": existing.id, "api": False, "source_type": source_type})
                    message = quote_plus(f"Duplicate artifact blocked: upload #{existing.id} already matches this file. Tick 'Allow duplicate upload' to force re-import.")
                    return RedirectResponse(url=f"/app?page=upload&message={message}", status_code=302)
                artifact_path = safe_store_artifact(user.tenant.slug, payload)
                execution_state = new_upload_execution_state(db, user.tenant_id)
                continuity_metadata, continuity_source, artifact_continuity_digest = continuity_metadata_for_upload(
                    result,
                    engagement_label=engagement_label,
                    engagement_key=engagement_key,
                    scope_label=scope_label,
                    scope_fingerprint=scope_fingerprint,
                    series_label=series_label,
                    series_key=series_key,
                    series_cadence=series_cadence,
                )
                upload = ScanUpload(
                    tenant_upload_seq=next_tenant_upload_seq(db, user.tenant_id),
                    tenant_id=user.tenant_id,
                    uploaded_by_id=user.id,
                    source_type=stored_source_type,
                    source_detail=source_detail,
                    provider=result.scanned_provider.value,
                    schema_version=result.schema_version,
                    coverage_level=result.coverage_level.value,
                    signature_valid=signature_valid,
                    signature_source=signature_source,
                    asset_count=result.asset_count,
                    finding_count=result.finding_count,
                    generated_at_utc=result.generated_at_utc,
                    artifact_path=artifact_path,
                    artifact_sha256=artifact_sha256,
                    continuity_metadata_json=json.dumps(continuity_metadata, sort_keys=True) if continuity_metadata else None,
                    continuity_metadata_source=continuity_source,
                    artifact_continuity_digest=artifact_continuity_digest,
                    raw_json=result.model_dump_json(indent=2),
                    execution_state=execution_state,
                    execution_state_updated_at=datetime.now(UTC),
                    execution_state_updated_by_user_id=user.id,
                )
                db.add(upload)
                db.flush()
                ensure_upload_reassessment_context(db, upload)
                db.commit()
                db.refresh(upload)
            log_event(db, request, event_type="upload_created", user=user, metadata={"upload_id": upload.id, "source_type": stored_source_type, "source_detail": source_detail, "signature_valid": signature_valid, "continuity_metadata": bool(continuity_metadata), "continuity_source": continuity_source})
            return RedirectResponse(url=f"/app?page=dashboard&upload={upload.id}", status_code=302)
        except (UploadValidationError, ValueError, json.JSONDecodeError) as exc:
            log_event(db, request, event_type="upload_validation_failed", user=user, metadata={"api": False, "source_type": source_type, "provider": provider, "export_type": export_type, "error": str(exc)})
            message = quote_plus(f"Upload failed: {exc}")
            return RedirectResponse(url=f"/app?page=upload&message={message}", status_code=302)

    @app.post("/uploads/{upload_id}/delete")
    def delete_upload(
        upload_id: int,
        request: Request,
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")
        removed = delete_artifact(upload.artifact_path)
        db.delete(upload)
        db.commit()
        log_event(db, request, event_type="upload_deleted", user=user, metadata={"upload_id": upload_id, "artifact_removed": removed})
        msg = quote_plus(f"Upload {upload_id} deleted")
        return RedirectResponse(url=f"/app?message={msg}", status_code=302)

    @app.get("/dashboard/{upload_id}", response_class=HTMLResponse)
    def dashboard(
        upload_id: int,
        request: Request,
        export_error: str | None = None,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("viewer")),
    ) -> HTMLResponse:
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")
        log_event(db, request, event_type="report_viewed", user=user, metadata={"upload_id": upload.id})
        redirect = f"/app?page=dashboard&upload={upload.id}"
        if export_error:
            redirect += f"&export_error={quote_plus(export_error)}"
        return RedirectResponse(url=redirect, status_code=302)

    @app.get("/dashboard/{upload_id}/export/html")
    def export_dashboard_html(upload_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require_role("viewer"))) -> Response:
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")
        result = validate_scan_payload(upload.raw_json)
        trend_summary = build_trend_summary(db, tenant_id=user.tenant_id, upload=upload, current_result=result)
        t = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / f"hybrisight-report-{upload.id}.html"
            save_html_report(result, out, trend_summary=trend_summary, client_name=t.name if t else None, gated_compliance=False)
            content = out.read_text(encoding="utf-8")

        log_event(db, request, event_type="report_exported", user=user, metadata={"upload_id": upload.id, "format": "html-server-render"})
        headers = {"Content-Disposition": f'attachment; filename="hybrisight-report-{upload.id}.html"'}
        return Response(content=content, media_type="text/html", headers=headers)

    @app.get("/dashboard/{upload_id}/export/pdf")
    def export_dashboard_pdf(upload_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require_role("viewer"))) -> Response:
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")
        
        try:
            ensure_pdf_renderer_available()
            result = validate_scan_payload(upload.raw_json)
            trend_summary = build_trend_summary(db, tenant_id=user.tenant_id, upload=upload, current_result=result)
            t2 = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
            _pdf_timeout = 60

            def _render() -> bytes:
                with tempfile.TemporaryDirectory() as td:
                    out_path = Path(td) / f"hybrisight-report-{upload.id}.pdf"
                    render_pdf_report(result, out_path, trend_summary=trend_summary, client_name=t2.name if t2 else None)
                    return out_path.read_bytes()

            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(_render)
                    content = future.result(timeout=_pdf_timeout)
            except concurrent.futures.TimeoutError:
                logging.getLogger(__name__).warning("pdf_export_timeout upload_id=%s timeout=%ds", upload.id, _pdf_timeout)
                raise HTTPException(
                    status_code=503,
                    detail=f"PDF generation timed out after {_pdf_timeout} seconds. Try the HTML export instead.",
                )
            log_event(db, request, event_type="report_exported", user=user, metadata={"upload_id": upload.id, "format": "pdf-server-render"})
            return Response(
                content=content,
                media_type="application/pdf",
                headers={"Content-Disposition": f'attachment; filename="hybrisight-report-{upload.id}.pdf"'}
            )
        except HTTPException:
            raise
        except Exception as exc:
            # Fallback to client-side print if server rendering fails or dependencies missing
            log_event(db, request, event_type="report_exported", user=user, metadata={"upload_id": upload.id, "format": "pdf-react-fallback", "error": str(exc)})
            return RedirectResponse(url=f"/app?page=report&upload={upload.id}&export=pdf", status_code=302)

    @app.get("/dashboard/{upload_id}/export/pdf-json")
    def export_dashboard_pdf_json(
        upload_id: int,
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("viewer")),
    ) -> Response:
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")

        result = validate_scan_payload(upload.raw_json)
        trend_summary = build_trend_summary(db, tenant_id=user.tenant_id, upload=upload, current_result=result)
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / f"hybrisight-pdf-summary-{upload.id}.json"
            save_pdf_ready_summary(result, out, trend_summary=trend_summary)
            content = out.read_text(encoding="utf-8")

        log_event(db, request, event_type="report_exported", user=user, metadata={"upload_id": upload.id, "format": "pdf-json"})
        headers = {"Content-Disposition": f'attachment; filename="hybrisight-pdf-summary-{upload.id}.json"'}
        return Response(content=content, media_type="application/json", headers=headers)

    @app.get("/dashboard/{upload_id}/finding/{finding_idx}", response_class=HTMLResponse)
    def finding_detail(
        upload_id: int,
        finding_idx: int,
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("viewer")),
    ) -> HTMLResponse:
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")
        result = validate_scan_payload(upload.raw_json)
        findings = build_dashboard_payload(result)["findings_sorted"]
        if finding_idx < 0 or finding_idx >= len(findings):
            raise HTTPException(status_code=404, detail="Finding not found")
        log_event(db, request, event_type="finding_viewed", user=user, metadata={"upload_id": upload.id, "finding_idx": finding_idx})
        return RedirectResponse(url=f"/app?page=finding&upload={upload.id}&finding={finding_idx}", status_code=302)
