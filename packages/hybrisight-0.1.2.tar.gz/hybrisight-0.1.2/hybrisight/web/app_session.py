# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
import secrets

from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.models import Tenant, User
from hybrisight.web.security import has_role


def ensure_csrf_session(request: Request) -> str:
    token = request.session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        request.session["csrf_token"] = token
    return token


def get_theme(request: Request) -> str:
    cookie_theme = request.cookies.get("hybrisight_theme")
    if cookie_theme in {"light", "dark", "board"}:
        return cookie_theme
    theme = request.session.get("theme", "board")
    return theme if theme in {"light", "dark", "board"} else "board"


def validate_csrf(request: Request, csrf_token: str | None) -> None:
    if os.getenv("HYBRISIGHT_DISABLE_CSRF", "").lower() in {"1", "true", "yes"}:
        return
    expected = request.session.get("csrf_token")
    if not expected or not csrf_token or not secrets.compare_digest(expected, csrf_token):
        raise HTTPException(status_code=403, detail="CSRF validation failed")


def normalized_tenant_status(tenant: Tenant | None) -> str:
    if tenant is None:
        return "unknown"
    value = (tenant.status or "active").strip().lower()
    return value if value else "active"


def tenant_is_active(tenant: Tenant | None) -> bool:
    return normalized_tenant_status(tenant) == "active"


def tenant_state_message(tenant: Tenant) -> str:
    status = normalized_tenant_status(tenant)
    if status == "suspended":
        return "Tenant access is suspended. Contact your administrator."
    if status == "archived":
        return "Tenant access is archived. Contact your administrator."
    return f"Tenant access is not active ({status})."


def get_current_user(request: Request, db: Session = Depends()) -> User:
    user_id = request.session.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=401, detail="Invalid session")
    tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
    if tenant is None:
        raise HTTPException(status_code=401, detail="Invalid session tenant")
    if not tenant_is_active(tenant):
        request.session.clear()
        raise HTTPException(status_code=403, detail=tenant_state_message(tenant))
    return user


def optional_user_from_session(request: Request, db: Session = Depends()) -> User | None:
    user_id = request.session.get("user_id")
    if not user_id:
        return None
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        return None
    tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
    if tenant is None or not tenant_is_active(tenant):
        return None
    return user


def require_role(required_role: str, get_current_user_fn):
    def _check(user: User = Depends(get_current_user_fn)) -> User:
        if not has_role(user.role, required_role):
            raise HTTPException(status_code=403, detail="Insufficient role")
        return user

    return _check
