# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from hybrisight.web.internal_ops_api_audit_routes import register_internal_ops_api_audit_routes
from hybrisight.web.internal_ops_api_download_routes import register_internal_ops_api_download_routes
from hybrisight.web.internal_ops_api_health_rules_routes import register_internal_ops_api_health_rules_routes
from hybrisight.web.internal_ops_api_journey_routes import register_internal_ops_api_journey_routes
from hybrisight.web.internal_ops_api_request_routes import register_internal_ops_api_request_routes
from hybrisight.web.internal_ops_api_storage_routes import register_internal_ops_api_storage_routes
from hybrisight.web.internal_ops_api_tenant_routes import register_internal_ops_api_tenant_routes
from hybrisight.web.internal_ops_api_upload_routes import register_internal_ops_api_upload_routes
from hybrisight.web.models import Tenant, User


def register_internal_ops_api_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Any, User], None],
    security_posture_checks: Callable[..., list[dict[str, Any]]],
    load_lockstep_health: Callable[[], dict[str, Any]],
    validate_csrf: Callable[[Any, str | None], None],
    parse_bool_like: Callable[[Any, bool], bool],
    internal_rule_setting_key: Callable[[str], str],
    internal_rule_toggle_key_prefix: str,
    sanitize_onboarding_reason: Callable[[str], str],
    normalized_tenant_status: Callable[[Tenant], str],
    get_client_ip: Callable[[Any], str | None],
    log_event: Callable[..., None],
) -> None:
    register_internal_ops_api_health_rules_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
        security_posture_checks=security_posture_checks,
        load_lockstep_health=load_lockstep_health,
        validate_csrf=validate_csrf,
        parse_bool_like=parse_bool_like,
        internal_rule_setting_key=internal_rule_setting_key,
        internal_rule_toggle_key_prefix=internal_rule_toggle_key_prefix,
        log_event=log_event,
    )
    register_internal_ops_api_request_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
        validate_csrf=validate_csrf,
        sanitize_onboarding_reason=sanitize_onboarding_reason,
        log_event=log_event,
    )
    register_internal_ops_api_journey_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
        validate_csrf=validate_csrf,
        log_event=log_event,
    )
    register_internal_ops_api_tenant_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
        validate_csrf=validate_csrf,
        sanitize_onboarding_reason=sanitize_onboarding_reason,
        normalized_tenant_status=normalized_tenant_status,
        get_client_ip=get_client_ip,
        log_event=log_event,
    )
    register_internal_ops_api_audit_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
    )
    register_internal_ops_api_storage_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
        validate_csrf=validate_csrf,
        parse_bool_like=parse_bool_like,
        normalized_tenant_status=normalized_tenant_status,
        log_event=log_event,
    )
    register_internal_ops_api_upload_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
    )
    register_internal_ops_api_download_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        enforce_internal_ops_access=enforce_internal_ops_access,
    )
