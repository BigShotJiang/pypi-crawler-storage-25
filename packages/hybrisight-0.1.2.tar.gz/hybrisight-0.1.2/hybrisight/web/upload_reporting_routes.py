# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import FastAPI
from sqlalchemy.orm import Session

from hybrisight.web.upload_reporting_api_routes import register_upload_reporting_api_routes
from hybrisight.web.upload_reporting_page_routes import register_upload_reporting_page_routes


def register_upload_reporting_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[..., None],
    log_event: Callable[..., None],
    parse_uploaded_scan_payload: Callable[..., tuple[Any, str]],
    parse_optional_signature_file: Callable[..., Any],
    verify_signature_status: Callable[..., tuple[bool | None, str | None]],
    validate_upload_basics: Callable[..., None],
    validate_scan_payload: Callable[..., Any],
    safe_store_artifact: Callable[[str, bytes], str],
    delete_artifact: Callable[[str], bool],
    save_pdf_ready_summary: Callable[..., None],
    save_html_report: Callable[..., None],
    build_dashboard_payload: Callable[[Any], dict[str, Any]],
    build_trend_summary: Callable[..., dict[str, Any]],
    summary_display: Callable[[dict[str, Any]], dict[str, str]],
    build_execution_progress: Callable[..., dict[str, Any]],
    taxonomy: dict[str, Any],
    notify_upload_summary: Callable[[str, int, int, int], bool] | None = None,
) -> None:
    register_upload_reporting_page_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        validate_csrf=validate_csrf,
        log_event=log_event,
        parse_uploaded_scan_payload=parse_uploaded_scan_payload,
        parse_optional_signature_file=parse_optional_signature_file,
        verify_signature_status=verify_signature_status,
        validate_upload_basics=validate_upload_basics,
        validate_scan_payload=validate_scan_payload,
        safe_store_artifact=safe_store_artifact,
        delete_artifact=delete_artifact,
        save_pdf_ready_summary=save_pdf_ready_summary,
        save_html_report=save_html_report,
        build_dashboard_payload=build_dashboard_payload,
        build_trend_summary=build_trend_summary,
    )
    register_upload_reporting_api_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        validate_csrf=validate_csrf,
        log_event=log_event,
        parse_uploaded_scan_payload=parse_uploaded_scan_payload,
        parse_optional_signature_file=parse_optional_signature_file,
        verify_signature_status=verify_signature_status,
        validate_upload_basics=validate_upload_basics,
        validate_scan_payload=validate_scan_payload,
        safe_store_artifact=safe_store_artifact,
        delete_artifact=delete_artifact,
        build_dashboard_payload=build_dashboard_payload,
        build_trend_summary=build_trend_summary,
        summary_display=summary_display,
        build_execution_progress=build_execution_progress,
        taxonomy=taxonomy,
        notify_upload_summary=notify_upload_summary,
    )
