# SPDX-License-Identifier: Apache-2.0

PRODUCT_TAXONOMY = {
    "hero_headline": "Executive Cloud Governance, Executed.",
    "hero_subhead": "A productized cloud governance assessment for UK SMEs. Board-ready risk and cost clarity with a tracked 90-day stabilisation roadmap.",
    "posture_icon": "activity",
    "actions": {
        "upload": "Request Baseline Access",
        "sample": "View Sample Governance Brief",
        "advisory": "Contact Advisory",
        "cli": "Scan Your Cloud — Free",
    },
    "kpis": [
        {"label": "Risk", "value": "Exposure Tier", "icon": "shield"},
        {"label": "Financial", "value": "Recoverable Cost", "icon": "trending-up"},
        {"label": "Execution", "value": "90-Day Stabilisation", "icon": "calendar"},
    ],
}
