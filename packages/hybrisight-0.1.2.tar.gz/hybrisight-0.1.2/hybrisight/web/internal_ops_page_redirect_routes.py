# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any, Callable
from urllib.parse import quote_plus

from fastapi import Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from hybrisight.web.models import AuditLog, Tenant, User


def register_internal_ops_page_redirect_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    validate_csrf: Callable[[Request, str | None], None],
    slugify_tenant_slug: Callable[[str], str],
    is_valid_company_name: Callable[[str], bool],
    is_valid_email: Callable[[str], bool],
    validate_tenant_password: Callable[[str], str | None],
    hash_password: Callable[[str], str],
    log_event: Callable[..., None],
) -> None:
    @app.get("/internal/ops", response_class=HTMLResponse)
    def internal_ops_dashboard(
        request: Request,
        q: str | None = None,
        audit_event: str | None = None,
        audit_path: str | None = None,
        audit_tenant: str | None = None,
        audit_user_email: str | None = None,
        audit_request_id: str | None = None,
        audit_from: str | None = None,
        audit_to: str | None = None,
        audit_include_http_requests: bool = False,
        audit_limit: int = 20,
        audit_page: int = 1,
        message: str | None = None,
        error: str | None = None,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> HTMLResponse:
        enforce_internal_ops_access(request, user)
        query = request.url.query
        return RedirectResponse(url=f"/app?page=operations&{query}" if query else "/app?page=operations", status_code=302)

    @app.get("/internal/ops/audit", response_class=HTMLResponse)
    def internal_ops_audit_logs_page(
        request: Request,
        audit_event: str | None = None,
        audit_path: str | None = None,
        audit_tenant: str | None = None,
        audit_user_email: str | None = None,
        audit_request_id: str | None = None,
        audit_from: str | None = None,
        audit_to: str | None = None,
        audit_include_http_requests: bool = False,
        audit_limit: int = 20,
        audit_page: int = 1,
        message: str | None = None,
        error: str | None = None,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> HTMLResponse:
        enforce_internal_ops_access(request, user)
        return RedirectResponse(url="/app?page=operations&tab=audit", status_code=302)

    @app.get("/internal/ops/compliance", response_class=HTMLResponse)
    def internal_ops_compliance_logs_page(
        request: Request,
        message: str | None = None,
        error: str | None = None,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> HTMLResponse:
        enforce_internal_ops_access(request, user)
        return RedirectResponse(url="/app?page=operations&tab=compliance", status_code=302)

    @app.post("/internal/ops/tenants/create")
    def internal_ops_create_tenant(
        request: Request,
        tenant_name: str = Form(...),
        tenant_slug: str = Form(""),
        admin_email: str = Form(...),
        admin_password: str = Form(...),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        name = tenant_name.strip()
        email = admin_email.strip().lower()
        slug = slugify_tenant_slug(tenant_slug if tenant_slug.strip() else tenant_name)
        password = admin_password.strip()
        if not name or not slug or not email or not password:
            return RedirectResponse(url="/internal/ops?error=Missing+required+fields", status_code=302)
        if not is_valid_company_name(name):
            return RedirectResponse(url="/internal/ops?error=Tenant+name+must+be+between+2+and+255+characters", status_code=302)
        if not is_valid_email(email):
            return RedirectResponse(url="/internal/ops?error=Enter+a+valid+tenant+admin+email", status_code=302)
        password_error = validate_tenant_password(password)
        if password_error:
            return RedirectResponse(url=f"/internal/ops?error={quote_plus(password_error)}", status_code=302)
        if db.query(Tenant).filter(Tenant.slug == slug).first() is not None:
            return RedirectResponse(url="/internal/ops?error=Tenant+slug+already+exists", status_code=302)
        if db.query(User).filter(User.email == email).first() is not None:
            return RedirectResponse(url="/internal/ops?error=Admin+email+already+exists", status_code=302)

        tenant = Tenant(name=name, slug=slug)
        db.add(tenant)
        db.flush()
        db.add(User(email=email, password_hash=hash_password(password), role="tenant_admin", tenant_id=tenant.id))
        db.commit()
        log_event(db, request, event_type="tenant_provisioned", user=user, metadata={"tenant_id": tenant.id, "tenant_slug": slug, "admin_email": email})
        return RedirectResponse(url=f"/internal/ops?message=Provisioned+tenant+{quote_plus(name)}", status_code=302)

    @app.post("/internal/ops/audit/purge")
    def internal_ops_purge_audit_logs(
        request: Request,
        older_than_days: int = Form(90),
        confirm_text: str = Form(""),
        include_http_requests: bool = Form(False),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        if confirm_text.strip().upper() != "PURGE":
            return RedirectResponse(url="/internal/ops/audit?error=Type+PURGE+to+confirm+audit+log+deletion", status_code=302)
        days = max(1, min(int(older_than_days or 90), 3650))
        cutoff = datetime.now(UTC) - timedelta(days=days)
        purge_query = db.query(AuditLog).filter(AuditLog.created_at < cutoff)
        if not include_http_requests:
            purge_query = purge_query.filter(AuditLog.event_type != "http_request")
        deleted_count = purge_query.delete(synchronize_session=False)
        db.commit()
        log_event(db, request, event_type="internal_ops_audit_purged", user=user, metadata={"older_than_days": days, "include_http_requests": bool(include_http_requests), "deleted_count": deleted_count})
        return RedirectResponse(url=f"/internal/ops/audit?message=Purged+{deleted_count}+audit+events+older+than+{days}+days", status_code=302)
