# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import hashlib
import logging
import os
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

import boto3
from botocore.exceptions import ClientError

from hybrisight.web.service_constants import UploadValidationError

_log = logging.getLogger(__name__)


def _get_s3_client():
    endpoint_url = os.getenv("HYBRISIGHT_S3_ENDPOINT_URL")
    return boto3.client("s3", endpoint_url=endpoint_url)


def _store_to_s3(bucket: str, key: str, payload: bytes) -> str:
    _get_s3_client().put_object(Bucket=bucket, Key=key, Body=payload, ServerSideEncryption="AES256")
    return f"s3://{bucket}/{key}"


def _delete_from_s3(path: str) -> bool:
    if not path.startswith("s3://"):
        return False
    try:
        parts = path[5:].split("/", 1)
        if len(parts) != 2:
            return False
        bucket, key = parts
        _get_s3_client().delete_object(Bucket=bucket, Key=key)
        return True
    except ClientError as exc:
        _log.warning(
            "s3_delete_failed path=%s error_code=%s message=%s — artifact may be orphaned in S3",
            path,
            exc.response.get("Error", {}).get("Code", "unknown"),
            exc.response.get("Error", {}).get("Message", str(exc)),
        )
        return False


def safe_store_artifact(tenant_slug: str, payload: bytes, suffix: str = ".json") -> str:
    storage_type = os.getenv("HYBRISIGHT_STORAGE_TYPE", "local").lower()
    tenant_hash = hashlib.sha256(tenant_slug.encode("utf-8")).hexdigest()[:16]
    artifact_name = f"{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}_{uuid4().hex}{suffix}"
    key = f"{tenant_hash}/{artifact_name}"

    if storage_type == "s3":
        bucket = os.getenv("HYBRISIGHT_S3_BUCKET")
        if not bucket:
            raise RuntimeError("HYBRISIGHT_S3_BUCKET must be set when storage type is S3")
        return _store_to_s3(bucket, key, payload)

    base = Path(os.getenv("HYBRISIGHT_WEB_STORAGE_DIR", "./hybrisight_web_storage")).resolve()
    tenant_dir = (base / tenant_hash).resolve()
    tenant_dir.mkdir(parents=True, exist_ok=True)
    if not str(tenant_dir).startswith(str(base)):
        raise UploadValidationError("Unsafe tenant storage path")

    artifact_path = (tenant_dir / artifact_name).resolve()
    if not str(artifact_path).startswith(str(tenant_dir)):
        raise UploadValidationError("Unsafe artifact path")

    artifact_path.write_bytes(payload)
    return str(artifact_path)


def delete_artifact(path: str) -> bool:
    if path.startswith("s3://"):
        return _delete_from_s3(path)

    try:
        p = Path(path).resolve()
        if p.exists() and p.is_file():
            p.unlink()
            return True
    except Exception:
        return False
    return False
