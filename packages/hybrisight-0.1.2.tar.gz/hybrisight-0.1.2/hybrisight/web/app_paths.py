# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import importlib
import importlib.metadata
import json
import os
import time
from pathlib import Path
from urllib.request import urlopen
from typing import Any

APP_DIR = Path(__file__).resolve().parent


def _looks_like_project_root(base: Path) -> bool:
    return (
        (base / "pyproject.toml").exists()
        and (base / "hybrisight" / "web").exists()
        and ((base / "frontend" / "src").exists() or (base / "frontend" / "dist").exists())
    )


def resolve_project_root() -> Path | None:
    configured = os.getenv("HYBRISIGHT_PROJECT_ROOT")
    if configured:
        candidate = Path(configured).expanduser().resolve()
        if _looks_like_project_root(candidate):
            return candidate

    cwd = Path.cwd().resolve()
    candidates = [cwd, *cwd.parents, APP_DIR, *APP_DIR.parents]
    seen: set[Path] = set()
    for base in candidates:
        if base in seen:
            continue
        seen.add(base)
        if _looks_like_project_root(base):
            return base
    return None


def resolve_static_dir() -> Path:
    direct = APP_DIR / "static"
    if direct.exists():
        return direct
    root = resolve_project_root()
    if root:
        candidate = root / "hybrisight" / "web" / "static"
        if candidate.exists():
            return candidate
    return direct


def resolve_frontend_dist_dir() -> Path:
    root = resolve_project_root()
    if root:
        candidate = root / "frontend" / "dist"
        if candidate.exists():
            return candidate
    return APP_DIR.parents[1] / "frontend" / "dist"


def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


_CLI_LATEST_CACHE: dict[str, Any] = {"version": "unknown", "expires_at": 0.0}


def fetch_latest_cli_version_from_pypi(*, json_url: str, timeout_seconds: float) -> str:
    try:
        with urlopen(json_url, timeout=timeout_seconds) as response:
            payload = json.loads(response.read().decode("utf-8"))
        info = payload.get("info") if isinstance(payload, dict) else None
        latest = (info.get("version") if isinstance(info, dict) else None) or ""
        latest = str(latest).strip()
        return latest or "unknown"
    except Exception:
        return "unknown"


def latest_cli_version(*, json_url: str) -> str:
    pinned = os.getenv("HYBRISIGHT_CLI_LATEST_VERSION", "").strip()
    if pinned:
        return pinned
    if not json_url:
        return "unknown"
    ttl_seconds = max(300, int(os.getenv("HYBRISIGHT_CLI_LATEST_CACHE_SECONDS", "21600")))
    now = time.time()
    cached_version = str(_CLI_LATEST_CACHE.get("version") or "unknown")
    expires_at = float(_CLI_LATEST_CACHE.get("expires_at") or 0.0)
    if now < expires_at and cached_version:
        return cached_version
    timeout_seconds = max(0.5, float(os.getenv("HYBRISIGHT_CLI_PYPI_TIMEOUT_SECONDS", "2.5")))
    latest = fetch_latest_cli_version_from_pypi(json_url=json_url, timeout_seconds=timeout_seconds)
    _CLI_LATEST_CACHE["version"] = latest
    _CLI_LATEST_CACHE["expires_at"] = now + ttl_seconds
    return latest


def cli_info() -> dict[str, str]:
    _default_install = (
        "curl -sSL https://hybrisight.agapii.org/install.sh -o install.sh && bash install.sh"
    )
    _default_registry_url = "https://gitlab.agapii.org/agapii/hybrisight/-/packages"
    install_command = os.getenv("HYBRISIGHT_CLI_INSTALL_COMMAND", _default_install).strip() or _default_install
    # HYBRISIGHT_CLI_REGISTRY_URL — link shown on the CLI page ("View Registry")
    registry_url = (
        os.getenv("HYBRISIGHT_CLI_REGISTRY_URL")
        or os.getenv("HYBRISIGHT_CLI_PYPI_URL")  # legacy alias
        or _default_registry_url
    ).strip() or _default_registry_url
    # GitLab Package Registry does not expose a pypi.org-style JSON API.
    # Latest version is resolved via HYBRISIGHT_CLI_LATEST_VERSION env var (set in GitLab CI/CD Variables).
    # HYBRISIGHT_CLI_PYPI_JSON_URL is kept for optional self-hosted pypi-compatible endpoints.
    pypi_json_url = os.getenv("HYBRISIGHT_CLI_PYPI_JSON_URL", "").strip()
    configured_version = os.getenv("HYBRISIGHT_CLI_VERSION", "").strip()
    if configured_version:
        installed_version = configured_version
    else:
        try:
            installed_version = importlib.metadata.version("hybrisight")
        except importlib.metadata.PackageNotFoundError:
            installed_version = "unknown"
    latest_version = latest_cli_version(json_url=pypi_json_url)
    _default_script_url = "https://hybrisight.agapii.org/install.sh"
    install_script_url = (
        os.getenv("HYBRISIGHT_CLI_INSTALL_SCRIPT_URL", _default_script_url).strip()
        or _default_script_url
    )
    return {
        "install_command": install_command,
        "install_script_url": install_script_url,
        "version": installed_version,
        "latest_version": latest_version,
        "registry_url": registry_url,
    }


def ensure_pdf_renderer_available() -> str:
    if env_bool("HYBRISIGHT_WEB_SKIP_PDF_PREFLIGHT", False):
        return "skipped"
    try:
        importlib.import_module("weasyprint")
        return "weasyprint"
    except Exception as weasy_exc:
        try:
            importlib.import_module("playwright")
            return "playwright"
        except Exception as playwright_exc:
            raise RuntimeError(
                "PDF renderer dependency is missing. "
                "Install WeasyPrint (recommended) or Playwright before starting hybrisight-web. "
                f"Details: weasyprint={type(weasy_exc).__name__}; playwright={type(playwright_exc).__name__}."
            ) from weasy_exc
