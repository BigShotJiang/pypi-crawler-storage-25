# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import csv
import json
import re
from datetime import UTC, datetime
from io import StringIO
from typing import Any

from hybrisight.engine import apply_scoring
from hybrisight.models import CoverageLevel, Effort, Finding, Provider, ScanResult, Severity
from hybrisight.web.service_constants import SUPPORTED_PDF_READY_SUMMARY_DOCUMENT_TYPES
from hybrisight.web.service_native_detect import _norm_key, looks_like_prowler_finding, looks_like_prowler_ocsf_finding

_PROWLER_STATUS_FAILED = {"fail", "failed", "fail_muted", "failed_muted"}
_PROWLER_STATUS_IGNORE = {"pass", "passed", "info", "informational", "manual", "not_applicable", "not-applicable"}
_PROWLER_SEVERITY_MAP = {
    "critical": Severity.critical,
    "high": Severity.high,
    "medium": Severity.medium,
    "low": Severity.low,
    "info": Severity.info,
    "informational": Severity.info,
}
_PROWLER_RULE_PREFIX_MAP = [
    ("iam_", ("AWS.IAM.PROWLER", "iam", "security", "medium")),
    ("identity_", ("AWS.IAM.PROWLER", "iam", "security", "medium")),
    ("accessanalyzer_", ("AWS.IAM.PROWLER", "iam", "security", "medium")),
    ("ec2_securitygroup_", ("AWS.NETWORK.PROWLER", "network", "security", "medium")),
    ("vpc_", ("AWS.NETWORK.PROWLER", "network", "security", "medium")),
    ("networkacl_", ("AWS.NETWORK.PROWLER", "network", "security", "medium")),
    ("elb_", ("AWS.NETWORK.PROWLER", "network", "security", "medium")),
    ("s3_", ("AWS.S3.PROWLER", "s3", "security", "medium")),
    ("kms_", ("AWS.S3.PROWLER", "storage", "security", "medium")),
    ("rds_", ("AWS.RESILIENCE.PROWLER", "backup", "resilience", "high")),
    ("backup_", ("AWS.RESILIENCE.PROWLER", "backup", "resilience", "high")),
    ("dr_", ("AWS.RESILIENCE.PROWLER", "backup", "resilience", "high")),
    ("cost_", ("AWS.COST.PROWLER", "cost", "cost", "low")),
    ("computeoptimizer_", ("AWS.COST.PROWLER", "cost", "cost", "low")),
    ("tagging_", ("AWS.OPS.PROWLER", "ops", "ops", "medium")),
    ("cloudtrail_", ("AWS.OPS.PROWLER", "ops", "ops", "medium")),
    ("config_", ("AWS.OPS.PROWLER", "ops", "ops", "medium")),
    ("guardduty_", ("AWS.OPS.PROWLER", "ops", "ops", "medium")),
    ("account_", ("AWS.OPS.PROWLER", "ops", "ops", "medium")),
    ("organizations_", ("AWS.OPS.PROWLER", "ops", "ops", "medium")),
]


def _finding(
    rule_id: str,
    provider: Provider,
    service: str,
    resource_id: str,
    title: str,
    category: str,
    severity: Severity,
    description: str,
    business_impact: str,
    remediation: str,
    annual_cost: float | None = None,
    remediation_effort: Effort = Effort.medium,
) -> Finding:
    return Finding(
        id=rule_id,
        provider=provider,
        service=service,
        resource_id=resource_id,
        title=title,
        category=category,
        severity=severity,
        description=description,
        business_impact=business_impact,
        estimated_annual_cost_impact_gbp=annual_cost,
        remediation_guidance=remediation,
        remediation_effort=remediation_effort,
    )


def _scan_result_from_pdf_ready_summary(raw: dict[str, Any]) -> ScanResult:
    summary = raw.get("executive_summary", {})
    findings_raw = raw.get("top_10_findings", [])
    findings = [Finding.model_validate(item) for item in findings_raw if isinstance(item, dict)]

    provider = str(summary.get("provider", "aws")).lower()
    coverage_level = str(summary.get("coverage_level", "unknown")).lower()
    return ScanResult(
        schema_version=str(summary.get("schema_version", "1.1")),
        coverage_level=CoverageLevel(coverage_level),
        scoring_version=str(summary.get("scoring_version", "1.0")),
        risk_index=float(summary["risk_index"]) if summary.get("risk_index") is not None else None,
        posture_score=float(summary["posture_score"]) if summary.get("posture_score") is not None else None,
        confidence_adjusted_score=float(summary["confidence_adjusted_score"]) if summary.get("confidence_adjusted_score") is not None else None,
        top_finding_ids=[f.id for f in findings] if findings else None,
        scanned_provider=Provider(provider),
        asset_count=int(summary.get("assets", 0)),
        finding_count=int(summary.get("findings", len(findings))),
        findings=findings,
        generated_at_utc=str(summary.get("generated_at_utc", datetime.now(UTC).isoformat())),
        signature=None,
    )


def validate_scan_payload(payload: str) -> ScanResult:
    raw = json.loads(payload)
    document_type = raw.get("document_type")
    if isinstance(document_type, str) and document_type in SUPPORTED_PDF_READY_SUMMARY_DOCUMENT_TYPES:
        return apply_scoring(_scan_result_from_pdf_ready_summary(raw))
    return apply_scoring(ScanResult.model_validate(raw))


def _prowler_domain(check_id: str) -> tuple[str, str, str, str]:
    cid = check_id.lower()
    for prefix, mapped in _PROWLER_RULE_PREFIX_MAP:
        if cid.startswith(prefix):
            return mapped
    return ("AWS.OPS.PROWLER", "ops", "ops", "medium")


def _sanitize_rule_suffix(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").upper() or "CHECK"


def _summarize_prowler_statuses(items: list[Any], is_match: Any, status_getter: Any) -> dict[str, int]:
    total = failed = passed = manual = 0
    for item in items:
        if not isinstance(item, dict) or not is_match(item):
            continue
        status_raw = str(status_getter(item) or "").strip().lower()
        if status_raw in {"pass", "passed"}:
            total, passed = total + 1, passed + 1
        elif status_raw in _PROWLER_STATUS_FAILED:
            total, failed = total + 1, failed + 1
        elif status_raw == "manual":
            manual += 1
    return {"total": total, "failed": failed, "passed": passed, "manual": manual}


def normalize_prowler_findings(payload: str) -> list[Finding]:
    raw = json.loads(payload)
    items = raw.get("findings") if isinstance(raw, dict) and isinstance(raw.get("findings"), list) else raw if isinstance(raw, list) else []
    findings: list[Finding] = []
    for item in items:
        if not isinstance(item, dict) or not looks_like_prowler_finding(item):
            continue
        status_raw = str(_norm_key(item, "Status") or _norm_key(item, "status") or "").strip().lower()
        if status_raw in _PROWLER_STATUS_IGNORE or status_raw not in _PROWLER_STATUS_FAILED:
            continue
        check_id = str(_norm_key(item, "CheckID") or _norm_key(item, "CheckId") or _norm_key(item, "check_id") or "unknown_check").strip()
        sev_raw = str(_norm_key(item, "Severity") or _norm_key(item, "severity") or "medium").strip().lower()
        severity = _PROWLER_SEVERITY_MAP.get(sev_raw, Severity.medium)
        rule_prefix, service, category, effort = _prowler_domain(check_id)
        findings.append(
            _finding(
                rule_id=f"{rule_prefix}.{_sanitize_rule_suffix(check_id)}",
                provider=Provider.aws,
                service=service,
                resource_id=str(_norm_key(item, "ResourceId") or _norm_key(item, "resource_id") or _norm_key(item, "ResourceArn") or _norm_key(item, "resource_arn") or "unknown"),
                title=str(_norm_key(item, "CheckTitle") or _norm_key(item, "check_title") or check_id),
                category=category,
                severity=severity,
                description=str(_norm_key(item, "StatusExtended") or _norm_key(item, "status_extended") or _norm_key(item, "Description") or _norm_key(item, "description") or "Imported Prowler failed control."),
                business_impact="Failed cloud security control increases operational and governance exposure.",
                remediation="Apply the control recommendation in Prowler output and validate remediation evidence.",
                remediation_effort=Effort(effort),
            )
        )
    return findings


def summarize_prowler_findings(payload: str) -> dict[str, int]:
    raw = json.loads(payload)
    items = raw.get("findings") if isinstance(raw, dict) and isinstance(raw.get("findings"), list) else raw if isinstance(raw, list) else []
    return _summarize_prowler_statuses(items, looks_like_prowler_finding, lambda item: _norm_key(item, "Status") or _norm_key(item, "status"))


def normalize_prowler_ocsf_findings(payload: str) -> list[Finding]:
    try:
        raw = json.loads(payload)
    except json.JSONDecodeError:
        return []
    items = raw if isinstance(raw, list) else raw.get("findings") if isinstance(raw, dict) and isinstance(raw.get("findings"), list) else []
    findings: list[Finding] = []
    for item in items:
        if not isinstance(item, dict) or not looks_like_prowler_ocsf_finding(item):
            continue

        status_raw = str(item.get("status_code") or "").strip().lower()
        if status_raw in _PROWLER_STATUS_IGNORE or status_raw not in _PROWLER_STATUS_FAILED:
            continue

        metadata = item.get("metadata") or {}
        check_id = str(metadata.get("event_code") or "unknown_check").strip()
        sev_raw = str(item.get("severity") or "medium").strip().lower()
        severity = _PROWLER_SEVERITY_MAP.get(sev_raw, Severity.medium)

        finding_info = item.get("finding_info") or {}
        remediation = item.get("remediation") or {}
        resources = item.get("resources") or []
        resource_id = resources[0].get("uid") if resources and isinstance(resources[0], dict) else "unknown"

        # Look for potential cost signal in unmapped data if available
        annual_cost = None
        unmapped = item.get("unmapped") or {}
        if isinstance(unmapped, dict):
            cost_val = unmapped.get("estimated_annual_cost_impact_gbp")
            if isinstance(cost_val, (int, float)):
                annual_cost = float(cost_val)

        rule_prefix, service, category, effort = _prowler_domain(check_id)

        findings.append(
            _finding(
                rule_id=f"{rule_prefix}.{_sanitize_rule_suffix(check_id)}",
                provider=Provider.aws,
                service=service,
                resource_id=str(resource_id),
                title=str(finding_info.get("title") or check_id),
                category=category,
                severity=severity,
                description=str(item.get("message") or finding_info.get("desc") or "Imported Prowler failed control (OCSF)."),
                business_impact="Failed cloud security control increases operational and governance exposure.",
                remediation=str(remediation.get("desc") or "Apply the control recommendation in Prowler output and validate remediation evidence."),
                remediation_effort=Effort(effort),
                annual_cost=annual_cost,
            )
        )
    return findings


def summarize_prowler_ocsf_findings(payload: str) -> dict[str, int]:
    try:
        raw = json.loads(payload)
    except json.JSONDecodeError:
        return {"total": 0, "failed": 0, "passed": 0, "manual": 0}
    items = raw if isinstance(raw, list) else raw.get("findings") if isinstance(raw, dict) and isinstance(raw.get("findings"), list) else []
    return _summarize_prowler_statuses(items, looks_like_prowler_ocsf_finding, lambda item: item.get("status_code"))


def severity_from_text(value: str | None, fallback: Severity = Severity.medium) -> Severity:
    normalized = str(value or "").strip().lower()
    if normalized in {"critical", "sev1", "s1"}:
        return Severity.critical
    if normalized in {"high", "error", "red", "sev2", "s2"}:
        return Severity.high
    if normalized in {"medium", "warning", "warn", "amber", "sev3", "s3"}:
        return Severity.medium
    if normalized in {"low", "ok", "green", "sev4", "s4"}:
        return Severity.low
    if normalized in {"info", "informational"}:
        return Severity.info
    return fallback


def normalize_trusted_advisor_items(items: list[Any]) -> list[Finding]:
    findings: list[Finding] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        source = str(item.get("checkId") or item.get("check_id") or item.get("id") or item.get("name") or "CHECK")
        findings.append(
            _finding(
                rule_id=f"AWS.TRUSTED_ADVISOR.{_sanitize_rule_suffix(source)}",
                provider=Provider.aws,
                service="trustedadvisor",
                resource_id=str(item.get("resource_id") or item.get("resourceId") or item.get("resource") or item.get("account_id") or item.get("accountId") or item.get("checkId") or item.get("id") or "trusted-advisor"),
                title=str(item.get("name") or item.get("title") or item.get("check_name") or "Trusted Advisor Check"),
                category="security",
                severity=severity_from_text(str(item.get("severity") or item.get("risk_level") or item.get("status") or ""), fallback=Severity.medium),
                description=str(item.get("description") or item.get("details") or item.get("metadata") or item.get("status_reason") or "Imported AWS Trusted Advisor recommendation."),
                business_impact="Trusted Advisor indicates unresolved cloud posture risk and operational exposure.",
                remediation="Prioritize this recommendation in your Phase 1 stabilization backlog and validate closure evidence.",
            )
        )
    return findings


def normalize_trusted_advisor_csv(payload: str) -> list[Finding]:
    reader = csv.DictReader(StringIO(payload))
    items = [{
        "checkId": row.get("check_id") or row.get("checkId") or row.get("id"),
        "name": row.get("check_name") or row.get("name") or row.get("title"),
        "severity": row.get("severity") or row.get("risk_level"),
        "status": row.get("status") or row.get("check_status"),
        "description": row.get("description") or row.get("details") or row.get("metadata"),
        "resource_id": row.get("resource_id") or row.get("resourceId") or row.get("resource"),
        "account_id": row.get("account_id") or row.get("accountId"),
    } for row in reader]
    return normalize_trusted_advisor_items(items)
