# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
import os

from alembic import command
from alembic.config import Config
from sqlalchemy import inspect, text

from hybrisight.web import db as web_db

logger = logging.getLogger(__name__)

def _resolve_alembic_cfg() -> str:
    env_path = os.getenv("HYBRISIGHT_ALEMBIC_CONFIG")
    if env_path:
        return env_path
    candidates = [
        os.path.join(os.path.dirname(web_db.__file__), "..", "..", "alembic.ini"),
        "/app/alembic.ini",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "alembic.ini"),
    ]
    for p in candidates:
        p = os.path.normpath(p)
        if os.path.exists(p):
            return p
    return candidates[0]


ALEMBIC_CFG_PATH = _resolve_alembic_cfg()
ALEMBIC_REVISION_TABLE = "alembic_version"

LEGACY_REVISION_TABLE = "schema_revisions"


def _alembic_cfg() -> Config:
    cfg = Config(ALEMBIC_CFG_PATH)
    cfg.set_main_option("sqlalchemy.url", web_db.DATABASE_URL)
    return cfg


def _has_legacy_revision_table() -> bool:
    inspector = inspect(web_db.engine)
    return LEGACY_REVISION_TABLE in set(inspector.get_table_names())


def _has_alembic_revision() -> bool:
    inspector = inspect(web_db.engine)
    table_names = set(inspector.get_table_names())
    if ALEMBIC_REVISION_TABLE not in table_names:
        return False
    with web_db.engine.begin() as conn:
        result = conn.execute(
            text(f"SELECT version_num FROM {ALEMBIC_REVISION_TABLE} LIMIT 1")
        ).scalar()
        return result is not None


def _stamp_alembic(revision: str = "head") -> None:
    cfg = _alembic_cfg()
    command.stamp(cfg, revision)


def _upgrade_alembic(revision: str = "head") -> None:
    cfg = _alembic_cfg()
    command.upgrade(cfg, revision)


def schema_bootstrap_allowed(database_url: str) -> bool:
    explicit = os.getenv("HYBRISIGHT_WEB_SCHEMA_BOOTSTRAP", "").strip().lower()
    if explicit in {"1", "true", "yes", "on"}:
        return True
    if explicit in {"0", "false", "no", "off"}:
        return False
    return database_url.startswith("sqlite")


def create_all_tables() -> None:
    web_db.Base.metadata.create_all(bind=web_db.engine)


def migrate_legacy_to_alembic() -> None:
    logger.info("Migrating from legacy revision tracking to Alembic...")
    with web_db.engine.begin() as conn:
        conn.execute(text(f"DROP TABLE IF EXISTS {LEGACY_REVISION_TABLE}"))
    _stamp_alembic("head")
    logger.info("Legacy revision table removed. Alembic now manages schema.")


def validate_schema_current() -> None:
    inspector = inspect(web_db.engine)
    table_names = set(inspector.get_table_names())
    if not table_names:
        raise RuntimeError("Database is empty. Run `hybrisight-web migrate` or enable local schema bootstrap.")
    if not _has_alembic_revision():
        raise RuntimeError(
            "Database schema revision is not tracked by Alembic. "
            "Run `hybrisight-web migrate` to sync."
        )
    for table in web_db.Base.metadata.sorted_tables:
        if table.name not in table_names:
            raise RuntimeError(f"Database table '{table.name}' is missing. Run `hybrisight-web migrate`.")
        existing_columns = {column["name"] for column in inspector.get_columns(table.name)}
        required_columns = {column.name for column in table.columns}
        missing = sorted(required_columns - existing_columns)
        if missing:
            raise RuntimeError(
                f"Database table '{table.name}' is missing columns: {', '.join(missing)}. "
                "Run `hybrisight-web migrate`."
            )


def migrate_to_head() -> str:
    if _has_alembic_revision():
        _upgrade_alembic()
        with web_db.engine.begin() as conn:
            result = conn.execute(
                text(f"SELECT version_num FROM {ALEMBIC_REVISION_TABLE} LIMIT 1")
            ).scalar()
            return str(result) if result else "unknown"
    create_all_tables()
    if _has_legacy_revision_table():
        migrate_legacy_to_alembic()
    else:
        _stamp_alembic("head")
    return _current_alembic_revision()


def _current_alembic_revision() -> str:
    with web_db.engine.begin() as conn:
        result = conn.execute(
            text(f"SELECT version_num FROM {ALEMBIC_REVISION_TABLE} LIMIT 1")
        ).scalar()
    return str(result) if result else "unknown"


def ensure_schema_ready(database_url: str, auto_migrate: bool) -> None:
    inspector = inspect(web_db.engine)
    table_names = set(inspector.get_table_names())
    local_sqlite_bootstrap = database_url.startswith("sqlite") and schema_bootstrap_allowed(database_url)
    if not table_names:
        if auto_migrate or local_sqlite_bootstrap:
            migrate_to_head()
            return
        raise RuntimeError("Database is empty. Run `hybrisight-web migrate` or enable schema bootstrap.")
    if auto_migrate or local_sqlite_bootstrap:
        migrate_to_head()
        return
    validate_schema_current()


def alembic_head_revision() -> str:
    from alembic.script import ScriptDirectory
    cfg = _alembic_cfg()
    script = ScriptDirectory.from_config(cfg)
    return script.get_current_head() or "unknown"


__all__ = [
    "alembic_head_revision",
    "ensure_schema_ready",
    "migrate_to_head",
    "schema_bootstrap_allowed",
    "validate_schema_current",
]
