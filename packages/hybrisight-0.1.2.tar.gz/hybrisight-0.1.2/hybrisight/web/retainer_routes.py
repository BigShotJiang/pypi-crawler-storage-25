# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any, Callable

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from hybrisight.engine import apply_scoring
from hybrisight.models import ScanResult
from hybrisight.scoring_projection import build_cumulative_phase_projection
from hybrisight.scoring_priority import prioritize_findings
from hybrisight.web.models import User
from hybrisight.web.models_core import ScanUpload
from hybrisight.web.models_engagements import Engagement


RETAINER_YEARLY_GBP = 10_000

RETAINER_DELIVERABLES = [
    {"id": "monthly_scan", "label": "Monthly re-baseline scan", "cadence": "monthly", "count_per_quarter": 3},
    {"id": "quarterly_brief", "label": "Quarterly executive brief", "cadence": "quarterly", "count_per_quarter": 1},
    {"id": "remediation_progress", "label": "Remediation progress tracking", "cadence": "monthly", "count_per_quarter": 3},
    {"id": "compliance_tracking", "label": "Compliance posture tracking", "cadence": "quarterly", "count_per_quarter": 1},
    {"id": "slack_support", "label": "Slack-based advisory support", "cadence": "ongoing", "count_per_quarter": None},
]


def _quarter_boundaries(dt: datetime | None = None) -> dict[str, str]:
    now = dt or datetime.now(UTC)
    q = (now.month - 1) // 3 + 1
    q_start = datetime(now.year, 3 * q - 2, 1, tzinfo=UTC)
    q_end = datetime(now.year, 3 * q + 1, 1, tzinfo=UTC) - timedelta(seconds=1) if q < 4 else datetime(now.year, 12, 31, 23, 59, 59, tzinfo=UTC)
    return {"quarter": f"Q{q} {now.year}", "start": q_start.isoformat(), "end": q_end.isoformat()}


def _scan_metrics(raw_json: str | None) -> dict[str, Any] | None:
    if not raw_json:
        return None
    try:
        import json
        parsed = json.loads(raw_json)
        result = ScanResult(**parsed)
        scored = apply_scoring(result)
        waste = sum((f.estimated_annual_cost_impact_gbp or 0.0) for f in scored.findings)
        severities = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for finding in scored.findings:
            sev = str(finding.severity.value if hasattr(finding.severity, "value") else finding.severity).lower()
            if sev in severities:
                severities[sev] += 1
        return {
            "posture_score": round(float(scored.posture_score or 0.0), 1),
            "risk_index": round(float(scored.risk_index or 0.0), 1),
            "confidence_adjusted_score": round(float(scored.confidence_adjusted_score or 0.0), 1),
            "estimated_waste": round(float(waste), 2),
            "critical_count": severities["critical"],
            "high_count": severities["high"],
            "finding_count": len(scored.findings),
        }
    except Exception:
        return None


def _build_roadmap(raw_json: str | None) -> dict[str, Any] | None:
    if not raw_json:
        return None
    try:
        import json
        parsed = json.loads(raw_json)
        result = ScanResult(**parsed)
        scored = apply_scoring(result)
        sorted_findings = prioritize_findings(scored.findings)
        projection = build_cumulative_phase_projection(
            prioritized_findings=sorted_findings,
            asset_count=scored.asset_count,
            coverage_level=scored.coverage_level,
        )
        return projection
    except Exception:
        return None


def _compute_retainer_trend(eng: Engagement, db: Session, tenant_id: int) -> dict[str, Any]:
    uploads = (
        db.query(ScanUpload)
        .filter(
            ScanUpload.tenant_id == tenant_id,
            ScanUpload.created_at >= eng.created_at,
        )
        .order_by(ScanUpload.created_at.asc())
        .all()
    )

    series = []
    baseline = None
    latest = None
    for u in uploads:
        metrics = _scan_metrics(u.raw_json)
        if metrics is None:
            continue
        entry = {
            "upload_id": u.id,
            "date": u.created_at.isoformat(),
            **metrics,
        }
        series.append(entry)
        latest = entry

    if series:
        baseline = series[0]

    latest_raw = uploads[-1].raw_json if uploads else None
    roadmap = _build_roadmap(latest_raw)

    savings = round((baseline["estimated_waste"] - latest["estimated_waste"]), 2) if baseline and latest else 0.0

    critical_delta = None
    high_delta = None
    if baseline and latest:
        critical_delta = latest["critical_count"] - baseline["critical_count"]
        high_delta = latest["high_count"] - baseline["high_count"]

    return {
        "has_data": len(series) > 0,
        "upload_count": len(series),
        "baseline": baseline,
        "latest": latest,
        "estimated_waste_saved_gbp": savings,
        "critical_count_delta": critical_delta,
        "high_count_delta": high_delta,
        "series": series,
        "roadmap": roadmap,
    }


def register_retainer_routes(
    app: Any,
    get_db: Callable,
    require_role: Callable,
) -> None:
    @app.get("/api/v1/retainer/status")
    def retainer_status(
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("viewer")),
    ) -> dict:
        engagement = (
            db.query(Engagement)
            .filter(
                Engagement.tenant_id == user.tenant_id,
                Engagement.package_type == "retainer",
            )
            .order_by(Engagement.created_at.desc())
            .first()
        )

        if not engagement:
            return {"active": False, "engagement": None}

        is_active = engagement.workflow_state == "retainer_active"
        quarter = _quarter_boundaries()

        recent_scans = (
            db.query(ScanUpload)
            .filter(
                ScanUpload.tenant_id == user.tenant_id,
                ScanUpload.created_at >= engagement.created_at,
            )
            .order_by(ScanUpload.created_at.desc())
            .limit(10)
            .all()
        )

        scans = [
            {
                "id": s.id,
                "provider": s.provider,
                "finding_count": s.finding_count,
                "asset_count": s.asset_count,
                "created_at": s.created_at.isoformat(),
                "execution_state": s.execution_state,
            }
            for s in recent_scans
        ]

        this_quarter_scans = [s for s in scans if s["created_at"] >= quarter["start"]]

        trend = _compute_retainer_trend(engagement, db, user.tenant_id)

        return {
            "active": is_active,
            "engagement": {
                "id": engagement.id,
                "title": engagement.title,
                "created_at": engagement.created_at.isoformat(),
                "currency": engagement.currency,
                "fixed_fee_amount": str(engagement.fixed_fee_amount) if engagement.fixed_fee_amount else None,
                "paid_amount": str(engagement.paid_amount) if engagement.paid_amount else None,
                "invoice_status": engagement.invoice_status,
                "next_step": engagement.next_step,
            },
            "annual_price_gbp": RETAINER_YEARLY_GBP,
            "quarter": quarter,
            "deliverables": RETAINER_DELIVERABLES,
            "scans_this_quarter": len(this_quarter_scans),
            "recent_scans": scans,
            "trend": trend,
        }
