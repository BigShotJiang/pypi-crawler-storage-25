# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import FastAPI
from sqlalchemy.orm import Session

from hybrisight.web.auth_account_routes import register_auth_account_routes
from hybrisight.web.auth_login_routes import register_auth_login_routes
from hybrisight.web.auth_mfa_theme_routes import register_auth_mfa_theme_routes
from hybrisight.web.models import Tenant, User


def register_auth_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    get_current_user: Callable[..., User],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[..., None],
    log_event: Callable[..., None],
    slugify_tenant_slug: Callable[[str], str],
    is_valid_company_name: Callable[[str], bool],
    is_valid_email: Callable[[str], bool],
    validate_tenant_password: Callable[[str], str | None],
    tenant_is_active: Callable[[Tenant | None], bool],
    tenant_state_message: Callable[[Tenant], str],
    normalized_tenant_status: Callable[[Tenant | None], str],
    hash_password: Callable[[str], str],
    verify_password: Callable[[str, str], bool],
    needs_password_rehash: Callable[[str], bool],
    generate_totp_secret: Callable[[], str],
    verify_totp_code: Callable[[str, str], bool],
    login_max_failed_attempts: int,
    login_lockout_minutes: int,
    send_onboarding_request_notification: Callable[[str, str, str], None],
) -> None:
    register_auth_login_routes(
        app,
        get_db=get_db,
        get_current_user=get_current_user,
        validate_csrf=validate_csrf,
        log_event=log_event,
        slugify_tenant_slug=slugify_tenant_slug,
        is_valid_company_name=is_valid_company_name,
        is_valid_email=is_valid_email,
        validate_tenant_password=validate_tenant_password,
        tenant_is_active=tenant_is_active,
        tenant_state_message=tenant_state_message,
        normalized_tenant_status=normalized_tenant_status,
        hash_password=hash_password,
        verify_password=verify_password,
        needs_password_rehash=needs_password_rehash,
        verify_totp_code=verify_totp_code,
        login_max_failed_attempts=login_max_failed_attempts,
        login_lockout_minutes=login_lockout_minutes,
        send_onboarding_request_notification=send_onboarding_request_notification,
    )
    register_auth_account_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        validate_csrf=validate_csrf,
        log_event=log_event,
        is_valid_email=is_valid_email,
        validate_tenant_password=validate_tenant_password,
        hash_password=hash_password,
        verify_password=verify_password,
    )
    register_auth_mfa_theme_routes(
        app,
        get_db=get_db,
        require_role=require_role,
        validate_csrf=validate_csrf,
        log_event=log_event,
        generate_totp_secret=generate_totp_secret,
        verify_totp_code=verify_totp_code,
        verify_password=verify_password,
    )
