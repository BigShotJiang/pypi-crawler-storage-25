# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import hashlib
import json
import logging
from datetime import UTC, datetime
from typing import Any, Callable

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from sqlalchemy.orm import Session

from hybrisight.web.engagement_policy import can_release_report
from hybrisight.web.models import ScanUpload, User
from hybrisight.web.models_core import Tenant
from hybrisight.web.models_engagements import Engagement
from hybrisight.web.internal_ops_upload_quality import extract_collection_quality
from hybrisight.web.service_ingestion_policy import build_upload_ingestion_summary
from hybrisight.web.service import UploadValidationError
from hybrisight.web.service_signature import extract_signature_metadata
from hybrisight.web.reassessment_series import continuity_context_payload, ensure_upload_reassessment_context
from hybrisight.web.upload_delete_service import delete_upload_with_dependencies
from hybrisight.web.upload_assessment_summary import extract_assessment_summary
from hybrisight.web.continuity_overrides import continuity_metadata_for_upload
from hybrisight.web.upload_locks import new_upload_execution_state, next_tenant_upload_seq, tenant_upload_lock


def register_upload_reporting_api_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    parse_uploaded_scan_payload: Callable[[str, str, str | None, str | None], tuple[Any, str]],
    parse_optional_signature_file: Callable[..., Any],
    verify_signature_status: Callable[..., tuple[bool | None, str | None]],
    validate_upload_basics: Callable[..., None],
    validate_scan_payload: Callable[..., Any],
    safe_store_artifact: Callable[[str, bytes], str],
    delete_artifact: Callable[[str], bool],
    build_dashboard_payload: Callable[[Any], dict[str, Any]],
    build_trend_summary: Callable[[Session, int, ScanUpload, Any], dict[str, Any]],
    summary_display: Callable[[dict[str, Any]], dict[str, str]],
    build_execution_progress: Callable[[Session, int, int], dict[str, Any]],
    taxonomy: dict[str, Any],
    notify_upload_summary: Callable[[str, int, int, int], bool] | None = None,
    ) -> None:
    def _split_source_detail(value: str) -> tuple[str, str | None]:
        if value.startswith("native_export:"):
            return "native_export", value.split(":", 1)[1] or None
        return value, None

    @app.post("/api/v1/uploads")
    async def upload_scan_api(
        request: Request,
        file: UploadFile = File(...),
        signature_file: UploadFile | None = File(None),
        source_type: str = Form("scanresult"),
        provider: str | None = Form(None),
        export_type: str | None = Form(None),
        engagement_label: str | None = Form(None),
        engagement_key: str | None = Form(None),
        scope_label: str | None = Form(None),
        scope_fingerprint: str | None = Form(None),
        series_label: str | None = Form(None),
        series_key: str | None = Form(None),
        series_cadence: str | None = Form(None),
        allow_duplicate: bool = Form(False),
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("analyst")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        payload = await file.read()
        artifact_sha256 = hashlib.sha256(payload).hexdigest()
        try:
            validate_upload_basics(file.content_type, payload)
            try:
                payload_text = payload.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise UploadValidationError("Upload contains invalid UTF-8 data") from exc
            result, resolved_source_type = parse_uploaded_scan_payload(payload_text=payload_text, source_type=source_type, provider=provider, export_type=export_type)
        except (UploadValidationError, ValueError, json.JSONDecodeError) as exc:
            log_event(db, request, event_type="upload_validation_failed", user=user, metadata={"api": True, "source_type": source_type, "provider": provider, "export_type": export_type, "error": str(exc)})
            raise HTTPException(status_code=400, detail=str(exc))

        stored_source_type, source_detail = _split_source_detail(resolved_source_type)
        sidecar_signature = await parse_optional_signature_file(signature_file)
        signature_valid, signature_source = verify_signature_status(result, sidecar_signature, db=db, tenant_id=user.tenant_id)
        with tenant_upload_lock(user.tenant_id):
            existing = (
                db.query(ScanUpload)
                .filter(ScanUpload.tenant_id == user.tenant_id, ScanUpload.artifact_sha256 == artifact_sha256)
                .order_by(ScanUpload.id.desc())
                .first()
            )
            if existing is not None and not allow_duplicate:
                log_event(db, request, event_type="upload_duplicate_blocked", user=user, metadata={"existing_upload_id": existing.id, "api": True, "source_type": source_type})
                raise HTTPException(status_code=409, detail={"message": "Duplicate artifact blocked", "existing_upload_id": existing.id, "hint": "Set allow_duplicate=true to force re-import."})
            artifact_path = safe_store_artifact(user.tenant.slug, payload)
            execution_state = new_upload_execution_state(db, user.tenant_id)
            continuity_metadata, continuity_source, artifact_continuity_digest = continuity_metadata_for_upload(
                result,
                engagement_label=engagement_label,
                engagement_key=engagement_key,
                scope_label=scope_label,
                scope_fingerprint=scope_fingerprint,
                series_label=series_label,
                series_key=series_key,
                series_cadence=series_cadence,
            )
            upload = ScanUpload(
                tenant_upload_seq=next_tenant_upload_seq(db, user.tenant_id),
                tenant_id=user.tenant_id,
                uploaded_by_id=user.id,
                source_type=stored_source_type,
                source_detail=source_detail,
                provider=result.scanned_provider.value,
                schema_version=result.schema_version,
                coverage_level=result.coverage_level.value,
                signature_valid=signature_valid,
                signature_source=signature_source,
                asset_count=result.asset_count,
                finding_count=result.finding_count,
                generated_at_utc=result.generated_at_utc,
                artifact_path=artifact_path,
                artifact_sha256=artifact_sha256,
                continuity_metadata_json=json.dumps(continuity_metadata, sort_keys=True) if continuity_metadata else None,
                continuity_metadata_source=continuity_source,
                artifact_continuity_digest=artifact_continuity_digest,
                raw_json=result.model_dump_json(indent=2),
                execution_state=execution_state,
                execution_state_updated_at=datetime.now(UTC),
                execution_state_updated_by_user_id=user.id,
            )
            db.add(upload)
            db.flush()
            ensure_upload_reassessment_context(db, upload)
            db.commit()
            db.refresh(upload)
        ingestion = build_upload_ingestion_summary(upload)
        log_event(db, request, event_type="upload_created", user=user, metadata={"upload_id": upload.id, "api": True, "source_type": stored_source_type, "source_detail": source_detail, "continuity_metadata": bool(continuity_metadata), "continuity_source": continuity_source})
        if notify_upload_summary:
            critical_count = sum(1 for f in result.findings if f.severity.value == 'critical')
            notify_upload_summary(user.email, upload.id, upload.finding_count, critical_count)
        response: dict = {"upload_id": upload.id, "finding_count": upload.finding_count, "coverage_level": upload.coverage_level, "signature_valid": upload.signature_valid, "ingestion": ingestion}
        if allow_duplicate and upload.reassessment_series_id is not None:
            response["duplicate_warning"] = (
                "This artifact was imported as a duplicate of an existing upload in a reassessment series. "
                "Trend data and posture trajectory for this series may be affected. "
                "Review the series context before drawing conclusions from trend analysis."
            )
        return response

    @app.post("/api/v1/uploads/{upload_id}/delete")
    def delete_upload_api(
        upload_id: int,
        request: Request,
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")
        removed = delete_artifact(upload.artifact_path)
        delete_upload_with_dependencies(db, upload)
        db.commit()
        log_event(db, request, event_type="upload_deleted", user=user, metadata={"upload_id": upload_id, "artifact_removed": removed, "api": True})
        return {"ok": True, "upload_id": upload_id, "artifact_removed": removed}

    @app.get("/api/v1/uploads/{upload_id}")
    def get_upload(
        upload_id: int,
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("viewer")),
    ) -> dict:
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")

        payment_gate: dict[str, Any] | None = None
        gate_engagement = (
            db.query(Engagement)
            .filter(
                Engagement.tenant_id == user.tenant_id,
                Engagement.package_type == "baseline",
                Engagement.payment_required_before_release == True,
            )
            .order_by(Engagement.created_at.desc())
            .first()
        )
        if gate_engagement and not can_release_report(gate_engagement):
            payment_gate = {
                "blocked": True,
                "amount_gbp": float(gate_engagement.fixed_fee_amount or 0) if gate_engagement.fixed_fee_amount else None,
                "invoice_status": gate_engagement.invoice_status,
                "invoice_url": gate_engagement.invoice_external_url,
                "engagement_id": gate_engagement.id,
            }

        result = validate_scan_payload(upload.raw_json)
        signature_meta = extract_signature_metadata(upload.raw_json)
        try:
            context = build_dashboard_payload(result)
        except Exception as ctx_exc:
            logging.getLogger(__name__).warning(
                "dashboard_payload_build_error upload_id=%s error=%s", upload_id, ctx_exc
            )
            raise HTTPException(status_code=500, detail="Failed to build dashboard data for this upload. The artifact may have unexpected content. Try re-uploading or contact support.")
        # Inject real tenant name from DB so in-app report shows correct client name
        tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
        if tenant and context.get("meta"):
            context["meta"]["tenant_name"] = tenant.name
        if tenant and context.get("summary"):
            context["summary"]["tenant_name"] = tenant.name
        trend_summary = build_trend_summary(db, tenant_id=user.tenant_id, upload=upload, current_result=result)
        log_event(db, request, event_type="report_viewed", user=user, metadata={"upload_id": upload.id, "api": True})

        summary = dict(context["summary"])
        summary["estimated_waste_gbp"] = float(summary.get("estimated_waste") or 0.0)
        return {
            "upload": {
                "id": upload.id,
                "tenant_upload_seq": upload.tenant_upload_seq,
                "provider": upload.provider,
                "source_type": upload.source_type,
                "source_detail": upload.source_detail,
                "schema_version": upload.schema_version,
                "coverage_level": upload.coverage_level,
                "signature_valid": upload.signature_valid,
                "signature_source": upload.signature_source,
                "signature_key_id": signature_meta["key_id"],
                "signature_algorithm": signature_meta["algorithm"],
                "asset_count": upload.asset_count,
                "finding_count": upload.finding_count,
                "generated_at_utc": upload.generated_at_utc,
                "created_at": upload.created_at.isoformat(),
                "continuity_context": continuity_context_payload(db, upload),
            },
            "summary": summary,
            "summary_display": summary_display(summary),
            "assessment": context.get("assessment"),
            "executive_brief": context["executive_brief"],
            "heat_map": context["heat_map"],
            "top_findings": [f.model_dump(mode="json") for f in context["top_findings"]],
            "findings": [{"idx": idx, "finding": finding.model_dump(mode="json")} for idx, finding in enumerate(context["findings_sorted"])],
            "findings_grouped": context["findings_grouped"],
            "meta": context.get("meta"),
            "environment_overview": context.get("environment_overview"),
            "kpis": context.get("kpis"),
            "drivers": context.get("drivers"),
            "risk_profile": context.get("risk_profile"),
            "roadmap_view": context.get("roadmap_view"),
            "trajectory": context.get("trajectory"),
            "appendix": context.get("appendix"),
            "board_translation": context.get("board_translation"),
            "immediate_actions": context.get("immediate_actions"),
            "immediate_actions_detailed": context.get("immediate_actions_detailed"),
            "roadmap": context["roadmap"],
            "phase_projection": context["phase_projection"],
            "trend_summary": trend_summary,
            "collection_diagnostics": context.get("collection_diagnostics") or {},
            "compliance": context.get("compliance"),
            "compliance_detailed": context.get("compliance_detailed"),
            "cost_breakdown": context.get("cost_breakdown"),
            "execution_progress": build_execution_progress(db, tenant_id=user.tenant_id, upload_id=upload.id),
            "ingestion": build_upload_ingestion_summary(upload),
            "continuity_context": continuity_context_payload(db, upload),
            "payment_gate": payment_gate,
        }

    @app.get("/api/v1/taxonomy")
    def get_taxonomy_api() -> dict:
        return taxonomy

    @app.get("/api/v1/uploads")
    def list_uploads(db: Session = Depends(get_db), user: User = Depends(require_role("viewer"))) -> dict:
        rows = db.query(ScanUpload).filter(ScanUpload.tenant_id == user.tenant_id).order_by(ScanUpload.created_at.desc()).limit(25).all()
        return {
            "items": [
                {
                    **{
                        "id": row.id,
                        "tenant_upload_seq": row.tenant_upload_seq,
                        "provider": row.provider,
                        "source_type": row.source_type,
                        "source_detail": row.source_detail,
                        "schema_version": row.schema_version,
                        "coverage_level": row.coverage_level,
                        "signature_valid": row.signature_valid,
                        "signature_source": row.signature_source,
                        "asset_count": row.asset_count,
                        "finding_count": row.finding_count,
                        "execution_state": row.execution_state or "hold",
                        "created_at": row.created_at.isoformat(),
                        "ingestion": build_upload_ingestion_summary(row),
                        "collection_quality": extract_collection_quality(row.raw_json),
                        "assessment": extract_assessment_summary(row.raw_json),
                    },
                    "signature_key_id": extract_signature_metadata(row.raw_json)["key_id"],
                    "continuity_context": continuity_context_payload(db, row),
                }
                for row in rows
            ]
        }
