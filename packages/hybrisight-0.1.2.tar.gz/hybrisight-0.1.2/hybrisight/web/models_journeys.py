# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from hybrisight.web.db import Base


class ClientJourney(Base):
    __tablename__ = "client_journeys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    journey_type: Mapped[str] = mapped_column(String(48), default="baseline_intake", index=True)
    journey_status: Mapped[str] = mapped_column(String(32), default="draft", index=True)
    delivery_mode: Mapped[str | None] = mapped_column(String(48), default=None, index=True)
    package_type: Mapped[str | None] = mapped_column(String(32), default=None, index=True)
    tenant_id: Mapped[int | None] = mapped_column(ForeignKey("tenants.id"), index=True, default=None)
    onboarding_request_id: Mapped[int | None] = mapped_column(ForeignKey("client_onboarding_requests.id"), index=True, default=None)
    baseline_request_id: Mapped[int | None] = mapped_column(ForeignKey("baseline_requests.id"), index=True, default=None)
    contact_request_id: Mapped[int | None] = mapped_column(ForeignKey("contact_feedback_requests.id"), index=True, default=None)
    engagement_id: Mapped[int | None] = mapped_column(ForeignKey("engagements.id"), index=True, default=None)
    owner_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    coordinator_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    current_stage_key: Mapped[str] = mapped_column(String(64), default="intake_review", index=True)
    current_step_key: Mapped[str | None] = mapped_column(String(96), default=None, index=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    target_start_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    target_delivery_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None, index=True)
    blocked_reason: Mapped[str | None] = mapped_column(Text, default=None)
    internal_notes: Mapped[str | None] = mapped_column(Text, default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        index=True,
    )


class ClientJourneyStage(Base):
    __tablename__ = "client_journey_stages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    journey_id: Mapped[int] = mapped_column(ForeignKey("client_journeys.id"), index=True)
    stage_key: Mapped[str] = mapped_column(String(64), index=True)
    display_order: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(32), default="not_started", index=True)
    owner_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None, index=True)
    blocked_reason: Mapped[str | None] = mapped_column(Text, default=None)
    notes: Mapped[str | None] = mapped_column(Text, default=None)


class ClientJourneyStep(Base):
    __tablename__ = "client_journey_steps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    journey_id: Mapped[int] = mapped_column(ForeignKey("client_journeys.id"), index=True)
    stage_key: Mapped[str] = mapped_column(String(64), index=True)
    step_key: Mapped[str] = mapped_column(String(96), index=True)
    display_order: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(32), default="not_started", index=True)
    completion_source: Mapped[str] = mapped_column(String(16), default="manual", index=True)
    owner_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None, index=True)
    completed_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    blocking: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    notes: Mapped[str | None] = mapped_column(Text, default=None)
    evidence_url: Mapped[str | None] = mapped_column(String(1024), default=None)
    evidence_ref: Mapped[str | None] = mapped_column(String(255), default=None)


class ClientJourneyEvent(Base):
    __tablename__ = "client_journey_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    journey_id: Mapped[int] = mapped_column(ForeignKey("client_journeys.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(64), index=True)
    event_source: Mapped[str] = mapped_column(String(32), default="manual", index=True)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    payload_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
