# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Callable

from fastapi import Body, Depends, FastAPI, Form, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.models import ApiKey, Tenant, TenantSigningKey, User


def register_signing_key_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    get_api_key_actor: Callable[..., tuple[ApiKey, Tenant, bool]],
) -> None:
    def _upsert_signing_key(
        *,
        db: Session,
        tenant: Tenant,
        created_by_id: int,
        key_id: str,
        algorithm: str,
        public_key_pem: str,
    ) -> TenantSigningKey:
        row = (
            db.query(TenantSigningKey)
            .filter(
                TenantSigningKey.tenant_id == tenant.id,
                TenantSigningKey.key_id == key_id,
                TenantSigningKey.algorithm == algorithm,
            )
            .first()
        )
        if row:
            row.public_key_pem = public_key_pem
            row.active = True
            row.revoked_at = None
            return row
        row = TenantSigningKey(
            tenant_id=tenant.id,
            created_by_id=created_by_id,
            key_id=key_id,
            algorithm=algorithm,
            public_key_pem=public_key_pem,
            active=True,
        )
        db.add(row)
        return row

    def _validate_signing_key_payload(payload: dict[str, Any]) -> tuple[str, str, str]:
        algorithm = str(payload.get("algorithm", "ed25519")).strip().lower()
        key_id = str(payload.get("key_id", "")).strip()
        public_key_pem = str(payload.get("public_key_pem", "")).strip()
        if algorithm != "ed25519":
            raise HTTPException(status_code=400, detail="Only ed25519 public keys are supported")
        if not public_key_pem:
            raise HTTPException(status_code=400, detail="public_key_pem is required")

        from hybrisight.signing import derive_ed25519_key_id_from_public_key

        derived = derive_ed25519_key_id_from_public_key(public_key_pem)
        if key_id and derived != key_id:
            raise HTTPException(status_code=400, detail=f"key_id mismatch; expected {derived}")
        return algorithm, derived, public_key_pem

    @app.post("/api/v1/signing-keys/register")
    def register_tenant_signing_key(
        request: Request,
        payload: dict[str, Any] = Body(...),
        db: Session = Depends(get_db),
        actor: tuple[ApiKey, Tenant, bool] = Depends(get_api_key_actor),
    ) -> dict:
        api_key_row, tenant, _ = actor
        algorithm, key_id, public_key_pem = _validate_signing_key_payload(payload)
        row = _upsert_signing_key(
            db=db,
            tenant=tenant,
            created_by_id=api_key_row.created_by_id,
            key_id=key_id,
            algorithm=algorithm,
            public_key_pem=public_key_pem,
        )
        db.commit()
        db.refresh(row)

        creator = db.query(User).filter(User.id == api_key_row.created_by_id).first()
        log_event(
            db,
            request,
            event_type="tenant_signing_key_registered",
            user=creator,
            metadata={"tenant_id": tenant.id, "key_id": row.key_id, "algorithm": row.algorithm},
        )
        return {
            "tenant_id": tenant.id,
            "signing_key_id": row.id,
            "key_id": row.key_id,
            "algorithm": row.algorithm,
            "active": row.active,
        }

    @app.post("/api/v1/signing-keys")
    def register_tenant_signing_key_via_session(
        request: Request,
        payload: dict[str, Any] = Body(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))
        tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
        if tenant is None:
            raise HTTPException(status_code=404, detail="Tenant not found")
        algorithm, key_id, public_key_pem = _validate_signing_key_payload(payload)
        row = _upsert_signing_key(
            db=db,
            tenant=tenant,
            created_by_id=user.id,
            key_id=key_id,
            algorithm=algorithm,
            public_key_pem=public_key_pem,
        )
        db.commit()
        db.refresh(row)
        log_event(
            db,
            request,
            event_type="tenant_signing_key_registered",
            user=user,
            metadata={"tenant_id": tenant.id, "key_id": row.key_id, "algorithm": row.algorithm, "source": "session"},
        )
        return {
            "tenant_id": tenant.id,
            "signing_key_id": row.id,
            "key_id": row.key_id,
            "algorithm": row.algorithm,
            "active": row.active,
        }

    @app.get("/api/v1/signing-keys")
    def list_tenant_signing_keys(
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        rows = (
            db.query(TenantSigningKey)
            .filter(TenantSigningKey.tenant_id == user.tenant_id)
            .order_by(TenantSigningKey.created_at.desc())
            .all()
        )
        return {
            "items": [
                {
                    "id": row.id,
                    "key_id": row.key_id,
                    "algorithm": row.algorithm,
                    "active": bool(row.active),
                    "created_at": row.created_at.isoformat(),
                    "revoked_at": row.revoked_at.isoformat() if row.revoked_at else None,
                }
                for row in rows
            ]
        }

    @app.post("/api/v1/signing-keys/{signing_key_id}/revoke")
    def revoke_tenant_signing_key(
        signing_key_id: int,
        request: Request,
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        row = (
            db.query(TenantSigningKey)
            .filter(TenantSigningKey.id == signing_key_id, TenantSigningKey.tenant_id == user.tenant_id)
            .first()
        )
        if row is None:
            raise HTTPException(status_code=404, detail="Signing key not found")
        row.active = False
        row.revoked_at = datetime.now(UTC)
        db.commit()
        log_event(db, request, event_type="tenant_signing_key_revoked", user=user, metadata={"signing_key_id": row.id})
        return {"revoked": True, "signing_key_id": row.id}
