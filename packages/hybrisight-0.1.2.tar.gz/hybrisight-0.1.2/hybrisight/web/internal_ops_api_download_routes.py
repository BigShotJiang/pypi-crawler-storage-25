# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from hybrisight.web.models import CliDownloadCount, User


class DownloadStats(BaseModel):
    sh_count: int
    ps1_count: int
    total: int


def register_internal_ops_api_download_routes(
    app: Any,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
) -> None:
    @app.get("/api/v1/internal/download-stats")
    def get_download_stats(
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> DownloadStats:
        enforce_internal_ops_access(request, user)
        sh = db.query(CliDownloadCount).filter_by(script_name="install.sh").first()
        ps1 = db.query(CliDownloadCount).filter_by(script_name="install.ps1").first()
        sh_count = sh.count if sh else 0
        ps1_count = ps1.count if ps1 else 0
        return DownloadStats(sh_count=sh_count, ps1_count=ps1_count, total=sh_count + ps1_count)
