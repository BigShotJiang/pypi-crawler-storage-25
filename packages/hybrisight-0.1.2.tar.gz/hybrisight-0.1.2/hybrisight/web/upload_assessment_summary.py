# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

from hybrisight.engine_context import build_report_context
from hybrisight.web.service_parse import validate_scan_payload


def extract_assessment_summary(raw_json: str | None) -> dict[str, Any]:
    if not raw_json:
        return {
            "type": "baseline",
            "label": "Governance Brief",
            "signal_sufficiency": "baseline_ready",
            "summary": "Assessment classification metadata is not available for this artifact.",
        }
    try:
        result = validate_scan_payload(raw_json)
        context = build_report_context(result)
        assessment = context.get("assessment") or {}
    except Exception:
        return {
            "type": "baseline",
            "label": "Governance Brief",
            "signal_sufficiency": "baseline_ready",
            "summary": "Assessment classification metadata could not be derived from the stored artifact.",
        }
    return {
        "type": str(assessment.get("type") or "baseline"),
        "label": str(assessment.get("label") or "Governance Brief"),
        "signal_sufficiency": str(assessment.get("signal_sufficiency") or "baseline_ready"),
        "summary": str(assessment.get("summary") or ""),
    }
