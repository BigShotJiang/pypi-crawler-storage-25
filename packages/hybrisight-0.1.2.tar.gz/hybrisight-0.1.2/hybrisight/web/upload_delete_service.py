from __future__ import annotations

from sqlalchemy.orm import Session

from hybrisight.web.models import ExecutionTicket, ExecutionTicketEvent, ReassessmentSeries, ScanUpload, TicketComment, TicketEvidence


def delete_upload_with_dependencies(db: Session, upload: ScanUpload) -> None:
    ticket_ids = [
        row[0]
        for row in db.query(ExecutionTicket.id).filter(ExecutionTicket.upload_id == upload.id).all()
    ]
    if ticket_ids:
        db.query(TicketEvidence).filter(TicketEvidence.ticket_id.in_(ticket_ids)).delete(synchronize_session=False)
        db.query(TicketComment).filter(TicketComment.ticket_id.in_(ticket_ids)).delete(synchronize_session=False)
        db.query(ExecutionTicketEvent).filter(ExecutionTicketEvent.ticket_id.in_(ticket_ids)).delete(synchronize_session=False)
        db.query(ExecutionTicket).filter(ExecutionTicket.id.in_(ticket_ids)).delete(synchronize_session=False)

    db.query(ExecutionTicketEvent).filter(ExecutionTicketEvent.upload_id == upload.id).delete(synchronize_session=False)
    db.query(ScanUpload).filter(ScanUpload.baseline_upload_id == upload.id).update(
        {ScanUpload.baseline_upload_id: None},
        synchronize_session=False,
    )
    db.query(ReassessmentSeries).filter(ReassessmentSeries.baseline_upload_id == upload.id).update(
        {ReassessmentSeries.baseline_upload_id: None},
        synchronize_session=False,
    )
    db.delete(upload)
