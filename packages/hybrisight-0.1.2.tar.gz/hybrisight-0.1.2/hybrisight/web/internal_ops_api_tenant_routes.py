# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any, Callable

from fastapi import Body, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.models import ComplianceLog, ScanUpload, Tenant, User


def register_internal_ops_api_tenant_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    validate_csrf: Callable[[Request, str | None], None],
    sanitize_onboarding_reason: Callable[[str], str],
    normalized_tenant_status: Callable[[Tenant], str],
    get_client_ip: Callable[[Request], str | None],
    log_event: Callable[..., None],
) -> None:
    @app.get('/api/v1/internal/tenants')
    def api_internal_tenants(request: Request, limit: int = 200, db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        safe_limit = max(1, min(int(limit or 200), 500))
        rows = db.query(Tenant).order_by(Tenant.name.asc()).limit(safe_limit).all()
        items: list[dict[str, Any]] = []
        for row in rows:
            status = normalized_tenant_status(row)
            items.append({'id': row.id, 'name': row.name, 'slug': row.slug, 'status': status, 'status_reason': row.status_reason, 'status_updated_at': row.status_updated_at.isoformat() if row.status_updated_at else '', 'users': db.query(User).filter(User.tenant_id == row.id).count(), 'admins': db.query(User).filter(User.tenant_id == row.id, User.role == 'tenant_admin').count(), 'uploads': db.query(ScanUpload).filter(ScanUpload.tenant_id == row.id).count(), 'can_suspend': row.id != user.tenant_id and status == 'active', 'can_reactivate': row.id != user.tenant_id and status == 'suspended', 'can_archive': row.id != user.tenant_id and status != 'archived', 'can_unarchive': row.id != user.tenant_id and status == 'archived'})
        return {'items': items}

    @app.post('/api/v1/internal/tenants/{tenant_id}/suspend')
    def api_internal_suspend_tenant(tenant_id: int, request: Request, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        if tenant_id == user.tenant_id:
            raise HTTPException(status_code=400, detail='Cannot suspend current operator tenant')
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if tenant is None:
            raise HTTPException(status_code=404, detail='Tenant not found')
        if normalized_tenant_status(tenant) == 'suspended':
            return {'ok': True, 'id': tenant.id, 'status': 'suspended'}
        reason = sanitize_onboarding_reason(str(payload.get('reason', '')))
        if not reason:
            raise HTTPException(status_code=400, detail='Suspension reason is required')
        now = datetime.now(UTC)
        tenant.status = 'suspended'; tenant.status_reason = reason; tenant.status_updated_at = now; tenant.status_updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type='tenant_suspended', user=user, metadata={'tenant_id': tenant.id, 'tenant_slug': tenant.slug, 'reason': reason, 'effective_at': now.isoformat()})
        db.add(ComplianceLog(event_type='TENANT_SUSPENDED', identifier=f'Tenant: {tenant.name} (ID: {tenant.id})', ip_address=get_client_ip(request), metadata_json=json.dumps({'reason': reason, 'effective_at': now.isoformat(), 'by_user_id': user.id})))
        db.commit()
        return {'ok': True, 'id': tenant.id, 'status': 'suspended'}

    @app.post('/api/v1/internal/tenants/{tenant_id}/reactivate')
    def api_internal_reactivate_tenant(tenant_id: int, request: Request, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if tenant is None:
            raise HTTPException(status_code=404, detail='Tenant not found')
        if normalized_tenant_status(tenant) == 'active':
            return {'ok': True, 'id': tenant.id, 'status': 'active'}
        note = sanitize_onboarding_reason(str(payload.get('note', '')))
        now = datetime.now(UTC)
        tenant.status = 'active'; tenant.status_reason = note or 'Reactivated by internal ops'; tenant.status_updated_at = now; tenant.status_updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type='tenant_reactivated', user=user, metadata={'tenant_id': tenant.id, 'tenant_slug': tenant.slug, 'note': tenant.status_reason, 'effective_at': now.isoformat()})
        db.add(ComplianceLog(event_type='TENANT_REACTIVATED', identifier=f'Tenant: {tenant.name} (ID: {tenant.id})', ip_address=get_client_ip(request), metadata_json=json.dumps({'note': tenant.status_reason, 'effective_at': now.isoformat(), 'by_user_id': user.id})))
        db.commit()
        return {'ok': True, 'id': tenant.id, 'status': 'active'}

    @app.post('/api/v1/internal/tenants/{tenant_id}/archive')
    def api_internal_archive_tenant(tenant_id: int, request: Request, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        if tenant_id == user.tenant_id:
            raise HTTPException(status_code=400, detail='Cannot archive current operator tenant')
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if tenant is None:
            raise HTTPException(status_code=404, detail='Tenant not found')
        if normalized_tenant_status(tenant) == 'archived':
            return {'ok': True, 'id': tenant.id, 'status': 'archived'}
        reason = sanitize_onboarding_reason(str(payload.get('reason', '')))
        if not reason:
            raise HTTPException(status_code=400, detail='Archive reason is required')
        now = datetime.now(UTC)
        tenant.status = 'archived'; tenant.status_reason = reason; tenant.status_updated_at = now; tenant.status_updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type='tenant_archived', user=user, metadata={'tenant_id': tenant.id, 'tenant_slug': tenant.slug, 'reason': reason, 'effective_at': now.isoformat()})
        db.add(ComplianceLog(event_type='TENANT_ARCHIVED', identifier=f'Tenant: {tenant.name} (ID: {tenant.id})', ip_address=get_client_ip(request), metadata_json=json.dumps({'reason': reason, 'effective_at': now.isoformat(), 'by_user_id': user.id})))
        db.commit()
        return {'ok': True, 'id': tenant.id, 'status': 'archived'}

    @app.post('/api/v1/internal/tenants/{tenant_id}/unarchive')
    def api_internal_unarchive_tenant(tenant_id: int, request: Request, payload: dict[str, Any] = Body(...), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if tenant is None:
            raise HTTPException(status_code=404, detail='Tenant not found')
        if normalized_tenant_status(tenant) != 'archived':
            raise HTTPException(status_code=400, detail='Only archived tenants can be unarchived')
        note = sanitize_onboarding_reason(str(payload.get('note', '')))
        now = datetime.now(UTC)
        tenant.status = 'active'; tenant.status_reason = note or 'Unarchived by internal ops'; tenant.status_updated_at = now; tenant.status_updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type='tenant_unarchived', user=user, metadata={'tenant_id': tenant.id, 'tenant_slug': tenant.slug, 'note': tenant.status_reason, 'effective_at': now.isoformat()})
        db.add(ComplianceLog(event_type='TENANT_UNARCHIVED', identifier=f'Tenant: {tenant.name} (ID: {tenant.id})', ip_address=get_client_ip(request), metadata_json=json.dumps({'note': tenant.status_reason, 'effective_at': now.isoformat(), 'by_user_id': user.id})))
        db.commit()
        return {'ok': True, 'id': tenant.id, 'status': 'active'}
