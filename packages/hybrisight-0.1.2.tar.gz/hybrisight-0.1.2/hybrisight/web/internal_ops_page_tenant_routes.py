# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any, Callable
from urllib.parse import quote_plus

from fastapi import Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from hybrisight.web.models import ComplianceLog, Tenant, User


def register_internal_ops_page_tenant_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    validate_csrf: Callable[[Request, str | None], None],
    normalized_tenant_status: Callable[[Tenant], str],
    sanitize_onboarding_reason: Callable[[str], str],
    get_client_ip: Callable[[Request], str | None],
    log_event: Callable[..., None],
) -> None:
    @app.post("/internal/ops/tenants/{tenant_id}/suspend")
    def internal_ops_suspend_tenant(
        request: Request,
        tenant_id: int,
        reason: str = Form(""),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        if tenant_id == user.tenant_id:
            return RedirectResponse(url="/internal/ops?error=Cannot+suspend+current+operator+tenant", status_code=302)
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if tenant is None:
            return RedirectResponse(url="/internal/ops?error=Tenant+not+found", status_code=302)
        if normalized_tenant_status(tenant) == "suspended":
            return RedirectResponse(url="/internal/ops?message=Tenant+already+suspended", status_code=302)
        cleaned_reason = sanitize_onboarding_reason(reason)
        if not cleaned_reason:
            return RedirectResponse(url="/internal/ops?error=Suspension+reason+is+required", status_code=302)
        now = datetime.now(UTC)
        tenant.status = "suspended"
        tenant.status_reason = cleaned_reason
        tenant.status_updated_at = now
        tenant.status_updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type="tenant_suspended", user=user, metadata={"tenant_id": tenant.id, "tenant_slug": tenant.slug, "reason": cleaned_reason, "effective_at": now.isoformat()})
        db.add(ComplianceLog(event_type="TENANT_SUSPENDED", identifier=f"Tenant: {tenant.name} (ID: {tenant.id})", ip_address=get_client_ip(request), metadata_json=json.dumps({"reason": cleaned_reason, "effective_at": now.isoformat(), "by_user_id": user.id})))
        db.commit()
        return RedirectResponse(url=f"/internal/ops?message=Suspended+tenant+{quote_plus(tenant.name)}+at+{quote_plus(now.isoformat())}", status_code=302)

    @app.post("/internal/ops/tenants/{tenant_id}/reactivate")
    def internal_ops_reactivate_tenant(
        request: Request,
        tenant_id: int,
        note: str = Form(""),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if tenant is None:
            return RedirectResponse(url="/internal/ops?error=Tenant+not+found", status_code=302)
        if normalized_tenant_status(tenant) == "active":
            return RedirectResponse(url="/internal/ops?message=Tenant+already+active", status_code=302)
        cleaned_note = sanitize_onboarding_reason(note)
        now = datetime.now(UTC)
        tenant.status = "active"
        tenant.status_reason = cleaned_note or "Reactivated by internal ops"
        tenant.status_updated_at = now
        tenant.status_updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type="tenant_reactivated", user=user, metadata={"tenant_id": tenant.id, "tenant_slug": tenant.slug, "note": tenant.status_reason, "effective_at": now.isoformat()})
        db.add(ComplianceLog(event_type="TENANT_REACTIVATED", identifier=f"Tenant: {tenant.name} (ID: {tenant.id})", ip_address=get_client_ip(request), metadata_json=json.dumps({"note": tenant.status_reason, "effective_at": now.isoformat(), "by_user_id": user.id})))
        db.commit()
        return RedirectResponse(url=f"/internal/ops?message=Reactivated+tenant+{quote_plus(tenant.name)}+at+{quote_plus(now.isoformat())}", status_code=302)

    @app.post("/internal/ops/tenants/{tenant_id}/archive")
    def internal_ops_archive_tenant(
        request: Request,
        tenant_id: int,
        reason: str = Form(""),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        if tenant_id == user.tenant_id:
            return RedirectResponse(url="/internal/ops?error=Cannot+archive+current+operator+tenant", status_code=302)
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if tenant is None:
            return RedirectResponse(url="/internal/ops?error=Tenant+not+found", status_code=302)
        if normalized_tenant_status(tenant) == "archived":
            return RedirectResponse(url="/internal/ops?message=Tenant+already+archived", status_code=302)
        cleaned_reason = sanitize_onboarding_reason(reason)
        if not cleaned_reason:
            return RedirectResponse(url="/internal/ops?error=Archive+reason+is+required", status_code=302)
        now = datetime.now(UTC)
        tenant.status = "archived"
        tenant.status_reason = cleaned_reason
        tenant.status_updated_at = now
        tenant.status_updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type="tenant_archived", user=user, metadata={"tenant_id": tenant.id, "tenant_slug": tenant.slug, "reason": cleaned_reason, "effective_at": now.isoformat()})
        db.add(ComplianceLog(event_type="TENANT_ARCHIVED", identifier=f"Tenant: {tenant.name} (ID: {tenant.id})", ip_address=get_client_ip(request), metadata_json=json.dumps({"reason": cleaned_reason, "effective_at": now.isoformat(), "by_user_id": user.id})))
        db.commit()
        return RedirectResponse(url=f"/internal/ops?message=Archived+tenant+{quote_plus(tenant.name)}+at+{quote_plus(now.isoformat())}", status_code=302)

    @app.post("/internal/ops/tenants/{tenant_id}/unarchive")
    def internal_ops_unarchive_tenant(
        request: Request,
        tenant_id: int,
        note: str = Form(""),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
        if tenant is None:
            return RedirectResponse(url="/internal/ops?error=Tenant+not+found", status_code=302)
        if normalized_tenant_status(tenant) != "archived":
            return RedirectResponse(url="/internal/ops?error=Only+archived+tenants+can+be+unarchived", status_code=302)
        cleaned_note = sanitize_onboarding_reason(note)
        now = datetime.now(UTC)
        tenant.status = "active"
        tenant.status_reason = cleaned_note or "Unarchived by internal ops"
        tenant.status_updated_at = now
        tenant.status_updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type="tenant_unarchived", user=user, metadata={"tenant_id": tenant.id, "tenant_slug": tenant.slug, "note": tenant.status_reason, "effective_at": now.isoformat()})
        db.add(ComplianceLog(event_type="TENANT_UNARCHIVED", identifier=f"Tenant: {tenant.name} (ID: {tenant.id})", ip_address=get_client_ip(request), metadata_json=json.dumps({"note": tenant.status_reason, "effective_at": now.isoformat(), "by_user_id": user.id})))
        db.commit()
        return RedirectResponse(url=f"/internal/ops?message=Unarchived+tenant+{quote_plus(tenant.name)}+at+{quote_plus(now.isoformat())}", status_code=302)
