# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
import threading
import time
from collections import defaultdict, deque

from hybrisight.security import scan_payload_for_malware

MAX_UPLOAD_BYTES = int(os.getenv("HYBRISIGHT_WEB_MAX_UPLOAD_BYTES", str(30 * 1024 * 1024)))
ALLOWED_CONTENT_TYPES = {
    "application/json",
    "text/json",
    "application/octet-stream",
    "text/plain",
    "application/csv",
    "text/csv",
}
SUPPORTED_PDF_READY_SUMMARY_DOCUMENT_TYPES = {"hybrisight_pdf_ready_summary"}
NATIVE_EXPORT_TYPE_ALIASES = {
    "aws_trusted_advisor": "aws_trusted_advisor_export",
    "aws_prowler_ocsf": "aws_prowler_ocsf_json",
    "aws_prowler_ocsf_v1": "aws_prowler_ocsf_json",
    "azure_defender_export": "azure_defender_summary",
    "azure_advisor_export": "azure_advisor_recommendations",
}


class UploadValidationError(ValueError):
    pass


class RateLimitExceeded(RuntimeError):
    pass


_RATE_LIMIT_STATE: dict[str, deque[float]] = defaultdict(deque)
_RATE_LIMIT_LOCK = threading.Lock()


def enforce_rate_limit(client_key: str) -> None:
    enabled_raw = os.getenv("HYBRISIGHT_WEB_RATE_LIMIT_ENABLED")
    if enabled_raw is None and os.getenv("PYTEST_CURRENT_TEST"):
        return
    enabled = (enabled_raw or "true").strip().lower() in {"1", "true", "yes", "on"}
    if not enabled:
        return

    max_requests = int(os.getenv("HYBRISIGHT_WEB_RATE_LIMIT_MAX_REQUESTS", "300"))
    window_seconds = int(os.getenv("HYBRISIGHT_WEB_RATE_LIMIT_WINDOW_SECONDS", "60"))
    now = time.monotonic()
    cutoff = now - window_seconds
    key = client_key or "unknown"

    with _RATE_LIMIT_LOCK:
        bucket = _RATE_LIMIT_STATE[key]
        while bucket and bucket[0] < cutoff:
            bucket.popleft()
        if len(bucket) >= max_requests:
            raise RateLimitExceeded(f"Rate limit exceeded for {key}")
        bucket.append(now)


def validate_upload_basics(content_type: str | None, payload: bytes) -> None:
    if len(payload) > MAX_UPLOAD_BYTES:
        max_mib = MAX_UPLOAD_BYTES / (1024 * 1024)
        raise UploadValidationError(f"File exceeds max upload size ({max_mib:.1f} MiB, {MAX_UPLOAD_BYTES:,} bytes).")
    if content_type and content_type.lower() not in ALLOWED_CONTENT_TYPES:
        raise UploadValidationError("Unsupported content-type")
    if not scan_payload_for_malware(payload):
        raise UploadValidationError("Malware scan failed")
