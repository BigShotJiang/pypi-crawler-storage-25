# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from datetime import datetime
from decimal import Decimal
from typing import Any

from hybrisight.web.engagement_policy import (
    ENGAGEMENT_ACCESS_STATES as POLICY_ENGAGEMENT_ACCESS_STATES,
    ENGAGEMENT_DELIVERY_MODES as POLICY_ENGAGEMENT_DELIVERY_MODES,
)
from hybrisight.web.models_engagements import Engagement, EngagementEvent

ENGAGEMENT_PACKAGE_TYPES = ("foundation", "baseline", "stabilisation", "retainer", "custom")
ENGAGEMENT_WORKFLOW_STATES = (
    "lead",
    "qualified",
    "proposal_sent",
    "invoice_issued",
    "invoice_paid",
    "foundation_in_progress",
    "foundation_delivered",
    "baseline_in_progress",
    "baseline_delivered",
    "stabilisation_active",
    "retainer_active",
    "closed_won",
    "closed_lost",
)
ENGAGEMENT_BILLING_PROVIDERS = ("none", "stripe", "xero", "quickbooks")
ENGAGEMENT_INVOICE_STATUSES = ("none", "draft", "issued", "paid", "overdue", "void")
ENGAGEMENT_REPORT_RELEASE_STATES = ("not_started", "draft_ready", "review_ready", "released")
ENGAGEMENT_REPORT_DELIVERY_FORMATS = ("none", "html", "pdf", "link")
ENGAGEMENT_DELIVERY_MODES = POLICY_ENGAGEMENT_DELIVERY_MODES
ENGAGEMENT_ACCESS_STATES = POLICY_ENGAGEMENT_ACCESS_STATES


def normalize_choice(raw: str | None, allowed: tuple[str, ...], *, field_name: str) -> str:
    value = (raw or "").strip().lower().replace("-", "_")
    if value not in allowed:
        raise ValueError(f"Unsupported {field_name}")
    return value


def parse_money(raw: Any, *, field_name: str) -> Decimal | None:
    if raw in (None, ""):
        return None
    try:
        value = Decimal(str(raw))
    except Exception as exc:  # pragma: no cover
        raise ValueError(f"Invalid {field_name}") from exc
    if value < 0:
        raise ValueError(f"Invalid {field_name}")
    return value.quantize(Decimal("0.01"))


def parse_datetime(raw: Any, *, field_name: str) -> datetime | None:
    if raw in (None, ""):
        return None
    try:
        return datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"Invalid {field_name}") from exc


def iso_or_none(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


def decimal_to_float(value: Decimal | None) -> float | None:
    return float(value) if value is not None else None


def serialize_engagement(item: Engagement, latest_upload_quality: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = {
        "id": item.id,
        "tenant_id": item.tenant_id,
        "client_tenant_id": item.client_tenant_id,
        "title": item.title,
        "client_name": item.client_name,
        "contact_email": item.contact_email,
        "package_type": item.package_type,
        "workflow_state": item.workflow_state,
        "delivery_mode": item.delivery_mode,
        "access_state": item.access_state,
        "payment_required_before_release": item.payment_required_before_release,
        "billing_provider": item.billing_provider,
        "invoice_status": item.invoice_status,
        "billing_customer_external_id": item.billing_customer_external_id,
        "invoice_external_id": item.invoice_external_id,
        "invoice_external_url": item.invoice_external_url,
        "currency": item.currency,
        "fixed_fee_amount": decimal_to_float(item.fixed_fee_amount),
        "quoted_amount": decimal_to_float(item.quoted_amount),
        "paid_amount": decimal_to_float(item.paid_amount),
        "proposal_sent_at": iso_or_none(item.proposal_sent_at),
        "invoice_issued_at": iso_or_none(item.invoice_issued_at),
        "invoice_paid_at": iso_or_none(item.invoice_paid_at),
        "delivery_due_at": iso_or_none(item.delivery_due_at),
        "report_release_state": item.report_release_state,
        "report_delivery_format": item.report_delivery_format,
        "report_delivery_url": item.report_delivery_url,
        "report_released_at": iso_or_none(item.report_released_at),
        "next_step": item.next_step,
        "notes": item.notes,
        "created_at": iso_or_none(item.created_at),
        "updated_at": iso_or_none(item.updated_at),
    }
    if latest_upload_quality is not None:
        payload["latest_upload_quality"] = latest_upload_quality
    return payload


def serialize_event(item: EngagementEvent) -> dict[str, Any]:
    return {
        "id": item.id,
        "engagement_id": item.engagement_id,
        "event_type": item.event_type,
        "summary": item.summary,
        "detail": item.detail,
        "metadata": json.loads(item.metadata_json or "{}"),
        "created_at": iso_or_none(item.created_at),
    }


def append_engagement_event(
    *,
    engagement_id: int,
    tenant_id: int,
    actor_user_id: int | None,
    event_type: str,
    summary: str,
    detail: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> EngagementEvent:
    return EngagementEvent(
        engagement_id=engagement_id,
        tenant_id=tenant_id,
        actor_user_id=actor_user_id,
        event_type=event_type,
        summary=summary[:255],
        detail=detail,
        metadata_json=json.dumps(metadata or {}, sort_keys=True),
    )
