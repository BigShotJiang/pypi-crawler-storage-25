# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any, Callable

from fastapi import Depends, FastAPI, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.models import ScanUpload, User
from hybrisight.web.models_core import ReportShareToken, Tenant

_log = logging.getLogger(__name__)

_TTL_OPTIONS = {1: 1, 7: 7, 30: 30}
_DEFAULT_TTL_DAYS = 7


def _utc_now() -> datetime:
    """Return current UTC time as timezone-aware datetime."""
    return datetime.now(UTC)


def _is_expired(dt: datetime, now: datetime) -> bool:
    """Compare datetimes tolerating SQLite's timezone-naive storage."""
    if dt.tzinfo is None:
        return dt < now.replace(tzinfo=None)
    return dt < now


def register_share_token_routes(
    app: FastAPI,
    *,
    get_db: Callable,
    require_role: Callable,
    validate_csrf: Callable,
    log_event: Callable,
    validate_scan_payload: Callable,
    build_dashboard_payload: Callable,
    build_trend_summary: Callable,
    build_execution_progress: Callable,
    summary_display: Callable,
    build_upload_ingestion_summary: Callable,
    continuity_context_payload: Callable,
    extract_signature_metadata: Callable,
) -> None:

    def _build_report_response(db: Session, upload: ScanUpload) -> dict[str, Any]:
        """Build the same report payload shape as GET /api/v1/uploads/{id}."""
        result = validate_scan_payload(upload.raw_json)
        signature_meta = extract_signature_metadata(upload.raw_json)
        try:
            context = build_dashboard_payload(result)
        except Exception as exc:
            _log.warning("share_payload_build_error upload_id=%s error=%s", upload.id, exc)
            raise HTTPException(status_code=500, detail="Failed to build report data for shared link.")
        tenant = db.query(Tenant).filter(Tenant.id == upload.tenant_id).first()
        if tenant and context.get("meta"):
            context["meta"]["tenant_name"] = tenant.name
        if tenant and context.get("summary"):
            context["summary"]["tenant_name"] = tenant.name
        trend_summary = build_trend_summary(db, tenant_id=upload.tenant_id, upload=upload, current_result=result)
        summary = dict(context["summary"])
        summary["estimated_waste_gbp"] = float(summary.get("estimated_waste") or 0.0)
        return {
            "upload": {
                "id": upload.id,
                "tenant_upload_seq": upload.tenant_upload_seq,
                "provider": upload.provider,
                "source_type": upload.source_type,
                "source_detail": upload.source_detail,
                "schema_version": upload.schema_version,
                "coverage_level": upload.coverage_level,
                "signature_valid": upload.signature_valid,
                "signature_source": upload.signature_source,
                "signature_key_id": signature_meta["key_id"],
                "signature_algorithm": signature_meta["algorithm"],
                "asset_count": upload.asset_count,
                "finding_count": upload.finding_count,
                "generated_at_utc": upload.generated_at_utc,
                "created_at": upload.created_at.isoformat(),
                "continuity_context": continuity_context_payload(db, upload),
            },
            "summary": summary,
            "summary_display": summary_display(summary),
            "assessment": context.get("assessment"),
            "executive_brief": context["executive_brief"],
            "heat_map": context["heat_map"],
            "top_findings": [f.model_dump(mode="json") for f in context["top_findings"]],
            "findings": [{"idx": idx, "finding": f.model_dump(mode="json")} for idx, f in enumerate(context["findings_sorted"])],
            "findings_grouped": context.get("findings_grouped"),
            "meta": context.get("meta"),
            "environment_overview": context.get("environment_overview"),
            "kpis": context.get("kpis"),
            "drivers": context.get("drivers"),
            "risk_profile": context.get("risk_profile"),
            "roadmap_view": context.get("roadmap_view"),
            "trajectory": context.get("trajectory"),
            "appendix": context.get("appendix"),
            "board_translation": context.get("board_translation"),
            "immediate_actions": context.get("immediate_actions"),
            "immediate_actions_detailed": context.get("immediate_actions_detailed"),
            "roadmap": context["roadmap"],
            "phase_projection": context["phase_projection"],
            "trend_summary": trend_summary,
            "collection_diagnostics": context.get("collection_diagnostics") or {},
            "compliance": context.get("compliance"),
            "execution_progress": build_execution_progress(db, tenant_id=upload.tenant_id, upload_id=upload.id),
            "ingestion": build_upload_ingestion_summary(upload),
            "continuity_context": continuity_context_payload(db, upload),
        }

    # ── Create share token ─────────────────────────────────────────────────
    @app.post("/api/v1/uploads/{upload_id}/share")
    async def create_share_token(
        upload_id: int,
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("analyst")),
    ) -> dict:
        csrf_token = request.headers.get("X-CSRF-Token")
        validate_csrf(request, csrf_token)
        upload = db.query(ScanUpload).filter(
            ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id
        ).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")
        ttl_days = _DEFAULT_TTL_DAYS
        try:
            import json
            body = await request.body()
            parsed = json.loads(body) if body else {}
            requested = int(parsed.get("ttl_days", _DEFAULT_TTL_DAYS))
            ttl_days = _TTL_OPTIONS.get(requested, _DEFAULT_TTL_DAYS)
        except Exception:
            pass
        token_value = secrets.token_hex(32)
        expires_at = datetime.now(UTC) + timedelta(days=ttl_days)
        share = ReportShareToken(
            token=token_value,
            upload_id=upload_id,
            tenant_id=user.tenant_id,
            created_by_user_id=user.id,
            expires_at=expires_at,
        )
        db.add(share)
        db.commit()
        db.refresh(share)
        log_event(db, request, event_type="share_token_created", user=user, metadata={
            "upload_id": upload_id, "share_token_id": share.id, "ttl_days": ttl_days,
        })
        return {
            "token": token_value,
            "expires_at": expires_at.isoformat(),
            "ttl_days": ttl_days,
            "share_url": f"/share/{token_value}",
        }

    # ── List share tokens for an upload ───────────────────────────────────
    @app.get("/api/v1/uploads/{upload_id}/shares")
    def list_share_tokens(
        upload_id: int,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("analyst")),
    ) -> dict:
        upload = db.query(ScanUpload).filter(
            ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id
        ).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Upload not found")
        tokens = (
            db.query(ReportShareToken)
            .filter(ReportShareToken.upload_id == upload_id, ReportShareToken.tenant_id == user.tenant_id)
            .order_by(ReportShareToken.created_at.desc())
            .all()
        )
        now = _utc_now()
        return {"tokens": [
            {
                "id": t.id,
                "token": t.token,
                "expires_at": t.expires_at.isoformat(),
                "revoked": t.revoked,
                "expired": _is_expired(t.expires_at, now),
                "accessed_count": t.accessed_count,
                "last_accessed_at": t.last_accessed_at.isoformat() if t.last_accessed_at else None,
                "created_at": t.created_at.isoformat(),
                "share_url": f"/share/{t.token}",
            }
            for t in tokens
        ]}

    # ── Revoke a share token ───────────────────────────────────────────────
    @app.post("/api/v1/share/{token}/revoke")
    def revoke_share_token(
        token: str,
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("analyst")),
    ) -> dict:
        csrf_token = request.headers.get("X-CSRF-Token")
        validate_csrf(request, csrf_token)
        share = db.query(ReportShareToken).filter(
            ReportShareToken.token == token, ReportShareToken.tenant_id == user.tenant_id
        ).first()
        if share is None:
            raise HTTPException(status_code=404, detail="Share token not found")
        share.revoked = True
        db.commit()
        log_event(db, request, event_type="share_token_revoked", user=user, metadata={"share_token_id": share.id})
        return {"revoked": True}

    # ── Public: fetch shared report ────────────────────────────────────────
    @app.get("/api/v1/share/{token}")
    def get_shared_report(token: str, request: Request, db: Session = Depends(get_db)) -> dict:
        share = db.query(ReportShareToken).filter(ReportShareToken.token == token).first()
        if share is None:
            raise HTTPException(status_code=404, detail="Share link not found or expired")
        now = _utc_now()
        if share.revoked:
            raise HTTPException(status_code=410, detail="This share link has been revoked")
        if _is_expired(share.expires_at, now):
            raise HTTPException(status_code=410, detail="This share link has expired")
        upload = db.query(ScanUpload).filter(ScanUpload.id == share.upload_id).first()
        if upload is None:
            raise HTTPException(status_code=404, detail="Report no longer available")
        # Update access tracking
        share.accessed_count = (share.accessed_count or 0) + 1
        share.last_accessed_at = now
        db.commit()
        _log.info("share_report_accessed token_id=%s upload_id=%s ip=%s", share.id, upload.id, request.client.host if request.client else "unknown")
        report_data = _build_report_response(db, upload)
        return {
            "report": report_data,
            "share": {
                "expires_at": share.expires_at.isoformat(),
                "token": token,
            },
        }
