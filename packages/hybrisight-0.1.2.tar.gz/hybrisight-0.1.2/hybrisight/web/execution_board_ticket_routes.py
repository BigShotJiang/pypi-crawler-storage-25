# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import Depends, Form, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.execution_board_helpers import (
    _build_playbook_view,
    _next_lane_order,
    _rebalance_lane_orders,
    _serialize_execution_ticket,
)
from hybrisight.web.execution_board_playbooks import resolve_playbook_for_ticket
from hybrisight.web.execution_board_route_helpers import ensure_ticket_in_active_workspace
from hybrisight.web.reassessment_series import record_ticket_event, ticket_events_payload
from hybrisight.web.models import ExecutionTicket, TenantSetting, TicketEvidence, User


def register_execution_board_ticket_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    execution_phase_labels: dict[str, str],
    execution_statuses: set[str],
    execution_wip_limit_setting_key: str,
    default_execution_wip_limit: int,
    tenant_execution_wip_limit_metadata: Callable[..., dict[str, Any]],
    notify_ticket_blocked: Callable[[str, str, str], bool] | None = None,
) -> None:
    # Valid status transitions — key: current status, value: set of allowed next statuses.
    # Forward progressions are unrestricted within a phase; backwards moves and skipping
    # validated are guarded. Closed is terminal except via explicit override.
    _ALLOWED_TRANSITIONS: dict[str, set[str]] = {
        'new':                  {'triaged', 'in_progress', 'blocked', 'deferred', 'accepted_risk', 'validated'},
        'triaged':              {'new', 'in_progress', 'blocked', 'deferred', 'accepted_risk', 'validated'},
        'in_progress':          {'triaged', 'blocked', 'ready_for_validation', 'deferred', 'accepted_risk'},
        'blocked':              {'new', 'triaged', 'in_progress', 'ready_for_validation', 'accepted_risk', 'deferred'},
        'ready_for_validation': {'in_progress', 'validated', 'blocked'},
        'validated':            {'closed', 'in_progress'},
        'deferred':             {'new', 'triaged', 'in_progress', 'blocked'},
        'accepted_risk':        {'new', 'triaged', 'closed'},
        'closed':               {'new'},  # re-open only
    }

    @app.post('/api/v1/execution-tickets/{ticket_id}/status')
    def update_execution_ticket_status(ticket_id: int, request: Request, status: str = Form(...), phase: str | None = Form(None), title: str | None = Form(None), owner: str | None = Form(None), blocked_reason: str | None = Form(None), accepted_risk_reason: str | None = Form(None), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        normalized_status = status.strip().lower()
        if normalized_status not in execution_statuses: raise HTTPException(status_code=400, detail='Invalid status')
        normalized_phase = phase.strip().lower() if phase is not None else None
        if normalized_phase is not None and normalized_phase not in execution_phase_labels: raise HTTPException(status_code=400, detail='Invalid phase')
        row = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if row is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, row)

        # Enforce valid status transitions
        current_status = row.status
        if current_status != normalized_status:
            allowed = _ALLOWED_TRANSITIONS.get(current_status, set())
            if normalized_status not in allowed:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid transition: cannot move ticket from '{current_status}' to '{normalized_status}'. "
                           f"Allowed next statuses: {', '.join(sorted(allowed)) or 'none'}.",
                )

        # Blocked status requires an explicit reason
        if normalized_status == 'blocked':
            reason_value = (blocked_reason or '').strip()
            if not reason_value:
                raise HTTPException(status_code=422, detail="A blocked_reason is required when setting status to 'blocked'.")

        previous_phase = row.phase; previous_status = row.status; previous_continuity_status = row.continuity_status; target_phase = normalized_phase if normalized_phase is not None else previous_phase
        moved_lane = target_phase != previous_phase or normalized_status != previous_status
        row.status = normalized_status
        if normalized_phase is not None: row.phase = normalized_phase
        if title is not None:
            title_value = title.strip()
            if not title_value: raise HTTPException(status_code=400, detail='Title cannot be empty')
            row.title = title_value[:255]
        if owner is not None:
            owner_value = owner.strip(); row.owner = owner_value if owner_value else None
        row.blocked_reason = ((blocked_reason or '').strip() or None) if normalized_status == 'blocked' else (blocked_reason.strip() or None if blocked_reason is not None else None)
        row.accepted_risk_reason = ((accepted_risk_reason or '').strip() or 'Accepted risk - rationale pending') if normalized_status == 'accepted_risk' else (accepted_risk_reason.strip() or None if accepted_risk_reason is not None else None)

        if normalized_status in {'validated', 'closed'}:
            playbook, override, resolution = resolve_playbook_for_ticket(db, user.tenant_id, row)
            if playbook is not None:
                required = set(_build_playbook_view(playbook, override, resolution).get('required_evidence', []))
                if required:
                    provided = {ev.evidence_key for ev in db.query(TicketEvidence).filter(TicketEvidence.ticket_id == row.id, TicketEvidence.tenant_id == user.tenant_id).all()}
                    missing = sorted(required - provided)
                    if missing: raise HTTPException(status_code=400, detail=f"Cannot move to {normalized_status}: missing required evidence keys: {', '.join(missing)}")

        if moved_lane:
            row.depends_on_ticket_id = None
            row.lane_order = _next_lane_order(db, user.tenant_id, row.phase, row.status)

        record_ticket_event(
            db,
            tenant_id=user.tenant_id,
            ticket_id=row.id,
            upload_id=row.upload_id,
            actor_user_id=user.id,
            event_type='status_updated',
            previous_status=previous_status,
            next_status=row.status,
            previous_continuity_status=previous_continuity_status,
            next_continuity_status=row.continuity_status,
            details={'phase': row.phase, 'previous_phase': previous_phase},
        )
        db.commit(); db.refresh(row)
        log_event(db, request, event_type='execution_ticket_status_updated', user=user, metadata={'ticket_id': row.id, 'status': row.status})
        if normalized_status == 'blocked' and notify_ticket_blocked and row.blocked_reason:
            notify_ticket_blocked(user.email, row.title or f"Ticket #{row.id}", row.blocked_reason)
        depends_on = db.query(ExecutionTicket).filter(ExecutionTicket.tenant_id == user.tenant_id, ExecutionTicket.id == row.depends_on_ticket_id).first() if row.depends_on_ticket_id else None
        return {'item': _serialize_execution_ticket(row, execution_phase_labels, depends_on)}

    @app.post('/api/v1/execution-tickets/{ticket_id}/reorder')
    def reorder_execution_ticket(ticket_id: int, request: Request, direction: str = Form('top'), target_ticket_id: int | None = Form(None), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        normalized = direction.strip().lower()
        if normalized not in {'top', 'bottom', 'before', 'after'}: raise HTTPException(status_code=400, detail='Direction must be one of: top, bottom, before, after')
        row = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if row is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, row)
        lane_rows = _rebalance_lane_orders(db, user.tenant_id, row.phase, row.status)
        ordered_ids = [item.id for item in lane_rows if item.id != row.id]
        insert_index = 0 if normalized == 'top' else len(ordered_ids)
        if normalized in {'before', 'after'}:
            if target_ticket_id is None: raise HTTPException(status_code=400, detail='target_ticket_id is required for before/after reorder')
            if target_ticket_id == row.id: raise HTTPException(status_code=400, detail='Cannot reorder relative to the same ticket')
            target = db.query(ExecutionTicket).filter(ExecutionTicket.id == target_ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
            if target is None: raise HTTPException(status_code=404, detail='Target ticket not found')
            ensure_ticket_in_active_workspace(db, user.tenant_id, target)
            if target.phase != row.phase or target.status != row.status: raise HTTPException(status_code=400, detail='Target ticket must be in the same lane')
            target_index = ordered_ids.index(target.id); insert_index = target_index if normalized == 'before' else target_index + 1
        ordered_ids.insert(insert_index, row.id)
        for idx, ticket_id_value in enumerate(ordered_ids, start=1):
            item = next((candidate for candidate in lane_rows if candidate.id == ticket_id_value), row if ticket_id_value == row.id else None)
            if item is not None: item.lane_order = idx
        record_ticket_event(
            db,
            tenant_id=user.tenant_id,
            ticket_id=row.id,
            upload_id=row.upload_id,
            actor_user_id=user.id,
            event_type='reordered',
            previous_status=row.status,
            next_status=row.status,
            previous_continuity_status=row.continuity_status,
            next_continuity_status=row.continuity_status,
            details={'direction': normalized, 'target_ticket_id': target_ticket_id, 'lane_order': row.lane_order},
        )
        db.commit(); db.refresh(row)
        log_event(db, request, event_type='execution_ticket_reordered', user=user, metadata={'ticket_id': row.id, 'phase': row.phase, 'status': row.status, 'direction': normalized, 'target_ticket_id': target_ticket_id, 'lane_order': row.lane_order})
        return {'item': _serialize_execution_ticket(row, execution_phase_labels)}

    @app.post('/api/v1/execution-tickets/{ticket_id}/dependency')
    def set_execution_ticket_dependency(ticket_id: int, request: Request, depends_on_ticket_id: int | None = Form(None), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        row = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if row is None: raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, row)
        depends_on: ExecutionTicket | None = None
        if depends_on_ticket_id is not None:
            if depends_on_ticket_id == row.id: raise HTTPException(status_code=400, detail='A ticket cannot depend on itself')
            depends_on = db.query(ExecutionTicket).filter(ExecutionTicket.id == depends_on_ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
            if depends_on is None: raise HTTPException(status_code=404, detail='Dependency ticket not found')
            ensure_ticket_in_active_workspace(db, user.tenant_id, depends_on)
            row.depends_on_ticket_id = depends_on.id; row.status = 'blocked'; row.blocked_reason = f'Blocked by HBS-{depends_on.id}'
        else:
            row.depends_on_ticket_id = None
            if row.status == 'blocked' and (row.blocked_reason or '').startswith('Blocked by HBS-'): row.blocked_reason = None
        record_ticket_event(
            db,
            tenant_id=user.tenant_id,
            ticket_id=row.id,
            upload_id=row.upload_id,
            actor_user_id=user.id,
            event_type='dependency_updated',
            previous_status=None,
            next_status=row.status,
            previous_continuity_status=row.continuity_status,
            next_continuity_status=row.continuity_status,
            details={'depends_on_ticket_id': row.depends_on_ticket_id},
        )
        db.commit(); db.refresh(row)
        if row.depends_on_ticket_id:
            depends_on = db.query(ExecutionTicket).filter(ExecutionTicket.id == row.depends_on_ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        log_event(db, request, event_type='execution_ticket_dependency_updated', user=user, metadata={'ticket_id': row.id, 'depends_on_ticket_id': row.depends_on_ticket_id})
        return {'item': _serialize_execution_ticket(row, execution_phase_labels, depends_on)}

    @app.get('/api/v1/execution-tickets/{ticket_id}/history')
    def get_execution_ticket_history(ticket_id: int, db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        row = db.query(ExecutionTicket).filter(ExecutionTicket.id == ticket_id, ExecutionTicket.tenant_id == user.tenant_id).first()
        if row is None:
            raise HTTPException(status_code=404, detail='Execution ticket not found')
        ensure_ticket_in_active_workspace(db, user.tenant_id, row)
        return {'items': ticket_events_payload(db, [row.id], limit=None).get(row.id, [])}

    @app.get('/api/v1/execution-board/settings')
    def get_execution_board_settings(db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        return tenant_execution_wip_limit_metadata(db, user.tenant_id, execution_wip_limit_setting_key, default_execution_wip_limit)

    @app.post('/api/v1/execution-board/settings')
    def update_execution_board_settings(request: Request, wip_limit_in_progress: int = Form(...), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        value = max(1, min(int(wip_limit_in_progress), 50))
        row = db.query(TenantSetting).filter(TenantSetting.tenant_id == user.tenant_id, TenantSetting.key == execution_wip_limit_setting_key).first()
        if row is None:
            db.add(TenantSetting(tenant_id=user.tenant_id, key=execution_wip_limit_setting_key, value=str(value), updated_by_user_id=user.id))
        else:
            row.value = str(value); row.updated_by_user_id = user.id
        db.commit(); log_event(db, request, event_type='execution_board_settings_updated', user=user, metadata={'wip_limit_in_progress': value})
        return tenant_execution_wip_limit_metadata(db, user.tenant_id, execution_wip_limit_setting_key, default_execution_wip_limit)
