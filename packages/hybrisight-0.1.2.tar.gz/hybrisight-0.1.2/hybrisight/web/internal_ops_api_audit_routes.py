# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from typing import Any, Callable

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from hybrisight.web.models import AuditLog, ComplianceLog, Tenant, User


def register_internal_ops_api_audit_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
) -> None:
    @app.get('/api/v1/internal/audit')
    def api_internal_audit_logs(
        request: Request,
        event: str | None = None,
        tenant: str | None = None,
        email: str | None = None,
        request_id: str | None = None,
        include_http_requests: bool = False,
        limit: int = 100,
        db: Session = Depends(get_db),
        user: User = Depends(require_role('tenant_admin')),
    ) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        safe_limit = max(1, min(int(limit or 100), 500))
        query = db.query(AuditLog).order_by(AuditLog.created_at.desc())
        if event and event.strip():
            query = query.filter(AuditLog.event_type.ilike(f"%{event.strip()}%"))
        if not include_http_requests:
            query = query.filter(AuditLog.event_type != 'http_request')

        if tenant and tenant.strip():
            tenant_ids = {row.id for row in db.query(Tenant).filter(Tenant.name.ilike(f"%{tenant.strip()}%")).all()}
            if not tenant_ids:
                return {'audit_logs': []}
            query = query.filter(AuditLog.tenant_id.in_(tenant_ids))

        if email and email.strip():
            user_ids = {row.id for row in db.query(User).filter(User.email.ilike(f"%{email.strip()}%")).all()}
            if not user_ids:
                return {'audit_logs': []}
            query = query.filter(AuditLog.user_id.in_(user_ids))

        rows = query.limit(safe_limit).all()
        users_by_id = {row.id: row for row in db.query(User).filter(User.id.in_({r.user_id for r in rows if r.user_id is not None})).all()} if rows else {}
        tenants_by_id = {row.id: row for row in db.query(Tenant).filter(Tenant.id.in_({r.tenant_id for r in rows if r.tenant_id is not None})).all()} if rows else {}

        audit_logs: list[dict[str, Any]] = []
        for row in rows:
            try:
                metadata = json.loads(row.metadata_json) if row.metadata_json else {}
                metadata = metadata if isinstance(metadata, dict) else {}
            except Exception:
                metadata = {}
            if request_id and str(metadata.get('request_id', '')).strip() != request_id.strip():
                continue
            audit_logs.append({'id': row.id, 'event_type': row.event_type, 'path': row.path, 'method': row.method, 'tenant': tenants_by_id[row.tenant_id].name if row.tenant_id in tenants_by_id else (str(row.tenant_id) if row.tenant_id is not None else ''), 'user_email': users_by_id[row.user_id].email if row.user_id in users_by_id else None, 'ip_address': row.ip_address, 'metadata_json': row.metadata_json, 'request_id': str(metadata.get('request_id', '')), 'created_at': row.created_at.isoformat() if row.created_at else ''})
        return {'audit_logs': audit_logs}

    @app.get('/api/v1/internal/compliance')
    def api_internal_compliance_logs(request: Request, limit: int = 200, db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        safe_limit = max(1, min(int(limit or 200), 500))
        rows = db.query(ComplianceLog).order_by(ComplianceLog.created_at.desc()).limit(safe_limit).all()
        return {'items': [{'id': r.id, 'event_type': r.event_type, 'identifier': r.identifier, 'ip_address': r.ip_address, 'metadata_json': r.metadata_json, 'created_at': r.created_at.isoformat() if r.created_at else ''} for r in rows]}
