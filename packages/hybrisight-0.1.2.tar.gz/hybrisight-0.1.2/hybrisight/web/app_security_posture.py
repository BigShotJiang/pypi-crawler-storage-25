# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import importlib
import os

from sqlalchemy import text
from sqlalchemy.orm import Session

from hybrisight.web.service import MAX_UPLOAD_BYTES
from hybrisight.web.app_paths import env_bool


def security_posture_checks(db: Session | None = None) -> list[dict[str, str]]:
    db_status = "enabled"
    db_detail = "SQLite (Local)"
    if db:
        try:
            db.execute(text("SELECT 1"))
            db_url = os.getenv("HYBRISIGHT_WEB_DATABASE_URL", "")
            if "postgresql" in db_url:
                db_detail = "PostgreSQL (Connected)"
        except Exception as e:
            db_status = "error"
            db_detail = f"Connection Failed: {str(e)[:50]}"

    storage_type = os.getenv("HYBRISIGHT_STORAGE_TYPE", "local").lower()
    s3_status = "disabled"
    s3_detail = "Using Local Filesystem"
    if storage_type == "s3":
        bucket = os.getenv("HYBRISIGHT_S3_BUCKET", "unknown")
        try:
            from hybrisight.web.service import _get_s3_client

            _get_s3_client().head_bucket(Bucket=bucket)
            s3_status = "enabled"
            s3_detail = f"AWS S3 (Bucket: {bucket})"
        except Exception as e:
            s3_status = "error"
            s3_detail = f"S3 Access Denied: {bucket} ({str(e)[:40]})"

    pdf_status = "stub"
    pdf_detail = "No renderer found (Install weasyprint or playwright)"
    try:
        importlib.import_module("weasyprint")
        pdf_status = "enabled"
        pdf_detail = "WeasyPrint (Active)"
    except ImportError:
        try:
            importlib.import_module("playwright")
            pdf_status = "enabled"
            pdf_detail = "Playwright (Active)"
        except ImportError:
            pass

    mb_size = MAX_UPLOAD_BYTES / (1024 * 1024)
    return [
        {"control": "Database Connectivity", "status": db_status, "details": db_detail},
        {"control": "Object Storage (Artifacts)", "status": s3_status, "details": s3_detail},
        {"control": "PDF Report Renderer", "status": pdf_status, "details": pdf_detail},
        {"control": "Session Cookies HTTPS-Only", "status": "enabled" if env_bool("HYBRISIGHT_WEB_HTTPS_ONLY", False) else "disabled", "details": "Set HYBRISIGHT_WEB_HTTPS_ONLY=true in production."},
        {"control": "CSRF Protection", "status": "enabled", "details": "Mutable endpoints enforce CSRF token validation."},
        {"control": "Upload Size Guardrail", "status": "enabled", "details": f"Max artifact size: {mb_size:.1f} MB"},
        {"control": "Malware Scanning", "status": "enabled", "details": "Pattern-based matcher (substring match) active on all uploads. Not a full YARA engine."},
        {"control": "Rate Limiting", "status": "enabled" if env_bool("HYBRISIGHT_WEB_RATE_LIMIT_ENABLED", True) else "disabled", "details": "In-memory IP-based rate limiter active (configurable by env)."},
    ]
