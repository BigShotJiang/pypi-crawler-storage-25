# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import Depends, Form, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.scoring import assign_roadmap_phase
from hybrisight.web.execution_board_playbooks import guide_coverage_summary
from hybrisight.web.execution_board_helpers import _next_lane_order, _serialize_execution_ticket
from hybrisight.web.execution_board_route_helpers import active_upload, set_upload_state
from hybrisight.web.models import ExecutionTicket, ScanUpload, User
from hybrisight.web.reassessment_series import continuity_context_payload, ensure_upload_reassessment_context, recent_ticket_events_payload, record_ticket_event
from hybrisight.web.service import build_dashboard_payload, validate_scan_payload


def register_execution_board_workspace_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    execution_phase_labels: dict[str, str],
    execution_statuses: set[str],
    theme_phase_map: Callable[[dict[str, Any]], dict[str, str]],
    execution_ticket_title: Callable[[str, str], str],
) -> None:
    severity_rank = {"critical": 5, "high": 4, "medium": 3, "low": 2, "info": 1}

    def _observation_summary(upload: ScanUpload) -> dict[str, int]:
        result = validate_scan_payload(upload.raw_json)
        unique_rule_trigger_count = len({finding.id for finding in result.findings})
        return {
            "raw_observation_count": int(upload.finding_count or 0),
            "unique_rule_trigger_count": unique_rule_trigger_count,
        }

    def _previous_upload(db: Session, tenant_id: int, upload_id: int) -> ScanUpload | None:
        current = db.query(ScanUpload).filter(ScanUpload.tenant_id == tenant_id, ScanUpload.id == upload_id).first()
        if current is None:
            return None
        ensure_upload_reassessment_context(db, current)
        candidates = (
            db.query(ScanUpload)
            .filter(ScanUpload.tenant_id == tenant_id, ScanUpload.id < upload_id)
            .order_by(ScanUpload.id.desc())
            .all()
        )
        for candidate in candidates:
            ensure_upload_reassessment_context(db, candidate)
            if (
                candidate.assessment_scope_id == current.assessment_scope_id
                and candidate.reassessment_series_id == current.reassessment_series_id
            ):
                return candidate
        return None

    @app.get('/api/v1/execution-tickets/workspace')
    def get_execution_workspace(db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        rows = db.query(ScanUpload).filter(ScanUpload.tenant_id == user.tenant_id).order_by(ScanUpload.created_at.desc(), ScanUpload.id.desc()).limit(25).all()
        active = active_upload(db, user.tenant_id)
        items: list[dict[str, Any]] = []
        for upload in rows:
            scope_context = continuity_context_payload(db, upload)
            ticket_rows = db.query(ExecutionTicket).filter(ExecutionTicket.tenant_id == user.tenant_id, ExecutionTicket.upload_id == upload.id).all()
            total = len(ticket_rows)
            completed = sum(1 for item in ticket_rows if item.status in {'validated', 'closed'})
            observation_summary = _observation_summary(upload)
            items.append({
                'id': upload.id,
                'provider': upload.provider,
                'created_at': upload.created_at.isoformat(),
                'execution_state': (upload.execution_state or 'hold').strip().lower() or 'hold',
                'ticket_total': total,
                'completed_total': completed,
                **observation_summary,
                'guide_coverage': guide_coverage_summary(db, user.tenant_id, ticket_rows),
                'continuity_context': scope_context,
            })
        return {'active_upload_id': active.id if active else None, 'items': items}

    @app.post('/api/v1/execution-tickets/workspace/activate')
    def activate_execution_workspace_upload(request: Request, upload_id: int = Form(...), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        target = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if target is None: raise HTTPException(status_code=404, detail='Upload not found')
        others = db.query(ScanUpload).filter(ScanUpload.tenant_id == user.tenant_id, ScanUpload.id != upload_id, ScanUpload.execution_state == 'active').all()
        for row in others: set_upload_state(db, row, 'hold', user.id)
        set_upload_state(db, target, 'active', user.id)
        db.commit(); log_event(db, request, event_type='execution_workspace_activated', user=user, metadata={'upload_id': upload_id})
        return {'ok': True, 'active_upload_id': upload_id}

    @app.post('/api/v1/execution-tickets/workspace/hold')
    def hold_execution_workspace_upload(request: Request, upload_id: int | None = Form(None), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        target = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first() if upload_id is not None else active_upload(db, user.tenant_id)
        if target is None: raise HTTPException(status_code=404, detail='No matching upload to hold')
        set_upload_state(db, target, 'hold', user.id)
        db.commit(); log_event(db, request, event_type='execution_workspace_held', user=user, metadata={'upload_id': target.id})
        return {'ok': True, 'held_upload_id': target.id}

    @app.get('/api/v1/execution-tickets')
    def list_execution_tickets(phase: str | None = None, status: str | None = None, upload_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        query = db.query(ExecutionTicket).filter(ExecutionTicket.tenant_id == user.tenant_id, ExecutionTicket.upload_id.is_not(None))
        active = active_upload(db, user.tenant_id)
        if phase:
            normalized_phase = phase.strip().lower()
            if normalized_phase not in execution_phase_labels: raise HTTPException(status_code=400, detail='Invalid phase filter')
            query = query.filter(ExecutionTicket.phase == normalized_phase)
        if status:
            normalized_status = status.strip().lower()
            if normalized_status not in execution_statuses: raise HTTPException(status_code=400, detail='Invalid status filter')
            query = query.filter(ExecutionTicket.status == normalized_status)
        if upload_id is not None: query = query.filter(ExecutionTicket.upload_id == upload_id)
        elif active is not None: query = query.filter(ExecutionTicket.upload_id == active.id)
        else: return {'items': [], 'phase_counts': {k: 0 for k in execution_phase_labels}, 'status_counts': {k: 0 for k in sorted(execution_statuses)}, 'active_upload_id': None}

        rows = query.order_by(ExecutionTicket.phase.asc(), ExecutionTicket.status.asc(), ExecutionTicket.lane_order.asc(), ExecutionTicket.created_at.asc(), ExecutionTicket.id.asc()).limit(500).all()
        dependency_ids = {row.depends_on_ticket_id for row in rows if row.depends_on_ticket_id}
        dependency_map = {row.id: row for row in db.query(ExecutionTicket).filter(ExecutionTicket.tenant_id == user.tenant_id, ExecutionTicket.id.in_(dependency_ids)).all()} if dependency_ids else {}
        current_upload = db.query(ScanUpload).filter(ScanUpload.id == (upload_id if upload_id is not None else (active.id if active else -1))).first()
        events_by_ticket = recent_ticket_events_payload(db, [row.id for row in rows])
        items = [
            _serialize_execution_ticket(
                row,
                execution_phase_labels,
                dependency_map.get(row.depends_on_ticket_id or -1),
                events_by_ticket.get(row.id, []),
            )
            for row in rows
        ]
        phase_counts: dict[str, int] = {key: 0 for key in execution_phase_labels}; status_counts: dict[str, int] = {key: 0 for key in sorted(execution_statuses)}
        for row in rows:
            phase_counts[row.phase] = phase_counts.get(row.phase, 0) + 1
            status_counts[row.status] = status_counts.get(row.status, 0) + 1
        return {
            'items': items,
            'phase_counts': phase_counts,
            'status_counts': status_counts,
            'active_upload_id': active.id if active is not None else None,
            'continuity_context': continuity_context_payload(db, current_upload),
        }

    @app.post('/api/v1/execution-tickets/bootstrap')
    def bootstrap_execution_tickets(request: Request, upload_id: int = Form(...), replace_existing: bool = Form(False), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('analyst'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        upload = db.query(ScanUpload).filter(ScanUpload.id == upload_id, ScanUpload.tenant_id == user.tenant_id).first()
        if upload is None: raise HTTPException(status_code=404, detail='Upload not found')
        ensure_upload_reassessment_context(db, upload)
        if (upload.execution_state or 'hold').strip().lower() != 'active':
            raise HTTPException(status_code=409, detail=(f'Upload #{upload_id} is not active ({upload.execution_state or "hold"}). Activate this report in workspace before generating tickets.'))

        result = validate_scan_payload(upload.raw_json); context = build_dashboard_payload(result); phase_map = theme_phase_map(context.get('roadmap', {}))
        phase_rank = {'30_days': 0, '60_days': 1, '90_days': 2}; finding_phase_map: dict[str, str] = {}
        for finding in result.findings:
            p = assign_roadmap_phase(finding); key = finding.id; current = finding_phase_map.get(key)
            if current is None or phase_rank[p] < phase_rank[current]: finding_phase_map[key] = p
        grouped = context.get('findings_grouped', [])
        if not isinstance(grouped, list): raise HTTPException(status_code=400, detail='Upload payload did not provide grouped findings')
        if replace_existing:
            db.query(ExecutionTicket).filter(ExecutionTicket.tenant_id == user.tenant_id, ExecutionTicket.upload_id == upload_id).delete(synchronize_session=False)
            db.commit()

        existing_rows = db.query(ExecutionTicket.finding_id, ExecutionTicket.theme, ExecutionTicket.upload_id).filter(ExecutionTicket.tenant_id == user.tenant_id, ExecutionTicket.upload_id == upload_id).all()
        existing_keys = {(row[0], row[1], row[2]) for row in existing_rows}
        previous_upload = _previous_upload(db, user.tenant_id, upload_id)
        previous_ticket_map: dict[tuple[str, str], ExecutionTicket] = {}
        if previous_upload is not None:
            previous_rows = (
                db.query(ExecutionTicket)
                .filter(ExecutionTicket.tenant_id == user.tenant_id, ExecutionTicket.upload_id == previous_upload.id)
                .all()
            )
            previous_ticket_map = {(row.finding_id, row.theme): row for row in previous_rows}
        matched_previous_keys: set[tuple[str, str]] = set()
        created = 0
        reopened = 0
        carried_forward = 0
        validated_by_rerun = 0
        for group in grouped:
            if not isinstance(group, dict): continue
            theme = str(group.get('theme') or '').strip(); rules = group.get('rules', [])
            if not isinstance(rules, list): continue
            for rule in rules:
                if not isinstance(rule, dict): continue
                finding_id = str(rule.get('id') or '').strip()
                if not finding_id: continue
                phase_value = finding_phase_map.get(finding_id, phase_map.get(theme, '60_days'))
                dedupe_key = (finding_id, theme, upload_id)
                if dedupe_key in existing_keys: continue
                prior = previous_ticket_map.get((finding_id, theme))
                continuity_status = 'new'
                status_value = 'new'
                owner_value = None
                blocked_reason_value = None
                accepted_risk_reason_value = None
                origin_upload_id = upload_id
                matched_from_ticket_id = None
                if prior is not None:
                    matched_previous_keys.add((finding_id, theme))
                    origin_upload_id = int(prior.origin_upload_id or prior.upload_id or upload_id)
                    matched_from_ticket_id = prior.id
                    owner_value = prior.owner
                    previous_severity = str(prior.severity or 'medium').lower()
                    next_severity = str(rule.get('severity') or 'medium').lower()
                    previous_occurrence = int(prior.occurrence_count or 0)
                    next_occurrence = int(rule.get('occurrence_count') or 1)
                    previous_resources = int(prior.affected_resource_count or 0)
                    next_resources = int(rule.get('affected_resource_count') or 0)
                    if prior.status in {'validated', 'closed'}:
                        continuity_status = 'reopened'
                        reopened += 1
                    elif (
                        severity_rank.get(next_severity, 0) < severity_rank.get(previous_severity, 0)
                        or next_occurrence < previous_occurrence
                        or next_resources < previous_resources
                    ):
                        continuity_status = 'reduced'
                        status_value = prior.status
                        carried_forward += 1
                    else:
                        continuity_status = 'persistent'
                        status_value = prior.status
                        carried_forward += 1
                    if status_value == 'blocked':
                        blocked_reason_value = prior.blocked_reason
                    if status_value == 'accepted_risk':
                        accepted_risk_reason_value = prior.accepted_risk_reason
                lane_order = _next_lane_order(db, user.tenant_id, phase_value, status_value)
                ticket = ExecutionTicket(
                    tenant_id=user.tenant_id,
                    upload_id=upload_id,
                    assessment_scope_id=upload.assessment_scope_id,
                    reassessment_series_id=upload.reassessment_series_id,
                    origin_upload_id=origin_upload_id,
                    last_seen_upload_id=upload_id,
                    matched_from_ticket_id=matched_from_ticket_id,
                    continuity_status=continuity_status,
                    finding_id=finding_id,
                    title=execution_ticket_title(theme, str(rule.get('title') or finding_id)),
                    theme=theme,
                    phase=phase_value,
                    severity=str(rule.get('severity') or 'medium'),
                    business_impact=str(rule.get('business_impact') or ''),
                    affected_resource_count=int(rule.get('affected_resource_count') or 0),
                    occurrence_count=int(rule.get('occurrence_count') or 1),
                    status=status_value,
                    owner=owner_value,
                    blocked_reason=blocked_reason_value,
                    accepted_risk_reason=accepted_risk_reason_value,
                    lane_order=lane_order,
                )
                db.add(ticket)
                db.flush()
                record_ticket_event(
                    db,
                    tenant_id=user.tenant_id,
                    ticket_id=ticket.id,
                    upload_id=upload_id,
                    actor_user_id=user.id,
                    event_type='continuity_seeded',
                    next_status=status_value,
                    next_continuity_status=continuity_status,
                    details={'matched_from_ticket_id': matched_from_ticket_id, 'upload_id': upload_id},
                )
                created += 1
        if previous_upload is not None:
            for key, prior in previous_ticket_map.items():
                if key in matched_previous_keys:
                    continue
                dedupe_key = (prior.finding_id, prior.theme, upload_id)
                if dedupe_key in existing_keys:
                    continue
                ticket = ExecutionTicket(
                    tenant_id=user.tenant_id,
                    upload_id=upload_id,
                    assessment_scope_id=upload.assessment_scope_id,
                    reassessment_series_id=upload.reassessment_series_id,
                    origin_upload_id=int(prior.origin_upload_id or prior.upload_id or upload_id),
                    last_seen_upload_id=upload_id,
                    matched_from_ticket_id=prior.id,
                    continuity_status='validated_by_rerun',
                    finding_id=prior.finding_id,
                    title=prior.title,
                    theme=prior.theme,
                    phase=prior.phase,
                    severity=prior.severity,
                    business_impact=prior.business_impact,
                    affected_resource_count=0,
                    occurrence_count=0,
                    status='validated',
                    owner=prior.owner,
                    lane_order=_next_lane_order(db, user.tenant_id, prior.phase, 'validated'),
                )
                db.add(ticket)
                db.flush()
                record_ticket_event(
                    db,
                    tenant_id=user.tenant_id,
                    ticket_id=ticket.id,
                    upload_id=upload_id,
                    actor_user_id=user.id,
                    event_type='validated_by_rerun',
                    previous_status=prior.status,
                    next_status='validated',
                    previous_continuity_status=prior.continuity_status,
                    next_continuity_status='validated_by_rerun',
                    details={'matched_from_ticket_id': prior.id, 'upload_id': upload_id},
                )
                created += 1
                validated_by_rerun += 1
        db.commit()
        ticket_rows = db.query(ExecutionTicket).filter(ExecutionTicket.tenant_id == user.tenant_id, ExecutionTicket.upload_id == upload_id).all()
        coverage = guide_coverage_summary(db, user.tenant_id, ticket_rows)
        observation_summary = _observation_summary(upload)
        continuity_counts = {
            'new': sum(1 for row in ticket_rows if row.continuity_status == 'new'),
            'persistent': sum(1 for row in ticket_rows if row.continuity_status == 'persistent'),
            'reduced': sum(1 for row in ticket_rows if row.continuity_status == 'reduced'),
            'validated_by_rerun': sum(1 for row in ticket_rows if row.continuity_status == 'validated_by_rerun'),
            'reopened': sum(1 for row in ticket_rows if row.continuity_status == 'reopened'),
        }
        log_event(db, request, event_type='execution_tickets_bootstrapped', user=user, metadata={'upload_id': upload_id, 'created': created, 'replace_existing': replace_existing, 'guide_coverage': coverage, 'continuity': continuity_counts})
        return {'upload_id': upload_id, 'created': created, 'total_for_upload': len(ticket_rows), **observation_summary, 'guide_coverage': coverage, 'continuity': continuity_counts}
