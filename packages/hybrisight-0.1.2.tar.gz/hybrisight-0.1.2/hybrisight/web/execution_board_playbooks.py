# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from typing import Any

from sqlalchemy.orm import Session

from hybrisight.web.models import ExecutionTicket, RemediationPlaybook, TenantPlaybookOverride


def parse_json_list(raw: str | None) -> list[str]:
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
    except Exception:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(item).strip() for item in parsed if str(item).strip()]


def json_list(items: list[str]) -> str:
    cleaned = [str(item).strip() for item in items if str(item).strip()]
    return json.dumps(cleaned)


def provider_from_finding_id(finding_id: str) -> str:
    prefix = str(finding_id or "").split(".", 1)[0].strip().lower()
    return prefix or "multi"


def resolve_playbook_for_ticket(
    db: Session,
    tenant_id: int,
    ticket: ExecutionTicket,
) -> tuple[RemediationPlaybook | None, TenantPlaybookOverride | None, str]:
    provider = provider_from_finding_id(ticket.finding_id)
    playbook = (
        db.query(RemediationPlaybook)
        .filter(
            RemediationPlaybook.provider == provider,
            RemediationPlaybook.finding_id == ticket.finding_id,
        )
        .order_by(RemediationPlaybook.updated_at.desc())
        .first()
    )
    resolution = "exact"
    if playbook is None:
        playbook = (
            db.query(RemediationPlaybook)
            .filter(
                RemediationPlaybook.provider == provider,
                RemediationPlaybook.theme == ticket.theme,
            )
            .order_by(RemediationPlaybook.updated_at.desc())
            .first()
        )
        resolution = "provider_theme"
    if playbook is None:
        return None, None, "generated"

    override = (
        db.query(TenantPlaybookOverride)
        .filter(
            TenantPlaybookOverride.tenant_id == tenant_id,
            TenantPlaybookOverride.playbook_id == playbook.id,
        )
        .order_by(TenantPlaybookOverride.updated_at.desc())
        .first()
    )
    return playbook, override, resolution


def build_playbook_view(playbook: RemediationPlaybook, override: TenantPlaybookOverride | None, resolution: str) -> dict[str, Any]:
    practical_steps = parse_json_list(
        override.practical_steps_json if override and override.practical_steps_json else playbook.practical_steps_json
    )
    validation_checks = parse_json_list(
        override.validation_checks_json if override and override.validation_checks_json else playbook.validation_checks_json
    )
    rollback_steps = parse_json_list(
        override.rollback_steps_json if override and override.rollback_steps_json else playbook.rollback_steps_json
    )
    required_evidence = parse_json_list(
        override.required_evidence_json if override and override.required_evidence_json else playbook.required_evidence_json
    )
    return {
        "playbook_id": playbook.id,
        "finding_id": playbook.finding_id,
        "provider": playbook.provider,
        "theme": playbook.theme,
        "version": playbook.version,
        "objective": playbook.objective,
        "practical_steps": practical_steps,
        "validation_checks": validation_checks,
        "rollback_steps": rollback_steps,
        "required_evidence": required_evidence,
        "owner_role": playbook.owner_role,
        "estimated_effort": playbook.estimated_effort,
        "tenant_notes": override.tenant_notes if override else None,
        "source": resolution,
        "catalog_backed": True,
    }


def build_generated_guide(ticket: ExecutionTicket) -> dict[str, Any]:
    provider = provider_from_finding_id(ticket.finding_id)
    provider_label = provider.upper() if provider in {"aws", "azure"} else "cloud"
    theme = ticket.theme.strip() or "Governance"
    title = ticket.title.strip() or ticket.finding_id
    guidance = ticket.remediation_guidance.strip() if ticket.remediation_guidance else ""
    
    practical_steps = [
        f"Review the affected {provider_label} resources and confirm why {title} was detected.",
    ]
    if guidance:
        # If guidance has newlines, split it into multiple steps
        if "\n" in guidance:
            for line in guidance.splitlines():
                line = line.strip().lstrip("-").lstrip("•").strip()
                if line:
                    practical_steps.append(line)
        else:
            practical_steps.append(guidance)
    else:
        practical_steps.append(f"Apply the required {theme.lower()} remediation to the impacted resources and remove the triggering condition.")
    
    practical_steps.append("Record the exact change made, including owner, timestamp, and resource scope.")

    return {
        "playbook_id": 0,
        "finding_id": ticket.finding_id,
        "provider": provider,
        "theme": theme,
        "version": "generated-v1",
        "objective": f"Resolve {title} and validate that the affected {provider_label} control is operating correctly.",
        "practical_steps": practical_steps,
        "validation_checks": [
            "Re-run the relevant native cloud control or export and confirm the issue no longer appears.",
            "Verify the updated configuration on the affected resources matches the intended target state.",
            "Capture evidence showing the control before and after remediation.",
        ],
        "rollback_steps": [
            "Restore the previous configuration only if the remediation causes an operational issue.",
            "Document the rollback reason and create a follow-up ticket before re-attempting the change.",
        ],
        "required_evidence": [
            "before_after_change_record",
            "validation_rerun_output",
        ],
        "owner_role": "Cloud Platform Engineer",
        "estimated_effort": "medium",
        "tenant_notes": (
            "Generated fallback guidance is being shown because no curated remediation playbook is mapped for this "
            "finding yet. Internal Ops should review and publish a provider-specific playbook."
        ),
        "source": "generated",
        "catalog_backed": False,
    }


def resolve_ticket_guide(db: Session, tenant_id: int, ticket: ExecutionTicket) -> tuple[dict[str, Any], str]:
    playbook, override, resolution = resolve_playbook_for_ticket(db, tenant_id, ticket)
    if playbook is None:
        return build_generated_guide(ticket), "generated"
    return build_playbook_view(playbook, override, resolution), resolution


def guide_coverage_summary(db: Session, tenant_id: int, tickets: list[ExecutionTicket]) -> dict[str, int]:
    coverage = {"exact": 0, "provider_theme": 0, "generated": 0, "total": len(tickets)}
    for ticket in tickets:
        _, _, resolution = resolve_playbook_for_ticket(db, tenant_id, ticket)
        coverage[resolution] = coverage.get(resolution, 0) + 1
    return coverage
