# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from hybrisight.web.models import ClientJourney, ClientJourneyStage, ClientJourneyStep


def serialize_client_journey(journey: ClientJourney) -> dict[str, Any]:
    return {
        "id": journey.id,
        "journey_type": journey.journey_type,
        "journey_status": journey.journey_status,
        "delivery_mode": journey.delivery_mode,
        "package_type": journey.package_type,
        "tenant_id": journey.tenant_id,
        "onboarding_request_id": journey.onboarding_request_id,
        "baseline_request_id": journey.baseline_request_id,
        "contact_request_id": journey.contact_request_id,
        "engagement_id": journey.engagement_id,
        "owner_user_id": journey.owner_user_id,
        "coordinator_user_id": journey.coordinator_user_id,
        "current_stage_key": journey.current_stage_key,
        "current_step_key": journey.current_step_key,
        "started_at": journey.started_at.isoformat() if journey.started_at else None,
        "target_start_at": journey.target_start_at.isoformat() if journey.target_start_at else None,
        "target_delivery_at": journey.target_delivery_at.isoformat() if journey.target_delivery_at else None,
        "completed_at": journey.completed_at.isoformat() if journey.completed_at else None,
        "blocked_reason": journey.blocked_reason,
        "internal_notes": journey.internal_notes,
        "created_at": journey.created_at.isoformat() if journey.created_at else None,
        "updated_at": journey.updated_at.isoformat() if journey.updated_at else None,
    }


def serialize_journey_detail(
    journey: ClientJourney,
    stages: Iterable[ClientJourneyStage],
    steps: Iterable[ClientJourneyStep],
) -> dict[str, Any]:
    return {
        **serialize_client_journey(journey),
        "stages": [
            {
                "id": stage.id,
                "stage_key": stage.stage_key,
                "display_order": stage.display_order,
                "status": stage.status,
                "owner_user_id": stage.owner_user_id,
                "started_at": stage.started_at.isoformat() if stage.started_at else None,
                "completed_at": stage.completed_at.isoformat() if stage.completed_at else None,
                "blocked_reason": stage.blocked_reason,
                "notes": stage.notes,
            }
            for stage in stages
        ],
        "steps": [
            {
                "id": step.id,
                "stage_key": step.stage_key,
                "step_key": step.step_key,
                "display_order": step.display_order,
                "status": step.status,
                "completion_source": step.completion_source,
                "owner_user_id": step.owner_user_id,
                "due_at": step.due_at.isoformat() if step.due_at else None,
                "completed_at": step.completed_at.isoformat() if step.completed_at else None,
                "completed_by_user_id": step.completed_by_user_id,
                "blocking": step.blocking,
                "notes": step.notes,
                "evidence_url": step.evidence_url,
                "evidence_ref": step.evidence_ref,
            }
            for step in steps
        ],
    }
