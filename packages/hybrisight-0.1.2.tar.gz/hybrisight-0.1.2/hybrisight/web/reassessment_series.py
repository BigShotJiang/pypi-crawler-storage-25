# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import re
from collections.abc import Iterable
from typing import Any

from sqlalchemy.orm import Session

from hybrisight.continuity_metadata import continuity_metadata_from_json
from hybrisight.web.models import AssessmentScope, ExecutionTicketEvent, ReassessmentSeries, ScanUpload
from hybrisight.web.upload_assessment_summary import extract_assessment_summary

_AWS_ACCOUNT_RE = re.compile(r"\b\d{12}\b")
_AZURE_SUB_RE = re.compile(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}\b")


def _walk(value: Any) -> Iterable[tuple[str | None, Any]]:
    if isinstance(value, dict):
        for key, item in value.items():
            yield str(key), item
            yield from _walk(item)
    elif isinstance(value, list):
        for item in value:
            yield None, item
            yield from _walk(item)


def _scope_identifiers(provider: str, raw_json: str) -> list[str]:
    try:
        payload = json.loads(raw_json)
    except Exception:
        return []
    ids: set[str] = set()
    key_hints = {"account", "account_id", "subscription", "subscription_id", "tenant_id"}
    for key, item in _walk(payload):
        if not isinstance(item, str):
            continue
        lowered = (key or "").lower()
        if provider == "aws":
            if lowered in key_hints or "arn:aws:" in item or _AWS_ACCOUNT_RE.search(item):
                ids.update(_AWS_ACCOUNT_RE.findall(item))
        elif provider == "azure":
            if lowered in key_hints or "/subscriptions/" in item.lower() or _AZURE_SUB_RE.search(item):
                ids.update(match.lower() for match in _AZURE_SUB_RE.findall(item))
    return sorted(ids)


def infer_scope_descriptor(upload: ScanUpload) -> dict[str, Any]:
    explicit = _continuity_metadata(upload)
    explicit_scope = explicit.get("scope", {}) if explicit else {}
    provider = (upload.provider or "cloud").strip().lower() or "cloud"
    identifiers = _scope_identifiers(provider, upload.raw_json)
    explicit_identifiers = explicit_scope.get("identifiers")
    if isinstance(explicit_identifiers, list) and explicit_identifiers:
        identifiers = sorted({str(item).strip().lower() for item in explicit_identifiers if str(item).strip()})
    source_detail = (upload.source_detail or upload.source_type or "scan").strip().lower().replace(" ", "-")
    fingerprint_parts = [provider, source_detail]
    label_tail = "assessment scope"
    if identifiers:
        fingerprint_parts.append(",".join(identifiers))
        label_tail = f"{len(identifiers)} account{'s' if len(identifiers) != 1 else ''}" if provider == "aws" else f"{len(identifiers)} subscription{'s' if len(identifiers) != 1 else ''}"
    fingerprint = str(explicit_scope.get("fingerprint") or ":".join(part for part in fingerprint_parts if part)).strip().lower()
    return {
        "provider": provider,
        "fingerprint": fingerprint,
        "label": str(explicit_scope.get("label") or f"{provider.upper()} {label_tail}").strip(),
        "metadata": {"provider": provider, "identifiers": identifiers, "source_detail": upload.source_detail, "source_type": upload.source_type},
    }


def infer_series_descriptor(upload: ScanUpload) -> dict[str, str]:
    explicit = _continuity_metadata(upload)
    explicit_series = explicit.get("series", {}) if explicit else {}
    assessment = extract_assessment_summary(upload.raw_json)
    provider = (upload.provider or "cloud").strip().lower() or "cloud"
    assessment_type = str(assessment.get("type") or "baseline").strip().lower()
    series_key = str(explicit_series.get("key") or f"{provider}:{assessment_type}").strip().lower()
    label = str(explicit_series.get("label") or f"{provider.upper()} {str(assessment.get('label') or 'Governance Brief').strip()}").strip()
    cadence = str(explicit_series.get("cadence") or ("ad_hoc" if assessment_type in {"baseline", "foundation"} else "periodic")).strip().lower()
    return {"series_key": series_key, "label": label, "cadence": cadence}


def _continuity_metadata(upload: ScanUpload) -> dict[str, Any] | None:
    if upload.continuity_metadata_json:
        try:
            value = json.loads(upload.continuity_metadata_json)
            if isinstance(value, dict) and value:
                return value
        except Exception:
            pass
    return continuity_metadata_from_json(upload.raw_json)


def ensure_upload_reassessment_context(db: Session, upload: ScanUpload) -> tuple[AssessmentScope | None, ReassessmentSeries | None]:
    scope = db.query(AssessmentScope).filter(AssessmentScope.id == upload.assessment_scope_id).first() if upload.assessment_scope_id else None
    if scope is None:
        descriptor = infer_scope_descriptor(upload)
        scope = (
            db.query(AssessmentScope)
            .filter(AssessmentScope.tenant_id == upload.tenant_id, AssessmentScope.fingerprint == descriptor["fingerprint"])
            .first()
        )
        if scope is None:
            scope = AssessmentScope(
                tenant_id=upload.tenant_id,
                provider=descriptor["provider"],
                label=descriptor["label"],
                fingerprint=descriptor["fingerprint"],
                scope_metadata_json=json.dumps(descriptor["metadata"], sort_keys=True),
            )
            db.add(scope)
            db.flush()
        upload.assessment_scope_id = scope.id

    series = db.query(ReassessmentSeries).filter(ReassessmentSeries.id == upload.reassessment_series_id).first() if upload.reassessment_series_id else None
    if series is None:
        descriptor = infer_series_descriptor(upload)
        series = (
            db.query(ReassessmentSeries)
            .filter(
                ReassessmentSeries.tenant_id == upload.tenant_id,
                ReassessmentSeries.assessment_scope_id == scope.id,
                ReassessmentSeries.series_key == descriptor["series_key"],
            )
            .first()
        )
        if series is None:
            series = ReassessmentSeries(
                tenant_id=upload.tenant_id,
                assessment_scope_id=scope.id,
                label=descriptor["label"],
                series_key=descriptor["series_key"],
                cadence=descriptor["cadence"],
            )
            db.add(series)
            db.flush()
        upload.reassessment_series_id = series.id

    baseline = (
        db.query(ScanUpload)
        .filter(
            ScanUpload.tenant_id == upload.tenant_id,
            ScanUpload.assessment_scope_id == scope.id,
            ScanUpload.reassessment_series_id == series.id,
        )
        .order_by(ScanUpload.tenant_upload_seq.asc(), ScanUpload.id.asc())
        .first()
    )
    if baseline is not None:
        upload.baseline_upload_id = baseline.id
        if series.baseline_upload_id is None:
            series.baseline_upload_id = baseline.id
    db.flush()
    return scope, series


def continuity_context_payload(db: Session, upload: ScanUpload | None) -> dict[str, Any] | None:
    if upload is None:
        return None
    scope, series = ensure_upload_reassessment_context(db, upload)
    if scope is None or series is None:
        return None
    explicit = _continuity_metadata(upload)
    baseline_id = int(upload.baseline_upload_id or series.baseline_upload_id or upload.id)
    return {
        "baseline_upload_id": baseline_id,
        "engagement": (explicit.get("engagement") if isinstance(explicit, dict) and isinstance(explicit.get("engagement"), dict) else None),
        "scope": {"id": scope.id, "label": scope.label, "fingerprint": scope.fingerprint, "provider": scope.provider},
        "series": {"id": series.id, "label": series.label, "key": series.series_key, "cadence": series.cadence},
        "source": upload.continuity_metadata_source or "inferred",
        "artifact_digest": upload.artifact_continuity_digest,
    }


def record_ticket_event(
    db: Session,
    *,
    tenant_id: int,
    ticket_id: int,
    upload_id: int | None,
    actor_user_id: int | None,
    event_type: str,
    previous_status: str | None = None,
    next_status: str | None = None,
    previous_continuity_status: str | None = None,
    next_continuity_status: str | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    db.add(
        ExecutionTicketEvent(
            tenant_id=tenant_id,
            ticket_id=ticket_id,
            upload_id=upload_id,
            actor_user_id=actor_user_id,
            event_type=event_type,
            previous_status=previous_status,
            next_status=next_status,
            previous_continuity_status=previous_continuity_status,
            next_continuity_status=next_continuity_status,
            details_json=json.dumps(details or {}, sort_keys=True),
        )
    )


def ticket_events_payload(
    db: Session,
    ticket_ids: list[int],
    *,
    limit: int | None = 5,
) -> dict[int, list[dict[str, Any]]]:
    if not ticket_ids:
        return {}
    rows = (
        db.query(ExecutionTicketEvent)
        .filter(ExecutionTicketEvent.ticket_id.in_(ticket_ids))
        .order_by(ExecutionTicketEvent.created_at.desc(), ExecutionTicketEvent.id.desc())
        .all()
    )
    events_by_ticket: dict[int, list[dict[str, Any]]] = {}
    for row in rows:
        bucket = events_by_ticket.setdefault(row.ticket_id, [])
        if limit is not None and len(bucket) >= limit:
            continue
        bucket.append(
            {
                "id": row.id,
                "event_type": row.event_type,
                "previous_status": row.previous_status,
                "next_status": row.next_status,
                "previous_continuity_status": row.previous_continuity_status,
                "next_continuity_status": row.next_continuity_status,
                "details": json.loads(row.details_json or "{}"),
                "created_at": row.created_at.isoformat(),
            }
        )
    return events_by_ticket


def recent_ticket_events_payload(db: Session, ticket_ids: list[int]) -> dict[int, list[dict[str, Any]]]:
    return ticket_events_payload(db, ticket_ids, limit=5)
