# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

JOURNEY_TYPES = (
    "baseline_intake",
    "onboarding_request",
    "delivery_follow_through",
    "manual_internal",
)

JOURNEY_STATUSES = (
    "draft",
    "active",
    "blocked",
    "completed",
    "cancelled",
)

DELIVERY_MODES = (
    "consultant_led",
    "client_controlled_read_only",
)

PACKAGE_TYPES = (
    "foundation",
    "baseline",
    "stabilisation",
    "retainer",
    "custom",
)

STAGE_STATUSES = (
    "not_started",
    "in_progress",
    "completed",
    "blocked",
    "not_applicable",
)

STEP_STATUSES = STAGE_STATUSES

STEP_COMPLETION_SOURCES = (
    "manual",
    "system",
    "derived",
)

JOURNEY_STAGE_KEYS = (
    "intake_review",
    "commercial_readiness",
    "delivery_setup",
    "baseline_collection",
    "delivery_execution",
    "client_handoff",
    "follow_through",
)

COMMON_STAGE_STEP_KEYS: dict[str, tuple[str, ...]] = {
    "intake_review": (
        "intake_request_linked",
        "contact_identity_verified",
        "company_scope_reviewed",
        "delivery_discussion_started",
        "intake_disposition_recorded",
    ),
    "commercial_readiness": (
        "package_type_confirmed",
        "commercial_owner_assigned",
        "terms_acceptance_verified",
        "payment_gate_policy_set",
        "commercial_path_recorded",
    ),
    "delivery_setup": (
        "delivery_mode_selected",
        "primary_contact_confirmed",
        "tenant_linkage_confirmed",
        "client_setup_guidance_sent",
    ),
    "baseline_collection": (
        "setup_confirmation_received",
        "baseline_artifact_received",
        "signature_status_checked",
        "collection_quality_checked",
        "fallback_warning_reviewed",
    ),
    "delivery_execution": (
        "delivery_pipeline_record_created",
        "workflow_state_initialized",
        "release_gate_set",
        "delivery_owner_assigned",
    ),
    "client_handoff": (
        "deliverable_issued",
        "client_notified",
        "delivery_note_recorded",
        "release_conditions_satisfied",
        "client_acknowledgement_recorded",
    ),
    "follow_through": (
        "followup_date_set",
        "open_blockers_recorded",
        "journey_outcome_recorded",
        "journey_closed",
    ),
}

CONSULTANT_LED_STEP_KEYS = (
    "consultant_owner_assigned",
    "advisory_cadence_scheduled",
    "consultant_access_plan_recorded",
    "internal_delivery_brief_prepared",
    "governance_brief_prepared",
    "consultant_review_scheduled",
    "execution_board_seeded",
)

CLIENT_CONTROLLED_STEP_KEYS = (
    "readonly_access_instructions_sent",
    "cli_or_api_path_confirmed",
    "signing_guidance_sent",
    "validation_expectations_shared",
    "handoff_materials_prepared",
    "execution_expectations_recorded",
    "validation_criteria_recorded",
)

BRANCH_STAGE_STEP_KEYS: dict[str, dict[str, tuple[str, ...]]] = {
    "consultant_led": {
        "delivery_setup": CONSULTANT_LED_STEP_KEYS[:4],
        "delivery_execution": CONSULTANT_LED_STEP_KEYS[4:],
    },
    "client_controlled_read_only": {
        "delivery_setup": CLIENT_CONTROLLED_STEP_KEYS[:4],
        "delivery_execution": CLIENT_CONTROLLED_STEP_KEYS[4:],
    },
}

ALL_BRANCH_STEP_KEYS = CONSULTANT_LED_STEP_KEYS + CLIENT_CONTROLLED_STEP_KEYS


def stage_step_keys_for_mode(stage_key: str, delivery_mode: str | None = None) -> tuple[str, ...]:
    common = COMMON_STAGE_STEP_KEYS.get(stage_key, ())
    if not delivery_mode:
        return common
    branch = BRANCH_STAGE_STEP_KEYS.get(delivery_mode, {}).get(stage_key, ())
    return common + branch
