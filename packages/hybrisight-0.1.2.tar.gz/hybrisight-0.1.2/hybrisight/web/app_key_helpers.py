# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import HTTPException
from sqlalchemy.orm import Session

from hybrisight.web.models import ApiKey, Tenant, User
from hybrisight.web.security import generate_api_key, hash_api_key


def create_api_key_row(db: Session, user: User, name: str, scope: str, soft_expires_days: int = 90) -> tuple[ApiKey, str]:
    raw_key = generate_api_key()
    days = max(1, min(soft_expires_days, 3650))
    soft_expires_at = datetime.now(UTC) + timedelta(days=days)
    row = ApiKey(
        tenant_id=user.tenant_id,
        created_by_id=user.id,
        name=name,
        key_hash=hash_api_key(raw_key),
        scope=scope,
        active=True,
        soft_expires_at=soft_expires_at,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row, raw_key


def tenant_api_key_or_404(db: Session, user: User, api_key_id: int) -> ApiKey:
    row = db.query(ApiKey).filter(ApiKey.id == api_key_id, ApiKey.tenant_id == user.tenant_id).first()
    if row is None:
        raise HTTPException(status_code=404, detail="API key not found")
    return row


def get_api_key_actor(db: Session, raw_key: str | None, tenant_is_active: any, tenant_state_message: any) -> tuple[ApiKey, Tenant, bool]:
    if not raw_key:
        raise HTTPException(status_code=401, detail="Missing API key")
    row = db.query(ApiKey).filter(ApiKey.key_hash == hash_api_key(raw_key), ApiKey.active.is_(True)).first()
    if row is None:
        raise HTTPException(status_code=401, detail="Invalid API key")
    if row.scope != "scan_job:create":
        raise HTTPException(status_code=403, detail="API key scope does not allow scan job creation")
    tenant = db.query(Tenant).filter(Tenant.id == row.tenant_id).first()
    if tenant is None:
        raise HTTPException(status_code=401, detail="API key tenant not found")
    if not tenant_is_active(tenant):
        raise HTTPException(status_code=403, detail=tenant_state_message(tenant))
    now = datetime.now(UTC)
    if row.soft_expires_at and row.soft_expires_at.tzinfo is None:
        now = now.replace(tzinfo=None)
    soft_expired = bool(row.soft_expires_at and row.soft_expires_at < now)
    row.last_used_at = now
    db.commit()
    return row, tenant, soft_expired
