# SPDX-License-Identifier: Apache-2.0
"""Environment-driven pricing configuration for all service tiers."""

from __future__ import annotations

import os


def _float_env(key: str, default: str) -> float:
    return float(os.getenv(key, default).strip() or default)


# Self-serve (software product)
SINGLE_REPORT_FEE_GBP = _float_env("HYBRISIGHT_SINGLE_REPORT_FEE_GBP", "350")
PRO_MONTHLY_FEE_GBP = _float_env("HYBRISIGHT_PRO_MONTHLY_FEE_GBP", "300")
BUSINESS_MONTHLY_FEE_GBP = _float_env("HYBRISIGHT_BUSINESS_MONTHLY_FEE_GBP", "600")

# Assisted (consultancy-led)
BASELINE_FIXED_FEE_GBP = _float_env("HYBRISIGHT_BASELINE_FIXED_FEE_GBP", "3500")
STABILISATION_FIXED_FEE_GBP = _float_env("HYBRISIGHT_STABILISATION_FIXED_FEE_GBP", "8500")
GOVERNANCE_QUARTERLY_FEE_GBP = _float_env("HYBRISIGHT_GOVERNANCE_QUARTERLY_FEE_GBP", "2500")


def pricing_dict() -> dict[str, object]:
    return {
        "single_report": SINGLE_REPORT_FEE_GBP,
        "pro_monthly": PRO_MONTHLY_FEE_GBP,
        "business_monthly": BUSINESS_MONTHLY_FEE_GBP,
        "baseline": BASELINE_FIXED_FEE_GBP,
        "stabilisation": STABILISATION_FIXED_FEE_GBP,
        "governance_quarterly": GOVERNANCE_QUARTERLY_FEE_GBP,
    }
