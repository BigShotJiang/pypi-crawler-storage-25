# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from typing import Any, Callable

from fastapi import UploadFile
from sqlalchemy.orm import Session

from hybrisight.engine import apply_scoring
from hybrisight.web.service import UploadValidationError


def summary_display(summary: dict[str, Any]) -> dict[str, str]:
    posture = float(summary.get("posture_score") or 0.0)
    risk = float(summary.get("risk_index") or 0.0)
    coverage = str(summary.get("coverage_level") or "unknown").replace("_", " ").title()
    resilience = str(summary.get("resilience_indicator") or "unknown").replace("-", " ").title()
    estimated_waste = float(summary.get("estimated_waste") or 0.0)

    if posture >= 8.0:
        posture_band = "Strong"
    elif posture >= 6.0:
        posture_band = "Good"
    elif posture >= 4.0:
        posture_band = "Moderate"
    elif posture >= 2.0:
        posture_band = "Weak"
    else:
        posture_band = "Critical"

    if risk >= 85.0:
        risk_band = "Critical"
    elif risk >= 65.0:
        risk_band = "High"
    elif risk >= 40.0:
        risk_band = "Moderate"
    else:
        risk_band = "Lower"

    return {
        "posture_band": posture_band,
        "risk_band": risk_band,
        "coverage_level": coverage,
        "estimated_waste": f"GBP {estimated_waste:,.0f}",
        "resilience_indicator": resilience,
    }


def build_execution_progress(
    db: Session,
    tenant_id: int,
    upload_id: int,
    *,
    execution_ticket_model: Any,
    phase_labels: dict[str, str],
    execution_statuses: set[str],
) -> dict[str, Any]:
    rows = (
        db.query(execution_ticket_model)
        .filter(execution_ticket_model.tenant_id == tenant_id, execution_ticket_model.upload_id == upload_id)
        .all()
    )
    total = len(rows)
    phase_counts: dict[str, int] = {key: 0 for key in phase_labels}
    phase_done_counts: dict[str, int] = {key: 0 for key in phase_labels}
    status_counts: dict[str, int] = {key: 0 for key in sorted(execution_statuses)}

    for row in rows:
        phase_counts[row.phase] = phase_counts.get(row.phase, 0) + 1
        status_counts[row.status] = status_counts.get(row.status, 0) + 1
        if row.status in {"validated", "closed"}:
            phase_done_counts[row.phase] = phase_done_counts.get(row.phase, 0) + 1

    phase_completion: dict[str, dict[str, Any]] = {}
    for phase, label in phase_labels.items():
        count = phase_counts.get(phase, 0)
        done = phase_done_counts.get(phase, 0)
        completion_pct = round((done / count) * 100.0, 1) if count > 0 else 0.0
        phase_completion[phase] = {"label": label, "total": count, "validated_or_closed": done, "completion_pct": completion_pct}

    critical_total = 0
    high_total = 0
    critical_done = 0
    high_done = 0
    for row in rows:
        sev = str(row.severity).lower()
        done = row.status in {"validated", "closed"}
        if sev == "critical":
            critical_total += 1
            if done:
                critical_done += 1
        elif sev == "high":
            high_total += 1
            if done:
                high_done += 1

    return {
        "total_tickets": total,
        "validated_or_closed": status_counts.get("validated", 0) + status_counts.get("closed", 0),
        "blocked_tickets": status_counts.get("blocked", 0),
        "accepted_risk_tickets": status_counts.get("accepted_risk", 0),
        "status_counts": status_counts,
        "phase_completion": phase_completion,
        "critical_reduction": {"validated_or_closed": critical_done, "total": critical_total},
        "high_reduction": {"validated_or_closed": high_done, "total": high_total},
    }


def _estimated_waste_from_result(result: Any) -> float:
    return float(round(sum((f.estimated_annual_cost_impact_gbp or 0.0) for f in result.findings), 2))


def _finding_key(finding: Any) -> tuple[str, str]:
    return str(finding.id), str(finding.resource_id)


def _severity_counts(result: Any) -> dict[str, int]:
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for finding in result.findings:
        severity = str(finding.severity.value if hasattr(finding.severity, "value") else finding.severity).lower()
        if severity in counts:
            counts[severity] += 1
    return counts


def _snapshot_metrics(result: Any) -> dict[str, Any]:
    scored = apply_scoring(result)
    return {
        "posture_score": round(float(scored.posture_score or 0.0), 1),
        "risk_index": round(float(scored.risk_index or 0.0), 1),
        "confidence_adjusted_score": round(float(scored.confidence_adjusted_score or 0.0), 1),
        "estimated_waste": round(_estimated_waste_from_result(scored), 2),
        "severity_counts": _severity_counts(scored),
        "finding_keys": {_finding_key(finding) for finding in scored.findings},
    }


def build_trend_summary(
    db: Session,
    tenant_id: int,
    upload: Any,
    current_result: Any,
    *,
    scan_upload_model: Any,
    validate_scan_payload: Callable[[str], Any],
) -> dict[str, Any]:
    baseline_upload = (
        db.query(scan_upload_model)
        .filter(scan_upload_model.tenant_id == tenant_id, scan_upload_model.id <= upload.id)
        .order_by(scan_upload_model.id.asc())
        .first()
    )
    previous_upload = (
        db.query(scan_upload_model)
        .filter(scan_upload_model.tenant_id == tenant_id, scan_upload_model.id < upload.id)
        .order_by(scan_upload_model.id.desc())
        .first()
    )
    upload_count = (
        db.query(scan_upload_model.id)
        .filter(scan_upload_model.tenant_id == tenant_id, scan_upload_model.id <= upload.id)
        .count()
    )
    if previous_upload is None:
        return {
            "has_prior_snapshot": False,
            "message": "No prior snapshot available for trend comparison.",
            "latest_upload_id": upload.id,
            "baseline_upload_id": upload.id,
            "upload_count": upload_count,
        }

    try:
        previous_result = validate_scan_payload(previous_upload.raw_json)
    except Exception:
        return {
            "has_prior_snapshot": False,
            "message": "Prior snapshot could not be parsed for trend comparison.",
            "latest_upload_id": upload.id,
            "prior_upload_id": previous_upload.id,
            "baseline_upload_id": baseline_upload.id if baseline_upload is not None else previous_upload.id,
            "upload_count": upload_count,
        }

    baseline_result = previous_result
    baseline_upload_id = previous_upload.id
    baseline_generated_at_utc = previous_upload.generated_at_utc
    if baseline_upload is not None:
        try:
            baseline_result = validate_scan_payload(baseline_upload.raw_json)
            baseline_upload_id = baseline_upload.id
            baseline_generated_at_utc = baseline_upload.generated_at_utc
        except Exception:
            pass

    latest_metrics = _snapshot_metrics(current_result)
    previous_metrics = _snapshot_metrics(previous_result)
    baseline_metrics = _snapshot_metrics(baseline_result)

    latest_finding_keys = latest_metrics["finding_keys"]
    previous_finding_keys = previous_metrics["finding_keys"]
    findings_added = sorted(f"{item[0]}::{item[1]}" for item in (latest_finding_keys - previous_finding_keys))
    findings_resolved = sorted(f"{item[0]}::{item[1]}" for item in (previous_finding_keys - latest_finding_keys))
    findings_persistent = latest_finding_keys & previous_finding_keys

    return {
        "has_prior_snapshot": True,
        "latest_upload_id": upload.id,
        "baseline_upload_id": baseline_upload_id,
        "prior_upload_id": previous_upload.id,
        "upload_count": upload_count,
        "latest_generated_at_utc": upload.generated_at_utc,
        "baseline_generated_at_utc": baseline_generated_at_utc,
        "prior_generated_at_utc": previous_upload.generated_at_utc,
        "latest_posture_score": latest_metrics["posture_score"],
        "prior_posture_score": previous_metrics["posture_score"],
        "baseline_posture_score": baseline_metrics["posture_score"],
        "posture_score_delta": round(latest_metrics["posture_score"] - previous_metrics["posture_score"], 1),
        "posture_score_delta_vs_baseline": round(latest_metrics["posture_score"] - baseline_metrics["posture_score"], 1),
        "latest_risk_index": latest_metrics["risk_index"],
        "prior_risk_index": previous_metrics["risk_index"],
        "baseline_risk_index": baseline_metrics["risk_index"],
        "risk_index_delta": round(latest_metrics["risk_index"] - previous_metrics["risk_index"], 1),
        "risk_index_delta_vs_baseline": round(latest_metrics["risk_index"] - baseline_metrics["risk_index"], 1),
        "latest_confidence_adjusted_score": latest_metrics["confidence_adjusted_score"],
        "prior_confidence_adjusted_score": previous_metrics["confidence_adjusted_score"],
        "baseline_confidence_adjusted_score": baseline_metrics["confidence_adjusted_score"],
        "confidence_adjusted_score_delta": round(latest_metrics["confidence_adjusted_score"] - previous_metrics["confidence_adjusted_score"], 1),
        "confidence_adjusted_score_delta_vs_baseline": round(latest_metrics["confidence_adjusted_score"] - baseline_metrics["confidence_adjusted_score"], 1),
        "latest_estimated_waste": latest_metrics["estimated_waste"],
        "prior_estimated_waste": previous_metrics["estimated_waste"],
        "baseline_estimated_waste": baseline_metrics["estimated_waste"],
        "estimated_waste_delta": round(latest_metrics["estimated_waste"] - previous_metrics["estimated_waste"], 2),
        "estimated_waste_delta_vs_baseline": round(latest_metrics["estimated_waste"] - baseline_metrics["estimated_waste"], 2),
        "latest_critical_count": latest_metrics["severity_counts"]["critical"],
        "prior_critical_count": previous_metrics["severity_counts"]["critical"],
        "baseline_critical_count": baseline_metrics["severity_counts"]["critical"],
        "critical_count_delta": latest_metrics["severity_counts"]["critical"] - previous_metrics["severity_counts"]["critical"],
        "critical_count_delta_vs_baseline": latest_metrics["severity_counts"]["critical"] - baseline_metrics["severity_counts"]["critical"],
        "latest_high_count": latest_metrics["severity_counts"]["high"],
        "prior_high_count": previous_metrics["severity_counts"]["high"],
        "baseline_high_count": baseline_metrics["severity_counts"]["high"],
        "high_count_delta": latest_metrics["severity_counts"]["high"] - previous_metrics["severity_counts"]["high"],
        "high_count_delta_vs_baseline": latest_metrics["severity_counts"]["high"] - baseline_metrics["severity_counts"]["high"],
        "findings_added_count": len(findings_added),
        "findings_resolved_count": len(findings_resolved),
        "findings_persistent_count": len(findings_persistent),
        "findings_added_top": findings_added[:10],
        "findings_resolved_top": findings_resolved[:10],
    }


def parse_uploaded_scan_payload(
    payload_text: str,
    source_type: str,
    provider: str | None,
    export_type: str | None,
    *,
    validate_scan_payload: Callable[[str], Any],
    infer_native_export_type: Callable[[str], tuple[str, str] | None],
    normalize_native_export: Callable[..., Any],
) -> tuple[Any, str]:
    def _friendly_scanresult_validation_error(scan_exc: Exception) -> str:
        missing_fields: list[str] = []
        errors_attr = getattr(scan_exc, "errors", None)
        if callable(errors_attr):
            try:
                for item in errors_attr():
                    if item.get("type") != "missing":
                        continue
                    loc = item.get("loc")
                    if isinstance(loc, tuple) and loc:
                        missing_fields.append(str(loc[-1]))
            except Exception:
                missing_fields = []

        if missing_fields:
            deduped = sorted(set(missing_fields))
            required = ", ".join(deduped)
            return (
                "Uploaded JSON is not a valid HybriSight ScanResult artifact. "
                f"Missing required fields: {required}. "
                "If this is a cloud-native export, choose 'Cloud-native export' and select the matching provider/export type."
            )

        return (
            "Uploaded file is not a valid HybriSight ScanResult artifact. "
            "If this is a cloud-native export, choose 'Cloud-native export' and select the matching provider/export type."
        )

    source_type = (source_type or "scanresult").strip().lower().replace("-", "_")

    if source_type == "scanresult":
        try:
            return validate_scan_payload(payload_text), "scanresult"
        except Exception as scan_exc:
            inferred = infer_native_export_type(payload_text)
            if not inferred:
                raise UploadValidationError(_friendly_scanresult_validation_error(scan_exc))
            chosen_provider = (provider or inferred[0]).strip().lower()
            chosen_export = (export_type or inferred[1]).strip()
            return normalize_native_export(provider=chosen_provider, export_type=chosen_export, payload=payload_text), f"native_export:{chosen_export}"

    if source_type == "native_export":
        inferred = infer_native_export_type(payload_text)
        chosen_provider = (provider or (inferred[0] if inferred else None))
        chosen_export = (export_type or (inferred[1] if inferred else None))
        if not chosen_provider or not chosen_export:
            raise UploadValidationError("provider and export_type are required for native_export")
        return normalize_native_export(provider=chosen_provider, export_type=chosen_export, payload=payload_text), f"native_export:{chosen_export}"

    raise UploadValidationError("Unsupported source_type")


async def parse_optional_signature_file(
    signature_file: UploadFile | None,
    *,
    validate_upload_basics: Callable[[str | None, bytes], None],
) -> dict[str, Any] | None:
    if not signature_file:
        return None

    if not signature_file.filename:
        return None

    sig_payload = await signature_file.read()
    if not sig_payload:
        return None

    validate_upload_basics(signature_file.content_type, sig_payload)
    try:
        return json.loads(sig_payload.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise UploadValidationError(f"Invalid signature JSON: {exc}") from exc
