# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
import secrets
from datetime import UTC, datetime, timedelta
from typing import Callable
from urllib.parse import quote_plus

from fastapi import Depends, FastAPI, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from hybrisight.web.models import ClientOnboardingRequest, Tenant, User
from hybrisight.web.recaptcha import verify_recaptcha


def register_auth_login_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    get_current_user: Callable[..., User],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    slugify_tenant_slug: Callable[[str], str],
    is_valid_company_name: Callable[[str], bool],
    is_valid_email: Callable[[str], bool],
    validate_tenant_password: Callable[[str], str | None],
    tenant_is_active: Callable[[Tenant | None], bool],
    tenant_state_message: Callable[[Tenant], str],
    normalized_tenant_status: Callable[[Tenant | None], str],
    hash_password: Callable[[str], str],
    verify_password: Callable[[str, str], bool],
    needs_password_rehash: Callable[[str], bool],
    verify_totp_code: Callable[[str, str], bool],
    login_max_failed_attempts: int,
    login_lockout_minutes: int,
    send_onboarding_request_notification: Callable[[str, str, str], None],
) -> None:
    def _current_terms_version() -> str:
        return (os.getenv("HYBRISIGHT_TERMS_VERSION") or "2026-03-22").strip() or "2026-03-22"

    def _public_redirect(path: str, *, message: str | None = None, error: str | None = None, status_code: int = 302) -> RedirectResponse:
        params: list[str] = []
        if message:
            params.append(f"message={quote_plus(message)}")
        if error:
            params.append(f"error={quote_plus(error)}")
        target = f"{path}?{'&'.join(params)}" if params else path
        return RedirectResponse(url=target, status_code=status_code)

    def _record_failed_login(db: Session, user: User | None, *, request: Request, reason: str, email: str) -> None:
        if user is None:
            log_event(db, request, event_type='login_failed', user=None, metadata={'email': email, 'reason': reason})
            return
        user.failed_login_attempts = int(user.failed_login_attempts or 0) + 1
        metadata = {'email': email, 'reason': reason, 'failed_attempts': user.failed_login_attempts}
        if user.failed_login_attempts >= login_max_failed_attempts:
            user.failed_login_attempts = 0
            user.login_locked_until = datetime.now(UTC) + timedelta(minutes=login_lockout_minutes)
            metadata['locked_until'] = user.login_locked_until.isoformat()
        db.commit()
        log_event(db, request, event_type='login_failed', user=user, metadata=metadata)

    @app.post('/login')
    def login(
        request: Request,
        email: str = Form(...),
        password: str = Form(...),
        mfa_code: str = Form(''),
        csrf_token: str = Form(...),
        g_recaptcha_response: str = Form(''),
        db: Session = Depends(get_db),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        if not verify_recaptcha(g_recaptcha_response.strip() or None):
            return _public_redirect('/login', error='reCAPTCHA verification failed. Please try again.')
        user = db.query(User).filter(User.email == email).first()
        locked_until = user.login_locked_until if user else None
        if locked_until is not None and locked_until.tzinfo is None:
            locked_until = locked_until.replace(tzinfo=UTC)
        if user and locked_until and locked_until > datetime.now(UTC):
            remaining_seconds = int((locked_until - datetime.now(UTC)).total_seconds())
            if remaining_seconds >= 60:
                remaining_str = f"{remaining_seconds // 60} minute{'s' if remaining_seconds // 60 != 1 else ''}"
            else:
                remaining_str = f"{remaining_seconds} second{'s' if remaining_seconds != 1 else ''}"
            log_event(db, request, event_type='login_blocked_locked', user=user, metadata={'email': email, 'locked_until': locked_until.isoformat()})
            return _public_redirect('/login', error=f'Account temporarily locked due to too many failed attempts. Try again in {remaining_str}.', status_code=302)

        if user is None or not verify_password(password, user.password_hash):
            _record_failed_login(db, user, request=request, reason='invalid_credentials', email=email)
            return _public_redirect('/login', error='Invalid credentials')
        if needs_password_rehash(user.password_hash):
            user.password_hash = hash_password(password)
            db.commit()
        if user.mfa_enabled:
            secret = (user.mfa_secret or '').strip()
            if not secret:
                return _public_redirect('/login', error='MFA configuration is missing. Contact support to reset MFA.')
            if not mfa_code.strip():
                _record_failed_login(db, user, request=request, reason='mfa_required', email=email)
                return _public_redirect('/login', error='MFA code required for this account.')
            if not verify_totp_code(secret, mfa_code.strip()):
                _record_failed_login(db, user, request=request, reason='mfa_invalid', email=email)
                return _public_redirect('/login', error='Invalid MFA code. If your authenticator app is showing the code correctly, check that your device clock is synchronised.')

        tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
        if tenant is None:
            log_event(db, request, event_type='login_failed', user=None, metadata={'email': email, 'reason': 'tenant_not_found'})
            return _public_redirect('/login', error='Invalid account configuration.')
        if not tenant_is_active(tenant):
            log_event(db, request, event_type='login_blocked_tenant_inactive', user=user, metadata={'email': email, 'tenant_id': tenant.id, 'tenant_status': normalized_tenant_status(tenant)})
            return _public_redirect('/login', error=tenant_state_message(tenant))

        user.failed_login_attempts = 0
        user.login_locked_until = None
        db.commit()
        # Regenerate session to prevent session fixation: clear any pre-login state
        # then set a fresh CSRF token alongside the authenticated user ID.
        request.session.clear()
        request.session['csrf_token'] = secrets.token_urlsafe(32)
        request.session['user_id'] = user.id
        log_event(db, request, event_type='login_success', user=user)
        return RedirectResponse(url='/app', status_code=302)

    @app.post('/signup')
    def signup_request(
        request: Request,
        company_name: str = Form(...),
        desired_slug: str = Form(''),
        admin_email: str = Form(...),
        password: str = Form(...),
        terms_accepted: str = Form(""),
        csrf_token: str = Form(...),
        g_recaptcha_response: str = Form(''),
        db: Session = Depends(get_db),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        if not verify_recaptcha(g_recaptcha_response.strip() or None):
            return _public_redirect('/signup', error='reCAPTCHA verification failed. Please try again.')
        name = company_name.strip()
        email = admin_email.strip().lower()
        slug = slugify_tenant_slug(desired_slug if desired_slug.strip() else company_name)
        pw = password.strip()
        if not name or not slug or not email or not pw:
            return _public_redirect('/signup', error='All fields are required.')
        if not is_valid_company_name(name):
            return _public_redirect('/signup', error='Company name must be between 2 and 255 characters.')
        if not is_valid_email(email):
            return _public_redirect('/signup', error='Enter a valid admin email address.')
        password_error = validate_tenant_password(pw)
        if password_error:
            return _public_redirect('/signup', error=password_error)
        if terms_accepted.strip().lower() not in {"1", "true", "yes", "on"}:
            return _public_redirect('/signup', error='You must accept the Terms of Service and Privacy Policy before requesting an account.')
        if db.query(User).filter(User.email == email).first() is not None:
            return _public_redirect('/signup', error='Email already exists. Sign in or use a different email.')
        if db.query(Tenant).filter(Tenant.slug == slug).first() is not None:
            return _public_redirect('/signup', error='Requested tenant slug already exists. Choose a different slug.')

        pending_for_email = db.query(ClientOnboardingRequest).filter(ClientOnboardingRequest.status == 'pending', ClientOnboardingRequest.admin_email == email).first()
        pending_for_slug = db.query(ClientOnboardingRequest).filter(ClientOnboardingRequest.status == 'pending', ClientOnboardingRequest.desired_slug == slug).first()
        if pending_for_email is not None or pending_for_slug is not None:
            return _public_redirect('/signup', error='A pending request already exists for this email or slug.')

        from hybrisight.web.app_key_helpers import create_api_key_row
        from hybrisight.web.engagement_billing import stripe_enabled as _stripe_enabled
        from hybrisight.web.models_engagements import Engagement
        from hybrisight.web.pricing_config import BASELINE_FIXED_FEE_GBP as _BASELINE_FEE

        tenant = Tenant(name=name, slug=slug)
        db.add(tenant)
        db.flush()

        user = User(
            email=email,
            password_hash=hash_password(pw),
            role='tenant_admin',
            tenant_id=tenant.id,
        )
        db.add(user)
        db.flush()

        api_key_row, _ = create_api_key_row(db, user, name='Signup', scope='scan_job:create')

        engagement = Engagement(
            tenant_id=tenant.id,
            client_tenant_id=tenant.id,
            created_by_user_id=user.id,
            title=f'Baseline Assessment — {name}',
            client_name=name,
            contact_email=email,
            package_type='baseline',
            workflow_state='lead',
            delivery_mode='client_run',
            access_state='provisioned',
            payment_required_before_release=_stripe_enabled(),
            billing_provider='stripe' if _stripe_enabled() else 'none',
            currency='GBP',
            fixed_fee_amount=_BASELINE_FEE,
            quoted_amount=_BASELINE_FEE,
            report_release_state='not_started',
        )
        db.add(engagement)
        db.commit()

        log_event(db, request, event_type='signup_completed', user=None, metadata={
            'tenant_id': tenant.id, 'user_id': user.id,
            'company_name': name, 'email': email, 'engagement_id': engagement.id,
        })

        request.session.clear()
        request.session['csrf_token'] = secrets.token_urlsafe(32)
        request.session['user_id'] = user.id
        return RedirectResponse(url='/app', status_code=302)

    @app.post('/logout')
    def logout(
        request: Request,
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(get_current_user),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        log_event(db, request, event_type='logout', user=user)
        request.session.clear()
        return RedirectResponse(url='/login', status_code=302)
