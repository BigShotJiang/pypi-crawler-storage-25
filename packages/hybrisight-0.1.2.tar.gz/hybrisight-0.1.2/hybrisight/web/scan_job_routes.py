# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any, Awaitable, Callable

from fastapi import Depends, File, Form, HTTPException, Request, UploadFile
from sqlalchemy.orm import Session

from hybrisight.continuity_metadata import continuity_metadata_digest, continuity_metadata_from_result
from hybrisight.web.continuity_overrides import continuity_metadata_for_upload, continuity_override_fields
from hybrisight.web.models import ApiKey, ScanJobToken, ScanUpload, Tenant, User
from hybrisight.web.reassessment_series import ensure_upload_reassessment_context
from hybrisight.web.upload_locks import next_tenant_upload_seq, tenant_upload_lock


def register_scan_job_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    sign_command_payload: Callable[[dict[str, Any]], str],
    verify_command_payload_signature: Callable[[dict[str, Any], str], bool],
    validate_upload_basics: Callable[[str | None, bytes], None],
    validate_scan_payload: Callable[[str], Any],
    parse_optional_signature_file: Callable[[UploadFile | None], Awaitable[dict[str, Any] | None]],
    verify_signature_status: Callable[..., tuple[bool, str]],
    safe_store_artifact: Callable[[str, bytes], str],
    tenant_is_active: Callable[[Tenant | None], bool],
    tenant_state_message: Callable[[Tenant], str],
    get_api_key_actor: Callable[..., tuple[ApiKey, Tenant, bool]],
    hash_token: Callable[[str], str],
) -> None:
    @app.post("/api/v1/scan-jobs")
    def create_scan_job_token(
        request: Request,
        expires_minutes: int = Form(30),
        engagement_label: str | None = Form(None),
        engagement_key: str | None = Form(None),
        scope_label: str | None = Form(None),
        scope_fingerprint: str | None = Form(None),
        series_label: str | None = Form(None),
        series_key: str | None = Form(None),
        series_cadence: str | None = Form(None),
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))

        token = secrets.token_urlsafe(32)
        token_hash = hash_token(token)
        expires_at = datetime.now(UTC) + timedelta(minutes=max(5, min(expires_minutes, 240)))

        row = ScanJobToken(
            tenant_id=user.tenant_id,
            created_by_id=user.id,
            token_hash=token_hash,
            scope="scan_job:upload",
            expires_at=expires_at,
        )
        db.add(row)
        db.commit()
        db.refresh(row)

        log_event(db, request, event_type="scan_job_token_created", user=user, metadata={"token_id": row.id})

        command_payload = {
            "token": token,
            "tenant_id": user.tenant_id,
            "expires_at": expires_at.isoformat(),
            "upload_endpoint": "/api/v1/scan-jobs/upload",
            "source_type": "scanresult",
            **continuity_override_fields(
                engagement_label=engagement_label,
                engagement_key=engagement_key,
                scope_label=scope_label,
                scope_fingerprint=scope_fingerprint,
                series_label=series_label,
                series_key=series_key,
                series_cadence=series_cadence,
            ),
        }
        command_signature = sign_command_payload(command_payload)

        return {
            "token": token,
            "expires_at": expires_at.isoformat(),
            "usage_hint": "Use this token in ephemeral runner flow (Workflow C).",
            "upload_endpoint": "/api/v1/scan-jobs/upload",
            "command_payload": command_payload,
            "command_signature": command_signature,
            "command_signature_algorithm": "hmac-sha256",
            "command_key_id": "portal-local-v1",
            "runner_one_liner_template": (
                "docker run --rm ghcr.io/hybrisight/scanner:latest sh -lc "
                "'hybrisight scan aws --sign --output /tmp/hybrisight-findings.json && "
                "curl -sS -X POST ${HYBRISIGHT_PORTAL_URL}/api/v1/scan-jobs/upload "
                "-F token=${HYBRISIGHT_SCAN_JOB_TOKEN} "
                "-F file=@/tmp/hybrisight-findings.json'"
            ),
        }

    @app.post("/api/v1/scan-jobs/exchange")
    def exchange_scan_job_token(
        request: Request,
        expires_minutes: int = Form(30),
        engagement_label: str | None = Form(None),
        engagement_key: str | None = Form(None),
        scope_label: str | None = Form(None),
        scope_fingerprint: str | None = Form(None),
        series_label: str | None = Form(None),
        series_key: str | None = Form(None),
        series_cadence: str | None = Form(None),
        db: Session = Depends(get_db),
        actor: tuple[ApiKey, Tenant, bool] = Depends(get_api_key_actor),
    ) -> dict:
        api_key_row, tenant, soft_expired = actor
        expires_at = datetime.now(UTC) + timedelta(minutes=max(5, min(expires_minutes, 240)))
        token = secrets.token_urlsafe(32)
        token_hash = hash_token(token)

        row = ScanJobToken(
            tenant_id=tenant.id,
            created_by_id=api_key_row.created_by_id,
            token_hash=token_hash,
            scope="scan_job:upload",
            expires_at=expires_at,
        )
        db.add(row)
        db.commit()
        db.refresh(row)

        command_payload = {
            "token": token,
            "tenant_id": tenant.id,
            "expires_at": expires_at.isoformat(),
            "upload_endpoint": "/api/v1/scan-jobs/upload",
            "source_type": "scanresult",
            **continuity_override_fields(
                engagement_label=engagement_label,
                engagement_key=engagement_key,
                scope_label=scope_label,
                scope_fingerprint=scope_fingerprint,
                series_label=series_label,
                series_key=series_key,
                series_cadence=series_cadence,
            ),
        }
        command_signature = sign_command_payload(command_payload)

        creator = db.query(User).filter(User.id == api_key_row.created_by_id).first()
        log_event(db, request, event_type="scan_job_token_exchanged", user=creator, metadata={"token_id": row.id, "api_key_id": api_key_row.id})

        return {
            "token": token,
            "expires_at": expires_at.isoformat(),
            "upload_endpoint": "/api/v1/scan-jobs/upload",
            "command_payload": command_payload,
            "command_signature": command_signature,
            "command_signature_algorithm": "hmac-sha256",
            "command_key_id": "portal-local-v1",
            "api_key_soft_expired": soft_expired,
            "warning": "API key is past soft expiry; rotate key." if soft_expired else None,
        }

    @app.post("/api/v1/scan-jobs/upload")
    async def upload_scan_with_job_token(
        request: Request,
        token: str = Form(...),
        file: UploadFile = File(...),
        signature_file: UploadFile | None = File(None),
        source_type: str = Form("scanresult"),
        engagement_label: str | None = Form(None),
        engagement_key: str | None = Form(None),
        scope_label: str | None = Form(None),
        scope_fingerprint: str | None = Form(None),
        series_label: str | None = Form(None),
        series_key: str | None = Form(None),
        series_cadence: str | None = Form(None),
        command_payload_json: str | None = Form(None),
        command_signature: str | None = Form(None),
        db: Session = Depends(get_db),
    ) -> dict:
        payload = await file.read()
        validate_upload_basics(file.content_type, payload)

        token_hash = hash_token(token)
        row = db.query(ScanJobToken).filter(ScanJobToken.token_hash == token_hash).first()
        if row is None:
            raise HTTPException(status_code=401, detail="Invalid scan job token")
        if row.used:
            raise HTTPException(status_code=401, detail="Scan job token already used")
        if row.scope != "scan_job:upload":
            raise HTTPException(status_code=401, detail="Scan job token scope invalid for upload")
        now = datetime.now(UTC)
        if row.expires_at.tzinfo is None:
            now = now.replace(tzinfo=None)
        if row.expires_at < now:
            raise HTTPException(status_code=401, detail="Scan job token expired")

        if source_type != "scanresult":
            raise HTTPException(status_code=400, detail="Workflow C currently supports source_type=scanresult")

        if not command_payload_json or not command_signature:
            raise HTTPException(status_code=400, detail="command_payload_json and command_signature are required")
        try:
            command_payload = json.loads(command_payload_json)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail=f"Invalid command payload JSON: {exc}") from exc
        if not verify_command_payload_signature(command_payload, command_signature):
            raise HTTPException(status_code=401, detail="Invalid command payload signature")
        if command_payload.get("token") != token:
            raise HTTPException(status_code=401, detail="Command payload token mismatch")
        if command_payload.get("source_type") != source_type:
            raise HTTPException(status_code=401, detail="Command payload source_type mismatch")
        if command_payload.get("upload_endpoint") != "/api/v1/scan-jobs/upload":
            raise HTTPException(status_code=401, detail="Command payload upload_endpoint mismatch")
        if int(command_payload.get("tenant_id", -1)) != int(row.tenant_id):
            raise HTTPException(status_code=401, detail="Command payload tenant mismatch")
        signed_override_fields = continuity_override_fields(
            engagement_label=engagement_label,
            engagement_key=engagement_key,
            scope_label=scope_label,
            scope_fingerprint=scope_fingerprint,
            series_label=series_label,
            series_key=series_key,
            series_cadence=series_cadence,
        )
        for field_name in ("engagement_label", "engagement_key", "scope_label", "scope_fingerprint", "series_label", "series_key", "series_cadence"):
            signed_value = str(command_payload.get(field_name) or "").strip()
            posted_value = signed_override_fields.get(field_name, "")
            if signed_value != posted_value:
                raise HTTPException(status_code=401, detail=f"Command payload {field_name} mismatch")

        result = validate_scan_payload(payload.decode("utf-8"))

        sidecar_signature = await parse_optional_signature_file(signature_file)

        signature_valid, signature_source = verify_signature_status(
            result,
            sidecar_signature,
            db=db,
            tenant_id=row.tenant_id,
        )

        tenant = db.query(Tenant).filter(Tenant.id == row.tenant_id).first()
        if tenant is None:
            raise HTTPException(status_code=400, detail="Token tenant not found")
        if not tenant_is_active(tenant):
            raise HTTPException(status_code=403, detail=tenant_state_message(tenant))

        continuity_metadata, continuity_source, _ = continuity_metadata_for_upload(
            result,
            engagement_label=engagement_label,
            engagement_key=engagement_key,
            scope_label=scope_label,
            scope_fingerprint=scope_fingerprint,
            series_label=series_label,
            series_key=series_key,
            series_cadence=series_cadence,
        )
        artifact_continuity = continuity_metadata_from_result(result)

        with tenant_upload_lock(row.tenant_id):
            artifact_path = safe_store_artifact(tenant.slug, payload)
            upload = ScanUpload(
                tenant_upload_seq=next_tenant_upload_seq(db, row.tenant_id),
                tenant_id=row.tenant_id,
                uploaded_by_id=row.created_by_id,
                source_type="scanresult_ephemeral",
                provider=result.scanned_provider.value,
                schema_version=result.schema_version,
                coverage_level=result.coverage_level.value,
                signature_valid=signature_valid,
                signature_source=signature_source,
                asset_count=result.asset_count,
                finding_count=result.finding_count,
                generated_at_utc=result.generated_at_utc,
                artifact_path=artifact_path,
                continuity_metadata_json=json.dumps(continuity_metadata, sort_keys=True) if continuity_metadata else None,
                continuity_metadata_source=continuity_source,
                artifact_continuity_digest=continuity_metadata_digest(artifact_continuity),
                raw_json=result.model_dump_json(indent=2),
            )
            db.add(upload)
            db.flush()
            ensure_upload_reassessment_context(db, upload)
            row.used = True
            db.commit()
            db.refresh(upload)

        creator = db.query(User).filter(User.id == row.created_by_id).first()
        log_event(
            db,
            request,
            event_type="scan_job_upload_created",
            user=creator,
            metadata={"upload_id": upload.id, "token_id": row.id, "continuity_source": continuity_source},
        )

        return {
            "upload_id": upload.id,
            "finding_count": upload.finding_count,
            "coverage_level": upload.coverage_level,
            "signature_valid": upload.signature_valid,
        }
