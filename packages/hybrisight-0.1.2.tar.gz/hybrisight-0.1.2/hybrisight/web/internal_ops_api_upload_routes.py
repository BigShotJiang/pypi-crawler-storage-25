# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import Depends, Request
from datetime import UTC, datetime, timedelta
from sqlalchemy.orm import Session, joinedload

from hybrisight.web.internal_ops_upload_quality import build_internal_upload_quality_payload
from hybrisight.web.models import ScanUpload, User


def register_internal_ops_api_upload_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
) -> None:
    @app.get("/api/v1/internal/uploads/quality")
    def api_internal_upload_quality(
        request: Request,
        limit: int = 200,
        provider: str | None = None,
        days: int | None = None,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        safe_limit = max(1, min(int(limit or 200), 500))
        query = db.query(ScanUpload).options(joinedload(ScanUpload.tenant))
        if provider and provider.strip():
            query = query.filter(ScanUpload.provider == provider.strip().lower())
        if days is not None:
            safe_days = max(1, min(int(days), 3650))
            query = query.filter(ScanUpload.created_at >= datetime.now(UTC) - timedelta(days=safe_days))
        rows = query.order_by(ScanUpload.created_at.desc(), ScanUpload.id.desc()).limit(safe_limit).all()
        return build_internal_upload_quality_payload(rows)
