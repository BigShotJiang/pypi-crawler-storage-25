# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Callable

from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.app_internal_ops import internal_ops_root_tenant_slug
from hybrisight.web.models import Tenant, User

def _docs_root() -> Path:
    root = Path(os.getenv(
        "HYBRISIGHT_DOCS_ROOT",
        str(Path(__file__).resolve().parent.parent.parent / "docs"),
    ))
    if not root.is_dir():
        alt = Path("/app/docs")
        if alt.is_dir():
            root = alt
    return root


def _safe_doc_candidate(path: str, *, suffix: str) -> Path | None:
    docs_root = _docs_root().resolve()
    safe_path = Path(path).as_posix().lstrip("/")
    candidate = (docs_root / f"{safe_path}{suffix}").resolve()
    if not candidate.is_relative_to(docs_root):
        return None
    return candidate

CATEGORY_LABELS: dict[str, str] = {
    "client": "Client Guides",
    "consultant": "Consultant Playbook",
    "ops": "Operations",
    "reference": "Reference",
    "access-setup": "Access Setup",
    "troubleshooting": "Troubleshooting",
    "product": "Product",
    "playbook": "Playbook",
}

TITLE_OVERRIDES: dict[str, str] = {
    "dual-delivery-options": "Delivery Options",
    "security-and-data-handling": "Security & Data Handling",
    "client-onboarding-guide": "Client Onboarding",
    "compliance-friendly-workflows": "Compliance-Friendly Workflows",
    "foundation-review": "Foundation Review",
    "engagements-workflow": "Engagements Workflow",
    "client-journey-orchestration": "Client Journey Orchestration",
    "native-export-guides": "Native Export Guides",
    "internal-ops-quick-start": "Internal Ops Quick Start",
    "consultancy-delivery-runbook": "Consultancy Delivery Runbook",
    "methodology-operating-model": "Methodology Operating Model",
    "aws-readonly-access": "AWS Read-Only Setup",
    "azure-readonly-access": "Azure Read-Only Setup",
    "credential-handling": "Credential Handling",
    "aws-pilot-architecture": "AWS Pilot Architecture",
    "kubernetes-stage-helm": "Kubernetes Stage Helm",
    "smtp-relay-strategy": "SMTP Relay Strategy",
    "pypi-user-install-e2e": "PyPI User Install Guide",
    "upload-size-limit-exceeded": "Upload Size Limit",
    "ai-insights-and-trend-analysis": "AI Insights & Trend Analysis",
    "aws-landing-zone-findings": "AWS Landing Zone Findings",
}


def _gather_docs() -> dict[str, list[dict[str, str]]]:
    root_dir = _docs_root()
    if not root_dir.is_dir():
        return {}
    docs: dict[str, list[dict[str, str]]] = {}
    for root, _dirs, files in os.walk(root_dir):
        rel = Path(root).relative_to(root_dir)
        category_key = str(rel.parts[0]) if rel.parts else "other"
        audience = category_key if category_key in CATEGORY_LABELS else "reference"
        for fname in sorted(files):
            if not fname.endswith(".md") or fname == "README.md":
                continue
            slug = fname.removesuffix(".md")
            subdir = str(rel) if str(rel) != "." else ""
            title = TITLE_OVERRIDES.get(slug, slug.replace("-", " ").title())
            entry = {"slug": slug, "title": title, "path": f"{subdir}/{slug}" if subdir else slug}
            docs.setdefault(audience, []).append(entry)
    return docs


def _doc_category(path: str) -> str | None:
    parts = path.split("/")
    for p in parts:
        if p in CATEGORY_LABELS:
            return p
    return None


def _visible_categories(user: User, db: Session) -> set[str]:
    tenant = db.query(Tenant).filter(Tenant.id == user.tenant_id).first()
    is_ops = tenant is not None and tenant.slug == internal_ops_root_tenant_slug()
    if is_ops:
        return {"client", "ops", "consultant", "reference", "access-setup", "troubleshooting", "product", "playbook"}
    return {"client", "access-setup", "troubleshooting", "product"}


def register_docs_routes(
    app: Any,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
) -> None:
    @app.get("/api/v1/docs")
    def list_docs(request: Request, db: Session = Depends(get_db), user: User = Depends(require_role("viewer"))) -> dict[str, Any]:
        docs = _gather_docs()
        visible = _visible_categories(user, db)
        return {
            "categories": {k: {"label": CATEGORY_LABELS.get(k, k.title()), "docs": v} for k, v in docs.items() if k in visible},
        }

    @app.get("/api/v1/docs/{path:path}")
    def get_doc(path: str, request: Request, db: Session = Depends(get_db), user: User = Depends(require_role("viewer"))) -> dict[str, str]:
        doc_category = _doc_category(path)
        if doc_category and doc_category not in _visible_categories(user, db):
            raise HTTPException(status_code=404, detail="Document not found")
        fpath = _safe_doc_candidate(path, suffix=".md")
        if fpath is None or not fpath.exists() or not fpath.is_file():
            alt = _safe_doc_candidate(path, suffix="/README.md")
            if alt is None or not alt.exists() or not alt.is_file():
                raise HTTPException(status_code=404, detail="Document not found")
            fpath = alt
        try:
            text = fpath.read_text(encoding="utf-8")
        except Exception:
            raise HTTPException(status_code=500, detail="Failed to read document")
        return {"content": text, "title": TITLE_OVERRIDES.get(fpath.stem, fpath.stem.replace("-", " ").title())}
