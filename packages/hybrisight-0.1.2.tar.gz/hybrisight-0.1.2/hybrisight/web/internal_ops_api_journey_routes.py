# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import Body, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.client_journey_schema import DELIVERY_MODES, JOURNEY_STATUSES, JOURNEY_TYPES, PACKAGE_TYPES
from hybrisight.web.client_journey_serialization import serialize_client_journey, serialize_journey_detail
from hybrisight.web.client_journey_service import (
    create_client_journey,
    update_client_journey,
    update_client_journey_step,
)
from hybrisight.web.models import ClientJourney, ClientJourneyStage, ClientJourneyStep, User


def register_internal_ops_api_journey_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
) -> None:
    @app.get("/api/v1/internal/journeys")
    def api_internal_list_client_journeys(
        request: Request,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        rows = db.query(ClientJourney).order_by(ClientJourney.created_at.desc()).limit(200).all()
        return {"items": [serialize_client_journey(row) for row in rows]}

    @app.get("/api/v1/internal/journeys/{journey_id}")
    def api_internal_get_client_journey(
        request: Request,
        journey_id: int,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        journey = db.query(ClientJourney).filter(ClientJourney.id == journey_id).first()
        if journey is None:
            raise HTTPException(status_code=404, detail="Client journey not found")
        stages = (
            db.query(ClientJourneyStage)
            .filter(ClientJourneyStage.journey_id == journey_id)
            .order_by(ClientJourneyStage.display_order.asc(), ClientJourneyStage.id.asc())
            .all()
        )
        steps = (
            db.query(ClientJourneyStep)
            .filter(ClientJourneyStep.journey_id == journey_id)
            .order_by(ClientJourneyStep.stage_key.asc(), ClientJourneyStep.display_order.asc(), ClientJourneyStep.id.asc())
            .all()
        )
        return serialize_journey_detail(journey, stages, steps)

    @app.post("/api/v1/internal/journeys")
    def api_internal_create_client_journey(
        request: Request,
        payload: dict[str, Any] = Body(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))

        journey_type = str(payload.get("journey_type") or "baseline_intake").strip()
        journey_status = str(payload.get("journey_status") or "active").strip()
        delivery_mode_raw = str(payload.get("delivery_mode") or "").strip()
        package_type_raw = str(payload.get("package_type") or "").strip()

        if journey_type not in JOURNEY_TYPES:
            raise HTTPException(status_code=400, detail="Invalid journey type")
        if journey_status not in JOURNEY_STATUSES:
            raise HTTPException(status_code=400, detail="Invalid journey status")
        if delivery_mode_raw and delivery_mode_raw not in DELIVERY_MODES:
            raise HTTPException(status_code=400, detail="Invalid delivery mode")
        if package_type_raw and package_type_raw not in PACKAGE_TYPES:
            raise HTTPException(status_code=400, detail="Invalid package type")

        journey = create_client_journey(
            db,
            journey_type=journey_type,
            journey_status=journey_status,
            delivery_mode=delivery_mode_raw or None,
            package_type=package_type_raw or None,
            tenant_id=_optional_int(payload.get("tenant_id")),
            onboarding_request_id=_optional_int(payload.get("onboarding_request_id")),
            baseline_request_id=_optional_int(payload.get("baseline_request_id")),
            contact_request_id=_optional_int(payload.get("contact_request_id")),
            engagement_id=_optional_int(payload.get("engagement_id")),
            owner_user_id=_optional_int(payload.get("owner_user_id")),
            coordinator_user_id=_optional_int(payload.get("coordinator_user_id")),
            internal_notes=_optional_text(payload.get("internal_notes")),
        )
        db.commit()
        log_event(
            db,
            request,
            event_type="client_journey_created",
            user=user,
            metadata={
                "journey_id": journey.id,
                "journey_type": journey.journey_type,
                "delivery_mode": journey.delivery_mode,
                "package_type": journey.package_type,
            },
        )
        return {"ok": True, "item": serialize_client_journey(journey)}

    @app.post("/api/v1/internal/journeys/{journey_id}")
    def api_internal_update_client_journey(
        request: Request,
        journey_id: int,
        payload: dict[str, Any] = Body(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))
        journey = db.query(ClientJourney).filter(ClientJourney.id == journey_id).first()
        if journey is None:
            raise HTTPException(status_code=404, detail="Client journey not found")
        delivery_mode = payload.get("delivery_mode")
        package_type = payload.get("package_type")
        if delivery_mode is not None and delivery_mode not in (*DELIVERY_MODES, "", None):
            raise HTTPException(status_code=400, detail="Invalid delivery mode")
        if package_type is not None and package_type not in (*PACKAGE_TYPES, "", None):
            raise HTTPException(status_code=400, detail="Invalid package type")
        update_client_journey(
            db,
            journey=journey,
            delivery_mode=(str(delivery_mode).strip() or None) if delivery_mode is not None else None,
            package_type=(str(package_type).strip() or None) if package_type is not None else None,
            owner_user_id=_optional_int(payload.get("owner_user_id")) if "owner_user_id" in payload else None,
            coordinator_user_id=_optional_int(payload.get("coordinator_user_id")) if "coordinator_user_id" in payload else None,
            internal_notes=_optional_text(payload.get("internal_notes")) if "internal_notes" in payload else None,
            blocked_reason=_optional_text(payload.get("blocked_reason")) if "blocked_reason" in payload else None,
        )
        db.commit()
        log_event(db, request, event_type="client_journey_updated", user=user, metadata={"journey_id": journey.id})
        return {"ok": True, "item": serialize_client_journey(journey)}

    @app.post("/api/v1/internal/journeys/{journey_id}/steps/{step_id}")
    def api_internal_update_client_journey_step(
        request: Request,
        journey_id: int,
        step_id: int,
        payload: dict[str, Any] = Body(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get("csrf_token", "")).strip() or request.headers.get("X-CSRF-Token"))
        journey = db.query(ClientJourney).filter(ClientJourney.id == journey_id).first()
        if journey is None:
            raise HTTPException(status_code=404, detail="Client journey not found")
        step = db.query(ClientJourneyStep).filter(ClientJourneyStep.id == step_id, ClientJourneyStep.journey_id == journey_id).first()
        if step is None:
            raise HTTPException(status_code=404, detail="Client journey step not found")
        status = payload.get("status")
        if status is not None and status not in ("not_started", "in_progress", "completed", "blocked", "not_applicable"):
            raise HTTPException(status_code=400, detail="Invalid journey step status")
        update_client_journey_step(
            db,
            journey=journey,
            step=step,
            status=str(status).strip() if status is not None else None,
            notes=_optional_text(payload.get("notes")) if "notes" in payload else None,
            blocking=_optional_bool(payload.get("blocking")) if "blocking" in payload else None,
            owner_user_id=_optional_int(payload.get("owner_user_id")) if "owner_user_id" in payload else None,
            completed_by_user_id=user.id,
        )
        db.commit()
        log_event(db, request, event_type="client_journey_step_updated", user=user, metadata={"journey_id": journey.id, "step_id": step.id, "step_key": step.step_key, "status": step.status})
        return {
            "ok": True,
            "step": {
                "id": step.id,
                "journey_id": step.journey_id,
                "stage_key": step.stage_key,
                "step_key": step.step_key,
                "status": step.status,
                "notes": step.notes,
                "blocking": step.blocking,
            },
            "journey": serialize_client_journey(journey),
        }


def _optional_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    return int(value)


def _optional_text(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def _optional_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}
