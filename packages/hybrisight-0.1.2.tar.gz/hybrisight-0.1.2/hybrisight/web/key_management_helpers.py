# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta

from sqlalchemy.orm import Session

from hybrisight.web.models import ApiKey, User


def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def revoked_retention_days() -> int:
    return max(1, int(os.getenv("HYBRISIGHT_API_KEY_REVOKED_RETENTION_DAYS", "90")))


def coerce_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value if value.tzinfo else value.replace(tzinfo=UTC)


def purge_revoked_api_keys_for_tenant(db: Session, user: User, *, older_than_days: int) -> int:
    cutoff = datetime.now(UTC) - timedelta(days=max(1, older_than_days))
    rows = (
        db.query(ApiKey)
        .filter(ApiKey.tenant_id == user.tenant_id, ApiKey.active.is_(False))
        .all()
    )
    removed = 0
    for row in rows:
        revoked_or_created = coerce_utc(row.revoked_at) or coerce_utc(row.created_at)
        if revoked_or_created and revoked_or_created < cutoff:
            db.delete(row)
            removed += 1
    if removed > 0:
        db.commit()
    return removed
