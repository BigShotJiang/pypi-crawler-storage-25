# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import Body, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.models import TenantSetting, User


def register_internal_ops_api_health_rules_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    security_posture_checks: Callable[[Session], list[dict[str, Any]]],
    load_lockstep_health: Callable[[], dict[str, Any]],
    validate_csrf: Callable[[Request, str | None], None],
    parse_bool_like: Callable[[Any, bool], bool],
    internal_rule_setting_key: Callable[[str], str],
    internal_rule_toggle_key_prefix: str,
    log_event: Callable[..., None],
) -> None:
    @app.get('/api/v1/internal/health')
    def api_internal_health(request: Request, db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        return {'checks': security_posture_checks(db)}

    @app.get('/api/v1/internal/lockstep')
    def api_internal_lockstep(request: Request, user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        return load_lockstep_health()

    @app.get('/api/v1/internal/rules')
    def api_internal_rules(request: Request, db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        from hybrisight.checks.loader import load_rules
        from hybrisight.config import RULES_DIR

        settings_rows = (
            db.query(TenantSetting)
            .filter(TenantSetting.tenant_id == user.tenant_id, TenantSetting.key.like(f'{internal_rule_toggle_key_prefix}%'))
            .all()
        )
        enabled_by_rule_id: dict[str, bool] = {}
        for row in settings_rows:
            rule_id = str(row.key).replace(internal_rule_toggle_key_prefix, '', 1).strip()
            if rule_id:
                enabled_by_rule_id[rule_id] = parse_bool_like(row.value, default=True)

        unique_rules_by_id: dict[str, Any] = {}
        for rule in load_rules(RULES_DIR):
            if rule.id not in unique_rules_by_id:
                unique_rules_by_id[rule.id] = rule
        return {
            'items': [
                {
                    'id': rule.id,
                    'title': rule.title,
                    'provider': rule.provider,
                    'category': rule.category,
                    'severity': rule.severity,
                    'enabled': enabled_by_rule_id.get(rule.id, True),
                }
                for rule in sorted(unique_rules_by_id.values(), key=lambda r: r.id)
            ]
        }

    @app.post('/api/v1/internal/rules/{rule_id}/toggle')
    def api_internal_toggle_rule(
        request: Request,
        rule_id: str,
        payload: dict[str, Any] = Body(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role('tenant_admin')),
    ) -> dict[str, Any]:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, str(payload.get('csrf_token', '')).strip() or request.headers.get('X-CSRF-Token'))
        from hybrisight.checks.loader import load_rules
        from hybrisight.config import RULES_DIR

        if not any(rule.id == rule_id for rule in load_rules(RULES_DIR)):
            raise HTTPException(status_code=404, detail='Rule not found')

        enabled = parse_bool_like(payload.get('enabled'), default=True)
        key = internal_rule_setting_key(rule_id)
        row = db.query(TenantSetting).filter(TenantSetting.tenant_id == user.tenant_id, TenantSetting.key == key).first()
        if row is None:
            row = TenantSetting(tenant_id=user.tenant_id, key=key, value='1' if enabled else '0', updated_by_user_id=user.id)
            db.add(row)
        else:
            row.value = '1' if enabled else '0'
            row.updated_by_user_id = user.id
        db.commit()
        log_event(db, request, event_type='internal_rule_toggled', user=user, metadata={'rule_id': rule_id, 'enabled': enabled})
        return {'ok': True, 'id': rule_id, 'enabled': enabled}
