# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from hybrisight.engine_context import build_report_context
from hybrisight.models import ScanResult
from hybrisight.web.service_constants import (
    MAX_UPLOAD_BYTES,
    RateLimitExceeded,
    UploadValidationError,
    enforce_rate_limit,
    validate_upload_basics,
)
from hybrisight.web.service_native_detect import infer_native_export_type, looks_like_prowler_finding
from hybrisight.web.service_normalize import normalize_native_export
from hybrisight.web.service_parse import validate_scan_payload
from hybrisight.web.service_signature import verify_signature_status
from hybrisight.web.service_storage import _get_s3_client, delete_artifact, safe_store_artifact


def build_dashboard_payload(result: ScanResult) -> dict:
    context = build_report_context(result)
    context["result"] = result
    return context


__all__ = [
    "MAX_UPLOAD_BYTES",
    "RateLimitExceeded",
    "UploadValidationError",
    "_get_s3_client",
    "build_dashboard_payload",
    "delete_artifact",
    "enforce_rate_limit",
    "infer_native_export_type",
    "looks_like_prowler_finding",
    "normalize_native_export",
    "safe_store_artifact",
    "validate_scan_payload",
    "validate_upload_basics",
    "verify_signature_status",
]
