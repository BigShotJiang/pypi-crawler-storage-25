# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable
from urllib.parse import quote_plus

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from hybrisight.web.models import User


def register_auth_account_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    require_role: Callable[[str], Any],
    validate_csrf: Callable[[Request, str | None], None],
    log_event: Callable[..., None],
    is_valid_email: Callable[[str], bool],
    validate_tenant_password: Callable[[str], str | None],
    hash_password: Callable[[str], str],
    verify_password: Callable[[str, str], bool],
) -> None:
    assignable_roles = {'viewer', 'analyst', 'tenant_admin'}

    def _normalize_assignable_role(raw: str) -> str:
        return raw.strip().lower().replace('-', '_')

    def _is_last_tenant_admin(db: Session, *, tenant_id: int, excluding_user_id: int) -> bool:
        remaining_admins = db.query(User).filter(User.tenant_id == tenant_id, User.role == 'tenant_admin', User.id != excluding_user_id).count()
        return remaining_admins == 0

    @app.get('/account/password')
    def account_password_page(user: User = Depends(require_role('viewer'))) -> RedirectResponse:
        return RedirectResponse(url='/app?page=account', status_code=302)

    @app.post('/account/password')
    def account_password_update(request: Request, current_password: str = Form(...), new_password: str = Form(...), confirm_password: str = Form(...), csrf_token: str = Form(...), db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        current_pw = current_password.strip(); new_pw = new_password.strip(); confirm_pw = confirm_password.strip()
        if not verify_password(current_pw, user.password_hash):
            log_event(db, request, event_type='password_change_failed', user=user, metadata={'reason': 'invalid_current_password'})
            return RedirectResponse(url='/app?page=account&message=Current+password+is+incorrect', status_code=302)
        if new_pw != confirm_pw:
            return RedirectResponse(url='/app?page=account&message=New+password+and+confirmation+do+not+match', status_code=302)
        if current_pw == new_pw:
            return RedirectResponse(url='/app?page=account&message=New+password+must+be+different+from+current+password', status_code=302)
        password_error = validate_tenant_password(new_pw)
        if password_error:
            return RedirectResponse(url=f'/app?page=account&message={quote_plus(password_error)}', status_code=302)
        user.password_hash = hash_password(new_pw)
        db.commit(); log_event(db, request, event_type='password_changed', user=user, metadata={'user_id': user.id})
        return RedirectResponse(url='/app?page=account&message=Password+updated+successfully', status_code=302)

    @app.post('/api/v1/account/password')
    def account_password_update_api(request: Request, current_password: str = Form(...), new_password: str = Form(...), confirm_password: str = Form(...), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        current_pw = current_password.strip(); new_pw = new_password.strip(); confirm_pw = confirm_password.strip()
        if not verify_password(current_pw, user.password_hash): raise HTTPException(status_code=400, detail='Current password is incorrect')
        if new_pw != confirm_pw: raise HTTPException(status_code=400, detail='New password and confirmation do not match')
        if current_pw == new_pw: raise HTTPException(status_code=400, detail='New password must be different from current password')
        password_error = validate_tenant_password(new_pw)
        if password_error: raise HTTPException(status_code=400, detail=password_error)
        user.password_hash = hash_password(new_pw)
        db.commit(); log_event(db, request, event_type='password_changed', user=user, metadata={'user_id': user.id})
        return {'ok': True, 'message': 'Password updated successfully.'}

    @app.post('/api/v1/account/delete')
    def account_delete(request: Request, current_password: str = Form(...), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('viewer'))) -> dict:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        if not verify_password(current_password.strip(), user.password_hash):
            raise HTTPException(status_code=400, detail='Current password is incorrect')
        if user.role == 'tenant_admin' and _is_last_tenant_admin(db, tenant_id=user.tenant_id, excluding_user_id=user.id):
            raise HTTPException(status_code=400, detail='Last tenant admin cannot self-delete. Use tenant erasure to fulfill GDPR deletion for the full tenant.')
        user_id = user.id; email = user.email
        db.delete(user); db.commit(); request.session.clear()
        log_event(db, request, event_type='account_deleted', user=None, metadata={'deleted_user_id': user_id, 'deleted_email': email})
        return {'ok': True, 'message': 'Account deleted successfully.'}

    @app.get('/api/v1/account/users')
    def account_users_list_api(user: User = Depends(require_role('tenant_admin')), db: Session = Depends(get_db)) -> dict[str, list[dict[str, Any]]]:
        rows = db.query(User).filter(User.tenant_id == user.tenant_id).order_by(User.created_at.asc(), User.id.asc()).all()
        return {'items': [{'id': row.id, 'email': row.email, 'role': row.role, 'mfa_enabled': bool(row.mfa_enabled), 'created_at': row.created_at.isoformat() if row.created_at else None, 'is_current_user': row.id == user.id} for row in rows]}

    @app.post('/api/v1/account/users')
    def account_users_create_api(request: Request, email: str = Form(...), password: str = Form(...), role: str = Form('viewer'), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        normalized_email = email.strip().lower(); normalized_role = _normalize_assignable_role(role); clean_password = password.strip()
        if not is_valid_email(normalized_email): raise HTTPException(status_code=400, detail='Enter a valid user email address')
        if normalized_role not in assignable_roles: raise HTTPException(status_code=400, detail='Unsupported role')
        password_error = validate_tenant_password(clean_password)
        if password_error: raise HTTPException(status_code=400, detail=password_error)
        if db.query(User).filter(User.email == normalized_email).first() is not None: raise HTTPException(status_code=409, detail='Email already exists')
        created = User(tenant_id=user.tenant_id, email=normalized_email, password_hash=hash_password(clean_password), role=normalized_role)
        db.add(created); db.commit(); db.refresh(created)
        log_event(db, request, event_type='tenant_user_created', user=user, metadata={'created_user_id': created.id, 'created_user_email': created.email, 'created_user_role': created.role})
        return {'ok': True, 'id': created.id}

    @app.post('/api/v1/account/users/{target_user_id}/role')
    def account_users_update_role_api(request: Request, target_user_id: int, role: str = Form(...), csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        target = db.query(User).filter(User.id == target_user_id, User.tenant_id == user.tenant_id).first()
        if target is None: raise HTTPException(status_code=404, detail='User not found')
        if target.id == user.id: raise HTTPException(status_code=400, detail='Use another tenant admin to change your role')
        next_role = _normalize_assignable_role(role)
        if next_role not in assignable_roles: raise HTTPException(status_code=400, detail='Unsupported role')
        if target.role == 'tenant_admin' and next_role != 'tenant_admin' and _is_last_tenant_admin(db, tenant_id=user.tenant_id, excluding_user_id=target.id):
            raise HTTPException(status_code=400, detail='Cannot remove the last tenant admin')
        previous_role = target.role; target.role = next_role; db.commit()
        log_event(db, request, event_type='tenant_user_role_updated', user=user, metadata={'target_user_id': target.id, 'target_user_email': target.email, 'previous_role': previous_role, 'new_role': target.role})
        return {'ok': True}

    @app.post('/api/v1/account/users/{target_user_id}/delete')
    def account_users_delete_api(request: Request, target_user_id: int, csrf_token: str | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_role('tenant_admin'))) -> dict[str, Any]:
        validate_csrf(request, csrf_token or request.headers.get('X-CSRF-Token'))
        target = db.query(User).filter(User.id == target_user_id, User.tenant_id == user.tenant_id).first()
        if target is None: raise HTTPException(status_code=404, detail='User not found')
        if target.id == user.id: raise HTTPException(status_code=400, detail='Use account deletion to remove your own account')
        if target.role == 'tenant_admin' and _is_last_tenant_admin(db, tenant_id=user.tenant_id, excluding_user_id=target.id): raise HTTPException(status_code=400, detail='Cannot delete the last tenant admin')
        deleted_user_id = target.id; deleted_email = target.email
        db.delete(target); db.commit()
        log_event(db, request, event_type='tenant_user_deleted', user=user, metadata={'deleted_user_id': deleted_user_id, 'deleted_user_email': deleted_email})
        return {'ok': True}
