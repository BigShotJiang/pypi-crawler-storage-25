# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from typing import Any

from hybrisight.web.service_ingestion_policy import build_upload_ingestion_summary
from hybrisight.web.upload_assessment_summary import extract_assessment_summary


def extract_collection_quality(raw_json: str | None) -> dict[str, str]:
    if not raw_json:
        return {
            "quality": "unknown",
            "label": "Unknown",
            "summary": "Collection quality metadata is not available for this artifact.",
        }
    try:
        payload = json.loads(raw_json)
    except Exception:
        return {
            "quality": "unknown",
            "label": "Unknown",
            "summary": "Collection quality metadata could not be parsed from the stored artifact.",
        }
    summary = (((payload or {}).get("collection_diagnostics") or {}).get("summary") or {})
    quality = str(summary.get("quality") or "unknown")
    label = str(summary.get("label") or quality.replace("_", " ").title() or "Unknown")
    text = str(summary.get("summary") or "Collection quality metadata is not available for this artifact.")
    return {"quality": quality, "label": label, "summary": text}


def build_internal_upload_quality_payload(rows: list[Any]) -> dict[str, Any]:
    ingestion_counts: dict[str, int] = {}
    collection_counts: dict[str, int] = {}
    provider_counts: dict[str, int] = {}
    recent_items: list[dict[str, Any]] = []
    for row in rows:
        ingestion = build_upload_ingestion_summary(row)
        collection = extract_collection_quality(getattr(row, "raw_json", None))
        ingestion_counts[ingestion["quality"]] = ingestion_counts.get(ingestion["quality"], 0) + 1
        collection_counts[collection["quality"]] = collection_counts.get(collection["quality"], 0) + 1
        provider = str(getattr(row, "provider", "") or "unknown").lower()
        provider_counts[provider] = provider_counts.get(provider, 0) + 1
        recent_items.append(
            {
                "upload_id": row.id,
                "tenant_id": row.tenant_id,
                "tenant_name": getattr(getattr(row, "tenant", None), "name", "Unknown Tenant"),
                "tenant_slug": getattr(getattr(row, "tenant", None), "slug", ""),
                "tenant_upload_seq": getattr(row, "tenant_upload_seq", None),
                "provider": getattr(row, "provider", "unknown"),
                "finding_count": getattr(row, "finding_count", 0),
                "coverage_level": getattr(row, "coverage_level", "unknown"),
                "created_at": row.created_at.isoformat() if getattr(row, "created_at", None) else "",
                "ingestion": ingestion,
                "collection_quality": collection,
                "assessment": extract_assessment_summary(getattr(row, "raw_json", None)),
            }
        )
    return {
        "summary": {
            "total_uploads": len(rows),
            "ingestion_counts": ingestion_counts,
            "collection_counts": collection_counts,
            "provider_counts": provider_counts,
            "assessment_counts": {
                "foundation": sum(1 for item in recent_items if item["assessment"]["type"] == "foundation"),
                "baseline": sum(1 for item in recent_items if item["assessment"]["type"] == "baseline"),
            },
        },
        "items": recent_items,
    }
