# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from collections.abc import Iterable

from sqlalchemy import inspect, text
from sqlalchemy.engine import Connection, Engine


HEAD_REVISION = "2026_03_23_01"
REVISION_TABLE = "schema_revisions"


def _table_names(engine: Engine) -> set[str]:
    return set(inspect(engine).get_table_names())


def _column_names(engine: Engine, table_name: str) -> set[str]:
    return {column["name"] for column in inspect(engine).get_columns(table_name)}


def _add_columns_if_missing(connection: Connection, table_name: str, ddl_columns: Iterable[str]) -> None:
    existing = _column_names(connection.engine, table_name)
    for ddl in ddl_columns:
        column_name = ddl.split()[0]
        if column_name in existing:
            continue
        connection.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {ddl}"))
        existing.add(column_name)


def _ensure_revision_table(connection: Connection) -> None:
    connection.execute(
        text(
            f"""
            CREATE TABLE IF NOT EXISTS {REVISION_TABLE} (
                revision VARCHAR(64) PRIMARY KEY,
                applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
    )


def _stamp_revision(connection: Connection, revision: str) -> None:
    _ensure_revision_table(connection)
    connection.execute(text(f"DELETE FROM {REVISION_TABLE}"))
    connection.execute(
        text(f"INSERT INTO {REVISION_TABLE} (revision) VALUES (:revision)"),
        {"revision": revision},
    )


def current_db_revision(engine: Engine) -> str | None:
    if REVISION_TABLE not in _table_names(engine):
        return None
    with engine.begin() as connection:
        row = connection.execute(
            text(f"SELECT revision FROM {REVISION_TABLE} ORDER BY applied_at DESC LIMIT 1")
        ).first()
    return str(row[0]) if row else None


def migrate_legacy_schema_to_head(engine: Engine, create_all: callable[[], None]) -> str:
    create_all()
    with engine.begin() as connection:
        tables = _table_names(engine)
        if "client_onboarding_requests" in tables:
            _add_columns_if_missing(
                connection,
                "client_onboarding_requests",
                (
                    "terms_version VARCHAR(64)",
                    "terms_accepted_at TIMESTAMP",
                    "terms_acceptance_ip VARCHAR(100)",
                ),
            )
            connection.execute(
                text(
                    """
                    UPDATE client_onboarding_requests
                    SET terms_version = COALESCE(terms_version, '2026-03-22'),
                        terms_accepted_at = COALESCE(terms_accepted_at, CURRENT_TIMESTAMP)
                    """
                )
            )
        if "baseline_requests" in tables:
            _add_columns_if_missing(
                connection,
                "baseline_requests",
                (
                    "full_name VARCHAR(255)",
                    "role_title VARCHAR(255)",
                    "context_notes TEXT",
                    "ops_notification_status VARCHAR(32)",
                    "ops_notification_error TEXT",
                    "requester_notification_status VARCHAR(32)",
                    "requester_notification_error TEXT",
                ),
            )
        if "schema_migrations" in tables:
            connection.execute(text("DROP TABLE schema_migrations"))
        _stamp_revision(connection, HEAD_REVISION)
    return HEAD_REVISION
