# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote_plus

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, Response
from sqlalchemy.orm import Session

from hybrisight.web.models import CliDownloadCount, ContactFeedbackRequest
from hybrisight.web.app_paths import resolve_project_root
from hybrisight.web.pricing_config import pricing_dict

_SCRIPTS_ROOT = resolve_project_root()
SCRIPTS_DIR = (_SCRIPTS_ROOT / "scripts") if _SCRIPTS_ROOT else Path("/app/scripts")


def register_public_routes(
    app: FastAPI,
    *,
    get_db: Callable[..., Session],
    optional_user_from_session: Callable[[Request, Session], Any | None],
    tenant_is_active: Callable[[Any], bool],
    validate_csrf: Callable[[Request, str | None], None],
    is_valid_email: Callable[[str], bool],
    deliver_contact_feedback_notifications: Callable[..., Any],
    favicon_path: Path,
    render_landing_home: Callable[[Request], HTMLResponse],
    render_public_home: Callable[..., HTMLResponse],
) -> None:
    def _contact_redirect(
        *,
        message: str | None = None,
        error: str | None = None,
        warning: str | None = None,
    ) -> RedirectResponse:
        parts: list[str] = []
        if message:
            parts.append(f"message={quote_plus(message)}")
        if error:
            parts.append(f"error={quote_plus(error)}")
        if warning:
            parts.append(f"warning={quote_plus(warning)}")
        suffix = f"?{'&'.join(parts)}" if parts else ""
        return RedirectResponse(url=f"/contact-feedback{suffix}", status_code=302)

    def _record_cli_download(db: Session, script_name: str) -> None:
        row = db.query(CliDownloadCount).filter_by(script_name=script_name).first()
        if row:
            row.count += 1
        else:
            row = CliDownloadCount(script_name=script_name, count=1)
            db.add(row)
        try:
            db.commit()
        except Exception:
            db.rollback()

    @app.get("/", response_class=HTMLResponse)
    def landing_page(request: Request, db: Session = Depends(get_db)) -> HTMLResponse:
        user = optional_user_from_session(request, db)
        if user:
            return RedirectResponse(url="/app", status_code=302)
        return render_landing_home(request)

    @app.get("/favicon.ico", include_in_schema=False)
    def favicon() -> FileResponse:
        if not favicon_path.exists():
            raise HTTPException(status_code=404, detail="favicon not found")
        return FileResponse(str(favicon_path), media_type="image/x-icon")

    @app.get("/login", response_class=HTMLResponse)
    def login_page(request: Request) -> HTMLResponse:
        return render_public_home(request=request, page="login")

    @app.get("/api/v1/public/pricing")
    def public_pricing() -> dict[str, object]:
        return pricing_dict()

    @app.get("/api/v1/public/version")
    def public_cli_version() -> dict[str, str]:
        from hybrisight.web.app_paths import cli_info
        info = cli_info()
        return {"version": info["version"], "latest": info["latest_version"]}

    @app.get("/api/v1/public/install-checksums")
    def public_install_checksums() -> dict[str, str]:
        import hashlib
        result: dict[str, str] = {}
        for script_name in ("install.sh", "install.ps1"):
            script_path = SCRIPTS_DIR / script_name
            if script_path.exists():
                sha256 = hashlib.sha256(script_path.read_bytes()).hexdigest()
                result[script_name] = sha256
        return result

    @app.get("/install.sh", include_in_schema=False)
    def install_script(db: Session = Depends(get_db)) -> Response:
        sh_path = SCRIPTS_DIR / "install.sh"
        if not sh_path.exists():
            raise HTTPException(status_code=404)
        _record_cli_download(db, "install.sh")
        return FileResponse(str(sh_path), media_type="text/x-shellscript", headers={"Content-Disposition": "inline"})

    @app.get("/install.ps1", include_in_schema=False)
    def install_script_ps1(db: Session = Depends(get_db)) -> Response:
        ps1_path = SCRIPTS_DIR / "install.ps1"
        if not ps1_path.exists():
            raise HTTPException(status_code=404)
        _record_cli_download(db, "install.ps1")
        return FileResponse(str(ps1_path), media_type="text/powershell", headers={"Content-Disposition": "inline"})

    @app.get("/signup", response_class=HTMLResponse)
    def signup_page(request: Request) -> HTMLResponse:
        return render_public_home(request=request, page="signup")

    @app.get("/request-baseline", response_class=HTMLResponse)
    def request_baseline_page(request: Request) -> HTMLResponse:
        return render_public_home(request=request, page="request-baseline")

    @app.get("/security-data-handling", response_class=HTMLResponse)
    def security_data_handling_page(request: Request, db: Session = Depends(get_db)) -> Response:
        user = optional_user_from_session(request, db)
        if user:
            return RedirectResponse(url="/app?page=security", status_code=302)
        return render_public_home(request=request, page="security")

    def _auth_redirect_or_public(request: Request, db: Session, *, page: str, app_page: str) -> Response:
        """Serve the public page to unauthenticated users; redirect authenticated users into the app shell."""
        user = optional_user_from_session(request, db)
        if user:
            return RedirectResponse(url=f"/app?page={app_page}", status_code=302)
        return render_public_home(request=request, page=page)

    @app.get("/help/dual-delivery-options", response_class=HTMLResponse)
    def dual_delivery_options_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="delivery-options", app_page="delivery-options")

    @app.get("/help/access-setup/aws-readonly-access", response_class=HTMLResponse)
    def aws_readonly_access_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="help-aws", app_page="help-aws")

    @app.get("/help/access-setup/azure-readonly-access", response_class=HTMLResponse)
    def azure_readonly_access_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="help-azure", app_page="help-azure")

    @app.get("/help/access-setup/credential-handling", response_class=HTMLResponse)
    def credential_handling_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="help-credential", app_page="help-credential")

    @app.get("/terms", response_class=HTMLResponse)
    def terms_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="terms", app_page="terms")

    @app.get("/privacy", response_class=HTMLResponse)
    def privacy_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="privacy", app_page="privacy")

    @app.get("/sample-executive-brief", response_class=HTMLResponse)
    def sample_executive_brief_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="sample-executive-brief", app_page="sample-executive-brief")

    @app.get("/cli", response_class=HTMLResponse)
    def cli_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="cli", app_page="download-cli")

    @app.get("/about", response_class=HTMLResponse)
    def about_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="about", app_page="about")

    @app.get("/pricing", response_class=HTMLResponse)
    def pricing_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="pricing", app_page="pricing")

    @app.get("/support-us", response_class=HTMLResponse)
    def support_us_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="support", app_page="support")

    @app.get("/contact-feedback", response_class=HTMLResponse)
    def contact_feedback_page(request: Request, db: Session = Depends(get_db)) -> Response:
        return _auth_redirect_or_public(request, db, page="contact", app_page="contact")

    @app.get("/docs/access-setup/aws-readonly-access", include_in_schema=False)
    def docs_redirect_aws() -> RedirectResponse:
        return RedirectResponse(url="/help/access-setup/aws-readonly-access", status_code=301)

    @app.get("/docs/access-setup/azure-readonly-access", include_in_schema=False)
    def docs_redirect_azure() -> RedirectResponse:
        return RedirectResponse(url="/help/access-setup/azure-readonly-access", status_code=301)

    @app.get("/docs/access-setup/credential-handling", include_in_schema=False)
    def docs_redirect_credential() -> RedirectResponse:
        return RedirectResponse(url="/help/access-setup/credential-handling", status_code=301)

    @app.post("/contact-feedback")
    def contact_feedback_submit(
        request: Request,
        full_name: str = Form(""),
        work_email: str = Form(""),
        company_name: str = Form(""),
        enquiry_type: str = Form("commercial"),
        subject: str = Form(""),
        message: str = Form(""),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)

        normalized_name = full_name.strip()
        normalized_email = work_email.strip().lower()
        normalized_company = company_name.strip()
        normalized_type = enquiry_type.strip().lower()
        normalized_subject = subject.strip()
        normalized_message = message.strip()

        if not normalized_name or not normalized_email or not normalized_subject or not normalized_message:
            return _contact_redirect(error="Name, work email, subject, and message are required.")
        if not is_valid_email(normalized_email):
            return _contact_redirect(error="Enter a valid work email.")
        if normalized_type not in {"commercial", "support", "feedback"}:
            return _contact_redirect(error="Invalid enquiry type. Refresh and submit again.")

        ops_result, requester_result = deliver_contact_feedback_notifications(
            full_name=normalized_name,
            work_email=normalized_email,
            company_name=normalized_company,
            enquiry_type=normalized_type,
            subject=normalized_subject,
            message=normalized_message,
        )
        db.add(
            ContactFeedbackRequest(
                full_name=normalized_name,
                work_email=normalized_email,
                company_name=normalized_company or None,
                enquiry_type=normalized_type,
                subject=normalized_subject,
                message=normalized_message,
                ops_notification_status=ops_result.status,
                ops_notification_error=ops_result.error,
                requester_notification_status=requester_result.status,
                requester_notification_error=requester_result.error,
                status="pending",
            )
        )
        db.commit()
        if not ops_result.ok:
            return _contact_redirect(
                error=(
                    "Your message could not be sent right now. Please retry shortly or use your existing "
                    "engagement channel."
                ),
            )

        warning = None
        if not requester_result.ok:
            warning = (
                "Your message was sent to our team, but the confirmation email back to you did not complete."
            )
        return _contact_redirect(
            message="Your message has been sent to AGAPII. We will route it through the right response channel.",
            warning=warning,
        )
