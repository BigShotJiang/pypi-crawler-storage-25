# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
import os
import smtplib
from dataclasses import dataclass
from email.message import EmailMessage

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class EmailDeliveryResult:
    ok: bool
    status: str
    error: str | None = None


def _csv_env(name: str) -> list[str]:
    raw = os.getenv(name, "")
    return [item.strip() for item in raw.split(",") if item.strip()]


def _ops_recipients() -> list[str]:
    explicit = _csv_env("HYBRISIGHT_ONBOARDING_NOTIFY_EMAILS")
    if explicit:
        return explicit
    return _csv_env("HYBRISIGHT_INTERNAL_OPS_EMAILS")


def _contact_recipients() -> list[str]:
    explicit = _csv_env("HYBRISIGHT_CONTACT_NOTIFY_EMAILS")
    if explicit:
        return explicit
    return _ops_recipients()


def _smtp_enabled() -> bool:
    return bool(os.getenv("HYBRISIGHT_SMTP_HOST", "").strip())


def _send_email(to_addrs: list[str], subject: str, body: str) -> bool:
    return _send_email_result(to_addrs, subject, body).ok


def _send_email_result(to_addrs: list[str], subject: str, body: str) -> EmailDeliveryResult:
    if not to_addrs:
        return EmailDeliveryResult(ok=False, status="skipped", error="No recipients configured")
    if not _smtp_enabled():
        logger.info("Email notification skipped (SMTP not configured): to=%s subject=%s", ",".join(to_addrs), subject)
        return EmailDeliveryResult(ok=False, status="skipped", error="SMTP not configured")

    host = os.getenv("HYBRISIGHT_SMTP_HOST", "").strip()
    port = int(os.getenv("HYBRISIGHT_SMTP_PORT", "587").strip())
    username = os.getenv("HYBRISIGHT_SMTP_USERNAME", "").strip()
    password = os.getenv("HYBRISIGHT_SMTP_PASSWORD", "")
    from_addr = os.getenv("HYBRISIGHT_SMTP_FROM", "").strip() or os.getenv("HYBRISIGHT_WEB_ADMIN_EMAIL", "").strip()
    use_tls = os.getenv("HYBRISIGHT_SMTP_TLS", "true").strip().lower() in {"1", "true", "yes", "on"}

    msg = EmailMessage()
    msg["From"] = from_addr
    msg["To"] = ", ".join(to_addrs)
    msg["Subject"] = subject
    msg.set_content(body)

    try:
        with smtplib.SMTP(host=host, port=port, timeout=10) as smtp:
            if use_tls:
                smtp.starttls()
            if username:
                smtp.login(username, password)
            smtp.send_message(msg)
        return EmailDeliveryResult(ok=True, status="sent", error=None)
    except Exception as exc:
        logger.warning("Failed to send onboarding email: %s", exc)
        return EmailDeliveryResult(ok=False, status="failed", error=str(exc))


def send_onboarding_request_notification(company_name: str, desired_slug: str, admin_email: str) -> bool:
    recipients = _ops_recipients()
    subject = f"HybriSight onboarding request: {company_name}"
    body = (
        "A new client onboarding request was submitted.\n\n"
        f"Company: {company_name}\n"
        f"Requested slug: {desired_slug}\n"
        f"Admin email: {admin_email}\n\n"
        "Review and approve/reject in Internal Ops: /internal/ops\n"
    )
    return _send_email(recipients, subject, body)


def send_onboarding_decision_notification(
    admin_email: str,
    company_name: str,
    approved: bool,
    reason: str | None = None,
) -> bool:
    if approved:
        subject = f"HybriSight onboarding approved: {company_name}"
        body = (
            "Your onboarding request has been approved.\n\n"
            f"Company: {company_name}\n"
            "You can now sign in at /login using the credentials submitted during signup.\n"
        )
    else:
        subject = f"HybriSight onboarding update: {company_name}"
        body = (
            "Your onboarding request was not approved at this time.\n\n"
            f"Company: {company_name}\n"
            f"Reason: {reason or 'No reason provided'}\n"
            "You can submit a new request at /signup.\n"
        )
    return _send_email([admin_email], subject, body)


def send_baseline_provisioned_notification(
    contact_email: str,
    company_name: str,
    login_url: str,
    api_key: str,
    invoice_url: str | None = None,
) -> bool:
    subject = f"HybriSight baseline provisioned: {company_name}"
    body = (
        "Your HybriSight Baseline Assessment is ready.\n\n"
        f"Company: {company_name}\n\n"
        "--- Your Credentials ---\n"
        f"Login: {login_url}\n"
        f"API Key: {api_key}\n\n"
        "--- Next Steps ---\n"
        "1. Install the CLI (macOS/Linux): curl -sSL https://hybrisight.agapii.org/install.sh -o install.sh && bash install.sh\n"
        "   (Windows PowerShell): irm https://hybrisight.agapii.org/install.ps1 -OutFile install.ps1; .\install.ps1\n"
        "   (Manual): pipx install hybrisight --index-url https://gitlab.agapii.org/api/v4/projects/28/packages/pypi/simple\n"
        "2. Run a scan: hybrisight scan aws --sign --output artifact.json\n"
        "3. Log in to the portal and upload your artifact\n"
    )
    if invoice_url:
        body += f"\n--- Invoice ---\nView your invoice: {invoice_url}\n"
    body += (
        "\nOnce your artifact is uploaded and processed, you will receive your "
        "executive governance brief with risk scoring, cost analysis, and a "
        "90-day stabilisation roadmap.\n\n"
        "If you have questions, reply to this email or visit the portal.\n\n"
        "Best regards,\nHybriSight Team"
    )
    return _send_email([contact_email], subject, body)


def deliver_contact_feedback_notifications(
    *,
    full_name: str,
    work_email: str,
    company_name: str,
    enquiry_type: str,
    subject: str,
    message: str,
) -> tuple[EmailDeliveryResult, EmailDeliveryResult]:
    company_display = company_name or "Not provided"
    ops_result = _send_email_result(
        _contact_recipients(),
        f"HybriSight contact enquiry: {company_display} ({enquiry_type})",
        (
            "A new contact and feedback submission was received.\n\n"
            f"Name: {full_name}\n"
            f"Work email: {work_email}\n"
            f"Company: {company_display}\n"
            f"Enquiry type: {enquiry_type}\n"
            f"Subject: {subject}\n\n"
            "Message:\n"
            f"{message}\n"
        ),
    )
    requester_result = _send_email_result(
        [work_email],
        f"HybriSight contact request received: {subject}",
        (
            "We have received your message.\n\n"
            f"Name: {full_name}\n"
            f"Company: {company_display}\n"
            f"Enquiry type: {enquiry_type}\n"
            f"Subject: {subject}\n\n"
            "Our team will respond through the most appropriate delivery or commercial channel.\n"
        ),
    )
    return ops_result, requester_result



def send_upload_summary_notification(to_email: str, upload_id: int, finding_count: int, critical_count: int) -> bool:
    if not _smtp_enabled():
        return False
    subject = f"HybriSight scan uploaded — {critical_count} critical finding{'s' if critical_count != 1 else ''}"
    body = (
        f"Your cloud scan has been processed and is ready to review.\n\n"
        f"Upload ID: {upload_id}\n"
        f"Total findings: {finding_count}\n"
        f"Critical findings: {critical_count}\n\n"
        "Log in to the HybriSight portal to view your report and remediation board.\n"
    )
    return _send_email([to_email], subject, body)


def send_ticket_blocked_notification(to_email: str, ticket_title: str, blocked_reason: str) -> bool:
    if not _smtp_enabled():
        return False
    subject = f"HybriSight ticket blocked: {ticket_title}"
    body = (
        f"A remediation ticket has been marked as blocked and requires attention.\n\n"
        f"Ticket: {ticket_title}\n"
        f"Reason: {blocked_reason}\n\n"
        "Log in to the HybriSight portal to review and unblock this ticket.\n"
    )
    return _send_email([to_email], subject, body)
