# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from fastapi import Depends, Form, HTTPException, Request
from sqlalchemy.orm import Session

from hybrisight.web.models import RemediationPlaybook, TenantPlaybookOverride, User


def register_remediation_playbook_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    validate_csrf: Callable[[Request, str | None], None],
    parse_json_list: Callable[[str | None], list[str]],
    json_list: Callable[[list[str]], str],
) -> None:
    @app.get("/api/v1/remediation-playbooks")
    def list_remediation_playbooks(
        request: Request,
        provider: str | None = None,
        finding_id: str | None = None,
        theme: str | None = None,
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        enforce_internal_ops_access(request, user)
        query = db.query(RemediationPlaybook)
        if provider:
            query = query.filter(RemediationPlaybook.provider == provider.strip().lower())
        if finding_id:
            query = query.filter(RemediationPlaybook.finding_id == finding_id.strip())
        if theme:
            query = query.filter(RemediationPlaybook.theme == theme.strip())
        rows = query.order_by(RemediationPlaybook.updated_at.desc()).limit(500).all()
        return {
            "items": [
                {
                    "id": row.id,
                    "finding_id": row.finding_id,
                    "provider": row.provider,
                    "theme": row.theme,
                    "version": row.version,
                    "objective": row.objective,
                    "practical_steps": parse_json_list(row.practical_steps_json),
                    "validation_checks": parse_json_list(row.validation_checks_json),
                    "rollback_steps": parse_json_list(row.rollback_steps_json),
                    "required_evidence": parse_json_list(row.required_evidence_json),
                    "owner_role": row.owner_role,
                    "estimated_effort": row.estimated_effort,
                    "updated_at": row.updated_at.isoformat() if row.updated_at else row.created_at.isoformat(),
                }
                for row in rows
            ]
        }

    @app.post("/api/v1/remediation-playbooks")
    def create_remediation_playbook(
        request: Request,
        finding_id: str = Form(...),
        provider: str = Form(...),
        theme: str = Form(...),
        objective: str = Form(...),
        practical_steps_json: str = Form("[]"),
        validation_checks_json: str = Form("[]"),
        rollback_steps_json: str = Form("[]"),
        required_evidence_json: str = Form("[]"),
        owner_role: str = Form("platform_engineer"),
        estimated_effort: str = Form("medium"),
        version: str = Form("1.0"),
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        enforce_internal_ops_access(request, user)
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        row = RemediationPlaybook(
            finding_id=finding_id.strip(),
            provider=provider.strip().lower(),
            theme=theme.strip(),
            version=version.strip() or "1.0",
            objective=objective.strip(),
            practical_steps_json=json_list(parse_json_list(practical_steps_json)),
            validation_checks_json=json_list(parse_json_list(validation_checks_json)),
            rollback_steps_json=json_list(parse_json_list(rollback_steps_json)),
            required_evidence_json=json_list(parse_json_list(required_evidence_json)),
            owner_role=owner_role.strip() or "platform_engineer",
            estimated_effort=estimated_effort.strip() or "medium",
            created_by_user_id=user.id,
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return {"id": row.id}

    @app.post("/api/v1/remediation-playbooks/{playbook_id}/override")
    def upsert_tenant_playbook_override(
        playbook_id: int,
        request: Request,
        practical_steps_json: str | None = Form(None),
        validation_checks_json: str | None = Form(None),
        rollback_steps_json: str | None = Form(None),
        required_evidence_json: str | None = Form(None),
        tenant_notes: str | None = Form(None),
        csrf_token: str | None = Form(None),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> dict:
        validate_csrf(request, csrf_token or request.headers.get("X-CSRF-Token"))
        playbook = db.query(RemediationPlaybook).filter(RemediationPlaybook.id == playbook_id).first()
        if playbook is None:
            raise HTTPException(status_code=404, detail="Playbook not found")
        row = (
            db.query(TenantPlaybookOverride)
            .filter(TenantPlaybookOverride.tenant_id == user.tenant_id, TenantPlaybookOverride.playbook_id == playbook_id)
            .first()
        )
        if row is None:
            row = TenantPlaybookOverride(
                tenant_id=user.tenant_id,
                playbook_id=playbook_id,
                created_by_user_id=user.id,
            )
            db.add(row)
        row.practical_steps_json = json_list(parse_json_list(practical_steps_json)) if practical_steps_json is not None else row.practical_steps_json
        row.validation_checks_json = json_list(parse_json_list(validation_checks_json)) if validation_checks_json is not None else row.validation_checks_json
        row.rollback_steps_json = json_list(parse_json_list(rollback_steps_json)) if rollback_steps_json is not None else row.rollback_steps_json
        row.required_evidence_json = (
            json_list(parse_json_list(required_evidence_json)) if required_evidence_json is not None else row.required_evidence_json
        )
        row.tenant_notes = tenant_notes.strip() if tenant_notes is not None else row.tenant_notes
        db.commit()
        db.refresh(row)
        return {"id": row.id}
