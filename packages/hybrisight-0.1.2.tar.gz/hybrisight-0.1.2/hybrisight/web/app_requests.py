# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import hashlib
import logging
import json
import os
import time
import uuid
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import Response
from sqlalchemy.orm import Session

from hybrisight.web.logging_config import clear_request_context, set_request_context
from hybrisight.web.models import AuditLog, User
from hybrisight.web.security import redact_sensitive_data
from hybrisight.web.service_constants import RateLimitExceeded

logger = logging.getLogger(__name__)


def _skip_rate_limit(request: Request) -> bool:
    path = request.url.path
    if path.startswith("/static") or path.startswith("/ui-static"):
        return True
    if request.method == "GET" and path.startswith("/dashboard/") and "/export/" in path:
        return True
    return False


def get_client_ip(request: Request) -> str | None:
    trust_proxy_headers = os.getenv("HYBRISIGHT_TRUST_PROXY_HEADERS", "").strip().lower() in {"1", "true", "yes", "on"}
    forwarded = request.headers.get("x-forwarded-for")
    if trust_proxy_headers and forwarded:
        return forwarded.split(",")[0].strip()
    if request.client:
        return request.client.host
    return None


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def frontend_asset_bundle_info(frontend_dist_dir: Any, *, entry_name: str = "index.html") -> dict[str, Any]:
    manifest_path = frontend_dist_dir / ".vite" / "manifest.json"
    info: dict[str, Any] = {
        "entry_name": entry_name,
        "dist_dir": str(frontend_dist_dir),
        "js_file": None,
        "js_url": None,
        "css_files": [],
        "css_urls": [],
    }
    if not manifest_path.exists():
        return info
    try:
        manifest = json.loads(manifest_path.read_text())
    except Exception:
        return info
    entry = manifest.get(entry_name)
    if not isinstance(entry, dict) and entry_name != "index.html":
        entry = manifest.get("index.html")
    if not isinstance(entry, dict):
        entry = manifest.get("src/main.tsx")
    if not isinstance(entry, dict):
        return info
    js_file = entry.get("file")
    css_files: list[str] = []
    seen_entries: set[str] = set()
    seen_css: set[str] = set()

    def collect_css(entry_key: str, entry_data: dict[str, Any]) -> None:
        if entry_key in seen_entries:
            return
        seen_entries.add(entry_key)
        for path in entry_data.get("css", []) or []:
            if isinstance(path, str) and path not in seen_css:
                seen_css.add(path)
                css_files.append(path)
        for import_key in entry_data.get("imports", []) or []:
            imported = manifest.get(import_key)
            if isinstance(imported, dict):
                collect_css(import_key, imported)

    collect_css(entry_name if isinstance(manifest.get(entry_name), dict) else str(entry.get("src") or entry_name), entry)
    info["js_file"] = js_file
    info["js_url"] = f"/ui-static/{js_file}" if js_file else None
    info["css_files"] = css_files
    info["css_urls"] = [f"/ui-static/{path}" for path in css_files]
    return info


def frontend_asset_urls(frontend_dist_dir: Any, *, entry_name: str = "index.html") -> tuple[list[str], str | None, dict[str, Any]]:
    info = frontend_asset_bundle_info(frontend_dist_dir, entry_name=entry_name)
    return list(info["css_urls"]), info["js_url"], info


def log_route_registry_check(app: FastAPI, *, internal_ops_root_tenant_slug: str, internal_ops_allowlist_count: int, internal_ops_key_enforced: bool) -> None:
    route_paths = {route.path for route in app.routes}
    required_account_routes = {"/api/v1/account/users", "/api/v1/account/users/{target_user_id}/role", "/api/v1/account/users/{target_user_id}/delete"}
    required_internal_storage_routes = {"/api/v1/internal/storage", "/api/v1/internal/storage/policy", "/api/v1/internal/storage/policy/run", "/api/v1/internal/storage/purge"}
    missing_account = sorted(required_account_routes - route_paths)
    missing_internal_storage = sorted(required_internal_storage_routes - route_paths)
    logger.info("route_registry_check", extra={"account_user_routes_ok": len(missing_account) == 0, "account_user_routes_missing": missing_account, "internal_storage_routes_ok": len(missing_internal_storage) == 0, "internal_storage_routes_missing": missing_internal_storage, "internal_ops_root_tenant_slug": internal_ops_root_tenant_slug, "internal_ops_allowlist_count": internal_ops_allowlist_count, "internal_ops_key_enforced": internal_ops_key_enforced})


def log_event(db: Session, request: Request, event_type: str, user: User | None = None, metadata: dict[str, Any] | None = None) -> None:
    sanitized = redact_sensitive_data(metadata or {})
    request_id = getattr(getattr(request, "state", None), "request_id", None)
    if request_id and "request_id" not in sanitized:
        sanitized["request_id"] = request_id
    row = AuditLog(
        tenant_id=user.tenant_id if user else None,
        user_id=user.id if user else None,
        event_type=event_type,
        path=request.url.path,
        method=request.method,
        ip_address=get_client_ip(request),
        metadata_json=json.dumps(sanitized, default=str),
    )
    db.add(row)
    db.commit()


def build_audit_middleware(*, SessionLocal: Any, enforce_rate_limit: Any) -> Any:
    async def audit_middleware(request: Request, call_next):
        request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
        request.state.request_id = request_id
        client_ip = get_client_ip(request)
        started = time.perf_counter()
        set_request_context(request_id=request_id, method=request.method, path=request.url.path, client_ip=client_ip)
        try:
            if not _skip_rate_limit(request):
                enforce_rate_limit(client_ip or "unknown")
        except RateLimitExceeded:
            duration_ms = round((time.perf_counter() - started) * 1000, 2)
            logger.warning("request_rate_limited", extra={"status_code": 429, "duration_ms": duration_ms})
            clear_request_context()
            return Response(content="Too Many Requests", status_code=429, headers={"Retry-After": "60", "X-Request-ID": request_id})

        response: Response | None = None
        try:
            response = await call_next(request)
            response.headers["X-Request-ID"] = request_id
            if request.url.path.startswith("/static"):
                return response
            try:
                with SessionLocal() as db:
                    user = None
                    user_id = request.session.get("user_id") if hasattr(request, "session") else None
                    if user_id:
                        user = db.query(User).filter(User.id == user_id).first()
                    if request.method in {"POST", "PUT", "DELETE"} or request.url.path in {"/", "/login"}:
                        log_event(db, request, event_type="http_request", user=user, metadata={"status_code": response.status_code, "query_params": dict(request.query_params), "headers": dict(request.headers)})
            except Exception as exc:
                logger.warning("audit_middleware_db_log_failed", extra={"error": str(exc)})
            return response
        finally:
            status_code = response.status_code if response else 500
            duration_ms = round((time.perf_counter() - started) * 1000, 2)
            logger.info("request_completed", extra={"status_code": status_code, "duration_ms": duration_ms})
            clear_request_context()

    return audit_middleware
