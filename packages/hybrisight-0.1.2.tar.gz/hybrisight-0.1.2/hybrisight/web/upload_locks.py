# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import threading
from contextlib import contextmanager
from collections.abc import Iterator

from sqlalchemy.orm import Session

from hybrisight.web.models import ScanUpload

_LOCKS: dict[int, threading.Lock] = {}
_LOCKS_GUARD = threading.Lock()


@contextmanager
def tenant_upload_lock(tenant_id: int) -> Iterator[None]:
    with _LOCKS_GUARD:
        lock = _LOCKS.setdefault(tenant_id, threading.Lock())
    lock.acquire()
    try:
        yield
    finally:
        lock.release()


def next_tenant_upload_seq(db: Session, tenant_id: int) -> int:
    current_max = (
        db.query(ScanUpload.tenant_upload_seq)
        .filter(ScanUpload.tenant_id == tenant_id)
        .order_by(ScanUpload.tenant_upload_seq.desc(), ScanUpload.id.desc())
        .limit(1)
        .scalar()
    )
    return int(current_max or 0) + 1


def new_upload_execution_state(db: Session, tenant_id: int) -> str:
    has_active = (
        db.query(ScanUpload.id)
        .filter(ScanUpload.tenant_id == tenant_id, ScanUpload.execution_state == "active")
        .first()
        is not None
    )
    return "hold" if has_active else "active"
