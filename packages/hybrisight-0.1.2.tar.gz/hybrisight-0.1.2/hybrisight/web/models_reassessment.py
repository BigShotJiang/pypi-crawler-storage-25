# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from hybrisight.web.db import Base


class AssessmentScope(Base):
    __tablename__ = "assessment_scopes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    provider: Mapped[str] = mapped_column(String(32), index=True)
    label: Mapped[str] = mapped_column(String(255))
    fingerprint: Mapped[str] = mapped_column(String(255), index=True)
    scope_metadata_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        index=True,
    )


class ReassessmentSeries(Base):
    __tablename__ = "reassessment_series"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    assessment_scope_id: Mapped[int] = mapped_column(ForeignKey("assessment_scopes.id"), index=True)
    baseline_upload_id: Mapped[int | None] = mapped_column(ForeignKey("scan_uploads.id"), index=True, default=None)
    label: Mapped[str] = mapped_column(String(255))
    series_key: Mapped[str] = mapped_column(String(255), index=True)
    cadence: Mapped[str] = mapped_column(String(64), default="ad_hoc")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        index=True,
    )


class ExecutionTicketEvent(Base):
    __tablename__ = "execution_ticket_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    tenant_id: Mapped[int] = mapped_column(ForeignKey("tenants.id"), index=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("execution_tickets.id"), index=True)
    upload_id: Mapped[int | None] = mapped_column(ForeignKey("scan_uploads.id"), index=True, default=None)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True, default=None)
    event_type: Mapped[str] = mapped_column(String(64), index=True)
    previous_status: Mapped[str | None] = mapped_column(String(32), default=None)
    next_status: Mapped[str | None] = mapped_column(String(32), default=None)
    previous_continuity_status: Mapped[str | None] = mapped_column(String(32), default=None)
    next_continuity_status: Mapped[str | None] = mapped_column(String(32), default=None)
    details_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(UTC), index=True)
