# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Callable
from urllib.parse import quote_plus

from fastapi import Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from hybrisight.web.models import BaselineRequest, ClientOnboardingRequest, Tenant, User
from hybrisight.web.notifications import send_onboarding_decision_notification


def register_internal_ops_page_request_routes(
    app: Any,
    *,
    get_db: Callable[..., Any],
    require_role: Callable[[str], Any],
    enforce_internal_ops_access: Callable[[Request, User], None],
    validate_csrf: Callable[[Request, str | None], None],
    sanitize_onboarding_reason: Callable[[str], str],
    log_event: Callable[..., None],
) -> None:
    @app.post("/internal/ops/onboarding/{request_id}/approve")
    def internal_ops_approve_onboarding_request(
        request: Request,
        request_id: int,
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        onboarding = db.query(ClientOnboardingRequest).filter(ClientOnboardingRequest.id == request_id).first()
        if onboarding is None or onboarding.status != "pending":
            return RedirectResponse(url="/internal/ops?error=Onboarding+request+not+found+or+already+processed", status_code=302)
        if db.query(Tenant).filter(Tenant.slug == onboarding.desired_slug).first() is not None:
            return RedirectResponse(url="/internal/ops?error=Tenant+slug+already+exists", status_code=302)
        if db.query(User).filter(User.email == onboarding.admin_email).first() is not None:
            return RedirectResponse(url="/internal/ops?error=Admin+email+already+exists", status_code=302)

        tenant = Tenant(name=onboarding.company_name, slug=onboarding.desired_slug)
        db.add(tenant)
        db.flush()
        admin_user = User(email=onboarding.admin_email, password_hash=onboarding.admin_password_hash, role="tenant_admin", tenant_id=tenant.id)
        db.add(admin_user)
        onboarding.status = "approved"
        onboarding.reviewed_by_user_id = user.id
        onboarding.reviewed_at = datetime.now(UTC)
        onboarding.rejection_reason = None
        db.commit()

        log_event(db, request, event_type="onboarding_approved", user=user, metadata={"request_id": onboarding.id, "tenant_id": tenant.id, "tenant_slug": tenant.slug, "admin_email": admin_user.email})
        send_onboarding_decision_notification(admin_user.email, onboarding.company_name, approved=True)
        return RedirectResponse(url=f"/internal/ops?message=Approved+onboarding+for+{quote_plus(onboarding.company_name)}", status_code=302)

    @app.post("/internal/ops/onboarding/{request_id}/reject")
    def internal_ops_reject_onboarding_request(
        request: Request,
        request_id: int,
        reason: str = Form(""),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        onboarding = db.query(ClientOnboardingRequest).filter(ClientOnboardingRequest.id == request_id).first()
        if onboarding is None or onboarding.status != "pending":
            return RedirectResponse(url="/internal/ops?error=Onboarding+request+not+found+or+already+processed", status_code=302)

        onboarding.status = "rejected"
        onboarding.reviewed_by_user_id = user.id
        onboarding.reviewed_at = datetime.now(UTC)
        onboarding.rejection_reason = sanitize_onboarding_reason(reason)
        db.commit()
        log_event(db, request, event_type="onboarding_rejected", user=user, metadata={"request_id": onboarding.id, "company_name": onboarding.company_name, "reason": onboarding.rejection_reason})
        send_onboarding_decision_notification(onboarding.admin_email, onboarding.company_name, approved=False, reason=onboarding.rejection_reason)
        return RedirectResponse(url=f"/internal/ops?message=Rejected+onboarding+for+{quote_plus(onboarding.company_name)}", status_code=302)

    @app.post("/internal/ops/baseline/{request_id}/reject")
    def internal_ops_reject_legacy_baseline(
        request: Request,
        request_id: int,
        reason: str = Form(""),
        csrf_token: str = Form(...),
        db: Session = Depends(get_db),
        user: User = Depends(require_role("tenant_admin")),
    ) -> RedirectResponse:
        validate_csrf(request, csrf_token)
        enforce_internal_ops_access(request, user)
        baseline = db.query(BaselineRequest).filter(BaselineRequest.id == request_id).first()
        if baseline is None:
            return RedirectResponse(url="/internal/ops?error=Baseline+request+not+found", status_code=302)
        baseline.status = "rejected"
        baseline.reviewed_by_user_id = user.id
        baseline.reviewed_at = datetime.now(UTC)
        baseline.rejection_reason = sanitize_onboarding_reason(reason)
        db.commit()
        log_event(db, request, event_type="baseline_rejected_by_operator", user=user, metadata={"request_id": baseline.id, "company_name": baseline.company_name})
        return RedirectResponse(url=f"/internal/ops?message=Rejected+baseline+for+{quote_plus(baseline.company_name)}", status_code=302)
