# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from fastapi import HTTPException

from hybrisight.web.models_engagements import Engagement

ENGAGEMENT_DELIVERY_MODES = ("consultant_led", "client_run")
ENGAGEMENT_ACCESS_STATES = ("not_provisioned", "provisioned")


def can_release_report(item: Engagement) -> bool:
    if not item.payment_required_before_release:
        return True
    return item.invoice_status == "paid"


def enforce_release_gate(item: Engagement) -> None:
    if not can_release_report(item):
        raise HTTPException(
            status_code=400,
            detail="Report release is blocked until payment is marked paid or the payment gate is disabled",
        )
