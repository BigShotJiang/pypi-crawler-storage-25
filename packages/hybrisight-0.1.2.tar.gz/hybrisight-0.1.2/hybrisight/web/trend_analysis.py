# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any, Callable

from sqlalchemy.orm import Session

from hybrisight.engine import apply_scoring
from hybrisight.web.reassessment_series import continuity_context_payload, ensure_upload_reassessment_context


def _estimated_waste_from_result(result: Any) -> float:
    return float(round(sum((f.estimated_annual_cost_impact_gbp or 0.0) for f in result.findings), 2))


def _finding_key(finding: Any) -> tuple[str, str]:
    return str(finding.id), str(finding.resource_id)


def _severity_counts(result: Any) -> dict[str, int]:
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for finding in result.findings:
        severity = str(finding.severity.value if hasattr(finding.severity, "value") else finding.severity).lower()
        if severity in counts:
            counts[severity] += 1
    return counts


def _snapshot_metrics(result: Any) -> dict[str, Any]:
    scored = apply_scoring(result)
    return {
        "posture_score": round(float(scored.posture_score or 0.0), 1),
        "risk_index": round(float(scored.risk_index or 0.0), 1),
        "confidence_adjusted_score": round(float(scored.confidence_adjusted_score or 0.0), 1),
        "estimated_waste": round(_estimated_waste_from_result(scored), 2),
        "severity_counts": _severity_counts(scored),
        "finding_keys": {_finding_key(finding) for finding in scored.findings},
    }


def build_trend_summary(
    db: Session,
    tenant_id: int,
    upload: Any,
    current_result: Any,
    *,
    scan_upload_model: Any,
    validate_scan_payload: Callable[[str], Any],
) -> dict[str, Any]:
    ensure_upload_reassessment_context(db, upload)
    continuity = continuity_context_payload(db, upload)
    scope_id = getattr(upload, "assessment_scope_id", None)
    series_id = getattr(upload, "reassessment_series_id", None)

    query = db.query(scan_upload_model).filter(scan_upload_model.tenant_id == tenant_id, scan_upload_model.id <= upload.id)
    if scope_id is not None:
        query = query.filter(scan_upload_model.assessment_scope_id == scope_id)
    if series_id is not None:
        query = query.filter(scan_upload_model.reassessment_series_id == series_id)
    series_rows = query.order_by(scan_upload_model.id.asc()).all()
    upload_count = len(series_rows)
    if not series_rows:
        return {
            "has_prior_snapshot": False,
            "message": "No prior snapshot available for trend comparison.",
            "latest_upload_id": upload.id,
            "baseline_upload_id": upload.id,
            "upload_count": 1,
            "series_position": 1,
            "continuity_context": continuity,
        }

    current_index = next((idx for idx, row in enumerate(series_rows) if row.id == upload.id), len(series_rows) - 1)
    baseline_upload = series_rows[0]
    previous_upload = series_rows[current_index - 1] if current_index > 0 else None

    if previous_upload is None:
        return {
            "has_prior_snapshot": False,
            "message": "No prior snapshot available for trend comparison inside this reassessment scope.",
            "latest_upload_id": upload.id,
            "baseline_upload_id": baseline_upload.id,
            "upload_count": upload_count,
            "series_position": current_index + 1,
            "continuity_context": continuity,
        }

    try:
        previous_result = validate_scan_payload(previous_upload.raw_json)
    except Exception:
        return {
            "has_prior_snapshot": False,
            "message": "Prior snapshot could not be parsed for trend comparison.",
            "latest_upload_id": upload.id,
            "prior_upload_id": previous_upload.id,
            "baseline_upload_id": baseline_upload.id,
            "upload_count": upload_count,
            "series_position": current_index + 1,
            "continuity_context": continuity,
        }

    baseline_result = previous_result
    baseline_generated_at_utc = previous_upload.generated_at_utc
    if baseline_upload is not None:
        try:
            baseline_result = validate_scan_payload(baseline_upload.raw_json)
            baseline_generated_at_utc = baseline_upload.generated_at_utc
        except Exception:
            pass

    latest_metrics = _snapshot_metrics(current_result)
    previous_metrics = _snapshot_metrics(previous_result)
    baseline_metrics = _snapshot_metrics(baseline_result)

    latest_finding_keys = latest_metrics["finding_keys"]
    previous_finding_keys = previous_metrics["finding_keys"]
    findings_added = sorted(f"{item[0]}::{item[1]}" for item in (latest_finding_keys - previous_finding_keys))
    findings_resolved = sorted(f"{item[0]}::{item[1]}" for item in (previous_finding_keys - latest_finding_keys))
    findings_persistent = latest_finding_keys & previous_finding_keys

    return {
        "has_prior_snapshot": True,
        "latest_upload_id": upload.id,
        "baseline_upload_id": baseline_upload.id,
        "prior_upload_id": previous_upload.id,
        "upload_count": upload_count,
        "series_position": current_index + 1,
        "latest_generated_at_utc": upload.generated_at_utc,
        "baseline_generated_at_utc": baseline_generated_at_utc,
        "prior_generated_at_utc": previous_upload.generated_at_utc,
        "latest_posture_score": latest_metrics["posture_score"],
        "prior_posture_score": previous_metrics["posture_score"],
        "baseline_posture_score": baseline_metrics["posture_score"],
        "posture_score_delta": round(latest_metrics["posture_score"] - previous_metrics["posture_score"], 1),
        "posture_score_delta_vs_baseline": round(latest_metrics["posture_score"] - baseline_metrics["posture_score"], 1),
        "latest_risk_index": latest_metrics["risk_index"],
        "prior_risk_index": previous_metrics["risk_index"],
        "baseline_risk_index": baseline_metrics["risk_index"],
        "risk_index_delta": round(latest_metrics["risk_index"] - previous_metrics["risk_index"], 1),
        "risk_index_delta_vs_baseline": round(latest_metrics["risk_index"] - baseline_metrics["risk_index"], 1),
        "latest_confidence_adjusted_score": latest_metrics["confidence_adjusted_score"],
        "prior_confidence_adjusted_score": previous_metrics["confidence_adjusted_score"],
        "baseline_confidence_adjusted_score": baseline_metrics["confidence_adjusted_score"],
        "confidence_adjusted_score_delta": round(latest_metrics["confidence_adjusted_score"] - previous_metrics["confidence_adjusted_score"], 1),
        "confidence_adjusted_score_delta_vs_baseline": round(latest_metrics["confidence_adjusted_score"] - baseline_metrics["confidence_adjusted_score"], 1),
        "latest_estimated_waste": latest_metrics["estimated_waste"],
        "prior_estimated_waste": previous_metrics["estimated_waste"],
        "baseline_estimated_waste": baseline_metrics["estimated_waste"],
        "estimated_waste_delta": round(latest_metrics["estimated_waste"] - previous_metrics["estimated_waste"], 2),
        "estimated_waste_delta_vs_baseline": round(latest_metrics["estimated_waste"] - baseline_metrics["estimated_waste"], 2),
        "latest_critical_count": latest_metrics["severity_counts"]["critical"],
        "prior_critical_count": previous_metrics["severity_counts"]["critical"],
        "baseline_critical_count": baseline_metrics["severity_counts"]["critical"],
        "critical_count_delta": latest_metrics["severity_counts"]["critical"] - previous_metrics["severity_counts"]["critical"],
        "critical_count_delta_vs_baseline": latest_metrics["severity_counts"]["critical"] - baseline_metrics["severity_counts"]["critical"],
        "latest_high_count": latest_metrics["severity_counts"]["high"],
        "prior_high_count": previous_metrics["severity_counts"]["high"],
        "baseline_high_count": baseline_metrics["severity_counts"]["high"],
        "high_count_delta": latest_metrics["severity_counts"]["high"] - previous_metrics["severity_counts"]["high"],
        "high_count_delta_vs_baseline": latest_metrics["severity_counts"]["high"] - baseline_metrics["severity_counts"]["high"],
        "findings_added_count": len(findings_added),
        "findings_resolved_count": len(findings_resolved),
        "findings_persistent_count": len(findings_persistent),
        "findings_added_top": findings_added[:10],
        "findings_resolved_top": findings_resolved[:10],
        "continuity_context": continuity,
    }
