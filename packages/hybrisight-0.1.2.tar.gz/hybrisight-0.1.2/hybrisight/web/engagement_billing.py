# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
from decimal import Decimal
from typing import Any

import httpx


def stripe_enabled() -> bool:
    return bool((os.getenv("HYBRISIGHT_STRIPE_SECRET_KEY") or "").strip())


def stripe_api_base_url() -> str:
    return (os.getenv("HYBRISIGHT_STRIPE_API_BASE_URL") or "https://api.stripe.com").rstrip("/")


def create_stripe_invoice(
    *,
    title: str,
    client_name: str,
    contact_email: str,
    amount: Decimal,
    currency: str,
    engagement_id: int,
    tenant_id: int,
    days_until_due: int,
) -> dict[str, Any]:
    secret_key = (os.getenv("HYBRISIGHT_STRIPE_SECRET_KEY") or "").strip()
    if not secret_key:
        raise RuntimeError("Stripe billing is not configured")

    base_url = stripe_api_base_url()
    auth = (secret_key, "")
    metadata = {
        "engagement_id": str(engagement_id),
        "tenant_id": str(tenant_id),
        "title": title,
    }
    amount_minor = int((amount * 100).quantize(Decimal("1")))
    description = f"HybriSight {title}"

    with httpx.Client(base_url=base_url, auth=auth, timeout=20.0) as client:
        customer = client.post(
            "/v1/customers",
            data={"email": contact_email, "name": client_name, "metadata[engagement_id]": str(engagement_id)},
        )
        customer.raise_for_status()
        customer_payload = customer.json()
        customer_id = str(customer_payload.get("id", "")).strip()
        if not customer_id:
            raise RuntimeError("Stripe customer creation failed")

        invoice_item = client.post(
            "/v1/invoiceitems",
            data={
                "customer": customer_id,
                "amount": str(amount_minor),
                "currency": currency.lower(),
                "description": description,
                **{f"metadata[{key}]": value for key, value in metadata.items()},
            },
        )
        invoice_item.raise_for_status()

        invoice = client.post(
            "/v1/invoices",
            data={
                "customer": customer_id,
                "collection_method": "send_invoice",
                "days_until_due": str(max(1, min(days_until_due, 90))),
                "auto_advance": "false",
                "description": description,
                **{f"metadata[{key}]": value for key, value in metadata.items()},
            },
        )
        invoice.raise_for_status()
        invoice_payload = invoice.json()
        invoice_id = str(invoice_payload.get("id", "")).strip()
        if not invoice_id:
            raise RuntimeError("Stripe invoice creation failed")

        finalized = client.post(f"/v1/invoices/{invoice_id}/finalize")
        finalized.raise_for_status()
        finalized_payload = finalized.json()

    return {
        "customer_id": customer_id,
        "invoice_id": finalized_payload.get("id") or invoice_id,
        "invoice_url": finalized_payload.get("hosted_invoice_url") or finalized_payload.get("invoice_pdf") or "",
        "invoice_status": finalized_payload.get("status") or "draft",
    }
