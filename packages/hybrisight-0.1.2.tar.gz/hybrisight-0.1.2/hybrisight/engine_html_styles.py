# SPDX-License-Identifier: Apache-2.0
"""CSS styles for the HybriSight HTML report (Open Governance Brief)."""
from __future__ import annotations

REPORT_CSS = """
    :root {
      --ink: #0f172a; --muted: #475569; --line: #e2e8f0; --accent: #1d4ed8;
      --accent-light: #eff6ff; --accent-bright: #2563eb; --panel: #ffffff; --bg: #f8fafc;
      --critical: #b91c1c; --high: #c2410c; --medium: #92400e;
      --low: #166534; --info: #1d4ed8;
    }
    * { box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      margin: 0; padding: 0; color: var(--ink); background: var(--bg); font-size: 13px; line-height: 1.55; }
    .page { max-width: 960px; margin: 0 auto; padding: 40px 32px; }
    .cover { background: linear-gradient(135deg, #1e40af 0%, #2563eb 50%, #3b82f6 100%); color: #fff;
      padding: 48px 32px 36px; margin: -40px -32px 40px; border-radius: 0 0 16px 16px; }
    .cover-logo { font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; opacity: 0.75; margin-bottom: 24px; }
    .cover h1 { font-size: 28px; font-weight: 700; margin: 0 0 6px; letter-spacing: -0.02em; }
    .cover-subtitle { font-size: 14px; opacity: 0.85; margin: 0 0 28px; }
    .cover-meta { display: flex; flex-wrap: wrap; gap: 24px; font-size: 12px; opacity: 0.85;
      border-top: 1px solid rgba(255,255,255,0.2); padding-top: 16px; }
    .cover-meta span strong { display: block; font-size: 10px; letter-spacing: 0.1em;
      text-transform: uppercase; opacity: 0.7; margin-bottom: 2px; }
    .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; margin-bottom: 32px; }
    .kpi-card { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 14px 16px; }
    .kpi-label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--muted); margin-bottom: 6px; font-weight: 600; }
    .kpi-value { font-size: 22px; font-weight: 700; color: var(--accent); line-height: 1; }
    .kpi-note { font-size: 11px; color: var(--muted); margin-top: 4px; }
    h2 { font-size: 15px; font-weight: 700; color: var(--accent); border-left: 3px solid var(--accent);
      padding-left: 10px; margin: 32px 0 14px; }
    h3 { font-size: 13px; font-weight: 700; margin: 0 0 8px; }
    .translation-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 8px; }
    .t-card { background: var(--panel); border: 1px solid var(--line); border-radius: 8px; padding: 14px; }
    .t-card h3 { color: var(--muted); font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin-bottom: 8px; }
    .t-card p { margin: 0; font-size: 12.5px; line-height: 1.5; }
    .actions-list { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 16px 20px; }
    .actions-list ul { margin: 0; padding-left: 20px; }
    .actions-list li { margin-bottom: 6px; font-size: 12.5px; }
    .drivers-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 12px; }
    .driver-card { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 14px; }
    .driver-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; margin-bottom: 8px; }
    .driver-title { font-weight: 600; font-size: 12.5px; line-height: 1.3; }
    .driver-impact { font-size: 12px; color: var(--muted); margin: 0 0 6px; }
    .driver-meta { font-size: 11px; color: var(--muted); margin: 0; }
    .badge { display: inline-block; padding: 2px 7px; border-radius: 999px; font-size: 10px; font-weight: 700; white-space: nowrap; }
    .badge-critical { background: #fee2e2; color: var(--critical); }
    .badge-high { background: #ffedd5; color: var(--high); }
    .badge-medium { background: #fef3c7; color: var(--medium); }
    .badge-low { background: #dcfce7; color: var(--low); }
    .badge-info { background: #dbeafe; color: var(--info); }
    table { width: 100%; border-collapse: collapse; background: var(--panel); border-radius: 10px;
      overflow: hidden; border: 1px solid var(--line); margin-bottom: 8px; }
    th, td { padding: 9px 12px; text-align: left; border-bottom: 1px solid var(--line); font-size: 12px; }
    th { background: #f1f5f9; font-size: 10px; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; color: var(--muted); }
    .sev-critical { color: var(--critical); font-weight: 700; }
    .sev-high { color: var(--high); font-weight: 700; }
    .sev-medium { color: var(--medium); font-weight: 600; }
    .compliance-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 12px; margin-bottom: 8px; }
    .compliance-card { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 14px; }
    .compliance-card-header { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
    .compliance-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
    .compliance-fw-name { font-weight: 600; font-size: 12px; line-height: 1.2; }
    .compliance-version { font-size: 10px; color: var(--muted); margin-bottom: 6px; }
    .compliance-pct-row { display: flex; align-items: baseline; gap: 6px; margin-bottom: 4px; }
    .compliance-pct { font-size: 24px; font-weight: 700; line-height: 1; }
    .compliance-pct-label { font-size: 11px; color: var(--muted); }
    .compliance-meta { font-size: 11px; color: var(--muted); }
    .roadmap-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
    .roadmap-phase { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 16px; }
    .phase-label { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--accent); margin-bottom: 6px; }
    .phase-goal { font-size: 11.5px; color: var(--muted); margin: 0 0 10px; }
    .phase-items { padding-left: 16px; margin: 0; }
    .phase-items li { font-size: 12px; margin-bottom: 4px; }
    .trajectory-row { display: flex; gap: 12px; margin-bottom: 12px; }
    .traj-point { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 12px 16px; flex: 1; text-align: center; }
    .traj-label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--muted); margin-bottom: 4px; }
    .traj-score { font-size: 22px; font-weight: 700; color: var(--accent); line-height: 1; }
    .traj-unit { font-size: 13px; font-weight: 400; color: var(--muted); }
    .traj-risk { font-size: 11px; color: var(--muted); margin-top: 4px; }
    .narrative { background: var(--accent-light); border-left: 3px solid var(--accent); border-radius: 0 8px 8px 0; padding: 12px 14px; font-size: 12.5px; margin-bottom: 10px; }
    .disclaimer { font-size: 11px; color: var(--muted); font-style: italic; }
    .appendix { font-size: 11.5px; color: var(--muted); }
    .appendix table { font-size: 11px; }
    .cta-footer { margin-top: 48px; background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
      color: #fff; border-radius: 12px; padding: 24px 28px; display: flex;
      justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; }
    .cta-footer h3 { margin: 0 0 4px; font-size: 15px; }
    .cta-footer p { margin: 0; font-size: 12px; opacity: 0.85; }
    .cta-contact { text-align: right; font-size: 12px; opacity: 0.9; }
    .cta-contact strong { display: block; font-size: 13px; margin-bottom: 2px; }
    .doc-footer { margin-top: 32px; padding-top: 16px; border-top: 1px solid var(--line);
      color: var(--muted); font-size: 11px; display: flex; justify-content: space-between;
      flex-wrap: wrap; gap: 8px; }
    @page { margin: 20mm 18mm; }
    @media print {
      body { background: #fff; }
      .page { padding: 0; }
      .cover { margin: 0 0 32px; padding: 28px 24px 24px; border-radius: 0; }
      .kpi-card, .driver-card, .roadmap-phase, .t-card { break-inside: avoid; }
      h2 { break-after: avoid; }
      .cta-footer { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
    }
"""
