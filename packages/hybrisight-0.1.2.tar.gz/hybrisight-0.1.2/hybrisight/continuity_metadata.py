# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import hashlib
import re
from collections.abc import Iterable
from typing import Any

from hybrisight.models import Asset, ScanResult

_AWS_ACCOUNT_RE = re.compile(r"\b\d{12}\b")
_AZURE_SUB_RE = re.compile(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}\b")


def _walk(value: Any) -> Iterable[Any]:
    if isinstance(value, dict):
        for item in value.values():
            yield item
            yield from _walk(item)
    elif isinstance(value, list):
        for item in value:
            yield item
            yield from _walk(item)


def infer_scope_identifiers(provider: str, assets: list[Asset] | None = None, payload: dict[str, Any] | None = None) -> list[str]:
    ids: set[str] = set()
    values: list[str] = []
    if assets:
        values.extend(str(asset.resource_id or "") for asset in assets)
    if payload:
        values.extend(str(item) for item in _walk(payload) if isinstance(item, str))
    for value in values:
        if provider == "aws":
            ids.update(_AWS_ACCOUNT_RE.findall(value))
        elif provider == "azure":
            ids.update(match.lower() for match in _AZURE_SUB_RE.findall(value))
    return sorted(ids)


def build_continuity_metadata(
    *,
    provider: str,
    engagement_label: str | None = None,
    engagement_key: str | None = None,
    scope_label: str | None = None,
    scope_fingerprint: str | None = None,
    identifiers: list[str] | None = None,
    series_label: str | None = None,
    series_key: str | None = None,
    cadence: str | None = None,
) -> dict[str, Any]:
    normalized_provider = provider.strip().lower()
    clean_identifiers = sorted({item.strip().lower() for item in identifiers or [] if item and item.strip()})
    normalized_engagement_key = (engagement_key or "").strip().lower()
    normalized_engagement_label = (engagement_label or "").strip()
    default_tail = "assessment scope" if not clean_identifiers else (
        f"{len(clean_identifiers)} account{'s' if len(clean_identifiers) != 1 else ''}" if normalized_provider == "aws" else f"{len(clean_identifiers)} subscription{'s' if len(clean_identifiers) != 1 else ''}"
    )
    payload = {
        "scope": {
            "provider": normalized_provider,
            "label": (scope_label or f"{normalized_provider.upper()} {default_tail}").strip(),
            "fingerprint": (scope_fingerprint or f"{normalized_provider}:explicit:{','.join(clean_identifiers) if clean_identifiers else 'default'}").strip().lower(),
            "identifiers": clean_identifiers,
        },
        "series": {
            "label": (series_label or normalized_engagement_label or f"{normalized_provider.upper()} Governance Brief").strip(),
            "key": (series_key or (f"{normalized_provider}:{normalized_engagement_key}:baseline" if normalized_engagement_key else f"{normalized_provider}:baseline")).strip().lower(),
            "cadence": (cadence or "ad_hoc").strip().lower(),
        },
    }
    if normalized_engagement_key or normalized_engagement_label:
        payload["engagement"] = {
            "label": normalized_engagement_label or normalized_engagement_key,
            "key": normalized_engagement_key or normalized_engagement_label.lower().replace(" ", "-"),
        }
    return payload


def continuity_metadata_from_result(result: ScanResult) -> dict[str, Any] | None:
    value = getattr(result, "continuity", None)
    return value if isinstance(value, dict) and value else None


def continuity_metadata_from_json(raw_json: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(raw_json)
    except Exception:
        return None
    value = payload.get("continuity")
    return value if isinstance(value, dict) and value else None


def continuity_metadata_digest(metadata: dict[str, Any] | None) -> str | None:
    if not metadata:
        return None
    payload = json.dumps(metadata, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()
