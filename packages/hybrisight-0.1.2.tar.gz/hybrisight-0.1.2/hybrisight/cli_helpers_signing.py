# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
from pathlib import Path

import typer

from hybrisight.cli_helpers_profile import (
    CREDENTIAL_HANDLING_URL,
    DEFAULT_SIGNING_KEY_PATH,
    DEFAULT_SIGNING_PRIVATE_KEY_PATH,
    DEFAULT_SIGNING_PUBLIC_KEY_PATH,
    _is_interactive_session,
    _safe_echo,
)
from hybrisight.signing import generate_ed25519_keypair_pem


def _resolve_signing_key_path() -> Path:
    path_value = os.environ.get("HYBRISIGHT_SIGNING_KEY_FILE")
    return Path(path_value).expanduser() if path_value else DEFAULT_SIGNING_KEY_PATH


def _resolve_signing_private_key_path() -> Path:
    path_value = os.environ.get("HYBRISIGHT_SIGNING_PRIVATE_KEY_FILE")
    return Path(path_value).expanduser() if path_value else DEFAULT_SIGNING_PRIVATE_KEY_PATH


def _resolve_signing_public_key_path() -> Path:
    path_value = os.environ.get("HYBRISIGHT_SIGNING_PUBLIC_KEY_FILE")
    return Path(path_value).expanduser() if path_value else DEFAULT_SIGNING_PUBLIC_KEY_PATH


def _load_signing_key_from_file(path: Path) -> str | None:
    if not path.exists():
        return None
    key = path.read_text().strip()
    return key or None


def _write_signing_key_file(path: Path, key: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"{key}\n")
    os.chmod(path, 0o600)


def _write_text_file(path: Path, content: str, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    os.chmod(path, mode)


def _print_signing_key_guidance(public_path: Path, key_id: str) -> None:
    _safe_echo(f"Artifact signing keypair ready. key_id={key_id}")
    _safe_echo("This key is for artifact integrity verification, not for the API Keys page.")
    _safe_echo(f"Public key path: {public_path}")
    _safe_echo("Register command example:")
    _safe_echo("hybrisight signing register --portal https://hybrisight.agapii.org --api-key <key> --public-key-file <path>")


def _ensure_signing_key_for_cli() -> bool:
    if os.environ.get("HYBRISIGHT_SIGNING_PRIVATE_KEY"):
        return True
    configured_private_key_file = os.environ.get("HYBRISIGHT_SIGNING_PRIVATE_KEY_FILE")
    if configured_private_key_file and Path(configured_private_key_file).expanduser().exists():
        return True

    private_key_path = _resolve_signing_private_key_path()
    if private_key_path.exists():
        os.environ["HYBRISIGHT_SIGNING_PRIVATE_KEY_FILE"] = str(private_key_path)
        return True

    if os.environ.get("HYBRISIGHT_SIGNING_KEY"):
        return True

    key_path = _resolve_signing_key_path()
    key_from_file = _load_signing_key_from_file(key_path)
    if key_from_file:
        os.environ["HYBRISIGHT_SIGNING_KEY"] = key_from_file
        return True

    if _is_interactive_session():
        _safe_echo("Artifact signing was requested, but no signing key is configured.", err=True)
        _safe_echo(f"Recommended private key path: {private_key_path}", err=True)
        if typer.confirm("Generate and store a tenant signing keypair now?", default=True):
            private_pem, public_pem, key_id = generate_ed25519_keypair_pem()
            public_key_path = _resolve_signing_public_key_path()
            try:
                _write_text_file(private_key_path, private_pem, 0o600)
                _write_text_file(public_key_path, public_pem, 0o644)
            except OSError as exc:
                _safe_echo(f"Unable to store signing keypair: {exc}", err=True)
                return False
            os.environ["HYBRISIGHT_SIGNING_PRIVATE_KEY_FILE"] = str(private_key_path)
            os.environ["HYBRISIGHT_SIGNING_KEY_ID"] = key_id
            _safe_echo(f"Signing private key created at {private_key_path} (permissions set to 600).")
            _print_signing_key_guidance(public_key_path, key_id)
            return True

    _safe_echo("Signing key is required when using --sign.", err=True)
    _safe_echo("Provide HYBRISIGHT_SIGNING_PRIVATE_KEY(_FILE) for tenant-scoped Ed25519 signing or HYBRISIGHT_SIGNING_KEY for legacy HMAC.", err=True)
    _safe_echo("Do not add signing keys in the API Keys UI. Register tenant public keys instead.", err=True)
    _safe_echo(f"Credential handling guide: {CREDENTIAL_HANDLING_URL}", err=True)
    return False
