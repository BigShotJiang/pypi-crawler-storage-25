# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import html
from typing import Any

from hybrisight.scoring import SCORING_VERSION
from hybrisight.engine_html_styles import REPORT_CSS
from hybrisight.engine_html_portal import PORTAL_PREVIEW_HTML


def render_html_report(context: dict[str, Any]) -> str:
    meta = context.get("meta", {})
    summary = context.get("summary", {})
    assessment = context.get("assessment", {})
    kpis = context.get("kpis", {})
    board_translation = context.get("board_translation", {})
    drivers = context.get("drivers", [])
    immediate_actions = context.get("immediate_actions", [])
    risk_profile = context.get("risk_profile", {})
    roadmap_view = context.get("roadmap_view", {})
    trajectory = context.get("trajectory", {})
    appendix = context.get("appendix", {})
    mapping_rows = appendix.get("foundation_mapping", []) or []
    compliance = context.get("compliance", {}) or {}

    def _e(value: Any) -> str:
        return html.escape("" if value is None else str(value))

    def _kpi(value: Any) -> str:
        """Format a KPI value, showing — only when truly absent (not for 0/0.0)."""
        if value is None:
            return "—"
        return html.escape(str(value))

    def _md(text: str) -> str:
        """Convert minimal markdown (bold, code, italic) to safe HTML."""
        import re
        escaped = html.escape(str(text))
        escaped = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", escaped)
        escaped = re.sub(r"`(.+?)`", r"<code>\1</code>", escaped)
        escaped = re.sub(r"\*(.+?)\*", r"<em>\1</em>", escaped)
        return escaped

    def _li(items: list[Any]) -> str:
        return "".join(f"<li>{_md(item)}</li>" for item in items)

    risk_rows = risk_profile.get("heatmap_rows", []) or []
    risk_rows_html = "".join(
        (
            "<tr>"
            f"<td>{_e(row.get('category'))}</td>"
            f"<td class='sev-critical'>{_e(row.get('critical'))}</td>"
            f"<td class='sev-high'>{_e(row.get('high'))}</td>"
            f"<td class='sev-medium'>{_e(row.get('medium'))}</td>"
            f"<td>{_e(row.get('low'))}</td>"
            f"<td>{_e(row.get('info'))}</td>"
            "</tr>"
        )
        for row in risk_rows
    )

    drivers_html = "".join(
        (
            "<div class='driver-card'>"
            "<div class='driver-header'>"
            f"<span class='driver-title'>{_e(driver.get('title'))}</span>"
            "<span class='badge badge-{sev}'>{sev_upper}</span>"
            "</div>"
            f"<p class='driver-impact'>{_e(driver.get('business_impact'))}</p>"
            f"<p class='driver-meta'>Affected resources: {_e(driver.get('affected_count'))} &nbsp;·&nbsp; Effort: {_e(driver.get('effort'))}</p>"
            "</div>"
        ).format(sev=_e(driver.get("severity") or ""), sev_upper=_e((driver.get("severity") or "").upper()))
        for driver in drivers
    )

    phases = roadmap_view.get("phases", []) or []
    roadmap_html = "".join(
        (
            "<div class='roadmap-phase'>"
            f"<div class='phase-label'>{_e(phase.get('label'))}</div>"
            f"<p class='phase-goal'>{_e(phase.get('goal'))}</p>"
            "<ul class='phase-items'>"
            + "".join(f"<li>{_e(theme.get('theme'))}</li>" for theme in (phase.get("themes") or []))
            + "</ul>"
            "</div>"
        )
        for phase in phases
    )

    points = trajectory.get("points", []) or []
    trajectory_html = "".join(
        f"<div class='traj-point'><div class='traj-label'>{_e(point.get('label'))}</div>"
        f"<div class='traj-score'>{_e(point.get('posture'))}<span class='traj-unit'>/10</span></div>"
        f"<div class='traj-risk'>Risk: {_e(point.get('risk_index'))}</div></div>"
        for point in points
    )
    mapping_html = "".join(
        (
            "<tr>"
            f"<td>{_e(row.get('control'))}</td>"
            f"<td>{_e(row.get('aws'))}</td>"
            f"<td>{_e(row.get('azure'))}</td>"
            "</tr>"
        )
        for row in mapping_rows
    )

    report_label = _e(assessment.get("label") or "Open Governance Brief")
    intro_copy = _e(assessment.get("summary") or "Cloud governance baseline assessment.")
    client_name = _e(meta.get("tenant_name") or "")
    provider = _e(meta.get("provider") or "")
    report_id = _e(meta.get("report_id") or "")
    generated_at = _e(meta.get("generated_at_utc") or "")
    year = _e(meta.get("year") or "")
    is_foundation = assessment.get("type") == "foundation"

    def _pct_color(pct: int) -> str:
        if pct >= 50:
            return "var(--low)"
        if pct >= 25:
            return "var(--medium)"
        return "var(--critical)"

    fw_colors = {
        "CIS AWS Foundations Benchmark": "#d97706",
        "SOC 2 Trust Services Criteria": "#2563eb",
        "NHS Data Security": "#4338ca",
        "NCSC Cyber Essentials": "#16a34a",
    }

    cards: list[str] = []
    gated = context.get("gated_compliance", True)
    if gated:
        for name_inner, data in sorted(compliance.items()):
            dot_color = fw_colors.get(name_inner, "var(--accent)")
            cards.append(
                "<div class='compliance-card' style='opacity:0.7;filter:blur(0.5px);position:relative;overflow:hidden'>"
                "<div style='position:absolute;inset:0;display:flex;align-items:center;justify-content:center;"
                "background:rgba(255,255,255,0.6);z-index:2;backdrop-filter:blur(2px)'>"
                "<span style='font-size:12px;font-weight:700;color:var(--accent);padding:8px 12px;"
                "background:#fff;border-radius:8px;border:1px solid var(--accent)'>"
                "Upload to unlock →</span></div>"
                f"<div class='compliance-card-header'>"
                f"<span class='compliance-dot' style='background:{dot_color}'></span>"
                f"<span class='compliance-fw-name'>{_e(name_inner)}</span>"
                "</div>"
                f"<div class='compliance-version'>{_e(data.get('version', ''))}</div>"
                "<div class='compliance-pct-row'>"
                f"<span class='compliance-pct' style='color:var(--muted)'>—%</span>"
                f"<span class='compliance-pct-label'>covered</span>"
                "</div>"
                f"<div class='compliance-meta'>— of — controls</div>"
                f"<div class='compliance-meta'>— applicable rules</div>"
                "</div>"
            )
    else:
        for name_inner, data in sorted(compliance.items()):
            dot_color = fw_colors.get(name_inner, "var(--accent)")
            pct = data.get("coverage_percent", 0)
            pct_color = _pct_color(pct)
            cards.append(
                "<div class='compliance-card'>"
                "<div class='compliance-card-header'>"
                f"<span class='compliance-dot' style='background:{dot_color}'></span>"
                f"<span class='compliance-fw-name'>{_e(name_inner)}</span>"
                "</div>"
                f"<div class='compliance-version'>v{_e(data.get('version', ''))}</div>"
                "<div class='compliance-pct-row'>"
                f"<span class='compliance-pct' style='color:{pct_color}'>{_e(pct)}%</span>"
                f"<span class='compliance-pct-label'>covered</span>"
                "</div>"
                f"<div class='compliance-meta'>{_e(data.get('covered_controls'))} of {_e(data.get('total_controls'))} controls</div>"
                f"<div class='compliance-meta'>{_e(data.get('applicable_rules'))} applicable rules</div>"
                "</div>"
            )
    compliance_cards = "".join(cards)

    def _first(*vals: Any) -> str:
        for v in vals:
            if v is not None:
                return html.escape(str(v))
        return "—"

    posture_score = _first(summary.get("posture_score"), kpis.get("posture_score"))
    risk_index = _first(summary.get("risk_index"), kpis.get("risk_index"))
    waste_label = _first(kpis.get("est_annual_waste_label"), summary.get("estimated_waste_label"))
    assets = _first(summary.get("assets"))
    findings_count = _first(summary.get("findings"))
    coverage = _first(summary.get("coverage_level"))
    confidence = _first(summary.get("confidence_adjusted_score"), kpis.get("confidence_adjusted_score"))
    coverage_disclaimer = _e(summary.get("coverage_disclaimer") or "")

    actions_section_title = "Immediate Must-Do Actions" if is_foundation else "Immediate Priority Actions"
    drivers_section_title = "Foundation Control Drivers" if is_foundation else "Primary Risk Drivers"
    roadmap_title = "30-Day Foundation Plan" if is_foundation else "Stabilisation Roadmap (30 / 60 / 90 Days)"

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>HybriSight {report_label} — {client_name}</title>
  <!-- scoring={_e(meta.get("scoring_version", SCORING_VERSION))} -->
  <style>{REPORT_CSS}</style>
</head>
<body>
<div class="page">

  <div class="cover">
    <div class="cover-logo">HybriSight · Cloud Governance</div>
    <h1>{report_label}</h1>
    <p class="cover-subtitle">{intro_copy}</p>
    <div class="cover-meta">
      <span><strong>Prepared for</strong>{client_name if client_name and client_name != "N/A" else "—"}</span>
      <span><strong>Cloud Provider</strong>{provider}</span>
      <span><strong>Assessment Date</strong>{generated_at}</span>
      <span><strong>Report ID</strong>{report_id}</span>
      <span><strong>Coverage</strong>{coverage}</span>
    </div>
  </div>

  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-label">Posture Score</div><div class="kpi-value">{posture_score}<span style="font-size:14px;color:var(--muted)">/10</span></div></div>
    <div class="kpi-card"><div class="kpi-label">Risk Index</div><div class="kpi-value">{risk_index}</div></div>
    <div class="kpi-card"><div class="kpi-label">Confidence-Adjusted</div><div class="kpi-value">{confidence}</div><div class="kpi-note">Coverage-weighted</div></div>
    <div class="kpi-card"><div class="kpi-label">Assets Analysed</div><div class="kpi-value">{assets}</div></div>
    <div class="kpi-card"><div class="kpi-label">Total Findings</div><div class="kpi-value">{findings_count}</div></div>
    <div class="kpi-card"><div class="kpi-label">Est. Annual Waste</div><div class="kpi-value" style="font-size:18px">{waste_label}</div></div>
  </div>

  <h2>Executive Exposure Summary</h2>
  <div class="translation-grid">
    <div class="t-card"><h3>Current Risk Position</h3><p>{_e(board_translation.get("current_risk_position_html"))}</p></div>
    <div class="t-card"><h3>Without Stabilisation</h3><p>{_e(board_translation.get("inaction_outlook_html"))}</p></div>
    <div class="t-card"><h3>Stabilisation Objective</h3><p>{_e(board_translation.get("stabilisation_objective_html"))}</p></div>
    <div class="t-card"><h3>Recommended Path</h3><p>{_e(board_translation.get("recommended_path_html"))}</p></div>
  </div>

  <h2>{actions_section_title}</h2>
  <div class="actions-list"><ul>{_li(immediate_actions)}</ul></div>

  <h2>{drivers_section_title}</h2>
  <div class="drivers-grid">{drivers_html}</div>

  <h2>Environment Risk Profile</h2>
  <table>
    <thead><tr><th>Category</th><th>Critical</th><th>High</th><th>Medium</th><th>Low</th><th>Info</th></tr></thead>
    <tbody>{risk_rows_html}</tbody>
  </table>
  {"<p class='disclaimer'>" + coverage_disclaimer + "</p>" if coverage_disclaimer else ""}
  <p class="narrative">{_e(risk_profile.get("narrative"))}</p>

  <h2>Compliance Framework Coverage</h2>
  <div class="compliance-grid">{compliance_cards}</div>
  <p class="disclaimer">Coverage is based on rules matched during this assessment. Controls not explicitly checked are marked uncovered. Framework mappings are advisory and not certified audit results.</p>

  <h2>{roadmap_title}</h2>
  <div class="roadmap-grid">{roadmap_html}</div>

  <h2>{"Expected Readiness Outcome" if is_foundation else "Governance Trajectory"}</h2>
  <div class="trajectory-row">{trajectory_html}</div>
  <p class="narrative">{_e(trajectory.get("narrative"))}</p>
  <p class="disclaimer">{_e(trajectory.get("assumptions"))}</p>

  <h2 class="appendix">Appendix: Assessment Methodology</h2>
  <div class="appendix">
    <p>{_e(appendix.get("methodology_html"))}</p>
    <p class="disclaimer">{_e(appendix.get("coverage_disclaimer_html"))}</p>
    <h3>Foundation Control Mapping</h3>
    <table>
      <thead><tr><th>HybriSight Control</th><th>AWS Native Evidence</th><th>Azure Native Evidence</th></tr></thead>
      <tbody>{mapping_html}</tbody>
    </table>
  </div>

  {PORTAL_PREVIEW_HTML}

  <div class="cta-footer">
    <div>
      <h3 style="margin:0 0 6px;font-size:16px">This scan runs the same engine as the portal.</h3>
      <p style="margin:0 0 10px;font-size:12.5px;opacity:0.9">57 rules. 4 compliance frameworks. Board-ready output. No trial period, no feature countdown — use the CLI freely.</p>
      <p style="margin:0;font-size:12px;opacity:0.8">When you need hosted reports, trend tracking, team collaboration, or an execution board — they're ready when you are.</p>
    </div>
    <div class="cta-contact">
      <strong style="display:block;font-size:14px;margin-bottom:4px">Portal (from £350)</strong>
      <span style="font-size:12px;opacity:0.85">Execution board · Trend tracking<br>Share links · Signed verification</span>
      <p style="margin:8px 0 0;font-size:11px;opacity:0.7"><a href="https://hybrisight.agapii.org" style="color:inherit;text-decoration:underline">hybrisight.agapii.org</a></p>
    </div>
  </div>

  <div class="doc-footer">
    <span>HybriSight &copy; {year} &nbsp;·&nbsp; Confidential &nbsp;·&nbsp; For authorised recipient only</span>
    <span>Report ID: {report_id}</span>
  </div>

</div>
</body>
</html>
"""
