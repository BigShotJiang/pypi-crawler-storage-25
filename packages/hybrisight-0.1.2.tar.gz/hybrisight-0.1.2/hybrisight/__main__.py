# SPDX-License-Identifier: Apache-2.0
from hybrisight.cli import app

if __name__ == "__main__":
    app()
