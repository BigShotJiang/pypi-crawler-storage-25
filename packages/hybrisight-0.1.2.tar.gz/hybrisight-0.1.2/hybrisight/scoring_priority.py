# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from math import exp, log10, sqrt
from typing import Any

from hybrisight.models import CoverageLevel, Finding
from hybrisight.scoring_constants import (
    CALIBRATION_K,
    CATEGORY_MULTIPLIERS,
    COVERAGE_MULTIPLIERS,
    EFFORT_MODIFIERS,
    EFFORT_RANK,
    SCORING_VERSION,
    SEVERITY_RANK,
    SEVERITY_WEIGHTS,
    THEME_DEFINITIONS,
)


def finding_base_score(finding: Finding) -> float:
    return SEVERITY_WEIGHTS[finding.severity.value] * CATEGORY_MULTIPLIERS[finding.category.value]


def finding_cost_score(finding: Finding) -> float:
    annual_cost = float(finding.estimated_annual_cost_impact_gbp or 0.0)
    return min(3.0, log10(1.0 + (annual_cost / 1000.0)))


def finding_impact_score(finding: Finding) -> float:
    return finding_base_score(finding) + finding_cost_score(finding)


def finding_priority_score(finding: Finding) -> float:
    return finding_impact_score(finding) * EFFORT_MODIFIERS[finding.remediation_effort.value]


def _priority_sort_key(finding: Finding) -> tuple[float, int, float, int, str]:
    return (
        -finding_priority_score(finding),
        -SEVERITY_WEIGHTS[finding.severity.value],
        -float(finding.estimated_annual_cost_impact_gbp or 0.0),
        EFFORT_RANK[finding.remediation_effort.value],
        finding.id,
    )


def prioritize_findings(findings: list[Finding]) -> list[Finding]:
    return sorted(findings, key=_priority_sort_key)


def calculate_snapshot_scores(
    findings: list[Finding],
    asset_count: int,
    coverage_level: CoverageLevel,
) -> dict[str, float | str]:
    total = sum(finding_impact_score(finding) for finding in findings)
    size_norm = sqrt(max(asset_count, 1))
    norm_total = total / size_norm

    risk_index = 100.0 * (1.0 - exp(-norm_total / CALIBRATION_K))
    posture_score = round(10.0 * (1.0 - (risk_index / 100.0)), 1)
    confidence_adjusted_score = round(posture_score * COVERAGE_MULTIPLIERS[coverage_level.value], 1)

    return {
        "scoring_version": SCORING_VERSION,
        "risk_index": round(risk_index, 1),
        "posture_score": posture_score,
        "confidence_adjusted_score": confidence_adjusted_score,
    }


def assign_roadmap_phase(finding: Finding) -> str:
    severity = finding.severity.value
    effort = finding.remediation_effort.value
    category = finding.category.value

    if severity == "critical":
        return "30_days"
    if category == "cost":
        if severity == "high" and effort in {"low", "medium"}:
            return "30_days"
        if severity in {"high", "medium"} or effort in {"low", "medium"}:
            return "60_days"
        return "90_days"
    if category in {"security", "resilience"}:
        if severity == "high" and effort in {"low", "medium"}:
            return "30_days"
        if severity in {"high", "medium"}:
            return "60_days"
        return "90_days"
    if category == "ops":
        if severity in {"critical", "high", "medium"}:
            return "60_days"
        return "90_days"
    return "90_days"


def resolve_theme(finding: Finding) -> dict[str, str]:
    rule_id = finding.id.upper()
    service = (finding.service or "").lower()

    for theme in THEME_DEFINITIONS:
        if any(rule_id.startswith(prefix) for prefix in theme["prefixes"]):
            return {"name": str(theme["name"]), "summary": str(theme["summary"])}
        if service in theme["fallback_services"]:
            return {"name": str(theme["name"]), "summary": str(theme["summary"])}

    fallback_name = f"{finding.category.value.title()} Controls"
    fallback_summary = "Address prioritized control gaps to reduce material risk and improve operating confidence."
    return {"name": fallback_name, "summary": fallback_summary}


def workflow_template(
    *,
    theme: str,
    risk_category: str,
    business_impact: str,
    actions: list[str],
    affected_resource_count: int,
) -> dict[str, Any]:
    category_map = {
        "security": {
            "current": "Control gaps leave exploitable paths and higher incident likelihood.",
            "target": "Access and exposure controls are hardened and continuously governed.",
            "validation": [
                "Privileged access paths reviewed and constrained",
                "High-risk policy exceptions removed",
                "Control baseline evidence captured",
            ],
        },
        "cost": {
            "current": "Spending inefficiencies reduce margin and budget predictability.",
            "target": "Waste is reduced and cost controls are embedded into operations.",
            "validation": [
                "Idle or oversized assets remediated",
                "Savings controls implemented and measured",
                "Cost ownership and accountability assigned",
            ],
        },
        "resilience": {
            "current": "Recovery readiness is limited by backup/availability control gaps.",
            "target": "Recovery posture supports agreed continuity expectations.",
            "validation": [
                "Backup scope and retention validated",
                "Single points of failure reduced",
                "Recovery verification evidence available",
            ],
        },
        "ops": {
            "current": "Governance hygiene issues reduce operational visibility and control.",
            "target": "Ownership and operating standards are consistently enforced.",
            "validation": [
                "Ownership metadata coverage meets policy",
                "Tagging/operating standards enforced",
                "Exception handling process in place",
            ],
        },
    }
    defaults = category_map.get(risk_category, category_map["ops"])
    steps = actions[:3] if actions else ["Define prioritized remediation plan", "Implement controls", "Validate outcomes"]

    return {
        "title": f"{theme} Remediation Workflow",
        "current_state": defaults["current"],
        "target_state": defaults["target"],
        "impact_statement": business_impact,
        "scope_statement": f"{affected_resource_count} affected resources in this phase.",
        "steps": [{"stage": idx + 1, "action": step} for idx, step in enumerate(steps)],
        "validation_checkpoints": defaults["validation"],
    }


__all__ = [
    "SEVERITY_RANK",
    "SEVERITY_WEIGHTS",
    "assign_roadmap_phase",
    "calculate_snapshot_scores",
    "finding_base_score",
    "finding_cost_score",
    "finding_impact_score",
    "finding_priority_score",
    "prioritize_findings",
    "resolve_theme",
    "workflow_template",
]
