# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

from hybrisight.models import Category, CoverageLevel, ScanResult
from hybrisight.scoring import SEVERITY_WEIGHTS

BASELINE_FEE_GBP = 2000.0
IMMATERIAL_WASTE_THRESHOLD_GBP = 250.0


def risk_exposure_tier(risk_index: float) -> str:
    if risk_index >= 80.0:
        return "Critical"
    if risk_index >= 60.0:
        return "High"
    if risk_index >= 40.0:
        return "Moderate"
    return "Controlled"


def posture_band(posture_score: float) -> str:
    if posture_score < 2.0:
        return "Critical"
    if posture_score < 5.0:
        return "At Risk"
    if posture_score < 8.0:
        return "Controlled"
    return "Strong"


def currency_comp_context(estimated_waste: float) -> str:
    if estimated_waste < IMMATERIAL_WASTE_THRESHOLD_GBP:
        return "Cost opportunity is not the primary driver in this snapshot."
    if BASELINE_FEE_GBP <= 0 or estimated_waste < BASELINE_FEE_GBP:
        return "Material recoverable inefficiency is present, but below baseline fee multiple threshold."
    multiple = estimated_waste / BASELINE_FEE_GBP
    return f"This represents approximately {multiple:.1f}x the baseline assessment fee in potential annual efficiency recovery."


def format_estimated_waste_label(estimated_waste: float) -> str:
    if estimated_waste < IMMATERIAL_WASTE_THRESHOLD_GBP:
        return "Low / immaterial opportunity detected (< GBP 250/year)"
    return f"GBP {estimated_waste:,.0f} annually"


def is_projection_valid(phase_projection: dict[str, Any]) -> bool:
    now_posture = float(phase_projection["now"]["posture_score"])
    d30_posture = float(phase_projection["d30"]["posture_score"])
    d60_posture = float(phase_projection["d60"]["posture_score"])
    d90_posture = float(phase_projection["d90"]["posture_score"])
    now_risk = float(phase_projection["now"]["risk_index"])
    d30_risk = float(phase_projection["d30"]["risk_index"])
    d60_risk = float(phase_projection["d60"]["risk_index"])
    d90_risk = float(phase_projection["d90"]["risk_index"])

    monotonic = (
        d30_posture >= now_posture
        and d60_posture >= d30_posture
        and d90_posture >= d60_posture
        and d30_risk <= now_risk
        and d60_risk <= d30_risk
        and d90_risk <= d60_risk
    )
    delayed_jump = d30_posture == now_posture and d60_posture == now_posture and d90_posture > now_posture
    return monotonic and not delayed_jump


def coverage_confidence_adjusted_score(result: ScanResult) -> float:
    posture_score = float(result.posture_score or 0.0)
    confidence_adjusted_score = float(result.confidence_adjusted_score or posture_score)
    if result.coverage_level == CoverageLevel.full:
        return posture_score
    return confidence_adjusted_score


def build_executive_brief(
    result: ScanResult,
    findings_sorted: list[Any],
    estimated_waste: float,
    phase_projection: dict[str, Any],
) -> dict[str, str | float]:
    risk_index = float(result.risk_index or 0.0)
    posture_score = float(result.posture_score or 0.0)
    tier = risk_exposure_tier(risk_index)

    has_identity_weakness = any(
        f.category == Category.security and (f.service == "iam" or "mfa" in f.title.lower() or "identity" in f.title.lower())
        for f in findings_sorted
    )
    has_external_exposure = any(
        f.category == Category.security and ("public" in f.title.lower() or "internet" in f.title.lower() or "0.0.0.0/0" in f.description)
        for f in findings_sorted
    )

    risk_headline = f"Current exposure is classified as {tier}."
    if tier in {"Critical", "High"}:
        risk_body = "Your cloud environment currently has multiple externally exploitable control gaps and systemic identity weaknesses. Based on the HybriSight model, compromise likelihood is materially elevated."
    elif tier == "Moderate":
        risk_body = "Your cloud environment shows material control weaknesses that can increase incident likelihood if left unresolved."
    else:
        risk_body = "Your cloud environment is currently in a controlled band, with targeted improvements available to sustain posture."

    signal_parts: list[str] = []
    if has_external_exposure:
        signal_parts.append("internet-facing exposure paths")
    if has_identity_weakness:
        signal_parts.append("identity governance gaps")
    if not signal_parts and findings_sorted:
        signal_parts.append("control weaknesses across security, cost, and resilience")

    risk_position_summary = f"{risk_headline} {risk_body}"
    if signal_parts:
        risk_position_summary += f" Primary drivers include {', '.join(signal_parts)}."

    if estimated_waste < IMMATERIAL_WASTE_THRESHOLD_GBP:
        financial_opportunity_summary = "Cost opportunity is currently low / immaterial in this snapshot (< GBP 250/year). Cost opportunity is not the primary driver in this snapshot."
    else:
        financial_opportunity_summary = f"Recoverable cost inefficiency identified: GBP {estimated_waste:,.0f} annually. {currency_comp_context(estimated_waste)}"

    d30 = phase_projection.get("d30", {})
    d90 = phase_projection.get("d90", {})
    projection_valid = bool(phase_projection.get("projection_valid", True))
    d30_posture = float(d30.get("posture_score", posture_score))
    d90_risk = float(d90.get("risk_index", risk_index))
    d90_posture = float(d90.get("posture_score", posture_score))

    stabilization_closure = "most severe externally exploitable conditions are removed" if has_external_exposure else "highest-priority exposure conditions are materially reduced"
    if projection_valid and abs(d30_posture - posture_score) >= 0.1:
        outcome_30_day_summary = f"Within 30 days, the objective is risk stabilisation: identity and external exposure controls are hardened first. Posture is projected to move from {posture_score:.1f} to {d30_posture:.1f}, while {stabilization_closure}."
        transformation_90_day_summary = f"By 90 days, full phase execution is projected to move the environment into a {risk_exposure_tier(d90_risk)} risk band with a {posture_band(d90_posture).lower()} posture band, assuming full remediation of listed themes."
    else:
        outcome_30_day_summary = "Within 30 days, the objective is risk stabilisation: identity and external exposure controls are hardened first. Measurable delta is confirmed on re-run after Phase 1 remediation."
        transformation_90_day_summary = "By 90 days, the target state is controlled governance with validated risk reduction, confirmed through scheduled reassessment."

    return {
        "exposure_tier": tier,
        "risk_position_summary": risk_position_summary,
        "financial_opportunity_summary": financial_opportunity_summary,
        "outcome_30_day_summary": outcome_30_day_summary,
        "transformation_90_day_summary": transformation_90_day_summary,
        "inaction_statement": "If no action is taken, current exposure conditions increase the probability of account takeover, regulatory reporting events, and ransomware-driven operational disruption.",
        "advisory_recommendation": "Recommended next step: initiate Phase 1 Stabilisation (0-30 days) focused on identity hardening, internet exposure removal, encryption enforcement, and immediate cost rightsizing, then re-run HybriSight to validate measurable delta.",
    }


def build_primary_risk_drivers(findings_grouped: list[dict[str, Any]]) -> list[dict[str, Any]]:
    deduped: dict[str, dict[str, Any]] = {}
    for theme_group in findings_grouped:
        for rule in theme_group["rules"]:
            key = str(rule["title"]).strip().lower()
            existing = deduped.get(key)
            rule_id = str(rule["id"])
            if existing is None:
                deduped[key] = {
                    "title": str(rule["title"]),
                    "severity": str(rule["severity"]),
                    "business_impact": str(rule["business_impact"]),
                    "effort": str(rule["remediation_effort"]),
                    "affected_resource_count": int(rule["affected_resource_count"]),
                    "theme": str(theme_group["theme"]),
                    "rule_ids": [rule_id],
                }
                continue
            existing["affected_resource_count"] += int(rule["affected_resource_count"])
            if rule_id not in existing["rule_ids"]:
                existing["rule_ids"].append(rule_id)
            if SEVERITY_WEIGHTS[str(rule["severity"])] > SEVERITY_WEIGHTS[str(existing["severity"])]:
                existing["severity"] = str(rule["severity"])
                existing["business_impact"] = str(rule["business_impact"])
                existing["effort"] = str(rule["remediation_effort"])
                existing["theme"] = str(theme_group["theme"])

    drivers = sorted(deduped.values(), key=lambda d: (-SEVERITY_WEIGHTS[d["severity"]], -int(d["affected_resource_count"]), d["title"]))
    return drivers[:5]
