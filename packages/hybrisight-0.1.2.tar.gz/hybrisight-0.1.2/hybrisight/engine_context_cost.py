# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any


def build_cost_breakdown(findings_sorted: list[Any], all_findings: list[Any]) -> list[dict[str, Any]]:
    """Build line-item cost breakdown from findings with cost data."""
    cost_findings = [f for f in all_findings if (f.estimated_annual_cost_impact_gbp or 0) > 0]
    if not cost_findings:
        return []
    cost_findings.sort(key=lambda f: f.estimated_annual_cost_impact_gbp or 0, reverse=True)
    breakdown: list[dict[str, Any]] = []
    for f in cost_findings[:8]:
        breakdown.append({
            "title": f.title,
            "finding_id": f.id,
            "severity": f.severity,
            "amount_gbp": f.estimated_annual_cost_impact_gbp,
            "category": f.category,
            "remediation": getattr(f, "remediation_guidance", ""),
            "effort": getattr(f, "remediation_effort", "low"),
        })
    return breakdown
