# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

import httpx

from hybrisight.models import Asset, Provider


def _collect_sql_assets(self: Any, credential: Any, subscription_id: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        token = credential.get_token("https://management.azure.com/.default").token
    except Exception:
        return assets

    try:
        servers_url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Sql/servers?api-version=2023-08-01"
        servers_resp = httpx.get(servers_url, headers={"Authorization": f"Bearer {token}"}, timeout=20.0)
        servers_resp.raise_for_status()
        for server in servers_resp.json().get("value", []):
            server_name = server["name"]
            rg = server["id"].split("/")[4]
            databases_url = f"https://management.azure.com/subscriptions/{subscription_id}/resourceGroups/{rg}/providers/Microsoft.Sql/servers/{server_name}/databases?api-version=2023-08-01"
            db_resp = httpx.get(databases_url, headers={"Authorization": f"Bearer {token}"}, timeout=20.0)
            db_resp.raise_for_status()
            for db in db_resp.json().get("value", []):
                props = db.get("properties", {})
                assets.append(
                    Asset(
                        provider=Provider.azure, service="azure_sql",
                        resource_id=db["id"], resource_type="sql_database",
                        region=server.get("location", ""),
                        tags={t["key"]: t["value"] for t in (db.get("tags") or {}).items() if isinstance(t, dict)},
                        metadata={
                            "backup_enabled": True,
                            "encrypted": bool(props.get("earliestRestoreDate") or False),
                            "allocated_gb": int((props.get("maxSizeBytes") or 0) / 1073741824),
                            "availability_zone_count": 1,
                            "is_critical": False,
                        },
                    )
                )
    except Exception:
        pass
    return assets


def _collect_activity_log_assets(self: Any, credential: Any, subscription_id: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        token = credential.get_token("https://management.azure.com/.default").token
    except Exception:
        return assets

    try:
        dtg_url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/microsoft.insights/diagnosticSettings?api-version=2021-05-01"
        dtg_resp = httpx.get(dtg_url, headers={"Authorization": f"Bearer {token}"}, timeout=20.0)
        dtg_resp.raise_for_status()
        diag_count = len(dtg_resp.json().get("value", []))
    except Exception:
        diag_count = 0

    try:
        alerts_url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Insights/activityLogAlerts?api-version=2020-10-01"
        alerts_resp = httpx.get(alerts_url, headers={"Authorization": f"Bearer {token}"}, timeout=20.0)
        alerts_resp.raise_for_status()
        alert_count = len(alerts_resp.json().get("value", []))
    except Exception:
        alert_count = 0

    try:
        events_url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/microsoft.insights/eventtypes/management/values?api-version=2015-04-01&$top=1"
        events_resp = httpx.get(events_url, headers={"Authorization": f"Bearer {token}"}, timeout=20.0)
        events_resp.raise_for_status()
        has_activity = len(events_resp.json().get("value", [])) > 0
    except Exception:
        has_activity = False

    if has_activity or diag_count > 0 or alert_count > 0:
        assets.append(
            Asset(
                provider=Provider.azure, service="azure_monitor",
                resource_id=f"activity-log:{subscription_id}",
                resource_type="activity_log_summary",
                region="global",
                metadata={
                    "has_activity_events": has_activity,
                    "diagnostic_setting_count": diag_count,
                    "activity_alert_count": alert_count,
                    "cloudwatch_log_group_encryption": True,
                    "retention_in_days": 365,
                },
            )
        )

    return assets
