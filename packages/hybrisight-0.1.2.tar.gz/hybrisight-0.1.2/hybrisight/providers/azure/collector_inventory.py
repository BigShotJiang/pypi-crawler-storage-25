# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

from hybrisight.models import Asset, Provider


def _collect_generic_resources(self: Any, resources: Any) -> list[Asset]:
    assets: list[Asset] = []
    for resource in resources.resources.list():
        tags = resource.tags or {}
        assets.append(
            Asset(
                provider=Provider.azure,
                service="resource",
                resource_id=resource.id,
                resource_type=resource.type,
                region=resource.location,
                tags=tags,
                metadata={},
            )
        )
    return assets


def _collect_storage_assets(self: Any, storage_client: Any) -> list[Asset]:
    assets: list[Asset] = []
    for account in storage_client.storage_accounts.list():
        rg = account.id.split("/")[4]
        details = storage_client.storage_accounts.get_properties(rg, account.name)
        tags = details.tags or {}
        lifecycle_policy = False
        try:
            policies = storage_client.management_policies.list_by_storage_account(rg, account.name)
            lifecycle_policy = len(list(policies)) > 0
        except Exception:
            lifecycle_policy = False

        sku_name = str(getattr(details.sku, "name", "") or "")
        redundancy = sku_name.split("_")[-1].lower() if "_" in sku_name else "unknown"
        public_access = bool(getattr(details, "allow_blob_public_access", True))
        encrypted = bool(getattr(details.encryption, "services", None))

        assets.append(
            Asset(
                provider=Provider.azure,
                service="storage",
                resource_id=details.id,
                resource_type="storage_account",
                region=details.location,
                tags=tags,
                metadata={
                    "public_access": public_access,
                    "encrypted": encrypted,
                    "versioning_enabled": bool(getattr(details, "is_hns_enabled", False)),
                    "lifecycle_policy": lifecycle_policy,
                    "redundancy": redundancy,
                    "allocated_gb": 0,
                    "used_gb": 0,
                },
            )
        )
    return assets


def _collect_vm_assets(self: Any, compute_client: Any, credential: Any = None, subscription_id: str = "") -> list[Asset]:
    assets: list[Asset] = []
    token: str | None = None
    if credential and subscription_id:
        try:
            token = credential.get_token("https://management.azure.com/.default").token
        except Exception:
            token = None

    for vm in compute_client.virtual_machines.list_all():
        tags = vm.tags or {}
        az_count = len(vm.zones or []) if hasattr(vm, "zones") else 1

        avg_cpu: float | None = None
        if token and subscription_id and vm.id:
            try:
                import httpx
                parts = vm.id.split("/")
                if "resourceGroups" in parts:
                    rg_idx = parts.index("resourceGroups") + 1
                    rg = parts[rg_idx] if rg_idx < len(parts) else ""
                    vm_name = parts[-1] if parts else ""
                    if rg and vm_name:
                        import urllib.parse
                        timespan_end = datetime.now(UTC)
                        timespan_start = timespan_end - timedelta(days=30)
                        cpu_url = (
                            f"https://management.azure.com/subscriptions/{subscription_id}"
                            f"/resourceGroups/{rg}/providers/Microsoft.Compute/virtualMachines/{vm_name}"
                            f"/providers/microsoft.insights/metrics"
                            f"?api-version=2018-01-01"
                            f"&metricnames=Percentage%20CPU"
                            f"&aggregation=Average"
                            f"&timespan={urllib.parse.quote(timespan_start.isoformat())}/{urllib.parse.quote(timespan_end.isoformat())}"
                            f"&interval=PT1H"
                        )
                        cpu_resp = httpx.get(cpu_url, headers={"Authorization": f"Bearer {token}"}, timeout=15.0)
                        cpu_resp.raise_for_status()
                        cpu_data = cpu_resp.json()
                        values: list[float] = []
                        for series in cpu_data.get("value", []):
                            for ts in series.get("timeseries", []):
                                for data_pt in ts.get("data", []):
                                    val = data_pt.get("average")
                                    if val is not None:
                                        values.append(float(val))
                        if values:
                            avg_cpu = sum(values) / len(values)
            except Exception:
                avg_cpu = None

        assets.append(
            Asset(
                provider=Provider.azure,
                service="vm",
                resource_id=vm.id,
                resource_type="virtual_machine",
                region=vm.location,
                tags=tags,
                metadata={
                    "avg_cpu_utilization_30d": avg_cpu,
                    "backup_enabled": bool(tags.get("backup", "").lower() in {"true", "yes", "1"}),
                    "is_critical": tags.get("criticality", "").lower() in {"high", "critical"},
                    "availability_zone_count": az_count,
                    "autoscaling_enabled": bool(getattr(vm, "virtual_machine_scale_set", None)),
                },
            )
        )

        for disk in vm.storage_profile.data_disks or []:
            assets.append(
                Asset(
                    provider=Provider.azure,
                    service="disk",
                    resource_id=disk.managed_disk.id if disk.managed_disk else f"{vm.id}/disk/{disk.name}",
                    resource_type="managed_disk",
                    region=vm.location,
                    tags=tags,
                    metadata={
                        "attached": True,
                        "encrypted": True,
                        "ade_enabled": bool(getattr(disk, "encryption_settings", None)),
                        "allocated_gb": int(getattr(disk, "disk_size_gb", 0) or 0),
                        "used_gb": int(getattr(disk, "disk_size_gb", 0) or 0),
                        "backup_enabled": bool(tags.get("backup", "").lower() in {"true", "yes", "1"}),
                    },
                )
            )

    try:
        active_disk_ids = {a.resource_id for a in assets if a.service == "disk"}
        for snap in compute_client.snapshots.list():
            source_id = None
            if snap.creation_data and snap.creation_data.source_resource_id:
                source_id = snap.creation_data.source_resource_id.lower()
            source_exists = any(source_id and source_id in d.lower() for d in active_disk_ids) if source_id else False
            assets.append(
                Asset(
                    provider=Provider.azure,
                    service="snapshot",
                    resource_id=snap.id,
                    resource_type="snapshot",
                    region=snap.location,
                    tags=snap.tags or {},
                    metadata={
                        "source_volume_exists": source_exists,
                        "encrypted": bool(snap.encryption),
                        "allocated_gb": int(snap.disk_size_gb or 0),
                    },
                )
            )
    except Exception:
        pass

    return assets


def _collect_network_assets(self: Any, network_client: Any) -> list[Asset]:
    assets: list[Asset] = []
    for nsg in network_client.network_security_groups.list_all():
        ingress: list[dict[str, str | int]] = []
        for rule in nsg.security_rules or []:
            if str(rule.direction).lower() != "inbound" or str(rule.access).lower() != "allow":
                continue
            cidr = getattr(rule, "source_address_prefix", None)
            port = getattr(rule, "destination_port_range", "*")
            if port == "*":
                port = 0
            try:
                p = int(port)
            except (TypeError, ValueError):
                p = 0
            ingress.append({"cidr": cidr, "port": p})

        assets.append(
            Asset(
                provider=Provider.azure,
                service="network",
                resource_id=nsg.id,
                resource_type="network_security_group",
                region=nsg.location,
                tags=nsg.tags or {},
                metadata={"ingress": ingress},
            )
        )

    for lb in network_client.load_balancers.list_all():
        zones = list(lb.zones or []) if hasattr(lb, "zones") and lb.zones else []
        az_count = len(zones) or 1
        backend_count = 0
        for pool in lb.backend_address_pools or []:
            backend_count += len(list(pool.backend_ip_configurations or []))
        assets.append(
            Asset(
                provider=Provider.azure,
                service="azure_lb",
                resource_id=lb.id,
                resource_type="load_balancer",
                region=lb.location,
                tags=lb.tags or {},
                metadata={
                    "request_count_30d": 0,
                    "availability_zone_count": az_count,
                    "is_critical": bool(lb.tags and lb.tags.get("criticality", "").lower() in {"high", "critical"}),
                    "backend_count": backend_count,
                },
            )
        )
    return assets


def _collect_identity(self: Any, credential: Any, subscription_id: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        graph_token = credential.get_token("https://graph.microsoft.com/.default").token
    except Exception:
        return assets
    try:
        import httpx
        org = httpx.get(
            "https://graph.microsoft.com/v1.0/organization",
            headers={"Authorization": f"Bearer {graph_token}"},
            timeout=15.0,
        )
        org.raise_for_status()
        orgs = org.json().get("value", [])
        if not orgs:
            return assets
        tenant_id = orgs[0].get("id", "")
        mfa_enforced = False
        try:
            ca = httpx.get(
                "https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies",
                headers={"Authorization": f"Bearer {graph_token}"},
                timeout=15.0,
            )
            if ca.status_code == 200:
                for policy in ca.json().get("value", []):
                    if policy.get("state") == "enabled":
                        controls = str(policy.get("grantControls", {}).get("builtInControls", []))
                        if "mfa" in controls.lower():
                            mfa_enforced = True
                            break
        except Exception:
            pass
        assets.append(
            Asset(
                provider=Provider.azure, service="iam_account",
                resource_id=f"azure-tenant:{tenant_id}", resource_type="tenant",
                region="global",
                metadata={"mfa_enforced": mfa_enforced},
            )
        )
    except Exception:
        pass
    return assets
