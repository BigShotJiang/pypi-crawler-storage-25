# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

import httpx

from hybrisight.models import Asset, Provider


def _collect_advisor_signals(self: Any, credential: Any, subscription_id: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        token = credential.get_token("https://management.azure.com/.default").token
        url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Advisor/recommendations?api-version=2025-01-01"
        resp = httpx.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=20.0)
        resp.raise_for_status()
        items = resp.json().get("value", [])
    except Exception as exc:
        self._set_signal_diag("advisor", "unavailable", str(exc))
        return assets

    counts: dict[str, int] = {"cost": 0, "security": 0}
    for item in items:
        props = item.get("properties", {})
        category = str(props.get("category", "")).strip().lower()
        mapped_category = "cost" if "cost" in category else "security" if "security" in category else ""
        if mapped_category:
            counts[mapped_category] += 1

    for category, count in counts.items():
        if count <= 0:
            continue
        assets.append(
            Asset(
                provider=Provider.azure,
                service="advisor",
                resource_id=f"advisor:{subscription_id}:{category}",
                resource_type="recommendation_summary",
                region="global",
                metadata={"signal_present": True, "recommendation_category": category, "recommendation_count": count},
            )
        )

    if not assets:
        self._set_signal_diag("advisor", "available_no_findings", "No advisor security/cost recommendations found.")
    else:
        self._set_signal_diag("advisor", "collected", f"{sum(counts.values())} advisor recommendations captured.")
    return assets


def _collect_defender_signals(self: Any, credential: Any, subscription_id: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        token = credential.get_token("https://management.azure.com/.default").token
        url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Security/assessments?api-version=2020-01-01"
        resp = httpx.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=20.0)
        resp.raise_for_status()
        items = resp.json().get("value", [])
    except Exception as exc:
        self._set_signal_diag("defender", "unavailable", str(exc))
        return assets

    unhealthy = 0
    for item in items:
        props = item.get("properties", {})
        status = (props.get("status") or {}).get("code", "")
        if str(status).lower() not in {"healthy", "notapplicable"}:
            unhealthy += 1

    if unhealthy > 0:
        assets.append(
            Asset(
                provider=Provider.azure,
                service="defender",
                resource_id=f"defender:{subscription_id}:summary",
                resource_type="assessment_summary",
                region="global",
                metadata={"signal_present": True, "recommendation_category": "security", "recommendation_count": unhealthy},
            )
        )
        self._set_signal_diag("defender", "collected", f"{unhealthy} unhealthy defender assessments captured.")
    else:
        self._set_signal_diag("defender", "available_no_findings", "No unhealthy defender assessments found.")
    return assets


def _collect_cost_management_signals(self: Any, credential: Any, subscription_id: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        token = credential.get_token("https://management.azure.com/.default").token
        url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.CostManagement/query?api-version=2023-03-01"
        body = {
            "type": "ActualCost",
            "timeframe": "MonthToDate",
            "dataset": {"granularity": "None", "aggregation": {"totalCost": {"name": "PreTaxCost", "function": "Sum"}}},
        }
        resp = httpx.post(url, headers={"Authorization": f"Bearer {token}"}, json=body, timeout=20.0)
        resp.raise_for_status()
        payload = resp.json().get("properties", {})
        rows = payload.get("rows", [])
        columns = payload.get("columns", [])
        if not rows:
            self._set_signal_diag("cost_management", "available_no_data", "No cost rows returned.")
            return assets
        idx = 0
        for i, col in enumerate(columns):
            if str(col.get("name", "")).lower() in {"pretaxcost", "cost", "totalcost"}:
                idx = i
                break
        monthly_spend = float(rows[0][idx] or 0.0)
        if monthly_spend <= 0:
            self._set_signal_diag("cost_management", "available_no_data", "Monthly spend reported as zero.")
            return assets
        estimated_annual_optimization = round(monthly_spend * 12 * 0.05, 2)
        assets.append(
            Asset(
                provider=Provider.azure,
                service="costmanagement",
                resource_id=f"costmanagement:{subscription_id}:mtd",
                resource_type="cost_signal",
                region="global",
                metadata={
                    "signal_present": True,
                    "recommendation_category": "cost",
                    "monthly_spend_gbp_proxy": monthly_spend,
                    "estimated_annual_cost_impact_gbp_signal": estimated_annual_optimization,
                },
            )
        )
        self._set_signal_diag("cost_management", "collected", f"Monthly spend signal captured (amount={monthly_spend:.2f}, est_annual_optimization={estimated_annual_optimization:.2f}).")
    except Exception as exc:
        self._set_signal_diag("cost_management", "unavailable", str(exc))
    return assets


def _collect_demo_assets(self: Any) -> list[Asset]:
    return [
        Asset(provider=Provider.azure, service="storage", resource_id="/subscriptions/123/resourceGroups/rg/providers/Microsoft.Storage/storageAccounts/publicblob", resource_type="storage_account", region="uksouth", metadata={"public_access": True, "encrypted": False, "versioning_enabled": False, "lifecycle_policy": False, "redundancy": "lrs", "allocated_gb": 1000, "used_gb": 200}, tags={}),
        Asset(provider=Provider.azure, service="vm", resource_id="/subscriptions/123/resourceGroups/rg/providers/Microsoft.Compute/virtualMachines/vm-prod-01", resource_type="virtual_machine", region="uksouth", metadata={"avg_cpu_utilization_30d": 4.1, "backup_enabled": False, "is_critical": True, "availability_zone_count": 1, "autoscaling_enabled": False}, tags={"environment": "prod"}),
        Asset(provider=Provider.azure, service="network", resource_id="/subscriptions/123/resourceGroups/rg/providers/Microsoft.Network/networkSecurityGroups/nsg-1", resource_type="network_security_group", region="uksouth", metadata={"ingress": [{"cidr": "0.0.0.0/0", "port": 3389}]}, tags={}),
        Asset(provider=Provider.azure, service="disk", resource_id="/subscriptions/123/resourceGroups/rg/providers/Microsoft.Compute/disks/disk-1", resource_type="managed_disk", region="uksouth", metadata={"attached": False, "encrypted": False, "allocated_gb": 512, "used_gb": 50, "backup_enabled": False}, tags={}),
        Asset(provider=Provider.azure, service="azure_lb", resource_id="/subscriptions/123/resourceGroups/rg/providers/Microsoft.Network/loadBalancers/lb-1", resource_type="load_balancer", region="uksouth", metadata={"request_count_30d": 0, "availability_zone_count": 1, "is_critical": True}, tags={}),
        Asset(provider=Provider.azure, service="snapshot", resource_id="/subscriptions/123/resourceGroups/rg/providers/Microsoft.Compute/snapshots/snap-1", resource_type="snapshot", region="uksouth", metadata={"source_volume_exists": False, "encrypted": False, "allocated_gb": 512}, tags={}),
        Asset(provider=Provider.azure, service="iam_account", resource_id="azure-tenant:demo-tenant-id", resource_type="tenant", region="global", metadata={"mfa_enforced": False}),
        Asset(provider=Provider.azure, service="azure_sql", resource_id="/subscriptions/123/resourceGroups/rg/providers/Microsoft.Sql/servers/sql-prod/databases/orders", resource_type="sql_database", region="uksouth", metadata={"backup_enabled": True, "encrypted": True, "allocated_gb": 50, "availability_zone_count": 1, "is_critical": True}, tags={}),
        Asset(provider=Provider.azure, service="azure_monitor", resource_id="activity-log:123", resource_type="activity_log_summary", region="global", metadata={"has_activity_events": True, "diagnostic_setting_count": 2, "activity_alert_count": 3}, tags={}),
    ]
