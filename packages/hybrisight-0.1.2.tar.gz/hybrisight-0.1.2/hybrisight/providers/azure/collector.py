# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from hybrisight.models import Asset
from hybrisight.providers.base import BaseCollector
from hybrisight.providers.errors import CollectorError
from hybrisight.providers.azure.collector_azure_extras import (
    _collect_activity_log_assets,
    _collect_sql_assets,
)
from hybrisight.providers.azure.collector_inventory import (
    _collect_generic_resources,
    _collect_identity,
    _collect_network_assets,
    _collect_storage_assets,
    _collect_vm_assets,
)
from hybrisight.providers.azure.collector_signals import (
    _collect_advisor_signals,
    _collect_cost_management_signals,
    _collect_defender_signals,
    _collect_demo_assets,
)


class AzureCollector(BaseCollector):
    _collect_generic_resources = _collect_generic_resources
    _collect_storage_assets = _collect_storage_assets
    _collect_vm_assets = _collect_vm_assets
    _collect_network_assets = _collect_network_assets
    _collect_identity = _collect_identity
    _collect_sql_assets = _collect_sql_assets
    _collect_activity_log_assets = _collect_activity_log_assets
    _collect_advisor_signals = _collect_advisor_signals
    _collect_defender_signals = _collect_defender_signals
    _collect_cost_management_signals = _collect_cost_management_signals
    _collect_demo_assets = _collect_demo_assets

    def __init__(self, tenant: str | None = None, subscription_id: str | None = None, demo: bool = False):
        self.tenant = tenant
        self.subscription_id = subscription_id
        self.demo = demo
        self.collection_diagnostics: dict[str, object] = {
            "provider": "azure",
            "signals": {
                "advisor": {"status": "unknown", "detail": ""},
                "defender": {"status": "unknown", "detail": ""},
                "cost_management": {"status": "unknown", "detail": ""},
            },
        }

    def _set_signal_diag(self, key: str, status: str, detail: str = "") -> None:
        signals = self.collection_diagnostics.setdefault("signals", {})
        if isinstance(signals, dict):
            signals[key] = {"status": status, "detail": detail}

    def collect(self) -> list[Asset]:
        if self.demo:
            self._set_signal_diag("advisor", "demo_mode", "Demo data path; API signals not queried.")
            self._set_signal_diag("defender", "demo_mode", "Demo data path; API signals not queried.")
            self._set_signal_diag("cost_management", "demo_mode", "Demo data path; API signals not queried.")
            return self._collect_demo_assets()

        try:
            from azure.identity import DefaultAzureCredential
            from azure.mgmt.compute import ComputeManagementClient
            from azure.mgmt.network import NetworkManagementClient
            from azure.mgmt.resource import ResourceManagementClient
            from azure.mgmt.storage import StorageManagementClient
            from azure.mgmt.subscription import SubscriptionClient
        except ImportError as exc:
            raise CollectorError("Azure dependencies missing. Install project dependencies first.") from exc

        credential = DefaultAzureCredential(exclude_interactive_browser_credential=False)
        subscription_id = self.subscription_id
        try:
            if not subscription_id:
                subscriptions = list(SubscriptionClient(credential).subscriptions.list())
                if not subscriptions:
                    raise CollectorError("No Azure subscriptions available for current credentials.")
                subscription_id = subscriptions[0].subscription_id
        except Exception as exc:
            raise CollectorError(f"Azure authentication failed: {exc}") from exc

        resources = ResourceManagementClient(credential, subscription_id)
        storage_client = StorageManagementClient(credential, subscription_id)
        compute_client = ComputeManagementClient(credential, subscription_id)
        network_client = NetworkManagementClient(credential, subscription_id)

        assets: list[Asset] = []
        assets.extend(self._collect_generic_resources(resources))
        assets.extend(self._collect_storage_assets(storage_client))
        assets.extend(self._collect_identity(credential, subscription_id))
        assets.extend(self._collect_sql_assets(credential, subscription_id))
        assets.extend(self._collect_activity_log_assets(credential, subscription_id))
        assets.extend(self._collect_vm_assets(compute_client, credential=credential, subscription_id=subscription_id))
        assets.extend(self._collect_network_assets(network_client))
        assets.extend(self._collect_cost_management_signals(credential, subscription_id))
        assets.extend(self._collect_advisor_signals(credential, subscription_id))
        assets.extend(self._collect_defender_signals(credential, subscription_id))
        return assets
