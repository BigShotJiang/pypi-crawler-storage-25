# SPDX-License-Identifier: Apache-2.0
class CollectorError(RuntimeError):
    """Raised when a provider collector cannot run with the current environment."""
