# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from abc import ABC, abstractmethod

from hybrisight.models import Asset


class BaseCollector(ABC):
    collection_diagnostics: dict[str, object]

    @abstractmethod
    def collect(self) -> list[Asset]:
        """Collect read-only metadata and normalize into assets."""

    def get_collection_diagnostics(self) -> dict[str, object]:
        return getattr(self, "collection_diagnostics", {})
