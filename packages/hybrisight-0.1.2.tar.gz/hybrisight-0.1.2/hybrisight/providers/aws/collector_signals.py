# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

from hybrisight.models import Asset, Provider


def _collect_trusted_advisor_signals(self: Any, session: Any, account_id: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        support = session.client("support", region_name="us-east-1")
        checks = support.describe_trusted_advisor_checks(language="en").get("checks", [])
    except Exception as exc:
        self._set_signal_diag("trusted_advisor", "unavailable", str(exc))
        return assets

    counts: dict[str, int] = {"security": 0, "cost": 0}
    for check in checks:
        try:
            cid = check.get("id")
            if not cid:
                continue
            result = support.describe_trusted_advisor_check_result(checkId=cid, language="en").get("result", {})
            status = str(result.get("status", "")).lower()
            if status in {"ok", "not_available"}:
                continue
            category = str(check.get("category", "security")).lower()
            if category not in {"security", "cost"}:
                continue
            counts[category] += 1
        except Exception:
            continue
    for category, count in counts.items():
        if count <= 0:
            continue
        assets.append(
            Asset(
                provider=Provider.aws,
                service="trustedadvisor",
                resource_id=f"trustedadvisor:{account_id}:{category}",
                resource_type="recommendation_summary",
                region="global",
                metadata={
                    "signal_present": True,
                    "recommendation_category": category,
                    "recommendation_count": count,
                    "account_id": account_id,
                },
            )
        )
    if not assets:
        self._set_signal_diag("trusted_advisor", "available_no_findings", "No open security/cost recommendations found.")
    else:
        total = sum(counts.values())
        self._set_signal_diag("trusted_advisor", "collected", f"{total} open recommendation signals captured.")
    return assets


def _collect_guardduty_signals(self: Any, session: Any, account_id: str) -> list[Asset]:
    assets: list[Asset] = []
    detector_seen = False
    for region in self.regions:
        try:
            gd = session.client("guardduty", region_name=region)
            detectors = gd.list_detectors().get("DetectorIds", [])
        except Exception as exc:
            self._set_signal_diag("guardduty", "unavailable", str(exc))
            continue
        detector_seen = detector_seen or bool(detectors)
        for detector_id in detectors:
            try:
                finding_ids = gd.list_findings(
                    DetectorId=detector_id,
                    FindingCriteria={"Criterion": {"severity": {"Gte": 4.0}}},
                    MaxResults=20,
                ).get("FindingIds", [])
                if not finding_ids:
                    continue
                assets.append(
                    Asset(
                        provider=Provider.aws,
                        service="guardduty",
                        resource_id=f"guardduty:{account_id}:{region}",
                        resource_type="finding_summary",
                        region=region,
                        metadata={
                            "signal_present": True,
                            "recommendation_category": "security",
                            "finding_count": len(finding_ids),
                            "account_id": account_id,
                        },
                    )
                )
            except Exception:
                continue
    if not detector_seen:
        self._set_signal_diag("guardduty", "not_enabled_or_no_detectors", "No GuardDuty detectors returned.")
    elif not assets:
        self._set_signal_diag("guardduty", "available_no_findings", "No medium/high GuardDuty findings returned.")
    else:
        total = sum(int(a.metadata.get("finding_count", 0)) for a in assets)
        self._set_signal_diag("guardduty", "collected", f"{total} GuardDuty findings captured.")
    return assets


def _collect_cost_explorer_signals(self: Any, session: Any, account_id: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        ce = session.client("ce", region_name="us-east-1")
        end_date = datetime.now(UTC).date()
        start_date = end_date - timedelta(days=30)
        res = ce.get_cost_and_usage(
            TimePeriod={"Start": start_date.isoformat(), "End": end_date.isoformat()},
            Granularity="MONTHLY",
            Metrics=["UnblendedCost"],
        )
        by_time = res.get("ResultsByTime", [])
        if not by_time:
            self._set_signal_diag("cost_explorer", "available_no_data", "No cost rows returned.")
            return assets
        monthly_spend = float(by_time[0].get("Total", {}).get("UnblendedCost", {}).get("Amount", "0") or 0.0)
        if monthly_spend <= 0:
            self._set_signal_diag("cost_explorer", "available_no_data", "Monthly spend reported as zero.")
            return assets
        estimated_annual_optimization = round(monthly_spend * 12 * 0.05, 2)
        assets.append(
            Asset(
                provider=Provider.aws,
                service="costexplorer",
                resource_id=f"costexplorer:{account_id}:mtd",
                resource_type="cost_signal",
                region="global",
                metadata={
                    "signal_present": True,
                    "recommendation_category": "cost",
                    "monthly_spend_gbp_proxy": monthly_spend,
                    "estimated_annual_cost_impact_gbp_signal": estimated_annual_optimization,
                },
            )
        )
        self._set_signal_diag("cost_explorer", "collected", f"Monthly spend signal captured (amount={monthly_spend:.2f}, est_annual_optimization={estimated_annual_optimization:.2f}).")
    except Exception as exc:
        self._set_signal_diag("cost_explorer", "unavailable", str(exc))
    return assets


def _collect_demo_assets(self: Any) -> list[Asset]:
    self._set_signal_diag("cloudwatch_ec2_cpu", "demo_mode", "Demo data path; CloudWatch API not queried.")
    self._set_signal_diag("cost_explorer", "demo_mode", "Demo data path; Cost Explorer API not queried.")
    self._set_signal_diag("network_posture", "demo_mode", "Demo data path; EC2 VPC APIs not queried.")
    return [
        Asset(provider=Provider.aws, service="iam_account", resource_id="arn:aws:iam::123456789012:account", resource_type="account", metadata={"mfa_enforced": False}),
        Asset(provider=Provider.aws, service="iam", resource_id="arn:aws:iam::123456789012:role/AdminWildcard", resource_type="role", tags={"environment": "prod"}, metadata={"actions": ["*"], "resources": ["*"], "is_admin_role": True}),
        Asset(provider=Provider.aws, service="s3", resource_id="arn:aws:s3:::hybrisight-public-data", resource_type="bucket", metadata={"public_access": True, "encrypted": False, "versioning_enabled": False, "lifecycle_policy": False, "redundancy": "single-az"}),
        Asset(provider=Provider.aws, service="ec2", resource_id="i-09abc123", resource_type="instance", region="eu-west-2", tags={"environment": "prod"}, metadata={"avg_cpu_utilization_30d": 3.2, "backup_enabled": False, "is_critical": True, "availability_zone_count": 1, "autoscaling_enabled": False}),
        Asset(provider=Provider.aws, service="network", resource_id="sg-123456", resource_type="security_group", region="eu-west-2", metadata={"ingress": [{"cidr": "0.0.0.0/0", "port": 22}, {"cidr": "0.0.0.0/0", "port": 443}]},),
        Asset(provider=Provider.aws, service="network", resource_id="network-posture:123456789012:eu-west-2", resource_type="network_posture_summary", region="eu-west-2", metadata={"default_vpc_present": True, "dedicated_workload_vpc_present": False, "subnet_tier_count": 0, "app_data_az_count": 0, "managed_egress_path_defined": False, "landing_zone_ready": False}),
        Asset(provider=Provider.aws, service="ebs", resource_id="vol-123", resource_type="volume", region="eu-west-2", tags={}, metadata={"attached": False, "encrypted": False, "allocated_gb": 500, "used_gb": 80, "backup_enabled": False}),
        Asset(provider=Provider.aws, service="snapshot", resource_id="snap-123", resource_type="snapshot", region="eu-west-2", metadata={"source_volume_exists": False, "encrypted": False, "lifecycle_policy": False}),
        Asset(provider=Provider.aws, service="elb", resource_id="arn:aws:elasticloadbalancing:eu-west-2:123:loadbalancer/app/lb1/123", resource_type="application", region="eu-west-2", metadata={"request_count_30d": 0, "availability_zone_count": 1, "is_critical": True}),
        Asset(provider=Provider.aws, service="kms", resource_id="arn:aws:kms:eu-west-2:123:key/mrk-1", resource_type="key", region="eu-west-2", metadata={"key_rotation_enabled": False, "key_manager": "CUSTOMER", "key_state": "Enabled"}),
        Asset(provider=Provider.aws, service="log_group", resource_id="/aws/lambda/hybrisight-processor", resource_type="log_group", region="eu-west-2", metadata={"encrypted": False, "retention_in_days": None, "subscription_filter_count": 0, "stored_bytes": 1048576}),
        Asset(provider=Provider.aws, service="ecs", resource_id="arn:aws:ecs:eu-west-2:123:cluster/hybrisight-cluster", resource_type="cluster", region="eu-west-2", metadata={"status": "ACTIVE", "running_tasks_count": 0, "active_services_count": 0}),
        Asset(provider=Provider.aws, service="eks", resource_id="arn:aws:eks:eu-west-2:123:cluster/hybrisight-eks", resource_type="cluster", region="eu-west-2", metadata={"status": "ACTIVE", "endpoint_public_access": True, "version": "1.28"}),
    ]
