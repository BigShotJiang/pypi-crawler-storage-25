# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

from hybrisight.models import Asset, Provider


def _collect_cloudtrail(self: Any, session: Any, account_id: str, region: str) -> list[Asset]:
    assets: list[Asset] = []
    try:
        ct = session.client("cloudtrail", region_name=region)
        trails = ct.describe_trails().get("trailList", [])
        if not trails:
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="cloudtrail",
                    resource_id=f"arn:aws:cloudtrail::{account_id}:trail/none",
                    resource_type="trail",
                    metadata={
                        "trail_exists": False,
                        "region": region,
                    },
                )
            )
            return assets
        for trail in trails:
            status = ct.get_trail_status(Name=trail["TrailARN"])
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="cloudtrail",
                    resource_id=trail["TrailARN"],
                    resource_type="trail",
                    metadata={
                        "trail_exists": True,
                        "is_multi_region": trail.get("IsMultiRegionTrail", False),
                        "log_file_validation_enabled": trail.get("LogFileValidationEnabled", False),
                        "cloudwatch_logs_log_group_arn": trail.get("CloudWatchLogsLogGroupArn", "") or "",
                        "is_logging": status.get("IsLogging", False),
                        "latest_delivery_time": str(status.get("LatestDeliveryTime", "") or ""),
                        "region": region,
                    },
                )
            )
    except Exception:
        pass
    return assets
