# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

from hybrisight.models import Asset, Provider


def _discover_enabled_regions(self: Any, session: Any) -> list[str]:
    try:
        ec2 = session.client("ec2", region_name="us-east-1")
        rows = ec2.describe_regions(AllRegions=False).get("Regions", [])
        return sorted({str(row.get("RegionName", "")).strip() for row in rows if str(row.get("RegionName", "")).strip()})
    except Exception:
        return []


def _collect_iam(self: Any, session: Any, account_id: str) -> list[Asset]:
    iam = session.client("iam")
    assets: list[Asset] = []

    try:
        summary = iam.get_account_summary().get("SummaryMap", {})
        mfa_enabled = summary.get("AccountMFAEnabled", 0) == 1
        root_keys = summary.get("AccountAccessKeysPresent", 0) == 1
        iam_users = int(summary.get("Users", 0))
        iam_users_mfa = int(summary.get("UsersMFA", 0))
        assets.append(
            Asset(
                provider=Provider.aws,
                service="iam_account",
                resource_id=f"arn:aws:iam::{account_id}:account",
                resource_type="account",
                metadata={
                    "mfa_enforced": mfa_enabled,
                    "root_access_keys_present": root_keys,
                    "iam_users": iam_users,
                    "iam_users_mfa": iam_users_mfa,
                },
            )
        )
    except Exception:
        pass

    try:
        pw_policy = iam.get_account_password_policy().get("PasswordPolicy", {})
        assets.append(
            Asset(
                provider=Provider.aws,
                service="iam_password_policy",
                resource_id=f"arn:aws:iam::{account_id}:password-policy",
                resource_type="password_policy",
                metadata={
                    "minimum_password_length": pw_policy.get("MinimumPasswordLength", 0),
                    "require_symbols": pw_policy.get("RequireSymbols", False),
                    "require_numbers": pw_policy.get("RequireNumbers", False),
                    "require_uppercase": pw_policy.get("RequireUppercaseCharacters", False),
                    "require_lowercase": pw_policy.get("RequireLowercaseCharacters", False),
                    "max_password_age_days": pw_policy.get("MaxPasswordAge", 0),
                    "password_reuse_prevention": pw_policy.get("PasswordReusePrevention", 0),
                    "allow_users_to_change": pw_policy.get("AllowUsersToChangePassword", False),
                },
            )
        )
    except Exception:
        pass

    paginator = iam.get_paginator("list_roles")
    for page in paginator.paginate():
        for role in page.get("Roles", []):
            role_name = role["RoleName"]
            actions, resources, is_admin = self._extract_role_permissions(iam, role_name)
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="iam",
                    resource_id=role["Arn"],
                    resource_type="role",
                    tags={tag["Key"]: tag["Value"] for tag in role.get("Tags", [])},
                    metadata={"actions": sorted(actions), "resources": sorted(resources), "is_admin_role": is_admin},
                )
            )

    return assets


def _extract_role_permissions(self: Any, iam: Any, role_name: str) -> tuple[set[str], set[str], bool]:
    actions: set[str] = set()
    resources: set[str] = set()
    is_admin = False

    try:
        attached = iam.list_attached_role_policies(RoleName=role_name).get("AttachedPolicies", [])
        for p in attached:
            policy_arn = p["PolicyArn"]
            if policy_arn.endswith("AdministratorAccess"):
                is_admin = True
            try:
                policy = iam.get_policy(PolicyArn=policy_arn)["Policy"]
                version_id = policy["DefaultVersionId"]
                document = iam.get_policy_version(PolicyArn=policy_arn, VersionId=version_id)["PolicyVersion"]["Document"]
                self._extract_statement_permissions(document, actions, resources)
            except Exception:
                continue

        inline = iam.list_role_policies(RoleName=role_name).get("PolicyNames", [])
        for inline_name in inline:
            try:
                inline_doc = iam.get_role_policy(RoleName=role_name, PolicyName=inline_name)["PolicyDocument"]
                self._extract_statement_permissions(inline_doc, actions, resources)
            except Exception:
                continue
    except Exception:
        pass

    return actions, resources, is_admin


def _extract_statement_permissions(self: Any, policy_doc: dict[str, Any], actions: set[str], resources: set[str]) -> None:
    statements = policy_doc.get("Statement", [])
    if isinstance(statements, dict):
        statements = [statements]
    for stmt in statements:
        if stmt.get("Effect") != "Allow":
            continue
        action = stmt.get("Action", [])
        resource = stmt.get("Resource", [])
        if isinstance(action, str):
            action = [action]
        if isinstance(resource, str):
            resource = [resource]
        actions.update(action)
        resources.update(resource)


def _collect_s3(self: Any, session: Any) -> list[Asset]:
    s3 = session.client("s3")
    assets: list[Asset] = []

    try:
        buckets = s3.list_buckets().get("Buckets", [])
    except Exception:
        return assets

    for bucket in buckets:
        name = bucket["Name"]
        public_access = False
        encryption = True
        versioning = False
        lifecycle = False

        try:
            pab = s3.get_public_access_block(Bucket=name)["PublicAccessBlockConfiguration"]
            public_access = not all(
                [
                    pab.get("BlockPublicAcls", False),
                    pab.get("IgnorePublicAcls", False),
                    pab.get("BlockPublicPolicy", False),
                    pab.get("RestrictPublicBuckets", False),
                ]
            )
        except Exception:
            public_access = True

        try:
            s3.get_bucket_encryption(Bucket=name)
            encryption = True
        except Exception:
            encryption = False

        try:
            status = s3.get_bucket_versioning(Bucket=name).get("Status")
            versioning = status == "Enabled"
        except Exception:
            versioning = False

        try:
            s3.get_bucket_lifecycle_configuration(Bucket=name)
            lifecycle = True
        except Exception:
            lifecycle = False

        try:
            loc = s3.get_bucket_location(Bucket=name).get("LocationConstraint") or "us-east-1"
        except Exception:
            loc = None

        assets.append(
            Asset(
                provider=Provider.aws,
                service="s3",
                resource_id=f"arn:aws:s3:::{name}",
                resource_type="bucket",
                region=loc,
                metadata={
                    "public_access": public_access,
                    "encrypted": encryption,
                    "versioning_enabled": versioning,
                    "lifecycle_policy": lifecycle,
                    "redundancy": "multi-az",
                },
            )
        )

    return assets
