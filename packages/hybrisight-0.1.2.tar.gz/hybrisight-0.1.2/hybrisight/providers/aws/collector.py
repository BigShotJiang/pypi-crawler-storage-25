# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed

from hybrisight.models import Asset
from hybrisight.providers.base import BaseCollector
from hybrisight.providers.errors import CollectorError
from hybrisight.providers.aws.collector_cloudtrail import _collect_cloudtrail
from hybrisight.providers.aws.collector_cloudwatch import _collect_cloudwatch_alarms
from hybrisight.providers.aws.collector_inventory import (
    _collect_iam,
    _collect_s3,
    _discover_enabled_regions,
    _extract_role_permissions,
    _extract_statement_permissions,
)
from hybrisight.providers.aws.collector_network import _collect_network_posture_signals
from hybrisight.providers.aws.collector_region import _collect_region_assets
from hybrisight.providers.aws.collector_signals import (
    _collect_cost_explorer_signals,
    _collect_demo_assets,
    _collect_guardduty_signals,
    _collect_trusted_advisor_signals,
)


class AwsCollector(BaseCollector):
    _discover_enabled_regions = _discover_enabled_regions
    _collect_iam = _collect_iam
    _extract_role_permissions = _extract_role_permissions
    _extract_statement_permissions = _extract_statement_permissions
    _collect_s3 = _collect_s3
    _collect_network_posture_signals = _collect_network_posture_signals
    _collect_region_assets = _collect_region_assets
    _collect_trusted_advisor_signals = _collect_trusted_advisor_signals
    _collect_guardduty_signals = _collect_guardduty_signals
    _collect_cost_explorer_signals = _collect_cost_explorer_signals
    _collect_demo_assets = _collect_demo_assets
    _collect_cloudtrail = _collect_cloudtrail
    _collect_cloudwatch_alarms = _collect_cloudwatch_alarms

    def __init__(self, profile: str | None = None, regions: list[str] | None = None, demo: bool = False):
        self.profile = profile
        self.regions = [r.strip() for r in (regions or []) if r and r.strip()]
        self.demo = demo
        self.collection_diagnostics: dict[str, object] = {
            "provider": "aws",
            "signals": {
                "trusted_advisor": {"status": "unknown", "detail": ""},
                "guardduty": {"status": "unknown", "detail": ""},
                "cloudwatch_ec2_cpu": {"status": "unknown", "detail": ""},
                "cost_explorer": {"status": "unknown", "detail": ""},
                "network_posture": {"status": "unknown", "detail": ""},
            },
        }

    def _set_signal_diag(self, key: str, status: str, detail: str = "") -> None:
        signals = self.collection_diagnostics.setdefault("signals", {})
        if isinstance(signals, dict):
            signals[key] = {"status": status, "detail": detail}

    def collect(self) -> list[Asset]:
        if self.demo:
            self._set_signal_diag("trusted_advisor", "demo_mode", "Demo data path; API signals not queried.")
            self._set_signal_diag("guardduty", "demo_mode", "Demo data path; API signals not queried.")
            return self._collect_demo_assets()

        try:
            import boto3
            from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError
        except ImportError as exc:
            raise CollectorError("AWS dependencies missing. Install project dependencies first.") from exc

        try:
            session = boto3.Session(profile_name=self.profile) if self.profile else boto3.Session()
            account_id = session.client("sts").get_caller_identity()["Account"]
        except NoCredentialsError as exc:
            raise CollectorError("AWS credentials not found. Configure profile or env credentials.") from exc
        except (BotoCoreError, ClientError) as exc:
            raise CollectorError(f"AWS authentication failed: {exc}") from exc

        assets: list[Asset] = []
        cpu_metric_collected_total = 0
        cpu_metric_errors_total = 0
        regions_with_no_instances: list[str] = []

        if not self.regions:
            self.regions = self._discover_enabled_regions(session)
        if not self.regions:
            self.regions = ["us-east-1"]

        self.collection_diagnostics["regions_scanned"] = self.regions
        assets.extend(self._collect_iam(session, account_id))
        assets.extend(self._collect_s3(session))

        with ThreadPoolExecutor(max_workers=min(len(self.regions), 8)) as executor:
            future_map = {executor.submit(self._collect_region_assets, session, region): region for region in self.regions}
            for future in as_completed(future_map):
                region = future_map[future]
                try:
                    region_assets, cpu_collected, cpu_errors, had_instances = future.result()
                    assets.extend(region_assets)
                    cpu_metric_collected_total += cpu_collected
                    cpu_metric_errors_total += cpu_errors
                    if not had_instances:
                        regions_with_no_instances.append(region)
                except Exception:
                    cpu_metric_errors_total += 1

        if cpu_metric_collected_total > 0:
            self._set_signal_diag("cloudwatch_ec2_cpu", "collected", f"CPU metrics captured for {cpu_metric_collected_total} instance(s) across {len(self.regions)} region(s).")
        elif cpu_metric_errors_total > 0:
            self._set_signal_diag("cloudwatch_ec2_cpu", "unavailable", "Unable to read CloudWatch EC2 CPU metrics for one or more instances.")
        else:
            region_hint = ", ".join(regions_with_no_instances[:3]) if regions_with_no_instances else "selected regions"
            if len(regions_with_no_instances) > 3:
                region_hint = f"{region_hint}, ..."
            self._set_signal_diag("cloudwatch_ec2_cpu", "available_no_instances", f"No EC2 instances found for CPU metric collection across scanned regions ({region_hint}).")

        assets.extend(self._collect_cost_explorer_signals(session, account_id))
        assets.extend(self._collect_trusted_advisor_signals(session, account_id))
        assets.extend(self._collect_guardduty_signals(session, account_id))
        assets.extend(self._collect_network_posture_signals(session, account_id))
        primary_region = self.regions[0] if self.regions else "us-east-1"
        assets.extend(self._collect_cloudtrail(session, account_id, primary_region))
        for region in self.regions:
            assets.extend(self._collect_cloudwatch_alarms(session, account_id, region))
        return assets
