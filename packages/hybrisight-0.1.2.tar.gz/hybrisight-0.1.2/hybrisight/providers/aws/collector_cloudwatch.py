# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

from hybrisight.models import Asset, Provider


def _collect_cloudwatch_alarms(self: Any, session: Any, account_id: str, region: str) -> list[Asset]:
    try:
        cw = session.client("cloudwatch", region_name=region)
        alarms = cw.describe_alarms(MaxRecords=1).get("MetricAlarms", [])
        return [
            Asset(
                provider=Provider.aws,
                service="cloudwatch",
                resource_id=f"arn:aws:cloudwatch:{region}:{account_id}:alarms",
                resource_type="alarm_summary",
                region=region,
                metadata={"alarms_configured": len(alarms) > 0},
            )
        ]
    except Exception:
        return []
