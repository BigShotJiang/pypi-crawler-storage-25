# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

from hybrisight.models import Asset, Provider


def _collect_region_assets(self: Any, session: Any, region: str) -> tuple[list[Asset], int, int, bool]:
    ec2 = session.client("ec2", region_name=region)
    cloudwatch = session.client("cloudwatch", region_name=region)
    autoscaling = session.client("autoscaling", region_name=region)
    assets: list[Asset] = []
    cpu_metric_errors = 0
    cpu_metric_collected = 0
    instance_count = 0

    asg_instance_ids: set[str] = set()
    try:
        asg_response = autoscaling.describe_auto_scaling_groups()
        for asg in asg_response.get("AutoScalingGroups", []):
            for inst in asg.get("Instances", []):
                iid = inst.get("InstanceId")
                if iid:
                    asg_instance_ids.add(iid)
    except Exception:
        pass

    try:
        response = ec2.describe_instances()
    except Exception:
        response = {"Reservations": []}

    for reservation in response.get("Reservations", []):
        for instance in reservation.get("Instances", []):
            instance_id = instance["InstanceId"]
            instance_count += 1
            tags = {t["Key"]: t["Value"] for t in instance.get("Tags", [])}
            az = instance.get("Placement", {}).get("AvailabilityZone", "")
            avg_cpu = None
            try:
                stats = cloudwatch.get_metric_statistics(
                    Namespace="AWS/EC2",
                    MetricName="CPUUtilization",
                    Dimensions=[{"Name": "InstanceId", "Value": instance_id}],
                    StartTime=datetime.now(UTC).replace(microsecond=0) - timedelta(days=30),
                    EndTime=datetime.now(UTC).replace(microsecond=0),
                    Period=86400,
                    Statistics=["Average"],
                )
                datapoints = stats.get("Datapoints", [])
                if datapoints:
                    avg_cpu = sum(float(dp.get("Average", 0.0)) for dp in datapoints) / len(datapoints)
                    cpu_metric_collected += 1
            except Exception:
                cpu_metric_errors += 1
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="ec2",
                    resource_id=instance_id,
                    resource_type="instance",
                    region=region,
                    tags=tags,
                    metadata={
                        "avg_cpu_utilization_30d": avg_cpu,
                        "backup_enabled": bool(tags.get("backup", "").lower() in {"true", "yes", "1"}),
                        "is_critical": tags.get("criticality", "").lower() in {"high", "critical"},
                        "availability_zone_count": 1 if az else 0,
                        "autoscaling_enabled": instance_id in asg_instance_ids,
                    },
                )
            )

    try:
        sgs = ec2.describe_security_groups().get("SecurityGroups", [])
        for sg in sgs:
            ingress = []
            for perm in sg.get("IpPermissions", []):
                port = perm.get("FromPort", -1)
                for ip in perm.get("IpRanges", []):
                    ingress.append({"cidr": ip.get("CidrIp"), "port": port})
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="network",
                    resource_id=sg["GroupId"],
                    resource_type="security_group",
                    region=region,
                    tags={t["Key"]: t["Value"] for t in sg.get("Tags", [])} if sg.get("Tags") else {},
                    metadata={"ingress": ingress},
                )
            )
    except Exception:
        pass

    try:
        for acl in ec2.describe_network_acls().get("NetworkAcls", []):
            acl_id = acl["NetworkAclId"]
            acl_tags = {t["Key"]: t["Value"] for t in acl.get("Tags", [])} if acl.get("Tags") else {}
            default_vpc = bool(acl.get("IsDefault", False))
            entries = []
            for entry in acl.get("Entries", []):
                entries.append({
                    "rule_number": entry.get("RuleNumber"),
                    "protocol": entry.get("Protocol", "-1"),
                    "action": entry.get("RuleAction"),
                    "cidr": entry.get("CidrBlock") or entry.get("Ipv6CidrBlock", ""),
                    "egress": bool(entry.get("Egress", False)),
                    "port_range": {"from": entry.get("PortRange", {}).get("From"), "to": entry.get("PortRange", {}).get("To")} if entry.get("PortRange") else None,
                })
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="nacl",
                    resource_id=acl_id,
                    resource_type="network_acl",
                    region=region,
                    tags=acl_tags,
                    metadata={"is_default": default_vpc, "entries": entries},
                )
            )
    except Exception:
        pass

    try:
        volumes = ec2.describe_volumes().get("Volumes", [])
        for vol in volumes:
            attachments = vol.get("Attachments", [])
            size = int(vol.get("Size", 0))
            tags = {t["Key"]: t["Value"] for t in vol.get("Tags", [])} if vol.get("Tags") else {}
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="ebs",
                    resource_id=vol["VolumeId"],
                    resource_type="volume",
                    region=region,
                    tags=tags,
                    metadata={
                        "attached": len(attachments) > 0,
                        "encrypted": bool(vol.get("Encrypted", False)),
                        "allocated_gb": size,
                        "used_gb": size,
                        "backup_enabled": bool(tags.get("backup", "").lower() in {"true", "yes", "1"}),
                    },
                )
            )
    except Exception:
        pass

    try:
        snapshots = ec2.describe_snapshots(OwnerIds=["self"]).get("Snapshots", [])
        active_volumes = {a.resource_id for a in assets if a.service == "ebs"}
        now = datetime.now(UTC)
        for snap in snapshots:
            volume_id = snap.get("VolumeId")
            start = snap.get("StartTime")
            age_days = (now - start).days if start else 0
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="snapshot",
                    resource_id=snap["SnapshotId"],
                    resource_type="snapshot",
                    region=region,
                    metadata={
                        "source_volume_exists": volume_id in active_volumes,
                        "encrypted": bool(snap.get("Encrypted", False)),
                        "lifecycle_policy": age_days <= 90,
                    },
                )
            )
    except Exception:
        pass

    try:
        elbv2 = session.client("elbv2", region_name=region)
        for lb in elbv2.describe_load_balancers().get("LoadBalancers", []):
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="elb",
                    resource_id=lb["LoadBalancerArn"],
                    resource_type=lb.get("Type", "application"),
                    region=region,
                    metadata={"request_count_30d": 1, "availability_zone_count": len(lb.get("AvailabilityZones", [])), "is_critical": True},
                )
            )
    except Exception:
        pass

    try:
        rds = session.client("rds", region_name=region)
        for db in rds.describe_db_instances().get("DBInstances", []):
            db_id = db["DBInstanceIdentifier"]
            tags_list = db.get("TagList", [])
            rds_tags = {t["Key"]: t["Value"] for t in tags_list} if tags_list else {}
            multi_az = bool(db.get("MultiAZ", False))
            assets.append(
                Asset(
                    provider=Provider.aws,
                    service="rds",
                    resource_id=db_id,
                    resource_type="db_instance",
                    region=region,
                    tags=rds_tags,
                    metadata={
                        "backup_enabled": int(db.get("BackupRetentionPeriod", 0)) > 0,
                        "encrypted": bool(db.get("StorageEncrypted", False)),
                        "allocated_gb": int(db.get("AllocatedStorage", 0)),
                        "availability_zone_count": 2 if multi_az else 1,
                        "is_critical": rds_tags.get("criticality", "").lower() in {"high", "critical"},
                        "engine": db.get("Engine", ""),
                    },
                )
            )
    except Exception:
        pass

    try:
        kms = session.client("kms", region_name=region)
        for key in kms.list_keys().get("Keys", []):
            desc = kms.describe_key(KeyId=key["KeyId"])["KeyMetadata"]
            if desc.get("KeyManager") == "AWS":
                rotation = True
            else:
                rotation = kms.get_key_rotation_status(KeyId=key["KeyId"]).get("KeyRotationEnabled", False)
            assets.append(
                Asset(
                    provider=Provider.aws, service="kms", resource_id=desc["Arn"],
                    resource_type="key", region=region,
                    metadata={
                        "key_rotation_enabled": bool(rotation),
                        "key_manager": desc.get("KeyManager", ""),
                        "key_state": desc.get("KeyState", ""),
                    },
                )
            )
    except Exception:
        pass

    try:
        logs = session.client("logs", region_name=region)
        for lg in logs.describe_log_groups().get("logGroups", []):
            subs = logs.describe_subscription_filters(logGroupName=lg["logGroupName"])
            assets.append(
                Asset(
                    provider=Provider.aws, service="log_group", resource_id=lg["logGroupName"],
                    resource_type="log_group", region=region,
                    metadata={
                        "encrypted": bool(lg.get("kmsKeyId")),
                        "retention_in_days": lg.get("retentionInDays"),
                        "subscription_filter_count": len(subs.get("subscriptionFilters", [])),
                        "stored_bytes": lg.get("storedBytes", 0),
                    },
                )
            )
    except Exception:
        pass

    try:
        ecs = session.client("ecs", region_name=region)
        for cluster_arn in ecs.list_clusters().get("clusterArns", []):
            cluster = ecs.describe_clusters(clusters=[cluster_arn])["clusters"][0]
            assets.append(
                Asset(
                    provider=Provider.aws, service="ecs", resource_id=cluster_arn,
                    resource_type="cluster", region=region,
                    metadata={
                        "status": cluster.get("status", ""),
                        "running_tasks_count": cluster.get("runningTasksCount", 0),
                        "active_services_count": cluster.get("activeServicesCount", 0),
                    },
                )
            )
    except Exception:
        pass

    try:
        eks = session.client("eks", region_name=region)
        for name in eks.list_clusters().get("clusters", []):
            cluster = eks.describe_cluster(name=name)["cluster"]
            assets.append(
                Asset(
                    provider=Provider.aws, service="eks", resource_id=cluster["arn"],
                    resource_type="cluster", region=region,
                    metadata={
                        "status": cluster.get("status", ""),
                        "endpoint_public_access": cluster.get("resourcesVpcConfig", {}).get("endpointPublicAccess", True),
                        "version": cluster.get("version", ""),
                    },
                )
            )
    except Exception:
        pass

    return assets, cpu_metric_collected, cpu_metric_errors, instance_count > 0
