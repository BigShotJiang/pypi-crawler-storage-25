# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from typing import Any

from hybrisight.models import Asset, Provider


def _normalize_tag_map(tags: Iterable[dict[str, Any]] | None) -> dict[str, str]:
    tag_map: dict[str, str] = {}
    for tag in tags or []:
        key = str(tag.get("Key") or "").strip()
        value = str(tag.get("Value") or "").strip()
        if key:
            tag_map[key] = value
    return tag_map


def _collect_network_posture_signals(self: Any, session: Any, account_id: str) -> list[Asset]:
    assets: list[Asset] = []

    default_vpc_present = False
    dedicated_workload_vpc_present = False
    managed_egress_path_defined = False
    subnet_tier_count = 0
    app_data_az_count = 0
    any_flow_logs_enabled = False
    regions_with_signal = 0

    for region in self.regions:
        try:
            ec2 = session.client("ec2", region_name=region)
            vpcs = ec2.describe_vpcs().get("Vpcs", [])
            subnets = ec2.describe_subnets().get("Subnets", [])
            route_tables = ec2.describe_route_tables().get("RouteTables", [])
            nat_gateways = ec2.describe_nat_gateways().get("NatGateways", [])
            vpc_endpoints = ec2.describe_vpc_endpoints().get("VpcEndpoints", [])
        except Exception as exc:
            self._set_signal_diag("network_posture", "unavailable", str(exc))
            continue

        regions_with_signal += 1

        non_default_vpc_ids: set[str] = set()
        for vpc in vpcs:
            is_default = bool(vpc.get("IsDefault", False))
            if is_default:
                default_vpc_present = True
                continue
            non_default_vpc_ids.add(str(vpc.get("VpcId") or ""))

        if non_default_vpc_ids:
            dedicated_workload_vpc_present = True

        flow_logs_filters = [{"Name": "resource-id", "Values": list(non_default_vpc_ids)}] if non_default_vpc_ids else []
        try:
            flow_logs = ec2.describe_flow_logs(Filters=flow_logs_filters) if flow_logs_filters else {"FlowLogs": []}
            if flow_logs.get("FlowLogs"):
                any_flow_logs_enabled = True
        except Exception:
            pass

        vpc_subnets: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for subnet in subnets:
            vpc_id = str(subnet.get("VpcId") or "")
            if vpc_id in non_default_vpc_ids:
                vpc_subnets[vpc_id].append(subnet)

        vpc_tier_names: dict[str, set[str]] = defaultdict(set)
        vpc_tier_azs: dict[str, set[str]] = defaultdict(set)

        for vpc_id, subnet_rows in vpc_subnets.items():
            for subnet in subnet_rows:
                tags = _normalize_tag_map(subnet.get("Tags"))
                tier_value = str(
                    tags.get("Tier")
                    or tags.get("tier")
                    or tags.get("SubnetTier")
                    or tags.get("subnet_tier")
                    or ""
                ).strip().lower()
                if tier_value not in {"app", "application", "data", "database", "db"}:
                    continue
                normalized_tier = "app" if tier_value in {"app", "application"} else "data"
                vpc_tier_names[vpc_id].add(normalized_tier)
                availability_zone = str(subnet.get("AvailabilityZone") or "").strip()
                if availability_zone:
                    vpc_tier_azs[vpc_id].add(availability_zone)

        if vpc_tier_names:
            subnet_tier_count = max(subnet_tier_count, max(len(tiers) for tiers in vpc_tier_names.values()))
        if vpc_tier_azs:
            app_data_az_count = max(app_data_az_count, max(len(azs) for azs in vpc_tier_azs.values()))

        nat_vpc_ids = {str(gateway.get("VpcId") or "") for gateway in nat_gateways if str(gateway.get("State") or "").lower() == "available"}
        endpoint_vpc_ids = {
            str(endpoint.get("VpcId") or "")
            for endpoint in vpc_endpoints
            if str(endpoint.get("State") or "").lower() == "available"
        }
        routed_vpc_ids: set[str] = set()
        for route_table in route_tables:
            vpc_id = str(route_table.get("VpcId") or "")
            if vpc_id not in non_default_vpc_ids:
                continue
            for route in route_table.get("Routes", []):
                gateway_id = str(route.get("GatewayId") or "").strip().lower()
                nat_gateway_id = str(route.get("NatGatewayId") or "").strip().lower()
                destination = str(route.get("DestinationCidrBlock") or "").strip()
                if destination == "0.0.0.0/0" and (gateway_id.startswith("igw-") or nat_gateway_id.startswith("nat-")):
                    routed_vpc_ids.add(vpc_id)
                    break
        if non_default_vpc_ids.intersection(nat_vpc_ids | endpoint_vpc_ids | routed_vpc_ids):
            managed_egress_path_defined = True

        assets.append(
            Asset(
                provider=Provider.aws,
                service="network",
                resource_id=f"network-posture:{account_id}:{region}",
                resource_type="network_posture_summary",
                region=region,
                metadata={
                    "default_vpc_present": default_vpc_present,
                    "dedicated_workload_vpc_present": dedicated_workload_vpc_present,
                    "subnet_tier_count": subnet_tier_count,
                    "app_data_az_count": app_data_az_count,
                    "managed_egress_path_defined": managed_egress_path_defined,
                    "flow_logs_enabled": any_flow_logs_enabled,
                    "landing_zone_ready": dedicated_workload_vpc_present
                    and subnet_tier_count >= 2
                    and app_data_az_count >= 2
                    and managed_egress_path_defined,
                },
            )
        )

    if regions_with_signal == 0:
        return assets

    if assets:
        self._set_signal_diag(
            "network_posture",
            "collected",
            "Network posture summary captured for landing-zone readiness checks.",
        )
    else:
        self._set_signal_diag("network_posture", "available_no_data", "No VPC topology rows returned.")
    return assets
