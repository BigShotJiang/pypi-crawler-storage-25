# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

from hybrisight.models import Finding
from hybrisight.scoring_constants import (
    SCORING_VERSION,
    SEVERITY_RANK,
    SEVERITY_WEIGHTS,
)
from hybrisight.scoring_priority import (
    assign_roadmap_phase,
    calculate_snapshot_scores,
    finding_base_score,
    finding_cost_score,
    finding_impact_score,
    finding_priority_score,
    prioritize_findings,
)
from hybrisight.scoring_projection import (
    build_cumulative_phase_projection,
    build_posture_trajectory_svg,
)
from hybrisight.scoring_roadmap import build_findings_groups, build_roadmap


def build_finding_debug_scores(finding: Finding) -> dict[str, Any]:
    return {
        "id": finding.id,
        "base_score": round(finding_base_score(finding), 4),
        "cost_score": round(finding_cost_score(finding), 4),
        "impact_score": round(finding_impact_score(finding), 4),
        "priority_score": round(finding_priority_score(finding), 4),
    }


__all__ = [
    "SCORING_VERSION",
    "SEVERITY_RANK",
    "SEVERITY_WEIGHTS",
    "assign_roadmap_phase",
    "build_cumulative_phase_projection",
    "build_finding_debug_scores",
    "build_findings_groups",
    "build_posture_trajectory_svg",
    "build_roadmap",
    "calculate_snapshot_scores",
    "finding_base_score",
    "finding_cost_score",
    "finding_impact_score",
    "finding_priority_score",
    "prioritize_findings",
]
