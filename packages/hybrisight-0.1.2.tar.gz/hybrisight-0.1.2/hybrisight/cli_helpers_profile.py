# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import os
import re
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator

import typer
from rich.console import Console

ACCESS_SETUP_BASE_URL = "https://hybrisight.agapii.org/help/access-setup"
AWS_ACCESS_SETUP_URL = f"{ACCESS_SETUP_BASE_URL}/aws-readonly-access"
AZURE_ACCESS_SETUP_URL = f"{ACCESS_SETUP_BASE_URL}/azure-readonly-access"
CREDENTIAL_HANDLING_URL = f"{ACCESS_SETUP_BASE_URL}/credential-handling"
DEFAULT_SIGNING_KEY_PATH = Path.home() / ".config" / "hybrisight" / "signing.key"
DEFAULT_SIGNING_PRIVATE_KEY_PATH = Path.home() / ".config" / "hybrisight" / "signing_ed25519_private.pem"
DEFAULT_SIGNING_PUBLIC_KEY_PATH = Path.home() / ".config" / "hybrisight" / "signing_ed25519_public.pem"
SENSITIVE_ENV_KEYS = (
    "AWS_ACCESS_KEY_ID",
    "AWS_SECRET_ACCESS_KEY",
    "AWS_SESSION_TOKEN",
    "AZURE_CLIENT_SECRET",
    "AZURE_CLIENT_CERTIFICATE_PASSWORD",
    "HYBRISIGHT_API_KEY",
    "HYBRISIGHT_PASSWORD",
)

SECRET_KV_RE = re.compile(r"(?i)\b([A-Z0-9_]*(?:SECRET|TOKEN|PASSWORD|API_KEY)[A-Z0-9_]*)=([^\s]+)")
AWS_KEY_RE = re.compile(r"\b(A3T[A-Z0-9]|AKIA|ASIA|AGPA|AIDA|AROA|ANPA)[A-Z0-9]{16}\b")

# Shared rich console for styled output and animations
console = Console(highlight=False)


def _default_config_path() -> Path:
    env_path = os.environ.get("HYBRISIGHT_CONFIG")
    return Path(env_path) if env_path else Path.home() / ".config" / "hybrisight" / "config.json"


def _load_profile(path: Path | None = None) -> dict[str, Any]:
    cfg_path = path or _default_config_path()
    if not cfg_path.exists():
        return {"portal": {}, "api_keys": {}}
    try:
        data = json.loads(cfg_path.read_text())
    except json.JSONDecodeError:
        return {"portal": {}, "api_keys": {}}
    data.setdefault("portal", {})
    data.setdefault("api_keys", {})
    return data


def _save_profile(data: dict[str, Any], path: Path | None = None) -> None:
    cfg_path = path or _default_config_path()
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(json.dumps(data, indent=2))


def _normalize_url(url: str) -> str:
    return url.rstrip("/")


def _redact_text(text: str) -> str:
    redacted = SECRET_KV_RE.sub(r"\1=[REDACTED]", text)
    redacted = AWS_KEY_RE.sub("[REDACTED]", redacted)
    for key in SENSITIVE_ENV_KEYS:
        value = os.environ.get(key)
        if value:
            redacted = redacted.replace(value, "[REDACTED]")
    return redacted


def _safe_echo(message: str, err: bool = False) -> None:
    typer.echo(_redact_text(str(message)), err=err)


def _print_section(title: str) -> None:
    _safe_echo("")
    _safe_echo(title)
    _safe_echo("-" * len(title))


def _is_interactive_session() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


@contextmanager
def _status_context(message: str) -> Generator[None, None, None]:
    """Provide a spinner animation for long-running CLI tasks."""
    if not _is_interactive_session():
        _safe_echo(f"[INFO] {message}...")
        yield
        return

    with console.status(f"[bold blue]{message}...", spinner="dots"):
        yield


def _parse_aws_regions_option(regions: str | None) -> list[str] | None:
    value = (regions or "").strip()
    if not value:
        return None
    tokens = [item.strip() for item in value.split(",") if item.strip()]
    if not tokens:
        return None
    if len(tokens) == 1 and tokens[0].lower() in {"all", "*"}:
        return None
    return tokens


def _discover_enabled_aws_regions(session: Any) -> list[str]:
    try:
        rows = session.client("ec2", region_name="us-east-1").describe_regions(AllRegions=False).get("Regions", [])
    except Exception:
        return []
    return sorted({str(row.get("RegionName", "")).strip() for row in rows if str(row.get("RegionName", "")).strip()})
