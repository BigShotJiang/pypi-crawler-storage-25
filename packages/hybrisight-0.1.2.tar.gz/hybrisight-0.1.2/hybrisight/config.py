# SPDX-License-Identifier: Apache-2.0
import os
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
BASE_DIR = PACKAGE_DIR.parent


def _resolve_rules_dir() -> Path:
    configured = os.getenv("HYBRISIGHT_RULES_DIR")
    if configured:
        return Path(configured).expanduser().resolve()

    # In-repo canonical path (used in local/dev and CI)
    repo_rules = BASE_DIR / "rules"
    if repo_rules.exists():
        return repo_rules

    # Installed package fallback
    return PACKAGE_DIR / "rules"


RULES_DIR = _resolve_rules_dir()
DEFAULT_JSON_OUTPUT = Path("hybrisight-findings.json")
DEFAULT_HTML_OUTPUT = Path("hybrisight-report.html")
DEFAULT_PDF_JSON_OUTPUT = Path("hybrisight-pdf-summary.json")
DEFAULT_PDF_OUTPUT = Path("hybrisight-report.pdf")
