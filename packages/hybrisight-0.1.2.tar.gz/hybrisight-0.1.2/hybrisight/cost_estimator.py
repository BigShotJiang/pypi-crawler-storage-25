# SPDX-License-Identifier: Apache-2.0
"""
Cost estimation engine.

Computes estimated annual waste based on:
1. Cost Explorer / Advisor API data (preferred — real billing data)
2. Pricing reference table fallback (estimated from resource specs)
3. Static rule defaults (last resort)

The methodology is:
- EC2 underutilized → 50% of on-demand rate (right-sizing savings)
- Orphaned EBS → 100% of volume cost (pure waste)
- Unattached IP → 100% of cost
- Idle ELB → 100% of monthly rate
- Overprovisioned storage → waste % × volume cost
"""

from hybrisight.pricing_data import (
    EBS_RATES,
    EC2_INSTANCE_RATES,
    ELB_MONTHLY_RATES,
    RDS_INSTANCE_RATES,
    region_multiplier,
)

HOURS_PER_YEAR = 8760
HOURS_PER_MONTH = 730


def _instance_type_from_resource_id(resource_id: str) -> str | None:
    parts = resource_id.split("/")
    for p in parts:
        p = p.strip().lower()
        if p in EC2_INSTANCE_RATES or p in RDS_INSTANCE_RATES:
            return p
    return None


def estimate_underutilized_compute_cost(metadata: dict, region: str | None = None) -> float | None:
    """EC2/VM running at <10% CPU → ~50% of on-demand cost is waste."""
    instance_type = _instance_type_from_resource_id(str(metadata.get("resource_id", "")))
    if not instance_type:
        return None
    hourly = EC2_INSTANCE_RATES.get(instance_type)
    if not hourly:
        return None
    mult = region_multiplier(region)
    annual_on_demand = hourly * HOURS_PER_YEAR * mult
    return round(annual_on_demand * 0.50, 2)


def estimate_orphaned_volume_cost(metadata: dict, region: str | None = None) -> float | None:
    """Unattached EBS volume → 100% of monthly cost × 12."""
    size_gb = metadata.get("allocated_gb", 0)
    if not size_gb:
        return None
    volume_type = str(metadata.get("volume_type", "gp3")).lower()
    rate = EBS_RATES.get(volume_type, EBS_RATES["gp3"])
    mult = region_multiplier(region)
    annual = size_gb * rate * 12 * mult
    return round(max(annual, 0), 2)


def estimate_overprovisioned_storage_cost(metadata: dict, region: str | None = None) -> float | None:
    """EBS/disk with utilization <50% → waste proportional to unused capacity."""
    allocated = metadata.get("allocated_gb", 0)
    used = metadata.get("used_gb", 0)
    if not allocated or used is None:
        return None
    waste_pct = max(0.0, 1.0 - used / allocated) if allocated > 0 else 0
    if waste_pct < 0.1:
        return 0.0
    volume_type = str(metadata.get("volume_type", "gp3")).lower()
    rate = EBS_RATES.get(volume_type, EBS_RATES["gp3"])
    mult = region_multiplier(region)
    annual = allocated * rate * 12 * waste_pct * mult
    return round(max(annual, 0), 2)


def estimate_idle_lb_cost(metadata: dict, region: str | None = None) -> float | None:
    """ELB with near-zero requests → 100% of monthly rate."""
    lb_type = str(metadata.get("load_balancer_type", "application")).lower()
    monthly = ELB_MONTHLY_RATES.get(lb_type, ELB_MONTHLY_RATES["application"])
    mult = region_multiplier(region)
    annual = monthly * 12 * mult
    return round(annual, 2)


def estimate_snapshot_cost(metadata: dict, region: str | None = None) -> float | None:
    """Orphaned snapshot → storage cost of the snapshot."""
    size_gb = metadata.get("allocated_gb", 0) or metadata.get("snapshot_size_gb", 0)
    if not size_gb:
        return None
    snapshot_count = metadata.get("snapshot_count", 1)
    rate = EBS_RATES["snapshot"]
    mult = region_multiplier(region)
    annual = size_gb * rate * 12 * snapshot_count * mult
    return round(annual, 2)


def estimate_unattached_ip_cost(region: str | None = None) -> float | None:
    """Unattached elastic IP → ~£43/yr per IP."""
    mult = region_multiplier(region)
    return round(43.80 * mult, 2)


ESTIMATORS: dict[str, callable] = {
    "underutilized_compute": estimate_underutilized_compute_cost,
    "unattached_volume": estimate_orphaned_volume_cost,
    "overprovisioned_storage": estimate_overprovisioned_storage_cost,
    "idle_load_balancer": estimate_idle_lb_cost,
    "orphaned_snapshot": estimate_snapshot_cost,
}
