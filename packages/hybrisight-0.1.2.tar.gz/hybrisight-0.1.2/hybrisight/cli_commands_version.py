# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import platform
import sys
from importlib.metadata import distributions

import typer
from rich.console import Console
from rich.table import Table

# Core dependencies (always installed via `pip install hybrisight`)
CORE_DEPS: dict[str, str] = {
    "boto3": "",
    "azure-identity": "",
    "httpx": "",
    "pydantic": "",
    "typer": "",
    "rich": "",
    "PyYAML": "",
    "alembic": "",
}

# Server extra (only when installed via `pip install hybrisight[server]`)
SERVER_DEPS: dict[str, str] = {
    "fastapi": "",
    "uvicorn": "",
    "sqlalchemy": "",
}

_console = Console(highlight=False)


def _collect_versions(target: dict[str, str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for dist in distributions():
        name = dist.metadata["Name"] or ""
        ver = dist.version or ""
        if name in target:
            result[name] = ver
        elif name.lower() in target:
            result[name.lower()] = ver
    return result


def version_cmd(
    all: bool = typer.Option(False, "--all", "-a", help="Show all installed packages"),
    check: bool = typer.Option(False, "--check", "-c", help="Check for available updates"),
) -> None:
    from hybrisight import __version__
    import httpx

    _console.print(f"[bold cyan]HybriSight[/bold cyan] v{__version__}")

    if check:
        try:
            resp = httpx.get("https://hybrisight.agapii.org/api/v1/public/version", timeout=10)
            data = resp.json() if resp.is_success else {}
            latest = data.get("latest", "unknown")
            _console.print(f"Latest available: [bold]{latest}[/bold]")
            if latest != "unknown" and latest != __version__:
                _console.print()
                _console.print(f"[yellow]Update available![/yellow] v{__version__} → v{latest}")
                _console.print("[dim]Safe install: curl -sSL https://hybrisight.agapii.org/install.sh -o install.sh && bash install.sh --verify-only && bash install.sh[/dim]")
            elif latest == __version__:
                _console.print("[green]You are up to date.[/green]")
            else:
                _console.print("[dim]Could not determine latest version.[/dim]")
        except Exception:
            _console.print("[dim]Could not reach update server.[/dim]")
        return

    _console.print(f"Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} — {platform.system()} {platform.release()}")
    _console.print()

    core_versions = _collect_versions(CORE_DEPS)
    server_versions = _collect_versions(SERVER_DEPS)
    has_server = bool(server_versions)

    table = Table(title="Core Dependencies", show_header=True, header_style="bold")
    table.add_column("Package", style="dim")
    table.add_column("Version", style="cyan")

    for name in CORE_DEPS:
        ver = core_versions.get(name) or "—"
        style = "green" if ver != "—" else "red dim"
        table.add_row(name, f"[{style}]{ver}[/{style}]")

    _console.print(table)

    if has_server:
        _console.print()
        srv = Table(title="Server Dependencies (installed)", show_header=True, header_style="bold")
        srv.add_column("Package", style="dim")
        srv.add_column("Version", style="cyan")
        for name in SERVER_DEPS:
            ver = server_versions.get(name) or "—"
            style = "green" if ver != "—" else "red dim"
            srv.add_row(name, f"[{style}]{ver}[/{style}]")
        _console.print(srv)
    else:
        _console.print("[dim]Server extras not installed (CLI-only). Run [bold]pip install 'hybrisight[server]'[/bold] for FastAPI/Uvicorn/SQLAlchemy.[/dim]")

    if all:
        _console.print()
        all_table = Table(title="All Installed Packages", show_header=True, header_style="bold")
        all_table.add_column("Package", style="dim")
        all_table.add_column("Version", style="cyan")
        for dist in sorted(distributions(), key=lambda d: (d.metadata["Name"] or "").lower()):
            name = dist.metadata["Name"] or "unknown"
            ver = dist.version or "?"
            all_table.add_row(name, ver)
        _console.print(all_table)
