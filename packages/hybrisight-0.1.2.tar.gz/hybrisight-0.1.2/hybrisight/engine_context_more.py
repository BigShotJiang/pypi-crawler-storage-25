# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any


def owner_for_risk_category(risk_category: str) -> str:
    owner_map = {
        "security": "Security",
        "cost": "Platform",
        "resilience": "Cloud Engineering",
        "ops": "Platform",
    }
    return owner_map.get(risk_category, "Cloud Engineering")


def effort_for_severity(severity: str) -> str:
    if severity == "critical":
        return "High"
    if severity == "high":
        return "Medium"
    return "Low"


def validation_for_theme(theme: str, risk_category: str) -> str:
    normalized = theme.lower()
    if "identity" in normalized or "iam" in normalized:
        return "IAM policy diff and least-privilege validation."
    if "data" in normalized or "storage" in normalized:
        return "Storage policy validation confirms no public access."
    if "resilience" in normalized or "backup" in normalized:
        return "Backup coverage and restore policy checks pass."
    if risk_category == "cost":
        return "Cost telemetry confirms expected optimization delta."
    if risk_category == "ops":
        return "Tagging and ownership policy checks pass."
    return "Control evidence captured and validated."


def build_immediate_actions(roadmap: dict[str, list[dict[str, Any]]]) -> tuple[list[str], list[dict[str, Any]]]:
    actions: list[str] = []
    action_details: list[dict[str, Any]] = []
    for item in roadmap.get("30_days", []):
        for action in item.get("actions", []):
            action_text = str(action).strip()
            if not action_text or action_text in actions:
                continue
            actions.append(action_text)
            action_details.append(
                {
                    "action": action_text,
                    "scope": int(item.get("affected_resource_count", 0)),
                    "effort": effort_for_severity(str(item.get("severity", "medium"))),
                    "owner": owner_for_risk_category(str(item.get("risk_category", "ops"))),
                    "validation": validation_for_theme(str(item.get("theme", "")), str(item.get("risk_category", "ops"))),
                }
            )
            if len(actions) >= 5:
                return actions, action_details
    return actions, action_details


def build_risk_profile_narrative(heat_map: dict[str, dict[str, int]], drivers: list[dict[str, Any]]) -> str:
    security_pressure = heat_map["security"]["critical"] + heat_map["security"]["high"]
    cost_pressure = heat_map["cost"]["critical"] + heat_map["cost"]["high"]
    resilience_pressure = heat_map["resilience"]["critical"] + heat_map["resilience"]["high"]
    ops_pressure = heat_map["ops"]["critical"] + heat_map["ops"]["high"]
    dominant = max(
        [("security", security_pressure), ("cost", cost_pressure), ("resilience", resilience_pressure), ("operations", ops_pressure)],
        key=lambda item: item[1],
    )
    if dominant[0] == "security":
        has_storage_driver = any("storage" in str(driver.get("title", "")).lower() for driver in drivers)
        has_iam_driver = any("iam" in str(driver.get("title", "")).lower() or "identity" in str(driver.get("title", "")).lower() for driver in drivers)
        if has_storage_driver and has_iam_driver:
            return (
                "Security exposure currently dominates this environment, driven primarily by publicly accessible storage "
                "and excessive IAM permissions. Addressing these two drivers removes the majority of externally "
                "exploitable conditions identified in this snapshot."
            )
    return (
        f"{dominant[0].title()} controls represent the highest concentration of severe exposure in this snapshot. "
        "Prioritize this pillar first to reduce board-level risk in the shortest stabilisation window."
    )
