# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from pathlib import Path

import typer

from hybrisight.engine import save_html_report
from hybrisight.models import ScanResult


def merge_cmd(
    inputs: list[Path] = typer.Argument(..., help="Scan result JSON files to merge (space-separated, or use glob)"),
    output: Path = typer.Option("merged.json", "--output", "-o", help="Output merged JSON file"),
    report: bool = typer.Option(False, "--report", "-r", help="Also generate a merged HTML report"),
) -> None:
    if not inputs:
        typer.secho("Error: specify at least one input scan file", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    results: list[ScanResult] = []
    account_labels: list[str] = []
    for i, path in enumerate(inputs):
        if not path.exists():
            typer.secho(f"Error: {path} not found", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=1)
        raw = path.read_bytes()
        data = json.loads(raw)
        result = ScanResult.model_validate(data)
        results.append(result)
        if result.metadata and result.metadata.get("account"):
            account_labels.append(str(result.metadata["account"]))
        else:
            account_labels.append(f"scan-{i}")

    if len(results) == 1:
        typer.secho("Only one scan provided. Use 'hybrisight report' directly instead.", fg=typer.colors.YELLOW)
        merged = results[0]
    else:
        typer.secho(f"Merging {len(results)} scans...", fg=typer.colors.CYAN)
        merged = _merge_results(results, account_labels)

    merged_json = merged.model_dump(mode="json")
    output.write_text(json.dumps(merged_json, indent=2))
    typer.secho(f"Merged scan written to {output}", fg=typer.colors.GREEN)

    if report:
        html_output = output.with_suffix(".html")
        save_html_report(merged, html_output)
        typer.secho(f"HTML report generated: {html_output}", fg=typer.colors.GREEN)

    typer.secho("\nAccounts included:", fg=typer.colors.CYAN)
    for label in account_labels:
        typer.secho(f"  • {label}", fg=typer.colors.CYAN)


def _merge_results(results: list[ScanResult], labels: list[str]) -> ScanResult:
    base = results[0].model_copy(deep=True)
    base.metadata = base.metadata or {}
    base.metadata["merged_accounts"] = labels
    base.metadata["merged_count"] = len(results)

    all_findings = list(base.findings or [])
    seen_rules: set[str] = {(f.rule_id or "") + ":" + (f.impacted_resource or "") for f in all_findings}

    for i, result in enumerate(results[1:], 1):
        for finding in result.findings or []:
            key = (finding.rule_id or "") + ":" + (finding.impacted_resource or "")
            if key not in seen_rules:
                seen_rules.add(key)
                all_findings.append(finding)

    base.findings = all_findings

    if base.summary and results[0].summary:
        for s in results[1:]:
            if s.summary:
                base.summary.assets = (base.summary.assets or 0) + (s.summary.assets or 0)
                base.summary.findings = (base.summary.findings or 0) + (s.summary.findings or 0)
                if s.summary.estimated_waste_gbp:
                    base.summary.estimated_waste_gbp = (base.summary.estimated_waste_gbp or 0) + s.summary.estimated_waste_gbp
        base.summary.findings = len(all_findings)

    return base
