# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

import httpx
import typer

from hybrisight.cli_commands_auth_signing import provision_api_key_via_login
from hybrisight.cli_helpers import (
    AWS_ACCESS_SETUP_URL,
    AZURE_ACCESS_SETUP_URL,
    CREDENTIAL_HANDLING_URL,
    _annotate_collection_diagnostics,
    _annotate_recommended_output,
    _doctor_aws,
    _doctor_azure,
    _ensure_signing_key_for_cli,
    _parse_aws_regions_option,
    _persist_profile_defaults,
    _print_collection_diagnostics_summary,
    _print_section,
    _resolve_api_key,
    _resolve_portal_url,
    _safe_echo,
    _status_context,
    _summarize_error_text,
)
from hybrisight.continuity_metadata import build_continuity_metadata, infer_scope_identifiers
from hybrisight.engine import run_scan, save_json_report
from hybrisight.providers.aws.collector import AwsCollector
from hybrisight.providers.azure.collector import AzureCollector
from hybrisight.providers.errors import CollectorError
from hybrisight.security import scan_payload_for_malware
from hybrisight.signing import sign_scan_result


def upload_cmd(
    artifact: Path,
    signature: Path | None,
    url: str | None,
    api_key: str | None,
    auto_provision: bool,
    yes: bool,
    engagement_label: str | None = None,
    engagement_key: str | None = None,
    scope_label: str | None = None,
    scope_fingerprint: str | None = None,
    series_label: str | None = None,
    series_key: str | None = None,
    series_cadence: str | None = None,
) -> None:
    _print_section("Artifact Upload")
    if not artifact.exists():
        _safe_echo(f"[ERROR] Input file not found: {artifact}", err=True)
        raise typer.Exit(code=1)
    payload = artifact.read_bytes()
    if not scan_payload_for_malware(payload):
        _safe_echo("[ERROR] Local malware scan failed. The artifact contains suspicious patterns.", err=True)
        raise typer.Exit(code=1)

    resolved_url = _resolve_portal_url(url)
    resolved_key = _resolve_api_key(resolved_url, api_key)

    if not resolved_key and auto_provision:
        _safe_echo("[INFO] No API key found for this portal. Auto-provisioning is enabled.")
        approved = yes
        if not approved:
            if not sys.stdin.isatty():
                typer.echo("Error: interactive approval required to auto-generate an API key. Re-run with --yes or run `hybrisight auth login` first.", err=True)
                raise typer.Exit(code=1)
            approved = typer.confirm("Generate a scoped API key now via portal login?", default=True)
        if not approved:
            typer.echo("Cancelled. Run `hybrisight auth login` or create an account at https://hybrisight.agapii.org", err=True)
            raise typer.Exit(code=1)

        try:
            resolved_key = provision_api_key_via_login(resolved_url, os.environ.get("HYBRISIGHT_EMAIL", "shawnthompson66@gmail.com"), os.environ.get("HYBRISIGHT_PASSWORD", "admin123"), "cli-auto-key")
            _persist_profile_defaults(resolved_url, resolved_key)
            typer.echo("Auto-provisioned API key and saved local profile defaults.")
            typer.echo("Security reminder: protect API keys like secrets, rotate regularly, and never commit them to source control.")
        except Exception as exc:
            _safe_echo(f"[ERROR] Auto-provision failed: {_summarize_error_text(str(exc))}", err=True)
            raise typer.Exit(code=1)

    if not resolved_key:
        typer.echo("Error: API key is required. Create a free account at https://hybrisight.agapii.org, then run `hybrisight auth login` to authenticate.", err=True)
        raise typer.Exit(code=1)

    with _status_context("Exchanging upload token"):
        with httpx.Client() as client:
            exchange_data: dict[str, str | int] = {"expires_minutes": 30}
            if engagement_label:
                exchange_data["engagement_label"] = engagement_label
            if engagement_key:
                exchange_data["engagement_key"] = engagement_key
            if scope_label:
                exchange_data["scope_label"] = scope_label
            if scope_fingerprint:
                exchange_data["scope_fingerprint"] = scope_fingerprint
            if series_label:
                exchange_data["series_label"] = series_label
            if series_key:
                exchange_data["series_key"] = series_key
            if series_cadence:
                exchange_data["series_cadence"] = series_cadence
            resp = client.post(f"{resolved_url}/api/v1/scan-jobs/exchange", headers={"X-HybriSight-Api-Key": resolved_key}, data=exchange_data)
            try:
                resp.raise_for_status()
            except httpx.HTTPError as exc:
                _safe_echo(f"[ERROR] Token exchange failed: {_summarize_error_text(str(exc))}", err=True)
                raise typer.Exit(code=1)
            job_data = resp.json()

    files: dict[str, tuple[str, bytes, str]] = {"file": (artifact.name, payload, "application/json")}
    if signature and signature.exists():
        files["signature_file"] = (signature.name, signature.read_bytes(), "application/json")
    data = {
        "token": job_data["token"],
        "source_type": "scanresult",
        "command_payload_json": json.dumps(job_data["command_payload"]),
        "command_signature": job_data["command_signature"],
    }
    if engagement_label:
        data["engagement_label"] = engagement_label
    if engagement_key:
        data["engagement_key"] = engagement_key
    if scope_label:
        data["scope_label"] = scope_label
    if scope_fingerprint:
        data["scope_fingerprint"] = scope_fingerprint
    if series_label:
        data["series_label"] = series_label
    if series_key:
        data["series_key"] = series_key
    if series_cadence:
        data["series_cadence"] = series_cadence

    try:
        with _status_context("Uploading artifact"):
            with httpx.Client() as client:
                resp = client.post(f"{resolved_url}{job_data['upload_endpoint']}", data=data, files=files)
                resp.raise_for_status()
                result = resp.json()
                typer.echo(f"Success! Upload ID: {result['upload_id']}")
                typer.echo(f"View report at: {resolved_url}/dashboard/{result['upload_id']}")
    except httpx.HTTPError as exc:
        _safe_echo(f"[ERROR] Upload failed: {_summarize_error_text(str(exc))}", err=True)
        if hasattr(exc, "response") and exc.response is not None:
            _safe_echo(f"[DETAIL] {_summarize_error_text(exc.response.text)}", err=True)
        raise typer.Exit(code=1)


def scan_cmd(
    provider: str,
    profile: str | None,
    regions: str,
    tenant: str | None,
    subscription_id: str | None,
    engagement_label: str | None,
    engagement_key: str | None,
    scope_label: str | None,
    scope_fingerprint: str | None,
    series_label: str | None,
    series_key: str | None,
    series_cadence: str | None,
    rules_dir: Path,
    output: Path,
    sign: bool,
    embed_signature: bool,
    signature_output: Path | None,
    demo: bool,
) -> None:
    provider = provider.lower()
    collector: Any | None = None
    assets: Any = None
    try:
        if provider == "aws":
            with _status_context("Collecting AWS assets"):
                collector = AwsCollector(profile=profile, regions=_parse_aws_regions_option(regions), demo=demo)
                assets = collector.collect()
        elif provider == "azure":
            with _status_context("Collecting Azure assets"):
                collector = AzureCollector(tenant=tenant, subscription_id=subscription_id, demo=demo)
                assets = collector.collect()
        else:
            raise typer.BadParameter("provider must be 'aws' or 'azure'")
    except CollectorError as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        typer.echo(f"Access setup guide: {AWS_ACCESS_SETUP_URL if provider == 'aws' else AZURE_ACCESS_SETUP_URL}", err=True)
        raise typer.Exit(code=1)

    with _status_context("Evaluating rules and scoring environment"):
        result = run_scan(provider=provider, assets=assets, rules_dir=rules_dir)
        result.continuity = build_continuity_metadata(
            provider=provider,
            engagement_label=engagement_label,
            engagement_key=engagement_key,
            scope_label=scope_label,
            scope_fingerprint=scope_fingerprint,
            identifiers=infer_scope_identifiers(provider, assets=assets),
            series_label=series_label,
            series_key=series_key,
            cadence=series_cadence,
        )
        if collector is not None and hasattr(collector, "get_collection_diagnostics"):
            try:
                diagnostics = collector.get_collection_diagnostics()
                if diagnostics:
                    result.collection_diagnostics = _annotate_collection_diagnostics(diagnostics)
            except Exception:
                pass
        _annotate_recommended_output(result)

    signature_block = None
    if sign:
        if not _ensure_signing_key_for_cli():
            raise typer.Exit(code=1)
        try:
            signature_block = sign_scan_result(result)
        except RuntimeError as exc:
            _safe_echo(f"Unable to sign artifact: {exc}", err=True)
            _safe_echo("Retry after configuring signing keys (`hybrisight signing init` + `hybrisight signing register`).", err=True)
            raise typer.Exit(code=1)
        if embed_signature:
            result.signature = signature_block

    save_json_report(result, output)
    if signature_output and signature_block:
        signature_output.write_text(signature_block.model_dump_json(indent=2))
    summary = ((result.collection_diagnostics or {}).get("summary") or {}) if isinstance(result.collection_diagnostics, dict) else {}
    quality_label = str(summary.get("label") or "Unknown")
    _print_section("Scan Summary")
    typer.echo(f"Provider: {provider.upper()}")
    typer.echo("Artifact Type: Canonical HybriSight CLI")
    typer.echo(f"Collection Quality: {quality_label}")
    recommended_output = ((result.collection_diagnostics or {}).get("recommended_output") or {}) if isinstance(result.collection_diagnostics, dict) else {}
    typer.echo(f"Recommended Output: {str(recommended_output.get('label') or 'Governance Brief')}")
    typer.echo(f"Use Case: {str(recommended_output.get('use_case') or 'Board-grade governance and stabilisation planning')}")
    typer.echo(f"Canonical Findings: {result.finding_count}")
    typer.echo(f"Artifact: {output}")
    if signature_output and signature_block:
        typer.echo(f"Signature: {signature_output}")
    typer.echo("Status: Scan completed; artifact ready for upload.")
    _print_collection_diagnostics_summary(result.collection_diagnostics)
    _print_section("Next Step")
    typer.echo("Upload this canonical artifact to HybriSight for the executive brief and stabilisation roadmap:")
    typer.echo("https://hybrisight.agapii.org")


def doctor_cmd(provider: str, profile: str | None, regions: str, tenant: str | None, subscription_id: str | None) -> None:
    provider = provider.lower().strip()
    if provider not in {"aws", "azure"}:
        raise typer.BadParameter("provider must be 'aws' or 'azure'")

    docs_url = AWS_ACCESS_SETUP_URL if provider == "aws" else AZURE_ACCESS_SETUP_URL
    _print_section(f"Credential Doctor ({provider})")
    _safe_echo("[INFO] Read-only checks only. No cloud changes are made.")

    try:
        with _status_context(f"Running {provider} diagnostic checks"):
            result = _doctor_aws(profile=profile, regions=regions) if provider == "aws" else _doctor_azure(tenant=tenant, subscription_id=subscription_id)
    except CollectorError as exc:
        _safe_echo(f"[ERROR] Doctor failed: {_summarize_error_text(str(exc))}", err=True)
        _safe_echo(f"Access setup guide: {docs_url}", err=True)
        _safe_echo(f"Credential handling policy: {CREDENTIAL_HANDLING_URL}", err=True)
        raise typer.Exit(code=1)

    identity = result.get("identity", {})
    checks = result.get("checks", [])
    _safe_echo(f"[INFO] Identity: {json.dumps(identity, sort_keys=True)}")
    for item in checks:
        status = "OK" if item.get("ok") else "WARN" if not item.get("required", True) else "FAIL"
        _safe_echo(f"[{status}] {item.get('name')}: {_summarize_error_text(str(item.get('detail', '')))}")

    failed_required = [item for item in checks if (not item.get("ok")) and item.get("required", True)]
    failed_optional = [item for item in checks if (not item.get("ok")) and (not item.get("required", True))]
    if failed_optional:
        _safe_echo("[WARN] Optional strategic signal checks failed (scan works, but brief may miss Advisor/Defender/GuardDuty/Trusted Advisor context).", err=True)
        _safe_echo(f"Review access setup: {docs_url}", err=True)
    if failed_required:
        _safe_echo("[ERROR] One or more required read-only checks failed.", err=True)
        _safe_echo(f"Review access setup: {docs_url}", err=True)
        raise typer.Exit(code=1)

    _safe_echo("[OK] All required read-only checks passed.")
    if provider == "aws":
        _safe_echo(f"Next: hybrisight scan aws --profile {profile} --output artifact.json" if profile else "Next: hybrisight scan aws --regions all --output artifact.json")
    else:
        _safe_echo(f"Next: hybrisight scan azure --subscription {subscription_id or '<subscription-id>'} --output artifact.json")
    _safe_echo("Upload example: hybrisight upload --artifact artifact.json --portal https://hybrisight.agapii.org")
