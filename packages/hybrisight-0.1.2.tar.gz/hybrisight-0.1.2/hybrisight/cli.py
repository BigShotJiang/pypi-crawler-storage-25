# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
from pathlib import Path

import httpx
import typer

import hybrisight.cli_commands_report as _report_mod
import hybrisight.cli_commands_scan_upload as _scan_upload_mod
from hybrisight.cli_commands_auth_signing import (
    provision_api_key_via_login as _provision_api_key_via_login,
    auth_login_cmd,
    signing_init_cmd,
    signing_register_cmd,
    signing_sign_artifact_cmd,
)
from hybrisight.cli_commands_merge import merge_cmd
from hybrisight.cli_commands_report import report_cmd
from hybrisight.cli_commands_scan_upload import doctor_cmd, scan_cmd, upload_cmd
from hybrisight.cli_commands_version import version_cmd
from hybrisight.cli_helpers import (
    AWS_ACCESS_SETUP_URL,
    AZURE_ACCESS_SETUP_URL,
    CREDENTIAL_HANDLING_URL,
    DEFAULT_SIGNING_PRIVATE_KEY_PATH,
    DEFAULT_SIGNING_PUBLIC_KEY_PATH,
    _doctor_aws,
    _parse_aws_regions_option,
    _redact_text as _redact_text_helper,
)
from hybrisight.config import DEFAULT_HTML_OUTPUT, DEFAULT_JSON_OUTPUT, RULES_DIR
from hybrisight.pdf import render_pdf_report

app = typer.Typer(
    help=(
        "HybriSight: Read-only Cloud & Infrastructure Efficiency Snapshot\n\n"
        "Access setup docs:\n"
        f"- AWS: {AWS_ACCESS_SETUP_URL}\n"
        f"- Azure: {AZURE_ACCESS_SETUP_URL}\n"
        f"- Credential handling: {CREDENTIAL_HANDLING_URL}"
    )
)
auth_app = typer.Typer(help="Authenticate and manage local CLI profile defaults")
signing_app = typer.Typer(help="Manage artifact signing keys")
app.add_typer(auth_app, name="auth")
app.add_typer(signing_app, name="signing")
app.command(name="version", help="Show HybriSight version and key dependency information")(version_cmd)
app.command(name="merge", help="Merge multiple scan results into a single report")(merge_cmd)


@app.callback(invoke_without_command=True)
def hybrisight_main(
    ctx: typer.Context,
    show_version: bool = typer.Option(False, "--version", help="Show HybriSight version"),
) -> None:
    if show_version:
        version_cmd(all=False)
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        raise typer.Exit()


def _redact_text(text: str) -> str:
    return _redact_text_helper(text)


@auth_app.command("login", help="Login to portal and create/store a scoped API key for CLI uploads")
def auth_login(
    url: str | None = typer.Option(None, "--url", "--portal", help="Portal base URL (defaults: option > env > profile > localhost)"),
    email: str = typer.Option(lambda: os.environ.get("HYBRISIGHT_EMAIL", ""), help="Portal user email (default: HYBRISIGHT_ENV or interactive prompt)"),
    password: str = typer.Option(lambda: os.environ.get("HYBRISIGHT_PASSWORD", ""), help="Portal user password (default: HYBRISIGHT_PASSWORD or interactive prompt)"),
    key_name: str = typer.Option("cli-auto-key", help="Name for the generated API key"),
) -> None:
    auth_login_cmd(url=url, email=email, password=password, key_name=key_name)


@signing_app.command("init", help="Generate a local Ed25519 signing keypair for artifact signing")
def signing_init(
    private_key_file: Path = typer.Option(DEFAULT_SIGNING_PRIVATE_KEY_PATH, help="Path to private key PEM"),
    public_key_file: Path = typer.Option(DEFAULT_SIGNING_PUBLIC_KEY_PATH, help="Path to public key PEM"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing key files"),
) -> None:
    signing_init_cmd(private_key_file=private_key_file, public_key_file=public_key_file, force=force)


@signing_app.command("register", help="Register a tenant public signing key with the portal")
def signing_register(
    public_key_file: Path = typer.Option(DEFAULT_SIGNING_PUBLIC_KEY_PATH, help="Path to public key PEM"),
    url: str | None = typer.Option(None, "--url", "--portal", help="Portal base URL"),
    api_key: str | None = typer.Option(None, help="Portal API key with scan_job:create scope"),
    key_id: str | None = typer.Option(None, help="Optional explicit key id"),
) -> None:
    signing_register_cmd(public_key_file=public_key_file, url=url, api_key=api_key, key_id=key_id)


@signing_app.command("sign-artifact", help="Sign an existing ScanResult artifact JSON")
def signing_sign_artifact(
    input: Path = typer.Option(..., "--input", help="Path to existing ScanResult JSON"),
    signature_output: Path = typer.Option(..., "--signature-output", help="Path to signature sidecar JSON"),
    embed_signature: bool = typer.Option(False, "--embed-signature", help="Embed signature block into output artifact JSON"),
    output: Path | None = typer.Option(None, "--output", help="Output artifact path when embedding signature"),
) -> None:
    signing_sign_artifact_cmd(input=input, signature_output=signature_output, embed_signature=embed_signature, output=output)


@app.command("upload", help="Upload a scan artifact to the HybriSight Portal")
def upload(
    artifact: Path = typer.Option(..., "--artifact", "-a", "--output", help="Path to findings JSON file"),
    signature: Path | None = typer.Option(None, help="Path to signature JSON file"),
    url: str | None = typer.Option(None, "--url", "--portal", help="Portal base URL (defaults: option > env > profile > localhost)"),
    api_key: str | None = typer.Option(None, help="API Key (defaults: option > env > profile)"),
    auto_provision: bool = typer.Option(False, help="Auto-create scoped API key via login if none is available (for automated/CI workflows)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Approve API key auto-provision without prompt"),
    engagement_label: str | None = typer.Option(None, help="Optional engagement label to bind continuity to a named client programme"),
    engagement_key: str | None = typer.Option(None, help="Optional engagement key to bind continuity to a stable programme identity"),
    scope_label: str | None = typer.Option(None, help="Optional upload-time continuity scope label"),
    scope_fingerprint: str | None = typer.Option(None, help="Optional upload-time continuity scope fingerprint"),
    series_label: str | None = typer.Option(None, help="Optional upload-time reassessment series label"),
    series_key: str | None = typer.Option(None, help="Optional upload-time reassessment series key"),
    series_cadence: str | None = typer.Option(None, help="Optional upload-time reassessment cadence"),
) -> None:
    # Preserve legacy monkeypatch points in tests via the cli module.
    _scan_upload_mod.provision_api_key_via_login = _provision_api_key_via_login
    upload_cmd(
        artifact=artifact,
        signature=signature,
        url=url,
        api_key=api_key,
        auto_provision=auto_provision,
        yes=yes,
        engagement_label=engagement_label,
        engagement_key=engagement_key,
        scope_label=scope_label,
        scope_fingerprint=scope_fingerprint,
        series_label=series_label,
        series_key=series_key,
        series_cadence=series_cadence,
    )


@app.command("scan")
def scan(
    provider: str = typer.Argument(..., help="aws or azure"),
    profile: str | None = typer.Option(None, help="AWS profile"),
    regions: str = typer.Option("all", help="Comma-separated AWS regions, or 'all' to scan all enabled account regions (default)."),
    tenant: str | None = typer.Option(None, "--tenant", "--tenant-id", help="Azure tenant ID"),
    subscription_id: str | None = typer.Option(None, "--subscription-id", "--subscription", help="Azure subscription ID"),
    engagement_label: str | None = typer.Option(None, help="Optional engagement label for reassessment continuity"),
    engagement_key: str | None = typer.Option(None, help="Optional stable engagement key for reassessment continuity"),
    scope_label: str | None = typer.Option(None, help="Optional explicit continuity scope label for the artifact"),
    scope_fingerprint: str | None = typer.Option(None, help="Optional explicit continuity scope fingerprint"),
    series_label: str | None = typer.Option(None, help="Optional explicit reassessment series label"),
    series_key: str | None = typer.Option(None, help="Optional explicit reassessment series key"),
    series_cadence: str | None = typer.Option(None, help="Optional reassessment cadence label, for example ad_hoc or monthly"),
    rules_dir: Path = typer.Option(RULES_DIR, help="Path to rule pack directory"),
    output: Path = typer.Option(DEFAULT_JSON_OUTPUT, help="Technical JSON output path"),
    sign: bool = typer.Option(False, help="Sign ScanResult artifact"),
    embed_signature: bool = typer.Option(True, help="Embed signature block in output JSON"),
    signature_output: Path | None = typer.Option(None, help="Optional signature sidecar JSON path"),
    demo: bool = typer.Option(False, help="Run with demo metadata"),
) -> None:
    _scan_upload_mod._parse_aws_regions_option = _parse_aws_regions_option
    scan_cmd(provider, profile, regions, tenant, subscription_id, engagement_label, engagement_key, scope_label, scope_fingerprint, series_label, series_key, series_cadence, rules_dir, output, sign, embed_signature, signature_output, demo)


@app.command("doctor", help="Validate identity and required read-only permissions for AWS/Azure scan collection.")
def doctor(
    provider: str = typer.Argument(..., help="aws or azure"),
    profile: str | None = typer.Option(None, help="AWS profile for identity and permission checks"),
    regions: str = typer.Option("all", help="Comma-separated AWS regions, or 'all' to auto-select from enabled account regions (default)."),
    tenant: str | None = typer.Option(None, "--tenant", "--tenant-id", help="Azure tenant ID"),
    subscription_id: str | None = typer.Option(None, "--subscription-id", "--subscription", help="Azure subscription ID"),
) -> None:
    _scan_upload_mod._doctor_aws = _doctor_aws
    doctor_cmd(provider, profile, regions, tenant, subscription_id)


@app.command("report")
def report(
    input: Path = typer.Option(DEFAULT_JSON_OUTPUT, help="Input findings JSON"),
    format: str = typer.Option("html", help="html, json, pdf-json, or pdf"),
    output: Path = typer.Option(DEFAULT_HTML_OUTPUT, help="Report output path"),
    source_type: str = typer.Option("auto", help="Input type: auto, scanresult (canonical), or native-export (cloud-native export)"),
    provider: str | None = typer.Option(None, help="Provider for native export input: aws or azure"),
    export_type: str | None = typer.Option(None, help="Native export type when using --source-type native-export"),
) -> None:
    _report_mod.render_pdf_report = render_pdf_report
    report_cmd(input=input, format=format, output=output, source_type=source_type, provider=provider, export_type=export_type)


__all__ = [
    "app",
    "auth_app",
    "signing_app",
    "run",
    "httpx",
    "render_pdf_report",
    "_doctor_aws",
    "_parse_aws_regions_option",
    "_provision_api_key_via_login",
]


def run() -> None:
    app()


if __name__ == "__main__":
    run()
