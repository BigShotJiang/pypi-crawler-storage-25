# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from collections.abc import Callable
from typing import Any

from hybrisight.checks.builtin_aws import AWS_EVALUATORS
from hybrisight.models import Asset
Evaluator = Callable[[Asset, dict], bool]


def _safe_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def has_wildcard_permissions(asset: Asset, config: dict) -> bool:
    actions = asset.metadata.get("actions", [])
    resources = asset.metadata.get("resources", [])
    return asset.service == "iam" and ("*" in actions or "*" in resources)


def is_admin_role(asset: Asset, config: dict) -> bool:
    return asset.service == "iam" and bool(asset.metadata.get("is_admin_role", False))


def missing_mfa_enforcement(asset: Asset, config: dict) -> bool:
    if asset.service != "iam_account":
        return False
    return not bool(asset.metadata.get("mfa_enforced", False))


def public_access_enabled(asset: Asset, config: dict) -> bool:
    services = set(config.get("service_in", ["s3", "storage"]))
    return asset.service in services and bool(asset.metadata.get("public_access", False))


def encryption_disabled(asset: Asset, config: dict) -> bool:
    return bool(config.get("service_in", [asset.service])) and asset.service in set(
        config.get("service_in", ["s3", "storage", "ebs", "snapshot", "disk"])
    ) and not bool(asset.metadata.get("encrypted", True))


def versioning_disabled(asset: Asset, config: dict) -> bool:
    return asset.service in {"s3", "storage"} and not bool(asset.metadata.get("versioning_enabled", False))


def backup_not_enabled(asset: Asset, config: dict) -> bool:
    return asset.service in set(config.get("service_in", ["ec2", "vm", "rds", "disk"])) and not bool(
        asset.metadata.get("backup_enabled", False)
    )


def single_az_deployment(asset: Asset, config: dict) -> bool:
    return asset.service in set(config.get("service_in", ["ec2", "rds", "vm"])) and bool(
        asset.metadata.get("is_critical", False)
    ) and int(asset.metadata.get("availability_zone_count", 1)) < 2


def missing_lifecycle_policy(asset: Asset, config: dict) -> bool:
    return asset.service in {"s3", "storage", "snapshot"} and not bool(asset.metadata.get("lifecycle_policy", False))


def unrestricted_ingress_admin_ports(asset: Asset, config: dict) -> bool:
    if asset.service != "network":
        return False
    monitored_ports = set(config.get("ports", [22, 3389]))
    for rule in asset.metadata.get("ingress", []):
        if rule.get("cidr") == "0.0.0.0/0" and int(rule.get("port", -1)) in monitored_ports:
            return True
    return False


def unrestricted_ingress_any_port(asset: Asset, config: dict) -> bool:
    if asset.service != "network":
        return False
    for rule in asset.metadata.get("ingress", []):
        if rule.get("cidr") == "0.0.0.0/0" and int(rule.get("port", -1)) in range(1, 65536):
            return True
    return False


def underutilized_compute(asset: Asset, config: dict) -> bool:
    if asset.service not in {"ec2", "vm"}:
        return False
    threshold = _safe_float(config.get("cpu_threshold_percent"), 10.0)
    cpu = _safe_float(asset.metadata.get("avg_cpu_utilization_30d"), -1.0)
    if cpu < 0:
        return False
    return cpu < threshold


def overprovisioned_storage(asset: Asset, config: dict) -> bool:
    if asset.service not in {"ebs", "disk", "storage"}:
        return False
    allocated = _safe_float(asset.metadata.get("allocated_gb"))
    used = _safe_float(asset.metadata.get("used_gb"), allocated)
    if allocated <= 0:
        return False
    utilization_ratio = used / allocated
    return utilization_ratio < _safe_float(config.get("min_utilization_ratio"), 0.5)


def idle_load_balancer(asset: Asset, config: dict) -> bool:
    return asset.service in {"elb", "azure_lb"} and _safe_float(asset.metadata.get("request_count_30d"), 1) <= _safe_float(
        config.get("max_request_count_30d"), 0
    )


def unattached_volume(asset: Asset, config: dict) -> bool:
    return asset.service in {"ebs", "disk"} and not bool(asset.metadata.get("attached", True))


def orphaned_snapshot(asset: Asset, config: dict) -> bool:
    return asset.service == "snapshot" and not bool(asset.metadata.get("source_volume_exists", True))


def missing_required_tags(asset: Asset, config: dict) -> bool:
    required_tags = {tag.lower() for tag in config.get("required_tags", [])}
    actual_tags = {k.lower() for k in asset.tags.keys()}
    return not required_tags.issubset(actual_tags)


def no_resource_owner(asset: Asset, config: dict) -> bool:
    owner_tags = {tag.lower() for tag in config.get("owner_tags", ["owner", "service_owner"])}
    actual_tags = {k.lower() for k in asset.tags.keys()}
    return len(owner_tags.intersection(actual_tags)) == 0


def no_cost_allocation_tags(asset: Asset, config: dict) -> bool:
    tags = {tag.lower() for tag in config.get("cost_tags", ["cost_center", "billing_code"])}
    actual_tags = {k.lower() for k in asset.tags.keys()}
    return len(tags.intersection(actual_tags)) == 0


def no_autoscaling(asset: Asset, config: dict) -> bool:
    return asset.service in {"ec2", "vm"} and bool(asset.metadata.get("is_critical", False)) and not bool(
        asset.metadata.get("autoscaling_enabled", False)
    )


def weak_storage_redundancy(asset: Asset, config: dict) -> bool:
    if asset.service not in {"storage", "s3"}:
        return False
    accepted = set(config.get("accepted_redundancy", ["grs", "zrs", "multi-az"]))
    redundancy = str(asset.metadata.get("redundancy", "unknown")).lower()
    return redundancy not in accepted


def recommendation_signal_present(asset: Asset, config: dict) -> bool:
    expected_category = str(config.get("recommendation_category", "")).strip().lower()
    signal_category = str(asset.metadata.get("recommendation_category", "")).strip().lower()
    if expected_category and signal_category != expected_category:
        return False
    return bool(asset.metadata.get("signal_present", False))


def default_vpc_present(asset: Asset, config: dict) -> bool:
    return asset.service == "network" and bool(asset.metadata.get("default_vpc_present", False))


def dedicated_workload_vpc_missing(asset: Asset, config: dict) -> bool:
    if asset.service != "network":
        return False
    return not bool(asset.metadata.get("dedicated_workload_vpc_present", False))


def incomplete_subnet_segmentation(asset: Asset, config: dict) -> bool:
    if asset.service != "network":
        return False
    if not bool(asset.metadata.get("dedicated_workload_vpc_present", False)):
        return False
    app_data_az_count = int(asset.metadata.get("app_data_az_count", 0) or 0)
    subnet_tier_count = int(asset.metadata.get("subnet_tier_count", 0) or 0)
    min_az_count = int(config.get("min_az_count", 2))
    min_tier_count = int(config.get("min_tier_count", 2))
    return app_data_az_count < min_az_count or subnet_tier_count < min_tier_count


def managed_egress_path_missing(asset: Asset, config: dict) -> bool:
    if asset.service != "network":
        return False
    if not bool(asset.metadata.get("dedicated_workload_vpc_present", False)):
        return False
    return not bool(asset.metadata.get("managed_egress_path_defined", False))


def landing_zone_prerequisites_incomplete(asset: Asset, config: dict) -> bool:
    if asset.service != "network":
        return False
    return not bool(asset.metadata.get("landing_zone_ready", False))


def password_policy_weak(asset: Asset, config: dict) -> bool:
    if asset.service != "iam_password_policy":
        return False
    min_len = int(asset.metadata.get("minimum_password_length", 0))
    return min_len < 14


def password_policy_no_uppercase(asset: Asset, config: dict) -> bool:
    if asset.service != "iam_password_policy":
        return False
    return not bool(asset.metadata.get("require_uppercase", False))


def password_policy_no_lowercase(asset: Asset, config: dict) -> bool:
    if asset.service != "iam_password_policy":
        return False
    return not bool(asset.metadata.get("require_lowercase", False))


def password_policy_no_symbol(asset: Asset, config: dict) -> bool:
    if asset.service != "iam_password_policy":
        return False
    return not bool(asset.metadata.get("require_symbols", False))


def password_policy_no_number(asset: Asset, config: dict) -> bool:
    if asset.service != "iam_password_policy":
        return False
    return not bool(asset.metadata.get("require_numbers", False))


def password_policy_reuse(asset: Asset, config: dict) -> bool:
    if asset.service != "iam_password_policy":
        return False
    reuse = int(asset.metadata.get("password_reuse_prevention", 0))
    return reuse < 24


def root_access_keys_exist(asset: Asset, config: dict) -> bool:
    if asset.service != "iam_account":
        return False
    return bool(asset.metadata.get("root_access_keys_present", False))


def cloudtrail_not_enabled(asset: Asset, config: dict) -> bool:
    if asset.service != "cloudtrail":
        return False
    return not bool(asset.metadata.get("trail_exists", False))


def cloudtrail_validation_disabled(asset: Asset, config: dict) -> bool:
    if asset.service != "cloudtrail":
        return False
    if not bool(asset.metadata.get("trail_exists", False)):
        return False
    return not bool(asset.metadata.get("log_file_validation_enabled", False))


def single_az_load_balancer(asset: Asset, config: dict) -> bool:
    if asset.service != "elb":
        return False
    az_count = int(asset.metadata.get("availability_zone_count", 0))
    return az_count < 2

def vpc_flow_logs_disabled(asset: Asset, config: dict) -> bool:
    return asset.service == "network" and not bool(asset.metadata.get("flow_logs_enabled", False))
def iam_users_without_mfa(asset: Asset, config: dict) -> bool:
    return asset.service == "iam_account" and int(asset.metadata.get("iam_users", 0)) > int(asset.metadata.get("iam_users_mfa", 0))
def cloudwatch_alarms_missing(asset: Asset, config: dict) -> bool:
    return asset.service == "cloudwatch" and not bool(asset.metadata.get("alarms_configured", False))

EVALUATORS: dict[str, Evaluator] = {**AWS_EVALUATORS,
    "has_wildcard_permissions": has_wildcard_permissions,
    "is_admin_role": is_admin_role,
    "missing_mfa_enforcement": missing_mfa_enforcement,
    "public_access_enabled": public_access_enabled,
    "encryption_disabled": encryption_disabled,
    "versioning_disabled": versioning_disabled,
    "backup_not_enabled": backup_not_enabled,
    "single_az_deployment": single_az_deployment,
    "missing_lifecycle_policy": missing_lifecycle_policy,
    "unrestricted_ingress_admin_ports": unrestricted_ingress_admin_ports,
    "unrestricted_ingress_any_port": unrestricted_ingress_any_port,
    "underutilized_compute": underutilized_compute,
    "overprovisioned_storage": overprovisioned_storage,
    "idle_load_balancer": idle_load_balancer,
    "unattached_volume": unattached_volume,
    "orphaned_snapshot": orphaned_snapshot,
    "missing_required_tags": missing_required_tags,
    "no_resource_owner": no_resource_owner,
    "no_cost_allocation_tags": no_cost_allocation_tags,
    "no_autoscaling": no_autoscaling,
    "weak_storage_redundancy": weak_storage_redundancy,
    "recommendation_signal_present": recommendation_signal_present,
    "default_vpc_present": default_vpc_present,
    "dedicated_workload_vpc_missing": dedicated_workload_vpc_missing,
    "incomplete_subnet_segmentation": incomplete_subnet_segmentation,
    "managed_egress_path_missing": managed_egress_path_missing,
    "landing_zone_prerequisites_incomplete": landing_zone_prerequisites_incomplete,
    "password_policy_weak": password_policy_weak,
    "password_policy_no_uppercase": password_policy_no_uppercase,
    "password_policy_no_lowercase": password_policy_no_lowercase,
    "password_policy_no_symbol": password_policy_no_symbol,
    "password_policy_no_number": password_policy_no_number,
    "password_policy_reuse": password_policy_reuse,
    "root_access_keys_exist": root_access_keys_exist,
    "cloudtrail_not_enabled": cloudtrail_not_enabled,
    "cloudtrail_validation_disabled": cloudtrail_validation_disabled,
    "single_az_load_balancer": single_az_load_balancer,
    "vpc_flow_logs_disabled": vpc_flow_logs_disabled,
    "iam_users_without_mfa": iam_users_without_mfa,
    "cloudwatch_alarms_missing": cloudwatch_alarms_missing,
}
