# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from collections.abc import Callable

from hybrisight.models import Asset

AwsEvaluator = Callable[[Asset, dict], bool]


def kms_key_rotation_disabled(asset: Asset, config: dict) -> bool:
    if asset.service != "kms":
        return False
    if asset.metadata.get("key_manager", "") == "AWS":
        return False
    return not bool(asset.metadata.get("key_rotation_enabled", False))


def log_group_encryption_disabled(asset: Asset, config: dict) -> bool:
    return asset.service == "log_group" and not bool(asset.metadata.get("encrypted", False))


def log_group_retention_missing(asset: Asset, config: dict) -> bool:
    if asset.service != "log_group":
        return False
    retention = asset.metadata.get("retention_in_days")
    if retention is None:
        return True
    return retention < 365


def ecs_cluster_unused(asset: Asset, config: dict) -> bool:
    return asset.service == "ecs" and int(asset.metadata.get("running_tasks_count", 0)) == 0


def eks_endpoint_public_access(asset: Asset, config: dict) -> bool:
    return asset.service == "eks" and bool(asset.metadata.get("endpoint_public_access", True))


def ade_not_enabled(asset: Asset, config: dict) -> bool:
    return asset.service in {"disk"} and not bool(asset.metadata.get("ade_enabled", True))


AWS_EVALUATORS: dict[str, AwsEvaluator] = {
    "kms_key_rotation_disabled": kms_key_rotation_disabled,
    "log_group_encryption_disabled": log_group_encryption_disabled,
    "log_group_retention_missing": log_group_retention_missing,
    "ecs_cluster_unused": ecs_cluster_unused,
    "eks_endpoint_public_access": eks_endpoint_public_access,
    "ade_not_enabled": ade_not_enabled,
}
