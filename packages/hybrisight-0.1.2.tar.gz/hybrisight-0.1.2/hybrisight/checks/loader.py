# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, Field


class RuleDefinition(BaseModel):
    id: str
    provider: str = "*"
    title: str
    category: str
    severity: str
    service: str
    evaluator: str
    description: str
    business_impact: str
    remediation_guidance: str
    remediation_effort: str
    estimated_annual_cost_impact_gbp: float | None = None
    config: dict = Field(default_factory=dict)


def load_rules(rules_dir: Path) -> list[RuleDefinition]:
    rules: list[RuleDefinition] = []
    for path in sorted(rules_dir.glob("*.yaml")):
        raw = yaml.safe_load(path.read_text())
        rules.append(RuleDefinition(**raw))
    return rules
