# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from math import exp, sqrt
from typing import Any

from hybrisight.models import CoverageLevel, Finding
from hybrisight.scoring_constants import CALIBRATION_K, COVERAGE_MULTIPLIERS
from hybrisight.scoring_priority import assign_roadmap_phase, finding_impact_score


def _scores_from_total_impact(total_impact: float, asset_count: int, coverage_level: CoverageLevel) -> dict[str, float]:
    size_norm = sqrt(max(asset_count, 1))
    norm_total = total_impact / size_norm
    risk_index = 100.0 * (1.0 - exp(-norm_total / CALIBRATION_K))
    posture_score = 10.0 * (1.0 - (risk_index / 100.0))
    confidence_adjusted_score = posture_score * COVERAGE_MULTIPLIERS[coverage_level.value]
    return {
        "risk_index": round(risk_index, 1),
        "posture_score": round(posture_score, 1),
        "confidence_adjusted_score": round(confidence_adjusted_score, 1),
    }


def build_cumulative_phase_projection(
    prioritized_findings: list[Finding],
    asset_count: int,
    coverage_level: CoverageLevel,
) -> dict[str, Any]:
    phase_order = ["30_days", "60_days", "90_days"]
    phase_key_map = {"30_days": "d30", "60_days": "d60", "90_days": "d90"}

    total_impact = sum(finding_impact_score(finding) for finding in prioritized_findings)
    total_estimated_waste = sum(float(finding.estimated_annual_cost_impact_gbp or 0.0) for finding in prioritized_findings)

    phase_impact = {key: 0.0 for key in phase_order}
    phase_cost_reduction = {key: 0.0 for key in phase_order}
    for finding in prioritized_findings:
        phase = assign_roadmap_phase(finding)
        phase_impact[phase] += finding_impact_score(finding)
        phase_cost_reduction[phase] += float(finding.estimated_annual_cost_impact_gbp or 0.0)

    current_scores = _scores_from_total_impact(total_impact, asset_count, coverage_level)
    projection: dict[str, Any] = {
        "now": {**current_scores, "estimated_waste": round(total_estimated_waste, 2)},
        "d30": {},
        "d60": {},
        "d90": {},
        "disclaimer": "Projection assumes full remediation of listed themes within this phase.",
    }

    remaining_impact = total_impact
    cumulative_cost_reduction = 0.0
    for phase in phase_order:
        remaining_impact = max(0.0, remaining_impact - phase_impact[phase])
        cumulative_cost_reduction += phase_cost_reduction[phase]
        scores = _scores_from_total_impact(remaining_impact, asset_count, coverage_level)
        key = phase_key_map[phase]
        projection[key] = {
            **scores,
            "estimated_waste": round(max(0.0, total_estimated_waste - cumulative_cost_reduction), 2),
            "phase_cost_reduction": round(phase_cost_reduction[phase], 2),
            "cumulative_cost_reduction": round(cumulative_cost_reduction, 2),
            "delta_risk": round(float(current_scores["risk_index"]) - float(scores["risk_index"]), 1),
            "delta_posture": round(float(scores["posture_score"]) - float(current_scores["posture_score"]), 1),
        }

    projection["projected_posture_improvement_90d"] = round(
        float(projection["d90"]["posture_score"]) - float(projection["now"]["posture_score"]),
        1,
    )
    return projection


def build_posture_trajectory_svg(phase_projection: dict[str, Any]) -> str:
    posture_points = [
        ("Now", float(phase_projection["now"]["posture_score"])),
        ("30d", float(phase_projection["d30"]["posture_score"])),
        ("60d", float(phase_projection["d60"]["posture_score"])),
        ("90d", float(phase_projection["d90"]["posture_score"])),
    ]
    risk_points = [
        ("Now", float(phase_projection["now"]["risk_index"])),
        ("30d", float(phase_projection["d30"]["risk_index"])),
        ("60d", float(phase_projection["d60"]["risk_index"])),
        ("90d", float(phase_projection["d90"]["risk_index"])),
    ]

    width, height = 720, 150
    left, right, top, bottom = 36, 20, 10, 34
    chart_w = width - left - right
    chart_h = height - top - bottom

    def x_at(index: int) -> float:
        return left + (chart_w * index / max(len(posture_points) - 1, 1))

    def y_at_posture(value: float) -> float:
        clamped = min(10.0, max(0.0, value))
        return top + (chart_h * (1.0 - (clamped / 10.0)))

    def y_at_risk(value: float) -> float:
        clamped = min(100.0, max(0.0, value))
        return top + (chart_h * (1.0 - (clamped / 100.0)))

    posture_path = " ".join(f"{x_at(i):.2f},{y_at_posture(v):.2f}" for i, (_, v) in enumerate(posture_points))
    risk_path = " ".join(f"{x_at(i):.2f},{y_at_risk(v):.2f}" for i, (_, v) in enumerate(risk_points))

    y_ticks = [0.0, 5.0, 10.0]
    grid = []
    for tick in y_ticks:
        y = y_at_posture(tick)
        grid.append(f'<line x1="{left}" y1="{y:.2f}" x2="{width-right}" y2="{y:.2f}" stroke="#e2e8f0" stroke-width="1" />')
        grid.append(f'<text x="{left-6}" y="{y+4:.2f}" text-anchor="end" font-size="10" fill="#64748b">{tick:g}</text>')

    labels, posture_circles, risk_circles = [], [], []
    for i, (label, posture_value) in enumerate(posture_points):
        x = x_at(i)
        y_posture = y_at_posture(posture_value)
        y_risk = y_at_risk(risk_points[i][1])
        posture_circles.append(f'<circle cx="{x:.2f}" cy="{y_posture:.2f}" r="3.5" fill="#0f172a" />')
        risk_circles.append(f'<circle class="trajectory-risk" cx="{x:.2f}" cy="{y_risk:.2f}" r="3" fill="#64748b" style="display:none;" />')
        labels.append(f'<text x="{x:.2f}" y="{height-10}" text-anchor="middle" font-size="11" fill="#64748b">{label}</text>')

    return (
        f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="Posture trajectory chart" preserveAspectRatio="none" style="width:100%; height:120px;">'
        + "".join(grid)
        + f'<polyline fill="none" stroke="#0f172a" stroke-width="2" points="{posture_path}" />'
        + f'<polyline class="trajectory-risk" fill="none" stroke="#64748b" stroke-width="1.5" stroke-dasharray="5 4" points="{risk_path}" style="display:none;" />'
        + "".join(posture_circles)
        + "".join(risk_circles)
        + "".join(labels)
        + "</svg>"
    )
