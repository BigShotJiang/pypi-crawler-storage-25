# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

COMPLIANCE_DIR = Path(__file__).resolve().parent / "compliance_data"


@lru_cache(maxsize=None)
def _load_framework(name: str) -> dict[str, Any] | None:
    fpath = COMPLIANCE_DIR / f"{name}.yaml"
    if not fpath.exists():
        return None
    with fpath.open(encoding="utf-8") as f:
        return yaml.safe_load(f)


@lru_cache(maxsize=1)
def load_all_frameworks() -> dict[str, dict[str, Any]]:
    frameworks: dict[str, dict[str, Any]] = {}
    for fname in sorted(os.listdir(COMPLIANCE_DIR)):
        if not fname.endswith(".yaml"):
            continue
        data = _load_framework(fname.removesuffix(".yaml"))
        if data:
            key = data["framework"]["name"]
            frameworks[key] = data
    return frameworks


def compute_coverage(frameworks: dict[str, dict], rule_ids: set[str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for fw_name, fw_data in frameworks.items():
        fw_controls = fw_data.get("controls", {})
        fw_rules = fw_data.get("rules", {})
        total = len(fw_controls)
        covered_controls: set[str] = set()
        for rid in rule_ids:
            mapped = fw_rules.get(rid, [])
            covered_controls.update(mapped)
        covered_count = len(covered_controls)
        coverage_pct = round(covered_count / total * 100) if total > 0 else 0
        result[fw_name] = {
            "version": fw_data["framework"].get("version", ""),
            "total_controls": total,
            "covered_controls": covered_count,
            "coverage_percent": coverage_pct,
            "applicable_rules": len([r for r in fw_rules if r in rule_ids]),
        }
    return result


def compute_coverage_detailed(
    frameworks: dict[str, dict],
    findings_by_id: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Return per-framework control-to-finding mappings for compliance drill-down."""
    results: list[dict[str, Any]] = []
    for fw_name, fw_data in frameworks.items():
        fw_controls = fw_data.get("controls", {})
        fw_rules = fw_data.get("rules", {})
        framework_controls: list[dict[str, Any]] = []
        scanned_rule_ids = set(findings_by_id.keys())

        for control_id, control_desc in fw_controls.items():
            # Find which rules map to this control
            mapped_rules: list[dict[str, Any]] = []
            is_covered = False
            for rule_id, control_list in fw_rules.items():
                if control_id not in control_list:
                    continue
                is_covered = True
                finding = findings_by_id.get(rule_id)
                mapped_rules.append({
                    "rule_id": rule_id,
                    "title": finding.get("title", rule_id) if finding else rule_id,
                    "severity": finding.get("severity", "info") if finding else "info",
                    "category": finding.get("category", "") if finding else "",
                    "impact": finding.get("business_impact", "") if finding else "",
                    "scanned": rule_id in scanned_rule_ids,
                })

            framework_controls.append({
                "control_id": control_id,
                "description": control_desc,
                "status": "covered" if is_covered else "uncovered",
                "mapped_rules": mapped_rules,
            })

        results.append({
            "framework": fw_name,
            "version": fw_data["framework"].get("version", ""),
            "color": fw_data["framework"].get("color", "var(--accent)"),
            "controls": framework_controls,
        })
    return results
