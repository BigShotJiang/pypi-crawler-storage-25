# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from typing import Any

from hybrisight.engine_context_assessment import classify_assessment
from hybrisight.scoring import SEVERITY_WEIGHTS

from hybrisight.cli_helpers_profile import _discover_enabled_aws_regions, _parse_aws_regions_option, _safe_echo
from hybrisight.providers.errors import CollectorError


def _summarize_error_text(detail: str, max_len: int = 180) -> str:
    text = " ".join((detail or "").split())
    if not text:
        return ""
    return text if len(text) <= max_len else text[: max_len - 3] + "..."


def _diagnostic_status_label(status: str) -> str:
    if status in {"collected", "available_no_findings"}:
        return "[OK]"
    if status in {"demo_mode", "unknown"}:
        return "[INFO]"
    return "[WARN]"


def _summarize_diagnostic_detail(detail: str) -> str:
    if not detail:
        return ""
    text = " ".join(detail.split())
    if "AccessDeniedException" in text and "support:DescribeTrustedAdvisorChecks" in text:
        return "Access denied to Trusted Advisor support API."
    if "SubscriptionRequiredException" in text and "DescribeTrustedAdvisorChecks" in text:
        return "Trusted Advisor requires eligible AWS support subscription."
    if "No GuardDuty detectors returned" in text:
        return "No detectors found in selected region(s)."
    if "ce:GetCostAndUsage" in text or "Cost Explorer" in text:
        return "Cost Explorer API unavailable or access denied."
    return text if len(text) <= 140 else text[:137] + "..."


def _collection_quality(signals: dict[str, Any]) -> dict[str, Any]:
    statuses = [str((meta or {}).get("status", "unknown")) for meta in signals.values() if isinstance(meta, dict)]
    unavailable = [name for name, meta in signals.items() if isinstance(meta, dict) and str(meta.get("status", "")) in {"unavailable", "not_enabled_or_no_detectors"}]
    positive = [name for name, meta in signals.items() if isinstance(meta, dict) and str(meta.get("status", "")) in {"collected", "available_no_findings", "available_no_instances"}]
    demo = [name for name, meta in signals.items() if isinstance(meta, dict) and str(meta.get("status", "")) == "demo_mode"]

    if demo and len(demo) == len(statuses):
        return {
            "quality": "demo",
            "label": "Demo",
            "summary": "Demo collection path used. Cloud APIs were not queried.",
            "unavailable_signals": [],
            "positive_signals": [],
        }
    if unavailable and not positive:
        return {
            "quality": "limited",
            "label": "Limited",
            "summary": "Artifact generated, but strategic signal completeness is limited.",
            "unavailable_signals": unavailable,
            "positive_signals": positive,
        }
    if unavailable:
        return {
            "quality": "partial",
            "label": "Partial",
            "summary": "Core scan completed, but some strategic signal sources were unavailable.",
            "unavailable_signals": unavailable,
            "positive_signals": positive,
        }
    return {
        "quality": "full",
        "label": "Full",
        "summary": "Core scan completed with available strategic signal sources.",
        "unavailable_signals": [],
        "positive_signals": positive,
    }


def _annotate_collection_diagnostics(diagnostics: dict[str, Any] | None) -> dict[str, Any] | None:
    if not diagnostics:
        return diagnostics
    signals = diagnostics.get("signals")
    if not isinstance(signals, dict) or not signals:
        return diagnostics
    diagnostics["summary"] = _collection_quality(signals)
    return diagnostics


def _recommended_output(result: Any) -> dict[str, str]:
    findings = list(getattr(result, "findings", []) or [])
    services_observed = sorted({str(getattr(finding, "service", "")).upper() for finding in findings if getattr(finding, "service", None)})
    severity_counts = {key: 0 for key in SEVERITY_WEIGHTS.keys()}
    unique_finding_ids = set()
    for finding in findings:
        severity = str(getattr(getattr(finding, "severity", None), "value", getattr(finding, "severity", "")) or "").lower()
        if severity in severity_counts:
            severity_counts[severity] += 1
        unique_finding_ids.add(str(getattr(finding, "id", "")))
    summary = ((getattr(result, "collection_diagnostics", None) or {}).get("summary") or {}) if isinstance(getattr(result, "collection_diagnostics", None), dict) else {}
    assessment = classify_assessment(
        provider=str(getattr(getattr(result, "scanned_provider", None), "value", getattr(result, "scanned_provider", "unknown"))),
        asset_count=int(getattr(result, "asset_count", 0) or 0),
        unique_findings=len(unique_finding_ids),
        services_observed=services_observed,
        strategic_signal_quality=str(summary.get("quality") or "full"),
        critical_count=severity_counts["critical"],
        high_count=severity_counts["high"],
    )
    return {
        "type": str(assessment.get("type") or "baseline"),
        "label": str(assessment.get("label") or "Governance Brief"),
        "signal_sufficiency": str(assessment.get("signal_sufficiency") or "baseline_ready"),
        "use_case": str(assessment.get("use_case") or "Board-grade governance and stabilisation planning"),
        "summary": str(assessment.get("summary") or ""),
    }


def _annotate_recommended_output(result: Any) -> dict[str, Any] | None:
    diagnostics = getattr(result, "collection_diagnostics", None)
    if not isinstance(diagnostics, dict):
        diagnostics = {}
        result.collection_diagnostics = diagnostics
    diagnostics["recommended_output"] = _recommended_output(result)
    return diagnostics


def _print_collection_diagnostics_summary(diagnostics: dict[str, Any] | None) -> None:
    if not diagnostics:
        return
    signals = diagnostics.get("signals")
    if not isinstance(signals, dict) or not signals:
        return
    summary = _collection_quality(signals)

    _safe_echo("Signal Coverage")
    _safe_echo("----------------")
    _safe_echo(f"Summary: {summary['summary']}")
    unavailable_sources: list[str] = []
    for name, meta in signals.items():
        if not isinstance(meta, dict):
            continue
        status = str(meta.get("status", "unknown"))
        detail = _summarize_diagnostic_detail(str(meta.get("detail", "")).strip())
        _safe_echo(f"{_diagnostic_status_label(status)} {name}: {status}" + (f" - {detail}" if detail else ""))
        if status in {"unavailable", "not_enabled_or_no_detectors"}:
            unavailable_sources.append(name)

    if unavailable_sources:
        _safe_echo("")
        _safe_echo("Impact")
        _safe_echo("------")
        _safe_echo("Executive brief remains valid. Some optimisation and advisory recommendations may be narrower due to reduced signal coverage.", err=True)
        _safe_echo("")
        _safe_echo("Operator Notes")
        _safe_echo("--------------")
        if "trusted_advisor" in unavailable_sources:
            detail = str((signals.get("trusted_advisor") or {}).get("detail", ""))
            if "SubscriptionRequiredException" in detail:
                _safe_echo("Trusted Advisor API requires eligible support subscription (Business/Enterprise).", err=True)
            else:
                _safe_echo("Add `support:DescribeTrustedAdvisorChecks` and `support:DescribeTrustedAdvisorCheckResult`.", err=True)
        if "guardduty" in unavailable_sources:
            _safe_echo("Enable GuardDuty detector in-region or grant `guardduty:ListDetectors` access.", err=True)
        if "advisor" in unavailable_sources:
            _safe_echo("Confirm Azure Advisor read access to recommendations API.", err=True)
        if "defender" in unavailable_sources:
            _safe_echo("Confirm Defender for Cloud assessment read access.", err=True)
        if "cost_explorer" in unavailable_sources:
            _safe_echo("Add `ce:GetCostAndUsage` for AWS Cost Explorer spend signals.", err=True)
        if "cost_management" in unavailable_sources:
            _safe_echo("Grant Azure Cost Management query read access.", err=True)


def _run_doctor_check(name: str, fn: Any, required: bool = True) -> dict[str, Any]:
    try:
        fn()
        return {"name": name, "ok": True, "detail": "ok", "required": required}
    except Exception as exc:
        return {"name": name, "ok": False, "detail": str(exc), "required": required}


def _doctor_aws(profile: str | None, regions: str) -> dict[str, Any]:
    try:
        import boto3
        from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError
    except ImportError as exc:
        raise CollectorError("AWS dependencies missing. Install project dependencies first.") from exc

    try:
        session = boto3.Session(profile_name=profile) if profile else boto3.Session()
        identity = session.client("sts").get_caller_identity()
    except NoCredentialsError as exc:
        raise CollectorError("AWS credentials not found. Configure profile or temporary environment credentials.") from exc
    except (BotoCoreError, ClientError) as exc:
        raise CollectorError(f"AWS authentication failed: {exc}") from exc

    region_list = _parse_aws_regions_option(regions)
    primary_region = region_list[0] if region_list else (_discover_enabled_aws_regions(session) or ["us-east-1"])[0]
    iam = session.client("iam")
    s3 = session.client("s3")
    ec2 = session.client("ec2", region_name=primary_region)
    checks = [
        _run_doctor_check("iam:GetAccountSummary", lambda: iam.get_account_summary()),
        _run_doctor_check("iam:ListRoles", lambda: iam.list_roles(MaxItems=1)),
        _run_doctor_check("s3:ListAllMyBuckets", lambda: s3.list_buckets()),
        _run_doctor_check("ec2:DescribeInstances", lambda: ec2.describe_instances(MaxResults=5)),
        _run_doctor_check("ec2:DescribeSecurityGroups", lambda: ec2.describe_security_groups(MaxResults=5)),
        _run_doctor_check("cloudwatch:GetMetricStatistics (optional)", lambda: session.client("cloudwatch", region_name=primary_region).get_metric_statistics(Namespace="AWS/EC2", MetricName="CPUUtilization", Dimensions=[{"Name": "InstanceId", "Value": "i-00000000000000000"}], StartTime=datetime.now(UTC).replace(microsecond=0) - timedelta(days=1), EndTime=datetime.now(UTC).replace(microsecond=0), Period=3600, Statistics=["Average"]), required=False),
        _run_doctor_check("ce:GetCostAndUsage (optional)", lambda: session.client("ce", region_name="us-east-1").get_cost_and_usage(TimePeriod={"Start": (datetime.now(UTC).date() - timedelta(days=1)).isoformat(), "End": datetime.now(UTC).date().isoformat()}, Granularity="DAILY", Metrics=["UnblendedCost"]), required=False),
        _run_doctor_check("support:DescribeTrustedAdvisorChecks (optional)", lambda: session.client("support", region_name="us-east-1").describe_trusted_advisor_checks(language="en"), required=False),
        _run_doctor_check("guardduty:ListDetectors (optional)", lambda: session.client("guardduty", region_name=primary_region).list_detectors(), required=False),
    ]
    return {"identity": {"account_id": identity.get("Account", "unknown"), "principal": identity.get("Arn", "unknown"), "region": primary_region}, "checks": checks}


def _doctor_azure(tenant: str | None, subscription_id: str | None) -> dict[str, Any]:
    try:
        from azure.identity import DefaultAzureCredential
        from azure.mgmt.compute import ComputeManagementClient
        from azure.mgmt.network import NetworkManagementClient
        from azure.mgmt.resource import ResourceManagementClient
        from azure.mgmt.storage import StorageManagementClient
        from azure.mgmt.subscription import SubscriptionClient
    except ImportError as exc:
        raise CollectorError(f"Azure dependencies missing: {exc}") from exc

    credential = DefaultAzureCredential(exclude_interactive_browser_credential=False)
    selected_subscription = subscription_id
    try:
        sub_client = SubscriptionClient(credential)
        if not selected_subscription:
            subscriptions = list(sub_client.subscriptions.list())
            if not subscriptions:
                raise CollectorError("No Azure subscriptions available for current credentials.")
            selected_subscription = subscriptions[0].subscription_id
        sub_details = sub_client.subscriptions.get(selected_subscription)
    except Exception as exc:
        raise CollectorError(f"Azure authentication failed: {exc}") from exc

    resources = ResourceManagementClient(credential, selected_subscription)
    storage = StorageManagementClient(credential, selected_subscription)
    compute = ComputeManagementClient(credential, selected_subscription)
    network = NetworkManagementClient(credential, selected_subscription)
    checks = [
        _run_doctor_check("resources:List", lambda: next(iter(resources.resources.list()), None)),
        _run_doctor_check("compute:VirtualMachinesListAll", lambda: next(iter(compute.virtual_machines.list_all()), None)),
        _run_doctor_check("network:NetworkSecurityGroupsListAll", lambda: next(iter(network.network_security_groups.list_all()), None)),
        _run_doctor_check("storage:StorageAccountsList", lambda: next(iter(storage.storage_accounts.list()), None)),
    ]
    return {"identity": {"subscription_id": selected_subscription, "subscription_name": getattr(sub_details, "display_name", "unknown"), "tenant_id": tenant or os.environ.get("AZURE_TENANT_ID", "default")}, "checks": checks}
