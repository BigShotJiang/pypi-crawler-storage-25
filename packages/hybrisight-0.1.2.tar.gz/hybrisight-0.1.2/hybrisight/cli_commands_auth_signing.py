# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import os
from pathlib import Path

import httpx
import typer

from hybrisight.cli_helpers import (
    _load_profile,
    _normalize_url,
    _print_section,
    _save_profile,
    _status_context,
    _summarize_error_text,
    _write_text_file,
)
from hybrisight.signing import generate_ed25519_keypair_pem, sign_scan_result


def provision_api_key_via_login(url: str, email: str, password: str, key_name: str) -> str:
    with httpx.Client() as client:
        resp = client.post(f"{url}/api/v1/auth/login", data={"username": email, "password": password})
        resp.raise_for_status()
        session_token = resp.json()["access_token"]

        resp = client.post(
            f"{url}/api/v1/account/api-keys",
            headers={"Authorization": f"Bearer {session_token}"},
            json={"name": key_name, "expiry_days": 30},
        )
        resp.raise_for_status()
        return str(resp.json()["api_key"])


def auth_login_cmd(url: str | None, email: str, password: str, key_name: str) -> None:
    _print_section("Portal Login")
    resolved_url = _normalize_url(url or os.environ.get("HYBRISIGHT_URL") or _load_profile()["portal"].get("url") or "http://localhost:8000")
    try:
        with _status_context(f"Logging in to {resolved_url}"):
            api_key = provision_api_key_via_login(resolved_url, email, password, key_name)
        
        profile = _load_profile()
        profile["portal"]["url"] = resolved_url
        profile["api_keys"][resolved_url] = api_key
        _save_profile(profile)
        typer.echo(f"Success! Authenticated to {resolved_url}")
        typer.echo(f"Scoped API key stored in local profile: {profile['_path'] if '_path' in profile else '~/.config/hybrisight/config.json'}")
    except Exception as exc:
        typer.secho(f"Login failed: {_summarize_error_text(str(exc))}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


def signing_init_cmd(private_key_file: Path, public_key_file: Path, force: bool) -> None:
    _print_section("Key Generation")
    if private_key_file.exists() and not force:
        typer.echo(f"Error: Private key already exists at {private_key_file}. Use --force to overwrite.", err=True)
        raise typer.Exit(code=1)

    private_key_pem, public_key_pem, _key_id = generate_ed25519_keypair_pem()
    _write_text_file(private_key_file, private_key_pem, 0o600)
    _write_text_file(public_key_file, public_key_pem, 0o644)

    typer.echo("Generated Ed25519 signing keypair:")
    typer.echo(f"  Private: {private_key_file}")
    typer.echo(f"  Public:  {public_key_file}")
    typer.echo("\nNext: Register your public key with the portal:")
    typer.echo(f"  hybrisight signing register --public-key-file {public_key_file}")


def signing_register_cmd(public_key_file: Path, url: str | None, api_key: str | None, key_id: str | None = None) -> None:
    _print_section("Key Registration")
    if not public_key_file.exists():
        typer.secho(f"Error: Public key file not found: {public_key_file}", fg=typer.colors.RED, err=True)
        typer.echo("Run `hybrisight signing init` first to generate local keys.")
        raise typer.Exit(code=1)

    resolved_url = _normalize_url(url or os.environ.get("HYBRISIGHT_URL") or _load_profile()["portal"].get("url") or "http://localhost:8000")
    resolved_key = api_key or os.environ.get("HYBRISIGHT_API_KEY") or _load_profile()["api_keys"].get(resolved_url)
    if not resolved_key:
        typer.secho("Error: API key required for registration. Provide --api-key or run `hybrisight auth login` first.", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    with _status_context("Registering public key with portal"):
        public_key_pem = public_key_file.read_text().strip()
        payload = {"public_key_pem": public_key_pem}
        if key_id:
            payload["key_id"] = key_id

        try:
            with httpx.Client() as client:
                resp = client.post(
                    f"{resolved_url}/api/v1/account/signing-keys",
                    headers={"X-HybriSight-Api-Key": resolved_key},
                    json=payload,
                )
                resp.raise_for_status()
                result = resp.json()
                typer.echo(f"Success! Public key registered with ID: {result['key_id']}")
                typer.echo("Artifacts signed with your matching private key will now show as 'Verified' in the portal.")
        except Exception as exc:
            typer.secho(f"Registration failed: {_summarize_error_text(str(exc))}", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=1)


def signing_sign_artifact_cmd(input: Path, signature_output: Path, embed_signature: bool, output: Path | None) -> None:
    _print_section("Artifact Signing")
    if not input.exists():
        typer.secho(f"Error: Input artifact not found: {input}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    from hybrisight.web.service_parse import validate_scan_payload
    result = validate_scan_payload(input.read_text())
    
    with _status_context("Signing scan artifact"):
        signature = sign_scan_result(result)
    
    if embed_signature:
        out_path = output or input
        result.signature = signature
        out_path.write_text(result.model_dump_json(indent=2))
        typer.echo(f"Signed artifact saved to: {out_path}")
    
    signature_output.write_text(signature.model_dump_json(indent=2))
    typer.echo(f"Signature sidecar saved to: {signature_output}")
