# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

import typer

from hybrisight.cli_helpers_profile import _load_profile, _normalize_url, _save_profile
from hybrisight.models import ScanResult
from hybrisight.web.service import normalize_native_export


def _resolve_portal_url(url: str | None) -> str:
    if url:
        return _normalize_url(url)
    env_url = __import__("os").environ.get("HYBRISIGHT_PORTAL_URL")
    if env_url:
        return _normalize_url(env_url)
    profile = _load_profile()
    profile_url = profile.get("portal", {}).get("default_url")
    if profile_url:
        return _normalize_url(profile_url)
    return "http://localhost:8080"


def _resolve_api_key(url: str, api_key: str | None) -> str | None:
    if api_key:
        return api_key
    env_key = __import__("os").environ.get("HYBRISIGHT_API_KEY")
    if env_key:
        return env_key
    profile = _load_profile()
    return profile.get("api_keys", {}).get(url)


def _persist_profile_defaults(url: str, api_key: str) -> None:
    profile = _load_profile()
    profile.setdefault("portal", {})["default_url"] = url
    profile.setdefault("api_keys", {})[url] = api_key
    _save_profile(profile)


def _detect_native_export_type(raw: Any) -> tuple[str, str] | None:
    if isinstance(raw, dict):
        if isinstance(raw.get("Findings"), list):
            return ("aws", "aws_security_hub")
        if isinstance(raw.get("checks"), list):
            return ("aws", "aws_trusted_advisor_export")
        if "ResultsByTime" in raw or "rows" in raw:
            return ("aws", "aws_cost_export")
        return None

    if not isinstance(raw, list) or not raw:
        return None
    first = raw[0]
    if not isinstance(first, dict):
        return None
    if "GeneratorId" in first or "AwsAccountId" in first or "ProductArn" in first:
        return ("aws", "aws_security_hub")
    if "finding_id" in first and "type" in first and "severity" in first:
        return ("aws", "aws_guardduty_export")
    if ("checkId" in first or "check_id" in first) and "status" in first:
        return ("aws", "aws_trusted_advisor_export")
    if "recommendationType" in first or "impact" in first:
        return ("azure", "azure_advisor_recommendations")
    if "cost" in first or "Total" in first or "service" in first:
        return ("aws", "aws_cost_export")
    return None


def _provider_for_export(provider: str | None, export_type: str) -> str:
    if provider:
        return provider.lower().strip()
    return "azure" if export_type.startswith("azure_") else "aws"


def _normalize_native_or_exit(raw: Any, raw_text: str, provider: str | None, export_type: str | None) -> ScanResult:
    detected = _detect_native_export_type(raw)
    chosen_export = export_type.strip() if export_type else (detected[1] if detected else None)
    if not chosen_export:
        typer.echo("Error: could not infer native export type. Provide --source-type native-export with --provider and --export-type.", err=True)
        raise typer.Exit(code=1)

    chosen_provider = _provider_for_export(provider, chosen_export)
    try:
        return normalize_native_export(provider=chosen_provider, export_type=chosen_export, payload=raw_text)
    except Exception as exc:
        typer.echo(f"Error normalizing native export: {exc}", err=True)
        raise typer.Exit(code=1)
