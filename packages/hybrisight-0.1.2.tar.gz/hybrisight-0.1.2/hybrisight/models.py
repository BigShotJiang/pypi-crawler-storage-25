# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class Provider(str, Enum):
    aws = "aws"
    azure = "azure"


class Category(str, Enum):
    security = "security"
    cost = "cost"
    resilience = "resilience"
    ops = "ops"


class Severity(str, Enum):
    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"
    info = "info"


class Effort(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"


class CoverageLevel(str, Enum):
    full = "full"
    partial = "partial"
    unknown = "unknown"


class SignatureBlock(BaseModel):
    algorithm: str
    key_id: str
    signature: str


class Asset(BaseModel):
    provider: Provider
    service: str
    resource_id: str
    resource_type: str
    region: str | None = None
    tags: dict[str, str] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class Finding(BaseModel):
    id: str
    provider: Provider
    service: str
    resource_id: str
    title: str
    category: Category
    severity: Severity
    description: str
    business_impact: str
    estimated_annual_cost_impact_gbp: float | None = None
    remediation_guidance: str
    remediation_effort: Effort


class ScanResult(BaseModel):
    schema_version: str = "1.1"
    coverage_level: CoverageLevel = CoverageLevel.unknown
    scoring_version: str = "1.0"
    risk_index: float | None = None
    posture_score: float | None = None
    confidence_adjusted_score: float | None = None
    top_finding_ids: list[str] | None = None
    scanned_provider: Provider
    asset_count: int
    finding_count: int
    findings: list[Finding]
    generated_at_utc: str
    collection_diagnostics: dict[str, Any] | None = None
    continuity: dict[str, Any] | None = None
    signature: SignatureBlock | None = None
