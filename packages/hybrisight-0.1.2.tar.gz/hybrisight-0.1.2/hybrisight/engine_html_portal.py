# SPDX-License-Identifier: Apache-2.0
"""Portal preview HTML block shared by CLI report and app HTML export."""


PORTAL_PREVIEW_HTML = """  <h2>Upgrade to Portal — What It Adds</h2>
  <p class="narrative">The free CLI gives you the diagnosis. The portal adds what a one-off report cannot: proof of improvement, team coordination, and audit-ready evidence.</p>

  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-bottom:16px">
    <div style="background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px">
      <div style="font-size:11px;font-weight:700;margin-bottom:8px;color:var(--accent)">Trend Tracking</div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:6px"><strong>CLI:</strong> Snapshot only — one point in time</div>
      <div style="font-size:11px;color:var(--low)"><strong>Portal:</strong> Quarterly progress, score delta, re-scan comparison</div>
    </div>
    <div style="background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px">
      <div style="font-size:11px;font-weight:700;margin-bottom:8px;color:var(--accent)">Execution Board</div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:6px"><strong>CLI:</strong> List of findings — you track fixes manually</div>
      <div style="font-size:11px;color:var(--low)"><strong>Portal:</strong> Tickets assigned to owners, status tracking (To Do / In Progress / Done), continuity across re-scans</div>
    </div>
    <div style="background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px">
      <div style="font-size:11px;font-weight:700;margin-bottom:8px;color:var(--accent)">Share Links</div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:6px"><strong>CLI:</strong> Email a .html file attachment</div>
      <div style="font-size:11px;color:var(--low)"><strong>Portal:</strong> Time-limited links with configurable expiry, view tracking, revoke anytime</div>
    </div>
    <div style="background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px">
      <div style="font-size:11px;font-weight:700;margin-bottom:8px;color:var(--accent)">Signed Verification</div>
      <div style="font-size:11px;color:var(--muted);margin-bottom:6px"><strong>CLI:</strong> No proof of report integrity</div>
      <div style="font-size:11px;color:var(--low)"><strong>Portal:</strong> Ed25519 cryptographic signature proves authenticity. Auditor-ready.</div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
    <div style="background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px">
      <div style="font-size:11px;font-weight:700;margin-bottom:6px;color:var(--accent)">Execution Board Example</div>
      <div style="font-size:10px;color:var(--muted);margin-bottom:8px">How findings become tracked work during delivery</div>
      <div style="font-size:10.5px;padding:6px 8px;border-radius:6px;margin-bottom:4px;background:#dcfce7;border-left:3px solid var(--low)"><strong>Done</strong> · Lock down public S3 bucket <span style="color:var(--muted)">— 1h · SK</span></div>
      <div style="font-size:10.5px;padding:6px 8px;border-radius:6px;margin-bottom:4px;background:#dbeafe;border-left:3px solid var(--info)"><strong>In Progress</strong> · Enable CloudTrail <span style="color:var(--muted)">— 30m · JD</span></div>
      <div style="font-size:10.5px;padding:6px 8px;border-radius:6px;margin-bottom:4px;background:#dbeafe;border-left:3px solid var(--info)"><strong>In Progress</strong> · Refactor IAM wildcards <span style="color:var(--muted)">— 3d · SK</span></div>
      <div style="font-size:10.5px;padding:6px 8px;border-radius:6px;background:var(--bg);border-left:3px solid var(--muted)"><strong>To Do</strong> · Enable MFA on all IAM users <span style="color:var(--muted)">— 2h · AL</span></div>
    </div>
    <div style="background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px">
      <div style="font-size:11px;font-weight:700;margin-bottom:6px;color:var(--accent)">Trend Tracker Example</div>
      <div style="font-size:10px;color:var(--muted);margin-bottom:8px">Posture improvement across quarterly re-scans</div>
      <table style="width:100%;font-size:10.5px;border-collapse:collapse">
        <tr style="border-bottom:1px solid var(--line)"><th style="text-align:left;padding:4px 0">Scan</th><th style="text-align:center">Posture</th><th style="text-align:center">Risk</th></tr>
        <tr><td style="padding:3px 0">May 15</td><td style="text-align:center;color:#c2410c;font-weight:700">4.8</td><td style="text-align:center">68</td></tr>
        <tr><td style="padding:3px 0">Jun 15</td><td style="text-align:center;color:#d97706;font-weight:700">6.2</td><td style="text-align:center">42</td></tr>
        <tr><td style="padding:3px 0">Jul 15</td><td style="text-align:center;color:#2563eb;font-weight:700">7.1</td><td style="text-align:center">28</td></tr>
        <tr><td style="padding:3px 0">Aug 15</td><td style="text-align:center;color:var(--low);font-weight:700">8.0</td><td style="text-align:center">15</td></tr>
      </table>
      <div style="margin-top:10px;display:flex;align-items:end;gap:4px;height:40px">
        <div style="flex:1;height:19px;border-radius:2px 2px 0 0;background:#c2410c"></div>
        <div style="flex:1;height:25px;border-radius:2px 2px 0 0;background:#d97706"></div>
        <div style="flex:1;height:28px;border-radius:2px 2px 0 0;background:#2563eb"></div>
        <div style="flex:1;height:32px;border-radius:2px 2px 0 0;background:var(--low)"></div>
      </div>
    </div>
  </div>"""
