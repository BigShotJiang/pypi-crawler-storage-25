# SPDX-License-Identifier: Apache-2.0
"""
AWS on-demand pricing reference (GBP) for common resource types.
Used as fallback when Cost Explorer API data is unavailable.

Prices are based on London (eu-west-2) region. Regional multipliers
are applied for other regions.
"""

REGION_MULTIPLIERS: dict[str, float] = {
    "us-east-1": 0.85,
    "us-east-2": 0.82,
    "us-west-1": 0.92,
    "us-west-2": 0.88,
    "eu-west-1": 0.95,
    "eu-west-2": 1.00,
    "eu-west-3": 0.98,
    "eu-central-1": 1.02,
    "eu-north-1": 0.90,
    "ap-southeast-1": 1.10,
    "ap-southeast-2": 1.08,
    "ap-northeast-1": 1.12,
    "ap-south-1": 0.85,
    "sa-east-1": 1.20,
    "ca-central-1": 0.88,
}

# EC2 on-demand hourly rates (GBP)
EC2_INSTANCE_RATES: dict[str, float] = {
    "t3.nano": 0.0063,
    "t3.micro": 0.0126,
    "t3.small": 0.0252,
    "t3.medium": 0.0504,
    "t3.large": 0.1008,
    "t3.xlarge": 0.2016,
    "t3.2xlarge": 0.4032,
    "t3a.nano": 0.0057,
    "t3a.micro": 0.0114,
    "t3a.small": 0.0227,
    "t3a.medium": 0.0454,
    "t3a.large": 0.0907,
    "t3a.xlarge": 0.1814,
    "t3a.2xlarge": 0.3629,
    "m5.large": 0.1158,
    "m5.xlarge": 0.2316,
    "m5.2xlarge": 0.4632,
    "m5.4xlarge": 0.9264,
    "m5.8xlarge": 1.8528,
    "m5a.large": 0.1042,
    "m5a.xlarge": 0.2084,
    "m5a.2xlarge": 0.4169,
    "m5a.4xlarge": 0.8338,
    "c5.large": 0.1045,
    "c5.xlarge": 0.2090,
    "c5.2xlarge": 0.4180,
    "c5.4xlarge": 0.8360,
    "c5.9xlarge": 1.8810,
    "c5a.large": 0.0940,
    "c5a.xlarge": 0.1881,
    "c5a.2xlarge": 0.3762,
    "r5.large": 0.1524,
    "r5.xlarge": 0.3048,
    "r5.2xlarge": 0.6096,
    "r5.4xlarge": 1.2192,
    "r5a.large": 0.1371,
    "r5a.xlarge": 0.2743,
    "r5a.2xlarge": 0.5486,
    "i3.large": 0.2080,
    "i3.xlarge": 0.4160,
    "i3.2xlarge": 0.8320,
    "i3.4xlarge": 1.6640,
}

# EBS volume monthly rates (GBP per GB)
EBS_RATES: dict[str, float] = {
    "gp3": 0.09,
    "gp2": 0.11,
    "io1": 0.14,
    "io2": 0.14,
    "st1": 0.05,
    "sc1": 0.03,
    "standard": 0.06,
    "snapshot": 0.06,
}

# RDS on-demand hourly rates (GBP)
RDS_INSTANCE_RATES: dict[str, float] = {
    "db.t3.micro": 0.020,
    "db.t3.small": 0.040,
    "db.t3.medium": 0.080,
    "db.t3.large": 0.160,
    "db.r5.large": 0.305,
    "db.r5.xlarge": 0.610,
    "db.r5.2xlarge": 1.220,
    "db.m5.large": 0.231,
    "db.m5.xlarge": 0.462,
    "db.m5.2xlarge": 0.924,
}

# ELB monthly rates (GBP)
ELB_MONTHLY_RATES: dict[str, float] = {
    "application": 24.00,
    "network": 24.00,
    "gateway": 36.00,
    "classic": 20.00,
}

# NAT Gateway monthly rates (GBP)
NAT_GATEWAY_MONTHLY: float = 35.00


def region_multiplier(region: str | None) -> float:
    if region and region.lower() in REGION_MULTIPLIERS:
        return REGION_MULTIPLIERS[region.lower()]
    return 1.0
