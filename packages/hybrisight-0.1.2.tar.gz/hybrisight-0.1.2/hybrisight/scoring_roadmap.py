# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any

from hybrisight.models import Finding
from hybrisight.scoring_constants import SEVERITY_RANK
from hybrisight.scoring_priority import (
    assign_roadmap_phase,
    finding_priority_score,
    resolve_theme,
    workflow_template,
)


def build_roadmap(
    prioritized_findings: list[Finding],
    posture_score: float | None = None,
    max_items_per_phase: int = 5,
) -> dict[str, list[dict[str, Any]]]:
    phase_rule: dict[str, dict[str, dict[str, Any]]] = {"30_days": {}, "60_days": {}, "90_days": {}}

    for finding in prioritized_findings:
        phase = assign_roadmap_phase(finding)
        slot = phase_rule[phase].setdefault(
            finding.id,
            {"finding": finding, "resource_ids": set(), "priority_score": finding_priority_score(finding)},
        )
        slot["resource_ids"].add(finding.resource_id)

    phase_theme: dict[str, dict[str, dict[str, Any]]] = {"30_days": {}, "60_days": {}, "90_days": {}}

    for phase, rules in phase_rule.items():
        for rule_id, item in rules.items():
            finding = item["finding"]
            theme_meta = resolve_theme(finding)
            theme_key = theme_meta["name"]
            group = phase_theme[phase].setdefault(
                theme_key,
                {
                    "theme": theme_meta["name"],
                    "summary": theme_meta["summary"],
                    "business_impact": finding.business_impact,
                    "risk_category": finding.category.value,
                    "severity": finding.severity.value,
                    "rule_ids": set(),
                    "affected_resources": set(),
                    "actions": [],
                    "technical_details": [],
                    "priority_weight": 0.0,
                },
            )
            group["rule_ids"].add(rule_id)
            group["affected_resources"].update(item["resource_ids"])
            group["priority_weight"] += float(item["priority_score"])

            if SEVERITY_RANK[finding.severity.value] > SEVERITY_RANK[group["severity"]]:
                group["severity"] = finding.severity.value
                group["business_impact"] = finding.business_impact
            if finding.remediation_guidance not in group["actions"] and len(group["actions"]) < 3:
                group["actions"].append(finding.remediation_guidance)
            group["technical_details"].append(f"{rule_id} ({len(item['resource_ids'])} resources affected)")

    roadmap: dict[str, list[dict[str, Any]]] = {"30_days": [], "60_days": [], "90_days": []}
    for phase, themes in phase_theme.items():
        entries: list[dict[str, Any]] = []
        for theme in themes.values():
            is_minor_ops = (
                theme["theme"] == "Governance & Ownership Hygiene"
                and SEVERITY_RANK[str(theme["severity"])] <= SEVERITY_RANK["medium"]
            )
            if posture_score is not None and posture_score >= 4.0 and is_minor_ops:
                continue
            affected_count = len(theme["affected_resources"])
            entry = {
                "theme": theme["theme"],
                "summary": theme["summary"],
                "business_impact": theme["business_impact"],
                "risk_category": theme["risk_category"],
                "severity": theme["severity"],
                "rule_count": len(theme["rule_ids"]),
                "affected_resource_count": affected_count,
                "actions": theme["actions"],
                "technical_details": sorted(theme["technical_details"]),
                "priority_weight": round(float(theme["priority_weight"]), 4),
            }
            entry["workflow"] = workflow_template(
                theme=str(entry["theme"]),
                risk_category=str(entry["risk_category"]),
                business_impact=str(entry["business_impact"]),
                actions=list(entry["actions"]),
                affected_resource_count=affected_count,
            )
            entries.append(entry)

        entries = sorted(
            entries,
            key=lambda item: (-float(item["priority_weight"]), -SEVERITY_RANK[str(item["severity"])], str(item["theme"])),
        )
        roadmap[phase] = entries[:max_items_per_phase]

    return roadmap


def build_findings_groups(prioritized_findings: list[Finding]) -> list[dict[str, Any]]:
    theme_rule_groups: dict[str, dict[str, Any]] = {}
    for finding in prioritized_findings:
        theme_meta = resolve_theme(finding)
        theme_name = theme_meta["name"]
        group = theme_rule_groups.setdefault(
            theme_name,
            {
                "theme": theme_name,
                "summary": theme_meta["summary"],
                "severity": finding.severity.value,
                "rule_map": {},
                "affected_resources": set(),
                "occurrence_count": 0,
            },
        )
        group["occurrence_count"] += 1
        if SEVERITY_RANK[finding.severity.value] > SEVERITY_RANK[group["severity"]]:
            group["severity"] = finding.severity.value
        group["affected_resources"].add(finding.resource_id)

        rule_entry = group["rule_map"].setdefault(
            finding.id,
            {
                "id": finding.id,
                "title": finding.title,
                "severity": finding.severity.value,
                "service": finding.service,
                "business_impact": finding.business_impact,
                "remediation_effort": finding.remediation_effort.value,
                "remediation_guidance": finding.remediation_guidance,
                "resources": set(),
                "occurrence_count": 0,
            },
        )
        rule_entry["occurrence_count"] += 1
        rule_entry["resources"].add(finding.resource_id)
        if SEVERITY_RANK[finding.severity.value] > SEVERITY_RANK[rule_entry["severity"]]:
            rule_entry["severity"] = finding.severity.value
            rule_entry["business_impact"] = finding.business_impact

    groups: list[dict[str, Any]] = []
    for group in theme_rule_groups.values():
        rules = sorted(group["rule_map"].values(), key=lambda r: (-SEVERITY_RANK[str(r["severity"])], str(r["id"])))
        serialized_rules = []
        for rule in rules:
            resources = sorted(rule["resources"])
            serialized_rules.append(
                {
                    "id": rule["id"],
                    "title": rule["title"],
                    "severity": rule["severity"],
                    "service": rule["service"],
                    "business_impact": rule["business_impact"],
                    "remediation_effort": rule["remediation_effort"],
                    "remediation_guidance": rule["remediation_guidance"],
                    "affected_resource_count": len(resources),
                    "occurrence_count": int(rule["occurrence_count"]),
                    "sample_resources": resources[:3],
                }
            )
        groups.append(
            {
                "theme": group["theme"],
                "summary": group["summary"],
                "severity": group["severity"],
                "rule_count": len(serialized_rules),
                "affected_resource_count": len(group["affected_resources"]),
                "occurrence_count": int(group["occurrence_count"]),
                "rules": serialized_rules,
            }
        )

    return sorted(
        groups,
        key=lambda g: (-SEVERITY_RANK[str(g["severity"])], -int(g["affected_resource_count"]), str(g["theme"])),
    )
