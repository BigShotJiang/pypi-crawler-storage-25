# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from typing import Any


def classify_assessment(
    *,
    provider: str,
    asset_count: int,
    unique_findings: int,
    services_observed: list[str],
    strategic_signal_quality: str,
    critical_count: int,
    high_count: int,
) -> dict[str, Any]:
    reasons: list[str] = []
    low_signal_flags = 0

    if asset_count < 25:
        reasons.append("Low asset volume indicates a foundation-stage environment.")
        low_signal_flags += 1
    if unique_findings < 8:
        reasons.append("Finding density is too low for a full governance-risk narrative.")
        low_signal_flags += 1
    if len(services_observed) < 4:
        reasons.append("Limited service diversity favors a foundations-first review.")
        low_signal_flags += 1
    if critical_count == 0 and high_count < 3:
        reasons.append("Execution workload is light; immediate must-do controls matter more than phased stabilisation.")
        low_signal_flags += 1
    if strategic_signal_quality in {"limited", "demo"}:
        reasons.append("Strategic signal completeness is limited for a full governance brief.")
        low_signal_flags += 1

    assessment_type = "foundation" if low_signal_flags >= 2 else "baseline"
    signal_sufficiency = "baseline_ready"
    if assessment_type == "foundation":
        signal_sufficiency = "limited" if strategic_signal_quality in {"limited", "demo"} else "foundation_only"

    provider_upper = provider.upper()
    return {
        "type": assessment_type,
        "label": "Foundation Review" if assessment_type == "foundation" else "Governance Brief",
        "package_type": assessment_type,
        "signal_sufficiency": signal_sufficiency,
        "recommended_next_service": "foundation_hardening" if assessment_type == "foundation" else "stabilisation",
        "use_case": (
            "Must-do controls and readiness"
            if assessment_type == "foundation"
            else "Board-grade governance and stabilisation planning"
        ),
        "headline": (
            f"HybriSight Foundation Review ({provider_upper})"
            if assessment_type == "foundation"
            else f"HybriSight Governance Brief ({provider_upper})"
        ),
        "summary": (
            "This environment is best served by a Foundation Review focused on must-do cloud controls and readiness."
            if assessment_type == "foundation"
            else "This environment has enough signal density for a full Governance Brief and execution-led roadmap."
        ),
        "reasons": reasons[:4],
    }


def build_foundation_mapping() -> list[dict[str, str]]:
    return [
        {
            "control": "Privileged identity protection",
            "aws": "Root hygiene, MFA coverage, IAM least-privilege review",
            "azure": "Entra privileged access, MFA coverage, RBAC least-privilege review",
        },
        {
            "control": "Audit and security telemetry",
            "aws": "CloudTrail, Security Hub, GuardDuty, log retention",
            "azure": "Activity Log, Defender for Cloud, diagnostic settings, log retention",
        },
        {
            "control": "Public exposure controls",
            "aws": "Security groups, public storage blocks, internet path review",
            "azure": "NSGs, public access controls, internet path review",
        },
        {
            "control": "Data protection defaults",
            "aws": "Encryption coverage, bucket and volume protection defaults",
            "azure": "Encryption coverage, storage protection defaults, disk protection",
        },
        {
            "control": "Recovery and ownership baseline",
            "aws": "Backup posture, tagging discipline, cost/budget guardrails",
            "azure": "Backup posture, tagging discipline, cost/budget guardrails",
        },
    ]
