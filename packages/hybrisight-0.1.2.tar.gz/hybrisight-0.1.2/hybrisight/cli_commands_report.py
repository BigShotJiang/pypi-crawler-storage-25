# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from pathlib import Path

import typer
from pydantic import ValidationError

from hybrisight.cli_helpers import _normalize_native_or_exit, _status_context
from hybrisight.config import DEFAULT_HTML_OUTPUT, DEFAULT_JSON_OUTPUT, DEFAULT_PDF_JSON_OUTPUT, DEFAULT_PDF_OUTPUT
from hybrisight.engine import apply_scoring, save_html_report, save_json_report, save_pdf_ready_summary
from hybrisight.models import ScanResult
from hybrisight.pdf import render_pdf_report
from hybrisight.security import scan_payload_for_malware


def report_cmd(input: Path, format: str, output: Path, source_type: str, provider: str | None, export_type: str | None) -> None:
    source_type = source_type.lower().strip()
    if not input.exists():
        typer.secho(f"Error: Input file not found: {input}", fg=typer.colors.RED, err=True)
        typer.secho("HINT: Run a scan first. Example:", fg=typer.colors.YELLOW, err=True)
        typer.secho(f"  hybrisight scan aws --regions eu-west-2 --output {input}", fg=typer.colors.YELLOW, err=True)
        raise typer.Exit(code=1)
    raw_payload = input.read_bytes()
    with _status_context("Scanning for malware"):
        if not scan_payload_for_malware(raw_payload):
            typer.secho("Error: Local malware scan failed. The input contains suspicious patterns.", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=1)

    raw_text = raw_payload.decode("utf-8")
    raw = json.loads(raw_text)

    if source_type == "scanresult":
        try:
            result = ScanResult.model_validate(raw)
        except ValidationError as exc:
            typer.echo(f"Error: input is not canonical ScanResult JSON ({exc.errors()[0].get('msg', 'validation failed')}).", err=True)
            typer.echo("Tip: use --source-type native-export --provider aws|azure --export-type <type>, or omit --source-type to auto-detect.", err=True)
            raise typer.Exit(code=1)
    elif source_type == "native-export":
        if not provider:
            typer.echo("Error: --provider is required when --source-type native-export", err=True)
            raise typer.Exit(code=2)
        if not export_type:
            typer.echo("Error: --export-type is required when --source-type native-export", err=True)
            raise typer.Exit(code=2)
        result = _normalize_native_or_exit(raw=raw, raw_text=raw_text, provider=provider, export_type=export_type)
    elif source_type == "auto":
        with _status_context("Detecting and normalizing input"):
            try:
                result = ScanResult.model_validate(raw)
            except ValidationError:
                result = _normalize_native_or_exit(raw=raw, raw_text=raw_text, provider=provider, export_type=export_type)
    else:
        raise typer.BadParameter("source-type must be 'auto', 'scanresult', or 'native-export'")

    with _status_context("Applying scoring and generating roadmap"):
        result = apply_scoring(result)

    with _status_context(f"Generating {format.upper()} report"):
        if format == "html":
            final_output = output
            save_html_report(result, final_output)
        elif format == "json":
            final_output = output if output != DEFAULT_HTML_OUTPUT else DEFAULT_JSON_OUTPUT
            save_json_report(result, final_output)
        elif format == "pdf-json":
            final_output = output if output != DEFAULT_HTML_OUTPUT else DEFAULT_PDF_JSON_OUTPUT
            save_pdf_ready_summary(result, final_output)
        elif format == "pdf":
            final_output = output if output != DEFAULT_HTML_OUTPUT else DEFAULT_PDF_OUTPUT
            try:
                render_pdf_report(result, final_output)
            except RuntimeError as exc:
                typer.echo(f"Error generating PDF: {exc}", err=True)
                raise typer.Exit(code=1)
            # typer.echo(f"PDF renderer: {renderer}")
        else:
            raise typer.BadParameter("format must be 'html', 'json', 'pdf-json', or 'pdf'")

    typer.echo(f"Report generated: {final_output}")
