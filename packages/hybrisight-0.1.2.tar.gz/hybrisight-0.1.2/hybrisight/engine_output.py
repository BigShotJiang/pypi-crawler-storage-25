# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from hybrisight.engine_context import build_report_context
from hybrisight.engine_html import render_html_report


def save_json_report(result: Any, output: Path) -> None:
    from hybrisight.engine import apply_scoring

    scored = apply_scoring(result)
    output.write_text(json.dumps(scored.model_dump(mode="json"), indent=2))


def save_pdf_ready_summary(result: Any, output: Path, trend_summary: dict[str, Any] | None = None, client_name: str | None = None) -> None:
    context = build_report_context(result, trend_summary=trend_summary, client_name=client_name)
    phase_projection = dict(context["phase_projection"])
    phase_projection.pop("trajectory_svg", None)
    payload = {
        "document_type": "hybrisight_pdf_ready_summary",
        "executive_summary": context["summary"],
        "executive_brief": context["executive_brief"],
        "primary_risk_drivers": context["primary_risk_drivers"],
        "immediate_actions": context["immediate_actions"],
        "risk_heat_map": context["heat_map"],
        "top_10_findings": [f.model_dump(mode="json") for f in context["top_findings"]],
        "roadmap_30_60_90": context["roadmap"],
        "phase_projection": phase_projection,
        "trend_summary": context.get("trend_summary"),
        "compliance": context.get("compliance"),
    }
    output.write_text(json.dumps(payload, indent=2))


def save_html_report(result: Any, output: Path, trend_summary: dict[str, Any] | None = None, client_name: str | None = None, gated_compliance: bool = True) -> None:
    context = build_report_context(result, trend_summary=trend_summary, client_name=client_name)
    context["gated_compliance"] = gated_compliance
    output.write_text(render_html_report(context), encoding="utf-8")
