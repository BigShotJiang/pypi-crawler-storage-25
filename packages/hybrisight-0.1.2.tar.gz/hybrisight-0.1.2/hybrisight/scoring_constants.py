# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

SCORING_VERSION = "1.0"
CALIBRATION_K = 12.0

SEVERITY_WEIGHTS = {
    "critical": 5,
    "high": 4,
    "medium": 3,
    "low": 2,
    "info": 1,
}

CATEGORY_MULTIPLIERS = {
    "security": 1.2,
    "resilience": 1.1,
    "cost": 1.0,
    "ops": 0.8,
}

EFFORT_MODIFIERS = {
    "low": 1.1,
    "medium": 1.0,
    "high": 0.9,
}

COVERAGE_MULTIPLIERS = {
    "full": 1.0,
    "partial": 0.85,
    "unknown": 0.7,
}

EFFORT_RANK = {
    "low": 0,
    "medium": 1,
    "high": 2,
}

SEVERITY_RANK = {
    "info": 0,
    "low": 1,
    "medium": 2,
    "high": 3,
    "critical": 4,
}

THEME_DEFINITIONS = [
    {
        "name": "Network Exposure Hardening",
        "prefixes": ("AWS.NETWORK.", "AZURE.NETWORK.", "MULTI.NETWORK."),
        "fallback_services": {"network", "vnet", "nsg", "security-group"},
        "summary": "Reduce internet-exposed attack surface and enforce controlled administrative access paths.",
    },
    {
        "name": "Identity Governance",
        "prefixes": ("AWS.IAM.", "AZURE.IAM.", "MULTI.IAM."),
        "fallback_services": {"iam", "identity"},
        "summary": "Strengthen privileged identity controls, least-privilege boundaries, and MFA enforcement.",
    },
    {
        "name": "Data Protection Controls",
        "prefixes": ("MULTI.STORAGE.", "AWS.S3.", "AZURE.STORAGE."),
        "fallback_services": {"s3", "storage", "blob"},
        "summary": "Protect sensitive data by restricting public exposure and enforcing durable storage guardrails.",
    },
    {
        "name": "Cost Optimization Controls",
        "prefixes": ("MULTI.COST.", "AWS.COST.", "AZURE.COST."),
        "fallback_services": {"billing", "cost"},
        "summary": "Capture immediate and medium-term savings by removing idle spend and overprovisioned capacity.",
    },
    {
        "name": "Governance & Ownership Hygiene",
        "prefixes": ("MULTI.OPS.", "AWS.OPS.", "AZURE.OPS."),
        "fallback_services": {"ops", "tags", "governance"},
        "summary": "Improve ownership, tagging, and operating discipline to support accountability and auditability.",
    },
    {
        "name": "Resilience & Backup Strategy",
        "prefixes": ("MULTI.RESILIENCE.", "AWS.RESILIENCE.", "AZURE.RESILIENCE."),
        "fallback_services": {"backup", "resilience", "dr"},
        "summary": "Increase service continuity by addressing backup gaps, single points of failure, and recovery readiness.",
    },
]
