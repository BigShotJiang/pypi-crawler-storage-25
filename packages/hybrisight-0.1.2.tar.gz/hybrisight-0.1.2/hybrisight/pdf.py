# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import tempfile
from pathlib import Path

from hybrisight.engine import save_html_report
from hybrisight.models import ScanResult


def render_pdf_report(result: ScanResult, output: Path, trend_summary: dict | None = None, client_name: str | None = None) -> str:
    """Render a PDF report from ScanResult.

    Returns the renderer used ("weasyprint" or "playwright").
    """
    with tempfile.TemporaryDirectory() as td:
        html_path = Path(td) / "hybrisight-report.html"
        save_html_report(result, html_path, trend_summary=trend_summary, client_name=client_name, gated_compliance=False)
        html_content = html_path.read_text(encoding="utf-8")

    try:
        from weasyprint import HTML  # type: ignore

        HTML(string=html_content).write_pdf(str(output))
        return "weasyprint"
    except Exception as weasy_exc:
        try:
            from playwright.sync_api import sync_playwright  # type: ignore

            with sync_playwright() as p:
                browser = p.chromium.launch()
                page = browser.new_page()
                page.set_content(html_content, wait_until="networkidle")
                page.pdf(path=str(output), format="A4", print_background=True)
                browser.close()
            return "playwright"
        except Exception as playwright_exc:
            raise RuntimeError(
                "PDF generation requires either weasyprint or playwright. "
                "Install one renderer: `pip install weasyprint` OR "
                "`pip install playwright` and then `playwright install chromium`."
            ) from (playwright_exc or weasy_exc)
