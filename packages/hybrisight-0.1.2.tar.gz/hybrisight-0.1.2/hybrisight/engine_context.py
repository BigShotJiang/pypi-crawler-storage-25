# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

import yaml

from hybrisight.compliance_map import compute_coverage, compute_coverage_detailed, load_all_frameworks
from hybrisight.engine_context_cost import build_cost_breakdown

logger = logging.getLogger(__name__)
from hybrisight.models import CoverageLevel, ScanResult
from hybrisight.scoring import (
    SEVERITY_WEIGHTS,
    build_cumulative_phase_projection,
    build_findings_groups,
    build_posture_trajectory_svg,
    build_roadmap,
    prioritize_findings,
)
from hybrisight.engine_context_helpers import (
    build_executive_brief,
    build_primary_risk_drivers,
    coverage_confidence_adjusted_score,
    format_estimated_waste_label,
    is_projection_valid,
    posture_band,
)
from hybrisight.engine_context_more import build_immediate_actions, build_risk_profile_narrative
from hybrisight.engine_context_assessment import build_foundation_mapping, classify_assessment


def _build_report_id(result: ScanResult) -> str:
    stamp = (result.generated_at_utc or "").replace(":", "").replace("-", "").replace("T", "").replace("Z", "")
    provider = str(result.scanned_provider.value).upper()
    return f"HS-{provider}-{stamp[:12] or 'SNAPSHOT'}"


def _build_compliance_coverage(result: ScanResult) -> dict[str, Any]:
    rule_ids = {f.id for f in result.findings if f.id}
    try:
        frameworks = load_all_frameworks()
        return compute_coverage(frameworks, rule_ids)
    except (FileNotFoundError, yaml.YAMLError, KeyError) as exc:
        logger.warning("Compliance coverage computation failed: %s", exc)
        return {}


def build_report_context(result: ScanResult, trend_summary: dict[str, Any] | None = None, client_name: str | None = None) -> dict[str, Any]:
    from hybrisight.engine import apply_scoring

    result = apply_scoring(result)
    estimated_waste = round(sum((f.estimated_annual_cost_impact_gbp or 0) for f in result.findings), 2)
    estimated_waste_label = format_estimated_waste_label(estimated_waste)
    confidence_adjusted_score = coverage_confidence_adjusted_score(result)

    categories = ["security", "cost", "resilience", "ops"]
    heat_map_rule_ids: dict[str, dict[str, set[str]]] = {c: {s: set() for s in SEVERITY_WEIGHTS.keys()} for c in categories}
    heat_map_resource_ids: dict[str, set[str]] = {c: set() for c in categories}
    for finding in result.findings:
        category = finding.category.value
        severity = finding.severity.value
        heat_map_rule_ids[category][severity].add(finding.id)
        heat_map_resource_ids[category].add(finding.resource_id)
    heat_map: dict[str, dict[str, int]] = {c: {s: len(ids) for s, ids in sev.items()} for c, sev in heat_map_rule_ids.items()}

    findings_sorted = prioritize_findings(result.findings)
    top_findings = findings_sorted[:10]
    unique_finding_ids = {finding.id for finding in result.findings}
    services_observed = sorted({str(finding.service).upper() for finding in result.findings if finding.service})
    collection_summary = ((result.collection_diagnostics or {}).get("summary") or {}) if isinstance(result.collection_diagnostics, dict) else {}

    severity_counts = {k: 0 for k in SEVERITY_WEIGHTS.keys()}
    for finding in result.findings:
        severity_counts[finding.severity.value] += 1

    resilience_pressure = heat_map["resilience"]["critical"] + heat_map["resilience"]["high"]
    resilience_indicator = "at-risk" if resilience_pressure > 0 else "stable"
    roadmap = build_roadmap(findings_sorted, posture_score=result.posture_score)
    phase_projection = build_cumulative_phase_projection(findings_sorted, asset_count=result.asset_count, coverage_level=result.coverage_level)
    phase_projection["projection_valid"] = is_projection_valid(phase_projection)
    phase_projection["trajectory_svg"] = build_posture_trajectory_svg(phase_projection)

    findings_grouped = build_findings_groups(findings_sorted)
    primary_risk_drivers = build_primary_risk_drivers(findings_grouped)
    immediate_actions, immediate_action_details = build_immediate_actions(roadmap)
    executive_brief = build_executive_brief(result, findings_sorted, estimated_waste, phase_projection)
    posture_band_value = posture_band(float(result.posture_score or 0.0))
    exposure_tier = str(executive_brief["exposure_tier"])
    assessment = classify_assessment(
        provider=result.scanned_provider.value,
        asset_count=int(result.asset_count or 0),
        unique_findings=len(unique_finding_ids),
        services_observed=services_observed,
        strategic_signal_quality=str(collection_summary.get("quality") or "full"),
        critical_count=severity_counts["critical"],
        high_count=severity_counts["high"],
    )
    if assessment["type"] == "foundation":
        executive_brief["outcome_30_day_summary"] = (
            "Within 30 days, the objective is foundation hardening: privileged identity, exposure controls, "
            "logging, protection defaults, and ownership baselines are established first."
        )
        executive_brief["transformation_90_day_summary"] = (
            "By 90 days, the target state is a controlled cloud foundation with must-do controls established and "
            "the environment ready for a fuller governance brief when signal density increases."
        )
        executive_brief["advisory_recommendation"] = (
            "Recommended next step: initiate a HybriSight Foundation Hardening plan focused on identity, exposure, "
            "logging, protection defaults, and ownership controls, then re-run HybriSight to confirm readiness."
        )

    risk_profile_rows = [
        {
            "category": category,
            "critical": severities["critical"],
            "high": severities["high"],
            "medium": severities["medium"],
            "low": severities["low"],
            "info": severities["info"],
        }
        for category, severities in heat_map.items()
    ]
    roadmap_phases = [
        {
            "key": "30",
            "label": (
                f"{result.scanned_provider.value.upper()} Foundation Hardening · 0\u201330 days"
                if assessment["type"] == "foundation"
                else f"{result.scanned_provider.value.upper()} Exposure Stabilisation · 0\u201330 days"
            ),
            "goal": "Remove externally exploitable attack surface and stabilise exposure.",
            "themes": roadmap["30_days"],
        },
        {
            "key": "60",
            "label": (
                f"{result.scanned_provider.value.upper()} Controls & Resilience · 31\u201360 days"
                if assessment["type"] == "foundation"
                else f"{result.scanned_provider.value.upper()} Operational Improvement · 31\u201360 days"
            ),
            "goal": "Reduce waste and improve resilience controls.",
            "themes": roadmap["60_days"],
        },
        {
            "key": "90",
            "label": (
                f"{result.scanned_provider.value.upper()} Governance Baseline · 61\u201390 days"
                if assessment["type"] == "foundation"
                else f"{result.scanned_provider.value.upper()} Governance Hardening · 61\u201390 days"
            ),
            "goal": "Embed governance guardrails and sustain posture gains.",
            "themes": roadmap["90_days"],
        },
    ]
    drivers_for_report = [
        {
            "title": driver["title"],
            "severity": driver["severity"],
            "business_impact": driver["business_impact"],
            "effort": driver["effort"],
            "affected_count": driver["affected_resource_count"],
            "why_now": "Immediate attack-surface reduction" if driver["severity"] in {"critical", "high"} else "Prevents escalation",
            "remediation_summary": driver["business_impact"],
            "rule_ids": driver.get("rule_ids", []),
        }
        for driver in primary_risk_drivers
    ]

    collection_diagnostics = result.collection_diagnostics or {}
    cost_sources = collection_diagnostics.get("cost_sources", {}) if isinstance(collection_diagnostics, dict) else {}
    dominant_source = max(cost_sources, key=cost_sources.get) if cost_sources else "static_default"
    source_labels = {"billing_api": "Cost Explorer/API", "pricing_table": "Pricing Reference", "static_default": "Rule Default"}
    cost_source_label = source_labels.get(dominant_source, "Rule Default")

    _client_name = (client_name or "").strip() or "N/A"
    return {
        "summary": {
            "provider": result.scanned_provider.value,
            "tenant_name": _client_name,
            "schema_version": result.schema_version,
            "coverage_level": result.coverage_level.value,
            "scoring_version": result.scoring_version,
            "risk_index": result.risk_index,
            "posture_score": result.posture_score,
            "posture_band": posture_band_value,
            "confidence_adjusted_score": confidence_adjusted_score,
            "assets": result.asset_count,
            "findings": result.finding_count,
            "estimated_waste": estimated_waste,
            "estimated_waste_label": estimated_waste_label,
            "cost_source_label": cost_source_label,
            "cost_source_breakdown": cost_sources,
            "critical_count": severity_counts["critical"],
            "high_count": severity_counts["high"],
            "resilience_indicator": resilience_indicator,
            "generated_at_utc": result.generated_at_utc,
            "roadmap_model": "theme_grouped_hybrid_v1",
            "coverage_disclaimer": "This assessment is based on partial data sources. Some risk signals may not be fully represented." if result.coverage_level != CoverageLevel.full else None,
        },
        "heat_map": heat_map,
        "top_findings": top_findings,
        "findings_sorted": findings_sorted,
        "findings_grouped": findings_grouped,
        "primary_risk_drivers": primary_risk_drivers,
        "immediate_actions": immediate_actions,
        "immediate_actions_detailed": immediate_action_details,
        "roadmap": roadmap,
        "phase_projection": phase_projection,
        "trend_summary": trend_summary,
        "executive_brief": executive_brief,
        "collection_diagnostics": collection_diagnostics,
        "meta": {
            "report_id": _build_report_id(result),
            "tenant_name": _client_name,
            "provider": str(result.scanned_provider.value).upper(),
            "generated_at_utc": result.generated_at_utc,
            "schema_version": result.schema_version,
            "scoring_version": result.scoring_version,
            "coverage_level": result.coverage_level.value,
            "signature_status": "verified" if result.signature else "not_provided",
            "year": datetime.now(UTC).year,
        },
        "assessment": assessment,
        "environment_overview": {
            "assets_evaluated": result.asset_count,
            "unique_findings": len(unique_finding_ids),
            "services_observed": services_observed[:8],
            "assessment_method": "Read-only metadata snapshot",
        },
        "kpis": {
            "posture_score": result.posture_score,
            "risk_index": result.risk_index,
            "confidence_adjusted_score": confidence_adjusted_score,
            "exposure_tier_label": exposure_tier,
            "exposure_tier_band": posture_band_value,
            "est_annual_waste_gbp": estimated_waste,
            "est_annual_waste_label": estimated_waste_label,
            "critical_count": severity_counts["critical"],
            "high_count": severity_counts["high"],
            "resilience_indicator": resilience_indicator,
        },
        "compliance": _build_compliance_coverage(result),
        "compliance_detailed": compute_coverage_detailed(
            load_all_frameworks(),
            {f.id: {"title": f.title, "severity": f.severity, "category": f.category, "business_impact": f.business_impact} for f in findings_sorted},
        ),
        "cost_breakdown": build_cost_breakdown(findings_sorted, result.findings),
        "drivers": drivers_for_report,
        "risk_profile": {
            "heatmap_rows": risk_profile_rows,
            "narrative": build_risk_profile_narrative(heat_map, drivers_for_report),
            "resources_affected": {category: len(resources) for category, resources in heat_map_resource_ids.items()},
        },
        "roadmap_view": {"phases": roadmap_phases},
        "trajectory": {
            "points": [
                {"label": "Now", "posture": phase_projection["now"]["posture_score"], "risk_index": phase_projection["now"]["risk_index"]},
                {"label": "30d", "posture": phase_projection["d30"]["posture_score"], "risk_index": phase_projection["d30"]["risk_index"]},
                {"label": "60d", "posture": phase_projection["d60"]["posture_score"], "risk_index": phase_projection["d60"]["risk_index"]},
                {"label": "90d", "posture": phase_projection["d90"]["posture_score"], "risk_index": phase_projection["d90"]["risk_index"]},
            ],
            "chart_svg": phase_projection["trajectory_svg"],
            "narrative": "If the stabilisation roadmap is executed, posture is projected to improve significantly over 90 days with measurable risk reduction validated through subsequent snapshots." if phase_projection["projection_valid"] else "Trajectory available after Phase 1 remediation is validated (requires re-run).",
            "assumptions": phase_projection["disclaimer"],
            "projection_invalid": not phase_projection["projection_valid"],
        },
        "appendix": {
            "methodology_html": "HybriSight is a read-only, non-intrusive snapshot method. It evaluates metadata and configuration evidence against versioned rules across security, cost, resilience, and operations.",
            "coverage_disclaimer_html": "This assessment is based on partial data sources." if result.coverage_level != CoverageLevel.full else "Assessment coverage is full for connected data sources.",
            "cost_methodology_html": (
                "Cost estimates use a three-tier methodology: "
                "(1) AWS Cost Explorer / Azure Cost Management API data when available (most accurate), "
                "(2) AWS on-demand pricing reference by instance type and region for common resources, "
                "(3) Static rule defaults. "
                "Tier 2 estimates are based on published AWS on-demand rates for London (eu-west-2) "
                "with regional multipliers applied. Rightsizing savings assume 50% of on-demand cost "
                "for underutilized compute and 100% of resource cost for orphaned volumes, idle LBs, "
                "and unattached IPs. These are estimates and should be validated against actual billing data."
            ),
            "foundation_mapping": build_foundation_mapping(),
        },
        "board_translation": {
            "current_risk_position_html": executive_brief["risk_position_summary"],
            "inaction_outlook_html": executive_brief["inaction_statement"],
            "stabilisation_objective_html": executive_brief["outcome_30_day_summary"],
            "recommended_path_html": executive_brief["advisory_recommendation"],
        },
    }
