# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from hybrisight.models import ScanResult, SignatureBlock

ALGORITHM = "ed25519"
LEGACY_ALGORITHM = "hmac-sha256"
DEFAULT_KEY_ID = "local-dev"


def _get_signing_key() -> bytes:
    key = os.getenv("HYBRISIGHT_SIGNING_KEY")
    if not key:
        raise RuntimeError(
            "HYBRISIGHT_SIGNING_KEY environment variable is not set. "
            "A secure key is required for signing scan results."
        )
    return key.encode("utf-8")


def _load_private_key() -> tuple[Ed25519PrivateKey | None, str | None]:
    key_pem = os.getenv("HYBRISIGHT_SIGNING_PRIVATE_KEY")
    key_file = os.getenv("HYBRISIGHT_SIGNING_PRIVATE_KEY_FILE")
    key_id = os.getenv("HYBRISIGHT_SIGNING_KEY_ID")
    if not key_pem and key_file and os.path.exists(key_file):
        key_pem = Path(key_file).read_text(encoding="utf-8")
    if not key_pem:
        return None, None

    private_key = serialization.load_pem_private_key(key_pem.encode("utf-8"), password=None)
    if not isinstance(private_key, Ed25519PrivateKey):
        raise RuntimeError("HYBRISIGHT_SIGNING_PRIVATE_KEY must be an Ed25519 private key")
    if key_id:
        return private_key, key_id

    pub = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    derived_key_id = hashlib.sha256(pub).hexdigest()[:16]
    return private_key, derived_key_id


def _load_public_key_from_pem(public_key_pem: str) -> Ed25519PublicKey:
    key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))
    if not isinstance(key, Ed25519PublicKey):
        raise RuntimeError("Registered public key is not Ed25519")
    return key


def derive_ed25519_key_id_from_public_key(public_key_pem: str) -> str:
    key = _load_public_key_from_pem(public_key_pem)
    raw = key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return hashlib.sha256(raw).hexdigest()[:16]


def generate_ed25519_keypair_pem() -> tuple[str, str, str]:
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    key_id = derive_ed25519_key_id_from_public_key(public_pem)
    return private_pem, public_pem, key_id


def _canonical_payload_dict(result: ScanResult) -> dict[str, Any]:
    payload = result.model_dump(mode="json")
    payload.pop("signature", None)
    return payload


def _canonical_payload_bytes(result: ScanResult) -> bytes:
    payload = _canonical_payload_dict(result)
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_scan_result(result: ScanResult, key_id: str = DEFAULT_KEY_ID) -> SignatureBlock:
    data = _canonical_payload_bytes(result)
    private_key, loaded_key_id = _load_private_key()
    if private_key:
        sig_bytes = private_key.sign(data)
        return SignatureBlock(
            algorithm=ALGORITHM,
            key_id=loaded_key_id or key_id,
            signature=base64.b64encode(sig_bytes).decode("ascii"),
        )

    if os.getenv("HYBRISIGHT_SIGNING_KEY"):
        signature = hmac.new(_get_signing_key(), data, hashlib.sha256).hexdigest()
        return SignatureBlock(algorithm=LEGACY_ALGORITHM, key_id=key_id, signature=signature)

    raise RuntimeError(
        "No artifact signing key configured. "
        "Set HYBRISIGHT_SIGNING_PRIVATE_KEY(_FILE) for Ed25519 or HYBRISIGHT_SIGNING_KEY for legacy HMAC."
    )


def verify_scan_result_signature_with_public_key(
    result: ScanResult,
    signature: SignatureBlock,
    public_key_pem: str,
) -> bool:
    if signature.algorithm != ALGORITHM:
        return False
    try:
        public_key = _load_public_key_from_pem(public_key_pem)
        sig_bytes = base64.b64decode(signature.signature.encode("ascii"))
        public_key.verify(sig_bytes, _canonical_payload_bytes(result))
        return True
    except Exception:
        return False


def verify_scan_result_signature(result: ScanResult, signature: SignatureBlock | None = None) -> bool:
    sig = signature or result.signature
    if sig is None:
        return False
    if sig.algorithm != LEGACY_ALGORITHM:
        return False

    if not os.getenv("HYBRISIGHT_SIGNING_KEY"):
        return False
    expected = hmac.new(_get_signing_key(), _canonical_payload_bytes(result), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig.signature)
