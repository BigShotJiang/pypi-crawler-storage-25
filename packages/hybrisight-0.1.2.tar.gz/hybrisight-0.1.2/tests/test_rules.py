# SPDX-License-Identifier: Apache-2.0
from hybrisight.checks.loader import load_rules
from hybrisight.config import RULES_DIR


def test_rule_pack_size_and_uniqueness() -> None:
    rules = load_rules(RULES_DIR)
    assert 20 <= len(rules) <= 65

    ids = [r.id for r in rules]
    assert len(ids) == len(set(ids))
