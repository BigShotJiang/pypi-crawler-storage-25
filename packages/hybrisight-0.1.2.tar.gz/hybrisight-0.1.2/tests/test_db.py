# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest
from sqlalchemy import inspect, text

from hybrisight.web import db as web_db
from hybrisight.web import schema_migrations
from hybrisight.web.client_journey_schema import (
    COMMON_STAGE_STEP_KEYS,
    DELIVERY_MODES,
    JOURNEY_STAGE_KEYS,
    JOURNEY_STATUSES,
    JOURNEY_TYPES,
    STEP_COMPLETION_SOURCES,
    stage_step_keys_for_mode,
)
from hybrisight.web import models  # noqa: F401


@pytest.fixture()
def sqlite_database_url(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> str:
    db_path = tmp_path / "canonical.db"
    database_url = f"sqlite:///{db_path}"
    monkeypatch.setenv("HYBRISIGHT_WEB_DATABASE_URL", database_url)
    web_db.reconfigure_from_env()
    yield database_url


def _current_alembic_revision() -> str | None:
    with web_db.engine.begin() as conn:
        result = conn.execute(text("SELECT version_num FROM alembic_version LIMIT 1")).scalar()
        return str(result) if result else None


def test_initialize_schema_creates_canonical_tables(sqlite_database_url: str) -> None:
    schema_migrations.migrate_to_head()
    inspector = inspect(web_db.engine)
    table_names = set(inspector.get_table_names())
    assert "tenants" in table_names
    assert "baseline_requests" in table_names
    assert "client_journeys" in table_names
    assert "client_journey_stages" in table_names
    assert "client_journey_steps" in table_names
    assert "client_journey_events" in table_names
    assert "schema_migrations" not in table_names
    assert "schema_revisions" not in table_names
    revision = _current_alembic_revision()
    assert revision is not None


def test_migrate_to_head_upgrades_legacy_schema_history(sqlite_database_url: str) -> None:
    db_path = sqlite_database_url.removeprefix("sqlite:///")
    connection = sqlite3.connect(db_path)
    try:
        connection.execute("create table schema_revisions (revision varchar(64) primary key, applied_at timestamp not null default current_timestamp)")
        connection.execute(
            """
            create table client_onboarding_requests (
                id integer primary key,
                company_name text not null,
                desired_slug text not null,
                admin_email text not null,
                admin_password_hash text not null,
                status text not null default 'pending',
                reviewed_by_user_id integer,
                reviewed_at text,
                rejection_reason text,
                created_at text
            )
            """
        )
        connection.commit()
    finally:
        connection.close()

    revision = schema_migrations.migrate_to_head()
    assert revision is not None
    inspector = inspect(web_db.engine)
    assert "schema_revisions" not in inspector.get_table_names()


def test_validate_schema_current_rejects_empty_hosted_database(sqlite_database_url: str, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HYBRISIGHT_WEB_SCHEMA_BOOTSTRAP", "false")
    with pytest.raises(RuntimeError, match="Database is empty"):
        schema_migrations.ensure_schema_ready(web_db.DATABASE_URL, auto_migrate=False)


def test_ensure_schema_ready_auto_migrates_local_sqlite_by_default(
    sqlite_database_url: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db_path = sqlite_database_url.removeprefix("sqlite:///")
    connection = sqlite3.connect(db_path)
    try:
        connection.execute("create table schema_revisions (revision varchar(64) primary key, applied_at timestamp not null default current_timestamp)")
        connection.execute(
            """
            create table client_onboarding_requests (
                id integer primary key,
                company_name text not null,
                desired_slug text not null,
                admin_email text not null,
                admin_password_hash text not null,
                status text not null default 'pending',
                reviewed_by_user_id integer,
                reviewed_at text,
                rejection_reason text,
                created_at text
            )
            """
        )
        connection.commit()
    finally:
        connection.close()

    monkeypatch.delenv("HYBRISIGHT_WEB_SCHEMA_BOOTSTRAP", raising=False)
    schema_migrations.ensure_schema_ready(web_db.DATABASE_URL, auto_migrate=False)

    inspector = inspect(web_db.engine)
    assert "schema_revisions" not in inspector.get_table_names()


def test_migrate_then_cascade_create_all_is_idempotent(sqlite_database_url: str) -> None:
    schema_migrations.migrate_to_head()
    head_revision_1 = _current_alembic_revision()

    web_db.Base.metadata.create_all(bind=web_db.engine)
    head_revision_2 = _current_alembic_revision()

    assert head_revision_2 is not None
    assert head_revision_1 == head_revision_2


def test_schema_bootstrap_allowed_returns_false_for_postgres_by_default(sqlite_database_url: str) -> None:
    assert not schema_migrations.schema_bootstrap_allowed("postgresql://localhost/db")


def test_schema_bootstrap_allowed_returns_true_for_sqlite_by_default(sqlite_database_url: str) -> None:
    assert schema_migrations.schema_bootstrap_allowed("sqlite:///local.db")


def test_schema_bootstrap_allowed_explicit_flag(sqlite_database_url: str, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HYBRISIGHT_WEB_SCHEMA_BOOTSTRAP", "true")
    assert schema_migrations.schema_bootstrap_allowed("postgresql://localhost/db")
    monkeypatch.setenv("HYBRISIGHT_WEB_SCHEMA_BOOTSTRAP", "false")
    assert not schema_migrations.schema_bootstrap_allowed("sqlite:///local.db")
