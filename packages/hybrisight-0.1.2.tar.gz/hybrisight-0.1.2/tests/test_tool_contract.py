# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import re
from pathlib import Path

from hybrisight.models import ScanResult


def test_tool_contract_doc_exists_and_has_required_sections() -> None:
    path = Path("docs/reference/tool-contract.md")
    assert path.exists(), "docs/reference/tool-contract.md must exist"

    text = path.read_text()
    required_headers = [
        "## 1. What HybriSight Is",
        "## 3. Operating Model (Portal-First, Zero-Install)",
        "## 4. Safety and Non-Intrusion Rules (Hard Constraints)",
        "## 6. Canonical Outputs (What It Produces)",
        "## 8. Coverage and Confidence (Preventing Misuse)",
        "## 9. Deterministic Scoring (Required IP Layer)",
        "## 12. Engineering Guardrails (Preventing Drift)",
    ]
    for header in required_headers:
        assert header in text, f"Missing contract section: {header}"


def test_scanresult_contract_fields_present() -> None:
    fields = ScanResult.model_fields
    for required in [
        "schema_version",
        "coverage_level",
        "scoring_version",
        "risk_index",
        "posture_score",
        "confidence_adjusted_score",
        "signature",
    ]:
        assert required in fields, f"ScanResult missing required field: {required}"


def test_read_only_provider_static_contract() -> None:
    forbidden_regex = re.compile(
        r"\.(create_|put_|delete_|update_|modify_|authorize_|revoke_|attach_|detach_|run_instances|start_instances|stop_instances|terminate_instances|reboot_instances|create_or_update|begin_create_or_update|begin_delete|set_)[A-Za-z0-9_]*\(",
    )
    hits: list[tuple[str, int, str]] = []
    for path in Path("hybrisight/providers").rglob("*.py"):
        for line_no, line in enumerate(path.read_text().splitlines(), start=1):
            if forbidden_regex.search(line):
                hits.append((str(path), line_no, line.strip()))

    assert not hits, f"Read-only provider contract violated: {hits}"
