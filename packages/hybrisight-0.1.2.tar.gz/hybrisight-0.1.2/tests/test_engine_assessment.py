# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from hybrisight.engine import build_report_context
from hybrisight.models import CoverageLevel, Finding, Provider, ScanResult, Severity


def _finding(*, finding_id: str, service: str, severity: Severity) -> Finding:
    return Finding(
        id=finding_id,
        provider=Provider.aws,
        service=service,
        resource_id=f"{service}-1",
        title=f"{service} control",
        category="security",
        severity=severity,
        description="desc",
        business_impact="impact",
        remediation_guidance="guide",
        remediation_effort="low",
    )


def test_foundation_review_classification_for_low_signal_environment() -> None:
    result = ScanResult(
        scanned_provider=Provider.aws,
        asset_count=6,
        finding_count=2,
        findings=[
            _finding(finding_id="AWS.IAM.001", service="iam", severity=Severity.medium),
            _finding(finding_id="AWS.S3.001", service="s3", severity=Severity.low),
        ],
        generated_at_utc="2026-03-07T12:00:00Z",
        coverage_level=CoverageLevel.partial,
        collection_diagnostics={"summary": {"quality": "limited", "label": "Limited", "summary": "Low-signal collection."}},
    )

    context = build_report_context(result)

    assert context["assessment"]["type"] == "foundation"
    assert context["assessment"]["package_type"] == "foundation"
    assert context["assessment"]["recommended_next_service"] == "foundation_hardening"
    assert "Foundation Hardening" in context["executive_brief"]["advisory_recommendation"]
    assert context["appendix"]["foundation_mapping"]


def test_governance_brief_classification_for_richer_environment() -> None:
    result = ScanResult(
        scanned_provider=Provider.aws,
        asset_count=80,
        finding_count=10,
        findings=[
            _finding(finding_id="AWS.IAM.001", service="iam", severity=Severity.critical),
            _finding(finding_id="AWS.S3.001", service="s3", severity=Severity.high),
            _finding(finding_id="AWS.EC2.001", service="ec2", severity=Severity.high),
            _finding(finding_id="AWS.RDS.001", service="rds", severity=Severity.medium),
            _finding(finding_id="AWS.KMS.001", service="kms", severity=Severity.medium),
            _finding(finding_id="AWS.CLOUDTRAIL.001", service="cloudtrail", severity=Severity.medium),
            _finding(finding_id="AWS.BACKUP.001", service="backup", severity=Severity.medium),
            _finding(finding_id="AWS.COST.001", service="ce", severity=Severity.low),
            _finding(finding_id="AWS.OPS.001", service="config", severity=Severity.low),
            _finding(finding_id="AWS.GUARDDUTY.001", service="guardduty", severity=Severity.low),
        ],
        generated_at_utc="2026-03-07T12:00:00Z",
        coverage_level=CoverageLevel.full,
        collection_diagnostics={"summary": {"quality": "full", "label": "Full", "summary": "All strategic sources collected."}},
    )

    context = build_report_context(result)

    assert context["assessment"]["type"] == "baseline"
    assert context["assessment"]["label"] == "Governance Brief"
    assert context["assessment"]["signal_sufficiency"] == "baseline_ready"
