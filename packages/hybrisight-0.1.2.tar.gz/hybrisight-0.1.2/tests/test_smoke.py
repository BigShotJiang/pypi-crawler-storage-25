# SPDX-License-Identifier: Apache-2.0
from hybrisight.engine import run_scan
from hybrisight.models import CoverageLevel
from hybrisight.providers.aws.collector import AwsCollector
from hybrisight.providers.azure.collector import AzureCollector


def test_aws_demo_smoke_new_services_produce_findings() -> None:
    assets = AwsCollector(demo=True).collect()
    result = run_scan(provider="aws", assets=assets)

    assert result.asset_count >= 13
    assert result.finding_count >= 10
    assert result.coverage_level.value == "full"
    assert result.risk_index is not None and result.risk_index > 0
    assert result.posture_score is not None

    rule_ids = {f.id for f in result.findings}

    # New rules from Phase 2.5 gap closure
    assert "AWS.RESILIENCE.004" in rule_ids  # KMS key rotation
    assert "AWS.OPS.015" in rule_ids          # Log group encryption
    assert "AWS.OPS.016" in rule_ids          # Log group retention
    assert "AWS.OPS.017" in rule_ids          # ECS cluster unused
    assert "AWS.NETWORK.014" in rule_ids      # EKS public endpoint

    # Coverage manifest includes new services
    manifest = result.collection_diagnostics.get("collection_manifest", {})
    for svc in ("kms", "log_group", "ecs", "eks"):
        entry = manifest.get(svc, {})
        assert entry.get("status") == "collected", f"{svc} not collected in manifest"


def test_azure_demo_smoke_new_services_produce_findings() -> None:
    assets = AzureCollector(demo=True).collect()
    result = run_scan(provider="azure", assets=assets)

    assert result.asset_count >= 9
    assert result.finding_count >= 5
    assert result.coverage_level.value == "full"
    assert result.risk_index is not None and result.risk_index > 0
    assert result.posture_score is not None

    rule_ids = {f.id for f in result.findings}

    # New Azure rules from Phase 2.5 gap closure
    assert "AZURE.NETWORK.001" in rule_ids    # NSG admin ports

    # Coverage manifest includes Azure services
    manifest = result.collection_diagnostics.get("collection_manifest", {})
    for svc in ("azure_lb", "snapshot", "iam_account", "azure_sql", "azure_monitor"):
        entry = manifest.get(svc, {})
        assert entry.get("status") == "collected", f"{svc} not collected in manifest"


def test_demo_smoke_coverage_manifest_completeness() -> None:
    aws_assets = AwsCollector(demo=True).collect()
    azure_assets = AzureCollector(demo=True).collect()

    aws_result = run_scan(provider="aws", assets=aws_assets)
    azure_result = run_scan(provider="azure", assets=azure_assets)

    aws_manifest = aws_result.collection_diagnostics.get("collection_manifest", {})
    azure_manifest = azure_result.collection_diagnostics.get("collection_manifest", {})

    # Every service in COLLECTED_SERVICES should be present
    expected_aws = {"ec2", "network", "ebs", "snapshot", "elb", "iam", "s3",
                    "kms", "log_group", "ecs", "eks"}
    expected_azure = {"vm", "disk", "storage", "azure_lb", "iam_account",
                      "azure_sql", "azure_monitor"}

    for svc in expected_aws:
        assert svc in aws_manifest, f"AWS manifest missing {svc}"
    for svc in expected_azure:
        assert svc in azure_manifest, f"Azure manifest missing {svc}"


def test_demo_smoke_posture_score_is_deterministic() -> None:
    aws_assets = AwsCollector(demo=True).collect()
    r1 = run_scan(provider="aws", assets=aws_assets)
    r2 = run_scan(provider="aws", assets=aws_assets)

    assert r1.posture_score == r2.posture_score
    assert r1.risk_index == r2.risk_index
