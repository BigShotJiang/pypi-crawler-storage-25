# SPDX-License-Identifier: Apache-2.0
from hybrisight.providers.aws.collector import AwsCollector
from hybrisight.providers.azure.collector import AzureCollector


def test_demo_collectors_return_assets() -> None:
    aws_assets = AwsCollector(demo=True).collect()
    azure_assets = AzureCollector(demo=True).collect()

    assert len(aws_assets) >= 5
    assert len(azure_assets) >= 4
