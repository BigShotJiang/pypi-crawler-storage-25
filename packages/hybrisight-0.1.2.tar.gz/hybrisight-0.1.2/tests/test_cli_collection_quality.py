# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json

from typer.testing import CliRunner

from hybrisight.cli import app

runner = CliRunner()


def test_cli_scan_outputs_polished_summary_and_collection_quality(tmp_path) -> None:
    findings = tmp_path / "artifact.json"
    signature = tmp_path / "artifact.sig.json"

    result = runner.invoke(
        app,
        [
            "scan",
            "aws",
            "--demo",
            "--sign",
            "--signature-output",
            str(signature),
            "--output",
            str(findings),
        ],
    )

    assert result.exit_code == 0, result.stdout
    assert "Scan Summary" in result.stdout
    assert "Artifact Type: Canonical HybriSight CLI" in result.stdout
    assert "Collection Quality: Demo" in result.stdout
    assert "Recommended Output: Foundation Review" in result.stdout
    assert "Use Case: Must-do controls and readiness" in result.stdout
    assert "Canonical Findings:" in result.stdout
    assert "Status: Scan completed; artifact ready for upload." in result.stdout
    assert "Signal Coverage" in result.stdout
    assert "Next Step" in result.stdout
    assert "Upload this canonical artifact to HybriSight" in result.stdout

    payload = json.loads(findings.read_text())
    assert payload["collection_diagnostics"]["summary"]["quality"] == "demo"
    assert payload["collection_diagnostics"]["summary"]["label"] == "Demo"
    assert payload["collection_diagnostics"]["recommended_output"]["type"] == "foundation"
    assert payload["collection_diagnostics"]["recommended_output"]["label"] == "Foundation Review"
    assert payload["collection_diagnostics"]["recommended_output"]["use_case"] == "Must-do controls and readiness"
