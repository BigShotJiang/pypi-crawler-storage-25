# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import hashlib

from hybrisight.web.auth import (
    PBKDF2_ALGO,
    PBKDF2_ITERATIONS,
    hash_password,
    needs_password_rehash,
    verify_password,
)


def test_hash_password_uses_versioned_format_and_verifies() -> None:
    pw = "supersecure12"
    hashed = hash_password(pw)
    parts = hashed.split("$")
    assert len(parts) == 4
    assert parts[0] == PBKDF2_ALGO
    assert int(parts[1]) == PBKDF2_ITERATIONS
    assert verify_password(pw, hashed) is True
    assert verify_password("wrong-pass", hashed) is False


def test_needs_password_rehash_for_lower_iteration_hash() -> None:
    pw = "supersecure12"
    salt = "lowsalt"
    low_iterations = 180_000
    digest = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt.encode("utf-8"), low_iterations).hex()
    old_hash = f"{PBKDF2_ALGO}${low_iterations}${salt}${digest}"
    assert verify_password(pw, old_hash) is True
    assert needs_password_rehash(old_hash) is True
