# SPDX-License-Identifier: Apache-2.0
import pytest
from hybrisight.providers.aws.collector import AwsCollector
from hybrisight.engine import run_scan
from hybrisight.signing import (
    generate_ed25519_keypair_pem,
    sign_scan_result,
    verify_scan_result_signature,
    verify_scan_result_signature_with_public_key,
)


@pytest.fixture(autouse=True)
def _signing_env(monkeypatch):
    monkeypatch.setenv("HYBRISIGHT_SIGNING_KEY", "test-signing-key")
    monkeypatch.delenv("HYBRISIGHT_SIGNING_PRIVATE_KEY", raising=False)
    monkeypatch.delenv("HYBRISIGHT_SIGNING_PRIVATE_KEY_FILE", raising=False)
    monkeypatch.delenv("HYBRISIGHT_SIGNING_KEY_ID", raising=False)


def test_sign_and_verify_roundtrip() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    signature = sign_scan_result(result)
    result.signature = signature
    assert verify_scan_result_signature(result) is True


def test_ed25519_sign_and_verify_roundtrip(monkeypatch) -> None:
    private_pem, public_pem, key_id = generate_ed25519_keypair_pem()
    monkeypatch.delenv("HYBRISIGHT_SIGNING_KEY", raising=False)
    monkeypatch.setenv("HYBRISIGHT_SIGNING_PRIVATE_KEY", private_pem)
    monkeypatch.setenv("HYBRISIGHT_SIGNING_KEY_ID", key_id)

    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    signature = sign_scan_result(result)
    assert signature.algorithm == "ed25519"
    assert signature.key_id == key_id
    assert verify_scan_result_signature_with_public_key(result, signature, public_pem) is True
