# SPDX-License-Identifier: Apache-2.0
import json

from hybrisight.engine import apply_scoring, build_report_context, calculate_snapshot_scores, run_scan, save_pdf_ready_summary
from hybrisight.models import CoverageLevel, Finding, Provider, ScanResult, Severity
from hybrisight.providers.aws.collector import AwsCollector
from hybrisight.scoring import (
    assign_roadmap_phase,
    build_cumulative_phase_projection,
    build_posture_trajectory_svg,
    finding_cost_score,
    prioritize_findings,
)


def test_engine_demo_scan_has_findings() -> None:
    assets = AwsCollector(demo=True).collect()
    result = run_scan(provider="aws", assets=assets)

    assert result.asset_count > 0
    assert result.finding_count > 0
    assert result.generated_at_utc
    assert result.schema_version == "1.1"
    assert result.coverage_level.value == "full"

    rule_ids = {f.id for f in result.findings}
    assert "AWS.IAM.001" in rule_ids
    assert "MULTI.COST.001" in rule_ids


def test_report_context_and_pdf_summary(tmp_path) -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())

    context = build_report_context(result)
    assert "heat_map" in context
    assert context["summary"]["risk_index"] > 0

    output = tmp_path / "summary.json"
    save_pdf_ready_summary(result, output)
    payload = json.loads(output.read_text())

    assert payload["document_type"] == "hybrisight_pdf_ready_summary"
    assert "roadmap_30_60_90" in payload
    assert payload["executive_summary"]["scoring_version"] == "1.0"
    assert "risk_score" not in payload["executive_summary"]


def test_deterministic_snapshot_scoring_math() -> None:
    findings = [
        Finding(
            id="T.SEC.1",
            provider=Provider.aws,
            service="iam",
            resource_id="r1",
            title="t",
            category="security",
            severity=Severity.critical,
            description="d",
            business_impact="b",
            remediation_guidance="r",
            remediation_effort="low",
        ),
        Finding(
            id="T.OPS.1",
            provider=Provider.aws,
            service="ec2",
            resource_id="r2",
            title="t",
            category="ops",
            severity=Severity.low,
            description="d",
            business_impact="b",
            remediation_guidance="r",
            remediation_effort="low",
        ),
    ]
    scores = calculate_snapshot_scores(findings, CoverageLevel.partial)
    # Total impact = (5*1.2) + (2*0.8) = 7.6 ; SizeNorm=sqrt(1)=1 ; Risk=100*(1-exp(-7.6/12))=46.9
    assert scores["risk_index"] == 46.9
    assert scores["posture_score"] == 5.3
    assert scores["confidence_adjusted_score"] == 4.5
    assert scores["scoring_version"] == "1.0"


def test_scoring_applied_when_score_fields_missing() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    input_without_scores = result.model_copy(deep=True)
    input_without_scores.scoring_version = None
    input_without_scores.risk_index = None
    input_without_scores.posture_score = None
    input_without_scores.confidence_adjusted_score = None

    rescored = apply_scoring(input_without_scores)
    assert rescored.scoring_version == "1.0"
    assert rescored.risk_index is not None
    assert rescored.posture_score is not None
    assert rescored.confidence_adjusted_score is not None
    assert rescored.top_finding_ids is not None


def test_cost_score_log_scale_and_cap() -> None:
    def _finding(cost: float | None) -> Finding:
        return Finding(
            id=f"COST.{cost}",
            provider=Provider.aws,
            service="ec2",
            resource_id="r1",
            title="t",
            category="cost",
            severity=Severity.medium,
            description="d",
            business_impact="b",
            estimated_annual_cost_impact_gbp=cost,
            remediation_guidance="r",
            remediation_effort="medium",
        )

    assert finding_cost_score(_finding(0)) == 0.0
    assert round(finding_cost_score(_finding(1000)), 2) == 0.30
    assert round(finding_cost_score(_finding(9000)), 2) == 1.00
    assert round(finding_cost_score(_finding(99000)), 2) == 2.00
    assert round(finding_cost_score(_finding(999000)), 2) == 3.00


def test_prioritization_tie_breakers_are_deterministic() -> None:
    findings = [
        Finding(
            id="A",
            provider=Provider.aws,
            service="iam",
            resource_id="r1",
            title="a",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="b",
            estimated_annual_cost_impact_gbp=2000,
            remediation_guidance="r",
            remediation_effort="medium",
        ),
        Finding(
            id="B",
            provider=Provider.aws,
            service="iam",
            resource_id="r2",
            title="b",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="b",
            estimated_annual_cost_impact_gbp=1000,
            remediation_guidance="r",
            remediation_effort="medium",
        ),
        Finding(
            id="C",
            provider=Provider.aws,
            service="iam",
            resource_id="r3",
            title="c",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="b",
            estimated_annual_cost_impact_gbp=2000,
            remediation_guidance="r",
            remediation_effort="high",
        ),
    ]
    ordered = prioritize_findings(findings)
    assert [f.id for f in ordered] == ["A", "B", "C"]


def test_roadmap_phase_assignment_rules() -> None:
    f_30 = Finding(
        id="R30",
        provider=Provider.aws,
        service="iam",
        resource_id="r30",
        title="r30",
        category="security",
        severity=Severity.high,
        description="d",
        business_impact="b",
        remediation_guidance="r",
        remediation_effort="low",
    )
    f_60 = Finding(
        id="R60",
        provider=Provider.aws,
        service="ec2",
        resource_id="r60",
        title="r60",
        category="resilience",
        severity=Severity.medium,
        description="d",
        business_impact="b",
        remediation_guidance="r",
        remediation_effort="medium",
    )
    f_90 = Finding(
        id="R90",
        provider=Provider.aws,
        service="ops",
        resource_id="r90",
        title="r90",
        category="ops",
        severity=Severity.low,
        description="d",
        business_impact="b",
        remediation_guidance="r",
        remediation_effort="high",
    )
    assert assign_roadmap_phase(f_30) == "30_days"
    assert assign_roadmap_phase(f_60) == "60_days"
    assert assign_roadmap_phase(f_90) == "90_days"


def test_roadmap_phase_does_not_put_low_or_info_in_30_days() -> None:
    low_cost = Finding(
        id="COST.LOW.001",
        provider=Provider.aws,
        service="cost",
        resource_id="r-low-cost",
        title="low cost optimization",
        category="cost",
        severity=Severity.low,
        description="d",
        business_impact="b",
        remediation_guidance="r",
        remediation_effort="low",
    )
    info_security = Finding(
        id="SEC.INFO.001",
        provider=Provider.aws,
        service="iam",
        resource_id="r-info-sec",
        title="info security hygiene",
        category="security",
        severity=Severity.info,
        description="d",
        business_impact="b",
        remediation_guidance="r",
        remediation_effort="low",
    )
    assert assign_roadmap_phase(low_cost) in {"60_days", "90_days"}
    assert assign_roadmap_phase(info_security) in {"60_days", "90_days"}


def test_roadmap_phase_allows_high_impact_cost_quick_wins_in_30_days() -> None:
    high_cost_quick = Finding(
        id="COST.HIGH.001",
        provider=Provider.aws,
        service="cost",
        resource_id="r-high-cost",
        title="high impact cost optimization",
        category="cost",
        severity=Severity.high,
        description="d",
        business_impact="b",
        remediation_guidance="r",
        remediation_effort="low",
    )
    assert assign_roadmap_phase(high_cost_quick) == "30_days"


def test_report_context_includes_coverage_disclaimer_when_not_full() -> None:
    result = run_scan(
        provider="aws",
        assets=AwsCollector(demo=True).collect(),
        coverage_level=CoverageLevel.partial,
    )
    context = build_report_context(result)
    assert context["summary"]["coverage_level"] == "partial"
    assert context["summary"]["coverage_disclaimer"] is not None


def test_roadmap_is_theme_grouped_and_deduplicated() -> None:
    findings = [
        Finding(
            id="MULTI.IAM.001",
            provider=Provider.aws,
            service="iam",
            resource_id="role-1",
            title="Overly permissive role",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="Identity controls are weak.",
            remediation_guidance="Remove wildcard permissions.",
            remediation_effort="low",
        ),
        Finding(
            id="MULTI.IAM.001",
            provider=Provider.aws,
            service="iam",
            resource_id="role-2",
            title="Overly permissive role",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="Identity controls are weak.",
            remediation_guidance="Remove wildcard permissions.",
            remediation_effort="low",
        ),
    ]
    ordered = prioritize_findings(findings)
    from hybrisight.scoring import build_roadmap

    roadmap = build_roadmap(ordered, posture_score=2.0)
    assert len(roadmap["30_days"]) == 1
    entry = roadmap["30_days"][0]
    assert entry["theme"] == "Identity Governance"
    assert entry["rule_count"] == 1
    assert entry["affected_resource_count"] == 2
    assert any("MULTI.IAM.001" in line for line in entry["technical_details"])


def test_roadmap_capped_to_five_items_per_phase() -> None:
    findings = [
        Finding(
            id="AWS.NETWORK.001",
            provider=Provider.aws,
            service="network",
            resource_id="n1",
            title="n",
            category="security",
            severity=Severity.critical,
            description="d",
            business_impact="b",
            remediation_guidance="a",
            remediation_effort="low",
        ),
        Finding(
            id="MULTI.IAM.001",
            provider=Provider.aws,
            service="iam",
            resource_id="i1",
            title="i",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="b",
            remediation_guidance="a",
            remediation_effort="low",
        ),
        Finding(
            id="MULTI.STORAGE.001",
            provider=Provider.aws,
            service="storage",
            resource_id="s1",
            title="s",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="b",
            remediation_guidance="a",
            remediation_effort="low",
        ),
        Finding(
            id="MULTI.COST.001",
            provider=Provider.aws,
            service="cost",
            resource_id="c1",
            title="c",
            category="cost",
            severity=Severity.high,
            description="d",
            business_impact="b",
            remediation_guidance="a",
            remediation_effort="low",
        ),
        Finding(
            id="MULTI.RESILIENCE.001",
            provider=Provider.aws,
            service="resilience",
            resource_id="r1",
            title="r",
            category="resilience",
            severity=Severity.high,
            description="d",
            business_impact="b",
            remediation_guidance="a",
            remediation_effort="low",
        ),
        Finding(
            id="MULTI.OPS.001",
            provider=Provider.aws,
            service="ops",
            resource_id="o1",
            title="o",
            category="ops",
            severity=Severity.high,
            description="d",
            business_impact="b",
            remediation_guidance="a",
            remediation_effort="low",
        ),
        Finding(
            id="MULTI.NETWORK.002",
            provider=Provider.aws,
            service="network",
            resource_id="n2",
            title="n2",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="b",
            remediation_guidance="a",
            remediation_effort="low",
        ),
        Finding(
            id="AWS.IAM.002",
            provider=Provider.aws,
            service="iam",
            resource_id="i2",
            title="i2",
            category="security",
            severity=Severity.high,
            description="d",
            business_impact="b",
            remediation_guidance="a",
            remediation_effort="low",
        ),
    ]
    ordered = prioritize_findings(findings)
    from hybrisight.scoring import build_roadmap

    roadmap = build_roadmap(ordered, posture_score=2.0)
    assert len(roadmap["30_days"]) == 5


def test_report_context_roadmap_uses_theme_entries() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    context = build_report_context(result)
    assert context["summary"]["roadmap_model"] == "theme_grouped_hybrid_v1"
    if context["roadmap"]["30_days"]:
        assert "theme" in context["roadmap"]["30_days"][0]


def test_cumulative_phase_projection_is_monotonic() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    ordered = prioritize_findings(result.findings)
    projection = build_cumulative_phase_projection(
        ordered,
        asset_count=result.asset_count,
        coverage_level=result.coverage_level,
    )

    r0 = projection["now"]["risk_index"]
    r1 = projection["d30"]["risk_index"]
    r2 = projection["d60"]["risk_index"]
    r3 = projection["d90"]["risk_index"]

    p0 = projection["now"]["posture_score"]
    p1 = projection["d30"]["posture_score"]
    p2 = projection["d60"]["posture_score"]
    p3 = projection["d90"]["posture_score"]

    assert r3 <= r2 <= r1 <= r0
    assert p3 >= p2 >= p1 >= p0


def test_projection_approaches_zero_when_all_impact_removed() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    ordered = prioritize_findings(result.findings)
    projection = build_cumulative_phase_projection(
        ordered,
        asset_count=result.asset_count,
        coverage_level=result.coverage_level,
    )
    assert projection["d90"]["risk_index"] <= 1.0


def test_trajectory_svg_contains_phase_labels() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    ordered = prioritize_findings(result.findings)
    projection = build_cumulative_phase_projection(
        ordered,
        asset_count=result.asset_count,
        coverage_level=result.coverage_level,
    )
    svg = build_posture_trajectory_svg(projection)
    assert "Now" in svg
    assert "30d" in svg
    assert "60d" in svg
    assert "90d" in svg
    assert svg.count("<circle") >= 4
    assert "trajectory-risk" in svg


def test_report_context_includes_phase_projection() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    context = build_report_context(result)
    phase_projection = context["phase_projection"]
    assert "trajectory_svg" in phase_projection
    assert phase_projection["d90"]["posture_score"] >= phase_projection["now"]["posture_score"]


def test_report_context_includes_executive_brief_translation() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    context = build_report_context(result)
    brief = context["executive_brief"]

    assert brief["exposure_tier"] in {"Critical", "High", "Moderate", "Controlled"}
    assert "Current exposure" in brief["risk_position_summary"]
    assert "Recoverable cost inefficiency identified" in brief["financial_opportunity_summary"]
    assert "risk stabilisation" in brief["outcome_30_day_summary"].lower()
    assert "If no action is taken" in brief["inaction_statement"]
    assert "90 days" in brief["transformation_90_day_summary"].lower()
    assert "Recommended next step" in brief["advisory_recommendation"]


def test_report_context_full_coverage_confidence_matches_posture() -> None:
    result = ScanResult(
        scanned_provider=Provider.aws,
        coverage_level=CoverageLevel.full,
        asset_count=1,
        finding_count=0,
        findings=[],
        generated_at_utc="2026-03-05T00:00:00Z",
        scoring_version="1.0",
        risk_index=0.0,
        posture_score=8.1,
        confidence_adjusted_score=0.0,
        top_finding_ids=[],
    )

    context = build_report_context(result)
    assert context["summary"]["confidence_adjusted_score"] == 8.1
    assert context["kpis"]["confidence_adjusted_score"] == 8.1


def test_primary_risk_drivers_dedupe_aggregates_scope() -> None:
    findings = [
        Finding(
            id="AWS.TAG.001",
            provider=Provider.aws,
            service="ec2",
            resource_id="r1",
            title="Missing cost allocation metadata",
            category="ops",
            severity=Severity.medium,
            description="d",
            business_impact="Ops visibility reduced.",
            remediation_guidance="Add tags.",
            remediation_effort="low",
        ),
        Finding(
            id="AZURE.TAG.001",
            provider=Provider.azure,
            service="vm",
            resource_id="r2",
            title="Missing cost allocation metadata",
            category="ops",
            severity=Severity.low,
            description="d",
            business_impact="Ops visibility reduced.",
            remediation_guidance="Add tags.",
            remediation_effort="low",
        ),
    ]
    result = ScanResult(
        scanned_provider=Provider.aws,
        coverage_level=CoverageLevel.full,
        asset_count=2,
        finding_count=2,
        findings=findings,
        generated_at_utc="2026-03-05T00:00:00Z",
    )

    context = build_report_context(result)
    drivers = [d for d in context["drivers"] if d["title"] == "Missing cost allocation metadata"]
    assert len(drivers) == 1
    assert drivers[0]["affected_count"] == 2
    assert set(drivers[0]["rule_ids"]) == {"AWS.TAG.001", "AZURE.TAG.001"}


def test_projection_sanity_guard_marks_delayed_jump_invalid(monkeypatch) -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())

    def fake_projection(*_args, **_kwargs):
        return {
            "now": {"risk_index": 90.0, "posture_score": 1.0, "confidence_adjusted_score": 1.0, "estimated_waste": 0.0},
            "d30": {"risk_index": 90.0, "posture_score": 1.0, "confidence_adjusted_score": 1.0, "estimated_waste": 0.0},
            "d60": {"risk_index": 90.0, "posture_score": 1.0, "confidence_adjusted_score": 1.0, "estimated_waste": 0.0},
            "d90": {"risk_index": 40.0, "posture_score": 6.0, "confidence_adjusted_score": 6.0, "estimated_waste": 0.0},
            "disclaimer": "test",
            "projected_posture_improvement_90d": 5.0,
        }

    monkeypatch.setattr("hybrisight.engine.build_cumulative_phase_projection", fake_projection)
    context = build_report_context(result)
    assert context["phase_projection"]["projection_valid"] is False
    assert context["trajectory"]["projection_invalid"] is True
    assert "Trajectory available after Phase 1 remediation is validated" in context["trajectory"]["narrative"]


def test_waste_display_threshold_and_multiplier_handling() -> None:
    low_waste = Finding(
        id="LOW.COST.001",
        provider=Provider.aws,
        service="ec2",
        resource_id="r1",
        title="Minor cost issue",
        category="cost",
        severity=Severity.low,
        description="d",
        business_impact="b",
        estimated_annual_cost_impact_gbp=1,
        remediation_guidance="r",
        remediation_effort="low",
    )
    high_waste = low_waste.model_copy(update={"id": "HIGH.COST.001", "estimated_annual_cost_impact_gbp": 5000, "resource_id": "r2"})

    low_result = ScanResult(
        scanned_provider=Provider.aws,
        coverage_level=CoverageLevel.full,
        asset_count=1,
        finding_count=1,
        findings=[low_waste],
        generated_at_utc="2026-03-05T00:00:00Z",
    )
    high_result = ScanResult(
        scanned_provider=Provider.aws,
        coverage_level=CoverageLevel.full,
        asset_count=1,
        finding_count=1,
        findings=[high_waste],
        generated_at_utc="2026-03-05T00:00:00Z",
    )

    low_context = build_report_context(low_result)
    high_context = build_report_context(high_result)

    assert low_context["kpis"]["est_annual_waste_label"] == "Low / immaterial opportunity detected (< GBP 250/year)"
    assert "Recoverable cost inefficiency identified" not in low_context["executive_brief"]["financial_opportunity_summary"]
    assert "2.5x the baseline assessment fee" in high_context["executive_brief"]["financial_opportunity_summary"]


def test_heatmap_counts_use_unique_rule_triggers_and_resource_scope() -> None:
    findings = [
        Finding(
            id="AWS.IAM.001",
            provider=Provider.aws,
            service="iam",
            resource_id="r1",
            title="MFA missing",
            category="security",
            severity=Severity.critical,
            description="d",
            business_impact="b",
            remediation_guidance="r",
            remediation_effort="low",
        ),
        Finding(
            id="AWS.IAM.001",
            provider=Provider.aws,
            service="iam",
            resource_id="r2",
            title="MFA missing",
            category="security",
            severity=Severity.critical,
            description="d",
            business_impact="b",
            remediation_guidance="r",
            remediation_effort="low",
        ),
    ]
    result = ScanResult(
        scanned_provider=Provider.aws,
        coverage_level=CoverageLevel.full,
        asset_count=2,
        finding_count=2,
        findings=findings,
        generated_at_utc="2026-03-05T00:00:00Z",
    )

    context = build_report_context(result)
    security_row = next(row for row in context["risk_profile"]["heatmap_rows"] if row["category"] == "security")
    assert security_row["critical"] == 1
    assert context["risk_profile"]["resources_affected"]["security"] == 2


def test_immediate_actions_detailed_include_scope_owner_effort_validation() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    context = build_report_context(result)
    detailed = context["immediate_actions_detailed"]
    if not detailed:
        return
    first = detailed[0]
    assert first["action"]
    assert isinstance(first["scope"], int)
    assert first["scope"] >= 0
    assert first["owner"] in {"Security", "Platform", "Cloud Engineering"}
    assert first["effort"] in {"Low", "Medium", "High"}
    assert "validation" in first and first["validation"]


def test_environment_overview_includes_assets_findings_services_and_method() -> None:
    result = run_scan(provider="aws", assets=AwsCollector(demo=True).collect())
    context = build_report_context(result)
    overview = context["environment_overview"]
    assert overview["assets_evaluated"] == result.asset_count
    assert overview["unique_findings"] >= 0
    assert isinstance(overview["services_observed"], list)
    assert overview["assessment_method"] == "Read-only metadata snapshot"
