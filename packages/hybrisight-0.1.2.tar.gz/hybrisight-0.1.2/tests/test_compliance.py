# SPDX-License-Identifier: Apache-2.0
from hybrisight.checks.loader import load_rules
from hybrisight.compliance_map import load_all_frameworks, compute_coverage
from hybrisight.config import RULES_DIR


def test_all_rules_mapped_to_all_frameworks() -> None:
    frameworks = load_all_frameworks()
    rules = load_rules(RULES_DIR)
    rule_ids = {r.id for r in rules}

    coverage = compute_coverage(frameworks, rule_ids)
    assert len(frameworks) == 4

    # Every rule ID must appear in every framework (even if empty mapping)
    for fw_name, fw_data in frameworks.items():
        fw_rules = fw_data.get("rules", {})
        unmapped = rule_ids - set(fw_rules.keys())
        assert not unmapped, f"{fw_name} missing rules: {unmapped}"

    # Coverage should be meaningful for CIS (highest alignment)
    cis = coverage.get("CIS AWS Foundations Benchmark", {})
    assert cis["coverage_percent"] >= 85


def test_new_rules_have_compliance_mappings() -> None:
    frameworks = load_all_frameworks()
    new_rules = {
        "AWS.NETWORK.014", "AWS.OPS.015", "AWS.OPS.016",
        "AWS.OPS.017", "AWS.RESILIENCE.004", "AZURE.NETWORK.001",
    }
    for fw_name, fw_data in frameworks.items():
        fw_rules = fw_data.get("rules", {})
        for rid in new_rules:
            assert rid in fw_rules, f"{rid} missing from {fw_name}"
