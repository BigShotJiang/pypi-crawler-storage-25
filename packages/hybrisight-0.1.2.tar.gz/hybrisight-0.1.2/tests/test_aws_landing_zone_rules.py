# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from hybrisight.engine import run_scan
from hybrisight.models import Asset, Provider


def _network_asset(**metadata: object) -> Asset:
    return Asset(
        provider=Provider.aws,
        service="network",
        resource_id="network-posture:test:eu-west-2",
        resource_type="network_posture_summary",
        region="eu-west-2",
        metadata=dict(metadata),
    )


def test_aws_landing_zone_rules_trigger_for_default_vpc_baseline() -> None:
    result = run_scan(
        provider="aws",
        assets=[
            _network_asset(
                default_vpc_present=True,
                dedicated_workload_vpc_present=False,
                subnet_tier_count=0,
                app_data_az_count=0,
                managed_egress_path_defined=False,
                landing_zone_ready=False,
            )
        ],
    )

    assert {
        "AWS.NETWORK.010",
        "AWS.NETWORK.011",
        "AWS.OPS.011",
    }.issubset({finding.id for finding in result.findings})


def test_aws_landing_zone_rules_detect_incomplete_segmented_vpc() -> None:
    result = run_scan(
        provider="aws",
        assets=[
            _network_asset(
                default_vpc_present=True,
                dedicated_workload_vpc_present=True,
                subnet_tier_count=1,
                app_data_az_count=1,
                managed_egress_path_defined=False,
                landing_zone_ready=False,
            )
        ],
    )

    finding_ids = {finding.id for finding in result.findings}
    assert "AWS.NETWORK.010" in finding_ids
    assert "AWS.NETWORK.012" in finding_ids
    assert "AWS.OPS.010" in finding_ids
    assert "AWS.OPS.011" in finding_ids
    assert "AWS.NETWORK.011" not in finding_ids


def test_aws_landing_zone_rules_clear_after_governed_vpc_ready() -> None:
    result = run_scan(
        provider="aws",
        assets=[
            _network_asset(
                default_vpc_present=False,
                dedicated_workload_vpc_present=True,
                subnet_tier_count=2,
                app_data_az_count=2,
                managed_egress_path_defined=True,
                landing_zone_ready=True,
            )
        ],
    )

    assert {finding.id for finding in result.findings}.isdisjoint(
        {
            "AWS.NETWORK.010",
            "AWS.NETWORK.011",
            "AWS.NETWORK.012",
            "AWS.OPS.010",
            "AWS.OPS.011",
        }
    )
