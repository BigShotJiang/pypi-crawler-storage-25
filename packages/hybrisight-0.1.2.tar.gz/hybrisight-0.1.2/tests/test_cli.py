# SPDX-License-Identifier: Apache-2.0
import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from hybrisight.cli import (
    AWS_ACCESS_SETUP_URL,
    CREDENTIAL_HANDLING_URL,
    _parse_aws_regions_option,
    app,
    _redact_text,
)

runner = CliRunner()


@pytest.fixture(autouse=True)
def _signing_env(monkeypatch):
    monkeypatch.setenv("HYBRISIGHT_SIGNING_KEY", "test-signing-key")
    monkeypatch.delenv("HYBRISIGHT_SIGNING_PRIVATE_KEY", raising=False)
    monkeypatch.delenv("HYBRISIGHT_SIGNING_PRIVATE_KEY_FILE", raising=False)
    monkeypatch.delenv("HYBRISIGHT_SIGNING_KEY_ID", raising=False)


class _MockResponse:
    def __init__(self, payload: dict):
        self._payload = payload
        self.text = json.dumps(payload)

    def raise_for_status(self) -> None:
        return

    def json(self) -> dict:
        return self._payload


class _MockHttpxClient:
    def __init__(self, responses: list[dict]):
        self._responses = responses

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def post(self, *args, **kwargs):
        return _MockResponse(self._responses.pop(0))


def test_cli_help_includes_upload() -> None:
    res = runner.invoke(app, ["--help"])
    assert res.exit_code == 0
    assert "upload" in res.stdout


def test_cli_help_includes_access_setup_pointers() -> None:
    res = runner.invoke(app, ["--help"])
    assert res.exit_code == 0
    assert AWS_ACCESS_SETUP_URL in res.stdout
    assert CREDENTIAL_HANDLING_URL in res.stdout


def test_parse_aws_regions_option_defaults_to_all() -> None:
    assert _parse_aws_regions_option("all") is None
    assert _parse_aws_regions_option("*") is None
    assert _parse_aws_regions_option("") is None
    assert _parse_aws_regions_option("eu-west-2,us-east-1") == ["eu-west-2", "us-east-1"]


def test_redact_text_masks_secret_patterns(monkeypatch) -> None:
    monkeypatch.setenv("HYBRISIGHT_API_KEY", "k_live_secret")
    sample = "HYBRISIGHT_API_KEY=k_live_secret token=plain AKIA1234567890ABCDEF"
    redacted = _redact_text(sample)
    assert "k_live_secret" not in redacted
    assert "AKIA1234567890ABCDEF" not in redacted
    assert "[REDACTED]" in redacted


def test_doctor_output_does_not_print_credential_material(monkeypatch) -> None:
    secret_key = "AKIA1234567890ABCDEF"
    secret_value = "super-secret-value"
    monkeypatch.setattr(
        "hybrisight.cli._doctor_aws",
        lambda profile, regions: {
            "identity": {"account_id": "123456789012", "principal": secret_key},
            "checks": [{"name": "iam:GetAccountSummary", "ok": True, "detail": f"AWS_SECRET_ACCESS_KEY={secret_value}"}],
        },
    )

    res = runner.invoke(app, ["doctor", "aws"])
    assert res.exit_code == 0
    assert secret_key not in res.stdout
    assert secret_value not in res.stdout
    assert "[REDACTED]" in res.stdout


def test_cli_scan_and_report(tmp_path) -> None:
    findings = tmp_path / "findings.json"
    signature = tmp_path / "findings.sig.json"
    html_report = tmp_path / "report.html"
    pdf_summary = tmp_path / "summary.json"

    scan_res = runner.invoke(
        app,
        [
            "scan",
            "aws",
            "--demo",
            "--sign",
            "--signature-output",
            str(signature),
            "--output",
            str(findings),
        ],
    )
    assert scan_res.exit_code == 0, scan_res.stdout
    assert "Signal Coverage" in scan_res.stdout
    assert "trusted_advisor: demo_mode" in scan_res.stdout
    assert "guardduty: demo_mode" in scan_res.stdout
    assert findings.exists()
    assert signature.exists()
    payload = json.loads(findings.read_text())
    assert "collection_diagnostics" in payload
    assert payload["collection_diagnostics"].get("provider") == "aws"

    report_res = runner.invoke(
        app,
        ["report", "--input", str(findings), "--format", "html", "--output", str(html_report)],
    )
    assert report_res.exit_code == 0, report_res.stdout
    assert html_report.exists()
    assert "scoring=1.0" in report_res.stdout or "scoring=1.0" in html_report.read_text()

    pdf_res = runner.invoke(
        app,
        ["report", "--input", str(findings), "--format", "pdf-json", "--output", str(pdf_summary)],
    )
    assert pdf_res.exit_code == 0, pdf_res.stdout

    pdf_payload = json.loads(pdf_summary.read_text())
    assert pdf_payload["document_type"] == "hybrisight_pdf_ready_summary"


def test_scan_sign_without_key_shows_guidance_not_traceback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("HYBRISIGHT_SIGNING_KEY", raising=False)
    monkeypatch.delenv("HYBRISIGHT_SIGNING_PRIVATE_KEY", raising=False)
    monkeypatch.setenv("HYBRISIGHT_SIGNING_PRIVATE_KEY_FILE", str(tmp_path / "missing-private.pem"))
    key_file = tmp_path / "signing.key"
    monkeypatch.setenv("HYBRISIGHT_SIGNING_KEY_FILE", str(key_file))

    findings = tmp_path / "findings.json"
    res = runner.invoke(app, ["scan", "aws", "--demo", "--sign", "--output", str(findings)])
    output = f"{res.stdout}{getattr(res, 'stderr', '')}"

    assert res.exit_code == 1
    assert "Signing key is required when using --sign." in output
    assert "Credential handling guide:" in output
    assert "Traceback" not in output


def test_scan_sign_uses_key_file_when_present(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("HYBRISIGHT_SIGNING_KEY", raising=False)
    key_file = tmp_path / "signing.key"
    key_file.write_text("test-file-signing-key\n")
    monkeypatch.setenv("HYBRISIGHT_SIGNING_KEY_FILE", str(key_file))

    findings = tmp_path / "findings.json"
    signature = tmp_path / "findings.sig.json"
    res = runner.invoke(
        app,
        ["scan", "aws", "--demo", "--sign", "--output", str(findings), "--signature-output", str(signature)],
    )

    assert res.exit_code == 0, res.stdout
    assert findings.exists()
    assert signature.exists()


def test_signing_init_generates_keypair(tmp_path: Path) -> None:
    private_key = tmp_path / "private.pem"
    public_key = tmp_path / "public.pem"
    res = runner.invoke(
        app,
        ["signing", "init", "--private-key-file", str(private_key), "--public-key-file", str(public_key)],
    )
    assert res.exit_code == 0, res.stdout
    assert private_key.exists()
    assert public_key.exists()
    assert "BEGIN PRIVATE KEY" in private_key.read_text()
    assert "BEGIN PUBLIC KEY" in public_key.read_text()


def test_signing_register_posts_public_key(monkeypatch, tmp_path: Path) -> None:
    public_key = tmp_path / "public.pem"
    public_key.write_text(
        "-----BEGIN PUBLIC KEY-----\n"
        "MCowBQYDK2VwAyEAT5o8M4+ifmY9V5zEg6MvhFhQx5efK6mL0fC6w0o7R6A=\n"
        "-----END PUBLIC KEY-----\n"
    )
    monkeypatch.setattr(
        "hybrisight.cli.httpx.Client",
        lambda: _MockHttpxClient([{"tenant_id": 1, "key_id": "abc", "algorithm": "ed25519"}]),
    )
    res = runner.invoke(
        app,
        [
            "signing",
            "register",
            "--public-key-file",
            str(public_key),
            "--url",
            "http://localhost:8080",
            "--api-key",
            "k_test",
            "--key-id",
            "abc",
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert "Public key registered" in res.stdout


def test_signing_sign_artifact_writes_sidecar(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.json"
    artifact.write_text(
        '{"schema_version":"1.1","coverage_level":"full","scoring_version":"1.0","risk_index":10.0,'
        '"posture_score":9.0,"confidence_adjusted_score":9.0,"top_finding_ids":[],"scanned_provider":"aws",'
        '"asset_count":1,"finding_count":0,"findings":[],"generated_at_utc":"2026-02-26T00:00:00+00:00"}'
    )
    signature = tmp_path / "artifact.sig.json"
    res = runner.invoke(
        app,
        ["signing", "sign-artifact", "--input", str(artifact), "--signature-output", str(signature)],
    )
    assert res.exit_code == 0, res.stdout
    assert signature.exists()
    payload = json.loads(signature.read_text())
    assert payload.get("algorithm") in {"ed25519", "hmac-sha256"}


def test_signing_sign_artifact_embed_requires_output(tmp_path: Path) -> None:
    artifact = tmp_path / "artifact.json"
    artifact.write_text(
        '{"schema_version":"1.1","coverage_level":"full","scoring_version":"1.0","risk_index":10.0,'
        '"posture_score":9.0,"confidence_adjusted_score":9.0,"top_finding_ids":[],"scanned_provider":"aws",'
        '"asset_count":1,"finding_count":0,"findings":[],"generated_at_utc":"2026-02-26T00:00:00+00:00"}'
    )
    signature = tmp_path / "artifact.sig.json"
    res = runner.invoke(
        app,
        ["signing", "sign-artifact", "--input", str(artifact), "--signature-output", str(signature), "--embed-signature", "--output", str(artifact)],
    )
    assert res.exit_code == 0, res.stdout


def test_cli_upload_with_exchange_and_upload(monkeypatch, tmp_path: Path) -> None:
    artifact = tmp_path / "findings.json"
    artifact.write_text('{"schema_version":"1.1","coverage_level":"full","scanned_provider":"aws","asset_count":1,"finding_count":0,"findings":[],"generated_at_utc":"2026-02-22T00:00:00+00:00"}')

    responses = [
        {
            "token": "tok123",
            "upload_endpoint": "/api/v1/scan-jobs/upload",
            "command_payload": {
                "token": "tok123",
                "tenant_id": 1,
                "expires_at": "2026-02-22T00:30:00+00:00",
                "upload_endpoint": "/api/v1/scan-jobs/upload",
                "source_type": "scanresult",
            },
            "command_signature": "sig123",
        },
        {
            "upload_id": 42,
            "finding_count": 0,
            "coverage_level": "full",
            "signature_valid": None,
        },
    ]

    monkeypatch.setattr(
        "hybrisight.cli.httpx.Client",
        lambda: _MockHttpxClient(responses),
    )

    res = runner.invoke(
        app,
        [
            "upload",
            "--artifact",
            str(artifact),
            "--url",
            "http://localhost:8080",
            "--api-key",
            "k_test",
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert "Success! Upload ID: 42" in res.stdout


def test_cli_upload_accepts_output_alias(monkeypatch, tmp_path: Path) -> None:
    artifact = tmp_path / "findings.json"
    artifact.write_text('{"schema_version":"1.1","coverage_level":"full","scanned_provider":"aws","asset_count":1,"finding_count":0,"findings":[],"generated_at_utc":"2026-02-22T00:00:00+00:00"}')

    responses = [
        {
            "token": "tok123",
            "upload_endpoint": "/api/v1/scan-jobs/upload",
            "command_payload": {
                "token": "tok123",
                "tenant_id": 1,
                "expires_at": "2026-02-22T00:30:00+00:00",
                "upload_endpoint": "/api/v1/scan-jobs/upload",
                "source_type": "scanresult",
            },
            "command_signature": "sig123",
        },
        {
            "upload_id": 43,
            "finding_count": 0,
            "coverage_level": "full",
            "signature_valid": None,
        },
    ]

    monkeypatch.setattr(
        "hybrisight.cli.httpx.Client",
        lambda: _MockHttpxClient(responses),
    )

    res = runner.invoke(
        app,
        [
            "upload",
            "--output",
            str(artifact),
            "--url",
            "http://localhost:8080",
            "--api-key",
            "k_test",
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert "Success! Upload ID: 43" in res.stdout


class _MockTextResponse:
    def __init__(self, text: str = "", payload: dict | None = None):
        self.text = text
        self._payload = payload or {}

    def raise_for_status(self) -> None:
        return

    def json(self) -> dict:
        return self._payload


class _MockAuthClient:
    def __init__(self):
        self._post_count = 0

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def get(self, url: str, *args, **kwargs):
        return _MockTextResponse('<input type="hidden" name="csrf_token" value="csrf123"/>')

    def post(self, url: str, *args, **kwargs):
        self._post_count += 1
        if self._post_count == 1:
            return _MockTextResponse(payload={"access_token": "session-token"})
        return _MockTextResponse(payload={"api_key": "k_auto_generated"})


class _MockUploadAutoClient:
    def __init__(self):
        self._exchange_done = False
        self.posts: list[tuple[str, dict]] = []

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def post(self, url: str, *args, **kwargs):
        self.posts.append((url, kwargs))
        if url.endswith("/api/v1/scan-jobs/exchange"):
            data = kwargs.get("data", {})
            return _MockResponse(
                {
                    "token": "tok_auto",
                    "upload_endpoint": "/api/v1/scan-jobs/upload",
                    "command_payload": {
                        "token": "tok_auto",
                        "tenant_id": 1,
                        "expires_at": "2026-02-22T00:30:00+00:00",
                        "upload_endpoint": "/api/v1/scan-jobs/upload",
                        "source_type": "scanresult",
                        **({k: v for k, v in data.items() if k in {"engagement_label", "engagement_key", "scope_label", "scope_fingerprint", "series_label", "series_key", "series_cadence"}}),
                    },
                    "command_signature": "sig_auto",
                }
            )
        return _MockResponse({"upload_id": 99, "finding_count": 0, "coverage_level": "full", "signature_valid": None})


def test_cli_auth_login_stores_profile(monkeypatch, tmp_path: Path) -> None:
    cfg = tmp_path / "cli-config.json"
    monkeypatch.setenv("HYBRISIGHT_CONFIG", str(cfg))
    monkeypatch.setattr("hybrisight.cli.httpx.Client", lambda *args, **kwargs: _MockAuthClient())

    res = runner.invoke(
        app,
        [
            "auth",
            "login",
            "--url",
            "http://localhost:8080",
            "--email",
            "shawnthompson66@gmail.com",
            "--password",
            "admin123",
        ],
    )
    assert res.exit_code == 0, res.stdout
    data = json.loads(cfg.read_text())
    assert data["portal"]["url"] == "http://localhost:8080"
    assert data["api_keys"]["http://localhost:8080"] == "k_auto_generated"

def test_cli_upload_auto_provisions_when_key_missing(monkeypatch, tmp_path: Path) -> None:
    artifact = tmp_path / "findings.json"
    artifact.write_text('{"schema_version":"1.1","coverage_level":"full","scanned_provider":"aws","asset_count":1,"finding_count":0,"findings":[],"generated_at_utc":"2026-02-22T00:00:00+00:00"}')

    cfg = tmp_path / "cli-config.json"
    monkeypatch.setenv("HYBRISIGHT_CONFIG", str(cfg))
    monkeypatch.setattr("hybrisight.cli._provision_api_key_via_login", lambda *args, **kwargs: "k_auto_generated")
    monkeypatch.setattr("hybrisight.cli.httpx.Client", lambda *args, **kwargs: _MockUploadAutoClient())

    res = runner.invoke(
        app,
        [
            "upload",
            "--artifact",
            str(artifact),
            "--url",
            "http://localhost:8080",
            "--auto-provision",
            "--yes",
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert "Auto-provisioned API key" in res.stdout
    assert "Success! Upload ID: 99" in res.stdout

def test_cli_upload_passes_continuity_override_fields(monkeypatch, tmp_path: Path) -> None:
    artifact = tmp_path / "findings.json"
    artifact.write_text('{"schema_version":"1.1","coverage_level":"full","scanned_provider":"aws","asset_count":1,"finding_count":0,"findings":[],"generated_at_utc":"2026-02-22T00:00:00+00:00"}')

    client = _MockUploadAutoClient()
    monkeypatch.setattr("hybrisight.cli.httpx.Client", lambda *args, **kwargs: client)

    res = runner.invoke(
        app,
        [
            "upload",
            "--artifact",
            str(artifact),
            "--url",
            "http://localhost:8080",
            "--api-key",
            "k_test",
            "--engagement-label",
            "Q2 2026 Pilot Landing Zone",
            "--engagement-key",
            "pilot-landing-zone-q2-2026",
            "--scope-label",
            "AWS Shared Services Accounts",
            "--scope-fingerprint",
            "aws:accounts=111111111111,222222222222:env=shared",
            "--series-label",
            "Quarterly Shared Services Review",
            "--series-key",
            "shared-services-quarterly",
            "--series-cadence",
            "quarterly",
        ],
    )
    assert res.exit_code == 0, res.stdout
    exchange_call = next(kwargs for url, kwargs in client.posts if url.endswith("/api/v1/scan-jobs/exchange"))
    assert exchange_call["data"]["engagement_label"] == "Q2 2026 Pilot Landing Zone"
    assert exchange_call["data"]["engagement_key"] == "pilot-landing-zone-q2-2026"
    assert exchange_call["data"]["scope_label"] == "AWS Shared Services Accounts"
    assert exchange_call["data"]["scope_fingerprint"] == "aws:accounts=111111111111,222222222222:env=shared"
    assert exchange_call["data"]["series_label"] == "Quarterly Shared Services Review"
    assert exchange_call["data"]["series_key"] == "shared-services-quarterly"
    assert exchange_call["data"]["series_cadence"] == "quarterly"
    upload_call = next(kwargs for url, kwargs in client.posts if url.endswith("/api/v1/scan-jobs/upload"))
    assert upload_call["data"]["engagement_label"] == "Q2 2026 Pilot Landing Zone"
    assert upload_call["data"]["engagement_key"] == "pilot-landing-zone-q2-2026"
    assert upload_call["data"]["scope_label"] == "AWS Shared Services Accounts"
    assert upload_call["data"]["scope_fingerprint"] == "aws:accounts=111111111111,222222222222:env=shared"
    assert upload_call["data"]["series_label"] == "Quarterly Shared Services Review"
    assert upload_call["data"]["series_key"] == "shared-services-quarterly"
    assert upload_call["data"]["series_cadence"] == "quarterly"

def test_cli_report_pdf_single_command(monkeypatch, tmp_path) -> None:
    findings = tmp_path / "findings.json"
    pdf_report = tmp_path / "report.pdf"

    scan_res = runner.invoke(
        app,
        [
            "scan",
            "aws",
            "--demo",
            "--output",
            str(findings),
        ],
    )
    assert scan_res.exit_code == 0, scan_res.stdout

    def _fake_render(result, output):
        output.write_bytes(b"%PDF-1.4\n%mock\n")
        return "mock"

    monkeypatch.setattr("hybrisight.cli.render_pdf_report", _fake_render)

    report_res = runner.invoke(
        app,
        ["report", "--input", str(findings), "--format", "pdf", "--output", str(pdf_report)],
    )
    assert report_res.exit_code == 0, report_res.stdout
    # assert "PDF renderer: mock" in report_res.stdout
    assert pdf_report.exists()

def test_cli_report_native_export_cost_html(tmp_path) -> None:
    native = tmp_path / "cost.json"
    native.write_text('[{"cost": 1234.56}, {"cost": 10}]')
    html_report = tmp_path / "native-cost-report.html"

    res = runner.invoke(
        app,
        [
            "report",
            "--input",
            str(native),
            "--format",
            "html",
            "--output",
            str(html_report),
            "--source-type",
            "native-export",
            "--provider",
            "aws",
            "--export-type",
            "aws_cost_export",
        ],
    )

    assert res.exit_code == 0, res.stdout
    assert html_report.exists()
    assert "Imported cost management signal" in html_report.read_text()

def test_cli_report_native_export_requires_provider_and_export_type(tmp_path) -> None:
    native = tmp_path / "native.json"
    native.write_text('[]')

    res_missing_provider = runner.invoke(
        app,
        [
            "report",
            "--input",
            str(native),
            "--source-type",
            "native-export",
            "--export-type",
            "aws_cost_export",
        ],
    )
    assert res_missing_provider.exit_code != 0
    assert "--provider is required" in res_missing_provider.output

    res_missing_export = runner.invoke(
        app,
        [
            "report",
            "--input",
            str(native),
            "--source-type",
            "native-export",
            "--provider",
            "aws",
        ],
    )
    assert res_missing_export.exit_code != 0
    assert "--export-type is required" in res_missing_export.output

def test_cli_report_auto_detects_native_export_cost(tmp_path) -> None:
    native = tmp_path / "cost-native.json"
    native.write_text('[{"service":"AmazonEC2","cost":123.4,"region":"us-east-1"}]')
    html_report = tmp_path / "auto-native-report.html"

    res = runner.invoke(
        app,
        [
            "report",
            "--input",
            str(native),
            "--format",
            "html",
            "--output",
            str(html_report),
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert html_report.exists()
    assert "Imported cost management signal" in html_report.read_text()

def test_cli_report_auto_detects_guardduty_export(tmp_path) -> None:
    native = tmp_path / "guardduty-native.json"
    native.write_text('[{"finding_id":"gd-001","type":"Trojan:EC2/DropPoint","severity":8.0,"title":"EC2 instance communicating with malware C2"}]')
    html_report = tmp_path / "auto-guardduty-report.html"

    res = runner.invoke(
        app,
        [
            "report",
            "--input",
            str(native),
            "--format",
            "html",
            "--output",
            str(html_report),
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert html_report.exists()
    body = html_report.read_text()
    assert "GuardDuty" in body or "guardduty" in body
