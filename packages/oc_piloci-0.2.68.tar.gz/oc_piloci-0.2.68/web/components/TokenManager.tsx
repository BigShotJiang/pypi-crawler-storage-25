"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Copy, Trash2, Check, ChevronUp } from "lucide-react";
import { api } from "@/lib/api";
import type { ApiToken, CreatedToken, Project } from "@/lib/types";
import { useTranslation } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

function CopyBlock({ value, label, sensitive }: { value: string; label?: string; sensitive?: boolean }) {
  const [copied, setCopied] = useState(false);
  const { t } = useTranslation();

  const handleCopy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const display = sensitive
    ? `${value.slice(0, 12)}${"·".repeat(24)}`
    : value;

  return (
    <div className="space-y-1.5">
      {label && <p className="text-xs text-muted-foreground">{label}</p>}
      <div className="flex items-center gap-2 rounded-md border bg-muted p-3">
        {sensitive ? (
          <code className="flex-1 truncate font-mono text-xs">{display}</code>
        ) : (
          <pre className="flex-1 overflow-x-auto whitespace-pre-wrap break-all font-mono text-xs leading-relaxed select-text">{value}</pre>
        )}
        <Button
          size="sm"
          variant={copied ? "default" : "outline"}
          className="shrink-0 gap-1.5 text-xs"
          onClick={handleCopy}
        >
          {copied ? <><Check className="size-3" />{t.common.copied}</> : <><Copy className="size-3" />{t.common.copy}</>}
        </Button>
      </div>
    </div>
  );
}

function buildMcpConfigs(token: string, baseUrl: string) {
  const auth = `Bearer ${token}`;
  const httpUrl = `${baseUrl}/mcp/http`;
  return {
    claude: JSON.stringify({
      mcpServers: { piloci: { type: "http", url: httpUrl, headers: { Authorization: auth } } },
    }, null, 2),
    opencode: JSON.stringify({
      $schema: "https://opencode.ai/config.json",
      mcp: { piloci: { type: "remote", url: httpUrl, enabled: true, headers: { Authorization: auth } } },
    }, null, 2),
  };
}

function SetupDialog({ data, onClose }: { data: CreatedToken; onClose: () => void }) {
  const { t } = useTranslation();
  const [showManual, setShowManual] = useState(false);
  const baseUrl = typeof window !== "undefined" ? window.location.origin : "https://piloci.opencourse.kr";
  const configs = buildMcpConfigs(data.token, baseUrl);
  const hasHook = !!data.setup?.hook_config;
  const hookSettingsJson = data.setup ? JSON.stringify(data.setup.hook_config, null, 2) : null;
  const hookConfigJson = data.setup?.hook_config_json
    ? JSON.stringify(data.setup.hook_config_json, null, 2)
    : null;
  const hookInstallCmd = `mkdir -p ~/.config/piloci && curl -sSL -H "Authorization: Bearer ${data.token}" ${baseUrl}/api/hook/script -o ~/.config/piloci/hook.py`;
  const claudeMd = data.setup?.claude_md ?? null;
  const installCommand = data.setup?.install_command ?? null;
  const installCommandWindows = data.setup?.install_command_windows ?? null;
  const defaultTab = installCommand ? "install" : hasHook ? "install" : "token";

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="flex max-h-[85vh] max-w-lg flex-col gap-0 p-0">
        <DialogHeader className="shrink-0 border-b px-6 pb-4 pt-6">
          <DialogTitle>{t.tokenManager.tokenCreated}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue={defaultTab} className="flex min-h-0 flex-1 flex-col">
          <div className="shrink-0 px-6 pt-4">
            <TabsList className="w-full">
              {hasHook && (
                <TabsTrigger value="install" className="flex-1">
                  {t.tokenManager.tabs.install}
                </TabsTrigger>
              )}
              <TabsTrigger value="mcp" className="flex-1">{t.tokenManager.tabs.mcpServer}</TabsTrigger>
              <TabsTrigger value="token" className="flex-1">{t.tokenManager.tabs.token}</TabsTrigger>
              {claudeMd && <TabsTrigger value="claudemd" className="flex-1">{t.tokenManager.tabs.claudeMd}</TabsTrigger>}
            </TabsList>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto px-6 pb-6 pt-2">
          {hasHook && (
            <TabsContent value="install" className="space-y-4 pt-1">
              <div className="space-y-1">
                <p className="text-sm font-semibold text-foreground">
                  {t.tokenManager.quickInstallTitle}
                </p>
                <p className="text-xs text-muted-foreground">
                  {t.tokenManager.quickInstallDesc}
                </p>
              </div>

              {installCommand ? (
                <ol className="space-y-3">
                  <li className="space-y-1.5">
                    <p className="text-xs font-semibold text-foreground">
                      {t.tokenManager.quickStep1}
                    </p>
                    <p className="text-[11px] leading-relaxed text-muted-foreground">
                      {t.tokenManager.quickStep1Desc}
                    </p>
                    <CopyBlock value={installCommand} label="macOS / Linux (bash)" />
                    {installCommandWindows && (
                      <CopyBlock
                        value={installCommandWindows}
                        label={t.tokenManager.crossPlatformLabel}
                      />
                    )}
                  </li>
                  <li className="space-y-1">
                    <p className="text-xs font-semibold text-foreground">
                      {t.tokenManager.quickStep2}
                    </p>
                    <p className="text-[11px] leading-relaxed text-muted-foreground">
                      {t.tokenManager.quickStep2Desc}
                    </p>
                  </li>
                  <li className="space-y-1">
                    <p className="text-xs font-semibold text-foreground">
                      {t.tokenManager.quickStep3}
                    </p>
                    <p className="text-[11px] leading-relaxed text-muted-foreground">
                      {t.tokenManager.quickStep3Desc}
                    </p>
                  </li>
                </ol>
              ) : (
                <p className="text-xs text-destructive">
                  {t.tokenManager.quickInstallNoCode}
                </p>
              )}

              <div className="border-t pt-3">
                <button
                  type="button"
                  onClick={() => setShowManual((v) => !v)}
                  className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                >
                  {showManual ? (
                    <>
                      <ChevronUp className="size-3" />
                      {t.tokenManager.manualInstallHide}
                    </>
                  ) : (
                    <>
                      <ChevronUp className="size-3 rotate-180" />
                      {t.tokenManager.manualInstallToggle}
                    </>
                  )}
                </button>
                {showManual && (
                  <div className="mt-3 space-y-4">
                    <p className="text-xs text-muted-foreground">
                      {t.tokenManager.manualInstallNote}
                    </p>
                    <div className="space-y-2">
                      <p className="text-xs font-semibold text-foreground">{t.tokenManager.hookStep1}</p>
                      <p className="text-xs text-muted-foreground">{t.tokenManager.hookStep1Desc}</p>
                      <CopyBlock value={hookInstallCmd} />
                    </div>
                    {hookConfigJson && (
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-foreground">{t.tokenManager.hookStep2}</p>
                        <p className="text-xs text-muted-foreground">{t.tokenManager.hookStep2Desc}</p>
                        <CopyBlock value={hookConfigJson} />
                      </div>
                    )}
                    {hookSettingsJson && (
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-foreground">{t.tokenManager.hookStep3}</p>
                        <p className="text-xs text-muted-foreground">{t.tokenManager.hookStep3Desc}</p>
                        <CopyBlock value={hookSettingsJson} />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </TabsContent>
          )}

          <TabsContent value="mcp" className="pt-1">
            <Tabs defaultValue="claude">
              <TabsList>
                <TabsTrigger value="claude">Claude</TabsTrigger>
                <TabsTrigger value="opencode">OpenCode</TabsTrigger>
              </TabsList>
              <TabsContent value="claude" className="space-y-2 pt-3">
                <p className="text-xs text-muted-foreground">
                  Claude Desktop / Claude Code / Cursor — <code className="rounded bg-muted px-1 py-0.5">.mcp.json</code> {t.tokenManager.mcpClaudeOr} <code className="rounded bg-muted px-1 py-0.5">claude_desktop_config.json</code>
                </p>
                <CopyBlock value={configs.claude} />
              </TabsContent>
              <TabsContent value="opencode" className="space-y-2 pt-3">
                <p className="text-xs text-muted-foreground">
                  OpenCode — <code className="rounded bg-muted px-1 py-0.5">opencode.json</code> (<code className="rounded bg-muted px-1 py-0.5">type: &quot;remote&quot;</code> {t.tokenManager.mcpOpencodeRemote})
                </p>
                <CopyBlock value={configs.opencode} />
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="token" className="space-y-3 pt-1">
            <p className="text-sm text-destructive">{t.tokenManager.tokenWarning}</p>
            <CopyBlock value={data.token} sensitive />
          </TabsContent>

          {claudeMd && (
            <TabsContent value="claudemd" className="space-y-3 pt-1">
              <p className="text-sm text-muted-foreground">{t.tokenManager.claudeMdInstructions}</p>
              <CopyBlock value={claudeMd} />
            </TabsContent>
          )}
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export function TokenManager() {
  const queryClient = useQueryClient();
  const { t } = useTranslation();
  const [showCreate, setShowCreate] = useState(false);
  const [formName, setFormName] = useState("");
  const [formExpireDays, setFormExpireDays] = useState<number | null>(365);
  const [createdToken, setCreatedToken] = useState<CreatedToken | null>(null);
  const [selectedTokenId, setSelectedTokenId] = useState<string | null>(null);

  const { data: tokens = [], isLoading, isError, error, refetch } = useQuery<ApiToken[]>({
    queryKey: ["tokens"],
    queryFn: () => api.listTokens(),
    retry: 1,
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["projects"],
    queryFn: () => api.listProjects(),
  });

  const createMutation = useMutation({
    mutationFn: ({
      name,
      scope,
      project_id,
      expire_days,
    }: {
      name: string;
      scope: "user" | "project";
      project_id?: string;
      expire_days?: number | null;
    }) => api.createToken(name, scope, project_id, expire_days) as Promise<CreatedToken>,
    onSuccess: (data) => {
      setCreatedToken(data);
      queryClient.invalidateQueries({ queryKey: ["tokens"] });
      setShowCreate(false);
      setFormName("");
      setFormExpireDays(365);
    },
  });

  const revokeMutation = useMutation({
    mutationFn: (id: string) => api.revokeToken(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tokens"] }),
  });

  const handleCreate = (e: { preventDefault(): void }) => {
    e.preventDefault();
    if (!formName.trim()) return;
    createMutation.mutate({
      name: formName.trim(),
      scope: "user",
      project_id: undefined,
      expire_days: formExpireDays,
    });
  };

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
    });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{t.tokenManager.desc}</p>
        <Button size="sm" onClick={() => setShowCreate(true)}>
          <Plus className="mr-1 size-4" /> {t.tokenManager.issue}
        </Button>
      </div>

      {createdToken && (
        <SetupDialog data={createdToken} onClose={() => setCreatedToken(null)} />
      )}

      {showCreate && (
        <Card className="border-dashed bg-muted/30 shadow-none">
          <CardContent className="p-4">
            <form onSubmit={handleCreate} className="space-y-3">
              <div className="space-y-1.5">
                <Label>{t.tokenManager.formName}</Label>
                <Input
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder={t.tokenManager.formNamePlaceholder}
                />
              </div>
              {/* Project-scoped tokens were retired in v0.2.68 — projects are
                  auto-classified from cwd by ingest, so a single user token
                  covers every workspace. */}
              <div className="space-y-1.5">
                <Label>{t.tokenManager.formExpire}</Label>
                <Select
                  value={formExpireDays === null ? "none" : String(formExpireDays)}
                  onValueChange={(v) => setFormExpireDays(v === "none" ? null : Number(v))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">{t.tokenManager.expireOptions.d30}</SelectItem>
                    <SelectItem value="90">{t.tokenManager.expireOptions.d90}</SelectItem>
                    <SelectItem value="180">{t.tokenManager.expireOptions.d180}</SelectItem>
                    <SelectItem value="365">{t.tokenManager.expireOptions.d365}</SelectItem>
                    <SelectItem value="none">{t.tokenManager.expireOptions.none}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {createMutation.error && (
                <p className="text-sm text-destructive">
                  {(createMutation.error as Error).message}
                </p>
              )}
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowCreate(false)}>
                  {t.tokenManager.cancel}
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || !formName.trim()}
                >
                  {createMutation.isPending ? t.tokenManager.issuing : t.tokenManager.issue}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : isError ? (
        <Card>
          <CardContent className="py-6 text-center space-y-3">
            <p className="text-sm text-destructive">
              {(error as Error)?.message || t.tokenManager.loadFailed}
            </p>
            <Button size="sm" variant="outline" onClick={() => refetch()}>{t.tokenManager.retry}</Button>
          </CardContent>
        </Card>
      ) : tokens.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            {t.tokenManager.noTokens}
          </CardContent>
        </Card>
      ) : (
        <div className="overflow-x-auto rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t.tokenManager.tableHeaders.name}</TableHead>
                <TableHead className="hidden sm:table-cell">{t.tokenManager.tableHeaders.scope}</TableHead>
                <TableHead className="hidden md:table-cell">{t.tokenManager.tableHeaders.issued}</TableHead>
                <TableHead className="hidden md:table-cell">{t.tokenManager.tableHeaders.lastUsed}</TableHead>
                <TableHead>{t.tokenManager.tableHeaders.expires}</TableHead>
                <TableHead className="w-16" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {tokens.map((token) => {
                const project = token.project_id
                  ? projects.find((p) => p.id === token.project_id)
                  : undefined;
                const isExpired = token.expires_at ? new Date(token.expires_at) < new Date() : false;
                return (
                  <TableRow
                    key={token.token_id}
                    className={`cursor-pointer ${selectedTokenId === token.token_id ? "bg-accent/50" : ""}`}
                    onClick={() => setSelectedTokenId(selectedTokenId === token.token_id ? null : token.token_id)}
                  >
                    <TableCell className="font-medium">
                      <div className="flex flex-col gap-0.5">
                        <span>
                          {token.name}
                          {project && (
                            <span className="ml-2 text-xs text-muted-foreground">
                              ({project.slug})
                            </span>
                          )}
                        </span>
                        {token.installed_at ? (
                          <span className="text-[11px] text-muted-foreground">
                            {t.tokenManager.installedOn} {formatDate(token.installed_at)}
                            {token.client_kinds && token.client_kinds.length > 0 && (
                              <> · {token.client_kinds.join(" + ")}</>
                            )}
                            {token.hostname && <> · {token.hostname}</>}
                          </span>
                        ) : (
                          <span className="text-[11px] text-muted-foreground/70">
                            {t.tokenManager.notInstalled}
                          </span>
                        )}
                        <span className="sm:hidden">
                          <Badge variant={token.scope === "user" ? "default" : "secondary"} className="text-xs">
                            {token.scope}
                          </Badge>
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <Badge variant={token.scope === "user" ? "default" : "secondary"}>
                        {token.scope}
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                      {formatDate(token.created_at)}
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                      {token.last_used_at ? formatDate(token.last_used_at) : "-"}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {token.expires_at
                        ? isExpired
                          ? <span className="text-destructive">{t.tokenManager.expired}</span>
                          : formatDate(token.expires_at)
                        : t.tokenManager.expiresNone}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-muted-foreground hover:text-destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (window.confirm(`"${token.name}" ${t.tokenManager.confirmRevoke}`)) {
                            revokeMutation.mutate(token.token_id);
                          }
                        }}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {selectedTokenId && (() => {
        const sel = tokens.find((t) => t.token_id === selectedTokenId);
        if (!sel) return null;
        const baseUrl = typeof window !== "undefined" ? window.location.origin : "https://piloci.opencourse.kr";
        const placeholder = t.tokenManager.tokenPlaceholder;
        const detailConfigs = buildMcpConfigs(placeholder, baseUrl);
        const isProjectScoped = sel.scope === "project";

        const claudeMdSnippet = isProjectScoped
          ? "## piLoci Memory\n\n"
            + "Use piLoci MCP tools to maintain context across sessions:\n\n"
            + "1. **Session start**: Call `recall` with a query about the current task "
            + "to load relevant memories from past sessions\n"
            + "2. **Save actively**: Use `memory` throughout the conversation to save facts, "
            + "decisions, preferences, code patterns, and insights. When in doubt, SAVE.\n"
            + '3. **Tags**: Add 1-3 tags when saving (e.g. `["architecture", "bugfix", "preference"]`)\n'
          : null;

        return (
          <div className="mt-4 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">{t.tokenManager.mcpConfigFor} &ldquo;{sel.name}&rdquo;</p>
              <Button variant="ghost" size="sm" onClick={() => setSelectedTokenId(null)}>
                <ChevronUp className="size-4" />
              </Button>
            </div>
            <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300">
              {t.tokenManager.tokenPasteNotice}
            </div>
            <Card className="border bg-card shadow-sm">
              <CardContent className="p-4">
                <Tabs defaultValue="claude-desktop">
                  <TabsList className="flex-wrap h-auto">
                    <TabsTrigger value="claude-desktop">Claude Desktop</TabsTrigger>
                    <TabsTrigger value="claude-code">Claude Code</TabsTrigger>
                    <TabsTrigger value="opencode">OpenCode</TabsTrigger>
                    <TabsTrigger value="cursor">Cursor</TabsTrigger>
                    {claudeMdSnippet && <TabsTrigger value="claude-md">{t.tokenManager.tabs.claudeMd}</TabsTrigger>}
                  </TabsList>

                  <TabsContent value="claude-desktop" className="space-y-2 pt-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="rounded bg-muted px-1.5 py-0.5 font-mono">~/Library/Application Support/Claude/claude_desktop_config.json</span>
                    </div>
                    <CopyBlock value={detailConfigs.claude} />
                  </TabsContent>

                  <TabsContent value="claude-code" className="space-y-2 pt-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="rounded bg-muted px-1.5 py-0.5 font-mono">~/.claude.json</span>
                      <span className="text-border">|</span>
                      <span className="rounded bg-muted px-1.5 py-0.5 font-mono">.mcp.json</span>
                    </div>
                    <CopyBlock value={detailConfigs.claude} />
                  </TabsContent>

                  <TabsContent value="opencode" className="space-y-2 pt-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="rounded bg-muted px-1.5 py-0.5 font-mono">opencode.json</span>
                    </div>
                    <CopyBlock value={detailConfigs.opencode} />
                  </TabsContent>

                  <TabsContent value="cursor" className="space-y-2 pt-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="rounded bg-muted px-1.5 py-0.5 font-mono">~/.cursor/mcp.json</span>
                    </div>
                    <CopyBlock value={detailConfigs.claude} />
                  </TabsContent>

                  {claudeMdSnippet && (
                    <TabsContent value="claude-md" className="space-y-3 pt-3">
                      <p className="text-xs text-muted-foreground">{t.tokenManager.claudeMdInstructions}</p>
                      <CopyBlock value={claudeMdSnippet} />
                    </TabsContent>
                  )}
                </Tabs>
              </CardContent>
            </Card>
          </div>
        );
      })()}
    </div>
  );
}
