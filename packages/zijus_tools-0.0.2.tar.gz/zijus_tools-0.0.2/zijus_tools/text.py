import uuid
from datetime import datetime, timezone, timedelta

# Import the helper function from your internal context module
from .context import emit_message

async def SendTextMessage(message: str, delay: float = 0) -> str:
    """
    Send a text message to the user.

    Args:
        message (str): The text message to send.
        delay (float, optional): Time in seconds to wait before broadcasting. Defaults to 0.
        
    Returns:
        str: Status string indicating if the message was sent successfully.
    """
    base_timestamp = datetime.now(timezone.utc)
    if delay > 0:
        # Keeping the delay logic consistent with other tools
        base_timestamp = base_timestamp + timedelta(seconds=delay * 3)

    response = {
        "source": "assistant",
        "content": message,
        "m_id": str(uuid.uuid4()),
        "ts": base_timestamp.isoformat(),
        "type": "TextMessage"
    }
    
    # Broadcast using the context-aware emitter
    success = await emit_message(response)
    
    # Return a string so the LLM Agent gets clear text feedback on the tool's execution
    return "Message sent." if success else "Failed to send message."