import uuid
from typing import Optional
from datetime import datetime, timezone, timedelta

# Import the helper function from your internal context module
from .context import emit_message

async def SendDatePicker(
    type: str = "date", 
    min_date: Optional[str] = None, 
    max_date: Optional[str] = None, 
    content: str = "", 
    response_format: Optional[str] = None, 
    delay: float = 3
) -> bool:
    """
    Builds a date/time picker component and broadcasts it to the user.
    
    Args:
        type (str, optional): The type of picker. Can be "date", "time", or "datetime".
                                Defaults to "date".
        min_date (str, optional): The minimum selectable date in "YYYY-MM-DD" ISO format.
                                    Defaults to None.
        max_date (str, optional): The maximum selectable date in "YYYY-MM-DD" ISO format.
                                    Defaults to None.
        content (str, optional): A message to display with the picker. Defaults to "".
        response_format (str, optional): The desired format for the returned date string,
                                            using standard date formatting codes (e.g., "%d/%m/%Y").
                                            Defaults to None (UI default, likely ISO 8601).
        delay (float, optional): Delay in seconds before broadcasting the message. Defaults to 3.
        
    Returns:
        True if the datepicker was successfully sent, False otherwise.
    """
    # Step 1: Validate input parameters
    valid_types = ["date", "time", "datetime"]
    if type not in valid_types:
        return False

    validated_min_date = None
    validated_max_date = None

    try:
        if min_date:
            datetime.fromisoformat(min_date)
            validated_min_date = min_date
        if max_date:
            datetime.fromisoformat(max_date)
            validated_max_date = max_date
            
        if validated_min_date and validated_max_date:
            if datetime.fromisoformat(validated_min_date) >= datetime.fromisoformat(validated_max_date):
                return False
    except ValueError:
        return False

    # Step 2: Build the datepicker payload
    datepicker_payload = {
        "type": type,
        "min_date": validated_min_date,
        "max_date": validated_max_date,
        "response_format": response_format,
    }

    # Step 3: Build the full response message and broadcast it
    ts = datetime.now(timezone.utc)
    if delay > 0:
        ts += timedelta(seconds=delay)
        
    response = {
        "source": "assistant",
        "content": content,
        "m_id": str(uuid.uuid4()),
        "datepicker": datepicker_payload,
        "ts": ts.isoformat(),
        "type": "DatePickerMessage",
    }

    # Broadcast using the context-aware emitter
    return await emit_message(response)