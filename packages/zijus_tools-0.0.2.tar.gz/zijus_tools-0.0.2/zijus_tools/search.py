import os
import json
import asyncio
import http.client
from typing import List, Dict

async def WebSearchWithSerperDev(query: str = "", number_of_pages: int = 5, country_code: str = "us") -> List[Dict[str, str]]:
    """
    Asynchronously fetches search results from the Serper.dev API and returns a list 
    of dictionaries containing the 'link' and 'snippet' for each result.
    
    Args:
        query (str): The search query.
        number_of_pages (int): The maximum number of search results to return.
        country_code (str): The country code for localization (e.g., "us", "uk", "in").
        
    Returns:
        List[Dict[str, str]]: A list of search results with 'link' and 'snippet', 
                              or an error message.
    """
    if not query:
        return [{"error": "Search query is required."}]

    api_key = os.getenv('WEBSEARCH_API_KEY', '')
    if not api_key:
        return [{"error": "API key missing. Developer must set WEBSEARCH_API_KEY environment variable."}]

    # Synchronous HTTP request function to be run in a thread
    def fetch_data():
        conn = http.client.HTTPSConnection("google.serper.dev")
        payload = json.dumps({
            "q": query,
            "gl": country_code
        })
        headers = {
            'X-API-KEY': api_key,
            'Content-Type': 'application/json'
        }
        conn.request("POST", "/search", payload, headers)
        res = conn.getresponse()
        return json.loads(res.read().decode('utf-8'))

    # Await the synchronous blocking code in a background thread
    try:
        data = await asyncio.to_thread(fetch_data)
    except Exception as e:
        print(f"Error fetching search results: {e}")
        return [{"error": f"Search request failed: {str(e)}"}]

    # Extract the 'organic' results list, defaulting to an empty list if not present
    organic_results = data.get("organic", [])
        
    # Extract the link and snippet into a list of dictionaries.
    # Slicing [:number_of_pages] safely limits the results.
    extracted_results = [
        {
            "link": result.get("link", ""),
            "snippet": result.get("snippet", "")
        }
        for result in organic_results[:number_of_pages]
        if "link" in result  # Only include if it at least has a link
    ]
        
    return extracted_results