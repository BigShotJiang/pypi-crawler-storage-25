import uuid
from datetime import datetime, timezone, timedelta

# Import the helper function from your internal context module
from .context import emit_message

async def SendSlider(min_value: int, max_value: int, default_value: int, content: str = "", delay: float = 2) -> bool:
    """
    Creates a slider using integer parameters and broadcasts it.

    Args:
        min_value (int): The minimum integer value of the slider.
        max_value (int): The maximum integer value of the slider.
        default_value (int): The initial integer position of the slider.
        content (str, optional): Additional text to display alongside the slider.
            Defaults to an empty string.
        delay (float, optional): Time in seconds to wait before broadcasting
            the slider data. Defaults to 2.

    Returns:
        True if the slider was successfully sent, False otherwise.
    """
    # Step 1: Validate the slider data
    # Ensure all values are numbers (int or float)
    if not all(isinstance(v, (int, float)) for v in [min_value, max_value, default_value]):
        # This check is good practice for robustness
        return False

    # Ensure the values are logically consistent
    if not (min_value < max_value and min_value <= default_value <= max_value):
        return False

    validated_slider = {
        "min_value": min_value,
        "max_value": max_value,
        "default_value": default_value,
    }

    # Step 2: Build the message
    base_timestamp = datetime.now(timezone.utc)
    if delay > 0:
        base_timestamp = base_timestamp + timedelta(seconds=delay * 3)
        
    response = {
        "source": "assistant",
        "content": content,
        "m_id": str(uuid.uuid4()),
        "slider": validated_slider,
        "ts": base_timestamp.isoformat(),
        "type": "SliderMessage",
    }

    # Step 3: Broadcast using the context-aware emitter
    return await emit_message(response)