import json
import uuid
from typing import Any
from datetime import datetime, timezone, timedelta

# Import the helper function from your internal context module
from .context import emit_message

async def SendSlots(slots: Any, content: str = "", checkbox: bool = False, delay: float = 2) -> bool:
    """
    Parses slot information from a list or a string, converts it into a
    standardized list of slot dictionaries, and broadcasts the result.

    Args:
        slots: A list or a string representing slot data.
        content (str, optional): Additional text to display alongside the slots.
        checkbox (bool, optional): If True, displays the slots as checkboxes.
        delay (float, optional): Time in seconds to wait before broadcasting.
    """
    if not slots:
        return False

    parsed_items = []
    if isinstance(slots, str):
        cleaned_slots = slots.strip()
        if not cleaned_slots:
            return False
        try:
            parsed_items = json.loads(cleaned_slots)
            if not isinstance(parsed_items, list):
                parsed_items = []
        except json.JSONDecodeError:
            parsed_items = [item.strip() for item in cleaned_slots.split(',') if item.strip()]
    elif isinstance(slots, list):
        parsed_items = slots

    slot_list = []
    for item in parsed_items:
        if isinstance(item, str) and item.strip():
            slot_list.append({"label": item.strip(), "value": item.strip()})
        elif isinstance(item, dict):
            if "label" in item and "value" in item:
                slot_list.append(item)
            else:
                label = item.get("label", item.get("name", item.get("title")))
                value = item.get("value", item.get("id", item.get("key")))
                if label is not None and value is not None:
                    slot_list.append({"label": str(label), "value": str(value)})

    if not slot_list:
        return False
        
    base_timestamp = datetime.now(timezone.utc)
    if delay > 0:
        base_timestamp = base_timestamp + timedelta(seconds=delay * 3)
            
    response = {
        "source": "assistant",
        "content": content,
        "m_id": str(uuid.uuid4()),
        "slots": slot_list,
        "checkbox": checkbox,
        "ts": base_timestamp.isoformat(),
        "type": "SlotMessage"
    }
    
    # Super clean! Just pass the dictionary to the emit function
    return await emit_message(response)