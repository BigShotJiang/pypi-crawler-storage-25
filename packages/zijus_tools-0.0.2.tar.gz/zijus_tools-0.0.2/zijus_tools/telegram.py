import logging
import asyncio

async def SendTelegramMessage(markdown_message: str, bot_token: str, chat_id: str) -> bool:
    """
    Sends a Markdown-formatted message to a specified Telegram chat.
    
    Args:
        markdown_message (str): The text content, formatted with Markdown, to send.
        bot_token (str): The secret token of the Telegram bot.
        chat_id (str): The unique identifier for the target chat or channel ID.
        
    Returns:
        bool: True if the Telegram API returned a successful status (200), False otherwise.
    """
    # Step 1: Validate input - all three parameters are mandatory
    if not all([markdown_message, bot_token, chat_id]):
        logging.error("Error: markdown_message, bot_token, or chat_id cannot be empty.")
        return False

    # Attempt to import the optional dependency
    try:
        import requests
    except ImportError:
        logging.error("Error: `requests` is not installed. The developer needs to run `pip install requests`.")
        return False

    # Step 2: Define the API endpoint and payload
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': markdown_message,
        'parse_mode': 'Markdown' # Ensures the message text is parsed as Markdown
    }

    # Step 3: Define the blocking function
    def make_request():
        return requests.post(url, data=payload)

    # Step 4: Run the blocking function in a background thread to keep the async loop free
    try:
        response = await asyncio.to_thread(make_request)
        
        # Step 5: Check the response status
        if response.status_code == 200:
            # The Telegram API returns 200 OK for a successful message send.
            return True
        else:
            # Log the API error for debugging
            logging.error(f"Telegram API call failed with status code {response.status_code}. Response: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        # Handle connection errors, timeouts, etc.
        logging.error(f"An error occurred during the network request: {e}")
        return False