import uuid
import random
from typing import Any
from datetime import datetime, timezone, timedelta

# Import the helper function from your internal context module
from .context import emit_message

async def SendMCQ(content: str, options: Any, randomize: bool = False, checkbox: bool = False, delay: float = 3) -> bool:
    """
    Builds and broadcasts a multiple-choice question (MCQ).
    
    This tool can accept options as a simple list of strings or a list of 
    label/value dictionaries.
        
    Args:
        content (str): The question or message to display above the options.
        options (List): A list of options.
            Can be strings (e.g., ["Option 1", "Option 2"]) or
            dicts (e.g., [{"label": "PostgreSQL", "value": "postgres"}]).
        randomize (bool, optional): If True, the order of options is shuffled.
            Defaults to False.
        checkbox (bool, optional): If True, allows for multiple selections.
            Defaults to False.
        delay (float, optional): Delay in seconds before broadcasting. Defaults to 3.
            
    Returns:
        True if the MCQ was sent successfully, False otherwise.
    """
    if not options or not isinstance(options, list):
        return False
        
    # Step 1: Normalize all options into a list of {"label": ..., "value": ...} dicts
    normalized_options = []
    for item in options:
        if isinstance(item, str) and item.strip():
            # Convert a simple string to the label/value format
            clean_item = item.strip()
            normalized_options.append({"label": clean_item, "value": clean_item})
        elif isinstance(item, dict) and "label" in item and "value" in item:
            # Use the provided dictionary if it's valid
            normalized_options.append({
                "label": str(item["label"]),
                "value": str(item["value"])
            })
            
    if not normalized_options:
        return False
        
    # Step 2: Shuffle the normalized list if requested
    final_options = normalized_options
    if randomize:
        random.shuffle(final_options)
            
    # Step 3: Build the message payload and broadcast
    ts = datetime.now(timezone.utc)
    if delay > 0:
        ts += timedelta(seconds=delay)
        
    response = {
        "source": "assistant",
        "content": content,
        "m_id": str(uuid.uuid4()),
        "options": final_options, # This is now the list of dicts
        "checkbox": checkbox,
        "ts": ts.isoformat(),
        "type": "MCQMessage"
    }
        
    # Super clean! Just pass the dictionary to the emit function
    return await emit_message(response)