import uuid
from datetime import datetime, timezone, timedelta

# Import the helper function from your internal context module
from .context import emit_message

async def SendLockMessage(reason: str = "", delay: float = 0) -> str:
    """
    Send a lock signal to the client to disable the typing area.
    
    Args:
        reason (str, optional): A short message indicating why the input is locked.
        delay (float, optional): Time in seconds to wait before broadcasting.
        
    Returns:
        str: Status string indicating if the lock message was sent successfully.
    """
    base_timestamp = datetime.now(timezone.utc)
    if delay > 0:
        base_timestamp += timedelta(seconds=delay)
        
    response = {
        "source": "assistant",
        "content": reason,
        "m_id": str(uuid.uuid4()),
        "ts": base_timestamp.isoformat(),
        "type": "LockMessage"
    }
    
    # Broadcast using the context-aware emitter
    success = await emit_message(response)
    
    # Return a string to the LLM confirming the action
    return "Lock message sent." if success else "Failed to send lock message."