import contextvars
import logging
from typing import Callable, Awaitable, Optional

logger = logging.getLogger("zijus_tools")

# Framework-agnostic callback storage
ws_send_callback: contextvars.ContextVar[Optional[Callable[[dict], Awaitable[None]]]] = contextvars.ContextVar('ws_send_callback', default=None)

def set_websocket_sender(sender_func: Callable[[dict], Awaitable[None]]) -> None:
    """
    Called by the developer in their web framework (e.g., FastAPI, Django) 
    to register the function that actually sends the JSON to the client.
    """
    ws_send_callback.set(sender_func)

async def emit_message(message: dict) -> bool:
    """
    Called by tools inside zijus_tools to broadcast a message to the UI.
    """
    sender = ws_send_callback.get()
    
    if sender:
        try:
            await sender(message)
            return True
        except Exception as e:
            logger.error(f"Failed to send UI message: {e}")
            return False
    else:
        logger.warning("No websocket sender registered. Did you forget to call `set_websocket_sender()`?")
        return False