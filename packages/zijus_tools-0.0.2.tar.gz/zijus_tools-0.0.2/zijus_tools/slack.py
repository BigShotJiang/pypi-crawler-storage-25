async def SlackMessenger(slack_bot_token: str = "", channel_id: str = "", message: str = "") -> str:
    """
    Send a message to a Slack Channel.
    
    Parameters:
        slack_bot_token (str): Slack bot token.
        channel_id (str): Slack channel ID.
        message (str): Message to send.
        
    Returns:
        str: Success or error message.
    """
    if not slack_bot_token:
        return "Pass `slack_bot_token`"
    if not channel_id:
        return "Pass `channel_id`"
    if not message:
        return "Pass `message`"

    # Attempt to import the optional dependency
    try:
        from slack_sdk import WebClient
        from slack_sdk.errors import SlackApiError
    except ImportError:
        return "Error: `slack_sdk` is not installed. Run `pip install slack_sdk`."

    client = WebClient(token=slack_bot_token)
    try:
        # Note: WebClient is synchronous. If you want this to be strictly non-blocking 
        # in an async loop, you could use AsyncWebClient from slack_sdk.web.async_client
        client.chat_postMessage(channel=channel_id, text=message)
        return "Message sent to Slack Channel"
    except SlackApiError as e:
        return "Some error occurred in connecting to Slack, please check with Admin"