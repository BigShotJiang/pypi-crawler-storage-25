/* 
* Copyright (C) 2020-2026 MEmilio
*
* Authors: Daniel Abele
*
* Contact: Martin J. Kuehn <Martin.Kuehn@DLR.de>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
#ifndef MIO_UTIL_STL_UTIL_H
#define MIO_UTIL_STL_UTIL_H

#include <array>
#include <concepts>
#include <filesystem>
#include <numeric>
#include <vector>
#include <algorithm>
#include <utility>
#include <iterator>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <cassert>
#include <memory>

/// @brief Stream operator for writing std::vector to an std::ostream. Requires that T has a viable overload itself.
template <class T>
std::ostream& operator<<(std::ostream& out, const std::vector<T>& vec)
{
    out << "{";
    // use size - 1 and handle the last entry separately, for nicer separator usage
    for (size_t i = 0; i < vec.size() - 1; i++) {
        out << vec[i] << ", ";
    }
    if (!vec.empty()) {
        out << vec.back();
    }
    out << "}";
    return out;
}

namespace mio
{

/**
 * @brief Adds manipulators for width, (fixed) precision and fill character to an ostream.
 * Note that the formatting is consumed by the first output given to the ostream.
 * @param out Any std::ostream.
 * @param width Minimum width of the output.
 * @param precision The exact number of decimals (used only for numbers).
 * @param fill [Default: A space ' '] The character used for padding.
 * @return Returns a reference to out.
 */
inline std::ostream& set_ostream_format(std::ostream& out, size_t width, size_t precision, char fill = ' ')
{
    // Note: ostream& operator<< returns a reference to itself
    return out << std::setw(width) << std::fixed << std::setprecision(precision) << std::setfill(fill);
}

/**
 * @brief inserts element in a sorted vector, replacing items that are equal
 * precondition:  elements in the vector are partially sorted and unique according the predicate
 * postcondition: same as precondition, additionally contains exactly one element that is equal to item, 
 *                order of other items is preserved
 * @param vec vector where item will be inserted
 * @param item item to insert
 * @param pred binary comparator, pred(item, a) returns true if item should go before element a,
 *                                pred(a, item) returns true if element a should go before item
 */
template <typename T, typename Pred>
void insert_sorted_replace(std::vector<T>& vec, T const& item, Pred pred)
{
    auto bounds = std::equal_range(begin(vec), end(vec), item, pred);
    auto lb     = bounds.first;
    auto ub     = bounds.second;
    assert(ub - lb <= 1); //input vector contains at most one item that is equal to the new item
    if (ub - lb == 1) {
        *lb = item;
        return;
    }
    else {
        vec.insert(lb, item);
        return;
    }
}

template <typename T>
void insert_sorted_replace(std::vector<T>& vec, T const& item)
{
    return insert_sorted_replace(vec, item, std::less<T>());
}

/**
 * @brief A range of items defined by two iterators.
 * Models an immutable random access range, e.g. a piece of a vector. Immutable means that elements can not be added or
 * removed, while the elements themselves can be modified, if the iterators that make up the range allow it.
 * @tparam Iterator An iterator to the beginning of the range.
 * @tparam Sentinel A sentinel to the end of the range. Defaults to the same type as Iterator.
 */
template <class Iterator, class Sentinel = Iterator>
    requires std::input_or_output_iterator<Iterator> && std::input_or_output_iterator<Sentinel> &&
             std::equality_comparable_with<Iterator, Sentinel>
class Range
{
    // TODO: Make this a thin wrapper for std::ranges::subrange, once we have the ranges library (min libc++ version 16)
public:
    // Type definitions for STL compatible containers.
    using iterator               = Iterator;
    using const_iterator         = iterator;
    using reverse_iterator       = std::reverse_iterator<iterator>;
    using const_reverse_iterator = std::reverse_iterator<const_iterator>;
    using value_type             = typename std::iterator_traits<iterator>::value_type;
    using reference              = typename std::iterator_traits<iterator>::reference;

    /// @brief Directly construct a Range from two iterators.
    Range(Iterator begin, Sentinel end)
        : m_iterator(std::move(begin))
        , m_sentinel(std::move(end))
    {
    }
    /// @brief Construct a Range from another range.
    template <class T>
    Range(T&& range)
        : m_iterator(std::forward<T>(range).begin())
        , m_sentinel(std::forward<T>(range).end())
    {
    }
    /// @brief Construct a Range from an std::pair of iterators.
    template <class I, class S>
    Range(std::pair<I, S> iterator_pair)
        : m_iterator(std::move(iterator_pair).first)
        , m_sentinel(std::move(iterator_pair).second)
    {
    }

    /// @brief Get an iterator to the start of the range, pointing at the first element of the range.
    Iterator begin() const
    {
        return m_iterator;
    }
    /// @brief Get an iterator at the end of the range, pointing to one element after the last in the range.
    Sentinel end() const
    {
        return m_sentinel;
    }

    /// @brief Get a reference to the first element in the range.
    reference front() const
        requires std::forward_iterator<iterator>
    {
        return *(begin());
    }
    /// @brief Get a reference to the last element in the range.
    reference back() const
        requires std::bidirectional_iterator<iterator>
    {
        return *(--end());
    }

    /// @brief Obtains the size of the range.
    size_t size() const
    {
        return static_cast<size_t>(std::distance(begin(), end()));
    }
    /// @brief Checks whether the range is empty.
    bool empty() const
    {
        return size() == 0;
    }

    /**
     * @brief Access operator.
     * @param[in] index An index into the range.
     * @return Returns a reference to the element at the given index.
     * Has constant complexity if random access iterator, linear otherwise
     */
    reference operator[](size_t index) const
    {
        assert(index < size());
        auto it = begin();
        std::advance(it, index);
        return *it;
    }

    /// @brief Get a reverse iterator, starting at the end of the range.
    decltype(auto) rbegin() const
        requires std::bidirectional_iterator<iterator>
    {
        return std::make_reverse_iterator(end());
    }
    /// @brief Get a reverse iterator, ending at the start of the range.
    decltype(auto) rend() const
        requires std::bidirectional_iterator<iterator>
    {
        return std::make_reverse_iterator(begin());
    }

private:
    Iterator m_iterator;
    Sentinel m_sentinel;
};

/// @brief Deduction guide to correctly deduce range type when constructed from a pair.
template <class I, class S>
Range(std::pair<I, S> iterator_pair) -> Range<I, S>;

/// @brief Deduction guide to correctly deduce range type when constructed from another range.
template <class T>
Range(T&& range) -> Range<decltype(range.begin()), decltype(range.end())>;

/// @brief Concept to check if type T has an existing stream output operator "<<".
template <class T>
concept HasOstreamOperator = requires(std::ostream os, T t) { os << t; };

/** join one ore more strings with path separators.
 * Accepts mixed C strings or std::strings. 
 * 
 * example: 
 * 
 *     std::string hello("Hello");
 *     auto p = path_join(hello, "World"); //returns "Hello/World"
 * 
 * @param base first string
 * @param app zero or more other strings
 * @returns all inputs joined 
 */
template <class String, class... Strings>
std::string path_join(String&& base, Strings&&... app)
{
    std::filesystem::path p(base);
    ((p /= std::filesystem::path(app)), ...);
    return p.string();
}

/**
 * converts a unique_ptr<T> to unique_ptr<U>.
 * behavior is similar to normal dynamic_cast except if the conversion 
 * is successful, the original unique_ptr<T> is now in a moved-from state and ownership
 * of the object has been transferred to the returned unique_ptr<U>.
 * @param base_ptr ptr to object to convert
 * @returns converted unique_ptr if object can be cast to U, default unique_ptr otherwise
 */
template <class U, class T>
std::unique_ptr<U> dynamic_unique_ptr_cast(std::unique_ptr<T>&& base_ptr)
{
    auto tmp_base_ptr = std::move(base_ptr);
    U* tmp            = dynamic_cast<U*>(tmp_base_ptr.get());
    std::unique_ptr<U> derived_ptr;
    if (tmp != nullptr) {
        tmp_base_ptr.release();
        derived_ptr.reset(tmp);
    }
    return derived_ptr;
}

/**
 * checks if there is an element in this range that matches a predicate
 */
template <class Iter, class Pred>
bool contains(Iter b, Iter e, Pred p)
{
    return find_if(b, e, p) != e;
}

/**
 * Get an std::array that contains all members of an enum class.
 * The enum class must be a valid index, i.e. members must be sequential starting at 0 and there must
 * be a member `Count` at the end, that will not be included in the array.
 * Example:
 * ```
 * enum class E { A, B, Count };
 * assert(enum_members<E>() == std::array<2, E>(E::A, E::B));
 * ``` 
 * @tparam T An enum class that is a valid index.
 * @return Array of all members of the enum class not including T::Count.
 */
template <class T>
constexpr std::array<T, size_t(T::Count)> enum_members()
{
    auto enum_members = std::array<T, size_t(T::Count)>{};
    auto indices      = std::array<std::underlying_type_t<T>, size_t(T::Count)>{};
    std::iota(indices.begin(), indices.end(), std::underlying_type_t<T>(0));
    std::transform(indices.begin(), indices.end(), enum_members.begin(), [](auto i) {
        return T(i);
    });
    return enum_members;
}

/**
 * @brief Defines generic Range type for IterPair of a vector.
 * When elements should be const, template argument accepts const type.
 * As vector is not defined for const values, the const specifier is removed and
 * the const_iterator is used. std::conditional tries to compile both cases, thus
 * we also need std::remove_const for the case where T is not const.
 */
template <class T>
using VectorRange =
    std::conditional_t<std::is_const_v<T>,
                       typename mio::Range<typename std::vector<std::remove_const_t<T>>::const_iterator>,
                       typename mio::Range<typename std::vector<std::remove_const_t<T>>::iterator>>;

} // namespace mio

#endif // MIO_UTIL_STL_UTIL_H
