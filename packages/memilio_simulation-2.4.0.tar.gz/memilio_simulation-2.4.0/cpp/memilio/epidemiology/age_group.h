/* 
* Copyright (C) 2020-2026 MEmilio
*
* Authors: Jan Kleinert, Daniel Abele
*
* Contact: Martin J. Kuehn <Martin.Kuehn@DLR.de>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
#ifndef AGEGROUP_H
#define AGEGROUP_H

#include "memilio/utils/index.h"

namespace mio
{

/**
 * @brief Typesafe index representing an age group.
 * Used as a tag for all age dependent categories in a model.
 * The number of age groups is determined at runtime.
 * The underlying size_t value (i.e., the age group index) can be obtained via the get() member function:
 * @code
 *   AgeGroup g(2);
 *   size_t idx = g.get();
 * @endcode
 * @see Index
 * @see TypeSafe
 */
struct AgeGroup : public Index<AgeGroup> {
    AgeGroup(size_t val)
        : Index<AgeGroup>(val)
    {
    }

    /**
     * Override deserialize of base class
     * @see mio::Index::deserialize
     */
    template <class IOContext>
    static IOResult<AgeGroup> deserialize(IOContext& io)
    {
        BOOST_OUTCOME_TRY(auto&& i, mio::deserialize(io, Tag<size_t>{}));
        return success(AgeGroup(i));
    }
};

} // namespace mio

#endif
