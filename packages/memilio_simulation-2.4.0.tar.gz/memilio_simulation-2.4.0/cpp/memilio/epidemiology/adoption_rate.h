/* 
* Copyright (C) 2020-2026 MEmilio
*
* Authors: René Schmieding, Julia Bicker, Kilian Volmer
*
* Contact: Martin J. Kuehn <Martin.Kuehn@DLR.de>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
#ifndef MIO_EPI_ADOPTIONRATE_H
#define MIO_EPI_ADOPTIONRATE_H

#include "memilio/geography/regions.h"
#include <vector>

namespace mio
{

/**
 * @brief Struct defining an influence for a second-order adoption.
 * The population having "status" is multiplied with "factor."
 * @tparam Status An infection state enum or MultiIndex.
 */
template <typename FP, class Status>
struct Influence {
    Status status;
    FP factor;
};

/**
 * @brief Struct defining a possible status adoption in a Model based on Poisson Processes.
 * The AdoptionRate is considered to be of second-order if there are any "influences".
 * In the d_abm and smm simulations, "from" is implicitly an influence, scaled by "factor". This is multiplied by
 * the sum over all "influences", which scale their "status" with the respective "factor".
 * @tparam Status An infection state enum or MultiIndex.
 * @tparam Region A MultiIndex.
 */
template <typename FP, class Status, class Region = mio::regions::Region>
struct AdoptionRate {
    Status from; // i
    Status to; // j
    Region region; // k
    FP factor; // gammahat_{ij}^k
    std::vector<Influence<FP, Status>> influences; // influences[tau] = ( Psi_{i,j,tau} , gamma_{i,j,tau} )
};

} // namespace mio

#endif
