# MEmilio C++ #

The MEmilio C++ library contains the implementation of the epidemiological models. 

Directory structure:
- memilio: framework for developing epidemiological models with, e.g., interregional mobility implementations, nonpharmaceutical interventions (NPIs), and  mathematical, programming, and IO utilities.
- models: implementation of concrete models (ODE, IDE, LCT and ABM)
- sbml_model_generation: Code for the SBML integration and models that were generated using it
- simulations: simulation applications that were used to generate the scenarios and data for publications
- examples: small applications that help with using the framework and models
- tests: unit tests for framework and models.
- cmake: build utility code
- thirdparty: configuration of dependencies
- benchmarks: applications to analyze runtime performance of the framework

## Requirements

MEmilio C++ uses CMake as a build configuration system (https://cmake.org/)

MEmilio C++ is regularly tested with the following compilers (list will be extended over time):
- GCC, versions 11 and 13
- Clang, version 14 and 17
- MSVC, version 19.43 (Visual Studio 2022)

MEmilio C++ is regularly tested on gitlub runners using Ubuntu 22.04 and 24.04 and Windows Server 2022 and 2025. It is expected to run on any comparable Linux or Windows system. It is currently not tested on MacOS.

The following table lists the dependencies that are used. Most of them are required, but some are optional. The library can be used without them but with slightly reduced features. CMake will warn about them during configuration. Most of them are bundled with this library and do not need to be installed manually. Bundled libraries are either included with this project or loaded from the web on demand. For each dependency, there is a CMake option to use an installed version instead. Version compatibility needs to be ensured by the user, the version we currently use is included in the table.

| Library | Version  | Required | Bundled               | Notes |
|---------|----------|----------|-----------------------|-------|
| spdlog  | 1.17.0   | Yes      | Yes (git repo)        | https://github.com/gabime/spdlog |
| Eigen   | 3.4.0    | Yes      | Yes (git repo)        | http://gitlab.com/libeigen/eigen |
| Boost   | 1.84.0   | Yes      | Yes (git repo)        | https://github.com/boostorg/boost |
| JsonCpp | 1.9.6    | No       | Yes (git repo)        | https://github.com/open-source-parsers/jsoncpp |
| HDF5    | 1.12.0   | No       | No                    | https://www.hdfgroup.org/, package libhdf5-dev on apt (Ubuntu) |
| GoogleTest | 1.10  | For Tests only | Yes (git repo)  | https://github.com/google/googletest |
| LibSBML | 5.20.2 | No | No |  https://sbml.org/software/libsbml/ (For SBML integration only) |

See the [thirdparty](thirdparty/README.md) directory for more details.

## Installation

### Configuring using CMake

To configure with default options:
```bash
mkdir build && cd build
cmake ..
```

Options can be specified with `cmake .. -D<OPTION>=<VALUE>` or by editing the `build/CMakeCache.txt` file after running cmake. The following options are known to the library:
- `MEMILIO_BUILD_TESTS`: build unit tests in the test directory, ON or OFF, default ON.
- `MEMILIO_BUILD_EXAMPLES`: build the example applications in the examples directory, ON or OFF, default ON.
- `MEMILIO_BUILD_MODELS`: build the separate model libraries in the models directory, ON or OFF, default ON.
- `MEMILIO_BUILD_SIMULATIONS`: build the simulation applications in the simulations directory, ON or OFF, default ON.
- `MEMILIO_USE_BUNDLED_SPDLOG/_BOOST/_EIGEN/_JSONCPP`: use the corresponding dependency bundled with this project, ON or OFF, default ON.
- `MEMILIO_BUILD_BENCHMARKS`: build the benchmarks for this project, ON or OFF, default OFF.
- `MEMILIO_SANITIZE_ADDRESS/_UNDEFINED`: compile with specified sanitizers to check correctness, ON or OFF, default OFF.
- `MEMILIO_ENABLE_OPENMP`: compile MEmilio with multithreading using OpenMP, ON or OFF, default OFF.
- `MEMILIO_ENABLE_MPI`: compile MEmilio with distributed memory parallelization using MPI. ON or OFF, default OFF. Requires an MPI implementation to be installed on the system. 
- `MEMILIO_ENABLE_HDF5`: build MEmilio with HDF5 IO support, ON or OFF, default ON. If OFF, HDF5 is not searched for and features like `save_result`/`read_result` are disabled.
- `MEMILIO_ENABLE_SBML`: build the SBML importer and imported models, i.e. everythin in the folder `sbml_model_generation`, ON or OFF, default OFF.
- `MEMILIO_ENABLE_WARNINGS`: enable compilation warnings (beyond those enabled in the compiler by default). ON or OFF, default ON.
- `MEMILIO_ENABLE_WARNINGS_AS_ERRORS`: compilation warnings are treated as compilation errors. ON or OFF, default ON.
- `MEMILIO_ENABLE_PROFILING`: compile with runtime profiling support. ON or OFF, default OFF. See [here](benchmarks/profiling.md) for information.
- `MEMILIO_ENABLE_LIKWID_MARKER`: compile MEmilio with likwid markers. ON or OFF, default OFF.

Other important options may need:
- `CMAKE_BUILD_TYPE`: controls compiler optimizations and diagnostics, Debug, Release, or RelWithDebInfo; not available for Multi-Config CMake Generators like Visual Studio, set the build type in the IDE or when running the compiler.
- `CMAKE_INSTALL_PREFIX`: controls the location where the project will be installed
- `HDF5_DIR`: if you have HDF5 installed but it is not found by CMake (usually on the Windows OS), you may have to set this option to the directory in your installation that contains the `hdf5-config.cmake` file.

To e.g. configure the build without unit tests and with a specific version of HDF5:
```bash
cmake .. -DMEMILIO_BUILD_TESTS=OFF -DHDF5_DIR=/home/xyz/share/hdf5
```

### Making the library

After configuring, make the library using cmake:
```bash
cmake --build .
```

### Running the tests or examples

Run the unittests with:
```bash
./bin/memilio-test
```

Run an example with:
```bash
./bin/secir-example
```

### Installing

Install the project at the location given in the `CMAKE_INSTALL_PREFIX` variable with:
```bash
cmake --install .
```
This will install the libraries, headers, and executables that were built, i.e. where `MEMILIO_BUILD_<PART>=ON`.

### Using the libraries in your project

Using CMake, integration is simple. 

If you installed the project, there is a `memilio-config.cmake` file included with your installation. This config file will tell CMake which libraries and directores have to be included. Look up the config using the command `find_package(memilio)` in your own `CMakeLists.txt`. On Linux, the file should be found automatically if you installed in the normal GNU directories. Otherwise, or if you are working on Windows, you have to specify the `memilio_DIR` variable when running CMake to point it to the `memilio-config.cmake` file. Add the main framework as a dependency with the command `target_link_libraries(<your target> PRIVATE memilio::memilio)`. Other targets that are exported are `memilio::secir`, `memilio::seir`, and `memilio::abm`. This will set all required include directories and libraries, even transitive ones.

Alternatively, `MEmilio` can be integrated as a subdirectory of your project with `add_subdirectory(memilio/cpp)`, then you can use the same  `target_link_libraries` command as above.

## Known Issues

- Installing currently is not tested and probably does not work as expected or at all. If you want to integrate the project into yours, use the `add_subdirectory` way.
- On Windows, automatic detection of HDF5 installations does not work reliably. If you get HDF5 related errors during the build, you may have to supply the HDF5_DIR variable during CMake configuration, see above.
