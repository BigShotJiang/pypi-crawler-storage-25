/*
* Copyright (C) 2020-2026 MEmilio
*
* Authors: Martin J. Kuehn
*
* Contact: Martin J. Kuehn <Martin.Kuehn@DLR.de>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
#include "ode_secirvvs/model.h"
#include "memilio/compartments/simulation.h"
#include "memilio/utils/logging.h"

int main()
{
    mio::set_log_level(mio::LogLevel::warn);

    ScalarType t0   = 0;
    ScalarType tmax = 30;
    ScalarType dt   = 0.1;

    mio::log_info("Simulating SECIRVVS; t={} ... {} with dt = {}.", t0, tmax, dt);

    mio::osecirvvs::Model<ScalarType> model(1);

    for (mio::AgeGroup i = 0; i < model.parameters.get_num_groups(); i++) {
        model.populations[{i, mio::osecirvvs::InfectionState::ExposedNaive}]                                = 10;
        model.populations[{i, mio::osecirvvs::InfectionState::ExposedImprovedImmunity}]                     = 11;
        model.populations[{i, mio::osecirvvs::InfectionState::ExposedPartialImmunity}]                      = 12;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedNoSymptomsNaive}]                     = 13;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedNoSymptomsNaiveConfirmed}]            = 13;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedNoSymptomsPartialImmunity}]           = 14;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedNoSymptomsPartialImmunityConfirmed}]  = 14;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedNoSymptomsImprovedImmunity}]          = 15;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedNoSymptomsImprovedImmunityConfirmed}] = 15;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSymptomsNaive}]                       = 5;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSymptomsNaiveConfirmed}]              = 5;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSymptomsPartialImmunity}]             = 6;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSymptomsPartialImmunityConfirmed}]    = 6;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSymptomsImprovedImmunity}]            = 7;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSymptomsImprovedImmunityConfirmed}]   = 7;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSevereNaive}]                         = 8;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSevereImprovedImmunity}]              = 1;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedSeverePartialImmunity}]               = 2;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedCriticalNaive}]                       = 3;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedCriticalPartialImmunity}]             = 4;
        model.populations[{i, mio::osecirvvs::InfectionState::InfectedCriticalImprovedImmunity}]            = 5;
        model.populations[{i, mio::osecirvvs::InfectionState::SusceptibleImprovedImmunity}]                 = 6;
        model.populations[{i, mio::osecirvvs::InfectionState::SusceptiblePartialImmunity}]                  = 7;
        model.populations[{(mio::AgeGroup)0, mio::osecirvvs::InfectionState::DeadNaive}]                    = 0;
        model.populations[{(mio::AgeGroup)0, mio::osecirvvs::InfectionState::DeadPartialImmunity}]          = 0;
        model.populations[{(mio::AgeGroup)0, mio::osecirvvs::InfectionState::DeadImprovedImmunity}]         = 0;
        model.populations.set_difference_from_group_total<mio::AgeGroup>(
            {i, mio::osecirvvs::InfectionState::SusceptibleNaive}, 1000);
    }

    model.parameters.get<mio::osecirvvs::ICUCapacity<ScalarType>>()          = 100;
    model.parameters.get<mio::osecirvvs::TestAndTraceCapacity<ScalarType>>() = 0.0143;
    const size_t daily_vaccinations                                          = 10;
    model.parameters.get<mio::osecirvvs::DailyPartialVaccinations<ScalarType>>().resize(
        mio::SimulationDay((size_t)tmax + 1));
    model.parameters.get<mio::osecirvvs::DailyFullVaccinations<ScalarType>>().resize(
        mio::SimulationDay((size_t)tmax + 1));
    for (size_t i = 0; i < tmax + 1; ++i) {
        auto num_vaccinations = static_cast<ScalarType>(i * daily_vaccinations);
        model.parameters
            .get<mio::osecirvvs::DailyPartialVaccinations<ScalarType>>()[{(mio::AgeGroup)0, mio::SimulationDay(i)}] =
            num_vaccinations;
        model.parameters
            .get<mio::osecirvvs::DailyFullVaccinations<ScalarType>>()[{(mio::AgeGroup)0, mio::SimulationDay(i)}] =
            num_vaccinations;
    }

    auto& contacts       = model.parameters.get<mio::osecirvvs::ContactPatterns<ScalarType>>();
    auto& contact_matrix = contacts.get_cont_freq_mat();
    contact_matrix[0].get_baseline().setConstant(0.5);
    contact_matrix[0].get_baseline().diagonal().setConstant(5.0);
    contact_matrix[0].add_damping(0.3, mio::SimulationTime<ScalarType>(5.0));

    //times
    model.parameters.get<mio::osecirvvs::TimeExposed<ScalarType>>()[mio::AgeGroup(0)]            = 3.33;
    model.parameters.get<mio::osecirvvs::TimeInfectedNoSymptoms<ScalarType>>()[mio::AgeGroup(0)] = 1.87;
    model.parameters.get<mio::osecirvvs::TimeInfectedSymptoms<ScalarType>>()[mio::AgeGroup(0)]   = 7;
    model.parameters.get<mio::osecirvvs::TimeInfectedSevere<ScalarType>>()[mio::AgeGroup(0)]     = 6;
    model.parameters.get<mio::osecirvvs::TimeInfectedCritical<ScalarType>>()[mio::AgeGroup(0)]   = 7;

    //probabilities
    model.parameters.get<mio::osecirvvs::TransmissionProbabilityOnContact<ScalarType>>()[mio::AgeGroup(0)] = 0.15;
    model.parameters.get<mio::osecirvvs::RelativeTransmissionNoSymptoms<ScalarType>>()[mio::AgeGroup(0)]   = 0.5;
    // The precise value between Risk* (situation under control) and MaxRisk* (situation not under control)
    // depends on incidence and test and trace capacity
    model.parameters.get<mio::osecirvvs::RiskOfInfectionFromSymptomatic<ScalarType>>()[mio::AgeGroup(0)]    = 0.0;
    model.parameters.get<mio::osecirvvs::MaxRiskOfInfectionFromSymptomatic<ScalarType>>()[mio::AgeGroup(0)] = 0.4;
    model.parameters.get<mio::osecirvvs::RecoveredPerInfectedNoSymptoms<ScalarType>>()[mio::AgeGroup(0)]    = 0.2;
    model.parameters.get<mio::osecirvvs::SeverePerInfectedSymptoms<ScalarType>>()[mio::AgeGroup(0)]         = 0.1;
    model.parameters.get<mio::osecirvvs::CriticalPerSevere<ScalarType>>()[mio::AgeGroup(0)]                 = 0.1;
    model.parameters.get<mio::osecirvvs::DeathsPerCritical<ScalarType>>()[mio::AgeGroup(0)]                 = 0.1;

    model.parameters.get<mio::osecirvvs::ReducExposedPartialImmunity<ScalarType>>()[mio::AgeGroup(0)]           = 0.8;
    model.parameters.get<mio::osecirvvs::ReducExposedImprovedImmunity<ScalarType>>()[mio::AgeGroup(0)]          = 0.331;
    model.parameters.get<mio::osecirvvs::ReducInfectedSymptomsPartialImmunity<ScalarType>>()[mio::AgeGroup(0)]  = 0.65;
    model.parameters.get<mio::osecirvvs::ReducInfectedSymptomsImprovedImmunity<ScalarType>>()[mio::AgeGroup(0)] = 0.243;
    model.parameters
        .get<mio::osecirvvs::ReducInfectedSevereCriticalDeadPartialImmunity<ScalarType>>()[mio::AgeGroup(0)] = 0.1;
    model.parameters
        .get<mio::osecirvvs::ReducInfectedSevereCriticalDeadImprovedImmunity<ScalarType>>()[mio::AgeGroup(0)] = 0.091;
    model.parameters.get<mio::osecirvvs::ReducTimeInfectedMild<ScalarType>>()[mio::AgeGroup(0)]               = 0.9;

    model.parameters.get<mio::osecirvvs::Seasonality<ScalarType>>() = 0.2;
    // The function apply_constraints() ensures that all parameters are within their defined bounds.
    // Note that negative values are set to zero instead of stopping the simulation.
    model.apply_constraints();

    // use adaptive Runge-Kutta-Fehlberg45 scheme as integrator
    // auto integrator = std::make_unique<mio::RKIntegratorCore>();
    // integrator->set_dt_min(0.3);
    // integrator->set_dt_max(1.0);
    // integrator->set_rel_tolerance(1e-4);
    // integrator->set_abs_tolerance(1e-1);
    // mio::TimeSeries<ScalarType> result = mio::osecirvvs::simulate<ScalarType>(t0, tmax, dt, model, std::move(integrator));

    // use default Cash-Karp adaptive integrator
    mio::TimeSeries<ScalarType> result = mio::osecirvvs::simulate<ScalarType>(t0, tmax, dt, model);

    bool print_to_terminal = true;

    if (print_to_terminal) {
        printf("\n%.14f ", result.get_last_time());
        for (size_t j = 0; j < (size_t)mio::osecirvvs::InfectionState::Count; j++) {
            printf("compartment %d: %.14f\n", (int)j, result.get_last_value()[j]);
        }
    }
}
