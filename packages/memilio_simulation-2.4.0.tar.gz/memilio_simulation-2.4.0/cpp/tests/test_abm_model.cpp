/* 
* Copyright (C) 2020-2026 MEmilio
*
* Authors: Daniel Abele, Elisabeth Kluth, David Kerkmann, Sascha Korf, Martin J. Kuehn, Khoa Nguyen, Carlotta Gerstein
*
* Contact: Martin J. Kuehn <Martin.Kuehn@DLR.de>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
#include "abm/location_id.h"
#include "abm/person_id.h"
#include "memilio/utils/random_number_generator.h"
#include "utils.h"
#include "abm/location.h"
#include "abm/location_type.h"
#include "abm/parameters.h"
#include "abm/person.h"
#include "abm/model.h"
#include "abm/model_functions.h"
#include "abm/virus_variant.h"
#include "abm_helpers.h"
#include "memilio/epidemiology/age_group.h"
#include "memilio/utils/abstract_parameter_distribution.h"
#include "memilio/utils/parameter_distributions.h"
#include "random_number_test.h"
#include <algorithm>
#include <cstddef>
#include <cstdint>

using TestModel = RandomNumberTest;

/**
 * @brief Test initialization of Model class.
 */
TEST_F(TestModel, init)
{
    auto model = mio::abm::Model(num_age_groups);

    // Verify that the model starts with exactly one location of type Cemetery.
    EXPECT_EQ(model.get_locations().size(), 1);
    EXPECT_EQ(model.get_locations()[0].get_type(), mio::abm::LocationType::Cemetery);

    // Verify that no persons are initialized in the model.
    EXPECT_THAT(model.get_persons(), testing::ElementsAre());
}

/**
 * @brief Test adding locations to the Model class.
 */
TEST_F(TestModel, addLocation)
{
    auto model      = mio::abm::Model(num_age_groups);
    auto school_id1 = model.add_location(mio::abm::LocationType::School);
    auto school_id2 = model.add_location(mio::abm::LocationType::School);
    auto work_id    = model.add_location(mio::abm::LocationType::Work);
    auto home_id    = model.add_location(mio::abm::LocationType::Home);

    // Verify the unique IDs of added locations.
    EXPECT_EQ(school_id1.get(), 1u);
    EXPECT_EQ(school_id2.get(), 2u);

    // Retrieve added locations by their IDs and verify their types.
    auto& school1 = model.get_location(school_id1);
    auto& school2 = model.get_location(school_id2);
    auto& work    = model.get_location(work_id);
    auto& home    = model.get_location(home_id);

    // Count the number of School-type locations and verify.
    size_t count_schools = 0;
    for (auto& loc : model.get_locations()) {
        if (loc.get_type() == mio::abm::LocationType::School) {
            count_schools++;
        }
    }
    EXPECT_EQ(count_schools, 2);

    // Verify the location order within the model's internal list of locations.
    EXPECT_EQ(model.get_locations()[1], school1);
    EXPECT_EQ(model.get_locations()[2], school2);
    EXPECT_EQ(model.get_locations()[3], work);
    EXPECT_EQ(model.get_locations()[4], home);
}

/**
 * @brief Test adding persons to a specific location in the Model class.
 */
TEST_F(TestModel, addPerson)
{
    auto model    = mio::abm::Model(num_age_groups);
    auto location = model.add_location(mio::abm::LocationType::School);

    auto id1 = model.add_person(location, age_group_15_to_34);
    auto id2 = model.add_person(location, age_group_35_to_59);

    // Verify the number of persons in the model and their respective age groups.
    EXPECT_EQ(model.get_persons().size(), 2);
    // Verify the number of persons in the model and their respective age groups.
    EXPECT_EQ(model.get_persons().size(), 2);
    EXPECT_EQ(model.get_person(id1).get_age(), age_group_15_to_34);
    EXPECT_EQ(model.get_person(id2).get_age(), age_group_35_to_59);
}

/**
 * @brief Test the get_number_persons and get_number_persons_age methods in the Model class.
 */
TEST_F(TestModel, getNumberPersons)
{
    // replace spdlog::default_logger
    mio::RedirectLogger logger(mio::LogLevel::debug); // Set log level to debug to capture log messages.
    logger.capture();

    auto model    = mio::abm::Model(num_age_groups);
    auto location = model.add_location(mio::abm::LocationType::School);

    // Add persons to the model.
    model.add_person(location, age_group_15_to_34);
    model.add_person(location, age_group_35_to_59);

    EXPECT_TRUE(logger.read().empty());

    // Verify the total number of persons in the model.
    EXPECT_EQ(model.get_number_persons(location), 2); // This get also does the first build of the cache.
#ifndef NDEBUG
    EXPECT_THAT(logger.read(), ::testing::HasSubstr("Building local population cache for ABM."));
#endif

    // Verify the number of persons in the model for each age group.
    EXPECT_EQ(model.get_number_persons_age(location, 0, age_group_15_to_34), 1);
    EXPECT_EQ(model.get_number_persons_age(location, 0, age_group_35_to_59), 1);
    // Verify the number of persons in the model for an age group that has no persons.
    EXPECT_EQ(model.get_number_persons_age(location, 0, age_group_0_to_4), 0);
    EXPECT_EQ(model.get_number_persons_age(location, 0, age_group_5_to_14), 0);
    EXPECT_EQ(model.get_number_persons_age(location, 0, age_group_60_to_79), 0);
    EXPECT_EQ(model.get_number_persons_age(location, 0, age_group_80_plus), 0);

    EXPECT_TRUE(logger.read().empty());

    logger.release();
}

/**
 * @brief Test combined subpopulation count by location type in the Model class.
 */
TEST_F(TestModel, getSubpopulationCombined)
{
    auto t       = mio::abm::TimePoint(0);
    auto model   = mio::abm::Model(num_age_groups);
    auto school1 = model.add_location(mio::abm::LocationType::School);
    auto school2 = model.add_location(mio::abm::LocationType::School);
    auto school3 = model.add_location(mio::abm::LocationType::School);
    auto home1   = model.add_location(mio::abm::LocationType::Home);

    // Add persons to these locations with various infection states.
    add_test_person(model, school1, age_group_15_to_34, mio::abm::InfectionState::InfectedNoSymptoms);
    add_test_person(model, school1, age_group_15_to_34, mio::abm::InfectionState::Susceptible);
    add_test_person(model, school2, age_group_15_to_34, mio::abm::InfectionState::Susceptible);
    add_test_person(model, school2, age_group_15_to_34, mio::abm::InfectionState::Susceptible);
    add_test_person(model, school3, age_group_15_to_34, mio::abm::InfectionState::InfectedNoSymptoms);
    add_test_person(model, home1, age_group_15_to_34, mio::abm::InfectionState::InfectedNoSymptoms);

    // Verify the count of susceptible persons across all School locations.
    EXPECT_EQ(model.get_subpopulation_combined_per_location_type(t, mio::abm::InfectionState::Susceptible,
                                                                 mio::abm::LocationType::School),
              3);
    // Verify the count of persons with no symptoms across all School locations.
    EXPECT_EQ(model.get_subpopulation_combined_per_location_type(t, mio::abm::InfectionState::InfectedNoSymptoms,
                                                                 mio::abm::LocationType::School),
              2);
    // Verify the total count of persons with no symptoms across all locations.
    EXPECT_EQ(model.get_subpopulation_combined(t, mio::abm::InfectionState::InfectedNoSymptoms), 3);
}

/**
 * @brief Test finding a location assigned to a person in the Model class.
 */
TEST_F(TestModel, findLocation)
{
    // Create a model and add different location types.
    auto model      = mio::abm::Model(num_age_groups);
    model.get_rng() = this->get_rng();

    auto home_id   = model.add_location(mio::abm::LocationType::Home);
    auto school_id = model.add_location(mio::abm::LocationType::School);
    auto work_id   = model.add_location(mio::abm::LocationType::Work);

    // Add a person to the model and assign them to multiple locations.
    auto person_id = add_test_person(model, home_id);
    auto& person   = model.get_person(person_id);
    person.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    person.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    person.set_assigned_location(mio::abm::LocationType::School, school_id, model.get_id());

    // Verify that the find_location method correctly identifies each assigned location.
    EXPECT_EQ(model.find_location(mio::abm::LocationType::Work, person_id), work_id);
    EXPECT_EQ(model.find_location(mio::abm::LocationType::School, person_id), school_id);
    EXPECT_EQ(model.find_location(mio::abm::LocationType::Home, person_id), home_id);

    // Check that the method also works with a constant reference to the model.
    auto&& model_test = std::as_const(model);
    EXPECT_EQ(model_test.find_location(mio::abm::LocationType::Work, person_id), work_id);
    EXPECT_EQ(model_test.find_location(mio::abm::LocationType::School, person_id), school_id);
    EXPECT_EQ(model_test.find_location(mio::abm::LocationType::Home, person_id), home_id);
}

/**
 * @brief Test the exposure contribution normalization in the Model class.
 */
TEST_F(TestModel, exposureContributionNormalization)
{
    mio::abm::ContactExposureRates contact_exposure_rates;
    contact_exposure_rates.resize({mio::abm::CellIndex{1}, mio::abm::VirusVariant{1}, mio::AgeGroup{1}});
    contact_exposure_rates[{mio::abm::CellIndex{0}, mio::abm::VirusVariant::Wildtype, mio::AgeGroup{0}}] = 10.0;

    mio::abm::PopulationByAge local_population_by_age;
    local_population_by_age.resize({mio::abm::CellIndex{1}, mio::AgeGroup{1}});
    local_population_by_age[{mio::abm::CellIndex{0}, mio::AgeGroup{0}}] =
        2; // Set population for cell 0 and age group 0 to 2

    mio::abm::normalize_exposure_contribution(contact_exposure_rates, local_population_by_age);

    auto& rate = contact_exposure_rates[{mio::abm::CellIndex{0}, mio::abm::VirusVariant::Wildtype, mio::AgeGroup{0}}];
    EXPECT_EQ(rate, 5.0);
}

/**
 * @brief Test state transitions during a time step in the Model class.
 */
TEST_F(TestModel, evolveStateTransition)
{
    using testing::Return;

    auto t          = mio::abm::TimePoint(0);
    auto dt         = mio::abm::hours(1);
    auto model      = mio::abm::Model(num_age_groups);
    model.get_rng() = this->get_rng();

    // Setup incubation and infection period parameters to prevent state transitions within one hour. p1 and p3 don't transition.
    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::LogNormalDistribution<double>>>> mock_logNorm_dist;
    EXPECT_CALL(mock_logNorm_dist.get_mock(), invoke).WillRepeatedly(testing::Return(2 * dt.days()));

    // Add locations and persons to the model with different initial infection states.
    auto location1 = model.add_location(mio::abm::LocationType::School);
    auto location2 = model.add_location(mio::abm::LocationType::Work);
    add_test_person(model, location1, age_group_15_to_34, mio::abm::InfectionState::InfectedNoSymptoms);
    add_test_person(model, location1, age_group_15_to_34, mio::abm::InfectionState::Susceptible);
    add_test_person(model, location2, age_group_15_to_34, mio::abm::InfectionState::InfectedSymptoms);

    auto& p1 = model.get_persons()[0];
    auto& p2 = model.get_persons()[1];
    auto& p3 = model.get_persons()[2];

    // Assign persons to their respective locations.
    p1.set_assigned_location(mio::abm::LocationType::School, location1, model.get_id());
    p2.set_assigned_location(mio::abm::LocationType::School, location1, model.get_id());
    p3.set_assigned_location(mio::abm::LocationType::Work, location2, model.get_id());

    // Setup mock so p2 becomes infected
    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::ExponentialDistribution<double>>>>
        mock_exponential_dist;
    EXPECT_CALL(mock_exponential_dist.get_mock(), invoke).Times(1).WillOnce(Return(0.0));

    model.evolve(t, dt);

    // Verify the state transitions.
    EXPECT_EQ(p1.get_infection_state(t + dt), mio::abm::InfectionState::InfectedNoSymptoms);
    EXPECT_EQ(p2.get_infection_state(t + dt), mio::abm::InfectionState::Exposed);
    EXPECT_EQ(p3.get_infection_state(t + dt), mio::abm::InfectionState::InfectedSymptoms);
}

/**
 * @brief Test mobility rule-based transitions during a time step in the Model class.
 */
TEST_F(TestModel, evolveMobilityRules)
{
    using testing::Return;

    auto t          = mio::abm::TimePoint(0) + mio::abm::hours(8);
    auto dt         = mio::abm::hours(1);
    auto model      = mio::abm::Model(num_age_groups);
    model.get_rng() = this->get_rng();

    // Setup infection period parameters to prevent state transitions within one hour. p1 doesn't transition.
    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::LogNormalDistribution<double>>>> mock_logNorm_dist;
    EXPECT_CALL(mock_logNorm_dist.get_mock(), invoke).WillRepeatedly(testing::Return(2 * dt.days()));
    model.parameters.get<mio::abm::AgeGroupGotoSchool>().set_multiple({age_group_5_to_14}, true);
    model.parameters.get<mio::abm::AgeGroupGotoWork>().set_multiple({age_group_15_to_34, age_group_35_to_59}, true);

    auto home_id   = model.add_location(mio::abm::LocationType::Home);
    auto school_id = model.add_location(mio::abm::LocationType::School);
    auto work_id   = model.add_location(mio::abm::LocationType::Work);

    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist;
    EXPECT_CALL(mock_uniform_dist.get_mock(), invoke)
        .Times(testing::AtLeast(8))
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillRepeatedly(testing::Return(1.0));

    auto pid2 = add_test_person(model, home_id, age_group_5_to_14, mio::abm::InfectionState::Susceptible, t);
    auto pid1 = add_test_person(model, home_id, age_group_15_to_34, mio::abm::InfectionState::InfectedNoSymptoms, t);

    auto& p1 = model.get_person(pid1);
    auto& p2 = model.get_person(pid2);

    p1.set_assigned_location(mio::abm::LocationType::School, school_id, model.get_id());
    p2.set_assigned_location(mio::abm::LocationType::School, school_id, model.get_id());
    p1.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p2.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p1.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p2.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());

    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::ExponentialDistribution<double>>>>
        mock_exponential_dist;
    EXPECT_CALL(mock_exponential_dist.get_mock(), invoke).WillRepeatedly(Return(1.)); //no state transitions

    // Evolve the model over one time step and verify the location transitions.
    model.evolve(t, dt);
    EXPECT_EQ(p1.get_location(), work_id);
    EXPECT_EQ(p2.get_location(), school_id);

    // Verify the number of persons at each location.
    EXPECT_EQ(model.get_number_persons(school_id), 1);
    EXPECT_EQ(model.get_number_persons(work_id), 1);
}

/**
 * @brief Test the evolution of mobility trips within the Model class.
 */
TEST_F(TestModel, evolveMobilityTrips)
{
    using testing::Return;

    // Initialize model, time, and step size for simulation.
    auto t          = mio::abm::TimePoint(0) + mio::abm::hours(8);
    auto dt         = mio::abm::hours(2);
    auto model      = mio::abm::Model(num_age_groups);
    model.get_rng() = this->get_rng();

    // Setup so p1-p5 don't do transition
    model.parameters
        .get<mio::abm::TimeInfectedNoSymptomsToSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_15_to_34}] =
        mio::ParameterDistributionConstant(2 * dt.days());
    model.parameters
        .get<mio::abm::TimeInfectedNoSymptomsToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_15_to_34}] =
        mio::ParameterDistributionConstant(2 * dt.days());
    model.parameters
        .get<mio::abm::TimeInfectedSevereToCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_15_to_34}] =
        mio::ParameterDistributionConstant(2 * dt.days());
    model.parameters
        .get<mio::abm::TimeInfectedSevereToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_15_to_34}] =
        mio::ParameterDistributionConstant(2 * dt.days());

    // Add different location types to the model.
    auto home_id     = model.add_location(mio::abm::LocationType::Home);
    auto event_id    = model.add_location(mio::abm::LocationType::SocialEvent);
    auto work_id     = model.add_location(mio::abm::LocationType::Work);
    auto hospital_id = model.add_location(mio::abm::LocationType::Hospital);

    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist;
    EXPECT_CALL(mock_uniform_dist.get_mock(), invoke)
        .Times(testing::AtLeast(8))
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillRepeatedly(testing::Return(0.8)); // this forces p1 and p3 to recover

    // Create persons with various infection states and assign them to multiple locations.
    auto pid1 = model.add_person(home_id, age_group_15_to_34);
    auto pid2 = model.add_person(home_id, age_group_15_to_34);
    auto pid3 = model.add_person(home_id, age_group_15_to_34);
    auto pid4 = model.add_person(hospital_id, age_group_15_to_34);
    auto pid5 = model.add_person(home_id, age_group_15_to_34);

    // Assign persons to locations for trips.
    auto& p1 = model.get_person(pid1);
    auto& p2 = model.get_person(pid2);
    auto& p3 = model.get_person(pid3);
    auto& p4 = model.get_person(pid4);
    auto& p5 = model.get_person(pid5);

    p1.set_assigned_location(mio::abm::LocationType::SocialEvent, event_id, model.get_id());
    p2.set_assigned_location(mio::abm::LocationType::SocialEvent, event_id, model.get_id());
    p1.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p2.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p1.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p2.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p3.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p4.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p3.set_assigned_location(mio::abm::LocationType::Hospital, hospital_id, model.get_id());
    p4.set_assigned_location(mio::abm::LocationType::Hospital, hospital_id, model.get_id());
    p5.set_assigned_location(mio::abm::LocationType::SocialEvent, event_id, model.get_id());
    p5.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p5.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());

    // Set trips for persons between assigned locations.
    mio::abm::TripList& data = model.get_trip_list();
    mio::abm::Trip trip1(p1.get_id(), mio::abm::TimePoint(0) + mio::abm::hours(9), work_id);
    mio::abm::Trip trip2(p2.get_id(), mio::abm::TimePoint(0) + mio::abm::hours(9), event_id);
    mio::abm::Trip trip3(p5.get_id(), mio::abm::TimePoint(0) + mio::abm::hours(9), event_id);

    auto trips_part1 = std::vector<mio::abm::Trip>{trip2, trip3};
    auto trips_part2 = std::vector<mio::abm::Trip>{trip1};
    data.add_trips(trips_part1);
    data.add_trips(trips_part2); //to see if merge works

    // Mock the random distribution to control random behavior.
    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist2;
    EXPECT_CALL(mock_uniform_dist2.get_mock(), invoke)
        .Times(testing::Exactly(6))
        .WillOnce(testing::Return(1.0)) // draw transition to Recovered p1
        .WillOnce(testing::Return(0.8)) // draw random viral shed p1
        .WillOnce(testing::Return(1.0)) // draw transition to Recovered p3
        .WillOnce(testing::Return(0.8)) // draw random viral shed p3
        .WillOnce(testing::Return(0.0)) // draw transition from InfectedCritical p4
        .WillOnce(testing::Return(0.8)) // draw random viral shed p4
        .RetiresOnSaturation();

    auto rng_p1 = mio::abm::PersonalRandomNumberGenerator(model.get_rng(), p1);
    p1.add_new_infection(mio::abm::Infection(rng_p1, static_cast<mio::abm::VirusVariant>(0), p1.get_age(),
                                             model.parameters, t, mio::abm::InfectionState::InfectedNoSymptoms));
    auto rng_p3 = mio::abm::PersonalRandomNumberGenerator(model.get_rng(), p3);
    p3.add_new_infection(mio::abm::Infection(rng_p3, static_cast<mio::abm::VirusVariant>(0), p3.get_age(),
                                             model.parameters, t, mio::abm::InfectionState::InfectedSevere));
    auto rng_p4 = mio::abm::PersonalRandomNumberGenerator(model.get_rng(), p4);
    p4.add_new_infection(mio::abm::Infection(rng_p4, static_cast<mio::abm::VirusVariant>(0), p4.get_age(),
                                             model.parameters, t, mio::abm::InfectionState::Recovered));

    // For any other uniform distribution calls in model.evolve
    EXPECT_CALL(mock_uniform_dist2.get_mock(), invoke).WillRepeatedly(Return(1.));

    // Mock the distribution to prevent infections in the test.
    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::ExponentialDistribution<double>>>>
        mock_exponential_dist;
    EXPECT_CALL(mock_exponential_dist.get_mock(), invoke).WillRepeatedly(Return(1.));

    model.evolve(t, dt);

    // Verify all the mobility transitions are correct.
    EXPECT_EQ(p1.get_location(), work_id);
    EXPECT_EQ(p2.get_location(), event_id);
    EXPECT_EQ(p3.get_location(), hospital_id);
    EXPECT_EQ(p4.get_location(), home_id);
    EXPECT_EQ(p5.get_location(), event_id);
    EXPECT_EQ(model.get_number_persons(event_id), 2);
    EXPECT_EQ(model.get_number_persons(work_id), 1);
    EXPECT_EQ(model.get_number_persons(home_id), 1);
    EXPECT_EQ(model.get_number_persons(hospital_id), 1);
}

#ifndef MEMILIO_ENABLE_OPENMP // TODO: Test can fail with parallel execution of mobility, as the capacity is not taken into account correctly at the moment (c. f. issue #640)
/**
 * @brief Test that a location correctly enforces its capacity constraint.
 */
TEST_F(TestModel, reachCapacity)
{
    using testing::Return;

    // Initialize time and model.
    auto t          = mio::abm::TimePoint{mio::abm::hours(8).seconds()};
    auto dt         = mio::abm::hours(1);
    auto model      = mio::abm::Model(num_age_groups);
    model.get_rng() = this->get_rng();
    model.parameters.get<mio::abm::AgeGroupGotoSchool>()[age_group_5_to_14] = true;

    auto home_id   = model.add_location(mio::abm::LocationType::Home);
    auto school_id = model.add_location(mio::abm::LocationType::School);

    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist;
    EXPECT_CALL(mock_uniform_dist.get_mock(), invoke)
        .Times(testing::AtLeast(8))
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillRepeatedly(testing::Return(1.0));

    // Create two persons with different infection states.
    auto p1 = add_test_person(model, home_id, age_group_5_to_14);
    auto p2 = add_test_person(model, home_id, age_group_5_to_14);

    // Assign both persons to School and Home.
    model.get_person(p1).set_assigned_location(mio::abm::LocationType::School, school_id, 0);
    model.get_person(p2).set_assigned_location(mio::abm::LocationType::School, school_id, 0);
    model.get_person(p1).set_assigned_location(mio::abm::LocationType::Home, home_id, 0);
    model.get_person(p2).set_assigned_location(mio::abm::LocationType::Home, home_id, 0);

    // Set the capacity of the school to 1 person with a distance requirement of 66.
    model.get_location(school_id).set_capacity(1, 66);

    model.evolve(t, dt);

    // Verify that only one person is at the school, while the other remains at home due to capacity constraints.
    EXPECT_EQ(model.get_person(p1).get_location(), school_id);
    EXPECT_EQ(model.get_person(p2).get_location(), home_id); // p2 should not be able to enter the school
    EXPECT_EQ(model.get_number_persons(school_id), 1);
    EXPECT_EQ(model.get_number_persons(home_id), 1);
}
#endif

/**
 * @brief Test that dead persons remain in the cemetery and can't be moved by scheduled trips.
 */
TEST_F(TestModel, checkMobilityOfDeadPerson)
{
    using testing::Return;
    auto t     = mio::abm::TimePoint(0);
    auto dt    = mio::abm::days(1);
    auto model = mio::abm::Model(num_age_groups);
    model.parameters
        .get<mio::abm::CriticalPerInfectedSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_60_to_79}] = 1.;
    model.parameters
        .get<mio::abm::DeathsPerInfectedCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_60_to_79}] = 1.;
    // Time to go from severe to critical infection is 1 day (dt).
    model.parameters
        .get<mio::abm::TimeInfectedSevereToCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_60_to_79}] =
        mio::ParameterDistributionConstant(dt.days());
    // Time to go from critical infection to dead state is 1/2 day (0.5 * dt).
    model.parameters
        .get<mio::abm::TimeInfectedCriticalToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_60_to_79}] =
        mio::ParameterDistributionConstant(0.5 * dt.days());

    auto home_id     = model.add_location(mio::abm::LocationType::Home);
    auto work_id     = model.add_location(mio::abm::LocationType::Work);
    auto icu_id      = model.add_location(mio::abm::LocationType::ICU);
    auto hospital_id = model.add_location(mio::abm::LocationType::Hospital);

    // Make sure all persons will be InfectedSevere -> InfectedCritical -> Dead.
    // Also mocks other things in the setup and evolve, thus not using times::Exactly here.
    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist;
    EXPECT_CALL(mock_uniform_dist.get_mock(), invoke).WillRepeatedly(testing::Return(1.0));

    // Create a person that is dead at time t
    add_test_person(model, icu_id, age_group_60_to_79, mio::abm::InfectionState::Dead, t);
    // Create a person that is severe at hospital and will be dead at time t + dt
    add_test_person(model, hospital_id, age_group_60_to_79, mio::abm::InfectionState::Dead, t + dt);

    auto& p_dead   = model.get_persons()[0];
    auto& p_severe = model.get_persons()[1];

    p_dead.set_assigned_location(mio::abm::LocationType::ICU, icu_id, model.get_id());
    p_dead.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_dead.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_severe.set_assigned_location(mio::abm::LocationType::Hospital, hospital_id, model.get_id());
    p_severe.set_assigned_location(mio::abm::LocationType::ICU, icu_id, model.get_id());
    p_severe.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());

    // Add trip to see if a dead person can change location outside of cemetery by scheduled trips
    mio::abm::TripList& trip_list = model.get_trip_list();
    mio::abm::Trip trip1(p_dead.get_id(), mio::abm::TimePoint(0) + mio::abm::hours(2), home_id);
    mio::abm::Trip trip2(p_dead.get_id(), mio::abm::TimePoint(0) + mio::abm::hours(3), icu_id);
    mio::abm::Trip trip3(p_severe.get_id(), mio::abm::TimePoint(0) + mio::abm::hours(3), icu_id);
    trip_list.add_trips({trip1, trip2, trip3});

    // Check the dead person got burried and the severely infected person starts in Hospital
    model.evolve(t, dt);
    EXPECT_EQ(model.get_location(p_dead.get_id()).get_type(), mio::abm::LocationType::Cemetery);
    EXPECT_EQ(p_severe.get_infection_state(t), mio::abm::InfectionState::InfectedSevere);
    EXPECT_EQ(model.get_location(p_severe.get_id()).get_type(), mio::abm::LocationType::Hospital);

    // Check the dead person is still in Cemetery and the severely infected person dies and got burried
    model.evolve(t + dt, dt);
    EXPECT_EQ(model.get_location(p_dead.get_id()).get_type(), mio::abm::LocationType::Cemetery);
    EXPECT_EQ(p_severe.get_infection_state(t + dt), mio::abm::InfectionState::Dead);
    EXPECT_EQ(model.get_location(p_severe.get_id()).get_type(), mio::abm::LocationType::Cemetery);
}

using TestModelTestingCriteria = RandomNumberTest;

/**
 * @brief Test the adding, updating, and running of testing schemes within the model.
 */
TEST_F(TestModelTestingCriteria, testAddingAndUpdatingAndRunningTestingSchemes)
{
    auto model = mio::abm::Model(num_age_groups);
    // make sure the infected person stay in Infected long enough
    model.parameters.get<mio::abm::TimeInfectedSymptomsToRecovered>()[{mio::abm::VirusVariant(0), age_group_15_to_34}] =
        mio::ParameterDistributionConstant(100.);
    model.parameters.get<mio::abm::TimeInfectedSymptomsToSevere>()[{mio::abm::VirusVariant(0), age_group_15_to_34}] =
        mio::ParameterDistributionConstant(100.);

    auto home_id = model.add_location(mio::abm::LocationType::Home);
    auto work_id = model.add_location(mio::abm::LocationType::Work);
    auto& work   = model.get_location(work_id);

    auto current_time = mio::abm::TimePoint(0);

    auto test_time = mio::abm::minutes(30);
    // Add a person to the model with an infection state that requires testing.
    // Since tests are performed before current_time, the InfectionState of the Person has to take into account test_time
    auto pid        = add_test_person(model, home_id, age_group_15_to_34, mio::abm::InfectionState::InfectedSymptoms,
                                      current_time - test_time);
    auto& person    = model.get_person(pid);
    auto rng_person = mio::abm::PersonalRandomNumberGenerator(model.get_rng(), person);
    person.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    person.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());

    auto validity_period       = mio::abm::days(1);
    const auto start_date      = mio::abm::TimePoint(0) + mio::abm::days(1);
    const auto end_date        = mio::abm::TimePoint(0) + mio::abm::days(3);
    const auto probability     = 1.0;
    const auto test_params_pcr = mio::abm::TestParameters{0.9, 0.99, test_time, mio::abm::TestType::Generic};

    auto testing_criteria = mio::abm::TestingCriteria(
        {}, {mio::abm::InfectionState::InfectedSymptoms, mio::abm::InfectionState::InfectedNoSymptoms});

    auto testing_scheme =
        mio::abm::TestingScheme(testing_criteria, validity_period, start_date, end_date, test_params_pcr, probability);

    model.get_testing_strategy().add_scheme(mio::abm::LocationType::Work, testing_scheme);
    EXPECT_EQ(model.get_testing_strategy().run_and_check(rng_person, person, work, current_time),
              true); // no active testing scheme -> person can enter
    current_time = mio::abm::TimePoint(0) + mio::abm::days(2);
    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist;
    EXPECT_CALL(mock_uniform_dist.get_mock(), invoke)
        .Times(testing::Exactly(3))
        .WillOnce(testing::Return(0.5)) // Probability for testing (is performed)
        .WillOnce(testing::Return(0.4)) // Test result is positive
        .WillOnce(testing::Return(0.0)); // Draw for isolation compliance (doesn't matter in this test)
    EXPECT_EQ(model.get_testing_strategy().run_and_check(rng_person, person, work, current_time),
              false); // Testing scheme active but person complies with testing
}

/**
 * @brief Test to validate the parameter constraints within the model.
 */
TEST_F(TestModel, checkParameterConstraints)
{
    mio::set_log_level(mio::LogLevel::critical); // Suppress logging of errors since they are expected here
    auto model  = mio::abm::Model(num_age_groups);
    auto params = model.parameters;

    params.get<mio::abm::TimeExposedToNoSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(1., 0.5);
    params.get<mio::abm::TimeInfectedNoSymptomsToSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(2., 0.5);
    params.get<mio::abm::TimeInfectedNoSymptomsToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(3., 0.5);
    params.get<mio::abm::TimeInfectedSymptomsToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(4., 0.5);
    params.get<mio::abm::TimeInfectedSymptomsToSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(5., 0.5);
    params.get<mio::abm::TimeInfectedSevereToCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(6., 0.5);
    params.get<mio::abm::TimeInfectedSevereToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(7., 0.5);
    params.get<mio::abm::TimeInfectedSevereToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(7., 0.5);
    params.get<mio::abm::TimeInfectedCriticalToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(8., 0.5);
    params.get<mio::abm::TimeInfectedCriticalToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(9., 0.5);
    params.get<mio::abm::SymptomsPerInfectedNoSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = 0.2;
    params.get<mio::abm::SeverePerInfectedSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}]     = 0.1;
    params.get<mio::abm::CriticalPerInfectedSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}]     = 0.05;
    params.get<mio::abm::DeathsPerInfectedSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}]       = 0.001;
    params.get<mio::abm::DeathsPerInfectedCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}]     = 0.1;
    params.get<mio::abm::ViralShedFactor>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionUniform(1.0, 1.0);
    params.get<mio::abm::GotoWorkTimeMinimum>()[age_group_35_to_59]                      = mio::abm::hours(4);
    params.get<mio::abm::GotoWorkTimeMaximum>()[age_group_35_to_59]                      = mio::abm::hours(8);
    params.get<mio::abm::GotoSchoolTimeMinimum>()[age_group_0_to_4]                      = mio::abm::hours(3);
    params.get<mio::abm::GotoSchoolTimeMaximum>()[age_group_0_to_4]                      = mio::abm::hours(6);
    params.get<mio::abm::InfectionRateFromViralShed>()[mio::abm::VirusVariant::Wildtype] = 0.1;
    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::Community]                = 0.5;
    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::FFP2]                     = 0.6;
    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::Surgical]                 = 0.7;
    params.get<mio::abm::QuarantineEffectiveness>()                                      = 0.5;
    params.get<mio::abm::QuarantineDuration>()                                           = mio::abm::days(14);
    params.get<mio::abm::LockdownDate>()                                                 = mio::abm::TimePoint(0);
    ASSERT_EQ(params.check_constraints(), false);

    params.get<mio::abm::TimeExposedToNoSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-1., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeExposedToNoSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(1., 0.5);
    params.get<mio::abm::TimeInfectedNoSymptomsToSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-2., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedNoSymptomsToSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(2., 0.5);
    params.get<mio::abm::TimeInfectedNoSymptomsToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-3., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedNoSymptomsToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(3., 0.5);
    params.get<mio::abm::TimeInfectedSymptomsToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-4., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedSymptomsToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(4., 0.5);
    params.get<mio::abm::TimeInfectedSymptomsToSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-5., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedSymptomsToSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(5., 0.5);
    params.get<mio::abm::TimeInfectedSevereToCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-6., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedSevereToCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(6., 0.5);
    params.get<mio::abm::TimeInfectedSevereToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-7., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedSevereToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(7., 0.5);
    params.get<mio::abm::TimeInfectedSevereToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-7., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedSevereToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(7., 0.5);
    params.get<mio::abm::TimeInfectedCriticalToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-8., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedCriticalToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(8., 0.5);
    params.get<mio::abm::TimeInfectedCriticalToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(-9., 0.5);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::TimeInfectedCriticalToRecovered>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionLogNormal(9., 0.5);
    params.get<mio::abm::SymptomsPerInfectedNoSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = -0.1;
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::SymptomsPerInfectedNoSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = 0.2;
    params.get<mio::abm::SeverePerInfectedSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}]     = -0.1;
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::SeverePerInfectedSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = 0.1;
    params.get<mio::abm::CriticalPerInfectedSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = -0.1;
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::CriticalPerInfectedSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = 0.05;
    params.get<mio::abm::DeathsPerInfectedSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}]   = -0.1;
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::DeathsPerInfectedSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = 0.99;
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::DeathsPerInfectedSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}]   = 0.001;
    params.get<mio::abm::DeathsPerInfectedCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = -0.1;
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::DeathsPerInfectedCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] = 0.1;
    params.get<mio::abm::ViralShedFactor>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionUniform(-1.0, 1.0);
    ASSERT_EQ(params.check_constraints(), true);
    params.get<mio::abm::ViralShedFactor>()[{mio::abm::VirusVariant::Wildtype, age_group_0_to_4}] =
        mio::ParameterDistributionUniform(1.0, 1.0);

    params.get<mio::abm::GotoWorkTimeMinimum>()[age_group_35_to_59] = mio::abm::hours(30);
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::GotoWorkTimeMinimum>()[age_group_35_to_59] = mio::abm::hours(4);
    params.get<mio::abm::GotoWorkTimeMaximum>()[age_group_35_to_59] = mio::abm::hours(30);
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::GotoWorkTimeMaximum>()[age_group_35_to_59] = mio::abm::hours(8);
    params.get<mio::abm::GotoSchoolTimeMinimum>()[age_group_0_to_4] = mio::abm::hours(30);
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::GotoSchoolTimeMinimum>()[age_group_0_to_4] = mio::abm::hours(3);
    params.get<mio::abm::GotoSchoolTimeMaximum>()[age_group_0_to_4] = mio::abm::hours(30);
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::GotoSchoolTimeMaximum>()[age_group_0_to_4] = mio::abm::hours(6);

    params.get<mio::abm::InfectionRateFromViralShed>()[mio::abm::VirusVariant::Wildtype] = -0.1;
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::InfectionRateFromViralShed>()[mio::abm::VirusVariant::Wildtype] = 0.1;

    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::Community] = 1.2;
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::Community] = 0.5;
    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::FFP2]      = 1.2;
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::FFP2]     = 0.6;
    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::Surgical] = 1.2;
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::MaskProtection>()[mio::abm::MaskType::Surgical] = 0.7;

    params.get<mio::abm::QuarantineEffectiveness>() = -0.1;
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::QuarantineEffectiveness>() = 1.5;
    EXPECT_TRUE(params.check_constraints());
    params.get<mio::abm::QuarantineEffectiveness>() = 0.8;

    params.get<mio::abm::LockdownDate>() = mio::abm::TimePoint(-2);
    EXPECT_TRUE(params.check_constraints());
    mio::set_log_level(mio::LogLevel::warn);
}

/**
 * @brief Test the enforcement of NPIs (Non-Pharmaceutical Interventions) on mobility rules.
 */
TEST_F(TestModel, mobilityRulesWithAppliedNPIs)
{
    using testing::Return;
    // Test when the NPIs are applied, people can enter targeted location if they comply to the rules.
    auto t          = mio::abm::TimePoint(0) + mio::abm::hours(8);
    auto dt         = mio::abm::hours(1);
    auto test_time  = mio::abm::minutes(30);
    auto model      = mio::abm::Model(num_age_groups);
    model.get_rng() = this->get_rng();

    model.parameters
        .get<mio::abm::TimeInfectedNoSymptomsToSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_15_to_34}] =
        mio::ParameterDistributionConstant(2 * dt.days());
    model.parameters.get<mio::abm::AgeGroupGotoWork>().set_multiple({age_group_15_to_34, age_group_35_to_59}, true);
    model.parameters.get<mio::abm::AgeGroupGotoSchool>()[age_group_5_to_14] = true;

    auto home_id   = model.add_location(mio::abm::LocationType::Home);
    auto work_id   = model.add_location(mio::abm::LocationType::Work);
    auto school_id = model.add_location(mio::abm::LocationType::School);
    auto& work     = model.get_location(work_id);

    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist;
    EXPECT_CALL(mock_uniform_dist.get_mock(), invoke)
        .Times(testing::AtLeast(16))
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillRepeatedly(testing::Return(0.9)); // draw that satisfies all pre-conditions of NPIs

    // Since tests are performed before t, the InfectionState of all the Person have to take into account test_time
    auto p_id_compliant_go_to_work =
        add_test_person(model, home_id, age_group_15_to_34, mio::abm::InfectionState::Susceptible, t - test_time);
    auto p_id_compliant_go_to_school =
        add_test_person(model, home_id, age_group_5_to_14, mio::abm::InfectionState::Susceptible, t - test_time);
    auto p_id_no_mask =
        add_test_person(model, home_id, age_group_15_to_34, mio::abm::InfectionState::Susceptible, t - test_time);
    auto p_id_no_test      = add_test_person(model, home_id, age_group_15_to_34,
                                             mio::abm::InfectionState::InfectedNoSymptoms, t - test_time);
    auto p_id_no_isolation = add_test_person(model, home_id, age_group_15_to_34,
                                             mio::abm::InfectionState::InfectedNoSymptoms, t - test_time);

    auto& p_compliant_go_to_work   = model.get_person(p_id_compliant_go_to_work);
    auto& p_compliant_go_to_school = model.get_person(p_id_compliant_go_to_school);
    auto& p_no_mask                = model.get_person(p_id_no_mask);
    auto& p_no_test                = model.get_person(p_id_no_test);
    auto& p_no_isolation           = model.get_person(p_id_no_isolation);

    p_compliant_go_to_work.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_compliant_go_to_work.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_compliant_go_to_work.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_compliant_go_to_school.set_assigned_location(mio::abm::LocationType::School, school_id, model.get_id());
    p_compliant_go_to_school.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_no_mask.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_no_mask.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_no_test.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_no_test.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_no_isolation.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_no_isolation.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());

    auto testing_criteria = mio::abm::TestingCriteria(
        {}, {mio::abm::InfectionState::InfectedSymptoms, mio::abm::InfectionState::InfectedNoSymptoms});
    const auto start_date        = mio::abm::TimePoint(0);
    const auto end_date          = mio::abm::TimePoint(60 * 60 * 24 * 3);
    const auto probability       = 1;
    const auto test_params       = mio::abm::TestParameters{0.99, 0.99, test_time, mio::abm::TestType::Generic};
    const auto testing_frequency = mio::abm::days(1);

    auto testing_scheme =
        mio::abm::TestingScheme(testing_criteria, testing_frequency, start_date, end_date, test_params, probability);
    model.get_testing_strategy().add_scheme(mio::abm::LocationType::Work, testing_scheme);

    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::ExponentialDistribution<double>>>>
        mock_exponential_dist;
    EXPECT_CALL(mock_exponential_dist.get_mock(), invoke).WillRepeatedly(Return(1.));

    work.set_required_mask(mio::abm::MaskType::FFP2);
    p_no_mask.set_compliance(mio::abm::InterventionType::Mask, 0.4);
    p_no_test.set_compliance(mio::abm::InterventionType::Testing, 0.4);
    p_no_isolation.set_compliance(mio::abm::InterventionType::Isolation, 0.4);

    model.evolve(t, dt);

    // The complied person is allowed to be at work and wear the required mask
    EXPECT_EQ(p_compliant_go_to_work.get_location(), work_id);
    EXPECT_EQ(p_compliant_go_to_work.get_mask().get_type(), mio::abm::MaskType::FFP2);

    // The complied person is allowed to be at school and don't wear mask
    EXPECT_EQ(p_compliant_go_to_school.get_location(), school_id);
    EXPECT_EQ(p_compliant_go_to_school.get_mask().get_type(), mio::abm::MaskType::None);

    // The person, who does not wear mask, is not allowed to be in location
    EXPECT_EQ(p_no_mask.get_mask().get_type(), mio::abm::MaskType::None);
    EXPECT_NE(p_no_mask.get_location(), work_id);

    // The person, who does not want test, is not allowed to be in location
    EXPECT_NE(p_no_test.get_location(), work_id);

    // The person does not want to isolate when the test is positive
    EXPECT_FALSE(p_no_isolation.is_in_quarantine(t, model.parameters));
}

/**
 * @brief Test the enforcement of NPIs (Non-Pharmaceutical Interventions) on trips.
 */
TEST_F(TestModel, mobilityTripWithAppliedNPIs)
{
    using testing::Return;
    // Test when the NPIs are applied, people can enter targeted location if they comply to the rules.
    auto t          = mio::abm::TimePoint(0) + mio::abm::hours(8);
    auto dt         = mio::abm::hours(1);
    auto test_time  = mio::abm::minutes(30);
    auto model      = mio::abm::Model(num_age_groups);
    model.get_rng() = this->get_rng();
    model.parameters
        .get<mio::abm::TimeInfectedNoSymptomsToSymptoms>()[{mio::abm::VirusVariant::Wildtype, age_group_15_to_34}] =
        mio::ParameterDistributionConstant(2 * dt.days());
    model.parameters.get<mio::abm::AgeGroupGotoWork>().set_multiple({age_group_15_to_34, age_group_35_to_59}, true);
    model.parameters.get<mio::abm::AgeGroupGotoSchool>()[age_group_5_to_14] = true;

    auto home_id   = model.add_location(mio::abm::LocationType::Home);
    auto work_id   = model.add_location(mio::abm::LocationType::Work);
    auto school_id = model.add_location(mio::abm::LocationType::School);
    auto& work     = model.get_location(work_id);

    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist;
    EXPECT_CALL(mock_uniform_dist.get_mock(), invoke)
        .Times(testing::AtLeast(16))
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillOnce(testing::Return(0.8)) // draw random work group
        .WillOnce(testing::Return(0.8)) // draw random school group
        .WillOnce(testing::Return(0.8)) // draw random work hour
        .WillOnce(testing::Return(0.8)) // draw random school hour
        .WillRepeatedly(testing::Return(0.9)); // draw that satisfies all pre-conditions of NPIs

    // Since tests are performed before t, the InfectionState of all the Person have to take into account test_time
    auto p_id_compliant_go_to_work =
        add_test_person(model, home_id, age_group_15_to_34, mio::abm::InfectionState::Susceptible, t - test_time);
    auto p_id_compliant_go_to_school =
        add_test_person(model, home_id, age_group_5_to_14, mio::abm::InfectionState::Susceptible, t - test_time);
    auto p_id_no_mask =
        add_test_person(model, home_id, age_group_15_to_34, mio::abm::InfectionState::Susceptible, t - test_time);
    auto p_id_no_test      = add_test_person(model, home_id, age_group_15_to_34,
                                             mio::abm::InfectionState::InfectedNoSymptoms, t - test_time);
    auto p_id_no_isolation = add_test_person(model, home_id, age_group_15_to_34,
                                             mio::abm::InfectionState::InfectedNoSymptoms, t - test_time);

    auto& p_compliant_go_to_work   = model.get_person(p_id_compliant_go_to_work);
    auto& p_compliant_go_to_school = model.get_person(p_id_compliant_go_to_school);
    auto& p_no_mask                = model.get_person(p_id_no_mask);
    auto& p_no_test                = model.get_person(p_id_no_test);
    auto& p_no_isolation           = model.get_person(p_id_no_isolation);

    p_compliant_go_to_work.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_compliant_go_to_work.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_compliant_go_to_work.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_compliant_go_to_school.set_assigned_location(mio::abm::LocationType::School, school_id, model.get_id());
    p_compliant_go_to_school.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_no_mask.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_no_mask.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_no_test.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_no_test.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_no_isolation.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());
    p_no_isolation.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());

    auto testing_criteria = mio::abm::TestingCriteria(
        {}, {mio::abm::InfectionState::InfectedSymptoms, mio::abm::InfectionState::InfectedNoSymptoms});
    const auto start_date        = mio::abm::TimePoint(0);
    const auto end_date          = mio::abm::TimePoint(60 * 60 * 24 * 3);
    const auto probability       = 1;
    const auto test_params       = mio::abm::TestParameters{0.99, 0.99, test_time, mio::abm::TestType::Generic};
    const auto testing_frequency = mio::abm::days(1);

    auto testing_scheme =
        mio::abm::TestingScheme(testing_criteria, testing_frequency, start_date, end_date, test_params, probability);
    model.get_testing_strategy().add_scheme(mio::abm::LocationType::Work, testing_scheme);

    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::ExponentialDistribution<double>>>>
        mock_exponential_dist;
    EXPECT_CALL(mock_exponential_dist.get_mock(), invoke).WillRepeatedly(Return(1.));

    work.set_required_mask(mio::abm::MaskType::FFP2);
    p_no_mask.set_compliance(mio::abm::InterventionType::Mask, 0.4);
    p_no_test.set_compliance(mio::abm::InterventionType::Testing, 0.4);
    p_no_isolation.set_compliance(mio::abm::InterventionType::Isolation, 0.4);

    // Using trip list
    mio::abm::TripList& trip_list = model.get_trip_list();
    mio::abm::Trip trip1(p_compliant_go_to_work.get_id(), t, work_id);
    mio::abm::Trip trip2(p_compliant_go_to_school.get_id(), t, school_id);
    mio::abm::Trip trip3(p_no_mask.get_id(), t, work_id);
    mio::abm::Trip trip4(p_no_test.get_id(), t, work_id);
    mio::abm::Trip trip5(p_no_isolation.get_id(), t, work_id);
    trip_list.add_trips({trip1, trip2, trip3, trip4, trip5});
    model.use_mobility_rules(false);
    model.evolve(t, dt);

    // The complied person is allowed to be at work and wear the required mask
    EXPECT_EQ(p_compliant_go_to_work.get_location(), work_id);
    EXPECT_EQ(p_compliant_go_to_work.get_mask().get_type(), mio::abm::MaskType::FFP2);

    // The complied person is allowed to be at school and don't wear mask
    EXPECT_EQ(p_compliant_go_to_school.get_location(), school_id);
    EXPECT_EQ(p_compliant_go_to_school.get_mask().get_type(), mio::abm::MaskType::None);

    // The person, who does not wear mask, is not allowed to be in location
    EXPECT_EQ(p_no_mask.get_mask().get_type(), mio::abm::MaskType::None);
    EXPECT_NE(p_no_mask.get_location(), work_id);

    // The person, who does not want test, is not allowed to be in location
    EXPECT_NE(p_no_test.get_location(), work_id);

    // The person does not want to isolate when the test is positive
    EXPECT_FALSE(p_no_isolation.is_in_quarantine(t, model.parameters));
}

/**
 * @brief Tests whether a person can die in a hospital setting, specifically not only in the InfectionState Severe.
 */
TEST_F(TestModel, personCanDieInHospital)
{
    using testing::Return;

    auto t          = mio::abm::TimePoint(0);
    auto dt         = mio::abm::days(1);
    auto model      = mio::abm::Model(num_age_groups);
    model.get_rng() = this->get_rng();

    // Time to go from infected with symptoms to severe infection is 1 day(dt).
    model.parameters
        .get<mio::abm::TimeInfectedSymptomsToSevere>()[{mio::abm::VirusVariant::Wildtype, age_group_60_to_79}] =
        mio::ParameterDistributionConstant(1);
    // Time to go from severe infection to critical is 1 day(dt).
    model.parameters
        .get<mio::abm::TimeInfectedSevereToCritical>()[{mio::abm::VirusVariant::Wildtype, age_group_60_to_79}] =
        mio::ParameterDistributionConstant(1);
    // Time to go from severe infection to dead is 1 day(dt).
    model.parameters.get<mio::abm::TimeInfectedSevereToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_60_to_79}] =
        mio::ParameterDistributionConstant(1);
    // Time to go from critical infection to dead is 1 day(dt).
    model.parameters
        .get<mio::abm::TimeInfectedCriticalToDead>()[{mio::abm::VirusVariant::Wildtype, age_group_60_to_79}] =
        mio::ParameterDistributionConstant(1);

    auto home_id     = model.add_location(mio::abm::LocationType::Home);
    auto work_id     = model.add_location(mio::abm::LocationType::Work);
    auto icu_id      = model.add_location(mio::abm::LocationType::ICU);
    auto hospital_id = model.add_location(mio::abm::LocationType::Hospital);

    // Make sure all persons will be InfectedSevere before Dead.
    // Also mocks other things in the setup and evolve, thus not using times::Exactly here.
    // 0.09 is required to have state InfectedSevere before Dead
    ScopedMockDistribution<testing::StrictMock<MockDistribution<mio::UniformDistribution<double>>>> mock_uniform_dist;
    EXPECT_CALL(mock_uniform_dist.get_mock(), invoke).WillRepeatedly(testing::Return(0.09));

    // Create a person that has InfectedSymptoms at time t - dt. The person is dead at time t + dt
    add_test_person(model, home_id, age_group_60_to_79, mio::abm::InfectionState::Dead, t + dt);

    auto& p_severe = model.get_persons()[0];
    p_severe.set_assigned_location(mio::abm::LocationType::Hospital, hospital_id, model.get_id());
    p_severe.set_assigned_location(mio::abm::LocationType::ICU, icu_id, model.get_id());
    p_severe.set_assigned_location(mio::abm::LocationType::Home, home_id, model.get_id());
    p_severe.set_assigned_location(mio::abm::LocationType::Work, work_id, model.get_id());

    // Check the infection course goes from InfectedSymptoms to Severe to Dead and skips Critical
    EXPECT_EQ(p_severe.get_infection_state(t - dt), mio::abm::InfectionState::InfectedSymptoms);
    EXPECT_EQ(p_severe.get_infection_state(t), mio::abm::InfectionState::InfectedSevere);
    EXPECT_EQ(p_severe.get_infection_state(t + dt), mio::abm::InfectionState::Dead);

    // Check the severely infected person go to hospital
    EXPECT_EQ(model.get_location(p_severe.get_id()).get_type(), mio::abm::LocationType::Home);
    model.evolve(t, dt);
    EXPECT_EQ(model.get_location(p_severe.get_id()).get_type(), mio::abm::LocationType::Hospital);
    // Check the severely infected person dies and got burried
    model.evolve(t + dt, dt);
    EXPECT_EQ(model.get_location(p_severe.get_id()).get_type(), mio::abm::LocationType::Cemetery);
}

TEST_F(TestModel, reset_rng)
{
    const int num_samples = 100; // number of samples used for comparing random sequences
    auto model            = mio::abm::Model(num_age_groups);
    model.get_rng()       = this->get_rng();
    // add two generic persons
    {
        // use DefaultFactory to avoid using the RNG in the Person ctor
        auto p = mio::DefaultFactory<mio::abm::Person>::create();
        p.set_location(mio::abm::LocationType::Cemetery, mio::abm::LocationId(0), 0);
        model.add_person(mio::abm::Person(p, mio::abm::PersonId(0)));
        model.add_person(mio::abm::Person(p, mio::abm::PersonId(1)));
    }
    auto& p0 = model.get_persons()[0];
    auto& p1 = model.get_persons()[1];
    // shorthand for drawing a random vector using a personal RNG
    const auto draw_samples = [](mio::abm::PersonalRandomNumberGenerator&& rng) {
        std::vector<mio::abm::PersonalRandomNumberGenerator::result_type> samples(num_samples);
        std::ranges::generate(samples, rng);
        return samples;
    };

    // case: draw independent samples from each person; expect the same random sequence for both persons after a reset
    const auto reference_samples0      = draw_samples({model.get_rng(), p0});
    const auto reference_samples0_cont = draw_samples({model.get_rng(), p0}); // used for next case
    const auto reference_samples1      = draw_samples({model.get_rng(), p1});
    model.reset_rng();
    EXPECT_EQ(reference_samples1, draw_samples({model.get_rng(), p1})); // reverse order to check independence
    EXPECT_EQ(reference_samples0, draw_samples({model.get_rng(), p0}));

    // case: draw samples twice from one person;
    //   expect the same random sequence after resetting with the counter set to num_samples
    model.reset_rng(mio::Counter<uint32_t>(num_samples));
    EXPECT_EQ(reference_samples0_cont, draw_samples({model.get_rng(), p0}));

    // case: reset with seed and counter; expect seed and counter to be set accordingly
    // this is a very simplistic test, as the main behaviour of the reset function is covered sufficiently above
    const std::vector<uint32_t> test_seed{1, 2, 3, 4, 5, 6};
    const mio::Counter<uint32_t> test_ctr(7);
    model.reset_rng(test_seed, test_ctr);
    EXPECT_EQ(model.get_rng().get_seeds(), test_seed);
    EXPECT_EQ(p0.get_rng_counter(), test_ctr);
    EXPECT_EQ(p1.get_rng_counter(), test_ctr);
}
