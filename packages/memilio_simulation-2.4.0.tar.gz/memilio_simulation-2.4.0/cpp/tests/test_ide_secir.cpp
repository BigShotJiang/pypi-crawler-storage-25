/* 
* Copyright (C) 2020-2026 MEmilio
*
* Authors: Lena Ploetzke, Anna Wendler
*
* Contact: Martin J. Kuehn <Martin.Kuehn@DLR.de>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
#include "load_test_data.h"
#include "ide_secir/infection_state.h"
#include "ide_secir/model.h"
#include "ide_secir/parameters.h"
#include "ide_secir/simulation.h"
#include "memilio/epidemiology/age_group.h"
#include "memilio/epidemiology/state_age_function.h"
#include "memilio/math/eigen.h"
#include "memilio/utils/time_series.h"
#include "memilio/utils/logging.h"
#include "memilio/config.h"
#include "memilio/epidemiology/uncertain_matrix.h"
#include <gtest/gtest.h>
#include <vector>

class ModelTestIdeSecir : public testing::Test
{
protected:
    virtual void SetUp()
    {
        using Vec = mio::TimeSeries<ScalarType>::Vector;

        //Set initial conditions
        size_t num_agegroups = 1;

        mio::CustomIndexArray<ScalarType, mio::AgeGroup> N =
            mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10000.);
        mio::CustomIndexArray<ScalarType, mio::AgeGroup> deaths =
            mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 13.10462213);

        int num_transitions = (int)mio::isecir::InfectionTransition::Count;

        Vec vec_init(num_transitions * num_agegroups);
        mio::TimeSeries<ScalarType> init(num_transitions * num_agegroups);
        vec_init[(int)mio::isecir::InfectionTransition::SusceptibleToExposed]                 = 25.0;
        vec_init[(int)mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms]          = 15.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedNoSymptomsToInfectedSymptoms] = 8.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedNoSymptomsToRecovered]        = 4.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedSymptomsToInfectedSevere]     = 1.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedSymptomsToRecovered]          = 4.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedSevereToInfectedCritical]     = 1.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedSevereToDead]                 = 0.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedSevereToRecovered]            = 1.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedCriticalToDead]               = 1.0;
        vec_init[(int)mio::isecir::InfectionTransition::InfectedCriticalToRecovered]          = 1.0;
        init.add_time_point(-10.0, vec_init);
        while (init.get_last_time() < 0) {
            vec_init *= 1.01;
            init.add_time_point(init.get_last_time() + dt, vec_init);
        }

        // Initialize model
        model = new mio::isecir::Model(std::move(init), N, deaths, num_agegroups);

        // Set working parameters.

        mio::SmootherCosine<ScalarType> smoothcos(2.0);
        mio::StateAgeFunctionWrapper<ScalarType> delaydistribution(smoothcos);
        std::vector<mio::StateAgeFunctionWrapper<ScalarType>> vec_delaydistrib(num_transitions, delaydistribution);
        model->parameters.get<mio::isecir::TransitionDistributions>()[mio::AgeGroup(0)] = vec_delaydistrib;

        std::vector<ScalarType> vec_prob((int)mio::isecir::InfectionTransition::Count, 0.5);
        vec_prob[Eigen::Index(mio::isecir::InfectionTransition::SusceptibleToExposed)]        = 1;
        vec_prob[Eigen::Index(mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms)] = 1;
        vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSevereToDead)]        = 0;
        model->parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)]       = vec_prob;

        mio::ContactMatrixGroup<ScalarType> contact_matrix = mio::ContactMatrixGroup<ScalarType>(1, num_agegroups);
        contact_matrix[0] =
            mio::ContactMatrix<ScalarType>(Eigen::MatrixX<ScalarType>::Constant(num_agegroups, num_agegroups, 10.));
        model->parameters.get<mio::isecir::ContactPatterns>() = mio::UncertainContactMatrix(contact_matrix);

        mio::ExponentialSurvivalFunction exponential(0.5);
        mio::StateAgeFunctionWrapper<ScalarType> prob(exponential);
        model->parameters.get<mio::isecir::TransmissionProbabilityOnContact>()[mio::AgeGroup(0)] = prob;
        model->parameters.get<mio::isecir::RelativeTransmissionNoSymptoms>()[mio::AgeGroup(0)]   = prob;
        model->parameters.get<mio::isecir::RiskOfInfectionFromSymptomatic>()[mio::AgeGroup(0)]   = prob;
        model->parameters.set<mio::isecir::Seasonality>(0.);
        model->parameters.set<mio::isecir::StartDay>(0);

        model->set_tol_for_support_max(1e-10);
    }

    virtual void TearDown()
    {
        delete model;
    }

public:
    mio::isecir::Model* model = nullptr;
    ScalarType dt             = 1;
};

// Check if population stays constant over course of simulation.
TEST_F(ModelTestIdeSecir, checkPopulationConservation)
{
    mio::TimeSeries<ScalarType> compartments = simulate(15, dt, *model);
    ScalarType num_persons_before            = 0.0;
    ScalarType num_persons_after             = 0.0;

    for (auto i = 0; i < compartments[0].size(); i++) {
        num_persons_before += compartments[0][i];
        num_persons_after += compartments.get_last_value()[i];
    }

    EXPECT_NEAR(num_persons_after, num_persons_before, 1e-10);
}

// Compare compartments with previous run.
TEST_F(ModelTestIdeSecir, compareWithPreviousRun)
{
    auto compare                             = load_test_data_csv<ScalarType>("ide-secir-compare.csv");
    mio::TimeSeries<ScalarType> compartments = simulate(5, dt, *model);

    ASSERT_EQ(compare.size(), static_cast<size_t>(compartments.get_num_time_points()));
    for (size_t i = 0; i < compare.size(); i++) {
        ASSERT_EQ(compare[i].size(), static_cast<size_t>(compartments.get_num_elements()) + 1) << "at row " << i;
        ASSERT_NEAR(compartments.get_time(i), compare[i][0], 1e-7) << "at row " << i;
        for (size_t j = 1; j < compare[i].size(); j++) {
            ASSERT_NEAR(compartments.get_value(i)[j - 1], compare[i][j], 1e-7) << " at row " << i;
        }
    }
}

// Compare transitions with previous run.
TEST_F(ModelTestIdeSecir, compareWithPreviousRunTransitions)
{
    auto compare = load_test_data_csv<ScalarType>("ide-secir-transitions-compare.csv");

    mio::isecir::Simulation sim(*model, dt);
    sim.advance(5);

    auto transitions = sim.get_transitions();

    size_t iter_0 = 0;
    while (transitions.get_time(iter_0) < compare[0][0]) {
        iter_0++;
    }

    for (size_t i = 0; i < compare.size(); i++) {
        ASSERT_EQ(compare[i].size(), static_cast<size_t>(transitions.get_num_elements()) + 1) << "at row " << i;
        ASSERT_NEAR(transitions.get_time(i + iter_0), compare[i][0], 1e-7) << "at row " << i;
        for (size_t j = 1; j < compare[i].size(); j++) {
            ASSERT_NEAR(transitions.get_value(i + iter_0)[j - 1], compare[i][j], 1e-7) << " at row " << i;
        }
    }
}

// Check that the start time of the simulation is determined by the given time points for the transitions.
TEST(IdeSecir, checkStartTime)
{
    using Vec = mio::TimeSeries<ScalarType>::Vector;

    size_t num_agegroups = 1;
    ScalarType tmax      = 3.0;
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> N =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10000.);
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> deaths =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10.);
    ScalarType dt = 1.;
    ScalarType t0 = 2.;

    int num_transitions = (int)mio::isecir::InfectionTransition::Count;

    // Create TimeSeries with num_transitions * num_agegroups elements where transitions needed for simulation
    // will be stored.
    mio::TimeSeries<ScalarType> init(num_transitions * num_agegroups);

    // Define transitions that will be used for initialization.
    Vec vec_init = Vec::Constant(num_transitions * num_agegroups, 0.);
    vec_init[(int)mio::isecir::InfectionTransition::SusceptibleToExposed]                 = 1.0;
    vec_init[(int)mio::isecir::InfectionTransition::InfectedNoSymptomsToInfectedSymptoms] = 8.0;
    // Add initial time point to TimeSeries.
    init.add_time_point(0.0, vec_init);
    // Add further time points until t0.
    while (init.get_last_time() < t0) {
        init.add_time_point(init.get_last_time() + dt, vec_init);
    }

    // Initialize model.
    mio::isecir::Model model(std::move(init), N, deaths, num_agegroups);

    // Create class for simulation.
    mio::isecir::Simulation sim(model, dt);

    // Check that the last time point of transitions is equal to t0.
    mio::TimeSeries<ScalarType> transitions = sim.get_transitions();
    EXPECT_NEAR(t0, transitions.get_last_time(), 1e-8);

    // Carry out simulation and check that first time point of resulting compartments is equal to t0.
    sim.advance(tmax);
    mio::TimeSeries<ScalarType> compartments = sim.get_result();
    EXPECT_NEAR(t0, compartments.get_time(0), 1e-8);
}

// Check results of our simulation with an example calculated by hand,
// see https://doi.org/10.1016/j.amc.2025.129636 for the used formulas.
TEST(IdeSecir, checkSimulationFunctions)
{
    using Vec            = mio::TimeSeries<ScalarType>::Vector;
    size_t num_agegroups = 1;
    ScalarType tmax      = 0.5;
    ScalarType dt        = 0.5;

    mio::CustomIndexArray<ScalarType, mio::AgeGroup> N =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10000.);
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> deaths =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10.);

    // Create TimeSeries with num_transitions elements where transitions needed for simulation will be stored.
    int num_transitions = (int)mio::isecir::InfectionTransition::Count;
    mio::TimeSeries<ScalarType> init(num_transitions * num_agegroups);

    // Add time points for initialization for transitions and death.
    Vec vec_init                                                          = Vec::Constant(num_transitions, 0.);
    vec_init[(int)mio::isecir::InfectionTransition::SusceptibleToExposed] = 1.0;
    vec_init[(int)mio::isecir::InfectionTransition::InfectedNoSymptomsToInfectedSymptoms] = 8.0;
    // Add initial time point to TimeSeries.
    init.add_time_point(-0.5, vec_init);
    while (init.get_last_time() < 0) {
        init.add_time_point(init.get_last_time() + dt, vec_init);
    }

    // Initialize model.
    mio::isecir::Model model(std::move(init), N, deaths, num_agegroups);

    // Set working parameters.
    // In this example, SmootherCosine with parameter 1 (and thus with a maximum support of 1)
    // is used for all TransitionDistribution%s.
    mio::SmootherCosine<ScalarType> smoothcos(1.0);
    mio::StateAgeFunctionWrapper<ScalarType> delaydistribution(smoothcos);
    std::vector<mio::StateAgeFunctionWrapper<ScalarType>> vec_delaydistrib(num_transitions, delaydistribution);
    model.parameters.get<mio::isecir::TransitionDistributions>()[mio::AgeGroup(0)] = vec_delaydistrib;

    std::vector<ScalarType> vec_prob((int)mio::isecir::InfectionTransition::Count, 0.5);
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::SusceptibleToExposed)]        = 1;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms)] = 1;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSevereToDead)]        = 0;
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)]        = vec_prob;

    mio::ContactMatrixGroup<ScalarType> contact_matrix = mio::ContactMatrixGroup<ScalarType>(1, num_agegroups);
    contact_matrix[0] =
        mio::ContactMatrix<ScalarType>(Eigen::MatrixX<ScalarType>::Constant(num_agegroups, num_agegroups, 4.));
    model.parameters.get<mio::isecir::ContactPatterns>() = mio::UncertainContactMatrix(contact_matrix);

    mio::SmootherCosine<ScalarType> smoothcos_prob(1.0);
    mio::StateAgeFunctionWrapper<ScalarType> prob(smoothcos_prob);
    model.parameters.get<mio::isecir::TransmissionProbabilityOnContact>()[mio::AgeGroup(0)] = prob;
    model.parameters.get<mio::isecir::RelativeTransmissionNoSymptoms>()[mio::AgeGroup(0)]   = prob;
    model.parameters.get<mio::isecir::RiskOfInfectionFromSymptomatic>()[mio::AgeGroup(0)]   = prob;
    model.parameters.set<mio::isecir::Seasonality>(0.);
    model.parameters.set<mio::isecir::StartDay>(0);

    // Carry out simulation.
    mio::isecir::Simulation sim(model, dt);
    sim.advance(tmax);
    mio::TimeSeries<ScalarType> secihurd_simulated    = sim.get_result();
    mio::TimeSeries<ScalarType> transitions_simulated = sim.get_transitions();

    // Define vectors for compartments and transitions at t0 and t1 with values from example
    // (calculated by hand, see https://doi.org/10.1016/j.amc.2025.129636 for the used formulas).
    Vec secihurd_t0((int)mio::isecir::InfectionState::Count);
    Vec secihurd_t1((int)mio::isecir::InfectionState::Count);
    Vec transitions_t1(num_transitions);
    secihurd_t0 << 4995, 0.5, 0, 4, 0, 0, 4990.5, 10;
    secihurd_t1 << 4994.00020016, 0.49989992, 0.49994996, 0.12498749, 1.03124687, 0.25781172, 4993.45699802,
        10.12890586;
    transitions_t1 << 0.99979984, 0.99989992, 0.24997498, 0.24997498, 2.06249374, 2.06249374, 0.51562344, 0.,
        0.51562344, 0.12890586, 0.12890586;

    // Compare simulated compartments at time points t0 and t1.
    for (Eigen::Index i = 0; i < (Eigen::Index)mio::isecir::InfectionState::Count; i++) {
        EXPECT_NEAR(secihurd_simulated[0][i], secihurd_t0[i], 1e-8);
        EXPECT_NEAR(secihurd_simulated[1][i], secihurd_t1[i], 1e-8);
    }

    // Compare simulated transitions with expected results at time point t1.
    for (Eigen::Index i = 0; i < num_transitions; i++) {
        EXPECT_NEAR(transitions_simulated[transitions_simulated.get_num_time_points() - 1][i], transitions_t1[i], 1e-8);
    }
}

// Check if the model uses the correct method for initialization using the function get_initialization_method_compartments().
TEST(IdeSecir, checkInitializations)
{
    using Vec = mio::TimeSeries<ScalarType>::Vector;

    size_t num_agegroups = 1;

    ScalarType tmax = 1;
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> N =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10000.);
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> deaths =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 13.10462213);
    ScalarType dt = 1;

    int num_transitions = (int)mio::isecir::InfectionTransition::Count;

    // Create TimeSeries with num_transitions elements where transitions needed for simulation will be stored.
    mio::TimeSeries<ScalarType> init(num_transitions * num_agegroups);
    // Add initial time point to time series.
    init.add_time_point(-10, Vec::Constant(num_transitions, 3.0));
    // Add further time points until time 0.
    while (init.get_last_time() < 0) {
        init.add_time_point(init.get_last_time() + dt, Vec::Constant(num_transitions, 3.0));
    }

    // --- Case with total_confirmed_cases.
    mio::TimeSeries<ScalarType> init_copy1(init);
    mio::isecir::Model model1(std::move(init_copy1), N, deaths, num_agegroups,
                              mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 1000.));

    // Check that the initialization method is not already set.
    EXPECT_EQ(0, model1.get_initialization_method_compartments());

    // Carry out simulation.
    mio::isecir::Simulation sim1(model1, dt);
    sim1.advance(tmax);

    // Verify that the expected initialization method was used.
    EXPECT_EQ(1, sim1.get_model().get_initialization_method_compartments());

    // --- Case with S.
    /* !! For the other tests, the contact rate is set to 0 so that the force of infection is zero.
     The forceofinfection initialization method is therefore not used for these tests.*/

    mio::ContactMatrixGroup<ScalarType> contact_matrix = mio::ContactMatrixGroup<ScalarType>(1, num_agegroups);
    contact_matrix[0] =
        mio::ContactMatrix<ScalarType>(Eigen::MatrixX<ScalarType>::Constant(num_agegroups, num_agegroups, 0));

    mio::TimeSeries<ScalarType> init_copy2(init);
    mio::isecir::Model model2(std::move(init_copy2), N, deaths, num_agegroups,
                              mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 0.));

    model2.parameters.get<mio::isecir::ContactPatterns>() = mio::UncertainContactMatrix(contact_matrix);
    model2.populations.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Susceptible] = 5000;
    model2.populations.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Recovered]   = 0;

    // Carry out simulation.
    mio::isecir::Simulation sim2(model2, dt);
    sim2.advance(tmax);

    // Verify that the expected initialization method was used.
    EXPECT_EQ(2, sim2.get_model().get_initialization_method_compartments());

    // --- Case with R.
    mio::TimeSeries<ScalarType> init_copy3(init);
    mio::isecir::Model model3(std::move(init_copy3), N, deaths, num_agegroups,
                              mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 0.));

    model3.parameters.get<mio::isecir::ContactPatterns>() = mio::UncertainContactMatrix(contact_matrix);
    model3.populations.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Susceptible] = 0;
    model3.populations.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Recovered]   = 1000;

    // Carry out simulation.
    mio::isecir::Simulation sim3(model3, dt);
    sim3.advance(tmax);

    // Verify that the expected initialization method was used.
    EXPECT_EQ(3, sim3.get_model().get_initialization_method_compartments());

    // --- Case with forceofinfection.
    mio::TimeSeries<ScalarType> init_copy4(init);
    mio::isecir::Model model4(std::move(init_copy4), N, deaths, num_agegroups,
                              mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 0.));

    // Carry out simulation.
    mio::isecir::Simulation sim4(model4, dt);
    sim4.advance(tmax);

    // Verify that the expected initialization method was used.
    EXPECT_EQ(4, sim4.get_model().get_initialization_method_compartments());

    // --- Case without fitting initialization method.
    // Deactivate temporarily log output for next tests. Errors are expected here.
    mio::set_log_level(mio::LogLevel::off);

    mio::TimeSeries<ScalarType> init_copy5(init);
    mio::isecir::Model model5(std::move(init_copy5), N, deaths, num_agegroups,
                              mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 0.));

    model5.parameters.get<mio::isecir::ContactPatterns>() = mio::UncertainContactMatrix(contact_matrix);
    model5.populations.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Susceptible] = 0;
    model5.populations.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Recovered]   = 0;

    // Carry out simulation.
    mio::isecir::Simulation sim5(model5, dt);
    sim5.advance(tmax);

    // Verify that initialization was not possible with one of the models methods.
    EXPECT_EQ(-1, sim5.get_model().get_initialization_method_compartments());

    // --- Test with negative number of deaths.
    deaths[mio::AgeGroup(0)] = -10;

    // Here we do not need a copy of init as this is the last use of the vector. We can apply move directly.
    mio::isecir::Model model6(std::move(init), N, deaths, num_agegroups,
                              mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 0.));

    model6.parameters.get<mio::isecir::ContactPatterns>() = mio::UncertainContactMatrix(contact_matrix);
    model6.populations.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Susceptible] = 0;
    model6.populations.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Recovered]   = 0;

    // Carry out simulation.
    mio::isecir::Simulation sim6(model6, dt);
    sim6.advance(tmax);

    // Verify that initialization was possible but the result is not appropriate.
    EXPECT_EQ(-2, sim6.get_model().get_initialization_method_compartments());

    // Reactive log output.
    mio::set_log_level(mio::LogLevel::warn);
}

TEST(IdeSecir, deathsPerSevere_flows)
{
    // Test that DeathsPerSevere causes ISev->Dead flow independent of ICU.
    // If the probability of going from InfectedSevere to InfectedCritical is zero, it blocks the ISev->ICr->Dead path
    // entirely, so the probability of transitioning from InfectedCritical to Dead has no influence and is left at its
    // default values.
    using Vec = mio::TimeSeries<ScalarType>::Vector;

    ScalarType t0 = 0., tmax = 10., dt = 0.1;

    size_t num_agegroups = 1;
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> N =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10000.);
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> deaths =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 0.);

    // Create TimeSeries with num_transitions elements where transitions needed for simulation will be stored.
    size_t num_transitions = (size_t)mio::isecir::InfectionTransition::Count;
    mio::TimeSeries<ScalarType> init(num_transitions * num_agegroups);
    // Add initial time point to time series, start with transitions only from InfectedSymptoms to InfectedSevere.
    Vec vec_init = Vec::Zero(num_transitions);
    init.add_time_point(-10, vec_init);
    // Add further time points until time t0.
    while (init.get_last_time() < t0 - dt) {
        init.add_time_point(init.get_last_time() + dt, vec_init);
    }
    vec_init[(Eigen::Index)mio::isecir::InfectionTransition::InfectedNoSymptomsToInfectedSymptoms] = 1000.;
    init.add_time_point(init.get_last_time() + dt, vec_init);

    mio::isecir::Model model(std::move(init), N, deaths, num_agegroups);

    // Set Susceptibles at t0.
    model.populations[0][(size_t)mio::isecir::InfectionState::Susceptible] = 9000;

    // Block ISev->ICr->Dead path.
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][Eigen::Index(
        mio::isecir::InfectionTransition::InfectedSevereToInfectedCritical)] = 0.;
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][Eigen::Index(
        mio::isecir::InfectionTransition::InfectedCriticalToDead)]           = 0.;
    // Set nonzero probability for InfectedSevereToDead.
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][Eigen::Index(
        mio::isecir::InfectionTransition::InfectedSevereToDead)] = 0.1;
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][Eigen::Index(
        mio::isecir::InfectionTransition::InfectedSevereToRecovered)] =
        1. - model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][Eigen::Index(
                 mio::isecir::InfectionTransition::InfectedSevereToDead)];

    // Simulate a small time step.
    mio::isecir::Simulation sim(model, dt);
    sim.advance(tmax);
    auto result = sim.get_result();

    // With prob(InfectedSevereToDead)=0.1, deaths from ISev must be larger than initial value.
    auto dead         = result.get_last_value()[(size_t)mio::isecir::InfectionState::Dead];
    auto dead_initial = result.get_value(0)[(size_t)mio::isecir::InfectionState::Dead];
    EXPECT_GT(dead, dead_initial);

    // Now run again with prob(InfectedSevereToDead)=0
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][Eigen::Index(
        mio::isecir::InfectionTransition::InfectedSevereToDead)] = 0.;
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][Eigen::Index(
        mio::isecir::InfectionTransition::InfectedSevereToRecovered)] =
        1. - model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][Eigen::Index(
                 mio::isecir::InfectionTransition::InfectedSevereToDead)];

    mio::isecir::Simulation sim_no_severe_deaths(model, dt);
    sim_no_severe_deaths.advance(tmax);
    auto result_no_severe_deaths = sim_no_severe_deaths.get_result();
    auto dead_no_severe_deaths   = result_no_severe_deaths.get_last_value()[(size_t)mio::isecir::InfectionState::Dead];

    // With prob(InfectedSevereToDead)=0 there should be no deaths from ISev, so Dead compartment should be equal to
    // initial value.
    auto dead_no_severe_deaths_initial =
        result_no_severe_deaths.get_value(0)[(size_t)mio::isecir::InfectionState::Dead];
    EXPECT_DOUBLE_EQ(dead_no_severe_deaths, dead_no_severe_deaths_initial);

    // Population must be conserved and equal in both runs; compare with initial population of first run, respectively.
    auto total                  = result.get_last_value().sum();
    auto total_initial          = result.get_value(0).sum();
    auto total_no_severe_deaths = result_no_severe_deaths.get_last_value().sum();
    EXPECT_NEAR(total, total_initial, 1e-10);
    EXPECT_NEAR(total_no_severe_deaths, total_initial, 1e-10);

    // Recovery flow during simulation must be higher when prob(InfectedSevereToDead)=0.
    auto rec         = result.get_last_value()[(size_t)mio::isecir::InfectionState::Recovered];
    auto rec_initial = result.get_value(0)[(size_t)mio::isecir::InfectionState::Recovered];
    auto rec_no_severe_deaths =
        result_no_severe_deaths.get_last_value()[(size_t)mio::isecir::InfectionState::Recovered];
    auto rec_no_severe_deaths_initial =
        result_no_severe_deaths.get_value(0)[(size_t)mio::isecir::InfectionState::Recovered];
    EXPECT_GT(rec_no_severe_deaths - rec_no_severe_deaths_initial, rec - rec_initial);
    mio::set_log_level(mio::LogLevel::off);
}

// a) Test if the function check_constraints() of the class Model correctly reports errors in the model constraints.
// b) Test if check_constraints() does not complain if the conditions are met.
TEST(IdeSecir, testModelConstraints)
{
    using Vec = mio::TimeSeries<ScalarType>::Vector;
    // Deactivate temporarily log output for next tests.
    mio::set_log_level(mio::LogLevel::off);

    // Set wrong initial data and use check_constraints().
    // Follow the same order as in check_constraints().

    // --- Test with wrong size of the initial value vector for the transitions.
    size_t num_agegroups = 1;
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> N =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10000.);
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> deaths =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10.);
    ScalarType dt = 1;

    int num_transitions  = (int)mio::isecir::InfectionTransition::Count;
    int num_compartments = (int)mio::isecir::InfectionState::Count;

    // Create TimeSeries of the wrong size.
    mio::TimeSeries<ScalarType> init_wrong_size(num_transitions + 1);
    // Add time points with vectors of the wrong size.
    Vec vec_init_wrong_size = Vec::Constant(num_transitions + 1, 0.);
    vec_init_wrong_size[(int)mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms] = 10.0;
    init_wrong_size.add_time_point(-3, vec_init_wrong_size);
    while (init_wrong_size.get_last_time() < 0) {
        init_wrong_size.add_time_point(init_wrong_size.get_last_time() + dt, vec_init_wrong_size);
    }

    // Initialize a model.
    mio::isecir::Model model_wrong_size(std::move(init_wrong_size), N, deaths, num_agegroups);

    auto constraint_check = model_wrong_size.check_constraints(dt);
    EXPECT_TRUE(constraint_check);

    // --- Test with negative number of deaths.
    // Create TimeSeries with num_transitions elements.
    mio::TimeSeries<ScalarType> init(num_transitions);
    // Add time points for initialization of transitions.
    Vec vec_init                                                                 = Vec::Constant(num_transitions, 0.);
    vec_init[(int)mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms] = 10.0;
    init.add_time_point(-3, vec_init);
    while (init.get_last_time() < 0) {
        init.add_time_point(init.get_last_time() + dt, vec_init);
    }

    deaths[mio::AgeGroup(0)] = -10;

    // Initialize a model.
    mio::isecir::Model model_negative_deaths(std::move(init), N, deaths, num_agegroups);

    // Return true for negative entry in populations.
    constraint_check = model_negative_deaths.check_constraints(dt);
    EXPECT_TRUE(constraint_check);

    // --- Test with too few time points.
    // Create TimeSeries with num_transitions elements.
    mio::TimeSeries<ScalarType> init_few_timepoints(num_transitions);
    // Add time points for initialization of transitions.
    init_few_timepoints.add_time_point(-3, vec_init);
    while (init_few_timepoints.get_last_time() < 0) {
        init_few_timepoints.add_time_point(init_few_timepoints.get_last_time() + dt, vec_init);
    }
    deaths[mio::AgeGroup(0)] = 10;

    // Initialize a model.
    mio::isecir::Model model(std::move(init_few_timepoints), N, deaths, num_agegroups);

    mio::ExponentialSurvivalFunction exponential(4.0);
    mio::StateAgeFunctionWrapper<ScalarType> delaydistribution(exponential);
    std::vector<mio::StateAgeFunctionWrapper<ScalarType>> vec_delaydistrib(num_transitions, delaydistribution);
    model.parameters.set<mio::isecir::TransitionDistributions>(vec_delaydistrib);

    // Return true for not enough time points given for the initial transitions.
    constraint_check = model.check_constraints(dt);
    EXPECT_TRUE(constraint_check);

    // --- Test with negative transitions.
    // Create TimeSeries with num_transitions elements.
    mio::TimeSeries<ScalarType> init_negative_transitions(num_transitions);
    // Add time points for initialization of transitions.
    init_negative_transitions.add_time_point(-3, vec_init);
    while (init_negative_transitions.get_last_time() < 0) {
        init_negative_transitions.add_time_point(init_negative_transitions.get_last_time() + dt, (-1) * vec_init);
    }

    // Initialize a model.
    mio::isecir::Model model_negative_transitions(std::move(init_negative_transitions), N, deaths, num_agegroups);

    // Return true for negative entries in the initial transitions.
    constraint_check = model_negative_transitions.check_constraints(dt);
    EXPECT_TRUE(constraint_check);

    // --- Test with last time point of transitions not matching last time point of populations.
    // Create TimeSeries with num_transitions elements.
    mio::TimeSeries<ScalarType> init_different_last_time(num_transitions);
    // Add enough time points for initialization of transitions but with different last time point
    // than before so that it does not match last time point of populations (that was set in
    // when constructing model above).
    init_different_last_time.add_time_point(-4, vec_init);
    while (init_different_last_time.get_last_time() < 1) {
        init_different_last_time.add_time_point(init_different_last_time.get_last_time() + dt, vec_init);
    }

    model.transitions = init_different_last_time;

    // Return true for not last time points of compartments and transitions not matching.
    constraint_check = model.check_constraints(dt);
    EXPECT_TRUE(constraint_check);

    // --- Test with TimeSeries for populations that contains more than one time point.
    // Create TimeSeries with num_compartments elements.
    mio::TimeSeries<ScalarType> populations_many_timepoints(num_compartments);
    // Add time points.
    Vec vec_populations = Vec::Constant(num_compartments, 0.);
    populations_many_timepoints.add_time_point(0, vec_populations);
    while (populations_many_timepoints.get_last_time() < 1) {
        populations_many_timepoints.add_time_point(populations_many_timepoints.get_last_time() + dt, vec_populations);
    }

    model.populations = populations_many_timepoints;

    // Return true for too many time points given for populations.
    constraint_check = model.check_constraints(dt);
    EXPECT_TRUE(constraint_check);

    // --- Test with wrong size of total_confirmed_cases.
    // Create TimeSeries with num_compartments elements.
    mio::TimeSeries<ScalarType> correct_populations(num_compartments);
    // Add one time point.
    correct_populations.add_time_point(1, vec_populations);

    model.populations = correct_populations;

    // Create total_confirmed_cases with wrong size regarding the number of age groups.
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> total_confirmed_cases_wrong_size =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups + 1), 100.);

    model.total_confirmed_cases = total_confirmed_cases_wrong_size;

    constraint_check = model.check_constraints(dt);
    EXPECT_TRUE(constraint_check);

    // --- Test with negative value in total_confirmed_cases.
    // Create total_confirmed_cases with wrong size regarding the number of age groups.
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> total_confirmed_cases_negative =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), -100.);

    model.total_confirmed_cases = total_confirmed_cases_negative;

    constraint_check = model.check_constraints(dt);
    EXPECT_TRUE(constraint_check);

    // --- Correct wrong setup so that next check can go through.
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> correct_total_confirmed_cases =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 100.);

    model.total_confirmed_cases = correct_total_confirmed_cases;

    constraint_check = model.check_constraints(dt);
    EXPECT_FALSE(constraint_check);

    // --- The check_constraints() function of parameters is tested in its own test below. ---

    // Reactive log output.
    mio::set_log_level(mio::LogLevel::warn);
}

// a) Test if check_constraints() function of Parameters correctly reports wrongly set parameters.
// b) Test if check_constraints() function of Parameters does not complain if parameters are set within correct ranges.
TEST(IdeSecir, testParametersConstraints)
{
    size_t num_agegroups = 1;
    // Create an object from the class Parameters.
    mio::isecir::Parameters parameters(num_agegroups);

    // Deactivate temporarily log output for next tests as warnings are expected.
    mio::set_log_level(mio::LogLevel::off);

    // Set wrong parameters and test if check_constraints() reports them correctly.
    // Test in the same order as in check_constraints().
    // Create invalid and valid function.
    mio::ConstantFunction<ScalarType> constant_func_neg(-1);
    mio::StateAgeFunctionWrapper<ScalarType> prob_neg(constant_func_neg);
    mio::ConstantFunction<ScalarType> constant_func_pos(1);
    mio::StateAgeFunctionWrapper<ScalarType> prob_pos(constant_func_pos);

    // Warn, i.e., return true for wrong TransmissionProbabilityOnContact.
    parameters.get<mio::isecir::TransmissionProbabilityOnContact>()[mio::AgeGroup(0)] = prob_neg;
    auto constraint_check                                                             = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Correct wrong parameter so that next check can go through.
    parameters.get<mio::isecir::TransmissionProbabilityOnContact>()[mio::AgeGroup(0)] = prob_pos;
    // Warn, i.e., return true for wrong RelativeTransmissionNoSymptoms.
    parameters.get<mio::isecir::RelativeTransmissionNoSymptoms>()[mio::AgeGroup(0)] = prob_neg;
    constraint_check                                                                = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Correct wrong parameter so that next check can go through.
    parameters.get<mio::isecir::RelativeTransmissionNoSymptoms>()[mio::AgeGroup(0)] = prob_pos;
    // Warn, i.e., return true for wrong RiskOfInfectionFromSymptomatic.
    parameters.get<mio::isecir::RiskOfInfectionFromSymptomatic>()[mio::AgeGroup(0)] = prob_neg;
    constraint_check                                                                = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Correct wrong parameter so that next check can go through.
    parameters.get<mio::isecir::RiskOfInfectionFromSymptomatic>()[mio::AgeGroup(0)] = prob_pos;

    // Set wrong values for InfectionTransitions.
    std::vector<ScalarType> vec_prob((int)mio::isecir::InfectionTransition::Count, 1);
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::SusceptibleToExposed)]          = 0.2;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedNoSymptomsToRecovered)] = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSymptomsToRecovered)]   = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSevereToDead)]          = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSevereToRecovered)]     = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedCriticalToRecovered)]   = 0.4;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedCriticalToDead)]        = -0.6;
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)]                = vec_prob;

    // Negative probability for InfectedCriticalToDead.
    constraint_check = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Check if SusceptibleToExposed is not equal to 1.
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedCriticalToDead] = 0.6;
    constraint_check                                                  = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Check if ExposedToInfectedNoSymptoms is not equal to 1.
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::SusceptibleToExposed]        = 1.0;
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms] = 0.6;
    constraint_check                                                       = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Check sum InfectedNoSymptomsToInfectedSymptoms + InfectedNoSymptomsToRecovered.
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms]   = 1.0;
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedNoSymptomsToRecovered] = 0.9;
    constraint_check                                                         = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Check sum InfectedSymptomsToInfectedSevere + InfectedSymptomsToRecovered.
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedNoSymptomsToRecovered]    = 0.0;
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedSymptomsToInfectedSevere] = 0.2;
    constraint_check                                                            = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Check sum InfectedSevereToInfectedCritical + InfectedSevereToDead + InfectedSevereToRecovered.
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedSymptomsToInfectedSevere] = 1.0;
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedSevereToDead]             = 0.2;
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedSevereToRecovered]        = 0.4;
    constraint_check                                                            = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Check sum InfectedCriticalToDead + InfectedCriticalToRecovered.
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedSevereToDead]      = 0.0;
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedSevereToRecovered] = 0.0;
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedCriticalToDead]    = 0.59;
    constraint_check                                                     = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Set wrong function type with unlimited support.
    parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)][(
        int)mio::isecir::InfectionTransition::InfectedCriticalToDead] = 0.6;
    mio::ConstantFunction const_func(1.0);
    mio::StateAgeFunctionWrapper<ScalarType> delaydistribution(const_func);
    std::vector<mio::StateAgeFunctionWrapper<ScalarType>> vec_delaydistrib((int)mio::isecir::InfectionTransition::Count,
                                                                           delaydistribution);
    parameters.get<mio::isecir::TransitionDistributions>()[mio::AgeGroup(0)] = vec_delaydistrib;
    constraint_check                                                         = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Check wrong value for Seasonality.
    mio::ExponentialSurvivalFunction exponential(4.0);
    mio::StateAgeFunctionWrapper<ScalarType> delaydistribution2(exponential);
    std::vector<mio::StateAgeFunctionWrapper<ScalarType>> vec_delaydistrib2(
        (int)mio::isecir::InfectionTransition::Count, delaydistribution2);
    parameters.get<mio::isecir::TransitionDistributions>()[mio::AgeGroup(0)] = vec_delaydistrib2;
    parameters.set<mio::isecir::Seasonality>(2.);
    constraint_check = parameters.check_constraints();
    EXPECT_TRUE(constraint_check);

    // Check if all parameter are correct.
    parameters.set<mio::isecir::Seasonality>(0.1);
    constraint_check = parameters.check_constraints();
    EXPECT_FALSE(constraint_check);

    // Reactive log output.
    mio::set_log_level(mio::LogLevel::warn);
}

// The idea of this test is to check whether the proportion between Recovered and Dead is as expected
// (after simulation for a long enough time, i.e. when the equlibrium is reached).
TEST(IdeSecir, checkProportionRecoveredDeath)
{
    using Vec = mio::TimeSeries<ScalarType>::Vector;

    size_t num_agegroups = 1;

    ScalarType tmax = 30;
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> N =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10000.);
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> deaths =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10.);
    ScalarType dt = 1;

    int num_transitions = (int)mio::isecir::InfectionTransition::Count;

    // Create TimeSeries with num_transitions elements where transitions needed for simulation will be stored.
    mio::TimeSeries<ScalarType> init(num_transitions * num_agegroups);

    // Add time points for initialization for transitions.
    Vec vec_init = Vec::Constant(num_transitions * num_agegroups, 0.);
    vec_init[(int)mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms]      = 10.0;
    vec_init[(int)mio::isecir::InfectionTransition::InfectedSymptomsToInfectedSevere] = 10.0;
    // Add initial time point to TimeSeries.
    init.add_time_point(-12, vec_init);
    while (init.get_last_time() < 0) {
        init.add_time_point(init.get_last_time() + dt, vec_init);
    }

    // Initialize model.
    mio::isecir::Model model(std::move(init), N, deaths, num_agegroups);

    // Set working parameters.
    // All TransitionDistribution%s are ExponentialSurvivalFunction functions.
    // For all TransitionDistribution%s init_parameter=2 is used except for InfectedCriticalToRecovered
    // where init_parameter=3 is used.
    mio::ExponentialSurvivalFunction exponential(4.0);
    mio::StateAgeFunctionWrapper<ScalarType> delaydistribution(exponential);
    std::vector<mio::StateAgeFunctionWrapper<ScalarType>> vec_delaydistrib(num_transitions, delaydistribution);
    vec_delaydistrib[(int)mio::isecir::InfectionTransition::InfectedCriticalToRecovered].set_distribution_parameter(
        3.0);
    model.parameters.get<mio::isecir::TransitionDistributions>()[mio::AgeGroup(0)] = (vec_delaydistrib);

    // Set probabilities so that all individuals go from Susceptible to InfectedCritical with probability 1,
    // from there they move to Recovered or Dead with probability 0.4 and 0.6, respectively.
    std::vector<ScalarType> vec_prob((int)mio::isecir::InfectionTransition::Count, 1);
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedNoSymptomsToRecovered)] = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSymptomsToRecovered)]   = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSevereToDead)]          = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSevereToRecovered)]     = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedCriticalToRecovered)]   = 0.4;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedCriticalToDead)]        = 0.6;
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)]          = vec_prob;

    mio::ContactMatrixGroup<ScalarType> contact_matrix = mio::ContactMatrixGroup<ScalarType>(1, num_agegroups);
    contact_matrix[0] =
        mio::ContactMatrix<ScalarType>(Eigen::MatrixX<ScalarType>::Constant(num_agegroups, num_agegroups, 1.));
    model.parameters.get<mio::isecir::ContactPatterns>() = mio::UncertainContactMatrix(contact_matrix);

    mio::ExponentialSurvivalFunction exponential2(0.5);
    mio::StateAgeFunctionWrapper<ScalarType> prob(exponential2);
    model.parameters.get<mio::isecir::TransmissionProbabilityOnContact>()[mio::AgeGroup(0)] = prob;
    model.parameters.get<mio::isecir::RelativeTransmissionNoSymptoms>()[mio::AgeGroup(0)]   = prob;
    model.parameters.get<mio::isecir::RiskOfInfectionFromSymptomatic>()[mio::AgeGroup(0)]   = prob;

    // Carry out simulation.
    mio::isecir::Simulation sim(model, dt);
    sim.advance(tmax);
    mio::TimeSeries<ScalarType> secihurd_simulated = sim.get_result();

    // Check whether equilibrium has been reached, only then the right proportion
    // between Recovered and Dead is expected.
    EXPECT_TRUE(secihurd_simulated[Eigen::Index(tmax / dt - 1)] == secihurd_simulated[Eigen::Index(tmax / dt - 2)]);

    // Check if the compartments E, C, I, H and U are almost empty at the equilibrium.
    EXPECT_NEAR(secihurd_simulated.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Exposed], 0, 1e-18);
    EXPECT_NEAR(secihurd_simulated.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::InfectedNoSymptoms], 0,
                1e-8);
    EXPECT_NEAR(secihurd_simulated.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::InfectedSymptoms], 0,
                1e-8);
    EXPECT_NEAR(secihurd_simulated.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::InfectedSevere], 0,
                1e-8);
    EXPECT_NEAR(secihurd_simulated.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::InfectedCritical], 0,
                1e-8);

    // Check whether equilibrium has the right proportion between Recovered and Dead.
    EXPECT_NEAR((vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedCriticalToDead)] /
                 vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedCriticalToRecovered)]) *
                    (secihurd_simulated.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Recovered] -
                     secihurd_simulated[0][(Eigen::Index)mio::isecir::InfectionState::Recovered]),
                secihurd_simulated.get_last_value()[(Eigen::Index)mio::isecir::InfectionState::Dead] -
                    secihurd_simulated[0][(Eigen::Index)mio::isecir::InfectionState::Dead],
                1e-8);
}

// The idea of this test is to confirm that the equilibrium of the compartments
// (after simulation for a long enough time) does not change if a different TransitionDistribution is used
// for the transition from InfectedCritical To Recovered.
// It is also checked whether the equilibirum is reached at an earlier time if m_support_max is chosen smaller.
TEST(IdeSecir, compareEquilibria)
{
    using Vec = mio::TimeSeries<ScalarType>::Vector;

    size_t num_agegroups = 1;

    ScalarType tmax = 20;
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> N =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10000.);
    mio::CustomIndexArray<ScalarType, mio::AgeGroup> deaths =
        mio::CustomIndexArray<ScalarType, mio::AgeGroup>(mio::AgeGroup(num_agegroups), 10.);
    ScalarType dt = 1;

    int num_transitions = (int)mio::isecir::InfectionTransition::Count;

    // Create TimeSeries with num_transitions elements where transitions needed for simulation will be stored.
    mio::TimeSeries<ScalarType> init(num_transitions);

    // Add time points for initialization for transitions.
    Vec vec_init = Vec::Constant(num_transitions * num_agegroups, 0.);
    vec_init[(int)mio::isecir::InfectionTransition::ExposedToInfectedNoSymptoms]      = 10.0;
    vec_init[(int)mio::isecir::InfectionTransition::InfectedSymptomsToInfectedSevere] = 10.0;
    // Add initial time point to TimeSeries.
    init.add_time_point(-12, vec_init);
    while (init.get_last_time() < 0) {
        init.add_time_point(init.get_last_time() + dt, vec_init);
    }

    mio::TimeSeries<ScalarType> init2(init);

    // Initialize two models.
    mio::isecir::Model model(std::move(init), N, deaths, num_agegroups);
    mio::isecir::Model model2(std::move(init2), N, deaths, num_agegroups);

    // Set working parameters.
    // Here the maximum support for the TransitionDistribution%s is set differently for each model
    // In both models, all TransitionDistribution%s are SmootherCosine.

    // For the Model model.
    // All TransitionDistribution%s have parameter=2.
    mio::SmootherCosine<ScalarType> smoothcos(2.0);
    mio::StateAgeFunctionWrapper<ScalarType> delaydistribution(smoothcos);
    std::vector<mio::StateAgeFunctionWrapper<ScalarType>> vec_delaydistrib(num_transitions, delaydistribution);
    model.parameters.get<mio::isecir::TransitionDistributions>()[mio::AgeGroup(0)] = (vec_delaydistrib);

    // For the Model model2.
    // All TransitionDistribution%s have parameter=2 except for InfectedCriticalToRecovered
    // which has parameter=7.
    mio::SmootherCosine<ScalarType> smoothcos2(2.0);
    mio::StateAgeFunctionWrapper<ScalarType> delaydistribution2(smoothcos);
    std::vector<mio::StateAgeFunctionWrapper<ScalarType>> vec_delaydistrib2(num_transitions, delaydistribution2);
    vec_delaydistrib2[(int)mio::isecir::InfectionTransition::InfectedCriticalToRecovered].set_distribution_parameter(
        7.0);
    model2.parameters.get<mio::isecir::TransitionDistributions>()[mio::AgeGroup(0)] = (vec_delaydistrib2);

    // All remaining parameters are equal for both models.
    // Set probabilities so that all individuals go from Susceptible to InfectedCritical with probability 1,
    // from there they move to Recovered or Dead with probability 0.5, respectively.
    std::vector<ScalarType> vec_prob((int)mio::isecir::InfectionTransition::Count, 1);
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedNoSymptomsToRecovered)] = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSymptomsToRecovered)]   = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSevereToDead)]          = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedSevereToRecovered)]     = 0.0;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedCriticalToRecovered)]   = 0.5;
    vec_prob[Eigen::Index(mio::isecir::InfectionTransition::InfectedCriticalToDead)]        = 0.5;
    model.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)]          = vec_prob;
    model2.parameters.get<mio::isecir::TransitionProbabilities>()[mio::AgeGroup(0)]         = vec_prob;

    mio::ContactMatrixGroup<ScalarType> contact_matrix = mio::ContactMatrixGroup<ScalarType>(1, num_agegroups);
    contact_matrix[0] =
        mio::ContactMatrix<ScalarType>(Eigen::MatrixX<ScalarType>::Constant(num_agegroups, num_agegroups, 1.));
    model.parameters.get<mio::isecir::ContactPatterns>()  = mio::UncertainContactMatrix(contact_matrix);
    model2.parameters.get<mio::isecir::ContactPatterns>() = mio::UncertainContactMatrix(contact_matrix);

    mio::ExponentialSurvivalFunction exponential(0.5);
    mio::StateAgeFunctionWrapper<ScalarType> prob(exponential);
    model.parameters.get<mio::isecir::TransmissionProbabilityOnContact>()[mio::AgeGroup(0)] = (prob);
    model.parameters.get<mio::isecir::RelativeTransmissionNoSymptoms>()[mio::AgeGroup(0)]   = (prob);
    model.parameters.get<mio::isecir::RiskOfInfectionFromSymptomatic>()[mio::AgeGroup(0)]   = (prob);

    model2.parameters.get<mio::isecir::TransmissionProbabilityOnContact>()[mio::AgeGroup(0)] = (prob);
    model2.parameters.get<mio::isecir::RelativeTransmissionNoSymptoms>()[mio::AgeGroup(0)]   = (prob);
    model2.parameters.get<mio::isecir::RiskOfInfectionFromSymptomatic>()[mio::AgeGroup(0)]   = (prob);

    // Carry out simulation.
    mio::isecir::Simulation sim(model, dt);
    sim.advance(tmax);
    mio::TimeSeries<ScalarType> secihurd_simulated = sim.get_result();

    mio::isecir::Simulation sim2(model2, dt);
    sim2.advance(tmax);
    mio::TimeSeries<ScalarType> secihurd_simulated2 = sim2.get_result();

    // Check whether equilibrium has been reached, only then it makes sense to compare results and times when
    // equilibrium was reached.
    EXPECT_TRUE(secihurd_simulated[Eigen::Index(tmax / dt - 1)] == secihurd_simulated[Eigen::Index(tmax / dt - 2)]);
    EXPECT_TRUE(secihurd_simulated2[Eigen::Index(tmax / dt - 1)] == secihurd_simulated2[Eigen::Index(tmax / dt - 2)]);

    // Check whether both models have the same result at time tmax.
    for (Eigen::Index i = 0; i < (Eigen::Index)mio::isecir::InfectionState::Count; i++) {
        EXPECT_NEAR(secihurd_simulated.get_last_value()[i], secihurd_simulated2.get_last_value()[i], 1e-8);
    }

    // Compute at what time the equilibrium was reached and check whether that time point is smaller for model than
    //for model2 (as a smaller maximum support is used in model compared to model2).
    ScalarType equilibrium_time{};
    ScalarType equilibrium_time2{};
    for (int t = 0; t < secihurd_simulated.get_num_time_points() - 1; t++) {
        if (secihurd_simulated[t] == secihurd_simulated[t + 1]) {
            equilibrium_time = t;
            break;
        }
    }
    for (int t = 0; t < secihurd_simulated.get_num_time_points() - 1; t++) {
        if (secihurd_simulated2[t] == secihurd_simulated2[t + 1]) {
            equilibrium_time2 = t;
            break;
        }
    }

    EXPECT_TRUE(equilibrium_time <= equilibrium_time2);
}