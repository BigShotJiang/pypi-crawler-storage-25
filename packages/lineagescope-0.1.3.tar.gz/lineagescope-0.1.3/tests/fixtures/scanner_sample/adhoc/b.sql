SELECT * FROM raw.events;
