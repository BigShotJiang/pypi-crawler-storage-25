"""
Core module for PubMed Search MCP.

Provides:
- Unified exception hierarchy
- Async utilities for efficient API calls
- Caching utilities
- Type definitions

Python 3.12+ features:
- Type parameter syntax (PEP 695)
- ExceptionGroup support (PEP 654)
- asyncio.TaskGroup (PEP 654)
- @override decorator support
"""

from __future__ import annotations

from .article_identity import canonical_article_key, normalize_article_doi, normalize_article_title
from .async_utils import (
    # Fault tolerance
    CircuitBreaker,
    # Rate limiting
    RateLimiter,
    batch_process,
    # Shared HTTP client
    close_shared_async_client,
    # Parallel execution
    gather_with_errors,
    get_rate_limiter,
    get_shared_async_client,
    # Utilities
    timeout_with_fallback,
)
from .exceptions import (
    # API errors
    APIError,
    # Configuration errors
    ConfigurationError,
    # Data errors
    DataError,
    ErrorCategory,
    ErrorContext,
    ErrorSeverity,
    InvalidParameterError,
    InvalidPMIDError,
    InvalidQueryError,
    NetworkError,
    NotFoundError,
    ParseError,
    # Base
    PubMedSearchError,
    RateLimitError,
    ServiceUnavailableError,
    # Validation errors
    ValidationError,
    # Utilities
    create_error_group,
    get_retry_delay,
    is_retryable_error,
)
from .settings import AppSettings, get_settings, load_settings, reset_settings_cache

__all__ = [
    # Exceptions
    "PubMedSearchError",
    "ErrorContext",
    "ErrorSeverity",
    "ErrorCategory",
    "APIError",
    "RateLimitError",
    "NetworkError",
    "ServiceUnavailableError",
    "ValidationError",
    "InvalidPMIDError",
    "InvalidQueryError",
    "InvalidParameterError",
    "DataError",
    "NotFoundError",
    "ParseError",
    "ConfigurationError",
    "create_error_group",
    "is_retryable_error",
    "get_retry_delay",
    # Async utilities
    "RateLimiter",
    "get_rate_limiter",
    "gather_with_errors",
    "batch_process",
    "CircuitBreaker",
    "get_shared_async_client",
    "close_shared_async_client",
    "timeout_with_fallback",
    "canonical_article_key",
    "normalize_article_doi",
    "normalize_article_title",
    "AppSettings",
    "get_settings",
    "load_settings",
    "reset_settings_cache",
]
