"""
Tool Registry - 集中管理所有 MCP Tool 註冊

此模組提供統一的 tool 註冊介面，方便管理和查詢所有可用工具。

Usage:
    from .tool_registry import register_all_mcp_tools, list_registered_tools

    # 註冊所有工具
    register_all_mcp_tools(mcp, searcher, session_manager, strategy_generator)

    # 查詢已註冊工具
    tools = list_registered_tools()
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import threading
from typing import TYPE_CHECKING, Any

from pubmed_search.shared.settings import load_settings

if TYPE_CHECKING:
    from collections.abc import Awaitable

    from mcp.server.fastmcp import FastMCP

    from pubmed_search.application.session.manager import SessionManager
    from pubmed_search.infrastructure.ncbi import LiteratureSearcher

logger = logging.getLogger(__name__)


async def _await_registered_tools(awaitable: Awaitable[Any]) -> Any:
    """Normalize generic awaitables into a coroutine that asyncio.run can execute."""
    return await awaitable


def _run_awaitable_in_thread(awaitable: Any) -> Any:
    """Run an awaitable to completion from a sync context, even if an event loop is already running."""
    result: dict[str, Any] = {}
    error: dict[str, BaseException] = {}

    def _worker() -> None:
        try:
            result["value"] = asyncio.run(_await_registered_tools(awaitable))
        except BaseException as exc:  # pragma: no cover - defensive transport glue
            error["value"] = exc

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
    thread.join()

    if "value" in error:
        raise error["value"]

    return result.get("value")


def _resolve_awaitable(awaitable: Awaitable[Any]) -> Any:
    """Resolve an awaitable from sync code without leaking un-awaited coroutines."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(_await_registered_tools(awaitable))

    return _run_awaitable_in_thread(awaitable)


def _extract_registered_tool_names(mcp: FastMCP) -> set[str]:
    """Get registered tool names using public APIs when available."""
    list_tools = getattr(mcp, "list_tools", None)
    if callable(list_tools):
        raw_tools = list_tools()
        if inspect.isawaitable(raw_tools):
            try:
                raw_tools = _resolve_awaitable(raw_tools)
            except Exception:
                logger.debug(
                    "FastMCP.list_tools() is awaitable but could not be resolved; falling back to private registry"
                )
                raw_tools = None

        names: set[str] = set()
        if raw_tools is not None:
            for tool in raw_tools:
                if isinstance(tool, str):
                    names.add(tool)
                    continue

                tool_name = getattr(tool, "name", None)
                if isinstance(tool_name, str):
                    names.add(tool_name)
            if names:
                return names

    tool_manager = getattr(mcp, "_tool_manager", None)
    tools = getattr(tool_manager, "_tools", None)
    if tools is not None:
        return set(tools.keys())

    msg = "Cannot access FastMCP tools registry"
    raise AttributeError(msg)


# ============================================================================
# Tool Categories - 工具分類定義
# ============================================================================

TOOL_CATEGORIES: dict[str, dict[str, Any]] = {
    "search": {
        "name": "搜尋工具",
        "description": "文獻搜索入口",
        "tools": [
            "unified_search",
            # Note: search_literature, search_europe_pmc, search_core 已整合到 unified_search
        ],
    },
    "query_intelligence": {
        "name": "查詢智能",
        "description": "MeSH 擴展、PICO 解析",
        "tools": ["parse_pico", "generate_search_queries", "analyze_search_query"],
    },
    "discovery": {
        "name": "文章探索",
        "description": "相關文章、引用網路",
        "tools": [
            "fetch_article_details",
            "find_related_articles",
            "find_citing_articles",
            "get_article_references",
            "get_citation_metrics",
        ],
    },
    "fulltext": {
        "name": "全文工具",
        "description": "全文取得與文本挖掘",
        "tools": ["get_fulltext", "get_text_mined_terms"],
    },
    "figure": {
        "name": "圖表擷取",
        "description": "文章圖表與視覺資料擷取",
        "tools": ["get_article_figures"],
    },
    "ncbi_extended": {
        "name": "NCBI 延伸",
        "description": "Gene, PubChem, ClinVar",
        "tools": [
            "search_gene",
            "get_gene_details",
            "get_gene_literature",
            "search_compound",
            "get_compound_details",
            "get_compound_literature",
            "search_clinvar",
        ],
    },
    "citation_network": {
        "name": "引用網絡",
        "description": "引用樹建構與探索",
        "tools": ["build_citation_tree"],
    },
    "export": {
        "name": "匯出工具",
        "description": "引用格式匯出",
        "tools": ["prepare_export"],
    },
    "session": {
        "name": "Session 管理",
        "description": "PMID 暫存與歷史",
        "tools": [
            "read_session",
            "get_session_pmids",
            "get_cached_article",
            "get_session_summary",
        ],
    },
    "institutional": {
        "name": "機構訂閱",
        "description": "OpenURL Link Resolver",
        "tools": [
            "configure_institutional_access",
            "get_institutional_link",
            "list_resolver_presets",
            "test_institutional_access",
        ],
    },
    "vision": {
        "name": "視覺搜索",
        "description": "圖片分析與搜索 (實驗性)",
        "tools": ["analyze_figure_for_search"],
    },
    "icd": {
        "name": "ICD 轉換",
        "description": "ICD-10 與 MeSH 轉換",
        "tools": ["convert_icd_mesh"],
        # Note: search_by_icd 已廢棄 → unified_search 支援 ICD 自動偵測
    },
    "timeline": {
        "name": "研究時間軸",
        "description": "研究演化追蹤與里程碑偵測",
        "tools": [
            "build_research_timeline",
            "analyze_timeline_milestones",
            "compare_timelines",
        ],
    },
    "image_search": {
        "name": "圖片搜尋",
        "description": "生物醫學圖片搜尋",
        "tools": ["search_biomedical_images"],
    },
    "pipeline": {
        "name": "Pipeline 管理",
        "description": "Pipeline 持久化、載入、排程",
        "tools": [
            "manage_pipeline",
            "save_pipeline",
            "list_pipelines",
            "load_pipeline",
            "delete_pipeline",
            "get_pipeline_history",
            "schedule_pipeline",
        ],
    },
}


# ============================================================================
# Registration Functions - 工具註冊函數
# ============================================================================


def register_all_mcp_tools(
    mcp: FastMCP,
    searcher: LiteratureSearcher,
    session_manager: SessionManager,
    strategy_generator: Any | None = None,
    workspace_dir: str | None = None,
) -> dict[str, int]:
    """
    註冊所有 MCP 工具。

    Args:
        mcp: FastMCP server instance
        searcher: LiteratureSearcher instance
        session_manager: SessionManager instance
        strategy_generator: Optional strategy generator
        workspace_dir: Explicit workspace root for workspace-scoped pipeline persistence.

    Returns:
        Dict with category names and tool counts
    """
    from .resources import register_resources
    from .session_tools import register_session_resources, register_session_tools
    from .tools import register_all_tools, set_session_manager, set_strategy_generator

    # Set global references
    set_session_manager(session_manager)
    if strategy_generator:
        set_strategy_generator(strategy_generator)

    # Initialize PipelineStore
    from pubmed_search.application.pipeline.runner import StoredPipelineRunner
    from pubmed_search.application.pipeline.store import PipelineStore
    from pubmed_search.infrastructure.scheduling import APSPipelineScheduler

    from .tools.pipeline_tools import set_pipeline_scheduler, set_pipeline_store

    data_dir = (
        str(session_manager.data_dir)
        if session_manager.data_dir
        else str(__import__("pathlib").Path.home() / ".pubmed-search-mcp")
    )

    settings = load_settings()
    configured_workspace_dir = getattr(settings, "workspace_dir", None)
    effective_workspace_dir = workspace_dir or (
        str(configured_workspace_dir).strip() if configured_workspace_dir else None
    )

    pipeline_store = PipelineStore(
        global_data_dir=data_dir,
        workspace_dir=effective_workspace_dir,
    )
    set_pipeline_store(pipeline_store)

    from pubmed_search.infrastructure.sources import search_alternate_source

    pipeline_runner = StoredPipelineRunner(
        store=pipeline_store,
        searcher=searcher,
        alternate_search_fn=search_alternate_source,
    )
    pipeline_scheduler = APSPipelineScheduler(
        store=pipeline_store,
        runner=pipeline_runner,
        settings=settings,
    )
    set_pipeline_scheduler(pipeline_scheduler)

    stats = {}

    # 1. Core search tools (from tools/__init__.py)
    logger.info("Registering search tools...")
    register_all_tools(mcp, searcher)
    core_tool_count = len(_extract_registered_tool_names(mcp))
    stats["search_and_discovery"] = core_tool_count

    # 2. Session tools
    logger.info("Registering session tools...")
    register_session_tools(mcp, session_manager)
    session_tool_count = len(_extract_registered_tool_names(mcp)) - core_tool_count
    register_session_resources(mcp, session_manager)
    stats["session"] = session_tool_count

    # 3. Resources (filter docs, etc.)
    logger.info("Registering resources...")
    register_resources(mcp)
    # Note: ICD tools are now registered via register_all_tools -> tools/icd.py

    # 4. Prompts
    logger.info("Registering research prompts...")
    from .prompts import register_prompts

    register_prompts(mcp)
    stats["prompts"] = 9  # Approximate

    total = sum(stats.values())
    logger.info(f"Total registered: {total} tools/prompts/resources")

    return stats


def list_registered_tools() -> dict[str, list[str]]:
    """
    列出所有已定義的工具，按類別分組。

    Returns:
        Dict with category names as keys and tool lists as values
    """
    return {cat_id: cat_info["tools"] for cat_id, cat_info in TOOL_CATEGORIES.items()}


def get_tool_info(tool_name: str) -> dict[str, str] | None:
    """
    取得特定工具的資訊。

    Args:
        tool_name: 工具名稱

    Returns:
        Dict with category, description, or None if not found
    """
    for cat_id, cat_info in TOOL_CATEGORIES.items():
        if tool_name in cat_info["tools"]:
            return {
                "name": tool_name,
                "category": cat_info["name"],
                "category_id": cat_id,
                "category_description": cat_info["description"],
            }
    return None


def get_tools_by_category(category_id: str) -> list[str]:
    """
    取得特定類別的所有工具。

    Args:
        category_id: 類別 ID (e.g., "search", "discovery")

    Returns:
        List of tool names, or empty list if category not found
    """
    if category_id in TOOL_CATEGORIES:
        return TOOL_CATEGORIES[category_id]["tools"]
    return []


def _render_markdown_table(headers: list[str], rows: list[list[str]]) -> list[str]:
    """Render a compact markdown table for generated docs."""
    rendered = [
        "| " + " | ".join(headers) + " |",
        "|" + "|".join("-" * max(len(header) + 2, 6) for header in headers) + "|",
    ]
    for row in rows:
        rendered.append("| " + " | ".join(row) + " |")
    return rendered


def generate_tools_index_markdown() -> str:
    """
    產生工具索引的 Markdown 文檔。

    Returns:
        Markdown formatted string
    """
    lines = [
        "# PubMed Search MCP - Tools Index",
        "",
        "Quick reference for all available MCP tools.",
        "",
        "---",
        "",
    ]

    for cat_info in TOOL_CATEGORIES.values():
        lines.extend([f"## {cat_info['name']}", "", cat_info["description"], ""])
        rows: list[list[str]] = []
        for tool in cat_info["tools"]:
            # 簡短描述 (可以後續從 docstring 提取)
            rows.append([f"`{tool}`", "-"])
        lines.extend(_render_markdown_table(["Tool", "Description"], rows))
        lines.append("")

    return "\n".join(lines)


# ============================================================================
# Validation Functions - 驗證工具註冊
# ============================================================================


def validate_tool_registry(mcp: FastMCP) -> dict[str, Any]:
    """
    驗證 TOOL_CATEGORIES 與實際註冊的工具是否同步。

    Args:
        mcp: FastMCP server instance (after tools are registered)

    Returns:
        Dict with:
        - defined: Tools in TOOL_CATEGORIES
        - registered: Actually registered tools
        - missing: Defined but not registered
        - extra: Registered but not defined
        - valid: True if fully synchronized
    """
    # Get defined tools from TOOL_CATEGORIES
    defined_tools: set[str] = set()
    for cat_info in TOOL_CATEGORIES.values():
        defined_tools.update(cat_info["tools"])

    try:
        registered_tools = _extract_registered_tool_names(mcp)
    except AttributeError:
        logger.warning("Cannot access registered tools from FastMCP instance")
        return {
            "defined": list(defined_tools),
            "registered": [],
            "missing": [],
            "extra": [],
            "valid": False,
            "error": "Cannot access FastMCP tools registry",
        }

    # Calculate differences
    missing = defined_tools - registered_tools
    extra = registered_tools - defined_tools

    result = {
        "defined": sorted(defined_tools),
        "registered": sorted(registered_tools),
        "missing": sorted(missing),
        "extra": sorted(extra),
        "valid": len(missing) == 0 and len(extra) == 0,
    }

    if missing:
        logger.warning(f"Tools defined but not registered: {missing}")
    if extra:
        logger.info(f"Tools registered but not in TOOL_CATEGORIES: {extra}")

    return result


def check_tool_registration(mcp: FastMCP, raise_on_error: bool = False) -> bool:
    """
    生產環境檢查：驗證所有工具都已正確註冊。

    Args:
        mcp: FastMCP server instance
        raise_on_error: If True, raise exception on validation failure

    Returns:
        True if all tools are properly registered
    """
    result = validate_tool_registry(mcp)

    if not result["valid"]:
        msg = f"Tool registry validation failed. Missing: {result['missing']}, Extra: {result['extra']}"
        if raise_on_error:
            raise RuntimeError(msg)
        logger.error(msg)
        return False

    logger.info(f"Tool registry validated: {len(result['registered'])} tools registered")
    return True


__all__ = [
    "TOOL_CATEGORIES",
    "check_tool_registration",
    "generate_tools_index_markdown",
    "get_tool_info",
    "get_tools_by_category",
    "list_registered_tools",
    "register_all_mcp_tools",
    "validate_tool_registry",
]
