import sys
import os
import re
import struct

BANNER = r"""
╔══════════════════════════════════════════════╗
║                                              ║
║         DECODE FFX  by: trickzqw             ║
║                                              ║
╚══════════════════════════════════════════════╝

  USAGE:
    decode-ffx <BinaryFile> [req|res]

  EXAMPLES:
    decode-ffx LoginGetAccountInfo
    decode-ffx LoginGetAccountInfo req
    decode-ffx LoginGetAccountInfo res

  DESCRIPTION:
    Decodes binary protobuf packets from Free Fire using
    the bundled proto.proto schema.

    <BinaryFile>   Path to the raw binary packet file
    req            Decode as request  (CS<Name>Req)
    res            Decode as response (CS<Name>Res)  [default]
"""

PROTO_FILE = os.path.join(os.path.dirname(__file__), "proto.proto")


def parse_proto(proto_file):
    with open(proto_file, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    content = re.sub(r"//[^\n]*", "", content)
    content = re.sub(r"/\*.*?\*/", "", content, flags=re.DOTALL)

    messages = {}

    def extract(text):
        pos = 0
        while pos < len(text):
            m = re.search(r"\bmessage\s+(\w+)\s*\{", text[pos:])
            if not m:
                break
            name = m.group(1)
            body_start = pos + m.end()
            depth = 1
            j = body_start
            while j < len(text) and depth > 0:
                if text[j] == "{":
                    depth += 1
                elif text[j] == "}":
                    depth -= 1
                j += 1
            body = text[body_start : j - 1]

            fields = {}
            fp = re.compile(
                r"(?:repeated\s+|optional\s+|required\s+)?"
                r"([\w.]+)\s+(\w+)\s*=\s*(\d+)\s*[;\[{]"
            )
            for fm in fp.finditer(body):
                ftype = fm.group(1)
                fname = fm.group(2)
                fnum = int(fm.group(3))
                if fname not in ("option", "syntax", "package", "import", "reserved"):
                    fields[fnum] = (fname, ftype)
            messages[name] = fields
            extract(body)
            pos = pos + m.end()

    extract(content)
    return messages


def decode_varint(data, pos):
    result = 0
    shift = 0
    while pos < len(data):
        b = data[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result, pos


def looks_like_message(data):
    if len(data) == 0:
        return False
    pos = 0
    count = 0
    try:
        while pos < len(data):
            tag, pos = decode_varint(data, pos)
            wire_type = tag & 0x7
            if wire_type not in (0, 1, 2, 5):
                return False
            if wire_type == 0:
                _, pos = decode_varint(data, pos)
            elif wire_type == 1:
                pos += 8
            elif wire_type == 2:
                length, pos = decode_varint(data, pos)
                if length < 0 or pos + length > len(data):
                    return False
                pos += length
            elif wire_type == 5:
                pos += 4
            count += 1
            if count > 200:
                break
        return pos == len(data) and count > 0
    except Exception:
        return False


def decode_message(data, messages, msg_name, indent=0):
    fields_def = messages.get(msg_name, {})
    pos = 0
    lines = []
    pad = "  " * indent

    while pos < len(data):
        try:
            tag, pos = decode_varint(data, pos)
        except Exception:
            break

        if pos > len(data):
            break

        field_num = tag >> 3
        wire_type = tag & 0x7

        info = fields_def.get(field_num)
        field_name = info[0] if info else f"field_{field_num}"
        field_type = info[1] if info else None

        if wire_type == 0:
            value, pos = decode_varint(data, pos)
            if field_type == "bool":
                lines.append(f"{pad}{field_name}: {str(bool(value)).lower()}")
            elif field_type in ("sint32", "sint64"):
                decoded = (value >> 1) ^ -(value & 1)
                lines.append(f"{pad}{field_name}: {decoded}")
            else:
                lines.append(f"{pad}{field_name}: {value}")

        elif wire_type == 1:
            if pos + 8 > len(data):
                break
            raw = data[pos : pos + 8]
            pos += 8
            if field_type == "double":
                v = struct.unpack("<d", raw)[0]
            elif field_type == "sfixed64":
                v = struct.unpack("<q", raw)[0]
            else:
                v = struct.unpack("<Q", raw)[0]
            lines.append(f"{pad}{field_name}: {v}")

        elif wire_type == 2:
            length, pos = decode_varint(data, pos)
            if pos + length > len(data):
                break
            raw = data[pos : pos + length]
            pos += length

            if field_type and field_type in messages:
                lines.append(f"{pad}{field_name} {{")
                lines.append(decode_message(raw, messages, field_type, indent + 1))
                lines.append(f"{pad}}}")
            elif field_type == "string":
                try:
                    lines.append(f'{pad}{field_name}: "{raw.decode("utf-8")}"')
                except Exception:
                    lines.append(f"{pad}{field_name}: 0x{raw.hex()}")
            elif field_type == "bytes":
                lines.append(f"{pad}{field_name}: 0x{raw.hex()}")
            else:
                try:
                    s = raw.decode("utf-8")
                    lines.append(f'{pad}{field_name}: "{s}"')
                except Exception:
                    if looks_like_message(raw):
                        lines.append(f"{pad}{field_name} {{")
                        lines.append(decode_message(raw, messages, "", indent + 1))
                        lines.append(f"{pad}}}")
                    else:
                        lines.append(f"{pad}{field_name}: 0x{raw.hex()}")

        elif wire_type == 5:
            if pos + 4 > len(data):
                break
            raw = data[pos : pos + 4]
            pos += 4
            if field_type == "float":
                v = struct.unpack("<f", raw)[0]
            elif field_type == "sfixed32":
                v = struct.unpack("<i", raw)[0]
            else:
                v = struct.unpack("<I", raw)[0]
            lines.append(f"{pad}{field_name}: {v}")

        else:
            lines.append(f"{pad}[wire_type={wire_type} field={field_num} — unsupported]")
            break

    return "\n".join(lines)


def resolve_class_name(messages, base_name, mode):
    if mode == "req":
        candidates = [f"CS{base_name}Req", f"{base_name}Req", base_name]
    else:
        candidates = [f"CS{base_name}Res", f"{base_name}Res", base_name]

    for c in candidates:
        if c in messages:
            return c
    return None


def main():
    print(BANNER)

    if len(sys.argv) < 2:
        sys.exit(0)

    base_name = sys.argv[1]
    mode = sys.argv[2].lower() if len(sys.argv) > 2 else "res"

    if mode not in ("req", "res"):
        print(f"[!] Invalid mode: '{mode}'. Use 'req' or 'res'.")
        sys.exit(1)

    if not os.path.exists(base_name):
        print(f"[!] Binary file not found: '{base_name}'")
        sys.exit(1)

    if not os.path.exists(PROTO_FILE):
        print(f"[!] proto.proto not found at: {PROTO_FILE}")
        sys.exit(1)

    print(f"[*] Parsing proto schema...")
    messages = parse_proto(PROTO_FILE)
    print(f"[*] {len(messages)} messages loaded.")

    class_name = resolve_class_name(messages, base_name, mode)
    if class_name is None:
        label = "Req" if mode == "req" else "Res"
        print(f"[!] Message 'CS{base_name}{label}' or '{base_name}{label}' not found in proto.")
        similar = [k for k in messages if base_name.lower() in k.lower()]
        if similar:
            print(f"[?] Similar messages: {similar[:10]}")
        sys.exit(1)

    with open(base_name, "rb") as f:
        raw = f.read()

    print(f"[+] Message : {class_name}")
    print(f"[+] Bytes   : {len(raw)}")
    print("=" * 60)

    result = decode_message(raw, messages, class_name)
    print(result)
