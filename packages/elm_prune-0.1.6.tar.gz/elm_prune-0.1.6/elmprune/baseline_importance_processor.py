from typing import Dict, List, Optional

from tqdm.auto import tqdm
import torch
from torch import nn

from .utils import get_all_conv_layer_names, dump_dict, load_dict
from .importance_processor_config import ImportanceProcessorConfig


class BaselineImportanceProcessor:

    IMPORTANCES_RELATIVE_FOLDER = "importances"
    IMPORTANCES_MAGNITUDE_CACHE_FILENAME = "importances_magnitude.json"
    IMPORTANCES_RANDOM_CACHE_FILENAME = "importances_random.json"

    def __init__(
        self,
        config: ImportanceProcessorConfig,
        model: nn.Module,
        input_example: Optional[torch.Tensor] = None,
    ):
        self.config = config
        self.model = model

        if config.layer_names == "":
            self.layer_names = get_all_conv_layer_names(model)
        elif isinstance(config.layer_names, str):
            self.layer_names = [config.layer_names]
        else:
            self.layer_names = list(config.layer_names)

        self.importances_path = config.abs_path / BaselineImportanceProcessor.IMPORTANCES_RELATIVE_FOLDER
        self.importances_path.mkdir(parents=True, exist_ok=True)

        self.modules_by_name = dict(model.named_modules())

        self.layer_names = self.__filter_valid_conv_layers(self.layer_names)

        if input_example is not None:
            self.layer_names = self.__filter_active_conv_layers(input_example)

        self.has_magnitude_cache, self.has_random_cache = self.__verify_cache()

    def __verify_cache(self):
        has_magnitude_cache = (
            self.importances_path / BaselineImportanceProcessor.IMPORTANCES_MAGNITUDE_CACHE_FILENAME
        ).exists()

        has_random_cache = (
            self.importances_path / BaselineImportanceProcessor.IMPORTANCES_RANDOM_CACHE_FILENAME
        ).exists()

        return has_magnitude_cache, has_random_cache

    def __to_float_list(self, values) -> List[float]:
        if torch.is_tensor(values):
            return values.detach().cpu().float().tolist()

        return [float(v) for v in values]

    def __is_valid_conv_layer(self, layer_name: str) -> bool:
        module = self.modules_by_name.get(layer_name)

        if module is None:
            return False

        if not isinstance(module, nn.Conv2d):
            return False

        if module.weight is None:
            return False

        if module.weight.ndim != 4:
            return False

        return True

    def __filter_valid_conv_layers(self, layer_names: List[str]) -> List[str]:
        valid_layer_names: List[str] = []
        ignored_layer_names: List[str] = []

        for layer_name in layer_names:
            if self.__is_valid_conv_layer(layer_name):
                valid_layer_names.append(layer_name)
            else:
                ignored_layer_names.append(layer_name)

        if len(valid_layer_names) == 0:
            raise RuntimeError(
                "No valid Conv2d layer was found for baseline importance computation. "
                "Check whether config.layer_names is compatible with the current model."
            )

        if len(ignored_layer_names) > 0:
            print(
                "[BaselineImportanceProcessor] Warning: some requested layers are not valid Conv2d "
                "layers and will be ignored:"
            )

            for layer_name in ignored_layer_names:
                print(f"  - {layer_name}")

        return valid_layer_names

    def __filter_active_conv_layers(self, input_example: torch.Tensor) -> List[str]:
        active_layer_names = set()
        hooks = []

        def make_hook(layer_name: str):
            def hook(module, inputs, output):
                active_layer_names.add(layer_name)

            return hook

        for layer_name in self.layer_names:
            module = self.modules_by_name[layer_name]
            hooks.append(module.register_forward_hook(make_hook(layer_name)))

        was_training = self.model.training

        try:
            self.model.eval()

            device = next(self.model.parameters()).device
            input_example = input_example.to(device)

            with torch.no_grad():
                _ = self.model(input_example)

        finally:
            for hook in hooks:
                hook.remove()

            if was_training:
                self.model.train()

        original_layer_names = list(self.layer_names)

        valid_active_layer_names = [
            layer_name
            for layer_name in original_layer_names
            if layer_name in active_layer_names
        ]

        missing_layer_names = [
            layer_name
            for layer_name in original_layer_names
            if layer_name not in active_layer_names
        ]

        if len(valid_active_layer_names) == 0:
            raise RuntimeError(
                "No selected Conv2d layer was activated during the forward pass. "
                "Check whether config.layer_names and input_example are compatible with the current model."
            )

        if len(missing_layer_names) > 0:
            print(
                "[BaselineImportanceProcessor] Warning: some Conv2d layers were not activated "
                "in the forward pass and will be ignored:"
            )

            for layer_name in missing_layer_names:
                print(f"  - {layer_name}")

        return valid_active_layer_names

    def compute_random_importances(self) -> Dict[str, List[float]]:
        print("[BaselineImportanceProcessor] Getting importances for random...")

        if self.config.use_cache and self.has_random_cache:
            print(
                "[BaselineImportanceProcessor] Not necessary to calculate importances here! "
                "Using cache for random importance."
            )

            return load_dict(
                self.importances_path / BaselineImportanceProcessor.IMPORTANCES_RANDOM_CACHE_FILENAME
            )

        result: Dict[str, List[float]] = {}

        generator = torch.Generator(device="cpu")
        generator.manual_seed(int(self.config.seed))

        for layer_name in tqdm(
            self.layer_names,
            desc="Random feature ranking processing",
            dynamic_ncols=True,
            position=1,
            leave=False,
        ):
            conv_layer: nn.Conv2d = self.modules_by_name[layer_name]
            out_channels = conv_layer.out_channels

            importances = torch.randn(out_channels, generator=generator).abs()
            result[layer_name] = self.__to_float_list(importances)

        importances_dump_path = (
            self.importances_path / BaselineImportanceProcessor.IMPORTANCES_RANDOM_CACHE_FILENAME
        )

        dump_dict(result, importances_dump_path)
        self.has_random_cache = True

        return result

    def compute_magnitude_importances(self) -> Dict[str, List[float]]:
        print("[BaselineImportanceProcessor] Getting importances for magnitude...")

        if self.config.use_cache and self.has_magnitude_cache:
            print(
                "[BaselineImportanceProcessor] Not necessary to calculate importances here! "
                "Using cache for magnitude importance."
            )

            return load_dict(
                self.importances_path / BaselineImportanceProcessor.IMPORTANCES_MAGNITUDE_CACHE_FILENAME
            )

        result: Dict[str, List[float]] = {}

        for layer_name in tqdm(
            self.layer_names,
            desc="Magnitude feature ranking processing",
            dynamic_ncols=True,
            position=1,
            leave=False,
        ):
            conv_layer: nn.Conv2d = self.modules_by_name[layer_name]
            weights = conv_layer.weight.detach().cpu().float()

            importances = weights.abs().flatten(start_dim=1).sum(dim=1)
            result[layer_name] = self.__to_float_list(importances)

        importances_dump_path = (
            self.importances_path / BaselineImportanceProcessor.IMPORTANCES_MAGNITUDE_CACHE_FILENAME
        )

        dump_dict(result, importances_dump_path)
        self.has_magnitude_cache = True

        return result