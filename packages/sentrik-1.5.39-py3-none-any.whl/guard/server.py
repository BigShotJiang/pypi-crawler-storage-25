"""FastAPI REST API server for Sentrik (AI SDLC Guard)."""

from __future__ import annotations

import hmac
import json
import logging
import os
import secrets
import tempfile
import threading
from urllib.parse import quote
from pathlib import Path
from typing import Any, Optional

import queue
import threading

from fastapi import Cookie, Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from pydantic import BaseModel, Field, field_validator

from guard.config import GuardConfig, VALID_PROVIDERS, VALID_REPORTERS, VALID_LLM_PROVIDERS, VALID_DEVOPS_PROVIDERS
from guard.core.comparison import load_findings
from guard.core.governance import AuditConfig, AuditLog, GovernanceConfig, VALID_PROFILES
from guard.core.models import Finding, GateResult, Severity, WorkItem
from guard.core.pipeline import evaluate_gate, run_scan_and_write
from guard.packs.registry import (
    delete_custom_pack,
    export_pack as registry_export_pack,
    import_pack as registry_import_pack,
    is_known_pack,
    list_available_packs,
    load_pack_rules as registry_load_pack_rules,
    validate_pack_yaml,
)
from guard.core.reconciler import reconcile as compute_reconcile_actions, execute_reconcile
from guard.providers.factory import build_devops, build_providers
from guard.reporters.factory import build_reporters, get_reporter
from guard.auth.models import AuthConfig, UserContext

_logger = logging.getLogger(__name__)

# If a project directory was specified via CLI --dir, chdir to it on module load
_project_dir = os.environ.get("SENTRIK_PROJECT_DIR")
if _project_dir:
    os.chdir(_project_dir)

app = FastAPI(
    title="SENTRIK API",
    description="REST API for scanning code, enforcing gates, and generating reports.",
    version="1.0.0",
)

# CORS — allow dashboard and external integrations
from starlette.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Rate limiting middleware (sliding window per client IP)
# ---------------------------------------------------------------------------

_RATE_LIMIT_ENABLED = os.environ.get("GUARD_RATE_LIMIT_ENABLED", "true").lower() in ("true", "1")
_RATE_LIMIT_RPM = int(os.environ.get("GUARD_RATE_LIMIT_RPM", "60"))  # requests per minute
_rate_limit_store: dict[str, list[float]] = {}
_rate_limit_lock = threading.Lock()

import time as _time


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    """Enforce per-IP rate limiting on API endpoints."""
    if not _RATE_LIMIT_ENABLED:
        return await call_next(request)

    # Only rate-limit /api/ endpoints, not static dashboard
    if not request.url.path.startswith("/api/"):
        return await call_next(request)

    client_ip = request.client.host if request.client else "unknown"
    now = _time.time()
    window = 60.0  # 1 minute

    with _rate_limit_lock:
        hits = _rate_limit_store.get(client_ip, [])
        hits = [t for t in hits if now - t < window]
        if len(hits) >= _RATE_LIMIT_RPM:
            from starlette.responses import JSONResponse
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded. Try again later."},
                headers={"Retry-After": str(int(window - (now - hits[0])))},
            )
        hits.append(now)
        _rate_limit_store[client_ip] = hits
    return await call_next(request)


# ---------------------------------------------------------------------------
# Auth dependency (dual-mode: JWT + API key, backward compatible)
# ---------------------------------------------------------------------------

_API_KEY = os.environ.get("GUARD_API_KEY")
_AUTH0_CLIENT_SECRET = os.environ.get("GUARD_AUTH0_CLIENT_SECRET", "")
_SESSION_SECRET = os.environ.get("GUARD_SESSION_SECRET", "")

# Lazy-initialised singletons (created on first request)
_jwt_handler = None
_oidc_client = None
_session_manager = None


def _get_auth_config() -> AuthConfig:
    """Load auth configuration."""
    config = _load_config()
    return config.get_auth_config()


_jwt_handler_lock = threading.Lock()


def _get_jwt_handler():
    """Get or create the JWT handler singleton (thread-safe)."""
    global _jwt_handler
    if _jwt_handler is None:
        with _jwt_handler_lock:
            if _jwt_handler is None:  # double-checked locking
                auth_config = _get_auth_config()
                if auth_config.enabled and auth_config.provider != "none":
                    from guard.auth.jwt_handler import JWTHandler
                    _jwt_handler = JWTHandler(auth_config)
    return _jwt_handler


def _get_session_manager():
    """Get or create the session manager singleton.

    If GUARD_SESSION_SECRET is not set, generates a secret and persists
    it to .sentrik/local/session_secret so sessions survive restarts.
    """
    global _session_manager
    if _session_manager is None:
        secret = _SESSION_SECRET
        if not secret:
            # Try to load persisted secret
            secret_path = Path(".sentrik") / "local" / "session_secret"
            if secret_path.exists():
                secret = secret_path.read_text(encoding="utf-8").strip()
            if not secret:
                secret = secrets.token_hex(32)
                try:
                    secret_path.parent.mkdir(parents=True, exist_ok=True)
                    # Write with restricted permissions from the start
                    try:
                        fd = os.open(str(secret_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                        with os.fdopen(fd, "w") as _f:
                            _f.write(secret)
                    except (OSError, AttributeError):
                        secret_path.write_text(secret, encoding="utf-8")
                        _logger.warning("Could not set restricted permissions on session secret file")
                    _logger.info("Generated and persisted session secret to %s", secret_path)
                except OSError:
                    _logger.warning("Could not persist session secret — sessions will not survive restart")
        auth_config = _get_auth_config()
        from guard.auth.oidc import SessionManager
        _session_manager = SessionManager(secret, auth_config.session_expiry_hours)
    return _session_manager


def _get_oidc_client(request_base_url: str = ""):
    """Get or create the OIDC client singleton."""
    global _oidc_client
    if _oidc_client is None:
        auth_config = _get_auth_config()
        if auth_config.enabled and auth_config.provider != "none":
            redirect_uri = f"{request_base_url.rstrip('/')}/auth/callback"
            from guard.auth.oidc import OIDCClient
            _oidc_client = OIDCClient(
                config=auth_config,
                client_secret=_AUTH0_CLIENT_SECRET,
                redirect_uri=redirect_uri,
            )
    return _oidc_client


def _check_api_key(x_api_key: Optional[str] = Header(None)) -> None:
    """Validate API key if GUARD_API_KEY is configured (legacy support)."""
    if _API_KEY is None:
        return  # Auth not enabled
    if not hmac.compare_digest(x_api_key or "", _API_KEY):
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


def _get_current_user(
    authorization: Optional[str] = Header(None),
    x_api_key: Optional[str] = Header(None),
    sentrik_session: Optional[str] = Cookie(None),
) -> UserContext:
    """Resolve the current user from JWT, session cookie, or API key.

    Auth precedence: JWT Bearer -> session cookie -> API key -> anonymous.
    When auth is disabled, returns an anonymous context (no 401).
    """
    auth_config = _get_auth_config()

    # 1. Try JWT Bearer token
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:]
        handler = _get_jwt_handler()
        if handler:
            try:
                return handler.validate_and_get_user(token)
            except (ValueError, KeyError, ImportError, TypeError) as exc:
                _logger.debug("JWT validation failed: %s", exc)
                if auth_config.enabled:
                    raise HTTPException(401, f"Invalid token: {exc}")

    # 2. Try session cookie (dashboard)
    if sentrik_session:
        mgr = _get_session_manager()
        session_data = mgr.read_session(sentrik_session)
        if session_data:
            return UserContext(
                user_id=session_data.get("user_id", ""),
                email=session_data.get("email", ""),
                name=session_data.get("name", ""),
                org_id=session_data.get("org_id", ""),
                roles=session_data.get("roles", []),
                auth_method="session",
                is_authenticated=True,
            )

    # 3. Try API key (backward compatible)
    if _API_KEY is not None:
        if x_api_key == _API_KEY:
            return UserContext.from_api_key()
        # API key is configured but not provided/wrong — reject
        raise HTTPException(401, "Invalid or missing API key")

    # 4. Auth disabled -> anonymous access
    if not auth_config.enabled:
        return UserContext.anonymous()

    raise HTTPException(401, "Authentication required")


def _require_permission(action: str, resource_type: str = "global"):
    """Dependency factory that resolves the current user and enforces a permission check.

    Combines ``_get_current_user`` (authn) with ``require_permission`` (authz) into a
    single FastAPI dependency so endpoints only need one ``Depends(...)`` call.
    """
    from guard.authz.checks import require_permission as _authz_check

    _perm_check = _authz_check(action, resource_type)

    def _dep(
        authorization: Optional[str] = Header(None),
        x_api_key: Optional[str] = Header(None),
        sentrik_session: Optional[str] = Cookie(None),
    ) -> UserContext:
        user = _get_current_user(authorization, x_api_key, sentrik_session)
        return _perm_check(user)

    return _dep


def _check_license(feature: str):
    """Dependency factory that gates an endpoint behind a license feature check."""
    from guard.core.licensing import check_feature, get_license_info

    def checker():
        config = _load_config()
        info = get_license_info(config.license_key)
        if not check_feature(info, feature):
            raise HTTPException(403, f"Feature '{feature}' requires a higher license tier.")

    return checker


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


_ALLOWED_CONFIG_OVERRIDE_KEYS = {
    "standards_packs", "standards_file", "work_items_file", "output_dir",
    "gate_fail_on", "scan_exclude", "governance", "parallel_scan",
    "max_workers", "severity_rescoring_enabled", "confidence_scoring_enabled",
}


class ScanRequest(BaseModel):
    """Request body for /scan endpoint."""
    repo_path: Optional[str] = None
    files: dict[str, str] = Field(
        default_factory=dict,
        description="Map of file path to file content for inline scanning",
    )
    changed_files: Optional[list[str]] = None
    config_overrides: dict[str, Any] = Field(
        default_factory=dict,
        description="Config overrides (same keys as .guard.yaml). Only safe keys are allowed.",
    )

    @field_validator("config_overrides")
    @classmethod
    def validate_override_keys(cls, v: dict[str, Any]) -> dict[str, Any]:
        invalid = set(v.keys()) - _ALLOWED_CONFIG_OVERRIDE_KEYS
        if invalid:
            raise ValueError(f"Disallowed config override keys: {', '.join(sorted(invalid))}")
        return v


class ScanResponse(BaseModel):
    """Response from /scan endpoint."""
    findings: list[dict[str, Any]]
    total: int
    by_severity: dict[str, int]


class GateResponse(BaseModel):
    """Response from /gate endpoint."""
    passed: bool
    total_findings: int
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    info: int = 0


class ReportResponse(BaseModel):
    """Response from /report endpoint."""
    format: str
    content: str


class RuleInfo(BaseModel):
    """Rule information for /rules endpoint."""
    id: str
    name: str
    type: str
    severity: str
    description: str = ""


class PackToggle(BaseModel):
    """Request body for /api/packs/toggle endpoint."""
    pack_id: str
    enabled: bool


class DevOpsTestConnectionRequest(BaseModel):
    """Request body for /api/devops/test-connection endpoint."""
    devops_provider: str
    azure_devops_org: str = ""
    azure_devops_project: str = ""
    azure_devops_team: str = ""
    azure_devops_iteration: str = ""
    github_owner: str = ""
    github_repo: str = ""
    github_label: str = ""
    github_milestone: str = ""
    jira_base_url: str = ""
    jira_project_key: str = ""
    jira_jql: str = ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _deep_merge(base: dict, updates: dict) -> dict:
    """Recursively merge *updates* into *base* (mutates *base*)."""
    for k, v in updates.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v
    return base


def _load_config(overrides: dict[str, Any] | None = None) -> GuardConfig:
    """Load config with optional overrides.

    When no config file exists, auto-detects the project and applies
    sensible defaults (same behavior as the CLI).
    """
    from guard.config import resolve_config_path

    config = GuardConfig.load()
    # Auto-detect if no config file exists (mirrors CLI _load_config behavior)
    resolved = resolve_config_path(None)
    if resolved is None or not resolved.exists():
        from guard.core.auto_detect import detect_project

        profile = detect_project()
        config = GuardConfig.from_profile(profile)
    if overrides:
        data = config.model_dump()
        _deep_merge(data, overrides)
        config = GuardConfig(**data)
    return config


def _run_scan(
    config: GuardConfig,
    repo_path: str | None = None,
    files: dict[str, str] | None = None,
    changed_files: list[str] | None = None,
) -> list[Finding]:
    """Run a scan and return findings."""
    _, _, scanner, rules_engine, _ = build_providers(config)
    scan_exclude = config.scan_exclude or None

    # If inline files provided, write to temp dir
    if files:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_resolved = Path(tmpdir).resolve()
            for file_path, content in files.items():
                p = (tmpdir_resolved / file_path).resolve()
                # Prevent path traversal outside tmpdir
                try:
                    p.relative_to(tmpdir_resolved)
                except ValueError:
                    raise HTTPException(400, f"Invalid file path (traversal attempt): {file_path}")
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content, encoding="utf-8")
            return _do_scan(rules_engine, scanner, tmpdir, changed_files, scan_exclude)

    # Use repo_path or current directory
    scan_root = repo_path or "."
    if repo_path:
        base_dir = Path.cwd().resolve()
        resolved = Path(repo_path).resolve()
        try:
            resolved.relative_to(base_dir)
        except ValueError:
            raise HTTPException(
                400,
                f"Invalid repo_path: path must be within the project directory",
            )
        scan_root = str(resolved)
    return _do_scan(rules_engine, scanner, scan_root, changed_files, scan_exclude)


def _do_scan(rules_engine, scanner, repo_root: str, changed_files: list[str] | None, scan_exclude: list[str] | None = None) -> list[Finding]:
    """Execute rules engine and scanner."""
    findings = rules_engine.evaluate(repo_root, changed_files=changed_files, scan_exclude=scan_exclude)
    scanner_findings = scanner.scan(repo_root, changed_files=changed_files)
    findings.extend(scanner_findings)
    return findings


def _findings_to_dicts(findings: list[Finding]) -> list[dict[str, Any]]:
    """Convert findings to serializable dicts."""
    return [f.model_dump() for f in findings]


def _count_by_severity(findings: list[Finding]) -> dict[str, int]:
    """Count findings by severity, excluding obligations."""
    counts: dict[str, int] = {}
    for f in findings:
        if f.is_obligation:
            continue
        sev = f.severity.value
        counts[sev] = counts.get(sev, 0) + 1
    return counts


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@app.get("/health")
def health():
    """Health check endpoint."""
    return {"status": "ok", "version": "0.1.0"}


# ---------------------------------------------------------------------------
# Auth endpoints (OIDC login flow)
# ---------------------------------------------------------------------------


@app.get("/auth/login")
def auth_login(request: Request):
    """Redirect to Auth0/Okta login page."""
    auth_config = _get_auth_config()
    if not auth_config.enabled:
        raise HTTPException(404, "Auth is not enabled")

    base_url = str(request.base_url).rstrip("/")
    client = _get_oidc_client(base_url)
    if not client:
        raise HTTPException(500, "OIDC client not configured")

    state = secrets.token_urlsafe(32)
    authorize_url = client.get_authorize_url(state=state)
    response = RedirectResponse(url=authorize_url, status_code=307)
    response.set_cookie("_sentrik_state", state, httponly=True, max_age=600, samesite="lax")
    return response


@app.get("/auth/callback")
def auth_callback(
    request: Request,
    code: str = Query(...),
    state: str = Query(""),
    _sentrik_state: Optional[str] = Cookie(None),
):
    """Handle Auth0/Okta OIDC callback after login."""
    auth_config = _get_auth_config()
    if not auth_config.enabled:
        raise HTTPException(404, "Auth is not enabled")

    # Validate CSRF state — require both presence and correctness
    if not _sentrik_state or state != _sentrik_state:
        raise HTTPException(400, "Invalid state parameter")

    base_url = str(request.base_url).rstrip("/")
    client = _get_oidc_client(base_url)
    if not client:
        raise HTTPException(500, "OIDC client not configured")

    # Exchange code for tokens
    try:
        tokens = client.exchange_code(code)
    except (ValueError, KeyError, OSError, ConnectionError, TypeError) as exc:
        _logger.error("OIDC callback failed: %s", exc)
        raise HTTPException(400, f"Login failed: {exc}")

    # Decode the ID token to get user info
    handler = _get_jwt_handler()
    id_token = tokens.get("id_token", "")
    access_token = tokens.get("access_token", "")

    user_data = {}
    if handler and id_token:
        try:
            payload = handler.decode_token(id_token)
            user_data = {
                "user_id": payload.sub,
                "email": payload.email,
                "name": payload.name,
                "org_id": payload.org_id,
                "roles": payload.roles,
            }
        except (ValueError, KeyError):
            _logger.warning("Failed to decode id_token, falling back to userinfo")

    # Fallback: fetch from /userinfo endpoint
    if not user_data.get("email") and access_token:
        try:
            userinfo = client.get_userinfo(access_token)
            user_data = {
                "user_id": userinfo.get("sub", ""),
                "email": userinfo.get("email", ""),
                "name": userinfo.get("name", ""),
                "org_id": userinfo.get("org_id", ""),
                "roles": userinfo.get("roles", []),
            }
        except Exception as exc:
            _logger.error("Userinfo fetch failed: %s", exc)

    # Create signed session cookie
    mgr = _get_session_manager()
    session_value = mgr.create_session(user_data)

    response = RedirectResponse(url="/dashboard", status_code=307)
    response.set_cookie(
        "sentrik_session", session_value,
        httponly=True, max_age=auth_config.session_expiry_hours * 3600,
        samesite="lax",
    )
    response.delete_cookie("_sentrik_state")
    return response


@app.post("/auth/logout")
def auth_logout(request: Request):
    """Clear session and optionally redirect to Auth0 logout."""
    auth_config = _get_auth_config()
    base_url = str(request.base_url).rstrip("/")

    response = RedirectResponse(url="/dashboard", status_code=307)
    response.delete_cookie("sentrik_session")

    # If OIDC is configured, redirect through Auth0 logout
    client = _get_oidc_client(base_url)
    if client and auth_config.enabled:
        logout_url = client.get_logout_url(return_to=f"{base_url}/dashboard")
        response = RedirectResponse(url=logout_url, status_code=307)
        response.delete_cookie("sentrik_session")

    return response


@app.get("/auth/me")
def auth_me(user: UserContext = Depends(_get_current_user)):
    """Return the current authenticated user context."""
    return {
        "user_id": user.user_id,
        "email": user.email,
        "name": user.name,
        "org_id": user.org_id,
        "roles": user.roles,
        "auth_method": user.auth_method,
        "is_authenticated": user.is_authenticated,
    }


# ---------------------------------------------------------------------------
# OAuth endpoints for DevOps provider connections
# ---------------------------------------------------------------------------

# In-memory state store for OAuth CSRF tokens (short-lived, with TTL)
_oauth_states: dict[str, tuple[str, float]] = {}  # state -> (provider, created_at)
_oauth_states_lock = threading.Lock()
_OAUTH_STATE_TTL = 600  # 10 minutes


@app.get("/oauth/{provider}/connect")
def oauth_connect(provider: str, request: Request):
    """Initiate OAuth flow for a DevOps provider (azure, github, jira)."""
    if provider not in ("azure", "github", "jira"):
        raise HTTPException(400, f"Unknown OAuth provider: {provider}")

    from guard.oauth.manager import OAuthManager, build_oauth_config
    config = build_oauth_config()

    # Validate that client_id is configured before redirecting to the provider.
    # Without this check, the user gets redirected to a broken URL with an empty
    # client_id parameter (e.g. Azure AADSTS900144 error).
    client_id_map = {
        "azure": config.azure_client_id,
        "github": config.github_client_id,
        "jira": config.jira_client_id,
    }
    client_id = client_id_map.get(provider, "")
    if not client_id:
        env_var = f"GUARD_{provider.upper()}_OAUTH_CLIENT_ID"
        error_msg = (
            f"OAuth not configured for {provider}. "
            f"Set the {env_var} environment variable "
            f"(and the corresponding CLIENT_SECRET) before connecting."
        )
        return RedirectResponse(
            url=f"/dashboard?oauth_error={quote(error_msg)}",
            status_code=302,
        )

    mgr = OAuthManager(config)

    base_url = str(request.base_url).rstrip("/")
    try:
        url, state = mgr.get_authorize_url(provider, base_url)
    except Exception as exc:
        raise HTTPException(500, f"Failed to build OAuth URL: {exc}. "
                            f"Ensure GUARD_{provider.upper()}_OAUTH_CLIENT_ID and "
                            f"GUARD_{provider.upper()}_OAUTH_CLIENT_SECRET are set.")

    import time as _t
    with _oauth_states_lock:
        # Clean up expired states
        now = _t.time()
        expired = [k for k, (_, ts) in _oauth_states.items() if now - ts > _OAUTH_STATE_TTL]
        for k in expired:
            del _oauth_states[k]
        _oauth_states[state] = (provider, now)
    return RedirectResponse(url=url, status_code=302)


@app.get("/oauth/{provider}/callback")
def oauth_callback(provider: str, request: Request, code: str = "", state: str = "", error: str = ""):
    """Handle OAuth callback from provider."""
    if error:
        from urllib.parse import quote
        safe_error = quote(error, safe="")
        return RedirectResponse(url=f"/dashboard?oauth_error={safe_error}", status_code=302)

    if provider not in ("azure", "github", "jira"):
        raise HTTPException(400, f"Unknown OAuth provider: {provider}")

    # Validate CSRF state (thread-safe with TTL check)
    import time as _t
    with _oauth_states_lock:
        state_data = _oauth_states.pop(state, None)
    if state_data is None:
        return RedirectResponse(url="/dashboard?oauth_error=invalid_state", status_code=302)
    expected_provider, created_at = state_data
    if _t.time() - created_at > _OAUTH_STATE_TTL:
        return RedirectResponse(url="/dashboard?oauth_error=state_expired", status_code=302)
    if expected_provider != provider:
        return RedirectResponse(url="/dashboard?oauth_error=invalid_state", status_code=302)

    from guard.oauth.manager import OAuthManager, build_oauth_config
    mgr = OAuthManager(build_oauth_config())

    base_url = str(request.base_url).rstrip("/")
    try:
        mgr.exchange_code(provider, code, base_url)
    except Exception as exc:
        _logger.error("OAuth token exchange failed for %s: %s", provider, exc)
        return RedirectResponse(url=f"/dashboard?oauth_error=token_exchange_failed", status_code=302)

    return RedirectResponse(url=f"/dashboard?oauth_success={provider}", status_code=302)


@app.post("/oauth/{provider}/disconnect", dependencies=[Depends(_require_permission("oauth:manage"))])
def oauth_disconnect(provider: str):
    """Remove stored OAuth tokens for a provider."""
    if provider not in ("azure", "github", "jira"):
        raise HTTPException(400, f"Unknown OAuth provider: {provider}")

    from guard.oauth.manager import OAuthManager, build_oauth_config
    mgr = OAuthManager(build_oauth_config())
    mgr.disconnect(provider)
    return {"status": "ok", "message": f"Disconnected from {provider}"}


@app.get("/api/oauth/status")
def oauth_status():
    """Return OAuth connection status for all providers."""
    from guard.oauth.manager import OAuthManager, build_oauth_config
    mgr = OAuthManager(build_oauth_config())
    return {
        "azure": mgr.get_connection_status("azure"),
        "github": mgr.get_connection_status("github"),
        "jira": mgr.get_connection_status("jira"),
    }


@app.post("/scan", response_model=ScanResponse, dependencies=[Depends(_require_permission("scan"))])
def scan(request: ScanRequest):
    """Scan code and return findings."""
    config = _load_config(request.config_overrides or None)
    findings = _run_scan(
        config,
        repo_path=request.repo_path,
        files=request.files or None,
        changed_files=request.changed_files,
    )
    return ScanResponse(
        findings=_findings_to_dicts(findings),
        total=len(findings),
        by_severity=_count_by_severity(findings),
    )


@app.post("/gate", response_model=GateResponse, dependencies=[Depends(_require_permission("gate"))])
def gate(request: ScanRequest):
    """Scan code and return gate result (pass/fail)."""
    config = _load_config(request.config_overrides or None)
    findings = _run_scan(
        config,
        repo_path=request.repo_path,
        files=request.files or None,
        changed_files=request.changed_files,
    )
    gate_result = evaluate_gate(findings, config)
    return GateResponse(
        passed=gate_result.passed,
        total_findings=gate_result.total_findings,
        critical=gate_result.critical,
        high=gate_result.high,
        medium=gate_result.medium,
        low=gate_result.low,
        info=gate_result.info,
    )


@app.post("/report", response_model=ReportResponse, dependencies=[Depends(_require_permission("findings:read"))])
def report(
    request: ScanRequest,
    format: str = Query("html", description="Report format: html, junit, sarif"),
):
    """Generate a report from scan findings."""
    config = _load_config(request.config_overrides or None)
    findings = _run_scan(
        config,
        repo_path=request.repo_path,
        files=request.files or None,
        changed_files=request.changed_files,
    )

    reporter = get_reporter(format)
    if reporter is None:
        raise HTTPException(status_code=400, detail=f"Unknown report format: {format}")

    content = reporter.render(findings)
    return ReportResponse(format=format, content=content)


@app.get("/rules", dependencies=[Depends(_require_permission("packs:read"))])
def list_rules():
    """List all configured rules."""
    config = _load_config()
    _, standards, _, rules_engine, _ = build_providers(config)

    from guard.rules.builtins import BUILTIN_RULES
    from guard.providers.factory import _load_pack_rules

    user_rules = standards.get_rules()
    pack_rules = _load_pack_rules(config.standards_packs, license_key=config.license_key)
    all_rules = BUILTIN_RULES + user_rules + pack_rules

    # Deduplicate
    seen: set[str] = set()
    unique: list[dict] = []
    for r in reversed(all_rules):
        rid = r.get("id", "")
        if rid not in seen:
            seen.add(rid)
            unique.append(r)
    unique.reverse()

    return {
        "rules": [
            RuleInfo(
                id=r.get("id", ""),
                name=r.get("name", ""),
                type=r.get("type", ""),
                severity=r.get("severity", ""),
                description=r.get("description", ""),
            ).model_dump()
            for r in unique
        ],
        "total": len(unique),
    }


# ---------------------------------------------------------------------------
# Metrics & Dashboard
# ---------------------------------------------------------------------------


@app.get("/api/posture", dependencies=[Depends(_require_permission("findings:read"))])
def get_posture():
    """Return the aggregate security posture score (ASPM).

    Combines compliance, vulnerability, trend, and gate reliability
    into a single weighted score with component breakdown.
    """
    from guard.core.posture import calculate_posture
    config = _load_config()
    db_path = Path(".sentrik") / "local" / "metrics.db"
    posture = calculate_posture(output_dir=config.output_dir, metrics_db_path=db_path)
    return posture.to_dict()


@app.get("/api/metrics", dependencies=[Depends(_require_permission("findings:read"))])
def get_metrics():
    """Return scan metrics from the most recent scan run."""
    config = _load_config()
    metrics_path = Path(config.output_dir) / "scan_metrics.json"
    findings_path = Path(config.output_dir) / "findings.json"

    result: dict[str, Any] = {}

    # Include project directory so the dashboard can display it
    result["project_dir"] = str(Path(".").resolve())

    if metrics_path.exists():
        try:
            result["scan_metrics"] = json.loads(
                metrics_path.read_text(encoding="utf-8")
            )
        except (json.JSONDecodeError, OSError):
            result["scan_metrics"] = None
    else:
        result["scan_metrics"] = None

    findings_data: list[dict] = []
    if findings_path.exists():
        try:
            findings_data = json.loads(
                findings_path.read_text(encoding="utf-8")
            )
            result["findings_count"] = len(findings_data)
            # Aggregate by file
            files: dict[str, int] = {}
            for f in findings_data:
                fp = f.get("evidence", {}).get("file", "unknown")
                files[fp] = files.get(fp, 0) + 1
            result["findings_by_file"] = dict(
                sorted(files.items(), key=lambda x: x[1], reverse=True)[:20]
            )
        except (json.JSONDecodeError, OSError):
            result["findings_count"] = 0
            result["findings_by_file"] = {}
    else:
        result["findings_count"] = 0
        result["findings_by_file"] = {}

    # Compliance score — read from scan_metrics if available, else compute
    if result.get("scan_metrics") and "compliance_score" in result["scan_metrics"]:
        result["compliance_score"] = result["scan_metrics"]["compliance_score"]
    else:
        # Compute from findings and loaded rules
        try:
            from guard.providers.factory import build_providers, _load_pack_rules
            _, standards, _, _, _ = build_providers(config)
            all_rules = standards.get_rules() + _load_pack_rules(config.standards_packs, license_key=config.license_key)
            rules_count = len(all_rules)
            if rules_count == 0:
                result["compliance_score"] = {"score": 100.0, "rules_total": 0, "rules_passed": 0, "rules_failed": 0}
            else:
                failed_ids: set[str] = set()
                for f in findings_data:
                    if not f.get("is_obligation", False):
                        rid = f.get("rule_id", "")
                        if rid:
                            failed_ids.add(rid)
                rules_failed = len(failed_ids)
                rules_passed = rules_count - rules_failed
                score = round((rules_passed / rules_count) * 100, 1)
                result["compliance_score"] = {
                    "score": score, "rules_total": rules_count,
                    "rules_passed": rules_passed, "rules_failed": rules_failed,
                }
        except (ImportError, KeyError, ZeroDivisionError, TypeError, ValueError) as exc:
            _logger.warning("Failed to compute compliance score: %s", exc, exc_info=True)
            result["compliance_score"] = None

    # Previous scan total for delta indicator
    history_dir = Path(config.output_dir) / "history"
    if history_dir.exists():
        history_files = sorted(history_dir.glob("scan_metrics_*.json"))
        if len(history_files) >= 2:
            try:
                prev_data = json.loads(history_files[-2].read_text(encoding="utf-8"))
                prev_sev = prev_data.get("findings_by_severity", {})
                result["scan_metrics"]["previous_total_findings"] = sum(prev_sev.values()) if prev_sev else prev_data.get("total_findings", 0)
            except (json.JSONDecodeError, OSError, TypeError):
                pass

    return result


@app.get("/api/config", dependencies=[Depends(_require_permission("config:read"))])
def get_config():
    """Return current configuration."""
    config = _load_config()
    return config.model_dump()


class ConfigUpdate(BaseModel):
    """Partial config update."""
    updates: dict[str, Any] = Field(default_factory=dict)


@app.post("/api/config", dependencies=[Depends(_require_permission("config:edit"))])
def update_config(request: ConfigUpdate):
    """Update configuration and write back to .guard.yaml."""
    config = _load_config()
    data = config.model_dump()
    _deep_merge(data, request.updates)
    new_config = GuardConfig(**data)
    path = new_config.save()

    # Audit log the configuration change
    try:
        from guard.core.governance import AuditLog
        gov = new_config.get_governance()
        audit = AuditLog(gov.audit)
        audit.log("config_update", details={
            "changed_keys": list(request.updates.keys()),
            "config_path": str(path),
        })
    except (ImportError, OSError, ValueError, TypeError) as exc:
        _logger.warning("Could not write audit entry for config update: %s", exc)

    return {"status": "ok", "path": str(path), "config": new_config.model_dump()}


@app.get("/api/governance", dependencies=[Depends(_require_permission("config:read")), Depends(_check_license("governance"))])
def get_governance():
    """Return resolved governance configuration with profile defaults applied."""
    config = _load_config()
    gov = config.get_governance()
    return {
        "profile": gov.profile,
        "valid_profiles": sorted(VALID_PROFILES),
        "human_review_required": gov.human_review_required.model_dump(),
        "auto_patch": gov.auto_patch.model_dump(),
        "gate": gov.gate.model_dump(),
        "sync": gov.sync.model_dump(),
        "audit": gov.audit.model_dump(),
    }


@app.get("/api/audit", dependencies=[Depends(_require_permission("audit:read")), Depends(_check_license("audit"))])
def get_audit_log(limit: int = Query(100, description="Max entries to return")):
    """Return recent audit log entries."""
    config = _load_config()
    gov = config.get_governance()
    audit = AuditLog(gov.audit)
    entries = audit.read(limit=limit)
    return {"entries": entries, "total": len(entries)}


@app.get("/api/audit/runs", dependencies=[Depends(_require_permission("audit:read")), Depends(_check_license("audit"))])
def list_audit_runs():
    """List historical scan runs available for report generation."""
    from guard.core.pipeline import list_historical_runs
    config = _load_config()
    runs = list_historical_runs(config.output_dir)
    return {"runs": runs, "total": len(runs)}


@app.get("/api/audit/runs/{run_id}/report", dependencies=[Depends(_require_permission("audit:read")), Depends(_check_license("audit"))])
def get_audit_run_report(run_id: str, framework: str = Query(None, description="Framework filter")):
    """Generate a compliance report for a historical scan run."""
    from guard.core.pipeline import load_historical_findings, load_historical_metadata
    from guard.reporters.compliance_report import generate_compliance_report

    config = _load_config()
    findings = load_historical_findings(config.output_dir, run_id)
    if findings is None:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    metadata = load_historical_metadata(config.output_dir, run_id)
    html = generate_compliance_report(findings, framework=framework)

    return {
        "html": html,
        "run_id": run_id,
        "metadata": metadata,
        "total_findings": sum(1 for f in findings if not f.is_obligation),
        "total_obligations": sum(1 for f in findings if f.is_obligation),
    }


# ---------------------------------------------------------------------------
# Approval endpoints (async approval gates)
# ---------------------------------------------------------------------------

@app.get("/api/approvals", dependencies=[Depends(_require_permission("approval:review")), Depends(_check_license("async_approval"))])
def list_approvals():
    """List pending approval requests."""
    from guard.core.approvals import get_approval_store
    store = get_approval_store()
    pending = store.list_pending()
    return {"approvals": [r.model_dump() for r in pending], "total": len(pending)}


@app.get("/api/approvals/{approval_id}", dependencies=[Depends(_require_permission("approval:review")), Depends(_check_license("async_approval"))])
def get_approval(approval_id: str):
    """Get details for a specific approval request."""
    from guard.core.approvals import get_approval_store
    store = get_approval_store()
    req = store.get(approval_id)
    if req is None:
        raise HTTPException(404, f"Approval request {approval_id} not found")
    return req.model_dump()


class ApprovalAction(BaseModel):
    action: str  # "approved" or "rejected"
    comment: str = ""
    create_work_items: bool = False


@app.patch("/api/approvals/{approval_id}", dependencies=[Depends(_require_permission("approval:review")), Depends(_check_license("async_approval"))])
def resolve_approval(
    approval_id: str,
    body: ApprovalAction,
    user: UserContext = Depends(_get_current_user),
):
    """Approve or reject a pending approval request."""
    from guard.core.approvals import get_approval_store
    if body.action not in ("approved", "rejected"):
        raise HTTPException(400, "action must be 'approved' or 'rejected'")
    if body.action == "approved" and not body.comment.strip():
        raise HTTPException(400, "comment is required when approving — provide a justification for the audit trail")
    store = get_approval_store()
    req = store.resolve(approval_id, body.action, user.user_id or "api-user", body.comment)
    if req is None:
        raise HTTPException(404, f"Approval request {approval_id} not found")

    created_work_items: list[dict] = []
    if body.action == "approved" and body.create_work_items:
        created_work_items = _create_work_items_for_findings(req)

    result = req.model_dump()
    if created_work_items:
        result["created_work_items"] = created_work_items
    return result


def _create_work_items_for_findings(approval) -> list[dict]:
    """Create work items in the configured DevOps provider for unresolved findings."""
    import json
    config = _load_config()
    findings_path = os.path.join(config.output_dir, "findings.json")
    if not os.path.exists(findings_path):
        return []
    try:
        with open(findings_path) as f:
            data = json.load(f)
        findings = data.get("findings", [])
    except (json.JSONDecodeError, OSError, KeyError):
        return []

    # Only create work items for gate-blocking severities
    fail_on = {s.lower() for s in config.gate_fail_on}
    blocking = [f for f in findings if f.get("severity", "").lower() in fail_on]
    if not blocking:
        return []

    provider = _get_devops_provider(config)
    if not hasattr(provider, "create_work_item"):
        return []

    created = []
    for finding in blocking:
        rule_id = finding.get("rule_id", "unknown")
        severity = finding.get("severity", "unknown")
        file_path = (finding.get("evidence", {}) or {}).get("file", "")
        message = finding.get("message", "")
        title = f"[{rule_id}] {severity.upper()}: {message[:80]}"
        desc = (
            f"**Finding from approval {approval.id[:8]}**\n\n"
            f"- **Rule:** {rule_id}\n"
            f"- **Severity:** {severity}\n"
            f"- **File:** {file_path}\n"
            f"- **Message:** {message}\n"
        )
        wi_id = provider.create_work_item(title=title, description=desc, tags="sentrik,approval-finding")
        if wi_id is not None:
            created.append({"rule_id": rule_id, "file": file_path, "work_item_id": wi_id})
    return created


@app.get("/api/approvals/{approval_id}/status", dependencies=[Depends(_require_permission("approval:request")), Depends(_check_license("async_approval"))])
def poll_approval_status(approval_id: str):
    """Poll the status of an approval request (for CI agents)."""
    from guard.core.approvals import get_approval_store
    store = get_approval_store()
    req = store.get(approval_id)
    if req is None:
        raise HTTPException(404, f"Approval request {approval_id} not found")
    config = _load_config()
    approval_config = config.get_async_approval_config()
    expired = req.is_expired(approval_config.timeout_seconds)
    if expired and req.status == "pending":
        store.resolve(req.id, "expired", "system", "Approval timed out")
        req = store.get(approval_id)
    return {"id": req.id, "status": req.status, "expired": expired}


def _get_repo_root() -> Path:
    """Return the project root — the directory containing the config file, or cwd."""
    from guard.config import resolve_config_path
    resolved = resolve_config_path(None)
    if resolved is not None and resolved.exists():
        # .sentrik/config.yaml → parent.parent is the project root
        # .guard.yaml → parent is the project root
        p = resolved.resolve()
        return p.parent.parent if p.parent.name == ".sentrik" else p.parent
    return Path(".").resolve()


@app.get("/api/packs", dependencies=[Depends(_require_permission("packs:read"))])
def get_packs():
    """Return available standards packs with enabled status."""
    config = _load_config()
    packs = list_available_packs(base_dir=_get_repo_root())
    enabled = set(config.standards_packs)
    return {
        "packs": [
            {
                "pack_id": p.pack_id,
                "name": p.name,
                "description": p.description,
                "rule_count": p.rule_count,
                "enabled": p.pack_id in enabled,
                "source": p.source,
            }
            for p in packs
        ],
        "total": len(packs),
        "enabled_count": len(enabled),
    }


@app.get("/api/findings", dependencies=[Depends(_require_permission("findings:read"))])
def get_findings(severity: Optional[str] = Query(None)):
    """Return findings from the last scan with optional severity filter."""
    config = _load_config()
    findings_path = Path(config.output_dir) / "findings.json"
    findings = load_findings(findings_path)
    if severity:
        findings = [f for f in findings if f.severity.value == severity]
    return {
        "findings": _findings_to_dicts(findings),
        "total": len(findings),
        "by_severity": _count_by_severity(findings),
    }


@app.get("/api/snippet", dependencies=[Depends(_require_permission("findings:read"))])
def get_snippet(
    file: str = Query(..., description="File path relative to repo root"),
    line: int = Query(1, ge=1, description="Center line number"),
    context: int = Query(5, ge=0, le=50, description="Lines of context above and below"),
):
    """Return source lines around a given line for code preview."""
    config = _load_config()
    # Resolve relative to CWD (where guard was run)
    base = Path.cwd()
    target = (base / file).resolve()
    # Security: prevent path traversal outside base
    try:
        target.relative_to(base.resolve())
    except ValueError:
        raise HTTPException(status_code=400, detail="File path outside project root")
    if not target.is_file():
        return {"lines": [], "start_line": line, "file": file, "error": "File not found"}
    try:
        text = target.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {"lines": [], "start_line": line, "file": file, "error": "Cannot read file"}
    all_lines = text.splitlines()
    start = max(0, line - 1 - context)
    end = min(len(all_lines), line - 1 + context + 1)
    snippet_lines = [
        {"num": i + 1, "text": all_lines[i], "highlight": i + 1 == line}
        for i in range(start, end)
    ]
    return {"lines": snippet_lines, "start_line": start + 1, "file": file, "total_lines": len(all_lines)}


@app.get("/api/report/generate", dependencies=[Depends(_require_permission("findings:read"))])
def generate_report(format: str = Query("html")):
    """Generate a report from the most recent scan findings on disk."""
    config = _load_config()
    findings = load_findings(Path(config.output_dir) / "findings.json")
    reporter = get_reporter(format)
    if reporter is None:
        raise HTTPException(status_code=400, detail=f"Unknown format: {format}")
    content = reporter.render(findings)
    return {"format": format, "content": content, "findings_count": len(findings)}


_compliance_map_cache: dict = {}

@app.get("/api/compliance-map", dependencies=[Depends(_require_permission("findings:read"))])
def compliance_map_endpoint(
    framework: Optional[str] = Query(None, description="Filter by standard/framework."),
    refresh: bool = Query(False, description="Force rebuild of evidence map."),
):
    """Return compliance evidence map showing where requirements are met."""
    import threading
    from guard.core.evidence_mapper import build_compliance_map

    cache_path = Path(_load_config().output_dir) / "compliance-map.json"

    # Serve from cache if available and not forcing refresh
    if not refresh and cache_path.exists():
        try:
            import json
            data = json.loads(cache_path.read_text(encoding="utf-8"))
            if framework:
                fw_lower = framework.lower()
                data["rules"] = [r for r in data.get("rules", []) if fw_lower in (r.get("standard") or "").lower()]
                applicable = sum(1 for r in data["rules"] if r["status"] in ("met", "violated"))
                met = sum(1 for r in data["rules"] if r["status"] == "met")
                data["summary"]["coverage_percent"] = round(met / applicable * 100, 1) if applicable else 100.0
            return data
        except Exception:
            pass

    # Build fresh — this scans files so can be slow
    config = _load_config()
    findings = load_findings(Path(config.output_dir) / "findings.json")
    _, _, _, rules_engine, _ = build_providers(config)

    cmap = build_compliance_map(
        repo_root=str(Path.cwd()),
        rules=rules_engine._rules,
        findings=findings,
        scan_exclude=config.scan_exclude,
    )

    # Cache result
    result = cmap.to_dict()
    try:
        import json
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    except OSError:
        pass

    if framework:
        fw_lower = framework.lower()
        result["rules"] = [r for r in result.get("rules", []) if fw_lower in (r.get("standard") or "").lower()]
        applicable = sum(1 for r in result["rules"] if r["status"] in ("met", "violated"))
        met = sum(1 for r in result["rules"] if r["status"] == "met")
        result["summary"]["coverage_percent"] = round(met / applicable * 100, 1) if applicable else 100.0

    return result


@app.get("/api/compliance-report", dependencies=[Depends(_require_permission("findings:read"))])
def compliance_report_endpoint(
    framework: Optional[str] = Query(None, description="Standard/framework name (e.g. 'IEC 62304'). Omit for all."),
    list_only: bool = Query(False, alias="list", description="If true, return available frameworks instead of report."),
):
    """Generate a per-framework compliance report mapping findings to regulatory clauses."""
    from guard.reporters.compliance_report import (
        generate_compliance_report,
        list_frameworks,
    )

    config = _load_config()
    findings = load_findings(Path(config.output_dir) / "findings.json")

    if list_only:
        frameworks = list_frameworks(findings)
        return {
            "frameworks": [
                {"name": fw, "findings": sum(1 for f in findings if f.standard == fw)}
                for fw in frameworks
            ]
        }

    # Read rules_total from scan_metrics if available
    rules_total = None
    metrics_path = Path(config.output_dir) / "scan_metrics.json"
    if metrics_path.exists():
        try:
            import json as _json
            metrics = _json.loads(metrics_path.read_text(encoding="utf-8"))
            cs = metrics.get("compliance_score", {})
            rules_total = cs.get("rules_total")
        except (ValueError, OSError):
            pass

    html = generate_compliance_report(findings, framework=framework, rules_total=rules_total)
    scoped = findings if not framework else [f for f in findings if f.standard and f.standard.lower() == framework.lower()]
    return {
        "html": html,
        "framework": framework or "all",
        "total_findings": sum(1 for f in scoped if not f.is_obligation),
        "total_obligations": sum(1 for f in scoped if f.is_obligation),
    }


@app.get("/api/trust-center", dependencies=[Depends(_require_permission("findings:read"))])
def trust_center_endpoint(
    format: str = Query("html", description="Output format: 'html' or 'json'."),
    org_name: Optional[str] = Query(None, description="Organization name for the header."),
):
    """Generate a public-safe trust center page showing compliance posture."""
    from guard.reporters.trust_center import (
        generate_trust_center,
        generate_trust_center_json,
    )

    config = _load_config()
    findings = load_findings(Path(config.output_dir) / "findings.json")

    # Read rules_total and timestamp from scan_metrics
    rules_total = None
    scan_timestamp = None
    metrics_path = Path(config.output_dir) / "scan_metrics.json"
    if metrics_path.exists():
        try:
            import json as _json
            metrics = _json.loads(metrics_path.read_text(encoding="utf-8"))
            cs = metrics.get("compliance_score", {})
            rules_total = cs.get("rules_total")
            scan_timestamp = metrics.get("timestamp")
        except (ValueError, OSError):
            pass

    if format == "json":
        return generate_trust_center_json(
            findings, rules_total=rules_total, org_name=org_name,
            scan_timestamp=scan_timestamp,
        )

    html = generate_trust_center(
        findings, rules_total=rules_total, org_name=org_name,
        scan_timestamp=scan_timestamp,
    )
    return {"html": html, "org_name": org_name}


@app.get("/api/evidence-export", dependencies=[Depends(_require_permission("findings:read"))])
def evidence_export_endpoint(
    framework: str = Query("", description="Framework name (e.g. 'SOC2', 'IEC 62304')."),
    format: str = Query("json", description="Output format: 'json' or 'html'."),
    list_only: bool = Query(False, alias="list", description="If true, return available frameworks."),
):
    """Generate an audit evidence package mapped to compliance framework controls."""
    from guard.core.evidence_export import (
        collect_evidence,
        generate_evidence_html,
        generate_evidence_package,
        list_available_frameworks,
    )

    if list_only or not framework:
        return {"frameworks": list_available_frameworks()}

    config = _load_config()

    evidence_items = collect_evidence(config.output_dir, framework)
    package = generate_evidence_package(
        evidence_items,
        framework=framework,
        project_name=Path(".").resolve().name,
    )

    if format == "html":
        return {"html": generate_evidence_html(package), "framework": framework}

    return package


@app.get("/api/org/projects", dependencies=[Depends(_require_permission("findings:read"))])
def org_projects_endpoint(
    root: Optional[str] = Query(None, description="Root directory containing sub-projects. Defaults to parent of cwd."),
):
    """Aggregate compliance data across multiple repositories under an org root."""
    from guard.core.org_dashboard import (
        aggregate_org_data,
        collect_project_data,
        discover_projects,
        org_data_to_json,
    )

    root_dir = Path(root) if root else Path(".").resolve().parent
    if not root_dir.is_dir():
        raise HTTPException(status_code=400, detail=f"Root directory not found: {root_dir}")

    project_paths = discover_projects(root_dir)
    projects = [collect_project_data(pp) for pp in project_paths]
    agg = aggregate_org_data(projects)
    return org_data_to_json(projects, agg)


@app.post("/api/run-scan", dependencies=[Depends(_require_permission("scan"))])
def run_scan_action():
    """Run a scan against the current working directory."""
    config = _load_config()
    _, _, scanner, rules_engine, _ = build_providers(config)
    findings, gate_result, out_path = run_scan_and_write(
        ".", config, rules_engine, scanner, command="scan",
    )
    return {
        "status": "completed",
        "total_findings": len(findings),
        "by_severity": _count_by_severity(findings),
        "gate_passed": gate_result.passed,
        "output_dir": str(out_path),
    }


@app.post("/api/run-gate", dependencies=[Depends(_require_permission("gate"))])
def run_gate_action():
    """Run a gate check against the current working directory."""
    config = _load_config()
    _, _, scanner, rules_engine, _ = build_providers(config)
    findings, gate_result, out_path = run_scan_and_write(
        ".", config, rules_engine, scanner, command="gate",
    )

    # Write audit entry (mirrors CLI gate behavior)
    try:
        from guard.core.governance import AuditLog, PolicyEngine
        from guard.core.pipeline import get_current_run_id
        gov = config.get_governance()
        policy = PolicyEngine(gov)
        audit = AuditLog(gov.audit)
        _run_id = get_current_run_id(config.output_dir)
        if gate_result.passed:
            audit.log("gate", details={"result": "passed", "findings": len(findings), "run_id": _run_id})
        else:
            decision = policy.check_gate_failure(has_critical=gate_result.critical > 0)
            audit.log(
                "gate", details={"result": "failed", "findings": len(findings), "run_id": _run_id},
                decision=decision, result="blocked",
            )
    except (ImportError, OSError, ValueError, TypeError) as exc:
        _logger.error("Audit logging failed during gate check: %s", exc, exc_info=True)

    # Webhook notifications on gate failure
    if not gate_result.passed:
        try:
            from guard.core.notifications import notify_gate_failure
            notify_gate_failure(config, gate_result, findings)
        except (ImportError, OSError, ConnectionError, ValueError, TypeError) as exc:
            _logger.error("Gate failure notification failed: %s", exc, exc_info=True)

    return {
        "status": "completed",
        "gate_passed": gate_result.passed,
        "total_findings": gate_result.total_findings,
        "critical": gate_result.critical,
        "high": gate_result.high,
        "medium": gate_result.medium,
        "low": gate_result.low,
        "info": gate_result.info,
    }


@app.post("/api/run-context", dependencies=[Depends(_require_permission("findings:read"))])
def run_context_action():
    """Build agent context by fetching work items from the configured DevOps provider."""
    from guard.core.context_builder import build_agent_context

    config = _load_config()
    devops, standards, _, _, _ = build_providers(config)
    ctx = build_agent_context(".", config, devops, standards)
    out_path = Path(config.output_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    (out_path / "agent_context.json").write_text(
        json.dumps(ctx.model_dump(), indent=2, default=str)
    )
    return {
        "status": "completed",
        "work_items_count": len(ctx.work_items),
        "output_file": str(out_path / "agent_context.json"),
    }


@app.post("/api/packs/toggle", dependencies=[Depends(_require_permission("packs:manage"))])
def toggle_pack(request: PackToggle):
    """Enable or disable a standards pack by updating config."""
    if request.enabled and not is_known_pack(request.pack_id, base_dir=_get_repo_root()):
        raise HTTPException(status_code=400, detail=f"Unknown pack {request.pack_id!r}")
    config = _load_config()
    packs = list(config.standards_packs)
    if request.enabled and request.pack_id not in packs:
        # License-gate packs by tier
        from guard.packs.registry import pack_tier as _pack_tier
        from guard.providers.factory import _pack_allowed
        from guard.core.licensing import get_license_info
        license_info = get_license_info(config.license_key)
        if not _pack_allowed(request.pack_id, license_info, config.license_key or ""):
            tier_needed = _pack_tier(request.pack_id)
            raise HTTPException(
                status_code=403,
                detail=f"Pack {request.pack_id!r} requires a {tier_needed}-tier license or higher.",
            )
        packs.append(request.pack_id)
    elif not request.enabled and request.pack_id in packs:
        packs.remove(request.pack_id)
    data = config.model_dump()
    data["standards_packs"] = packs
    new_config = GuardConfig(**data)
    new_config.save()
    return {"status": "ok", "standards_packs": packs}


class PackImportRequest(BaseModel):
    """Request body for importing a pack."""
    pack_id: str
    pack_yaml: dict
    overwrite: bool = False


@app.post("/api/packs/import", dependencies=[Depends(_require_permission("packs:manage")), Depends(_check_license("custom_packs"))])
def import_pack_endpoint(request: PackImportRequest):
    """Import a custom standards pack."""
    errors = validate_pack_yaml(request.pack_yaml)
    if errors:
        raise HTTPException(status_code=400, detail={"validation_errors": errors})
    try:
        path = registry_import_pack(
            request.pack_id, request.pack_yaml, overwrite=request.overwrite,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"status": "ok", "pack_id": request.pack_id, "path": str(path)}


@app.get("/api/packs/{pack_id}/export", dependencies=[Depends(_require_permission("packs:read"))])
def export_pack_endpoint(pack_id: str):
    """Export a standards pack as YAML dict."""
    try:
        raw = registry_export_pack(pack_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"pack_id": pack_id, "pack_yaml": raw}


@app.get("/api/packs/{pack_id}/rules", dependencies=[Depends(_require_permission("packs:read"))])
def get_pack_rules(pack_id: str):
    """Return rules for a specific pack with current overrides."""
    if not is_known_pack(pack_id, base_dir=_get_repo_root()):
        raise HTTPException(status_code=404, detail=f"Unknown pack {pack_id!r}")
    config = _load_config()
    raw = registry_export_pack(pack_id)
    rules = raw.get("rules", [])
    overrides = config.pack_overrides.get(pack_id, {})
    return {"pack_id": pack_id, "rules": rules, "overrides": overrides}


@app.delete("/api/packs/{pack_id}", dependencies=[Depends(_require_permission("packs:manage")), Depends(_check_license("custom_packs"))])
def delete_pack_endpoint(pack_id: str):
    """Delete a custom standards pack."""
    try:
        delete_custom_pack(pack_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    # Also remove from config if enabled
    config = _load_config()
    if pack_id in config.standards_packs:
        config.standards_packs.remove(pack_id)
        config.save()
    return {"status": "ok", "pack_id": pack_id}


@app.get("/api/license", dependencies=[Depends(_require_permission("config:read"))])
def get_license():
    """Return license status and feature availability."""
    from guard.core.licensing import get_license_info, TIER_DISPLAY
    config = _load_config()
    info = get_license_info(config.license_key)
    return {
        "valid": info.valid,
        "tier": info.tier,
        "tier_display": TIER_DISPLAY.get(info.tier, info.tier),
        "expiry": info.expiry.isoformat() if info.expiry else None,
        "expired": info.expired,
        "features": sorted(info.features),
        "message": info.message,
    }


def _check_project_mismatch(provider: str, req: "DevOpsTestConnectionRequest") -> str | None:
    """Return a warning string if the configured DevOps project doesn't match the local git repo name."""
    from guard.core.repo_reader import get_git_repo_name

    local_name = get_git_repo_name()
    if not local_name:
        return None
    local_lower = local_name.lower()

    if provider == "azure" and req.azure_devops_project:
        remote = req.azure_devops_project
        if remote.lower() != local_lower:
            return f"Local git repo '{local_name}' does not match Azure DevOps project '{remote}'. You may be syncing to the wrong project."
    elif provider == "github" and req.github_repo:
        remote = req.github_repo
        if remote.lower() != local_lower:
            return f"Local git repo '{local_name}' does not match GitHub repo '{remote}'. You may be syncing to the wrong project."
    elif provider == "jira" and req.jira_project_key:
        remote = req.jira_project_key
        # Jira project keys are often abbreviations — only warn, don't block
        if remote.lower() != local_lower and local_lower not in remote.lower():
            return f"Local git repo '{local_name}' does not match Jira project '{remote}'. Verify this is the correct project."
    return None


@app.post("/api/devops/test-connection", dependencies=[Depends(_require_permission("config:edit"))])
def test_devops_connection(req: DevOpsTestConnectionRequest):
    """Test a DevOps provider connection using form fields (without saving config)."""
    provider = req.devops_provider
    if provider not in VALID_DEVOPS_PROVIDERS:
        raise HTTPException(400, f"Invalid provider '{provider}'. Must be one of: {sorted(VALID_DEVOPS_PROVIDERS)}")

    # Stub provider always succeeds — no remote call needed
    if provider == "stub":
        return {"status": "ok", "provider": "stub", "message": "Stub provider (local file) is always available.", "work_item_count": 0}

    # Build a temporary config from form fields and attempt connection
    temp_config = GuardConfig(
        devops_provider=provider,
        azure_devops_org=req.azure_devops_org,
        azure_devops_project=req.azure_devops_project,
        azure_devops_team=req.azure_devops_team,
        azure_devops_iteration=req.azure_devops_iteration,
        github_owner=req.github_owner,
        github_repo=req.github_repo,
        github_label=req.github_label,
        github_milestone=req.github_milestone,
        jira_base_url=req.jira_base_url,
        jira_project_key=req.jira_project_key,
        jira_jql=req.jira_jql,
    )
    try:
        devops = build_devops(temp_config)
        items = devops.get_work_items()
        # Check for project name mismatch with local git repo
        mismatch_warning = _check_project_mismatch(provider, req)
        msg = f"Connected successfully. Found {len(items)} work item(s)."
        resp: dict = {
            "status": "ok",
            "provider": provider,
            "message": msg,
            "work_item_count": len(items),
        }
        if mismatch_warning:
            resp["mismatch_warning"] = mismatch_warning
        return resp
    except Exception as exc:
        raise HTTPException(502, f"Connection failed: {exc}")


@app.post("/api/devops/work-item-types", dependencies=[Depends(_require_permission("config:read"))])
def get_devops_work_item_types(req: DevOpsTestConnectionRequest):
    """Fetch available work item types from the DevOps provider project."""
    provider = req.devops_provider
    if provider != "azure":
        return {"types": []}
    temp_config = GuardConfig(
        devops_provider=provider,
        azure_devops_org=req.azure_devops_org,
        azure_devops_project=req.azure_devops_project,
        azure_devops_team=req.azure_devops_team,
        azure_devops_iteration=req.azure_devops_iteration,
    )
    try:
        devops = build_devops(temp_config)
        types = devops.get_available_work_item_types()
        return {"types": types}
    except Exception as exc:
        raise HTTPException(502, f"Failed to fetch work item types: {exc}")


@app.get("/api/devops/status", dependencies=[Depends(_require_permission("config:read"))])
def get_devops_status():
    """Return current DevOps provider configuration and connection status."""
    config = _load_config()
    provider = config.devops_provider
    configured = provider != "stub"

    config_summary = {}
    env_vars: dict[str, bool] = {}

    if provider == "azure":
        config_summary = {
            "org": config.azure_devops_org,
            "project": config.azure_devops_project,
            "team": config.azure_devops_team,
        }
        env_vars = {"AZURE_DEVOPS_PAT": bool(os.environ.get("AZURE_DEVOPS_PAT"))}
    elif provider == "github":
        config_summary = {
            "owner": config.github_owner,
            "repo": config.github_repo,
            "label": config.github_label,
        }
        env_vars = {"GITHUB_TOKEN": bool(os.environ.get("GITHUB_TOKEN"))}
    elif provider == "jira":
        config_summary = {
            "base_url": config.jira_base_url,
            "project_key": config.jira_project_key,
        }
        env_vars = {
            "JIRA_USER": bool(os.environ.get("JIRA_USER")),
            "JIRA_TOKEN": bool(os.environ.get("JIRA_TOKEN")),
            "JIRA_PAT": bool(os.environ.get("JIRA_PAT")),
        }

    # Read last reconcile summary if available
    last_reconcile = None
    output_dir = Path(config.output_dir)
    summary_path = output_dir / "reconcile_summary.json"
    if summary_path.exists():
        try:
            with open(summary_path) as f:
                last_reconcile = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    # OAuth connection status
    oauth_info = {}
    if provider in ("azure", "github", "jira"):
        try:
            from guard.oauth.manager import OAuthManager, build_oauth_config
            mgr = OAuthManager(build_oauth_config())
            oauth_info = mgr.get_connection_status(provider)
        except (ImportError, OSError, ValueError):
            oauth_info = {"connected": False, "method": None, "message": "OAuth not available"}

    return {
        "provider": provider,
        "configured": configured,
        "config_summary": config_summary,
        "env_vars": env_vars,
        "oauth": oauth_info,
        "last_reconcile": last_reconcile,
    }


@app.get("/api/work-items", dependencies=[Depends(_require_permission("config:read"))])
def get_work_items():
    """Return work items from the configured DevOps provider."""
    config = _load_config()
    devops = build_devops(config)
    items = devops.get_work_items()

    # Load findings for cross-reference
    output_dir = Path(config.output_dir)
    findings_path = output_dir / "findings.json"
    findings: list[Finding] = []
    if findings_path.exists():
        findings = load_findings(findings_path)

    # Count linked findings per work item rule_id
    from guard.core.reconciler import group_findings_by_rule
    groups = group_findings_by_rule(findings)

    result = []
    for wi in items:
        wi_data = wi.model_dump(exclude_none=True)
        wi_data["linked_findings_count"] = len(groups.get(wi.rule_id or "", []))
        result.append(wi_data)

    return {"work_items": result, "total": len(result), "provider": config.devops_provider}


@app.post("/api/reconcile", dependencies=[Depends(_require_permission("reconcile")), Depends(_check_license("reconcile"))])
def run_reconcile(dry_run: bool = Query(False)):
    """Run reconciliation between findings and work items."""
    config = _load_config()
    output_dir = Path(config.output_dir)
    findings_path = output_dir / "findings.json"

    # Load findings from last scan
    findings: list[Finding] = []
    if findings_path.exists():
        findings = load_findings(findings_path)

    if not findings:
        return {"status": "no_findings", "actions": [], "result": None}

    # Load existing work items — use DevOps provider when configured
    wi_path = Path(config.work_items_file)
    existing: list[WorkItem] = []
    if config.devops_provider != "stub":
        devops = build_devops(config)
        try:
            existing = devops.get_work_items()
        except (OSError, ValueError, KeyError):
            existing = []
    elif wi_path.exists():
        with open(wi_path) as f:
            raw = json.load(f)
        existing = [WorkItem(**wi) for wi in raw]

    actions = compute_reconcile_actions(findings, existing)
    actions_data = [
        {"action": a.action, "rule_id": a.rule_id, "title": a.title}
        for a in actions
    ]

    if dry_run:
        return {"status": "dry_run", "actions": actions_data, "result": None}

    devops = build_devops(config)
    result = execute_reconcile(actions, devops, existing, wi_path, output_dir,
                              work_item_type=config.azure_devops_work_item_type)

    # Write audit log entry with enriched details
    from guard.core.governance import PolicyEngine
    gov = config.get_governance()
    policy = PolicyEngine(gov)
    audit = AuditLog(gov.audit)
    has_changes = bool(result.created or result.updated or result.closed)
    if has_changes:
        decision = policy.check_requirement_change()
        from guard.core.reconciler import group_findings_by_rule as _grp
        groups = _grp(findings)

        def _enrich(wi_id, action):
            if not action:
                return {"id": wi_id}
            ac_list = [
                line.lstrip("- ").strip()
                for line in (action.acceptance_criteria or "").splitlines()
                if line.strip()
            ]
            rule_findings = groups.get(action.rule_id, [])
            severity = rule_findings[0].severity.value if rule_findings else "unknown"
            return {
                "id": wi_id,
                "rule_id": action.rule_id,
                "title": action.title,
                "severity": severity,
                "finding_count": len(rule_findings),
                "description": action.description,
                "acceptance_criteria": ac_list,
            }

        create_actions = [a for a in actions if a.action == "create"]
        created_detail = [
            _enrich(wi_id, create_actions[i] if i < len(create_actions) else None)
            for i, wi_id in enumerate(result.created)
        ]
        update_actions = [a for a in actions if a.action == "update"]
        updated_detail = [
            _enrich(wi_id, update_actions[i] if i < len(update_actions) else None)
            for i, wi_id in enumerate(result.updated)
        ]
        audit.log(
            "reconcile",
            details={
                "created": created_detail,
                "updated": updated_detail,
                "closed": result.closed,
                "summary": (
                    f"{len(result.created)} created, "
                    f"{len(result.updated)} updated, "
                    f"{len(result.closed)} closed"
                ),
            },
            decision=decision,
        )

    return {
        "status": "completed",
        "actions": actions_data,
        "result": {
            "created": result.created,
            "updated": result.updated,
            "closed": result.closed,
            "errors": result.errors,
        },
    }


@app.post("/api/check-coverage", dependencies=[Depends(_require_permission("findings:write"))])
def check_coverage(force: bool = Query(False)):
    """Check requirement coverage — flag files not traced to any work item."""
    from guard.core.repo_reader import list_files

    config = _load_config()

    if not config.requirement_coverage_enabled and not force:
        raise HTTPException(
            status_code=400,
            detail="Requirement coverage checking is disabled. Enable it in config or use ?force=true.",
        )

    # Get work items
    devops = build_devops(config)
    try:
        work_items = devops.get_work_items()
    except (OSError, ValueError, KeyError):
        work_items = []

    # Walk the project directory for real source files (excludes node_modules, dist, .venv, etc.)
    files = [f.replace("\\", "/") for f in list_files(Path("."))]

    from guard.core.requirement_tracker import check_requirement_coverage

    exclude = config.requirement_coverage_exclude if config.requirement_coverage_exclude else None
    findings = check_requirement_coverage(files, work_items, exclude)

    return {
        "status": "completed",
        "untracked_count": len(findings),
        "untracked_files": [f.evidence.file for f in findings],
        "findings": [f.model_dump(mode="json") for f in findings],
    }


@app.post("/api/generate-reqs", dependencies=[Depends(_require_permission("findings:write"))])
def generate_reqs(push: bool = Query(False), dry_run: bool = Query(False)):
    """Auto-generate requirements from untracked source files using LLM."""
    from guard.core.repo_reader import list_files
    from guard.core.requirement_tracker import check_requirement_coverage
    from guard.core.requirements_generator import (
        generate_requirements,
        generate_requirements_stub,
        get_already_covered_files,
        push_requirements_to_devops,
        write_requirements_yaml,
    )
    from guard.providers.factory import build_llm

    config = _load_config()

    # Get work items
    devops = build_devops(config)
    try:
        work_items = devops.get_work_items()
    except (OSError, ValueError, KeyError):
        work_items = []

    # Walk the project directory for real source files (excludes node_modules, dist, .venv, etc.)
    files = [f.replace("\\", "/") for f in list_files(Path("."))]

    exclude = config.requirement_coverage_exclude if config.requirement_coverage_exclude else None
    findings = check_requirement_coverage(files, work_items, exclude)

    if not findings:
        return {
            "status": "completed",
            "requirements": [],
            "requirements_file": config.requirements_output_file,
            "work_items_created": [],
            "untracked_count": 0,
            "requirements_count": 0,
        }

    untracked = [f.evidence.file for f in findings]

    # Filter out files already covered by existing requirements or work items
    already_covered = get_already_covered_files(
        Path(config.requirements_output_file), work_items,
    )
    untracked = [f for f in untracked if f not in already_covered]

    if not untracked:
        return {
            "status": "completed",
            "requirements": [],
            "requirements_file": config.requirements_output_file,
            "work_items_created": [],
            "untracked_count": 0,
            "requirements_count": 0,
        }

    # Generate requirements via LLM or stub
    llm = build_llm(config)
    repo_root = str(Path(".").resolve())

    if config.llm_provider != "stub" and config.llm_enabled:
        reqs = generate_requirements(untracked, repo_root, llm)
    else:
        reqs = generate_requirements_stub(untracked, repo_root)

    if dry_run:
        return {
            "status": "preview",
            "requirements": [r.model_dump(exclude_none=True) for r in reqs],
            "requirements_file": config.requirements_output_file,
            "work_items_created": [],
            "untracked_count": len(untracked),
            "requirements_count": len(reqs),
        }

    # Write YAML
    output_path = Path(config.requirements_output_file)
    write_requirements_yaml(reqs, output_path)

    work_items_created: list[str] = []
    if push:
        from guard.core.models import WorkItem as WI

        wi_path = Path(config.work_items_file)
        existing: list[WI] = []
        if wi_path.exists():
            with wi_path.open() as f:
                raw = json.load(f)
            existing = [WI(**item) for item in raw]
        wi_type = config.azure_devops_work_item_type
        reqs = push_requirements_to_devops(reqs, devops, existing, wi_path, work_item_type=wi_type)
        work_items_created = [r.work_item_id for r in reqs if r.work_item_id]

    return {
        "status": "completed",
        "requirements": [r.model_dump(exclude_none=True) for r in reqs],
        "requirements_file": config.requirements_output_file,
        "work_items_created": work_items_created,
        "untracked_count": len(untracked),
        "requirements_count": len(reqs),
    }


@app.post("/api/verify-reqs", dependencies=[Depends(_require_permission("findings:read"))])
def verify_reqs_action(dry_run: bool = Query(False)):
    """Verify requirements against source code for drift detection."""
    from guard.core.requirements_verifier import (
        load_requirements,
        verify_requirements,
        verify_requirements_stub,
    )
    from guard.providers.factory import build_llm

    config = _load_config()
    req_path = Path(config.requirements_output_file)

    if not req_path.exists():
        return {"status": "error", "message": "No requirements file found", "findings": []}

    requirements = load_requirements(req_path)
    reqs_with_files = [r for r in requirements if r.source_files and r.status != "rejected"]

    if not reqs_with_files:
        return {"status": "completed", "findings": [], "drift_count": 0}

    repo_root = str(Path(".").resolve())

    if config.llm_provider != "stub" and config.llm_enabled:
        llm = build_llm(config)
        findings = verify_requirements(reqs_with_files, repo_root, llm)
    else:
        findings = verify_requirements_stub(reqs_with_files, repo_root)

    findings_data = [f.model_dump(mode="json") for f in findings]

    if not dry_run:
        out_dir = Path(config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        drift_path = out_dir / "drift_findings.json"
        drift_path.write_text(json.dumps(findings_data, indent=2), encoding="utf-8")

    return {
        "status": "completed",
        "findings": findings_data,
        "drift_count": len(findings),
        "requirements_checked": len(reqs_with_files),
    }


@app.post("/api/pull-reqs", dependencies=[Depends(_require_permission("findings:write"))])
def pull_reqs_action(
    merge: bool = Query(False),
    map_files: bool = Query(False, alias="map-files"),
):
    """Pull requirements from configured DevOps provider into requirements.yaml."""
    from guard.core.pull_reqs import pull_requirements
    from guard.core.repo_reader import list_files

    config = _load_config()

    if config.devops_provider == "stub":
        return {"status": "error", "message": "No DevOps provider configured"}

    devops = build_devops(config)
    output_path = Path(config.requirements_output_file)

    source_files = None
    if map_files:
        source_files = [f.replace("\\", "/") for f in list_files(Path("."))]

    try:
        reqs = pull_requirements(
            devops=devops,
            provider=config.devops_provider,
            output_path=output_path,
            merge=merge,
            map_files=map_files,
            source_files=source_files,
        )
    except (OSError, ValueError, RuntimeError) as exc:
        return {"status": "error", "message": str(exc)}

    return {
        "status": "completed",
        "requirements": [r.model_dump(exclude_none=True) for r in reqs],
        "requirements_file": str(output_path),
        "count": len(reqs),
        "provider": config.devops_provider,
    }


@app.get("/api/onboarding-status")
def onboarding_status():
    """Return onboarding checklist status and health metrics."""
    config = _load_config()
    devops_configured = config.devops_provider != "stub"
    packs_enabled = len(config.standards_packs) > 0
    packs_count = len(config.standards_packs)

    # Check if a scan has been run
    findings_path = Path(config.output_dir) / "findings.json"
    scan_run = findings_path.exists()

    # Load scan metrics for last_scan_time
    last_scan_time = None
    metrics_path = Path(config.output_dir) / "scan_metrics.json"
    if metrics_path.exists():
        try:
            metrics_data = json.loads(metrics_path.read_text(encoding="utf-8"))
            last_scan_time = metrics_data.get("timestamp")
        except (json.JSONDecodeError, OSError):
            pass

    # Count active rules
    rules_active_count = 0
    try:
        from guard.rules.builtins import BUILTIN_RULES
        from guard.providers.factory import _load_pack_rules as load_pr
        _, standards, _, _, _ = build_providers(config)
        rules = BUILTIN_RULES + standards.get_rules() + load_pr(config.standards_packs)
        seen: set[str] = set()
        for r in rules:
            rid = r.get("id", "")
            if rid not in seen:
                seen.add(rid)
                rules_active_count += 1
    except (ImportError, OSError, ValueError, KeyError):
        pass

    # Count findings
    findings_count = 0
    if scan_run:
        try:
            raw = json.loads(findings_path.read_text(encoding="utf-8"))
            findings_count = len(raw)
        except (json.JSONDecodeError, OSError):
            pass

    # DevOps connection status
    devops_connected = False
    if devops_configured:
        try:
            devops = build_devops(config)
            devops.get_work_items()
            devops_connected = True
        except (OSError, ValueError, KeyError):
            pass

    all_complete = devops_configured and packs_enabled and scan_run

    return {
        "steps": {
            "devops_configured": devops_configured,
            "packs_enabled": packs_enabled,
            "packs_count": packs_count,
            "scan_run": scan_run,
        },
        "health": {
            "config_loaded": True,
            "devops_provider": config.devops_provider,
            "devops_connected": devops_connected,
            "packs_enabled_count": packs_count,
            "last_scan_time": last_scan_time,
            "rules_active_count": rules_active_count,
            "findings_count": findings_count,
        },
        "all_complete": all_complete,
    }


@app.get("/api/config/validate", dependencies=[Depends(_require_permission("config:read"))])
def validate_config_endpoint():
    """Validate the current configuration and return warnings."""
    config = _load_config()
    warnings = config.validate_config()
    error_count = sum(1 for w in warnings if w.level == "error")
    warning_count = sum(1 for w in warnings if w.level == "warning")
    return {
        "valid": error_count == 0,
        "warnings": [w.model_dump() for w in warnings],
        "error_count": error_count,
        "warning_count": warning_count,
    }


@app.post("/api/run-scan-stream", dependencies=[Depends(_require_permission("scan"))])
def run_scan_stream():
    """Run a scan with SSE progress events."""
    config = _load_config()
    progress_queue: queue.Queue = queue.Queue()

    def progress_callback(phase: str, progress: float) -> None:
        progress_queue.put({"phase": phase, "progress": progress})

    def run_in_thread():
        try:
            from guard.core.pipeline import run_scan_and_write
            from guard.providers.factory import build_providers
            _, _, scanner, rules_engine, _ = build_providers(config)
            # Call run_scan_and_write with progress events at boundaries
            progress_callback("rules_engine", 0.2)
            findings, gate, out = run_scan_and_write(".", config, rules_engine, scanner)
            progress_callback("complete", 1.0)
            progress_queue.put({
                "phase": "complete", "progress": 1.0,
                "result": {
                    "total_findings": gate.total_findings,
                    "gate_passed": gate.passed,
                    "output_dir": str(out),
                }
            })
        except Exception as e:
            progress_queue.put({"phase": "error", "progress": 1.0, "error": str(e)})
        finally:
            progress_queue.put(None)  # sentinel

    thread = threading.Thread(target=run_in_thread, daemon=True)
    thread.start()

    def event_stream():
        while True:
            item = progress_queue.get()
            if item is None:
                break
            yield f"data: {json.dumps(item)}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@app.get("/api/trends", dependencies=[Depends(_require_permission("findings:read"))])
def get_trends():
    """Return scan history for trends chart.

    Reads from the SQLite metrics DB when available, falling back to the
    file-based history directory for backward compatibility.
    """
    runs: list[dict] = []

    # Try SQLite DB first (richer data)
    try:
        from guard.core.metrics_db import MetricsDB

        db_path = Path(".sentrik") / "local" / "metrics.db"
        if db_path.exists():
            db = MetricsDB(db_path)
            try:
                history = db.get_scan_history(limit=200)
                for row in reversed(history):  # oldest first for charts
                    by_sev = {
                        "critical": row.get("critical", 0),
                        "high": row.get("high", 0),
                        "medium": row.get("medium", 0),
                        "low": row.get("low", 0),
                        "info": row.get("info", 0),
                    }
                    total = sum(by_sev.values())
                    runs.append({
                        "timestamp": row.get("timestamp", ""),
                        "total": total,
                        "by_severity": by_sev,
                        "compliance_score": row.get("compliance_score"),
                        "duration_ms": row.get("duration_ms"),
                        "gate_passed": bool(row["gate_passed"]) if row.get("gate_passed") is not None else None,
                    })
            finally:
                db.close()

            if runs:
                return {"runs": runs}
    except (ImportError, OSError, KeyError, TypeError, ValueError) as exc:
        _logger.warning("Metrics DB read failed, falling back to file-based history: %s", exc, exc_info=True)

    # Fallback: file-based history directory
    config = _load_config()
    history_dir = Path(config.output_dir) / "history"
    if history_dir.exists():
        for metrics_file in sorted(history_dir.glob("scan_metrics_*.json")):
            try:
                data = json.loads(metrics_file.read_text(encoding="utf-8"))
                raw_ts = metrics_file.stem.replace("scan_metrics_", "")
                # Convert 20260305T124322Z → 2026-03-05T12:43:22Z
                if len(raw_ts) >= 15 and "T" in raw_ts:
                    d, t = raw_ts.split("T", 1)
                    t = t.rstrip("Z")
                    ts = f"{d[:4]}-{d[4:6]}-{d[6:8]}T{t[:2]}:{t[2:4]}:{t[4:6]}Z"
                else:
                    ts = raw_ts
                by_sev = data.get("findings_by_severity", {})
                total = sum(by_sev.values()) if by_sev else data.get("total_findings", 0)
                runs.append({"timestamp": ts, "total": total, "by_severity": by_sev})
            except (json.JSONDecodeError, OSError):
                continue
    return {"runs": runs}


@app.get("/api/metrics/history", dependencies=[Depends(_require_permission("findings:read"))])
def get_metrics_history(
    days: int = Query(90, ge=1, le=365, description="Number of days of history"),
    limit: int = Query(50, ge=1, le=500, description="Max records to return"),
):
    """Return scan history and stats from the metrics database."""
    try:
        from guard.core.metrics_db import MetricsDB

        db_path = Path(".sentrik") / "local" / "metrics.db"
        if not db_path.exists():
            return {"scans": [], "trend": [], "compliance_trend": [], "stats": {}}

        db = MetricsDB(db_path)
        try:
            scans = db.get_scan_history(limit=limit)
            trend = db.get_trend_data(days=days)
            compliance_trend = db.get_compliance_trend(days=days)
            stats = db.get_stats()
        finally:
            db.close()

        return {
            "scans": scans,
            "trend": trend,
            "compliance_trend": compliance_trend,
            "stats": stats,
        }
    except (ImportError, OSError, KeyError, TypeError, ValueError) as exc:
        _logger.warning("Failed to read metrics DB: %s", exc, exc_info=True)
        return {"scans": [], "trend": [], "compliance_trend": [], "stats": {}}


@app.get("/api/suppressions", dependencies=[Depends(_require_permission("findings:read"))])
def get_suppressions():
    """Return current suppression rules."""
    config = _load_config()
    suppressions = config.model_dump().get("suppressions", [])
    return {"suppressions": suppressions}


@app.get("/api/audit-bundle", dependencies=[Depends(_require_permission("audit:read"))])
def get_audit_bundle():
    """Create and download a zip bundle of all scan artifacts for auditors."""
    from guard.core.pipeline import export_audit_bundle

    config = _load_config()
    output_dir = Path(config.output_dir)
    if not output_dir.exists():
        raise HTTPException(404, "Output directory does not exist. Run a scan first.")

    bundle_path = export_audit_bundle(output_dir)
    if not bundle_path.exists():
        raise HTTPException(500, "Failed to create audit bundle.")

    from fastapi.responses import FileResponse
    return FileResponse(
        path=str(bundle_path),
        media_type="application/zip",
        filename=bundle_path.name,
        headers={"Content-Disposition": f"attachment; filename={bundle_path.name}"},
    )


@app.get("/api", response_class=HTMLResponse, tags=["docs"])
def api_docs_page():
    """Branded API documentation landing page."""
    endpoints = [
        {"method": "GET", "path": "/health", "desc": "Health check"},
        {"method": "POST", "path": "/scan", "desc": "Run scan on code"},
        {"method": "POST", "path": "/gate", "desc": "Evaluate gate pass/fail"},
        {"method": "POST", "path": "/report", "desc": "Generate a report"},
        {"method": "GET", "path": "/rules", "desc": "List active rules"},
        {"method": "GET", "path": "/api/metrics", "desc": "Scan metrics"},
        {"method": "GET", "path": "/api/config", "desc": "Get configuration"},
        {"method": "POST", "path": "/api/config", "desc": "Update configuration"},
        {"method": "GET", "path": "/api/config/validate", "desc": "Validate configuration"},
        {"method": "GET", "path": "/api/governance", "desc": "Governance settings"},
        {"method": "GET", "path": "/api/audit", "desc": "Audit log entries"},
        {"method": "GET", "path": "/api/packs", "desc": "List standards packs"},
        {"method": "GET", "path": "/api/findings", "desc": "Get scan findings"},
        {"method": "POST", "path": "/api/run-scan", "desc": "Trigger scan via dashboard"},
        {"method": "POST", "path": "/api/run-scan-stream", "desc": "Scan with SSE progress"},
        {"method": "POST", "path": "/api/run-gate", "desc": "Trigger gate via dashboard"},
        {"method": "GET", "path": "/api/work-items", "desc": "List work items"},
        {"method": "POST", "path": "/api/reconcile", "desc": "Reconcile findings with DevOps"},
        {"method": "GET", "path": "/api/trends", "desc": "Scan history for trends"},
        {"method": "GET", "path": "/api/metrics/history", "desc": "Metrics DB history, trends, and stats"},
        {"method": "GET", "path": "/api/license", "desc": "License information"},
        {"method": "GET", "path": "/api/suppressions", "desc": "Suppression rules"},
        {"method": "POST", "path": "/api/generate-reqs", "desc": "Generate requirements"},
        {"method": "POST", "path": "/api/verify-reqs", "desc": "Verify requirements vs code (drift detection)"},
        {"method": "GET", "path": "/api/audit-bundle", "desc": "Download audit bundle zip"},
        {"method": "GET", "path": "/api/licenses", "desc": "Dependency license compliance scan"},
        {"method": "GET", "path": "/api/impact", "desc": "Change impact analysis"},
        {"method": "GET", "path": "/dashboard", "desc": "Management console"},
    ]
    rows = "\n".join(
        f'<tr><td><span style="display:inline-block;padding:2px 8px;border-radius:4px;'
        f'background:{"#22c55e" if e["method"]=="GET" else "#3b82f6"};color:#fff;font-size:0.75rem;'
        f'font-weight:700">{e["method"]}</span></td>'
        f'<td><code>{e["path"]}</code></td><td>{e["desc"]}</td></tr>'
        for e in endpoints
    )
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>SENTRIK API</title>
<style>body{{font-family:-apple-system,sans-serif;max-width:800px;margin:2rem auto;padding:0 1rem;color:#333}}
h1{{border-bottom:2px solid #eee;padding-bottom:.5rem}}
table{{width:100%;border-collapse:collapse;margin:1rem 0}}
th,td{{text-align:left;padding:8px 12px;border-bottom:1px solid #eee}}
th{{background:#f5f5f5}}code{{background:#f0f0f0;padding:2px 4px;border-radius:3px;font-size:0.85em}}
a{{color:#3b82f6}}</style></head><body>
<h1>SENTRIK API</h1>
<p>REST API for scanning code, enforcing gates, and generating reports. Version 1.0.0</p>
<p><a href="/docs">Swagger UI</a> | <a href="/redoc">ReDoc</a> | <a href="/dashboard">Dashboard</a></p>
<table><thead><tr><th>Method</th><th>Endpoint</th><th>Description</th></tr></thead>
<tbody>{rows}</tbody></table>
<p style="color:#999;font-size:0.8rem;margin-top:2rem">
Set <code>GUARD_API_KEY</code> to enable authentication. Pass via <code>X-API-Key</code> header.</p>
</body></html>"""


@app.get("/api/sbom", dependencies=[Depends(_require_permission("findings:read"))])
def sbom_endpoint(
    format: str = Query("cyclonedx", description="SBOM format: 'cyclonedx' or 'spdx'."),
):
    """Generate a Software Bill of Materials (SBOM) from dependency manifests."""
    from guard.core.sbom import (
        SBOMMetadata,
        detect_manifests,
        generate_cyclonedx,
        generate_spdx,
        parse_dependencies,
    )

    config = _load_config()
    repo_root = os.getcwd()
    manifests = detect_manifests(repo_root)

    all_components = []
    seen: set[tuple[str, str, str]] = set()
    for m in manifests:
        for comp in parse_dependencies(m):
            key = (comp.ecosystem, comp.name, comp.version)
            if key not in seen:
                seen.add(key)
                all_components.append(comp)

    project_name = Path(repo_root).name
    meta = SBOMMetadata(name=project_name)

    fmt = format.lower()
    if fmt == "spdx":
        return generate_spdx(all_components, meta)
    elif fmt in ("cyclonedx", "cdx"):
        return generate_cyclonedx(all_components, meta)
    else:
        raise HTTPException(status_code=400, detail=f"Unknown format '{format}'. Use 'cyclonedx' or 'spdx'.")


@app.get("/api/vulns", dependencies=[Depends(_require_permission("findings:read"))])
def vulns_endpoint(
    refresh: bool = Query(False, description="Force a fresh scan instead of reading cached results."),
):
    """Return vulnerability scan results.

    By default, reads cached results from ``out/vulnerabilities.json``
    (written by ``sentrik vulns`` CLI). Pass ``?refresh=true`` to trigger
    a live scan against OSV.dev.
    """
    config = _load_config()
    cached_path = Path(config.output_dir) / "vulnerabilities.json"

    # Return cached results if available and refresh not requested
    if not refresh and cached_path.exists():
        try:
            import json as _json
            return _json.loads(cached_path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            pass

    # Live scan
    from guard.core.sbom import detect_manifests, parse_dependencies
    from guard.core.vuln_scanner import result_to_dict, scan_dependencies

    repo_root = os.getcwd()
    manifests = detect_manifests(repo_root)

    all_components = []
    seen: set[tuple[str, str, str]] = set()
    for m in manifests:
        for comp in parse_dependencies(m):
            key = (comp.ecosystem, comp.name, comp.version)
            if key not in seen:
                seen.add(key)
                all_components.append(comp)

    result = scan_dependencies(all_components)
    data = result_to_dict(result)

    # Cache results
    try:
        Path(config.output_dir).mkdir(parents=True, exist_ok=True)
        import json as _json
        cached_path.write_text(_json.dumps(data, indent=2), encoding="utf-8")
    except OSError as exc:
        _logger.warning("Failed to write cache: %s", exc)

    return data


@app.get("/api/vulns/report", dependencies=[Depends(_require_permission("findings:read"))])
def vulns_report_endpoint():
    """Generate an HTML vulnerability report from cached or live scan results."""
    from guard.core.vuln_scanner import generate_vuln_html_report

    # Get the data (reuse the vulns endpoint logic)
    data = vulns_endpoint(refresh=False)

    html = generate_vuln_html_report(data)
    return {
        "html": html,
        "vulnerable_count": data.get("vulnerable_count", 0),
        "total_dependencies": data.get("total_dependencies", 0),
    }


@app.get("/api/licenses", dependencies=[Depends(_require_permission("findings:read"))])
def licenses_endpoint(
    refresh: bool = Query(False, description="Force a fresh license scan instead of reading cached results."),
):
    """Return dependency license scan results.

    Detects project manifests, parses dependencies, and queries registries
    (PyPI, npm) for license metadata.  Results are cached in
    ``out/licenses.json``.
    """
    config = _load_config()
    cached_path = Path(config.output_dir) / "licenses.json"

    if not refresh and cached_path.exists():
        try:
            import json as _json
            return _json.loads(cached_path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            pass

    from guard.core.license_scanner import scan_licenses, result_to_dict
    from guard.core.sbom import detect_manifests, parse_dependencies

    repo_root = os.getcwd()
    manifests = detect_manifests(repo_root)

    all_components = []
    seen: set[tuple[str, str, str]] = set()
    for m in manifests:
        for comp in parse_dependencies(m):
            key = (comp.ecosystem, comp.name, comp.version)
            if key not in seen:
                seen.add(key)
                all_components.append(comp)

    result = scan_licenses(all_components)
    data = result_to_dict(result)

    # Cache
    try:
        Path(config.output_dir).mkdir(parents=True, exist_ok=True)
        import json as _json
        cached_path.write_text(_json.dumps(data, indent=2), encoding="utf-8")
    except OSError as exc:
        _logger.warning("Failed to write license cache: %s", exc)

    return data


@app.get("/api/impact", dependencies=[Depends(_require_permission("findings:read"))])
def impact_endpoint(
    git_range: str = Query("", description="Git range for diff, e.g. origin/main...HEAD"),
    staged: bool = Query(False, description="Analyze staged changes instead of a git range"),
):
    """Analyze which rules, requirements, and frameworks are affected by changed files."""
    from guard.core.impact_analysis import analyze_impact, get_changed_files_from_git, report_to_dict
    from guard.providers.factory import _load_pack_rules

    config = _load_config()
    repo_root = os.getcwd()

    # Get changed files
    if staged or not git_range:
        changed_files = get_changed_files_from_git(git_range=None, repo_root=repo_root)
    else:
        changed_files = get_changed_files_from_git(git_range=git_range, repo_root=repo_root)

    # Load rules from configured providers + packs
    from guard.providers.factory import build_standards
    standards = build_standards(config)
    rules = standards.get_rules() + _load_pack_rules(config.standards_packs, license_key=config.license_key)
    rule_dicts = []
    for r in rules:
        rd = r if isinstance(r, dict) else r.__dict__ if hasattr(r, '__dict__') else {}
        rule_dicts.append(rd)

    # Load requirements if available
    requirements = None
    reqs_path = Path(config.output_dir) / "requirements.yaml"
    if reqs_path.exists():
        try:
            from guard.core.models import GeneratedRequirement
            import yaml
            raw = yaml.safe_load(reqs_path.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                requirements = [GeneratedRequirement(**r) for r in raw]
        except (yaml.YAMLError, OSError, TypeError, ValueError) as exc:
            _logger.warning("Failed to load requirements from %s: %s", reqs_path, exc)

    report = analyze_impact(changed_files, rule_dicts, requirements)
    return report_to_dict(report)


_DASHBOARD_HTML_PATH = Path(__file__).parent / "dashboard.html"


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    """Serve an interactive HTML dashboard with management console."""
    return _DASHBOARD_HTML_PATH.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Auditor Portal — time-boxed, read-only access for external auditors
# ---------------------------------------------------------------------------

_AUDITOR_HTML_PATH = Path(__file__).parent / "auditor_portal.html"


@app.get("/auditor", response_class=HTMLResponse)
def auditor_portal_page():
    """Serve the auditor portal HTML page.

    The page itself handles token validation via the /api/auditor/portal-data
    endpoint — no server-side auth gate here so the page can show a
    user-friendly "Access Denied" message for invalid tokens.
    """
    return _AUDITOR_HTML_PATH.read_text(encoding="utf-8")


def _strip_file_paths(file_path: str) -> str:
    """Convert an absolute file path to a safe relative form for auditors."""
    from pathlib import PurePosixPath, PureWindowsPath
    try:
        p = PureWindowsPath(file_path)
    except Exception:
        p = PurePosixPath(file_path)
    # Return just the filename (no parent directories)
    return p.name


@app.get("/api/auditor/portal-data")
def auditor_portal_data(token: str = Query("", description="Auditor access token")):
    """Return read-only portal data for a valid auditor token.

    No source code, full file paths, configuration secrets, or API keys
    are included in the response.
    """
    from guard.core.auditor_portal import validate_auditor_token
    from guard.core.comparison import load_findings

    tok = validate_auditor_token(token)
    if not tok:
        raise HTTPException(403, "Invalid or expired auditor token")

    config = _load_config()
    out = Path(config.output_dir)
    scope = tok.access_scope

    result: dict[str, Any] = {
        "auditor_name": tok.auditor_name,
        "auditor_email": tok.auditor_email,
        "expires_at": tok.expires_at,
        "access_scope": scope,
    }

    # Metrics
    metrics: dict[str, Any] = {}
    metrics_path = out / "scan_metrics.json"
    if metrics_path.exists():
        try:
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    safe_metrics: dict[str, Any] = {}
    safe_metrics["total_findings"] = metrics.get("total_findings")
    safe_metrics["by_severity"] = metrics.get("by_severity", {})
    safe_metrics["compliance_score"] = metrics.get("compliance_score", {})
    safe_metrics["total_duration_ms"] = metrics.get("total_duration_ms")
    safe_metrics["files_scanned"] = metrics.get("files_scanned")
    result["metrics"] = safe_metrics

    # Findings by rule (no file paths, no code)
    if "findings" in scope:
        findings = load_findings(out / "findings.json")
        rule_counts: dict[str, dict[str, Any]] = {}
        for f in findings:
            rid = f.rule_id
            if rid not in rule_counts:
                rule_counts[rid] = {"rule_id": rid, "severity": f.severity.value, "count": 0}
            rule_counts[rid]["count"] += 1
        result["findings_by_rule"] = list(rule_counts.values())

    # Frameworks
    if "compliance" in scope:
        findings = load_findings(out / "findings.json")
        fw_map: dict[str, dict[str, Any]] = {}
        for f in findings:
            fw_name = f.standard or "General"
            if fw_name not in fw_map:
                fw_map[fw_name] = {"name": fw_name, "findings": 0, "has_critical": False}
            fw_map[fw_name]["findings"] += 1
            if f.severity.value == "critical":
                fw_map[fw_name]["has_critical"] = True
        result["frameworks"] = list(fw_map.values())

    # Audit log (sanitised — no file paths)
    if "audit_log" in scope:
        audit_path = out / "agent_audit.jsonl"
        entries: list[dict] = []
        if audit_path.exists():
            try:
                for line in audit_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line:
                        try:
                            entry = json.loads(line)
                            # Strip sensitive fields
                            entry.pop("config", None)
                            entry.pop("files", None)
                            entries.append(entry)
                        except json.JSONDecodeError:
                            pass
            except OSError as exc:
                _logger.warning("Failed to read audit log: %s", exc)
        result["audit_log"] = entries

    # Trends
    if "trends" in scope:
        trends_path = out / "findings_history.json"
        trends: list[dict] = []
        if trends_path.exists():
            try:
                raw_trends = json.loads(trends_path.read_text(encoding="utf-8"))
                for t in raw_trends:
                    trends.append({
                        "date": t.get("date", ""),
                        "total": t.get("total", 0),
                        "critical": t.get("critical", 0),
                        "high": t.get("high", 0),
                        "medium": t.get("medium", 0),
                        "low": t.get("low", 0),
                        "info": t.get("info", 0),
                    })
            except (json.JSONDecodeError, OSError):
                pass
        result["trends"] = trends

    return result


@app.get("/api/auditor/download")
def auditor_download(
    token: str = Query("", description="Auditor access token"),
    type: str = Query("compliance", description="Report type: compliance, evidence, trust-center"),
):
    """Download a report for a valid auditor token."""
    from guard.core.auditor_portal import validate_auditor_token

    tok = validate_auditor_token(token)
    if not tok:
        raise HTTPException(403, "Invalid or expired auditor token")
    if "evidence" not in tok.access_scope:
        raise HTTPException(403, "Evidence downloads not in scope for this token")

    config = _load_config()
    out = Path(config.output_dir)

    if type == "compliance":
        from guard.reporters.compliance_report import generate_compliance_report
        findings = load_findings(out / "findings.json")
        html = generate_compliance_report(findings)
        return HTMLResponse(html, media_type="text/html")

    elif type == "evidence":
        from guard.core.evidence_export import (
            collect_evidence,
            generate_evidence_html,
            generate_evidence_package,
            list_available_frameworks,
        )
        frameworks = list_available_frameworks()
        fw = frameworks[0] if frameworks else "General"
        items = collect_evidence(config.output_dir, fw)
        package = generate_evidence_package(items, framework=fw, project_name=Path(".").resolve().name)
        html = generate_evidence_html(package)
        return HTMLResponse(html, media_type="text/html")

    elif type == "trust-center":
        from guard.reporters.trust_center import generate_trust_center
        findings = load_findings(out / "findings.json")
        html = generate_trust_center(findings)
        return HTMLResponse(html, media_type="text/html")

    raise HTTPException(400, f"Unknown report type: {type}")


# ---------------------------------------------------------------------------
# SDK endpoints — compliance checking for AI coding agents
# ---------------------------------------------------------------------------


class SDKCheckRequest(BaseModel):
    """Request body for POST /api/sdk/check."""
    code: str
    filename: str
    frameworks: list[str] | None = None


@app.post("/api/sdk/check", dependencies=[Depends(_require_permission("findings:write"))])
def sdk_check(body: SDKCheckRequest):
    """Check code for compliance violations (AI agent SDK endpoint)."""
    from guard.sdk.checker import check_code

    result = check_code(body.code, body.filename, body.frameworks)
    return {
        "compliant": result.compliant,
        "findings": result.findings,
        "suggestions": result.suggestions,
        "confidence": result.confidence,
    }


@app.get("/api/sdk/context", dependencies=[Depends(_require_permission("findings:read"))])
def sdk_context(filename: str = Query(..., description="Target file path")):
    """Return compliance context for a file (AI agent SDK endpoint)."""
    from guard.sdk.checker import get_compliance_context

    return get_compliance_context(filename)


@app.get("/api/sdk/rules", dependencies=[Depends(_require_permission("findings:read"))])
def sdk_rules(
    filename: str = Query(..., description="Target file path"),
    frameworks: str = Query("", description="Comma-separated framework names"),
):
    """Return applicable rules for a file (AI agent SDK endpoint)."""
    from guard.sdk.checker import get_rules_for_file

    fw_list = [f.strip() for f in frameworks.split(",") if f.strip()] or None
    return get_rules_for_file(filename, fw_list)


# ---------------------------------------------------------------------------
# AI Chat — interactive fix assistant
# ---------------------------------------------------------------------------


_CHAT_MAX_TOTAL_BYTES = 50 * 1024  # 50 KB limit for chat request content


class ChatRequest(BaseModel):
    """Request body for POST /api/chat."""
    messages: list[dict[str, str]]  # [{"role": "user", "content": "..."}, ...]
    finding_context: Optional[dict[str, Any]] = None
    file_path: Optional[str] = None


class ApplyFixRequest(BaseModel):
    """Request body for POST /api/apply-fix."""
    file_path: str
    original_code: str
    fixed_code: str
    start_line: int
    end_line: int


def _extract_code_fix(response_text: str) -> dict[str, Any] | None:
    """Extract a code block from the LLM response as a suggested fix.

    Looks for fenced code blocks (```lang ... ```) and returns the first
    one that looks like a substantive code fix (>1 line or >20 chars).
    """
    import re
    pattern = re.compile(r"```(?:\w*)\n(.*?)```", re.DOTALL)
    matches = pattern.findall(response_text)
    for code in matches:
        code = code.strip()
        if len(code) > 20 or code.count("\n") > 0:
            return {"code": code, "start_line": None, "end_line": None}
    return None


@app.post("/api/chat", dependencies=[Depends(_require_permission("findings:write"))])
def chat_endpoint(req: ChatRequest):
    """Interactive AI chat for fixing compliance findings."""
    # Enforce size limit to prevent resource exhaustion
    total_size = sum(len(m.get("content", "")) for m in req.messages)
    if req.finding_context:
        total_size += len(json.dumps(req.finding_context))
    if total_size > _CHAT_MAX_TOTAL_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"Request content too large ({total_size} bytes). Maximum is {_CHAT_MAX_TOTAL_BYTES} bytes.",
        )
    config = _load_config()

    if config.llm_provider == "stub":
        raise HTTPException(
            status_code=400,
            detail="No LLM provider configured. Set llm_provider to 'anthropic', "
                   "'openai', or 'ollama' in your config (or set the corresponding "
                   "environment variables).",
        )

    from guard.providers.factory import build_llm

    llm = build_llm(config)

    # Build system prompt with finding context
    system_parts = [
        "You are sentrik, an AI compliance assistant for software development. Never capitalize sentrik — it is always lowercase.",
        "You help developers fix compliance findings by suggesting corrected code.",
        "When suggesting a fix, include the corrected code in a fenced code block (```language).",
        "Be concise and focus on the specific issue.",
    ]

    if req.finding_context:
        fc = req.finding_context
        system_parts.append("\n--- Finding Context ---")
        if fc.get("rule_id"):
            system_parts.append(f"Rule: {fc['rule_id']}")
        if fc.get("severity"):
            system_parts.append(f"Severity: {fc['severity']}")
        if fc.get("message"):
            system_parts.append(f"Issue: {fc['message']}")
        if fc.get("standard"):
            system_parts.append(f"Standard: {fc['standard']}")
        if fc.get("clause"):
            system_parts.append(f"Clause: {fc['clause']}")
        if fc.get("remediation"):
            system_parts.append(f"Remediation guidance: {fc['remediation']}")
        if fc.get("suggestion"):
            system_parts.append(f"Suggestion: {fc['suggestion']}")

        # Detect vulnerability context (evidence.file == 'dependencies')
        ev = fc.get("evidence", {})
        if ev.get("file") == "dependencies":
            system_parts.append("\nThis is a DEPENDENCY VULNERABILITY, not a code finding.")
            system_parts.append("Help the user understand: where this package is used in their project, what the vulnerability means, what could break on upgrade, and how to remediate.")
            system_parts.append("You can suggest running: sentrik vulns --fix to auto-patch, or sentrik vulns --fix --create-pr to open a PR.")
        if ev.get("file"):
            system_parts.append(f"File: {ev['file']}")
        if ev.get("lines"):
            system_parts.append(f"Lines: {ev['lines']}")
        if ev.get("matched_text") or ev.get("snippet"):
            system_parts.append(f"Code snippet: {ev.get('matched_text') or ev.get('snippet')}")

    # Read the full file content if available
    if req.file_path:
        base = Path.cwd().resolve()
        target = (base / req.file_path).resolve()
        try:
            target.relative_to(base)
        except ValueError:
            _logger.warning("Path traversal attempt in chat context: %s", req.file_path)
            target = None
        if target and target.is_file():
            try:
                content = target.read_text(encoding="utf-8", errors="replace")
                system_parts.append(f"\n--- Full file content ({req.file_path}) ---")
                system_parts.append(content)
            except OSError as exc:
                _logger.debug("Could not read file for chat context: %s", exc)

    system_prompt = "\n".join(system_parts)

    try:
        response_text = llm.chat(req.messages, system=system_prompt)
    except Exception as exc:
        _logger.warning("LLM chat call failed: %s", exc)
        raise HTTPException(status_code=502, detail=f"LLM provider error: {exc}")

    suggested_fix = _extract_code_fix(response_text)

    return {
        "response": response_text,
        "suggested_fix": suggested_fix,
    }


class ProfileChatRequest(BaseModel):
    """Request body for POST /api/profile-chat."""
    messages: list[dict[str, str]]


@app.post("/api/profile-chat", dependencies=[Depends(_require_permission("scan"))])
def profile_chat_endpoint(req: ProfileChatRequest):
    """Interactive AI chat scoped to the current project profile."""
    total_size = sum(len(m.get("content", "")) for m in req.messages)
    if total_size > _CHAT_MAX_TOTAL_BYTES:
        raise HTTPException(status_code=413, detail="Request too large.")

    config = _load_config()
    if config.llm_provider == "stub":
        raise HTTPException(
            status_code=400,
            detail="No LLM provider configured. Set llm_provider in your Sentrik config.",
        )

    from guard.providers.factory import build_llm
    from guard.core.project_profile import load_profile, _read_profile_context

    llm = build_llm(config)
    profile = load_profile(config.output_dir) or {}
    root = _get_repo_root()

    # Build a rich system prompt from the saved profile
    name = profile.get("name") or "this project"
    languages = ", ".join(profile.get("languages", [])) or "unknown"
    frameworks = ", ".join(f["name"] for f in profile.get("frameworks", [])) or "none detected"
    arch = ", ".join(p["pattern"] for p in profile.get("architecture", [])) or "none detected"
    signals = ", ".join(s["signal"] for s in profile.get("compliance_signals", [])) or "none detected"
    summary = profile.get("llm_summary", "")
    recs = "\n".join(f"- {r}" for r in profile.get("recommendations", []))
    # Read context directly from disk so manual edits to profile-context.md are reflected
    context_md = _read_profile_context(root) or profile.get("profile_context", "")

    system_parts = [
        "You are sentrik, an AI compliance and architecture assistant. Never capitalize sentrik.",
        f"You are discussing the project: {name}",
        f"Languages: {languages}",
        f"Frameworks: {frameworks}",
        f"Architecture patterns: {arch}",
        f"Compliance signals: {signals}",
    ]
    if summary:
        system_parts.append(f"\nArchitectural summary: {summary}")
    if recs:
        system_parts.append(f"\nCurrent recommendations:\n{recs}")
    if context_md:
        system_parts.append(f"\nProject context:\n{context_md[:2000]}")
    system_parts.append(
        "\nAnswer questions about the project's architecture, compliance posture, "
        "recommended Sentrik packs, and how to address gaps. Be concise and specific."
    )

    system_prompt = "\n".join(system_parts)

    try:
        response_text = llm.chat(req.messages, system=system_prompt)
    except Exception as exc:
        _logger.warning("Profile chat LLM call failed: %s", exc)
        raise HTTPException(status_code=502, detail=f"LLM provider error: {exc}")

    return {"response": response_text}


@app.post("/api/ai-key")
def set_ai_key(req: dict, _auth=Depends(_check_api_key)):
    """Set the LLM API key as an environment variable for the current session.

    The key is stored in the process environment only — it is never written
    to config files or persisted to disk.
    """
    provider = req.get("provider", "")
    api_key = req.get("api_key", "")
    if not api_key:
        raise HTTPException(400, "api_key is required")

    env_map = {
        "anthropic": "ANTHROPIC_API_KEY",
        "openai": "OPENAI_API_KEY",
    }
    env_var = env_map.get(provider)
    if env_var:
        os.environ[env_var] = api_key
        return {"status": "ok", "env_var": env_var, "message": f"API key set for {provider} (session only)"}
    elif provider == "ollama":
        return {"status": "ok", "message": "Ollama does not require an API key"}
    else:
        raise HTTPException(400, f"Unknown provider: {provider}")


@app.post("/api/vuln-fix")
def vuln_fix_endpoint(req: dict, _auth=Depends(_check_api_key)):
    """Apply a single dependency version fix."""
    from guard.core.sbom import detect_manifests, parse_dependencies
    from guard.core.vuln_fixer import FixAction, apply_fixes

    package = req.get("package", "")
    fixed_version = req.get("fixed_version", "")
    if not package or not fixed_version:
        raise HTTPException(400, "package and fixed_version are required")

    repo_root = os.getcwd()
    manifests = detect_manifests(repo_root)

    # Find which manifest contains this package
    target_manifest = None
    for m in manifests:
        for comp in parse_dependencies(m):
            if comp.name.lower() == package.lower():
                target_manifest = str(m)
                break
        if target_manifest:
            break

    if not target_manifest:
        raise HTTPException(404, f"Package '{package}' not found in any manifest")

    action = FixAction(
        package=package,
        current_version="",
        fixed_version=fixed_version,
        manifest_file=target_manifest,
    )
    report = apply_fixes([action])

    if report.applied_count > 0:
        return {"status": "ok", "manifest": target_manifest, "package": package, "version": fixed_version}
    else:
        errors = [a.error for a in report.actions if a.error]
        raise HTTPException(500, f"Fix failed: {'; '.join(errors) or 'unknown error'}")


@app.post("/api/apply-fix")
def apply_fix_endpoint(req: ApplyFixRequest, _auth=Depends(_check_api_key)):
    """Apply a code fix suggested by the AI chat assistant."""
    import shutil

    base = Path.cwd().resolve()

    # Security: prevent path traversal — check BEFORE resolving symlinks
    # to catch attempts using ../../../etc/passwd
    raw_target = base / req.file_path
    try:
        raw_target.resolve().relative_to(base)
    except ValueError:
        raise HTTPException(status_code=400, detail="File path outside project root")

    target = raw_target.resolve()

    # Reject symlinks that escape the project root
    if target.is_symlink() or any(p.is_symlink() for p in raw_target.parents if p != base):
        try:
            target.relative_to(base)
        except ValueError:
            raise HTTPException(status_code=400, detail="Symlink target outside project root")

    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")

    try:
        content = target.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Cannot read file: {exc}")

    lines = content.splitlines(keepends=True)

    # Validate line range
    if req.start_line < 1 or req.end_line < req.start_line:
        raise HTTPException(status_code=400, detail="Invalid line range")
    if req.end_line > len(lines):
        raise HTTPException(status_code=400, detail=f"end_line ({req.end_line}) exceeds file length ({len(lines)})")

    # Soft verification: warn but don't block if original doesn't match exactly
    # (whitespace differences, encoding, or snippet context mismatch are common)
    original_from_file = "".join(lines[req.start_line - 1 : req.end_line]).strip()
    expected_original = req.original_code.strip()
    if expected_original and original_from_file != expected_original:
        # Log the mismatch but proceed — the backup file provides safety
        _logger.info("Apply-fix: original code mismatch at lines %d-%d (proceeding with backup)", req.start_line, req.end_line)

    # Create backup
    backup_path = target.with_suffix(target.suffix + ".bak")
    try:
        shutil.copy2(str(target), str(backup_path))
    except OSError as exc:
        _logger.warning("Could not create backup: %s", exc)

    # Apply the fix
    fixed_lines = req.fixed_code.splitlines(keepends=True)
    # Ensure last line has newline if original did
    if fixed_lines and not fixed_lines[-1].endswith("\n"):
        fixed_lines[-1] += "\n"

    new_lines = lines[: req.start_line - 1] + fixed_lines + lines[req.end_line :]
    new_content = "".join(new_lines)

    try:
        target.write_text(new_content, encoding="utf-8")
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Cannot write file: {exc}")

    return {
        "success": True,
        "file": req.file_path,
        "backup": str(backup_path.relative_to(base)),
        "lines_replaced": req.end_line - req.start_line + 1,
        "lines_inserted": len(fixed_lines),
    }


# ── New Feature Endpoints ──────────────────────────────────────


@app.get("/api/quality-score", dependencies=[Depends(_require_permission("findings:read"))])
def quality_score_endpoint():
    """Return quality score history from out/quality_history.json."""
    config = _load_config()
    p = Path(config.output_dir) / "quality_history.json"
    if p.exists():
        try:
            import json as _json
            return _json.loads(p.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            pass
    return []


@app.get("/api/project-profile", dependencies=[Depends(_require_permission("findings:read"))])
def project_profile_endpoint():
    """Return project profile from out/project-profile.json."""
    config = _load_config()
    p = Path(config.output_dir) / "project-profile.json"
    if p.exists():
        try:
            import json as _json
            return _json.loads(p.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            pass
    return {}


@app.get("/api/design-decisions", dependencies=[Depends(_require_permission("findings:read"))])
def design_decisions_endpoint():
    """Return design decisions including metadata from out/design_decisions.json."""
    from guard.core.design_reviewer import load_decisions_with_meta
    config = _load_config()
    return load_decisions_with_meta(config.output_dir)


@app.post("/api/design-decisions/ack", dependencies=[Depends(_require_permission("findings:write"))])
def ack_design_decision(decision_id: str = Query(...), note: str = Query("")):
    """Acknowledge a design decision."""
    config = _load_config()
    p = Path(config.output_dir) / "design_decisions.json"
    if not p.exists():
        raise HTTPException(status_code=404, detail="No design decisions found")
    import json as _json
    raw = _json.loads(p.read_text(encoding="utf-8"))
    # Support both old bare-list and new dict format
    if isinstance(raw, list):
        decisions = raw
        meta: dict = {}
    else:
        decisions = raw.get("decisions", [])
        meta = {k: v for k, v in raw.items() if k != "decisions"}
    for d in decisions:
        if d.get("decision_id") == decision_id:
            d["acknowledged"] = True
            d["acknowledgment_note"] = note
            out = {**meta, "decisions": decisions}
            p.write_text(_json.dumps(out, indent=2), encoding="utf-8")
            return {"success": True, "decision_id": decision_id}
    raise HTTPException(status_code=404, detail=f"Decision {decision_id} not found")


@app.post("/api/design-decisions/unack", dependencies=[Depends(_require_permission("findings:write"))])
def unack_design_decision(decision_id: str = Query(...)):
    """Unacknowledge a previously acknowledged design decision."""
    config = _load_config()
    p = Path(config.output_dir) / "design_decisions.json"
    if not p.exists():
        raise HTTPException(status_code=404, detail="No design decisions found")
    import json as _json
    raw = _json.loads(p.read_text(encoding="utf-8"))
    if isinstance(raw, list):
        decisions = raw
        meta: dict = {}
    else:
        decisions = raw.get("decisions", [])
        meta = {k: v for k, v in raw.items() if k != "decisions"}
    for d in decisions:
        if d.get("decision_id") == decision_id:
            d["acknowledged"] = False
            d["acknowledgment_note"] = ""
            out = {**meta, "decisions": decisions}
            p.write_text(_json.dumps(out, indent=2), encoding="utf-8")
            return {"success": True, "decision_id": decision_id}
    raise HTTPException(status_code=404, detail=f"Decision {decision_id} not found")


class DesignChatRequest(BaseModel):
    """Request body for POST /api/design-chat."""
    messages: list[dict[str, str]]
    decision_id: str = ""


@app.post("/api/design-chat", dependencies=[Depends(_require_permission("scan"))])
def design_chat_endpoint(req: DesignChatRequest):
    """Interactive AI chat scoped to a specific design decision."""
    total_size = sum(len(m.get("content", "")) for m in req.messages)
    if total_size > _CHAT_MAX_TOTAL_BYTES:
        raise HTTPException(status_code=413, detail="Request too large.")

    config = _load_config()
    if config.llm_provider == "stub":
        raise HTTPException(status_code=400,
            detail="No LLM provider configured. Set llm_provider in your Sentrik config.")

    from guard.providers.factory import build_llm
    from guard.core.design_reviewer import load_decisions_with_meta

    llm = build_llm(config)
    meta = load_decisions_with_meta(config.output_dir)
    decisions = meta.get("decisions", [])

    # Find the specific decision if an ID was given
    decision = next((d for d in decisions if d.get("decision_id") == req.decision_id), None)

    root = _get_repo_root()

    if decision:
        # Load actual file contents so the AI can cite specific lines
        file_snippet = ""
        file_path_str = decision.get("file", "")
        if file_path_str:
            candidate = root / file_path_str
            if not candidate.is_file():
                # Try treating it as absolute or relative to cwd
                candidate = Path(file_path_str)
            if candidate.is_file():
                try:
                    lines = candidate.read_text(encoding="utf-8", errors="replace").splitlines()
                    line_start = decision.get("line_start") or 1
                    line_end = decision.get("line_end") or line_start
                    # Include generous context: 30 lines before and after the flagged range
                    ctx_start = max(0, line_start - 31)
                    ctx_end = min(len(lines), line_end + 30)
                    numbered = "\n".join(
                        f"{i+1:>5}: {l}" for i, l in enumerate(lines[ctx_start:ctx_end], start=ctx_start)
                    )
                    file_snippet = (
                        f"\nFILE CONTENTS ({file_path_str}, lines {ctx_start+1}–{ctx_end}):\n"
                        f"```\n{numbered}\n```\n"
                    )
                    # If the file is large, also include a broader scan for the pattern
                    # to surface all usages (e.g. shared_ptr across the whole file)
                    if len(lines) > ctx_end - ctx_start + 5:
                        full_numbered = "\n".join(f"{i+1:>5}: {l}" for i, l in enumerate(lines))
                        # Cap at ~400 lines to stay within context
                        if len(lines) <= 400:
                            file_snippet = (
                                f"\nFULL FILE CONTENTS ({file_path_str}):\n"
                                f"```\n{full_numbered}\n```\n"
                            )
                except OSError:
                    pass

        system_prompt = (
            "You are sentrik, an AI architecture assistant. Never capitalize sentrik.\n"
            "You have access to the actual source code for this design decision. "
            "When the developer asks about specific usages, patterns, or line numbers, "
            "reference the file contents below directly — quote line numbers and code snippets. "
            "Do NOT tell the developer to search for things you can already see in the code.\n\n"
            "DESIGN DECISION:\n"
            f"  ID: {decision.get('decision_id')}\n"
            f"  Category: {decision.get('category')}\n"
            f"  Summary: {decision.get('summary')}\n"
            f"  File: {decision.get('file')}:{decision.get('line_start', '')}\n"
            f"  Risk: {decision.get('risk', '')}\n"
            f"  Alternatives: {', '.join(decision.get('alternatives', []))}\n"
            f"  Review question: {decision.get('question', '')}\n"
            f"{file_snippet}\n"
            "Help the developer understand the tradeoffs and whether to accept or change this decision. "
            "Be concrete — cite specific line numbers from the code above when relevant."
        )
    else:
        # General design decisions chat — include all decision files
        all_summaries = "\n".join(
            f"- [{d.get('category')}] {d.get('summary')} ({d.get('file')}:{d.get('line_start', '')})"
            for d in decisions[:20]
        ) or "None loaded yet."
        system_prompt = (
            "You are sentrik, an AI architecture assistant. Never capitalize sentrik.\n"
            "You are discussing design decisions found in this project.\n\n"
            f"Detected decisions:\n{all_summaries}\n\n"
            "Help the developer understand architectural tradeoffs, risks, and how to address gaps. "
            "Be concise and specific."
        )

    try:
        response_text = llm.chat(req.messages, system=system_prompt)
    except Exception as exc:
        _logger.warning("Design chat LLM call failed: %s", exc)
        raise HTTPException(status_code=502, detail=f"LLM provider error: {exc}")

    return {"response": response_text}


@app.get("/api/developer-profiles", dependencies=[Depends(_require_permission("findings:read"))])
def developer_profiles_endpoint():
    """Return developer expertise profiles from out/developer_profiles.json."""
    config = _load_config()
    p = Path(config.output_dir) / "developer_profiles.json"
    if p.exists():
        try:
            import json as _json
            return _json.loads(p.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            pass
    return {}


@app.get("/api/attestation", dependencies=[Depends(_require_permission("findings:read"))])
def attestation_endpoint():
    """Return latest attestation from out/attestation.json."""
    config = _load_config()
    p = Path(config.output_dir) / "attestation.json"
    if p.exists():
        try:
            import json as _json
            return _json.loads(p.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            pass
    return {}


@app.get("/api/threat-model", dependencies=[Depends(_require_permission("findings:read"))])
def threat_model_endpoint():
    """Return threat model from out/threat_model.json."""
    config = _load_config()
    p = Path(config.output_dir) / "threat_model.json"
    if p.exists():
        try:
            import json as _json
            return _json.loads(p.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            pass
    return []


def _run_sentrik_command(args: list[str]) -> dict:
    """Run a sentrik CLI command as a subprocess and return status + output."""
    import subprocess
    import sys
    result = subprocess.run(
        [sys.executable, "-m", "guard.cli"] + args,
        capture_output=True,
        text=True,
        cwd=str(Path(".").resolve()),
    )
    return {
        "status": "completed" if result.returncode == 0 else "failed",
        "returncode": result.returncode,
        "output": result.stdout.strip(),
        "error": result.stderr.strip() if result.returncode != 0 else "",
    }


@app.post("/api/run-profile", dependencies=[Depends(_require_permission("scan"))])
def run_profile_action():
    """Build/refresh the project profile, with LLM-powered insights if an LLM is configured."""
    import re as _re
    from guard.core.project_profile import (
        build_project_profile,
        save_profile,
        _read_scan_insights,
        _read_profile_context,
        save_profile_context,
    )

    config = _load_config()
    root = _get_repo_root()

    # Step 1: full source-tree heuristic analysis (respects scan_exclude)
    profile = build_project_profile(
        root,
        scan_exclude=config.scan_exclude if hasattr(config, "scan_exclude") else [],
        enabled_packs=config.standards_packs if hasattr(config, "standards_packs") else [],
    )

    # Step 2: LLM interpretation — three-layer context enrichment
    if config.llm_provider != "stub":
        try:
            from guard.providers.factory import build_llm
            llm = build_llm(config)

            arch_list = ", ".join(p["pattern"] for p in profile.get("architecture", [])) or "none detected"
            signal_list = ", ".join(s["signal"] for s in profile.get("compliance_signals", [])) or "none"
            fw_list = ", ".join(f['name'] for f in profile.get("frameworks", [])) or "none"
            top_imports_str = ", ".join(
                f"{i['module']} ({i['importers']} importers)"
                for i in profile.get("top_imports", [])[:8]
            ) or "none"
            module_lines = "\n".join(
                f"  {m['directory']}/ ({m.get('source_files', m['files'])} source files)"
                + (f" — {m['purpose']}" if m.get('purpose') else "")
                for m in profile.get("module_map", [])
            )

            # Sample of source file names (stems only) to help LLM identify signals
            # not captured by top-level directory names alone
            from guard.core.project_profile import _collect_source_files, _ALWAYS_SKIP
            _excl = config.scan_exclude if hasattr(config, "scan_exclude") else []
            _src_files = _collect_source_files(Path(root), _excl)
            file_sample = ", ".join(
                sorted({f.stem for f in _src_files if f.stem and not f.stem.startswith("_")})[:120]
            )
            pack_recs = ", ".join(r["pack"] for r in profile.get("recommended_packs", [])) or "none"
            enabled_packs_str = ", ".join(config.standards_packs) if config.standards_packs else "none"
            conv = json.dumps(profile.get("conventions", {}), indent=None)

            # Layer 1: README — domain context (highest priority)
            readme_text = ""
            for readme_name in ("README.md", "readme.md", "README.rst"):
                readme_path = Path(root) / readme_name
                if readme_path.is_file():
                    try:
                        readme_text = readme_path.read_text(encoding="utf-8", errors="replace")[:1500]
                    except OSError:
                        pass
                    break

            # Layer 2: Scan insights — risk clusters from findings.json
            scan_insights = _read_scan_insights(config.output_dir)
            scan_insights_str = ""
            if scan_insights:
                sev = scan_insights.get("severity_counts", {})
                sev_str = ", ".join(f"{k}: {v}" for k, v in sev.items() if v)
                top_rules = ", ".join(f"{r} ({c}x)" for r, c in scan_insights.get("top_rules", [])[:5])
                risk_mods = ", ".join(scan_insights.get("risk_modules", []))
                stds = ", ".join(scan_insights.get("frameworks_flagged", []))
                scan_insights_str = (
                    f"Total findings: {scan_insights.get('total', 0)}\n"
                    f"Severity distribution: {sev_str or 'none'}\n"
                    f"Most-fired rules: {top_rules or 'none'}\n"
                    f"Riskiest modules: {risk_mods or 'none'}\n"
                    f"Compliance standards flagged: {stds or 'none'}"
                )

            # Layer 3: Prior profile-context — accumulated understanding
            prior_context = _read_profile_context(root)
            prior_context_section = ""
            if prior_context.strip():
                prior_context_section = f"""
PRIOR PROFILE CONTEXT (your understanding from last run — update and correct as needed):
{prior_context[:2000]}
"""

            llm_prompt = f"""You are a senior software architect maintaining a living profile of a codebase.
Your role is to interpret automated signals and produce an accurate, project-specific understanding.
Use the README content to understand the project's domain — it takes priority over any inferences from file names alone.

PROJECT: {profile.get('name', 'unknown')} v{profile.get('version', '')}
DESCRIPTION: {profile.get('description', 'not provided')}
LANGUAGES: {', '.join(profile.get('languages', []))}
FRAMEWORKS: {fw_list}
FILE COUNT: {profile.get('file_count', 0)} source files

README CONTENT (first 1500 chars — authoritative domain source):
{readme_text or '(no README found)'}

DETECTED ARCHITECTURE PATTERNS:
{arch_list}

COMPLIANCE SIGNALS ALREADY DETECTED (do not repeat these):
{signal_list or 'none'}

CORE DEPENDENCIES (most-used external libraries):
{top_imports_str}

DIRECTORY STRUCTURE (all top-level directories):
{module_lines}

SOURCE FILE NAMES (sample — use these to infer compliance-relevant modules):
{file_sample}

CODING CONVENTIONS:
{conv}

SENTRIK PACKS ALREADY ENABLED (do NOT recommend these — they are already active):
{enabled_packs_str}

SENTRIK PACKS SUGGESTED BY DETERMINISTIC ANALYSIS (not yet enabled):
{pack_recs}

LAST SCAN FINDINGS SUMMARY:
{scan_insights_str or '(no scan data available yet — run a scan first)'}
{prior_context_section}
Provide:
1. A 2-3 sentence architectural summary — describe what this project IS and how it is structured.
2. Three to five actionable Sentrik recommendations specific to THIS project. \
Do NOT recommend external tools. Do NOT recommend any pack listed under "SENTRIK PACKS ALREADY ENABLED". \
Frame as: enabling a Sentrik pack (from the suggested list or others not yet enabled), \
creating a custom Sentrik rule, configuring a Sentrik feature, \
or addressing a specific gap visible in the scan findings above.
3. Additional compliance signals not already in "COMPLIANCE SIGNALS ALREADY DETECTED". \
Look at the source file names and directory structure to identify compliance-relevant modules \
the keyword scanner missed — things like safety-critical control, risk management, \
hardware interfaces, real-time scheduling, IPC, memory management, device drivers, \
calibration, data integrity, watchdogs, etc. \
Only include signals with clear evidence from the file/directory names above. \
Use empty array if nothing meaningful to add.
4. A profile-context document (markdown) that captures your accumulated understanding of this project \
for use in future profiling runs. Include: project domain, critical modules, design patterns, \
compliance obligations, and any risk areas identified from scan findings. \
This document will be shown to you on the next run as "prior context" — write it to be useful to yourself.

Return ONLY valid JSON (no markdown fences):
{{
  "summary": "...",
  "recommendations": ["...", "...", "..."],
  "additional_signals": [
    {{"signal": "Signal Name", "evidence": "files: foo, bar", "description": "Why this matters for compliance"}}
  ],
  "profile_context": "# Project Context\\n\\n..."
}}"""

            response_text = llm.chat([{"role": "user", "content": llm_prompt}])
            match = _re.search(r"\{.*\}", response_text, _re.DOTALL)
            if match:
                insights = json.loads(match.group())
                profile["llm_summary"] = insights.get("summary", "")
                profile["recommendations"] = insights.get("recommendations", [])

                # Merge LLM-identified compliance signals with heuristic ones
                additional = insights.get("additional_signals", [])
                if additional and isinstance(additional, list):
                    existing_labels = {s["signal"] for s in profile.get("compliance_signals", [])}
                    for sig in additional:
                        if isinstance(sig, dict) and sig.get("signal") and sig["signal"] not in existing_labels:
                            profile["compliance_signals"].append({
                                "signal":      sig["signal"],
                                "evidence":    sig.get("evidence", "AI analysis"),
                                "description": sig.get("description", ""),
                                "source_files": [],  # AI-detected: no file-level evidence
                            })
                            existing_labels.add(sig["signal"])

                # Persist the profile-context for next run (Layer 3)
                context_md = insights.get("profile_context", "")
                if context_md.strip():
                    save_profile_context(context_md, root)
                    profile["profile_context"] = context_md
        except Exception as exc:
            _logger.warning("Profile LLM enhancement failed: %s", exc)

    path = save_profile(profile, config.output_dir)
    return {"status": "completed", "output": f"Profile saved to {path}", "data": profile}


@app.post("/api/run-design-review", dependencies=[Depends(_require_permission("scan"))])
def run_design_review_action():
    """Run design decision review — scans the full codebase for architectural decisions."""
    from guard.core.design_reviewer import review_design_from_files, save_decisions
    from guard.core.project_profile import _collect_source_files, _ALWAYS_SKIP
    from guard.providers.llm_stub import LLMStub
    from guard.providers.factory import build_llm

    config = _load_config()
    root = _get_repo_root()

    if config.llm_provider == "stub":
        raise HTTPException(
            status_code=400,
            detail="Design review requires an LLM. Configure AI in the Sentrik extension settings.",
        )

    llm = build_llm(config)
    if isinstance(llm, LLMStub):
        raise HTTPException(status_code=400, detail="Design review requires an LLM provider.")

    exclude = config.scan_exclude if hasattr(config, "scan_exclude") else []
    files = _collect_source_files(Path(root), exclude)

    if not files:
        return {"status": "completed", "output": "No source files found to review.", "decisions": []}

    decisions = review_design_from_files(
        llm, files, root=root, output_dir=config.output_dir
    )
    save_decisions(decisions, config.output_dir)

    return {
        "status": "completed",
        "output": f"Found {len(decisions)} design decision(s) across {len(files)} source files.",
        "decisions": [d.to_dict() for d in decisions],
    }


@app.post("/api/run-expertise", dependencies=[Depends(_require_permission("scan"))])
def run_expertise_action():
    """Build/refresh developer expertise profiles from git history."""
    return _run_sentrik_command(["check-expertise", "--profile"])


@app.post("/api/run-threat-model", dependencies=[Depends(_require_permission("scan"))])
def run_threat_model_action(git_range: str = Query(None), file: str = Query(None)):
    """Run STRIDE threat analysis. Defaults to last 10 commits if no range given."""
    args = ["threat-model"]
    if file:
        args += ["--file", file]
    elif git_range:
        args += ["--git-range", git_range]
    else:
        args += ["--git-range", "HEAD~10..HEAD"]
    return _run_sentrik_command(args)


@app.post("/api/run-attest", dependencies=[Depends(_require_permission("scan"))])
def run_attest_action():
    """Generate a signed compliance attestation."""
    return _run_sentrik_command(["attest"])


@app.post("/api/threat-model/mitigate", dependencies=[Depends(_require_permission("findings:write"))])
def mitigate_threat(threat_id: str = Query(...), note: str = Query("")):
    """Mark a threat as mitigated."""
    config = _load_config()
    p = Path(config.output_dir) / "threat_model.json"
    if not p.exists():
        raise HTTPException(status_code=404, detail="No threat model found")
    import json as _json
    threats = _json.loads(p.read_text(encoding="utf-8"))
    for t in threats:
        if t.get("threat_id") == threat_id:
            t["mitigated"] = True
            t["mitigation_note"] = note
            p.write_text(_json.dumps(threats, indent=2), encoding="utf-8")
            return {"success": True, "threat_id": threat_id}
    raise HTTPException(status_code=404, detail=f"Threat {threat_id} not found")
