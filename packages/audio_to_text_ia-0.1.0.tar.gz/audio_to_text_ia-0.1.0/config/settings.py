# config/settings.py
import os
import yaml
from typing import Dict, List, Any

class Settings:
    _instance = None
    _config: Dict[str, any] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Settings, cls).__new__(cls)
            cls._instance._load_config()
        return cls._instance
    
    def _load_config(self, config_path: str = None):
        """Carga la configuración desde un archivo YAML"""
        default_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),  # Asume que config/ está en raíz
            'config',
            'settings.yml'
        )
        
        config_file = config_path or default_path
        
        try:
            with open(config_file, 'r') as f:
                raw_config = yaml.safe_load(f)
                self._process_config(raw_config)
        except FileNotFoundError:
            raise RuntimeError(f"Archivo de configuración no encontrado: {config_file}")
        except yaml.YAMLError as e:
            raise RuntimeError(f"Error en formato YAML: {str(e)}")

    def _process_config(self, raw_config: Dict[str, Any]):
        """Procesa las configuraciones y aplica formato a extensiones"""
        # Procesar extensiones añadiendo el punto
        self._config['file_extensions'] = {
            file_type: [f'.{ext}' for ext in extensions]
            for file_type, extensions in raw_config.get('file_extensions', {}).items()
        }
        
        # Cargar configuración de entorno
        self._config['environment'] = raw_config.get('environment', 'local')
        
        # Cargar carpetas del proyecto
        self._config['project_folders'] = raw_config.get('project_folders', [])

    @classmethod
    def get_file_extensions(cls) -> Dict[str, List[str]]:
        """Obtiene las extensiones de archivo configuradas"""
        return cls()._config.get('file_extensions', {})
    
    @classmethod
    def get_environment(cls) -> str:
        """Obtiene el entorno configurado (local, dev, prod)"""
        return cls()._config.get('environment', 'local')
    
    @classmethod
    def get_project_folders(cls) -> List[str]:
        """Obtiene la lista de carpetas del proyecto a excluir en navegación local"""
        return cls()._config.get('project_folders', [])
    
    @classmethod
    def is_local_environment(cls) -> bool:
        """Verifica si el entorno actual es local"""
        return cls.get_environment() == 'local'
