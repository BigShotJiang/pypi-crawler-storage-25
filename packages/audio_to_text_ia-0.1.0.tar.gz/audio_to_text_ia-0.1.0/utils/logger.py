from coloredlogs import install as coloredlogs_install
from datetime import datetime
from inspect import currentframe as inspect_currentframe
from json import dumps as json_dumps
from logging import getLogger as logging_getLogger
import logging
import os
from os import path as os_path
import traceback
import sys

__version__ = '1.0.0'

# Configuraciones de colores
GRAY = '\033[90m'
RED = '\033[91m'
RED_BOLD = '\033[1m\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
PURPLE = '\033[95m'
CYAN = '\033[96m'
WHITE = '\033[97m'
END = '\033[0m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'

LEVEL = {
    'SPAM': GRAY,
    'ERROR': RED,
    'CRITICAL': RED_BOLD,
    'SUCCESS': GREEN,
    'DEBUG': CYAN,
    'WARNING': YELLOW,
    'VERBOSE': BLUE,
    'NOTICE': PURPLE,
    'HEADER': CYAN,
    'INFO': WHITE,
}

# Crear directorio de logs si no existe
LOGS_DIR = os.path.join(os.getcwd(), 'logs')
if not os.path.exists(LOGS_DIR):
    os.makedirs(LOGS_DIR)

class Logger:
    """
    Logger de proyecto con métodos info, warn, error, critical, debug y block

    Attributes
    ----------
    name : str
        Nombre de aplicación o módulo para tracking del log
    local_logger : str
        Instancia de loggin, librería externa
    file_logger : logging.Logger
        Logger para escribir en archivos

    :Authors:
        - Pablo Contreras

    :Created:
        - 2025-04-13
    """
    name = None
    local_logger = None
    file_logger = None
    log_file_path = None

    def __init__(self, name='audio_to_text_ia', *args, **kwargs):
        """
        Inicializador logger que configura el objeto

        Parameters
        ----------
        name : str
            Nombre de aplicación o módulo para tracking del log

        :Authors:
            - Pablo Contreras

        :Created:
            - 2025-04-13
        """
        self.name = name
        self.local_logger = logging_getLogger(self.name)
        coloredlogs_install(level='DEBUG', logger=self.local_logger)
        
        # Crear un nuevo archivo de log con timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file_path = os.path.join(LOGS_DIR, f"{name}_{timestamp}.log")
        
        # Configurar el logger de archivo
        self.file_logger = logging.getLogger(f"{name}_file")
        self.file_logger.setLevel(logging.DEBUG)
        
        # Evitar duplicación de handlers
        if not self.file_logger.handlers:
            file_handler = logging.FileHandler(self.log_file_path)
            file_handler.setLevel(logging.DEBUG)
            formatter = logging.Formatter('%(asctime)s [%(levelname)s] - %(message)s | %(filename)s:%(lineno)d')
            file_handler.setFormatter(formatter)
            self.file_logger.addHandler(file_handler)
        
        self.info(f"Log inicializado en: {self.log_file_path}")

    def _log(self, level: str, message: str, extra: dict = None, exc_info: bool = False) -> None:
        """
        Método interno para manejar el logging con extra

        Parameters
        ----------
        level : str
            Nivel de log (info, warn, error, critical, debug)
        message : str
            Mensaje principal del log
        extra : dict, optional
            Información adicional para incluir en el log
        exc_info : bool, optional
            Si es True, incluye información de la excepción en el log
        """
        if not extra:
            extra = {}

        log_message = str(message)
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        color = LEVEL.get(level.upper(), WHITE)
        
        # Obtener información del caller
        frame = inspect_currentframe().f_back.f_back
        filename = frame.f_code.co_filename
        lineno = frame.f_lineno
        func_name = frame.f_code.co_name

        # Obtener ruta relativa del archivo
        try:
            base_dir = os.getcwd()
            relative_path = os_path.relpath(filename, base_dir)
        except ValueError:
            relative_path = filename

        file_info = f"{relative_path}:{lineno}"

        # Agregar IP si está disponible y es un nivel de error
        if level.upper() in ['ERROR', 'WARNING', 'CRITICAL'] and 'ip_address' in extra:
            log_message = f"{log_message} [IP: {extra['ip_address']}]"

        # Información de excepción si se solicita
        exception_info = ""
        if exc_info:
            exception_info = "\n" + "".join(traceback.format_exception(*sys.exc_info()))

        # Formatear para la consola con colores
        formatted_console = f"{GREEN}[{current_time}]{END} {BLUE}[{file_info}]{END} {color}[{level.upper()}] - {log_message}{END}"
        if extra:
            extra_json = json_dumps(extra, indent=2, default=str)
            formatted_console += f" | {extra_json}"
        if exception_info:
            formatted_console += f"\n{RED}{exception_info}{END}"
        
        # Imprimir en consola
        print(formatted_console, flush=True)
        
        # Formatear para el archivo de log (sin colores)
        formatted_file = f"[{current_time}] [{file_info}] [{level.upper()}] - {log_message}"
        if extra:
            extra_json = json_dumps(extra, default=str)
            formatted_file += f" | {extra_json}"
        if exception_info:
            formatted_file += f"\n{exception_info}"
        
        # Escribir en el archivo de log
        log_method = getattr(self.file_logger, level.lower(), self.file_logger.info)
        log_method(formatted_file, exc_info=exc_info)

    def info(self, message, extra=None):
        """
        Log con nivel informativo

        Parameters
        ----------
        message : str
            Mensaje a imprimir
        extra : dict, optional
            Información adicional para incluir en el log

        :Authors:
            - Pablo Contreras

        :Created:
            - 2025-04-13
        """
        self._log('INFO', message, extra)

    def warning(self, message, extra=None):
        """
        Log con nivel de advertencia

        Parameters
        ----------
        message : str
            Mensaje a imprimir
        extra : dict, optional
            Información adicional para incluir en el log

        :Authors:
            - Pablo Contreras

        :Created:
            - 2025-04-13
        """
        self._log('WARNING', message, extra)

    def error(self, message, extra=None, exc_info=False):
        """
        Log para impresión de errores

        Parameters
        ----------
        message : str
            Mensaje a imprimir
        extra : dict, optional
            Información adicional para incluir en el log
        exc_info : bool, optional
            Si es True, incluye información de la excepción en el log

        :Authors:
            - Pablo Contreras

        :Created:
            - 2025-04-13
        """
        self._log('ERROR', message, extra, exc_info)

    def critical(self, message, extra=None, exc_info=False):
        """
        Log para impresiones de errores críticos de sistema

        Parameters
        ----------
        message : str
            Mensaje a imprimir
        extra : dict, optional
            Información adicional para incluir en el log
        exc_info : bool, optional
            Si es True, incluye información de la excepción en el log

        :Authors:
            - Pablo Contreras

        :Created:
            - 2025-04-13
        """
        self._log('CRITICAL', message, extra, exc_info)

    def debug(self, message, extra=None):
        """
        Impresiones simples para depuración

        Parameters
        ----------
        message : str
            Mensaje a imprimir
        extra : dict, optional
            Información adicional para incluir en el log

        :Authors:
            - Pablo Contreras

        :Created:
            - 2025-04-13
        """
        self._log('DEBUG', message, extra)

    def success(self, message, extra=None):
        """
        Log para operaciones exitosas

        Parameters
        ----------
        message : str
            Mensaje a imprimir
        extra : dict, optional
            Información adicional para incluir en el log

        :Authors:
            - Pablo Contreras

        :Created:
            - 2025-04-13
        """
        self._log('SUCCESS', message, extra)


# Singleton instance
logger = Logger()
