from __future__ import annotations

import asyncio
from collections.abc import Callable, Sequence
import functools
import inspect
import logging
from typing import Any, Literal

from pydantic import BaseModel

from .binding.reader import DbReader
from .binding.writer import DbWriter
from .core.engine import EngineProvider
from .core.errors import ConfigurationError
from .observability import MetricsCollector
from .trigger.normalizers import EventNormalizer
from .trigger.poll import PollTrigger
from .trigger.retry import RetryPolicy
from .trigger.runner import SourceAdapter, StateStore

logger = logging.getLogger(__name__)

# Parameter names reserved by Azure Functions runtime.
_RESERVED_ARGS = frozenset({"timer", "req", "context", "msg", "input", "output"})
_DB_DECORATOR_ATTR = "_db_decorators"
_TOOLKIT_META_ATTR = "_azure_functions_metadata"


class DbOut:
    """Output binding parameter injected by the ``output`` decorator.

    Mirrors the native Azure Functions ``func.Out[T]`` pattern.
    The handler calls ``.set()`` to write data to the database explicitly,
    leaving the handler's return value free for other purposes (e.g.
    ``HttpResponse``).

    Example::

        @db.output("order", url="%DB_URL%", table="orders")
        def create_order(req, order: DbOut) -> func.HttpResponse:
            order.set({"id": 1, "status": "pending"})
            return func.HttpResponse("Created", status_code=201)

    Accepted types for ``.set()``:
        - ``dict`` — single-row write
        - ``list[dict]`` — batch write
        - ``BaseModel`` / ``list[BaseModel]`` — auto-dumped to dict
        - ``None`` — no-op (skip write)
    """

    def __init__(
        self,
        *,
        url: str,
        table: str,
        schema: str | None,
        action: Literal["insert", "upsert"],
        conflict_columns: list[str] | None,
        engine_provider: EngineProvider | None,
    ) -> None:
        self._url = url
        self._table = table
        self._schema = schema
        self._action = action
        self._conflict_columns = conflict_columns
        self._engine_provider = engine_provider

    def set(
        self,
        data: (
            dict[str, object] | Sequence[dict[str, object]] | BaseModel | Sequence[BaseModel] | None
        ),
    ) -> None:
        """Write *data* to the configured table.

        Parameters
        ----------
        data:
            ``dict`` for single row, ``list[dict]`` for batch,
            ``BaseModel`` / ``list[BaseModel]`` for Pydantic models,
            or ``None`` to skip.
        """
        if data is None:
            return

        writer = DbWriter(
            url=self._url,
            table=self._table,
            schema=self._schema,
            engine_provider=self._engine_provider,
        )
        try:
            if isinstance(data, (dict, BaseModel)):
                row = _normalize_output_row(data)
                if self._action == "upsert":
                    if self._conflict_columns is None:
                        msg = "output: unreachable – upsert without conflict_columns"
                        raise ConfigurationError(msg)
                    writer.upsert(data=row, conflict_columns=self._conflict_columns)
                else:
                    writer.insert(data=row)
            elif isinstance(data, list):
                bad = next(
                    (i for i, row in enumerate(data) if not isinstance(row, (dict, BaseModel))),
                    None,
                )
                if bad is not None:
                    bad_type = type(data[bad]).__name__
                    msg = (
                        f"output: DbOut.set() received list with non-dict element "
                        f"at index {bad} ({bad_type}); expected list[dict | BaseModel]"
                    )
                    raise ConfigurationError(msg)
                rows = [_normalize_output_row(row) for row in data]
                if self._action == "upsert":
                    if self._conflict_columns is None:
                        msg = "output: unreachable – upsert without conflict_columns"
                        raise ConfigurationError(msg)
                    writer.upsert_many(rows=rows, conflict_columns=self._conflict_columns)
                else:
                    writer.insert_many(rows=rows)
            else:
                msg = (
                    f"output: DbOut.set() received {type(data).__name__}, "
                    f"expected dict, list[dict], BaseModel, list[BaseModel], or None"
                )
                raise ConfigurationError(msg)
        finally:
            writer.close()


class _AsyncDbOutProxy:
    """Async wrapper for :class:`DbOut` used in async handlers.

    Delegates ``.set()`` to a worker thread via ``asyncio.to_thread()``
    so the event loop stays free.
    """

    def __init__(self, out: DbOut) -> None:
        self._out = out

    async def set(
        self,
        data: (
            dict[str, object] | Sequence[dict[str, object]] | BaseModel | Sequence[BaseModel] | None
        ),
    ) -> None:
        """Async version of :meth:`DbOut.set`."""
        await asyncio.to_thread(self._out.set, data)


def _get_db_decorators(fn: Callable[..., Any]) -> frozenset[str]:
    existing: object = getattr(fn, _DB_DECORATOR_ATTR, frozenset())
    if not isinstance(existing, frozenset):
        return frozenset()
    return existing


def _mark_decorator(fn: Callable[..., Any], name: str) -> None:
    setattr(fn, _DB_DECORATOR_ATTR, _get_db_decorators(fn) | {name})


def _merge_toolkit_metadata(
    fn: Callable[..., Any], namespace: str, payload: dict[str, Any],
) -> None:
    """Merge toolkit metadata into the convention attribute, preserving other namespaces."""
    existing: dict[str, Any] = getattr(fn, _TOOLKIT_META_ATTR, {})
    if not isinstance(existing, dict):
        existing = {}

    if namespace in existing and isinstance(existing[namespace], dict):
        old = existing[namespace]
        merged_payload = {**payload}
        if "bindings" in old and "bindings" in payload:
            merged_payload["bindings"] = old["bindings"] + payload["bindings"]
        if "injections" in old and "injections" in payload:
            merged_payload["injections"] = old["injections"] + payload["injections"]
        existing = {**existing, namespace: merged_payload}
    else:
        existing = {**existing, namespace: payload}

    setattr(fn, _TOOLKIT_META_ATTR, existing)


def _check_composition(fn: Callable[..., Any], name: str) -> None:
    existing = _get_db_decorators(fn)

    if name in existing:
        msg = f"Decorator '{name}' cannot be applied twice to the same handler"
        raise ConfigurationError(msg)

    if name == "input" and "inject_reader" in existing:
        msg = (
            "Cannot combine 'input' and 'inject_reader' on the same handler — use one or the other"
        )
        raise ConfigurationError(msg)
    if name == "inject_reader" and "input" in existing:
        msg = (
            "Cannot combine 'inject_reader' and 'input' on the same handler — use one or the other"
        )
        raise ConfigurationError(msg)

    if name == "output" and "inject_writer" in existing:
        msg = (
            "Cannot combine 'output' and 'inject_writer' on the same handler — use one or the other"
        )
        raise ConfigurationError(msg)
    if name == "inject_writer" and "output" in existing:
        msg = (
            "Cannot combine 'inject_writer' and 'output' on the same handler — use one or the other"
        )
        raise ConfigurationError(msg)


class _AsyncDbReaderProxy:
    def __init__(self, reader: DbReader) -> None:
        self._reader = reader

    async def get(self, *, pk: dict[str, object]) -> dict[str, object] | None:
        return await asyncio.to_thread(self._reader.get, pk=pk)

    async def query(
        self,
        sql: str,
        *,
        params: dict[str, object] | None = None,
    ) -> list[dict[str, object]]:
        return await asyncio.to_thread(self._reader.query, sql, params=params)

    def close(self) -> None:
        self._reader.close()


class _AsyncDbWriterProxy:
    def __init__(self, writer: DbWriter) -> None:
        self._writer = writer

    async def insert(self, *, data: dict[str, object]) -> None:
        await asyncio.to_thread(self._writer.insert, data=data)

    async def insert_many(self, *, rows: list[dict[str, object]]) -> None:
        await asyncio.to_thread(self._writer.insert_many, rows=rows)

    async def upsert(self, *, data: dict[str, object], conflict_columns: list[str]) -> None:
        await asyncio.to_thread(self._writer.upsert, data=data, conflict_columns=conflict_columns)

    async def upsert_many(
        self,
        *,
        rows: list[dict[str, object]],
        conflict_columns: list[str],
    ) -> None:
        await asyncio.to_thread(
            self._writer.upsert_many, rows=rows, conflict_columns=conflict_columns
        )

    def close(self) -> None:
        self._writer.close()


def _validate_arg_name(arg_name: str, fn: Callable[..., Any], decorator_name: str) -> None:
    """Validate that *arg_name* exists in *fn*'s signature and does not collide."""
    sig = inspect.signature(fn, follow_wrapped=False)
    if arg_name not in sig.parameters:
        msg = (
            f"{decorator_name} arg_name='{arg_name}' not found in "
            f"function '{fn.__name__}' parameters"
        )
        raise ConfigurationError(msg)

    if arg_name in _RESERVED_ARGS:
        msg = (
            f"{decorator_name} arg_name='{arg_name}' conflicts with Azure Functions "
            f"reserved parameter name. Avoid: {sorted(_RESERVED_ARGS)}"
        )
        raise ConfigurationError(msg)


def _build_host_signature(
    fn: Callable[..., Any],
    injected: set[str],
) -> inspect.Signature:
    """Return a signature hiding *injected* params from Azure runtime."""
    sig = inspect.signature(fn, follow_wrapped=False)
    params = [p for name, p in sig.parameters.items() if name not in injected]
    return sig.replace(parameters=params)


def _validate_resolver(
    resolver: Callable[..., dict[str, object]],
    fn: Callable[..., Any],
    injected_args: set[str],
    param_label: str,
    decorator_name: str,
) -> list[str]:
    """Validate a resolver callable at decoration time.

    Ensures the resolver's parameter names are a subset of the handler's
    non-injected parameters and that it does not use ``*args`` or ``**kwargs``.

    Returns the list of parameter names the resolver expects.
    """
    resolver_sig = inspect.signature(resolver)
    for p in resolver_sig.parameters.values():
        if p.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            msg = f"{decorator_name} {param_label} callable must not use *args or **kwargs"
            raise ConfigurationError(msg)
        if p.kind == inspect.Parameter.POSITIONAL_ONLY:
            msg = (
                f"{decorator_name} {param_label} callable must not use positional-only "
                f"parameters ('{p.name}'). Use keyword-compatible parameters instead."
            )
            raise ConfigurationError(msg)

    handler_sig = inspect.signature(fn, follow_wrapped=False)
    handler_params = {name for name in handler_sig.parameters if name not in injected_args}
    resolver_params = list(resolver_sig.parameters.keys())
    unknown = set(resolver_params) - handler_params
    if unknown:
        msg = (
            f"{decorator_name} {param_label} callable references parameters "
            f"{sorted(unknown)} not found in handler '{fn.__name__}'. "
            f"Available: {sorted(handler_params)}"
        )
        raise ConfigurationError(msg)
    return resolver_params


def _resolve_callable(
    resolver: Callable[..., dict[str, object]],
    resolver_params: list[str],
    all_kwargs: dict[str, Any],
) -> dict[str, object]:
    """Call a resolver with matching kwargs extracted from the handler invocation."""
    call_kwargs = {name: all_kwargs[name] for name in resolver_params if name in all_kwargs}
    return resolver(**call_kwargs)


def _validate_model_type(model: object | None) -> None:
    if model is None:
        return
    if not isinstance(model, type) or not issubclass(model, BaseModel):
        model_name = model.__name__ if isinstance(model, type) else type(model).__name__
        msg = f"input model must be a subclass of BaseModel, got '{model_name}'"
        raise ConfigurationError(msg)


def _apply_input_model(
    result: dict[str, object] | list[dict[str, object]] | None,
    model: type[BaseModel] | None,
) -> dict[str, object] | list[dict[str, object]] | BaseModel | list[BaseModel] | None:
    if model is None:
        return result
    if result is None:
        return None
    if isinstance(result, list):
        return [model.model_validate(row) for row in result]
    return model.model_validate(result)


def _normalize_output_row(row: dict[str, object] | BaseModel) -> dict[str, object]:
    if isinstance(row, BaseModel):
        return row.model_dump()
    return row


class DbBindings:
    """Azure Functions-style decorator API for database integration.

    Provides ``trigger``, ``input``, ``output``, ``inject_reader``,
    and ``inject_writer`` decorator methods that wrap the imperative API
    (PollTrigger, DbReader, DbWriter) in an Azure Functions-native
    decorator experience.

    **Data injection** (``input`` / ``output``):
        ``input`` injects query results into handler parameters.
        ``output`` injects a :class:`DbOut` instance; call ``.set()``
        to write data explicitly.

    **Client injection** (``inject_reader`` / ``inject_writer``):
        Handlers receive ``DbReader`` / ``DbWriter`` instances for
        imperative control.

    Decorator order contract:
        Decorator composition rules:
            - Azure decorators outermost, db decorators closest to the function
            - ``trigger`` + ``output`` can be combined (process events and write results)
            - ``trigger`` + ``inject_writer`` can be combined (imperative write in trigger handler)
            - ``input`` + ``output`` can be combined (read data, write results)
            - ``input`` and ``inject_reader`` are mutually exclusive
            - ``output`` and ``inject_writer`` are mutually exclusive
            - No decorator can be applied twice to the same handler

        Valid combinations::

            @app.schedule(...)
            @db.trigger(...)        # Azure trigger outermost
            @db.output("out", ...)  # db output innermost
            def handler(events, out: DbOut) -> None:
                out.set([...])

            @db.input("user", ...)
            @db.output("out", ...)
            def handler(user, out: DbOut) -> dict:
                out.set({...})
                return user

    Note: This is a pseudo-trigger implementation. ``trigger`` requires
    an actual Azure Functions trigger (e.g. ``@app.schedule``) to fire.
    It does not register a native Azure Functions binding.
    """

    def trigger(
        self,
        *,
        arg_name: str,
        source: SourceAdapter,
        checkpoint_store: StateStore,
        name: str | None = None,
        normalizer: EventNormalizer | None = None,
        batch_size: int = 100,
        max_batches_per_tick: int = 1,
        lease_ttl_seconds: int = 120,
        retry_policy: RetryPolicy | None = None,
        metrics: MetricsCollector | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator for database change detection (pseudo-trigger).

        Wraps a handler function so that on each invocation it polls the
        database source for new/changed rows and passes them to the handler.

        The decorated function's ``arg_name`` parameter will receive the
        list of :class:`RowChange` events.  An optional parameter named
        ``context`` will receive the :class:`PollContext`.

        Must be used together with an actual Azure Functions trigger
        (e.g. ``@app.schedule(...)``).

        Parameters
        ----------
        arg_name:
            Name of the handler parameter that receives the events list.
        source:
            Database source adapter (e.g. ``SqlAlchemySource``).
        checkpoint_store:
            State store for checkpointing (e.g. ``BlobCheckpointStore``).
        name:
            Trigger name for logging/metrics.  Defaults to the function name.

        .. note::
            Only synchronous handlers are supported. Async handlers will raise
            ``ConfigurationError`` at decoration time. This is because
            ``PollTrigger.run`` is synchronous.
        """

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            _check_composition(fn, "trigger")
            _validate_arg_name(arg_name, fn, "trigger")

            # Reject async handlers: PollTrigger.run is synchronous and
            # calling an async function without await would silently return
            # an unawaited coroutine.
            if inspect.iscoroutinefunction(fn):
                msg = (
                    "trigger does not support async handlers because PollTrigger.run() "
                    "is synchronous. Use a sync handler instead."
                )
                raise ConfigurationError(msg)

            trigger_name = name or fn.__name__
            trigger = PollTrigger(
                name=trigger_name,
                source=source,
                checkpoint_store=checkpoint_store,
                normalizer=normalizer,
                batch_size=batch_size,
                max_batches_per_tick=max_batches_per_tick,
                lease_ttl_seconds=lease_ttl_seconds,
                retry_policy=retry_policy,
                metrics=metrics,
            )

            fn_sig = inspect.signature(fn, follow_wrapped=False)
            has_context = "context" in fn_sig.parameters

            db_injected = {arg_name}
            if has_context:
                db_injected.add("context")
            host_params = [p_name for p_name in fn_sig.parameters if p_name not in db_injected]

            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> int:
                timer: Any = None
                if args:
                    timer = args[0]
                elif host_params:
                    timer = kwargs.get(host_params[0])

                bound_args = dict(kwargs)
                if args and host_params:
                    for i, val in enumerate(args):
                        if i < len(host_params):
                            bound_args[host_params[i]] = val

                def invoke_handler(events: Any, context: Any | None = None) -> Any:
                    call_kwargs: dict[str, Any] = dict(bound_args)
                    call_kwargs[arg_name] = events
                    if has_context and context is not None:
                        call_kwargs["context"] = context
                    return fn(**call_kwargs)

                return trigger.run(timer=timer, handler=invoke_handler)

            # Keep host trigger params visible in __signature__ so Azure
            # worker binding validation can find them.  Only hide the
            # db-injected params (events, context).
            setattr(wrapper, "__signature__", _build_host_signature(fn, db_injected))
            _mark_decorator(wrapper, "trigger")
            _merge_toolkit_metadata(
                wrapper,
                "db",
                {
                    "version": 1,
                    "bindings": [
                        {
                            "kind": "trigger",
                            "parameter": arg_name,
                        }
                    ],
                    "injections": [],
                },
            )

            return wrapper

        return decorator

    # ------------------------------------------------------------------
    # Data injection decorators
    # ------------------------------------------------------------------

    def input(
        self,
        arg_name: str,
        *,
        url: str,
        table: str | None = None,
        schema: str | None = None,
        pk: dict[str, object] | Callable[..., dict[str, object]] | None = None,
        query: str | None = None,
        params: dict[str, object] | Callable[..., dict[str, object]] | None = None,
        model: type[BaseModel] | None = None,
        on_not_found: Literal["none", "raise"] = "none",
        engine_provider: EngineProvider | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator that injects query results into the handler.

        The handler parameter named ``arg_name`` will receive the actual
        data from the database, not a ``DbReader`` instance.  Exactly one
        of ``pk`` or ``query`` must be provided.

        **PK mode** (single row):
            The parameter receives ``dict[str, object] | None``.  Use a
            static dict for fixed lookups or a callable for dynamic
            resolution from other handler parameters::

                @db.input("user", url=..., table="users",
                             pk=lambda req: {"id": req.params["id"]})
                def handler(req, user): ...

        **Query mode** (multiple rows):
            The parameter receives ``list[dict[str, object]]``::

                @db.input("users", url=...,
                             query="SELECT * FROM users WHERE active = :active",
                             params={"active": True})
                def handler(users): ...

        Parameters
        ----------
        arg_name:
            Name of the handler parameter that receives the data.
        url:
            SQLAlchemy connection URL.  Supports ``%VAR%`` env-var substitution.
        table:
            Table name.  Required when using ``pk``.
        schema:
            Optional schema qualifier.
        pk:
            Primary key for single-row lookup.  Either a static dict or a
            callable whose parameter names match other handler parameters.
        query:
            SQL query string for multi-row results.  Use ``:name``
            placeholders for parameters.
        params:
            Parameters for ``query``.  Either a static dict or a callable.
        on_not_found:
            Behavior when ``pk`` lookup returns no row.  ``"none"`` (default)
            injects ``None``; ``"raise"`` raises ``NotFoundError``.
        engine_provider:
            Optional shared ``EngineProvider`` for connection pooling.

        Supports both sync and async handlers. For async handlers, blocking
        database I/O is automatically offloaded via ``asyncio.to_thread()``.
        """
        if on_not_found not in ("none", "raise"):
            msg = f"input on_not_found must be 'none' or 'raise', got '{on_not_found}'"
            raise ConfigurationError(msg)
        if pk is not None and query is not None:
            msg = "input requires exactly one of 'pk' or 'query', not both"
            raise ConfigurationError(msg)
        if pk is None and query is None:
            msg = "input requires exactly one of 'pk' or 'query'"
            raise ConfigurationError(msg)
        if pk is not None and table is None:
            msg = "input with 'pk' requires 'table' to be set"
            raise ConfigurationError(msg)
        if params is not None and query is None:
            msg = "input 'params' is only valid with 'query'"
            raise ConfigurationError(msg)
        _validate_model_type(model)

        use_pk = pk is not None
        pk_callable: Callable[..., dict[str, object]] | None = pk if callable(pk) else None
        pk_static: dict[str, object] | None = None if callable(pk) else pk
        params_callable: Callable[..., dict[str, object]] | None = (
            params if callable(params) else None
        )
        params_static: dict[str, object] | None = None if callable(params) else params

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            _check_composition(fn, "input")
            _validate_arg_name(arg_name, fn, "input")

            pk_resolver_params: list[str] = []
            params_resolver_params: list[str] = []
            if pk_callable is not None:
                pk_resolver_params = _validate_resolver(pk_callable, fn, {arg_name}, "pk", "input")
            if params_callable is not None:
                params_resolver_params = _validate_resolver(
                    params_callable, fn, {arg_name}, "params", "input"
                )

            is_async = inspect.iscoroutinefunction(fn)

            binding_info: dict[str, Any] = {
                "kind": "input",
                "parameter": arg_name,
                "connection_setting": url,
                "resource": {"table": table} if table else {},
                "query_kind": "pk" if use_pk else "text",
            }
            if model is not None:
                binding_info["model_ref"] = f"{model.__module__}:{model.__qualname__}"

            def _resolve_read_args(
                all_kwargs: dict[str, Any],
            ) -> tuple[dict[str, object] | None, dict[str, object] | None]:
                """Resolve pk/params from handler kwargs (safe to call on any thread)."""
                resolved_pk: dict[str, object] | None = None
                resolved_params: dict[str, object] | None = None
                if use_pk:
                    if pk_callable is not None:
                        resolved_pk = _resolve_callable(pk_callable, pk_resolver_params, all_kwargs)
                    elif pk_static is not None:
                        resolved_pk = pk_static
                    else:
                        msg = "input: unreachable – neither pk callable nor pk static"
                        raise ConfigurationError(msg)
                else:
                    if params_callable is not None:
                        resolved_params = _resolve_callable(
                            params_callable, params_resolver_params, all_kwargs
                        )
                    elif params_static is not None:
                        resolved_params = params_static
                return resolved_pk, resolved_params

            def _execute_read(
                resolved_pk: dict[str, object] | None,
                resolved_params: dict[str, object] | None,
            ) -> Any:
                """Execute DB I/O (blocking — run in worker thread for async)."""
                reader = DbReader(
                    url=url,
                    table=table,
                    schema=schema,
                    engine_provider=engine_provider,
                )
                try:
                    if use_pk:
                        if resolved_pk is None:
                            msg = "input: unreachable – pk mode but resolved_pk is None"
                            raise ConfigurationError(msg)
                        result = reader.get(pk=resolved_pk)
                        if result is None and on_not_found == "raise":
                            from .core.errors import NotFoundError

                            msg = f"input: no row found for pk={resolved_pk} in table '{table}'"
                            raise NotFoundError(msg)
                        return result
                    else:
                        if query is None:
                            msg = "input: unreachable – query mode but query is None"
                            raise ConfigurationError(msg)
                        return reader.query(query, params=resolved_params)
                finally:
                    reader.close()

            if is_async:

                @functools.wraps(fn)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    r_pk, r_params = _resolve_read_args(kwargs)
                    data = await asyncio.to_thread(_execute_read, r_pk, r_params)
                    kwargs[arg_name] = _apply_input_model(data, model)
                    return await fn(*args, **kwargs)

                setattr(async_wrapper, "__signature__", _build_host_signature(fn, {arg_name}))
                _mark_decorator(async_wrapper, "input")
                _merge_toolkit_metadata(
                    async_wrapper,
                    "db",
                    {
                        "version": 1,
                        "bindings": [binding_info],
                        "injections": [],
                    },
                )
                return async_wrapper

            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                r_pk, r_params = _resolve_read_args(kwargs)
                data = _execute_read(r_pk, r_params)
                kwargs[arg_name] = _apply_input_model(data, model)
                return fn(*args, **kwargs)

            setattr(wrapper, "__signature__", _build_host_signature(fn, {arg_name}))
            _mark_decorator(wrapper, "input")
            _merge_toolkit_metadata(
                wrapper,
                "db",
                {
                    "version": 1,
                    "bindings": [binding_info],
                    "injections": [],
                },
            )
            return wrapper

        return decorator

    def output(
        self,
        arg_name: str,
        *,
        url: str,
        table: str,
        schema: str | None = None,
        action: Literal["insert", "upsert"] = "insert",
        conflict_columns: list[str] | None = None,
        engine_provider: EngineProvider | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator that injects a :class:`DbOut` instance into the handler.

        Follows the native Azure Functions output binding pattern
        (``func.Out[T]`` with ``.set()``).  The handler parameter named
        ``arg_name`` will receive a ``DbOut`` instance for sync handlers
        or an ``_AsyncDbOutProxy`` for async handlers.

        The handler's return value is **not** intercepted — use
        ``out.set(data)`` to write explicitly.

        Parameters
        ----------
        arg_name:
            Name of the handler parameter that receives the ``DbOut``.
        url:
            SQLAlchemy connection URL.  Supports ``%VAR%`` env-var substitution.
        table:
            Table name for write operations.
        schema:
            Optional schema qualifier.
        action:
            Write action: ``"insert"`` (default) or ``"upsert"``.
        conflict_columns:
            Columns for upsert conflict resolution.  Required when
            ``action="upsert"``.
        engine_provider:
            Optional shared ``EngineProvider`` for connection pooling.

        Supports both sync and async handlers. For async handlers, blocking
        database I/O is automatically offloaded via ``asyncio.to_thread()``.
        """
        if action not in ("insert", "upsert"):
            msg = f"output action must be 'insert' or 'upsert', got '{action}'"
            raise ConfigurationError(msg)
        if action == "upsert" and not conflict_columns:
            msg = "output with action='upsert' requires 'conflict_columns'"
            raise ConfigurationError(msg)

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            _check_composition(fn, "output")
            _validate_arg_name(arg_name, fn, "output")
            is_async = inspect.iscoroutinefunction(fn)

            out = DbOut(
                url=url,
                table=table,
                schema=schema,
                action=action,
                conflict_columns=conflict_columns,
                engine_provider=engine_provider,
            )

            if is_async:
                proxy = _AsyncDbOutProxy(out)

                @functools.wraps(fn)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    kwargs[arg_name] = proxy
                    return await fn(*args, **kwargs)

                setattr(async_wrapper, "__signature__", _build_host_signature(fn, {arg_name}))
                _mark_decorator(async_wrapper, "output")
                _merge_toolkit_metadata(
                    async_wrapper,
                    "db",
                    {
                        "version": 1,
                        "bindings": [
                            {
                                "kind": "output",
                                "parameter": arg_name,
                                "connection_setting": url,
                                "resource": {"table": table},
                            }
                        ],
                        "injections": [],
                    },
                )
                return async_wrapper

            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                kwargs[arg_name] = out
                return fn(*args, **kwargs)

            setattr(wrapper, "__signature__", _build_host_signature(fn, {arg_name}))
            _mark_decorator(wrapper, "output")
            _merge_toolkit_metadata(
                wrapper,
                "db",
                {
                    "version": 1,
                    "bindings": [
                        {
                            "kind": "output",
                            "parameter": arg_name,
                            "connection_setting": url,
                            "resource": {"table": table},
                        }
                    ],
                    "injections": [],
                },
            )
            return wrapper

        return decorator

    # ------------------------------------------------------------------
    # Client injection decorators (imperative escape hatches)
    # ------------------------------------------------------------------

    def inject_reader(
        self,
        arg_name: str,
        *,
        url: str,
        table: str | None = None,
        schema: str | None = None,
        engine_provider: EngineProvider | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator that injects a :class:`DbReader` instance into the handler.

        Use this when you need imperative control over reads (multiple
        queries, dynamic SQL, etc.).  For simple data injection, prefer
        :meth:`input`.

        The handler parameter named ``arg_name`` will receive a pre-configured
        ``DbReader`` instance.  The reader is created fresh per invocation and
        closed automatically after the handler returns.

        Parameters
        ----------
        arg_name:
            Name of the handler parameter that receives the ``DbReader``.
        url:
            SQLAlchemy connection URL.  Supports ``%VAR%`` env-var substitution.
        table:
            Optional table name for ``get()`` operations.
        schema:
            Optional schema qualifier.
        engine_provider:
            Optional shared ``EngineProvider`` for connection pooling.

        Supports both sync and async handlers. For async handlers, blocking
        database I/O is automatically offloaded via ``asyncio.to_thread()``.
        """

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            _check_composition(fn, "inject_reader")
            _validate_arg_name(arg_name, fn, "inject_reader")
            is_async = inspect.iscoroutinefunction(fn)

            if is_async:

                @functools.wraps(fn)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    reader = DbReader(
                        url=url,
                        table=table,
                        schema=schema,
                        engine_provider=engine_provider,
                    )
                    proxy = _AsyncDbReaderProxy(reader)
                    try:
                        kwargs[arg_name] = proxy
                        return await fn(*args, **kwargs)
                    finally:
                        reader.close()

                setattr(async_wrapper, "__signature__", _build_host_signature(fn, {arg_name}))
                _mark_decorator(async_wrapper, "inject_reader")
                _merge_toolkit_metadata(
                    async_wrapper,
                    "db",
                    {
                        "version": 1,
                        "bindings": [],
                        "injections": [{"kind": "reader", "parameter": arg_name}],
                    },
                )
                return async_wrapper

            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                reader = DbReader(
                    url=url,
                    table=table,
                    schema=schema,
                    engine_provider=engine_provider,
                )
                try:
                    kwargs[arg_name] = reader
                    return fn(*args, **kwargs)
                finally:
                    reader.close()

            setattr(wrapper, "__signature__", _build_host_signature(fn, {arg_name}))
            _mark_decorator(wrapper, "inject_reader")
            _merge_toolkit_metadata(
                wrapper,
                "db",
                {
                    "version": 1,
                    "bindings": [],
                    "injections": [{"kind": "reader", "parameter": arg_name}],
                },
            )
            return wrapper

        return decorator

    def inject_writer(
        self,
        arg_name: str,
        *,
        url: str,
        table: str,
        schema: str | None = None,
        engine_provider: EngineProvider | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator that injects a :class:`DbWriter` instance into the handler.

        Use this when you need imperative control over writes (multiple
        operations, transactions, update/delete, etc.).  For simple
        auto-write, prefer :meth:`output`.

        The handler parameter named ``arg_name`` will receive a pre-configured
        ``DbWriter`` instance.  The writer is created fresh per invocation and
        closed automatically after the handler returns.

        Parameters
        ----------
        arg_name:
            Name of the handler parameter that receives the ``DbWriter``.
        url:
            SQLAlchemy connection URL.  Supports ``%VAR%`` env-var substitution.
        table:
            Table name for write operations.
        schema:
            Optional schema qualifier.
        engine_provider:
            Optional shared ``EngineProvider`` for connection pooling.

        Supports both sync and async handlers. For async handlers, blocking
        database I/O is automatically offloaded via ``asyncio.to_thread()``.
        """

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            _check_composition(fn, "inject_writer")
            _validate_arg_name(arg_name, fn, "inject_writer")
            is_async = inspect.iscoroutinefunction(fn)

            if is_async:

                @functools.wraps(fn)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    writer = DbWriter(
                        url=url,
                        table=table,
                        schema=schema,
                        engine_provider=engine_provider,
                    )
                    proxy = _AsyncDbWriterProxy(writer)
                    try:
                        kwargs[arg_name] = proxy
                        return await fn(*args, **kwargs)
                    finally:
                        writer.close()

                setattr(async_wrapper, "__signature__", _build_host_signature(fn, {arg_name}))
                _mark_decorator(async_wrapper, "inject_writer")
                _merge_toolkit_metadata(
                    async_wrapper,
                    "db",
                    {
                        "version": 1,
                        "bindings": [],
                        "injections": [{"kind": "writer", "parameter": arg_name}],
                    },
                )
                return async_wrapper

            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                writer = DbWriter(
                    url=url,
                    table=table,
                    schema=schema,
                    engine_provider=engine_provider,
                )
                try:
                    kwargs[arg_name] = writer
                    return fn(*args, **kwargs)
                finally:
                    writer.close()

            setattr(wrapper, "__signature__", _build_host_signature(fn, {arg_name}))
            _mark_decorator(wrapper, "inject_writer")
            _merge_toolkit_metadata(
                wrapper,
                "db",
                {
                    "version": 1,
                    "bindings": [],
                    "injections": [{"kind": "writer", "parameter": arg_name}],
                },
            )
            return wrapper

        return decorator


def get_db_metadata(func: Any) -> dict[str, Any] | None:
    """Return db metadata if the function was decorated with DbBindings decorators.

    Returns None if the function has no db metadata attached.
    """
    toolkit_meta = getattr(func, _TOOLKIT_META_ATTR, None)
    if isinstance(toolkit_meta, dict):
        db_meta = toolkit_meta.get("db")
        if isinstance(db_meta, dict):
            return db_meta
    return None
