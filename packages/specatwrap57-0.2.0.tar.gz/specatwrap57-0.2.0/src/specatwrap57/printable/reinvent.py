import polars as pl

lf: pl.LazyFrame = None
# {{paste:begin}}

# {{paste:DIAG_initial_sorting}}

# {{paste:DIAG_stats}}

lf = lf.filter((pl.col("TDiag") == "Death").last().over("case:PNR"))

lf = lf.with_columns(
    (
        pl.col("TDiag") + pl.int_range(1, pl.len() + 1).over("TDiag").cast(pl.String)
    ).over("case:PNR")
)

"""
Converts into counts
"""
lf = lf.with_columns(
    pl.when(pl.col("TDiag").str.starts_with("CANCER"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CANCER3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("CARDIOVASCULAR"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CARDIOVASCULAR3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("MUSCULOSKELETAL"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 2)
        .then(pl.lit("MUSCULOSKELETAL2+"))
        .otherwise(pl.col("TDiag"))
    )
    .otherwise(pl.col("TDiag"))
    .alias("TDiag")
)

"""
Stats
"""
# 1. Create a LazyFrame for the total count
total_pnr_lf = lf.select(total=pl.col("case:PNR").n_unique())

# 2. Join it into your main pipeline
counts = (
    lf.group_by("case:PNR")
    .agg(pl.col("ADiag"))
    .explode("ADiag")
    .group_by("ADiag")
    .len(name="count")
    .join(total_pnr_lf, how="cross")  # Injects 'total' into every row
    .with_columns(percentage=pl.col("count") / pl.col("total"))
    .drop("total")
)

quick_to_death = (
    lf.group_by("case:PNR")
    .agg(
        time_diff=(
            pl.col("startTime").gather(-1) - pl.col("startTime").gather(-2)
        ).first(),
        ADiag=(pl.col("ADiag").gather(-2)).first(),
    )
    .group_by("ADiag")
    .agg(
        mean_time_diff=pl.col("time_diff").mean(),
        median_time_diff=pl.col("time_diff").median(),
        count=pl.col("time_diff").count(),
    )
    .sort(pl.col("count").reverse())
)

"""
Merging close activities
"""
# 1. Identify Death vs Clinical rows
lf = lf.with_columns(is_death=pl.col("ADiag").str.contains("Death"))

# 2. Separate them
clinical_events = lf.filter(~pl.col("is_death"))
death_events = lf.filter(pl.col("is_death"))

# 3. Cluster the clinical events
is_new_chain = (
    (pl.col("startTime") - pl.col("startTime").shift(1).over("case:PNR")).abs()
    >= pl.duration(days=100)
).fill_null(True)

clustered_clinical = (
    clinical_events.with_columns(
        chain_id=is_new_chain.cast(pl.Int32).cum_sum().over("case:PNR")
    )
    .group_by(["case:PNR", "chain_id"], maintain_order=True)
    .agg(
        startTime=pl.col("startTime").last(),
        # Clean and concatenate
        TDiag=pl.lit("BURST ") + pl.len().cast(pl.String),
        is_death=pl.lit(False),
    )
    .drop("chain_id")
)

# 4. Combine and Sort
final_lf = pl.concat(
    [clustered_clinical, death_events.select(clustered_clinical.columns)]
).sort(["case:PNR", "startTime"])
