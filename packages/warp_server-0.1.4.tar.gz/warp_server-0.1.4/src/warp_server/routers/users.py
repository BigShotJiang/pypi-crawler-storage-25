import secrets
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user, require_admin
from warp_server.database import get_db
from warp_server.models import ApiKey, User
from warp_server.schemas import (
    ApiKeyInfo,
    ApiKeyMdl,
    ChangeRoleRequest,
    ChangeUsernameRequest,
    CreateApiKeyRequest,
    CreateUserRequest,
    PaginatedResponse,
    UserInfo,
    UserMdl,
    UserQueryRequest,
)

router = APIRouter(prefix="/api/v1/users", tags=["users"])

DEFAULT_LIMIT = 20


@router.post("", status_code=201, response_model=UserMdl)
async def create_user(
    body: CreateUserRequest,
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_admin),
):
    username = body.name or body.email.split("@")[0]
    user = User(email=body.email, username=username, role="User")
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return UserMdl(
        id=user.id,
        created_at=user.created_at,
        email=user.email,
        role=user.role,
        username=user.username,
    )


@router.get("/me", response_model=UserMdl)
async def get_current_user_endpoint(user: User = Depends(get_current_user)):
    return UserMdl(
        id=user.id,
        created_at=user.created_at,
        email=user.email,
        role=user.role,
        username=user.username,
    )


@router.post("/query", response_model=PaginatedResponse[UserInfo])
async def query_users(body: UserQueryRequest, db: AsyncSession = Depends(get_db)):
    query = select(User)
    if body.name:
        if body.exact:
            query = query.where(User.username == body.name)
        else:
            query = query.where(User.username.ilike(f"%{body.name}%"))
    if body.role:
        query = query.where(User.role == body.role)

    total = await db.scalar(select(func.count()).select_from(query.subquery()))
    limit = body.limit or DEFAULT_LIMIT
    page = body.page or 1
    offset = (page - 1) * limit
    results = await db.execute(query.offset(offset).limit(limit))
    users = results.scalars().all()
    total_pages = max(1, -(-total // limit))  # ceil division

    return PaginatedResponse(
        items=[
            UserInfo(id=u.id, username=u.username, role=u.role, created_at=u.created_at)
            for u in users
        ],
        total_pages=total_pages,
        total_results=total,
    )


@router.get("/{user_id}", response_model=UserInfo)
async def get_user_by_id(user_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return UserInfo(
        id=user.id, username=user.username, role=user.role, created_at=user.created_at
    )


@router.delete("/{user_id}", status_code=204)
async def delete_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_admin),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    await db.delete(user)
    await db.commit()


@router.patch("/{user_id}/role", response_model=UserInfo)
async def change_role(
    user_id: int,
    body: ChangeRoleRequest,
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_admin),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    user.role = body.role
    await db.commit()
    await db.refresh(user)
    return UserInfo(
        id=user.id, username=user.username, role=user.role, created_at=user.created_at
    )


@router.patch("/{user_id}/username", response_model=UserInfo)
async def change_username(
    user_id: int,
    body: ChangeUsernameRequest,
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_admin),
):
    existing = await db.execute(select(User).where(User.username == body.username))
    if existing.scalar_one_or_none() is not None:
        raise HTTPException(status_code=409, detail="Username already taken")

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    user.username = body.username
    await db.commit()
    await db.refresh(user)
    return UserInfo(
        id=user.id, username=user.username, role=user.role, created_at=user.created_at
    )


# ── API Keys ────────────────────────────────────────────────────


def _key_info(k: ApiKey) -> ApiKeyInfo:
    return ApiKeyInfo(
        id=k.id,
        user_id=k.user_id,
        name=k.name,
        created_at=k.created_at,
        expires_at=k.expires_at,
        last_used_at=k.last_used_at,
    )


@router.get("/me/keys", response_model=list[ApiKeyInfo])
async def list_current_user_keys(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(select(ApiKey).where(ApiKey.user_id == user.id))
    return [_key_info(k) for k in result.scalars().all()]


@router.post("/me/keys", status_code=201, response_model=ApiKeyMdl)
async def create_current_user_api_key(
    body: CreateApiKeyRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    raw_key = secrets.token_urlsafe(32)
    api_key = ApiKey(
        user_id=user.id,
        key=raw_key,
        name=body.name,
        created_at=datetime.now(timezone.utc),
    )
    db.add(api_key)
    await db.commit()
    await db.refresh(api_key)
    return ApiKeyMdl(
        id=api_key.id,
        user_id=api_key.user_id,
        key=api_key.key,
        name=api_key.name,
        created_at=api_key.created_at,
        expires_at=api_key.expires_at,
        last_used_at=api_key.last_used_at,
    )


@router.get("/{user_id}/keys", response_model=list[ApiKeyInfo])
async def list_user_keys(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_admin),
):
    result = await db.execute(select(ApiKey).where(ApiKey.user_id == user_id))
    return [_key_info(k) for k in result.scalars().all()]


@router.post("/{user_id}/keys", status_code=201, response_model=ApiKeyMdl)
async def create_api_key(
    user_id: int,
    body: CreateApiKeyRequest,
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(require_admin),
):
    raw_key = secrets.token_urlsafe(32)
    api_key = ApiKey(
        user_id=user_id,
        key=raw_key,
        name=body.name,
        created_at=datetime.now(timezone.utc),
    )
    db.add(api_key)
    await db.commit()
    await db.refresh(api_key)
    return ApiKeyMdl(
        id=api_key.id,
        user_id=api_key.user_id,
        key=api_key.key,
        name=api_key.name,
        created_at=api_key.created_at,
        expires_at=api_key.expires_at,
        last_used_at=api_key.last_used_at,
    )
