from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.database import get_db
from warp_server.models import Function, Source, Type
from warp_server.models import Symbol
from warp_server.schemas import SearchIndexRow, SearchResponse

router = APIRouter(prefix="/api/v1/search", tags=["search"])

DEFAULT_LIMIT = 20
MAX_LIMIT = 100


@router.get("", response_model=SearchResponse)
async def search_handler(
    q: str | None = None,
    kind: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
    function_guid: UUID | None = None,
    commit_id: int | None = None,
    source_id: UUID | None = None,
    source_tags: list[str] | None = None,
    retrieve_data: bool | None = None,
    db: AsyncSession = Depends(get_db),
):
    actual_limit = min(limit or DEFAULT_LIMIT, MAX_LIMIT)
    actual_offset = offset or 0

    items: list[SearchIndexRow] = []
    total = 0

    # Search across sources, functions, and types based on kind filter
    kinds_to_search = [kind] if kind else ["source", "function", "type"]

    for k in kinds_to_search:
        if k == "source":
            query = select(Source)
            if q:
                query = query.where(Source.name.ilike(f"%{q}%"))
            if source_id:
                query = query.where(Source.id == source_id)

            count = await db.scalar(select(func.count()).select_from(query.subquery()))
            total += count

            results = await db.execute(query.offset(actual_offset).limit(actual_limit))
            for s in results.scalars().all():
                items.append(
                    SearchIndexRow(
                        kind="source",
                        id=str(s.id),
                        created_at=s.created_at,
                        name=s.name,
                        source_id=s.id,
                    )
                )

        elif k == "function":
            query = select(Function)
            if function_guid:
                query = query.where(Function.guid == function_guid)
            if commit_id:
                query = query.where(Function.commit_id == commit_id)
            if source_id:
                query = query.where(Function.source_id == source_id)
            if q:
                # Join with symbol to search by name
                query = query.join(Symbol, Symbol.id == Function.symbol_id).where(
                    Symbol.name.ilike(f"%{q}%")
                )

            count = await db.scalar(select(func.count()).select_from(query.subquery()))
            total += count

            results = await db.execute(query.offset(actual_offset).limit(actual_limit))
            for f in results.scalars().all():
                row = SearchIndexRow(
                    kind="function",
                    id=str(f.id),
                    created_at=f.created_at,
                    source_id=f.source_id,
                    function_guid=f.guid,
                    symbol_id=f.symbol_id,
                    commit_id=f.commit_id,
                    data=list(f.data) if retrieve_data and f.data else None,
                )
                items.append(row)

        elif k == "type":
            query = select(Type)
            if source_id:
                query = query.where(Type.source_id == source_id)
            if q:
                query = query.where(Type.name.ilike(f"%{q}%"))

            count = await db.scalar(select(func.count()).select_from(query.subquery()))
            total += count

            results = await db.execute(query.offset(actual_offset).limit(actual_limit))
            for t in results.scalars().all():
                row = SearchIndexRow(
                    kind="type",
                    id=str(t.id),
                    created_at=t.created_at,
                    name=t.name,
                    source_id=t.source_id,
                    commit_id=t.commit_id,
                    data=list(t.data) if retrieve_data and t.data else None,
                )
                items.append(row)

    return SearchResponse(
        total=total,
        limit=actual_limit,
        offset=actual_offset,
        items=items,
    )
