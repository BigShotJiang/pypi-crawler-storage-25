from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user
from warp_server.database import get_db
from warp_server.models import Source, SourceTag, SourceUser, User
from warp_server.schemas import (
    CreateSourceRequest,
    PaginatedResponse,
    PutSourceRequest,
    SourceMdl,
    SourceQueryRequest,
    SourceTagMdl,
    SourceUserMdl,
)

router = APIRouter(prefix="/api/v1/sources", tags=["sources"])

DEFAULT_LIMIT = 20


def _source_mdl(s: Source) -> SourceMdl:
    return SourceMdl(id=s.id, created_at=s.created_at, name=s.name)


@router.post("", response_model=SourceMdl)
async def create_source(
    body: CreateSourceRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    source = Source(name=body.name)
    db.add(source)
    await db.flush()

    # Add requesting user if not in the list
    user_ids = set(body.user_ids)
    user_ids.add(user.id)
    for uid in user_ids:
        db.add(SourceUser(source_id=source.id, user_id=uid))

    db.add(SourceTag(source_id=source.id, tag="trusted"))

    await db.commit()
    await db.refresh(source)
    return _source_mdl(source)


@router.post("/query", response_model=PaginatedResponse[SourceMdl])
async def query_sources(body: SourceQueryRequest, db: AsyncSession = Depends(get_db)):
    query = select(Source)
    if body.name:
        if body.exact:
            query = query.where(Source.name == body.name)
        else:
            query = query.where(Source.name.ilike(f"%{body.name}%"))
    if body.user_id is not None:
        query = query.join(SourceUser).where(SourceUser.user_id == body.user_id)

    total = await db.scalar(select(func.count()).select_from(query.subquery()))
    limit = body.limit or DEFAULT_LIMIT
    page = body.page or 1
    offset = (page - 1) * limit
    results = await db.execute(query.offset(offset).limit(limit))
    sources = results.scalars().all()
    total_pages = max(1, -(-total // limit))

    return PaginatedResponse(
        items=[_source_mdl(s) for s in sources],
        total_pages=total_pages,
        total_results=total,
    )


@router.get("/{source_id}", response_model=SourceMdl)
async def get_source_by_id(source_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Source).where(Source.id == source_id))
    source = result.scalar_one_or_none()
    if source is None:
        raise HTTPException(status_code=404, detail="Source not found")
    return _source_mdl(source)


async def _check_source_access(db: AsyncSession, source_id: UUID, user: User) -> Source:
    result = await db.execute(select(Source).where(Source.id == source_id))
    source = result.scalar_one_or_none()
    if source is None:
        raise HTTPException(status_code=404, detail="Source not found")
    if user.role == "Admin":
        return source
    su = await db.execute(
        select(SourceUser).where(
            SourceUser.source_id == source_id, SourceUser.user_id == user.id
        )
    )
    if su.scalar_one_or_none() is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authorized"
        )
    return source


@router.post("/{source_id}/", status_code=200)
async def update_source(
    source_id: UUID,
    body: PutSourceRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    source = await _check_source_access(db, source_id, user)

    if body.name is not None:
        source.name = body.name

    if body.user_ids is not None:
        await db.execute(
            SourceUser.__table__.delete().where(SourceUser.source_id == source_id)
        )
        for uid in body.user_ids:
            db.add(SourceUser(source_id=source_id, user_id=uid))

    if body.tags is not None:
        # Only admins can set tags.
        if user.role != "Admin":
            raise HTTPException(status_code=403, detail="Only admins can set tags")
        await db.execute(
            SourceTag.__table__.delete().where(SourceTag.source_id == source_id)
        )
        for tag in body.tags:
            db.add(SourceTag(source_id=source_id, tag=tag))

    await db.commit()


@router.delete("/{source_id}/", status_code=204)
async def delete_source(
    source_id: UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    source = await _check_source_access(db, source_id, user)
    await db.delete(source)
    await db.commit()
    return Response(status_code=204)


@router.get("/{source_id}/tags", response_model=list[SourceTagMdl])
async def list_source_tags(source_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(SourceTag).where(SourceTag.source_id == source_id))
    return [
        SourceTagMdl(source_id=t.source_id, tag=t.tag) for t in result.scalars().all()
    ]


@router.get("/{source_id}/users", response_model=list[SourceUserMdl])
async def list_source_users(source_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(SourceUser).where(SourceUser.source_id == source_id)
    )
    return [
        SourceUserMdl(source_id=su.source_id, user_id=su.user_id)
        for su in result.scalars().all()
    ]
