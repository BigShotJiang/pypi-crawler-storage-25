from collections import defaultdict

from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.database import get_db
from warp_server.models import (
    Function,
    FunctionComment,
    FunctionConstraint,
    SourceTag,
    Symbol,
)
from warp_server.models import Type as TypeModel
from warp_server.schemas import (
    FunctionCommentMdl,
    FunctionConstraintMdl,
    FunctionMdl,
    FunctionQueryRequest,
    PaginatedResponse,
    SymbolMdl,
    TypeMdl,
)
from warp_server.warp_parser import build_warp_file

router = APIRouter(prefix="/api/v1/functions", tags=["functions"])

DEFAULT_LIMIT = 20


def _func_mdl(f: Function) -> FunctionMdl:
    return FunctionMdl(
        id=f.id,
        created_at=f.created_at,
        commit_id=f.commit_id,
        target_id=f.target_id,
        source_id=f.source_id,
        guid=f.guid,
        symbol_id=f.symbol_id,
        type_id=f.type_id,
    )


def _build_function_query(body: FunctionQueryRequest):
    query = select(Function)
    if body.guids:
        query = query.where(Function.guid.in_(body.guids))
    if body.source_id:
        query = query.where(Function.source_id == body.source_id)
    if body.target_id:
        query = query.where(Function.target_id == body.target_id)
    if body.commit_id:
        query = query.where(Function.commit_id == body.commit_id)
    if body.symbol_id:
        query = query.where(Function.symbol_id == body.symbol_id)
    if body.source_tags:
        query = query.join(SourceTag, SourceTag.source_id == Function.source_id).where(
            SourceTag.tag.in_(body.source_tags)
        )
    return query


@router.post("/query")
async def query_functions(
    body: FunctionQueryRequest, db: AsyncSession = Depends(get_db)
):
    query = _build_function_query(body)

    if body.format == "flatbuffer":
        results = await db.execute(query)
        funcs = results.scalars().all()
        func_data = [f.data for f in funcs if f.data]
        blob = build_warp_file(func_data, [])
        return Response(content=blob, media_type="application/octet-stream")

    total = await db.scalar(select(func.count()).select_from(query.subquery()))
    limit = body.limit or DEFAULT_LIMIT
    page = body.page or 1
    offset = (page - 1) * limit
    results = await db.execute(query.offset(offset).limit(limit))
    funcs = results.scalars().all()
    total_pages = max(1, -(-total // limit))

    return PaginatedResponse(
        items=[_func_mdl(f) for f in funcs],
        total_pages=total_pages,
        total_results=total,
    )


@router.post("/query/source")
async def query_functions_source(
    body: FunctionQueryRequest, db: AsyncSession = Depends(get_db)
):
    query = _build_function_query(body)
    results = await db.execute(query)
    funcs = results.scalars().all()
    mapping: dict[str, list[str]] = defaultdict(list)
    for f in funcs:
        mapping[str(f.source_id)].append(str(f.guid))
    return mapping


@router.post("/data")
async def get_function_datas(body: dict, db: AsyncSession = Depends(get_db)):
    ids = body.get("ids", [])
    if not ids:
        return Response(content=b"", media_type="application/octet-stream")
    results = await db.execute(select(Function).where(Function.id.in_(ids)))
    funcs = results.scalars().all()
    func_data = [f.data for f in funcs if f.data]
    blob = build_warp_file(func_data, [])
    return Response(content=blob, media_type="application/octet-stream")


@router.get("/{function_id}", response_model=FunctionMdl)
async def get_function_by_id(function_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Function).where(Function.id == function_id))
    f = result.scalar_one_or_none()
    if f is None:
        raise HTTPException(status_code=404, detail="Function not found")
    return _func_mdl(f)


@router.get("/{function_id}/comments", response_model=list[FunctionCommentMdl])
async def get_function_comments(function_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(FunctionComment).where(FunctionComment.function_id == function_id)
    )
    return [
        FunctionCommentMdl(
            id=c.id, function_id=c.function_id, text=c.text, byte_offset=c.byte_offset
        )
        for c in result.scalars().all()
    ]


@router.get("/{function_id}/constraints", response_model=list[FunctionConstraintMdl])
async def get_function_constraints(
    function_id: int, db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(FunctionConstraint).where(FunctionConstraint.function_id == function_id)
    )
    return [
        FunctionConstraintMdl(
            id=c.id, function_id=c.function_id, guid=c.guid, byte_offset=c.byte_offset
        )
        for c in result.scalars().all()
    ]


@router.get("/{function_id}/data")
async def get_function_data(function_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Function).where(Function.id == function_id))
    f = result.scalar_one_or_none()
    if f is None:
        raise HTTPException(status_code=404, detail="Function not found")
    return Response(content=f.data or b"", media_type="application/octet-stream")


@router.get("/{function_id}/symbol", response_model=SymbolMdl)
async def get_function_symbol(function_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Function).where(Function.id == function_id))
    f = result.scalar_one_or_none()
    if f is None:
        raise HTTPException(status_code=404, detail="Function not found")
    sym_result = await db.execute(select(Symbol).where(Symbol.id == f.symbol_id))
    sym = sym_result.scalar_one_or_none()
    if sym is None:
        raise HTTPException(status_code=404, detail="Symbol not found")
    return SymbolMdl(
        id=sym.id,
        created_at=sym.created_at,
        name=sym.name,
        **{"class": sym.symbol_class},
        modifier=sym.modifier,
    )


@router.get("/{function_id}/type", response_model=TypeMdl)
async def get_function_type(function_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Function).where(Function.id == function_id))
    f = result.scalar_one_or_none()
    if f is None:
        raise HTTPException(status_code=404, detail="Function not found")
    if f.type_id is None:
        raise HTTPException(status_code=404, detail="Function has no type")
    type_result = await db.execute(select(TypeModel).where(TypeModel.id == f.type_id))
    t = type_result.scalar_one_or_none()
    if t is None:
        raise HTTPException(status_code=404, detail="Type not found")
    return TypeMdl(
        id=t.id,
        created_at=t.created_at,
        commit_id=t.commit_id,
        source_id=t.source_id,
        name=t.name,
        data=list(t.data) if t.data else [],
    )
