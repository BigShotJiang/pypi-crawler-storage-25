from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.database import get_db
from warp_server.models import Symbol
from warp_server.schemas import PaginatedResponse, SymbolMdl, SymbolQueryRequest

router = APIRouter(prefix="/api/v1/symbols", tags=["symbols"])

DEFAULT_LIMIT = 20


def _symbol_mdl(s: Symbol) -> SymbolMdl:
    return SymbolMdl(
        id=s.id,
        created_at=s.created_at,
        name=s.name,
        **{"class": s.symbol_class},
        modifier=s.modifier,
    )


@router.post("/query", response_model=PaginatedResponse[SymbolMdl])
async def query_symbols(body: SymbolQueryRequest, db: AsyncSession = Depends(get_db)):
    query = select(Symbol)
    if body.name:
        if body.exact:
            query = query.where(Symbol.name == body.name)
        else:
            query = query.where(Symbol.name.ilike(f"%{body.name}%"))
    total = await db.scalar(select(func.count()).select_from(query.subquery()))
    limit = body.limit or DEFAULT_LIMIT
    page = body.page or 1
    offset = (page - 1) * limit
    results = await db.execute(query.offset(offset).limit(limit))
    symbols = results.scalars().all()
    total_pages = max(1, -(-total // limit))
    return PaginatedResponse(
        items=[_symbol_mdl(s) for s in symbols],
        total_pages=total_pages,
        total_results=total,
    )


@router.get("/{symbol_id}", response_model=SymbolMdl)
async def get_symbol_by_id(symbol_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Symbol).where(Symbol.id == symbol_id))
    sym = result.scalar_one_or_none()
    if sym is None:
        raise HTTPException(status_code=404, detail="Symbol not found")
    return _symbol_mdl(sym)
