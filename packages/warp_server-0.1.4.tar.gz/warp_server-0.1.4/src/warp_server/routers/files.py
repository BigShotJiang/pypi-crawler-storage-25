import asyncio
import base64
import logging
import time
from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user
from warp_server.database import get_db
from warp_server.models import (
    Commit,
    Function,
    FunctionComment,
    FunctionConstraint,
    Source,
    SourceUser,
    Symbol,
    Target,
    User,
)
from warp_server.models import Type as TypeModel
from warp_server.schemas import PushResponse
from warp_server.schemas import UploadFileJson as UploadFileJsonSchema
from warp_server.warp_parser import ParsedChunk, parse_warp_file

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/files", tags=["files"])


async def _check_push_access(db: AsyncSession, source_id, user: User) -> Source:
    result = await db.execute(select(Source).where(Source.id == source_id))
    source = result.scalar_one_or_none()
    if source is None:
        raise HTTPException(status_code=404, detail="Source not found")
    if user.role == "Admin":
        return source
    su = await db.execute(
        select(SourceUser).where(
            SourceUser.source_id == source_id, SourceUser.user_id == user.id
        )
    )
    if su.scalar_one_or_none() is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authorized"
        )
    return source


@router.post("", response_model=PushResponse)
async def push_file_multipart(
    file: UploadFile,
    name: str,
    source: str,
    description: str | None = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    source_id = UUID(source)
    await _check_push_access(db, source_id, user)

    file_bytes = await file.read()
    logger.info("Upload %s: %d bytes received", name, len(file_bytes))

    t0 = time.perf_counter()
    try:
        chunks = await asyncio.to_thread(parse_warp_file, file_bytes)
    except Exception:
        logger.exception("Failed to parse warp file")
        raise HTTPException(status_code=400, detail="Invalid warp file")
    t_parse = time.perf_counter()

    n_funcs = sum(len(c.functions) for c in chunks)
    n_types = sum(len(c.types) for c in chunks)
    logger.info(
        "Upload %s: parsed %d chunks, %d functions, %d types in %.1f ms",
        name,
        len(chunks),
        n_funcs,
        n_types,
        (t_parse - t0) * 1000,
    )

    commit = Commit(
        source_id=source_id,
        user_id=user.id,
        name=name,
        description=description,
    )
    db.add(commit)
    await db.flush()

    await _ingest_chunks(db, chunks, commit.id, source_id)
    await db.commit()
    t_db = time.perf_counter()

    logger.info(
        "Upload %s: DB ingestion done in %.1f ms (total %.1f ms)",
        name,
        (t_db - t_parse) * 1000,
        (t_db - t0) * 1000,
    )

    await db.refresh(commit)
    return PushResponse(commit_id=commit.id)


@router.post("/json", response_model=PushResponse)
async def push_file_json(
    body: UploadFileJsonSchema,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    await _check_push_access(db, body.source, user)

    try:
        file_bytes = base64.b64decode(body.file)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid base64 file data")

    try:
        chunks = await asyncio.to_thread(parse_warp_file, file_bytes)
    except Exception:
        logger.exception("Failed to parse warp file")
        raise HTTPException(status_code=400, detail="Invalid warp file")

    commit = Commit(
        source_id=body.source,
        user_id=user.id,
        name=body.name,
        description=body.description,
    )
    db.add(commit)
    await db.flush()

    try:
        await _ingest_chunks(db, chunks, commit.id, body.source)
        await db.commit()
    except Exception:
        logger.exception(
            "Failed to ingest file %s (%d bytes)", body.name, len(file_bytes)
        )
        await db.rollback()
        raise HTTPException(status_code=500, detail="Ingestion failed")

    await db.refresh(commit)
    return PushResponse(commit_id=commit.id)


# ---------------------------------------------------------------------------
# Ingestion logic
# ---------------------------------------------------------------------------

BATCH_SIZE = 500


async def _get_or_create_target(
    db: AsyncSession,
    platform: str | None,
    arch: str | None,
    cache: dict[tuple, Target],
) -> Target:
    key = (platform, arch)
    if key in cache:
        return cache[key]
    result = await db.execute(
        select(Target).where(Target.platform == platform, Target.arch == arch)
    )
    target = result.scalar_one_or_none()
    if target is None:
        target = Target(platform=platform, arch=arch)
        db.add(target)
        await db.flush()
    cache[key] = target
    return target


async def _resolve_symbols(
    db: AsyncSession,
    chunks: list[ParsedChunk],
) -> dict[tuple, int]:
    """Pre-fetch or create all symbols referenced by the chunks.

    Returns a mapping (name, class, modifier) → symbol.id.
    """
    needed: set[tuple[str, str, str]] = set()
    for chunk in chunks:
        for pf in chunk.functions:
            needed.add((pf.symbol.name, pf.symbol.symbol_class, pf.symbol.modifier))

    if not needed:
        return {}

    # Fetch existing symbols in one query
    result = await db.execute(select(Symbol))
    existing = {
        (s.name, s.symbol_class, s.modifier): s.id for s in result.scalars().all()
    }

    cache: dict[tuple, int] = {}
    to_create: list[Symbol] = []
    for name, cls, mod in needed:
        key = (name, cls, mod)
        if key in existing:
            cache[key] = existing[key]
        else:
            to_create.append(Symbol(name=name, symbol_class=cls, modifier=mod))

    if to_create:
        db.add_all(to_create)
        await db.flush()
        for sym in to_create:
            cache[(sym.name, sym.symbol_class, sym.modifier)] = sym.id

    return cache


async def _bulk_insert_types(
    db: AsyncSession,
    chunks: list[ParsedChunk],
    commit_id: int,
    source_id: UUID,
) -> None:
    """Insert all types using INSERT OR IGNORE to skip duplicates."""
    now = datetime.now(timezone.utc)
    rows = []
    seen: set[UUID] = set()
    for chunk in chunks:
        for pt in chunk.types:
            if pt.guid in seen:
                continue
            seen.add(pt.guid)
            rows.append(
                {
                    "id": pt.guid,
                    "commit_id": commit_id,
                    "source_id": source_id,
                    "name": pt.name,
                    "data": pt.data,
                    "created_at": now,
                }
            )

    for i in range(0, len(rows), BATCH_SIZE):
        batch = rows[i : i + BATCH_SIZE]
        stmt = sqlite_insert(TypeModel).values(batch).on_conflict_do_nothing()
        await db.execute(stmt)
    if rows:
        await db.flush()


async def _ingest_chunks(
    db: AsyncSession,
    chunks: list[ParsedChunk],
    commit_id: int,
    source_id: UUID,
) -> None:
    target_cache: dict[tuple, Target] = {}

    # Phase 3a: resolve all symbols up front
    t0 = time.perf_counter()
    sym_cache = await _resolve_symbols(db, chunks)
    t_sym = time.perf_counter()
    logger.info(
        "Ingest: resolved %d symbols in %.1f ms", len(sym_cache), (t_sym - t0) * 1000
    )

    # Phase 3b: batch-insert types
    await _bulk_insert_types(db, chunks, commit_id, source_id)
    t_types = time.perf_counter()
    n_types = sum(len(c.types) for c in chunks)
    logger.info(
        "Ingest: inserted types (%d) in %.1f ms", n_types, (t_types - t_sym) * 1000
    )

    # Phase 3c: batch-insert functions, comments, constraints
    now = datetime.now(timezone.utc)
    func_rows: list[dict] = []
    # Deferred comments/constraints keyed by position in func_rows
    pending_comments: list[list[dict]] = []
    pending_constraints: list[list[dict]] = []

    for chunk in chunks:
        target = await _get_or_create_target(
            db, chunk.target.platform, chunk.target.architecture, target_cache
        )

        for pf in chunk.functions:
            sym_key = (pf.symbol.name, pf.symbol.symbol_class, pf.symbol.modifier)
            func_rows.append(
                {
                    "commit_id": commit_id,
                    "target_id": target.id,
                    "source_id": source_id,
                    "guid": pf.guid,
                    "symbol_id": sym_cache[sym_key],
                    "type_id": pf.type_guid,
                    "data": pf.data,
                    "created_at": now,
                }
            )
            pending_comments.append(
                [{"text": c.text, "byte_offset": c.byte_offset} for c in pf.comments]
            )
            pending_constraints.append(
                [{"guid": c.guid, "byte_offset": c.byte_offset} for c in pf.constraints]
            )

    # Insert functions in batches and collect their IDs
    all_func_ids: list[int] = []
    for i in range(0, len(func_rows), BATCH_SIZE):
        batch = func_rows[i : i + BATCH_SIZE]
        result = await db.execute(
            Function.__table__.insert().returning(Function.__table__.c.id), batch
        )
        all_func_ids.extend(row[0] for row in result)
    t_funcs = time.perf_counter()
    logger.info(
        "Ingest: inserted %d functions in %.1f ms",
        len(all_func_ids),
        (t_funcs - t_types) * 1000,
    )

    # Now bulk-insert comments and constraints with the real function IDs
    comment_rows: list[dict] = []
    constraint_rows: list[dict] = []
    for idx, func_id in enumerate(all_func_ids):
        for c in pending_comments[idx]:
            comment_rows.append({**c, "function_id": func_id})
        for c in pending_constraints[idx]:
            constraint_rows.append({**c, "function_id": func_id})

    for i in range(0, len(comment_rows), BATCH_SIZE):
        await db.execute(
            FunctionComment.__table__.insert(),
            comment_rows[i : i + BATCH_SIZE],
        )
    for i in range(0, len(constraint_rows), BATCH_SIZE):
        await db.execute(
            FunctionConstraint.__table__.insert(),
            constraint_rows[i : i + BATCH_SIZE],
        )
    t_end = time.perf_counter()
    logger.info(
        "Ingest: inserted %d comments + %d constraints in %.1f ms",
        len(comment_rows),
        len(constraint_rows),
        (t_end - t_funcs) * 1000,
    )
