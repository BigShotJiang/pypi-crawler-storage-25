from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user
from warp_server.database import get_db
from warp_server.models import Commit, SourceUser, User
from warp_server.schemas import CommitMdl, CommitQueryRequest, PaginatedResponse

router = APIRouter(prefix="/api/v1/commits", tags=["commits"])

DEFAULT_LIMIT = 20


def _commit_mdl(c: Commit) -> CommitMdl:
    return CommitMdl(
        id=c.id,
        created_at=c.created_at,
        source_id=c.source_id,
        user_id=c.user_id,
        name=c.name,
        description=c.description,
    )


@router.post("/query", response_model=PaginatedResponse[CommitMdl])
async def query_commits(body: CommitQueryRequest, db: AsyncSession = Depends(get_db)):
    query = select(Commit)
    if body.source_id:
        query = query.where(Commit.source_id == body.source_id)
    total = await db.scalar(select(func.count()).select_from(query.subquery()))
    limit = body.limit or DEFAULT_LIMIT
    page = body.page or 1
    offset = (page - 1) * limit
    results = await db.execute(
        query.order_by(Commit.id.desc()).offset(offset).limit(limit)
    )
    commits = results.scalars().all()
    total_pages = max(1, -(-total // limit))
    return PaginatedResponse(
        items=[_commit_mdl(c) for c in commits],
        total_pages=total_pages,
        total_results=total,
    )


@router.get("/{commit_id}", response_model=CommitMdl)
async def get_commit(commit_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Commit).where(Commit.id == commit_id))
    commit = result.scalar_one_or_none()
    if commit is None:
        raise HTTPException(status_code=404, detail="Commit not found")
    return _commit_mdl(commit)


@router.delete("/{commit_id}", status_code=200)
async def delete_commit(
    commit_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(select(Commit).where(Commit.id == commit_id))
    commit = result.scalar_one_or_none()
    if commit is None:
        raise HTTPException(status_code=404, detail="Commit not found")

    # Must be admin or in source users
    if user.role != "Admin":
        su = await db.execute(
            select(SourceUser).where(
                SourceUser.source_id == commit.source_id,
                SourceUser.user_id == user.id,
            )
        )
        if su.scalar_one_or_none() is None:
            raise HTTPException(status_code=401, detail="Not authorized")

    await db.delete(commit)
    await db.commit()
    return Response(status_code=200)
