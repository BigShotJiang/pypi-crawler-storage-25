import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from warp_server.config import settings
from warp_server.database import engine
from warp_server.models import Base
from warp_server.routers import (
    auth,
    commits,
    files,
    functions,
    search,
    sources,
    status,
    symbols,
    targets,
    types,
    users,
)

logger = logging.getLogger("warp_server")


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


app = FastAPI(title="warp-server", version="0.1.0", lifespan=lifespan)


@app.middleware("http")
async def log_request_duration(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    elapsed_ms = (time.perf_counter() - start) * 1000
    logger.info(
        "%s %s → %d (%.1f ms)",
        request.method,
        request.url.path,
        response.status_code,
        elapsed_ms,
    )
    return response


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


app = FastAPI(title="warp-server", version="0.1.0", lifespan=lifespan)

app.include_router(status.router)
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(sources.router)
app.include_router(commits.router)
app.include_router(targets.router)
app.include_router(symbols.router)
app.include_router(functions.router)
app.include_router(files.router)
app.include_router(types.router)
app.include_router(search.router)

# -- Static web UI ---------------------------------------------------------
_static_dir = Path(__file__).parent / "static"

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

if _static_dir.is_dir():
    app.mount("/web-ui/static", StaticFiles(directory=_static_dir), name="static")

    @app.get("/web-ui", response_class=HTMLResponse)
    async def web_ui():
        return HTMLResponse((_static_dir / "index.html").read_text())


def run():
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-5s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    uvicorn.run(
        "warp_server.main:app",
        host=settings.host,
        port=settings.port,
        reload=True,
    )


if __name__ == "__main__":
    run()
