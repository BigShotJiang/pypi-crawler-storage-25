import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Column,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    LargeBinary,
    String,
    Text,
    Uuid,
)
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


# ── Users ────────────────────────────────────────────────────────────


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    email = Column(String, unique=True, nullable=False)
    username = Column(String, unique=True, nullable=False)
    role = Column(
        Enum("User", "Admin", name="user_role"), default="User", nullable=False
    )
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )

    api_keys = relationship(
        "ApiKey", back_populates="user", cascade="all, delete-orphan"
    )


class ApiKey(Base):
    __tablename__ = "api_keys"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(
        Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    key = Column(String, unique=True, nullable=False)
    name = Column(String, nullable=False)
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    expires_at = Column(DateTime, nullable=True)
    last_used_at = Column(DateTime, nullable=True)

    user = relationship("User", back_populates="api_keys")


# ── Sources ──────────────────────────────────────────────────────────


class Source(Base):
    __tablename__ = "sources"

    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False)
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )

    tags = relationship(
        "SourceTag", back_populates="source", cascade="all, delete-orphan"
    )
    users = relationship(
        "SourceUser", back_populates="source", cascade="all, delete-orphan"
    )


class SourceTag(Base):
    __tablename__ = "source_tags"

    id = Column(Integer, primary_key=True, autoincrement=True)
    source_id = Column(
        Uuid, ForeignKey("sources.id", ondelete="CASCADE"), nullable=False
    )
    tag = Column(String, nullable=False)

    source = relationship("Source", back_populates="tags")


class SourceUser(Base):
    __tablename__ = "source_users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    source_id = Column(
        Uuid, ForeignKey("sources.id", ondelete="CASCADE"), nullable=False
    )
    user_id = Column(
        Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )

    source = relationship("Source", back_populates="users")


# ── Targets ──────────────────────────────────────────────────────────


class Target(Base):
    __tablename__ = "targets"

    id = Column(Integer, primary_key=True, autoincrement=True)
    platform = Column(String, nullable=True)
    arch = Column(String, nullable=True)
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )


# ── Commits ──────────────────────────────────────────────────────────


class Commit(Base):
    __tablename__ = "commits"

    id = Column(Integer, primary_key=True, autoincrement=True)
    source_id = Column(
        Uuid, ForeignKey("sources.id", ondelete="CASCADE"), nullable=False
    )
    user_id = Column(
        Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    name = Column(String, nullable=True)
    description = Column(Text, nullable=True)
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )


# ── Symbols ──────────────────────────────────────────────────────────


class Symbol(Base):
    __tablename__ = "symbols"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    symbol_class = Column(
        Enum("Bare", "Data", "Function", name="symbol_class"),
        nullable=False,
        default="Function",
    )
    modifier = Column(
        Enum("None", "Extern", "Exported", name="symbol_modifier"),
        nullable=False,
        default="None",
    )
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )


# ── Functions ────────────────────────────────────────────────────────


class Function(Base):
    __tablename__ = "functions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    commit_id = Column(
        Integer, ForeignKey("commits.id", ondelete="CASCADE"), nullable=False
    )
    target_id = Column(Integer, ForeignKey("targets.id"), nullable=False)
    source_id = Column(
        Uuid, ForeignKey("sources.id", ondelete="CASCADE"), nullable=False
    )
    guid = Column(Uuid, nullable=False)
    symbol_id = Column(Integer, ForeignKey("symbols.id"), nullable=False)
    type_id = Column(Uuid, ForeignKey("types.id"), nullable=True)
    data = Column(LargeBinary, nullable=True)
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )

    comments = relationship(
        "FunctionComment", back_populates="function", cascade="all, delete-orphan"
    )
    constraints = relationship(
        "FunctionConstraint", back_populates="function", cascade="all, delete-orphan"
    )


class FunctionComment(Base):
    __tablename__ = "function_comments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    function_id = Column(
        Integer, ForeignKey("functions.id", ondelete="CASCADE"), nullable=False
    )
    text = Column(Text, nullable=False)
    byte_offset = Column(Integer, nullable=False)

    function = relationship("Function", back_populates="comments")


class FunctionConstraint(Base):
    __tablename__ = "function_constraints"

    id = Column(Integer, primary_key=True, autoincrement=True)
    function_id = Column(
        Integer, ForeignKey("functions.id", ondelete="CASCADE"), nullable=False
    )
    guid = Column(Uuid, nullable=False)
    byte_offset = Column(Integer, nullable=True)

    function = relationship("Function", back_populates="constraints")


# ── Types ────────────────────────────────────────────────────────────


class Type(Base):
    __tablename__ = "types"

    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    commit_id = Column(
        Integer, ForeignKey("commits.id", ondelete="CASCADE"), nullable=False
    )
    source_id = Column(
        Uuid, ForeignKey("sources.id", ondelete="CASCADE"), nullable=False
    )
    name = Column(String, nullable=True)
    data = Column(LargeBinary, nullable=False)
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
