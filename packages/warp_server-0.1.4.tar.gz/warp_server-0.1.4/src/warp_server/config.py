from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "sqlite+aiosqlite:///./warp.db"
    secret_key: str = "change-me-in-production"
    host: str = "127.0.0.1"
    port: int = 8000
    log_level: str = "info"

    model_config = {"env_prefix": "WARP_"}


settings = Settings()
