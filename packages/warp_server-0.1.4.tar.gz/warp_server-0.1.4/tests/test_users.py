import pytest
from httpx import AsyncClient

from tests.conftest import auth_headers
from warp_server.models import User


@pytest.mark.asyncio
async def test_get_current_user(
    client: AsyncClient, admin_token: str, admin_user: User
):
    resp = await client.get("/api/v1/users/me", headers=auth_headers(admin_token))
    assert resp.status_code == 200
    data = resp.json()
    assert data["username"] == "admin"
    assert data["role"] == "Admin"


@pytest.mark.asyncio
async def test_get_current_user_unauthorized(client: AsyncClient):
    resp = await client.get("/api/v1/users/me")
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_create_user_as_admin(client: AsyncClient, admin_token: str):
    resp = await client.post(
        "/api/v1/users",
        json={"email": "new@test.com", "name": "newuser"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["username"] == "newuser"
    assert data["role"] == "User"


@pytest.mark.asyncio
async def test_create_user_as_non_admin(client: AsyncClient, user_token: str):
    resp = await client.post(
        "/api/v1/users",
        json={"email": "blocked@test.com"},
        headers=auth_headers(user_token),
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_query_users(client: AsyncClient, admin_user: User, regular_user: User):
    resp = await client.post("/api/v1/users/query", json={})
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_results"] == 2
    assert len(data["items"]) == 2


@pytest.mark.asyncio
async def test_query_users_by_name(
    client: AsyncClient, admin_user: User, regular_user: User
):
    resp = await client.post(
        "/api/v1/users/query", json={"name": "admin", "exact": True}
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_results"] == 1
    assert data["items"][0]["username"] == "admin"


@pytest.mark.asyncio
async def test_get_user_by_id(client: AsyncClient, admin_user: User):
    resp = await client.get(f"/api/v1/users/{admin_user.id}")
    assert resp.status_code == 200
    assert resp.json()["username"] == "admin"


@pytest.mark.asyncio
async def test_get_user_not_found(client: AsyncClient):
    resp = await client.get("/api/v1/users/9999")
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_change_role(client: AsyncClient, admin_token: str, regular_user: User):
    resp = await client.patch(
        f"/api/v1/users/{regular_user.id}/role",
        json={"role": "Admin"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 200
    assert resp.json()["role"] == "Admin"


@pytest.mark.asyncio
async def test_change_username(
    client: AsyncClient, admin_token: str, regular_user: User
):
    resp = await client.patch(
        f"/api/v1/users/{regular_user.id}/username",
        json={"username": "renamed"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 200
    assert resp.json()["username"] == "renamed"


@pytest.mark.asyncio
async def test_change_username_conflict(
    client: AsyncClient, admin_token: str, admin_user: User, regular_user: User
):
    resp = await client.patch(
        f"/api/v1/users/{regular_user.id}/username",
        json={"username": "admin"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 409


@pytest.mark.asyncio
async def test_delete_user(client: AsyncClient, admin_token: str, regular_user: User):
    resp = await client.delete(
        f"/api/v1/users/{regular_user.id}", headers=auth_headers(admin_token)
    )
    assert resp.status_code == 204
    resp = await client.get(f"/api/v1/users/{regular_user.id}")
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_api_keys_flow(client: AsyncClient, admin_token: str, admin_user: User):
    # List keys (should have the test key)
    resp = await client.get("/api/v1/users/me/keys", headers=auth_headers(admin_token))
    assert resp.status_code == 200
    assert len(resp.json()) == 1

    # Create a new key
    resp = await client.post(
        "/api/v1/users/me/keys",
        json={"name": "new-key"},
        headers=auth_headers(admin_token),
    )
    assert resp.status_code == 201
    new_key = resp.json()
    assert "key" in new_key

    # List again
    resp = await client.get("/api/v1/users/me/keys", headers=auth_headers(admin_token))
    assert len(resp.json()) == 2
