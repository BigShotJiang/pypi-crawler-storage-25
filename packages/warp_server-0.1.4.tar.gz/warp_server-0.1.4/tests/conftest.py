import secrets

import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from warp_server.database import get_db
from warp_server.main import app
from warp_server.models import ApiKey, Base, User


@pytest_asyncio.fixture
async def db_session():
    engine = create_async_engine("sqlite+aiosqlite://", echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    async with session_factory() as session:
        yield session

    await engine.dispose()


@pytest_asyncio.fixture
async def client(db_session: AsyncSession):
    async def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def admin_user(db_session: AsyncSession) -> User:
    user = User(email="admin@test.com", username="admin", role="Admin")
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


@pytest_asyncio.fixture
async def regular_user(db_session: AsyncSession) -> User:
    user = User(email="user@test.com", username="testuser", role="User")
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


@pytest_asyncio.fixture
async def admin_token(db_session: AsyncSession, admin_user: User) -> str:
    key = secrets.token_urlsafe(32)
    api_key = ApiKey(user_id=admin_user.id, key=key, name="admin-key")
    db_session.add(api_key)
    await db_session.commit()
    return key


@pytest_asyncio.fixture
async def user_token(db_session: AsyncSession, regular_user: User) -> str:
    key = secrets.token_urlsafe(32)
    api_key = ApiKey(user_id=regular_user.id, key=key, name="user-key")
    db_session.add(api_key)
    await db_session.commit()
    return key


def auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}
