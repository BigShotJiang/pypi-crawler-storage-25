import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from tests.conftest import auth_headers
from warp_server.models import Commit, Source, SourceUser, User


@pytest.fixture
async def source_with_commits(db_session: AsyncSession, regular_user: User):
    source = Source(name="commit-src")
    db_session.add(source)
    await db_session.flush()
    db_session.add(SourceUser(source_id=source.id, user_id=regular_user.id))

    for i in range(3):
        db_session.add(
            Commit(
                source_id=source.id,
                user_id=regular_user.id,
                name=f"commit-{i}",
            )
        )
    await db_session.commit()
    return source


@pytest.mark.asyncio
async def test_query_commits(client: AsyncClient, source_with_commits):
    resp = await client.post("/api/v1/commits/query", json={})
    assert resp.status_code == 200
    assert resp.json()["total_results"] == 3


@pytest.mark.asyncio
async def test_query_commits_by_source(client: AsyncClient, source_with_commits):
    resp = await client.post(
        "/api/v1/commits/query",
        json={"source_id": str(source_with_commits.id)},
    )
    assert resp.status_code == 200
    assert resp.json()["total_results"] == 3


@pytest.mark.asyncio
async def test_get_commit(client: AsyncClient, source_with_commits, db_session):
    from sqlalchemy import select
    from warp_server.models import Commit

    result = await db_session.execute(select(Commit).limit(1))
    commit = result.scalar_one()

    resp = await client.get(f"/api/v1/commits/{commit.id}")
    assert resp.status_code == 200
    assert resp.json()["id"] == commit.id


@pytest.mark.asyncio
async def test_get_commit_not_found(client: AsyncClient, source_with_commits):
    resp = await client.get("/api/v1/commits/9999")
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_delete_commit(
    client: AsyncClient,
    user_token: str,
    source_with_commits,
    db_session: AsyncSession,
):
    from sqlalchemy import select
    from warp_server.models import Commit

    result = await db_session.execute(select(Commit).limit(1))
    commit = result.scalar_one()

    resp = await client.delete(
        f"/api/v1/commits/{commit.id}", headers=auth_headers(user_token)
    )
    assert resp.status_code == 200

    resp = await client.get(f"/api/v1/commits/{commit.id}")
    assert resp.status_code == 404
