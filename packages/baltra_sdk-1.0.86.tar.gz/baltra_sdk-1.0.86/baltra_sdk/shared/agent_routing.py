"""Centralised agent-routing configuration and selector.

Phone-number IDs listed here are routed to the Skills agent; everything
else falls back to the SOLID path.

For phone numbers in ``PARTIAL_SKILLS_PHONE_NUMBER_IDS`` only ~20 % of
candidates are routed to Skills — specifically those whose
``candidate_id`` ends in **1** or **2**.
"""

from __future__ import annotations

# Phone number IDs that are *always* routed to the Skills agent.
SKILLS_PHONE_NUMBER_IDS: set[str] = {
    "309958495536131",
    "989297707605833",
    "672466825958746",
}

# Phone number IDs where only ~20 % of candidates use Skills.
#"767534513119374","885376867996134",
# A candidate qualifies when ``str(candidate_id)`` ends in '1' or '2'.
PARTIAL_SKILLS_PHONE_NUMBER_IDS: set[str] = set()

# Union kept for quick "is this phone number Skills-eligible at all?" checks.
ALL_SKILLS_PHONE_NUMBER_IDS: set[str] = SKILLS_PHONE_NUMBER_IDS | PARTIAL_SKILLS_PHONE_NUMBER_IDS

_PARTIAL_ROUTING_SUFFIXES = {"1", "2"}


def select_agent(
    phone_number_id: str | None,
    candidate_id: str | int | None = None,
) -> str:
    """Return ``'skills'`` or ``'solid'`` for a given routing context.

    Parameters
    ----------
    phone_number_id:
        The WhatsApp Business phone-number ID that received the message.
    candidate_id:
        Optional candidate identifier.  Required for partial-routing phone
        numbers — when absent those numbers default to ``'solid'``.
    """
    if not phone_number_id:
        return "solid"

    # 100 % routing
    if phone_number_id in SKILLS_PHONE_NUMBER_IDS:
        return "skills"

    # 20 % routing — needs candidate_id
    if phone_number_id in PARTIAL_SKILLS_PHONE_NUMBER_IDS:
        if candidate_id is not None and str(candidate_id)[-1] in _PARTIAL_ROUTING_SUFFIXES:
            return "skills"
        return "solid"

    return "solid"
