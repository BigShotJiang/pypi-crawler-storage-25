# Baltra SDK — Release Notes

## v1.0.72 — Current

| Table | Column | Change |
|-------|--------|--------|
| `candidates` | `application_reminders_sent` | Updated default value |

### Details

**`candidates.application_reminders_sent`**
Default keys updated to match the actual keys written by the application-reminders-worker:
```json
{
  "reminder_20": null,
  "reminder_02": null,
  "reminder_23_5": null
}
```
Values are `null` when not sent, or an ISO 8601 UTC timestamp string when sent.

### Migration Status

| Database | Applied |
|----------|---------|
| `baltra-chatbot-nonprod-db-instance.cdyoauyystls.us-east-2.rds.amazonaws.com` | ⬜ Pending |
| `chatbot-db-instance.cdyoauyystls.us-east-2.rds.amazonaws.com` | ⬜ Pending |

