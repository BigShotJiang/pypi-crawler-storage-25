"""Killswitch — emergency close all positions, cancel all orders, transfer all funds."""

import os
import sys

import typer

from regard.core.output import output, die


def _log(msg: str):
    """Progress output to stderr — doesn't break JSON on stdout."""
    print(msg, file=sys.stderr, flush=True)

killswitch_app = typer.Typer(
    name="killswitch",
    invoke_without_command=True,
    help="Emergency close all positions, cancel all orders, transfer all funds.",
)


def _get_killswitch_address() -> str | None:
    from regard.venues.hyperliquid.client import _load_settings_env
    return _load_settings_env().get("KILLSWITCH_ADDRESS")


def _get_killswitch_slippage() -> float:
    from regard.venues.hyperliquid.client import _load_settings_env
    from regard.commands.config import DEFAULT_KILLSWITCH_SLIPPAGE
    val = _load_settings_env().get("KILLSWITCH_SLIPPAGE")
    if val:
        try:
            return float(val)
        except (ValueError, TypeError):
            pass
    return DEFAULT_KILLSWITCH_SLIPPAGE


def _is_agent_key() -> bool:
    """True if using an agent key (limited permissions), False if master key."""
    from regard.venues.hyperliquid.client import _load_settings_env
    settings = _load_settings_env()
    return bool(
        os.environ.get("HYPERLIQUID_AGENT_KEY")
        or settings.get("HYPERLIQUID_AGENT_KEY")
    )


@killswitch_app.callback()
def killswitch(
    ctx: typer.Context,
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would happen without executing"),
):
    """Cancel all orders, market-close all positions, transfer all funds across all venues."""
    dest = _get_killswitch_address()
    if not dest:
        die("validation_error", "NO_KILLSWITCH_ADDRESS",
            "No killswitch address configured",
            hint="Set KILLSWITCH_ADDRESS via the config command first",
            exit_code=2)

    if dry_run:
        _log("[killswitch] DRY RUN — no actions will be taken")

    results = {"destination": dest, "dry_run": dry_run, "hl": None, "poly": None}

    _log(f"[killswitch] destination: {dest}")

    # --- Hyperliquid ---
    _log("[killswitch] Hyperliquid...")
    try:
        results["hl"] = _kill_hl(dest, dry_run=dry_run)
    except SystemExit:
        raise
    except Exception as e:
        _log(f"[killswitch] HL error: {e}")
        results["hl"] = {"error": str(e)}

    # --- Polymarket ---
    _log("[killswitch] Polymarket...")
    try:
        results["poly"] = _kill_poly(dest, dry_run=dry_run)
    except SystemExit:
        raise
    except Exception as e:
        _log(f"[killswitch] Poly error: {e}")
        results["poly"] = {"error": str(e)}

    output(results, None)


def _kill_hl(dest: str, dry_run: bool = False) -> dict:
    from regard.venues.hyperliquid.client import (
        get_exchange, get_address, get_all_positions, get_all_orders,
        get_spot_balances, get_dex_balances,
    )
    from regard.venues.hyperliquid.resolver import get_resolver

    exchange = get_exchange()
    info = exchange.info
    addr = get_address()
    agent_mode = _is_agent_key()

    # Load HIP-3 dex metadata so SDK's name_to_asset works for all coins
    resolver = get_resolver(info)
    resolver._load_dexes()

    # 1. Cancel all orders
    all_orders = get_all_orders(info, addr)
    cancelled = 0
    if all_orders:
        _log(f"  cancelling {len(all_orders)} orders...")
        if not dry_run:
            cancel_requests = [{"coin": o["coin"], "oid": o["oid"]} for o in all_orders]
            exchange.bulk_cancel(cancel_requests)
        cancelled = len(all_orders)
        _log(f"  {'would cancel' if dry_run else 'cancelled'} {cancelled}")
    else:
        _log("  no open orders")

    # 2. Close all positions at market via SDK market_close
    slippage = _get_killswitch_slippage()
    positions = get_all_positions(info, addr)
    _log(f"  closing {len(positions)} positions (slippage {slippage:.0%})...")
    closed = []
    for pos in positions:
        coin = pos["coin"]
        szi = float(pos["szi"])
        if szi == 0:
            continue
        side = "buy" if szi < 0 else "sell"
        size = abs(szi)
        _log(f"  {coin} {side} {size}...")
        if dry_run:
            _log(f"    would close")
            closed.append({"asset": coin, "side": side, "size": size, "status": "dry_run"})
            continue
        try:
            resp = exchange.market_close(coin, slippage=slippage)
            if resp is None:
                _log(f"    FAIL: not found by SDK")
                closed.append({"asset": coin, "side": side, "size": size, "error": "market_close returned None — position not found by SDK"})
                continue
            if resp.get("status") == "err":
                _log(f"    FAIL: {resp.get('response', '')}")
                closed.append({"asset": coin, "side": side, "size": size, "error": resp.get("response", str(resp))})
                continue
            statuses = resp.get("response", {}).get("data", {}).get("statuses", [])
            if statuses and "filled" in statuses[0]:
                filled = statuses[0]["filled"]
                _log(f"    filled @ {filled.get('avgPx', '?')}")
                closed.append({"asset": coin, "side": side, "size": filled.get("totalSz", str(size)), "avg_price": filled.get("avgPx", ""), "status": "filled"})
            elif statuses and "error" in statuses[0]:
                _log(f"    FAIL: {statuses[0]['error']}")
                closed.append({"asset": coin, "side": side, "size": size, "error": statuses[0]["error"]})
            else:
                _log(f"    FAIL: no fill")
                closed.append({"asset": coin, "side": side, "size": size, "error": "no fill — IOC expired", "response": str(statuses)})
        except Exception as e:
            _log(f"    FAIL: {e}")
            closed.append({"asset": coin, "side": side, "size": size, "error": str(e)})

    # 3. Transfer all funds to destination
    _log("  transferring funds...")
    transferred = []
    from regard.venues.hyperliquid.client import get_account_mode
    is_unified = get_account_mode(info, addr) == "unifiedAccount"

    # Build token name → send_asset identifier map
    # Canonical tokens (like USDC) use plain name. Non-canonical (USDH, USDE, USDT0)
    # need "NAME:tokenId" format for the Hyperliquid API.
    spot_meta = info.spot_meta()
    token_send_name = {}
    for t in spot_meta["tokens"]:
        if t.get("isCanonical", False):
            token_send_name[t["name"]] = t["name"]
        else:
            token_send_name[t["name"]] = f"{t['name']}:{t['tokenId']}"

    if is_unified:
        # Unified accounts: all equity in spot. Use send_asset to transfer to destination.
        # spot_transfer is disabled on unified accounts; send_asset(dest, "spot", "spot", ...) works.
        # Re-read balances fresh (positions just closed, balances may have changed).
        try:
            spot = get_spot_balances(info, addr)
            for s in spot:
                bal = float(s["balance"])
                if bal <= 0:
                    continue
                # Leave tiny dust to avoid "Insufficient balance" from rounding
                send_amount = round(bal - 0.01, 6) if bal > 0.02 else bal
                if send_amount <= 0:
                    continue
                send_name = token_send_name.get(s["token"], s["token"])
                _log(f"    {s['token']} {send_amount}...")
                if dry_run:
                    _log(f"      would send")
                    transferred.append({"source": "spot", "token": s["token"], "amount": send_amount, "status": "dry_run"})
                else:
                    try:
                        resp = exchange.send_asset(dest, "spot", "spot", send_name, send_amount)
                        if resp.get("status") == "err":
                            _log(f"      FAIL: {resp.get('response', '')}")
                            transferred.append({"source": "spot", "token": s["token"], "error": resp.get("response", str(resp))})
                        else:
                            _log(f"      sent")
                            transferred.append({"source": "spot", "token": s["token"], "amount": send_amount})
                    except Exception as e:
                        _log(f"      FAIL: {e}")
                        transferred.append({"source": "spot", "token": s["token"], "error": str(e)})
        except Exception as e:
            transferred.append({"source": "spot", "error": str(e)})
    else:
        # Standard accounts: perp + spot + HIP-3 dex balances
        # Order: perp USDC → dex→spot consolidation → wait → spot sweep

        # 3a. Default perp USDC
        try:
            state = info.user_state(addr)
            withdrawable = float(state.get("withdrawable", "0"))
            if withdrawable > 0.01:
                _log(f"    USDC {withdrawable}...")
                if dry_run:
                    _log(f"      would send")
                    transferred.append({"source": "perp", "token": "USDC", "amount": withdrawable, "status": "dry_run"})
                else:
                    exchange.usd_transfer(withdrawable, dest)
                    _log(f"      sent")
                    transferred.append({"source": "perp", "token": "USDC", "amount": withdrawable})
        except Exception as e:
            transferred.append({"source": "perp", "token": "USDC", "error": str(e)})

        # 3b. HIP-3 dex balances → consolidate to spot (master key only)
        consolidated_any = False
        try:
            from regard.venues.hyperliquid.client import get_collateral_map
            coll_map = get_collateral_map(info)
            dex_bals = get_dex_balances(info, addr)
            for d in dex_bals:
                dex = d.get("dex", "")
                if not dex or dex in ("spot", "default"):
                    continue
                val = float(d.get("account_value", 0))
                if val <= 0.01:
                    continue
                if agent_mode:
                    transferred.append({
                        "source": f"dex:{dex}", "amount": val,
                        "error": "agent key cannot transfer HIP-3 dex funds — use master key or withdraw via Hyperliquid UI",
                    })
                else:
                    token_name = coll_map.get(dex, ("USDC", 0))[0]
                    send_name = token_send_name.get(token_name, token_name)
                    try:
                        _log(f"    dex:{dex} → spot  {token_name} {val}...")
                        if dry_run:
                            _log(f"      would consolidate")
                            transferred.append({"source": f"dex:{dex}", "token": token_name, "amount": val, "consolidated": True, "status": "dry_run"})
                        else:
                            exchange.send_asset(addr, dex, "spot", send_name, val)
                            _log(f"      consolidated")
                            transferred.append({"source": f"dex:{dex}", "token": token_name, "amount": val, "consolidated": True})
                        consolidated_any = True
                    except Exception as e:
                        _log(f"      FAIL: {e}")
                        transferred.append({"source": f"dex:{dex}", "token": token_name, "error": str(e)})
        except Exception as e:
            transferred.append({"source": "dex_scan", "error": str(e)})

        # 3c. Wait for dex→spot settlement before sweeping
        if consolidated_any and not dry_run:
            import time
            _log("    waiting for settlement (3s)...")
            time.sleep(3)

        # 3d. Sweep all spot balances to destination
        try:
            spot = get_spot_balances(info, addr)
            for s in spot:
                bal = float(s["balance"])
                if bal <= 0:
                    continue
                send_amount = round(bal - 0.01, 6) if bal > 0.02 else bal
                if send_amount <= 0:
                    continue
                send_name = token_send_name.get(s["token"], s["token"])
                _log(f"    {s['token']} {send_amount}...")
                if dry_run:
                    _log(f"      would send")
                    transferred.append({"source": "spot", "token": s["token"], "amount": send_amount, "status": "dry_run"})
                else:
                    try:
                        exchange.spot_transfer(send_amount, dest, send_name)
                        _log(f"      sent")
                        transferred.append({"source": "spot", "token": s["token"], "amount": send_amount})
                    except Exception as e:
                        _log(f"      FAIL: {e}")
                        transferred.append({"source": "spot", "token": s["token"], "error": str(e)})
        except Exception as e:
            transferred.append({"source": "spot", "error": str(e)})

        # 3e. Final default perp sweep — catches USDC consolidated from USDC-collateral dexes
        if not agent_mode and not dry_run:
            try:
                state = info.user_state(addr)
                withdrawable = float(state.get("withdrawable", "0"))
                if withdrawable > 0.01:
                    exchange.usd_transfer(withdrawable, dest)
                    transferred.append({"source": "perp_final", "token": "USDC", "amount": withdrawable})
            except Exception:
                pass

    return {
        "cancelled_orders": cancelled,
        "closed_positions": closed,
        "transferred": transferred,
        "key_mode": "agent" if agent_mode else "master",
    }


CTF_REDEEM_ABI = [{"inputs":[{"name":"collateralToken","type":"address"},{"name":"parentCollectionId","type":"bytes32"},{"name":"conditionId","type":"bytes32"},{"name":"indexSets","type":"uint256[]"}],"name":"redeemPositions","outputs":[],"type":"function"}]
CTF_MERGE_ABI = [{"inputs":[{"name":"collateralToken","type":"address"},{"name":"parentCollectionId","type":"bytes32"},{"name":"conditionId","type":"bytes32"},{"name":"partition","type":"uint256[]"},{"name":"amount","type":"uint256"}],"name":"mergePositions","outputs":[],"type":"function"}]


def _ctf_call(condition_id: str, size: float, token_id: str, action: str) -> dict:
    """Execute a redeem or merge on the CTF contract."""
    from regard.venues.polymarket.client import _get_key, get_web3, CONTRACTS
    from regard.core.evm import get_safe_gas_price, simulate_and_send
    import eth_account as ea

    w3 = get_web3()
    account = ea.Account.from_key(_get_key())
    sender = w3.to_checksum_address(account.address)
    collateral_addr = CONTRACTS["USDC_E"]
    cid_bytes = bytes.fromhex(condition_id[2:] if condition_id.startswith("0x") else condition_id)

    if action == "redeem":
        ctf = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["CTF"]), abi=CTF_REDEEM_ABI)
        fn = ctf.functions.redeemPositions(
            w3.to_checksum_address(collateral_addr), bytes(32), cid_bytes, [1, 2],
        )
    else:
        ctf = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["CTF"]), abi=CTF_MERGE_ABI)
        # Merge amount in token units (6 decimals for USDC.e-backed CTF)
        amount_raw = int(round(size * 10**6))
        fn = ctf.functions.mergePositions(
            w3.to_checksum_address(collateral_addr), bytes(32), cid_bytes, [1, 2], amount_raw,
        )

    gas_price = get_safe_gas_price(w3)
    nonce = w3.eth.get_transaction_count(sender, "pending")
    tx = fn.build_transaction({"from": sender, "nonce": nonce, "gas": 200_000, "gasPrice": gas_price, "chainId": 137})
    tx_hash = simulate_and_send(w3, tx, account)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
    if receipt["status"] != 1:
        raise RuntimeError(f"{action} tx reverted: {tx_hash.hex()}")
    _log(f"      {action}ed (tx {tx_hash.hex()})")
    return {"token_id": token_id, "action": action, "size": size, "tx": tx_hash.hex()}


def _ctf_redeem(condition_id: str, size: float, token_id: str) -> dict:
    return _ctf_call(condition_id, size, token_id, "redeem")


def _ctf_merge(condition_id: str, size: float, token_id: str) -> dict:
    return _ctf_call(condition_id, size, token_id, "merge")


def _kill_poly(dest: str, dry_run: bool = False) -> dict:
    from regard.venues.polymarket.client import get_clob_client, check_geo_block, _get_key, get_web3, CONTRACTS

    # Check if Polymarket is configured
    try:
        _get_key()
    except SystemExit:
        return {"skipped": "not configured"}

    # Check geo-restriction
    try:
        check_geo_block()
    except SystemExit:
        return {"error": "geo-blocked — connect via allowed region to close Polymarket positions"}

    clob = get_clob_client()

    # 1. Cancel all orders
    _log("  cancelling orders...")
    if not dry_run:
        try:
            clob.cancel_all()
        except Exception:
            pass

    # 2. Close all positions
    from regard.venues.polymarket.client import get_positions
    positions_error = None
    try:
        pos_list = get_positions(raise_on_error=True)
    except Exception as e:
        _log(f"  WARN: failed to fetch positions: {e}")
        positions_error = str(e)
        pos_list = []

    # Deduplicate mergeable positions by conditionId — both YES and NO entries
    # return mergeable=True for the same condition, but merge only needs one call
    merged_conditions = set()

    _log(f"  closing {len(pos_list)} positions...")
    closed = []
    for p in pos_list:
        size = float(p.get("size", 0) or 0)
        if size == 0:
            continue
        token_id = p.get("asset_id", "")
        condition_id = p.get("condition_id", "")
        side = p.get("side", "")
        close_side = "SELL" if side == "BUY" else "BUY"

        if p.get("redeemable") and condition_id:
            # Resolved market — redeem winning tokens for USDC.e on-chain
            _log(f"    {token_id[:16]}... redeem (resolved)")
            if dry_run:
                closed.append({"token_id": token_id, "action": "redeem", "size": size, "status": "dry_run"})
                continue
            try:
                closed.append(_ctf_redeem(condition_id, size, token_id))
            except Exception as e:
                _log(f"      FAIL: {e}")
                closed.append({"token_id": token_id, "action": "redeem", "error": str(e)})
        elif p.get("mergeable") and condition_id:
            if condition_id in merged_conditions:
                _log(f"    {token_id[:16]}... skip (already merged)")
                continue
            merged_conditions.add(condition_id)
            # Hold both outcomes — merge for USDC.e on-chain (cheaper than CLOB sell)
            _log(f"    {token_id[:16]}... merge (both outcomes held)")
            if dry_run:
                closed.append({"token_id": token_id, "action": "merge", "size": size, "status": "dry_run"})
                continue
            try:
                closed.append(_ctf_merge(condition_id, size, token_id))
            except Exception as e:
                _log(f"      FAIL: {e}")
                closed.append({"token_id": token_id, "action": "merge", "error": str(e)})
        else:
            # Active market — FOK sell on CLOB
            _log(f"    {token_id[:16]}... {close_side} {size}")
            if dry_run:
                closed.append({"token_id": token_id, "side": close_side, "size": size, "status": "dry_run"})
                continue
            try:
                from py_clob_client_v2.clob_types import OrderArgs as ClobOrderArgs, OrderType
                from py_clob_client_v2.order_builder.constants import BUY as CLOB_BUY, SELL as CLOB_SELL
                order_side = CLOB_SELL if close_side == "SELL" else CLOB_BUY
                price = 0.01 if close_side == "SELL" else 0.99
                order_args = ClobOrderArgs(
                    token_id=token_id,
                    price=price,
                    size=size,
                    side=order_side,
                )
                signed = clob.create_order(order_args)
                clob.post_order(signed, OrderType.FOK)
                closed.append({"token_id": token_id, "side": close_side, "size": size})
            except Exception as e:
                closed.append({"token_id": token_id, "error": str(e)})

    # 3. Transfer all tokens on Polygon to destination
    _log("  transferring tokens...")
    transferred = []
    try:
        import eth_account

        w3 = get_web3()
        key = _get_key()
        account = eth_account.Account.from_key(key)
        sender = w3.to_checksum_address(account.address)
        dest_checksum = w3.to_checksum_address(dest)
        nonce = w3.eth.get_transaction_count(sender, "pending")

        from regard.core.evm import get_safe_gas_price, simulate_and_send

        TRANSFER_ABI = [
            {"constant": False, "inputs": [{"name": "_to", "type": "address"}, {"name": "_value", "type": "uint256"}],
             "name": "transfer", "outputs": [{"name": "", "type": "bool"}], "type": "function"},
            {"constant": True, "inputs": [{"name": "_owner", "type": "address"}],
             "name": "balanceOf", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
        ]

        USDC_NATIVE = "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"
        tokens = [
            ("USDC.e", CONTRACTS["USDC_E"]),
            ("USDC", USDC_NATIVE),
        ]

        for label, token_addr in tokens:
            try:
                contract = w3.eth.contract(address=w3.to_checksum_address(token_addr), abi=TRANSFER_ABI)
                balance = contract.functions.balanceOf(sender).call()
                if balance == 0:
                    continue
                _log(f"    {label} {balance / 1e6}...")
                if dry_run:
                    transferred.append({"token": label, "amount": balance / 1e6, "status": "dry_run"})
                    continue
                gas_price = get_safe_gas_price(w3)
                tx = contract.functions.transfer(dest_checksum, balance).build_transaction({
                    "from": sender,
                    "nonce": nonce,
                    "gas": 100_000,
                    "gasPrice": gas_price,
                    "chainId": 137,
                })
                tx_hash = simulate_and_send(w3, tx, account)
                _log(f"      sent tx {tx_hash.hex()}")
                transferred.append({"token": label, "amount": balance / 1e6, "tx_hash": tx_hash.hex()})
                nonce += 1
            except Exception as e:
                transferred.append({"token": label, "error": str(e)})

        # Transfer native POL (keep gas for the tx itself)
        try:
            pol_balance = w3.eth.get_balance(sender)
            gas_price = get_safe_gas_price(w3)
            gas_cost = 21000 * gas_price
            if pol_balance > gas_cost * 2:
                _log(f"    POL {(pol_balance - gas_cost) / 1e18:.6f}...")
                if dry_run:
                    transferred.append({"token": "POL", "amount": (pol_balance - gas_cost) / 1e18, "status": "dry_run"})
                else:
                    tx = {
                        "from": sender,
                        "to": dest_checksum,
                        "value": pol_balance - gas_cost,
                        "gas": 21000,
                        "gasPrice": gas_price,
                        "nonce": nonce,
                        "chainId": 137,
                    }
                    tx_hash = simulate_and_send(w3, tx, account)
                    _log(f"      sent tx {tx_hash.hex()}")
                    transferred.append({"token": "POL", "amount": (pol_balance - gas_cost) / 1e18, "tx_hash": tx_hash.hex()})
        except Exception as e:
            transferred.append({"token": "POL", "error": str(e)})

    except Exception as e:
        transferred.append({"error": str(e)})

    result = {"cancelled_orders": "all", "closed_positions": closed, "transferred": transferred}
    if positions_error:
        result["positions_fetch_error"] = positions_error
    return result
