"""Cold-start adapter tests — SDK state not pre-seeded.

Unlike the main test suite which pre-populates coin_to_asset, these tests
start with only default perps loaded (like production) and verify that
lazy-loading, token format resolution, and balance parsing work against
real API response shapes.

Mocks only the HTTP boundary (Info.post / Info.meta). Internal SDK state
management (coin_to_asset, set_perp_meta) uses real implementations.
"""

import pytest
from unittest.mock import MagicMock, patch

from regard.venues.hyperliquid.resolver import Resolver
from regard.venues.hyperliquid.client import get_spot_balances, get_collateral_map


# ---------------------------------------------------------------------------
# Realistic API response shapes — copied from real mainnet responses
# ---------------------------------------------------------------------------

DEFAULT_META = {
    "universe": [
        {"name": "BTC", "szDecimals": 5, "maxLeverage": 50},
        {"name": "ETH", "szDecimals": 4, "maxLeverage": 50},
        {"name": "SOL", "szDecimals": 2, "maxLeverage": 20},
    ]
}

XYZ_META = {
    "universe": [
        {"name": "xyz:TSLA", "szDecimals": 1, "maxLeverage": 10},
        {"name": "xyz:CL", "szDecimals": 0, "maxLeverage": 10},
        {"name": "xyz:NATGAS", "szDecimals": 0, "maxLeverage": 5},
    ]
}

FLX_META = {
    "universe": [
        {"name": "flx:DOGE", "szDecimals": 0, "maxLeverage": 5},
    ]
}

PERP_DEXS = [
    None,              # default dex is None on mainnet
    {"name": "xyz"},
    {"name": "flx"},
]

ALL_PERP_METAS = [
    {"universe": DEFAULT_META["universe"], "collateralToken": 0},
    {"universe": XYZ_META["universe"], "collateralToken": 0},
    {"universe": FLX_META["universe"], "collateralToken": 360},
]

SPOT_META = {
    "tokens": [
        {"name": "USDC", "szDecimals": 2, "weiDecimals": 8, "index": 0, "tokenId": "0x1", "isCanonical": True},
        {"name": "HYPE", "szDecimals": 2, "weiDecimals": 18, "index": 1, "tokenId": "0x2", "isCanonical": True},
        {"name": "USDH", "szDecimals": 2, "weiDecimals": 8, "index": 360, "tokenId": "0x54e00a", "isCanonical": False},
        {"name": "USDE", "szDecimals": 2, "weiDecimals": 18, "index": 235, "tokenId": "0x3b2e8", "isCanonical": False},
    ],
    "universe": [
        {"tokens": [1, 0], "name": "HYPE/USDC", "index": 0, "isCanonical": True},
    ],
}

# Real shape from spot_user_state API — uses "token" key (not "coin")
SPOT_BALANCES_UNIFIED = {
    "balances": [
        {"token": 0, "total": "17.32"},
        {"token": 360, "total": "14.56"},
        {"token": 235, "total": "11.97"},
    ]
}

SPOT_BALANCES_LEGACY = {
    "balances": [
        {"token": 0, "holds": "1732000000", "withdrawn": "0"},       # USDC: 17.32 (8 weiDecimals)
        {"token": 360, "holds": "1456000000", "withdrawn": "0"},     # USDH: 14.56 (8 weiDecimals)
    ]
}


# ---------------------------------------------------------------------------
# Helper: semi-real Info mock
# ---------------------------------------------------------------------------

def _make_cold_info():
    """Create an Info-like mock with real state management but mocked HTTP.

    Starts with ONLY default perps in coin_to_asset (like production).
    set_perp_meta is the real implementation so lazy-loading actually works.
    """
    info = MagicMock()

    # Real state — only default perps loaded at init (production behavior)
    info.coin_to_asset = {}
    info.name_to_coin = {}
    info.asset_to_sz_decimals = {}

    # Load default perps (what Info.__init__ does)
    for asset, asset_info in enumerate(DEFAULT_META["universe"]):
        info.coin_to_asset[asset_info["name"]] = asset
        info.name_to_coin[asset_info["name"]] = asset_info["name"]
        info.asset_to_sz_decimals[asset] = asset_info["szDecimals"]

    # Load spot (what Info.__init__ does)
    for spot_info in SPOT_META["universe"]:
        asset = spot_info["index"] + 10000
        info.coin_to_asset[spot_info["name"]] = asset

    # Real set_perp_meta — updates coin_to_asset when called
    def _set_perp_meta(meta, offset):
        for asset_idx, asset_info in enumerate(meta["universe"]):
            a = asset_idx + offset
            info.coin_to_asset[asset_info["name"]] = a
            info.name_to_coin[asset_info["name"]] = asset_info["name"]
            info.asset_to_sz_decimals[a] = asset_info["szDecimals"]
    info.set_perp_meta = _set_perp_meta

    # Mock HTTP boundary — returns realistic data by request type
    def _post(endpoint, payload):
        req_type = payload.get("type", "")
        dex = payload.get("dex", "")
        if req_type == "perpDexs":
            return list(PERP_DEXS)
        if req_type == "meta":
            if dex == "xyz":
                return dict(XYZ_META)
            if dex == "flx":
                return dict(FLX_META)
            return dict(DEFAULT_META)
        if req_type == "allPerpMetas":
            return list(ALL_PERP_METAS)
        if req_type == "spotMeta":
            return dict(SPOT_META)
        return {}
    info.post.side_effect = _post

    # meta() delegates to post (like real SDK)
    def _meta(dex=""):
        return _post("/info", {"type": "meta", "dex": dex})
    info.meta.side_effect = _meta

    info.spot_meta.return_value = dict(SPOT_META)
    info.spot_user_state.return_value = dict(SPOT_BALANCES_UNIFIED)

    return info


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestResolverColdStart:
    """Resolver starts with empty HIP-3 state, loads lazily."""

    def test_default_perp_resolves_immediately(self):
        info = _make_cold_info()
        r = Resolver(info)
        assert r.resolve("BTC") == "BTC"
        assert r.resolve("eth") == "ETH"  # case-insensitive

    def test_hip3_full_name_resolves_after_lazy_load(self):
        """xyz:CL is NOT in coin_to_asset initially. Resolver must lazy-load."""
        info = _make_cold_info()
        r = Resolver(info)

        assert "xyz:CL" not in info.coin_to_asset  # not pre-seeded
        result = r.resolve("xyz:CL")
        assert result == "xyz:CL"
        assert "xyz:CL" in info.coin_to_asset  # now loaded

    def test_hip3_short_name_resolves_after_lazy_load(self):
        """Bare 'CL' should resolve to 'xyz:CL' via short map."""
        info = _make_cold_info()
        r = Resolver(info)

        result = r.resolve("CL")
        assert result == "xyz:CL"

    def test_hip3_from_second_dex_resolves(self):
        """Assets on non-xyz dexes also lazy-load correctly."""
        info = _make_cold_info()
        r = Resolver(info)

        assert "flx:DOGE" not in info.coin_to_asset
        result = r.resolve("flx:DOGE")
        assert result == "flx:DOGE"

    def test_unknown_asset_dies(self):
        """Completely unknown asset fails cleanly after lazy-load attempt."""
        info = _make_cold_info()
        r = Resolver(info)

        with pytest.raises(SystemExit) as exc_info:
            r.resolve("DOESNOTEXIST")
        assert exc_info.value.code == 2  # validation_error

    def test_all_dexes_loaded_on_first_miss(self):
        """A single miss triggers loading ALL dexes, not just one."""
        info = _make_cold_info()
        r = Resolver(info)

        r.resolve("xyz:CL")
        # flx:DOGE should also be available now (loaded in same batch)
        assert "flx:DOGE" in info.coin_to_asset


class TestSpotBalanceParsing:
    """Verify balance parsing uses correct API response keys."""

    def test_unified_format_uses_token_key(self):
        """Real API returns 'token' (int index), not 'coin'."""
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_UNIFIED)

        balances = get_spot_balances(info, "0xTEST")
        tokens = {b["token"] for b in balances}
        assert "USDC" in tokens
        assert "USDH" in tokens
        assert "USDE" in tokens

    def test_unified_format_correct_amounts(self):
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_UNIFIED)

        balances = get_spot_balances(info, "0xTEST")
        by_token = {b["token"]: b["balance"] for b in balances}
        assert by_token["USDC"] == "17.32"
        assert by_token["USDH"] == "14.56"

    def test_legacy_format_uses_token_key(self):
        """Legacy format (holds/withdrawn in wei) also uses 'token' key."""
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_LEGACY)

        balances = get_spot_balances(info, "0xTEST")
        tokens = {b["token"] for b in balances}
        assert "USDC" in tokens
        assert "USDH" in tokens

    def test_legacy_format_wei_conversion(self):
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_LEGACY)

        balances = get_spot_balances(info, "0xTEST")
        by_token = {b["token"]: b["balance"] for b in balances}
        assert by_token["USDC"] == "17.32"   # 1732000000 / 10^8
        assert by_token["USDH"] == "14.56"   # 1456000000 / 10^8


class TestTokenFormatResolution:
    """Transfer path must build TOKEN:tokenId for non-canonical tokens."""

    def test_non_canonical_gets_token_id_suffix(self):
        """USDH is non-canonical → must become 'USDH:0x54e00a' for send_asset."""
        info = _make_cold_info()
        spot_meta = info.spot_meta()

        for t in spot_meta["tokens"]:
            if t["name"] == "USDH":
                assert not t["isCanonical"]
                expected = f"{t['name']}:{t['tokenId']}"
                assert expected == "USDH:0x54e00a"
                break
        else:
            pytest.fail("USDH not found in spot meta")

    def test_canonical_stays_plain(self):
        """USDC is canonical → stays as plain 'USDC'."""
        info = _make_cold_info()
        spot_meta = info.spot_meta()

        for t in spot_meta["tokens"]:
            if t["name"] == "USDC":
                assert t["isCanonical"]
                break
        else:
            pytest.fail("USDC not found in spot meta")

    def test_transfer_propose_builds_sdk_token(self):
        """Full transfer propose path resolves non-canonical token format."""
        from typer.testing import CliRunner
        from regard.main import app

        info = _make_cold_info()
        info.query_user_abstraction_state.return_value = "default"
        info.user_state.return_value = {"withdrawable": "100.00"}

        with patch("regard.venues.hyperliquid.commands.act.get_info", return_value=info), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xTEST"), \
             patch("regard.venues.hyperliquid.commands.act.get_exchange"), \
             patch("regard.venues.hyperliquid.commands.act.get_account_mode", return_value="default"), \
             patch("regard.venues.hyperliquid.commands.act.get_collateral_map", return_value={
                 "": ("USDC", 0), "flx": ("USDH", 360),
             }):
            runner = CliRunner()
            result = runner.invoke(app, ["hl", "transfer", "5.00", "--from", "spot", "--to", "flx", "--token", "USDH"])

            import json
            data = json.loads(result.output)
            assert data["ok"]
            assert data["data"]["params"]["sdk_token"] == "USDH:0x54e00a"
            assert data["data"]["params"]["token"] == "USDH"


class TestCollateralMapResolution:
    """Collateral map correctly maps dexes to their collateral tokens."""

    def test_non_usdc_collateral(self):
        """flx uses USDH (token index 360), not USDC."""
        info = _make_cold_info()
        coll_map = get_collateral_map(info)

        assert coll_map[""] == ("USDC", 0)       # default dex key is ""
        assert coll_map["xyz"] == ("USDC", 0)
        assert coll_map["flx"] == ("USDH", 360)
