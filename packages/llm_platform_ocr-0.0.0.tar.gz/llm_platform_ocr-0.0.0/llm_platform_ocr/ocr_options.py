from typing import Union, Required, Optional, TypedDict, Literal


class OpenAIOcrOption(TypedDict):
    type: Literal["openai"]
    api_key: Required[str]
    model: Optional[str]

OCROption = Union[
    OpenAIOcrOption,
]

