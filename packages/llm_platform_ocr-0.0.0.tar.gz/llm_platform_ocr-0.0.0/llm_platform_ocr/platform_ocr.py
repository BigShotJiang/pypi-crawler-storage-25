from .core.get_ocr_client import get_ocr_client
from .core.ocr_client import OCRClient
from .ocr_options import OCROption


class PlatformOCR:

    def __init__(self, ocr_option: OCROption):
        self._ocr_client: OCRClient = get_ocr_client(ocr_option=ocr_option)


    async def execute(self, base64_image: str) -> str:
        return await self._ocr_client.execute(base64_image)