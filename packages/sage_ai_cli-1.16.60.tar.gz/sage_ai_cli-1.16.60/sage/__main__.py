"""Entry point for running sage as a module: python -m sage"""

from __future__ import annotations

import sys


def _windows_startup() -> None:
    """One-time Windows console setup: UTF-8 encoding + ANSI escape codes.

    Must run before any Rich output or file I/O so that:
    - Unicode characters in model responses aren't mangled by CP1252
    - Rich colour/box-drawing works without extra user config
    - The 'sage' command behaves identically to macOS/Linux
    """
    if sys.platform != "win32":
        return

    import os

    # Force UTF-8 for all standard streams (Python 3.7+).
    # This mirrors CPython's PYTHONUTF8 mode without requiring the user to set it.
    os.environ.setdefault("PYTHONUTF8", "1")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")

    # Enable Virtual Terminal Processing (ANSI escape codes) on Windows 10+.
    # Without this, Rich's colour output prints raw escape sequences instead
    # of colours.  The call is a no-op on older Windows or Wine.
    try:
        import ctypes
        import ctypes.wintypes

        STD_OUTPUT_HANDLE = -11
        STD_ERROR_HANDLE = -12
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004

        kernel32 = ctypes.windll.kernel32
        for handle_id in (STD_OUTPUT_HANDLE, STD_ERROR_HANDLE):
            handle = kernel32.GetStdHandle(handle_id)
            if handle and handle != ctypes.wintypes.HANDLE(-1).value:
                mode = ctypes.wintypes.DWORD()
                if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                    kernel32.SetConsoleMode(
                        handle, mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING
                    )
    except Exception:
        pass  # Non-fatal: Rich degrades gracefully without ANSI


_windows_startup()

from sage.main import app  # noqa: E402 — must come after startup

if __name__ == "__main__":
    app()
