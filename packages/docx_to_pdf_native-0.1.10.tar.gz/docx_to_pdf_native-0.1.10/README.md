# docx_to_pdf_native (High-Fidelity Converter)

A powerful, zero-dependency Python package to convert `.docx` documents (invoices, reports, resumes) to high-quality `.pdf` files using **only the Python Standard Library**.

## Key Features
- **Zero Third-Party Dependencies**: No `pip install` requirements other than this package. Built using only built-in modules (`zipfile`, `xml`, `zlib`).
- **High-Fidelity Rendering**:
    - **Bold, Italic, and Highlights**: Preserves inline styling from Word documents.
    - **Precision Word Wrapping**: Intelligent layout engine using font metrics for accurate line breaks.
    - **Image Extraction**: Automatically embeds images (JPEG/PNG) from the DOCX at their original dimensions.
    - **Tables**: Renders borders and layouts structured data, ideal for invoices.
    - **Bullet Points**: Supports numbered and bulleted lists with proper indentation.
- **Advanced Engine**:
    - **Unicode Support**: Safely handles non-ASCII characters (like smart quotes, em-dashes, and currency symbols) via CP1252 encoding.
    - **Multi-Page Support**: Automatic pagination and page-break management.
    - **Native PDF Generation**: Independently constructs the binary PDF structure (Xref tables, font dictionaries, and trailers).

## Installation
Since this is a zero-dependency project, you can simply include the folder in your project or install it via pip:

```bash
pip install .
```

## Usage
### Command Line
```bash
docx2pdf-native path/to/input.docx output.pdf
```

### Python API
```python
from docx_to_pdf_native import DocxToPdfConverter

converter = DocxToPdfConverter("invoice.docx", "invoice.pdf")
converter.convert()
```

## Production Reliability
- **Isolated**: No risk of dependency conflicts in your server environment.
- **Fast**: Performs direct XML-to-binary conversion without spawning sub-processes or browser instances.
- **Stand-alone**: Perfect for Dockerized microservices or serverless functions (AWS Lambda, etc.).
