import zlib

class PDFWriter:
    """
    Experimental Manual PDF binary engine.
    Independently constructs PDF objects, content streams, Cross-Reference tables, 
    and trailers without external libraries.
    """
    def __init__(self):
        """Initializes the binary structure tracking."""
        self.objects = []
        self.offsets = []
        self.current_offset = 0
        # Standard PDF 1.4 header with binary indicator for safety
        self.header = b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"

    def _add_object(self, content):
        """
        Wraps binary content in a PDF object declaration and tracks its offset.
        :param content: binary payload of the object.
        :return: The object index (1-indexed).
        """
        obj_num = len(self.objects) + 1
        obj_header = f"{obj_num} 0 obj\n".encode('ascii')
        obj_footer = b"\nendobj\n"
        full_obj = obj_header + content + obj_footer
        
        self.offsets.append(self.current_offset)
        self.objects.append(full_obj)
        self.current_offset += len(full_obj)
        return obj_num

    def _create_stream(self, data, compress=True):
        """
        Creates a PDF stream object, optionally with zlib compression.
        :param data: Binary content of the stream.
        :param compress: Whether to apply FlateDecode.
        """
        if compress:
            compressed_data = zlib.compress(data)
            dict_str = f"<< /Length {len(compressed_data)} /Filter /FlateDecode >>\n"
            return dict_str.encode('ascii') + b"stream\n" + compressed_data + b"\nendstream"
        else:
            dict_str = f"<< /Length {len(data)} >>\n"
            return dict_str.encode('ascii') + b"stream\n" + data + b"\nendstream"

    def _get_image_info(self, data):
        """
        Parses JPEG or PNG headers to determine dimensions (width/height).
        Necessary for registering image XObjects in the PDF dictionary.
        """
        # Default fallback
        width, height = 500, 500
        img_filter = "/DCTDecode"
        
        if data.startswith(b"\x89PNG\r\n\x1a\n"):
            img_filter = "/FlateDecode"
            import struct
            try:
                width, height = struct.unpack(">II", data[16:24])
            except: pass
        elif data.startswith(b"\xff\xd8"):
            img_filter = "/DCTDecode"
            import struct
            i = 2
            while i < len(data):
                if data[i] == 0xff and data[i+1] in [0xc0, 0xc1, 0xc2]:
                    height, width = struct.unpack(">HH", data[i+5:i+9])
                    break
                i += 2 + struct.unpack(">H", data[i+2:i+4])[0]
        return width, height, img_filter

    def build_pdf(self, page_streams, images=None, page_size=None):
        """
        Assembles all objects into a final PDF binary stream.
        :param page_streams: List of bytes representing page contents.
        :param images: List of (rel_id, filename, binary_data).
        :param page_size: dict with 'width' and 'height'
        :return: Completed PDF bytes.
        """
        # 1. Font Objects (shared)
        f1_normal = self._add_object(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        f2_bold = self._add_object(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        f3_italic = self._add_object(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>")
        
        # 2. XObjects (Images) (shared)
        image_objs = {}
        if images:
            for r_id, name, data in images:
                img_name = f"I{r_id}"
                w, h, f = self._get_image_info(data)
                img_obj = self._add_object(
                    f"<< /Type /XObject /Subtype /Image /Width {w} /Height {h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter {f} /Length {len(data)} >>\n".encode('cp1252') +
                    b"stream\n" + data + b"\nendstream"
                )
                image_objs[img_name] = img_obj

        # 3. Resources (shared)
        res_dict = f"<< /Font << /F1 {f1_normal} 0 R /F2 {f2_bold} 0 R /F3 {f3_italic} 0 R >> "
        if image_objs:
            res_dict += "/XObject << "
            for name, idx in image_objs.items():
                res_dict += f"/{name} {idx} 0 R "
            res_dict += ">> "
        res_dict += ">>"
        res_obj = self._add_object(res_dict.encode('cp1252'))

        # 4. Content Streams and Page Objects
        page_indices = []
        parent_idx = len(self.objects) + len(page_streams) * 2 + 1
        
        ps = page_size or {'width': 595, 'height': 842}
        media_box = f"[0 0 {ps['width']} {ps['height']}]"

        for stream_data in page_streams:
            content_obj = self._add_object(self._create_stream(stream_data))
            page_obj = self._add_object(
                f"<< /Type /Page /Parent {parent_idx} 0 R /Resources {res_obj} 0 R /Contents {content_obj} 0 R /MediaBox {media_box} >>".encode('cp1252')
            )
            page_indices.append(page_obj)

        # 5. Pages Tree
        kids_str = " ".join([f"{idx} 0 R" for idx in page_indices])
        pages_obj = self._add_object(
            f"<< /Type /Pages /Kids [{kids_str}] /Count {len(page_indices)} >>".encode('cp1252')
        )
        
        # 6. Catalog
        catalog_obj = self._add_object(
            f"<< /Type /Catalog /Pages {pages_obj} 0 R >>".encode('cp1252')
        )
        
        # Build final bytes
        output = [self.header]
        current_pos = len(self.header)
        
        # Recalculate offsets relative to header
        final_offsets = []
        for obj in self.objects:
            final_offsets.append(current_pos)
            output.append(obj)
            current_pos += len(obj)
            
        xref_pos = current_pos
        output.append(b"xref\n")
        output.append(f"0 {len(self.objects) + 1}\n".encode('cp1252'))
        output.append(b"0000000000 65535 f \n")
        for offset in final_offsets:
            output.append(f"{offset:010} 00000 n \n".encode('cp1252'))
            
        output.append(b"trailer\n")
        output.append(f"<< /Size {len(self.objects) + 1} /Root {len(self.objects)} 0 R >>\n".encode('cp1252'))
        output.append(b"startxref\n")
        output.append(f"{xref_pos}\n".encode('cp1252'))
        output.append(b"%%EOF\n")
        
        return b"".join(output)
