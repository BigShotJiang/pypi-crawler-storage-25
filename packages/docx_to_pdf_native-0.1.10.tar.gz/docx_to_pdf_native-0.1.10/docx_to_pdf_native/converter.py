import sys
import argparse
import os
from .reader import DocxReader
from .writer import PDFWriter
from .layout_engine import LayoutEngine

class DocxToPdfConverter:
    """
    Main API for converting DOCX files to PDF using only the Python Standard Library.
    Supports text, tables, images, multiple pages, and basic styling (bold, italic, highlight).
    """
    def __init__(self, input_path, output_path):
        """
        Initialize the converter.
        :param input_path: Path to the source .docx file.
        :param output_path: Path where the resulting .pdf will be saved.
        """
        self.input_path = input_path
        self.output_path = output_path

    def convert(self):
        """
        Executes the conversion process:
        1. Reads and parses the DOCX XML structure.
        2. Lays out content (text runs, tables, images) into PDF pages.
        3. Generates the final PDF binary stream.
        """
        # 1. Read DOCX
        reader = DocxReader(self.input_path)
        data = reader.read()
        body = data['body']
        headers = data['headers']
        footers = data['footers']
        page_size = data['page_size']
        
        # 2. Layout
        layout = LayoutEngine(page_size, headers, footers)
        for item in body:
            if item['type'] == 'paragraph':
                # Handle styled text and images in flow
                layout.add_paragraph(
                    item['data']['elements'], 
                    is_bullet=item['data'].get('is_bullet', False),
                    spacing_after=item['data'].get('spacing_after')
                )
            elif item['type'] == 'table':
                # Handle structured table data
                layout.add_table(item['data'])
        
        # 3. Write PDF
        writer = PDFWriter()
        # Collect all extracted media for XObject registration
        image_list = []
        for r_id, img_info in reader.images.items():
            filename, data = img_info
            image_list.append((r_id, filename, data))
            
        pdf_bytes = writer.build_pdf(layout.get_pages(), images=image_list, page_size=page_size)
        
        with open(self.output_path, 'wb') as f:
            f.write(pdf_bytes)

def main():
    """CLI entry point for the docx2pdf-native tool."""
    parser = argparse.ArgumentParser(
        description="Convert DOCX to PDF without dependencies (High-Fidelity)."
    )
    parser.add_argument("input", help="Path to input .docx file")
    parser.add_argument("output", help="Path to output .pdf file")
    parser.add_argument("-v", "--version", action="version", version="docx_to_pdf_native 1.0.1")
    
    args = parser.parse_args()
    
    try:
        if not os.path.exists(args.input):
            raise FileNotFoundError(f"Input file not found: {args.input}")
            
        converter = DocxToPdfConverter(args.input, args.output)
        print(f"Converting '{args.input}'...")
        converter.convert()
        print(f"Successfully generated PDF: '{args.output}'")
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"Error during conversion: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
