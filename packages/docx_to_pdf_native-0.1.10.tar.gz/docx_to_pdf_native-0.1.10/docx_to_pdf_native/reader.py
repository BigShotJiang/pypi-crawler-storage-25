import zipfile
import xml.etree.ElementTree as ET
import os

class DocxReader:
    """
    Parses a .docx file to extract text runs, styles, images, and tables.
    Uses xml.etree.ElementTree and zipfile to navigate the OpenXML structure.
    """
    NAMESPACE = {
        'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
        'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
        'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
        'v': 'urn:schemas-microsoft-com:vml',
        'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'
    }

    def __init__(self, docx_path):
        """
        :param docx_path: Path to the .docx file to read.
        """
        self.docx_path = docx_path
        self.content = []
        self.images = {} # rel_id -> (filename, binary_data)
        self.rels = {}   # rel_id -> target path
        self.headers = [] # List of parsed paragraph data
        self.footers = []
        self.page_size = {'width': 595, 'height': 842, 'orient': 'portrait'}

    def read(self):
        """
        Reads the DOCX zip archive and parses internal XML components.
        :return: A list of content dictionaries representing paragraphs and tables.
        """
        with zipfile.ZipFile(self.docx_path, 'r') as z:
            self._load_rels(z)
            self._load_content(z)
        return {
            'body': self.content,
            'headers': self.headers,
            'footers': self.footers,
            'page_size': self.page_size
        }

    def _load_rels(self, z):
        """Extracts relationship mapping for images and other media from ALL .rels files."""
        for name in z.namelist():
            if name.endswith('.rels'):
                with z.open(name) as f:
                    try:
                        tree = ET.parse(f)
                        for rel in tree.getroot():
                            r_id = rel.get('Id')
                            target = rel.get('Target')
                            if not r_id or not target: continue
                            self.rels[r_id] = target
                            
                            if 'media/' in target:
                                # Resolve path relative to word/ directory
                                path_parts = target.split('media/')
                                full_path = 'word/media/' + path_parts[-1]
                                if full_path in z.namelist():
                                    self.images[r_id] = (os.path.basename(target), z.read(full_path))
                    except: continue

    def _load_content(self, z):
        """Parses word/document.xml for paragraphs and tables."""
        with z.open('word/document.xml') as f:
            tree = ET.parse(f)
            root = tree.getroot()
            body = root.find('w:body', self.NAMESPACE)
            
            for child in body:
                if child.tag.endswith('p'): # Paragraph
                    self.content.append({'type': 'paragraph', 'data': self._parse_paragraph(child)})
                elif child.tag.endswith('tbl'): # Table
                    self.content.append({'type': 'table', 'data': self._parse_table(child)})
                elif child.tag.endswith('sectPr'): # Section Properties
                    self._parse_sect_pr(child, z)

            # Some DOCX files have sectPr as child of the last paragraph's pPr
            if not self.headers and not self.footers:
                last_p = body.findall('w:p', self.NAMESPACE)
                if last_p:
                    pPr = last_p[-1].find('w:pPr', self.NAMESPACE)
                    if pPr is not None:
                        sectPr = pPr.find('w:sectPr', self.NAMESPACE)
                        if sectPr is not None:
                            self._parse_sect_pr(sectPr, z)

    def _parse_sect_pr(self, sect_pr, z):
        """Extracts page size and header/footer references from sectPr."""
        pg_sz = sect_pr.find('w:pgSz', self.NAMESPACE)
        if pg_sz is not None:
            # Twips to Points (1/1440 inch vs 1/72 inch) -> divide by 20
            w = int(pg_sz.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}w', 11906))
            h = int(pg_sz.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}h', 16838))
            orient = pg_sz.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}orient', 'portrait')
            self.page_size = {'width': w / 20, 'height': h / 20, 'orient': orient}

        # Process Headers
        for h_ref in sect_pr.findall('w:headerReference', self.NAMESPACE):
            r_id = h_ref.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
            if r_id in self.rels:
                self.headers.extend(self._parse_external_xml(z, f"word/{self.rels[r_id]}"))

        # Process Footers
        for f_ref in sect_pr.findall('w:footerReference', self.NAMESPACE):
            r_id = f_ref.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
            if r_id in self.rels:
                self.footers.extend(self._parse_external_xml(z, f"word/{self.rels[r_id]}"))

    def _parse_external_xml(self, z, path):
        """Parses external XML files like headers and footers."""
        content = []
        if path in z.namelist():
            with z.open(path) as f:
                tree = ET.parse(f)
                root = tree.getroot()
                for child in root:
                    if child.tag.endswith('p'):
                        content.append({'type': 'paragraph', 'data': self._parse_paragraph(child)})
                    elif child.tag.endswith('tbl'):
                        content.append({'type': 'table', 'data': self._parse_table(child)})
        return content

    def _parse_paragraph(self, p_node):
        """
        Extracts styled runs and images in sequential order.
        Supports w:drawing (modern) and w:pict (legacy/seals).
        """
        elements = []
        is_bullet = False
        pPr = p_node.find('w:pPr', self.NAMESPACE)
        if pPr is not None:
            numPr = pPr.find('w:numPr', self.NAMESPACE)
            if numPr is not None:
                is_bullet = True

        # Extract spacing
        spacing_after = 0
        if pPr is not None:
            spacing = pPr.find('w:spacing', self.NAMESPACE)
            if spacing is not None:
                after = spacing.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}after')
                if after:
                    spacing_after = int(after) / 20

        # Iterate through all children to maintain order (mainly w:r)
        for r in p_node.findall('w:r', self.NAMESPACE):
            # 1. Check for text
            text = ""
            for t in r.findall('w:t', self.NAMESPACE):
                if t.text: text += t.text
            
            if text:
                bold = False
                italic = False
                highlight = None
                rPr = r.find('w:rPr', self.NAMESPACE)
                if rPr is not None:
                    if rPr.find('w:b', self.NAMESPACE) is not None: bold = True
                    if rPr.find('w:i', self.NAMESPACE) is not None: italic = True
                    hi = rPr.find('w:highlight', self.NAMESPACE)
                    if hi is not None: 
                        highlight = hi.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                
                elements.append({
                    'type': 'text',
                    'text': text,
                    'bold': bold,
                    'italic': italic,
                    'highlight': highlight
                })

            # 2. Check for modern drawings (w:drawing)
            for drawing in r.findall('.//w:drawing', self.NAMESPACE):
                blip = drawing.find('.//a:blip', {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'})
                extent = drawing.find('.//wp:extent', self.NAMESPACE)
                if blip is not None and extent is not None:
                    r_id = blip.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
                    w = int(extent.get('cx', 0)) / 12700
                    h = int(extent.get('cy', 0)) / 12700
                    if r_id in self.images:
                        filename, data = self.images[r_id]
                        elements.append({
                            'type': 'image',
                            'rel_id': r_id,
                            'width': w,
                            'height': h,
                            'filename': filename
                        })

            # 3. Check for legacy pictures/seals (w:pict)
            for pict in r.findall('.//w:pict', self.NAMESPACE):
                v_shape = pict.find('.//v:shape', self.NAMESPACE)
                imagedata = pict.find('.//v:imagedata', self.NAMESPACE)
                if imagedata is not None:
                    r_id = imagedata.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
                    w, h = 100, 100 # Fallback
                    if v_shape is not None:
                        style = v_shape.get('style', '')
                        for part in style.split(';'):
                            if ':' in part:
                                k, val = part.split(':', 1)
                                if k.strip() == 'width':
                                    try: w = float(val.replace('pt','').replace('in','').strip()) * (72 if 'in' in val else 1)
                                    except: pass
                                elif k.strip() == 'height':
                                    try: h = float(val.replace('pt','').replace('in','').strip()) * (72 if 'in' in val else 1)
                                    except: pass

                    if r_id in self.images:
                        filename, data = self.images[r_id]
                        elements.append({
                            'type': 'image',
                            'rel_id': r_id,
                            'width': w,
                            'height': h,
                            'filename': filename
                        })

        return {
            'elements': elements,
            'is_bullet': is_bullet,
            'spacing_after': spacing_after
        }

    def _parse_table(self, tbl_node):
        """
        Parses a table structure including column widths (grid).
        """
        grid = []
        tblGrid = tbl_node.find('w:tblGrid', self.NAMESPACE)
        if tblGrid is not None:
            for col in tblGrid.findall('w:gridCol', self.NAMESPACE):
                w = col.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}w')
                if w: grid.append(int(w) / 20) # Twips to pts

        rows = []
        for tr in tbl_node.findall('w:tr', self.NAMESPACE):
            row = []
            for tc in tr.findall('w:tc', self.NAMESPACE):
                cell_paragraphs = []
                for p in tc.findall('w:p', self.NAMESPACE):
                    cell_paragraphs.append(self._parse_paragraph(p))
                row.append(cell_paragraphs)
            rows.append(row)
        return {'rows': rows, 'grid': grid}
