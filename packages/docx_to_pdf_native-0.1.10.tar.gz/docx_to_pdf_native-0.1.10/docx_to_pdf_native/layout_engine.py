class LayoutEngine:
    """
    Core layout engine that manages page coordinates and content flow.
    Features a custom Word-Wrapping algorithm based on Helvetica font metrics.
    """
    # Standard Helvetica character widths (1000 units = 1 em)
    # These metrics are used to calculate accurate line breaks.
    WIDTHS = {
        ' ': 278, '!': 278, '"': 355, '#': 556, '$': 556, '%': 889, '&': 667, "'": 191,
        '(': 333, ')': 333, '*': 389, '+': 584, ',': 278, '-': 333, '.': 278, '/': 278,
        '0': 556, '1': 556, '2': 556, '3': 556, '4': 556, '5': 556, '6': 556, '7': 556,
        '8': 556, '9': 556, ':': 278, ';': 278, '<': 584, '=': 584, '>': 584, '?': 556,
        'A': 667, 'B': 667, 'C': 722, 'D': 722, 'E': 667, 'F': 611, 'G': 778, 'H': 722,
        'I': 278, 'J': 500, 'K': 667, 'L': 556, 'M': 833, 'N': 722, 'O': 778, 'P': 667,
        'Q': 778, 'R': 722, 'S': 667, 'T': 611, 'U': 722, 'V': 667, 'W': 944, 'X': 667,
        'Y': 667, 'Z': 611, 'a': 556, 'b': 556, 'c': 500, 'd': 556, 'e': 556, 'f': 278,
        'g': 556, 'h': 556, 'i': 222, 'j': 222, 'k': 500, 'l': 222, 'm': 833, 'n': 556,
        'o': 556, 'p': 556, 'q': 556, 'r': 333, 's': 500, 't': 278, 'u': 556, 'v': 500,
        'w': 722, 'x': 500, 'y': 500, 'z': 500
    }

    def __init__(self, page_size=None, headers=None, footers=None):
        """
        Initializes the layout engine with dynamic dimensions and fixed elements.
        :param page_size: dict with 'width', 'height', 'orient'
        :param headers: list of header paragraphs/tables
        :param footers: list of footer paragraphs/tables
        """
        ps = page_size or {'width': 595, 'height': 842, 'orient': 'portrait'}
        self.page_width = ps['width']
        self.page_height = ps['height']
        self.margin = 50
        self.indent = 20
        self.header_content = headers or []
        self.footer_content = footers or []
        
        # Reserve extra space for headers and footers (approx 40 points each)
        self.header_reserve = 60 if self.header_content else 20
        self.footer_reserve = 60 if self.footer_content else 40
        
        self.cursor_y = self.page_height - self.header_reserve
        self.pages = []
        self.current_page_stream = []
        self.line_height = 16 # Increased from 14 to provide better vertical breathing room
        self.font_size = 11
        self.paragraph_spacing_default = 6
        self.table_spacing_after = 12
        self.in_fixed_section = False

    def _new_page(self):
        """Flushes current page, resets cursor, and renders headers for the new page."""
        if self.current_page_stream:
            # Render footer before closing the page
            self._render_fixed_section(self.footer_content, self.footer_reserve, is_footer=True)
            self.pages.append(b"\n".join(self.current_page_stream))
        
        self.current_page_stream = []
        self.cursor_y = self.page_height - self.header_reserve
        
        # Render header for the new page
        self._render_fixed_section(self.header_content, self.margin)

    def _render_fixed_section(self, content, start_y, is_footer=False):
        """Helper to render headers/footers at fixed positions."""
        self.in_fixed_section = True
        old_cursor = self.cursor_y
        # Fixed elements use a separate coordinate space
        # For footers, start_y might be 40
        self.cursor_y = start_y if is_footer else self.page_height - 30
        
        # Save current page width/margin to restore later if needed
        for item in content:
            if item['type'] == 'paragraph':
                self.add_paragraph(item['data']['elements'], is_bullet=item['data'].get('is_bullet', False))
            elif item['type'] == 'table':
                self.add_table(item['data'])
        
        if not is_footer:
            # Reset cursor for body content
            self.cursor_y = self.page_height - self.header_reserve
        else:
            self.cursor_y = old_cursor
        self.in_fixed_section = False

    def _get_string_width(self, text, size):
        """Calculates the width of a string in points using the font metrics table."""
        w = 0
        for char in text:
            char_w = self.WIDTHS.get(char, 500)
            w += (char_w * size) / 1000
        return w

    def _sanitize_text(self, text):
        """Replaces common non-WinAnsi Unicode with safe equivalents and escapes PDF control chars."""
        repls = {'\u2019': "'", '\u2018': "'", '\u201c': '"', '\u201d': '"',
                 '\u2013': '-', '\u2014': '-', '\u2026': '...'}
        for u, r in repls.items():
            text = text.replace(u, r)
        return text.encode('cp1252', errors='replace').decode('cp1252').replace('(', '\\(').replace(')', '\\)')

    def _wrap_text(self, text, max_width, size):
        # ... logic unchanged ...
        """
        Wraps text into multiple lines based on a maximum width.
        Includes hard-wrapping for long unbreakable words.
        :return: List of strings (lines).
        """
        text = self._sanitize_text(text)
        words = text.split(' ')
        lines = []
        current_line = []
        current_w = 0

        for word in words:
            word_to_add = word + " "
            word_w = self._get_string_width(word_to_add, size)

            # Case 1: The whole word (plus space) fits
            if current_w + word_w <= max_width:
                current_line.append(word)
                current_w += word_w
            else:
                # Case 2: The current line is not empty, flush it and try the word on a new line
                if current_line:
                    lines.append(" ".join(current_line))
                    current_line = []
                    current_w = 0

                # Case 3: Re-check the word on a fresh line
                word_w = self._get_string_width(word, size)
                if word_w <= max_width:
                    current_line.append(word)
                    current_w = self._get_string_width(word + " ", size)
                else:
                    # Case 4: The word ALONE is wider than max_width. Hard-wrap it!
                    chunk = ""
                    for char in word:
                        char_w = self._get_string_width(char, size)
                        if self._get_string_width(chunk + char, size) > max_width:
                            lines.append(chunk)
                            chunk = char
                        else:
                            chunk += char
                    if chunk:
                        current_line = [chunk]
                        current_w = self._get_string_width(chunk + " ", size)
        
        if current_line:
            lines.append(" ".join(current_line))
        return lines

    def add_paragraph(self, elements, is_bullet=False, spacing_after=None):
        """
        Processes a sequence of text and images, handles wrapping, 
        and updates the global page stream.
        """
        s_after = spacing_after if spacing_after is not None else self.paragraph_spacing_default
        if not self.in_fixed_section and self.cursor_y < self.margin + self.line_height:
            self._new_page()

        x_start = self.margin + (self.indent if is_bullet else 0)
        if is_bullet:
            self._draw_run("• ", x_start - 10, self.cursor_y, font="F1")

        current_x = x_start
        max_x = self.page_width - self.margin

        for el in elements:
            if el['type'] == 'text':
                text = self._sanitize_text(el['text'])
                font = "F2" if el['bold'] else ("F3" if el.get('italic') else "F1")
                highlight = el.get('highlight')
                
                words = text.split(' ')
                for i, word in enumerate(words):
                    word_to_draw = word + (" " if i < len(words) - 1 else "")
                    word_w = self._get_string_width(word_to_draw, self.font_size)

                    if current_x + word_w > max_x:
                        if current_x > x_start:
                            self.cursor_y -= self.line_height
                            if not self.in_fixed_section and self.cursor_y < self.margin: self._new_page()
                            current_x = x_start
                            word_w = self._get_string_width(word_to_draw, self.font_size)

                        if current_x + word_w > max_x:
                            chunk = ""
                            for char in word_to_draw:
                                char_w = self._get_string_width(char, self.font_size)
                                if current_x + self._get_string_width(chunk + char, self.font_size) > max_x:
                                    if highlight: self._draw_highlight(current_x, self.cursor_y, self._get_string_width(chunk, self.font_size), highlight)
                                    self._draw_run(chunk, current_x, self.cursor_y, font)
                                    self.cursor_y -= self.line_height
                                    if not self.in_fixed_section and self.cursor_y < self.margin: self._new_page()
                                    current_x = x_start
                                    chunk = char
                                else:
                                    chunk += char
                            word_to_draw = chunk
                            word_w = self._get_string_width(word_to_draw, self.font_size)

                    if highlight:
                        self._draw_highlight(current_x, self.cursor_y, word_w, highlight)
                    
                    self._draw_run(word_to_draw, current_x, self.cursor_y, font)
                    current_x += word_w
            
            elif el['type'] == 'image':
                # If we have text on current line, move image to next line for simplicity
                if current_x > x_start:
                    self.cursor_y -= self.line_height
                    current_x = x_start
                
                # Image might be small (signature) or large.
                # If it fits on the current page, render it.
                self.add_image(el['rel_id'], el['width'], el['height'])
                # add_image updates cursor_y. We need to reset current_x.
                current_x = x_start
        
        self.cursor_y -= (self.line_height + s_after)

    def _draw_run(self, text, x, y, font="F1"):
        """Directly appends PDF Text operators (BT/Td/Tj/ET) to the stream."""
        self.current_page_stream.append(b"BT")
        self.current_page_stream.append(f"/{font} {self.font_size} Tf".encode('cp1252'))
        self.current_page_stream.append(f"{x} {y} Td".encode('cp1252'))
        self.current_page_stream.append(f"({text}) Tj".encode('cp1252'))
        self.current_page_stream.append(b"ET")

    def _draw_highlight(self, x, y, width, color_val):
        """Draws a colored rectangle background behind a text run."""
        self.current_page_stream.append(b"q 1 1 0 rg") # Yellow RGB
        self.current_page_stream.append(f"{x} {y-2} {width} {self.line_height} re f Q".encode('cp1252'))

    def add_image(self, rel_id, width, height, x=None, container_width=None):
        """Registers and draws an image XObject. Scales to fit container while keeping aspect ratio."""
        max_w = container_width if container_width is not None else (self.page_width - 2 * self.margin)
        
        if width > max_w:
            scale = max_w / width
            width = max_w
            height = height * scale

        if not self.in_fixed_section and self.cursor_y < self.margin + height:
            self._new_page()

        img_x = x if x is not None else self.margin
        img_y = self.cursor_y - height
        img_name = f"I{rel_id}"
        
        self.current_page_stream.append(b"q")
        self.current_page_stream.append(f"{width} 0 0 {height} {img_x} {img_y} cm".encode('cp1252'))
        self.current_page_stream.append(f"/{img_name} Do".encode('cp1252'))
        self.current_page_stream.append(b"Q")
        self.cursor_y = img_y - 10

    def _get_cell_lines(self, cell_paragraphs, max_width):
        """Flattens cell paragraphs into a list of text lines and image objects."""
        lines = []
        for p in cell_paragraphs:
            for el in p['elements']:
                if el['type'] == 'text':
                    lines.extend(self._wrap_text(el['text'], max_width, self.font_size))
                elif el['type'] == 'image':
                    lines.append(el)
        return lines

    def add_table(self, table_data):
        """
        Renders table with variable column widths.
        """
        rows = table_data['rows'] if isinstance(table_data, dict) else table_data
        grid = table_data.get('grid', []) if isinstance(table_data, dict) else []
        if not rows: return
        col_count = len(rows[0])
        avail_w = self.page_width - 2 * self.margin
        
        if grid and len(grid) >= col_count:
            col_widths = grid[:col_count]
            if sum(col_widths) > avail_w:
                scale = avail_w / sum(col_widths)
                col_widths = [w * scale for w in col_widths]
        else:
            col_widths = [avail_w / col_count] * col_count
        padding = 10
        
        for row in rows:
            wrapped_row = [self._get_cell_lines(cell, col_widths[i] - padding) for i, cell in enumerate(row)]
            max_elements = max(len(elements) for elements in wrapped_row)
            
            for i in range(col_count):
                lx = self.margin + sum(col_widths[:i])
                self.current_page_stream.append(f"{lx} {self.cursor_y} {col_widths[i]} 0 re S".encode('cp1252'))

            for idx in range(max_elements):
                slot_height = self.line_height
                for i, elements in enumerate(wrapped_row):
                    if idx < len(elements) and isinstance(elements[idx], dict):
                        img_w = elements[idx]['width']
                        img_h = elements[idx]['height']
                        max_w = col_widths[i] - padding
                        if img_w > max_w:
                            img_h = img_h * (max_w / img_w)
                        slot_height = max(slot_height, img_h + 5)

                if not self.in_fixed_section and self.cursor_y < self.margin + slot_height:
                    for i in range(col_count):
                        lx = self.margin + sum(col_widths[:i])
                        self.current_page_stream.append(f"{lx} {self.cursor_y} {col_widths[i]} 0 re S".encode('cp1252'))
                    self._new_page()
                    for i in range(col_count):
                        lx = self.margin + sum(col_widths[:i])
                        self.current_page_stream.append(f"{lx} {self.cursor_y} {col_widths[i]} 0 re S".encode('cp1252'))

                for i, elements in enumerate(wrapped_row):
                    lx = self.margin + sum(col_widths[:i])
                    self.current_page_stream.append(f"{lx} {self.cursor_y} 0 {-slot_height} re S".encode('cp1252'))
                    if i == col_count - 1:
                        self.current_page_stream.append(f"{lx + col_widths[i]} {self.cursor_y} 0 {-slot_height} re S".encode('cp1252'))

                    if idx < len(elements):
                        item = elements[idx]
                        if isinstance(item, str):
                            text_x = lx + 5
                            text_y = self.cursor_y - 13
                            self._draw_run(item, text_x, text_y)
                        elif isinstance(item, dict):
                            img_x = lx + 5
                            old_y = self.cursor_y
                            self.add_image(item['rel_id'], item['width'], item['height'], x=img_x, container_width=col_widths[i]-padding)
                            self.cursor_y = old_y
                
                self.cursor_y -= slot_height

            for i in range(col_count):
                lx = self.margin + sum(col_widths[:i])
                self.current_page_stream.append(f"{lx} {self.cursor_y} {col_widths[i]} 0 re S".encode('cp1252'))
        
        self.cursor_y -= self.table_spacing_after

    def get_pages(self):
        """Finalizes and returns the list of all constructed page streams."""
        if self.current_page_stream or not self.pages:
            self._new_page()
        return self.pages
