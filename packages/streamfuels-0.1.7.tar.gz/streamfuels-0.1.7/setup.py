from setuptools import setup, find_packages

setup(
    name="streamfuels",
    version="0.1.7",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.2.0",
        "requests>=2.25.0",
        "beautifulsoup4>=4.9.0",
        "unidecode>=1.1.1",
        "numpy>=1.19.0",
        "editdistance>=0.5.3",
        "tqdm==4.65.0",
    ],
    extras_require={
        "viz": [
            "matplotlib>=3.0",
            "seaborn>=0.11",
        ],
        "ml": [
            "scikit-learn>=1.0",
            "statsmodels",
        ],
        "all": [
            "matplotlib>=3.0",
            "seaborn>=0.11",
            "scikit-learn>=1.0",
            "statsmodels",
        ],
    },
    author="StreamFuels",
    author_email="lucascstxv@gmail.com",
    description="Data processing and analysis tools for fuel market research",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/lucas-castrow/StreamFuels",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
    license="MIT",
    license_files=("LICENSE",),
)
