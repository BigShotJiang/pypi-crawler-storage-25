"""Tests for the evidence-pack reader and summaries."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import pytest

from ml4t.agent.schemas import EvidencePack
from ml4t.agent.tools.evidence import (
    list_open_questions,
    read_case_study_evidence,
    summarize_run,
)


def test_read_roundtrips_through_asdict(run_dir: Path, sample_pack: EvidencePack):
    loaded = read_case_study_evidence(run_dir)
    # MappingProxyType vs dict differ in identity but compare equal as mappings;
    # asdict round-trip is the contract this loader claims.
    assert asdict(loaded) == asdict(sample_pack)


def test_read_missing_file_raises(tmp_path: Path):
    with pytest.raises(FileNotFoundError, match="evidence_pack"):
        read_case_study_evidence(tmp_path)


def test_read_rejects_non_object(tmp_path: Path):
    (tmp_path / "evidence_pack.json").write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError, match="expected JSON object"):
        read_case_study_evidence(tmp_path)


def test_read_rejects_malformed_pack(tmp_path: Path):
    (tmp_path / "evidence_pack.json").write_text(
        json.dumps({"case_study": "etfs"}), encoding="utf-8"
    )
    with pytest.raises(ValueError, match="malformed EvidencePack"):
        read_case_study_evidence(tmp_path)


def test_summarize_includes_key_facts(sample_pack: EvidencePack):
    text = summarize_run(sample_pack)
    assert "case_study=etfs" in text
    assert "line_id=L-1" in text
    assert "holdout: sealed" in text
    assert "best=gbm" in text
    assert "warnings (blocking|material): 1" in text


def test_summarize_flags_open_holdout(sample_pack: EvidencePack):
    from dataclasses import replace

    from ml4t.agent.schemas import HoldoutMetrics

    open_pack = replace(
        sample_pack,
        holdout=HoldoutMetrics(
            model_runs=(),
            signal=sample_pack.validation.signal,
            backtests=(),
        ),
    )
    text = summarize_run(open_pack)
    assert "holdout: OPEN" in text


def test_open_questions_for_sample_pack(sample_pack: EvidencePack):
    questions = list_open_questions(sample_pack)
    # warning resolution + signal-strength question should be absent (t_stat>=2)
    assert any("LEAK_RISK" in q for q in questions)
    assert all("Bonferroni at k>1" not in q for q in questions)


def test_open_questions_when_no_baselines():
    """Sparse pack: no baselines, no regime breakdown, weak signal."""
    from ml4t.agent.schemas import (
        CostSummary,
        EvidencePack,
        LineageSummary,
        RobustnessSummary,
        SignalSummary,
        ValidationDesign,
        ValidationMetrics,
    )

    pack = EvidencePack(
        case_study="x",
        objective="y",
        primary_label="z",
        horizon="1d",
        cadence="daily",
        parent_run_id="P",
        line_id="L",
        validation_design=ValidationDesign(
            n_splits=1,
            train_size="1y",
            val_size="1m",
            holdout_start="x",
            holdout_end="y",
            embargo_days=None,
            purge_days=None,
            fold_calendar_id="c",
        ),
        validation=ValidationMetrics(
            model_runs=(),
            signal=SignalSummary(
                best_family="none",
                best_config="none",
                best_mean_ic=0.0,
                ic_t_stat=1.2,
                horizons_tested=(),
            ),
            backtests=(),
            robustness=RobustnessSummary(
                fold_sharpe_dispersion=0.0,
                regime_breakdown_available=False,
                seed_variance_estimate=None,
            ),
        ),
        holdout=None,
        costs=CostSummary(
            per_leg_bps_low=0.0,
            per_leg_bps_high=0.0,
            cost_class="none",
            components=(),
        ),
        lineage=LineageSummary(
            git_sha="0",
            data_snapshot_id="0",
            config_hash="0",
            package_versions={},
        ),
        warnings=(),
    )
    questions = list_open_questions(pack)
    assert any("linear baseline" in q for q in questions)
    assert any("gbm" in q for q in questions)
    assert any("regime" in q for q in questions)
    assert any("Bonferroni" in q for q in questions)
