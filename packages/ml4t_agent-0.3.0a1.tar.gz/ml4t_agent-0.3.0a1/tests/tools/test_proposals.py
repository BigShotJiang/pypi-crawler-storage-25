"""Smoke tests for the LLM-bounded experiment proposer."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import replace
from typing import Any

import pytest

from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    Determinism,
    EvidencePack,
    ExperimentPlan,
    LineState,
    MethodologyWarning,
    PlanValidationError,
    Severity,
    validate_plan,
)
from ml4t.agent.tools.proposals import (
    build_tc1_template,
    default_templates,
    propose_experiments,
)


@pytest.fixture
def clean_pack(sample_pack: EvidencePack) -> EvidencePack:
    """sample_pack with the MATERIAL warning stripped so T-C1 is eligible."""
    return replace(sample_pack, warnings=())


@pytest.fixture
def line_state() -> LineState:
    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


def _tc1_proposal(experiment_id: str = "E-tc1-1") -> dict[str, Any]:
    return {
        "experiment_id": experiment_id,
        "template_id": "T-C1",
        "comparison_target_id": "strat-gbm",
        "hypothesis": "net edge >= 1.0x at 25 bps upper bound",
        "rationale": (
            "validation.backtests[strat-gbm].edge_to_cost_ratio=1.6; "
            "stricter cost bound tests survival floor"
        ),
        "config_patches": [
            {
                "path_template": "config/setup.yaml",
                "path_variables": {},
                "yaml_path": ["costs", "per_leg_cost_bps_range"],
                "new_value": [15.0, 25.0],
            }
        ],
    }


def _make_responder(proposals: list[dict[str, Any]]):
    def responder(_messages: Sequence[Message], _schema: Mapping[str, Any]) -> LLMResponse:
        payload = {"proposals": proposals}
        return LLMResponse(data=payload, raw=str(payload))

    return responder


def test_default_catalogue_v02_three_templates():
    cat = default_templates()
    assert tuple(t.template_id for t in cat) == ("T-C1", "T-A2", "T-M1")


def test_proposes_valid_tc1_plan(clean_pack: EvidencePack, line_state: LineState):
    llm = MockLLMClient(responder=_make_responder([_tc1_proposal()]))
    plans = propose_experiments(clean_pack, llm=llm, line_state=line_state)
    assert len(plans) == 1
    plan = plans[0]
    assert isinstance(plan, ExperimentPlan)
    assert plan.template_id == "T-C1"
    assert plan.parent_run_id == clean_pack.parent_run_id
    assert plan.delta_criterion.bonferroni_k == 1
    # Plan validates against its template — the contract the planner promises.
    validate_plan(plan, build_tc1_template(), clean_pack, line_state)


def test_bonferroni_k_tracks_iteration_index(clean_pack: EvidencePack):
    line = LineState(line_id="L-1", iteration_index=3, base_alpha=0.05)
    llm = MockLLMClient(responder=_make_responder([_tc1_proposal()]))
    plans = propose_experiments(clean_pack, llm=llm, line_state=line)
    assert plans[0].delta_criterion.bonferroni_k == 3


def test_returns_empty_when_no_template_eligible(sample_pack: EvidencePack, line_state: LineState):
    # sample_pack carries a MATERIAL warning -> has_clean_validity=False -> T-C1 ineligible.
    llm = MockLLMClient(responder=_make_responder([_tc1_proposal()]))
    plans = propose_experiments(sample_pack, llm=llm, line_state=line_state)
    assert plans == []
    # LLM is never called when the eligible set is empty.
    assert llm.calls == []


def test_invalid_value_raises_plan_validation_error(
    clean_pack: EvidencePack, line_state: LineState
):
    bad = _tc1_proposal()
    bad["config_patches"][0]["new_value"] = [25.0, 15.0]  # inverted bounds
    llm = MockLLMClient(responder=_make_responder([bad]))
    with pytest.raises(PlanValidationError, match="inverted"):
        propose_experiments(clean_pack, llm=llm, line_state=line_state)


def test_unknown_template_id_raises(clean_pack: EvidencePack, line_state: LineState):
    bad = _tc1_proposal()
    bad["template_id"] = "T-DOES-NOT-EXIST"
    llm = MockLLMClient(responder=_make_responder([bad]))
    with pytest.raises(PlanValidationError, match="unknown template_id"):
        propose_experiments(clean_pack, llm=llm, line_state=line_state)


def test_missing_required_field_raises(clean_pack: EvidencePack, line_state: LineState):
    bad = _tc1_proposal()
    del bad["rationale"]
    llm = MockLLMClient(responder=_make_responder([bad]))
    with pytest.raises(PlanValidationError, match="missing field"):
        propose_experiments(clean_pack, llm=llm, line_state=line_state)


def test_multiple_proposals_each_validate(clean_pack: EvidencePack, line_state: LineState):
    a = _tc1_proposal("E-tc1-a")
    b = _tc1_proposal("E-tc1-b")
    b["config_patches"][0]["new_value"] = [20.0, 30.0]
    llm = MockLLMClient(responder=_make_responder([a, b]))
    plans = propose_experiments(clean_pack, llm=llm, line_state=line_state)
    assert [p.experiment_id for p in plans] == ["E-tc1-a", "E-tc1-b"]


def test_blocking_warning_filters_template(clean_pack: EvidencePack, line_state: LineState):
    blocked = replace(
        clean_pack,
        warnings=(
            MethodologyWarning(
                code="LEAKAGE",
                message="future timestamp on label",
                severity=Severity.BLOCKING,
                determinism=Determinism.ARITHMETIC,
                triggering_artifact="x.parquet",
            ),
        ),
    )
    llm = MockLLMClient(responder=_make_responder([_tc1_proposal()]))
    plans = propose_experiments(blocked, llm=llm, line_state=line_state)
    assert plans == []


def test_response_missing_proposals_raises(clean_pack: EvidencePack, line_state: LineState):
    def responder(_m: Sequence[Message], _s: Mapping[str, Any]) -> LLMResponse:
        return LLMResponse(data={"wrong_key": []}, raw="{}")

    llm = MockLLMClient(responder=responder)
    with pytest.raises(PlanValidationError, match="missing required 'proposals'"):
        propose_experiments(clean_pack, llm=llm, line_state=line_state)


def test_explicit_parent_run_id_overrides_evidence(clean_pack: EvidencePack, line_state: LineState):
    llm = MockLLMClient(responder=_make_responder([_tc1_proposal()]))
    plans = propose_experiments(
        clean_pack, llm=llm, line_state=line_state, parent_run_id="P-OVERRIDE"
    )
    assert plans[0].parent_run_id == "P-OVERRIDE"
