"""OpenAI concrete impl tests.

Wiring is exercised against a fake SDK to verify response_format
construction, JSON parsing, and usage extraction without needing an
API key. The live test is gated on ``OPENAI_API_KEY`` and the ``live``
marker.
"""

from __future__ import annotations

import json
import os
import sys
from types import ModuleType, SimpleNamespace
from typing import Any

import pytest


@pytest.fixture
def fake_openai(monkeypatch):
    """Replace the ``openai`` SDK with a configurable fake."""
    captured: dict[str, Any] = {}

    def fake_create(**kwargs):
        captured["kwargs"] = kwargs
        message = SimpleNamespace(content=json.dumps({"answer": "fake"}))
        choice = SimpleNamespace(message=message)
        usage = SimpleNamespace(
            prompt_tokens=11,
            completion_tokens=5,
            total_tokens=16,
            prompt_tokens_details=SimpleNamespace(cached_tokens=4),
        )
        return SimpleNamespace(choices=[choice], usage=usage)

    class FakeOpenAI:
        def __init__(self, api_key: str) -> None:
            captured["api_key"] = api_key
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(create=fake_create),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010

    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)
    return captured


def test_openai_client_sends_response_format_and_messages(fake_openai):
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    schema = {
        "type": "object",
        "properties": {"answer": {"type": "string"}},
        "required": ["answer"],
    }
    response = client.complete_with_schema(
        [
            Message(role="system", content="rules"),
            Message(role="user", content="hello"),
        ],
        schema,
    )

    kwargs = fake_openai["kwargs"]
    assert fake_openai["api_key"] == "fake-key"
    assert kwargs["model"] == "gpt-5-mini"
    assert kwargs["messages"] == [
        {"role": "system", "content": "rules"},
        {"role": "user", "content": "hello"},
    ]
    assert kwargs["max_completion_tokens"] == 1024
    assert kwargs["response_format"] == {
        "type": "json_schema",
        "json_schema": {
            "name": "structured_response",
            "schema": schema,
            "strict": True,
        },
    }
    assert kwargs["temperature"] == 0.0
    assert response.data == {"answer": "fake"}
    assert response.usage == {
        "prompt_tokens": 11,
        "completion_tokens": 5,
        "total_tokens": 16,
        "cached_tokens": 4,
    }


def test_openai_client_omits_temperature_when_none(fake_openai):
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
        temperature=None,
    )
    assert "temperature" not in fake_openai["kwargs"]


def test_openai_client_respects_custom_model(fake_openai):
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key", model="gpt-5")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
    )
    assert fake_openai["kwargs"]["model"] == "gpt-5"


def test_openai_client_raises_without_key(fake_openai, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    from ml4t.agent.llm import OpenAIClient

    with pytest.raises(RuntimeError, match="OPENAI_API_KEY"):
        OpenAIClient()


def test_openai_client_rejects_non_object_payload(monkeypatch):
    """If the assistant returns a JSON value that isn't an object, raise."""
    from types import ModuleType, SimpleNamespace

    class FakeOpenAI:
        def __init__(self, api_key: str):
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(
                    create=lambda **kwargs: SimpleNamespace(
                        choices=[SimpleNamespace(message=SimpleNamespace(content="[1, 2]"))],
                        usage=None,
                    ),
                ),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)

    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    with pytest.raises(ValueError, match="not a JSON object"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


def test_openai_client_rejects_invalid_json(monkeypatch):
    from types import ModuleType, SimpleNamespace

    class FakeOpenAI:
        def __init__(self, api_key: str):
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(
                    create=lambda **kwargs: SimpleNamespace(
                        choices=[SimpleNamespace(message=SimpleNamespace(content="not-json{"))],
                        usage=None,
                    ),
                ),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)

    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    with pytest.raises(ValueError, match="not valid JSON"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


def test_openai_client_rejects_empty_choices(monkeypatch):
    from types import ModuleType, SimpleNamespace

    class FakeOpenAI:
        def __init__(self, api_key: str):
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(
                    create=lambda **kwargs: SimpleNamespace(choices=[], usage=None),
                ),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)

    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    with pytest.raises(ValueError, match="no choices"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


def test_openai_client_satisfies_protocol(fake_openai):
    from ml4t.agent.llm import LLMClient, OpenAIClient

    client = OpenAIClient(api_key="fake-key")
    assert isinstance(client, LLMClient)


# --- Live test (skipped without API key) -------------------------------------


@pytest.mark.live
@pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set; skipping live OpenAI test",
)
def test_openai_client_live_smoke(cost_logger):  # pragma: no cover - network
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient()
    response = client.complete_with_schema(
        [Message(role="user", content="Reply with answer='hello'.")],
        {
            "type": "object",
            "properties": {"answer": {"type": "string"}},
            "required": ["answer"],
            "additionalProperties": False,
        },
        max_tokens=64,
    )
    assert "answer" in response.data
    cost_logger("openai", "gpt-5-mini", response.usage)
