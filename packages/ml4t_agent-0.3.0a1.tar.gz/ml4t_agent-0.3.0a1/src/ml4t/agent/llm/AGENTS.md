# llm/ — Provider-agnostic LLM adapter

Provider-neutral Protocol with a deterministic mock client for CI and
three opt-in vendor implementations behind separate extras
(`[llm-anthropic]`, `[llm-openai]`, `[llm-google]`, or umbrella
`[llm]`). The Protocol is the stable contract.

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `base.py` | 67 | `LLMClient` Protocol, `Message`, `LLMResponse` — the surface every provider implements |
| `mock.py` | 136 | `MockLLMClient` (record/replay), `compute_cache_key`, `save_recording`, `load_recording` |
| `anthropic.py` | 148 | `AnthropicClient` — lazy import (raises a clear error if extra missing); prompt-caching enabled |
| `openai_client.py` | 137 | `OpenAIClient` — Structured Outputs via `response_format={"type": "json_schema", ...}`; automatic prompt caching |
| `google_client.py` | 145 | `GoogleClient` — `google-genai` SDK; `response_schema` enforcement; implicit caching above threshold |

## Protocol

Every client has one method: `complete_with_schema(messages, json_schema,
*, max_tokens, temperature) -> LLMResponse`. `temperature` is `float | None`;
`None` maps to the provider's "not given" sentinel. Extended-thinking
models (Opus 4.7) reject `temperature`; pass `None` for those.

## Mock client

`MockLLMClient` is deterministic by hash of input. Recordings serialise
to JSON via `save_recording` / `load_recording` and are how the chapter
notebook stays reproducible in CI without an API key.

## Vendor clients (defaults / flagships)

| Provider | Default | Flagship | Caching |
|----------|---------|----------|---------|
| Anthropic | `claude-sonnet-4-6` | `claude-opus-4-7` | per-call ephemeral |
| OpenAI | `gpt-5-mini` | `gpt-5` | automatic |
| Google | `gemini-2.5-flash` | `gemini-2.5-pro` | implicit ≥1024 tokens |

Approximate per-iteration cost with a warm cache: Anthropic Sonnet 4.6
~$0.008, Opus 4.7 ~$0.04, OpenAI gpt-5-mini ~$0.003, Google
gemini-2.5-flash ~$0.001.

## Live-cost guardrail

`tests/llm/conftest.py` defines a `cost_logger` fixture that estimates
USD per call from a manually-maintained rate table and asserts a
$0.05/run ceiling. Live tests gate on the relevant API-key env var and
the `live` pytest marker so CI never touches them. Refresh
`RATES_PER_MTOK` quarterly.
