"""Provider-agnostic LLM adapter.

The :class:`LLMClient` Protocol is the contract surface; the rest of the
agent code depends only on it. :class:`MockLLMClient` is a deterministic
recorder/replay client used in tests and the notebook by default.
:class:`AnthropicClient`, :class:`OpenAIClient`, and :class:`GoogleClient`
are concrete implementations and require their respective optional
extras (``[llm-anthropic]``, ``[llm-openai]``, ``[llm-google]``, or the
umbrella ``[llm]``).
"""

from typing import TYPE_CHECKING

from .base import LLMClient, LLMResponse, Message
from .mock import MockLLMClient

if TYPE_CHECKING:
    # Imported eagerly at type-check time so ty sees the real types. At
    # runtime the imports stay lazy via __getattr__ so importing
    # ml4t.agent.llm doesn't require the optional vendor extras.
    from .anthropic import AnthropicClient as AnthropicClient
    from .google_client import GoogleClient as GoogleClient
    from .openai_client import OpenAIClient as OpenAIClient

__all__ = [
    "Message",
    "LLMClient",
    "LLMResponse",
    "MockLLMClient",
    "AnthropicClient",
    "OpenAIClient",
    "GoogleClient",
]


def __getattr__(name: str) -> object:
    if name == "AnthropicClient":
        from .anthropic import AnthropicClient

        return AnthropicClient
    if name == "OpenAIClient":
        from .openai_client import OpenAIClient

        return OpenAIClient
    if name == "GoogleClient":
        from .google_client import GoogleClient

        return GoogleClient
    raise AttributeError(f"module 'ml4t.agent.llm' has no attribute {name!r}")
