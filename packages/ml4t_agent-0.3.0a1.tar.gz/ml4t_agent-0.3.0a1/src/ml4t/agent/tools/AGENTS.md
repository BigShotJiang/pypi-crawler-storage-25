# tools/ — Bounded tool functions

The closed surface the `ResearchReviewAgent` calls. Every function here
takes typed inputs, returns a typed dataclass, and is unit-tested against
fixture artefacts. New templates extend this surface by adding new tool
modules; the contract stays uniform.

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `evidence.py` | 270 | `read_case_study_evidence`, `summarize_run`, `list_open_questions` — load and summarise a case-study run dir |
| `proposals.py` | 350 | `propose_experiments(evidence, *, llm)` — JSON-schema-bounded LLM proposal step; `default_templates`, `build_tc1_template` |
| `reruns.py` | 75 | `run_cost_sensitivity` — runs T-C1 against a fixture run dir |
| `handoff.py` | 108 | `write_experiment_spec_for_coding_agent`, `render_experiment_spec` — markdown emitter for the v0.6 hand-off |

## Tool contract

Every tool returns a typed dataclass; none of them have hidden side
effects beyond writing a file path the agent expects to find on the next
step. The LLM is bounded to a single function (`propose_experiments`)
whose output is constrained by a JSON schema enumerating the allowed
template ids and override field shapes.

## Adding a tool

1. Add a typed input/output dataclass to `schemas/`.
2. Add the tool function in a new module here. Keep it a single
   function or a small group of related functions.
3. Add a unit test in `tests/tools/` against fixture data — never
   network, never the live runner.
4. Wire it into `ResearchReviewAgent` only after the unit test passes.
