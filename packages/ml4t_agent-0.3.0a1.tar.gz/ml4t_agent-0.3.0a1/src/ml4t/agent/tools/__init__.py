"""Bounded tools the research-review agent invokes from its ReAct loop.

Each tool returns a typed schema artifact (or writes one to disk). LLM
prompting and the agent itself live in ``ml4t.agent.agents``; ``tools``
stays mechanical and side-effect-explicit.
"""

from .evidence import list_open_questions, read_case_study_evidence, summarize_run
from .handoff import render_experiment_spec, write_experiment_spec_for_coding_agent
from .proposals import (
    build_ta2_template,
    build_tc1_template,
    build_tm1_template,
    default_templates,
    propose_experiments,
)
from .reruns import run_cost_sensitivity, run_lineage_recheck, run_narrow_gbm_search

__all__ = [
    "read_case_study_evidence",
    "summarize_run",
    "list_open_questions",
    "propose_experiments",
    "default_templates",
    "build_tc1_template",
    "build_ta2_template",
    "build_tm1_template",
    "run_cost_sensitivity",
    "run_lineage_recheck",
    "run_narrow_gbm_search",
    "write_experiment_spec_for_coding_agent",
    "render_experiment_spec",
]
