"""Round-2 typed schemas for the ml4t research-loop.

Five-file split (workflow → evidence → delta → action_space → validation)
of the original ``agent_ml4t_schemas`` module from
``code/24_autonomous_agents/``. Public surface is preserved verbatim;
``from ml4t.agent.schemas import EvidencePack, validate_plan, ...`` works
exactly as before.

Module map:

- :mod:`.workflow` — enums (Severity, Determinism, IterationCategory,
  DeltaOutcome, Decision, TemplateMaturity) + workflow artifacts
  (WorkflowSpec, Finding, ResearchEvidenceReview, LineState, ExecutionRecord)
- :mod:`.evidence` — EvidencePack + components + predicates +
  ``PredicateUnavailable`` (deviation from plan §4: kept here, not in
  ``validation.py``, to avoid a circular import with the predicates)
- :mod:`.delta` — DeltaCriterion, DeltaReview, recommend_decision
- :mod:`.action_space` — OverrideSpec, ConfigPatch, StageInvocation,
  ArtifactContract, ExperimentTemplate, ExperimentPlan, IterationPlan,
  PlanValidationError (lives here because OverrideSpec.validate_value
  raises it; re-exported by ``validation.py``)
- :mod:`.validation` — validate_plan + PlanValidationError re-export
"""

from .action_space import (
    HOLDOUT_FORBIDDEN_TOKENS,
    ArtifactContract,
    ConfigPatch,
    ExperimentPlan,
    ExperimentTemplate,
    IterationPlan,
    OverrideSpec,
    PathTemplate,
    PlanValidationError,
    StageInvocation,
    ValueTypeName,
)
from .delta import (
    DeltaCriterion,
    DeltaReview,
    recommend_decision,
)
from .evidence import (
    PREDICATES,
    BacktestSummary,
    CostSummary,
    DiagnosticNote,
    EvidencePack,
    HoldoutMetrics,
    LineageSummary,
    MethodologyWarning,
    ModelRunSummary,
    PredicateUnavailable,
    RobustnessSummary,
    SignalSummary,
    ValidationDesign,
    ValidationMetrics,
    feature_triage_has_stop,
    gbm_baseline_present,
    gbm_dispersion_large,
    has_clean_validity,
    holdout_sealed,
    linear_baseline_present,
    methodology_warning_cites_lineage,
    methodology_warning_present,
    regime_features_available,
    signal_positive_net_weak,
    turnover_high,
)
from .note import ResearchNote
from .rerun_results import LineageRecheckResult, NarrowGbmResult
from .validation import validate_plan
from .workflow import (
    Decision,
    DeltaOutcome,
    Determinism,
    ExecutionRecord,
    Finding,
    IterationCategory,
    LineState,
    ResearchEvidenceReview,
    Severity,
    TemplateMaturity,
    WorkflowSpec,
)

__all__ = [
    # workflow
    "IterationCategory",
    "Severity",
    "Determinism",
    "DeltaOutcome",
    "Decision",
    "TemplateMaturity",
    "WorkflowSpec",
    "Finding",
    "ResearchEvidenceReview",
    "LineState",
    "ExecutionRecord",
    # evidence
    "ValidationDesign",
    "ModelRunSummary",
    "SignalSummary",
    "BacktestSummary",
    "CostSummary",
    "RobustnessSummary",
    "LineageSummary",
    "MethodologyWarning",
    "DiagnosticNote",
    "ValidationMetrics",
    "HoldoutMetrics",
    "EvidencePack",
    "PredicateUnavailable",
    "PREDICATES",
    "has_clean_validity",
    "methodology_warning_present",
    "methodology_warning_cites_lineage",
    "gbm_baseline_present",
    "linear_baseline_present",
    "gbm_dispersion_large",
    "signal_positive_net_weak",
    "turnover_high",
    "regime_features_available",
    "feature_triage_has_stop",
    "holdout_sealed",
    # delta
    "DeltaCriterion",
    "DeltaReview",
    "recommend_decision",
    # note
    "ResearchNote",
    # rerun_results
    "LineageRecheckResult",
    "NarrowGbmResult",
    # action_space
    "PathTemplate",
    "ValueTypeName",
    "HOLDOUT_FORBIDDEN_TOKENS",
    "PlanValidationError",
    "OverrideSpec",
    "ConfigPatch",
    "StageInvocation",
    "ArtifactContract",
    "ExperimentTemplate",
    "ExperimentPlan",
    "IterationPlan",
    # validation
    "validate_plan",
]
