"""EvidencePack and predicates.

Stage A1 builds an EvidencePack from on-disk artifacts; Stage A2 (LLM
synthesis) and every downstream stage may only cite fields from this object.
Holdout/validation are *structurally* separated.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from .workflow import Determinism, Severity

# --- EvidencePack components -------------------------------------------------


@dataclass(frozen=True)
class ValidationDesign:
    """Protocol parameters of the parent run. Static across iterations within
    a research line (loop-discipline §1.3)."""

    n_splits: int
    train_size: str
    val_size: str
    holdout_start: str
    holdout_end: str
    embargo_days: int | None
    purge_days: int | None
    fold_calendar_id: str  # opaque hash of the fold-boundary calendar


@dataclass(frozen=True)
class ModelRunSummary:
    family: str
    config_name: str
    label: str
    mean_fold_ic: float
    fold_ic_std: float
    fold_sharpe_mean: float | None
    fold_sharpe_std: float | None
    n_folds: int


@dataclass(frozen=True)
class SignalSummary:
    best_family: str
    best_config: str
    best_mean_ic: float
    ic_t_stat: float
    horizons_tested: tuple[str, ...]


@dataclass(frozen=True)
class BacktestSummary:
    config_id: str
    family: str
    gross_sharpe: float
    net_sharpe: float
    max_drawdown: float
    mean_monthly_turnover: float
    edge_to_cost_ratio: float


@dataclass(frozen=True)
class CostSummary:
    per_leg_bps_low: float
    per_leg_bps_high: float
    cost_class: str
    components: tuple[str, ...]


@dataclass(frozen=True)
class RobustnessSummary:
    fold_sharpe_dispersion: float
    regime_breakdown_available: bool
    seed_variance_estimate: float | None


@dataclass(frozen=True)
class LineageSummary:
    git_sha: str
    data_snapshot_id: str
    config_hash: str
    package_versions: Mapping[str, str]  # set MappingProxyType at construction


@dataclass(frozen=True)
class MethodologyWarning:
    code: str
    message: str
    severity: Severity
    determinism: Determinism
    triggering_artifact: str
    triggering_field: str | None = None


@dataclass(frozen=True)
class DiagnosticNote:
    """Run-log gap, metadata mismatch, or other non-methodology observation.
    Reported but does not gate decisions and is never an input to severity."""

    code: str
    message: str
    triggering_artifact: str


@dataclass(frozen=True)
class ValidationMetrics:
    """All quantitative evidence from the validation panel only."""

    model_runs: tuple[ModelRunSummary, ...]
    signal: SignalSummary
    backtests: tuple[BacktestSummary, ...]
    robustness: RobustnessSummary


@dataclass(frozen=True)
class HoldoutMetrics:
    """Populated only after `advance_to_holdout_review` has been authorized.
    During iterations 1..N this is `None`; A1 verifies that.
    """

    model_runs: tuple[ModelRunSummary, ...]
    signal: SignalSummary
    backtests: tuple[BacktestSummary, ...]


@dataclass(frozen=True)
class EvidencePack:
    """Deterministic, normalized view of a completed ML4T case-study run.

    Stage A1 builds this from on-disk artifacts. Stage A2 (LLM synthesis) and
    every downstream stage may only cite fields from this object; any claim
    that cannot be traced to an EvidencePack field is invalid.

    Holdout/validation are *structurally* separated. `holdout` is `None`
    during normal iteration. The `holdout_sealed` predicate becomes a
    structural assertion (`pack.holdout is None`), not a self-reported flag.
    """

    case_study: str
    objective: str
    primary_label: str
    horizon: str
    cadence: str
    parent_run_id: str
    line_id: str
    validation_design: ValidationDesign
    validation: ValidationMetrics
    holdout: HoldoutMetrics | None
    costs: CostSummary
    lineage: LineageSummary
    warnings: tuple[MethodologyWarning, ...]
    diagnostics: tuple[DiagnosticNote, ...] = ()


# --- Predicates --------------------------------------------------------------
# Deterministic functions referenced by `ExperimentTemplate.preconditions`.
# Documented in plans/26_etf_action_space.md §4.
#
# Contract: a predicate either returns a bool, or raises `PredicateUnavailable`
# if it cannot be evaluated (a required artifact is missing). The planner
# distinguishes "ineligible" (False) from "unable to evaluate" (raise).


class PredicateUnavailable(Exception):
    """Raised when a predicate cannot evaluate because required artifacts are
    missing from the EvidencePack. Distinct from returning False (which means
    the predicate evaluated and the condition does not hold)."""


def has_clean_validity(pack: EvidencePack) -> bool:
    return not any(w.severity in (Severity.BLOCKING, Severity.MATERIAL) for w in pack.warnings)


def methodology_warning_present(pack: EvidencePack) -> bool:
    return any(w.severity in (Severity.BLOCKING, Severity.MATERIAL) for w in pack.warnings)


# Fields on `LineageSummary`. A `MethodologyWarning` whose `triggering_field`
# matches one of these is treated as a lineage-citing finding by
# `methodology_warning_cites_lineage`. Substring match on `code` ("lineage"
# / "reproducib") is the second signal.
_LINEAGE_FIELDS: frozenset[str] = frozenset(
    {"git_sha", "data_snapshot_id", "config_hash", "package_versions"}
)


def methodology_warning_cites_lineage(pack: EvidencePack) -> bool:
    """T-A2 eligibility: a BLOCKING/MATERIAL warning that cites lineage.

    A warning cites lineage if either:

    - `code` contains the substring ``"lineage"`` or ``"reproducib"``
      (case-insensitive), or
    - `triggering_field` is one of the `LineageSummary` fields
      (``git_sha``, ``data_snapshot_id``, ``config_hash``,
      ``package_versions``).

    Only BLOCKING / MATERIAL severities count, matching the gating
    convention of `methodology_warning_present`. Plain WARNING-severity
    lineage observations do not trigger T-A2 — they are reported but do
    not gate the line.
    """

    for w in pack.warnings:
        if w.severity not in (Severity.BLOCKING, Severity.MATERIAL):
            continue
        code = w.code.lower()
        if "lineage" in code or "reproducib" in code:
            return True
        if w.triggering_field in _LINEAGE_FIELDS:
            return True
    return False


def gbm_baseline_present(pack: EvidencePack) -> bool:
    return any(r.family == "gbm" for r in pack.validation.model_runs)


def linear_baseline_present(pack: EvidencePack) -> bool:
    return any(r.family == "linear" for r in pack.validation.model_runs)


def gbm_dispersion_large(pack: EvidencePack) -> bool:
    """T-M1 eligibility: best GBM run has fold-IC std >= 0.5 * |mean_fold_ic|.

    Threshold per plan-29 (user decision, 2026-05-02): `fold_ic_std >=
    0.5 * |mean_fold_ic|` over the GBM run with the largest mean_fold_ic.
    Raises `PredicateUnavailable` when no GBM run is present. Returns
    False when |mean_fold_ic| is near-zero (no signal to tighten),
    avoiding a degenerate "any nonzero dispersion qualifies" outcome.
    """

    gbms = [r for r in pack.validation.model_runs if r.family == "gbm"]
    if not gbms:
        raise PredicateUnavailable("no gbm model_runs in validation")
    best = max(gbms, key=lambda r: r.mean_fold_ic)
    if abs(best.mean_fold_ic) < 1e-9:
        return False
    return best.fold_ic_std >= 0.5 * abs(best.mean_fold_ic)


def signal_positive_net_weak(pack: EvidencePack) -> bool:
    if not pack.validation.backtests:
        raise PredicateUnavailable("no backtests in validation")
    benchmark = next((b for b in pack.validation.backtests if b.family == "benchmark"), None)
    if benchmark is None:
        raise PredicateUnavailable("no benchmark backtest in validation set")
    strategies = [b for b in pack.validation.backtests if b.family != "benchmark"]
    if not strategies:
        raise PredicateUnavailable("no non-benchmark backtest in validation set")
    if pack.validation.signal.ic_t_stat <= 2.0:
        return False
    best_strategy_net = max(b.net_sharpe for b in strategies)
    return best_strategy_net <= benchmark.net_sharpe


def turnover_high(pack: EvidencePack, threshold: float = 0.30) -> bool:
    if not pack.validation.backtests:
        raise PredicateUnavailable("no backtests in validation")
    strategies = [b for b in pack.validation.backtests if b.family != "benchmark"]
    if not strategies:
        raise PredicateUnavailable("no non-benchmark backtest in validation set")
    return max(b.mean_monthly_turnover for b in strategies) > threshold


def regime_features_available(pack: EvidencePack) -> bool:
    return pack.validation.robustness.regime_breakdown_available


def feature_triage_has_stop(pack: EvidencePack) -> bool:
    """Pending: requires the runner to expose triage_ledger.parquet rows on
    EvidencePack. Until that contract exists, this predicate is unavailable
    rather than silently False."""

    raise PredicateUnavailable("triage ledger is not yet on EvidencePack; runner contract pending")


def holdout_sealed(pack: EvidencePack) -> bool:
    """Structural seal. Returns True iff no holdout metrics are present."""

    return pack.holdout is None


PREDICATES: dict[str, Any] = {
    "has_clean_validity": has_clean_validity,
    "methodology_warning_present": methodology_warning_present,
    "methodology_warning_cites_lineage": methodology_warning_cites_lineage,
    "gbm_baseline_present": gbm_baseline_present,
    "linear_baseline_present": linear_baseline_present,
    "gbm_dispersion_large": gbm_dispersion_large,
    "signal_positive_net_weak": signal_positive_net_weak,
    "turnover_high": turnover_high,
    "regime_features_available": regime_features_available,
    "feature_triage_has_stop": feature_triage_has_stop,
    "holdout_sealed": holdout_sealed,
}
