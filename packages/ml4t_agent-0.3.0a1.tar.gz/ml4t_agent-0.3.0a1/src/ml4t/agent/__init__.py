"""ml4t-agent — systematic research agent for ml4t case studies.

The v0.1 public surface (tools, schemas, agents, llm adapter) is populated by
T2-T7 of plan 28. The pre-existing benchmark scaffolding has been archived
under :mod:`ml4t.agent._benchmark` (private, see ROADMAP.md v0.5/v0.6).
"""

from importlib.metadata import PackageNotFoundError as _PackageNotFoundError
from importlib.metadata import version as _dist_version

from ml4t.agent.agents import ResearchReviewAgent
from ml4t.agent.llm import LLMClient, MockLLMClient
from ml4t.agent.schemas import (
    EvidencePack,
    ExperimentTemplate,
    ResearchNote,
)
from ml4t.agent.tools import (
    propose_experiments,
    read_case_study_evidence,
    run_cost_sensitivity,
    summarize_run,
    write_experiment_spec_for_coding_agent,
)

try:
    from ml4t.agent._version import version as __version__
except Exception:
    try:
        __version__ = _dist_version("ml4t-agent")
    except _PackageNotFoundError:
        __version__ = "0+unknown"

__all__ = [
    "EvidencePack",
    "ResearchNote",
    "ExperimentTemplate",
    "ResearchReviewAgent",
    "read_case_study_evidence",
    "summarize_run",
    "propose_experiments",
    "run_cost_sensitivity",
    "write_experiment_spec_for_coding_agent",
    "LLMClient",
    "MockLLMClient",
]
