"""Single-agent ReAct loop that emits a :class:`ResearchNote`.

The loop runs a fixed sequence of bounded tool calls — read evidence,
propose, optionally rerun, evaluate delta, decide — and records each
step on an :class:`AgentTrace`. The LLM is consulted exactly once per
run (inside :func:`propose_experiments`); everything else is
deterministic and unit-testable.

Delta evaluation in v0.1 reads a fixture artefact
``delta_review_{template_id}.json`` from the run directory. v0.6 will
swap that for a real rerun + bootstrap pipeline; the schema and the
loop stay the same.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ml4t.agent.llm import LLMClient
from ml4t.agent.schemas import (
    Decision,
    DeltaOutcome,
    DeltaReview,
    EvidencePack,
    ExperimentPlan,
    ExperimentTemplate,
    LineState,
    ModelRunSummary,
    ResearchNote,
    recommend_decision,
)
from ml4t.agent.tools import (
    propose_experiments,
    read_case_study_evidence,
    run_cost_sensitivity,
    run_lineage_recheck,
    run_narrow_gbm_search,
    summarize_run,
)
from ml4t.agent.tracing import AgentRun, AgentTrace

__all__ = ["ResearchReviewAgent", "DELTA_REVIEW_FILENAME"]


DELTA_REVIEW_FILENAME = "delta_review_{template_id}.json"
DEFAULT_MAX_STEPS = 5


class ResearchReviewAgent:
    """ReAct loop: evidence → propose → rerun → evaluate → decide.

    The agent keeps no hidden state between :meth:`run` calls; every
    invocation produces a fresh :class:`AgentRun` accessible via
    :attr:`last_run`.
    """

    def __init__(
        self,
        llm: LLMClient,
        *,
        line_state: LineState,
        templates: Sequence[ExperimentTemplate] | None = None,
        max_steps: int = DEFAULT_MAX_STEPS,
        agent_id: str = "ResearchReviewAgent.v0.1",
    ) -> None:
        if max_steps < 4:
            raise ValueError("max_steps must be >= 4 (read, propose, evaluate, decide)")
        self._llm = llm
        self._line_state = line_state
        self._templates = templates
        self._max_steps = max_steps
        self._agent_id = agent_id
        self.last_run: AgentRun | None = None

    def run(self, run_dir: Path | str) -> ResearchNote:
        """Execute one iteration over ``run_dir`` and return the note."""

        rd = Path(run_dir)
        traces: list[AgentTrace] = []
        step = 0

        # Step 1 — read evidence
        step += 1
        evidence = read_case_study_evidence(rd)
        traces.append(
            _trace(
                step=step,
                action="read_evidence",
                tool_name="read_case_study_evidence",
                inputs={"run_dir": str(rd)},
                outputs={
                    "case_study": evidence.case_study,
                    "parent_run_id": evidence.parent_run_id,
                    "warning_count": len(evidence.warnings),
                },
            )
        )

        # Step 2 — propose
        step += 1
        proposals = propose_experiments(
            evidence,
            llm=self._llm,
            line_state=self._line_state,
            templates=self._templates,
        )
        traces.append(
            _trace(
                step=step,
                action="propose",
                tool_name="propose_experiments",
                inputs={"line_iteration_index": self._line_state.iteration_index},
                outputs={
                    "n_proposals": len(proposals),
                    "template_ids": [p.template_id for p in proposals],
                },
            )
        )

        if not proposals:
            return self._finalize(
                evidence,
                proposals=(),
                selected=None,
                delta=None,
                decision=Decision.STOP_RESEARCH_LINE,
                rationale=(
                    "no template was eligible for the current evidence pack; "
                    "the line cannot iterate without resolving ineligibility"
                ),
                traces=traces,
            )

        # Step 3 — pick the first proposal (deterministic; ranking is post-v0.1)
        selected = proposals[0]

        # Step 4 — optional rerun, dispatched by template_id.
        if step < self._max_steps - 1:
            rerun_trace = self._maybe_rerun(selected, evidence, rd, step + 1)
            if rerun_trace is not None:
                step += 1
                traces.append(rerun_trace)

        # Step N-1 — evaluate delta
        step += 1
        delta = _load_delta_review(rd, selected)
        if delta is None:
            traces.append(
                _trace(
                    step=step,
                    action="evaluate",
                    tool_name=None,
                    inputs={"experiment_id": selected.experiment_id},
                    outputs={"status": "no_delta_review_artifact"},
                )
            )
            return self._finalize(
                evidence,
                proposals=tuple(proposals),
                selected=selected,
                delta=None,
                decision=Decision.ITERATE_OFFLINE,
                rationale=(
                    f"no delta-review artifact for {selected.experiment_id}; "
                    "agent emitted the proposal for the coding agent to execute"
                ),
                traces=traces,
            )

        traces.append(
            _trace(
                step=step,
                action="evaluate",
                tool_name=None,
                inputs={"experiment_id": selected.experiment_id},
                outputs={
                    "outcome": delta.outcome.value,
                    "point_estimate": delta.point_estimate,
                    "interval": [delta.interval_low, delta.interval_high],
                },
            )
        )

        # Step N — decide
        step += 1
        decision = recommend_decision(
            review=None,
            delta=delta,
            line_state=self._line_state,
            consecutive_inconclusive=(1 if delta.outcome is DeltaOutcome.INCONCLUSIVE else 0),
            audits_consumed=0,
        )
        rationale = _decision_rationale(decision, delta, selected)
        traces.append(
            _trace(
                step=step,
                action="decide",
                tool_name="recommend_decision",
                inputs={"delta_outcome": delta.outcome.value},
                outputs={"decision": decision.value, "rationale": rationale},
            )
        )

        return self._finalize(
            evidence,
            proposals=tuple(proposals),
            selected=selected,
            delta=delta,
            decision=decision,
            rationale=rationale,
            traces=traces,
        )

    # --- helpers ---------------------------------------------------------

    def _maybe_rerun(
        self,
        plan: ExperimentPlan,
        evidence: EvidencePack,
        run_dir: Path,
        step: int,
    ) -> AgentTrace | None:
        """Dispatch the per-template rerun tool. Returns a trace, or None
        if the template has no rerun wired up or the fixture is missing."""

        if plan.template_id == "T-C1":
            cost_range = _cost_range_from_plan(plan, evidence)
            cost_summary = run_cost_sensitivity(run_dir, cost_bps_range=cost_range)
            return _trace(
                step=step,
                action="rerun",
                tool_name="run_cost_sensitivity",
                inputs={"cost_bps_range": list(cost_range)},
                outputs={
                    "cost_class": cost_summary.cost_class,
                    "components": list(cost_summary.components),
                },
            )

        if plan.template_id == "T-A2":
            baseline = _best_baseline(evidence, plan)
            try:
                result = run_lineage_recheck(run_dir, parent_baseline=baseline)
            except FileNotFoundError:
                return None
            return _trace(
                step=step,
                action="rerun",
                tool_name="run_lineage_recheck",
                inputs={"parent_baseline_config": baseline.config_name},
                outputs={
                    "mean_fold_ic_after": result.mean_fold_ic_after,
                    "git_sha_at_rerun": result.git_sha_at_rerun,
                },
            )

        if plan.template_id == "T-M1":
            presets = _presets_from_tm1_plan(plan)
            baseline = _best_gbm_baseline(evidence)
            if baseline is None or not presets:
                return None
            try:
                result = run_narrow_gbm_search(
                    run_dir,
                    presets_to_try=presets,
                    baseline_within_family=baseline,
                )
            except FileNotFoundError:
                return None
            return _trace(
                step=step,
                action="rerun",
                tool_name="run_narrow_gbm_search",
                inputs={"presets_to_try": list(presets)},
                outputs={
                    "best_within_family_config": result.best_within_family.config_name,
                    "mean_fold_ic_within_family_delta": (result.mean_fold_ic_within_family_delta),
                },
            )

        return None

    def _finalize(
        self,
        evidence: EvidencePack,
        *,
        proposals: tuple[ExperimentPlan, ...],
        selected: ExperimentPlan | None,
        delta: DeltaReview | None,
        decision: Decision,
        rationale: str,
        traces: list[AgentTrace],
    ) -> ResearchNote:
        note = ResearchNote(
            line_id=self._line_state.line_id,
            iteration_index=self._line_state.iteration_index,
            parent_run_id=evidence.parent_run_id,
            case_study=evidence.case_study,
            objective=evidence.objective,
            summary=summarize_run(evidence),
            proposals=proposals,
            selected_experiment_id=selected.experiment_id if selected else None,
            delta_review=delta,
            decision=decision,
            rationale=rationale,
            open_questions=tuple(_open_questions(evidence, delta)),
        )
        self.last_run = AgentRun(
            run_id=f"{self._line_state.line_id}-i{self._line_state.iteration_index}",
            agent_id=self._agent_id,
            traces=tuple(traces),
            final_artifact={
                "decision": note.decision.value,
                "selected_experiment_id": note.selected_experiment_id,
            },
        )
        return note


def _trace(
    *,
    step: int,
    action: str,
    tool_name: str | None,
    inputs: Mapping[str, Any] | None,
    outputs: Mapping[str, Any] | None,
) -> AgentTrace:
    return AgentTrace(
        step=step,
        action=action,
        tool_name=tool_name,
        inputs=inputs,
        outputs=outputs,
        timestamp=datetime.now(UTC).isoformat(),
    )


def _best_baseline(evidence: EvidencePack, plan: ExperimentPlan) -> ModelRunSummary:
    """Best-IC run in the parent's signal-best family. Falls back to the
    overall-best run if the family isn't represented (defensive — the T-A2
    eligibility predicate already implies a baseline exists)."""

    runs = evidence.validation.model_runs
    if not runs:
        raise ValueError(f"{plan.experiment_id}: no model_runs in evidence")
    best_family = evidence.validation.signal.best_family
    in_family = [r for r in runs if r.family == best_family]
    if in_family:
        return max(in_family, key=lambda r: r.mean_fold_ic)
    return max(runs, key=lambda r: r.mean_fold_ic)


def _best_gbm_baseline(evidence: EvidencePack) -> ModelRunSummary | None:
    gbms = [r for r in evidence.validation.model_runs if r.family == "gbm"]
    if not gbms:
        return None
    return max(gbms, key=lambda r: r.mean_fold_ic)


def _presets_from_tm1_plan(plan: ExperimentPlan) -> tuple[str, ...]:
    for patch in plan.config_patches:
        if patch.yaml_path == ("gbm",):
            value = patch.new_value
            if isinstance(value, list | tuple):
                return tuple(str(v) for v in value)
    return ()


def _cost_range_from_plan(plan: ExperimentPlan, evidence: EvidencePack) -> tuple[float, float]:
    """Pull (low, high) from the T-C1 cost patch; fall back to evidence."""
    for patch in plan.config_patches:
        if patch.yaml_path == ("costs", "per_leg_cost_bps_range"):
            value = patch.new_value
            if isinstance(value, list | tuple) and len(value) == 2:
                return float(value[0]), float(value[1])
    return evidence.costs.per_leg_bps_low, evidence.costs.per_leg_bps_high


def _load_delta_review(run_dir: Path, plan: ExperimentPlan) -> DeltaReview | None:
    path = run_dir / DELTA_REVIEW_FILENAME.format(template_id=plan.template_id)
    if not path.is_file():
        return None
    with path.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"{path}: expected JSON object")
    try:
        outcome = DeltaOutcome(str(data["outcome"]))
        decision_value = data.get("recommendation")
        recommendation = (
            Decision(str(decision_value))
            if decision_value is not None
            else Decision.ITERATE_OFFLINE
        )
        return DeltaReview(
            experiment_id=str(data.get("experiment_id", plan.experiment_id)),
            primary_metric=str(data["primary_metric"]),
            metric_kind=data["metric_kind"],
            before=float(data["before"]),
            after=float(data["after"]),
            point_estimate=float(data["point_estimate"]),
            interval_low=float(data["interval_low"]),
            interval_high=float(data["interval_high"]),
            fold_deltas=tuple(float(x) for x in data.get("fold_deltas", [])),
            cost_sensitivity=tuple(
                (float(a), float(b)) for a, b in data.get("cost_sensitivity", [])
            ),
            outcome=outcome,
            recommendation=recommendation,
            rationale=str(data.get("rationale", "")),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"{path}: malformed delta_review: {exc}") from exc


def _decision_rationale(decision: Decision, delta: DeltaReview, plan: ExperimentPlan) -> str:
    if decision is Decision.STOP_RESEARCH_LINE:
        return (
            f"{plan.experiment_id} produced delta outcome {delta.outcome.value}; "
            "loop-discipline §6 stops the line"
        )
    if decision is Decision.ADVANCE_TO_HOLDOUT_REVIEW:
        return (
            f"{plan.experiment_id} supported the hypothesis on the validation "
            "panel; the line is mature enough for holdout review"
        )
    if decision is Decision.AUDIT_REQUIRED:
        return (
            f"{plan.experiment_id} flagged invalidity; an audit cycle is "
            "required before further iteration"
        )
    return (
        f"{plan.experiment_id} delta {delta.outcome.value}; another offline "
        "iteration is justified within budget"
    )


def _open_questions(evidence: EvidencePack, delta: DeltaReview | None) -> list[str]:
    questions: list[str] = []
    if delta is None:
        questions.append("delta-review artifact missing; rerun and re-evaluate")
        return questions
    if delta.outcome is DeltaOutcome.INCONCLUSIVE:
        questions.append(
            f"{delta.experiment_id} inconclusive at adjusted alpha; can the "
            "rerun be tightened (more folds, longer block bootstrap)?"
        )
    if not evidence.validation.robustness.regime_breakdown_available:
        questions.append(
            "regime breakdown not available; consider regime-tagged delta before advancing"
        )
    return questions
