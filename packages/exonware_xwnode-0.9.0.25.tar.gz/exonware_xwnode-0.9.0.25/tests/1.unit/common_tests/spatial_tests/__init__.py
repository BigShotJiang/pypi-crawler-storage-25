"""
Spatial tests module.
"""
