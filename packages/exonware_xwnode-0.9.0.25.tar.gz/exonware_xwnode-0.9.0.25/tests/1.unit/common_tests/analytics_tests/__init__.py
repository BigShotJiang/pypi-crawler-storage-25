"""
Analytics tests module.
"""
