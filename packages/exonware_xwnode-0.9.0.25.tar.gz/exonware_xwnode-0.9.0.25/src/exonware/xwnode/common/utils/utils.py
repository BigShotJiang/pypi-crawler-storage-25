"""
Shared utilities for XWNode strategies.
This module provides common functionality that can be used by multiple strategies
without creating cross-dependencies between strategies.
"""

from __future__ import annotations
import threading
from typing import Any
import weakref
import time
# Use xSystem logging
from exonware.xwsystem import get_logger
from exonware.xwsystem.caching import create_cache
from collections.abc import Iterator
logger = get_logger('xnode.strategies.utils')
# ============================================================================
# PATH PARSING UTILITIES
# ============================================================================
# REUSE xwsystem.io.path_parser.PathParser
from exonware.xwsystem.io.path_parser import PathParser
# ============================================================================
# ADVANCED DATA STRUCTURES (Shared implementations)
# ============================================================================
# REUSE xwsystem.data_structures
from exonware.xwsystem.data_structures import TrieNode, UnionFind


class MinHeap:
    """Min-heap implementation for priority queue operations - shared across strategies."""

    def __init__(self):
        self._heap: list[tuple[float, Any]] = []
        self._size = 0

    def push(self, value: Any, priority: float = 0.0) -> None:
        """Push item with priority. O(log n)"""
        self._heap.append((priority, value))
        self._size += 1
        self._heapify_up(self._size - 1)

    def pop_min(self) -> Any:
        """Pop minimum priority item. O(log n)"""
        if self._size == 0:
            raise IndexError("Heap is empty")
        min_val = self._heap[0][1]
        self._heap[0] = self._heap[self._size - 1]
        self._heap.pop()
        self._size -= 1
        if self._size > 0:
            self._heapify_down(0)
        return min_val

    def peek_min(self) -> Any:
        """Peek at minimum without removing. O(1)"""
        if self._size == 0:
            raise IndexError("Heap is empty")
        return self._heap[0][1]

    def _heapify_up(self, index: int) -> None:
        """Move element up to maintain heap property."""
        parent = (index - 1) // 2
        if parent >= 0 and self._heap[index][0] < self._heap[parent][0]:
            self._heap[index], self._heap[parent] = self._heap[parent], self._heap[index]
            self._heapify_up(parent)

    def _heapify_down(self, index: int) -> None:
        """Move element down to maintain heap property."""
        smallest = index
        left = 2 * index + 1
        right = 2 * index + 2
        if left < self._size and self._heap[left][0] < self._heap[smallest][0]:
            smallest = left
        if right < self._size and self._heap[right][0] < self._heap[smallest][0]:
            smallest = right
        if smallest != index:
            self._heap[index], self._heap[smallest] = self._heap[smallest], self._heap[index]
            self._heapify_down(smallest)

    def size(self) -> int:
        """Get heap size. O(1)"""
        return self._size

    def is_empty(self) -> bool:
        """Check if heap is empty. O(1)"""
        return self._size == 0
# ============================================================================
# COMMON UTILITY FUNCTIONS
# ============================================================================

def recursive_to_native(obj: Any) -> Any:
    """
    Recursively convert objects to native Python types.
    This is a shared utility for converting complex objects (including XWNode objects)
    to native Python types for serialization and comparison.
    """
    if hasattr(obj, 'to_native'):
        # This is an XWNode, recursively convert it
        return recursive_to_native(obj.to_native())
    elif isinstance(obj, dict):
        return {k: recursive_to_native(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [recursive_to_native(item) for item in obj]
    else:
        return obj


def is_sequential_numeric_keys(data: dict[str, Any]) -> bool:
    """
    Check if dictionary keys are sequential numeric indices (for list detection).
    This is useful for determining if a dict represents a list structure.
    """
    if not data:
        return False
    keys = list(data.keys())
    try:
        indices = [int(k) for k in keys]
        return indices == list(range(len(indices)))
    except ValueError:
        return False


def calculate_structural_hash(data: dict[str, Any]) -> int:
    """
    Calculate a structural hash based on keys only (not values).
    This is useful for fast equality checking when values don't matter.
    """
    return hash(tuple(sorted(data.keys())))


def validate_traits(supported_traits, requested_traits, strategy_name: str) -> None:
    """
    Validate that requested traits are supported by a strategy.
    Args:
        supported_traits: Traits supported by the strategy
        requested_traits: Traits requested by the user
        strategy_name: Name of the strategy for error messages
    """
    unsupported = requested_traits & ~supported_traits
    if unsupported != 0:
        unsupported_names = [trait.name for trait in unsupported]
        raise ValueError(f"Strategy {strategy_name} does not support traits: {unsupported_names}")
# ============================================================================
# PERFORMANCE MONITORING UTILITIES
# ============================================================================

class PerformanceTracker:
    """
    Shared performance tracking utilities for strategies.
    Performance Optimization:
    - Uses xwsystem create_cache() for operation_times (PylruCache when pylru installed)
    - Automatic eviction when capacity is reached (limits memory usage)
    - Built-in statistics via cache.get_stats()
    - Thread-safe by default (via xwsystem cache)
    """

    def __init__(self, max_operations: int = 100):
        """
        Initialize performance tracker.
        Args:
            max_operations: Maximum number of tracked operations (default: 100)
        """
        self._access_count = 0
        self._cache_hits = 0
        self._cache_misses = 0
        # Use xwsystem optimized cache for operation times (automatic eviction)
        # Limits memory usage by automatically evicting old operation entries
        self._operation_times = create_cache(
            capacity=max_operations,
            namespace='xwnode',
            name='performance_tracker_operation_times'
        )
        self._max_operations = max_operations
        self._lock = threading.RLock()  # Still needed for counter updates

    def record_access(self) -> None:
        """Record a data access operation."""
        with self._lock:
            self._access_count += 1

    def record_cache_hit(self) -> None:
        """Record a cache hit."""
        with self._lock:
            self._cache_hits += 1

    def record_cache_miss(self) -> None:
        """Record a cache miss."""
        with self._lock:
            self._cache_misses += 1

    def record_operation_time(self, operation: str, time_taken: float) -> None:
        """
        Record the time taken for an operation.
        Performance: Uses xwsystem cache for automatic eviction of old entries.
        Keeps only the most recent measurements per operation (limited by cache capacity).
        """
        # Get existing times list or create new one
        times = self._operation_times.get(operation)
        if times is None:
            times = []
        # Append new measurement
        times.append(time_taken)
        # Keep only last N measurements per operation to limit memory
        # (Cache eviction handles when capacity is exceeded, but we also limit per-operation size)
        max_per_operation = min(1000, self._max_operations)  # Limit per-operation size
        if len(times) > max_per_operation:
            times = times[-max_per_operation:]
        # Store back to cache (automatic eviction when capacity exceeded)
        self._operation_times.put(operation, times)

    def get_metrics(self) -> dict[str, Any]:
        """Get performance metrics."""
        with self._lock:
            metrics = {
                'access_count': self._access_count,
                'cache_hits': self._cache_hits,
                'cache_misses': self._cache_misses,
            }
            # Calculate cache hit rate
            total_cache_ops = self._cache_hits + self._cache_misses
            if total_cache_ops > 0:
                metrics['cache_hit_rate'] = self._cache_hits / total_cache_ops
            else:
                metrics['cache_hit_rate'] = 0.0
            # Calculate average operation times (using xwsystem cache items())
            for operation, times in self._operation_times.items():
                if times:
                    metrics[f'{operation}_avg_time'] = sum(times) / len(times)
                    metrics[f'{operation}_min_time'] = min(times)
                    metrics[f'{operation}_max_time'] = max(times)
            return metrics

    def reset(self) -> None:
        """Reset all performance counters."""
        with self._lock:
            self._access_count = 0
            self._cache_hits = 0
            self._cache_misses = 0
            self._operation_times.clear()  # xwsystem cache clear() method
# ============================================================================
# OBJECT POOLING UTILITIES
# ============================================================================

class ObjectPool:
    """Generic object pool for strategies that need pooling."""

    def __init__(self, max_size: int = 100):
        self._pool: list[Any] = []
        self._max_size = max_size
        self._lock = threading.RLock()
        self._stats = {
            'created': 0,
            'reused': 0,
            'pooled': 0
        }

    def get_object(self, factory_func, *args, **kwargs) -> Any:
        """
        Get an object from the pool or create a new one.
        Args:
            factory_func: Function to create new objects
            *args, **kwargs: Arguments for factory function
        Returns:
            Object from pool or newly created
        """
        with self._lock:
            if self._pool:
                # Reuse existing object
                obj = self._pool.pop()
                self._stats['reused'] += 1
                logger.debug(f"♻️ Reused object from pool")
                return obj
            else:
                # Create new object
                obj = factory_func(*args, **kwargs)
                self._stats['created'] += 1
                logger.debug(f"🆕 Created new object")
                return obj

    def return_object(self, obj: Any, reset_func=None) -> None:
        """
        Return an object to the pool for reuse.
        Args:
            obj: Object to return to pool
            reset_func: Optional function to reset object state
        """
        with self._lock:
            if len(self._pool) < self._max_size:
                if reset_func:
                    reset_func(obj)
                self._pool.append(obj)
                self._stats['pooled'] += 1
                logger.debug(f"🔄 Returned object to pool")

    def get_stats(self) -> dict[str, int]:
        """Get pool statistics."""
        with self._lock:
            stats = self._stats.copy()
            stats['pool_size'] = len(self._pool)
            return stats
    @property

    def efficiency(self) -> float:
        """Get pool efficiency (reuse rate)."""
        total = self._stats['created'] + self._stats['reused']
        return self._stats['reused'] / total if total > 0 else 0.0

    def clear(self) -> None:
        """Clear all pooled objects."""
        with self._lock:
            self._pool.clear()
            logger.info("🧹 Cleared object pool")
# ============================================================================
# FACTORY FUNCTIONS
# ============================================================================

def create_path_parser(max_cache_size: int = 1024) -> PathParser:
    """Create a path parser instance."""
    return PathParser(max_cache_size)


def create_performance_tracker() -> PerformanceTracker:
    """Create a performance tracker instance."""
    return PerformanceTracker()


def create_object_pool(max_size: int = 100) -> ObjectPool:
    """Create an object pool instance."""
    return ObjectPool(max_size)


def create_basic_metrics(strategy_name: str, size: int, **additional_metrics) -> dict[str, Any]:
    """Create basic metrics dictionary for strategies."""
    metrics = {
        'strategy': strategy_name,
        'size': size,
        'memory_usage': f"{size * 64} bytes (estimated)",
        'timestamp': time.time()
    }
    metrics.update(additional_metrics)
    return metrics


def create_basic_backend_info(strategy_name: str, backend_type: str, **additional_info) -> dict[str, Any]:
    """Create basic backend info dictionary for strategies."""
    info = {
        'strategy': strategy_name,
        'backend': backend_type,
        'complexity': {
            'get': 'O(1) average',
            'put': 'O(1) average',
            'has': 'O(1) average',
            'remove': 'O(1) average'
        }
    }
    info.update(additional_info)
    return info


def is_list_like(keys: list[str]) -> bool:
    """Check if keys represent a list-like structure."""
    if not keys:
        return False
    # Check if all keys are numeric and consecutive starting from 0
    try:
        numeric_keys = [int(key) for key in keys]
        return numeric_keys == list(range(len(numeric_keys)))
    except (ValueError, TypeError):
        return False


def safe_to_native_conversion(data: Any) -> Any:
    """Safely convert data to native Python types, handling XWNode objects."""
    if hasattr(data, 'to_native'):
        # This is an XWNode, recursively convert it
        return safe_to_native_conversion(data.to_native())
    elif isinstance(data, dict):
        return {k: safe_to_native_conversion(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [safe_to_native_conversion(item) for item in data]
    elif isinstance(data, (set, frozenset)):
        return {safe_to_native_conversion(item) for item in data}
    else:
        return data


def create_strategy_logger(strategy_name: str):
    """Create a logger for a specific strategy."""
    return get_logger(f"xnode.strategy.{strategy_name}")


def validate_strategy_options(options: dict[str, Any], allowed_options: list[str]) -> dict[str, Any]:
    """Validate strategy options and return only allowed ones."""
    return {k: v for k, v in options.items() if k in allowed_options}


def create_size_tracker() -> dict[str, int]:
    """Create a size tracking dictionary."""
    return {'size': 0}


def update_size_tracker(tracker: dict[str, int], delta: int) -> None:
    """Update size tracker with delta change."""
    tracker['size'] = max(0, tracker['size'] + delta)


def create_access_tracker() -> dict[str, int]:
    """Create an access tracking dictionary."""
    return {
        'get_count': 0,
        'put_count': 0,
        'delete_count': 0,
        'access_count': 0
    }


def record_access(tracker: dict[str, int], operation: str) -> None:
    """Record an access operation."""
    if operation in tracker:
        tracker[operation] += 1
    tracker['access_count'] += 1


def get_access_metrics(tracker: dict[str, int]) -> dict[str, Any]:
    """Get access metrics from tracker."""
    return {
        'total_accesses': tracker['access_count'],
        'get_operations': tracker['get_count'],
        'put_operations': tracker['put_count'],
        'delete_operations': tracker['delete_count']
    }
