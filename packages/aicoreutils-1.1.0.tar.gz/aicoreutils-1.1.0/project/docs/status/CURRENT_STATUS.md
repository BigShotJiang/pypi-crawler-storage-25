# 当前项目状态 / Current Project Status

## 中文说明

> **这是项目当前状态的唯一权威来源。**
> 历史报告见 `docs/reports/`，分析日志见 `docs/analysis/`。

| 属性 | 值 |
|---|---|
| **最后验证日期** | 2026-05-05 |
| **验证对象** | 本地工作区（`5c8d941`，已推送并通过 CI 全平台验证 11/11） |
| **Python 版本** | Windows: 3.14.4; WSL: 3.12.3; CI: 3.11/3.12/3.13 |
| **操作系统** | Windows 11 (开发) + WSL Ubuntu-24.04 (Ubuntu 24.04.4 LTS), CI: ubuntu-latest + macos-latest + windows-latest |
| **项目版本** | 1.1.0 |

### 测试

| 指标 | 数值 |
|---|---|
| **推荐测试命令** | `python -m pytest project/tests/ -v --tb=short` |
| **Legacy 入口** | `python -m unittest discover -s tests -v` (部分运行器) |
| **Windows 推荐入口结果** | 399 passed, 60 skipped, 0 failed (Python 3.14) |
| **CI 全平台结果 (最新)** | Ubuntu: 399 passed, 1 skipped; macOS: 399 passed, 60 skipped; Windows: 399 passed, 60 skipped; lint + typecheck ✅ |
| **Windows 跳过原因** | 无 symlink 支持; locale 相关中文排序/分词; GNU 工具部分不可用 (choco 安装后部分可用) |
| **Property-based 测试** | `python -m pytest project/tests/test_property_based_cli.py -v` (25 测试) |
| **GNU 对照测试** | `python -m pytest project/tests/test_gnu_differential.py -v`（56 测试；Ubuntu CI 通过；Windows/macOS 按平台跳过） |
| **沙箱逃逸测试** | `python -m pytest project/tests/test_sandbox_escape_hardening.py -v` (46 测试, 全部通过或 skip) |
| **文档治理测试** | `python -m pytest project/tests/test_docs_governance.py -v` (9 测试, 全部通过) |
| **双语文档测试** | `python -m pytest project/tests/test_docs_bilingual.py -v` (1 测试, 通过) |
| **版本一致性测试** | `python -m pytest tests/test_version_consistency.py -v` (4 测试, 本地通过; CI 未纳入) |
| **覆盖率** | `python -m pytest project/tests/ --cov=src/aicoreutils` (需要 pytest-cov; 阈值 45%) |
| **静态检查** | `ruff check src/ project/tests/`; `ruff format --check src/ project/tests/`; `mypy src/aicoreutils/ --strict` 全部通过 |
| **CI 平台** | GitHub Actions: ubuntu-latest (3.11/3.12/3.13), macos-latest (3.12/3.13), windows-latest (3.11/3.12/3.13) |

### 安全状态

| 项目 | 状态 |
|---|---|
| **沙箱逃逸漏洞** | ✅ 全部 5 个已知漏洞已于 2026-04-30 修复 |
| **cwd 边界校验** | ✅ 全 20 个 mutating 命令均校验目标路径在 cwd 内（含 cp/mv/ln/link/mkdir/touch/chmod/chown/chgrp/shred/mktemp/mkfifo/mknod/rmdir/unlink/csplit/split/nohup） |
| **符号链接逃逸** | ✅ `resolve_path` 解析真实路径后校验; Windows 跳过(symlink 不可用) |
| **dry-run 零副作用** | ✅ 20 个 mutating 命令 dry-run 均通过零副作用验证 |
| **危险命令默认拒绝** | ✅ shred/kill/nice/nohup/stty/chcon/runcon/chroot 需要显式 `--allow-*` 确认 |
| **MCP 安全控制** | ✅ `--read-only`/`--allow-command`/`--deny-command` 三级权限 |

### GNU 兼容性状态

| 项目 | 状态 |
|---|---|
| **GNU 命令名覆盖** | 109/109 |
| **Agent 子集实现** | 全部 114 命令（含 5 个元命令：catalog、schema、coreutils、tool-list、hash） |
| **GNU differential verified (Windows)** | 仅 sort (5 tests), 其余 51 因缺少 GNU 工具跳过 |
| **GNU differential verified (Local WSL Ubuntu)** | 本地 WSL 已验证 — 54/56 GNU 对照测试通过，2 个中文用例硬编码跳过 |
| **GNU differential verified (CI Ubuntu)** | ✅ CI verified — CI #7 (`cb3e61e`) Ubuntu job 中 GNU 对照测试通过 |
| **兼容性表述** | "JSON-first agent-friendly subset inspired by GNU Coreutils" |

### CI 状态

| 项目 | 状态 |
|---|---|
| **CI 平台** | GitHub Actions |
| **Ubuntu runner** | ubuntu-latest, Python 3.11/3.12/3.13 |
| **macOS runner** | macos-latest, Python 3.12/3.13 |
| **Windows runner** | windows-latest, Python 3.11/3.12/3.13 |
| **Lint + Typecheck** | ruff check + ruff format --check + mypy --strict, Python 3.13 |
| **CI 测试命令** | `python -m pytest project/tests/ tests/test_version_consistency.py -v --tb=short --cov=src/aicoreutils --cov-fail-under=45` |
| **GNU coreutils** | ✅ Ubuntu job 已安装（`apt-get update && apt-get install coreutils`）; macOS: `brew install coreutils` |
| **最新 CI 结果** | ✅ 11/11 全平台通过 (commit `5c8d941`): lint, typecheck, test-ubuntu (3×Python), test-macos (3×Python), test-windows (3×Python) |
| **本地 WSL CI 入口** | ✅ `.github/scripts/run-ci-wsl.ps1` + `.github/scripts/wsl-ci.sh` |

### 已知未解决问题

| 编号 | 问题 | 优先级 |
|---|---|---|
| K-003 | CI Node.js 20 deprecation 警告 — 需等 GitHub Actions 发布 Node.js 24 版本的 checkout/setup-python | P4 |

### 建议下一步

1. **补充测试覆盖**：为 `async_interface`、`plugins`、`stream` 模块添加单元测试
2. **MCP 安全默认模式**：添加 `--read-only`、`--deny` 禁用列表、tool annotations
3. **状态文档自动化**：让 CI 自动同步动态数字（版本号、测试通过数等）到 CURRENT_STATUS.md

---

## English

> **This is the single authoritative source for current project status.**
> Historical reports are in `docs/reports/`, analysis logs in `docs/analysis/`.

| Property | Value |
|---|---|
| **Last verified** | 2026-05-05 |
| **Verified target** | local working tree (`5c8d941`, pushed and verified by CI 11/11 on all platforms) |
| **Python version** | Windows: 3.14.4; WSL: 3.12.3; CI: 3.11/3.12/3.13 |
| **OS** | Windows 11 (dev) + WSL Ubuntu-24.04 (Ubuntu 24.04.4 LTS), CI: ubuntu-latest + macos-latest + windows-latest |
| **Project version** | 1.1.0 |

### Tests

| Metric | Value |
|---|---|
| **Recommended command** | `python -m pytest project/tests/ -v --tb=short` |
| **Legacy entry** | `python -m unittest discover -s tests -v` (partial runner) |
| **Windows recommended-entry result** | 399 passed, 60 skipped, 0 failed (Python 3.14) |
| **CI all-platform results (latest)** | Ubuntu: 399 passed, 1 skipped; macOS: 399 passed, 60 skipped; Windows: 399 passed, 60 skipped; lint + typecheck ✅ |
| **Windows skip reasons** | No symlink support; locale-dependent Chinese sort/word-count; GNU tools partially available (after choco install) |
| **Property-based** | `python -m pytest project/tests/test_property_based_cli.py -v` (25 tests) |
| **GNU differential** | `python -m pytest project/tests/test_gnu_differential.py -v` (56 tests; Ubuntu CI passes; Windows/macOS skip per platform) |
| **Sandbox escape** | `python -m pytest project/tests/test_sandbox_escape_hardening.py -v` (46 tests, all pass or skip) |
| **Docs governance** | `python -m pytest project/tests/test_docs_governance.py -v` (9 tests, all pass) |
| **Bilingual docs** | `python -m pytest project/tests/test_docs_bilingual.py -v` (1 test, passes) |
| **Version consistency** | `python -m pytest tests/test_version_consistency.py -v` (4 tests, local pass; not yet in CI) |
| **Coverage** | `python -m pytest project/tests/ --cov=src/aicoreutils` (requires pytest-cov; threshold 45%) |
| **Static checks** | `ruff check src/ project/tests/`; `ruff format --check src/ project/tests/`; `mypy src/aicoreutils/ --strict` all pass |
| **CI platform** | GitHub Actions: ubuntu-latest (3.11/3.12/3.13), macos-latest (3.12/3.13), windows-latest (3.11/3.12/3.13) |

### Security Status

| Item | Status |
|---|---|
| **Sandbox escape gaps** | ✅ All 5 known gaps fixed 2026-04-30 |
| **cwd boundary checks** | ✅ All 20 mutating commands validate paths inside cwd (including cp/mv/ln/link/mkdir/touch/chmod/chown/chgrp/shred/mktemp/mkfifo/mknod/rmdir/unlink/csplit/split/nohup) |
| **Symlink escape** | ✅ `resolve_path` resolves then checks; Windows skips (no symlink) |
| **dry-run zero side-effects** | ✅ 20 mutating commands verified |
| **Dangerous command gates** | ✅ shred/kill/nice/nohup/stty/chcon/runcon/chroot require explicit `--allow-*` |
| **MCP security controls** | ✅ `--read-only`/`--allow-command`/`--deny-command` three-tier access |
| **Security model doc** | `docs/reference/SECURITY_MODEL.md` |

### GNU Compatibility Status

| Item | Status |
|---|---|
| **GNU command name coverage** | 109/109 |
| **Agent subset implemented** | All 114 commands (incl. 5 meta-commands: catalog, schema, coreutils, tool-list, hash) |
| **GNU differential verified (Windows)** | sort only (5 tests), 51 skipped (no GNU tools) |
| **GNU differential verified (Local WSL Ubuntu)** | Locally verified in WSL — 54/56 GNU differential tests passed, 2 Chinese cases hard-skipped |
| **GNU differential verified (CI Ubuntu)** | ✅ CI verified — CI #7 (`cb3e61e`) GNU differential tests passed in Ubuntu job |
| **Compatibility description** | "JSON-first agent-friendly subset inspired by GNU Coreutils" |

### CI Status

| Item | Status |
|---|---|
| **CI platform** | GitHub Actions |
| **Ubuntu runner** | ubuntu-latest, Python 3.11/3.12/3.13 |
| **macOS runner** | macos-latest, Python 3.12/3.13 |
| **Windows runner** | windows-latest, Python 3.11/3.12/3.13 |
| **Lint + Typecheck** | ruff check + ruff format --check + mypy --strict, Python 3.13 |
| **CI test command** | `python -m pytest project/tests/ tests/test_version_consistency.py -v --tb=short --cov=src/aicoreutils --cov-fail-under=45` |
| **GNU coreutils** | ✅ Ubuntu: `apt-get update && apt-get install coreutils`; macOS: `brew install coreutils` |
| **Latest CI result** | ✅ 11/11 all platforms pass (commit `5c8d941`): lint, typecheck, test-ubuntu (3×Python), test-macos (3×Python), test-windows (3×Python) |
| **Local WSL CI entry** | ✅ `.github/scripts/run-ci-wsl.ps1` + `.github/scripts/wsl-ci.sh` |

### Known Open Issues

| # | Issue | Priority |
|---|---|---|
| K-003 | CI Node.js 20 deprecation warnings — awaiting GitHub Actions Node.js 24 checkout/setup-python releases | P4 |

### Next Required Actions

1. **Add test coverage**: Unit tests for `async_interface`, `plugins`, `stream` modules
2. **MCP security defaults**: Add `--read-only` mode, `--deny` block list, tool annotations
3. **Status doc automation**: Have CI auto-sync dynamic numbers (version, test counts, etc.) to CURRENT_STATUS.md
