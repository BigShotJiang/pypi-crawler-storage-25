"""Pure domain layer for the Soi Gia SDK."""

from importlib import import_module

from . import common as common

_SUBMODULES = {
    "anki": ".anki",
    "common": ".common",
    "crm": ".crm",
    "obsidian": ".obsidian",
    "purchases": ".purchases",
    "sheets": ".sheets",
    "sales": ".sales",
}
_COMMON_EXPORTS = tuple(getattr(common, "__all__", ()))

__all__ = [*sorted(_SUBMODULES), *_COMMON_EXPORTS]

for _name in _COMMON_EXPORTS:
    globals()[_name] = getattr(common, _name)


def __getattr__(name):
    if name in _SUBMODULES:
        module = import_module(_SUBMODULES[name], __name__)
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(__all__))
