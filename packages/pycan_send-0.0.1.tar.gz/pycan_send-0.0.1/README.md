# pycan-send

[![PyPI - Version](https://img.shields.io/pypi/v/pycan-send.svg)](https://pypi.org/project/pycan-send)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pycan-send.svg)](https://pypi.org/project/pycan-send)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pycan-send
```

## Usage

```console
pycan-send path/to/file.kcd can0 -m MessageName -s SignalName Value
```

`Value` can be numeric or, for signals that define labeled choices in the
KCD, the label name itself (e.g. `-s Mode Active`).

## Fish tab completion

One-shot (current shell only):

```fish
_PYCAN_SEND_COMPLETE=fish_source pycan-send | source
```

Persistent:

```fish
_PYCAN_SEND_COMPLETE=fish_source pycan-send > ~/.config/fish/completions/pycan-send.fish
```

Once enabled, tab completion works for KCD files, message names (`-m <TAB>`
after the KCD path), signal names, and choice labels — all pulled live from
the KCD file given on the command line.

## License

`pycan-send` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
