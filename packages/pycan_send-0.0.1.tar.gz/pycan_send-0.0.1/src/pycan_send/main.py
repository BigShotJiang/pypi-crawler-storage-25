from pathlib import Path

import click
import cantools
import can
from click.shell_completion import CompletionItem


def _kcd_from_ctx(ctx):
    """During shell completion, positional args aren't parsed into
    ctx.params yet — they sit in ctx.args. Check both."""
    kcd = ctx.params.get("kcd_file")
    if kcd:
        return kcd
    for a in ctx.args:
        if a.endswith(".kcd"):
            return a
    return None


def _load_db(ctx):
    kcd = _kcd_from_ctx(ctx)
    if not kcd:
        return None
    kcd = Path(kcd).expanduser()
    try:
        return cantools.database.load_file(str(kcd))
    except Exception:
        return None


def _complete_message(ctx, param, incomplete):
    db = _load_db(ctx)
    if db is None:
        return []
    return [
        CompletionItem(m.name)
        for m in db.messages
        if m.name.startswith(incomplete)
    ]


def _complete_signal(ctx, param, incomplete):
    db = _load_db(ctx)
    if db is None:
        return []
    message = ctx.params.get("message")
    existing = ctx.params.get("signal") or ()

    # Click invokes shell_complete once per tuple element. Determine which
    # element we're completing by the count of already-parsed pairs vs the
    # raw tokens on the command line.
    # Heuristic: if the last existing tuple is incomplete, we're on value.
    # Simpler: inspect the current incomplete position via len of trailing
    # partial. Click passes only the current token as `incomplete`, so use
    # ctx.params to decide: if #signals * 2 tokens already consumed, we're
    # on a name; otherwise on a value.
    # `existing` is a tuple of fully-parsed (name, value) pairs; Click only
    # adds a pair once both tokens are provided. So when shell_complete
    # fires, we're always completing the NAME of the next pair... unless
    # the user is mid-pair. We can't distinguish from ctx alone, so offer
    # both: signal names (always useful) plus — if the previous token on
    # argv was a known signal name — its choice labels.
    if not message:
        return []
    try:
        db_msg = db.get_message_by_name(message)
    except KeyError:
        return []

    items = [
        CompletionItem(s.name)
        for s in db_msg.signals
        if s.name.startswith(incomplete)
    ]

    # Also add choice labels for any signal in the message whose choices
    # start with `incomplete` — this makes value completion work after
    # typing `-s SigName <TAB>`.
    for s in db_msg.signals:
        if not s.choices:
            continue
        for raw_label in s.choices.values():
            label = str(raw_label)
            if label.startswith(incomplete):
                items.append(CompletionItem(label))
    return items


def _complete_kcd(ctx, param, incomplete):
    raw = incomplete or ""
    expanded = Path(raw).expanduser() if raw else Path(".")
    if raw.endswith("/") and expanded.is_dir():
        directory, prefix = expanded, ""
    else:
        directory, prefix = expanded.parent, expanded.name
    if not directory.exists():
        return []

    # Keep the user-visible form (~/foo, ./foo, foo) rather than
    # replacing the token with an absolute path.
    if raw.startswith("~"):
        home = Path.home()

        def display(p: Path) -> str:
            try:
                return "~/" + str(p.relative_to(home))
            except ValueError:
                return str(p)
    else:
        def display(p: Path) -> str:
            return str(p)

    items = []
    for entry in directory.iterdir():
        if not entry.name.startswith(prefix):
            continue
        shown = display(entry)
        if entry.is_dir():
            items.append(CompletionItem(shown + "/", type="plain"))
        elif entry.suffix == ".kcd":
            items.append(CompletionItem(shown))
    return items


def _coerce_signal_value(sig, raw):
    """Accept a numeric string or a choice label and return what cantools
    encode() should receive."""
    try:
        f = float(raw)
        if f.is_integer():
            return int(f)
        return f
    except ValueError:
        pass
    if sig.choices:
        labels = {str(v): k for k, v in sig.choices.items()}
        if raw in labels:
            # cantools encode accepts the label string directly when a
            # signal has choices, so pass it through.
            return raw
    raise click.ClickException(
        f"Value '{raw}' for signal '{sig.name}' is not numeric and is not "
        f"one of the defined labels: "
        f"{', '.join(str(v) for v in sig.choices.values()) if sig.choices else '(none)'}"
    )


@click.command()
@click.argument("KCD-File", type=click.Path(exists=True, dir_okay=False),
                required=True, nargs=1, shell_complete=_complete_kcd)
@click.argument("can-interface", type=str, required=True)
@click.option("-p", "--prefix", required=False, default="0x0", type=str,
              help="A prefixe that is 'ORed' with the message id. This is "
              "useful if there are multiple identical devices on the bus")
@click.option("-m", "--message", required=False, type=str, multiple=False,
              shell_complete=_complete_message)
@click.option("-s", "--signal", required=False, type=(str, str), multiple=True,
              shell_complete=_complete_signal)
def main(kcd_file, can_interface, prefix, message, signal):
    signals = signal
    prefix = int(prefix, 16)
    try:
        can_db = cantools.database.load_file(kcd_file)
    except ValueError as e:
        click.echo(e)
        return

    try:
        db_msg = can_db.get_message_by_name(message)
    except KeyError:
        click.echo(f"The message '{message}' could not be found")
        click.echo("Available messages are:")
        for msg in can_db.messages:
            click.echo(f"    {msg.name}")
        return

    resolved = {}
    for signame, raw in signals:
        try:
            sig = db_msg.get_signal_by_name(signame)
        except KeyError:
            click.echo(f"The message '{message}' does not contain '{signame}'")
            click.echo(f"Available signals in '{message}' are:")
            for s in db_msg.signals:
                click.echo(f"    {s.name}")
            return
        resolved[signame] = _coerce_signal_value(sig, raw)

    try:
        other_signals = {s.name: 0 for s in db_msg.signals if s.name not in resolved}
        encode_input = resolved | other_signals
        data = db_msg.encode(encode_input)
    except OverflowError as err:
        click.echo(str(err))
        exit(-1)

    bus = can.interface.Bus(channel=can_interface, interface="socketcan")
    msg = can.Message(arbitration_id=db_msg.frame_id | prefix, data=data,
                      is_extended_id=True)
    bus.send(msg)
    bus.shutdown()
