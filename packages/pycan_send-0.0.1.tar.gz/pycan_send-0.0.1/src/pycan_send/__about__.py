# SPDX-FileCopyrightText: 2025-present Alexander Becker <nabla.becker@mailbox.org>
#
# SPDX-License-Identifier: GPL-3.0-or-later
__version__ = "0.0.1"
__author__ = "Alexander Becker"
