# SPDX-FileCopyrightText: 2025-present Alexander Becker <nabla.becker@mailbox.org>
#
# SPDX-License-Identifier: MIT
