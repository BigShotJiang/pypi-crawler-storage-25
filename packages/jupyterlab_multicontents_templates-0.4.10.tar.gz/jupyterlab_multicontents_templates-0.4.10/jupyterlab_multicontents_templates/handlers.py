import datetime
import json
import base64
import urllib.parse

import nbformat
import tornado
from jupyter_server.base.handlers import APIHandler, JupyterHandler
from jupyter_server.utils import url_path_join, ensure_async
from multicontents import MultiContentsManager
from nbconvert import HTMLExporter
from traitlets.config import Config


def build_manager(config):
    return


class BaseMixin(object):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        config = self.config.get("JupyterLabMultiContentsTemplates", {}).get(
            "template_folders", {}
        )
        self.manager = MultiContentsManager(
            config=Config({"MultiContentsManager": {"managers": config}})
        )

    def to_json(self, content):
        def convert_dt(obj):
            if isinstance(obj, datetime.datetime):
                return obj.isoformat()

        return json.dumps(content, default=convert_dt)

    def get_notebook(self, path):
        if not self.manager.file_exists(path):
            raise tornado.web.HTTPError(404, reason="File Not Found")
        if path.rsplit(".", 1)[-1].lower() != "ipynb":
            raise tornado.web.HTTPError(400, reason="Not ipynb File")
        return self.manager.get(path, content=True)


class ContentHandler(BaseMixin, APIHandler):
    @tornado.web.authenticated
    async def put(self):
        try:
            data = json.loads(self.request.body)
            path = data.get("path", None)
            nb_content = await ensure_async(
                self.get_notebook(path)
            )
            self.finish(self.to_json(nb_content))
        except Exception as e:
            self.set_status(500)
            self.finish(f'jupyterlab_multicontents_templates: Error: {str(e)}')


class PreviewHandler(BaseMixin, JupyterHandler):
    async def get(self):
        try:
            path = self.get_argument("path")
            html_exporter = HTMLExporter()
            html_exporter.template_name = "classic"

            _nb = await ensure_async(
                self.get_notebook(path)
            )
            notebook_node = nbformat.from_dict(
                _nb.get("content", {})
            )
            html, _ = html_exporter.from_notebook_node(notebook_node)
        except Exception as e:
            self.set_status(500)
            self.finish(f'jupyterlab_multicontents_templates: Error: {str(e)}')

        self.finish(html)


class PublishHandler(BaseMixin, APIHandler):
    async def put(self):
        try:
            data = json.loads(self.request.body)

            notebook = await ensure_async(
                self.contents_manager.get(
                    data["source_path"], type="notebook", content=1
                )
            )

            target_path = data["target_path"]

            output = await ensure_async(
                self.manager.save(notebook, target_path)
            )
            output["path"] = target_path
        except Exception as e:
            self.set_status(500)
            self.finish(f'jupyterlab_multicontents_templates: Error: {str(e)}')

        self.finish({"save": "success", **json.loads(self.to_json(output))})


class ListHandler(BaseMixin, APIHandler):
    async def put(self):
        try:
            data = json.loads(self.request.body)

            path = data.get("path", "")

            result = await ensure_async(
                self.manager.get(path, content=True)
            )

            unsorted_content = [
                item
                for item in result["content"] or []
                if item["type"] in ("notebook", "directory")
            ]

            sort_by_name = self.config.get("JupyterLabMultiContentsTemplates", {}).get(
                "sort_templates_by_name_asc", False
            )

            if sort_by_name and (len(unsorted_content) > 0 and "/" in unsorted_content[0]["path"]):
                # user argument to sort by name and path is within a directory
                sorted_content = sorted(unsorted_content, key=lambda x: x["name"])
                result["content"] = sorted_content
            else:
                # root directory list, create sort object based on user template folder definition
                template_config = self.config.get("JupyterLabMultiContentsTemplates", {}).get(
                    "template_folders", {}
                )
                user_folder_keys = list(template_config.keys())
                user_folder_sort = {}
                for i in range(len(user_folder_keys)):
                    user_folder_sort[user_folder_keys[i]] = i
                result["content"] = sorted(unsorted_content, key=lambda x: user_folder_sort[x["name"]])
        except Exception as e:
            self.set_status(500)
            self.finish(f'jupyterlab_multicontents_templates: Error: {str(e)}')

        self.finish(self.to_json(result))


class ShareURLHandler(APIHandler):
    def put(self):
        data = json.loads(self.request.body)
        path = data.get("path", "")
        append_prefix = self.config.get("JupyterLabMultiContentsTemplates", {}).get(
            "append_hub_user_redirect", False
        )
        url = "/user-redirect/" if append_prefix else "/"
        url += f"?template-preview={urllib.parse.quote(base64.b64encode(path.encode('utf-8')))}"
        self.finish(json.dumps({"path": url}))


class DecodePathHandler(APIHandler):
    def put(self):
        data = json.loads(self.request.body)
        path = data.get("path")
        decoded_path = base64.b64decode(path).decode("utf-8")
        self.finish(json.dumps({"path": decoded_path}))


def setup_handlers(web_app):
    host_pattern = ".*$"

    base_url = url_path_join(
        web_app.settings["base_url"], "jupyterlab_multicontents_templates"
    )
    route_to_handler = {
        "list": ListHandler,
        "preview": PreviewHandler,
        "content": ContentHandler,
        "publish": PublishHandler,
        "share-link": ShareURLHandler,
        "decode-link": DecodePathHandler,
    }
    handlers = [
        (url_path_join(base_url, route), handler)
        for route, handler in route_to_handler.items()
    ]
    web_app.add_handlers(host_pattern, handlers)
