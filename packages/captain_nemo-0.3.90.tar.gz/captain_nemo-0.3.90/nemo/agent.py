"""Main agent loop — event-driven message processing.

Wires together:
- Lark event stream (lark.events) — receives messages via WebSocket 长连接
- Command dispatch (commands) — built-in /clear, /model, etc.
- SDK turn execution (turn) — Claude Agent SDK
- Signal monitoring (monitor) — /esc, handback detection
- Card presentation (cards) — unified turn card
- Permission bridge (permissions) — button card + reaction approval
"""

from __future__ import annotations

import asyncio
import datetime
import logging
import os
import re
import signal
import time
import urllib.error
import uuid

from . import cards, commands, messages, monitor
from .agent_factory import AgentProvider, build_coding_agent, is_model_compatible
from .coding_agent import EndpointConfig
from .channel import IncomingMessage
from .config import load_credentials
from .db import Database
from .lark_channel import LarkChannel
from .turn import AnswerEvent, DoneEvent, ProgressEvent, RateLimitNoticeEvent

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Response helpers
# ---------------------------------------------------------------------------

_INLINE_CODE_RE = re.compile(r"`[^`\n]+`")
_MARKDOWN_LINK_RE = re.compile(r"\[[^\]\n]+\]\([^)]+\)")
_TABLE_LINE_RE = re.compile(r"^\s*\|(?:[^|\n]+\|){1,}.*$")
_NUMBERED_LIST_RE = re.compile(r"\s*\d+[.)]\s+")
_BULLET_LIST_RE = re.compile(r"\s*[-*+]\s+")
_HEADING_RE = re.compile(r"\s{0,3}#{1,6}\s+\S")
_SETEXT_HEADING_UNDERLINE_RE = re.compile(r"\s{0,3}(?:=+|-+)\s*$")
_CONTROL_TAG_RE = re.compile(r"</?[a-zA-Z][^>\n]*>")
_EMPHASIS_RES = (
  re.compile(r"(?<!\*)\*\*[^*\n]+\*\*(?!\*)"),
  re.compile(r"(?<!\*)\*[^*\n]+\*(?!\*)"),
  re.compile(r"(?<!_)__[^_\n]+__(?!_)"),
  re.compile(r"(?<![\w_])_[^_\n]+_(?![\w_])"),
  re.compile(r"~~[^~\n]+~~"),
)


def _should_send_plain_text(text: str) -> bool:
  """Return True only for short, unformatted natural-language replies."""
  stripped = text.strip()
  if not stripped:
    return True

  if len(stripped) > 280:
    return False
  if "```" in stripped:
    return False
  if _INLINE_CODE_RE.search(stripped):
    return False
  if any(regex.search(stripped) for regex in _EMPHASIS_RES):
    return False
  if _MARKDOWN_LINK_RE.search(stripped):
    return False
  if _CONTROL_TAG_RE.search(stripped):
    return False

  lines = stripped.splitlines()
  if len(lines) > 6:
    return False

  non_empty_lines = [line.strip() for line in lines if line.strip()]
  if not non_empty_lines:
    return True

  if any(_HEADING_RE.match(line) for line in non_empty_lines):
    return False
  for prev_line, line in zip(non_empty_lines, non_empty_lines[1:]):
    if prev_line and _SETEXT_HEADING_UNDERLINE_RE.match(line):
      return False
  if any(line.startswith("> ") for line in non_empty_lines):
    return False
  if any(_TABLE_LINE_RE.match(line) for line in non_empty_lines):
    return False
  if "\n\n" in stripped:
    return False

  for line in non_empty_lines:
    if _BULLET_LIST_RE.match(line) or _NUMBERED_LIST_RE.match(line):
      return False

  if len(non_empty_lines) >= 4:
    return False

  return True


def _merge_pending(pending: list[IncomingMessage]) -> IncomingMessage | None:
  """Merge multiple pending messages into a single IncomingMessage.

  Messages collected during a turn are combined so that the coding agent
  receives one turn instead of N separate turns.  A short header tells
  the model how many messages were merged.
  """
  if not pending:
    return None
  if len(pending) == 1:
    return pending[0]

  # Separate regular text messages from non-text (commands, card actions, etc.)
  text_msgs: list[IncomingMessage] = []
  other_msgs: list[IncomingMessage] = []
  for msg in pending:
    if msg.event_type in ("", "message") and msg.text.strip():
      text_msgs.append(msg)
    else:
      other_msgs.append(msg)

  merged: IncomingMessage | None = None
  if text_msgs:
    if len(text_msgs) == 1:
      merged = text_msgs[0]
    else:
      lines = [f"[用户在上一轮工作期间发送了 {len(text_msgs)} 条消息]"]
      for m in text_msgs:
        lines.append(m.text.strip())
      base = text_msgs[0]
      merged = IncomingMessage(
        event_type=base.event_type,
        chat_id=base.chat_id,
        chat_type=base.chat_type,
        sender_id=base.sender_id,
        message_id=text_msgs[-1].message_id,
        msg_type="text",
        text="\n".join(lines),
        mentions=base.mentions,
        create_time=text_msgs[-1].create_time,
        raw=base.raw,
      )

  # Return merged text + any non-text messages that need separate handling
  if other_msgs:
    # Non-text messages (card actions, commands) stay individual
    return merged, other_msgs  # type: ignore[return-value]
  return merged


def _requeue_pending(
  pending: list[IncomingMessage],
  channel: LarkChannel,
) -> None:
  """Merge pending messages and push back into the channel queue."""
  if not pending:
    return
  result = _merge_pending(pending)
  if result is None:
    return
  # _merge_pending returns a tuple when there are non-text messages
  if isinstance(result, tuple):
    merged, others = result
    if merged is not None:
      channel.push_back(merged)
    for msg in others:
      channel.push_back(msg)
  else:
    channel.push_back(result)


async def _send_response(
  channel: LarkChannel, chat_id: str, text: str, db: Database,
) -> str | None:
  text = text.strip()
  if not text:
    return None
  try:
    if _should_send_plain_text(text):
      msg_id = await channel.send_text(chat_id, text)
      log.info("Response sent transport=text chat=%s msg=%s", chat_id, msg_id)
    else:
      card = cards.build_markdown_card(text)
      msg_id = await channel.send_card(chat_id, card)
      log.info("Response sent transport=card chat=%s msg=%s", chat_id, msg_id)
    db.record_sent(msg_id, text=text[:500], chat_id=chat_id)
    _register_msg(msg_id, chat_id)
    return msg_id
  except Exception as e:
    log.error("Send error: %s", e)
    return None


def _register_msg(msg_id: str, chat_id: str) -> None:
  """Register message for reaction routing (relay only, best-effort)."""
  from .config import load_relay_config
  relay_url, _ = load_relay_config()
  if relay_url and msg_id:
    from . import relay as relay_client
    relay_client.register_message(msg_id, chat_id)


def _truncate_for_preview(text: str, limit: int = 2000) -> str:
  """Return text clipped to ``limit`` chars at a line boundary."""
  if len(text) <= limit:
    return text
  return text[:limit].rsplit("\n", 1)[0] + "\n\n_…truncated_"


def _cancel_emoji(elapsed: float) -> str:
  """Pick an emoji based on how long the turn ran before cancellation."""
  if elapsed < 3:
    return "👋"
  if elapsed < 30:
    return "🛑"
  if elapsed < 120:
    return "😮‍💨"
  if elapsed < 300:
    return "💨"
  return "🫠"


def _update_done_card_with_fallback(
  *,
  channel: LarkChannel,
  chat_id: str,
  turn_card_id: str,
  final_text: str,
  thinking,
  elapsed: int,
  usage,
  session_id: str,
  await_channel,
  register_msg,
) -> str:
  """Update the done card with tiered fallback; return the resulting id.

  1. Try the full-body card.
  2. On failure (other than auth-class HTTPError), retry with a truncated
     preview — this recovers transport blips and card-body-too-large alike.
  3. If the preview retry also fails, upload the full text as a .md file
     and update the card with a short preview + "sent as file" note.
  """
  full_card = cards.build_turn_card(
    "done", body=final_text, steps=thinking,
    elapsed=elapsed, usage=usage, session_id=session_id,
  )
  try:
    prev_id = turn_card_id
    turn_card_id = await_channel(channel.update_card(turn_card_id, full_card))
    if turn_card_id != prev_id:
      register_msg(turn_card_id, chat_id)
    return turn_card_id
  except Exception as e:
    log.warning("Failed to update done card: %s", e)
    first_err = e

  # Auth-class HTTP errors won't be fixed by shrinking or uploading a file.
  if (
    isinstance(first_err, urllib.error.HTTPError)
    and first_err.code in (401, 403, 404)
  ) or not final_text:
    return turn_card_id

  preview_body = _truncate_for_preview(final_text)
  preview_card = cards.build_turn_card(
    "done", body=preview_body, steps=thinking,
    elapsed=elapsed, usage=usage, session_id=session_id,
  )
  try:
    prev_id = turn_card_id
    turn_card_id = await_channel(
      channel.update_card(turn_card_id, preview_card))
    if turn_card_id != prev_id:
      register_msg(turn_card_id, chat_id)
    return turn_card_id
  except Exception as e:
    log.warning("Preview card update also failed: %s", e)

  try:
    import tempfile
    file_dir = os.path.join("/tmp/nemo", "nemo-files")
    os.makedirs(file_dir, exist_ok=True)
    fd, overflow_path = tempfile.mkstemp(
      suffix=".md", prefix="nemo-response-", dir=file_dir)
    with os.fdopen(fd, "w") as f:
      f.write(final_text)
    from .lark import api as lark_api
    file_key = lark_api.upload_file(channel.token, overflow_path)
    lark_api.send_file(channel.token, chat_id, file_key)
    log.info("Sent overflow response as file: %s", overflow_path)
    preview = final_text[:500].rsplit("\n", 1)[0]
    preview += f"\n\n_…full response ({len(final_text)} chars) sent as file_"
    fallback_card = cards.build_turn_card(
      "done", body=preview, steps=thinking,
      elapsed=elapsed, usage=usage, session_id=session_id,
    )
    prev_id = turn_card_id
    turn_card_id = await_channel(
      channel.update_card(turn_card_id, fallback_card))
    if turn_card_id != prev_id:
      register_msg(turn_card_id, chat_id)
  except Exception as e:
    log.warning("Failed to send overflow fallback: %s", e)
  return turn_card_id


async def _handle_turn_error(
  message: str,
  exc: Exception,
  channel: LarkChannel,
  chat_id: str,
  db: Database,
  session_id: str,
  card_id: str | None,
  steps: list,
  turn_start: float,
) -> None:
  """Display a red error card for SDK turn errors (timeout, rate limit, etc.)."""
  log.error("Turn error: %s", exc)
  try:
    if card_id:
      elapsed = int(time.time() - turn_start)
      err_card = cards.build_turn_card(
        "error", body=f"**{message}**",
        steps=steps, elapsed=elapsed,
      )
      await channel.update_card(card_id, err_card)
      db.clear_working(session_id)
    else:
      err_card = cards.build_card("Error", body=f"**{message}**", color="red")
      msg_id = await channel.send_card(chat_id, err_card)
      db.record_sent(msg_id, text=message[:500], chat_id=chat_id)
  except Exception as e:
    log.warning("Failed to send error card: %s", e)


async def _handle_diag(
  channel: LarkChannel,
  chat_id: str,
  project_dir: str,
  db: Database,
) -> None:
  """Run diagnostics and send results as a card."""
  results: list[str] = []

  # Check token
  try:
    _ = channel.token  # triggers auto-refresh if expired
    results.append("Token: OK")
  except Exception as e:
    results.append(f"Token: FAIL ({e})")

  # Check send/receive
  try:
    test_card = cards.build_card("Diag", body="test", color="grey")
    msg_id = await channel.send_card(chat_id, test_card)
    if msg_id:
      results.append("Send card: OK")
      try:
        await channel.delete_message(msg_id)
      except Exception as e:
        log.debug("Failed to delete diag test message: %s", e)
    else:
      results.append("Send card: FAIL (no msg_id)")
  except Exception as e:
    results.append(f"Send card: FAIL ({e})")

  # Check workspace tag
  try:
    from .workspace import get_workspace_id
    ws_id = get_workspace_id(project_dir)
    info = await channel.get_chat_info(chat_id)
    desc = info.get("description", "")
    tag = f"workspace:{ws_id}"
    if tag in desc:
      results.append(f"Workspace tag: OK ({ws_id})")
    else:
      results.append(f"Workspace tag: MISSING ({ws_id})")
  except Exception as e:
    results.append(f"Workspace tag: FAIL ({e})")

  body = "\n".join(f"- {r}" for r in results)
  diag_card = cards.build_card("Diagnostics", body=body, color="blue")
  try:
    await channel.send_card(chat_id, diag_card)
  except Exception as e:
    log.error("Failed to send diag card: %s", e)


# When an SDK turn times out the underlying CLI/agent is usually choking on a
# heavy context that's been asked to do too much at once. The next user turn
# gets this preamble so the agent paces itself instead of repeating the
# overrun. One-shot per timeout — cleared on /clear or after one use.
_PACING_HINT_PREFIX = (
  "[Nemo 系统提示] 上一回合超时了——通常是上下文较重、一次想做太多事造成的。"
  "这一回合请放慢节奏：把工作拆成多个小步，每回合只做一步，做完等用户确认再继续，"
  "不要试图一次完成所有事。\n\n"
  "（以下是用户的新消息）\n"
)


def _format_rate_limit_notice(event: RateLimitNoticeEvent) -> str:
  """Render a RateLimitNoticeEvent as a one-line banner string.

  Returns "" when the status is "allowed" (limit cleared) so callers can use
  truthiness to know whether to show or hide the banner.
  """
  status = (event.status or "").lower()
  if status == "allowed":
    return ""

  if status == "rejected":
    head = "⛔ Rate limit hit"
  elif status == "allowed_warning":
    head = "⚠️ Rate limit warning"
  else:
    head = f"Rate limit: {status}" if status else "Rate limit"

  bits = [head]
  if event.rate_limit_type:
    bits.append(f"({event.rate_limit_type})")
  if event.utilization is not None:
    try:
      bits.append(f"{event.utilization * 100:.0f}% used")
    except Exception:
      pass
  if event.resets_at:
    delta = int(event.resets_at - time.time())
    if delta > 0:
      if delta < 60:
        bits.append(f"resets in {delta}s")
      elif delta < 3600:
        # Ceiling so "resets in N min" doesn't visibly tick down by a minute
        # within the first second of being shown.
        mins = -(-delta // 60)
        bits.append(f"resets in {mins}m")
      else:
        h, rem = divmod(delta, 3600)
        mins = -(-rem // 60)
        if mins == 60:
          h += 1
          mins = 0
        bits.append(f"resets in {h}h {mins}m" if mins else f"resets in {h}h")
  return " ".join(bits)


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

async def main_loop(
  chat_id: str,
  project_dir: str,
  model: str,
  provider: AgentProvider = "claude",
  permission_mode: str = "bypassPermissions",
  effort: str = "",
  system_prompt: str = "",
  endpoint: EndpointConfig | None = None,
) -> int:
  """Run the agent main loop."""
  session_id = str(uuid.uuid4())

  credentials = load_credentials()
  if not credentials:
    log.error("No credentials configured")
    return 1

  channel = LarkChannel(chat_id)
  await channel.start()

  # Resolve operator & bot
  operator_open_id = ""
  bot_open_id = ""
  try:
    email = credentials.get("email", "")
    operator_open_id, bot_open_id = await channel.resolve_operator_and_bot(email)
  except Exception as e:
    log.warning("Operator/bot lookup failed: %s", e)

  # Database
  db = Database(project_dir)

  # Let LarkChannel recover quoted-message text from our own DB when the
  # Lark API can't (e.g. interactive cards lose body content on get_message).
  def _db_parent_lookup(mid: str) -> str | None:
    row = db.lookup_parent_message(mid)
    if not row:
      return None
    text = row.get("text")
    return str(text) if text else None

  channel.parent_lookup = _db_parent_lookup

  # Clean stale sessions (preserve sdk_session_id for resume).
  # Per-provider lookup so switching providers on a chat doesn't feed a
  # Claude UUID into Codex (or vice versa) — the right answer is always
  # to start that provider fresh, while leaving the other providers'
  # stored ids intact for when the user switches back.
  _resume_sdk_id = ""
  try:
    old_owner = db.get_chat_owner(chat_id)
    if old_owner:
      _resume_sdk_id = db.get_sdk_session_id(chat_id, provider)
      log.info("Cleaning stale session %s (sdk[%s]=%s)", old_owner,
               provider, _resume_sdk_id[:8] if _resume_sdk_id else "none")
      db.deactivate(old_owner)
  except Exception as e:
    log.warning("Stale cleanup error: %s", e)

  # Ensure workspace tag and claim group
  await channel.ensure_workspace_claimed(project_dir, model)

  # Detect need_mention: nemo-managed groups (with workspace tag) or
  # 1-on-1 groups default to False. Other multi-human groups default to True.
  # Can be overridden via group config.
  from . import group_config as gcfg
  gc = gcfg.load_config(channel.token, chat_id)
  if "need_mention" in gc:
    need_mention = bool(gc["need_mention"])
  else:
    need_mention = True
    try:
      info = await channel.get_chat_info(chat_id)
      desc = str(info.get("description", "") or "")
      if "workspace:" in desc:
        # Nemo-managed group (created by auto_create_chat)
        need_mention = False
      else:
        members = await channel.get_chat_members(chat_id)
        human_count = sum(1 for m in members if m.get("member_id") != bot_open_id)
        if human_count <= 1:
          need_mention = False
    except Exception as e:
      log.warning("Failed to detect need_mention, defaulting to True: %s", e)

  # Activate session
  db.activate(
    session_id, chat_id, model,
    operator_open_id=operator_open_id,
    bot_open_id=bot_open_id,
    need_mention=need_mention,
  )
  log.info("Session %s activated (chat=%s bot=%s operator=%s need_mention=%s)",
           session_id, chat_id, bot_open_id[:16] if bot_open_id else "?",
           operator_open_id[:16] if operator_open_id else "?", need_mention)

  # Send start card
  log.info("Sending start card to %s", chat_id)
  from nemo import __version__
  folder = os.path.basename(project_dir) or project_dir
  start_lines = [f"📂 `{folder}`  ·  pid `{os.getpid()}`"]
  if _resume_sdk_id:
    start_lines.append(f"Session `{_resume_sdk_id[:8]}` resumed")
  start_note = project_dir
  start_card = cards.build_card(
    f"Nemo v{__version__} ({provider} · {model})",
    body="\n".join(start_lines),
    color="blue",
    note=start_note,
  )
  try:
    msg_id = await channel.send_card(chat_id, start_card)
    log.info("Start card sent: %s", msg_id)
  except Exception as e:
    log.error("Start card failed: %s", e)
    err_msg = str(e)
    if "230002" in err_msg or "NOT be out of the chat" in err_msg:
      return 1

  # Status tab — green idle, with provider name next to the dot.
  await channel.update_status(model, "idle", provider)

  # Periodic heartbeat (relay-based idle detection)
  _heartbeat_task: asyncio.Task | None = None
  from .config import load_relay_config
  relay_url, _ = load_relay_config()
  if relay_url:
    async def _heartbeat_loop():
      while True:
        await asyncio.sleep(30)
        await channel.send_heartbeat(model)

    _heartbeat_task = asyncio.create_task(_heartbeat_loop())

  agent = build_coding_agent(
    provider,
    credentials, chat_id, db, channel,
    permission_mode=permission_mode,
    system_prompt=system_prompt,
    endpoint=endpoint,
  )
  if effort:
    agent.set_effort(effort)
  # Resume previous SDK session if available
  _sdk_session_id: str = _resume_sdk_id
  if _sdk_session_id:
    log.info("Resuming SDK session %s", _sdk_session_id[:8])
  try:
    await agent.start(project_dir, model, resume=_sdk_session_id)
  except Exception as e:
    log.error("SDK startup failed: %s", e)
    err_card = cards.build_card(
      "Error", body=f"Startup failed:\n```\n{e}\n```", color="red"
    )
    try:
      await channel.send_card(chat_id, err_card)
    except Exception as send_err:
      log.warning("Failed to send SDK startup error card: %s", send_err)
    # Structural startup failures (missing CLI / sidecar / credentials) do
    # not recover by retrying later turns. Exit so a supervisor can
    # restart us cleanly rather than stay in a half-alive zombie state
    # where every user message produces another obscure error.
    raise

  # Context
  ctx = commands.AgentContext(model, project_dir, time.time())
  ctx.provider = provider
  ctx.effort = effort
  main_loop_ref = asyncio.get_running_loop()
  running = True
  _dissolve_on_exit = False
  # One-shot flag: prepend a pacing hint to the next user prompt after an
  # SDK timeout. Cleared after use or on /clear.
  _pending_pacing_hint = False

  def handle_sig(_sig, _frame):
    nonlocal running
    running = False
    channel.push_back(IncomingMessage())

  signal.signal(signal.SIGINT, handle_sig)
  signal.signal(signal.SIGTERM, handle_sig)

  async def _restart_client(resume: str = ""):
    await agent.reset(project_dir, model, resume=resume)

  # Load guest/coowner roles for authorization
  from .guests import get_member_roles
  _member_roles: dict[str, str] = {}
  try:
    _member_roles = get_member_roles(channel.token, chat_id)
  except Exception as e:
    log.warning("Failed to load member roles: %s", e)

  # ---- Main loop: event-driven ----
  while running:
    try:
      reply = await channel.receive(timeout=300)
      if reply is None:
        continue  # Timeout, keep waiting

      log.info("Event: type=%s chat=%s sender=%s text=%r",
               reply.event_type, reply.chat_id[:16] if reply.chat_id else "?",
               reply.sender_id[:16] if reply.sender_id else "?",
               reply.text[:60] if reply.text else "")

      # Skip card action events at top level (handled during turns)
      if reply.event_type == "card.action.trigger":
        log.info("Ignoring card action outside turn: %s", reply.action_value)
        continue

      # Skip recall events at top level (handled during turns)
      if reply.event_type == "im.message.recalled_v1":
        continue

      # Scope to this session's chat (WebSocket receives all chats)
      if reply.chat_id and reply.chat_id != chat_id:
        log.debug("Skipping: wrong chat %s (expected %s)", reply.chat_id, chat_id)
        continue

      # Ignore sticker messages
      if getattr(reply, "msg_type", "") == "sticker":
        continue

      # Filter
      sender = reply.sender_id
      if bot_open_id and sender == bot_open_id:
        log.debug("Skipping: own message from bot %s", sender)
        continue  # Skip own messages
      from .guests import is_authorized_sender
      if operator_open_id and not is_authorized_sender(
          sender, operator_open_id, _member_roles):
        log.info("Skipping: unauthorized sender %s (operator=%s)", sender, operator_open_id)
        continue

      # need_mention mode: only respond to @mentions and interactions
      # directed at nemo's own messages (text reply or emoji reaction).
      # Slash commands must also be @-directed. Replying to *other*
      # people's messages (quoting a teammate's card while @-ing
      # another teammate) is not considered bot-directed.
      if need_mention and bot_open_id:
        def _is_own_message(mid: str) -> bool:
          row = db.lookup_parent_message(mid)
          return bool(row and row.get("direction") == "sent")
        kept = messages.filter_bot_interactions(
          [reply], bot_open_id, is_own_message=_is_own_message)
        if not kept:
          log.info("Skipping: need_mention on, not bot-directed "
                   "(event=%s parent=%s mentions=%s)",
                   reply.event_type,
                   reply.parent_id[:16] if reply.parent_id else "",
                   [m.get("id","")[:10] for m in reply.mentions])
          continue

      text = reply.text.strip()
      if not text:
        log.debug("Skipping: empty text")
        continue

      # Strip @-mention markers
      user_message = messages.strip_mentions(text, [reply], bot_open_id=bot_open_id)
      if not user_message:
        log.debug("Skipping: empty after stripping mentions")
        continue

      # Acknowledge receipt with THINKING reaction
      ack_msg_id = reply.message_id
      ack_reaction_id = await channel.add_reaction(ack_msg_id, "THINKING")
      db.record_received(
        chat_id=chat_id, text=text,
        source_message_id=reply.message_id,
        message_time=reply.create_time,
      )

      async def _clear_ack():
        nonlocal ack_reaction_id
        if ack_reaction_id and ack_msg_id:
          await channel.remove_reaction(ack_msg_id, ack_reaction_id)
          ack_reaction_id = ""

      # Command dispatch — strip the parent-quote tail first, otherwise
      # slash commands in topic chats (where every message carries a
      # root_id) never match because the enriched text looks like
      # "/mention\n\n(The user is replying…)".
      handled, response = commands.try_dispatch(
        messages.strip_parent_quote(user_message), ctx)
      if handled:
        if response == "__clear__":
          t = datetime.datetime.now().strftime("%H:%M")
          card = cards.build_card("🔄 Session Cleared",
                                  body=f"Context reset at {t}.", color="orange")
          msg_id = await channel.send_card(chat_id, card)
          db.record_sent(msg_id, text="Session Cleared", chat_id=chat_id)
          _register_msg(msg_id, chat_id)
          log.info("Session cleared card sent: %s", msg_id)
          await _restart_client()
          _pending_pacing_hint = False
        elif response == "__esc__":
          elapsed = time.time() - _turn_start
          await _send_response(channel, chat_id, f"{_cancel_emoji(elapsed)} Operation cancelled.", db)
        elif response and response.startswith("__model__:"):
          new_model = response.split(":", 1)[1]
          # Resolve against the preset registry first. A preset name
          # expands to (endpoint, remote model id) — switching to one
          # also flips the SDK env vars on the next reconnect, so the
          # daemon can move between e.g. claude-opus-4-7 (real
          # Anthropic) and deepseek-v4-pro (DeepSeek's Anthropic
          # endpoint) on the same chat without restart.
          from .presets import resolve_preset
          preset = resolve_preset(new_model)
          if preset is not None:
            if not preset.supports(provider):
              await _send_response(
                channel, chat_id,
                f"Preset **{new_model}** has no endpoint for "
                f"provider **{provider}**.",
                db,
              )
              await _clear_ack()
              continue
            if preset.api_key_env and not os.environ.get(preset.api_key_env):
              await _send_response(
                channel, chat_id,
                f"Preset **{new_model}** requires `${preset.api_key_env}` "
                f"in the daemon's environment.",
                db,
              )
              await _clear_ack()
              continue
            agent.set_endpoint(preset.endpoint_for(provider))
            switched_to = preset.remote_for(provider)
            log.info("Model switch to preset %s → %s (resume=%s)",
                     preset.name, switched_to,
                     _sdk_session_id[:8] if _sdk_session_id else "none")
            model = switched_to
            ctx.model = model
            await _restart_client(resume=_sdk_session_id)
            await channel.update_status(model, "idle", provider)
            await _send_response(
              channel, chat_id,
              f"Model switched to preset **{preset.name}** "
              f"(remote: `{switched_to}`).",
              db,
            )
            continue
          if not is_model_compatible(provider, new_model):
            await _send_response(
              channel,
              chat_id,
              f"Model **{new_model}** is not supported by provider **{provider}**.",
              db,
            )
            await _clear_ack()
            continue
          # Plain model swap. Clear any preset endpoint that was active
          # so we go back to the provider's default auth path.
          agent.set_endpoint(EndpointConfig())
          model = new_model
          ctx.model = model
          log.info("Model switch to %s (resume=%s)", model, _sdk_session_id[:8] if _sdk_session_id else "none")
          await _restart_client(resume=_sdk_session_id)
          await channel.update_status(model, "idle", provider)
          await _send_response(channel, chat_id, f"Model switched to **{model}**.", db)
        elif response and response.startswith("__provider__:"):
          # Format: "__provider__:<name>:<default_model>"
          _, new_provider, default_model = response.split(":", 2)
          # Stop the old adapter cleanly so its subprocesses / threads
          # release before we build the replacement.
          try:
            await agent.stop()
          except Exception as exc:
            log.warning("Stopping %s agent on /provider switch: %s",
                        provider, exc)
          # Reset state to the new provider's defaults. Endpoint goes
          # back to empty (no preset assumed) and model is the
          # provider's default — the user can /model afterwards if
          # they want a non-default. Each provider's resume id lives
          # in its own DB column (per-provider session storage), so
          # switching back later resumes that provider's last thread.
          provider = new_provider  # type: ignore[assignment]
          model = default_model
          endpoint = EndpointConfig()
          ctx.provider = provider
          ctx.model = model
          _sdk_session_id = db.get_sdk_session_id(chat_id, provider)
          agent = build_coding_agent(
            provider, credentials, chat_id, db, channel,
            permission_mode=permission_mode,
            system_prompt=system_prompt,
            endpoint=endpoint,
          )
          if ctx.effort:
            agent.set_effort(ctx.effort)
          log.info("Provider switch to %s (model=%s, resume=%s)",
                   provider, model,
                   _sdk_session_id[:8] if _sdk_session_id else "none")
          try:
            await agent.start(project_dir, model, resume=_sdk_session_id)
          except Exception as exc:
            log.error("Failed to start %s agent: %s", provider, exc, exc_info=True)
            await _send_response(
              channel, chat_id,
              f"Provider switch to **{provider}** failed: `{exc}`. "
              f"Daemon is in a broken state — restart it.",
              db,
            )
            await _clear_ack()
            continue
          await channel.update_status(model, "idle", provider)
          await _send_response(
            channel, chat_id,
            f"Switched to provider **{provider}** "
            f"(default model `{model}`). Use `/model <name>` to pick "
            f"a different one.",
            db,
          )
        elif response and response.startswith("__effort__:"):
          new_effort = response.split(":", 1)[1]
          ctx.effort = new_effort
          agent.set_effort(new_effort)
          label = new_effort if new_effort else "default"
          detail_map = commands._EFFORT_DETAIL.get(provider, {})
          detail = detail_map.get(new_effort, "")
          hint = f" — {detail}" if detail else ""
          log.info("Reasoning effort set to %s — restarting client (resume=%s)",
                   label, _sdk_session_id[:8] if _sdk_session_id else "none")
          # Effort lives on SDK options for native-effort backends (Claude),
          # so we must rebuild options + reconnect for the change to apply.
          # Codex/OpenCode reset is essentially free.
          await _restart_client(resume=_sdk_session_id)
          await _send_response(channel, chat_id, f"Reasoning effort: **{label}**{hint}.", db)
        elif response and response.startswith("__cd__:"):
          new_dir = response.split(":", 1)[1]
          project_dir = new_dir
          ctx.project_dir = project_dir
          await _restart_client()
          await channel.update_workspace_tag(project_dir)
          await _send_response(channel, chat_id, f"Working directory: **{project_dir}**", db)
        elif response == "__autoapprove_toggle__":
          sess = db.get_session(session_id) or {}
          enabled = not bool(sess.get("autoapprove"))
          db.set_autoapprove(chat_id, enabled)
          await _send_response(
            channel, chat_id,
            f"Auto-approve **{'enabled' if enabled else 'disabled'}**.", db)
        elif response and response.startswith("__autoapprove__:"):
          enabled = response.endswith(":on")
          db.set_autoapprove(chat_id, enabled)
          await _send_response(
            channel, chat_id,
            f"Auto-approve **{'enabled' if enabled else 'disabled'}**.", db)
        elif response == "__mention_toggle__":
          need_mention = not need_mention
          _gc = gcfg.load_config(channel.token, chat_id)
          _gc["need_mention"] = need_mention
          gcfg.save_config(channel.token, chat_id, _gc)
          await _send_response(
            channel, chat_id,
            f"@mention requirement **{'on' if need_mention else 'off'}**.", db)
        elif response and response.startswith("__mention__:"):
          need_mention = response.endswith(":on")
          _gc = gcfg.load_config(channel.token, chat_id)
          _gc["need_mention"] = need_mention
          gcfg.save_config(channel.token, chat_id, _gc)
          await _send_response(
            channel, chat_id,
            f"@mention requirement **{'on' if need_mention else 'off'}**.", db)
        elif response == "__norm_list__":
          from .norms import get_norms, format_norms_prompt
          norms = get_norms(channel.token, chat_id)
          if norms:
            lines = [f"**Group Norms**\n"]
            for name, text in norms.items():
              lines.append(f"- **{name}**: {text}")
            await _send_response(channel, chat_id, "\n".join(lines), db)
          else:
            await _send_response(channel, chat_id, "No norms configured.", db)
        elif response and response.startswith("__norm_add__:"):
          from .norms import add_norm
          _, rest = response.split(":", 1)
          name, text = rest.split(":", 1)
          add_norm(channel.token, chat_id, name, text)
          await _send_response(channel, chat_id, f"Norm **{name}** added.", db)
        elif response and response.startswith("__norm_remove__:"):
          from .norms import remove_norm
          name = response.split(":", 1)[1]
          if remove_norm(channel.token, chat_id, name):
            await _send_response(channel, chat_id, f"Norm **{name}** removed.", db)
          else:
            await _send_response(channel, chat_id, f"Norm **{name}** not found.", db)
        elif response == "__guest_list__":
          from .guests import list_guests
          guests = list_guests(channel.token, chat_id)
          if guests:
            lines = ["**Guests**\n"]
            for g in guests:
              role = g.get("role", "guest")
              name = g.get("name", g.get("open_id", "?")[:16])
              lines.append(f"- **{name}** ({role})")
            await _send_response(channel, chat_id, "\n".join(lines), db)
          else:
            await _send_response(channel, chat_id, "No guests configured.", db)
        elif response and response.startswith("__guest_add_all__:"):
          from .guests import add_guest
          role = response.split(":", 1)[1]
          added: list[str] = []
          try:
            members = await channel.get_chat_members(chat_id)
            for m in members:
              mid = str(m.get("member_id", ""))
              mname = str(m.get("name", "")) or mid[:16]
              if not mid:
                continue
              if mid == operator_open_id:
                continue  # skip the owner/operator
              if mid == bot_open_id:
                continue  # skip the bot
              add_guest(channel.token, chat_id, mid, name=mname, role=role)
              added.append(mname)
            _member_roles = get_member_roles(channel.token, chat_id)
          except Exception as e:
            log.warning("Failed to batch-add guests: %s", e)
            await _send_response(channel, chat_id, f"Batch add failed: {e}", db)
          if added:
            lines = [f"Added **{len(added)}** members as **{role}**:"]
            lines.extend(f"- {n}" for n in added)
            await _send_response(channel, chat_id, "\n".join(lines), db)
          else:
            await _send_response(channel, chat_id, "No members to add.", db)
        elif response and response.startswith("__guest_add__:"):
          from .guests import add_guest
          _, rest = response.split(":", 1)
          role, name = rest.split(":", 1)
          # Resolve name to open_id by searching chat members
          open_id = ""
          try:
            members = await channel.get_chat_members(chat_id)
            for m in members:
              mname = str(m.get("name", ""))
              if mname.lower() == name.lower():
                open_id = str(m.get("member_id", ""))
                name = mname  # Use canonical name
                break
          except Exception as e:
            log.warning("Failed to get chat members for guest add: %s", e)
          if open_id:
            add_guest(channel.token, chat_id, open_id, name=name, role=role)
            _member_roles = get_member_roles(channel.token, chat_id)
            await _send_response(channel, chat_id, f"Added **{name}** as **{role}**.", db)
          else:
            await _send_response(channel, chat_id, f"Could not find **{name}** in this group.", db)
        elif response and response.startswith("__guest_remove__:"):
          from .guests import remove_guest, list_guests as _lg
          name = response.split(":", 1)[1]
          # Find open_id by name
          guests = _lg(channel.token, chat_id)
          target = next((g for g in guests if g.get("name", "").lower() == name.lower()), None)
          if target:
            remove_guest(channel.token, chat_id, target["open_id"])
            _member_roles = get_member_roles(channel.token, chat_id)
            await _send_response(channel, chat_id, f"Removed **{name}**.", db)
          else:
            await _send_response(channel, chat_id, f"Guest **{name}** not found.", db)
        elif response and response.startswith("__name__:"):
          new_name = response.split(":", 1)[1]
          try:
            from .lark import api as lark_api
            lark_api.update_chat_info(channel.token, chat_id, {"name": new_name})
            await _send_response(channel, chat_id, f"Renamed to **{new_name}**.", db)
          except Exception as e:
            await _send_response(channel, chat_id, f"Rename failed: {e}", db)
        elif response == "__diag__":
          await _handle_diag(channel, chat_id, project_dir, db)
        elif response == "__exit__":
          end_card = cards.build_card("Nemo — Stopped", body="Agent stopped.", color="blue")
          await channel.send_card(chat_id, end_card)
          running = False
          break
        elif response == "__dissolve__":
          end_card = cards.build_card("Nemo — Dissolved", body="Agent stopped. Group will be dissolved.", color="red")
          await channel.send_card(chat_id, end_card)
          _dissolve_on_exit = True
          running = False
          break
        elif response:
          await _send_response(channel, chat_id, response, db)
        await _clear_ack()
        continue

      # --- Run SDK turn ---
      log.info("Processing: %s", user_message[:80])
      ctx.msg_count += 1

      # Turn state
      _turn_card_id: str | None = None
      _turn_steps: list[cards.ThinkingStep] = []
      _turn_start = time.time()
      _turn_current_tool = ""
      _turn_interrupt_phase: str | None = None
      # Latest rendered rate-limit notice for this turn. Persists on the
      # working card and is appended to the timeout error if the turn dies.
      _turn_rate_limit_notice = ""

      async def _update_interrupt_card(phase: str) -> None:
        nonlocal _turn_card_id, _turn_interrupt_phase
        if not _turn_card_id:
          return
        _turn_interrupt_phase = phase
        try:
          card = cards.build_turn_card(
            phase,
            steps=_turn_steps,
            current_tool=_turn_current_tool,
            elapsed=int(time.time() - _turn_start),
            rate_limit_notice=_turn_rate_limit_notice,
          )
          prev_id = _turn_card_id
          _turn_card_id = await channel.update_card(_turn_card_id, card)
          if _turn_card_id != prev_id:
            _register_msg(_turn_card_id, chat_id)
        except Exception as e:
          log.warning("Failed to update interrupt card: %s", e)

      def _await_channel(coro):
        return asyncio.run_coroutine_threadsafe(coro, main_loop_ref).result()

      def _on_event(event):
        # Thread safety: this runs on the SDK thread. It mutates _turn_card_id,
        # _turn_steps. The main loop only reads these AFTER
        # asyncio.wait({sdk_task, ...}) completes, which guarantees all
        # _on_event calls have finished. No lock needed.
        nonlocal _turn_card_id, _sdk_session_id, _turn_current_tool
        nonlocal _turn_rate_limit_notice

        def _ensure_card():
          """Create working card if it doesn't exist yet."""
          nonlocal _turn_card_id
          if _turn_card_id:
            return
          _await_channel(_clear_ack())
          card = cards.build_turn_card("working", chat_id=chat_id)
          try:
            _turn_card_id = _await_channel(channel.send_card(chat_id, card))
            db.set_working(session_id, _turn_card_id)
            _register_msg(_turn_card_id, chat_id)
          except Exception as e:
            log.error("Working card error: %s", e)

        def _update_working(**kwargs):
          """Update the working card with current state."""
          nonlocal _turn_card_id
          if not _turn_card_id or _turn_interrupt_phase:
            return
          elapsed = int(time.time() - _turn_start)
          card = cards.build_turn_card(
            "working",
            steps=_turn_steps,
            elapsed=elapsed,
            chat_id=chat_id,
            rate_limit_notice=_turn_rate_limit_notice,
            **kwargs,
          )
          try:
            prev_id = _turn_card_id
            _turn_card_id = _await_channel(channel.update_card(_turn_card_id, card))
            if _turn_card_id != prev_id:
              _register_msg(_turn_card_id, chat_id)
          except Exception as e:
            log.debug("Failed to update working card: %s", e)

        if isinstance(event, ProgressEvent):
          _turn_steps.append(cards.ThinkingStep(event.kind, event.summary))
          _turn_current_tool = event.summary if event.kind == "tool" else _turn_current_tool
          if event.first:
            _ensure_card()
          _update_working(current_tool=_turn_current_tool if event.kind == "tool" else None)

        elif isinstance(event, AnswerEvent):
          _turn_steps.append(cards.ThinkingStep("answer", event.text))
          # Don't create card for text-only responses — let them go as
          # plain text messages. Only update if card already exists.
          _update_working()

        elif isinstance(event, RateLimitNoticeEvent):
          new_notice = _format_rate_limit_notice(event)
          if new_notice == _turn_rate_limit_notice:
            return
          _turn_rate_limit_notice = new_notice
          # Surface upstream rate-limit pressure even when the turn hasn't
          # produced any visible work yet — that silence is exactly what we
          # want to explain.
          _ensure_card()
          _update_working()

        elif isinstance(event, DoneEvent):
          _await_channel(_clear_ack())
          if event.session_id:
            _sdk_session_id = event.session_id
            db.set_sdk_session_id(chat_id, _sdk_session_id, provider)
          if _turn_interrupt_phase:
            if _turn_card_id:
              db.clear_working(session_id)
            return
          elapsed = int(time.time() - _turn_start)
          # Final response = last answer step (if any)
          answer_steps = [s for s in _turn_steps if s.kind == "answer"]
          final_text = answer_steps[-1].content if answer_steps else ""
          # Ask the active coding agent for any provider-specific note to tack
          # onto the response (e.g. Claude warns when the session jsonl is
          # getting large so the user remembers to /clear).
          if final_text:
            trailing = agent.trailing_note(_sdk_session_id)
            if trailing:
              final_text = final_text + trailing
          # Thinking timeline = all non-answer steps
          thinking = [s for s in _turn_steps if s.kind != "answer"]
          if _turn_card_id:
            _turn_card_id = _update_done_card_with_fallback(
              channel=channel,
              chat_id=chat_id,
              turn_card_id=_turn_card_id,
              final_text=final_text,
              thinking=thinking,
              elapsed=elapsed,
              usage=event.usage,
              session_id=_sdk_session_id,
              await_channel=_await_channel,
              register_msg=_register_msg,
            )
            db.clear_working(session_id)
            if final_text:
              db.record_sent(_turn_card_id, text=final_text[:500], chat_id=chat_id)
          else:
            # Pure text response with no tools and no card created
            if final_text:
              _await_channel(_send_response(channel, chat_id, final_text, db))
          ctx.total_cost += event.cost

      if _pending_pacing_hint:
        log.info("Prepending pacing hint after prior timeout")
        prompt_for_agent = _PACING_HINT_PREFIX + user_message
        _pending_pacing_hint = False
      else:
        prompt_for_agent = user_message
      sdk_task = asyncio.create_task(
        agent.run_turn(prompt_for_agent, _on_event)
      )

      # Concurrent signal watcher: read events during SDK execution
      signal_detected = None

      _pending_msgs: list = []
      _pending_ack_msg_id: str = ""
      _pending_ack_reaction_id: str = ""

      async def _dispatch_inline(response: str | None, msg: IncomingMessage) -> None:
        """Handle an inline-safe command during an active turn."""
        nonlocal need_mention
        try:
          # Remove THINKING reaction from the command message
          if msg.message_id:
            await channel.add_reaction(msg.message_id, "DONE")

          if response == "__autoapprove_toggle__":
            cur = db.get_session(db._session_id) or {}
            enabled = not bool(cur.get("autoapprove"))
            db.set_autoapprove(chat_id, enabled)
            await _send_response(
              channel, chat_id,
              f"Auto-approve **{'enabled' if enabled else 'disabled'}**.", db)
          elif response and response.startswith("__autoapprove__:"):
            enabled = response.endswith(":on")
            db.set_autoapprove(chat_id, enabled)
            await _send_response(
              channel, chat_id,
              f"Auto-approve **{'enabled' if enabled else 'disabled'}**.", db)
          elif response == "__mention_toggle__":
            need_mention = not need_mention
            _gc = gcfg.load_config(channel.token, chat_id)
            _gc["need_mention"] = need_mention
            gcfg.save_config(channel.token, chat_id, _gc)
            await _send_response(
              channel, chat_id,
              f"@mention requirement **{'on' if need_mention else 'off'}**.", db)
          elif response and response.startswith("__mention__:"):
            need_mention = response.endswith(":on")
            _gc = gcfg.load_config(channel.token, chat_id)
            _gc["need_mention"] = need_mention
            gcfg.save_config(channel.token, chat_id, _gc)
            await _send_response(
              channel, chat_id,
              f"@mention requirement **{'on' if need_mention else 'off'}**.", db)
          elif response == "__norm_list__":
            from .norms import get_norms
            norms = get_norms(channel.token, chat_id)
            if norms:
              lines = ["**Group Norms**\n"]
              for name, text in norms.items():
                lines.append(f"- **{name}**: {text}")
              await _send_response(channel, chat_id, "\n".join(lines), db)
            else:
              await _send_response(channel, chat_id, "No norms configured.", db)
          elif response and response.startswith("__norm_add__:"):
            from .norms import add_norm
            _, rest = response.split(":", 1)
            name, text = rest.split(":", 1)
            add_norm(channel.token, chat_id, name, text)
            await _send_response(channel, chat_id, f"Norm **{name}** added.", db)
          elif response and response.startswith("__norm_remove__:"):
            from .norms import remove_norm
            name = response.split(":", 1)[1]
            if remove_norm(channel.token, chat_id, name):
              await _send_response(channel, chat_id, f"Norm **{name}** removed.", db)
            else:
              await _send_response(channel, chat_id, f"Norm **{name}** not found.", db)
          elif response and response.startswith("__name__:"):
            new_name = response.split(":", 1)[1]
            try:
              from .lark import api as lark_api
              lark_api.update_chat_info(channel.token, chat_id, {"name": new_name})
              await _send_response(channel, chat_id, f"Renamed to **{new_name}**.", db)
            except Exception as e:
              await _send_response(channel, chat_id, f"Rename failed: {e}", db)
          elif response == "__diag__":
            await _handle_diag(channel, chat_id, project_dir, db)
          elif response and response.startswith("__effort__:"):
            new_effort = response.split(":", 1)[1]
            ctx.effort = new_effort
            agent.set_effort(new_effort)
            label = new_effort if new_effort else "default"
            detail_map = commands._EFFORT_DETAIL.get(provider, {})
            detail = detail_map.get(new_effort, "")
            hint = f" — {detail}" if detail else ""
            await _restart_client(resume=_sdk_session_id)
            await _send_response(channel, chat_id, f"Reasoning effort: **{label}**{hint}.", db)
          elif response:
            # Text responses: /ping, /cost, /help, /usage, /guest help, /norm help
            await _send_response(channel, chat_id, response, db)
        except Exception as e:
          log.warning("Inline command error: %s", e)

      async def _ack_pending(msg: IncomingMessage) -> None:
        """Move the OneSecond reaction to the latest pending message."""
        nonlocal _pending_ack_msg_id, _pending_ack_reaction_id
        # Remove from previous message
        if _pending_ack_msg_id and _pending_ack_reaction_id:
          try:
            await channel.remove_reaction(
              _pending_ack_msg_id, _pending_ack_reaction_id)
          except Exception:
            pass
          _pending_ack_msg_id = ""
          _pending_ack_reaction_id = ""
        # Add to new message
        if msg.message_id:
          try:
            _pending_ack_reaction_id = await channel.add_reaction(
              msg.message_id, "OneSecond")
            _pending_ack_msg_id = msg.message_id
          except Exception as exc:
            log.warning("Failed to ack pending message: %s", exc)

      async def _clear_pending_ack() -> None:
        """Remove the OneSecond reaction (before THINKING replaces it)."""
        nonlocal _pending_ack_msg_id, _pending_ack_reaction_id
        if _pending_ack_msg_id and _pending_ack_reaction_id:
          try:
            await channel.remove_reaction(
              _pending_ack_msg_id, _pending_ack_reaction_id)
          except Exception:
            pass
          _pending_ack_msg_id = ""
          _pending_ack_reaction_id = ""

      async def _watch_signals():
        nonlocal signal_detected
        while not sdk_task.done():
          # If permission handler is reading the queue, yield to it
          if channel.permission_active:
            await asyncio.sleep(0.2)
            continue
          msg = await channel.receive(timeout=5)
          if msg is None:
            continue
          # Double-check: if permission became active while we waited,
          # push back the message so permission handler can read it
          if channel.permission_active:
            channel.push_back(msg)
            await asyncio.sleep(0.1)
            continue
          # Scope to this session's chat
          if msg.chat_id and msg.chat_id != chat_id:
            continue
          # Handle message recall: remove from pending queue
          if msg.event_type == "im.message.recalled_v1":
            recalled_id = msg.message_id
            before = len(_pending_msgs)
            _pending_msgs[:] = [
              m for m in _pending_msgs if m.message_id != recalled_id
            ]
            if len(_pending_msgs) < before:
              log.info("Recalled message %s removed from pending queue", recalled_id)
              # Update OneSecond ack to the new last pending message
              if _pending_msgs:
                await _ack_pending(_pending_msgs[-1])
              else:
                await _clear_pending_ack()
            continue
          # Handle Stop button card action (check authorization)
          if msg.event_type == "card.action.trigger":
            action = msg.action_value.get("action", "")
            # Relay-originated stop signals are already authenticated by the relay.
            # Raw "__stop__" actions should still require operator authorization.
            if action == "stop":
              signal_detected = "stop"
              return
            if action == "__stop__" and monitor.is_privileged(
                msg.operator_id, operator_open_id, _member_roles):
              signal_detected = "stop"
              return
            continue
          msg_text = msg.text
          mentions = msg.mentions
          if monitor.is_esc(msg_text, mentions):
            signal_detected = "esc"
            return
          if monitor.is_dissolve(msg_text, mentions):
            signal_detected = "dissolve"
            return
          if monitor.is_exit(msg_text, mentions):
            signal_detected = "exit"
            return
          # Inline-safe commands: execute during turn without waiting
          stripped = messages.strip_mentions(msg_text, [msg], bot_open_id=bot_open_id)
          if stripped:
            handled, response = commands.try_dispatch(
              messages.strip_parent_quote(stripped), ctx)
            if handled and commands.is_inline_safe(response):
              await _dispatch_inline(response, msg)
              continue
            elif handled:
              # Needs SDK restart — re-queue for after turn
              _pending_msgs.append(msg)
              await _ack_pending(msg)
              continue
          # Re-queue non-signal messages so they aren't lost
          _pending_msgs.append(msg)
          await _ack_pending(msg)

      watcher = asyncio.create_task(_watch_signals())

      done_tasks, _ = await asyncio.wait(
        {sdk_task, watcher},
        return_when=asyncio.FIRST_COMPLETED,
      )

      if watcher in done_tasks and signal_detected:
        if signal_detected in ("esc", "stop"):
          log.info("Stop signal received — interrupting SDK")
          await _clear_ack()
          await _update_interrupt_card("stopping")
          try:
            await agent.interrupt()
            await asyncio.wait_for(sdk_task, timeout=10)
            log.info("SDK turn interrupted cleanly")
          except Exception as exc:
            log.warning("SDK interrupt failed (%s), cancelling task", exc)
            sdk_task.cancel()
          elapsed = time.time() - _turn_start
          await _send_response(channel, chat_id, f"{_cancel_emoji(elapsed)} Operation cancelled.", db)
          await _update_interrupt_card("stopped")

        elif signal_detected in ("exit", "dissolve"):
          await _clear_ack()
          try:
            await agent.interrupt()
            await asyncio.wait_for(sdk_task, timeout=10)
          except Exception:
            sdk_task.cancel()
          if signal_detected == "dissolve":
            end_card = cards.build_card("Nemo — Dissolved",
                                        body="Agent stopped. Group will be dissolved.", color="red")
            _dissolve_on_exit = True
          else:
            end_card = cards.build_card("Nemo — Stopped", body="Agent stopped.", color="blue")
          await channel.send_card(chat_id, end_card)
          running = False
          break
      else:
        # SDK finished, cancel watcher
        watcher.cancel()
        try:
          await watcher
        except asyncio.CancelledError:
          pass  # expected on watcher cancel
        # Check for errors from run_turn (timeout, rate limit, SDK errors)
        try:
          sdk_task.result()
        except TimeoutError as exc:
          msg = "Timed out — SDK stopped responding. Context preserved, send another message to continue."
          if _turn_rate_limit_notice:
            msg = f"{msg}\n\n{_turn_rate_limit_notice}"
          await _handle_turn_error(
            msg, exc, channel, chat_id, db, session_id,
            _turn_card_id, _turn_steps, _turn_start,
          )
          _pending_pacing_hint = True
          await _clear_ack()
          await _clear_pending_ack()
          _requeue_pending(_pending_msgs, channel)
          continue
        except Exception as exc:
          await _handle_turn_error(
            str(exc), exc, channel, chat_id, db, session_id,
            _turn_card_id, _turn_steps, _turn_start,
          )
          await _clear_ack()
          await _clear_pending_ack()
          _requeue_pending(_pending_msgs, channel)
          continue

      # Re-queue any messages consumed during the turn
      await _clear_pending_ack()
      _requeue_pending(_pending_msgs, channel)

    except KeyboardInterrupt:
      running = False
    except asyncio.CancelledError:
      log.warning("Loop cancelled (CancelledError)")
      running = False
    except Exception as e:
      log.error("Loop error: %s", e)
      try:
        err_card = cards.build_card("Error", body=f"```\n{str(e)[:500]}\n```", color="red")
        msg_id = await channel.send_card(chat_id, err_card)
        db.record_sent(msg_id, text=str(e)[:500], chat_id=chat_id)
      except Exception as e2:
        log.warning("Failed to send loop error card: %s", e2)
      await asyncio.sleep(5)

  # Cleanup — all threads are daemon, so fire-and-forget is safe.
  if _heartbeat_task:
    _heartbeat_task.cancel()
    try:
      await _heartbeat_task
    except asyncio.CancelledError:
      pass  # expected on shutdown cancel
  # Close SDK, event stream, and Lark API calls all concurrently
  loop = asyncio.get_event_loop()
  cleanup: list = [agent.stop(), channel.stop()]
  cleanup.append(channel.release_workspace())
  cleanup.append(channel.update_status(model, "stopped", provider))
  await asyncio.gather(*cleanup, return_exceptions=True)
  db.deactivate(session_id)
  db.close()
  if _dissolve_on_exit:
    try:
      await channel.dissolve_chat()
      log.info("Dissolved group %s", chat_id)
    except Exception as e:
      log.warning("Failed to dissolve group: %s", e)
  log.info("Agent stopped.")
  return 0
