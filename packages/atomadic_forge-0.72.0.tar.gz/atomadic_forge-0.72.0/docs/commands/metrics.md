# `atomadic-forge metrics`

_Emit forge_metrics.json — canonical metrics for README/CHANGELOG/welcome/worker._

- **Module**: `atomadic_forge.commands.metrics`
- **Surface**: `typer_app`
- **Source root**: `atomadic_forge_seed`
- **Hidden**: `False`

