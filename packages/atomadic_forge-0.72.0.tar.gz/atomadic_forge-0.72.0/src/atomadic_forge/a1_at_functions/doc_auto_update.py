"""Tier a1 — auto-doc update: regenerate doc sections from structured data.

Zero LLM tokens.  Reads forge_metrics.json, inspects MCP enum lists and CLI
command decorators, then rewrites bounded sections in README.md, CHANGELOG.md,
docs/IDE_INTEGRATION.md, WHITEPAPER.md, and docs/AGENTS_GUIDE.md
programmatically.  Every value is derived from live code or the metrics artifact
— no human-authored prose is touched.

Updateable sections
-------------------
README.md
  • "By the Numbers" table  (bounded by METRICS_START / METRICS_END anchors)
  • "## MCP Server — N Tools, M Actions" heading
  • Tool-table rows for ``explore`` and ``audit`` (action counts)
  • "**N CLI verbs total.**" count

CHANGELOG.md
  • Prepends a new ``## vX.Y.Z — YYYY-MM-DD — …`` block when the current
    package version is not yet the first entry.  Falls back gracefully if
    git is unavailable.

docs/IDE_INTEGRATION.md
  • "**NN tools dispatching NN actions**" pattern in MCP section description.

WHITEPAPER.md
  • All ``NN MCP tools dispatching NN actions`` occurrences.
  • All ``NN passing tests`` occurrences.

docs/AGENTS_GUIDE.md
  • Summary table rows matching ``| explore | NN actions |`` pattern (if present).

Pure: no subprocess unless git is requested.  No writes when dry_run=True.
"""
from __future__ import annotations

import json
import re
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

SCHEMA_VERSION_DOC_AUTO_UPDATE_V1 = "atomadic-forge.doc_auto_update/v1"

# ── README anchors ────────────────────────────────────────────────────────────
_METRICS_START = "| Metric | Value |"
_METRICS_SEP = "|--------|-------|"
_METRICS_END = "\nForge eats its own cooking."

_MCP_HEADER_RE = re.compile(r"## MCP Server — \d+ Tools, \d+ Actions")
_CLI_COUNT_RE = re.compile(r"\*\*(\d+) CLI verbs total\.\*\*")
_EXPLORE_ROW_RE = re.compile(r"(\| `explore` \| )(\d+)( \|)")
_AUDIT_ROW_RE = re.compile(r"(\| `audit` \| )(\d+)( \|)")

# ── CHANGELOG anchor ──────────────────────────────────────────────────────────
_CHANGELOG_UNRELEASED = "## Unreleased"
_CHANGELOG_VER_RE = re.compile(r"^## v(\d+\.\d+\.\d+)", re.MULTILINE)

# ── Extended-doc regexes ───────────────────────────────────────────────────────
# IDE_INTEGRATION.md: matches "**NN tools**" or "**NN tools dispatching NN actions**"
_IDE_TOOLS_RE = re.compile(r'\*\*\d+ tools(?:\s+dispatching\s+\d+\s+actions)?\*\*')

# WHITEPAPER.md: matches "NN MCP tools [word] dispatching NN actions" (optional mid-word)
_WP_TOOLS_PHRASE_RE = re.compile(r'(\d+) MCP tools(?:\s+\w+)? dispatching (\d+) actions')
# WHITEPAPER.md: matches "NN,NNN passing tests" or "NN passing tests"
_WP_TESTS_RE = re.compile(r'([\d,]+) passing tests')

# AGENTS_GUIDE.md: matches "| explore | NN actions |" style rows
_AG_EXPLORE_RE = re.compile(r'(\|\s*`?explore`?\s*\|\s*)(\d+)(\s*actions?\s*\|)',
                             re.IGNORECASE)
# AGENTS_GUIDE.md: matches "## The NN MCP tools" headings
_AG_HEADING_TOOLS_RE = re.compile(r'(## The )\d+( MCP tools)')

# Drift detection: broad number-before-keyword patterns
_DRIFT_TOOLS_RE = re.compile(r'(\d+)\s+MCP\s+tools')
_DRIFT_ACTIONS_RE = re.compile(r'dispatching\s+(\d+)\s+actions')
_DRIFT_TESTS_RE = re.compile(r'([\d,]+)\s+passing\s+tests')


# ── helpers ───────────────────────────────────────────────────────────────────

def _load_metrics(project_root: Path) -> dict[str, Any]:
    """Load forge_metrics.json and normalize to a flat key surface.

    The metrics schema evolved from a flat dict (``mcp_tools``,
    ``cli_verbs``, ``tests_passing``) to a nested shape produced by
    ``scripts/update_metrics.py`` (``{"version": ..., "metrics": {...}}``
    with renamed keys like ``mcp_tool_count`` and ``cli_verb_count``).

    This loader handles both schemas so doc-update keeps working as the
    metrics generator evolves. Closes GAP-011 root cause (silent schema
    drift between metrics writer and doc-update reader).
    """
    path = project_root / "forge_metrics.json"
    if not path.exists():
        return {}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

    # If nested under "metrics", pull the inner dict up to the top level.
    flat: dict[str, Any] = {}
    if isinstance(raw.get("metrics"), dict):
        flat.update(raw["metrics"])
    flat.update({k: v for k, v in raw.items() if k != "metrics"})

    # Provide both old and new field names so existing readers keep working.
    aliases: dict[str, list[str]] = {
        "mcp_tools": ["mcp_tool_count"],
        "mcp_actions": ["mcp_action_count"],
        "cli_verbs": ["cli_verb_count"],
        "tests_passing": ["test_count"],
        "test_functions": ["test_count"],
        "test_files": ["test_file_count"],
        "source_files": ["source_file_count"],
        "source_lines": ["source_line_count"],
        "lean_theorems": ["lean4_theorem_count"],
        "package_version": ["version"],
    }
    for old, new_keys in aliases.items():
        if old in flat:
            continue
        for nk in new_keys:
            if nk in flat:
                flat[old] = flat[nk]
                break

    # mcp_actions is computed live (parser scans mcp_protocol.py) — but
    # also surface a sum from per-tool counts if available, so older
    # readers that only check `metrics["mcp_actions"]` still work.
    if "mcp_actions" not in flat:
        proto = project_root / "src" / "atomadic_forge" / "a1_at_functions" / "mcp_protocol.py"
        if proto.exists():
            counts = _count_mcp_actions_per_tool(project_root)
            if counts:
                flat["mcp_actions"] = sum(counts.values())

    return flat


def _count_mcp_actions_per_tool(project_root: Path) -> dict[str, int]:
    """Parse enum lists in mcp_protocol.py to count actions per tool.

    Anchors each enum to its tool name in the TOOLS dict so counts are
    correct even when audit grows larger than explore.
    """
    proto = project_root / "src" / "atomadic_forge" / "a1_at_functions" / "mcp_protocol.py"
    if not proto.exists():
        return {}
    text = proto.read_text(encoding="utf-8", errors="replace")

    result: dict[str, int] = {}
    # Match: "toolname": { ... "enum": [ items ] }  — non-greedy, anchored by name.
    for tool in ("explore", "audit", "plan", "transmute", "loop", "hive", "wisdom"):
        pat = re.compile(
            rf'"{re.escape(tool)}".*?"enum":\s*\[([^\]]+)\]',
            re.DOTALL,
        )
        m = pat.search(text)
        if m:
            items = [s.strip().strip('"') for s in m.group(1).split(",")
                     if s.strip().strip('"')]
            if len(items) > 2:
                result[tool] = len(items)
    return result


def _count_cli_verbs(project_root: Path) -> int:
    """Count @app.command decorators in cli.py."""
    cli = project_root / "src" / "atomadic_forge" / "a4_sy_orchestration" / "cli.py"
    if not cli.exists():
        return 0
    text = cli.read_text(encoding="utf-8", errors="replace")
    return len(re.findall(r'@app\.command\(', text))


def _git_log_since(project_root: Path, since_ref: str) -> list[str]:
    """Return one-line git log entries since since_ref."""
    try:
        result = subprocess.run(
            ["git", "log", "--oneline", f"v{since_ref}..HEAD"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return [ln for ln in result.stdout.splitlines() if ln.strip()]
    except (OSError, subprocess.TimeoutExpired):
        pass
    return []


def _build_metrics_table(metrics: dict[str, Any]) -> str:
    """Rebuild the "By the Numbers" table rows from metrics.

    Tolerant to both the legacy flat schema (``mcp_tools``, ``cli_verbs``,
    ``test_functions``, ``lean_theorems`` dict) and the current nested
    schema flattened by ``_load_metrics`` (``mcp_tool_count``,
    ``cli_verb_count``, ``test_count``, ``lean4_theorem_count`` int).
    """
    mcp_tools = metrics.get("mcp_tools", metrics.get("mcp_tool_count", "?"))
    mcp_actions = metrics.get("mcp_actions", "?")
    cli_verbs = metrics.get("cli_verbs", metrics.get("cli_verb_count", "?"))
    source_files = metrics.get("source_files",
                                metrics.get("source_file_count", "?"))
    source_lines = metrics.get("source_lines",
                                metrics.get("source_line_count", 0))
    test_functions = metrics.get("test_functions",
                                  metrics.get("test_count", "?"))
    test_files = metrics.get("test_files", "?")

    # Lean count: dict (old) or int (new flat / new nested).
    lean_raw = metrics.get("lean_theorems")
    lean_count: int = 0
    lean_files: int = 0
    if isinstance(lean_raw, dict):
        lean_count = int(lean_raw.get("count") or 0)
        lean_files = int(lean_raw.get("files") or 0)
    elif isinstance(lean_raw, int):
        lean_count = lean_raw
    else:
        # New nested schema — pulled via alias by _load_metrics.
        v = metrics.get("lean4_theorem_count")
        if isinstance(v, int):
            lean_count = v
    monadic_tiers = metrics.get("monadic_tiers", 5)

    loc_k = f"~{source_lines // 1000:,}K" if source_lines else "?"
    lean_row = (
        f"**{lean_count} theorems** "
        + (f"across {lean_files} files " if lean_files else "")
        + "(mathematically verified core logic)"
        if lean_count else "not yet active"
    )

    rows = [
        f"| MCP tools | **{mcp_tools} tools · {mcp_actions} actions** |",
        f"| CLI verbs | **{cli_verbs}** |",
        f"| Source files | **{source_files}** ({loc_k} LOC) |",
        f"| Tests | **{test_functions} passing** across **{test_files} test files** |",
        f"| Lean4 formal proofs | {lean_row} |",
        f"| Monadic tiers | **{monadic_tiers}** (a0 → a4, strict upward-only composition) |",
        "| Languages | Python, JS/TS, Swift, Kotlin, Go, Rust |",
        "| Infrastructure cost | **$5/mo** |",
        "| Self-score | **100/100** certify · 0 wire violations |",
        "| License | BSL 1.1 (Apache 2.0 after 2030-04-27) |",
    ]
    return "\n".join(rows)


def _build_changelog_block(version: str, log_lines: list[str]) -> str:
    """Generate a CHANGELOG section for the given version."""
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    items = "\n".join(f"- {line}" for line in log_lines[:20]) if log_lines else "- (see git log)"
    return (
        f"## v{version} — {today}\n\n"
        f"### Changed\n\n"
        f"{items}\n"
    )


# ── section updaters ──────────────────────────────────────────────────────────

def update_readme(
    project_root: Path,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Rewrite the bounded sections of README.md from live metrics."""
    readme_path = project_root / "README.md"
    if not readme_path.exists():
        return {"available": False, "reason": "README.md not found"}

    metrics = _load_metrics(project_root)
    if not metrics:
        return {"available": False, "reason": "forge_metrics.json not found or empty"}

    text = readme_path.read_text(encoding="utf-8")
    changes: list[str] = []

    # 1. By the Numbers table
    start_idx = text.find(_METRICS_START)
    end_idx = text.find(_METRICS_END)
    if start_idx != -1 and end_idx != -1:
        sep_idx = text.find(_METRICS_SEP, start_idx)
        if sep_idx != -1:
            table_body_start = sep_idx + len(_METRICS_SEP) + 1  # after \n
            new_rows = _build_metrics_table(metrics)
            old_body = text[table_body_start:end_idx]
            new_body = "\n" + new_rows + "\n"
            if old_body != new_body:
                text = text[:table_body_start] + new_body + text[end_idx:]
                changes.append("README: By the Numbers table updated")

    # 2. MCP Server heading
    mcp_tools = metrics.get("mcp_tools", "?")
    mcp_actions = metrics.get("mcp_actions", "?")
    new_header = f"## MCP Server — {mcp_tools} Tools, {mcp_actions} Actions"
    new_text, n = _MCP_HEADER_RE.subn(new_header, text)
    if n:
        text = new_text
        changes.append("README: MCP Server heading updated")

    # 3. explore / audit action counts in tool table
    action_counts = _count_mcp_actions_per_tool(project_root)
    if "explore" in action_counts:
        new_text, n = _EXPLORE_ROW_RE.subn(
            lambda m: m.group(1) + str(action_counts["explore"]) + m.group(3), text
        )
        if n:
            text = new_text
            changes.append(f"README: explore action count → {action_counts['explore']}")
    if "audit" in action_counts:
        new_text, n = _AUDIT_ROW_RE.subn(
            lambda m: m.group(1) + str(action_counts["audit"]) + m.group(3), text
        )
        if n:
            text = new_text
            changes.append(f"README: audit action count → {action_counts['audit']}")

    # 4. CLI verb count
    cli_verbs = metrics.get("cli_verbs", 0)
    new_text, n = _CLI_COUNT_RE.subn(f"**{cli_verbs} CLI verbs total.**", text)
    if n:
        text = new_text
        changes.append(f"README: CLI verb count → {cli_verbs}")

    if not dry_run and changes:
        readme_path.write_text(text, encoding="utf-8")

    return {
        "schema_version": SCHEMA_VERSION_DOC_AUTO_UPDATE_V1,
        "available": True,
        "file": "README.md",
        "changes": changes,
        "dry_run": dry_run,
    }


def update_changelog(
    project_root: Path,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Prepend a new version block to CHANGELOG.md if current version is undocumented."""
    metrics = _load_metrics(project_root)
    version = metrics.get("package_version", "")
    if not version:
        return {"available": False, "reason": "package_version not in forge_metrics.json"}

    changelog_path = project_root / "CHANGELOG.md"
    if not changelog_path.exists():
        return {"available": False, "reason": "CHANGELOG.md not found"}

    text = changelog_path.read_text(encoding="utf-8")

    # Check if this version already has an entry
    existing = _CHANGELOG_VER_RE.findall(text)
    if existing and existing[0] == version:
        return {
            "schema_version": SCHEMA_VERSION_DOC_AUTO_UPDATE_V1,
            "available": True,
            "file": "CHANGELOG.md",
            "changes": [],
            "reason": f"v{version} already documented",
            "dry_run": dry_run,
        }

    # Find the previous version for git log range
    prev_version = existing[0] if existing else ""
    log_lines = _git_log_since(project_root, prev_version) if prev_version else []

    new_block = _build_changelog_block(version, log_lines)

    # Insert after "## Unreleased" line (or at top after "# Changelog")
    unreleased_idx = text.find(_CHANGELOG_UNRELEASED)
    if unreleased_idx != -1:
        insert_at = unreleased_idx + len(_CHANGELOG_UNRELEASED) + 1
    else:
        # After "# Changelog\n"
        header_end = text.find("\n") + 1
        insert_at = header_end

    new_text = text[:insert_at] + "\n" + new_block + "\n" + text[insert_at:]

    if not dry_run:
        changelog_path.write_text(new_text, encoding="utf-8")

    return {
        "schema_version": SCHEMA_VERSION_DOC_AUTO_UPDATE_V1,
        "available": True,
        "file": "CHANGELOG.md",
        "changes": [f"Prepended v{version} block ({len(log_lines)} git entries)"],
        "dry_run": dry_run,
    }


# ── extended-doc updaters ─────────────────────────────────────────────────────

def update_extended_docs(
    project_root: Path,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Rewrite MCP tool/action/test counts in IDE_INTEGRATION.md, WHITEPAPER.md,
    and docs/AGENTS_GUIDE.md from live forge_metrics.json values.

    Returns a dict with ``schema_version``, ``available``, ``changes``, and
    ``dry_run`` matching the shape of :func:`update_readme`.
    """
    metrics = _load_metrics(project_root)
    if not metrics:
        return {
            "schema_version": SCHEMA_VERSION_DOC_AUTO_UPDATE_V1,
            "available": False,
            "reason": "forge_metrics.json not found or empty",
            "changes": [],
            "dry_run": dry_run,
        }

    mcp_tools = metrics.get("mcp_tools", "?")
    mcp_actions = metrics.get("mcp_actions", "?")
    test_functions = metrics.get("test_functions", "?")
    changes: list[str] = []
    warnings: list[str] = []

    # ── 1. IDE_INTEGRATION.md ─────────────────────────────────────────────────
    ide_path = project_root / "docs" / "IDE_INTEGRATION.md"
    if ide_path.exists():
        ide_text = ide_path.read_text(encoding="utf-8")
        new_label = f"**{mcp_tools} tools dispatching {mcp_actions} actions**"
        new_ide, n = _IDE_TOOLS_RE.subn(new_label, ide_text)
        if n and new_ide != ide_text:
            if not dry_run:
                ide_path.write_text(new_ide, encoding="utf-8")
            changes.append(
                f"IDE_INTEGRATION.md: tools/actions → {mcp_tools} tools dispatching "
                f"{mcp_actions} actions ({n} occurrence(s))"
            )
        elif n == 0:
            warnings.append("IDE_INTEGRATION.md: tools pattern matched 0 — format may have changed")

    # ── 2. WHITEPAPER.md ──────────────────────────────────────────────────────
    wp_path = project_root / "WHITEPAPER.md"
    if wp_path.exists():
        wp_text = wp_path.read_text(encoding="utf-8")
        new_phrase = f"{mcp_tools} MCP tools dispatching {mcp_actions} actions"
        new_wp, n_tools = _WP_TOOLS_PHRASE_RE.subn(new_phrase, wp_text)
        if n_tools and new_wp != wp_text:
            wp_text = new_wp
            changes.append(
                f"WHITEPAPER.md: MCP tools phrase → {new_phrase} ({n_tools} occurrence(s))"
            )
        elif n_tools == 0:
            warnings.append("WHITEPAPER.md: MCP-tools-phrase pattern matched 0 — format may have changed")
        new_wp2, n_tests = _WP_TESTS_RE.subn(
            lambda m: f"{test_functions} passing tests", wp_text
        )
        if n_tests and new_wp2 != wp_text:
            wp_text = new_wp2
            changes.append(
                f"WHITEPAPER.md: passing tests → {test_functions} ({n_tests} occurrence(s))"
            )
        elif n_tests == 0:
            warnings.append("WHITEPAPER.md: passing-tests pattern matched 0 — format may have changed")
        if any("WHITEPAPER" in c for c in changes) and not dry_run:
            wp_path.write_text(wp_text, encoding="utf-8")

    # ── 3. docs/AGENTS_GUIDE.md ───────────────────────────────────────────────
    ag_path = project_root / "docs" / "AGENTS_GUIDE.md"
    if ag_path.exists():
        ag_text = ag_path.read_text(encoding="utf-8")
        new_ag, n_ag = _AG_EXPLORE_RE.subn(
            lambda m: m.group(1) + str(mcp_actions) + m.group(3), ag_text
        )
        if n_ag and new_ag != ag_text:
            changes.append(
                f"AGENTS_GUIDE.md: explore actions → {mcp_actions} ({n_ag} occurrence(s))"
            )
            ag_text = new_ag
        new_ag2, n_heading = _AG_HEADING_TOOLS_RE.subn(
            lambda m: m.group(1) + str(mcp_tools) + m.group(2), ag_text
        )
        if n_heading and new_ag2 != ag_text:
            changes.append(
                f"AGENTS_GUIDE.md: heading tool count → {mcp_tools} ({n_heading} occurrence(s))"
            )
            ag_text = new_ag2
        if any("AGENTS_GUIDE" in c for c in changes) and not dry_run:
            ag_path.write_text(ag_text, encoding="utf-8")

    return {
        "schema_version": SCHEMA_VERSION_DOC_AUTO_UPDATE_V1,
        "available": True,
        "changes": changes,
        "warnings": warnings,
        "dry_run": dry_run,
    }


# ── drift detector ────────────────────────────────────────────────────────────

def detect_doc_drift(project_root: Path) -> dict[str, Any]:
    """Scan key doc files for stale MCP tool/action/test counts.

    Reads forge_metrics.json then checks README.md, WHITEPAPER.md,
    docs/IDE_INTEGRATION.md, and docs/AGENTS_GUIDE.md for numbers that no
    longer match the live metrics.

    Returns::

        {
            "schema_version": ...,
            "available": True,
            "mcp_tools": <int>,
            "mcp_actions": <int>,
            "test_functions": <int>,
            "drift_items": [
                {"file": str, "line": int, "pattern": str,
                 "found_value": int, "expected_value": int},
                ...
            ],
            "drift_count": <int>,
        }
    """
    metrics = _load_metrics(project_root)
    if not metrics:
        return {
            "schema_version": SCHEMA_VERSION_DOC_AUTO_UPDATE_V1,
            "available": False,
            "reason": "forge_metrics.json not found or empty",
        }

    mcp_tools = int(metrics.get("mcp_tools", 0))
    mcp_actions = int(metrics.get("mcp_actions", 0))
    test_functions = int(metrics.get("test_functions", 0))

    doc_files = [
        project_root / "README.md",
        project_root / "WHITEPAPER.md",
        project_root / "docs" / "IDE_INTEGRATION.md",
        project_root / "docs" / "AGENTS_GUIDE.md",
    ]

    drift_items: list[dict[str, Any]] = []

    for doc_path in doc_files:
        if not doc_path.exists():
            continue
        rel = str(doc_path.relative_to(project_root))
        lines = doc_path.read_text(encoding="utf-8").splitlines()
        for lineno, line in enumerate(lines, start=1):
            for m in _DRIFT_TOOLS_RE.finditer(line):
                found = int(m.group(1))
                if found != mcp_tools:
                    drift_items.append({
                        "file": rel, "line": lineno, "pattern": "MCP tools",
                        "found_value": found, "expected_value": mcp_tools,
                    })
            for m in _DRIFT_ACTIONS_RE.finditer(line):
                found = int(m.group(1))
                if found != mcp_actions:
                    drift_items.append({
                        "file": rel, "line": lineno, "pattern": "dispatching actions",
                        "found_value": found, "expected_value": mcp_actions,
                    })
            for m in _DRIFT_TESTS_RE.finditer(line):
                found = int(m.group(1).replace(",", ""))
                if found != test_functions:
                    drift_items.append({
                        "file": rel, "line": lineno, "pattern": "passing tests",
                        "found_value": found, "expected_value": test_functions,
                    })

    return {
        "schema_version": SCHEMA_VERSION_DOC_AUTO_UPDATE_V1,
        "available": True,
        "mcp_tools": mcp_tools,
        "mcp_actions": mcp_actions,
        "test_functions": test_functions,
        "drift_items": drift_items,
        "drift_count": len(drift_items),
    }


# ── main entry point ──────────────────────────────────────────────────────────

def run_doc_auto_update(
    project_root: Path,
    *,
    sections: tuple[str, ...] = ("readme", "changelog", "extended_docs"),
    dry_run: bool = False,
) -> dict[str, Any]:
    """Run all doc auto-update passes.

    Args:
        project_root: Repository root.
        sections: Which sections to update — any combination of
                  ``"readme"``, ``"changelog"``, and ``"extended_docs"``.
                  Defaults to all three.  ``"extended_docs"`` patches
                  IDE_INTEGRATION.md, WHITEPAPER.md, and AGENTS_GUIDE.md.
        dry_run: If True, return what would change without writing.

    Returns dict with ``schema_version``, ``results`` per section,
    aggregate ``total_changes`` count, and ``post_drift`` residual check.
    """
    root = Path(project_root).resolve()
    results: dict[str, Any] = {}
    total = 0

    if "readme" in sections:
        r = update_readme(root, dry_run=dry_run)
        results["readme"] = r
        total += len(r.get("changes", []))

    if "changelog" in sections:
        r = update_changelog(root, dry_run=dry_run)
        results["changelog"] = r
        total += len(r.get("changes", []))

    if "extended_docs" in sections:
        r = update_extended_docs(root, dry_run=dry_run)
        results["extended_docs"] = r
        total += len(r.get("changes", []))

    # Self-verify: residual drift after all writes confirms every pattern fired.
    post_drift = detect_doc_drift(root) if not dry_run else {"drift_count": 0}

    return {
        "schema_version": SCHEMA_VERSION_DOC_AUTO_UPDATE_V1,
        "available": True,
        "dry_run": dry_run,
        "total_changes": total,
        "results": results,
        "post_drift": post_drift,
    }
