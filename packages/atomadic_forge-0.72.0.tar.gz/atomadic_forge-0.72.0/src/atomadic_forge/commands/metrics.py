"""``atomadic-forge metrics`` — emit / refresh the canonical forge_metrics.json.

Single source of truth for every public number Forge claims about itself —
mcp tool count, action count, CLI verb count, source/test files, lines of
code, Lean theorem count from the IP-protected proof corpus. Public surfaces (README, CHANGELOG,
welcome handshake, the Cloudflare Worker, shields.io badges) all read from
this artifact.

Usage::

    forge metrics                    # print live metrics, do not write
    forge metrics --apply            # rewrite forge_metrics.json at repo root
    forge metrics --json             # JSON to stdout (no file write)
    forge metrics --proof-corpus <path>   # override proof corpus auto-detect
    forge metrics --self-cert        # also embed certify score (slower)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from atomadic_forge.a3_og_features.forge_metrics_feature import emit_forge_metrics


def _live_cli_verb_count() -> int:
    """a4-side helper: count registered CLI verbs from the live Typer app.

    Lives here (a4) instead of a3 because the metrics feature must not
    import the CLI module — that would be an upward tier import.
    """
    try:
        from atomadic_forge.a4_sy_orchestration import cli as _cli
        commands = getattr(_cli.app, "registered_commands", []) or []
        groups = getattr(_cli.app, "registered_groups", []) or []
        return len(commands) + len(groups)
    except Exception:
        return 0

COMMAND_NAME = "metrics"
COMMAND_HELP = (
    "Emit forge_metrics.json — canonical metrics for README/CHANGELOG/welcome/worker."
)

app = typer.Typer(
    no_args_is_help=False, help=COMMAND_HELP, invoke_without_command=True,
)


@app.callback()
def run(
    apply: Annotated[bool, typer.Option(
        "--apply",
        help="Overwrite <repo_root>/forge_metrics.json with the freshly computed artifact.",
    )] = False,
    json_out: Annotated[bool, typer.Option(
        "--json",
        help="Emit the artifact to stdout as JSON (no human-readable summary).",
    )] = False,
    mhed: Annotated[Path | None, typer.Option(
        "--proof-corpus",
        help="Override proof corpus location (default: autodetect).",
        exists=False, file_okay=False, dir_okay=True, resolve_path=True,
    )] = None,
    self_cert: Annotated[bool, typer.Option(
        "--self-cert",
        help="Embed latest certify score (slower; runs the full pipeline).",
    )] = False,
    tests_passing: Annotated[int | None, typer.Option(
        "--tests-passing",
        help="Embed an externally-computed pytest pass count "
             "(from the most recent CI run).",
    )] = None,
    project: Annotated[Path, typer.Option(
        "--project",
        help="Forge repo root (default: cwd).",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
    )] = Path("."),
) -> None:
    """Compute live forge metrics and optionally write forge_metrics.json."""
    res = emit_forge_metrics(
        project,
        apply=apply,
        proof_corpus_root=mhed,
        skip_self_cert=not self_cert,
        cli_verbs_count=_live_cli_verb_count(),
        tests_passing=tests_passing,
    )
    if json_out:
        typer.echo(json.dumps(res["metrics"], indent=2, sort_keys=True))
        return
    m = res["metrics"]
    typer.echo(f"forge_metrics — generated_at_utc={m['generated_at_utc']}")
    if "package_version" in m:
        typer.echo(f"  package_version       : {m['package_version']}")
    typer.echo(f"  monadic_tiers         : {m['monadic_tiers']}")
    if "mcp_tools" in m:
        typer.echo(f"  mcp_tools             : {m['mcp_tools']}")
    if "mcp_actions" in m:
        typer.echo(f"  mcp_actions           : {m['mcp_actions']}")
    if "cli_verbs" in m:
        typer.echo(f"  cli_verbs             : {m['cli_verbs']}")
    typer.echo(f"  source_files          : {m['source_files']}")
    typer.echo(f"  source_lines          : {m['source_lines']}")
    typer.echo(f"  test_files            : {m['test_files']}")
    if "test_functions" in m:
        typer.echo(f"  test_functions        : {m['test_functions']}")
    if "self_certify_score" in m:
        typer.echo(f"  self_certify_score    : {m['self_certify_score']}")
    if "self_wire_violations" in m:
        typer.echo(f"  self_wire_violations  : {m['self_wire_violations']}")
    lean = m["lean_theorems"]
    if lean["found"]:
        typer.echo(f"  lean_theorems.count   : {lean['count']} "
                    f"(theorems={lean['theorems']}, lemmas={lean['lemmas']}, "
                    f"files={lean['files']})")
    else:
        typer.echo("  lean_theorems         : not found "
                    "(set FORGE_PROOF_CORPUS or pass --proof-corpus)")
    if res["written_to"]:
        typer.echo(f"\nwritten -> {res['written_to']}")
    else:
        typer.echo("\n(dry-run; pass --apply to write forge_metrics.json)")
