"""Atomadic Forge — unified CLI.

Public verbs:
    forge init        — interactive setup wizard (configure LLM, defaults)
    forge auto        — flagship: scout + cherry + assimilate + wire + certify
    forge recon       — scout walk only (writes scout.json)
    forge cherry      — cherry-pick from latest scout (writes cherry.json)
    forge finalize    — assimilate + wire + certify (consumes cherry.json)
    forge wire        — upward-import scanner over a tier-organized package
    forge certify     — score documentation/tests/layout/imports
    forge diff        — compare two Forge JSON manifests
    forge config      — show / set / test configuration

Specialty verbs (advanced):
    forge emergent    — symbol-level composition discovery
    forge synergy     — feature-pair discovery + auto-implement adapters
    forge commandsmith — auto-register/document/smoke CLI commands
    forge doctor      — environment diagnostic
"""

from __future__ import annotations

import io
import json
import shutil
import sys
import warnings
from pathlib import Path
from typing import Annotated

import typer

from .. import __version__
from ..a1_at_functions.agent_context_pack import emit_context_pack
from ..a1_at_functions.agent_summary import (
    render_summary_text,
    summarize_blockers,
)
from ..a1_at_functions.card_renderer import render_receipt_card
from ..a1_at_functions.certify_checks import certify as certify_checks
from ..a1_at_functions.error_hints import format_hint
from ..a1_at_functions.local_signer import sign_receipt_local
from ..a1_at_functions.manifest_diff import diff_manifests
from ..a1_at_functions.mcp_protocol import TOOLS
from ..a1_at_functions.preflight_change import preflight_change
from ..a1_at_functions.progress_reporter import make_stderr_reporter
from ..a1_at_functions.receipt_emitter import build_receipt, receipt_to_json
from ..a1_at_functions.recipes import all_recipes, get_recipe, list_recipes
from ..a1_at_functions.sbom_emitter import emit_sbom
from ..a1_at_functions.scout_walk import harvest_repo
from ..a1_at_functions.sidecar_parser import (
    find_sidecar_for,
    parse_sidecar_file,
)
from ..a1_at_functions.sidecar_validator import validate_sidecar
from ..a1_at_functions.wire_check import scan_violations
from ..a1_at_functions.worktree_status import worktree_status
from ..a2_mo_composites.lineage_chain_store import LineageChainStore
from ..a2_mo_composites.plan_store import PlanStore
from ..a2_mo_composites.receipt_signer import sign_receipt
from ..a3_og_features.forge_enforce import run_enforce
from ..a3_og_features.forge_pipeline import (
    run_auto,
    run_auto_plan,
    run_cherry,
    run_finalize,
    run_recon,
)
from ..a3_og_features.forge_plan_apply import apply_all_applyable, apply_card
from ..a3_og_features.mcp_server import serve_stdio as mcp_serve_stdio
from .copilots_cmd import COPILOTS_VERBS as _COPILOTS_VERBS
from .login_cmd import app as _login_app
from .whoami_cmd import app as _whoami_app

# Suppress SyntaxWarnings from third-party code in seed/forged directories.
warnings.filterwarnings("ignore", category=SyntaxWarning)


def _force_utf8() -> None:
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"atomadic-forge {__version__}")
        raise typer.Exit()


app = typer.Typer(no_args_is_help=True,
                  help="Atomadic Forge — absorb · enforce · emerge.")


@app.callback()
def _root_callback(
    version: Annotated[bool | None, typer.Option(
        "--version", "-V",
        help="Show the Forge version and exit.",
        callback=_version_callback, is_eager=True,
    )] = None,
) -> None:
    """Root callback so --version works at the top level (Codex
    production-hardening: agents shouldn't get a usage error when
    asking for the version)."""
    return None


@app.command("init")
def init_cmd() -> None:
    """Interactive setup wizard — configure LLM, defaults, and workspace."""
    from atomadic_forge.a3_og_features.setup_wizard import run_wizard
    run_wizard(Path.cwd())


@app.command("auto")
def auto_cmd(
    target: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Source repository to absorb.")],
    output: Annotated[Path, typer.Argument(
        file_okay=False, dir_okay=True, resolve_path=True,
        help="Destination root for the materialized tier tree.")],
    package: Annotated[str, typer.Option("--package",
        help="Python package name to materialize under output/src/.")] = "absorbed",
    apply: Annotated[bool, typer.Option("--apply",
        help="Actually write files. Default is dry-run.")] = False,
    on_conflict: Annotated[str, typer.Option("--on-conflict",
        help="rename | first | last | fail")] = "rename",
    json_out: Annotated[bool, typer.Option("--json")] = False,
    progress: Annotated[bool | None, typer.Option(
        "--progress/--no-progress",
        help="Emit per-file scout progress to stderr. Default: auto "
             "(on when stderr is a TTY, off in CI / pipes / --json).")] = None,
    seed_determinism: Annotated[int | None, typer.Option(
        "--seed-determinism",
        help="Record a fixed RNG seed in the receipt for reproducibility audits (Lane G).",
    )] = None,
) -> None:
    """Flagship: scout → cherry-pick → assimilate → wire → certify in one shot."""
    output.mkdir(parents=True, exist_ok=True)
    reporter = make_stderr_reporter(
        enabled=False if json_out else progress, label="scout")
    report = run_auto(target=target, output=output, package=package,
                      apply=apply, on_conflict=on_conflict,
                      progress=reporter)
    if seed_determinism is not None:
        report.setdefault("extra", {})["seed_determinism"] = seed_determinism
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    typer.echo(f"\nAtomadic Forge — auto pipeline ({'APPLY' if apply else 'DRY-RUN'})")
    typer.echo("-" * 60)
    typer.echo(f"  source:        {target}")
    typer.echo(f"  destination:   {output}/{package}")
    typer.echo(f"  symbols:       {report['scout']['symbol_count']}")
    typer.echo(f"  cherry-picked: {report['cherry']['items']}")
    typer.echo(f"  components:    {report['finalize']['components_emitted']}")
    typer.echo(f"  tier_dist:     {report['finalize']['tier_distribution']}")
    typer.echo(f"  wire verdict:  {report['finalize']['wire'].get('verdict')}")
    typer.echo(f"  certify score: {report['finalize']['certify'].get('score', 0)}/100")
    if not apply:
        typer.echo("\n  (re-run with --apply to write the materialized tree)")


@app.command("recon")
def recon_cmd(
    target: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)],
    json_out: Annotated[bool, typer.Option("--json")] = False,
    progress: Annotated[bool | None, typer.Option(
        "--progress/--no-progress",
        help="Emit per-file scout progress to stderr. Default: auto "
             "(on when stderr is a TTY, off in CI / pipes / --json).")] = None,
) -> None:
    """Walk a repo, classify every public symbol, surface tier/effect distributions."""
    reporter = make_stderr_reporter(
        enabled=False if json_out else progress, label="scout")
    report = run_recon(target, progress=reporter)
    # v0.13 — wisdom-recall hook (Phase 0 / pre-execution).
    # Pulls top-N repo-scoped wisdom entries inline so any agent or dev
    # walking into this repo sees prior lessons before doing work.
    # Empty DB → empty list, no errors. Backwards-compatible: callers
    # parsing the old shape can ignore the new field.
    try:
        from atomadic_forge.a3_og_features.wisdom_feature import recall_for_recon
        report["prior_wisdom"] = recall_for_recon(project_root=target)
    except Exception as exc:  # noqa: BLE001 — wisdom is best-effort
        report["prior_wisdom"] = {"error": f"recall failed: {exc!r}"}
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    typer.echo(f"\nRecon: {target}")
    typer.echo("-" * 60)
    typer.echo(f"  python files:     {report['python_file_count']}")
    typer.echo(f"  javascript files: {report.get('javascript_file_count', 0)}")
    typer.echo(f"  typescript files: {report.get('typescript_file_count', 0)}")
    primary = report.get("primary_language")
    if primary:
        typer.echo(f"  primary language: {primary}")
    typer.echo(f"  symbols:          {report['symbol_count']}")
    typer.echo(f"  tier dist:        {report['tier_distribution']}")
    typer.echo(f"  effect dist:      {report['effect_distribution']}")
    if report["recommendations"]:
        typer.echo("  recommendations:")
        for r in report["recommendations"]:
            typer.echo(f"    - {r}")
    # ── prior wisdom recall ─────────────────────────────────────────
    pw = report.get("prior_wisdom") or {}
    pw_entries = pw.get("top_entries") if isinstance(pw, dict) else None
    if pw_entries:
        typer.echo("")
        typer.echo(f"  prior wisdom for this repo  ({len(pw_entries)} relevant):")
        for i, e in enumerate(pw_entries, 1):
            insight = e.get("insight", "")
            insight_short = insight[:140] + ("..." if len(insight) > 140 else "")
            typer.echo(f"    {i}. {insight_short}")


@app.command("cherry")
def cherry_cmd(
    target: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)],
    pick: Annotated[list[str] | None, typer.Option("--pick",
        help="Explicit qualnames. Pass --pick all to take everything.")] = None,
    only_tier: Annotated[str | None, typer.Option("--only-tier",
        help="Restrict to one tier guess.")] = None,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Build a cherry-pick manifest from the latest scout report."""
    pick_all = pick == ["all"]
    names = None if (pick_all or not pick) else pick
    manifest = run_cherry(target, names=names, pick_all=pick_all,
                           only_tier=only_tier)
    if json_out:
        typer.echo(json.dumps(manifest, indent=2, default=str))
        return
    typer.echo("\nCherry-pick manifest written to .atomadic-forge/cherry.json")
    typer.echo(f"  selected: {len(manifest['items'])}")


@app.command("finalize")
def finalize_cmd(
    target: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)],
    output: Annotated[Path, typer.Argument(
        file_okay=False, dir_okay=True, resolve_path=True)],
    package: Annotated[str, typer.Option("--package")] = "absorbed",
    apply: Annotated[bool, typer.Option("--apply")] = False,
    on_conflict: Annotated[str, typer.Option("--on-conflict")] = "rename",
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Assimilate cherry-picked symbols + run wire + certify."""
    output.mkdir(parents=True, exist_ok=True)
    report = run_finalize(target=target, output=output, package=package,
                           apply=apply, on_conflict=on_conflict)
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    typer.echo(f"\nFinalize ({'APPLY' if apply else 'DRY-RUN'}): {output}/{package}")
    typer.echo(f"  components: {report['components_emitted']}")
    typer.echo(f"  tier dist:  {report['tier_distribution']}")
    typer.echo(f"  wire:       {report['wire'].get('verdict')}")
    typer.echo(f"  certify:    {report['certify'].get('score', 0)}/100")


@app.command("wire")
def wire_cmd(
    source: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Tier-organized package root.")],
    json_out: Annotated[bool, typer.Option("--json")] = False,
    fail_on_violations: Annotated[bool, typer.Option(
        "--fail-on-violations",
        help="Exit 1 when any upward-import violations are found "
             "(for use in CI gates).")] = False,
    suggest_repairs: Annotated[bool, typer.Option(
        "--suggest-repairs",
        help="For every violation, propose a concrete mechanical fix "
             "(target tier, sketch shell command). Heuristic, for review "
             "before applying.")] = False,
    summary: Annotated[bool, typer.Option(
        "--summary",
        help="Emit ONLY the compact agent-native blocker summary (top "
             "5 actionable items + next-command) instead of the full "
             "violation list. Pairs with --json for machine consumers.")] = False,
    strict_cycles: Annotated[bool, typer.Option(
        "--strict-cycles",
        help="Also detect file-pair cycles within the same tier and "
             "report them under same_tier_cycles. Off by default — "
             "intra-tier cycles are not always smells.")] = False,
) -> None:
    """Scan a tier tree for upward-import violations."""
    report = scan_violations(
        source,
        suggest_repairs=suggest_repairs,
        strict_cycles=strict_cycles,
    )
    has_violations = report["violation_count"] > 0
    if summary:
        s = summarize_blockers(wire_report=report, package_root=str(source))
        if json_out:
            typer.echo(json.dumps(s, indent=2, default=str))
        else:
            typer.echo(render_summary_text(s))
        if fail_on_violations and has_violations:
            raise typer.Exit(code=1)
        return
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        if fail_on_violations and has_violations:
            raise typer.Exit(code=1)
        return
    typer.echo(f"\nWire scan: {source}")
    typer.echo(f"  verdict:    {report['verdict']}")
    typer.echo(f"  violations: {report['violation_count']}")
    if suggest_repairs:
        typer.echo(f"  auto-fixable: {report['auto_fixable']}/{report['violation_count']}")
    for v in report["violations"][:10]:
        fcode = v.get("f_code", "")
        prefix = f"[{fcode}] " if fcode else ""
        line = (f"    - {prefix}{v['file']}: "
                f"{v['from_tier']} ⟵ {v['to_tier']}.{v['imported']}")
        typer.echo(line)
        if suggest_repairs and v.get("proposed_destination"):
            typer.echo(f"        → move to {v['proposed_destination']}/  "
                       f"({v.get('proposed_action', 'review_manually')})")
    if suggest_repairs and report.get("repair_suggestions"):
        typer.echo("\n  Repair plan (one entry per file):")
        for s in report["repair_suggestions"][:10]:
            dest = s.get("proposed_destination") or "(review manually)"
            typer.echo(
                f"    - {s['file']}: {s['violation_count']} violation(s) "
                f"→ {dest}"
            )
    if fail_on_violations and has_violations:
        typer.echo("  gate:       FAIL (--fail-on-violations set)")
        raise typer.Exit(code=1)
    if has_violations and not suggest_repairs and not json_out:
        typer.echo(
            "\n"
            + format_hint("wire_fail_with_violations",
                          count=report["violation_count"], path=source),
            err=True,
        )


@app.command("plan")
def plan_cmd(
    target: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Repo to inspect. The agent operates on it in-place "
             "(mode='improve', default) — Forge does NOT mutate.")],
    goal: Annotated[str, typer.Option("--goal",
        help="One-line description of what the agent is trying to achieve. "
             "Echoed back in the plan envelope.")] = "improve repo conformance",
    mode: Annotated[str, typer.Option("--mode",
        help="improve = operate in-place; absorb = scaffold a new "
             "tier-organized package from a flat repo.")] = "improve",
    package: Annotated[str | None, typer.Option("--package",
        help="Forwarded to forge certify when relevant.")] = None,
    top_n: Annotated[int, typer.Option("--top",
        help="Cap the action card list at N (action_count remains "
             "the full count).")] = 7,
    json_out: Annotated[bool, typer.Option("--json")] = False,
    save: Annotated[bool, typer.Option(
        "--save",
        help="Persist the plan under .atomadic-forge/plans/<id>.json "
             "so it can be addressed by `forge plan-step` / "
             "`forge plan-apply`.")] = False,
) -> None:
    """Codex-driven 'next best action card' generator (agent_plan/v1).

    Runs scout + wire + certify (and the optional emergent / synergy
    overlays when scans are present), ranks blockers and opportunities,
    and emits one ordered ``agent_plan/v1`` document. Each action card
    carries:

      id, kind, title, why, write_scope, risk, applyable,
      commands, related_fcodes, next_command, sample_path,
      score_delta_estimate

    The active agent inspects the cards, picks one (typically the
    first applyable), and runs its ``next_command``. Forge does NOT
    mutate the repo from this verb — the bounded write-step is
    delegated to verbs the cards reference (forge enforce, forge
    auto, forge synergy implement, forge emergent synthesize, etc.).
    """
    plan = run_auto_plan(target=target, goal=goal, mode=mode,
                          package=package, top_n=top_n)
    plan_id = None
    if save:
        plan_id = PlanStore(target).save_plan(plan)
        plan["id"] = plan_id  # so JSON / human output reflect the id
    if json_out:
        typer.echo(json.dumps(plan, indent=2, default=str))
        return
    typer.echo(f"\nForge plan ({plan['mode']}): {target}")
    typer.echo("-" * 60)
    typer.echo(f"  goal:          {plan['goal']}")
    typer.echo(f"  verdict:       {plan['verdict']}")
    typer.echo(f"  actions:       {plan['action_count']} "
                f"({plan['applyable_count']} applyable)")
    typer.echo("")
    for i, card in enumerate(plan["top_actions"], 1):
        tag = "AUTO" if card.get("applyable") else "REVIEW"
        risk = card.get("risk", "?")
        typer.echo(f"  {i}. [{tag}] [{risk}] [{card.get('kind', '?')}]"
                    f"  {card.get('title', '')}")
        typer.echo(f"     id:   {card.get('id', '')}")
        why = card.get("why", "").strip()
        if why:
            typer.echo(f"     why:  {why[:120]}")
        nc = card.get("next_command", "").strip()
        if nc:
            typer.echo(f"     next: {nc[:120]}")
        typer.echo("")
    typer.echo(f"  NEXT: {plan.get('next_command', '').strip()[:120]}")
    if plan_id:
        typer.echo(f"  saved: plan_id={plan_id}")
        typer.echo(f"        forge plan-show {plan_id} --project {target}")


@app.command("context-pack")
def context_pack_cmd(
    target: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    focus: Annotated[str | None, typer.Option(
        "--focus",
        help="Optional context focus: orientation, change, release, or debug.",
    )] = None,
    intent: Annotated[str, typer.Option(
        "--intent",
        help="One-line task intent used for targeted suggestions.",
    )] = "",
    files: Annotated[list[str] | None, typer.Option(
        "--file", "-f",
        help="Repeat for each target or changed file to include targeted context.",
    )] = None,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Codex 'Copilot's Copilot' #1: first-call context bundle.

    Returns repo purpose + tier law + tier map + blockers + best
    next action + test commands + release gate + risky files +
    recent lineage in one read. The single tool every coding agent
    should call on first connect.

    Examples:

        forge context-pack . --json
        forge context-pack . --focus change --intent "Edit README" --file README.md --json
    """
    target = Path(target).resolve()
    try:
        scout = harvest_repo(target)
    except (OSError, ValueError):
        scout = None
    try:
        wire = scan_violations(target)
    except (OSError, ValueError):
        wire = None
    try:
        cert = certify_checks(target, project=target.name)
    except (OSError, RuntimeError, ValueError):
        cert = None
    pack = emit_context_pack(
        project_root=target,
        scout_report=scout, wire_report=wire, certify_report=cert,
        focus=focus, intent=intent, files=files or [],
    )
    if json_out:
        typer.echo(json.dumps(pack, indent=2, default=str))
        return
    typer.echo(f"\nForge context-pack: {target}")
    typer.echo("-" * 60)
    typer.echo(f"  purpose:   {pack['repo_purpose'][:200]}")
    typer.echo(f"  focus:     {pack.get('focus', 'orientation')}")
    typer.echo(f"  language:  {pack['primary_language']}")
    typer.echo(f"  tiers:     {pack['tier_map']}")
    bs = pack["blockers_summary"]
    typer.echo(f"  verdict:   {bs.get('verdict', '?')}  "
                f"({bs.get('blocker_count', 0)} blocker(s))")
    if pack.get("best_next_action"):
        n = pack["best_next_action"]
        typer.echo(f"  best next: {n.get('title', n.get('id', '?'))}")
        nc = n.get("next_command", "").strip()
        if nc:
            typer.echo(f"             {nc[:140]}")
    typer.echo(f"  tests:     {' | '.join(pack['test_commands'][:3])}")
    typer.echo(f"  gate:      {' && '.join(pack['release_gate'])}")
    if pack.get("target_files"):
        typer.echo("  target files:")
        for f in pack.get("file_context", [])[:8]:
            tier = f.get("detected_tier") or "-"
            typer.echo(
                f"    - {f.get('path')}  "
                f"({f.get('kind')}, tier={tier}, exists={f.get('exists')})"
            )
    if pack.get("selected_tests"):
        tests = pack["selected_tests"]
        typer.echo(f"  focused:   {tests.get('minimum_command', '')}")
    if pack.get("suggested_next_steps"):
        typer.echo("  suggestions:")
        for step in pack["suggested_next_steps"][:5]:
            label = step.get("action", "?")
            why = step.get("why", "").strip()
            typer.echo(f"    - {label}: {why[:140]}")
            cmd = step.get("next_command", "").strip()
            if cmd:
                typer.echo(f"      next: {cmd[:160]}")
    if pack["risky_files"]:
        typer.echo("  risky files (most-edited):")
        for f in pack["risky_files"][:5]:
            typer.echo(f"    - {f['path']}  ({f['edit_count']}x)")


@app.command("preflight")
def preflight_cmd(
    intent: Annotated[str, typer.Argument(
        help="One-line description of what the agent intends to do.")],
    files: Annotated[list[str], typer.Argument(
        help="Proposed file paths the agent plans to write/modify.")],
    project: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)] = Path("."),
    scope_threshold: Annotated[int, typer.Option(
        "--scope-threshold",
        help="Warn when more than N files are in the write scope.")] = 8,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Codex 'Copilot's Copilot' #2: pre-edit guardrail.

    For each proposed file, returns the detected tier, forbidden
    imports, likely-affected tests, and sibling files to read first.
    Surfaces 'write_scope too broad' before the agent commits to a
    fragile multi-file patch.
    """
    report = preflight_change(
        intent=intent, proposed_files=list(files),
        project_root=project, scope_threshold=scope_threshold,
    )
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        if report["write_scope_too_broad"]:
            raise typer.Exit(code=1)
        return
    typer.echo(f"\nForge preflight ({len(files)} file(s))")
    typer.echo("-" * 60)
    typer.echo(f"  intent: {intent[:200]}")
    if report["write_scope_too_broad"]:
        typer.echo(f"  ⚠ write_scope: {report['write_scope_size']} files "
                    f"(> {report['write_scope_threshold']} threshold)")
    for f in report["proposed_files"]:
        tier = f.get("detected_tier") or "(none)"
        typer.echo(f"\n  {f['path']}  [{tier}]")
        if f.get("forbidden_imports"):
            typer.echo(f"    forbidden: {f['forbidden_imports']}")
        if f.get("likely_tests"):
            typer.echo(f"    tests:     {f['likely_tests'][:3]}")
        if f.get("siblings_to_read"):
            typer.echo(f"    siblings:  {f['siblings_to_read'][:3]}")
        for note in f.get("notes", []):
            typer.echo(f"    note: {note}")
    for note in report.get("overall_notes", []):
        typer.echo(f"\n  ! {note}")
    if report["write_scope_too_broad"]:
        raise typer.Exit(code=1)


sidecar_app = typer.Typer(
    no_args_is_help=True,
    help=".forge sidecar tools: parse + validate the per-symbol "
         "effect / compose_with / proves contract (Lane D W8 / W11).",
)


@sidecar_app.command("parse")
def sidecar_parse_cmd(
    sidecar_file: Annotated[Path, typer.Argument(
        exists=True, file_okay=True, dir_okay=False, resolve_path=True)],
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Parse a .forge sidecar YAML file."""
    rep = parse_sidecar_file(sidecar_file)
    if json_out:
        typer.echo(json.dumps(rep, indent=2, default=str))
        if rep["errors"]:
            raise typer.Exit(code=1)
        return
    if rep["errors"]:
        typer.echo(f"\nSidecar parse FAILED: {sidecar_file}")
        for e in rep["errors"]:
            typer.echo(f"  ! {e}")
        raise typer.Exit(code=1)
    sc = rep["sidecar"]
    typer.echo(f"\nSidecar OK: {sc['target']}  "
                f"({len(sc['symbols'])} symbol(s))")
    for w in rep.get("warnings", []):
        typer.echo(f"  ⚠ {w}")
    for s in sc["symbols"]:
        typer.echo(f"  - {s.get('name')}  effect={s.get('effect')}  "
                    f"tier={s.get('tier', '?')}")


@sidecar_app.command("validate")
def sidecar_validate_cmd(
    source_file: Annotated[Path, typer.Argument(
        exists=True, file_okay=True, dir_okay=False, resolve_path=True,
        help="Source file to validate against (e.g. src/pkg/auth.py).")],
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Cross-check a .forge sidecar against its source AST.

    Looks for ``<source>.forge`` next to the source file. Reports
    drift across S0000–S0007 finding classes; exits 1 on FAIL.
    """
    sidecar_path = find_sidecar_for(source_file)
    parse = parse_sidecar_file(sidecar_path)
    if parse["errors"]:
        typer.echo(f"\nCould not parse sidecar at {sidecar_path}:")
        for e in parse["errors"]:
            typer.echo(f"  ! {e}")
        raise typer.Exit(code=1)
    try:
        source_text = source_file.read_text(encoding="utf-8")
    except OSError as exc:
        raise typer.BadParameter(f"could not read {source_file}: {exc}") from exc
    rep = validate_sidecar(
        parse["sidecar"], source_text=source_text, source_path=source_file,
    )
    if json_out:
        typer.echo(json.dumps(rep, indent=2, default=str))
        if rep["verdict"] == "FAIL":
            raise typer.Exit(code=1)
        return
    typer.echo(f"\nSidecar validate: {source_file}")
    typer.echo(f"  verdict:  {rep['verdict']}")
    typer.echo(f"  findings: {rep['finding_count']}")
    for f in rep["findings"]:
        sev = f.get("severity", "?").upper()
        typer.echo(f"  - [{f.get('code')}] [{sev:<5}] "
                    f"{f.get('symbol', '?')}: {f.get('message', '')}")
    if rep["verdict"] == "FAIL":
        raise typer.Exit(code=1)


app.add_typer(sidecar_app, name="sidecar",
               help="Parse / validate .forge sidecar files.")


@app.command("recipes")
def recipes_cmd(
    name: Annotated[str | None, typer.Argument(
        help="Recipe name to show; omit to list all.")] = None,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Codex #12: golden-path recipes catalogue.

    With no argument, lists every recipe. With a name, shows that
    recipe's checklist + file_scope_hints + validation_gate. Same
    surface as the MCP tools list_recipes / get_recipe.
    """
    if name is None:
        names = list_recipes()
        catalogue = all_recipes()
        if json_out:
            typer.echo(json.dumps(
                {"schema_version": "atomadic-forge.recipe.list/v1",
                 "recipes": names,
                 "recipe_count": len(names),
                 "catalogue": {n: r["description"] for n, r in catalogue.items()}},
                indent=2, default=str))
            return
        typer.echo("\nForge — golden-path recipes")
        typer.echo("-" * 60)
        for n in names:
            typer.echo(f"  {n:<22}  {catalogue[n]['description']}")
        typer.echo("\n  forge recipes <name>  — show one recipe")
        return
    recipe = get_recipe(name)
    if recipe is None:
        raise typer.BadParameter(
            f"unknown recipe: {name!r}. "
            f"Available: {', '.join(list_recipes())}"
        )
    if json_out:
        typer.echo(json.dumps(recipe, indent=2, default=str))
        return
    typer.echo(f"\nForge recipe: {recipe['name']}")
    typer.echo("-" * 60)
    typer.echo(f"  {recipe['description']}\n")
    typer.echo("  Checklist:")
    for i, step in enumerate(recipe.get("checklist", []), 1):
        typer.echo(f"    {i}. {step}")
    if recipe.get("file_scope_hints"):
        typer.echo("\n  File scope:")
        for f in recipe["file_scope_hints"]:
            typer.echo(f"    - {f}")
    if recipe.get("validation_gate"):
        typer.echo("\n  Validation gate:")
        for cmd in recipe["validation_gate"]:
            typer.echo(f"    $ {cmd}")
    if recipe.get("notes"):
        typer.echo("\n  Notes:")
        for n in recipe["notes"]:
            typer.echo(f"    {n}")


@app.command("plan-list")
def plan_list_cmd(
    project: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root the plans are stored under.")] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """List saved agent_plan/v1 documents for ``--project``."""
    plans = PlanStore(project).list_plans()
    if json_out:
        typer.echo(json.dumps(
            {"schema_version": "atomadic-forge.plan.list/v1",
             "project": str(project),
             "plans": plans}, indent=2, default=str))
        return
    if not plans:
        typer.echo(f"\nNo saved plans under {project}/.atomadic-forge/plans/")
        typer.echo("Run `forge plan <target> --save` to persist one.")
        return
    typer.echo(f"\nForge — saved plans under {project}/.atomadic-forge/plans/")
    typer.echo("-" * 60)
    for p in plans:
        typer.echo(f"  {p['plan_id']}  {p['verdict']:<6}  "
                    f"actions={p['action_count']}  "
                    f"applyable={p['applyable_count']}  "
                    f"saved={p['saved_at_utc']}")
        typer.echo(f"    goal: {p['goal'][:80]}")


@app.command("plan-show")
def plan_show_cmd(
    plan_id: Annotated[str, typer.Argument(help="Plan id from plan-list.")],
    project: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Pretty-print a saved agent_plan/v1 by id."""
    store = PlanStore(project)
    plan = store.load_plan(plan_id)
    if plan is None:
        raise typer.BadParameter(
            f"plan id {plan_id!r} not found under "
            f"{project}/.atomadic-forge/plans/"
        )
    state = store.load_state(plan_id) or {}
    if json_out:
        typer.echo(json.dumps({"plan": plan, "state": state},
                                indent=2, default=str))
        return
    typer.echo(f"\nForge plan {plan_id}  ({plan.get('verdict', '?')})")
    typer.echo("-" * 60)
    typer.echo(f"  goal:    {plan.get('goal', '')}")
    typer.echo(f"  mode:    {plan.get('mode', '')}")
    typer.echo(f"  actions: {plan.get('action_count', 0)} "
                f"({plan.get('applyable_count', 0)} applyable)")
    for i, card in enumerate(plan.get("top_actions", []), 1):
        cid = card.get("id", "?")
        status = store.card_status(plan_id, cid)
        tag = "AUTO" if card.get("applyable") else "REVIEW"
        typer.echo(f"  {i}. [{tag}] [{status}] {card.get('title', '')}")
        typer.echo(f"     id: {cid}")


@app.command("plan-step")
def plan_step_cmd(
    plan_id: Annotated[str, typer.Argument(help="Plan id from plan-list.")],
    card_id: Annotated[str, typer.Argument(help="Card id from plan-show.")],
    project: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)] = Path("."),
    apply: Annotated[bool, typer.Option(
        "--apply",
        help="Actually execute the card. Default is dry-run.")] = False,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Apply ONE card from a saved plan (Codex's bounded-step verb)."""
    store = PlanStore(project)
    plan = store.load_plan(plan_id)
    if plan is None:
        raise typer.BadParameter(f"plan id {plan_id!r} not found")
    result = apply_card(project, plan, card_id, apply=apply)
    if json_out:
        typer.echo(json.dumps(result, indent=2, default=str))
        if result["status"] in {"failed", "rolled_back"}:
            raise typer.Exit(code=1)
        return
    typer.echo(f"\nForge plan-step ({'APPLY' if apply else 'DRY-RUN'}) "
                f"{plan_id}/{card_id}")
    typer.echo(f"  status: {result['status']}")
    detail = result.get("detail") or {}
    for key, value in detail.items():
        if isinstance(value, dict | list):
            value = json.dumps(value, default=str)[:120]
        typer.echo(f"  {key}: {value}")
    if result["status"] in {"failed", "rolled_back"}:
        raise typer.Exit(code=1)


@app.command("plan-apply")
def plan_apply_cmd(
    plan_id: Annotated[str, typer.Argument(help="Plan id from plan-list.")],
    project: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)] = Path("."),
    apply: Annotated[bool, typer.Option(
        "--apply",
        help="Actually execute every applyable card. Default is dry-run.")] = False,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Apply ALL applyable cards from a saved plan in order.

    Halts on the first ``rolled_back`` or ``failed`` outcome so the
    agent inspects before cascading further mutations.
    """
    store = PlanStore(project)
    plan = store.load_plan(plan_id)
    if plan is None:
        raise typer.BadParameter(f"plan id {plan_id!r} not found")
    result = apply_all_applyable(project, plan, apply=apply)
    if json_out:
        typer.echo(json.dumps(result, indent=2, default=str))
        if result.get("halted_on") in {"failed", "rolled_back"}:
            raise typer.Exit(code=1)
        return
    typer.echo(f"\nForge plan-apply ({'APPLY' if apply else 'DRY-RUN'}) "
                f"{plan_id}")
    typer.echo("-" * 60)
    typer.echo(f"  applied: {result['applied_count']}  "
                f"skipped: {result['skipped_count']}  "
                f"halted_on: {result.get('halted_on') or '-'}")
    for r in result["results"]:
        typer.echo(f"  - [{r['status']:<12s}] {r['card_id']}")
    if result.get("halted_on") in {"failed", "rolled_back"}:
        raise typer.Exit(code=1)


@app.command("enforce")
def enforce_cmd(
    package_root: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Tier-organized package root.")],
    apply: Annotated[bool, typer.Option(
        "--apply",
        help="Actually execute file moves. Default is dry-run.")] = False,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Plan (and optionally apply) mechanical fixes for wire violations.

    Routes by F-code (Lane A W5); rolls back any fix that increases the
    violation count. Default mode is dry-run — pass --apply to execute.
    """
    report = run_enforce(package_root, apply=apply)
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        if apply and report["post_violations"] > report["pre_violations"]:
            raise typer.Exit(code=1)
        return
    plan = report["plan"]
    typer.echo(f"\nForge enforce ({'APPLY' if apply else 'DRY-RUN'}): "
               f"{package_root}")
    typer.echo("-" * 60)
    typer.echo(f"  pre  violations: {report['pre_violations']}")
    typer.echo(f"  post violations: {report['post_violations']}")
    typer.echo(f"  actions:         {plan['action_count']} "
               f"({plan['auto_apply_count']} auto, "
               f"{plan['review_count']} review)")
    if plan["by_fcode"]:
        typer.echo(f"  by F-code:       {plan['by_fcode']}")
    if not apply and plan["action_count"] > 0:
        typer.echo("\n  Planned moves:")
        for action in plan["actions"][:10]:
            tag = "AUTO" if action.get("auto_apply") else "REVIEW"
            if action.get("dest"):
                typer.echo(
                    f"    [{tag}] [{action['f_code']}] "
                    f"{action['src']}  →  {action['dest']}"
                )
            else:
                typer.echo(
                    f"    [{tag}] [{action['f_code']}] "
                    f"{action['src']}  →  (manual review)"
                )
            for w in action.get("warnings", [])[:2]:
                typer.echo(f"        ! {w}")
        typer.echo("\n  (re-run with --apply to execute the AUTO actions)")
    if apply:
        typer.echo("\n  Apply results:")
        for entry in report["applied"]:
            a = entry["action"]
            typer.echo(f"    [{entry['status'].upper():12s}] "
                       f"[{a['f_code']}] {a['src']}")
        if report["rollbacks"]:
            typer.echo(f"\n  Rolled back: {len(report['rollbacks'])} action(s) "
                       "(violations rose; reverted)")
        if report["post_violations"] > report["pre_violations"]:
            raise typer.Exit(code=1)


@app.command("certify")
def certify_cmd(
    project_root: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True)],
    package: Annotated[str | None, typer.Option("--package")] = None,
    fail_under: Annotated[float | None, typer.Option("--fail-under",
        help="Exit 1 when the certify score is below this threshold.")] = None,
    json_out: Annotated[bool, typer.Option("--json")] = False,
    emit_receipt: Annotated[Path | None, typer.Option(
        "--emit-receipt",
        help="Write a Forge Receipt v1 JSON to PATH "
             "(see docs/RECEIPT.md for the schema).")] = None,
    print_card: Annotated[bool, typer.Option(
        "--print-card",
        help="Print the receipt as a 60-wide box-drawing card to stdout. "
             "Powers the '62 -> 5' viral demo.")] = False,
    sign: Annotated[bool, typer.Option(
        "--sign",
        help="Send the receipt to AAAA-Nexus /v1/verify/forge-receipt "
             "for Sigstore + AAAA-Nexus signing before emitting / "
             "rendering. Soft-fails if the endpoint is unavailable; the "
             "unsigned receipt is still emitted with a notes entry.")] = False,
    local_sign: Annotated[bool, typer.Option(
        "--local-sign/--no-local-sign",
        help="Sign the receipt with a local Ed25519 key (Lane G W5). "
             "Soft-fails if the key is absent or cryptography not installed.")] = False,
    local_sign_key: Annotated[Path | None, typer.Option(
        "--local-sign-key",
        help="Path to the Ed25519 PEM private key used by --local-sign. "
             "Defaults to forge-signing.pem in the project root.")] = None,
    summary: Annotated[bool, typer.Option(
        "--summary",
        help="Emit ONLY the compact agent-native blocker summary (top "
             "5 actionable items + next-command) instead of the full "
             "certify report. Pairs with --json for machine consumers.")] = False,
    skip_tests: Annotated[bool, typer.Option(
        "--skip-tests",
        help="Skip running pytest (~40 s) and credit the behavioral axis "
             "at 1.0. Structure-only check completes in ~500 ms.")] = False,
) -> None:
    """Score documentation, tests, tier layout, import discipline."""
    if fail_under is not None and not 0 <= fail_under <= 100:
        raise typer.BadParameter(
            format_hint("fail_under_out_of_range", value=fail_under)
        )
    report = certify_checks(project_root, project=project_root.name,
                             package=package, skip_tests=skip_tests)
    failed_gate = fail_under is not None and float(report["score"]) < fail_under
    if summary:
        # Pair certify with a fresh wire scan so the summary covers
        # both axes (Codex feedback: agents want one compact answer).
        wire_for_summary = scan_violations(project_root)
        s = summarize_blockers(
            wire_report=wire_for_summary,
            certify_report=report,
            package_root=package or project_root.name,
        )
        if json_out:
            typer.echo(json.dumps(s, indent=2, default=str))
        else:
            typer.echo(render_summary_text(s))
        if failed_gate:
            raise typer.Exit(code=1)
        return
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        if failed_gate:
            raise typer.Exit(code=1)
        return
    typer.echo(f"\nCertify: {project_root}")
    typer.echo(f"  score: {report['score']}/100")
    typer.echo(f"  docs:  {'PASS' if report['documentation_complete'] else 'FAIL'}")
    typer.echo(f"  tests: {'PASS' if report['tests_present'] else 'FAIL'}")
    typer.echo(f"  layout:{'PASS' if report['tier_layout_present'] else 'FAIL'}")
    typer.echo(f"  wire:  {'PASS' if report['no_upward_imports'] else 'FAIL'}")
    for issue in report["issues"]:
        typer.echo(f"    - {issue}")
    if emit_receipt is not None or print_card or sign or local_sign:
        # The Receipt needs a scout summary; if scout didn't already
        # run via forge auto, harvest a cheap one now (no symbol dump
        # written; we only need counts + tier_distribution).
        scout_for_receipt = harvest_repo(project_root)
        wire_for_receipt = scan_violations(project_root)
        receipt = build_receipt(
            certify_result=report,
            wire_report=wire_for_receipt,
            scout_report=scout_for_receipt,
            project_name=project_root.name,
            project_root=project_root,
            forge_version=__version__,
            package=package,
            certify_threshold=fail_under or 100.0,
        )
        # Lane A W4: append a local lineage-chain link before signing
        # so signatures.aaaa_nexus can carry the lineage_path the
        # Vanguard endpoint sees. Skip on --no-lineage (future flag).
        receipt = LineageChainStore(project_root).link_and_append(receipt)
        if sign:
            receipt = sign_receipt(receipt)
        if local_sign:
            key = local_sign_key or (project_root / "forge-signing.pem")
            receipt = sign_receipt_local(receipt, key_path=key)
        if emit_receipt is not None:
            emit_receipt.parent.mkdir(parents=True, exist_ok=True)
            emit_receipt.write_text(receipt_to_json(receipt), encoding="utf-8")
        if print_card:
            typer.echo("")
            typer.echo(render_receipt_card(receipt))
    if failed_gate:
        typer.echo(f"  gate:  FAIL (score below --fail-under {fail_under:g})")
        typer.echo(
            "\n"
            + format_hint("certify_below_threshold",
                          score=report["score"],
                          threshold=int(fail_under) if float(fail_under).is_integer() else fail_under,
                          path=project_root),
            err=True,
        )
        raise typer.Exit(code=1)


@app.command("status")
def status_cmd(
    project_root: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
    fail_under: Annotated[float | None, typer.Option(
        "--fail-under",
        help="Exit 1 when the certify score is below this threshold.")] = None,
) -> None:
    """Quick health snapshot: wire violations + certify score in one call.

    The go-to command when you want a fast answer to 'is my project clean?'
    without running the full auto pipeline.
    """
    wire_report = scan_violations(project_root)
    certify_report = certify_checks(project_root, project=project_root.name)
    violations = wire_report["violation_count"]
    score = certify_report["score"]
    overall = "PASS" if (violations == 0 and score >= (fail_under or 75)) else "FAIL"
    if json_out:
        typer.echo(json.dumps({
            "schema_version": "atomadic-forge.status/v1",
            "project": str(project_root),
            "verdict": overall,
            "wire": {"violations": violations, "verdict": wire_report.get("verdict")},
            "certify": {"score": score, "issues": certify_report.get("issues", [])},
        }, indent=2, default=str))
        if overall == "FAIL" and fail_under is not None:
            raise typer.Exit(code=1)
        return
    typer.echo(f"\nForge status: {project_root}")
    typer.echo("-" * 60)
    wire_ok = violations == 0
    score_ok = score >= (fail_under or 75)
    typer.echo(f"  wire:    {'PASS' if wire_ok else 'FAIL':5s}  {violations} violation(s)")
    typer.echo(f"  certify: {'PASS' if score_ok else 'FAIL':5s}  {score}/100")
    for issue in certify_report.get("issues", []):
        typer.echo(f"    - {issue}")
    typer.echo(f"\n  {'✓ CLEAN' if overall == 'PASS' else '✗ NEEDS WORK'}")
    if overall == "FAIL" and fail_under is not None:
        raise typer.Exit(code=1)


@app.command("verify")
def verify_cmd(
    project_root: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root to verify.")] = Path("."),
    package: Annotated[str | None, typer.Option(
        "--package", help="Python package sub-directory.")] = None,
    fail_under: Annotated[float, typer.Option(
        "--fail-under",
        help="Certify score threshold; exit 1 when below.")] = 75.0,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Composite wire + certify gate — one verdict, one exit code.

    Runs wire (upward-import scanner) and certify (score) in sequence
    and synthesises a single PASS / REFINE / FAIL verdict.  Designed
    for CI steps where you want a binary answer and a non-zero exit on
    failure without having to chain two commands.
    """
    wire_report = scan_violations(project_root)
    certify_report = certify_checks(project_root, project=project_root.name,
                                    package=package)
    violations = wire_report["violation_count"]
    score = float(certify_report["score"])

    if violations == 0 and score >= fail_under:
        verdict = "PASS"
    elif violations <= 2 and score >= fail_under * 0.85:
        verdict = "REFINE"
    else:
        verdict = "FAIL"

    result = {
        "schema_version": "atomadic-forge.verify/v1",
        "project": str(project_root),
        "verdict": verdict,
        "wire": {"violations": violations, "verdict": wire_report.get("verdict")},
        "certify": {"score": score, "issues": certify_report.get("issues", [])},
        "threshold": fail_under,
    }
    if json_out:
        typer.echo(json.dumps(result, indent=2, default=str))
        if verdict == "FAIL":
            raise typer.Exit(code=1)
        return
    typer.echo(f"\nForge verify: {project_root}")
    typer.echo("-" * 60)
    typer.echo(f"  wire:    {'PASS' if violations == 0 else 'FAIL':5s}  {violations} violation(s)")
    typer.echo(f"  certify: {score:.0f}/100  (threshold {fail_under:g})")
    for issue in certify_report.get("issues", []):
        typer.echo(f"    - {issue}")
    typer.echo(f"\n  verdict: {verdict}")
    if verdict == "FAIL":
        raise typer.Exit(code=1)


@app.command("smell")
def smell_cmd(
    project_root: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root to scan.")] = Path("."),
    cc_threshold: Annotated[int, typer.Option(
        "--cc", help="Cyclomatic complexity threshold (default 10).")] = 10,
    loc_threshold: Annotated[int, typer.Option(
        "--loc", help="Lines-per-function threshold (default 50).")] = 50,
    package: Annotated[str | None, typer.Option(
        "--package", help="Python package sub-directory.")] = None,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Code smell scan — cyclomatic complexity, long functions, duplicates.

    Reports a smell_score (0–100, higher is worse) and a prioritised
    list of the worst offenders so you know exactly where to refactor.
    """
    from ..a1_at_functions.smell_scan import smell_scan
    report = smell_scan(project_root, cc_threshold=cc_threshold,
                        loc_threshold=loc_threshold, package_subdir=package)
    if json_out:
        typer.echo(json.dumps(report.as_dict(), indent=2, default=str))
        return
    d = report.as_dict()
    typer.echo(f"\nForge smell: {project_root}")
    typer.echo("-" * 60)
    typer.echo(f"  smell_score:  {d['smell_score']}/100")
    typer.echo(f"  files scanned:{d.get('files_scanned', '?')}")
    typer.echo(f"  smells found: {d.get('total_smells', len(d.get('smells', [])))}")
    smells = d.get("smells", [])[:10]
    if smells:
        typer.echo("  top offenders:")
        for s in smells:
            typer.echo(f"    [{s.get('code', '?')}] {s.get('location', '?')}  — {s.get('message', '')}")
    if d["smell_score"] == 0:
        typer.echo("  ✓ No smells detected")


@app.command("call-graph")
def call_graph_cmd(
    qualname: Annotated[str, typer.Argument(
        help="Fully-qualified symbol name (e.g. my_pkg.utils.parse_line).")],
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    package: Annotated[str | None, typer.Option(
        "--package", help="Python package name.")] = None,
    direction: Annotated[str, typer.Option(
        "--direction",
        help="callers | callees | both")] = "both",
    max_depth: Annotated[int, typer.Option(
        "--max-depth", help="Maximum traversal depth.")] = 3,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """AST call-graph for a symbol — who calls it, what it calls."""
    from ..a1_at_functions.call_graph import build_call_graph
    report = build_call_graph({
        "qualname": qualname,
        "project_root": str(project_root),
        "package": package,
        "direction": direction,
        "max_depth": max_depth,
    })
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    typer.echo(f"\nForge call-graph: {qualname}")
    typer.echo("-" * 60)
    typer.echo(f"  direction:  {direction}")
    typer.echo(f"  max_depth:  {max_depth}")
    callers = report.get("callers", [])
    callees = report.get("callees", [])
    if callers:
        typer.echo(f"  callers ({len(callers)}):")
        for c in callers[:20]:
            typer.echo(f"    ← {c}")
    if callees:
        typer.echo(f"  callees ({len(callees)}):")
        for c in callees[:20]:
            typer.echo(f"    → {c}")
    if not callers and not callees:
        typer.echo("  (no edges found — check that qualname and package are correct)")


@app.command("call-graph-summary")
def call_graph_summary_cmd(
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    package: Annotated[str | None, typer.Option(
        "--package", help="Python package name.")] = None,
    top_n: Annotated[int, typer.Option(
        "--top-n", help="Max hotspots / orphans to surface.")] = 10,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Whole-package call-graph portfolio: orphans, hotspots, max depth."""
    from ..a1_at_functions.call_graph import build_call_graph_summary
    report = build_call_graph_summary({
        "project_root": str(project_root),
        "package": package,
        "top_n": top_n,
    })
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    typer.echo(f"\nForge call-graph-summary: {project_root}")
    typer.echo("-" * 60)
    typer.echo(f"  package:          {report.get('package', '?')}")
    typer.echo(f"  total_callers:    {report.get('total_callers', '?')}")
    typer.echo(f"  total_edges:      {report.get('total_edges', '?')}")
    typer.echo(f"  max_call_depth:   {report.get('max_call_depth', '?')}")
    typer.echo(f"  uncalled_callers: {report.get('uncalled_callers_count', '?')}")
    hotspots = report.get("hotspots", [])
    if hotspots:
        typer.echo(f"  hotspots (top {len(hotspots)}):")
        for h in hotspots:
            typer.echo(f"    [{h.get('fan_in', 0):>3} calls in] {h.get('qualname', '?')}")


@app.command("churn")
def churn_cmd(
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root (must be a git repo).")] = Path("."),
    since: Annotated[str, typer.Option(
        "--since", help="Git date filter, e.g. '6 months ago'.")] = "",
    top_n: Annotated[int, typer.Option(
        "--top-n", help="Hotspot / stable files to surface.")] = 15,
    all_files: Annotated[bool, typer.Option(
        "--all-files", help="Include all files, not just src/.")] = False,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Git churn analysis — which files change most / least often."""
    from ..a1_at_functions.git_churn import compute_git_churn
    report = compute_git_churn(
        project_root, top_n=top_n, since=since, src_only=not all_files
    )
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    if not report.get("available"):
        typer.echo(f"Git churn unavailable: {report.get('reason', 'unknown')}")
        return
    typer.echo(f"\nForge churn: {project_root}")
    typer.echo("-" * 60)
    typer.echo(f"  period:           {report['churn_period']}")
    typer.echo(f"  total_commits:    {report['total_commits']}")
    typer.echo(f"  files_tracked:    {report['files_tracked']}")
    typer.echo(f"  avg commits/file: {report['avg_commits_per_file']}")
    hotspots = report.get("hotspot_files", [])
    if hotspots:
        typer.echo(f"  hotspot files (top {len(hotspots)}):")
        for h in hotspots:
            typer.echo(f"    [{h['commits']:>4}] {h['path']}")
    stable = report.get("stable_files", [])
    if stable:
        typer.echo(f"  stable files (≤2 commits, top {len(stable)}):")
        for s in stable:
            typer.echo(f"    [{s['commits']:>4}] {s['path']}")


@app.command("surface-gaps")
def surface_gaps_cmd(
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    top_n: Annotated[int, typer.Option(
        "--top-n", help="Max gaps to surface per category.")] = 20,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Find a1 entry points that lack MCP or CLI coverage.

    Surfaces the wiring gap punch-list so you know exactly what to wire
    next.  Both-gaps are the highest priority: not reachable from MCP *or*
    the CLI.
    """
    from ..a1_at_functions.surface_gap_check import check_surface_gaps
    report = check_surface_gaps(project_root)
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    if not report.get("available"):
        typer.echo(f"surface-gaps unavailable: {report.get('reason', 'unknown')}")
        return
    typer.echo(f"\nForge surface-gaps: {project_root}")
    typer.echo("-" * 60)
    typer.echo(f"  entry points scanned: {report['total_entry_points_scanned']}")
    typer.echo(f"  mcp_gap_count:        {report['mcp_gap_count']}")
    typer.echo(f"  cli_gap_count:        {report['cli_gap_count']}")
    typer.echo(f"  both_gaps (priority): {report['both_gap_count']}")
    both = report.get("both_gaps", [])[:top_n]
    if both:
        typer.echo("  ── Missing from BOTH MCP and CLI ──")
        for g in both:
            typer.echo(f"    {g['qualname']}")
    mcp_only = [g for g in report.get("mcp_gaps", [])[:top_n]
                if g["qualname"] not in {b["qualname"] for b in both}]
    if mcp_only:
        typer.echo("  ── Missing from MCP only ──")
        for g in mcp_only[:10]:
            typer.echo(f"    {g['qualname']}")


@app.command("capability-scout")
def capability_scout_cmd(
    queries: Annotated[str, typer.Option(
        "--queries", "-q",
        help="Comma-separated capability search queries."
    )] = "code analysis python ast,dead code detection python,refactoring suggestions python",
    per_query: Annotated[int, typer.Option(
        "--per-query", help="Max GitHub results per query (≤30).")] = 8,
    min_score: Annotated[float, typer.Option(
        "--min-score", help="Minimum harvest-confidence score (0-100).")] = 30.0,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Search GitHub for repos matching capability queries — harvest target finder."""
    from ..a1_at_functions.capability_scout import scout_capabilities
    query_list = [q.strip() for q in queries.split(",") if q.strip()]
    report = scout_capabilities(query_list, per_query=per_query, min_score=min_score)
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    typer.echo(f"\nForge capability-scout ({len(query_list)} queries)")
    typer.echo("-" * 60)
    typer.echo(f"  total candidates: {report['total_candidates']}")
    for t in report.get("targets", [])[:15]:
        typer.echo(f"  [{t['harvest_score']:>5.1f}] {t['repo']:40s} ★{t['stars']:>6,}")
        typer.echo(f"         {t['description'][:80]}")


@app.command("wire-stubs")
def wire_stubs_cmd(
    module: Annotated[str, typer.Argument(help="a1 module stem (e.g. git_churn).")],
    function: Annotated[str, typer.Argument(help="Public function name.")],
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    apply: Annotated[bool, typer.Option(
        "--apply", help="Write stubs directly into mcp_protocol.py, cli.py, tests/.")] = False,
    tools: Annotated[str, typer.Option(
        "--tools", help="Which dispatchers to wire: explore, audit, or both (comma-sep).")] = "explore,audit",
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Generate (and optionally apply) MCP handler + CLI command + test skeleton.

    Without --apply: prints stubs to stdout for review.
    With --apply: injects stubs directly into the forge source files — no copy-paste needed.
    """
    from ..a1_at_functions.wire_stubs_gen import apply_wire_stubs, generate_wire_stubs
    tool_set = tuple(t.strip() for t in tools.split(",") if t.strip())
    if apply:
        report = apply_wire_stubs(project_root, module_stem=module, fn_name=function,
                                  tools=tool_set)
    else:
        report = generate_wire_stubs(project_root, module_stem=module, fn_name=function)
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    if not report.get("available"):
        typer.echo(f"wire-stubs error: {report.get('reason', 'unknown')}")
        return
    typer.echo(f"\nForge wire-stubs: {module}.{function}")
    typer.echo("-" * 60)
    typer.echo(f"  action_name:      {report['action_name']}")
    typer.echo(f"  cli_command_name: {report['cli_command_name']}")
    if apply:
        typer.echo(f"  applied:          {report.get('applied', False)}")
        for f in report.get("files_modified", []):
            typer.echo(f"  modified:         {f}")
        for e in report.get("errors", []):
            typer.echo(f"  ERROR:            {e}", err=True)
    else:
        typer.echo("\n── MCP handler (use --apply to inject automatically) ──")
        typer.echo(report["mcp_handler"])
        typer.echo("\n── CLI command ──")
        typer.echo(report["cli_command"])
        typer.echo("\n── Test skeleton ──")
        typer.echo(report["test_skeleton"])


@app.command("auto-wire")
def auto_wire_cmd(
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    top_n: Annotated[int, typer.Option(
        "--top-n", help="Max gaps to auto-wire per run.")] = 10,
    tools: Annotated[str, typer.Option(
        "--tools", help="Dispatchers to wire into: explore, audit, or both.")] = "explore,audit",
    dry_run: Annotated[bool, typer.Option(
        "--dry-run", help="Show what would be wired without writing files.")] = False,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Auto-wire unwired a1 entry points into MCP and CLI in one shot.

    Runs surface-gaps to find unwired functions, then applies wire-stubs
    for each one.  No copy-paste.  Run forge certify afterward to verify.
    """
    from ..a1_at_functions.surface_gap_check import check_surface_gaps
    from ..a1_at_functions.wire_stubs_gen import apply_wire_stubs
    tool_set = tuple(t.strip() for t in tools.split(",") if t.strip())

    gaps_report = check_surface_gaps(project_root)
    if not gaps_report.get("available"):
        typer.echo(f"auto-wire: {gaps_report.get('reason', 'surface-gaps unavailable')}")
        raise typer.Exit(1)

    targets = gaps_report.get("both_gaps", [])[:top_n]
    results = []
    wired = 0
    skipped = 0

    for gap in targets:
        mod = gap["module"]
        fn = gap["function"]
        result = apply_wire_stubs(project_root, module_stem=mod, fn_name=fn,
                                  tools=tool_set, dry_run=dry_run)
        results.append(result)
        if result.get("errors"):
            skipped += 1
        else:
            wired += 1

    summary = {
        "schema_version": "atomadic-forge.auto_wire/v1",
        "available": True,
        "dry_run": dry_run,
        "gaps_found": gaps_report.get("both_gap_count", 0),
        "targets_attempted": len(targets),
        "wired": wired,
        "skipped": skipped,
        "results": results,
    }

    # Self-verify: run ruff --fix on every file modified during a real apply.
    ruff_results: list[str] = []
    if not dry_run and wired:
        import subprocess as _sp
        patched: set[str] = set()
        for r in results:
            patched.update(r.get("files_modified", []))
        for rel in sorted(patched):
            abs_path = str(project_root / rel)
            rv = _sp.run(
                ["python", "-m", "ruff", "check", "--fix", abs_path],
                cwd=str(project_root), capture_output=True, text=True,
            )
            if rv.returncode != 0:
                ruff_results.append(f"ruff WARN {rel}: {rv.stdout.strip()[:120]}")
            else:
                ruff_results.append(f"ruff OK   {rel}")
        summary["ruff_self_verify"] = ruff_results

    if json_out:
        typer.echo(json.dumps(summary, indent=2, default=str))
        return

    typer.echo(f"\nForge auto-wire ({'DRY-RUN' if dry_run else 'APPLY'}): {project_root}")
    typer.echo("-" * 60)
    typer.echo(f"  both-gaps found:  {gaps_report.get('both_gap_count', 0)}")
    typer.echo(f"  attempted:        {len(targets)}")
    typer.echo(f"  wired:            {wired}")
    typer.echo(f"  skipped (errors): {skipped}")
    for r in results:
        status = "OK " if not r.get("errors") else "ERR"
        typer.echo(f"  [{status}] {r.get('module', '?')}.{r.get('function', '?')}")
        for e in r.get("errors", []):
            typer.echo(f"       ! {e}", err=True)
    for line in ruff_results:
        typer.echo(f"  {line}")
    if not dry_run and wired:
        typer.echo("\n  Run: forge certify --project . to verify the wiring")


@app.command("dead-code")
def dead_code_cmd(
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    package: Annotated[str, typer.Option(
        "--package", help="Package subdirectory to scan (auto-detected if omitted).")] = "",
    include_imports: Annotated[bool, typer.Option(
        "--imports", help="Include unused imports.")] = False,
    include_variables: Annotated[bool, typer.Option(
        "--vars", help="Include unused module-level variables.")] = False,
    confidence_threshold: Annotated[float, typer.Option(
        "--confidence", help="Minimum confidence to report (60-100).")] = 60.0,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Find defined-but-unreferenced symbols (dead code detector, vulture synthesis)."""
    from ..a1_at_functions.dead_code_check import check_dead_code
    report = check_dead_code(
        project_root,
        package=package or None,
        include_imports=include_imports,
        include_variables=include_variables,
        confidence_threshold=confidence_threshold,
    )
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    if not report.get("available"):
        typer.echo(f"dead-code unavailable: {report.get('reason', 'unknown')}")
        return
    typer.echo(f"\nForge dead-code: {project_root}")
    typer.echo("-" * 60)
    typer.echo(f"  package:          {report['package']}")
    typer.echo(f"  files scanned:    {report['files_scanned']}")
    typer.echo(f"  dead symbols:     {report['dead_symbol_count']}")
    dist = report.get("dead_by_kind", {})
    typer.echo(f"  by kind:  functions={dist.get('function', 0)}  classes={dist.get('class', 0)}")
    for sym in report.get("dead_symbols", [])[:20]:
        typer.echo(f"    [{sym['confidence']:>3}%] {sym['kind']:10s} {sym['qualname']}")
    if report.get("parse_errors"):
        typer.echo(f"\n  parse errors: {len(report['parse_errors'])}")


@app.command("maintainability")
def maintainability_cmd(
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    package: Annotated[str, typer.Option(
        "--package", help="Package subdirectory (auto-detected if omitted).")] = "",
    top_n: Annotated[int, typer.Option(
        "--top-n", help="Number of worst/best modules to surface.")] = 15,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Compute Maintainability Index per module (radon MI: A≥65, B≥40, C≥20, D<20)."""
    from ..a1_at_functions.maintainability_index import compute_maintainability_index
    report = compute_maintainability_index(project_root, package=package or None, top_n=top_n)
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    if not report.get("available"):
        typer.echo(f"maintainability unavailable: {report.get('reason', 'unknown')}")
        return
    typer.echo(f"\nForge maintainability: {report['package']}")
    typer.echo("-" * 60)
    typer.echo(f"  modules scanned: {report['modules_scanned']}")
    typer.echo(f"  avg MI:          {report['avg_mi']}")
    typer.echo(f"  median MI:       {report['median_mi']}")
    dist = report.get("rank_distribution", {})
    typer.echo(f"  ranks:  A={dist.get('A', 0)}  B={dist.get('B', 0)}  C={dist.get('C', 0)}  D={dist.get('D', 0)}")
    worst = report.get("worst_modules", [])
    if worst:
        typer.echo("\n  ── Worst modules (lowest MI) ──")
        for m in worst[:top_n]:
            typer.echo(f"    [{m['rank']}] MI={m['mi_score']:5.1f}  CC={m['cc']:>3}  {m['path']}")


@app.command("concept-bridge")
def concept_bridge_cmd(
    harvest_json: Annotated[str, typer.Option(
        "--harvest-json", "-f",
        help="Path to forge harvest --json output file.")] = "",
    top_n: Annotated[int, typer.Option(
        "--top-n", help="Max synthesis plans to generate.")] = 10,
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Convert harvest candidates below TAU_TRUST into actionable synthesis plans."""
    from ..a1_at_functions.harvest_concept_bridge import run_concept_bridge
    report = run_concept_bridge(
        project_root,
        harvest_json_path=harvest_json or None,
        top_n=top_n,
    )
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    if not report.get("available", True):
        typer.echo(f"concept-bridge unavailable: {report.get('reason', 'unknown')}")
        return
    typer.echo(f"\nForge concept-bridge: {report.get('synthesis_plan_count', 0)} plans")
    typer.echo("-" * 60)
    typer.echo(f"  candidates analyzed: {report.get('total_candidates_analyzed', 0)}")
    typer.echo(f"  synthesis plans:     {report.get('synthesis_plan_count', 0)}")
    for plan in report.get("synthesis_plans", []):
        typer.echo(f"\n  [{plan['priority']:>3}] {plan['source_qualname']}")
        typer.echo(f"       concept:   {plan['concept']}")
        typer.echo(f"       suggest:   {plan['suggested_function']}({', '.join(plan['suggested_args'][:2])})")
        typer.echo(f"       cmd:       {plan['wire_stubs_cmd']}")
    if report.get("recommended_actions"):
        typer.echo("\n  ── Recommended next ──")
        for cmd in report["recommended_actions"]:
            typer.echo(f"    forge {cmd}")


@app.command("doc-update")
def doc_update_cmd(
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    sections: Annotated[str, typer.Option(
        "--sections",
        help=(
            "Comma-separated sections to update: "
            "readme,changelog,extended_docs. "
            "extended_docs patches IDE_INTEGRATION.md, WHITEPAPER.md, "
            "and docs/AGENTS_GUIDE.md."
        ),
    )] = "readme,changelog,extended_docs",
    dry_run: Annotated[bool, typer.Option(
        "--dry-run",
        help="Show what would change without writing.")] = False,
    json_out: Annotated[bool, typer.Option(
        "--json", help="Emit raw JSON.")] = False,
) -> None:
    """Regenerate bounded README, CHANGELOG, and extended doc sections from live metrics — zero LLM tokens."""
    from ..a1_at_functions.doc_auto_update import run_doc_auto_update
    section_tuple = tuple(s.strip() for s in sections.split(",") if s.strip())
    report = run_doc_auto_update(project_root, sections=section_tuple, dry_run=dry_run)
    if json_out:
        typer.echo(json.dumps(report, indent=2))
        return
    mode = "[DRY RUN] " if dry_run else ""
    total = report.get("total_changes", 0)
    typer.echo(f"{mode}doc-update: {total} change(s)")
    for section, result in report.get("results", {}).items():
        changes = result.get("changes", [])
        if changes:
            typer.echo(f"  {section}:")
            for c in changes:
                typer.echo(f"    • {c}")
        elif result.get("reason"):
            typer.echo(f"  {section}: {result['reason']}")
        else:
            typer.echo(f"  {section}: up to date")


@app.command("doc-drift")
def doc_drift_cmd(
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    json_out: Annotated[bool, typer.Option(
        "--json", help="Emit raw JSON.")] = False,
) -> None:
    """Detect stale MCP tool/action/test counts across README, WHITEPAPER, IDE_INTEGRATION, and AGENTS_GUIDE.

    Run this before `forge doc-update` to see what is out of date.
    Exits 1 when drift is detected so it can gate CI pipelines.
    """
    from ..a1_at_functions.doc_auto_update import detect_doc_drift
    report = detect_doc_drift(project_root)
    if json_out:
        typer.echo(json.dumps(report, indent=2))
        raise typer.Exit(1 if report.get("drift_count", 0) else 0)
    if not report.get("available"):
        typer.echo(f"doc-drift: unavailable — {report.get('reason', 'unknown')}")
        raise typer.Exit(1)
    drift_count = report.get("drift_count", 0)
    if drift_count == 0:
        typer.echo("doc-drift: all counts up to date")
        return
    typer.echo(f"doc-drift: {drift_count} stale value(s) found — run `forge doc-update` to fix")
    for item in report.get("drift_items", []):
        typer.echo(
            f"  {item['file']}:{item['line']} [{item['pattern']}] "
            f"found={item['found_value']} expected={item['expected_value']}"
        )
    raise typer.Exit(1)


@app.command("cna-check")
def cna_check_cmd(
    proposed_name: Annotated[str, typer.Argument(
        help="Symbol name you are about to create.")],
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    body: Annotated[str | None, typer.Option(
        "--body", help="Optional short description of the symbol.")] = None,
    package: Annotated[str | None, typer.Option(
        "--package", help="Python package sub-directory.")] = None,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Compose-Not-Add check — verify a symbol doesn't already exist.

    Before writing new code Forge checks whether an equivalent symbol
    already exists in the project.  Exits 1 on REJECT (duplicate found)
    so this can gate PR pipelines.
    """
    from ..a3_og_features.cna_check import cna_check
    report = cna_check(project_root=project_root, proposed_name=proposed_name,
                       proposed_body=body, package_subdir=package)
    if json_out:
        typer.echo(json.dumps(report.as_dict() if hasattr(report, "as_dict") else report,
                              indent=2, default=str))
        if hasattr(report, "verdict") and report.verdict == "REJECT":
            raise typer.Exit(code=1)
        return
    d = report.as_dict() if hasattr(report, "as_dict") else report
    verdict = d.get("verdict", "?")
    typer.echo(f"\nForge cna-check: {proposed_name}")
    typer.echo("-" * 60)
    typer.echo(f"  verdict:  {verdict}")
    for match in d.get("top_matches", [])[:5]:
        score = match.get("score", 0)
        name = match.get("qualname") or match.get("name", "?")
        typer.echo(f"    {score:.2f}  {name}")
    if verdict == "REJECT":
        raise typer.Exit(code=1)


@app.command("trust-gate")
def trust_gate_cmd(
    response_file: Annotated[Path | None, typer.Argument(
        help="File containing the LLM response to gate (omit to read stdin).",
        exists=False)] = None,
    known_capabilities: Annotated[str | None, typer.Option(
        "--capabilities",
        help="Comma-separated list of capabilities the agent is expected "
             "to have.  Claims outside this set lower the trust score.")] = None,
    pkg_prefix: Annotated[str, typer.Option(
        "--pkg-prefix",
        help="Local package prefix for import-claim validation.")] = "",
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Hallucination detector for LLM responses — trust-gated output.

    Reads an LLM response (from a file or stdin), scores it against
    known tool capabilities, and returns a trust verdict with a
    safe_to_act boolean.  Exits 1 when safe_to_act is False.
    """
    from ..a1_at_functions.trust_gate_response import gate_response
    if response_file is not None:
        try:
            text = response_file.read_text(encoding="utf-8")
        except OSError as exc:
            raise typer.BadParameter(f"could not read {response_file}: {exc}") from exc
    else:
        text = sys.stdin.read()
    caps = [c.strip() for c in known_capabilities.split(",")] if known_capabilities else None
    verdict = gate_response(text, known_capabilities=caps, local_pkg_prefix=pkg_prefix)
    from dataclasses import asdict
    d = asdict(verdict) if hasattr(verdict, "__dataclass_fields__") else {}
    safe = d.get("safe_to_act", True)
    score = d.get("score", 1.0)
    if json_out:
        typer.echo(json.dumps(d, indent=2, default=str))
        if not safe:
            raise typer.Exit(code=1)
        return
    typer.echo("\nForge trust-gate")
    typer.echo("-" * 60)
    typer.echo(f"  score:       {score:.3f}")
    typer.echo(f"  safe_to_act: {safe}")
    for finding in d.get("findings", []):
        if isinstance(finding, dict):
            typer.echo(f"  ⚠ {finding.get('message', finding)}")
    if not safe:
        raise typer.Exit(code=1)


@app.command("commit-compose")
def commit_compose_cmd(
    intent: Annotated[str, typer.Argument(
        help="One-line description of what changed and why.")],
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    commit_type: Annotated[str, typer.Option(
        "--type",
        help="ship | fix | refactor | docs | test | chore")] = "ship",
    body: Annotated[str, typer.Option(
        "--body", help="Optional extended commit body.")] = "",
    no_coauthor: Annotated[bool, typer.Option(
        "--no-coauthor",
        help="Omit the Co-Authored-By trailer.")] = False,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Generate a structured, Forge-signed commit message.

    Composes a commit message from intent + type, optionally attaches a
    Co-Authored-By trailer, and validates the result against the project's
    wisdom DB.  Prints the message ready to paste into ``git commit -m``.
    """
    from ..a3_og_features.commit_compose import compose_commit_message
    artifact = compose_commit_message(
        project_root=project_root,
        intent=intent,
        commit_type=commit_type,
        body=body,
        include_coauthor=not no_coauthor,
    )
    d = artifact.as_dict() if hasattr(artifact, "as_dict") else artifact
    if json_out:
        typer.echo(json.dumps(d, indent=2, default=str))
        return
    message = d.get("message") or d.get("commit_message") or str(d)
    typer.echo(message)


@app.command("sbom")
def sbom_cmd(
    project: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root (must contain pyproject.toml).")] = Path("."),
    out: Annotated[Path | None, typer.Option(
        "--out",
        help="Write the SBOM JSON to this path instead of stdout.")] = None,
    json_out: Annotated[bool, typer.Option(
        "--json", help="Pretty-print the SBOM JSON to stdout.")] = False,
) -> None:
    """Generate a CycloneDX 1.5 SBOM from pyproject.toml (Lane G G3)."""
    try:
        scout = harvest_repo(project)
    except Exception:  # noqa: BLE001
        scout = None
    sbom = emit_sbom(project_root=project, scout_report=scout)
    sbom_json = json.dumps(sbom, indent=2, default=str)
    if out is not None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(sbom_json, encoding="utf-8")
        typer.echo(f"SBOM written to {out}")
    elif json_out:
        typer.echo(sbom_json)
    else:
        # CycloneDX payload is nested under sbom['sbom']; the wrapper carries
        # only the schema_version + project_root + generated_at.
        cyclonedx = sbom.get("sbom", {})
        typer.echo(f"SBOM: {project.name}")
        typer.echo(f"  format:     CycloneDX {cyclonedx.get('specVersion', '1.5')}")
        typer.echo(f"  components: {len(cyclonedx.get('components', []))}")
        typer.echo(f"  schema:     {sbom.get('schema_version', '')}")
        typer.echo("  (use --json or --out to emit the full CycloneDX JSON)")


@app.command("diff")
def diff_cmd(
    left: Annotated[Path, typer.Argument(
        exists=True, file_okay=True, dir_okay=False, resolve_path=True,
        help="Left (baseline) Forge JSON manifest.")],
    right: Annotated[Path, typer.Argument(
        exists=True, file_okay=True, dir_okay=False, resolve_path=True,
        help="Right (candidate) Forge JSON manifest.")],
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Compare two Forge JSON manifests (scout/cherry/assimilate/wire/certify/synergy/emergent)."""
    def _load(p: Path) -> dict:
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise typer.BadParameter(
                format_hint("not_a_forge_manifest", path=p)
                + f"\n\nUnderlying parse error: {exc}"
            ) from exc
        if not isinstance(data, dict) or not isinstance(
                data.get("schema_version"), str) or not data["schema_version"].startswith(
                "atomadic-forge."):
            raise typer.BadParameter(
                format_hint("not_a_forge_manifest", path=p)
            )
        return data

    left_doc = _load(left)
    right_doc = _load(right)
    diff = diff_manifests(left_doc, right_doc)

    if json_out:
        typer.echo(json.dumps(diff, indent=2, default=str))
        return

    typer.echo(f"\nForge diff: {left.name} → {right.name}")
    typer.echo("-" * 60)
    typer.echo(f"  left:        {diff['left_schema']}")
    typer.echo(f"  right:       {diff['right_schema']}")
    typer.echo(f"  compatible:  {diff['compatible']}")
    if diff["summary"]:
        typer.echo("  summary:")
        for k, v in diff["summary"].items():
            if isinstance(v, str | int | float | bool) or v is None:
                typer.echo(f"    {k}: {v}")
            elif isinstance(v, dict):
                typer.echo(f"    {k}: {v}")
            elif isinstance(v, list):
                typer.echo(f"    {k}: {len(v)} item(s)")
    typer.echo(
        f"  +{len(diff['added'])} added / "
        f"-{len(diff['removed'])} removed / "
        f"~{len(diff['changed'])} changed"
    )


mcp_app = typer.Typer(no_args_is_help=True,
                       help="MCP server surface — speak Forge to coding agents.")


def _mcp_frame(payload: dict[str, object]) -> bytes:
    body = json.dumps(payload).encode("utf-8")
    return f"Content-Length: {len(body)}\r\n\r\n".encode("ascii") + body


def _mcp_doctor_report(project: Path) -> dict[str, object]:
    project = Path(project).resolve()
    stdin = io.BytesIO(
        _mcp_frame({"jsonrpc": "2.0", "id": 1, "method": "initialize"})
        + _mcp_frame({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
        + _mcp_frame({"jsonrpc": "2.0", "id": 3, "method": "shutdown"})
    )
    stdout = io.BytesIO()
    stderr = io.StringIO()
    rc = mcp_serve_stdio(
        project_root=project,
        stdin=stdin,
        stdout=stdout,
        stderr=stderr,
        env={},
    )
    raw = stdout.getvalue()
    response_count = raw.count(b"Content-Length:")
    ok = rc == 0 and response_count >= 3 and bool(TOOLS)
    forge_path = shutil.which("forge") or ""
    server_source = str(Path(mcp_serve_stdio.__code__.co_filename).resolve())
    protocol_source = str(Path(__file__).resolve())
    return {
        "schema_version": "atomadic-forge.mcp_doctor/v1",
        "verdict": "PASS" if ok else "FAIL",
        "forge_version": __version__,
        "project_root": str(project),
        "project_exists": project.exists(),
        "tool_count": len(TOOLS),
        "python_executable": sys.executable,
        "forge_command_path": forge_path,
        "server_module_path": server_source,
        "cli_module_path": protocol_source,
        "recommended_config": {
            "command": sys.executable,
            "args": [
                "-m", "atomadic_forge", "mcp", "serve",
                "--project", str(project),
            ],
        },
        "framed_stdio_smoke": "PASS" if response_count >= 3 else "FAIL",
        "response_count": response_count,
        "server_exit_code": rc,
        "stderr": stderr.getvalue().strip(),
        "next_command": (
            "restart the MCP host/editor if this command passes but the live "
            "agent connection is stale"
            if ok else
            f"forge mcp doctor --project {project} --json"
        ),
    }


@mcp_app.command("serve")
def mcp_serve_cmd(
    project: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root the MCP tools will operate against. "
             "Defaults to the current working directory.")] = Path("."),
) -> None:
    """Run the MCP stdio JSON-RPC server (Cursor / Claude Code / Aider / Devin).

    Add to your client's MCP config:

        {
          "mcpServers": {
            "atomadic-forge": {
              "command": "forge",
              "args": ["mcp", "serve", "--project", "/path/to/your/repo"]
            }
          }
        }

    Tools exposed (10) — each tool dispatches via action= (or op= for nexus; create takes named args):
      welcome   — RECOMMENDED FIRST CALL: full onboarding scan (score, violations,
                  narrative, capability showcase, safety net)
      explore   — understand/analyze/discover (9 actions):
                  recon | explain | call_graph | smell_scan | lineage |
                  harvest | synergy | scan | swarm
      audit     — quality gates + change safety (14 actions):
                  certify | wire | enforce | validate | guard | composite |
                  gate | health | check | score | tests | cna | rollback | diff
      plan      — orient + dev utilities (9 actions):
                  context | compose | policy | recipes | generate | apply |
                  locate | commit | scaffold
      transmute — FLAGSHIP spaghetti->certified pipeline (3 actions):
                  auto | cherry | finalize
      loop      — LLM iteration loops (4 actions):
                  iterate | resume | evolve | evolve_step
      hive      — multi-agent coordination (13 actions):
                  register | list | deactivate | observe | propose | vote |
                  needs_vote | result | recap | handoff_create | handoff_list |
                  enhance_propose | enhance_list
      wisdom    — institutional memory DB (5 actions):
                  record | query | list | recall | promote
      nexus     — AAAA-Nexus auth primitives (7 ops via op=):
                  identity_verify | federation_mint | authorize_action |
                  sys_trust_gate | contract_verify | lineage_record | ratchet_register
      create    — intent + seed repos -> shippable pip package
                  (named args: intent, seed_repos[], out_dir, package, top_n, run_certify)

    Legacy tool names are automatically redirected — existing callers keep working.

    Resources exposed (5):
      forge://docs/receipt           — Receipt v1 schema docs
      forge://docs/formalization     — AAM + BEP theorem citations
      forge://lineage/chain          — local Vanguard lineage chain
      forge://schema/receipt         — verdict enum + version constants
      forge://summary/blockers       — one-call 'what's blocking?' summary
    """
    rc = mcp_serve_stdio(project_root=project)
    if rc != 0:
        raise typer.Exit(code=rc)


@mcp_app.command("doctor")
def mcp_doctor_cmd(
    project: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root to smoke-test through the MCP stdio surface.")] = Path("."),
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Smoke-test MCP stdio framing, tool listing, and server startup.

    Example:

        forge mcp doctor --project . --json
    """
    report = _mcp_doctor_report(project)
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        if report["verdict"] != "PASS":
            raise typer.Exit(code=1)
        return
    typer.echo("\nForge MCP doctor")
    typer.echo("-" * 60)
    typer.echo(f"  verdict:      {report['verdict']}")
    typer.echo(f"  version:      {report['forge_version']}")
    typer.echo(f"  python:       {report['python_executable']}")
    typer.echo(f"  forge cmd:    {report['forge_command_path']}")
    typer.echo(f"  project:      {report['project_root']}")
    typer.echo(f"  tools:        {report['tool_count']}")
    typer.echo(f"  stdio frame:  {report['framed_stdio_smoke']}")
    typer.echo(f"  next:         {report['next_command']}")
    if report["verdict"] != "PASS":
        raise typer.Exit(code=1)


app.add_typer(mcp_app, name="mcp",
               help="MCP server surface — speak Forge to coding agents.")


worktree_app = typer.Typer(
    no_args_is_help=True,
    help="Agent worktree utilities — status before editing, release, or publish work.",
)


@worktree_app.command("status")
def worktree_status_cmd(
    project_root: Annotated[Path, typer.Argument(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root or any directory inside a git worktree.")] = Path("."),
    max_files: Annotated[int, typer.Option(
        "--max-files",
        help="Maximum dirty status lines to include.")] = 20,
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Report git, remote, version, and installed-command state.

    Example:

        forge worktree status . --json
    """
    report = worktree_status(project_root=project_root, max_files=max_files)
    if json_out:
        typer.echo(json.dumps(report, indent=2, default=str))
        return
    typer.echo("\nForge worktree status")
    typer.echo("-" * 60)
    typer.echo(f"  root:       {report.get('git_root') or report['project_root']}")
    typer.echo(f"  branch:     {report.get('branch') or '-'}")
    typer.echo(f"  upstream:   {report.get('upstream') or '-'}")
    typer.echo(
        f"  dirty:      {report['dirty']}  "
        f"ahead={report['ahead']} behind={report['behind']}"
    )
    typer.echo(
        f"  version:    pyproject={report.get('declared_version') or '-'}  "
        f"package={report.get('package_version') or '-'}"
    )
    typer.echo(f"  forge cmd:  {report.get('forge_command_version') or '-'}")
    typer.echo("  recommendations:")
    for item in report["recommendations"]:
        typer.echo(f"    - {item}")


app.add_typer(worktree_app, name="worktree",
               help="Agent worktree utilities.")

# Lane C W5 — `forge login` captures a paid Forge subscription key
# and stores it in ~/.atomadic-forge/credentials.toml. The MCP server
# at a3 gates `tools/call` on this key.
app.add_typer(_login_app, name="login",
               help="Capture a Forge subscription key (required by `forge mcp serve`).")

# Lane C W6 — `forge whoami` resolves the current auth state without
# burning a real tool call. Pairs with `forge login` so agents can
# verify what the gate is reading and where it came from.
app.add_typer(_whoami_app, name="whoami",
               help="Show the current Forge auth state — email, plan, source.")

# Lane C W7 — Codex 'Copilot's Copilot' surface as CLI verbs.
# Until 0.3.5 these were MCP-only (tools/call); now they're shell-runnable
# so any agent that can spawn Bash can sample the same intelligence.
for _verb_name, _verb_app, _verb_help in _COPILOTS_VERBS:
    app.add_typer(_verb_app, name=_verb_name, help=_verb_help)


def _check_optional_dep(module: str) -> str:
    try:
        __import__(module)
        return "ok"
    except ImportError:
        return "missing"


@app.command("doctor")
def doctor_cmd(
    json_out: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Environment diagnostic."""
    optional = {
        "complexipy": _check_optional_dep("complexipy"),
        "cryptography": _check_optional_dep("cryptography"),
        "tomli": _check_optional_dep("tomli"),
    }
    info = {
        "atomadic_forge_version": __version__,
        "python": sys.version.split()[0],
        "executable": sys.executable,
        "platform": sys.platform,
        "stdout_encoding": getattr(sys.stdout, "encoding", "?"),
        "optional_deps": optional,
    }
    if json_out:
        typer.echo(json.dumps(info, indent=2))
        return
    typer.echo("\nAtomadic Forge — doctor")
    for k, v in info.items():
        if k == "optional_deps":
            continue
        typer.echo(f"  {k:24s} {v}")
    typer.echo("  optional dependencies:")
    for dep, status in optional.items():
        mark = "✓" if status == "ok" else "✗"
        note = "" if status == "ok" else f"  (pip install {dep})"
        typer.echo(f"    {mark} {dep}{note}")


@app.command("cs1")
def cs1_cmd(
    project: Annotated[str, typer.Argument(help="Project root path.")] = ".",
    receipt: Annotated[Path | None, typer.Option("--receipt", help="Path to receipt.json.")] = None,
    out: Annotated[Path | None, typer.Option("--out", help="Output path for CS-1.md.")] = None,
    json_out: Annotated[bool, typer.Option("--json", help="Emit CS-1 as JSON instead of Markdown.")] = False,
) -> None:
    """Generate a Conformity Statement CS-1 v1 (EU AI Act / SR 11-7 / FDA PCCP / CMMC-AI)."""
    from ..a1_at_functions.cs1_renderer import render_cs1, render_cs1_markdown

    project_path = Path(project).resolve()
    if receipt is None:
        receipt = project_path / ".atomadic-forge" / "receipt.json"
    if not receipt.exists():
        typer.secho(
            f"Receipt not found at {receipt}.\n"
            f"Generate one first:\n"
            f"  forge certify {project_path} --emit-receipt {receipt}",
            fg="red", err=True,
        )
        raise typer.Exit(code=1)
    try:
        receipt_data = json.loads(receipt.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        typer.secho(f"Failed to load receipt: {exc}", fg="red", err=True)
        raise typer.Exit(code=1) from exc
    try:
        cs1 = render_cs1(receipt_data)
    except ValueError as exc:
        typer.secho(f"Receipt validation failed: {exc}", fg="red", err=True)
        raise typer.Exit(code=1) from exc
    if json_out:
        typer.echo(json.dumps(cs1, indent=2, default=str))
        return
    md = render_cs1_markdown(cs1)
    if out is None:
        out = project_path / ".atomadic-forge" / "CS-1.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(md, encoding="utf-8")
    typer.secho(f"\nForge CS-1 — Conformity Statement written to {out}", fg="green")


# Specialty sub-apps — registered lazily so any import error in one doesn't
# break the others.
def _register_specialty_apps() -> None:
    for module_path, name, help_text in (
        ("atomadic_forge.commands.demo", "demo",
         "One-shot launch-video verb: preset evolve + DEMO.md artifact."),
        ("atomadic_forge.commands.iterate", "iterate",
         "LLM ↔ Forge loop: intent → architecturally-coherent code."),
        ("atomadic_forge.commands.evolve", "evolve",
         "Recursive self-improvement: iterate N times, growing catalog."),
        ("atomadic_forge.commands.chat", "chat",
         "Chat with a Forge-aware AI copilot over optional repo context."),
        ("atomadic_forge.commands.emergent", "emergent",
         "Symbol-level composition discovery."),
        ("atomadic_forge.commands.materialize", "materialize",
         "Emergent candidates → shippable Python package (scaffold + certify)."),
        ("atomadic_forge.commands.create", "create",
         "One-command pipeline: intent + seed repos → shippable package."),
        ("atomadic_forge.commands.synergy", "synergy",
         "Feature-pair detection + auto-implement adapters."),
        ("atomadic_forge.commands.commandsmith", "commandsmith",
         "Auto-register / document / smoke CLI commands."),
        ("atomadic_forge.commands.feature_then_emergent", "feature-then-emergent",
         "Run any feature → fan its output into emergent scan."),
        ("atomadic_forge.commands.config_cmd", "config",
         "Configure Atomadic Forge — show / set / test config + wizard."),
        ("atomadic_forge.commands.audit", "audit",
         "Surface .atomadic-forge lineage: list / show / log."),
        ("atomadic_forge.commands.emergent_then_synergy", "emergent-then-synergy",
         "Run emergent → pipe JSON artifact to synergy."),
        ("atomadic_forge.commands.synergy_then_emergent", "synergy-then-emergent",
         "Run synergy → pipe JSON artifact to emergent."),
        ("atomadic_forge.commands.evolve_then_iterate", "evolve-then-iterate",
         "Run evolve → pipe JSON artifact to iterate."),
        # Round-4 / Round-5 cross-repo + guard surfaces — MCP tools
        # since v0.10.0; CLI wired here so demo paths and shell users
        # reach the same handlers.
        # Hyphenated and underscore aliases both registered so commandsmith
        # smoke + new-user muscle memory both find them. The underscore form
        # is the legacy name (kept stable for any external scripts).
        ("atomadic_forge.commands.recon_swarm", "recon-swarm",
         "Round-4: walk N repos, return unified scout."),
        ("atomadic_forge.commands.recon_swarm", "recon_swarm",
         "Alias of recon-swarm (legacy underscore form)."),
        ("atomadic_forge.commands.harvest", "harvest",
         "Round-4: cross-repo capability gap finder, trust-gated."),
        ("atomadic_forge.commands.emergent_swarm", "emergent-swarm",
         "Round-5: cross-repo emergent composition discovery."),
        ("atomadic_forge.commands.emergent_swarm", "emergent_swarm",
         "Alias of emergent-swarm (legacy underscore form)."),
        ("atomadic_forge.commands.guard_install", "guard-install",
         "Round-5: install four-layer architectural guard."),
        ("atomadic_forge.commands.guard_install", "guard_install",
         "Alias of guard-install (legacy underscore form)."),
        # v0.12 — single-source-of-truth surface artifact + drift CI gate.
        ("atomadic_forge.commands.surface", "surface",
         "Emit / check / diff the canonical Forge surface artifact."),
        # v0.49.0 — single-source-of-truth metrics artifact (live numbers
        # for README, CHANGELOG, welcome handshake, the worker, badges).
        ("atomadic_forge.commands.metrics", "metrics",
         "Emit forge_metrics.json — canonical metrics for all surfaces."),
        # v0.13 — wisdom DB: cross-session institutional memory.
        ("atomadic_forge.commands.wisdom", "wisdom",
         "Record / query / list / recall cross-session wisdom."),
        # v0.13.2 — hive sync: agent registry + consensus + observe.
        ("atomadic_forge.commands.hive", "hive",
         "Agent registry + consensus + observation pipeline."),
        # v0.14.0-alpha — local relay daemon (the no-stubs goal).
        ("atomadic_forge.commands.relay", "relay",
         "Local relay daemon — dispatch Worker-side jobs via local CLI."),
        # v0.14.0a9 — handoff: structured agent-to-agent context transfer.
        ("atomadic_forge.commands.handoff", "handoff",
         "Capture / list / show structured session handoffs."),
        # v0.14.0a11 — enhancement proposals (trust-gated, human-published).
        ("atomadic_forge.commands.enhancement", "enhancement",
         "Submit / list / show / publish Forge enhancement proposals."),
        # v0.14.0a12 — welcome: first-call handshake for any agent.
        ("atomadic_forge.commands.welcome", "welcome",
         "First-call handshake — scout + certify + wire packaged into one response."),
        # harvest-absorb: ingest any Python repo layout into Atomadic tiers.
        ("atomadic_forge.commands.absorb", "absorb",
         "Absorb any Python repo into a tier-organized Atomadic package."),
    ):
        try:
            mod = __import__(module_path, fromlist=["app"])
            sub_app = getattr(mod, "app", None)
            if sub_app is not None:
                app.add_typer(sub_app, name=name, help=help_text)
        except Exception as exc:  # noqa: BLE001
            typer.secho(f"[forge] could not register {name}: {exc}",
                         fg="yellow", err=True)


@app.command("bump")
def bump_cmd(
    part: Annotated[str, typer.Argument(
        help="Version part to increment: patch, minor, or major.")] = "patch",
    project_root: Annotated[Path, typer.Option(
        "--project",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
        help="Project root.")] = Path("."),
    push: Annotated[bool, typer.Option(
        "--push/--no-push",
        help="Push commit + tag to origin after bumping.")] = True,
    tag: Annotated[bool, typer.Option(
        "--tag/--no-tag",
        help="Create an annotated git tag.")] = True,
    dry_run: Annotated[bool, typer.Option(
        "--dry-run", help="Show what would change without writing.")] = False,
) -> None:
    """Bump version, regenerate all docs, commit, tag, and push in one command.

    Reads the current version from pyproject.toml, increments the requested
    part (default: patch), writes the new version, runs ``forge doc-update``
    (all sections), stages all touched files, commits, optionally tags, and
    pushes — with no manual steps required.

    Examples::

        forge bump               # patch: 0.56.0 → 0.56.1
        forge bump minor         # minor: 0.56.0 → 0.57.0
        forge bump major         # major: 0.56.0 → 1.0.0
        forge bump --no-push     # commit + tag locally only
        forge bump --dry-run     # preview without writing
    """
    import re as _re
    import subprocess as _sp

    root = Path(project_root).resolve()
    pyproject = root / "pyproject.toml"

    if not pyproject.exists():
        typer.echo("bump: pyproject.toml not found", err=True)
        raise typer.Exit(1)

    text = pyproject.read_text(encoding="utf-8")
    m = _re.search(r'^(version\s*=\s*")(\d+)\.(\d+)\.(\d+)(")', text, _re.MULTILINE)
    if not m:
        typer.echo("bump: could not parse version from pyproject.toml", err=True)
        raise typer.Exit(1)

    major, minor, patch_n = int(m.group(2)), int(m.group(3)), int(m.group(4))
    old_version = f"{major}.{minor}.{patch_n}"

    if part == "major":
        major += 1
        minor = 0
        patch_n = 0
    elif part == "minor":
        minor += 1
        patch_n = 0
    elif part == "patch":
        patch_n += 1
    else:
        typer.echo(f"bump: unknown part '{part}' — use patch, minor, or major", err=True)
        raise typer.Exit(1)

    new_version = f"{major}.{minor}.{patch_n}"
    typer.echo(f"bump: {old_version} → {new_version}")

    if dry_run:
        typer.echo(f"[DRY RUN] would write pyproject.toml v{new_version}, "
                   "run doc-update --sections readme changelog extended_docs, "
                   f"commit, {'tag v' + new_version + ', ' if tag else ''}{'push' if push else 'no push'}")
        return

    # 1. Write new version into pyproject.toml.
    new_text = text[: m.start(2)] + new_version + text[m.end(4):]
    pyproject.write_text(new_text, encoding="utf-8")

    # 2. Recompute forge_metrics.json — must happen before doc-update so that
    #    update_changelog() reads the correct new version, and so the committed
    #    artifact matches the live recompute in CI's Metrics Drift Gate.
    metrics_rv = _sp.run(
        ["python", "-m", "atomadic_forge.a4_sy_orchestration.cli", "metrics", "--apply"],
        cwd=str(root), capture_output=True, text=True,
    )
    if metrics_rv.returncode != 0:
        typer.echo(f"bump: metrics --apply failed:\n{metrics_rv.stderr.strip()}", err=True)
        raise typer.Exit(1)
    typer.echo("bump: forge_metrics.json updated")

    # 2b. Regenerate surface.json — keeps Surface Drift Gate green.
    surface_rv = _sp.run(
        ["python", "-m", "atomadic_forge.a4_sy_orchestration.cli",
         "surface", "emit", "--out", "surface.json"],
        cwd=str(root), capture_output=True, text=True,
    )
    if surface_rv.returncode == 0:
        typer.echo("bump: surface.json updated")
    else:
        typer.echo(f"bump: surface emit warning — {surface_rv.stderr.strip()[:80]}", err=True)

    # 3. Regenerate all doc sections (changelog prepends new version entry now
    #    that forge_metrics.json carries the correct package_version).
    from ..a1_at_functions.doc_auto_update import run_doc_auto_update
    doc_result = run_doc_auto_update(
        root, sections=("readme", "changelog", "extended_docs"),
    )
    doc_total = doc_result.get("total_changes", 0)
    typer.echo(f"bump: docs updated ({doc_total} change(s))")

    # Report any residual drift so the user knows if a regex didn't fire.
    post_drift = doc_result.get("post_drift", {})
    if post_drift.get("drift_count", 0):
        typer.echo(f"  ⚠ post-update drift: {post_drift['drift_count']} item(s) still stale "
                   "— check doc_auto_update regexes", err=True)

    # 4. Stage all potentially-modified files.
    candidates = [
        "pyproject.toml", "forge_metrics.json", "surface.json",
        "README.md", "CHANGELOG.md",
        "WHITEPAPER.md", "docs/IDE_INTEGRATION.md", "docs/AGENTS_GUIDE.md",
    ]
    to_add = [c for c in candidates if (root / c).exists()]
    _sp.run(["git", "add"] + to_add, cwd=str(root), check=True)

    # 5. Commit.
    commit_msg = f"release: v{new_version}"
    _sp.run(["git", "commit", "-m", commit_msg], cwd=str(root), check=True)
    typer.echo(f"bump: committed '{commit_msg}'")

    # 6. Tag.
    tag_name = f"v{new_version}"
    if tag:
        _sp.run(
            ["git", "tag", "-a", tag_name, "-m", f"Release {tag_name}"],
            cwd=str(root), check=True,
        )
        typer.echo(f"bump: tagged {tag_name}")

    # 7. Push.
    if push:
        _sp.run(["git", "push", "origin", "main"], cwd=str(root), check=True)
        if tag:
            _sp.run(["git", "push", "origin", tag_name], cwd=str(root), check=True)
        typer.echo(f"bump: pushed to origin (tag: {tag_name if tag else 'none'})")

    typer.echo(f"bump: v{new_version} live ✓")


_register_specialty_apps()


def main() -> None:
    """Console-script entry."""
    _force_utf8()
    app()


if __name__ == "__main__":
    main()
