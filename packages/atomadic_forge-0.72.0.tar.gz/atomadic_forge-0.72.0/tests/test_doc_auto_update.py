"""Tests for a1 doc_auto_update: zero-token doc section regeneration."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from atomadic_forge.a1_at_functions.doc_auto_update import (
    _build_changelog_block,
    _build_metrics_table,
    _count_cli_verbs,
    _count_mcp_actions_per_tool,
    _load_metrics,
    run_doc_auto_update,
    update_changelog,
    update_readme,
)


@pytest.fixture()
def tmp_project(tmp_path: Path) -> Path:
    """Minimal project with forge_metrics.json, README.md, CHANGELOG.md."""
    metrics = {
        "schema_version": "atomadic-forge.metrics/v1",
        "package_version": "0.55.0",
        "mcp_tools": 10,
        "mcp_actions": 78,
        "cli_verbs": 82,
        "source_files": 225,
        "source_lines": 43000,
        "test_functions": 1490,
        "test_files": 106,
        "lean_theorems": {"count": 0, "files": 0, "found": False},
        "monadic_tiers": 5,
    }
    (tmp_path / "forge_metrics.json").write_text(json.dumps(metrics), encoding="utf-8")

    readme = """\
# Atomadic Forge

## CLI Commands

**80 CLI verbs total.** Full reference here.

---

## MCP Server — 10 Tools, 76 Actions

| Tool | Actions | What it does |
|------|---------|-------------|
| `explore` | 16 | Analyze |
| `audit` | 19 | Quality gates |

---

## By the Numbers

> Docs.

| Metric | Value |
|--------|-------|
| MCP tools | **10 tools · 76 actions** |
| CLI verbs | **80** |
| Source files | **221** (~42K LOC) |
| Tests | **1,465 passing** across **97 test files** |
| Lean4 formal proofs | not yet active |
| Monadic tiers | **5** (a0 → a4, strict upward-only composition) |
| Languages | Python, JS/TS, Swift, Kotlin, Go, Rust |
| Infrastructure cost | **$5/mo** |
| Self-score | **100/100** certify · 0 wire violations |
| License | BSL 1.1 (Apache 2.0 after 2030-04-27) |

Forge eats its own cooking.

---
"""
    (tmp_path / "README.md").write_text(readme, encoding="utf-8")

    changelog = """\
# Changelog

## Unreleased

## v0.54.0 — 2026-05-07 — Synthesis pipeline

### Added
- surface_gaps
"""
    (tmp_path / "CHANGELOG.md").write_text(changelog, encoding="utf-8")
    return tmp_path


# ── unit tests ────────────────────────────────────────────────────────────────

def test_load_metrics(tmp_project: Path) -> None:
    m = _load_metrics(tmp_project)
    assert m["package_version"] == "0.55.0"
    assert m["mcp_tools"] == 10


def test_load_metrics_missing(tmp_path: Path) -> None:
    m = _load_metrics(tmp_path)
    assert m == {}


def test_build_metrics_table_contains_key_values() -> None:
    metrics = {
        "mcp_tools": 10, "mcp_actions": 78, "cli_verbs": 82,
        "source_files": 225, "source_lines": 43000,
        "test_functions": 1490, "test_files": 106,
        "lean_theorems": {"count": 0, "files": 0},
        "monadic_tiers": 5,
    }
    table = _build_metrics_table(metrics)
    assert "78 actions" in table
    assert "82" in table
    assert "1490 passing" in table


def test_build_changelog_block_format() -> None:
    block = _build_changelog_block("0.55.0", ["abc1234 feat: add doc-update"])
    assert "v0.55.0" in block
    assert "doc-update" in block
    assert "### Changed" in block


def test_update_readme_dry_run(tmp_project: Path) -> None:
    result = update_readme(tmp_project, dry_run=True)
    assert result["available"]
    assert result["dry_run"]
    # Dry run should report changes but not write
    original = (tmp_project / "README.md").read_text()
    assert "82" not in original.split("CLI verbs total")[0].split("\n")[-1]


def test_update_readme_writes(tmp_project: Path) -> None:
    result = update_readme(tmp_project, dry_run=False)
    assert result["available"]
    readme = (tmp_project / "README.md").read_text()
    assert "**82 CLI verbs total.**" in readme
    assert "78 actions" in readme


def test_update_changelog_prepends_new_version(tmp_project: Path) -> None:
    result = update_changelog(tmp_project, dry_run=False)
    assert result["available"]
    changelog = (tmp_project / "CHANGELOG.md").read_text()
    assert "v0.55.0" in changelog
    # New version should appear before old
    assert changelog.index("v0.55.0") < changelog.index("v0.54.0")


def test_update_changelog_skips_if_already_documented(tmp_project: Path) -> None:
    # Set metrics version to match existing CHANGELOG entry
    metrics = json.loads((tmp_project / "forge_metrics.json").read_text())
    metrics["package_version"] = "0.54.0"
    (tmp_project / "forge_metrics.json").write_text(json.dumps(metrics))

    result = update_changelog(tmp_project, dry_run=False)
    assert result["available"]
    assert result.get("reason") and "already documented" in result["reason"]


def test_run_doc_auto_update_full(tmp_project: Path) -> None:
    result = run_doc_auto_update(tmp_project, sections=("readme", "changelog"), dry_run=True)
    assert result["available"]
    assert result["schema_version"] == "atomadic-forge.doc_auto_update/v1"
    assert "readme" in result["results"]
    assert "changelog" in result["results"]


def test_count_cli_verbs_real_project() -> None:
    real_root = Path(__file__).parents[1]
    count = _count_cli_verbs(real_root)
    assert count > 20  # forge cli has many commands (@app.command decorators)


def test_count_mcp_actions_per_tool_real_project() -> None:
    real_root = Path(__file__).parents[1]
    counts = _count_mcp_actions_per_tool(real_root)
    assert counts.get("explore", 0) > 10
    assert counts.get("audit", 0) > 10
