"""Adapter registry. Add new adapters here so the CLI can find them."""

from __future__ import annotations

from typing import Callable

from bench.adapters.base import PerceptionAdapter


def _lazy(loader: Callable[[], type[PerceptionAdapter]]):
    """Defer importing playwright until the adapter is actually used."""
    return loader


def _playwright_baseline_loader():
    from bench.adapters.playwright_baseline import PlaywrightBaselineAdapter
    return PlaywrightBaselineAdapter


def _playwright_filtered_loader():
    from bench.adapters.playwright_filtered import PlaywrightFilteredAdapter
    return PlaywrightFilteredAdapter


def _perceive_loader():
    from bench.adapters.perceive_adapter import PerceiveAdapter
    return PerceiveAdapter


def _perceive_mcp_loader():
    from bench.adapters.perceive_mcp import PerceiveMCPAdapter
    return PerceiveMCPAdapter


def _playwright_mcp_loader():
    from bench.adapters.playwright_mcp import PlaywrightMCPAdapter
    return PlaywrightMCPAdapter


def _chrome_devtools_mcp_loader():
    from bench.adapters.chrome_devtools_mcp import ChromeDevToolsMCPAdapter
    return ChromeDevToolsMCPAdapter


def _agent_browser_loader():
    from bench.adapters.agent_browser import AgentBrowserAdapter
    return AgentBrowserAdapter


REGISTRY: dict[str, Callable[[], type[PerceptionAdapter]]] = {
    "playwright_baseline": _lazy(_playwright_baseline_loader),
    "playwright_filtered": _lazy(_playwright_filtered_loader),
    "playwright_mcp": _lazy(_playwright_mcp_loader),
    "chrome_devtools_mcp": _lazy(_chrome_devtools_mcp_loader),
    "agent_browser": _lazy(_agent_browser_loader),
    "perceive": _lazy(_perceive_loader),
    "perceive_mcp": _lazy(_perceive_mcp_loader),
}


def get_adapter(name: str) -> PerceptionAdapter:
    if name not in REGISTRY:
        available = ", ".join(REGISTRY.keys())
        raise KeyError(f"Unknown adapter '{name}'. Available: {available}")
    return REGISTRY[name]()()


def list_adapters() -> list[str]:
    return sorted(REGISTRY.keys())
