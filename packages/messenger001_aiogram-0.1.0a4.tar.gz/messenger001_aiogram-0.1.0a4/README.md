# messenger001-aiogram

**aiogram-совместимый SDK для [Messenger001](https://messenger001.ru) Bot API.**
Перенеси свой Telegram-бот на aiogram в Messenger001 **заменой одного импорта**.

> ⚠️ Alpha. API стабилизируется. Используй для пилотов и экспериментов.

## Установка

```bash
pip install messenger001-aiogram   # позже, после публикации на PyPI
# Сейчас:
pip install git+https://github.com/maratmost/messenger001-aiogram.git
```

## Миграция существующего TG-бота

```diff
- from aiogram import Bot, Dispatcher, F
- from aiogram.filters import Command, CommandStart
- from aiogram.types import Message, CallbackQuery
- from aiogram.utils.keyboard import InlineKeyboardBuilder
+ from messenger001_aiogram import Bot, Dispatcher, F, InlineKeyboardBuilder
+ from messenger001_aiogram.filters import Command, CommandStart
+ from messenger001_aiogram.types import Message, CallbackQuery
```

Handlers, фильтры, inline-клавиатуры, FSM — остаются без изменений.

## Пример

```python
import asyncio, os
from messenger001_aiogram import Bot, Dispatcher, F, InlineKeyboardBuilder, Message, start_webhook
from messenger001_aiogram.filters import CommandStart

dp = Dispatcher()

@dp.message(CommandStart())
async def start(msg: Message):
    kb = InlineKeyboardBuilder()
    kb.button(text="Ping", callback_data="ping")
    await msg.answer("Привет!", reply_markup=kb.as_markup())

async def main():
    async with Bot(token=os.environ["M001_TOKEN"]) as bot:
        await start_webhook(dp, bot, port=8080)

asyncio.run(main())
```

См. [examples/echo_bot.py](examples/echo_bot.py) для полного примера.

## Меню команд

Зарегистрируй команды бота — в чате с ботом появится кнопка меню слева от поля ввода, `/команды` в тексте станут кликабельными, а ввод `/` покажет автокомплит.

```python
from messenger001_aiogram import BotCommand

async with Bot(token=TOKEN) as bot:
    await bot.set_my_commands([
        BotCommand(command="start", description="Начать работу"),
        BotCommand(command="help",  description="Помощь"),
    ])
```

## Что поддерживается (v0.1)

| aiogram | messenger001-aiogram |
|---------|----------------------|
| `Bot(token)` | ✅ |
| `bot.send_message / send_photo / send_document / send_video / send_audio` | ✅ |
| `bot.edit_message_text / edit_message_reply_markup` | ✅ |
| `bot.answer_callback_query / send_chat_action / get_me` | ✅ |
| `bot.set_my_commands / get_my_commands / delete_my_commands` | ✅ |
| `Dispatcher`, `Router`, `include_router` | ✅ |
| `@dp.message(...)`, `@dp.callback_query(...)` | ✅ |
| `Command`, `CommandStart(deep_link=True)` | ✅ |
| `F.data == "..."`, `F.text.startswith(...)` | ✅ (подмножество) |
| `InlineKeyboardBuilder`, `InlineKeyboardMarkup` | ✅ |
| `State`, `StatesGroup`, `FSMContext`, `MemoryStorage` | ✅ |
| Webhook receiver (aiohttp) + HMAC-verify | ✅ |
| `bot.start_polling(...)` | ❌ (M001 — webhook-only) |
| Reply-клавиатура | ❌ (нет на платформе) |
| Forwarding, polls, stickers | ❌ (нет на платформе) |

## Подключение

1. **Создай бота.** Открой в Messenger001 чат с **@botfather** → `/newbot` → получи токен. Сохрани его в env-переменную `M001_TOKEN`.

2. **Напиши код бота.** Используй пример выше или скопируй [examples/echo_bot.py](examples/echo_bot.py).

3. **Запусти бота на сервере с публичным HTTPS** (VPS, Railway, Render, Fly.io). Скрипт должен слушать `POST /webhook` на публично доступном URL. Для production используй systemd / supervisor / docker, чтобы процесс автоматически рестартился.

   ```bash
   python your_bot.py
   ```

4. **Зарегистрируй webhook у @botfather.** В том же чате: `/mybots` → выбери бота → «Webhook URL» → укажи `https://your-host/webhook`.

5. **Готово.** Пиши боту в Messenger001 — он отвечает.

## Лицензия

MIT © Marat Khusainov
