"""MLDock CLI — manage datasets, trainers, models and training jobs from your terminal."""

__version__ = "0.1.0"
__author__ = "Kreateyou Technologies Ltd"
