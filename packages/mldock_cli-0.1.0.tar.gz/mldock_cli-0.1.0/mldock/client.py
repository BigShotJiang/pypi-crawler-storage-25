"""HTTP client — wraps requests with auth headers and structured error handling."""

from __future__ import annotations

from typing import Any, Optional
import requests

from .auth import get_token, get_base_url, clear_session, AuthError


class ApiError(Exception):
    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


def _api_url(path: str, base_url: Optional[str] = None) -> str:
    base = (base_url or get_base_url()).rstrip("/")
    return f"{base}/api/v1/{path.lstrip('/')}"


def request(
    method: str,
    path: str,
    *,
    json_body: Any = None,
    data: Any = None,
    files: Any = None,
    params: Any = None,
    base_url: Optional[str] = None,
    require_auth: bool = True,
    token: Optional[str] = None,
    timeout: int = 60,
) -> Any:
    """Make an authenticated API request. Returns parsed JSON or raises ApiError."""
    headers: dict = {}
    if require_auth:
        tok = token or get_token()
        headers["Authorization"] = f"Bearer {tok}"

    url = _api_url(path, base_url)
    resp = requests.request(
        method.upper(),
        url,
        headers=headers,
        json=json_body,
        data=data,
        files=files,
        params=params,
        timeout=timeout,
    )

    if resp.status_code == 401:
        clear_session()
        raise AuthError("Session expired. Run `mldock login` to re-authenticate.")

    if resp.status_code == 204:
        return None

    try:
        body = resp.json()
    except Exception:
        body = {"message": resp.text}

    if not resp.ok:
        # Try structured error envelope first
        err = body.get("error") or body.get("detail") or body
        msg = err.get("message") if isinstance(err, dict) else str(err)
        raise ApiError(msg or f"HTTP {resp.status_code}", resp.status_code)

    return body


def get(path: str, **kwargs) -> Any:
    return request("GET", path, **kwargs)


def post(path: str, **kwargs) -> Any:
    return request("POST", path, **kwargs)


def patch(path: str, **kwargs) -> Any:
    return request("PATCH", path, **kwargs)


def delete(path: str, **kwargs) -> Any:
    return request("DELETE", path, **kwargs)
