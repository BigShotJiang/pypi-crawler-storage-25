"""mldock model commands — list, info, predict, rollback, delete."""

from __future__ import annotations

import json
import sys
from typing import Optional

import click

from .. import client
from ..utils.output import console, success, error, info, make_table


@click.group("model")
def model_group() -> None:
    """Manage deployed models."""


@model_group.command("list")
@click.option("--json", "as_json", is_flag=True)
def list_models(as_json: bool) -> None:
    """List all deployed models in your workspace."""
    try:
        data = client.get("models")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    items = data if isinstance(data, list) else data.get("items", [])
    if not items:
        info("No models deployed yet. Train a model first.")
        return

    if as_json:
        console.print_json(json.dumps(items))
        return

    t = make_table("Trainer", "Version", "Status", "Endpoint", "Deployed")
    for m in items:
        endpoint = f"/api/v1/predict/{m.get('trainer_name', '')}".rstrip("/")
        t.add_row(
            m.get("trainer_name", "—"),
            m.get("version", "—"),
            _status_badge(m.get("status", "—")),
            endpoint,
            _fmt_date(m.get("deployed_at")),
        )
    console.print(t)


@model_group.command("info")
@click.argument("deployment_id")
def model_info(deployment_id: str) -> None:
    """Show details about a specific deployment."""
    try:
        data = client.get(f"models/{deployment_id}")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    from rich.table import Table
    from rich import box
    t = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    t.add_column("Key", style="dim")
    t.add_column("Value", style="bold")
    for k, v in data.items():
        if k not in ("_id",):
            t.add_row(k, str(v)[:120])
    console.print(t)


@model_group.command("predict")
@click.argument("trainer_name")
@click.option("--input", "-i", "input_data", required=True,
              help="JSON input payload for the model")
@click.option("--api-key", "-k", default=None, envvar="MLDOCK_API_KEY",
              help="API key (uses session token if not set)")
def predict(trainer_name: str, input_data: str, api_key: Optional[str]) -> None:
    """Run inference against a deployed model."""
    try:
        parsed = json.loads(input_data)
    except json.JSONDecodeError:
        error("--input must be valid JSON.")
        sys.exit(1)

    info(f"Running inference on [bold]{trainer_name}[/]…")
    try:
        if api_key:
            # Use the public API key endpoint
            result = client.post(
                f"api/inference/{trainer_name}",
                json_body=parsed,
                token=api_key,
            )
        else:
            result = client.post(f"predict/{trainer_name}", json_body=parsed)
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    console.print("\n[bold]Result:[/]")
    console.print_json(json.dumps(result))


@model_group.command("rollback")
@click.argument("deployment_id")
@click.confirmation_option(prompt="Roll back this deployment?")
def rollback(deployment_id: str) -> None:
    """Roll back a deployment to the previous version."""
    try:
        client.post(f"models/{deployment_id}/rollback")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)
    success(f"Deployment [bold]{deployment_id[:12]}…[/] rolled back.")


@model_group.command("delete")
@click.argument("deployment_id")
@click.confirmation_option(prompt="Delete this deployment? This cannot be undone.")
def delete_model(deployment_id: str) -> None:
    """Delete a deployed model."""
    try:
        client.delete(f"models/{deployment_id}")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)
    success(f"Deployment [bold]{deployment_id[:12]}…[/] deleted.")


@model_group.command("metrics")
@click.argument("deployment_id")
def model_metrics(deployment_id: str) -> None:
    """Show production metrics for a deployed model."""
    try:
        data = client.get(f"models/{deployment_id}/metric-history")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)
    console.print_json(json.dumps(data))


def _status_badge(status: str) -> str:
    colors = {
        "running": "[green]running[/]",
        "active": "[green]active[/]",
        "stopped": "[yellow]stopped[/]",
        "failed": "[red]failed[/]",
    }
    return colors.get(status, status)


def _fmt_date(iso: Optional[str]) -> str:
    if not iso:
        return "—"
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%b %d, %Y")
    except Exception:
        return iso[:10]
