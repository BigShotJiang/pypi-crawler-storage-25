"""mldock train commands — start, status, logs, list."""

from __future__ import annotations

import json
import sys
import time
from typing import Optional

import click

from .. import client
from ..utils.output import console, success, error, info, warn, make_table


@click.group("train")
def train_group() -> None:
    """Trigger and monitor training jobs."""


@train_group.command("start")
@click.argument("trainer_name")
@click.option("--dataset", "-d", default=None, help="Dataset ID to use for training")
@click.option("--params", "-p", default=None,
              help='JSON hyperparameters, e.g. \'{"lr": 0.01, "epochs": 10}\'')
@click.option("--gpu", is_flag=True, help="Request GPU compute")
@click.option("--follow", "-f", is_flag=True, help="Stream status until job completes")
def start_training(
    trainer_name: str,
    dataset: Optional[str],
    params: Optional[str],
    gpu: bool,
    follow: bool,
) -> None:
    """Start a training job for a trainer."""
    body: dict = {"trainer_name": trainer_name}
    if dataset:
        body["dataset_id"] = dataset
    if gpu:
        body["use_gpu"] = True
    if params:
        try:
            body["hyperparams"] = json.loads(params)
        except json.JSONDecodeError:
            error("--params must be valid JSON.")
            sys.exit(1)

    info(f"Starting training job for [bold]{trainer_name}[/]…")
    try:
        data = client.post("training/start", json_body=body)
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    job_id = data.get("job_id") or data.get("id", "—")
    success(f"Training job queued: [bold]{job_id}[/]")
    console.print(f"  Trainer: {trainer_name}")
    if dataset:
        console.print(f"  Dataset: {dataset[:12]}…")

    if follow:
        _follow_job(job_id)
    else:
        info(f"Track progress: mldock train status {job_id}")


@train_group.command("status")
@click.argument("job_id")
@click.option("--follow", "-f", is_flag=True, help="Poll until complete")
def job_status(job_id: str, follow: bool) -> None:
    """Check the status of a training job."""
    if follow:
        _follow_job(job_id)
        return

    try:
        data = client.get(f"training/jobs/{job_id}")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    _print_job(data)


@train_group.command("list")
@click.option("--limit", default=20, help="Number of jobs to show")
@click.option("--json", "as_json", is_flag=True)
def list_jobs(limit: int, as_json: bool) -> None:
    """List recent training jobs."""
    try:
        data = client.get("training/jobs", params={"limit": limit})
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    items = data if isinstance(data, list) else data.get("items", [])
    if not items:
        info("No training jobs found.")
        return

    if as_json:
        console.print_json(json.dumps(items))
        return

    t = make_table("Job ID", "Trainer", "Status", "Duration", "Started")
    for j in items:
        t.add_row(
            str(j.get("id", "—"))[:12] + "…",
            j.get("trainer_name", "—"),
            _status_badge(j.get("status", "—")),
            _duration(j.get("started_at"), j.get("completed_at")),
            _fmt_date(j.get("started_at")),
        )
    console.print(t)


@train_group.command("cancel")
@click.argument("job_id")
@click.confirmation_option(prompt="Cancel this training job?")
def cancel_job(job_id: str) -> None:
    """Cancel a running training job."""
    try:
        client.post(f"training/jobs/{job_id}/cancel")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)
    success(f"Job [bold]{job_id[:12]}…[/] cancelled.")


# ── Helpers ────────────────────────────────────────────────────────────────────

def _follow_job(job_id: str, poll_interval: int = 4, timeout: int = 3600) -> None:
    deadline = time.time() + timeout
    terminal = {"completed", "failed", "cancelled", "error"}
    last_status = ""

    with console.status(f"[dim]Waiting for job {job_id[:12]}…[/]", spinner="dots") as spin:
        while time.time() < deadline:
            try:
                data = client.get(f"training/jobs/{job_id}")
                status = data.get("status", "unknown")
                if status != last_status:
                    spin.update(f"[dim]{status}…[/]")
                    last_status = status
                if status in terminal:
                    console.print()
                    _print_job(data)
                    if status == "completed":
                        success("Training complete!")
                    else:
                        error(f"Job ended with status: {status}")
                    return
            except Exception:
                pass
            time.sleep(poll_interval)
    warn("Timed out waiting for job. Check manually with `mldock train status`.")


def _print_job(data: dict) -> None:
    from rich.table import Table
    from rich import box
    t = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    t.add_column("Key", style="dim")
    t.add_column("Value", style="bold")
    for k in ("id", "trainer_name", "status", "started_at", "completed_at", "error"):
        v = data.get(k)
        if v is not None:
            t.add_row(k, str(v)[:120])
    console.print(t)


def _status_badge(status: str) -> str:
    colors = {
        "completed": "[green]completed[/]",
        "running": "[cyan]running[/]",
        "queued": "[yellow]queued[/]",
        "failed": "[red]failed[/]",
        "cancelled": "[dim]cancelled[/]",
    }
    return colors.get(status, status)


def _duration(start: Optional[str], end: Optional[str]) -> str:
    if not start:
        return "—"
    try:
        from datetime import datetime
        s = datetime.fromisoformat(start.replace("Z", "+00:00"))
        e = datetime.fromisoformat(end.replace("Z", "+00:00")) if end else datetime.utcnow().replace(tzinfo=s.tzinfo)
        secs = int((e - s).total_seconds())
        if secs < 60:
            return f"{secs}s"
        return f"{secs // 60}m {secs % 60}s"
    except Exception:
        return "—"


def _fmt_date(iso: Optional[str]) -> str:
    if not iso:
        return "—"
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%b %d %H:%M")
    except Exception:
        return iso[:16]
