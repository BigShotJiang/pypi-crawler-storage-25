"""mldock dataset commands — upload, list, pull, create, delete."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import click

from .. import client
from ..utils.output import console, success, error, info, warn, make_table


@click.group("dataset")
def dataset_group() -> None:
    """Manage training datasets."""


@dataset_group.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
def list_datasets(as_json: bool) -> None:
    """List all datasets in your workspace."""
    try:
        data = client.get("datasets")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    items = data.get("items", data) if isinstance(data, dict) else data
    if not items:
        info("No datasets found. Upload one with `mldock dataset upload <path>`.")
        return

    if as_json:
        console.print_json(json.dumps(items))
        return

    t = make_table("ID", "Name", "Entries", "Visibility", "Created")
    for d in items:
        t.add_row(
            d.get("id", "")[:12] + "…",
            d.get("name", "—"),
            str(d.get("entry_count", "—")),
            d.get("visibility", "—"),
            _fmt_date(d.get("created_at")),
        )
    console.print(t)


@dataset_group.command("create")
@click.argument("name")
@click.option("--description", "-d", default="", help="Dataset description")
@click.option("--visibility", type=click.Choice(["private", "public"]), default="private")
def create_dataset(name: str, description: str, visibility: str) -> None:
    """Create a new empty dataset."""
    try:
        data = client.post("datasets", json_body={
            "name": name,
            "description": description,
            "visibility": visibility,
        })
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    success(f"Dataset created: [bold]{data.get('name')}[/]")
    console.print(f"  ID:  [cyan]{data.get('id')}[/]")
    console.print(f"  Visibility: {data.get('visibility', 'private')}")


@dataset_group.command("upload")
@click.argument("path", type=click.Path(exists=True))
@click.option("--dataset-id", "-d", required=True, help="Target dataset ID")
@click.option("--label", "-l", default="", help="Optional label for entries")
def upload_dataset(path: str, dataset_id: str, label: str) -> None:
    """Upload a CSV or JSON file as dataset entries."""
    file_path = Path(path)
    suffix = file_path.suffix.lower()

    if suffix not in (".csv", ".json", ".jsonl"):
        error("Supported formats: .csv, .json, .jsonl")
        sys.exit(1)

    info(f"Uploading {file_path.name} → dataset {dataset_id[:12]}…")

    # Parse file into entries
    entries: list[dict] = []
    try:
        if suffix == ".csv":
            import csv
            with open(file_path, newline="", encoding="utf-8") as f:
                entries = list(csv.DictReader(f))
        elif suffix == ".jsonl":
            with open(file_path, encoding="utf-8") as f:
                entries = [json.loads(line) for line in f if line.strip()]
        else:
            with open(file_path, encoding="utf-8") as f:
                raw = json.load(f)
                entries = raw if isinstance(raw, list) else [raw]
    except Exception as e:
        error(f"Failed to parse file: {e}")
        sys.exit(1)

    if not entries:
        error("File is empty or contains no records.")
        sys.exit(1)

    info(f"Parsed {len(entries)} entries. Uploading in batches…")

    # Upload in batches of 200
    batch_size = 200
    total = 0
    from tqdm import tqdm
    for i in tqdm(range(0, len(entries), batch_size), desc="Uploading", unit="batch"):
        batch = entries[i: i + batch_size]
        try:
            client.post(f"datasets/{dataset_id}/entries/bulk", json_body={"entries": batch})
            total += len(batch)
        except client.ApiError as e:
            error(f"Upload failed at batch {i // batch_size + 1}: {e}")
            sys.exit(1)

    success(f"Uploaded {total} entries to dataset [bold]{dataset_id[:12]}…[/]")


@dataset_group.command("pull")
@click.argument("dataset_id")
@click.option("--output", "-o", default=".", help="Output directory (default: current dir)")
@click.option("--format", "fmt", type=click.Choice(["csv", "jsonl"]), default="csv")
def pull_dataset(dataset_id: str, output: str, fmt: str) -> None:
    """Download a dataset to your local machine."""
    out_dir = Path(output)
    out_dir.mkdir(parents=True, exist_ok=True)

    info(f"Fetching dataset {dataset_id[:12]}…")
    try:
        meta = client.get(f"datasets/{dataset_id}")
        name = meta.get("name", dataset_id)

        # Paginate entries
        all_entries: list[dict] = []
        page = 1
        while True:
            resp = client.get(f"datasets/{dataset_id}/entries", params={"page": page, "page_size": 500})
            batch = resp.get("items", []) if isinstance(resp, dict) else resp
            if not batch:
                break
            all_entries.extend(batch)
            if len(batch) < 500:
                break
            page += 1
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    if not all_entries:
        warn("Dataset has no entries.")
        return

    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)
    if fmt == "csv":
        import csv
        out_file = out_dir / f"{safe_name}.csv"
        with open(out_file, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(all_entries[0].keys()))
            w.writeheader()
            w.writerows(all_entries)
    else:
        out_file = out_dir / f"{safe_name}.jsonl"
        with open(out_file, "w", encoding="utf-8") as f:
            for entry in all_entries:
                f.write(json.dumps(entry) + "\n")

    success(f"Downloaded {len(all_entries)} entries → [bold]{out_file}[/]")


@dataset_group.command("delete")
@click.argument("dataset_id")
@click.confirmation_option(prompt="Delete this dataset? This cannot be undone.")
def delete_dataset(dataset_id: str) -> None:
    """Delete a dataset permanently."""
    try:
        client.delete(f"datasets/{dataset_id}")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)
    success(f"Dataset {dataset_id[:12]}… deleted.")


@dataset_group.command("info")
@click.argument("dataset_id")
def dataset_info(dataset_id: str) -> None:
    """Show details about a dataset."""
    try:
        data = client.get(f"datasets/{dataset_id}")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    from rich.table import Table
    from rich import box
    t = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    t.add_column("Key", style="dim")
    t.add_column("Value", style="bold")
    for k, v in data.items():
        if k not in ("_id",):
            t.add_row(k, str(v)[:120])
    console.print(t)


def _fmt_date(iso: Optional[str]) -> str:
    if not iso:
        return "—"
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%b %d, %Y")
    except Exception:
        return iso[:10]
