"""mldock trainer commands — publish, list, test locally."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import click

from .. import client
from ..auth import get_token, get_base_url
from ..utils.output import console, success, error, info, warn, make_table


@click.group("trainer")
def trainer_group() -> None:
    """Manage and publish trainers."""


@trainer_group.command("list")
@click.option("--json", "as_json", is_flag=True)
def list_trainers(as_json: bool) -> None:
    """List all trainers in your workspace."""
    try:
        data = client.get("trainers")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    items = data if isinstance(data, list) else data.get("items", [])
    if not items:
        info("No trainers found. Publish one with `mldock trainer publish <file>`.")
        return

    if as_json:
        console.print_json(json.dumps(items))
        return

    t = make_table("Name", "Status", "Framework", "Last Trained", "Deployments")
    for tr in items:
        t.add_row(
            tr.get("name", "—"),
            _status_badge(tr.get("status", "—")),
            tr.get("framework", "—"),
            _fmt_date(tr.get("last_trained_at")),
            str(tr.get("deployment_count", 0)),
        )
    console.print(t)


@trainer_group.command("publish")
@click.argument("file", type=click.Path(exists=True))
@click.option("--name", "-n", default=None, help="Override trainer name (default: filename stem)")
@click.option("--description", "-d", default="")
@click.option("--wait", is_flag=True, help="Wait for scan and approval")
def publish_trainer(file: str, name: Optional[str], description: str, wait: bool) -> None:
    """Upload and publish a trainer file to your MLDock workspace."""
    path = Path(file)
    if path.suffix != ".py":
        error("Trainer must be a .py file.")
        sys.exit(1)

    trainer_name = name or path.stem
    info(f"Publishing trainer [bold]{trainer_name}[/] from {path.name}…")

    try:
        with open(path, "rb") as f:
            data = client.post(
                "trainers/upload",
                files={"file": (path.name, f, "text/plain")},
                data={"name": trainer_name, "description": description},
                require_auth=True,
            )
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    success(f"Trainer [bold]{trainer_name}[/] uploaded.")
    status = data.get("status", "pending")
    console.print(f"  Status: [yellow]{status}[/]")

    if status == "pending":
        console.print("  [dim]Trainer is queued for security scan. "
                      "Run `mldock trainer info {trainer_name}` to check status.[/]")

    if wait:
        _wait_for_scan(trainer_name)


@trainer_group.command("info")
@click.argument("name")
def trainer_info(name: str) -> None:
    """Show details about a trainer."""
    try:
        data = client.get(f"trainers/{name}")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)

    from rich.table import Table
    from rich import box
    t = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    t.add_column("Key", style="dim")
    t.add_column("Value", style="bold")
    for k, v in data.items():
        if k not in ("_id", "plugin_file"):
            t.add_row(k, str(v)[:120])
    console.print(t)


@trainer_group.command("delete")
@click.argument("name")
@click.confirmation_option(prompt="Deactivate this trainer?")
def delete_trainer(name: str) -> None:
    """Deactivate a trainer."""
    try:
        client.delete(f"trainers/{name}")
    except client.ApiError as e:
        error(str(e))
        sys.exit(1)
    success(f"Trainer [bold]{name}[/] deactivated.")


@trainer_group.command("test")
@click.argument("file", type=click.Path(exists=True))
@click.option("--input", "-i", "input_data", default='{"text": "hello"}',
              help="JSON input to pass to predict() (default: {\"text\": \"hello\"})")
@click.option("--dataset", "-d", default=None,
              help="Local CSV/JSON file to mount as training data")
@click.option("--remote-dataset", "-r", default=None,
              help="Remote MLDock dataset ID to download and mount")
def test_trainer(file: str, input_data: str, dataset: Optional[str],
                 remote_dataset: Optional[str]) -> None:
    """
    Test a trainer locally — runs predict() in an isolated environment.

    If Docker is available: spins up a container (kept alive to avoid cold starts).
    Otherwise: creates a virtualenv in ~/.mldock/envs/<trainer_name>/ and reuses it.
    """
    path = Path(file)

    try:
        parsed_input = json.loads(input_data)
    except json.JSONDecodeError:
        error(f"--input must be valid JSON. Got: {input_data}")
        sys.exit(1)

    dataset_path = Path(dataset) if dataset else None
    if dataset_path and not dataset_path.exists():
        error(f"Dataset file not found: {dataset_path}")
        sys.exit(1)

    from ..utils.local_runner import run_local_test
    run_local_test(
        trainer_path=path,
        input_data=parsed_input,
        dataset_path=dataset_path,
        dataset_id=remote_dataset,
        base_url=get_base_url() if remote_dataset else None,
        token=get_token() if remote_dataset else None,
    )


@trainer_group.command("train")
@click.argument("file", type=click.Path(exists=True))
@click.option("--dataset", "-d", required=True, type=click.Path(exists=True),
              help="Path to local CSV dataset for training")
@click.option("--target", "-t", default="label",
              help="Target column name (default: label)")
@click.option("--params", "-p", default=None,
              help='JSON hyperparameters e.g. \'{"lr": 0.01, "epochs": 10}\'')
@click.option("--output", "-o", default=None,
              help="Save trained model pickle to this path (default: <trainer>.pkl)")
def train_local(file: str, dataset: str, target: str, params: Optional[str],
                output: Optional[str]) -> None:
    """
    Train a trainer locally on your machine.

    Runs inside Docker (if available) or a persistent virtualenv.
    The trained model is saved as a .pkl file for use with `mldock trainer serve`.
    """
    from pathlib import Path as P
    trainer_path = P(file)
    dataset_path = P(dataset)
    output_path = P(output) if output else trainer_path.with_suffix(".pkl")

    hyperparams: dict = {}
    if params:
        try:
            hyperparams = json.loads(params)
        except json.JSONDecodeError:
            error("--params must be valid JSON.")
            sys.exit(1)

    from ..utils.local_trainer import run_local_training
    run_local_training(
        trainer_path=trainer_path,
        dataset_path=dataset_path,
        target_col=target,
        hyperparams=hyperparams,
        output_path=output_path,
    )


@trainer_group.command("serve")
@click.argument("file", type=click.Path(exists=True))
@click.option("--model", "-m", default=None, type=click.Path(),
              help="Path to trained model pickle (default: <trainer>.pkl)")
@click.option("--port", default=8800, show_default=True,
              help="Local port to serve on")
def serve_local(file: str, model: Optional[str], port: int) -> None:
    """
    Serve a trainer as a local REST API (Docker or virtualenv).

    Starts a FastAPI server at http://localhost:<port>/predict.
    Kept alive until Ctrl-C.

    \b
    Examples:
      mldock trainer serve my_trainer.py
      mldock trainer serve my_trainer.py --model my_trainer.pkl --port 9000
    """
    from pathlib import Path as P
    trainer_path = P(file)
    model_path = P(model) if model else trainer_path.with_suffix(".pkl")
    if not model_path.exists():
        warn(f"No trained model found at {model_path}. "
             "Run `mldock trainer train` first, or start without a pickle.")
        model_path = None  # type: ignore[assignment]

    from ..utils.local_serve import serve_local as _serve
    _serve(trainer_path=trainer_path, model_pickle=model_path, port=port)


def _wait_for_scan(trainer_name: str, timeout: int = 120) -> None:
    import time
    info(f"Waiting for scan of [bold]{trainer_name}[/]…")
    deadline = time.time() + timeout
    with console.status("[dim]Scanning…[/]", spinner="dots"):
        while time.time() < deadline:
            try:
                data = client.get(f"trainers/{trainer_name}")
                status = data.get("status", "pending")
                if status in ("active", "live"):
                    success(f"Trainer [bold]{trainer_name}[/] is live!")
                    return
                if status in ("rejected", "failed"):
                    error(f"Trainer scan {status}. Check `mldock trainer info {trainer_name}`.")
                    sys.exit(1)
            except Exception:
                pass
            time.sleep(4)
    warn("Scan is taking longer than expected. Check status with `mldock trainer info`.")


def _status_badge(status: str) -> str:
    colors = {
        "active": "[green]active[/]",
        "live": "[green]live[/]",
        "pending": "[yellow]pending[/]",
        "rejected": "[red]rejected[/]",
        "failed": "[red]failed[/]",
    }
    return colors.get(status, status)


def _fmt_date(iso: Optional[str]) -> str:
    if not iso:
        return "—"
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%b %d, %Y")
    except Exception:
        return iso[:10]
