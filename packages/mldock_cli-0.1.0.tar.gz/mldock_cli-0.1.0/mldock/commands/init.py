"""mldock init — scaffold a new trainer project from a template."""

from __future__ import annotations

import sys
from pathlib import Path

import click

from ..utils.output import console, success, error, info, warn

# ── Templates ──────────────────────────────────────────────────────────────────

TEMPLATES = {
    "classifier": {
        "desc": "Tabular classification (scikit-learn / XGBoost / LightGBM)",
        "deps": ["scikit-learn", "pandas", "numpy"],
        "code": '''\
"""
{name} — tabular classifier trainer.

Train:   mldock trainer test {filename} --input '{{"feature_1": 1.0, "feature_2": 2.0}}'
Publish: mldock trainer publish {filename}
"""
from __future__ import annotations
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import pickle, os


class {class_name}:
    def __init__(self):
        self.model = None
        self.le = LabelEncoder()
        self.feature_cols: list[str] = []

    def train(self, dataset_path: str, target_col: str = "label", **kwargs) -> dict:
        df = pd.read_csv(dataset_path)
        self.feature_cols = [c for c in df.columns if c != target_col]
        X = df[self.feature_cols].fillna(0)
        y = self.le.fit_transform(df[target_col])

        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
        self.model = GradientBoostingClassifier(
            n_estimators=kwargs.get("n_estimators", 100),
            learning_rate=kwargs.get("lr", 0.1),
        )
        self.model.fit(X_train, y_train)
        acc = self.model.score(X_val, y_val)
        return {{"val_accuracy": round(acc, 4), "classes": list(self.le.classes_)}}

    def predict(self, input_data: dict) -> dict:
        if self.model is None:
            return {{"error": "model not trained"}}
        row = pd.DataFrame([[input_data.get(c, 0) for c in self.feature_cols]],
                           columns=self.feature_cols)
        probs = self.model.predict_proba(row)[0]
        predicted = self.le.inverse_transform([probs.argmax()])[0]
        return {{
            "prediction": predicted,
            "confidence": round(float(probs.max()), 4),
            "probabilities": {{cls: round(float(p), 4)
                              for cls, p in zip(self.le.classes_, probs)}},
        }}

    def save(self, path: str) -> None:
        import pickle
        with open(path, "wb") as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls, path: str) -> "{class_name}":
        import pickle
        with open(path, "rb") as f:
            return pickle.load(f)
''',
    },

    "regressor": {
        "desc": "Tabular regression (scikit-learn)",
        "deps": ["scikit-learn", "pandas", "numpy"],
        "code": '''\
"""
{name} — tabular regression trainer.

Train:   mldock trainer test {filename} --input '{{"feature_1": 1.0}}'
Publish: mldock trainer publish {filename}
"""
from __future__ import annotations
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error


class {class_name}:
    def __init__(self):
        self.model = None
        self.feature_cols: list[str] = []

    def train(self, dataset_path: str, target_col: str = "target", **kwargs) -> dict:
        df = pd.read_csv(dataset_path)
        self.feature_cols = [c for c in df.columns if c != target_col]
        X = df[self.feature_cols].fillna(0)
        y = df[target_col]

        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
        self.model = GradientBoostingRegressor(
            n_estimators=kwargs.get("n_estimators", 100),
            learning_rate=kwargs.get("lr", 0.1),
        )
        self.model.fit(X_train, y_train)
        mae = mean_absolute_error(y_val, self.model.predict(X_val))
        return {{"val_mae": round(float(mae), 4)}}

    def predict(self, input_data: dict) -> dict:
        if self.model is None:
            return {{"error": "model not trained"}}
        row = pd.DataFrame([[input_data.get(c, 0) for c in self.feature_cols]],
                           columns=self.feature_cols)
        pred = float(self.model.predict(row)[0])
        return {{"prediction": round(pred, 4)}}
''',
    },

    "text-classifier": {
        "desc": "Text / NLP classifier (TF-IDF + sklearn)",
        "deps": ["scikit-learn", "pandas", "numpy"],
        "code": '''\
"""
{name} — text classification trainer.

Train:   mldock trainer test {filename} --input '{{"text": "some input text"}}'
Publish: mldock trainer publish {filename}
"""
from __future__ import annotations
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder


class {class_name}:
    def __init__(self):
        self.pipeline = None
        self.le = LabelEncoder()

    def train(self, dataset_path: str, text_col: str = "text",
              target_col: str = "label", **kwargs) -> dict:
        df = pd.read_csv(dataset_path).dropna(subset=[text_col, target_col])
        X = df[text_col].astype(str)
        y = self.le.fit_transform(df[target_col])

        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
        self.pipeline = Pipeline([
            ("tfidf", TfidfVectorizer(max_features=20000, ngram_range=(1, 2))),
            ("clf",   LogisticRegression(max_iter=1000, C=kwargs.get("C", 1.0))),
        ])
        self.pipeline.fit(X_train, y_train)
        acc = self.pipeline.score(X_val, y_val)
        return {{"val_accuracy": round(acc, 4), "classes": list(self.le.classes_)}}

    def predict(self, input_data: dict) -> dict:
        if self.pipeline is None:
            return {{"error": "model not trained"}}
        text = input_data.get("text", "")
        probs = self.pipeline.predict_proba([text])[0]
        predicted = self.le.inverse_transform([probs.argmax()])[0]
        return {{
            "prediction": predicted,
            "confidence": round(float(probs.max()), 4),
        }}
''',
    },

    "image-classifier": {
        "desc": "Image classification (PyTorch / torchvision)",
        "deps": ["torch", "torchvision", "Pillow", "numpy"],
        "code": '''\
"""
{name} — image classification trainer (PyTorch).

Train:   mldock trainer test {filename} --input '{{"image_path": "./test.jpg"}}'
Publish: mldock trainer publish {filename}
"""
from __future__ import annotations
import os, json
import numpy as np
from PIL import Image
import torch
import torch.nn as nn
from torchvision import models, transforms
from torch.utils.data import DataLoader, Dataset


class {class_name}:
    def __init__(self, num_classes: int = 2):
        self.num_classes = num_classes
        self.model = None
        self.classes: list[str] = []
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])

    def train(self, dataset_path: str, epochs: int = 5, **kwargs) -> dict:
        """
        dataset_path: path to a directory with subfolders per class,
                      OR a CSV with columns: image_path, label
        """
        # Minimal stub — adapt to your dataset structure
        device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = models.efficientnet_b0(pretrained=False)
        self.model.classifier[1] = nn.Linear(self.model.classifier[1].in_features, self.num_classes)
        self.model = self.model.to(device)
        return {{"status": "training stub — implement DataLoader for your dataset"}}

    def predict(self, input_data: dict) -> dict:
        if self.model is None:
            return {{"error": "model not trained"}}
        img_path = input_data.get("image_path")
        if not img_path or not os.path.exists(img_path):
            return {{"error": f"image_path not found: {{img_path}}"}}

        img = Image.open(img_path).convert("RGB")
        tensor = self.transform(img).unsqueeze(0)
        with torch.no_grad():
            logits = self.model(tensor)
            probs = torch.softmax(logits, dim=1)[0].tolist()
        idx = int(np.argmax(probs))
        label = self.classes[idx] if self.classes else str(idx)
        return {{"prediction": label, "confidence": round(probs[idx], 4)}}
''',
    },

    "anomaly-detector": {
        "desc": "Anomaly / outlier detection (Isolation Forest)",
        "deps": ["scikit-learn", "pandas", "numpy"],
        "code": '''\
"""
{name} — anomaly detection trainer.

Train:   mldock trainer test {filename} --input '{{"value": 3.5, "feature": 1.0}}'
Publish: mldock trainer publish {filename}
"""
from __future__ import annotations
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler


class {class_name}:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.feature_cols: list[str] = []

    def train(self, dataset_path: str, contamination: float = 0.05, **kwargs) -> dict:
        df = pd.read_csv(dataset_path).select_dtypes(include=[np.number])
        self.feature_cols = list(df.columns)
        X = self.scaler.fit_transform(df.fillna(0))
        self.model = IsolationForest(contamination=contamination, random_state=42)
        self.model.fit(X)
        return {{"features": self.feature_cols, "contamination": contamination}}

    def predict(self, input_data: dict) -> dict:
        if self.model is None:
            return {{"error": "model not trained"}}
        row = np.array([[input_data.get(c, 0) for c in self.feature_cols]])
        row_scaled = self.scaler.transform(row)
        score = float(self.model.decision_function(row_scaled)[0])
        is_anomaly = self.model.predict(row_scaled)[0] == -1
        return {{
            "anomaly": bool(is_anomaly),
            "anomaly_score": round(score, 4),
            "threshold": "negative score = anomaly",
        }}
''',
    },
}

GITIGNORE = """\
__pycache__/
*.pyc
*.pyo
.env
.venv/
venv/
*.egg-info/
dist/
build/
.DS_Store
*.model
*.pkl
*.pt
*.h5
dataset*.csv
"""

DOTENV = """\
# MLDock CLI configuration
MLDOCK_BASE_URL=https://www.mldock.io
# MLDOCK_FRONTEND_URL=http://localhost:5200  # self-hosted only
# MLDOCK_API_KEY=your-api-key               # for inference calls
"""


# ── Command ────────────────────────────────────────────────────────────────────

@click.command("init")
@click.argument("project_name", default=".")
@click.option(
    "--template", "-t",
    type=click.Choice(list(TEMPLATES.keys())),
    default=None,
    help="Trainer template to scaffold",
)
def init_cmd(project_name: str, template: str | None) -> None:
    """
    Scaffold a new MLDock trainer project.

    \b
    Examples:
      mldock init                              # interactive, current dir
      mldock init my-project                   # creates my-project/ folder
      mldock init my-project -t classifier     # skip template picker
    """
    # Resolve output directory
    if project_name == ".":
        project_dir = Path.cwd()
        trainer_name = project_dir.name
    else:
        project_dir = Path.cwd() / project_name
        trainer_name = project_name

    # Sanitise name
    safe_name = "".join(c if c.isalnum() or c == "_" else "_" for c in trainer_name)
    class_name = "".join(word.capitalize() for word in safe_name.split("_"))
    filename = f"{safe_name}.py"

    # Pick template interactively if not specified
    if not template:
        console.print("\n[bold]Choose a trainer template:[/]\n")
        choices = list(TEMPLATES.keys())
        for i, key in enumerate(choices, 1):
            console.print(f"  [cyan]{i}[/]. [bold]{key}[/] — {TEMPLATES[key]['desc']}")
        console.print()
        while True:
            raw = click.prompt("Template number", default="1")
            try:
                idx = int(raw) - 1
                if 0 <= idx < len(choices):
                    template = choices[idx]
                    break
            except ValueError:
                pass
            warn("Enter a number from the list above.")

    tmpl = TEMPLATES[template]

    # Create directory
    if project_dir != Path.cwd():
        if project_dir.exists() and any(project_dir.iterdir()):
            error(f"Directory '{project_dir}' already exists and is not empty.")
            sys.exit(1)
        project_dir.mkdir(parents=True, exist_ok=True)

    # Write trainer file
    trainer_file = project_dir / filename
    code = tmpl["code"].format(
        name=safe_name,
        class_name=class_name,
        filename=filename,
    )
    trainer_file.write_text(code)

    # Write .env
    (project_dir / ".env").write_text(DOTENV)

    # Write .gitignore
    (project_dir / ".gitignore").write_text(GITIGNORE)

    # Write requirements.txt
    (project_dir / "requirements.txt").write_text("\n".join(tmpl["deps"]) + "\n")

    # Done
    console.print()
    success(f"Project scaffolded in [bold]{project_dir}[/]")
    console.print()
    console.print(f"  [dim]Trainer:[/]  {filename}")
    console.print(f"  [dim]Template:[/] {template} — {tmpl['desc']}")
    console.print(f"  [dim]Class:[/]    {class_name}")
    console.print()
    console.print("[bold]Next steps:[/]")
    if project_dir != Path.cwd():
        console.print(f"  cd {project_name}")
    console.print(f"  pip install {' '.join(tmpl['deps'])}")
    console.print(f"  mldock trainer test {filename} --input '{{}}' ")
    console.print(f"  mldock login")
    console.print(f"  mldock trainer publish {filename}")
    console.print()
