"""mldock login / logout / whoami commands."""

from __future__ import annotations

import sys
import time
import webbrowser

import click
import requests

from ..auth import save_session, clear_session, load_session, DEFAULT_BASE_URL, AuthError
from ..utils.output import console, success, error, info, warn


@click.command("login")
@click.option("--base-url", default=None, envvar="MLDOCK_BASE_URL",
              help="MLDock API base URL (default: https://www.mldock.io)")
@click.option("--frontend-url", default=None, envvar="MLDOCK_FRONTEND_URL",
              help="Override the browser login URL host (self-hosted: e.g. http://localhost:5200)")
@click.option("--no-browser", is_flag=True, help="Print the login URL instead of opening it")
def login_cmd(base_url: str | None, frontend_url: str | None, no_browser: bool) -> None:
    """Authenticate with MLDock via browser (device flow)."""
    base = (base_url or DEFAULT_BASE_URL).rstrip("/")

    console.print("\n[bold]Logging in to MLDock[/]")
    info(f"API: {base}")
    console.print()

    # Step 1: request a device code
    try:
        resp = requests.post(f"{base}/api/v1/auth/cli-session/request", timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        error(f"Could not reach MLDock API: {e}")
        sys.exit(1)

    device_code: str = data["device_code"]
    login_url: str = data["login_url"]
    expires_in: int = data.get("expires_in", 300)

    # For self-hosted instances the server's login_url may point to an
    # internal host/port (e.g. https://localhost:5443) that is unreachable
    # from the user's machine. --frontend-url overrides just the scheme+host+port.
    if frontend_url:
        from urllib.parse import urlparse, urlunparse
        parsed = urlparse(login_url)
        override = urlparse(frontend_url.rstrip("/"))
        login_url = urlunparse(parsed._replace(
            scheme=override.scheme,
            netloc=override.netloc,
        ))

    console.print(f"[bold cyan]Open this URL to sign in:[/]\n  {login_url}\n")

    if no_browser:
        warn("--no-browser set. Open the URL above manually.")
    else:
        try:
            webbrowser.open(login_url)
            info("Browser opened — sign in and authorize the CLI.")
        except Exception:
            warn("Could not open browser. Open the URL above manually.")

    # Step 2: poll until authorized or expired
    console.print()
    poll_url = f"{base}/api/v1/auth/cli-session/poll/{device_code}"
    deadline = time.time() + expires_in
    interval = 3

    with console.status("[dim]Waiting for authorization…[/]", spinner="dots"):
        while time.time() < deadline:
            try:
                poll = requests.get(poll_url, timeout=10)
                if poll.status_code == 200:
                    body = poll.json()
                    if body.get("status") == "authorized":
                        token: str = body["token"]
                        user: dict = body["user"]
                        save_session(token, user, base)
                        console.print()
                        success(f"Logged in as [bold]{user.get('email')}[/] ([dim]{user.get('role')}[/])")
                        console.print(f"  Org: [cyan]{user.get('org_id', '—')}[/]")
                        console.print()
                        return
            except Exception:
                pass
            time.sleep(interval)

    error("Login timed out. Run `mldock login` to try again.")
    sys.exit(1)


@click.command("logout")
def logout_cmd() -> None:
    """Clear the local MLDock session."""
    clear_session()
    success("Logged out. Session cleared.")


@click.command("whoami")
def whoami_cmd() -> None:
    """Show the currently authenticated user."""
    session = load_session()
    if not session or not session.get("token"):
        error("Not logged in. Run `mldock login` first.")
        sys.exit(1)

    user = session.get("user", {})
    base = session.get("base_url", DEFAULT_BASE_URL)

    from rich.table import Table
    from rich import box
    t = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    t.add_column("Key", style="dim")
    t.add_column("Value", style="bold")
    t.add_row("Email",   user.get("email", "—"))
    t.add_row("Name",    user.get("full_name", "—"))
    t.add_row("Role",    user.get("role", "—"))
    t.add_row("Org",     user.get("org_id", "—"))
    t.add_row("Server",  base)
    console.print(t)
