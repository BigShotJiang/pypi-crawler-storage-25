"""MLDock CLI — entry point."""

import click
from rich.console import Console

from . import __version__
from .commands.login import login_cmd, logout_cmd, whoami_cmd
from .commands.dataset import dataset_group
from .commands.trainer import trainer_group
from .commands.model import model_group
from .commands.train import train_group
from .commands.init import init_cmd

console = Console()

BANNER = """[bold blue]
  __  __ _     ____             _
 |  \\/  | |   |  _ \\  ___   ___| | __
 | |\\/| | |   | | | |/ _ \\ / __| |/ /
 | |  | | |___| |_| | (_) | (__|   <
 |_|  |_|_____|____/ \\___/ \\___|_|\\_\\
[/bold blue]
[dim]The complete ML lifecycle platform.[/dim]
"""


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="mldock")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """
    \b
    mldock — MLDock CLI

    Manage your ML lifecycle from the terminal:
      datasets, trainers, training jobs, and deployments.

    \b
    Quick start:
      mldock login                          Sign in via browser
      mldock dataset list                   List datasets
      mldock trainer publish my_model.py    Upload a trainer
      mldock train start my_model           Start training
      mldock model list                     View deployments
      mldock model predict my_model -i '{}'  Run inference
    """
    if ctx.invoked_subcommand is None:
        console.print(BANNER)
        click.echo(ctx.get_help())


# ── Auth commands ──────────────────────────────────────────────────────────────
cli.add_command(login_cmd,  name="login")
cli.add_command(logout_cmd, name="logout")
cli.add_command(whoami_cmd, name="whoami")

# ── Resource groups ────────────────────────────────────────────────────────────
cli.add_command(init_cmd,      name="init")
cli.add_command(dataset_group, name="dataset")
cli.add_command(trainer_group, name="trainer")
cli.add_command(model_group,   name="model")
cli.add_command(train_group,   name="train")


# ── Convenience top-level aliases ──────────────────────────────────────────────
@cli.command("status")
def platform_status() -> None:
    """Check MLDock platform connectivity."""
    from .auth import get_base_url, is_logged_in
    import requests

    base = get_base_url()
    console.print(f"[dim]Checking {base}…[/]")
    try:
        resp = requests.get(f"{base}/api/v1/health", timeout=8)
        if resp.ok:
            from .utils.output import success
            success(f"MLDock is reachable at {base}")
            if is_logged_in():
                from .auth import get_user
                u = get_user() or {}
                console.print(f"  Signed in as [bold]{u.get('email', '?')}[/]")
            else:
                console.print("  [yellow]Not signed in[/] — run `mldock login`")
        else:
            from .utils.output import warn
            warn(f"Server responded with HTTP {resp.status_code}")
    except Exception as e:
        from .utils.output import error
        error(f"Cannot reach {base}: {e}")
