"""Session management — read/write ~/.mldock/session.json."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from typing import Optional

SESSION_FILE = Path.home() / ".mldock" / "session.json"
DEFAULT_BASE_URL = os.environ.get("MLDOCK_BASE_URL", "https://www.mldock.io")


class AuthError(Exception):
    pass


def save_session(token: str, user: dict, base_url: str = DEFAULT_BASE_URL) -> None:
    SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
    SESSION_FILE.write_text(
        json.dumps({"token": token, "user": user, "base_url": base_url}, indent=2)
    )
    SESSION_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 600 — owner only


def clear_session() -> None:
    if SESSION_FILE.exists():
        SESSION_FILE.unlink()


def load_session() -> Optional[dict]:
    if not SESSION_FILE.exists():
        return None
    try:
        return json.loads(SESSION_FILE.read_text())
    except Exception:
        return None


def get_token() -> str:
    s = load_session()
    if not s or not s.get("token"):
        raise AuthError("Not logged in. Run `mldock login` first.")
    return s["token"]


def get_base_url() -> str:
    s = load_session()
    return (s or {}).get("base_url") or DEFAULT_BASE_URL


def get_user() -> Optional[dict]:
    s = load_session()
    return (s or {}).get("user")


def is_logged_in() -> bool:
    s = load_session()
    return bool(s and s.get("token"))
