"""
Local API server — serves a trained model as a REST endpoint on the user's machine.

Spawns a tiny FastAPI app that loads the trainer pickle and exposes:
  POST /predict  — runs trainer.predict(input_data)
  GET  /health   — liveness check
  GET  /info     — trainer metadata

Runs inside Docker (if available) or in a virtualenv process (cross-platform).
The server is kept alive until the user hits Ctrl-C.
"""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path
from typing import Optional

from .output import console, success, error, info, warn

SERVE_IMAGE = "python:3.11-slim"
SERVE_CONTAINER_PREFIX = "mldock-serve-"
SERVE_PORT = 8800


def _docker_available() -> bool:
    return shutil.which("docker") is not None


def _container_name(trainer_name: str) -> str:
    safe = "".join(c if c.isalnum() else "-" for c in trainer_name)
    return f"{SERVE_CONTAINER_PREFIX}{safe}"


def _server_script(trainer_filename: str, model_pickle: Optional[str]) -> str:
    """Generate the tiny FastAPI server script."""
    module_name = trainer_filename.replace(".py", "")
    load_block = ""
    if model_pickle:
        load_block = f"""
import pickle
with open(r'{model_pickle}', 'rb') as f:
    trainer = pickle.load(f)
print("[MLDock] Loaded trained model from pickle.")
"""
    else:
        load_block = f"""
import importlib, sys
sys.path.insert(0, '/workspace')
mod = importlib.import_module('{module_name}')
trainer_cls = None
for name in dir(mod):
    obj = getattr(mod, name)
    if isinstance(obj, type) and hasattr(obj, 'predict') and obj.__module__ == '{module_name}':
        trainer_cls = obj
        break
if not trainer_cls:
    raise RuntimeError("No trainer class found in {trainer_filename}")
trainer = trainer_cls()
print(f"[MLDock] Instantiated {{trainer_cls.__name__}} (not yet trained — call /train first).")
"""

    return textwrap.dedent(f"""
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import uvicorn, json

app = FastAPI(title="MLDock Local Server", version="0.1.0")

{load_block}

@app.get("/health")
def health():
    return {{"status": "ok", "trainer": "{module_name}"}}

@app.get("/info")
def info_route():
    return {{
        "trainer": "{module_name}",
        "has_model": trainer is not None,
        "predict_endpoint": "POST /predict",
    }}

@app.post("/predict")
async def predict(request: Request):
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({{"error": "Request body must be JSON"}}, status_code=400)
    try:
        result = trainer.predict(body)
        return result
    except Exception as e:
        return JSONResponse({{"error": str(e)}}, status_code=500)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port={SERVE_PORT})
""")


def serve_local(
    trainer_path: Path,
    model_pickle: Optional[Path] = None,
    port: int = SERVE_PORT,
    requirements: Optional[list[str]] = None,
) -> None:
    """Start a local REST API server for the trainer."""
    reqs = requirements or _detect_requirements(trainer_path)
    reqs = list(set(reqs + ["fastapi", "uvicorn[standard]"]))

    script = _server_script(trainer_path.name, str(model_pickle) if model_pickle else None)

    if _docker_available():
        _serve_docker(trainer_path, script, reqs, model_pickle, port)
    else:
        _serve_venv(trainer_path, script, reqs, model_pickle, port)


def _serve_docker(
    trainer_path: Path,
    script: str,
    reqs: list[str],
    model_pickle: Optional[Path],
    port: int,
) -> None:
    name = _container_name(trainer_path.stem)
    ws_dir = Path.home() / ".mldock" / "serve" / trainer_path.stem
    ws_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy(trainer_path, ws_dir / trainer_path.name)
    (ws_dir / "server.py").write_text(script)
    (ws_dir / "requirements.txt").write_text("\n".join(reqs))
    if model_pickle:
        shutil.copy(model_pickle, ws_dir / model_pickle.name)

    # Stop any existing container with the same name
    subprocess.run(["docker", "rm", "-f", name], capture_output=True)

    subprocess.run(["docker", "pull", SERVE_IMAGE], capture_output=True)

    console.print(f"\n[bold]Starting local API server[/] (Docker)")
    info(f"Container: {name}")
    info(f"Endpoint:  http://localhost:{port}/predict")
    console.print("[dim]Press Ctrl-C to stop.[/]\n")

    try:
        subprocess.run([
            "docker", "run", "--rm",
            "--name", name,
            "-p", f"{port}:{port}",
            "-v", f"{ws_dir}:/workspace",
            "-w", "/workspace",
            SERVE_IMAGE,
            "bash", "-c",
            f"pip install -q -r requirements.txt && python server.py",
        ])
    except KeyboardInterrupt:
        pass
    finally:
        subprocess.run(["docker", "rm", "-f", name], capture_output=True)
        info("Server stopped.")


def _serve_venv(
    trainer_path: Path,
    script: str,
    reqs: list[str],
    model_pickle: Optional[Path],
    port: int,
) -> None:
    env_dir = Path.home() / ".mldock" / "serve-envs" / trainer_path.stem
    env_dir.mkdir(parents=True, exist_ok=True)

    ws_dir = Path.home() / ".mldock" / "serve" / trainer_path.stem
    ws_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy(trainer_path, ws_dir / trainer_path.name)
    (ws_dir / "server.py").write_text(script)
    if model_pickle:
        shutil.copy(model_pickle, ws_dir / model_pickle.name)

    # Create venv if needed
    if not env_dir.exists() or not _venv_python(env_dir).exists():
        py = _get_python()
        subprocess.run([py, "-m", "venv", str(env_dir)], check=True)

    py = str(_venv_python(env_dir))

    # Install dependencies
    req_hash_file = env_dir / ".req_hash"
    import hashlib
    current_hash = hashlib.md5("\n".join(sorted(reqs)).encode()).hexdigest()[:8]
    if not req_hash_file.exists() or req_hash_file.read_text().strip() != current_hash:
        info("Installing server dependencies…")
        subprocess.run([py, "-m", "pip", "install", "-q"] + reqs, check=True)
        req_hash_file.write_text(current_hash)
        success("Dependencies ready.")
    else:
        info("Dependencies unchanged — skipping install.")

    console.print(f"\n[bold]Starting local API server[/] (virtualenv)")
    info(f"Endpoint:  http://localhost:{port}/predict")
    info(f"Docs:      http://localhost:{port}/docs")
    console.print("[dim]Press Ctrl-C to stop.[/]\n")

    env = os.environ.copy()
    env["PORT"] = str(port)
    try:
        subprocess.run([py, str(ws_dir / "server.py")], env=env)
    except KeyboardInterrupt:
        info("Server stopped.")


def _get_python() -> str:
    for candidate in ("python3", "python"):
        if shutil.which(candidate):
            return candidate
    error("No Python executable found.")
    sys.exit(1)


def _venv_python(env_dir: Path) -> Path:
    if platform.system() == "Windows":
        return env_dir / "Scripts" / "python.exe"
    return env_dir / "bin" / "python"


def _detect_requirements(trainer_path: Path) -> list[str]:
    source = trainer_path.read_text(errors="ignore")
    candidates = {
        "sklearn": "scikit-learn", "xgboost": "xgboost", "lightgbm": "lightgbm",
        "catboost": "catboost", "torch": "torch", "tensorflow": "tensorflow",
        "keras": "keras", "pandas": "pandas", "numpy": "numpy",
        "cv2": "opencv-python-headless", "PIL": "Pillow",
        "ultralytics": "ultralytics", "transformers": "transformers",
    }
    found = ["requests"]
    for imp, pkg in candidates.items():
        if f"import {imp}" in source or f"from {imp}" in source:
            found.append(pkg)
    return found
