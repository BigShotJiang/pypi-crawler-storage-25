"""
Local trainer test runner — cross-platform (macOS, Linux, Windows).

Strategy:
  1. If Docker is available → run in a container.
     The container is kept alive (not torn down) to avoid cold starts on repeat runs.
     On the next `mldock trainer test`, it re-executes inside the same running container.
  2. If Docker is NOT available → use a persistent virtualenv in ~/.mldock/envs/<trainer_name>/.
     Dependencies are installed once; subsequent runs skip reinstall if requirements haven't changed.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Optional

from .output import console, success, error, info, warn

DOCKER_IMAGE = "python:3.11-slim"
CONTAINER_PREFIX = "mldock-test-"
ENVS_DIR = Path.home() / ".mldock" / "envs"


# ── Docker path ────────────────────────────────────────────────────────────────

def _docker_available() -> bool:
    return shutil.which("docker") is not None


def _container_name(trainer_name: str) -> str:
    safe = "".join(c if c.isalnum() else "-" for c in trainer_name)
    return f"{CONTAINER_PREFIX}{safe}"


def _container_running(name: str) -> bool:
    result = subprocess.run(
        ["docker", "ps", "--filter", f"name={name}", "--format", "{{{{.Names}}}}"],
        capture_output=True, text=True,
    )
    return name in result.stdout


def _run_in_docker(trainer_path: Path, harness: str, requirements: list[str]) -> None:
    name = _container_name(trainer_path.stem)

    # Write workspace to a persistent temp dir per trainer
    ws_dir = Path.home() / ".mldock" / "workspaces" / trainer_path.stem
    ws_dir.mkdir(parents=True, exist_ok=True)

    # Write files
    shutil.copy(trainer_path, ws_dir / trainer_path.name)
    (ws_dir / "harness.py").write_text(harness)
    (ws_dir / "requirements.txt").write_text("\n".join(requirements))

    if not _container_running(name):
        info(f"Starting Docker container [bold]{name}[/] (kept alive for fast re-runs)…")
        # Pull image if needed (silently)
        subprocess.run(["docker", "pull", DOCKER_IMAGE], capture_output=True)
        # Start a sleeping container that we can exec into
        subprocess.run([
            "docker", "run", "-d",
            "--name", name,
            "-v", f"{ws_dir}:/workspace",
            "--rm",  # auto-remove when stopped
            DOCKER_IMAGE,
            "tail", "-f", "/dev/null",  # keep alive
        ], check=True, capture_output=True)
        # Install requirements once
        info("Installing dependencies (first run only)…")
        subprocess.run([
            "docker", "exec", name,
            "pip", "install", "-q", "-r", "/workspace/requirements.txt",
        ], check=True)
        success("Container ready.")
    else:
        info(f"Reusing running container [bold]{name}[/] (no cold start).")
        # Sync updated files
        subprocess.run([
            "docker", "cp", str(ws_dir / "harness.py"), f"{name}:/workspace/harness.py",
        ], capture_output=True)
        subprocess.run([
            "docker", "cp", str(trainer_path), f"{name}:/workspace/{trainer_path.name}",
        ], capture_output=True)

    # Run harness
    console.print()
    result = subprocess.run(
        ["docker", "exec", name, "python", "/workspace/harness.py"],
        text=True,
    )
    if result.returncode != 0:
        error("Test failed in container.")
        sys.exit(1)
    success("Local test complete (container still running — fast re-runs ready).")
    info(f"  Stop container: docker stop {name}")


# ── Virtualenv path ────────────────────────────────────────────────────────────

def _get_python() -> str:
    """Find a suitable python3 executable cross-platform."""
    for candidate in ("python3", "python"):
        if shutil.which(candidate):
            return candidate
    error("No Python executable found. Please install Python 3.9+.")
    sys.exit(1)


def _venv_python(env_dir: Path) -> str:
    if platform.system() == "Windows":
        return str(env_dir / "Scripts" / "python.exe")
    return str(env_dir / "bin" / "python")


def _req_hash(requirements: list[str]) -> str:
    return hashlib.md5("\n".join(sorted(requirements)).encode()).hexdigest()[:8]


def _run_in_venv(trainer_path: Path, harness: str, requirements: list[str]) -> None:
    env_dir = ENVS_DIR / trainer_path.stem
    hash_file = env_dir / ".req_hash"
    current_hash = _req_hash(requirements)

    if not env_dir.exists():
        info(f"Creating virtualenv at [bold]{env_dir}[/]…")
        python = _get_python()
        subprocess.run([python, "-m", "venv", str(env_dir)], check=True)

    py = _venv_python(env_dir)

    # Install requirements only if they changed
    if not hash_file.exists() or hash_file.read_text().strip() != current_hash:
        info("Installing dependencies…")
        req_txt = env_dir / "requirements.txt"
        req_txt.write_text("\n".join(requirements))
        subprocess.run([py, "-m", "pip", "install", "-q"] + requirements, check=True)
        hash_file.write_text(current_hash)
        success("Dependencies installed.")
    else:
        info("Dependencies unchanged — skipping install (fast re-run).")

    # Write harness next to trainer
    harness_path = env_dir / "harness.py"
    harness_path.write_text(harness)
    trainer_copy = env_dir / trainer_path.name
    shutil.copy(trainer_path, trainer_copy)

    console.print()
    result = subprocess.run([py, str(harness_path)], text=True)
    if result.returncode != 0:
        error("Test failed.")
        sys.exit(1)
    success("Local test complete (venv kept at ~/.mldock/envs/ for fast re-runs).")


# ── Public entry point ─────────────────────────────────────────────────────────

def run_local_test(
    trainer_path: Path,
    input_data: Any,
    dataset_path: Optional[Path] = None,
    dataset_id: Optional[str] = None,
    base_url: Optional[str] = None,
    token: Optional[str] = None,
) -> None:
    # Resolve remote dataset
    if dataset_id and base_url and token:
        dataset_path = _download_remote_dataset(dataset_id, base_url, token)

    requirements = _detect_requirements(trainer_path)
    harness = _build_harness(trainer_path.name, input_data, dataset_path)

    if _docker_available():
        info("Docker detected — using container runner.")
        _run_in_docker(trainer_path, harness, requirements)
    else:
        warn("Docker not available — using virtualenv runner.")
        _run_in_venv(trainer_path, harness, requirements)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _build_harness(trainer_filename: str, input_data: Any, dataset_path: Optional[Path]) -> str:
    module_name = trainer_filename.replace(".py", "")
    dataset_block = ""
    if dataset_path:
        # Use forward slashes for cross-platform path in the script string
        ds = str(dataset_path).replace("\\", "/")
        dataset_block = f"""
import pandas as pd
df = pd.read_csv(r'{ds}')
print(f"[MLDock] Dataset loaded: {{len(df)}} rows, {{list(df.columns)}}")
"""

    return f"""
import sys, json, traceback, importlib, os

# Ensure workspace is on path (both Docker /workspace and venv sibling dir)
for p in ['/workspace', os.path.dirname(os.path.abspath(__file__))]:
    if p not in sys.path:
        sys.path.insert(0, p)

print("[MLDock] Importing trainer {module_name}...")
try:
    mod = importlib.import_module('{module_name}')
    trainer_cls = None
    for name in dir(mod):
        obj = getattr(mod, name)
        if (isinstance(obj, type)
                and hasattr(obj, 'predict')
                and hasattr(obj, 'train')
                and obj.__module__ == '{module_name}'):
            trainer_cls = obj
            break
    if not trainer_cls:
        print("[MLDock] ERROR: No class with train() + predict() found in {trainer_filename}")
        sys.exit(1)
    print(f"[MLDock] Found: {{trainer_cls.__name__}}")
except Exception as e:
    print(f"[MLDock] Import error: {{e}}")
    traceback.print_exc()
    sys.exit(1)

{dataset_block}

print("[MLDock] Running predict()...")
try:
    trainer = trainer_cls()
    result = trainer.predict({json.dumps(input_data)})
    print("[MLDock] Result:")
    print(json.dumps(result, indent=2, default=str))
except Exception as e:
    print(f"[MLDock] predict() error: {{e}}")
    traceback.print_exc()
    sys.exit(1)

print("[MLDock] ✓ Test passed")
"""


def _detect_requirements(trainer_path: Path) -> list[str]:
    source = trainer_path.read_text(errors="ignore")
    candidates = {
        "sklearn": "scikit-learn",
        "xgboost": "xgboost",
        "lightgbm": "lightgbm",
        "catboost": "catboost",
        "torch": "torch",
        "tensorflow": "tensorflow",
        "keras": "keras",
        "pandas": "pandas",
        "numpy": "numpy",
        "cv2": "opencv-python-headless",
        "PIL": "Pillow",
        "ultralytics": "ultralytics",
        "transformers": "transformers",
    }
    found = ["requests"]
    for imp, pkg in candidates.items():
        if f"import {imp}" in source or f"from {imp}" in source:
            found.append(pkg)
    return found


def _download_remote_dataset(dataset_id: str, base_url: str, token: str) -> Optional[Path]:
    import requests as req
    info(f"Downloading remote dataset {dataset_id[:12]}…")
    try:
        resp = req.get(
            f"{base_url.rstrip('/')}/api/v1/datasets/{dataset_id}/entries",
            headers={"Authorization": f"Bearer {token}"},
            params={"page_size": 500},
            timeout=60,
        )
        resp.raise_for_status()
        entries = resp.json().get("items", [])
        if not entries:
            warn("Dataset has no entries.")
            return None

        import csv, io
        keys = list(entries[0].keys())
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=keys)
        w.writeheader()
        w.writerows(entries)

        tmp = tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w", encoding="utf-8")
        tmp.write(buf.getvalue())
        tmp.flush()
        success(f"Downloaded {len(entries)} entries.")
        return Path(tmp.name)
    except Exception as e:
        warn(f"Could not download dataset: {e}. Running without data.")
        return None
