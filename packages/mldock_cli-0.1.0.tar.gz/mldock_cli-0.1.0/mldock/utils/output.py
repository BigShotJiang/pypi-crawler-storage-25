"""Rich terminal output helpers."""

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

console = Console()
err_console = Console(stderr=True)


def success(msg: str) -> None:
    console.print(f"[bold green]✓[/] {msg}")


def error(msg: str) -> None:
    err_console.print(f"[bold red]✗[/] {msg}")


def info(msg: str) -> None:
    console.print(f"[dim]{msg}[/]")


def warn(msg: str) -> None:
    console.print(f"[bold yellow]![/] {msg}")


def header(title: str, subtitle: str = "") -> None:
    content = f"[bold]{title}[/]"
    if subtitle:
        content += f"\n[dim]{subtitle}[/]"
    console.print(Panel(content, border_style="blue", padding=(0, 1)))


def make_table(*columns: str, title: str = "") -> Table:
    t = Table(title=title, box=box.SIMPLE_HEAVY, show_header=True, header_style="bold cyan")
    for col in columns:
        t.add_column(col)
    return t
