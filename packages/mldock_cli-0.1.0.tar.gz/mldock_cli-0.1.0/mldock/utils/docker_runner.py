"""Local trainer testing via Docker — spins up a container, runs inference, tears it down."""

from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Optional

from ..utils.output import console, info, success, error, warn

DOCKER_IMAGE = "python:3.11-slim"
TEST_CONTAINER_NAME = "mldock-local-test"


def _docker_available() -> bool:
    try:
        import docker  # noqa: F401
        return True
    except ImportError:
        return False


def run_local_test(
    trainer_path: Path,
    input_data: Any,
    dataset_path: Optional[Path] = None,
    dataset_id: Optional[str] = None,
    base_url: Optional[str] = None,
    token: Optional[str] = None,
) -> None:
    """
    Test a trainer locally inside a Docker container.

    Steps:
      1. Pull python:3.11-slim
      2. Copy trainer file + a test harness script into a temp dir
      3. Run container, mount temp dir, run harness → prints prediction
      4. Remove container
    """
    if not _docker_available():
        error("docker Python SDK not installed. Run: pip install mldock[docker]")
        sys.exit(1)

    import docker as docker_sdk

    client = docker_sdk.from_env()

    # Resolve dataset
    dataset_csv: Optional[Path] = None
    if dataset_path:
        dataset_csv = dataset_path
    elif dataset_id and base_url and token:
        dataset_csv = _download_remote_dataset(dataset_id, base_url, token)

    with tempfile.TemporaryDirectory(prefix="mldock-test-") as tmpdir:
        tmp = Path(tmpdir)

        # Copy trainer
        import shutil
        shutil.copy(trainer_path, tmp / trainer_path.name)

        # Write test harness
        harness = _build_harness(trainer_path.name, input_data, dataset_csv)
        (tmp / "harness.py").write_text(harness)

        # Write requirements stub (detect from trainer imports)
        reqs = _detect_requirements(trainer_path)
        (tmp / "requirements.txt").write_text("\n".join(reqs))

        console.print(f"\n[bold]Running local test in Docker ({DOCKER_IMAGE})[/]")
        info(f"Trainer: {trainer_path.name}")
        info(f"Dataset: {dataset_csv or 'none (using random data)'}")
        console.print()

        try:
            # Run container
            output = client.containers.run(
                DOCKER_IMAGE,
                command=[
                    "bash", "-c",
                    "pip install -q -r /workspace/requirements.txt && "
                    "python /workspace/harness.py"
                ],
                volumes={str(tmp): {"bind": "/workspace", "mode": "rw"}},
                remove=True,
                stdout=True,
                stderr=True,
                name=TEST_CONTAINER_NAME,
            )
            console.print(output.decode() if isinstance(output, bytes) else output)
            success("Local test complete")
        except docker_sdk.errors.ContainerError as e:
            error("Container exited with error:")
            console.print(e.stderr.decode() if e.stderr else str(e))
            sys.exit(1)
        except docker_sdk.errors.ImageNotFound:
            error(f"Docker image {DOCKER_IMAGE} not found. Pull it with: docker pull {DOCKER_IMAGE}")
            sys.exit(1)


def _build_harness(trainer_filename: str, input_data: Any, dataset_path: Optional[Path]) -> str:
    module_name = trainer_filename.replace(".py", "")
    dataset_load = ""
    if dataset_path:
        dataset_load = f"""
import pandas as pd
df = pd.read_csv('/workspace/dataset.csv')
print(f"[MLDock] Dataset loaded: {{len(df)}} rows, {{list(df.columns)}}")
"""

    return f"""
import sys, json, traceback
sys.path.insert(0, '/workspace')

print("[MLDock] Importing trainer...")
try:
    import importlib
    mod = importlib.import_module('{module_name}')
    # Find the trainer class (subclass of BaseTrainer or with train/predict)
    trainer_cls = None
    for name in dir(mod):
        obj = getattr(mod, name)
        if isinstance(obj, type) and hasattr(obj, 'predict') and hasattr(obj, 'train') and obj.__module__ == '{module_name}':
            trainer_cls = obj
            break
    if not trainer_cls:
        print("[MLDock] ERROR: No trainer class with train() and predict() found in {trainer_filename}")
        sys.exit(1)
    print(f"[MLDock] Found trainer class: {{trainer_cls.__name__}}")
except Exception as e:
    print(f"[MLDock] Import failed: {{e}}")
    traceback.print_exc()
    sys.exit(1)

{dataset_load}

print("[MLDock] Running predict()...")
try:
    trainer = trainer_cls()
    input_data = {json.dumps(input_data)}
    result = trainer.predict(input_data)
    print("[MLDock] Prediction result:")
    print(json.dumps(result, indent=2, default=str))
except Exception as e:
    print(f"[MLDock] predict() failed: {{e}}")
    traceback.print_exc()
    sys.exit(1)

print("[MLDock] ✓ Test passed")
"""


def _detect_requirements(trainer_path: Path) -> list[str]:
    """Best-effort: detect common imports in trainer file."""
    source = trainer_path.read_text()
    candidates = {
        "sklearn": "scikit-learn",
        "xgboost": "xgboost",
        "lightgbm": "lightgbm",
        "catboost": "catboost",
        "torch": "torch",
        "tensorflow": "tensorflow",
        "keras": "keras",
        "pandas": "pandas",
        "numpy": "numpy",
        "cv2": "opencv-python-headless",
        "PIL": "Pillow",
        "ultralytics": "ultralytics",
    }
    found = ["requests"]
    for imp, pkg in candidates.items():
        if f"import {imp}" in source or f"from {imp}" in source:
            found.append(pkg)
    return found


def _download_remote_dataset(dataset_id: str, base_url: str, token: str) -> Optional[Path]:
    """Download remote dataset CSV to a temp file."""
    import requests as req
    import tempfile

    info(f"Downloading remote dataset {dataset_id}...")
    try:
        resp = req.get(
            f"{base_url.rstrip('/')}/api/v1/datasets/{dataset_id}/entries",
            headers={"Authorization": f"Bearer {token}"},
            timeout=60,
        )
        resp.raise_for_status()
        entries = resp.json().get("items", [])
        if not entries:
            warn("Dataset has no entries — running without data")
            return None

        import csv, io
        keys = list(entries[0].keys()) if entries else []
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=keys)
        w.writeheader()
        w.writerows(entries)

        tmp = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
        tmp.write(buf.getvalue().encode())
        tmp.flush()
        success(f"Downloaded {len(entries)} entries")
        return Path(tmp.name)
    except Exception as e:
        warn(f"Could not download dataset: {e}. Running without data.")
        return None
