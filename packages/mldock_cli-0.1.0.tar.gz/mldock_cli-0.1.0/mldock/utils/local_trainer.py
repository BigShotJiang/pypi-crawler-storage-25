"""
Local training runner — trains a trainer on the user's machine.

Uses Docker (if available) or a persistent virtualenv (cross-platform).
Saves the trained model as a pickle file.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path
from typing import Optional

from .output import console, success, error, info, warn

TRAIN_IMAGE = "python:3.11-slim"
TRAIN_CONTAINER_PREFIX = "mldock-train-"


def _docker_available() -> bool:
    return shutil.which("docker") is not None


def _container_name(trainer_name: str) -> str:
    safe = "".join(c if c.isalnum() else "-" for c in trainer_name)
    return f"{TRAIN_CONTAINER_PREFIX}{safe}"


def _get_python() -> str:
    for candidate in ("python3", "python"):
        if shutil.which(candidate):
            return candidate
    error("No Python executable found.")
    sys.exit(1)


def _venv_python(env_dir: Path) -> Path:
    if platform.system() == "Windows":
        return env_dir / "Scripts" / "python.exe"
    return env_dir / "bin" / "python"


def _detect_requirements(trainer_path: Path) -> list[str]:
    source = trainer_path.read_text(errors="ignore")
    candidates = {
        "sklearn": "scikit-learn", "xgboost": "xgboost", "lightgbm": "lightgbm",
        "catboost": "catboost", "torch": "torch", "tensorflow": "tensorflow",
        "keras": "keras", "pandas": "pandas", "numpy": "numpy",
        "cv2": "opencv-python-headless", "PIL": "Pillow",
        "ultralytics": "ultralytics", "transformers": "transformers",
    }
    found = ["requests"]
    for imp, pkg in candidates.items():
        if f"import {imp}" in source or f"from {imp}" in source:
            found.append(pkg)
    return found


def _build_train_script(trainer_filename: str, dataset_path: str,
                         target_col: str, hyperparams: dict, output_pkl: str) -> str:
    module_name = trainer_filename.replace(".py", "")
    return textwrap.dedent(f"""
import sys, json, traceback, importlib, os, pickle

sys.path.insert(0, '/workspace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("[MLDock] Importing trainer {module_name}...")
try:
    mod = importlib.import_module('{module_name}')
    trainer_cls = None
    for name in dir(mod):
        obj = getattr(mod, name)
        if isinstance(obj, type) and hasattr(obj, 'train') and hasattr(obj, 'predict') and obj.__module__ == '{module_name}':
            trainer_cls = obj
            break
    if not trainer_cls:
        print("[MLDock] ERROR: No trainer class found.")
        sys.exit(1)
    print(f"[MLDock] Using class: {{trainer_cls.__name__}}")
except Exception as e:
    print(f"[MLDock] Import error: {{e}}")
    traceback.print_exc()
    sys.exit(1)

print("[MLDock] Starting training...")
try:
    trainer = trainer_cls()
    hyperparams = {json.dumps(hyperparams)}
    result = trainer.train(
        r'{dataset_path}',
        target_col='{target_col}',
        **hyperparams,
    )
    print(f"[MLDock] Training complete: {{json.dumps(result, default=str)}}")
except Exception as e:
    print(f"[MLDock] Training error: {{e}}")
    traceback.print_exc()
    sys.exit(1)

print("[MLDock] Saving model...")
try:
    if hasattr(trainer, 'save'):
        trainer.save(r'{output_pkl}')
    else:
        with open(r'{output_pkl}', 'wb') as f:
            pickle.dump(trainer, f)
    print(f"[MLDock] Model saved to {output_pkl}")
except Exception as e:
    print(f"[MLDock] Save error: {{e}}")
    traceback.print_exc()
    sys.exit(1)

print("[MLDock] ✓ Training complete")
""")


def run_local_training(
    trainer_path: Path,
    dataset_path: Path,
    target_col: str = "label",
    hyperparams: Optional[dict] = None,
    output_path: Optional[Path] = None,
) -> None:
    reqs = _detect_requirements(trainer_path)
    out_pkl = output_path or trainer_path.with_suffix(".pkl")
    hp = hyperparams or {}

    if _docker_available():
        _train_docker(trainer_path, dataset_path, target_col, hp, out_pkl, reqs)
    else:
        _train_venv(trainer_path, dataset_path, target_col, hp, out_pkl, reqs)


def _train_docker(
    trainer_path: Path,
    dataset_path: Path,
    target_col: str,
    hyperparams: dict,
    output_path: Path,
    reqs: list[str],
) -> None:
    name = _container_name(trainer_path.stem)
    ws_dir = Path.home() / ".mldock" / "train-workspaces" / trainer_path.stem
    ws_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy(trainer_path, ws_dir / trainer_path.name)
    shutil.copy(dataset_path, ws_dir / "dataset.csv")
    (ws_dir / "requirements.txt").write_text("\n".join(reqs))

    # Output pickle is written into workspace then copied out
    script = _build_train_script(
        trainer_path.name,
        "/workspace/dataset.csv",
        target_col,
        hyperparams,
        "/workspace/model.pkl",
    )
    (ws_dir / "train.py").write_text(script)

    # Remove stale container
    subprocess.run(["docker", "rm", "-f", name], capture_output=True)
    subprocess.run(["docker", "pull", TRAIN_IMAGE], capture_output=True)

    console.print(f"\n[bold]Training in Docker[/] ({TRAIN_IMAGE})")
    info(f"Trainer:  {trainer_path.name}")
    info(f"Dataset:  {dataset_path.name}  ({dataset_path.stat().st_size // 1024} KB)")
    console.print()

    result = subprocess.run([
        "docker", "run", "--rm",
        "--name", name,
        "-v", f"{ws_dir}:/workspace",
        "-w", "/workspace",
        TRAIN_IMAGE,
        "bash", "-c",
        "pip install -q -r requirements.txt && python train.py",
    ])

    if result.returncode != 0:
        error("Training failed in container.")
        sys.exit(1)

    # Copy pickle out
    pkl_in_ws = ws_dir / "model.pkl"
    if pkl_in_ws.exists():
        shutil.copy(pkl_in_ws, output_path)
        success(f"Model saved → [bold]{output_path}[/]")
    else:
        warn("Training script did not produce a model.pkl — check your save() method.")

    success("Training complete (Docker).")
    info(f"  Serve it: mldock trainer serve {trainer_path.name}")


def _train_venv(
    trainer_path: Path,
    dataset_path: Path,
    target_col: str,
    hyperparams: dict,
    output_path: Path,
    reqs: list[str],
) -> None:
    env_dir = Path.home() / ".mldock" / "train-envs" / trainer_path.stem
    ws_dir = Path.home() / ".mldock" / "train-workspaces" / trainer_path.stem
    ws_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy(trainer_path, ws_dir / trainer_path.name)
    shutil.copy(dataset_path, ws_dir / "dataset.csv")

    script = _build_train_script(
        trainer_path.name,
        str(ws_dir / "dataset.csv"),
        target_col,
        hyperparams,
        str(output_path),
    )
    (ws_dir / "train.py").write_text(script)

    # Create venv once
    if not env_dir.exists():
        info(f"Creating virtualenv at {env_dir}…")
        subprocess.run([_get_python(), "-m", "venv", str(env_dir)], check=True)

    py = str(_venv_python(env_dir))

    # Install deps if changed
    req_hash_file = env_dir / ".req_hash"
    current_hash = hashlib.md5("\n".join(sorted(reqs)).encode()).hexdigest()[:8]
    if not req_hash_file.exists() or req_hash_file.read_text().strip() != current_hash:
        info("Installing dependencies…")
        subprocess.run([py, "-m", "pip", "install", "-q"] + reqs, check=True)
        req_hash_file.write_text(current_hash)
        success("Dependencies ready.")
    else:
        info("Dependencies unchanged — skipping install.")

    console.print(f"\n[bold]Training locally[/] (virtualenv)")
    info(f"Trainer:  {trainer_path.name}")
    info(f"Dataset:  {dataset_path.name}  ({dataset_path.stat().st_size // 1024} KB)")
    console.print()

    result = subprocess.run([py, str(ws_dir / "train.py")])
    if result.returncode != 0:
        error("Training failed.")
        sys.exit(1)

    if output_path.exists():
        success(f"Model saved → [bold]{output_path}[/]")
    else:
        warn("Training script did not produce a model file.")

    success("Training complete (virtualenv).")
    info(f"  Serve it: mldock trainer serve {trainer_path.name}")
