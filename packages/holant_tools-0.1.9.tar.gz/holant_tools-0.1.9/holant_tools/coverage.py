r"""Sub-signature projection coverage (viewing-frame coordinate iv).

ADMISSIBILITY_AS_FRAME.md, "Scope of v0.4" item 5. Quantifies the fourth
coordinate of the four-coordinate viewing-frame: the *sub-signature
coverage* of a Holant configuration.

## Definition

For a symmetric matchgate signature $\sigma$ of arity $n$, a **restriction
pattern** is a pair $(n_0, n_1)$ with $n_0 + n_1 \leq n$, specifying that
$n_0$ variables are fixed to 0 and $n_1$ variables are fixed to 1; the
remaining $n_r = n - n_0 - n_1$ variables are unrestricted. The restricted
signature is symmetric of arity $n_r$ with weight-$w$ value $\sigma_{n_1 + w}$
for $w = 0, 1, \ldots, n_r$.

The **sub-signature coverage** of $\sigma$ is the fraction of restriction
patterns (out of $\binom{n+2}{2}$ total) whose restricted signature is
individually matchgate-realisable (Cai-Lu Theorem 2.5).

For a *configuration* $\{\sigma_1, \ldots, \sigma_k\}$, we report each
signature's coverage independently, plus aggregate statistics (min, max,
mean). Per-vertex restriction coverage is the simplest first-cut measure
of how-close-to-matchgate the configuration is, structurally; a more
faithful measure restricts the configuration *as a network* (consistent
restriction of shared variables) and requires a Holant-network
representation we don't yet ship.

## Interpretation

- **Coverage close to 1**: most restrictions are realisable. The
  configuration is "matchgate almost everywhere with structured
  exceptions." A poly-time algorithm may exist via solving the structured
  exceptions by brute force ($O(2^h)$ for $h$ exceptional sub-instances)
  and the realisable bulk via the SRP path.

- **Coverage close to 0**: few restrictions are realisable. The
  configuration is genuinely far from the matchgate world.

- **Intermediate**: structural fingerprint. Two configurations with the
  same coverage are structurally similar in this coordinate.

## Connection to the live scheduling question

Real cluster-scheduling instances are built compositionally from a small
library of constraint primitives. The structural-bound hypothesis of the
viewing-frame is: naturally-occurring families have high sub-signature
coverage even when the global SRP is infeasible. The sampler here is the
operational tool for testing this hypothesis empirically.

## Scope and honest gaps

- **Per-signature, not per-network.** True network-level restriction
  (consistent shared-variable restriction) requires the network rep
  we don't yet ship. Per-signature coverage is the first-cut proxy.

- **Symmetric signatures only.** Non-symmetric generalisation needs to
  enumerate bit-string restrictions rather than weight-only patterns;
  the count grows to $3^n$ rather than $(n+1)(n+2)/2$.

- **Theorem-2.5 realisability only.** This module checks the necessary
  condition (a 3-term linear recurrence exists) for each restriction;
  it does not run the full SRP-on-restriction. The latter is a
  follow-up that combines this module with `srp_solve` per restriction.

See ADMISSIBILITY_AS_FRAME.md for the broader frame.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from .signatures import Signature, is_realizable_somewhere


@dataclass
class SignatureCoverageResult:
    """Sub-signature projection coverage of a single symmetric signature.

    Attributes:
        signature_name: display name of the input signature.
        arity: the signature's arity.
        total_restrictions: number of restriction patterns enumerated.
            For symmetric arity n, equals (n+1)(n+2)/2.
        realisable_count: how many of those restrictions pass Cai-Lu
            Theorem 2.5 individual-realisability.
        coverage: realisable_count / total_restrictions.
        per_pattern: list of ((n_0, n_1), is_realisable) entries, one per
            enumerated pattern. Useful for downstream analysis -- e.g.,
            identifying which restrictions are the "structured exceptions"
            that block global realisability.
    """

    signature_name: str
    arity: int
    total_restrictions: int
    realisable_count: int
    coverage: float
    per_pattern: List[Tuple[Tuple[int, int], bool]] = field(default_factory=list)

    def __repr__(self) -> str:
        return (
            f"SignatureCoverageResult(name={self.signature_name!r}, arity={self.arity}, "
            f"coverage={self.coverage:.4f} "
            f"({self.realisable_count}/{self.total_restrictions}))"
        )


@dataclass
class ConfigurationCoverageResult:
    """Sub-signature projection coverage of a Holant configuration.

    Attributes:
        per_signature: list of SignatureCoverageResult, one per input.
        min_coverage: lowest coverage across signatures.
        max_coverage: highest coverage across signatures.
        mean_coverage: arithmetic mean of per-signature coverages.
        worst_signature: name of the signature with the lowest coverage.
    """

    per_signature: List[SignatureCoverageResult]
    min_coverage: float
    max_coverage: float
    mean_coverage: float
    worst_signature: str = ""

    def __repr__(self) -> str:
        return (
            f"ConfigurationCoverageResult({len(self.per_signature)} sigs, "
            f"coverage min={self.min_coverage:.3f} mean={self.mean_coverage:.3f} "
            f"max={self.max_coverage:.3f}, worst={self.worst_signature!r})"
        )


def enumerate_restrictions(sig: Signature) -> List[Tuple[Tuple[int, int], Signature]]:
    r"""Enumerate all (n_0, n_1) restriction patterns of a symmetric signature.

    For arity-n signature sigma, yields (n+1)(n+2)/2 pairs
    ((n_0, n_1), sigma_restricted) where the restricted signature is
    symmetric of arity n_r = n - n_0 - n_1 with weight-w value
    sigma_{n_1 + w} for w = 0, ..., n_r.

    Args:
        sig: a symmetric Signature.

    Returns:
        list of ((n_0, n_1), restricted_signature) tuples.
    """
    n = sig.arity
    results: List[Tuple[Tuple[int, int], Signature]] = []
    for n_0 in range(n + 1):
        for n_1 in range(n - n_0 + 1):
            n_r = n - n_0 - n_1
            restricted_values = tuple(sig.values[n_1 + w] for w in range(n_r + 1))
            restricted = Signature(
                values=restricted_values,
                kind=sig.kind,
                name=f"{sig.name or 'sig'}|n0={n_0},n1={n_1}",
            )
            results.append(((n_0, n_1), restricted))
    return results


def signature_coverage(sig: Signature) -> SignatureCoverageResult:
    """Compute the sub-signature projection coverage of a single signature.

    For each restriction pattern (n_0, n_1), test whether the restricted
    signature passes Cai-Lu Theorem 2.5 (i.e., admits a 3-term linear
    recurrence -- equivalently, is matchgate-realisable on some basis).

    Args:
        sig: a symmetric Signature.

    Returns:
        SignatureCoverageResult with per-pattern realisability flags and
        the overall coverage fraction.
    """
    per_pattern: List[Tuple[Tuple[int, int], bool]] = []
    realisable_count = 0
    for pattern, restricted in enumerate_restrictions(sig):
        is_realisable = is_realizable_somewhere(restricted)
        per_pattern.append((pattern, is_realisable))
        if is_realisable:
            realisable_count += 1
    total = len(per_pattern)
    return SignatureCoverageResult(
        signature_name=sig.name or "<unnamed>",
        arity=sig.arity,
        total_restrictions=total,
        realisable_count=realisable_count,
        coverage=realisable_count / total if total > 0 else 1.0,
        per_pattern=per_pattern,
    )


def configuration_coverage(signatures: Sequence[Signature]) -> ConfigurationCoverageResult:
    """Compute per-signature coverage + aggregate statistics for a configuration.

    Args:
        signatures: list of symmetric signatures.

    Returns:
        ConfigurationCoverageResult with per-signature breakdown and
        aggregate min / max / mean across signatures.
    """
    if not signatures:
        return ConfigurationCoverageResult(
            per_signature=[],
            min_coverage=1.0,
            max_coverage=1.0,
            mean_coverage=1.0,
        )
    per_sig = [signature_coverage(s) for s in signatures]
    coverages = [r.coverage for r in per_sig]
    min_c = min(coverages)
    max_c = max(coverages)
    mean_c = sum(coverages) / len(coverages)
    worst_idx = coverages.index(min_c)
    worst_name = per_sig[worst_idx].signature_name
    return ConfigurationCoverageResult(
        per_signature=per_sig,
        min_coverage=min_c,
        max_coverage=max_c,
        mean_coverage=mean_c,
        worst_signature=worst_name,
    )
