"""Free-fermion / matchgate quantum simulation via covariance matrices.

Valiant 2002 / Terhal-DiVincenzo 2002 established that quantum circuits built
from *matchgate gates* are classically simulable in polynomial time. The
mechanism: matchgate gates correspond to Gaussian operations on Majorana
fermions under the Jordan-Wigner transformation; their action on the state
is captured by an O(n) x O(n) real antisymmetric covariance matrix instead
of the 2^n complex amplitudes of the full state vector.

This module ships the kernel of a free-fermion simulator.

Conventions (Jordan-Wigner)
---------------------------

For an n-qubit system, define 2n Majorana operators c_1, c_2, ..., c_{2n}:

    c_{2j-1} = Z_1 Z_2 ... Z_{j-1} X_j   (the "X-type" Majorana at qubit j)
    c_{2j}   = Z_1 Z_2 ... Z_{j-1} Y_j   (the "Y-type" Majorana at qubit j)

Anticommutation: {c_i, c_j} = 2 * delta_{ij}.

The covariance matrix M of a fermionic Gaussian state |psi> is the 2n x 2n
real antisymmetric matrix

    M_{ij} = (i / 2) * <psi | [c_i, c_j] | psi>

equivalently, for i < j, M_{ij} = i * <c_i c_j>; M_{ji} = -M_{ij}; M_{ii} = 0.

For the vacuum state |00...0> (all fermion modes empty), the covariance
matrix is the direct sum of 2x2 blocks:

    M_vac = diag_block( [[0, 1], [-1, 0]],  ... n times )

Equivalently, M_vac[2j-1, 2j] = 1 (i.e., M_vac[2j-2, 2j-1] in 0-indexed).

Matchgate action
----------------

A matchgate gate acting on adjacent qubits j and j+1 corresponds to a 4x4
orthogonal transformation R on the four Majorana operators c_{2j-1}, c_{2j},
c_{2j+1}, c_{2j+2}. The covariance matrix updates as

    M -> R_full @ M @ R_full.T

where R_full is the 2n x 2n orthogonal matrix that acts as R on the four
relevant Majorana indices and as identity elsewhere.

For this v0.1.2-alpha prototype, we accept the 4x4 R directly (the conversion
from a matchgate 2-qubit unitary U to the corresponding orthogonal R is a
v0.1.3 follow-on).

Observables
-----------

Pauli-Z on qubit j corresponds to -i * c_{2j-1} * c_{2j}:

    <sigma_z^(j)> = M[2j-1, 2j]   (1-indexed; M[2j-2, 2j-1] in 0-indexed Python)

For the vacuum, this gives +1 (the |0> state has <Z> = +1).

References
----------

- L. G. Valiant, *Quantum Circuits That Can Be Simulated Classically in
  Polynomial Time*, SIAM J. Comput. 31 (4) (2002).
- B. M. Terhal, D. P. DiVincenzo, *Classical simulation of noninteracting-
  fermion quantum circuits*, Phys. Rev. A 65 (2002).
- S. Bravyi, *Lagrangian representation for fermionic linear optics*,
  Quantum Info. Comput. 5 (3) (2005).
"""

from __future__ import annotations
from typing import Sequence, Tuple

from sympy import Matrix, eye, zeros, simplify, sympify, Rational, Integer


# ---------------------------------------------------------------------------
# Matchgate unitary recognition (Valiant 2002 condition)
# ---------------------------------------------------------------------------

def is_matchgate_unitary(U):
    """Check whether a 4x4 unitary U is a matchgate (Valiant 2002).

    A 4x4 matrix is a matchgate iff it has the block-diagonal structure

        [[a, 0, 0, b],
         [0, e, f, 0],
         [0, g, h, 0],
         [c, 0, 0, d]]

    with det([[a, b], [c, d]]) = det([[e, f], [g, h]]).

    Returns:
        bool: True iff U has the matchgate form (block structure + determinant
        equality). Does NOT check unitarity itself; the caller is responsible
        if that matters.
    """
    if not isinstance(U, Matrix):
        U = Matrix(U)
    if U.shape != (4, 4):
        return False

    # Block structure: entries outside the {00, 03, 11, 12, 21, 22, 30, 33} pattern must be zero.
    nonzero_positions = {(0, 0), (0, 3), (3, 0), (3, 3),
                         (1, 1), (1, 2), (2, 1), (2, 2)}
    for i in range(4):
        for j in range(4):
            if (i, j) not in nonzero_positions:
                if simplify(U[i, j]) != 0:
                    return False

    # Determinant equality of the two 2x2 blocks.
    outer_det = U[0, 0] * U[3, 3] - U[0, 3] * U[3, 0]
    inner_det = U[1, 1] * U[2, 2] - U[1, 2] * U[2, 1]
    if simplify(outer_det - inner_det) != 0:
        return False
    return True


# ---------------------------------------------------------------------------
# FreeFermionCircuit: covariance-matrix simulator
# ---------------------------------------------------------------------------

class FreeFermionCircuit:
    """Polynomial-time simulator for matchgate / free-fermion quantum circuits.

    State: a fermionic Gaussian state on n qubits, represented by its 2n x 2n
    real antisymmetric covariance matrix M (in the Majorana basis under the
    Jordan-Wigner convention; see module docstring).

    Initial state: the vacuum |00...0>.

    Updates: matchgate gates on adjacent qubits, applied as 4x4 orthogonal
    rotations on the corresponding 4 Majorana indices. Each gate updates M in
    O(n) work (the relevant 4 rows/columns); a circuit of G gates costs
    O(G * n) total. Compare to state-vector simulation: O(G * 2^n) memory,
    O(G * n * 2^n) time -- exponential.

    Observables (this prototype): <sigma_z^(j)> = M[2j-2, 2j-1] (0-indexed).
    """

    def __init__(self, n_qubits: int):
        if n_qubits < 1:
            raise ValueError(f"n_qubits must be >= 1, got {n_qubits}")
        self.n_qubits = n_qubits
        self.n_majorana = 2 * n_qubits
        self._M = self._vacuum_covariance_matrix(n_qubits)

    @property
    def covariance(self) -> Matrix:
        """The current covariance matrix (2n x 2n real antisymmetric)."""
        return Matrix(self._M)

    @staticmethod
    def _vacuum_covariance_matrix(n_qubits: int) -> Matrix:
        """M_vac = diag_block([[0, 1], [-1, 0]], n times)."""
        n = 2 * n_qubits
        M = zeros(n, n)
        for j in range(n_qubits):
            # Block at rows/cols 2j, 2j+1 (0-indexed).
            M[2 * j, 2 * j + 1] = 1
            M[2 * j + 1, 2 * j] = -1
        return M

    def apply_majorana_rotation(self, R, qubit_pair: Tuple[int, int]):
        """Apply a 4x4 orthogonal Majorana rotation R to a pair of qubits.

        Acts on the four Majorana operators c_{2q1}, c_{2q1+1}, c_{2q2}, c_{2q2+1}
        in that order. For ADJACENT qubits (q2 == q1 + 1), this is the standard
        matchgate-gate action on the local 4-Majorana subspace. For NON-ADJACENT
        qubits (q2 > q1 + 1), this corresponds to a *fermionic* Gaussian operation
        on the c-operators directly -- which is matchgate-simulable in the
        covariance-matrix sense but is NOT the same as a 4x4 quantum unitary on
        the (q1, q2) 2-qubit subspace (the difference is the Jordan-Wigner string
        on intermediate qubits).

        The covariance matrix updates as M -> R_full @ M @ R_full.T where R_full
        is R extended to the full 2n x 2n space (identity on other Majorana
        indices).

        Args:
            R: a 4x4 orthogonal matrix.
            qubit_pair: (q1, q2) with q1 < q2 and both in [0, n_qubits - 1].

        Raises:
            ValueError: if R is not 4x4 or qubit indices are out of range.
        """
        q1, q2 = qubit_pair
        if q1 < 0 or q2 >= self.n_qubits:
            raise ValueError(f"qubit indices ({q1}, {q2}) out of range [0, {self.n_qubits - 1}]")
        if q1 >= q2:
            raise ValueError(f"need q1 < q2; got ({q1}, {q2})")
        indices = [2 * q1, 2 * q1 + 1, 2 * q2, 2 * q2 + 1]
        self.apply_majorana_rotation_at_indices(R, indices)

    def apply_majorana_rotation_at_indices(self, R, indices):
        """Apply a 4x4 orthogonal R to four arbitrary Majorana indices.

        This is the most general matchgate-on-the-covariance-matrix primitive.
        The caller supplies four distinct Majorana indices (in [0, 2n-1]) and a
        4x4 orthogonal R; M is updated as M -> R_full M R_full.T where R_full
        acts as R on rows/cols at `indices` and identity elsewhere.

        Use this when you want fine-grained control over which Majoranas the
        rotation touches (e.g., applying a fermionic two-mode squeeze on
        non-adjacent qubits' Majoranas).

        Args:
            R: a 4x4 orthogonal matrix.
            indices: sequence of 4 distinct Majorana indices in [0, 2n-1].

        Raises:
            ValueError: if R isn't 4x4 or indices invalid.
        """
        if not isinstance(R, Matrix):
            R = Matrix(R)
        if R.shape != (4, 4):
            raise ValueError(f"R must be 4x4, got {R.shape}")
        idx = list(indices)
        if len(idx) != 4:
            raise ValueError(f"indices must have length 4; got {len(idx)}")
        if len(set(idx)) != 4:
            raise ValueError(f"indices must be distinct; got {idx}")
        for i in idx:
            if i < 0 or i >= self.n_majorana:
                raise ValueError(
                    f"Majorana index {i} out of range [0, {self.n_majorana - 1}]"
                )

        # Update M: rows at idx, then cols at idx.
        M = self._M
        new_rows = R * M[idx, :]
        for i_local, gi in enumerate(idx):
            for j in range(self.n_majorana):
                M[gi, j] = new_rows[i_local, j]
        new_cols = M[:, idx] * R.T
        for j_local, gj in enumerate(idx):
            for i in range(self.n_majorana):
                M[i, gj] = new_cols[i, j_local]
        self._M = M

    def apply_matchgate(self, U, qubit_pair: Tuple[int, int]):
        """Convenience: apply a 4x4 matchgate unitary U to adjacent qubits.

        Internally converts U to the 4x4 orthogonal Majorana rotation R via
        unitary_to_majorana_rotation(U), then calls apply_majorana_rotation.

        Args:
            U: a 4x4 unitary matrix satisfying the matchgate condition.
            qubit_pair: (q1, q2) with q2 == q1 + 1.

        Raises:
            ValueError: if U fails the matchgate condition or qubits not adjacent.
        """
        R = unitary_to_majorana_rotation(U)
        self.apply_majorana_rotation(R, qubit_pair)

    def expectation_z(self, qubit: int):
        """<sigma_z^(qubit)> = M[2*qubit, 2*qubit+1].

        For the vacuum |00...0>, this is +1 for all qubits.
        """
        if qubit < 0 or qubit >= self.n_qubits:
            raise ValueError(f"qubit {qubit} out of range [0, {self.n_qubits - 1}]")
        return self._M[2 * qubit, 2 * qubit + 1]

    def expectation_z_all(self):
        """List of <sigma_z^(j)> for j = 0, 1, ..., n_qubits - 1."""
        return [self.expectation_z(j) for j in range(self.n_qubits)]

    def expectation_z_product(self, qubits):
        """Multi-qubit Pauli-Z product expectation via Wick's theorem.

        Returns <Z_{q_1} Z_{q_2} ... Z_{q_m}> for a fermionic Gaussian state.

        Derivation. Each Z_q = -i c_{2q} c_{2q+1} (with the Jordan-Wigner
        convention of this module). For distinct qubits q_1 < q_2 < ... < q_m
        the Pauli-Z product is

            Z_{q_1} ... Z_{q_m} = (-i)^m c_{2q_1} c_{2q_1+1} c_{2q_2} c_{2q_2+1} ... c_{2q_m} c_{2q_m+1}

        Gaussian Wick (Isserlis for fermions) gives
            <c_{i_1} ... c_{i_{2m}}> = i^m * Pf(M_sub)
        where M_sub is the 2m x 2m antisymmetric submatrix on those indices.
        Combining, the factors (-i)^m and i^m multiply to 1; the Pauli-Z product
        expectation is exactly the Pfaffian of M_sub.

        Single qubit (m=1) reduces to <Z_q> = M[2q, 2q+1] = expectation_z(q).

        Args:
            qubits: iterable of qubit indices (must be distinct; 0-indexed).

        Returns:
            Pf(M_sub) — the Pauli-Z product expectation value.
        """
        from .holant import pfaffian
        qubits_list = list(qubits)
        if not qubits_list:
            return 1  # empty product = identity expectation
        if len(set(qubits_list)) != len(qubits_list):
            raise ValueError(f"qubits must be distinct; got {qubits_list}")
        for q in qubits_list:
            if q < 0 or q >= self.n_qubits:
                raise ValueError(f"qubit {q} out of range [0, {self.n_qubits - 1}]")
        # Sort the qubits so the Pfaffian sign is unambiguous.
        qubits_sorted = sorted(qubits_list)
        indices = []
        for q in qubits_sorted:
            indices.extend([2 * q, 2 * q + 1])
        M_sub = self._M[indices, indices]
        return pfaffian(M_sub)

    def expectation_pauli_string(self, pauli_string):
        """Expectation of a general Pauli string via JW + Wick's theorem.

        For a Pauli string of the form P = sigma_{q_1, P_1} sigma_{q_2, P_2} ...
        sigma_{q_k, P_k} with P_i in {'X', 'Y', 'Z'} on distinct qubits q_i,
        compute <P> exactly via the Jordan-Wigner expansion of P as a signed
        product of Majoranas, then apply Wick's theorem on the resulting
        Majorana product (cf. expectation_majorana_product).

        Implementation: convert the Pauli string to a list of Majorana indices
        plus a sign / phase, accounting for the Jordan-Wigner Z-strings
        (Z-strings cancel pairwise on intermediate qubits).

        Args:
            pauli_string: dict {qubit_index: 'X' | 'Y' | 'Z'} on distinct qubits.

        Returns:
            <P> -- the Pauli string expectation value.

        Example:
            >>> ff.expectation_pauli_string({0: 'X', 2: 'X'})    # <X_0 X_2>
            >>> ff.expectation_pauli_string({0: 'X', 1: 'Y'})    # <X_0 Y_1>
            >>> ff.expectation_pauli_string({1: 'Z'})            # <Z_1>
        """
        from sympy import I as sympy_I
        from .holant import pfaffian
        if not pauli_string:
            return 1
        # Build the Majorana representation. For each (qubit, P) in sorted order
        # by qubit, P expands as:
        #   Z_q = -i c_{2q} c_{2q+1}    (no JW string)
        #   X_q = JW(<q) c_{2q}          (JW string = Z_0 Z_1 ... Z_{q-1})
        #   Y_q = JW(<q) c_{2q+1}        (same JW string)
        # where JW(<q) = Z_0 Z_1 ... Z_{q-1}, each Z_j = -i c_{2j} c_{2j+1}.
        #
        # The JW strings cancel pairwise when multiple Paulis hit different qubits:
        # for each PAIR of X/Y operators on qubits q1 < q2, the JW strings up to
        # q1 cancel each other (each Z_j appears twice in the combined product),
        # and the JW string between q1 and q2 contributes Z_{q1+1} ... Z_{q2-1}.
        #
        # Cleanest computation: just expand the product of Pauli-string operators
        # in terms of Majoranas symbolically, simplifying Z_j^2 = 1 cancellations.

        # Sort by qubit index for canonical handling.
        items = sorted(pauli_string.items())
        # Verify all qubits valid.
        for q, P in items:
            if q < 0 or q >= self.n_qubits:
                raise ValueError(f"qubit {q} out of range [0, {self.n_qubits - 1}]")
            if P not in ('X', 'Y', 'Z'):
                raise ValueError(f"Pauli must be X, Y, or Z; got {P!r} at qubit {q}")

        # For each (q, P), record the Majorana index that the LOCAL operator contributes,
        # plus whether a JW string is needed for the operator.
        # We track the multiset of Majoranas + an overall phase.
        #
        # For Z_q: the operator IS -i c_{2q} c_{2q+1}. Contributes 2 majoranas
        #   (2q, 2q+1) and a phase factor -i.
        # For X_q: contributes JW(<q) c_{2q}. The JW string is Z_0...Z_{q-1} =
        #   (-i)^q c_0 c_1 c_2 c_3 ... c_{2q-2} c_{2q-1}.
        # For Y_q: similarly JW(<q) c_{2q+1}.
        #
        # To handle JW-string cancellations cleanly: we collect all Majoranas
        # in order with appropriate phase factors, then for each pair of duplicate
        # Majoranas use c_i^2 = 1 to cancel them (with sign tracking from
        # anticommuting them through other Majoranas).

        # Strategy: build the Pauli operator as a list of (sign_phase, Majorana_index)
        # tuples, then reorder + cancel pairs.
        majoranas = []   # list of Majorana indices, in the ORDER the operator factors them
        phase = 1        # current overall phase factor (powers of i)
        for q, P in items:
            # The JW string up to q: -i^q * c_0 c_1 ... c_{2q-1}
            if P in ('X', 'Y'):
                # JW string
                for j in range(q):
                    majoranas.append(2 * j)
                    majoranas.append(2 * j + 1)
                phase *= sympy_I ** q * (-1) ** q   # Z_0...Z_{q-1} = (-i)^q product
                # Local operator
                if P == 'X':
                    majoranas.append(2 * q)
                else:  # Y
                    majoranas.append(2 * q + 1)
            elif P == 'Z':
                # Z_q = -i c_{2q} c_{2q+1}, no JW string
                phase *= -sympy_I
                majoranas.append(2 * q)
                majoranas.append(2 * q + 1)

        # Now we have a phase * (c_{i_1} c_{i_2} ... c_{i_K}). The indices may
        # repeat (from JW-string cancellations). Reduce duplicates using c_i^2 = 1
        # and anticommutation c_i c_j = -c_j c_i for i != j.
        #
        # We move all occurrences to be adjacent by counting swaps mod 2; each
        # adjacent pair (c_i c_i) reduces to 1.
        #
        # Implementation: walk through the list left-to-right, and for each
        # element, count how many later occurrences exist; pairwise cancellation
        # uses parity of swaps.
        reduced_majoranas, parity = _reduce_majorana_word(majoranas)
        if parity:
            phase = -phase

        # Now reduced_majoranas is a list of distinct Majorana indices (in some order).
        # Apply Wick's theorem.
        k = len(reduced_majoranas)
        if k == 0:
            return phase   # phase * identity expectation
        if k % 2 == 1:
            return 0
        # Permute reduced_majoranas to ascending order, tracking parity for the Pfaffian.
        sorted_idx = sorted(reduced_majoranas)
        # Count inversions between the order we have and ascending.
        perm = [reduced_majoranas.index(x) for x in sorted_idx]
        # Actually use the simple parity-of-permutation calculation.
        perm_parity = _permutation_parity(reduced_majoranas, sorted_idx)
        sign = (-1) ** perm_parity
        M_sub = self._M[sorted_idx, sorted_idx]
        m = k // 2
        return phase * sign * (sympy_I ** m) * pfaffian(M_sub)

    def expectation_majorana_product(self, indices):
        """General Majorana product expectation via Wick's theorem.

        Returns <c_{i_1} c_{i_2} ... c_{i_k}> for a fermionic Gaussian state.

        Wick / Isserlis identity for fermions:
            - For k odd: returns 0.
            - For k = 2m even: returns i^m * Pf(M_sub) where M_sub is the
              2m x 2m antisymmetric submatrix of the covariance on the given
              Majorana indices (in the user-supplied order).

        Args:
            indices: sequence of Majorana indices (0-indexed; 0 <= i < 2n).
                Must be distinct.

        Returns:
            <c_{i_1} ... c_{i_k}> — the Majorana product expectation.
        """
        from .holant import pfaffian
        from sympy import I as sympy_I
        idx = list(indices)
        if not idx:
            return 1
        k = len(idx)
        if k % 2 == 1:
            return 0
        if len(set(idx)) != k:
            raise ValueError(f"indices must be distinct; got {idx}")
        for i in idx:
            if i < 0 or i >= self.n_majorana:
                raise ValueError(f"Majorana index {i} out of range [0, {self.n_majorana - 1}]")
        M_sub = self._M[idx, idx]
        m = k // 2
        return (sympy_I ** m) * pfaffian(M_sub)


# ---------------------------------------------------------------------------
# Canonical matchgate Majorana rotations
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Conversion: 2-qubit matchgate unitary U -> 4x4 Majorana orthogonal R
# ---------------------------------------------------------------------------

def _reduce_majorana_word(word):
    """Reduce a word of Majorana indices using c_i^2 = 1 and c_i c_j = -c_j c_i.

    Walks left-to-right; for each index, if it appears later in the word, swap
    pairs to bring the duplicate adjacent (each swap flips parity), then cancel.

    Returns (reduced_word, parity_flips) where reduced_word has distinct indices
    in the order they appear after reduction, and parity_flips is the
    accumulated swap count mod 2.
    """
    word = list(word)
    parity = 0
    i = 0
    while i < len(word):
        x = word[i]
        # Find the next occurrence of x.
        j = None
        for k in range(i + 1, len(word)):
            if word[k] == x:
                j = k
                break
        if j is None:
            i += 1
            continue
        # We have word[i] = word[j] = x. Bring word[j] adjacent to word[i] by
        # swapping it left past (j - i - 1) elements, each swap flips parity.
        parity ^= (j - i - 1) & 1
        # Now word[i] = x, word[i+1] = x, cancel them.
        del word[j]
        del word[i]
        # Continue from position i (don't advance), since the word changed.
    return word, parity


def _permutation_parity(source, target):
    """Compute the parity of the permutation that sorts `source` into `target` order.

    Both lists must contain the same elements; `target` is the sorted order.
    Returns 0 (even) or 1 (odd).
    """
    src = list(source)
    parity = 0
    for i, x in enumerate(target):
        j = src.index(x, i)
        if j != i:
            src[i], src[j] = src[j], src[i]
            parity ^= 1
    return parity


def _local_majorana_matrices():
    """The four 4x4 Hermitian matrices c_0, c_1, c_2, c_3 representing the
    Majorana operators on the local 2-qubit Hilbert space, in the Jordan-Wigner
    convention used throughout this module.

    Returns: a list [c_0, c_1, c_2, c_3] of 4x4 sympy Matrices.
    """
    from sympy import I as sympy_I
    II = Matrix([[1, 0], [0, 1]])
    X  = Matrix([[0, 1], [1, 0]])
    Y  = Matrix([[0, -sympy_I], [sympy_I, 0]])
    Z  = Matrix([[1, 0], [0, -1]])
    # Kronecker product convention: qubit 0 is the LEFT factor.
    def kron(A, B):
        m, n = A.shape
        p, q = B.shape
        out = Matrix.zeros(m * p, n * q)
        for i in range(m):
            for j in range(n):
                for k in range(p):
                    for l in range(q):
                        out[i * p + k, j * q + l] = A[i, j] * B[k, l]
        return out
    c0 = kron(X, II)        # X_0 I_1
    c1 = kron(Y, II)        # Y_0 I_1
    c2 = kron(Z, X)         # Z_0 X_1
    c3 = kron(Z, Y)         # Z_0 Y_1
    return [c0, c1, c2, c3]


def unitary_to_majorana_rotation(U) -> Matrix:
    """Convert a 4x4 matchgate unitary U into the corresponding 4x4 orthogonal
    Majorana rotation R acting on the local 2-qubit Majoranas (c_0, c_1, c_2, c_3).

    The map is defined by U c_i U^dagger = sum_j R_{ji} c_j; equivalently

        R[j, i] = (1/4) tr( c_j @ U @ c_i @ U^dagger )

    using the trace orthogonality of the Majoranas (tr(c_i c_j) = 4 delta_{ij}
    on the local 2-qubit Hilbert space).

    This lets the user write `circuit.apply_matchgate(U, (q1, q2))` with U
    as a 4x4 unitary directly, instead of constructing the Majorana rotation
    matrix R by hand.

    Args:
        U: a 4x4 unitary (matchgate) matrix.

    Returns:
        R: a 4x4 real orthogonal matrix.

    Raises:
        ValueError: if U is not 4x4 or fails the matchgate condition.
    """
    from sympy import I as sympy_I, simplify, re

    if not isinstance(U, Matrix):
        U = Matrix(U)
    if U.shape != (4, 4):
        raise ValueError(f"U must be 4x4, got {U.shape}")
    if not is_matchgate_unitary(U):
        raise ValueError(
            "U does not satisfy the matchgate condition (block structure + "
            "determinant equality). Use is_matchgate_unitary(U) to check."
        )

    c = _local_majorana_matrices()
    U_dag = U.H

    R = Matrix.zeros(4, 4)
    for i in range(4):
        UciUdag = U * c[i] * U_dag
        for j in range(4):
            trace = (c[j] * UciUdag).trace()
            entry = trace / 4
            # The trace is real for matchgate U (the result is an orthogonal R);
            # extract the real part and simplify.
            entry_simplified = simplify(re(entry))
            R[j, i] = entry_simplified
    return R


# ---------------------------------------------------------------------------
# Canonical Majorana rotations (still exported for direct use)
# ---------------------------------------------------------------------------

def majorana_rotation_z_left(theta) -> Matrix:
    """Z-rotation on the LEFT qubit of the pair: U = exp(-i theta/2 * Z_{q1}).

    Action on the local 4 Majoranas (c_{2q1}, c_{2q1+1}, c_{2q2}, c_{2q2+1}):
    rotates the first pair (c_{2q1}, c_{2q1+1}) by angle theta, leaves the
    second pair (c_{2q2}, c_{2q2+1}) untouched.
    """
    from sympy import cos, sin
    c = cos(theta)
    s = sin(theta)
    return Matrix([
        [c, -s, 0, 0],
        [s,  c, 0, 0],
        [0,  0, 1, 0],
        [0,  0, 0, 1],
    ])


def majorana_rotation_z_right(theta) -> Matrix:
    """Z-rotation on the RIGHT qubit of the pair: U = exp(-i theta/2 * Z_{q2}).

    Action on the local 4 Majoranas: rotates the second pair (c_{2q2}, c_{2q2+1})
    by angle theta, leaves the first pair (c_{2q1}, c_{2q1+1}) untouched.
    """
    from sympy import cos, sin
    c = cos(theta)
    s = sin(theta)
    return Matrix([
        [1, 0, 0,  0],
        [0, 1, 0,  0],
        [0, 0, c, -s],
        [0, 0, s,  c],
    ])


def majorana_rotation_xx(theta) -> Matrix:
    """Joint-XX rotation: U = exp(-i theta/2 * X_{q1} X_{q2}).

    Action on the local 4 Majoranas: rotates the CROSS pair (c_{2q1+1}, c_{2q2}),
    leaves the outer pair (c_{2q1}, c_{2q2+1}) untouched.

    In Majorana operator language, X_{q1} X_{q2} = -i c_{2q1+1} c_{2q2} (in our
    Jordan-Wigner convention), so the generator is bilinear in c_{2q1+1} and c_{2q2},
    producing a 2D rotation in that plane.
    """
    from sympy import cos, sin
    c = cos(theta)
    s = sin(theta)
    return Matrix([
        [1, 0,  0, 0],
        [0, c, -s, 0],
        [0, s,  c, 0],
        [0, 0,  0, 1],
    ])


def majorana_rotation_yy(theta) -> Matrix:
    """Joint-YY rotation: U = exp(-i theta/2 * Y_{q1} Y_{q2}).

    Action on the local 4 Majoranas: rotates the OUTER pair (c_{2q1}, c_{2q2+1}),
    leaves the cross pair (c_{2q1+1}, c_{2q2}) untouched.

    Y_{q1} Y_{q2} = i c_{2q1} c_{2q2+1} in our Jordan-Wigner convention.
    Heisenberg evolution under H = (1/2) Y_{q1} Y_{q2}:
        c_{2q1}    -> c_{2q1} cos(theta) + c_{2q2+1} sin(theta)
        c_{2q2+1}  -> -c_{2q1} sin(theta) + c_{2q2+1} cos(theta)
    """
    from sympy import cos, sin
    c = cos(theta)
    s = sin(theta)
    return Matrix([
        [c,  0, 0, s],
        [0,  1, 0, 0],
        [0,  0, 1, 0],
        [-s, 0, 0, c],
    ])
