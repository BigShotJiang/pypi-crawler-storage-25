"""Top-level SRP (Simultaneous Realizability Problem) solver.

Glues together the v0.2 pieces:
  1. classify_form: Cai-Lu Form of each signature (informational).
  2. realizability_subvariety: build B(sigma_i) in M for each sigma_i.
  3. intersect_subvarieties: decide whether the intersection is non-empty.

The sufficient-condition step that completes Cai-Lu Theorem 4.1.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from .signatures import Signature, Recurrence, find_recurrence
from .realizability import (
    FormClassification,
    Subvariety,
    classify_form,
    realizability_subvariety,
)
from .intersection import IntersectionResult, intersect_subvarieties


@dataclass
class SRPResult:
    """Outcome of a full SRP decision."""

    feasible: bool
    witness: Optional[dict] = None
    individual_results: List[Tuple[Signature, Optional[FormClassification]]] = field(
        default_factory=list
    )
    subvarieties: List[Subvariety] = field(default_factory=list)
    intersection: Optional[IntersectionResult] = None
    notes: str = ""

    @property
    def infeasible_signatures(self) -> List[Signature]:
        return [sig for sig, fc in self.individual_results if fc is None]


def srp_solve(
    signatures: Sequence[Signature],
    modulus: Optional[int] = None,
) -> SRPResult:
    """Decide the Simultaneous Realizability Problem (Cai-Lu 2011).

    Args:
        signatures: list of symmetric signatures to be jointly realized.
        modulus: optional finite-field modulus p. If given, search for a
            common basis in F_p; otherwise search over the algebraic closure
            of Q.

    Returns:
        SRPResult with:
            - feasible: True iff all signatures are individually realizable
              AND a common basis exists in M.
            - witness: a basis (u, v) in M realizing all signatures.
            - individual_results: per-signature Form classification (None if
              individually non-realizable).
            - subvarieties: per-signature B(sigma_i).
            - intersection: low-level IntersectionResult.

    A signature that fails Theorem 2.5 (individually non-realizable) makes
    the whole SRP infeasible regardless of basis choice; we short-circuit.
    """
    individual: List[Tuple[Signature, Optional[FormClassification]]] = []
    infeasible_individually: List[Signature] = []
    for sig in signatures:
        fc = classify_form(sig)
        individual.append((sig, fc))
        if fc is None:
            infeasible_individually.append(sig)

    if infeasible_individually:
        names = [s.name or "<unnamed>" for s in infeasible_individually]
        return SRPResult(
            feasible=False,
            individual_results=individual,
            notes=f"individual realizability fails for: {names}",
        )

    subvarieties = [realizability_subvariety(sig) for sig in signatures]
    intersection = intersect_subvarieties(subvarieties, modulus=modulus)

    return SRPResult(
        feasible=intersection.feasible,
        witness=intersection.witness if intersection.feasible else None,
        individual_results=individual,
        subvarieties=subvarieties,
        intersection=intersection,
        notes=intersection.notes,
    )


# ---------------------------------------------------------------------------
# Field-extension distance: minimum field where the SRP becomes feasible
# ---------------------------------------------------------------------------
#
# v0.2's srp_solve(signatures, modulus=p) decides SRP feasibility over a
# specific field (Q-bar or F_p). The Cai-Lu sec 5.1 mod-7 phenomenon --
# infeasible over Q-bar and F_2/3/5; feasible over F_7 -- shows that the
# *minimum* prime p where SRP becomes feasible is itself a structural
# invariant of the configuration, not just a solver parameter.
#
# `field_extension_distance` promotes this from solver parameter to output
# coordinate. It iterates Q-bar (if requested) then ascending primes,
# returning the FIRST feasible field. The result distinguishes "feasible
# over Q-bar" (distance 0) from "feasible over F_p" (distance p) from
# "exceeds_max" (no feasibility in the tried fields).


_DEFAULT_PRIMES_FOR_DISTANCE = [2, 3, 5, 7, 11, 13, 17, 19, 23]


@dataclass
class FieldExtensionDistanceResult:
    """Minimum field over which the SRP becomes feasible.

    Attributes:
        distance: 0 if feasible over the algebraic closure of Q;
            the prime p if F_p is the minimum feasible finite field;
            None if no feasibility was found among the tried fields.
        min_feasible_field: human-readable label of the minimum feasible
            field ("Q-bar", "F_p"), or None.
        witness: basis (u, v) witnessing feasibility, or None.
        fields_tried: per-field trace as (label, feasible, witness_or_None).
        primes_tried: ascending list of primes that were searched.
        individual_infeasibility: signature names that fail Theorem 2.5
            (short-circuits the whole search).
        status: one of
            "feasible_in_Q_bar"
            "feasible_in_F_p"
            "exceeds_max"
            "individually_infeasible"
        notes: free-form summary.
    """

    distance: Optional[int]
    min_feasible_field: Optional[str] = None
    witness: Optional[dict] = None
    fields_tried: List[Tuple[str, bool, Optional[dict]]] = field(default_factory=list)
    primes_tried: List[int] = field(default_factory=list)
    individual_infeasibility: List[str] = field(default_factory=list)
    status: str = "computed"
    notes: str = ""

    def __repr__(self) -> str:
        if self.status == "individually_infeasible":
            return (f"FieldExtensionDistanceResult(distance=None, "
                    f"individually_infeasible={self.individual_infeasibility})")
        if self.status == "feasible_in_Q_bar":
            return f"FieldExtensionDistanceResult(distance=0, field='Q-bar', witness={self.witness})"
        if self.status == "feasible_in_F_p":
            return (f"FieldExtensionDistanceResult(distance={self.distance}, "
                    f"field='F_{self.distance}', witness={self.witness})")
        if self.status == "exceeds_max":
            return (f"FieldExtensionDistanceResult(distance>max(tried), "
                    f"tried={[label for label, _, _ in self.fields_tried]})")
        return f"FieldExtensionDistanceResult(distance={self.distance}, status={self.status!r})"


def field_extension_distance(
    signatures: Sequence[Signature],
    primes_to_try: Optional[Sequence[int]] = None,
    include_algebraic_closure: bool = True,
) -> FieldExtensionDistanceResult:
    """Compute the field-extension distance of an SRP configuration.

    Tries the algebraic closure of Q first (unless disabled), then
    ascending primes. Returns the minimum field where the SRP is feasible.

    Args:
        signatures: list of symmetric signatures.
        primes_to_try: ascending list of primes to search F_p over.
            Defaults to [2, 3, 5, 7, 11, 13, 17, 19, 23]. Must be sorted
            ascending; the function reports the FIRST feasible field.
        include_algebraic_closure: whether to try Q-bar first. If True
            and Q-bar is feasible, distance = 0 and no primes are tried.
            If False, the search is restricted to finite fields.

    Returns:
        FieldExtensionDistanceResult.

    Example:
        Cai-Lu sec 5.1 (#_7 Pl-Rtw-Mon-3CNF):

            >>> from holant_tools import field_extension_distance, examples
            >>> result = field_extension_distance(
            ...     [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
            ... )
            >>> result.distance
            7
            >>> result.min_feasible_field
            'F_7'
    """
    if primes_to_try is None:
        primes_to_try = list(_DEFAULT_PRIMES_FOR_DISTANCE)
    primes_to_try = list(primes_to_try)
    if any(primes_to_try[i] >= primes_to_try[i + 1] for i in range(len(primes_to_try) - 1)):
        raise ValueError(f"primes_to_try must be strictly ascending, got {primes_to_try}")

    fields_tried: List[Tuple[str, bool, Optional[dict]]] = []
    individual_failures: List[str] = []

    if include_algebraic_closure:
        result_qbar = srp_solve(signatures)
        if result_qbar.infeasible_signatures:
            individual_failures = [
                s.name or "<unnamed>" for s in result_qbar.infeasible_signatures
            ]
            return FieldExtensionDistanceResult(
                distance=None,
                fields_tried=[("Q-bar", False, None)],
                individual_infeasibility=individual_failures,
                status="individually_infeasible",
                notes=(
                    f"Short-circuit: individually non-realisable signatures "
                    f"{individual_failures} make the SRP infeasible over every "
                    f"field."
                ),
            )
        fields_tried.append(
            ("Q-bar", result_qbar.feasible, result_qbar.witness if result_qbar.feasible else None)
        )
        if result_qbar.feasible:
            return FieldExtensionDistanceResult(
                distance=0,
                min_feasible_field="Q-bar",
                witness=result_qbar.witness,
                fields_tried=fields_tried,
                status="feasible_in_Q_bar",
                notes="Feasible over the algebraic closure of Q; no field extension needed.",
            )

    primes_actually_tried: List[int] = []
    for p in primes_to_try:
        result_p = srp_solve(signatures, modulus=p)
        primes_actually_tried.append(p)
        if result_p.infeasible_signatures and not individual_failures:
            individual_failures = [
                s.name or "<unnamed>" for s in result_p.infeasible_signatures
            ]
        fields_tried.append(
            (f"F_{p}", result_p.feasible, result_p.witness if result_p.feasible else None)
        )
        if result_p.feasible:
            return FieldExtensionDistanceResult(
                distance=p,
                min_feasible_field=f"F_{p}",
                witness=result_p.witness,
                fields_tried=fields_tried,
                primes_tried=primes_actually_tried,
                status="feasible_in_F_p",
                notes=(
                    f"Minimum feasible field: F_{p}. Configuration is "
                    f"infeasible over Q-bar and over F_q for every q < {p} "
                    f"that was tried."
                ),
            )

    return FieldExtensionDistanceResult(
        distance=None,
        fields_tried=fields_tried,
        primes_tried=primes_actually_tried,
        individual_infeasibility=individual_failures,
        status="exceeds_max",
        notes=(
            f"No feasibility found among Q-bar and primes "
            f"{primes_actually_tried}. The configuration may be infeasible "
            f"on the tried chart of M (cf. NON_SYMMETRIC.md), or the true "
            f"minimum prime may be larger than max(primes_to_try)."
        ),
    )
