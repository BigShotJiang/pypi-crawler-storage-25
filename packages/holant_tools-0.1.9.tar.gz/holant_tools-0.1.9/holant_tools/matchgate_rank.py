r"""Standard-basis matchgate rank for symmetric Holant signatures.

First v0.4 deliverable from `ADMISSIBILITY_AS_FRAME.md` (the viewing-frame
design doc). Implements coordinate (i) of the four-coordinate apparatus:
**matchgate rank** measured in standard basis.

## Definition

For a symmetric signature $\sigma = (\sigma_0, \ldots, \sigma_n)$ of arity $n$,
the **standard-basis matchgate rank** is the minimum $r$ such that

    sigma_w = sum_{i=1}^{2r} c_i * xi_i^w   for w = 0, 1, ..., n

i.e. $\sigma$ is a sum of $r$ standard-basis matchgate signatures (each one
of which is a Cai-Lu Form-1 sum-of-two-exponentials; Forms 2 and 3 are
degenerate sub-cases of the same family with multiplicity / special
exponents).

## Computation

By Kronecker's theorem on linear recurrences, the Hankel matrix
$H[i,j] = \sigma_{i+j}$ has rank equal to the order of the minimal linear
recurrence satisfied by $\sigma$. Each matchgate component contributes at
most 2 to the recurrence order. Therefore

    matchgate_rank(sigma) = ceil(Hankel_rank(sigma) / 2).

This is computable directly from the signature values via a sympy
`Matrix.rank()` call. No basis search, no polynomial-system solving;
the standard-basis case is closed-form.

## Connection to v0.1 / v0.2

`signatures.find_recurrence` is the *order-2* special case: it returns a
non-trivial null vector of the Hankel matrix $H_2$ (size $(n-1) \times 3$),
which exists iff $\sigma$ has matchgate rank $\leq 1$ (= is itself a
Cai-Lu Form-1 / Form-2 / Form-3 standard-basis signature).

`matchgate_rank` here generalises this to all orders.

## Scope and honest gaps

- **Standard basis only.** A signature $\sigma$ may have a higher
  standard-basis matchgate rank than its rank after pullback by some
  $\beta \in \mathcal{M}$. The basis-aware matchgate rank
  (minimum over $\beta$) is harder; deferred. The standard-basis
  rank is well-defined, computable in poly time, and the natural
  starting coordinate.

- **Repeated-root decompositions.** When the characteristic polynomial of
  the minimal recurrence has a repeated root (Cai-Lu Form 2 case), the
  signature has the form $(\alpha + \beta w) \mu^w$ rather than a sum of
  two distinct exponentials. The Hankel-rank calculation is unchanged
  (still rank 2 in this case), but the explicit decomposition into
  $\sum c_i \xi_i^w$ does not exist with distinct $\xi_i$. The `rank`
  output is still correct; `recurrence` is still recoverable; explicit
  decomposition into Form-1 pieces is deferred to a follow-up.

- **Non-symmetric signatures.** Not handled here. The non-symmetric
  generalisation needs the multi-dimensional Hankel-tensor rank
  (a.k.a. multilinear rank); a separate module.

See `ADMISSIBILITY_AS_FRAME.md` for the broader frame.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple

from sympy import Matrix, sympify, S

from .signatures import Signature


@dataclass
class MatchgateRankResult:
    """Result of a matchgate-rank computation.

    Attributes:
        rank: minimum r such that sigma decomposes into r standard-basis
            matchgate signatures. 0 for the zero signature; None if the
            computation reports an exceeds-bound or underdetermined status.
        hankel_rank: rank of the Hankel matrix of sigma.
        order: order of the minimal linear recurrence the signature
            satisfies (equals hankel_rank when the signature has at least
            2 * hankel_rank + 1 values, otherwise reports None and
            status="underdetermined").
        recurrence: tuple (c_0, c_1, ..., c_order) of the minimal
            recurrence's coefficients, normalised so the leading
            coefficient is non-zero. The signature satisfies
                sum_{i=0}^{order} c_i * sigma_{j+i} = 0  for all valid j.
        status: one of
            "computed"        -- rank determined, recurrence recovered
            "zero"            -- the zero signature, rank 0
            "underdetermined" -- signature too short for a useful Hankel
                                 matrix; the bound is informative but the
                                 minimal recurrence cannot be recovered
            "exceeds_max"     -- rank exceeds the max_rank bound
        max_attempted: the max_rank bound that was checked (only set when
            status="exceeds_max").
    """

    rank: Optional[int]
    hankel_rank: Optional[int] = None
    order: Optional[int] = None
    recurrence: Optional[Tuple] = None
    status: str = "computed"
    max_attempted: Optional[int] = None

    def __repr__(self) -> str:
        if self.status == "zero":
            return "MatchgateRankResult(rank=0, status='zero')"
        if self.status == "exceeds_max":
            return (f"MatchgateRankResult(rank>{self.max_attempted}, "
                    f"hankel_rank={self.hankel_rank}, status='exceeds_max')")
        if self.status == "underdetermined":
            return (f"MatchgateRankResult(rank<={self.rank}, "
                    f"hankel_rank={self.hankel_rank}, "
                    f"status='underdetermined')")
        return (f"MatchgateRankResult(rank={self.rank}, "
                f"hankel_rank={self.hankel_rank}, order={self.order}, "
                f"recurrence={self.recurrence}, status='computed')")


def hankel_matrix(values, k: Optional[int] = None) -> Matrix:
    """Build the Hankel matrix of a sequence.

    For `values` of length L, returns the (L-k) x (k+1) matrix H with
    H[i, j] = values[i+j]. Default k = (L-1) // 2 gives the most-square
    shape and the maximum possible rank.

    Args:
        values: sequence of length L >= 1.
        k: window size; default (L-1) // 2.

    Returns:
        sympy Matrix of shape (L-k) x (k+1).
    """
    L = len(values)
    if L == 0:
        raise ValueError("hankel_matrix needs a non-empty sequence")
    if k is None:
        k = (L - 1) // 2
    if k < 0 or k >= L:
        raise ValueError(f"window size k={k} out of range [0, {L-1}]")
    rows = [[sympify(values[i + j]) for j in range(k + 1)] for i in range(L - k)]
    return Matrix(rows)


def matchgate_rank(sigma: Signature, max_rank: Optional[int] = None) -> MatchgateRankResult:
    """Compute the standard-basis matchgate rank of a symmetric signature.

    Returns a `MatchgateRankResult` with the rank, the Hankel rank, the
    minimal recurrence (when recoverable), and a status flag.

    Algorithm:
        1. If sigma is zero, return rank 0.
        2. Form the most-square Hankel matrix of sigma's values.
        3. Compute its rank H.
        4. Return ceil(H / 2) as the matchgate rank.
        5. Recover the minimal recurrence by reading the null space of the
           order-H Hankel matrix when possible.

    The rank is bounded by `max_rank` if supplied; if the Hankel rank
    exceeds 2 * max_rank, the result reports status="exceeds_max".

    Args:
        sigma: a symmetric Signature.
        max_rank: optional upper bound on the rank to compute. If supplied
            and the rank exceeds the bound, the function returns early
            with status="exceeds_max".

    Returns:
        MatchgateRankResult.
    """
    if not isinstance(sigma, Signature):
        raise TypeError(f"matchgate_rank expects a Signature, got {type(sigma)}")

    values = sigma.values
    L = len(values)

    if all(sympify(v) == S.Zero for v in values):
        return MatchgateRankResult(
            rank=0, hankel_rank=0, order=0, recurrence=(), status="zero"
        )

    # Most-square Hankel; max rank = min(L-k, k+1) with k = (L-1)//2.
    H = hankel_matrix(values)
    hr = H.rank()
    rank = (hr + 1) // 2  # ceil(hr / 2)

    if max_rank is not None and rank > max_rank:
        return MatchgateRankResult(
            rank=None,
            hankel_rank=hr,
            status="exceeds_max",
            max_attempted=max_rank,
        )

    # Recover the minimal recurrence: form the Hankel matrix with window
    # k = hr; its null space gives the recurrence coefficients (c_0, ..., c_hr).
    # Requires L - hr >= 1 (rows) AND hr + 1 <= L (columns); the latter is
    # automatic since hr <= L/2. If L - hr < 1, we can't form the matrix.
    if hr == 0:
        # Zero signature already handled; reaching here means rank is 0
        # but signature is non-zero -- shouldn't happen.
        return MatchgateRankResult(
            rank=0, hankel_rank=0, order=0, recurrence=(),
            status="computed",
        )

    if L - hr < 1 or hr + 1 > L:
        return MatchgateRankResult(
            rank=rank,
            hankel_rank=hr,
            order=None,
            recurrence=None,
            status="underdetermined",
        )

    H_min = hankel_matrix(values, k=hr)
    ns = H_min.nullspace()
    if not ns:
        return MatchgateRankResult(
            rank=rank,
            hankel_rank=hr,
            order=hr,
            recurrence=None,
            status="computed",
        )
    rec = ns[0]
    recurrence = tuple(rec[i] for i in range(rec.shape[0]))

    return MatchgateRankResult(
        rank=rank,
        hankel_rank=hr,
        order=hr,
        recurrence=recurrence,
        status="computed",
    )
