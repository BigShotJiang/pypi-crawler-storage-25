r"""Scheduling adapter: from scheduling-instance descriptions to Holant signatures.

This module is the first step of the empirical-validation project sketched
in `examples/07-structural-fingerprint/README.md`. It converts a
scheduling instance (jobs, machines, capacities, precedence constraints)
into the corresponding Holant configuration (a list of signature +
variable-list pairs), then lifts the v0.1.5 four-coordinate apparatus to
instance-level structural analysis.

## Scope (first cut)

Captures the natural HPC-batch-scheduling primitives:

- **Jobs** with a name (and optionally a processor requirement, walltime,
  priority, deadline -- not all used by every compilation).
- **Machines** with a capacity (number of jobs that can run concurrently).
- **Precedence constraints**: ordered pairs (before_job, after_job).
- **Exclusions**: unordered pairs (job_a, job_b) that cannot share a machine.

The compilation produces the standard bipartite-assignment encoding:

- Variables: x_{j, m} = "is job j assigned to machine m?"  (binary)
- For each job j: EXACT_1 on its row (x_{j, 1}, ..., x_{j, M})
  -- each job assigned to exactly one machine.
- For each machine m: AT_MOST_capacity_m on its column
  (x_{1, m}, ..., x_{N, m})  -- capacity bound per machine.
- (Precedence and exclusions deferred to a follow-up; they need an
  additional time-slot variable and the constraint hypergraph
  representation that goes with it.)

## What the adapter produces

`compile_to_holant(instance)` returns a `CompiledInstance` with:

- `signatures`: list of (Signature, variable_index_list) pairs.
- `variables`: the global ordered list of (job, machine) variable names.
- The constraint hypergraph is implicit in the variable-index lists.

`instance_coordinates(instance)` lifts the four v0.1.5 coordinates to
instance-level statistics:

- Per-signature matchgate ranks and an aggregate `max_rank`.
- Field-extension distance of the distinct-signature set.
- Sub-signature coverage (per-signature and aggregate).
- (Genus extraction is deferred -- requires constraint hypergraph
  embedding logic that is a separate research thread.)

## Honest scope

- This adapter handles the **bipartite-assignment-with-capacity** family.
  Precedence DAGs, deadlines, gang scheduling, and modular / cyclic
  structure are documented in the data model but not yet compiled to
  Holant. Adding each is a focused engineering step.

- The Cai-Lu single-chart limitation propagates through. EXACT_1 (job
  assignment) and AT_MOST_k (capacity) both have Forms with realising
  bases involving zero entries, which the v0.2 chart misses. The
  field-extension distance therefore commonly reports "exceeds_max" for
  configurations of these primitives -- a chart-coverage artefact, not
  a genuine non-realisability. The matchgate-rank and coverage
  coordinates are chart-independent and unaffected.

- This is **not** a SLURM / AMPL / MiniZinc parser. Building a parser
  for any of those is a separate engineering step that takes this
  module's `SchedulingInstance` as the intermediate representation.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .signatures import Signature
from .matchgate_rank import matchgate_rank, MatchgateRankResult
from .srp_solver import field_extension_distance, FieldExtensionDistanceResult
from .coverage import signature_coverage, configuration_coverage, ConfigurationCoverageResult


# ---------------------------------------------------------------------------
# Scheduling-instance data model
# ---------------------------------------------------------------------------


@dataclass
class Job:
    """A schedulable job.

    Attributes:
        name: identifier (e.g., "J1", "compile-suite").
        processors: number of processors / resource units the job needs.
            Not all compilations use this; the bipartite-assignment-with-
            capacity encoding treats each job as consuming 1 resource
            unit on its assigned machine.
        walltime: optional walltime estimate (seconds). Informational
            unless a time-slot compilation is used.
        priority: optional priority tag (informational).
        deadline: optional deadline (seconds from t=0). Informational.
    """

    name: str
    processors: int = 1
    walltime: Optional[float] = None
    priority: Optional[int] = None
    deadline: Optional[float] = None


@dataclass
class Machine:
    """A compute resource that runs jobs.

    Attributes:
        name: identifier (e.g., "M1", "gpu-node-2").
        capacity: number of jobs that can run on this machine concurrently
            (the resource-unit budget in the bipartite-assignment-with-
            capacity encoding). For the simplest "one job per machine"
            problem, capacity = 1.
    """

    name: str
    capacity: int = 1


@dataclass
class SchedulingInstance:
    """A scheduling instance: jobs, machines, optional constraints.

    The bipartite-assignment-with-capacity compilation uses `jobs`,
    `machines`, and per-machine capacities directly. Precedence and
    exclusions are recorded but not yet compiled to Holant.

    Attributes:
        jobs: ordered list of Job objects.
        machines: ordered list of Machine objects.
        precedence: optional list of (before_job_name, after_job_name)
            pairs. Recorded; not yet compiled (needs time-slot variables).
        exclusions: optional list of (job_a_name, job_b_name) pairs that
            cannot share a machine. Recorded; not yet compiled (needs a
            dedicated NAND-style signature per pair).
        name: optional instance display name.
    """

    jobs: List[Job]
    machines: List[Machine]
    precedence: List[Tuple[str, str]] = field(default_factory=list)
    exclusions: List[Tuple[str, str]] = field(default_factory=list)
    name: str = ""

    def __post_init__(self):
        # Validate uniqueness of names
        job_names = [j.name for j in self.jobs]
        machine_names = [m.name for m in self.machines]
        if len(set(job_names)) != len(job_names):
            raise ValueError(f"duplicate job names: {job_names}")
        if len(set(machine_names)) != len(machine_names):
            raise ValueError(f"duplicate machine names: {machine_names}")

    @property
    def num_variables(self) -> int:
        """Number of (job, machine) binary variables."""
        return len(self.jobs) * len(self.machines)

    def variable_index(self, job_name: str, machine_name: str) -> int:
        """Return the canonical index of the x_{job, machine} variable."""
        job_idx = next(i for i, j in enumerate(self.jobs) if j.name == job_name)
        machine_idx = next(i for i, m in enumerate(self.machines) if m.name == machine_name)
        return job_idx * len(self.machines) + machine_idx

    def variable_name(self, idx: int) -> str:
        n_machines = len(self.machines)
        job = self.jobs[idx // n_machines]
        machine = self.machines[idx % n_machines]
        return f"x[{job.name},{machine.name}]"


@dataclass
class CompiledInstance:
    """A scheduling instance compiled to a Holant configuration.

    Attributes:
        signatures: list of (Signature, variable_index_list) pairs. Each
            entry says "this signature applies to these variable indices".
        variables: ordered list of variable names (matches indices).
        instance_name: display name from the source SchedulingInstance.
        num_variables: total number of variables.
        compilation_notes: any informational notes from the compilation
            (e.g., "capacity > 1 produced rank-2 signature for machine M3").
    """

    signatures: List[Tuple[Signature, List[int]]]
    variables: List[str]
    instance_name: str = ""
    num_variables: int = 0
    compilation_notes: List[str] = field(default_factory=list)

    @property
    def distinct_signatures(self) -> List[Signature]:
        """Distinct signature objects appearing in the compilation."""
        seen = []
        for sig, _ in self.signatures:
            if not any(s.values == sig.values for s in seen):
                seen.append(sig)
        return seen


# ---------------------------------------------------------------------------
# Compilation: scheduling instance -> Holant configuration
# ---------------------------------------------------------------------------


def _exact_1_n(n: int) -> Signature:
    """Symmetric arity-n EXACT_1 signature: weight-w value = 1 iff w == 1."""
    return Signature(
        values=tuple(1 if w == 1 else 0 for w in range(n + 1)),
        kind="recognizer",
        name=f"EXACT_1_{n}",
    )


def _at_most_k_n(k: int, n: int) -> Signature:
    """Symmetric arity-n AT_MOST_k signature: weight-w value = 1 iff w <= k."""
    return Signature(
        values=tuple(1 if w <= k else 0 for w in range(n + 1)),
        kind="recognizer",
        name=f"AT_MOST_{k}_{n}",
    )


def compile_to_holant_time_slot(instance: SchedulingInstance) -> CompiledInstance:
    """Compile a SchedulingInstance using the TIME-SLOT encoding.

    Each machine of capacity c is unfolded into c individual slots. The
    variable layout is x[job, slot] where slot indexes the full pool of
    sum(machine.capacity for machine in machines) slots.

    Signatures:
      - Per job j: EXACT_1 on its row of all S slots
        (each job assigned to exactly one slot). Arity = S.
      - Per slot s: AT_MOST_1 on its column of all N job variables
        (each slot accepts at most one job). Arity = N.

    Both signatures are matchgate rank 1 (EXACT_1_n and AT_MOST_1_n
    both have Hankel rank 2 regardless of n). The product_rank_bound
    of any compiled instance is therefore 1.

    The cost moves from (ceil(C/2))^M * poly(NM) for the original
    bipartite-assignment-with-capacity encoding to 1 * poly(N*S) for
    the time-slot encoding. The structural improvement is the rank
    coordinate collapsing from O(C) to O(1) at the price of NMC
    variables instead of NM.

    Args:
        instance: a SchedulingInstance with per-machine capacities.

    Returns:
        CompiledInstance whose distinct_signatures are at most two
        (EXACT_1_S and AT_MOST_1_N), each of rank 1.
    """
    n_jobs = len(instance.jobs)
    if n_jobs == 0:
        return CompiledInstance(
            signatures=[],
            variables=[],
            instance_name=instance.name,
            num_variables=0,
            compilation_notes=["empty instance"],
        )

    # Build the slot pool: each machine of capacity c contributes c slots
    slot_descriptors: List[Tuple[str, int]] = []
    for machine in instance.machines:
        for s_idx in range(machine.capacity):
            slot_descriptors.append((machine.name, s_idx))
    n_slots = len(slot_descriptors)
    if n_slots == 0:
        return CompiledInstance(
            signatures=[],
            variables=[],
            instance_name=instance.name,
            num_variables=0,
            compilation_notes=["no slots (all machines have capacity 0)"],
        )

    # Variables: x[job_idx, slot_idx], laid out row-major (jobs * slots).
    variables = [
        f"x[{instance.jobs[j].name},{m_name}#{s_idx}]"
        for j in range(n_jobs)
        for (m_name, s_idx) in slot_descriptors
    ]

    signatures: List[Tuple[Signature, List[int]]] = []
    notes: List[str] = []

    # Per-job EXACT_1 over the full slot pool
    exact_1_S = _exact_1_n(n_slots)
    for job_idx in range(n_jobs):
        row_indices = [job_idx * n_slots + s for s in range(n_slots)]
        signatures.append((exact_1_S, row_indices))

    # Per-slot AT_MOST_1 over the N job variables for that slot
    at_most_1_N = _at_most_k_n(1, n_jobs)
    for s_idx in range(n_slots):
        col_indices = [j_idx * n_slots + s_idx for j_idx in range(n_jobs)]
        signatures.append((at_most_1_N, col_indices))

    notes.append(
        f"time-slot encoding: {n_jobs} jobs * {n_slots} slots = "
        f"{n_jobs * n_slots} variables. Per-signature ranks all 1."
    )
    if instance.precedence:
        notes.append(
            f"precedence constraints recorded ({len(instance.precedence)} edges) "
            "but not yet compiled."
        )

    return CompiledInstance(
        signatures=signatures,
        variables=variables,
        instance_name=instance.name,
        num_variables=n_jobs * n_slots,
        compilation_notes=notes,
    )


def compile_to_holant(instance: SchedulingInstance) -> CompiledInstance:
    """Compile a SchedulingInstance to a Holant configuration.

    Standard bipartite-assignment-with-capacity encoding:
      - Variables: x[job, machine], one per (job, machine) pair.
      - Per job: EXACT_1 on the row of variables (one machine per job).
      - Per machine: AT_MOST_capacity on the column of variables.

    Args:
        instance: a SchedulingInstance.

    Returns:
        CompiledInstance with signatures + variables + compilation notes.
    """
    if instance.precedence:
        # Documented but not yet implemented; flag rather than silently ignore.
        pass  # accumulated as a compilation note below
    if instance.exclusions:
        pass

    n_jobs = len(instance.jobs)
    n_machines = len(instance.machines)

    variables = [
        instance.variable_name(i) for i in range(n_jobs * n_machines)
    ]

    signatures: List[Tuple[Signature, List[int]]] = []
    notes: List[str] = []

    # Per-job EXACT_1 signatures
    exact_1_sig = _exact_1_n(n_machines)
    for job_idx, job in enumerate(instance.jobs):
        row_indices = [job_idx * n_machines + m_idx for m_idx in range(n_machines)]
        signatures.append((exact_1_sig, row_indices))

    # Per-machine AT_MOST_capacity_n signatures
    for m_idx, machine in enumerate(instance.machines):
        col_indices = [j_idx * n_machines + m_idx for j_idx in range(n_jobs)]
        cap_sig = _at_most_k_n(machine.capacity, n_jobs)
        signatures.append((cap_sig, col_indices))
        # Inform the user when the capacity signature is non-trivial.
        if machine.capacity >= n_jobs:
            # Vacuously satisfied: every assignment satisfies the bound.
            pass
        elif machine.capacity >= 2 and n_jobs >= 4:
            notes.append(
                f"machine {machine.name!r} cap={machine.capacity} on {n_jobs} jobs: "
                f"AT_MOST_{machine.capacity}_{n_jobs} (non-trivial; rank > 1 expected)"
            )

    if instance.precedence:
        notes.append(
            f"precedence constraints recorded ({len(instance.precedence)} edges) "
            "but not yet compiled to Holant -- needs time-slot variables."
        )
    if instance.exclusions:
        notes.append(
            f"exclusion constraints recorded ({len(instance.exclusions)} pairs) "
            "but not yet compiled to Holant -- needs per-pair NAND signatures "
            "on the machine column slices."
        )

    return CompiledInstance(
        signatures=signatures,
        variables=variables,
        instance_name=instance.name,
        num_variables=n_jobs * n_machines,
        compilation_notes=notes,
    )


# ---------------------------------------------------------------------------
# Coordinate analysis: lift the v0.1.5 four coordinates to instance level
# ---------------------------------------------------------------------------


@dataclass
class InstanceCoordinates:
    """Instance-level structural-fingerprint coordinates.

    Attributes:
        instance_name: display name from the source.
        num_variables: number of (job, machine) variables.
        num_signature_uses: total number of signature uses in the
            compilation (one per job + one per machine, in the bipartite
            encoding).
        distinct_signatures: number of structurally distinct signatures.
        per_signature_rank: dict mapping signature display name to its
            matchgate rank (coord. i).
        max_rank: max over per-signature ranks. The dominant rank factor
            in the cost formula.
        product_rank_bound: upper bound on prod_v r_v assuming each
            signature use contributes its rank; this is the
            sum-of-Pfaffians term count.
        field_extension_distance: minimum prime where the distinct-
            signature set becomes SRP-feasible (coord. iii). None if
            no feasibility found in the tried primes (often a single-
            chart artefact -- see module docstring).
        configuration_coverage: per-signature + aggregate coverage stats
            (coord. iv).
        compilation_notes: any informational notes from the compilation.
    """

    instance_name: str
    num_variables: int
    num_signature_uses: int
    distinct_signatures: int
    per_signature_rank: Dict[str, int]
    max_rank: int
    product_rank_bound: int
    field_extension_distance: Optional[int]
    field_extension_status: str
    configuration_coverage: ConfigurationCoverageResult
    compilation_notes: List[str]

    def __repr__(self) -> str:
        return (
            f"InstanceCoordinates({self.instance_name!r}: "
            f"V={self.num_variables}, distinct sigs={self.distinct_signatures}, "
            f"max_rank={self.max_rank}, "
            f"prod_rank<={self.product_rank_bound}, "
            f"distance={self.field_extension_distance}, "
            f"coverage_mean={self.configuration_coverage.mean_coverage:.3f})"
        )


def instance_coordinates(
    instance: SchedulingInstance,
    compute_field_distance: bool = True,
    encoding: str = "bipartite-capacity",
) -> InstanceCoordinates:
    """Compute the v0.1.5 four-coordinate structural fingerprint on an instance.

    Two encodings supported:

    - `"bipartite-capacity"` (default, v0.1.6): per-job EXACT_1 across
      machines + per-machine AT_MOST_k across jobs. Matchgate rank
      scales as ceil(k/2)+1 where k = capacity. Rank-explosive for
      large capacity.

    - `"time-slot"` (v0.1.9): each machine of capacity c is unfolded
      into c slots. Per-job EXACT_1 across all slots + per-slot
      AT_MOST_1 across jobs. All signatures are matchgate rank 1
      regardless of capacity. Larger Pfaffians (NMC variables vs NM),
      but product_rank stays at 1 -- the structural cost collapses from
      (ceil(k/2))^M to 1.

    Empirical demonstration (KTH-SP2 archive, see example 09):

      Cell                bipartite-capacity         time-slot
      ----                ------------------         ---------
      24h P=25 cap=4      rank 3, prod_rank=8e11    rank 1, prod_rank=1
      24h P=4  cap=25     rank 13, prod_rank=29k    rank 1, prod_rank=1
      6h  P=2  cap=50     rank 26, prod_rank=...    rank 1, prod_rank=1

    Pipeline (both encodings):
      1. Compile (compile_to_holant or compile_to_holant_time_slot).
      2. matchgate_rank per distinct signature.
      3. field_extension_distance on the distinct-signature set
         (skipped if compute_field_distance=False).
      4. signature_coverage on the distinct-signature set.

    Args:
        instance: a SchedulingInstance.
        compute_field_distance: skip the slow field-ext computation
            when False.
        encoding: "bipartite-capacity" or "time-slot".

    Returns:
        InstanceCoordinates.
    """
    if encoding == "bipartite-capacity":
        compiled = compile_to_holant(instance)
    elif encoding == "time-slot":
        compiled = compile_to_holant_time_slot(instance)
    else:
        raise ValueError(f"unknown encoding {encoding!r}; expected "
                         f"'bipartite-capacity' or 'time-slot'")

    distinct_sigs = compiled.distinct_signatures

    per_sig_rank: Dict[str, int] = {}
    for sig in distinct_sigs:
        mr = matchgate_rank(sig)
        per_sig_rank[sig.name or f"<sig_arity_{sig.arity}>"] = mr.rank

    # Product-rank bound: each signature USE (not just distinct signature)
    # contributes its rank to the product.
    product_rank_bound = 1
    for sig, _ in compiled.signatures:
        r = per_sig_rank.get(sig.name or f"<sig_arity_{sig.arity}>", 1)
        product_rank_bound *= r

    max_rank = max(per_sig_rank.values()) if per_sig_rank else 1

    # Field-extension distance on the distinct-signature set (opt-in fast-path skip)
    if compute_field_distance:
        fd = field_extension_distance(distinct_sigs)
        fd_distance = fd.distance
        fd_status = fd.status
    else:
        fd_distance = None
        fd_status = "skipped"

    # Configuration coverage on the distinct-signature set
    cov = configuration_coverage(distinct_sigs)

    return InstanceCoordinates(
        instance_name=instance.name,
        num_variables=compiled.num_variables,
        num_signature_uses=len(compiled.signatures),
        distinct_signatures=len(distinct_sigs),
        per_signature_rank=per_sig_rank,
        max_rank=max_rank,
        product_rank_bound=product_rank_bound,
        field_extension_distance=fd_distance,
        field_extension_status=fd_status,
        configuration_coverage=cov,
        compilation_notes=compiled.compilation_notes,
    )
