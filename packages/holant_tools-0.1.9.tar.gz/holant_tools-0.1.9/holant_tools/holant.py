"""Holant evaluation layer for matchgate networks on genus-g surfaces.

v0.3 (alpha): symbolic Pfaffian + Arf-signed sum over spin structures.

This module complements v0.2's realizability layer (`srp_solve` on the basis
manifold M). v0.2 decides whether a common basis exists; this module
*evaluates* the Holant given the basis and the Kasteleyn-oriented matrices.

For planar (genus 0) matchgate networks, the Holant equals a single Pfaffian
(FKT 1961). For genus-g networks, the Galluccio-Loebl formula gives

    Holant(Omega) = (1 / 2^g) * sum_{theta in Spin(Sigma_g)} Arf(theta) Pf(M_theta)

with |Spin(Sigma_g)| = 2^{2g} and M_theta the Kasteleyn-oriented matrix
indexed by spin structure theta. v0.3-alpha takes the M_theta as input
(deferring automatic Kasteleyn-orientation construction to v0.3-beta) and
implements the evaluation:

    pfaffian(M)                  -- O(n^3) skew-LDLT Pfaffian (Parlett-Reid)
    arf_invariant_genus_1(theta) -- Arf for the four spin structures on the torus
    holant_genus_g(matrices, g)  -- Galluccio-Loebl signed sum

See BOUNDED_GENUS.md for the full design + scope statement.
"""

from __future__ import annotations
from typing import Dict, List, Sequence, Tuple

from sympy import Matrix, Rational, S, Symbol, sympify


# ---------------------------------------------------------------------------
# Pfaffian (symbolic, recursive)
# ---------------------------------------------------------------------------

def pfaffian(M):
    """Pfaffian of a symbolic antisymmetric matrix.

    For a 2n x 2n antisymmetric matrix M, Pf(M) is defined by

        Pf(M)^2 = det(M)

    with a definite sign convention. Computed via the Parlett-Reid skew-symmetric
    LDLT decomposition in O(n^3): reduce M to skew-block-tridiagonal form via
    simultaneous row + column operations; Pfaffian is the product of the
    super-diagonal 2x2 blocks' (2i, 2i+1) entries times a sign from row/col swaps.

    For small matrices (n <= 4) the recursive Galbiati-Maffioli formula
    Pf(M) = sum_{j=1}^{2n-1} (-1)^{j+1} M[0, j] * Pf(M with rows/cols 0, j removed)
    is also correct and is used as a fallback / clarity reference.

    Args:
        M: a sympy Matrix (numerical or symbolic).

    Returns:
        sympy expression for Pf(M).
    """
    if not isinstance(M, Matrix):
        M = Matrix(M)
    n = M.shape[0]
    if M.shape[1] != n:
        raise ValueError(f"matrix must be square, got shape {M.shape}")
    if n % 2 != 0:
        # Pfaffian of an odd-dimensional antisymmetric matrix is zero.
        return S.Zero
    if n == 0:
        return S.One
    if n == 2:
        return M[0, 1]

    # For small matrices, use the recursive formula directly (it's a single
    # expansion for n=4 -- 3 terms -- and faster than setting up the LDLT pivoting).
    if n == 4:
        return (
            M[0, 1] * M[2, 3]
            - M[0, 2] * M[1, 3]
            + M[0, 3] * M[1, 2]
        )

    # Parlett-Reid: simultaneous row + column operations on a working copy.
    A = Matrix(M)
    sign = S.One
    for i in range(0, n - 1, 2):
        # Pivot: A[i+1, i]. If zero, search for a non-zero entry in column i
        # below row i, then swap rows and cols to bring it to position (i+1, i).
        if A[i + 1, i] == 0:
            pivot = None
            for j in range(i + 2, n):
                if A[j, i] != 0:
                    pivot = j
                    break
            if pivot is None:
                return S.Zero
            A.row_swap(i + 1, pivot)
            A.col_swap(i + 1, pivot)
            sign = -sign
        # Eliminate A[j, i] for j > i+1 by row op (and col op to maintain antisymmetry).
        for j in range(i + 2, n):
            if A[j, i] != 0:
                ratio = A[j, i] / A[i + 1, i]
                # Row j -= ratio * row (i+1)
                for k in range(n):
                    A[j, k] = A[j, k] - ratio * A[i + 1, k]
                # Col j -= ratio * col (i+1)
                for k in range(n):
                    A[k, j] = A[k, j] - ratio * A[k, i + 1]
    # Pfaffian is sign * product of super-diagonal entries of 2x2 blocks.
    result = sign
    for i in range(0, n, 2):
        result = result * A[i, i + 1]
    return result


# ---------------------------------------------------------------------------
# Spin structures on Sigma_g and their Arf invariants
# ---------------------------------------------------------------------------

# A spin structure is an element of (Z/2)^{2g}. We represent it as a tuple
# of 2g bits. For g = 1, this is (epsilon_1, epsilon_2) in {0, 1}^2.

SpinStructure = Tuple[int, ...]


def spin_structures_genus(g: int) -> List[SpinStructure]:
    """Enumerate the 2^{2g} spin structures on Sigma_g.

    Conventional ordering: lexicographic on tuples of 2g bits.
    """
    if g < 0:
        raise ValueError(f"genus must be >= 0, got {g}")
    if g == 0:
        return [()]  # single (trivial) spin structure on the sphere
    structures: List[SpinStructure] = []
    for mask in range(1 << (2 * g)):
        structures.append(tuple((mask >> i) & 1 for i in range(2 * g)))
    return structures


def arf_invariant(theta: SpinStructure) -> int:
    """Arf-invariant sign of a spin structure on Sigma_g.

    Convention. A spin structure theta = (epsilon_1, ..., epsilon_{2g}) is the
    coordinate vector of a quadratic form q_theta on H_1(Sigma_g; Z/2) with
    respect to a symplectic basis {a_1, b_1, ..., a_g, b_g}, where
    q_theta(a_i) = epsilon_{2i-1} and q_theta(b_i) = epsilon_{2i}.

    The Z/2-valued Arf invariant of q is

        Arf(q) = sum_{i=1}^g q(a_i) * q(b_i)  in Z/2.

    The sign returned here is

        sign(theta) = (-1)^{Arf(q_theta)}

    so for genus 1:

        sign((0, 0)) = +1   (Arf = 0)
        sign((0, 1)) = +1   (Arf = 0)
        sign((1, 0)) = +1   (Arf = 0)
        sign((1, 1)) = -1   (Arf = 1)

    For genus 0 the spin structure is trivial and the sign is +1.

    Note on labeling. The "which spin structure is the special one" depends
    on the choice of symplectic basis for H_1(Sigma_g; Z/2). The convention
    above places the negative sign on theta = (1, 1, ..., 1) and other
    Arf-odd structures. When supplying matrices to holant_genus_g, the
    caller must use the same labeling (i.e., the Kasteleyn orientation
    obtained by "twisting" along both homology cycles is M_{(1, 1)}, etc.).
    This matches Cimasoni-Reshetikhin 2007 / Norine 2008.
    """
    if len(theta) == 0:
        return 1  # genus 0
    if len(theta) % 2 != 0:
        raise ValueError(f"spin structure must have even length, got {len(theta)}")
    g = len(theta) // 2
    arf = sum(theta[2 * i] * theta[2 * i + 1] for i in range(g)) % 2
    return 1 if arf == 0 else -1


def arf_invariant_genus_1(theta: SpinStructure) -> int:
    """Arf sign specialised to genus 1.

    Three even structures (Arf = 0, sign +1) and one odd (Arf = 1, sign -1):

        sign((0, 0)) = +1
        sign((0, 1)) = +1
        sign((1, 0)) = +1
        sign((1, 1)) = -1
    """
    if len(theta) != 2:
        raise ValueError(f"genus-1 spin structure must have length 2, got {len(theta)}")
    return arf_invariant(theta)


# ---------------------------------------------------------------------------
# Galluccio-Loebl Holant evaluation
# ---------------------------------------------------------------------------

def holant_genus_g(matrices: Dict[SpinStructure, Matrix], genus: int):
    """Galluccio-Loebl signed sum of Pfaffians over spin structures.

        Holant = (1 / 2^g) * sum_theta Arf(theta) * Pf(M_theta)

    Args:
        matrices: dict mapping spin structure (tuple of 2g bits) to its
            Kasteleyn-oriented antisymmetric matrix M_theta. Must contain
            exactly the 2^{2g} expected spin structures.
        genus: genus g of the surface.

    Returns:
        sympy expression for the Holant.

    For genus 0, the input dict has one entry under key (); the result is
    just Pf(M_()) (the FKT planar Pfaffian).

    For genus 1, the input dict must have 4 entries; the result is
    (1/2) * (Arf-signed sum of the 4 Pfaffians).
    """
    expected = spin_structures_genus(genus)
    if set(matrices.keys()) != set(expected):
        raise ValueError(
            f"matrices dict keys {set(matrices.keys())} do not match the "
            f"expected spin structures {set(expected)} for genus {genus}"
        )

    total = S.Zero
    for theta in expected:
        a = arf_invariant(theta)
        total += a * pfaffian(matrices[theta])

    if genus == 0:
        return total  # division by 2^0 = 1 is a no-op
    return Rational(1, 2 ** genus) * total


def holant_planar(M):
    """Convenience: Holant for a planar (genus 0) matchgrid is just Pf(M)."""
    return pfaffian(M)


# ---------------------------------------------------------------------------
# Sum-of-Pfaffians evaluator for bounded-matchgate-rank Holant networks
# ---------------------------------------------------------------------------
#
# Setup. A Holant network with signatures sigma_v at each vertex v. If
# every sigma_v decomposes as
#
#     sigma_v = sum_{j=1}^{r_v} lambda_{v, j} * sigma_{v, j}^{mg}
#
# where each sigma_{v, j}^{mg} is matchgate-realisable, then by
# multilinearity of the Holant in the per-vertex signatures:
#
#     Holant(Omega)
#       = sum_{(j_1, ..., j_V)} (prod_v lambda_{v, j_v}) * Holant(Omega_{j_1, ..., j_V})
#
# where Omega_{j_1, ..., j_V} is the matchgate network from selecting
# component j_v at vertex v. Each summand is computable via either
# holant_planar (genus 0) or holant_genus_g (genus g). Total cost:
# (prod_v r_v) * (1 for planar; 4^g for genus g) Pfaffians.
#
# Together with matchgate_rank, these are the building blocks for Holant
# evaluation of configurations whose per-vertex signatures are not
# individually matchgate-realisable but are bounded sums of matchgate
# components. See Bravyi 2008's "matchgate rank" for fermionic states for
# the direct analogue.


def holant_sum_of_pfaffians(terms):
    """Weighted sum of Pfaffians of antisymmetric matrices.

        sum_i coefficient_i * Pf(matrix_i)

    Intended for evaluating a Holant whose per-vertex signatures are
    matchgate-rank-r_v decompositions: one term per choice (j_1, ..., j_V)
    of matchgate components, coefficient prod_v lambda_{v, j_v},
    matrix the Kasteleyn-oriented antisymmetric matrix of the resulting
    planar matchgate network.

    Args:
        terms: iterable of (coefficient, matrix) pairs. Coefficient is
            any sympy expression. Matrix is a sympy Matrix (or array-like
            convertible by sympy.Matrix), antisymmetric, even-dimensional.

    Returns:
        sympy expression for the weighted Pfaffian sum.
    """
    total = S.Zero
    for coeff, M in terms:
        total = total + sympify(coeff) * pfaffian(M)
    return total


def holant_sum_of_genus_g(terms, genus):
    """Weighted sum of genus-g Galluccio-Loebl Holants.

        sum_i coefficient_i * holant_genus_g(matrices_i, genus)

    Combines bounded matchgate rank (the per-vertex decomposition) with
    bounded genus (the spin-structure sum). Total cost is
    sum_i 2^{2g} Pfaffians = |terms| * 4^g Pfaffians.

    Args:
        terms: iterable of (coefficient, matrices_dict) pairs, where each
            matrices_dict maps spin structures (tuples of 2g bits) to
            their Kasteleyn-oriented antisymmetric matrices -- the
            standard input format of holant_genus_g.
        genus: genus g of the surface (same for every term).

    Returns:
        sympy expression for the weighted Galluccio-Loebl-summed Holant.
    """
    total = S.Zero
    for coeff, matrices in terms:
        total = total + sympify(coeff) * holant_genus_g(matrices, genus)
    return total
