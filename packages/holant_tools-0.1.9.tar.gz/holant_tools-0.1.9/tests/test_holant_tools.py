"""Smoke tests for holant-tools.

Run as:
    python -m pytest tests/
or:
    python tests/test_holant_tools.py
"""

from sympy import sympify, simplify, sqrt, I, expand, Matrix, Symbol, symbols

from holant_tools.signatures import (
    Signature,
    find_recurrence,
    is_realizable_somewhere,
    srp_necessary_check,
)
from holant_tools.realizability import (
    Form,
    classify_form,
    realizability_subvariety,
    U,
    V,
)
from holant_tools.intersection import intersect_subvarieties
from holant_tools.srp_solver import (
    srp_solve,
    FieldExtensionDistanceResult,
    field_extension_distance,
)
from holant_tools.holant import (
    pfaffian,
    arf_invariant,
    arf_invariant_genus_1,
    spin_structures_genus,
    holant_genus_g,
    holant_planar,
    holant_sum_of_pfaffians,
    holant_sum_of_genus_g,
)
from holant_tools.matchgate_rank import (
    MatchgateRankResult,
    hankel_matrix,
    matchgate_rank,
)
from holant_tools.coverage import (
    SignatureCoverageResult,
    ConfigurationCoverageResult,
    enumerate_restrictions,
    signature_coverage,
    configuration_coverage,
)
from holant_tools.non_symmetric import (
    NonSymmetricSignature,
    pullback_tau_non_symmetric,
    realizability_subvariety_non_symmetric,
    matchgate_identity_arity_4_even,
    matchgate_identity_arity_4_odd,
)
from holant_tools.hardness import hardness_candidate, HardnessReport
from holant_tools import examples


def test_eq_2_realizable():
    """[1, 0, 1] satisfies a*x_0 + b*x_1 + c*x_2 = 0  =>  a + c = 0."""
    sig = examples.EQUALITY_2_REC
    rec = find_recurrence(sig)
    assert rec is not None, "EQ_2 should be realizable"
    assert rec.a + rec.c == 0, f"Expected a + c = 0, got {rec}"
    print(f"  test_eq_2_realizable: OK ({rec})")


def test_or_3_realizable():
    """[0, 1, 1, 1] satisfies a recurrence: a*0+b*1+c*1=0, a*1+b*1+c*1=0, a*1+b*1+c*1=0."""
    sig = examples.OR_k_GEN(3)
    rec = find_recurrence(sig)
    assert rec is not None, "OR_3 should be realizable"
    print(f"  test_or_3_realizable: OK ({rec})")


def test_nae_3_realizable():
    """[0, 1, 1, 0] satisfies recurrence (1, -1, 1): x_k - x_{k+1} + x_{k+2} = 0."""
    sig = examples.NAE_k(3)
    rec = find_recurrence(sig)
    assert rec is not None, "NAE_3 should be realizable"
    print(f"  test_nae_3_realizable: OK ({rec})")


def test_non_realizable_caught():
    """A signature where the only recurrence is trivial."""
    sig = examples.NON_REALIZABLE_EXAMPLE
    rec = find_recurrence(sig)
    assert rec is None, f"Expected non-realizable, got {rec}"
    print(f"  test_non_realizable_caught: OK")


def test_zero_signature_trivially_realizable():
    """A zero signature is trivially realizable on any basis."""
    sig = Signature((0, 0, 0, 0), "recognizer", "zero")
    assert is_realizable_somewhere(sig), "Zero signature should be realizable"
    print("  test_zero_signature_trivially_realizable: OK")


def test_srp_necessary_check_cai_lu_5_1():
    """The signatures from Cai-Lu sec. 5.1 each pass individual realizability."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = srp_necessary_check(sigs)
    assert result["feasible_necessary"], (
        f"Expected pass; got infeasible {result['infeasible_signatures']}"
    )
    print(f"  test_srp_necessary_check_cai_lu_5_1: OK ({len(sigs)} sigs, all realizable)")


def test_srp_necessary_check_with_non_realizable():
    """Mixing realizable and non-realizable: should report failure."""
    sigs = [examples.EQUALITY_2_REC, examples.NON_REALIZABLE_EXAMPLE]
    result = srp_necessary_check(sigs)
    assert not result["feasible_necessary"], "Mixed set should fail necessary check"
    assert len(result["infeasible_signatures"]) == 1
    print("  test_srp_necessary_check_with_non_realizable: OK")


# ---------------------------------------------------------------------------
# v0.2 tests: Form classification
# ---------------------------------------------------------------------------


def test_form_eq_2_is_form_1():
    """EQ_2 = [1, 0, 1]: Form 1 with roots {1, -1}."""
    fc = classify_form(examples.EQUALITY_2_REC)
    assert fc is not None
    assert fc.form == Form.FORM_1
    roots = sorted(fc.roots, key=lambda r: float(r) if r.is_real else 99)
    assert sympify(roots[0]) == -1 and sympify(roots[1]) == 1, f"roots {roots}"
    print(f"  test_form_eq_2_is_form_1: OK ({fc})")


def test_form_or_3_is_form_3():
    """OR_3 = [0, 1, 1, 1]: Form 3 (root zero, a = 0)."""
    fc = classify_form(examples.OR_k_GEN(3))
    assert fc is not None
    assert fc.form == Form.FORM_3
    assert sympify(0) in fc.roots, f"expected 0 in roots, got {fc.roots}"
    print(f"  test_form_or_3_is_form_3: OK ({fc})")


def test_form_nae_3_is_form_1_complex():
    """NAE_3 = [0, 1, 1, 0]: Form 1 with primitive 6th roots of unity."""
    fc = classify_form(examples.NAE_k(3))
    assert fc is not None
    assert fc.form == Form.FORM_1
    expected = {sympify("1/2") + I * sqrt(3) / 2, sympify("1/2") - I * sqrt(3) / 2}
    got = {simplify(r) for r in fc.roots}
    assert got == expected, f"roots {got} != {expected}"
    print(f"  test_form_nae_3_is_form_1_complex: OK ({fc})")


def test_form_pure_geometric_is_form_2():
    """[1, 2, 4, 8, 16]: pure geometric sequence, Form 2 with repeated root r=2."""
    sig = Signature(values=(1, 2, 4, 8, 16), name="geom-r2")
    fc = classify_form(sig)
    assert fc is not None and fc.form == Form.FORM_2
    assert sympify(fc.roots[0]) == 2
    print(f"  test_form_pure_geometric_is_form_2: OK ({fc})")


def test_form_doubly_degenerate():
    """EQ_3 = [1, 0, 0, 1]: Form 3 with doubly-degenerate recurrence (a = c = 0)."""
    fc = classify_form(examples.EQUALITY_3_REC)
    assert fc is not None and fc.form == Form.FORM_3
    print(f"  test_form_doubly_degenerate: OK ({fc})")


def test_form_non_realizable_is_none():
    fc = classify_form(examples.NON_REALIZABLE_EXAMPLE)
    assert fc is None
    print("  test_form_non_realizable_is_none: OK")


# ---------------------------------------------------------------------------
# v0.2 tests: realizability subvariety
# ---------------------------------------------------------------------------


def test_subvariety_eq_2_equations():
    """EQ_2 = [1, 0, 1] subvariety: even-parity {uv + 1 = 0}, odd-parity {u^2 + 1 = 0, v^2 + 1 = 0}."""
    sv = realizability_subvariety(examples.EQUALITY_2_REC)
    assert not sv.is_trivial
    # Even parity: one equation, should be u*v + 1.
    assert len(sv.even_parity_equations) == 1
    assert simplify(sv.even_parity_equations[0] - (U * V + 1)) == 0
    # Odd parity: two equations.
    assert len(sv.odd_parity_equations) == 2
    expected_odd = {U * U + 1, V * V + 1}
    got_odd = {simplify(eq) for eq in sv.odd_parity_equations}
    assert got_odd == expected_odd, f"got {got_odd}, expected {expected_odd}"
    print("  test_subvariety_eq_2_equations: OK")


def test_subvariety_or_3_tau_3_is_v_cubed_form():
    """OR_3 even-parity tau_3 = v^3 + 3v^2 + 3v = (1+v)^3 - 1."""
    sv = realizability_subvariety(examples.OR_k_GEN(3))
    # tau_3 is one of the even-parity equations.
    expected = V * V * V + 3 * V * V + 3 * V  # = (1+v)^3 - 1
    found = any(simplify(eq - expected) == 0 for eq in sv.even_parity_equations)
    assert found, f"could not find (1+v)^3 - 1 in {sv.even_parity_equations}"
    print("  test_subvariety_or_3_tau_3_is_v_cubed_form: OK")


def test_subvariety_zero_signature_trivial():
    sig = Signature(values=(0, 0, 0, 0), kind="recognizer", name="zero")
    sv = realizability_subvariety(sig)
    assert sv.is_trivial
    print("  test_subvariety_zero_signature_trivial: OK")


# ---------------------------------------------------------------------------
# v0.2 tests: intersection (full SRP)
# ---------------------------------------------------------------------------


def test_srp_cai_lu_5_1_feasible_mod_7():
    """Cai-Lu sec 5.1 SRP feasible over F_7 with witness (u, v) = (2, 3)."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = srp_solve(sigs, modulus=7)
    assert result.feasible, f"expected feasible, got {result}"
    u_val, v_val = result.witness[U], result.witness[V]
    # Either order: (2, 3) or (3, 2) since (u, v) ~ (v, u) on M.
    assert {int(u_val), int(v_val)} == {2, 3}, f"witness {result.witness}"
    print(f"  test_srp_cai_lu_5_1_feasible_mod_7: OK (witness u={u_val}, v={v_val})")


def test_srp_cai_lu_5_1_infeasible_over_Q():
    """Cai-Lu sec 5.1 SRP infeasible over algebraic closure of Q."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = srp_solve(sigs)
    assert not result.feasible, f"expected infeasible over Q-bar, got {result}"
    print("  test_srp_cai_lu_5_1_infeasible_over_Q: OK")


def test_srp_cai_lu_5_1_infeasible_mod_5():
    """Cai-Lu sec 5.1 SRP infeasible over F_5 (mod 7 is needed for cube roots)."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = srp_solve(sigs, modulus=5)
    assert not result.feasible
    print("  test_srp_cai_lu_5_1_infeasible_mod_5: OK")


def test_srp_short_circuits_on_individual_infeasibility():
    """If any sigma fails Theorem 2.5, srp_solve short-circuits."""
    sigs = [examples.EQUALITY_2_REC, examples.NON_REALIZABLE_EXAMPLE]
    result = srp_solve(sigs)
    assert not result.feasible
    assert len(result.infeasible_signatures) == 1
    print("  test_srp_short_circuits_on_individual_infeasibility: OK")


def test_srp_eq_2_alone_feasible_over_Q():
    """A single realizable signature has a non-empty B(sigma); SRP feasible."""
    result = srp_solve([examples.EQUALITY_2_REC])
    assert result.feasible
    u_val = result.witness[U]
    v_val = result.witness[V]
    # Witness should lie on one of the parity branches: uv + 1 = 0 or u^2 + 1 = v^2 + 1 = 0.
    branch = result.intersection.branch_combination[0]
    if branch == "even":
        assert simplify(u_val * v_val + 1) == 0
    else:
        assert simplify(u_val * u_val + 1) == 0
        assert simplify(v_val * v_val + 1) == 0
    print(f"  test_srp_eq_2_alone_feasible_over_Q: OK (witness u={u_val}, v={v_val}, branch={branch})")


def test_srp_empty_signature_list_feasible():
    """SRP with no signatures is vacuously feasible."""
    result = srp_solve([])
    assert result.feasible
    print("  test_srp_empty_signature_list_feasible: OK")


# ---------------------------------------------------------------------------
# v0.3-alpha tests: Pfaffian + Arf + Holant evaluator (bounded-genus layer)
# ---------------------------------------------------------------------------


def test_pfaffian_2x2():
    """Pf of a 2x2 antisymmetric matrix is its off-diagonal entry."""
    a = Symbol("a")
    M = Matrix([[0, a], [-a, 0]])
    assert pfaffian(M) == a
    print(f"  test_pfaffian_2x2: OK (Pf = {pfaffian(M)})")


def test_pfaffian_4x4_formula():
    """Pf of generic 4x4: M[0,1]*M[2,3] - M[0,2]*M[1,3] + M[0,3]*M[1,2]."""
    a, b, c, d, e, f = symbols("a b c d e f")
    M = Matrix([[0, a, b, c], [-a, 0, d, e], [-b, -d, 0, f], [-c, -e, -f, 0]])
    pf = pfaffian(M)
    expected = a * f - b * e + c * d
    assert simplify(pf - expected) == 0
    print(f"  test_pfaffian_4x4_formula: OK")


def test_pfaffian_squared_equals_det():
    """Pf(M)^2 = det(M) for antisymmetric M."""
    a, b, c, d, e, f = symbols("a b c d e f")
    M = Matrix([[0, a, b, c], [-a, 0, d, e], [-b, -d, 0, f], [-c, -e, -f, 0]])
    assert simplify(pfaffian(M) ** 2 - M.det()) == 0
    print("  test_pfaffian_squared_equals_det: OK")


def test_pfaffian_odd_dim_is_zero():
    M = Matrix([[0, 1, 2], [-1, 0, 3], [-2, -3, 0]])
    assert pfaffian(M) == 0
    print("  test_pfaffian_odd_dim_is_zero: OK")


def test_pfaffian_4_cycle_planar():
    """The 4-cycle (1-2-3-4-1) as a planar matchgrid: Pf = 2 (two perfect matchings)."""
    M = Matrix([
        [0, 1, 0, 1],
        [-1, 0, 1, 0],
        [0, -1, 0, 1],
        [-1, 0, -1, 0],
    ])
    assert pfaffian(M) == 2
    print(f"  test_pfaffian_4_cycle_planar: OK (Pf = 2 = PerfMatch(C_4))")


def test_arf_invariant_genus_0():
    assert arf_invariant(()) == 1
    print("  test_arf_invariant_genus_0: OK")


def test_arf_invariant_genus_1():
    """Three even (sign +1) and one odd (sign -1)."""
    assert arf_invariant_genus_1((0, 0)) == 1
    assert arf_invariant_genus_1((0, 1)) == 1
    assert arf_invariant_genus_1((1, 0)) == 1
    assert arf_invariant_genus_1((1, 1)) == -1
    print("  test_arf_invariant_genus_1: OK (3 even, 1 odd)")


def test_arf_invariant_genus_2_count():
    """Genus 2: 10 even and 6 odd spin structures (the +1/-1 count formula)."""
    sigs = spin_structures_genus(2)
    assert len(sigs) == 16
    plus = sum(1 for t in sigs if arf_invariant(t) == 1)
    minus = sum(1 for t in sigs if arf_invariant(t) == -1)
    # 2^{g-1}(2^g + 1) even = 2*5 = 10; 2^{g-1}(2^g - 1) odd = 2*3 = 6.
    assert plus == 10 and minus == 6
    print(f"  test_arf_invariant_genus_2_count: OK ({plus} even, {minus} odd)")


def test_spin_structures_count():
    for g in range(4):
        assert len(spin_structures_genus(g)) == max(1, 4 ** g)
    print("  test_spin_structures_count: OK")


def test_holant_planar_is_pfaffian():
    """Genus-0 Holant equals a single Pfaffian (FKT)."""
    M = Matrix([[0, 1, 0, 1], [-1, 0, 1, 0], [0, -1, 0, 1], [-1, 0, -1, 0]])
    assert holant_planar(M) == pfaffian(M)
    holant = holant_genus_g({(): M}, genus=0)
    assert holant == pfaffian(M)
    print("  test_holant_planar_is_pfaffian: OK")


def test_holant_genus_1_identical_matrices_collapses_to_pfaffian():
    """If all 4 matrices are identical, Holant = (1/2)(1+1+1-1) Pf = Pf."""
    M = Matrix([[0, 1, 0, 1], [-1, 0, 1, 0], [0, -1, 0, 1], [-1, 0, -1, 0]])
    matrices = {theta: M for theta in spin_structures_genus(1)}
    h = holant_genus_g(matrices, genus=1)
    assert h == pfaffian(M)
    print(f"  test_holant_genus_1_identical_matrices_collapses_to_pfaffian: OK (h = {h})")


def test_holant_genus_1_formula_structure():
    """Symbolic structural check: Holant = (1/2)(Pf_00 + Pf_01 + Pf_10 - Pf_11)."""
    p00, p01, p10, p11 = symbols("p00 p01 p10 p11")
    # 2x2 antisymmetric matrices with Pf = each symbol.
    M = lambda p: Matrix([[0, p], [-p, 0]])
    matrices = {(0, 0): M(p00), (0, 1): M(p01), (1, 0): M(p10), (1, 1): M(p11)}
    h = holant_genus_g(matrices, genus=1)
    expected = (p00 + p01 + p10 - p11) / 2
    assert simplify(h - expected) == 0
    print(f"  test_holant_genus_1_formula_structure: OK")


def test_holant_genus_g_rejects_wrong_keys():
    """holant_genus_g raises if matrices dict does not have the right spin structures."""
    M = Matrix([[0, 1], [-1, 0]])
    try:
        holant_genus_g({(0, 0): M, (0, 1): M}, genus=1)  # missing (1,0), (1,1)
        assert False, "expected ValueError"
    except ValueError:
        pass
    print("  test_holant_genus_g_rejects_wrong_keys: OK")


# ---------------------------------------------------------------------------
# v0.3-beta tests: non-symmetric matchgate signatures
# ---------------------------------------------------------------------------


def test_non_sym_symmetric_reduction_matches_v0_2():
    """Non-symmetric EQ_2 as (1,0,0,1) reduces to v0.2 EQ_2."""
    from holant_tools.realizability import realizability_subvariety
    nsym = NonSymmetricSignature(values={(0, 0): 1, (1, 1): 1}, arity=2, name="EQ_2-non-sym")
    assert nsym.is_symmetric()
    sv_nsym = realizability_subvariety_non_symmetric(nsym)
    sv_sym = realizability_subvariety(examples.EQUALITY_2_REC)

    # Even-parity: nsym has two equations (tau_{01}, tau_{10}) that are equal symbolically;
    # symmetric version has one (uv + 1). Verify they describe the same locus by checking
    # that both nsym even-eqs reduce to uv + 1.
    for eq in sv_nsym.even_parity_equations:
        assert simplify(eq - (U * V + 1)) == 0, f"got {eq}, expected u*v + 1"
    # Odd-parity equations: should match {u^2+1, v^2+1} (with possibly an extra at index (0,0)).
    nsym_odd = {simplify(e) for e in sv_nsym.odd_parity_equations}
    expected_odd = {U * U + 1, V * V + 1}
    assert expected_odd.issubset(nsym_odd) or nsym_odd == expected_odd
    print("  test_non_sym_symmetric_reduction_matches_v0_2: OK")


def test_non_sym_balanced_asymmetric_arity_2_feasible():
    """(0, 1, -1, 0) is feasible via odd-parity branch in our chart (x + y = 0)."""
    sig = NonSymmetricSignature(values={(0, 1): 1, (1, 0): -1}, arity=2, name="bal-asym")
    assert not sig.is_symmetric()
    sv = realizability_subvariety_non_symmetric(sig)
    res = intersect_subvarieties([sv])
    assert res.feasible, f"expected feasible, got {res}"
    print(f"  test_non_sym_balanced_asymmetric_arity_2_feasible: OK (witness u={res.witness[U]}, v={res.witness[V]})")


def test_non_sym_unbalanced_asymmetric_arity_2_chart_limitation():
    """(0, 2, 3, 0): x + y != 0; realising basis is outside our chart (documented limitation)."""
    sig = NonSymmetricSignature(values={(0, 1): 2, (1, 0): 3}, arity=2, name="unbal-asym")
    sv = realizability_subvariety_non_symmetric(sig)
    res = intersect_subvarieties([sv])
    # Per NON_SYMMETRIC.md, this case is "realisable but outside chart".
    # The prototype correctly reports infeasibility in this chart; full coverage needs chart 2.
    assert not res.feasible
    print(f"  test_non_sym_unbalanced_asymmetric_arity_2_chart_limitation: OK (chart-miss as designed)")


def test_non_sym_is_symmetric_detection():
    """is_symmetric correctly distinguishes symmetric vs non-symmetric input."""
    sym = NonSymmetricSignature(values={(0, 0): 1, (1, 1): 1}, arity=2)
    assert sym.is_symmetric()
    asym = NonSymmetricSignature(values={(0, 1): 1, (1, 0): -1}, arity=2)
    assert not asym.is_symmetric()
    print("  test_non_sym_is_symmetric_detection: OK")


def test_non_sym_arity_3_pullback_structure():
    """Valiant 6.2 case 1 (uniform x=y=z=t=1) is symmetric; arity-3 pullback is correct."""
    sig = NonSymmetricSignature(
        values={(0, 0, 1): 1, (0, 1, 0): 1, (1, 0, 0): 1, (1, 1, 1): 1},
        arity=3,
        name="V6.2-uniform",
    )
    assert sig.is_symmetric()
    tau = pullback_tau_non_symmetric(sig)
    # tau_{(1,1,1)} = (1+u)^? -- check against the v0.2 OR_3-style formula.
    # For sigma = (0,1,1,1) symmetric, tau_{(1,1,1)} comes from the v=1 corner: v^3 + 3v.
    assert simplify(tau[(1, 1, 1)] - (V ** 3 + 3 * V)) == 0
    print("  test_non_sym_arity_3_pullback_structure: OK")


# ---------------------------------------------------------------------------
# v0.3-beta-followon tests: arity-4 matchgate identity (Grassmann-Plücker)
# ---------------------------------------------------------------------------


def test_matchgate_identity_pf_4x4_self_consistency():
    """The arity-4 identity polynomial agrees with the 4x4 Pfaffian identity."""
    from sympy import symbols, Matrix
    from holant_tools.holant import pfaffian

    a, b, c, d, e, f = symbols("a b c d e f")
    M = Matrix([[0, a, b, c], [-a, 0, d, e], [-b, -d, 0, f], [-c, -e, -f, 0]])
    # tau indexed by S = "indices in the 2-element submatrix":
    # tau_{1100} = Pf({1,2}) = a, tau_{0011} = Pf({3,4}) = f, etc.
    # tau_{0000} (empty Pfaffian) = 1, tau_{1111} = Pf(full) = pfaffian(M).
    tau = {
        (0, 0, 0, 0): 1,
        (1, 1, 1, 1): pfaffian(M),
        (1, 1, 0, 0): a, (0, 0, 1, 1): f,
        (1, 0, 1, 0): b, (0, 1, 0, 1): e,
        (1, 0, 0, 1): c, (0, 1, 1, 0): d,
    }
    mg = matchgate_identity_arity_4_even(tau)
    assert simplify(mg) == 0, f"identity polynomial should vanish on the 4x4 Pfaffian; got {simplify(mg)}"
    print("  test_matchgate_identity_pf_4x4_self_consistency: OK")


def test_arity_4_symmetric_reduction_matches_v0_2():
    """Non-symmetric path on symmetric arity-4 EQ_4 agrees with v0.2 path."""
    from holant_tools.realizability import realizability_subvariety
    weights = {0: 1, 1: 0, 2: 0, 3: 0, 4: 1}
    values = {tuple((mask >> i) & 1 for i in range(4)): weights[bin(mask).count("1")] for mask in range(16)}
    nsym = NonSymmetricSignature(values=values, arity=4, name="EQ_4-non-sym")
    assert nsym.is_symmetric()
    sv_n = realizability_subvariety_non_symmetric(nsym)
    res_n = intersect_subvarieties([sv_n])

    sym = Signature(values=(1, 0, 0, 0, 1), kind="recognizer", name="EQ_4")
    sv_s = realizability_subvariety(sym)
    res_s = intersect_subvarieties([sv_s])

    assert res_n.feasible == res_s.feasible
    if res_n.feasible:
        # Both should find a witness on the even branch.
        assert res_n.branch_combination[0] == res_s.branch_combination[0]
    print(f"  test_arity_4_symmetric_reduction_matches_v0_2: OK (both feasible)")


def test_matchgate_identity_arity_4_odd_pf_self_consistency():
    """Odd-parity arity-4 identity vanishes on augmented-Pfaffian construction.

    Build a generic 5x5 skew matrix on indices {1,2,3,4,omega}. Each odd-parity
    tau_b is the Pfaffian on the complement of S(b) in {1,2,3,4,omega} (including
    omega), which has even cardinality. Verify the identity polynomial vanishes
    identically -- this is the derivation that anchors the augmented-Pfaffian
    matchgate identity.
    """
    from sympy import symbols, Matrix
    from holant_tools.holant import pfaffian

    a, b, c, p, d, e, q, f, r, s = symbols("a b c p d e q f r s")
    M = Matrix([
        [0,  a,  b,  c,  p],
        [-a, 0,  d,  e,  q],
        [-b, -d, 0,  f,  r],
        [-c, -e, -f, 0,  s],
        [-p, -q, -r, -s, 0],
    ])

    # tau_b for odd weight b: Pf on complement of S(b) in {1,2,3,4,omega} (= cols not in S(b), plus omega).
    # weight-1 entries (Pfaffian on 4 elements):
    tau = {
        (1, 0, 0, 0): pfaffian(M[[1, 2, 3, 4], [1, 2, 3, 4]]),  # complement {2,3,4,omega}
        (0, 1, 0, 0): pfaffian(M[[0, 2, 3, 4], [0, 2, 3, 4]]),  # complement {1,3,4,omega}
        (0, 0, 1, 0): pfaffian(M[[0, 1, 3, 4], [0, 1, 3, 4]]),  # complement {1,2,4,omega}
        (0, 0, 0, 1): pfaffian(M[[0, 1, 2, 4], [0, 1, 2, 4]]),  # complement {1,2,3,omega}
        # weight-3 entries (Pfaffian on 2 elements):
        (0, 1, 1, 1): pfaffian(M[[0, 4], [0, 4]]),  # complement {1,omega}
        (1, 0, 1, 1): pfaffian(M[[1, 4], [1, 4]]),  # complement {2,omega}
        (1, 1, 0, 1): pfaffian(M[[2, 4], [2, 4]]),  # complement {3,omega}
        (1, 1, 1, 0): pfaffian(M[[3, 4], [3, 4]]),  # complement {4,omega}
    }
    identity = matchgate_identity_arity_4_odd(tau)
    assert simplify(identity) == 0, f"identity should vanish; got {simplify(identity)}"
    print("  test_matchgate_identity_arity_4_odd_pf_self_consistency: OK")


def test_matchgate_identity_arity_4_odd_vacuous_on_symmetric():
    """Odd-parity identity vanishes identically when the pullback is symmetric.

    For a symmetric arity-4 signature, all 4 weight-1 entries of the pullback equal
    some tau_1(u,v) and all 4 weight-3 entries equal some tau_3(u,v). The identity

        tau_1000 * tau_0111 - tau_0100 * tau_1011 + tau_0010 * tau_1101 - tau_0001 * tau_1110

    becomes tau_1 * tau_3 - tau_1 * tau_3 + tau_1 * tau_3 - tau_1 * tau_3 = 0 — trivially
    satisfied for any tau_1, tau_3. So the odd-parity identity imposes no constraint on
    symmetric signatures. (This is why v0.2's symmetric path never needed it.)
    """
    weights = {0: 0, 1: 1, 2: 1, 3: 1, 4: 0}  # symmetric NAE_4-shape
    values = {tuple((mask >> i) & 1 for i in range(4)): weights[bin(mask).count("1")] for mask in range(16)}
    nsym = NonSymmetricSignature(values=values, arity=4)
    tau = pullback_tau_non_symmetric(nsym)
    identity_poly = simplify(matchgate_identity_arity_4_odd(tau))
    assert identity_poly == 0, f"expected identically zero on symmetric, got {identity_poly}"
    print("  test_matchgate_identity_arity_4_odd_vacuous_on_symmetric: OK (identity = 0 identically)")


def test_matchgate_identity_arity_4_odd_distinguishes_asymmetric_cases():
    """Constructive positive + negative test.

    Positive: a matchgate-realizable asymmetric arity-4 odd-parity signature,
    constructed from a 5x5 augmented skew matrix; the identity must hold by
    construction.

    Negative: perturb one entry of the positive example so the identity fails;
    confirm the identity polynomial detects the violation.
    """
    # Constructed from M with augmented row/col omega having entries (1, 2, 3, 4):
    # tau_{1000} = 0, tau_{0100} = 0, tau_{0010} = 4, tau_{0001} = 3,
    # tau_{0111} = 1, tau_{1011} = 2, tau_{1101} = 3, tau_{1110} = 4.
    tau_realizable = {
        (1, 0, 0, 0): 0, (0, 1, 0, 0): 0, (0, 0, 1, 0): 4, (0, 0, 0, 1): 3,
        (0, 1, 1, 1): 1, (1, 0, 1, 1): 2, (1, 1, 0, 1): 3, (1, 1, 1, 0): 4,
    }
    tau_realizable = {b: sympify(v) for b, v in tau_realizable.items()}
    weight_1_vals = {tau_realizable[b] for b in tau_realizable if sum(b) == 1}
    assert len(weight_1_vals) > 1, "test setup: signature must be asymmetric"
    id_val = matchgate_identity_arity_4_odd(tau_realizable)
    assert id_val == 0, f"identity should vanish on realizable; got {id_val}"

    # Perturb tau_0001 from 3 to 5: identity now reads 0*1 - 0*2 + 4*3 - 5*4 = -8.
    tau_violating = dict(tau_realizable)
    tau_violating[(0, 0, 0, 1)] = sympify(5)
    id_val_bad = matchgate_identity_arity_4_odd(tau_violating)
    assert id_val_bad != 0, f"identity should detect violation; got {id_val_bad}"
    assert id_val_bad == -8
    print(f"  test_matchgate_identity_arity_4_odd_distinguishes_asymmetric_cases: OK (realizable=0, perturbed={id_val_bad})")


def test_arity_4_v0_2_rejected_also_rejected_via_non_sym():
    """A symmetric arity-4 [1,1,1,0,1] that v0.2 rejects (no recurrence) is also rejected on the non-symmetric path."""
    sym = Signature(values=(1, 1, 1, 0, 1), kind="recognizer", name="rec-fail")
    assert find_recurrence(sym) is None, "v0.2 prerequisite: should have no recurrence"

    weights = {0: 1, 1: 1, 2: 1, 3: 0, 4: 1}
    values = {tuple((mask >> i) & 1 for i in range(4)): weights[bin(mask).count("1")] for mask in range(16)}
    nsym = NonSymmetricSignature(values=values, arity=4)
    sv = realizability_subvariety_non_symmetric(nsym)
    res = intersect_subvarieties([sv])
    assert not res.feasible
    print("  test_arity_4_v0_2_rejected_also_rejected_via_non_sym: OK")


def test_arity_4_matchgate_identity_reduces_for_symmetric_eq4():
    """For symmetric EQ_4 pullback, matchgate identity reduces to (u^2 - v^2)^2."""
    weights = {0: 1, 1: 0, 2: 0, 3: 0, 4: 1}
    values = {tuple((mask >> i) & 1 for i in range(4)): weights[bin(mask).count("1")] for mask in range(16)}
    nsym = NonSymmetricSignature(values=values, arity=4)
    tau = pullback_tau_non_symmetric(nsym)
    mg = simplify(matchgate_identity_arity_4_even(tau))
    expected = (U * U - V * V) ** 2
    assert simplify(mg - expand(expected)) == 0, f"got {mg}, expected {expand(expected)}"
    print(f"  test_arity_4_matchgate_identity_reduces_for_symmetric_eq4: OK")


# ---------------------------------------------------------------------------
# Hardness recognition tests
# ---------------------------------------------------------------------------


def test_hardness_cai_lu_5_1_not_a_candidate():
    """Cai-Lu sec 5.1 is matchgate-realisable over F_7; not a hardness candidate."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    report = hardness_candidate(sigs)
    assert not report.is_hardness_candidate
    assert report.is_matchgate_realizable_anywhere_tried
    # Should be feasible specifically over F_7.
    feasible_fields = [f for f, ok, _ in report.fields_tried if ok]
    assert "F_7" in feasible_fields
    print(f"  test_hardness_cai_lu_5_1_not_a_candidate: OK (realisable on {feasible_fields})")


def test_hardness_individual_infeasibility_short_circuits():
    """A family containing a Theorem-2.5-infeasible signature short-circuits."""
    sigs = [examples.NON_REALIZABLE_EXAMPLE]
    report = hardness_candidate(sigs)
    assert not report.is_hardness_candidate  # not a genuine hardness candidate
    assert not report.is_matchgate_realizable_anywhere_tried  # trivially
    assert len(report.individual_infeasibility) == 1
    print("  test_hardness_individual_infeasibility_short_circuits: OK")


def test_hardness_single_signature_simple_realisable():
    """EQ_2 alone is matchgate-realisable in Q-bar."""
    sigs = [examples.EQUALITY_2_REC]
    report = hardness_candidate(sigs)
    assert not report.is_hardness_candidate
    assert report.is_matchgate_realizable_anywhere_tried
    # Should be feasible over Q-bar (any uv = -1 basis works).
    q_bar_result = [ok for f, ok, _ in report.fields_tried if f == "Q-bar"]
    assert q_bar_result and q_bar_result[0]
    print("  test_hardness_single_signature_simple_realisable: OK")


def test_hardness_modulus_only_realisability():
    """A family realisable only on a specific finite field (mod-7 phenomenon)."""
    # Cai-Lu sec 5.1 is the canonical example.
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    report = hardness_candidate(sigs, primes_to_try=[2, 3, 5])
    # Without F_7 in the list, this should be reported as hardness candidate (a false positive).
    # This test documents the limitation honestly.
    assert report.is_hardness_candidate, (
        "Without F_7, this family looks like a hardness candidate -- "
        "documenting the limitation that the screen is sensitive to the prime list."
    )
    print("  test_hardness_modulus_only_realisability: OK (limitation documented)")


# ---------------------------------------------------------------------------
# Kasteleyn orientation tests (v0.1.1 -- automatic construction from rotation system)
# ---------------------------------------------------------------------------


from holant_tools.kasteleyn import kasteleyn_orient
from holant_tools.free_fermion import (
    FreeFermionCircuit,
    is_matchgate_unitary,
    majorana_rotation_z_left,
    majorana_rotation_z_right,
    majorana_rotation_xx,
    majorana_rotation_yy,
    unitary_to_majorana_rotation,
)


def test_kasteleyn_c4():
    """C_4 (= K_{2,2}) has 2 perfect matchings; auto-constructed orientation gives |Pf| = 2."""
    vertices = [1, 2, 3, 4]
    edges = [(1, 2), (2, 3), (3, 4), (4, 1)]
    rotation = {1: [2, 4], 2: [3, 1], 3: [4, 2], 4: [1, 3]}
    M = kasteleyn_orient(vertices, edges, rotation)
    assert abs(pfaffian(M)) == 2
    print(f"  test_kasteleyn_c4: OK (|Pf| = 2)")


def test_kasteleyn_k4():
    """K_4 (planar embedding with vertex 4 inside triangle 1-2-3); 3 perfect matchings."""
    vertices = [1, 2, 3, 4]
    edges = [(1, 2), (2, 3), (3, 1), (1, 4), (2, 4), (3, 4)]
    rotation = {1: [2, 4, 3], 2: [3, 4, 1], 3: [1, 4, 2], 4: [1, 2, 3]}
    M = kasteleyn_orient(vertices, edges, rotation)
    assert abs(pfaffian(M)) == 3
    print(f"  test_kasteleyn_k4: OK (|Pf| = 3)")


def test_kasteleyn_bipartite_6cycle():
    """6-cycle worker-task graph (planar bipartite) has 2 perfect matchings."""
    vertices = ['W1', 'W2', 'W3', 'T1', 'T2', 'T3']
    edges = [('W1', 'T1'), ('W1', 'T2'), ('W2', 'T2'),
             ('W2', 'T3'), ('W3', 'T1'), ('W3', 'T3')]
    rotation = {
        'W1': ['T1', 'T2'],
        'T1': ['W3', 'W1'],
        'W3': ['T3', 'T1'],
        'T3': ['W2', 'W3'],
        'W2': ['T2', 'T3'],
        'T2': ['W1', 'W2'],
    }
    M = kasteleyn_orient(vertices, edges, rotation)
    assert abs(pfaffian(M)) == 2
    print(f"  test_kasteleyn_bipartite_6cycle: OK (|Pf| = 2)")


def test_kasteleyn_skew_symmetric():
    """The returned matrix must be skew-symmetric."""
    vertices = [1, 2, 3, 4]
    edges = [(1, 2), (2, 3), (3, 4), (4, 1)]
    rotation = {1: [2, 4], 2: [3, 1], 3: [4, 2], 4: [1, 3]}
    M = kasteleyn_orient(vertices, edges, rotation)
    assert simplify(M + M.T) == 0 * M
    print("  test_kasteleyn_skew_symmetric: OK")


def test_kasteleyn_inconsistent_rotation_raises():
    """Inconsistent rotation system should raise ValueError."""
    vertices = [1, 2, 3]
    edges = [(1, 2), (2, 3), (3, 1)]
    rotation = {1: [2, 3], 2: [3, 1], 3: [2, 1]}  # this is consistent
    try:
        kasteleyn_orient(vertices, edges, rotation)
    except Exception as e:
        raise AssertionError(f"valid rotation should not raise; got {e}")
    # Now inject an inconsistency
    rotation_bad = {1: [2, 3], 2: [3, 1], 3: [5, 1]}  # 5 not a neighbor of 3
    try:
        kasteleyn_orient(vertices, edges, rotation_bad)
        raise AssertionError("expected ValueError on inconsistent rotation system")
    except ValueError:
        pass
    print("  test_kasteleyn_inconsistent_rotation_raises: OK")


# ---------------------------------------------------------------------------
# Free-fermion / matchgate quantum simulator tests (v0.1.2-alpha)
# ---------------------------------------------------------------------------


def test_vacuum_expectation_z_is_one():
    """The vacuum |00...0> has <Z_j> = 1 for every qubit."""
    for n in [1, 2, 3, 5]:
        ff = FreeFermionCircuit(n)
        for j in range(n):
            assert ff.expectation_z(j) == 1
    print("  test_vacuum_expectation_z_is_one: OK (n in {1, 2, 3, 5})")


def test_z_rotations_dont_change_z_expectation():
    """A Z-rotation on a qubit commutes with Pauli-Z; <Z> unchanged."""
    from sympy import pi
    ff = FreeFermionCircuit(2)
    ff.apply_majorana_rotation(majorana_rotation_z_left(pi / 4), (0, 1))
    assert ff.expectation_z(0) == 1
    assert ff.expectation_z(1) == 1
    ff.apply_majorana_rotation(majorana_rotation_z_right(pi / 3), (0, 1))
    assert ff.expectation_z(0) == 1
    assert ff.expectation_z(1) == 1
    print("  test_z_rotations_dont_change_z_expectation: OK")


def test_xx_yy_compose_to_identity_on_z():
    """XX(theta) followed by YY(theta) leaves <Z_0> = <Z_1> = 1 on the vacuum.

    Analytical check: XX(theta) YY(theta) is identity on the |00>-|11> subspace
    (the two rotations cancel on that subspace because XX = +sigma_x there while
    YY = -sigma_x). The vacuum |00> is in that subspace, so it returns to itself
    up to a global phase. Pauli-Z expectations are unchanged.
    """
    from sympy import pi, simplify
    ff = FreeFermionCircuit(2)
    ff.apply_majorana_rotation(majorana_rotation_xx(pi / 3), (0, 1))
    ff.apply_majorana_rotation(majorana_rotation_yy(pi / 3), (0, 1))
    assert simplify(ff.expectation_z(0) - 1) == 0
    assert simplify(ff.expectation_z(1) - 1) == 0
    print(f"  test_xx_yy_compose_to_identity_on_z: OK")


def test_xx_pi_over_2_makes_z_zero():
    """XX(pi/2) on |00> produces a maximally entangled state; marginals are mixed.

    State after XX(pi/2) |00> = (|00> - i|11>)/sqrt(2). Reduced density on each
    qubit is I/2, so <Z_0> = <Z_1> = 0.
    """
    from sympy import pi
    ff = FreeFermionCircuit(2)
    ff.apply_majorana_rotation(majorana_rotation_xx(pi / 2), (0, 1))
    assert ff.expectation_z(0) == 0
    assert ff.expectation_z(1) == 0
    print("  test_xx_pi_over_2_makes_z_zero: OK")


def test_is_matchgate_unitary_identity():
    """The 4x4 identity is a matchgate unitary (a=d=e=h=1, b=c=f=g=0; both dets = 1)."""
    from sympy import eye
    I4 = eye(4)
    assert is_matchgate_unitary(I4)
    print("  test_is_matchgate_unitary_identity: OK")


def test_is_matchgate_unitary_rejects_nonmatchgate():
    """A 4x4 unitary with non-zero entries outside the matchgate pattern is rejected."""
    from sympy import Matrix
    # CNOT in standard ordering: a permutation that does NOT have the matchgate block form.
    CNOT = Matrix([
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 0, 1],
        [0, 0, 1, 0],
    ])
    assert not is_matchgate_unitary(CNOT)
    print("  test_is_matchgate_unitary_rejects_nonmatchgate: OK")


def test_is_matchgate_unitary_rejects_unequal_determinants():
    """Block structure correct but determinants unequal => rejected."""
    from sympy import Matrix
    U = Matrix([
        [2, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, 1],
    ])
    assert not is_matchgate_unitary(U)
    print("  test_is_matchgate_unitary_rejects_unequal_determinants: OK")


def test_unitary_to_majorana_rotation_xx():
    """U_XX(pi/3) -> R via unitary_to_majorana_rotation == majorana_rotation_xx(pi/3)."""
    from sympy import I as sympy_I, cos, sin, pi, simplify, Matrix
    theta = pi / 3
    c, s = cos(theta / 2), sin(theta / 2)
    U = Matrix([
        [c, 0, 0, -sympy_I * s],
        [0, c, -sympy_I * s, 0],
        [0, -sympy_I * s, c, 0],
        [-sympy_I * s, 0, 0, c],
    ])
    R = simplify(unitary_to_majorana_rotation(U))
    assert simplify(R - majorana_rotation_xx(theta)) == Matrix.zeros(4, 4)
    print("  test_unitary_to_majorana_rotation_xx: OK")


def test_unitary_to_majorana_rotation_yy():
    """U_YY(pi/3) -> R via formula == majorana_rotation_yy(pi/3)."""
    from sympy import I as sympy_I, cos, sin, pi, simplify, Matrix
    theta = pi / 3
    c, s = cos(theta / 2), sin(theta / 2)
    U = Matrix([
        [c, 0, 0, sympy_I * s],
        [0, c, -sympy_I * s, 0],
        [0, -sympy_I * s, c, 0],
        [sympy_I * s, 0, 0, c],
    ])
    R = simplify(unitary_to_majorana_rotation(U))
    assert simplify(R - majorana_rotation_yy(theta)) == Matrix.zeros(4, 4)
    print("  test_unitary_to_majorana_rotation_yy: OK")


def test_apply_matchgate_convenience():
    """apply_matchgate(U) is equivalent to apply_majorana_rotation(R) where R = U->R(U)."""
    from sympy import I as sympy_I, cos, sin, pi, simplify
    theta = pi / 4
    c, s = cos(theta / 2), sin(theta / 2)
    U = Matrix([
        [c, 0, 0, -sympy_I * s],
        [0, c, -sympy_I * s, 0],
        [0, -sympy_I * s, c, 0],
        [-sympy_I * s, 0, 0, c],
    ])
    ff_a = FreeFermionCircuit(2)
    ff_a.apply_matchgate(U, (0, 1))
    ff_b = FreeFermionCircuit(2)
    ff_b.apply_majorana_rotation(majorana_rotation_xx(theta), (0, 1))
    diff = simplify(ff_a.covariance - ff_b.covariance)
    assert diff == Matrix.zeros(4, 4)
    print("  test_apply_matchgate_convenience: OK")


def test_expectation_z_product_two_qubits():
    """<Z_0 Z_1> on a 2-qubit XX rotation matches state-vector simulation."""
    from sympy import pi, simplify
    import numpy as np
    import scipy.linalg

    ff = FreeFermionCircuit(2)
    ff.apply_majorana_rotation(majorana_rotation_xx(pi / 5), (0, 1))
    z01 = float(simplify(ff.expectation_z_product([0, 1])).evalf())

    X = np.array([[0, 1], [1, 0]], dtype=complex)
    Z = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    theta_val = float(pi.evalf() / 5)
    U = scipy.linalg.expm(-1j * theta_val / 2 * np.kron(X, X))
    psi = U @ np.array([1, 0, 0, 0], dtype=complex)
    sv_z01 = float(np.real(np.vdot(psi, np.kron(Z, Z) @ psi)))
    assert abs(z01 - sv_z01) < 1e-10
    print(f"  test_expectation_z_product_two_qubits: OK (FF=SV={z01:.6f})")


def test_expectation_z_product_empty_returns_one():
    """The empty Pauli-Z product (identity observable) has expectation 1."""
    ff = FreeFermionCircuit(3)
    assert ff.expectation_z_product([]) == 1
    print("  test_expectation_z_product_empty_returns_one: OK")


def test_non_adjacent_majorana_rotation():
    """apply_majorana_rotation_at_indices on non-adjacent Majorana indices preserves antisymmetry."""
    from sympy import simplify, Matrix
    ff = FreeFermionCircuit(4)
    R = majorana_rotation_xx(sympify("pi/4"))  # arbitrary 4x4 orthogonal
    # Apply to non-adjacent Majoranas: indices 0, 1, 4, 5 (qubits 0 and 2).
    ff.apply_majorana_rotation_at_indices(R, [0, 1, 4, 5])
    M = ff.covariance
    # Antisymmetry preserved
    assert simplify(M + M.T) == Matrix.zeros(*M.shape)
    print("  test_non_adjacent_majorana_rotation: OK")


def test_pauli_string_z_only():
    """Pauli string with only Z's reproduces expectation_z_product."""
    from sympy import pi, simplify
    ff = FreeFermionCircuit(3)
    ff.apply_majorana_rotation(majorana_rotation_xx(pi / 5), (0, 1))
    ff.apply_majorana_rotation(majorana_rotation_yy(pi / 7), (1, 2))
    v1 = simplify(ff.expectation_pauli_string({0: 'Z', 1: 'Z', 2: 'Z'}))
    v2 = simplify(ff.expectation_z_product([0, 1, 2]))
    assert simplify(v1 - v2) == 0
    print("  test_pauli_string_z_only: OK")


def test_pauli_string_x_correlator_against_state_vector():
    """<X_0 X_2> via Pauli string matches state-vector simulation."""
    from sympy import pi, simplify
    import numpy as np
    import scipy.linalg
    ff = FreeFermionCircuit(3)
    ff.apply_majorana_rotation(majorana_rotation_xx(pi / 5), (0, 1))
    ff.apply_majorana_rotation(majorana_rotation_yy(pi / 7), (1, 2))
    ff_val = complex(simplify(ff.expectation_pauli_string({0: 'X', 2: 'X'})).evalf())
    # State-vector
    X = np.array([[0, 1], [1, 0]], dtype=complex)
    Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    theta_xx = float(pi.evalf() / 5)
    theta_yy = float(pi.evalf() / 7)
    U_xx = scipy.linalg.expm(-1j * theta_xx / 2 * np.kron(X, X))
    U_yy = scipy.linalg.expm(-1j * theta_yy / 2 * np.kron(Y, Y))
    G1 = np.kron(U_xx, I2)
    G2 = np.kron(I2, U_yy)
    psi = G2 @ G1 @ np.array([1, 0, 0, 0, 0, 0, 0, 0], dtype=complex)
    obs = np.kron(np.kron(X, I2), X)
    sv_val = complex(np.vdot(psi, obs @ psi))
    assert abs(ff_val - sv_val) < 1e-10
    print(f"  test_pauli_string_x_correlator_against_state_vector: OK (val = {ff_val.real:.6f})")


def test_pauli_string_mixed_xyz():
    """<X_0 Y_1 Z_2>: non-trivial mixed string with JW handling."""
    from sympy import pi, simplify
    import numpy as np
    import scipy.linalg
    ff = FreeFermionCircuit(3)
    ff.apply_majorana_rotation(majorana_rotation_xx(pi / 5), (0, 1))
    ff.apply_majorana_rotation(majorana_rotation_yy(pi / 7), (1, 2))
    ff_val = complex(simplify(ff.expectation_pauli_string({0: 'X', 1: 'Y', 2: 'Z'})).evalf())
    # State-vector
    X = np.array([[0, 1], [1, 0]], dtype=complex)
    Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
    Z = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    theta_xx = float(pi.evalf() / 5)
    theta_yy = float(pi.evalf() / 7)
    U_xx = scipy.linalg.expm(-1j * theta_xx / 2 * np.kron(X, X))
    U_yy = scipy.linalg.expm(-1j * theta_yy / 2 * np.kron(Y, Y))
    G1 = np.kron(U_xx, I2)
    G2 = np.kron(I2, U_yy)
    psi = G2 @ G1 @ np.array([1, 0, 0, 0, 0, 0, 0, 0], dtype=complex)
    obs = np.kron(np.kron(X, Y), Z)
    sv_val = complex(np.vdot(psi, obs @ psi))
    assert abs(ff_val - sv_val) < 1e-10
    print(f"  test_pauli_string_mixed_xyz: OK (val = {ff_val.real:.6f})")


def test_pauli_string_empty_returns_one():
    """Empty Pauli string is the identity observable, expectation 1."""
    ff = FreeFermionCircuit(3)
    assert ff.expectation_pauli_string({}) == 1
    print("  test_pauli_string_empty_returns_one: OK")


def test_expectation_majorana_product_odd_is_zero():
    """An odd-length Majorana product has zero expectation in a Gaussian state."""
    ff = FreeFermionCircuit(2)
    # Apply some rotations to get a non-trivial state.
    from sympy import pi
    ff.apply_majorana_rotation(majorana_rotation_xx(pi / 5), (0, 1))
    # Odd-length product: 3 indices
    assert ff.expectation_majorana_product([0, 1, 2]) == 0
    print("  test_expectation_majorana_product_odd_is_zero: OK")


def test_xx_against_state_vector():
    """XX(theta) on a 2-qubit vacuum: <Z> agrees with state-vector simulation."""
    import math
    import numpy as np
    import scipy.linalg
    from sympy import pi

    theta_val = float(pi.evalf() / 5)
    ff = FreeFermionCircuit(2)
    ff.apply_majorana_rotation(majorana_rotation_xx(pi / 5), (0, 1))

    X = np.array([[0, 1], [1, 0]], dtype=complex)
    Z = np.array([[1, 0], [0, -1]], dtype=complex)
    I2 = np.eye(2, dtype=complex)
    XX = np.kron(X, X)
    U = scipy.linalg.expm(-1j * theta_val / 2 * XX)
    psi = U @ np.array([1, 0, 0, 0], dtype=complex)
    sv_z0 = float(np.real(np.vdot(psi, np.kron(Z, I2) @ psi)))
    sv_z1 = float(np.real(np.vdot(psi, np.kron(I2, Z) @ psi)))

    ff_z0 = float(ff.expectation_z(0).evalf())
    ff_z1 = float(ff.expectation_z(1).evalf())
    assert abs(ff_z0 - sv_z0) < 1e-10
    assert abs(ff_z1 - sv_z1) < 1e-10
    print(f"  test_xx_against_state_vector: OK (FF agrees with SV)")


# ---------------------------------------------------------------------------
# v0.1.5 -- structural-fingerprint coordinates (matchgate rank, sum-of-Pf,
#           field-extension distance, sub-signature coverage)
# ---------------------------------------------------------------------------


def test_v015_matchgate_rank_two_root():
    """sigma_w = 2^w + 3^w: rank 1, order-2 recurrence with char poly r^2 - 5r + 6."""
    sig = Signature(values=(2, 5, 13, 35, 97))
    mr = matchgate_rank(sig)
    assert mr.rank == 1, f"expected 1, got {mr.rank}"
    assert mr.hankel_rank == 2
    assert mr.recurrence == (6, -5, 1)
    print(f"  test_v015_matchgate_rank_two_root: OK ({mr})")


def test_v015_matchgate_rank_four_root():
    """1 + 2^w + 3^w + 4^w at arity 4: matchgate rank 2 (Hankel rank 3)."""
    sig = Signature(values=(4, 10, 30, 100, 354))
    mr = matchgate_rank(sig)
    assert mr.rank == 2, f"expected 2, got {mr.rank}"
    assert mr.hankel_rank == 3
    print(f"  test_v015_matchgate_rank_four_root: OK ({mr})")


def test_v015_matchgate_rank_capacity_constraints():
    """AT_MOST_2_3 -> rank 1; AT_MOST_2_4 -> rank 2. The arity-4 jump."""
    am_2_3 = Signature(values=(1, 1, 1, 0), name="AT_MOST_2_3")
    am_2_4 = Signature(values=(1, 1, 1, 0, 0), name="AT_MOST_2_4")
    r_2_3 = matchgate_rank(am_2_3).rank
    r_2_4 = matchgate_rank(am_2_4).rank
    assert r_2_3 == 1 and r_2_4 == 2
    print(f"  test_v015_matchgate_rank_capacity_constraints: OK "
          f"(AT_MOST_2_3 rank 1, AT_MOST_2_4 rank 2)")


def test_v015_sum_of_pfaffians_linearity():
    """alpha*Pf(M1) + beta*Pf(M2) == holant_sum_of_pfaffians([(alpha, M1), (beta, M2)])."""
    a, b, c, d = sympify("a"), sympify("b"), sympify("c"), sympify("d")
    M1 = Matrix([[0, a, 0, 0], [-a, 0, b, 0], [0, -b, 0, 1], [0, 0, -1, 0]])
    M2 = Matrix([[0, c, d, 0], [-c, 0, 0, 1], [-d, 0, 0, 1], [0, -1, -1, 0]])
    direct = 2 * pfaffian(M1) + 3 * pfaffian(M2)
    via = holant_sum_of_pfaffians([(2, M1), (3, M2)])
    from sympy import simplify
    assert simplify(direct - via) == 0
    print(f"  test_v015_sum_of_pfaffians_linearity: OK")


def test_v015_sum_of_pfaffians_empty():
    """Empty term list evaluates to 0."""
    assert holant_sum_of_pfaffians([]) == 0
    print(f"  test_v015_sum_of_pfaffians_empty: OK")


def test_v015_sum_of_genus_g_zero_reduces_to_planar():
    """At genus 0, sum-of-genus-g equals sum-of-pfaffians on the single-key dicts."""
    a, b = sympify("a"), sympify("b")
    M1 = Matrix([[0, a, 0, 0], [-a, 0, 1, 0], [0, -1, 0, b], [0, 0, -b, 0]])
    M2 = Matrix([[0, 1, a, 0], [-1, 0, 0, b], [-a, 0, 0, 1], [0, -b, -1, 0]])
    terms_g0 = [(2, {(): M1}), (3, {(): M2})]
    via_genus_g = holant_sum_of_genus_g(terms_g0, genus=0)
    via_pfaff = holant_sum_of_pfaffians([(2, M1), (3, M2)])
    from sympy import simplify
    assert simplify(via_genus_g - via_pfaff) == 0
    print(f"  test_v015_sum_of_genus_g_zero_reduces_to_planar: OK")


def test_v015_field_extension_distance_mod_7():
    """Cai-Lu sec 5.1: distance = 7 with witness (u, v) = (2, 3) over F_7."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = field_extension_distance(sigs)
    assert result.distance == 7
    assert result.min_feasible_field == "F_7"
    assert result.status == "feasible_in_F_p"
    print(f"  test_v015_field_extension_distance_mod_7: OK ({result})")


def test_v015_field_extension_distance_feasible_in_q_bar():
    """A simple matchgate-realisable single-signature problem has distance 0."""
    result = field_extension_distance([examples.EQUALITY_2_REC])
    assert result.distance == 0
    assert result.min_feasible_field == "Q-bar"
    print(f"  test_v015_field_extension_distance_feasible_in_q_bar: OK")


def test_v015_field_extension_distance_skips_higher_primes():
    """The function stops at the first feasible prime."""
    sigs = [examples.EQUALITY_2_REC, examples.OR_k_GEN(3)]
    result = field_extension_distance(sigs, primes_to_try=[2, 3, 5, 7, 11, 13])
    assert result.primes_tried == [2, 3, 5, 7]
    print(f"  test_v015_field_extension_distance_skips_higher_primes: OK")


def test_v015_signature_coverage_fully_realisable():
    """EQ_2 has coverage 1.0."""
    result = signature_coverage(examples.EQUALITY_2_REC)
    assert result.coverage == 1.0
    print(f"  test_v015_signature_coverage_fully_realisable: OK")


def test_v015_signature_coverage_non_realisable_example():
    """NON_REALIZABLE_EXAMPLE has coverage 23/28 = 0.821."""
    result = signature_coverage(examples.NON_REALIZABLE_EXAMPLE)
    expected = 23 / 28
    assert abs(result.coverage - expected) < 1e-9
    print(f"  test_v015_signature_coverage_non_realisable_example: OK "
          f"coverage={result.coverage:.4f}")


def test_v015_enumerate_restrictions_count():
    """Arity-n sig has (n+1)(n+2)/2 restriction patterns."""
    sig = Signature(values=(1, 2, 3, 4))
    restrictions = enumerate_restrictions(sig)
    assert len(restrictions) == 10  # (3+1)(3+2)/2 = 10
    print(f"  test_v015_enumerate_restrictions_count: OK")


# ---------------------------------------------------------------------------
# v0.1.6 -- scheduling adapter (instance -> Holant -> 4 coordinates)
# ---------------------------------------------------------------------------


def test_v016_scheduling_instance_basic_compilation():
    """SchedulingInstance compiles to expected number of variables and signatures."""
    from holant_tools.scheduling import Job, Machine, SchedulingInstance, compile_to_holant
    jobs = [Job(f"J{i+1}") for i in range(3)]
    machines = [Machine("M1", capacity=1), Machine("M2", capacity=2)]
    inst = SchedulingInstance(jobs=jobs, machines=machines, name="test")
    compiled = compile_to_holant(inst)
    # 3 jobs * 2 machines = 6 variables; 3 per-job + 2 per-machine = 5 signature uses
    assert compiled.num_variables == 6
    assert len(compiled.signatures) == 5
    # Distinct signatures: EXACT_1_2 (the per-job arity-2 EXACT_1), AT_MOST_1_3, AT_MOST_2_3.
    distinct_names = [s.name for s in compiled.distinct_signatures]
    assert "EXACT_1_2" in distinct_names
    print(f"  test_v016_scheduling_instance_basic_compilation: OK "
          f"(V={compiled.num_variables}, sigs={len(compiled.signatures)})")


def test_v016_instance_coordinates_max_rank_jump():
    """At N>=4 with capacity-2 machine, max_rank should be 2."""
    from holant_tools.scheduling import Job, Machine, SchedulingInstance, instance_coordinates
    jobs = [Job(f"J{i+1}") for i in range(5)]
    machines = [Machine("M1", capacity=1), Machine("M2", capacity=2)]
    inst = SchedulingInstance(jobs=jobs, machines=machines, name="5j-cap2")
    coords = instance_coordinates(inst)
    assert coords.max_rank == 2, f"expected 2, got {coords.max_rank}"
    print(f"  test_v016_instance_coordinates_max_rank_jump: OK "
          f"(max_rank={coords.max_rank}, prod_rank<={coords.product_rank_bound})")


def test_v016_instance_coordinates_product_rank_bound():
    """Product-rank bound = 2^(number of cap>=2 machines on >=4 jobs)."""
    from holant_tools.scheduling import Job, Machine, SchedulingInstance, instance_coordinates
    jobs = [Job(f"J{i+1}") for i in range(5)]
    machines = [
        Machine("M1", capacity=1),  # rank 1
        Machine("M2", capacity=2),  # rank 2 on 5 jobs
        Machine("M3", capacity=2),  # rank 2 on 5 jobs
    ]
    inst = SchedulingInstance(jobs=jobs, machines=machines, name="2-cap2")
    coords = instance_coordinates(inst)
    # 5 per-job EXACT_1 (rank 1) + 1 cap-1 (rank 1) + 2 cap-2 (rank 2) = 2^2 = 4
    assert coords.product_rank_bound == 4, f"expected 4, got {coords.product_rank_bound}"
    print(f"  test_v016_instance_coordinates_product_rank_bound: OK "
          f"(prod_rank={coords.product_rank_bound})")


def test_v016_scaling_scan_keeps_max_rank_constant():
    """The structural-bound hypothesis: max_rank stays constant as N grows."""
    from holant_tools.scheduling import Job, Machine, SchedulingInstance, instance_coordinates
    ranks_observed = []
    for n_jobs in range(4, 8):  # arity >= 4 to keep AT_MOST_2 in rank-2 regime
        jobs = [Job(f"J{i+1}") for i in range(n_jobs)]
        machines = [
            Machine("M1", capacity=1),
            Machine("M2", capacity=2),
        ]
        inst = SchedulingInstance(jobs=jobs, machines=machines)
        coords = instance_coordinates(inst)
        ranks_observed.append(coords.max_rank)
    # max_rank should be 2 throughout (one cap-2 machine on >=4 jobs)
    assert all(r == 2 for r in ranks_observed), f"max_rank not constant: {ranks_observed}"
    print(f"  test_v016_scaling_scan_keeps_max_rank_constant: OK "
          f"(max_rank constant at 2 across N=4..7)")


# ---------------------------------------------------------------------------
# v0.1.7 -- SWF parser (Standard Workload Format -> SchedulingInstance)
# ---------------------------------------------------------------------------


_SWF_TEXT = """\
; SWFVersion: 2.2
; UnixStartTime: 1700000000
; MaxNodes: 64
; MaxProcs: 64
; MaxJobs: 5
; MaxRuntime: 3600
; MaxPartitions: 2
       1     0    10    180    4    -1    256    4   600   -1  1  100   10   1   1   1   -1   -1
       2    30    20    240    2    -1    128    2   600   -1  1  101   10   1   1   1   -1   -1
       3    60     0    420    8    -1    512    8   900   -1  1  102   11   2   1   1   -1   -1
       4   100    50    120    1    -1     64    1   300   -1  1  100   10   1   1   2   -1   -1
       5   150    30    300    4    -1    256    4   600   -1  1  103   12   1   1   2    3   30
"""


def test_v017_swf_parse_string():
    """parse_swf_string handles header + 5 jobs correctly."""
    from holant_tools.swf import parse_swf_string
    wl = parse_swf_string(_SWF_TEXT, source="test")
    assert wl.num_jobs == 5
    assert wl.header.max_procs == 64
    assert wl.header.max_jobs == 5
    assert wl.header.unix_start_time == 1700000000
    # job 5 has a precedence on job 3
    assert wl.jobs[4].preceding_job_number == 3
    assert wl.jobs[4].has_dependency
    print(f"  test_v017_swf_parse_string: OK (5 jobs, max_procs=64)")


def test_v017_swf_jobs_active_at():
    """jobs_active_at returns jobs submitted by t but not completed."""
    from holant_tools.swf import parse_swf_string
    wl = parse_swf_string(_SWF_TEXT)
    # At t=100: job 1 has completed (submit+wait+run = 0+10+180 = 190 -- wait, 190 > 100, so it's still running).
    # job 1: submit 0, wait 10, run 180 -> completes at 190. Still active at 100.
    # job 2: submit 30, completes at 30+20+240 = 290. Active at 100.
    # job 3: submit 60, completes at 60+0+420 = 480. Active at 100.
    # job 4: submit 100, active at 100.
    # job 5: submit 150, NOT yet submitted at 100.
    active = wl.jobs_active_at(100)
    assert len(active) == 4, f"expected 4 active jobs at t=100, got {len(active)}: {[j.job_number for j in active]}"
    print(f"  test_v017_swf_jobs_active_at: OK ({len(active)} jobs at t=100)")


def test_v017_instance_from_window():
    """instance_from_window builds a SchedulingInstance with the right job set."""
    from holant_tools.swf import parse_swf_string, instance_from_window
    wl = parse_swf_string(_SWF_TEXT)
    inst = instance_from_window(wl, t_start=0, t_end=100, machine_partitions=2)
    # submit times 0, 30, 60 fall in [0, 100); 100 is exclusive. So jobs 1, 2, 3 only.
    assert len(inst.jobs) == 3
    assert {j.name for j in inst.jobs} == {"J1", "J2", "J3"}
    # 2 machines from 64 max_procs -> capacity 32 each.
    assert len(inst.machines) == 2
    assert all(m.capacity == 32 for m in inst.machines)
    print(f"  test_v017_instance_from_window: OK (3 jobs, 2 machines of cap 32)")


def test_v017_instance_from_window_precedence():
    """Precedence dependencies within the job set are recorded."""
    from holant_tools.swf import parse_swf_string, instance_from_window
    wl = parse_swf_string(_SWF_TEXT)
    # window including both job 3 and job 5 (which depends on job 3)
    inst = instance_from_window(wl, t_start=0, t_end=200, machine_partitions=1)
    assert ("J3", "J5") in inst.precedence, f"expected precedence J3->J5 in {inst.precedence}"
    print(f"  test_v017_instance_from_window_precedence: OK ({inst.precedence})")


def test_v017_instance_from_snapshot_uses_active_jobs():
    """instance_from_snapshot uses jobs_active_at."""
    from holant_tools.swf import parse_swf_string, instance_from_snapshot
    wl = parse_swf_string(_SWF_TEXT)
    inst = instance_from_snapshot(wl, t=200, machine_partitions=2)
    # At t=200: job 1 completed (190), jobs 2,3,4,5 active.
    assert len(inst.jobs) == 4
    print(f"  test_v017_instance_from_snapshot_uses_active_jobs: OK ({len(inst.jobs)} jobs)")


def test_v017_instance_partitioning_handles_uneven_split():
    """Machine partitioning distributes capacity evenly with remainder to low-index."""
    from holant_tools.swf import parse_swf_string, instance_from_window
    wl = parse_swf_string(_SWF_TEXT)
    inst = instance_from_window(wl, t_start=0, t_end=10000, machine_partitions=3)
    caps = [m.capacity for m in inst.machines]
    # 64 / 3 = 21 remainder 1 -> [22, 21, 21]
    assert caps == [22, 21, 21], f"expected [22, 21, 21], got {caps}"
    print(f"  test_v017_instance_partitioning_handles_uneven_split: OK (caps={caps})")


def test_v018_instance_coordinates_skip_field_distance():
    """compute_field_distance=False skips the slow field-ext computation."""
    from holant_tools.scheduling import Job, Machine, SchedulingInstance, instance_coordinates
    jobs = [Job(f"J{i+1}") for i in range(5)]
    machines = [Machine("M1", capacity=1), Machine("M2", capacity=2)]
    inst = SchedulingInstance(jobs=jobs, machines=machines, name="fast-path")
    coords = instance_coordinates(inst, compute_field_distance=False)
    assert coords.field_extension_distance is None
    assert coords.field_extension_status == "skipped"
    # Other coordinates still computed:
    assert coords.max_rank == 2
    assert coords.product_rank_bound == 2
    assert coords.configuration_coverage.mean_coverage > 0.9
    print(f"  test_v018_instance_coordinates_skip_field_distance: OK")


def test_v019_time_slot_encoding_rank_1():
    """Time-slot encoding: every signature is matchgate rank 1."""
    from holant_tools.scheduling import (
        Job, Machine, SchedulingInstance, compile_to_holant_time_slot
    )
    from holant_tools import matchgate_rank
    jobs = [Job(f"J{i+1}") for i in range(5)]
    machines = [Machine("M1", 1), Machine("M2", 2), Machine("M3", 8)]  # mixed capacities
    inst = SchedulingInstance(jobs=jobs, machines=machines, name="time-slot-test")
    compiled = compile_to_holant_time_slot(inst)
    # Variables = jobs * total slots = 5 * (1 + 2 + 8) = 55
    assert compiled.num_variables == 55
    # All distinct signatures must be rank 1
    for sig in compiled.distinct_signatures:
        mr = matchgate_rank(sig)
        assert mr.rank == 1, f"{sig.name} should be rank 1, got {mr.rank}"
    print(f"  test_v019_time_slot_encoding_rank_1: OK "
          f"(all {len(compiled.distinct_signatures)} signatures rank 1)")


def test_v019_time_slot_collapses_product_rank():
    """Time-slot encoding gives product_rank=1 regardless of capacity."""
    from holant_tools.scheduling import (
        Job, Machine, SchedulingInstance, instance_coordinates
    )
    # 10 jobs, 4 machines of capacity 8 -- high-cap case
    jobs = [Job(f"J{i+1}") for i in range(10)]
    machines = [Machine(f"M{m+1}", 8) for m in range(4)]
    inst = SchedulingInstance(jobs=jobs, machines=machines)
    # Bipartite-capacity: AT_MOST_8_10 has rank ~5; product over 4 machines
    bip = instance_coordinates(inst, compute_field_distance=False, encoding="bipartite-capacity")
    # Time-slot: all rank 1
    ts = instance_coordinates(inst, compute_field_distance=False, encoding="time-slot")
    assert bip.product_rank_bound > 1, f"bipartite should have prod_rank > 1, got {bip.product_rank_bound}"
    assert ts.product_rank_bound == 1, f"time-slot must have prod_rank=1, got {ts.product_rank_bound}"
    assert ts.max_rank == 1
    print(f"  test_v019_time_slot_collapses_product_rank: OK "
          f"(bipartite prod_rank={bip.product_rank_bound} -> time-slot prod_rank=1)")


def test_v019_encoding_validation():
    """instance_coordinates rejects unknown encoding."""
    from holant_tools.scheduling import (
        Job, Machine, SchedulingInstance, instance_coordinates
    )
    jobs = [Job("J1")]
    machines = [Machine("M1")]
    inst = SchedulingInstance(jobs=jobs, machines=machines)
    try:
        instance_coordinates(inst, encoding="bogus")
        assert False, "expected ValueError on unknown encoding"
    except ValueError as e:
        assert "bogus" in str(e) or "encoding" in str(e).lower()
    print(f"  test_v019_encoding_validation: OK")


def test_v018_swf_gz_path_detection():
    """parse_swf detects .gz paths and uses gzip; non-gz uses plain open."""
    # We can't easily test the gzip path without a real .gz file in CI,
    # but we can at least verify the gzip module is imported correctly
    # by checking that the function exists with the right signature.
    import inspect
    from holant_tools.swf import parse_swf
    src = inspect.getsource(parse_swf)
    assert ".gz" in src and "gzip" in src
    print(f"  test_v018_swf_gz_path_detection: OK (gzip path present)")


def test_v017_swf_rejects_short_lines():
    """A job line with fewer than 18 fields raises a clear error."""
    from holant_tools.swf import parse_swf_string
    bad = "; header line\n  1 0 0 0\n"
    try:
        parse_swf_string(bad)
        assert False, "expected ValueError on short line"
    except ValueError as e:
        assert "18" in str(e)
    print(f"  test_v017_swf_rejects_short_lines: OK")


def test_v016_scheduling_instance_rejects_duplicate_names():
    """SchedulingInstance enforces unique job names and unique machine names."""
    from holant_tools.scheduling import Job, Machine, SchedulingInstance
    try:
        SchedulingInstance(jobs=[Job("J1"), Job("J1")], machines=[Machine("M1")])
        assert False, "expected ValueError on duplicate job names"
    except ValueError:
        pass
    try:
        SchedulingInstance(jobs=[Job("J1")], machines=[Machine("M1"), Machine("M1")])
        assert False, "expected ValueError on duplicate machine names"
    except ValueError:
        pass
    print(f"  test_v016_scheduling_instance_rejects_duplicate_names: OK")


def test_v015_demo_runs_and_signals_match():
    """Smoke test that the example 07 demo's core claims hold."""
    from sympy import Symbol, solve
    # The Part-2 decomposition: 1 + 2^w + 3^w + 4^w at arity 7 -> rank 2, four roots {1,2,3,4}
    vals = tuple(sum(k**w for k in range(1, 5)) for w in range(8))
    sig = Signature(values=vals)
    mr = matchgate_rank(sig)
    assert mr.rank == 2
    assert mr.hankel_rank == 4
    r = Symbol("r")
    char = sum(mr.recurrence[i] * r**i for i in range(len(mr.recurrence)))
    roots = solve(char, r)
    assert set(roots) == {1, 2, 3, 4}
    print(f"  test_v015_demo_runs_and_signals_match: OK")


def run_all():
    print("admissibility v0.1 + v0.2 + v0.3-alpha + v0.3-beta + v0.3-beta-followon + hardness + kasteleyn + free-fermion smoke tests:")
    print(" v0.1:")
    test_eq_2_realizable()
    test_or_3_realizable()
    test_nae_3_realizable()
    test_non_realizable_caught()
    test_zero_signature_trivially_realizable()
    test_srp_necessary_check_cai_lu_5_1()
    test_srp_necessary_check_with_non_realizable()
    print(" v0.2 -- Form classification:")
    test_form_eq_2_is_form_1()
    test_form_or_3_is_form_3()
    test_form_nae_3_is_form_1_complex()
    test_form_pure_geometric_is_form_2()
    test_form_doubly_degenerate()
    test_form_non_realizable_is_none()
    print(" v0.2 -- subvariety construction:")
    test_subvariety_eq_2_equations()
    test_subvariety_or_3_tau_3_is_v_cubed_form()
    test_subvariety_zero_signature_trivial()
    print(" v0.2 -- intersection + SRP solver:")
    test_srp_cai_lu_5_1_feasible_mod_7()
    test_srp_cai_lu_5_1_infeasible_over_Q()
    test_srp_cai_lu_5_1_infeasible_mod_5()
    test_srp_short_circuits_on_individual_infeasibility()
    test_srp_eq_2_alone_feasible_over_Q()
    test_srp_empty_signature_list_feasible()
    print(" v0.3-alpha -- Pfaffian + Arf:")
    test_pfaffian_2x2()
    test_pfaffian_4x4_formula()
    test_pfaffian_squared_equals_det()
    test_pfaffian_odd_dim_is_zero()
    test_pfaffian_4_cycle_planar()
    test_arf_invariant_genus_0()
    test_arf_invariant_genus_1()
    test_arf_invariant_genus_2_count()
    test_spin_structures_count()
    print(" v0.3-alpha -- Holant evaluator:")
    test_holant_planar_is_pfaffian()
    test_holant_genus_1_identical_matrices_collapses_to_pfaffian()
    test_holant_genus_1_formula_structure()
    test_holant_genus_g_rejects_wrong_keys()
    print(" v0.3-beta -- non-symmetric signatures:")
    test_non_sym_is_symmetric_detection()
    test_non_sym_symmetric_reduction_matches_v0_2()
    test_non_sym_balanced_asymmetric_arity_2_feasible()
    test_non_sym_unbalanced_asymmetric_arity_2_chart_limitation()
    test_non_sym_arity_3_pullback_structure()
    print(" v0.3-beta-followon -- arity-4 Grassmann-Plücker matchgate identity:")
    test_matchgate_identity_pf_4x4_self_consistency()
    test_matchgate_identity_arity_4_odd_pf_self_consistency()
    test_matchgate_identity_arity_4_odd_vacuous_on_symmetric()
    test_matchgate_identity_arity_4_odd_distinguishes_asymmetric_cases()
    test_arity_4_matchgate_identity_reduces_for_symmetric_eq4()
    test_arity_4_symmetric_reduction_matches_v0_2()
    test_arity_4_v0_2_rejected_also_rejected_via_non_sym()
    print(" hardness recognition:")
    test_hardness_cai_lu_5_1_not_a_candidate()
    test_hardness_individual_infeasibility_short_circuits()
    test_hardness_single_signature_simple_realisable()
    test_hardness_modulus_only_realisability()
    print(" Kasteleyn orientation (auto-construction):")
    test_kasteleyn_c4()
    test_kasteleyn_k4()
    test_kasteleyn_bipartite_6cycle()
    test_kasteleyn_skew_symmetric()
    test_kasteleyn_inconsistent_rotation_raises()
    print(" Free-fermion / matchgate quantum simulation (v0.1.2-alpha):")
    test_vacuum_expectation_z_is_one()
    test_z_rotations_dont_change_z_expectation()
    test_xx_yy_compose_to_identity_on_z()
    test_xx_pi_over_2_makes_z_zero()
    test_is_matchgate_unitary_identity()
    test_is_matchgate_unitary_rejects_nonmatchgate()
    test_is_matchgate_unitary_rejects_unequal_determinants()
    test_xx_against_state_vector()
    print(" Free-fermion v0.1.3 (U->R + Wick's theorem):")
    test_unitary_to_majorana_rotation_xx()
    test_unitary_to_majorana_rotation_yy()
    test_apply_matchgate_convenience()
    test_expectation_z_product_two_qubits()
    test_expectation_z_product_empty_returns_one()
    test_non_adjacent_majorana_rotation()
    test_pauli_string_z_only()
    test_pauli_string_x_correlator_against_state_vector()
    test_pauli_string_mixed_xyz()
    test_pauli_string_empty_returns_one()
    test_expectation_majorana_product_odd_is_zero()
    print(" v0.1.5 -- structural-fingerprint coordinates:")
    test_v015_matchgate_rank_two_root()
    test_v015_matchgate_rank_four_root()
    test_v015_matchgate_rank_capacity_constraints()
    test_v015_sum_of_pfaffians_linearity()
    test_v015_sum_of_pfaffians_empty()
    test_v015_sum_of_genus_g_zero_reduces_to_planar()
    test_v015_field_extension_distance_mod_7()
    test_v015_field_extension_distance_feasible_in_q_bar()
    test_v015_field_extension_distance_skips_higher_primes()
    test_v015_signature_coverage_fully_realisable()
    test_v015_signature_coverage_non_realisable_example()
    test_v015_enumerate_restrictions_count()
    test_v015_demo_runs_and_signals_match()
    print(" v0.1.6 -- scheduling adapter:")
    test_v016_scheduling_instance_basic_compilation()
    test_v016_instance_coordinates_max_rank_jump()
    test_v016_instance_coordinates_product_rank_bound()
    test_v016_scaling_scan_keeps_max_rank_constant()
    test_v016_scheduling_instance_rejects_duplicate_names()
    print(" v0.1.7 -- SWF parser:")
    test_v017_swf_parse_string()
    test_v017_swf_jobs_active_at()
    test_v017_instance_from_window()
    test_v017_instance_from_window_precedence()
    test_v017_instance_from_snapshot_uses_active_jobs()
    test_v017_instance_partitioning_handles_uneven_split()
    test_v017_swf_rejects_short_lines()
    print(" v0.1.8 -- empirical-scan tooling:")
    test_v018_instance_coordinates_skip_field_distance()
    test_v018_swf_gz_path_detection()
    print(" v0.1.9 -- time-slot encoding:")
    test_v019_time_slot_encoding_rank_1()
    test_v019_time_slot_collapses_product_rank()
    test_v019_encoding_validation()
    print("All tests pass (v0.1 + v0.2 + v0.3-alpha + v0.3-beta + v0.3-beta-followon + hardness + kasteleyn + free-fermion + v0.1.3 + v0.1.4 + v0.1.5 + v0.1.6 + v0.1.7 + v0.1.8 + v0.1.9).")


if __name__ == "__main__":
    run_all()
