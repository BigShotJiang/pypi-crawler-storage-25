"""Polymarket venue tests — contract + error paths.

Mocks the CLOB client, Gamma client, and web3 to test all 14 poly commands
without requiring py_clob_client to be installed.
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Mock data
# ---------------------------------------------------------------------------

# CLOB's get_balance_allowance returns `balance` as raw 6-decimal base units
# (stringified int). 500 pUSD = 500 × 10^6 = "500000000". Mock must match so
# the orient.py normalization produces the expected "500.000000" display.
MOCK_BALANCE = {"balance": "500000000", "allowances": {"USDC": "1000000"}}

MOCK_ORDERS = [
    {
        "id": "0xa0afb499737a22fc936add1de64b2e2066fe0ffd9dbc014bb15727aab9e7a30c",
        "market": "0xmarket1",
        "asset_id": "token-yes-001",
        "side": "BUY",
        "price": "0.55",
        "original_size": "100",
        "size_matched": "50",
        "status": "LIVE",
        "created_at": "2026-03-30T10:00:00Z",
    },
]

MOCK_POSITIONS = [
    {
        "asset_id": "token-yes-001",
        "market": "0xmarket1",
        "side": "BUY",
        "size": "100",
        "avg_price": "0.55",
        "cur_price": "0.60",
        "pnl": "5.00",
    },
]

MOCK_REDEEMABLE_POSITIONS = [
    {
        "asset_id": "token-yes-r1",
        "market": "Resolved Market A",
        "side": "BUY",
        "size": "50",
        "avg_price": "0.40",
        "cur_price": "1.00",
        "pnl": "30.00",
        "condition_id": "0xcondition_resolved_1",
        "outcome": "Yes",
        "redeemable": True,
        "mergeable": False,
    },
]

MOCK_MERGEABLE_POSITIONS = [
    {
        "asset_id": "token-yes-m1",
        "market": "Merge Market B",
        "side": "BUY",
        "size": "30",
        "avg_price": "0.55",
        "cur_price": "0.60",
        "pnl": "1.50",
        "condition_id": "0xcondition_merge_1",
        "outcome": "Yes",
        "redeemable": False,
        "mergeable": True,
    },
    {
        "asset_id": "token-no-m1",
        "market": "Merge Market B",
        "side": "BUY",
        "size": "20",
        "avg_price": "0.45",
        "cur_price": "0.40",
        "pnl": "-1.00",
        "condition_id": "0xcondition_merge_1",
        "outcome": "No",
        "redeemable": False,
        "mergeable": True,
    },
]

MOCK_TRADES = [
    {
        "id": "trade-001",
        "market": "0xmarket1",
        "asset_id": "token-yes-001",
        "side": "BUY",
        "price": "0.55",
        "size": "100",
        "fee_rate_bps": "200",
        "status": "CONFIRMED",
        "match_time": "1711789200",
        "outcome": "Yes",
    },
]

MOCK_GAMMA_MARKET = {
    "id": "12345",
    "conditionId": "0xcondition",
    "question": "Will BTC hit $100k by 2027?",
    "slug": "btc-100k-2027",
    "clobTokenIds": '["token-yes-001", "token-no-001"]',
    "outcomePrices": '["0.55", "0.45"]',
    "active": True,
    "closed": False,
    "acceptingOrders": "true",
    "negRisk": "false",
    "volume24hr": "50000",
    "volumeNum": "1000000",
    "liquidityNum": "200000",
    "endDateIso": "2027-01-01T00:00:00Z",
    "bestBid": "0.54",
    "bestAsk": "0.56",
    "orderMinSize": "5",
    "orderPriceMinTickSize": "0.01",
}

MOCK_GAMMA_MARKETS = [MOCK_GAMMA_MARKET]

MOCK_ORDER_BOOK = {
    "bids": [{"price": "0.54", "size": "200"}, {"price": "0.53", "size": "150"}],
    "asks": [{"price": "0.56", "size": "180"}, {"price": "0.57", "size": "120"}],
}

MOCK_EVENT = {
    "id": "event-001",
    "title": "US Presidential Election 2028",
    "slug": "us-presidential-election-2028",
    "markets": [
        {
            "id": "m1",
            "question": "Will Democrat win?",
            "clobTokenIds": ["t1", "t2"],
            "outcomePrices": ["0.45", "0.55"],
            "volume24hr": "10000",
            "active": True,
            "acceptingOrders": True,
        },
    ],
}

MOCK_WALLET = {"pusd": "5.00", "usdc_e": "0.00", "usdc": "0.00", "pol": "2.94", "rpc_ok": True}
MOCK_COLLATERAL = {"name": "pUSD", "address": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB", "source": "on-chain"}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_clob():
    clob = MagicMock()
    clob.get_balance_allowance.return_value = MOCK_BALANCE
    clob.get_open_orders.return_value = list(MOCK_ORDERS)
    # get_positions moved to Data API (client.get_positions), not on clob
    clob.get_trades.return_value = list(MOCK_TRADES)
    clob.get_order_book.return_value = MOCK_ORDER_BOOK
    clob.cancel_order.return_value = {"status": "ok"}
    clob.cancel_all.return_value = {"status": "ok"}
    clob.get_fee_rate_bps.return_value = 1000
    return clob


@pytest.fixture
def mock_gamma():
    gamma = MagicMock()

    def _mock_get(path, params=None):
        resp = MagicMock()
        resp.status_code = 200
        if "/markets" in path:
            resp.json.return_value = list(MOCK_GAMMA_MARKETS)
        elif "/events" in path:
            resp.json.return_value = [MOCK_EVENT]
        else:
            resp.json.return_value = {}
        resp.raise_for_status = MagicMock()
        return resp

    gamma.get.side_effect = _mock_get
    return gamma


@pytest.fixture
def mock_ctf_redeem():
    return MagicMock(return_value={"token_id": "token-yes-r1", "action": "redeem", "size": 50.0, "tx": "0xredeem_hash"})


@pytest.fixture
def mock_ctf_merge():
    return MagicMock(return_value={"token_id": "token-yes-m1", "action": "merge", "size": 20.0, "tx": "0xmerge_hash"})


MOCK_GEO = {"blocked": False, "ip": "203.0.113.1", "country": "IE", "region": "L", "close_only": False}


@pytest.fixture
def poly_patched(mock_clob, mock_gamma, mock_ctf_redeem, mock_ctf_merge):
    patches = [
        patch("regard.venues.polymarket.commands.orient.get_clob_client", return_value=mock_clob),
        patch("regard.venues.polymarket.commands.orient.get_positions", return_value=list(MOCK_POSITIONS)),
        patch("regard.venues.polymarket.commands.orient._get_balance", return_value=dict(MOCK_BALANCE)),
        patch("regard.venues.polymarket.commands.orient.get_wallet_balances", return_value=dict(MOCK_WALLET)),
        patch("regard.venues.polymarket.commands.orient.get_collateral_token", return_value=dict(MOCK_COLLATERAL)),
        patch("regard.venues.polymarket.commands.research.get_clob_client", return_value=mock_clob),
        patch("regard.venues.polymarket.commands.research.get_gamma_client", return_value=mock_gamma),
        patch("regard.venues.polymarket.commands.research.get_geo_status", return_value=dict(MOCK_GEO)),
        patch("regard.venues.polymarket.commands.review.get_clob_client", return_value=mock_clob),
        patch("regard.venues.polymarket.commands.act.get_clob_client", return_value=mock_clob),
        patch("regard.venues.polymarket.commands.act.get_gamma_client", return_value=mock_gamma),
        patch("regard.venues.polymarket.commands.act.get_web3", return_value=MagicMock()),
        patch("regard.venues.polymarket.commands.act.check_geo_block"),
        patch("regard.venues.polymarket.commands.act.get_positions", return_value=[]),
        patch("regard.venues.polymarket.client.lookup_neg_risk", return_value={}),
        patch("regard.venues.polymarket.commands.act.ctf_redeem", mock_ctf_redeem),
        patch("regard.venues.polymarket.commands.act.ctf_merge", mock_ctf_merge),
        # Mock collateral resolver — real implementation needs valid bytes32 condition_id
        # and uint256 token_id, which the mock positions don't provide.
        patch("regard.venues.polymarket.client.resolve_binary_collateral",
              return_value="0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB"),
    ]
    for p in patches:
        p.start()
    yield {"clob": mock_clob, "gamma": mock_gamma, "ctf_redeem": mock_ctf_redeem, "ctf_merge": mock_ctf_merge}
    for p in patches:
        p.stop()


def parse(result) -> dict:
    stdout = result.stdout.strip()
    assert "Traceback" not in stdout, f"Traceback leaked: {stdout[:300]}"
    return json.loads(stdout)


# ---------------------------------------------------------------------------
# Orient commands
# ---------------------------------------------------------------------------

class TestPolyStatus:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "status"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["collateral_token"] == "pUSD"
        assert d["data"]["open_order_count"] == 1

    def test_clob_failure_produces_json(self, poly_patched):
        poly_patched["clob"].get_open_orders.side_effect = Exception("CLOB down")
        result = runner.invoke(app, ["polymarket", "status"])
        d = parse(result)
        # Should still succeed — orders gracefully degrade to []
        assert d["ok"] is True
        assert d["data"]["open_order_count"] == 0

    def test_clob_unreachable_returns_wallet(self, poly_patched):
        # Simulate fresh wallet: get_clob_client raises (e.g. derive_api_key fails)
        with patch(
            "regard.venues.polymarket.commands.orient.get_clob_client",
            side_effect=Exception("Could not derive api key!"),
        ):
            result = runner.invoke(app, ["polymarket", "status"])
        d = parse(result)
        assert d["ok"] is True
        # On-chain wallet info still present
        assert d["data"]["wallet"]["usdc_e"] is not None
        # CLOB sections fail-open
        assert d["data"]["open_order_count"] == 0
        assert "clob_error" in d["data"]
        assert "Could not derive api key" in d["data"]["clob_error"]


class TestPolyBalance:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "balance"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["clob_balance"] == "500.000000"


class TestPolyClobBalanceNormalization:
    """Regression: CLOB returns raw 6-decimal base units; CLI must normalize.

    Bug surfaced in v0.19.7: a wallet with 9.99 pUSD showed `clob_balance =
    "9990000"` instead of "9.990000" in both `poly status` and `port`. Fixed
    in v0.19.8 by normalizing raw → human units at display/aggregation time.

    `poly_patched` fixture patches `_get_balance` directly with MOCK_BALANCE,
    so we can't override via `.get_balance_allowance.return_value` — re-patch
    `_get_balance` per test with the raw value we want to exercise.
    """

    def test_small_raw_balance_normalizes(self, poly_patched):
        """9.99 pUSD raw (9990000) → "9.990000" in poly status."""
        with patch(
            "regard.venues.polymarket.commands.orient._get_balance",
            return_value={"balance": "9990000", "allowances": {}},
        ):
            result = runner.invoke(app, ["polymarket", "status"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["clob_balance"] == "9.990000"

    def test_zero_balance_remains_zero(self, poly_patched):
        """Zero raw stays zero; no spurious formatting."""
        with patch(
            "regard.venues.polymarket.commands.orient._get_balance",
            return_value={"balance": "0", "allowances": {}},
        ):
            result = runner.invoke(app, ["polymarket", "status"])
        d = parse(result)
        assert d["data"]["clob_balance"] == "0.000000"

    def test_malformed_balance_falls_back(self, poly_patched):
        """Non-numeric balance (unexpected from real API) → safe default."""
        with patch(
            "regard.venues.polymarket.commands.orient._get_balance",
            return_value={"balance": "not-a-number", "allowances": {}},
        ):
            result = runner.invoke(app, ["polymarket", "status"])
        d = parse(result)
        # Fallback "0.00" — explicitly distinct from the "0.000000" normalize
        # path so we know the safety catch fired, not a silent zero.
        assert d["data"]["clob_balance"] == "0.00"

    def test_clob_unreachable_returns_wallet(self, poly_patched):
        # Simulate fresh wallet: get_clob_client raises (e.g. derive_api_key fails)
        with patch(
            "regard.venues.polymarket.commands.orient.get_clob_client",
            side_effect=Exception("Could not derive api key!"),
        ):
            result = runner.invoke(app, ["polymarket", "balance"])
        d = parse(result)
        assert d["ok"] is True
        # On-chain wallet info still present
        assert d["data"]["wallet"]["usdc_e"] is not None
        # CLOB fields fail-open: balance is None, allowances empty
        assert d["data"]["clob_balance"] is None
        assert d["data"]["allowances"] == {}
        assert "clob_error" in d["data"]
        assert "Could not derive api key" in d["data"]["clob_error"]


class TestPolyPositions:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "positions"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1
        assert d["data"][0]["pnl"] == "5.00"

    def test_empty(self, poly_patched):
        with patch("regard.venues.polymarket.commands.orient.get_positions", return_value=[]):
            result = runner.invoke(app, ["polymarket", "positions"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"] == []


class TestPolyOrders:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "orders"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["open_order_count"] == 1
        assert d["data"]["orders"][0]["order_id"] == "0xa0afb499737a22fc936add1de64b2e2066fe0ffd9dbc014bb15727aab9e7a30c"

    def test_clob_unreachable_returns_empty(self, poly_patched):
        # Fresh wallet: get_clob_client raises. Orders fail-opens to empty + clob_error.
        with patch(
            "regard.venues.polymarket.commands.orient.get_clob_client",
            side_effect=Exception("Could not derive api key!"),
        ):
            result = runner.invoke(app, ["polymarket", "orders"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["open_order_count"] == 0
        assert d["data"]["orders"] == []
        assert "clob_error" in d["data"]
        assert "Could not derive api key" in d["data"]["clob_error"]


# ---------------------------------------------------------------------------
# Research commands
# ---------------------------------------------------------------------------

class TestPolyMarkets:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "markets"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) >= 1
        assert "question" in d["data"][0]


class TestPolyMarket:
    def test_by_slug(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "market", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "question" in d["data"]

    def test_not_found(self, poly_patched):
        poly_patched["gamma"].get.side_effect = lambda *a, **kw: MagicMock(
            json=MagicMock(return_value=[]), status_code=200
        )
        result = runner.invoke(app, ["polymarket", "market", "nonexistent-market"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "UNKNOWN_MARKET"


class TestPolyEvent:
    def test_by_slug(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "event", "us-presidential-election-2028"])
        d = parse(result)
        assert d["ok"] is True
        assert "markets" in d["data"]
        assert d["data"]["market_count"] >= 1


class TestPolyPrices:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "prices", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "yes_price" in d["data"]


class TestPolyBook:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "book", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "bids" in d["data"]
        assert "asks" in d["data"]


# ---------------------------------------------------------------------------
# Review commands
# ---------------------------------------------------------------------------

class TestPolyTrades:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "trades"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1
        t = d["data"][0]
        assert t["trade_id"] == "trade-001"
        assert t["side"] == "BUY"
        assert t["price"] == "0.55"
        assert t["size"] == "100"
        assert t["fee"] == "1.1"  # 0.55 * 100 * 200/10000
        assert t["fee_rate_bps"] == "200"
        assert t["outcome"] == "Yes"
        assert t["status"] == "CONFIRMED"
        assert t["created_at"] == "2024-03-30T09:00:00Z"  # epoch 1711789200


# ---------------------------------------------------------------------------
# Act commands
# ---------------------------------------------------------------------------

class TestPolyOrder:
    """Poly order now creates proposals."""

    def test_limit_order_creates_proposal(self, poly_patched):
        """Limit buy on yes outcome creates a proposal with resolved params."""
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["venue"] == "polymarket"
        assert d["data"]["command"] == "order"
        assert d["data"]["params"]["outcome"] == "yes"
        assert d["data"]["params"]["side"] == "BUY"
        assert d["data"]["params"]["size"] == "100.0"
        assert d["data"]["params"]["price"] == "0.55"
        assert d["data"]["params"]["market_order"] is False
        assert d["data"]["params"]["token_id"] == "token-yes-001"
        assert d["data"]["params"]["market_slug"] == "btc-100k-2027"
        # mark_price is the market's current yes price (0.55), not the user's limit price
        assert d["data"]["checks"]["mark_price"] == "0.55"
        # CLOB should NOT be called (propose only)
        poly_patched["clob"].create_order.assert_not_called()
        poly_patched["clob"].post_order.assert_not_called()

    def test_market_order_creates_proposal(self, poly_patched):
        """Market buy creates proposal with market_order=True."""
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "no", "buy", "50", "--market"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["params"]["outcome"] == "no"
        assert d["data"]["params"]["market_order"] is True

    def test_invalid_outcome(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "maybe", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_OUTCOME"

    def test_invalid_side(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "hold", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_SIDE"

    def test_missing_price_no_market(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "MISSING_PRICE"

    def test_price_out_of_range(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "1.5"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_PRICE"


class TestPolyMinOrderSize:
    """Minimum order size validation (per-market, from Gamma API)."""

    def test_below_min_rejected(self, poly_patched):
        """Order below market's orderMinSize → BELOW_MIN_SIZE."""
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "1", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "BELOW_MIN_SIZE"
        assert "5" in d["error"]["message"]

    def test_at_min_accepted(self, poly_patched):
        """Order at exactly min size → proposal created."""
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "5", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"


class TestPolyMinNotional:
    """Marketable-order $1 minimum notional check — catches the venue's
    rejection at propose time so agents don't waste a proposal slot on
    an order the CLOB will reject at submit time.

    Regression guard: Order Lifecycle Cycle E run 2026-04-17 proposed
    `poly order 561234 yes buy 5 0.12` (5 × 0.12 = $0.60), which the
    venue rejected with "invalid amount for a marketable BUY order
    ($0.6), min size: $1". Pre-flight check would have caught it upfront.
    """

    def _low_price_market(self):
        """Mock a market with cheap prices so small sizes can hit the $1 floor."""
        return {
            **MOCK_GAMMA_MARKET,
            "outcomePrices": '["0.10", "0.90"]',
            "bestBid": "0.09",
            "bestAsk": "0.10",
        }

    def _patch_market(self, poly_patched, market):
        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if path == "/markets":
                resp.json.return_value = [market]
            else:
                resp.json.return_value = {}
            resp.raise_for_status = MagicMock()
            return resp
        poly_patched["gamma"].get.side_effect = _mock_get

    def test_marketable_buy_below_min_notional_rejected(self, poly_patched):
        """BUY at price >= best_ask with size × price < $1 must be rejected."""
        self._patch_market(poly_patched, self._low_price_market())
        # 5 shares × 0.10 = $0.50, below $1. Price 0.10 crosses best_ask 0.10.
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "5", "0.10"])
        d = parse(result)
        assert d["ok"] is False, f"expected rejection, got: {d}"
        assert d["error"]["code"] == "BELOW_MIN_NOTIONAL"
        assert "$0.50" in d["error"]["message"]

    def test_marketable_buy_above_min_notional_passes(self, poly_patched):
        """BUY at price crossing best_ask with size × price >= $1 proposes cleanly."""
        self._patch_market(poly_patched, self._low_price_market())
        # 10 shares × 0.10 = $1.00, at boundary.
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "10", "0.10"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"

    def test_resting_buy_below_min_notional_allowed(self, poly_patched):
        """Non-marketable (resting) limit with notional < $1 is exempt from the check."""
        self._patch_market(poly_patched, self._low_price_market())
        # 5 shares × 0.05 = $0.25, below $1 — BUT price 0.05 is below best_ask 0.10
        # so the order rests rather than matches, Polymarket's $1 floor doesn't apply.
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "5", "0.05"])
        d = parse(result)
        assert d["ok"] is True, f"resting limit below ask should propose cleanly: {d}"
        assert d["data"]["status"] == "pending"

    def test_marketable_sell_below_min_notional_rejected(self, poly_patched):
        """SELL at price <= best_bid with size × price < $1 must be rejected (mirror of BUY case)."""
        self._patch_market(poly_patched, self._low_price_market())
        # 5 shares × 0.09 = $0.45, below $1. Price 0.09 at best_bid (crossing SELL).
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "sell", "5", "0.09"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "BELOW_MIN_NOTIONAL"


class TestPolyPrecision:
    """Numeric precision validation — Article II compliance."""

    def test_fractional_shares_rejected(self, poly_patched):
        """Size must be a whole number of shares."""
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "10.5", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "PRECISION_EXCEEDED"
        assert "whole number" in d["error"]["message"]

    def test_price_not_on_tick_rejected(self, poly_patched):
        """Price must be a multiple of tick_size (0.01 in mock)."""
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.555"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "PRECISION_EXCEEDED"
        assert "tick size" in d["error"]["message"]

    def test_valid_precision_passes(self, poly_patched):
        """Correct precision passes through to proposal."""
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"


class TestPolyApprove:
    """Poly approve (on-chain token approvals) creates proposal."""

    def test_creates_proposal(self, poly_patched):
        """poly approve creates a proposal, does not call web3 or sign txs."""
        result = runner.invoke(app, ["polymarket", "approve"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["command"] == "approve"
        assert d["data"]["venue"] == "polymarket"
        # Exchange/web3 should NOT be called at propose time
        poly_patched["clob"].post_order.assert_not_called()


class TestPolyCancel:
    """Poly cancel/cancel-all now create proposals."""

    def test_cancel(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "cancel", "0xa0afb499737a22fc936add1de64b2e2066fe0ffd9dbc014bb15727aab9e7a30c"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["command"] == "cancel"
        assert d["data"]["params"]["order_id"] == "0xa0afb499737a22fc936add1de64b2e2066fe0ffd9dbc014bb15727aab9e7a30c"
        # CLOB should NOT be called
        poly_patched["clob"].cancel_order.assert_not_called()

    def test_cancel_all(self, poly_patched):
        result = runner.invoke(app, ["polymarket", "cancel-all"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["command"] == "cancel-all"
        poly_patched["clob"].cancel_all.assert_not_called()


# ---------------------------------------------------------------------------
# Executor integration: approve → execute → CLOB called correctly
# ---------------------------------------------------------------------------


class TestPolyOrderExecutor:
    """Approve a poly order proposal → real executor fires → CLOB called."""

    def _approve_with_price_bypass(self, proposal_id, mark_price="0.55"):
        """Run approve with _fetch_current_price returning the same mark_price (delta=0)."""
        with patch("regard.main._fetch_current_price", return_value=mark_price):
            return runner.invoke(app, ["approve", proposal_id])

    def test_limit_order_executor(self, poly_patched):
        """Limit order: executor calls create_order + post_order(GTC)."""
        clob = poly_patched["clob"]
        clob.post_order.return_value = {"orderID": "oid-limit-1"}
        clob.create_order.return_value = {"signed": True}
        clob.get_balance_allowance.return_value = {"balance": "10000.00"}

        # 1. Propose
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        proposal_id = d["data"]["id"]

        # 2. Approve → executor fires
        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["order_id"] == "oid-limit-1"
        assert d["data"]["type"] == "GTC"
        assert d["data"]["side"] == "BUY"
        assert d["data"]["outcome"] == "yes"

        # 3. Verify CLOB was called
        clob.create_order.assert_called_once()
        args = clob.create_order.call_args[0][0]
        assert args.token_id == "token-yes-001"
        assert args.price == 0.55
        assert args.size == 100.0
        assert args.side == "BUY"
        # V2 orders: fees calculated match-time by exchange, not set on signed order
        assert not hasattr(args, "fee_rate_bps") or getattr(args, "fee_rate_bps", None) in (None, 0)
        clob.post_order.assert_called_once()

    def test_market_order_executor(self, poly_patched):
        """Market order: executor calls create_market_order + post_order(FOK)."""
        clob = poly_patched["clob"]
        clob.post_order.return_value = {"orderID": "oid-market-1"}
        clob.create_market_order.return_value = {"signed": True}
        clob.get_balance_allowance.return_value = {"balance": "10000.00"}

        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "--market"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["type"] == "FOK"
        assert d["data"]["order_id"] == "oid-market-1"

        clob.create_market_order.assert_called_once()
        args = clob.create_market_order.call_args[0][0]
        assert args.token_id == "token-yes-001"
        assert args.amount == 100.0
        assert args.side == "BUY"
        # V2 orders: fees calculated match-time by exchange, not set on signed order
        assert not hasattr(args, "fee_rate_bps") or getattr(args, "fee_rate_bps", None) in (None, 0)
        clob.create_order.assert_not_called()

    def test_insufficient_balance_rejects(self, poly_patched):
        """BUY order with insufficient balance → INSUFFICIENT_BALANCE before CLOB call."""
        clob = poly_patched["clob"]
        clob.get_balance_allowance.return_value = {"balance": "10.00"}

        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INSUFFICIENT_BALANCE"
        clob.get_balance_allowance.assert_called()  # verify balance path was reached
        clob.create_order.assert_not_called()
        clob.post_order.assert_not_called()

    def test_precision_rejected_at_approve_time(self, poly_patched):
        """Tampered proposal with fractional shares → rejected at executor."""
        # Create a valid proposal, then tamper with the params
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        # Read, tamper size to fractional, write back
        import json as _json
        import os

        from regard.core.proposal import get_workspace_dir
        ws = get_workspace_dir()
        pending_dir = os.path.join(ws, "pending")
        pf = os.path.join(pending_dir, f"{proposal_id}.json")
        with open(pf) as f:
            prop = _json.load(f)
        prop["params"]["size"] = 10.5
        with open(pf, "w") as f:
            _json.dump(prop, f)

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "PRECISION_EXCEEDED"

    def test_success_false_not_enough_balance_classified(self, poly_patched):
        """CLOB returns success:false with documented code → classified as INSUFFICIENT_BALANCE."""
        clob = poly_patched["clob"]
        clob.post_order.return_value = {
            "success": False,
            "errorMsg": "INVALID_ORDER_NOT_ENOUGH_BALANCE",
        }
        clob.create_order.return_value = {"signed": True}
        clob.get_balance_allowance.return_value = {"balance": "10000.00"}

        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INSUFFICIENT_BALANCE"

    def test_success_false_min_tick_classified(self, poly_patched):
        clob = poly_patched["clob"]
        clob.post_order.return_value = {
            "success": False,
            "errorMsg": "INVALID_ORDER_MIN_TICK_SIZE",
        }
        clob.create_order.return_value = {"signed": True}
        clob.get_balance_allowance.return_value = {"balance": "10000.00"}

        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "TICK_SIZE_VIOLATION"

    def test_success_false_unknown_errormsg_falls_back(self, poly_patched):
        """Unclassified errorMsg → ORDER_REJECTED, raw message preserved."""
        clob = poly_patched["clob"]
        clob.post_order.return_value = {
            "success": False,
            "errorMsg": "some-novel-error-string",
        }
        clob.create_order.return_value = {"signed": True}
        clob.get_balance_allowance.return_value = {"balance": "10000.00"}

        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "ORDER_REJECTED"
        assert "some-novel-error-string" in d["error"]["message"]


# ---------------------------------------------------------------------------
# Fee handling — propose, affordability, formula
# ---------------------------------------------------------------------------

# Sports/crypto markets carry a feeSchedule on Polymarket Gamma. Empirical
# rates 2026-04-27: sports 3% taker, crypto 7.2% taker, both with exponent=1.
_FEE_SPORTS = {"exponent": 1, "rate": 0.03, "takerOnly": True, "rebateRate": 0.25}
_FEE_CRYPTO = {"exponent": 1, "rate": 0.072, "takerOnly": True, "rebateRate": 0.2}

MOCK_GAMMA_MARKET_FEE_BEARING = {
    **MOCK_GAMMA_MARKET,
    "feesEnabled": True,
    "feeType": "crypto_fees_v2",
    "feeSchedule": _FEE_CRYPTO,
}


class TestComputeFee:
    """Pure-function tests for the Polymarket taker fee formula."""

    def test_no_schedule_returns_zero(self):
        from regard.venues.polymarket.market import compute_fee
        assert compute_fee(100.0, 0.5, None) == 0.0
        assert compute_fee(100.0, 0.5, {}) == 0.0

    def test_formula_matches_polymarket_spec(self):
        """fee = notional * rate * price^exp * (1-price)^exp"""
        from regard.venues.polymarket.market import compute_fee
        # 7.2% rate, exp=1, price=0.5: 100 * 0.072 * 0.5 * 0.5 = 1.8
        assert compute_fee(100.0, 0.5, _FEE_CRYPTO) == pytest.approx(1.8)
        # 3% rate, exp=1, price=0.4: 50 * 0.03 * 0.4 * 0.6 = 0.36
        assert compute_fee(50.0, 0.4, _FEE_SPORTS) == pytest.approx(0.36)

    def test_boundary_prices_return_zero(self):
        """Formula degenerates at p=0 or p=1; return 0 instead of 0 via product."""
        from regard.venues.polymarket.market import compute_fee
        assert compute_fee(100.0, 0.0, _FEE_CRYPTO) == 0.0
        assert compute_fee(100.0, 1.0, _FEE_CRYPTO) == 0.0

    def test_malformed_schedule_returns_zero(self):
        from regard.venues.polymarket.market import compute_fee
        assert compute_fee(100.0, 0.5, {"rate": "not-a-number"}) == 0.0


class TestPolyOrderFees:
    """Propose-time fee preview surfaces expected_fees + net_cost in checks."""

    def _patch_market(self, poly_patched, market):
        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if "/markets" in path:
                resp.json.return_value = [market]
            else:
                resp.json.return_value = {}
            resp.raise_for_status = MagicMock()
            return resp
        poly_patched["gamma"].get.side_effect = _mock_get

    def test_fee_exempt_market_has_no_fee_keys(self, poly_patched):
        """Default mock market is fee-exempt — checks must omit fee keys."""
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        checks = d["data"]["checks"]
        assert "fees_enabled" not in checks
        assert "expected_fees" not in checks
        assert "net_cost" not in checks

    def test_fee_bearing_buy_surfaces_expected_fees(self, poly_patched):
        """Crypto market 7.2% taker, BUY 100 @ 0.55: notional=55, fee = 55*0.072*0.55*0.45."""
        self._patch_market(poly_patched, MOCK_GAMMA_MARKET_FEE_BEARING)
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        checks = d["data"]["checks"]
        assert checks["fees_enabled"] == "true"
        assert checks["fee_type"] == "crypto_fees_v2"
        # 100 * 0.55 * 0.072 * 0.55 * 0.45 = 0.9801
        assert float(checks["expected_fees"]) == pytest.approx(0.9801, rel=1e-3)
        # net_cost = 55 + 0.9801 = 55.9801
        assert float(checks["net_cost"]) == pytest.approx(55.9801, rel=1e-3)

    def test_fee_bearing_sell_omits_net_cost(self, poly_patched):
        """SELL doesn't show net_cost (proceeds, not cost) but still shows expected_fees."""
        self._patch_market(poly_patched, MOCK_GAMMA_MARKET_FEE_BEARING)
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "sell", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        checks = d["data"]["checks"]
        assert "expected_fees" in checks
        assert "net_cost" not in checks

    def test_fee_schedule_persisted_to_proposal_params(self, poly_patched):
        """Executor needs fee_schedule from params for affordability — must be stored."""
        self._patch_market(poly_patched, MOCK_GAMMA_MARKET_FEE_BEARING)
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["data"]["params"]["fee_schedule"] == _FEE_CRYPTO

    def test_market_buy_uses_size_as_dollar_notional(self, poly_patched):
        """Market BUY: MarketOrderArgs.amount is dollars, so size = notional directly.

        Without this branch, a regression that treats `size * price` as notional
        for market BUYs would double-count the price factor and silently misreport
        fees.
        """
        self._patch_market(poly_patched, MOCK_GAMMA_MARKET_FEE_BEARING)
        # market BUY 50 dollars → fee_notional=50, mark price 0.55 (yes_price)
        # expected = 50 * 0.072 * 0.55 * 0.45 = 0.891
        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "50", "--market"])
        d = parse(result)
        assert d["ok"] is True
        checks = d["data"]["checks"]
        assert float(checks["expected_fees"]) == pytest.approx(0.891, rel=1e-3)
        assert float(checks["net_cost"]) == pytest.approx(50.891, rel=1e-3)


class TestPolyOrderExecutorFees:
    """Approve path: affordability check reserves expected fees from balance."""

    def _approve(self, proposal_id, mark_price="0.55"):
        with patch("regard.main._fetch_current_price", return_value=mark_price):
            return runner.invoke(app, ["approve", proposal_id])

    def _patch_market(self, poly_patched, market):
        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if "/markets" in path:
                resp.json.return_value = [market]
            else:
                resp.json.return_value = {}
            resp.raise_for_status = MagicMock()
            return resp
        poly_patched["gamma"].get.side_effect = _mock_get

    def test_balance_just_above_cost_but_below_with_fees_rejects(self, poly_patched):
        """Tight balance: 55.50 covers naive 55 cost but not 55 + 0.98 fees."""
        self._patch_market(poly_patched, MOCK_GAMMA_MARKET_FEE_BEARING)
        clob = poly_patched["clob"]
        clob.get_balance_allowance.return_value = {"balance": "55.50"}

        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve(proposal_id)
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INSUFFICIENT_BALANCE"
        assert "fees" in d["error"]["message"].lower()
        clob.create_order.assert_not_called()

    def test_balance_above_cost_with_fees_passes(self, poly_patched):
        """Comfortable balance covers cost + fees → executor proceeds."""
        self._patch_market(poly_patched, MOCK_GAMMA_MARKET_FEE_BEARING)
        clob = poly_patched["clob"]
        clob.get_balance_allowance.return_value = {"balance": "10000.00"}
        clob.create_order.return_value = {"signed": True}
        clob.post_order.return_value = {"orderID": "oid-fee-1"}

        result = runner.invoke(app, ["polymarket", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve(proposal_id)
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["order_id"] == "oid-fee-1"
        clob.create_order.assert_called_once()


class TestPolyClassifier:
    """Pure-function tests for _classify_poly_clob_error."""

    def test_balance_error_maps_to_insufficient_balance(self):
        from regard.venues.polymarket.commands.act import _classify_poly_clob_error
        code, hint = _classify_poly_clob_error("INVALID_ORDER_NOT_ENOUGH_BALANCE")
        assert code == "INSUFFICIENT_BALANCE"
        assert hint is not None

    def test_fok_unfilled(self):
        from regard.venues.polymarket.commands.act import _classify_poly_clob_error
        code, _ = _classify_poly_clob_error("FOK_ORDER_NOT_FILLED_ERROR")
        assert code == "FOK_UNFILLED"

    def test_market_not_ready(self):
        from regard.venues.polymarket.commands.act import _classify_poly_clob_error
        code, _ = _classify_poly_clob_error("MARKET_NOT_READY")
        assert code == "MARKET_NOT_READY"

    def test_geo_blocked_phrasing(self):
        from regard.venues.polymarket.commands.act import _classify_poly_clob_error
        for msg in [
            "Polymarket is not available in your region",
            "geo-restricted",
            "geoblocked",
            "403",
            "403 Forbidden",
        ]:
            code, hint = _classify_poly_clob_error(msg)
            assert code == "GEO_BLOCKED", f"should classify '{msg}' as GEO_BLOCKED"
            assert hint is not None

    def test_geo_no_false_positive_on_id(self):
        """Order IDs containing '403' shouldn't trigger GEO_BLOCKED."""
        from regard.venues.polymarket.commands.act import _classify_poly_clob_error
        code, _ = _classify_poly_clob_error("Order 0x403abc not found")
        assert code != "GEO_BLOCKED"

    def test_geo_no_false_positive_on_restricted_prose(self):
        """Non-geo 'restricted' prose shouldn't route to GEO_BLOCKED."""
        from regard.venues.polymarket.commands.act import _classify_poly_clob_error
        code, _ = _classify_poly_clob_error("operation restricted to admin users")
        assert code != "GEO_BLOCKED"

    def test_expiration_only_on_documented_code(self):
        """'invalid_order_expiration' is the documented code; bare 'expiration'
        can appear in unrelated JWT/auth errors and must NOT false-match."""
        from regard.venues.polymarket.commands.act import _classify_poly_clob_error
        assert _classify_poly_clob_error("INVALID_ORDER_EXPIRATION")[0] == "ORDER_EXPIRED"
        assert _classify_poly_clob_error("invalid token expiration in JWT header")[0] != "ORDER_EXPIRED"

    def test_unknown_falls_back(self):
        from regard.venues.polymarket.commands.act import _classify_poly_clob_error
        code, hint = _classify_poly_clob_error("some gibberish error")
        assert code == "ORDER_REJECTED"
        assert hint is None


class TestExtractOrderIds:
    """_extract_order_ids handles both flat-string and dict-wrapped entries."""

    def test_flat_strings(self):
        from regard.venues.polymarket.commands.act import _extract_order_ids
        assert _extract_order_ids(["0xaaa", "0xbbb"]) == ["0xaaa", "0xbbb"]

    def test_dict_wrapped_order_id(self):
        from regard.venues.polymarket.commands.act import _extract_order_ids
        assert _extract_order_ids([{"order_id": "0xaaa"}, {"orderID": "0xbbb"}]) == ["0xaaa", "0xbbb"]

    def test_mixed(self):
        from regard.venues.polymarket.commands.act import _extract_order_ids
        assert _extract_order_ids(["0xaaa", {"id": "0xbbb"}, {"orderId": "0xccc"}]) == ["0xaaa", "0xbbb", "0xccc"]

    def test_unknown_dict_shape_skipped(self):
        from regard.venues.polymarket.commands.act import _extract_order_ids
        # Dict without any recognized ID key — skip rather than crash
        assert _extract_order_ids([{"random": "0xaaa"}]) == []


class TestPolyCancelExecutor:
    """Approve a poly cancel proposal → executor calls clob.cancel_order.

    CLOB's cancel response shape is `{canceled: [ids...], not_canceled: {id: reason}}`.
    """

    _OID = "0xa0afb499737a22fc936add1de64b2e2066fe0ffd9dbc014bb15727aab9e7a30c"

    def test_cancel_executor(self, poly_patched):
        clob = poly_patched["clob"]
        clob.cancel_order.return_value = {"canceled": [self._OID], "not_canceled": {}}

        result = runner.invoke(app, ["polymarket", "cancel", self._OID])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["order_id"] == self._OID
        assert d["data"]["canceled"] is True

        from py_clob_client_v2.clob_types import OrderPayload
        clob.cancel_order.assert_called_once_with(OrderPayload(orderID=self._OID))

    def test_cancel_not_in_canceled_dies(self, poly_patched):
        """Order lands in not_canceled{} → CANCEL_FAILED with reason preserved."""
        clob = poly_patched["clob"]
        clob.cancel_order.return_value = {
            "canceled": [],
            "not_canceled": {self._OID: "order already filled"},
        }

        result = runner.invoke(app, ["polymarket", "cancel", self._OID])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "CANCEL_FAILED"
        assert "already filled" in d["error"]["message"]

    def test_cancel_sdk_raises(self, poly_patched):
        """SDK exception → classifier falls back to CANCEL_FAILED."""
        clob = poly_patched["clob"]
        clob.cancel_order.side_effect = Exception("service unavailable")

        result = runner.invoke(app, ["polymarket", "cancel", self._OID])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "CANCEL_FAILED"

    def test_cancel_accepts_dict_wrapped_canceled_entry(self, poly_patched):
        """Defensive: if SDK ever wraps IDs in `{order_id: ...}` envelopes,
        extract uniformly rather than treating a successful cancel as failed."""
        clob = poly_patched["clob"]
        clob.cancel_order.return_value = {
            "canceled": [{"order_id": self._OID}],
            "not_canceled": {},
        }

        result = runner.invoke(app, ["polymarket", "cancel", self._OID])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["canceled"] is True


class TestPolyCancelAllExecutor:
    """Approve a poly cancel-all proposal → executor calls clob.cancel_all.

    CLOB's cancel-all response has the same shape as single cancel:
    `{canceled: [...], not_canceled: {id: reason}}`.
    """

    def test_cancel_all_executor(self, poly_patched):
        clob = poly_patched["clob"]
        clob.cancel_all.return_value = {
            "canceled": ["0xaaa", "0xbbb", "0xccc"],
            "not_canceled": {},
        }

        result = runner.invoke(app, ["polymarket", "cancel-all"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["count"] == 3
        assert d["data"]["canceled"] == ["0xaaa", "0xbbb", "0xccc"]
        assert d["data"].get("partial") is not True

        clob.cancel_all.assert_called_once()

    def test_cancel_all_partial_surfaces_not_canceled(self, poly_patched):
        """Partial success surfaces not_canceled{} to the agent, doesn't die."""
        clob = poly_patched["clob"]
        clob.cancel_all.return_value = {
            "canceled": ["0xaaa"],
            "not_canceled": {"0xbbb": "order already filled"},
        }

        result = runner.invoke(app, ["polymarket", "cancel-all"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["count"] == 1
        assert d["data"]["partial"] is True
        assert d["data"]["not_canceled"] == {"0xbbb": "order already filled"}

    def test_cancel_all_nothing_canceled_dies(self, poly_patched):
        """No orders canceled AND not_canceled has entries → CANCEL_FAILED."""
        clob = poly_patched["clob"]
        clob.cancel_all.return_value = {
            "canceled": [],
            "not_canceled": {"0xaaa": "order already filled", "0xbbb": "not found"},
        }

        result = runner.invoke(app, ["polymarket", "cancel-all"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "CANCEL_FAILED"

    def test_cancel_all_sdk_raises(self, poly_patched):
        clob = poly_patched["clob"]
        clob.cancel_all.side_effect = Exception("service unavailable")

        result = runner.invoke(app, ["polymarket", "cancel-all"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "CANCEL_FAILED"

    def test_cancel_all_empty_both_marked_no_orders(self, poly_patched):
        """`{canceled:[], not_canceled:{}}` is ambiguous between 'nothing to cancel'
        and 'all 0 orders canceled' — mark result so the agent can tell."""
        clob = poly_patched["clob"]
        clob.cancel_all.return_value = {"canceled": [], "not_canceled": {}}

        result = runner.invoke(app, ["polymarket", "cancel-all"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["count"] == 0
        assert d["data"]["no_orders"] is True

    def test_cancel_all_accepts_dict_entries(self, poly_patched):
        """Defensive: CLOB SDK drift could wrap IDs in objects. Extract uniformly."""
        clob = poly_patched["clob"]
        clob.cancel_all.return_value = {
            "canceled": [{"order_id": "0xaaa"}, {"orderID": "0xbbb"}],
            "not_canceled": {},
        }

        result = runner.invoke(app, ["polymarket", "cancel-all"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["count"] == 2
        assert d["data"]["canceled"] == ["0xaaa", "0xbbb"]


# ---------------------------------------------------------------------------
# Redeem command
# ---------------------------------------------------------------------------

class TestPolyRedeem:
    """Poly redeem — on-chain redemption of resolved positions."""

    def test_creates_proposal(self, poly_patched):
        """Redeem with redeemable positions creates a proposal."""
        with patch("regard.venues.polymarket.commands.act.get_positions",
                    return_value=list(MOCK_REDEEMABLE_POSITIONS)):
            result = runner.invoke(app, ["polymarket", "redeem"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["command"] == "redeem"
        assert d["data"]["venue"] == "polymarket"
        assert len(d["data"]["params"]["positions"]) == 1
        pos = d["data"]["params"]["positions"][0]
        assert pos["condition_id"] == "0xcondition_resolved_1"
        assert pos["size"] == "50"
        assert pos["outcome"] == "Yes"

    def test_no_redeemable_positions(self, poly_patched):
        """No redeemable positions → NOTHING_TO_REDEEM."""
        result = runner.invoke(app, ["polymarket", "redeem"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "NOTHING_TO_REDEEM"


class TestPolyRedeemExecutor:
    """Approve a poly redeem proposal → executor calls ctf_redeem."""

    def test_redeem_executor(self, poly_patched):
        """Redeem executor calls ctf_redeem for each position."""
        with patch("regard.venues.polymarket.commands.act.get_positions",
                    return_value=list(MOCK_REDEEMABLE_POSITIONS)):
            result = runner.invoke(app, ["polymarket", "redeem"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["count"] == 1
        assert len(d["data"]["redeemed"]) == 1
        assert d["data"]["redeemed"][0]["tx"] == "0xredeem_hash"

        poly_patched["ctf_redeem"].assert_called_once_with(
            "0xcondition_resolved_1", 50.0, "token-yes-r1",
            collateral_addr="0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB",
        )

    def test_redeem_failure(self, poly_patched):
        """CTF redeem raises → REDEEM_FAILED."""
        poly_patched["ctf_redeem"].side_effect = RuntimeError("tx reverted")

        with patch("regard.venues.polymarket.commands.act.get_positions",
                    return_value=list(MOCK_REDEEMABLE_POSITIONS)):
            result = runner.invoke(app, ["polymarket", "redeem"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "REDEEM_FAILED"


# ---------------------------------------------------------------------------
# Merge command
# ---------------------------------------------------------------------------

class TestPolyMerge:
    """Poly merge — on-chain merge of YES + NO token pairs."""

    def test_creates_proposal(self, poly_patched):
        """Merge with mergeable positions creates a proposal with merge amounts."""
        with patch("regard.venues.polymarket.commands.act.get_positions",
                    return_value=list(MOCK_MERGEABLE_POSITIONS)), \
             patch("regard.venues.polymarket.client.lookup_neg_risk",
                    return_value={"0xcondition_merge_1": False}):
            result = runner.invoke(app, ["polymarket", "merge"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["command"] == "merge"
        assert d["data"]["venue"] == "polymarket"
        assert len(d["data"]["params"]["merges"]) == 1
        m = d["data"]["params"]["merges"][0]
        assert m["condition_id"] == "0xcondition_merge_1"
        # Merge size = min(30, 20) = 20
        assert m["merge_size"] == "20.0"
        assert m["neg_risk"] is False
        assert len(m["legs"]) == 2
        assert m["market"] == "Merge Market B"

    def test_neg_risk_stored_in_proposal(self, poly_patched):
        """negRisk markets have neg_risk=True in proposal params."""
        with patch("regard.venues.polymarket.commands.act.get_positions",
                    return_value=list(MOCK_MERGEABLE_POSITIONS)), \
             patch("regard.venues.polymarket.client.lookup_neg_risk",
                    return_value={"0xcondition_merge_1": True}):
            result = runner.invoke(app, ["polymarket", "merge"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["params"]["merges"][0]["neg_risk"] is True

    def test_no_mergeable_positions(self, poly_patched):
        """No mergeable positions → NOTHING_TO_MERGE."""
        result = runner.invoke(app, ["polymarket", "merge"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "NOTHING_TO_MERGE"


class TestPolyMergeExecutor:
    """Approve a poly merge proposal → executor calls ctf_merge."""

    def test_merge_executor(self, poly_patched):
        """Merge executor calls ctf_merge with neg_risk for each pair."""
        with patch("regard.venues.polymarket.commands.act.get_positions",
                    return_value=list(MOCK_MERGEABLE_POSITIONS)), \
             patch("regard.venues.polymarket.client.lookup_neg_risk",
                    return_value={"0xcondition_merge_1": False}):
            result = runner.invoke(app, ["polymarket", "merge"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["count"] == 1
        assert len(d["data"]["merged"]) == 1
        assert d["data"]["merged"][0]["tx"] == "0xmerge_hash"
        assert d["data"]["total_collateral"] == "20.00"

        poly_patched["ctf_merge"].assert_called_once_with(
            "0xcondition_merge_1", 20.0, "token-yes-m1",
            neg_risk=False,
            collateral_addr="0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB",
        )

    def test_merge_neg_risk_routed(self, poly_patched):
        """negRisk merge passes neg_risk=True to ctf_merge with resolved collateral.

        Before v0.19.16 the executor short-circuited resolve_binary_collateral
        for neg_risk=True and let ctf_call route through NEG_RISK_ADAPTER. Under
        V2 the adapter rejects pUSD with UnexpectedCollateralToken, so every
        such merge reverted. The fix routes everything through CTF with an
        explicit collateral address — Gamma's negRisk flag is a market-grouping
        hint, not an on-chain routing instruction.
        """
        with patch("regard.venues.polymarket.commands.act.get_positions",
                    return_value=list(MOCK_MERGEABLE_POSITIONS)), \
             patch("regard.venues.polymarket.client.lookup_neg_risk",
                    return_value={"0xcondition_merge_1": True}):
            result = runner.invoke(app, ["polymarket", "merge"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True

        poly_patched["ctf_merge"].assert_called_once_with(
            "0xcondition_merge_1", 20.0, "token-yes-m1",
            neg_risk=True,
            collateral_addr="0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB",
        )

    def test_merge_failure(self, poly_patched):
        """CTF merge raises → MERGE_FAILED."""
        poly_patched["ctf_merge"].side_effect = RuntimeError("tx reverted")

        with patch("regard.venues.polymarket.commands.act.get_positions",
                    return_value=list(MOCK_MERGEABLE_POSITIONS)), \
             patch("regard.venues.polymarket.client.lookup_neg_risk",
                    return_value={"0xcondition_merge_1": False}):
            result = runner.invoke(app, ["polymarket", "merge"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "MERGE_FAILED"


class TestCtfCallRouting:
    """Regression: every merge — including NegRisk-grouped — routes through
    the standard CTF contract, not the V1 NegRiskAdapter.

    The adapter's `col` immutable is USDC.e and rejects pUSD with
    UnexpectedCollateralToken under V2. Pre-fix, ctf_call(neg_risk=True) used
    the adapter with a 2-arg mergePositions and would revert every time post
    the 2026-04-28 V2 cutover. See upstream polymarket-alpha-bot PR #45.
    """

    @staticmethod
    def _ctf_addr() -> str:
        from regard.venues.polymarket.client import CONTRACTS
        return CONTRACTS["CTF"].lower()

    @staticmethod
    def _adapter_addr() -> str:
        from regard.venues.polymarket.client import CONTRACTS
        return CONTRACTS["NEG_RISK_ADAPTER"].lower()

    def _run_ctf_call(self, *, neg_risk: bool) -> str:
        """Drive ctf_call through a fully mocked stack and return the
        checksummed contract address that the merge fn was built against."""
        from unittest.mock import MagicMock, patch

        from regard.venues.polymarket import client as poly_client

        captured: dict[str, str] = {}

        def fake_contract(*, address, abi):
            captured["address"] = address
            mock = MagicMock()
            # Capture the merge call so we can assert the 5-arg signature
            merge_fn = MagicMock()
            merge_fn.build_transaction = MagicMock(return_value={"gas": 200000})
            mock.functions.mergePositions = MagicMock(return_value=merge_fn)
            captured["merge_fn"] = mock.functions.mergePositions
            return mock

        w3 = MagicMock()
        w3.eth.contract = fake_contract
        w3.eth.get_transaction_count = MagicMock(return_value=0)
        w3.to_checksum_address = lambda a: a if isinstance(a, str) and a.startswith("0x") else "0x" + str(a)
        receipt = {"status": 1}
        receipt_mock = MagicMock()
        receipt_mock.__getitem__ = lambda self, key: receipt[key]
        w3.eth.wait_for_transaction_receipt = MagicMock(return_value=receipt_mock)

        # Realistic 32-byte conditionId so bytes.fromhex doesn't raise
        cid = "0x" + "ab" * 32
        # Force a known collateral so we don't depend on resolve_binary_collateral
        pusd = poly_client.CONTRACTS["PUSD"]

        with patch.object(poly_client, "get_web3", return_value=w3), \
             patch.object(poly_client, "_get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_safe_gas_price", return_value=30_000_000_000), \
             patch("regard.core.evm.simulate_and_send", return_value=b"\x00" * 32):
            poly_client.ctf_call(cid, 1.0, "token", "merge",
                                 neg_risk=neg_risk, collateral_addr=pusd)

        return captured["address"].lower()

    def test_neg_risk_merge_uses_ctf_not_adapter(self):
        """neg_risk=True must route through CTF, not NEG_RISK_ADAPTER."""
        addr = self._run_ctf_call(neg_risk=True)
        assert addr == self._ctf_addr(), (
            f"NegRisk-flagged merge routed to {addr}; expected CTF "
            f"({self._ctf_addr()}). Routing through NEG_RISK_ADAPTER would "
            "revert with UnexpectedCollateralToken under V2."
        )
        assert addr != self._adapter_addr()

    def test_binary_merge_uses_ctf(self):
        """neg_risk=False must also route through CTF (unchanged from prior behavior)."""
        addr = self._run_ctf_call(neg_risk=False)
        assert addr == self._ctf_addr()


class TestPolyWrap:
    """Poly wrap (USDC.e → pUSD via CollateralOnramp)."""

    def test_creates_proposal(self, poly_patched):
        """poly wrap N creates a proposal with sender/recipient/amount in params."""
        with patch("regard.venues.polymarket.client.get_wallet_balances",
                   return_value={"pusd": "0.00", "usdc_e": "5.00", "usdc": "0.00", "pol": "2.00", "rpc_ok": True}), \
             patch("regard.venues.polymarket.client.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"):
            result = runner.invoke(app, ["polygon", "usdce", "transfer", "pusd", "1"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["command"] == "usdce.transfer.pusd"
        assert d["data"]["params"]["amount"] == "1.0"
        assert d["data"]["params"]["amount_raw"] == "1000000"
        assert d["data"]["checks"]["usdc_e_balance"] == "5.000000"
        assert d["data"]["checks"]["projected_usdc_e"] == "4.000000"

    def test_insufficient_balance_rejected(self, poly_patched):
        """wrap with amount > USDC.e balance → INSUFFICIENT_BALANCE."""
        with patch("regard.venues.polymarket.client.get_wallet_balances",
                   return_value={"pusd": "0.00", "usdc_e": "0.50", "usdc": "0.00", "pol": "2.00", "rpc_ok": True}), \
             patch("regard.venues.polymarket.client.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"):
            result = runner.invoke(app, ["polygon", "usdce", "transfer", "pusd", "1"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INSUFFICIENT_BALANCE"

    def test_invalid_amount_rejected(self, poly_patched):
        """wrap 0 or negative → INVALID_AMOUNT."""
        with patch("regard.venues.polymarket.client.get_wallet_balances",
                   return_value={"pusd": "0.00", "usdc_e": "5.00", "usdc": "0.00", "pol": "2.00", "rpc_ok": True}), \
             patch("regard.venues.polymarket.client.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"):
            result = runner.invoke(app, ["polygon", "usdce", "transfer", "pusd", "0"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_AMOUNT"


class TestPolyUnwrap:
    """Poly unwrap (pUSD → USDC.e via CollateralOfframp)."""

    def test_creates_proposal(self, poly_patched):
        """poly unwrap N creates a proposal with sender/recipient/amount in params."""
        with patch("regard.venues.polymarket.client.get_wallet_balances",
                   return_value={"pusd": "5.00", "usdc_e": "0.00", "usdc": "0.00", "pol": "2.00", "rpc_ok": True}), \
             patch("regard.venues.polymarket.client.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"):
            result = runner.invoke(app, ["polygon", "pusd", "transfer", "usdce", "1"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["command"] == "pusd.transfer.usdce"
        assert d["data"]["params"]["amount"] == "1.0"
        assert d["data"]["params"]["amount_raw"] == "1000000"
        assert d["data"]["checks"]["pusd_balance"] == "5.000000"
        assert d["data"]["checks"]["projected_pusd"] == "4.000000"

    def test_insufficient_balance_rejected(self, poly_patched):
        """unwrap with amount > pUSD balance → INSUFFICIENT_BALANCE."""
        with patch("regard.venues.polymarket.client.get_wallet_balances",
                   return_value={"pusd": "0.50", "usdc_e": "0.00", "usdc": "0.00", "pol": "2.00", "rpc_ok": True}), \
             patch("regard.venues.polymarket.client.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"):
            result = runner.invoke(app, ["polygon", "pusd", "transfer", "usdce", "1"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INSUFFICIENT_BALANCE"


# ---------------------------------------------------------------------------
# Contract: all poly commands produce valid JSON
# ---------------------------------------------------------------------------

POLY_COMMANDS = [
    ["polymarket", "status"],
    ["polymarket", "balance"],
    ["polymarket", "positions"],
    ["polymarket", "orders"],
    ["polymarket", "markets"],
    ["polymarket", "market", "btc-100k-2027"],
    ["polymarket", "event", "us-presidential-election-2028"],
    ["polymarket", "prices", "btc-100k-2027"],
    ["polymarket", "book", "btc-100k-2027"],
    ["polymarket", "trades"],
    ["polymarket", "cancel", "0xa0afb499737a22fc936add1de64b2e2066fe0ffd9dbc014bb15727aab9e7a30c"],
    ["polymarket", "cancel-all"],
    ["polymarket", "redeem"],
    ["polymarket", "merge"],
]


@pytest.mark.parametrize("args", POLY_COMMANDS, ids=lambda a: " ".join(a))
def test_poly_contract(poly_patched, args):
    """Every poly command must produce valid JSON."""
    result = runner.invoke(app, args)
    d = parse(result)
    assert "ok" in d


# ---------------------------------------------------------------------------
# Display conformance: every agent-safe read MUST include a `display` field
# ---------------------------------------------------------------------------

POLY_READ_COMMANDS = [
    ["polymarket", "status"],
    ["polymarket", "balance"],
    ["polymarket", "positions"],
    ["polymarket", "orders"],
    ["polymarket", "geo"],
    ["polymarket", "markets"],
    ["polymarket", "market", "btc-100k-2027"],
    ["polymarket", "event", "us-presidential-election-2028"],
    ["polymarket", "prices", "btc-100k-2027"],
    ["polymarket", "book", "btc-100k-2027"],
    ["polymarket", "trades"],
]


@pytest.mark.parametrize("args", POLY_READ_COMMANDS, ids=lambda a: " ".join(a))
def test_poly_read_has_display(poly_patched, args):
    """Every Poly agent-safe read MUST populate the `display` field.

    Regression guard against the systemic gap discovered 2026-04-17: all 11
    Poly reads were shipping without a human-readable rendering while HL peers
    populated one. Keeps the two venues aligned as new commands land.
    """
    result = runner.invoke(app, args)
    d = parse(result)
    assert d.get("ok") is True, f"{args} did not succeed: {d}"
    assert "display" in d, f"{args} missing `display` field"
    assert d["display"], f"{args} has empty `display` field"


class TestPolyTradesSortOrder:
    """Regression guard for poly trades slicing semantics.

    Mirrors the HL `test_output_sorted_newest_first` / `test_limit_returns_newest`
    tests added 2026-04-17. `get_trades()` empirically returns newest-first, so
    `review.py:29` uses `[:limit]` to take the N most recent. If the SDK ever
    flips its sort order, these tests fail — prompting a slicing update (sort
    by match_time desc before slicing) rather than silently returning oldest.
    """

    def test_limit_returns_newest(self, poly_patched):
        poly_patched["clob"].get_trades.return_value = [
            {**MOCK_TRADES[0], "id": "newer", "match_time": "1711789300"},
            {**MOCK_TRADES[0], "id": "older", "match_time": "1711789100"},
        ]
        result = runner.invoke(app, ["polymarket", "trades", "--limit", "1"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1
        assert d["data"][0]["trade_id"] == "newer"

    def test_limit_returns_newest_from_oldest_first_input(self, poly_patched):
        """SDK sort-order flip must not leak the N OLDEST fills to the user.

        Regression guard for peer-review finding TRADES_NO_SORT (2026-04-17):
        `get_trades()` empirically returns newest-first today, but if the SDK
        ever flips to oldest-first, the previous `[:limit]` would silently
        return stale trades. Fix: explicit sort by match_time desc before
        slicing.
        """
        poly_patched["clob"].get_trades.return_value = [
            {**MOCK_TRADES[0], "id": "oldest", "match_time": "1711789100"},
            {**MOCK_TRADES[0], "id": "middle", "match_time": "1711789200"},
            {**MOCK_TRADES[0], "id": "newest", "match_time": "1711789300"},
        ]
        result = runner.invoke(app, ["polymarket", "trades", "--limit", "1"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1
        assert d["data"][0]["trade_id"] == "newest"

    def test_output_sorted_newest_first(self, poly_patched):
        """Output MUST be in descending time order regardless of SDK order."""
        poly_patched["clob"].get_trades.return_value = [
            {**MOCK_TRADES[0], "id": "oldest", "match_time": "1711789100"},
            {**MOCK_TRADES[0], "id": "newest", "match_time": "1711789300"},
            {**MOCK_TRADES[0], "id": "middle", "match_time": "1711789200"},
        ]
        result = runner.invoke(app, ["polymarket", "trades"])
        d = parse(result)
        times = [row["created_at"] for row in d["data"]]
        assert times == sorted(times, reverse=True)


class TestPolyMarketFreeTextResolution:
    """Free-text resolver picks the best word-overlap match.

    Gamma's `/markets?q=<text>` ranks by popularity, not relevance. Fetching
    only the top-1 hit yields unrelated markets (e.g. `q=Hezbollah` → "Russia
    Ukraine Ceasefire"). Fix: fetch 25 candidates and score by shared word
    count with the query, reject all-zero to preserve the `UNKNOWN_MARKET`
    contract.
    """

    def test_best_overlap_wins_over_popular_unrelated(self, poly_patched):
        # Resolver falls back to top-N-by-volume and scores word overlap client-side.
        # Fixture: first candidate is popular but unrelated; second matches the query.
        popular_unrelated = {**MOCK_GAMMA_MARKET, "id": "999", "question": "Russia Ukraine Ceasefire", "slug": "russia-ukraine-ceasefire"}
        correct_match = {**MOCK_GAMMA_MARKET, "id": "1994007", "question": "Israel x Hezbollah ceasefire by April 18, 2026?", "slug": "israel-x-hezbollah-ceasefire"}

        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if path == "/markets":
                # Condition lookup (0x...): empty; slug: empty; fallback list: pool
                if params and ("condition_id" in params or "slug" in params):
                    resp.json.return_value = []
                else:
                    resp.json.return_value = [popular_unrelated, correct_match]
            else:
                resp.status_code = 404
                resp.json.return_value = []
            resp.raise_for_status = MagicMock()
            return resp

        poly_patched["gamma"].get.side_effect = _mock_get
        result = runner.invoke(app, ["polymarket", "market", "Hezbollah"])
        d = parse(result)
        assert d["ok"] is True, f"Expected resolution, got: {d}"
        assert d["data"]["market_id"] == "1994007"

    def test_all_zero_overlap_still_returns_unknown(self, poly_patched):
        unrelated = {**MOCK_GAMMA_MARKET, "id": "999", "question": "Completely different market", "slug": "completely-different"}

        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if path == "/markets":
                if params and ("condition_id" in params or "slug" in params):
                    resp.json.return_value = []
                else:
                    resp.json.return_value = [unrelated]
            else:
                resp.status_code = 404
                resp.json.return_value = []
            resp.raise_for_status = MagicMock()
            return resp

        poly_patched["gamma"].get.side_effect = _mock_get
        result = runner.invoke(app, ["polymarket", "market", "zxqvbnm"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "UNKNOWN_MARKET"

    def test_stop_word_only_query_rejected(self, poly_patched):
        """Stop-word-only query MUST NOT resolve to any market.

        Regression guard for peer-review finding RESOLVER_STOP_WORDS (2026-04-17):
        unfiltered word-overlap counted "will", "the", "by" etc., so
        `poly order will buy 5` (a nonsense identifier with only stop words)
        could silently resolve to a high-volume market like "Will BTC hit
        $100k by 2027?" and route the order to the wrong market. Fix: strip
        stop words from the query before scoring; empty post-filter set
        returns UNKNOWN_MARKET.
        """
        # Pool has a high-volume market whose only overlap with "will" / "by"
        # / "the" is those stop words. Resolver MUST NOT pick it.
        pool_market = {
            **MOCK_GAMMA_MARKET,
            "id": "btc_100k",
            "question": "Will BTC hit $100k by 2027?",
            "slug": "btc-100k-2027",
        }

        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if path == "/markets":
                if params and ("condition_id" in params or "slug" in params):
                    resp.json.return_value = []
                else:
                    resp.json.return_value = [pool_market]
            else:
                resp.status_code = 404
                resp.json.return_value = []
            resp.raise_for_status = MagicMock()
            return resp

        poly_patched["gamma"].get.side_effect = _mock_get
        # Query "will by the" has only stop words; after filter, empty set.
        result = runner.invoke(app, ["polymarket", "market", "will by the"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "UNKNOWN_MARKET"

    def test_content_word_overlap_resolves(self, poly_patched):
        """After stop-word filter, a single content-word overlap still resolves.

        Sanity check that the stop-word filter didn't break the legitimate
        single-word case (e.g., `poly market "Hezbollah"` should still work
        against a pool containing "Israel x Hezbollah ceasefire").
        """
        correct = {
            **MOCK_GAMMA_MARKET,
            "id": "1994007",
            "question": "Israel x Hezbollah ceasefire by April 18, 2026?",
            "slug": "israel-x-hezbollah-ceasefire",
        }

        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if path == "/markets":
                if params and ("condition_id" in params or "slug" in params):
                    resp.json.return_value = []
                else:
                    resp.json.return_value = [correct]
            else:
                resp.status_code = 404
                resp.json.return_value = []
            resp.raise_for_status = MagicMock()
            return resp

        poly_patched["gamma"].get.side_effect = _mock_get
        result = runner.invoke(app, ["polymarket", "market", "Hezbollah"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["market_id"] == "1994007"

    def test_multiword_query_requires_two_overlaps(self, poly_patched):
        """Multi-word queries need ≥2 content-word matches.

        Regression: a 4-word fake slug `unknown-slug-xyz-does-not-exist`
        shared only the token "exist" with a high-volume market ("Will
        the US confirm that aliens exist before 2027?"). With the old
        flat `_MIN_SCORE = 1` threshold, that single incidental overlap
        silently resolved the fake slug to the aliens market. Fix:
        require min(2, N) overlap where N is the post-stop-word query
        length — single-word queries still resolve on a single match,
        but 2+-word queries must share at least 2 content words.
        """
        aliens = {
            **MOCK_GAMMA_MARKET,
            "id": "703257",
            "question": "Will the US confirm that aliens exist before 2027?",
            "slug": "will-the-us-confirm-that-aliens-exist-before-2027",
        }

        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if path == "/markets":
                if params and ("condition_id" in params or "slug" in params):
                    resp.json.return_value = []
                else:
                    resp.json.return_value = [aliens]
            else:
                resp.status_code = 404
                resp.json.return_value = []
            resp.raise_for_status = MagicMock()
            return resp

        poly_patched["gamma"].get.side_effect = _mock_get
        result = runner.invoke(app, ["polymarket", "market", "unknown-slug-xyz-does-not-exist"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "UNKNOWN_MARKET"

    def test_multiword_query_with_two_overlaps_resolves(self, poly_patched):
        """Multi-word queries with ≥2 content-word overlaps still resolve."""
        correct = {
            **MOCK_GAMMA_MARKET,
            "id": "703257",
            "question": "Will the US confirm that aliens exist before 2027?",
            "slug": "us-aliens-exist-2027",
        }

        def _mock_get(path, params=None):
            resp = MagicMock()
            resp.status_code = 200
            if path == "/markets":
                if params and ("condition_id" in params or "slug" in params):
                    resp.json.return_value = []
                else:
                    resp.json.return_value = [correct]
            else:
                resp.status_code = 404
                resp.json.return_value = []
            resp.raise_for_status = MagicMock()
            return resp

        poly_patched["gamma"].get.side_effect = _mock_get
        # Two content words ('aliens', 'exist') both match.
        result = runner.invoke(app, ["polymarket", "market", "aliens exist"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["market_id"] == "703257"
