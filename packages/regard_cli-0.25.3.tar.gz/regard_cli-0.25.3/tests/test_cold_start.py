"""Cold-start adapter tests — SDK state not pre-seeded.

Unlike the main test suite which pre-populates coin_to_asset, these tests
start with only default perps loaded (like production) and verify that
lazy-loading, token format resolution, and balance parsing work against
real API response shapes.

Mocks only the HTTP boundary (Info.post / Info.meta). Internal SDK state
management (coin_to_asset, set_perp_meta) uses real implementations.
"""

from unittest.mock import MagicMock, patch

import pytest

from regard.venues.hyperliquid.client import get_collateral_map, get_spot_balances
from regard.venues.hyperliquid.resolver import Resolver

# ---------------------------------------------------------------------------
# Realistic API response shapes — copied from real mainnet responses
# ---------------------------------------------------------------------------

DEFAULT_META = {
    "universe": [
        {"name": "BTC", "szDecimals": 5, "maxLeverage": 50},
        {"name": "ETH", "szDecimals": 4, "maxLeverage": 50},
        {"name": "SOL", "szDecimals": 2, "maxLeverage": 20},
    ]
}

XYZ_META = {
    "universe": [
        {"name": "xyz:TSLA", "szDecimals": 1, "maxLeverage": 10},
        {"name": "xyz:CL", "szDecimals": 0, "maxLeverage": 10},
        {"name": "xyz:NATGAS", "szDecimals": 0, "maxLeverage": 5},
    ]
}

FLX_META = {
    "universe": [
        {"name": "flx:DOGE", "szDecimals": 0, "maxLeverage": 5},
    ]
}

PERP_DEXS = [
    None,              # default dex is None on mainnet
    {"name": "xyz"},
    {"name": "flx"},
]

ALL_PERP_METAS = [
    {"universe": DEFAULT_META["universe"], "collateralToken": 0},
    {"universe": XYZ_META["universe"], "collateralToken": 0},
    {"universe": FLX_META["universe"], "collateralToken": 360},
]

SPOT_META = {
    "tokens": [
        {"name": "USDC", "szDecimals": 2, "weiDecimals": 8, "index": 0, "tokenId": "0x1", "isCanonical": True},
        {"name": "HYPE", "szDecimals": 2, "weiDecimals": 18, "index": 1, "tokenId": "0x2", "isCanonical": True},
        {"name": "USDH", "szDecimals": 2, "weiDecimals": 8, "index": 360, "tokenId": "0x54e00a", "isCanonical": False},
        {"name": "USDE", "szDecimals": 2, "weiDecimals": 18, "index": 235, "tokenId": "0x3b2e8", "isCanonical": False},
    ],
    "universe": [
        {"tokens": [1, 0], "name": "HYPE/USDC", "index": 0, "isCanonical": True},
    ],
}

# Real shape from spot_user_state API — uses "token" key (not "coin")
SPOT_BALANCES_UNIFIED = {
    "balances": [
        {"token": 0, "total": "17.32"},
        {"token": 360, "total": "14.56"},
        {"token": 235, "total": "11.97"},
    ]
}

SPOT_BALANCES_LEGACY = {
    "balances": [
        {"token": 0, "holds": "1732000000", "withdrawn": "0"},       # USDC: 17.32 (8 weiDecimals)
        {"token": 360, "holds": "1456000000", "withdrawn": "0"},     # USDH: 14.56 (8 weiDecimals)
    ]
}

# HIP-4 outcome holdings — `coin` is `+<encoding>`, `token` may be missing
# (outcome tokens have no tokenId per brief §8). Mirrors what the chainstacklabs
# reference repo's `examples/03_account_state.py` filters for.
SPOT_BALANCES_WITH_OUTCOMES = {
    "balances": [
        # Standard spot row (existing pattern)
        {"token": 0, "total": "100.00", "coin": "USDC", "entryNtl": "0.0", "hold": "0.0"},
        # HIP-4 YES side held — token missing (no tokenId per brief §8)
        {"coin": "+10", "total": "0.5", "hold": "0.0", "entryNtl": "0.225"},
        # HIP-4 NO side held — token explicitly null
        {"token": None, "coin": "+11", "total": "0.3", "hold": "0.0", "entryNtl": "0.135"},
        # Zero-balance outcome row should be filtered out
        {"coin": "+19", "total": "0.0", "hold": "0.0", "entryNtl": "0.0"},
    ]
}

# HIP-4 outcomeMeta — shape captured from mainnet 2026-05-04 (one BTC daily binary).
# Brief §3 #10/#11 UX gotcha: outcome=1 produces sequential-looking coin strings
# (#10 / #11) that are actually the two sides of a single market.
OUTCOME_META = {
    "outcomes": [
        {
            "outcome": 1,
            "name": "Recurring",
            "description": "class:priceBinary|underlying:BTC|expiry:20260504-0600|targetPrice:78213|period:1d",
            "sideSpecs": [
                {"name": "Yes"},
                {"name": "No"},
            ],
        }
    ],
    "questions": [],
}


# ---------------------------------------------------------------------------
# Helper: semi-real Info mock
# ---------------------------------------------------------------------------

def _make_cold_info():
    """Create an Info-like mock with real state management but mocked HTTP.

    Starts with ONLY default perps in coin_to_asset (like production).
    set_perp_meta is the real implementation so lazy-loading actually works.
    """
    info = MagicMock()

    # Real state — only default perps loaded at init (production behavior)
    info.coin_to_asset = {}
    info.name_to_coin = {}
    info.asset_to_sz_decimals = {}

    # Load default perps (what Info.__init__ does)
    for asset, asset_info in enumerate(DEFAULT_META["universe"]):
        info.coin_to_asset[asset_info["name"]] = asset
        info.name_to_coin[asset_info["name"]] = asset_info["name"]
        info.asset_to_sz_decimals[asset] = asset_info["szDecimals"]

    # Load spot (what Info.__init__ does)
    for spot_info in SPOT_META["universe"]:
        asset = spot_info["index"] + 10000
        info.coin_to_asset[spot_info["name"]] = asset

    # Real set_perp_meta — updates coin_to_asset when called
    def _set_perp_meta(meta, offset):
        for asset_idx, asset_info in enumerate(meta["universe"]):
            a = asset_idx + offset
            info.coin_to_asset[asset_info["name"]] = a
            info.name_to_coin[asset_info["name"]] = asset_info["name"]
            info.asset_to_sz_decimals[a] = asset_info["szDecimals"]
    info.set_perp_meta = _set_perp_meta

    # Mock HTTP boundary — returns realistic data by request type
    def _post(endpoint, payload):
        req_type = payload.get("type", "")
        dex = payload.get("dex", "")
        if req_type == "perpDexs":
            return list(PERP_DEXS)
        if req_type == "meta":
            if dex == "xyz":
                return dict(XYZ_META)
            if dex == "flx":
                return dict(FLX_META)
            return dict(DEFAULT_META)
        if req_type == "allPerpMetas":
            return list(ALL_PERP_METAS)
        if req_type == "spotMeta":
            return dict(SPOT_META)
        if req_type == "outcomeMeta":
            return dict(OUTCOME_META)
        return {}
    info.post.side_effect = _post

    # meta() delegates to post (like real SDK)
    def _meta(dex=""):
        return _post("/info", {"type": "meta", "dex": dex})
    info.meta.side_effect = _meta

    info.spot_meta.return_value = dict(SPOT_META)
    info.spot_user_state.return_value = dict(SPOT_BALANCES_UNIFIED)

    return info


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestResolverColdStart:
    """Resolver starts with empty HIP-3 state, loads lazily."""

    def test_default_perp_resolves_immediately(self):
        info = _make_cold_info()
        r = Resolver(info)
        assert r.resolve("BTC") == "BTC"
        assert r.resolve("eth") == "ETH"  # case-insensitive

    def test_hip3_full_name_resolves_after_lazy_load(self):
        """xyz:CL is NOT in coin_to_asset initially. Resolver must lazy-load."""
        info = _make_cold_info()
        r = Resolver(info)

        assert "xyz:CL" not in info.coin_to_asset  # not pre-seeded
        result = r.resolve("xyz:CL")
        assert result == "xyz:CL"
        assert "xyz:CL" in info.coin_to_asset  # now loaded

    def test_hip3_short_name_resolves_after_lazy_load(self):
        """Bare 'CL' should resolve to 'xyz:CL' via short map."""
        info = _make_cold_info()
        r = Resolver(info)

        result = r.resolve("CL")
        assert result == "xyz:CL"

    def test_hip3_from_second_dex_resolves(self):
        """Assets on non-xyz dexes also lazy-load correctly."""
        info = _make_cold_info()
        r = Resolver(info)

        assert "flx:DOGE" not in info.coin_to_asset
        result = r.resolve("flx:DOGE")
        assert result == "flx:DOGE"

    def test_unknown_asset_dies(self):
        """Completely unknown asset fails cleanly after lazy-load attempt."""
        info = _make_cold_info()
        r = Resolver(info)

        with pytest.raises(SystemExit) as exc_info:
            r.resolve("DOESNOTEXIST")
        assert exc_info.value.code == 2  # validation_error

    def test_all_dexes_loaded_on_first_miss(self):
        """A single miss triggers loading ALL dexes, not just one."""
        info = _make_cold_info()
        r = Resolver(info)

        r.resolve("xyz:CL")
        # flx:DOGE should also be available now (loaded in same batch)
        assert "flx:DOGE" in info.coin_to_asset


class TestResolverOutcomes:
    """HIP-4 outcomeMeta lazy-loading + resolver fall-through."""

    def test_outcomes_not_loaded_at_construction(self):
        """outcomeMeta is NOT fetched eagerly — only on first need.

        Eager-load would force every CLI invocation to pay the network cost
        even when no HIP-4 path is used. Mirrors the HIP-3 dex pattern.
        """
        info = _make_cold_info()
        Resolver(info)
        # No outcomeMeta call should have been issued during construction
        for call in info.post.call_args_list:
            payload = call.args[1] if len(call.args) > 1 else call.kwargs.get("json", {})
            assert payload.get("type") != "outcomeMeta", \
                f"outcomeMeta fetched eagerly: {call}"

    def test_get_outcomes_lazy_loads(self):
        """Calling get_outcomes() triggers lazy-load, returns structured data."""
        info = _make_cold_info()
        r = Resolver(info)
        outcomes = r.get_outcomes()
        assert len(outcomes) == 1
        btc = outcomes[0]
        assert btc["outcome"] == 1
        assert btc["name"] == "Recurring"
        assert btc["parsed_description"]["underlying"] == "BTC"
        assert btc["parsed_description"]["target_price"] == "78213"  # string per Article I
        # Both sides present, in YES/NO order
        assert len(btc["sides"]) == 2
        assert btc["sides"][0]["coin"] == "#10"
        assert btc["sides"][0]["balance_coin"] == "+10"
        assert btc["sides"][0]["asset_id"] == 100_000_010
        assert btc["sides"][0]["name"] == "Yes"
        assert btc["sides"][1]["coin"] == "#11"
        assert btc["sides"][1]["balance_coin"] == "+11"
        assert btc["sides"][1]["asset_id"] == 100_000_011
        assert btc["sides"][1]["name"] == "No"

    def test_get_outcomes_injects_into_coin_to_asset(self):
        """Lazy-load must inject `#<encoding>` entries so SDK helpers see them."""
        info = _make_cold_info()
        r = Resolver(info)
        assert "#10" not in info.coin_to_asset  # not pre-seeded
        r.get_outcomes()
        assert info.coin_to_asset["#10"] == 100_000_010
        assert info.coin_to_asset["#11"] == 100_000_011
        assert info.name_to_coin["#10"] == "#10"
        assert info.name_to_coin["#11"] == "#11"

    def test_resolve_falls_through_to_outcomes_for_hash_prefix(self):
        """`resolve('#10')` lazy-loads outcomes when not yet loaded.

        This is the resolver's HIP-4 fall-through: a `#`-prefixed name that
        the dex/spot maps don't know is presumed to be an outcome coin. We
        try one round of outcomeMeta load before declaring UNKNOWN_ASSET.
        """
        info = _make_cold_info()
        r = Resolver(info)
        assert "#10" not in info.coin_to_asset
        result = r.resolve("#10")
        assert result == "#10"
        assert "#10" in info.coin_to_asset  # now loaded

    def test_resolve_does_not_lazy_load_for_non_outcome_typos(self):
        """A typo like `BTCC` should NOT trigger an outcomeMeta network call.

        Only `#`-prefixed unknowns pull outcomeMeta. Saves a round-trip per
        misspelled perp/spot ticker.
        """
        info = _make_cold_info()
        r = Resolver(info)
        with pytest.raises(SystemExit) as exc_info:
            r.resolve("BTCC")
        assert exc_info.value.code == 2
        # No outcomeMeta call was issued
        for call in info.post.call_args_list:
            payload = call.args[1] if len(call.args) > 1 else call.kwargs.get("json", {})
            assert payload.get("type") != "outcomeMeta"

    def test_get_outcome_by_id_lookup(self):
        """O(1) lookup by outcome integer for the singular `outcome <id>` command."""
        info = _make_cold_info()
        r = Resolver(info)
        record = r.get_outcome_by_id(1)
        assert record is not None
        assert record["outcome"] == 1
        assert record["sides"][0]["coin"] == "#10"

    def test_get_outcome_by_id_returns_none_for_unknown(self):
        info = _make_cold_info()
        r = Resolver(info)
        assert r.get_outcome_by_id(99999) is None

    def test_lazy_load_idempotent(self):
        """Repeat calls don't re-fetch — the loaded flag is sticky."""
        info = _make_cold_info()
        r = Resolver(info)
        r.get_outcomes()
        r.get_outcomes()
        r.get_outcomes()
        outcome_meta_calls = [
            call for call in info.post.call_args_list
            if (call.args[1] if len(call.args) > 1 else call.kwargs.get("json", {})).get("type") == "outcomeMeta"
        ]
        assert len(outcome_meta_calls) == 1, \
            f"outcomeMeta fetched {len(outcome_meta_calls)} times — should be 1"

    def test_network_failure_degrades_silently(self):
        """A failed outcomeMeta fetch returns [] without raising (mirrors dexes)."""
        info = _make_cold_info()

        def _fail_post(endpoint, payload):
            if payload.get("type") == "outcomeMeta":
                raise ConnectionError("network down")
            return {}
        info.post.side_effect = _fail_post

        r = Resolver(info)
        outcomes = r.get_outcomes()
        assert outcomes == []  # graceful degradation
        # And the loaded flag is still set so we don't retry on every call
        outcomes = r.get_outcomes()
        assert outcomes == []

    def test_malformed_outcomemeta_response_degrades_silently(self):
        """If outcomeMeta returns a shape that fails Pydantic validation,
        treat it the same as a network failure: empty list, no exception."""
        info = _make_cold_info()

        def _bad_post(endpoint, payload):
            if payload.get("type") == "outcomeMeta":
                return {"outcomes": "not-a-list"}  # malformed
            if payload.get("type") == "perpDexs":
                return list(PERP_DEXS)
            return {}
        info.post.side_effect = _bad_post

        r = Resolver(info)
        assert r.get_outcomes() == []

    def test_outcome_coin_skipped_from_short_map(self):
        """`_build_default_map` must not pollute `_short_map` with `#<enc>` keys.

        Once outcomes are loaded, `info.coin_to_asset` contains `#10` etc.
        The short-map indexes UPPER tickers for ambiguity resolution; folding
        outcome coins in there would create useless 'AMBIGUOUS' candidates.
        """
        info = _make_cold_info()
        r = Resolver(info)
        r.get_outcomes()  # loads #10, #11 into coin_to_asset
        # If we recreate the resolver after load, _build_default_map should
        # still skip the #<enc> entries.
        r2 = Resolver(info)
        assert "#10" not in r2._short_map
        assert "#11" not in r2._short_map


class TestSpotBalanceParsing:
    """Verify balance parsing uses correct API response keys."""

    def test_unified_format_uses_token_key(self):
        """Real API returns 'token' (int index), not 'coin'."""
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_UNIFIED)

        balances = get_spot_balances(info, "0xTEST")
        tokens = {b["token"] for b in balances}
        assert "USDC" in tokens
        assert "USDH" in tokens
        assert "USDE" in tokens

    def test_unified_format_correct_amounts(self):
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_UNIFIED)

        balances = get_spot_balances(info, "0xTEST")
        by_token = {b["token"]: b["balance"] for b in balances}
        assert by_token["USDC"] == "17.32"
        assert by_token["USDH"] == "14.56"

    def test_legacy_format_uses_token_key(self):
        """Legacy format (holds/withdrawn in wei) also uses 'token' key."""
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_LEGACY)

        balances = get_spot_balances(info, "0xTEST")
        tokens = {b["token"] for b in balances}
        assert "USDC" in tokens
        assert "USDH" in tokens

    def test_legacy_format_wei_conversion(self):
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_LEGACY)

        balances = get_spot_balances(info, "0xTEST")
        by_token = {b["token"]: b["balance"] for b in balances}
        assert by_token["USDC"] == "17.32"   # 1732000000 / 10^8
        assert by_token["USDH"] == "14.56"   # 1456000000 / 10^8


class TestSpotBalanceOutcomes:
    """HIP-4 outcome rows in spotClearinghouseState.balances[] (brief §8).

    Discriminator is `coin` starting with `+`. `token` may be missing or
    null. The output row carries `kind: "outcome"` so downstream commands
    can distinguish it from standard spot tokens.
    """

    def test_outcome_row_surfaced_with_kind_outcome(self):
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_WITH_OUTCOMES)

        balances = get_spot_balances(info, "0xTEST")
        outcomes = [b for b in balances if b.get("kind") == "outcome"]
        assert len(outcomes) == 2  # +10 and +11; +19 is zero, USDC is spot
        coins = {o["token"] for o in outcomes}
        assert coins == {"+10", "+11"}

    def test_outcome_row_decodes_outcome_and_side(self):
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_WITH_OUTCOMES)

        balances = get_spot_balances(info, "0xTEST")
        by_token = {b["token"]: b for b in balances if b.get("kind") == "outcome"}
        yes = by_token["+10"]
        no = by_token["+11"]
        # +10 → outcome=1, side=0 (YES)
        assert yes["outcome"] == 1
        assert yes["side"] == 0
        assert yes["side_name"] == "yes"
        # +11 → outcome=1, side=1 (NO)
        assert no["outcome"] == 1
        assert no["side"] == 1
        assert no["side_name"] == "no"

    def test_outcome_row_balance_is_string(self):
        """Article I: financial values are strings."""
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_WITH_OUTCOMES)

        balances = get_spot_balances(info, "0xTEST")
        for b in balances:
            if b.get("kind") == "outcome":
                assert isinstance(b["balance"], str)
                # The values come straight from the API "total" field, e.g. "0.5"
                assert b["balance"] in ("0.5", "0.3")

    def test_zero_balance_outcome_filtered(self):
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_WITH_OUTCOMES)

        balances = get_spot_balances(info, "0xTEST")
        outcome_coins = {b["token"] for b in balances if b.get("kind") == "outcome"}
        assert "+19" not in outcome_coins  # zero-balance row dropped

    def test_spot_row_carries_kind_spot(self):
        """Existing spot tokens get `kind: "spot"` for symmetry with outcome rows."""
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_WITH_OUTCOMES)

        balances = get_spot_balances(info, "0xTEST")
        usdc = [b for b in balances if b["token"] == "USDC"]
        assert len(usdc) == 1
        assert usdc[0]["kind"] == "spot"
        assert usdc[0]["balance"] == "100.00"

    def test_token_index_optional_for_outcomes(self):
        """token_index may be None on outcome rows (brief §8: no tokenId)."""
        info = _make_cold_info()
        info.spot_user_state.return_value = dict(SPOT_BALANCES_WITH_OUTCOMES)

        balances = get_spot_balances(info, "0xTEST")
        outcomes = [b for b in balances if b.get("kind") == "outcome"]
        # +10 has no `token` field; +11 has explicit None — both should land
        # with token_index=None (or missing) and not crash Pydantic validation.
        for o in outcomes:
            assert o.get("token_index") is None

    def test_plus_prefix_with_non_digit_body_falls_through_to_spot(self):
        """Regression (peer-review PLUS-DISCRIM): a row with `coin: +ABC`
        and a real `token` index must NOT be silently dropped when
        decode_balance_coin returns None. Falls through to the standard
        spot path so a future spot token whose name happens to start with
        `+` still surfaces. Current HL API has no such tokens — this is
        defensive against a latent silent-drop hazard.
        """
        info = _make_cold_info()
        # Seed a synthetic spot token whose name starts with `+`. We do
        # this by extending tokens_by_index via the existing spot_meta
        # mock — `+ABC` becomes a spot token with index 99.
        synthetic_meta = {
            "tokens": [
                *SPOT_META["tokens"],
                {"name": "+ABC", "szDecimals": 2, "weiDecimals": 8, "index": 99, "tokenId": "0x99", "isCanonical": False},
            ],
            "universe": SPOT_META["universe"],
        }
        info.spot_meta.return_value = synthetic_meta
        info.spot_user_state.return_value = {
            "balances": [
                {"token": 99, "total": "5.00", "coin": "+ABC", "entryNtl": "0.0", "hold": "0.0"},
            ]
        }
        balances = get_spot_balances(info, "0xTEST")
        # Pre-fix this row was dropped (decode returned None → continue).
        # Post-fix it surfaces via the spot path.
        plus_abc = [b for b in balances if b["token"] == "+ABC"]
        assert len(plus_abc) == 1
        assert plus_abc[0]["kind"] == "spot"
        assert plus_abc[0]["balance"] == "5.00"


class TestResolverUnknownOutcome:
    """Regression (peer-review UNKNOWN-CODE): `resolve('#<enc>')` for an
    expired/settled outcome must surface UNKNOWN_OUTCOME, not UNKNOWN_ASSET.

    Without this, agents using `book` / future `order` against an expired
    outcome coin pattern-match the same code as a perp typo. Article IV:
    structured error codes are the agent contract.
    """

    def test_unknown_hash_coin_after_meta_loaded_is_unknown_outcome(self, capsys):
        info = _make_cold_info()
        r = Resolver(info)
        # Force outcomes to load (#10/#11 are now in coin_to_asset).
        r.get_outcomes()

        # `#99999` doesn't exist in outcomeMeta — represents a settled or
        # never-existed market. Pre-fix this surfaced UNKNOWN_ASSET (wrong);
        # post-fix it's UNKNOWN_OUTCOME with a HIP-4-specific hint.
        with pytest.raises(SystemExit) as exc_info:
            r.resolve("#99999")
        assert exc_info.value.code == 2  # validation_error
        out = capsys.readouterr().out
        import json
        envelope = json.loads(out)
        assert envelope["error"]["code"] == "UNKNOWN_OUTCOME"
        assert "outcomeMeta" in envelope["error"]["hint"]

    def test_unknown_perp_typo_remains_unknown_asset(self, capsys):
        """Negative control — non-#-prefixed unknowns still get UNKNOWN_ASSET."""
        info = _make_cold_info()
        r = Resolver(info)
        with pytest.raises(SystemExit) as exc_info:
            r.resolve("BTCC")
        assert exc_info.value.code == 2
        out = capsys.readouterr().out
        import json
        envelope = json.loads(out)
        assert envelope["error"]["code"] == "UNKNOWN_ASSET"


class TestTokenFormatResolution:
    """Transfer path must build TOKEN:tokenId for non-canonical tokens."""

    def test_non_canonical_gets_token_id_suffix(self):
        """USDH is non-canonical → must become 'USDH:0x54e00a' for send_asset."""
        info = _make_cold_info()
        spot_meta = info.spot_meta()

        for t in spot_meta["tokens"]:
            if t["name"] == "USDH":
                assert not t["isCanonical"]
                expected = f"{t['name']}:{t['tokenId']}"
                assert expected == "USDH:0x54e00a"
                break
        else:
            pytest.fail("USDH not found in spot meta")

    def test_canonical_stays_plain(self):
        """USDC is canonical → stays as plain 'USDC'."""
        info = _make_cold_info()
        spot_meta = info.spot_meta()

        for t in spot_meta["tokens"]:
            if t["name"] == "USDC":
                assert t["isCanonical"]
                break
        else:
            pytest.fail("USDC not found in spot meta")

    def test_transfer_propose_builds_sdk_token(self):
        """Full transfer propose path resolves non-canonical token format."""
        from typer.testing import CliRunner

        from regard.main import app

        info = _make_cold_info()
        info.query_user_abstraction_state.return_value = "default"
        info.user_state.return_value = {"withdrawable": "100.00"}

        with patch("regard.venues.hyperliquid.commands.act.get_info", return_value=info), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xTEST"), \
             patch("regard.venues.hyperliquid.commands.act.get_exchange"), \
             patch("regard.venues.hyperliquid.commands.act.get_account_mode", return_value="default"), \
             patch("regard.venues.hyperliquid.commands.act.get_collateral_map", return_value={
                 "": ("USDC", 0), "flx": ("USDH", 360),
             }):
            runner = CliRunner()
            result = runner.invoke(app, ["hypercore", "spot", "transfer", "dex", "flx", "5.00", "--token", "USDH"])

            import json
            data = json.loads(result.output)
            assert data["ok"], f"unexpected error: {result.output}"
            assert data["data"]["params"]["sdk_token"] == "USDH:0x54e00a"
            assert data["data"]["params"]["token"] == "USDH"


class TestCollateralMapResolution:
    """Collateral map correctly maps dexes to their collateral tokens."""

    def test_non_usdc_collateral(self):
        """flx uses USDH (token index 360), not USDC."""
        info = _make_cold_info()
        coll_map = get_collateral_map(info)

        assert coll_map[""] == ("USDC", 0)       # default dex key is ""
        assert coll_map["xyz"] == ("USDC", 0)
        assert coll_map["flx"] == ("USDH", 360)
