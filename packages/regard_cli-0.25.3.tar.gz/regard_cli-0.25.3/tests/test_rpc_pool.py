"""Tests for `regard.core.rpc_pool` — RPC failover + reputation filtering.

Per Constitution Article II + memory `feedback_no_rpc_infra.md`. The pool's
behavior:
  1. User config override → exclusive use, chainId-verified.
  2. PRIMARY_RPC[chain_id] → if responsive AND chainId matches.
  3. chainlist.org candidates filtered by demo/keyed + M4 allowlist.
  4. All exhausted → RPC_UNAVAILABLE.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from regard.core.rpc_pool import (
    DEMO_KEYED_PATTERNS,
    PRIMARY_RPC,
    TRUSTED_RPC_OPERATORS,
    _filter_candidates,
    get_web3,
    is_keyed_or_demo,
    matches_allowlist,
)

# ---------------------------------------------------------------------------
# Constants smoke (catches accidental edits)
# ---------------------------------------------------------------------------


class TestConstants:
    def test_primary_rpc_covers_all_in_scope_chains(self):
        # 11 chains in v0.25.0 spec
        for chain_id in (1, 137, 42161, 8453, 10, 56, 43114, 143, 130, 4326, 999):
            assert chain_id in PRIMARY_RPC, f"PRIMARY_RPC missing chainId {chain_id}"
            assert PRIMARY_RPC[chain_id].startswith("https://")

    def test_trusted_operators_includes_minimum_set(self):
        # The operators that actually contribute failover URLs after filtering.
        # Symbolic-only entries (Alchemy, Chainstack) are also expected to be
        # present so future expansions match the same allowlist semantics.
        for name in ("dRPC", "PublicNode", "OnFinality", "1RPC", "BlastAPI",
                     "PocketNetwork", "bloXroute", "Ankr", "Tenderly",
                     "Alchemy", "LlamaRPC", "Chainstack"):
            assert name in TRUSTED_RPC_OPERATORS

    def test_demo_keyed_patterns_present(self):
        assert len(DEMO_KEYED_PATTERNS) >= 4


# ---------------------------------------------------------------------------
# is_keyed_or_demo — URL hygiene
# ---------------------------------------------------------------------------


class TestIsKeyedOrDemo:
    def test_alchemy_demo_path_rejected(self):
        assert is_keyed_or_demo("https://polygon-mainnet.g.alchemy.com/v2/demo")
        assert is_keyed_or_demo("https://arb-mainnet.g.alchemy.com/v2/demo")

    def test_alchemy_placeholder_rejected(self):
        assert is_keyed_or_demo("https://arb-mainnet.g.alchemy.com/v2/${ALCHEMY_API_KEY}")

    def test_long_hex_path_rejected(self):
        # 32+ hex char path segment is almost certainly an API key
        assert is_keyed_or_demo("https://rpc.ankr.com/arbitrum/c4cc6a8c87ec30258076de433ab2cf3d834228aae3fc4d76087873e4fea11635")
        assert is_keyed_or_demo("https://go.getblock.io/02667b699f05444ab2c64f9bff28f027")

    def test_uuid_path_rejected(self):
        assert is_keyed_or_demo("https://api-polygon-mainnet-full.n.dwellir.com/2ccf18bf-2916-4198-8856-42172854353c")

    def test_query_apikey_rejected(self):
        assert is_keyed_or_demo("https://example.com/rpc?api_key=foo")
        assert is_keyed_or_demo("https://example.com/rpc?apikey=bar")
        assert is_keyed_or_demo("https://example.com/rpc?key=baz")

    def test_clean_urls_pass(self):
        assert not is_keyed_or_demo("https://polygon-rpc.com")
        assert not is_keyed_or_demo("https://polygon.drpc.org")
        assert not is_keyed_or_demo("https://arb1.arbitrum.io/rpc")
        assert not is_keyed_or_demo("https://rpc.ankr.com/polygon")
        assert not is_keyed_or_demo("https://rpc.hyperliquid.xyz/evm")


# ---------------------------------------------------------------------------
# matches_allowlist — operator hostname filter
# ---------------------------------------------------------------------------


class TestMatchesAllowlist:
    def test_drpc_matches(self):
        assert matches_allowlist("https://polygon.drpc.org")
        assert matches_allowlist("https://arbitrum.drpc.org")
        assert matches_allowlist("https://hyperliquid.drpc.org")

    def test_publicnode_matches(self):
        assert matches_allowlist("https://polygon-bor-rpc.publicnode.com")

    def test_ankr_matches(self):
        assert matches_allowlist("https://rpc.ankr.com/polygon")

    def test_unknown_provider_rejected(self):
        # HypurrScan / Stakely / HyperLend are HL-specific operators NOT in M4
        assert not matches_allowlist("https://rpc.hypurrscan.io")
        assert not matches_allowlist("https://hyperliquid-json-rpc.stakely.io")
        assert not matches_allowlist("https://rpc.hyperlend.finance")
        # Random hosts also rejected
        assert not matches_allowlist("https://malicious-rpc.example.com")


# ---------------------------------------------------------------------------
# _filter_candidates — combines keyed-rejection + allowlist
# ---------------------------------------------------------------------------


class TestFilterCandidates:
    def test_filters_chainlist_polygon_entry(self):
        # Synthetic chainlist entry shape (matches real /rpcs.json)
        entry = {
            "chainId": 137,
            "rpc": [
                {"url": "https://polygon-rpc.com"},               # primary, ALSO matches no operator pattern
                {"url": "https://polygon.drpc.org"},              # dRPC ✓
                {"url": "https://rpc.ankr.com/polygon"},          # Ankr ✓
                {"url": "https://polygon-bor-rpc.publicnode.com"},  # PublicNode ✓
                {"url": "wss://polygon.drpc.org"},                # wss:// rejected
                {"url": "https://polygon-mainnet.g.alchemy.com/v2/demo"},  # demo-rejected
                {"url": "https://malicious-rpc.example.com"},     # not in allowlist
                {"url": "https://rpc.private.mev-x.com/polygon"}, # not in allowlist
                {"url": "https://1rpc.io/matic"},                 # 1RPC ✓
            ],
        }
        out = _filter_candidates(entry)
        assert "https://polygon.drpc.org" in out
        assert "https://rpc.ankr.com/polygon" in out
        assert "https://polygon-bor-rpc.publicnode.com" in out
        assert "https://1rpc.io/matic" in out
        # Rejected:
        assert "wss://polygon.drpc.org" not in out
        assert "https://polygon-mainnet.g.alchemy.com/v2/demo" not in out
        assert "https://malicious-rpc.example.com" not in out
        assert "https://rpc.private.mev-x.com/polygon" not in out
        # polygon-rpc.com has no operator pattern in TRUSTED_RPC_OPERATORS
        # (it's the chain's primary, not a multi-chain operator). Filtered out
        # of failover candidates by design — primary is tried first separately.
        assert "https://polygon-rpc.com" not in out

    def test_empty_chainlist_returns_empty_list(self):
        assert _filter_candidates({"chainId": 137, "rpc": []}) == []

    def test_missing_rpc_field_returns_empty(self):
        assert _filter_candidates({"chainId": 137}) == []


# ---------------------------------------------------------------------------
# get_web3 — full failover behavior
# ---------------------------------------------------------------------------


class TestGetWeb3:
    def test_unknown_chain_dies(self):
        with pytest.raises(SystemExit):
            get_web3(99999)

    def test_user_override_exclusive_when_set(self):
        """User config override is used exclusively — no fallback to primary."""
        mock_w3 = MagicMock()
        mock_w3.eth.chain_id = 137

        with patch("regard.core.project_state.load_project_env",
                   return_value={"POLYGON_RPC": "https://my-private-rpc.example.com"}), \
             patch("regard.core.rpc_pool._try_endpoint", return_value=mock_w3) as mock_try:
            result = get_web3(137)
            assert result is mock_w3
            # Only the override URL was tried; primary not even attempted.
            assert mock_try.call_count == 1
            assert mock_try.call_args[0][0] == "https://my-private-rpc.example.com"

    def test_user_override_unreachable_dies(self):
        """If user override fails chainId verification, die — no fallback."""
        with patch("regard.core.project_state.load_project_env",
                   return_value={"POLYGON_RPC": "https://broken.example.com"}), \
             patch("regard.core.rpc_pool._try_endpoint", return_value=None):
            with pytest.raises(SystemExit):
                get_web3(137)

    def test_primary_success_no_failover_fetch(self):
        """If primary works, chainlist is never fetched."""
        mock_w3 = MagicMock()
        mock_w3.eth.chain_id = 137

        def _try(url, expected):
            if url == PRIMARY_RPC[137]:
                return mock_w3
            return None

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.rpc_pool._try_endpoint", side_effect=_try), \
             patch("regard.core.rpc_pool._fetch_chainlist_cached") as mock_fetch:
            result = get_web3(137)
            assert result is mock_w3
            mock_fetch.assert_not_called()

    def test_primary_fails_then_failover_succeeds(self):
        """Primary down → chainlist filtered candidates → first responsive wins."""
        mock_w3 = MagicMock()
        mock_w3.eth.chain_id = 137

        def _try(url, expected):
            if url == "https://polygon.drpc.org":
                return mock_w3
            return None  # primary + others fail

        chainlist_data = [
            {"chainId": 137, "rpc": [
                {"url": "https://polygon-mainnet.g.alchemy.com/v2/demo"},  # filtered out
                {"url": "https://polygon.drpc.org"},                       # ✓
                {"url": "https://1rpc.io/matic"},                          # ✓
            ]},
        ]

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.rpc_pool._try_endpoint", side_effect=_try), \
             patch("regard.core.rpc_pool._fetch_chainlist_cached", return_value=chainlist_data):
            result = get_web3(137)
            assert result is mock_w3

    def test_all_fail_dies_with_rpc_unavailable(self):
        """Primary fails AND all chainlist candidates fail → die."""
        chainlist_data = [
            {"chainId": 137, "rpc": [{"url": "https://polygon.drpc.org"}]},
        ]
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.rpc_pool._try_endpoint", return_value=None), \
             patch("regard.core.rpc_pool._fetch_chainlist_cached", return_value=chainlist_data):
            with pytest.raises(SystemExit):
                get_web3(137)

    def test_chainlist_unreachable_no_cache_dies(self):
        """Primary fails, chainlist returns None (no cache, fetch failed) → die."""
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.rpc_pool._try_endpoint", return_value=None), \
             patch("regard.core.rpc_pool._fetch_chainlist_cached", return_value=None):
            with pytest.raises(SystemExit):
                get_web3(137)

    def test_chainlist_missing_chain_entry_dies(self):
        """Primary fails AND chainlist has no entry for our chainId → die."""
        chainlist_data = [{"chainId": 999999, "rpc": []}]
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.rpc_pool._try_endpoint", return_value=None), \
             patch("regard.core.rpc_pool._fetch_chainlist_cached", return_value=chainlist_data):
            with pytest.raises(SystemExit):
                get_web3(137)

    def test_chainid_mismatch_skips_endpoint(self):
        """An endpoint reporting wrong chainId is silently skipped (returns None
        from _try_endpoint), failover continues to the next."""
        # _try_endpoint returns None on chainId mismatch — already tested in
        # the "all_fail" path. This is a structural assertion that the pool
        # uses _try_endpoint's return value correctly.
        chainlist_data = [
            {"chainId": 137, "rpc": [
                {"url": "https://polygon.drpc.org"},
                {"url": "https://1rpc.io/matic"},
            ]},
        ]
        # All endpoints fail (simulating either unreachable or chainId-mismatch)
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.rpc_pool._try_endpoint", return_value=None), \
             patch("regard.core.rpc_pool._fetch_chainlist_cached", return_value=chainlist_data):
            with pytest.raises(SystemExit):
                get_web3(137)


# ---------------------------------------------------------------------------
# Cache behavior (file-system-level)
# ---------------------------------------------------------------------------


class TestChainlistCache:
    def test_cache_hit_skips_network(self, tmp_path):
        """Fresh cache file → no HTTP fetch."""
        import json as json_mod

        cache_dir = tmp_path / ".regard" / "rpc-cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir / "chainlist.json"
        cache_file.write_text(json_mod.dumps([{"chainId": 137, "rpc": []}]))

        with patch("regard.core.project_dir.get_regard_dir", return_value=tmp_path / ".regard"), \
             patch("regard.core.rpc_pool.requests.get") as mock_get:
            from regard.core.rpc_pool import _fetch_chainlist_cached
            data = _fetch_chainlist_cached()
            assert data == [{"chainId": 137, "rpc": []}]
            mock_get.assert_not_called()

    def test_cache_miss_fetches_and_writes(self, tmp_path):
        """No cache → fetch fresh, write to disk."""
        import json as json_mod

        cache_dir = tmp_path / ".regard" / "rpc-cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir / "chainlist.json"

        fresh = [{"chainId": 137, "rpc": [{"url": "https://polygon.drpc.org"}]}]
        mock_resp = MagicMock()
        mock_resp.json.return_value = fresh
        mock_resp.raise_for_status.return_value = None

        with patch("regard.core.project_dir.get_regard_dir", return_value=tmp_path / ".regard"), \
             patch("regard.core.rpc_pool.requests.get", return_value=mock_resp):
            from regard.core.rpc_pool import _fetch_chainlist_cached
            data = _fetch_chainlist_cached()
            assert data == fresh
            assert cache_file.exists()
            assert json_mod.loads(cache_file.read_text()) == fresh

    def test_fetch_fails_falls_back_to_stale_cache(self, tmp_path):
        """Fetch fails AND stale cache exists → use stale (better than nothing)."""
        import json as json_mod
        import time

        cache_dir = tmp_path / ".regard" / "rpc-cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir / "chainlist.json"
        stale = [{"chainId": 137, "rpc": [{"url": "https://stale.example.com"}]}]
        cache_file.write_text(json_mod.dumps(stale))
        # Make the file 30 days old (stale)
        old = time.time() - (30 * 24 * 3600)
        import os
        os.utime(cache_file, (old, old))

        import requests as _requests
        with patch("regard.core.project_dir.get_regard_dir", return_value=tmp_path / ".regard"), \
             patch("regard.core.rpc_pool.requests.get",
                   side_effect=_requests.RequestException("network down")):
            from regard.core.rpc_pool import _fetch_chainlist_cached
            data = _fetch_chainlist_cached()
            assert data == stale  # stale-cache fallback

    def test_fetch_fails_no_cache_returns_none(self, tmp_path):
        """Fetch fails AND no cache → None (caller should die with RPC_UNAVAILABLE)."""
        import requests as _requests

        with patch("regard.core.project_dir.get_regard_dir", return_value=tmp_path / ".regard"), \
             patch("regard.core.rpc_pool.requests.get",
                   side_effect=_requests.RequestException("network down")):
            from regard.core.rpc_pool import _fetch_chainlist_cached
            data = _fetch_chainlist_cached()
            assert data is None
