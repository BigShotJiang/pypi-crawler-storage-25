"""Golden fixture validation — validates recorded API responses against Pydantic models.

Uses extra="forbid" so any new or renamed field from the exchange causes a test
failure, forcing the model to be updated. This is the ratchet: schema drift is
caught here, not in production.

Run `python tests/record_fixtures.py` to refresh fixtures from the real API.
"""

import json
import typing
from pathlib import Path

import pytest
from pydantic import BaseModel, ConfigDict

from regard.venues.hyperliquid.models import (
    ActiveAssetData,
    AssetCtx,
    AssetInfo,
    Candle,
    Fill,
    FrontendOrder,
    FundingEntry,
    L2Snapshot,
    OutcomeMeta,
    PerpDexInfo,
    PerpMetaEntry,
    SpotBalance,
    SpotMeta,
    UserState,
)
from regard.venues.polymarket.models import (
    ClobBalanceAllowance,
    ClobOrder,
    ClobOrderBook,
    ClobTrade,
    DataApiPosition,
    GammaEvent,
    GammaMarket,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def _load(venue: str, name: str):
    return json.loads((FIXTURES_DIR / venue / f"{name}.json").read_text())


def _rewrite_annotation(annotation, _cache):
    """Rewrite a type annotation, replacing BaseModel subclasses with strict versions.

    Handles: direct BaseModel, list[BaseModel], BaseModel | None, Union[BaseModel, ...].
    """
    # Direct BaseModel subclass
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        result = _strict(annotation, _cache)
        return result if result is not None else annotation

    # Generic types: list[X], X | None, Optional[X], Union[X, Y, ...]
    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)
    if not args:
        return annotation

    new_args = tuple(_rewrite_annotation(a, _cache) for a in args)
    if new_args == args:
        return annotation  # nothing changed

    # Reconstruct the generic with strict args
    if origin is list:
        return list[new_args[0]]
    if origin is typing.Union:
        return typing.Union[new_args]  # noqa: UP007 — runtime union construction from dynamic tuple
    # Fallback: return original if we can't reconstruct
    return annotation


def _strict(model_cls, _cache=None):
    """Create a strict subclass that rejects unknown fields — recursively.

    All nested BaseModel fields also get extra="forbid" so unknown fields at
    any depth cause a validation error, not just top-level.
    """
    if _cache is None:
        _cache = {}
    if model_cls in _cache:
        # May be None (placeholder for self-referential models in progress)
        return _cache[model_cls]

    # Reserve cache slot to break self-referential recursion (e.g. FrontendOrder.children)
    _cache[model_cls] = None  # placeholder — replaced at end of function

    # Build strict versions of all nested model fields, unwrapping generics
    strict_annotations = {}
    for field_name, field_info in model_cls.model_fields.items():
        annotation = field_info.annotation
        rewritten = _rewrite_annotation(annotation, _cache)
        if rewritten is not annotation:
            strict_annotations[field_name] = rewritten

    # Create strict subclass
    namespace = {"model_config": ConfigDict(extra="forbid"), "__annotations__": strict_annotations}
    StrictModel = type(f"Strict{model_cls.__name__}", (model_cls,), namespace)
    _cache[model_cls] = StrictModel
    return StrictModel


# Skip all tests if fixtures haven't been recorded yet
pytestmark = pytest.mark.skipif(
    not (FIXTURES_DIR / "hyperliquid" / "all_mids.json").exists(),
    reason="Golden fixtures not recorded — run: python tests/record_fixtures.py",
)


# --- Hyperliquid ---


class TestUserState:
    def test_validates(self):
        data = _load("hyperliquid", "user_state")
        _strict(UserState).model_validate(data)

    def test_has_asset_positions(self):
        data = _load("hyperliquid", "user_state")
        state = UserState.model_validate(data)
        # Real accounts have positions — fixture should capture this
        assert isinstance(state.assetPositions, list)

    def test_margin_summary_present(self):
        data = _load("hyperliquid", "user_state")
        state = UserState.model_validate(data)
        assert state.crossMarginSummary is not None or state.marginSummary is not None


class TestFrontendOrders:
    def test_validates(self):
        data = _load("hyperliquid", "frontend_open_orders")
        Strict = _strict(FrontendOrder)
        for order in data:
            Strict.model_validate(order)

    def test_trigger_fields_always_present(self):
        """Regression: real API returns triggerPx and isTrigger on ALL orders,
        including non-trigger orders where triggerPx is '0.0'."""
        data = _load("hyperliquid", "frontend_open_orders")
        for order in data:
            assert "triggerPx" in order, "triggerPx missing — real API always includes it"
            assert "isTrigger" in order, "isTrigger missing — real API always includes it"

    def test_non_trigger_order_has_triggerPx_zero(self):
        """Regression: non-trigger orders have triggerPx='0.0' (truthy string)."""
        data = _load("hyperliquid", "frontend_open_orders")
        non_triggers = [o for o in data if not o.get("isTrigger")]
        if non_triggers:
            for o in non_triggers:
                assert o["triggerPx"] == "0.0"


class TestMetaAndAssetCtxs:
    def test_meta_validates(self):
        data = _load("hyperliquid", "meta_and_asset_ctxs")
        meta = data[0] if isinstance(data, list) else data
        Strict = _strict(AssetInfo)
        for asset in meta.get("universe", [])[:5]:
            Strict.model_validate(asset)

    def test_asset_ctxs_validate(self):
        data = _load("hyperliquid", "meta_and_asset_ctxs")
        ctxs = data[1] if isinstance(data, list) and len(data) > 1 else []
        Strict = _strict(AssetCtx)
        for ctx in ctxs[:5]:
            Strict.model_validate(ctx)


class TestSpotMeta:
    def test_validates(self):
        data = _load("hyperliquid", "spot_meta")
        _strict(SpotMeta).model_validate(data)


class TestPerpDexs:
    def test_first_is_none(self):
        """perpDexs[0] is None on mainnet (the default dex)."""
        data = _load("hyperliquid", "perp_dexs")
        assert data[0] is None

    def test_non_null_validate(self):
        data = _load("hyperliquid", "perp_dexs")
        Strict = _strict(PerpDexInfo)
        for dex in data:
            if dex is not None:
                Strict.model_validate(dex)


class TestOutcomeMeta:
    """HIP-4 outcomeMeta golden-fixture validation.

    The mainnet response is small at launch (one BTC daily binary, no
    categoricals). When validators add markets, the fixture grows; the
    extra="forbid" gate catches new fields immediately so the model stays
    in sync with reality.
    """

    def test_validates_strict(self):
        data = _load("hyperliquid", "outcome_meta")
        _strict(OutcomeMeta).model_validate(data)

    def test_envelope_shape(self):
        # Sanity: response has the two top-level keys we depend on.
        data = _load("hyperliquid", "outcome_meta")
        assert "outcomes" in data
        assert "questions" in data
        assert isinstance(data["outcomes"], list)
        assert isinstance(data["questions"], list)

    def test_outcome_entries_have_expected_fields(self):
        data = _load("hyperliquid", "outcome_meta")
        meta = OutcomeMeta.model_validate(data)
        # At least the BTC daily binary should be present at all times.
        assert len(meta.outcomes) >= 1
        for outcome in meta.outcomes:
            assert outcome.outcome >= 0
            assert outcome.name
            # Binary outcomes have exactly 2 sideSpecs; categoricals can have more.
            assert len(outcome.sideSpecs) >= 2

    def test_binary_outcome_yes_no_naming(self):
        # Brief §3: side 0 = YES, side 1 = NO. The API names them as such.
        data = _load("hyperliquid", "outcome_meta")
        meta = OutcomeMeta.model_validate(data)
        binary = [o for o in meta.outcomes if len(o.sideSpecs) == 2]
        if binary:  # only assert if any binary present (always true at launch)
            sample = binary[0]
            # Names are human-readable but follow YES/NO convention
            assert sample.sideSpecs[0].name in ("Yes", "YES", "yes")
            assert sample.sideSpecs[1].name in ("No", "NO", "no")


class TestAllPerpMetas:
    def test_validates(self):
        data = _load("hyperliquid", "all_perp_metas")
        Strict = _strict(PerpMetaEntry)
        for meta in data[:3]:
            Strict.model_validate(meta)


class TestL2Snapshot:
    def test_validates(self):
        data = _load("hyperliquid", "l2_snapshot")
        _strict(L2Snapshot).model_validate(data)


class TestFundingHistory:
    def test_validates(self):
        data = _load("hyperliquid", "funding_history")
        Strict = _strict(FundingEntry)
        for entry in data[:5]:
            Strict.model_validate(entry)


class TestCandles:
    def test_validates(self):
        data = _load("hyperliquid", "candles")
        Strict = _strict(Candle)
        for candle in data[:5]:
            Strict.model_validate(candle)


class TestFills:
    def test_validates(self):
        data = _load("hyperliquid", "user_fills")
        Strict = _strict(Fill)
        for fill in data[:5]:
            Strict.model_validate(fill)


class TestSpotBalance:
    def test_validates(self):
        data = _load("hyperliquid", "spot_user_state")
        Strict = _strict(SpotBalance)
        for bal in data.get("balances", [])[:5]:
            Strict.model_validate(bal)


class TestActiveAssetData:
    def test_validates(self):
        data = _load("hyperliquid", "active_asset_data")
        _strict(ActiveAssetData).model_validate(data)


class TestXyzMeta:
    """HIP-3 dex-scoped metaAndAssetCtxs — may have extra fields like growthMode."""

    @pytest.mark.skipif(
        not (FIXTURES_DIR / "hyperliquid" / "meta_and_asset_ctxs_xyz.json").exists(),
        reason="xyz dex fixture not recorded",
    )
    def test_validates(self):
        data = _load("hyperliquid", "meta_and_asset_ctxs_xyz")
        meta = data[0] if isinstance(data, list) else data
        Strict = _strict(AssetInfo)
        for asset in meta.get("universe", [])[:5]:
            Strict.model_validate(asset)


class TestPerpAnnotations:
    """perpConciseAnnotations returns [[asset_name, {category: str}], ...]."""

    def test_is_list_of_pairs(self):
        data = _load("hyperliquid", "perp_annotations")
        assert isinstance(data, list)
        assert len(data) > 0, "annotations fixture is empty"
        # Each entry is [asset_name, annotation_dict]
        for entry in data[:5]:
            assert isinstance(entry, list) and len(entry) == 2
            assert isinstance(entry[0], str)
            assert isinstance(entry[1], dict)


class TestAllMids:
    def test_is_dict_of_string_prices(self):
        data = _load("hyperliquid", "all_mids")
        assert isinstance(data, dict)
        assert len(data) > 0
        for coin, price in list(data.items())[:5]:
            assert isinstance(coin, str)
            assert isinstance(price, str)
            float(price)  # must be parseable as float


# --- Polymarket ---

# Poly models intentionally use extra="ignore" for the ~60 Gamma fields we
# don't access. Golden tests validate that modeled fields parse correctly
# and that key fields exist in the real response. We don't use _strict()
# here because the Gamma API has far more fields than we model.

_poly_skip = pytest.mark.skipif(
    not (FIXTURES_DIR / "polymarket" / "gamma_markets.json").exists(),
    reason="Poly golden fixtures not recorded — run: python tests/record_fixtures.py",
)


@_poly_skip
class TestGammaMarket:
    def test_modeled_fields_parse(self):
        """All modeled fields parse without error (extra="ignore" drops the rest)."""
        data = _load("polymarket", "gamma_markets")
        for m in data:
            GammaMarket.model_validate(m)

    def test_key_fields_present(self):
        """Key fields that our code accesses exist in real response."""
        data = _load("polymarket", "gamma_markets")
        for m in data:
            assert "clobTokenIds" in m
            assert "outcomePrices" in m
            assert "conditionId" in m
            assert "question" in m
            assert "acceptingOrders" in m
            assert "negRisk" in m

    def test_clobTokenIds_parseable(self):
        """clobTokenIds decodes to a list whether it arrives as JSON string or native list."""
        data = _load("polymarket", "gamma_markets")
        import json as _json
        for m in data:
            raw = m.get("clobTokenIds")
            if isinstance(raw, str):
                parsed = _json.loads(raw)
            elif isinstance(raw, list):
                parsed = raw
            else:
                pytest.fail(f"clobTokenIds is neither str nor list: {type(raw)}")
            assert isinstance(parsed, list)
            assert len(parsed) >= 2, "Expected at least yes + no token IDs"

    def test_single_market_shape(self):
        """Single market endpoint returns same shape as list endpoint."""
        if not (FIXTURES_DIR / "polymarket" / "gamma_market_single.json").exists():
            pytest.skip("single market fixture not recorded")
        data = _load("polymarket", "gamma_market_single")
        GammaMarket.model_validate(data)
        assert "conditionId" in data
        assert "question" in data


@_poly_skip
class TestGammaEvent:
    def test_modeled_fields_parse(self):
        data = _load("polymarket", "gamma_events")
        for e in data:
            GammaEvent.model_validate(e)

    def test_has_markets(self):
        data = _load("polymarket", "gamma_events")
        for e in data:
            assert "markets" in e
            assert isinstance(e["markets"], list)
            assert len(e["markets"]) > 0, "Event should have at least one market"

    def test_nested_markets_parse(self):
        """Markets nested inside events parse as GammaMarket."""
        data = _load("polymarket", "gamma_events")
        for e in data:
            for m in e.get("markets", [])[:3]:
                GammaMarket.model_validate(m)


# --- Polymarket: CLOB + Data API ---
# These use _strict() — our models should match the full response shape.
# Run `python tests/record_fixtures.py --poly-clob` to record (needs auth + VPN).

_clob_skip = pytest.mark.skipif(
    not (FIXTURES_DIR / "polymarket" / "data_api_positions.json").exists(),
    reason="CLOB fixtures not recorded — run: python tests/record_fixtures.py --poly-clob",
)


@_clob_skip
class TestDataApiPositions:
    def test_strict_validates(self):
        data = _load("polymarket", "data_api_positions")
        Strict = _strict(DataApiPosition)
        for p in data:
            Strict.model_validate(p)

    def test_key_fields_present(self):
        """Fields that get_positions() reads from the response."""
        data = _load("polymarket", "data_api_positions")
        for p in data:
            assert "asset" in p
            assert "size" in p
            assert "conditionId" in p
            assert "outcome" in p
            assert "redeemable" in p
            assert "mergeable" in p

    def test_addresses_sanitized(self):
        """No real wallet addresses in fixture."""
        data = _load("polymarket", "data_api_positions")
        raw = json.dumps(data).lower()
        assert "0xf373b4a2" not in raw, "Wallet 1 address leaked"
        assert "0x3710f20c" not in raw, "Wallet 2 address leaked"


@_clob_skip
class TestClobBalanceAllowance:
    def test_strict_validates(self):
        data = _load("polymarket", "clob_balance_allowance")
        _strict(ClobBalanceAllowance).model_validate(data)

    def test_balance_is_string(self):
        data = _load("polymarket", "clob_balance_allowance")
        assert isinstance(data.get("balance"), str)


@_clob_skip
class TestClobOpenOrders:
    def test_strict_validates(self):
        data = _load("polymarket", "clob_open_orders")
        Strict = _strict(ClobOrder)
        for o in data:
            Strict.model_validate(o)

    def test_key_fields_present(self):
        data = _load("polymarket", "clob_open_orders")
        for o in data:
            assert "id" in o
            assert "asset_id" in o
            assert "side" in o
            assert "price" in o
            assert "status" in o

    def test_addresses_sanitized(self):
        data = _load("polymarket", "clob_open_orders")
        raw = json.dumps(data).lower()
        assert "0xf373b4a2" not in raw


@_clob_skip
class TestClobTrades:
    def test_strict_validates(self):
        data = _load("polymarket", "clob_trades")
        if not data:
            pytest.skip("No trades in fixture")
        Strict = _strict(ClobTrade)
        for t in data:
            Strict.model_validate(t)

    def test_sanitized(self):
        """No real addresses, UUIDs, or tx hashes in fixture."""
        data = _load("polymarket", "clob_trades")
        if not data:
            pytest.skip("No trades in fixture")
        for t in data:
            assert t.get("owner", "").startswith("fixture-"), f"owner not sanitized: {t.get('owner')}"
            assert t.get("id", "").startswith("fixture_trade_"), f"id not sanitized: {t.get('id')}"
            assert t.get("taker_order_id", "").startswith("0x"), "taker_order_id missing"
            for m in t.get("maker_orders", []):
                assert "FIXTURE_MAKER" in m.get("maker_address", ""), f"maker_address not sanitized: {m.get('maker_address')}"
                assert m.get("owner", "").startswith("fixture-maker-"), f"maker owner not sanitized: {m.get('owner')}"


@_clob_skip
class TestClobOrderBook:
    def test_strict_validates(self):
        data = _load("polymarket", "clob_order_book")
        _strict(ClobOrderBook).model_validate(data)

    def test_has_bids_and_asks(self):
        data = _load("polymarket", "clob_order_book")
        assert "bids" in data
        assert "asks" in data
        assert isinstance(data["bids"], list)
        assert isinstance(data["asks"], list)
