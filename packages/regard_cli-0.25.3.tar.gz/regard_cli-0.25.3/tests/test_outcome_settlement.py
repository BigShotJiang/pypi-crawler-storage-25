"""Tests for SettlementWatcher — HIP-4 outcome settlement detection.

Pure-logic tests against synthetic poll sequences. The watcher's I/O loop
in commands/watch.py is covered separately in test_watch.py.

Coverage paths:
- Settled (won) — outcome disappears, USDH delta ≈ size held
- Settled (lost) — outcome disappears, USDH delta ≈ 0
- Sale (Cycle D) — balance clears while outcome stays in meta → no event
- Cold start — first poll never emits (no prior state)
- Multi-outcome — separate tracking per outcome_id
- USDH unobservable — payout reports "unknown"
"""

from regard.venues.hyperliquid.outcome_settlement import (
    SettlementWatcher,
    _classify_settlement,
)


def _meta_entry(outcome: int, *, expiry: str = "20260505-0600", target_price: str = "80000") -> dict:
    """Build a synthetic outcomeMeta record matching resolver.get_outcomes() shape."""
    return {
        "outcome": outcome,
        "name": "Recurring",
        "description": f"class:priceBinary|underlying:BTC|expiry:{expiry}|targetPrice:{target_price}|period:1d",
        "parsed_description": {
            "class": "priceBinary",
            "underlying": "BTC",
            "expiry": expiry,
            "target_price": target_price,
            "period": "1d",
        },
        "sides": [
            {"side": 0, "name": "Yes", "coin": f"#{outcome*10}", "balance_coin": f"+{outcome*10}", "asset_id": 100_000_000 + outcome*10},
            {"side": 1, "name": "No", "coin": f"#{outcome*10+1}", "balance_coin": f"+{outcome*10+1}", "asset_id": 100_000_001 + outcome*10},
        ],
    }


def _balance_outcome(outcome: int, side: int, size: str) -> dict:
    """Build a synthetic +<enc> spot balance row matching get_spot_balances output."""
    return {
        "coin": f"+{outcome*10 + side}",
        "balance": size,
        "token_index": None,
        "kind": "outcome",
        "outcome": outcome,
        "side": side,
        "side_name": "yes" if side == 0 else "no",
    }


def _balance_usdh(amount: str) -> dict:
    return {"coin": "USDH", "balance": amount, "token_index": 360, "kind": "spot", "token": "USDH"}


# ---------------------------------------------------------------------------
# Settlement detection paths
# ---------------------------------------------------------------------------


def test_settles_won_when_outcome_disappears_with_full_payout():
    """Held YES position 21 contracts → outcome removed → USDH +21 → won."""
    w = SettlementWatcher()
    # Tick 1: position visible, outcome 2 in meta.
    events = w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_outcome(2, 0, "21"), _balance_usdh("3.62")],
        now_iso="2026-05-04T05:59:00Z",
    )
    assert events == []  # silent on first tracking

    # Tick 2: outcome gone, USDH credited ≈ 21.
    events = w.poll(
        outcomes_meta=[],  # outcome 2 removed by validators
        spot_balances=[_balance_usdh("24.62")],  # +21 credit
        now_iso="2026-05-04T06:00:30Z",
    )
    assert len(events) == 1
    e = events[0]
    assert e["event"] == "outcome_settled"
    assert e["outcome"] == 2
    assert e["side_held"] == "yes"
    assert e["size"] == "21"
    assert e["payout_usdh"] == "21.00"
    assert e["implied_winning_side"] == "held"
    assert e["settled_at"] == "2026-05-04T06:00:30Z"
    assert e["expiry"] == "20260505-0600"


def test_settles_lost_when_outcome_disappears_with_zero_payout():
    """Held NO position 15 contracts → outcome removed → USDH +0 → lost."""
    w = SettlementWatcher()
    w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_outcome(2, 1, "15"), _balance_usdh("10.0")],
        now_iso="2026-05-04T05:59:00Z",
    )
    events = w.poll(
        outcomes_meta=[],
        spot_balances=[_balance_usdh("10.0")],
        now_iso="2026-05-04T06:00:30Z",
    )
    assert len(events) == 1
    e = events[0]
    assert e["payout_usdh"] == "0.0"
    assert e["implied_winning_side"] == "opposite"
    assert e["side_held"] == "no"


def test_sale_does_not_emit_settlement():
    """Cycle D pattern: position closed via sell while outcome still active.
    Watcher MUST NOT emit a settlement event."""
    w = SettlementWatcher()
    w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_outcome(2, 0, "21"), _balance_usdh("3.62")],
        now_iso="2026-05-04T07:00:00Z",
    )
    # Sale: balance row disappears, USDH up, outcome STILL in meta.
    events = w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_usdh("13.97")],
        now_iso="2026-05-04T07:05:00Z",
    )
    assert events == []


def test_cold_start_first_poll_silent():
    """A fresh watcher's first tick takes inventory; never emits.
    Prevents spurious 'settled' events on watcher restart."""
    w = SettlementWatcher()
    events = w.poll(
        outcomes_meta=[_meta_entry(2)],
        spot_balances=[_balance_outcome(2, 0, "21"), _balance_usdh("3.62")],
        now_iso="2026-05-04T08:00:00Z",
    )
    assert events == []


def test_no_holdings_emits_nothing():
    """Wallet with no outcome positions never emits."""
    w = SettlementWatcher()
    for _ in range(3):
        events = w.poll(
            outcomes_meta=[_meta_entry(2)],
            spot_balances=[_balance_usdh("10.0")],
            now_iso="2026-05-04T08:00:00Z",
        )
        assert events == []


def test_multi_outcome_separate_tracking():
    """Holding two different outcomes: one settles, the other stays active.
    Only the settled one emits."""
    w = SettlementWatcher()
    w.poll(
        outcomes_meta=[_meta_entry(2), _meta_entry(3)],
        spot_balances=[
            _balance_outcome(2, 0, "21"),
            _balance_outcome(3, 1, "15"),
            _balance_usdh("5.0"),
        ],
        now_iso="2026-05-04T08:00:00Z",
    )
    events = w.poll(
        outcomes_meta=[_meta_entry(3)],  # only #2 settled
        spot_balances=[
            _balance_outcome(3, 1, "15"),
            _balance_usdh("26.0"),  # +21 credit from #2
        ],
        now_iso="2026-05-04T08:05:00Z",
    )
    assert len(events) == 1
    assert events[0]["outcome"] == 2


def test_payout_unknown_when_usdh_unobservable():
    """If we transition straight from cold-start to settlement (no prior
    USDH observation), payout reports 'unknown'."""
    w = SettlementWatcher()
    # Manually seed tracking without a prior USDH observation.
    w._tracked[2] = {
        "side": 0, "side_name": "yes", "size": "21",
        "name": "Recurring", "expiry": "20260505-0600", "target_price": "80000",
    }
    # _prev_usdh stays None.
    events = w.poll(
        outcomes_meta=[],
        spot_balances=[_balance_usdh("10.0")],
        now_iso="2026-05-04T09:00:00Z",
    )
    assert len(events) == 1
    assert events[0]["payout_usdh"] == "unknown"
    assert events[0]["implied_winning_side"] == "unknown"


# ---------------------------------------------------------------------------
# _classify_settlement helper
# ---------------------------------------------------------------------------


def test_classify_held_won_full_payout():
    from decimal import Decimal
    payout, winner = _classify_settlement("21", Decimal("3"), Decimal("24"))
    assert payout == "21"
    assert winner == "held"


def test_classify_held_lost_zero_payout():
    from decimal import Decimal
    payout, winner = _classify_settlement("21", Decimal("3"), Decimal("3"))
    assert payout == "0"
    assert winner == "opposite"


def test_classify_first_poll_unknown():
    payout, winner = _classify_settlement("21", None, None)
    assert payout == "unknown"
    assert winner == "unknown"


def test_classify_negative_delta_does_not_infer_winner():
    """USDH went down across the window — likely an unrelated outflow.
    Payout reports the negative delta but winner stays unknown."""
    from decimal import Decimal
    payout, winner = _classify_settlement("21", Decimal("10"), Decimal("9"))
    assert payout.startswith("-")
    assert winner == "unknown"


def test_classify_partial_payout_at_threshold():
    """Payout >= 50% of size counts as held-won (covers fee haircut /
    multi-position aggregation drift)."""
    from decimal import Decimal
    payout, winner = _classify_settlement("20", Decimal("0"), Decimal("10"))
    assert winner == "held"
    payout, winner = _classify_settlement("20", Decimal("0"), Decimal("9"))
    assert winner == "opposite"


# ---------------------------------------------------------------------------
# count_held_outcomes_near_expiry — tilt indicator helper
# ---------------------------------------------------------------------------


def test_near_expiry_counts_within_threshold():
    """Held outcome expiring 30 min from now → counts at 60 min threshold."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)  # 30 min before 06:00 expiry
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 1


def test_near_expiry_excludes_far_outcomes():
    """Held outcome expiring 90 min from now is NOT near at 60 min threshold."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 4, 30, tzinfo=timezone.utc)  # 90 min before 06:00
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 0


def test_near_expiry_excludes_past_expiry():
    """Already-expired outcome counts as 0 — past the actionable window."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 6, 30, tzinfo=timezone.utc)  # 30 min after expiry
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 0


def test_near_expiry_zero_threshold_returns_zero():
    """`threshold_minutes` ≤ 0 disables detection."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
    assert count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=0,
        now_utc=now,
    ) == 0


def test_near_expiry_multi_position():
    """Holding two outcomes; one near, one far → count = 1."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
    count = count_held_outcomes_near_expiry(
        spot_balances=[
            _balance_outcome(2, 0, "21"),  # near (06:00)
            _balance_outcome(3, 1, "15"),  # far (next day)
        ],
        outcomes_meta=[
            _meta_entry(2, expiry="20260505-0600"),
            _meta_entry(3, expiry="20260506-0600"),
        ],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 1


def test_near_expiry_outcome_not_in_meta_skipped():
    """Held outcome with no matching record in outcomeMeta — skip silently
    (the resolver lazy-load might be stale; safer to under-count than over-)."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "21")],
        outcomes_meta=[],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 0


def test_near_expiry_zero_balance_not_counted():
    """Dust row at balance 0 is ignored — defensive against stale spot rows."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcome_settlement import (
        count_held_outcomes_near_expiry,
    )
    now = datetime(2026, 5, 5, 5, 30, tzinfo=timezone.utc)
    count = count_held_outcomes_near_expiry(
        spot_balances=[_balance_outcome(2, 0, "0")],
        outcomes_meta=[_meta_entry(2, expiry="20260505-0600")],
        threshold_minutes=60,
        now_utc=now,
    )
    assert count == 0


def test_parse_expiry_canonical():
    """`20260505-0600` parses to UTC datetime."""
    from datetime import datetime, timezone

    from regard.venues.hyperliquid.outcomes import parse_expiry
    assert parse_expiry("20260505-0600") == datetime(2026, 5, 5, 6, 0, tzinfo=timezone.utc)


def test_parse_expiry_invalid_returns_none():
    from regard.venues.hyperliquid.outcomes import parse_expiry
    assert parse_expiry(None) is None
    assert parse_expiry("") is None
    assert parse_expiry("garbage") is None
    assert parse_expiry("2026-05-05") is None  # wrong shape
    assert parse_expiry("20260505-99") is None  # wrong length
    assert parse_expiry("20260505-9999") is None  # invalid HHMM


# ---------------------------------------------------------------------------
# v0.23.3 peer-review regression tests
# ---------------------------------------------------------------------------


class TestResolverForceReloadFailureRegression:
    """RESOLVE-FALSE-SETTLE — Critical (peer-review v0.23.3 ratchet).

    `_load_outcomes(force=True)` previously cleared `_outcomes` and
    `_outcomes_by_id` BEFORE the network call. On any transient HL API
    failure during a watcher's force-reload, the resolver was left with
    empty outcomes meta — and the SettlementWatcher would then read
    `current_outcome_ids = set()`, see every tracked outcome as missing,
    and fire false `outcome_settled` events for the whole portfolio.
    The fix defers `clear()` until after a successful network + Pydantic
    validation. These tests pin the recovery shape.
    """

    def test_force_reload_preserves_state_when_network_fails(self):
        """Force-reload that hits a network exception MUST keep the prior
        outcomes intact (caller falls through to stale-but-correct data)."""
        from unittest.mock import MagicMock

        from regard.venues.hyperliquid.resolver import Resolver

        info = MagicMock()
        info.coin_to_asset = {}
        info.name_to_coin = {}
        # First load — succeeds.
        info.post.return_value = {
            "outcomes": [
                {"outcome": 7, "name": "Recurring",
                 "description": "class:priceBinary|underlying:BTC|expiry:20260505-0600|targetPrice:80000|period:1d",
                 "sideSpecs": [{"name": "Yes"}, {"name": "No"}]}
            ],
            "questions": [],
        }
        resolver = Resolver(info)
        first = resolver.get_outcomes()
        assert len(first) == 1 and first[0]["outcome"] == 7

        # Force reload — network blows up.
        info.post.side_effect = Exception("transient HL API failure")
        second = resolver.get_outcomes(force_reload=True)
        # State preserved — caller still sees outcome 7.
        assert len(second) == 1 and second[0]["outcome"] == 7

    def test_force_reload_preserves_state_when_pydantic_fails(self):
        """Same protection when validation fails on a malformed response."""
        from unittest.mock import MagicMock

        from regard.venues.hyperliquid.resolver import Resolver

        info = MagicMock()
        info.coin_to_asset = {}
        info.name_to_coin = {}
        info.post.return_value = {
            "outcomes": [
                {"outcome": 7, "name": "Recurring",
                 "description": "class:priceBinary|underlying:BTC|expiry:20260505-0600|targetPrice:80000|period:1d",
                 "sideSpecs": [{"name": "Yes"}, {"name": "No"}]}
            ],
            "questions": [],
        }
        resolver = Resolver(info)
        resolver.get_outcomes()
        # Force reload returns garbage that won't validate.
        info.post.return_value = {"unexpected": "shape"}
        second = resolver.get_outcomes(force_reload=True)
        assert len(second) == 1 and second[0]["outcome"] == 7

    def test_watcher_does_not_emit_false_settle_on_resolver_failure(self):
        """End-to-end: SettlementWatcher fed by a resolver whose
        force-reload silently failed must NOT classify the still-held
        outcome as settled. This is the live failure mode the v0.23.3
        ratchet was filed for."""
        w = SettlementWatcher()
        # Tick 1 — observe held position.
        w.poll(
            outcomes_meta=[_meta_entry(7)],
            spot_balances=[_balance_outcome(7, 0, "21"), _balance_usdh("5.0")],
            now_iso="2026-05-04T08:00:00Z",
        )
        # Tick 2 — resolver returned its PRESERVED last-good outcomes
        # (exactly what the fixed _load_outcomes does on transient
        # failure). Because the outcome is still in current_outcome_ids,
        # the watcher must NOT emit.
        events = w.poll(
            outcomes_meta=[_meta_entry(7)],  # same as tick 1
            spot_balances=[_balance_outcome(7, 0, "21"), _balance_usdh("5.0")],
            now_iso="2026-05-04T08:05:00Z",
        )
        assert events == []


class TestSimultaneousSettlement:
    """SIMULT-CLASSIFY — Important (peer-review v0.23.3 ratchet).

    When >1 outcome settles in the same poll, the wallet-level USDH delta
    cannot be attributed to individual outcomes. `_classify_settlement`
    used to apply the per-outcome heuristic to each, mis-tagging a loser
    as `held` because the winner's payout dominated the wallet delta.
    Fix: when len(to_settle) > 1, set implied_winning_side = "unknown"
    for all simultaneous events.
    """

    def test_simultaneous_settle_marks_winner_unknown(self):
        """Two outcomes settle in the same poll, one wins (50 contracts)
        and one loses (30 contracts). USDH delta = +50. Pre-fix, the loser
        was mis-classified as `held` because 50 ≥ 30*0.5. Post-fix, both
        events report `implied_winning_side = "unknown"`."""
        w = SettlementWatcher()
        w.poll(
            outcomes_meta=[_meta_entry(1), _meta_entry(2)],
            spot_balances=[
                _balance_outcome(1, 0, "50"),  # YES, will win
                _balance_outcome(2, 1, "30"),  # NO, will lose
                _balance_usdh("100.0"),
            ],
            now_iso="2026-05-04T08:00:00Z",
        )
        events = w.poll(
            outcomes_meta=[],  # both settled simultaneously
            spot_balances=[_balance_usdh("150.0")],  # +50 from outcome 1 only
            now_iso="2026-05-04T08:05:00Z",
        )
        assert len(events) == 2
        for e in events:
            assert e["implied_winning_side"] == "unknown", e
        # `payout_usdh` reports the wallet-level delta (still useful as a
        # bound), not per-outcome attribution.
        assert events[0]["payout_usdh"] == "50.0"
        assert events[1]["payout_usdh"] == "50.0"

    def test_single_settle_still_classifies_normally(self):
        """The fix only triggers when len(to_settle) > 1. Single
        settlements continue to use _classify_settlement's heuristic."""
        w = SettlementWatcher()
        w.poll(
            outcomes_meta=[_meta_entry(1)],
            spot_balances=[_balance_outcome(1, 0, "50"), _balance_usdh("100.0")],
            now_iso="2026-05-04T08:00:00Z",
        )
        events = w.poll(
            outcomes_meta=[],
            spot_balances=[_balance_usdh("150.0")],
            now_iso="2026-05-04T08:05:00Z",
        )
        assert len(events) == 1
        assert events[0]["implied_winning_side"] == "held"
