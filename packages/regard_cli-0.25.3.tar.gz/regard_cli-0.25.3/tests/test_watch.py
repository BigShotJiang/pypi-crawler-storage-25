"""Tests for regard watch — REST-polling watchers that emit JSONL alerts.

Tests use --once mode to exercise poll logic without the loop scaffold.
Debounce state is tested by calling poll() directly through the module.
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from regard.commands.watch import _emit, watch_app
from regard.main import app


@pytest.fixture
def runner():
    return CliRunner()


def _parse_jsonl(stdout: str) -> list[dict]:
    """Parse stdout into a list of JSON events. Skips empty lines."""
    return [json.loads(line) for line in stdout.strip().splitlines() if line.strip()]


# ---------------------------------------------------------------------------
# liquidation
# ---------------------------------------------------------------------------


def _patch_liquidation(positions, mids):
    patches = [
        patch("regard.commands.watch.get_info", return_value=MagicMock()),
        patch("regard.commands.watch.get_address", return_value="0xTEST"),
        patch("regard.commands.watch.get_all_positions", return_value=positions),
        patch("regard.commands.watch.get_all_mids", return_value=mids),
    ]
    return patches


def test_liquidation_fires_for_long_near_liq(runner):
    # Long BTC at mark 100, liq 95 → proximity = 5% → alert at threshold 10%
    positions = [{"coin": "BTC", "szi": "0.1", "liquidationPx": "95.00"}]
    mids = {"BTC": "100.00"}
    patches = _patch_liquidation(positions, mids)
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "liquidation_warning"
        assert e["asset"] == "BTC"
        assert e["side"] == "long"
        assert e["proximity_pct"] == 5.0
        assert e["threshold_pct"] == 10.0
    finally:
        for p in patches:
            p.stop()


def test_liquidation_fires_for_short_near_liq(runner):
    # Short ETH at mark 100, liq 108 → proximity = 8% → alert at threshold 10%
    positions = [{"coin": "ETH", "szi": "-1.0", "liquidationPx": "108.00"}]
    mids = {"ETH": "100.00"}
    patches = _patch_liquidation(positions, mids)
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        assert events[0]["side"] == "short"
        assert events[0]["proximity_pct"] == 8.0
    finally:
        for p in patches:
            p.stop()


def test_liquidation_silent_when_safe(runner):
    # Long BTC at mark 100, liq 50 → proximity 50% → safe under 10% threshold
    positions = [{"coin": "BTC", "szi": "0.1", "liquidationPx": "50.00"}]
    mids = {"BTC": "100.00"}
    patches = _patch_liquidation(positions, mids)
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""
    finally:
        for p in patches:
            p.stop()


def test_liquidation_silent_when_no_positions(runner):
    patches = _patch_liquidation([], {})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""
    finally:
        for p in patches:
            p.stop()


def test_liquidation_skips_positions_without_liq_price(runner):
    # Zero liquidationPx (can happen with cross-margin zero-isolation) should be skipped.
    positions = [{"coin": "BTC", "szi": "0.1", "liquidationPx": ""}]
    mids = {"BTC": "100.00"}
    patches = _patch_liquidation(positions, mids)
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "liquidation", "--proximity-pct", "10", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""
    finally:
        for p in patches:
            p.stop()


# ---------------------------------------------------------------------------
# price
# ---------------------------------------------------------------------------


def _patch_price(mids):
    patches = [
        patch("regard.commands.watch.get_info", return_value=MagicMock()),
        patch("regard.commands.watch.get_all_mids", return_value=mids),
    ]
    return patches


def test_price_fires_above(runner):
    patches = _patch_price({"BTC": "96000.0"})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "BTC", "--above", "95000", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "price_cross"
        assert e["direction"] == "above"
        assert e["price"] == 96000.0
        assert e["threshold"] == 95000.0
    finally:
        for p in patches:
            p.stop()


def test_price_fires_below(runner):
    patches = _patch_price({"BTC": "79000.0"})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "BTC", "--below", "80000", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert events[0]["direction"] == "below"
    finally:
        for p in patches:
            p.stop()


def test_price_validation_no_thresholds(runner):
    result = runner.invoke(app, ["watch", "price", "BTC", "--once"])
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "MISSING_THRESHOLD"


def test_price_validation_invalid_range(runner):
    result = runner.invoke(app, ["watch", "price", "BTC", "--above", "100", "--below", "200", "--once"])
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "INVALID_RANGE"


def test_price_asset_not_found_raises(runner):
    patches = _patch_price({"BTC": "96000.0"})  # no UNKNOWN
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "UNKNOWN", "--above", "1", "--once"])
        # poll() raises; --once doesn't catch, so Typer's exception handler fires
        assert result.exit_code != 0
    finally:
        for p in patches:
            p.stop()


# ---------------------------------------------------------------------------
# funding
# ---------------------------------------------------------------------------


def _make_info_with_funding(funding_rate: str):
    info = MagicMock()
    info.meta_and_asset_ctxs.return_value = [
        {"universe": [{"name": "BTC"}]},
        [{"funding": funding_rate, "markPx": "100"}],
    ]
    return info


def test_funding_fires_spike(runner):
    info = _make_info_with_funding("0.001")  # 0.1%/hr, way above 0.01% threshold
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.01", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        e = events[0]
        assert e["event"] == "funding_spike"
        assert e["asset"] == "BTC"
        assert e["hourly_pct"] == 0.1
        assert e["direction"] == "long_pays"


def test_funding_fires_negative_spike(runner):
    info = _make_info_with_funding("-0.001")  # -0.1%/hr
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.01", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert events[0]["direction"] == "short_pays"
        assert events[0]["hourly_pct"] == -0.1


def test_funding_silent_when_below_threshold(runner):
    info = _make_info_with_funding("0.00001")  # 0.001%/hr, below 0.01% threshold
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.01", "--once"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""


def test_funding_asset_not_found_raises(runner):
    info = MagicMock()
    info.meta_and_asset_ctxs.return_value = [{"universe": [{"name": "ETH"}]}, [{"funding": "0"}]]
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.001", "--once"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Output contract — _emit produces valid JSONL with expected keys
# ---------------------------------------------------------------------------


def test_emit_produces_single_jsonl_line(capsys):
    _emit({"event": "test", "watcher": "unit", "value": 42})
    captured = capsys.readouterr()
    # Exactly one line, valid JSON, ts auto-added
    lines = captured.out.strip().splitlines()
    assert len(lines) == 1
    event = json.loads(lines[0])
    assert event["event"] == "test"
    assert event["watcher"] == "unit"
    assert event["value"] == 42
    assert "ts" in event
    # ISO 8601 Z format
    assert event["ts"].endswith("Z")


def test_emit_preserves_explicit_ts(capsys):
    _emit({"event": "test", "ts": "2020-01-01T00:00:00Z"})
    event = json.loads(capsys.readouterr().out.strip())
    assert event["ts"] == "2020-01-01T00:00:00Z"


def test_watch_app_has_four_subcommands():
    """Surface check: liquidation, price, funding, outcomes are registered.
    Drawdown was removed in v0.19.9; outcomes added in v0.23.0 (HIP-4)."""
    runner = CliRunner()
    result = runner.invoke(watch_app, ["--help"])
    assert "drawdown" not in result.stdout
    assert "liquidation" in result.stdout
    assert "price" in result.stdout
    assert "funding" in result.stdout
    assert "outcomes" in result.stdout


# ---------------------------------------------------------------------------
# outcomes — HIP-4 settlement watcher (v0.23.0)
# ---------------------------------------------------------------------------


def _patch_outcomes_watcher(outcomes_meta_seq, balances_seq):
    """Each call to poll consumes one item from each sequence in order."""
    info = MagicMock()
    info.coin_to_asset = {}
    info.name_to_coin = {}

    # Mock get_resolver to return a stub with a get_outcomes that yields
    # successive responses. Since CLI invokes once with --once, only first.
    resolver = MagicMock()
    resolver.get_outcomes.side_effect = list(outcomes_meta_seq)

    return [
        patch("regard.commands.watch.get_info", return_value=info),
        patch("regard.commands.watch.get_address", return_value="0xWATCHER"),
        patch("regard.commands.watch.get_spot_balances", side_effect=list(balances_seq)),
        # The watch.outcomes command imports get_resolver inside the
        # function body — patch the source module so the in-function import
        # picks up the mock.
        patch("regard.venues.hyperliquid.resolver.get_resolver", return_value=resolver),
    ]


def test_outcomes_once_emits_no_event_on_first_tick(runner):
    """First-tick inventory: position exists but watcher hasn't seen it before
    → no emission. Catches the cold-start regression where a fresh watcher
    would otherwise mis-detect an existing position as 'just settled'."""
    outcomes_meta = [
        {
            "outcome": 2, "name": "Recurring",
            "description": "class:priceBinary|underlying:BTC|expiry:20260505-0600|targetPrice:80000|period:1d",
            "parsed_description": {"class": "priceBinary", "underlying": "BTC",
                                    "expiry": "20260505-0600", "target_price": "80000", "period": "1d"},
            "sides": [{"side": 0, "name": "Yes", "coin": "#20", "balance_coin": "+20", "asset_id": 100000020},
                      {"side": 1, "name": "No", "coin": "#21", "balance_coin": "+21", "asset_id": 100000021}],
        }
    ]
    balances = [
        {"coin": "+20", "balance": "21.0", "kind": "outcome", "outcome": 2, "side": 0, "side_name": "yes"},
        {"coin": "USDH", "balance": "3.62", "kind": "spot", "token": "USDH", "token_index": 360},
    ]
    patches = _patch_outcomes_watcher([outcomes_meta], [balances])
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "outcomes", "--once"])
        assert result.exit_code == 0
        assert _parse_jsonl(result.stdout) == []
    finally:
        for p in patches:
            p.stop()


def test_outcomes_interval_zero_rejected(runner):
    result = runner.invoke(app, ["watch", "outcomes", "--interval", "0", "--once"])
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "INVALID_INTERVAL"


def test_outcomes_address_override_passes_through(runner):
    """--address allows watching another wallet (read-only)."""
    outcomes_meta: list = []
    balances: list = []
    patches = _patch_outcomes_watcher([outcomes_meta], [balances])
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "outcomes", "--address", "0xABC123", "--once"])
        assert result.exit_code == 0
    finally:
        for p in patches:
            p.stop()


# ---------------------------------------------------------------------------
# Peer-review regression tests: interval validation + symbol normalization
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("args", [
    ["watch", "liquidation", "--proximity-pct", "10", "--interval", "0", "--once"],
    ["watch", "price", "BTC", "--above", "1", "--interval", "0", "--once"],
    ["watch", "funding", "BTC", "--threshold-hourly-pct", "0.01", "--interval", "0", "--once"],
])
def test_interval_zero_rejected(runner, args):
    """--interval 0 would produce a tight poll loop; must be rejected at validation time."""
    result = runner.invoke(app, args)
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "INVALID_INTERVAL"


@pytest.mark.parametrize("args", [
    ["watch", "price", "BTC", "--above", "1", "--interval", "-5", "--once"],
])
def test_interval_negative_rejected(runner, args):
    result = runner.invoke(app, args)
    assert result.exit_code == 2
    envelope = json.loads(result.stdout)
    assert envelope["error"]["code"] == "INVALID_INTERVAL"


def test_price_lowercase_symbol_normalizes(runner):
    """`btc` should be uppercased before HL dict lookup — matches rest of CLI."""
    patches = _patch_price({"BTC": "96000.0"})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "btc", "--above", "95000", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        assert events[0]["asset"] == "BTC"  # emission uses normalized form
    finally:
        for p in patches:
            p.stop()


def test_funding_lowercase_symbol_normalizes(runner):
    info = _make_info_with_funding("0.001")  # name in mock is "BTC"
    with patch("regard.commands.watch.get_info", return_value=info):
        result = runner.invoke(app, ["watch", "funding", "btc", "--threshold-hourly-pct", "0.01", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        assert events[0]["asset"] == "BTC"


def test_price_hip3_symbol_preserves_lowercase_prefix(runner):
    """`xyz:tsla` → `xyz:TSLA` — HIP-3 dex prefix stays lowercase, name uppercases."""
    patches = _patch_price({"xyz:TSLA": "350.0"})
    for p in patches:
        p.start()
    try:
        result = runner.invoke(app, ["watch", "price", "xyz:tsla", "--above", "300", "--once"])
        assert result.exit_code == 0
        events = _parse_jsonl(result.stdout)
        assert len(events) == 1
        assert events[0]["asset"] == "xyz:TSLA"
    finally:
        for p in patches:
            p.stop()


def test_normalize_asset_helper():
    """Direct test of the normalization helper."""
    from regard.commands.watch import _normalize_asset
    assert _normalize_asset("btc") == "BTC"
    assert _normalize_asset("BTC") == "BTC"
    assert _normalize_asset("xyz:tsla") == "xyz:TSLA"
    assert _normalize_asset("XYZ:TSLA") == "XYZ:TSLA"  # user explicitly capped dex — preserve
    assert _normalize_asset("xyz:TSLA") == "xyz:TSLA"
