"""Tests for review commands — trades."""

import json

from regard.main import app


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


class TestTrades:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hypercore", "trades"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["hypercore", "trades", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_limit(self, runner, patched):
        result = runner.invoke(app, ["hypercore", "trades", "--limit", "1"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1

    def test_limit_returns_newest(self, runner, patched):
        """--limit N MUST return the N most recent fills, not the N oldest.

        Regression: `user_fills` returns newest-first, so the naive `[-limit:]`
        slice took the oldest N. Fix sorts by time desc before slicing.
        Fixture: BTC@1773000000000 (newer) and ETH@1772990000000 (older).
        """
        result = runner.invoke(app, ["hypercore", "trades", "--limit", "1"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"
        assert d[0]["time"] == "2026-03-08T20:00:00Z"

    def test_output_sorted_newest_first(self, runner, patched):
        """Output MUST be in descending time order regardless of endpoint."""
        result = runner.invoke(app, ["hypercore", "trades"])
        assert result.exit_code == 0
        d = data(result)
        times = [row["time"] for row in d]
        assert times == sorted(times, reverse=True)
