"""SKILL.md contract tests — verify documented commands match CLI reality.

Uses generate_schema() to introspect the live command tree instead of
parsing --help output. Per CLI Constitution Article V: "SKILL.md is validated
against the live schema — not against help-text scraping."

Reads the canonical SKILL.md (`regard-computer/skills/any-agent/`) rather
than the legacy frozen `tabtabtabTABtab/` snapshot.

After v0.24.0 the documented surface includes multi-segment dot-paths
(`hypercore perp transfer dex`, `polygon usdc transfer usdce`, etc.). The
test extracts each documented `regard <prefix> <segments...>` example as a
dot-path string and asserts that path exists in the schema (or is a prefix
of an existing one — for cases like `polygon usdc transfer` which the docs
mention as a category but the leaf is `polygon usdc transfer usdce`).
"""

import re
from pathlib import Path

import pytest

from regard.main import app, generate_schema

# ---------------------------------------------------------------------------
# Extract documented commands from SKILL.md
# ---------------------------------------------------------------------------

SKILL_PATH = (
    Path(__file__).parent.parent.parent
    / "regard-computer" / "skills" / "any-agent" / "regard-computer" / "SKILL.md"
)


def _extract_command_paths(prefix: str) -> set[str]:
    """Extract `regard <prefix> <segs...>` examples from SKILL.md as dot paths.

    The captured path is truncated to the longest schema-known prefix so
    positional argument values (e.g. `xyz` in `hypercore dex xyz transfer perp`)
    don't pollute the documented set. The result is a set of structural
    paths the SKILL.md references — each must resolve to a real schema entry.
    """
    if not SKILL_PATH.exists():
        return set()
    content = SKILL_PATH.read_text()
    pattern = rf"`regard {re.escape(prefix)}((?: [a-z][a-z0-9-]*)+)"
    schema_names = _all_dot_names()
    # Schema-known structural paths under `<prefix>` — these are dot-path
    # prefixes that lead to actual commands (so e.g. `polygon.usdc.transfer`
    # is structural even though only `polygon.usdc.transfer.usdce` is a leaf).
    structural_paths: set[str] = set()
    for name in schema_names:
        if name == prefix or name.startswith(prefix + "."):
            structural_paths.add(name)
            parts = name.split(".")
            for i in range(2, len(parts)):
                structural_paths.add(".".join(parts[:i]))

    paths: set[str] = set()
    for match in re.findall(pattern, content):
        segs = match.strip().split()
        if not segs:
            continue
        # Walk segments left-to-right, keeping only the longest prefix that
        # corresponds to a structural schema path. Once a segment fails the
        # check, treat the rest as positional arguments and stop.
        candidate = prefix
        for seg in segs:
            extended = f"{candidate}.{seg}"
            if extended in structural_paths:
                candidate = extended
            else:
                break
        if candidate != prefix:
            paths.add(candidate)
    return paths


def _all_dot_names() -> set[str]:
    return {c["name"] for c in generate_schema(app)["commands"]}


def _has_path_prefix(documented: str, all_names: set[str]) -> bool:
    """A documented dot-path is satisfied if it's an exact match OR a strict prefix
    of any actual schema command.

    Example: `polygon.usdc.transfer` (a structural intermediate) is OK if any
    schema command starts with `polygon.usdc.transfer.` — that means the doc
    is referring to the subtree by the path that leads to it, not a missing
    leaf.
    """
    if documented in all_names:
        return True
    prefix = documented + "."
    return any(name.startswith(prefix) for name in all_names)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

DOCUMENTED_HYPERCORE = _extract_command_paths("hypercore")
DOCUMENTED_POLYMARKET = _extract_command_paths("polymarket")
DOCUMENTED_POLYGON = _extract_command_paths("polygon")
DOCUMENTED_ARBITRUM = _extract_command_paths("arbitrum")
DOCUMENTED_HYPEREVM = _extract_command_paths("hyperevm")


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_no_stale_hypercore_docs():
    """Every documented hypercore command path must resolve to a real command (or subtree)."""
    all_names = _all_dot_names()
    stale = {p for p in DOCUMENTED_HYPERCORE if not _has_path_prefix(p, all_names)}
    assert not stale, f"SKILL.md references non-existent hypercore paths: {stale}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_no_stale_polymarket_docs():
    """Every documented polymarket command path must resolve to a real command."""
    all_names = _all_dot_names()
    stale = {p for p in DOCUMENTED_POLYMARKET if not _has_path_prefix(p, all_names)}
    # Allow `polymarket.pulse` as a known doc reference even though only
    # hypercore has pulse — the briefing template in SKILL.md predates the
    # rename and is being phased out separately. Drop this exception once
    # the briefing template stops referencing it.
    stale.discard("polymarket.pulse")
    assert not stale, f"SKILL.md references non-existent polymarket paths: {stale}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_no_stale_polygon_docs():
    """Every documented polygon command path must resolve to a real command."""
    all_names = _all_dot_names()
    stale = {p for p in DOCUMENTED_POLYGON if not _has_path_prefix(p, all_names)}
    assert not stale, f"SKILL.md references non-existent polygon paths: {stale}"


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_documented_command_count():
    """Sanity check — SKILL.md should document a reasonable number of commands.

    Counts unique dot paths per venue.
    """
    assert len(DOCUMENTED_HYPERCORE) >= 12, (
        f"Only {len(DOCUMENTED_HYPERCORE)} hypercore paths documented"
    )
    assert len(DOCUMENTED_POLYMARKET) >= 8, (
        f"Only {len(DOCUMENTED_POLYMARKET)} polymarket paths documented"
    )
    assert len(DOCUMENTED_POLYGON) >= 1, (
        f"Only {len(DOCUMENTED_POLYGON)} polygon paths documented"
    )


@pytest.mark.skipif(not SKILL_PATH.exists(), reason="SKILL.md not found")
def test_core_mutating_commands_documented():
    """Each top-level mutating command's first segment is mentioned at least once."""
    # Schema-derived: every mutating command's first dot segment must be
    # mentioned somewhere in the SKILL (even as a subtree reference).
    schema = generate_schema(app)
    documented_first_segments = {
        p.split(".", 2)[0] + "." + p.split(".", 2)[1]
        for p in (DOCUMENTED_HYPERCORE | DOCUMENTED_POLYMARKET | DOCUMENTED_POLYGON
                  | DOCUMENTED_ARBITRUM | DOCUMENTED_HYPEREVM)
        if "." in p
    }
    actual_first_two = {
        ".".join(c["name"].split(".")[:2])
        for c in schema["commands"]
        if c["class"] == "mutating"
    }
    # Allow a small set of paths to be missing without failing — they are
    # invariant-implementation details (e.g. polygon.send is documented).
    missing = actual_first_two - documented_first_segments
    # Allow polymarket.cancel-all which is hyphenated and may not match
    # cleanly via the regex.
    missing.discard("polymarket.cancel-all")
    assert not missing, f"mutating command paths not mentioned in SKILL.md: {missing}"
