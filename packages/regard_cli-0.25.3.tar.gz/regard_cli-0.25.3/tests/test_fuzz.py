"""Property-based fuzz testing — every input produces valid JSON.

Uses Hypothesis to generate adversarial inputs: empty strings, huge numbers,
NaN, negative prices, Unicode, special characters. The invariant is simple:
no matter what you throw at the CLI, stdout must be valid JSON.
"""

import json

from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st
from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()

# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

KNOWN_ASSETS = ["BTC", "ETH", "SOL", "xyz:TSLA", "xyz:NATGAS", "km:GOLD"]

asset_names = st.one_of(
    st.sampled_from(KNOWN_ASSETS),
    st.text(min_size=0, max_size=50),  # fuzz
)

sides = st.one_of(
    st.sampled_from(["buy", "sell", "long", "short"]),
    st.text(min_size=0, max_size=20),  # fuzz
)

sizes = st.one_of(
    st.sampled_from(["0", "0.001", "1", "100", "999999"]),
    st.text(min_size=0, max_size=20),  # fuzz
)

prices = st.one_of(
    st.sampled_from(["0", "0.01", "100", "99999", ""]),
    st.none(),
    st.text(min_size=0, max_size=20),  # fuzz
)

intervals = st.one_of(
    st.sampled_from(["1m", "5m", "15m", "1h", "4h", "1d"]),
    st.text(min_size=0, max_size=10),  # fuzz
)

tif_values = st.one_of(
    st.sampled_from(["gtc", "ioc", "alo"]),
    st.text(min_size=0, max_size=20),  # fuzz
)


def is_valid_json(stdout: str) -> bool:
    """Check if stdout is valid JSON (or empty for help output)."""
    stdout = stdout.strip()
    if not stdout:
        return True  # help output / no-args-is-help
    try:
        json.loads(stdout)
        return True
    except json.JSONDecodeError:
        return False


# ---------------------------------------------------------------------------
# Properties — every input → valid JSON
# ---------------------------------------------------------------------------

@given(asset=asset_names)
@settings(max_examples=50, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture])
def test_prices_always_json(asset, patched):
    result = runner.invoke(app, ["hypercore", "prices", asset])
    assert is_valid_json(result.stdout), f"Non-JSON for asset={asset!r}: {result.stdout[:200]}"


@given(asset=asset_names)
@settings(max_examples=50, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture])
def test_assets_always_json(asset, patched):
    result = runner.invoke(app, ["hypercore", "assets", asset])
    assert is_valid_json(result.stdout), f"Non-JSON for asset={asset!r}: {result.stdout[:200]}"


@given(asset=asset_names, side=sides, size=sizes)
@settings(max_examples=50, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture])
def test_order_always_json(asset, side, size, patched):
    args = ["hypercore", "order", asset, side, size, "--market"]
    result = runner.invoke(app, args)
    assert is_valid_json(result.stdout), f"Non-JSON for {args}: {result.stdout[:200]}"


@given(asset=asset_names, side=sides, size=sizes, price=prices)
@settings(max_examples=50, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture])
def test_limit_order_always_json(asset, side, size, price, patched):
    args = ["hypercore", "order", asset, side, size]
    if price is not None and price != "":
        args.append(price)
    result = runner.invoke(app, args)
    assert is_valid_json(result.stdout), f"Non-JSON for {args}: {result.stdout[:200]}"


@given(asset=asset_names, interval=intervals)
@settings(max_examples=50, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture])
def test_candles_always_json(asset, interval, patched):
    result = runner.invoke(app, ["hypercore", "candles", asset, interval])
    assert is_valid_json(result.stdout), f"Non-JSON for candles {asset} {interval}: {result.stdout[:200]}"


@given(tif=tif_values)
@settings(max_examples=30, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture])
def test_tif_always_json(tif, patched):
    result = runner.invoke(app, ["hypercore", "order", "BTC", "buy", "0.01", "65000", "--tif", tif])
    assert is_valid_json(result.stdout), f"Non-JSON for tif={tif!r}: {result.stdout[:200]}"


@given(asset=asset_names)
@settings(max_examples=50, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture])
def test_funding_always_json(asset, patched):
    result = runner.invoke(app, ["hypercore", "funding", asset])
    assert is_valid_json(result.stdout), f"Non-JSON for funding {asset!r}: {result.stdout[:200]}"


@given(asset=asset_names)
@settings(max_examples=50, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture])
def test_book_always_json(asset, patched):
    result = runner.invoke(app, ["hypercore", "book", asset])
    assert is_valid_json(result.stdout), f"Non-JSON for book {asset!r}: {result.stdout[:200]}"
