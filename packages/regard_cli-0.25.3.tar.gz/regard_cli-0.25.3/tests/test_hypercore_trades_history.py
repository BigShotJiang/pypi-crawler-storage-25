"""Tests for venues/hyperliquid/trades_history.py — the tilt detector's
HL fills helper."""

from unittest.mock import MagicMock, patch

from regard.venues.hyperliquid.trades_history import (
    consecutive_losses,
    consecutive_wins,
    fetch_recent_fills,
    first_red_in_session,
    rolling_baseline,
    win_streak_with_size_escalation,
)

# ---------------------------------------------------------------------------
# consecutive_losses — pure-logic walk over closed_pnl values
# ---------------------------------------------------------------------------


class TestConsecutiveLosses:
    def test_empty_returns_zero(self):
        assert consecutive_losses([]) == 0

    def test_no_losses_returns_zero(self):
        fills = [
            {"closed_pnl": 50.0},
            {"closed_pnl": 100.0},
        ]
        assert consecutive_losses(fills) == 0

    def test_single_loss_at_top(self):
        fills = [{"closed_pnl": -25.0}, {"closed_pnl": 30.0}]
        assert consecutive_losses(fills) == 1

    def test_three_in_a_row(self):
        fills = [
            {"closed_pnl": -10.0},
            {"closed_pnl": -20.0},
            {"closed_pnl": -5.0},
            {"closed_pnl": 100.0},  # winner — streak ends here
        ]
        assert consecutive_losses(fills) == 3

    def test_break_even_terminates_streak(self):
        # closed_pnl == 0 (e.g. open position, fee-only entry) ends the
        # streak — only converted losses count.
        fills = [
            {"closed_pnl": -10.0},
            {"closed_pnl": 0.0},
            {"closed_pnl": -100.0},
        ]
        assert consecutive_losses(fills) == 1

    def test_winner_after_losses_ignored(self):
        # Older trades after a streak don't count if they're behind a winner.
        fills = [
            {"closed_pnl": -10.0},
            {"closed_pnl": -20.0},
            {"closed_pnl": 50.0},  # streak terminator
            {"closed_pnl": -100.0},  # not counted (older, behind a win)
        ]
        assert consecutive_losses(fills) == 2

    def test_missing_pnl_field_treated_as_zero(self):
        fills = [{"asset": "BTC"}]  # no closed_pnl → defaults to 0 → terminates streak
        assert consecutive_losses(fills) == 0


class TestFirstRedInSession:
    def test_empty_returns_false(self):
        assert first_red_in_session([]) is False

    def test_all_winners_returns_false(self):
        fills = [{"closed_pnl": 50.0}, {"closed_pnl": 100.0}]
        assert first_red_in_session(fills) is False

    def test_one_loss_returns_true(self):
        fills = [{"closed_pnl": 50.0}, {"closed_pnl": -10.0}]
        assert first_red_in_session(fills) is True

    def test_loss_anywhere_in_list_returns_true(self):
        # Order doesn't matter — ANY loss anywhere flips the flag
        fills = [
            {"closed_pnl": 100.0},
            {"closed_pnl": 50.0},
            {"closed_pnl": -25.0},  # anywhere
            {"closed_pnl": 75.0},
        ]
        assert first_red_in_session(fills) is True

    def test_break_even_does_not_count(self):
        # closed_pnl == 0 is not a "red" — fees-only / open positions
        fills = [{"closed_pnl": 0.0}, {"closed_pnl": 0.0}]
        assert first_red_in_session(fills) is False


class TestConsecutiveWins:
    def test_empty_zero(self):
        assert consecutive_wins([]) == 0

    def test_three_wins(self):
        fills = [
            {"closed_pnl": 100.0},
            {"closed_pnl": 50.0},
            {"closed_pnl": 25.0},
            {"closed_pnl": -10.0},  # terminator
        ]
        assert consecutive_wins(fills) == 3

    def test_break_even_terminates(self):
        fills = [{"closed_pnl": 100.0}, {"closed_pnl": 0.0}, {"closed_pnl": 50.0}]
        assert consecutive_wins(fills) == 1


class TestWinStreakWithSizeEscalation:
    def _wins(self, n: int, sizes: list[float]) -> list[dict]:
        # newest-first; pair each win with a size
        return [{"closed_pnl": 100.0, "size": s} for s in sizes[:n]]

    def test_too_few_wins_returns_false(self):
        fills = self._wins(3, [1.0, 1.0, 1.0])
        assert win_streak_with_size_escalation(fills, win_threshold=5) is False

    def test_streak_but_no_size_escalation_returns_false(self):
        # 5 wins, all same size — pure running-good, not Winner's Tilt
        fills = self._wins(5, [1.0, 1.0, 1.0, 1.0, 1.0])
        assert win_streak_with_size_escalation(fills, win_threshold=5) is False

    def test_streak_plus_size_doubling_returns_true(self):
        # 5 wins with last size 2× the others → 2× avg → tilt
        fills = self._wins(5, [3.0, 1.0, 1.0, 1.0, 1.0])
        assert win_streak_with_size_escalation(
            fills, win_threshold=5, size_multiplier=1.3,
        ) is True

    def test_size_just_below_threshold_returns_false(self):
        # 5 wins, last size 1.2× avg → below 1.3 threshold
        sizes = [1.2, 1.0, 1.0, 1.0, 1.0]  # avg = 1.04, last = 1.2 = 1.15× avg
        fills = self._wins(5, sizes)
        assert win_streak_with_size_escalation(
            fills, win_threshold=5, size_multiplier=1.3,
        ) is False

    def test_loss_in_streak_returns_false(self):
        fills = [
            {"closed_pnl": 100.0, "size": 5.0},
            {"closed_pnl": -10.0, "size": 1.0},  # loss breaks streak
            {"closed_pnl": 50.0, "size": 1.0},
        ]
        assert win_streak_with_size_escalation(fills, win_threshold=2) is False

    def test_configurable_threshold(self):
        # With threshold=3, a 3-win streak qualifies
        fills = self._wins(3, [3.0, 1.0, 1.0])
        assert win_streak_with_size_escalation(fills, win_threshold=3) is True
        # Same fills with threshold=5 doesn't
        assert win_streak_with_size_escalation(fills, win_threshold=5) is False


class TestRollingBaseline:
    def _fill(self, size: float, time_ms: int) -> dict:
        return {"size": size, "time_ms": time_ms, "closed_pnl": 0,
                "asset": "BTC", "side": "buy", "price": 1.0,
                "fee": 0, "time_iso": ""}

    def test_below_min_samples_returns_none(self):
        fills = [self._fill(1.0, 1000 + i * 1000) for i in range(10)]
        assert rolling_baseline(fills, min_samples=50) is None

    def test_no_fills_returns_none(self):
        assert rolling_baseline([]) is None
        assert rolling_baseline([], min_samples=1) is None

    def test_meets_min_samples_returns_stats(self):
        # 60 fills, all size=2.0, intervals=1000ms (=1s).
        # Use time_ms starting at 1000 (not 0) — time_ms=0 is filtered
        # out of the valid set per the timestamp guard.
        fills = [self._fill(2.0, (i + 1) * 1000) for i in range(60)]
        result = rolling_baseline(fills, min_samples=50)
        assert result is not None
        assert result["sample_count"] == 60
        assert result["avg_size"] == 2.0
        # Intervals between consecutive fills are 1000ms = 1s
        assert abs(result["avg_interval_seconds"] - 1.0) < 0.01

    def test_zero_size_excluded(self):
        # Mix of valid and zero-size fills; only valid ones count
        fills = [self._fill(0, i * 1000) for i in range(40)] + \
                [self._fill(5.0, 40_000 + i * 1000) for i in range(60)]
        result = rolling_baseline(fills, min_samples=50)
        assert result is not None
        assert result["sample_count"] == 60
        assert result["avg_size"] == 5.0

    def test_unsorted_times_handled(self):
        # Fills out of order — function should sort internally
        fills = [self._fill(2.0, t) for t in [5000, 1000, 3000, 2000, 4000]] * 12
        result = rolling_baseline(fills, min_samples=50)
        assert result is not None
        assert result["avg_interval_seconds"] >= 0  # non-negative

    def test_size_valid_but_times_invalid_returns_none(self):
        # Regression: 50 size-valid fills but only 2 with valid time_ms
        # must NOT pass the gate (peer-review finding — both filters
        # apply to the SAME subset of fills).
        fills = (
            [self._fill(1.0, 0) for _ in range(50)]  # size valid, time_ms=0 invalid
            + [self._fill(0, 1000) for _ in range(2)]  # time valid, size=0 invalid
        )
        result = rolling_baseline(fills, min_samples=50)
        assert result is None

    def test_partial_overlap_below_threshold_returns_none(self):
        # Mix where some fills have both, some have only one — total
        # both-valid count must reach min_samples
        fills = (
            [self._fill(2.0, (i + 1) * 1000) for i in range(40)]  # both valid
            + [self._fill(0, (i + 50) * 1000) for i in range(20)]  # size invalid
        )
        result = rolling_baseline(fills, min_samples=50)
        # Only 40 fully-valid fills; below threshold of 50
        assert result is None


# ---------------------------------------------------------------------------
# fetch_recent_fills — graceful degradation + normalization
# ---------------------------------------------------------------------------


class TestFetchRecentFillsDegradation:
    def test_no_wallet_returns_empty(self, tmp_path, monkeypatch):
        # No wallet configured → get_address raises → helper returns []
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        # Make sure no env var leaks in
        monkeypatch.delenv("HYPERLIQUID_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("POLYMARKET_PRIVATE_KEY", raising=False)
        assert fetch_recent_fills() == []

    def test_sdk_exception_returns_empty(self):
        with patch("regard.venues.hyperliquid.client.get_address", return_value="0x" + "a" * 40):
            mock_info = MagicMock()
            mock_info.user_fills.side_effect = RuntimeError("network down")
            with patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info):
                assert fetch_recent_fills() == []


class TestFetchRecentFillsNormalization:
    def _mock_sdk(self, fills_data):
        mock_info = MagicMock()
        mock_info.user_fills.return_value = fills_data
        return mock_info

    def test_basic_normalization(self):
        sdk_data = [
            {
                "coin": "BTC",
                "side": "B",
                "sz": "0.5",
                "px": "60000",
                "closedPnl": "-150.00",
                "fee": "5.50",
                "time": 1717200000000,
            },
            {
                "coin": "ETH",
                "side": "A",
                "sz": "10",
                "px": "3000",
                "closedPnl": "200",
                "fee": "1",
                "time": 1717100000000,  # older
            },
        ]
        with patch("regard.venues.hyperliquid.client.get_address", return_value="0x" + "a" * 40):
            with patch("regard.venues.hyperliquid.client.get_info", return_value=self._mock_sdk(sdk_data)):
                fills = fetch_recent_fills()

        assert len(fills) == 2
        # newest-first
        assert fills[0]["asset"] == "BTC"
        assert fills[0]["side"] == "buy"
        assert fills[0]["size"] == 0.5
        assert fills[0]["price"] == 60000.0
        assert fills[0]["closed_pnl"] == -150.0
        assert fills[0]["fee"] == 5.50
        assert fills[0]["time_ms"] == 1717200000000
        assert fills[0]["time_iso"]  # populated
        assert fills[1]["asset"] == "ETH"
        assert fills[1]["side"] == "sell"

    def test_bad_numeric_fields_default_to_zero(self):
        sdk_data = [
            {"coin": "BTC", "side": "B", "sz": None, "px": "", "closedPnl": "abc", "time": 1000},
        ]
        with patch("regard.venues.hyperliquid.client.get_address", return_value="0x" + "a" * 40):
            with patch("regard.venues.hyperliquid.client.get_info", return_value=self._mock_sdk(sdk_data)):
                fills = fetch_recent_fills()

        assert fills[0]["size"] == 0.0
        assert fills[0]["price"] == 0.0
        assert fills[0]["closed_pnl"] == 0.0

    def test_limit_caps_results(self):
        sdk_data = [
            {"coin": f"COIN{i}", "side": "B", "sz": "1", "px": "1", "closedPnl": "0", "time": 1000 + i}
            for i in range(50)
        ]
        with patch("regard.venues.hyperliquid.client.get_address", return_value="0x" + "a" * 40):
            with patch("regard.venues.hyperliquid.client.get_info", return_value=self._mock_sdk(sdk_data)):
                fills = fetch_recent_fills(limit=5)

        assert len(fills) == 5
        # newest-first → highest time_ms first
        assert fills[0]["time_ms"] == 1049
        assert fills[4]["time_ms"] == 1045

    def test_non_list_response_returns_empty(self):
        # SDK returning something weird (None, dict) → graceful fallback
        with patch("regard.venues.hyperliquid.client.get_address", return_value="0x" + "a" * 40):
            mock_info = MagicMock()
            mock_info.user_fills.return_value = None
            with patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info):
                assert fetch_recent_fills() == []

    def test_extreme_timestamp_does_not_crash(self):
        # Regression: `datetime.fromtimestamp(huge / 1000)` raises
        # OverflowError on some platforms — must NOT propagate to caller.
        sdk_data = [
            {"coin": "BTC", "side": "B", "sz": "1", "px": "1",
             "closedPnl": "0", "time": 99999999999999999},  # absurd
        ]
        with patch("regard.venues.hyperliquid.client.get_address", return_value="0x" + "a" * 40):
            mock_info = MagicMock()
            mock_info.user_fills.return_value = sdk_data
            with patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info):
                fills = fetch_recent_fills()
        assert len(fills) == 1
        # time_ms preserved, time_iso defaults to empty on overflow
        assert fills[0]["time_iso"] == ""
