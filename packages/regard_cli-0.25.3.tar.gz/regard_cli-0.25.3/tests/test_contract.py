"""Contract tests — every command produces valid JSON, no tracebacks, no ANSI.

The meta-test: invoke every command (success + error cases) and assert
the output is always valid JSON with the correct envelope shape.
This single file would have caught all 10 bugs from the 2026-03-31 test run.
"""

import json
import re

import pytest

from regard.main import app

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_stdout(result) -> dict:
    """Parse CLI result stdout as JSON. Fails with clear message if non-JSON."""
    stdout = result.stdout.strip() if result.stdout else ""
    assert "Traceback" not in stdout, f"Traceback in stdout: {stdout[:300]}"
    assert not re.search(r"\x1b\[[0-9;]*[a-zA-Z]", stdout), "ANSI codes in stdout"
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        pytest.fail(f"Non-JSON stdout (exit={result.exit_code}): {stdout!r}")


def assert_envelope(data: dict):
    """Assert the output follows the envelope contract."""
    assert isinstance(data, dict)
    assert "ok" in data
    if data["ok"]:
        assert "data" in data
        assert "meta" in data
    else:
        assert "error" in data


# ---------------------------------------------------------------------------
# HL commands — success paths (with mocked SDK)
# ---------------------------------------------------------------------------

HL_SUCCESS_COMMANDS = [
    ["hypercore", "status"],
    ["hypercore", "balance"],
    ["hypercore", "positions"],
    ["hypercore", "orders"],
    ["hypercore", "assets"],
    ["hypercore", "assets", "BTC"],
    ["hypercore", "prices"],
    ["hypercore", "prices", "BTC"],
    ["hypercore", "book", "BTC"],
    ["hypercore", "funding"],
    ["hypercore", "funding", "BTC"],
    ["hypercore", "funding", "BTC", "--history", "--limit", "3"],
    ["hypercore", "candles", "BTC", "1h", "--limit", "2"],
    ["hypercore", "trades"],
    ["hypercore", "trades", "BTC"],
    ["hypercore", "preflight", "BTC", "buy", "0.01"],
    ["hypercore", "order", "BTC", "buy", "0.01", "65000"],
    ["hypercore", "order", "BTC", "sell", "0.01", "--market"],
    ["hypercore", "cancel", "BTC", "100001"],
    ["hypercore", "cancel-all"],
    ["hypercore", "leverage", "BTC", "10"],
    # HIP-4 read-path commands
    ["hypercore", "outcomes"],
    ["hypercore", "outcome", "1"],            # bare integer → both sides
    ["hypercore", "outcome", "1:yes"],        # named side
    ["hypercore", "outcome", "1:no"],
    ["hypercore", "outcome", "1:0"],          # numeric side
    ["hypercore", "outcome", "#10"],          # full coin form
]


@pytest.mark.parametrize("args", HL_SUCCESS_COMMANDS, ids=lambda a: " ".join(a))
def test_hl_command_produces_valid_json(runner, patched, args):
    result = runner.invoke(app, args)
    data = parse_stdout(result)
    assert_envelope(data)
    assert data["ok"] is True, f"Expected ok=True for {args}: {data}"


# ---------------------------------------------------------------------------
# HL commands — error paths (should STILL produce valid JSON)
# ---------------------------------------------------------------------------

HL_ERROR_COMMANDS = [
    # Unknown asset
    (["hypercore", "prices", "FAKECOIN123"], "UNKNOWN_ASSET"),
    # Invalid side
    (["hypercore", "order", "BTC", "invalidside", "1", "65000"], "INVALID_SIDE"),
    # Invalid TIF
    (["hypercore", "order", "BTC", "buy", "1", "65000", "--tif", "badvalue"], "INVALID_TIF"),
    # Missing required args (Click/Typer parse error → JSON via monkey-patch)
    (["hypercore", "order"], "USAGE_ERROR"),
    (["hypercore", "book"], "USAGE_ERROR"),
    (["hypercore", "candles"], "USAGE_ERROR"),
    (["hypercore", "leverage", "BTC"], "USAGE_ERROR"),
    (["hypercore", "preflight", "BTC"], "USAGE_ERROR"),
    (["hypercore", "outcome"], "USAGE_ERROR"),
    # HIP-4 outcome id parsing — every malformed form has its own code.
    (["hypercore", "outcome", ""], "INVALID_OUTCOME_ID"),
    (["hypercore", "outcome", "#"], "INVALID_OUTCOME_ID"),       # empty body
    (["hypercore", "outcome", "#abc"], "INVALID_OUTCOME_ID"),    # non-digit body
    (["hypercore", "outcome", "1:badside"], "INVALID_OUTCOME_ID"),
    (["hypercore", "outcome", "abc"], "INVALID_OUTCOME_ID"),     # not an int
    (["hypercore", "outcome", "1.5"], "INVALID_OUTCOME_ID"),     # not an int (float)
    # Peer-review regression cases (commit 155bc26 + fixup):
    (["hypercore", "outcome", "#12"], "INVALID_OUTCOME_ID"),     # SIDE-OOB: side=2 (categoricals not supported)
    (["hypercore", "outcome", "#010"], "INVALID_OUTCOME_ID"),    # LEAD-ZERO: leading zeros aliased #10 pre-fix
    (["hypercore", "outcome", "#²"], "INVALID_OUTCOME_ID"),      # UNICODE-VAL: was internal_error/exit 7 pre-fix
    (["hypercore", "outcome", "99999"], "UNKNOWN_OUTCOME"),      # parses but not in meta
    # Unknown option
    (["hypercore", "status", "--nonexistent"], "USAGE_ERROR"),
]


@pytest.mark.parametrize("args,expected_code", HL_ERROR_COMMANDS,
                         ids=lambda a: " ".join(a) if isinstance(a, list) else a)
def test_hl_error_produces_json(runner, patched, args, expected_code):
    result = runner.invoke(app, args)
    data = parse_stdout(result)
    assert_envelope(data)
    assert data["ok"] is False
    assert data["error"]["code"] == expected_code


# ---------------------------------------------------------------------------
# Display conformance — every agent-safe read MUST include `display`
# ---------------------------------------------------------------------------
#
# Regression guard against silent display-field omissions. Caught two gaps in
# 2026-04-17: (1) hl spot-balances missing display field, (2) the entire Poly
# venue missing display. Keeps the invariant enforceable as new reads land.
# Mutating commands (order/cancel/leverage/etc.) are not in scope — their
# envelopes carry proposals, not renderable data.

HL_READ_COMMANDS = [
    ["hypercore", "status"],
    ["hypercore", "balance"],
    ["hypercore", "positions"],
    ["hypercore", "orders"],
    ["hypercore", "spot-balances"],
    ["hypercore", "assets"],
    ["hypercore", "prices"],
    ["hypercore", "prices", "BTC"],
    ["hypercore", "book", "BTC"],
    ["hypercore", "funding"],
    ["hypercore", "candles", "BTC", "1h", "--limit", "2"],
    ["hypercore", "trades"],
    ["hypercore", "pulse"],
    ["hypercore", "outcomes"],
    ["hypercore", "outcome", "1"],
]


@pytest.mark.parametrize("args", HL_READ_COMMANDS, ids=lambda a: " ".join(a))
def test_hl_read_has_display(runner, patched, args):
    """Every HL agent-safe read MUST populate `display`.

    Poly venue has an equivalent test in test_poly.py::test_poly_read_has_display.
    """
    result = runner.invoke(app, args)
    data = parse_stdout(result)
    assert data["ok"] is True, f"{args} did not succeed: {data}"
    assert "display" in data, f"{args} missing `display` field"
    assert data["display"], f"{args} has empty `display` field"


# ---------------------------------------------------------------------------
# Global flags
# ---------------------------------------------------------------------------

def test_version_flag(runner):
    result = runner.invoke(app, ["--version"])
    # Version output is plain text (not JSON) — that's OK, it's a special case
    assert result.exit_code == 0


def test_fields_projection(runner, patched):
    result = runner.invoke(app, ["--fields", "account_value", "hypercore", "status"])
    data = parse_stdout(result)
    assert data["ok"] is True
    assert "account_value" in data["data"]


def test_no_args_help(runner):
    result = runner.invoke(app, [])
    # no_args_is_help exits 0 or 2 depending on Typer version — help text, not JSON (acceptable)
    assert result.exit_code in (0, 2)
