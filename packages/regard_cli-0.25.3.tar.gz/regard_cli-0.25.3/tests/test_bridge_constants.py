"""Smoke-tests for bridge constants — pin known-good contract / system addresses.

These constants are pulled from HL docs and the SDK. If they change, multiple
production paths break. Pinning them in a test catches accidental edits.
"""

from decimal import Decimal


def test_arbitrum_chain_id():
    from regard.venues.hyperliquid.bridge_constants import ARB_CHAIN_ID
    assert ARB_CHAIN_ID == 42161


def test_arb_usdc_contract_address():
    """Native USDC on Arbitrum — Circle-issued."""
    from regard.venues.hyperliquid.bridge_constants import ARB_USDC_CONTRACT
    assert ARB_USDC_CONTRACT == "0xaf88d065e77c8cC2239327C5EDb3A432268e5831"


def test_hl_bridge2_contract_address():
    """Hyperliquid Bridge2 deposit target. Sending USDC here auto-credits HL perp."""
    from regard.venues.hyperliquid.bridge_constants import HL_BRIDGE2_CONTRACT
    assert HL_BRIDGE2_CONTRACT == "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7"


def test_arb_min_deposit():
    """5 USDC minimum — below this HL silently loses the deposit."""
    from regard.venues.hyperliquid.bridge_constants import ARB_MIN_DEPOSIT
    assert ARB_MIN_DEPOSIT == Decimal("5")


def test_arb_usdc_decimals():
    from regard.venues.hyperliquid.bridge_constants import ARB_USDC_DECIMALS
    assert ARB_USDC_DECIMALS == 6


def test_hyperevm_chain_id():
    from regard.venues.hyperliquid.bridge_constants import HYPEREVM_CHAIN_ID
    assert HYPEREVM_CHAIN_ID == 999


def test_hype_system_address():
    """HYPE return target: system contract with payable receive()."""
    from regard.venues.hyperliquid.bridge_constants import HYPE_SYSTEM_ADDRESS
    assert HYPE_SYSTEM_ADDRESS == "0x2222222222222222222222222222222222222222"


def test_hype_bridge_gas_limit():
    """HYPE native value-send needs ~65k gas (LOG3 + intrinsic). 100k is the safe override."""
    from regard.venues.hyperliquid.bridge_constants import HYPE_BRIDGE_GAS_LIMIT
    assert HYPE_BRIDGE_GAS_LIMIT == 100_000


def test_gas_thresholds_present():
    from regard.venues.hyperliquid.bridge_constants import (
        ARB_GAS_HARD_THRESHOLD,
        ARB_GAS_WARN_THRESHOLD,
        HYPEREVM_GAS_HARD_THRESHOLD,
        HYPEREVM_GAS_WARN_THRESHOLD,
    )
    # Numeric values may be tuned; just verify they're positive Decimals.
    assert ARB_GAS_WARN_THRESHOLD > 0
    assert ARB_GAS_HARD_THRESHOLD > 0
    assert HYPEREVM_GAS_WARN_THRESHOLD > 0
    assert HYPEREVM_GAS_HARD_THRESHOLD > 0
