"""Tests for venues/hyperliquid/leverage_helper.py."""

from unittest.mock import MagicMock, patch

from regard.venues.hyperliquid.leverage_helper import (
    _coerce_leverage,
    detect_leverage_ratchet,
    fetch_current_leverage,
)


class TestCoerceLeverage:
    def test_dict_form(self):
        assert _coerce_leverage({"type": "cross", "value": 10}) == 10.0
        assert _coerce_leverage({"type": "isolated", "value": 5.5}) == 5.5

    def test_dict_with_string_value(self):
        assert _coerce_leverage({"type": "cross", "value": "20"}) == 20.0

    def test_int_form(self):
        assert _coerce_leverage(5) == 5.0

    def test_string_form(self):
        assert _coerce_leverage("3.5") == 3.5

    def test_none_returns_zero(self):
        assert _coerce_leverage(None) == 0.0

    def test_negative_returns_zero(self):
        assert _coerce_leverage(-5) == 0.0

    def test_garbage_returns_zero(self):
        assert _coerce_leverage("not-a-number") == 0.0
        assert _coerce_leverage([]) == 0.0
        assert _coerce_leverage({"type": "cross"}) == 0.0


class TestFetchCurrentLeverage:
    def test_no_wallet_returns_empty(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        monkeypatch.delenv("HYPERLIQUID_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("POLYMARKET_PRIVATE_KEY", raising=False)
        assert fetch_current_leverage() == {}

    def test_get_all_positions_exception(self):
        with patch(
            "regard.venues.hyperliquid.client.get_address",
            return_value="0x" + "a" * 40,
        ), patch(
            "regard.venues.hyperliquid.client.get_info",
            return_value=MagicMock(),
        ), patch(
            "regard.venues.hyperliquid.client.get_all_positions",
            side_effect=RuntimeError("dex API down"),
        ):
            assert fetch_current_leverage() == {}

    def test_normalizes_polymorphic_leverage(self):
        positions = [
            {"coin": "BTC", "leverage": {"type": "cross", "value": 10}},
            {"coin": "ETH", "leverage": 5},
            {"coin": "SOL", "leverage": "3"},
        ]
        with patch(
            "regard.venues.hyperliquid.client.get_address",
            return_value="0x" + "a" * 40,
        ), patch(
            "regard.venues.hyperliquid.client.get_info",
            return_value=MagicMock(),
        ), patch(
            "regard.venues.hyperliquid.client.get_all_positions",
            return_value=positions,
        ):
            result = fetch_current_leverage()
        assert result == {"BTC": 10.0, "ETH": 5.0, "SOL": 3.0}

    def test_zero_leverage_excluded(self):
        positions = [
            {"coin": "BTC", "leverage": 0},
            {"coin": "ETH", "leverage": 5},
        ]
        with patch(
            "regard.venues.hyperliquid.client.get_address",
            return_value="0x" + "a" * 40,
        ), patch(
            "regard.venues.hyperliquid.client.get_info",
            return_value=MagicMock(),
        ), patch(
            "regard.venues.hyperliquid.client.get_all_positions",
            return_value=positions,
        ):
            result = fetch_current_leverage()
        assert result == {"ETH": 5.0}

    def test_same_asset_across_dexes_keeps_max(self):
        positions = [
            {"coin": "BTC", "leverage": 5, "_dex": ""},
            {"coin": "BTC", "leverage": 20, "_dex": "xyz"},
        ]
        with patch(
            "regard.venues.hyperliquid.client.get_address",
            return_value="0x" + "a" * 40,
        ), patch(
            "regard.venues.hyperliquid.client.get_info",
            return_value=MagicMock(),
        ), patch(
            "regard.venues.hyperliquid.client.get_all_positions",
            return_value=positions,
        ):
            result = fetch_current_leverage()
        assert result == {"BTC": 20.0}


class TestDetectLeverageRatchet:
    def test_no_history_no_ratchet(self):
        ratchet, descs = detect_leverage_ratchet({}, {"BTC": 50.0}, threshold=5)
        assert ratchet is False
        assert descs == []

    def test_below_threshold_skipped(self):
        history = {"BTC": [{"ts": "2026-04-30T10:00:00+00:00", "lev": 1.0}]}
        ratchet, descs = detect_leverage_ratchet(
            history, {"BTC": 3.0}, threshold=5,
        )
        assert ratchet is False

    def test_clean_ratchet_2x_to_10x(self):
        history = {"BTC": [{"ts": "2026-04-30T10:00:00+00:00", "lev": 2.0}]}
        ratchet, descs = detect_leverage_ratchet(
            history, {"BTC": 10.0}, threshold=5, ratchet_multiplier=1.5,
        )
        assert ratchet is True
        assert "BTC" in descs[0]
        assert "2" in descs[0] and "10" in descs[0]

    def test_below_multiplier_no_ratchet(self):
        history = {"BTC": [{"ts": "2026-04-30T10:00:00+00:00", "lev": 5.0}]}
        ratchet, descs = detect_leverage_ratchet(
            history, {"BTC": 7.0}, threshold=5, ratchet_multiplier=1.5,
        )
        assert ratchet is False

    def test_uses_earliest_in_session_as_baseline(self):
        history = {
            "BTC": [
                {"ts": "2026-04-30T10:00:00+00:00", "lev": 2.0},
                {"ts": "2026-04-30T11:00:00+00:00", "lev": 8.0},
            ],
        }
        ratchet, descs = detect_leverage_ratchet(
            history, {"BTC": 12.0}, threshold=5,
        )
        assert ratchet is True
        assert "2" in descs[0] and "12" in descs[0]

    def test_multi_asset_any_fires(self):
        history = {
            "BTC": [{"ts": "2026-04-30T10:00:00+00:00", "lev": 5.0}],
            "ETH": [{"ts": "2026-04-30T10:00:00+00:00", "lev": 2.0}],
        }
        ratchet, descs = detect_leverage_ratchet(
            history, {"BTC": 5.5, "ETH": 15.0}, threshold=5,
        )
        assert ratchet is True
        assert any("ETH" in d for d in descs)

    def test_zero_baseline_skipped(self):
        history = {"BTC": [{"ts": "2026-04-30T10:00:00+00:00", "lev": 0}]}
        ratchet, descs = detect_leverage_ratchet(
            history, {"BTC": 10.0}, threshold=5,
        )
        assert ratchet is False
