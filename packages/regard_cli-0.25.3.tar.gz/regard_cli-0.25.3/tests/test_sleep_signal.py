"""Tests for core/sleep_signal.py — declarative-only Phase 1 implementation."""

from datetime import datetime

from regard.core.sleep_signal import _parse_window, hours_since_last_wakeup


class TestParseWindow:
    def test_parses_standard_format(self):
        assert _parse_window("23:00-07:00") == (7, 0)

    def test_parses_single_digit_hour(self):
        assert _parse_window("9:30-7:00") == (7, 0)

    def test_returns_none_when_unset(self):
        assert _parse_window(None) is None
        assert _parse_window("") is None

    def test_returns_none_for_garbage(self):
        assert _parse_window("not-a-window") is None
        assert _parse_window("23-7") is None
        assert _parse_window("23:00:00-07:00:00") is None

    def test_returns_none_for_out_of_range(self):
        assert _parse_window("24:00-07:00") is None
        assert _parse_window("23:00-25:00") is None
        assert _parse_window("23:60-07:00") is None


class TestHoursSinceLastWakeup:
    def test_unset_returns_zero(self):
        # No window declared → no signal contribution
        assert hours_since_last_wakeup(None, datetime(2026, 4, 30, 14, 0)) == 0.0

    def test_unparseable_returns_zero(self):
        assert hours_since_last_wakeup("garbage", datetime(2026, 4, 30, 14, 0)) == 0.0

    def test_just_after_wake(self):
        # Wake 07:00, current 08:00 → 1 hour awake
        assert hours_since_last_wakeup("23:00-07:00", datetime(2026, 4, 30, 8, 0)) == 1.0

    def test_mid_afternoon(self):
        # Wake 07:00, current 14:00 → 7 hours awake
        assert hours_since_last_wakeup("23:00-07:00", datetime(2026, 4, 30, 14, 0)) == 7.0

    def test_late_night_before_sleep_window_starts(self):
        # Wake 07:00 today, current 22:00 → 15 hours awake
        # (still before declared 23:00 sleep onset, so technically supposed to be awake)
        assert hours_since_last_wakeup("23:00-07:00", datetime(2026, 4, 30, 22, 0)) == 15.0

    def test_three_am_user_should_be_asleep_but_isnt(self):
        # Wake 07:00 yesterday (last wake), current 03:00 today
        # → 20 hours awake. User is up at 3am — exactly the tilt scenario.
        assert hours_since_last_wakeup("23:00-07:00", datetime(2026, 4, 30, 3, 0)) == 20.0

    def test_pre_wakeup_uses_yesterday(self):
        # Wake 07:00, current 06:00 → still asleep per window → 23 hours
        # since yesterday's wake
        assert hours_since_last_wakeup("23:00-07:00", datetime(2026, 4, 30, 6, 0)) == 23.0

    def test_exact_wake_moment(self):
        # Current = wake → 0 hours
        assert hours_since_last_wakeup("23:00-07:00", datetime(2026, 4, 30, 7, 0)) == 0.0

    def test_one_minute_before_wake(self):
        # 06:59 — still in sleep window, last wake was yesterday 07:00
        result = hours_since_last_wakeup("23:00-07:00", datetime(2026, 4, 30, 6, 59))
        # 23h59m = 23.9833...
        assert 23.95 < result < 24.0
