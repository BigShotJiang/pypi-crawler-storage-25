"""Tests for HL HIP-4 → Polymarket parity matcher.

Pure-logic tests with a mock gamma client. The CLI integration (`regard hl
outcome <id> --parity`) is exercised via test_hl_outcomes_commands.py.
"""

from unittest.mock import MagicMock

from regard.venues.polymarket.parity import find_polymarket_equivalent


def _hl_outcome(
    outcome: int = 2,
    underlying: str = "BTC",
    expiry: str = "20260505-0600",
    target_price: str = "80000",
) -> dict:
    return {
        "outcome": outcome,
        "name": "Recurring",
        "description": f"class:priceBinary|underlying:{underlying}|expiry:{expiry}|targetPrice:{target_price}|period:1d",
        "parsed_description": {
            "class": "priceBinary",
            "underlying": underlying,
            "expiry": expiry,
            "target_price": target_price,
            "period": "1d",
        },
        "sides": [],
    }


def _gamma_returning(markets: list[dict]) -> MagicMock:
    """Build a mock gamma httpx client whose `.get('/markets', ...)` returns
    the given markets list."""
    resp = MagicMock()
    resp.json.return_value = markets
    client = MagicMock()
    client.get.return_value = resp
    return client


def test_finds_themed_match_by_underlying_keyword():
    """A Polymarket market matching the underlying keyword + end-date window."""
    pm_market = {
        "id": "12345",
        "conditionId": "0xabc",
        "slug": "bitcoin-up-or-down-may-5",
        "question": "Bitcoin up or down on May 5?",
        "outcomePrices": '["0.55", "0.45"]',
        "endDateIso": "2026-05-05T23:59:00Z",
        "active": True,
        "closed": False,
    }
    gamma = _gamma_returning([pm_market])
    result = find_polymarket_equivalent(_hl_outcome(), gamma)
    assert result is not None
    assert result["market_id"] == "12345"
    assert result["yes_price"] == "0.55"
    assert result["no_price"] == "0.45"
    assert result["match_quality"] in ("themed", "exact")


def test_exact_match_when_target_price_appears_in_question():
    """Question contains both 'bitcoin' and the target strike → exact tier."""
    pm_market = {
        "id": "67890",
        "conditionId": "0xdef",
        "slug": "bitcoin-above-80000-may-5",
        "question": "Will Bitcoin be above $80,000 on May 5?",
        "outcomePrices": '["0.42", "0.58"]',
        "endDateIso": "2026-05-05T06:00:00Z",
        "active": True,
        "closed": False,
    }
    gamma = _gamma_returning([pm_market])
    result = find_polymarket_equivalent(_hl_outcome(target_price="80000"), gamma)
    assert result is not None
    assert result["match_quality"] == "exact"


def test_returns_none_when_no_keyword_match():
    """A market about an unrelated event must not be returned for a BTC HL."""
    pm_market = {
        "id": "999",
        "slug": "election-result-2028",
        "question": "Will candidate X win the 2028 election?",
        "outcomePrices": '["0.50", "0.50"]',
        "endDateIso": "2026-05-05T23:59:00Z",
        "active": True,
        "closed": False,
    }
    gamma = _gamma_returning([pm_market])
    assert find_polymarket_equivalent(_hl_outcome(), gamma) is None


def test_returns_none_when_end_date_out_of_window():
    """Bitcoin market with end_date 5 days off → outside ±36h, skipped."""
    pm_market = {
        "id": "111",
        "slug": "bitcoin-end-of-month",
        "question": "Will Bitcoin be above $80,000 by end of May?",
        "outcomePrices": '["0.30", "0.70"]',
        "endDateIso": "2026-05-31T23:59:00Z",
        "active": True,
        "closed": False,
    }
    gamma = _gamma_returning([pm_market])
    assert find_polymarket_equivalent(_hl_outcome(), gamma) is None


def test_returns_none_when_end_date_unparsable():
    """Markets without a parsable endDateIso are excluded — better silent
    than spurious match."""
    pm_market = {
        "id": "222",
        "slug": "bitcoin-no-date",
        "question": "Bitcoin price prediction",
        "outcomePrices": '["0.50", "0.50"]',
        "endDateIso": "",
        "active": True,
        "closed": False,
    }
    gamma = _gamma_returning([pm_market])
    assert find_polymarket_equivalent(_hl_outcome(), gamma) is None


def test_returns_none_when_unknown_underlying():
    """An underlying without a manual keyword map entry returns None — we'd
    rather acknowledge the gap than pull an unrelated themed market."""
    gamma = _gamma_returning([{
        "id": "333", "slug": "x", "question": "x",
        "outcomePrices": '["0.5","0.5"]',
        "endDateIso": "2026-05-05T06:00:00Z",
    }])
    assert find_polymarket_equivalent(_hl_outcome(underlying="WEIRD"), gamma) is None


def test_picks_highest_score_when_multiple_candidates():
    pm_low = {
        "id": "low", "slug": "bitcoin-march", "question": "Bitcoin in March",
        "outcomePrices": '["0.5","0.5"]',
        "endDateIso": "2026-05-05T23:59:00Z",
    }
    pm_high = {
        "id": "high", "slug": "bitcoin-above-80000-may-5",
        "question": "Will Bitcoin be above $80,000 on May 5?",
        "outcomePrices": '["0.42","0.58"]',
        "endDateIso": "2026-05-05T06:00:00Z",
    }
    gamma = _gamma_returning([pm_low, pm_high])
    result = find_polymarket_equivalent(_hl_outcome(), gamma)
    assert result is not None
    assert result["market_id"] == "high"


def test_gamma_failure_returns_none():
    client = MagicMock()
    client.get.side_effect = Exception("network down")
    assert find_polymarket_equivalent(_hl_outcome(), client) is None


def test_non_list_response_returns_none():
    resp = MagicMock()
    resp.json.return_value = {"error": "rate limited"}
    client = MagicMock()
    client.get.return_value = resp
    assert find_polymarket_equivalent(_hl_outcome(), client) is None


def test_short_outcomePrices_returns_none():
    """Malformed Polymarket response (only one price) → skip."""
    pm_market = {
        "id": "777",
        "slug": "bitcoin-may-5",
        "question": "Bitcoin on May 5",
        "outcomePrices": '["0.5"]',
        "endDateIso": "2026-05-05T06:00:00Z",
    }
    gamma = _gamma_returning([pm_market])
    assert find_polymarket_equivalent(_hl_outcome(), gamma) is None


def test_eth_underlying_finds_ethereum_market():
    """Underlying ETH maps to keyword 'ethereum' — confirms the map covers
    more than just BTC."""
    pm_market = {
        "id": "eth1",
        "slug": "ethereum-above-3000-may-5",
        "question": "Will Ethereum be above $3,000 on May 5?",
        "outcomePrices": '["0.6","0.4"]',
        "endDateIso": "2026-05-05T23:59:00Z",
    }
    gamma = _gamma_returning([pm_market])
    result = find_polymarket_equivalent(
        _hl_outcome(underlying="ETH", target_price="3000"), gamma,
    )
    assert result is not None
    assert result["market_id"] == "eth1"


# ---------------------------------------------------------------------------
# v0.23.3 peer-review regression tests
# ---------------------------------------------------------------------------


def test_returns_none_when_hl_expiry_unparsable():
    """PARITY-EXPIRY-SKIP — Important (peer-review v0.23.3 ratchet).

    When parse_expiry returns None (HL changes the expiry format), the
    function MUST return None instead of skipping the date gate. Pre-fix,
    the gate was conditional on `expiry_dt is not None`, so an unparsable
    HL expiry let any active same-underlying Polymarket market be returned
    as 'parity'. The function's own docstring/comment said 'better to
    return None than mislead' — code now matches intent.
    """
    pm_market = {
        "id": "12345",
        "slug": "bitcoin-above-80000-may-5",
        "question": "Will Bitcoin be above $80,000 on May 5?",
        "outcomePrices": '["0.42", "0.58"]',
        "endDateIso": "2026-05-05T06:00:00Z",
    }
    gamma = _gamma_returning([pm_market])
    # Build an HL outcome whose expiry won't parse.
    bad = _hl_outcome()
    bad["parsed_description"]["expiry"] = "garbage-format"
    assert find_polymarket_equivalent(bad, gamma) is None
    # Critical observation: gamma_client.get must not even have been
    # called — short-circuit happens before the network round-trip.
    gamma.get.assert_not_called()


def test_formatted_price_with_commas_scores_exact():
    """COMMA-BONUS-DEAD — Style (peer-review v0.23.3 ratchet).

    Polymarket commonly formats prices as "$80,000" in question text, not
    "80000". Pre-fix, the bonus check `,{rounded_k:03d}` produced ",080"
    for 80k strikes — never matched. Post-fix, the function checks the
    canonical `f"{price_int:,}"` form and awards the +3 target-price
    bonus, lifting the match to `match_quality: "exact"` instead of
    `"themed"` (which is what live Cycle H would have surfaced if the
    PM slug had used the commaless form).
    """
    pm_market = {
        "id": "fmt1",
        "slug": "bitcoin-may-5",  # raw-integer NOT in slug
        "question": "Will Bitcoin be above $80,000 on May 5?",
        "outcomePrices": '["0.42", "0.58"]',
        "endDateIso": "2026-05-05T06:00:00Z",
    }
    gamma = _gamma_returning([pm_market])
    result = find_polymarket_equivalent(
        _hl_outcome(target_price="80000"), gamma,
    )
    assert result is not None
    # 'bitcoin' → +2, 'btc' (slug) → +2 = 4. Plus formatted '80,000' → +3 = 7.
    # Plus '80k' phrasing if present (no), so final score = 7 → "exact".
    assert result["match_quality"] == "exact"
    assert result["score"] >= 5


def test_parity_response_always_has_spread_keys():
    """PARITY-SPREAD-DOC-DRIFT — Contested → fixed (peer-review v0.23.3
    ratchet). The docstring promises `spread_yes` and `spread_no`; the
    function now returns them as empty strings by default. CLI command
    overwrites with computed values when HL mids are available."""
    pm_market = {
        "id": "spread1",
        "slug": "bitcoin-may-5",
        "question": "Bitcoin May 5",
        "outcomePrices": '["0.5", "0.5"]',
        "endDateIso": "2026-05-05T06:00:00Z",
    }
    gamma = _gamma_returning([pm_market])
    result = find_polymarket_equivalent(_hl_outcome(), gamma)
    assert result is not None
    assert "spread_yes" in result
    assert "spread_no" in result
    assert result["spread_yes"] == ""  # placeholder for CLI to fill
    assert result["spread_no"] == ""
