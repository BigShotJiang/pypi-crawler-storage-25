"""Tests for regard config command."""

import json
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


def test_config_show_default():
    """config show returns default polygon_rpc when no override set."""
    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["ok"] is True
    rpc = data["data"]["polygon_rpc"]
    assert rpc["current"] == "https://polygon-rpc.com"
    assert rpc["source"] == "default"
    assert rpc["default"] == rpc["current"]


def test_config_show_custom(tmp_path, monkeypatch):
    """config show reflects POLYGON_RPC from project-local settings file."""
    # Use distinct HOME and CWD so the settings walk-up doesn't stop at HOME
    # before reaching our project dir.
    project = tmp_path / "project"
    project.mkdir()
    settings = project / ".regard" / "config.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {"POLYGON_RPC": "https://custom-rpc.example.com"}}))
    monkeypatch.chdir(project)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    rpc = data["data"]["polygon_rpc"]
    assert rpc["current"] == "https://custom-rpc.example.com"
    assert rpc["source"] == "settings"
    assert rpc["default"] == "https://polygon-rpc.com"


# ---------------------------------------------------------------------------
# `regard config set` — writes project-local settings
# ---------------------------------------------------------------------------


def _project_env(path):
    """Parse the env block from a config.json file."""
    return json.loads(path.read_text()).get("env", {})


class TestConfigSetKillswitchAddress:
    def test_valid_address_written(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        addr = "0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14"
        result = runner.invoke(app, ["config", "set", "killswitch-address", addr])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["ok"] is True
        assert data["data"]["value"] == addr

        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["KILLSWITCH_ADDRESS"] == addr

    def test_invalid_address_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "killswitch-address", "0xbadbad"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_ADDRESS"
        # File should NOT exist — we validate before touching disk
        assert not (project / ".regard" / "config.json").exists()

    def test_rejects_same_as_trading_wallet(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        trading_addr = "0x1234567890abcdef1234567890abcdef12345678"
        # Seed a trading key so _trading_address() resolves to trading_addr
        mock_account = MagicMock(address=trading_addr)
        with patch("eth_account.Account.from_key", return_value=mock_account):
            with patch.dict("os.environ", {"HYPERLIQUID_PRIVATE_KEY": "0x" + "a" * 64}):
                result = runner.invoke(app, ["config", "set", "killswitch-address", trading_addr])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "SAME_AS_TRADING_WALLET"


class TestConfigSetSlippage:
    def test_valid_slippage(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "killswitch-slippage", "0.15"])
        assert result.exit_code == 0
        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["KILLSWITCH_SLIPPAGE"] == "0.15"

    def test_out_of_range(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "killswitch-slippage", "1.5"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_SLIPPAGE"

    def test_non_numeric(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "killswitch-slippage", "abc"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_SLIPPAGE"


class TestConfigSetUrl:
    def test_polygon_rpc(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "polygon-rpc", "https://my-rpc.example.com"])
        assert result.exit_code == 0
        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["POLYGON_RPC"] == "https://my-rpc.example.com"

    def test_rejects_non_url(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "polygon-rpc", "not-a-url"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_URL"


class TestConfigSetUnknownKey:
    def test_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "mystery-setting", "value"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "UNKNOWN_SETTING"
        # Hint should list valid keys (existing flat env-style + tilt-* keys)
        assert "killswitch-address" in envelope["error"]["hint"]
        assert "tilt-daily-loss-budget-usd" in envelope["error"]["hint"]


class TestConfigSetPendingTTL:
    def test_valid_ttl(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "pending-ttl-minutes", "5"])
        assert result.exit_code == 0
        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["PENDING_TTL_MINUTES"] == "5"

    def test_rejects_zero(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "pending-ttl-minutes", "0"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_TTL"

    def test_rejects_over_max(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "pending-ttl-minutes", "1441"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_TTL"

    def test_rejects_non_integer(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "pending-ttl-minutes", "15.5"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_TTL"


class TestConfigSetSendSafety:
    def test_send_max_amount(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "send-max-amount", "25"])
        assert result.exit_code == 0
        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["SEND_MAX_AMOUNT"] == "25.0"

    def test_send_daily_max(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "send-daily-max", "100.50"])
        assert result.exit_code == 0
        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["SEND_DAILY_MAX"] == "100.5"

    def test_send_cooldown(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "send-cooldown-seconds", "60"])
        assert result.exit_code == 0
        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["SEND_COOLDOWN"] == "60"

    def test_send_cooldown_zero_allowed(self, tmp_path, monkeypatch):
        """Cooldown = 0 disables the check; should be accepted."""
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "send-cooldown-seconds", "0"])
        assert result.exit_code == 0
        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["SEND_COOLDOWN"] == "0"

    def test_send_max_rejects_zero(self, tmp_path, monkeypatch):
        """Zero is not a valid per-op cap — must be strictly positive."""
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "send-max-amount", "0"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_NUMBER"

    def test_send_max_rejects_non_numeric(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "send-max-amount", "abc"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_NUMBER"

    def test_send_allow_raw_address_bool(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "send-allow-raw-address", "yes"])
        assert result.exit_code == 0
        settings_path = project / ".regard" / "config.json"
        assert _project_env(settings_path)["SEND_ALLOW_RAW_ADDRESS"] == "true"

    def test_send_allow_raw_address_invalid(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "send-allow-raw-address", "maybe"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_BOOL"


class TestConfigShowWithNewSettings:
    def test_pending_ttl_and_send_caps_in_output(self, tmp_path, monkeypatch):
        """config show surfaces pending_ttl_minutes + send_* even when defaults."""
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0
        d = json.loads(result.output)["data"]
        assert d["pending_ttl_minutes"]["current"] == 15
        assert d["pending_ttl_minutes"]["source"] == "default"
        assert d["send_max_amount"]["configured"] is False
        assert d["send_daily_max"]["configured"] is False
        assert d["send_cooldown_seconds"]["current"] == 30
        assert d["send_allow_raw_address"]["current"] is False


class TestConfigSetPreservesOtherEntries:
    def test_merges_without_clobbering(self, tmp_path, monkeypatch):
        """Writing KILLSWITCH_ADDRESS must not wipe other env or top-level keys."""
        project = tmp_path / "project"
        project.mkdir()
        settings_path = project / ".regard" / "config.json"
        settings_path.parent.mkdir(parents=True)
        settings_path.write_text(json.dumps({
            "permissions": {"allow": ["Bash(ls)"]},
            "env": {
                "HYPERLIQUID_PRIVATE_KEY": "0x" + "a" * 64,
                "POLYMARKET_PRIVATE_KEY": "0x" + "a" * 64,
                "UNRELATED_VAR": "keep",
            },
        }))

        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(
            app,
            ["config", "set", "killswitch-address", "0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14"],
        )
        assert result.exit_code == 0

        data = json.loads(settings_path.read_text())
        assert data["permissions"]["allow"] == ["Bash(ls)"]
        assert data["env"]["HYPERLIQUID_PRIVATE_KEY"] == "0x" + "a" * 64
        assert data["env"]["POLYMARKET_PRIVATE_KEY"] == "0x" + "a" * 64
        assert data["env"]["UNRELATED_VAR"] == "keep"
        assert data["env"]["KILLSWITCH_ADDRESS"] == "0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14"


# ---------------------------------------------------------------------------
# Tilt config — typed values in the `tilt` block of config.json
# ---------------------------------------------------------------------------


def _project_tilt(path):
    """Parse the tilt block from a config.json file."""
    return json.loads(path.read_text()).get("tilt", {})


class TestConfigShowIncludesTilt:
    def test_tilt_defaults_surfaced(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        tilt = data["data"]["tilt"]
        # Spot-check defaults
        assert tilt["max_session_hours"] == 8
        assert tilt["sleep_thresholds_hours"] == {"yellow": 18, "orange": 24, "red": 36}
        assert tilt["polymarket"]["longshot_threshold_cents"] == 5
        assert tilt["polymarket"]["longshot_max_size_pct"] == 2.0
        assert tilt["hyperliquid"]["leverage_ratchet_threshold"] == 5
        assert tilt["first_red_pivot_enabled"] is True
        assert tilt["daily_loss_budget_usd"] is None
        assert tilt["ulysses_text"] is None
        assert tilt["asymmetric_change"]["loosening_delay_hours"] == 24


class TestConfigSetTiltScalar:
    def test_daily_loss_budget_usd_writes_as_float(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-daily-loss-budget-usd", "500"])
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert data["data"]["value"] == 500.0
        # Persisted as a typed float, not a string
        assert _project_tilt(project / ".regard" / "config.json")["daily_loss_budget_usd"] == 500.0

    def test_first_red_pivot_disabling_is_loosen_goes_pending(self, tmp_path, monkeypatch):
        # Default is True (signal active). Setting False = removing protection
        # = loosen → pending (not immediate). This validates the asymmetric
        # change rule for boolean protection flags.
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-first-red-pivot-enabled", "false"])
        assert result.exit_code == 0, result.output
        body = json.loads(result.output)["data"]
        assert "pending" in body
        assert body["pending"] == "tilt-first-red-pivot-enabled"
        assert body["requested_value"] is False
        # Config NOT yet modified — tightening is immediate, loosening waits
        cfg_path = project / ".regard" / "config.json"
        if cfg_path.exists():
            tilt = _project_tilt(cfg_path)
            # The flag is unchanged from default until tilt-confirm
            assert tilt.get("first_red_pivot_enabled", True) is True

    def test_ulysses_text_preserves_string(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        msg = "stop after 3 losses no exceptions touch grass"
        result = runner.invoke(app, ["config", "set", "tilt-ulysses-text", msg])
        assert result.exit_code == 0
        assert _project_tilt(project / ".regard" / "config.json")["ulysses_text"] == msg


class TestConfigSetTiltNested:
    def test_polymarket_longshot_threshold_tighten_writes_immediately(self, tmp_path, monkeypatch):
        # Default is 5¢. Higher threshold = tighter (more positions caught).
        # Set to 7 = tighten = immediate.
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-pm-longshot-threshold-cents", "7"])
        assert result.exit_code == 0, result.output
        tilt = _project_tilt(project / ".regard" / "config.json")
        assert tilt["polymarket"]["longshot_threshold_cents"] == 7

    def test_polymarket_longshot_threshold_loosen_goes_pending(self, tmp_path, monkeypatch):
        # Set to 3 from default 5 — lower = looser (fewer positions caught) → pending
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-pm-longshot-threshold-cents", "3"])
        assert result.exit_code == 0, result.output
        body = json.loads(result.output)["data"]
        assert "pending" in body

    def test_sleep_yellow_writes_to_nested_thresholds(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-sleep-yellow-hours", "16"])
        assert result.exit_code == 0
        tilt = _project_tilt(project / ".regard" / "config.json")
        assert tilt["sleep_thresholds_hours"]["yellow"] == 16


class TestConfigSetTiltValidation:
    def test_non_numeric_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-pm-longshot-threshold-cents", "abc"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_NUMBER"
        # File should NOT exist — validate-before-write
        assert not (project / ".regard" / "config.json").exists()

    def test_zero_pct_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        # 0 is at the boundary — must be > 0 for a percentage budget
        result = runner.invoke(app, ["config", "set", "tilt-pm-longshot-max-size-pct", "0"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_PERCENT"

    def test_pct_over_100_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-pm-longshot-max-size-pct", "150"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_PERCENT"

    def test_invalid_sleep_window_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-sleep-window-local", "11pm-7am"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_TIME_WINDOW"

    def test_valid_sleep_window_accepted(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-sleep-window-local", "23:00-07:00"])
        assert result.exit_code == 0
        assert _project_tilt(project / ".regard" / "config.json")["sleep_window_local"] == "23:00-07:00"

    def test_invalid_bool_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-first-red-pivot-enabled", "maybe"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_BOOL"

    def test_nan_budget_rejected(self, tmp_path, monkeypatch):
        # Regression: float("NaN") <= 0 is False, would silently disable the
        # daily-budget hard stop. Validator must reject non-finite numbers.
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-daily-loss-budget-usd", "NaN"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_NUMBER"
        assert "finite" in envelope["error"]["message"].lower()

    def test_infinity_budget_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-daily-loss-budget-usd", "Infinity"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_NUMBER"

    def test_nan_pct_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-pm-longshot-max-size-pct", "NaN"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_PERCENT"

    def test_sleep_window_24_hour_rejected(self, tmp_path, monkeypatch):
        # Regression: regex alone matched "24:00-07:00", but downstream
        # parser silently rejected it, leaving sleep signal permanently 0.
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-sleep-window-local", "24:00-07:00"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_TIME_WINDOW"

    def test_sleep_window_minutes_60_rejected(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-sleep-window-local", "23:60-07:00"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "INVALID_TIME_WINDOW"


class TestConfigSetTiltNullClears:
    def test_null_clearing_is_loosen_goes_pending(self, tmp_path, monkeypatch):
        # Setting daily-loss-budget-usd from 500 to null = removing protection = loosen
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        # Adding the budget initially = tighten (None → 500), immediate
        runner.invoke(app, ["config", "set", "tilt-daily-loss-budget-usd", "500"])
        # Now clearing it = loosen → pending
        result = runner.invoke(app, ["config", "set", "tilt-daily-loss-budget-usd", "null"])
        assert result.exit_code == 0
        body = json.loads(result.output)["data"]
        assert "pending" in body
        # Original value still present
        assert _project_tilt(project / ".regard" / "config.json")["daily_loss_budget_usd"] == 500.0

    def test_empty_string_clearing_ulysses_is_loosen_goes_pending(self, tmp_path, monkeypatch):
        # Adding text = tighten, immediate. Clearing = loosen, pending.
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        runner.invoke(app, ["config", "set", "tilt-ulysses-text", "max 2 losses per day"])
        result = runner.invoke(app, ["config", "set", "tilt-ulysses-text", ""])
        assert result.exit_code == 0
        body = json.loads(result.output)["data"]
        assert "pending" in body
        # Text preserved until tilt-confirm
        assert _project_tilt(project / ".regard" / "config.json")["ulysses_text"] == "max 2 losses per day"


class TestTiltAsymmetricChangeCLI:
    """End-to-end smoke tests for the asymmetric change rule via CLI."""

    def test_tighten_applies_immediately(self, tmp_path, monkeypatch):
        # Default max_session_hours is 8; setting 6 = lower = tighter
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-max-session-hours", "6"])
        assert result.exit_code == 0, result.output
        body = json.loads(result.output)["data"]
        assert body.get("direction") == "tighten"
        assert _project_tilt(project / ".regard" / "config.json")["max_session_hours"] == 6

    def test_loosen_writes_pending_not_config(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "set", "tilt-max-session-hours", "12"])
        assert result.exit_code == 0, result.output
        body = json.loads(result.output)["data"]
        assert "pending" in body
        assert body["requested_value"] == 12
        assert body["current_value"] == 8
        # Cooling-off message present
        assert "cooling-off" in body["message"]

    def test_tilt_pending_lists_entries(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        runner.invoke(app, ["config", "set", "tilt-max-session-hours", "12"])
        result = runner.invoke(app, ["config", "tilt-pending"])
        assert result.exit_code == 0
        body = json.loads(result.output)["data"]
        assert body["count"] == 1
        assert body["pending"][0]["cli_key"] == "tilt-max-session-hours"
        # Computed fields present
        assert "ready" in body["pending"][0]
        assert "remaining_seconds" in body["pending"][0]

    def test_tilt_cancel_removes_pending(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        # Create a pending
        r1 = runner.invoke(app, ["config", "set", "tilt-max-session-hours", "12"])
        pending_id = json.loads(r1.output)["data"]["id"]
        # Cancel it
        result = runner.invoke(app, ["config", "tilt-cancel", pending_id])
        assert result.exit_code == 0
        body = json.loads(result.output)["data"]
        assert body["cancelled"] == pending_id
        # No more pending
        r2 = runner.invoke(app, ["config", "tilt-pending"])
        assert json.loads(r2.output)["data"]["count"] == 0

    def test_tilt_confirm_too_early_rejects(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        # Create pending
        r1 = runner.invoke(app, ["config", "set", "tilt-max-session-hours", "12"])
        pending_id = json.loads(r1.output)["data"]["id"]
        # Try to confirm immediately — should reject
        result = runner.invoke(app, ["config", "tilt-confirm", pending_id])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "TOO_EARLY"

    def test_tighten_after_pending_cancels_stale_pending(self, tmp_path, monkeypatch):
        """Regression (peer-review #2): without cancellation, sequence
        loosen→tighten→confirm-pending would apply stale loosening against
        the new tighter baseline, fully bypassing the Ulysses contract.
        """
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        # Step 1: loosen 8→12 → pending
        r1 = runner.invoke(app, ["config", "set", "tilt-max-session-hours", "12"])
        pending_id = json.loads(r1.output)["data"]["id"]
        # Step 2: tighten 8→4 → immediate, must cancel the pending
        r2 = runner.invoke(app, ["config", "set", "tilt-max-session-hours", "4"])
        body2 = json.loads(r2.output)["data"]
        assert body2.get("direction") == "tighten"
        assert body2.get("cancelled_pending") == 1
        # Step 3: pending list now empty
        r3 = runner.invoke(app, ["config", "tilt-pending"])
        assert json.loads(r3.output)["data"]["count"] == 0
        # Step 4: confirming the (now-cancelled) pending fails not_found
        r4 = runner.invoke(app, ["config", "tilt-confirm", pending_id])
        assert r4.exit_code == 2
        envelope = json.loads(r4.output)
        assert envelope["error"]["code"] == "PENDING_NOT_FOUND"
        # Config still at the tightened value, not bypassed
        cfg = json.loads((project / ".regard" / "config.json").read_text())
        assert cfg["tilt"]["max_session_hours"] == 4

    def test_tilt_cancel_missing_id_errors(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        result = runner.invoke(app, ["config", "tilt-cancel", "doesnotexist"])
        assert result.exit_code == 2
        envelope = json.loads(result.output)
        assert envelope["error"]["code"] == "PENDING_NOT_FOUND"


class TestLoadTiltConfig:
    def test_defaults_when_no_user_config(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        from regard.core.project_state import load_tilt_config
        cfg = load_tilt_config()
        assert cfg["max_session_hours"] == 8
        assert cfg["polymarket"]["longshot_threshold_cents"] == 5

    def test_user_values_merge_on_defaults(self, tmp_path, monkeypatch):
        project = tmp_path / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        # Write a partial user config — only overrides longshot_threshold_cents
        config_path = project / ".regard" / "config.json"
        config_path.parent.mkdir(parents=True)
        config_path.write_text(json.dumps({
            "tilt": {
                "polymarket": {"longshot_threshold_cents": 3},
                "max_session_hours": 6,
            }
        }))

        from regard.core.project_state import load_tilt_config
        cfg = load_tilt_config()
        # User overrides applied
        assert cfg["polymarket"]["longshot_threshold_cents"] == 3
        assert cfg["max_session_hours"] == 6
        # Untouched defaults preserved (deep merge, not replacement)
        assert cfg["polymarket"]["longshot_max_size_pct"] == 2.0
        assert cfg["sleep_thresholds_hours"] == {"yellow": 18, "orange": 24, "red": 36}
