"""Tests for the Gamma client's retry/jitter/Retry-After behavior.

Polymarket's Gamma API can blip with transient 5xx or 429 under load. The
client wraps httpx with exponential backoff + jitter so a single hiccup
doesn't surface as a hard CLI error.
"""

from unittest.mock import patch

import httpx
import pytest

from regard.venues.polymarket.client import _RetryingHttpxClient


class _FakeTransport(httpx.BaseTransport):
    """Returns scripted responses in order, then raises if exhausted."""

    def __init__(self, scripted):
        self._scripted = list(scripted)
        self.call_count = 0
        self.urls = []

    def handle_request(self, request):
        self.call_count += 1
        self.urls.append(str(request.url))
        if not self._scripted:
            return httpx.Response(200, json={"ok": True})
        item = self._scripted.pop(0)
        if isinstance(item, Exception):
            raise item
        status, headers, body = item
        return httpx.Response(status, headers=headers, json=body)


def _client(transport):
    return _RetryingHttpxClient(
        transport=transport,
        base_url="https://gamma-api.polymarket.com",
        timeout=30.0,
    )


@pytest.fixture(autouse=True)
def _no_sleep():
    with patch("time.sleep"):
        yield


class TestRetryOn429:
    def test_retries_then_succeeds(self):
        transport = _FakeTransport([
            (429, {}, {}),
            (429, {}, {}),
            (200, {}, {"ok": True}),
        ])
        c = _client(transport)
        resp = c.get("/markets")
        assert resp.status_code == 200
        assert transport.call_count == 3

    def test_returns_429_after_exhaustion(self):
        # 5 retries → 5 attempts; all 429 → return last response with 429
        transport = _FakeTransport([(429, {}, {})] * 5)
        c = _client(transport)
        resp = c.get("/markets")
        assert resp.status_code == 429
        assert transport.call_count == 5


class TestRetryOn5xx:
    @pytest.mark.parametrize("code", [500, 502, 503, 504])
    def test_5xx_retries(self, code):
        transport = _FakeTransport([
            (code, {}, {}),
            (200, {}, {"ok": True}),
        ])
        c = _client(transport)
        resp = c.get("/markets")
        assert resp.status_code == 200
        assert transport.call_count == 2


class TestNo4xxRetry:
    """Non-429 4xx must surface immediately — caller logic depends on this."""

    @pytest.mark.parametrize("code", [400, 401, 403, 404, 422])
    def test_4xx_does_not_retry(self, code):
        transport = _FakeTransport([(code, {}, {})])
        c = _client(transport)
        resp = c.get("/markets")
        assert resp.status_code == code
        assert transport.call_count == 1


class TestNetworkErrorRetry:
    def test_network_error_retries_then_succeeds(self):
        transport = _FakeTransport([
            httpx.ConnectError("dns failed"),
            httpx.ReadTimeout("slow"),
            (200, {}, {"ok": True}),
        ])
        c = _client(transport)
        resp = c.get("/markets")
        assert resp.status_code == 200
        assert transport.call_count == 3

    def test_network_error_raises_after_exhaustion(self):
        transport = _FakeTransport([httpx.ConnectError("dns failed")] * 5)
        c = _client(transport)
        with pytest.raises(httpx.ConnectError):
            c.get("/markets")
        assert transport.call_count == 5


class TestRetryAfterHeader:
    def test_retry_after_seconds_used_for_delay(self):
        """When Retry-After is present, the client sleeps for that duration."""
        transport = _FakeTransport([
            (429, {"retry-after": "2"}, {}),
            (200, {}, {"ok": True}),
        ])
        c = _client(transport)
        with patch("time.sleep") as sleep:
            c.get("/markets")
        # sleep called once between the two attempts; first arg is the delay
        sleep.assert_called_once()
        delay = sleep.call_args[0][0]
        assert delay == pytest.approx(2.0, abs=0.001)

    def test_retry_after_capped(self):
        """Hostile-header large Retry-After is capped to _MAX_RA_SLEEP."""
        transport = _FakeTransport([
            (429, {"retry-after": "9999"}, {}),
            (200, {}, {"ok": True}),
        ])
        c = _client(transport)
        with patch("time.sleep") as sleep:
            c.get("/markets")
        delay = sleep.call_args[0][0]
        assert delay == pytest.approx(_RetryingHttpxClient._MAX_RA_SLEEP)

    def test_unparseable_retry_after_falls_back_to_backoff(self):
        transport = _FakeTransport([
            (429, {"retry-after": "tomorrow"}, {}),
            (200, {}, {"ok": True}),
        ])
        c = _client(transport)
        with patch("time.sleep") as sleep:
            c.get("/markets")
        # Falls back to attempt-0 backoff: ~1s ± 20% jitter
        delay = sleep.call_args[0][0]
        assert 0.7 <= delay <= 1.3


class TestBackoffWithJitter:
    def test_backoff_grows_exponentially(self):
        """Each successive 429 should produce a longer backoff (modulo jitter)."""
        transport = _FakeTransport([(429, {}, {})] * 5)
        c = _client(transport)
        with patch("time.sleep") as sleep:
            c.get("/markets")
        # 4 sleeps between 5 attempts. Means should ~double each step modulo jitter.
        delays = [call.args[0] for call in sleep.call_args_list]
        assert len(delays) == 4
        # Verify monotonic-ish growth: each delay is at least 60% of double the prior
        # (jitter is ±20%, so worst case (0.8)*next vs (1.2)*prior still passes 60% bound).
        for i in range(1, len(delays)):
            assert delays[i] >= delays[i - 1] * 0.6

    def test_jitter_lands_in_expected_band(self):
        """Each backoff delay sits in [base * (1 - jitter), base * (1 + jitter)].

        Tests jitter is *applied* (vs. exact-equality between runs, which can
        flake under deterministic test ordering / pytest-randomly seeds).
        """
        transport = _FakeTransport([(429, {}, {})] * 5)
        c = _client(transport)
        with patch("time.sleep") as sleep:
            c.get("/markets")

        base_for = lambda attempt: min(  # noqa: E731 — local helper, not an abstraction
            _RetryingHttpxClient._BASE_DELAY * (2**attempt),
            _RetryingHttpxClient._MAX_DELAY,
        )
        spread = _RetryingHttpxClient._JITTER
        for attempt, call in enumerate(sleep.call_args_list):
            base = base_for(attempt)
            delay = call.args[0]
            assert base * (1 - spread) <= delay <= base * (1 + spread), (
                f"attempt {attempt}: delay {delay} outside [{base * (1 - spread)}, {base * (1 + spread)}]"
            )

    def test_jitter_is_not_constant(self):
        """Jitter must actually vary — using sufficient samples to drown PRNG luck."""
        transport = _FakeTransport([(429, {}, {})] * 5)
        c = _client(transport)
        with patch("time.sleep") as sleep:
            c.get("/markets")
        delays = [call.args[0] for call in sleep.call_args_list]
        # 4 sleeps with independent jitter — at least 3 distinct floats virtually
        # always (collision probability is ~0 with float jitter).
        assert len(set(delays)) >= 3
