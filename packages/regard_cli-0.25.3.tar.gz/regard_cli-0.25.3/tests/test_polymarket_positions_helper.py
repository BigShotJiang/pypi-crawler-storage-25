"""Tests for venues/polymarket/positions_helper.py — long-shot detection
with thesis check."""

from unittest.mock import patch

from regard.venues.polymarket.positions_helper import (
    count_unguarded_longshots,
    fetch_polymarket_positions,
    has_recent_thesis,
)

# ---------------------------------------------------------------------------
# fetch_polymarket_positions — graceful degradation
# ---------------------------------------------------------------------------


class TestFetchPolymarketPositions:
    def test_get_positions_exception_returns_empty(self):
        with patch("regard.venues.polymarket.client.get_positions",
                   side_effect=RuntimeError("CLOB unreachable")):
            assert fetch_polymarket_positions() == []

    def test_get_positions_systemexit_returns_empty(self):
        # die() raises SystemExit — must be caught
        with patch("regard.venues.polymarket.client.get_positions",
                   side_effect=SystemExit(2)):
            assert fetch_polymarket_positions() == []

    def test_non_list_returns_empty(self):
        with patch("regard.venues.polymarket.client.get_positions",
                   return_value=None):
            assert fetch_polymarket_positions() == []

    def test_normal_pass_through(self):
        sample = [{"market": "Trump 2032", "cur_price": "0.04"}]
        with patch("regard.venues.polymarket.client.get_positions",
                   return_value=sample):
            assert fetch_polymarket_positions() == sample


# ---------------------------------------------------------------------------
# has_recent_thesis — gg/ markdown scan
# ---------------------------------------------------------------------------


class TestHasRecentThesis:
    def test_empty_title_returns_false(self, tmp_path):
        assert has_recent_thesis("", tmp_path) is False

    def test_short_title_rejected(self, tmp_path):
        # min_title_length=4 by default — "BTC" too short for substring match
        assert has_recent_thesis("BTC", tmp_path) is False

    def test_no_gg_dir_returns_false(self, tmp_path):
        assert has_recent_thesis("Trump 2032 wins", tmp_path) is False

    def test_finds_market_in_research_doc(self, tmp_path):
        research = tmp_path / "gg" / "research"
        research.mkdir(parents=True)
        (research / "thesis.md").write_text(
            "Analysis: Trump 2032 wins is mispriced — see Pew polling data."
        )
        assert has_recent_thesis("Trump 2032 wins", tmp_path) is True

    def test_case_insensitive_match(self, tmp_path):
        research = tmp_path / "gg" / "research"
        research.mkdir(parents=True)
        (research / "thesis.md").write_text("trump 2032 wins is interesting")
        assert has_recent_thesis("Trump 2032 Wins", tmp_path) is True

    def test_no_match_returns_false(self, tmp_path):
        research = tmp_path / "gg" / "research"
        research.mkdir(parents=True)
        (research / "thesis.md").write_text("ETH analysis")
        assert has_recent_thesis("Trump 2032 wins", tmp_path) is False

    def test_handoff_within_24h_matches(self, tmp_path):
        handoffs = tmp_path / "gg" / "handoffs"
        handoffs.mkdir(parents=True)
        recent = handoffs / "recent.md"
        recent.write_text("watching the Trump 2032 wins market")
        # mtime is now (recent), default 24h cutoff includes it
        assert has_recent_thesis("Trump 2032 wins", tmp_path) is True

    def test_handoff_older_than_24h_excluded(self, tmp_path):
        import os
        handoffs = tmp_path / "gg" / "handoffs"
        handoffs.mkdir(parents=True)
        old = handoffs / "old.md"
        old.write_text("watched Trump 2032 wins forever ago")
        # Backdate mtime to 48h ago
        old_ts = old.stat().st_mtime - (48 * 3600)
        os.utime(old, (old_ts, old_ts))
        assert has_recent_thesis("Trump 2032 wins", tmp_path) is False

    def test_research_dir_no_age_limit(self, tmp_path):
        # research/ docs match regardless of age (research is durable)
        import os
        research = tmp_path / "gg" / "research"
        research.mkdir(parents=True)
        old = research / "long-ago.md"
        old.write_text("trump 2032 wins thesis from months back")
        old_ts = old.stat().st_mtime - (90 * 24 * 3600)
        os.utime(old, (old_ts, old_ts))
        assert has_recent_thesis("Trump 2032 wins", tmp_path) is True


# ---------------------------------------------------------------------------
# count_unguarded_longshots — composition of price filter + thesis check
# ---------------------------------------------------------------------------


class TestCountUnguardedLongshots:
    def test_empty_positions_returns_zero(self, tmp_path):
        assert count_unguarded_longshots([], tmp_path) == 0

    def test_no_project_dir_returns_zero(self):
        # Without project_dir, can't check theses → can't honestly fire
        positions = [{"market": "Trump 2032 wins", "cur_price": "0.02"}]
        assert count_unguarded_longshots(positions, None) == 0

    def test_above_threshold_skipped(self, tmp_path):
        # 0.10 > 0.05 default → not a long-shot
        positions = [{"market": "Trump 2032 wins", "cur_price": "0.10"}]
        assert count_unguarded_longshots(positions, tmp_path) == 0

    def test_at_threshold_counts(self, tmp_path):
        # 0.05 ≤ 0.05 → counts (no thesis logged)
        positions = [{"market": "Trump 2032 wins", "cur_price": "0.05"}]
        assert count_unguarded_longshots(positions, tmp_path) == 1

    def test_long_shot_with_thesis_excluded(self, tmp_path):
        research = tmp_path / "gg" / "research"
        research.mkdir(parents=True)
        (research / "trump-2032-thesis.md").write_text(
            "Trump 2032 wins thesis: see polling data..."
        )
        positions = [{"market": "Trump 2032 wins", "cur_price": "0.02"}]
        assert count_unguarded_longshots(positions, tmp_path) == 0

    def test_multiple_long_shots_counted(self, tmp_path):
        positions = [
            {"market": "Trump 2032 wins", "cur_price": "0.02"},
            {"market": "Hilary 2028 wins", "cur_price": "0.03"},
            {"market": "Bitcoin > $200k by 2027", "cur_price": "0.04"},
            {"market": "Random Higher Priced Market Title", "cur_price": "0.50"},
        ]
        # Three long-shots, none with thesis
        assert count_unguarded_longshots(positions, tmp_path) == 3

    def test_zero_price_skipped(self, tmp_path):
        # Defensive — 0 cur_price is a stale/invalid quote, not a long-shot
        positions = [{"market": "Test market title", "cur_price": "0"}]
        assert count_unguarded_longshots(positions, tmp_path) == 0

    def test_unparseable_price_skipped(self, tmp_path):
        positions = [{"market": "Test market title", "cur_price": "n/a"}]
        assert count_unguarded_longshots(positions, tmp_path) == 0

    def test_configurable_threshold(self, tmp_path):
        positions = [{"market": "Test market title", "cur_price": "0.08"}]
        # Default 0.05 → 0.08 above → 0
        assert count_unguarded_longshots(positions, tmp_path) == 0
        # Raise threshold to 0.10 → 0.08 below → 1
        assert count_unguarded_longshots(positions, tmp_path, longshot_threshold=0.10) == 1
