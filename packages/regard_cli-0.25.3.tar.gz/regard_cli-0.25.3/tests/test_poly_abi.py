"""ABI completeness tests for polymarket/client.py.

A MagicMock-based contract test doesn't catch missing ABI entries (the mock
accepts any attribute access, so `contract.functions.nonexistent()` silently
works). This test checks the ABI lists directly against the set of functions
actually called in the code.

If you add a new `contract.functions.<name>` call anywhere in the poly code,
add it to the appropriate ABI list and to the expected-set in this test.
"""

import re
from pathlib import Path

from regard.venues.polymarket.client import (
    CTF_ABI,
    CTF_MERGE_ABI,
    CTF_REDEEM_ABI,
    DECIMALS_ABI,
    ERC20_ABI,
    EXCHANGE_ABI,
    OFFRAMP_ABI,
    ONRAMP_ABI,
)

_SRC_ROOT = Path(__file__).parent.parent / "src" / "regard" / "venues" / "polymarket"


def _abi_function_names(abi: list[dict]) -> set[str]:
    return {entry["name"] for entry in abi if entry.get("type") == "function"}


def test_erc20_abi_declares_transfer():
    """The deposit executor calls `.transfer(to, amount)` — must be in the ABI.

    Regression test for v0.19.3: the deposit feature added a transfer call
    but missed adding the function to the ABI, causing EXECUTION_FAILED with
    'The function "transfer" was not found in this contract's abi.'
    """
    assert "transfer" in _abi_function_names(ERC20_ABI)


def test_erc20_abi_has_all_functions_used_in_code():
    """Grep poly src for `contract.functions.<name>` on ERC20 contracts.

    Every name we call must be declared in ERC20_ABI. Catches the same class
    of bug as the transfer regression — someone adds a new ERC20 call but
    forgets the ABI entry, which MagicMock-only tests can't detect.
    """
    erc20_names = _abi_function_names(ERC20_ABI)

    # Minimum set we know the code relies on (every one of these has failed
    # in a past or present call site).
    required = {"balanceOf", "allowance", "approve", "transfer"}
    missing = required - erc20_names
    assert not missing, f"ERC20_ABI is missing required functions: {missing}"


def test_ctf_abi_has_approval_methods():
    ctf_names = _abi_function_names(CTF_ABI)
    required = {"isApprovedForAll", "setApprovalForAll"}
    missing = required - ctf_names
    assert not missing, f"CTF_ABI is missing required functions: {missing}"


def test_onramp_abi_has_wrap():
    assert "wrap" in _abi_function_names(ONRAMP_ABI)


def test_offramp_abi_has_unwrap():
    assert "unwrap" in _abi_function_names(OFFRAMP_ABI)


def test_no_undeclared_erc20_function_calls():
    """Scan poly src for `.functions.<name>` patterns on ERC20_ABI contracts.

    Finds all function-name tokens called after `.functions.` in poly code,
    then filters down to the ones used on ERC20 contracts (approx heuristic:
    names matching methods in any of our ABIs). Asserts every ERC20-ish
    function name appearing in code is declared in ERC20_ABI, CTF_ABI,
    ONRAMP_ABI, or OFFRAMP_ABI.
    """
    # Union of all declared function names across our ABIs
    declared = (
        _abi_function_names(ERC20_ABI)
        | _abi_function_names(CTF_ABI)
        | _abi_function_names(EXCHANGE_ABI)
        | _abi_function_names(ONRAMP_ABI)
        | _abi_function_names(OFFRAMP_ABI)
        | _abi_function_names(DECIMALS_ABI)
        | _abi_function_names(CTF_REDEEM_ABI)
        | _abi_function_names(CTF_MERGE_ABI)
    )

    # Names we use from web3 library itself or from other ABIs (e.g. SDK-owned)
    # that we don't declare and shouldn't be flagged. Keep this list small.
    # Empty today; add entries with a one-line comment if a SDK-internal call
    # needs to bypass the check.
    ALLOW_UNDECLARED: set[str] = set()

    call_pattern = re.compile(r"\.functions\.([A-Za-z_][A-Za-z0-9_]*)")
    found: set[str] = set()
    for path in _SRC_ROOT.rglob("*.py"):
        text = path.read_text()
        for match in call_pattern.finditer(text):
            found.add(match.group(1))

    undeclared = found - declared - ALLOW_UNDECLARED
    assert not undeclared, (
        f"Functions called in poly src but not declared in any ABI: {sorted(undeclared)}. "
        "Add the missing entry to ERC20_ABI / CTF_ABI / ONRAMP_ABI / OFFRAMP_ABI, "
        "or add to ALLOW_UNDECLARED with justification."
    )
