"""Tests for v0.25.0 bridge surface (outbound + inbound + perp send).

Per V025-IMPLEMENTATION.md. Five new commands across two signing paths:

Outbound (HL-signed via SDK actions):
- hypercore perp bridge arbitrum --to <addr> <amount>     (withdraw_from_bridge)
- hypercore spot bridge hyperevm --to self <amount> --token <tok>  (send_asset)
- hypercore perp send <addr> <amount>                     (usd_transfer)

Inbound (EVM-signed via core/evm.py):
- arbitrum bridge hypercore --to self <amount>            (ERC-20 to Bridge2)
- hyperevm bridge hypercore --to self <amount> --token <tok>  (ERC-20 or native)
"""

import json
from decimal import Decimal
from unittest.mock import MagicMock, patch

from regard.main import app
from tests.conftest import load_fixture


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


# Address book entries for tests — both EVM addresses are checksummed.
MOCK_ADDRESSES = {
    "trading": {
        "address": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
        "chains": ["hypercore", "polygon", "arbitrum"],
        "added_at": "2026-04-16T12:00:00Z",
    },
    "reserve": {
        "address": "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411",
        "chains": ["hypercore", "polygon"],
        "added_at": "2026-04-16T12:00:00Z",
    },
}

# Mock spot_meta with a linked USDC + a HYPE entry + an unlinked custom token.
# Pulled from golden fixture for canonical tokens to satisfy Article IV.
_SPOT_GOLDEN = load_fixture("hyperliquid", "spot_meta")


def _spot_token(name: str) -> dict:
    for t in _SPOT_GOLDEN["tokens"]:
        if t["name"] == name:
            return dict(t)
    raise KeyError(f"{name} not in golden spot_meta tokens")


# Build a custom spot_meta with explicit evmContract values for testing.
# Schema MUST match the real HL API: `evmContract` is a dict
# {"address": "0x...", "evm_extra_wei_decimals": <int>}, NOT a flat string.
# Earlier mock divergence from this shape masked two critical bugs caught by
# the v0.25.0 round-3 peer review (token_address became a dict; evm extra
# decimals always read 0 because the field doesn't exist as a top-level key).
def _build_mock_spot_meta(usdc_evm_addr=None, include_unlinked=False,
                          usdc_extra_decimals=-2):
    """Build a spot_meta dict matching the real API schema.

    For canonical USDC: weiDecimals=8, evmContract.evm_extra_wei_decimals=-2
    → ERC-20 decimals = 8 + (-2) = 6 (matches native USDC's 6 decimals).
    """
    usdc_entry = _spot_token("USDC")
    # Keep weiDecimals from golden (8); override the contract to a known test addr.
    usdc_entry["evmContract"] = {
        "address": usdc_evm_addr or "0x5555555555555555555555555555555555555555",
        "evm_extra_wei_decimals": usdc_extra_decimals,
    }
    usdh_entry = _spot_token("USDH")
    usdh_entry["evmContract"] = {
        "address": "0x6666666666666666666666666666666666666666",
        "evm_extra_wei_decimals": 0,
    }
    tokens = [
        usdc_entry,
        usdh_entry,
        # HYPE has no evmContract — it's the native gas token on EVM.
        {"name": "HYPE", "index": 150, "weiDecimals": 8,
         "isCanonical": True, "tokenId": "0x" + "00" * 32, "evmContract": None},
    ]
    if include_unlinked:
        tokens.append({"name": "LICK", "index": 200, "weiDecimals": 6,
                       "isCanonical": False, "tokenId": "0x" + "ff" * 32,
                       "evmContract": None})
    return {"tokens": tokens, "universe": []}


MOCK_SPOT_META = _build_mock_spot_meta()


# ---------------------------------------------------------------------------
# Outbound: hypercore perp bridge arbitrum
# ---------------------------------------------------------------------------


class TestPerpBridgeArbitrum:
    def test_propose_to_self_succeeds(self, runner, patched):
        """--to self resolves to wallet address; proposal carries amount + chain."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None):
            patched["info"].post.side_effect = lambda endpoint, payload: (
                {"withdrawable": "100.0"} if payload.get("type") == "clearinghouseState"
                else []
            )
            result = runner.invoke(app, ["hypercore", "perp", "bridge", "arbitrum",
                                          "--to", "self", "10"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["command"] == "perp.bridge.arbitrum"
            assert d["data"]["params"]["chain"] == "arbitrum"
            # Decimal preserves the user's input representation exactly:
            # `Decimal("10")` → "10". Pre-Decimal code did float() round-trip → "10.0".
            assert d["data"]["params"]["amount"] == "10"
            # --to self ⇒ recipient_on_hl is set (locked decision 18).
            assert d["data"]["params"]["recipient_on_hl"] == "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"

    def test_propose_to_arbitrary_addr(self, runner, patched):
        """--to <addr> stores user-supplied address; recipient_on_hl unset (gate falls back to dest_address)."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={"SEND_ALLOW_RAW_ADDRESS": "true"}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None):
            patched["info"].post.side_effect = lambda endpoint, payload: (
                {"withdrawable": "100.0"} if payload.get("type") == "clearinghouseState"
                else []
            )
            result = runner.invoke(app, ["hypercore", "perp", "bridge", "arbitrum",
                                          "--to", "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411", "10"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["params"]["dest_address"] == "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411"
            assert "recipient_on_hl" not in d["data"]["params"]

    def test_missing_to_flag(self, runner, patched):
        """No --to flag fails with MISSING_DESTINATION."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hypercore", "perp", "bridge", "arbitrum", "10"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "MISSING_DESTINATION"

    def test_executor_calls_withdraw_from_bridge(self):
        """Executor invokes the right SDK method exactly once."""
        mock_exchange = MagicMock()
        mock_exchange.withdraw_from_bridge.return_value = {"status": "ok"}

        with patch("regard.venues.hyperliquid.commands.act.get_exchange", return_value=mock_exchange), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.commands.act import execute_perp_bridge_arbitrum
            result = execute_perp_bridge_arbitrum({
                "sender": "0xSENDER",
                "dest_address": "0xDEST",
                "dest_label": "test",
                "amount": "10.0",
                "chain": "arbitrum",
                "testnet": False,
            })
            mock_exchange.withdraw_from_bridge.assert_called_once_with(10.0, "0xDEST")
            assert result["status"] == "bridged"
            assert result["fee_usdc"] == "1"
            # Decimal quantize to 6 decimals (USDC precision) preserves explicit
            # zeros — more precise than float round() which trims to "9.0".
            assert result["credited_amount"] == "9.000000"


# ---------------------------------------------------------------------------
# Outbound: hypercore spot bridge hyperevm
# ---------------------------------------------------------------------------


class TestSpotBridgeHyperevm:
    def test_propose_to_self_with_usdc_succeeds(self, runner, patched):
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "100.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["params"]["token"] == "USDC"
            assert d["data"]["params"]["chain"] == "hyperevm"
            # System address is computed from the token index.
            assert d["data"]["params"]["dest_address"].startswith("0x20")
            assert d["data"]["params"]["recipient_on_hl"] == "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"

    def test_to_other_addr_rejected(self, runner, patched):
        """Any --to other than 'self' must fail (HL only credits sender)."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411", "5", "--token", "USDC"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_RECIPIENT_NOT_SELF"

    def test_missing_token(self, runner, patched):
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "MISSING_TOKEN"

    def test_token_lowercase_normalized(self, runner, patched):
        """Locked decision 15: --token usdc must route the same as --token USDC."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "100.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "usdc"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["params"]["token"] == "USDC"  # normalized

    def test_hype_routes_to_system_address(self, runner, patched):
        """HYPE special-case: dest_address is 0x222...2222."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "HYPE", "balance": "100.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "HYPE"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["params"]["dest_address"] == "0x2222222222222222222222222222222222222222"

    def test_unlinked_token_hard_blocked(self, runner, patched):
        """Locked decision 19: tokens with evmContract: None must hard-block."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "LICK", "balance": "100.0"}]):
            patched["info"].spot_meta.return_value = _build_mock_spot_meta(include_unlinked=True)
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "LICK"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_TOKEN_UNLINKED"

    def test_propose_discloses_fee_estimate_with_oracle(self, runner, patched):
        """Fee estimate is computed and disclosed when RPC + HYPE oracle are available.

        Per HL docs: 200k gas × next-block HyperEVM baseFee, charged in token-equivalent
        at the HYPE oracle rate. The proposal MUST disclose this so users can predict
        their post-bridge balance accurately. Fintech accuracy: silent under-disclosure
        of fees is a defect, not a cosmetic issue.
        """
        from decimal import Decimal

        mock_w3 = MagicMock()
        mock_w3.eth.get_block.return_value = {"baseFeePerGas": 500_000_000}  # 0.5 gwei
        mock_info_for_mids = MagicMock()
        mock_info_for_mids.all_mids.return_value = {"HYPE": "44.0"}

        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.core.rpc_pool.get_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "10.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            patched["info"].all_mids.return_value = {"HYPE": "44.0"}
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "3", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            checks = d["data"]["checks"]
            # Fee = 200_000 * 500_000_000 / 1e18 HYPE = 0.0001 HYPE
            # In USDC at $44 = 0.0044
            expected_fee = Decimal("200000") * Decimal("500000000") / Decimal(10**18) * Decimal("44.0")
            assert checks["bridge_fee_estimate"] == str(expected_fee.quantize(Decimal("0.000001")))
            assert "200,000 gas" in checks["bridge_fee_basis"]
            assert "500000000 wei" in checks["bridge_fee_basis"]
            assert "HYPE oracle $44.0" in checks["bridge_fee_basis"]
            # projected_spot = balance - amount - fee = 10 - 3 - 0.0044 = 6.9956
            expected_projected = (Decimal("10") - Decimal("3") - expected_fee).quantize(Decimal("0.000001"))
            assert checks["projected_spot"] == str(expected_projected)
            assert "next-block" in checks["bridge_fee_note"]

    def test_propose_discloses_when_estimate_unavailable(self, runner, patched):
        """When RPC or oracle is unavailable, the proposal must say so explicitly.

        Silent fallback to a zero-fee projection would mislead the user about their
        post-bridge balance. Disclaimer must include: bridge_fee_estimate='unavailable',
        formula in bridge_fee_basis, projected_spot annotated with '(excludes ...)'.
        """
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.core.rpc_pool.get_web3", side_effect=RuntimeError("RPC unreachable")), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "10.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "3", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True
            checks = d["data"]["checks"]
            assert checks["bridge_fee_estimate"] == "unavailable"
            assert "200,000 gas" in checks["bridge_fee_basis"]
            assert "USDC" in checks["bridge_fee_basis"]
            assert "Could not estimate" in checks["bridge_fee_note"]
            # projected_spot annotated to flag the missing fee deduction
            assert "excludes unestimated bridge fee" in checks["projected_spot"]

    def test_propose_hype_fee_paid_in_hype_no_oracle(self, runner, patched):
        """HYPE bridge: fee paid in HYPE itself, no oracle conversion needed.

        Validates the gas-token-only branch: 200k * baseFee (in wei) / 1e18 = HYPE.
        """
        from decimal import Decimal

        mock_w3 = MagicMock()
        mock_w3.eth.get_block.return_value = {"baseFeePerGas": 1_000_000_000}  # 1 gwei

        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.core.rpc_pool.get_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "HYPE", "balance": "10.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "3", "--token", "HYPE"])
            d = parse(result)
            assert d["ok"] is True
            checks = d["data"]["checks"]
            # Fee = 200_000 * 1e9 / 1e18 = 0.0002 HYPE
            expected_fee = Decimal("0.0002")
            assert checks["bridge_fee_estimate"] == str(expected_fee.quantize(Decimal("0.000001")))
            # No HYPE oracle string for HYPE → HYPE
            assert "HYPE oracle" not in checks["bridge_fee_basis"]
            assert "200,000 gas" in checks["bridge_fee_basis"]

    def test_propose_warns_when_fee_exceeds_remainder(self, runner, patched):
        """If estimated fee > balance - amount, propose adds BRIDGE_FEE_INSUFFICIENT_BALANCE warning.

        This is a soft warning, not a hard block — the estimate has uncertainty
        and the user may still want to attempt the bridge. But the user MUST be
        warned that the bridge will likely fail at execution time.
        """
        # Massive baseFee → large fee that will exceed the remaining balance after a tiny bridge
        mock_w3 = MagicMock()
        mock_w3.eth.get_block.return_value = {"baseFeePerGas": 10_000_000_000_000}  # 10000 gwei

        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address",
                   return_value="0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"), \
             patch("regard.venues.hyperliquid.commands.act._check_dest_native_gas", return_value=None), \
             patch("regard.core.rpc_pool.get_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_spot_balances",
                   return_value=[{"token": "USDC", "balance": "5.0"}]):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            patched["info"].all_mids.return_value = {"HYPE": "44.0"}
            result = runner.invoke(app, ["hypercore", "spot", "bridge", "hyperevm",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True
            warnings = d["data"]["warnings"]
            warning_types = [w["type"] for w in warnings]
            assert "BRIDGE_FEE_INSUFFICIENT_BALANCE" in warning_types

    def test_executor_calls_send_asset(self):
        mock_exchange = MagicMock()
        mock_exchange.send_asset.return_value = {"status": "ok"}

        with patch("regard.venues.hyperliquid.commands.act.get_exchange", return_value=mock_exchange), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.commands.act import execute_spot_bridge_hyperevm
            execute_spot_bridge_hyperevm({
                "sender": "0xSENDER",
                "dest_address": "0x20" + "00" * 19,
                "dest_label": "HYPEREVM_SYSTEM_USDC",
                "recipient_on_evm": "0xSENDER",
                "token": "USDC",
                "sdk_token": "USDC",
                "amount": "5.0",
                "chain": "hyperevm",
                "testnet": False,
            })
            mock_exchange.send_asset.assert_called_once_with(
                "0x20" + "00" * 19, "spot", "spot", "USDC", 5.0
            )


# ---------------------------------------------------------------------------
# Outbound: hypercore perp send
# ---------------------------------------------------------------------------


class TestPerpSend:
    def test_propose_to_label_succeeds(self, runner, patched):
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"):
            patched["info"].post.side_effect = lambda endpoint, payload: (
                {"withdrawable": "100.0"} if payload.get("type") == "clearinghouseState"
                else []
            )
            result = runner.invoke(app, ["hypercore", "perp", "send", "reserve", "5"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["command"] == "perp.send"
            assert d["data"]["params"]["dest_address"] == "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411"

    def test_self_send_blocked(self, runner, patched):
        with patch("regard.commands.address._load_addresses", return_value={
            "myself": {"address": "0xTEST", "chains": ["hypercore"], "added_at": ""},
        }), patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xTEST"):
            patched["info"].post.side_effect = lambda e, p: {"withdrawable": "100.0"}
            result = runner.invoke(app, ["hypercore", "perp", "send", "myself", "1"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "SELF_SEND"

    def test_unified_account_hard_blocked(self, runner, patched):
        """v0.25.1: HL disables usd_transfer when account is in unifiedAccount /
        portfolioMargin mode. Discovered live 2026-05-06: HL returns 'Action
        disabled when unified account is active' at execution. Propose must
        hard-block so the user never approves a doomed proposal — point them
        at `hypercore spot send` which works for all account modes.
        """
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.commands.act.get_account_mode",
                   return_value="unifiedAccount"):
            result = runner.invoke(app, ["hypercore", "perp", "send", "reserve", "5"])
            assert result.exit_code == 2
            d = parse(result)
            assert d["error"]["code"] == "PERP_SEND_DISABLED_UNIFIED_MODE"
            assert "unifiedAccount" in d["error"]["message"]
            assert "hypercore spot send" in d["error"]["hint"]

    def test_portfolio_margin_hard_blocked(self, runner, patched):
        """Same hard block applies to portfolioMargin mode."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.commands.act.get_account_mode",
                   return_value="portfolioMargin"):
            result = runner.invoke(app, ["hypercore", "perp", "send", "reserve", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "PERP_SEND_DISABLED_UNIFIED_MODE"

    def test_executor_calls_usd_transfer(self):
        mock_exchange = MagicMock()
        mock_exchange.usd_transfer.return_value = {"status": "ok"}

        with patch("regard.venues.hyperliquid.commands.act.get_exchange", return_value=mock_exchange), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.commands.act import execute_perp_send
            execute_perp_send({
                "sender": "0xSENDER",
                "dest_address": "0xDEST",
                "dest_label": "test",
                "amount": "5.0",
                "testnet": False,
            })
            mock_exchange.usd_transfer.assert_called_once_with(5.0, "0xDEST")


# ---------------------------------------------------------------------------
# Inbound: arbitrum bridge hypercore
# ---------------------------------------------------------------------------


class TestArbitrumBridgeHypercore:
    def _patch_w3(self, balance_eth: Decimal = Decimal("1.0"), usdc_balance_raw: int = 100_000_000):
        """Build a mocked Web3 + key + sender for inbound tests.

        balance_eth: native ETH balance in tokens (Decimal). 1.0 ETH > hard threshold.
        usdc_balance_raw: ERC-20 USDC balance in raw units (6 decimals — 100M = 100 USDC).
        """
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(balance_eth * Decimal(10**18))
        # `Web3.to_checksum_address` is a static; use a passthrough for the test.
        return sender, mock_w3

    def test_propose_to_self_succeeds(self, runner, patched):
        sender, mock_w3 = self._patch_w3()
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=100_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "5"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["command"] == "bridge.hypercore"
            assert d["data"]["params"]["chain"] == "arbitrum"
            # Bridge2 contract address is the EVM tx target.
            assert d["data"]["params"]["dest_address"] == "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7"
            assert d["data"]["params"]["recipient_on_hl"] == sender

    def test_below_min_deposit_rejected(self, runner, patched):
        """Locked decision 13: amount < 5 USDC must hard-block with MIN_DEPOSIT_NOT_MET."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "4.5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "MIN_DEPOSIT_NOT_MET"

    def test_min_deposit_boundary(self, runner, patched):
        """Exactly 5 USDC should pass the min check."""
        sender, mock_w3 = self._patch_w3()
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=100_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "5"])
            d = parse(result)
            assert d["ok"] is True

    def test_to_other_addr_rejected(self, runner, patched):
        """--to anything other than 'self' must fail (Bridge2 credits sender)."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_RECIPIENT_NOT_SELF"

    def test_source_no_gas_hard_blocks(self, runner, patched):
        """Locked decision 14: 0 ETH on Arbitrum must hard-block at propose time."""
        sender, mock_w3 = self._patch_w3(balance_eth=Decimal("0"))
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_SOURCE_NO_GAS"

    def test_rpc_unreachable_hard_blocks(self, runner, patched):
        """RPC failure on inbound must hard-block (we can't proceed without verifying gas)."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.side_effect = Exception("RPC down")
        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["arbitrum", "bridge", "hypercore",
                                          "--to", "self", "5"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "RPC_UNREACHABLE"

    def test_executor_calls_transfer_erc20(self):
        from regard.venues.hyperliquid.bridge_constants import (
            ARB_USDC_CONTRACT,
            HL_BRIDGE2_CONTRACT,
        )

        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_account = MagicMock()
        mock_account.address = sender
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("1.0") * Decimal(10**18))

        with patch("regard.venues.hyperliquid.inbound_bridge._get_arbitrum_web3", return_value=mock_w3), \
             patch("regard.core.evm.transfer_erc20", return_value=b"\x00" * 32) as mock_transfer, \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key", return_value=mock_account), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.inbound_bridge import execute_arbitrum_bridge_hypercore
            result = execute_arbitrum_bridge_hypercore({
                "sender": sender,
                "dest_address": HL_BRIDGE2_CONTRACT,
                "dest_label": "HL_BRIDGE2",
                "recipient_on_hl": sender,
                "token_address": ARB_USDC_CONTRACT,
                "token": "USDC",
                "amount": "5.0",
                "amount_raw": "5000000",
                "chain": "arbitrum",
            })
            mock_transfer.assert_called_once_with(
                mock_w3, mock_account, HL_BRIDGE2_CONTRACT, ARB_USDC_CONTRACT, 5_000_000
            )
            assert result["status"] == "bridged"
            assert result["chain"] == "arbitrum"


# ---------------------------------------------------------------------------
# Inbound: hyperevm bridge hypercore
# ---------------------------------------------------------------------------


class TestHyperevmBridgeHypercore:
    def test_hype_routes_to_native_path(self, runner, patched):
        """--token HYPE: is_native=True, dest is 0x222...2222."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "0.5", "--token", "HYPE"])
            d = parse(result)
            assert d["ok"] is True, f"Expected success; got: {d}"
            assert d["data"]["params"]["is_native"] is True
            assert d["data"]["params"]["dest_address"] == "0x2222222222222222222222222222222222222222"
            assert d["data"]["params"]["token"] == "HYPE"

    def test_hype_lowercase_normalized(self, runner, patched):
        """--token hype must route to native path (locked decision 15)."""
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "0.5", "--token", "hype"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["params"]["token"] == "HYPE"
            assert d["data"]["params"]["is_native"] is True

    def test_usdc_routes_to_erc20_path(self, runner, patched):
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        # inbound_bridge.py imports get_info directly from venues.hyperliquid.client,
        # so we patch at that import site (the conftest `patched` fixture doesn't cover it).
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = MOCK_SPOT_META

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=100_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Failed: {d}"
            assert d["data"]["params"]["is_native"] is False
            assert d["data"]["params"]["token"] == "USDC"
            # ERC-20 dest is the system address (0x20 + token_index_bytes).
            assert d["data"]["params"]["dest_address"].startswith("0x20")
            # token_address is the linked HyperEVM ERC-20 contract.
            assert d["data"]["params"]["token_address"] == "0x5555555555555555555555555555555555555555"

    def test_unlinked_token_hard_blocked(self, runner, patched):
        """Token with evmContract: None must hard-block with BRIDGE_TOKEN_NOT_LINKED.

        Patches `regard.venues.hyperliquid.client.get_info` directly because
        inbound_bridge.py imports get_info lazily inside the function body —
        the conftest `patched` fixture only covers `commands.act.get_info`.
        Without this patch, the test makes live API calls (round-3 peer review
        Important #1).
        """
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = _build_mock_spot_meta(include_unlinked=True)

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "LICK"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_TOKEN_NOT_LINKED"

    def test_to_other_addr_rejected(self, runner, patched):
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411", "5", "--token", "USDC"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "BRIDGE_RECIPIENT_NOT_SELF"

    def test_executor_hype_passes_explicit_gas_limit(self):
        """Locked decision 15: HYPE path MUST pass gas_limit=100_000 explicitly.

        transfer_native's default 21k is insufficient because the system
        contract emits a LOG3 op (~65k gas total). 100k is the safe override.
        Catch any future regression.
        """
        from regard.venues.hyperliquid.bridge_constants import (
            HYPE_BRIDGE_GAS_LIMIT,
            HYPE_SYSTEM_ADDRESS,
        )

        sender_addr = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_account = MagicMock()
        mock_account.address = sender_addr
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))

        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.core.evm.transfer_native", return_value=b"\x00" * 32) as mock_transfer, \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key", return_value=mock_account), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.inbound_bridge import execute_hyperevm_bridge_hypercore
            execute_hyperevm_bridge_hypercore({
                "sender": sender_addr,
                "dest_address": HYPE_SYSTEM_ADDRESS,
                "dest_label": "HYPERCORE_SYSTEM_HYPE",
                "recipient_on_hl": sender_addr,
                "token": "HYPE",
                "token_address": None,
                "is_native": True,
                "amount": "0.5",
                "amount_raw": str(int(Decimal("0.5") * Decimal(10**18))),
                "chain": "hyperevm",
            })
            mock_transfer.assert_called_once_with(
                mock_w3, mock_account, HYPE_SYSTEM_ADDRESS,
                int(Decimal("0.5") * Decimal(10**18)),
                gas_limit=HYPE_BRIDGE_GAS_LIMIT,
            )

    def test_executor_erc20_does_not_pass_gas_limit(self):
        """ERC-20 path uses transfer_erc20's default 100k — no explicit override needed."""
        sender_addr = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_account = MagicMock()
        mock_account.address = sender_addr
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))

        with patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.core.evm.transfer_erc20", return_value=b"\x00" * 32) as mock_transfer, \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("eth_account.Account.from_key", return_value=mock_account), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.inbound_bridge import execute_hyperevm_bridge_hypercore
            execute_hyperevm_bridge_hypercore({
                "sender": sender_addr,
                "dest_address": "0x20" + "00" * 19,
                "dest_label": "HYPERCORE_SYSTEM_USDC",
                "recipient_on_hl": sender_addr,
                "token": "USDC",
                "token_address": "0x5555555555555555555555555555555555555555",
                "is_native": False,
                "amount": "5.0",
                "amount_raw": "5000000",
                "chain": "hyperevm",
            })
            mock_transfer.assert_called_once_with(
                mock_w3, mock_account, "0x20" + "00" * 19,
                "0x5555555555555555555555555555555555555555", 5_000_000,
            )


# ---------------------------------------------------------------------------
# Schema regression: real golden spot_meta USDC entry (catches API-shape bugs)
# ---------------------------------------------------------------------------


class TestDecimalArithmeticInvariants:
    """Demonstrates the IEEE 754 cases the Article II Decimal rule prevents.

    Article IV ("Every financial safety rule in Article II MUST have a
    corresponding test") makes these tests load-bearing — the new rule
    needs a test that demonstrates its necessity, not just one that
    verifies the output format change. These tests document the actual
    bug class the rule is designed to prevent.
    """

    def test_decimal_from_string_preserves_precision(self):
        """The bug: Decimal(float_var) carries IEEE 754 representation error.

        For 0.1 — the canonical IEEE 754 unfriendly value — the float
        representation is 0.1000000000000000055511151231257827021181583... .
        When that float is converted to Decimal, the error propagates through
        every downstream multiplication.
        """
        from decimal import Decimal

        # The correct path: string -> Decimal is exact.
        decimal_from_string = Decimal("0.1") * Decimal(10**18)
        assert int(decimal_from_string) == 100000000000000000

        # The dangerous path: float -> Decimal carries IEEE 754 drift.
        decimal_from_float = Decimal(float("0.1")) * Decimal(10**18)
        assert int(decimal_from_float) == 100000000000000005, (
            "If this changes, Python's Decimal(float) representation may have "
            "changed. The rule's premise depends on Decimal(float_var) carrying "
            "float's representation error verbatim."
        )

        # The two paths produce different amount_raw values — exactly the
        # silent drift Article II clause 1 is designed to prevent.
        assert decimal_from_string != decimal_from_float
        assert int(decimal_from_float) - int(decimal_from_string) == 5

    def test_string_intermediary_recovers_safety(self):
        """Decimal(str(float_var)) recovers safety for typical amounts.

        Python's str(float) uses repr-equivalent shortest round-trip
        representation for non-extreme values. `str(0.1) == "0.1"` exactly
        in Python 3, so `Decimal(str(0.1)) == Decimal("0.1")`.
        """
        from decimal import Decimal

        f = float("0.1")
        assert Decimal(str(f)) == Decimal("0.1")

        # The string-intermediary path produces the safe Decimal.
        safe = Decimal(str(f)) * Decimal(10**18)
        assert int(safe) == 100000000000000000

    def test_float_decimal_inequality_for_typical_amounts(self):
        """For 6-decimal USDC and 8-decimal HYPE inputs, the rule still applies.

        Even though `float * 10^N` happens to be exact for these typical
        amounts (verified empirically — see Article 11), the
        `Decimal(float_var)` path is unsafe regardless of magnitude.
        """
        from decimal import Decimal

        # 5.123456 USDC at 6 decimals
        amount_str = "5.123456"
        d_correct = int(Decimal(amount_str) * Decimal(10**6))
        d_unsafe = int(Decimal(float(amount_str)) * Decimal(10**6))
        # For this specific value the two paths happen to agree; but the
        # rule's guarantee is unconditional. Document the safe path:
        assert d_correct == 5123456


class TestEvmContractSchemaRegression:
    """Regression tests against the unmodified golden spot_meta fixture.

    Round-3 peer review (2026-05-05) caught two Critical bugs that the
    previous mock had masked:
    1. `evmContract` is a dict {"address": ..., "evm_extra_wei_decimals": ...},
       not a flat string. Returning the dict broke `to_checksum_address`.
    2. The decimals offset is `evm_extra_wei_decimals` (snake_case) nested
       inside the dict, NOT `evmExtraWeiDecimals` at the token level.

    These tests bind the implementation to the actual golden fixture so any
    future schema drift between mock and reality re-surfaces immediately.
    """

    def test_linked_erc20_returns_address_string_from_golden(self):
        """`_hyperevm_linked_erc20('USDC', info)` must return a string, not a dict."""
        from regard.venues.hyperliquid.inbound_bridge import _hyperevm_linked_erc20
        mock_info = MagicMock()
        # Use the unmodified golden fixture — no overrides.
        mock_info.spot_meta.return_value = _SPOT_GOLDEN
        result = _hyperevm_linked_erc20("USDC", mock_info)
        assert isinstance(result, str), f"Expected str, got {type(result).__name__}: {result!r}"
        assert result.startswith("0x")
        assert len(result) == 42

    def test_evm_contract_for_token_returns_address_string_from_golden(self):
        """Outbound helper: same string-return contract as inbound."""
        from regard.venues.hyperliquid.commands.act import _evm_contract_for_token
        mock_info = MagicMock()
        mock_info.spot_meta.return_value = _SPOT_GOLDEN
        result = _evm_contract_for_token("USDC", mock_info)
        assert isinstance(result, str)
        assert result.startswith("0x")
        assert len(result) == 42

    def test_amount_raw_uses_correct_decimals_from_golden(self, runner, patched):
        """End-to-end: bridging 5 USDC must compute amount_raw with the linked
        ERC-20's actual decimals (Core 8 + extra -2 = EVM 6 decimals = 5_000_000),
        NOT the wrong default that masked the bug.
        """
        sender = "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080"
        mock_w3 = MagicMock()
        mock_w3.eth.get_balance.return_value = int(Decimal("10") * Decimal(10**18))
        mock_info_local = MagicMock()
        mock_info_local.spot_meta.return_value = _SPOT_GOLDEN

        with patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.inbound_bridge._get_hyperevm_web3", return_value=mock_w3), \
             patch("regard.venues.hyperliquid.client.get_info", return_value=mock_info_local), \
             patch("regard.venues.polymarket.client._get_key", return_value="0x" + "11" * 32), \
             patch("regard.core.evm.get_erc20_balance", return_value=10_000_000), \
             patch("eth_account.Account.from_key") as mock_from_key:
            mock_from_key.return_value.address = sender
            result = runner.invoke(app, ["hyperevm", "bridge", "hypercore",
                                          "--to", "self", "5", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True, f"Failed: {d}"
            # 5 USDC at 6 effective decimals = 5_000_000 raw, NOT 500_000_000 (8 decimals)
            # NOR 5_000_000_000_000_000_000 (18 decimals fallback).
            assert d["data"]["params"]["amount_raw"] == "5000000", (
                f"amount_raw is {d['data']['params']['amount_raw']!r} — implementation "
                "is using wrong wei_decimals (should be 8 + -2 = 6)"
            )
            # token_address must be a string (the address from the dict),
            # not a dict (which would fail at to_checksum_address).
            assert isinstance(d["data"]["params"]["token_address"], str)
            assert d["data"]["params"]["token_address"].startswith("0x")


# ---------------------------------------------------------------------------
# CRITICAL gate uses recipient_on_hl, not dest_address (locked decision 18)
# ---------------------------------------------------------------------------


class TestCriticalGateRecipientOnHl:
    """Locked decision 18: when proposal sets recipient_on_hl, gate confirms against it."""

    def test_gate_uses_recipient_on_hl_when_set(self, runner, tmp_path):
        """Approve a CRITICAL bridge with recipient_on_hl: gate checks user EOA, not constant dest."""
        from regard.core.proposal import create_proposal

        # Construct a synthetic CRITICAL-risk bridge proposal where dest_address
        # is the Bridge2 contract (a constant) but recipient_on_hl is the user's
        # actual address.
        proposal = create_proposal(
            "arbitrum", "bridge.hypercore",
            params={
                "sender": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
                "dest_address": "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7",
                "dest_label": "HL_BRIDGE2",
                "recipient_on_hl": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
                "token_address": "0xaf88d065e77c8cC2239327C5EDb3A432268e5831",
                "token": "USDC",
                "amount": "5.0",
                "amount_raw": "5000000",
                "chain": "arbitrum",
            },
            checks={
                "sender": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
                "risk": "CRITICAL",
            },
            warnings=[],
        )

        # Without --confirm-addr the gate should fire; the expected hex
        # comes from recipient_on_hl[2:8], not from dest_address[2:8].
        # User EOA: 0xF373B4... → expected = "f373b4"
        # Bridge2:  0x2df1c5... → would be "2df1c5"
        result = runner.invoke(app, ["approve", proposal["id"]])
        # Print the actual output for debugging if assertion fails.
        d = parse(result)
        assert d["ok"] is False, f"Expected CONFIRM_ADDR_REQUIRED; got: {d}"
        err = d["error"]
        assert err["code"] == "CONFIRM_ADDR_REQUIRED", f"Got: {err}"
        # Either "f373b4" appears (gate uses recipient_on_hl) OR "2df1c5"
        # (gate fell back to dest_address — fix did not apply). The test
        # passes only on the former.
        assert "f373b4" in err["message"].lower(), f"Gate confirmed wrong field: {err['message']}"
        assert "2df1c5" not in err["message"].lower(), f"Gate confirmed dest_address (Bridge2 constant) instead of recipient_on_hl: {err['message']}"


# ---------------------------------------------------------------------------
# session.py regex coverage for new commands
# ---------------------------------------------------------------------------


class TestSessionRegex:
    """Session command extraction must include the 5 new bridge/send commands.

    `_extract_hypercore_command` parses Bash-tool-call entry text where the
    command is embedded as JSON: '"command": "regard hypercore ..."'.
    """

    def _entry(self, cmd: str) -> str:
        return f'Bash: {{"command": "{cmd}"}}'

    def test_extract_perp_bridge_arbitrum(self):
        from regard.commands.session import _extract_hypercore_command
        out = _extract_hypercore_command(self._entry("regard hypercore perp bridge arbitrum --to self 10"))
        assert out == "regard hypercore perp bridge arbitrum --to self 10"

    def test_extract_spot_bridge_hyperevm(self):
        from regard.commands.session import _extract_hypercore_command
        out = _extract_hypercore_command(self._entry("regard hypercore spot bridge hyperevm --to self 5 --token USDC"))
        assert out == "regard hypercore spot bridge hyperevm --to self 5 --token USDC"

    def test_extract_perp_send(self):
        from regard.commands.session import _extract_hypercore_command
        out = _extract_hypercore_command(self._entry("regard hypercore perp send reserve 5"))
        assert out == "regard hypercore perp send reserve 5"
