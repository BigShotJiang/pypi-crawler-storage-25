"""Tests for `check_approvals` — on-chain approval state reader.

Surfaces approval state in `regard poly status` so the agent stops hallucinating
"wallet not set up / no V2 approvals yet" when the wallet is actually fully
approved. Reads 7 slots in parallel:

  4 × pUSD.allowance(wallet, spender) — threshold >= 10**18
  3 × CTF.isApprovedForAll(wallet, spender)

Defensive handling: any read failure marks that slot as `None` (unknown) rather
than `False` (missing). `all_set` is True only when every slot is confirmed
True — no falsely claiming approvals are missing on transient RPC hiccups.
"""

from unittest.mock import MagicMock, patch

from regard.venues.polymarket.client import check_approvals

WALLET = "0x1293F4b3E29f427defFc14300d5d926b2671a221"
MAX_UINT256 = 2**256 - 1


def _mock_w3(collateral_allowances: dict, ctf_approvals: dict):
    """Build a w3 mock that returns pre-canned allowance / isApprovedForAll values.

    collateral_allowances: {spender_addr_checksum: int | Exception}
    ctf_approvals:         {spender_addr_checksum: bool | Exception}
    """
    w3 = MagicMock()
    w3.to_checksum_address = lambda a: a  # identity for test simplicity

    def _make_contract(abi_marker):
        """Return a mock contract whose .functions.allowance/isApprovedForAll
        lookups resolve against the canned maps based on the second arg."""
        contract = MagicMock()

        def allowance_call(_owner, spender):
            val = collateral_allowances.get(spender)
            if isinstance(val, Exception):
                raise val
            call_mock = MagicMock()
            call_mock.call.return_value = val
            return call_mock

        def isApprovedForAll_call(_owner, spender):
            val = ctf_approvals.get(spender)
            if isinstance(val, Exception):
                raise val
            call_mock = MagicMock()
            call_mock.call.return_value = val
            return call_mock

        contract.functions.allowance.side_effect = allowance_call
        contract.functions.isApprovedForAll.side_effect = isApprovedForAll_call
        return contract

    w3.eth.contract.side_effect = lambda **kwargs: _make_contract(kwargs)
    return w3


# Expected spender labels (in the order check_approvals emits them)
_EXPECTED_LABELS = [
    "pUSD→CTF", "pUSD→Exchange", "pUSD→NegRiskExchange", "pUSD→NegRiskAdapter",
    "CTF→Exchange", "CTF→NegRiskExchange", "CTF→NegRiskAdapter",
]


def _all_set_responses():
    """Build allowance + approval maps where every slot is set (approved)."""
    from regard.venues.polymarket.client import CONTRACTS
    allowances = {
        CONTRACTS["CTF"]: MAX_UINT256,
        CONTRACTS["CTF_EXCHANGE"]: MAX_UINT256,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: MAX_UINT256,
        CONTRACTS["NEG_RISK_ADAPTER"]: MAX_UINT256,
    }
    ctf_approvals = {
        CONTRACTS["CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_ADAPTER"]: True,
    }
    return allowances, ctf_approvals


def test_check_approvals_all_set():
    """Fully approved wallet reports all_set=True, missing/unknown empty."""
    allowances, ctf_approvals = _all_set_responses()
    w3 = _mock_w3(allowances, ctf_approvals)

    with patch("regard.venues.polymarket.client.get_collateral_token",
               return_value={"name": "pUSD", "address": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB"}):
        result = check_approvals(w3=w3, wallet=WALLET)

    assert result["all_set"] is True
    assert result["count_set"] == 7
    assert result["count_total"] == 7
    assert result["missing"] == []
    assert result["unknown"] == []
    assert set(result["detail"].keys()) == set(_EXPECTED_LABELS)
    assert all(v is True for v in result["detail"].values())


def test_check_approvals_fresh_wallet():
    """Fresh wallet: all allowances 0, all isApprovedForAll False → all_set=False, 7 missing."""
    from regard.venues.polymarket.client import CONTRACTS
    allowances = {
        CONTRACTS["CTF"]: 0,
        CONTRACTS["CTF_EXCHANGE"]: 0,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: 0,
        CONTRACTS["NEG_RISK_ADAPTER"]: 0,
    }
    ctf_approvals = {
        CONTRACTS["CTF_EXCHANGE"]: False,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: False,
        CONTRACTS["NEG_RISK_ADAPTER"]: False,
    }
    w3 = _mock_w3(allowances, ctf_approvals)

    with patch("regard.venues.polymarket.client.get_collateral_token",
               return_value={"name": "pUSD", "address": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB"}):
        result = check_approvals(w3=w3, wallet=WALLET)

    assert result["all_set"] is False
    assert result["count_set"] == 0
    assert len(result["missing"]) == 7
    assert result["unknown"] == []


def test_check_approvals_partial():
    """5 set, 2 missing → all_set=False, count_set=5."""
    from regard.venues.polymarket.client import CONTRACTS
    allowances = {
        CONTRACTS["CTF"]: MAX_UINT256,
        CONTRACTS["CTF_EXCHANGE"]: MAX_UINT256,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: 0,  # missing
        CONTRACTS["NEG_RISK_ADAPTER"]: MAX_UINT256,
    }
    ctf_approvals = {
        CONTRACTS["CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: False,  # missing
        CONTRACTS["NEG_RISK_ADAPTER"]: True,
    }
    w3 = _mock_w3(allowances, ctf_approvals)

    with patch("regard.venues.polymarket.client.get_collateral_token",
               return_value={"name": "pUSD", "address": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB"}):
        result = check_approvals(w3=w3, wallet=WALLET)

    assert result["all_set"] is False
    assert result["count_set"] == 5
    assert set(result["missing"]) == {"pUSD→NegRiskExchange", "CTF→NegRiskExchange"}
    assert result["unknown"] == []


def test_check_approvals_rpc_failure_is_unknown():
    """RPC read failure → slot marked None (unknown), not False (missing).

    This prevents transient RPC hiccups from falsely triggering a 7-tx re-approve.
    """
    from regard.venues.polymarket.client import CONTRACTS
    allowances = {
        CONTRACTS["CTF"]: MAX_UINT256,
        CONTRACTS["CTF_EXCHANGE"]: RuntimeError("RPC timeout"),  # unknown
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: MAX_UINT256,
        CONTRACTS["NEG_RISK_ADAPTER"]: MAX_UINT256,
    }
    ctf_approvals = {
        CONTRACTS["CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_ADAPTER"]: True,
    }
    w3 = _mock_w3(allowances, ctf_approvals)

    with patch("regard.venues.polymarket.client.get_collateral_token",
               return_value={"name": "pUSD", "address": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB"}):
        result = check_approvals(w3=w3, wallet=WALLET)

    # Unknowns prevent all_set even when nothing is confirmed missing
    assert result["all_set"] is False
    assert result["count_set"] == 6
    assert result["missing"] == []
    assert result["unknown"] == ["pUSD→Exchange"]
    assert result["detail"]["pUSD→Exchange"] is None


def test_check_approvals_threshold_boundary():
    """Allowance exactly at 10**18 is considered set; below is missing."""
    from regard.venues.polymarket.client import CONTRACTS
    allowances = {
        CONTRACTS["CTF"]: 10**18,              # exactly at threshold — set
        CONTRACTS["CTF_EXCHANGE"]: 10**18 - 1,  # one wei below — missing
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: MAX_UINT256,
        CONTRACTS["NEG_RISK_ADAPTER"]: MAX_UINT256,
    }
    ctf_approvals = {
        CONTRACTS["CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_ADAPTER"]: True,
    }
    w3 = _mock_w3(allowances, ctf_approvals)

    with patch("regard.venues.polymarket.client.get_collateral_token",
               return_value={"name": "pUSD", "address": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB"}):
        result = check_approvals(w3=w3, wallet=WALLET)

    assert result["detail"]["pUSD→CTF"] is True
    assert result["detail"]["pUSD→Exchange"] is False
    assert "pUSD→Exchange" in result["missing"]


def test_check_approvals_collateral_lookup_failure_falls_back_to_pusd():
    """If get_collateral_token raises, falls back to PUSD address + 'pUSD' label."""
    from regard.venues.polymarket.client import CONTRACTS
    allowances = {
        CONTRACTS["CTF"]: MAX_UINT256,
        CONTRACTS["CTF_EXCHANGE"]: MAX_UINT256,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: MAX_UINT256,
        CONTRACTS["NEG_RISK_ADAPTER"]: MAX_UINT256,
    }
    ctf_approvals = {
        CONTRACTS["CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_CTF_EXCHANGE"]: True,
        CONTRACTS["NEG_RISK_ADAPTER"]: True,
    }
    w3 = _mock_w3(allowances, ctf_approvals)

    with patch("regard.venues.polymarket.client.get_collateral_token",
               side_effect=RuntimeError("RPC down")):
        result = check_approvals(w3=w3, wallet=WALLET)

    # Labels still use "pUSD→..." prefix via the fallback
    assert "pUSD→CTF" in result["detail"]
    assert result["all_set"] is True
