"""Tests for core/tilt_session_state.py — per-session leverage history."""

import json
from datetime import datetime, timedelta, timezone

from regard.core.tilt_session_state import (
    _prune_history,
    load_leverage_history,
    record_leverage_snapshot,
)


def _ts(dt: datetime) -> str:
    return dt.isoformat()


# ---------------------------------------------------------------------------
# _prune_history — pure-logic walk
# ---------------------------------------------------------------------------


class TestPruneHistory:
    def test_empty(self):
        assert _prune_history({}, max_age_hours=24) == {}

    def test_within_window_kept(self):
        now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        history = {
            "BTC": [{"ts": _ts(now - timedelta(hours=1)), "lev": 5.0}],
        }
        result = _prune_history(history, max_age_hours=24, now=now)
        assert "BTC" in result
        assert len(result["BTC"]) == 1
        assert result["BTC"][0]["lev"] == 5.0

    def test_older_than_window_dropped(self):
        now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        history = {
            "BTC": [
                {"ts": _ts(now - timedelta(hours=48)), "lev": 2.0},  # too old
                {"ts": _ts(now - timedelta(hours=1)), "lev": 10.0},  # kept
            ],
        }
        result = _prune_history(history, max_age_hours=24, now=now)
        assert len(result["BTC"]) == 1
        assert result["BTC"][0]["lev"] == 10.0

    def test_asset_with_no_kept_snapshots_removed(self):
        now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        history = {
            "ETH": [{"ts": _ts(now - timedelta(hours=72)), "lev": 5.0}],
        }
        result = _prune_history(history, max_age_hours=24, now=now)
        assert "ETH" not in result

    def test_corrupt_entries_skipped(self):
        now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        history = {
            "BTC": [
                "not a dict",
                {"missing_ts": True},
                {"ts": "garbage-timestamp", "lev": 5.0},
                {"ts": _ts(now - timedelta(hours=1)), "lev": "not-a-number"},
                {"ts": _ts(now - timedelta(hours=1)), "lev": 7.0},  # only valid one
            ],
        }
        result = _prune_history(history, max_age_hours=24, now=now)
        assert len(result["BTC"]) == 1
        assert result["BTC"][0]["lev"] == 7.0


# ---------------------------------------------------------------------------
# load_leverage_history — read + prune + sort
# ---------------------------------------------------------------------------


class TestLoadLeverageHistory:
    def test_missing_file_returns_empty(self, tmp_path):
        assert load_leverage_history(tmp_path) == {}

    def test_corrupt_file_returns_empty(self, tmp_path):
        regard_dir = tmp_path / ".regard"
        regard_dir.mkdir(exist_ok=True)
        (regard_dir / "tilt_session.json").write_text("{not valid json")
        assert load_leverage_history(tmp_path) == {}

    def test_returns_oldest_first_per_asset(self, tmp_path):
        now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        regard_dir = tmp_path / ".regard"
        regard_dir.mkdir(exist_ok=True)
        # Write entries in mixed order
        (regard_dir / "tilt_session.json").write_text(json.dumps({
            "leverage_history": {
                "BTC": [
                    {"ts": _ts(now - timedelta(hours=1)), "lev": 10.0},
                    {"ts": _ts(now - timedelta(hours=5)), "lev": 2.0},  # oldest
                    {"ts": _ts(now - timedelta(hours=3)), "lev": 5.0},
                ],
            },
        }))
        result = load_leverage_history(tmp_path, now=now)
        # Oldest-first
        assert [e["lev"] for e in result["BTC"]] == [2.0, 5.0, 10.0]

    def test_window_pruning_applied(self, tmp_path):
        now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        regard_dir = tmp_path / ".regard"
        regard_dir.mkdir(exist_ok=True)
        (regard_dir / "tilt_session.json").write_text(json.dumps({
            "leverage_history": {
                "BTC": [
                    {"ts": _ts(now - timedelta(hours=72)), "lev": 2.0},  # too old
                    {"ts": _ts(now - timedelta(hours=1)), "lev": 10.0},
                ],
            },
        }))
        result = load_leverage_history(tmp_path, max_age_hours=24, now=now)
        assert len(result["BTC"]) == 1
        assert result["BTC"][0]["lev"] == 10.0


# ---------------------------------------------------------------------------
# record_leverage_snapshot — append + atomic-write
# ---------------------------------------------------------------------------


class TestRecordLeverageSnapshot:
    def test_empty_input_no_op(self, tmp_path):
        assert record_leverage_snapshot({}, tmp_path) is None
        assert not (tmp_path / ".regard" / "tilt_session.json").exists()

    def test_first_snapshot_creates_file(self, tmp_path):
        path = record_leverage_snapshot({"BTC": 5.0}, tmp_path)
        assert path is not None and path.exists()
        data = json.loads(path.read_text())
        assert "BTC" in data["leverage_history"]
        assert len(data["leverage_history"]["BTC"]) == 1
        assert data["leverage_history"]["BTC"][0]["lev"] == 5.0

    def test_subsequent_snapshot_appends(self, tmp_path):
        record_leverage_snapshot({"BTC": 5.0}, tmp_path)
        record_leverage_snapshot({"BTC": 10.0}, tmp_path)
        data = json.loads((tmp_path / ".regard" / "tilt_session.json").read_text())
        assert len(data["leverage_history"]["BTC"]) == 2
        # Both leverages preserved
        levs = [e["lev"] for e in data["leverage_history"]["BTC"]]
        assert 5.0 in levs and 10.0 in levs

    def test_invalid_leverage_dropped(self, tmp_path):
        record_leverage_snapshot(
            {"BTC": 5.0, "ETH": "not-a-number", "SOL": 0, "DOGE": -1},
            tmp_path,
        )
        data = json.loads((tmp_path / ".regard" / "tilt_session.json").read_text())
        # Only BTC was a positive numeric leverage
        assert "BTC" in data["leverage_history"]
        assert "ETH" not in data["leverage_history"]
        assert "SOL" not in data["leverage_history"]
        assert "DOGE" not in data["leverage_history"]

    def test_existing_history_pruned_on_write(self, tmp_path):
        # Pre-populate with an old entry that should be pruned
        regard_dir = tmp_path / ".regard"
        regard_dir.mkdir(exist_ok=True)
        old_now = datetime(2026, 4, 28, 12, 0, tzinfo=timezone.utc)  # 48h before now
        new_now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        (regard_dir / "tilt_session.json").write_text(json.dumps({
            "leverage_history": {
                "BTC": [{"ts": _ts(old_now), "lev": 2.0}],
            },
        }))
        record_leverage_snapshot({"BTC": 10.0}, tmp_path, max_age_hours=24, now=new_now)
        data = json.loads((tmp_path / ".regard" / "tilt_session.json").read_text())
        # Old entry pruned, new one kept
        levs = [e["lev"] for e in data["leverage_history"]["BTC"]]
        assert levs == [10.0]
