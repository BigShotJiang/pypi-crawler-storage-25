"""Tests for core/tilt_pending.py — asymmetric change rule for tilt config."""

from datetime import datetime, timedelta, timezone

import pytest

from regard.core.tilt_pending import (
    cancel_by_key,
    cancel_pending,
    compare_direction,
    confirm_pending,
    find_pending_by_key,
    list_pending,
    write_pending,
)

# ---------------------------------------------------------------------------
# compare_direction — per-key direction classification
# ---------------------------------------------------------------------------


class TestCompareDirection:
    @pytest.mark.parametrize("path,old,new,expected", [
        # lower-tighter
        (("max_session_hours",), 8, 6, "tighten"),
        (("max_session_hours",), 8, 12, "loosen"),
        (("max_session_hours",), 8, 8, "neutral"),
        # higher-tighter
        (("polymarket", "longshot_threshold_cents"), 5, 7, "tighten"),
        (("polymarket", "longshot_threshold_cents"), 5, 3, "loosen"),
        (("asymmetric_change", "loosening_delay_hours"), 24, 48, "tighten"),
        # nullable-num
        (("daily_loss_budget_usd",), None, 500, "tighten"),
        (("daily_loss_budget_usd",), 500, None, "loosen"),
        (("daily_loss_budget_usd",), None, None, "neutral"),
        (("daily_loss_budget_usd",), 500, 1000, "loosen"),
        (("daily_loss_budget_usd",), 500, 250, "tighten"),
        # true-tighter
        (("first_red_pivot_enabled",), False, True, "tighten"),
        (("first_red_pivot_enabled",), True, False, "loosen"),
        # text-protection
        (("ulysses_text",), None, "stop after 3", "tighten"),
        (("ulysses_text",), "stop after 3", None, "loosen"),
        (("ulysses_text",), "stop after 3", "stop after 2", "neutral"),  # text update
        (("ulysses_text",), "", "stop after 3", "tighten"),  # empty → text
        (("sleep_window_local",), None, "23:00-07:00", "tighten"),
        (("sleep_window_local",), "23:00-07:00", None, "loosen"),
        # neutral key
        (("size_deviation_baseline_days",), 7, 14, "neutral"),
        # unknown path → neutral (defensive default for forward-compat)
        (("unknown_future_key",), 1, 5, "neutral"),
    ])
    def test_direction_classification(self, path, old, new, expected):
        assert compare_direction(path, old, new) == expected

    def test_garbage_old_value_neutral(self):
        # Defensive — corrupt config returning non-numeric for a numeric key
        assert compare_direction(("max_session_hours",), "not-a-number", 6) == "neutral"


# ---------------------------------------------------------------------------
# Pending file lifecycle
# ---------------------------------------------------------------------------


class TestWritePending:
    def test_creates_pending_file(self, tmp_path):
        entry = write_pending(
            cli_key="tilt-daily-loss-budget-usd",
            json_path=("daily_loss_budget_usd",),
            current_value=500,
            requested_value=1000,
            project_dir=tmp_path,
            ttl_hours=24,
        )
        assert entry["cli_key"] == "tilt-daily-loss-budget-usd"
        assert entry["current_value"] == 500
        assert entry["requested_value"] == 1000
        assert entry["ttl_hours"] == 24
        assert "id" in entry and len(entry["id"]) == 8
        # File created
        pending_files = list((tmp_path / ".regard" / "pending").glob("tilt_*.json"))
        assert len(pending_files) == 1

    def test_replaces_existing_for_same_key(self, tmp_path):
        write_pending(
            cli_key="tilt-daily-loss-budget-usd",
            json_path=("daily_loss_budget_usd",),
            current_value=500,
            requested_value=1000,
            project_dir=tmp_path,
        )
        # Use distinct timestamp so the new pending gets a different ID
        write_pending(
            cli_key="tilt-daily-loss-budget-usd",
            json_path=("daily_loss_budget_usd",),
            current_value=500,
            requested_value=2000,
            project_dir=tmp_path,
            now=datetime(2026, 4, 30, 18, 0, tzinfo=timezone.utc),
        )
        # Only one pending for this key
        entries = list_pending(tmp_path)
        same_key = [e for e in entries if e["cli_key"] == "tilt-daily-loss-budget-usd"]
        assert len(same_key) == 1
        assert same_key[0]["requested_value"] == 2000

    def test_different_keys_coexist(self, tmp_path):
        write_pending(
            cli_key="tilt-daily-loss-budget-usd",
            json_path=("daily_loss_budget_usd",),
            current_value=500,
            requested_value=1000,
            project_dir=tmp_path,
        )
        write_pending(
            cli_key="tilt-max-session-hours",
            json_path=("max_session_hours",),
            current_value=8,
            requested_value=12,
            project_dir=tmp_path,
            now=datetime(2026, 4, 30, 19, 0, tzinfo=timezone.utc),
        )
        entries = list_pending(tmp_path)
        assert len(entries) == 2


class TestListPending:
    def test_empty_returns_empty(self, tmp_path):
        assert list_pending(tmp_path) == []

    def test_annotates_with_ready_and_remaining(self, tmp_path):
        past_now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        write_pending(
            cli_key="tilt-max-session-hours",
            json_path=("max_session_hours",),
            current_value=8,
            requested_value=12,
            project_dir=tmp_path,
            ttl_hours=24,
            now=past_now,
        )
        # Query 12h after request — not ready yet
        entries = list_pending(
            tmp_path,
            now=past_now + timedelta(hours=12),
        )
        assert entries[0]["ready"] is False
        assert 0 < entries[0]["remaining_seconds"] <= 12 * 3600

        # Query 25h after — ready
        entries = list_pending(
            tmp_path,
            now=past_now + timedelta(hours=25),
        )
        assert entries[0]["ready"] is True
        assert entries[0]["remaining_seconds"] == 0

    def test_prune_removes_malformed(self, tmp_path):
        pending_dir = tmp_path / ".regard" / "pending"
        pending_dir.mkdir(parents=True)
        (pending_dir / "tilt_garbage.json").write_text("{not json")
        entries = list_pending(tmp_path, prune=True)
        assert entries == []
        # Malformed file deleted
        assert not (pending_dir / "tilt_garbage.json").exists()


class TestConfirmPending:
    def test_too_early(self, tmp_path):
        now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        entry = write_pending(
            cli_key="tilt-max-session-hours",
            json_path=("max_session_hours",),
            current_value=8,
            requested_value=12,
            project_dir=tmp_path,
            ttl_hours=24,
            now=now,
        )
        # Query 1h after request
        status, returned = confirm_pending(
            entry["id"], tmp_path, now=now + timedelta(hours=1),
        )
        assert status == "too_early"
        assert returned is not None
        assert returned["remaining_seconds"] > 0
        # Pending file still exists
        assert (tmp_path / ".regard" / "pending" / f"tilt_{entry['id']}.json").exists()

    def test_after_elapse_returns_ready_without_removing_file(self, tmp_path):
        # confirm_pending validates the TTL but does NOT delete — caller
        # (the CLI command) removes the file AFTER successfully writing
        # the new config. This protects against losing a 24h-cooled-off
        # approval to a transient OSError on the config write.
        now = datetime(2026, 4, 30, 12, 0, tzinfo=timezone.utc)
        entry = write_pending(
            cli_key="tilt-max-session-hours",
            json_path=("max_session_hours",),
            current_value=8,
            requested_value=12,
            project_dir=tmp_path,
            ttl_hours=24,
            now=now,
        )
        status, returned = confirm_pending(
            entry["id"], tmp_path, now=now + timedelta(hours=25),
        )
        assert status == "ready"
        assert returned["requested_value"] == 12
        # Pending file still exists — caller hasn't deleted yet
        assert (tmp_path / ".regard" / "pending" / f"tilt_{entry['id']}.json").exists()

    def test_not_found(self, tmp_path):
        status, returned = confirm_pending("doesnotexist", tmp_path)
        assert status == "not_found"
        assert returned is None


class TestCancelPending:
    def test_cancel_existing(self, tmp_path):
        entry = write_pending(
            cli_key="tilt-max-session-hours",
            json_path=("max_session_hours",),
            current_value=8,
            requested_value=12,
            project_dir=tmp_path,
        )
        assert cancel_pending(entry["id"], tmp_path) is True
        assert not (tmp_path / ".regard" / "pending" / f"tilt_{entry['id']}.json").exists()

    def test_cancel_missing_returns_false(self, tmp_path):
        assert cancel_pending("doesnotexist", tmp_path) is False

    def test_cancel_by_key(self, tmp_path):
        write_pending(
            cli_key="tilt-max-session-hours",
            json_path=("max_session_hours",),
            current_value=8,
            requested_value=12,
            project_dir=tmp_path,
        )
        assert cancel_by_key("tilt-max-session-hours", tmp_path) == 1
        assert list_pending(tmp_path) == []


class TestFindPendingByKey:
    def test_returns_entry(self, tmp_path):
        write_pending(
            cli_key="tilt-max-session-hours",
            json_path=("max_session_hours",),
            current_value=8,
            requested_value=12,
            project_dir=tmp_path,
        )
        entry = find_pending_by_key("tilt-max-session-hours", tmp_path)
        assert entry is not None
        assert entry["cli_key"] == "tilt-max-session-hours"

    def test_returns_none_when_no_pending(self, tmp_path):
        assert find_pending_by_key("tilt-max-session-hours", tmp_path) is None
