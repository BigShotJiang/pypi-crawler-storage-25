"""Tests for core/safety.py — risk classification, amount caps, cooldown, daily caps."""

import json
import time
from decimal import Decimal

import pytest

from regard.core.safety import (
    _last_send_to,
    _sum_today_sends,
    check_amount_cap,
    check_cooldown,
    check_daily_cap,
    classify_risk,
)


class TestClassifyRisk:
    def test_standard(self):
        assert classify_risk(Decimal("10"), Decimal("100")) == "STANDARD"

    def test_high(self):
        assert classify_risk(Decimal("60"), Decimal("100")) == "HIGH"

    def test_critical(self):
        assert classify_risk(Decimal("95"), Decimal("100")) == "CRITICAL"

    def test_zero_balance(self):
        assert classify_risk(Decimal("1"), Decimal("0")) == "CRITICAL"

    def test_boundary_50(self):
        assert classify_risk(Decimal("50"), Decimal("100")) == "STANDARD"

    def test_boundary_51(self):
        assert classify_risk(Decimal("51"), Decimal("100")) == "HIGH"

    def test_boundary_90(self):
        assert classify_risk(Decimal("90"), Decimal("100")) == "HIGH"

    def test_boundary_91(self):
        assert classify_risk(Decimal("91"), Decimal("100")) == "CRITICAL"


class TestAmountCap:
    def test_no_cap_configured(self):
        check_amount_cap(Decimal("999999"), "USDC", {})  # should not raise

    def test_within_cap(self):
        check_amount_cap(Decimal("50"), "USDC", {"SEND_MAX_AMOUNT": "100"})  # should not raise

    def test_exceeds_cap(self):
        with pytest.raises(SystemExit):
            check_amount_cap(Decimal("150"), "USDC", {"SEND_MAX_AMOUNT": "100"})

    def test_invalid_cap_value(self):
        check_amount_cap(Decimal("50"), "USDC", {"SEND_MAX_AMOUNT": "not_a_number"})  # should not raise


class TestDailyCap:
    def test_no_cap_configured(self):
        check_daily_cap(Decimal("999"), "USDC", "hypercore", {})  # should not raise


class TestCooldown:
    def test_no_recent_sends(self, tmp_path):
        """No audit log → no cooldown. (autouse _isolate_proposals chdirs to tmp_path; no .regard/send_log.jsonl exists)"""
        check_cooldown("0xABC", {"SEND_COOLDOWN": "30"})  # should not raise

    def test_cooldown_active(self, tmp_path):
        """Recent send within cooldown → should die."""
        log_file = tmp_path / ".regard" / "send_log.jsonl"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        now_utc = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        log_file.write_text(json.dumps({
            "ts": now_utc, "event": "executed", "command": "send", "to": "0xABC",
        }) + "\n")
        with pytest.raises(SystemExit):
            check_cooldown("0xABC", {"SEND_COOLDOWN": "300"})

    def test_cooldown_expired(self, tmp_path):
        """Old send outside cooldown → should not die."""
        log_file = tmp_path / ".regard" / "send_log.jsonl"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        old_ts = "2020-01-01T00:00:00Z"  # long ago
        log_file.write_text(json.dumps({
            "ts": old_ts, "event": "executed", "command": "send", "to": "0xABC",
        }) + "\n")
        check_cooldown("0xABC", {"SEND_COOLDOWN": "30"})  # should not raise

    def test_cooldown_disabled(self, tmp_path):
        """Cooldown = 0 → never triggers."""
        log_file = tmp_path / ".regard" / "send_log.jsonl"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        now_utc = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        log_file.write_text(json.dumps({
            "ts": now_utc, "event": "executed", "command": "send", "to": "0xABC",
        }) + "\n")
        check_cooldown("0xABC", {"SEND_COOLDOWN": "0"})  # should not raise

    def test_cooldown_different_address(self, tmp_path):
        """Send to different address → no cooldown for this one."""
        log_file = tmp_path / ".regard" / "send_log.jsonl"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        now_utc = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        log_file.write_text(json.dumps({
            "ts": now_utc, "event": "executed", "command": "send", "to": "0xOTHER",
        }) + "\n")
        check_cooldown("0xABC", {"SEND_COOLDOWN": "300"})  # should not raise


class TestTimezoneHandling:
    """Verify _last_send_to uses UTC, not local time."""

    def test_utc_timestamp_parsed_correctly(self, tmp_path):
        """A known UTC timestamp should produce the correct epoch value."""
        log_file = tmp_path / ".regard" / "send_log.jsonl"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        # 2026-01-01T00:00:00Z = epoch 1767225600
        log_file.write_text(json.dumps({
            "ts": "2026-01-01T00:00:00Z", "event": "executed", "command": "send", "to": "0xABC",
        }) + "\n")
        result = _last_send_to("0xABC")
        import calendar
        expected = calendar.timegm(time.strptime("2026-01-01T00:00:00Z", "%Y-%m-%dT%H:%M:%SZ"))
        assert result == expected


class TestCorruptedLog:
    """Verify corrupt log entries don't crash or silently bypass safety."""

    def test_corrupt_line_skipped(self, tmp_path):
        """Corrupted JSON line is skipped; valid entries still counted."""
        log_file = tmp_path / ".regard" / "send_log.jsonl"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        today = time.strftime("%Y-%m-%d", time.gmtime())
        log_file.write_text(
            "THIS IS NOT JSON\n"
            + json.dumps({
                "ts": f"{today}T12:00:00Z", "event": "executed",
                "command": "send", "venue": "hypercore", "amount": "5.0",
            }) + "\n"
        )
        total = _sum_today_sends("hypercore")
        assert total == Decimal("5.0")


class TestDottedPathFilter:
    """Regression guard for V025 locked decision 17.

    Pre-v0.25.0 the safety filter matched only `command == "send"` exactly,
    which silently skipped `spot.send`, `perp.send`, and any `*.bridge.*`
    path — meaning past executions of those commands never accumulated
    toward the daily cap. v0.25.0 fixes the filter to match all dotted-path
    forms.
    """

    def _write_log(self, tmp_path, entries):
        log_file = tmp_path / ".regard" / "send_log.jsonl"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text("\n".join(json.dumps(e) for e in entries) + "\n")

    def test_spot_send_counted(self, tmp_path):
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [{
            "ts": f"{today}T12:00:00Z", "event": "executed",
            "command": "spot.send", "venue": "hypercore", "amount": "3.0",
        }])
        assert _sum_today_sends("hypercore") == Decimal("3.0")

    def test_perp_send_counted(self, tmp_path):
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [{
            "ts": f"{today}T12:00:00Z", "event": "executed",
            "command": "perp.send", "venue": "hypercore", "amount": "2.0",
        }])
        assert _sum_today_sends("hypercore") == Decimal("2.0")

    def test_perp_bridge_arbitrum_counted(self, tmp_path):
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [{
            "ts": f"{today}T12:00:00Z", "event": "executed",
            "command": "perp.bridge.arbitrum", "venue": "hypercore", "amount": "10.0",
        }])
        assert _sum_today_sends("hypercore") == Decimal("10.0")

    def test_inbound_arbitrum_bridge_counted(self, tmp_path):
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [{
            "ts": f"{today}T12:00:00Z", "event": "executed",
            "command": "bridge.hypercore", "venue": "arbitrum", "amount": "5.0",
        }])
        assert _sum_today_sends("arbitrum") == Decimal("5.0")

    def test_inbound_hyperevm_bridge_counted(self, tmp_path):
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [{
            "ts": f"{today}T12:00:00Z", "event": "executed",
            "command": "bridge.hypercore", "venue": "hyperevm", "amount": "0.5",
        }])
        assert _sum_today_sends("hyperevm") == Decimal("0.5")

    def test_three_perp_sends_accumulate(self, tmp_path):
        """Regression guard: pre-v0.25.0 these all silently skipped accumulation."""
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [
            {"ts": f"{today}T10:00:00Z", "event": "executed",
             "command": "perp.send", "venue": "hypercore", "amount": "1.0"},
            {"ts": f"{today}T11:00:00Z", "event": "executed",
             "command": "perp.send", "venue": "hypercore", "amount": "1.0"},
            {"ts": f"{today}T12:00:00Z", "event": "executed",
             "command": "perp.send", "venue": "hypercore", "amount": "1.0"},
        ])
        assert _sum_today_sends("hypercore") == Decimal("3.0")

    def test_non_send_commands_not_counted(self, tmp_path):
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [
            {"ts": f"{today}T10:00:00Z", "event": "executed",
             "command": "order", "venue": "hypercore", "amount": "100.0"},
            {"ts": f"{today}T11:00:00Z", "event": "executed",
             "command": "cancel", "venue": "hypercore", "amount": "0"},
            {"ts": f"{today}T12:00:00Z", "event": "executed",
             "command": "approve", "venue": "polymarket", "amount": "0"},
        ])
        assert _sum_today_sends("hypercore") == Decimal("0")

    def test_last_send_to_finds_perp_send(self, tmp_path):
        """_last_send_to must also recognize dotted-path send commands."""
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [{
            "ts": f"{today}T12:00:00Z", "event": "executed",
            "command": "perp.send", "to": "0xABC", "amount": "1.0",
        }])
        assert _last_send_to("0xABC") is not None

    def test_last_send_to_finds_bridge(self, tmp_path):
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [{
            "ts": f"{today}T12:00:00Z", "event": "executed",
            "command": "perp.bridge.arbitrum", "to": "0xABC", "amount": "5.0",
        }])
        assert _last_send_to("0xABC") is not None

    def test_last_send_to_ignores_non_send(self, tmp_path):
        today = time.strftime("%Y-%m-%d", time.gmtime())
        self._write_log(tmp_path, [{
            "ts": f"{today}T12:00:00Z", "event": "executed",
            "command": "order", "to": "0xABC", "amount": "100.0",
        }])
        assert _last_send_to("0xABC") is None

    def test_corrupt_line_in_cooldown(self, tmp_path):
        """Corrupted line doesn't prevent finding valid entries."""
        log_file = tmp_path / ".regard" / "send_log.jsonl"
        log_file.parent.mkdir(parents=True, exist_ok=True)
        log_file.write_text(
            "CORRUPT\n"
            + json.dumps({
                "ts": "2020-01-01T00:00:00Z", "event": "executed",
                "command": "send", "to": "0xABC",
            }) + "\n"
        )
        result = _last_send_to("0xABC")
        assert result is not None
