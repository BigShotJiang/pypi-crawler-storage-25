"""Tests for the canonical EVM address validator (`core.eth_address`).

The validator is the shared source of truth for `regard config set
killswitch-address` and `regard address add`. Behavior:

  - Mixed-case wrong checksum -> reject hard (CHECKSUM_INVALID)
  - All-lowercase -> normalize to checksummed (silent)
  - All-uppercase -> normalize to checksummed (silent)
  - Correctly checksummed -> accept as-is
  - All-digit (no letters) -> accept with stderr warning
  - Bad format / wrong length -> reject (INVALID_ADDRESS)
"""

import pytest

from regard.core.eth_address import validate_address

# Same address in three forms for parity-checking the normalize branches.
_CHECKSUMMED = "0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14"
_LOWERCASE = _CHECKSUMMED.lower()
_UPPERCASE = "0x" + _CHECKSUMMED[2:].upper()


class TestNormalize:
    """All-lowercase / all-uppercase input must normalize silently."""

    def test_lowercase_normalizes(self):
        assert validate_address(_LOWERCASE) == _CHECKSUMMED

    def test_uppercase_normalizes(self):
        assert validate_address(_UPPERCASE) == _CHECKSUMMED

    def test_correct_checksum_passes_through(self):
        assert validate_address(_CHECKSUMMED) == _CHECKSUMMED

    def test_strips_whitespace(self):
        assert validate_address(f"  {_CHECKSUMMED}  ") == _CHECKSUMMED


class TestRejectInvalidChecksum:
    """Mixed-case input must match the EIP-55 checksum.

    The user has asserted "this is the right case" by mixing upper/lower.
    A mismatch is treated as a likely typo or tampering and rejected hard
    — we don't show a 'corrected' form because we can't know which
    characters were intended.
    """

    def test_one_letter_flipped(self):
        # Flip the first uppercase 'E' to lowercase 'e' — checksum no longer holds
        bad = "0x347e363866Ad5849705e4c3be4FfA7ad0C3f4e14"
        with pytest.raises(SystemExit):
            validate_address(bad)

    def test_random_mixed_case_rejected(self):
        # Same hex value, mixed case that doesn't match EIP-55 output
        bad = "0x347E363866AD5849705E4c3bE4FFa7Ad0c3F4E14"
        with pytest.raises(SystemExit):
            validate_address(bad)


class TestFormatErrors:
    def test_too_short(self):
        with pytest.raises(SystemExit):
            validate_address("0x123")

    def test_too_long(self):
        with pytest.raises(SystemExit):
            validate_address("0x" + "a" * 64)

    def test_missing_0x_prefix(self):
        with pytest.raises(SystemExit):
            validate_address("347E363866Ad5849705e4c3be4FfA7ad0C3f4e14")

    def test_non_hex_char(self):
        with pytest.raises(SystemExit):
            validate_address("0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e1Z")

    def test_empty_string(self):
        with pytest.raises(SystemExit):
            validate_address("")


class TestAllDigitAddress:
    """Addresses with no a-f letters carry zero EIP-55 information.

    They're accepted (legitimate per spec — `0x0000...0000` is the zero
    address) but a stderr warning is emitted so callers know typo
    detection is impossible for these.
    """

    def test_zero_address_accepted_with_warning(self, capsys):
        zero = "0x" + "0" * 40
        result = validate_address(zero)
        assert result == zero
        captured = capsys.readouterr()
        assert "no letters" in captured.err
        assert "EIP-55 cannot detect typos" in captured.err

    def test_digit_only_accepted_with_warning(self, capsys):
        digits_only = "0x1234567890123456789012345678901234567890"
        result = validate_address(digits_only)
        # Digit-only addresses are their own checksum (no letters to mix)
        assert result.lower() == digits_only.lower()
        captured = capsys.readouterr()
        assert "no letters" in captured.err

    def test_letters_present_no_warning(self, capsys):
        validate_address(_CHECKSUMMED)
        captured = capsys.readouterr()
        assert captured.err == ""


class TestLabelInError:
    """The `label` kwarg flows into both error messages and the warning,
    so callers can disambiguate which address failed (killswitch destination
    vs address-book entry, etc.).
    """

    def test_label_appears_in_invalid_error(self, capsys):
        with pytest.raises(SystemExit):
            validate_address("not-an-address", label="killswitch destination")
        # The error envelope is on stdout (JSON), labels appear in the message
        captured = capsys.readouterr()
        assert "killswitch destination" not in captured.err  # label is in message, not warning
        assert '"INVALID_ADDRESS"' in captured.out or "killswitch" in captured.out

    def test_label_appears_in_digit_warning(self, capsys):
        zero = "0x" + "0" * 40
        validate_address(zero, label="killswitch destination")
        captured = capsys.readouterr()
        assert "killswitch destination" in captured.err
