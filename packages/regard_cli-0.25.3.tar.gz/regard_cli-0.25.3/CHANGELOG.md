# Changelog

## [v0.25.3] — 2026-05-07

### Refactored — v0.24-helper Decimal migration (Constitution Article II finalization)

The three v0.24-or-earlier safety helpers — `check_amount_cap`,
`check_daily_cap`, `classify_risk` — and the `_sum_today_sends` aggregator
now accept and return `Decimal` instead of `float`. Constitution Article II
clause (b), the temporary legacy-helper allowlist, is removed; the only
permitted `float()` boundary is now the inline argument expression of an
external-SDK call.

Every safety-helper call site updated: `act.py:spot_send`,
`act.py:perp_bridge_arbitrum`, `act.py:spot_bridge_hyperevm`,
`act.py:perp_send` (each propose+approve), `inbound_bridge.py` arbitrum +
hyperevm propose+approve, `polymarket/act.py:polygon_send` propose+approve.

Polymarket `polygon_send` got a deeper migration since it had been on a
pure-float pipeline (balance/sendable computed via float division and
stored in float-typed locals). The amount, balance, sendable, and gas
display values are now Decimal throughout; raw wei stays int per Article
II's "integer raw units" allowance.

User-visible: stringified amounts in `params`/`checks` payloads preserve
exact Decimal representation (`"5"` not `"5.0"` for whole numbers). No
behavioral change in normal operation; test count unchanged at 1345.

## [v0.25.2] — 2026-05-06

### Added — HL activation-fee disclosure on `hypercore spot send`

Per HL docs (`activation-gas-fee.md`): the first transfer to a fresh
HyperCore account burns 1 quote token (1 USDC, 1 USDH, 1 USDT0, 1 USDE)
as an activation fee. Pre-v0.25.2 the CLI had no signal — sending 5 USDC
to a never-activated address would silently deliver 4 USDC to the
recipient, with the 1 USDC burn invisible until the user reconciled
balances post-execute.

v0.25.2 detects fresh recipients at propose time via `info.spot_user_state`
+ `clearinghouseState` (both empty + zero) and surfaces:
- `checks.recipient_activation_fee: "1"` (when the sent token is a quote)
- `checks.recipient_credited` (= `amount - 1`, what the recipient actually
  receives)
- Warning `RECIPIENT_FRESH_ACTIVATION_FEE` explaining the mechanism
- Warning `ACTIVATION_FEE_EXCEEDS_AMOUNT` if `amount <= 1` (recipient gets
  nothing, the entire send is consumed by the fee)

For non-quote token sends to fresh recipients (e.g. HYPE, PURR), surfaces a
generic warning without an exact `recipient_credited` — HL's mechanics for
those cases aren't fully modelled. Detection is fail-soft: any RPC error in
`_is_fresh_hl_user` returns False, so the propose still goes through but
without a fee surfaced (under-warning beats over-warning when the venue
API misbehaves).

Generalizes the fintech-accuracy principle (`CLAUDE.md`,
`feedback_fintech_accuracy.md`) to a third surface: spot send joins the
HL→HyperEVM bridge fee disclosure (v0.25.0) and the perp_send
unified-mode hard block (v0.25.1).

### Refactored — `hypercore spot send` migrated to Decimal arithmetic

`act.py:spot_send` now uses Decimal for amount, balance, and projection
arithmetic per Constitution Article II. The legacy float pipeline (flagged
in `docs/V025-IMPLEMENTATION.md` Out-of-scope) is removed; `float()` calls
remain inline at the legacy safety-helper boundary (`check_amount_cap`,
`check_daily_cap`, `classify_risk`) until those helpers also migrate.
User-visible: `params.amount` and `checks.projected_balance` now preserve
Decimal representations (e.g. `Decimal("5") -> "5"` instead of legacy
`float(5) -> "5.0"`). One regression-test assertion updated in
`tests/test_act.py::TestHlSend::test_send_to_label`.

## [v0.25.1] — 2026-05-06

### Fixed — `hypercore perp send` hard-blocks in unified-account mode

- HL disables the `usd_transfer` SDK action when `account_mode` is
  `unifiedAccount` or `portfolioMargin` — at execution time HL returns
  `"Action disabled when unified account is active"`. v0.25.0 detected the
  mode but used a spot-USDC fallback to compute balance, so the propose
  succeeded and the user only learned the action was rejected after pressing
  approve. v0.25.1 hard-blocks at propose with new error code
  `PERP_SEND_DISABLED_UNIFIED_MODE` and a hint pointing at
  `regard hypercore spot send <label> <amount> --token USDC`, which works
  for all account modes. Caught live during K Test 3 of the v0.25.0 Bridges
  playbook on bonbonki (2026-05-06). Regression tests added in
  `tests/test_bridges.py::TestPerpSend`.

## [v0.25.0] — 2026-05-05

### Added — Outbound bridges (HL-signed)

- **`regard hypercore perp bridge arbitrum --to <addr|self> <amount>`** — withdraws
  USDC from the default-perp clearinghouse to an Arbitrum address via the HL
  Bridge2 contract. $1 fee, 3-5 min finalization. Accepts arbitrary `--to <addr>`
  or `--to self` (resolves to the wallet's Arbitrum address; same EOA). USDC
  only (no `--token` flag — Bridge2 accepts only USDC). Per Constitution
  Article VI.
- **`regard hypercore spot bridge hyperevm --to self <amount> --token <tok>`** —
  sends a Core spot token to the HyperEVM side via `sendAsset` to the token's
  system address. `--to self` is the only allowed value (HL credits sender's
  EVM address). Tokens: USDC, HYPE, USDH, USDE, USDT0, PURR — anything linked
  in `spot_meta`. Unlinked tokens hard-block with `BRIDGE_TOKEN_UNLINKED`
  (the EVM-side ERC-20 transfer would silently lose the funds otherwise).
- **`regard hypercore perp send <addr|label> <amount>`** — sends USDC from
  the perp clearinghouse to another HL user's perp clearinghouse, same-chain.
  Mirrors `hypercore spot send` shape but operates on perp. No fee. USDC only.

### Added — Inbound bridges (EVM-signed return paths)

- **`regard arbitrum bridge hypercore --to self <amount>`** — bridges Arbitrum
  native USDC back to HL perp clearinghouse via Bridge2. Sender signs an
  Arbitrum ERC-20 transfer; HL validators auto-credit the sender's HL perp
  account in <1 min. **Minimum 5 USDC** (HL silently loses below this — CLI
  hard-blocks at validation). Sender needs ETH on Arbitrum for gas.
- **`regard hyperevm bridge hypercore --to self <amount> --token <tok>`** —
  bridges a HyperEVM token back to HL spot. `--token HYPE` does a native
  value-send to `0x222...2222` (gas-limit override of 100k applied to handle
  the system contract's LOG3 op). Other tokens do an ERC-20 transfer to the
  token's system address. Sender needs HYPE on HyperEVM for gas.
- **`arbitrum` env prefix** — new chain prefix, sibling to `polygon`.
- **`hyperevm` env prefix** — new execution-layer prefix, sibling to `hypercore`.

### Added — Bridge fee disclosure (HL Core → HyperEVM)

- **`bridge_fee_estimate`, `bridge_fee_basis`, `bridge_fee_note`** in `hypercore spot
  bridge hyperevm` proposal `checks`. Per HL docs, the fee is `200,000 gas ×
  next-block HyperEVM baseFee` (paid in HYPE for HYPE bridges, in token-equivalent
  at the HYPE oracle rate for USD-linked stablecoins). Estimator
  (`_estimate_corespot_to_evm_fee`) reads the current baseFee + `info.all_mids()`
  HYPE rate and subtracts the estimate from `projected_spot`. RPC/oracle gaps are
  disclosed explicitly (`"unavailable"` + `(excludes unestimated bridge fee)`
  annotation), never silently fall back to a zero-fee projection. New warning
  `BRIDGE_FEE_INSUFFICIENT_BALANCE` fires if `balance - amount - fee_estimate < 0`.

### Fixed — Arbitrum baseFee race in `core/evm.py:get_safe_gas_price`

- `get_safe_gas_price` now adds 25% submit-time headroom to `eth_gasPrice` (integer
  arithmetic `* 5 // 4`). On Arbitrum, `eth_gasPrice` returns ≈ baseFee with no
  forward buffer; baseFee can rise between fetch and submit (Arbitrum block time
  ~250 ms), causing `max fee per gas less than block base fee` rejections at the
  RPC. Caught live during Cycle L Test 1; regression test
  `test_arbitrum_basefee_race_headroom` added. Anomaly-detection ceiling check
  unchanged.

### Added — Pre-propose checks

- **`BRIDGE_DEST_NO_GAS` warning** (outbound, soft) — pre-propose `eth_getBalance`
  query against the destination chain. Surfaces in proposal `warnings[]`. Bridge
  succeeds either way; the warning flags that recipient may need gas to use the
  bridged tokens.
- **`BRIDGE_SOURCE_NO_GAS` hard block** (inbound) — pre-propose `eth_getBalance`
  query against the source chain. Without native gas the EVM tx can't be signed.
- **`MIN_DEPOSIT_NOT_MET` hard block** (Arbitrum→HL) — rejects deposits below
  5 USDC.
- **`BRIDGE_TOKEN_UNLINKED` hard block** (HL→HyperEVM and HyperEVM→HL) —
  rejects tokens whose linked HyperEVM ERC-20 isn't resolvable.

### Added — RPC config

- **`arbitrum-rpc`** config knob (default = official Arbitrum Foundation `https://arb1.arbitrum.io/rpc`; user override sole-endpoint).
- **`hyperevm-rpc`** config knob (default = HL protocol-team `https://rpc.hyperliquid.xyz/evm`; user override sole-endpoint).
- **`ethereum-rpc`, `base-rpc`, `optimism-rpc`, `bsc-rpc`, `avalanche-rpc`, `monad-rpc`, `unichain-rpc`, `megaeth-rpc`** config knobs registered for forward-looking chains (no commands wire them yet — defaults reachable via `regard.core.rpc_pool` for future feature use).
- **RPC pool architecture** (`regard.core.rpc_pool`) — three-tier resolution per chain: (1) user override exclusive, (2) hardcoded protocol-team primary, (3) `chainlist.org/rpcs.json` failover filtered by reputation allowlist (`dRPC`, `PublicNode`, `OnFinality`, `1RPC`, `BlastAPI`, `PocketNetwork`, `bloXroute`, `Ankr`, `Tenderly`, `Alchemy`, `LlamaRPC`, `Chainstack`) and a demo/keyed URL strip. Every endpoint is `eth_chainId`-verified before use. chainlist response cached at `<project>/.regard/rpc-cache/chainlist.json` with 7-day TTL. Per memory `feedback_no_rpc_infra.md`: regard never hosts RPC infrastructure; defaults route through public providers only.

### Removed

- **`rpc.regard.computer/regard/evm/<chainId>` proxy** dropped as the default Polygon RPC. v0.24.0 had `https://rpc.regard.computer/regard/evm/137` baked in; v0.25.0 routes through `regard.core.rpc_pool` (Polygon Foundation primary `https://polygon-rpc.com` + chainlist failover). No grace period (per `feedback_no_backwards_compat.md`); users with the proxy URL hardcoded in their config will pick up the new default unless they had explicitly set `polygon-rpc` (in which case nothing changes — user override remains exclusive).

### Changed

- **Address book `--chain` flag now accepts `arbitrum` and `hyperevm`** in
  addition to `hypercore`, `polygon`, `both`. Help text updated to clarify
  that `both` still means `hypercore + polygon` (use explicit flags for the
  new chains).
- **CRITICAL-risk gate extended to bridges.** `regard approve` requires
  `--confirm-addr` for any send OR bridge command at CRITICAL risk. For
  `--to self` bridges where `dest_address` is a protocol-constant contract
  (e.g. Bridge2), the gate confirms `recipient_on_hl` (the user's HL EOA,
  user-specific) instead, so the confirmation is meaningful. Outbound bridges
  with user-supplied `--to <addr>` continue confirming `dest_address`.

### Fixed

- **Daily-cap and cooldown counters now include all dotted-path commands.**
  Pre-v0.25.0 the safety filter was a bare `command == "send"` string match,
  silently skipping `spot.send`, `perp.send`, and any `*.bridge.*` path.
  v0.25.0 fixes the filter so all send/bridge commands accumulate correctly
  toward the daily cap.

### Notes

- Spot USDC → Arbitrum and perp USDC → HyperEVM (outbound) remain
  agent-composed sequences. Article VI forbids sugar verbs that wrap multi-hop
  paths. SKILL.md "Cross-chain bridges" section documents both directions
  with worked recipes.
- Inbound bridges require **`--to self` only**: Bridge2 (Arbitrum) and the
  HyperCore system contract (HyperEVM) both credit the EVM transaction sender.
  No protocol path for redirecting to a third party.

## [v0.24.0] — 2026-05-04

### Breaking changes

- **Vocabulary rename per CLI Constitution Article VI.** Every `hl`-prefixed
  command is renamed to `hypercore`. Every `poly`-prefixed command is
  renamed to either `polymarket` (venue trading: `order`, `cancel`, `approve`,
  `redeem`, `merge`, `balance`, `positions`, `markets`, `market`, `event`,
  `prices`, `book`, `trades`, `orders`, `geo`, `status`) or `polygon`
  (chain operations: token transfers, sends).
- **Fund-movement commands restructured into explicit subcommand trees.**
  `hl transfer` (with `--from` / `--to` flags) is split into seven explicit
  commands under the new grammar `<env> <compartment> transfer <destination> <args>`:
  - `hypercore perp transfer spot <amount> --token USDC`
  - `hypercore perp transfer dex <name> <amount>`
  - `hypercore spot transfer perp <amount> --token USDC`
  - `hypercore spot transfer dex <name> <amount> --token <tok>`
  - `hypercore dex <name> transfer spot <amount> --token <tok>`
  - `hypercore dex <name> transfer perp <amount>`
  - `hypercore dex <name> transfer dex <other> <amount> --token <tok>`

  The destination compartment is visible in every command name; `--from`/`--to`
  flags are gone. See `docs/CLI-CONSTITUTION.md` Article VI and
  `docs/V024-IMPLEMENTATION.md` for the full mapping.
- **`hl send` moves under spot.** Wallet-to-wallet sends are now
  `regard hypercore spot send <addr> <amount> --token <tok>`. The destination
  is positional; address-book labels are the default. Raw 0x addresses
  require both `--raw` and `SEND_ALLOW_RAW_ADDRESS=true`.
- **Polygon chain operations consolidated under `polygon`.** What used to be
  `poly deposit`, `poly wrap`, `poly unwrap`, and `poly send` now live under
  the new `polygon` env prefix as compartment-shift commands:
  - `polygon usdc transfer usdce <amount>` (was `poly deposit`)
  - `polygon usdce transfer pusd <amount>` (was `poly wrap`)
  - `polygon pusd transfer usdce <amount>` (was `poly unwrap`)
  - `polygon send <addr> <amount> --token <tok>` (was `poly send`)
- **No deprecation aliases.** Old commands are gone in this single commit.
  Update scripts, skills, and any external callers to the new vocabulary.
- **Address book chain tags renamed.** Existing entries tagged
  `chains: ["hl"]` will not resolve under `hypercore` commands. Re-add
  affected entries with the new chain tag (`--chain hypercore` or
  `--chain both`). No automatic migration is performed.
- **Send-cap state effectively resets at the upgrade boundary.** Daily
  send-cap counters track venue strings; pre-rename history (entries with
  `venue="hl"` or `venue="poly"`) does not contribute to today's cap if
  today straddles the upgrade. Historical entries remain readable for
  audit but do not count toward the cap. Effectively, the cap resets
  at the upgrade boundary.
- **Killswitch result keys renamed.** `regard killswitch` now returns
  `{"hypercore": {...}, "polymarket": {...}}` instead of `{"hl": {...}, "poly": {...}}`.

### Removed

- **Dropped `poly deposit --token usdc_e` source path.** Same-chain
  Polygon→Polygon `--token usdc_e` was a Bridge-API round-trip
  (USDC.e in → USDC.e out, paying ~0.08% bridge fee for no value-add).
  The CollateralOnramp wrap path is preserved as
  `polygon usdce transfer pusd <amount>` (1:1, on-chain, no fees).
  Cross-chain extension (Ethereum / Arbitrum / Base / etc. → Polygon
  USDC.e) is deferred to v0.25+ under the
  `<source-chain> usdc bridge polygon --to <addr>` shape per Article VI.

### Added

- `--max-slippage-bps N` option on `regard hypercore order` for market
  orders (closes the spot-order slippage gap from `docs/HIP-4-IMPLEMENTATION.md`).
  Pass-through to `exchange.market_open(..., slippage=N/10000)`. When unset,
  the SDK default (5%) applies.

### Out of scope (slated for v0.25.0)

- `hyperevm` env prefix and HyperEVM-native commands.
- New bridge commands (`hypercore spot bridge arbitrum`,
  `hypercore spot bridge hyperevm`, `hypercore perp bridge arbitrum`,
  `hypercore perp send`).
- MCP `ToolAnnotations` wrapper-decorator implementation (the constitutional
  rule applies forward; v0.25.0 is when there is a wrapper to apply it on).
