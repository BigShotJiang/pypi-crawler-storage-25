"""Transfer safety — amount caps, cooldown, risk classification.

All enforcement happens at the CLI level. Not in hooks, not in LLM config.

Send log lives at `<project>/.regard/send_log.jsonl` (project-local since v0.19).
Daily cap + cooldown are computed per-project — running regard from a different
project directory gets an independent cap/cooldown (consistent with per-project
auth scope).
"""

import calendar
import json
import sys
import time
from decimal import Decimal, InvalidOperation

from regard.core.output import die
from regard.core.project_dir import get_regard_dir


def _log_file():
    """Resolve `<project>/.regard/send_log.jsonl` at call time (CWD may differ per call)."""
    return get_regard_dir() / "send_log.jsonl"


def classify_risk(amount: Decimal, balance: Decimal) -> str:
    """Classify send risk based on amount as percentage of balance.

    Returns: "STANDARD", "HIGH", or "CRITICAL"
    """
    if balance <= 0:
        return "CRITICAL"
    pct = amount / balance
    if pct > Decimal("0.9"):
        return "CRITICAL"
    if pct > Decimal("0.5"):
        return "HIGH"
    return "STANDARD"


def check_amount_cap(amount: Decimal, token: str, settings_env: dict) -> None:
    """Die if amount exceeds configured per-operation cap."""
    cap_key = "SEND_MAX_AMOUNT"
    cap_str = settings_env.get(cap_key)
    if cap_str is None:
        return
    try:
        cap = Decimal(str(cap_str))
    except (InvalidOperation, ValueError, TypeError):
        return
    if amount > cap:
        die(
            "validation_error", "AMOUNT_CAP_EXCEEDED",
            f"Send amount {amount} {token} exceeds configured cap of {cap}",
            hint=f"Adjust {cap_key} in settings or reduce the amount",
        )


def check_daily_cap(amount: Decimal, token: str, venue: str, settings_env: dict) -> None:
    """Die if today's total + this send exceeds daily cap."""
    cap_str = settings_env.get("SEND_DAILY_MAX")
    if cap_str is None:
        return
    try:
        cap = Decimal(str(cap_str))
    except (InvalidOperation, ValueError, TypeError):
        return

    today_total = _sum_today_sends(venue)
    if today_total + amount > cap:
        die(
            "validation_error", "DAILY_CAP_EXCEEDED",
            f"This send ({amount} {token}) would bring today's total to {today_total + amount}, "
            f"exceeding the daily cap of {cap}",
            hint="Adjust SEND_DAILY_MAX in settings or wait until tomorrow",
        )


def check_cooldown(dest_address: str, settings_env: dict) -> None:
    """Die if a send to this address was made too recently."""
    cooldown_str = settings_env.get("SEND_COOLDOWN", "30")
    try:
        cooldown = int(cooldown_str)
    except (ValueError, TypeError):
        cooldown = 30

    if cooldown <= 0:
        return

    last_send_ts = _last_send_to(dest_address)
    if last_send_ts is None:
        return

    elapsed = time.time() - last_send_ts
    if elapsed < cooldown:
        remaining = int(cooldown - elapsed)
        die(
            "validation_error", "COOLDOWN_ACTIVE",
            f"Must wait {remaining}s before sending to this address again",
            hint=f"Cooldown is {cooldown}s (SEND_COOLDOWN). Last send was {int(elapsed)}s ago.",
        )


def _is_send_or_bridge(command: str) -> bool:
    """Match send and bridge commands across all dotted-path forms.

    Pre-v0.25.0 the filter was a bare `command == "send"` string match, which
    silently skipped `spot.send`, `perp.send`, and any `*.bridge.*` path —
    meaning past executions of those commands never accumulated toward the
    daily cap. v0.25.0 adds five new bridge/send commands and fixes the
    pre-existing gap in one place.

    Matches:
      "send"                            (legacy polygon)
      "spot.send", "perp.send"          (hypercore)
      "perp.bridge.arbitrum",
      "spot.bridge.hyperevm"            (hypercore outbound)
      "bridge.hypercore"                (arbitrum, hyperevm inbound)
    """
    parts = command.split(".")
    return command == "send" or parts[-1] == "send" or "bridge" in parts


def _sum_today_sends(venue: str) -> Decimal:
    """Sum all executed send/bridge amounts for today (UTC) from audit log.

    Filter is keyed by the same venue string `log_event` writes:
    - `"hypercore"` for hypercore spot/perp sends and outbound HL-signed bridges
    - `"polygon"` for Polygon-chain sends
    - `"arbitrum"` and `"hyperevm"` for inbound EVM-signed bridges
    Pre-rename history (`"hl"`/`"poly"`) does not contribute to today's cap if
    the day crosses the v0.24.0 upgrade boundary; documented in CHANGELOG.
    """
    today = time.strftime("%Y-%m-%d", time.gmtime())
    total = Decimal("0")
    log_file = _log_file()
    if not log_file.exists():
        return total
    try:
        for line in log_file.read_text().splitlines():
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if (
                record.get("event") == "executed"
                and _is_send_or_bridge(record.get("command", ""))
                and record.get("venue") == venue
                and record.get("ts", "").startswith(today)
            ):
                try:
                    total += Decimal(str(record.get("amount", 0)))
                except (InvalidOperation, ValueError):
                    continue
    except Exception:
        pass
    return total


def _last_send_to(dest_address: str) -> float | None:
    """Find the timestamp of the most recent executed send/bridge to this address."""
    log_file = _log_file()
    if not log_file.exists():
        return None
    dest_lower = dest_address.lower()
    last_ts = None
    try:
        for line in log_file.read_text().splitlines():
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                print(f"WARNING: corrupt audit log entry, skipping: {line[:80]}", file=sys.stderr)
                continue
            if (
                record.get("event") == "executed"
                and _is_send_or_bridge(record.get("command", ""))
                and record.get("to", "").lower() == dest_lower
            ):
                ts_str = record.get("ts", "")
                try:
                    ts = calendar.timegm(time.strptime(ts_str, "%Y-%m-%dT%H:%M:%SZ"))
                    if last_ts is None or ts > last_ts:
                        last_ts = ts
                except ValueError:
                    print(f"WARNING: unparseable timestamp in audit log: {ts_str}", file=sys.stderr)
    except Exception:
        pass
    return last_ts
