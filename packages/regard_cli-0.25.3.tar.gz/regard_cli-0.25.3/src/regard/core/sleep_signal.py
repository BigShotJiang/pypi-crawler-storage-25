"""Sleep / time-since-rest signal helpers for the tilt detector.

Phase 1 implementation: declarative-only. The user sets `tilt.sleep_window_local`
in `.regard/config.json` (e.g. `"23:00-07:00"`); we compute hours-since-most-
recent-wakeup against current local time. No wearable / no inactivity inference
in v0.20 — those land in Phase 5.

Returns 0.0 when sleep window is not declared. Caller treats this as "no
signal contribution" — the score formula multiplies by 1.5, so 0 input = 0
score penalty. Avoids penalizing users who simply haven't told us their
schedule.
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta

_SLEEP_WINDOW_RE = re.compile(r"^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$")


def _parse_window(sleep_window: str | None) -> tuple[int, int] | None:
    """Parse `HH:MM-HH:MM` into (wake_hour, wake_minute). None if unparseable.

    Both ends of the window are validated as legal clock times even though
    only the wake-end is consumed downstream — defense in depth against a
    config file with `24:00-07:00` quietly returning a "valid" tuple.
    """
    if not sleep_window:
        return None
    m = _SLEEP_WINDOW_RE.match(sleep_window.strip())
    if not m:
        return None
    try:
        sleep_h = int(m.group(1))
        sleep_m = int(m.group(2))
        wake_h = int(m.group(3))
        wake_m = int(m.group(4))
    except ValueError:
        return None
    if not (0 <= sleep_h <= 23 and 0 <= sleep_m <= 59):
        return None
    if not (0 <= wake_h <= 23 and 0 <= wake_m <= 59):
        return None
    return (wake_h, wake_m)


def hours_since_last_wakeup(
    sleep_window: str | None,
    now: datetime | None = None,
) -> float:
    """Compute hours since user's most recent declared wakeup.

    `sleep_window` format: `HH:MM-HH:MM` local time, e.g. `"23:00-07:00"`.
    The end of the window is the wakeup hour.

    Algorithm: today's wakeup if `now` is at-or-past it; otherwise yesterday's.
    `now` is the LOCAL system time (naive datetime); pass for testability.

    Returns 0.0 if window is unset or unparseable. Returns elapsed hours as
    a non-negative float otherwise.
    """
    parsed = _parse_window(sleep_window)
    if parsed is None:
        return 0.0
    wake_h, wake_m = parsed
    if now is None:
        now = datetime.now()  # naive local

    today_wake = now.replace(hour=wake_h, minute=wake_m, second=0, microsecond=0)
    wake = today_wake if now >= today_wake else today_wake - timedelta(days=1)
    elapsed = (now - wake).total_seconds() / 3600
    return max(0.0, elapsed)
