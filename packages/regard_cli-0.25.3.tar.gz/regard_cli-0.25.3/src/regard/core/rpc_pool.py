"""RPC pool — primary + chainlist-fetched failover with reputation filtering.

Per Constitution Article II + memory `feedback_no_rpc_infra.md`: regard does
not host RPC infrastructure. Defaults point at official chain-foundation /
protocol-team endpoints (PRIMARY_RPC). On primary failure, fetch
`chainlist.org/rpcs.json` (cached locally with TTL), filter candidates through
a small reputation allowlist (TRUSTED_RPC_OPERATORS), reject demo/keyed URLs,
verify `eth_chainId` at every candidate, return the first that succeeds.

User overrides via `regard config set <chain>-rpc <url>` bypass everything.

Public API: `get_web3(chain_id: int) -> Web3`.

Out of scope:
- HL trading API (`api.hyperliquid.xyz`) — single endpoint, hardcoded in HL SDK.
- Polymarket APIs (`*.polymarket.com`) — single Polymarket-operated endpoints.
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Any

import requests

from regard.core.output import die

# ---------------------------------------------------------------------------
# Tier 1 — Primary endpoints (hardcoded official protocol-team URLs)
# ---------------------------------------------------------------------------

PRIMARY_RPC: dict[int, str] = {
    1:     "https://ethereum-rpc.publicnode.com",   # No canonical Foundation RPC; PublicNode is the public-team-blessed proxy
    137:   "https://polygon-rpc.com",                # Polygon Foundation
    42161: "https://arb1.arbitrum.io/rpc",           # Arbitrum Foundation
    8453:  "https://mainnet.base.org",               # Base team (Coinbase)
    10:    "https://mainnet.optimism.io",            # Optimism Foundation
    56:    "https://bsc-dataseed.bnbchain.org",      # BNB Chain (Binance)
    43114: "https://api.avax.network/ext/bc/C/rpc",  # Ava Labs
    143:   "https://rpc.monad.xyz",                  # Monad team
    130:   "https://mainnet.unichain.org",           # Uniswap
    4326:  "https://mainnet.megaeth.com/rpc",        # MegaETH team
    999:   "https://rpc.hyperliquid.xyz/evm",        # Hyperliquid protocol team
}

# Mapping chainId → friendly name used to derive env var (`<NAME>_RPC`) and
# config key (`<name>-rpc`). Names match the existing _SETTINGS scheme.
CHAIN_NAMES: dict[int, str] = {
    1:     "ethereum",
    137:   "polygon",
    42161: "arbitrum",
    8453:  "base",
    10:    "optimism",
    56:    "bsc",
    43114: "avalanche",
    143:   "monad",
    130:   "unichain",
    4326:  "megaeth",
    999:   "hyperevm",
}


# ---------------------------------------------------------------------------
# Tier 2 — Reputation allowlist (operator hostname patterns)
# ---------------------------------------------------------------------------

# Substring match (case-insensitive) against the URL. A chainlist candidate is
# accepted only if it survives the demo/keyed filter AND its URL contains at
# least one pattern below. Symbolic entries (Alchemy, Chainstack) contribute 0
# failover URLs from chainlist today but are kept so user overrides via
# config naturally route through the same allowlist semantics if we later
# expand the source.
TRUSTED_RPC_OPERATORS: dict[str, list[str]] = {
    "dRPC":          [".drpc.org"],
    "PublicNode":    [".publicnode.com"],
    "OnFinality":    [".api.onfinality.io"],
    "1RPC":          ["1rpc.io/"],
    "BlastAPI":      [".public.blastapi.io"],
    "PocketNetwork": [".api.pocket.network"],
    "bloXroute":     [".rpc.blxrbdn.com"],
    "Ankr":          ["rpc.ankr.com/"],          # only non-keyed URLs survive
    "Tenderly":      [".gateway.tenderly.co"],   # virtual.* keyed paths excluded
    "Alchemy":       [".g.alchemy.com"],         # chainlist URLs are demo; symbolic only
    "LlamaRPC":      [".llamarpc.com"],
    "Chainstack":    [".chainstack.com"],        # not in chainlist (paid-only); symbolic
}


# ---------------------------------------------------------------------------
# URL hygiene — reject demo / keyed URLs before matching the allowlist
# ---------------------------------------------------------------------------

DEMO_KEYED_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"/v2/demo$"),                                              # Alchemy demo path
    re.compile(r"\$\{[A-Z_]+\}"),                                          # placeholder like ${ALCHEMY_API_KEY}
    re.compile(r"/[0-9a-f]{32,}", re.IGNORECASE),                          # 32+ hex char path segment (likely a key)
    re.compile(r"/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"),  # UUID (Tenderly virtual, etc.)
    re.compile(r"\?api[_-]?key=", re.IGNORECASE),                          # ?api_key= or ?apikey=
    re.compile(r"\?key=", re.IGNORECASE),                                  # generic ?key=
]


def is_keyed_or_demo(url: str) -> bool:
    """True if url matches any DEMO_KEYED_PATTERNS (likely embeds an API key
    or a demo placeholder). Used to filter chainlist candidates before
    matching the operator allowlist.
    """
    return any(p.search(url) for p in DEMO_KEYED_PATTERNS)


def matches_allowlist(url: str) -> bool:
    """True if url contains a hostname pattern from any TRUSTED_RPC_OPERATORS
    entry. Case-insensitive substring match.
    """
    lower = url.lower()
    for patterns in TRUSTED_RPC_OPERATORS.values():
        for pat in patterns:
            if pat.lower() in lower:
                return True
    return False


# ---------------------------------------------------------------------------
# chainlist.org cache
# ---------------------------------------------------------------------------

CHAINLIST_URL = "https://chainlist.org/rpcs.json"
CACHE_TTL_SECONDS = 7 * 24 * 3600  # 7 days
CHAINLIST_FETCH_TIMEOUT = 10        # seconds
RPC_REQUEST_TIMEOUT = 5             # per-endpoint chainId verification


def _cache_path() -> Path:
    """Per-project chainlist cache file."""
    from regard.core.project_dir import get_regard_dir
    cache_dir = get_regard_dir() / "rpc-cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / "chainlist.json"


def _fetch_chainlist_cached() -> list[dict[str, Any]] | None:
    """Return chainlist data, refreshed if cache is stale or missing.

    Behavior:
    - Cache hit (file exists, age < TTL): return cached JSON.
    - Cache miss / stale: fetch fresh, write to cache, return fresh.
    - Fetch fails AND stale cache present: return stale cache (best-effort).
    - Fetch fails AND no cache: return None (caller should skip failover).
    """
    cache = _cache_path()
    now = time.time()

    if cache.exists():
        age = now - cache.stat().st_mtime
        if age < CACHE_TTL_SECONDS:
            try:
                return json.loads(cache.read_text())
            except (OSError, json.JSONDecodeError):
                pass  # fall through to fetch

    # Cache miss or stale → fetch fresh
    try:
        resp = requests.get(CHAINLIST_URL, timeout=CHAINLIST_FETCH_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        try:
            cache.write_text(json.dumps(data))
        except OSError:
            pass  # cache write failure is non-fatal
        return data
    except (requests.RequestException, json.JSONDecodeError):
        # Fetch failed — try stale cache as last resort
        if cache.exists():
            try:
                return json.loads(cache.read_text())
            except (OSError, json.JSONDecodeError):
                pass
        return None


def _filter_candidates(chain_entry: dict[str, Any]) -> list[str]:
    """Extract HTTP URLs from a chainlist entry, drop demo/keyed, keep only
    URLs whose hostname matches the M4 reputation allowlist.
    """
    rpc_list = chain_entry.get("rpc", [])
    out: list[str] = []
    for entry in rpc_list:
        url = entry.get("url", "") if isinstance(entry, dict) else str(entry)
        if not url:
            continue
        if not url.startswith(("http://", "https://")):
            continue  # skip wss://, ipfs://, etc.
        if is_keyed_or_demo(url):
            continue
        if not matches_allowlist(url):
            continue
        out.append(url)
    return out


def _chainlist_entry_for(chain_id: int, data: list[dict[str, Any]]) -> dict[str, Any] | None:
    for entry in data:
        if entry.get("chainId") == chain_id:
            return entry
    return None


# ---------------------------------------------------------------------------
# chainId verification + Web3 construction
# ---------------------------------------------------------------------------


def _try_endpoint(url: str, expected_chain_id: int) -> Any | None:
    """Construct a Web3 client for url and verify it reports the expected chainId.

    Returns the Web3 instance on success, None on any failure (RPC unreachable,
    HTTP error, parse error, chainId mismatch).
    """
    try:
        from web3 import Web3
        w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": RPC_REQUEST_TIMEOUT}))
        actual = w3.eth.chain_id
        if actual != expected_chain_id:
            return None
        return w3
    except Exception:
        return None


def _user_override_url(chain_id: int) -> str | None:
    """Read the user's per-chain RPC override from project env, if set.

    Pattern: ENV var `<NAME>_RPC` (uppercase) — e.g., POLYGON_RPC, ARBITRUM_RPC.
    Settable via `regard config set <name>-rpc <url>` for chains exposed in
    the config surface; also honored if set as a real shell env var.
    """
    name = CHAIN_NAMES.get(chain_id)
    if name is None:
        return None
    env_var = f"{name.upper()}_RPC"
    try:
        from regard.core.project_state import load_project_env
        return load_project_env().get(env_var) or None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_web3(chain_id: int) -> Any:
    """Return a Web3 client for chain_id, with user-override → primary → failover.

    1. User config override (`<NAME>_RPC` env or via `regard config set <name>-rpc`)
       → exclusive use; chainId verified; die on mismatch.
    2. PRIMARY_RPC[chain_id] → if responsive AND chainId matches.
    3. chainlist.org candidates filtered by demo/keyed + M4 allowlist; first match wins.
    4. All exhausted → die("RPC_UNAVAILABLE").

    Per-process state. No caching of "which endpoint won" across calls within
    the same process (Web3 instances are cheap; the chainId check is one HTTP
    round-trip). Callers that need the same instance across calls should
    cache locally.
    """
    if chain_id not in PRIMARY_RPC:
        die("internal_error", "RPC_UNKNOWN_CHAIN",
            f"No PRIMARY_RPC configured for chainId {chain_id}",
            hint="Add the chain to regard.core.rpc_pool.PRIMARY_RPC and CHAIN_NAMES.",
            exit_code=7)

    name = CHAIN_NAMES[chain_id]

    # Tier 3: user override
    override = _user_override_url(chain_id)
    if override:
        w3 = _try_endpoint(override, chain_id)
        if w3 is not None:
            return w3
        die("validation_error", "RPC_CHAIN_MISMATCH",
            f"Configured {name}-rpc URL is unreachable or reports the wrong chainId",
            hint=f"Verify the URL: regard config show — or unset to fall back: regard config set {name}-rpc ''")

    # Tier 1: primary
    primary = PRIMARY_RPC[chain_id]
    w3 = _try_endpoint(primary, chain_id)
    if w3 is not None:
        return w3

    # Tier 2: chainlist failover
    data = _fetch_chainlist_cached()
    if data is None:
        die("venue_error", "RPC_UNAVAILABLE",
            f"Primary {name} RPC is unreachable and chainlist.org is unreachable (no cache available)",
            hint=f"Set {name}-rpc manually: regard config set {name}-rpc <url>",
            exit_code=4)

    entry = _chainlist_entry_for(chain_id, data)
    if entry is None:
        die("venue_error", "RPC_UNAVAILABLE",
            f"Primary {name} RPC is unreachable and chainlist.org has no entry for chainId {chain_id}",
            hint=f"Set {name}-rpc manually: regard config set {name}-rpc <url>",
            exit_code=4)

    candidates = _filter_candidates(entry)
    for url in candidates:
        w3 = _try_endpoint(url, chain_id)
        if w3 is not None:
            return w3

    # All exhausted
    die("venue_error", "RPC_UNAVAILABLE",
        f"All {name} RPC endpoints failed (primary + {len(candidates)} chainlist failover candidates)",
        hint=f"Set {name}-rpc manually: regard config set {name}-rpc <url>",
        exit_code=4)
