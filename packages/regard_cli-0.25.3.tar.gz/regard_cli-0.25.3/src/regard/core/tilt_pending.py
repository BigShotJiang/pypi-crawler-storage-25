"""Asymmetric change rule for tilt config — Ulysses contract mechanic.

Tightening any tilt limit takes effect immediately. Loosening writes a
pending change to `<project>/.regard/pending/tilt_<id>.json` with a 24h
default TTL (configurable via `tilt.asymmetric_change.loosening_delay_hours`);
the user must run `regard config tilt-confirm <id>` after the delay to
apply the change.

Modeled on gambling-harm-reduction research: limit reductions are immediate,
limit increases require a cooling-off period. The principle is that
decisions made in cool state outperform decisions made in hot state, and
loss aversion makes a 24h-deferred commitment stickier than a willpower
check.

Per-key direction rules below define what counts as "tightening" vs
"loosening" for each of the 17 tilt-* config keys.
"""

from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Literal

# ---------------------------------------------------------------------------
# Direction rules
# ---------------------------------------------------------------------------
#
# Tag legend:
#   "lower-tighter"   — numeric; lower value is tighter (most thresholds)
#   "higher-tighter"  — numeric; higher value is tighter (e.g. longshot_threshold_cents)
#   "nullable-num"    — numeric or None; None = no protection, value = protection;
#                       within values, lower is tighter
#   "true-tighter"    — bool; True = tighter (signal active)
#   "text-protection" — string or None; populated = protection on, null/empty = off
#   "neutral"         — no asymmetric semantics; always immediate
#
# Keys are JSON paths within the tilt block (tuple form).

_DIRECTION_RULES: dict[tuple[str, ...], str] = {
    ("daily_loss_budget_usd",): "nullable-num",
    ("daily_loss_budget_pct",): "nullable-num",
    ("max_session_hours",): "lower-tighter",
    ("max_yolo_session_hours",): "lower-tighter",
    ("mandatory_break_interval_hours",): "lower-tighter",
    ("sleep_window_local",): "text-protection",
    ("sleep_thresholds_hours", "yellow"): "lower-tighter",
    ("sleep_thresholds_hours", "orange"): "lower-tighter",
    ("sleep_thresholds_hours", "red"): "lower-tighter",
    ("first_red_pivot_enabled",): "true-tighter",
    ("win_streak_threshold",): "lower-tighter",
    ("size_deviation_baseline_days",): "neutral",
    ("polymarket", "longshot_threshold_cents"): "higher-tighter",
    ("polymarket", "longshot_max_size_pct"): "lower-tighter",
    ("hyperliquid", "leverage_ratchet_threshold"): "lower-tighter",
    ("hyperliquid", "outcome_near_expiry_enabled"): "true-tighter",
    ("hyperliquid", "outcome_near_expiry_minutes"): "higher-tighter",
    ("ulysses_text",): "text-protection",
    ("asymmetric_change", "loosening_delay_hours"): "higher-tighter",
}


Direction = Literal["tighten", "loosen", "neutral"]


def compare_direction(json_path: tuple[str, ...], old: Any, new: Any) -> Direction:
    """Classify a config change as tighten, loosen, or neutral.

    Used by `regard config set tilt-*` to decide whether to apply
    immediately (tighten/neutral) or write a pending entry (loosen).
    Unknown paths return neutral — defensive default that doesn't gate
    new keys behind asymmetric review until rules are defined.
    """
    rule = _DIRECTION_RULES.get(json_path, "neutral")
    if old == new:
        return "neutral"

    if rule == "lower-tighter":
        try:
            return "tighten" if float(new) < float(old) else "loosen"
        except (TypeError, ValueError):
            return "neutral"

    if rule == "higher-tighter":
        try:
            return "tighten" if float(new) > float(old) else "loosen"
        except (TypeError, ValueError):
            return "neutral"

    if rule == "nullable-num":
        if old is None and new is not None:
            return "tighten"  # adding protection
        if old is not None and new is None:
            return "loosen"   # removing protection
        if old is None and new is None:
            return "neutral"
        try:
            return "tighten" if float(new) < float(old) else "loosen"
        except (TypeError, ValueError):
            return "neutral"

    if rule == "true-tighter":
        return "tighten" if new else "loosen"

    if rule == "text-protection":
        old_has = bool(old) and (not isinstance(old, str) or old.strip())
        new_has = bool(new) and (not isinstance(new, str) or new.strip())
        if not old_has and new_has:
            return "tighten"
        if old_has and not new_has:
            return "loosen"
        return "neutral"  # text changed but both have content

    return "neutral"


# ---------------------------------------------------------------------------
# Pending file storage
# ---------------------------------------------------------------------------

_PENDING_FILENAME_PREFIX = "tilt_"


def _pending_dir(project_dir: Path) -> Path:
    return project_dir / ".regard" / "pending"


def _pending_path(project_dir: Path, pending_id: str) -> Path:
    return _pending_dir(project_dir) / f"{_PENDING_FILENAME_PREFIX}{pending_id}.json"


def _atomic_write(path: Path, content: str, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content)
    try:
        os.chmod(tmp, mode)
    except OSError:
        pass
    os.replace(tmp, path)


def _new_pending_id(cli_key: str, now: datetime) -> str:
    """Stable-ish short ID derived from key + timestamp (8 hex chars)."""
    seed = f"{cli_key}|{now.isoformat()}".encode()
    return hashlib.sha1(seed, usedforsecurity=False).hexdigest()[:8]


def write_pending(
    *,
    cli_key: str,
    json_path: tuple[str, ...],
    current_value: Any,
    requested_value: Any,
    project_dir: Path,
    ttl_hours: float = 24.0,
    now: datetime | None = None,
) -> dict:
    """Persist a pending change. Returns the entry dict.

    If a pending entry already exists for this `cli_key`, it's replaced —
    only one pending change per key at a time. The CLI surface should
    surface this replacement to the user explicitly (don't silently
    overwrite stale pending state).
    """
    if now is None:
        now = datetime.now(timezone.utc)

    # Remove any existing pending for this cli_key (one-per-key invariant)
    cancel_by_key(cli_key, project_dir)

    pending_id = _new_pending_id(cli_key, now)
    earliest = now + timedelta(hours=ttl_hours)
    entry = {
        "id": pending_id,
        "cli_key": cli_key,
        "json_path": list(json_path),
        "current_value": current_value,
        "requested_value": requested_value,
        "requested_at": now.isoformat(),
        "earliest_apply": earliest.isoformat(),
        "ttl_hours": ttl_hours,
    }
    _atomic_write(_pending_path(project_dir, pending_id), json.dumps(entry, indent=2) + "\n")
    return entry


def _read_pending(path: Path) -> dict | None:
    """Load a single pending file, returning None on read/parse error."""
    try:
        data = json.loads(path.read_text())
        if not isinstance(data, dict):
            return None
        return data
    except (json.JSONDecodeError, OSError):
        return None


def list_pending(
    project_dir: Path,
    *,
    prune: bool = False,
    now: datetime | None = None,
) -> list[dict]:
    """Return all pending entries, optionally pruning expired-and-overdue.

    "Expired" here means past their `earliest_apply` timestamp BUT we
    keep them — the user is supposed to run `tilt-confirm` after expiry.
    `prune=True` removes only files that are MALFORMED (unparseable)
    so they don't accumulate. Genuinely expired-but-unconfirmed entries
    stay until the user explicitly confirms or cancels.
    """
    pending_dir = _pending_dir(project_dir)
    if not pending_dir.is_dir():
        return []

    entries = []
    for path in sorted(pending_dir.glob(f"{_PENDING_FILENAME_PREFIX}*.json")):
        entry = _read_pending(path)
        if entry is None:
            if prune:
                try:
                    path.unlink()
                except OSError:
                    pass
            continue
        # Annotate with computed fields for display
        if now is None:
            now = datetime.now(timezone.utc)
        try:
            earliest = datetime.fromisoformat(entry.get("earliest_apply", ""))
            if earliest.tzinfo is None:
                earliest = earliest.replace(tzinfo=timezone.utc)
            remaining = (earliest - now).total_seconds()
            entry["ready"] = remaining <= 0
            entry["remaining_seconds"] = max(0, int(remaining))
        except ValueError:
            entry["ready"] = False
            entry["remaining_seconds"] = None
        entries.append(entry)
    return entries


def get_pending(pending_id: str, project_dir: Path) -> dict | None:
    """Look up a single pending entry by ID."""
    return _read_pending(_pending_path(project_dir, pending_id))


def find_pending_by_key(cli_key: str, project_dir: Path) -> dict | None:
    """Return the pending entry for a given cli_key, if any."""
    for entry in list_pending(project_dir):
        if entry.get("cli_key") == cli_key:
            return entry
    return None


def cancel_pending(pending_id: str, project_dir: Path) -> bool:
    """Delete a pending entry without applying. Returns True if found+deleted."""
    path = _pending_path(project_dir, pending_id)
    if not path.exists():
        return False
    try:
        path.unlink()
        return True
    except OSError:
        return False


def cancel_by_key(cli_key: str, project_dir: Path) -> int:
    """Delete any pending entries matching `cli_key`. Returns count deleted.

    Used internally to enforce one-pending-per-key when a new pending
    change is written.
    """
    count = 0
    pending_dir = _pending_dir(project_dir)
    if not pending_dir.is_dir():
        return 0
    for path in pending_dir.glob(f"{_PENDING_FILENAME_PREFIX}*.json"):
        entry = _read_pending(path)
        if entry and entry.get("cli_key") == cli_key:
            try:
                path.unlink()
                count += 1
            except OSError:
                pass
    return count


def confirm_pending(
    pending_id: str,
    project_dir: Path,
    *,
    now: datetime | None = None,
) -> tuple[Literal["ready", "too_early", "not_found"], dict | None]:
    """Validate that a pending change is ready to apply.

    Returns (status, entry_or_none). Does NOT remove the pending file —
    caller must call `cancel_pending(id)` AFTER successfully writing the
    new config value. This ordering protects the user from losing a
    24h-cooled-off approval to a transient OSError on the config write
    (disk full, permissions): the pending file survives the failed
    write, and the user can retry without re-waiting the cooling-off.

    Status `ready` means the TTL has elapsed and the entry is unchanged
    on disk. `too_early` means the cooling-off hasn't completed; the
    entry includes a `remaining_seconds` annotation.
    """
    entry = get_pending(pending_id, project_dir)
    if entry is None:
        return ("not_found", None)
    if now is None:
        now = datetime.now(timezone.utc)
    try:
        earliest = datetime.fromisoformat(entry["earliest_apply"])
        if earliest.tzinfo is None:
            earliest = earliest.replace(tzinfo=timezone.utc)
    except (KeyError, ValueError):
        return ("not_found", None)
    if now < earliest:
        entry["remaining_seconds"] = int((earliest - now).total_seconds())
        return ("too_early", entry)
    return ("ready", entry)
