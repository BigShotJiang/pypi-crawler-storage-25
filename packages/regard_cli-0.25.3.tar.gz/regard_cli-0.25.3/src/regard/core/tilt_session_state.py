"""Per-session tilt state — stores leverage snapshots so the leverage-ratchet
detector can compare current leverage to earlier-in-session.

Single state file at `<project>/.regard/tilt_session.json`. Schema:

    {
      "leverage_history": {
        "<asset>": [
          {"ts": "<iso8601-utc>", "lev": <float>},
          ...
        ],
        ...
      }
    }

Snapshots are appended on each tilt() invocation. Entries older than the
session window (default 24h) are pruned on every read. Corrupted state
files start fresh — never crash the tilt command for state-file errors.

This is a narrow, focused state surface. The Phase 3 events.jsonl journal
will subsume it as a more general agent-tilt + provenance log.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path


def _state_path(project_dir: Path) -> Path:
    return project_dir / ".regard" / "tilt_session.json"


def _atomic_write(path: Path, content: str, mode: int = 0o600) -> None:
    """Crash-safe write via tmp+rename. Mirrors core.project_state pattern."""
    import os
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content)
    try:
        os.chmod(tmp, mode)
    except OSError:
        pass
    os.replace(tmp, path)


def _load_raw(project_dir: Path) -> dict:
    """Read tilt_session.json, returning {} on missing/corrupt."""
    path = _state_path(project_dir)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def _prune_history(
    history: dict[str, list[dict]],
    *,
    max_age_hours: float,
    now: datetime | None = None,
) -> dict[str, list[dict]]:
    """Drop snapshots older than `max_age_hours` and assets with no remaining."""
    if now is None:
        now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=max_age_hours)
    out: dict[str, list[dict]] = {}
    for asset, snapshots in history.items():
        if not isinstance(snapshots, list):
            continue
        kept = []
        for snap in snapshots:
            if not isinstance(snap, dict):
                continue
            ts_str = snap.get("ts", "")
            if not ts_str:
                continue
            try:
                ts = datetime.fromisoformat(ts_str)
            except ValueError:
                continue
            # Normalize naive → UTC for comparison
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            if ts >= cutoff:
                # Coerce lev to float defensively (state file may be hand-edited)
                try:
                    lev = float(snap.get("lev", 0))
                except (TypeError, ValueError):
                    continue
                kept.append({"ts": ts.isoformat(), "lev": lev})
        if kept:
            out[asset] = kept
    return out


def load_leverage_history(
    project_dir: Path,
    *,
    max_age_hours: float = 24.0,
    now: datetime | None = None,
) -> dict[str, list[dict]]:
    """Return {asset: [{ts, lev}, ...]} pruned to last `max_age_hours`.

    Sorted oldest-first per asset so the first entry = baseline for ratchet
    detection. Returns `{}` for missing/corrupt state files.
    """
    raw = _load_raw(project_dir)
    history = raw.get("leverage_history", {})
    if not isinstance(history, dict):
        return {}
    pruned = _prune_history(history, max_age_hours=max_age_hours, now=now)
    # Ensure oldest-first (by ts) for ratchet baseline
    for asset, snaps in pruned.items():
        snaps.sort(key=lambda s: s["ts"])
    return pruned


def record_leverage_snapshot(
    leverage_by_asset: dict[str, float],
    project_dir: Path,
    *,
    max_age_hours: float = 24.0,
    now: datetime | None = None,
) -> Path | None:
    """Append a leverage snapshot for each asset to the session state.

    No-op (returns None) when `leverage_by_asset` is empty — saves the
    tilt detector from creating an empty state file when there are no
    open positions.

    Loads existing history, prunes expired entries, appends the new
    snapshot, atomic-writes back. Returns the state file path on
    successful write.
    """
    if not leverage_by_asset:
        return None
    if now is None:
        now = datetime.now(timezone.utc)
    ts_iso = now.isoformat()

    history = load_leverage_history(
        project_dir, max_age_hours=max_age_hours, now=now,
    )
    for asset, lev in leverage_by_asset.items():
        try:
            lev_f = float(lev)
        except (TypeError, ValueError):
            continue
        if lev_f <= 0:
            continue
        history.setdefault(asset, []).append({"ts": ts_iso, "lev": lev_f})

    state = {"leverage_history": history}
    path = _state_path(project_dir)
    try:
        _atomic_write(path, json.dumps(state, indent=2) + "\n")
        return path
    except OSError:
        return None
