"""EVM transaction safety — gas ceiling and simulation.

Constitution Article II: gas price ceiling per chain, simulation before submission.
"""


class EVMSafetyError(Exception):
    """Raised when a gas ceiling or simulation check fails."""


# Internal multiplier: reject if current gas exceeds this multiple of
# the recent median effective gas price. 10x is generous — catches genuine
# anomalies (RPC garbage, flash spikes) without triggering on normal
# fluctuations.
_GAS_CEILING_MULTIPLIER = 10

# Number of recent blocks to sample for fee history baseline.
_FEE_HISTORY_BLOCKS = 20

# Submit-time headroom over eth_gasPrice (numerator/denominator → 5/4 = +25%).
# eth_gasPrice on Arbitrum returns ≈ baseFee with no forward buffer; baseFee
# can rise between fetch and submit (Arbitrum block time ~250 ms), causing
# `max fee per gas less than block base fee` rejections at the RPC. 25% is
# enough headroom for normal block-to-block movement and is well within the
# anomaly-detection ceiling above.
_GAS_HEADROOM_NUM = 5
_GAS_HEADROOM_DEN = 4


def get_safe_gas_price(w3) -> int:
    """Fetch current gas price, validate against recent chain history.

    Compares the current gas price (base fee + priority fee) to the median
    effective gas price over the last 20 blocks. Uses fee_history with
    reward percentiles so both sides of the comparison include the priority
    fee — avoids false rejections on chains like Polygon where the tip is
    large relative to base fee.

    Anomaly check runs against raw eth_gasPrice. The returned value adds 25%
    submit-time headroom so the broadcast survives a baseFee uptick between
    fetch and submit (Arbitrum-style chains ship a new block every ~250 ms).

    Returns the gas price (wei, with headroom) if safe. Raises EVMSafetyError
    if too high.
    """
    gas_price = w3.eth.gas_price

    try:
        # Request 50th percentile priority fee per block so we compare
        # total effective gas prices (base + tip), not base-only.
        history = w3.eth.fee_history(_FEE_HISTORY_BLOCKS, "latest", [50])
        base_fees = history["baseFeePerGas"]
        rewards = history.get("reward", [])

        # Compute total effective gas price per block
        effective = []
        for i in range(len(rewards)):
            tip = rewards[i][0] if rewards[i] else 0
            effective.append(base_fees[i] + tip)

        if effective:
            median = sorted(effective)[len(effective) // 2]
            if median > 0:
                ratio = gas_price / median
                if ratio > _GAS_CEILING_MULTIPLIER:
                    current_gwei = gas_price / 10**9
                    median_gwei = median / 10**9
                    raise EVMSafetyError(
                        f"Transaction fees are unusually high right now. "
                        f"Current fee is {ratio:.0f}x above the recent average "
                        f"({current_gwei:.1f} vs {median_gwei:.1f} gwei)."
                    )
    except EVMSafetyError:
        raise
    except Exception:
        # If fee history is unavailable (old node, non-EIP-1559 chain),
        # skip the ceiling check — we still have simulation as a safety net.
        pass

    return gas_price * _GAS_HEADROOM_NUM // _GAS_HEADROOM_DEN


def simulate_and_send(w3, tx: dict, account) -> bytes:
    """Simulate a transaction via eth_call, then sign and send.

    Takes an unsigned transaction dict (from build_transaction) and an
    account. Runs eth_call to catch reverts, insufficient balances, and
    state-dependent failures before spending gas.

    Returns the transaction hash. Raises EVMSafetyError if simulation reverts.
    """
    # Build simulation params — eth_call only needs these fields
    sim = {k: v for k, v in tx.items() if k in ("from", "to", "value", "data", "gas")}

    try:
        w3.eth.call(sim)
    except Exception as e:
        raise EVMSafetyError(f"Transaction would fail: {e}") from e

    signed = account.sign_transaction(tx)
    return w3.eth.send_raw_transaction(signed.raw_transaction)


# --- Shared transfer utilities ---
# Extracted from killswitch. Used by killswitch and send commands.

# Minimal ABI for ERC-20 transfer + balanceOf
ERC20_ABI = [
    {
        "constant": False,
        "inputs": [
            {"name": "_to", "type": "address"},
            {"name": "_value", "type": "uint256"},
        ],
        "name": "transfer",
        "outputs": [{"name": "", "type": "bool"}],
        "type": "function",
    },
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "type": "function",
    },
]


def transfer_erc20(
    w3, account, dest: str, token_address: str, amount_raw: int,
    *, nonce: int | None = None, gas_limit: int = 100_000,
) -> bytes:
    """Send ERC-20 tokens with safe gas estimation.

    Args:
        w3: Web3 instance
        account: eth_account.Account (has .address and can sign)
        dest: checksummed destination address
        token_address: checksummed ERC-20 contract address
        amount_raw: amount in token's smallest unit (e.g. 1_000_000 for 1 USDC)
        nonce: explicit nonce, or None to fetch from chain
        gas_limit: gas limit for the transfer (default 100k)

    Returns tx hash bytes. Raises EVMSafetyError on simulation failure.
    """
    gas_price = get_safe_gas_price(w3)
    if nonce is None:
        nonce = w3.eth.get_transaction_count(account.address, "pending")
    contract = w3.eth.contract(
        address=w3.to_checksum_address(token_address), abi=ERC20_ABI,
    )
    tx = contract.functions.transfer(
        w3.to_checksum_address(dest), amount_raw,
    ).build_transaction({
        "from": account.address,
        "nonce": nonce,
        "gas": gas_limit,
        "gasPrice": gas_price,
        "chainId": w3.eth.chain_id,
    })
    return simulate_and_send(w3, tx, account)


def transfer_native(
    w3, account, dest: str, amount_wei: int,
    *, nonce: int | None = None, gas_limit: int = 21_000,
) -> bytes:
    """Send native token (POL/ETH) with safe gas estimation.

    Args:
        w3: Web3 instance
        account: eth_account.Account
        dest: checksummed destination address
        amount_wei: amount in wei
        nonce: explicit nonce, or None to fetch from chain
        gas_limit: gas limit (default 21k for simple transfer)

    Returns tx hash bytes. Raises EVMSafetyError on simulation failure.
    """
    gas_price = get_safe_gas_price(w3)
    if nonce is None:
        nonce = w3.eth.get_transaction_count(account.address, "pending")
    tx = {
        "from": account.address,
        "to": w3.to_checksum_address(dest),
        "value": amount_wei,
        "gas": gas_limit,
        "gasPrice": gas_price,
        "nonce": nonce,
        "chainId": w3.eth.chain_id,
    }
    return simulate_and_send(w3, tx, account)


def get_erc20_balance(w3, owner: str, token_address: str) -> int:
    """Read ERC-20 balance in smallest unit."""
    contract = w3.eth.contract(
        address=w3.to_checksum_address(token_address), abi=ERC20_ABI,
    )
    return contract.functions.balanceOf(w3.to_checksum_address(owner)).call()
