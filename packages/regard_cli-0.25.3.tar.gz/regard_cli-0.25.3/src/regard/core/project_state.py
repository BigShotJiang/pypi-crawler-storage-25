"""Wallet + config persistence for the project-local `.regard/` layout.

Two files, two concerns:

  <project>/.regard/secrets/wallet.json  — private keys. 0o600 file in 0o700 dir.
                                           Schema: {"evm": {"private_key", "address"}}
                                           [future: "solana": {...}]
  <project>/.regard/config.json          — non-secret config + address book.
                                           Schema: {"env": {...flat env-style...}, "addresses": {...}}

`load_project_env()` returns a flat env-style dict (the contract that
read-only callers across the codebase depend on). It expands
`evm.private_key` from wallet.json into both `HYPERLIQUID_PRIVATE_KEY` and
`POLYMARKET_PRIVATE_KEY` (one wallet, two venues), and merges the flat keys
from config.json's `env` block on top.
"""

import json
import os
from pathlib import Path

from regard.core.project_dir import find_project_dir


def _wallet_path(project: Path) -> Path:
    return project / ".regard" / "secrets" / "wallet.json"


def _config_path(project: Path) -> Path:
    return project / ".regard" / "config.json"


def _atomic_write(path: Path, content: str, mode: int = 0o600) -> None:
    """Write to a sibling .tmp file, chmod, then rename. Crash-safe.

    `os.replace()` preserves the SOURCE (tmp) file's mode bits on POSIX —
    the destination's prior mode is discarded. So setting `mode` on the
    tmp BEFORE rename propagates the locked-down permissions to the final
    path, regardless of whether the destination already existed. POSIX-only;
    partial no-op on Windows.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content)
    try:
        os.chmod(tmp, mode)
    except OSError:
        pass
    os.replace(tmp, path)


# ---------------------------------------------------------------------------
# Wallet (private keys)
# ---------------------------------------------------------------------------

def load_wallet(cwd: str | None = None) -> dict:
    """Return the wallet dict, or `{}` if no wallet/project found.

    Shape: {"evm": {"private_key": "0x...", "address": "0x..."}, [...]}
    """
    project = find_project_dir(cwd)
    if project is None:
        return {}
    path = _wallet_path(project)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_wallet(wallet: dict, project_dir: Path) -> Path:
    """Atomic write of the full wallet dict to `.regard/secrets/wallet.json`.

    Caller passes the project root directory. Creates `.regard/secrets/`
    with 0o700 if missing, writes wallet.json with 0o600.
    """
    secrets_dir = project_dir / ".regard" / "secrets"
    secrets_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(secrets_dir, 0o700)
    except OSError:
        pass
    path = secrets_dir / "wallet.json"
    _atomic_write(path, json.dumps(wallet, indent=2) + "\n", mode=0o600)
    return path


# ---------------------------------------------------------------------------
# Config (non-secret)
# ---------------------------------------------------------------------------

def load_config(cwd: str | None = None) -> dict:
    """Return the full config dict, or `{}` if no config/project found.

    Shape: {"env": {...flat env-style...}, "addresses": {...}}
    """
    project = find_project_dir(cwd)
    if project is None:
        return {}
    path = _config_path(project)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_config(config: dict, project_dir: Path) -> Path:
    """Atomic write of the full config dict to `.regard/config.json`.

    Mode 0o600 — config holds killswitch destination + send caps; not
    secret material per se but no reason to expose more broadly.
    """
    regard_dir = project_dir / ".regard"
    regard_dir.mkdir(parents=True, exist_ok=True)
    path = regard_dir / "config.json"
    _atomic_write(path, json.dumps(config, indent=2) + "\n", mode=0o600)
    return path


def set_config_env(env_var: str, value: str, project_dir: Path) -> Path:
    """Merge a single flat env-style key into config.json's `env` block."""
    config = {}
    path = _config_path(project_dir)
    if path.exists():
        try:
            config = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    env = config.setdefault("env", {})
    env[env_var] = value
    return save_config(config, project_dir)


# ---------------------------------------------------------------------------
# Tilt config (typed, nested) — separate from flat env block
# ---------------------------------------------------------------------------
#
# The flat `env` block stores env-var-style strings. Tilt config is typed
# structured config (ints, floats, bools, nested objects), so it lives in
# its own top-level `tilt` block in config.json. Defaults baked in here;
# user values from the file merge on top.

_TILT_DEFAULTS: dict = {
    "daily_loss_budget_usd": None,           # null = fall back to pct or 3% account default
    "daily_loss_budget_pct": None,
    "max_session_hours": 8,
    "max_yolo_session_hours": 8,
    "mandatory_break_interval_hours": 6,
    "sleep_window_local": None,              # e.g. "23:00-07:00"; null = no declared window
    "sleep_thresholds_hours": {
        "yellow": 18,
        "orange": 24,
        "red": 36,
    },
    "first_red_pivot_enabled": True,
    "win_streak_threshold": 5,
    "size_deviation_baseline_days": 7,
    "polymarket": {
        "longshot_threshold_cents": 5,
        "longshot_max_size_pct": 2.0,
    },
    "hyperliquid": {
        "leverage_ratchet_threshold": 5,
        "outcome_near_expiry_enabled": True,
        "outcome_near_expiry_minutes": 60,
    },
    "ulysses_text": None,                    # surfaced at RED-level interventions
    "asymmetric_change": {
        "loosening_delay_hours": 24,
    },
}


def _deep_merge(base: dict, overlay: dict) -> dict:
    """Merge overlay onto base; nested dicts merge recursively, scalars overwrite."""
    out = dict(base)
    for k, v in overlay.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_tilt_config(cwd: str | None = None) -> dict:
    """Return tilt config — defaults with user values merged on top.

    Returns the full nested structure (no flattening). Read-only — does
    not warn or die. If no project found, returns defaults unchanged.
    """
    config = load_config(cwd)
    user = config.get("tilt", {}) if isinstance(config.get("tilt"), dict) else {}
    return _deep_merge(_TILT_DEFAULTS, user)


def set_tilt_config(json_path: list[str], value, project_dir: Path) -> Path:
    """Write a value at the given path within config.json's `tilt` block.

    `json_path` is a list of keys, e.g. ["polymarket", "longshot_threshold_cents"].
    `value` can be any JSON-serializable type — int, float, bool, str, None.
    Caller is responsible for type validation; this function only persists.
    """
    config = {}
    cfg_path = _config_path(project_dir)
    if cfg_path.exists():
        try:
            config = json.loads(cfg_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    tilt = config.setdefault("tilt", {})
    if not isinstance(tilt, dict):
        tilt = {}
        config["tilt"] = tilt
    cursor = tilt
    for k in json_path[:-1]:
        nxt = cursor.get(k)
        if not isinstance(nxt, dict):
            nxt = {}
            cursor[k] = nxt
        cursor = nxt
    cursor[json_path[-1]] = value
    return save_config(config, project_dir)


# ---------------------------------------------------------------------------
# Unified env contract (flat dict, legacy callers)
# ---------------------------------------------------------------------------

def load_project_env(cwd: str | None = None) -> dict:
    """Return a flat env-style dict merging config.json + wallet.json.

    Wallet expansion: `evm.private_key` populates both
    HYPERLIQUID_PRIVATE_KEY and POLYMARKET_PRIVATE_KEY (one wallet, both
    venues). Config `env` keys merge on top.

    Returns `{}` if no project found. Read-only — does not warn or die.
    """
    project = find_project_dir(cwd)
    if project is None:
        return {}
    out: dict[str, str] = {}

    # Wallet keys first
    wallet_path = _wallet_path(project)
    if wallet_path.exists():
        try:
            wallet = json.loads(wallet_path.read_text())
            evm_key = wallet.get("evm", {}).get("private_key")
            if evm_key:
                out["HYPERLIQUID_PRIVATE_KEY"] = evm_key
                out["POLYMARKET_PRIVATE_KEY"] = evm_key
        except (json.JSONDecodeError, OSError):
            pass

    # Config env block second (lets users override wallet-derived values
    # via config if they ever want to point HL and Poly at different keys —
    # not the default, but the contract permits it)
    config_path = _config_path(project)
    if config_path.exists():
        try:
            config = json.loads(config_path.read_text())
            env = config.get("env", {})
            if isinstance(env, dict):
                out.update({k: v for k, v in env.items() if isinstance(v, str)})
        except (json.JSONDecodeError, OSError):
            pass

    return out
