"""EVM address validation — single source of truth.

EIP-55 checksum logic shared by `regard config set killswitch-address`
and `regard address add`. Three branches:

  - Mixed-case input that fails the EIP-55 checksum -> reject hard.
    A user who manually capitalized the address (or whose wallet returned
    a checksummed form) is asserting "this is the right case." If the
    checksum disagrees, the address has been tampered with or mis-keyed
    since it left the source.
  - All-lowercase or all-uppercase -> normalize to the checksummed form.
    Per EIP-55, these are valid encodings that simply carry no checksum
    information; tools normalize them rather than reject them. The
    standard CLI/library pattern (web3.py, ethers.js, viem) is to do the
    same so that wallet APIs which return lowercase don't trigger a
    false-positive rejection.
  - Correctly checksummed -> return as-is.

Caveat: addresses with no letters (only 0-9 digits) carry zero checksum
information by design — EIP-55 cannot detect typos. We accept them but
emit a one-line stderr warning so the caller is aware. Real EOAs almost
never look like this; a digit-only address is usually a contract or
the zero address.
"""

import re
import sys

from regard.core.output import die

_HEX_ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")


def _is_all_digit(addr: str) -> bool:
    """True if the address has no a-f letters.

    Caller is expected to have already passed the address through
    `_HEX_ADDRESS_RE`, which enforces the `0x` prefix — so we always
    strip the leading two chars.
    """
    return addr[2:].isdigit()


def validate_address(addr: str, *, label: str = "address") -> str:
    """Validate and normalize an EVM address.

    Returns the EIP-55 checksummed form. Dies on invalid format or on
    mixed-case input whose checksum is wrong. Normalizes all-lowercase
    or all-uppercase input. Warns (stderr) when the address has no
    letters and therefore zero checksum coverage.
    """
    addr = addr.strip()
    if not _HEX_ADDRESS_RE.match(addr):
        die(
            "validation_error", "INVALID_ADDRESS",
            f"Expected a 0x-prefixed EVM address (40 hex chars). Got: {addr[:6]}… ({len(addr)} chars)",
            hint="An EVM address looks like 0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14",
        )

    try:
        from eth_utils import is_checksum_address, to_checksum_address
    except ImportError as e:
        # eth_utils is a transitive dep of eth-account and web3 (both declared
        # direct deps), so this branch is unreachable in any valid install.
        # If we somehow get here, fail loudly — silently returning the address
        # unchecked would let bad checksums slip through the gate this module
        # exists to enforce.
        raise RuntimeError(
            "eth_utils is required for EIP-55 address validation but could not be imported. "
            "This indicates a broken install — reinstall with `uv tool install regard-cli --force`."
        ) from e

    body = addr[2:]
    letters = [c for c in body if c.isalpha()]
    is_mixed_case = any(c.isupper() for c in letters) and any(c.islower() for c in letters)

    if is_mixed_case and not is_checksum_address(addr):
        # Mixed case is an assertion that the capitalization is meaningful
        # (a checksum attempt). A mismatch signals a typo or tampering.
        # Don't show a "corrected" address — we don't know which letters
        # were intended. All-uppercase / all-lowercase fall through to
        # normalization since neither carries checksum information.
        die(
            "validation_error", "CHECKSUM_INVALID",
            f"EIP-55 checksum invalid for {label}: {addr}",
            hint="Copy the address directly from your wallet or block explorer without modifying capitalization",
        )

    checksummed = to_checksum_address(addr)
    if _is_all_digit(addr):
        sys.stderr.write(
            f"[regard] note: {label} {addr} contains no letters (only 0-9) — "
            "EIP-55 cannot detect typos in addresses with no letters. Double-check before continuing.\n"
        )
    return checksummed
