"""Project-local directory resolution — shared across CLI commands.

A regard project is any directory containing a `.regard/` subdirectory. All
project-local state lives under `<project>/.regard/`:

    <project>/.regard/
      secrets/wallet.json   ← private keys (chmod 0o600, dir chmod 0o700)
      config.json           ← non-secret config (killswitch, RPC, send caps, addresses)
      events.jsonl          ← append-only audit trail
      pending/p_*.json      ← active proposals
      send_log.jsonl        ← per-day send-cap state

Walk-up lookup from CWD lets users run `regard` from any subdirectory of
the project (analogous to git finding `.git/`). Traversal stops BEFORE
$HOME so a stray `~/.regard/` is never treated as a project root.
"""

import os
from pathlib import Path

from regard.core.output import die

_PROJECT_MARKER = ".regard"


def find_project_dir(cwd: str | None = None) -> Path | None:
    """Walk up from CWD for a dir containing `.regard/`.

    Returns the project root (the dir *containing* `.regard/`, not the
    `.regard/` dir itself). Stops before $HOME — reaching HOME without a
    match returns None.
    """
    try:
        home = Path.home().resolve()
        cur = (Path(cwd) if cwd else Path.cwd()).resolve()
    except Exception:
        return None
    while True:
        if cur == home:
            return None
        if (cur / _PROJECT_MARKER).is_dir():
            return cur
        parent = cur.parent
        if parent == cur:
            return None
        cur = parent


def get_regard_dir(cwd: str | None = None) -> Path:
    """Return `<project>/.regard/`, creating `pending/` and `secrets/` eagerly.

    Dies with NO_PROJECT if no project dir is found. `secrets/` is chmod
    0o700 (owner-only) so other users on a multi-user box can't enumerate
    file names; idempotent on each call so older installs get tightened
    automatically.
    """
    project = find_project_dir(cwd)
    if project is None:
        die(
            "auth_error", "NO_PROJECT",
            f"No regard project found. Looked for .regard/ in {Path.cwd()} and above.",
            hint="cd to your project directory, or run `regard wallet <key>` here to set one up",
            exit_code=3,
        )
    regard_dir = project / _PROJECT_MARKER
    regard_dir.mkdir(parents=True, exist_ok=True)
    (regard_dir / "pending").mkdir(exist_ok=True)
    secrets_dir = regard_dir / "secrets"
    secrets_dir.mkdir(exist_ok=True)
    # 0o700 = owner-only directory. POSIX-only; partial no-op on Windows.
    try:
        os.chmod(secrets_dir, 0o700)
    except OSError:
        pass
    return regard_dir
