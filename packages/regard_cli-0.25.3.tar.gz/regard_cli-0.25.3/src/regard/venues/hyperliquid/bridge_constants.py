"""Bridge-related constants for Arbitrum <-> HL and HyperEVM <-> HL paths.

Pure constants module — no imports from regard.* and no logic. Tests import
this directly to verify pinned values (Bridge2 contract address, native USDC
address, HYPE system address).
"""

from decimal import Decimal

# ---------------------------------------------------------------------------
# Arbitrum (chainId 42161) — Hyperliquid Bridge2 deposit target
# ---------------------------------------------------------------------------

ARB_CHAIN_ID = 42161

# Native USDC on Arbitrum (Circle-issued, not USDC.e bridged).
ARB_USDC_CONTRACT = "0xaf88d065e77c8cC2239327C5EDb3A432268e5831"

# Hyperliquid Bridge2 deposit target. Sending native USDC to this address
# from any Arbitrum EOA auto-credits the sender's HL perp clearinghouse in
# under 1 minute.
HL_BRIDGE2_CONTRACT = "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7"

# Native USDC has 6 decimals.
ARB_USDC_DECIMALS = 6

# HL-enforced minimum deposit. Below this, funds are silently lost.
# Source: references/hyperliquid-docs/docs/for-developers/api/bridge2.md.
ARB_MIN_DEPOSIT = Decimal("5")


# ---------------------------------------------------------------------------
# HyperEVM (chainId 999) — HyperCore <-> HyperEVM bridge via system addresses
# ---------------------------------------------------------------------------

HYPEREVM_CHAIN_ID = 999

# Native HYPE return target. System contract with payable receive() emitting
# event Received(address indexed user, uint256 amount). Used by HyperEVM ->
# HyperCore native HYPE transfers.
HYPE_SYSTEM_ADDRESS = "0x2222222222222222222222222222222222222222"


# ---------------------------------------------------------------------------
# Native-gas thresholds (per locked decisions 5 + 14)
# ---------------------------------------------------------------------------

# Outbound (soft warning): destination doesn't need gas to RECEIVE bridged
# tokens, but will need gas to USE them. Warn if balance is below this.
ARB_GAS_WARN_THRESHOLD = Decimal("0.0001")     # ETH on Arbitrum
HYPEREVM_GAS_WARN_THRESHOLD = Decimal("0.01")  # HYPE on HyperEVM

# Inbound (hard block): sender must sign an EVM transaction at the source.
# No native gas means the tx can't be broadcast. Block if balance is below
# this. Same numeric value as the warn threshold today; kept as separate
# named constants so we can tune independently later.
ARB_GAS_HARD_THRESHOLD = ARB_GAS_WARN_THRESHOLD
HYPEREVM_GAS_HARD_THRESHOLD = HYPEREVM_GAS_WARN_THRESHOLD


# ---------------------------------------------------------------------------
# HYPE bridge gas-limit override (locked decision 15)
# ---------------------------------------------------------------------------

# transfer_native's default gas_limit is 21_000 (EOA-to-EOA). The HYPE system
# address is a contract whose payable receive() emits a LOG3 op (~65k gas
# total per HL docs). 100k matches transfer_erc20's default and gives ~50%
# headroom over the docs' estimate.
HYPE_BRIDGE_GAS_LIMIT = 100_000
