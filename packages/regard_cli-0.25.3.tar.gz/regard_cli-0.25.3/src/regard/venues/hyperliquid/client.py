"""SDK client factory — creates Info and Exchange instances."""

import os
from pathlib import Path

import eth_account
from hyperliquid.exchange import Exchange
from hyperliquid.info import Info
from hyperliquid.utils.constants import MAINNET_API_URL
from pydantic import ValidationError

from regard.core.output import die
from regard.core.project_dir import find_project_dir
from regard.core.project_state import load_project_env
from regard.venues.hyperliquid.models import (
    ActiveAssetData,
    FrontendOrder,
    PerpDexInfo,
    PerpMetaEntry,
    Position,
    SpotBalance,
    UserState,
)


def _validate(model_cls, data, label: str = ""):
    """Validate data against a Pydantic model. Silently passes on failure.

    Uses extra="ignore" (the model default) so unknown fields pass through.
    If the API response has wrong types or missing required fields, this is
    a no-op — the golden fixture tests (extra="forbid") catch drift in CI.
    Runtime validation guards against genuinely wrong types only.
    """
    try:
        model_cls.model_validate(data)
    except ValidationError:
        pass  # Schema drift is caught by golden fixture tests, not at runtime

TESTNET_API_URL = "https://api.hyperliquid-testnet.xyz"


def _base_url(testnet: bool) -> str:
    return TESTNET_API_URL if testnet else MAINNET_API_URL


def _get_key():
    key = os.environ.get("HYPERLIQUID_PRIVATE_KEY")
    if not key:
        key = load_project_env().get("HYPERLIQUID_PRIVATE_KEY")
    if not key:
        if find_project_dir() is None:
            die(
                "auth_error", "NO_PROJECT",
                f"No regard project found. Looked for .regard/ in {Path.cwd()} and above.",
                hint="cd to your project directory, or run `regard wallet <key>` here to set one up",
                exit_code=3,
            )
        die(
            "auth_error", "NO_KEY",
            "No wallet set for this project",
            hint="Run `regard wallet <key>` (or `regard wallet --prompt`) from this project dir in a separate terminal",
            exit_code=3,
        )
    return key


def get_address(explicit: str | None = None, testnet: bool = False) -> str:
    """Get account address for queries.

    Priority: explicit arg > derived from HYPERLIQUID_PRIVATE_KEY.
    `testnet` retained for signature compatibility with callers that pass it.
    """
    del testnet  # unused — address derives from key, not endpoint
    if explicit:
        return explicit
    key = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or load_project_env().get("HYPERLIQUID_PRIVATE_KEY")
    if key:
        return eth_account.Account.from_key(key).address
    if find_project_dir() is None:
        die(
            "auth_error", "NO_PROJECT",
            f"No regard project found. Looked for .regard/ in {Path.cwd()} and above.",
            hint="cd to your project directory, or use --address for read-only",
            exit_code=3,
        )
    die(
        "auth_error", "NO_ADDRESS",
        "No address available for this project",
        hint="Run `regard wallet <key>` from this project dir, or use --address for read-only",
        exit_code=3,
    )


def get_info(testnet: bool = False) -> Info:
    """Create Info client (default perps only, dexes loaded lazily by resolver)."""
    return Info(_base_url(testnet), skip_ws=True)


def get_exchange(testnet: bool = False) -> Exchange:
    """Create Exchange client signed by the master private key."""
    key = _get_key()
    wallet = eth_account.Account.from_key(key)
    account_address = get_address()
    return Exchange(wallet, _base_url(testnet), account_address=account_address)


def get_all_mids(info: Info) -> dict:
    """Get all mid prices including HIP-3 deployer assets."""
    mids = info.all_mids()
    try:
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            dex_mids = info.post("/info", {"type": "allMids", "dex": dex_info["name"]})
            mids.update(dex_mids)
    except Exception:
        pass
    return mids


def get_account_mode(info: Info, address: str) -> str:
    """Get account abstraction mode: standard, unifiedAccount, portfolioMargin."""
    try:
        return info.query_user_abstraction_state(address) or "standard"
    except Exception:
        return "standard"


def get_spot_balances(info: Info, address: str) -> list:
    """Get spot token balances with human-readable amounts.

    Handles three shapes:
    - Unified spot — `total` as human-readable float string, `token` as int index
    - Legacy spot — `holds`/`withdrawn` in wei, `token` as int index
    - HIP-4 outcome — `coin` is `+<encoding>`, `token` may be missing or null
      (outcome tokens have no tokenId per brief §8); discriminator is the
      `coin` string prefix `+`. Returned with `kind: "outcome"` plus parsed
      `outcome` integer and `side` index so downstream commands can compose
      with resolver state for mark-to-market.

    Returns [] for accounts with no spot holdings or on error.
    """
    try:
        spot_state = info.spot_user_state(address)
        raw_balances = spot_state.get("balances", [])
        if not raw_balances:
            return []

        for bal in raw_balances:
            _validate(SpotBalance, bal, "spot_balance")

        # Build token index lookup (spot side; outcomes don't appear here)
        meta = info.spot_meta()
        tokens_by_index = {t["index"]: t for t in meta["tokens"]}

        # Lazy import to avoid circular: outcomes.py imports nothing back.
        from regard.venues.hyperliquid.outcomes import decode_balance_coin

        result = []
        for bal in raw_balances:
            coin_name = bal.get("coin", "") or ""

            # HIP-4 outcome path — discriminate by `+<encoding>` prefix.
            # Only commit to the outcome path if the body is a well-formed
            # encoding integer; if `decode_balance_coin` returns None, fall
            # through to the standard spot path so a future spot token whose
            # name happens to start with `+<non-digit>` still surfaces. The
            # current HL API has no such tokens, but this guards a latent
            # silent-drop hazard against future protocol additions.
            if coin_name.startswith("+"):
                decoded = decode_balance_coin(coin_name)
                if decoded is not None:
                    outcome_id, side_idx = decoded
                    # Unified-account "total" is the canonical balance for
                    # outcomes; if absent, the entry isn't surface-worthy.
                    total = bal.get("total")
                    if total is None:
                        continue
                    try:
                        if float(total) <= 0:
                            continue
                    except (TypeError, ValueError):
                        continue
                    result.append({
                        "token": coin_name,                # "+59150" — preserves Article-I string-typed identifier
                        "balance": str(total),             # already a string from API; str() to be explicit
                        "token_index": bal.get("token"),   # may be None for outcomes
                        "kind": "outcome",
                        "outcome": outcome_id,
                        "side": side_idx,
                        "side_name": "yes" if side_idx == 0 else "no",
                    })
                    continue
                # Decode failure → not a real outcome encoding; fall through

            # Standard spot path — same shape as before.
            token_idx = bal.get("token")
            if token_idx is None:
                continue
            token_info = tokens_by_index.get(token_idx)
            if not token_info:
                continue

            # Unified accounts use "total" as human-readable float string
            if "total" in bal:
                net = float(bal["total"])
            else:
                # Legacy: holds/withdrawn in wei
                holds = int(bal.get("holds", "0"))
                withdrawn = int(bal.get("withdrawn", "0"))
                net_wei = holds - withdrawn
                wei_decimals = token_info.get("weiDecimals", 18)
                net = net_wei / (10 ** wei_decimals)

            if net <= 0:
                continue

            sz_decimals = token_info.get("szDecimals", 2)
            result.append({
                "token": token_info["name"],
                "balance": f"{net:.{sz_decimals}f}",
                "token_index": token_idx,
                "kind": "spot",
            })

        return result
    except Exception:
        return []


def get_all_perp_metas(info: Info) -> list:
    """All perp dex metas in one call (replaces perpDexs for dex discovery).

    Returns raw list from allPerpMetas API. Index 0 is the default dex,
    the rest are HIP-3 deployers. Each item has: universe, marginTables,
    collateralToken. Dex name is extracted from universe asset names
    (e.g. "xyz:TSLA" → "xyz", "BTC" → "").
    """
    try:
        data = info.post("/info", {"type": "allPerpMetas"})
        for m in data:
            _validate(PerpMetaEntry, m, "perp_meta")
        return data
    except Exception:
        return []


def get_perp_annotations(info: Info) -> dict:
    """Asset categories from perpConciseAnnotations API.

    Returns {asset_name: category} where category is "crypto", "stocks",
    "commodities", "indices", etc. Only HIP-3 assets appear; default perps
    are all crypto by definition.
    """
    try:
        data = info.post("/info", {"type": "perpConciseAnnotations"})
        return {item[0]: item[1].get("category", "") for item in data}
    except Exception:
        return {}


def get_collateral_map(info: Info) -> dict:
    """Build {dex_name: (token_name, token_index)} from allPerpMetas + spot meta.

    Resolves collateral token index to human-readable name via spot tokens list.
    Default dex key is "".
    """
    try:
        all_metas = info.post("/info", {"type": "allPerpMetas"})
        for m in all_metas:
            _validate(PerpMetaEntry, m, "perp_meta")
        dex_list = info.post("/info", {"type": "perpDexs"})
        for d in dex_list:
            if d is not None:
                _validate(PerpDexInfo, d, "perp_dex")
        spot_meta = info.spot_meta()
        tokens = spot_meta["tokens"]

        tokens_by_index = {t["index"]: t for t in tokens}
        result = {"": ("USDC", 0)}  # default dex always USDC
        for dex_info, meta in zip(dex_list, all_metas):
            # perpDexs[0] is None for the default dex on mainnet
            name = dex_info.get("name", "") if dex_info else ""
            idx = meta.get("collateralToken", 0)
            token_name = tokens_by_index[idx]["name"] if idx in tokens_by_index else "USDC"
            result[name] = (token_name, idx)
        return result
    except Exception:
        return {"": ("USDC", 0)}


def dex_name_from_universe(universe: list) -> str:
    """Extract dex name from allPerpMetas universe asset names.

    "xyz:TSLA" → "xyz", "BTC" → "" (default dex).
    """
    if not universe:
        return ""
    name = universe[0].get("name", "")
    return name.split(":")[0] if ":" in name else ""


def get_dex_for_coin(coin: str) -> str:
    """Extract dex name from coin. 'xyz:CL' → 'xyz', 'BTC' → '' (default)."""
    return coin.split(":")[0] if ":" in coin else ""


def get_asset_margin_info(info: Info, coin: str) -> dict:
    """Look up an asset's margin configuration from the HL universe.

    Returns `{margin_mode, only_isolated, max_leverage}` for the given coin.
    `margin_mode` is one of `"strictIsolated"`, `"noCross"`, `"normal"`, or
    None (unset → cross-capable by default). `only_isolated` is the deprecated
    fallback flag — True means strictIsolated or noCross.

    Routes to the correct dex's meta for HIP-3 coins (`xyz:CL` → xyz dex).
    Returns `{}` if the asset isn't found; caller decides how to handle.
    """
    dex = get_dex_for_coin(coin)
    try:
        if dex:
            meta = info.post("/info", {"type": "meta", "dex": dex})
        else:
            meta = info.meta()
        for asset in meta.get("universe", []) or []:
            if asset.get("name") == coin:
                return {
                    "margin_mode": asset.get("marginMode"),
                    "only_isolated": asset.get("onlyIsolated"),
                    "max_leverage": asset.get("maxLeverage"),
                }
    except Exception:
        pass
    return {}


def is_isolated_only(margin_info: dict) -> bool:
    """True if the asset requires isolated margin (cross not allowed).

    Reads the new `marginMode` field first (HIP-3 canonical: strictIsolated /
    noCross / normal). When `marginMode` is set, it's authoritative — the
    deprecated `onlyIsolated` flag is ignored. Falls back to `onlyIsolated`
    only when `marginMode` is absent (native perps typically have neither).
    """
    mode = margin_info.get("margin_mode")
    if mode is not None:
        return mode in ("strictIsolated", "noCross")
    return bool(margin_info.get("only_isolated"))


def get_asset_oracle_px(info: Info, coin: str) -> float | None:
    """Read oracle price for an asset from metaAndAssetCtxs.

    Returns the oracle price as a float, or None if not found/unavailable.
    Used by order/stop preflight to detect prices that would fail HL's
    per-asset oracle-bound validation (tight on HIP-3 commodities
    especially during underlying-market off-hours).
    """
    dex = get_dex_for_coin(coin)
    try:
        if dex:
            ctxs = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex})
        else:
            ctxs = info.meta_and_asset_ctxs()
        universe = ctxs[0].get("universe", [])
        asset_ctxs = ctxs[1]
        for a_info, a_ctx in zip(universe, asset_ctxs):
            if a_info.get("name") == coin:
                raw = a_ctx.get("oraclePx")
                if raw is None:
                    return None
                return float(raw)
    except Exception:
        pass
    return None


def get_active_asset_data(info: Info, address: str, coin: str) -> dict | None:
    """Preflight check: max trade size, available margin, leverage for a specific asset.

    Returns None on error. Fields: coin, leverage, max_trade_szs, available_to_trade, mark_px.
    """
    try:
        data = info.post("/info", {"type": "activeAssetData", "user": address, "coin": coin})
        if isinstance(data, dict):
            _validate(ActiveAssetData, data, "active_asset_data")
        return data
    except Exception:
        return None


def get_all_orders(info: Info, address: str) -> list:
    """Get open orders across all perp dexes (default + HIP-3), including trigger orders.

    Uses frontendOpenOrders which returns full trigger metadata (triggerPx, isTrigger, etc.).
    """
    orders = []
    try:
        # Default perps
        for o in info.frontend_open_orders(address):
            _validate(FrontendOrder, o, "order")
            orders.append(o)

        # HIP-3 dexes
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            name = dex_info["name"]
            try:
                dex_orders = info.post("/info", {"type": "frontendOpenOrders", "user": address, "dex": name})
                for o in dex_orders:
                    _validate(FrontendOrder, o, "dex_order")
                    orders.append(o)
            except Exception:
                continue
    except Exception:
        pass
    return orders


def get_all_positions(info: Info, address: str) -> list:
    """Get positions across all perp dexes (default + HIP-3).

    Returns list of raw position dicts from the API, each with an added
    "dex" field ("" for default, "xyz" etc for HIP-3).
    """
    positions = []
    try:
        # Default perps
        state = info.user_state(address)
        _validate(UserState, state, "user_state")
        for p in state.get("assetPositions", []):
            pos = p["position"]
            _validate(Position, pos, "position")
            if float(pos["szi"]) != 0:
                pos["_dex"] = ""
                positions.append(pos)

        # HIP-3 dexes
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            name = dex_info["name"]
            try:
                dex_state = info.post("/info", {"type": "clearinghouseState", "user": address, "dex": name})
                _validate(UserState, dex_state, "dex_state")
                for p in dex_state.get("assetPositions", []):
                    pos = p["position"]
                    _validate(Position, pos, "position")
                    if float(pos["szi"]) != 0:
                        pos["_dex"] = name
                        positions.append(pos)
            except Exception:
                continue
    except Exception:
        pass
    return positions


def get_dex_balances(info: Info, address: str) -> list:
    """Get account balances across all perp dexes.

    Returns [{dex, account_value, positions}] for dexes with non-zero balance or positions.
    For unified accounts, includes a "spot" entry with the total spot equity.
    """
    result = []
    is_unified = get_account_mode(info, address) == "unifiedAccount"
    try:
        # Default perps
        state = info.user_state(address)
        _validate(UserState, state, "user_state")
        margin = state.get("marginSummary", state.get("crossMarginSummary", {}))
        val = margin.get("accountValue", "0")
        n_pos = len([p for p in state.get("assetPositions", []) if float(p["position"]["szi"]) != 0])
        result.append({"dex": "default", "account_value": val, "positions": n_pos})

        # HIP-3 dexes
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            name = dex_info["name"]
            try:
                dex_state = info.post("/info", {"type": "clearinghouseState", "user": address, "dex": name})
                _validate(UserState, dex_state, "dex_state")
                dex_margin = dex_state.get("marginSummary", dex_state.get("crossMarginSummary", {}))
                dex_val = dex_margin.get("accountValue", "0")
                dex_pos = len([p for p in dex_state.get("assetPositions", []) if float(p["position"]["szi"]) != 0])
                if float(dex_val) > 0 or dex_pos > 0:
                    result.append({"dex": name, "account_value": dex_val, "positions": dex_pos})
            except Exception:
                continue

        # Unified accounts hold equity in spot — include spot balances
        if is_unified:
            spot_bals = get_spot_balances(info, address)
            spot_total = sum(float(s["balance"]) for s in spot_bals)
            if spot_total > 0:
                result.append({"dex": "spot", "account_value": f"{spot_total:.6f}", "positions": 0})
    except Exception:
        pass
    return result
