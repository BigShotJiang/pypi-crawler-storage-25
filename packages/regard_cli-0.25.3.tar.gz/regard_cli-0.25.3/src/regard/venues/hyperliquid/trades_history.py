"""Hyperliquid fills helper for the tilt detector.

Wraps the Hyperliquid SDK's `info.user_fills` / `info.user_fills_by_time` with
graceful degradation: any failure (no wallet, no network, SDK exception)
returns an empty list rather than raising. The tilt detector calls this
optimistically — if the data isn't available, the affected signals just
contribute zero to the score.

Distinct from `commands/review.py:trades()` which is a Typer command for
human inspection; this module is for programmatic consumption with typed
numeric fields suitable for downstream math.
"""

from __future__ import annotations

import contextlib
import io
from datetime import datetime, timezone


def _to_float(value, default: float = 0.0) -> float:
    """Best-effort float coercion. Returns default on None / empty / bad input."""
    if value is None or value == "":
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def fetch_recent_fills(
    *,
    testnet: bool = False,
    limit: int = 200,
    start: datetime | None = None,
    end: datetime | None = None,
) -> list[dict]:
    """Fetch HL fills, normalized and sorted newest-first.

    Each entry: {asset, side, size, price, closed_pnl, fee, time_ms, time_iso}.
    Numeric fields are floats (SDK returns strings); bad/missing values
    coerce to 0.0.

    Returns `[]` on any failure — missing wallet, missing network, SDK
    error. Callers (the tilt detector) should treat the empty case as
    "no signal contribution," not as "no trades exist."

    `start` / `end` accept timezone-aware datetimes and trigger the
    by-time variant of the SDK call. Without them, returns the most
    recent fills (newest-first per the SDK contract).

    `limit` is applied AFTER sort, so the cap always yields the N most
    recent entries.
    """
    # `get_address()` calls `die()` on missing wallet, which writes a
    # structured auth-error envelope to stdout *before* raising SystemExit.
    # The catch below absorbs the SystemExit but doesn't unwrite the
    # bytes — they leak into the next emitter's output and break the
    # single-JSON-per-CLI-invocation contract that callers rely on.
    # Redirect stdout for the wrap so any such envelope is discarded
    # cleanly. SDK setup paths don't print on success, so the redirect
    # has no effect on the happy path.
    try:
        from regard.venues.hyperliquid.client import get_address, get_info
        with contextlib.redirect_stdout(io.StringIO()):
            info = get_info(testnet)
            addr = get_address()
    except (Exception, SystemExit):
        return []

    try:
        if start is not None or end is not None:
            start_ms = int(start.timestamp() * 1000) if start else 0
            end_ms = int(end.timestamp() * 1000) if end else None
            data = info.user_fills_by_time(addr, start_ms, end_ms)
        else:
            data = info.user_fills(addr)
    except (Exception, SystemExit):
        return []

    if not isinstance(data, list):
        return []

    result = []
    for f in data:
        if not isinstance(f, dict):
            continue
        try:
            time_ms = int(f.get("time", 0) or 0)
        except (TypeError, ValueError):
            time_ms = 0
        # `datetime.fromtimestamp` raises OverflowError / OSError on
        # platform-specific extreme values — guard so a single malformed
        # fill doesn't propagate to the tilt detector.
        time_iso = ""
        if time_ms:
            try:
                time_iso = datetime.fromtimestamp(
                    time_ms / 1000, tz=timezone.utc
                ).isoformat()
            except (OverflowError, OSError, ValueError):
                time_iso = ""
        result.append({
            "asset": f.get("coin", ""),
            "side": "buy" if f.get("side") == "B" else "sell",
            "size": _to_float(f.get("sz")),
            "price": _to_float(f.get("px")),
            "closed_pnl": _to_float(f.get("closedPnl")),
            "fee": _to_float(f.get("fee")),
            "time_ms": time_ms,
            "time_iso": time_iso,
        })

    result.sort(key=lambda r: r["time_ms"], reverse=True)
    return result[:limit]


def rolling_baseline(
    fills: list[dict],
    *,
    min_samples: int = 50,
) -> dict | None:
    """Compute size + frequency baselines from a fills window.

    Returns `{avg_size, avg_interval_seconds, sample_count}` if the window
    has at least `min_samples` fills with BOTH valid size AND valid
    timestamp data; else returns `None` to signal "cold-start: caller
    should fall back to session-relative baseline."

    Both filters apply to the SAME subset of fills — so a dataset with
    50 size-valid fills but only 2 timestamp-valid fills correctly
    returns None instead of producing a misleading baseline drawn from
    inconsistent rows.

    Used by the tilt detector to refine size-deviation and frequency-
    acceleration signals — comparing current-session behavior to the
    trader's rolling baseline (default 7 days) is more diagnostic than
    comparing to session-internal averages, especially in early sessions
    where 3 trades isn't a meaningful baseline.
    """
    valid = [
        f for f in fills
        if f.get("size", 0) > 0 and f.get("time_ms", 0) > 0
    ]
    if len(valid) < min_samples:
        return None

    sizes = [f["size"] for f in valid]
    times = sorted(f["time_ms"] for f in valid)
    intervals_sec = [(times[i] - times[i - 1]) / 1000 for i in range(1, len(times))]
    avg_interval = sum(intervals_sec) / len(intervals_sec) if intervals_sec else 0

    return {
        "avg_size": sum(sizes) / len(sizes),
        "avg_interval_seconds": avg_interval,
        "sample_count": len(valid),
    }


def first_red_in_session(fills: list[dict]) -> bool:
    """True iff any fill in the session has a realized loss.

    The "first red of session" signal — once the trader has had any
    converted loss in the current session, the rest of the session runs
    at elevated tilt risk per Coval & Shumway 2005 (16% above-average
    afternoon risk after morning loss) + community lived-experience.
    Order-independent: just checks whether any fill closed negative.
    """
    return any(f.get("closed_pnl", 0) < 0 for f in fills)


def consecutive_losses(fills: list[dict]) -> int:
    """Count consecutive losing trades from the most recent fill backward.

    Walks the newest-first list, counting entries with `closed_pnl < 0`
    until it hits a winning trade or break-even. Trades with
    `closed_pnl == 0` (open positions, fee-only entries) terminate the
    streak — the tilt signal is *converted* losses, not stale data.
    """
    n = 0
    for fill in fills:
        if fill.get("closed_pnl", 0) < 0:
            n += 1
        else:
            break
    return n


def consecutive_wins(fills: list[dict]) -> int:
    """Count consecutive winning trades from the most recent fill backward.

    Mirror of `consecutive_losses` for Tendler's Winner's Tilt detection.
    Walks newest-first, counting `closed_pnl > 0` until non-win.
    """
    n = 0
    for fill in fills:
        if fill.get("closed_pnl", 0) > 0:
            n += 1
        else:
            break
    return n


def win_streak_with_size_escalation(
    fills: list[dict],
    *,
    win_threshold: int = 5,
    size_multiplier: float = 1.3,
) -> bool:
    """Compound signal: N+ consecutive wins AND last size > multiplier × avg.

    Tendler's Winner's Tilt requires two things together. A pure win
    streak isn't tilt — that's just running good. Tilt is when the
    streak makes the trader start upsizing past their normal pattern.
    Single-signal use (just streak, just size-up) misses the compound
    pattern that's the actual harm signature.

    Returns False when there's insufficient data to assess (fewer than
    `win_threshold` total fills, or zero average size).
    """
    if consecutive_wins(fills) < win_threshold:
        return False
    sizes = [f.get("size", 0) for f in fills if f.get("size", 0) > 0]
    if len(sizes) < win_threshold:
        return False
    avg = sum(sizes) / len(sizes)
    if avg <= 0:
        return False
    last_size = sizes[0]  # newest-first
    return last_size > avg * size_multiplier
