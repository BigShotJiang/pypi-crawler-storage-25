"""HIP-4 outcome settlement + near-expiry detection — pure logic.

Detects when held outcome positions transition from "active" to "settled"
across consecutive REST polls. Emits structured events suitable for
JSONL stdout consumption by Claude Code's Monitor tool.

Architecture:
- Pure logic. `SettlementWatcher.poll(meta, balances)` takes the result
  of `resolver.get_outcomes()` + `client.get_spot_balances()` and returns
  the list of events to emit. No network, no I/O — `commands/watch.py`
  drives the I/O loop.
- State carried in memory across polls. Restart loses state — fresh
  watcher rediscovers held positions on first tick (no spurious settled
  events because tracking starts empty).

Detection logic:
- An outcome is "settled" when it was previously tracked as held AND
  it is no longer in outcomeMeta. Validators auto-credit USDH at expiry
  and remove the outcome from the meta — both happen in the same
  settlement window.
- A position that disappears from balance while the outcome stays in
  meta is a sale (Cycle D pattern), NOT a settlement — does not emit.
- Payout amount is computed from the USDH balance delta between the
  poll that observed the position and the poll that observed the
  settlement. Paths where USDH delta is unobservable (first poll, etc.)
  surface as `payout_usdh="unknown"`.

All numeric values in events are JSON strings (Article I).
"""

from decimal import Decimal
from typing import Any


class SettlementWatcher:
    """Tracks held HIP-4 outcomes and detects settlements across polls.

    Usage:
        watcher = SettlementWatcher()
        events = watcher.poll(outcomes_meta=..., spot_balances=...)
        for ev in events: emit(ev)
    """

    def __init__(self):
        # outcome_id → {side, side_name, size (str), name, expiry, target_price}
        self._tracked: dict[int, dict[str, Any]] = {}
        # Previous-poll USDH balance (Decimal). None on first poll.
        self._prev_usdh: Decimal | None = None

    def poll(
        self,
        outcomes_meta: list[dict[str, Any]],
        spot_balances: list[dict[str, Any]],
        now_iso: str,
    ) -> list[dict[str, Any]]:
        """Process one poll cycle. Return any settlement events.

        Args:
            outcomes_meta: result of resolver.get_outcomes() — list of dicts
                with keys outcome (int), name, parsed_description {expiry,
                target_price, ...}, sides.
            spot_balances: result of client.get_spot_balances() — list of
                dicts. Outcome rows have kind="outcome", outcome (int), side
                (int), side_name (str), balance (str). USDH row has
                token="USDH", balance (str).
            now_iso: current UTC time as ISO 8601 string. Caller passes in
                so the function stays pure.
        """
        events: list[dict[str, Any]] = []

        current_outcome_ids = {o["outcome"] for o in outcomes_meta}
        outcomes_by_id = {o["outcome"]: o for o in outcomes_meta}

        held: dict[int, dict[str, Any]] = {}
        usdh_balance: Decimal | None = None
        for b in spot_balances:
            if b.get("kind") == "outcome":
                oid = b.get("outcome")
                if not isinstance(oid, int):
                    continue
                size_str = str(b.get("balance", "0"))
                # Defensive: skip dust rows where balance is 0 or non-positive.
                try:
                    if Decimal(size_str) <= 0:
                        continue
                except Exception:
                    continue
                held[oid] = {
                    "side": b.get("side", 0),
                    "side_name": b.get("side_name", "yes" if b.get("side") == 0 else "no"),
                    "size": size_str,
                }
            elif b.get("token") == "USDH":
                try:
                    usdh_balance = Decimal(str(b.get("balance", "0")))
                except Exception:
                    pass

        # Settlement detection — any tracked outcome no longer in meta is
        # settled (validators remove outcomes after auto-crediting payouts).
        to_settle = [oid for oid in self._tracked if oid not in current_outcome_ids]
        # When >1 outcome settles in the same poll, the wallet-level USDH
        # delta cannot be attributed to individual outcomes (HL doesn't
        # expose per-fill credits). `payout_usdh` is the aggregate delta
        # for the poll (still useful as a sanity bound); `implied_winning_side`
        # is "unknown" to avoid the misclassification where a
        # small loss is mis-tagged "held" because a larger sibling won.
        # Peer-review v0.23.3 ratchet — see TestSimultaneousSettlement.
        multi_settle = len(to_settle) > 1
        for oid in to_settle:
            tracked = self._tracked[oid]
            if multi_settle:
                if self._prev_usdh is not None and usdh_balance is not None:
                    payout = str(usdh_balance - self._prev_usdh)
                else:
                    payout = "unknown"
                implied_winning = "unknown"
            else:
                payout, implied_winning = _classify_settlement(
                    tracked["size"], self._prev_usdh, usdh_balance
                )
            events.append({
                "event": "outcome_settled",
                "watcher": "outcomes",
                "outcome": oid,
                "name": tracked.get("name", ""),
                "side_held": tracked["side_name"],
                "size": tracked["size"],
                "payout_usdh": payout,
                "implied_winning_side": implied_winning,
                "settled_at": now_iso,
                "expiry": tracked.get("expiry", ""),
                "target_price": tracked.get("target_price", ""),
            })
            del self._tracked[oid]

        # Update tracking from current holdings. New positions enter
        # tracking silently (no event); positions cleared while outcome is
        # still active (sale path) leave tracking silently too. We only
        # emit on the settlement transition above.
        for oid, h in held.items():
            outcome_record = outcomes_by_id.get(oid)
            parsed = (outcome_record or {}).get("parsed_description") or {}
            self._tracked[oid] = {
                "side": h["side"],
                "side_name": h["side_name"],
                "size": h["size"],
                "name": (outcome_record or {}).get("name", ""),
                "expiry": parsed.get("expiry") or "",
                "target_price": parsed.get("target_price") or "",
            }

        # Drop tracking for outcomes that are still active in meta but no
        # longer in our balance (sale path).
        for oid in list(self._tracked.keys()):
            if oid not in held and oid in current_outcome_ids:
                del self._tracked[oid]

        if usdh_balance is not None:
            self._prev_usdh = usdh_balance

        return events


def _classify_settlement(
    size_held: str,
    prev_usdh: Decimal | None,
    curr_usdh: Decimal | None,
) -> tuple[str, str]:
    """Infer payout amount + winning side from USDH delta.

    Returns (payout_usdh_str, implied_winning_side).

    HIP-4 binary settlement pays full size in USDH to the winning side
    (1.0 USDH per contract) and 0 to the losing side. So:
      delta ≈ size  →  held side won
      delta ≈ 0     →  held side lost

    On first poll (prev_usdh=None) or missing USDH balance, payout is
    "unknown" — we can't tell from a single observation.
    """
    if prev_usdh is None or curr_usdh is None:
        return ("unknown", "unknown")

    delta = curr_usdh - prev_usdh
    if delta < 0:
        # USDH went down? Strange — possibly an unrelated send happened
        # during the same window. Don't infer winner.
        return (str(delta), "unknown")

    try:
        size = Decimal(size_held)
    except Exception:
        return (str(delta), "unknown")

    if size <= 0:
        return (str(delta), "unknown")

    # Held side won if payout reached >= 50% of full size (covers fee
    # haircuts, partial precision drift, multi-position aggregation).
    if delta >= size * Decimal("0.5"):
        return (str(delta), "held")
    return (str(delta), "opposite")


def count_held_outcomes_near_expiry(
    spot_balances: list[dict[str, Any]],
    outcomes_meta: list[dict[str, Any]],
    threshold_minutes: int,
    now_utc,
) -> int:
    """Count held outcome positions expiring within `threshold_minutes`.

    Used by tilt's `outcome_near_expiry` indicator. Pure function — caller
    fetches state and passes the current UTC datetime.

    A held position counts as "near expiry" when:
      - balance row has `kind:outcome` and `balance > 0`
      - the corresponding outcome record is in outcomes_meta
      - the outcome's parsed expiry is in the future AND <= threshold_minutes
        away from `now_utc`

    Outcomes that have already expired (expiry < now) do NOT count — those
    are pending settlement and the trader can't act on them. Threshold ≤ 0
    returns 0 (no detection window).
    """
    from regard.venues.hyperliquid.outcomes import parse_expiry

    if threshold_minutes <= 0:
        return 0

    outcomes_by_id: dict[int, dict[str, Any]] = {}
    for o in outcomes_meta:
        oid = o.get("outcome")
        if isinstance(oid, int):
            outcomes_by_id[oid] = o

    count = 0
    for b in spot_balances:
        if b.get("kind") != "outcome":
            continue
        try:
            balance = Decimal(str(b.get("balance", "0")))
        except Exception:
            continue
        if balance <= 0:
            continue
        oid = b.get("outcome")
        if not isinstance(oid, int):
            continue
        record = outcomes_by_id.get(oid)
        if record is None:
            continue
        parsed = record.get("parsed_description") or {}
        expiry_dt = parse_expiry(parsed.get("expiry"))
        if expiry_dt is None:
            continue
        if expiry_dt <= now_utc:
            continue
        minutes_left = (expiry_dt - now_utc).total_seconds() / 60.0
        if minutes_left <= threshold_minutes:
            count += 1
    return count
