"""Inbound bridges (EVM-signed) — return paths to Hyperliquid.

Two commands and two top-level env prefixes:
  arbitrum bridge hypercore --to self <amount>      (Arbitrum USDC -> HL perp)
  hyperevm bridge hypercore --to self <amount> --token <tok>   (HyperEVM -> HL spot)

Both use src/regard/core/evm.py's chain-agnostic transfer_erc20 / transfer_native
helpers — same EVM-signing infra that polygon send already exercises against
Polygon. The only chain-specific pieces are the RPC URL, contract addresses,
and (for HYPE) the gas-limit override per locked decision 15.

Per V025-IMPLEMENTATION.md locked decisions 11-20.
"""

import sys
from decimal import Decimal
from typing import Annotated

import typer

from regard.core.output import die, output
from regard.core.proposal import create_proposal, register_executor, register_safety_validator
from regard.venues.hyperliquid.bridge_constants import (
    ARB_GAS_HARD_THRESHOLD,
    ARB_MIN_DEPOSIT,
    ARB_USDC_CONTRACT,
    ARB_USDC_DECIMALS,
    HL_BRIDGE2_CONTRACT,
    HYPE_BRIDGE_GAS_LIMIT,
    HYPE_SYSTEM_ADDRESS,
    HYPEREVM_GAS_HARD_THRESHOLD,
)

# ---------------------------------------------------------------------------
# Web3 client factories
# ---------------------------------------------------------------------------


def _make_retry_session():
    """Build a requests session with retries on 429/5xx."""
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry

    session = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["POST", "GET"],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def _get_arbitrum_web3():
    """Web3 client for Arbitrum One via the shared RPC pool (chainId 42161)."""
    from regard.core.rpc_pool import get_web3
    return get_web3(42161)


def _get_hyperevm_web3():
    """Web3 client for HyperEVM via the shared RPC pool (chainId 999)."""
    from regard.core.rpc_pool import get_web3
    return get_web3(999)


# ---------------------------------------------------------------------------
# Hard-block source-gas check (locked decision 14)
# ---------------------------------------------------------------------------


def _native_balance(w3, address: str) -> Decimal | None:
    """Return native gas balance in tokens (Decimal), or None on RPC error."""
    try:
        from web3 import Web3
        balance_wei = w3.eth.get_balance(Web3.to_checksum_address(address))
        return Decimal(balance_wei) / Decimal(10**18)
    except Exception:
        return None


def require_source_gas(chain: str, w3, address: str) -> None:
    """Hard-block if source-chain native gas is insufficient to sign a tx.

    Inbound bridges sign EVM transactions on the source chain; with no gas
    the tx cannot be broadcast at all. Per locked decision 14 this is a
    hard block, not a warning.

    RPC failure dies with RPC_UNREACHABLE rather than silently passing —
    we cannot proceed without confirming gas.
    """
    threshold = {
        "arbitrum": ARB_GAS_HARD_THRESHOLD,
        "hyperevm": HYPEREVM_GAS_HARD_THRESHOLD,
    }[chain]
    native = "ETH" if chain == "arbitrum" else "HYPE"

    balance = _native_balance(w3, address)
    if balance is None:
        die("validation_error", "RPC_UNREACHABLE",
            f"Cannot verify {chain} gas balance for {address}. RPC is unreachable.",
            hint=f"Retry, or set {chain.upper()}_RPC in config to a working endpoint.")
    if balance < threshold:
        die("validation_error", "BRIDGE_SOURCE_NO_GAS",
            f"Sender {address} has {balance} {native} on {chain}; need at least {threshold} to sign the bridge tx.",
            hint=f"Fund the sender with {native} on {chain} before retrying.")


# ---------------------------------------------------------------------------
# HyperEVM linked-ERC-20 lookup (used by hyperevm bridge hypercore)
# ---------------------------------------------------------------------------


def _hyperevm_linked_erc20(token_name: str, info) -> str | None:
    """Resolve a Core spot token to its linked HyperEVM ERC-20 contract address.

    The HL spot_meta `evmContract` field is a dict:
        {"address": "0x...", "evm_extra_wei_decimals": <int>}
    Returns the contract `address` string, or None if unlinked / unknown.
    HYPE has no evmContract — callers must short-circuit on token == "HYPE".
    """
    try:
        spot_meta = info.spot_meta()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SPOT_META_UNAVAILABLE",
            f"Could not fetch spot_meta for token link check: {e}",
            exit_code=4)

    for t in spot_meta.get("tokens", []):
        if t.get("name", "").upper() == token_name.upper():
            evm_contract = t.get("evmContract")
            if evm_contract is None:
                return None
            # Real API: dict with `address` field. Defensive: accept a plain
            # string too (older fixtures, alternate API versions).
            if isinstance(evm_contract, dict):
                return evm_contract.get("address")
            if isinstance(evm_contract, str):
                return evm_contract
            return None
    return None


def _system_address_for_token(token_name: str, info) -> str:
    """Compute the HyperCore system address for a token (used as the EVM dest)."""
    if token_name.upper() == "HYPE":
        return HYPE_SYSTEM_ADDRESS

    try:
        spot_meta = info.spot_meta()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SPOT_META_UNAVAILABLE",
            f"Could not fetch spot_meta: {e}", exit_code=4)

    for t in spot_meta.get("tokens", []):
        if t.get("name", "").upper() == token_name.upper():
            idx = t.get("index")
            if idx is None:
                die("venue_error", "SPOT_META_UNAVAILABLE",
                    f"spot_meta entry for {token_name} has no index field", exit_code=4)
            return "0x20" + idx.to_bytes(19, "big").hex()

    die("validation_error", "UNKNOWN_TOKEN",
        f"Token '{token_name}' not found in Hyperliquid spot_meta",
        hint="Check available tokens with: regard hypercore spot-balances")
    return ""  # unreachable


# ---------------------------------------------------------------------------
# Click subapps
# ---------------------------------------------------------------------------


arbitrum_app = typer.Typer(
    name="arbitrum",
    no_args_is_help=True,
    help="Arbitrum One. EVM-signed transactions on chainId 42161.",
    pretty_exceptions_enable=False,
)
arbitrum_bridge_app = typer.Typer(
    name="bridge",
    no_args_is_help=True,
    help="Move tokens from Arbitrum to a different chain.",
    pretty_exceptions_enable=False,
)


@arbitrum_app.callback()
def arbitrum_main(ctx: typer.Context):
    """Arbitrum One CLI."""
    ctx.ensure_object(dict)
    # Match polygon's pattern: testnet flag is not relevant here (Arbitrum
    # mainnet only for v0.25.0).
    ctx.obj.setdefault("testnet", False)


hyperevm_app = typer.Typer(
    name="hyperevm",
    no_args_is_help=True,
    help="HyperEVM execution layer. EVM-signed transactions on chainId 999.",
    pretty_exceptions_enable=False,
)
hyperevm_bridge_app = typer.Typer(
    name="bridge",
    no_args_is_help=True,
    help="Move tokens from HyperEVM to a different chain.",
    pretty_exceptions_enable=False,
)


@hyperevm_app.callback()
def hyperevm_main(ctx: typer.Context):
    """HyperEVM execution layer CLI."""
    ctx.ensure_object(dict)
    ctx.obj.setdefault("testnet", False)


# ---------------------------------------------------------------------------
# arbitrum bridge hypercore
# ---------------------------------------------------------------------------


@arbitrum_bridge_app.command("hypercore")
def arbitrum_bridge_hypercore(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="USDC amount (>=5 USDC; below this funds are LOST)")],
    to: Annotated[str, typer.Option("--to", help="Must be 'self' (Bridge2 credits sender's HL perp)")] = "",
):
    """Bridge native USDC from Arbitrum to HL perp clearinghouse.

    Sends an ERC-20 transfer of native USDC to Hyperliquid's Bridge2 contract
    (0x2df1c5...). Validators auto-credit the sender's HL perp account in
    under 1 minute. USDC is implicit; min 5 USDC (HL-enforced; below this
    funds are silently LOST).
    """
    opts = ctx.obj
    import eth_account

    from regard.core.audit import log_event
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()

    if not to:
        die("validation_error", "MISSING_DESTINATION",
            "Bridge commands require --to with no implicit default",
            hint="Bridge2 credits the sender's address — use --to self.")

    if to != "self":
        die("validation_error", "BRIDGE_RECIPIENT_NOT_SELF",
            f"arbitrum bridge hypercore credits the sender's HL perp; got --to '{to}'",
            hint="Use --to self. Bridge2 protocol credits sender — no third-party recipient.")

    amt = Decimal(amount)
    if amt < ARB_MIN_DEPOSIT:
        die("validation_error", "MIN_DEPOSIT_NOT_MET",
            f"Arbitrum -> HL deposit is {amt} USDC; minimum is {ARB_MIN_DEPOSIT} USDC. "
            f"Below this minimum, Hyperliquid silently loses the deposit.",
            hint=f"Increase amount to at least {ARB_MIN_DEPOSIT}, or use a different path.")

    # Resolve sender address from EVM key.
    key = _get_key()
    sender = eth_account.Account.from_key(key).address

    # Source-gas hard block — must verify before proposing (can't sign without gas).
    w3 = _get_arbitrum_web3()
    require_source_gas("arbitrum", w3, sender)

    # USDC ERC-20 source-balance check.
    from regard.core.evm import get_erc20_balance
    try:
        balance_raw = get_erc20_balance(w3, sender, ARB_USDC_CONTRACT)
        balance = Decimal(balance_raw) / Decimal(10**ARB_USDC_DECIMALS)
    except Exception as e:
        die("venue_error", "BALANCE_CHECK_FAILED",
            f"Could not read Arbitrum USDC balance for {sender}: {e}",
            exit_code=4)

    if balance < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"Arbitrum USDC balance is {balance}, cannot bridge {amt}",
            hint="Fund the sender's Arbitrum address with USDC.",
            exit_code=4)

    # Safety gates (per-venue daily cap + cooldown + amount cap).
    check_amount_cap(amt, "USDC", settings_env)
    check_daily_cap(amt, "USDC", "arbitrum", settings_env)
    check_cooldown(HL_BRIDGE2_CONTRACT, settings_env)

    risk = classify_risk(amt, balance)

    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Bridging {amt/balance*100:.0f}% of Arbitrum USDC balance"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Bridging {amt/balance*100:.0f}% of Arbitrum USDC balance. Approve will require --confirm-addr"})

    amount_raw = int(amt * Decimal(10**ARB_USDC_DECIMALS))

    params = {
        "sender": sender,
        "dest_address": HL_BRIDGE2_CONTRACT,  # the EVM tx target (Bridge2 contract)
        "dest_label": "HL_BRIDGE2",
        "recipient_on_hl": sender,  # user's own HL EOA, used by CRITICAL gate (locked decision 18)
        "token_address": ARB_USDC_CONTRACT,
        "token": "USDC",
        "amount": str(amt),
        "amount_raw": str(amount_raw),
        "chain": "arbitrum",
    }
    checks = {
        "sender": sender,
        "arbitrum_usdc_balance": str(balance),
        "projected_arbitrum_usdc": str(balance - amt),
        "credited_on_hl_perp": str(amt),  # full amount credits — no fee on the deposit side
        "estimated_credit_minutes": "<1",
        "risk": risk,
    }

    log_event("proposed", command="bridge.hypercore", venue="arbitrum",
              to=HL_BRIDGE2_CONTRACT, to_label="HL_BRIDGE2", token="USDC", amount=str(amt), risk=risk)
    proposal = create_proposal("arbitrum", "bridge.hypercore", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_arbitrum_bridge_hypercore_safety(params: dict) -> None:
    """Re-check safety at approve time (defense-in-depth + source-gas re-check)."""
    import eth_account

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), "USDC", "arbitrum", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    key = _get_key()
    current_addr = eth_account.Account.from_key(key).address
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")

    # Re-check source gas — could have been spent between propose and approve.
    w3 = _get_arbitrum_web3()
    require_source_gas("arbitrum", w3, current_addr)


def execute_arbitrum_bridge_hypercore(params: dict) -> dict:
    """Sign + broadcast the Arbitrum ERC-20 transfer to the Bridge2 contract."""
    import eth_account

    from regard.core.audit import log_event
    from regard.core.evm import transfer_erc20
    from regard.venues.polymarket.client import _get_key

    validate_arbitrum_bridge_hypercore_safety(params)

    key = _get_key()
    account = eth_account.Account.from_key(key)
    w3 = _get_arbitrum_web3()

    dest = params["dest_address"]
    token_address = params["token_address"]
    amount_raw = int(params["amount_raw"])

    try:
        tx_hash = transfer_erc20(w3, account, dest, token_address, amount_raw)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "BRIDGE_FAILED", str(e), exit_code=4)

    tx_hex = f"0x{tx_hash.hex()}"

    try:
        log_event("executed", command="bridge.hypercore", venue="arbitrum",
                  to=dest, to_label=params["dest_label"], token="USDC",
                  amount=params["amount"], tx_hash=tx_hex)
    except Exception as e:
        print(f"WARNING: audit log write failed ({e}) — bridge tx broadcast: {tx_hex}", file=sys.stderr)

    return {
        "status": "bridged",
        "destination": dest,
        "destination_label": params["dest_label"],
        "recipient_on_hl": params["recipient_on_hl"],
        "chain": "arbitrum",
        "token": "USDC",
        "amount": params["amount"],
        "tx_hash": tx_hex,
        "estimated_credit_minutes": "<1",
    }


register_executor("arbitrum", "bridge.hypercore", execute_arbitrum_bridge_hypercore)
register_safety_validator("arbitrum", "bridge.hypercore", validate_arbitrum_bridge_hypercore_safety)


# ---------------------------------------------------------------------------
# hyperevm bridge hypercore
# ---------------------------------------------------------------------------


@hyperevm_bridge_app.command("hypercore")
def hyperevm_bridge_hypercore(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Token amount")],
    to: Annotated[str, typer.Option("--to", help="Must be 'self' (system tx credits msg.sender)")] = "",
    token: Annotated[str, typer.Option("--token", help="Token name (HYPE, USDC, USDH, ...) — required")] = "",
):
    """Bridge a HyperEVM token back to HL spot.

    For HYPE: native value-send to system address 0x2222...2222 (the system
    contract emits Received event). For ERC-20 tokens: transfer to the token's
    system address; HL credits sender's spot account next-block.
    """
    opts = ctx.obj
    import eth_account

    from regard.core.audit import log_event
    from regard.core.evm import get_erc20_balance
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk
    from regard.venues.hyperliquid.client import get_info
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()

    if not to:
        die("validation_error", "MISSING_DESTINATION",
            "Bridge commands require --to with no implicit default",
            hint="HyperEVM->HyperCore credits msg.sender — use --to self.")

    if to != "self":
        die("validation_error", "BRIDGE_RECIPIENT_NOT_SELF",
            f"hyperevm bridge hypercore credits the sender's HL spot; got --to '{to}'",
            hint="Use --to self. The system tx credits msg.sender — no third-party recipient.")

    if not token:
        die("validation_error", "MISSING_TOKEN",
            "Must specify --token (e.g. HYPE, USDC, USDH)",
            hint="regard hyperevm bridge hypercore --to self <amount> --token HYPE")

    # Locked decision 15: normalize token name BEFORE branching.
    token = token.upper()

    key = _get_key()
    sender = eth_account.Account.from_key(key).address

    # Source-gas hard block.
    w3 = _get_hyperevm_web3()
    require_source_gas("hyperevm", w3, sender)

    info = get_info(opts["testnet"])
    system_addr = _system_address_for_token(token, info)

    is_native = (token == "HYPE")
    if is_native:
        # HYPE balance is the native gas token balance — read via eth_getBalance.
        # Note: the same balance was just checked by require_source_gas, so we read
        # it again here only to validate amount fits (gas threshold is independent).
        balance_native = _native_balance(w3, sender)
        if balance_native is None:
            die("venue_error", "BALANCE_CHECK_FAILED",
                f"Could not read HyperEVM HYPE balance for {sender}",
                exit_code=4)
        balance = balance_native
        token_address = None
        amount_raw = int(Decimal(amount) * Decimal(10**18))
    else:
        # Linked ERC-20 lookup.
        token_address = _hyperevm_linked_erc20(token, info)
        if token_address is None:
            die("validation_error", "BRIDGE_TOKEN_NOT_LINKED",
                f"Token {token} has no linked HyperEVM ERC-20 contract.",
                hint=f"Pick a linked token (USDC, HYPE, USDH, USDE, USDT0, PURR), or wait for {token} to be linked.")

        # Resolve the token's wei decimals from spot_meta to compute amount_raw.
        try:
            spot_meta = info.spot_meta()
        except SystemExit:
            raise
        except Exception as e:
            die("venue_error", "SPOT_META_UNAVAILABLE",
                f"Could not fetch spot_meta: {e}", exit_code=4)

        wei_decimals = 18  # default if not specified
        for t in spot_meta.get("tokens", []):
            if t.get("name", "").upper() == token:
                # The ERC-20 contract's decimals = Core weiDecimals + evm_extra_wei_decimals.
                # Core fields are camelCase at the token level; the offset is snake_case
                # nested inside the `evmContract` dict. For canonical tokens like USDC:
                # weiDecimals=8, evmContract.evm_extra_wei_decimals=-2 → ERC-20 decimals=6.
                core_wd = t.get("weiDecimals", 0)
                evm_contract = t.get("evmContract") or {}
                extra = evm_contract.get("evm_extra_wei_decimals", 0) if isinstance(evm_contract, dict) else 0
                wei_decimals = core_wd + extra
                break

        try:
            balance_raw = get_erc20_balance(w3, sender, token_address)
            balance = Decimal(balance_raw) / Decimal(10**wei_decimals)
        except Exception as e:
            die("venue_error", "BALANCE_CHECK_FAILED",
                f"Could not read {token} ERC-20 balance for {sender}: {e}",
                exit_code=4)
        amount_raw = int(Decimal(amount) * Decimal(10**wei_decimals))

    amt = Decimal(amount)
    if balance < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"HyperEVM {token} balance is {balance}, cannot bridge {amt}",
            hint=f"Fund the sender with {token} on HyperEVM.",
            exit_code=4)

    # Safety gates.
    check_amount_cap(amt, token, settings_env)
    check_daily_cap(amt, token, "hyperevm", settings_env)
    check_cooldown(system_addr, settings_env)

    risk = classify_risk(amt, balance)

    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Bridging {amt/balance*100:.0f}% of HyperEVM {token} balance"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Bridging {amt/balance*100:.0f}% of HyperEVM {token} balance. Approve will require --confirm-addr"})

    params = {
        "sender": sender,
        "dest_address": system_addr,  # EVM tx target (system address for the token)
        "dest_label": f"HYPERCORE_SYSTEM_{token}",
        "recipient_on_hl": sender,  # user's HL EOA, used by CRITICAL gate (locked decision 18)
        "token": token,
        "token_address": token_address,  # None for HYPE, contract addr otherwise
        "is_native": is_native,
        "amount": str(amt),
        "amount_raw": str(amount_raw),
        "chain": "hyperevm",
    }
    checks = {
        "sender": sender,
        "system_address": system_addr,
        "hyperevm_balance": str(balance),
        "projected_hyperevm": str(balance - amt),
        "credited_on_hl_spot": str(amt),
        "estimated_credit_block": "next",
        "risk": risk,
    }

    log_event("proposed", command="bridge.hypercore", venue="hyperevm",
              to=system_addr, to_label=f"HYPERCORE_SYSTEM_{token}", token=token, amount=str(amt), risk=risk)
    proposal = create_proposal("hyperevm", "bridge.hypercore", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_hyperevm_bridge_hypercore_safety(params: dict) -> None:
    """Re-check safety at approve time (defense-in-depth + source-gas re-check)."""
    import eth_account

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), params["token"], "hyperevm", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    key = _get_key()
    current_addr = eth_account.Account.from_key(key).address
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")

    w3 = _get_hyperevm_web3()
    require_source_gas("hyperevm", w3, current_addr)


def execute_hyperevm_bridge_hypercore(params: dict) -> dict:
    """Sign + broadcast the HyperEVM tx (native value-send for HYPE, ERC-20 transfer otherwise).

    Per locked decision 15: HYPE path passes gas_limit=100_000 explicitly to
    transfer_native (the default 21k is insufficient because the system
    contract emits a LOG3).
    """
    import eth_account

    from regard.core.audit import log_event
    from regard.core.evm import transfer_erc20, transfer_native
    from regard.venues.polymarket.client import _get_key

    validate_hyperevm_bridge_hypercore_safety(params)

    key = _get_key()
    account = eth_account.Account.from_key(key)
    w3 = _get_hyperevm_web3()

    dest = params["dest_address"]
    amount_raw = int(params["amount_raw"])

    try:
        if params.get("is_native"):
            # HYPE: native value-send with explicit gas_limit override.
            tx_hash = transfer_native(w3, account, dest, amount_raw, gas_limit=HYPE_BRIDGE_GAS_LIMIT)
        else:
            # ERC-20: transfer to the token's system address.
            token_address = params["token_address"]
            tx_hash = transfer_erc20(w3, account, dest, token_address, amount_raw)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "BRIDGE_FAILED", str(e), exit_code=4)

    tx_hex = f"0x{tx_hash.hex()}"

    try:
        log_event("executed", command="bridge.hypercore", venue="hyperevm",
                  to=dest, to_label=params["dest_label"], token=params["token"],
                  amount=params["amount"], tx_hash=tx_hex)
    except Exception as e:
        print(f"WARNING: audit log write failed ({e}) — bridge tx broadcast: {tx_hex}", file=sys.stderr)

    return {
        "status": "bridged",
        "destination": dest,
        "destination_label": params["dest_label"],
        "recipient_on_hl": params["recipient_on_hl"],
        "chain": "hyperevm",
        "token": params["token"],
        "amount": params["amount"],
        "tx_hash": tx_hex,
        "is_native": params.get("is_native", False),
    }


register_executor("hyperevm", "bridge.hypercore", execute_hyperevm_bridge_hypercore)
register_safety_validator("hyperevm", "bridge.hypercore", validate_hyperevm_bridge_hypercore_safety)


# Wire bridge subapps onto their env apps.
arbitrum_app.add_typer(arbitrum_bridge_app, name="bridge")
hyperevm_app.add_typer(hyperevm_bridge_app, name="bridge")
