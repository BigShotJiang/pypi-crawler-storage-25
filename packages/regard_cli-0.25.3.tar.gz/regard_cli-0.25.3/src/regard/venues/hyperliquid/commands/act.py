"""Act commands — order, cancel, cancel-all, leverage, stop, transfer, send, preflight.

Fund-movement command vocabulary (CLI Constitution Article VI, v0.24.0+):
  hypercore perp transfer spot <amount> --token <tok>
  hypercore perp transfer dex <name> <amount> [--token <tok>]
  hypercore spot transfer perp <amount> --token <tok>
  hypercore spot transfer dex <name> <amount> --token <tok>
  hypercore dex <name> transfer spot <amount> --token <tok>
  hypercore dex <name> transfer perp <amount>
  hypercore dex <name> transfer dex <other> <amount> --token <tok>
  hypercore spot send <addr> <amount> --token <tok>
"""

import sys
from typing import Annotated

import typer

from regard.core.output import die, output
from regard.core.proposal import create_proposal, register_executor, register_safety_validator
from regard.main import hypercore_app
from regard.venues.hyperliquid.client import (
    get_account_mode,
    get_active_asset_data,
    get_address,
    get_all_mids,
    get_all_orders,
    get_all_positions,
    get_asset_margin_info,
    get_asset_oracle_px,
    get_collateral_map,
    get_dex_for_coin,
    get_exchange,
    get_info,
    is_isolated_only,
)
from regard.venues.hyperliquid.outcomes import (
    OutcomeValidationError,
    decode_coin,
    validate_outcome_order,
)
from regard.venues.hyperliquid.resolver import get_resolver

SIDE_MAP = {"buy": True, "long": True, "sell": False, "short": False}


def _validate_trigger_direction(trigger_px: float, mid: float, is_long: bool, is_tp: bool):
    """Validate that a stop/TP trigger price is on the correct side of market.

    Dies with BAD_STOP or BAD_TP if the trigger would fire immediately.
    No-op if mid price is unavailable (mid <= 0).
    """
    if mid <= 0:
        return
    if not is_tp:
        if is_long and trigger_px >= mid:
            die("validation_error", "BAD_STOP",
                f"Stop loss {trigger_px:.6g} is above market ({mid:.6g}) for a long — would trigger immediately",
                hint="Stop loss for longs must be below current price")
        if not is_long and trigger_px <= mid:
            die("validation_error", "BAD_STOP",
                f"Stop loss {trigger_px:.6g} is below market ({mid:.6g}) for a short — would trigger immediately",
                hint="Stop loss for shorts must be above current price")
    else:
        if is_long and trigger_px <= mid:
            die("validation_error", "BAD_TP",
                f"Take profit {trigger_px:.6g} is below market ({mid:.6g}) for a long — would trigger immediately",
                hint="Take profit for longs must be above current price")
        if not is_long and trigger_px >= mid:
            die("validation_error", "BAD_TP",
                f"Take profit {trigger_px:.6g} is above market ({mid:.6g}) for a short — would trigger immediately",
                hint="Take profit for shorts must be below current price")


def _check_liq_vs_stop(position: dict, trigger_px: float, is_long: bool) -> list:
    """Check if a stop loss is inside the liquidation price.

    Constitution Article II: isolated → hard reject, cross → warn.
    Returns warnings list (may be empty). Dies for isolated margin violations.
    """
    liq_px_str = position.get("liquidationPx", "")
    if not liq_px_str:
        return []
    liq_px = float(liq_px_str)
    if liq_px <= 0:
        return []

    is_inside = (is_long and liq_px > trigger_px) or (not is_long and liq_px < trigger_px)
    if not is_inside:
        return []

    lev_info = position.get("leverage", {})
    margin_type = lev_info.get("type", "cross")
    code = "LIQ_ABOVE_STOP" if is_long else "LIQ_BELOW_STOP"
    # Warning body: "any stop below/above liq will never trigger"
    warn_direction = "below" if is_long else "above"
    # Hint: "set stop above/below liq" (opposite — escape the danger zone)
    hint_direction = "above" if is_long else "below"

    if margin_type == "isolated":
        # Isolated margin: liq price is deterministic → hard reject
        die("validation_error", "STOP_INSIDE_LIQ",
            f"Stop at {trigger_px:.6g} is inside liquidation price {liq_px:.6g} "
            f"(isolated margin — liq price is fixed, stop will never trigger)",
            hint=f"Set stop {hint_direction} {liq_px:.6g} or switch to cross margin",
            exit_code=2)

    # Cross margin: liq depends on portfolio → warn only
    return [{
        "code": code,
        "message": f"Liquidation at {liq_px:.6g} — any stop {warn_direction} that will never trigger (yours: {trigger_px:.6g})",
        "liq_price": liq_px,
    }]


def _check_oracle_bound(info, coin: str, px: float, px_kind: str = "price", threshold_pct: float = 1.0) -> list:
    """Preflight warning if a price is outside the per-asset oracle bound.

    HL validates trigger_px / limit_px against each asset's oracle bound at approve
    time; HIP-3 deployers can set very tight bounds (notoriously tight on xyz:CL
    during CME off-hours — 'Price too far from oracle' rejections). This preflight
    surfaces the risk as a warning at propose time instead of a silent approve-time
    failure. Threshold is a heuristic across all HL perps; specific deployer bounds
    may be tighter.

    Returns a list of 0-1 warning dicts.
    """
    oracle = get_asset_oracle_px(info, coin)
    if not oracle or oracle == 0:
        return []
    delta_pct = abs(px - oracle) / oracle * 100
    if delta_pct > threshold_pct:
        return [{
            "code": "ORACLE_BOUND_WARNING",
            "message": (
                f"{px_kind.capitalize()} {px:.6g} is {delta_pct:.2f}% from oracle {oracle:.6g} — "
                f"HL may reject at approve-time with 'Price too far from oracle'. "
                f"Deployer-configured bound; tightest on HIP-3 commodities during underlying off-hours."
            ),
            "oracle_price": oracle,
            "price": px,
            "delta_pct": round(delta_pct, 2),
            "threshold_pct": threshold_pct,
            "kind": px_kind,
        }]
    return []


def _classify_hl_error(msg: str) -> tuple[str, str | None]:
    """Map raw HL error strings to CLI error codes + optional hint.

    Grown reactively as production sessions surface patterns. Preserves the
    raw venue message unchanged; only the `code` field is refined so agents
    can pattern-match on stable semantic labels instead of prose.

    Returns `(code, hint)`. `hint` is None when the code itself is enough;
    otherwise gives agents / users a next-step suggestion.
    """
    lower = msg.lower()
    if "too far from oracle" in lower or "price too far" in lower:
        return (
            "PRICE_TOO_FAR_FROM_ORACLE",
            "Limit/trigger price outside HL's per-asset oracle bound. Place closer to oracle, "
            "or use a synthetic stop via `regard watch price` + manual close when a tight stop "
            "is essential and the bound is very tight (HIP-3 commodities during off-hours).",
        )
    if "insufficient margin" in lower:
        return ("INSUFFICIENT_MARGIN", None)
    if "cannot switch leverage type" in lower:
        return (
            "LEVERAGE_TYPE_LOCKED",
            "HL blocks switching between cross and isolated margin while a position is open. "
            "Close the position first, then change leverage type.",
        )
    # HIP-4 server-side rejections — the brief §6 documents these messages,
    # and Phase 2's client-side `validate_outcome_order` should catch most
    # before they reach the server. Patterns here are the safety net for
    # any edge cases the client missed (e.g. a future tick-size change).
    # Article IV: each pattern landed has a regression test in test_act.py.
    if "order has invalid size" in lower:
        return (
            "OUTCOME_SIZE_NON_INTEGER",
            "HIP-4 outcomes require integer size. Round to a whole number (1, 27, 1024, ...) and re-propose.",
        )
    if "minimum value of 10 usdh" in lower or "must have minimum value of 10" in lower:
        return (
            "OUTCOME_MIN_NOTIONAL",
            "HIP-4 outcomes have a $10 USDH minimum notional. Increase size or raise price so size × price ≥ 10.",
        )
    # Tick-violation pattern is gated on HIP-4-specific context ("usdh" /
    # "outcome") to avoid misclassifying perp tick errors. Perps also have
    # tick alignment requirements; without the gate, a perp message like
    # "price must be a multiple of 0.0001" would be wrongly tagged as
    # OUTCOME_TICK_VIOLATION. Server-side classifier is a safety net only —
    # client-side `validate_outcome_order` catches tick failures pre-propose,
    # so this fallback fires rarely. If the actual server message turns out
    # to differ from the brief's wording, ratchet via test_act.py.
    if "must be a multiple of" in lower and ("usdh" in lower or "outcome" in lower):
        return (
            "OUTCOME_TICK_VIOLATION",
            "HIP-4 outcome price must align to the market's tick size (default 0.0001). Round and re-propose.",
        )
    # Unclassified venue error — stable fallback. Raw message preserved in `message`.
    return ("ORDER_REJECTED", None)


def _check_leverage_preflight(info, coin: str, requested_lev: int, requested_is_cross: bool, margin_info: dict) -> list:
    """Preflight warnings for `regard hypercore leverage` when a position is already open.

    HL rejects `updateLeverage` in two specific cases with open positions:
    1. Type switch (cross↔isolated) — "Cannot switch leverage type with open position"
    2. strictIsolated + leverage increase — the increase frees margin, which
       strictIsolated forbids ("strictIsolated doesn't allow removing margin from
       open positions", confirmed by HL team on Discord 2026-03-13)

    Returns warnings list suitable for the proposal's `warnings[]` field; empty
    when there's no open position or no expected rejection.
    """
    try:
        addr = get_address()
        positions = get_all_positions(info, addr)
    except Exception as exc:
        # Best-effort — don't block propose on a read error, but emit a visible
        # signal so the agent knows preflight's silence means "unknown", not "safe".
        # Without this, a type-switch proposal emits clean and runtime blows up.
        return [{
            "code": "PREFLIGHT_UNAVAILABLE",
            "message": (
                f"Could not verify open positions for {coin} — preflight skipped. "
                f"HL may still reject at approve-time (type switch on open position, "
                f"strictIsolated margin-removal)."
            ),
            "asset": coin,
            "reason": str(exc)[:200],
        }]

    pos = None
    for p in positions:
        if p.get("coin") == coin:
            pos = p
            break
    if pos is None:
        return []

    lev_info = pos.get("leverage", {}) or {}
    current_type = lev_info.get("type", "")  # "cross" | "isolated" | ""
    try:
        current_lev = int(lev_info.get("value", 0))
    except (TypeError, ValueError):
        current_lev = 0

    requested_type = "cross" if requested_is_cross else "isolated"
    warnings = []

    if current_type and current_type != requested_type:
        warnings.append({
            "code": "LEVERAGE_TYPE_SWITCH_WITH_POSITION",
            "message": (
                f"Open position on {coin} uses {current_type} margin; requested {requested_type}. "
                f"HL will reject: 'Cannot switch leverage type with open position'. "
                f"Close the position first."
            ),
            "asset": coin,
            "current_margin_type": current_type,
            "requested_margin_type": requested_type,
        })
        return warnings  # other warnings are moot if the type switch will fail

    is_strict_isolated = margin_info.get("margin_mode") == "strictIsolated"
    # When leverage value is unreadable (0 or missing), we can't compare, but
    # strictIsolated still makes ANY leverage change risky — warn unconditionally
    # rather than silently skip the guard.
    if is_strict_isolated and current_lev == 0:
        warnings.append({
            "code": "LEVERAGE_INCREASE_STRICT_ISOLATED",
            "message": (
                f"{coin} uses strictIsolated margin and has an open position "
                f"(current leverage unknown). Leverage changes that release margin "
                f"are forbidden; close the position first to be safe."
            ),
            "asset": coin,
            "current_leverage": None,
            "requested_leverage": requested_lev,
            "margin_mode": "strictIsolated",
        })
    elif is_strict_isolated and requested_lev > current_lev:
        warnings.append({
            "code": "LEVERAGE_INCREASE_STRICT_ISOLATED",
            "message": (
                f"{coin} uses strictIsolated margin; position is at {current_lev}x, "
                f"requested {requested_lev}x. Increasing leverage releases margin, "
                f"which strictIsolated forbids — HL will likely reject. "
                f"Close the position first, or lower leverage instead."
            ),
            "asset": coin,
            "current_leverage": current_lev,
            "requested_leverage": requested_lev,
            "margin_mode": "strictIsolated",
        })
    elif current_lev and requested_lev != current_lev:
        warnings.append({
            "code": "LEVERAGE_CHANGE_WITH_POSITION",
            "message": (
                f"Position is open on {coin} at {current_lev}x — leverage change to "
                f"{requested_lev}x may be accepted or rejected depending on venue state."
            ),
            "asset": coin,
            "current_leverage": current_lev,
            "requested_leverage": requested_lev,
        })

    return warnings


def _die_with_dex_hint(asset: str, msg: str):
    """Die with a classified error code, plus a dex hint for HIP-3 margin shortfalls."""
    code, generic_hint = _classify_hl_error(msg)
    dex = get_dex_for_coin(asset)
    # INSUFFICIENT_MARGIN on a HIP-3 dex gets an extra balance + transfer hint
    if code == "INSUFFICIENT_MARGIN" and dex:
        try:
            info = get_info()
            addr = get_address()
            dex_state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex})
            dex_val = dex_state.get("marginSummary", dex_state.get("crossMarginSummary", {})).get("accountValue", "0")
            die("venue_error", code, msg,
                hint=f"{dex} dex balance: ${dex_val}. Transfer funds: regard hypercore perp transfer dex {dex} <amount>",
                exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass
    die("venue_error", code, msg, hint=generic_hint, exit_code=4)


def _parse_order_response(resp, asset: str, side_str: str, size: str):
    """Parse SDK order response into CLI output format."""
    if resp.get("status") == "err":
        msg = resp.get("response", str(resp))
        _die_with_dex_hint(asset, msg)

    data = resp.get("response", {}).get("data", {})
    statuses = data.get("statuses", [])
    if not statuses:
        die("venue_error", "ORDER_REJECTED", "No status in response", exit_code=4)

    st = statuses[0]
    if "error" in st:
        _die_with_dex_hint(asset, st["error"])

    if "filled" in st:
        filled = st["filled"]
        return {
            "status": "filled",
            "oid": filled.get("oid", 0),
            "asset": asset,
            "side": side_str,
            "size": filled.get("totalSz", size),
            "avg_price": filled.get("avgPx", ""),
        }
    elif "resting" in st:
        resting = st["resting"]
        return {
            "status": "resting",
            "oid": resting.get("oid", 0),
            "asset": asset,
            "side": side_str,
            "size": size,
        }
    else:
        return {"status": "unknown", "raw": st}



@hypercore_app.command()
def order(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    side: Annotated[str, typer.Argument(help="buy/long or sell/short")],
    size: Annotated[str, typer.Argument(help="Amount in base asset")],
    price: Annotated[str | None, typer.Argument(help="Limit price")] = None,
    market: Annotated[bool, typer.Option("--market", help="Market order (IOC)")] = False,
    tif: Annotated[str | None, typer.Option("--tif", help="gtc|ioc|alo")] = None,
    reduce_only: Annotated[bool, typer.Option("--reduce-only", help="Reduce only")] = False,
    tp: Annotated[str | None, typer.Option("--tp", help="Take profit trigger price")] = None,
    sl: Annotated[str | None, typer.Option("--sl", help="Stop loss trigger price")] = None,
    cloid: Annotated[str | None, typer.Option("--cloid", help="Client order ID (hex)")] = None,
    max_slippage_bps: Annotated[int | None, typer.Option("--max-slippage-bps", help="Maximum slippage in basis points for market orders (e.g. 100 = 1%). Default = SDK default of 5%.")] = None,
):
    """Place an order. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    side_lower = side.lower()
    if side_lower not in SIDE_MAP:
        die("validation_error", "INVALID_SIDE", f"Invalid side: {side}", hint="Use buy/long or sell/short", param="side")

    is_buy = SIDE_MAP[side_lower]

    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    is_market = market or price is None

    # HIP-4 outcome detection (Phase 2). When the resolved coin is `#<enc>`,
    # the perp-shaped checks below (szDecimals lookup, $10 USDC notional
    # via all_mids, oracle-bound, leverage preflight, limit-far-from-mark
    # warnings) don't apply — outcomes have their own validation surface
    # per brief §6. We compute `is_outcome` once and gate the perp blocks
    # below on it, replacing them with `validate_outcome_order` upfront.
    is_outcome = decode_coin(resolved) is not None

    if is_outcome:
        # Triggers (TP/SL) are perp-only — HIP-4 has no liquidations and
        # no built-in trigger orders. Reject early so the agent knows to
        # flatten by crossing the book instead.
        if tp or sl:
            die("validation_error", "HIP4_NO_TRIGGERS",
                "HIP-4 outcomes don't support stop-loss or take-profit triggers",
                hint="Outcomes are fully collateralized with no liquidations — flatten by crossing the book")
        try:
            validate_outcome_order(size, None if is_market else price)
        except OutcomeValidationError as e:
            die("validation_error", e.code, e.message, hint=e.hint, param="size" if "SIZE" in e.code else "price", exit_code=2)

    # Validate size precision against szDecimals from asset meta (perp/spot only;
    # HIP-4 uses validate_outcome_order above)
    if not is_outcome:
        try:
            from decimal import Decimal
            sz_decimals = None
            if ":" in resolved:
                # HIP-3 asset — look up in dex-specific meta
                dex_name = resolved.split(":")[0]
                dex_meta = info.meta(dex=dex_name)
                for asset_info in dex_meta["universe"]:
                    if asset_info["name"] == resolved:
                        sz_decimals = asset_info.get("szDecimals", 8)
                        break
            else:
                # Default perp — look up in default meta
                meta = info.meta()
                asset_idx = info.coin_to_asset.get(resolved)
                if asset_idx is not None and asset_idx < len(meta["universe"]):
                    sz_decimals = meta["universe"][asset_idx].get("szDecimals", 8)

            if sz_decimals is not None:
                d_size = Decimal(size)
                if d_size != d_size.quantize(Decimal(10) ** -sz_decimals):
                    die("validation_error", "PRECISION_EXCEEDED",
                        f"Size {size} exceeds allowed precision of {sz_decimals} decimal places for {resolved}",
                        param="size", exit_code=2)
        except SystemExit:
            raise
        except Exception:
            pass  # if meta lookup fails, let the exchange validate

    # Minimum $10 notional at mark price for perps/spot (exchange rejects below
    # this). HIP-4 is checked above via validate_outcome_order against USDH.
    mids = get_all_mids(info)
    mark = mids.get(resolved)
    if not is_outcome and mark:
        notional = float(size) * float(mark)
        if notional < 10:
            min_size = 10 / float(mark)
            die("validation_error", "BELOW_MIN_NOTIONAL",
                f"Order notional ${notional:.2f} (size {size} × mark ${float(mark):,.2f}) is below the $10 minimum",
                hint=f"Minimum size for {resolved} at current price: {min_size:.6g}",
                param="size", exit_code=2)

    # TP/SL require a limit order — market fills instantly, no resting order to attach to
    if is_market and (tp or sl):
        die("validation_error", "MARKET_WITH_TPSL",
            "Cannot use --sl or --tp with a market order",
            hint="Use a limit price instead of --market to attach TP/SL")

    # Validate TIF for limit orders
    if not is_market:
        tif_map = {"gtc": "Gtc", "ioc": "Ioc", "alo": "Alo"}
        tif_val = tif_map.get((tif or "gtc").lower())
        if not tif_val:
            die("validation_error", "INVALID_TIF", f"Invalid TIF: {tif}", hint="Valid values: gtc, ioc, alo", param="tif")

    # Validate TP/SL direction before creating proposal
    warnings = []
    if tp or sl:
        mids = get_all_mids(info)
        mid = float(mids.get(resolved, "0"))
        if sl:
            _validate_trigger_direction(float(sl), mid, is_buy, is_tp=False)
            # Liq-vs-stop on existing position (new positions skip — liq unknown until open)
            # Use the existing position's side, not the new order's side
            addr = get_address()
            all_pos = get_all_positions(info, addr)
            for pos in all_pos:
                if pos["coin"] == resolved:
                    existing_is_long = float(pos["szi"]) > 0
                    warnings.extend(_check_liq_vs_stop(pos, float(sl), existing_is_long))
                    break
        if tp:
            _validate_trigger_direction(float(tp), mid, is_buy, is_tp=True)

    # Capture mark price for price delta check at approve time. For perps/spot
    # this comes from `all_mids`; outcomes aren't surfaced there, so compute
    # mid from the side's l2 book instead. The approve-flow's price-delta
    # threshold is venue-aware (hl perp = 0.5%, hl outcome = 5% OR 0.01 abs)
    # — see main.py:_get_price_threshold.
    checks = {}
    if is_outcome:
        try:
            from decimal import Decimal as _D
            snap = info.l2_snapshot(resolved)
            levels = snap.get("levels", [[], []])
            if levels and levels[0] and levels[1]:
                top_bid = _D(levels[0][0]["px"])
                top_ask = _D(levels[1][0]["px"])
                checks["mark_price"] = str((top_bid + top_ask) / _D(2))
        except Exception:
            pass  # outcome mid unavailable — approve flow degrades gracefully
    else:
        mids = get_all_mids(info)
        mark = mids.get(resolved)
        if mark is not None:
            checks["mark_price"] = mark

    # Warn if limit price is far from market (likely hallucinated price).
    # Perp/spot only — outcome prices are bounded [0.001, 0.999] so this
    # heuristic doesn't translate. Skip for ALO (post-only).
    tif_lower = (tif or "gtc").lower()
    if not is_outcome and not is_market and price and mark and tif_lower != "alo":
        try:
            limit_px = float(price)
            mark_px = float(mark)
            if mark_px > 0:
                pct = (limit_px - mark_px) / mark_px * 100
                if is_buy and pct > 100:
                    warnings.append(f"Buy limit ${limit_px:,.6g} is {pct:,.0f}% above mark ${mark_px:,.6g} — will fill immediately at market price")
                elif not is_buy and pct < -50:
                    warnings.append(f"Sell limit ${limit_px:,.6g} is {abs(pct):,.0f}% below mark ${mark_px:,.6g} — will fill immediately at market price")
        except (ValueError, TypeError):
            pass  # non-numeric price — let downstream validation handle it

    # Oracle-bound preflight (perp-only: catches HIP-3 'Price too far from oracle'
    # at propose time). HIP-4 has no oracle bound — its price is its own market.
    if not is_outcome and not is_market and price:
        try:
            warnings.extend(_check_oracle_bound(info, resolved, float(price), "limit"))
        except (ValueError, TypeError):
            pass
    if sl:
        try:
            warnings.extend(_check_oracle_bound(info, resolved, float(sl), "sl trigger"))
        except (ValueError, TypeError):
            pass
    if tp:
        try:
            warnings.extend(_check_oracle_bound(info, resolved, float(tp), "tp trigger"))
        except (ValueError, TypeError):
            pass

    # --max-slippage-bps validation: positive integer, sane upper bound (50% = 5000 bps)
    if max_slippage_bps is not None:
        if max_slippage_bps <= 0 or max_slippage_bps > 5000:
            die("validation_error", "INVALID_SLIPPAGE",
                f"--max-slippage-bps must be between 1 and 5000 (0.01%–50%), got {max_slippage_bps}",
                param="max_slippage_bps", exit_code=2)

    params = {
        "asset": resolved,
        "side": side_lower,
        "is_buy": is_buy,
        "size": size,
        "price": price,
        "market": is_market,
        "tif": tif,
        "reduce_only": reduce_only,
        "tp": tp,
        "sl": sl,
        "cloid": cloid,
        "max_slippage_bps": max_slippage_bps,
        "testnet": opts["testnet"],
    }

    proposal = create_proposal("hypercore", "order", params, checks, warnings)
    output(proposal, opts["fields"])


def _wire_executor_resolver(info, resolved: str) -> None:
    """Ensure info.coin_to_asset has `resolved` populated before SDK calls.

    HIP-3 (`<dex>:<asset>`) and HIP-4 (`#<encoding>`) coins are absent from
    the SDK's default coin_to_asset map; the resolver patches them in via
    lazy load. Approve runs in a separate process from propose, so the
    wiring must happen on every executor entry that calls
    `exchange.<method>(coin, ...)`. Without this, the SDK raises and the
    venue layer surfaces ORDER_REJECTED / CANCEL_FAILED with the bare coin
    name. Discovered live across HIP-4 Cycle C on bonbonki 2026-05-04
    (v0.22.0 → 0.22.1 → 0.22.2 → 0.22.3 ratchet chain).
    """
    if ":" in resolved:
        from regard.venues.hyperliquid.resolver import Resolver
        Resolver(info).resolve(resolved)
    elif resolved.startswith("#"):
        from regard.venues.hyperliquid.resolver import get_resolver
        get_resolver(info).get_outcomes()


def execute_order(params: dict) -> dict:
    """Execute an order from proposal params. Called by `regard approve`."""
    exchange = get_exchange(params.get("testnet", False))
    resolved = params["asset"]
    _wire_executor_resolver(exchange.info, resolved)
    is_buy = params["is_buy"]
    sz = float(params["size"])
    side_str = params["side"]
    size_str = params["size"]

    from hyperliquid.utils.types import Cloid as SdkCloid
    sdk_cloid = SdkCloid.from_str(params["cloid"]) if params.get("cloid") else None

    # Convert --max-slippage-bps to SDK's slippage float (e.g. 100 bps = 0.01).
    # When unset, fall back to the SDK default (DEFAULT_SLIPPAGE = 5%).
    max_slippage_bps = params.get("max_slippage_bps")
    market_kwargs = {"cloid": sdk_cloid}
    if max_slippage_bps is not None:
        market_kwargs["slippage"] = float(max_slippage_bps) / 10000.0

    if params.get("market"):
        try:
            resp = exchange.market_open(resolved, is_buy, sz, **market_kwargs)
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        return _parse_order_response(resp, resolved, side_str, size_str)

    # Limit order
    px = float(params["price"])
    tif_map = {"gtc": "Gtc", "ioc": "Ioc", "alo": "Alo"}
    tif_val = tif_map.get((params.get("tif") or "gtc").lower())
    order_type = {"limit": {"tif": tif_val}}

    if params.get("tp") or params.get("sl"):
        order_requests = [
            {
                "coin": resolved,
                "is_buy": is_buy,
                "sz": sz,
                "limit_px": px,
                "order_type": order_type,
                "reduce_only": params.get("reduce_only", False),
                "cloid": sdk_cloid,
            }
        ]
        if params.get("tp"):
            tp_px = float(params["tp"])
            tp_type = {"trigger": {"triggerPx": tp_px, "isMarket": True, "tpsl": "tp"}}
            order_requests.append({
                "coin": resolved,
                "is_buy": not is_buy,
                "sz": sz,
                "limit_px": tp_px,
                "order_type": tp_type,
                "reduce_only": True,
            })
        if params.get("sl"):
            sl_px = float(params["sl"])
            sl_type = {"trigger": {"triggerPx": sl_px, "isMarket": True, "tpsl": "sl"}}
            order_requests.append({
                "coin": resolved,
                "is_buy": not is_buy,
                "sz": sz,
                "limit_px": sl_px,
                "order_type": sl_type,
                "reduce_only": True,
            })

        try:
            resp = exchange.bulk_orders(
                [exchange._order_request_to_wire(r) for r in order_requests]
                if hasattr(exchange, "_order_request_to_wire")
                else order_requests,
                grouping="normalTpsl",
            )
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        return _parse_order_response(resp, resolved, side_str, size_str)
    else:
        try:
            resp = exchange.order(resolved, is_buy, sz, px, order_type, params.get("reduce_only", False), cloid=sdk_cloid)
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        return _parse_order_response(resp, resolved, side_str, size_str)


register_executor("hypercore", "order", execute_order)


@hypercore_app.command()
def cancel(
    ctx: typer.Context,
    first: Annotated[str | None, typer.Argument(help="OID or asset name")] = None,
    second: Annotated[str | None, typer.Argument(help="OID (if first is asset)")] = None,
    cloid: Annotated[str | None, typer.Option("--cloid", help="Cancel by client order ID")] = None,
    asset_opt: Annotated[str | None, typer.Option("--asset", help="Asset for cloid cancel")] = None,
):
    """Cancel a specific order. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    if cloid:
        if not asset_opt:
            die("validation_error", "MISSING_ARGUMENT", "Must specify --asset with --cloid", hint="regard hypercore cancel --cloid 0x... --asset BTC")
        if not cloid.startswith("0x") or len(cloid) != 34:
            die("validation_error", "INVALID_CLOID", f"Client order ID must be 0x + 32 hex chars, got: {cloid}",
                hint="Example: 0x0123456789abcdef0123456789abcdef", param="cloid")
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset_opt)
        params = {"asset": resolved, "cloid": cloid, "testnet": opts["testnet"]}
    elif first is None:
        die("validation_error", "MISSING_ARGUMENT", "Must specify OID or --cloid",
            hint="regard hypercore cancel <oid> OR regard hypercore cancel --cloid 0x... --asset BTC")
    elif second is not None:
        resolver = get_resolver(info)
        resolved = resolver.resolve(first)
        oid = int(second)
        params = {"asset": resolved, "oid": oid, "testnet": opts["testnet"]}
    else:
        oid = int(first)
        addr = get_address()
        open_orders = info.open_orders(addr)
        coin = None
        for o in open_orders:
            if o["oid"] == oid:
                coin = o["coin"]
                break
        if not coin:
            die("validation_error", "ORDER_NOT_FOUND", f"Order {oid} not found in open orders", hint=f"Pass asset explicitly: regard hypercore cancel BTC {oid}")
        params = {"asset": coin, "oid": oid, "testnet": opts["testnet"]}

    proposal = create_proposal("hypercore", "cancel", params, {}, [])
    output(proposal, opts["fields"])


def execute_cancel(params: dict) -> dict:
    """Execute a cancel from proposal params."""
    exchange = get_exchange(params.get("testnet", False))
    resolved = params["asset"]
    _wire_executor_resolver(exchange.info, resolved)

    if "cloid" in params:
        from hyperliquid.utils.types import Cloid as SdkCloid
        resp = exchange.cancel_by_cloid(resolved, SdkCloid.from_str(params["cloid"]))
        if isinstance(resp, dict) and resp.get("status") == "err":
            die("venue_error", "CANCEL_FAILED", resp.get("response", str(resp)), exit_code=4)
        return {"status": "cancelled", "asset": resolved, "cloid": params["cloid"]}
    else:
        oid = params["oid"]
        resp = exchange.cancel(resolved, oid)
        if isinstance(resp, dict) and resp.get("status") == "err":
            die("venue_error", "CANCEL_FAILED", resp.get("response", str(resp)), exit_code=4)
        return {"status": "cancelled", "oid": oid, "asset": resolved}


register_executor("hypercore", "cancel", execute_cancel)


@hypercore_app.command(name="cancel-all")
def cancel_all(
    ctx: typer.Context,
    asset: Annotated[str | None, typer.Argument(help="Cancel only this asset's orders")] = None,
):
    """Cancel all open orders. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address()
    all_orders = get_all_orders(info, addr)

    if asset:
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset)
        all_orders = [o for o in all_orders if o["coin"] == resolved]

    if not all_orders:
        output({"cancelled": 0, "assets": []}, opts["fields"])
        return

    cancel_requests = [{"coin": o["coin"], "oid": o["oid"]} for o in all_orders]
    assets_found = sorted(set(o["coin"] for o in all_orders))
    params = {"cancel_requests": cancel_requests, "count": len(all_orders), "assets": assets_found, "testnet": opts["testnet"]}

    proposal = create_proposal("hypercore", "cancel-all", params, {}, [])
    output(proposal, opts["fields"])


def execute_cancel_all(params: dict) -> dict:
    """Execute a cancel-all from proposal params."""
    exchange = get_exchange(params.get("testnet", False))
    cancel_requests = params["cancel_requests"]
    # Some cancel_requests may target HIP-3 / HIP-4 coins — wire each.
    for req in cancel_requests:
        coin = req.get("coin")
        if isinstance(coin, str):
            _wire_executor_resolver(exchange.info, coin)
    resp = exchange.bulk_cancel(cancel_requests)
    result = {"cancelled": params["count"], "assets": params["assets"]}
    if isinstance(resp, dict) and resp.get("status") == "err":
        die("venue_error", "CANCEL_FAILED", resp.get("response", str(resp)), exit_code=4)
    if isinstance(resp, dict):
        result["response"] = resp
    return result


register_executor("hypercore", "cancel-all", execute_cancel_all)


@hypercore_app.command()
def leverage(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    lev: Annotated[int, typer.Argument(help="Leverage (integer)")],
    cross: Annotated[bool, typer.Option("--cross", help="Cross margin")] = False,
    isolated: Annotated[bool, typer.Option("--isolated", help="Isolated margin")] = False,
):
    """Set leverage for an asset. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    if cross and isolated:
        die("validation_error", "CONFLICTING_OPTIONS", "Cannot specify both --cross and --isolated")

    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    # Fetch margin_info once — also used by preflight below
    margin_info = get_asset_margin_info(info, resolved)

    is_cross = not isolated  # default is cross
    if is_cross and is_isolated_only(margin_info):
        mode = margin_info.get("margin_mode") or "onlyIsolated"
        print(f"Warning: {resolved} requires isolated margin ({mode}). Using isolated.", file=sys.stderr)
        is_cross = False

    warnings = _check_leverage_preflight(info, resolved, lev, is_cross, margin_info)

    params = {
        "asset": resolved,
        "leverage": lev,
        "is_cross": is_cross,
        "testnet": opts["testnet"],
    }

    proposal = create_proposal("hypercore", "leverage", params, {}, warnings)
    output(proposal, opts["fields"])


def execute_leverage(params: dict) -> dict:
    """Execute a leverage change from proposal params.

    HL's `updateLeverage` endpoint returns HTTP 200 + `{"status": "err", "response": msg}`
    on rejections (e.g. type switch with open position, strictIsolated margin-removal
    blocks). Raw message preserved; code refined via `_classify_hl_error()`.
    """
    exchange = get_exchange(params.get("testnet", False))
    _wire_executor_resolver(exchange.info, params["asset"])
    resp = exchange.update_leverage(params["leverage"], params["asset"], params["is_cross"])
    # Defensive: guard against SDK drift. Current SDK (0.14+) returns a dict,
    # but a future version returning a bare string must not be silently
    # treated as success — same class of bug this fix was designed to eliminate.
    if not isinstance(resp, dict):
        code, hint = _classify_hl_error(str(resp))
        die("venue_error", code, str(resp), hint=hint, exit_code=4)
    if resp.get("status") == "err":
        msg = resp.get("response", str(resp))
        msg_str = msg if isinstance(msg, str) else str(msg)
        code, hint = _classify_hl_error(msg_str)
        die("venue_error", code, msg_str, hint=hint, exit_code=4)
    return {
        "asset": params["asset"],
        "leverage": params["leverage"],
        "margin_mode": "cross" if params["is_cross"] else "isolated",
    }


register_executor("hypercore", "leverage", execute_leverage)


@hypercore_app.command()
def stop(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    price: Annotated[str, typer.Argument(help="Trigger price")],
    tp: Annotated[bool, typer.Option("--tp", help="Take profit instead of stop loss")] = False,
):
    """Set a stop loss (or take profit) on an existing position. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    # Look up the current position across all dexes (default + HIP-3)
    addr = get_address()
    all_pos = get_all_positions(info, addr)
    position = None
    for pos in all_pos:
        if pos["coin"] == resolved:
            position = pos
            break

    if not position:
        die("validation_error", "NO_POSITION", f"No open position for {resolved}",
            hint=f"Check positions: regard hypercore positions {asset}")

    size = abs(float(position["szi"]))
    is_long = float(position["szi"]) > 0
    trigger_px = float(price)

    # Validate trigger direction (shared with order --sl/--tp)
    mids = get_all_mids(info)
    mid = float(mids.get(resolved, "0"))
    _validate_trigger_direction(trigger_px, mid, is_long, is_tp=tp)

    # Liq-vs-stop: isolated → hard reject, cross → warn (Constitution Article II)
    warnings = []
    if not tp:
        warnings.extend(_check_liq_vs_stop(position, trigger_px, is_long))

    # Oracle-bound preflight (catches HIP-3 'Price too far from oracle' at propose time)
    warnings.extend(_check_oracle_bound(info, resolved, trigger_px, "tp trigger" if tp else "sl trigger"))

    checks = {}
    mark = mids.get(resolved)
    if mark is not None:
        checks["mark_price"] = mark

    params = {
        "asset": resolved,
        "trigger_price": price,
        "size": str(size),
        "is_long": is_long,
        "is_tp": tp,
        "testnet": opts["testnet"],
    }

    proposal = create_proposal("hypercore", "stop", params, checks, warnings)
    output(proposal, opts["fields"])


def execute_stop(params: dict) -> dict:
    """Execute a stop/TP from proposal params."""
    exchange = get_exchange(params.get("testnet", False))
    resolved = params["asset"]
    _wire_executor_resolver(exchange.info, resolved)
    trigger_px = float(params["trigger_price"])
    size = float(params["size"])
    is_long = params["is_long"]
    is_tp = params["is_tp"]

    tpsl = "tp" if is_tp else "sl"
    trigger_type = {"trigger": {"triggerPx": trigger_px, "isMarket": True, "tpsl": tpsl}}

    is_buy = not is_long
    try:
        resp = exchange.order(resolved, is_buy, size, trigger_px, trigger_type, reduce_only=True)
    except SystemExit:
        raise
    except Exception as e:
        err = str(e)
        if "reduce only" in err.lower() or "no position" in err.lower():
            die("venue_error", "POSITION_CLOSED",
                f"Position for {resolved} may have closed since proposal — reduce-only order rejected: {err}",
                hint=f"Check positions: regard hypercore positions {resolved}",
                exit_code=4)
        code, hint = _classify_hl_error(err)
        die("venue_error", code, err, hint=hint, exit_code=4)
    result = _parse_order_response(resp, resolved, "sell" if is_long else "buy", params["size"])
    result["trigger_price"] = params["trigger_price"]
    result["type"] = "take_profit" if is_tp else "stop_loss"
    result["position_side"] = "long" if is_long else "short"
    return result


register_executor("hypercore", "stop", execute_stop)


# ---------------------------------------------------------------------------
# Fund-movement vocabulary (CLI Constitution Article VI)
#
# Three explicit verbs:
#   transfer <compartment> — same-account compartment shift via send_asset
#   send <addr>            — wallet-to-wallet on the same chain
#   bridge <chain>         — cross-chain (deferred to v0.25.0)
#
# The grammar is `<env> <compartment> <verb> <destination> <args>`. Source
# compartment lives in the path, never in a flag. The seven explicit transfer
# commands map onto a single shared `_propose_transfer` + `execute_transfer`
# pair so the SDK call surface is identical to the prior single-command form.
# ---------------------------------------------------------------------------


# Source compartment subapps. Spot also hosts the `send` command (wallet-
# to-wallet on the spot layer is the only HL send path the SDK exposes today).
perp_app = typer.Typer(
    name="perp",
    no_args_is_help=True,
    help="Hypercore default-perp clearinghouse. Use as a source compartment.",
    pretty_exceptions_enable=False,
)
spot_app = typer.Typer(
    name="spot",
    no_args_is_help=True,
    help="Hypercore spot CLOB / spot-balance compartment.",
    pretty_exceptions_enable=False,
)
dex_app = typer.Typer(
    name="dex",
    no_args_is_help=True,
    help="Hypercore HIP-3 deployer dex compartment. Pass the dex name as a positional argument.",
    pretty_exceptions_enable=False,
)

# Nested transfer subapps: one per source compartment.
perp_transfer_app = typer.Typer(
    name="transfer",
    no_args_is_help=True,
    help="Move funds out of the default-perp compartment.",
    pretty_exceptions_enable=False,
)
spot_transfer_app = typer.Typer(
    name="transfer",
    no_args_is_help=True,
    help="Move funds out of the spot compartment.",
    pretty_exceptions_enable=False,
)
dex_transfer_app = typer.Typer(
    name="transfer",
    no_args_is_help=True,
    help="Move funds out of an HIP-3 dex compartment.",
    pretty_exceptions_enable=False,
)


@dex_app.callback()
def dex_callback(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="HIP-3 deployer dex name (e.g. xyz, flx, hyna)")],
):
    """Capture the dex name into context for nested commands."""
    ctx.ensure_object(dict)
    # Inherit testnet flag from the parent hypercore subapp.
    parent_obj = ctx.parent.obj if ctx.parent and isinstance(ctx.parent.obj, dict) else {}
    if parent_obj:
        ctx.obj.update(parent_obj)
    ctx.obj["dex_name"] = name


def _propose_transfer(
    opts: dict,
    *,
    source: str,
    dest: str,
    amount: str,
    token: str | None,
) -> None:
    """Shared propose path for all 7 hypercore transfer commands.

    `source` and `dest` use the SDK's send_asset convention:
      ""     → default perp clearinghouse
      "spot" → spot
      <name> → HIP-3 deployer dex
    """
    source_label = source or "default"
    dest_label = dest or "default"
    is_spot = source == "spot" or dest == "spot"

    info = get_info(opts["testnet"])
    addr = get_address()

    # Unified/portfolio margin accounts share margin across all dexes — intra-account transfers are no-ops
    acct_mode = get_account_mode(info, addr)
    if acct_mode in ("unifiedAccount", "portfolioMargin"):
        die("validation_error", "UNIFIED_ACCOUNT",
            f"Your account is in {acct_mode} mode — margin is shared across all dexes. "
            "No transfer needed, you can trade on any dex directly.",
            exit_code=2)

    if is_spot:
        # Article I: spot transfers MUST specify --token in either direction.
        # Previously perp→spot silently defaulted to USDC, which is wrong for
        # HIP-3 dexes using non-USDC collateral (flx=USDH, hyna=USDE, cash=USDT0)
        # and a silent pick among candidates even for default→spot.
        if not token:
            die("validation_error", "MISSING_TOKEN",
                "Specify --token for spot transfers (e.g. --token USDC or --token USDH)",
                exit_code=2)
        token_name = token
    else:
        collateral_map = get_collateral_map(info)
        src_token = collateral_map.get(source, ("USDC", 0))
        dst_token = collateral_map.get(dest, ("USDC", 0))

        if src_token[1] != dst_token[1]:
            die("validation_error", "COLLATERAL_MISMATCH",
                f"{source_label} dex uses {src_token[0]} but {dest_label} dex uses {dst_token[0]} — "
                f"cannot transfer between dexes with different collateral tokens",
                exit_code=2)
        token_name = token or src_token[0]

    # Validate amount is numeric
    try:
        transfer_amount = float(amount)
    except ValueError:
        die("validation_error", "INVALID_AMOUNT", f"Amount must be a number, got: {amount}", param="amount")

    # Check source balance at propose time
    if source == "spot":
        # Spot source: check spot balance for the specific token
        # Use spot_user_state directly so API errors are caught (get_spot_balances
        # swallows exceptions and returns [], which would false-reject).
        try:
            spot_state = info.spot_user_state(addr)
            raw_bals = spot_state.get("balances", [])
            spot_meta = info.spot_meta()
            tokens_by_index = {t["index"]: t for t in spot_meta["tokens"]}
            token_bal = 0.0
            for bal in raw_bals:
                t_info = tokens_by_index.get(bal.get("token", -1))
                if t_info and t_info["name"] == token_name:
                    if "total" in bal:
                        # Unified account format
                        token_bal = float(bal["total"])
                    else:
                        # Legacy format: holds/withdrawn in wei
                        holds = int(bal.get("holds", "0"))
                        withdrawn = int(bal.get("withdrawn", "0"))
                        wei_decimals = t_info.get("weiDecimals", 18)
                        token_bal = (holds - withdrawn) / (10 ** wei_decimals)
                    break
            if token_bal > 0 and transfer_amount > token_bal:
                die("venue_error", "INSUFFICIENT_BALANCE",
                    f"Spot balance for {token_name} is {token_bal}, cannot transfer {transfer_amount}",
                    hint="Check balances: regard hypercore balance",
                    exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass  # API error → skip check, let exchange validate
    else:
        try:
            state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": source})
            available = float(state.get("withdrawable", "0"))
            if transfer_amount > available:
                die("venue_error", "INSUFFICIENT_BALANCE",
                    f"{source_label} dex has ${available:.2f} withdrawable {token_name}, cannot transfer ${transfer_amount:.2f}",
                    hint="Some balance may be locked as margin for open positions",
                    exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass

    # Resolve SDK-compatible token name for non-canonical tokens (USDH, USDE, USDT0)
    # Canonical tokens use plain name; non-canonical need "NAME:tokenId" for send_asset
    sdk_token_name = token_name
    try:
        spot_meta = info.spot_meta()
        for t in spot_meta.get("tokens", []):
            if t["name"] == token_name:
                if not t.get("isCanonical", False):
                    sdk_token_name = f"{t['name']}:{t['tokenId']}"
                break
    except Exception:
        pass  # fall back to plain name

    params = {
        "amount": amount,
        "source": source,
        "dest": dest,
        "source_label": source_label,
        "dest_label": dest_label,
        "token": token_name,
        "sdk_token": sdk_token_name,
        "addr": addr,
        "testnet": opts["testnet"],
    }

    proposal = create_proposal("hypercore", "transfer", params, {}, [])
    output(proposal, opts["fields"])


# --- perp source ----------------------------------------------------------

@perp_transfer_app.command("spot")
def perp_transfer_spot(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[str, typer.Option("--token", help="Token name (e.g. USDC) — required for spot transfers")] = "",
):
    """Move USDC from the default-perp clearinghouse to spot. Creates a proposal."""
    _propose_transfer(ctx.obj, source="", dest="spot", amount=amount, token=token or None)


@perp_transfer_app.command("dex")
def perp_transfer_dex(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Destination HIP-3 dex name")],
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[str | None, typer.Option("--token", help="Override collateral token (rarely needed)")] = None,
):
    """Move funds from the default-perp clearinghouse to an HIP-3 dex. Creates a proposal."""
    _propose_transfer(ctx.obj, source="", dest=name, amount=amount, token=token)


# --- spot source ----------------------------------------------------------

@spot_transfer_app.command("perp")
def spot_transfer_perp(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[str, typer.Option("--token", help="Token name (e.g. USDC) — required")] = "",
):
    """Move USDC from spot to the default-perp clearinghouse. Creates a proposal."""
    _propose_transfer(ctx.obj, source="spot", dest="", amount=amount, token=token or None)


@spot_transfer_app.command("dex")
def spot_transfer_dex(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Destination HIP-3 dex name")],
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[str, typer.Option("--token", help="Token name (USDC for default, USDH for flx, etc.) — required")] = "",
):
    """Move a spot token to an HIP-3 dex (e.g. USDH from spot to flx). Creates a proposal."""
    _propose_transfer(ctx.obj, source="spot", dest=name, amount=amount, token=token or None)


# --- dex source -----------------------------------------------------------

@dex_transfer_app.command("spot")
def dex_transfer_spot(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[str, typer.Option("--token", help="Token name on this dex (e.g. USDH for flx) — required")] = "",
):
    """Move funds from this dex back to spot. Creates a proposal."""
    src = ctx.obj["dex_name"]
    _propose_transfer(ctx.obj, source=src, dest="spot", amount=amount, token=token or None)


@dex_transfer_app.command("perp")
def dex_transfer_perp(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[str | None, typer.Option("--token", help="Override collateral token (rarely needed)")] = None,
):
    """Move funds from this dex to the default-perp clearinghouse. Creates a proposal."""
    src = ctx.obj["dex_name"]
    _propose_transfer(ctx.obj, source=src, dest="", amount=amount, token=token)


@dex_transfer_app.command("dex")
def dex_transfer_dex(
    ctx: typer.Context,
    other: Annotated[str, typer.Argument(help="Destination HIP-3 dex name")],
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[str, typer.Option("--token", help="Token name (must match both dexes' collateral) — required")] = "",
):
    """Move funds between two HIP-3 dexes (e.g. para → kn). Creates a proposal."""
    src = ctx.obj["dex_name"]
    _propose_transfer(ctx.obj, source=src, dest=other, amount=amount, token=token or None)


# Wire the subapp tree onto hypercore_app.
perp_app.add_typer(perp_transfer_app, name="transfer")
spot_app.add_typer(spot_transfer_app, name="transfer")
dex_app.add_typer(dex_transfer_app, name="transfer")
hypercore_app.add_typer(perp_app, name="perp")
hypercore_app.add_typer(spot_app, name="spot")
hypercore_app.add_typer(dex_app, name="dex")


def execute_transfer(params: dict) -> dict:
    """Execute a transfer from proposal params. Shared by all 7 transfer commands."""
    exchange = get_exchange(params.get("testnet", False))
    addr = params["addr"]
    source = params["source"]
    dest = params["dest"]
    token_name = params.get("sdk_token", params["token"])
    amount = float(params["amount"])

    try:
        resp = exchange.send_asset(addr, source, dest, token_name, amount)
        if resp.get("status") == "err":
            die("venue_error", "TRANSFER_FAILED", resp.get("response", str(resp)), exit_code=4)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "TRANSFER_FAILED", str(e), exit_code=4)

    return {
        "amount": params["amount"],
        "from_dex": params["source_label"],
        "to_dex": params["dest_label"],
        "token": token_name,
    }


# Single executor key for all 7 transfer commands. Each propose path stores
# `command="transfer"` in the proposal, so the same executor fires regardless
# of which compartment pair the user picked. The new dot-path command tree is
# expressed in the click structure and `_MUTATING` classification (main.py);
# the executor itself doesn't need to know which path the propose came from
# because `params["source"]` and `params["dest"]` carry that information.
register_executor("hypercore", "transfer", execute_transfer)


# ---------------------------------------------------------------------------
# Send — wallet-to-wallet transfer via address book
# ---------------------------------------------------------------------------


@spot_app.command("send")
def spot_send(
    ctx: typer.Context,
    addr: Annotated[str, typer.Argument(help="Address book label, or raw 0x address with --raw")],
    amount: Annotated[str, typer.Argument(help="Amount to send")],
    token: Annotated[str, typer.Option("--token", help="Token name (e.g. USDC, USDH) — required")] = "",
    raw: Annotated[bool, typer.Option("--raw", help="Treat addr as a raw 0x address (requires SEND_ALLOW_RAW_ADDRESS)")] = False,
):
    """Send a spot token wallet-to-wallet on the Hypercore spot layer. Creates a proposal."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    from regard.commands.address import resolve_address
    from regard.core.audit import log_event
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk

    settings_env = load_project_env()

    # --- Token is required ---
    # Constitution Article I forbids silent picks on ambiguous input. HL spot
    # accounts routinely hold multiple tokens (USDC, USDH, USDE, USDT0), so
    # defaulting to USDC would silently choose one among many. Require explicit
    # specification.
    if not token:
        die("validation_error", "MISSING_TOKEN",
            "Must specify --token (e.g. USDC, USDH, USDE, USDT0)",
            hint="regard hypercore spot send <addr> <amount> --token USDC")

    # --- Resolve destination ---
    # Default: treat `addr` as an address-book label. With `--raw`, treat it
    # as a raw 0x address (subject to SEND_ALLOW_RAW_ADDRESS). A bare 0x
    # address without --raw is rejected so users don't bypass the address
    # book by accident.
    if raw:
        if not settings_env.get("SEND_ALLOW_RAW_ADDRESS"):
            die(
                "validation_error", "RAW_ADDRESS_BLOCKED",
                "Raw addresses are disabled. Use a label from the address book.",
                hint="To enable: set SEND_ALLOW_RAW_ADDRESS=true in settings. Or add the address: regard address add <label> <address>",
            )
        from regard.commands.address import _validate_checksum
        dest_address = _validate_checksum(addr)
        dest_label = "RAW"
    elif addr.startswith("0x"):
        die(
            "validation_error", "RAW_ADDRESS_BLOCKED",
            "Raw 0x addresses require --raw and SEND_ALLOW_RAW_ADDRESS=true.",
            hint="Add a label: regard address add <label> <address>, or pass --raw",
        )
    else:
        dest = resolve_address(addr, "hypercore")
        dest_address = dest["address"]
        dest_label = dest["label"]

    # --- Resolve token via spot_meta ---
    # Article II: amount stays Decimal end-to-end; float() is permitted only
    # inline at external SDK call boundaries.
    from decimal import Decimal
    amt = Decimal(amount)
    sdk_token = token
    try:
        spot_meta = info.spot_meta()
        found = False
        for t in spot_meta.get("tokens", []):
            if t["name"].upper() == token.upper():
                found = True
                if not t.get("isCanonical", False):
                    sdk_token = f"{t['name']}:{t['tokenId']}"
                else:
                    sdk_token = t["name"]
                break
        if not found:
            die("validation_error", "UNKNOWN_TOKEN", f"Token '{token}' not found in Hyperliquid spot_meta",
                hint="Check available tokens with: regard hypercore spot-balances")
    except SystemExit:
        raise
    except Exception:
        pass  # fall back to plain name

    sender_addr = get_address(testnet=opts["testnet"])

    # --- Self-send check ---
    if sender_addr.lower() == dest_address.lower():
        die("validation_error", "SELF_SEND", "Cannot send to yourself",
            hint="Pick a different label or address")

    # --- Safety checks (config gates fire before state checks so users see
    #     their own caps before "insufficient balance") ---
    check_amount_cap(amt, token, settings_env)
    check_daily_cap(amt, token, "hypercore", settings_env)
    check_cooldown(dest_address, settings_env)

    # --- Balance check (Decimal-only; defensive str() per Article II) ---
    try:
        from regard.venues.hyperliquid.client import get_spot_balances
        balances = get_spot_balances(info, sender_addr)
        balance = Decimal(0)
        for b in balances:
            if b.get("token", "").upper() == token.upper():
                balance = Decimal(str(b.get("balance", "0")))
                break
    except Exception:
        balance = Decimal(0)

    if balance < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"Balance ({balance} {token}) less than send amount ({amt} {token})",
            exit_code=4)

    # --- Risk classification ---
    risk = classify_risk(amt, balance)

    warnings = []
    pct = (amt / balance * 100) if balance > 0 else Decimal(0)
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Sending {pct:.0f}% of your {token} balance"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Sending {pct:.0f}% of your {token} balance. Approve will require --confirm-addr"})

    # --- Activation-fee disclosure (per HL docs activation-gas-fee.md) ---
    # First transfer to a fresh HL account burns 1 quote token. For quote-token
    # sends we know the exact recipient_credited; for other tokens we surface
    # a generic warning so the user knows their full amount won't arrive.
    activation_fee = None
    recipient_credited = None
    if _is_fresh_hl_user(info, dest_address):
        if token.upper() in _QUOTE_TOKENS:
            activation_fee = Decimal("1")
            # Recipient gets max(amount - fee, 0). HL doesn't credit negative
            # amounts; if fee >= amount, recipient receives nothing and the
            # ACTIVATION_FEE_EXCEEDS_AMOUNT warning fires below.
            raw_credit = amt - activation_fee
            recipient_credited = max(raw_credit, Decimal(0)).quantize(Decimal("0.000001"))
            warnings.append({
                "type": "RECIPIENT_FRESH_ACTIVATION_FEE",
                "message": (
                    f"Recipient {dest_address} is a fresh HL account. Per HL docs, "
                    f"the first transfer to a fresh account burns a 1 {token} "
                    f"activation fee. Recipient will receive {recipient_credited} {token}, "
                    f"not the full {amt} {token}."
                ),
                "fee_amount": "1",
                "fee_token": token,
            })
            if amt <= activation_fee:
                warnings.append({
                    "type": "ACTIVATION_FEE_EXCEEDS_AMOUNT",
                    "message": (
                        f"Send amount ({amt} {token}) does not exceed the 1 {token} "
                        f"activation fee. Recipient will receive nothing — the entire "
                        f"send will be consumed by the activation fee."
                    ),
                })
        else:
            warnings.append({
                "type": "RECIPIENT_FRESH_ACTIVATION_FEE",
                "message": (
                    f"Recipient {dest_address} is a fresh HL account. Per HL docs, "
                    f"the first transfer to a fresh account burns a 1 quote-token "
                    f"activation fee (e.g. 1 USDC). The recipient will need an extra "
                    f"quote-token balance to cover this — exact mechanics for non-quote "
                    f"sends ({token}) are not modelled in the CLI."
                ),
            })

    params = {
        "sender": sender_addr,
        "dest_address": dest_address,
        "dest_label": dest_label,
        "token": token,
        "sdk_token": sdk_token,
        "amount": str(amt),
        "testnet": opts["testnet"],
    }
    checks = {
        "sender": sender_addr,
        "sender_balance": str(balance),
        "projected_balance": str((balance - amt).quantize(Decimal("0.000001"))),
        "risk": risk,
    }
    if activation_fee is not None:
        checks["recipient_activation_fee"] = str(activation_fee)
        checks["recipient_credited"] = str(recipient_credited)

    log_event("proposed", command="spot.send", venue="hypercore", to=dest_address, to_label=dest_label, token=token, amount=str(amt), risk=risk)
    proposal = create_proposal("hypercore", "spot.send", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_hl_send_safety(params: dict) -> None:
    """Pre-claim safety re-checks for hypercore spot send (sender key, cooldown, daily cap).

    Called from approve BEFORE claim_proposal so fixable mismatches don't
    consume the pending file. Also invoked by the executor as defense-in-depth.
    """
    from decimal import Decimal

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), params["token"], "hypercore", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    current_addr = get_address(testnet=params.get("testnet", False))
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")


def execute_hl_send(params: dict) -> dict:
    """Execute an HL send from proposal params."""
    from regard.core.audit import log_event

    # Defense-in-depth: approve runs the same check pre-claim so a mismatch
    # here indicates a race between validator and executor or a direct caller.
    validate_hl_send_safety(params)

    exchange = get_exchange(params.get("testnet", False))
    dest = params["dest_address"]
    token_name = params.get("sdk_token", params["token"])
    amount = float(params["amount"])

    try:
        resp = exchange.send_asset(dest, "spot", "spot", token_name, amount)
        if resp.get("status") == "err":
            die("venue_error", "SEND_FAILED", resp.get("response", str(resp)), exit_code=4)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SEND_FAILED", str(e), exit_code=4)

    try:
        log_event("executed", command="spot.send", venue="hypercore", to=dest, to_label=params["dest_label"],
                  token=params["token"], amount=params["amount"])
    except Exception as e:
        import sys
        print(f"WARNING: audit log write failed ({e}) — send succeeded", file=sys.stderr)

    return {
        "status": "sent",
        "destination": dest,
        "destination_label": params["dest_label"],
        "token": params["token"],
        "amount": params["amount"],
    }


register_executor("hypercore", "spot.send", execute_hl_send)
register_safety_validator("hypercore", "spot.send", validate_hl_send_safety)


# ---------------------------------------------------------------------------
# Outbound bridges (HL-signed) and perp send — v0.25.0
#
# Three commands sharing the propose/approve flow:
#   hypercore perp bridge arbitrum --to <addr> <amount>     (withdraw_from_bridge)
#   hypercore spot bridge hyperevm --to self <amount> --token <tok>  (send_asset)
#   hypercore perp send <addr> <amount>                     (usd_transfer)
#
# Per Constitution Article VI + V025-IMPLEMENTATION.md locked decisions 1-20.
# ---------------------------------------------------------------------------


def _system_address(token_name: str, info) -> str:
    """Resolve a Core spot token to its HyperEVM system address.

    HYPE short-circuits to the special system contract address. All other
    tokens go through info.spot_meta() to look up the token index, then
    compute "0x20" + token_index.to_bytes(19, "big").hex().

    Per locked decision 9: any non-SystemExit exception from spot_meta()
    must die("venue_error", "SPOT_META_UNAVAILABLE") cleanly — the system
    address requires the index, no fallback exists.
    Per locked decision 19: tokens with `evmContract: None` (unlinked) are
    a separate concern handled by the propose handler, not here.
    """
    from regard.venues.hyperliquid.bridge_constants import HYPE_SYSTEM_ADDRESS

    if token_name.upper() == "HYPE":
        return HYPE_SYSTEM_ADDRESS

    try:
        spot_meta = info.spot_meta()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SPOT_META_UNAVAILABLE",
            f"Could not fetch spot_meta to resolve system address for {token_name}: {e}",
            hint="Retry the propose; if persistent, check Hyperliquid API status.",
            exit_code=4)

    for t in spot_meta.get("tokens", []):
        if t.get("name", "").upper() == token_name.upper():
            idx = t.get("index")
            if idx is None:
                die("venue_error", "SPOT_META_UNAVAILABLE",
                    f"spot_meta entry for {token_name} has no index field",
                    exit_code=4)
            return "0x20" + idx.to_bytes(19, "big").hex()

    die("validation_error", "UNKNOWN_TOKEN",
        f"Token '{token_name}' not found in Hyperliquid spot_meta",
        hint="Check available tokens with: regard hypercore spot-balances")
    return ""  # unreachable, for type checker


def _evm_contract_for_token(token_name: str, info) -> str | None:
    """Return the linked HyperEVM ERC-20 contract address for a Core spot token.

    The HL spot_meta `evmContract` field is a dict
    `{"address": "0x...", "evm_extra_wei_decimals": <int>}`. Returns the
    `address` string, or None if the token has no linked contract
    (`evmContract` is None or the field is missing). Per locked decision 19,
    callers MUST hard-block with BRIDGE_TOKEN_UNLINKED on outbound paths.

    HYPE has no `evmContract` (it's the native gas token, not an ERC-20) —
    callers must short-circuit on `token.upper() == "HYPE"` before consulting
    this helper.
    """
    try:
        spot_meta = info.spot_meta()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SPOT_META_UNAVAILABLE",
            f"Could not fetch spot_meta for token link check: {e}",
            exit_code=4)

    for t in spot_meta.get("tokens", []):
        if t.get("name", "").upper() == token_name.upper():
            evm_contract = t.get("evmContract")
            if evm_contract is None:
                return None
            # Real API: dict with `address` field. Defensive: accept a plain
            # string too (older fixtures, alternate API versions).
            if isinstance(evm_contract, dict):
                return evm_contract.get("address")
            if isinstance(evm_contract, str):
                return evm_contract
            return None
    return None


def _check_dest_native_gas(chain: str, address: str, timeout_s: float = 5.0):
    """Query eth_getBalance on the destination chain RPC.

    Returns balance as Decimal in native units (ETH for arbitrum, HYPE for
    hyperevm), or None on RPC failure / parse error. Outbound callers treat
    None as "couldn't check, don't emit warning."

    Routes through `regard.core.rpc_pool.get_web3` — primary + chainlist
    failover with reputation filtering. The pool dies on hard failures (no
    primary, no failover candidates); we catch and return None so a soft
    warning never blocks an outbound propose. `timeout_s` is unused here
    because the pool's per-endpoint chainId timeout is a wrapper concern.
    """
    from decimal import Decimal

    chain_id = {"arbitrum": 42161, "hyperevm": 999}.get(chain)
    if chain_id is None:
        return None

    try:
        from web3 import Web3

        from regard.core.rpc_pool import get_web3
        w3 = get_web3(chain_id)
        balance_wei = w3.eth.get_balance(Web3.to_checksum_address(address))
        return Decimal(balance_wei) / Decimal(10**18)
    except SystemExit:
        # rpc_pool.get_web3() may die on hard failure; outbound treats this
        # as "couldn't check" and silently omits the warning.
        return None
    except Exception:
        return None


def maybe_dest_no_gas_warning(chain: str, address: str):
    """Outbound soft warning for low destination-side native gas.

    Returns a warnings[] entry dict if the destination is below the warn
    threshold, else None. RPC failures return None silently — outbound
    propose must not block on observability gaps.
    """
    from regard.venues.hyperliquid.bridge_constants import (
        ARB_GAS_WARN_THRESHOLD,
        HYPEREVM_GAS_WARN_THRESHOLD,
    )

    threshold = {
        "arbitrum": ARB_GAS_WARN_THRESHOLD,
        "hyperevm": HYPEREVM_GAS_WARN_THRESHOLD,
    }.get(chain)
    balance = _check_dest_native_gas(chain, address)
    if balance is None or threshold is None:
        return None
    if balance >= threshold:
        return None
    native = "ETH" if chain == "arbitrum" else "HYPE"
    return {
        "type": "BRIDGE_DEST_NO_GAS",
        "message": (
            f"Destination {address} has {balance} {native} on {chain}. "
            f"Bridged tokens will arrive but you may need {native} gas to use them."
        ),
        "balance": str(balance),
        "threshold": str(threshold),
    }


# Per HL docs (hypercore-less-than-greater-than-hyperevm-transfers.md):
# "A transfer from HyperCore to HyperEVM costs 200k gas at the base gas price
# of the next HyperEVM block." Charged in the token being sent (for non-HYPE,
# converted from HYPE-equivalent at the HL oracle rate).
COREEVM_BRIDGE_GAS = 200_000

# Stablecoins that price 1:1 against USD on HL. Other tokens would need
# TOKEN/USDC conversion which we don't model yet — fee estimate returns
# None for them, and the proposal documents the formula instead.
_USD_LINKED_TOKENS = {"USDC", "USDH", "USDT0", "USDE"}

# Quote tokens — when the sent asset is one of these, the activation fee on a
# fresh recipient is denominated in the same token (1 USDC, 1 USDH, etc.). For
# non-quote sends, the activation fee is still 1 quote-token but in some other
# denomination per HL docs — we surface a generic warning instead of an exact
# `recipient_credited` value.
_QUOTE_TOKENS = {"USDC", "USDH", "USDT", "USDT0", "USDE"}


def _is_fresh_hl_user(info, address: str) -> bool:
    """Best-effort check: returns True if `address` has never received HL funds.

    Per HL docs (`activation-gas-fee.md`): "New HyperCore accounts require 1
    quote token (e.g., 1 USDC, 1 USDT, or 1 USDH) of fees for the first
    transaction which has the new account as destination address." A user is
    "fresh" if no spot balances exist AND perp clearinghouse is empty.

    Returns False on any error (conservative: under-warning is better than
    over-warning when the venue API is misbehaving).
    """
    from decimal import Decimal
    try:
        spot = info.spot_user_state(address) or {}
        if spot.get("balances"):
            return False
        cstate = info.post("/info", {"type": "clearinghouseState", "user": address, "dex": ""}) or {}
        withdrawable = Decimal(str(cstate.get("withdrawable", "0") or "0"))
        margin_summary = cstate.get("marginSummary") or {}
        account_value = Decimal(str(margin_summary.get("accountValue", "0") or "0"))
        if withdrawable > 0 or account_value > 0:
            return False
    except Exception:
        return False
    return True


def _estimate_corespot_to_evm_fee(token: str, info, w3_evm):
    """Estimate the HL Core spot → HyperEVM bridge fee.

    Per HL docs: 200k gas × next-block HyperEVM baseFee, charged in the token
    being sent (HYPE: paid in HYPE; others: HYPE-equivalent at oracle rate).

    Returns dict with {fee_token: Decimal, fee_hype: Decimal, basis: str,
    base_fee_wei: int, hype_rate: Decimal | None} on success.
    Returns None if RPC or oracle is unavailable — caller must surface this
    explicitly to the user (do NOT default to a zero-fee projection).
    """
    from decimal import Decimal

    try:
        latest = w3_evm.eth.get_block("latest")
        base_fee_wei = int(latest.get("baseFeePerGas", 0) or 0)
    except Exception:
        return None
    if base_fee_wei <= 0:
        return None

    fee_hype = Decimal(COREEVM_BRIDGE_GAS * base_fee_wei) / Decimal(10**18)

    if token.upper() == "HYPE":
        return {
            "fee_token": fee_hype,
            "fee_hype": fee_hype,
            "base_fee_wei": base_fee_wei,
            "hype_rate": None,
            "basis": (
                f"{COREEVM_BRIDGE_GAS:,} gas × {base_fee_wei} wei "
                f"(HyperEVM next-block baseFee, est)"
            ),
        }

    # Non-HYPE: convert HYPE → token via HL HYPE/USD oracle (info.all_mids).
    # Article II: oracle price arrives as a string from the API; init Decimal
    # via str() defensively in case of future numeric-typed values.
    try:
        mids = info.all_mids()
        hype_rate = Decimal(str(mids.get("HYPE", "0")))
    except Exception:
        return None
    if hype_rate <= 0:
        return None

    if token.upper() in _USD_LINKED_TOKENS:
        fee_token = fee_hype * hype_rate
        return {
            "fee_token": fee_token,
            "fee_hype": fee_hype,
            "base_fee_wei": base_fee_wei,
            "hype_rate": hype_rate,
            "basis": (
                f"{COREEVM_BRIDGE_GAS:,} gas × {base_fee_wei} wei × "
                f"HYPE oracle ${hype_rate}"
            ),
        }

    # Non-USD-linked token: TOKEN/USDC conversion not modelled. Return None
    # so propose disclaims the estimate explicitly.
    return None


# --- Click subapps for bridge subcommands ---

perp_bridge_app = typer.Typer(
    name="bridge",
    no_args_is_help=True,
    help="Move USDC from perp clearinghouse to a different chain.",
    pretty_exceptions_enable=False,
)
spot_bridge_app = typer.Typer(
    name="bridge",
    no_args_is_help=True,
    help="Move spot tokens to a different chain.",
    pretty_exceptions_enable=False,
)


# --- hypercore perp bridge arbitrum ---


@perp_bridge_app.command("arbitrum")
def perp_bridge_arbitrum(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="USDC amount to withdraw to Arbitrum")],
    to: Annotated[str, typer.Option("--to", help="Arbitrum address (0x...) or 'self'")] = "",
):
    """Withdraw USDC from perp clearinghouse to an Arbitrum address.

    Uses Hyperliquid's withdraw3 / Bridge2 contract. $1 fee, 3-5 min finality.
    USDC only (implicit; no --token flag — the bridge accepts only USDC).
    --to self resolves to the current wallet's Arbitrum address (same EOA).
    """
    opts = ctx.obj
    info = get_info(opts["testnet"])

    from regard.commands.address import _validate_checksum, resolve_address
    from regard.core.audit import log_event
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk

    settings_env = load_project_env()

    if not to:
        die("validation_error", "MISSING_DESTINATION",
            "Bridge commands require --to <addr> with no implicit default",
            hint="Use --to self for your own address, or --to <0x... or label>")

    sender_addr = get_address(testnet=opts["testnet"])
    # Per Constitution Article II: amount stays Decimal internally; float() only
    # inline at external SDK call sites.
    from decimal import Decimal
    amt = Decimal(amount)

    # Resolve destination — `self`, address-book label, or raw 0x with --raw-style guard.
    if to == "self":
        dest_address = sender_addr
        dest_label = "SELF"
        recipient_on_hl = sender_addr
    elif to.startswith("0x"):
        if not settings_env.get("SEND_ALLOW_RAW_ADDRESS"):
            die(
                "validation_error", "RAW_ADDRESS_BLOCKED",
                "Raw addresses are disabled. Use a label from the address book or --to self.",
                hint="To enable: set SEND_ALLOW_RAW_ADDRESS=true in settings. Or add the address: regard address add <label> <address> --chain arbitrum",
            )
        dest_address = _validate_checksum(to)
        dest_label = "RAW"
        recipient_on_hl = None  # user-supplied dest; not 'self'
    else:
        dest = resolve_address(to, "arbitrum")
        dest_address = dest["address"]
        dest_label = dest["label"]
        recipient_on_hl = None

    # Safety gates.
    check_amount_cap(amt, "USDC", settings_env)
    check_daily_cap(amt, "USDC", "hypercore", settings_env)
    check_cooldown(dest_address, settings_env)

    # Balance: USDC available for the bridge. The lookup depends on account mode.
    # - Standard mode: USDC lives in the perp clearinghouse; check
    #   `clearinghouseState.withdrawable` (string from HL API).
    # - Unified / portfolioMargin: USDC sits on the spot side of the unified
    #   account; the perp `withdrawable` field reads 0 even when the unified
    #   total has USDC. The underlying `withdraw_from_bridge` SDK call pulls
    #   from the unified clearinghouse regardless, so we must check the right
    #   source. Caught live during Cycle K Test 1 on a unified-mode bonbonki
    #   wallet (2026-05-05).
    # Article II: Decimal initialized from string/int only; no float reentry.
    addr = sender_addr
    try:
        account_mode = get_account_mode(info, addr)
    except Exception:
        account_mode = "standard"

    if account_mode in ("unifiedAccount", "portfolioMargin"):
        try:
            from regard.venues.hyperliquid.client import get_spot_balances
            balances = get_spot_balances(info, addr)
            withdrawable = Decimal(0)
            for b in balances:
                if b.get("token", "").upper() == "USDC":
                    withdrawable = Decimal(str(b.get("balance", "0")))
                    break
        except Exception:
            withdrawable = Decimal(0)
        balance_label = f"unified-account spot USDC ({account_mode} mode)"
    else:
        try:
            state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": ""})
            withdrawable = Decimal(state.get("withdrawable", "0"))
        except Exception:
            withdrawable = Decimal(0)
        balance_label = "perp withdrawable USDC"

    if withdrawable < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"{balance_label} is {withdrawable}, cannot bridge {amt}",
            hint="Some balance may be locked as margin. Check: regard hypercore balance",
            exit_code=4)

    risk = classify_risk(amt, withdrawable)

    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Bridging {amt/withdrawable*100:.0f}% of perp withdrawable USDC"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Bridging {amt/withdrawable*100:.0f}% of perp withdrawable USDC. Approve will require --confirm-addr"})

    # $1 bridge fee notice — agents will pattern-match this in propose output.
    warnings.append({
        "type": "BRIDGE_FEE",
        "message": f"Hyperliquid bridge fee is $1 USDC. Arbitrum will receive {amt - Decimal(1)} USDC.",
    })

    # Soft destination-gas warning.
    gas_warning = maybe_dest_no_gas_warning("arbitrum", dest_address)
    if gas_warning is not None:
        warnings.append(gas_warning)

    params = {
        "sender": sender_addr,
        "dest_address": dest_address,
        "dest_label": dest_label,
        "amount": str(amt),
        "chain": "arbitrum",
        "testnet": opts["testnet"],
    }
    if recipient_on_hl is not None:
        params["recipient_on_hl"] = recipient_on_hl

    checks = {
        "sender": sender_addr,
        "perp_withdrawable": str(withdrawable),
        "projected_perp": str((withdrawable - amt).quantize(Decimal("0.000001"))),
        "fee_usdc": "1",
        "credited_on_arbitrum": str((amt - Decimal(1)).quantize(Decimal("0.000001"))),
        "risk": risk,
    }

    log_event("proposed", command="perp.bridge.arbitrum", venue="hypercore",
              to=dest_address, to_label=dest_label, token="USDC", amount=str(amt), risk=risk)
    proposal = create_proposal("hypercore", "perp.bridge.arbitrum", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_perp_bridge_arbitrum_safety(params: dict) -> None:
    """Re-check safety at approve time (defense-in-depth)."""
    from decimal import Decimal

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), "USDC", "hypercore", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    current_addr = get_address(testnet=params.get("testnet", False))
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")


def execute_perp_bridge_arbitrum(params: dict) -> dict:
    """Execute withdraw_from_bridge from proposal params."""
    from decimal import Decimal

    from regard.core.audit import log_event

    validate_perp_bridge_arbitrum_safety(params)

    exchange = get_exchange(params.get("testnet", False))
    dest = params["dest_address"]
    # Article II: amount stays Decimal; float() inline at the SDK call.
    amount = Decimal(params["amount"])

    try:
        resp = exchange.withdraw_from_bridge(float(amount), dest)
        if resp.get("status") == "err":
            die("venue_error", "BRIDGE_FAILED", resp.get("response", str(resp)), exit_code=4)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "BRIDGE_FAILED", str(e), exit_code=4)

    try:
        log_event("executed", command="perp.bridge.arbitrum", venue="hypercore",
                  to=dest, to_label=params["dest_label"], token="USDC", amount=params["amount"])
    except Exception as e:
        print(f"WARNING: audit log write failed ({e}) — bridge succeeded", file=sys.stderr)

    return {
        "status": "bridged",
        "destination": dest,
        "destination_label": params["dest_label"],
        "chain": "arbitrum",
        "token": "USDC",
        "amount": params["amount"],
        "fee_usdc": "1",
        "credited_amount": str((amount - Decimal(1)).quantize(Decimal("0.000001"))),
        "estimated_finality_minutes": "3-5",
    }


register_executor("hypercore", "perp.bridge.arbitrum", execute_perp_bridge_arbitrum)
register_safety_validator("hypercore", "perp.bridge.arbitrum", validate_perp_bridge_arbitrum_safety)


# --- hypercore spot bridge hyperevm ---


@spot_bridge_app.command("hyperevm")
def spot_bridge_hyperevm(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Token amount to bridge to HyperEVM")],
    to: Annotated[str, typer.Option("--to", help="Must be 'self' (HyperCore->HyperEVM only credits sender)")] = "",
    token: Annotated[str, typer.Option("--token", help="Token name (USDC, HYPE, USDH, ...) — required")] = "",
):
    """Bridge a Core spot token to HyperEVM via send_asset to its system address.

    --to self is the only supported value: HL's send_asset to a system address
    always credits the sender's EVM address (= sender's HL EOA, same EOA).
    Arbitrary recipients require sendToEvmWithData (deferred to a later release).
    """
    opts = ctx.obj
    info = get_info(opts["testnet"])

    from regard.core.audit import log_event
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk

    settings_env = load_project_env()

    if not to:
        die("validation_error", "MISSING_DESTINATION",
            "Bridge commands require --to with no implicit default",
            hint="HyperCore->HyperEVM only supports --to self")

    if to != "self":
        die("validation_error", "BRIDGE_RECIPIENT_NOT_SELF",
            f"hypercore spot bridge hyperevm only credits the sender's own EVM address; got --to '{to}'",
            hint="Use --to self. Arbitrary EVM recipients require sendToEvmWithData (not yet supported).")

    if not token:
        die("validation_error", "MISSING_TOKEN",
            "Must specify --token (e.g. USDC, HYPE, USDH, USDE, USDT0)",
            hint="regard hypercore spot bridge hyperevm --to self <amount> --token USDC")

    # Locked decision 15: normalize token name BEFORE any branching.
    token = token.upper()

    sender_addr = get_address(testnet=opts["testnet"])
    # Article II: amount stays Decimal; float() inline at external SDK boundary.
    from decimal import Decimal
    amt = Decimal(amount)

    # Resolve token: HYPE special case OR linked-ERC-20 hard block.
    if token == "HYPE":
        # HYPE has no ERC-20 (native gas token on EVM); system address is fixed.
        sdk_token = "HYPE"
    else:
        # Locked decision 19: hard-block unlinked tokens.
        evm_contract = _evm_contract_for_token(token, info)
        if evm_contract is None:
            die("validation_error", "BRIDGE_TOKEN_UNLINKED",
                f"Token {token} has no linked HyperEVM ERC-20 contract. "
                f"Sending it via send_asset to its system address would irrecoverably lose the funds.",
                hint="Pick a linked token (USDC, HYPE, USDH, USDE, USDT0, PURR), or wait for the token to be linked.")
        # Resolve SDK token name (canonical name plain; non-canonical needs name:tokenId).
        try:
            spot_meta = info.spot_meta()
        except SystemExit:
            raise
        except Exception as e:
            die("venue_error", "SPOT_META_UNAVAILABLE",
                f"Could not fetch spot_meta to resolve SDK token name for {token}: {e}",
                exit_code=4)
        sdk_token = token
        for t in spot_meta.get("tokens", []):
            if t.get("name", "").upper() == token:
                if not t.get("isCanonical", False):
                    sdk_token = f"{t['name']}:{t['tokenId']}"
                else:
                    sdk_token = t["name"]
                break

    # Compute system address (also dies cleanly on spot_meta failure).
    system_addr = _system_address(token, info)

    # Spot balance check. HL spot balance values arrive as strings; use
    # Decimal directly. Defensive str() in case a future API revision returns
    # numeric types — Article II forbids Decimal(float_var).
    try:
        from regard.venues.hyperliquid.client import get_spot_balances
        balances = get_spot_balances(info, sender_addr)
        balance = Decimal(0)
        for b in balances:
            if b.get("token", "").upper() == token:
                balance = Decimal(str(b.get("balance", "0")))
                break
    except Exception:
        balance = Decimal(0)

    if balance < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"Spot {token} balance ({balance}) less than bridge amount ({amt})",
            exit_code=4)

    # Safety gates.
    check_amount_cap(amt, token, settings_env)
    check_daily_cap(amt, token, "hypercore", settings_env)
    check_cooldown(system_addr, settings_env)

    risk = classify_risk(amt, balance)

    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Bridging {amt/balance*100:.0f}% of spot {token} balance"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Bridging {amt/balance*100:.0f}% of spot {token} balance. Approve will require --confirm-addr"})

    # Soft destination-gas warning.
    gas_warning = maybe_dest_no_gas_warning("hyperevm", sender_addr)
    if gas_warning is not None:
        warnings.append(gas_warning)

    # Bridge fee disclosure (per HL docs: 200k gas × next-block HyperEVM
    # baseFee, charged in the token being sent at HYPE oracle rate). This is
    # critical for fintech accuracy — silent under-disclosure would leave
    # users with unexplained balance deltas after execution.
    fee_estimate = None
    try:
        from regard.core.rpc_pool import get_web3 as _rpc_pool_get_web3
        w3_evm = _rpc_pool_get_web3(999)
        fee_estimate = _estimate_corespot_to_evm_fee(token, info, w3_evm)
    except SystemExit:
        # rpc_pool may die on hard failure; treat as "estimate unavailable"
        # so the proposal still goes through with explicit disclaimer.
        fee_estimate = None
    except Exception:
        fee_estimate = None

    params = {
        "sender": sender_addr,
        "dest_address": system_addr,
        "dest_label": f"HYPEREVM_SYSTEM_{token}",
        "recipient_on_hl": sender_addr,  # user's HL EOA — used by CRITICAL gate (locked decision 18)
        "recipient_on_evm": sender_addr,  # same EOA on HyperEVM
        "token": token,
        "sdk_token": sdk_token,
        "amount": str(amt),
        "chain": "hyperevm",
        "testnet": opts["testnet"],
    }
    checks = {
        "sender": sender_addr,
        "system_address": system_addr,
        "spot_balance": str(balance),
        "risk": risk,
    }

    if fee_estimate is not None:
        fee_token = fee_estimate["fee_token"].quantize(Decimal("0.000001"))
        projected = (balance - amt - fee_token).quantize(Decimal("0.000001"))
        checks["bridge_fee_estimate"] = str(fee_token)
        checks["bridge_fee_basis"] = fee_estimate["basis"]
        checks["bridge_fee_note"] = (
            "Actual fee is computed at execution time from the next-block "
            "HyperEVM baseFee; estimate is current baseFee × HYPE oracle."
        )
        checks["projected_spot"] = str(projected)
        if projected < 0:
            warnings.append({
                "type": "BRIDGE_FEE_INSUFFICIENT_BALANCE",
                "message": (
                    f"Estimated bridge fee ({fee_token} {token}) exceeds "
                    f"remaining balance after amount ({balance - amt} {token}). "
                    f"Bridge will likely fail at execution."
                ),
                "fee_estimate": str(fee_token),
                "remaining_after_amount": str((balance - amt).quantize(Decimal("0.000001"))),
            })
    else:
        # Estimator unavailable (RPC down, non-USD-linked token, oracle
        # missing). Be explicit — do not silently project a zero-fee balance.
        checks["bridge_fee_estimate"] = "unavailable"
        checks["bridge_fee_basis"] = (
            f"{COREEVM_BRIDGE_GAS:,} gas × HyperEVM next-block baseFee "
            f"(charged in {token} at HYPE oracle rate)"
        )
        checks["bridge_fee_note"] = (
            "Could not estimate fee (RPC or oracle unavailable). Actual fee "
            "will be deducted at execution time per HL docs."
        )
        checks["projected_spot"] = str(
            (balance - amt).quantize(Decimal("0.000001"))
        ) + " (excludes unestimated bridge fee)"

    log_event("proposed", command="spot.bridge.hyperevm", venue="hypercore",
              to=system_addr, to_label=f"HYPEREVM_SYSTEM_{token}", token=token, amount=str(amt), risk=risk)
    proposal = create_proposal("hypercore", "spot.bridge.hyperevm", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_spot_bridge_hyperevm_safety(params: dict) -> None:
    """Re-check safety at approve time."""
    from decimal import Decimal

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), params["token"], "hypercore", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    current_addr = get_address(testnet=params.get("testnet", False))
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")


def execute_spot_bridge_hyperevm(params: dict) -> dict:
    """Execute send_asset to system address from proposal params."""
    from decimal import Decimal

    from regard.core.audit import log_event

    validate_spot_bridge_hyperevm_safety(params)

    exchange = get_exchange(params.get("testnet", False))
    dest = params["dest_address"]
    sdk_token = params["sdk_token"]
    # Article II: amount stays Decimal; float() inline at the SDK call.
    amount = Decimal(params["amount"])

    try:
        resp = exchange.send_asset(dest, "spot", "spot", sdk_token, float(amount))
        if resp.get("status") == "err":
            die("venue_error", "BRIDGE_FAILED", resp.get("response", str(resp)), exit_code=4)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "BRIDGE_FAILED", str(e), exit_code=4)

    try:
        log_event("executed", command="spot.bridge.hyperevm", venue="hypercore",
                  to=dest, to_label=params["dest_label"], token=params["token"], amount=params["amount"])
    except Exception as e:
        print(f"WARNING: audit log write failed ({e}) — bridge succeeded", file=sys.stderr)

    return {
        "status": "bridged",
        "destination": dest,
        "destination_label": params["dest_label"],
        "recipient_on_evm": params["recipient_on_evm"],
        "chain": "hyperevm",
        "token": params["token"],
        "amount": params["amount"],
    }


register_executor("hypercore", "spot.bridge.hyperevm", execute_spot_bridge_hyperevm)
register_safety_validator("hypercore", "spot.bridge.hyperevm", validate_spot_bridge_hyperevm_safety)


# --- hypercore perp send ---


@perp_app.command("send")
def perp_send(
    ctx: typer.Context,
    addr: Annotated[str, typer.Argument(help="Address book label, or raw 0x address with --raw")],
    amount: Annotated[str, typer.Argument(help="USDC amount")],
    raw: Annotated[bool, typer.Option("--raw", help="Treat addr as a raw 0x address (requires SEND_ALLOW_RAW_ADDRESS)")] = False,
):
    """Send USDC from perp clearinghouse to another HL user's perp clearinghouse.

    Same-chain user-to-user. USDC only (no --token flag). Uses the existing
    usd_transfer SDK method, mirroring spot send's pattern.
    """
    opts = ctx.obj

    from regard.commands.address import _validate_checksum, resolve_address
    from regard.core.audit import log_event
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk

    settings_env = load_project_env()

    if raw:
        if not settings_env.get("SEND_ALLOW_RAW_ADDRESS"):
            die(
                "validation_error", "RAW_ADDRESS_BLOCKED",
                "Raw addresses are disabled. Use a label from the address book.",
                hint="To enable: set SEND_ALLOW_RAW_ADDRESS=true in settings. Or add the address: regard address add <label> <address>",
            )
        dest_address = _validate_checksum(addr)
        dest_label = "RAW"
    elif addr.startswith("0x"):
        die(
            "validation_error", "RAW_ADDRESS_BLOCKED",
            "Raw 0x addresses require --raw and SEND_ALLOW_RAW_ADDRESS=true.",
            hint="Add a label: regard address add <label> <address>, or pass --raw",
        )
    else:
        dest = resolve_address(addr, "hypercore")
        dest_address = dest["address"]
        dest_label = dest["label"]

    sender_addr = get_address(testnet=opts["testnet"])
    # Article II: amount stays Decimal; float() inline at external SDK boundary.
    from decimal import Decimal
    amt = Decimal(amount)

    if sender_addr.lower() == dest_address.lower():
        die("validation_error", "SELF_SEND", "Cannot send to yourself",
            hint="Pick a different label or address")

    # Safety gates.
    check_amount_cap(amt, "USDC", settings_env)
    check_daily_cap(amt, "USDC", "hypercore", settings_env)
    check_cooldown(dest_address, settings_env)

    info = get_info(opts["testnet"])

    # HL disables the `usd_transfer` action when the account is in
    # unifiedAccount or portfolioMargin mode (verified live 2026-05-06: HL
    # returns `"Action disabled when unified account is active"`). Hard-block
    # at propose so the user never approves a doomed proposal — point them
    # at `hypercore spot send` which works for all account modes.
    try:
        account_mode = get_account_mode(info, sender_addr)
    except Exception:
        account_mode = "standard"

    if account_mode in ("unifiedAccount", "portfolioMargin"):
        die("validation_error", "PERP_SEND_DISABLED_UNIFIED_MODE",
            f"hypercore perp send is disabled by HL when account_mode is "
            f"'{account_mode}'. The usd_transfer SDK action returns "
            f"'Action disabled when unified account is active' at execution.",
            hint=f"Use 'regard hypercore spot send {dest_label or '<label>'} {amt} --token USDC' instead — spot send works for both standard and unified accounts.")

    # Standard mode: read perp clearinghouse withdrawable directly.
    # Article II: Decimal-only, no float reentry.
    try:
        state = info.post("/info", {"type": "clearinghouseState", "user": sender_addr, "dex": ""})
        withdrawable = Decimal(str(state.get("withdrawable", "0")))
    except Exception:
        withdrawable = Decimal(0)

    if withdrawable < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"perp withdrawable USDC is {withdrawable}, cannot send {amt}",
            hint="Some balance may be locked as margin. Check: regard hypercore balance",
            exit_code=4)

    risk = classify_risk(amt, withdrawable)

    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Sending {amt/withdrawable*100:.0f}% of perp withdrawable USDC"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Sending {amt/withdrawable*100:.0f}% of perp withdrawable USDC. Approve will require --confirm-addr"})

    params = {
        "sender": sender_addr,
        "dest_address": dest_address,
        "dest_label": dest_label,
        "amount": str(amt),
        "testnet": opts["testnet"],
    }
    checks = {
        "sender": sender_addr,
        "perp_withdrawable": str(withdrawable),
        "projected_perp": str((withdrawable - amt).quantize(Decimal("0.000001"))),
        "risk": risk,
    }

    log_event("proposed", command="perp.send", venue="hypercore",
              to=dest_address, to_label=dest_label, token="USDC", amount=str(amt), risk=risk)
    proposal = create_proposal("hypercore", "perp.send", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_perp_send_safety(params: dict) -> None:
    """Re-check safety at approve time."""
    from decimal import Decimal

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), "USDC", "hypercore", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    current_addr = get_address(testnet=params.get("testnet", False))
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")


def execute_perp_send(params: dict) -> dict:
    """Execute usd_transfer (perp user-to-user USDC) from proposal params."""
    from decimal import Decimal

    from regard.core.audit import log_event

    validate_perp_send_safety(params)

    exchange = get_exchange(params.get("testnet", False))
    dest = params["dest_address"]
    # Article II: amount stays Decimal; float() inline at the SDK call.
    amount = Decimal(params["amount"])

    try:
        resp = exchange.usd_transfer(float(amount), dest)
        if resp.get("status") == "err":
            die("venue_error", "SEND_FAILED", resp.get("response", str(resp)), exit_code=4)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SEND_FAILED", str(e), exit_code=4)

    try:
        log_event("executed", command="perp.send", venue="hypercore",
                  to=dest, to_label=params["dest_label"], token="USDC", amount=params["amount"])
    except Exception as e:
        print(f"WARNING: audit log write failed ({e}) — send succeeded", file=sys.stderr)

    return {
        "status": "sent",
        "destination": dest,
        "destination_label": params["dest_label"],
        "token": "USDC",
        "amount": params["amount"],
    }


register_executor("hypercore", "perp.send", execute_perp_send)
register_safety_validator("hypercore", "perp.send", validate_perp_send_safety)


# Wire bridge subapps onto perp_app and spot_app.
perp_app.add_typer(perp_bridge_app, name="bridge")
spot_app.add_typer(spot_bridge_app, name="bridge")


@hypercore_app.command()
def preflight(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    side: Annotated[str, typer.Argument(help="buy/long or sell/short")],
    size: Annotated[str, typer.Argument(help="Size to check")],
    sl: Annotated[str | None, typer.Option("--sl", help="Planned stop loss price")] = None,
):
    """Pre-trade risk check: margin, leverage, liq price, position sizing, warnings."""
    opts = ctx.obj

    side_lower = side.lower()
    if side_lower not in SIDE_MAP:
        die("validation_error", "INVALID_SIDE", f"Invalid side: {side}", hint="Use buy/long or sell/short", param="side")

    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)
    addr = get_address()
    dex = get_dex_for_coin(resolved)
    is_buy = SIDE_MAP[side_lower]
    idx = 0 if is_buy else 1

    # Get active asset data (max trade sizes, available margin)
    asset_data = get_active_asset_data(info, addr, resolved)

    result = {
        "asset": resolved,
        "dex": dex or "default",
        "side": side_lower,
        "requested_size": size,
    }

    warnings = []

    if asset_data:
        max_szs = asset_data.get("maxTradeSzs", ["0", "0"])
        avail = asset_data.get("availableToTrade", ["0", "0"])
        mark_px = float(asset_data.get("markPx", "0"))
        lev_info = asset_data.get("leverage", {})
        lev_value = lev_info.get("value", 1)
        lev_type = lev_info.get("type", "cross")

        result["mark_px"] = asset_data.get("markPx", "")
        result["leverage"] = lev_info
        result["max_size"] = max_szs[idx]
        result["available_to_trade"] = avail[idx]
        result["can_trade"] = float(max_szs[idx]) >= float(size)

        # --- Risk metrics ---
        sz = float(size)

        # Notional exposure
        notional = sz * mark_px
        result["notional"] = round(notional, 2)

        # Equity — for unified accounts, use total account value (includes spot),
        # not dex-specific balance which is misleadingly small.
        try:
            acct_mode = get_account_mode(info, addr)
            if acct_mode == "unifiedAccount":
                state = info.user_state(addr)
            else:
                dex_name = dex or ""
                state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex_name})
            margin = state.get("marginSummary", state.get("crossMarginSummary", {}))
            equity = float(margin.get("accountValue", "0"))
            result["equity"] = round(equity, 2)
            if equity > 0:
                notional_pct = (notional / equity) * 100
                result["notional_pct"] = round(notional_pct, 1)
                if notional_pct > 50:
                    warnings.append({
                        "code": "HIGH_NOTIONAL",
                        "message": f"{notional_pct:.1f}% of equity in one trade (${notional:.2f} / ${equity:.2f})",
                    })
        except Exception:
            pass

        # Margin required (approximate)
        if lev_value > 0:
            result["margin_required"] = round(notional / lev_value, 2)

        # Liquidation price estimate (isolated only — cross liq depends on full portfolio)
        if mark_px > 0 and lev_value > 0:
            if lev_type == "isolated":
                if is_buy:
                    liq_est = mark_px * (1 - 1 / lev_value)
                else:
                    liq_est = mark_px * (1 + 1 / lev_value)
                result["liq_price_est"] = round(liq_est, 6)
            else:
                result["liq_price_est"] = None  # cross: depends on portfolio

        # Stop loss analysis
        if sl is not None:
            sl_px = float(sl)
            result["stop_price"] = sl
            max_loss = sz * abs(mark_px - sl_px)
            result["max_loss"] = round(max_loss, 2)

            # Check liq vs stop
            liq_est = result.get("liq_price_est")
            if liq_est is not None:
                if is_buy and liq_est > sl_px:
                    safe_lev = max(1, int(mark_px / (mark_px - sl_px * 0.95)))
                    warnings.append({
                        "code": "LIQ_ABOVE_STOP",
                        "message": f"Liquidation at {liq_est:.6g} — any stop below that will never trigger (yours: {sl_px:.6g})",
                        "liq_price": liq_est,
                        "suggested_leverage": safe_lev,
                    })
                elif not is_buy and liq_est < sl_px:
                    safe_lev = max(1, int(mark_px / (sl_px * 1.05 - mark_px)))
                    warnings.append({
                        "code": "LIQ_BELOW_STOP",
                        "message": f"Liquidation at {liq_est:.6g} — any stop above that will never trigger (yours: {sl_px:.6g})",
                        "liq_price": liq_est,
                        "suggested_leverage": safe_lev,
                    })
    else:
        result["can_trade"] = False
        result["error"] = "Could not fetch asset data"

    # If can't trade on HIP-3, check dex balance
    if not result.get("can_trade") and dex:
        try:
            dex_state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex})
            dex_margin = dex_state.get("marginSummary", dex_state.get("crossMarginSummary", {}))
            dex_val = dex_margin.get("accountValue", "0")
            result["dex_balance"] = dex_val
            if float(dex_val) == 0:
                result["recovery"] = {
                    "action": "transfer_funds",
                    "dex": dex,
                    "command": f"regard hypercore perp transfer dex {dex} <amount>",
                }
        except Exception:
            pass

    # Existing position check
    try:
        all_pos = get_all_positions(info, addr)
        for pos in all_pos:
            if pos["coin"] == resolved:
                pos_size = float(pos["szi"])
                result["existing_position"] = {
                    "side": "long" if pos_size > 0 else "short",
                    "size": abs(pos_size),
                    "entry_px": pos.get("entryPx", ""),
                    "unrealized_pnl": pos.get("unrealizedPnl", ""),
                    "liq_price": pos.get("liquidationPx", ""),
                }
                warnings.append({
                    "code": "EXISTING_POSITION",
                    "message": f"Already {'long' if pos_size > 0 else 'short'} {abs(pos_size)} {resolved} from {pos.get('entryPx', '?')}",
                })
                # Liq-vs-stop on existing position (cross margin has real liq price)
                if sl is not None:
                    warnings.extend(_check_liq_vs_stop(pos, float(sl), pos_size > 0))
                break
    except Exception:
        pass

    result["warnings"] = warnings

    # Build display
    lines = [f"Preflight: {side_lower} {size} {resolved}"]
    lines.append(f"  Mark price     {result.get('mark_px', '?')}")
    lev = result.get("leverage", {})
    if lev:
        lines.append(f"  Leverage       {lev.get('value', '?')}x {lev.get('type', '')}")
    lines.append(f"  Can trade      {'yes' if result.get('can_trade') else 'NO'}")
    if "notional" in result:
        lines.append(f"  Notional       ${result['notional']}")
    if "equity" in result:
        lines.append(f"  Equity         ${result['equity']}")
    if "notional_pct" in result:
        lines.append(f"  Exposure       {result['notional_pct']}% of equity")
    if "margin_required" in result:
        lines.append(f"  Margin req     ${result['margin_required']}")
    if result.get("liq_price_est") is not None:
        lines.append(f"  Liq price est  {result['liq_price_est']:.6g}")
    elif result.get("liq_price_est") is None and lev.get("type") == "cross":
        lines.append("  Liq price est  n/a (cross margin — depends on portfolio)")
    if sl is not None:
        lines.append(f"  Stop loss      {sl}")
    if "max_loss" in result:
        lines.append(f"  Max loss       ${result['max_loss']}")
    if result.get("existing_position"):
        ep = result["existing_position"]
        lines.append(f"  Existing pos   {ep['side']} {ep['size']} @ {ep['entry_px']}")
    if warnings:
        lines.append("")
        for w in warnings:
            lines.append(f"  ⚠ {w['code']}: {w['message']}")
            if "suggested_leverage" in w:
                lines.append(f"    → Suggested leverage: {w['suggested_leverage']}x")
    result["display"] = "\n".join(lines)

    output(result, opts["fields"])
