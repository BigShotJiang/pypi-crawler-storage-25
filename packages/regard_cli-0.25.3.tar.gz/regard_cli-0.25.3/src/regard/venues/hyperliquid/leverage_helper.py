"""Hyperliquid leverage helpers for the tilt detector's ratchet signal.

Wraps `info.user_state(addr)` with graceful degradation. Returns a dict mapping
asset name → current leverage (as a float). Used by the leverage-ratchet
detector to snapshot leverage state into `<project>/.regard/tilt_session.json`
on each tilt() invocation; ratchet is detected by comparing the current
snapshot to the earliest one in the session window.

The HL position `leverage` field is polymorphic in the API
(`{"type": "cross", "value": 10}` or int or str); this helper normalizes
to a float.
"""

from __future__ import annotations

import contextlib
import io


def _coerce_leverage(raw) -> float:
    """Normalize the polymorphic HL leverage field to a positive float.

    Handles:
      - {"type": "cross"|"isolated", "value": <num>}
      - int / float
      - numeric string ("10", "5.5")

    Returns 0.0 on any failure — caller treats 0 as "no leverage signal,"
    not as "1× leverage."
    """
    if isinstance(raw, dict):
        return _coerce_leverage(raw.get("value", 0))
    try:
        f = float(raw)
        return f if f > 0 else 0.0
    except (TypeError, ValueError):
        return 0.0


def fetch_current_leverage(*, testnet: bool = False) -> dict[str, float]:
    """Return {asset: leverage_float} for the trading wallet's open positions.

    Includes default perps and HIP-3 dexes (per `get_all_positions`).
    Returns `{}` on any failure — missing wallet, network down, SDK error.
    Mirrors the graceful-degradation pattern of `trades_history.py`.
    """
    # `get_address()` writes auth-error JSON to stdout via die() before
    # raising SystemExit on missing wallet; the catch below absorbs the
    # exit but not the bytes. Redirect stdout for the wrap so the
    # envelope is discarded — see `trades_history.fetch_recent_fills`
    # for full rationale.
    try:
        from regard.venues.hyperliquid.client import (
            get_address,
            get_all_positions,
            get_info,
        )
        with contextlib.redirect_stdout(io.StringIO()):
            info = get_info(testnet)
            addr = get_address()
            positions = get_all_positions(info, addr)
    except (Exception, SystemExit):
        return {}

    out: dict[str, float] = {}
    if not isinstance(positions, list):
        return {}
    for p in positions:
        if not isinstance(p, dict):
            continue
        coin = p.get("coin", "")
        if not coin:
            continue
        lev = _coerce_leverage(p.get("leverage", 0))
        if lev > 0:
            # If the same asset appears across dexes, keep the highest leverage
            out[coin] = max(out.get(coin, 0.0), lev)
    return out


def detect_leverage_ratchet(
    history: dict[str, list[dict]],
    current: dict[str, float],
    *,
    threshold: float = 5.0,
    ratchet_multiplier: float = 1.5,
) -> tuple[bool, list[str]]:
    """Detect within-session leverage ratchet across all assets.

    `history` is the per-asset snapshot list from
    `tilt_session_state.load_leverage_history()` — each entry is
    `{"ts": iso, "lev": float}`. `current` is the live leverages from
    `fetch_current_leverage()`.

    An asset shows a ratchet when:
      - It has at least one historical snapshot (i.e., we have something to
        compare against; first-ever snapshot can't be a ratchet).
      - Its current leverage exceeds `threshold` (filtering out ordinary
        low-leverage activity from triggering the signal).
      - Its current leverage is `ratchet_multiplier`× greater than the
        earliest leverage in the session window (e.g., 2× → 5× = 2.5x ratio).

    Returns `(any_ratchet, [list_of_descriptions])`. Descriptions are
    human-readable and used in the indicator string.
    """
    descriptions: list[str] = []
    for asset, lev_now in current.items():
        if lev_now < threshold:
            continue
        snapshots = history.get(asset, [])
        if not snapshots:
            continue
        # Use earliest in session as the baseline — that's the start of the
        # ratchet path. If user opened BTC at 2× and is now at 10×, baseline=2.
        earliest = snapshots[0].get("lev", 0)
        if earliest <= 0:
            continue
        if lev_now / earliest >= ratchet_multiplier:
            descriptions.append(
                f"{asset} {earliest:g}x → {lev_now:g}x"
            )
    return (bool(descriptions), descriptions)
