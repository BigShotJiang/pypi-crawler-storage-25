"""HIP-4 encoding, parsing, and order validation — pure logic, no I/O.

HIP-4 outcomes use a different API representation from spot AND perps. The
same `(outcome, side)` pair appears in three forms across the API:

- `#<encoding>` — `/info` `l2Book`, `Exchange.order(...)`, WebSocket subs
- `+<encoding>` — `spotClearinghouseState` balance entries
- `100_000_000 + encoding` — internal asset references requiring an integer

Where `encoding = 10 * outcome + side` and `side` is 0 (YES) or 1 (NO).

Mixing them silently fails: querying `l2Book` with `+59150` returns nothing,
looking up balances with `#59150` finds nothing. This module is the single
source of truth so callers never construct these by hand. See the brief at
`thoughts/research/2026-05-04_hip-4-implementation-brief.md` §3 for the
full encoding spec and the `#10`/`#11` UX gotcha (outcome 1's two sides).

Order validation per brief §6 lives in `validate_outcome_order` —
client-side enforcement of the matching engine's constraints (price
range, tick alignment, integer size, min notional).
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation

ASSET_ID_BASE = 100_000_000
SIDE_YES = 0
SIDE_NO = 1

# Trading constraints from brief §6. Server-enforced but client-side
# rejection per Constitution Article II ("MUST reject, never silently
# truncate") prevents wasted server roundtrips and gives the agent a
# structured error code at propose time.
OUTCOME_PRICE_MIN = Decimal("0.001")
OUTCOME_PRICE_MAX = Decimal("0.999")
OUTCOME_PRICE_TICK_DEFAULT = Decimal("0.0001")
OUTCOME_MIN_NOTIONAL_USDH = Decimal("10")
# Upper size bound — Decimal accepts arbitrarily large finite values
# (`Decimal("1e500")` is finite and integer). Without a ceiling, scientific
# notation slips past the size guards and the client emits a "valid"
# proposal that the server rejects as insufficient balance — the agent
# sees a misleading "pending" instead of a structured validation error.
# Aligned with Article I's stated rationale (IEEE-754 precision loss past
# ~15 sig digits) so the cap matches what we already trust elsewhere.
OUTCOME_MAX_SIZE = Decimal("1e15")


def _check_side(side: int) -> None:
    if side not in (SIDE_YES, SIDE_NO):
        raise ValueError(f"side must be 0 (YES) or 1 (NO), got {side!r}")


def _check_outcome(outcome: int) -> None:
    if not isinstance(outcome, int) or isinstance(outcome, bool) or outcome < 0:
        raise ValueError(f"outcome must be a non-negative integer, got {outcome!r}")


def encode_coin(outcome: int, side: int) -> str:
    """`#<encoding>` — used in l2Book queries and Exchange.order()."""
    _check_outcome(outcome)
    _check_side(side)
    return f"#{10 * outcome + side}"


def encode_balance_coin(outcome: int, side: int) -> str:
    """`+<encoding>` — used in spotClearinghouseState balance entries."""
    _check_outcome(outcome)
    _check_side(side)
    return f"+{10 * outcome + side}"


def encode_asset_id(outcome: int, side: int) -> int:
    """`100_000_000 + encoding` — integer asset reference."""
    _check_outcome(outcome)
    _check_side(side)
    return ASSET_ID_BASE + 10 * outcome + side


def _is_ascii_decimal_no_leading_zero(body: str) -> bool:
    """True iff `body` is non-empty ASCII digits with no leading zero.

    Tightens the discriminator beyond `str.isdigit()`, which is True for
    Unicode digit categories like superscript `²` (U+00B2). Without this
    guard, `decode_coin('#²')` would pass the digit check, then `int(body)`
    raises `ValueError` and the caller's `is None` check misses it,
    propagating an internal_error (exit 7) instead of validation_error
    (exit 2). Article IV exit-code consistency requires the latter.

    Also rejects leading zeros (`'010'`) so `#10` and `#010` aren't
    silent aliases — the help text already documents "no leading zeros".
    """
    if not body:
        return False
    if not body.isascii() or not body.isdigit():
        return False
    if len(body) > 1 and body[0] == "0":
        return False
    return True


def decode_coin(coin: str) -> tuple[int, int] | None:
    """Reverse `#<encoding>` to `(outcome, side)`.

    Returns `None` for any non-outcome coin: missing `#` prefix, empty
    body, non-ASCII-digit body (e.g. Unicode superscripts), or a body
    with a leading zero (`#010` is rejected so it cannot silently alias
    `#10`). Safe to call against any coin string — the resolver uses
    this as a discriminator between outcome / spot / perp coins.
    """
    if not isinstance(coin, str) or not coin.startswith("#"):
        return None
    body = coin[1:]
    if not _is_ascii_decimal_no_leading_zero(body):
        return None
    return divmod(int(body), 10)


def decode_balance_coin(coin: str) -> tuple[int, int] | None:
    """Reverse `+<encoding>` to `(outcome, side)`. Same contract as decode_coin."""
    if not isinstance(coin, str) or not coin.startswith("+"):
        return None
    body = coin[1:]
    if not _is_ascii_decimal_no_leading_zero(body):
        return None
    return divmod(int(body), 10)


class OutcomeValidationError(ValueError):
    """Raised by `validate_outcome_order` on a client-side rejection.

    Carries `code` (matches the CLI error code so the caller can
    `die(...)` directly without re-classifying), `message`, and an
    optional `hint`. Subclassing ValueError lets callers also catch
    via `except (Exception, SystemExit)` patterns elsewhere without
    touching this module.
    """

    def __init__(self, code: str, message: str, hint: str | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.hint = hint


def _to_decimal_or_raise(value, field: str, code: str) -> Decimal:
    """Strict Decimal parse — rejects non-string, non-finite, non-numeric.

    `Decimal('NaN')` and `Decimal('Infinity')` are valid Decimal
    constructions but never represent a tradeable price/size. Reject
    them at the boundary so downstream arithmetic doesn't propagate
    NaN. Article II: silent NaN-poisoning is the failure mode the
    constitution explicitly forbids.
    """
    if isinstance(value, bool) or not isinstance(value, (str, int, Decimal)):
        raise OutcomeValidationError(code, f"{field} must be a numeric string, got {value!r}")
    try:
        d = Decimal(str(value)) if isinstance(value, int) else Decimal(value)
    except (InvalidOperation, TypeError):
        raise OutcomeValidationError(code, f"{field} must be a numeric string, got {value!r}") from None
    if not d.is_finite():
        raise OutcomeValidationError(code, f"{field} must be finite, got {value}")
    return d


def validate_outcome_order(
    size: str,
    price: str | None = None,
    *,
    tick: Decimal = OUTCOME_PRICE_TICK_DEFAULT,
    min_notional: Decimal = OUTCOME_MIN_NOTIONAL_USDH,
) -> None:
    """Validate an outcome order's size + price per brief §6.

    Always runs:
    - Size MUST parse as a positive integer Decimal (>0, no fraction).
      Raises `OutcomeValidationError("OUTCOME_SIZE_NON_INTEGER", ...)`.

    Limit orders only (price is not None):
    - Price MUST be in `[0.001, 0.999]` (raises `OUTCOME_PRICE_OUT_OF_RANGE`).
    - Price MUST be a multiple of `tick` (raises `OUTCOME_TICK_VIOLATION`).
    - Notional `size * price` MUST be >= `min_notional` USDH
      (raises `OUTCOME_MIN_NOTIONAL`).

    Market orders (price is None) skip price/tick/notional — the matching
    engine validates against the current top-of-book at fill time. Size
    integer check still applies.

    Article II: every failure raises, NEVER silently truncates. The
    caller (`act.py:order()`) translates the error to `die(...)` with
    the carried code.
    """
    d_size = _to_decimal_or_raise(size, "size", "OUTCOME_SIZE_NON_INTEGER")
    if d_size <= 0:
        raise OutcomeValidationError(
            "OUTCOME_SIZE_NON_INTEGER",
            f"Outcome size must be a positive integer, got {size}",
            hint="HIP-4 requires integer size (1, 27, 1024, ...) — fractions and zero/negative are rejected",
        )
    if d_size != d_size.to_integral_value():
        raise OutcomeValidationError(
            "OUTCOME_SIZE_NON_INTEGER",
            f"Outcome size must be a positive integer, got {size}",
            hint="HIP-4 requires integer size — round to a whole number (1, 27, 1024, ...) before submitting",
        )
    # Upper bound (Decimal accepts arbitrary finite magnitudes; reject
    # operationally-impossible values before the server does).
    if d_size > OUTCOME_MAX_SIZE:
        raise OutcomeValidationError(
            "OUTCOME_SIZE_NON_INTEGER",
            f"Outcome size {size} exceeds maximum {OUTCOME_MAX_SIZE}",
            hint="HIP-4 size capped at 1e15 contracts — likely a typo or scientific notation; use plain integer",
        )

    if price is None:
        return  # market order — server-side validates the rest

    d_price = _to_decimal_or_raise(price, "price", "OUTCOME_PRICE_OUT_OF_RANGE")
    if not (OUTCOME_PRICE_MIN <= d_price <= OUTCOME_PRICE_MAX):
        raise OutcomeValidationError(
            "OUTCOME_PRICE_OUT_OF_RANGE",
            f"Outcome price {price} out of range [{OUTCOME_PRICE_MIN}, {OUTCOME_PRICE_MAX}]",
            hint="HIP-4 prices are probabilities — must be in [0.001, 0.999] (server clamps the rest)",
        )

    # Tick alignment — price / tick must be an integer Decimal. Use
    # remainder-based check (`% tick`) over division to avoid Decimal's
    # context precision artifacts on long quotients.
    remainder = d_price % tick
    if remainder != 0:
        raise OutcomeValidationError(
            "OUTCOME_TICK_VIOLATION",
            f"Outcome price {price} is not a multiple of tick {tick}",
            hint=f"Round to a multiple of {tick} (e.g. 0.4561, 0.4562 — not 0.45605)",
        )

    notional = d_size * d_price
    if notional < min_notional:
        # Compute the minimum integer size for this price so the hint
        # gives the agent a recovery action, not just a rejection.
        # Use ceil-equivalent via integral rounding upward; cast to int
        # to avoid Decimal's scientific-notation formatting (`2E+1` vs `20`).
        min_size_int = int((min_notional / d_price).to_integral_value(rounding="ROUND_CEILING"))
        raise OutcomeValidationError(
            "OUTCOME_MIN_NOTIONAL",
            f"Outcome notional {notional} USDH (size {size} × price {price}) is below the {min_notional} USDH minimum",
            hint=f"Increase size to at least {min_size_int} at this price, or raise price",
        )


_DESCRIPTION_KEYS = {
    "class": "class",
    "underlying": "underlying",
    "expiry": "expiry",
    "targetPrice": "target_price",  # camelCase in API → snake_case in our model
    "period": "period",
}


def parse_description(desc: str) -> dict[str, str | None]:
    """Parse the pipe-separated `key:value|...` outcome description.

    Returns a dict with these keys (None when missing or input malformed):
    `class`, `underlying`, `expiry`, `target_price`, `period`.

    `target_price` is kept as a string — financial values stay strings
    end-to-end per Constitution Article I. Unknown keys (future protocol
    additions) are ignored, never raised.
    """
    out: dict[str, str | None] = {v: None for v in _DESCRIPTION_KEYS.values()}
    if not isinstance(desc, str) or not desc:
        return out
    for part in desc.split("|"):
        if ":" not in part:
            continue
        key, _, value = part.partition(":")
        mapped = _DESCRIPTION_KEYS.get(key.strip())
        if mapped is not None:
            out[mapped] = value.strip()
    return out


def parse_expiry(expiry: str | None):
    """Parse outcomeMeta's `expiry` (e.g. `20260505-0600`) to a UTC datetime.

    Returns None for missing, malformed, or impossibly-shaped input.
    Format observed on mainnet: `YYYYMMDD-HHMM` (UTC, four-digit year /
    two-digit month / two-digit day, hyphen, four-digit time HHMM).
    """
    from datetime import datetime, timezone

    if not isinstance(expiry, str) or not expiry:
        return None
    body = expiry.strip()
    if len(body) != 13 or body[8] != "-":
        return None
    if not body[:8].isdigit() or not body[9:].isdigit():
        return None
    try:
        return datetime.strptime(body, "%Y%m%d-%H%M").replace(tzinfo=timezone.utc)
    except ValueError:
        return None
