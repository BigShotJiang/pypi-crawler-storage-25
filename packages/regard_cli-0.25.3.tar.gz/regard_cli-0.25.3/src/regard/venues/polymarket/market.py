"""Market resolution — resolve identifiers to Polymarket market data."""

import json
import re

import httpx
from pydantic import ValidationError

from regard.venues.polymarket.models import GammaMarket


def compute_fee(notional: float, price: float, fee_schedule: dict | None) -> float:
    """Polymarket taker fee: notional * rate * price^exp * (1-price)^exp.

    Returns 0.0 when fee_schedule is None/empty (fee-exempt market) or when
    price is at the 0/1 boundary where the formula degenerates.
    """
    if not fee_schedule:
        return 0.0
    try:
        rate = float(fee_schedule.get("rate", 0.0))
        exponent = int(fee_schedule.get("exponent", 1))
    except (TypeError, ValueError):
        return 0.0
    if price <= 0.0 or price >= 1.0:
        return 0.0
    return notional * rate * (price**exponent) * ((1.0 - price) ** exponent)


def fee_rate_pct(price: float, fee_schedule: dict | None) -> float | None:
    """Effective fee rate at this price as a fraction of notional (e.g. 0.018 for 1.8%).

    Returns None when fee-exempt. Useful for display so callers don't repeat
    the price^exp * (1-price)^exp factor.
    """
    if not fee_schedule:
        return None
    try:
        rate = float(fee_schedule.get("rate", 0.0))
        exponent = int(fee_schedule.get("exponent", 1))
    except (TypeError, ValueError):
        return None
    if price <= 0.0 or price >= 1.0:
        return 0.0
    return rate * (price**exponent) * ((1.0 - price) ** exponent)

# Stop words excluded from the free-text word-overlap score. Without this
# filter, any query whose only shared token is "will" or "the" silently
# resolves to an unrelated high-volume market — which is a MONEY-PATH risk
# because `poly order` calls this same resolver when an identifier isn't a
# clean slug/id/condition-id.
_STOP_WORDS = frozenset({
    "a", "an", "the",
    "and", "or", "but", "nor",
    "be", "am", "is", "are", "was", "were", "been", "being",
    "do", "does", "did", "doing",
    "will", "would", "can", "could", "shall", "should", "may", "might", "must",
    "have", "has", "had", "having",
    "of", "in", "on", "at", "to", "from", "by", "for", "with", "about",
    "as", "into", "through", "over", "between",
    "this", "that", "these", "those",
    "it", "its",
    "not", "no",
})

# Minimum required word-overlap for a free-text resolution:
#   - 1-word queries: ≥1 shared word (the only token must match)
#   - 2+-word queries: ≥2 shared words (a single incidental match from a
#     4-word fake slug like "unknown-slug-xyz-does-not-exist" must not
#     resolve to the aliens market just because both contain "exist").
def _required_score(query_word_count: int) -> int:
    return min(2, query_word_count)


def _validate_gamma(data):
    try:
        GammaMarket.model_validate(data)
    except ValidationError:
        pass


def resolve_market(identifier: str, gamma: httpx.Client) -> dict | None:
    """Resolve a market by condition ID, market ID, slug, or question substring.

    Returns a normalized MarketInfo dict or None if not found.
    """
    # Try by condition ID (0x...)
    if identifier.startswith("0x"):
        resp = gamma.get("/markets", params={"condition_id": identifier})
        markets = resp.json()
        if markets:
            return _normalize(markets[0] if isinstance(markets, list) else markets)

    # Try by numeric market ID
    if identifier.isdigit():
        try:
            resp = gamma.get(f"/markets/{identifier}")
            if resp.status_code == 200:
                return _normalize(resp.json())
        except Exception:
            pass

    # Try by slug
    resp = gamma.get("/markets", params={"slug": identifier})
    markets = resp.json()
    if markets:
        return _normalize(markets[0] if isinstance(markets, list) else markets)

    # Fallback: search by question text via local word-overlap against the
    # top markets by volume. Gamma's `q=` parameter is unreliable (returns
    # completely unrelated markets regardless of query — empirically `q=Hezbollah`
    # returns GTA VI and NHL markets). Mirrors `poly markets` which also filters
    # client-side for the same reason. Tradeoff: caps discovery at top-N by
    # volume, but low-volume markets are better looked up by slug or ID anyway.
    #
    # Stop words are stripped from the query before scoring. This is a
    # MONEY-PATH guard: `poly order` uses this resolver, so a mistyped slug
    # that overlaps with a high-volume market only on words like "will" /
    # "the" must not silently resolve to that market.
    query_words = set(re.findall(r"\w+", identifier.lower())) - _STOP_WORDS
    if not query_words:
        return None

    required = _required_score(len(query_words))
    resp = gamma.get(
        "/markets",
        params={"limit": 500, "order": "volume24hr", "ascending": "false", "active": "true", "closed": "false"},
    )
    markets = resp.json()
    if markets:
        best: tuple[int, dict] | None = None
        for m in markets:
            question = (m.get("question", "") or "").lower()
            slug = (m.get("slug", "") or "").lower()
            question_words = (
                (set(re.findall(r"\w+", question)) | set(re.findall(r"\w+", slug)))
                - _STOP_WORDS
            )
            score = len(query_words & question_words)
            if score >= required and (best is None or score > best[0]):
                best = (score, m)
        if best is not None:
            return _normalize(best[1])

    return None


def _normalize(m: dict) -> dict:
    """Normalize a Gamma API market response to a standard shape."""
    _validate_gamma(m)
    raw_clob = m.get("clobTokenIds", "[]")
    clob_ids = json.loads(raw_clob) if isinstance(raw_clob, str) else (raw_clob or [])
    raw_prices = m.get("outcomePrices", "[]")
    outcome_prices = json.loads(raw_prices) if isinstance(raw_prices, str) else (raw_prices or [])

    return {
        "market_id": m.get("id", ""),
        "condition_id": m.get("conditionId", ""),
        "question": m.get("question", ""),
        "slug": m.get("slug", ""),
        "yes_token_id": clob_ids[0] if len(clob_ids) > 0 else "",
        "no_token_id": clob_ids[1] if len(clob_ids) > 1 else "",
        "yes_price": float(outcome_prices[0]) if len(outcome_prices) > 0 else 0.0,
        "no_price": float(outcome_prices[1]) if len(outcome_prices) > 1 else 0.0,
        "active": m.get("active", False),
        "closed": m.get("closed", False),
        "accepting_orders": m.get("acceptingOrders", "false").lower() == "true" if isinstance(m.get("acceptingOrders"), str) else bool(m.get("acceptingOrders", False)),
        "neg_risk": m.get("negRisk", "false").lower() == "true" if isinstance(m.get("negRisk"), str) else bool(m.get("negRisk", False)),
        "volume_24h": float(m.get("volume24hr", 0) or 0),
        "volume": float(m.get("volumeNum", 0) or 0),
        "liquidity": float(m.get("liquidityNum", 0) or 0),
        "end_date": m.get("endDateIso", ""),
        "best_bid": m.get("bestBid", ""),
        "best_ask": m.get("bestAsk", ""),
        "min_order_size": float(m.get("orderMinSize", 5) or 5),
        "tick_size": float(m.get("orderPriceMinTickSize", 0.01) or 0.01),
        "fees_enabled": bool(m.get("feesEnabled", False)),
        "fee_type": m.get("feeType") or "",
        "fee_schedule": m.get("feeSchedule") or None,
    }
