"""Cross-venue parity finder — match HL HIP-4 outcomes to Polymarket equivalents.

HIP-4's BTC daily binary asks "Will BTC be above $X at 06:00 UTC?". Polymarket
has its own bitcoin price markets — sometimes phrased identically, more often
adjacent ("Bitcoin Up or Down today?", "Bitcoin to hit $X by Y?"). This module
makes a *best-effort* match using a manual underlying→keywords map, end-date
proximity, and word-overlap scoring against active markets.

Returns `None` when no defensible match is found. Match quality is reported in
the response so the caller can decide how much to trust the spread.

Out of scope:
- Reverse direction (Polymarket → HL). HL has a single mainnet outcome per
  underlying at launch; the asymmetry doesn't justify the abstraction yet.
- Fuzzy time window for non-binary HL markets (categoricals — Phase 4).
- Side mapping (assumes HL YES ↔ Polymarket YES; flip if a found market has
  inverted phrasing — caller responsibility today, automated mapping later).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from regard.venues.hyperliquid.outcomes import parse_expiry

# Manual underlying → search keywords map. Keep narrow to avoid false-positive
# themed matches (e.g. mapping "BTC" to "crypto" would pull in altcoin markets).
# Add entries when a new HIP-4 asset class lands.
_UNDERLYING_KEYWORDS: dict[str, tuple[str, ...]] = {
    "BTC": ("bitcoin", "btc"),
    "ETH": ("ethereum", "eth"),
    "SOL": ("solana", "sol"),
    "HYPE": ("hyperliquid", "hype"),
}

# How much can Polymarket's `endDateIso` differ from HL's expiry before we stop
# considering the market a parity candidate? HIP-4 BTC binary settles 06:00
# UTC daily; Polymarket equivalents typically use 23:59 UTC end-of-day. ±36h
# captures both the same-day and next-day phrasing variants without dragging
# in unrelated weekly/monthly markets.
_EXPIRY_WINDOW_HOURS = 36


def _score_market(
    market: dict[str, Any],
    keywords: tuple[str, ...],
    target_price: str | None,
) -> int:
    """Heuristic score: keyword presence + target-price hit. Higher = better."""
    haystack = (
        (market.get("question") or "").lower()
        + " "
        + (market.get("slug") or "").lower()
    )
    score = 0
    for kw in keywords:
        if kw in haystack:
            score += 2
    # Bonus when the HL target price (e.g. "79980" or "80000") shows up in the
    # market question or slug. Polymarket commonly formats prices three ways:
    #   raw "80000"      — slugs like "bitcoin-above-80000-may-5"
    #   formatted "80,000" — questions like "Will Bitcoin be above $80,000 …"
    #   abbreviated "80k"  — questions like "Bitcoin to 80k by …"
    # Each form is checked independently. Peer-review v0.23.3 ratchet:
    # the prior `,{rounded_k:03d}` check produced ",080" for 80k strikes —
    # never matched. Replaced with the canonical `f"{price_int:,}"` form.
    if target_price:
        try:
            price_int = int(Decimal(target_price))
            raw = str(price_int)
            formatted = f"{price_int:,}"  # "80,000"
            if raw in haystack:
                score += 3
            # Avoid double-counting prices < 1000 where formatted == raw.
            if formatted != raw and formatted in haystack:
                score += 3
            rounded_k = price_int // 1000
            if rounded_k > 0 and f"{rounded_k}k" in haystack:
                score += 1
        except Exception:
            pass
    return score


def find_polymarket_equivalent(
    hl_outcome: dict[str, Any],
    gamma_client,
    *,
    expiry_window_hours: int = _EXPIRY_WINDOW_HOURS,
) -> dict[str, Any] | None:
    """Best-effort match an HL outcome to a Polymarket market.

    Args:
        hl_outcome: An outcome record from `resolver.get_outcomes()` with
            `parsed_description` containing `underlying`, `expiry`, `target_price`.
        gamma_client: An httpx client from `polymarket.client.get_gamma_client()`.
        expiry_window_hours: Max hours between HL expiry and Polymarket end_date
            for a market to count as a candidate.

    Returns:
        Dict shaped:
            {
              "market_id": str,
              "slug": str,
              "question": str,
              "yes_price": str,         # Article I — string, not float
              "no_price": str,
              "end_date": str,
              "match_quality": "exact" | "themed" | "fuzzy",
              "score": int,
              "spread_yes": str,        # |hl_yes_mid - pm_yes_price| if both present
              "spread_no": str,
            }
        or None when no defensible match exists.
    """
    parsed = (hl_outcome or {}).get("parsed_description") or {}
    underlying = (parsed.get("underlying") or "").upper()
    if not underlying:
        return None
    keywords = _UNDERLYING_KEYWORDS.get(underlying)
    if not keywords:
        return None

    expiry_dt = parse_expiry(parsed.get("expiry"))
    if expiry_dt is None:
        # Without a comparable HL expiry we can't enforce the date gate;
        # falling through would let any active same-underlying market be
        # returned as "parity" — better to acknowledge the gap than to
        # mislead. Peer-review v0.23.3 ratchet: aligns code with the
        # function's stated intent ("better to return None than mislead").
        return None
    target_price = parsed.get("target_price")

    # Pull a wide top-by-volume slice of active markets and filter locally.
    # Mirrors market.py's resolver pattern — Gamma's `q=` is unreliable, so
    # we score client-side. Cap at 500 to bound the network call.
    try:
        resp = gamma_client.get(
            "/markets",
            params={
                "limit": 500,
                "order": "volume24hr",
                "ascending": "false",
                "active": "true",
                "closed": "false",
            },
        )
        markets = resp.json()
    except Exception:
        return None
    if not isinstance(markets, list):
        return None

    from datetime import datetime, timezone
    candidates: list[tuple[int, dict[str, Any]]] = []
    for m in markets:
        # End-date proximity gate. Skip markets without parsable end_date or
        # outside the window.
        end_iso = m.get("endDateIso") or m.get("endDate") or ""
        try:
            end_dt = datetime.fromisoformat(str(end_iso).replace("Z", "+00:00"))
            if end_dt.tzinfo is None:
                end_dt = end_dt.replace(tzinfo=timezone.utc)
        except Exception:
            continue
        if abs((end_dt - expiry_dt).total_seconds()) > expiry_window_hours * 3600:
            continue
        score = _score_market(m, keywords, target_price)
        # Require at least one keyword hit (score ≥ 2) for a candidate.
        if score >= 2:
            candidates.append((score, m))

    if not candidates:
        return None

    candidates.sort(key=lambda x: -x[0])
    best_score, best = candidates[0]

    # Quality tier from score:
    #   exact  — keyword hit + target-price hit (>= 5)
    #   themed — keyword hit only (2-4)
    #   fuzzy  — single keyword without target (this branch never fires given
    #            the score>=2 gate, but kept for callers that lower the gate)
    if best_score >= 5:
        quality = "exact"
    elif best_score >= 2:
        quality = "themed"
    else:
        quality = "fuzzy"

    yes_price = best.get("outcomePrices") or "[]"
    if isinstance(yes_price, str):
        import json as _json
        try:
            yes_price = _json.loads(yes_price)
        except Exception:
            yes_price = []
    if not isinstance(yes_price, list) or len(yes_price) < 2:
        return None

    pm_yes = str(yes_price[0])
    pm_no = str(yes_price[1])

    # `spread_yes` / `spread_no` are initialized as empty strings so the
    # response shape matches the docstring contract. The CLI command in
    # `research.py:outcome` overwrites both when HL mids are available;
    # callers without HL data still see the keys and can treat empty as
    # "spread not computed" (peer-review v0.23.3 ratchet).
    return {
        "market_id": str(best.get("id", "")),
        "condition_id": str(best.get("conditionId", "")),
        "slug": best.get("slug", ""),
        "question": best.get("question", ""),
        "yes_price": pm_yes,
        "no_price": pm_no,
        "end_date": best.get("endDateIso") or best.get("endDate") or "",
        "match_quality": quality,
        "score": best_score,
        "spread_yes": "",
        "spread_no": "",
    }
