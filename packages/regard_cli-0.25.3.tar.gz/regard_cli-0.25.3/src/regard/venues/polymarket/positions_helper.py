"""Polymarket positions helper for the tilt detector.

Wraps `get_positions()` with graceful degradation: any failure (no wallet,
geo-block, network, SDK exception) returns `[]` rather than raising. Mirrors
`venues/hyperliquid/trades_history.py` design.

Also provides the long-shot detection logic — positions priced ≤ threshold
without a corresponding thesis logged in the prior 24h. Thesis check scans
`<project>/gg/research/*.md` and recent `gg/handoffs/*.md` for the market
title (case-insensitive substring match).
"""

from __future__ import annotations

import contextlib
import io
import time
from pathlib import Path


def fetch_polymarket_positions() -> list[dict]:
    """Fetch current Polymarket positions, graceful on any failure.

    Each entry: {asset_id, market, side, size, avg_price, cur_price, pnl,
    condition_id, outcome}. Numeric fields are strings per the existing
    contract — caller coerces as needed.
    """
    # `get_positions()` calls `get_address()` → `_get_key()` → `die()`
    # on missing wallet, which writes auth-error JSON to stdout before
    # raising SystemExit. The catch below absorbs the exit but not the
    # bytes — see `regard.venues.hyperliquid.trades_history.fetch_recent_fills`
    # for full rationale. Redirect stdout to discard the envelope cleanly.
    try:
        from regard.venues.polymarket.client import get_positions
        with contextlib.redirect_stdout(io.StringIO()):
            positions = get_positions()
    except (Exception, SystemExit):
        return []
    if not isinstance(positions, list):
        return []
    return positions


def _market_mentioned_in_file(path: Path, needle: str) -> bool:
    """Case-insensitive substring check. Returns False on read errors."""
    try:
        return needle in path.read_text(encoding="utf-8", errors="ignore").lower()
    except OSError:
        return False


def has_recent_thesis(
    market_title: str,
    project_dir: Path,
    *,
    max_age_seconds: int = 24 * 3600,
    min_title_length: int = 4,
) -> bool:
    """True if `market_title` appears in any recent gg/ markdown file.

    Searches:
      - `<project>/gg/research/*.md` (any age — research is presumed durable)
      - `<project>/gg/handoffs/*.md` modified within `max_age_seconds`

    Match is case-insensitive substring on the market title. Very short
    titles (< `min_title_length` chars) are rejected to avoid spurious
    matches like "BTC" against any document mentioning Bitcoin.

    Returns False on any I/O issue or missing project — defaults to "no
    thesis," which is the safer state for a tilt-warning signal.
    """
    if not market_title:
        return False
    title_clean = market_title.strip().lower()
    if len(title_clean) < min_title_length:
        return False

    cutoff_mtime = time.time() - max_age_seconds

    research_dir = project_dir / "gg" / "research"
    if research_dir.is_dir():
        for md in research_dir.glob("*.md"):
            if _market_mentioned_in_file(md, title_clean):
                return True

    handoffs_dir = project_dir / "gg" / "handoffs"
    if handoffs_dir.is_dir():
        for md in handoffs_dir.glob("*.md"):
            try:
                if md.stat().st_mtime < cutoff_mtime:
                    continue
            except OSError:
                continue
            if _market_mentioned_in_file(md, title_clean):
                return True

    return False


def count_unguarded_longshots(
    positions: list[dict],
    project_dir: Path | None,
    *,
    longshot_threshold: float = 0.05,
) -> int:
    """Count Polymarket positions priced ≤ threshold with no logged thesis.

    A position counts as "long-shot" if its current price is at-or-below
    the threshold (default 5¢ → ≤5% implied probability). It counts as
    "unguarded" if the user has not logged a thesis mentioning the
    market title in the prior 24h (handoffs) or any time (research docs).

    Returns 0 when project_dir is None (no thesis layer to check) — caller
    treats that as "skip the signal" rather than "all long-shots count."
    The whole point of this signal is the *thesis vs evidence* mismatch;
    without a thesis layer to check, the signal can't fire honestly.
    """
    if project_dir is None or not positions:
        return 0
    n = 0
    for p in positions:
        try:
            cur_price = float(p.get("cur_price", "") or 0)
        except (TypeError, ValueError):
            continue
        if cur_price <= 0 or cur_price > longshot_threshold:
            continue
        market = p.get("market", "")
        if not has_recent_thesis(market, project_dir):
            n += 1
    return n
