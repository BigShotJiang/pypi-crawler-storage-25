"""Pydantic models for Polymarket API response shapes.

These models validate the seam between raw Polymarket API responses and
regard-cli's internal domain. They use extra="ignore" so the CLI never crashes
when the API adds a new field. Tests validate with extra="forbid" to catch
schema drift.

Three APIs: Gamma (market/event data), CLOB (orders/balance), Data API (positions).
"""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, ConfigDict, field_validator, model_validator

# --- Shared config ---

_API_CONFIG = ConfigDict(extra="ignore")


# --- Data API: positions ---

class DataApiPosition(BaseModel):
    """A single position from the Data API /positions endpoint."""
    model_config = _API_CONFIG

    size: float | str | None = None
    asset: str = ""
    title: str = ""
    slug: str = ""
    avgPrice: str | float | None = None
    curPrice: str | float | None = None
    cashPnl: str | float | None = None
    initialValue: float | None = None
    currentValue: float | None = None
    percentPnl: float | None = None
    totalBought: int | float | None = None
    realizedPnl: float | None = None
    percentRealizedPnl: float | None = None
    conditionId: str = ""
    outcome: str = ""
    outcomeIndex: int | None = None
    oppositeOutcome: str = ""
    oppositeAsset: str = ""
    redeemable: bool = False
    mergeable: bool = False
    proxyWallet: str = ""
    icon: str = ""
    eventId: str = ""
    eventSlug: str = ""
    endDate: str = ""
    negativeRisk: bool = False


# --- Gamma API: markets ---

class GammaMarket(BaseModel):
    """A market object from the Gamma API.

    Several fields are polymorphic — the API returns either a JSON string or
    a native list/bool depending on the endpoint and market state.
    """
    model_config = _API_CONFIG

    id: str | int = ""
    conditionId: str = ""
    question: str = ""
    slug: str = ""
    clobTokenIds: list[str] | str | None = None
    outcomePrices: list[str | float] | str | None = None
    active: bool = False
    closed: bool = False
    acceptingOrders: bool | str = False
    negRisk: bool | str = False
    volume24hr: float | str | None = None
    volumeNum: float | str | None = None
    liquidityNum: float | str | None = None
    endDateIso: str = ""
    bestBid: str | float | None = ""
    bestAsk: str | float | None = ""
    orderMinSize: float | str | None = None
    orderPriceMinTickSize: float | str | None = None
    feesEnabled: bool = False
    feeType: str | None = None
    feeSchedule: dict | None = None

    @field_validator("clobTokenIds", mode="before")
    @classmethod
    def parse_clob_token_ids(cls, v: Any) -> list[str] | str | None:
        if isinstance(v, str):
            try:
                return json.loads(v)
            except (json.JSONDecodeError, TypeError):
                return v
        return v

    @field_validator("outcomePrices", mode="before")
    @classmethod
    def parse_outcome_prices(cls, v: Any) -> list[str | float] | str | None:
        if isinstance(v, str):
            try:
                return json.loads(v)
            except (json.JSONDecodeError, TypeError):
                return v
        return v


# --- Gamma API: events ---

class GammaEvent(BaseModel):
    """An event object from the Gamma API /events endpoint."""
    model_config = _API_CONFIG

    id: str | int = ""
    title: str = ""
    slug: str = ""
    markets: list[GammaMarket] = []


# --- CLOB API: orders ---

class ClobTrade(BaseModel):
    """A trade from clob.get_trades()."""
    model_config = _API_CONFIG

    id: str = ""
    taker_order_id: str = ""
    market: str = ""
    asset_id: str = ""
    side: str = ""
    size: str = ""
    fee_rate_bps: str = ""
    price: str = ""
    status: str = ""
    match_time: str = ""
    last_update: str = ""
    outcome: str = ""
    bucket_index: int | None = None
    owner: str = ""
    maker_address: str = ""
    transaction_hash: str = ""
    maker_orders: list = []
    trader_side: str = ""


class ClobOrderBook(BaseModel):
    """Response from clob.get_order_book()."""
    model_config = _API_CONFIG

    market: str = ""
    asset_id: str = ""
    timestamp: str = ""
    hash: str = ""
    bids: list[dict] = []
    asks: list[dict] = []
    min_order_size: str = ""
    tick_size: str = ""
    neg_risk: bool = False
    last_trade_price: str = ""


class ClobOrder(BaseModel):
    """An open order from clob.get_open_orders()."""
    model_config = _API_CONFIG

    id: str = ""
    market: str = ""
    asset_id: str = ""
    side: str = ""
    price: str = ""
    original_size: str = ""
    size_matched: str = ""
    status: str = ""
    created_at: str | int | None = None
    owner: str = ""
    maker_address: str = ""
    outcome: str = ""
    expiration: str = ""
    order_type: str = ""
    associate_trades: list = []


# --- CLOB API: order response ---

class ClobOrderResponse(BaseModel):
    """Response from clob.post_order() or clob.create_market_order().

    Order ID field is polymorphic: "orderID" or "id".
    """
    model_config = _API_CONFIG

    success: bool | None = None
    errorMsg: str | None = None
    status: str | None = None
    orderID: str | None = None
    id: str | None = None

    @model_validator(mode="after")
    def check_order_id_on_success(self) -> ClobOrderResponse:
        if self.success and not (self.orderID or self.id):
            raise ValueError("successful order response has no order ID (neither orderID nor id)")
        return self


# --- CLOB API: balance ---

class ClobBalanceAllowance(BaseModel):
    """Response from clob.get_balance_allowance()."""
    model_config = _API_CONFIG

    balance: str = "0"
    allowances: dict[str, Any] | None = None
