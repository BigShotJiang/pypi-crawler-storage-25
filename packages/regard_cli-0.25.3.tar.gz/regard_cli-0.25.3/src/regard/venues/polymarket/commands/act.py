"""Act commands — approve, order, cancel, cancel-all, redeem, merge.

Trading and protocol surface lives under `polymarket_app`. Chain-level
Polygon operations (USDC ↔ USDC.e ↔ pUSD compartment shifts, ERC-20 sends)
live under `polygon_app` per CLI Constitution Article VI.
"""

from typing import Annotated

import typer

from regard.core.output import die, output
from regard.core.proposal import create_proposal, register_executor, register_safety_validator
from regard.venues.polymarket.client import (
    CONTRACTS,
    CTF_ABI,
    ERC20_ABI,
    OFFRAMP_ABI,
    ONRAMP_ABI,
    TOKEN_NAMES,
    check_geo_block,
    ctf_merge,
    ctf_redeem,
    get_bridge_asset_spec,
    get_bridge_deposit_addresses,
    get_clob_client,
    get_collateral_token,
    get_gamma_client,
    get_positions,
    get_web3,
    poll_bridge_status,
)
from regard.venues.polymarket.main import polygon_app, polymarket_app
from regard.venues.polymarket.market import compute_fee, resolve_market

# ---------------------------------------------------------------------------
# Polygon chain command tree (Constitution Article VI):
#
# regard polygon usdc  transfer usdce <amount>      (Bridge API)
# regard polygon usdce transfer pusd  <amount>      (Collateral Onramp)
# regard polygon pusd  transfer usdce <amount>      (Collateral Offramp)
# regard polygon send  <addr> <amount> --token <t>  (ERC-20 / native)
#
# Each `<asset> transfer <other-asset>` form is a same-chain compartment
# shift, expressed as nested typer subapps so the source asset lives in the
# command path (no `--from` flag).
# ---------------------------------------------------------------------------

polygon_usdc_app = typer.Typer(
    name="usdc",
    no_args_is_help=True,
    help="Polygon native USDC (0x3c499c...) — source compartment.",
    pretty_exceptions_enable=False,
)
polygon_usdce_app = typer.Typer(
    name="usdce",
    no_args_is_help=True,
    help="Polygon legacy bridged USDC.e — source compartment.",
    pretty_exceptions_enable=False,
)
polygon_pusd_app = typer.Typer(
    name="pusd",
    no_args_is_help=True,
    help="Polymarket pUSD (CTF collateral, post-V2 era) — source compartment.",
    pretty_exceptions_enable=False,
)

polygon_usdc_transfer_app = typer.Typer(
    name="transfer",
    no_args_is_help=True,
    help="Move funds out of the Polygon USDC compartment.",
    pretty_exceptions_enable=False,
)
polygon_usdce_transfer_app = typer.Typer(
    name="transfer",
    no_args_is_help=True,
    help="Move funds out of the Polygon USDC.e compartment.",
    pretty_exceptions_enable=False,
)
polygon_pusd_transfer_app = typer.Typer(
    name="transfer",
    no_args_is_help=True,
    help="Move funds out of the Polymarket pUSD compartment.",
    pretty_exceptions_enable=False,
)


def _wire_polygon_tree() -> None:
    """Idempotently attach the polygon subapp tree.

    Called at module import time. Polygon command modules (this one) and the
    main.py registration both reference `polygon_app`; wiring lives here so
    the tree definition stays co-located with the commands.
    """
    polygon_usdc_app.add_typer(polygon_usdc_transfer_app, name="transfer")
    polygon_usdce_app.add_typer(polygon_usdce_transfer_app, name="transfer")
    polygon_pusd_app.add_typer(polygon_pusd_transfer_app, name="transfer")
    polygon_app.add_typer(polygon_usdc_app, name="usdc")
    polygon_app.add_typer(polygon_usdce_app, name="usdce")
    polygon_app.add_typer(polygon_pusd_app, name="pusd")


_wire_polygon_tree()

SIDE_MAP = {"buy": "BUY", "sell": "SELL"}
MAX_UINT256 = 2**256 - 1


def _classify_poly_clob_error(err_msg: str) -> tuple[str, str | None]:
    """Map CLOB error strings / error codes to stable CLI codes + optional hints.

    CLOB's order-placement response uses `{success: false, errorMsg: "..."}` at
    HTTP 200. `errorMsg` is sometimes a documented error code (e.g.
    `INVALID_ORDER_NOT_ENOUGH_BALANCE`) and sometimes free-form prose. We match
    both. Cancel endpoints return `{canceled: [], not_canceled: {oid: reason}}`
    — same classifier applies to the per-order reason strings there.

    Grown reactively as production sessions surface new patterns. Raw message
    is always preserved in the outer `message` field; only `code` is refined.

    Returns `(code, hint)`. `hint=None` when the code is self-explanatory.
    """
    lower = err_msg.lower()
    # Documented CLOB error codes (from trading/orders/overview docs)
    if "invalid_order_not_enough_balance" in lower or "not enough balance" in lower:
        return ("INSUFFICIENT_BALANCE",
                "Fund the wallet (`regard polygon usdc transfer usdce <amount>`) or wrap USDC.e (`regard polygon usdce transfer pusd <amount>`).")
    if "invalid_order_min_size" in lower or "below the minimum" in lower:
        return ("ORDER_BELOW_MIN_SIZE",
                "Polymarket minimum order size is 5 shares (verify per-market).")
    if "invalid_order_min_tick_size" in lower or "tick size" in lower:
        return ("TICK_SIZE_VIOLATION",
                "Price must be a multiple of the market's tick size.")
    if "invalid_order_duplicated" in lower:
        return ("ORDER_DUPLICATED", None)
    if "invalid_order_expiration" in lower:
        return ("ORDER_EXPIRED", None)
    if "invalid_post_only_order_type" in lower:
        return ("POST_ONLY_ON_TAKER", None)
    if "invalid_post_only_order" in lower:
        return ("POST_ONLY_CROSSES_BOOK", None)
    if "fok_order_not_filled" in lower:
        return ("FOK_UNFILLED",
                "FOK order could not be fully filled at the quoted size.")
    if "market_not_ready" in lower:
        return ("MARKET_NOT_READY", None)
    if "order_delayed" in lower:
        return ("ORDER_DELAYED", None)
    if "execution_error" in lower:
        return ("EXECUTION_ERROR", None)
    # Tight GEO matching — avoid false positives on order IDs containing "403"
    # or prose like "operation restricted to admin". Only match Polymarket's
    # known geo-block phrasing and HTTP 403 appearing as a bare status token.
    if ("geo-restricted" in lower
            or "not available in your region" in lower
            or "geoblocked" in lower
            or err_msg.strip().startswith("403 ")
            or err_msg.strip() == "403"):
        return ("GEO_BLOCKED",
                "Polymarket order placement is geo-restricted; connect from a non-restricted jurisdiction.")
    if "not found" in lower or "unknown order" in lower:
        return ("ORDER_NOT_FOUND", None)
    # Unclassified — stable fallback. Raw message preserved in outer `message`.
    return ("ORDER_REJECTED", None)


def _extract_order_ids(canceled: list) -> list[str]:
    """Extract order IDs from a canceled[] response list.

    CLOB docs show flat strings across all SDK examples, but shapes drift over
    time — newer SDKs sometimes wrap IDs in `{order_id: "0x..."}` envelopes.
    Extract uniformly so a future shape change doesn't silently break cancels.
    """
    ids: list[str] = []
    for item in canceled:
        if isinstance(item, str):
            ids.append(item)
        elif isinstance(item, dict):
            for key in ("order_id", "orderID", "id", "orderId"):
                if key in item and isinstance(item[key], str):
                    ids.append(item[key])
                    break
    return ids


def _validate_poly_precision(size: float, price: float | None, tick_size: float):
    """Reject orders with excess precision. Constitution Article II.

    Polymarket shares are whole numbers. Prices must be multiples of tick_size.
    Silent rounding is a correctness violation — reject instead.
    """
    from decimal import Decimal

    if size % 1 != 0:
        die("validation_error", "PRECISION_EXCEEDED",
            f"Size must be a whole number of shares, got {size}",
            param="size", exit_code=2)

    if price is not None:
        d_price = Decimal(str(price))
        d_tick = Decimal(str(tick_size))
        if d_tick > 0 and d_price % d_tick != 0:
            die("validation_error", "PRECISION_EXCEEDED",
                f"Price {price} is not a multiple of tick size {tick_size}",
                param="price", exit_code=2)


@polymarket_app.command()
def approve(ctx: typer.Context):
    """Approve USDC and CTF tokens for Polymarket contracts. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    params = {}
    proposal = create_proposal("polymarket", "approve", params, {}, [])
    output(proposal, opts["fields"])


def execute_poly_approve(params: dict) -> dict:
    """Execute on-chain Polymarket approvals from proposal params."""
    from regard.venues.polymarket.client import _get_key, get_address

    key = _get_key()
    if not key.startswith("0x"):
        key = f"0x{key}"
    address = get_address()

    w3 = get_web3()
    try:
        w3.eth.block_number  # verify connectivity (is_connected uses web3_clientVersion which eRPC blocks)
    except Exception:
        die("network_error", "RPC_UNREACHABLE", "Cannot connect to Polygon RPC",
            hint="Set POLYGON_RPC env var to a working RPC URL", exit_code=6)

    account = w3.eth.account.from_key(key)
    checksummed = w3.to_checksum_address(address)

    collateral = get_collateral_token(w3)
    collateral_addr = collateral["address"]
    collateral_name = collateral["name"]

    usdc = w3.eth.contract(address=w3.to_checksum_address(collateral_addr), abi=ERC20_ABI)
    ctf = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["CTF"]), abi=CTF_ABI)

    erc20_approvals = [
        (f"{collateral_name}→CTF", CONTRACTS["CTF"]),
        (f"{collateral_name}→Exchange", CONTRACTS["CTF_EXCHANGE"]),
        (f"{collateral_name}→NegRiskExchange", CONTRACTS["NEG_RISK_CTF_EXCHANGE"]),
        (f"{collateral_name}→NegRiskAdapter", CONTRACTS["NEG_RISK_ADAPTER"]),
    ]
    ctf_approvals = [
        ("CTF→Exchange", CONTRACTS["CTF_EXCHANGE"]),
        ("CTF→NegRiskExchange", CONTRACTS["NEG_RISK_CTF_EXCHANGE"]),
        ("CTF→NegRiskAdapter", CONTRACTS["NEG_RISK_ADAPTER"]),
    ]

    pending = []
    for label, spender in erc20_approvals:
        try:
            allowance = usdc.functions.allowance(checksummed, w3.to_checksum_address(spender)).call()
            if allowance < 10**18:
                pending.append((label, usdc, "approve", spender, MAX_UINT256))
        except Exception:
            pending.append((label, usdc, "approve", spender, MAX_UINT256))

    for label, spender in ctf_approvals:
        try:
            approved = ctf.functions.isApprovedForAll(checksummed, w3.to_checksum_address(spender)).call()
            if not approved:
                pending.append((label, ctf, "setApprovalForAll", spender, True))
        except Exception:
            pending.append((label, ctf, "setApprovalForAll", spender, True))

    if not pending:
        return {"approvals": [], "count": 0, "message": "All approvals already set"}

    tx_hashes = []
    nonce = w3.eth.get_transaction_count(checksummed, "pending")

    import time

    from regard.core.evm import get_safe_gas_price, simulate_and_send
    for label, contract, method, spender, value in pending:
        try:
            gas_price = get_safe_gas_price(w3)
            fn = getattr(contract.functions, method)
            tx = fn(w3.to_checksum_address(spender), value).build_transaction({
                "from": checksummed,
                "nonce": nonce,
                "gas": 100_000,
                "gasPrice": gas_price,
                "chainId": 137,
            })
            tx_hash = simulate_and_send(w3, tx, account)
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)

            if receipt["status"] != 1:
                die("venue_error", "APPROVAL_FAILED", f"{label} tx reverted: {tx_hash.hex()}", exit_code=4)

            tx_hashes.append({"label": label, "tx_hash": tx_hash.hex()})
            nonce += 1
            time.sleep(5)
        except SystemExit:
            raise
        except Exception as e:
            die("venue_error", "APPROVAL_FAILED", f"{label}: {e}", exit_code=4)

    return {"approvals": tx_hashes, "count": len(tx_hashes)}


register_executor("polymarket", "approve", execute_poly_approve)


# ---------------------------------------------------------------------------
# Wrap / Unwrap — USDC.e ↔ pUSD via CollateralOnramp / CollateralOfframp
# ---------------------------------------------------------------------------

@polygon_usdce_transfer_app.command("pusd")
def polygon_usdce_transfer_pusd(
    ctx: typer.Context,
    amount: Annotated[float, typer.Argument(help="USDC.e amount to wrap into pUSD (1:1)")],
    to: Annotated[str | None, typer.Option("--to", help="Recipient address (default: current wallet)")] = None,
):
    """Same-chain compartment shift: USDC.e → pUSD via Polymarket's Collateral Onramp (1:1, no fees). Creates a proposal."""
    from regard.venues.polymarket.client import get_address, get_wallet_balances
    opts = ctx.obj

    if amount <= 0:
        die("validation_error", "INVALID_AMOUNT",
            "Amount must be positive", param="amount", exit_code=2)

    sender = get_address()
    recipient = to or sender

    balances = get_wallet_balances()
    usdc_e_balance = float(balances["usdc_e"])
    if usdc_e_balance < amount:
        die("validation_error", "INSUFFICIENT_BALANCE",
            f"USDC.e balance ({usdc_e_balance}) < requested ({amount})",
            hint="Check balance with `regard polymarket balance`",
            exit_code=2)

    amount_raw = int(round(amount * 10**6))
    params = {
        "sender": sender,
        "recipient": recipient,
        "amount": str(amount),
        "amount_raw": str(amount_raw),
    }
    checks = {
        "sender": sender,
        "recipient": recipient,
        "usdc_e_balance": f"{usdc_e_balance:.6f}",
        "projected_usdc_e": f"{usdc_e_balance - amount:.6f}",
    }
    warnings = [f"Wraps {amount} USDC.e → {amount} pUSD (1:1, contract-enforced, no slippage)"]
    proposal = create_proposal("polygon", "usdce.transfer.pusd", params, checks, warnings)
    output(proposal, opts["fields"])


def _ensure_allowance(w3, token_contract, owner_addr, spender_addr, amount_raw: int, nonce: int, account):
    """Approve `spender` to spend `owner`'s `token` if allowance < amount_raw.

    Returns (tx_hash_entry_or_None, next_nonce). After the approval tx is mined,
    polls allowance() until the new value is visible on the upstream RPC — some
    upstreams lag a block or two behind tx confirmation and return stale state.
    """
    import time

    from regard.core.evm import get_safe_gas_price, simulate_and_send

    try:
        allowance = token_contract.functions.allowance(owner_addr, spender_addr).call()
    except Exception:
        allowance = 0

    if allowance >= amount_raw:
        return None, nonce

    gas_price = get_safe_gas_price(w3)
    approve_tx = token_contract.functions.approve(spender_addr, MAX_UINT256).build_transaction({
        "from": owner_addr,
        "nonce": nonce,
        "gas": 100_000,
        "gasPrice": gas_price,
        "chainId": 137,
    })
    approve_hash = simulate_and_send(w3, approve_tx, account)
    approve_receipt = w3.eth.wait_for_transaction_receipt(approve_hash, timeout=120)
    if approve_receipt["status"] != 1:
        die("venue_error", "APPROVAL_FAILED",
            f"Approval tx reverted: 0x{approve_hash.hex()}",
            exit_code=4)

    # RPC state lag: wait until allowance() reflects the new value before the caller
    # simulates the next tx (which would fail with stale state).
    post = 0
    for _ in range(10):
        try:
            post = token_contract.functions.allowance(owner_addr, spender_addr).call()
            if post >= amount_raw:
                break
        except Exception:
            pass
        time.sleep(1)
    else:
        import sys
        print(
            f"WARNING: approval tx 0x{approve_hash.hex()} was mined but RPC still shows stale "
            f"allowance after 10s; subsequent simulation may fail with TransferFromFailed. "
            "Retry the command — the approval persists.",
            file=sys.stderr,
        )

    return {"label": "approve", "tx_hash": f"0x{approve_hash.hex()}"}, nonce + 1


def _execute_ramp(params: dict, *, action: str) -> dict:
    """Shared execute path for wrap (USDC.e → pUSD) and unwrap (pUSD → USDC.e).

    action ∈ {"wrap", "unwrap"}. wrap approves USDC.e→Onramp, calls wrap().
    unwrap approves pUSD→Offramp, calls unwrap(). Both operate on USDC.e as `_asset`
    per the ramp contract ABI.
    """
    import eth_account

    from regard.core.audit import log_event
    from regard.core.evm import get_safe_gas_price, simulate_and_send
    from regard.venues.polymarket.client import _get_key

    key = _get_key()
    if not key.startswith("0x"):
        key = f"0x{key}"
    account = eth_account.Account.from_key(key)

    w3 = get_web3()
    try:
        w3.eth.block_number
    except Exception:
        die("network_error", "RPC_UNREACHABLE", "Cannot connect to Polygon RPC",
            hint="Set POLYGON_RPC env var to a working RPC URL", exit_code=6)

    sender_addr = w3.to_checksum_address(params["sender"])
    recipient = w3.to_checksum_address(params["recipient"])
    amount_raw = int(params["amount_raw"])

    if account.address.lower() != sender_addr.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({account.address}) does not match proposal sender ({sender_addr})",
            hint="Set POLYMARKET_PRIVATE_KEY to the same key used when creating the proposal",
            exit_code=2)

    usdc_e_addr = w3.to_checksum_address(CONTRACTS["USDC_E"])

    if action == "wrap":
        pay_token_addr = usdc_e_addr
        ramp_addr = w3.to_checksum_address(CONTRACTS["COLLATERAL_ONRAMP"])
        ramp_abi = ONRAMP_ABI
        ramp_method = "wrap"
        fail_code = "WRAP_FAILED"
    else:
        pay_token_addr = w3.to_checksum_address(CONTRACTS["PUSD"])
        ramp_addr = w3.to_checksum_address(CONTRACTS["COLLATERAL_OFFRAMP"])
        ramp_abi = OFFRAMP_ABI
        ramp_method = "unwrap"
        fail_code = "UNWRAP_FAILED"

    tx_hashes = []
    nonce = w3.eth.get_transaction_count(sender_addr, "pending")

    pay_token = w3.eth.contract(address=pay_token_addr, abi=ERC20_ABI)
    approval_entry, nonce = _ensure_allowance(w3, pay_token, sender_addr, ramp_addr, amount_raw, nonce, account)
    if approval_entry is not None:
        approval_entry["label"] = f"approve_{action}"
        tx_hashes.append(approval_entry)

    ramp = w3.eth.contract(address=ramp_addr, abi=ramp_abi)
    gas_price = get_safe_gas_price(w3)
    ramp_tx = getattr(ramp.functions, ramp_method)(
        usdc_e_addr,
        recipient,
        amount_raw,
    ).build_transaction({
        "from": sender_addr,
        "nonce": nonce,
        "gas": 150_000,
        "gasPrice": gas_price,
        "chainId": 137,
    })
    ramp_hash = simulate_and_send(w3, ramp_tx, account)
    ramp_receipt = w3.eth.wait_for_transaction_receipt(ramp_hash, timeout=120)
    if ramp_receipt["status"] != 1:
        die("venue_error", fail_code,
            f"Collateral{ramp_method.capitalize()} reverted: 0x{ramp_hash.hex()}",
            exit_code=4)
    ramp_hex = f"0x{ramp_hash.hex()}"
    tx_hashes.append({"label": ramp_method, "tx_hash": ramp_hex})

    try:
        # `action` is "wrap" / "unwrap" — kept as the command audit label so
        # historic event filters still resolve. The venue is "polygon" because
        # both flows are Polygon chain operations on the Collateral Onramp/Offramp.
        log_event("executed", command=action, venue="polygon",
                  amount=params["amount"], tx_hash=ramp_hex)
    except Exception as e:
        import sys
        print(f"WARNING: audit log write failed ({e}) — tx was sent: {ramp_hex}", file=sys.stderr)

    return {
        "status": f"{action}ped",
        "amount": params["amount"],
        "recipient": recipient,
        "txs": tx_hashes,
        "tx_hash": ramp_hex,
    }


def execute_poly_wrap(params: dict) -> dict:
    """Execute USDC.e → pUSD wrap via CollateralOnramp."""
    return _execute_ramp(params, action="wrap")


register_executor("polygon", "usdce.transfer.pusd", execute_poly_wrap)


@polygon_pusd_transfer_app.command("usdce")
def polygon_pusd_transfer_usdce(
    ctx: typer.Context,
    amount: Annotated[float, typer.Argument(help="pUSD amount to unwrap into USDC.e (1:1)")],
    to: Annotated[str | None, typer.Option("--to", help="Recipient address (default: current wallet)")] = None,
):
    """Same-chain compartment shift: pUSD → USDC.e via Polymarket's Collateral Offramp (1:1, no fees). Creates a proposal."""
    from regard.venues.polymarket.client import get_address, get_wallet_balances
    opts = ctx.obj

    if amount <= 0:
        die("validation_error", "INVALID_AMOUNT",
            "Amount must be positive", param="amount", exit_code=2)

    sender = get_address()
    recipient = to or sender

    balances = get_wallet_balances()
    pusd_balance = float(balances["pusd"])
    if pusd_balance < amount:
        die("validation_error", "INSUFFICIENT_BALANCE",
            f"pUSD balance ({pusd_balance}) < requested ({amount})",
            hint="Check balance with `regard polymarket balance`",
            exit_code=2)

    amount_raw = int(round(amount * 10**6))
    params = {
        "sender": sender,
        "recipient": recipient,
        "amount": str(amount),
        "amount_raw": str(amount_raw),
    }
    checks = {
        "sender": sender,
        "recipient": recipient,
        "pusd_balance": f"{pusd_balance:.6f}",
        "projected_pusd": f"{pusd_balance - amount:.6f}",
    }
    warnings = [f"Unwraps {amount} pUSD → {amount} USDC.e (1:1, contract-enforced, no slippage)"]
    proposal = create_proposal("polygon", "pusd.transfer.usdce", params, checks, warnings)
    output(proposal, opts["fields"])


def execute_poly_unwrap(params: dict) -> dict:
    """Execute pUSD → USDC.e unwrap via CollateralOfframp."""
    return _execute_ramp(params, action="unwrap")


register_executor("polygon", "pusd.transfer.usdce", execute_poly_unwrap)


# ---------------------------------------------------------------------------
# Deposit — bridge any supported source token → pUSD via Polymarket Bridge API
# ---------------------------------------------------------------------------

# Polygon-side token addresses accepted by the Bridge API as USDC flavors.
# Both bridge to pUSD via the Collateral Onramp 1:1.
_POLY_USDC_TOKENS = {
    "usdc": {
        "address": "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359",  # native USDC
        "name": "USDC",
    },
    "usdc_e": {
        "address": CONTRACTS["USDC_E"],  # legacy bridged USDC.e
        "name": "USDC.e",
    },
}


@polygon_usdc_transfer_app.command("usdce")
def polygon_usdc_transfer_usdce(
    ctx: typer.Context,
    amount: Annotated[float, typer.Argument(help="Amount of native USDC to bridge into USDC.e (1:1 minus ~0.08% bridge fee)")],
):
    """Same-chain compartment shift: native USDC → USDC.e via Polymarket's Bridge API.

    Creates a proposal. On approve, submits one USDC.transfer tx from the
    current wallet to Polymarket's bridge deposit address, then polls until
    the bridge confirms USDC.e arrival (or times out after 5 min with the
    source tx hash for manual follow-up).

    Bridges 1:1 (no slippage, no fx). Minimum $2 USD equivalent.
    Chain into `regard polygon usdce transfer pusd <delivered>` to convert to tradeable pUSD.
    """
    from regard.venues.polymarket.client import get_address, get_wallet_balances

    opts = ctx.obj

    # Source token is fixed by the command path: native USDC. The legacy
    # `--token` flag is gone — the destination compartment is now in the
    # subcommand name, and "usdc_e source" overlapped with the (now moved)
    # `polygon usdce transfer pusd` (wrap) flow.
    token_key = "usdc"
    if token_key not in _POLY_USDC_TOKENS:
        die("validation_error", "UNSUPPORTED_DEPOSIT_TOKEN",
            f"Unknown source token: '{token_key}'. Supported: {', '.join(_POLY_USDC_TOKENS)}",
            param="amount", exit_code=2)

    if amount <= 0:
        die("validation_error", "INVALID_AMOUNT",
            "Amount must be positive", param="amount", exit_code=2)

    token_spec = _POLY_USDC_TOKENS[token_key]
    token_addr = token_spec["address"]
    token_name = token_spec["name"]

    # Check Bridge API supports this token (it may change over time), pull min.
    try:
        asset = get_bridge_asset_spec(137, token_addr)
    except Exception as e:
        die("network_error", "BRIDGE_API_UNREACHABLE",
            f"Polymarket Bridge API unreachable: {e}",
            hint="The Bridge API may be temporarily down. Retry in a moment.",
            retryable=True, exit_code=6)

    if asset is None:
        die("validation_error", "UNSUPPORTED_DEPOSIT_TOKEN",
            f"Polymarket Bridge API does not currently list {token_name} "
            f"({token_addr}) on Polygon",
            hint="Check `curl https://bridge.polymarket.com/supported-assets` for the current list.",
            param="token", exit_code=2)

    min_usd = float(asset.get("minCheckoutUsd", 2))
    if amount < min_usd:
        die("validation_error", "BELOW_MIN_DEPOSIT",
            f"Amount {amount} {token_name} is below Polymarket's minimum deposit ({min_usd} USD)",
            hint=f"Minimum deposit is {min_usd} {token_name}. Increase and retry.",
            param="amount", exit_code=2)

    sender = get_address()

    # Balance check (best-effort — on-chain read may fail on transient RPC issues)
    try:
        balances = get_wallet_balances()
        balance = float(balances.get(token_key, 0))
    except Exception:
        balance = None

    if balance is not None and balance < amount:
        die("validation_error", "INSUFFICIENT_BALANCE",
            f"{token_name} balance ({balance}) < requested ({amount})",
            hint="Check balance with `regard polymarket status`.",
            exit_code=2)

    # Fetch deposit addresses fresh at propose time — they're deterministic per
    # wallet but not guaranteed stable across bridge-provider migrations, so we
    # lock the evm address into the proposal now.
    try:
        addresses = get_bridge_deposit_addresses(sender)
    except Exception as e:
        die("network_error", "BRIDGE_API_UNREACHABLE",
            f"Polymarket Bridge API unreachable: {e}",
            hint="The Bridge API may be temporarily down. Retry in a moment.",
            retryable=True, exit_code=6)

    evm_deposit = addresses.get("evm")
    if not evm_deposit:
        die("venue_error", "NO_DEPOSIT_ADDRESS",
            "Polymarket Bridge API did not return an EVM deposit address",
            hint="Unexpected — retry, or file an issue with the Bridge API response.",
            retryable=True, exit_code=6)

    decimals = int(asset.get("token", {}).get("decimals", 6))
    amount_raw = int(round(amount * 10**decimals))

    params = {
        "sender": sender,
        "recipient": sender,  # pUSD is credited to the same wallet
        "amount": f"{amount:.6f}",
        "amount_raw": str(amount_raw),
        "token": token_key,
        "token_name": token_name,
        "token_address": token_addr,
        "token_decimals": decimals,
        "source_chain_id": 137,
        "deposit_address": evm_deposit,
        "min_usd": min_usd,
    }
    checks: dict = {
        "sender": sender,
        "source_token": token_name,
        "source_chain": "Polygon",
        "deposit_address": evm_deposit,
        "projected_pusd": f"{amount:.6f}",
    }
    if balance is not None:
        checks[f"{token_key}_balance"] = f"{balance:.6f}"
        checks[f"projected_{token_key}"] = f"{balance - amount:.6f}"

    # Honest two-step narrative: for same-chain Polygon→Polygon deposits,
    # Polymarket's bridge delivers USDC.e (not pUSD — despite what their docs
    # suggest). Final USDC.e → pUSD wrap is a separate
    # `regard polygon usdce transfer pusd` call. The executor surfaces this
    # as `next_command` when it fires.
    warnings = [
        f"Sends {amount} {token_name} to Polymarket's bridge deposit address on Polygon "
        f"(~1–2 min, small bridge fee ~0.08%). "
        f"For Polygon→Polygon the bridge delivers USDC.e to your wallet — "
        f"follow this with `regard polygon usdce transfer pusd` to convert to "
        f"tradeable pUSD (1:1, on-chain, no fees). The executor surfaces the "
        f"exact wrap command once the bridge completes."
    ]
    proposal = create_proposal("polygon", "usdc.transfer.usdce", params, checks, warnings)
    output(proposal, opts["fields"])


def execute_poly_deposit(params: dict) -> dict:
    """Execute the Polygon-side USDC transfer to Polymarket's bridge, then poll
    status until the bridge confirms pUSD arrival (or timeout with partial success).
    """
    import time

    import eth_account

    from regard.core.audit import log_event
    from regard.core.evm import get_safe_gas_price, simulate_and_send
    from regard.venues.polymarket.client import _get_key

    key = _get_key()
    if not key.startswith("0x"):
        key = f"0x{key}"
    account = eth_account.Account.from_key(key)

    w3 = get_web3()
    try:
        w3.eth.block_number
    except Exception:
        die("network_error", "RPC_UNREACHABLE", "Cannot connect to Polygon RPC",
            hint="Set POLYGON_RPC env var to a working RPC URL", exit_code=6)

    sender_addr = w3.to_checksum_address(params["sender"])
    if account.address.lower() != sender_addr.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({account.address}) does not match proposal sender ({sender_addr})",
            hint="Set POLYMARKET_PRIVATE_KEY to the same key used when creating the proposal",
            exit_code=2)

    token_addr = w3.to_checksum_address(params["token_address"])
    deposit_addr = w3.to_checksum_address(params["deposit_address"])
    amount_raw = int(params["amount_raw"])
    token_name = params.get("token_name", "USDC")

    token_contract = w3.eth.contract(address=token_addr, abi=ERC20_ABI)

    # Verify balance at execute time (state may have drifted between propose/approve)
    try:
        current_balance = token_contract.functions.balanceOf(sender_addr).call()
    except Exception as e:
        die("venue_error", "BALANCE_READ_FAILED",
            f"Could not read {token_name} balance: {e}",
            hint="Retry — likely a transient RPC issue.",
            retryable=True, exit_code=6)

    if current_balance < amount_raw:
        die("validation_error", "INSUFFICIENT_BALANCE",
            f"{token_name} balance ({current_balance / 10**int(params.get('token_decimals', 6))}) "
            f"< requested ({amount_raw / 10**int(params.get('token_decimals', 6))})",
            hint="Top up the wallet or reduce the deposit amount.",
            exit_code=2)

    # Record the start time so we can filter status transactions to just this deposit
    started_ms = int(time.time() * 1000)

    log_event("proposed_execute", command="polygon_deposit", sender=sender_addr,
              deposit_address=deposit_addr, amount=params.get("amount"),
              token=token_name)

    # Submit the source-chain transfer (USDC.transfer to deposit_addr)
    nonce = w3.eth.get_transaction_count(sender_addr, "pending")
    gas_price = get_safe_gas_price(w3)
    tx = token_contract.functions.transfer(deposit_addr, amount_raw).build_transaction({
        "from": sender_addr,
        "nonce": nonce,
        "gas": 100_000,
        "gasPrice": gas_price,
        "chainId": 137,
    })

    try:
        tx_hash = simulate_and_send(w3, tx, account)
    except Exception as e:
        die("venue_error", "DEPOSIT_TX_FAILED",
            f"{token_name} transfer simulation/send failed: {e}",
            exit_code=4)

    try:
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
    except Exception as e:
        die("venue_error", "DEPOSIT_TX_NOT_MINED",
            f"Source tx {tx_hash.hex()} submitted but not mined within 3 min: {e}",
            hint=f"Poll status manually: curl https://bridge.polymarket.com/status/{deposit_addr}",
            exit_code=4)

    if receipt["status"] != 1:
        die("venue_error", "DEPOSIT_TX_REVERTED",
            f"{token_name} transfer tx reverted: 0x{tx_hash.hex()}",
            exit_code=4)

    src_tx_hash = f"0x{tx_hash.hex()}"
    log_event("bridge_source_confirmed", command="polygon_deposit",
              src_tx=src_tx_hash, block=receipt.get("blockNumber"))

    # Poll the Bridge API for the off-chain → pUSD credit
    final = poll_bridge_status(
        deposit_addr,
        timeout_s=300,
        interval_s=15,
        since_time_ms=started_ms,
    )

    if final is None:
        # Source tx landed but bridge never detected it — unusual. Surface as
        # partial success so user can follow up; don't die because the USDC
        # transfer is already on-chain.
        return {
            "status": "SOURCE_CONFIRMED_BRIDGE_UNDETECTED",
            "src_tx_hash": src_tx_hash,
            "deposit_address": deposit_addr,
            "amount": params.get("amount"),
            "token": token_name,
            "hint": (
                f"Source {token_name} transfer confirmed on Polygon but Bridge "
                "API never registered it in 5 min. Check manually: "
                f"curl https://bridge.polymarket.com/status/{deposit_addr}"
            ),
        }

    bridge_status = final.get("status", "UNKNOWN")
    bridge_tx = final.get("txHash")

    if bridge_status == "COMPLETED":
        # Read the actual destination token from the bridge status — the API
        # (and docs) aren't reliable on this. For same-chain Polygon→Polygon,
        # the bridge delivers USDC.e, NOT pUSD, despite docs claiming auto-wrap.
        # Bridge's own `/status.toTokenAddress` is the source of truth.
        dest_addr_raw = final.get("toTokenAddress") or ""
        dest_addr_lower = dest_addr_raw.lower()
        _TOKEN_NAMES_LOWER = {k.lower(): v for k, v in TOKEN_NAMES.items()}
        dest_token_name = _TOKEN_NAMES_LOWER.get(dest_addr_lower, f"token {dest_addr_raw}")

        # Compute delivered amount from on-chain balance delta of the delivered
        # token. Bridge takes a small fee (~0.08%) so "amount deposited" is not
        # exactly "amount delivered". Caller decides what to do with the delta
        # (typically chain into `poly wrap` if dest is USDC.e).
        delivered_amount = None
        if dest_addr_raw:
            try:
                dest_contract = w3.eth.contract(
                    address=w3.to_checksum_address(dest_addr_raw), abi=ERC20_ABI
                )
                post_balance = dest_contract.functions.balanceOf(sender_addr).call()
                # Decimals for pUSD and USDC.e are both 6; native USDC too.
                # Safe assumption for the bridge's supported assets.
                delivered_amount = f"{post_balance / 10**6:.6f}"
            except Exception:
                pass  # partial result — users can still check manually

        log_event("bridge_complete", command="polygon_deposit",
                  src_tx=src_tx_hash, dest_tx=bridge_tx,
                  delivered_token=dest_token_name,
                  delivered_amount=delivered_amount,
                  amount_requested=params.get("amount"))

        result = {
            "status": "COMPLETED",
            "src_tx_hash": src_tx_hash,
            "bridge_tx_id": bridge_tx,  # Bridge-provider internal ID, NOT a Polygon tx hash
            "deposit_address": deposit_addr,
            "amount_requested": params.get("amount"),
            "amount_delivered": delivered_amount,
            "token_source": token_name,
            "token_dest": dest_token_name,
            "token_dest_address": dest_addr_raw,
            "chain_source": 137,
            "chain_dest": int(final.get("toChainId", 137)),
        }

        # If delivered token isn't pUSD, surface the next-step command so the
        # agent (or user) can chain into the final wrap. Dyad-contract hint: the
        # agent should offer `regard polygon usdce transfer pusd <delivered>`
        # as the follow-up proposal rather than leave the user stuck with USDC.e.
        if dest_addr_lower != CONTRACTS["PUSD"].lower() and delivered_amount:
            if dest_addr_lower == CONTRACTS["USDC_E"].lower():
                result["next_command"] = f"regard polygon usdce transfer pusd {delivered_amount}"
                result["next_command_reason"] = (
                    f"Bridge delivered {delivered_amount} USDC.e, not pUSD. "
                    f"Run `regard polygon usdce transfer pusd {delivered_amount}` to "
                    f"convert to tradeable pUSD via the Collateral Onramp (on-chain, 1:1, no fees)."
                )
            else:
                result["next_command_reason"] = (
                    f"Bridge delivered {delivered_amount} {dest_token_name}, not pUSD. "
                    "Manual conversion needed."
                )
        return result

    if bridge_status == "FAILED":
        die("venue_error", "DEPOSIT_BRIDGE_FAILED",
            f"Bridge reported FAILED after source tx {src_tx_hash}",
            hint="Contact Polymarket's Bridge API support for recovery.",
            extra={"src_tx_hash": src_tx_hash, "bridge_tx_hash": bridge_tx,
                   "deposit_address": deposit_addr},
            exit_code=4)

    # Still processing at timeout — surface partial success; user can re-query
    return {
        "status": "SUBMITTED",
        "src_tx_hash": src_tx_hash,
        "deposit_address": deposit_addr,
        "amount": params.get("amount"),
        "token": token_name,
        "bridge_status_at_timeout": bridge_status,
        "hint": (
            "Source tx confirmed; bridge still processing after 5 min. Poll: "
            f"curl https://bridge.polymarket.com/status/{deposit_addr}"
        ),
    }


register_executor("polygon", "usdc.transfer.usdce", execute_poly_deposit)


@polymarket_app.command()
def order(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID, condition ID, or slug")],
    outcome: Annotated[str, typer.Argument(help="yes or no")],
    side: Annotated[str, typer.Argument(help="buy or sell")],
    size: Annotated[float, typer.Argument(help="Number of shares")],
    price: Annotated[float | None, typer.Argument(help="Limit price (probability 0.01-0.99)")] = None,
    market_order: Annotated[bool, typer.Option("--market", help="Market order (fill or kill)")] = False,
):
    """Place an order on a prediction market outcome. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    outcome_lower = outcome.lower()
    if outcome_lower not in ("yes", "no"):
        die("validation_error", "INVALID_OUTCOME", f"Outcome must be 'yes' or 'no', got '{outcome}'", exit_code=2)

    side_upper = SIDE_MAP.get(side.lower())
    if not side_upper:
        die("validation_error", "INVALID_SIDE", f"Side must be 'buy' or 'sell', got '{side}'", exit_code=2)

    if not market_order and price is None:
        die("validation_error", "MISSING_PRICE", "Specify a price or use --market", exit_code=2)

    if price is not None and (price < 0.01 or price > 0.99):
        die("validation_error", "INVALID_PRICE", f"Price must be between 0.01 and 0.99, got {price}", exit_code=2)

    check_geo_block()

    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)
    if not m["accepting_orders"]:
        die("venue_error", "MARKET_CLOSED", f"Market is not accepting orders: {m['question']}", exit_code=4)

    token_id = m["yes_token_id"] if outcome_lower == "yes" else m["no_token_id"]
    if not token_id:
        die("validation_error", "NO_TOKEN", f"No {outcome} token found", exit_code=2)

    # Validate precision before creating proposal
    _validate_poly_precision(size, price, m["tick_size"])

    # Validate minimum order size (per-market, from Gamma API)
    min_size = m.get("min_order_size", 5)
    if size < min_size:
        die("validation_error", "BELOW_MIN_SIZE",
            f"Order size {size} is below the minimum of {min_size} shares for this market",
            hint=f"Use size >= {min_size}",
            param="size", exit_code=2)

    # Pre-flight minimum notional check for marketable LIMIT orders.
    # Polymarket enforces a $1 minimum notional on marketable orders (orders
    # that execute immediately against the book). Catching this at propose
    # time avoids wasting a proposal slot when the venue would reject at
    # approve time. Resting limits (price below ask for BUY, above bid for
    # SELL) are exempt — they just sit in the book.
    #
    # Not applied to --market orders: the V2 SDK's `MarketOrderArgs.amount`
    # is dollars for BUY / shares for SELL, so the CLI's `size` argument
    # has different semantics there. Market-order validation is left to the
    # venue until that inconsistency is resolved separately.
    if price is not None and not market_order:
        try:
            best_ask_val = float(m.get("best_ask") or 0)
            best_bid_val = float(m.get("best_bid") or 0)
        except (ValueError, TypeError):
            best_ask_val = best_bid_val = 0.0
        is_marketable = (
            (side_upper == "BUY" and best_ask_val > 0 and price >= best_ask_val)
            or (side_upper == "SELL" and best_bid_val > 0 and price <= best_bid_val)
        )
        if is_marketable:
            notional = size * price
            if notional < 1.0:
                import math
                min_shares_needed = math.ceil(1.0 / price)
                die("validation_error", "BELOW_MIN_NOTIONAL",
                    f"Marketable order notional ${notional:.2f} is below Polymarket's $1 minimum (size × price)",
                    hint=f"Use size >= {min_shares_needed} shares at this price, or a non-marketable limit (below {best_ask_val} for BUY / above {best_bid_val} for SELL)",
                    param="size", exit_code=2)

    # Capture current market probability as mark price (not user's limit price)
    current_prob = m["yes_price"] if outcome_lower == "yes" else m["no_price"]
    checks = {}
    if current_prob > 0:
        checks["mark_price"] = str(current_prob)

    # Fee preview. Polymarket charges takerOnly fees on a subset of markets
    # (sports/crypto/politics/etc — see feeType). Resting limits pay 0 unless
    # they cross and become takers. We surface the worst-case taker fee so the
    # agent sees the upper bound before approving.
    fee_schedule = m.get("fee_schedule")
    fee_price = price if price is not None else current_prob
    if market_order and side_upper == "BUY":
        # MarketOrderArgs.amount is dollars on BUY (size variable holds dollars here)
        fee_notional = size
    else:
        fee_notional = size * fee_price if fee_price else 0.0
    expected_fees = compute_fee(fee_notional, fee_price, fee_schedule) if fee_schedule and fee_price else 0.0
    if m.get("fees_enabled"):
        checks["fees_enabled"] = "true"
        checks["fee_type"] = m.get("fee_type", "")
        checks["expected_fees"] = f"{expected_fees:.4f}"
        if side_upper == "BUY":
            checks["net_cost"] = f"{fee_notional + expected_fees:.4f}"

    params = {
        "token_id": token_id,
        "market_question": m["question"],
        "market_slug": m["slug"],
        "outcome": outcome_lower,
        "side": side_upper,
        "size": str(size),
        "price": str(price) if price is not None else None,
        "market_order": market_order,
        "tick_size": m["tick_size"],
        "fee_schedule": fee_schedule,
        "mark_price": str(current_prob) if current_prob else None,
    }

    warnings = []
    proposal = create_proposal("polymarket", "order", params, checks, warnings)
    output(proposal, opts["fields"])


def execute_poly_order(params: dict) -> dict:
    """Execute a Polymarket order from proposal params."""
    check_geo_block()
    clob = get_clob_client()

    token_id = params["token_id"]
    side_upper = params["side"]
    size = float(params["size"])
    is_market = params["market_order"]

    # Validate precision at approve time too (defense in depth —
    # pre-upgrade proposals or tampered pending files could bypass propose-time check)
    price_val = float(params["price"]) if params.get("price") else None
    tick = params.get("tick_size", 0.01)
    _validate_poly_precision(size, price_val, tick)

    # Proactive balance check — catch insufficient funds before submission.
    # Reserves expected taker fees from the proposal so a fee-bearing market
    # near the balance edge doesn't slip past the propose-time check and
    # rejection-loop at the venue.
    fee_schedule = params.get("fee_schedule")
    if side_upper == "BUY":
        try:
            from py_clob_client_v2.clob_types import AssetType, BalanceAllowanceParams
            bal = clob.get_balance_allowance(BalanceAllowanceParams(asset_type=AssetType.COLLATERAL))
            available = float(bal.get("balance", 0))
            if is_market:
                # MarketOrderArgs.amount is dollars on BUY → size already notional
                base_cost = size
                fee_price = float(params.get("mark_price") or price_val or 0.5)
            else:
                base_cost = size * (price_val if price_val else 1.0)
                fee_price = price_val if price_val else 0.5
            fees = compute_fee(base_cost, fee_price, fee_schedule) if fee_schedule else 0.0
            estimated_cost = base_cost + fees
            if available < estimated_cost:
                fee_note = f" (incl. ~{fees:.4f} fees)" if fees else ""
                die("venue_error", "INSUFFICIENT_BALANCE",
                    f"Available balance ({available:.2f}) is less than estimated order cost ({estimated_cost:.2f}){fee_note}",
                    hint="Deposit more pUSD (or wrap USDC.e with `regard polygon usdce transfer pusd <amount>`) or reduce order size. Check balance with: regard polymarket balance",
                    extra={"execution_state": "not_executed"},
                    exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass  # balance check is best-effort; CLOB will reject if insufficient

    try:
        from py_clob_client_v2.clob_types import MarketOrderArgs, OrderArgs, OrderType, PartialCreateOrderOptions

        if is_market:
            order_args = MarketOrderArgs(
                token_id=token_id,
                amount=size,
                side=side_upper,
            )
            signed = clob.create_market_order(order_args)
            resp = clob.post_order(signed, OrderType.FOK)
        else:
            price = float(params["price"])
            options = PartialCreateOrderOptions(tick_size=str(tick))

            order_args = OrderArgs(
                price=price,
                size=size,
                side=side_upper,
                token_id=token_id,
            )
            signed = clob.create_order(order_args, options)
            resp = clob.post_order(signed, OrderType.GTC)

    except Exception as e:
        err_str = str(e)
        code, hint = _classify_poly_clob_error(err_str)
        # Preserve the GEO_BLOCKED special-casing as geo_error (not venue_error)
        if code == "GEO_BLOCKED":
            die("geo_error", code, err_str, hint=hint, exit_code=4)
        die("venue_error", code, err_str, hint=hint, exit_code=4)

    # CLOB returns HTTP 200 + `{success: false, errorMsg: "..."}` on rejections.
    # Without this check, rejections silently surfaced as "success" with an empty
    # order_id — see trading/orders/overview#error-messages in Polymarket docs.
    if isinstance(resp, dict) and resp.get("success") is False:
        err_msg = resp.get("errorMsg") or str(resp)
        code, hint = _classify_poly_clob_error(err_msg)
        if code == "GEO_BLOCKED":
            die("geo_error", code, err_msg, hint=hint, exit_code=4)
        die("venue_error", code, err_msg, hint=hint, exit_code=4)

    order_id = ""
    if isinstance(resp, dict):
        order_id = resp.get("orderID", resp.get("id", ""))

    return {
        "order_id": order_id,
        "market": params["market_question"],
        "outcome": params["outcome"],
        "side": side_upper,
        "size": params["size"],
        "price": params["price"] if params.get("price") else "market",
        "type": "FOK" if is_market else "GTC",
        "response": resp,
    }


register_executor("polymarket", "order", execute_poly_order)


@polymarket_app.command()
def cancel(
    ctx: typer.Context,
    order_id: Annotated[str, typer.Argument(help="Order ID to cancel")],
):
    """Cancel an open order. Creates a proposal — use `regard approve` to execute."""
    import re
    opts = ctx.obj

    # CLOB order IDs are 0x-prefixed 64-char hex hashes
    if not re.match(r'^(0x[0-9a-fA-F]{64}|[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$', order_id):
        die("validation_error", "INVALID_ORDER_ID",
            f"Invalid order ID format: '{order_id}'",
            hint="Order IDs are 0x-prefixed hex hashes from 'regard polymarket orders'")

    # Note: cancel is NOT geo-restricted (verified live from US, confirmed by
    # docs). Blocked-region users must be able to exit positions.

    params = {"order_id": order_id}
    proposal = create_proposal("polymarket", "cancel", params, {}, [])
    output(proposal, opts["fields"])


def execute_poly_cancel(params: dict) -> dict:
    """Execute a Polymarket cancel from proposal params.

    CLOB returns `{canceled: [ids...], not_canceled: {id: reason, ...}}`. A
    single-order cancel that lands in `not_canceled` is a failure — surface it
    with a classified code, not a silent "response wrapping" that the agent
    would mistake for success.
    """
    clob = get_clob_client()

    try:
        from py_clob_client_v2.clob_types import OrderPayload
        resp = clob.cancel_order(OrderPayload(orderID=params["order_id"]))
    except Exception as e:
        code, hint = _classify_poly_clob_error(str(e))
        die("venue_error", code if code != "ORDER_REJECTED" else "CANCEL_FAILED",
            str(e), hint=hint, exit_code=4)

    oid = params["order_id"]
    if isinstance(resp, dict):
        canceled = resp.get("canceled") or []
        not_canceled = resp.get("not_canceled") or {}
        # Docs show canceled[] as flat list of string IDs across all SDKs, but
        # be defensive against SDK drift / wrapping changes — extract IDs from
        # either string-or-object entries so a future shape change doesn't
        # turn every successful cancel into a false CANCEL_FAILED.
        canceled_ids = _extract_order_ids(canceled)
        if oid not in canceled_ids:
            reason = not_canceled.get(oid) if isinstance(not_canceled, dict) else None
            err_msg = reason or f"Order {oid} was not canceled (not in response canceled[])"
            code, hint = _classify_poly_clob_error(str(err_msg))
            if code == "ORDER_REJECTED":
                code = "CANCEL_FAILED"
            die("venue_error", code, str(err_msg), hint=hint, exit_code=4)

    return {"order_id": oid, "canceled": True, "response": resp}


register_executor("polymarket", "cancel", execute_poly_cancel)


@polymarket_app.command(name="cancel-all")
def cancel_all(ctx: typer.Context):
    """Cancel all open orders. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    # Note: cancel-all is NOT geo-restricted. Blocked-region users must be
    # able to clear resting orders.

    params = {}
    proposal = create_proposal("polymarket", "cancel-all", params, {}, [])
    output(proposal, opts["fields"])


def execute_poly_cancel_all(params: dict) -> dict:
    """Execute a Polymarket cancel-all from proposal params.

    Same CLOB response shape as cancel: `{canceled: [...], not_canceled: {...}}`.
    If the user had orders but none canceled, that's a hard failure. Partial
    cancellations are returned to the agent with `not_canceled` mapped to each
    order's failure reason — no classification for partials since reasons vary
    per order.
    """
    clob = get_clob_client()

    try:
        resp = clob.cancel_all()
    except Exception as e:
        code, hint = _classify_poly_clob_error(str(e))
        die("venue_error", code if code != "ORDER_REJECTED" else "CANCEL_FAILED",
            str(e), hint=hint, exit_code=4)

    canceled_raw: list = []
    not_canceled: dict = {}
    if isinstance(resp, dict):
        canceled_raw = resp.get("canceled") or []
        not_canceled = resp.get("not_canceled") or {}

    canceled_ids = _extract_order_ids(canceled_raw)

    result: dict = {
        "canceled": canceled_ids,
        "count": len(canceled_ids),
        "response": resp,
    }

    # Hard failure: nothing canceled and we have explicit failure reasons
    if not canceled_ids and not_canceled:
        first_reason = next(iter(not_canceled.values()), "cancel-all returned no canceled orders")
        err_msg = f"No orders canceled. Reasons: {not_canceled}"
        code, hint = _classify_poly_clob_error(str(first_reason))
        if code == "ORDER_REJECTED":
            code = "CANCEL_FAILED"
        die("venue_error", code, err_msg, hint=hint, exit_code=4)

    # Empty both: ambiguous between "no orders existed" and "all canceled" —
    # mark so the agent can distinguish from a real success (count > 0).
    if not canceled_ids and not not_canceled:
        result["no_orders"] = True

    # Partial: surface not_canceled for agent visibility, don't die
    if not_canceled:
        result["not_canceled"] = not_canceled
        result["partial"] = True

    return result


register_executor("polymarket", "cancel-all", execute_poly_cancel_all)


# ---------------------------------------------------------------------------
# Redeem — on-chain redemption of resolved positions
# ---------------------------------------------------------------------------

@polymarket_app.command()
def redeem(ctx: typer.Context):
    """Redeem resolved positions for pUSD. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    try:
        pos_list = get_positions(raise_on_error=True)
    except Exception as e:
        die("venue_error", "FETCH_FAILED", f"Failed to fetch positions: {e}", exit_code=4)

    redeemable = [
        p for p in pos_list
        if p.get("redeemable") and p.get("condition_id")
    ]

    if not redeemable:
        die("validation_error", "NOTHING_TO_REDEEM",
            "No redeemable positions found",
            hint="Positions become redeemable after market resolution",
            exit_code=2)

    positions = []
    for p in redeemable:
        positions.append({
            "condition_id": p["condition_id"],
            "token_id": p["asset_id"],
            "market": p.get("market", ""),
            "outcome": p.get("outcome", ""),
            "size": p["size"],
        })

    params = {"positions": positions}
    warnings = [f"Will redeem {len(positions)} resolved position(s) on-chain"]
    proposal = create_proposal("polymarket", "redeem", params, {}, warnings)
    output(proposal, opts["fields"])


def execute_poly_redeem(params: dict) -> dict:
    """Execute on-chain redemption of resolved positions.

    For each position, resolve the market's collateral (pUSD vs USDC.e) by
    matching candidate CTF position IDs against the user's asset_id. Pre-V2
    markets need USDC.e; post-V2 markets need pUSD. redeemPositions reverts
    with ERC1155 burn-exceeds-balance if the wrong collateral is passed.
    """
    from regard.venues.polymarket.client import resolve_binary_collateral
    results = []
    errors = []
    for pos in params["positions"]:
        try:
            collateral_addr = resolve_binary_collateral(
                pos["condition_id"], pos["token_id"], pos.get("outcome", "yes"),
            )
            result = ctf_redeem(
                pos["condition_id"], float(pos["size"]), pos["token_id"],
                collateral_addr=collateral_addr,
            )
            results.append(result)
        except Exception as e:
            errors.append({
                "condition_id": pos["condition_id"],
                "market": pos.get("market", ""),
                "error": str(e),
            })

    if not results and errors:
        die("venue_error", "REDEEM_FAILED",
            f"All redemptions failed: {errors[0]['error']}",
            exit_code=4)

    resp: dict = {
        "redeemed": results,
        "count": len(results),
    }
    if errors:
        resp["errors"] = errors
    return resp


register_executor("polymarket", "redeem", execute_poly_redeem)


# ---------------------------------------------------------------------------
# Merge — on-chain merge of YES + NO token pairs back to collateral
# ---------------------------------------------------------------------------

@polymarket_app.command()
def merge(ctx: typer.Context):
    """Merge YES + NO token pairs into pUSD. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    try:
        pos_list = get_positions(raise_on_error=True)
    except Exception as e:
        die("venue_error", "FETCH_FAILED", f"Failed to fetch positions: {e}", exit_code=4)

    from regard.venues.polymarket.client import plan_merges
    merges = plan_merges(pos_list)

    if not merges:
        die("validation_error", "NOTHING_TO_MERGE",
            "No mergeable positions found",
            hint="Positions are mergeable when you hold both YES and NO tokens for the same market",
            exit_code=2)

    # Stringify merge_size for proposal serialization
    for m in merges:
        m["merge_size"] = str(m["merge_size"])
        for leg in m["legs"]:
            leg["size"] = str(leg["size"])

    total_recovery = sum(float(m["merge_size"]) for m in merges)
    params = {"merges": merges}
    warnings = [
        f"Will merge {len(merges)} pair(s) on-chain",
        f"Estimated recovery: ~${total_recovery:.2f} pUSD",
    ]
    proposal = create_proposal("polymarket", "merge", params, {}, warnings)
    output(proposal, opts["fields"])


def execute_poly_merge(params: dict) -> dict:
    """Execute on-chain merge of token pairs.

    Resolve per-pair collateral by matching the leg's token_id against
    pUSD- and USDC.e-derived position IDs — applies to all markets routed
    through CTF, including NegRisk-grouped markets (the conditionId from
    Gamma is always a CTF condition).
    """
    from regard.venues.polymarket.client import resolve_binary_collateral

    results = []
    errors = []
    for m in params["merges"]:
        legs = m.get("legs") or []
        token_id = legs[0]["token_id"] if legs else ""
        outcome = legs[0].get("outcome", "yes") if legs else "yes"
        neg_risk = m.get("neg_risk", False)
        try:
            collateral_addr = None
            if token_id:
                collateral_addr = resolve_binary_collateral(
                    m["condition_id"], token_id, outcome,
                )
            result = ctf_merge(
                m["condition_id"], float(m["merge_size"]), token_id,
                neg_risk=neg_risk, collateral_addr=collateral_addr,
            )
            results.append(result)
        except Exception as e:
            errors.append({
                "condition_id": m["condition_id"],
                "market": m.get("market", ""),
                "error": str(e),
            })

    if not results and errors:
        die("venue_error", "MERGE_FAILED",
            f"All merges failed: {errors[0]['error']}",
            exit_code=4)

    total = sum(r["size"] for r in results)
    # Collate collaterals: merges can span multiple markets with different eras
    collaterals = {r.get("collateral", "unknown") for r in results}
    resp: dict = {
        "merged": results,
        "count": len(results),
        "total_collateral": f"{total:.2f}",
        "collateral_tokens": sorted(collaterals),
    }
    if errors:
        resp["errors"] = errors
    return resp


register_executor("polymarket", "merge", execute_poly_merge)


# ---------------------------------------------------------------------------
# Send — wallet-to-wallet transfer on Polygon via address book
# ---------------------------------------------------------------------------


@polygon_app.command("send")
def polygon_send(
    ctx: typer.Context,
    addr: Annotated[str, typer.Argument(help="Address book label, or raw 0x address with --raw")],
    amount: Annotated[str, typer.Argument(help="Amount to send")],
    token: Annotated[str, typer.Option("--token", help="Token: pusd, usdc_e, usdc, or pol")] = "",
    raw: Annotated[bool, typer.Option("--raw", help="Treat addr as a raw 0x address (requires SEND_ALLOW_RAW_ADDRESS)")] = False,
):
    """Send a Polygon-native token (pUSD, USDC.e, USDC, POL) to a labeled address. Creates a proposal."""
    opts = ctx.obj

    from decimal import Decimal

    from regard.commands.address import resolve_address
    from regard.core.audit import log_event
    from regard.core.project_state import load_project_env
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk
    from regard.venues.polymarket.client import _get_key
    from regard.venues.polymarket.tokens import resolve_token

    settings_env = load_project_env()

    # --- Token is required ---
    if not token:
        die("validation_error", "MISSING_TOKEN",
            "Must specify --token (pusd, usdc_e, usdc, or pol)",
            hint="regard polygon send <addr> <amount> --token usdc_e")

    token_info = resolve_token(token)

    # --- Resolve destination ---
    if raw:
        if not settings_env.get("SEND_ALLOW_RAW_ADDRESS"):
            die(
                "validation_error", "RAW_ADDRESS_BLOCKED",
                "Raw addresses are disabled. Use a label from the address book.",
                hint="To enable: set SEND_ALLOW_RAW_ADDRESS=true in settings. Or add the address: regard address add <label> <address>",
            )
        from regard.commands.address import _validate_checksum
        dest_address = _validate_checksum(addr)
        dest_label = "RAW"
    elif addr.startswith("0x"):
        die(
            "validation_error", "RAW_ADDRESS_BLOCKED",
            "Raw 0x addresses require --raw and SEND_ALLOW_RAW_ADDRESS=true.",
            hint="Add a label: regard address add <label> <address>, or pass --raw",
        )
    else:
        dest = resolve_address(addr, "polygon")
        dest_address = dest["address"]
        dest_label = dest["label"]

    # --- Self-send check ---
    import eth_account
    key = _get_key()
    sender = eth_account.Account.from_key(key).address
    if sender.lower() == dest_address.lower():
        die("validation_error", "SELF_SEND", "Cannot send to yourself")

    # Article II: amount stays Decimal end-to-end; raw wei stays int.
    amt = Decimal(amount)

    # --- Safety checks (config gates fire before state checks so users see
    #     their own caps before "insufficient balance") ---
    check_amount_cap(amt, token, settings_env)
    check_daily_cap(amt, token, "polygon", settings_env)
    check_cooldown(dest_address, settings_env)

    # --- Balance check ---
    w3 = get_web3()
    decimals = token_info["decimals"]
    token_unit = Decimal(10 ** decimals)

    if token_info["address"] is None:
        # Native POL — gas paid in the same token, so reserve before comparing.
        balance_raw = w3.eth.get_balance(w3.to_checksum_address(sender))
        balance = Decimal(balance_raw) / token_unit
        gas_reserve_raw = 21_000 * w3.eth.gas_price
        sendable = Decimal(balance_raw - gas_reserve_raw) / token_unit
        if amt > sendable:
            gas_reserve = Decimal(gas_reserve_raw) / Decimal(10**18)
            die("venue_error", "INSUFFICIENT_BALANCE",
                f"POL balance ({balance:.6f}) minus gas reserve ({gas_reserve:.6f}) "
                f"is less than send amount ({amt})",
                exit_code=4)
    else:
        # ERC-20 — gas paid in POL separately.
        from regard.core.evm import get_erc20_balance
        balance_raw = get_erc20_balance(w3, sender, token_info["address"])
        balance = Decimal(balance_raw) / token_unit
        if amt > balance:
            die("venue_error", "INSUFFICIENT_BALANCE",
                f"Balance ({balance} {token}) less than send amount ({amt})",
                exit_code=4)
        # Check POL for gas (raw wei comparison; format displays in Decimal).
        pol_balance_raw = w3.eth.get_balance(w3.to_checksum_address(sender))
        gas_needed_raw = 100_000 * w3.eth.gas_price
        if pol_balance_raw < gas_needed_raw:
            pol_balance = Decimal(pol_balance_raw) / Decimal(10**18)
            gas_needed = Decimal(gas_needed_raw) / Decimal(10**18)
            die("venue_error", "INSUFFICIENT_GAS",
                f"POL balance ({pol_balance:.6f}) insufficient for gas (~{gas_needed:.6f})",
                exit_code=4)

    # --- Risk classification ---
    risk = classify_risk(amt, balance)

    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Sending {amt/balance*100:.0f}% of your {token} balance"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Sending {amt/balance*100:.0f}% of your {token} balance. Approve will require --confirm-addr"})

    amount_raw = int(amt * token_unit)
    params = {
        "sender": sender,
        "dest_address": dest_address,
        "dest_label": dest_label,
        "token": token,
        "token_address": token_info["address"],
        "token_decimals": decimals,
        "amount": str(amt),
        "amount_raw": str(amount_raw),
    }
    checks = {
        "sender": sender,
        "sender_balance": str(balance.quantize(Decimal("0.000001"))),
        "projected_balance": str((balance - amt).quantize(Decimal("0.000001"))),
        "risk": risk,
        "chain": "polygon",
        "token_name": token_info["name"],
    }

    log_event("proposed", command="send", venue="polygon", to=dest_address, to_label=dest_label, token=token, amount=str(amt), risk=risk)
    proposal = create_proposal("polygon", "send", params, checks, warnings)
    output(proposal, opts.get("fields"))


def validate_poly_send_safety(params: dict) -> None:
    """Pre-claim safety re-checks for polygon send (sender key, cooldown, daily cap).

    Called from approve BEFORE claim_proposal so fixable mismatches don't
    consume the pending file. Also invoked by the executor as defense-in-depth.
    """
    from decimal import Decimal

    import eth_account

    from regard.core.project_state import load_project_env
    from regard.core.safety import check_cooldown, check_daily_cap
    from regard.venues.polymarket.client import _get_key

    settings_env = load_project_env()
    check_daily_cap(Decimal(params["amount"]), params["token"], "polygon", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    key = _get_key()
    account = eth_account.Account.from_key(key)
    expected_sender = params.get("sender", "")
    if expected_sender and account.address.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({account.address}) does not match proposal sender ({expected_sender})",
            hint="Set POLYMARKET_PRIVATE_KEY to the same key used when creating the proposal")


def execute_poly_send(params: dict) -> dict:
    """Execute a Polygon send from proposal params."""
    import eth_account

    from regard.core.audit import log_event
    from regard.venues.polymarket.client import _get_key

    # Defense-in-depth: approve runs the same check pre-claim so a mismatch
    # here indicates a race between validator and executor or a direct caller.
    validate_poly_send_safety(params)

    key = _get_key()
    account = eth_account.Account.from_key(key)

    w3 = get_web3()

    dest = params["dest_address"]
    token_address = params.get("token_address")
    amount_raw = int(params["amount_raw"])

    if token_address is None:
        # Native POL
        from regard.core.evm import transfer_native
        tx_hash = transfer_native(w3, account, dest, amount_raw)
    else:
        # ERC-20
        from regard.core.evm import transfer_erc20
        tx_hash = transfer_erc20(w3, account, dest, token_address, amount_raw)

    tx_hex = f"0x{tx_hash.hex()}"

    try:
        log_event("executed", command="send", venue="polygon", to=dest, to_label=params["dest_label"],
                  token=params["token"], amount=params["amount"], tx_hash=tx_hex)
    except Exception as e:
        import sys
        print(f"WARNING: audit log write failed ({e}) — tx was sent: {tx_hex}", file=sys.stderr)

    return {
        "status": "sent",
        "destination": dest,
        "destination_label": params["dest_label"],
        "token": params["token"],
        "token_name": params.get("token_address") and "ERC-20" or "native",
        "amount": params["amount"],
        "tx_hash": tx_hex,
    }


register_executor("polygon", "send", execute_poly_send)
register_safety_validator("polygon", "send", validate_poly_send_safety)
