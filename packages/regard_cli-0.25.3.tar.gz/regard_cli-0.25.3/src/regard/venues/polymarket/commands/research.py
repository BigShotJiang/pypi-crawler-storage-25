"""Research commands — markets, market, book, prices."""

from typing import Annotated

import typer

from regard.core.output import die, make_table, output
from regard.venues.polymarket.client import get_clob_client, get_gamma_client, get_geo_status
from regard.venues.polymarket.main import polymarket_app
from regard.venues.polymarket.market import resolve_market


@polymarket_app.command()
def geo(ctx: typer.Context):
    """Check Polymarket order-placement eligibility from the current IP.

    Queries Polymarket's geoblock endpoint. Returns blocked/country/region plus
    a derived `close_only` flag (true for PL/SG/TH/TW where users can close
    existing positions but not open new ones). Cancel is NOT geo-restricted
    regardless of response.
    """
    import httpx
    opts = ctx.obj
    try:
        data = get_geo_status()
    except httpx.HTTPError as e:
        die("network_error", "GEOBLOCK_UNREACHABLE",
            f"Could not reach geoblock endpoint: {e}",
            hint="Network or endpoint outage. Trading still works from unrestricted regions.",
            exit_code=6)
    output(data, opts["fields"], display=_display_geo(data))


@polymarket_app.command()
def markets(
    ctx: typer.Context,
    query: Annotated[str | None, typer.Argument(help="Search query")] = None,
    limit: Annotated[int, typer.Option("--limit", help="Max results")] = 20,
    active: Annotated[bool, typer.Option("--active/--all", help="Active only")] = True,
):
    """Search and list markets."""
    opts = ctx.obj
    gamma = get_gamma_client()

    # Fetch more than needed when filtering by query (client-side text search)
    fetch_limit = limit * 5 if query else limit
    params = {"limit": fetch_limit, "order": "volume24hr", "ascending": "false"}
    if active:
        params["active"] = "true"
        params["closed"] = "false"

    try:
        resp = gamma.get("/markets", params=params)
        resp.raise_for_status()
        raw = resp.json()
    except Exception as e:
        die("venue_error", "FETCH_FAILED", f"Gamma API error: {e}", exit_code=4)

    # Client-side text filter (Gamma API search is unreliable)
    if query:
        q = query.lower()
        raw = [m for m in raw if q in m.get("question", "").lower()][:limit]

    result = []
    for m in raw:
        import json
        raw_clob = m.get("clobTokenIds", "[]")
        clob_ids = json.loads(raw_clob) if isinstance(raw_clob, str) else (raw_clob or [])
        raw_prices = m.get("outcomePrices", "[]")
        outcome_prices = json.loads(raw_prices) if isinstance(raw_prices, str) else (raw_prices or [])
        result.append({
            "market_id": m.get("id", ""),
            "question": m.get("question", ""),
            "yes_price": outcome_prices[0] if outcome_prices else "",
            "no_price": outcome_prices[1] if len(outcome_prices) > 1 else "",
            "volume_24h": m.get("volume24hr", ""),
            "liquidity": m.get("liquidityNum", ""),
            "end_date": m.get("endDateIso", ""),
            "active": m.get("active", False),
            "yes_token_id": clob_ids[0] if clob_ids else "",
        })

    output(result, opts["fields"], display=_display_markets(result))


@polymarket_app.command()
def market(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID, condition ID, slug, or search query")],
):
    """Get detailed market info."""
    opts = ctx.obj
    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)
    output(m, opts["fields"], display=_display_market(m))


@polymarket_app.command()
def book(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID or condition ID")],
    outcome: Annotated[str, typer.Option("--outcome", help="yes or no")] = "yes",
    depth: Annotated[int, typer.Option("--depth", help="Levels per side")] = 10,
):
    """Order book for a market outcome."""
    opts = ctx.obj
    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)

    token_id = m["yes_token_id"] if outcome.lower() == "yes" else m["no_token_id"]
    if not token_id:
        die("validation_error", "NO_TOKEN", f"No {outcome} token found for this market", exit_code=2)

    clob = get_clob_client()
    ob = clob.get_order_book(token_id)

    raw_bids = ob.get("bids", []) if isinstance(ob, dict) else ob.bids
    raw_asks = ob.get("asks", []) if isinstance(ob, dict) else ob.asks
    bids = [{"price": str(b["price"] if isinstance(b, dict) else b.price),
             "size": str(b["size"] if isinstance(b, dict) else b.size)} for b in raw_bids[:depth]]
    asks = [{"price": str(a["price"] if isinstance(a, dict) else a.price),
             "size": str(a["size"] if isinstance(a, dict) else a.size)} for a in raw_asks[:depth]]

    result = {
        "question": m["question"],
        "outcome": outcome,
        "token_id": token_id,
        "bids": bids,
        "asks": asks,
    }
    output(result, opts["fields"], display=_display_book(result))


@polymarket_app.command()
def event(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Event ID, slug, or search query")],
):
    """List all markets within an event — natural hedge pairs."""
    opts = ctx.obj
    gamma = get_gamma_client()

    # Try by event ID
    event_data = None
    if identifier.isdigit():
        try:
            resp = gamma.get(f"/events/{identifier}")
            if resp.status_code == 200:
                event_data = resp.json()
        except Exception:
            pass

    # Try by slug
    if not event_data:
        try:
            resp = gamma.get("/events", params={"slug": identifier, "limit": 1})
            events = resp.json()
            if events:
                event_data = events[0]
        except Exception:
            pass

    # Fallback: search by title across top events by volume
    if not event_data:
        try:
            resp = gamma.get("/events", params={
                "limit": 100, "active": "true", "closed": "false",
                "order": "volume24hr", "ascending": "false",
            })
            events = resp.json()
        except Exception as e:
            die("venue_error", "FETCH_FAILED", f"Gamma API error: {e}", exit_code=4)
        q = identifier.lower()
        for e in events:
            if q in e.get("title", "").lower():
                event_data = e
                break

    if not event_data:
        die("validation_error", "UNKNOWN_EVENT", f"No event found for '{identifier}'", exit_code=2)

    import json as json_mod
    event_markets = event_data.get("markets", [])
    result_markets = []
    for m in event_markets:
        clob_ids = json_mod.loads(m.get("clobTokenIds", "[]")) if isinstance(m.get("clobTokenIds"), str) else m.get("clobTokenIds", [])
        outcome_prices = json_mod.loads(m.get("outcomePrices", "[]")) if isinstance(m.get("outcomePrices"), str) else m.get("outcomePrices", [])
        result_markets.append({
            "market_id": m.get("id", ""),
            "question": m.get("question", ""),
            "yes_price": outcome_prices[0] if outcome_prices else "",
            "no_price": outcome_prices[1] if len(outcome_prices) > 1 else "",
            "volume_24h": m.get("volume24hr", ""),
            "active": m.get("active", False),
            "accepting_orders": m.get("acceptingOrders", False),
            "yes_token_id": clob_ids[0] if clob_ids else "",
        })

    # Sort by volume
    result_markets.sort(key=lambda x: float(x["volume_24h"] or "0"), reverse=True)

    result = {
        "event_id": event_data.get("id", ""),
        "title": event_data.get("title", ""),
        "slug": event_data.get("slug", ""),
        "markets": result_markets,
        "market_count": len(result_markets),
    }
    output(result, opts["fields"], display=_display_event(result))


@polymarket_app.command()
def prices(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Market ID or condition ID")],
):
    """Current prices for a market."""
    opts = ctx.obj
    gamma = get_gamma_client()
    m = resolve_market(identifier, gamma)
    if not m:
        die("validation_error", "UNKNOWN_MARKET", f"No market found for '{identifier}'", exit_code=2)

    result = {
        "question": m["question"],
        "yes_price": m["yes_price"],
        "no_price": m["no_price"],
        "best_bid": m["best_bid"],
        "best_ask": m["best_ask"],
        "volume_24h": m["volume_24h"],
        "liquidity": m["liquidity"],
    }
    output(result, opts["fields"], display=_display_prices(result))


# ---------------------------------------------------------------------------
# Display builders
# ---------------------------------------------------------------------------

_MARKETS_COLS = [
    ("question", "Question", "<"),
    ("yes_price", "Yes", ">"),
    ("no_price", "No", ">"),
    ("volume_24h", "24h Volume", ">"),
    ("end_date", "Ends", "<"),
]

_EVENT_MARKET_COLS = [
    ("question", "Question", "<"),
    ("yes_price", "Yes", ">"),
    ("no_price", "No", ">"),
    ("volume_24h", "24h Volume", ">"),
]


def _shorten(s: str, width: int = 44) -> str:
    if not s or len(s) <= width:
        return s
    return s[: width - 1] + "…"


def _fmt_vol(v) -> str:
    """Render volume as $X.XXM / $X.Xk / $N."""
    try:
        n = float(v)
    except (TypeError, ValueError):
        return str(v or "")
    if n >= 1_000_000:
        return f"${n / 1_000_000:.2f}M"
    if n >= 1_000:
        return f"${n / 1_000:.1f}k"
    return f"${n:.0f}"


def _fmt_date(s: str) -> str:
    """Trim ISO timestamp to YYYY-MM-DD for table display."""
    if not s:
        return ""
    return s[:10]


def _display_geo(data: dict) -> str:
    status = "BLOCKED" if data.get("blocked") else "allowed"
    close_only = " (close-only)" if data.get("close_only") else ""
    return (
        f"Status   {status}{close_only}\n"
        f"Country  {data.get('country', '?')}\n"
        f"Region   {data.get('region', '?')}\n"
        f"IP       {data.get('ip', '?')}"
    )


def _display_markets(markets: list[dict]) -> str:
    if not markets:
        return "No markets matched"
    rows = [
        {
            **m,
            "question": _shorten(m.get("question", "")),
            "volume_24h": _fmt_vol(m.get("volume_24h")),
            "end_date": _fmt_date(m.get("end_date", "")),
        }
        for m in markets
    ]
    return make_table(rows, _MARKETS_COLS)


def _display_market(m: dict) -> str:
    lines = [
        f"{m.get('question', '?')}",
        f"  market_id    {m.get('market_id', '?')}",
        f"  slug         {m.get('slug', '?')}",
        f"  condition    {m.get('condition_id', '?')}",
        "",
        f"  Yes          {m.get('yes_price', '?')}   bid {m.get('best_bid', '?')} / ask {m.get('best_ask', '?')}",
        f"  No           {m.get('no_price', '?')}",
        f"  24h volume   {_fmt_vol(m.get('volume_24h'))}",
        f"  Liquidity    {_fmt_vol(m.get('liquidity'))}",
        f"  Tick size    {m.get('tick_size', '?')}",
        f"  Min order    {m.get('min_order_size', '?')}",
        f"  Accepting    {m.get('accepting_orders', '?')}  (neg_risk={m.get('neg_risk', '?')})",
        f"  Ends         {_fmt_date(m.get('end_date', ''))}",
    ]
    if m.get("fees_enabled"):
        sched = m.get("fee_schedule") or {}
        rate = sched.get("rate")
        fee_type = m.get("fee_type") or "?"
        if rate is not None:
            try:
                lines.append(f"  Fee          {float(rate) * 100:.2f}% taker ({fee_type})")
            except (TypeError, ValueError):
                lines.append(f"  Fee          enabled ({fee_type})")
        else:
            lines.append(f"  Fee          enabled ({fee_type})")
    return "\n".join(lines)


def _display_book(data: dict) -> str:
    bids = data.get("bids", [])
    asks = data.get("asks", [])
    depth = max(len(bids), len(asks))
    lines = [
        f"{data.get('question', '?')}",
        f"Outcome: {data.get('outcome', '?')}",
        "",
    ]
    if depth == 0:
        lines.append("(empty book)")
        return "\n".join(lines)
    # Render bids and asks side-by-side up to depth rows
    header = f"{'Bid price':>10}  {'Bid size':>10}    {'Ask price':>10}  {'Ask size':>10}"
    sep = "─" * 10 + "  " + "─" * 10 + "    " + "─" * 10 + "  " + "─" * 10
    lines.append(header)
    lines.append(sep)
    for i in range(depth):
        b = bids[i] if i < len(bids) else {"price": "", "size": ""}
        a = asks[i] if i < len(asks) else {"price": "", "size": ""}
        lines.append(
            f"{str(b.get('price', '')):>10}  {str(b.get('size', '')):>10}    "
            f"{str(a.get('price', '')):>10}  {str(a.get('size', '')):>10}"
        )
    return "\n".join(lines)


def _display_event(data: dict) -> str:
    lines = [
        f"{data.get('title', '?')}",
        f"  event_id   {data.get('event_id', '?')}",
        f"  slug       {data.get('slug', '?')}",
        f"  Markets    {data.get('market_count', 0)}",
    ]
    markets = data.get("markets", [])
    if markets:
        # Show top 10 by volume (already sorted in command)
        sample = markets[:10]
        rows = [
            {
                **m,
                "question": _shorten(m.get("question", "")),
                "volume_24h": _fmt_vol(m.get("volume_24h")),
            }
            for m in sample
        ]
        lines.append("")
        lines.append(make_table(rows, _EVENT_MARKET_COLS))
        if len(markets) > 10:
            lines.append(f"... {len(markets) - 10} more")
    return "\n".join(lines)


def _display_prices(data: dict) -> str:
    return (
        f"{data.get('question', '?')}\n"
        f"  Yes        {data.get('yes_price', '?')}   bid {data.get('best_bid', '?')} / ask {data.get('best_ask', '?')}\n"
        f"  No         {data.get('no_price', '?')}\n"
        f"  24h vol    {_fmt_vol(data.get('volume_24h'))}\n"
        f"  Liquidity  {_fmt_vol(data.get('liquidity'))}"
    )
