"""Orient commands — status, balance, positions, orders."""

import typer
from pydantic import ValidationError

from regard.core.output import make_table, output
from regard.venues.polymarket.client import (
    check_approvals,
    get_clob_client,
    get_collateral_token,
    get_positions,
    get_wallet_balances,
)
from regard.venues.polymarket.main import polymarket_app
from regard.venues.polymarket.models import ClobOrder


def _get_balance(clob):
    from py_clob_client_v2.clob_types import AssetType, BalanceAllowanceParams
    return clob.get_balance_allowance(BalanceAllowanceParams(asset_type=AssetType.COLLATERAL))


# Both pUSD and USDC.e are 6-decimal ERC20s. The CLOB's get_balance_allowance
# returns the balance field as raw base units (stringified int). Presenting
# that raw number as dollars (e.g. "9990000" for 9.99 pUSD) is misleading.
# Normalize before display / equity aggregation.
_PUSD_DECIMALS = 6


def _normalize_clob_balance(raw) -> str:
    """Convert raw 6-decimal CLOB balance string/int to a human pUSD string.

    Returns "0.00" on any parse error — balance is informational-only in the
    briefing, not a trade precondition (those use on-chain reads).
    """
    if raw is None:
        return "0.00"
    try:
        return f"{int(str(raw)) / 10**_PUSD_DECIMALS:.6f}"
    except (ValueError, TypeError):
        return "0.00"


@polymarket_app.command()
def status(ctx: typer.Context):
    """Account overview — balance, positions, open orders. CLOB sections fail-open if unreachable (e.g. fresh wallet without a derived API key)."""
    opts = ctx.obj
    clob = None
    clob_error: str | None = None
    try:
        clob = get_clob_client()
    except SystemExit:
        raise
    except Exception as e:
        clob_error = str(e)

    # Balance (USDC allowance on CLOB)
    balance_resp: dict = {}
    if clob is not None:
        try:
            balance_resp = _get_balance(clob)
        except SystemExit:
            raise
        except Exception:
            balance_resp = {}

    # Open orders
    open_orders: list = []
    if clob is not None:
        try:
            open_orders = clob.get_open_orders()
        except SystemExit:
            raise
        except Exception:
            open_orders = []
    orders = []
    for o in (open_orders if isinstance(open_orders, list) else []):
        try:
            ClobOrder.model_validate(o)
        except ValidationError:
            pass
        orders.append({
            "order_id": o.get("id", ""),
            "market": o.get("market", ""),
            "asset_id": o.get("asset_id", ""),
            "side": o.get("side", ""),
            "price": o.get("price", ""),
            "original_size": o.get("original_size", ""),
            "size_matched": o.get("size_matched", ""),
            "status": o.get("status", ""),
        })

    # On-chain wallet balances + collateral token (best-effort)
    try:
        collateral = get_collateral_token()
    except Exception:
        collateral = {"name": "pUSD", "address": "", "source": "fallback"}

    try:
        wallet = get_wallet_balances()
    except Exception:
        wallet = {"pusd": "?", "usdc_e": "?", "usdc": "?", "pol": "?"}

    # On-chain approval state (best-effort — fail-open like wallet balances).
    # Surfaces enough info for the agent to avoid proposing `regard polymarket approve`
    # when it would be a no-op. Full RPC failure marks all slots unknown.
    try:
        approvals = check_approvals()
    except Exception:
        approvals = {
            "all_set": False,
            "count_set": 0,
            "count_total": 7,
            "missing": [],
            "unknown": [],
            "detail": {},
        }

    result: dict = {
        "collateral_token": collateral["name"],
        "wallet": wallet,
        "clob_balance": _normalize_clob_balance(balance_resp.get("balance")) if isinstance(balance_resp, dict) else "0.00",
        "open_orders": orders,
        "open_order_count": len(orders),
        "approvals": approvals,
    }
    if clob_error:
        result["clob_error"] = clob_error
    output(result, opts["fields"], display=_display_status(result))


@polymarket_app.command()
def balance(ctx: typer.Context):
    """USDC balance and allowance on Polymarket. Falls back to on-chain wallet only if CLOB unreachable."""
    opts = ctx.obj
    clob_balance: str | None = "0.00"
    allowances: dict = {}
    clob_error: str | None = None
    try:
        clob = get_clob_client()
        clob_resp = _get_balance(clob)
        if isinstance(clob_resp, dict):
            clob_balance = _normalize_clob_balance(clob_resp.get("balance"))
            allowances = clob_resp.get("allowances", {})
    except SystemExit:
        raise
    except Exception as e:
        clob_balance = None
        clob_error = str(e)

    try:
        wallet = get_wallet_balances()
    except Exception:
        wallet = {"pusd": "?", "usdc_e": "?", "usdc": "?", "pol": "?"}

    result: dict = {
        "wallet": wallet,
        "clob_balance": clob_balance,
        "allowances": allowances,
    }
    if clob_error:
        result["clob_error"] = clob_error
    output(result, opts["fields"], display=_display_balance(result))


@polymarket_app.command()
def positions(ctx: typer.Context):
    """Open token positions."""
    opts = ctx.obj

    pos_list = get_positions()

    result = []
    for p in pos_list:
        result.append({
            "asset_id": p.get("asset_id", ""),
            "market": p.get("market", ""),
            "side": p.get("side", ""),
            "size": p.get("size", ""),
            "avg_price": p.get("avg_price", ""),
            "cur_price": p.get("cur_price", ""),
            "pnl": p.get("pnl", ""),
        })

    output(result, opts["fields"], display=_display_positions(result))


@polymarket_app.command()
def orders(ctx: typer.Context):
    """Open orders. Fails open if CLOB unreachable (fresh wallet without a derived API key)."""
    opts = ctx.obj
    clob = None
    clob_error: str | None = None
    try:
        clob = get_clob_client()
    except SystemExit:
        raise
    except Exception as e:
        clob_error = str(e)

    open_orders: list = []
    if clob is not None:
        try:
            fetched = clob.get_open_orders()
            if isinstance(fetched, list):
                open_orders = fetched
        except SystemExit:
            raise
        except Exception as e:
            clob_error = str(e)

    orders_list = []
    for o in open_orders:
        try:
            ClobOrder.model_validate(o)
        except ValidationError:
            pass
        orders_list.append({
            "order_id": o.get("id", ""),
            "market": o.get("market", ""),
            "asset_id": o.get("asset_id", ""),
            "side": o.get("side", ""),
            "price": o.get("price", ""),
            "original_size": o.get("original_size", ""),
            "size_matched": o.get("size_matched", ""),
            "status": o.get("status", ""),
            "created_at": o.get("created_at", ""),
        })

    result: dict = {"orders": orders_list, "open_order_count": len(orders_list)}
    if clob_error:
        result["clob_error"] = clob_error
    output(result, opts["fields"], display=_display_orders(result))


# ---------------------------------------------------------------------------
# Display builders
# ---------------------------------------------------------------------------

_POSITION_COLS = [
    ("market", "Market", "<"),
    ("side", "Side", "<"),
    ("size", "Size", ">"),
    ("avg_price", "Avg", ">"),
    ("cur_price", "Cur", ">"),
    ("pnl", "PnL", ">"),
]

_ORDER_COLS = [
    ("market", "Market", "<"),
    ("side", "Side", "<"),
    ("price", "Price", ">"),
    ("original_size", "Size", ">"),
    ("size_matched", "Filled", ">"),
    ("status", "Status", "<"),
]


def _shorten(s: str, width: int = 18) -> str:
    """Abbreviate a long hex/question string for table display."""
    if not s or len(s) <= width:
        return s
    return s[: width - 1] + "…"


def _display_wallet_lines(wallet: dict) -> list[str]:
    return [
        f"  pUSD     {wallet.get('pusd', '?')}",
        f"  USDC.e   {wallet.get('usdc_e', '?')}  (wrappable)",
        f"  USDC     {wallet.get('usdc', '?')}",
        f"  POL      {wallet.get('pol', '?')}",
    ]


def _approval_status_line(approvals: dict) -> str:
    """One-line summary of the approval block for the status display."""
    if not approvals:
        return "Approvals    ?"
    total = approvals.get("count_total", 7)
    set_ct = approvals.get("count_set", 0)
    unknown = approvals.get("unknown", [])
    missing = approvals.get("missing", [])
    if approvals.get("all_set"):
        return f"Approvals    {set_ct}/{total} set"
    if unknown and not missing:
        return f"Approvals    {set_ct}/{total} set — {len(unknown)} unknown (RPC read failed)"
    hint = " — run 'regard polymarket approve'"
    if unknown:
        return f"Approvals    {set_ct}/{total} set ({len(missing)} missing, {len(unknown)} unknown){hint}"
    return f"Approvals    {set_ct}/{total} set ({len(missing)} missing){hint}"


def _display_status(data: dict) -> str:
    lines = [
        f"Collateral   {data.get('collateral_token', '?')}",
        f"CLOB balance {data.get('clob_balance', '?')}",
        _approval_status_line(data.get("approvals", {})),
        "",
        "Wallet",
        *_display_wallet_lines(data.get("wallet", {})),
        "",
        f"Open orders  {data.get('open_order_count', 0)}",
    ]
    orders = data.get("open_orders", [])
    if orders:
        rows = [{**o, "market": _shorten(o.get("market", ""))} for o in orders]
        lines.append(make_table(rows, _ORDER_COLS))
    if "clob_error" in data:
        lines.append("")
        lines.append(f"CLOB error: {data['clob_error']}")
    return "\n".join(lines)


def _display_balance(data: dict) -> str:
    lines = [
        f"CLOB balance {data.get('clob_balance') if data.get('clob_balance') is not None else '(unavailable)'}",
        "",
        "Wallet",
        *_display_wallet_lines(data.get("wallet", {})),
    ]
    allowances = data.get("allowances", {}) or {}
    if allowances:
        lines.append("")
        lines.append(f"Allowances   {len(allowances)} contract(s)")
    if "clob_error" in data:
        lines.append("")
        lines.append(f"CLOB error: {data['clob_error']}")
    return "\n".join(lines)


def _display_positions(positions: list[dict]) -> str:
    if not positions:
        return "No open positions"
    rows = [{**p, "market": _shorten(p.get("market", ""))} for p in positions]
    return make_table(rows, _POSITION_COLS)


def _display_orders(data: dict) -> str:
    orders = data.get("orders", [])
    if not orders:
        suffix = ""
        if "clob_error" in data:
            suffix = f"\nCLOB error: {data['clob_error']}"
        return "No open orders" + suffix
    rows = [{**o, "market": _shorten(o.get("market", ""))} for o in orders]
    return make_table(rows, _ORDER_COLS)
