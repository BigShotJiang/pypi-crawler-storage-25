"""Polymarket venue compatibility shim.

The CLI exposes two top-level apps for the Polymarket ecosystem:

- `polymarket_app` (defined in `regard.main`) — venue-level trading commands
  (orders, cancels, approvals, positions, redemptions, merges, market lookups).
- `polygon_app` (defined in `regard.main`) — Polygon chain operations
  (token transfers, sends).

This module re-exports both apps so existing imports continue to work as the
command-registration sites in `commands/act.py`, `orient.py`, `research.py`,
and `review.py` migrate to the new vocabulary.
"""

from regard.main import polygon_app, polymarket_app

__all__ = ["polygon_app", "polymarket_app"]
