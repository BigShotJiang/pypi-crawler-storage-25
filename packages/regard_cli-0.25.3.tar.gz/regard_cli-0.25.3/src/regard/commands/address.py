"""Address book — labeled destinations for send commands.

All send commands resolve destinations from this address book. Addresses not
in the book are blocked by default (SEND_ALLOW_RAW_ADDRESS opt-in for Tier 2).

Mutations (add, remove) go through the proposal flow and are audit-logged.
"""

import time
from pathlib import Path
from typing import Annotated

import typer

from regard.core.audit import log_event
from regard.core.output import die, output
from regard.core.project_dir import find_project_dir
from regard.core.project_state import load_config, save_config
from regard.core.proposal import create_proposal, register_executor

address_app = typer.Typer(
    name="address",
    no_args_is_help=True,
    help="Manage the address book for send commands.",
    pretty_exceptions_enable=False,
)


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------

def _project_dir_for_save() -> Path:
    """Project root for address-book writes — existing project found by
    walk-up, else CWD as the bootstrap target.
    """
    found = find_project_dir()
    return found if found is not None else Path.cwd()


def _load_addresses() -> dict:
    """Load address book from `<project>/.regard/config.json`."""
    return load_config().get("addresses", {})


def _save_addresses(addresses: dict) -> None:
    """Write address book back to config.json (atomic replace).

    Preserves the rest of the config file (env block, future keys).
    """
    project_dir = _project_dir_for_save()
    config = load_config()
    config["addresses"] = addresses
    save_config(config, project_dir)


def resolve_address(label: str, chain: str) -> dict:
    """Resolve a label to an address entry. Dies if not found or wrong chain.

    Returns: {"label": str, "address": str, "chains": list}
    """
    addresses = _load_addresses()
    entry = addresses.get(label)
    if not entry:
        available = ", ".join(addresses) if addresses else "(none configured)"
        die(
            "validation_error", "UNKNOWN_ADDRESS",
            f"Address label '{label}' not found in address book. Available: {available}",
            hint="Add it first: regard address add <label> <address>",
        )
    if chain not in entry.get("chains", []):
        die(
            "validation_error", "CHAIN_MISMATCH",
            f"Address '{label}' is not tagged for chain '{chain}'. Tagged: {entry.get('chains', [])}",
            hint=f"Re-add with correct chain: regard address add {label} {entry['address']} --chain {chain}",
        )
    return {"label": label, "address": entry["address"], "chains": entry["chains"]}


def _validate_checksum(address: str) -> str:
    """Validate, EIP-55-checksum-check, and normalize an EVM address.

    See `core.eth_address.validate_address` for the full contract:
    mixed-case wrong checksum -> reject; lowercase/uppercase -> normalize;
    correct checksum -> accept.
    """
    from regard.core.eth_address import validate_address
    return validate_address(address, label="address")


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@address_app.command()
def add(
    ctx: typer.Context,
    label: Annotated[str, typer.Argument(help="Human-readable label (e.g. 'trading', 'reserve')")],
    address: Annotated[str, typer.Argument(help="EIP-55 checksummed Ethereum/Polygon address")],
    chain: Annotated[str, typer.Option("--chain", help="Chain tag: hypercore, polygon, arbitrum, hyperevm, or 'both' (= hypercore + polygon only; use explicit flags for arbitrum/hyperevm)")] = "both",
):
    """Add an address to the book. Creates a proposal."""
    opts = ctx.obj or {}

    # Validate
    address = _validate_checksum(address)

    if chain == "both":
        chains = ["hypercore", "polygon"]
    elif chain in ("hypercore", "polygon", "arbitrum", "hyperevm"):
        chains = [chain]
    else:
        die("validation_error", "INVALID_CHAIN",
            f"Chain must be 'hypercore', 'polygon', 'arbitrum', 'hyperevm', or 'both'. Got: {chain}")
        return  # unreachable, for type checker

    # Check for duplicate label
    existing = _load_addresses()
    if label in existing:
        die(
            "validation_error", "LABEL_EXISTS",
            f"Label '{label}' already exists (address: {existing[label]['address']}). Remove it first.",
            hint=f"regard address remove {label}",
        )

    params = {
        "label": label,
        "address": address,
        "chains": chains,
    }

    log_event("proposed", command="address-add", label=label, address=address, chains=chains)
    proposal = create_proposal("address", "add", params, {}, [])
    output(proposal, opts.get("fields"))


@address_app.command(name="list")
def list_addresses(ctx: typer.Context):
    """Show all addresses in the book."""
    opts = ctx.obj or {}
    addresses = _load_addresses()

    result = []
    for label, entry in sorted(addresses.items()):
        result.append({
            "label": label,
            "address": entry["address"],
            "chains": entry.get("chains", []),
            "added_at": entry.get("added_at", ""),
        })

    output(result, opts.get("fields"))


@address_app.command()
def remove(
    ctx: typer.Context,
    label: Annotated[str, typer.Argument(help="Label to remove")],
):
    """Remove an address from the book. Creates a proposal."""
    opts = ctx.obj or {}

    existing = _load_addresses()
    if label not in existing:
        die("validation_error", "UNKNOWN_ADDRESS", f"Label '{label}' not in address book")

    entry = existing[label]
    params = {
        "label": label,
        "address": entry["address"],
    }

    log_event("proposed", command="address-remove", label=label, address=entry["address"])
    proposal = create_proposal("address", "remove", params, {}, [])
    output(proposal, opts.get("fields"))


# ---------------------------------------------------------------------------
# Executors
# ---------------------------------------------------------------------------

def execute_add(params: dict) -> dict:
    """Execute address add — store in settings."""
    label = params["label"]
    address = params["address"]
    chains = params["chains"]

    addresses = _load_addresses()
    addresses[label] = {
        "address": address,
        "chains": chains,
        "added_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    _save_addresses(addresses)

    log_event("executed", command="address-add", label=label, address=address, chains=chains)
    return {"label": label, "address": address, "chains": chains, "status": "added"}


def execute_remove(params: dict) -> dict:
    """Execute address remove — delete from settings."""
    label = params["label"]
    address = params["address"]

    addresses = _load_addresses()
    addresses.pop(label, None)
    _save_addresses(addresses)

    log_event("executed", command="address-remove", label=label, address=address)
    return {"label": label, "status": "removed"}


register_executor("address", "add", execute_add)
register_executor("address", "remove", execute_remove)
