"""Wallet setup — single-key onboarding, project-local scope.

Saves one EVM private key to `<project>/.regard/secrets/wallet.json`.
The same key signs for Hyperliquid and Polymarket. Multi-instance
isolation is the default — each project directory has its own wallet.

Run in a separate terminal, `cd`'d to the project directory the agent is
operating on. Keys never enter the conversation transcript.

Usage:
    regard wallet               — check current wallet (structured JSON)
    regard wallet <0x-key>      — save key for this project
    regard wallet --prompt      — save key via hidden terminal input
    regard wallet --export      — emit `export` lines for shells without env auto-injection (Codex CLI)
"""

import getpass
import os
import shlex
import sys
from pathlib import Path
from typing import Annotated

import typer

from regard.core.project_dir import find_project_dir
from regard.core.project_state import load_project_env, load_wallet, save_wallet

wallet_app = typer.Typer(
    name="wallet",
    invoke_without_command=True,
    no_args_is_help=False,
    help="Wallet setup. Bare `regard wallet` reports status; `regard wallet <key>` saves a key.",
)


def _validate_hex_key(key: str) -> str:
    """Return normalized 0x-prefixed key or empty string if invalid."""
    key = key.strip()
    if key.startswith("0x"):
        key = key[2:]
    if len(key) != 64:
        return ""
    try:
        int(key, 16)
    except ValueError:
        return ""
    return "0x" + key


def _project_dir_for_save() -> Path:
    """Project root for wallet writes — existing project found by walk-up,
    else CWD as the bootstrap target.

    The bootstrap target is how `regard wallet` creates `.regard/` for the
    first time in a fresh project directory. After first save, walk-up
    from any subdirectory finds the same project.

    Refuses to bootstrap at $HOME: `find_project_dir()` stops walking
    BEFORE $HOME, so a wallet saved to `~/.regard/secrets/wallet.json`
    would be invisible to every subsequent CLI invocation. Catch that
    case here with a clear error rather than silently writing to a
    location no other command will ever read.
    """
    found = find_project_dir()
    if found is not None:
        return found
    cwd = Path.cwd().resolve()
    try:
        home = Path.home().resolve()
    except Exception:
        home = None
    if home is not None and cwd == home:
        print()
        print("Error: cannot save a wallet at $HOME.", file=sys.stderr)
        print("regard projects are project-local — `cd` into a project directory first,", file=sys.stderr)
        print("then re-run `regard wallet`. (`mkdir -p ~/my-project && cd ~/my-project` works.)", file=sys.stderr)
        raise SystemExit(1)
    return cwd


def _report_status() -> None:
    """Emit structured JSON about whether a wallet is configured."""
    from regard.core.output import output as _output

    env = load_project_env()
    hl_key = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or env.get("HYPERLIQUID_PRIVATE_KEY")
    poly_key = os.environ.get("POLYMARKET_PRIVATE_KEY") or env.get("POLYMARKET_PRIVATE_KEY")

    def _address_of(k: str | None) -> str | None:
        if not k:
            return None
        try:
            import eth_account
            return eth_account.Account.from_key(k).address
        except Exception:
            return None

    hl_addr = _address_of(hl_key)
    poly_addr = _address_of(poly_key)

    result: dict = {"venues": {}}
    result["venues"]["hyperliquid"] = (
        {"configured": True, "address": hl_addr} if hl_key
        else {"configured": False, "setup_command": "regard wallet <key>"}
    )
    result["venues"]["polymarket"] = (
        {"configured": True, "address": poly_addr} if poly_key
        else {"configured": False, "setup_command": "regard wallet <key>"}
    )

    if hl_addr and hl_addr == poly_addr:
        result["address"] = hl_addr
        result["unified_key"] = True

    _output(result, None)


def _export_shell_vars() -> None:
    """Emit shell-eval-able `export` lines for each configured key.

    Output format is POSIX-compatible `export KEY=VALUE`, one line per
    venue, to stdout. Errors go to stderr so `eval "$(regard wallet --export)"`
    stays clean under failure. No file writes, no network calls.

    Designed for harnesses without env auto-injection (Codex CLI, plain
    shell, CI).
    """
    env = load_project_env()
    hl_key = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or env.get("HYPERLIQUID_PRIVATE_KEY")
    poly_key = os.environ.get("POLYMARKET_PRIVATE_KEY") or env.get("POLYMARKET_PRIVATE_KEY")

    if not hl_key and not poly_key:
        print("Error: no wallet found in env or .regard/secrets/wallet.json.", file=sys.stderr)
        print("Run `regard wallet <key>` first (in a project dir) to save a wallet, then retry.", file=sys.stderr)
        raise SystemExit(1)

    # shlex.quote on each value — defense in depth against shell injection
    # via wallet.json or config.json contents. wallet.json keys are validated
    # by `_validate_hex_key` on save (must be 0x + 64 hex), but config.json
    # is hand-editable and an `env.HYPERLIQUID_PRIVATE_KEY` override would
    # otherwise reach `eval` unquoted.
    print('# regard wallet --export — eval "$(regard wallet --export)" to load keys into shell env')
    if hl_key:
        print(f"export HYPERLIQUID_PRIVATE_KEY={shlex.quote(hl_key)}")
    if poly_key:
        print(f"export POLYMARKET_PRIVATE_KEY={shlex.quote(poly_key)}")


def _save_key(normalized: str) -> None:
    """Derive + display address, persist wallet.

    Address derivation is mandatory: if eth_account rejects the key (valid
    hex but not a valid secp256k1 scalar — e.g. all-zero or above curve
    order), abort instead of saving an unusable wallet that would surface
    a cryptic error at the next trading command.
    """
    import eth_account
    try:
        address = eth_account.Account.from_key(normalized).address
    except Exception as e:
        print()
        print(f"  Key is valid hex but not a valid secp256k1 scalar: {e}", file=sys.stderr)
        print("  Check for typos or try generating a fresh wallet.", file=sys.stderr)
        raise SystemExit(1)

    print()
    print(f"  Wallet address: {address}")

    project_dir = _project_dir_for_save()

    # Preserve any other top-level fields (e.g. future `solana` block) on re-save
    existing = load_wallet()
    existing["evm"] = {
        "private_key": normalized,
        "address": address,
    }
    path = save_wallet(existing, project_dir)

    print()
    print(f"  Saved to {path}")
    print()
    print("  Return to your agent in this project directory.")
    print("  The key is picked up automatically on the next command.")
    print()


@wallet_app.callback(invoke_without_command=True)
def wallet(
    key: Annotated[str | None, typer.Argument(help="EVM private key (0x + 64 hex). Omit for status, or use --prompt for hidden input.")] = None,
    prompt: Annotated[bool, typer.Option("--prompt", help="Read key from hidden terminal input (getpass).")] = False,
    export: Annotated[bool, typer.Option("--export", help='Emit shell `export` lines so keys flow into harnesses without env auto-injection (Codex CLI, plain shell). Use: eval "$(regard wallet --export)". Errors go to stderr so eval stays clean. No file writes, no network.')] = False,
):
    """Save one EVM private key for all trading venues in this project, or check status.

    The same wallet key signs for Hyperliquid and Polymarket. Writes to
    `<project>/.regard/secrets/wallet.json` — project-local, so each
    project directory has its own wallet.

    Run this in a separate terminal, `cd`'d to the same project directory
    the agent is operating on. Keys never appear in the conversation
    transcript.

    Modes:
      regard wallet              → report status (JSON)
      regard wallet <0x-key>     → save key (args visible — use --prompt for privacy)
      regard wallet --prompt     → save key via hidden terminal input
      regard wallet --export     → emit `export` lines for shell eval (Codex CLI etc.)
    """
    if export:
        if key is not None or prompt:
            print("Error: --export does not take a key argument or --prompt.", file=sys.stderr)
            raise SystemExit(1)
        _export_shell_vars()
        return

    if prompt:
        if not sys.stdin.isatty():
            print("Error: --prompt requires an interactive terminal.", file=sys.stderr)
            raise SystemExit(1)

        print()
        print("  Regard — wallet setup")
        print()
        print("  Paste your EVM wallet private key. The same key signs for")
        print("  Hyperliquid (perps) and Polymarket (prediction markets).")
        print()
        print(f"  Will be saved to: {_project_dir_for_save()}/.regard/secrets/wallet.json")
        print()

        key = getpass.getpass("  Paste your key (input is hidden): ")
        if not key:
            print()
            print("Error: no key entered.", file=sys.stderr)
            raise SystemExit(1)

    if not key:
        _report_status()
        return

    normalized = _validate_hex_key(key)
    if not normalized:
        print()
        print("  Invalid key. Expected 0x + 64 hex characters.", file=sys.stderr)
        raise SystemExit(1)

    _save_key(normalized)
