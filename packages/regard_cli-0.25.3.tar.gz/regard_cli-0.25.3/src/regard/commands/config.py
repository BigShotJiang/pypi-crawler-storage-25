"""Config — surface and inspect CLI configuration."""

import os
import re
from pathlib import Path
from typing import Annotated

import typer

from regard.core.output import die, output
from regard.core.project_dir import find_project_dir
from regard.core.project_state import (
    load_project_env,
    load_tilt_config,
    set_config_env,
    set_tilt_config,
)
from regard.core.tilt_pending import (
    cancel_pending,
    compare_direction,
    confirm_pending,
    list_pending,
    write_pending,
)

config_app = typer.Typer(
    name="config",
    no_args_is_help=True,
    help="View or change CLI configuration.",
)

# Per-chain RPC defaults are owned by `regard.core.rpc_pool.PRIMARY_RPC`.
# `regard.computer` does NOT host RPC infra (per `feedback_no_rpc_infra.md`);
# the pool tries the official protocol-team endpoint, then falls over to
# chainlist.org candidates filtered by a small reputation allowlist. Users
# override per-chain via `regard config set <chain>-rpc <url>`.

DEFAULT_KILLSWITCH_SLIPPAGE = 0.10

# Re-export PRIMARY_RPC under a private alias so `config show` can surface the
# default Polygon endpoint without creating a circular import. The pool module
# owns the canonical defaults.
from regard.core.rpc_pool import PRIMARY_RPC as _PRIMARY_RPC  # noqa: E402

DEFAULT_PENDING_TTL_MINUTES = 15
DEFAULT_SEND_COOLDOWN_SECONDS = 30

_URL_RE = re.compile(r"^https?://[^\s]+$")

# Mapping of user-facing setting names → (env var, validator, description).
# Agents and users can see the accepted keys via `regard config --help` or by
# reading setting names from `regard config show`.
_SETTINGS = {
    "killswitch-address": "KILLSWITCH_ADDRESS",
    "killswitch-slippage": "KILLSWITCH_SLIPPAGE",
    # Chain RPC overrides — see `regard.core.rpc_pool.PRIMARY_RPC` for the
    # default set; user-set values bypass the failover pool entirely.
    "polygon-rpc": "POLYGON_RPC",
    "arbitrum-rpc": "ARBITRUM_RPC",
    "hyperevm-rpc": "HYPEREVM_RPC",
    "ethereum-rpc": "ETHEREUM_RPC",
    "base-rpc": "BASE_RPC",
    "optimism-rpc": "OPTIMISM_RPC",
    "bsc-rpc": "BSC_RPC",
    "avalanche-rpc": "AVALANCHE_RPC",
    "monad-rpc": "MONAD_RPC",
    "unichain-rpc": "UNICHAIN_RPC",
    "megaeth-rpc": "MEGAETH_RPC",
    "polymarket-clob-url": "POLYMARKET_CLOB_URL",
    "pending-ttl-minutes": "PENDING_TTL_MINUTES",
    "send-max-amount": "SEND_MAX_AMOUNT",
    "send-daily-max": "SEND_DAILY_MAX",
    "send-cooldown-seconds": "SEND_COOLDOWN",
    "send-allow-raw-address": "SEND_ALLOW_RAW_ADDRESS",
}


def _effective_slippage(raw_val) -> float:
    """Return the slippage that killswitch will actually use."""
    if raw_val:
        try:
            s = float(raw_val)
            if 0.001 <= s <= 0.5:
                return s
        except (ValueError, TypeError):
            pass
    return DEFAULT_KILLSWITCH_SLIPPAGE


def _validate_address(value: str) -> str:
    """Validate, EIP-55-checksum-check, and normalize an EVM address.

    Mixed-case input with a wrong checksum is rejected hard (likely typo
    or tampering). All-lowercase or all-uppercase input is normalized to
    the checksummed form. See `core.eth_address.validate_address` for
    the full contract.
    """
    from regard.core.eth_address import validate_address
    return validate_address(value, label="killswitch destination")


def _trading_address() -> str | None:
    """Best-effort lookup of the trading wallet address from env + project state."""
    env = load_project_env()
    key = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or env.get("HYPERLIQUID_PRIVATE_KEY")
    if not key:
        return None
    try:
        import eth_account
        return eth_account.Account.from_key(key).address
    except Exception:
        return None


def _validate_url(value: str) -> str:
    value = value.strip()
    if not _URL_RE.match(value):
        die("validation_error", "INVALID_URL", f"Expected http(s) URL. Got: {value[:40]}…")
    return value


def _validate_slippage(value: str) -> str:
    try:
        f = float(value)
    except ValueError:
        die("validation_error", "INVALID_SLIPPAGE", f"Expected a number between 0.001 and 0.5. Got: {value}")
    if not (0.001 <= f <= 0.5):
        die("validation_error", "INVALID_SLIPPAGE", f"Slippage must be between 0.001 and 0.5. Got: {f}")
    return str(f)


def _validate_ttl_minutes(value: str) -> str:
    """Proposal pending-TTL — integer minutes in [1, 1440] (1 day max)."""
    try:
        m = int(value)
    except ValueError:
        die("validation_error", "INVALID_TTL",
            f"Expected an integer number of minutes (1–1440). Got: {value}")
    if not (1 <= m <= 1440):
        die("validation_error", "INVALID_TTL",
            f"TTL must be between 1 and 1440 minutes (24h max). Got: {m}",
            hint="Crypto moves fast — default 15 min is a reasonable backstop.")
    return str(m)


def _validate_positive_number(value: str) -> str:
    """Positive float (for send amount caps). Any decimal > 0 accepted."""
    try:
        f = float(value)
    except ValueError:
        die("validation_error", "INVALID_NUMBER",
            f"Expected a positive number. Got: {value}")
    if f <= 0:
        die("validation_error", "INVALID_NUMBER",
            f"Must be greater than zero. Got: {f}")
    return str(f)


def _validate_non_negative_int(value: str) -> str:
    """Non-negative integer (for cooldown seconds). 0 = disabled."""
    try:
        n = int(value)
    except ValueError:
        die("validation_error", "INVALID_NUMBER",
            f"Expected a non-negative integer. Got: {value}")
    if n < 0:
        die("validation_error", "INVALID_NUMBER",
            f"Must be zero or greater. Got: {n}")
    return str(n)


def _validate_bool(value: str) -> str:
    """Accept common bool tokens, normalize to 'true' / 'false'.

    Match what config.json typically holds — lowercase string. Env var
    truthy check in upstream code looks for truthy-string presence; storing
    the explicit value here makes the config state readable.
    """
    v = value.strip().lower()
    if v in ("true", "1", "yes", "on"):
        return "true"
    if v in ("false", "0", "no", "off", ""):
        return "false"
    die("validation_error", "INVALID_BOOL",
        f"Expected true/false (or yes/no, on/off, 1/0). Got: {value}")


_VALIDATORS = {
    "killswitch-address": _validate_address,
    "killswitch-slippage": _validate_slippage,
    "polygon-rpc": _validate_url,
    "polymarket-clob-url": _validate_url,
    "pending-ttl-minutes": _validate_ttl_minutes,
    "send-max-amount": _validate_positive_number,
    "send-daily-max": _validate_positive_number,
    "send-cooldown-seconds": _validate_non_negative_int,
    "send-allow-raw-address": _validate_bool,
}


# ---------------------------------------------------------------------------
# Tilt config validators — return TYPED values (not strings) since tilt config
# is structured JSON, not env-var strings.
# ---------------------------------------------------------------------------

_NULL_TOKENS = ("", "null", "none")
_TIME_WINDOW_RE = re.compile(r"^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$")


def _validate_tilt_optional_positive_number(value: str) -> float | None:
    """Positive finite float, or null/empty to clear.

    Rejects NaN and Infinity — `f <= 0` is False for NaN (all NaN
    comparisons return False), so without the `isfinite` guard a `NaN`
    string would silently disable the daily-loss-budget hard stop.
    """
    import math

    if value.strip().lower() in _NULL_TOKENS:
        return None
    try:
        f = float(value)
    except ValueError:
        die("validation_error", "INVALID_NUMBER",
            f"Expected positive number or 'null' to clear. Got: {value}")
    if not math.isfinite(f) or f <= 0:
        die("validation_error", "INVALID_NUMBER",
            f"Must be a finite number greater than zero. Got: {f}")
    return f


def _validate_tilt_pct(value: str) -> float:
    """Percentage in (0, 100]. Rejects NaN/Infinity (see above)."""
    import math

    try:
        f = float(value)
    except ValueError:
        die("validation_error", "INVALID_PERCENT",
            f"Expected percentage between 0 and 100. Got: {value}")
    if not math.isfinite(f) or not (0 < f <= 100):
        die("validation_error", "INVALID_PERCENT",
            f"Percentage must be a finite number > 0 and ≤ 100. Got: {f}")
    return f


def _validate_tilt_optional_pct(value: str) -> float | None:
    if value.strip().lower() in _NULL_TOKENS:
        return None
    return _validate_tilt_pct(value)


def _validate_tilt_positive_int(value: str) -> int:
    try:
        n = int(value)
    except ValueError:
        die("validation_error", "INVALID_NUMBER",
            f"Expected positive integer. Got: {value}")
    if n <= 0:
        die("validation_error", "INVALID_NUMBER",
            f"Must be greater than zero. Got: {n}")
    return n


def _validate_tilt_bool(value: str) -> bool:
    v = value.strip().lower()
    if v in ("true", "1", "yes", "on"):
        return True
    if v in ("false", "0", "no", "off"):
        return False
    die("validation_error", "INVALID_BOOL",
        f"Expected true/false (or yes/no, on/off, 1/0). Got: {value}")


def _validate_tilt_sleep_window(value: str) -> str | None:
    """Sleep window in HH:MM-HH:MM format, or null/empty to clear.

    Validates BOTH ends of the window as legal clock times — the regex
    alone accepts `24:00-07:00`, which `core.sleep_signal._parse_window`
    later silently rejects, leaving the user with a sleep signal that
    never fires despite a populated config.
    """
    if value.strip().lower() in _NULL_TOKENS:
        return None
    m = _TIME_WINDOW_RE.match(value.strip())
    if not m:
        die("validation_error", "INVALID_TIME_WINDOW",
            f"Expected HH:MM-HH:MM (e.g. 23:00-07:00) or 'null'. Got: {value}",
            hint="The window represents your usual sleep hours, local time.")
    sleep_h, sleep_m, wake_h, wake_m = (int(m.group(i)) for i in range(1, 5))
    if not (0 <= sleep_h <= 23 and 0 <= sleep_m <= 59
            and 0 <= wake_h <= 23 and 0 <= wake_m <= 59):
        die("validation_error", "INVALID_TIME_WINDOW",
            f"Hours must be 0–23, minutes 0–59. Got: {value}",
            hint="Use 23:00-07:00, not 24:00-07:00.")
    return value


def _validate_tilt_optional_string(value: str) -> str | None:
    """Free-form string (e.g. Ulysses text), or null/empty to clear."""
    if value.strip().lower() in _NULL_TOKENS:
        return None
    return value


# Map: CLI key → (JSON path inside `tilt` block, validator returning typed value).
# Used by `regard config set` to dispatch tilt-* keys to set_tilt_config().
_TILT_SETTINGS = {
    "tilt-daily-loss-budget-usd": (["daily_loss_budget_usd"], _validate_tilt_optional_positive_number),
    "tilt-daily-loss-budget-pct": (["daily_loss_budget_pct"], _validate_tilt_optional_pct),
    "tilt-max-session-hours": (["max_session_hours"], _validate_tilt_positive_int),
    "tilt-max-yolo-session-hours": (["max_yolo_session_hours"], _validate_tilt_positive_int),
    "tilt-mandatory-break-interval-hours": (["mandatory_break_interval_hours"], _validate_tilt_positive_int),
    "tilt-sleep-window-local": (["sleep_window_local"], _validate_tilt_sleep_window),
    "tilt-sleep-yellow-hours": (["sleep_thresholds_hours", "yellow"], _validate_tilt_positive_int),
    "tilt-sleep-orange-hours": (["sleep_thresholds_hours", "orange"], _validate_tilt_positive_int),
    "tilt-sleep-red-hours": (["sleep_thresholds_hours", "red"], _validate_tilt_positive_int),
    "tilt-first-red-pivot-enabled": (["first_red_pivot_enabled"], _validate_tilt_bool),
    "tilt-win-streak-threshold": (["win_streak_threshold"], _validate_tilt_positive_int),
    "tilt-size-deviation-baseline-days": (["size_deviation_baseline_days"], _validate_tilt_positive_int),
    "tilt-pm-longshot-threshold-cents": (["polymarket", "longshot_threshold_cents"], _validate_tilt_positive_int),
    "tilt-pm-longshot-max-size-pct": (["polymarket", "longshot_max_size_pct"], _validate_tilt_pct),
    "tilt-hl-leverage-ratchet-threshold": (["hyperliquid", "leverage_ratchet_threshold"], _validate_tilt_positive_int),
    "tilt-hl-outcome-near-expiry-enabled": (["hyperliquid", "outcome_near_expiry_enabled"], _validate_tilt_bool),
    "tilt-hl-outcome-near-expiry-minutes": (["hyperliquid", "outcome_near_expiry_minutes"], _validate_tilt_positive_int),
    "tilt-ulysses-text": (["ulysses_text"], _validate_tilt_optional_string),
    "tilt-loosen-delay-hours": (["asymmetric_change", "loosening_delay_hours"], _validate_tilt_positive_int),
}


def _project_dir_for_save() -> Path:
    """Project root for config writes — existing project found by walk-up,
    else CWD as the bootstrap target.
    """
    found = find_project_dir()
    return found if found is not None else Path.cwd()


def _write_setting(env_var: str, value: str) -> Path:
    """Atomic merge of a single env var into <project>/.regard/config.json."""
    return set_config_env(env_var, value, _project_dir_for_save())


@config_app.command()
def show():
    """Show current configuration."""
    from regard.venues.polymarket.client import DEFAULT_CLOB_URL

    settings = load_project_env()
    custom_rpc = settings.get("POLYGON_RPC")
    custom_clob_url = settings.get("POLYMARKET_CLOB_URL")

    killswitch_addr = settings.get("KILLSWITCH_ADDRESS")
    custom_slippage = settings.get("KILLSWITCH_SLIPPAGE")
    effective_slip = _effective_slippage(custom_slippage)

    project_dir = find_project_dir()

    # Pending TTL (minutes) + send safety caps
    pending_ttl = settings.get("PENDING_TTL_MINUTES")
    send_max = settings.get("SEND_MAX_AMOUNT")
    send_daily = settings.get("SEND_DAILY_MAX")
    send_cooldown = settings.get("SEND_COOLDOWN")
    send_raw = settings.get("SEND_ALLOW_RAW_ADDRESS")

    def _ttl_effective(raw):
        try:
            m = int(raw) if raw else DEFAULT_PENDING_TTL_MINUTES
            return m if 1 <= m <= 1440 else DEFAULT_PENDING_TTL_MINUTES
        except (ValueError, TypeError):
            return DEFAULT_PENDING_TTL_MINUTES

    def _cooldown_effective(raw):
        try:
            n = int(raw) if raw else DEFAULT_SEND_COOLDOWN_SECONDS
            return n if n >= 0 else DEFAULT_SEND_COOLDOWN_SECONDS
        except (ValueError, TypeError):
            return DEFAULT_SEND_COOLDOWN_SECONDS

    tilt_config = load_tilt_config()

    # Surface pending tilt changes (Ulysses-contract loosenings awaiting cooldown)
    tilt_pending_entries: list = []
    if project_dir is not None:
        try:
            tilt_pending_entries = list_pending(project_dir, prune=True)
        except OSError:
            tilt_pending_entries = []

    result = {
        "project_dir": str(project_dir) if project_dir else None,
        "config_path": str(project_dir / ".regard" / "config.json") if project_dir else None,
        "in_project": project_dir is not None,
        "tilt": tilt_config,
        "tilt_pending": tilt_pending_entries,
        "polygon_rpc": {
            "current": custom_rpc or _PRIMARY_RPC[137],
            "source": "settings" if custom_rpc else "default",
            "default": _PRIMARY_RPC[137],
        },
        "polymarket_clob_url": {
            "current": custom_clob_url or DEFAULT_CLOB_URL,
            "source": "settings" if custom_clob_url else "default",
            "default": DEFAULT_CLOB_URL,
        },
        "killswitch_address": {
            "current": killswitch_addr or None,
            "configured": killswitch_addr is not None,
        },
        "killswitch_slippage": {
            "current": effective_slip,
            "source": "settings" if custom_slippage and effective_slip != DEFAULT_KILLSWITCH_SLIPPAGE else "default",
            "default": DEFAULT_KILLSWITCH_SLIPPAGE,
        },
        "pending_ttl_minutes": {
            "current": _ttl_effective(pending_ttl),
            "source": "settings" if pending_ttl else "default",
            "default": DEFAULT_PENDING_TTL_MINUTES,
        },
        "send_max_amount": {
            "current": float(send_max) if send_max else None,
            "configured": send_max is not None,
        },
        "send_daily_max": {
            "current": float(send_daily) if send_daily else None,
            "configured": send_daily is not None,
        },
        "send_cooldown_seconds": {
            "current": _cooldown_effective(send_cooldown),
            "source": "settings" if send_cooldown else "default",
            "default": DEFAULT_SEND_COOLDOWN_SECONDS,
        },
        "send_allow_raw_address": {
            "current": str(send_raw).lower() == "true" if send_raw else False,
            "configured": send_raw is not None,
        },
    }
    output(result, None)


@config_app.command("set")
def set_value(
    key: Annotated[str, typer.Argument(help="Setting name. Run `regard config show` for the available keys.")],
    value: Annotated[str, typer.Argument(help="New value")],
):
    """Set a config value — writes to <project>/.regard/config.json.

    Run in a separate terminal, `cd`'d to the project directory. The value is
    validated per-key before write; an invalid value does not touch the file.
    """
    if key in _SETTINGS:
        validated = _VALIDATORS[key](value)

        # Safety check — killswitch destination must not equal the trading wallet
        if key == "killswitch-address":
            trading = _trading_address()
            if trading and trading.lower() == validated.lower():
                die(
                    "validation_error",
                    "SAME_AS_TRADING_WALLET",
                    "Killswitch destination cannot equal the trading wallet — sweeping funds to yourself is a no-op",
                    hint="Use a separate wallet address as the emergency destination",
                )

        env_var = _SETTINGS[key]
        path = _write_setting(env_var, validated)
        output({"set": key, "value": validated, "path": str(path)}, None)
        return

    if key in _TILT_SETTINGS:
        json_path, validator = _TILT_SETTINGS[key]
        tilt_value = validator(value)
        project_dir = _project_dir_for_save()

        # Asymmetric change rule — Ulysses contract. Tightening applies
        # immediately; loosening writes a pending entry that the user must
        # confirm after a 24h cooling-off (configurable via
        # `tilt.asymmetric_change.loosening_delay_hours`).
        current_tilt = load_tilt_config()
        old_value = _resolve_path(current_tilt, json_path)
        direction = compare_direction(tuple(json_path), old_value, tilt_value)

        if direction == "loosen":
            ttl_hours = float(
                current_tilt.get("asymmetric_change", {}).get(
                    "loosening_delay_hours", 24.0,
                )
                or 24.0
            )
            entry = write_pending(
                cli_key=key,
                json_path=tuple(json_path),
                current_value=old_value,
                requested_value=tilt_value,
                project_dir=project_dir,
                ttl_hours=ttl_hours,
            )
            output({
                "pending": key,
                "id": entry["id"],
                "current_value": entry["current_value"],
                "requested_value": entry["requested_value"],
                "earliest_apply": entry["earliest_apply"],
                "ttl_hours": entry["ttl_hours"],
                "message": (
                    f"Loosening this limit requires a {ttl_hours:g}h cooling-off period. "
                    f"Run `regard config tilt-confirm {entry['id']}` after that time, "
                    f"or `regard config tilt-cancel {entry['id']}` to abort."
                ),
            }, None)
            return

        # Tighten or neutral → apply immediately. Cancel any pending entry
        # for this key first — a stale pending against the OLD current_value
        # would otherwise apply a now-incorrect loosening on tilt-confirm
        # (e.g. user loosened 8→12, then tightened to 4; without cancel,
        # tilt-confirm would later raise back to 12 against the new 4 baseline).
        from regard.core.tilt_pending import (
            cancel_by_key as _cancel_pending_by_key,
        )
        _cancelled = _cancel_pending_by_key(key, project_dir)
        path = set_tilt_config(json_path, tilt_value, project_dir)
        result = {
            "set": key,
            "value": tilt_value,
            "path": str(path),
            "direction": direction,
        }
        if _cancelled:
            result["cancelled_pending"] = _cancelled
        output(result, None)
        return

    all_keys = sorted(list(_SETTINGS) + list(_TILT_SETTINGS))
    die(
        "validation_error",
        "UNKNOWN_SETTING",
        f"Unknown setting '{key}'.",
        hint=f"Valid keys: {', '.join(all_keys)}",
    )


def _resolve_path(data: dict, path):
    """Walk a JSON path tuple/list against a dict, returning the leaf or None."""
    cursor: object = data
    for k in path:
        if isinstance(cursor, dict):
            cursor = cursor.get(k)
        else:
            return None
    return cursor


# ---------------------------------------------------------------------------
# `regard config tilt-pending` / `tilt-confirm` / `tilt-cancel`
# ---------------------------------------------------------------------------


@config_app.command("tilt-pending")
def tilt_pending():
    """List pending tilt-config changes awaiting cooling-off cooldown.

    Loosening any tilt limit writes a pending entry rather than applying
    immediately. Each entry shows time-remaining until it can be confirmed.
    Use `tilt-confirm <id>` after the time elapses, or `tilt-cancel <id>`
    to abort.
    """
    project_dir = _project_dir_for_save()
    entries = list_pending(project_dir, prune=True)
    output({"pending": entries, "count": len(entries)}, None)


@config_app.command("tilt-confirm")
def tilt_confirm(
    pending_id: Annotated[str, typer.Argument(help="ID from `regard config tilt-pending`")],
):
    """Apply a pending tilt-config change after cooling-off elapses."""
    project_dir = _project_dir_for_save()
    status, entry = confirm_pending(pending_id, project_dir)
    if status == "not_found":
        die(
            "validation_error",
            "PENDING_NOT_FOUND",
            f"No pending change with id '{pending_id}'.",
            hint="Run `regard config tilt-pending` to list current pending changes.",
        )
    if status == "too_early":
        assert entry is not None
        die(
            "validation_error",
            "TOO_EARLY",
            f"Cooling-off period not yet elapsed for pending change '{pending_id}'.",
            hint=(
                f"Earliest apply: {entry['earliest_apply']} "
                f"({entry.get('remaining_seconds', '?')}s remaining)"
            ),
        )
    # Ready — write the new value FIRST, then remove the pending file.
    # If the write fails (OSError), the pending entry survives and the
    # user can retry without re-waiting 24h.
    assert entry is not None
    path = set_tilt_config(
        entry["json_path"],
        entry["requested_value"],
        project_dir,
    )
    cancel_pending(pending_id, project_dir)
    output({
        "applied": entry["cli_key"],
        "value": entry["requested_value"],
        "path": str(path),
        "id": entry["id"],
    }, None)


@config_app.command("tilt-cancel")
def tilt_cancel(
    pending_id: Annotated[str, typer.Argument(help="ID from `regard config tilt-pending`")],
):
    """Cancel a pending tilt-config change without applying."""
    project_dir = _project_dir_for_save()
    if not cancel_pending(pending_id, project_dir):
        die(
            "validation_error",
            "PENDING_NOT_FOUND",
            f"No pending change with id '{pending_id}'.",
            hint="Run `regard config tilt-pending` to list current pending changes.",
        )
    output({"cancelled": pending_id}, None)
