# regard-cli

AI trading partner for the unified speculator. Multi-venue trading CLI consumed by the [regard-computer](https://github.com/akegaviar/tabtabtabTABtab) Claude Code skill.

## Install

```bash
uv tool install regard-cli
```

## Usage

```bash
# Read commands (no auth needed)
regard hypercore prices BTC ETH
regard hypercore book BTC --depth 10
regard hypercore assets TSLA
regard hypercore funding BTC --history
regard hypercore candles BTC 1h --limit 50

# Account commands (needs HYPERLIQUID_AGENT_KEY or --address)
regard hypercore status
regard hypercore balance
regard hypercore positions
regard hypercore orders
regard hypercore fills

# Write commands (needs HYPERLIQUID_AGENT_KEY)
regard hypercore order BTC buy 0.1 --market
regard hypercore order BTC buy 0.1 95000 --tp 100000 --sl 90000
regard hypercore cancel 77738308
regard hypercore cancel-all BTC
regard hypercore leverage BTC 10
```

## Auth

Set `HYPERLIQUID_AGENT_KEY` env var with your Hyperliquid agent wallet key (can trade, cannot withdraw). Master address auto-resolved via `userRole` API.

Read-only commands work without auth using `--address`.

## Design

- Env-prefixed sub-commands (`regard hypercore`, `regard polymarket`, `regard polygon`, ...)
- Output envelope: `{"ok": true, "data": ..., "meta": {"timestamp": ...}}`
- Structured errors with type/code/message, recovery hints, retryable flag
- Exit codes: 0=success, 2=validation, 3=auth, 4=venue, 5=rate_limit, 6=network
- Field projection via `--fields`
- HIP-3 asset auto-resolution (e.g. `TSLA` → `xyz:TSLA`)
- CLI-first: agents invoke `regard <verb>` directly through shell; structured JSON envelope is the universal interface

## License

MIT
