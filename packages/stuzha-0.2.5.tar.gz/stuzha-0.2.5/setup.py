from setuptools import setup, find_packages

setup(
    name='stuzha',
    version='0.2.5',
    packages=find_packages(),
    install_requires=[
        'colorama>=0.4.6',
    ],
    entry_points={
        'console_scripts': [
            # NLP entry points
            'pln_1 = stuzha.NLP:pln_1',
            'pln_2 = stuzha.NLP:pln_2',
            'pln_3 = stuzha.NLP:pln_3',
            'pln_4 = stuzha.NLP:pln_4',
            'pln_5 = stuzha.NLP:pln_5',
            'pln_6 = stuzha.NLP:pln_6',
            'pln_7 = stuzha.NLP:pln_7',
            'pln_8 = stuzha.NLP:pln_8',
            'pln_9 = stuzha.NLP:pln_9',
            'pln_10 = stuzha.NLP:pln_10',
            # SNA entry points
            'ans_1 = stuzha.SNA:ans_1',
            'ans_2 = stuzha.SNA:ans_2',
            'ans_3 = stuzha.SNA:ans_3',
            'ans_4 = stuzha.SNA:ans_4',
            'ans_5 = stuzha.SNA:ans_5',
            'ans_6 = stuzha.SNA:ans_6',
            'ans_7 = stuzha.SNA:ans_7',
            'ans_8 = stuzha.SNA:ans_8',
            'ans_9 = stuzha.SNA:ans_9',
            'ans_10 = stuzha.SNA:ans_10',
            # IoT entry points
            'cp_1 = stuzha.IoT:cp_1',
            'cp_2 = stuzha.IoT:cp_2',
            'cp_3 = stuzha.IoT:cp_3',
            'cp_4 = stuzha.IoT:cp_4',
            'cp_5 = stuzha.IoT:cp_5',
            'cp_6 = stuzha.IoT:cp_6',
            'cp_7 = stuzha.IoT:cp_7',
            'cp_8 = stuzha.IoT:cp_8',
            'cp_9 = stuzha.IoT:cp_9',
            # BF entry points
            'fb_1 = stuzha.BF:fb_1',
            'fb_2 = stuzha.BF:fb_2',
            'fb_3 = stuzha.BF:fb_3',
            'fb_4 = stuzha.BF:fb_4',
            'fb_5 = stuzha.BF:fb_5',
            'fb_6 = stuzha.BF:fb_6',
            'fb_7 = stuzha.BF:fb_7',
            'fb_8 = stuzha.BF:fb_8',
            'fb_9 = stuzha.BF:fb_9',
            'fb_10 = stuzha.BF:fb_10',
        ],
    }
)