from colorama import Fore, Style, init

init(autoreset=True)

def pln_1():
    print(Fore.RED + '''

# pip install nltk matplotlib          
          

import nltk

nltk.download('punkt')
nltk.download('punkt_tab')


#Sentence Tokenization

from nltk.tokenize import sent_tokenize

text="""The Hexenzirkel is a mysterious organization of powerful witches. It was founded by the mage Alice, and consisted of at least eight members at one point. The group sometimes gathers around for "formal tea parties", with one such meeting spot being a secret island above Falcon Coast."""
tokenized_text=sent_tokenize(text)
print(tokenized_text)


#Word Tokenization

from nltk.tokenize import word_tokenize

tokenized_word=word_tokenize(text)
print(tokenized_word)


#Frequency Distribution

from nltk.probability import FreqDist

fdist = FreqDist(tokenized_word)
print(fdist)
fdist.most_common()


#Plot

import matplotlib.pyplot as plt

fdist.plot(30, cumulative=False)



#Removing Stop Words

nltk.download('stopwords')

from nltk.corpus import stopwords

stop_words = set(stopwords.words('english'))
print(stop_words)


filtered_sent=[]

for w in tokenized_word:
   if w not in stop_words:
       filtered_sent.append(w)

print("Tokenized Word: ", tokenized_word)
print("Filtered Word: ", filtered_sent)
        
          ''')

def pln_2():
    print(Fore.RED + '''


# Regular expression for detecting words (ignoring punctuation)

import re

text = "Hello, my name is Sigma Rizzler! I am learning water magic"

word_pattern = r'\b\w+\b'

words = re.findall(word_pattern, text)
print("Words: ", words)



# Regular Expression for detecting specific word patterns

patternWp = r'\bm\w*\b'
m_words = re.findall(patternWp, text)
print("Words starting with 'm': ", m_words)



# Tokenizing text based on spaces and punctuation

tokens = re.split(r'(\W+)', text)
print("Tokens:", [token.strip() for token in tokens if token.strip()]) 



# Regular Expression for detecting numbers 

number_pattern = r'\b\d+\b'
numbers = re.findall(number_pattern, text)
print("Numbers:", numbers)



# Generate regular expression for the given data text = """101   COM   Computers205   MAT   Mathematics189   ENG    English"""

text = """101   COM   Computers
205   MAT   Mathematics
189   ENG    English"""


re.findall('[0-9]+', text)

re.findall('[A-Z]{3}', text)

re.findall('[A-Za-z]{4,}', text)

course_pattern = r'([0-9]+)\s*([A-Z]{3})\s*([A-Za-z]{4,})'

re.findall(course_pattern, text)



# Find "Cool"

print(re.findall(r'Co+l', 'So Cooool Coool Cool coool col'))



# Find 'toy'

re.findall(r'\btoy\b', 'play toy broke toys')




# Regular Expression for email ID

emails = """adityagoriwale@facebook.com
irminsul@google.com
Deez@amazon.com"""
pattern = r'(\w+)@([A-Z0-9]+)\.([A-Z]{2,4})'
re.findall(pattern, emails, flags=re.IGNORECASE)




# Regular expression for Cleaning the tweet msg for proper message

tweet = "Insert Random stuff here"


import re

def clean_tweet(tweet):
   tweet = re.sub(r'http\S+\s*', '', tweet) 
   tweet = re.sub(r'RT|cc', '', tweet)
   tweet = re.sub(r'#\S+', '', tweet) 
   tweet = re.sub(r'@\S+', '', tweet) 
   tweet = re.sub(r'[%s]' % re.escape(r"""!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"""), '', tweet) 
   tweet = re.sub(r'\s+', ' ', tweet)
   return tweet

print(clean_tweet(tweet))

          ''')
    
def pln_3():
    print(Fore.RED + '''

# pip install nltk spacy


# Apply Stemming on the following words running", "runner", "runs", "easily", "happier", "better”

from nltk.stem import PorterStemmer

stemmer = PorterStemmer()
words = ["running", "runner", "runs", "easily", "happier", "better"]
stemmed_words = [stemmer.stem(word) for word in words]
print(stemmed_words)



# Apply Lemmatization on the following words running", "runner", "runs", "easily", "happier", "better”

import nltk
nltk.download('wordnet')


from nltk.stem import WordNetLemmatizer
from nltk.corpus import wordnet

lemmatizer = WordNetLemmatizer()
words = ["running", "runner", "runs", "easily", "happier", "better"]
lemmatized_words = [lemmatizer.lemmatize(word, pos=wordnet.VERB) for word in words]
print(lemmatized_words)


# Morphological Analysis Using NLTK's for ing, ly, s or and etc as per your choice.

import nltk
nltk.download('punkt_tab')


from nltk.tag import RegexpTagger
from nltk.tokenize import word_tokenize

sentence = "Heroes were running swiftly towards the bridges."
tokens = word_tokenize(sentence)
patterns = [
   (r'.*ing$', 'VB'),   
   (r'.*ly$', 'RB'),    
   (r'.*es$', 'NNS'),   
]
tagger = RegexpTagger(patterns)
tagged_tokens = tagger.tag(tokens)
print(tagged_tokens)



# Using WordNet for Morphological Analysis.

from nltk.corpus import wordnet

nltk.download('wordnet')
synsets = wordnet.synsets('running')
print(synsets[0].lemmas())



# Identifying Prefixes and Suffixes for the following words "running", "played", "happily", "cats", "jump".

import re

def extract_prefixes(word):
   prefixes = ['un', 're', 'pre', 'dis']
   for prefix in prefixes:
       if word.startswith(prefix):
           return prefix
   return None
words = ["running", "redo", "unhappy", "dislike", "prepaid", "happy"]
prefixes = [extract_prefixes(word) for word in words]
print(prefixes)



import re

def extract_suffixes(word):
   suffixes = ['ing', 'ed', 'ly', 's']
   for suffix in suffixes:
       if word.endswith(suffix):
           return suffix
   return None
words = ["running", "played", "unhappy", "cats", "jump"]
suffixes = [extract_suffixes(word) for word in words]
print(suffixes)



# Using Regular Expressions for Compound Word Segmentation Splitting Compound Words eg: sunflower etc.

import re

compound_words = ['sunflower', 'basketball', 'football', 'notebook', 'toothbrush']
common_words = ['sun', 'flower', 'basket', 'ball', 'foot', 'book', 'tooth', 'brush']

def split_compound_word(word, components):
   for component in components:
       if word.startswith(component):
           remaining = word[len(component):]
           if remaining in components:
               return component, remaining
   return word 
split_results = {word: split_compound_word(word, common_words) for word in compound_words}
print(split_results)


# Using Spacy for Compound Word Detection.

import spacy

nlp = spacy.load("en_core_web_sm")
text = "The football players were practicing on the basketball court."
doc = nlp(text)
for token in doc:
   if token.dep_ == "compound":
       print(f"Compound word found: {token.text} -> Head: {token.head.text}")
       
             
          ''')
    
def pln_4():
    print(Fore.RED + '''
          

# Edit distance between strings s1 and s2


def edit_distance(s1, s2):
   m, n = len(s1), len(s2)
   dp = [[0] * (n + 1) for _ in range(m + 1)]
   for i in range(m + 1):
       dp[i][0] = i
   for j in range(n + 1):
       dp[0][j] = j
   for i in range(1, m + 1):
       for j in range(1, n + 1):
           if s1[i - 1] == s2[j - 1]:
               dp[i][j] = dp[i - 1][j - 1]
           else:
               dp[i][j] = 1 + min(dp[i - 1][j],
                                  dp[i][j - 1],
                                  dp[i - 1][j - 1])
   return dp[m][n]
print(edit_distance("CHARACTERIZATION", "NATIONALIZATION")) 



# Levenshtein weighted edit distance between strings s1 and s2

def levenshtein_distance(s1, s2):
   m, n = len(s1), len(s2)
   dp = [[0] * (n + 1) for _ in range(m + 1)]
   for i in range(m + 1):
       dp[i][0] = i
   for j in range(n + 1):
       dp[0][j] = j
   for i in range(1, m + 1):
       for j in range(1, n + 1):
           if s1[i - 1] == s2[j - 1]:
               dp[i][j] = dp[i - 1][j - 1]
           else:
               dp[i][j] = min(dp[i - 1][j] + 1,    
                              dp[i][j - 1] + 1,     
                              dp[i - 1][j - 1] + 2)
  
   print("DP Matrix:")
   for row in dp:
       print(row)
   return dp[m][n]
print("Levenshtein Distance:", levenshtein_distance("CHARACTERIZATION", "NATIONALIZATION"))



# Two sentences are given. Compute the edit distance at the word level: 

def word_edit_distance(sentence1, sentence2):
   words1 = sentence1.split()
   words2 = sentence2.split()
   m, n = len(words1), len(words2)
   dp = [[0] * (n + 1) for _ in range(m + 1)]
  
   for i in range(m + 1):
       dp[i][0] = i
   for j in range(n + 1):
       dp[0][j] = j
  
   for i in range(1, m + 1):
       for j in range(1, n + 1):
           if words1[i - 1] == words2[j - 1]:
               dp[i][j] = dp[i - 1][j - 1]
           else:
               dp[i][j] = 1 + min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
  
   print("DP Matrix:")
   for row in dp:
       print(row)
  
   return dp[m][n]
print("Edit Distance:", word_edit_distance("I love natural language processing", "I enjoy learning language processing"))

          ''')
    
def pln_5():
    print(Fore.RED + '''

# TextBlob

# pip install -U textblob, -r textblob., nltk, -r textblob.download_corpora

# pip install -r textblob.download_corpora

import nltk
nltk.download('punkt')
nltk.download('punkt_tab')

from textblob import TextBlob

sentence = "Technology is best when it brings people together"

ngram_object = TextBlob(sentence)


bigrams = ngram_object.ngrams(n=2) 
print(bigrams)

trigrams = ngram_object.ngrams(n=3)
print(trigrams)



# Trigram Model

import random
from collections import defaultdict

def generate_ngrams(text, n):
   words = text.split()

   ngrams = zip(*[words[i:] for i in range(n)])

   return ngrams

def build_ngram_model(text, n):
   ngram_model = defaultdict(list)
   ngrams = generate_ngrams(text, n)

   for ngram in ngrams:
       prefix = tuple(ngram[:-1])
       suffix = ngram[-1] 
       ngram_model[prefix].append(suffix)
   return ngram_model

def generate_text(ngram_model, n, length=20):
   prefix = random.choice(list(ngram_model.keys()))
   generated_words = list(prefix)

   for _ in range(length - n + 1):
       suffixes = ngram_model.get(prefix, [])

       if not suffixes: 
           print(f"No suffix found for prefix: {prefix}")
           break 
       suffix = random.choice(suffixes)
       generated_words.append(suffix)
       prefix = tuple(generated_words[-(n-1):])
   return ' '.join(generated_words)

text = "I am learning machine learning and natural language processing"
n = 3

ngram_model = build_ngram_model(text, n)
print(ngram_model)

generated_text = generate_text(ngram_model, n, length=10)
print("Generated Text:", generated_text)




# 4Gram Model (character based)

import random
from collections import defaultdict

def generate_char_ngrams(text, n):
   ngrams = zip(*[text[i:] for i in range(n)])
   return ngrams

def build_char_ngram_model(text, n):
   ngram_model = defaultdict(list)
   ngrams = generate_char_ngrams(text, n)

   for ngram in ngrams:
       prefix = tuple(ngram[:-1])
       suffix = ngram[-1]
       ngram_model[prefix].append(suffix)
   return ngram_model

def generate_char_text(ngram_model, n, length=100):
   prefix = random.choice(list(ngram_model.keys()))
   generated_text = ''.join(prefix)
   for _ in range(length - n + 1):
       suffixes = ngram_model.get(prefix, [])

       if not suffixes:
           print(f"No suffix found for prefix: {prefix}")
           prefix = random.choice(list(ngram_model.keys()))
           continue
       suffix = random.choice(suffixes)
       generated_text += suffix
       prefix = tuple(generated_text[-(n-1):])
   return generated_text

text = "hello world, welcome to the n-gram model!"
n = 4 

ngram_model = build_char_ngram_model(text, n)
print(ngram_model)
generated_text = generate_char_text(ngram_model, n, length=50)
print("Generated Text:", generated_text)



# Bigram and Trigram Model


import random
from collections import defaultdict

def generate_ngrams(text, n):
   words = text.split() 
   ngrams = zip(*[words[i:] for i in range(n)]) 
   return ngrams

def build_ngram_model(text, n):
   ngram_model = defaultdict(list) 
   ngrams = generate_ngrams(text, n)

   for ngram in ngrams:
       prefix = tuple(ngram[:-1]) 
       suffix = ngram[-1] 
       ngram_model[prefix].append(suffix)
   return ngram_model

def generate_text(ngram_model, n, length=20):
   prefix = random.choice(list(ngram_model.keys()))
   generated_words = list(prefix)

   for _ in range(length - n + 1):
       suffixes = ngram_model.get(prefix, [])
       if not suffixes:
           print(f"No suffix found for prefix: {prefix}")
           break
       suffix = random.choice(suffixes)
       generated_words.append(suffix)
       prefix = tuple(generated_words[-(n-1):])
   return ' '.join(generated_words)

text = "I am learning natural language processing with machine learning"
bigram_n = 2 
trigram_n = 3
bigram_model = build_ngram_model(text, bigram_n)

bigram_generated_text = generate_text(bigram_model, bigram_n, length=10)
print("Bigram Generated Text:", bigram_generated_text)

trigram_model = build_ngram_model(text, trigram_n)

trigram_generated_text = generate_text(trigram_model, trigram_n, length=10)
print("Trigram Generated Text:", trigram_generated_text)



# Jaccard Coefficient

def generate_ngrams(words, n):
   ngrams = []
   for i in range(len(words) - n + 1):
       ngrams.append(tuple(words[i:i+n]))
   return ngrams

def jaccard(set1, set2):
   intersection = set1.intersection(set2)
   union = set1.union(set2)
   if len(union) == 0:
       return 0
   return len(intersection) / len(union)

s1 = input("Enter Sentence 1: ").lower()
s2 = input("Enter Sentence 2: ").lower()

words1 = s1.split()
words2 = s2.split()

bigrams1 = set(generate_ngrams(words1, 2))
bigrams2 = set(generate_ngrams(words2, 2))

trigrams1 = set(generate_ngrams(words1, 3))
trigrams2 = set(generate_ngrams(words2, 3))

print("\n===== BIGRAMS =====")
print("Sentence 1:", bigrams1)
print("Sentence 2:", bigrams2)

print("\n===== TRIGRAMS =====")
print("Sentence 1:", trigrams1)
print("Sentence 2:", trigrams2)

def jaccard_manual(set1, set2):
   intersection_count = 0
   for item in set1:
       if item in set2:
           intersection_count += 1

   union_list = []
   for item in set1:
       if item not in union_list:
           union_list.append(item)
   for item in set2:
       if item not in union_list:
           union_list.append(item)
   union_count = len(union_list)

   if union_count == 0:
       return 0
   return intersection_count / union_count

j_bigram = jaccard_manual(bigrams1, bigrams2)
j_trigram = jaccard_manual(trigrams1, trigrams2)

print("\n===== JACCARD CO-EFFICIENT =====")
print(f"Bigram Jaccard Co-efficient: {j_bigram:.4f}")
print(f"Trigram Jaccard Co-efficient: {j_trigram:.4f}")

          ''')
    
def pln_6():
    print(Fore.RED + '''
          

# pip install nltk, spacy

import nltk
from nltk.corpus import brown

import nltk
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger_eng')
nltk.download('brown')
nltk.download('universal_tagset')

sentence = "The quick brown fox jumped over the lazy dog."

tokens = nltk.word_tokenize(sentence)

tagged = nltk.pos_tag(tokens)

print(tagged)




import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

text = "The quick brown fox jumps over the lazy dog."

tokens = word_tokenize(text)

tagged_tokens = pos_tag(tokens)

for token, tag in tagged_tokens:
   print(f"{token}: {tag}")




# pip install spacy
# !python -m spacy download en_core_web_sm

import spacy

nlp = spacy.load("en_core_web_sm")

text = "The quick brown fox jumps over the lazy dog."

doc = nlp(text)

for token in doc:
   print(f"{token.text}: {token.pos_}")




import spacy

nlp = spacy.load("en_core_web_sm")

text = "Google Colab is a great platform for running Python code."

doc = nlp(text)

for token in doc:
   print(f"{token.text}\t{token.pos_}\t{token.dep_}")




# POS tagger using a Naive Bayes Classifier with the NLTK library

# !pip install NaiveBayesClassifier
# !pip install nltk

import nltk
from nltk.classify import NaiveBayesClassifier
from nltk.corpus import names

nltk.download('names')
nltk.download('punkt')

def gender_features(word):
   return {'last_letter': word[-1]}

names = ([(name, 'male') for name in names.words('male.txt')] +
        [(name, 'female') for name in names.words('female.txt')])

import random
random.shuffle(names)

featuresets = [(gender_features(n), gender) for (n, gender) in names]
train_set, test_set = featuresets[500:], featuresets[:500]
classifier = NaiveBayesClassifier.train(train_set)
print("Accuracy:", nltk.classify.accuracy(classifier, test_set))
classifier.show_most_informative_features(5)

print("Classification:", classifier.classify(gender_features('John')))


          ''')

def pln_7():
    print(Fore.RED + '''
          

import math
from collections import defaultdict

training_data = [
   [("I", "PRON"), ("LOVE", "VERB"), ("CATS", "NOUN")],
   [("YOU", "PRON"), ("LOVE", "VERB"), ("DOGS", "NOUN")],
   [("CATS", "NOUN"), ("MEOW", "VERB")]
]

tags = set(tag for sent in training_data for _, tag in sent)
words = set(word for sent in training_data for word, _ in sent)

START = "<START>"
transition_counts = defaultdict(lambda: defaultdict(int))
emission_counts = defaultdict(lambda: defaultdict(int))
tag_counts = defaultdict(int)

for sent in training_data:
   prev_tag = START
   for word, tag in sent:
       transition_counts[prev_tag][tag] += 1
       emission_counts[tag][word] += 1
       tag_counts[tag] += 1
       prev_tag = tag

transition_probs = {
   prev: {tag: count / sum(tags.values()) for tag, count in tags.items()}
   for prev, tags in transition_counts.items()
}

emission_probs = {
   tag: {word: count / tag_counts[tag] for word, count in words.items()}
   for tag, words in emission_counts.items()
}

def viterbi(sentence):
   V = [{}]
   path = {}

   for tag in tags:
       V[0][tag] = math.log(transition_probs[START].get(tag, 1e-10)) + \
                   math.log(emission_probs[tag].get(sentence[0], 1e-10))
       path[tag] = [tag]

   for t in range(1, len(sentence)):
       V.append({})
       new_path = {}
       for curr_tag in tags:
           prob, prev_tag = max(
               (V[t-1][pt] + math.log(transition_probs[pt].get(curr_tag, 1e-10)) +
                math.log(emission_probs[curr_tag].get(sentence[t], 1e-10)), pt)
               for pt in tags
           )
           V[t][curr_tag] = prob
           new_path[curr_tag] = path[prev_tag] + [curr_tag]
       path = new_path

   final_tag = max(tags, key=lambda tag: V[-1][tag])
   return path[final_tag]

sentence = ["I", "LOVE", "CATS"]
tags_result = viterbi(sentence)
print(list(zip(sentence, tags_result)))

          ''')  
    
def pln_8():
    print(Fore.RED + '''

# pip install nltk, spacy, beautifulsoup4, html5lib, requests, lxml, -m spacy download en_core_web_sm

import nltk
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger_eng')

ex = 'European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices'

def preprocess(sent):
   sent = nltk.word_tokenize(sent)
   sent = nltk.pos_tag(sent)
   return sent

sent = preprocess(ex)
sent



pattern = 'NP: {<DT>?<JJ>*<NN>}'

cp = nltk.RegexpParser(pattern)
cs = cp.parse(sent)
print(cs)




from nltk.chunk import conlltags2tree, tree2conlltags
from pprint import pprint
iob_tagged = tree2conlltags(cs)
pprint(iob_tagged)




from nltk import ne_chunk

import nltk
nltk.download('maxent_ne_chunker')
nltk.download('words')
nltk.download('maxent_ne_chunker_tab')

ne_tree = ne_chunk(pos_tag(word_tokenize(ex)))
print(ne_tree)




import spacy
from spacy import displacy
from collections import Counter
import en_core_web_sm

nlp = en_core_web_sm.load()

doc = nlp('European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices')
pprint([(X.text, X.label_) for X in doc.ents])

pprint([(X, X.ent_iob_, X.ent_type_) for X in doc])



from bs4 import BeautifulSoup
import requests
import re
def url_to_string(url):
   res = requests.get(url)
   html = res.text
   soup = BeautifulSoup(html, 'html5lib')
   for script in soup(["script", "style", 'aside']):
       script.extract()
   return " ".join(re.split(r'[\n\t]+', soup.get_text()))
ny_bb = url_to_string('https://www.nytimes.com/')
#https://www.nytimes.com/2018/08/13/us/politics/peter-strzok-fired-fbi.html?hp&action=click&pgtype=Homepage&clickSource=story-heading&module=first-column-region&region=top-news&WT.nav=top-news')
article = nlp(ny_bb)
len(article.ents)


labels = [x.label_ for x in article.ents]
Counter(labels)


items = [x.text for x in article.ents]
Counter(items).most_common(4)


sentences = [x for x in article.sents]
print(sentences[40])


displacy.render(nlp(str(sentences[40])), jupyter=True, style='ent')


displacy.render(nlp(str(sentences[20])), style='dep', jupyter = True, options = {'distance': 80})




import nltk
nltk.download('averaged_perceptron_tagger')
sample_text="""
Rama killed Ravana to save Sita from Lanka.The legend of the Ramayan is the most popular Indian epic.A lot of movies and serials have already
been shot in several languages here in India based on the Ramayana.
"""
tokenized=nltk.sent_tokenize(sample_text)
for i in tokenized:
 words=nltk.word_tokenize(i)
 # print(words)
 tagged_words=nltk.pos_tag(words)
 # print(tagged_words)
 chunkGram=r"""VB: {}"""
 chunkParser=nltk.RegexpParser(chunkGram)
 chunked=chunkParser.parse(tagged_words)

displacy.render(nlp(str(sample_text)), style='dep', jupyter = True, options = {'distance': 80})





import nltk
sample_text= "I am a coding ninja, and I am the best in coding."

tokenized=nltk.sent_tokenize(sample_text)
for i in tokenized:
 words=nltk.word_tokenize(i)
 tagged_words=nltk.pos_tag(words)
 print(tagged_words)
 chunkGram = r"""Chunk: {<RB.?>*<VB.?>*<NNP>+<NN>?}""" # this is the grammar that we define,
 chunkParser=nltk.RegexpParser(chunkGram)
 chunked=chunkParser.parse(tagged_words)

displacy.render(nlp(str(sample_text)), style='dep', jupyter = True, options = {'distance': 100})




import nltk
sentence = [
  ("the", "DT"),
  ("book", "NN"),
  ("has","VBZ"),
  ("many","JJ"),
  ("chapters","NNS")
]
chunker = nltk.RegexpParser(
  r"""
  NP:{<DT><NN.*><.*>*<NN.*>}
  }<VB.*>{
  """
)
chunker.parse(sentence)
Output = chunker.parse(sentence)
displacy.render(nlp(str(Output)), style='dep', jupyter = True, options = {'distance': 100})




import nltk
nltk.download('punkt_tab')
from nltk.tokenize import word_tokenize
from nltk import pos_tag
from nltk.chunk import RegexpParser
nltk.download('averaged_perceptron_tagger_eng')

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('maxent_ne_chunker')
nltk.download('words')


sentence = "The quick brown fox jumps over the lazy dog."

words = word_tokenize(sentence)

tagged_words = pos_tag(words)

grammar = """
 NP: {<DT>?<JJ>*<NN>}  # Noun phrase (optional determiner, adjectives, and noun)
 VP: {<VB.*>}            # Verb phrase (verbs)
 PP: {<IN><NP>}          # Prepositional phrase (preposition followed by noun phrase)
"""

chunk_parser = RegexpParser(grammar)

chunked = chunk_parser.parse(tagged_words)

print("Chunked Output:")
print(chunked)


chunked.pretty_print()

          ''')
    
def pln_9():
    print(Fore.RED + '''
          
          
import random

responses = {
    'greeting': ['Hello!', 'Hi there!', 'Hey! How can I help you?'],
    'goodbye': ['Goodbye!', 'See you later!', 'Take care!'],
    'default': ["I'm sorry, I didn't understand that.", "Can you please clarify?"]
}

def get_intent(user_input):
    user_input = user_input.lower()
    if 'hello' in user_input or 'hi' in user_input:
        return 'greeting'
    elif 'bye' in user_input:
        return 'goodbye'
    else:
        return 'default'

def chatbot_response(user_input):
    intent = get_intent(user_input)
    return random.choice(responses[intent])

print("Chatbot: Hello! How can I assist you today?")
while True:
    user_input = input("You: ")
    if 'bye' in user_input.lower():
        print("Chatbot:", chatbot_response(user_input))
        break
    print("Chatbot:", chatbot_response(user_input))





# Chatbot with a simple dialog system

import random
import re

greetings = ["hi", "hello", "hey", "hola"]
responses = {
    "how are you": "I am doing well, thank you!",
    "what is your name": "I am a simple chatbot!",
    "bye": "Goodbye! Have a great day!",
    "default": "I'm not sure how to respond to that. Can you ask something else?",
}


def greet(user_input):
    if any(greeting in user_input.lower() for greeting in greetings):
        return random.choice(["Hello!", "Hi there!", "Hey!"])
    return None

def get_response(user_input):
    user_input = user_input.lower()
    
    greeting_response = greet(user_input)
    
    if greeting_response:
        return greeting_response
    
    for key, value in responses.items():
            if key in user_input:
                return value
            
    return responses["default"]

def chatbot():
    print("Chatbot: Hi! How can I help you today? Type 'bye' to exit.")
    while True:
        user_input = input("You: ")
        
        if user_input.lower() == "bye":
            print("Chatbot: Goodbye! Have a great day!")
            break
        
        response = get_response(user_input)
        
        print("Chatbot:", response)

if __name__ == "__main__":
    chatbot()





          ''')
    
def pln_10():
    print(Fore.RED + '''
          
# pip install nltk, SpeechRecognition, pydub, google.colab


import nltk

nltk.download('punkt')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger')
nltk.download('wordnet')


import speech_recognition as sr

r = sr.Recognizer()
with sr.AudioFile("song.wav") as source:
   audio = r.record(source, duration=50)
try:
   text = r.recognize_google(audio)
   print("Recognized Text:")
   print(text)
except Exception as e:
   print(f"Could not recognize audio: {e}")



import nltk
nltk.download('punkt_tab')
from nltk.tokenize import word_tokenize

tokens = word_tokenize(text.lower())
print("Tokens:", tokens)



from nltk.corpus import stopwords

stop_words = set(stopwords.words("english"))
filtered_words = [w for w in tokens if w.isalpha() and w not in stop_words]
print("After Stopword Removal:", filtered_words)




from nltk.stem import PorterStemmer

ps = PorterStemmer()
stemmed_words = [ps.stem(w) for w in filtered_words]
print("Stemmed Words:", stemmed_words)



from nltk.stem import WordNetLemmatizer

lemmatizer = WordNetLemmatizer()
lemmatized_words = [lemmatizer.lemmatize(w) for w in filtered_words]
print("Lemmatized Words:", lemmatized_words)




import nltk
nltk.download('averaged_perceptron_tagger_eng')
pos_tags = nltk.pos_tag(filtered_words)
print("POS Tags:", pos_tags)




def asr_nlp_pipeline(audio_file):
   r = sr.Recognizer()

   with sr.AudioFile(audio_file) as source:
       audio = r.record(source)

   text = r.recognize_google(audio)

   tokens = word_tokenize(text.lower())
   stop_words = set(stopwords.words("english"))
   words = [w for w in tokens if w.isalpha() and w not in stop_words]

   ps = PorterStemmer()
   stemmed = [ps.stem(w) for w in words]
   pos = nltk.pos_tag(words)
   return text, words, stemmed, pos

text, words, stemmed, pos = asr_nlp_pipeline("sample.wav")
print("Text:", text)
print("Filtered Words:", words)
print("Stemmed:", stemmed)
print("POS Tags:", pos)






# Alternate (Collab)

!pip install SpeechRecognition pydub
import nltk
import os
from pydub import AudioSegment
from google.colab import files

nltk.download('punkt')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger')
nltk.download('wordnet')
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger_eng')

print("Please upload 'song.wav' and 'sample.wav' below:")
uploaded = files.upload()

# Identify the actual filenames from the upload
song_file = next((f for f in uploaded.keys() if 'song' in f.lower()), "song.wav")
sample_file = next((f for f in uploaded.keys() if 'sample' in f.lower()), "sample.wav")

# Helper function to ensure WAV is in a compatible format (PCM 16-bit)
def fix_audio_format(filename):
    if os.path.exists(filename):
        try:
            audio = AudioSegment.from_file(filename)
            audio.export(filename, format="wav")
            return True
        except Exception as e:
            print(f"Format fix error for {filename}: {e}")
    return False

import speech_recognition as sr
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer

# --- Step 1: Speech to Text ---
text = "I am learning natural language processing with machine learning"
if os.path.exists(song_file):
    fix_audio_format(song_file)
    r = sr.Recognizer()
    try:
        with sr.AudioFile(song_file) as source:
           audio = r.record(source, duration=50)
        text = r.recognize_google(audio)
        print("\nRecognized Text from", song_file, ":", text)
    except sr.UnknownValueError:
       print(f"\nSpeech Recognition could not understand {song_file}. Using default text.")
    except Exception as e:
       print(f"\nError processing {song_file}: {e}")
       
       
       
# --- Step 2: NLP Processing ---
tokens = word_tokenize(text.lower())
stop_words = set(stopwords.words("english"))
filtered_words = [w for w in tokens if w.isalpha() and w not in stop_words]
ps = PorterStemmer()
stemmed_words = [ps.stem(w) for w in filtered_words]
lemmatizer = WordNetLemmatizer()
lemmatized_words = [lemmatizer.lemmatize(w) for w in filtered_words]
pos_tags = nltk.pos_tag(filtered_words)

print("Tokens:", tokens)
print("Stemmed Words:", stemmed_words)
print("POS Tags:", pos_tags)

# --- Step 3: Pipeline Function ---
def asr_nlp_pipeline(audio_file):
   if not os.path.exists(audio_file):
       return f"Error: {audio_file} not found.", [], [], []
   
   fix_audio_format(audio_file)
   r = sr.Recognizer()
   try:
       with sr.AudioFile(audio_file) as source:
           audio = r.record(source)
       text_out = r.recognize_google(audio)
       tokens_out = word_tokenize(text_out.lower())
       words_out = [w for w in tokens_out if w.isalpha() and w not in set(stopwords.words('english'))]
       return text_out, words_out, [PorterStemmer().stem(w) for w in words_out], nltk.pos_tag(words_out)
   except Exception as e:
       return f"Error processing {audio_file}: {e}", [], [], []

if os.path.exists(sample_file):
    text_res, _, _, _ = asr_nlp_pipeline(sample_file)
    print("\nPipeline Result for", sample_file, ":", text_res)



          ''')