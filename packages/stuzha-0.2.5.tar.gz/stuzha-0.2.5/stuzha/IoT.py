from colorama import Fore, Style, init

init(autoreset=True)

def cp_1():
    print(Fore.RED + '''

# Create a new project in the Google Cloud Console and select that project.
# Navigate to Pub/Sub product and create a new topic (Topic001 - Default Topic)

# Create a new topic (Topic002) using a Schema (Schema002)
 
# Create a schema revision to create a new schema.
 
# Rollback the older schema to get another schema.
 
# Delete the entire schema in the end.


# Cloud Shell Editor
## Open editor and type:

gcloud pubsub topics list #To the get the output of all topics and schemas


gcloud pubsub subscriptions list #Displays the state and other details of the subscriptions


gcloud pubsub schemas list #List the schemas


gcloud pubsub topics list #List the topics


gcloud pubsub topics describe Topic001 


gcloud pubsub schema describe Schema002




# Create a new topic (Topic002), then go to messages and click on publish message




          ''')

def cp_2():
    print(Fore.RED + '''


# Enable the Google Artifact Registry API and navigate to the screen. Navigate to the Artifact Registry and create a new repository.
# Set the format to “Generic” and select the region as “Mumbai”.
# Set the cleanup policies to “Delete artifacts” and add a new cleanup policy.
# Enter a name and set the Policy type to “Keep most recent versions” with keep count as 1.
# Repository will be created and displayed.
# Log into the google cloud account.

# Update the components if any.

gcloud components update


# Set the project which has the repository:

gcloud config set project cloud-iot-project-2



gcloud artifacts repositories list



gcloud config set artifacts/repository practical-2-repo



gcloud config set artifacts/location asia-south1



gcloud artifacts generic upload --source=test.txt --package=demo --version=1.0.0



# The file would get uploaded to the previously created repository.

gcloud artifacts files list



gcloud artifacts files download --destination=. "demo:1.0.0:test.txt"


   
   
          ''')

def cp_3():
    print(Fore.RED + '''
          
# Create a new project and navigate to Buckets
# Authenticate using the GCloud SDK


gcloud init 


# Create a bucket

gcloud storage buckets create gs://cloud-iot-practical-3-bucket


# Upload a file to the bucket

gcloud storage cp "pkglist.txt" gs://cloud-iot-practical-3-bucket/uploaded.txt




          ''')
    
def cp_4():
    print(Fore.RED + '''

# Create a new project and navigate to Dataflow.
# Enable all the data pipeline APIs
# Authenticate using the gcloud SDK.


gcloud init


# Set up Application Default Credentials (ADC)


gcloud auth application-default login



# Install Apache Beam.


pip install apache-beam[gcp]



# Create a cloud storage bucket.


gcloud storage buckets create gs://practical-4-pipeline --default-storage-class=STANDARD



# Run the example wordcount pipeline locally.


python -m apache_beam.examples.wordcount --output outputs




# Run the wordcount pipeline on Cloud Dataflow.

python -m apache_beam.examples.wordcount --region asia-south2 --input gs://dataflow-samples/shakespeare/kinglear.txt --output gs://p4-cloud-dataflow-pipeline/results/outputs --runner DataflowRunner --project p4-cloud-dataflow-pipeline --temp_location gs://p4-cloud-dataflow-pipeline/tmp



# Alternate command


python -m apache_beam.examples.wordcount \
        --region asia-south1 \
        --runner DataflowRunner \
        --project practical-4-488111 \
        --temp_location gs://practical-4-pipeline/tmp \
        --input gs://dataflow-samples/shakespeare/kinglear.txt \
        --output gs://practical-4-pipeline/results/outputs \
        --num_workers 1 \
        --max_num_workers 1 \
        --machine_type e2-medium






# Verify the pipeline execution.
# View the output in the cloud storage bucket.

          ''')

def cp_5():
    print(Fore.RED + '''

# After creating a new google cloud project, make a new bucket in the newly created project.


gcloud storage buckets create gs://cloudiotp5


# Enable cloud Pub/Sub API for this project. 
# Go to IAM & Admin and create a new service account. Make sure to give the service account proper permissions to let it upload data into the buckets. 
# Create a new auth key and save the newly generated json auth key.
# Install python libraries:
    google-cloud-storage
    google-cloud-pubsub
    faker

# Execute the code with proper credentials file and bucket name.




from google.cloud import storage
from google.oauth2 import service_account
import time
import json
from faker import Faker
import random

fake = Faker()

credentials = service_account.Credentials.from_service_account_file(
    "C:\\Users\\Admin\\Documents\\IoTPractical5\\cloud-iot-practical-5-484507-47453c4f1b0a.json"
)

storage_client = storage.Client(credentials=credentials)

bucket_name = "cloudiotp5"
bucket = storage_client.get_bucket(bucket_name)


def generate_iot_data():
    """Generates mock IoT data"""
    data = {
        "device_id": fake.uuid4(),
        "timestamp": fake.date_time_this_year().isoformat(),
        "temperature": round(random.uniform(20.0, 30.0), 2),  
        "humidity": round(random.uniform(30.0, 70.0), 2),    
        "pressure": round(random.uniform(1000, 1050), 2),    
    }
    return json.dumps(data)


def upload_data_to_gcs(iot_data, filename):
    blob = bucket.blob(filename)
    blob.upload_from_string(iot_data, content_type="application/json")
    print(f"Data uploaded to {filename}.")


while True:
    iot_data = generate_iot_data()

    timestamp = time.time()
    filename = f"iot_data_{timestamp}.json"

    upload_data_to_gcs(iot_data, filename)

    time.sleep(5)







# Data would get uploaded every 5 seconds. 





          ''')
    
def cp_6():
    print(Fore.RED + '''


#include "arduino_secrets.h"
#include "thingProperties.h"

int LED_BUILTIN = 2;

void setup() {
  Serial.begin(9600);
  delay(1500);

  pinMode(LED_BUILTIN, OUTPUT);

  initProperties();
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);

  setDebugMessageLevel(2);
  ArduinoCloud.printDebugInfo();
}

void loop() {
  ArduinoCloud.update();
}

void onIsPoweredChange() {
  digitalWrite(LED_BUILTIN, is_powered);
}

          ''')
    
def cp_7():
    print(Fore.RED + '''

#include "arduino_secrets.h"
#include "thingProperties.h"

#include "DHT.h"
#define DHTPIN 4
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  delay(1500);
  initProperties();
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);

  setDebugMessageLevel(2);
  ArduinoCloud.printDebugInfo();

  Serial.println(F("DHT11 test!"));
  dht.begin();
}

void loop() {
  ArduinoCloud.update();
  delay(2000);
  temp = dht.readTemperature();
  if (isnan(temp)) {
    Serial.println(F("Failed to read from DHT sensor!"));
  return;
  }

  Serial.print(F("Temperature: "));
  Serial.print(temp);
  Serial.println(F(" C"));
}

void onTempChange() {

}


          ''')

def cp_8():
    print(Fore.RED + '''

#include "arduino_secrets.h"
#include "thingProperties.h"

#define FLAME_PIN 4

void setup() {
  Serial.begin(9600);
  delay(1500);

  pinMode(FLAME_PIN, INPUT);
  initProperties();
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);
  setDebugMessageLevel(2);
  ArduinoCloud.printDebugInfo();

  Serial.println("Flame sensor started!");
}

void loop() {
  ArduinoCloud.update();
  int flameValue = digitalRead(FLAME_PIN);
  flameDetected = (flameValue == LOW);
  if (flameDetected) {
    Serial.println("Flame detected!");
    } else {
      Serial.println("No flame");
    }
    delay(2000);
}

void onFlameDetectedChange() {
}



          ''')
    
def cp_9():
    print(Fore.RED + '''
          
#include "arduino_secrets.h"
#include "arduino_secrets.h"
#include "thingProperties.h"

#define PIR_PIN 4
#define LED_PIN 2

void setup() {
  Serial.begin(9600);
  delay(1500);
 
  pinMode(PIR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);

  initProperties();

  ArduinoCloud.begin(ArduinoIoTPreferredConnection);
 
  setDebugMessageLevel(2);
  ArduinoCloud.printDebugInfo();
}

void loop() {
  ArduinoCloud.update();

  bool pirState = digitalRead(PIR_PIN);
  motionDetected = pirState;
  digitalWrite(LED_PIN, pirState ? HIGH : LOW);
  if (pirState) {
    Serial.println("Motion detected!");
    } else {
    Serial.println("No motion");
    }
  delay(300);
 
}

void onMotionDetectedChange()  {
}

          
          ''')