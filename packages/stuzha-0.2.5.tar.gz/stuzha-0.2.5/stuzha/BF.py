from colorama import Fore, Style, init

init(autoreset=True)

def fb_1():
    print(Fore.RED + '''

# AES Encryption Decryption


# pip install cryptography

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
import os


def aes_encrypt(key, plaintext):
   iv = os.urandom(16) 
   cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
   encryptor = cipher.encryptor()
   padder = padding.PKCS7(128).padder()
   padded_data = padder.update(plaintext.encode()) + padder.finalize()
   ciphertext = encryptor.update(padded_data) + encryptor.finalize()
   return iv + ciphertext

def aes_decrypt(key, ciphertext):
   iv = ciphertext[:16]
   actual_ciphertext = ciphertext[16:]

   cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
   decryptor = cipher.decryptor()

   padded_plaintext = decryptor.update(actual_ciphertext) + decryptor.finalize()

   unpadder = padding.PKCS7(128).unpadder()
   plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()

   return plaintext.decode()

key = os.urandom(32) 
message = "Hello AES!"

encrypted = aes_encrypt(key, message)
print("Encrypted AES:", encrypted)

decrypted = aes_decrypt(key, encrypted)
print("Decrypted AES:", decrypted)




# Blowfish cipher


# pip install pycryptodome

from Crypto.Cipher import Blowfish
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

key = b"mysecretkey"
iv = get_random_bytes(8)

cipher = Blowfish.new(key, Blowfish.MODE_CBC, iv)
ciphertext = iv + cipher.encrypt(pad(b"Hello Blowfish!", 8))

iv = ciphertext[:8]
cipher = Blowfish.new(key, Blowfish.MODE_CBC, iv)
plaintext = unpad(cipher.decrypt(ciphertext[8:]), 8)

print("Encrypted:", ciphertext)
print("Decrypted:", plaintext)




# RSA


from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

private_key = rsa.generate_private_key(
   public_exponent=65537,
   key_size=2048,
)
public_key = private_key.public_key()

message = b"Hello RSA!"
ciphertext = public_key.encrypt(
   message,
   padding.OAEP(
       mgf=padding.MGF1(algorithm=hashes.SHA256()),
       algorithm=hashes.SHA256(),
       label=None,
   ),
)
print("Encrypted:", ciphertext)

plaintext = private_key.decrypt(
   ciphertext,
   padding.OAEP(
       mgf=padding.MGF1(algorithm=hashes.SHA256()),
       algorithm=hashes.SHA256(),
       label=None,
   ),
)
print("Decrypted:", plaintext)




# DSA


from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import utils

private_key = dsa.generate_private_key(key_size=2048)


def dsa_sign(private_key, message):
   signature = private_key.sign(message.encode(), hashes.SHA256())
   return signature


def dsa_verify(public_key, message, signature):
   try:
       public_key.verify(signature, message.encode(), hashes.SHA256())
       return True
   except:
       return False

message = "Hello DSA!"
signature = dsa_sign(private_key, message)
public_key = private_key.public_key()

print("Signature valid?", dsa_verify(public_key, message, signature))






''')

def fb_2():
    print(Fore.RED + '''

# SHA-256


import hashlib

def generate_hash(data):
   hash_object = hashlib.sha256()
   hash_object.update(data.encode())
   return hash_object.hexdigest()

def verify_hash(data, original_hash):
   new_hash = generate_hash(data)
   return new_hash == original_hash

data = "This is a secret message."
hash_value = generate_hash(data)
print(f"Hash: {hash_value}")

print("Verification (correct data):", verify_hash(data, hash_value))

print(
   "Verification (tampered data):",
   verify_hash("This is a tampered message.", hash_value),
)




# HMAC


import hashlib
import hmac

def generate_hash(data):
   hash_object = hashlib.sha256()
   hash_object.update(data.encode()) 
   return hash_object.hexdigest()

def verify_hash(data, original_hash):
   new_hash = generate_hash(data)
   return hmac.compare_digest(new_hash, original_hash)

def check_data_integrity(data, original_hash):
   if verify_hash(data, original_hash):
       print("Data is intact and verified.")
   else:
       print("Warning: Data has been tampered with!")

original_data = "This is a secret message."
hash_value = generate_hash(original_data)
print(f"Original Hash: {hash_value}\n")

print("Checking original data:")
check_data_integrity(original_data, hash_value)

tampered_data = "This is a hacked message."
print("\nChecking data with a hacked message:")
check_data_integrity(tampered_data, hash_value)

tampered_data_space = "This is a secret message. "
print("\nChecking data with added space:")
check_data_integrity(tampered_data_space, hash_value)

tampered_data_char = "This is a secet message."
print("\nChecking data with missing character:")
check_data_integrity(tampered_data_char, hash_value)





          ''')
          
def fb_3():
    print(Fore.RED + '''

# Single Block Generation


import hashlib
import time
import json
class Block:
   def __init__(self, index, data, previous_hash):
       self.index = index
       self.timestamp = time.time()
       self.data = data
       self.previous_hash = previous_hash
       self.nonce = 0
       self.hash = self.compute_hash()
  
   def compute_hash(self):
       block_string = json.dumps({
       'index': self.index,
       'timestamp': self.timestamp,
       'data': self.data,
       'previous_hash': self.previous_hash,
       'nonce': self.nonce
       }, sort_keys=True)
       return hashlib.sha256(block_string.encode()).hexdigest()

genesis_block = Block(0, "Genesis Block", "0")
print("Block index:", genesis_block.index)
print("Block timestamp:", genesis_block.timestamp)
print("Block data:", genesis_block.data)
print("Previous hash:", genesis_block.previous_hash)
print("Current hash:", genesis_block.hash)




# User input single block one transaction


import hashlib
from datetime import datetime
import json

def create_blockchain_transaction_block():
   print("--- Blockchain Transaction Block Creation ---")

   sender = input("Enter Sender Address (Public Key): ")
   recipient = input("Enter Recipient Address (Public Key): ")
   amount_str = input("Enter Transaction Amount: ")

   try:
       amount = float(amount_str)
   except ValueError:
       print("\n[ERROR] Transaction Amount must be a valid number.")
       return None
  
   timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

   transaction_block = {
   "timestamp": timestamp,
   "sender": sender,
   "recipient": recipient,
   "amount": amount,
   "previous_hash": "0" * 64,
   "nonce": 0
   }

   block_string = json.dumps(transaction_block, sort_keys=True).encode()
   transaction_block["current_hash"] = hashlib.sha256(block_string).hexdigest()
   print("\n--- Secure Transaction Block Created ---")

   for key, value in transaction_block.items():
       print(f" {key}: {value}")
  
   return transaction_block

new_block = create_blockchain_transaction_block()




# Single Block with multiple transactions


import hashlib
import datetime
import json
class Block:
   def __init__(self, transactions, previous_hash="0"*64):
       self.index = 0
       self.timestamp = str(datetime.datetime.now())
       self.transactions = transactions
       self.previous_hash = previous_hash
       self.nonce = 0
       self.hash = self.compute_hash()

   def compute_hash(self):
       block_string = json.dumps({
       'index': self.index,
       'timestamp': self.timestamp,
       'transactions': self.transactions,
       'previous_hash': self.previous_hash,
       'nonce': self.nonce
       }, sort_keys=True)
       return hashlib.sha256(block_string.encode()).hexdigest()
  
   def __str__(self):
       return (f"Block index: {self.index}\n"
           f"Timestamp: {self.timestamp}\n"
           f"Transactions:\n" + "\n".join(f" - {tx}" for tx in self.transactions) + "\n"
           f"Previous hash: {self.previous_hash}\n"
           f"Hash: {self.hash}\n")

transactions = [
"Alice pays Bob 5 BTC",
"Bob pays Charlie 2 BTC",
"Charlie pays Dave 1 BTC"
]
block = Block(transactions)
print(block)




# Single Block with multiple transactions and Proof of Work


import hashlib
import datetime
import json
import time
import random
import sys

class Block:
   def __init__(self, transactions, difficulty=2, previous_hash="0"*64):
       self.index = 0
       self.timestamp = str(datetime.datetime.now())
       self.transactions = transactions
       self.previous_hash = previous_hash
       self.nonce = 0
       self.difficulty = difficulty
       self.hash = self.compute_hash()
      
   def compute_hash(self):
       block_string = json.dumps({
           'index': self.index,
           'timestamp': self.timestamp,
           'transactions': self.transactions,
           'previous_hash': self.previous_hash,
           'nonce': self.nonce
           }, sort_keys=True)
       return hashlib.sha256(block_string.encode()).hexdigest()
      
   def mine(self):
       print(f"Mining block with difficulty {self.difficulty}...")
       start_time = time.time()
       required_prefix = "0" * self.difficulty
       while not self.hash.startswith(required_prefix):
           self.nonce = random.randint(0, sys.maxsize)
           self.hash = self.compute_hash()
       end_time = time.time()
       print(f"Block mined: {self.hash}")
       print(f"Nonce found: {self.nonce}")
       print(f"Time taken to mine: {end_time - start_time:.2f} seconds\n")

   def __str__(self):
       return (f"Block index: {self.index}\n"
           f"Timestamp: {self.timestamp}\n"
           f"Transactions:\n" + "\n".join(f" - {tx}" for tx in self.transactions) + "\n"
           f"Previous hash: {self.previous_hash}\n"
           f"Nonce: {self.nonce}\n"
           f"Hash: {self.hash}\n")

transactions = [
"Alice pays Bob 5 BTC",
"Bob pays Charlie 2 BTC",
"Charlie pays Dave 1 BTC"
]

block = Block(transactions, difficulty=4)
block.mine()
print(block)



# Single Block with User Input and Proof-of-Work


import hashlib
from datetime import datetime

DIFFICULTY_LEVEL = 0
BLOCKCHAIN = []

class Block:
   def __init__(self, data, prev_hash="0" * 64):
       self.blockId = len(BLOCKCHAIN)
       self.timestamp = datetime.now().strftime("%d-%b-%y %H:%M:%S.%f")
       self.data = data
       self.prev_hash = prev_hash
       self.nonce = 0
       self.hash = self.hashBlock()

   def hashBlock(self):
       block_string = str(self.blockId) + str(self.data) + str(self.prev_hash) + str(self.nonce)
       self.hash = hashlib.sha256(block_string.encode()).hexdigest()
       while self.hash[:DIFFICULTY_LEVEL] != "0" * DIFFICULTY_LEVEL:
           self.nonce += 1
           block_string = str(self.blockId) + str(self.data) + str(self.prev_hash) + str(self.nonce)
           self.hash = hashlib.sha256(block_string.encode()).hexdigest()
       return self.hash

   def __str__(self):
       return (f"\nBlock ID: {self.blockId}\n"
           f"Timestamp: {self.timestamp}\n"
           f"Data: {self.data}\n"
           f"Previous Hash: {self.prev_hash}\n"
           f"Nonce: {self.nonce}\n"
           f"Hash: {self.hash}\n")

data = input("Enter the data for the block: ")

DIFFICULTY_LEVEL = int(input("Enter difficulty level (number of leading zeros): "))

prev_hash = BLOCKCHAIN[-1].hash if BLOCKCHAIN else "0" * 64
block = Block(data, prev_hash)
BLOCKCHAIN.append(block)

print("\nBlock added to the blockchain:")
print(block)



         ''')
        
def fb_4():
    print(Fore.RED + '''

# Multiple Block Generation

import hashlib
import json
import time

def create_transaction(sender, recipient, amount):
   return {
       "sender": sender,
       "recipient": recipient,
       "amount": amount
   }

def compute_hash(block):
   block_string = json.dumps(block, sort_keys=True).encode()
   return hashlib.sha256(block_string).hexdigest()

def create_block(index, transactions, previous_hash):
   block = {
       'index': index,
       'timestamp': time.time(),
       'transactions': transactions,
       'previous_hash': previous_hash,
   }
   block['hash'] = compute_hash(block)
   return block


def generate_blockchain(num_blocks, tx_per_block=2):
   blockchain = []
   genesis_block = create_block(0, [], "0")
   blockchain.append(genesis_block)
   for i in range(1, num_blocks):
       transactions = [
           create_transaction(f"User{i}", f"User{i+1}", i * 10 + j)
           for j in range(tx_per_block)
       ]
       previous_hash = blockchain[-1]['hash']
       new_block = create_block(i, transactions, previous_hash)
       blockchain.append(new_block)
   return blockchain

if __name__ == "__main__":
   chain = generate_blockchain(5, tx_per_block=3)
   for block in chain:
       print(json.dumps(block, indent=4), "\n")





# Blockchain with multiple blocks and basic validation

import hashlib

import json
import time

def hash_block(block):
   block_string = json.dumps(block, sort_keys=True).encode()
   return hashlib.sha256(block_string).hexdigest()

def create_block(index, previous_hash, transactions):
   block = {
   'index': index,
   'timestamp': time.time(),
   'transactions': transactions,
   'previous_hash': previous_hash,
   }
   block['hash'] = hash_block(block)
   return block

def is_valid_block(block, previous_block):
   if block['index'] != previous_block['index'] + 1:
       print("Invalid index")
       return False
  
   if block['previous_hash'] != previous_block['hash']:

       print("Previous hash mismatch")
       return False
  
   if hash_block({k: block[k] for k in block if k != 'hash'}) != block['hash']:
       print("Hash mismatch")
       return False
   return True

def is_valid_chain(chain):
   for i in range(1, len(chain)):
       if not is_valid_block(chain[i], chain[i-1]):
           print(f"Block {i} is invalid")
           return False
   return True

chain = []
chain.append(create_block(0, "0", []))
for i in range(1, 3):
   txns = [f"User{i} pays User{i+1} {10 * j}" for j in range(1, 4)]
   chain.append(create_block(i, chain[-1]['hash'], txns))


for block in chain:
   print(json.dumps(block, indent=4))
   print()

print("Is blockchain valid?", is_valid_chain(chain))





# Multiple block generation with Proof of work

DIFFICULTY = 4

def create_transaction(sender, recipient, amount):
   return {
       "sender": sender,
       "recipient": recipient,
       "amount": amount
   }

def compute_hash(block):
   block_string = json.dumps(block, sort_keys=True).encode()
   return hashlib.sha256(block_string).hexdigest()

def mine_block(block):
   block['nonce'] = 0

   computed_hash = compute_hash(block)
   while not computed_hash.startswith('0' * DIFFICULTY):
       block['nonce'] += 1
       computed_hash = compute_hash(block)
   return computed_hash

def create_block(index, transactions, previous_hash):
   block = {
   'index': index,
   'timestamp': time.time(),
   'transactions': transactions,
   'previous_hash': previous_hash,
   'nonce': 0
   }
   block['hash'] = mine_block(block)
   return block

def generate_blockchain(num_blocks, tx_per_block=2):
   blockchain = []
   genesis_block = create_block(0, [], "0")
   blockchain.append(genesis_block)
   for i in range(1, num_blocks):
       transactions = [
           create_transaction(f"User{i}", f"User{i+1}", i * 10 + j)
           for j in range(tx_per_block)
       ]
   previous_hash = blockchain[-1]['hash']
   new_block = create_block(i, transactions, previous_hash)
   blockchain.append(new_block)
   return blockchain

if __name__ == "__main__":
   chain = generate_blockchain(3, tx_per_block=3)
   for block in chain:
       print(json.dumps(block, indent=4), "\n")






# Multiple block generation with user input

import hashlib
import json
import time

def create_transaction(sender, recipient, amount):
   return {
       "sender": sender,
       "recipient": recipient,
       "amount": amount
   }

def compute_hash(block):
   block_string = json.dumps(block, sort_keys=True).encode()
   return hashlib.sha256(block_string).hexdigest()

def create_block(index, transactions, previous_hash):
   block = {
       'index': index,
       'timestamp': time.time(),
       'transactions': transactions,
       'previous_hash': previous_hash,
   }
   block['hash'] = compute_hash(block)
   return block

def generate_blockchain_with_input():
   blockchain = []
  
   # Create genesis block
   genesis_block = create_block(0, [], "0")
   blockchain.append(genesis_block)
   print("Genesis block created.\n")
  
   # Get number of blocks
   num_blocks = int(input("Enter the number of blocks to generate: "))
  
   # Generate each block
   for i in range(1, num_blocks):
       print(f"\n--- Block {i} ---")
       num_transactions = int(input(f"Enter number of transactions for block {i}: "))
      
       transactions = []
       for j in range(num_transactions):
           print(f"  Transaction {j+1}:")
           sender = input(f"    Sender address: ")
           recipient = input(f"    Recipient address: ")
           amount = float(input(f"    Amount: "))
           transactions.append(create_transaction(sender, recipient, amount))
      
       previous_hash = blockchain[-1]['hash']
       new_block = create_block(i, transactions, previous_hash)
       blockchain.append(new_block)
       print(f"Block {i} created successfully!")
  
   return blockchain

if __name__ == "__main__":
   chain = generate_blockchain_with_input()
  
   print("\n" + "="*50)
   print("GENERATED BLOCKCHAIN")
   print("="*50 + "\n")
  
   for block in chain:
       print(json.dumps(block, indent=4), "\n")


         ''')
    
def fb_5():
    print(Fore.RED + '''


# Message


pragma solidity ^0.8;

contract Message {
   string public message;

   constructor(string memory newMessage) {
       message = newMessage;
   }

   function setMessage(string memory newMessage) public {
       message = newMessage;
   }

   function getMessage() public view returns (string memory) {
       return message;
   }
}




# Calculator

pragma solidity ^0.8;

contract n {
   uint public na;
   uint public nb;
   constructor(uint _na, uint _nb) {
       na = _na;
       nb = _nb;
   }
  
   function add() public view returns (uint) {
       return na + nb;
   }
   function sub() public view returns (uint) {
       require(na >= nb, "Subtraction results in negative value");
       return na - nb;
   }
   function mul() public view returns (uint) {
       return na * nb;
   }

   function div() public view returns (uint) {
       require(nb != 0, "Division by zero is not allowed");
       return na / nb;
   }
   function getAllResults() public view returns (uint, uint, uint, uint) {
       uint sum = na + nb;
       uint diff = na >= nb ? na - nb : 0;
       uint prod = na * nb;
       uint quotient = nb != 0 ? na / nb : 0;
       return (sum, diff, prod, quotient);
   }
   function setValues(uint _na, uint _nb) public {
       na = _na;
       nb = _nb;
   }
}






# Factorial


pragma solidity ^0.8;

contract f {
   uint public a;
   constructor(uint _a) {
       a = _a;
   }
   function fact() public view returns (uint256) {
       uint256 r = 1;
       for (uint256 i = 1; i <= a; i++) {
           r *= i;
       }
       return r;
   }
}






# Prime or not

pragma solidity ^0.8;

contract PrimeCheck {
   uint public a;
   constructor(uint _a) {
       a = _a;
   }
   function isPrime() public view returns (bool) {
       if (a <= 1) {
           return false;
       }
       for (uint256 i = 2; i * i <= a; i++) {
           if (a % i == 0) {
               return false;
           }
       }
       return true;
   }
}






# Odd or even


pragma solidity ^0.8;
contract EvenOddCheck {
   uint public a;
   constructor(uint _a) {
       a = _a;
   }
   function isEven() public view returns (string memory) {
       if (a % 2 == 0) {
           return "Number is even";
       } else {
           return "Number is odd";
       }
   }
}







# Numbers to weekdays

pragma solidity ^0.8;

contract Weekday {
   function getWeekday(uint8 day) public pure returns (string memory) {
       if (day == 1) {
           return "Monday";
       } else if (day == 2) {
           return "Tuesday";
       } else if (day == 3) {
           return "Wednesday";
       } else if (day == 4) {
           return "Thursday";
       } else if (day == 5) {
           return "Friday";
       } else if (day == 6) {
           return "Saturday";
       } else if (day == 7) {
           return "Sunday";
       } else {
           return "Invalid input";
       }
   }
}






# Structures


pragma solidity ^0.8;

contract SimpleStruct {
   struct Person {
       string name;
       uint age;
   }

   Person public person;

   function setPerson(string memory _name, uint _age) public {
       person.name = _name;
       person.age = _age;
   }

   function getPerson() public view returns (string memory, uint) {
       return (person.name, person.age);
   }
}






# Arrays


pragma solidity ^0.8;

contract SimpleArray {
   uint[] public numbers;
   function addNumber(uint _number) public {
       numbers.push(_number);
   }
   function getNumbers() public view returns (uint[] memory) {
       return numbers;
   }
   function getNumberCount() public view returns (uint) {
       return numbers.length;
   }
}

          ''')
     
def fb_6():
    print(Fore.RED + '''

# Inheritance


## Single Inheritance

pragma solidity ^0.8;

contract Contract_A {
   uint256 value;

   constructor(uint256 n) {
       value = n;
   }
   function incrementValue(uint256 x) public {
       value += x;
   }
}

contract Contract_B is Contract_A(22) {
   function getValue() public view returns (uint256) {
       return value;
   }
}





## Multilevel Inheritance

pragma solidity ^0.8;

contract Contract_A {
   uint256 value;

   constructor(uint256 n) {
       value = n;
   }
   function incrementValue(uint256 x) public {
       value += x;
   }
}

contract Contract_B is Contract_A(22) {
   function decrementValue(uint256 x) public {
       value -= x;
   }
}

contract Contract_C is Contract_B {
   function getValue() public view returns (uint256) {
       return value;
   }
}






## Hierarchical Inheritance

pragma solidity ^0.8;

contract Contract_A {
   uint256 value;
   constructor(uint256 n) {
       value = n;
   }

   function getValue() public view returns (uint256) {
       return value;
   }
}

contract Contract_B is Contract_A(22) {
   function incrementValue(uint256 x) public {
       value += x;
   }
}

contract Contract_C is Contract_A(25) {
   function decrementValue(uint256 x) public {
       value -= x;
   }
}






## Multiple Inheritance


pragma solidity ^0.8;

contract Contract_A {
   uint256 value;
   constructor(uint256 n) {
       value = n;
   }
   function incrementValue(uint256 x) public {
       value += x;
   }
}

contract Contract_B is Contract_A(25) {
   function decrementValue(uint256 x) public {
       value -= x;
   }
}

contract Contract_C is Contract_A, Contract_B {
   function getValue() public view returns (uint256) {
       return value;
   }
}






# Libraries in Solidity

## Library definition


pragma solidity ^0.8;

library lib {
   function increment(uint val) public pure returns (uint) {
       return val + 1;
   }

   function decrement(uint val) public pure returns (uint) {
       return val - 1;
   }

   function incrementByValue(uint val, uint x) public pure returns (uint) {
       return val + x;
   }
  
   function decrementByValue(uint val, uint x) public pure returns (uint) {
       return val - x;
   }
}






## Using the library


pragma solidity ^0.8;

import "Practical 6/Library/librarydefn.sol";

contract useLibrary {
   using lib for uint;
  
   function testIncrement(uint userVal) public pure returns (uint) {
       return lib.increment(userVal);
   }

   function testDecrement(uint userVal) public pure returns (uint) {
       return lib.decrement(userVal);
   }
  
   function testIncrementByValue(
       uint userVal,
       uint x
   ) public pure returns (uint) {
       return lib.incrementByValue(userVal, x);
   }

   function testDecrementByValue(
       uint userVal,
       uint x
       ) public pure returns (uint) {
           return lib.decrementByValue(userVal, x);
       }
}







# Mappings in Solidity 

pragma solidity ^0.8;

contract mappingExample {
   mapping(int => string) details;
   function addDetails(int id, string memory name) public {
       details[id] = name;
   }
  
   function updateDetails(int id, string memory name) public {
       details[id] = name;
   }

   function getDetails(int id) public view returns (string memory) {
       return details[id];
   }
}





# Modifiers and Access Control

## Modifier without argument (Admin only)


pragma solidity ^0.8;

contract modifierWithoutArg {
   address admin;
   struct employee {
       uint emp_id;
       string emp_name;
       uint age;
   }
   employee e;
   constructor() {
       admin = msg.sender;
   }
   modifier isAdmin() {
       require(admin == msg.sender, "Not authorized");
       _;
   }
  
   function enterDetails(
       uint _empid,
       string memory _empname,
       uint _empage
       ) public isAdmin {
           e.emp_id = _empid;
           e.emp_name = _empname;
           e.age = _empage;
       }
}





## Modifier with argument (Experience check)


pragma solidity ^0.8;

contract modifierWithArg {
   struct employee {
       uint emp_id;
       string emp_name;
       uint age;
   }
   employee e;
   modifier isExperienced(uint exp) {
       if (exp >= 5) {
           _;
       } else {
           revert("Must have a minimum of 5 years of experience");
       }
   }
   function enterDetails(
       uint _empid,
       string memory _empname,
       uint _empage
       ) public isExperienced(2) {
           e.emp_id = _empid;
           e.emp_name = _empname;
           e.age = _empage;
       }
}







## Multiple Modifiers (Admin and Experience check)

pragma solidity ^0.8;

contract multiplemodifier {
   address admin;
   struct employee {
       uint emp_id;
       string emp_name;
       uint age;
   }
   employee e;

   constructor() {
       admin = msg.sender;
   }

   modifier isAdmin() {
       require(admin == msg.sender, "Not authorized");
       _;
   }
   modifier isExperienced(uint exp) {
       if (exp >= 5) {
           _;
       } else {
           revert("Must have a minimum of 5 years of experience");
       }
   }
   function enterDetails(
       uint _empid,
       string memory _empname,
       uint _empage
       ) public isAdmin isExperienced(2) {
           e.emp_id = _empid;
           e.emp_name = _empname;
           e.age = _empage;
       }
}






# Structs and Arrays

pragma solidity ^0.8;

contract StructExample {
    struct Employee {
        uint emp_id;
        string emp_name;
        uint age;
    }

    uint[] public dynamicArray;

    function add(uint value) public {
        dynamicArray.push(value);
    }

    function getArray() public view returns (uint[] memory) {
        return dynamicArray;
    }

    function staticArrayExample() public pure returns (uint) {
        uint[3] memory c = [uint(1), 2, 3]; 
        assert(c.length == 3);
        return c.length;
    }
}





# Error handling in Solidity

## Using require


pragma solidity ^0.8;

contract RequireStatement {
   function checkInput(uint _input) public pure returns (string memory) {
       require(_input >= 0, "invalid uint8");
       require(_input <= 255, "invalid uint8");
       return "Input is Uint8";
   }
  
   function odd(uint _input) public pure returns (bool) {
       require(_input % 2 != 0, "Input is not odd");
       return true;
   }
}






## Using assert


pragma solidity ^0.8;

contract AssertStatement {
   bool result;
   function checkOverflow(uint _num1, uint _num2) public {
       uint sum = _num1 + _num2;
       assert(sum <= 255);
       result = true;
   }
  
   function getResult() public view returns (string memory) {
       if (result == true) {
           return "No Overflow";
       } else {
           return "Overflow exists";
       }
   }
}







# Using revert


pragma solidity ^0.8;

contract RevertStatement {
   function checkOverflow(uint _num1, uint _num2)
   public
   pure
   returns (string memory, uint)
   {
       uint sum = _num1 + _num2;
       if (sum > 255) {
           revert("Overflow Exist");
       } else {
           return ("No Overflow", sum);
       }
   }
}

          ''')
    
def fb_7():
    print(Fore.RED + '''

# Launch Ganache and create a new workspace. 
# Download and extract MyEtherWallet v3.11.2.4 and open the index.html file.
# Add a custom node in MyEtherWallet by getting the RPC Server Address from Ganache. 
# Navigate to contracts on MyEtherWallet and select “Deploy Contract”

# Write the below CRUD smart contract in Remix IDE



pragma solidity >0.4.0 <0.6.0;

contract Crud {
   struct User {
       uint id;
       string name;
       string email;
       uint age;
   }
  
   User[] users;
   uint nextId;
   function create(
       string memory name,
       string memory email,
       uint age
       ) public {
           users.push(User(nextId, name, email, age));
           nextId++;
       }
      
   function read(uint id)
   public
   view
   returns (
       uint,
       string memory,
       string memory,
       uint
       )
   {
       uint i = find(id);
       return (
           users[i].id,
           users[i].name,
           users[i].email,
           users[i].age
       );
   }
   function update(
       uint id,
       string memory name,
       string memory email,
       uint age
       ) public {
           uint i = find(id);
           users[i].name = name;
           users[i].email = email;
           users[i].age = age;
       }
  
   function destroy(uint id) public {
       uint i = find(id);
       delete users[i];
   }
  
   function find(uint id) internal view returns (uint) {
       for (uint i = 0; i < users.length; i++) {
           if (users[i].id == id) {
               return i;
           }
   }
   revert("User does not exist");
   }
}





# Compile the smart contract using compiler version 0.5.17+commit.d19bba13 and copy the generated bytecode.
# Paste the byte code in the previously opened “Deployed Contract” page of MyEtherWallet.
# Copy the private key from one of the accounts from Ganache by pressing the key icon and paste it in MyEtherWallet and unlock the wallet.
# Sign the transaction and deploy the contract.
# Verify the contract creation in Ganache (In the transactions tab).
# Select “Interact with Contract” on MyEtherWallet. 
# Copy and paste the created Contract address from Ganache along with the generated ABI from Remix IDE. 
# Click access to view the smart contract functions. 
# Perform CRUD operations.
          
          ''')
    
def fb_8():
    print(Fore.RED + '''
        

# Single Node Blockchain with Flask API


import datetime
import hashlib
import json
from flask import Flask, jsonify, request
import requests
from uuid import uuid4
from urllib.parse import urlparse

class Blockchain:
   def __init__(self):
       self.chain = []
       self.transactions = []
       self.create_block(proof=1, previous_hash='0')
       self.nodes = set()

   def create_block(self, proof, previous_hash):
       block = {
           'index': len(self.chain) + 1,
           'timestamp': str(datetime.datetime.now()),
           'proof': proof,
           'previous_hash': previous_hash,
           'transaction': self.transactions
       }
       self.transactions = []
       self.chain.append(block)
       return block

   def get_previous_block(self):
       return self.chain[-1]

   def proof_of_work(self, previous_proof):
       new_proof = 1
       check_proof = False
       while check_proof is False:
           hash_value = hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()
           if hash_value[:5] == '00000':
               check_proof = True
           else:
               new_proof += 1
       return new_proof

   def hash(self, block):
       encoded_block = json.dumps(block, sort_keys=True).encode()
       return hashlib.sha256(encoded_block).hexdigest()

   def is_chain_valid(self, chain):
       previous_block = chain[0]
       block_index = 1
       while block_index < len(chain):
           block = chain[block_index]
           if block['previous_hash'] != self.hash(previous_block):
               return False
           previous_proof = previous_block['proof']
           new_proof = block['proof']
           hash_value = hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()
           if hash_value[:5] != '00000':
               return False
           previous_block = block
           block_index += 1
       return True

   def add_transaction(self, sender, receiver, amount):
       self.transactions.append({
           'sender': sender,
           'receiver': receiver,
           'amount': amount
       })
       previous_block = self.get_previous_block()
       return previous_block['index'] + 1

   def add_node(self, address):
       parsed_url = urlparse(address)
       self.nodes.add(parsed_url.netloc)

   def replace_chain(self):
       network = self.nodes
       max_length = len(self.chain)
       longest_chain = None
       for node in network:
           response = requests.get(f'http://{node}/get_chain')
           if response.status_code == 200:
               length = response.json()['length']
               chain = response.json()['chain']
               if length > max_length and self.is_chain_valid(chain):
                   max_length = length
                   longest_chain = chain
       if longest_chain:
           self.chain = longest_chain
           return True
       return False

app = Flask(__name__)
blockchain = Blockchain()

@app.route('/mine_block', methods=['GET'])
def mine_block():
   previous_block = blockchain.get_previous_block()
   previous_proof = previous_block['proof']
   proof = blockchain.proof_of_work(previous_proof)
   previous_hash = blockchain.hash(previous_block)
   block = blockchain.create_block(proof, previous_hash)
   response = {
       'message': 'block is mined',
       'index': block['index'],
       'timestamp': block['timestamp'],
       'proof': block['proof'],
       'previous_hash': block['previous_hash'],
       'transactions': block['transactions']
   }
   return jsonify(response), 200

@app.route('/get_chain', methods=['GET'])
def get_chain():
   response = {
       'chain': blockchain.chain,
       'length': len(blockchain.chain)
   }
   return jsonify(response), 200

@app.route('/is_valid', methods=['GET'])
def is_valid():
   is_valid = blockchain.is_chain_valid(blockchain.chain)
   if is_valid:
       response = {'message': 'Your chain is validated'}
   else:
       response = {'message': 'Your chain is not valid'}
   return jsonify(response), 200

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
   json_data = request.get_json()
   transaction_keys = ['sender', 'receiver', 'amount']
   if not all(key in json_data for key in transaction_keys):
       return 'Some elements are missing', 400
   index = blockchain.add_transaction(json_data['sender'], json_data['receiver'], json_data['amount'])
   response = {'Message': f'The transaction is added to block {index}'}
   return jsonify(response), 201

@app.route('/connect_nodes', methods=['POST'])
def connect_nodes():
   json_data = request.get_json()
   nodes = json_data.get('nodes')
   if nodes is None:
       return 'No Nodes', 400
   for node in nodes:
       blockchain.add_node(node)
   response = {
       'message': 'all nodes are now connected',
       'Total nodes': list(blockchain.nodes)
   }
   return jsonify(response), 201

@app.route('/replace_chain', methods=['GET'])
def replace_chain():
   is_chain_replaced = blockchain.replace_chain()
   if is_chain_replaced:
       response = {
           'message': 'chain replaced',
           'new_chain': blockchain.chain
       }
   else:
       response = {
           'message': 'chain not replaced',
           'new_chain': blockchain.chain
       }
   return jsonify(response), 200

app.run(host='0.0.0.0', port=5001)





# GET
# localhost:5001/get_chain

# POST
# localhost:5001/add_transaction
# Body: 
{
    "sender": "abc",
    "receiver": "xyz",
    "amount": "10"
}


# GET
# localhost:5001/mine_block

# GET
# localhost:5001/get_chain



          ''')
    
def fb_9():
    print(Fore.RED + '''
          

# blockchain1.py

import datetime
import hashlib
import json
from flask import Flask, jsonify, request
import requests
from uuid import uuid4
from urllib.parse import urlparse

class Blockchain:
   def __init__(self):
       self.chain = []
       self.transactions = []
       self.create_block(proof=1, previous_hash=0)
       self.nodes = set()

   def create_block(self, proof, previous_hash):
       block = {
           'index': len(self.chain) + 1,
           'timestamp': str(datetime.datetime.now()),
           'proof': proof,
           'previous_hash': previous_hash,
           'transaction': self.transactions
       }
       self.transactions = []
       self.chain.append(block)
       return block

   def get_previous_block(self):
       return self.chain[-1]

   def proof_of_work(self, previous_proof):
       new_proof = 1
       check_proof = False
       while check_proof is False:
           hash_value = hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()
           if hash_value[:5] == '00000':
               check_proof = True
           else:
               new_proof += 1
       return new_proof

   def hash(self, block):
       encoded_block = json.dumps(block, sort_keys=True).encode()
       return hashlib.sha256(encoded_block).hexdigest()

   def is_chain_valid(self, chain):
       previous_block = chain[0]
       block_index = 1
       while block_index < len(chain):
           block = chain[block_index]
           if block['previous_hash'] != self.hash(previous_block):
               return False
           previous_proof = previous_block['proof']
           new_proof = block['proof']
           hash_value = hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()
           if hash_value[:5] != '00000':
               return False
           previous_block = block
           block_index += 1
       return True

   def add_transaction(self, sender, receiver, amount):
       self.transactions.append({
           'sender': sender,
           'receiver': receiver,
           'amount': amount
       })
       previous_block = self.get_previous_block()
       return previous_block['index'] + 1

   def add_node(self, address):
       parsed_url = urlparse(address)
       self.nodes.add(parsed_url.netloc)

   def replace_chain(self):
       network = self.nodes
       max_length = len(self.chain)
       longest_chain = None
       for node in network:
           response = requests.get(f'http://{node}/get_chain')
           if response.status_code == 200:
               length = response.json()['length']
               chain = response.json()['chain']
               if length > max_length and self.is_chain_valid(chain):
                   max_length = length
                   longest_chain = chain
       if longest_chain:
           self.chain = longest_chain
           return True
       return False

app = Flask(__name__)
blockchain = Blockchain()

@app.route('/mine_block', methods=['GET'])
def mine_block():
   previous_block = blockchain.get_previous_block()
   previous_proof = previous_block['proof']
   proof = blockchain.proof_of_work(previous_proof)
   previous_hash = blockchain.hash(previous_block)
   block = blockchain.create_block(proof, previous_hash)
   response = {
       'message': 'block is mined',
       'index': block['index'],
       'timestamp': block['timestamp'],
       'proof': block['proof'],
       'previous_hash': block['previous_hash']
   }
   return jsonify(response), 200

@app.route('/get_chain', methods=['GET'])
def get_chain():
   response = {
       'chain': blockchain.chain,
       'length': len(blockchain.chain)
   }
   return jsonify(response), 200

@app.route('/is_valid', methods=['GET'])
def is_valid():
   is_valid = blockchain.is_chain_valid(blockchain.chain)
   if is_valid:
       response = {'message': 'Your chain is validated'}
   else:
       response = {'message': 'Your chain is not valid'}
   return jsonify(response), 200

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
   json = request.get_json()
   transaction_keys = ['sender', 'receiver', 'amount']
   if not all(key in json for key in transaction_keys):
       return 'Some elements are missing', 400
   index = blockchain.add_transaction(
       json['sender'],
       json['receiver'],
       json['amount']
   )
   response = {'Message': f'The transaction is added to block {index}'}
   return jsonify(response), 201

@app.route('/connect_nodes', methods=['POST'])
def connect_nodes():
   json = request.get_json()
   nodes = json.get('nodes')
   print(nodes)
   if nodes is None:
       return 'No Nodes', 400
   for node in nodes:
       blockchain.add_node(node)
   response = {
       'message': 'all nodes are now connected',
       'Total nodes': list(blockchain.nodes)
   }
   return jsonify(response), 201

@app.route('/replace_chain', methods=['GET'])
def replace_chain():
   is_chain_replace = blockchain.replace_chain()
   if is_chain_replace:
       response = {
           'message': 'chain replaced',
           'new_chain': blockchain.chain
       }
   else:
       response = {
           'message': 'chain not replaced',
           'new_chain': blockchain.chain
       }
   return jsonify(response), 201

app.run(host='0.0.0.0', port=5001)






# blockchain2.py

import datetime
import hashlib
import json
from flask import Flask, jsonify, request
import requests
from uuid import uuid4
from urllib.parse import urlparse

class Blockchain:
   def __init__(self):
       self.chain = []
       self.transactions = []
       self.create_block(proof=1, previous_hash=0)
       self.nodes = set()

   def create_block(self, proof, previous_hash):
       block = {
           'index': len(self.chain) + 1,
           'timestamp': str(datetime.datetime.now()),
           'proof': proof,
           'previous_hash': previous_hash,
           'transaction': self.transactions
       }
       self.transactions = []
       self.chain.append(block)
       return block

   def get_previous_block(self):
       return self.chain[-1]

   def proof_of_work(self, previous_proof):
       new_proof = 1
       check_proof = False
       while check_proof is False:
           hash_value = hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()
           if hash_value[:5] == '00000':
               check_proof = True
           else:
               new_proof += 1
       return new_proof

   def hash(self, block):
       encoded_block = json.dumps(block, sort_keys=True).encode()
       return hashlib.sha256(encoded_block).hexdigest()

   def is_chain_valid(self, chain):
       previous_block = chain[0]
       block_index = 1
       while block_index < len(chain):
           block = chain[block_index]
           if block['previous_hash'] != self.hash(previous_block):
               return False
           previous_proof = previous_block['proof']
           new_proof = block['proof']
           hash_value = hashlib.sha256(str(new_proof**2 - previous_proof**2).encode()).hexdigest()
           if hash_value[:5] != '00000':
               return False
           previous_block = block
           block_index += 1
       return True

   def add_transaction(self, sender, receiver, amount):
       self.transactions.append({
           'sender': sender,
           'receiver': receiver,
           'amount': amount
       })
       previous_block = self.get_previous_block()
       return previous_block['index'] + 1

   def add_node(self, address):
       parsed_url = urlparse(address)
       self.nodes.add(parsed_url.netloc)

   def replace_chain(self):
       network = self.nodes
       max_length = len(self.chain)
       longest_chain = None
       for node in network:
           response = requests.get(f'http://{node}/get_chain')
           if response.status_code == 200:
               length = response.json()['length']
               chain = response.json()['chain']
               if length > max_length and self.is_chain_valid(chain):
                   max_length = length
                   longest_chain = chain
       if longest_chain:
           self.chain = longest_chain
           return True
       return False

app = Flask(__name__)
blockchain = Blockchain()

@app.route('/mine_block', methods=['GET'])
def mine_block():
   previous_block = blockchain.get_previous_block()
   previous_proof = previous_block['proof']
   proof = blockchain.proof_of_work(previous_proof)
   previous_hash = blockchain.hash(previous_block)
   block = blockchain.create_block(proof, previous_hash)
   response = {
       'message': 'block is mined',
       'index': block['index'],
       'timestamp': block['timestamp'],
       'proof': block['proof'],
       'previous_hash': block['previous_hash']
   }
   return jsonify(response), 200

@app.route('/get_chain', methods=['GET'])
def get_chain():
   response = {
       'chain': blockchain.chain,
       'length': len(blockchain.chain)
   }
   return jsonify(response), 200

@app.route('/is_valid', methods=['GET'])
def is_valid():
   is_valid = blockchain.is_chain_valid(blockchain.chain)
   if is_valid:
       response = {'message': 'Your chain is validated'}
   else:
       response = {'message': 'Your chain is not valid'}
   return jsonify(response), 200

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
   json = request.get_json()
   transaction_keys = ['sender', 'receiver', 'amount']
   if not all(key in json for key in transaction_keys):
       return 'Some elements are missing', 400
   index = blockchain.add_transaction(
       json['sender'],
       json['receiver'],
       json['amount']
   )
   response = {'Message': f'The transaction is added to block {index}'}
   return jsonify(response), 201

@app.route('/connect_nodes', methods=['POST'])
def connect_nodes():
   json = request.get_json()
   nodes = json.get('nodes')
   print(nodes)
   if nodes is None:
       return 'No Nodes', 400
   for node in nodes:
       blockchain.add_node(node)
   response = {
       'message': 'all nodes are now connected',
       'Total nodes': list(blockchain.nodes)
   }
   return jsonify(response), 201

@app.route('/replace_chain', methods=['GET'])
def replace_chain():
   is_chain_replace = blockchain.replace_chain()
   if is_chain_replace:
       response = {
           'message': 'chain replaced',
           'new_chain': blockchain.chain
       }
   else:
       response = {
           'message': 'chain not replaced',
           'new_chain': blockchain.chain
       }
   return jsonify(response), 201

app.run(host='0.0.0.0', port=5002)






# Connect node 1 to node 2

# POST
# localhost:5001/connect_nodes

{
    "nodes": [
        "http://127.0.0.1:5002"
    ]
}



# Connect node 2 to node 1

# POST
# localhost:5002/connect_nodes

{
    "nodes": [
        "http://127.0.0.1:5001"
    ]
}



# GET
# localhost:5001/get_chain

# POST
# localhost:5001/add_transaction

{
    "sender": "abc",
    "receiver": "xyz",
    "amount": "10"
}


# GET
# localhost:5001/mine_block


# GET
# localhost:5001/get_chain


# GET
# localhost:5002/get_chain


# GET
# localhost:5002/replace_chain

# POST
# localhost:5002/add_transaction

{
    "sender": "Alice",
    "receiver": "Carl",
    "amount": "50"
}


# GET
# localhost:5002/mine_block

# GET
# localhost:5002/get_chain

Get chain node 1 and replace chain on node 1
          
          ''')
    
def fb_10():
    print(Fore.RED + '''
          

# Download Metamask browser extension and create a new wallet by completing the wallet creation process.
# Navigate to settings and enable “Show test networks” in the Advanced section of the settings. 
# Or for newer versions of Metamask open the menu on the top right > Go to "Networks" > Scroll down and enable show test networks
# Now select Sepolia as the test network from Custom networks

# Go to Google Ethereum Sepolia Faucet, sign in and enter the MetaMask Sepolia wallet address to get the Ethereum tokens. (Get the Ethereum address by pressing the receive button on metamask)

# View the added tokens in MetaMask
# Go to Remix IDE to connect the Sepolia Testnet - MetaMask wallet in the browser extension section of the environment.
# Compile the smart contract and deploy it.


        
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.0;
contract SimpleStorage {
    uint256 private storedData;
    function set(uint256 x) public {
        storedData = x;
    }

    function get() public view returns (uint256) {
        return storedData;
    }
}



# Go to the deployed contacts and test the functions. 
# Copy the deployed contract’s address and paste it in the app.js file of the local DApp


# index.html

<!DOCTYPE html>
<html>
<head>
<title>SimpleStorage DApp</title>
</head>
<body>
<h2>SimpleStorage DApp</h2>
<input type="number" id="inputValue" placeholder="Enter a number" />
<button onclick="setValue()">Set Value</button>
<button onclick="getValue()">Get Stored Value</button>
<p>Stored Value: <span id="storedValue">-</span></p>
<script
src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"></script>
<script src="app.js"></script>
</body>
</html>





# app.js

const contractABI = [
 "function set(uint256 x) public",
 "function get() public view returns (uint256)",
];
const contractAddress = "0x077980e4Bd973BbE2Daf6516c970b1C586d6C809";
let provider;
let signer;
let contract;
async function init() {
 if (typeof window.ethereum === "undefined") {
   alert("MetaMask is not installed!");
   return;
 }
 await window.ethereum.request({ method: "eth_requestAccounts" });
 provider = new ethers.providers.Web3Provider(window.ethereum);
 signer = provider.getSigner();
 contract = new ethers.Contract(contractAddress, contractABI, signer);
}
async function setValue() {
 const value = document.getElementById("inputValue").value;
 if (!value) {
   alert("Enter a number first!");
   return;
 }
 try {
   const tx = await contract.set(value);
   await tx.wait();
   alert("Value set successfully!");
 } catch (err) {
   console.error(err);
   alert("Transaction failed!");
 }
}
async function getValue() {
 try {
   const value = await contract.get();
   document.getElementById("storedValue").innerText = value.toString();
 } catch (err) {
   console.error(err);
   alert("Failed to get value!");
 }
}
window.onload = init;





# Run the DApp locally using the live server extension in VS Code. 
# Set and get a new value. 
# View the updated balance and activity in MetaMask.
          
          ''')