from colorama import Fore, Style, init

init(autoreset=True)

def ans_1():
    print(Fore.RED + '''

library(igraph)
g <- graph.formula(1-2, 1-3, 2-3, 2-4, 3-5, 4-5, 4-6, 4-7, 5-6, 6-7)
V(g)
E(g)

plot(g)

dg <- graph.formula(1-+2, 1-+3, 2++3)
plot(dg)

dg1 <- graph.formula(Sam-+Mary, Sam-+Tom, Mary++Tom)
plot(dg1)



#Number of edges/ties/dyads
ecount(g)

degree(g)


# Number of Vertices/Nodes:
vcount(g)



#In-degree
degree(dg, mode = "in")

#Out-degree
degree(dg, mode = "out")




#Node with lowest degree
V(dg) $name[degree(dg) == min(degree(dg))]

#Node with highest degree
V(dg) $name[degree(dg) == max(degree(dg))]


#Adjacency list

neighbors(g,5)

neighbors(g,2)

get.adjlist(dg)

get.adjlist(g)



#Matrix of the graph

get.adjacency(g)

          ''')
    
def ans_2():
    print(Fore.RED + '''


library(igraph)

nodes <- read.csv("Nodes.csv", header=TRUE, as.is=TRUE)
head(nodes)

links <- read.csv("Edges.csv", header=TRUE, as.is=TRUE)
head(links)



#Basic Network Matrics transformation

net <- graph.data.frame(d=links, vertices=nodes, directed=TRUE)
m <- as.matrix(net)
print(m)
print(get.adjacency(net))

plot(net)


''')
    
def ans_3():
    print(Fore.RED + '''

# Length of the shortest path from a given node to another node.

library(igraph)

matt <- as.matrix(read.table(text="node  R  S  T  U
                                      R  7  5  0  0
                                      S  7  0  0  2
                                      T  0  6  0  0
                                      U  4  0  1  0", header=T))

nms <- matt[, 1]
matt <- matt[, -1]
colnames(matt) <- rownames(matt) <- nms
matt[is.na(matt)] <- 0

g <- graph.adjacency(matt, weighted=TRUE)
plot(g)

s.paths <- shortest.paths(g, algorithm = "dijkstra")
print(s.paths)

shortest.paths(g, v = "R", to = "S")

plot(g, edge.label = E(g)$weight)




# The density of the graph.

dg <- graph.formula(1-+2, 1-+3, 2++3)

plot(dg)
graph.density(dg, loops = TRUE)

graph.density(simplify(dg), loops = FALSE)

 
          ''')
    
def ans_4():
    print(Fore.RED + '''

# Network graph

library(igraph)

ng <- graph.formula(Andy++Garth, Garth-+Bill, Bill-+Elena, Elena++Frank, 
                    Carol-+Andy, Carol-+Elena, Carol++Dan, Carol++Bill, 
                    Dan++Andy, Dan++Bill)

plot(ng)




# Network Matrix

net_matrix <- graph.formula(
  Alice -+ Nicole, Alice -+ Dori, Nicole -+ Dori, Dori -+ Bronya, Bronya -+ Alice
)

adj_matrix <- as_adjacency_matrix(net_matrix, sparse = FALSE)
adj_matrix



# Network Edge List

net_edges <- graph.formula(
  Aether ++ Zhongli, Zhongli ++ Lumine, Lumine ++ Firefly, Firefly ++ Aether, Aether ++ Lumine
)
edge_list <- as_edgelist(net_edges)
edge_list

          ''')

def ans_5():
    print(Fore.RED + '''

#Density

library(igraph)
g <- erdos.renyi.game(10, 0.3, directed = T)
g1 <- sample_gnp(10, 0.3, directed = T)
den <- graph.density(g)
den


#Degree

deg <- degree(g)
deg


#Reciprocity

rec <- reciprocity(g)
rec


# Transitivity 

tra <- transitivity(g, type = "global")
tra


plot(g)



library(igraph)

kite <- make_graph("Krackhardt_Kite")
atri <- count_triangles(kite)
plot(kite, vertex.label = atri)
transitivity(kite, type = "local")
count_triangles(kite) / (degree(kite) * (degree(kite) - 1) / 2)

g1 <- sample_pa(50, power = 1, directed = FALSE)
g2 <- sample_smallworld(dim = 1, size = 100, nei = 5, p = 0.05)

g <- union(g1, g2)
g <- simplify(g)

ebc <- cluster_edge_betweenness(g, directed = FALSE)
plot(ebc, g)

mods <- sapply(0:ecount(g), function(i) {
 g_temp <- delete_edges(g, ebc$removed.edges[seq_len(i)])
 membership <- components(g_temp)$membership
 modularity(g_temp, membership)
})
mods



source("Practical5.2.R")

optimal_edges <- which.max(mods) - 1
g2 <- delete_edges(g, ebc$removed.edges[seq(length = optimal_edges)])
V(g2)$color <- components(g2)$membership
g$layout <- layout_with_fr(g)

plot(g, vertex.label = NA)
plot(g2, vertex.label = NA)
plot(kite)

as_adj_edge_list(kite, mode = c("all", "out", "in", "total"))
fc <- cluster_fast_greedy(g2)
max_step <- min(which.max(fc$modularity), length(fc$steps))
com <- cut_at(fc, steps = max_step)
V(g2)$color <- fc$membership + 1
g2$layout <- layout_with_fr(g)
plot(g2, vertex.label = NA)

library(igraph)
centr_degree(g, mode="in", normalized=T)
closeness(g, mode = "all", weights = NA)
centr_clo(g, mode = "all", normalized = "T")
betweenness(g, directed = T, weights = NA)
edge_betweenness(g, directed = T, weights = NA)
centr_betw(g, directed = T, normalized = T)
#Eigenvector centrality
centr_eigen(g, directed = T, normalized = T)

          
          ''')

def ans_6():
    print(Fore.RED + '''
          
# pip install networkx, matplotlib, scipy


import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

adj = np.array([[0, 1, 1, 0], [0, 0, 1, 0], [1, 0, 0, 1], [0, 0, 1, 0]])
nodes = ["A", "B", "C", "D"]

G = nx.from_numpy_array(adj, create_using=nx.DiGraph)
G = nx.relabel_nodes(G, {i: nodes[i] for i in range(4)})
pr = nx.pagerank(G)

print("PageRank Scores:", {n: f"{pr[n]:.4f}" for n in nodes})

pos = {"A": (0, 1), "B": (2, 2), "C": (4, 1), "D": (2, 0)}
nx.draw(G, pos, labels={n: f"{n}\n{pr[n]:.3f}" for n in nodes},
       node_size=[800 + 3000 * pr[n] for n in nodes],
       node_color="lightblue", edgecolors="darkblue",
       font_size=10, arrows=True, arrowsize=20)
plt.title("PageRank")
plt.show()






# Alternate Code for PageRank Visualization

import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

# Define adjacency matrix and node names
adj = np.array([[0, 1, 1, 0], [0, 0, 1, 0], [1, 0, 0, 1], [0, 0, 1, 0]])
nodes = ["A", "B", "C", "D"]

# Create Directed Graph
G = nx.from_numpy_array(adj, create_using=nx.DiGraph)
G = nx.relabel_nodes(G, {i: nodes[i] for i in range(len(nodes))})

pr = nx.pagerank(G)

print("PageRank Scores:", {n: f"{pr[n]:.4f}" for n in nodes})

pos = {"A": (0, 1), "B": (2, 2), "C": (4, 1), "D": (2, 0)}

labels = {n: f"{n}\n{pr[n]:.3f}" for n in nodes}
node_sizes = [800 + 5000 * pr[n] for n in nodes]

plt.figure(figsize=(8, 6))
nx.draw(G, pos, labels=labels,
        node_size=node_sizes,
        node_color="lightblue", 
        edgecolors="darkblue",
        font_size=10, 
        arrows=True, 
        arrowsize=20,
        connectionstyle='arc3, rad = 0.1')

plt.title("PageRank Visualization")
plt.margins(0.2) 
plt.show()

    
''')
      
def ans_7():
    print(Fore.RED + '''

library(sna)
library(igraph)

links2 <- read.csv("Edges.csv", header=T, row.names=1)

eq <- equiv.clust(links2)

plot(eq)

g.se <- sedist(links2)

plot(cmdscale(as.dist(g.se)))

b <- blockmodel(links2, eq, h=10)
plot(b)


          ''')
                   
def ans_8():
    print(Fore.RED + '''

library(igraph)

relations <- data.frame(
   Director = c("Alice", "Alice", "Bob", "Charlie", "Charlie", "David", "Eve", "Eve"),
   Committee = c("Audit", "Risk", "Audit", "Risk", "Comp", "Comp", "Audit", "Comp")
)

g_2mode <- graph_from_data_frame(relations, directed = FALSE)

V(g_2mode)$type <- V(g_2mode)$name %in% relations$Committee

plot(g_2mode,
   layout = layout_as_bipartite,
   vertex.color = ifelse(V(g_2mode)$type, "salmon", "lightblue"),
   main = "Two-Mode Network: Directors & Committees"
)

projections <- bipartite_projection(g_2mode)

g_persons <- projections$proj1
g_committees <- projections$proj2

par(mfrow = c(1, 2))

plot(g_persons,
   vertex.color = "lightblue",
   main = "Person-by-Person\n(Shared Committees)"
)
plot(g_committees,
   vertex.color = "salmon",
   main = "Committee-by-Committee\n(Shared Members)"
)


          ''')
    
def ans_9():
    print(Fore.RED + '''

library(igraph)

davis <- read.csv("Davis.csv", header = FALSE)
g <- graph.data.frame(davis, directed = FALSE)
plot(g)



bipartile.mapping(g)




V(g)$type <- bipartite.mapping(g)$type
plot(g)


plot(g, vertex.label.cex = 0.8, vertex.label.color = "black")



V(g)$color <- ifelse(V(g)$type, "lightblue", "salmon")
V(g)$shape <- ifelse(V(g)$type, "circle", "square")
E(g)$color <- "lightgray"

plot(g, vertex.label.cex = 0.8, vertex.label.color = "black")



V(g)$label.color <- "black"

V(g)$label.cex <- 1
V(g)$frame.color <- "gray"
V(g)$size <- 18

plot(g, layout = layout_with_graphopt)
plot(g, layout = layout.bipartite, vertex.size = 7, vertex.label.cex = 0.6)




''')
     
def ans_10():
    print(Fore.RED + '''

library(e1071)

x <- c(0, 0, 0, 0)
y <- c(0, 0, 1, 0)
z <- c(1, 0, 1, 1)
w <- c(0, 1, 1, 1)

hamming.distance(x, y)
hamming.distance(y, z)
hamming.distance(x, w)
hamming.distance(z, w)
hamming.distance(x, z)



''')