from .NLP import pln_1, pln_2, pln_3, pln_4, pln_5, pln_6, pln_7, pln_8, pln_9, pln_10
from .SNA import ans_1, ans_2, ans_3, ans_4, ans_5, ans_6, ans_7, ans_8, ans_9, ans_10
from .IoT import cp_1, cp_2, cp_3, cp_4, cp_5, cp_6, cp_7, cp_8, cp_9
from .BF import fb_1, fb_2, fb_3, fb_4, fb_5, fb_6, fb_7, fb_8, fb_9