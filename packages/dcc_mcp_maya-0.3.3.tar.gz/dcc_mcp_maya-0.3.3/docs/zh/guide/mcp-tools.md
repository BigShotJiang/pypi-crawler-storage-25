# MCP Tools 使用指南

本指南面向使用 AI 助手（Claude、Cursor 等）以自然语言控制 Maya 的用户，无需任何 Python 知识。

## 工作原理

`dcc-mcp-maya` 服务器在 Maya 内运行后，你的 AI 助手可以发现 **23 个 Maya Skill 包**，并按需加载 **160+ 个 typed Maya 工具**。只需用普通话描述你的需求即可；助手应先搜索能力、加载匹配 Skill，再调用带 schema 的 typed tool。

默认启动工具面很小。如果某个工具看起来不存在，请让助手先调用 `dcc_capability_manifest` 或 `search_skills`，再调用 `load_skill("<skill-name>")`。

## 场景操作

### 创建与管理场景

```
"新建一个空场景"
"将当前场景保存到 /projects/my_scene.ma"
"打开文件 /projects/character.mb"
"当前帧率是多少？改成 30fps"
```

### 浏览场景

```
"列出场景中的所有对象"
"显示场景层次结构"
"场景里有多少对象？"
"选择所有网格对象"
"当前选中了什么？"
```

## 创建对象

### 基础几何体

```
"创建一个球体"
"创建一个宽度为 2 的立方体，命名为 'table'"
"创建一个地面平面，缩放到 10x10"
"在位置 (3, 0, 0) 创建一个圆柱体"
```

### 变换操作

```
"将 pSphere1 移动到位置 (0, 5, 0)"
"将立方体绕 Y 轴旋转 45 度"
"将 pPlane1 在 X 和 Z 方向缩放为 5"
"冻结所有选中对象的变换"
"将 my_mesh 的轴心居中"
```

### 对象管理

```
"将 pSphere1 重命名为 'ball'"
"复制这个立方体并向右移动 3 个单位"
"删除 pCone1"
"将 sphere1、cube1 和 cylinder1 编组为 'objects'"
"将 sphere1 放到 group1 下"
"隐藏 camera_rig 组"
"锁定 ground_plane 的变换"
```

## 材质与着色

```
"创建一个名为 'redMat' 的红色 Lambert 材质"
"制作一个闪亮的金色材质"
"将 redMat 赋予 pSphere1"
"创建一个透明材质并赋予玻璃对象"
"列出场景中的所有材质"
"将 material1 的颜色改为蓝色"
```

## 动画

```
"在第 1 帧给 pSphere1 打关键帧"
"设置 ball 的 translateY：第 1 帧=0，第 24 帧=5，第 48 帧=0"
"将时间轴设置为第 1 帧到第 120 帧"
"跳转到第 50 帧"
"当前在哪一帧？"
"将 pCloth1 的模拟从第 1 帧烘焙到第 100 帧"
"删除 pSphere1 在第 20 到 40 帧之间的所有关键帧"
"将 character_ctrl 的动画曲线导出到 /exports/walk_cycle.anim"
```

## 灯光 Rig

```
"围绕资产创建一个三点布光 rig"
"使用 /textures/studio.hdr 创建 HDRI dome"
"列出当前场景中的灯光 rig"
"降低 key light 的强度"
```

## 场景装配

```
"为这个道具创建 assembly definition"
"给 assembly 添加 GPU cache representation"
"在 layout 场景中创建 assembly reference"
"列出所有 assemblies"
```

## 渲染与截图

```
"截取当前视口截图"
"从正视图截取场景"
"将渲染分辨率设为 1920x1080"
"将渲染器设置为 Arnold"
"当前的渲染设置是什么？"
```

## 进阶工作流

### Skill 路由

```
"找到最适合导出所选 mesh 到 FBX 的 skill，加载它，然后导出"
"显示未加载的 render 和 farm 工具 capability manifest"
"加载 maya-material-library，并把这个 shader network 保存为 preset"
```

### 完整资产创建

```
"创建一张桌子：一个扁平立方体作为桌面（缩放 4x0.2x2，高度 2），
 四根圆柱腿（缩放 0.1x1x0.1）放在四个角落。
 给所有对象应用棕色木纹材质。"
```

### 动画设置

```
"我需要一个弹跳球动画：
 - 创建名为 'ball' 的球体，位置 (0,0,0)
 - 设置关键帧：第 1 帧 Y=0，第 12 帧 Y=5，第 24 帧 Y=0
 - 将时间轴设为 1-48 帧
 - 截图看看效果"
```

### 场景检查

```
"给我一份当前场景的完整报告：
 - 有多少对象？
 - 使用了哪些材质？
 - 渲染设置是什么？
 - 给我看一张截图"
```

## 使用技巧

1. **明确对象名称** — 使用 Maya 显示的确切名称（如 `pSphere1`，而非仅仅 `球体`）
2. **链式操作** — 可以在一条消息中描述多步骤工作流
3. **要求确认** — 操作后说"给我看张截图"来验证结果
4. **使用自然单位** — "1 单位" = 1 个 Maya 单位（通常为 1 厘米或 1 米，取决于场景比例）
