"""Data models for OpenQuery."""
