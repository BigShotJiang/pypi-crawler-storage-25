"""FastAPI server for OpenQuery."""
