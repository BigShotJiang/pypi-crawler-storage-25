from __future__ import annotations

import atexit
import logging
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from queue import Empty, Queue
from typing import Any

import httpx

from growth.types import EventContext, Properties, TrackEvent

_DEFAULT_HOST = "https://api.growth-loop.dev"
_INGEST_PATH = "/v1/ingest"
_DEFAULT_FLUSH_INTERVAL = 5.0
_DEFAULT_BATCH_SIZE = 50
_SDK_NAME = "growth-py"
_SDK_VERSION = "0.0.1"

logger = logging.getLogger("growth")


@dataclass(slots=True)
class GrowthOptions:
    api_key: str
    host: str = _DEFAULT_HOST
    flush_interval: float = _DEFAULT_FLUSH_INTERVAL
    batch_size: int = _DEFAULT_BATCH_SIZE
    environment: str | None = None
    release: str | None = None
    timeout: float = 5.0


@dataclass(slots=True)
class TrackOptions:
    distinct_id: str | None = None
    timestamp: datetime | None = None
    context: EventContext | None = None


@dataclass(slots=True)
class IdentifyOptions:
    distinct_id: str
    properties: Properties | None = None
    context: EventContext | None = None


class Growth:
    def __init__(self, options: GrowthOptions) -> None:
        if not options.api_key:
            raise ValueError("api_key is required")
        self._options = options
        self._queue: Queue[TrackEvent] = Queue()
        self._stopping = threading.Event()
        self._distinct_id = str(uuid.uuid4())
        self._client = httpx.Client(timeout=options.timeout)
        self._worker = threading.Thread(target=self._run, name="growth-flush", daemon=True)
        self._worker.start()
        atexit.register(self.shutdown)

    def set_distinct_id(self, distinct_id: str) -> None:
        self._distinct_id = distinct_id

    def track(
        self,
        name: str,
        properties: Properties | None = None,
        options: TrackOptions | None = None,
    ) -> None:
        if self._stopping.is_set():
            return

        ts = (options.timestamp if options and options.timestamp else datetime.now(timezone.utc))
        event = TrackEvent(
            name=name,
            distinct_id=(options.distinct_id if options and options.distinct_id else self._distinct_id),
            timestamp=ts.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            properties=properties,
            context=self._build_context(options.context if options else None),
        )
        self._queue.put_nowait(event)

    def identify(self, options: IdentifyOptions) -> None:
        self._distinct_id = options.distinct_id
        self.track(
            "$identify",
            options.properties,
            TrackOptions(distinct_id=options.distinct_id, context=options.context),
        )

    def alias(self, distinct_id: str, previous_id: str) -> None:
        self.track(
            "$alias",
            {"previous_id": previous_id},
            TrackOptions(distinct_id=distinct_id),
        )
        self._distinct_id = distinct_id

    def flush(self) -> None:
        events = self._drain()
        if events:
            self._send(events)

    def shutdown(self) -> None:
        if self._stopping.is_set():
            return
        self._stopping.set()
        self.flush()
        self._client.close()

    def _run(self) -> None:
        while not self._stopping.is_set():
            try:
                event = self._queue.get(timeout=self._options.flush_interval)
            except Empty:
                self.flush()
                continue
            batch: list[TrackEvent] = [event]
            while len(batch) < self._options.batch_size:
                try:
                    batch.append(self._queue.get_nowait())
                except Empty:
                    break
            self._send(batch)

    def _drain(self) -> list[TrackEvent]:
        out: list[TrackEvent] = []
        while True:
            try:
                out.append(self._queue.get_nowait())
            except Empty:
                return out

    def _send(self, events: list[TrackEvent]) -> None:
        if not events:
            return
        payload: dict[str, Any] = {
            "api_key": self._options.api_key,
            "sdk": {"name": _SDK_NAME, "version": _SDK_VERSION},
            "sent_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "events": [e.to_dict() for e in events],
        }
        url = self._options.host.rstrip("/") + _INGEST_PATH
        try:
            response = self._client.post(
                url,
                json=payload,
                headers={"x-growth-sdk": f"{_SDK_NAME}/{_SDK_VERSION}"},
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("growth ingest failed: %s", exc)

    def _build_context(self, context: EventContext | None) -> dict[str, Any]:
        merged: dict[str, Any] = {}
        if self._options.release:
            merged["release"] = self._options.release
        if self._options.environment:
            merged["environment"] = self._options.environment
        if context:
            merged.update(context.to_dict())
        return merged
