"""
Higher-level instrumentation: spans, steps, tracked events.

These wrap the low-level `track()` API in patterns the agent (and a human)
can drop into existing code with minimal change. Designed to be applied
automatically by `claude /growth init`.

Usage:

    from growth import Growth, GrowthOptions

    growth = Growth(GrowthOptions(api_key="pk_live_…", host="https://api.growth-loop.dev"))

    @growth_span(growth, "checkout")
    def run_checkout(user_id: str): ...

    @growth_step(growth, "activation.invited_team")
    def invite_team(team_id: str): ...

    growth_track(growth, "login_clicked")
"""

from __future__ import annotations

import functools
import inspect
import time
from collections.abc import Awaitable, Callable
from typing import Any, ParamSpec, TypeVar, cast, overload

from growth.client import Growth, TrackOptions
from growth.types import Properties

P = ParamSpec("P")
T = TypeVar("T")


def growth_span(
    client: Growth,
    name: str,
    *,
    properties: Properties | None = None,
    distinct_id: Callable[..., str | None] | str | None = None,
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    """Decorator that emits `<name>.started`, `<name>.completed`, `<name>.failed`
    events with duration_ms. Works on sync and async functions.

    `distinct_id` may be a string (literal user id) or a callable that receives
    the wrapped function's args/kwargs and returns the id.
    """

    def _resolve_id(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str | None:
        if callable(distinct_id):
            try:
                return distinct_id(*args, **kwargs)
            except Exception:
                return None
        return distinct_id

    def decorator(fn: Callable[P, T]) -> Callable[P, T]:
        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
                started_at = time.monotonic()
                base = dict(properties or {})
                opts = TrackOptions(distinct_id=_resolve_id(args, kwargs))
                client.track(f"{name}.started", base, opts)
                try:
                    result = await cast(Awaitable[T], fn(*args, **kwargs))
                    client.track(
                        f"{name}.completed",
                        {**base, "duration_ms": int((time.monotonic() - started_at) * 1000)},
                        opts,
                    )
                    return result
                except Exception as exc:
                    client.track(
                        f"{name}.failed",
                        {
                            **base,
                            "duration_ms": int((time.monotonic() - started_at) * 1000),
                            "error_message": str(exc)[:500],
                            "error_name": type(exc).__name__,
                        },
                        opts,
                    )
                    raise

            return cast(Callable[P, T], async_wrapper)

        @functools.wraps(fn)
        def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            started_at = time.monotonic()
            base = dict(properties or {})
            opts = TrackOptions(distinct_id=_resolve_id(args, kwargs))
            client.track(f"{name}.started", base, opts)
            try:
                result = fn(*args, **kwargs)
                client.track(
                    f"{name}.completed",
                    {**base, "duration_ms": int((time.monotonic() - started_at) * 1000)},
                    opts,
                )
                return result
            except Exception as exc:
                client.track(
                    f"{name}.failed",
                    {
                        **base,
                        "duration_ms": int((time.monotonic() - started_at) * 1000),
                        "error_message": str(exc)[:500],
                        "error_name": type(exc).__name__,
                    },
                    opts,
                )
                raise

        return sync_wrapper

    return decorator


def growth_step(
    client: Growth,
    funnel_step: str,
    *,
    properties: Properties | None = None,
    distinct_id: Callable[..., str | None] | str | None = None,
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    """Decorator that emits a single funnel-step event when the wrapped function runs."""

    def decorator(fn: Callable[P, T]) -> Callable[P, T]:
        @functools.wraps(fn)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            opts: TrackOptions | None = None
            if callable(distinct_id):
                try:
                    opts = TrackOptions(distinct_id=distinct_id(*args, **kwargs))
                except Exception:
                    opts = None
            elif distinct_id is not None:
                opts = TrackOptions(distinct_id=distinct_id)
            client.track(funnel_step, dict(properties or {}), opts)
            return fn(*args, **kwargs)

        return wrapper

    return decorator


@overload
def growth_track(client: Growth, name: str) -> None: ...
@overload
def growth_track(
    client: Growth, name: str, properties: Properties | None
) -> None: ...


def growth_track(
    client: Growth, name: str, properties: Properties | None = None
) -> None:
    """Synchronous one-off track. Equivalent to `client.track(name, properties)`."""
    client.track(name, properties)
