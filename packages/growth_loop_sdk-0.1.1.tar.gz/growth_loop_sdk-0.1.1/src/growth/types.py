from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

Properties = dict[str, Any]


@dataclass(slots=True)
class EventContext:
    page_url: str | None = None
    page_path: str | None = None
    page_title: str | None = None
    referrer: str | None = None
    user_agent: str | None = None
    ip: str | None = None
    locale: str | None = None
    timezone: str | None = None
    utm_source: str | None = None
    utm_medium: str | None = None
    utm_campaign: str | None = None
    release: str | None = None
    commit_sha: str | None = None
    deploy_id: str | None = None
    environment: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}


@dataclass(slots=True)
class TrackEvent:
    name: str
    distinct_id: str
    timestamp: str
    source: str = "server"
    properties: Properties | None = None
    context: dict[str, Any] = field(default_factory=dict)
    session_id: str | None = None
    anonymous_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "name": self.name,
            "distinct_id": self.distinct_id,
            "timestamp": self.timestamp,
            "source": self.source,
        }
        if self.properties:
            out["properties"] = self.properties
        if self.context:
            out["context"] = self.context
        if self.session_id:
            out["session_id"] = self.session_id
        if self.anonymous_id:
            out["anonymous_id"] = self.anonymous_id
        return out
