"""
SayHi — CLI Banner
两栏启动画面：左侧铁十字，右侧 Agent 信息
"""

from __future__ import annotations

import time

IRON_CROSS = r"""
      ████
   ████████████
 ████          ████
████  ██████████  ████
████  ██████████  ████
████  ██████████  ████
 ████          ████
   ████████████
      ████
"""

TAGLINE_EN = "A self-directed AI agent that grows through conversation"
TAGLINE_ZH = "在持续对话中不断成长的 AI Agent"

try:
    from importlib.metadata import version
    VERSION = version("sayhi-agent")
except Exception:
    try:
        from .. import __version__
        VERSION = __version__
    except Exception:
        VERSION = "1.0.0"


def print_banner(profile=None, model: str = ""):
    """打印两栏启动 Banner：左铁十字，右 Agent 信息。"""
    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table
        from rich.markup import escape

        console = Console()
        console.clear()

        cross = IRON_CROSS.strip("\n")

        name = profile.name if profile else "SayHi"
        session_name = profile.current_session if profile else "default"
        last_score = profile.last_score if profile else None

        score_line = ""
        if last_score:
            score_line = f"\n  [dim]上次评分[/dim]  [bold cyan]{last_score['composite']:.0f}[/bold cyan] / 100"

        right_content = (
            f"\n"
            f"  [bold cyan]✠  {escape(name)}[/bold cyan]\n"
            f"\n"
            f"  [dim]Model  [/dim]  {escape(model or '—')}\n"
            f"  [dim]Session[/dim]  {escape(session_name)}\n"
            f"  [dim]Topic  [/dim]  {escape(session_name)}"
            f"{score_line}\n"
            f"\n"
            f"  [dim]{TAGLINE_ZH}[/dim]"
        )

        table = Table(box=None, show_header=False, padding=(0, 2), expand=True)
        table.add_column("cross", no_wrap=True, vertical="middle", min_width=26)
        table.add_column("info",  no_wrap=False, vertical="middle")
        table.add_row(
            f"[bold white]{escape(cross)}[/bold white]",
            right_content,
        )

        console.print(Panel(
            table,
            title="[bold cyan]✠  SayHi[/bold cyan]",
            border_style="cyan",
            subtitle=f"[dim]v{VERSION}[/dim]",
            padding=(0, 1),
        ))

    except ImportError:
        _print_banner_plain(profile, model)


def _print_banner_plain(profile=None, model: str = ""):
    print(IRON_CROSS)
    name = profile.name if profile else "SayHi"
    print(f"  ✠ {name}  |  Model: {model or '—'}")
    print(f"  {TAGLINE_EN}  v{VERSION}\n")


def boot_sequence():
    """启动动画序列"""
    try:
        from rich.console import Console
        from rich.progress import Progress, SpinnerColumn, TextColumn

        console = Console()

        steps = [
            ("🧠 加载记忆系统…", 0.3),
            ("🔧 初始化工具集…", 0.3),
            ("🌐 连接平台网关…", 0.4),
            ("✠  唤醒 SayHi…",   0.4),
        ]

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            for desc, delay in steps:
                task = progress.add_task(desc, total=None)
                time.sleep(delay)
                progress.remove_task(task)

        console.print("\n[bold green]✓ SayHi 已就绪[/bold green]\n")

    except ImportError:
        print("Loading SayHi...")
        time.sleep(0.5)
        print("✓ Ready\n")