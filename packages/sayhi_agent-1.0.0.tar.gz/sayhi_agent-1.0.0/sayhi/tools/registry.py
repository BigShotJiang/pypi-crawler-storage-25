"""
Panda Ronin — Tool Registry
工具注册表：标准工具 + 网络工具
"""

from __future__ import annotations

import os
import subprocess
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    handler: Callable
    is_mutating: bool = False
    never_parallel: bool = False

    @property
    def schema(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.parameters,
        }

    def execute(self, **kwargs) -> str:
        try:
            result = self.handler(**kwargs)
            return str(result) if result is not None else "完成"
        except Exception as e:
            return f"[错误] {type(e).__name__}: {e}"


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> "ToolRegistry":
        self._tools[tool.name] = tool
        return self

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def get_schemas(self) -> list[dict]:
        return [t.schema for t in self._tools.values()]

    def dispatch(self, name: str, args: dict) -> str:
        tool = self.get(name)
        if not tool:
            return f"[错误] 未知工具：{name}"
        return tool.execute(**args)


# ── 工具处理函数 ──────────────────────────────────────────────────

_BASH_BLOCKED = [
    "rm -rf", "rmdir /s", "format c:", "format d:", "format e:",
    "mkfs.", "dd if=", "> /dev/sd", "| bash", "| sh",
    ":(){ :|:& };:", "; rm -", "&& rm -", "curl.*bash",
    "wget.*bash", "shutil.rmtree", "os.remove", "del /f /s",
]


def _bash(command: str, timeout: int = 30, cwd: str | None = None) -> str:
    cmd_lower = command.lower()
    for b in _BASH_BLOCKED:
        if b in cmd_lower:
            return f"[安全阻止] 危险命令包含：{b}"

    result = subprocess.run(
        command, shell=True,
        capture_output=True, text=True,
        timeout=timeout, cwd=cwd or os.getcwd(),
    )
    out = result.stdout
    if result.returncode != 0:
        out += f"\n[exit:{result.returncode}]\n{result.stderr}"
    return out[:4000] or "(无输出)"


def _read_file(path: str, offset: int = 1, limit: int = 200) -> str:
    p = Path(path)
    if not p.exists():
        return f"[错误] 文件不存在：{path}"
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    start = max(0, offset - 1)
    selected = lines[start:start + limit]
    result = "\n".join(f"{start+i+1:4d}│ {l}" for i, l in enumerate(selected))
    if len(lines) > start + limit:
        result += f"\n... 共 {len(lines)} 行"
    return result


def _write_file(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"已写入 {path}（{len(content)} 字符）"


def _glob_files(pattern: str, base_dir: str = ".") -> str:
    matches = sorted(Path(base_dir).glob(pattern))
    if not matches:
        return f"未找到匹配 '{pattern}' 的文件"
    return "\n".join(str(m) for m in matches[:100])


def _grep(pattern: str, path: str, recursive: bool = True) -> str:
    import re
    results = []
    p = Path(path)
    files = p.rglob("*") if recursive and p.is_dir() else [p]
    for f in files:
        if not f.is_file():
            continue
        try:
            for i, line in enumerate(
                f.read_text(encoding="utf-8", errors="replace").splitlines(), 1
            ):
                if re.search(pattern, line):
                    results.append(f"{f}:{i}: {line.strip()}")
        except Exception:
            pass
    return "\n".join(results[:200]) or f"未找到匹配 '{pattern}'"


def _web_fetch(url: str, timeout: int = 15) -> str:
    """获取网页内容（纯文本）"""
    try:
        # 优先用 requests
        import requests
        resp = requests.get(
            url, timeout=timeout,
            headers={"User-Agent": "Mozilla/5.0 PandaRonin/0.1"},
        )
        # 尝试用 markdownify 转换 HTML
        try:
            from markdownify import markdownify
            return markdownify(resp.text)[:8000]
        except ImportError:
            import re
            text = re.sub(r"<[^>]+>", "", resp.text)
            return text[:8000]
    except ImportError:
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0 PandaRonin/0.1"}
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8", errors="replace")[:8000]
    except Exception as e:
        return f"[错误] 无法获取 {url}: {e}"


def _web_search(query: str, num_results: int = 5) -> str:
    """使用 DuckDuckGo 搜索（无需 API key）"""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=num_results))
        if not results:
            return "无搜索结果"
        lines = []
        for i, r in enumerate(results, 1):
            lines.append(f"{i}. {r.get('title', '')}")
            lines.append(f"   {r.get('href', '')}")
            lines.append(f"   {r.get('body', '')[:200]}")
        return "\n".join(lines)
    except ImportError:
        # 降级到 urllib
        import urllib.parse, re
        encoded = urllib.parse.quote(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0"}
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            html = r.read().decode("utf-8", errors="replace")
        titles = re.findall(r'class="result__title"[^>]*>(.*?)</a>', html)
        urls = re.findall(r'class="result__url"[^>]*>(.*?)</span>', html)
        results_list = []
        for i, (t, u) in enumerate(zip(titles[:num_results], urls[:num_results]), 1):
            results_list.append(f"{i}. {re.sub('<[^>]+>', '', t).strip()}\n   {u.strip()}")
        return "\n".join(results_list) or "无结果"
    except Exception as e:
        return f"[错误] 搜索失败：{e}"


def _get_time(timezone: str = "local") -> str:
    """返回当前日期时间"""
    import datetime
    now = datetime.datetime.now()
    utc = datetime.datetime.utcnow()
    return (
        f"本地时间：{now.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"UTC 时间：{utc.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"星期：{['周一','周二','周三','周四','周五','周六','周日'][now.weekday()]}"
    )


def _jina_read(url: str, timeout: int = 20) -> str:
    """通过 Jina Reader API 获取任意 URL 的干净 Markdown 内容"""
    jina_url = f"https://r.jina.ai/{url}"
    try:
        import requests
        resp = requests.get(
            jina_url, timeout=timeout,
            headers={"Accept": "text/markdown", "X-Return-Format": "markdown"},
        )
        return resp.text[:10000]
    except ImportError:
        req = urllib.request.Request(
            jina_url,
            headers={"Accept": "text/markdown", "User-Agent": "PandaRonin/1.0"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8", errors="replace")[:10000]
    except Exception as e:
        return f"[错误] Jina 读取失败：{e}"


def _playwright_fetch(url: str, wait_ms: int = 2000) -> str:
    """用无头浏览器获取 JS 渲染后的页面内容（需要 playwright）"""
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            page = browser.new_page(user_agent="Mozilla/5.0 PandaRonin/1.0")
            page.goto(url, timeout=30000)
            page.wait_for_timeout(wait_ms)
            # 提取纯文本
            text = page.evaluate("() => document.body.innerText")
            browser.close()
            return (text or "")[:8000]
    except ImportError:
        # 降级到 jina_read
        return _jina_read(url)
    except Exception as e:
        return f"[错误] 浏览器获取失败：{e}"


def _news_search(query: str, num_results: int = 8) -> str:
    """搜索最新新闻（DuckDuckGo news，返回标题+摘要+链接）"""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.news(query, max_results=num_results))
        if not results:
            return "无新闻结果"
        lines = []
        for i, r in enumerate(results, 1):
            lines.append(
                f"{i}. [{r.get('date','')[:10]}] {r.get('title','')}\n"
                f"   {r.get('url','')}\n"
                f"   {(r.get('body','') or '')[:200]}"
            )
        return "\n".join(lines)
    except ImportError:
        return _web_search(f"news {query}", num_results)
    except Exception as e:
        return f"[错误] 新闻搜索失败：{e}"


def _markitdown(source: str, timeout: int = 20) -> str:
    """将 URL 或本地文件路径转换为 Markdown（支持 PDF/Office/图片/网页）"""
    try:
        from markitdown import MarkItDown
        md = MarkItDown()
        result = md.convert(source)
        return (result.text_content or "")[:8000]
    except ImportError:
        # 降级到 jina 或 web_fetch
        if source.startswith("http"):
            return _jina_read(source, timeout)
        return f"[需要] pip install markitdown"
    except Exception as e:
        return f"[错误] 转换失败：{e}"


def create_default_registry(home: Path | None = None) -> ToolRegistry:
    """
    构建标准工具集。
    当 home 不为 None 时，文件类工具（read/write/glob/grep/bash cwd）
    只允许访问 home 目录内的路径，防止越权读写。
    """

    def _safe(path: str) -> Path | str:
        """返回 resolved Path（安全）或错误字符串（拒绝）。"""
        if home is None:
            return Path(path).expanduser()
        try:
            resolved = Path(path).expanduser().resolve()
            resolved.relative_to(home.resolve())
            return resolved
        except ValueError:
            return f"[安全阻止] 只能访问 {home}，拒绝路径：{path}"

    def bash_h(command: str, timeout: int = 30, cwd: str | None = None) -> str:
        safe_cwd = str(home) if (home and not cwd) else cwd
        if cwd:
            p = _safe(cwd)
            if isinstance(p, str):
                return p
            safe_cwd = str(p)
        return _bash(command, timeout, safe_cwd)

    def read_h(path: str, offset: int = 1, limit: int = 200) -> str:
        p = _safe(path)
        return p if isinstance(p, str) else _read_file(str(p), offset, limit)

    def write_h(path: str, content: str) -> str:
        p = _safe(path)
        return p if isinstance(p, str) else _write_file(str(p), content)

    def glob_h(pattern: str, base_dir: str = ".") -> str:
        bd = str(home) if (home and base_dir == ".") else base_dir
        p = _safe(bd)
        return p if isinstance(p, str) else _glob_files(pattern, str(p))

    def grep_h(pattern: str, path: str, recursive: bool = True) -> str:
        p = _safe(path)
        return p if isinstance(p, str) else _grep(pattern, str(p), recursive)

    tools = [
        Tool(
            name="bash",
            description="执行 shell 命令（仅限 ~/.panda-ronin 目录）。30s 超时，危险命令被阻止。",
            parameters={"type": "object", "properties": {
                "command": {"type": "string"},
                "timeout": {"type": "integer", "default": 30},
                "cwd": {"type": "string"},
            }, "required": ["command"]},
            handler=bash_h, is_mutating=True, never_parallel=True,
        ),
        Tool(
            name="read_file",
            description="读取文件内容（带行号，仅限 ~/.panda-ronin 目录）。",
            parameters={"type": "object", "properties": {
                "path": {"type": "string"},
                "offset": {"type": "integer", "default": 1},
                "limit": {"type": "integer", "default": 200},
            }, "required": ["path"]},
            handler=read_h,
        ),
        Tool(
            name="write_file",
            description="写入文件（仅限 ~/.panda-ronin 目录）。自动创建目录。",
            parameters={"type": "object", "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            }, "required": ["path", "content"]},
            handler=write_h, is_mutating=True,
        ),
        Tool(
            name="glob",
            description="按 glob 模式查找文件（仅限 ~/.panda-ronin 目录）。",
            parameters={"type": "object", "properties": {
                "pattern": {"type": "string"},
                "base_dir": {"type": "string", "default": "."},
            }, "required": ["pattern"]},
            handler=glob_h,
        ),
        Tool(
            name="grep",
            description="在文件/目录中搜索正则（仅限 ~/.panda-ronin 目录）。",
            parameters={"type": "object", "properties": {
                "pattern": {"type": "string"},
                "path": {"type": "string"},
                "recursive": {"type": "boolean", "default": True},
            }, "required": ["pattern", "path"]},
            handler=grep_h,
        ),
        Tool(
            name="web_fetch",
            description="获取网页内容（自动转为纯文本/Markdown）",
            parameters={"type": "object", "properties": {
                "url": {"type": "string"},
                "timeout": {"type": "integer", "default": 15},
            }, "required": ["url"]},
            handler=_web_fetch,
        ),
        Tool(
            name="web_search",
            description="使用 DuckDuckGo 搜索（无需 API key）",
            parameters={"type": "object", "properties": {
                "query": {"type": "string"},
                "num_results": {"type": "integer", "default": 5},
            }, "required": ["query"]},
            handler=_web_search,
        ),
        Tool(
            name="get_time",
            description="获取当前日期和时间（本地时间 + UTC）",
            parameters={"type": "object", "properties": {
                "timezone": {"type": "string", "default": "local"},
            }, "required": []},
            handler=_get_time,
        ),
        Tool(
            name="jina_read",
            description=(
                "通过 Jina Reader API 获取任意 URL 的干净 Markdown 内容。"
                "比 web_fetch 更擅长提取文章正文，去掉广告和导航栏。"
            ),
            parameters={"type": "object", "properties": {
                "url": {"type": "string", "description": "要读取的网页 URL"},
                "timeout": {"type": "integer", "default": 20},
            }, "required": ["url"]},
            handler=_jina_read,
        ),
        Tool(
            name="browser_fetch",
            description=(
                "用无头浏览器获取 JS 渲染后的完整页面内容。"
                "适合需要 JavaScript 的现代网站（如 Twitter、Reddit、SPA 应用）。"
                "需要 playwright 已安装，否则自动降级到 jina_read。"
            ),
            parameters={"type": "object", "properties": {
                "url": {"type": "string"},
                "wait_ms": {"type": "integer", "default": 2000, "description": "等待页面加载的毫秒数"},
            }, "required": ["url"]},
            handler=_playwright_fetch,
        ),
        Tool(
            name="news_search",
            description="搜索最新新闻（DuckDuckGo 新闻频道，返回标题、摘要、发布时间、链接）",
            parameters={"type": "object", "properties": {
                "query": {"type": "string", "description": "新闻搜索关键词"},
                "num_results": {"type": "integer", "default": 8},
            }, "required": ["query"]},
            handler=_news_search,
        ),
        Tool(
            name="markitdown",
            description=(
                "将 URL 或本地文件转换为 Markdown 文本。"
                "支持 PDF、Word、Excel、PowerPoint、图片（OCR）、网页。"
                "需要 pip install markitdown。"
            ),
            parameters={"type": "object", "properties": {
                "source": {"type": "string", "description": "URL 或本地文件路径"},
            }, "required": ["source"]},
            handler=_markitdown,
        ),
    ]

    registry = ToolRegistry()
    for tool in tools:
        registry.register(tool)
    return registry
