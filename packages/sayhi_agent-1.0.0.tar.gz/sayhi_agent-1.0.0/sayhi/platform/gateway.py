"""
Panda Ronin — Platform Gateway
协调所有平台适配器，将 broadcast 注册到 agent
"""

from __future__ import annotations

import logging
import threading
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..config import Config

logger = logging.getLogger(__name__)


class ChannelAdapter(ABC):
    """所有平台适配器的基类"""

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    def send(self, message: str, **kwargs) -> None:
        """向该平台发送消息"""
        ...

    def start(self) -> None:
        """启动适配器（如 webhook 服务器、长轮询等）"""
        pass

    def stop(self) -> None:
        """停止适配器"""
        pass


class PlatformGateway:
    """
    聚合所有 ChannelAdapter，提供统一的 broadcast() 接口。
    把 broadcast 注册给 agent.core.PandaRonin。
    """

    def __init__(self):
        self._adapters: list[ChannelAdapter] = []
        self._lock = threading.Lock()

    def register(self, adapter: ChannelAdapter) -> "PlatformGateway":
        with self._lock:
            self._adapters.append(adapter)
        logger.info(f"Registered platform adapter: {adapter.name}")
        return self

    def broadcast(self, message: str, **kwargs) -> None:
        """向所有已注册平台广播消息"""
        with self._lock:
            adapters = list(self._adapters)
        for adapter in adapters:
            try:
                adapter.send(message, **kwargs)
            except Exception as e:
                logger.error(f"[{adapter.name}] broadcast failed: {e}")

    def start_all(self) -> None:
        for adapter in self._adapters:
            try:
                adapter.start()
            except Exception as e:
                logger.error(f"[{adapter.name}] failed to start: {e}")

    def stop_all(self) -> None:
        for adapter in self._adapters:
            try:
                adapter.stop()
            except Exception as e:
                logger.error(f"[{adapter.name}] failed to stop: {e}")


def build_gateway(config: "Config", agent) -> PlatformGateway:
    """根据 config 构建并连接网关"""
    from .adapters.cli import CLIAdapter

    gateway = PlatformGateway()

    # CLI is always registered — it is the primary interface
    cli = CLIAdapter(agent)
    gateway.register(cli)

    # Optional: Telegram
    if config.telegram.enabled and config.telegram.bot_token:
        try:
            from .adapters.telegram import TelegramAdapter
            gateway.register(TelegramAdapter(config.telegram, agent))
        except ImportError:
            logger.warning("python-telegram-bot not installed; Telegram disabled")

    # Optional: Feishu
    if config.feishu.enabled and config.feishu.app_id:
        try:
            from .adapters.feishu import FeishuAdapter
            gateway.register(FeishuAdapter(config.feishu, agent))
        except ImportError:
            logger.warning("lark-oapi not installed; Feishu disabled")

    # Optional: DingTalk
    if config.dingtalk.enabled and config.dingtalk.app_key:
        try:
            from .adapters.dingtalk import DingtalkAdapter
            gateway.register(DingtalkAdapter(config.dingtalk, agent))
        except ImportError:
            logger.warning("dingtalk-stream not installed; DingTalk disabled")

    # Optional: WeCom
    if config.wecom.enabled and config.wecom.corp_id:
        try:
            from .adapters.wecom import WecomAdapter
            gateway.register(WecomAdapter(config.wecom, agent))
        except ImportError:
            logger.warning("wechatpy not installed; WeCom disabled")

    # Optional: QQ
    if config.qq.enabled and config.qq.app_id:
        try:
            from .adapters.qq import QQAdapter
            gateway.register(QQAdapter(config.qq, agent))
        except ImportError:
            logger.warning("qq-botpy not installed; QQ disabled")

    # Optional: HTTP API
    if config.http.enabled:
        try:
            from .adapters.http_api import HttpAdapter
            gateway.register(HttpAdapter(config.http, agent))
        except ImportError:
            logger.warning("fastapi/uvicorn not installed; HTTP API disabled")

    # Wire broadcast into agent
    agent.broadcast = gateway.broadcast
    return gateway