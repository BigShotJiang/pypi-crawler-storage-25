"""
Panda Ronin — Feishu/Lark Adapter
依赖: pip install lark-oapi
文档: https://open.feishu.cn/document/home/index
"""

from __future__ import annotations

import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...config import FeishuConfig
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class FeishuAdapter(ChannelAdapter):
    name = "feishu"

    def __init__(self, config: "FeishuConfig", agent: "PandaRonin"):
        self.config = config
        self.agent = agent
        self._client = None
        self._server: HTTPServer | None = None
        self._thread: threading.Thread | None = None

    def send(self, message: str, open_id: str | None = None, **kwargs) -> None:
        if not self._client or not open_id:
            return
        try:
            import lark_oapi as lark
            from lark_oapi.api.im.v1 import CreateMessageRequest, CreateMessageRequestBody

            body = CreateMessageRequestBody.builder() \
                .receive_id(open_id) \
                .msg_type("text") \
                .content(json.dumps({"text": message})) \
                .build()
            req = CreateMessageRequest.builder() \
                .receive_id_type("open_id") \
                .request_body(body) \
                .build()
            self._client.im.v1.message.create(req)
        except Exception as e:
            logger.error(f"Feishu send failed: {e}")

    def start(self) -> None:
        try:
            import lark_oapi as lark
            self._client = lark.Client.builder() \
                .app_id(self.config.app_id) \
                .app_secret(self.config.app_secret) \
                .build()
        except ImportError:
            logger.warning("lark-oapi not installed")
            return

        self._thread = threading.Thread(target=self._run_webhook, daemon=True)
        self._thread.start()

    def _run_webhook(self) -> None:
        adapter = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(length))
                self.send_response(200)
                self.end_headers()

                # Challenge handshake
                if body.get("type") == "url_verification":
                    self.wfile.write(
                        json.dumps({"challenge": body["challenge"]}).encode()
                    )
                    return

                # Message event
                event = body.get("event", {})
                msg = event.get("message", {})
                if msg.get("message_type") == "text":
                    content = json.loads(msg.get("content", "{}"))
                    text = content.get("text", "")
                    sender = event.get("sender", {}).get("sender_id", {}).get("open_id")
                    if text and sender:
                        response = adapter.agent.chat(text)
                        adapter.send(response, open_id=sender)

            def log_message(self, *args): pass

        self._server = HTTPServer(("0.0.0.0", 8081), Handler)
        logger.info("Feishu webhook listening on :8081")
        self._server.serve_forever()

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()