"""
Panda Ronin — QQ 频道 Adapter
依赖: pip install qq-botpy
文档: https://bot.q.qq.com/wiki/develop/pythonsdk/
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...config import QQConfig
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class QQAdapter(ChannelAdapter):
    name = "qq"

    def __init__(self, config: "QQConfig", agent: "PandaRonin"):
        self.config = config
        self.agent = agent
        self._bot = None
        self._channel_id: str | None = config.guild_id or None
        self._thread: threading.Thread | None = None

    def send(self, message: str, channel_id: str | None = None, **kwargs) -> None:
        target = channel_id or self._channel_id
        if not self._bot or not target:
            return
        try:
            import asyncio
            asyncio.run_coroutine_threadsafe(
                self._bot.api.post_message(channel_id=target, content=message),
                self._loop,
            )
        except Exception as e:
            logger.error(f"QQ send failed: {e}")

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        try:
            import asyncio
            import botpy
            from botpy.message import Message

            adapter = self

            class PandaBot(botpy.Client):
                async def on_ready(self):
                    logger.info(f"QQ bot logged in as {self.robot.name}")
                    adapter._bot = self

                async def on_at_message_create(self, message: Message):
                    text = message.content.strip()
                    response = adapter.agent.chat(text)
                    await message.reply(content=response)

            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            intents = botpy.Intents(public_guild_messages=True)
            client = PandaBot(intents=intents)
            client.run(appid=self.config.app_id, token=self.config.app_token)
        except ImportError:
            logger.warning("qq-botpy not installed")
        except Exception as e:
            logger.error(f"QQ bot error: {e}")

    def stop(self) -> None:
        pass