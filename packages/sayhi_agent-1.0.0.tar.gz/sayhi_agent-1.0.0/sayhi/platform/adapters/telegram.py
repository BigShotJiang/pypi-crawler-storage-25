"""
Panda Ronin — Telegram Adapter
依赖: pip install python-telegram-bot
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...config import TelegramConfig
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class TelegramAdapter(ChannelAdapter):
    name = "telegram"

    def __init__(self, config: "TelegramConfig", agent: "PandaRonin"):
        self.config = config
        self.agent = agent
        self._app = None
        self._chat_ids: set[int] = set(config.allowed_chat_ids)
        self._thread: threading.Thread | None = None

    def send(self, message: str, chat_id: int | None = None, **kwargs) -> None:
        if self._app is None:
            return
        import asyncio
        targets = [chat_id] if chat_id else list(self._chat_ids)
        for cid in targets:
            try:
                asyncio.run_coroutine_threadsafe(
                    self._app.bot.send_message(chat_id=cid, text=message, parse_mode="Markdown"),
                    self._loop,
                )
            except Exception as e:
                logger.error(f"Telegram send failed to {cid}: {e}")

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if self._app:
            import asyncio
            asyncio.run_coroutine_threadsafe(self._app.stop(), self._loop)

    def _run(self) -> None:
        import asyncio
        from telegram.ext import Application, MessageHandler, filters, CommandHandler

        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        app = Application.builder().token(self.config.bot_token).build()
        self._app = app

        app.add_handler(CommandHandler("start", self._cmd_start))
        app.add_handler(CommandHandler("status", self._cmd_status))
        app.add_handler(CommandHandler("needs", self._cmd_needs))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self._on_message))

        logger.info("Telegram adapter starting...")
        app.run_polling()

    async def _cmd_start(self, update, context):
        cid = update.effective_chat.id
        self._chat_ids.add(cid)
        await update.message.reply_text(
            "🐼 *Panda Ronin* has acknowledged your presence.\n"
            "Use /status to check vitals, /needs to see pending requests.",
            parse_mode="Markdown",
        )

    async def _cmd_status(self, update, context):
        v = self.agent.vitals
        msg = (
            f"🐼 *Panda Ronin Status*\n"
            f"❤️ HP: {v.hp:.0f}/100\n"
            f"⚡ Energy: {v.energy:.0f}/100\n"
            f"🧠 Wisdom: {v.wisdom:.0f}/100\n"
            f"💬 Social: {v.social:.0f}/100\n"
            f"📅 Age: {v.age_str}\n"
            f"🔮 State: {v.state.value}"
        )
        await update.message.reply_text(msg, parse_mode="Markdown")

    async def _cmd_needs(self, update, context):
        needs = self.agent.needs_manager.pending()
        if not needs:
            await update.message.reply_text("No pending needs.")
            return
        lines = [f"📋 *Pending Needs*"]
        for n in needs:
            lines.append(f"`{n.need_id}` [{n.need_type.value}] *{n.title}*\n  {n.description}")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    async def _on_message(self, update, context):
        cid = update.effective_chat.id
        self._chat_ids.add(cid)
        text = update.message.text
        response = self.agent.chat(text)
        # Split long messages
        for chunk in self._split(response, 4000):
            await update.message.reply_text(chunk, parse_mode="Markdown")

    @staticmethod
    def _split(text: str, max_len: int) -> list[str]:
        return [text[i:i+max_len] for i in range(0, len(text), max_len)]