"""
Panda Ronin — Slack Adapter
依赖: pip install slack-bolt
文档: https://slack.dev/bolt-python/
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class SlackAdapter(ChannelAdapter):
    name = "slack"

    def __init__(self, bot_token: str, signing_secret: str, agent: "PandaRonin"):
        self.bot_token = bot_token
        self.signing_secret = signing_secret
        self.agent = agent
        self._app = None
        self._channels: set[str] = set()
        self._thread: threading.Thread | None = None

    def send(self, message: str, channel: str | None = None, **kwargs) -> None:
        if not self._app:
            return
        targets = [channel] if channel else list(self._channels)
        for ch in targets:
            try:
                self._app.client.chat_postMessage(
                    channel=ch,
                    text=message,
                    mrkdwn=True,
                )
            except Exception as e:
                logger.error(f"Slack send failed: {e}")

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        try:
            from slack_bolt import App
            from slack_bolt.adapter.socket_mode import SocketModeHandler

            adapter = self
            app = App(token=self.bot_token, signing_secret=self.signing_secret)
            adapter._app = app

            @app.event("message")
            def on_message(event, say):
                text = event.get("text", "")
                channel = event.get("channel")
                adapter._channels.add(channel)
                response = adapter.agent.chat(text)
                say(text=response)

            @app.event("app_mention")
            def on_mention(event, say):
                text = event.get("text", "")
                channel = event.get("channel")
                adapter._channels.add(channel)
                response = adapter.agent.chat(text)
                say(text=response)

            logger.info("Slack socket mode starting...")
            SocketModeHandler(app, self.bot_token).start()
        except ImportError:
            logger.warning("slack-bolt not installed")
        except Exception as e:
            logger.error(f"Slack error: {e}")

    def stop(self) -> None:
        pass