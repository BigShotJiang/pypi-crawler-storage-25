"""
Panda Ronin — HTTP API Adapter
依赖: pip install fastapi uvicorn
提供 REST + SSE 接口，供 web 客户端或第三方集成
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...config import HttpConfig
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class HttpAdapter(ChannelAdapter):
    name = "http_api"

    def __init__(self, config: "HttpConfig", agent: "PandaRonin"):
        self.config = config
        self.agent = agent
        self._app = None
        self._thread: threading.Thread | None = None
        self._pending: list[str] = []

    def send(self, message: str, **kwargs) -> None:
        self._pending.append(message)
        if len(self._pending) > 100:
            self._pending.pop(0)

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        try:
            import uvicorn
            from fastapi import FastAPI, HTTPException, Depends
            from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
            from fastapi.middleware.cors import CORSMiddleware
            from pydantic import BaseModel

            app = FastAPI(title="Panda Ronin API", version="0.1.0")
            app.add_middleware(
                CORSMiddleware,
                allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
            )

            api_key = self.config.api_key
            security = HTTPBearer(auto_error=bool(api_key))
            adapter = self

            def verify(creds: HTTPAuthorizationCredentials = Depends(security)):
                if api_key and creds.credentials != api_key:
                    raise HTTPException(status_code=401, detail="Invalid API key")

            class ChatRequest(BaseModel):
                message: str

            @app.get("/", response_class=__import__("fastapi").responses.HTMLResponse)
            def dashboard():
                v = adapter.agent.vitals
                def bar(val, total=100, width=20):
                    filled = int(width * val / total)
                    return "█" * filled + "░" * (width - filled)
                pending = adapter.agent.needs.pending()
                needs_html = "".join(
                    f"<li><b>{n.title}</b> [{n.need_type.value}] — {n.description[:80]}</li>"
                    for n in pending
                ) or "<li><i>暂无需求</i></li>"
                msgs_html = "".join(
                    f"<p>{m}</p>" for m in adapter._pending[-5:]
                ) or "<p><i>暂无消息</i></p>"
                state_color = {"healthy": "#4CAF50", "curious": "#2196F3", "hungry": "#FF9800",
                               "ill": "#F44336", "critical": "#B00020", "dormant": "#9E9E9E",
                               "dead": "#424242", "newborn": "#8BC34A"}.get(v.state.value, "#fff")
                return f"""<!DOCTYPE html>
<html lang="zh"><head><meta charset="utf-8">
<meta http-equiv="refresh" content="10">
<title>🐼 {v.name} — Panda Ronin</title>
<style>
body{{font-family:monospace;background:#0d1117;color:#c9d1d9;margin:0;padding:24px}}
h1{{color:#58a6ff}} .panel{{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:16px;margin:12px 0}}
.stat{{display:flex;align-items:center;gap:12px;margin:6px 0}}
.bar{{color:#4CAF50;letter-spacing:0}} .label{{color:#8b949e;width:60px}}
.state{{display:inline-block;padding:2px 10px;border-radius:4px;background:{state_color};color:#fff}}
ul{{padding-left:20px}} li{{margin:4px 0}} a{{color:#58a6ff}}
</style></head>
<body>
<h1>🐼 {v.name}</h1>
<div class="panel">
  <span class="state">{v.state.value.upper()}</span>&nbsp; Age: {v.age_str}
  <div class="stat"><span class="label">HP</span><span class="bar">{bar(v.hp)}</span> {v.hp:.0f}/100</div>
  <div class="stat"><span class="label">Energy</span><span class="bar">{bar(v.energy)}</span> {v.energy:.0f}/100</div>
  <div class="stat"><span class="label">Wisdom</span><span class="bar">{bar(v.wisdom)}</span> {v.wisdom:.0f}/100</div>
  <div class="stat"><span class="label">Social</span><span class="bar">{bar(v.social)}</span> {v.social:.0f}/100</div>
</div>
<div class="panel"><b>📊 Stats</b><br>
  Actions: {v.total_actions} &nbsp; Failures: {v.total_failures} &nbsp;
  Skills: {v.skills_learned} &nbsp; Helped: {v.times_helped}
</div>
<div class="panel"><b>📋 Pending Needs</b><ul>{needs_html}</ul></div>
<div class="panel"><b>📡 Recent Messages</b>{msgs_html}</div>
<div class="panel"><b>🔗 API</b> &nbsp;
  <a href="/status">/status</a> &nbsp;
  <a href="/needs">/needs</a> &nbsp;
  <a href="/docs">/docs</a>
</div>
<p style="color:#484f58;font-size:11px">Auto-refreshes every 10s · Panda Ronin</p>
</body></html>"""

            @app.get("/health")
            def health():
                return {"status": "alive" if adapter.agent.vitals.is_alive else "dead"}

            @app.get("/status")
            def status():
                v = adapter.agent.vitals
                return {
                    "hp": v.hp, "energy": v.energy,
                    "wisdom": v.wisdom, "social": v.social,
                    "state": v.state.value, "age": v.age_str,
                    "name": v.name,
                }

            @app.get("/needs")
            def needs():
                return [
                    {
                        "id": n.need_id, "type": n.need_type.value,
                        "title": n.title, "description": n.description,
                    }
                    for n in adapter.agent.needs.pending()
                ]

            @app.post("/chat")
            def chat(req: ChatRequest, _=Depends(verify)):
                response = adapter.agent.chat(req.message)
                return {"response": response}

            @app.post("/fulfill/{need_id}")
            def fulfill(need_id: str, req: ChatRequest, _=Depends(verify)):
                need = adapter.agent.needs.fulfill(need_id, req.message)
                if not need:
                    raise HTTPException(status_code=404, detail="Need not found")
                reply = adapter.agent.chat(
                    f"[SYSTEM] Your need '{need.title}' has been fulfilled: {req.message}"
                )
                return {"fulfilled": need.title, "response": reply}

            @app.get("/broadcast")
            def broadcast_poll():
                msgs = list(adapter._pending)
                adapter._pending.clear()
                return {"messages": msgs}

            self._app = app
            logger.info(f"HTTP API starting on {self.config.host}:{self.config.port}")
            uvicorn.run(
                app, host=self.config.host, port=self.config.port,
                log_level="warning",
            )
        except ImportError:
            logger.warning("fastapi/uvicorn not installed; HTTP API disabled")
        except Exception as e:
            logger.error(f"HTTP API error: {e}")

    def stop(self) -> None:
        pass