"""
Panda Ronin — Discord Adapter
依赖: pip install discord.py
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class DiscordAdapter(ChannelAdapter):
    name = "discord"

    def __init__(self, bot_token: str, agent: "PandaRonin"):
        self.bot_token = bot_token
        self.agent = agent
        self._client = None
        self._channels: list = []
        self._loop = None
        self._thread: threading.Thread | None = None

    def send(self, message: str, **kwargs) -> None:
        if not self._client or not self._channels:
            return
        import asyncio
        for channel in self._channels:
            try:
                asyncio.run_coroutine_threadsafe(
                    channel.send(message[:2000]),
                    self._loop,
                )
            except Exception as e:
                logger.error(f"Discord send failed: {e}")

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        try:
            import asyncio
            import discord

            adapter = self
            intents = discord.Intents.default()
            intents.message_content = True
            client = discord.Client(intents=intents)

            @client.event
            async def on_ready():
                adapter._client = client
                adapter._loop = asyncio.get_event_loop()
                logger.info(f"Discord bot logged in as {client.user}")

            @client.event
            async def on_message(message):
                if message.author == client.user:
                    return
                if client.user in message.mentions or isinstance(message.channel, discord.DMChannel):
                    if message.channel not in adapter._channels:
                        adapter._channels.append(message.channel)
                    response = adapter.agent.chat(message.content)
                    await message.reply(response[:2000])

            asyncio.run(client.start(self.bot_token))
        except ImportError:
            logger.warning("discord.py not installed")
        except Exception as e:
            logger.error(f"Discord error: {e}")

    def stop(self) -> None:
        if self._client:
            import asyncio
            asyncio.run_coroutine_threadsafe(self._client.close(), self._loop)