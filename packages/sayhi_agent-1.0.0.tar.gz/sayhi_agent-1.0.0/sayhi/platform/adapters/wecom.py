"""
Panda Ronin — 企业微信(WeCom) Adapter
依赖: pip install wechatpy
文档: https://developer.work.weixin.qq.com/document/path/90967
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...config import WecomConfig
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class WecomAdapter(ChannelAdapter):
    name = "wecom"

    def __init__(self, config: "WecomConfig", agent: "PandaRonin"):
        self.config = config
        self.agent = agent
        self._client = None
        self._thread: threading.Thread | None = None
        self._user_ids: list[str] = []

    def send(self, message: str, user_id: str = "@all", **kwargs) -> None:
        if not self._client:
            return
        try:
            self._client.message.send(
                agent_id=int(self.config.agent_id),
                party_ids=None,
                user_ids=[user_id] if user_id != "@all" else None,
                msg_type="text",
                msg_content={"content": message},
            )
        except Exception as e:
            logger.error(f"WeCom send failed: {e}")

    def start(self) -> None:
        try:
            from wechatpy.enterprise import WeChatClient
            self._client = WeChatClient(
                self.config.corp_id, self.config.corp_secret
            )
            logger.info("WeCom adapter initialized (push-only mode)")
        except ImportError:
            logger.warning("wechatpy not installed")

    def stop(self) -> None:
        pass