"""
SayHi — CLI Adapter
Rich 交互式终端 REPL
"""

from __future__ import annotations

import datetime
import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...agent.core import PandaRonin
    from ...agent.session import SessionStore


class CLIAdapter(ChannelAdapter):
    name = "cli"

    def __init__(self, agent: "PandaRonin", session_store: "SessionStore | None" = None):
        self.agent = agent
        self._lock = threading.Lock()
        self._session_store = session_store

    # ── 输出面板 ─────────────────────────────────────────────────

    def send(self, message: str, **kwargs) -> None:
        with self._lock:
            self._print_agent_panel(message)

    def _print_agent_panel(self, message: str) -> None:
        """Agent 回复：带 ✠ 标题的 Panel，内容用 Markdown 渲染。"""
        name = self.agent.profile.name
        try:
            from rich.console import Console
            from rich.panel import Panel
            from rich.markdown import Markdown
            Console().print(Panel(
                Markdown(message),
                title=f"[bold cyan]✠  {name}[/bold cyan]",
                border_style="cyan",
                padding=(0, 1),
            ))
        except ImportError:
            print(f"\n✠ {name}:\n{message}\n")

    def _print_user_panel(self, message: str) -> None:
        """用户消息：带 You 标题的 dim Panel。"""
        try:
            from rich.console import Console
            from rich.panel import Panel
            Console().print(Panel(
                message,
                title="[dim]You[/dim]",
                border_style="dim",
                padding=(0, 1),
            ))
        except ImportError:
            print(f"You: {message}")

    # ── REPL 主循环 ───────────────────────────────────────────────

    def run_repl(self) -> None:
        self._print_welcome()
        try:
            while True:
                user_input = self._read_input()
                if user_input is None:
                    break
                cmd = user_input.strip()
                if not cmd:
                    continue

                # ── 命令路由 ──────────────────────────────────────
                if cmd in ("/quit", "/exit", "/bye"):
                    self._print_farewell()
                    break
                if cmd == "/status":
                    self._print_status()
                    continue
                if cmd == "/score":
                    self._run_score()
                    continue
                if cmd == "/help":
                    self._print_help()
                    continue
                if cmd == "/path":
                    self._cmd_path()
                    continue
                if cmd == "/clear":
                    self._cmd_clear()
                    continue
                if cmd == "/compact":
                    self._cmd_compact()
                    continue
                if cmd.startswith("/session"):
                    self._cmd_session(cmd[len("/session"):].strip())
                    continue
                if cmd.startswith("/model"):
                    self._cmd_model(cmd[len("/model"):].strip())
                    continue

                # ── 普通聊天 ──────────────────────────────────────
                self._print_user_panel(cmd)
                response = self._chat_with_status(cmd)
                self.send(response)

        except (KeyboardInterrupt, EOFError):
            print("\n")

    def _chat_with_status(self, cmd: str) -> str:
        """调用 agent.chat()，同时在终端显示动态单行状态；日志输出静默。"""
        # 静默 sayhi 的 WARNING 日志，防止与 Live 输出混杂
        agent_logger = logging.getLogger("sayhi")
        old_level = agent_logger.level
        agent_logger.setLevel(logging.ERROR)

        try:
            from rich.console import Console
            from rich.live import Live
            from rich.text import Text

            console = Console()
            status_text = Text("💭 正在思考…", style="dim")

            def _update(msg: str):
                status_text.plain = msg

            self.agent.on_status = _update
            try:
                with Live(status_text, console=console, refresh_per_second=12, transient=True):
                    response = self.agent.chat(cmd)
            finally:
                self.agent.on_status = None
            return response
        except ImportError:
            return self.agent.chat(cmd)
        finally:
            agent_logger.setLevel(old_level)

    # ── 输入 ─────────────────────────────────────────────────────

    def _read_input(self) -> str | None:
        try:
            from rich.console import Console
            return Console().input("[dim]you[/dim] [bold cyan]❯[/bold cyan] ")
        except ImportError:
            return input("you ❯ ")
        except (KeyboardInterrupt, EOFError):
            return None

    # ── 欢迎 / 告别 ──────────────────────────────────────────────

    def _print_welcome(self) -> None:
        try:
            from rich.console import Console
            from rich.rule import Rule
            console = Console()
            console.print(Rule("[bold cyan]✠  SayHi[/bold cyan]", style="cyan"))
            console.print("[dim]输入 /help 查看命令，直接打字开始对话[/dim]\n")
        except ImportError:
            print("─" * 50 + "\n✠ SayHi\n" + "─" * 50 + "\n")

    def _print_farewell(self) -> None:
        try:
            from rich.console import Console
            Console().print("\n[dim]再见。[/dim]\n")
        except ImportError:
            print("\n再见。\n")

    # ── /status ──────────────────────────────────────────────────

    def _print_status(self) -> None:
        p = self.agent.profile
        last = p.last_score
        rate = f"{p.tool_success_rate * 100:.0f}%" if p.total_tool_calls else "—"
        last_score_str = ""
        if last:
            days_ago = (datetime.datetime.now().timestamp() - last["timestamp"]) / 86400
            last_score_str = f"  ·  上次评分 [bold]{last['composite']:.0f}[/bold]（{days_ago:.0f} 天前）"
        session_name = p.current_session
        try:
            from rich.console import Console
            from rich.panel import Panel
            Console().print(Panel(
                f"[dim]会话[/dim] #{p.session_count}  "
                f"[dim]消息[/dim] {p.total_messages}  "
                f"[dim]工具调用[/dim] {p.total_tool_calls}（成功率 {rate}）"
                f"{last_score_str}\n"
                f"[dim]当前 session[/dim] {session_name}  "
                f"[dim]存活时长[/dim] {p.age_str}",
                title="[cyan]📊 Profile[/cyan]",
                border_style="cyan",
            ))
        except ImportError:
            print(f"Sessions:{p.session_count} Messages:{p.total_messages} Tools:{p.total_tool_calls}({rate})")

    # ── /score ───────────────────────────────────────────────────

    def _run_score(self) -> None:
        try:
            from rich.console import Console
            Console().print("[dim]正在计算评分，请稍候…[/dim]")
        except ImportError:
            print("Scoring...")
        try:
            report = self.agent.run_score()
            self._print_score_report(report)
        except Exception as e:
            self.send(f"❌ 评分失败：{e}")

    def _print_score_report(self, report) -> None:
        try:
            from rich.console import Console
            from rich.panel import Panel

            console = Console()
            p = self.agent.profile

            def bar(val: float, width: int = 10) -> str:
                filled = int(width * val / 100)
                return "█" * filled + "░" * (width - filled)

            def delta_str(d: float) -> str:
                if abs(d) < 0.5:
                    return "[dim]→[/dim]"
                sign = "↑" if d > 0 else "↓"
                color = "green" if d > 0 else "red"
                return f"[{color}]{sign}{abs(d):.0f}[/{color}]"

            ts = datetime.datetime.fromtimestamp(report.timestamp).strftime("%Y-%m-%d %H:%M")
            prev_info = ""
            if report.previous_composite is not None:
                diff = report.composite - report.previous_composite
                sign = "+" if diff >= 0 else ""
                prev_info = f"  [dim](对比上次 {sign}{diff:.1f})[/dim]"

            lines = []
            lines.append(f"[dim]{ts}  ·  会话 #{p.session_count}[/dim]{prev_info}\n")

            lines.append("[bold]能力维度[/bold]")
            cap_keys = {"tool_mastery", "memory_depth", "conversation", "domain_expertise", "reliability"}
            for d in report.dimensions:
                if d.key not in cap_keys:
                    continue
                lines.append(
                    f"  [dim]{d.label:<8}[/dim]  {bar(d.score)}  "
                    f"[bold]{d.score:5.1f}[/bold]  {delta_str(d.delta)}"
                    + (f"  [dim]{d.reasoning}[/dim]" if d.reasoning else "")
                )

            lines.append("")
            lines.append("[bold]成长轨迹[/bold]")
            growth_keys = {"activity", "growth_rate"}
            for d in report.dimensions:
                if d.key not in growth_keys:
                    continue
                extra = ""
                if d.key == "activity":
                    extra = f"  [dim]({p.session_count} 次会话 / {p.total_messages} 条消息)[/dim]"
                lines.append(
                    f"  [dim]{d.label:<8}[/dim]  {bar(d.score)}  "
                    f"[bold]{d.score:5.1f}[/bold]  {delta_str(d.delta)}{extra}"
                )

            lines.append("")
            lines.append(
                f"[bold]综合分[/bold]  "
                f"[bold cyan]{report.composite:.1f}[/bold cyan] / 100   "
                f"{report.rank_emoji} [bold]{report.rank}[/bold]"
            )

            if report.milestones_achieved or report.milestones_pending:
                lines.append("")
                lines.append("[bold]📈 里程碑[/bold]")
                for m in report.milestones_achieved:
                    lines.append(f"  [green]✓[/green] {m}")
                for m in report.milestones_pending[:3]:
                    lines.append(f"  [dim]○ {m}[/dim]")

            console.print(Panel(
                "\n".join(lines),
                title=f"[cyan]✠ Score Card · {p.name}[/cyan]",
                border_style="cyan",
                padding=(1, 2),
            ))
        except ImportError:
            print(f"\nScore: {report.composite:.1f}/100  Rank: {report.rank}")
            for d in report.dimensions:
                print(f"  {d.label}: {d.score:.1f}")

    # ── /path ────────────────────────────────────────────────────

    def _cmd_path(self) -> None:
        from ...agent.scorer import RANKS
        p = self.agent.profile
        history = p.score_history
        if not history:
            self._info("暂无评分记录，请先运行 /score")
            return

        def get_rank(score: float) -> tuple[str, str]:
            for threshold, rank, emoji in RANKS:
                if score >= threshold:
                    return rank, emoji
            return "初学者", "🌱"

        lines = []
        prev_composite = None
        consecutive_up = 0
        max_consecutive = 0
        deltas = []

        for i, snap in enumerate(history):
            ts = datetime.datetime.fromtimestamp(snap["timestamp"]).strftime("%Y-%m-%d")
            comp = snap["composite"]
            rank, emoji = get_rank(comp)
            delta_str = ""
            if prev_composite is not None:
                d = comp - prev_composite
                deltas.append(d)
                sign = "↑+" if d >= 0 else "↓"
                color = "green" if d >= 0 else "red"
                delta_str = f"  [{color}]{sign}{abs(d):.1f}[/{color}]"
                if d > 0:
                    consecutive_up += 1
                    max_consecutive = max(max_consecutive, consecutive_up)
                else:
                    consecutive_up = 0
            is_current = " [bold cyan]← 当前[/bold cyan]" if i == len(history) - 1 else ""
            lines.append(
                f"  [dim]{ts}[/dim]  {emoji} [bold]{rank:<6}[/bold]  "
                f"[cyan]{comp:5.1f}[/cyan]{delta_str}{is_current}"
            )
            prev_composite = comp

        lines.append("")
        if deltas:
            avg = sum(deltas) / len(deltas)
            lines.append(f"  [dim]最长连续进步：{max_consecutive} 次  ·  平均变化：{avg:+.1f} / 次[/dim]")

        try:
            from rich.console import Console
            from rich.panel import Panel
            Console().print(Panel(
                "\n".join(lines),
                title=f"[cyan]📈 成长路径 · {p.name}[/cyan]",
                border_style="cyan",
                padding=(1, 2),
            ))
        except ImportError:
            for line in lines:
                print(line)

    # ── /session ─────────────────────────────────────────────────

    def _cmd_session(self, arg: str) -> None:
        if not self._session_store:
            self._info("会话持久化未启用")
            return

        p = self.agent.profile

        if not arg:
            sessions = self._session_store.list_sessions()
            if not sessions:
                self._info(f"当前只有一个会话：[bold]{p.current_session}[/bold]")
                return
            lines = []
            for s in sessions:
                marker = " [cyan]← 当前[/cyan]" if s["name"] == p.current_session else ""
                ts = datetime.datetime.fromtimestamp(s["created_at"]).strftime("%m-%d %H:%M") if s["created_at"] else "—"
                summary = f"  [dim]{s['summary'][:40]}…[/dim]" if s.get("summary") else ""
                lines.append(
                    f"  [bold]{s['name']:<16}[/bold]  "
                    f"[dim]{s['msg_count']} 条消息  {ts}[/dim]{marker}{summary}"
                )
            self._panel("\n".join(lines), title="[cyan]💬 会话列表[/cyan]")
            return

        target = arg.strip()
        if target == p.current_session:
            self._info(f"已在会话 [bold]{target}[/bold] 中")
            return

        self._session_store.save(p.current_session, self.agent.messages)
        self.agent.messages = self._session_store.load(target)
        p.current_session = target
        self._info(f"已切换到会话 [bold]{target}[/bold]（{len(self.agent.messages) // 2} 条历史消息）")

    # ── /clear ───────────────────────────────────────────────────

    def _cmd_clear(self) -> None:
        p = self.agent.profile
        count = len(self.agent.messages)
        self.agent.messages = []
        if self._session_store:
            self._session_store.delete(p.current_session)
        self._info(f"已清空会话 [bold]{p.current_session}[/bold]（{count} 条消息已移除）")

    # ── /compact ─────────────────────────────────────────────────

    def _cmd_compact(self) -> None:
        if not self.agent.messages:
            self._info("当前会话为空，无需压缩")
            return

        original_count = len(self.agent.messages)
        self._info_inline("正在压缩对话历史…")

        history_text = "\n".join(
            f"{'用户' if m['role'] == 'user' else 'Agent'}: {(m.get('content') or '')[:300]}"
            for m in self.agent.messages
            if m.get("role") in ("user", "assistant") and m.get("content")
        )

        prompt = (
            f"请将以下对话历史压缩为一段简洁的摘要（不超过 300 字），"
            f"保留关键事实、结论和用户偏好：\n\n{history_text}"
        )
        try:
            resp = self.agent._call_llm(
                [
                    {"role": "system", "content": "你是对话压缩助手，只输出摘要文本，不要加任何格式。"},
                    {"role": "user", "content": prompt},
                ],
                tools=None,
            )
            summary = (resp.choices[0].message.content or "").strip()
        except Exception as e:
            self._info(f"❌ 压缩失败：{e}")
            return

        self.agent.messages = [{"role": "system", "content": f"[对话摘要]\n{summary}"}]
        if self._session_store:
            self._session_store.set_summary(
                self.agent.profile.current_session,
                self.agent.messages,
                summary,
            )
        self._info(f"已压缩：{original_count} 条 → 1 条摘要（{len(summary)} 字）")

    # ── /model ───────────────────────────────────────────────────

    def _cmd_model(self, arg: str) -> None:
        if not arg:
            self._info(f"当前模型：[bold cyan]{self.agent.model}[/bold cyan]")
            self._info("[dim]用法：/model <model_string>  或  /model add[/dim]")
            return

        if arg == "add":
            self._cmd_model_add()
            return

        self.agent.model = arg
        self._info(f"已切换模型：[bold cyan]{arg}[/bold cyan]（当前会话立即生效）")

    def _cmd_model_add(self) -> None:
        """Mini 配置向导：使用 input() 避免 Windows Rich Console 输入 bug。"""
        self._info("[bold]配置新模型[/bold]（回车跳过可选项）")
        try:
            model_str = input("  ❯ 模型字符串（如 deepseek/deepseek-chat）：").strip()
            if not model_str:
                self._info("已取消")
                return
            api_key  = input("  ❯ API Key（Ollama 留空）：").strip()
            base_url = input("  ❯ Base URL（默认留空）：").strip()
        except (KeyboardInterrupt, EOFError):
            self._info("已取消")
            return

        self.agent.model = model_str
        if api_key:
            self.agent.api_key = api_key
        if base_url:
            self.agent.base_url = base_url or None

        from pathlib import Path
        config_path = Path.home() / ".sayhi" / "config.yaml"
        try:
            import yaml as _yaml
            if config_path.exists():
                with open(config_path, encoding="utf-8") as f:
                    cfg = _yaml.safe_load(f) or {}
            else:
                cfg = {}
            cfg.setdefault("llm", {})
            cfg["llm"]["model"] = model_str
            if api_key:
                cfg["llm"]["api_key"] = api_key
            if base_url:
                cfg["llm"]["base_url"] = base_url
            with open(config_path, "w", encoding="utf-8") as f:
                _yaml.dump(cfg, f, allow_unicode=True, default_flow_style=False)
            self._info(f"✓ 已写入 {config_path}")
        except Exception:
            self._info("⚠️  config.yaml 写入失败，本次会话仍已切换模型")

        self._info(f"✓ 当前模型已切换为 [bold cyan]{model_str}[/bold cyan]")

    # ── /help ────────────────────────────────────────────────────

    def _print_help(self) -> None:
        help_text = (
            "**Commands**\n\n"
            "| 命令 | 说明 |\n"
            "|------|------|\n"
            "| `/session [name]` | 列出/切换会话 |\n"
            "| `/clear` | 清空当前会话 |\n"
            "| `/compact` | 压缩会话历史 |\n"
            "| `/model [name\\|add]` | 查看/切换/添加模型 |\n"
            "| `/path` | 查看成长路径 |\n"
            "| `/score` | 能力维度评分 |\n"
            "| `/status` | Profile 概览 |\n"
            "| `/quit` | 退出 |\n\n"
            "直接打字开始对话。"
        )
        try:
            from rich.console import Console
            from rich.markdown import Markdown
            Console().print(Markdown(help_text))
        except ImportError:
            print(help_text)

    # ── 工具方法 ─────────────────────────────────────────────────

    def _info(self, msg: str) -> None:
        try:
            from rich.console import Console
            Console().print(f"  {msg}")
        except ImportError:
            print(f"  {msg}")

    def _info_inline(self, msg: str) -> None:
        try:
            from rich.console import Console
            Console().print(f"  [dim]{msg}[/dim]")
        except ImportError:
            print(f"  {msg}")

    def _panel(self, content: str, title: str = "") -> None:
        try:
            from rich.console import Console
            from rich.panel import Panel
            Console().print(Panel(content, title=title, border_style="cyan", padding=(0, 2)))
        except ImportError:
            print(content)