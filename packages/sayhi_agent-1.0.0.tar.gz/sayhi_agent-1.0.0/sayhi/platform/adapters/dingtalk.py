"""
Panda Ronin — DingTalk Adapter
依赖: pip install dingtalk-stream
文档: https://open.dingtalk.com/document/orgapp/overview-of-dingtalk-stream
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

from ..gateway import ChannelAdapter

if TYPE_CHECKING:
    from ...config import DingtalkConfig
    from ...agent.core import PandaRonin

logger = logging.getLogger(__name__)


class DingtalkAdapter(ChannelAdapter):
    name = "dingtalk"

    def __init__(self, config: "DingtalkConfig", agent: "PandaRonin"):
        self.config = config
        self.agent = agent
        self._client = None
        self._thread: threading.Thread | None = None

    def send(self, message: str, webhook: str | None = None, **kwargs) -> None:
        target = webhook or self.config.webhook_url
        if not target:
            return
        try:
            import requests
            payload = {
                "msgtype": "markdown",
                "markdown": {
                    "title": "🐼 Panda Ronin",
                    "text": f"## 🐼 Panda Ronin\n\n{message}",
                },
            }
            requests.post(target, json=payload, timeout=10)
        except Exception as e:
            logger.error(f"DingTalk send failed: {e}")

    def start(self) -> None:
        if not self.config.app_key or not self.config.app_secret:
            return
        self._thread = threading.Thread(target=self._run_stream, daemon=True)
        self._thread.start()

    def _run_stream(self) -> None:
        try:
            import dingtalk_stream
            from dingtalk_stream import ChatbotHandler, AckMessage

            adapter = self

            class Handler(ChatbotHandler):
                async def process(self, callback):
                    incoming = dingtalk_stream.ChatbotMessage.from_dict(callback.data)
                    text = incoming.text.content.strip()
                    response = adapter.agent.chat(text)
                    self.reply_text(response, incoming)
                    return AckMessage.STATUS_OK, "OK"

            client = dingtalk_stream.DingTalkStreamClient(
                dingtalk_stream.Credential(self.config.app_key, self.config.app_secret)
            )
            client.register_callback_handler(
                dingtalk_stream.ChatbotMessage.TOPIC, Handler()
            )
            logger.info("DingTalk stream adapter started")
            client.start_forever()
        except ImportError:
            logger.warning("dingtalk-stream not installed")
        except Exception as e:
            logger.error(f"DingTalk stream error: {e}")

    def stop(self) -> None:
        pass