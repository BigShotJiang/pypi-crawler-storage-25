"""
Panda Ronin — Agent Scorer
7 维多模态评分系统：能力维度（5）+ 成长轨迹（2）
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .core import PandaRonin

# ── 维度定义（key, 中文名, 权重）────────────────────────────────────

CAPABILITY_DIMS = [
    ("tool_mastery",     "工具精通度", 0.20),
    ("memory_depth",     "记忆积累",   0.15),
    ("conversation",     "对话质量",   0.20),
    ("domain_expertise", "领域专长",   0.20),
    ("reliability",      "执行可靠性", 0.10),
]

GROWTH_DIMS = [
    ("activity",    "活跃度",   0.10),
    ("growth_rate", "成长速率", 0.05),
]

ALL_DIMS = CAPABILITY_DIMS + GROWTH_DIMS

RANKS = [
    (80, "宗师",   "🏆"),
    (60, "专家",   "🥇"),
    (40, "进阶学者", "🏅"),
    (20, "见习者", "📚"),
    (0,  "初学者", "🌱"),
]

MILESTONES = [
    ("first_tool",   "首次成功调用工具",    lambda p, mc, c: p.tool_success_count > 0),
    ("memory_10",    "记忆条目突破 10 条",  lambda p, mc, c: mc >= 10),
    ("memory_50",    "记忆条目突破 50 条",  lambda p, mc, c: mc >= 50),
    ("memory_100",   "记忆条目突破 100 条", lambda p, mc, c: mc >= 100),
    ("messages_50",  "累计对话超过 50 轮",  lambda p, mc, c: p.total_messages >= 50),
    ("messages_200", "累计对话超过 200 轮", lambda p, mc, c: p.total_messages >= 200),
    ("messages_500", "累计对话超过 500 轮", lambda p, mc, c: p.total_messages >= 500),
    ("multi_tool",   "掌握 5 种以上工具",   lambda p, mc, c: len(p.tool_names_used) >= 5),
    ("sessions_10",  "完成 10 次会话",      lambda p, mc, c: p.session_count >= 10),
    ("score_60",     "综合能力评分突破 60", lambda p, mc, c: c >= 60),
    ("score_80",     "综合能力评分突破 80", lambda p, mc, c: c >= 80),
]


@dataclass
class DimensionScore:
    key: str
    label: str
    score: float
    delta: float
    reasoning: str = ""


@dataclass
class ScoreReport:
    timestamp: float
    dimensions: list
    composite: float
    rank: str
    rank_emoji: str
    milestones_achieved: list
    milestones_pending: list
    previous_composite: float | None = None

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "composite": round(self.composite, 1),
            "rank": self.rank,
            "dimensions": {
                d.key: {
                    "score": round(d.score, 1),
                    "delta": round(d.delta, 1),
                    "reasoning": d.reasoning,
                }
                for d in self.dimensions
            },
        }


class AgentScorer:
    def __init__(self, agent: "PandaRonin"):
        self.agent = agent

    def compute(self) -> ScoreReport:
        profile = self.agent.profile
        prev = profile.last_score

        # 1. 算法评分
        algo = self._compute_algorithmic(profile)

        # 2. LLM 自评
        llm = self._compute_llm_assessed()

        # 3. 合并所有维度
        dim_scores: list[DimensionScore] = []
        for key, label, _ in ALL_DIMS:
            score = algo.get(key, llm.get(key, 50.0))
            prev_score = (
                prev["dimensions"].get(key, {}).get("score") if prev else None
            )
            delta = (score - prev_score) if prev_score is not None else 0.0
            reasoning = llm.get(f"{key}_reason", "")
            dim_scores.append(DimensionScore(
                key=key, label=label,
                score=max(0.0, min(100.0, score)),
                delta=delta,
                reasoning=reasoning,
            ))

        # 4. 综合分
        composite = sum(
            d.score * w
            for d, (_, _, w) in zip(dim_scores, ALL_DIMS)
        )

        # 5. 段位
        rank, rank_emoji = self._get_rank(composite)

        # 6. 里程碑
        memory_count = self._count_memory_entries()
        achieved, pending = self._check_milestones(profile, memory_count, composite)

        report = ScoreReport(
            timestamp=time.time(),
            dimensions=dim_scores,
            composite=composite,
            rank=rank,
            rank_emoji=rank_emoji,
            milestones_achieved=achieved,
            milestones_pending=pending,
            previous_composite=prev["composite"] if prev else None,
        )

        profile.add_score(report.to_dict())
        profile.save(self.agent.home)
        return report

    # ── 算法评分 ──────────────────────────────────────────────────

    def _compute_algorithmic(self, profile) -> dict[str, float]:
        scores: dict[str, float] = {}

        # 工具精通度：工具多样性 × 成功率
        variety = min(len(profile.tool_names_used) / 12.0, 1.0)
        rate = profile.tool_success_rate
        scores["tool_mastery"] = (variety * 0.4 + rate * 0.6) * 100

        # 执行可靠性：工具成功率
        scores["reliability"] = rate * 100 if profile.total_tool_calls > 0 else 0.0

        # 活跃度：会话数 + 消息数
        session_part = min(profile.session_count / 30.0, 1.0) * 50
        message_part = min(profile.total_messages / 500.0, 1.0) * 50
        scores["activity"] = session_part + message_part

        # 成长速率：历史综合分斜率
        scores["growth_rate"] = self._compute_growth_rate(profile)

        return scores

    def _compute_growth_rate(self, profile) -> float:
        history = profile.score_history
        if len(history) < 2:
            return 50.0
        earliest = history[0]["composite"]
        latest = history[-1]["composite"]
        span_days = max(
            (history[-1]["timestamp"] - history[0]["timestamp"]) / 86400, 0.1
        )
        daily_rate = (latest - earliest) / span_days
        return max(0.0, min(100.0, 50.0 + daily_rate * 5))

    # ── LLM 自评 ──────────────────────────────────────────────────

    def _compute_llm_assessed(self) -> dict[str, float]:
        try:
            profile = self.agent.profile
            memory_text = self._read_memory_sample()
            conv_text = self._format_conversation()

            prompt = f"""你是 {profile.name}，请基于以下信息对自己的三个能力维度各给出 0-100 整数分，并各用一句话说明理由。

## 记忆积累样本
{memory_text or "（暂无记忆记录）"}

## 最近对话
{conv_text or "（暂无对话历史）"}

## 客观统计
- 总对话轮数：{profile.total_messages}
- 工具调用次数：{profile.total_tool_calls}（成功 {profile.tool_success_count} 次）
- 已掌握工具：{', '.join(profile.tool_names_used) or "无"}

请严格返回 JSON，不要加 markdown 代码块：
{{"conversation":<整数>,"conversation_reason":"<一句话>","domain_expertise":<整数>,"domain_expertise_reason":"<一句话>","memory_depth":<整数>,"memory_depth_reason":"<一句话>"}}"""

            messages = [
                {"role": "system", "content": "你是正在进行自我评估的 AI agent。只输出 JSON，不要有其他内容。"},
                {"role": "user", "content": prompt},
            ]
            resp = self.agent._call_llm(messages, tools=None)
            raw = (resp.choices[0].message.content or "").strip()
            if "```" in raw:
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            data = json.loads(raw.strip())
            return {
                "conversation":            float(data.get("conversation", 50)),
                "conversation_reason":     data.get("conversation_reason", ""),
                "domain_expertise":        float(data.get("domain_expertise", 50)),
                "domain_expertise_reason": data.get("domain_expertise_reason", ""),
                "memory_depth":            float(data.get("memory_depth", 50)),
                "memory_depth_reason":     data.get("memory_depth_reason", ""),
            }
        except Exception:
            return {
                "conversation": 50.0, "domain_expertise": 50.0, "memory_depth": 50.0
            }

    # ── 辅助 ──────────────────────────────────────────────────────

    def _read_memory_sample(self, max_lines: int = 30) -> str:
        f = self.agent.home / "MEMORY.md"
        if not f.exists():
            return ""
        lines = f.read_text(encoding="utf-8").splitlines()
        return "\n".join(lines[-max_lines:])

    def _count_memory_entries(self) -> int:
        f = self.agent.home / "MEMORY.md"
        if not f.exists():
            return 0
        return sum(1 for ln in f.read_text(encoding="utf-8").splitlines() if ln.startswith("- "))

    def _format_conversation(self) -> str:
        lines = []
        for m in self.agent.messages[-20:]:
            role = "用户" if m["role"] == "user" else "Agent"
            content = (m.get("content") or "")[:200]
            if content:
                lines.append(f"{role}: {content}")
        return "\n".join(lines)

    def _get_rank(self, composite: float) -> tuple[str, str]:
        for threshold, rank, emoji in RANKS:
            if composite >= threshold:
                return rank, emoji
        return "初学者", "🌱"

    def _check_milestones(
        self, profile, memory_count: int, composite: float
    ) -> tuple[list[str], list[str]]:
        achieved, pending = [], []
        for _, label, fn in MILESTONES:
            (achieved if fn(profile, memory_count, composite) else pending).append(label)
        return achieved, pending
