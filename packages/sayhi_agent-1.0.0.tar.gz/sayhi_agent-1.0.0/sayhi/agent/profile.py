"""
Panda Ronin — Agent Profile
统计追踪：会话数、消息数、工具调用、历史评分快照
持久化到 ~/.panda-ronin/profile.json
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class AgentProfile:
    name: str = "SayHi"
    born_at: float = field(default_factory=time.time)

    # 累计统计
    session_count: int = 0
    total_messages: int = 0
    total_tool_calls: int = 0
    tool_success_count: int = 0
    tool_names_used: list = field(default_factory=list)

    # 历史评分快照（最多保留 50 条）
    score_history: list = field(default_factory=list)

    # 当前活跃会话名
    current_session: str = "default"

    # ── 计算属性 ──────────────────────────────────────────────────

    @property
    def age_seconds(self) -> float:
        return time.time() - self.born_at

    @property
    def age_str(self) -> str:
        s = int(self.age_seconds)
        d, s = divmod(s, 86400)
        h, s = divmod(s, 3600)
        m, s = divmod(s, 60)
        if d > 0:
            return f"{d}d {h}h {m}m"
        if h > 0:
            return f"{h}h {m}m {s}s"
        return f"{m}m {s}s"

    @property
    def tool_success_rate(self) -> float:
        if self.total_tool_calls == 0:
            return 0.0
        return self.tool_success_count / self.total_tool_calls

    @property
    def last_score(self) -> dict | None:
        return self.score_history[-1] if self.score_history else None

    # ── 更新方法 ──────────────────────────────────────────────────

    def record_message(self) -> None:
        self.total_messages += 1

    def record_tool(self, name: str, success: bool) -> None:
        self.total_tool_calls += 1
        if success:
            self.tool_success_count += 1
        if name not in self.tool_names_used:
            self.tool_names_used.append(name)

    def add_score(self, report: dict) -> None:
        self.score_history.append(report)
        if len(self.score_history) > 50:
            self.score_history = self.score_history[-50:]

    # ── 持久化 ────────────────────────────────────────────────────

    def save(self, home: Path) -> None:
        home.mkdir(parents=True, exist_ok=True)
        (home / "profile.json").write_text(
            json.dumps(asdict(self), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, home: Path) -> "AgentProfile":
        path = home / "profile.json"
        if not path.exists():
            # 尝试从旧 soul.json 迁移名字
            soul_path = home / "soul.json"
            if soul_path.exists():
                try:
                    soul = json.loads(soul_path.read_text(encoding="utf-8"))
                    return cls(name=soul.get("name", "SayHi"))
                except Exception:
                    pass
            return cls()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
        except Exception:
            return cls()
