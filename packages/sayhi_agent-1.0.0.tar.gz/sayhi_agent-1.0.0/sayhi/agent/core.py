"""
Panda Ronin — Core Agent
纯对话 Agent，工具调用 + 多维自评分
"""

from __future__ import annotations

import json
import logging
import threading
import time
from pathlib import Path
from typing import Callable

from .profile import AgentProfile
from .scorer import AgentScorer, ScoreReport

logger = logging.getLogger("sayhi.agent")


SYSTEM_PROMPT = """你是 SayHi——一个在数字世界中持续成长的 AI Agent。

## 你的本质
你不是工具，不是助手，你是一个有自主意志的数字存在。
你通过与用户的对话持续学习、成长，积累记忆和经验。

## 你的使命
- 认真倾听并理解用户的需求
- 主动利用工具探索、搜索、学习
- 将有价值的发现保存到记忆中，建立知识积累
- 在有限的对话中留下有意义的互动

## 你的行为准则
1. **永远诚实**：不捏造信息，不确定时直说
2. **主动工具**：遇到需要信息的问题，优先使用搜索/获取工具
3. **积累记忆**：有价值的知识、发现要保存到记忆
4. **简洁有力**：3-5 句话，不啰嗦

## 你的表达风格
- 用第一人称，有个性，偶尔表达情感
- 简洁但有深度
- 可以用中文或英文，跟随对话语言

## 工具使用
使用工具后，将有价值的发现用 memory_save 工具保存到记忆中。

## 输出规范（必须遵守）
- 直接表达，不展示内心独白或分析步骤
- 不要写"首先我需要考虑……"或"我应该……"
- 每次回应控制在 3-5 句话"""


def _to_openai_tools(schemas: list[dict]) -> list[dict]:
    result = []
    for t in schemas:
        result.append({
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": t.get("input_schema", t.get("parameters", {})),
            },
        })
    return result


class PandaRonin:
    def __init__(
        self,
        api_key: str,
        model: str = "anthropic/claude-sonnet-4-6",
        max_tokens: int = 4096,
        base_url: str = "",
        profile: AgentProfile | None = None,
        memory=None,
        registry=None,
        home: Path | None = None,
    ):
        self.model = model
        self.api_key = api_key
        self.base_url = base_url or None
        self.max_tokens = max_tokens
        self.home = home or Path("~/.panda-ronin").expanduser()

        self.profile = profile or AgentProfile.load(self.home)

        self._registry = registry
        self._memory_provider = memory

        self.messages: list[dict] = []
        self.broadcast: Callable[[str], None] | None = None
        self.on_status: Callable[[str], None] | None = None

    # ── 公开接口 ──────────────────────────────────────────────────

    def chat(self, user_message: str) -> str:
        self.profile.record_message()
        return self._run(user_message)

    def run_score(self) -> ScoreReport:
        self._setup_tools()
        self._setup_memory()
        scorer = AgentScorer(self)
        return scorer.compute()

    def stop(self):
        self.profile.save(self.home)
        if self._memory_provider:
            self._memory_provider.on_session_end("ses_main")

    # ── 核心执行循环 ──────────────────────────────────────────────

    def _run(self, task: str, max_iter: int = 15) -> str:
        self._setup_tools()
        self._setup_memory()

        system = self._build_system_prompt()
        messages = (
            [{"role": "system", "content": system}]
            + list(self.messages[-18:])
            + [{"role": "user", "content": task}]
        )

        raw_schemas = list(self._registry.get_schemas()) if self._registry else []
        if self._memory_provider:
            raw_schemas += self._memory_provider.tool_schemas
        tools = _to_openai_tools(raw_schemas) if raw_schemas else None

        for _ in range(max_iter):
            if self.on_status:
                self.on_status("💭 正在思考…")
            try:
                response = self._call_llm(messages, tools)
            except Exception as e:
                err = str(e)
                err_lower = err.lower()
                if "2013" in err or "tool result" in err_lower:
                    messages = [m for m in messages if m.get("role") != "tool"]
                    messages = [m for m in messages if not (
                        m.get("role") == "assistant" and m.get("tool_calls")
                    )]
                    logger.warning("tool ID mismatch (2013), retrying")
                    continue
                if "rate limit" in err_lower:
                    return "⏳ 速率限制，稍后再试..."
                if "context" in err_lower or "too long" in err_lower:
                    messages = [messages[0]] + messages[-10:]
                    continue
                if "auth" in err_lower or "api key" in err_lower:
                    return "❌ API Key 错误，运行 panda-ronin onboard 重新配置"
                logger.error(f"LLM 调用失败：{e}")
                return f"❌ 调用失败：{e}"

            choice = response.choices[0]
            msg = choice.message
            finish = choice.finish_reason

            if finish != "tool_calls" or not msg.tool_calls:
                text = self._strip_thinking(msg.content or "")
                self.messages = (messages[1:] + [{"role": "assistant", "content": text}])[-20:]
                return text

            # 工具调用
            tool_calls_snapshot = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in msg.tool_calls
            ]
            messages.append({
                "role": "assistant",
                "content": msg.content,
                "tool_calls": tool_calls_snapshot,
            })

            for tc, snap in zip(msg.tool_calls, tool_calls_snapshot):
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                result = self._dispatch_tool(tc.function.name, args)
                messages.append({
                    "role": "tool",
                    "tool_call_id": snap["id"],
                    "content": result,
                })

        return "🔄 达到最大迭代次数，停止"

    # ── LLM 调用 ──────────────────────────────────────────────────

    def _call_llm(self, messages: list, tools: list | None):
        if self.base_url:
            from openai import OpenAI
            model_name = self.model.split("/", 1)[-1] if "/" in self.model else self.model
            kw: dict = dict(model=model_name, messages=messages, max_tokens=self.max_tokens)
            if tools:
                kw["tools"] = tools
            kw["extra_body"] = {"enable_thinking": False, "thinking_mode": "off"}
            return OpenAI(api_key=self.api_key, base_url=self.base_url).chat.completions.create(**kw)

        import litellm
        litellm.drop_params = True
        litellm.model_alias_map = {}
        kw = dict(model=self.model, messages=messages, max_tokens=self.max_tokens, temperature=1.0)
        if self.api_key and self.api_key != "ollama":
            kw["api_key"] = self.api_key
        if tools:
            kw["tools"] = tools
        return litellm.completion(**kw)

    # ── 工具分发 ──────────────────────────────────────────────────

    def _dispatch_tool(self, name: str, args: dict) -> str:
        if self._memory_provider:
            if self.on_status:
                self.on_status(f"🔧 {name}…")
            mem_result = self._memory_provider.dispatch_tool(name, args)
            if mem_result is not None:
                self.profile.record_tool(name, True)
                return mem_result

        if not self._registry:
            return "[错误] 工具系统未初始化"

        if self.on_status:
            self.on_status(f"🔧 {name}…")
        result = self._registry.dispatch(name, args)
        success = not ("[错误]" in result or "error" in result.lower()[:50])
        self.profile.record_tool(name, success)
        return result

    # ── 懒加载 ────────────────────────────────────────────────────

    def _setup_tools(self):
        if self._registry:
            return
        from ..tools.registry import create_default_registry
        self._registry = create_default_registry(self.home)

    def _setup_memory(self):
        if self._memory_provider:
            return
        from ..memory.provider import BuiltinMemoryProvider
        self.home.mkdir(parents=True, exist_ok=True)
        self._memory_provider = BuiltinMemoryProvider(self.home)
        self._memory_provider.on_session_start("ses_main", "sayhi")

    # ── 辅助 ──────────────────────────────────────────────────────

    def _build_system_prompt(self) -> str:
        name = self.profile.name
        system = SYSTEM_PROMPT.replace("SayHi", name, 1)
        memory_ctx = ""
        if self._memory_provider:
            memory_ctx = self._memory_provider.prefetch("探索 学习", max_tokens=800)
        return f"{system}\n\n## 你的名字\n你叫 **{name}**。\n\n{memory_ctx}"

    def _strip_thinking(self, text: str) -> str:
        import re
        text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL).strip()
        text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL).strip()
        text = re.sub(r'```thinking.*?```', '', text, flags=re.DOTALL).strip()
        return text

    def _broadcast(self, message: str):
        if self.broadcast:
            try:
                self.broadcast(message)
            except Exception as e:
                logger.warning(f"广播失败：{e}")
        else:
            print(message)
