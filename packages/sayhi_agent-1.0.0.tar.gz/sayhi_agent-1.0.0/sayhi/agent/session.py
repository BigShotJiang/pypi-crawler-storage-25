"""
Panda Ronin — Session Store
多会话持久化：~/.panda-ronin/sessions/{name}.json
"""

from __future__ import annotations

import json
import time
from pathlib import Path


class SessionStore:
    def __init__(self, home: Path):
        self.sessions_dir = home / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)

    # ── 公开接口 ──────────────────────────────────────────────────

    def list_sessions(self) -> list[dict]:
        result = []
        for f in sorted(self.sessions_dir.glob("*.json")):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                msgs = data.get("messages", [])
                result.append({
                    "name": data.get("name", f.stem),
                    "created_at": data.get("created_at", 0.0),
                    "msg_count": len([m for m in msgs if m.get("role") in ("user", "assistant")]),
                    "summary": data.get("summary", ""),
                })
            except Exception:
                continue
        return result

    def load(self, name: str) -> list[dict]:
        path = self._path(name)
        if not path.exists():
            return []
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data.get("messages", [])
        except Exception:
            return []

    def save(self, name: str, messages: list[dict], summary: str = "") -> None:
        path = self._path(name)
        existing = {}
        if path.exists():
            try:
                existing = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                pass
        data = {
            "name": name,
            "created_at": existing.get("created_at", time.time()),
            "messages": messages,
            "summary": summary or existing.get("summary", ""),
        }
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def delete(self, name: str) -> None:
        path = self._path(name)
        if path.exists():
            path.unlink()

    def get_summary(self, name: str) -> str:
        path = self._path(name)
        if not path.exists():
            return ""
        try:
            return json.loads(path.read_text(encoding="utf-8")).get("summary", "")
        except Exception:
            return ""

    def set_summary(self, name: str, messages: list[dict], summary: str) -> None:
        self.save(name, messages, summary)

    # ── 私有 ──────────────────────────────────────────────────────

    def _path(self, name: str) -> Path:
        safe = "".join(c for c in name if c.isalnum() or c in "-_") or "default"
        return self.sessions_dir / f"{safe}.json"
