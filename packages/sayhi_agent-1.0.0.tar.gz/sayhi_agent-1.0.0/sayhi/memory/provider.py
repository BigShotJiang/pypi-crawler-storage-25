"""
Panda Ronin — Memory Provider
基于 MEMORY.md 的持久化记忆
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

TOOL_SCHEMAS = [
    {
        "name": "memory_save",
        "description": "保存重要发现、经历或学到的知识到长期记忆",
        "input_schema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "要记住的内容"},
                "category": {
                    "type": "string",
                    "enum": ["discovery", "experience", "knowledge", "todo", "feeling"],
                    "default": "knowledge",
                },
            },
            "required": ["content"],
        },
    },
    {
        "name": "memory_get",
        "description": "检索与当前话题相关的记忆",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        },
    },
]


class BuiltinMemoryProvider:
    tool_schemas = TOOL_SCHEMAS

    def __init__(self, home: Path):
        self.memory_file = home / "MEMORY.md"
        self.user_file = home / "USER.md"
        home.mkdir(parents=True, exist_ok=True)

        if not self.memory_file.exists():
            self.memory_file.write_text(
                "# SayHi 记忆\n\n", encoding="utf-8"
            )
        if not self.user_file.exists():
            self.user_file.write_text(
                "# 人类伙伴\n\n", encoding="utf-8"
            )

    def on_session_start(self, session_id: str, user_id: str):
        pass

    def on_session_end(self, session_id: str):
        pass

    def prefetch(self, context: str, max_tokens: int = 1000) -> str:
        entries = self._load_entries()
        if not entries:
            return ""

        query_words = set(re.findall(r'\w+', context.lower()))
        scored = sorted(
            [(self._score(e, query_words), e) for e in entries],
            reverse=True,
        )
        relevant = [e for s, e in scored if s > 0][:15]

        if not relevant:
            return ""

        return "## 我的记忆碎片\n" + "\n".join(relevant)

    def dispatch_tool(self, name: str, args: dict) -> str | None:
        if name == "memory_save":
            return self._save(args["content"], args.get("category", "knowledge"))
        if name == "memory_get":
            return self._get(args["query"], args.get("limit", 10))
        return None

    def sync(self): pass

    # ── 私有 ─────────────────────────────────────────────────

    def _save(self, content: str, category: str) -> str:
        date = datetime.now().strftime("%Y-%m-%d")
        entry = f"- [{date}][{category}] {content}"
        with open(self.memory_file, "a", encoding="utf-8") as f:
            f.write(entry + "\n")
        return f"✅ 已记住：{content[:60]}"

    def _get(self, query: str, limit: int) -> str:
        entries = self._load_entries()
        words = set(re.findall(r'\w+', query.lower()))
        relevant = sorted(
            [(self._score(e, words), e) for e in entries],
            reverse=True,
        )
        results = [e for s, e in relevant if s > 0][:limit]
        if not results:
            return f"未找到与 '{query}' 相关的记忆"
        return "\n".join(results)

    def _load_entries(self) -> list[str]:
        if not self.memory_file.exists():
            return []
        return [
            l for l in self.memory_file.read_text(encoding="utf-8").splitlines()
            if l.strip().startswith("-")
        ]

    def _score(self, entry: str, query_words: set) -> float:
        entry_words = set(re.findall(r'\w+', entry.lower()))
        if not query_words:
            return 0.0
        return len(entry_words & query_words) / len(query_words)
