"""
Panda Ronin — Entry Point
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path


def _setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )


def cmd_start(args):
    from .config import Config
    from .agent.profile import AgentProfile
    from .agent.session import SessionStore
    from .memory.provider import BuiltinMemoryProvider
    from .tools.registry import create_default_registry
    from .agent.core import PandaRonin
    from .platform.gateway import build_gateway
    from .platform.adapters.cli import CLIAdapter
    from .ui.banner import print_banner, boot_sequence

    config = Config.load(args.config)
    if not config.llm.api_key:
        print("❌ API Key 未配置。运行: panda-ronin onboard")
        sys.exit(1)

    home = Path(config.lifecycle.home_dir).expanduser()

    profile = AgentProfile.load(home)
    if config.panda_name != "SayHi" and profile.name == "SayHi":
        profile.name = config.panda_name
    profile.session_count += 1

    session_store = SessionStore(home)
    memory = BuiltinMemoryProvider(home)
    registry = create_default_registry(home)

    boot_sequence()
    print_banner(profile, model=config.llm.model)

    agent = PandaRonin(
        api_key=config.llm.api_key,
        model=config.llm.model,
        base_url=config.llm.base_url,
        max_tokens=config.llm.max_tokens,
        profile=profile,
        memory=memory,
        registry=registry,
        home=home,
    )

    # 恢复上次会话消息
    agent.messages = session_store.load(profile.current_session)

    gateway = build_gateway(config, agent)
    gateway.start_all()

    import atexit

    def _save_all():
        profile.save(home)
        session_store.save(profile.current_session, agent.messages)

    atexit.register(_save_all)

    cli = next((a for a in gateway._adapters if isinstance(a, CLIAdapter)), None)
    if cli:
        cli._session_store = session_store
        cli.run_repl()
    else:
        print("Running headless. Press Ctrl+C to exit.")
        try:
            import signal
            signal.pause()
        except (AttributeError, KeyboardInterrupt):
            import time
            while True:
                time.sleep(1)

    gateway.stop_all()


def cmd_status(args):
    from .config import Config
    from .agent.profile import AgentProfile
    from .ui.banner import print_banner

    config = Config.load(args.config)
    home = Path(config.lifecycle.home_dir).expanduser()
    profile = AgentProfile.load(home)
    print_banner(profile)


def cmd_score(args):
    from .config import Config
    from .agent.profile import AgentProfile
    from .agent.core import PandaRonin
    from .memory.provider import BuiltinMemoryProvider
    from .tools.registry import create_default_registry

    config = Config.load(args.config)
    if not config.llm.api_key:
        print("❌ API Key 未配置。运行: panda-ronin onboard")
        sys.exit(1)

    home = Path(config.lifecycle.home_dir).expanduser()
    profile = AgentProfile.load(home)

    agent = PandaRonin(
        api_key=config.llm.api_key,
        model=config.llm.model,
        base_url=config.llm.base_url,
        max_tokens=config.llm.max_tokens,
        profile=profile,
        memory=BuiltinMemoryProvider(home),
        registry=create_default_registry(home),
        home=home,
    )

    print("🔍 正在计算多维评分，请稍候…")
    try:
        from .platform.adapters.cli import CLIAdapter
        adapter = CLIAdapter(agent)
        report = agent.run_score()
        adapter._print_score_report(report)
    except Exception as e:
        print(f"❌ 评分失败：{e}")
        raise


def cmd_onboard(args):
    import os

    _print_onboard_banner()

    # ── Step 0: 给 Agent 起名 ─────────────────────────────────────
    _section("Step 0/4", "给你的 AI Agent 起个名字")
    print("  名字会出现在所有对话中。")
    raw_name = _ask("输入名字（直接回车使用 SayHi）").strip()
    panda_name = raw_name or "SayHi"
    print(f"\n  ✓ 名字：{panda_name}")

    # ── 厂商列表 ──────────────────────────────────────────────────
    PROVIDERS = [
        {
            "name": "Ollama (本地运行·完全免费·无需 API Key) ★ 推荐新手",
            "tag": "ollama",
            "models": [
                ("qwen2.5",        "Qwen2.5     — 中文最佳，推荐"),
                ("qwen2.5:14b",    "Qwen2.5 14B — 效果更好"),
                ("llama3.2",       "Llama 3.2"),
                ("deepseek-r1:8b", "DeepSeek-R1 8B — 本地推理"),
            ],
            "key_url":  "https://ollama.com/download",
            "key_hint": None,
        },
        {
            "name": "DeepSeek 🇨🇳",
            "tag": "deepseek",
            "models": [
                ("deepseek-chat",     "DeepSeek-V3  — 性价比极高"),
                ("deepseek-reasoner", "DeepSeek-R1  — 推理模型"),
            ],
            "key_url":  "https://platform.deepseek.com/",
            "key_hint": "sk-...",
        },
        {
            "name": "通义千问 Qwen 🇨🇳",
            "tag": "dashscope",
            "models": [
                ("qwen-max",   "Qwen-Max  — 最强"),
                ("qwen-plus",  "Qwen-Plus — 均衡"),
                ("qwen-turbo", "Qwen-Turbo — 最快"),
            ],
            "key_url":  "https://dashscope.console.aliyun.com/",
            "key_hint": "sk-...",
        },
        {
            "name": "智谱 AI (GLM) 🇨🇳",
            "tag": "zhipuai",
            "models": [
                ("glm-4-plus",  "GLM-4-Plus  — 最强"),
                ("glm-4-flash", "GLM-4-Flash — 免费"),
            ],
            "key_url":  "https://open.bigmodel.cn/",
            "key_hint": "xxx.xxx",
        },
        {
            "name": "Moonshot Kimi 🇨🇳",
            "tag": "moonshot",
            "models": [
                ("moonshot-v1-8k",   "Kimi 8k   — 快速"),
                ("moonshot-v1-128k", "Kimi 128k — 长文本"),
            ],
            "key_url":  "https://platform.moonshot.cn/",
            "key_hint": "sk-...",
        },
        {
            "name": "OpenAI (GPT)",
            "tag": "openai",
            "models": [
                ("gpt-4o",      "GPT-4o       — 旗舰"),
                ("gpt-4o-mini", "GPT-4o-mini  — 便宜"),
            ],
            "key_url":  "https://platform.openai.com/",
            "key_hint": "sk-...",
        },
        {
            "name": "Anthropic (Claude)",
            "tag": "anthropic",
            "models": [
                ("claude-sonnet-4-6", "Claude Sonnet 4.6  — 推荐"),
                ("claude-opus-4-7",   "Claude Opus 4.7   — 最强"),
                ("claude-haiku-4-5",  "Claude Haiku 4.5  — 最快"),
            ],
            "key_url":  "https://console.anthropic.com/",
            "key_hint": "sk-ant-...",
        },
        {
            "name": "Google Gemini",
            "tag": "gemini",
            "models": [
                ("gemini-1.5-pro",   "Gemini 1.5 Pro  — 旗舰"),
                ("gemini-1.5-flash", "Gemini 1.5 Flash — 免费额度大"),
            ],
            "key_url":  "https://aistudio.google.com/",
            "key_hint": "AIza...",
        },
        {
            "name": "Groq (免费，极速)",
            "tag": "groq",
            "models": [
                ("llama-3.1-70b-versatile", "Llama 3.1 70B — 免费"),
                ("mixtral-8x7b-32768",      "Mixtral 8x7B  — 免费"),
            ],
            "key_url":  "https://console.groq.com/",
            "key_hint": "gsk_...",
        },
        {
            "name": "MiniMax 🇨🇳",
            "tag": "openai",
            "models": [
                ("MiniMax-M2.7",  "MiniMax-M2.7  — 推荐"),
                ("MiniMax-M2.5",  "MiniMax-M2.5"),
                ("abab6.5s-chat", "abab6.5s      — 旧版"),
            ],
            "key_url":  "https://platform.minimaxi.com/",
            "key_hint": "eyJ...",
            "base_url": "https://api.minimaxi.com/v1",
        },
        {
            "name": "硅基流动 SiliconFlow 🇨🇳",
            "tag": "openai",
            "models": [
                ("Qwen/Qwen2.5-72B-Instruct",      "Qwen2.5-72B — 免费"),
                ("deepseek-ai/DeepSeek-V3",         "DeepSeek-V3 — 免费"),
                ("meta-llama/Meta-Llama-3.1-70B-Instruct", "Llama 3.1 70B"),
            ],
            "key_url":  "https://cloud.siliconflow.cn/",
            "key_hint": "sk-...",
            "base_url": "https://api.siliconflow.cn/v1",
        },
        {
            "name": "其他（手动输入）",
            "tag": "custom",
            "models": [],
            "key_url":  "https://docs.litellm.ai/docs/providers",
            "key_hint": "...",
        },
    ]

    # ── Step 1: 选择厂商 ──────────────────────────────────────────
    _section("Step 1/4", "选择模型厂商")
    for i, p in enumerate(PROVIDERS, 1):
        print(f"  {i:2d}.  {p['name']}")
    print()

    provider = None
    while provider is None:
        raw = _ask("请输入编号").strip()
        if raw.isdigit() and 1 <= int(raw) <= len(PROVIDERS):
            provider = PROVIDERS[int(raw) - 1]
        else:
            print("     请输入有效编号")

    # ── Step 2: 选择模型 ──────────────────────────────────────────
    _section("Step 2/4", "选择模型")
    model_id = ""

    if provider["tag"] == "custom":
        model_id = _ask("输入完整 model 字符串（如 openai/gpt-4o）").strip()
    elif provider["tag"] == "ollama":
        import urllib.request as _ur
        try:
            _ur.urlopen("http://localhost:11434/api/tags", timeout=2)
            print("  ✓ 检测到 Ollama 正在运行")
        except Exception:
            print("  ⚠️  未检测到 Ollama，请先安装并运行：https://ollama.com/download")
        for i, (mid, desc) in enumerate(provider["models"], 1):
            print(f"  {i}.  {mid:<28} {desc}")
        print(f"  {len(provider['models'])+1}.  手动输入其他模型")
        choice = _ask("请输入编号").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(provider["models"]):
            model_id = provider["models"][int(choice) - 1][0]
        else:
            model_id = _ask("输入 Ollama 模型名（如 qwen2.5:14b）").strip()
    else:
        for i, (mid, desc) in enumerate(provider["models"], 1):
            print(f"  {i}.  {mid:<28} {desc}")
        print(f"  {len(provider['models'])+1}.  手动输入其他模型 ID")
        choice = _ask("请输入编号").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(provider["models"]):
            model_id = provider["models"][int(choice) - 1][0]
        else:
            model_id = _ask("输入模型 ID").strip()

    if provider["tag"] == "custom":
        full_model = model_id
    elif provider["tag"] == "ollama":
        full_model = f"ollama/{model_id}"
    else:
        full_model = f"{provider['tag']}/{model_id}"

    print(f"\n  ✓ 已选择模型：{full_model}")

    # ── Step 3: 输入 API Key ──────────────────────────────────────
    _section("Step 3/4", "API Key")
    api_key = ""

    if provider["tag"] == "ollama":
        print("  Ollama 本地运行，无需 API Key。")
        api_key = "ollama"
    else:
        if provider["key_url"]:
            print(f"  获取 Key：{provider['key_url']}")
        existing = _detect_existing_key(provider["tag"])
        if existing:
            print(f"  ✓ 检测到环境变量中已有 Key：{existing[:16]}...")
            if _ask("直接使用该 Key？[Y/n]").strip().lower() in ("", "y", "yes"):
                api_key = existing
        if not api_key:
            api_key = _ask(f"粘贴你的 API Key（{provider['key_hint'] or '...'}）").strip()
            if not api_key:
                print("  ⚠️  未输入 Key，稍后可在 config.yaml 中填写。")

    # ── Step 4: 写入配置 ─────────────────────────────────────────
    _section("Step 4/4", "写入配置")
    config_path = Path.home() / ".sayhi" / "config.yaml"
    base_url = provider.get("base_url", "")
    _write_config(config_path, full_model, api_key, base_url, panda_name)

    # 同步名字到 profile.json
    profile_path = Path.home() / ".sayhi" / "profile.json"
    if profile_path.exists():
        import json as _json
        try:
            data = _json.loads(profile_path.read_text(encoding="utf-8"))
            data["name"] = panda_name
            profile_path.write_text(_json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    print(f"\n  ✓ 已写入 {config_path}")
    print()
    _print_success(full_model)


# ── onboard 辅助函数 ──────────────────────────────────────────────

def _section(step: str, title: str):
    try:
        from rich.console import Console
        Console().print(f"\n[bold cyan]{step}[/bold cyan]  [bold]{title}[/bold]")
    except ImportError:
        print(f"\n── {step}: {title} " + "─" * 30)


def _ask(prompt: str) -> str:
    try:
        from rich.console import Console
        return Console().input(f"  [bold yellow]❯[/bold yellow] {prompt}：")
    except ImportError:
        return input(f"  ❯ {prompt}：")
    except (KeyboardInterrupt, EOFError):
        print("\n  已取消。")
        sys.exit(0)


def _detect_existing_key(tag: str) -> str:
    import os
    mapping = {
        "anthropic": "ANTHROPIC_API_KEY",
        "openai":    "OPENAI_API_KEY",
        "deepseek":  "DEEPSEEK_API_KEY",
        "dashscope": "DASHSCOPE_API_KEY",
        "zhipuai":   "ZHIPUAI_API_KEY",
        "moonshot":  "MOONSHOT_API_KEY",
        "gemini":    "GEMINI_API_KEY",
        "groq":      "GROQ_API_KEY",
    }
    return os.getenv(mapping.get(tag, ""), "") or os.getenv("LLM_API_KEY", "")


def _write_config(config_path: Path, model: str, api_key: str, base_url: str = "", name: str = "SayHi"):
    config_path.parent.mkdir(parents=True, exist_ok=True)
    content = f"""# SayHi Configuration
# Generated by: sayhi onboard

panda:
  name: "{name}"

llm:
  model: "{model}"
  api_key: "{api_key}"
  base_url: "{base_url}"
  max_tokens: 4096

lifecycle:
  home_dir: "~/.sayhi"

http:
  enabled: true
  host: "0.0.0.0"
  port: 8080
  api_key: ""
"""
    config_path.write_text(content, encoding="utf-8")


def _print_onboard_banner():
    try:
        from rich.console import Console
        from rich.panel import Panel
        Console().print(Panel(
            "[bold cyan]Welcome to SayHi ✠[/bold cyan]\n"
            "[dim]Let's get your AI agent ready.[/dim]",
            border_style="cyan",
        ))
    except ImportError:
        print("\n✠  Welcome to SayHi — Setup Wizard\n")


def _print_success(model: str):
    try:
        from rich.console import Console
        from rich.panel import Panel
        Console().print(Panel(
            f"[bold green]✅  配置完成！[/bold green]\n\n"
            f"模型：[cyan]{model}[/cyan]\n\n"
            f"唤醒你的 Agent：\n\n"
            f"  [bold]sayhi start[/bold]",
            border_style="green",
            padding=(1, 2),
        ))
    except ImportError:
        print(f"✅  配置完成！模型：{model}\n   sayhi start\n")


def cmd_log(args):
    from .config import Config
    config = Config.load(args.config)
    home = Path(config.lifecycle.home_dir).expanduser()
    log_file = home / "activity.log"
    if not log_file.exists():
        print("No activity log found.")
        return
    lines = log_file.read_text(encoding="utf-8").splitlines()
    n = getattr(args, "n", 20)
    try:
        from rich.console import Console
        from rich.panel import Panel
        Console().print(Panel(
            "\n".join(lines[-n:]),
            title="[cyan]📜 Activity Log[/cyan]",
            border_style="cyan",
        ))
    except ImportError:
        for line in lines[-n:]:
            print(line)


def cmd_doctor(args):
    import importlib
    import os

    ok = True

    def check(label: str, passed: bool, hint: str = ""):
        nonlocal ok
        icon = "✓" if passed else "✗"
        color = "\033[32m" if passed else "\033[31m"
        reset = "\033[0m"
        print(f"  {color}{icon}{reset}  {label}")
        if not passed and hint:
            print(f"      → {hint}")
        if not passed:
            ok = False

    print("\n🩺  SayHi — Doctor\n")

    v = sys.version_info
    check(f"Python {v.major}.{v.minor}.{v.micro}", v >= (3, 10), "Python 3.10+ required")

    from .config import Config
    cfg = Config.load(args.config)
    check("API Key configured", bool(cfg.llm.api_key), "Run: sayhi onboard")

    for pkg in ["rich", "yaml"]:
        mod = "pyyaml" if pkg == "yaml" else pkg
        check(f"Package: {mod}", importlib.util.find_spec(pkg) is not None, f"pip install {mod}")

    print()
    for pkg, label in [
        ("requests",          "requests (web fetch)"),
        ("duckduckgo_search", "duckduckgo-search (web search)"),
        ("playwright",        "playwright (browser fetch)"),
        ("markitdown",        "markitdown (PDF/Office reader)"),
        ("fastapi",           "fastapi (HTTP API)"),
        ("uvicorn",           "uvicorn (HTTP API)"),
    ]:
        found = importlib.util.find_spec(pkg) is not None
        print(f"  {'✓' if found else '○'}  {label} {'(installed)' if found else '(optional)'}")

    print()
    if ok:
        print("✅  All checks passed. Run: sayhi start\n")
    else:
        print("⚠️   Some checks failed.\n")


def cmd_update(args):
    import subprocess
    repo = "https://github.com/yourusername/sayhi-agent.git"
    channel = args.channel
    print(f"🔄 Updating sayhi ({channel})...")
    target = f"git+{repo}" if channel == "stable" else f"git+{repo}@{channel}"
    result = subprocess.run(["pipx", "list", "--short"], capture_output=True, text=True)
    use_pipx = "sayhi" in result.stdout
    cmd = ["pipx", "install", "--force", target] if use_pipx else [
        sys.executable, "-m", "pip", "install", "--upgrade", target
    ]
    proc = subprocess.run(cmd)
    if proc.returncode == 0:
        from . import __version__
        print(f"✅  Updated. Version: {__version__}")
    else:
        print(f"❌  Update failed. Try: pip install --upgrade {target}")


# ── CLI wiring ────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="sayhi",
        description="✠ SayHi — A self-directed AI agent that grows through conversation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  sayhi onboard     # First-time setup\n"
            "  sayhi start       # Start chatting\n"
            "  sayhi score       # Run self-assessment\n"
            "  sayhi status      # Check profile\n"
            "  sayhi log         # View activity log\n"
            "  sayhi doctor      # Diagnose problems\n"
        ),
    )
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--verbose", "-v", action="store_true")

    sub = parser.add_subparsers(dest="command")

    p_start = sub.add_parser("start", help="Start SayHi")
    p_start.set_defaults(func=cmd_start)

    p_status = sub.add_parser("status", help="Show profile summary")
    p_status.set_defaults(func=cmd_status)

    p_score = sub.add_parser("score", help="Run multi-dimensional self-assessment")
    p_score.set_defaults(func=cmd_score)

    p_onboard = sub.add_parser("onboard", help="First-time setup wizard")
    p_onboard.set_defaults(func=cmd_onboard)

    p_log = sub.add_parser("log", help="Show recent activity log")
    p_log.add_argument("--n", type=int, default=20)
    p_log.set_defaults(func=cmd_log)

    p_update = sub.add_parser("update", help="Update to latest version")
    p_update.add_argument("--channel", default="stable", choices=["stable", "main", "dev"])
    p_update.set_defaults(func=cmd_update)

    p_doctor = sub.add_parser("doctor", help="Check installation health")
    p_doctor.set_defaults(func=cmd_doctor)

    args = parser.parse_args()
    _setup_logging(args.verbose)

    if args.command is None:
        cmd_start(args)
    else:
        args.func(args)


if __name__ == "__main__":
    main()
