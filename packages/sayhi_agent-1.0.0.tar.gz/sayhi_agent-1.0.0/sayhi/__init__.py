"""SayHi — A self-directed AI agent that grows through conversation."""

__version__ = "1.0.0"
__author__ = "SayHi"
