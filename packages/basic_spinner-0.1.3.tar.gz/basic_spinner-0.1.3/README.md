# Basic Spinner

![PyPI](https://img.shields.io/pypi/v/basic-spinner)
[![Python](https://img.shields.io/pypi/pyversions/basic-spinner)](https://pypi.org/project/basic-spinner/)
[![License](https://img.shields.io/github/license/ThereAreBucketsOnMyHead/basic-spinner)](https://github.com/ThereAreBucketsOnMyHead/basic-spinner/blob/main/LICENSE)

A lightweight terminal spinner for Python

## Installation
```bash
pip install basic-spinner