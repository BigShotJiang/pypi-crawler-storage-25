##################################################
#                                                #
#                    SPINNER                     #
#                                                #
##################################################

import threading
import sys
import itertools
import time

# Main class
# ------------------------------
class Spinner:
    def __init__(self, *, message = "Loading..."):
        self.spinner = itertools.cycle(["|", "/", "-", "\\",]) #Animation frames
        self.running = False
        self.message = message
        self.thread = None

    # Animate spinner
    # ------------------------------
    def spin(self):
        while self.running:
            sys.stdout.write(f"\r{self.message} {next(self.spinner)}")
            sys.stdout.flush()
            time.sleep(0.1)

    # Start spinner animation
    # ------------------------------
    def start(self):
        self.running = True
        self.thread = threading.Thread(target = self.spin)
        self.thread.start()

    # Stop spinner animation
    # ------------------------------
    def stop(self, *, message = "Done!"):
        self.running = False
        self.thread.join()
        sys.stdout.write(f"\r{message}      \n")