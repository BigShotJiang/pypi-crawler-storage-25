from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from breathing_memory.cli import (
    CLIError,
    doctor,
    inspect_memory,
    install_codex_registration,
    main,
    render_agents_block,
    resolve_codex_registration_binding,
    resolve_agents_guidance_mode,
    warmup,
)
from breathing_memory.config import MemoryConfig, TOTAL_CAPACITY_MB_ENV_VAR
from breathing_memory.engine import BreathingMemoryEngine
from breathing_memory.runtime import resolve_db_path


class FakeRunner:
    def __init__(self, responses: list[subprocess.CompletedProcess[str]]):
        self.responses = list(responses)
        self.calls: list[tuple[list[str], dict[str, object]]] = []

    def __call__(self, command: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
        self.calls.append((command, kwargs))
        if not self.responses:
            raise AssertionError("FakeRunner received more calls than expected")
        return self.responses.pop(0)


def registration_stdout(env: dict[str, str] | None) -> str:
    return json.dumps(
        {
            "transport": {
                "type": "stdio",
                "command": "breathing-memory",
                "args": ["serve"],
                "env": env,
                "env_vars": [],
                "cwd": None,
            }
        },
        ensure_ascii=False,
        separators=(",", ":"),
    )


class CodexInstallTests(unittest.TestCase):
    def test_install_codex_registers_expected_command(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            binding = resolve_codex_registration_binding(cwd=Path(tempdir), env={"PATH": "/usr/bin"})
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        1,
                        "",
                        "Error: No MCP server named 'breathing-memory' found.",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "add", "breathing-memory", "--", "breathing-memory", "serve"],
                        0,
                        "",
                        "",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(binding["env"]),
                        "",
                    ),
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                message = install_codex_registration(runner=runner, env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

            self.assertIn("Registered Codex MCP server 'breathing-memory'.", message)
            self.assertIn("Post-check: Codex registration is configured.", message)
            self.assertIn("Created AGENTS.md", message)
            self.assertIn("Next steps:", message)
            self.assertIn("Project identity:", message)
            self.assertIn("DB path:", message)
            self.assertIn("Effective retrieval mode:", message)
            self.assertIn("breathing-memory doctor", message)
            self.assertEqual(
                runner.calls[1][0],
                [
                    "codex",
                    "mcp",
                    "add",
                    "breathing-memory",
                    "--env",
                    f"BREATHING_MEMORY_PROJECT_ID={binding['env']['BREATHING_MEMORY_PROJECT_ID']}",
                    "--",
                    "breathing-memory",
                    "serve",
                ],
            )
            self.assertEqual(
                runner.calls[2][0],
                ["codex", "mcp", "get", "breathing-memory", "--json"],
            )
            self.assertTrue((Path(tempdir) / "AGENTS.md").exists())

    def test_install_codex_repo_scope_uses_repo_as_codex_home(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            binding = resolve_codex_registration_binding(cwd=Path(tempdir), env={"PATH": "/usr/bin"})
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        1,
                        "",
                        "Error: No MCP server named 'breathing-memory' found.",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "add", "breathing-memory", "--", "breathing-memory", "serve"],
                        0,
                        "",
                        "",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(binding["env"]),
                        "",
                    ),
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                message = install_codex_registration(
                    runner=runner,
                    env={"PATH": "/usr/bin", "HOME": "/home/tester"},
                    cwd=Path(tempdir),
                    codex_config="repo",
                )

            self.assertIn("Codex config target: repo", message)
            self.assertEqual(runner.calls[0][1]["env"]["HOME"], tempdir)
            self.assertEqual(runner.calls[1][1]["env"]["HOME"], tempdir)
            self.assertEqual(runner.calls[2][1]["env"]["HOME"], tempdir)
            self.assertTrue((Path(tempdir) / ".codex").exists())

    def test_existing_matching_registration_is_success(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            binding = resolve_codex_registration_binding(cwd=Path(tempdir), env={"PATH": "/usr/bin"})
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(binding["env"]),
                        "",
                    )
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                first = install_codex_registration(runner=runner, env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

            self.assertIn("already configured", first)
            self.assertIn("Created AGENTS.md", first)
            self.assertIn("Next steps:", first)
            self.assertIn("Effective retrieval mode:", first)

            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(binding["env"]),
                        "",
                    )
                ]
            )
            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                second = install_codex_registration(runner=runner, env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

            self.assertIn("already configured", second)
            self.assertIn("AGENTS.md already contains", second)
            self.assertIn("Next steps:", second)
            self.assertEqual(len(runner.calls), 1)

    def test_conflicting_registration_raises_clear_error(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        '{"transport":{"type":"stdio","command":"python","args":["-m","breathing_memory"]}}',
                        "",
                    )
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                with self.assertRaises(CLIError) as context:
                    install_codex_registration(runner=runner, env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

            message = str(context.exception)
            self.assertIn("already exists with a different configuration", message)
            self.assertIn("codex mcp remove breathing-memory", message)

    def test_existing_absolute_path_registration_is_treated_as_matching(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            binding = resolve_codex_registration_binding(cwd=Path(tempdir), env={"PATH": "/usr/bin"})
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        json.dumps(
                            {
                                "transport": {
                                    "type": "stdio",
                                    "command": "/tmp/bin/breathing-memory",
                                    "args": ["serve"],
                                    "env": binding["env"],
                                    "env_vars": [],
                                    "cwd": None,
                                }
                            }
                        ),
                        "",
                    )
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                message = install_codex_registration(runner=runner, env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

            self.assertIn("already configured", message)

    def test_missing_codex_binary_raises_clear_error(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            with patch("breathing_memory.cli.shutil.which", return_value=None):
                with self.assertRaises(CLIError) as context:
                    install_codex_registration(env={"PATH": ""}, cwd=Path(tempdir))

            self.assertIn("Codex CLI was not found on PATH", str(context.exception))

    def test_home_scope_registration_failure_suggests_repo_scope(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        1,
                        "",
                        "Error: No MCP server named 'breathing-memory' found.",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "add", "breathing-memory", "--", "breathing-memory", "serve"],
                        1,
                        "",
                        "failed to persist config.toml",
                    ),
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                with self.assertRaises(CLIError) as context:
                    install_codex_registration(runner=runner, env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

            message = str(context.exception)
            self.assertIn("Failed to register the MCP server with Codex.", message)
            self.assertIn("--codex-config repo", message)

    def test_install_codex_fails_fast_when_default_app_data_root_is_not_writable(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            with patch("breathing_memory.cli.get_app_data_root", return_value=Path("/nonexistent/protected/root")):
                with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                    with self.assertRaises(CLIError) as context:
                        install_codex_registration(env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

            message = str(context.exception)
            self.assertIn("app-data root is not writable", message)
            self.assertIn("BREATHING_MEMORY_DB_PATH", message)

    def test_install_codex_allows_explicit_db_path_when_default_app_data_root_is_not_writable(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            db_path = Path(tempdir) / "custom.sqlite3"
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        1,
                        "",
                        "Error: No MCP server named 'breathing-memory' found.",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "add", "breathing-memory", "--", "breathing-memory", "serve"],
                        0,
                        "",
                        "",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout({"BREATHING_MEMORY_DB_PATH": str(db_path)}),
                        "",
                    ),
                ]
            )

            with patch("breathing_memory.cli.get_app_data_root", return_value=Path("/nonexistent/protected/root")):
                with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                    message = install_codex_registration(
                        runner=runner,
                        env={"PATH": "/usr/bin", "BREATHING_MEMORY_DB_PATH": str(db_path)},
                        cwd=Path(tempdir),
                    )

            self.assertIn("Registered Codex MCP server 'breathing-memory'.", message)

    def test_existing_agents_file_keeps_external_content_and_updates_managed_block(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            agents_path = Path(tempdir) / "AGENTS.md"
            binding = resolve_codex_registration_binding(cwd=Path(tempdir), env={"PATH": "/usr/bin"})
            agents_path.write_text(
                "# AGENTS\n\nKeep this note.\n\n<!-- BEGIN BREATHING MEMORY -->\nold block\n<!-- END BREATHING MEMORY -->\n",
                encoding="utf-8",
            )
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(binding["env"]),
                        "",
                    )
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                message = install_codex_registration(runner=runner, env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

            self.assertIn("Updated AGENTS.md", message)
            updated = agents_path.read_text(encoding="utf-8")
            self.assertIn("Keep this note.", updated)
        self.assertIn('memory_remember(actor="user")', updated)
        self.assertIn("check `memory_recent`", updated)
        self.assertIn("very recent `actor + content` fallback", updated)
        self.assertIn("Keep the query in the user's language and avoid unnecessary translation.", updated)
        self.assertIn('`memory_search` may use `actor="user"` or `actor="agent"`', updated)
        self.assertIn("memory_read_active_collaboration_policy(token_budget=512)", updated)
        self.assertIn('kind="collaboration_policy"', updated)
        self.assertIn("broader conversational context", updated)
        self.assertIn("affect future behavior, choices, or response style", updated)
        self.assertIn("When uncertain, prefer not to save.", updated)
        self.assertIn("may confirm it with the user before relying on it.", updated)
        self.assertIn("record that with `memory_feedback`.", updated)
        self.assertLess(
            updated.index("3. Call `memory_read_active_collaboration_policy(token_budget=512)`"),
            updated.index("4. Search with `memory_search`"),
        )
        self.assertEqual(updated.count("<!-- BEGIN BREATHING MEMORY -->"), 1)

    def test_render_agents_block_uses_super_lite_guidance(self) -> None:
        block = render_agents_block(guidance_mode="super_lite")

        self.assertIn("Choose a query optimized for lexical retrieval.", block)
        self.assertIn("Use keyword- or phrase-oriented queries when they improve lexical retrieval.", block)
        self.assertIn('`memory_search` may use `actor="user"` or `actor="agent"`', block)
        self.assertIn("Use `memory_recent` as the caller-side first check", block)
        self.assertIn("For `user` messages, use caller-side `memory_recent` checks", block)
        self.assertIn("### Collaboration Policy", block)
        self.assertIn("memory_read_active_collaboration_policy(token_budget=512)", block)
        self.assertIn("may confirm it with the user before relying on it.", block)
        self.assertLess(
            block.index("3. Call `memory_read_active_collaboration_policy(token_budget=512)`"),
            block.index("4. Search with `memory_search`"),
        )
        self.assertIn("### Feedback Attribution", block)
        self.assertIn("skip `memory_feedback` rather than guessing.", block)
        self.assertIn(
            "This may be derived either from explicit user feedback or from broader conversational context when the caller judges it likely to be reusable.",
            block,
        )
        self.assertIn(
            "Prefer saving collaboration-policy fragments only when they are likely to affect future behavior, choices, or response style.",
            block,
        )
        self.assertIn(
            "Do not save weak inferences, one-off requests, transient emotions, or ambiguous signals as collaboration policy.",
            block,
        )
        self.assertIn("When uncertain, prefer not to save.", block)
        self.assertNotIn("Choose a query optimized for semantic retrieval.", block)

    def test_install_codex_uses_explicit_project_id_when_provided(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            explicit_env = {"PATH": "/usr/bin", "BREATHING_MEMORY_PROJECT_ID": "shared-memory"}
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        1,
                        "",
                        "Error: No MCP server named 'breathing-memory' found.",
                    ),
                    subprocess.CompletedProcess(
                        [
                            "codex",
                            "mcp",
                            "add",
                            "breathing-memory",
                            "--env",
                            "BREATHING_MEMORY_PROJECT_ID=shared-memory",
                            "--",
                            "breathing-memory",
                            "serve",
                        ],
                        0,
                        "",
                        "",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout({"BREATHING_MEMORY_PROJECT_ID": "shared-memory"}),
                        "",
                    ),
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                install_codex_registration(runner=runner, env=explicit_env, cwd=Path(tempdir))

            self.assertEqual(
                runner.calls[1][0],
                [
                    "codex",
                    "mcp",
                    "add",
                    "breathing-memory",
                    "--env",
                    "BREATHING_MEMORY_PROJECT_ID=shared-memory",
                    "--",
                    "breathing-memory",
                    "serve",
                ],
            )

    def test_install_codex_uses_explicit_db_path_when_provided(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            db_path = Path(tempdir) / "custom.sqlite3"
            explicit_env = {"PATH": "/usr/bin", "BREATHING_MEMORY_DB_PATH": str(db_path)}
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        1,
                        "",
                        "Error: No MCP server named 'breathing-memory' found.",
                    ),
                    subprocess.CompletedProcess(
                        [
                            "codex",
                            "mcp",
                            "add",
                            "breathing-memory",
                            "--env",
                            f"BREATHING_MEMORY_DB_PATH={db_path}",
                            "--",
                            "breathing-memory",
                            "serve",
                        ],
                        0,
                        "",
                        "",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout({"BREATHING_MEMORY_DB_PATH": str(db_path)}),
                        "",
                    ),
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                install_codex_registration(runner=runner, env=explicit_env, cwd=Path(tempdir))

            self.assertEqual(
                runner.calls[1][0],
                [
                    "codex",
                    "mcp",
                    "add",
                    "breathing-memory",
                    "--env",
                    f"BREATHING_MEMORY_DB_PATH={db_path}",
                    "--",
                    "breathing-memory",
                    "serve",
                ],
            )

    def test_install_codex_registers_total_capacity_override(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            binding = resolve_codex_registration_binding(cwd=Path(tempdir), env={"PATH": "/usr/bin"})
            expected_env = dict(binding["env"])
            expected_env[TOTAL_CAPACITY_MB_ENV_VAR] = "0.5"
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        1,
                        "",
                        "Error: No MCP server named 'breathing-memory' found.",
                    ),
                    subprocess.CompletedProcess(
                        [
                            "codex",
                            "mcp",
                            "add",
                            "breathing-memory",
                            "--env",
                            f"BREATHING_MEMORY_PROJECT_ID={binding['env']['BREATHING_MEMORY_PROJECT_ID']}",
                            "--env",
                            f"{TOTAL_CAPACITY_MB_ENV_VAR}=0.5",
                            "--",
                            "breathing-memory",
                            "serve",
                        ],
                        0,
                        "",
                        "",
                    ),
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(expected_env),
                        "",
                    ),
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                message = install_codex_registration(
                    runner=runner,
                    env={"PATH": "/usr/bin"},
                    cwd=Path(tempdir),
                    total_capacity_mb=0.5,
                )

            self.assertEqual(
                runner.calls[1][0],
                [
                    "codex",
                    "mcp",
                    "add",
                    "breathing-memory",
                    "--env",
                    f"BREATHING_MEMORY_PROJECT_ID={binding['env']['BREATHING_MEMORY_PROJECT_ID']}",
                    "--env",
                    f"{TOTAL_CAPACITY_MB_ENV_VAR}=0.5",
                    "--",
                    "breathing-memory",
                    "serve",
                ],
            )
            self.assertIn("Total capacity: 524288 bytes (0.5 MB)", message)

    def test_resolve_agents_guidance_mode_prefers_semantic_when_available_in_auto(self) -> None:
        self.assertEqual(resolve_agents_guidance_mode(retrieval_mode="auto", semantic_available=True), "semantic")
        self.assertEqual(resolve_agents_guidance_mode(retrieval_mode="auto", semantic_available=False), "super_lite")

    def test_install_codex_fails_when_agents_file_is_not_writable(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            agents_path = Path(tempdir) / "AGENTS.md"
            agents_path.write_text("existing", encoding="utf-8")
            agents_path.chmod(0o444)
            try:
                with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                    with self.assertRaises(CLIError) as context:
                        install_codex_registration(env={"PATH": "/usr/bin"}, cwd=Path(tempdir))
            finally:
                agents_path.chmod(0o644)

        self.assertIn("AGENTS.md is not writable", str(context.exception))

    def test_install_codex_fails_on_malformed_managed_block(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            agents_path = Path(tempdir) / "AGENTS.md"
            agents_path.write_text("# AGENTS\n\n<!-- BEGIN BREATHING MEMORY -->\nmissing end\n", encoding="utf-8")

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                with self.assertRaises(CLIError) as context:
                    install_codex_registration(env={"PATH": "/usr/bin"}, cwd=Path(tempdir))

        self.assertIn("management block is malformed", str(context.exception))

    def test_main_prints_install_error_to_stderr(self) -> None:
        stderr = io.StringIO()
        with patch("breathing_memory.cli.install_codex_registration", side_effect=CLIError("broken")):
            with contextlib.redirect_stderr(stderr):
                status = main(["install-codex"])

        self.assertEqual(status, 1)
        self.assertIn("broken", stderr.getvalue())

    def test_warmup_reports_missing_semantic_dependency(self) -> None:
        with patch("breathing_memory.cli.BreathingMemoryEngine.warmup_embeddings", return_value=False):
            message = warmup(env={"PATH": ""}, cwd=Path("/workspace"))

        self.assertIn("Semantic embedding backend is not available", message)

    def test_main_runs_warmup_command(self) -> None:
        stdout = io.StringIO()
        with patch(
            "breathing_memory.cli.BreathingMemoryEngine.warmup_embeddings",
            return_value=True,
        ):
            with contextlib.redirect_stdout(stdout):
                status = main(["warmup"])

        self.assertEqual(status, 0)
        self.assertIn("warmed up", stdout.getvalue())

    def test_inspect_memory_reports_fragment_counts_and_missing_replies(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            db_path = Path(tempdir) / "memory.sqlite3"
            config = MemoryConfig(db_path=db_path)
            engine = BreathingMemoryEngine(config=config)
            try:
                root = engine.remember(content="hello memory", actor="user")
                engine.remember(content="hello back", actor="agent", reply_to=root["anchor_id"])
                engine.remember(content="still waiting", actor="user", reply_to=root["anchor_id"])
                engine.store.delete_fragment(root["id"])
            finally:
                engine.close()

            stdout = io.StringIO()
            env = {
                "BREATHING_MEMORY_DB_PATH": str(db_path),
            }
            with patch.dict("os.environ", env, clear=False):
                with contextlib.redirect_stdout(stdout):
                    status = main(["inspect-memory", "--json"])

            self.assertEqual(status, 0)
            report = json.loads(stdout.getvalue())
            self.assertEqual(report["fragment_count"], 2)
            self.assertEqual(report["active_fragment_count"], 2)
            self.assertGreaterEqual(report["deleted_fragment_count"], 0)
            self.assertEqual(report["root_count"], 0)
            self.assertEqual(report["missing_reply_count"], 2)
            self.assertEqual(report["recent_fragments"][-1]["reply_target"], "missing")

    def test_inspect_memory_uses_codex_registration_environment(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            workspace = Path(tempdir)
            binding = resolve_codex_registration_binding(cwd=workspace, env={"PATH": "/usr/bin"})
            db_path = resolve_db_path(cwd=workspace, env=binding["env"])
            config = MemoryConfig(db_path=db_path)
            engine = BreathingMemoryEngine(config=config)
            try:
                engine.remember(content="hello from codex registration", actor="user")
            finally:
                engine.close()

            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(binding["env"]),
                        "",
                    )
                ]
            )

            with patch("breathing_memory.cli.shutil.which", return_value="/usr/bin/codex"):
                report = json.loads(
                    inspect_memory(
                        json_output=True,
                        runner=runner,
                        env={"PATH": "/usr/bin"},
                        cwd=workspace,
                    )
                )

        self.assertEqual(report["fragment_count"], 1)
        self.assertEqual(report["working_count"], 1)
        self.assertEqual(report["recent_fragments"][-1]["content_length"], len("hello from codex registration".encode("utf-8")))

    def test_doctor_reports_missing_codex_and_db_path(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            db_path = Path(tempdir) / "memory.sqlite3"
            stdout = io.StringIO()
            env = {
                "PATH": "",
                "BREATHING_MEMORY_DB_PATH": str(db_path),
            }
            with patch.dict("os.environ", env, clear=False):
                with contextlib.redirect_stdout(stdout):
                    status = main(["doctor", "--json"])

        self.assertEqual(status, 0)
        report = json.loads(stdout.getvalue())
        self.assertEqual(report["db_path"], str(db_path))
        self.assertEqual(report["db_path_source"], "env_override")
        self.assertFalse(report["db_exists"])
        self.assertEqual(report["codex_registration"]["status"], "codex_not_found")
        self.assertEqual(
            report["next_steps"],
            [
                "Install Breathing Memory so `breathing-memory` is available on PATH.",
                "Install Codex and ensure `codex` is available on PATH.",
            ],
        )

    def test_doctor_reports_total_capacity_env_override(self) -> None:
        report = json.loads(
            doctor(
                json_output=True,
                env={
                    "PATH": "",
                    TOTAL_CAPACITY_MB_ENV_VAR: "0.5",
                },
                cwd=Path("/workspace"),
            )
        )

        self.assertEqual(report["total_capacity_mb"], 0.5)
        self.assertEqual(report["total_capacity"], int(0.5 * (1 << 20)))
        self.assertIn("retrieval", report)
        self.assertEqual(report["retrieval"]["configured_mode"], "auto")
        self.assertIn(report["retrieval"]["effective_mode"], {"super_lite", "lite", "default"})

    def test_doctor_ignores_legacy_total_capacity_env_name(self) -> None:
        report = json.loads(
            doctor(
                json_output=True,
                env={
                    "PATH": "",
                    "BREATHING_MEMORY_TOTAL_CAPACITY": "1234",
                },
                cwd=Path("/workspace"),
            )
        )

        self.assertEqual(report["total_capacity_mb"], MemoryConfig().total_capacity_mb)
        self.assertEqual(report["total_capacity"], int(MemoryConfig().total_capacity_mb * (1 << 20)))

    def test_doctor_reports_matching_codex_registration(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            binding = resolve_codex_registration_binding(cwd=Path(tempdir), env={"PATH": "/usr/bin"})
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(binding["env"]),
                        "",
                    )
                ]
            )

            with patch("breathing_memory.cli.shutil.which", side_effect=lambda name, path=None: "/usr/bin/codex" if name == "codex" else "/usr/bin/breathing-memory"):
                with patch("breathing_memory.cli.semantic_extra_available", return_value=False):
                    report = json.loads(
                        doctor(
                            json_output=True,
                            runner=runner,
                            env={"PATH": "/usr/bin", "HOME": tempdir},
                            cwd=Path(tempdir),
                        )
                    )

        self.assertEqual(report["codex_registration"]["status"], "configured")
        self.assertTrue(report["codex_registration"]["matches_expected"])
        self.assertEqual(report["codex_registration"]["source"], "missing")
        self.assertEqual(report["codex_registration"]["command_source"], "path")
        self.assertEqual(report["diagnostic_context"], "codex_registration")
        self.assertEqual(report["db_path_source"], "codex_registration")
        self.assertEqual(
            report["next_steps"],
            [
                "Codex registration is pinned to a stable project identity.",
                "Open this repository in Codex and start a conversation to create the project DB.",
                "Optional: install `breathing-memory[semantic]` to enable semantic retrieval.",
            ],
        )

    def test_doctor_reports_legacy_unpinned_registration(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        registration_stdout(None),
                        "",
                    )
                ]
            )

            with patch("breathing_memory.cli.shutil.which", side_effect=lambda name, path=None: "/usr/bin/codex" if name == "codex" else "/usr/bin/breathing-memory"):
                with patch("breathing_memory.cli.semantic_extra_available", return_value=False):
                    report = json.loads(
                        doctor(
                            json_output=True,
                            runner=runner,
                            env={"PATH": "/usr/bin"},
                            cwd=Path(tempdir),
                        )
                    )

        self.assertEqual(report["codex_registration"]["status"], "conflict")
        self.assertEqual(report["codex_registration"]["reason"], "legacy_unpinned_registration")
        self.assertEqual(report["diagnostic_context"], "working_directory")
        self.assertTrue(report["warnings"])
        self.assertIn("legacy unpinned format", report["warnings"][0])
        self.assertEqual(
            report["next_steps"][0],
            "Rerun `breathing-memory install-codex` to migrate Codex registration to a stable project identity.",
        )

    def test_doctor_warns_when_container_app_data_is_not_mounted(self) -> None:
        report = json.loads(
            doctor(
                json_output=True,
                env={"PATH": "", "DEVCONTAINER": "1"},
                cwd=Path("/workspace"),
                path_is_mount=lambda path: False,
            )
        )

        self.assertTrue(report["environment"]["is_container"])
        self.assertTrue(report["environment"]["is_devcontainer"])
        self.assertTrue(report["warnings"])
        self.assertIn("Memory may not survive container rebuilds", report["warnings"][0])

    def test_doctor_reports_repo_local_registration_source_and_absolute_path_command(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = Path(tempdir)
            codex_dir = repo / ".codex"
            codex_dir.mkdir()
            (codex_dir / "config.toml").write_text(
                """
[mcp_servers.breathing-memory]
command = "/opt/tools/breathing-memory"
args = ["serve"]
""".strip()
                + "\n",
                encoding="utf-8",
            )
            binding = resolve_codex_registration_binding(cwd=repo, env={"PATH": "/usr/bin"})
            runner = FakeRunner(
                [
                    subprocess.CompletedProcess(
                        ["codex", "mcp", "get", "breathing-memory", "--json"],
                        0,
                        json.dumps(
                            {
                                "transport": {
                                    "type": "stdio",
                                    "command": "/opt/tools/breathing-memory",
                                    "args": ["serve"],
                                    "env": binding["env"],
                                    "env_vars": [],
                                    "cwd": None,
                                }
                            }
                        ),
                        "",
                    )
                ]
            )

            with patch(
                "breathing_memory.cli.shutil.which",
                side_effect=lambda name, path=None: "/usr/bin/codex" if name == "codex" else None,
            ):
                report = json.loads(
                    doctor(
                        json_output=True,
                        runner=runner,
                        env={"PATH": "/usr/bin", "HOME": "/home/tester"},
                        cwd=repo,
                    )
                )

        self.assertEqual(report["codex_registration"]["status"], "configured")
        self.assertEqual(report["codex_registration"]["source"], "repo_local")
        self.assertEqual(report["codex_registration"]["command_source"], "absolute_path")
        self.assertEqual(report["codex_registration"]["config_entries"]["repo_local"], True)
        self.assertEqual(report["codex_registration"]["config_entries"]["home"], False)

    def test_doctor_warns_when_default_app_data_root_is_not_writable(self) -> None:
        with patch("breathing_memory.cli.get_app_data_root", return_value=Path("/nonexistent/protected/root")):
            report = json.loads(
                doctor(
                    json_output=True,
                    env={"PATH": ""},
                    cwd=Path("/workspace"),
                    path_is_mount=lambda path: True,
                )
            )

        self.assertFalse(report["default_app_data_writable"])
        self.assertIn("not writable", report["warnings"][0])

    def test_doctor_reports_default_runtime_when_hnsw_support_is_available_but_not_ready(self) -> None:
        with patch("breathing_memory.cli.semantic_extra_available", return_value=True):
            with patch(
                "breathing_memory.cli.inspect_hnsw_status",
                return_value={
                    "support_available": True,
                    "ready": False,
                    "status": "build_required",
                    "reason": "missing_index_files",
                    "index_path": "/tmp/memory.sqlite3.hnsw.bin",
                    "metadata_path": "/tmp/memory.sqlite3.hnsw.json",
                },
            ):
                report = json.loads(
                    doctor(
                        json_output=True,
                        env={"PATH": ""},
                        cwd=Path("/workspace"),
                    )
                )

        self.assertTrue(report["retrieval"]["semantic_extra_available"])
        self.assertTrue(report["retrieval"]["hnsw_support_available"])
        self.assertFalse(report["retrieval"]["hnsw_index_ready"])
        self.assertEqual(report["retrieval"]["effective_mode"], "default")
        self.assertEqual(report["retrieval"]["resolution_reason"], "auto_with_hnsw_support")
        self.assertEqual(
            report["retrieval"]["embedding_model"],
            MemoryConfig().embedding_model,
        )

    def test_doctor_reports_default_runtime_when_hnsw_is_ready(self) -> None:
        with patch("breathing_memory.cli.semantic_extra_available", return_value=True):
            with patch(
                "breathing_memory.cli.inspect_hnsw_status",
                return_value={
                    "support_available": True,
                    "ready": True,
                    "status": "ready",
                    "reason": "healthy_index",
                    "index_path": "/tmp/memory.sqlite3.hnsw.bin",
                    "metadata_path": "/tmp/memory.sqlite3.hnsw.json",
                },
            ):
                report = json.loads(
                    doctor(
                        json_output=True,
                        env={"PATH": ""},
                        cwd=Path("/workspace"),
                    )
                )

        self.assertTrue(report["retrieval"]["semantic_extra_available"])
        self.assertEqual(report["retrieval"]["effective_mode"], "default")
        self.assertEqual(report["retrieval"]["resolution_reason"], "auto_with_hnsw_ready")
        self.assertEqual(
            report["retrieval"]["embedding_model"],
            MemoryConfig().embedding_model,
        )

    def test_python_module_entrypoint_starts_server(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            env = {
                "PYTHONPATH": "/workspace/public/src",
                "BREATHING_MEMORY_DB_PATH": str(Path(tempdir) / "memory.sqlite3"),
            }
            with patch.dict("os.environ", env, clear=False):
                output = self._round_trip_module_process()

        self.assertEqual(output["initialize_protocol"], output["latest_protocol"])
        self.assertEqual(
            output["tool_names"],
            [
                "memory_remember",
                "memory_search",
                "memory_read_active_collaboration_policy",
                "memory_fetch",
                "memory_recent",
                "memory_feedback",
                "memory_stats",
            ],
        )
        self.assertEqual(output["stats_fragment_count"], 0)

    def _round_trip_module_process(self) -> dict[str, object]:
        script = """
import anyio
import json
import os
import sys

from mcp import types
from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client


async def main():
    server = StdioServerParameters(
        command=sys.executable,
        args=["-m", "breathing_memory"],
        env=dict(os.environ),
    )
    async with stdio_client(server) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            init = await session.initialize()
            tools = await session.list_tools()
            stats = await session.call_tool("memory_stats", {})

            print(
                json.dumps(
                    {
                        "initialize_protocol": init.protocolVersion,
                        "latest_protocol": types.LATEST_PROTOCOL_VERSION,
                        "tool_names": [tool.name for tool in tools.tools],
                        "stats_fragment_count": stats.structuredContent["fragment_count"],
                    }
                )
            )


anyio.run(main)
"""
        completed = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        return dict(__import__("json").loads(completed.stdout))


if __name__ == "__main__":
    unittest.main()
