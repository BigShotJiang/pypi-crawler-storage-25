#!/usr/bin/env python3
"""Kite Server - Reverse tunnel service registry and proxy."""

import argparse
import asyncio
import base64
import json
import time
import uuid

# Use the lenient Python HTTP parser instead of the strict C parser.
# The C parser rejects duplicate headers (e.g. User-Agent added by proxies),
# while the Python parser tolerates them.
from aiohttp.http_parser import HttpRequestParserPy
import aiohttp.web_protocol
aiohttp.web_protocol.HttpRequestParser = HttpRequestParserPy

from aiohttp import web, WSMsgType

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

services: dict[str, dict] = {}          # service_id -> service info
pending: dict[str, asyncio.Future] = {} # request_id -> Future[response_msg]

# ---------------------------------------------------------------------------
# Dashboard HTML (embedded)
# ---------------------------------------------------------------------------

DASHBOARD_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Kite Dashboard</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
         background: #f5f7fa; color: #333; padding: 2rem; }
  h1 { margin-bottom: 1.5rem; font-size: 1.6rem; }
  .empty { color: #999; font-style: italic; }
  table { width: 100%; border-collapse: collapse; background: #fff;
          border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
  th, td { text-align: left; padding: .75rem 1rem; }
  th { background: #4a90d9; color: #fff; font-weight: 600; }
  tr:nth-child(even) { background: #f9fafb; }
  tr:hover { background: #eef3fb; }
  a { color: #4a90d9; text-decoration: none; font-weight: 500; }
  a:hover { text-decoration: underline; }
  .status { display: inline-block; width: 10px; height: 10px; border-radius: 50%;
            background: #4caf50; margin-right: .4rem; vertical-align: middle; }
  .status.offline { background: #ccc; }
  .refresh-note { margin-top: 1rem; font-size: .85rem; color: #999; }
</style>
</head>
<body>
<h1>Kite Dashboard</h1>
<div id="content"><p class="empty">Loading...</p></div>
<p class="refresh-note">Auto-refreshes every 5 seconds</p>
<script>
async function load() {
  try {
    const res = await fetch('/api/services');
    const data = await res.json();
    if (data.length === 0) {
      document.getElementById('content').innerHTML = '<p class="empty">No services registered.</p>';
      return;
    }
    let html = '<table><tr><th></th><th>Name</th><th>Host</th><th>Port</th><th>Registered</th></tr>';
    for (const s of data) {
      const t = new Date(s.registered_at * 1000).toLocaleString();
      html += `<tr>
        <td><span class="status ${s.online ? '' : 'offline'}"></span></td>
        <td><a href="/proxy/${s.id}/" target="_blank">${esc(s.name)}</a></td>
        <td>${esc(s.host)}</td>
        <td>${s.port}</td>
        <td>${t}</td>
      </tr>`;
    }
    html += '</table>';
    document.getElementById('content').innerHTML = html;
  } catch(e) { console.error(e); }
}
function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
load();
setInterval(load, 5000);
</script>
</body>
</html>
"""

# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

async def handle_dashboard(request: web.Request) -> web.Response:
    return web.Response(text=DASHBOARD_HTML, content_type="text/html")


async def handle_api_services(request: web.Request) -> web.Response:
    items = sorted(services.values(), key=lambda s: s["registered_at"], reverse=True)
    out = [
        {
            "id": s["id"],
            "name": s["name"],
            "host": s["host"],
            "port": s["port"],
            "registered_at": s["registered_at"],
            "online": s.get("online", False),
        }
        for s in items
    ]
    return web.json_response(out)


async def handle_ws(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse(heartbeat=20)
    await ws.prepare(request)

    service_id = None

    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                data = json.loads(msg.data)

                if data.get("type") == "register":
                    service_id = str(uuid.uuid4())[:8]
                    services[service_id] = {
                        "id": service_id,
                        "name": data.get("name", "unnamed"),
                        "host": data.get("host", "unknown"),
                        "port": data.get("port", 0),
                        "registered_at": time.time(),
                        "online": True,
                        "ws": ws,
                    }
                    await ws.send_json({"type": "registered", "id": service_id})
                    print(f"[+] Service registered: {services[service_id]['name']} "
                          f"({services[service_id]['host']}:{data.get('port')}) -> {service_id}")

                elif data.get("type") == "response":
                    req_id = data.get("id")
                    fut = pending.pop(req_id, None)
                    if fut and not fut.done():
                        fut.set_result(data)

            elif msg.type in (WSMsgType.ERROR, WSMsgType.CLOSE):
                break
    finally:
        if service_id and service_id in services:
            services[service_id]["online"] = False
            services[service_id].pop("ws", None)
            print(f"[-] Service disconnected: {services[service_id]['name']} ({service_id})")

    return ws


async def handle_proxy(request: web.Request) -> web.Response:
    service_id = request.match_info["service_id"]
    subpath = request.match_info.get("path", "")

    svc = services.get(service_id)
    if not svc:
        return web.Response(status=502, text=f"Service '{service_id}' not found")
    if not svc.get("online") or not svc.get("ws"):
        return web.Response(status=502, text=f"Service '{svc['name']}' is offline")

    # Read request body
    body_bytes = await request.read()
    body_b64 = base64.b64encode(body_bytes).decode() if body_bytes else ""

    # Build headers dict — deduplicate by keeping the first occurrence
    seen_headers: dict[str, str] = {}
    for k, v in request.headers.items():
        lower_k = k.lower()
        if lower_k not in ("host", "connection", "upgrade") and lower_k not in seen_headers:
            seen_headers[lower_k] = v
    headers = seen_headers

    req_id = str(uuid.uuid4())
    msg = {
        "type": "request",
        "id": req_id,
        "method": request.method,
        "path": "/" + subpath,
        "query": request.query_string,
        "headers": headers,
        "body": body_b64,
    }

    fut: asyncio.Future = asyncio.get_running_loop().create_future()
    pending[req_id] = fut

    try:
        ws = svc["ws"]
        await ws.send_json(msg)
    except Exception as e:
        pending.pop(req_id, None)
        svc["online"] = False
        svc.pop("ws", None)
        print(f"[!] WebSocket send failed for {svc['name']} ({service_id}): {e}")
        return web.Response(status=502, text=f"Service '{svc['name']}' connection broken")

    try:
        resp_data = await asyncio.wait_for(fut, timeout=30)
    except asyncio.TimeoutError:
        pending.pop(req_id, None)
        return web.Response(status=504, text=f"Service '{svc['name']}' did not respond within 30s")
    except Exception as e:
        pending.pop(req_id, None)
        return web.Response(status=502, text=f"Proxy error: {e}")

    # Build response
    status = resp_data.get("status", 502)
    resp_headers = resp_data.get("headers", {})
    resp_body = base64.b64decode(resp_data.get("body", "")) if resp_data.get("body") else b""

    # Filter hop-by-hop headers
    skip = {"transfer-encoding", "connection", "keep-alive"}
    filtered = {k: v for k, v in resp_headers.items() if k.lower() not in skip}

    return web.Response(status=status, headers=filtered, body=resp_body)


# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

def create_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/", handle_dashboard)
    app.router.add_get("/api/services", handle_api_services)
    app.router.add_get("/ws", handle_ws)
    app.router.add_route("*", "/proxy/{service_id}/{path:.*}", handle_proxy)
    return app


def main():
    parser = argparse.ArgumentParser(description="Kite Server")
    parser.add_argument("--host", default="0.0.0.0", help="Listen address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8080, help="Listen port (default: 8080)")
    args = parser.parse_args()

    print(f"Kite server starting on {args.host}:{args.port}")
    web.run_app(create_app(), host=args.host, port=args.port)


if __name__ == "__main__":
    main()
