#!/usr/bin/env python3
"""Kite Client - Register a local web service through a Kite server tunnel."""

import argparse
import asyncio
import base64
import json
import platform
import signal
import sys

import aiohttp

# ---------------------------------------------------------------------------
# Tunnel client
# ---------------------------------------------------------------------------

async def run_tunnel(server_url: str, local_port: int, name: str):
    """Connect to Kite server and serve proxy requests."""
    backoff = 1
    max_backoff = 30
    host = platform.node()

    while True:
        try:
            async with aiohttp.ClientSession() as session:
                print(f"Connecting to {server_url} ...")
                async with session.ws_connect(server_url, heartbeat=20) as ws:
                    # Register
                    await ws.send_json({
                        "type": "register",
                        "name": name,
                        "port": local_port,
                        "host": host,
                    })

                    reg = await ws.receive_json()
                    service_id = reg.get("id", "?")
                    print(f"Registered as '{name}' (id={service_id}), tunneling localhost:{local_port}")
                    backoff = 1  # reset on successful connect

                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            data = json.loads(msg.data)
                            if data.get("type") == "request":
                                asyncio.create_task(
                                    handle_request(ws, data, local_port)
                                )
                        elif msg.type in (aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                            break

        except (aiohttp.ClientError, OSError, asyncio.TimeoutError) as e:
            print(f"Connection lost: {e}")

        print(f"Reconnecting in {backoff}s ...")
        await asyncio.sleep(backoff)
        backoff = min(backoff * 2, max_backoff)


async def handle_request(ws, data: dict, local_port: int):
    """Forward a proxied request to the local service and return the response."""
    req_id = data["id"]
    method = data.get("method", "GET")
    path = data.get("path", "/")
    query = data.get("query", "")
    headers = data.get("headers", {})
    body_b64 = data.get("body", "")

    url = f"http://127.0.0.1:{local_port}{path}"
    if query:
        url += f"?{query}"

    body = base64.b64decode(body_b64) if body_b64 else None

    # Remove headers that conflict with aiohttp's auto-generated ones
    skip = {"user-agent", "content-length", "transfer-encoding", "host", "connection"}
    clean_headers = {k: v for k, v in headers.items() if k.lower() not in skip}

    try:
        async with aiohttp.ClientSession() as session:
            async with session.request(
                method, url, headers=clean_headers, data=body, timeout=aiohttp.ClientTimeout(total=25)
            ) as resp:
                resp_body = await resp.read()
                resp_headers = {k: v for k, v in resp.headers.items()
                                if k.lower() not in ("transfer-encoding", "connection", "keep-alive")}

                await ws.send_json({
                    "type": "response",
                    "id": req_id,
                    "status": resp.status,
                    "headers": resp_headers,
                    "body": base64.b64encode(resp_body).decode(),
                })
    except Exception as e:
        print(f"Error proxying request {req_id}: {e}")
        try:
            await ws.send_json({
                "type": "response",
                "id": req_id,
                "status": 502,
                "headers": {"content-type": "text/plain"},
                "body": base64.b64encode(f"Proxy error: {e}".encode()).decode(),
            })
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Kite Client")
    parser.add_argument("--server", required=True, help="Kite server WebSocket URL (e.g. ws://X:8080/ws)")
    parser.add_argument("--port", type=int, required=True, help="Local port to expose")
    parser.add_argument("--name", default="", help="Service name (default: hostname:port)")
    args = parser.parse_args()

    name = args.name or f"{platform.node()}:{args.port}"

    loop = asyncio.new_event_loop()

    def shutdown():
        print("\nShutting down...")
        for task in asyncio.all_tasks(loop):
            task.cancel()

    if sys.platform != "win32":
        loop.add_signal_handler(signal.SIGINT, shutdown)
        loop.add_signal_handler(signal.SIGTERM, shutdown)

    try:
        loop.run_until_complete(run_tunnel(args.server, args.port, name))
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        loop.close()
        print("Bye.")


if __name__ == "__main__":
    main()
