from __future__ import annotations

from abc import ABC, abstractmethod


class CredentialsProvider(ABC):
    """
    Abstract base class for providing Odoo credentials.
    This class defines the interface for retrieving Odoo credentials from various sources.
    Subclasses must implement the `get_credentials` method to provide the required credentials.

    Usage:
        Subclass this class and implement the `get_credentials` method to retrieve credentials
        from a specific source, such as environment variables, AWS Secrets Manager, or a configuration file.
    """

    @abstractmethod
    def get_credentials(self) -> dict[str, str | SecureCredential]:
        """
        Returns a dictionary with Odoo credentials.

        The following keys are mandatory:
        - url: The Odoo server URL
        - db: The Odoo database name
        - username: The Odoo username
        - password: The Odoo password

        Creates a new instance of the CredentialsProvider class and implement the logic
        to gather credentials from the desired source (AWS, secrets managers, etc.)

        You can use the `SecureCredential` class to handle sensitive information securely.
        For example:
        def get_credentials(self) -> Dict[str, str]:
            return {
                'url': 'https://my-odoo-server.com',
                'db': 'my_database',
                'username': 'my_username',
                'password': SecureCredential('my_password')
            }

            This will return '********' when the password is printed, logged, or inspected.
        """
        pass


class EnvFileCredentialsProvider(CredentialsProvider):
    """Default credentials provider that reads from an .env file."""

    def __init__(self) -> None:
        """
        Initialize from fastodoo.settings.py file.
        """
        from .settings import settings

        self.settings = settings

    def get_credentials(self) -> dict[str, str | SecureCredential]:
        return {
            "url": self.settings.ODOO_URL,
            "db": self.settings.ODOO_DB,
            "username": self.settings.ODOO_USERNAME,
            "password": SecureCredential(self.settings.ODOO_PASSWORD),
        }


class SecureCredential:
    """A secure credential that masks its value when inspected."""

    def __init__(self, value: str) -> None:
        self._value = value

    def __repr__(self) -> str:
        return "**********"

    def __str__(self) -> str:
        return "**********"

    @property
    def value(self) -> str:
        return self._value
