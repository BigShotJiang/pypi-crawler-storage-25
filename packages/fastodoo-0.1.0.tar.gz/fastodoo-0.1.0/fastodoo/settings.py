from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    ODOO_URL: str = Field(default=...)
    ODOO_DB: str = Field(default=...)
    ODOO_USERNAME: str = Field(default=...)
    ODOO_PASSWORD: str = Field(default=...)

    model_config = SettingsConfigDict(env_file=".env")


settings = Settings()  # type: ignore[call-arg]
