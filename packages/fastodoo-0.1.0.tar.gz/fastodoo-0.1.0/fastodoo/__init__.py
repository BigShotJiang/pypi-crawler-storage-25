"""FastOdoo - FastAPI integration for Odoo."""

__version__ = "0.1.0"

from .exceptions import InvalidModelNameError, OdooAuthenticationError
from .odoo import Environment, Odoo, RecordSet
from .router import odoo_router

__all__ = [
    "Odoo",
    "Environment",
    "RecordSet",
    "odoo_router",
    "OdooAuthenticationError",
    "InvalidModelNameError",
]
