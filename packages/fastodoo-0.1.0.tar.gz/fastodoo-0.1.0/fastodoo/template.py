"""
Template for FastAPI application with FastOdoo integration.
"""

FASTAPI_TEMPLATE = '''import logging

from fastapi import FastAPI, Depends
from fastodoo.router import odoo_router
from fastodoo.odoo import Environment, Odoo

_logger = logging.getLogger("uvicorn")

app = FastAPI()

# Include FastOdoo CRUD router. Delete next line if you don't need it.
app.include_router(odoo_router, prefix="/odoo", tags=["Odoo CRUD"])

# Initialize Odoo connection
try:
    odoo = Odoo()
    _logger.info(fff"Connected to Odoo version {{odoo.version}} at {{odoo.url}}")
except Exception as e:
    _logger.error(f"{{e}}")

def get_env() -> Environment:
    """Get the Odoo environment."""
    return odoo.env

@app.get("/")
def hello_world():
    """Hello World endpoint."""
    return {{"message": "Hello World! FastOdoo is running."}}

@app.get("/contacts")
def get_contacts(env: Environment = Depends(get_env)):
    """Example endpoint to get the name of the first 5 Odoo contacts."""
    try:
        contacts = env['res.partner'].search([], limit=5).mapped('name')
        return {{"contacts": contacts}}
    except Exception as e:
        return {{"error": str(e), "message": "Make sure your .env file is configured with valid Odoo credentials"}}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port={port})
'''
