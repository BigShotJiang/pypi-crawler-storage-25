class OdooAuthenticationError(Exception):
    """Raised when authentication to Odoo fails."""

    pass


class InvalidModelNameError(Exception):
    """Raised when the model name is invalid or not found in Odoo."""

    pass
