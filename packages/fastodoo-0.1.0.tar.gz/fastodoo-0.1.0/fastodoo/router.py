import ast
import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query

from fastodoo.exceptions import InvalidModelNameError
from fastodoo.odoo import Environment, Odoo

_logger = logging.getLogger("uvicorn")

odoo_router = APIRouter()

# Module-level singleton for Odoo instance
_odoo_instance: Odoo | None = None


def get_odoo() -> Odoo:
    """Get or create Odoo instance."""
    global _odoo_instance
    if _odoo_instance is None:
        _odoo_instance = Odoo()
    return _odoo_instance


def get_odoo_env() -> Environment:
    return get_odoo().env


def validated_model_name(
    model_name: str,
) -> str:
    try:
        return get_odoo().validate_model_name(model_name)
    except InvalidModelNameError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{e}") from e


@odoo_router.get("/info")
def odoo_info():
    return get_odoo()._get_info()


@odoo_router.get("/search_read/{model_name}")
def search_read_records(
    model_name: str = Depends(validated_model_name),
    fields_str: Annotated[str, Query(alias="fields", description="Comma-separated list of fields to read")] = "id",
    domain_str: Annotated[str, Query(alias="domain", description="Domain in Odoo syntax")] = "[]",
    offset: Annotated[int, Query()] = 0,
    limit: Annotated[int, Query()] = 100,
    order: Annotated[str, Query(description="Order in Odoo syntax, e.g. 'id desc'")] = "id",
    env: Environment = Depends(get_odoo_env),
):
    try:
        domain: list[Any] = ast.literal_eval(domain_str)
    except Exception as e:
        _logger.error(f"Invalid formatted domain: {e}")
        domain = []
    try:
        fields_list: list[str] = [field.strip() for field in fields_str.split(",")]
    except Exception as e:
        _logger.error(f"Invalid formatted fields: {e}")
        fields_list = ["id"]
    try:
        records = env[model_name].search_read(
            domain=domain, fields=fields_list, offset=offset, limit=limit, order=order
        )
        return records
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching records: {e}") from e


@odoo_router.get("/browse/{model_name}")
def browse_records(
    ids_str: Annotated[str, Query(alias="ids", description="List of IDs to browse, e.g. 1,2,3")],
    fields_str: Annotated[str, Query(alias="fields", description="Comma-separated list of fields to read")],
    model_name: str = Depends(validated_model_name),
    env: Environment = Depends(get_odoo_env),
):
    try:
        fields_list: list[str] = [field.strip() for field in fields_str.split(",")]
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid fields format") from None

    try:
        ids_list: list[int] = [int(id_val) for id_val in ids_str.split(",")]
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid ids format") from None

    try:
        records = env[model_name].browse(ids_list).read(fields_list)
        return records
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error browsing records: {e}") from e


@odoo_router.delete("/delete/{model_name}")
def delete_records(
    ids_str: Annotated[str, Query(alias="ids", description="List of IDs to delete, e.g. 1,2,3")],
    model_name: str = Depends(validated_model_name),
    env: Environment = Depends(get_odoo_env),
):
    try:
        ids_list: list[int] = [int(id_val) for id_val in ids_str.split(",")]
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid ids format") from None

    try:
        records = env[model_name].browse(ids_list).unlink()
        return records
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting records: {e}") from e


@odoo_router.post("/create/{model_name}")
def create_records(
    values: list[dict[str, Any]],
    model_name: str = Depends(validated_model_name),
    env: Environment = Depends(get_odoo_env),
):
    try:
        record = env[model_name].create(values)
        return record
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating record: {e}") from e


@odoo_router.put("/write/{model_name}")
def write_records(
    ids_str: Annotated[str, Query(alias="ids", description="List of IDs to update, e.g. 1,2,3")],
    values: dict[str, Any],
    model_name: str = Depends(validated_model_name),
    env: Environment = Depends(get_odoo_env),
):
    try:
        ids_list: list[int] = [int(id_val) for id_val in ids_str.split(",")]
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid ids format") from None

    try:
        records = env[model_name].browse(ids_list).write(values)
        return records
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating records: {e}") from e
