import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt

from .template import FASTAPI_TEMPLATE

app = typer.Typer(
    help="FastOdoo CLI - FastAPI integration for Odoo",
    invoke_without_command=True,
)
console = Console()


@app.callback(invoke_without_command=True)
def main_callback(ctx: typer.Context):
    """FastOdoo - FastAPI integration for Odoo ERP systems."""
    if ctx.invoked_subcommand is None:
        console.print()
        console.print(
            Panel.fit(
                "[bold yellow]We are cooking something for Odoo guys[/bold yellow]\n\n"
                "[dim]FastOdoo will provide a FastAPI-based REST interface for Odoo ERP systems.\n"
                "Stay tuned for the full release![/dim]\n\n"
                "[cyan]https://github.com/aidooit/fastodoo[/cyan]",
                title="[bold blue]FastOdoo v0.1.0[/bold blue]",
                border_style="blue",
            )
        )
        console.print()


@app.command()
def init(
    port: int | None = typer.Option(None, "--port", "-p", help="Port for FastAPI server"),
    template: bool | None = typer.Option(None, "--template", "-t", help="Create template file"),
    output: str = typer.Option("main.py", "--output", "-o", help="Output filename"),
    url: str | None = typer.Option(None, "--url", help="Odoo server URL"),
    db: str | None = typer.Option(None, "--db", help="Odoo database name"),
    user: str | None = typer.Option(None, "--user", help="Odoo username"),
    password: str | None = typer.Option(None, "--password", help="Odoo password"),
    auto_start: bool = typer.Option(True, "--auto-start/--no-auto-start", help="Automatically start fastodoo service"),
):
    """
    Initialize a new FastOdoo project or start existing one.

    If main.py exists, starts the fastodoo service. Otherwise, creates a new FastAPI
    application with FastOdoo integration.
    """
    output_path = Path(output)

    if output_path.exists():
        console.print()
        console.print("[bold blue]✅ FastOdoo Application Found[/bold blue]")
        console.print(f"[dim]Found existing {output}.[/dim]")
        console.print()

        if port is None:
            try:
                with open(output_path) as f:
                    content = f.read()
                    import re

                    port_match = re.search(r"port=(\d+)", content)
                    if port_match:
                        port = int(port_match.group(1))
                    else:
                        port = 8000
            except Exception:
                port = 8000

        console.print("[bold]🚀 Starting fastodoo service...[/bold]")
        console.print(f"[dim]Server will be available at http://localhost:{port}[/dim]")
        console.print(f"[dim]API documentation at http://localhost:{port}/docs[/dim]")
        console.print()
        console.print("[yellow]Press Ctrl+C to stop the service[/yellow]")
        console.print()

        try:
            cmd = [
                sys.executable,
                "-m",
                "uvicorn",
                f"{output_path.stem}:app",
                "--host",
                "0.0.0.0",
                "--port",
                str(port),
                "--reload",
            ]
            subprocess.run(cmd, cwd=Path.cwd())
        except KeyboardInterrupt:
            console.print()
            console.print("[yellow]👋 See you next time![/yellow]")
            console.print()
        except Exception as e:
            console.print(f"[bold red]❌ Error starting server: {e}[/bold red]")
            console.print()
            console.print("[bold]Manual startup:[/bold]")
            console.print(f"   [cyan]python {output}[/cyan]")
            console.print("   [dim]or[/dim]")
            console.print(f"   [cyan]uvicorn {output_path.stem}:app --host 0.0.0.0 --port {port} --reload[/cyan]")
        return

    # Original initialization logic when main.py doesn't exist
    console.print()
    console.print("[bold blue]🚀 FastOdoo Project Initialization[/bold blue]")
    console.print()

    # Determine if we're in non-interactive mode (all required params provided)
    non_interactive = all([url, db, user is not None, password is not None])

    # Get port with default
    if port is None:
        if non_interactive:
            port = 8000
        else:
            port_input = Prompt.ask("Enter default port for FastAPI", default="8000", show_default=True)
            try:
                port = int(port_input)
            except ValueError:
                console.print("[bold red]❌ Invalid port number. Using default: 8000[/bold red]")
                port = 8000

    # Collect Odoo environment variables
    if non_interactive:
        odoo_url = url
        odoo_db = db
        odoo_username = user
        odoo_password = password
        console.print("[dim]Using non-interactive mode with provided credentials[/dim]")
        console.print("[dim]URL: {odoo_url}, DB: {odoo_db}, User: {odoo_username}[/dim]")
    else:
        console.print()
        console.print("[bold]📋 Odoo Configuration[/bold]")

        odoo_url = url or Prompt.ask("Odoo URL", default="http://localhost:8069", show_default=True)
        odoo_db = db or Prompt.ask("Odoo Database name")
        odoo_username = user or Prompt.ask("Odoo Username", default="admin", show_default=True)
        console.print(
            "[dim] From Odoo 16 onwards, it is possible (and recommended) to use an API Key as password.[/dim]"
        )
        console.print(
            "[dim] This way you can avoid using your actual user password. Also, you can easily revoke [/dim]"
        )
        console.print("[dim] access by deleting the API Key. If you don't know how to generate it see:[/dim]")
        console.print("[dim] https://www.odoo.com/documentation/16.0/developer/reference/external_api.html [/dim]")
        odoo_password = password or Prompt.ask(
            "Odoo Password or API Key", default="admin", password=True, show_default=True
        )
    console.print()

    # Ask about template creation
    if template is None:
        if non_interactive:
            template = True
        else:
            template = Confirm.ask("Create template FastAPI application?", default=True)

    if template:
        # Create the main.py file
        output_path = Path(output)
        if output_path.exists():
            overwrite = Confirm.ask(f"File {output} already exists. Overwrite?", default=False)
            if not overwrite:
                console.print("[yellow]⚠️ Operation cancelled.[/yellow]")
                return
        # Generate the template content with the specified port
        template_content = FASTAPI_TEMPLATE.format(port=port)
        try:
            # Create the main.py file
            with open(output_path, "w") as f:
                f.write(template_content)

            console.print(f"[bold green]✅ Successfully created {output}[/bold green]")
            # Create .env file
            env_content = f"""ODOO_URL={odoo_url}
ODOO_DB={odoo_db}
ODOO_USERNAME={odoo_username}
ODOO_PASSWORD={odoo_password}
"""
            env_path = Path(".env")
            if env_path.exists():
                overwrite_env = Confirm.ask(".env file already exists. Overwrite?", default=False)
                if not overwrite_env:
                    console.print("[yellow]⚠️  .env file not updated.[/yellow]")
                else:
                    with open(env_path, "w") as f:
                        f.write(env_content)
                    console.print("[bold green]✅ Successfully created .env file[/bold green]")
            else:
                with open(env_path, "w") as f:
                    f.write(env_content)
                console.print("[bold green]✅ Successfully created .env file[/bold green]")

            # Ask if user wants to start the fastodoo service
            if non_interactive:
                start_server = auto_start
            else:
                start_server = Confirm.ask("Start the fastodoo service now?", default=auto_start)

            if start_server:
                console.print()
                console.print("[bold]🚀 Starting fastodoo service...[/bold]")
                console.print(f"[dim]Server will be available at http://localhost:{port}[/dim]")
                console.print(f"[dim]API documentation at http://localhost:{port}/docs[/dim]")
                console.print()
                console.print("[yellow]Press Ctrl+C to stop the server[/yellow]")
                console.print()

                try:
                    # Start the server using uvicorn
                    cmd = [
                        sys.executable,
                        "-m",
                        "uvicorn",
                        f"{output_path.stem}:app",
                        "--host",
                        "0.0.0.0",
                        "--port",
                        str(port),
                        "--reload",
                    ]
                    subprocess.run(cmd, cwd=Path.cwd())
                except KeyboardInterrupt:
                    console.print()
                    console.print("[yellow]👋 See you next time![/yellow]")
                    console.print()
                except Exception as e:
                    console.print(f"[bold red]❌ Error starting server: {e}[/bold red]")
                    console.print()
                    console.print("[bold]Manual startup:[/bold]")
                    console.print(f"   [cyan]python {output}[/cyan]")
                    console.print("   [dim]or[/dim]")
                    console.print(
                        f"   [cyan]uvicorn {output_path.stem}:app --host 0.0.0.0 --port {port} --reload[/cyan]"
                    )
            else:
                console.print()
                console.print("[bold]✅ Setup complete![/bold]")
                console.print()
                console.print("[bold]To start your fastodoo service:[/bold]")
                console.print("   [cyan]fastodoo init[/cyan]")
                console.print()
                console.print("[yellow]👋 See you next time![/yellow]")
                console.print()
        except Exception as e:
            console.print(f"[bold red]❌ Error creating files: {e}[/bold red]")
            return
    else:
        # Even if template is skipped, create the .env file
        try:
            env_content = f"""ODOO_URL={odoo_url}
ODOO_DB={odoo_db}
ODOO_USERNAME={odoo_username}
ODOO_PASSWORD={odoo_password}
"""
            env_path = Path(".env")
            if env_path.exists():
                overwrite_env = Confirm.ask(".env file already exists. Overwrite?", default=False)
                if not overwrite_env:
                    console.print("[yellow]⚠️  .env file not updated.[/yellow]")
                else:
                    with open(env_path, "w") as f:
                        f.write(env_content)
                    console.print("[bold green]✅ Successfully created .env file[/bold green]")
            else:
                with open(env_path, "w") as f:
                    f.write(env_content)
                console.print("[bold green]✅ Successfully created .env file[/bold green]")
        except Exception as e:
            console.print(f"[bold red]❌ Error creating .env file: {e}[/bold red]")

        console.print("[yellow]⚠️  Template creation skipped.[/yellow]")
        console.print()
        console.print("[bold]Manual setup:[/bold]")
        console.print("Create your FastAPI application manually and use:")
        console.print("[cyan]from fastodoo.router import odoo_router[/cyan]")
        console.print("[cyan]from fastodoo.odoo import Odoo, Environment[/cyan]")
        console.print()
        console.print(f"Remember to configure your server to run on port {port}")


@app.command()
def version():
    """Show FastOdoo version."""
    try:
        from importlib.metadata import version

        fastodoo_version = version("fastodoo")
        console.print(f"[bold blue]FastOdoo version: {fastodoo_version}[/bold blue]")
    except Exception:
        console.print("[bold blue]FastOdoo version: development[/bold blue]")


def main():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
