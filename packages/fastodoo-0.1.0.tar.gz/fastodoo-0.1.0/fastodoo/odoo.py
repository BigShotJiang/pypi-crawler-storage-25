from __future__ import annotations

import logging
import xmlrpc.client
from collections.abc import Callable, Iterator
from typing import Any, Literal, cast, overload

import requests

from .api import ApiMixin, OdooJSONRPCMixin
from .auth import CredentialsProvider, EnvFileCredentialsProvider, SecureCredential
from .exceptions import InvalidModelNameError, OdooAuthenticationError


class Odoo:
    def __init__(
        self,
        credentials_provider: CredentialsProvider | None = None,
    ) -> None:
        """Initialize the Odoo client with credentials and SSL settings.

        To use credentials from other places rather than .env file proceed as follow:

        1. Define a custom class that inherits from CredentialsProvider.
            >> auth.py file

            class MyCustomProvider(CredentialsProvider):
                def get_credentials(self) -> Dict[str, str]:
                    # Logic to get credentials from any source: AWS, secret manager, etc.
                    # ...
                    return {
                        'url': 'my_odoo_url',
                        'db': 'my_database',
                        'username': 'my_username',
                        'password': 'my_password'
                    }

        2. Use it when creating the Odoo instance:

            from fastodoo.odoo import Odoo
            from .auth import MyCustomProvider
            odoo = Odoo(credentials_provider=MyCustomProvider())

        3. Keys `url`, `db`, `username`, and `password` are mandatory in the dictionary
            returned by the `get_credentials` method.

        Args:
            version (int): Odoo version (e.g., 14, 15, 16, 17, 18).
            credentials_provider (Optional[CredentialsProvider], optional): see class `CredentialsProvider`
                for more details. Defaults to None (will read from .env file).
            verify_ssl (bool, optional): Whether to verify SSL certificates. Defaults to True. Make it False
                only for testing purposes.
        """
        if credentials_provider is None:
            credentials_provider = EnvFileCredentialsProvider()
        credentials = credentials_provider.get_credentials()
        self.validate_credentials(credentials)

        self.url = credentials["url"]
        self.db = credentials["db"]
        self.username = credentials["username"]
        self.version = self.get_odoo_version()

        # Handle password securely - ensure it's a SecureCredential
        if isinstance(credentials["password"], SecureCredential):
            self._password = credentials["password"]
        else:
            self._password = SecureCredential(credentials["password"])

        self.uid = None
        self.authenticate()

    def get_odoo_version(self) -> int:
        version: int | None = None
        try:
            # assume always version 19.0 or higher, calling the public endpoint /web/version
            response = requests.get(f"{self.url}/web/version")
            if response.status_code != 200:
                raise ValueError(f"Failed to get version from {self.url}/web/version")
            version_info = response.json()["version_info"]
            version = int(version_info[0])
        except Exception:
            # fallback to xmlrpc for older versions or any error.
            common = xmlrpc.client.ServerProxy(f"{self.url}/xmlrpc/2/common")
            version_result = cast(dict[str, Any], common.version())
            version = int(version_result["server_version_info"][0])
        if not version:
            raise ValueError("Could not determine Odoo version from the server.")
        return version

    def validate_credentials(self, credentials: dict[str, str | SecureCredential]) -> None:
        for key in ["url", "db", "username", "password"]:
            if key not in credentials:
                raise ValueError(f"Missing required credential: {key}")

    def authenticate(self) -> None:
        try:
            api = ApiMixin(self)
            password = self._get_actual_password()
            uid = api.call("authenticate", self.db, self.username, password)
            if not uid:
                raise OdooAuthenticationError("Check credentials.")
            self.uid = uid
        except ConnectionError as e:
            raise OdooAuthenticationError(f"Connection error: {str(e)}") from e
        except Exception as e:
            raise OdooAuthenticationError(f"Authentication error: {str(e)}") from e

    @property
    def env(self) -> Environment:
        """Return an Environment instance to allow ORM-style access."""
        if not hasattr(self, "_env"):
            self._env = Environment(self)
        return self._env

    @property
    def password(self) -> str:
        """Return masked password."""
        return str(self._password)

    def _get_actual_password(self) -> str:
        """Access the actual password value (for internal use only)."""
        return self._password.value

    def _get_info(self) -> dict:
        return {"implement": "me :D"}

    def validate_model_name(self, model_name: str) -> str:
        """Validate the model name against the Odoo server."""
        try:
            # TODO: implement me please :D
            models = False
            if not models:
                raise InvalidModelNameError(f"Model '{model_name}' does not exist.")
        except Exception as e:
            raise ValueError(f"Error validating model name: {str(e)}") from e

        return model_name


class RecordSet(ApiMixin):
    """Class representing a set of records from an Odoo model."""

    def __init__(self, odoo_instance, model_name, ids=None, context=None) -> None:
        super().__init__(odoo_instance)
        self.model_name = model_name
        self._odoo = odoo_instance
        self.ids = ids if ids is not None else []
        if not isinstance(self.ids, list):
            self.ids = [self.ids] if self.ids else []
        self._context = context or {}

    def __str__(self) -> str:
        if len(self.ids) == 1:
            return f"{self.model_name}({self.ids[0]})"
        return f"{self.model_name}{tuple(self.ids)}"

    def __repr__(self) -> str:
        if not self.ids:
            return f"{self.model_name}()"
        elif len(self.ids) == 1:
            return f"{self.model_name}({self.ids[0]})"
        else:
            return f"{self.model_name}{tuple(self.ids)}"

    def __iter__(self) -> Iterator[RecordSet]:
        for id_ in self.ids:
            yield self.browse(id_)

    def __getattr__(self, name: str) -> Any:
        if not self.ids:
            _logger = logging.getLogger("uvicorn")
            _logger.warning(
                f"Accessing field '{name}' on empty recordset {self.model_name}(). "
                "All fields return False for empty recordsets."
            )
            return False

        # For single records, check if it's a field first, then try to read it
        if len(self.ids) == 1:
            try:
                # Check if it's a valid field first
                fields_info = self.fields_get()
                if name in fields_info:
                    # It's a field, try to read it
                    result = self.read([name])
                    if result and name in result[0]:
                        result = self._parse_read_result(name, result[0][name])
                        return result
            except Exception:
                # If anything fails, fall back to method call
                pass

        # If not a field, or we have multiple records, return a method callable
        return self._create_method_callable(name)

    def _create_method_callable(self, method_name: str):
        """Create a callable wrapper for Odoo method execution."""

        # TODO: investigate why some read and fields_get are done when calling action_confirm
        def method_wrapper(*args, **kwargs):
            if not self.ids:
                return None

            # Use the models service to execute the method
            try:
                # TODO: self.service does not exist anymore. We have to remove this method
                if self.service == "jsonrpc":
                    return self._execute_jsonrpc_method(method_name, *args, **kwargs)
            except Exception as e:
                raise ValueError(f"Error executing method '{method_name}': {str(e)}") from e

        return method_wrapper

    def _check_recordset_params(self, method_name: str, args: tuple, kwargs: dict):
        """Check if any parameters are RecordSet objects and raise helpful error."""
        # Check positional arguments
        # TODO: check this method. Was done to avoid passing recordset as params
        for i, arg in enumerate(args):
            if isinstance(arg, RecordSet):
                raise ValueError(
                    f"Cannot pass RecordSet as parameter to method '{method_name}'. "
                    f"Positional argument {i} is a RecordSet ({arg}). "
                    f"Pass record IDs instead: {arg.ids}"
                )

        # Check keyword arguments
        for key, value in kwargs.items():
            if isinstance(value, RecordSet):
                raise ValueError(
                    f"Cannot pass RecordSet as parameter to method '{method_name}'. "
                    f"Keyword argument '{key}' is a RecordSet ({value}). "
                    f"Pass record IDs instead: {value.ids}"
                )

    def _execute_jsonrpc_method(self, method_name: str, *args, **kwargs):
        """Execute method using JSONRPC."""
        # TODO: shouldn't I make this decision in the general APIMixing?
        # like call_method and there we decide which service to use?
        self._check_recordset_params(method_name, args, kwargs)

        if self._context:
            if "context" in kwargs:
                merged_context = self._context.copy()
                merged_context.update(kwargs["context"])
                kwargs["context"] = merged_context
            else:
                kwargs["context"] = self._context

        params = {
            "service": "object",
            "method": "execute_kw",
            "args": [
                self.odoo.db,
                self.odoo.uid,
                self.odoo._get_actual_password(),
                self.model_name,
                method_name,
                [self.ids] + list(args),
                kwargs,
            ],
        }
        # TODO: we should make the decision not here right? I mean, we are forcen to use OdooJSONRPCMixin
        api_mixin = OdooJSONRPCMixin(self.odoo)
        # TODO: fixed url should not be like this. we have self.api_url for that reason
        return api_mixin.json_rpc(self.odoo.url + "/jsonrpc", "call", params)

    def _parse_read_result(self, field_name: str, read_value: Any) -> Any:
        # TODO: revisit this. Its working but we might want to use some cache to store fields_info
        if not self.ids:
            return None
        fields_info = self.fields_get()
        if field_name not in fields_info:
            raise AttributeError(f"Field '{field_name}' does not exist in model '{self.model_name}'")
        field_type = fields_info[field_name].get("type")
        relation_model = fields_info[field_name].get("relation", False)
        if relation_model:
            env = self.odoo.env
            if field_type == "many2one" and isinstance(read_value, list):
                return env[relation_model].browse(read_value[0])
            elif field_type in ("many2many", "one2many") and isinstance(read_value, list):
                return env[relation_model].browse(read_value)
        return read_value

    def __len__(self):
        return len(self.ids)

    def __bool__(self):
        """Return True if recordset has any records."""
        return bool(self.ids)

    @property
    def id(self):
        """Return the ID of a single record."""
        if len(self.ids) == 1:
            return self.ids[0]
        elif len(self.ids) == 0:
            _logger = logging.getLogger("uvicorn")
            _logger.warning(
                f"Accessing 'id' on empty recordset {self.model_name}(). All fields return False for empty recordsets."
            )
            return False
        else:
            raise ValueError("Cannot get 'id' property from recordset with multiple records")

    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith("_") or name in ("model_name", "ids", "odoo", "api_version"):
            super().__setattr__(name, value)
            return

        # For field assignments, use write method
        # Check if object is initialized and has ids
        if hasattr(self, "ids") and hasattr(self, "model_name") and self.ids:
            self.write({name: value})
        else:
            # If no ids yet (during initialization), set normally
            super().__setattr__(name, value)

    def __getitem__(self, key: Any) -> RecordSet:
        """Make RecordSet subscriptable with index notation (recordset[0]).

        Args:
            key: An index (integer) or slice

        Returns:
            RecordSet: A new recordset containing the selected record(s)
        """
        if isinstance(key, int):
            # Handle negative indices
            if key < 0:
                key = len(self.ids) + key

            # Check if index is in range
            if key < 0 or key >= len(self.ids):
                raise IndexError("RecordSet index out of range")

            # Return a new recordset with just the selected ID
            return RecordSet(self._odoo, self.model_name, [self.ids[key]], self._context)

        elif isinstance(key, slice):
            # Handle slices like record_set[1:5]
            sliced_ids = self.ids[key]
            return RecordSet(self._odoo, self.model_name, sliced_ids, self._context)

        else:
            raise TypeError(f"RecordSet indices must be integers or slices, not {type(key).__name__}")

    def browse(self, ids) -> RecordSet:
        """Create a new RecordSet with the given ids, validating they exist in the database."""
        if not isinstance(ids, list):
            ids = [ids] if ids else []

        # If no ids provided, return empty recordset
        if not ids:
            return RecordSet(self._odoo, self.model_name, [], self._context)

        # Validate which IDs actually exist in the database
        existing_ids = self.call("search", self.model_name, [("id", "in", ids)])

        return RecordSet(self._odoo, self.model_name, existing_ids, self._context)

    @overload
    def create(
        self, vals: dict[str, Any] | list[dict[str, Any]], return_recordset: Literal[False] = ...
    ) -> list[int]: ...

    @overload
    def create(
        self, vals: dict[str, Any] | list[dict[str, Any]], return_recordset: Literal[True] = ...
    ) -> RecordSet: ...

    def create(
        self, vals: dict[str, Any] | list[dict[str, Any]], return_recordset: bool = False
    ) -> list[int] | RecordSet:
        """Create a new record and return its ID."""
        vals_list: list[dict[str, Any]] = [vals] if isinstance(vals, dict) else vals
        new_ids: list[int] = self.call("create", self.model_name, vals_list)
        if new_ids:
            self.ids.extend(new_ids)
        if return_recordset:
            return self.browse(new_ids)
        return new_ids

    def read(self, fields: list[str] | None = None) -> list[dict[str, Any]]:
        if not self.ids:
            return []
        fields = fields or []
        # Use api.call() to invoke the read method
        result = self.call("read", self.model_name, self.ids, fields)
        return result

    def write(self, vals: dict[str, Any]) -> bool:
        if not self.ids:
            return False
        result = self.call("write", self.model_name, self.ids, vals)
        return result

    def unlink(self) -> bool:
        if not self.ids:
            return False
        result = self.call("unlink", self.model_name, self.ids)
        return result

    def search(
        self, domain: list[Any] | None = None, offset: int = 0, limit: int | None = None, order: str | None = None
    ) -> RecordSet:
        """Search records using the ApiMixin."""
        domain = domain or []
        # Use api.call() to invoke the search method
        result_ids = self.call("search", self.model_name, domain, offset, limit, order)
        return RecordSet(self._odoo, self.model_name, result_ids, self._context)

    def search_read(
        self,
        domain: list[Any] | None = None,
        fields: list[str] | None = None,
        offset: int = 0,
        limit: int | None = None,
        order: str | None = None,
    ):
        domain = domain or []
        fields = fields or []
        result = self.call("search_read", self.model_name, domain, fields, offset, limit, order)
        return result

    def search_count(self, domain: list[Any] | None = None) -> int:
        domain = domain or []
        result = self.call("search_count", self.model_name, domain)
        return result

    def _union(self, args: Any) -> Any:
        """Create a unified recordset from various inputs."""
        if hasattr(args, "union"):
            return args.union()
        if args and isinstance(args, list) and hasattr(args[0], "union"):
            return self.union(*args)
        return args

    def union(self, *args) -> RecordSet:
        """Return the union of all records, preserving first occurrence order."""
        ids = self.ids.copy()
        for other in args:
            if isinstance(other, RecordSet) and other.model_name == self.model_name:
                ids.extend(other.ids)

        if len(ids) > 1:
            seen = set()
            uniqids = []
            for id_ in ids:
                if id_ not in seen and not seen.add(id_):
                    uniqids.append(id_)
            ids = uniqids

        return RecordSet(self._odoo, self.model_name, ids, self._context)

    def fields_get(
        self, allfields: list[str] | None = None, attributes: list[str] | None = None
    ) -> dict[str, dict[str, Any]]:
        result = self.call("fields_get", self.model_name, allfields, attributes)
        return result

    def mapped(self, field_path: str | Callable[[RecordSet], Any]) -> Any:
        """Map records by the given field or function.

        Args:
            field_path: The field to extract or a function to apply
                       (dot notation supported for related fields)

        Returns:
            Various: Values of the specified field or RecordSet for relational fields
        """
        # TODO: revisit this implementation
        # Handle empty recordsets
        if not self.ids:
            return [] if isinstance(field_path, str) else self._union([])

        if not isinstance(field_path, str):
            # For callable functions, apply to each record
            return self._union([field_path(self.browse(id_)) for id_ in self.ids])

        # Split the field path for dot notation
        parts = field_path.split(".")

        # Get the first field
        first_field = parts[0]

        # For simple field access (no dot notation), just read and return values
        if len(parts) == 1:
            records = self.read([first_field])
            # TODO: revisit this logic, avoid repeat code
            # check if records should be records instead of normal values
            fields_info = self.fields_get()
            if first_field not in fields_info:
                raise AttributeError(f"Field '{first_field}' does not exist in model '{self.model_name}'")
            relation_model = fields_info[first_field].get("relation", False)
            if relation_model:
                ids = list({rec[first_field][0] for rec in records})
                return RecordSet(self._odoo, relation_model, ids, self._context)
            return [record.get(first_field) for record in records]

        # For complex field paths (dot notation), we need field metadata
        # TODO: revisit this here, to avoid duplicate code
        fields_metadata = self.fields_get()

        # Check if we have field metadata
        if not fields_metadata:
            # If fields_get failed, just fetch the field directly
            records = self.read([first_field])
            return [record.get(first_field) for record in records]

        field_info = fields_metadata.get(first_field, {})
        is_relational = field_info.get("type") in ("many2one", "one2many", "many2many")
        relation_model = field_info.get("relation")

        # Read the records
        records = self.read([first_field])

        # Extract values for the first field
        values = [record.get(first_field) for record in records]

        # Handle relational fields for dot notation
        if is_relational and relation_model:
            if field_info.get("type") == "many2one":
                # many2one fields return [id, name] tuples
                relation_ids = list({value[0] for value in values if value})
            else:
                # one2many and many2many fields return lists of IDs
                relation_ids = list({id_ for ids in values if ids for id_ in ids})

            # Continue with the rest of the path
            relation_records = RecordSet(self._odoo, relation_model, relation_ids)

            return relation_records.mapped(".".join(parts[1:]))

        # If we have more parts but can't proceed (not a relation), just return values
        return values

    def with_context(self, context_dict=None, **kwargs) -> RecordSet:
        """Return a new RecordSet with updated context.

        Args:
            context_dict (dict, optional): Context dictionary to merge
            **kwargs: Context values as keyword arguments

        Returns:
            RecordSet: New RecordSet with merged context

        Usage:
            record.with_context({'key': 'value', 'key2': 'value2'})
            record.with_context(key='value', key2='value2')
        """
        # Start with current context
        new_context = self._context.copy()

        # Merge context_dict if provided
        if context_dict:
            if not isinstance(context_dict, dict):
                raise ValueError("context_dict must be a dictionary")
            new_context.update(context_dict)

        # Merge kwargs
        new_context.update(kwargs)

        # Return new RecordSet with merged context
        return RecordSet(self._odoo, self.model_name, self.ids.copy(), new_context)

    def filtered(self, func):
        """Filter records that satisfy the function.

        Args:
            func: Callable that takes a record and returns a boolean

        Returns:
            RecordSet: A new recordset containing only matching records
        """
        # TODO: re-visit this method :|
        if not callable(func):
            raise ValueError("filtered() expects a callable function")

        # Empty recordset case
        if not self.ids:
            return RecordSet(self._odoo, self.model_name, [])

        # Create single-record RecordSets for each ID
        single_records = [self.browse(id_) for id_ in self.ids]  # TODO: can i do self.browse(self.ids) right?

        # Apply function to each record and collect those that match
        # matching_records = [record for record in single_records if func(record)]
        matching_records = []
        for rec in single_records:
            func(rec)
            matching_records.append(rec)
        matching_ids = [record.ids[0] for record in matching_records]

        # Return a new recordset with only the matching IDs
        return RecordSet(self._odoo, self.model_name, matching_ids, self._context)


class Environment:
    """Class representing an Odoo environment, similar to Odoo's env."""

    def __init__(self, odoo: Odoo) -> None:
        self.odoo = odoo

    def __getitem__(self, model_name: str) -> RecordSet:
        """Allow accessing models with env['model.name'] syntax."""
        return RecordSet(self.odoo, model_name)
