import logging
import random
from typing import Any

import requests

_logger = logging.getLogger("uvicorn")
_logger.setLevel(logging.DEBUG)


class ApiMixin:
    def __init__(self, odoo_instance) -> None:
        self.odoo = odoo_instance
        self.api_version = self._get_api_version()

    def _get_api_version(self) -> int:
        """Determine API version based on Odoo version.

        Returns:
            1: For Odoo versions 8-18 (JSON-RPC v1)
            2: For Odoo versions 19+ (JSON-2 API)
        """
        if self.odoo.version >= 19:
            return 2
        else:
            return 1

    def call(self, method: str, *args, **kwargs) -> Any:
        _logger.debug(f"API call done: {method} (API v{self.api_version})")
        api_mixin = self._get_api_mixin()
        if hasattr(api_mixin, method):
            func = getattr(api_mixin, method)
            return func(*args, **kwargs)
        else:
            raise AttributeError(f"Method '{method}' not found in API v{self.api_version} mixin")

    def _get_api_mixin(self):
        """Get the appropriate API mixin based on API version.

        Returns:
            OdooJSONRPCMixin: For API v1 (Odoo 8-18)
            OdooJSON2Mixin: For API v2 (Odoo 19+)
        """
        if self.api_version == 2:
            return OdooJSON2Mixin(self.odoo)
        else:
            return OdooJSONRPCMixin(self.odoo)


class OdooJSONRPCMixin:
    """JSON-RPC v1 API mixin for Odoo versions 8-18."""

    def __init__(self, odoo_instance):
        self.odoo = odoo_instance
        self.api_url = "/jsonrpc"

    def _get_headers(self) -> dict:
        """Get headers for JSON-RPC v1 requests."""
        return {"Content-Type": "application/json"}

    def _get_full_url(self) -> str:
        """Get the full API URL for JSON-RPC v1."""
        return f"{self.odoo.url}{self.api_url}"

    def json_rpc(self, url, method, params):
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": random.randint(0, 1000000000),
        }
        headers = self._get_headers()
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        response = response.json()
        if response.get("error"):
            raise Exception(response["error"])
        return response["result"]

    def authenticate(self, db, username, password, **kwargs) -> int:
        return self.json_rpc(
            self._get_full_url(),
            "call",
            {
                "service": "common",
                "method": "authenticate",
                "args": [db, username, password, {}],
            },
        )

    def search(self, model_name, domain=None, offset=0, limit=None, order=None):
        """Search records using JSONRPC."""
        params = {
            "service": "object",
            "method": "execute_kw",
            "args": [
                self.odoo.db,
                self.odoo.uid,
                self.odoo._get_actual_password(),
                model_name,
                "search",
                [domain or []],
                {"offset": offset, "limit": limit, "order": order},
            ],
        }
        return self.json_rpc(self._get_full_url(), "call", params)

    def read(self, model_name, ids, fields=None):
        """Read records using JSONRPC."""
        params = {
            "service": "object",
            "method": "execute_kw",
            "args": [
                self.odoo.db,
                self.odoo.uid,
                self.odoo._get_actual_password(),
                model_name,
                "read",
                [ids],
                {"fields": fields or []},
            ],
        }
        return self.json_rpc(self._get_full_url(), "call", params)

    def fields_get(self, model_name, allfields=None, attributes=None):
        """Get field metadata using JSONRPC."""
        params = {
            "service": "object",
            "method": "execute_kw",
            "args": [
                self.odoo.db,
                self.odoo.uid,
                self.odoo._get_actual_password(),
                model_name,
                "fields_get",
                [[], ["relation", "type"]],
            ],
        }
        return self.json_rpc(self._get_full_url(), "call", params)

    def search_count(self, model_name, domain=None):
        """Count records using JSONRPC."""
        params = {
            "service": "object",
            "method": "execute_kw",
            "args": [
                self.odoo.db,
                self.odoo.uid,
                self.odoo._get_actual_password(),
                model_name,
                "search_count",
                [domain or []],
            ],
        }
        return self.json_rpc(self._get_full_url(), "call", params)

    def search_read(self, model_name, domain=None, fields=None, offset=0, limit=None, order=None):
        """Search and read records using JSONRPC."""
        params = {
            "service": "object",
            "method": "execute_kw",
            "args": [
                self.odoo.db,
                self.odoo.uid,
                self.odoo._get_actual_password(),
                model_name,
                "search_read",
                [domain or []],
                {"fields": fields or [], "offset": offset, "limit": limit, "order": order},
            ],
        }
        return self.json_rpc(self._get_full_url(), "call", params)

    def create(self, model_name, values):
        """Create a new record using JSONRPC."""
        # TODO: check this again. Isnt possible create_multi by xmlrpc/jsonrpc?
        ids = []
        for vals in values:
            params = {
                "service": "object",
                "method": "execute_kw",
                "args": [self.odoo.db, self.odoo.uid, self.odoo._get_actual_password(), model_name, "create", [vals]],
            }
            ids.append(self.json_rpc(f"{self.odoo.url}{self.api_url}", "call", params))
        return ids

    def write(self, model_name, ids, vals):
        """Write records using JSONRPC."""
        params = {
            "service": "object",
            "method": "execute_kw",
            "args": [
                self.odoo.db,
                self.odoo.uid,
                self.odoo._get_actual_password(),
                model_name,
                "write",
                [ids, vals],
            ],
        }
        return self.json_rpc(self._get_full_url(), "call", params)

    def unlink(self, model_name, ids):
        """Delete records using JSONRPC."""
        params = {
            "service": "object",
            "method": "execute_kw",
            "args": [self.odoo.db, self.odoo.uid, self.odoo._get_actual_password(), model_name, "unlink", [ids]],
        }
        return self.json_rpc(self._get_full_url(), "call", params)


class OdooJSON2Mixin:
    """JSON-2 API mixin for Odoo versions 19+.

    Uses the new JSON-2 API with bearer token authentication and REST-like URLs.
    """

    def __init__(self, odoo_instance):
        self.odoo = odoo_instance
        self.api_base_url = "/json/2"
        # Note: JSON-2 API requires API keys instead of username/password
        # This is a limitation that needs to be addressed in the credentials system

    def _get_headers(self) -> dict:
        """Get headers for JSON-2 API requests."""
        # TODO: why do I replace https:// and http:// ?
        headers = {
            "Content-Type": "application/json",
            "Host": self.odoo.url.replace("https://", "").replace("http://", ""),
        }

        # Add database header if needed (multi-database systems)
        if hasattr(self.odoo, "db") and self.odoo.db:
            headers["X-Odoo-Database"] = self.odoo.db

        headers["Authorization"] = f"Bearer {self.odoo._get_actual_password()}"

        return headers

    def _get_model_url(self, model_name: str, method: str) -> str:
        """Get the full URL for a specific model and method in JSON-2 API."""
        return f"{self.odoo.url}{self.api_base_url}/{model_name}/{method}"

    def _make_request(self, model_name: str, method: str, params: dict) -> Any:
        """Make a JSON-2 API request."""
        url = self._get_model_url(model_name, method)
        headers = self._get_headers()

        response = requests.post(url, json=params, headers=headers)
        response.raise_for_status()

        result = response.json()
        if isinstance(result, dict) and result.get("error"):
            raise Exception(result["error"])
        return result

    def authenticate(self, db, username, password, **kwargs) -> int:
        """Authentication for JSON-2 API.

        Note: JSON-2 API uses API keys instead of username/password.
        This method is kept for compatibility but will need API key implementation.
        """
        uid = self.search("res.users", [["login", "=", username]])
        return bool(uid) and uid[0] or False

    def search(self, model_name, domain=None, offset=0, limit=None, order=None):
        """Search records using JSON-2 API."""
        params = {"domain": domain or [], "offset": offset, "limit": limit, "order": order}
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        return self._make_request(model_name, "search", params)

    def read(self, model_name, ids, fields=None):
        """Read records using JSON-2 API."""
        params = {"ids": ids, "fields": fields or []}
        return self._make_request(model_name, "read", params)

    def fields_get(self, model_name, allfields=None, attributes=None):
        """Get field metadata using JSON-2 API."""
        params = {"allfields": allfields or [], "attributes": attributes or ["relation", "type"]}
        return self._make_request(model_name, "fields_get", params)

    def search_count(self, model_name, domain=None):
        """Count records using JSON-2 API."""
        params = {"domain": domain or []}
        return self._make_request(model_name, "search_count", params)

    def search_read(self, model_name, domain=None, fields=None, offset=0, limit=None, order=None):
        """Search and read records using JSON-2 API."""
        params = {"domain": domain or [], "fields": fields or [], "offset": offset, "limit": limit, "order": order}
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        return self._make_request(model_name, "search_read", params)

    def create(self, model_name, values):
        """Create records using JSON-2 API."""
        # JSON-2 API supports batch creation
        params = {"vals_list": values}
        return self._make_request(model_name, "create", params)

    def write(self, model_name, ids, vals):
        """Write records using JSON-2 API."""
        params = {"ids": ids, "values": vals}
        return self._make_request(model_name, "write", params)

    def unlink(self, model_name, ids):
        """Delete records using JSON-2 API."""
        params = {"ids": ids}
        return self._make_request(model_name, "unlink", params)
