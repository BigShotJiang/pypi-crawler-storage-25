#!/bin/bash

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

get_last_tag() {
    git describe --tags --abbrev=0 2>/dev/null || echo "none"
}

get_next_version_hint() {
    local last_tag=$(get_last_tag)
    if [[ "$last_tag" == "none" ]]; then
        echo "v0.1.0"
    else
        # Extract version numbers
        local version="${last_tag#v}"
        IFS='.' read -r major minor patch <<< "$version"
        echo "v${major}.${minor}.$((patch + 1)) or v${major}.$((minor + 1)).0"
    fi
}

show_help() {
    echo -e "${BLUE}FastOdoo Deploy Script${NC}"
    echo ""
    echo "Usage:"
    echo "  ./deploy.sh --tag <version>    Create and push a release tag"
    echo "  ./deploy.sh --help             Show this help message"
    echo ""
    echo "Examples:"
    echo "  ./deploy.sh --tag v0.1.0"
    echo "  ./deploy.sh --tag v1.0.0"
    echo ""
    echo -e "${YELLOW}Current Status:${NC}"
    echo -e "  Last tag:      ${GREEN}$(get_last_tag)${NC}"
    echo -e "  Next version:  ${GREEN}$(get_next_version_hint)${NC}"
    echo ""
    echo -e "${YELLOW}What this script does:${NC}"
    echo "  1. Checks out main branch"
    echo "  2. Pulls latest changes"
    echo "  3. Creates the specified tag"
    echo "  4. Pushes the tag to origin"
    echo "  5. GitHub Actions then automatically:"
    echo "     - Creates a GitHub Release with auto-generated notes"
    echo "     - Publishes to PyPI"
}

deploy() {
    local tag=$1

    # Validate tag format
    if [[ ! "$tag" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo -e "${RED}Error: Invalid tag format '$tag'${NC}"
        echo "Tag must be in format: v0.0.0 (e.g., v0.1.0, v1.2.3)"
        exit 1
    fi

    # Check if tag already exists
    if git rev-parse "$tag" >/dev/null 2>&1; then
        echo -e "${RED}Error: Tag '$tag' already exists${NC}"
        exit 1
    fi

    echo -e "${BLUE}Deploying FastOdoo $tag${NC}"
    echo ""

    # Check for uncommitted changes
    if [[ -n $(git status --porcelain) ]]; then
        echo -e "${RED}Error: You have uncommitted changes${NC}"
        echo "Please commit or stash your changes before deploying."
        exit 1
    fi

    # Checkout main and pull
    echo -e "${YELLOW}→ Checking out main branch...${NC}"
    git checkout main

    echo -e "${YELLOW}→ Pulling latest changes...${NC}"
    git pull origin main

    # Create tag
    echo -e "${YELLOW}→ Creating tag $tag...${NC}"
    git tag "$tag"

    # Push tag
    echo -e "${YELLOW}→ Pushing tag to origin...${NC}"
    git push origin "$tag"

    echo ""
    echo -e "${GREEN}✓ Successfully deployed $tag${NC}"
    echo ""
    echo "GitHub Actions will now:"
    echo "  1. Build the package"
    echo "  2. Create a GitHub Release"
    echo "  3. Publish to PyPI"
    echo ""
    echo -e "Monitor progress at: ${BLUE}https://github.com/aidooit/fastodoo/actions${NC}"
}

# Main
case "${1:-}" in
    --tag)
        if [[ -z "${2:-}" ]]; then
            echo -e "${RED}Error: Missing tag version${NC}"
            echo "Usage: ./deploy.sh --tag <version>"
            exit 1
        fi
        deploy "$2"
        ;;
    --help|-h|"")
        show_help
        ;;
    *)
        echo -e "${RED}Error: Unknown option '$1'${NC}"
        show_help
        exit 1
        ;;
esac
