"""
Unit tests for wizard.py helpers — state persistence, engine/model picking
logic, presence checks, and the Claude/Codex wiring helpers.
"""

from __future__ import annotations

import os

# ---------------------------------------------------------------------------
# WizardState persistence — roundtrip + mark + resilience to a missing file.
# ---------------------------------------------------------------------------


class TestWizardState:
    def test_load_returns_empty_when_no_state_file(self, isolated_state):
        _, wiz, _ = isolated_state
        state = wiz.WizardState.load()
        assert state.completed_steps == []
        assert state.primary_harness == ""

    def test_save_then_load_roundtrips_fields(self, isolated_state):
        _, wiz, _ = isolated_state
        state = wiz.WizardState(
            primary_harness="claude",
            primary_engine="ollama",
            model_name="qwen3-coder:30b",
            engine_model_tag="qwen3-coder:30b",
            completed_steps=["2.1", "2.2"],
        )
        state.save()
        reloaded = wiz.WizardState.load()
        assert reloaded.primary_harness == "claude"
        assert reloaded.primary_engine == "ollama"
        assert reloaded.completed_steps == ["2.1", "2.2"]

    def test_mark_is_idempotent(self, isolated_state):
        _, wiz, _ = isolated_state
        state = wiz.WizardState()
        state.mark("2.1")
        state.mark("2.1")
        state.mark("2.2")
        assert state.completed_steps == ["2.1", "2.2"]

    def test_load_handles_corrupt_state_file(self, isolated_state):
        _, wiz, state_dir = isolated_state
        state_dir.mkdir(parents=True, exist_ok=True)
        wiz.STATE_FILE.write_text("this is not json {")
        state = wiz.WizardState.load()
        assert state.completed_steps == []


# ---------------------------------------------------------------------------
# _default_engine — platform-aware preference rules.
# ---------------------------------------------------------------------------


class TestDefaultEngine:
    def _profile(self, **overrides):
        base = {
            "host": {"system": "Darwin", "machine": "arm64"},
            "ollama": {"models": []},
            "lmstudio": {"server_running": False, "models": []},
        }
        base.update(overrides)
        return base

    def test_prefers_lmstudio_when_ready_on_apple_silicon(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = self._profile(lmstudio={"server_running": True, "models": [{"path": "a"}]})
        assert wiz._default_engine(["ollama", "lmstudio"], profile) == "lmstudio"

    def test_prefers_ollama_when_it_has_models(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = self._profile(ollama={"models": [{"name": "qwen3-coder:30b"}]})
        assert wiz._default_engine(["ollama", "lmstudio"], profile) == "ollama"

    def test_lmstudio_fallback_on_apple_silicon_when_nothing_ready(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._default_engine(["lmstudio", "ollama"], self._profile()) == "lmstudio"

    def test_ollama_fallback_on_linux_x86(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = self._profile(host={"system": "Linux", "machine": "x86_64"})
        assert wiz._default_engine(["ollama", "llamacpp"], profile) == "ollama"

    def test_first_engine_when_nothing_matches_rules(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = self._profile(host={"system": "Linux", "machine": "x86_64"})
        assert wiz._default_engine(["llamacpp"], profile) == "llamacpp"


# ---------------------------------------------------------------------------
# _map_to_engine — resolve a user-typed name to an engine-specific tag.
# ---------------------------------------------------------------------------


class TestMapToEngine:
    def test_ollama_passthrough_for_existing_tag(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._map_to_engine("qwen3-coder:30b", "ollama") == "qwen3-coder:30b"

    def test_ollama_resolves_hf_name(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._map_to_engine("Qwen/Qwen2.5-Coder-7B", "ollama") == "qwen2.5-coder:7b"

    def test_lmstudio_passthrough_for_hub_slash_name(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._map_to_engine("qwen/qwen3-coder-30b", "lmstudio") == "qwen/qwen3-coder-30b"

    def test_lmstudio_resolves_hf_shortname(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._map_to_engine("Qwen3-Coder-30B", "lmstudio") == "qwen/qwen3-coder-30b"

    def test_llamacpp_returns_input_unchanged(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._map_to_engine("whatever", "llamacpp") == "whatever"


# ---------------------------------------------------------------------------
# _candidate_tag — engine-specific field extraction.
# ---------------------------------------------------------------------------


class TestCandidateTag:
    def test_ollama_reads_ollama_tag(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._candidate_tag({"ollama_tag": "qwen3-coder:30b"}, "ollama") == "qwen3-coder:30b"

    def test_lmstudio_prefers_hub_over_mlx_path(self, isolated_state):
        _, wiz, _ = isolated_state
        c = {"lms_hub_name": "qwen/qwen3-coder-30b", "lms_mlx_path": "lmstudio-community/x"}
        assert wiz._candidate_tag(c, "lmstudio") == "qwen/qwen3-coder-30b"

    def test_lmstudio_falls_back_to_mlx_path(self, isolated_state):
        _, wiz, _ = isolated_state
        c = {"lms_mlx_path": "lmstudio-community/x-MLX-4bit"}
        assert wiz._candidate_tag(c, "lmstudio") == "lmstudio-community/x-MLX-4bit"

    def test_llamacpp_falls_back_to_raw_name(self, isolated_state):
        _, wiz, _ = isolated_state
        assert (
            wiz._candidate_tag({"name": "Qwen/Qwen3-Coder-30B"}, "llamacpp")
            == "Qwen/Qwen3-Coder-30B"
        )


# ---------------------------------------------------------------------------
# _model_already_installed — check profile dicts.
# ---------------------------------------------------------------------------


class TestModelAlreadyInstalled:
    def test_ollama_match(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = {"ollama": {"models": [{"name": "qwen3-coder:30b"}]}, "lmstudio": {"models": []}}
        assert wiz._model_already_installed("ollama", "qwen3-coder:30b", profile) is True

    def test_ollama_no_match(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = {"ollama": {"models": [{"name": "llama2:7b"}]}, "lmstudio": {"models": []}}
        assert wiz._model_already_installed("ollama", "qwen3-coder:30b", profile) is False

    def test_lmstudio_match_by_path(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = {
            "ollama": {"models": []},
            "lmstudio": {"models": [{"path": "qwen/qwen3-coder-30b"}]},
        }
        assert wiz._model_already_installed("lmstudio", "qwen/qwen3-coder-30b", profile) is True

    def test_llamacpp_always_false(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._model_already_installed("llamacpp", "x", {}) is False


# ---------------------------------------------------------------------------
# _model_known_incompatible_with_claude_code — tag-pattern check.
# ---------------------------------------------------------------------------


class TestModelIncompatibility:
    def test_qwen3_is_incompatible(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._model_known_incompatible_with_claude_code("qwen/qwen3-coder-30b") is True

    def test_qwen25_is_compatible(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._model_known_incompatible_with_claude_code("qwen/qwen2.5-coder-7b") is False

    def test_llama_is_compatible(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._model_known_incompatible_with_claude_code("meta-llama/llama-3-8b") is False


# ---------------------------------------------------------------------------
# _wire_claude — returns a WireResult, no settings.json written.
# ---------------------------------------------------------------------------


class TestWireClaude:
    def test_ollama_returns_ollama_launch_argv(self, isolated_state):
        _, wiz, _ = isolated_state
        result = wiz._wire_claude("ollama", "qwen3-coder:30b")
        # Trailing "--" lets the helper script forward user args to claude
        # instead of having `ollama launch` eat them.
        assert result.argv == [
            "ollama",
            "launch",
            "claude",
            "--model",
            "qwen3-coder:30b",
            "--",
        ]
        assert result.env == {}
        assert result.effective_tag == "qwen3-coder:30b"

    def test_lmstudio_returns_inline_env(self, isolated_state):
        pb, wiz, _ = isolated_state
        result = wiz._wire_claude("lmstudio", "qwen/qwen2.5-coder-7b")
        assert result.argv == ["claude", "--model", "qwen/qwen2.5-coder-7b"]
        assert result.env["ANTHROPIC_BASE_URL"] == f"http://localhost:{pb.LMS_SERVER_PORT}"
        assert result.env["ANTHROPIC_CUSTOM_MODEL_OPTION"] == "qwen/qwen2.5-coder-7b"
        assert result.env["CLAUDE_CODE_ATTRIBUTION_HEADER"] == "0"

    def test_llamacpp_returns_inline_env(self, isolated_state):
        _, wiz, _ = isolated_state
        result = wiz._wire_claude("llamacpp", "some-gguf")
        assert result.argv == ["claude", "--model", "some-gguf"]
        assert result.env["ANTHROPIC_BASE_URL"] == "http://localhost:8001"

    def test_unknown_engine_returns_none(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._wire_claude("bogus", "tag") is None


# ---------------------------------------------------------------------------
# _wire_codex — returns WireResult with engine-specific argv/env.
# ---------------------------------------------------------------------------


class TestWireCodex:
    def test_ollama_path(self, isolated_state):
        _, wiz, _ = isolated_state
        result = wiz._wire_codex("ollama", "qwen3-coder:30b")
        assert result.argv[:5] == ["ollama", "launch", "codex", "--model", "qwen3-coder:30b"]
        assert "--oss" in result.argv
        assert result.env == {}

    def test_lmstudio_path(self, isolated_state):
        pb, wiz, _ = isolated_state
        result = wiz._wire_codex("lmstudio", "qwen/qwen3-coder-30b")
        assert result.argv == ["codex", "-m", "qwen/qwen3-coder-30b"]
        assert result.env["OPENAI_BASE_URL"] == f"http://localhost:{pb.LMS_SERVER_PORT}/v1"
        assert result.env["OPENAI_API_KEY"] == "lmstudio"

    def test_llamacpp_path(self, isolated_state):
        _, wiz, _ = isolated_state
        result = wiz._wire_codex("llamacpp", "some-gguf")
        assert result.argv == ["codex", "-m", "some-gguf"]
        assert result.env["OPENAI_BASE_URL"] == "http://localhost:8001/v1"

    def test_unknown_engine(self, isolated_state):
        _, wiz, _ = isolated_state
        assert wiz._wire_codex("bogus", "x") is None


# ---------------------------------------------------------------------------
# Helper script writer — bash file under .claude-codex-local/bin/.
# ---------------------------------------------------------------------------


class TestHelperScriptWriter:
    def test_ollama_script_uses_ollama_launch_no_exports(self, isolated_state):
        _, wiz, _ = isolated_state
        result = wiz.WireResult(
            argv=["ollama", "launch", "claude", "--model", "qwen2.5-coder:7b", "--"],
            env={},
            effective_tag="qwen2.5-coder:7b",
        )
        path = wiz._write_helper_script("claude", result)
        body = path.read_text()
        # The "--" must appear before "$@" so user flags reach claude, not
        # `ollama launch`.
        assert 'exec ollama launch claude --model qwen2.5-coder:7b -- "$@"' in body
        assert "export " not in body
        assert os.access(path, os.X_OK)

    def test_lmstudio_script_exports_env_and_execs_claude(self, isolated_state):
        pb, wiz, _ = isolated_state
        result = wiz.WireResult(
            argv=["claude", "--model", "qwen/qwen2.5-coder-7b"],
            env={
                "ANTHROPIC_BASE_URL": f"http://localhost:{pb.LMS_SERVER_PORT}",
                "ANTHROPIC_API_KEY": "lmstudio",
            },
            effective_tag="qwen/qwen2.5-coder-7b",
        )
        path = wiz._write_helper_script("claude", result)
        body = path.read_text()
        assert "export ANTHROPIC_BASE_URL=" in body
        assert "exec claude --model" in body and '"$@"' in body
        assert os.access(path, os.X_OK)


# ---------------------------------------------------------------------------
# Shell alias installer — fenced block, idempotent overwrite.
# ---------------------------------------------------------------------------


class TestShellAliasInstaller:
    def _make_script(self, tmp_path):
        path = tmp_path / "cc"
        path.write_text("#!/bin/sh\necho hi\n")
        path.chmod(0o755)
        return path

    def test_fresh_install_into_empty_rc(self, isolated_state, tmp_path):
        _, wiz, _ = isolated_state
        from pathlib import Path

        rc = Path.home() / ".zshrc"
        rc.write_text("")
        script = self._make_script(tmp_path)
        rc_path, names = wiz._install_shell_aliases(script, "claude", non_interactive=True)
        assert rc_path == rc
        body = rc.read_text()
        assert "# >>> claude-codex-local >>>" in body
        assert "alias cc=" in body
        assert "alias claude-local=" in body
        assert "cc" in names

    def test_overwrite_replaces_existing_block(self, isolated_state, tmp_path):
        _, wiz, _ = isolated_state
        from pathlib import Path

        rc = Path.home() / ".zshrc"
        rc.write_text(
            "# >>> claude-codex-local >>>\nalias cc='/old/path'\n# <<< claude-codex-local <<<\n"
        )
        script = self._make_script(tmp_path)
        wiz._install_shell_aliases(script, "claude", non_interactive=True)
        body = rc.read_text()
        # Should be exactly one block
        assert body.count("# >>> claude-codex-local >>>") == 1
        assert "/old/path" not in body
        assert str(script) in body

    def test_preserves_surrounding_content(self, isolated_state, tmp_path):
        _, wiz, _ = isolated_state
        from pathlib import Path

        rc = Path.home() / ".zshrc"
        rc.write_text(
            "export FOO=bar\n"
            "# >>> claude-codex-local >>>\n"
            "alias cc='/old/path'\n"
            "# <<< claude-codex-local <<<\n"
            "export BAZ=qux\n"
        )
        script = self._make_script(tmp_path)
        wiz._install_shell_aliases(script, "claude", non_interactive=True)
        body = rc.read_text()
        assert "export FOO=bar" in body
        assert "export BAZ=qux" in body
        assert body.count("# >>> claude-codex-local >>>") == 1

    def test_unknown_shell_returns_none(self, isolated_state, tmp_path, monkeypatch):
        _, wiz, _ = isolated_state
        monkeypatch.setenv("SHELL", "/bin/fish")
        script = self._make_script(tmp_path)
        rc_path, names = wiz._install_shell_aliases(script, "claude", non_interactive=True)
        assert rc_path is None
        assert "cc" in names


# ---------------------------------------------------------------------------
# _estimate_model_size — delegates to pb.llmfit_estimate_size_bytes.
# ---------------------------------------------------------------------------


class TestEstimateModelSize:
    def test_uses_captured_candidate(self, isolated_state, monkeypatch):
        pb, wiz, _ = isolated_state
        monkeypatch.setattr(
            pb, "llmfit_estimate_size_bytes", lambda x: 42 if isinstance(x, dict) else None
        )
        state = wiz.WizardState(model_candidate={"total_memory_gb": 4}, model_name="irrelevant")
        assert wiz._estimate_model_size(state) == 42

    def test_falls_back_to_name_lookup(self, isolated_state, monkeypatch):
        pb, wiz, _ = isolated_state
        monkeypatch.setattr(
            pb, "llmfit_estimate_size_bytes", lambda x: 99 if isinstance(x, str) else None
        )
        state = wiz.WizardState(model_name="qwen3-coder:30b")
        assert wiz._estimate_model_size(state) == 99

    def test_returns_none_when_nothing_known(self, isolated_state, monkeypatch):
        pb, wiz, _ = isolated_state
        monkeypatch.setattr(pb, "llmfit_estimate_size_bytes", lambda x: None)
        assert wiz._estimate_model_size(wiz.WizardState()) is None


# ---------------------------------------------------------------------------
# _find_model_auto — installed-first preference, llmfit fallback.
# ---------------------------------------------------------------------------


class TestFindModelAuto:
    def test_prefers_installed_coding_model(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = {
            "ollama": {
                "models": [
                    {"name": "llama2:7b", "local": True},
                    {"name": "qwen2.5-coder:7b", "local": True},
                ]
            },
            "lmstudio": {"models": []},
        }
        result = wiz._find_model_auto("ollama", profile)
        assert result["tag"] == "qwen2.5-coder:7b"

    def test_lmstudio_prefers_coder_model(self, isolated_state):
        _, wiz, _ = isolated_state
        profile = {
            "ollama": {"models": []},
            "lmstudio": {
                "models": [
                    {"path": "meta/llama-3-8b", "format": "mlx"},
                    {"path": "qwen/qwen3-coder-30b", "format": "mlx"},
                ]
            },
        }
        result = wiz._find_model_auto("lmstudio", profile)
        assert result["tag"] == "qwen/qwen3-coder-30b"

    def test_falls_back_to_llmfit_when_nothing_installed(self, isolated_state, monkeypatch):
        pb, wiz, _ = isolated_state
        monkeypatch.setattr(
            pb,
            "llmfit_coding_candidates",
            lambda: [
                {
                    "name": "Qwen/Qwen3-Coder-30B",
                    "ollama_tag": "qwen3-coder:30b",
                    "lms_mlx_path": None,
                    "lms_hub_name": None,
                    "score": 90,
                },
            ],
        )
        profile = {"ollama": {"models": []}, "lmstudio": {"models": []}}
        result = wiz._find_model_auto("ollama", profile)
        assert result["tag"] == "qwen3-coder:30b"

    def test_returns_none_when_nothing_at_all(self, isolated_state, monkeypatch):
        pb, wiz, _ = isolated_state
        monkeypatch.setattr(pb, "llmfit_coding_candidates", lambda: [])
        profile = {"ollama": {"models": []}, "lmstudio": {"models": []}}
        assert wiz._find_model_auto("ollama", profile) is None
