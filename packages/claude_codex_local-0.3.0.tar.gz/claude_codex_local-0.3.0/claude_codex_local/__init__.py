"""claude-codex-local — local backend bridge for Claude Code and Codex."""

__version__ = "0.3.0"
