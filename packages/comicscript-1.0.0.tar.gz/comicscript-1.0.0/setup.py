﻿from setuptools import setup, find_packages

setup(
    name="ComicScript",
    version="1.0.0",
    packages=find_packages(),
    # AQUÍ ES DONDE SUCEDE LA MAGIA
    install_requires=[
        'Emilve', # Esto obliga a pip a instalar emilve si el usuario no la tiene
    ], 
    description="Sarcastic Python tracebacks for developers who don't take themselves too seriously.",
    author="Emiliano",
    author_email="emicicsmaker@gmail.com",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)