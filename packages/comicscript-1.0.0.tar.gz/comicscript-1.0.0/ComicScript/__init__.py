from .core import setup_comic_errors

# Al importar la librería, se activan los errores automáticamente
setup_comic_errors()

__version__ = "1.0.0"
__author__ = "Emiliano"