﻿import sys
import random

def setup_comic_errors():
    def custom_excepthook(type, value, traceback):
        # Humor universal para programadores anónimos
        roasts = {
            'NameError': [
                "Whoops! '{0}'? I haven't heard that name since the Big Bang.",
                "Are you inventing a new language? Because '{0}' is definitely not in Python.",
                "Variable '{0}' not found. Maybe it's hiding in a different dimension?"
            ],
            'SyntaxError': [
                "Syntax Error at '{0}'? My keyboard codes cleaner than this.",
                "You call '{0}' code? It looks like a cat walked over the keyboard.",
                "Check '{0}' again. Even a compiler has feelings, you know?"
            ],
            'TypeError': [
                "'{0}'? You're trying to mix things that don't belong together.",
                "Invalid type '{0}'! Even an AI has higher standards than this.",
                "TypeError '{0}': Your code is trying to be something it's not. Just be yourself."
            ],
            'IndexError': [
                "Index '{0}' is out of bounds! You're reaching for things that don't exist.",
                "Index '{0}' out of range. You've gone too far, come back to reality!",
                "Error at index '{0}': Try staying inside the lines for once."
            ],
            'ZeroDivisionError': [
                "Dividing '{0}'? Do you want to create a black hole in the server room?",
                "Math '{0}' is hard, I know. But that's literally impossible.",
                "Zero division '{0}' detected. Somewhere, a math teacher is crying."
            ],
            'AttributeError': [
                "'{0}'? Asking for that is like asking a fish to fly a plane.",
                "Attribute Error: Stop trying to make '{0}' happen. It's not going to happen."
            ],
            'ModuleNotFoundError': [
                "Module '{0}' missing! Did you forget to install your dependencies?",
                "I can't find '{0}'. It's probably lost in the cloud somewhere."
            ],
            'KeyError': [
                "Key '{0}' isn't in the dictionary. It's like looking for keys already in your hand.",
                "KeyError '{0}': Access denied. The dictionary says NO."
            ]
        }

        error_name = type.__name__
        if error_name in roasts:
            # Formateamos el valor del error dentro del chiste
            msg = random.choice(roasts[error_name]).format(value)
            print(f"\n🔥 [COMIC-SCRIPT ERROR] 🔥")
            print(f">>> {msg}\n")
        else:
            # Fallback para errores no mapeados
            print(f"\n🙄 Even I don't know what you did with '{value}'. Here's the boring stuff:")
            sys.__excepthook__(type, value, traceback)

    sys.excepthook = custom_excepthook

# Esto asegura que se active al importar la librería
setup_comic_errors()