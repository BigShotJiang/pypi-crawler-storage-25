"""Op → typed Request translation for reconcile_v3.

Translates ``DiffOp`` objects produced by ``diff.py`` into typed
``Request`` objects from ``api_types._generated`` suitable for batchUpdate.

Strategy
--------
- Simple ops (named style updates, tab create/delete, header/footer create/delete)
  are lowered directly.
- Content ops (UpdateBodyContentOp) use index arithmetic against the base
  document: base content elements carry ``startIndex``/``endIndex`` directly
  from the API response.
- Ops that are structurally unsupported raise ``NotImplementedError`` with a
  clear diagnostic message.

Multi-batch ordering
--------------------
Batch 1: Structural creation — createHeader, createFooter, addDocumentTab.
Batch 2: All content operations (deleteContentRange, insertText, updateNamedStyle,
         deleteTab, deleteHeader, deleteFooter).
Batch 3: (currently empty; reserved for footnotes and named ranges)

Deferred IDs
------------
When a header/footer is created in Batch 1, its ID is not yet known.  The
``updateSectionStyle`` request in Batch 2 that attaches the header uses a
``DeferredID`` placeholder that ``resolve_deferred_placeholders`` resolves
after Batch 1 executes.
"""

from __future__ import annotations

import copy
import difflib
from itertools import groupby
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from extradoc.diffmerge import ContentAlignment

from extradoc.api_types._generated import (
    AddDocumentTabRequest,
    Bullet,
    CreateFooterRequest,
    CreateFooterRequestType,
    CreateFootnoteRequest,
    CreateHeaderRequest,
    CreateNamedRangeRequest,
    CreateParagraphBulletsRequest,
    CreateParagraphBulletsRequestBulletPreset,
    DeferredID,
    DeleteContentRangeRequest,
    DeleteFooterRequest,
    DeleteHeaderRequest,
    DeleteNamedRangeRequest,
    DeleteParagraphBulletsRequest,
    DeleteTableColumnRequest,
    DeleteTableRowRequest,
    DeleteTabRequest,
    Dimension,
    InsertInlineImageRequest,
    InsertPageBreakRequest,
    InsertSectionBreakRequest,
    InsertTableColumnRequest,
    InsertTableRequest,
    InsertTableRowRequest,
    InsertTextRequest,
    Location,
    NamedStyle,
    Paragraph,
    ParagraphElement,
    ParagraphStyle,
    Range,
    Request,
    SectionStyle,
    StructuralElement,
    Tab,
    Table,
    TableCellLocation,
    TableCellStyle,
    TableColumnProperties,
    TableRange,
    TableRowStyle,
    TabProperties,
    TextStyle,
    UpdateDocumentStyleRequest,
    UpdateParagraphStyleRequest,
    UpdateSectionStyleRequest,
    UpdateTableCellStyleRequest,
    UpdateTableColumnPropertiesRequest,
    UpdateTableRowStyleRequest,
    UpdateTextStyleRequest,
)
from extradoc.api_types._generated import (
    List as DocList,
)
from extradoc.diffmerge import (
    CoordinateNotResolvedError,
    CreateFooterOp,
    CreateHeaderOp,
    DeleteFooterOp,
    DeleteFootnoteOp,
    DeleteHeaderOp,
    DeleteInlineObjectOp,
    DeleteListOp,
    DeleteNamedStyleOp,
    DeleteTableColumnOp,
    DeleteTableRowOp,
    DeleteTabOp,
    DiffOp,
    InsertFootnoteOp,
    InsertInlineObjectOp,
    InsertListOp,
    InsertNamedStyleOp,
    InsertTableColumnOp,
    InsertTableRowOp,
    InsertTabOp,
    UpdateBodyContentOp,
    UpdateDocumentStyleOp,
    UpdateFooterContentOp,
    UpdateFootnoteContentOp,
    UpdateHeaderContentOp,
    UpdateInlineObjectOp,
    UpdateListOp,
    UpdateNamedStyleOp,
    UpdateTableCellStyleOp,
    UpdateTableColumnPropertiesOp,
    UpdateTableRowStyleOp,
)
from extradoc.diffmerge.model import DeleteNamedRangeOp, InsertNamedRangeOp
from extradoc.indexer import utf16_len

# Slot → API type string
_HEADER_TYPE = {
    "DEFAULT": "DEFAULT",
    "FIRST_PAGE": "FIRST_PAGE",
    "EVEN_PAGE": "EVEN_PAGE",
}

_FOOTER_TYPE = {
    "DEFAULT": "DEFAULT",
    "FIRST_PAGE": "FIRST_PAGE",
    "EVEN_PAGE": "EVEN_PAGE",
}

_HEADER_SLOT_FIELD = {
    "DEFAULT": "defaultHeaderId",
    "FIRST_PAGE": "firstPageHeaderId",
    "EVEN_PAGE": "evenPageHeaderId",
}

_FOOTER_SLOT_FIELD = {
    "DEFAULT": "defaultFooterId",
    "FIRST_PAGE": "firstPageFooterId",
    "EVEN_PAGE": "evenPageFooterId",
}

# ParagraphStyle fields that are server-managed and cannot be set via the API.
# Including them in an updateParagraphStyle field mask causes a 400 error.
_PARA_STYLE_READONLY_FIELDS: frozenset[str] = frozenset(
    {
        "headingId",  # assigned by server when namedStyleType=HEADING_*
    }
)

# ParagraphStyle fields that Google Docs rejects with HTTP 400 when the target
# range sits inside a table, header, footer, or footnote.  These "unsupported
# regions" are documented on ``ParagraphStyle.pageBreakBefore`` — attempting
# to update the field there returns
#   "Cannot update page-break-before when the range contains paragraphs in a table."
# Drop the field from the updateParagraphStyle mask in those contexts.
_PARA_STYLE_FORBIDDEN_IN_UNSUPPORTED_REGIONS: frozenset[str] = frozenset(
    {
        "pageBreakBefore",
    }
)

# A resolved string ID or a DeferredID placeholder that the executor
# will substitute after an earlier batch completes.
_StrOrDeferred = str | DeferredID


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def lower_ops(ops: list[DiffOp]) -> list[Request]:
    """Lower a list of DiffOps to typed Request objects (single batch).

    For ops whose lowering is not yet implemented, raises ``NotImplementedError``
    with a message identifying the op type and confirming the op was detected.
    """
    requests: list[Request] = []
    for op in ops:
        requests.extend(_lower_one(op))
    return requests


def lower_batches(
    ops: list[DiffOp],
    desired_lists_by_tab: dict[str, dict[str, DocList]] | None = None,
    base_lists_by_tab: dict[str, dict[str, DocList]] | None = None,
) -> list[list[Request]]:
    """Lower ops into an ordered list of request batches.

    Batch 0: Structural creation (createHeader, createFooter, addDocumentTab).
    Batch 1: All content + style + structural-delete operations.
    Batch 2: Footnote operations (reserved; currently empty).

    Returns only non-empty batches.

    Deferred-ID placeholders in Batch 1 refer to Batch 0 responses and must
    be resolved via ``resolve_deferred_placeholders`` before execution.

    Parameters
    ----------
    ops:
        The list of DiffOp objects to lower.
    desired_lists_by_tab:
        Optional mapping of tab_id → lists dict from the desired document.
        Used to infer bullet presets when inserting or updating bullet paragraphs.
        If not provided, bullet presets fall back to BULLET_DISC_CIRCLE_SQUARE.
    base_lists_by_tab:
        Optional mapping of tab_id → lists dict from the base document.
        Used alongside desired_lists_by_tab to detect list-type changes when
        both base and desired have the same synthetic list ID.
    """
    batch0: list[Request] = []  # structural creates
    batch1: list[Request] = []  # content + style + structural deletes
    # Sidecar map of synthetic "structural byte insert" events keyed by the
    # ``id()`` of the request in ``batch1`` that produces them. Each value is
    # a list of ``(tab_id, live_index, delta)`` tuples where ``live_index``
    # is the insertion position in the frame that exists immediately AFTER
    # the event executes (same convention as ``insertText.location.index``).
    # These represent byte-level mutations to the body segment that table
    # structural requests (``insertTableRow``/``insertTableColumn``) perform
    # but do not expose as ``insertText``. The shift helper reads these
    # alongside ``batch1``'s insertText/deleteContentRange requests so it
    # can correctly shift BASE anchors for later same-table structural ops.
    # See ``_compute_index_shift_for_body_ref``.
    struct_events_by_req_id: dict[int, list[tuple[str, int, int]]] = {}
    batch1b: list[
        Request
    ] = []  # createFootnote (after body content, before named ranges)
    batch1b_content: list[
        Request
    ] = []  # footnote content insertions (after createFootnote)
    batch2: list[Request] = []  # named ranges (after content, so indices are stable)

    _desired_lists_by_tab: dict[str, dict[str, DocList]] = desired_lists_by_tab or {}
    _base_lists_by_tab: dict[str, dict[str, DocList]] = base_lists_by_tab or {}

    # Track which requests in batch0 return IDs, keyed by (kind, slot, tab_id)
    # so that batch1 content-attachment requests can reference them.
    batch0_index: dict[str, int] = {}  # key → index in batch0

    # Accumulate footnote-reference deletions (from DeleteFootnoteOp) per tab.
    # These are body-segment single-char deletes at pristine document positions.
    # They are NOT added to batch1 immediately; instead they are passed to the
    # UpdateBodyContentOp handler for the same tab so that all body-segment
    # deletes (fn-ref + content) are merged and emitted in globally-descending
    # document order. This prevents ascending fn-ref deletes from shifting the
    # positions relied upon by the descending UpdateBodyContentOp deletes.
    # Any fn-ref deletes not consumed by a matching UpdateBodyContentOp are
    # flushed to batch1 (sorted descending) at the end of the op loop.
    _fn_ref_deletes: dict[str, list[tuple[int, int]]] = {}  # tab_id → [(start, end)]
    _fn_ref_consumed: dict[str, bool] = {}  # tab_id → whether consumed

    for op in ops:
        match op:
            # ---------------------------------------------------------------- #
            # Structural creates → batch 0
            # ---------------------------------------------------------------- #
            case CreateHeaderOp():
                key = f"header:{op.tab_id}:{op.section_slot}"
                req_index = len(batch0)
                batch0_index[key] = req_index
                batch0.append(
                    _make_create_header(
                        tab_id=op.tab_id,
                        header_type=_HEADER_TYPE[op.section_slot],
                    )
                )
                # Batch1: attach header via updateSectionStyle with deferred ID
                deferred_id = DeferredID(
                    placeholder=f"header_{req_index}",
                    batch_index=0,
                    request_index=req_index,
                    response_path="createHeader.headerId",
                )
                field_name = _HEADER_SLOT_FIELD[op.section_slot]
                batch1.append(
                    _make_update_section_style_deferred(
                        tab_id=op.tab_id,
                        field_name=field_name,
                        deferred_id=deferred_id,
                    )
                )
                # Batch1: insert header content
                batch1.extend(
                    _lower_content_insert(
                        content=op.desired_content,
                        start_index=1,
                        tab_id=op.tab_id,
                        segment_id=deferred_id,
                        in_unsupported_region=True,
                    )
                )

            case CreateFooterOp():
                key = f"footer:{op.tab_id}:{op.section_slot}"
                req_index = len(batch0)
                batch0_index[key] = req_index
                batch0.append(
                    _make_create_footer(
                        tab_id=op.tab_id,
                        footer_type=_FOOTER_TYPE[op.section_slot],
                    )
                )
                deferred_id = DeferredID(
                    placeholder=f"footer_{req_index}",
                    batch_index=0,
                    request_index=req_index,
                    response_path="createFooter.footerId",
                )
                field_name = _FOOTER_SLOT_FIELD[op.section_slot]
                batch1.append(
                    _make_update_section_style_deferred(
                        tab_id=op.tab_id,
                        field_name=field_name,
                        deferred_id=deferred_id,
                    )
                )
                batch1.extend(
                    _lower_content_insert(
                        content=op.desired_content,
                        start_index=1,
                        tab_id=op.tab_id,
                        segment_id=deferred_id,
                        in_unsupported_region=True,
                    )
                )

            case InsertTabOp():
                props = op.desired_tab.tab_properties
                title = props.title if props and props.title else "Untitled"
                index = props.index if props else None
                parent_tab_id = props.parent_tab_id if props else None
                req_index = len(batch0)
                batch0.append(
                    _make_add_document_tab(
                        title=title,
                        index=index,
                        parent_tab_id=parent_tab_id,
                    )
                )
                deferred_tab_id = DeferredID(
                    placeholder=f"tab_{req_index}",
                    batch_index=0,
                    request_index=req_index,
                    response_path="addDocumentTab.tabProperties.tabId",
                )
                body_content = _extract_tab_body_content(op.desired_tab)
                if body_content:
                    batch1.extend(
                        _lower_content_insert(
                            content=body_content,
                            start_index=1,
                            tab_id=deferred_tab_id,
                            segment_id=None,
                        )
                    )

            # ---------------------------------------------------------------- #
            # Structural deletes → batch 1
            # ---------------------------------------------------------------- #
            case DeleteHeaderOp():
                batch1.append(
                    _make_delete_header(
                        header_id=op.base_header_id,
                        tab_id=op.tab_id,
                    )
                )

            case DeleteFooterOp():
                batch1.append(
                    _make_delete_footer(
                        footer_id=op.base_footer_id,
                        tab_id=op.tab_id,
                    )
                )

            case DeleteTabOp():
                batch1.append(_make_delete_tab(tab_id=op.base_tab_id))

            # ---------------------------------------------------------------- #
            # NamedStyles → batch 1
            # ---------------------------------------------------------------- #
            case UpdateNamedStyleOp():
                batch1.append(
                    _make_update_named_style(
                        tab_id=op.tab_id,
                        style=op.desired_style,
                    )
                )

            case InsertNamedStyleOp():
                batch1.append(
                    _make_update_named_style(
                        tab_id=op.tab_id,
                        style=op.desired_style,
                    )
                )

            case DeleteNamedStyleOp():
                # Named styles cannot be truly deleted via the API.
                # Raise so callers know this is unsupported.
                raise NotImplementedError(
                    f"lowering for DeleteNamedStyleOp not supported — "
                    f"Google Docs API does not support removing a namedStyle. "
                    f"(tab_id={op.tab_id!r}, namedStyleType={op.named_style_type!r})"
                )

            # ---------------------------------------------------------------- #
            # DocumentStyle → batch 1
            # ---------------------------------------------------------------- #
            case UpdateDocumentStyleOp():
                # op.desired_style carries the full desired DocumentStyle;
                # op.fields_mask restricts the update to only changed fields.
                batch1.append(
                    Request(
                        update_document_style=UpdateDocumentStyleRequest(
                            document_style=op.desired_style,
                            fields=op.fields_mask,
                            tab_id=op.tab_id if op.tab_id else None,
                        )
                    )
                )

            # ---------------------------------------------------------------- #
            # Lists — InsertListOp is handled implicitly via paragraph bullets;
            # DeleteListOp can be ignored (bullets are removed via
            # deleteParagraphBullets on content).  UpdateListOp is unsupported.
            # ---------------------------------------------------------------- #
            case InsertListOp():
                # List defs are created implicitly by createParagraphBullets;
                # no explicit request needed.
                pass

            case DeleteListOp():
                # List cleanup is handled implicitly by deleteParagraphBullets
                # on the paragraph content; no explicit request needed here.
                pass

            case UpdateListOp():
                raise NotImplementedError(
                    f"lowering for UpdateListOp not supported — "
                    f"list definitions cannot be edited via batchUpdate. "
                    f"(tab_id={op.tab_id!r}, list_id={op.list_id!r})"
                )

            # ---------------------------------------------------------------- #
            # InlineObjects
            # ---------------------------------------------------------------- #
            case UpdateInlineObjectOp():
                raise NotImplementedError(
                    f"lowering for UpdateInlineObjectOp not supported — "
                    f"inline object properties cannot be edited via batchUpdate. "
                    f"(tab_id={op.tab_id!r}, inline_object_id={op.inline_object_id!r})"
                )

            case InsertInlineObjectOp():
                # Insert an inline image via insertInlineImage → batch 1
                batch1.append(
                    Request(
                        insert_inline_image=InsertInlineImageRequest(
                            uri=op.content_uri,
                            location=Location(
                                index=op.insert_index,
                                segment_id=op.tab_id if op.tab_id else None,
                            ),
                            object_size=op.object_size,
                        )
                    )
                )

            case DeleteInlineObjectOp():
                # Delete the inlineObjectElement (occupies exactly 1 character)
                # via deleteContentRange → batch 1
                batch1.append(
                    _make_delete_content_range(
                        start_index=op.delete_index,
                        end_index=op.delete_index + 1,
                        tab_id=op.tab_id,
                        segment_id=None,
                    )
                )

            # ---------------------------------------------------------------- #
            # Header / footer content updates → batch 1
            # ---------------------------------------------------------------- #
            case UpdateHeaderContentOp():
                batch1.extend(
                    _lower_story_content_update(
                        op.alignment,
                        base_content=op.base_content,
                        desired_content=op.desired_content,
                        tab_id=op.tab_id,
                        segment_id=op.header_id,
                        desired_lists=_desired_lists_by_tab.get(op.tab_id, {}),
                        base_lists=_base_lists_by_tab.get(op.tab_id, {}),
                        in_unsupported_region=True,
                    )
                )

            case UpdateFooterContentOp():
                batch1.extend(
                    _lower_story_content_update(
                        op.alignment,
                        base_content=op.base_content,
                        desired_content=op.desired_content,
                        tab_id=op.tab_id,
                        segment_id=op.footer_id,
                        desired_lists=_desired_lists_by_tab.get(op.tab_id, {}),
                        base_lists=_base_lists_by_tab.get(op.tab_id, {}),
                        in_unsupported_region=True,
                    )
                )

            # ---------------------------------------------------------------- #
            # Footnotes — batch 1b (createFootnote, after body content)
            #           + batch 1b_content (footnote content insertions)
            # ---------------------------------------------------------------- #
            case InsertFootnoteOp():
                if op.anchor_index < 0:
                    raise NotImplementedError(
                        f"lowering for InsertFootnoteOp: anchor_index is unknown "
                        f"(no footnoteReference with index found in desired body). "
                        f"(tab_id={op.tab_id!r}, footnote_id={op.footnote_id!r})"
                    )
                req_index = len(batch1b)
                batch1b.append(
                    _make_create_footnote(
                        index=op.anchor_index,
                        tab_id=op.tab_id,
                    )
                )
                deferred_fn_id = DeferredID(
                    placeholder=f"footnote_{req_index}",
                    # batch_index is set to a sentinel; will be resolved below
                    # once we know which actual batch index batch1b lands on.
                    batch_index=-1,
                    request_index=req_index,
                    response_path="createFootnote.footnoteId",
                )
                batch1b_content.extend(
                    _lower_content_insert(
                        content=op.desired_content,
                        start_index=1,
                        tab_id=op.tab_id,
                        segment_id=deferred_fn_id,
                        in_unsupported_region=True,
                    )
                )

            case DeleteFootnoteOp():
                # Deleting a footnote is done by removing its footnoteReference
                # element (a single character) from the base document body.
                # The footnote story is automatically cleaned up by the API.
                # The base_doc is not available here, so we rely on the op
                # carrying the ref_index set by the diff layer.
                if op.ref_index < 0:
                    raise NotImplementedError(
                        f"lowering for DeleteFootnoteOp: ref_index is unknown "
                        f"(no footnoteReference with index found in base body). "
                        f"(tab_id={op.tab_id!r}, footnote_id={op.footnote_id!r})"
                    )
                # Accumulate footnote-reference deletes instead of immediately
                # appending to batch1.  The UpdateBodyContentOp handler for
                # the same tab will merge them with body content deletes so
                # that all body-segment deletes are globally descending.
                # footnoteReference occupies exactly 1 character.
                _fn_ref_deletes.setdefault(op.tab_id, []).append(
                    (op.ref_index, op.ref_index + 1)
                )

            case UpdateFootnoteContentOp():
                batch1.extend(
                    _lower_story_content_update(
                        op.alignment,
                        base_content=op.base_content,
                        desired_content=op.desired_content,
                        tab_id=op.tab_id,
                        segment_id=op.footnote_id,
                        desired_lists=_desired_lists_by_tab.get(op.tab_id, {}),
                        base_lists=_base_lists_by_tab.get(op.tab_id, {}),
                        in_unsupported_region=True,
                    )
                )

            # ---------------------------------------------------------------- #
            # Body / story content → batch 1
            # ---------------------------------------------------------------- #
            case UpdateBodyContentOp():
                content_to_lower = op.base_content
                if op.story_kind == "table_cell":
                    # Table cell content elements carry body-level BASE
                    # indices. Prior requests in batch1 (body-text edits,
                    # deleteTableRow, insertTableRow) may have shifted these
                    # indices. Compute the cumulative shift and adjust.
                    # Base-tree read: contract guarantees concrete indices.
                    # See docs/coordinate_contract.md §who-reads-what.
                    first_start, _ = _require_concrete(
                        op.base_content[0],
                        context=(
                            f"UpdateBodyContentOp.base_content[0] "
                            f"tab_id={op.tab_id} story_kind={op.story_kind}"
                        ),
                    )
                    shift = _compute_index_shift_for_body_ref(
                        batch1,
                        base_index=first_start,
                        tab_id=op.tab_id,
                        struct_events_by_req_id=struct_events_by_req_id,
                    )
                    if shift != 0:
                        content_to_lower = _shift_elements(op.base_content, shift)
                # Pass any accumulated footnote-reference deletes for this
                # tab so they are merged with body content deletes in globally-
                # descending order.  Only applies to the main body story
                # (story_kind != "table_cell"); table-cell ops already apply
                # an index shift via _compute_index_shift_for_body_ref and
                # don't interact with fn-ref deletes at lower pristine indices.
                _tab_fn_deletes: list[tuple[int, int]] | None = None
                if op.story_kind != "table_cell":
                    _tab_fn_deletes = _fn_ref_deletes.pop(op.tab_id, None)
                    if _tab_fn_deletes is not None:
                        _fn_ref_consumed[op.tab_id] = True
                batch1.extend(
                    _lower_story_content_update(
                        op.alignment,
                        base_content=content_to_lower,
                        desired_content=op.desired_content,
                        tab_id=op.tab_id,
                        segment_id=None,
                        desired_lists=_desired_lists_by_tab.get(op.tab_id, {}),
                        base_lists=_base_lists_by_tab.get(op.tab_id, {}),
                        in_unsupported_region=(op.story_kind == "table_cell"),
                        prior_body_deletes=_tab_fn_deletes,
                    )
                )

            # ---------------------------------------------------------------- #
            # Table structural ops → batch 1
            # ---------------------------------------------------------------- #
            case InsertTableRowOp():
                # Shift BASE table-anchored indices by the cumulative byte
                # delta of body-text ops (and prior same-table structural
                # ops) already in ``batch1``.
                shift_table_start = _compute_index_shift_for_body_ref(
                    batch1,
                    base_index=op.table_start_index,
                    tab_id=op.tab_id,
                    struct_events_by_req_id=struct_events_by_req_id,
                )
                itr_req = _make_insert_table_row(
                    table_start_index=op.table_start_index + shift_table_start,
                    row_index=op.row_index,
                    insert_below=op.insert_below,
                    tab_id=op.tab_id,
                )
                batch1.append(itr_req)
                # Record the structural byte injection this request performs,
                # so later same-table ops can shift their BASE anchors past
                # it. A new row of ``_ROW_OVERHEAD + column_count *
                # _EMPTY_CELL_SIZE`` bytes is inserted at
                # ``new_row_start_index`` (in live post-prior-ops coords),
                # before the cell-fill inserts run.
                if op.new_row_start_index is not None:
                    shift_new_row = _compute_index_shift_for_body_ref(
                        batch1[:-1],  # exclude the req we just appended
                        base_index=op.new_row_start_index,
                        tab_id=op.tab_id,
                        struct_events_by_req_id=struct_events_by_req_id,
                    )
                    live_row_start = op.new_row_start_index + shift_new_row
                    row_bytes = _ROW_OVERHEAD + op.column_count * _EMPTY_CELL_SIZE
                    struct_events_by_req_id[id(itr_req)] = [
                        (op.tab_id, live_row_start, row_bytes)
                    ]
                    # Populate the newly-created cells with the desired text.
                    # ``insertTableRow`` creates an empty row with default
                    # cell layout (per cell: 1 start-overhead byte + "\n"
                    # paragraph = 2 bytes); plus 1 row-overhead byte.
                    batch1.extend(
                        _make_new_row_cell_text_inserts(
                            new_row_start_index=live_row_start,
                            new_cell_texts=op.new_cell_texts,
                            tab_id=op.tab_id,
                        )
                    )

            case DeleteTableRowOp():
                shift = _compute_index_shift_for_body_ref(
                    batch1,
                    base_index=op.table_start_index,
                    tab_id=op.tab_id,
                    struct_events_by_req_id=struct_events_by_req_id,
                )
                dtr_req = _make_delete_table_row(
                    table_start_index=op.table_start_index + shift,
                    row_index=op.row_index,
                    tab_id=op.tab_id,
                )
                batch1.append(dtr_req)
                # Record the structural byte removal so later same-batch
                # ops (cell content updates) can shift their indices.
                if op.row_start_index is not None and op.row_end_index is not None:
                    row_bytes = op.row_end_index - op.row_start_index
                    live_row_start = op.row_start_index + shift
                    # Negative delta: bytes are removed at this position.
                    struct_events_by_req_id[id(dtr_req)] = [
                        (op.tab_id, live_row_start, -row_bytes)
                    ]

            case InsertTableColumnOp():
                shift_table_start = _compute_index_shift_for_body_ref(
                    batch1,
                    base_index=op.table_start_index,
                    tab_id=op.tab_id,
                    struct_events_by_req_id=struct_events_by_req_id,
                )
                itc_req = _make_insert_table_column(
                    table_start_index=op.table_start_index + shift_table_start,
                    column_index=op.column_index,
                    insert_right=op.insert_right,
                    tab_id=op.tab_id,
                )
                batch1.append(itc_req)
                # Populate the newly-created cells with the desired text.
                # ``insertTableColumn`` creates one empty 2-byte cell per
                # row (1 cell-overhead + 1 "\n" paragraph). Each row's new
                # cell lands at a DIFFERENT live byte position; compute the
                # per-row live anchor independently by walking all prior
                # body-text AND prior same-table structural events.
                live_anchors: list[int | None] = []
                for base_anchor in op.new_cell_anchor_indices:
                    if base_anchor is None:
                        live_anchors.append(None)
                        continue
                    row_shift = _compute_index_shift_for_body_ref(
                        batch1[:-1],  # exclude the ITC we just appended
                        base_index=base_anchor,
                        tab_id=op.tab_id,
                        struct_events_by_req_id=struct_events_by_req_id,
                    )
                    live_anchors.append(base_anchor + row_shift)
                # Record THIS ITC's structural byte injections so later ops
                # on the same table can account for them. Row r's new cell
                # lands at ``live_anchors[r] + r * _EMPTY_CELL_SIZE`` in
                # post-event coords (cumulative shift from rows 0..r-1's
                # new cells, each adding _EMPTY_CELL_SIZE bytes).
                events: list[tuple[str, int, int]] = []
                for r, live in enumerate(live_anchors):
                    if live is None:
                        continue
                    events.append(
                        (op.tab_id, live + r * _EMPTY_CELL_SIZE, _EMPTY_CELL_SIZE)
                    )
                if events:
                    struct_events_by_req_id[id(itc_req)] = events
                batch1.extend(
                    _make_new_column_cell_text_inserts(
                        new_cell_anchor_indices=live_anchors,
                        new_cell_texts=op.new_cell_texts,
                        insert_right=op.insert_right,
                        tab_id=op.tab_id,
                    )
                )

            case DeleteTableColumnOp():
                shift = _compute_index_shift_for_body_ref(
                    batch1,
                    base_index=op.table_start_index,
                    tab_id=op.tab_id,
                    struct_events_by_req_id=struct_events_by_req_id,
                )
                batch1.append(
                    _make_delete_table_column(
                        table_start_index=op.table_start_index + shift,
                        column_index=op.column_index,
                        tab_id=op.tab_id,
                    )
                )

            # ---------------------------------------------------------------- #
            # Table style ops → batch 1
            # ---------------------------------------------------------------- #
            case UpdateTableCellStyleOp():
                shift = _compute_index_shift_for_body_ref(
                    batch1,
                    base_index=op.table_start_index,
                    tab_id=op.tab_id,
                    struct_events_by_req_id=struct_events_by_req_id,
                )
                batch1.append(
                    _make_update_table_cell_style(
                        table_start_index=op.table_start_index + shift,
                        row_index=op.row_index,
                        column_index=op.column_index,
                        desired_style=op.desired_style,
                        fields_mask=op.fields_mask,
                        tab_id=op.tab_id,
                    )
                )

            case UpdateTableRowStyleOp():
                shift = _compute_index_shift_for_body_ref(
                    batch1,
                    base_index=op.table_start_index,
                    tab_id=op.tab_id,
                    struct_events_by_req_id=struct_events_by_req_id,
                )
                batch1.append(
                    _make_update_table_row_style(
                        table_start_index=op.table_start_index + shift,
                        row_index=op.row_index,
                        min_row_height=op.min_row_height,
                        tab_id=op.tab_id,
                    )
                )

            case UpdateTableColumnPropertiesOp():
                shift = _compute_index_shift_for_body_ref(
                    batch1,
                    base_index=op.table_start_index,
                    tab_id=op.tab_id,
                    struct_events_by_req_id=struct_events_by_req_id,
                )
                batch1.append(
                    _make_update_table_column_properties(
                        table_start_index=op.table_start_index + shift,
                        column_index=op.column_index,
                        width=op.width,
                        width_type=op.width_type,
                        tab_id=op.tab_id,
                    )
                )

            # ---------------------------------------------------------------- #
            # Named ranges → batch 2 (after content, so indices are stable)
            # ---------------------------------------------------------------- #
            case InsertNamedRangeOp():
                # createNamedRange accepts exactly one Range per request.
                for rng in op.ranges:
                    batch2.append(
                        Request(
                            create_named_range=CreateNamedRangeRequest(
                                name=op.name,
                                range=rng,
                            )
                        )
                    )

            case DeleteNamedRangeOp():
                batch2.append(
                    Request(
                        delete_named_range=DeleteNamedRangeRequest(
                            named_range_id=op.named_range_id,
                        )
                    )
                )

            case _:
                raise NotImplementedError(
                    f"lowering for op type {type(op).__name__!r} not yet implemented"
                )

    # Flush any footnote-reference deletes that were not consumed by an
    # UpdateBodyContentOp (e.g. when all body content is unchanged but some
    # footnotes were deleted).  Sort descending so they are self-consistent.
    for tab_id, fn_deletes in _fn_ref_deletes.items():
        for start, end in sorted(fn_deletes, key=lambda x: x[0], reverse=True):
            batch1.append(
                _make_delete_content_range(
                    start_index=start,
                    end_index=end,
                    tab_id=tab_id,
                    segment_id=None,
                )
            )

    batches: list[list[Request]] = []
    if batch0:
        batches.append(batch0)
    if batch1:
        for sub in _split_on_insert_tables(batch1):
            batches.append(sub)
    if batch1b:
        # Resolve the sentinel batch_index on DeferredIDs in batch1b_content
        # now that we know which batch index batch1b will occupy.
        batch1b_index = len(batches)
        for req in batch1b_content:
            _fix_deferred_batch_index(req, batch1b_index)
        batches.append(batch1b)
    if batch1b_content:
        batches.append(batch1b_content)
    if batch2:
        batches.append(batch2)
    return batches


def _split_on_insert_tables(batch: list[Request]) -> list[list[Request]]:
    """Split a batch into sub-batches so that each ``insertTable`` op and its
    immediately-following cell-fill requests form their own isolated batch.

    ``insertTable`` injects structural byte overhead (cell/row/table boundary
    markers) that shifts all subsequent indices.  When multiple ``insertTable``
    ops appear in the same batch, the structural bytes from each table shift
    the indices for later tables and later ``insertText`` ops.  By isolating
    each table (with its cell fills) in its own batch, we guarantee that each
    batch is self-consistent: the ``insertTable`` runs first, then the
    cell-fill ``insertText`` ops address positions relative to the freshly
    created table — with no stale-index hazard from prior tables.

    The split rule: scan the batch left to right.  When an ``insertTable``
    request is encountered, close the current sub-batch (if non-empty) and
    start a new one beginning with that ``insertTable``.  All subsequent
    requests join this new sub-batch until the next ``insertTable`` is
    encountered or the list is exhausted.

    **Same-index co-location rule**: if the requests immediately preceding
    the ``insertTable`` in the current sub-batch target the *same* document
    index as the ``insertTable`` itself, they must stay with the
    ``insertTable`` in the new sub-batch — not in the closing sub-batch.
    Concretely, ``lower_batches`` emits a bare ``insertText@N: '\\n'`` as the
    paragraph-separator that precedes a new table at index N.  If that
    ``insertText`` lands in sub-batch A while the ``insertTable@N`` starts
    sub-batch B, sub-batch A inserts a ``\\n`` at N first, which shifts the
    document so the table opener in sub-batch B lands one position off.  The
    cell-fill ``insertText`` ops in sub-batch B were computed assuming the
    ``insertTable`` created the pre-``\\n`` itself (at N+0) — they break when
    the ``\\n`` was already injected by the prior sub-batch.

    If the batch contains no ``insertTable`` requests, the original batch is
    returned as-is (wrapped in a single-element list).
    """
    if not any(r.insert_table is not None for r in batch):
        return [batch]

    def _req_index(r: Request) -> int | None:
        if r.insert_text is not None and r.insert_text.location is not None:
            idx = r.insert_text.location.index
            return idx if isinstance(idx, int) else None
        if r.insert_table is not None and r.insert_table.location is not None:
            idx = r.insert_table.location.index
            return idx if isinstance(idx, int) else None
        return None

    result: list[list[Request]] = []
    current: list[Request] = []

    for req in batch:
        if req.insert_table is not None:
            # Move any trailing same-index requests from current into the new
            # sub-batch so they stay co-located with the insertTable.
            table_index = _req_index(req)
            carry: list[Request] = []
            if table_index is not None:
                while current and _req_index(current[-1]) == table_index:
                    carry.append(current.pop())
                carry.reverse()
            if current:
                result.append(current)
            current = [*carry, req]
        else:
            current.append(req)

    if current:
        result.append(current)

    return result


def _fix_deferred_batch_index(req: Request, target_batch_index: int) -> None:
    """Walk a Request and fix any DeferredID with batch_index == -1.

    Used to resolve the sentinel batch_index on DeferredID placeholders
    created for createFootnote requests, once we know the actual batch index.
    """

    def _walk(obj: object) -> None:
        if isinstance(obj, DeferredID):
            if obj.batch_index == -1:
                # DeferredID is frozen; use object.__setattr__ to bypass
                object.__setattr__(obj, "batch_index", target_batch_index)
            return
        # Walk Pydantic model fields
        model_fields = getattr(type(obj), "model_fields", None)
        if model_fields is not None:
            for field_name in model_fields:
                val = getattr(obj, field_name, None)
                if val is not None:
                    _walk(val)
        elif isinstance(obj, list):
            for item in obj:
                _walk(item)

    _walk(req)


def _lower_one(op: DiffOp) -> list[Request]:
    """Lower a single op to zero or more Request objects (single-batch mode).

    This is a convenience wrapper around ``lower_batches`` that flattens all
    batches into one list.  It raises for ops that cannot be lowered.
    """
    batches = lower_batches([op])
    return [req for batch in batches for req in batch]


# ---------------------------------------------------------------------------
# Bullet preset helpers (ported from reconcile/_generators.py)
# ---------------------------------------------------------------------------

# Maps level-0 glyphType to the createParagraphBullets preset string
_GLYPH_TYPE_TO_PRESET: dict[str, str] = {
    "DECIMAL": "NUMBERED_DECIMAL_NESTED",
    "UPPER_ALPHA": "NUMBERED_UPPERALPHA_ALPHA_ROMAN",
    "ALPHA": "NUMBERED_DECIMAL_ALPHA_ROMAN",
    "UPPER_ROMAN": "NUMBERED_UPPERROMAN_UPPERALPHA_DECIMAL",
    "ROMAN": "NUMBERED_UPPERROMAN_UPPERALPHA_DECIMAL",
    "ZERO_DECIMAL": "NUMBERED_ZERODECIMAL_ALPHA_ROMAN",
}

# Maps level-0 glyphSymbol to the createParagraphBullets preset string
_GLYPH_SYMBOL_TO_PRESET: dict[str, str] = {
    "●": "BULLET_DISC_CIRCLE_SQUARE",
    "❖": "BULLET_DIAMONDX_ARROW3D_SQUARE",
    "☐": "BULLET_CHECKBOX",
    "➔": "BULLET_ARROW_DIAMOND_DISC",
    "★": "BULLET_STAR_CIRCLE_SQUARE",
    "➢": "BULLET_ARROW3D_CIRCLE_SQUARE",
    "◀": "BULLET_LEFTTRIANGLE_DIAMOND_DISC",
}

_DEFAULT_BULLET_PRESET = "BULLET_DISC_CIRCLE_SQUARE"


def _infer_bullet_preset_from_model(bullet: Bullet, lists: dict[str, DocList]) -> str:
    """Infer the createParagraphBullets preset from a typed Bullet and lists."""
    list_id = bullet.list_id
    if not list_id or not lists or list_id not in lists:
        return _DEFAULT_BULLET_PRESET

    list_obj = lists[list_id]
    lp = list_obj.list_properties
    if not lp:
        return _DEFAULT_BULLET_PRESET
    nesting = lp.nesting_levels
    if not nesting:
        return _DEFAULT_BULLET_PRESET
    level_0 = nesting[0]
    glyph_type: str = level_0.glyph_type or ""
    glyph_symbol: str = level_0.glyph_symbol or ""

    # Numbered list: a real glyphType is set (not NONE / GLYPH_TYPE_UNSPECIFIED)
    if glyph_type and glyph_type not in ("GLYPH_TYPE_UNSPECIFIED", "NONE", ""):
        return _GLYPH_TYPE_TO_PRESET.get(glyph_type, "NUMBERED_DECIMAL_NESTED")

    # Checkbox: GLYPH_TYPE_UNSPECIFIED with no glyph symbol
    if glyph_type == "GLYPH_TYPE_UNSPECIFIED":
        return "BULLET_CHECKBOX"

    # Unordered: glyph symbol determines the preset
    if glyph_symbol:
        return _GLYPH_SYMBOL_TO_PRESET.get(glyph_symbol, _DEFAULT_BULLET_PRESET)

    return _DEFAULT_BULLET_PRESET


def _make_create_paragraph_bullets(
    *,
    start: int,
    end: int,
    preset: str,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
) -> Request:
    """Build a createParagraphBullets Request."""
    return Request(
        create_paragraph_bullets=CreateParagraphBulletsRequest(
            range=Range(
                start_index=start,
                end_index=end,
                tab_id=tab_id if tab_id else None,
                segment_id=segment_id if segment_id else None,
            ),
            bullet_preset=CreateParagraphBulletsRequestBulletPreset(preset),
        )
    )


def _make_delete_paragraph_bullets(
    *,
    start: int,
    end: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
) -> Request:
    """Build a deleteParagraphBullets Request."""
    return Request(
        delete_paragraph_bullets=DeleteParagraphBulletsRequest(
            range=Range(
                start_index=start,
                end_index=end,
                tab_id=tab_id if tab_id else None,
                segment_id=segment_id if segment_id else None,
            ),
        )
    )


# ---------------------------------------------------------------------------
# Content update helpers
# ---------------------------------------------------------------------------


def _lower_story_content_update(
    alignment: ContentAlignment,
    *,
    base_content: list[StructuralElement],
    desired_content: list[StructuralElement],
    tab_id: str,
    segment_id: str | None,
    desired_lists: dict[str, DocList] | None = None,
    base_lists: dict[str, DocList] | None = None,
    in_unsupported_region: bool = False,
    prior_body_deletes: list[tuple[int, int]] | None = None,
) -> list[Request]:
    """Lower a ContentAlignment into delete/insert/update Request objects.

    Strategy
    --------
    We process operations in reverse document order (highest index first) so
    that each deletion/insertion does not affect the indices of earlier
    elements.

    1. Delete elements in ``alignment.base_deletes`` (in reverse order).
    2. Insert elements in ``alignment.desired_inserts`` at the appropriate
       position in the post-deletion document.
    3. Update matched elements whose content differs (in-place text replacement).

    Only paragraphs with simple text runs are fully lowered.  Tables and other
    structural elements raise ``NotImplementedError`` for insert/update — delete
    is always supported via ``deleteContentRange``.

    Index arithmetic
    ----------------
    The base content elements carry ``startIndex``/``endIndex`` from the
    Google Docs API response.  We use these directly for deletions.  For
    insertions, we compute the target position based on the surrounding matched
    elements.

    The terminal paragraph (last element) is never deleted — it is always
    matched.  Insertions before the terminal are handled by inserting before
    the terminal's startIndex.

    ``prior_body_deletes`` is an optional list of ``(start, end)`` pristine
    position pairs for body-segment deletes from other ops (e.g.
    ``DeleteFootnoteOp`` footnote-reference deletions) that will run in the
    same batch.  When provided:

    - The corresponding ``deleteContentRange`` requests are merged with this
      op's own deletes, sorted globally in descending document order so that
      no delete invalidates a later delete's index.
    - Insert and match-update positions are adjusted to account for ALL
      body-segment deletes (not just this op's own) at positions below the
      target.

    Only meaningful when ``segment_id is None`` (body segment).
    """
    requests: list[Request] = []

    # Compute own-delete ranges (pristine positions) for use in the
    # prior-delete filter below.  Apply the same SB-adjacent truncation that
    # the actual delete-request generation uses so the containment check
    # matches what actually gets emitted.
    own_delete_ranges: list[tuple[int, int]] = []
    for base_idx in alignment.base_deletes:
        el = base_content[base_idx]
        # Base-tree read: contract guarantees concrete indices.
        # See docs/coordinate_contract.md §who-reads-what.
        start, end = _require_concrete(
            el,
            context=(
                f"_lower_story_content_update own_delete_ranges base_idx={base_idx}"
            ),
        )
        next_el = (
            base_content[base_idx + 1] if base_idx + 1 < len(base_content) else None
        )
        if (
            next_el is not None
            and next_el.section_break is not None
            and end - start > 1
        ):
            end = end - 1
        if end > start:
            own_delete_ranges.append((start, end))

    # Build prior-delete requests (from e.g. DeleteFootnoteOp) so we can
    # merge them with this op's own deletes in globally-descending order.
    # Filter out any prior delete whose range is entirely contained within an
    # own-delete range: the enclosing paragraph delete will remove that content
    # anyway, and emitting the prior delete first (due to higher index) would
    # shrink the paragraph range and make the own-delete range invalid.
    prior_reqs_with_start: list[tuple[int, Request]] = []
    # Also track which prior_body_deletes are actually emitted (vs. subsumed),
    # so the insert-offset calculation only counts the ones that will run.
    effective_prior_deletes: list[tuple[int, int]] = []
    if prior_body_deletes and segment_id is None:
        for pr_start, pr_end in prior_body_deletes:
            subsumed = any(
                own_start <= pr_start and pr_end <= own_end
                for own_start, own_end in own_delete_ranges
            )
            if subsumed:
                # This fn-ref is inside a paragraph that will be deleted
                # wholesale; skip it to avoid shrinking that paragraph range.
                continue
            effective_prior_deletes.append((pr_start, pr_end))
            prior_reqs_with_start.append(
                (
                    pr_start,
                    _make_delete_content_range(
                        start_index=pr_start,
                        end_index=pr_end,
                        tab_id=tab_id,
                        segment_id=None,
                    ),
                )
            )

    # Sort own deletes in descending document position order so each delete
    # does not invalidate indices for subsequent deletes.
    own_deletes_with_start: list[tuple[int, int, Request]] = []
    for base_idx in alignment.base_deletes:
        el = base_content[base_idx]
        # Base-tree read: contract guarantees concrete indices. A None here
        # is an invariant violation (see docs/coordinate_contract.md §who-reads-what).
        start, end = _require_concrete(
            el,
            context=(f"_lower_story_content_update base_delete base_idx={base_idx}"),
        )
        # The Google Docs API forbids deleting the ``\n`` immediately preceding
        # a SectionBreak.  When the element to delete ends exactly where a
        # SectionBreak begins (its ``\n`` is that preceding newline), truncate
        # the delete range to ``[start, end-1)`` so the ``\n`` survives and the
        # API request is accepted.  The leftover empty paragraph is harmless
        # structurally (it is the required separator before the section break).
        next_el = (
            base_content[base_idx + 1] if base_idx + 1 < len(base_content) else None
        )
        if (
            next_el is not None
            and next_el.section_break is not None
            and end - start > 1  # only truncate when content exists besides the \n
        ):
            end = end - 1  # exclude the \n immediately before the SB
        if start >= end:
            # Nothing to delete (paragraph was only the \n before a SB).
            continue
        own_deletes_with_start.append(
            (
                start,
                end,
                _make_delete_content_range(
                    start_index=start,
                    end_index=end,
                    tab_id=tab_id,
                    segment_id=segment_id,
                ),
            )
        )

    # Merge prior and own deletes, emitting them globally descending by start.
    # prior_reqs_with_start contains (start, req) for external deletes;
    # own_deletes_with_start contains (start, end, req) for this op's deletes.
    all_delete_reqs: list[tuple[int, Request]] = [
        (s, r) for s, _e, r in own_deletes_with_start
    ] + prior_reqs_with_start
    all_delete_reqs.sort(key=lambda x: x[0], reverse=True)
    for _start, req in all_delete_reqs:
        requests.append(req)

    # Insertions: we need to find where to insert each desired element.
    # Strategy: for each desired_insert index, find the closest preceding
    # matched element and insert after it, or before the terminal if none.
    #
    # We process inserts in ascending order (they are into the post-deletion
    # document).  Since we process deletes first (in reverse), the base indices
    # have been consumed; the positions of surviving elements shift by the
    # cumulative character count deleted before them.
    #
    # For simplicity in this v3 experiment, we use the desired element's text
    # and find the insertion point using the base document's known element
    # indices BEFORE deletions, then apply an offset for the characters deleted
    # before that point.
    #
    # We compute the insertion point for each desired_insert by looking at the
    # alignment: find the last matched base element whose base_idx < the
    # "virtual" position and use its endIndex (adjusted for prior deletions).

    insert_metadata: list[tuple[int, int]] = []
    if alignment.desired_inserts:
        # Build a map from desired_idx → base insertion point (startIndex of
        # the NEXT surviving base element after where we want to insert).
        # For the simple case, we insert before the next matched element or
        # before the terminal.
        insert_requests, insert_metadata = _plan_insertions(
            alignment=alignment,
            base_content=base_content,
            desired_content=desired_content,
            tab_id=tab_id,
            segment_id=segment_id,
            desired_lists=desired_lists or {},
            in_unsupported_region=in_unsupported_region,
            prior_delete_ranges=effective_prior_deletes or None,
        )
        requests.extend(insert_requests)

    # Handle matched elements whose content differs (text updates).
    # The update requests must use coordinates that account for whole-element
    # deletions (base_deletes) applied earlier in this batch.  Compute the
    # number of characters deleted BEFORE each matched element's startIndex so
    # we can shift the generated request indices accordingly.
    deleted_sizes: dict[int, int] = {}
    for base_idx in alignment.base_deletes:
        el = base_content[base_idx]
        # Base-tree read: contract guarantees concrete indices. A None here
        # is an invariant violation (see docs/coordinate_contract.md §who-reads-what).
        start, end = _require_concrete(
            el,
            context=(f"_lower_story_content_update deleted_sizes base_idx={base_idx}"),
        )
        # Apply the same SB-adjacent truncation used when emitting the actual
        # delete request so that shift calculations reflect the real deletion.
        next_el_for_ds = (
            base_content[base_idx + 1] if base_idx + 1 < len(base_content) else None
        )
        if (
            next_el_for_ds is not None
            and next_el_for_ds.section_break is not None
            and end - start > 1
        ):
            end = end - 1
        deleted_sizes[base_idx] = max(0, end - start)

    # Process matched element updates in DESCENDING start-index order.
    # Each in-place paragraph update may grow or shrink the paragraph.  If we
    # processed in ascending order, a size change in paragraph N would shift
    # the indices of paragraph N+1, making the pre-computed requests for N+1
    # use stale positions.  Descending order ensures that updates to later
    # (higher-index) elements are emitted first; a size change there only
    # affects positions below it, which we haven't emitted yet — so they will
    # use the correct original positions (no cumulative shift needed).
    # Base-tree read: contract guarantees concrete indices.
    # See docs/coordinate_contract.md §who-reads-what.
    def _match_start(m: object) -> int:
        s, _ = _require_concrete(
            base_content[m.base_idx],  # type: ignore[attr-defined]
            context=(
                f"_lower_story_content_update match sort base_idx={m.base_idx}"  # type: ignore[attr-defined]
            ),
        )
        return s

    matches_desc = sorted(
        alignment.matches,
        key=_match_start,
        reverse=True,
    )
    for match in matches_desc:
        b_el = base_content[match.base_idx]
        d_el = desired_content[match.desired_idx]
        if b_el == d_el:
            continue
        # Base-tree read: contract guarantees concrete indices.
        # See docs/coordinate_contract.md §who-reads-what.
        b_el_start, _ = _require_concrete(
            b_el,
            context=(
                f"_lower_story_content_update match update base_idx={match.base_idx}"
            ),
        )
        shift = _deleted_chars_before(
            deleted_sizes=deleted_sizes,
            base_content=base_content,
            before_pos=b_el_start,
            prior_delete_ranges=effective_prior_deletes or None,
        )
        post_insert_shift = _inserted_chars_before_or_at(
            insert_metadata=insert_metadata,
            before_pos=b_el_start,
        )
        update_reqs = _lower_element_update(
            base_el=b_el,
            desired_el=d_el,
            tab_id=tab_id,
            segment_id=segment_id,
            pre_delete_shift=shift,
            post_insert_shift=post_insert_shift,
            desired_lists=desired_lists or {},
            base_lists=base_lists or {},
            in_unsupported_region=in_unsupported_region,
        )
        requests.extend(update_reqs)

    return requests


def _plan_insertions(
    *,
    alignment: ContentAlignment,
    base_content: list[StructuralElement],
    desired_content: list[StructuralElement],
    tab_id: str,
    segment_id: str | None,
    desired_lists: dict[str, DocList] | None = None,
    in_unsupported_region: bool = False,
    prior_delete_ranges: list[tuple[int, int]] | None = None,
) -> tuple[list[Request], list[tuple[int, int]]]:
    """Plan insertion requests for desired_inserts.

    For each desired index to insert, we determine the insertion position in
    the base document's coordinate space (before deletes are applied) and
    generate an insertText or insertTable request.

    The net offset calculation
    --------------------------
    After processing all deletes (highest first), positions shift.  We must
    adjust the insertion indices by the total characters deleted BEFORE the
    target position.

    Since we cannot easily compute post-delete positions without simulating
    the entire batchUpdate, we use a forward-pass approach:

    - Sort desired_inserts ascending.
    - For each insert, find the base index to insert BEFORE by looking at the
      alignment for the nearest match or using the terminal element.
    - Compute offset adjustment = sum of sizes of deleted base elements whose
      startIndex < insertion_point.

    This gives the correct insertion index after all deletes have been applied.
    Always uses explicit indices — the real terminal paragraph has a real
    startIndex that is a valid insertion point.
    """
    if not alignment.desired_inserts:
        return [], []

    # Build sorted list of matched (base_idx, desired_idx) pairs
    matches_sorted = sorted(alignment.matches, key=lambda m: m.desired_idx)

    # Precompute sizes of deleted elements (for offset adjustment).
    # Apply the same SB-adjacent truncation used when emitting delete requests:
    # when an element's trailing \n is immediately before a SectionBreak, the
    # actual delete omits that \n, so the effective deleted size is one less.
    deleted_sizes: dict[int, int] = {}
    for base_idx in alignment.base_deletes:
        el = base_content[base_idx]
        # Base-tree read: contract guarantees concrete indices. A None here
        # is an invariant violation (see docs/coordinate_contract.md §who-reads-what).
        start, end = _require_concrete(
            el,
            context=f"_plan_insertions deleted_sizes base_idx={base_idx}",
        )
        next_el = (
            base_content[base_idx + 1] if base_idx + 1 < len(base_content) else None
        )
        if (
            next_el is not None
            and next_el.section_break is not None
            and end - start > 1
        ):
            end = end - 1
        deleted_sizes[base_idx] = max(0, end - start)

    # Phase 1: Compute (insert_pos, desired_idx, element_requests) for each insert.
    # We collect them first so we can reorder within same-position groups.
    planned: list[tuple[int, int, list[Request]]] = []
    # Metadata for post_insert_shift computation: list of
    # (raw_insert_pos, insert_size) — one tuple per planned insert, where
    # raw_insert_pos is in BASE coordinates (before delete shift).
    insert_metadata: list[tuple[int, int]] = []

    for desired_idx in sorted(alignment.desired_inserts):
        # Find the base insertion point: the startIndex of the next surviving
        # base element after this desired_idx in the alignment.
        # "after this desired_idx" = first match with desired_idx > desired_idx.
        insert_before_base_idx: int | None = None
        for m in matches_sorted:
            if m.desired_idx > desired_idx:
                insert_before_base_idx = m.base_idx
                break

        # Base-tree reads: contract guarantees concrete indices.
        # See docs/coordinate_contract.md §who-reads-what.
        if insert_before_base_idx is not None:
            base_el = base_content[insert_before_base_idx]
            raw_insert_pos, _ = _require_concrete(
                base_el,
                context=(
                    f"_plan_insertions anchor desired_idx={desired_idx} "
                    f"base_idx={insert_before_base_idx}"
                ),
            )
        else:
            # Insert before terminal (last element in base_content)
            terminal = base_content[-1]
            raw_insert_pos, _ = _require_concrete(
                terminal,
                context=(f"_plan_insertions terminal anchor desired_idx={desired_idx}"),
            )

        # Adjust for characters deleted before this insertion point.
        # Include both this op's own deletes and any prior body-segment deletes
        # (e.g. footnote-reference deletes from DeleteFootnoteOp) that will run
        # in the same batch before this insert.
        offset = _deleted_chars_before(
            deleted_sizes=deleted_sizes,
            base_content=base_content,
            before_pos=raw_insert_pos,
            prior_delete_ranges=prior_delete_ranges,
        )
        insert_pos = raw_insert_pos - offset

        d_el = desired_content[desired_idx]
        reqs = _lower_element_insert(
            el=d_el,
            index=insert_pos,
            tab_id=tab_id,
            segment_id=segment_id,
            desired_lists=desired_lists or {},
            in_unsupported_region=in_unsupported_region,
        )
        planned.append((insert_pos, desired_idx, reqs))
        insert_metadata.append((raw_insert_pos, _batch_insert_size_from_reqs(reqs)))

    # Phase 2: Emit requests in the correct order.
    #
    # When multiple elements are inserted at the SAME index, Google Docs
    # processes requests sequentially.  Each insertText(index=X) pushes all
    # existing content at X upward.  So inserting [A, B, C] all at X gives the
    # final order [C, B, A] — reversed.
    #
    # Fix: within a same-position group, reverse the emission order (emit the
    # element that should appear LAST first).  Elements with different target
    # positions are emitted in ascending position order (lower positions first),
    # which is correct because inserting at a lower position does not affect the
    # absolute position of a later insert at a higher position.
    #
    # Additionally, when multiple consecutive items in the same logical list are
    # all inserted at the same position, we must emit a SINGLE createParagraphBullets
    # covering the entire range.  Individual per-item calls create separate lists.
    requests: list[Request] = []

    # Sort entries by insert_pos DESCENDING, then desired_idx ascending within a group.
    #
    # Rationale: requests are processed sequentially by the API.  Inserting at
    # a lower position shifts all higher-position content rightward, which would
    # corrupt positions in subsequent requests.  By emitting from the HIGHEST
    # position down to the LOWEST, each group's requests run before any
    # lower-position group can shift its content.  Within a same-position group
    # we still need the items in their original desired_idx order (so that the
    # final reverse-insertion trick places them correctly).
    planned.sort(key=lambda t: (-t[0], t[1]))
    for _pos, group_iter in groupby(planned, key=lambda t: t[0]):
        group = list(group_iter)
        # Within the group, emit in REVERSE desired_idx order so that the first
        # desired element ends up first after all same-position inserts land.
        # We split each element's reqs into: insertText, createParagraphBullets,
        # and style requests (updateParagraphStyle, updateTextStyle).  Same-list
        # items have their createParagraphBullets merged into a single call.
        requests.extend(_emit_same_position_group(group))

    return requests, insert_metadata


def _shift_request_indices(
    reqs: list[Request],
    offset: int,
) -> list[Request]:
    """Return copies of style requests with all index values shifted by ``offset``.

    Only shifts ``updateParagraphStyle`` and ``updateTextStyle`` requests.
    Other request types are returned unchanged.  The shift is applied to the
    ``range`` field's ``startIndex`` and ``endIndex``.
    """
    if offset == 0:
        return reqs

    shifted: list[Request] = []
    for req in reqs:
        if req.update_paragraph_style is not None or req.update_text_style is not None:
            req = copy.deepcopy(req)
            inner = req.update_paragraph_style or req.update_text_style
            assert inner is not None
            rng = inner.range
            if rng is not None:
                if rng.start_index is not None:
                    rng.start_index += offset
                if rng.end_index is not None:
                    rng.end_index += offset
        shifted.append(req)
    return shifted


def _get_insert_text_content(req: Request) -> str | None:
    """Extract the text from an insertText request, or None."""
    if req.insert_text is not None and req.insert_text.text is not None:
        return req.insert_text.text
    return None


def _count_leading_tabs(text: str) -> int:
    """Count leading '\\t' characters in ``text``.

    Used to predict how many characters createParagraphBullets will strip from
    a paragraph when converting it to a list item at a given nesting level.
    """
    n = 0
    while n < len(text) and text[n] == "\t":
        n += 1
    return n


def _get_create_bullets_info(
    req: Request,
) -> tuple[str, str, str | DeferredID | None] | None:
    """Extract (preset, tab_id_str, segment_id) from a createParagraphBullets request.

    Returns None if the request is not createParagraphBullets.
    """
    if req.create_paragraph_bullets is None:
        return None
    cb = req.create_paragraph_bullets
    preset = str(cb.bullet_preset) if cb.bullet_preset else ""
    tab_id = ""
    segment_id = None
    if cb.range is not None:
        tab_id_val = cb.range.tab_id
        tab_id = str(tab_id_val) if tab_id_val is not None else ""
        segment_id = cb.range.segment_id
    return (preset, tab_id, segment_id)


def _final_doc_size_from_reqs(reqs: list[Request]) -> int:
    """Compute how many UTF-16 code units this element occupies in the final doc.

    Sums contributions from ``insertText`` (text length), ``insertTable``
    (empty-table structural size, counted as emitted by insertTable: 1 pre-\\n
    + table_opener + rows*(row_opener + cols*cell_size) + trailing \\n, where
    cell_size starts at 2 for an empty cell but grows with cell-content
    ``insertText``s that follow), and page/section break inserts.
    """
    total = 0
    for req in reqs:
        if req.insert_text is not None:
            total += utf16_len(req.insert_text.text or "")
        elif req.insert_table is not None:
            it = req.insert_table
            rows = it.rows or 0
            cols = it.columns or 0
            # Empty table as emitted by insertTable: pre-\n (1) + table opener
            # (1) + rows * (row opener (1) + cols * (cell opener (1) +
            # terminal \n (1))) + trailing \n (1).
            total += 2 + rows * (1 + cols * 2) + 1
        elif req.insert_page_break is not None:
            total += 2
        elif req.insert_section_break is not None:
            total += 1
    return total


def _batch_insert_size_from_reqs(reqs: list[Request]) -> int:
    """Compute the net UTF-16 size added to the story segment by this element's
    requests, measured as the sum of each insert request's own contribution.

    Differs from ``_final_doc_size_from_reqs`` in how ``insertTable`` is
    counted: here we count only the table skeleton as the API delta
    (``1 + rows * (1 + cols * 2)``), matching the request-level accounting
    used by the matched-element post_insert_shift.  We do NOT add the
    pre-paragraph \\n or trailing carrier paragraph here — those are either
    absorbed into the existing paragraph structure or emitted as separate
    ``insertText`` requests already counted above.
    """
    total = 0
    for req in reqs:
        if req.insert_text is not None:
            total += utf16_len(req.insert_text.text or "")
        elif req.insert_table is not None:
            it = req.insert_table
            rows = it.rows or 0
            cols = it.columns or 0
            total += 1 + rows * (1 + cols * 2)
        elif req.insert_page_break is not None:
            total += 2
        elif req.insert_section_break is not None:
            total += 1
    return total


def _is_insert_request(req: Request) -> bool:
    """True if this request inserts characters into the document."""
    return (
        req.insert_text is not None
        or req.insert_table is not None
        or req.insert_page_break is not None
        or req.insert_section_break is not None
    )


def _shift_post_insert_request(req: Request, offset: int) -> Request:
    """Shift the index range of a non-insert request by ``offset``.

    Used for requests that run AFTER all inserts have happened in the same
    batch (style updates, createParagraphBullets).  These were generated as
    if the element were at ``base_pos``; they need to point at
    ``base_pos + offset`` where the element actually ends up after all
    same-position inserts complete.
    """
    if offset == 0:
        return req
    if req.update_paragraph_style is not None or req.update_text_style is not None:
        req = copy.deepcopy(req)
        inner = req.update_paragraph_style or req.update_text_style
        assert inner is not None
        rng = inner.range
        if rng is not None:
            if rng.start_index is not None:
                rng.start_index += offset
            if rng.end_index is not None:
                rng.end_index += offset
        return req
    if req.create_paragraph_bullets is not None:
        req = copy.deepcopy(req)
        cb = req.create_paragraph_bullets
        assert cb is not None
        rng = cb.range
        if rng is not None:
            if rng.start_index is not None:
                rng.start_index += offset
            if rng.end_index is not None:
                rng.end_index += offset
        return req
    return req


def _emit_same_position_group(
    group: list[tuple[int, int, list[Request]]],
) -> list[Request]:
    """Emit requests for a same-position insertion group.

    For bullet items that all share the same preset+tab, we suppress individual
    createParagraphBullets calls and emit a SINGLE call that covers the total
    inserted text range.  This ensures all same-preset items land in the SAME
    Google Docs list rather than each getting their own list.

    The ordering:
    1. All insertText calls in reverse desired_idx order (so item 1 ends up first)
    2. One merged createParagraphBullets per distinct (preset, tabId) combination,
       covering the full range of items in that list
    3. All style requests (updateParagraphStyle, updateTextStyle)

    Items in different lists (different presets) or non-bullet items fall back to
    the standard per-element order within their own group.
    """
    if len(group) == 1:
        # Single item — no merging needed
        return group[0][2]

    # Classify each element: "simple" = exactly one insertText and no
    # insertTable/page-break/section-break.  A simple element is a plain
    # paragraph that fits the bullet-merge optimisation.  Anything else
    # (tables with cell content, page breaks, section breaks) is "complex"
    # and must emit its requests atomically.
    def _is_simple(reqs: list[Request]) -> bool:
        num_ins_text = 0
        for r in reqs:
            if r.insert_text is not None:
                num_ins_text += 1
            elif (
                r.insert_table is not None
                or r.insert_page_break is not None
                or r.insert_section_break is not None
            ):
                return False
        return num_ins_text == 1

    if not all(_is_simple(reqs) for _, _, reqs in group):
        # Complex mixed group (tables among paragraphs, etc.).
        #
        # ``group`` is sorted by desired_idx ascending.  We must insert items
        # in REVERSE desired_idx order at ``base_pos`` so the final document
        # order matches desired order.  Each element's requests contain both
        # insert-type and post-insert-type requests; within the batch, the
        # API processes requests sequentially, so we can emit each element's
        # requests contiguously.  Crucially, a table's cell-content
        # ``insertText``s MUST follow its ``insertTable`` (they reference
        # indices relative to the table's position at the moment it was
        # inserted).
        #
        # After all inserts complete, element i (in desired order) lives at
        # ``base_pos + cumulative_i`` where cumulative_i is the combined size
        # of desired elements 0..i-1.  Post-insert requests (style updates,
        # createParagraphBullets) were generated assuming the element is at
        # ``base_pos``; we shift their ranges by cumulative_i.
        lens = [_final_doc_size_from_reqs(reqs) for _, _, reqs in group]
        out_inserts: list[Request] = []
        out_post: list[Request] = []
        # Emit in reverse desired order (= reverse of group order).
        for i in range(len(group) - 1, -1, -1):
            _, _, reqs = group[i]
            cumulative = sum(lens[:i])
            for req in reqs:
                if _is_insert_request(req):
                    out_inserts.append(req)
                else:
                    out_post.append(_shift_post_insert_request(req, cumulative))
        return out_inserts + out_post

    # All-simple (paragraph) path: the bullet-merge optimisation.
    # Per-element structure: (insert_req, create_bullets_req_or_None, style_reqs)
    per_element: list[tuple[Request, Request | None, list[Request]]] = []

    for _insert_pos, _desired_idx, reqs in reversed(group):
        ins: Request | None = None
        cb: Request | None = None
        style_reqs: list[Request] = []
        for req in reqs:
            if req.insert_text is not None:
                ins = req
            elif req.create_paragraph_bullets is not None:
                cb = req
            else:
                style_reqs.append(req)
        if ins is not None:
            per_element.append((ins, cb, style_reqs))

    # Now per_element[0] = LAST desired item (inserted first at P), so after all
    # inserts, the DOCUMENT ORDER is the reverse of per_element's order.
    # We need to compute positions in document order (ascending desired_idx).
    # The items in document order (desired order) are: reversed(per_element).
    desired_order = list(reversed(per_element))

    # Compute each item's document position = base_pos + cumulative len of prior items.
    # The base position is the insert_pos from the group (all items share the same pos).
    base_pos = group[0][0]  # insert_pos from the first planned entry

    combined_insert_texts: list[Request] = []
    merged_create_bullets: list[Request] = []
    all_style_reqs: list[Request] = []

    # Collect insertTexts in the reversed order (as they will be emitted)
    for ins_req, _cb, _s in per_element:
        combined_insert_texts.append(ins_req)

    # Compute merged createParagraphBullets by grouping consecutive same-preset
    # items in DESIRED (document) order, with correct cumulative offsets.
    #
    # Index bookkeeping accounts for leading-tab stripping performed by
    # createParagraphBullets: bullet items with nesting > 0 are inserted with
    # "\t" * nesting at the start; createParagraphBullets removes those tabs
    # and sets the nesting level from them.  That shortens the document.
    #
    #   cumulative_tabbed    — sum of insert_text lengths (tabs included) for
    #                          all items processed so far, expressed in the
    #                          inserted-but-not-yet-stripped coordinate system.
    #   cumulative_tabs      — total leading tabs that will be stripped for
    #                          all items processed so far.
    #
    # Post-strip position of item k = base_pos + cumulative_tabbed_k
    #                                          - cumulative_tabs_k.
    #
    # Style requests run AFTER every createParagraphBullets in the batch, so
    # their ranges must use fully-stripped positions.  A createParagraphBullets
    # for run R must use pre-strip-of-R positions for its own range (since it
    # processes its own tabs) but must account for strips performed by prior
    # runs.
    cumulative_tabbed = 0
    cumulative_tabs = 0
    i = 0
    while i < len(desired_order):
        ins_req, cb_req, s_reqs = desired_order[i]
        text_content = _get_insert_text_content(ins_req) or ""
        item_len = utf16_len(text_content)
        item_tabs = _count_leading_tabs(text_content) if cb_req is not None else 0
        # Style reqs use fully-stripped positions.
        all_style_reqs.extend(
            _shift_request_indices(s_reqs, cumulative_tabbed - cumulative_tabs)
        )
        if cb_req is None:
            cumulative_tabbed += item_len
            i += 1
            continue
        # Start of a bullet run — collect consecutive items with the same preset
        cb_info = _get_create_bullets_info(cb_req)
        assert cb_info is not None
        preset, tab_id_str, segment_id = cb_info
        # createParagraphBullets's own range is in pre-strip-of-this-run
        # coordinates, so it must NOT subtract this run's own tabs.  But it
        # must subtract tabs stripped by earlier, already-completed runs.
        run_start = base_pos + cumulative_tabbed - cumulative_tabs
        run_len = item_len
        run_tabs = item_tabs
        inner_tabbed = item_len
        inner_tabs = item_tabs
        j = i + 1
        while j < len(desired_order):
            next_ins, next_cb, next_s_reqs = desired_order[j]
            if next_cb is None:
                break
            next_cb_info = _get_create_bullets_info(next_cb)
            assert next_cb_info is not None
            next_preset, next_tab, next_seg = next_cb_info
            if (next_preset, next_tab, str(next_seg) if next_seg else None) != (
                preset,
                tab_id_str,
                str(segment_id) if segment_id else None,
            ):
                break
            next_text = _get_insert_text_content(next_ins) or ""
            next_item_len = utf16_len(next_text)
            next_item_tabs = _count_leading_tabs(next_text)
            all_style_reqs.extend(
                _shift_request_indices(
                    next_s_reqs,
                    cumulative_tabbed + inner_tabbed - cumulative_tabs - inner_tabs,
                )
            )
            run_len += next_item_len
            run_tabs += next_item_tabs
            inner_tabbed += next_item_len
            inner_tabs += next_item_tabs
            j += 1
        # Emit ONE createParagraphBullets for this run
        merged_range = Range(
            start_index=run_start,
            end_index=run_start + run_len,
            tab_id=tab_id_str if tab_id_str else None,
            segment_id=segment_id if segment_id else None,
        )
        merged_create_bullets.append(
            Request(
                create_paragraph_bullets=CreateParagraphBulletsRequest(
                    bullet_preset=CreateParagraphBulletsRequestBulletPreset(preset),
                    range=merged_range,
                )
            )
        )
        cumulative_tabbed += run_len
        cumulative_tabs += run_tabs
        i = j

    # Emit: insertTexts first (reverse order, for correct document ordering),
    # then merged createParagraphBullets, then style requests.
    return combined_insert_texts + merged_create_bullets + all_style_reqs


def _deleted_chars_before(
    *,
    deleted_sizes: dict[int, int],
    base_content: list[StructuralElement],
    before_pos: int,
    prior_delete_ranges: list[tuple[int, int]] | None = None,
) -> int:
    """Return total character count deleted from positions < before_pos.

    ``prior_delete_ranges`` is an optional list of ``(start, end)`` pristine
    position pairs representing additional body-segment deletes (e.g. from
    ``DeleteFootnoteOp``) that will run in the same batch before any inserts.
    Their contribution is included in the offset so that insert positions
    computed by ``_plan_insertions`` are correct when all deletes are sorted
    globally descending.
    """
    total = 0
    for bidx, size in deleted_sizes.items():
        # Base-tree read: contract guarantees concrete indices.
        # See docs/coordinate_contract.md §who-reads-what.
        el_start, _ = _require_concrete(
            base_content[bidx],
            context=f"_deleted_chars_before base_idx={bidx}",
        )
        if el_start < before_pos:
            total += size
    if prior_delete_ranges:
        for start, end in prior_delete_ranges:
            if start < before_pos:
                total += end - start
    return total


def _inserted_chars_before_or_at(
    *,
    insert_metadata: list[tuple[int, int]],
    before_pos: int,
) -> int:
    """Return total character count inserted at raw positions <= before_pos.

    Used to shift matched-element update indices by the size of whole-element
    inserts that run BEFORE the update in the same batch.  An insert whose
    raw (base-coordinate) insertion point is `<= before_pos` lands at or
    before the matched element's position, pushing its content forward.
    """
    return sum(size for raw_pos, size in insert_metadata if raw_pos <= before_pos)


def _lower_element_update(
    *,
    base_el: StructuralElement,
    desired_el: StructuralElement,
    tab_id: str,
    segment_id: str | None,
    pre_delete_shift: int = 0,
    post_insert_shift: int = 0,
    desired_lists: dict[str, DocList] | None = None,
    base_lists: dict[str, DocList] | None = None,
    in_unsupported_region: bool = False,
) -> list[Request]:
    """Lower an in-place element update (matched element, content changed).

    For paragraphs: replace text runs.
    For tables: raise NotImplementedError (complex; not yet implemented).

    For structural elements: no-op (cannot change their content).

    ``pre_delete_shift`` is the total number of characters removed by
    whole-element base_deletes whose startIndex is below this element's
    startIndex.  All generated request indices are shifted down by this
    amount to account for the prior deletions.
    """
    if base_el.paragraph is not None and desired_el.paragraph is not None:
        return _lower_paragraph_update(
            base_el=base_el,
            desired_el=desired_el,
            tab_id=tab_id,
            segment_id=segment_id,
            pre_delete_shift=pre_delete_shift,
            post_insert_shift=post_insert_shift,
            desired_lists=desired_lists or {},
            base_lists=base_lists or {},
            in_unsupported_region=in_unsupported_region,
        )
    elif base_el.table is not None and desired_el.table is not None:
        # Table cell content updates are emitted as separate UpdateBodyContentOp
        # ops with story_kind="table_cell" by the diff layer.  At the body level
        # a matched table pair means "same table, cells may have changed" — the
        # cell-level child ops handle the actual content edits.  No body-level
        # request is needed here.
        return []
    elif base_el.section_break is not None and desired_el.section_break is not None:
        return _lower_section_break_update(
            base_el=base_el,
            desired_el=desired_el,
            tab_id=tab_id,
            pre_delete_shift=pre_delete_shift,
            post_insert_shift=post_insert_shift,
        )
    else:
        # TOC etc. — no content to update
        return []


def _lower_paragraph_update(
    *,
    base_el: StructuralElement,
    desired_el: StructuralElement,
    tab_id: str,
    segment_id: str | None,
    pre_delete_shift: int = 0,
    post_insert_shift: int = 0,
    desired_lists: dict[str, DocList] | None = None,
    base_lists: dict[str, DocList] | None = None,
    in_unsupported_region: bool = False,
) -> list[Request]:
    """Replace the text content of a paragraph in place using surgical ops.

    Approach:
    1. Compute a character-level diff on non-terminal text to find minimal edits.
    2. For unchanged spans: emit updateTextStyle if the style changed.
    3. For deleted spans: emit deleteContentRange.
    4. For inserted spans: emit insertText + updateTextStyle if non-default style.
    5. Always emit updateParagraphStyle if paragraph-level style changed.

    Operations are emitted in descending character order (highest index first)
    so that earlier ops do not corrupt later indices.
    """
    assert base_el.paragraph is not None
    assert desired_el.paragraph is not None
    base_para = base_el.paragraph
    desired_para = desired_el.paragraph

    # Base-tree read: contract guarantees concrete indices. A None here is
    # an invariant violation (see docs/coordinate_contract.md §who-reads-what).
    start, end = _require_concrete(base_el, context="base_el in element update")

    adjusted_start = start - pre_delete_shift + post_insert_shift
    adjusted_end = end - pre_delete_shift + post_insert_shift

    # Paragraph-level style changes (alignment, spacing, namedStyleType, etc.)
    # are emitted FIRST — before the text-level diff ops — so the style range
    # [adjusted_start..adjusted_end) is still valid.  If we emitted them after
    # the diff ops, a shrinking diff (e.g. body replaced with shorter text)
    # would leave the style range pointing past the paragraph's new end, which
    # the API rejects with "Index X must be less than the end index of the
    # referenced segment".
    style_reqs = _lower_para_style_update(
        base_para=base_para,
        desired_para=desired_para,
        start_index=adjusted_start,
        end_index=adjusted_end,
        tab_id=tab_id,
        segment_id=segment_id,
        desired_lists=desired_lists or {},
        base_lists=base_lists or {},
        in_unsupported_region=in_unsupported_region,
    )

    # Run-level diff (handles text changes + text-style changes).
    # For the same-text case this emits only updateTextStyle for changed runs.
    # For the changed-text case this emits delete/insert/updateTextStyle as needed.
    diff_reqs = _diff_paragraph_runs(
        base_para=base_para,
        desired_para=desired_para,
        story_offset=adjusted_start,
        tab_id=tab_id,
        segment_id=segment_id,
    )

    return style_reqs + diff_reqs


_EMPTY_TEXT_STYLE = TextStyle()

# Sentinel character used to represent non-textRun paragraph elements
# (footnote refs, rich links, inline objects, etc.) in the character-level diff.
# U+FFFC (OBJECT REPLACEMENT CHARACTER) is the standard Unicode placeholder for
# embedded objects that occupy space but whose content is opaque to text processing.
_OPAQUE_ELEMENT_CHAR = "\ufffc"

# Sentinel TextStyle used to tag opaque placeholder runs so that
# _diff_paragraph_runs can recognise them and avoid generating text-level
# API requests (delete / insert / updateTextStyle) for those positions.
_OPAQUE_SENTINEL_STYLE = TextStyle(bold=None, italic=None)
_OPAQUE_SENTINEL_STYLE.__dict__["__opaque__"] = True


def _is_opaque_style(style: TextStyle) -> bool:
    """Return True if *style* is the opaque-element sentinel."""
    return bool(getattr(style, "__dict__", {}).get("__opaque__"))


def _non_text_element_size(el: ParagraphElement) -> int:
    """Return the character size of a non-textRun ParagraphElement.

    If the element carries startIndex/endIndex, use those.
    Otherwise fall back to 1 — correct for footnoteReference, autoText,
    pageBreak, columnBreak, equation, horizontalRule, inlineObjectElement,
    and person.  For richLink, try the title length; default to 1.
    """
    start = el.start_index
    end = el.end_index
    if isinstance(start, int) and isinstance(end, int):
        return end - start
    # Try richLink title length
    if el.rich_link is not None:
        props = el.rich_link.rich_link_properties
        if props is not None and props.title:
            return utf16_len(props.title)
    return 1


def _extract_runs(
    para: Paragraph,
) -> list[tuple[str, TextStyle]]:
    """Return list of (text, TextStyle) for each element in a paragraph.

    textRun elements produce their normal (text, style) tuple.
    Non-textRun elements (footnote refs, rich links, inline objects, etc.)
    produce a placeholder string of ``_OPAQUE_ELEMENT_CHAR`` repeated to the
    element's character size, paired with the ``_OPAQUE_SENTINEL_STYLE``.
    This ensures the character-level diff sees the correct index space.
    """
    runs: list[tuple[str, TextStyle]] = []
    for el in para.elements or []:
        if el.text_run is not None:
            tr = el.text_run
            text = tr.content or ""
            style = tr.text_style or _EMPTY_TEXT_STYLE
            runs.append((text, style))
        else:
            size = _non_text_element_size(el)
            runs.append((_OPAQUE_ELEMENT_CHAR * size, _OPAQUE_SENTINEL_STYLE))
    return runs


def _runs_to_spans(
    runs: list[tuple[str, TextStyle]],
) -> list[tuple[int, int, str, TextStyle]]:
    """Convert runs to (start, end, text, style) spans with character offsets.

    Offsets are code-point-based (matching SequenceMatcher output), relative
    to the start of the paragraph (0-based).
    """
    spans: list[tuple[int, int, str, TextStyle]] = []
    cursor = 0
    for text, style in runs:
        length = len(text)
        spans.append((cursor, cursor + length, text, style))
        cursor += length
    return spans


def _build_cp_to_utf16(text: str) -> list[int]:
    """Build a mapping from code-point index to UTF-16 offset.

    Returns a list of length ``len(text) + 1`` where entry ``i`` is the
    UTF-16 offset corresponding to code-point index ``i``.  The final
    entry gives the total UTF-16 length.
    """
    result: list[int] = []
    utf16_pos = 0
    for ch in text:
        result.append(utf16_pos)
        utf16_pos += 2 if ord(ch) > 0xFFFF else 1
    result.append(utf16_pos)
    return result


def _styles_equal(s1: TextStyle, s2: TextStyle) -> bool:
    """Return True if two TextStyle models are effectively equal.

    Compares via model_dump to handle None vs missing field equivalence.
    """
    return s1.model_dump(by_alias=True, exclude_none=True) == s2.model_dump(
        by_alias=True, exclude_none=True
    )


def _delete_ops_skipping_opaque(
    *,
    base_body: str,
    rel_start: int,
    rel_end: int,
    story_offset: int,
    tab_id: _StrOrDeferred,
    segment_id: str | None,
    cp_to_utf16: list[int] | None = None,
) -> list[tuple[int, list[Request]]]:
    """Split a delete range around opaque placeholder characters.

    Scans ``base_body[rel_start:rel_end]`` and emits deleteContentRange
    requests only for sub-ranges of real text, skipping any positions
    occupied by ``_OPAQUE_ELEMENT_CHAR`` (non-textRun elements).

    If *cp_to_utf16* is provided, code-point offsets are translated to
    UTF-16 offsets before adding *story_offset*.

    Returns a list of ``(abs_start, [Request])`` pairs for each contiguous
    real-text sub-range.
    """

    def _abs(cp_idx: int) -> int:
        if cp_to_utf16 is not None:
            return story_offset + cp_to_utf16[cp_idx]
        return story_offset + cp_idx

    result: list[tuple[int, list[Request]]] = []
    i = rel_start
    while i < rel_end:
        # Skip opaque chars
        if base_body[i] == _OPAQUE_ELEMENT_CHAR:
            i += 1
            continue
        # Find the end of the contiguous real-text run
        j = i + 1
        while j < rel_end and base_body[j] != _OPAQUE_ELEMENT_CHAR:
            j += 1
        abs_start = _abs(i)
        abs_end = _abs(j)
        result.append(
            (
                abs_start,
                [
                    _make_delete_content_range(
                        start_index=abs_start,
                        end_index=abs_end,
                        tab_id=tab_id,
                        segment_id=segment_id,
                    )
                ],
            )
        )
        i = j
    return result


def _diff_paragraph_runs(
    *,
    base_para: Paragraph,
    desired_para: Paragraph,
    story_offset: int,
    tab_id: str,
    segment_id: str | None,
) -> list[Request]:
    """Compute surgical API requests for a paragraph whose text changed.

    Algorithm:
    1. Extract text runs from base and desired paragraphs.
    2. Build a plain-text string (excluding the terminal \\n) for each.
    3. Run a character-level diff (SequenceMatcher) to find equal/insert/delete chunks.
    4. For each chunk:
       - 'equal': check if style changed → emit updateTextStyle if so.
       - 'delete': emit deleteContentRange.
       - 'insert': emit insertText + updateTextStyle if non-default style.
       - 'replace': emit deleteContentRange + insertText + optional updateTextStyle.
    5. All ops are collected and returned in descending character order so they
       can be applied sequentially without index corruption.

    The terminal \\n is never touched.
    """
    base_runs = _extract_runs(base_para)
    desired_runs = _extract_runs(desired_para)

    # Build plain text (all runs concatenated)
    base_full_text = "".join(t for t, _ in base_runs)
    desired_full_text = "".join(t for t, _ in desired_runs)

    # Strip terminal \n for diffing (we never touch it)
    base_body = (
        base_full_text.rstrip("\n") if base_full_text.endswith("\n") else base_full_text
    )
    desired_body = (
        desired_full_text.rstrip("\n")
        if desired_full_text.endswith("\n")
        else desired_full_text
    )

    # Build span maps for style lookup: char_offset → style
    # We need to find the style at any character position in base/desired.
    # Spans use code-point offsets (matching SequenceMatcher output).
    base_spans = _runs_to_spans(base_runs)
    desired_spans = _runs_to_spans(desired_runs)

    # Build code-point → UTF-16 offset maps so that we translate
    # SequenceMatcher indices (code-point-based) into UTF-16 offsets
    # required by the Google Docs API.  Characters outside the BMP
    # (emoji, mathematical bold, etc.) are 1 code point but 2 UTF-16 units.
    base_cp_to_utf16 = _build_cp_to_utf16(base_body)

    # Compute character-level diff
    matcher = difflib.SequenceMatcher(None, base_body, desired_body, autojunk=False)
    opcodes = matcher.get_opcodes()

    # Collect pending ops as (abs_start, abs_end, kind, extra)
    # kind ∈ {"delete", "insert", "update_style", "replace"}
    # We process in reverse order (highest index first).

    # Pending ops list: (sort_key, requests_list)
    # sort_key is the document-absolute start index (for descending sort)
    pending: list[tuple[int, list[Request]]] = []

    for tag, i1, i2, j1, j2 in opcodes:
        if tag == "equal":
            # Check if style changed for this span
            # We check style at the first char of the base span
            if i2 <= i1:
                continue
            # Find all distinct style sub-ranges within this equal span
            sub_ops = _style_update_ops_for_equal_span(
                base_spans=base_spans,
                desired_spans=desired_spans,
                base_start=i1,
                base_end=i2,
                desired_start=j1,
                desired_end=j2,
                story_offset=story_offset,
                tab_id=tab_id,
                segment_id=segment_id,
                cp_to_utf16=base_cp_to_utf16,
            )
            for abs_start, reqs in sub_ops:
                pending.append((abs_start, reqs))

        elif tag == "delete":
            # Delete [i1, i2) in base, but skip over opaque placeholder
            # chars (non-textRun elements that can't be deleted via text ops).
            del_reqs = _delete_ops_skipping_opaque(
                base_body=base_body,
                rel_start=i1,
                rel_end=i2,
                story_offset=story_offset,
                tab_id=tab_id,
                segment_id=segment_id,
                cp_to_utf16=base_cp_to_utf16,
            )
            for abs_pos, reqs in del_reqs:
                pending.append((abs_pos, reqs))

        elif tag == "insert":
            # Insert desired[j1:j2] at position i1 in base (after deletions)
            # We'll compute the insertion position relative to the base document.
            # The insertion happens at base position i1 (before any character there).
            # We group chars by style from desired spans.
            insert_reqs = _insert_ops_for_span(
                desired_spans=desired_spans,
                desired_start=j1,
                desired_end=j2,
                base_pos=i1,
                story_offset=story_offset,
                tab_id=tab_id,
                segment_id=segment_id,
                base_cp_to_utf16=base_cp_to_utf16,
                inherited_style=_inherited_insert_style(
                    base_spans=base_spans,
                    base_body=base_body,
                    base_pos=i1,
                ),
            )
            if insert_reqs:
                pending.append((story_offset + base_cp_to_utf16[i1], insert_reqs))

        elif tag == "replace":
            # Delete base[i1:i2], insert desired[j1:j2]
            abs_start = story_offset + base_cp_to_utf16[i1]

            # Deletion (skipping opaque chars)
            replace_del_ops = _delete_ops_skipping_opaque(
                base_body=base_body,
                rel_start=i1,
                rel_end=i2,
                story_offset=story_offset,
                tab_id=tab_id,
                segment_id=segment_id,
                cp_to_utf16=base_cp_to_utf16,
            )
            flat_del_reqs: list[Request] = []
            for _pos, dreqs in replace_del_ops:
                flat_del_reqs.extend(dreqs)

            # Insertion at the same position (after deletion, index is abs_start)
            insert_reqs = _insert_ops_for_span(
                desired_spans=desired_spans,
                desired_start=j1,
                desired_end=j2,
                base_pos=i1,
                story_offset=story_offset,
                tab_id=tab_id,
                segment_id=segment_id,
                base_cp_to_utf16=base_cp_to_utf16,
                inherited_style=_inherited_insert_style(
                    base_spans=base_spans,
                    base_body=base_body,
                    base_pos=i1,
                ),
            )
            # Delete and insert at the same logical position.
            # We emit the insert first (smaller sort key → processed before delete
            # in descending order — actually we want delete before insert when
            # applying).  Use a tuple to break ties: (abs_start, priority) where
            # delete=0 (higher priority = applied first in descending scan).
            # To ensure delete comes before insert in the final request list,
            # we emit them as a single group in delete-first order.
            combined: list[Request] = [*flat_del_reqs, *insert_reqs]
            if combined:
                pending.append((abs_start, combined))

    # Sort pending ops by sort_key descending (highest document index first)
    pending.sort(key=lambda item: item[0], reverse=True)

    # Flatten
    requests: list[Request] = []
    for _key, reqs in pending:
        requests.extend(reqs)

    return requests


def _style_update_ops_for_equal_span(
    *,
    base_spans: list[tuple[int, int, str, TextStyle]],
    desired_spans: list[tuple[int, int, str, TextStyle]],
    base_start: int,
    base_end: int,
    desired_start: int,
    desired_end: int,
    story_offset: int,
    tab_id: str,
    segment_id: str | None,
    cp_to_utf16: list[int] | None = None,
) -> list[tuple[int, list[Request]]]:
    """For an 'equal' diff chunk, emit updateTextStyle where style changed.

    We walk character-by-character through the equal span and group consecutive
    characters that share the same (base_style, desired_style) pair, then emit
    an updateTextStyle for each group where styles differ.

    If *cp_to_utf16* is provided, code-point offsets are translated to
    UTF-16 offsets before adding *story_offset*.

    Returns list of (abs_start, [Request]) pairs.
    """

    def _abs(cp_idx: int) -> int:
        if cp_to_utf16 is not None:
            return story_offset + cp_to_utf16[cp_idx]
        return story_offset + cp_idx

    # Find all style-change sub-ranges within the equal span
    # Group by consecutive chars with same (base_style != desired_style)
    result: list[tuple[int, list[Request]]] = []

    # Walk through the span and find style boundaries
    i = base_start
    j = desired_start
    while i < base_end:
        b_style = _style_at_offset(base_spans, i)
        d_style = _style_at_offset(desired_spans, j)

        # Find next boundary in either base or desired spans.
        # b_next and d_next are in their respective coordinate spaces
        # (base: [base_start, base_end), desired: [desired_start, desired_end)).
        # Advance by the smaller of the two distances so we never overshoot
        # a span boundary in either sequence.
        b_next = _next_span_boundary(base_spans, i, base_end)
        d_next = _next_span_boundary(desired_spans, j, desired_end)
        step = min(b_next - i, d_next - j)
        if step <= 0:
            # Defensive guard: should never happen given well-formed spans,
            # but prevent an infinite loop if spans don't cover the position.
            break
        chunk_end = i + step

        if (
            not _styles_equal(b_style, d_style)
            and not _is_opaque_style(b_style)
            and not _is_opaque_style(d_style)
        ):
            abs_start = _abs(i)
            abs_end = _abs(chunk_end)
            changed_fields = _text_style_changed_fields(b_style, d_style)
            if changed_fields:
                result.append(
                    (
                        abs_start,
                        [
                            _make_update_text_style(
                                start_index=abs_start,
                                end_index=abs_end,
                                tab_id=tab_id,
                                segment_id=segment_id,
                                text_style=d_style,
                                fields=changed_fields,
                            )
                        ],
                    )
                )

        i += step
        j += step

    return result


def _style_at_offset(
    spans: list[tuple[int, int, str, TextStyle]],
    offset: int,
) -> TextStyle:
    """Return the TextStyle for the character at the given offset within spans."""
    for start, end, _text, style in spans:
        if start <= offset < end:
            return style
    return _EMPTY_TEXT_STYLE


def _next_span_boundary(
    spans: list[tuple[int, int, str, TextStyle]],
    pos: int,
    limit: int,
) -> int:
    """Return the end of the span containing pos (capped at limit)."""
    for start, end, _text, _style in spans:
        if start <= pos < end:
            return min(end, limit)
    return limit


def _inherited_insert_style(
    *,
    base_spans: list[tuple[int, int, str, TextStyle]],
    base_body: str,
    base_pos: int,
) -> TextStyle:
    """Return the TextStyle that ``insertText`` at ``base_pos`` will inherit.

    Google Docs ``insertText`` inherits the style of the character to the
    LEFT of the insertion point (falling back to the character to the right
    when inserting at the very start of a paragraph/segment).  We mirror
    that behaviour here so the reconciler can avoid emitting spurious
    ``updateTextStyle`` requests for inserted characters whose desired style
    already matches what they would inherit from the surrounding run.

    Opaque placeholder chars (non-textRun elements) are skipped — they are
    not real runs and their sentinel style must not be mistaken for
    inherited formatting.
    """
    # Prefer the left neighbour (classic Docs insert-inherit semantics).
    i = base_pos - 1
    while i >= 0 and i < len(base_body) and base_body[i] == _OPAQUE_ELEMENT_CHAR:
        i -= 1
    if i >= 0:
        style = _style_at_offset(base_spans, i)
        if not _is_opaque_style(style):
            return style
    # Fall back to the right neighbour.
    j = base_pos
    while j < len(base_body) and base_body[j] == _OPAQUE_ELEMENT_CHAR:
        j += 1
    if j < len(base_body):
        style = _style_at_offset(base_spans, j)
        if not _is_opaque_style(style):
            return style
    return _EMPTY_TEXT_STYLE


def _insert_ops_for_span(
    *,
    desired_spans: list[tuple[int, int, str, TextStyle]],
    desired_start: int,
    desired_end: int,
    base_pos: int,
    story_offset: int,
    tab_id: str,
    segment_id: str | None,
    base_cp_to_utf16: list[int] | None = None,
    inherited_style: TextStyle | None = None,
) -> list[Request]:
    """Emit insertText + optional updateTextStyle for desired[desired_start:desired_end].

    The text is inserted at base_pos (before any character at that position in base).
    We group consecutive characters by their textStyle and emit one insertText per
    contiguous group with the same style — but since insertText inserts at the same
    index and text flows forward, we emit a single insertText with all the text and
    then style each sub-range.

    If *base_cp_to_utf16* is provided, *base_pos* is translated from code-point
    offset to UTF-16 offset before adding *story_offset*.
    """
    if desired_start >= desired_end:
        return []

    # Collect the full text to insert, skipping opaque placeholder chars
    full_text = ""
    i = desired_start
    while i < desired_end:
        for start, end, text, _style in desired_spans:
            if start <= i < end:
                # Take the portion of this span in [desired_start, desired_end)
                offset_in_span = i - start
                take = min(end, desired_end) - i
                chunk = text[offset_in_span : offset_in_span + take]
                # Skip opaque placeholder characters — they represent non-textRun
                # elements and must not be emitted as insertText.
                if not _is_opaque_style(_style):
                    full_text += chunk
                i += take
                break
        else:
            break

    if not full_text:
        return []

    if base_cp_to_utf16 is not None:
        abs_insert = story_offset + base_cp_to_utf16[base_pos]
    else:
        abs_insert = story_offset + base_pos
    reqs: list[Request] = [
        _make_insert_text(
            index=abs_insert,
            tab_id=tab_id,
            segment_id=segment_id,
            text=full_text,
        )
    ]

    # Apply styles to sub-ranges of the inserted text.
    # cursor tracks the absolute UTF-16 position within the newly inserted
    # text.  span_len is in code-point space, so we compute the UTF-16
    # length of each text chunk for cursor advancement.
    #
    # To avoid fragmenting runs on the real Google Docs API, we coalesce
    # consecutive spans that have the same changed-fields mask AND the same
    # TextStyle values into a single updateTextStyle request.
    cursor = abs_insert
    i = desired_start
    base_ref = inherited_style if inherited_style is not None else _EMPTY_TEXT_STYLE

    # Pending group state for coalescing same-style adjacent spans.
    pending_start: int | None = None
    pending_end: int = cursor
    pending_fields: list[str] = []
    pending_style: TextStyle | None = None

    def _flush_pending() -> None:
        if pending_start is not None and pending_fields and pending_style is not None:
            reqs.append(
                _make_update_text_style(
                    start_index=pending_start,
                    end_index=pending_end,
                    tab_id=tab_id,
                    segment_id=segment_id,
                    text_style=pending_style,
                    fields=pending_fields,
                )
            )

    while i < desired_end:
        style = _style_at_offset(desired_spans, i)
        end_of_span = _next_span_boundary(desired_spans, i, desired_end)
        span_cp_len = end_of_span - i
        # Compute the UTF-16 length of this span's text for correct cursor
        # advancement.  We need the actual text, not just the code-point count.
        span_text = ""
        for s_start, s_end, s_text, _ in desired_spans:
            if s_start <= i < s_end:
                offset_in = i - s_start
                span_text = s_text[offset_in : offset_in + span_cp_len]
                break
        span_utf16_len = utf16_len(span_text) if span_text else span_cp_len
        # Skip opaque spans (non-textRun elements).
        # Opaque chars are NOT included in full_text, so cursor must not advance.
        # Flush any pending style group — do not coalesce across opaque barriers.
        if _is_opaque_style(style):
            _flush_pending()
            pending_start = None
            pending_fields = []
            pending_style = None
            i = end_of_span
            continue
        # Compare the desired style against the style that the inserted
        # text will inherit from its neighbour in the base document.  Only
        # fields that actually differ need an explicit updateTextStyle.
        # Emitting a redundant updateTextStyle — even with identical values
        # — fragments the run on the real Google Docs API and causes edits
        # like ``PARTI`` → ``PART I`` to round-trip as ``**PART** **I**``.
        fields = _text_style_changed_fields(base_ref, style)
        if fields:
            # Check whether this span can be merged into the pending group:
            # same fields mask AND same style values.
            if (
                pending_start is not None
                and pending_fields == fields
                and pending_style is not None
                and _styles_equal(pending_style, style)
            ):
                # Extend the pending group to cover this span.
                pending_end = cursor + span_utf16_len
            else:
                # Flush the previous pending group (if any) and start a new one.
                _flush_pending()
                pending_start = cursor
                pending_end = cursor + span_utf16_len
                pending_fields = fields
                pending_style = style
        else:
            # This span needs no updateTextStyle — flush any pending group.
            _flush_pending()
            pending_start = None
            pending_fields = []
            pending_style = None
        cursor += span_utf16_len
        i = end_of_span

    # Flush any remaining pending group.
    _flush_pending()

    return reqs


def _make_update_text_style(
    *,
    start_index: int,
    end_index: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
    text_style: TextStyle,
    fields: list[str],
) -> Request:
    """Build an updateTextStyle Request."""
    return Request(
        update_text_style=UpdateTextStyleRequest(
            range=Range(
                start_index=start_index,
                end_index=end_index,
                tab_id=tab_id if tab_id else None,
                segment_id=segment_id if segment_id else None,
            ),
            text_style=text_style,
            fields=",".join(fields),
        )
    )


def _lower_para_style_update(
    *,
    base_para: Paragraph,
    desired_para: Paragraph,
    start_index: int,
    end_index: int,
    tab_id: str,
    segment_id: str | None,
    desired_lists: dict[str, DocList] | None = None,
    base_lists: dict[str, DocList] | None = None,
    in_unsupported_region: bool = False,
) -> list[Request]:
    """Emit paragraphStyle / bullet / textStyle update requests if styles changed.

    Bullet handling for matched paragraphs:

    Case A — paragraph gains a bullet (base has none, desired has one):
        1. Prepend ``"\\t" * nesting_level`` tabs via insertText at start_index.
        2. Emit createParagraphBullets covering the extended range.

    Case B — paragraph loses a bullet (base has one, desired has none):
        1. Emit deleteParagraphBullets.
        2. Emit updateParagraphStyle clearing indentStart (deleteParagraphBullets
           adds visual indent to preserve appearance).

    Case C — nesting level or list type changes (both have bullet):
        1. Emit deleteParagraphBullets.
        2. Prepend new tabs at start_index.
        3. Emit createParagraphBullets with desired preset.
    """
    requests: list[Request] = []

    base_bullet = base_para.bullet
    desired_bullet = desired_para.bullet

    if not base_bullet and desired_bullet:
        # Case A: paragraph gains a bullet
        nesting_level = desired_bullet.nesting_level or 0
        preset = _infer_bullet_preset_from_model(desired_bullet, desired_lists or {})
        tabs = "\t" * nesting_level
        tabs_len = utf16_len(tabs)
        if tabs_len > 0:
            requests.append(
                _make_insert_text(
                    index=start_index,
                    tab_id=tab_id,
                    segment_id=segment_id,
                    text=tabs,
                )
            )
        # createParagraphBullets covers the tabs + paragraph content
        requests.append(
            _make_create_paragraph_bullets(
                start=start_index,
                end=start_index + tabs_len + (end_index - start_index),
                preset=preset,
                tab_id=tab_id,
                segment_id=segment_id,
            )
        )

    elif base_bullet and not desired_bullet:
        # Case B: paragraph loses a bullet
        requests.append(
            _make_delete_paragraph_bullets(
                start=start_index,
                end=end_index,
                tab_id=tab_id,
                segment_id=segment_id,
            )
        )
        # deleteParagraphBullets adds visual indent — clear it
        requests.append(
            _make_update_paragraph_style(
                start_index=start_index,
                end_index=end_index,
                tab_id=tab_id,
                segment_id=segment_id,
                paragraph_style={"indentStart": None, "indentFirstLine": None},
                fields=["indentStart", "indentFirstLine"],
            )
        )

    elif base_bullet and desired_bullet:
        # Case C: both have bullet — check if nesting level or list type changed.
        # List type change is detected by comparing the inferred bullet preset:
        # base preset (from base_lists) vs desired preset (from desired_lists).
        base_nesting = base_bullet.nesting_level or 0
        desired_nesting = desired_bullet.nesting_level or 0
        base_preset = _infer_bullet_preset_from_model(base_bullet, base_lists or {})
        desired_preset = _infer_bullet_preset_from_model(
            desired_bullet, desired_lists or {}
        )
        if base_nesting != desired_nesting or base_preset != desired_preset:
            # Delete then re-add with new nesting level / list type
            requests.append(
                _make_delete_paragraph_bullets(
                    start=start_index,
                    end=end_index,
                    tab_id=tab_id,
                    segment_id=segment_id,
                )
            )
            preset = desired_preset
            tabs = "\t" * desired_nesting
            tabs_len = utf16_len(tabs)
            if tabs_len > 0:
                requests.append(
                    _make_insert_text(
                        index=start_index,
                        tab_id=tab_id,
                        segment_id=segment_id,
                        text=tabs,
                    )
                )
            requests.append(
                _make_create_paragraph_bullets(
                    start=start_index,
                    end=start_index + tabs_len + (end_index - start_index),
                    preset=preset,
                    tab_id=tab_id,
                    segment_id=segment_id,
                )
            )

    # Paragraph style changes (beyond bullet-related indentation)
    base_ps = (
        base_para.paragraph_style.model_dump(by_alias=True, exclude_none=True)
        if base_para.paragraph_style
        else {}
    )
    desired_ps = (
        desired_para.paragraph_style.model_dump(by_alias=True, exclude_none=True)
        if desired_para.paragraph_style
        else {}
    )

    if base_ps != desired_ps and desired_ps:
        # Compute changed fields — exclude bullet-managed indentation when
        # bullet ops were already emitted above (they set indentation).
        fields = _dict_changed_fields(base_ps, desired_ps)
        # Always exclude server-managed readonly fields from the field mask.
        fields = [f for f in fields if f not in _PARA_STYLE_READONLY_FIELDS]
        if in_unsupported_region:
            # Inside tables, headers, footers, footnotes: certain paragraph
            # fields (pageBreakBefore) return 400 from the API.  Drop them
            # from the mask — the value change is discarded silently.
            fields = [
                f
                for f in fields
                if f not in _PARA_STYLE_FORBIDDEN_IN_UNSUPPORTED_REGIONS
            ]
        if base_bullet or desired_bullet:
            # Exclude indent fields that createParagraphBullets manages
            fields = [f for f in fields if f not in ("indentFirstLine", "indentStart")]
        if fields:
            requests.append(
                _make_update_paragraph_style(
                    start_index=start_index,
                    end_index=end_index,
                    tab_id=tab_id,
                    segment_id=segment_id,
                    paragraph_style=desired_ps,
                    fields=fields,
                )
            )

    return requests


def _lower_element_insert(
    *,
    el: StructuralElement,
    index: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
    desired_lists: dict[str, DocList] | None = None,
    in_unsupported_region: bool = False,
) -> list[Request]:
    """Generate request(s) to insert a content element at the given index.

    For page break paragraphs: insertPageBreak.
    For paragraphs: insertText (text + \\n) + style requests.
    For tables: insertTable (dimensions only; cell content not yet supported).
    For section breaks: insertSectionBreak + optional updateSectionStyle.
    """
    if el.paragraph is not None and _is_pagebreak_para(el.paragraph):
        return _lower_page_break_insert(
            index=index,
            tab_id=tab_id,
        )
    elif el.paragraph is not None:
        return _lower_paragraph_insert(
            el=el,
            index=index,
            tab_id=tab_id,
            segment_id=segment_id,
            desired_lists=desired_lists or {},
            in_unsupported_region=in_unsupported_region,
        )
    elif el.table is not None:
        return _lower_table_insert(
            el=el,
            index=index,
            tab_id=tab_id,
            segment_id=segment_id,
        )
    elif el.section_break is not None:
        return _lower_section_break_insert(
            el=el,
            index=index,
            tab_id=tab_id,
        )
    else:
        el_keys = []
        if el.paragraph is not None:
            el_keys.append("paragraph")
        if el.table is not None:
            el_keys.append("table")
        if el.section_break is not None:
            el_keys.append("sectionBreak")
        if el.table_of_contents is not None:
            el_keys.append("tableOfContents")
        raise NotImplementedError(
            f"lowering for insertion of element kind {el_keys!r} not yet implemented"
        )


def _lower_paragraph_insert(
    *,
    el: StructuralElement,
    index: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
    desired_lists: dict[str, DocList] | None = None,
    in_unsupported_region: bool = False,
) -> list[Request]:
    """Insert a paragraph at ``index`` via insertText + optional style.

    For bullet paragraphs, the approach is:
    1. Prepend ``"\\t" * nesting_level`` to the text before insertText.
    2. Emit createParagraphBullets covering the range (including tabs).
       The API strips the tabs and sets the nesting level from them.
    3. Style requests (updateParagraphStyle, updateTextStyle) use the
       tab-free ``index`` as start — by the time they execute in the batch,
       createParagraphBullets has already removed the tabs.
    4. Net index advance for subsequent elements = len(text), not len(tabs+text).
    """
    requests: list[Request] = []

    assert el.paragraph is not None
    para = el.paragraph
    text = _para_text(para)
    text_len = utf16_len(text)

    bullet = para.bullet
    if bullet:
        nesting_level = bullet.nesting_level or 0
        tabs = "\t" * nesting_level
        preset = _infer_bullet_preset_from_model(bullet, desired_lists or {})
        full_text = tabs + text  # text already ends with \n

        # insertText with leading tabs for nesting
        requests.append(
            _make_insert_text(
                index=index,
                tab_id=tab_id,
                segment_id=segment_id,
                text=full_text,
            )
        )

        # createParagraphBullets: range covers tabs+text before removal.
        # After this runs, tabs are removed and the nesting level is set.
        full_text_len = utf16_len(full_text)
        requests.append(
            _make_create_paragraph_bullets(
                start=index,
                end=index + full_text_len,
                preset=preset,
                tab_id=tab_id,
                segment_id=segment_id,
            )
        )

        # Style requests use tab-free indices: createParagraphBullets has
        # already removed the tabs by the time these run in the batch.
        desired_ps = (
            para.paragraph_style.model_dump(by_alias=True, exclude_none=True)
            if para.paragraph_style
            else {}
        )
        if desired_ps:
            # Exclude indentation fields — createParagraphBullets sets them.
            # Also exclude server-managed readonly fields (e.g. headingId).
            ps_fields = [
                k
                for k in desired_ps
                if k not in ("indentFirstLine", "indentStart")
                and k not in _PARA_STYLE_READONLY_FIELDS
            ]
            if in_unsupported_region:
                ps_fields = [
                    f
                    for f in ps_fields
                    if f not in _PARA_STYLE_FORBIDDEN_IN_UNSUPPORTED_REGIONS
                ]
            if ps_fields:
                requests.append(
                    _make_update_paragraph_style(
                        start_index=index,
                        end_index=index + text_len,
                        tab_id=tab_id,
                        segment_id=segment_id,
                        paragraph_style={k: desired_ps[k] for k in ps_fields},
                        fields=ps_fields,
                    )
                )

        # Apply text styles for each run (use tab-free index)
        runs = _extract_runs(para)
        run_offset = index
        for text_content, style in runs:
            run_len = utf16_len(text_content)
            style_dict = style.model_dump(by_alias=True, exclude_none=True)
            if run_len > 0 and style_dict:
                requests.append(
                    _make_update_text_style(
                        start_index=run_offset,
                        end_index=run_offset + run_len,
                        tab_id=tab_id,
                        segment_id=segment_id,
                        text_style=style,
                        fields=list(style_dict.keys()),
                    )
                )
            run_offset += run_len

    else:
        # Non-bullet paragraph: plain insertText + style
        requests.append(
            _make_insert_text(
                index=index,
                tab_id=tab_id,
                segment_id=segment_id,
                text=text,
            )
        )

        # Apply paragraph style
        desired_ps = (
            para.paragraph_style.model_dump(by_alias=True, exclude_none=True)
            if para.paragraph_style
            else {}
        )
        if desired_ps:
            # Exclude server-managed readonly fields (e.g. headingId) from mask.
            fields = [k for k in desired_ps if k not in _PARA_STYLE_READONLY_FIELDS]
            if in_unsupported_region:
                fields = [
                    f
                    for f in fields
                    if f not in _PARA_STYLE_FORBIDDEN_IN_UNSUPPORTED_REGIONS
                ]
            if fields:
                requests.append(
                    _make_update_paragraph_style(
                        start_index=index,
                        end_index=index + text_len,
                        tab_id=tab_id,
                        segment_id=segment_id,
                        paragraph_style={k: desired_ps[k] for k in fields},
                        fields=fields,
                    )
                )

        # Apply text styles for each run
        runs = _extract_runs(para)
        run_offset = index
        for text_content, style in runs:
            run_len = utf16_len(text_content)
            style_dict = style.model_dump(by_alias=True, exclude_none=True)
            if run_len > 0 and style_dict:
                requests.append(
                    _make_update_text_style(
                        start_index=run_offset,
                        end_index=run_offset + run_len,
                        tab_id=tab_id,
                        segment_id=segment_id,
                        text_style=style,
                        fields=list(style_dict.keys()),
                    )
                )
            run_offset += run_len

    return requests


def _lower_table_insert(
    *,
    el: StructuralElement,
    index: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
) -> list[Request]:
    """Insert a table at ``index`` and populate cell content.

    Emits ``insertTable`` first, then ``insertText`` + style requests for each
    cell's desired content at the correct absolute index.

    Index arithmetic
    ----------------
    After ``insertTable`` creates an empty table, each empty cell occupies
    exactly 2 characters: one cell-opener character and one terminal ``\\n``.
    When we insert ``s`` characters of content into a cell at position P+1
    (after the cell opener at P), all subsequent cells shift right by ``s``.
    The loop tracks this running shift via ``table_pos``.

    Structural layout immediately after ``insertTable`` at ``index``::

        index     : table opener  (1 char)
        index+1   : row[0] opener (1 char)
        index+2   : cell[0][0] opener (1 char)
        index+3   : cell[0][0] terminal \\n (1 char) — empty
        index+4   : cell[0][1] opener (1 char)
        ...
    """
    assert el.table is not None
    table = el.table
    table_rows = table.table_rows or []
    rows = table.rows or len(table_rows)
    cols = table.columns or 0
    if cols == 0 and table_rows:
        cols = len(table_rows[0].table_cells or [])

    loc = Location(
        index=index,
        tab_id=tab_id if tab_id else None,
        segment_id=segment_id if segment_id else None,
    )

    requests: list[Request] = [
        Request(
            insert_table=InsertTableRequest(
                rows=rows,
                columns=cols,
                location=loc,
            )
        )
    ]

    # table_pos tracks the next position as it shifts with each insertion.
    # insertTable inserts a \n at ``index`` and places the table opener at
    # ``index+1``, so we start at ``index+2`` to skip both. Subsequent
    # increments account for row openers and cell openers.
    table_pos = index + 2

    for row in table_rows:
        table_pos += 1  # skip row opener (1 char)
        for cell in row.table_cells or []:
            cell_content: list[StructuralElement] = cell.content or []
            if not cell_content:
                # Fully empty cell (no content list at all) — skip.
                # An empty cell still occupies 2 chars (opener + terminal \n).
                table_pos += 2
                continue

            # First element in cell starts at table_pos + 1 (after cell opener).
            content_start = table_pos + 1

            # Filter out terminal paragraphs (bare "\n").  We skip them because
            # insertTable creates one terminal \n per cell automatically.
            #
            # We filter rather than blindly using content[:-1] because the
            # markdown deserialiser produces cells with a single paragraph whose
            # text already ends with "\n" (no separate terminal element), while a
            # real API pull produces [content_para, terminal_para].  Both cases
            # must work correctly.
            insertable = [e for e in cell_content if not _is_cell_terminal(e)]

            # Compute estimated char count using element sizes to decide
            # whether there is anything to insert (same guard as before).
            estimated_inserted_chars = sum(_element_size(e) for e in insertable)

            # Emit insert requests for this cell and track the ACTUAL number
            # of characters inserted.  We cannot use _element_size() alone
            # here because it counts all paragraph elements including
            # non-textRun inline objects (footnote references, inline
            # images, …).  _lower_element_insert / _lower_paragraph_insert
            # only emits insertText for the text-run content, so non-textRun
            # elements contribute 0 inserted characters.  Using
            # _element_size() to advance ``running`` would over-count and
            # shift all subsequent cell positions by the number of such
            # opaque elements in the cell.
            actual_inserted_chars = 0
            if estimated_inserted_chars > 0:
                running = content_start
                for e in insertable:
                    el_reqs = _lower_element_insert(
                        el=e,
                        index=running,
                        tab_id=tab_id,
                        segment_id=segment_id,
                        in_unsupported_region=True,
                    )
                    requests.extend(el_reqs)
                    el_actual = _batch_insert_size_from_reqs(el_reqs)
                    running += el_actual
                    actual_inserted_chars += el_actual

            # Advance past this cell:
            # originally 2 chars (opener + terminal \n), now 2 + actual chars.
            table_pos += actual_inserted_chars + 2

    return requests


def _is_pagebreak_para(para: Paragraph) -> bool:
    """Return True if a Paragraph's only content element(s) include a pageBreak.

    A page break paragraph has a ``pageBreak`` element among its elements (plus
    an optional terminal ``\\n`` textRun).  Such paragraphs must be inserted via
    ``insertPageBreak``, not ``insertText``.
    """
    has_page_break = False
    for elem in para.elements or []:
        if elem.page_break is not None:
            has_page_break = True
        elif elem.text_run is not None:
            content = elem.text_run.content or ""
            if content not in ("", "\n"):
                # Real text alongside the page break — not a pure page break para
                return False
        else:
            # Other inline elements (inlineObject, footnoteReference, etc.)
            return False
    return has_page_break


def _lower_page_break_insert(
    *,
    index: int,
    tab_id: _StrOrDeferred,
) -> list[Request]:
    """Insert a page break via ``insertPageBreak`` at ``index``.

    ``insertPageBreak`` inserts two characters (pageBreak element + newline).
    The ``segmentId`` field must be omitted — the API only allows page breaks
    in the document body.
    """
    return [
        Request(
            insert_page_break=InsertPageBreakRequest(
                location=Location(
                    index=index,
                    tab_id=tab_id if tab_id else None,
                ),
            )
        )
    ]


def _lower_section_break_insert(
    *,
    el: StructuralElement,
    index: int,
    tab_id: _StrOrDeferred,
) -> list[Request]:
    """Insert a section break via ``insertSectionBreak`` at ``index``.

    Reads ``sectionType`` from ``el.section_break.section_style.section_type``;
    defaults to ``"NEXT_PAGE"`` if absent.

    If the ``sectionStyle`` contains additional style fields beyond
    ``sectionType``, emits a follow-up ``updateSectionStyle`` request covering
    the newly inserted section break character.
    """
    assert el.section_break is not None
    section_style = el.section_break.section_style
    section_style_dict = (
        section_style.model_dump(by_alias=True, exclude_none=True)
        if section_style
        else {}
    )
    section_type = section_style_dict.get("sectionType", "NEXT_PAGE")

    requests: list[Request] = [
        Request(
            insert_section_break=InsertSectionBreakRequest(
                location=Location(
                    index=index,
                    tab_id=tab_id if tab_id else None,
                ),
                section_type=section_type,
            )
        )
    ]

    # Emit updateSectionStyle for any non-default style fields.
    # insertSectionBreak inserts 2 characters (newline + section break element),
    # so the section break lands at index+1 in the post-insert document.
    style_fields = [k for k in section_style_dict if k != "sectionType"]
    if style_fields and section_style_dict:
        style_to_apply = {k: section_style_dict[k] for k in style_fields}
        requests.append(
            Request(
                update_section_style=UpdateSectionStyleRequest(
                    range=Range(
                        start_index=index + 1,
                        end_index=index + 2,
                        tab_id=tab_id if tab_id else None,
                    ),
                    section_style=SectionStyle.model_validate(style_to_apply),
                    fields=",".join(sorted(style_fields)),
                )
            )
        )

    return requests


def _lower_section_break_update(
    *,
    base_el: StructuralElement,
    desired_el: StructuralElement,
    tab_id: str,
    pre_delete_shift: int = 0,
    post_insert_shift: int = 0,
) -> list[Request]:
    """Emit ``updateSectionStyle`` when a matched section break's style changed.

    The range covers the section break character itself (startIndex → endIndex).
    If ``sectionStyle`` is identical, returns an empty list.
    """
    assert base_el.section_break is not None
    assert desired_el.section_break is not None
    base_style = (
        base_el.section_break.section_style.model_dump(by_alias=True, exclude_none=True)
        if base_el.section_break.section_style
        else {}
    )
    desired_style = (
        desired_el.section_break.section_style.model_dump(
            by_alias=True, exclude_none=True
        )
        if desired_el.section_break.section_style
        else {}
    )

    changed_fields = _dict_changed_fields(base_style, desired_style)
    if not changed_fields:
        return []

    # Base-tree read: contract guarantees concrete indices. A None here is
    # an invariant violation (see docs/coordinate_contract.md §who-reads-what).
    start, end = _require_concrete(base_el, context="base_el in element update")

    adjusted_start = start - pre_delete_shift + post_insert_shift
    adjusted_end = end - pre_delete_shift + post_insert_shift

    return [
        Request(
            update_section_style=UpdateSectionStyleRequest(
                range=Range(
                    start_index=adjusted_start,
                    end_index=adjusted_end,
                    tab_id=tab_id if tab_id else None,
                ),
                section_style=SectionStyle.model_validate(desired_style),
                fields=",".join(sorted(changed_fields)),
            )
        )
    ]


def _lower_content_insert(
    *,
    content: list[StructuralElement],
    start_index: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
    desired_lists: dict[str, DocList] | None = None,
    in_unsupported_region: bool = False,
) -> list[Request]:
    """Insert a list of StructuralElements starting at ``start_index``.

    This is the single unified pure-insert entry point for all five content
    containers (body, header, footer, footnote, table cell).

    The terminal paragraph (the trailing ``\\n`` that every container already
    has) is skipped — ``content[:-1]`` is processed.

    ``tab_id`` and ``segment_id`` may be DeferredID placeholders; they
    flow through to ``_lower_element_insert`` and ultimately to the builder
    helpers, where ``resolve_deferred_placeholders`` substitutes them before
    the batch executes.

    Index arithmetic
    ----------------
    A freshly created segment (header, footer, footnote) has one empty
    paragraph whose ``\\n`` sits at index 1 in the segment's coordinate
    space.  Pass ``start_index=1`` for those containers.

    For a body (new tab), content also starts at index 1.

    For a table cell, pass the pre-computed absolute index of the first
    position inside the cell (cell_opener_index + 1).
    """
    requests: list[Request] = []
    running_index = start_index

    for el in content[:-1]:  # skip terminal paragraph
        reqs = _lower_element_insert(
            el=el,
            index=running_index,
            tab_id=tab_id,
            segment_id=segment_id,
            desired_lists=desired_lists,
            in_unsupported_region=in_unsupported_region,
        )
        requests.extend(reqs)
        running_index += _element_size(el)

    return requests


# ---------------------------------------------------------------------------
# Tab body extraction helper
# ---------------------------------------------------------------------------


def _extract_tab_body_content(tab: Tab) -> list[StructuralElement]:
    """Return the body StructuralElements from a Tab.

    Skips any leading ``sectionBreak`` element — ``addDocumentTab`` creates
    it automatically, so it must not be re-inserted.

    Returns an empty list if the body has no content beyond the terminal
    paragraph (nothing to insert into the new tab).
    """
    doc_tab = tab.document_tab
    if doc_tab is None:
        return []
    body = doc_tab.body
    if body is None:
        return []
    content: list[StructuralElement] = body.content or []
    # Drop leading sectionBreak (inserted automatically by addDocumentTab)
    filtered = [el for el in content if el.section_break is None]
    # Nothing to do if the only remaining element is the terminal paragraph
    if len(filtered) <= 1:
        return []
    return filtered


# ---------------------------------------------------------------------------
# Element index helpers
# ---------------------------------------------------------------------------


def _is_cell_terminal(el: StructuralElement) -> bool:
    """Return True if ``el`` is a bare terminal paragraph (text == "\\n").

    Table cells may or may not include an explicit terminal paragraph depending
    on whether the content came from a real API pull (always has one) or from
    the markdown/XML deserialiser (may omit it).  Either way, ``insertTable``
    creates the terminal automatically, so we must never re-insert it.
    """
    if el.paragraph is None:
        return False
    return _para_text(el.paragraph) == "\n"


def _paragraph_size(para: Paragraph) -> int:
    """Return the total character size of a paragraph including non-textRun elements.

    Each textRun contributes its UTF-16 content length.
    Non-textRun elements (footnote refs, rich links, inline objects, etc.)
    each contribute their character size (usually 1, computed from indices
    or element properties).
    """
    total = 0
    for e in para.elements or []:
        if e.text_run is not None and e.text_run.content is not None:
            total += utf16_len(e.text_run.content)
        elif e.text_run is None:
            # Non-textRun element
            total += _non_text_element_size(e)
    return total


def _table_size(table: Table) -> int:
    """Compute table size recursively from cell contents.

    Google Docs index model for tables:
    1 (table opener) + per_row(1 (row opener) + per_cell(1 (cell opener) +
    content_size)) + 1 (trailing newline after last row).
    """
    size = 1  # table opener
    for row in table.table_rows or []:
        size += 1  # row opener
        for cell in row.table_cells or []:
            size += 1  # cell opener
            for content_el in cell.content or []:
                size += _element_size(content_el)
    size += 1  # trailing newline after last row
    return size


def _element_size(el: StructuralElement) -> int:
    """Return the number of UTF-16 code units occupied by a StructuralElement.

    For paragraphs the size is derived from all elements (text runs + non-text).
    For section breaks the API allocates exactly one character.
    For tables, the size is computed recursively from cell contents.
    For other elements we read ``startIndex``/``endIndex`` if present.
    """
    if el.paragraph is not None:
        return _paragraph_size(el.paragraph)
    if el.section_break is not None:
        return 1
    if el.table is not None:
        # Desired-tree tolerant path: indices are used only as a fast-path
        # optimization. If they are None (State B per coordinate contract
        # §three-state-invariant), we recursively compute size from cell
        # content. Both base and desired callers are supported.
        start, end = _element_range(el)
        if start is not None and end is not None:
            return end - start
        return _table_size(el.table)
    # Desired-tree tolerant path: same rationale as the table branch above.
    # See docs/coordinate_contract.md §three-state-invariant.
    start, end = _element_range(el)
    if start is not None and end is not None:
        return end - start
    el_keys = []
    if el.table_of_contents is not None:
        el_keys.append("tableOfContents")
    raise NotImplementedError(
        f"Cannot compute size of element with keys {el_keys!r} "
        "without startIndex/endIndex. Ensure the desired document was "
        "pulled from the Google API so that index information is present."
    )


def _shift_elements(
    elements: list[StructuralElement], shift: int
) -> list[StructuralElement]:
    """Return a shallow copy of *elements* with all indices shifted by *shift*.

    Used to adjust table-cell content elements whose body-level BASE indices
    have been invalidated by prior batch requests (e.g. ``deleteTableRow``,
    ``insertText`` in the body before the table).
    """
    shifted: list[StructuralElement] = []
    for el in elements:
        el = el.model_copy(deep=True)
        if el.start_index is not None:
            el.start_index += shift
        if el.end_index is not None:
            el.end_index += shift
        shifted.append(el)
    return shifted


def _element_range(el: StructuralElement) -> tuple[int | None, int | None]:
    """Return (startIndex, endIndex) from a StructuralElement, or (None, None)."""
    start = el.start_index
    end = el.end_index
    if isinstance(start, int) and isinstance(end, int):
        return start, end
    return None, None


def _element_start(el: StructuralElement) -> int | None:
    """Return startIndex from a StructuralElement, or None."""
    start = el.start_index
    return start if isinstance(start, int) else None


def _require_concrete(el: StructuralElement, *, context: str) -> tuple[int, int]:
    """Return ``(startIndex, endIndex)`` from a base-tree element.

    Per the coordinate contract (``docs/coordinate_contract.md``), the base
    tree is always in State A — concrete indices. The Google Docs API uses an
    "implicit-zero" convention for the very first element of a segment: it
    omits ``startIndex`` entirely (meaning 0). Per the contract's
    "Missing index keys = concrete State A" rule, a missing ``startIndex``
    paired with a concrete ``endIndex`` is still State A and resolves to
    ``start=0``.

    Fully absent indices (``start=None, end=None``) on a base-tree element
    are an invariant violation — either the producer in ``apply_ops.py``
    corrupted the base tree, or a caller passed a desired-tree element into a
    site that expects base. Raise loudly so the bug surfaces at its origin.
    """
    start = el.start_index
    end = el.end_index
    # Resolve the API's implicit-zero for the first element of a segment.
    if start is None and isinstance(end, int):
        start = 0
    if not isinstance(start, int) or not isinstance(end, int):
        raise CoordinateNotResolvedError(
            f"{context}: expected concrete base-tree indices, "
            f"got (start={el.start_index!r}, end={el.end_index!r}). "
            "The coordinate contract guarantees the base tree is concrete; "
            "a None here is an invariant violation. "
            "See docs/coordinate_contract.md §who-reads-what."
        )
    return start, end


def _resolve_desired_range(
    desired_el: StructuralElement,
    *,
    base_anchor_start: int,
    cumulative_shift: int,
    local_offset: int = 0,
    context: str = "desired element",
) -> tuple[int, int]:
    """Synthesize a live-doc coordinate for a desired-tree element whose
    indices are ``(None, None)``.

    The live-doc start index is computed as::

        base_anchor_start + cumulative_shift + local_offset

    where:
    - ``base_anchor_start`` is the startIndex of the nearest preceding
      matched base element (callers must supply this; this helper does not
      try to walk up the tree).
    - ``cumulative_shift`` is the net byte delta produced by all prior ops in
      the current batch (positive for inserts, negative for deletes).
    - ``local_offset`` is a caller-supplied offset within the synthesized
      region (e.g. an intra-paragraph run offset).

    The element's length is derived from its structural content (text runs
    for paragraphs, recursive walk for tables). Raises
    ``CoordinateNotResolvedError`` if a length cannot be computed — for
    example a ``tableOfContents`` element with no indices and no other size
    signal.
    """
    start = base_anchor_start + cumulative_shift + local_offset
    try:
        length = _element_size(desired_el)
    except NotImplementedError as exc:
        raise CoordinateNotResolvedError(
            f"{context}: cannot synthesize desired-range length — "
            f"no concrete indices and no derivable size. Root cause: {exc}"
        ) from None
    return start, start + length


def _para_text(para: Paragraph) -> str:
    """Return concatenated text from a Paragraph."""
    texts: list[str] = []
    for e in para.elements or []:
        if e.text_run is not None and e.text_run.content is not None:
            texts.append(e.text_run.content)
    return "".join(texts)


def _dict_changed_fields(
    base_dict: dict[str, object],
    desired_dict: dict[str, object],
) -> list[str]:
    """Return the camelCase field names that differ between two style dicts."""
    all_keys = set(base_dict) | set(desired_dict)
    return [k for k in all_keys if base_dict.get(k) != desired_dict.get(k)]


def _text_style_changed_fields(
    base_style: TextStyle,
    desired_style: TextStyle,
) -> list[str]:
    """Return the camelCase field names that differ between two TextStyle models."""
    return _dict_changed_fields(
        base_style.model_dump(by_alias=True, exclude_none=True),
        desired_style.model_dump(by_alias=True, exclude_none=True),
    )


# ---------------------------------------------------------------------------
# Request builder helpers
# ---------------------------------------------------------------------------


def _make_create_header(
    *,
    tab_id: str,
    header_type: str,
) -> Request:
    section_break_loc = Location(index=0, tab_id=tab_id) if tab_id else None
    return Request(
        create_header=CreateHeaderRequest(
            type=CreateFooterRequestType(header_type),
            section_break_location=section_break_loc,
        )
    )


def _make_create_footer(
    *,
    tab_id: str,
    footer_type: str,
) -> Request:
    section_break_loc = Location(index=0, tab_id=tab_id) if tab_id else None
    return Request(
        create_footer=CreateFooterRequest(
            type=CreateFooterRequestType(footer_type),
            section_break_location=section_break_loc,
        )
    )


def _make_delete_header(*, header_id: str, tab_id: str) -> Request:
    return Request(
        delete_header=DeleteHeaderRequest(
            header_id=header_id,
            tab_id=tab_id if tab_id else None,
        )
    )


def _make_delete_footer(*, footer_id: str, tab_id: str) -> Request:
    return Request(
        delete_footer=DeleteFooterRequest(
            footer_id=footer_id,
            tab_id=tab_id if tab_id else None,
        )
    )


def _make_delete_tab(*, tab_id: str) -> Request:
    return Request(
        delete_tab=DeleteTabRequest(tab_id=tab_id),
    )


def _make_add_document_tab(
    *,
    title: str,
    index: int | None = None,
    parent_tab_id: str | None = None,
) -> Request:
    return Request(
        add_document_tab=AddDocumentTabRequest(
            tab_properties=TabProperties(
                title=title,
                index=index,
                parent_tab_id=parent_tab_id,
            ),
        )
    )


def _make_create_footnote(*, index: int, tab_id: str) -> Request:
    """Build a createFootnote Request."""
    return Request(
        create_footnote=CreateFootnoteRequest(
            location=Location(
                index=index,
                tab_id=tab_id if tab_id else None,
            ),
        )
    )


def _make_delete_content_range(
    *,
    start_index: int,
    end_index: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None = None,
) -> Request:
    return Request(
        delete_content_range=DeleteContentRangeRequest(
            range=Range(
                start_index=start_index,
                end_index=end_index,
                tab_id=tab_id if tab_id else None,
                segment_id=segment_id if segment_id else None,
            ),
        )
    )


def _make_insert_text(
    *,
    index: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
    text: str,
) -> Request:
    return Request(
        insert_text=InsertTextRequest(
            location=Location(
                index=index,
                tab_id=tab_id if tab_id else None,
                segment_id=segment_id if segment_id else None,
            ),
            text=text,
        )
    )


def _make_update_paragraph_style(
    *,
    start_index: int,
    end_index: int,
    tab_id: _StrOrDeferred,
    segment_id: _StrOrDeferred | None,
    paragraph_style: ParagraphStyle | dict[str, object],
    fields: list[str],
) -> Request:
    ps = (
        paragraph_style
        if isinstance(paragraph_style, ParagraphStyle)
        else ParagraphStyle.model_validate(paragraph_style)
    )
    return Request(
        update_paragraph_style=UpdateParagraphStyleRequest(
            range=Range(
                start_index=start_index,
                end_index=end_index,
                tab_id=tab_id if tab_id else None,
                segment_id=segment_id if segment_id else None,
            ),
            paragraph_style=ps,
            fields=",".join(fields),
        )
    )


def _make_update_named_style(
    *,
    tab_id: str,
    style: NamedStyle,
) -> Request:
    """Emit an updateDocumentStyle request to update/insert a single named style.

    The Google Docs API uses ``updateDocumentStyle`` with a ``namedStyles``
    payload to update named styles.  Since the typed ``UpdateDocumentStyleRequest``
    model doesn't have a ``namedStyles`` field, we use ``model_validate`` with
    the raw dict to leverage ``extra="allow"`` on the model.
    """
    style_dict = style.model_dump(by_alias=True, exclude_none=True)
    inner: dict[str, object] = {
        "namedStyles": {
            "styles": [style_dict],
        },
        "fields": "namedStyles",
    }
    if tab_id:
        inner["tabId"] = tab_id
    return Request(
        update_document_style=UpdateDocumentStyleRequest.model_validate(inner),
    )


def _make_update_section_style_deferred(
    *,
    tab_id: str,
    field_name: str,
    deferred_id: DeferredID,
) -> Request:
    """Emit an updateSectionStyle that attaches a freshly created header/footer.

    The header/footer ID is a DeferredID placeholder resolved after Batch 0.
    We use a full-document range (0→1) which is the typical pattern for
    applying a header/footer to the DEFAULT slot.
    """
    # The field_name is a camelCase alias (e.g. "defaultHeaderId") and the
    # value is a DeferredID.  SectionStyle's typed fields are str | None,
    # so we use model_construct to bypass validation and inject the DeferredID.
    # Map camelCase alias → snake_case Python field name.
    _ALIAS_TO_FIELD = {
        "defaultHeaderId": "default_header_id",
        "firstPageHeaderId": "first_page_header_id",
        "evenPageHeaderId": "even_page_header_id",
        "defaultFooterId": "default_footer_id",
        "firstPageFooterId": "first_page_footer_id",
        "evenPageFooterId": "even_page_footer_id",
    }
    python_field = _ALIAS_TO_FIELD.get(field_name, field_name)
    # Deliberately inject DeferredID into a str field; resolved before execution.
    section_style = SectionStyle.model_construct(**{python_field: deferred_id})  # type: ignore[arg-type]
    return Request(
        update_section_style=UpdateSectionStyleRequest(
            range=Range(
                start_index=0,
                end_index=1,
                tab_id=tab_id if tab_id else None,
            ),
            section_style=section_style,
            fields=field_name,
        )
    )


# ---------------------------------------------------------------------------
# Table structural request helpers
# ---------------------------------------------------------------------------


def _table_start_location(
    *,
    table_start_index: int,
    tab_id: str,
) -> Location:
    return Location(
        index=table_start_index,
        tab_id=tab_id if tab_id else None,
    )


def _make_insert_table_row(
    *,
    table_start_index: int,
    row_index: int,
    insert_below: bool,
    tab_id: str,
) -> Request:
    return Request(
        insert_table_row=InsertTableRowRequest(
            table_cell_location=TableCellLocation(
                table_start_location=_table_start_location(
                    table_start_index=table_start_index,
                    tab_id=tab_id,
                ),
                row_index=row_index,
                column_index=0,
            ),
            insert_below=insert_below,
        )
    )


# Per-cell overhead in a newly-inserted (empty) table row, in bytes:
#   1 byte: cell start-overhead
#   1 byte: one empty paragraph ("\n")
# Note: rows created by ``insertTableRow`` contain exactly ONE paragraph per
# cell (observed on the live Google Docs API). This differs from cells
# authored via ``insertTable`` (which carry two paragraphs per cell).
_EMPTY_CELL_SIZE = 2
# One-byte row-overhead prefix each new row carries.
_ROW_OVERHEAD = 1


def _make_new_row_cell_text_inserts(
    *,
    new_row_start_index: int | None,
    new_cell_texts: list[str],
    tab_id: str,
) -> list[Request]:
    """Emit ``insertText`` requests that populate an empty, just-inserted row.

    After ``insertTableRow``, the new row exists at ``new_row_start_index``
    (in LIVE doc coords — shifted by all prior batch ops) with predictable
    byte layout (each cell is ``_EMPTY_CELL_SIZE`` bytes;
    rows have a ``_ROW_OVERHEAD`` byte prefix). We emit one ``insertText`` per
    non-empty cell, targeting the cell's first paragraph. We emit them in
    REVERSE column order so each insert does not invalidate the byte offsets
    computed for earlier (lower-column) cells.
    """
    if not new_cell_texts:
        return []
    if new_row_start_index is None:
        # Synthetic docs without API indices: diff emits an empty
        # ``new_cell_texts`` in that case, so reaching this branch with a
        # populated list would be an invariant violation.
        raise ValueError(
            "InsertTableRowOp carries new_cell_texts but no "
            "new_row_start_index; cannot compute cell byte offsets"
        )

    # Position of cell ``c``'s first paragraph (the empty "\n" inserted by
    # insertTableRow): new_row_start + row_overhead + c * cell_size + cell_overhead
    # The cell_overhead is 1, so the first paragraph sits at:
    #     new_row_start + 1 + c * 3 + 1
    requests: list[Request] = []
    for col_idx in reversed(range(len(new_cell_texts))):
        text = new_cell_texts[col_idx]
        if not text:
            continue
        p1_index = (
            new_row_start_index
            + _ROW_OVERHEAD
            + col_idx * _EMPTY_CELL_SIZE
            + 1  # cell start-overhead
        )
        requests.append(
            _make_insert_text(
                index=p1_index,
                tab_id=tab_id,
                segment_id=None,
                text=text,
            )
        )
    return requests


def _compute_index_shift_for_body_ref(
    batch: list[Request],
    *,
    base_index: int,
    tab_id: str,
    struct_events_by_req_id: dict[int, list[tuple[str, int, int]]] | None = None,
) -> int:
    """Return the net byte shift at ``base_index`` caused by prior body-text
    ops in ``batch`` for ``tab_id``'s body segment.

    Ops in ``batch`` are emitted in execution order. Each ``insertText`` /
    ``deleteContentRange`` request's indices are valid at the point it runs
    (the body-content lowerer emits them in descending base-index order so
    they are self-consistent). Requests emitted AFTER body-text ops (such as
    table-structural ops) use BASE indices and therefore need to be shifted
    by the cumulative delta body-text ops impose at positions ≤ their
    reference index.

    We walk ``batch`` in order, maintaining ``current`` = the live position
    of ``base_index`` after each op executes:

    - ``insertText(loc=L, text=T)``: if ``L <= current``, ``current += len(T)``.
    - ``deleteContentRange(start=s, end=e)``: if ``e <= current``, ``current -= (e - s)``.
      If ``s >= current``, no shift. Partial-overlap deletes are not emitted
      by the reconciler (deletes are always whole structural elements),
      so we don't model them here and raise on encounter.

    Table-structural requests (``insertTableRow``/``insertTableColumn``) do
    NOT appear in ``batch`` as insertText/deleteContentRange, but they DO
    inject bytes into the body segment. The caller records those byte
    injections in ``struct_events`` (parallel list to ``batch``); each entry
    is a list of ``(tab_id, live_index, delta)`` tuples where ``live_index``
    is the insertion position in the frame that exists AFTER the event
    executes. The shift rule mirrors ``insertText``: if ``live_index <
    current``, the delta applies (strict ``<`` because new cells are
    inserted AT a structural boundary, and the anchor is precisely at that
    boundary — content AT the boundary stays at the boundary, content
    strictly after moves forward).

    ``insertTable`` requests also inject structural overhead bytes that are
    NOT captured by the cell-fill ``insertText`` requests.  After
    ``insertTable`` creates an empty RxC skeleton at position L, the document
    grows by::

        structural_bytes = 2 + R x (1 + 2 x C)

    (1 pre-table ``\\n`` + 1 table-opener + R row-openers + RxCx2 empty-cell
    bytes).  These bytes ARE at position L (≤ any subsequent body reference
    above L) and therefore contribute to the shift just like an insertText.

    Only body-segment requests (``segment_id=None``, matching ``tab_id``)
    contribute; header/footer/footnote ops live in distinct coordinate spaces.
    """
    current = base_index
    for req in batch:
        if struct_events_by_req_id is not None:
            events = struct_events_by_req_id.get(id(req))
            if events is not None:
                for ev_tab_id, ev_index, ev_delta in events:
                    if ev_tab_id != tab_id:
                        continue
                    if ev_index < current:
                        current += ev_delta
        # Handle insertTable structural overhead (skeleton bytes not tracked
        # by the cell-fill insertText requests already in the batch).
        ins_table = req.insert_table
        if ins_table is not None:
            loc = ins_table.location
            if loc is not None and loc.segment_id is None and loc.tab_id == tab_id:
                idx = loc.index
                if isinstance(idx, int) and idx <= current:
                    r = ins_table.rows or 0
                    c = ins_table.columns or 0
                    structural_bytes = 2 + r * (1 + 2 * c)
                    current += structural_bytes
            continue
        it = req.insert_text
        dcr = req.delete_content_range
        if it is not None:
            loc = it.location
            if loc is None or loc.index is None:
                continue
            if loc.segment_id is not None:
                continue
            if loc.tab_id != tab_id:
                continue
            text = it.text or ""
            if loc.index <= current:
                current += len(text)
            continue
        if dcr is not None:
            rng = dcr.range
            if rng is None or rng.start_index is None or rng.end_index is None:
                continue
            if rng.segment_id is not None:
                continue
            if rng.tab_id != tab_id:
                continue
            s, e = rng.start_index, rng.end_index
            if e <= current:
                current -= e - s
            elif s >= current:
                continue
            else:
                # Delete straddles the reference position. The reconciler
                # only emits whole-element deletes, and table-structural
                # refs are always at a structural boundary, so this should
                # never happen. Raise loudly if it does.
                raise ValueError(
                    f"deleteContentRange [{s},{e}) straddles table "
                    f"reference index {base_index} (live position "
                    f"{current}); cannot compute shift."
                )
    return current - base_index


def _make_new_column_cell_text_inserts(
    *,
    new_cell_anchor_indices: list[int | None],
    new_cell_texts: list[str],
    insert_right: bool,
    tab_id: str,
) -> list[Request]:
    """Emit ``insertText`` requests populating an empty, just-inserted column.

    After ``insertTableColumn``, each base row has gained one new
    ``_EMPTY_CELL_SIZE``-byte cell (1 cell-overhead + 1 ``\\n`` paragraph —
    same layout as rows created by ``insertTableRow``). The new cell's
    position in each row is determined by the anchor cell's boundary in the
    LIVE document (as shifted by all prior batch ops): for
    ``insert_right=True`` the anchor is that cell's ``end_index``; for
    ``insert_right=False`` the anchor is its ``start_index``. Because every
    earlier base row has also gained a new cell, row ``R``'s anchor must be
    shifted by ``R * _EMPTY_CELL_SIZE`` to land on the POST-insert absolute
    byte index.

    We emit one ``insertText`` per non-empty cell, targeting the cell's
    ``\\n`` paragraph, in REVERSE row order so each insert only shifts byte
    offsets at strictly greater indices (which we've already processed).
    """
    if not new_cell_texts:
        return []
    if len(new_cell_anchor_indices) != len(new_cell_texts):
        raise ValueError(
            "InsertTableColumnOp: new_cell_anchor_indices and new_cell_texts "
            "must have the same length"
        )

    requests: list[Request] = []
    # Iterate rows bottom-up so each emitted insert does not shift offsets of
    # subsequent (higher-row) inserts we still need to emit.
    for row_idx in reversed(range(len(new_cell_texts))):
        text = new_cell_texts[row_idx]
        if not text:
            continue
        anchor = new_cell_anchor_indices[row_idx]
        if anchor is None:
            raise ValueError(
                f"InsertTableColumnOp: row {row_idx} has non-empty "
                f"new_cell_text but no anchor index; cannot compute byte offset"
            )
        # Post-insert absolute index of the new cell's first (only) paragraph:
        #   anchor + row_idx * _EMPTY_CELL_SIZE  (cumulative shift from this
        #     op's earlier rows' new cells)
        #   + 1                                  (the new cell's start-overhead)
        # For insert_right=True, anchor = base_cell.end_index → the new cell
        # begins exactly at that byte. For insert_right=False, anchor =
        # base_cell.start_index → the new cell is inserted BEFORE the anchor,
        # and begins at that byte too. Both paths share the same formula.
        _ = insert_right  # kept for documentation symmetry; formula identical
        p1_index = anchor + row_idx * _EMPTY_CELL_SIZE + 1
        requests.append(
            _make_insert_text(
                index=p1_index,
                tab_id=tab_id,
                segment_id=None,
                text=text,
            )
        )
    return requests


def _make_delete_table_row(
    *,
    table_start_index: int,
    row_index: int,
    tab_id: str,
) -> Request:
    return Request(
        delete_table_row=DeleteTableRowRequest(
            table_cell_location=TableCellLocation(
                table_start_location=_table_start_location(
                    table_start_index=table_start_index,
                    tab_id=tab_id,
                ),
                row_index=row_index,
                column_index=0,
            ),
        )
    )


def _make_insert_table_column(
    *,
    table_start_index: int,
    column_index: int,
    insert_right: bool,
    tab_id: str,
) -> Request:
    return Request(
        insert_table_column=InsertTableColumnRequest(
            table_cell_location=TableCellLocation(
                table_start_location=_table_start_location(
                    table_start_index=table_start_index,
                    tab_id=tab_id,
                ),
                row_index=0,
                column_index=column_index,
            ),
            insert_right=insert_right,
        )
    )


def _make_delete_table_column(
    *,
    table_start_index: int,
    column_index: int,
    tab_id: str,
) -> Request:
    return Request(
        delete_table_column=DeleteTableColumnRequest(
            table_cell_location=TableCellLocation(
                table_start_location=_table_start_location(
                    table_start_index=table_start_index,
                    tab_id=tab_id,
                ),
                row_index=0,
                column_index=column_index,
            ),
        )
    )


def _make_update_table_cell_style(
    *,
    table_start_index: int,
    row_index: int,
    column_index: int,
    desired_style: TableCellStyle,
    fields_mask: str,
    tab_id: str,
) -> Request:
    loc = _table_start_location(
        table_start_index=table_start_index,
        tab_id=tab_id,
    )
    return Request(
        update_table_cell_style=UpdateTableCellStyleRequest(
            table_start_location=loc,
            table_range=TableRange(
                table_cell_location=TableCellLocation(
                    table_start_location=_table_start_location(
                        table_start_index=table_start_index,
                        tab_id=tab_id,
                    ),
                    row_index=row_index,
                    column_index=column_index,
                ),
                row_span=1,
                column_span=1,
            ),
            table_cell_style=desired_style,
            fields=fields_mask,
        )
    )


def _make_update_table_row_style(
    *,
    table_start_index: int,
    row_index: int,
    min_row_height: Dimension | None,
    tab_id: str,
) -> Request:
    return Request(
        update_table_row_style=UpdateTableRowStyleRequest(
            table_start_location=_table_start_location(
                table_start_index=table_start_index,
                tab_id=tab_id,
            ),
            row_indices=[row_index],
            table_row_style=TableRowStyle(min_row_height=min_row_height),
            fields="minRowHeight",
        )
    )


def _make_update_table_column_properties(
    *,
    table_start_index: int,
    column_index: int,
    width: Dimension | None,
    width_type: str | None,
    tab_id: str,
) -> Request:
    fields_parts: list[str] = []
    if width is not None:
        fields_parts.append("width")
    if width_type is not None:
        fields_parts.append("widthType")
    fields_mask = ",".join(sorted(fields_parts)) if fields_parts else "widthType"
    return Request(
        update_table_column_properties=UpdateTableColumnPropertiesRequest(
            table_start_location=_table_start_location(
                table_start_index=table_start_index,
                tab_id=tab_id,
            ),
            column_indices=[column_index],
            table_column_properties=TableColumnProperties(
                width=width,
                width_type=width_type,
            ),
            fields=fields_mask,
        )
    )
