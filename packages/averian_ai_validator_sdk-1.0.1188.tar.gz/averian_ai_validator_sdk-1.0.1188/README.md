# Averian AI Validator SDK

Python SDK for the Averian AI Validator platform. Integrate anomaly detection inference into your application in minutes.

## Installation

```bash
pip install averian-ai-validator-sdk
```

## Prerequisites

- An **API key** with inference access — obtained from the Organization Settings page by an admin user
- A project with at least one trained and hosted model ensemble

## Quick Start — Inference

This guide assumes your project, input source, and model are already set up in the Averian AI Validator platform.

### Step 1 — Connect

```python
from averian_ai_validator_sdk import APIClient

api = APIClient()
api.connect("https://api.yourhost.com", "YOUR_API_KEY")
```

For servers with a self-signed certificate:

```python
api.connect("https://api.yourhost.com", "YOUR_API_KEY", ca_cert="/path/to/ca.pem")
```

> **API keys** are created and managed by admin users in the Organization Settings page. Each key has a specific level of access — contact your administrator to obtain a key with inference permissions.

### Step 2 — Select Project and Input Source

```python
# List and select a project
projects = api.get_projects()['projects']
project_id = projects[0]['id']  # or match by name

# List and select an input source
sources = api.get_input_sources(project_id)
input_id = sources[0]['id']  # or match by name
```

### Step 3 — Get the Model

The SDK uses the **default model ensemble** if one has been set for the input source, and falls back to the **last active model** if not.

```python
source = api.get_input_source_by_id(project_id, input_id)
model_id = source.get('defaultEnsemble')

if not model_id:
    model = api.get_last_active_model(project_id, input_id)
    if not model:
        raise RuntimeError("No hosted model available for this input source.")
    model_id = model['id']

print(f"Using model: {model_id}")
```

### Step 4 — Run Inference

```python
import os

image_path = "part_to_inspect.jpg"
img_name, img_ext = os.path.splitext(os.path.basename(image_path))
img_blob = api.read_file_as_blob(image_path)

result = api.infer(project_id, input_id, model_id, img_name, img_ext.lstrip("."), img_blob)

print(f"Anomalous: {result['isAnomalous']}")
print(f"Result ID: {result['id']}")
```

### Step 5 — Retrieve the Heatmap

```python
heatmap = api.fetch_result_image_with_heatmap(project_id, result['id'])
with open("heatmap.jpg", "wb") as f:
    f.write(heatmap)
print("Heatmap saved to heatmap.jpg")
```

### Step 6 — Clean Up (Optional)

```python
api.del_result(project_id, result['id'])
```

---

For the full API reference, visit the Averian AI Validator documentation.
