import os

import requests
import json
import base64
import urllib.parse
from enum import Enum
from typing import Optional, TypeAlias


AVAILABLE_PROCESSORS = [
    "AiModel",
    "RegionCrop",
    "GridSegmentation",
    "ReferenceImageCrop",
    "MultipleRegionsCrop",
    "ChamberDetector",
    "CircularCrop",
    "PolygonalCrop",
    "DefectiveImageFilter",
]


class ModelType(str, Enum):
    """Supported model types"""
    PATCHCORE = "Patchcore"
    PADIM = "Padim"


AnomalyCoordinates: TypeAlias = list[list[dict[str, float]]]
"""
Represents a set of anomaly coordinates.

Each anomaly is defined as a list of polygons, where:
- Each polygon is a list that contains dictionaries with 'x' and 'y' float values.

Example:
anomaly_coordinates = [
    [
        {"x": 0.51376953125, "y": 0.589375},
        {"x": 0.71626953125, "y": 0.589375},
        {"x": 0.71626953125, "y": 0.969375},
        {"x": 0.51376953125, "y": 0.969375}
    ]
]
"""
class APIClient:
    def __init__(self):
        self.api_host = ''
        self.verify: bool | str = True
        self._api_key = ''
        self._token_cache: dict[str, float] = {}  # {token: str, expires_at: float}

    def connect(self, api_host: str, api_key: str, ca_cert: Optional[str] = None):
        """
        Connect using an API key.

        The API key is bound to a specific organization — no separate Org ID is needed.

        Args:
            api_host (str): The API service host URL.
            api_key (str): The API key secret obtained at creation time.
            ca_cert (str, optional): Path to a PEM file containing the CA certificate
                to verify the server's SSL certificate. Use this when connecting to a
                server that uses a self-signed certificate. If None, the default system
                CA bundle is used. Defaults to None.

        Raises:
            ValueError: If ca_cert is provided but the file does not exist.
            Exception: If the API key authentication fails.
        """
        if ca_cert is not None:
            if not os.path.isfile(ca_cert):
                raise ValueError(f"ca_cert file not found: {ca_cert}")

        self.api_host = api_host
        self._api_key = api_key
        self.verify = ca_cert if ca_cert is not None else True

        # Validate credentials immediately
        self.__get_token()


###########################################################################
# Organizations functions
###########################################################################

    def get_organization(self) -> dict:
        """
        Get the organization this client is authenticated against.

        The API key is bound to a single organization; this method returns its descriptor.

        Returns:
            dict: The organization descriptor with the following keys:
            - orgID (str): The unique ID of the organization.
            - name (str): The name of the organization.
            - isExpired (bool): Whether the organization is expired or not.
            - metadata (list): Organization metadata.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f"{self.api_host}/orgapi/OrgAnyUser/MyOrg"
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            org = response.json()
            return {
                "orgID": org.get("id"),
                "name": org.get("name"),
                "isExpired": not org.get("isActive", True),
                "metadata": org.get("metadata", [])
            }
        else:
            raise Exception(f"Failed to fetch organization: URL={url} Status={response.status_code} Body={response.text}")


###########################################################################
# Projects functions
###########################################################################

    def create_project(self, project_name: str) -> dict:
        """
        Creates a new anomaly detection project.

        Args:
            project_name (str): The name of the project to be created.

        Returns:
            dict: A JSON object containing the project metadata with the following keys:
            - `orgID` (str): The organization ID to which the project belongs.
            - `id` (str): The unique identifier of the project.
            - `createdAt` (str): The timestamp when the project was created.
            - `name` (str): The name of the project.
            - `aspectRatio` (float): The aspect ratio of the project images.
            - `crop` (float): The crop setting of the project.
            - `thumbUrl` (str): URL of the project's thumbnail.
            - `channels` (list): A list of channels, each containing:
                - `id` (str): The unique identifier of the anomaly detection channel.
                - `imageHeight` (int, optional): The height of images in the channel.
                - `imageWidth` (int, optional): The width of images in the channel.
                - `batchSize` (int, optional): The batch size for processing.
                - `backbone` (dict): Model backbone settings with:
                    - `model` (str): The model name.
                    - `layer1` (bool): Whether Layer1 is enabled.
                    - `layer2` (bool): Whether Layer2 is enabled.
                    - `layer3` (bool): Whether Layer3 is enabled.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        encoded_project_name = urllib.parse.quote(project_name)
        url = f'{self.api_host}/vision/AnomalyDetectionMC/CreateProject/{encoded_project_name}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to create project: URL={url} Status={response.status_code} Body={response.text}")

    def get_projects(self) -> dict:
        """
        Retrieves the list of projects for the authenticated organization.

        Returns:
            dict: A JSON object containing the list of projects with the following keys:
            - `succeeded` (bool): Indicates whether the request was successful.
            - `error` (str, optional): Error message if the request failed.
            - `projects` (list): A list of project metadata, where each project contains:
                - `id` (str): The unique identifier of the project.
                - `createdAt` (str): The timestamp when the project was created.
                - `name` (str): The name of the project.
                - `aspectRatio` (float): The aspect ratio of the project images.
                - `crop` (float): The crop setting of the project.
                - `thumbUrl` (str): URL of the project's thumbnail.
            - `nextToken` (str, optional): A token for fetching the next set of results if pagination is supported.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/GetProjects'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch anomaly projects: URL={url} Status={response.status_code} Body={response.text}")

    def get_project_info(self, project_id: str) -> dict:
        """
        Retrieves detailed information about a specific anomaly detection project.

        Args:
            project_id (str): The unique identifier of the project.

        Returns:
            dict: A JSON object containing project details with the following keys:
            - `id` (str): The unique identifier of the project.
            - `createdAt` (str): The timestamp when the project was created.
            - `name` (str): The name of the project.
            - `aspectRatio` (float): The aspect ratio of the project images.
            - `crop` (float): The crop setting of the project.
            - `thumbUrl` (str): URL of the project's thumbnail.
            - `normalImages` (int): The number of normal images in the project.
            - `anomalousImages` (int): The number of anomalous images in the project.
            - `newImages` (int): The number of new images added to the project.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/GetProject/{project_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch project info: URL={url} Status={response.status_code} Body={response.text}")

    def delete_project(self, project_id: str) -> None:
        """
        Deletes an anomaly detection project.

        Args:
            project_id (str): The unique identifier of the project to be deleted.

        Returns:
            None

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/DeleteProject/{project_id}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code != 200:
            raise Exception(f"Failed to delete project: URL={url} Status={response.status_code} Body={response.text}")


###########################################################################
# Input sources management functions
###########################################################################

    def get_input_sources(self, project_id: str) -> list[dict]:
        """
        Retrieves the input sources associated with a specific project.

        Args:
            project_id (str): The unique identifier of the project.

        Returns:
            list[dict]: A list of input source objects, where each object contains:
            - `id` (str): The unique identifier of the input source.
            - `name` (str): The name of the input source.
            - `segmentationStatus` (str): The segmentation status, which can be:
                - `"COMPLETED"`: Segmentation has been successfully completed.
                - `"INPROGRESS"`: Segmentation is currently in progress.
                - `"FAILED"`: Segmentation failed.
            - `isSetup` (bool): Indicates whether the input source has been set up.
            - `hasDraft` (bool): Indicates whether a draft version of the input source exists.
            - `defaultEnsemble` (str, optional): The ID of the default models ensemble associated with this input source.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/InputSource/{project_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch input sources: URL={url} Status={response.status_code} Body={response.text}")

    def add_input_source(self, project_id: str, name: str) -> dict:
        """
        Adds a new input source to the specified project.

        Args:
            project_id (str): The unique identifier of the project.
            name (str): The name of the new input source.

        Returns:
            dict: A JSON object representing the newly created input source with the following keys:
            - `id` (str): The unique identifier of the input source.
            - `name` (str): The name of the input source.
            - `segmentationStatus` (str): The segmentation status, which can be:
                - `"COMPLETED"`: Segmentation has been successfully completed.
                - `"INPROGRESS"`: Segmentation is currently in progress.
                - `"FAILED"`: Segmentation failed.
            - `isSetup` (bool): Indicates whether the input source has been set up.
            - `hasDraft` (bool): Indicates whether a draft version of the input source exists.
            - `defaultEnsemble` (str, optional): The ID of the default models ensemble associated with this input source.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        body = {
            'Name': name
        }
        url = f'{self.api_host}/vision/InputSource/Add/{project_id}'
        response = requests.post(url, headers=headers, json=body, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to add input source: URL={url} Status={response.status_code} Body={response.text}")

    def get_input_source_by_id(self, project_id: str, input_id: str) -> dict:
        """
        Retrieves a specific input source by its ID.

        Args:
            project_id (str): The unique identifier of the project.
            input_id (str): The unique identifier of the input source.

        Returns:
            dict: A JSON object representing the input source with the following keys:
            - `id` (str): The unique identifier of the input source.
            - `name` (str): The name of the input source.
            - `segmentationStatus` (str): The segmentation status, which can be:
                - `"COMPLETED"`: Segmentation has been successfully completed.
                - `"INPROGRESS"`: Segmentation is currently in progress.
                - `"FAILED"`: Segmentation failed.
            - `isSetup` (bool): Indicates whether the input source has been set up.
            - `hasDraft` (bool): Indicates whether a draft version of the input source exists.
            - `defaultEnsemble` (str, optional): The ID of the default models ensemble associated with this input source.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/InputSource/{project_id}/{input_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch input source: URL={url} Status={response.status_code} Body={response.text}")

    def set_default_ensemble(self, project_id: str, input_id: str, ensemble_id: str, set_as_default: bool = True) -> None:
        """
        Sets the default ensemble for a specific input source.

        Args:
            project_id (str): The unique identifier of the project.
            input_id (str): The unique identifier of the input source.
            ensemble_id (str): The unique identifier of the ensemble to set as default.
            set_as_default (bool, optional): Whether to set this ensemble as the default. Defaults to True.

        Returns:
            None

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/InputSource/SetDefaultEnsemble/{project_id}/{input_id}/{ensemble_id}'
        params = {"setAsDefault": set_as_default}
        response = requests.put(url, headers=headers, params=params, verify=self.verify)

        if response.status_code != 200:
            raise Exception(f"Failed to set default ensemble: URL={url} Status={response.status_code} Body={response.text}")

    def del_input_source(self, project_id: str, input_id: str) -> dict:
        """
        Deletes an input source from the specified project by ID.

        Args:
            project_id (str): The unique identifier of the project.
            input_id (str): The unique identifier of the input source.

        Returns:
            dict: A JSON object containing the result of the deletion operation.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/InputSource/Del/{project_id}/{input_id}'
        response = requests.delete(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to delete input source: URL={url} Status={response.status_code} Body={response.text}")


    def list_input_images(self, project_id: str, input_id: str, isAnomalous: bool|None = None, page=1, page_size=10):
        """
        Fetches a list of images from the anomaly detection service.

        Args:
            project_id (str): The ID of the project within the organization.
            input_id (str): The input source id.
            isAnomalous (bool, optional): Filters images by anomaly status. If None, includes both anomalous and non-anomalous images.
            page (int, optional): The page number for pagination. Defaults to 1.
            page_size (int, optional): The number of images per page. Defaults to 10.

        Returns:
            dict: A dictionary containing a list of images and the total count of images. Each image object contains:
                - `id`: Unique identifier for the image.
                - `createdAt`: Timestamp of image creation.
                - `inputId`: ID associated with the input.
                - `isAnomalous`: Boolean indicating if the image is anomalous.
                - `imgName`: The name of the image.
                - `imgExt`: The file extension of the image (e.g., jpeg).
                - `thumbUrl`: URL of the image thumbnail.
                - `isNew`: Boolean indicating if the image is new.
                - `anomalyCoordinates`: List of coordinates highlighting detected anomalies, if any.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.

        Example output:
            {
                "images": [
                    {
                        "id": "667f37ce-11f6-484b-ad91-5450b0e420a8",
                        "createdAt": "2025-02-24T17:45:38.104Z",
                        "inputId": "22de0905-f2a7-4aea-be01-abc7011d0941",
                        "isAnomalous": true,
                        "imgExt": "jpeg",
                        "thumbUrl": "https://api.arvizio.cloud/data/thumbs/...",
                        "isNew": false,
                        "anomalyCoordinates": [
                            [
                                {"x": 0.5975, "y": 0.559375},
                                {"x": 0.8025, "y": 0.559375},
                                {"x": 0.8025, "y": 0.919375},
                                {"x": 0.5975, "y": 0.919375}
                            ]
                        ]
                    },
                    ...
                ],
                "totalImages": 30
            }
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/ListInputImages/{project_id}/{input_id}'
        params = {"page": page, "pageSize": page_size}
        if isAnomalous is not None:
            params["isAnomalous"] = isAnomalous  # Only include if not None

        response = requests.get(url, headers=headers, params=params, verify=self.verify)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch input images: URL={url} Status={response.status_code} Body={response.text}")


    def fetch_input_image(self, project_id: str, image_id: str) -> bytes:
        """
        Fetches an input image bytes.

        Args:
            project_id (str): The identifier for the project.
            image_id (str): The identifier for the specific image to retrieve.

        Returns:
            bytes: The image data as bytes, representing the fetched image.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers('blob')
        url = f'{self.api_host}/vision/AnomalyDetectionMC/GetInputImage/{project_id}/{image_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.content
        else:
            raise Exception(f"Failed to fetch dataset image: URL={url} Status={response.status_code} Body={response.text}")

    def apply_configuration_changes(self, project_id: str, input_id: str):
        """
        Applies the configuration changes for the specified input source.

        Args:
            project_id (str): The unique identifier of the project.
            input_id (str): The unique identifier of the input source.
        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        
        url = f'{self.api_host}/vision/InputSource/Setup/{project_id}/{input_id}?createSnap=false'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.content
        else:
            raise Exception(f"Failed to apply configuration changes: URL={url} Status={response.status_code} Body={response.text}")

    def get_segmentation_status(self, project_id: str) -> dict:
        """
        Retrieves the segmentation status for the specified project.

        Args:
            project_id (str): The unique identifier of the project.
        Returns:
            dict: Statuss of the segmentation with the following keys
        """
        headers = self.__get_api_headers()
       
        url = f'{self.api_host}/vision/InputSource/{project_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch segmentation status: URL={url} Status={response.status_code} Body={response.text}")


###########################################################################
# Image Processor functions
###########################################################################
    def get_image_processors(self, project_id: str, input_id: str) -> list[dict]:
        """
        Retrieves the image processors associated with a specific input source.

        Args:
            project_id (str): The unique identifier of the project.
            input_id (str): The unique identifier of the input source.

        Returns:
            list[dict]: A list of image processor objects, where each object contains:
            - `id` (str): The unique identifier of the image processor.
            - `processorKey` (str): The key identifying the type of processor (e.g., "AiModel", "RegionCrop").
            - `parentProcessorId` (str): The unique identifier of the parent processor, or "undefined" if none.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/ImageProcessor/GetDraft/{project_id}/{input_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch images: URL={url} Status={response.status_code} Body={response.text}")

    def add_image_processor(self, project_id: str, input_id: str, processor_key: str="", parent_processor_id: str = "undefined") -> dict:
        """
        Creates a new image processor for the specified project and input source.

        Args:
            project_id (str): The unique identifier of the project.
            input_id (str): The unique identifier of the input source.
            processor_key (str): The key identifying the type of processor to create.
            parent_processor_id (str): The unique identifier of the parent processor. Defaults to "undefined".

        Returns:
            dict: A JSON object containing the image processor metadata.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        if processor_key == "":
            processor_key = AVAILABLE_PROCESSORS[0] # default to "AI Model" processor if not specified
        else:
            if processor_key not in AVAILABLE_PROCESSORS:
                raise Exception(f"Invalid processor key '{processor_key}'. Available processors are: {', '.join(AVAILABLE_PROCESSORS)}")

        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/ImageProcessor/{project_id}/{input_id}/{processor_key}/{parent_processor_id}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to create image processor:  URL={url} Status={response.status_code} Body={response.text}")

    def del_image_processor(self, processor_id: str):
        """
        Deletes input source from the specified project by ID.

        Args:
            processor_id (str): The unique identifier of the image processor.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/ImageProcessor/{processor_id}'
        response = requests.delete(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to delete image processor: URL={url} Status={response.status_code} Body={response.text}")

    def get_models(self, project_id: str, input_id: str):
        """
        Fetches the models ensembles for a specific project.
        A models ensemble is a set of models created from different segments of input pictures.

        Args:
            project_id (str): The ID of the project for which models ensembles are being retrieved.
            input_id (str): The ID of the input source.

        Returns:
            list: A list of dictionaries representing models ensembles for the given project. Each dictionary contains:
            - `orgID` (str): The unique identifier of the organization.
            - `projectID` (str): The unique identifier of the project.
            - `inputID` (str): The unique identifier of the input associated with the models ensemble.
            - `id` (str): The unique identifier of the models ensemble.
            - `name` (str): The custom name of the models ensemble.
            - `createdAt` (str): The timestamp when the models ensemble was created, in ISO 8601 format (e.g., "2025-02-24T17:47:28.868Z").
            - `status` (str): The status of the models ensemble, which can be:
                - `"HOSTED"`: The models ensemble is hosted and ready to use.
                - Other possible statuses (`"CREATED"`, `"TRAINING"`, `"FAILED"`, `"CANCELLED"`, `"CANCELLING"`)
            - `statusMessage` (str): Detailed status information.
            - `isPublished` (bool): Indicates whether the ensemble is published/visible.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/GetModelsEnsembles/{project_id}/{input_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch models: URL={url} Status={response.status_code} Body={response.text}")

    def update_ensemble_name(self, project_id: str, ensemble_id: str, name: str) -> None:
        """
        Updates the name of a models ensemble.

        Args:
            project_id (str): The unique identifier of the project.
            ensemble_id (str): The unique identifier of the models ensemble.
            name (str): The new name for the ensemble.

        Returns:
            None

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        body = {
            'Name': name
        }
        url = f'{self.api_host}/vision/AnomalyDetectionMC/UpdateEnsembleName/{project_id}/ensemble/{ensemble_id}'
        response = requests.put(url, headers=headers, json=body, verify=self.verify)

        if response.status_code != 200:
            raise Exception(f"Failed to update ensemble name: URL={url} Status={response.status_code} Body={response.text}")

    def delete_ensemble(self, project_id: str, ensemble_id: str) -> None:
        """
        Deletes a models ensemble from the specified project.

        Args:
            project_id (str): The unique identifier of the project.
            ensemble_id (str): The unique identifier of the models ensemble to be deleted.

        Returns:
            None

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/DeleteEnsemble/{project_id}/{ensemble_id}'
        response = requests.delete(url, headers=headers, verify=self.verify)

        if response.status_code != 200:
            raise Exception(f"Failed to delete ensemble: URL={url} Status={response.status_code} Body={response.text}")

    def update_ensemble_published_state(self, project_id: str, ensemble_id: str, is_published: bool) -> None:
        """
        Updates the published state of a models ensemble.

        Args:
            project_id (str): The unique identifier of the project.
            ensemble_id (str): The unique identifier of the models ensemble.
            is_published (bool): Whether the ensemble should be published/visible.

        Returns:
            None

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/UpdateEnsemblePublishedState/{project_id}/{ensemble_id}/{is_published}'
        response = requests.put(url, headers=headers, verify=self.verify)

        if response.status_code != 200:
            raise Exception(f"Failed to update ensemble published state: URL={url} Status={response.status_code} Body={response.text}")

    def retrain_ensemble(self, project_id: str, input_id: str, ensemble_id: str):
        """
        Retrains an existing models ensemble.

        Args:
            project_id (str): The identifier for the project.
            input_id (str): The input source id.
            ensemble_id (str): The identifier of the ensemble to retrain.

        Returns:
            dict: A dictionary representing the retrained models ensemble with the following keys:
            - `orgID` (str): The unique identifier of the organization.
            - `projectID` (str): The unique identifier of the project.
            - `inputID` (str): The unique identifier of the input associated with the models ensemble.
            - `id` (str): The unique identifier of the models ensemble.
            - `name` (str): The custom name of the models ensemble.
            - `createdAt` (str): The timestamp when the models ensemble was created, in ISO 8601 format (e.g., "2025-02-24T17:47:28.868Z").
            - `status` (str): The status of the models ensemble, which can be:
                - (`"CREATED"`, `"TRAINING"`, `"FAILED"`, `"CANCELLED"`, `"CANCELLING"`, `"HOSTED"`)
            - `statusMessage` (str): Detailed status information.
            - `isPublished` (bool): Indicates whether the ensemble is published/visible.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/RetrainModelsEnsemble/{project_id}/{input_id}/{ensemble_id}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to retrain ensemble: URL={url} Status={response.status_code} Body={response.text}")

    def get_ensemble_by_id(self, project_id: str, ensemble_id: str):
        """
        Retrieves a specific models ensemble by its ID.

        Args:
            project_id (str): The ID of the project.
            ensemble_id (str): The unique identifier of the models ensemble.

        Returns:
            dict: A dictionary representing the models ensemble with the following keys:
            - `orgID` (str): The unique identifier of the organization.
            - `projectID` (str): The unique identifier of the project.
            - `inputID` (str): The unique identifier of the input associated with the models ensemble.
            - `id` (str): The unique identifier of the models ensemble.
            - `name` (str): The custom name of the models ensemble.
            - `createdAt` (str): The timestamp when the models ensemble was created, in ISO 8601 format (e.g., "2025-02-24T17:47:28.868Z").
            - `status` (str): The status of the models ensemble.
            - `statusMessage` (str): Detailed status information.
            - `isPublished` (bool): Indicates whether the ensemble is published/visible.
            - `modelIds` (list): A list of model IDs that are part of this ensemble.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/GetEnsembleById/{project_id}/{ensemble_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch ensemble: URL={url} Status={response.status_code} Body={response.text}")

    def get_internal_models(self, project_id: str, ensemble_id: str):
        """
        Retrieves the internal models of a specific models ensemble.

        Args:
            project_id (str): The ID of the project.
            ensemble_id (str): The unique identifier of the models ensemble.

        Returns:
            list: A list of model metadata objects representing the internal models of the ensemble.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/GetInternalModels/{project_id}/{ensemble_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch internal models: URL={url} Status={response.status_code} Body={response.text}")

    def list_test_images(self, project_id: str, input_id: str, isAnomalous: bool|None = None, page=1, page_size=10):
        """
        Fetches a list of test images from the anomaly detection service.

        Args:
            project_id (str): The ID of the project within the organization.
            input_id (str): The input source id.
            isAnomalous (bool, optional): Filters images by anomaly status. If None, includes both anomalous and non-anomalous images.
            page (int, optional): The page number for pagination. Defaults to 1.
            page_size (int, optional): The number of images per page. Defaults to 10.

        Returns:
            dict: A dictionary containing a list of test images and the total count of images. Each image object contains:
                - `id`: Unique identifier for the image.
                - `createdAt`: Timestamp of image creation.
                - `inputId`: ID associated with the input.
                - `isAnomalous`: Boolean indicating if the image is anomalous.
                - `imgName`: The name of the image.
                - `imgExt`: The file extension of the image (e.g., jpeg).
                - `thumbUrl`: URL of the image thumbnail.
                - `anomalyCoordinates`: List of coordinates highlighting detected anomalies, if any.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/ListTestImages/{project_id}/{input_id}'
        params = {"page": page, "pageSize": page_size}
        if isAnomalous is not None:
            params["isAnomalous"] = isAnomalous  # Only include if not None

        response = requests.get(url, headers=headers, params=params, verify=self.verify)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch test images: URL={url} Status={response.status_code} Body={response.text}")

    def add_test_image_from_result(self, project_id: str, result_id: str, is_anomaly: bool, anomaly_coordinates: Optional[AnomalyCoordinates]):
        """
        Adds an image from anomaly detection results to the test dataset.

        Args:
            project_id (str): The identifier for the project.
            result_id (str): The identifier of the result image to be added to the test dataset.
            is_anomaly (bool): Indicates whether the image should be classified as anomalous (True) or normal (False).
            anomaly_coordinates (Optional[AnomalyCoordinates]): The coordinates of the detected anomaly (applicable for anomalous images).

        Returns:
            dict: A JSON response containing details about the newly added test image with the following keys:
            - `id`: Unique identifier for the image.
            - `createdAt`: Timestamp of image creation.
            - `inputId`: ID associated with the input.
            - `isAnomalous`: Boolean indicating if the image is anomalous.
            - `imgExt`: The file extension of the image (e.g., jpeg).
            - `thumbUrl`: URL of the image thumbnail.
            - `anomalyCoordinates`: List of coordinates highlighting detected anomalies, if any.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        anomaly_coordinates_encoded = self.__encode_anomaly_coordinates(anomaly_coordinates)
        url = f'{self.api_host}/vision/AnomalyDetectionMC/AddTestImageFromResult/{project_id}/{result_id}/{is_anomaly}/{anomaly_coordinates_encoded}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to add test image from result: URL={url} Status={response.status_code} Body={response.text}")

    def move_from_train_to_test(self, project_id: str, image_id: str):
        """
        Moves an image from the training dataset to the test dataset.

        Args:
            project_id (str): The identifier for the project.
            image_id (str): The identifier of the image to be moved.

        Returns:
            dict: A JSON response containing details about the moved image with the following keys:
            - `id` (str): Unique identifier for the image.
            - `createdAt` (str): Timestamp of image creation.
            - `inputId` (str): ID associated with the input.
            - `isAnomalous` (bool): Boolean indicating if the image is anomalous.
            - `imgName` (str): The name of the image.
            - `imgExt` (str): The file extension of the image (e.g., jpeg).
            - `thumbUrl` (str): URL of the image thumbnail.
            - `anomalyCoordinates` (list): List of coordinates highlighting detected anomalies, if any.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/MoveFromTrainToTest/{project_id}/{image_id}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to move image from train to test: URL={url} Status={response.status_code} Body={response.text}")

    def move_from_test_to_train(self, project_id: str, image_id: str):
        """
        Moves an image from the test dataset to the training dataset.

        Args:
            project_id (str): The identifier for the project.
            image_id (str): The identifier of the image to be moved.

        Returns:
            dict: A JSON response containing details about the moved image with the following keys:
            - `id` (str): Unique identifier for the image.
            - `createdAt` (str): Timestamp of image creation.
            - `inputId` (str): ID associated with the input.
            - `isAnomalous` (bool): Boolean indicating if the image is anomalous.
            - `imgName` (str): The name of the image.
            - `imgExt` (str): The file extension of the image (e.g., jpeg).
            - `thumbUrl` (str): URL of the image thumbnail.
            - `anomalyCoordinates` (list): List of coordinates highlighting detected anomalies, if any.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/MoveFromTestToTrain/{project_id}/{image_id}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to move image from test to train: URL={url} Status={response.status_code} Body={response.text}")

    def reclassify_test_image(self, project_id: str, image_id: str, is_anomaly: bool, anomaly_coordinates: Optional[AnomalyCoordinates], submit_non_defective: bool = True):
        """
        Reclassifies a test image's anomaly status.

        Args:
            project_id (str): The identifier for the project.
            image_id (str): The identifier of the image to be reclassified.
            is_anomaly (bool): The new anomaly status of the image (True for anomalous, False for normal).
            anomaly_coordinates (Optional[AnomalyCoordinates]): The coordinates of the detected anomaly (applicable for anomalous images).
            submit_non_defective (bool, optional): Whether to submit non-defective segments. Defaults to True.

        Returns:
            dict: A JSON response containing details about the reclassified test image with the following keys:
            - `id` (str): Unique identifier for the image.
            - `createdAt` (str): Timestamp of image creation.
            - `inputId` (str): ID associated with the input.
            - `isAnomalous` (bool): Boolean indicating if the image is anomalous.
            - `imgName` (str): The name of the image.
            - `imgExt` (str): The file extension of the image (e.g., jpeg).
            - `thumbUrl` (str): URL of the image thumbnail.
            - `anomalyCoordinates` (list): List of coordinates highlighting detected anomalies, if any.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        anomaly_coordinates_encoded = self.__encode_anomaly_coordinates(anomaly_coordinates)
        url = f'{self.api_host}/vision/AnomalyDetectionMC/ReclassifyTest/{project_id}/{image_id}/{is_anomaly}/{anomaly_coordinates_encoded}/{submit_non_defective}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to reclassify test image: URL={url} Status={response.status_code} Body={response.text}")

    def get_last_active_model(self, project_id: str, input_id: str):
        """
        Fetches the last active/hosted models ensemble for a specific project.

        Args:
            project_id (str): The ID of the project for which models ensembles are being retrieved.
            input_id (str): The unique identifier of the input associated with the models ensemble.

        Returns:
            dictionary: A dictionary representing models ensemble with the following keys:
            - `orgID` (str): The unique identifier of the organization.
            - `projectID` (str): The unique identifier of the project.
            - `inputID` (str): The unique identifier of the input associated with the models ensemble.
            - `id` (str): The unique identifier of the models ensemble.
            - `createdAt` (str): The timestamp when the models ensemble was created, in ISO 8601 format (e.g., "2025-02-24T17:47:28.868Z").
            - `status` (str): The status of the models ensemble, which can be:
                - `"HOSTED"`: The models ensemble is hosted and ready to use.
                - Other possible statuses (`"CREATED"`, `"TRAINING"`, `"FAILED"`, `"CANCELLED"`, `"CANCELLING"`)
            - `modelIds` (list): A list of model IDs that are part of this ensemble. Each entry in the list contains:
                - `modelID` (str): The unique identifier of a model in the ensemble.
                - `channelID` (str): The unique identifier of the channel associated with the model.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/GetLatestActiveModelsEnsemble/{project_id}/{input_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        elif response.status_code == 204:
            return None
        else:
            raise Exception(f"Failed to fetch last active model: URL={url} Status={response.status_code} Body={response.text}")

    def train_new_model(self, project_id: str, input_id: str, model_type: ModelType | None):
        """
        Trains a new models ensemble.

        Args:
            project_id (str): The identifier for the project.
            input_id: The input source id.
            model_type (ModelType | None): The type of the model to train. If None, a default model type is used.

        Returns:
            dictionary: A dictionary representing models ensemble with the following keys:
            - `orgID` (str): The unique identifier of the organization.
            - `projectID` (str): The unique identifier of the project.
            - `inputID` (str): The unique identifier of the input associated with the models ensemble.
            - `id` (str): The unique identifier of the models ensemble.
            - `createdAt` (str): The timestamp when the models ensemble was created, in ISO 8601 format (e.g., "2025-02-24T17:47:28.868Z").
            - `status` (str): The status of the models ensemble, which can be:
                - (`"CREATED"`, `"TRAINING"`, `"FAILED"`, `"CANCELLED"`, `"CANCELLING"`, `"HOSTED"`)
            - `modelIds` (list): A list of model IDs that are part of this ensemble. Each entry in the list contains:
                - `modelID` (str): The unique identifier of a model in the ensemble.
                - `channelID` (str): The unique identifier of the channel associated with the model.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        model_type_param = model_type if model_type is not None else ""
        url = f'{self.api_host}/vision/AnomalyDetectionMC/TrainModelsEnsemble/{project_id}/{input_id}/{model_type_param}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to train new model: URL={url} Status={response.status_code} Body={response.text}")

    def set_image_anomality(self, project_id: str, image_id: str, is_anomaly: bool, anomaly_coordinates: Optional[AnomalyCoordinates]):
        """
        Sets the anomality status of an input image within a project.

        Args:
            project_id (str): The identifier for the project.
            image_id (str): The identifier of the image whose anomaly status needs to be changed.
            is_anomaly (bool): The new anomaly status of the image (True for anomalous, False for normal).
            anomaly_coordinates (optional): anomaly polygons, should be set for anomalous images only

        Returns:
            None

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        anomaly_coordinates_encoded = self.__encode_anomaly_coordinates(anomaly_coordinates)

        url = f'{self.api_host}/vision/AnomalyDetectionMC/MoveInputImage/{project_id}/{image_id}/{is_anomaly}/{anomaly_coordinates_encoded}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            print(f"Image {image_id} anomality is switched to {is_anomaly}")
        else:
            raise Exception(f"Failed to switch image anomality: URL={url} Status={response.status_code} Body={response.text}")

    def delete_input_image(self, project_id: str, image_id: str) -> None:
        """
        Deletes an input image from the training dataset.

        Args:
            project_id (str): The identifier for the project.
            image_id (str): The identifier of the image to be deleted.

        Returns:
            None

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/RemoveInputImage/{project_id}/{image_id}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code != 200:
            raise Exception(f"Failed to delete input image: URL={url} Status={response.status_code} Body={response.text}")

    def add_input_image_from_result(self, project_id: str, result_id: str, is_anomaly: bool, anomaly_coordinates: Optional[AnomalyCoordinates]):
        """
        Adds an image from anomaly detection results to the dataset.

        Args:
            project_id (str): The identifier for the project.
            result_id (str): The identifier of the result image to be added to the dataset.
            is_anomaly (bool): Indicates whether the image should be classified as anomalous (True) or normal (False).
            anomaly_coordinates (Optional[AnomalyCoordinates]): The coordinates of the detected anomaly (applicable for anomalous images).

        Returns:
            dict: A JSON response containing details about the newly added input image with the following keys:
            - `id`: Unique identifier for the image.
            - `createdAt`: Timestamp of image creation.
            - `inputId`: ID associated with the input.
            - `isAnomalous`: Boolean indicating if the image is anomalous.
            - `imgExt`: The file extension of the image (e.g., jpeg).
            - `thumbUrl`: URL of the image thumbnail.
            - `isNew`: Boolean indicating if the image is new.
            - `anomalyCoordinates`: List of coordinates highlighting detected anomalies, if any.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.

        """
        headers = self.__get_api_headers()
        anomaly_coordinates_encoded = self.__encode_anomaly_coordinates(anomaly_coordinates)
        url = f'{self.api_host}/vision/AnomalyDetectionMC/AddInputImageFromResult/{project_id}/{result_id}/{is_anomaly}/{anomaly_coordinates_encoded}'
        response = requests.post(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to add image to dataset: URL={url} Status={response.status_code} Body={response.text}")


    def submit_pic(self, project_id: str, input_id: str, is_anomaly: bool, img_name: str, img_ext: str, img_blob: bytes, anomaly_coordinates: Optional[AnomalyCoordinates]):
        """
        Submit an input image into a dataset.

        Args:
            project_id (str): The ID of the project for which the inference is performed.
            input_id (str): The input source id.
            is_anomaly (bool): Whether the image is anomalous.
            img_name (str): The name of the image.
            img_ext (str): The extension of the image file (e.g., 'jpg', 'png').
            img_blob (bytes): The image binary data to be uploaded.
            anomaly_coordinates (optional): anomaly polygons

        Returns:
            dict: A dictionary containing the result in JSON format if successful with the following keys:
            - `id`: Unique identifier for the image.
            - `createdAt`: Timestamp of image creation.
            - `inputId`: ID associated with the input.
            - `isAnomalous`: Boolean indicating if the image is anomalous.
            - `imgName`: The name of the image.
            - `imgExt`: The file extension of the image (e.g., jpeg).
            - `thumbUrl`: URL of the image thumbnail.
            - `isNew`: Boolean indicating if the image is new.
            - `anomalyCoordinates`: List of coordinates highlighting detected anomalies, if any.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers('application/octet-stream')

        anomaly_coordinates_encoded = self.__encode_anomaly_coordinates(anomaly_coordinates)
        encoded_img_name = urllib.parse.quote(img_name)
        encoded_img_ext = urllib.parse.quote(img_ext)

        url = f'{self.api_host}/vision/AnomalyDetectionMC/AddInputImage/{project_id}/{input_id}/{is_anomaly}/{encoded_img_name}/{encoded_img_ext}/{anomaly_coordinates_encoded}'
        response = requests.post(url, headers=headers, data=img_blob, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to submit input picture: URL={url} Status={response.status_code} Body={response.text}")


    def infer(self, project_id: str, input_id: str, model_id: str, img_name: str, img_ext: str, img_blob: bytes, use_openvino=False):
        """
        Submit an image for anomaly detection.

        Args:
            project_id (str): The ID of the project for which the inference is performed.
            input_id (str): The input source id.
            model_id (str): The ID of the model used for anomaly detection.
            img_name (str): The image name.
            img_ext (str): The extension of the image file (e.g., 'jpg', 'png').
            img_blob (bytes): The image binary data to be sent for inference.
            use_openvino (bool, optional): Whether to use OpenVino for inference. Defaults to False.

        Returns:
            dict: A dictionary containing the inference results in JSON format if successful with the following keys:
            - "id" (str): A unique identifier for the anomaly detection result.
            - "createdAt" (str): The timestamp of when the anomaly detection was performed.
            - "inputID" (str): The input source ID.
            - "isAnomalous" (bool): A boolean indicating whether the image is classified as anomalous.
            - "thumbUrl" (str): A URL linking to the thumbnail of the input image.
            - "imgName" (str): The image name.
            - "imgExt" (str): The file extension of the image (e.g., 'jpg', 'png').
            - "copiedToDataset" (bool): A boolean indicating whether the result has been copied to a dataset.
            - "channelResults" (list): A list of results for each individual channel (if applicable) within the image. Each channel result contains:
                - "isAnomalous" (bool): A boolean indicating whether the specific channel is anomalous.
                - "channelID" (str): The unique ID of the channel being analyzed.
                - "channelName" (str): The name of the channel being analyzed.
                - "imgID" (str): The ID of the image for the given channel.
                - "segmentArea" (list of dicts): A list of coordinates defining the anomalous area within the image.
                - "heatMap" (list): The heatmap data for the channel, expressed as array of arrays of bytes

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers('application/octet-stream')
        encoded_img_name = urllib.parse.quote(img_name)
        encoded_img_ext = urllib.parse.quote(img_ext)
        url = f'{self.api_host}/vision/AnomalyDetectionMC/{project_id}/{input_id}/{model_id}/{encoded_img_name}/{encoded_img_ext}'

        params = {}
        if use_openvino:
            params['useOpenVino'] = 'true'

        response = requests.post(url, headers=headers, data=img_blob, params=params, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to perform inference: URL={url} Status={response.status_code} Body={response.text}")

    def get_results(self, project_id: str, input_id: str, page=1, page_size=10):
        """
        Retrieves anomaly detection results for a given input within a project.

        Args:
            project_id (str): The identifier for the project.
            input_id (str): The identifier for the specific input source to retrieve results for.
            page (int, optional): The page number for paginated results (default: 1).
            page_size (int, optional): The number of results per page (default: 10).

        Returns:
            dict: A JSON response containing anomaly detection results with the following keys:
                - results (list[dict]): A list of result entries, each containing:
                    - id (str): The unique identifier of the result.
                    - createdAt (str): The timestamp when the result was created.
                    - inputID (str): The identifier of the input source associated with the result.
                    - isAnomalous (bool): Indicates whether the input was classified as anomalous.
                    - thumbUrl (str): URL of the thumbnail image for the result.
                    - imgExt (str): File extension of the image.
                    - copiedToDataset (bool): Indicates whether the result was copied to a dataset.
                    - channelResults (list): A list of channel-specific results (currently empty).
                - totalResults (int): The total number of results available.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/ListResults/{project_id}/{input_id}?page={page}&pageSize={page_size}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch results: URL={url} Status={response.status_code} Body={response.text}")

    def fetch_result_image(self, project_id: str, image_id: str) -> bytes:
        """
        Fetches the result image for a given result image identifier within a project.

        Args:
            project_id (str): The identifier for the project.
            image_id (str): The identifier for the specific result image to retrieve.

        Returns:
            bytes: The binary content of the fetched image.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers('blob')
        url = f'{self.api_host}/vision/AnomalyDetectionMC/GetResultsImage/{project_id}/{image_id}'
        response = requests.get(url, headers=headers, verify=self.verify)

        if response.status_code == 200:
            return response.content
        else:
            raise Exception(f"Failed to fetch result image: URL={url} Status={response.status_code} Body={response.text}")


    def fetch_result_image_with_heatmap(
        self,
        project_id: str,
        image_id: str,
        use_background: bool = True,
        normalize: bool = True,
        threshold_ratio: float = 0.2,
        amplification_threshold_ratio: float = 1.0,
        amplifier: float = 1,
        opacity: int = 230
    ) -> bytes:
        """
        Fetches the result image with heatmap for a given result image identifier within a project.

        Args:
            project_id (str): The identifier for the project.
            image_id (str): The identifier for the specific result image to retrieve.
            use_background (bool, optional):
                Determines whether the original image should be used as a background for the heatmap.
                If true, the heatmap is overlaid on the original image;
                if false, only the heatmap is returned. (default: True).
            normalize (bool, optional): Specifies whether to normalize the heatmap values based on its current maximum.
                If true, the heatmap values are scaled between 0 and 1,
                where the highest value in the heatmap becomes 1 and the lowest value remains proportionally adjusted.
                This ensures consistency across different heatmaps, making them comparable regardless of their original intensity range. (default: True),
            threshold_ratio (float [0.0 - 1.0], optional): Defines the relative threshold below which heatmap values are not visible.
                For example, if set to 0.2, all heatmap values below 20% of the maximum will be ignored. (default: 0.2).
            amplification_threshold_ratio (float [0.0 - 1.0], optional): Specifies the threshold above which heatmap values will be amplified.
                If a heatmap value exceeds this fraction of the maximum, it will be multiplied by the amplifier. (default 1.0),
            amplifier (float, optional): The amplification factor applied to heatmap values exceeding amplifyThresholdRatio.
                Higher values increase the contrast in the heatmap by making high-intensity regions stand out more. (default: 1),
            opacity (int [0 - 255], optional): Controls the transparency of the heatmap overlay.
                A value of 0 makes the heatmap fully transparent, while 255 makes it fully opaque. (default: 230).

        Returns:
            bytes: The binary content of the fetched image (jpg).

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers('blob')
        url = f"{self.api_host}/vision/AnomalyDetectionMC/GetCombinedHeatMap/{project_id}/{image_id}"

        query_params = {
            "useBackground": use_background,
            "normalize": normalize,
            "thresholdRatio": threshold_ratio,
            "amplifyThresholdRatio": amplification_threshold_ratio,
            "amplifier": amplifier,
            "opacity": opacity
        }

        response = requests.get(url, headers=headers, params=query_params, verify=self.verify)

        if response.status_code == 200:
            return response.content
        else:
            raise Exception(f"Failed to fetch result image with heatmap: URL={url} Status={response.status_code} Body={response.text}")


    def del_result(self, project_id: str, result_id: str):
        """
        Deletes a result from the specified project by ID.

        Args:
            project_id (str): The unique identifier of the project.
            result_id (str): The unique identifier of the result.

        Raises:
            Exception: If the API request fails or returns an unexpected status code.
        """
        headers = self.__get_api_headers()
        url = f'{self.api_host}/vision/AnomalyDetectionMC/DeleteResult/{project_id}/{result_id}'
        response = requests.delete(url, headers=headers, verify=self.verify)

        if response.status_code != 200:
            raise Exception(f"Failed to delete result: URL={url} Status={response.status_code} Body={response.text}")

    def read_file_as_blob(self, file_path: str) -> bytes:
        """
        Reads a file and returns its content as a blob.
        """
        with open(file_path, "rb") as file:
            return file.read()

    def __get_token(self) -> str:
        """
        Exchange the API key for a JWT.
        Result is cached until it expires (with a 10-second safety margin).
        """
        import time

        cached = self._token_cache
        if cached and time.time() < cached.get("expires_at", 0):
            return str(cached["token"])

        url = f"{self.api_host}/orgapi/auth/token/apikey"
        payload = {"secret": self._api_key}
        response = requests.post(url, json=payload, verify=self.verify)

        if response.status_code != 200:
            raise Exception(f"API key authentication failed: URL={url} Status={response.status_code} Body={response.text}")

        data = response.json()
        token = data["token"]
        expires_in = data.get("expires_in", 120)

        self._token_cache = {
            "token": token,
            "expires_at": time.time() + expires_in - 10  # 10-second safety margin
        }

        return token

    def __get_api_headers(self, content_type: str = ""):
        """
        Build authorization headers for API calls.
        """
        token = self.__get_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": content_type or "application/json",
        }

    def __encode_anomaly_coordinates(self, anomaly_coordinates: Optional[AnomalyCoordinates]) -> str:
        """
        Encodes anomaly coordinates as a URL-encoded JSON string.

        The input should be a list of lists containing (x, y) coordinate tuples.

        Args:
            anomaly_coordinates (Optional[AnomalyCoordinates]):
                A 2D array representing polygons of anomaly coordinates.
                Each inner list contains dictionaries with 'x' and 'y' float values.

        Returns:
            str: A URL-encoded JSON string representing the anomaly coordinates.

        Example:
            >>> anomaly_coordinates = [
            ...     [{"x": 0.51376953125, "y": 0.589375},
            ...      {"x": 0.71626953125, "y": 0.589375},
            ...      {"x": 0.71626953125, "y": 0.969375},
            ...      {"x": 0.51376953125, "y": 0.969375}]  # First polygon
            ... ]
            >>> encoded = __encode_anomaly_coordinates(anomaly_coordinates)
        """
        if anomaly_coordinates is not None:
            anomaly_coordinates_json = json.dumps(anomaly_coordinates)
            anomaly_coordinates_base64 = base64.b64encode(anomaly_coordinates_json.encode('utf-8')).decode('utf-8')
            anomaly_coordinates_encoded = urllib.parse.quote(anomaly_coordinates_base64)
        else:
            anomaly_coordinates_encoded = ""  # Empty if not provided

        return anomaly_coordinates_encoded
