"""ClawBench utility helpers."""
