"""Tests for model assessment and task decomposition."""

from openlaoke.core.model_assessment.assessor import ModelAssessor, TaskDecomposer
from openlaoke.core.model_assessment.types import (
    KNOWN_MODEL_TIERS,
    TIER_GRANULARITIES,
    CapabilityCategory,
    CapabilityScore,
    ModelBenchmark,
    ModelTier,
    TaskGranularity,
)
from openlaoke.types.providers import MultiProviderConfig


class TestModelTier:
    def test_tier_values(self):
        assert ModelTier.TIER_1_ADVANCED.value == "tier_1_advanced"
        assert ModelTier.TIER_5_LIMITED.value == "tier_5_limited"

    def test_tier_ordering(self):
        tiers = [
            ModelTier.TIER_1_ADVANCED,
            ModelTier.TIER_2_CAPABLE,
            ModelTier.TIER_3_MODERATE,
            ModelTier.TIER_4_BASIC,
            ModelTier.TIER_5_LIMITED,
        ]
        for i, tier in enumerate(tiers):
            if i > 0:
                assert tier.value > tiers[i - 1].value

    def test_known_model_tiers(self):
        assert "claude-opus-4" in KNOWN_MODEL_TIERS
        assert KNOWN_MODEL_TIERS["claude-opus-4"] == ModelTier.TIER_1_ADVANCED

        assert "gemma3:1b" in KNOWN_MODEL_TIERS
        assert KNOWN_MODEL_TIERS["gemma3:1b"] == ModelTier.TIER_5_LIMITED

        assert "gpt-4o" in KNOWN_MODEL_TIERS
        assert KNOWN_MODEL_TIERS["gpt-4o"] == ModelTier.TIER_1_ADVANCED


class TestTaskGranularity:
    def test_granularity_values(self):
        gran = TaskGranularity(
            max_subtasks=3,
            subtask_complexity_limit="atomic",
            verification_frequency="every_step",
            retry_limit=10,
            timeout_multiplier=2.0,
            tool_call_limit=5,
            requires_explicit_steps=True,
            min_confidence_threshold=0.9,
        )
        assert gran.max_subtasks == 3
        assert gran.requires_explicit_steps
        assert gran.verification_frequency == "every_step"
        assert gran.subtask_complexity_limit == "atomic"
        assert gran.tool_call_limit == 5

    def test_tier_granularities_mapping(self):
        assert ModelTier.TIER_1_ADVANCED in TIER_GRANULARITIES
        assert ModelTier.TIER_5_LIMITED in TIER_GRANULARITIES

        tier1_gran = TIER_GRANULARITIES[ModelTier.TIER_1_ADVANCED]
        tier5_gran = TIER_GRANULARITIES[ModelTier.TIER_5_LIMITED]

        assert tier1_gran.max_subtasks > tier5_gran.max_subtasks
        assert not tier1_gran.requires_explicit_steps
        assert tier5_gran.requires_explicit_steps

        assert tier1_gran.verification_frequency == "minimal"
        assert tier5_gran.verification_frequency == "every_step"

    def test_advanced_model_can_handle_complex_tasks(self):
        gran = TIER_GRANULARITIES[ModelTier.TIER_1_ADVANCED]
        assert gran.max_subtasks == 20
        assert not gran.requires_explicit_steps
        assert gran.subtask_complexity_limit == "high"
        assert gran.tool_call_limit == 50

    def test_limited_model_needs_explicit_steps(self):
        gran = TIER_GRANULARITIES[ModelTier.TIER_5_LIMITED]
        assert gran.max_subtasks == 4
        assert gran.requires_explicit_steps
        assert gran.verification_frequency == "every_step"
        assert gran.retry_limit == 8
        assert gran.subtask_complexity_limit == "atomic"
        assert gran.tool_call_limit == 10


class TestCapabilityScore:
    def test_capability_score_creation(self):
        score = CapabilityScore(
            category=CapabilityCategory.BASIC_CHAT,
            score=8.5,
            tests_passed=8,
            tests_total=10,
        )
        assert score.category == CapabilityCategory.BASIC_CHAT
        assert score.score == 8.5
        assert score.tests_passed == 8
        assert score.tests_total == 10

    def test_capability_categories(self):
        assert CapabilityCategory.BASIC_CHAT.value == "basic_chat"
        assert CapabilityCategory.TOOL_CALLING.value == "tool_calling"
        assert CapabilityCategory.CODE_GENERATION.value == "code_generation"
        assert CapabilityCategory.MULTI_TURN.value == "multi_turn"


class TestModelBenchmark:
    def test_benchmark_creation(self):
        caps = {
            "basic_chat": CapabilityScore(CapabilityCategory.BASIC_CHAT, 9.0, 9, 10),
            "tool_calling": CapabilityScore(CapabilityCategory.TOOL_CALLING, 8.5, 8, 10),
        }
        bench = ModelBenchmark(
            provider="openai",
            model="gpt-4o",
            overall_score=8.75,
            tier=ModelTier.TIER_1_ADVANCED,
            capabilities=caps,
            tested_at=1000.0,
            test_duration=5.0,
            recommendations=["Can handle complex tasks directly"],
        )
        assert bench.provider == "openai"
        assert bench.model == "gpt-4o"
        assert bench.overall_score == 8.75
        assert bench.tier == ModelTier.TIER_1_ADVANCED

    def test_benchmark_serialization(self):
        caps = {
            "basic_chat": CapabilityScore(CapabilityCategory.BASIC_CHAT, 9.0, 9, 10),
        }
        bench = ModelBenchmark(
            provider="openai",
            model="gpt-4o",
            overall_score=9.0,
            tier=ModelTier.TIER_1_ADVANCED,
            capabilities=caps,
            tested_at=1000.0,
            test_duration=5.0,
            recommendations=["Test"],
        )

        d = bench.to_dict()
        assert d["provider"] == "openai"
        assert d["model"] == "gpt-4o"
        assert d["overall_score"] == 9.0
        assert d["tier"] == "tier_1_advanced"

        restored = ModelBenchmark.from_dict(d)
        assert restored.provider == bench.provider
        assert restored.model == bench.model
        assert restored.overall_score == bench.overall_score


class TestModelAssessor:
    def test_get_tier_known_models(self):
        config = MultiProviderConfig.defaults()
        assessor = ModelAssessor(config)

        tier = assessor.get_tier("claude-opus-4")
        assert tier == ModelTier.TIER_1_ADVANCED

        tier = assessor.get_tier("gemma3:1b")
        assert tier == ModelTier.TIER_5_LIMITED

        tier = assessor.get_tier("gpt-4o")
        assert tier == ModelTier.TIER_1_ADVANCED

    def test_get_tier_unknown_model(self):
        config = MultiProviderConfig.defaults()
        assessor = ModelAssessor(config)

        tier = assessor.get_tier("unknown-model-v1")
        assert tier == ModelTier.TIER_3_MODERATE

    def test_get_granularity(self):
        config = MultiProviderConfig.defaults()
        assessor = ModelAssessor(config)

        gran = assessor.get_granularity("claude-opus-4")
        assert gran.max_subtasks == 20
        assert not gran.requires_explicit_steps
        assert gran.subtask_complexity_limit == "high"

        gran = assessor.get_granularity("gemma3:1b")
        assert gran.max_subtasks == 4
        assert gran.requires_explicit_steps
        assert gran.verification_frequency == "every_step"
        assert gran.subtask_complexity_limit == "atomic"


class TestTaskDecomposer:
    def test_decompose_simple_task(self):
        gran = TIER_GRANULARITIES[ModelTier.TIER_1_ADVANCED]
        decomposer = TaskDecomposer(gran)

        steps = decomposer.decompose("Write a simple hello world function")
        assert len(steps) == 1
        assert steps[0] == "Write a simple hello world function"

    def test_decompose_complex_task_advanced_model(self):
        gran = TIER_GRANULARITIES[ModelTier.TIER_1_ADVANCED]
        decomposer = TaskDecomposer(gran)

        complex_task = "Write an article about AI and create a diagram and implement code"
        steps = decomposer.decompose(complex_task)
        assert len(steps) == 1
        assert steps[0] == complex_task

    def test_decompose_complex_task_limited_model(self):
        gran = TIER_GRANULARITIES[ModelTier.TIER_5_LIMITED]
        decomposer = TaskDecomposer(gran)

        complex_task = "Write an article about AI and create a diagram and implement code"
        steps = decomposer.decompose(complex_task)
        assert len(steps) > 1
        assert len(steps) <= gran.max_subtasks
        assert len(steps) == 3

    def test_decompose_with_then_keyword(self):
        gran = TIER_GRANULARITIES[ModelTier.TIER_4_BASIC]
        decomposer = TaskDecomposer(gran)

        task = "First read the file then process it then write output"
        steps = decomposer.decompose(task)
        assert len(steps) > 1
        assert "First read the file" in steps
        assert "process it" in steps
        assert "write output" in steps

    def test_decompose_respects_max_subtasks(self):
        gran = TaskGranularity(
            max_subtasks=2,
            subtask_complexity_limit="atomic",
            verification_frequency="every_step",
            retry_limit=5,
            timeout_multiplier=1.5,
            tool_call_limit=5,
            requires_explicit_steps=True,
            min_confidence_threshold=0.8,
        )
        decomposer = TaskDecomposer(gran)

        task = "Step 1 and Step 2 and Step 3 and Step 4"
        steps = decomposer.decompose(task)
        assert len(steps) <= 2

    def test_should_verify_every_step(self):
        gran = TaskGranularity(
            max_subtasks=3,
            subtask_complexity_limit="atomic",
            verification_frequency="every_step",
            retry_limit=5,
            timeout_multiplier=1.5,
            tool_call_limit=5,
            requires_explicit_steps=True,
            min_confidence_threshold=0.8,
        )
        decomposer = TaskDecomposer(gran)

        assert decomposer.should_verify(0)
        assert decomposer.should_verify(1)
        assert decomposer.should_verify(2)

    def test_should_verify_frequent(self):
        gran = TaskGranularity(
            max_subtasks=10,
            subtask_complexity_limit="low",
            verification_frequency="frequent",
            retry_limit=5,
            timeout_multiplier=1.5,
            tool_call_limit=15,
            requires_explicit_steps=True,
            min_confidence_threshold=0.8,
        )
        decomposer = TaskDecomposer(gran)

        assert decomposer.should_verify(0)
        assert not decomposer.should_verify(1)
        assert decomposer.should_verify(2)
        assert not decomposer.should_verify(3)

    def test_should_verify_moderate(self):
        gran = TaskGranularity(
            max_subtasks=10,
            subtask_complexity_limit="medium",
            verification_frequency="moderate",
            retry_limit=5,
            timeout_multiplier=1.0,
            tool_call_limit=20,
            requires_explicit_steps=False,
            min_confidence_threshold=0.7,
        )
        decomposer = TaskDecomposer(gran)

        assert decomposer.should_verify(0)
        assert not decomposer.should_verify(1)
        assert not decomposer.should_verify(2)
        assert decomposer.should_verify(3)

    def test_should_verify_minimal(self):
        gran = TaskGranularity(
            max_subtasks=20,
            subtask_complexity_limit="high",
            verification_frequency="minimal",
            retry_limit=3,
            timeout_multiplier=1.0,
            tool_call_limit=50,
            requires_explicit_steps=False,
            min_confidence_threshold=0.6,
        )
        decomposer = TaskDecomposer(gran)

        assert not decomposer.should_verify(0)
        assert not decomposer.should_verify(1)
        assert not decomposer.should_verify(10)

    def test_get_timeout(self):
        gran = TaskGranularity(
            max_subtasks=3,
            subtask_complexity_limit="atomic",
            verification_frequency="every_step",
            retry_limit=5,
            timeout_multiplier=2.0,
            tool_call_limit=5,
            requires_explicit_steps=True,
            min_confidence_threshold=0.9,
        )
        decomposer = TaskDecomposer(gran)

        timeout = decomposer.get_timeout(60.0)
        assert timeout == 120.0


class TestComplexTaskDecomposition:
    def test_full_pipeline_complex_task(self):
        config = MultiProviderConfig.defaults()
        assessor = ModelAssessor(config)

        model = "gemma3:1b"
        gran = assessor.get_granularity(model)
        decomposer = TaskDecomposer(gran)

        complex_task = "Write a comprehensive research paper with citations and create visualizations and implement reference code"
        steps = decomposer.decompose(complex_task)

        assert len(steps) > 1
        assert len(steps) <= gran.max_subtasks

        assert gran.requires_explicit_steps
        assert gran.verification_frequency == "every_step"

        for i in range(len(steps)):
            assert decomposer.should_verify(i)

        timeout = decomposer.get_timeout(120.0)
        assert timeout == gran.timeout_multiplier * 120.0

    def test_different_models_different_strategies(self):
        config = MultiProviderConfig.defaults()
        assessor = ModelAssessor(config)

        task = "Complex multi-step task with analysis and implementation and testing"

        tier1_gran = assessor.get_granularity("claude-opus-4")
        tier1_decomposer = TaskDecomposer(tier1_gran)
        tier1_steps = tier1_decomposer.decompose(task)
        assert len(tier1_steps) == 1

        tier5_gran = assessor.get_granularity("gemma3:1b")
        tier5_decomposer = TaskDecomposer(tier5_gran)
        tier5_steps = tier5_decomposer.decompose(task)
        assert len(tier5_steps) > 1
        assert len(tier5_steps) <= 4

    def test_edge_cases(self):
        gran = TIER_GRANULARITIES[ModelTier.TIER_5_LIMITED]
        decomposer = TaskDecomposer(gran)

        steps = decomposer.decompose("")
        assert len(steps) == 0

        steps = decomposer.decompose("Single simple task")
        assert len(steps) <= 1

        steps = decomposer.decompose("Task with many words but no connectors")
        assert len(steps) == 1
