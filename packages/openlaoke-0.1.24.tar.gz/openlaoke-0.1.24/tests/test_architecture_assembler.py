"""Tests for architecture system - assembler."""

import tempfile
from pathlib import Path

import pytest

from openlaoke.core.architecture.assembler import (
    AssemblyResult,
    ValidationResult,
    CodeAssembler,
    IntegrationValidator,
)
from openlaoke.core.architecture.decomposer import (
    AtomicTask,
    TaskGraph,
    FineGrainedDecomposer,
)
from openlaoke.core.architecture.interfaces import (
    CodeTemplate,
    ComponentSpec,
    ComponentType,
)
from openlaoke.core.model_assessment.types import ModelTier


class TestValidationResult:
    def test_validation_result_creation(self):
        result = ValidationResult(
            is_valid=True,
            errors=[],
            warnings=["Minor issue"],
            suggestions=["Consider refactoring"],
        )
        assert result.is_valid
        assert len(result.warnings) == 1
        assert len(result.suggestions) == 1

    def test_validation_result_with_errors(self):
        result = ValidationResult(
            is_valid=False,
            errors=["Error 1", "Error 2"],
        )
        assert not result.is_valid
        assert len(result.errors) == 2


class TestAssemblyResult:
    def test_assembly_result_creation(self):
        result = AssemblyResult(
            success=True,
            code="def test(): pass",
            errors=[],
            warnings=[],
        )
        assert result.success
        assert "def test" in result.code

    def test_assembly_result_with_tests(self):
        result = AssemblyResult(
            success=True,
            code="...",
            test_results={"test1": True, "test2": False},
        )
        assert result.test_results["test1"]
        assert not result.test_results["test2"]


class TestCodeAssembler:
    def test_assembler_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))
            assert assembler.project_root == Path(tmpdir)

    def test_assemble_simple_task(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            spec = ComponentSpec(
                name="test_func",
                component_type=ComponentType.FUNCTION,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def test_func(): pass",
            )
            task = AtomicTask(
                task_id="test_task",
                description="Test task",
                component_spec=spec,
                template=template,
            )
            graph = TaskGraph(root_task_id="root")
            graph.add_task(task)

            result = assembler.assemble_atomic_task(task, graph)
            assert result.success or len(result.errors) > 0

    def test_assemble_task_with_dependencies(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            spec1 = ComponentSpec(
                name="func1",
                component_type=ComponentType.FUNCTION,
            )
            spec2 = ComponentSpec(
                name="func2",
                component_type=ComponentType.FUNCTION,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def func(): pass",
            )

            task1 = AtomicTask(
                task_id="task1",
                description="Task 1",
                component_spec=spec1,
                template=template,
            )
            task2 = AtomicTask(
                task_id="task2",
                description="Task 2",
                component_spec=spec2,
                template=template,
                dependencies=["task1"],
            )

            graph = TaskGraph(root_task_id="root")
            graph.add_task(task1)
            graph.add_task(task2)
            graph.mark_completed("task1")

            result = assembler.assemble_atomic_task(task2, graph)
            assert result is not None

    def test_validate_code_syntax(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            spec = ComponentSpec(
                name="test",
                component_type=ComponentType.FUNCTION,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def test(): pass",
                validation_rules=["Must have type hints"],
            )
            task = AtomicTask(
                task_id="test",
                description="Test",
                component_spec=spec,
                template=template,
            )

            validation = assembler._validate_code("def test(): pass", task)
            assert validation is not None


class TestIntegrationValidator:
    def test_validator_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            validator = IntegrationValidator(Path(tmpdir))
            assert validator.project_root == Path(tmpdir)

    def test_validate_empty_code(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            validator = IntegrationValidator(Path(tmpdir))

            result = AssemblyResult(success=False, code="")
            validation = validator.validate_assembly(result)
            assert not validation.is_valid
            assert "Empty code" in " ".join(validation.errors)

    def test_validate_valid_code(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            validator = IntegrationValidator(Path(tmpdir))

            code = '''"""Module docstring."""
def test_func():
    """Test function."""
    return 42
'''
            result = AssemblyResult(success=True, code=code)
            validation = validator.validate_assembly(result)
            assert validation.is_valid or len(validation.errors) == 0


class TestAssemblyWorkflow:
    def test_full_assembly_workflow(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            spec = ComponentSpec(
                name="simple_func",
                component_type=ComponentType.FUNCTION,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def simple_func(): return 42",
            )
            task = AtomicTask(
                task_id="simple_func_main",
                description="Implement simple_func",
                component_spec=spec,
                template=template,
                test_required=False,
            )

            graph = TaskGraph(root_task_id="root")
            graph.add_task(task)

            result = assembler.assemble_task_graph(graph)
            assert result is not None
            assert isinstance(result.code, str)

    def test_assembly_with_context(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            spec = ComponentSpec(
                name="add",
                component_type=ComponentType.FUNCTION,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def {function_name}({parameters}) -> {return_type}:\n    return {return_value}",
            )
            task = AtomicTask(
                task_id="add_main",
                description="Add function",
                component_spec=spec,
                template=template,
                context={
                    "function_name": "add",
                    "parameters": "a: int, b: int",
                    "return_type": "int",
                    "return_value": "a + b",
                },
            )

            graph = TaskGraph(root_task_id="root")
            graph.add_task(task)

            result = assembler.assemble_task_graph(graph)
            assert result is not None


class TestCodeOrganization:
    def test_organize_imports_and_code(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            imports = {"import os", "import sys"}
            code_parts = ["def func1(): pass", "def func2(): pass"]

            organized = assembler._organize_code(imports, code_parts)
            assert "import os" in organized
            assert "import sys" in organized
            assert "def func1" in organized
            assert "def func2" in organized

    def test_auto_fix_missing_docstring(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            code = "def test(): pass"
            validation = ValidationResult(
                is_valid=False,
                errors=["Missing docstring"],
            )

            can_fix = assembler._can_auto_fix(validation)
            assert can_fix


class TestTaskGraphAssembly:
    def test_sequential_assembly(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            specs = [
                ComponentSpec(name=f"func{i}", component_type=ComponentType.FUNCTION)
                for i in range(3)
            ]
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def func(): pass",
            )

            tasks = [
                AtomicTask(
                    task_id=f"task{i}",
                    description=f"Task {i}",
                    component_spec=spec,
                    template=template,
                    test_required=False,
                )
                for i, spec in enumerate(specs)
            ]

            graph = TaskGraph(root_task_id="root")
            for task in tasks:
                graph.add_task(task)

            result = assembler.assemble_task_graph(graph)
            assert result is not None

    def test_dependency_based_assembly(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            assembler = CodeAssembler(Path(tmpdir))

            template = CodeTemplate(
                name="test",
                description="Test",
                template="def func(): pass",
            )

            task1 = AtomicTask(
                task_id="imports",
                description="Imports",
                component_spec=ComponentSpec(name="imports", component_type=ComponentType.FUNCTION),
                template=template,
                test_required=False,
            )
            task2 = AtomicTask(
                task_id="main",
                description="Main",
                component_spec=ComponentSpec(name="main", component_type=ComponentType.FUNCTION),
                template=template,
                dependencies=["imports"],
                test_required=False,
            )

            graph = TaskGraph(root_task_id="root")
            graph.add_task(task1)
            graph.add_task(task2)

            result = assembler.assemble_task_graph(graph)
            assert result is not None
