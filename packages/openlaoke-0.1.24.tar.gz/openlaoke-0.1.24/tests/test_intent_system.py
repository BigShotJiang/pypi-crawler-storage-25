"""Tests for intent parsing and specification conversion."""

from __future__ import annotations

import pytest

from openlaoke.core.intent_parser import (
    IntentParser,
    IntentType,
    ProgrammingIntent,
    ProgrammingLanguage,
    TaskComplexity,
)
from openlaoke.core.intent_to_spec import (
    IntentToSpecConverter,
    SpecGenerationResult,
    create_converter_for_model,
)
from openlaoke.core.architecture.interfaces import ComponentType
from openlaoke.core.model_assessment.types import ModelTier


class TestIntentParser:
    def test_parser_initialization(self) -> None:
        parser = IntentParser()
        assert parser is not None
        assert hasattr(parser, "parse")
        assert hasattr(parser, "INTENT_PATTERNS")
        assert hasattr(parser, "LANGUAGE_PATTERNS")

    def test_parse_write_program_intent(self) -> None:
        parser = IntentParser()
        request = "write a new program for CPU benchmark"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.WRITE_PROGRAM
        assert intent.language == ProgrammingLanguage.PYTHON
        assert intent.task_name == "benchmark"
        assert "benchmark" in intent.description.lower()
        assert intent.confidence > 0.0

    def test_parse_write_function_intent(self) -> None:
        parser = IntentParser()
        request = "create a function to calculate average"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.WRITE_FUNCTION
        assert intent.language == ProgrammingLanguage.PYTHON
        assert intent.task_name == "calculator"
        assert intent.confidence > 0.0

    def test_parse_write_class_intent(self) -> None:
        parser = IntentParser()
        request = "implement a class for user management"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.WRITE_CLASS
        assert intent.language == ProgrammingLanguage.PYTHON
        assert "manager" in intent.task_name.lower() or "management" in intent.description.lower()
        assert intent.confidence > 0.0

    def test_parse_debug_intent(self) -> None:
        parser = IntentParser()
        request = "debug the error in my code"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.DEBUG_CODE
        assert intent.confidence > 0.0

    def test_parse_refactor_intent(self) -> None:
        parser = IntentParser()
        request = "refactor the code to make it cleaner"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.REFACTOR_CODE
        assert intent.confidence > 0.0

    def test_parse_test_intent(self) -> None:
        parser = IntentParser()
        request = "write tests for the calculator"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.TEST_CODE
        assert intent.confidence > 0.0

    def test_parse_analyze_intent(self) -> None:
        parser = IntentParser()
        request = "analyze the code for performance issues"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.ANALYZE_CODE
        assert intent.confidence > 0.0

    def test_parse_document_intent(self) -> None:
        parser = IntentParser()
        request = "document the function with comments"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.DOCUMENT_CODE
        assert intent.confidence > 0.0

    def test_parse_unknown_intent(self) -> None:
        parser = IntentParser()
        request = "hello world"
        intent = parser.parse(request)

        assert intent.intent_type == IntentType.UNKNOWN
        assert intent.confidence < 0.5

    def test_detect_python_language(self) -> None:
        parser = IntentParser()
        request = "write a python program for sorting"
        intent = parser.parse(request)

        assert intent.language == ProgrammingLanguage.PYTHON

    def test_detect_javascript_language(self) -> None:
        parser = IntentParser()
        request = "create a javascript app"
        intent = parser.parse(request)

        assert intent.language == ProgrammingLanguage.JAVASCRIPT

    def test_detect_rust_language(self) -> None:
        parser = IntentParser()
        request = "implement a rust program"
        intent = parser.parse(request)

        assert intent.language == ProgrammingLanguage.RUST

    def test_extract_requirements(self) -> None:
        parser = IntentParser()
        request = "write a program that should support multiple inputs and handle errors"
        intent = parser.parse(request)

        assert len(intent.requirements) > 0
        assert any(
            "support" in req.lower() or "handle" in req.lower() for req in intent.requirements
        )

    def test_extract_inputs(self) -> None:
        parser = IntentParser()
        request = "write a function that takes filename as input"
        intent = parser.parse(request)

        assert len(intent.inputs) > 0
        assert any("filename" in inp.lower() for inp in intent.inputs)

    def test_extract_outputs(self) -> None:
        parser = IntentParser()
        request = "create a program that output: calculated result"
        intent = parser.parse(request)

        assert len(intent.outputs) > 0

    def test_detect_atomic_complexity(self) -> None:
        parser = IntentParser()
        request = "write simple basic minimal program"
        intent = parser.parse(request)

        assert intent.complexity == TaskComplexity.ATOMIC

    def test_detect_simple_complexity(self) -> None:
        parser = IntentParser()
        request = "create small easy straightforward function"
        intent = parser.parse(request)

        assert intent.complexity == TaskComplexity.SIMPLE

    def test_detect_complex_complexity(self) -> None:
        parser = IntentParser()
        request = "build complex advanced large comprehensive system with multiple modules and full architecture"
        intent = parser.parse(request)

        assert intent.complexity == TaskComplexity.COMPLEX

    def test_cache_intent(self) -> None:
        parser = IntentParser()
        request = "write a program"

        intent1 = parser.parse(request)
        intent2 = parser.parse(request)

        assert intent1.raw_request == intent2.raw_request
        assert request in parser._cache

    def test_suggest_clarifications_for_unknown_intent(self) -> None:
        parser = IntentParser()
        request = "hello"
        intent = parser.parse(request)
        questions = parser.suggest_clarifications(intent)

        assert len(questions) > 0
        assert any("details" in q.lower() or "type" in q.lower() for q in questions)

    def test_to_dict(self) -> None:
        parser = IntentParser()
        request = "write a python calculator program"
        intent = parser.parse(request)
        intent_dict = intent.to_dict()

        assert "intent_type" in intent_dict
        assert "language" in intent_dict
        assert "task_name" in intent_dict
        assert intent_dict["intent_type"] == IntentType.WRITE_PROGRAM.value


class TestIntentToSpecConverter:
    def test_converter_initialization(self) -> None:
        converter = IntentToSpecConverter()
        assert converter is not None
        assert converter.model_tier == ModelTier.TIER_5_LIMITED
        assert converter.max_lines_per_spec == 15
        assert converter.max_params_per_spec == 3

    def test_converter_for_different_tiers(self) -> None:
        converter_tier5 = create_converter_for_model(ModelTier.TIER_5_LIMITED)
        assert converter_tier5.max_lines_per_spec == 15
        assert converter_tier5.max_params_per_spec == 3

        converter_tier1 = create_converter_for_model(ModelTier.TIER_1_ADVANCED)
        assert converter_tier1.max_lines_per_spec == 100
        assert converter_tier1.max_params_per_spec == 10

    def test_convert_write_program_intent(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "write a benchmark program"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert result.success
        assert len(result.specs) > 0
        assert any(spec.component_type == ComponentType.MODULE for spec in result.specs)
        assert any(spec.component_type == ComponentType.TEST for spec in result.specs)

    def test_convert_write_function_intent(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "create a function to sort list"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert result.success
        assert len(result.specs) > 0
        assert any(spec.component_type == ComponentType.FUNCTION for spec in result.specs)

    def test_convert_write_class_intent(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "implement a class for data processor"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert result.success
        assert len(result.specs) > 0
        assert any(spec.component_type == ComponentType.CLASS for spec in result.specs)

    def test_convert_unknown_intent_fails(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "hello"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert not result.success
        assert len(result.specs) == 0
        assert len(result.errors) > 0

    def test_spec_has_api_spec(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "write a calculator program"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert result.success
        for spec in result.specs:
            if spec.component_type != ComponentType.TEST:
                assert spec.api_spec is not None
                assert spec.api_spec.name
                assert spec.api_spec.description

    def test_spec_has_test_requirements(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "write a program"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert result.success
        for spec in result.specs:
            if spec.component_type != ComponentType.TEST:
                assert len(spec.test_requirements) > 0

    def test_spec_complexity_within_limits(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter(ModelTier.TIER_5_LIMITED)

        request = "write a complex comprehensive program"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert result.success
        for spec in result.specs:
            assert spec.complexity_score <= converter.max_lines_per_spec

    def test_warning_for_excessive_params(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "write a function with many inputs: param1, param2, param3, param4, param5"
        intent = parser.parse(request)
        intent.inputs = ["param1", "param2", "param3", "param4", "param5"]
        result = converter.convert(intent)

        assert len(result.warnings) > 0 or all(
            len(spec.api_spec.input_schema.get("properties", {})) <= converter.max_params_per_spec
            for spec in result.specs
            if spec.api_spec
        )

    def test_helper_specs_created_for_requirements(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "write a program that should validate input and parse format"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert result.success
        helper_specs = [
            spec
            for spec in result.specs
            if spec.name
            and (
                "validate" in spec.name.lower()
                or "parse" in spec.name.lower()
                or "helper" in spec.name.lower()
            )
        ]
        assert len(helper_specs) > 0

    def test_spec_generation_result_structure(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = "write a program"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert hasattr(result, "success")
        assert hasattr(result, "specs")
        assert hasattr(result, "errors")
        assert hasattr(result, "warnings")
        assert hasattr(result, "suggestions")


class TestIntegration:
    def test_full_pipeline_intent_to_spec(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter()

        request = (
            "write a cpu benchmark program that measures performance and calculates ops per second"
        )
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert intent.intent_type == IntentType.WRITE_PROGRAM
        assert intent.language == ProgrammingLanguage.PYTHON
        assert intent.confidence > 0.5

        assert result.success
        assert len(result.specs) >= 3

        module_specs = [s for s in result.specs if s.component_type == ComponentType.MODULE]
        assert len(module_specs) >= 1

        function_specs = [s for s in result.specs if s.component_type == ComponentType.FUNCTION]
        assert len(function_specs) >= 1

        test_specs = [s for s in result.specs if s.component_type == ComponentType.TEST]
        assert len(test_specs) >= 1

    def test_tier_5_limits_enforced(self) -> None:
        parser = IntentParser()
        converter = IntentToSpecConverter(ModelTier.TIER_5_LIMITED)

        request = "write a very complex comprehensive advanced large system with many features"
        intent = parser.parse(request)
        result = converter.convert(intent)

        assert result.success

        for spec in result.specs:
            if spec.api_spec:
                input_params = spec.api_spec.input_schema.get("properties", {})
                if len(input_params) > 3:
                    assert any("too many parameters" in w.lower() for w in result.warnings)

            if spec.complexity_score > 15:
                assert any(
                    "exceeds model limit" in w.lower() or "will be decomposed" in w.lower()
                    for w in result.warnings
                )
