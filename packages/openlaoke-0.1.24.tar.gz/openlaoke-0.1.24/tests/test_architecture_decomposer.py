"""Tests for architecture system - decomposer."""

import pytest

from openlaoke.core.architecture.decomposer import (
    AtomicTask,
    TaskGraph,
    FineGrainedDecomposer,
    create_decomposer_for_model,
)
from openlaoke.core.architecture.interfaces import (
    APISpec,
    ComponentSpec,
    ComponentType,
    TaskSize,
)
from openlaoke.core.model_assessment.types import ModelTier


class TestAtomicTask:
    def test_atomic_task_creation(self):
        spec = ComponentSpec(
            name="test_func",
            component_type=ComponentType.FUNCTION,
        )
        from openlaoke.core.architecture.interfaces import CodeTemplate

        template = CodeTemplate(
            name="test",
            description="Test",
            template="def test(): pass",
        )
        task = AtomicTask(
            task_id="test_task",
            description="Test task",
            component_spec=spec,
            template=template,
        )
        assert task.task_id == "test_task"
        assert task.test_required is True
        assert task.estimated_lines == 10

    def test_atomic_task_with_dependencies(self):
        spec = ComponentSpec(
            name="test_func",
            component_type=ComponentType.FUNCTION,
        )
        from openlaoke.core.architecture.interfaces import CodeTemplate

        template = CodeTemplate(
            name="test",
            description="Test",
            template="def test(): pass",
        )
        task = AtomicTask(
            task_id="test_task",
            description="Test task",
            component_spec=spec,
            template=template,
            dependencies=["dep1", "dep2"],
            estimated_lines=15,
        )
        assert len(task.dependencies) == 2
        assert task.estimated_lines == 15


class TestTaskGraph:
    def test_task_graph_creation(self):
        graph = TaskGraph(root_task_id="root")
        assert graph.root_task_id == "root"
        assert len(graph.tasks) == 0
        assert len(graph.completed) == 0
        assert len(graph.failed) == 0

    def test_task_graph_add_task(self):
        spec = ComponentSpec(
            name="test",
            component_type=ComponentType.FUNCTION,
        )
        from openlaoke.core.architecture.interfaces import CodeTemplate

        template = CodeTemplate(
            name="test",
            description="Test",
            template="def test(): pass",
        )
        task = AtomicTask(
            task_id="task1",
            description="Task 1",
            component_spec=spec,
            template=template,
        )
        graph = TaskGraph(root_task_id="root")
        graph.add_task(task)
        assert "task1" in graph.tasks

    def test_task_graph_get_ready_tasks(self):
        spec = ComponentSpec(
            name="test",
            component_type=ComponentType.FUNCTION,
        )
        from openlaoke.core.architecture.interfaces import CodeTemplate

        template = CodeTemplate(
            name="test",
            description="Test",
            template="def test(): pass",
        )
        task1 = AtomicTask(
            task_id="task1",
            description="Task 1",
            component_spec=spec,
            template=template,
        )
        task2 = AtomicTask(
            task_id="task2",
            description="Task 2",
            component_spec=spec,
            template=template,
            dependencies=["task1"],
        )
        graph = TaskGraph(root_task_id="root")
        graph.add_task(task1)
        graph.add_task(task2)

        ready = graph.get_ready_tasks()
        assert len(ready) == 1
        assert ready[0].task_id == "task1"

    def test_task_graph_completion(self):
        spec = ComponentSpec(
            name="test",
            component_type=ComponentType.FUNCTION,
        )
        from openlaoke.core.architecture.interfaces import CodeTemplate

        template = CodeTemplate(
            name="test",
            description="Test",
            template="def test(): pass",
        )
        task1 = AtomicTask(
            task_id="task1",
            description="Task 1",
            component_spec=spec,
            template=template,
        )
        task2 = AtomicTask(
            task_id="task2",
            description="Task 2",
            component_spec=spec,
            template=template,
            dependencies=["task1"],
        )
        graph = TaskGraph(root_task_id="root")
        graph.add_task(task1)
        graph.add_task(task2)

        graph.mark_completed("task1")
        ready = graph.get_ready_tasks()
        assert len(ready) == 1
        assert ready[0].task_id == "task2"

    def test_task_graph_failure(self):
        graph = TaskGraph(root_task_id="root")
        graph.mark_failed("task1")
        assert "task1" in graph.failed


class TestFineGrainedDecomposer:
    def test_decomposer_creation(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        assert decomposer.model_tier == ModelTier.TIER_5_LIMITED
        assert decomposer.max_lines_per_task == 15
        assert decomposer.max_params_per_function == 3
        assert decomposer.max_complexity == 5

    def test_decomposer_tier5_limits(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        assert decomposer.max_lines_per_task == 15
        assert decomposer.max_params_per_function == 3

    def test_decomposer_tier1_limits(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_1_ADVANCED)
        assert decomposer.max_lines_per_task == 100
        assert decomposer.max_params_per_function == 10

    def test_decompose_simple_function(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        spec = ComponentSpec(
            name="simple_func",
            component_type=ComponentType.FUNCTION,
            complexity_score=2,
        )
        tasks = decomposer.decompose_function(spec)
        assert len(tasks) >= 1
        assert tasks[0].task_id == "simple_func_main"

    def test_decompose_function_with_test(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        spec = ComponentSpec(
            name="func_with_test",
            component_type=ComponentType.FUNCTION,
            test_requirements=["unit test"],
        )
        tasks = decomposer.decompose_function(spec)
        test_tasks = [t for t in tasks if "test" in t.task_id.lower()]
        assert len(test_tasks) >= 1

    def test_decompose_class(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        spec = ComponentSpec(
            name="test_class",
            component_type=ComponentType.CLASS,
            complexity_score=3,
        )
        tasks = decomposer.decompose_class(spec)
        assert len(tasks) >= 2

    def test_decompose_module(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        spec = ComponentSpec(
            name="test_module",
            component_type=ComponentType.MODULE,
            complexity_score=5,
        )
        tasks = decomposer.decompose_module(spec)
        assert len(tasks) >= 3

        import_tasks = [t for t in tasks if "imports" in t.task_id]
        export_tasks = [t for t in tasks if "exports" in t.task_id]
        assert len(import_tasks) >= 1
        assert len(export_tasks) >= 1

    def test_decompose_project(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        project_spec = {
            "modules": [
                {
                    "name": "module1",
                    "dependencies": [],
                    "complexity": 3,
                }
            ]
        }
        graph = decomposer.decompose_project(project_spec)
        assert graph is not None
        assert len(graph.tasks) > 0

    def test_parameter_grouping(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)

        params = {f"param_{i}": {"type": "int"} for i in range(7)}
        groups = decomposer._group_parameters(params)

        assert len(groups) >= 2
        for group in groups:
            assert len(group) <= decomposer.max_params_per_function


class TestCreateDecomposerForModel:
    def test_create_for_tier5(self):
        decomposer = create_decomposer_for_model(ModelTier.TIER_5_LIMITED)
        assert decomposer.model_tier == ModelTier.TIER_5_LIMITED

    def test_create_for_tier1(self):
        decomposer = create_decomposer_for_model(ModelTier.TIER_1_ADVANCED)
        assert decomposer.model_tier == ModelTier.TIER_1_ADVANCED


class TestTaskComplexityHandling:
    def test_simple_function_decomposition(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        spec = ComponentSpec(
            name="add",
            component_type=ComponentType.FUNCTION,
            api_spec=APISpec(
                name="add",
                description="Add two numbers",
                input_schema={
                    "properties": {
                        "a": {"type": "float"},
                        "b": {"type": "float"},
                    }
                },
                output_schema={"type": "float"},
            ),
            complexity_score=1,
        )
        tasks = decomposer.decompose_function(spec)

        assert len(tasks) >= 1
        assert all(t.estimated_lines <= 15 for t in tasks)

    def test_complex_function_decomposition(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        spec = ComponentSpec(
            name="complex_func",
            component_type=ComponentType.FUNCTION,
            api_spec=APISpec(
                name="complex",
                description="Complex function with many parameters",
                input_schema={"properties": {f"param_{i}": {"type": "int"} for i in range(5)}},
                output_schema={"type": "object"},
            ),
            complexity_score=7,
        )
        tasks = decomposer.decompose_function(spec)

        assert len(tasks) >= 2


class TestDependencyManagement:
    def test_task_dependencies(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        spec = ComponentSpec(
            name="test_func",
            component_type=ComponentType.FUNCTION,
            test_requirements=["test"],
        )
        tasks = decomposer.decompose_function(spec)

        tasks_with_deps = [t for t in tasks if len(t.dependencies) > 0]
        assert len(tasks_with_deps) >= 1

    def test_module_dependency_chain(self):
        decomposer = FineGrainedDecomposer(ModelTier.TIER_5_LIMITED)
        spec = ComponentSpec(
            name="test_module",
            component_type=ComponentType.MODULE,
            complexity_score=4,
        )
        tasks = decomposer.decompose_module(spec)

        for task in tasks:
            for dep_id in task.dependencies:
                assert dep_id in [t.task_id for t in tasks]
