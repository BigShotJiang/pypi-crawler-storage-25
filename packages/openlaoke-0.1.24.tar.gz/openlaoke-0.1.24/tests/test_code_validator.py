"""Tests for incremental code validation."""

import pytest

from openlaoke.core.code_validator import (
    CodeValidator,
    IncrementalBuilder,
    ExecutionValidator,
    ValidationResult,
    create_validated_code,
)


class TestValidationResult:
    def test_result_creation(self):
        result = ValidationResult(is_valid=True)
        assert result.is_valid
        assert len(result.errors) == 0

    def test_result_with_errors(self):
        result = ValidationResult(
            is_valid=False,
            errors=["Error 1", "Error 2"],
        )
        assert not result.is_valid
        assert len(result.errors) == 2


class TestCodeValidator:
    def test_validator_creation(self):
        validator = CodeValidator()
        assert validator is not None

    def test_validate_correct_syntax(self):
        validator = CodeValidator()

        code = "x = 1\nprint(x)"
        result = validator.validate_syntax(code)

        assert result.is_valid
        assert len(result.errors) == 0

    def test_validate_syntax_error(self):
        validator = CodeValidator()

        code = "x = 1\nprint(x"
        result = validator.validate_syntax(code)

        assert not result.is_valid
        assert len(result.errors) > 0

    def test_validate_function_correct(self):
        validator = CodeValidator()

        func = '''
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b
'''
        result = validator.validate_function(func)

        assert result.is_valid

    def test_validate_function_syntax_error(self):
        validator = CodeValidator()

        func = """
def broken(:
    pass
"""
        result = validator.validate_function(func)

        assert not result.is_valid

    def test_auto_fix_syntax(self):
        validator = CodeValidator()

        code = "print('hello'"
        fixed = validator.auto_fix_syntax(code)

        # Should not crash
        assert isinstance(fixed, str)


class TestIncrementalBuilder:
    def test_builder_creation(self):
        builder = IncrementalBuilder()
        assert len(builder.code_parts) == 0

    def test_add_imports(self):
        builder = IncrementalBuilder()

        imports = "import os\nimport sys"
        result = builder.add_imports(imports)

        assert result.is_valid
        assert len(builder.code_parts) == 1

    def test_add_function(self):
        builder = IncrementalBuilder()

        func = """
def test() -> None:
    pass
"""
        result = builder.add_function(func)

        assert result.is_valid
        assert len(builder.code_parts) == 1

    def test_get_final_code(self):
        builder = IncrementalBuilder()

        builder.add_imports("import os")
        builder.add_function("def test(): pass")

        code = builder.get_final_code()

        assert "import os" in code
        assert "def test" in code


class TestExecutionValidator:
    def test_test_imports_valid(self):
        validator = ExecutionValidator()

        code = "import os\nimport sys"
        result = validator.test_imports(code)

        assert result.is_valid

    def test_test_imports_invalid(self):
        validator = ExecutionValidator()

        code = "import nonexistent_module_xyz"
        result = validator.test_imports(code)

        assert not result.is_valid

    def test_test_syntax_valid(self):
        validator = ExecutionValidator()

        code = "x = 1\nprint(x)"
        result = validator.test_syntax_with_python(code)

        assert result.is_valid

    def test_test_syntax_invalid(self):
        validator = ExecutionValidator()

        code = "x = 1\nprint(x"
        result = validator.test_syntax_with_python(code)

        assert not result.is_valid


class TestCreateValidatedCode:
    def test_create_from_parts(self):
        parts = [
            "import os",
            "def test(): pass",
        ]

        code, result = create_validated_code(parts)

        assert "import os" in code
        assert "def test" in code

    def test_create_with_validation(self):
        parts = [
            "import os",
            "def broken(: pass",  # Syntax error
        ]

        code, result = create_validated_code(parts, validate_each=True)

        assert not result.is_valid  # Should catch the error


class TestIncrementalValidation:
    def test_step_by_step_validation(self):
        builder = IncrementalBuilder()

        # Step 1: Add imports
        result1 = builder.add_imports("import time")
        assert result1.is_valid

        # Step 2: Add function
        result2 = builder.add_function("def get_time() -> float:\n    return time.time()")
        assert result2.is_valid

        # Step 3: Add main
        result3 = builder.add_main_block("print(get_time())")
        assert result3.is_valid

        # Final validation
        final = builder.validate_final()
        assert final.is_valid


class TestErrorRecovery:
    def test_continue_after_error(self):
        builder = IncrementalBuilder()

        # Add invalid code
        result1 = builder.add_function("def broken(: pass")
        assert not result1.is_valid

        # Should still be able to add valid code
        result2 = builder.add_function("def valid(): pass")
        assert result2.is_valid

        code = builder.get_final_code()
        assert "def valid" in code
