"""Tests for task supervisor system."""

import tempfile

import pytest

from openlaoke.core.state import create_app_state
from openlaoke.core.supervisor.requirements import TaskRequirements
from openlaoke.core.supervisor.supervisor import (
    RetryReason,
    SupervisedTask,
    SupervisionResult,
    TaskStatus,
    TaskSupervisor,
)
from openlaoke.types.providers import MultiProviderConfig


class TestTaskStatus:
    def test_task_status_values(self):
        assert TaskStatus.PENDING.value == "pending"
        assert TaskStatus.IN_PROGRESS.value == "in_progress"
        assert TaskStatus.COMPLETED.value == "completed"
        assert TaskStatus.FAILED.value == "failed"
        assert TaskStatus.RETRYING.value == "retrying"
        assert TaskStatus.ESCALATED.value == "escalated"


class TestRetryReason:
    def test_retry_reason_values(self):
        assert RetryReason.INCOMPLETE_OUTPUT.value == "incomplete_output"
        assert RetryReason.MISSING_REQUIREMENTS.value == "missing_requirements"
        assert RetryReason.ERROR_OCCURRED.value == "error_occurred"
        assert RetryReason.QUALITY_ISSUE.value == "quality_issue"
        assert RetryReason.AI_DETECTED.value == "ai_detected"


class TestTaskRequirements:
    def test_requirement_creation(self):
        req = TaskRequirements(
            name="document_created",
            description="Target document must be created",
            check_type="file_exists",
            critical=True,
        )
        assert req.name == "document_created"
        assert req.description == "Target document must be created"
        assert req.check_type == "file_exists"
        assert req.critical
        assert req.weight == 2.0

    def test_requirement_with_threshold(self):
        req = TaskRequirements(
            name="word_count",
            description="Document must have sufficient length",
            check_type="word_count",
            threshold=3000,
            critical=True,
        )
        assert req.threshold == 3000

    def test_requirement_weight(self):
        req = TaskRequirements(
            name="optional_check",
            description="Optional quality check",
            check_type="general",
            critical=False,
        )
        assert req.weight == 1.0


class TestSupervisedTask:
    def test_supervised_task_creation(self):
        reqs = [
            TaskRequirements(
                name="test_req",
                description="Test requirement",
                check_type="general",
                critical=True,
            )
        ]
        task = SupervisedTask(
            original_request="Test task",
            requirements=reqs,
        )
        assert task.original_request == "Test task"
        assert len(task.requirements) == 1
        assert task.status == TaskStatus.PENDING
        assert task.attempts == 0
        assert task.max_attempts == 5

    def test_supervised_task_with_model(self):
        task = SupervisedTask(
            original_request="Test",
            requirements=[],
            model="gemma3:1b",
        )
        assert task.model == "gemma3:1b"

    def test_supervised_task_with_decomposed_steps(self):
        task = SupervisedTask(
            original_request="Complex task",
            requirements=[],
            decomposed_steps=["Step 1", "Step 2", "Step 3"],
        )
        assert len(task.decomposed_steps) == 3
        assert task.current_step == 0


class TestSupervisionResult:
    def test_supervision_result_creation(self):
        result = SupervisionResult(
            task_id="task_123",
            is_complete=False,
            completion_percentage=50.0,
            missing_requirements=["Missing doc"],
            suggested_actions=["Create document"],
            should_retry=True,
            retry_reason=RetryReason.MISSING_REQUIREMENTS,
            feedback="Incomplete",
        )
        assert result.task_id == "task_123"
        assert not result.is_complete
        assert result.completion_percentage == 50.0
        assert len(result.missing_requirements) == 1
        assert result.should_retry
        assert result.retry_reason == RetryReason.MISSING_REQUIREMENTS

    def test_supervision_result_complete(self):
        result = SupervisionResult(
            task_id="task_123",
            is_complete=True,
            completion_percentage=100.0,
            missing_requirements=[],
            suggested_actions=[],
            should_retry=False,
        )
        assert result.is_complete
        assert result.completion_percentage == 100.0
        assert not result.should_retry


class TestTaskSupervisor:
    def test_supervisor_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)
            assert supervisor.app_state == state
            assert len(supervisor.tasks) == 0

    def test_set_model(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)
            config = MultiProviderConfig.defaults()

            supervisor.set_model("gemma3:1b", config)
            assert supervisor.current_model == "gemma3:1b"
            assert supervisor.model_assessor is not None
            assert supervisor.task_decomposer is not None

    def test_parse_simple_request(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Simple query")
            assert task.original_request == "Simple query"
            assert task.status == TaskStatus.PENDING
            assert len(task.requirements) == 1

    def test_parse_write_article_request(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Write an article about AI")
            assert task.original_request == "Write an article about AI"
            assert len(task.requirements) > 1

            critical_reqs = [r for r in task.requirements if r.critical]
            assert len(critical_reqs) > 0

            assert any(r.name == "document_created" for r in task.requirements)
            assert any(r.name == "sufficient_length" for r in task.requirements)
            assert any(r.name == "anti_ai_quality" for r in task.requirements)

    def test_parse_code_request(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Implement a Python function")
            assert len(task.requirements) >= 1  # Should have at least general requirement

    def test_parse_comparison_request(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Compare two approaches")
            assert any(r.name == "quantitative_data" for r in task.requirements)

    def test_parse_diagram_request(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Create a diagram")
            assert any(r.name == "figures_created" for r in task.requirements)

    def test_decompose_with_model_assessment(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)
            config = MultiProviderConfig.defaults()

            supervisor.set_model("gemma3:1b", config)

            task = supervisor.parse_request(
                "Write an article and create a diagram and implement code"
            )

            assert len(task.decomposed_steps) > 1
            assert len(task.decomposed_steps) <= 4

    def test_get_task_status(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Test")
            task_id = [k for k in supervisor.tasks.keys()][0]

            retrieved = supervisor.get_task_status(task_id)
            assert retrieved is not None
            assert retrieved.original_request == "Test"

    def test_should_escalate(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Test")
            task_id = [k for k in supervisor.tasks.keys()][0]

            assert not supervisor.should_escalate(task_id)

            task.attempts = task.max_attempts
            task.status = TaskStatus.RETRYING
            assert supervisor.should_escalate(task_id)

    def test_enable_supervision(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            assert supervisor._supervision_enabled

            supervisor.enable_supervision(False)
            assert not supervisor._supervision_enabled

    def test_enable_anti_ai_mode(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            assert supervisor._anti_ai_mode

            supervisor.enable_anti_ai_mode(False)
            assert not supervisor._anti_ai_mode


class TestSupervisorCheckCompletion:
    @pytest.mark.asyncio
    async def test_check_completion_task_not_found(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            result = await supervisor.check_completion("nonexistent", {})
            assert not result.is_complete
            assert "Task not found" in result.missing_requirements
            assert not result.should_retry

    @pytest.mark.asyncio
    async def test_check_completion_complete_task(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Simple query")
            task_id = [k for k in supervisor.tasks.keys()][0]

            artifacts = {"output": "Task completed successfully"}
            result = await supervisor.check_completion(task_id, artifacts)

            assert result.completion_percentage >= 0.0

    @pytest.mark.asyncio
    async def test_check_completion_with_file_artifacts(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Write an article about AI")
            task_id = [k for k in supervisor.tasks.keys()][0]

            test_file = f"{tmpdir}/article.md"
            with open(test_file, "w") as f:
                f.write("Article content\n" * 200)

            artifacts = {
                "file": test_file,
                "content": "Article with sufficient content",
            }

            result = await supervisor.check_completion(task_id, artifacts)
            assert result.completion_percentage >= 0.0


class TestSupervisorRetryPrompt:
    def test_get_retry_prompt_basic(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Write an article")
            task_id = [k for k in supervisor.tasks.keys()][0]

            result = SupervisionResult(
                task_id=task_id,
                is_complete=False,
                completion_percentage=30.0,
                missing_requirements=["Missing length", "Missing citations"],
                suggested_actions=["Add content", "Add citations"],
                should_retry=True,
                retry_reason=RetryReason.MISSING_REQUIREMENTS,
            )

            prompt = supervisor.get_retry_prompt(task_id, result)
            assert "Write an article" in prompt
            assert "30.0%" in prompt
            assert "Missing length" in prompt
            assert "Add content" in prompt

    def test_get_retry_prompt_ai_detected(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Write an article")
            task_id = [k for k in supervisor.tasks.keys()][0]

            result = SupervisionResult(
                task_id=task_id,
                is_complete=False,
                completion_percentage=50.0,
                missing_requirements=["AI-typical patterns detected"],
                suggested_actions=["Add specific numbers", "Add real citations"],
                should_retry=True,
                retry_reason=RetryReason.AI_DETECTED,
            )

            prompt = supervisor.get_retry_prompt(task_id, result)
            assert "AI" in prompt or "Anti-AI" in prompt
            assert "specific numbers" in prompt or "SPECIFIC" in prompt


class TestSupervisorStepManagement:
    def test_get_step_prompt(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)
            config = MultiProviderConfig.defaults()

            supervisor.set_model("gemma3:1b", config)

            task = supervisor.parse_request("Step 1 and Step 2 and Step 3")
            task_id = [k for k in supervisor.tasks.keys()][0]

            step_prompt = supervisor.get_step_prompt(task_id)
            if step_prompt:
                assert "Step" in step_prompt

    def test_advance_step(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)
            config = MultiProviderConfig.defaults()

            supervisor.set_model("gemma3:1b", config)

            task = supervisor.parse_request("Step 1 and Step 2")
            task_id = [k for k in supervisor.tasks.keys()][0]

            if len(task.decomposed_steps) > 1:
                assert supervisor.advance_step(task_id)
                assert supervisor.tasks[task_id].current_step == 1

                assert not supervisor.advance_step(task_id)

    def test_get_timeout(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            timeout = supervisor.get_timeout(60.0)
            assert timeout == 60.0

            config = MultiProviderConfig.defaults()
            supervisor.set_model("gemma3:1b", config)

            timeout = supervisor.get_timeout(60.0)
            assert timeout > 60.0

    def test_get_model_guidance(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            guidance = supervisor.get_model_guidance()
            assert guidance == ""

            config = MultiProviderConfig.defaults()
            supervisor.set_model("gemma3:1b", config)

            guidance = supervisor.get_model_guidance()
            if guidance:
                assert "explicit" in guidance.lower() or "atomic" in guidance.lower()


class TestSupervisorIntegration:
    @pytest.mark.asyncio
    async def test_full_supervision_cycle(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)
            config = MultiProviderConfig.defaults()

            supervisor.set_model("gemma3:1b", config)

            task = supervisor.parse_request(
                "Write a comprehensive article about machine learning with citations"
            )
            task_id = [k for k in supervisor.tasks.keys()][0]

            assert len(task.requirements) > 3
            assert task.status == TaskStatus.PENDING

            artifacts1 = {"partial": "Incomplete work"}
            result1 = await supervisor.check_completion(task_id, artifacts1)

            assert not result1.is_complete
            assert result1.completion_percentage < 80.0

            test_file = f"{tmpdir}/article.md"
            with open(test_file, "w") as f:
                f.write("Introduction\n\n" + "Content\n" * 300 + "\nReferences\n[1] Test\n")

            artifacts2 = {
                "file": test_file,
                "content": "Full article with references",
            }

            result2 = await supervisor.check_completion(task_id, artifacts2)
            assert result2.completion_percentage >= result1.completion_percentage

    @pytest.mark.asyncio
    async def test_retry_cycle_with_improvement(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            supervisor = TaskSupervisor(state)

            task = supervisor.parse_request("Write an article")
            task_id = [k for k in supervisor.tasks.keys()][0]

            result1 = SupervisionResult(
                task_id=task_id,
                is_complete=False,
                completion_percentage=20.0,
                missing_requirements=["No content"],
                suggested_actions=["Add content"],
                should_retry=True,
                retry_reason=RetryReason.INCOMPLETE_OUTPUT,
            )

            prompt1 = supervisor.get_retry_prompt(task_id, result1)
            assert prompt1

            task.attempts += 1

            result2 = SupervisionResult(
                task_id=task_id,
                is_complete=False,
                completion_percentage=40.0,
                missing_requirements=["More content needed"],
                suggested_actions=["Expand"],
                should_retry=True,
                retry_reason=RetryReason.INCOMPLETE_OUTPUT,
            )

            prompt2 = supervisor.get_retry_prompt(task_id, result2)
            assert "40.0%" in prompt2
            assert "Attempt 1" in prompt2
