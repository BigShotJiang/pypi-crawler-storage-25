"""End-to-end tests for intent-based pipeline."""

from __future__ import annotations

import pytest

from openlaoke.core.intent_pipeline import (
    IntentBasedPipeline,
    ProcessingPipelineResult,
    create_pipeline_for_model,
)
from openlaoke.core.intent_parser import IntentType, ProgrammingLanguage
from openlaoke.core.architecture.interfaces import ComponentType
from openlaoke.core.model_assessment.types import ModelTier
from pathlib import Path


class TestIntentBasedPipeline:
    def test_pipeline_initialization(self) -> None:
        pipeline = IntentBasedPipeline()
        assert pipeline is not None
        assert pipeline.parser is not None
        assert pipeline.converter is not None
        assert pipeline.decomposer is not None

    def test_pipeline_for_tier_5(self) -> None:
        pipeline = create_pipeline_for_model(ModelTier.TIER_5_LIMITED)
        assert pipeline.model_tier == ModelTier.TIER_5_LIMITED
        assert pipeline.decomposer.max_lines_per_task == 15
        assert pipeline.decomposer.max_params_per_function == 3

    def test_process_write_program_request(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a python calculator program"
        result = pipeline.process_request(request)

        assert result.success
        assert result.intent.intent_type == IntentType.WRITE_PROGRAM
        assert result.intent.language == ProgrammingLanguage.PYTHON
        assert len(result.specs) > 0
        assert len(result.tasks) > 0
        assert result.task_graph is not None
        assert result.ready_to_execute

    def test_process_write_function_request(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "create a function to sort list"
        result = pipeline.process_request(request)

        assert result.success
        assert result.intent.intent_type == IntentType.WRITE_FUNCTION
        assert len(result.specs) > 0
        assert len(result.tasks) > 0

    def test_process_write_class_request(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "implement a class for user manager"
        result = pipeline.process_request(request)

        assert result.success
        assert result.intent.intent_type == IntentType.WRITE_CLASS
        assert len(result.specs) > 0
        assert len(result.tasks) > 0

    def test_unknown_request_fails_gracefully(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "hello world"
        result = pipeline.process_request(request)

        assert not result.success
        assert result.intent.intent_type == IntentType.UNKNOWN
        assert len(result.errors) > 0
        assert not result.ready_to_execute

    def test_execution_plan_generated(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a benchmark program"
        result = pipeline.process_request(request)

        assert result.success

        plan = pipeline.get_execution_plan(result)

        assert "total_tasks" in plan
        assert "ready_tasks" in plan
        assert "pending_tasks" in plan
        assert plan["total_tasks"] > 0

    def test_task_prompt_generated(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a calculator program"
        result = pipeline.process_request(request)

        assert result.success
        assert len(result.tasks) > 0

        task = result.tasks[0]
        prompt = pipeline.generate_task_prompt(task)

        assert task.description in prompt
        assert "Requirements:" in prompt
        assert "lines" in prompt.lower()

    def test_validate_correct_code(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a function"
        result = pipeline.process_request(request)

        assert result.success
        task = result.tasks[0]

        correct_code = '''
def example_function(x: int) -> int:
    """Example function."""
    return x * 2
'''

        is_valid, errors = pipeline.validate_task_result(task, correct_code)
        assert is_valid
        assert len(errors) == 0

    def test_validate_incorrect_code_syntax_error(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a function"
        result = pipeline.process_request(request)

        assert result.success
        task = result.tasks[0]

        incorrect_code = """
def example_function(x: int) -> int:
    return x * 2
    else:
        pass
"""

        is_valid, errors = pipeline.validate_task_result(task, incorrect_code)
        assert not is_valid
        assert len(errors) > 0
        assert any("syntax" in e.lower() for e in errors)

    def test_validate_missing_type_hints(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a function"
        result = pipeline.process_request(request)

        assert result.success
        task = result.tasks[0]

        code_without_hints = '''
def example_function(x):
    """Example function."""
    return x * 2
'''

        is_valid, errors = pipeline.validate_task_result(task, code_without_hints)
        assert not is_valid
        assert any("type hint" in e.lower() for e in errors)

    def test_validate_missing_docstring(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a function"
        result = pipeline.process_request(request)

        assert result.success
        task = result.tasks[0]

        code_without_docstring = """
def example_function(x: int) -> int:
    return x * 2
"""

        is_valid, errors = pipeline.validate_task_result(task, code_without_docstring)
        assert not is_valid
        assert any("docstring" in e.lower() for e in errors)

    def test_tier_5_task_size_limits(self) -> None:
        pipeline = IntentBasedPipeline(ModelTier.TIER_5_LIMITED)
        request = "write a comprehensive large complex program"
        result = pipeline.process_request(request)

        assert result.success

        for task in result.tasks:
            assert task.estimated_lines <= 15

    def test_cpu_benchmark_example(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a cpu benchmark program"
        result = pipeline.process_request(request)

        assert result.success
        assert result.intent.intent_type == IntentType.WRITE_PROGRAM
        assert result.intent.task_name == "benchmark"

        plan = pipeline.get_execution_plan(result)
        assert plan["total_tasks"] >= 3

        has_module = any(
            "module" in task["description"].lower()
            for task in plan["ready_tasks"] + plan["pending_tasks"]
        )
        has_main = any(
            "main" in task["description"].lower() or "benchmark" in task["description"].lower()
            for task in plan["ready_tasks"] + plan["pending_tasks"]
        )
        has_test = any(
            "test" in task["description"].lower()
            for task in plan["ready_tasks"] + plan["pending_tasks"]
        )

        assert has_module or has_main or has_test

    def test_tasks_have_dependencies(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a calculator program with validation"
        result = pipeline.process_request(request)

        assert result.success

        tasks_with_deps = [t for t in result.tasks if len(t.dependencies) > 0]
        assert len(tasks_with_deps) > 0

    def test_task_graph_ready_tasks(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a program"
        result = pipeline.process_request(request)

        assert result.success
        assert result.task_graph is not None

        ready_tasks = result.task_graph.get_ready_tasks()
        assert len(ready_tasks) > 0

        for task in ready_tasks:
            assert len(task.dependencies) == 0 or all(
                dep in result.task_graph.completed for dep in task.dependencies
            )


class TestEndToEndWorkflow:
    def test_full_workflow_cpu_benchmark(self) -> None:
        pipeline = IntentBasedPipeline(ModelTier.TIER_5_LIMITED)

        request = "write a CPU benchmark program that calculates real performance"
        result = pipeline.process_request(request)

        assert result.success
        assert result.ready_to_execute

        plan = pipeline.get_execution_plan(result)
        assert plan["total_tasks"] > 0

        ready_tasks = result.task_graph.get_ready_tasks() if result.task_graph else []
        assert len(ready_tasks) > 0

        first_task = ready_tasks[0]
        prompt = pipeline.generate_task_prompt(first_task)

        assert "Task:" in prompt
        assert "Requirements:" in prompt
        assert "15 lines" in prompt

        code_example = '''
def measure_performance(iterations: int) -> float:
    """Measure CPU performance."""
    import time
    start = time.time()
    for _ in range(iterations):
        _ = sum(range(1000))
    end = time.time()
    return iterations / (end - start)
'''

        is_valid, errors = pipeline.validate_task_result(first_task, code_example)
        assert is_valid or len(errors) == 0 or all("lines" in e.lower() for e in errors)

    def test_decomposition_creates_atomic_tasks(self) -> None:
        pipeline = IntentBasedPipeline(ModelTier.TIER_5_LIMITED)

        request = "write a comprehensive program with input validation, calculation, and output formatting"
        result = pipeline.process_request(request)

        assert result.success

        for task in result.tasks:
            assert task.estimated_lines <= 15
            assert task.template is not None
            assert task.description is not None

    def test_incremental_execution_order(self) -> None:
        pipeline = IntentBasedPipeline()
        request = "write a program"
        result = pipeline.process_request(request)

        assert result.success
        assert result.task_graph is not None

        execution_order = []
        graph = result.task_graph

        iteration = 0
        max_iterations = 10

        while len(graph.completed) < len(graph.tasks) and iteration < max_iterations:
            ready = graph.get_ready_tasks()

            if not ready:
                break

            for task in ready:
                execution_order.append(task.task_id)
                graph.mark_completed(task.task_id)

            iteration += 1

        assert len(execution_order) > 0
        assert len(graph.completed) == len(graph.tasks)
