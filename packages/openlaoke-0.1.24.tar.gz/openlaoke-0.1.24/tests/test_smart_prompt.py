"""Tests for smart prompt generator."""

import pytest

from openlaoke.core.smart_prompt import (
    SmartPromptGenerator,
    optimize_for_small_model,
)


class TestSmartPromptGenerator:
    def test_generator_creation(self):
        generator = SmartPromptGenerator("gemma3:1b")
        assert generator.adapter.model == "gemma3:1b"

    def test_generate_basic_prompt(self):
        generator = SmartPromptGenerator("gemma3:1b")
        base = "You are helpful."
        user_req = "read the file"

        prompt = generator.generate_system_prompt(user_req, base)
        assert "You are helpful" in prompt

    def test_optimize_for_creation(self):
        generator = SmartPromptGenerator("gemma3:1b")
        base = "You are helpful."
        user_req = "write a new program"

        prompt = generator.generate_system_prompt(user_req, base)
        assert "OPTIMIZATION" in prompt
        assert "Do NOT" in prompt
        assert "IMMEDIATELY" in prompt

    def test_no_optimization_for_reading(self):
        generator = SmartPromptGenerator("gemma3:1b")
        base = "You are helpful."
        user_req = "show me the file"

        prompt = generator.generate_system_prompt(user_req, base)
        assert "OPTIMIZATION" not in prompt

    def test_tool_instructions_for_no_tool_model(self):
        generator = SmartPromptGenerator("gemma3:1b")
        base = "You are helpful."
        user_req = "do something"
        tools = [{"name": "read", "description": "Read file", "input_schema": {}}]

        prompt = generator.generate_system_prompt(user_req, base, tools)
        assert "TOOL USAGE" in prompt

    def test_no_tool_instructions_for_tool_model(self):
        generator = SmartPromptGenerator("gemma4:e2b")
        base = "You are helpful."
        user_req = "do something"
        tools = [{"name": "read", "description": "Read file", "input_schema": {}}]

        prompt = generator.generate_system_prompt(user_req, base, tools)
        assert "TOOL USAGE" not in prompt

    def test_get_execution_hints_creation(self):
        generator = SmartPromptGenerator("gemma3:1b")

        hints = generator.get_execution_hints("write a new file")
        assert hints["skip_context_gathering"] is True
        assert hints["is_creation"] is True
        assert hints["needs_tools"] is True

    def test_get_execution_hints_reading(self):
        generator = SmartPromptGenerator("gemma3:1b")

        hints = generator.get_execution_hints("read the file")
        assert hints["skip_context_gathering"] is False
        assert hints["is_creation"] is False
        assert hints["needs_tools"] is True


class TestOptimizeForSmallModel:
    def test_optimize_basic(self):
        base = "You are helpful."
        user_req = "write a new program"
        model = "gemma3:1b"

        prompt, hints = optimize_for_small_model(model, user_req, base)

        assert "OPTIMIZATION" in prompt
        assert hints["skip_context_gathering"] is True

    def test_optimize_with_tools(self):
        base = "You are helpful."
        user_req = "create a file"
        model = "gemma3:1b"
        tools = [{"name": "write", "description": "Write", "input_schema": {}}]

        prompt, hints = optimize_for_small_model(model, user_req, base, tools)

        assert "TOOL USAGE" in prompt
        assert hints["needs_tools"] is True

    def test_optimize_for_tool_model(self):
        base = "You are helpful."
        user_req = "write a program"
        model = "gemma4:e2b"

        prompt, hints = optimize_for_small_model(model, user_req, base)

        assert hints["needs_tools"] is False


class TestChineseRequests:
    def test_chinese_creation_request(self):
        generator = SmartPromptGenerator("gemma3:1b")

        prompt = generator.generate_system_prompt("写一个新程序", "You are helpful.")
        assert "OPTIMIZATION" in prompt

    def test_chinese_read_request(self):
        generator = SmartPromptGenerator("gemma3:1b")

        prompt = generator.generate_system_prompt("读取文件", "You are helpful.")
        assert "OPTIMIZATION" not in prompt


class TestEdgeCases:
    def test_empty_request(self):
        generator = SmartPromptGenerator("gemma3:1b")
        hints = generator.get_execution_hints("")
        assert hints["is_creation"] is False

    def test_modify_existing(self):
        generator = SmartPromptGenerator("gemma3:1b")

        hints = generator.get_execution_hints("modify existing file")
        assert hints["skip_context_gathering"] is False
        assert hints["is_creation"] is False  # modification, not creation

    def test_based_on_existing(self):
        generator = SmartPromptGenerator("gemma3:1b")

        hints = generator.get_execution_hints("create based on existing code")
        assert hints["skip_context_gathering"] is False
