#!/usr/bin/env python
"""Test script for dual-model optimization features.

This script demonstrates:
1. Intelligent model selection based on available resources
2. CPU/GPU hybrid model loading
3. Batch operations for better performance
4. Model status monitoring
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


async def test_intelligent_selector():
    """Test intelligent model selection."""
    from openlaoke.core.intelligent_model_selector import IntelligentModelSelector

    print("=" * 60)
    print("TEST 1: Intelligent Model Selector")
    print("=" * 60)

    selector = IntelligentModelSelector()

    vram = await selector.detect_available_vram()
    print(f"\n✓ Detected VRAM: {vram:.1f} GB")

    report = await selector.get_recommendation_report()

    print(f"\n✓ Recommended Combination: {report['recommended_combination']['name'].upper()}")
    print(f"  Planner:   {report['recommended_combination']['planner']}")
    print(f"  Executor:  {report['recommended_combination']['executor']}")
    print(f"  Validator: {report['recommended_combination']['validator']}")

    print(f"\n✓ Estimated:")
    print(f"  VRAM Usage: {report['estimated']['vram_usage_gb']:.1f} GB")
    print(f"  Quality:    {report['estimated']['quality_score']:.1f}/10")
    print(f"  Cost:       {report['estimated']['cost_factor']:.1f}x")

    print(f"\n✓ Suitable Combinations: {len(report['all_suitable_combinations'])}")
    for combo in report["all_suitable_combinations"][:3]:
        print(f"  - {combo['name']}: {combo['vram_gb']:.1f} GB, quality {combo['quality']:.1f}")

    return True


async def test_hybrid_manager():
    """Test CPU/GPU hybrid model manager."""
    from openlaoke.core.hybrid_model_manager import create_hybrid_manager

    print("\n" + "=" * 60)
    print("TEST 2: CPU/GPU Hybrid Model Manager")
    print("=" * 60)

    manager = create_hybrid_manager()

    print("\n✓ Initializing model pool...")
    result = await manager.initialize()

    print(f"  Success: {result['success']}")
    print(f"  Strategy: {result['strategy']}")

    print("\n✓ Getting model status...")
    status = await manager.get_status()

    print(f"\n  CPU Models: {len(status.cpu_models)}")
    for model in status.cpu_models:
        loaded = "✓" if model.is_loaded else "✗"
        print(f"    {loaded} {model.name} ({model.tier})")

    print(f"\n  GPU Models: {len(status.gpu_models)}")
    for model in status.gpu_models:
        loaded = "✓" if model.is_loaded else "✗"
        print(f"    {loaded} {model.name} ({model.tier}, {model.size_gb:.1f} GB)")

    print(f"\n  GPU Memory: {status.gpu_used_gb:.1f} / {status.gpu_total_gb:.1f} GB")

    return True


async def test_batch_operations():
    """Test batch operations."""
    from openlaoke.core.hybrid_model_manager import create_hybrid_manager

    print("\n" + "=" * 60)
    print("TEST 3: Batch Operations (Simulated)")
    print("=" * 60)

    manager = create_hybrid_manager()
    await manager.initialize()

    print("\n✓ Simulating batch planner calls...")

    tasks = [
        "Task 1: Analyze requirements",
        "Task 2: Decompose into subtasks",
        "Task 3: Plan validation strategy",
    ]

    print(f"  Tasks to process: {len(tasks)}")
    print("  Batch processing (single model load)...")

    start = asyncio.get_event_loop().time()

    for i, task in enumerate(tasks, 1):
        print(f"    {i}. {task}")

    elapsed = asyncio.get_event_loop().time() - start
    print(f"\n  ✓ Batch completed in {elapsed:.2f}s")
    print("  (vs ~3x time for individual calls with model switching)")

    return True


async def test_dual_model_agent():
    """Test dual-model agent with optimizations."""
    from openlaoke.core.dual_model_agent import create_dual_model_agent
    from openlaoke.core.state import AppState

    print("\n" + "=" * 60)
    print("TEST 4: Dual-Model Agent with Optimizations")
    print("=" * 60)

    app_state = AppState()

    print("\n✓ Creating dual-model agent...")
    agent = create_dual_model_agent(app_state)

    print("✓ Selecting optimal models...")
    models = await agent._select_optimal_models()

    print(f"  Planner:   {models['planner']} ({models['planner_device']})")
    print(f"  Executor:  {models['executor']} ({models['executor_device']})")
    print(f"  Validator: {models['validator']} ({models['validator_device']})")

    print("\n✓ Model selection complete")
    print("  (Models will be loaded on first execution)")

    return True


async def main():
    """Run all tests."""
    print("\n" + "=" * 60)
    print("OpenLaoKe Model Optimization Test Suite")
    print("=" * 60)

    tests = [
        ("Intelligent Selector", test_intelligent_selector),
        ("Hybrid Manager", test_hybrid_manager),
        ("Batch Operations", test_batch_operations),
        ("Dual-Model Agent", test_dual_model_agent),
    ]

    results = []

    for name, test_func in tests:
        try:
            success = await test_func()
            results.append((name, success, None))
        except Exception as e:
            results.append((name, False, str(e)))

    print("\n" + "=" * 60)
    print("Test Results")
    print("=" * 60)

    for name, success, error in results:
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"{status}: {name}")
        if error:
            print(f"  Error: {error}")

    passed = sum(1 for _, success, _ in results if success)
    total = len(results)

    print(f"\n{passed}/{total} tests passed")

    print("\n" + "=" * 60)
    print("Next Steps")
    print("=" * 60)
    print("\nTo use these optimizations:")
    print("  1. pip install -e .")
    print("  2. openlaoke")
    print("  3. /preload-models")
    print("  4. /model-status")
    print("  5. /model-recommend quality")
    print("  6. /dual write a Python program to calculate disk storage")


if __name__ == "__main__":
    asyncio.run(main())
