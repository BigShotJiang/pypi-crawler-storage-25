"""Tests for safe execution boundary."""

import tempfile
from pathlib import Path

import pytest

from openlaoke.core.safe_boundary import (
    ExecutionBoundary,
    SafeToolWrapper,
    create_safe_wrapper,
)


class TestExecutionBoundary:
    def test_boundary_from_cwd(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = ExecutionBoundary.from_cwd(tmpdir)
            assert tmpdir in str(boundary.allowed_paths)

    def test_is_path_allowed_in_cwd(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = ExecutionBoundary.from_cwd(tmpdir)

            # Path inside cwd should be allowed
            assert boundary.is_path_allowed(tmpdir)
            assert boundary.is_path_allowed(Path(tmpdir) / "subdir")

    def test_is_path_denied_outside_cwd(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = ExecutionBoundary.from_cwd(tmpdir)

            # Path outside cwd should be denied
            assert not boundary.is_path_allowed("/etc/passwd")
            assert not boundary.is_path_allowed("/tmp")

    def test_check_path_allowed(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = ExecutionBoundary.from_cwd(tmpdir)

            allowed, msg = boundary.check_path(tmpdir)
            assert allowed
            assert msg == "OK"

    def test_check_path_denied(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = ExecutionBoundary.from_cwd(tmpdir)

            allowed, msg = boundary.check_path("/etc/passwd")
            assert not allowed
            assert "Unauthorized" in msg


class TestSafeToolWrapper:
    def test_wrapper_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)
            assert wrapper is not None

    def test_check_bash_command_allowed(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)

            # Command with path inside cwd
            allowed, msg = wrapper.check_bash_command(f"ls {tmpdir}")
            assert allowed

    def test_check_bash_command_denied(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)

            # Command with path outside cwd
            allowed, msg = wrapper.check_bash_command("cat /etc/passwd")
            assert not allowed

    def test_check_read_path_allowed(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)

            test_file = Path(tmpdir) / "test.txt"
            test_file.write_text("test")

            allowed, msg = wrapper.check_read_path(str(test_file))
            assert allowed

    def test_check_read_path_denied(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)

            allowed, msg = wrapper.check_read_path("/etc/passwd")
            assert not allowed

    def test_check_write_path_allowed(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)

            test_file = Path(tmpdir) / "output.txt"

            allowed, msg = wrapper.check_write_path(str(test_file))
            assert allowed

    def test_check_write_path_denied(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)

            allowed, msg = wrapper.check_write_path("/etc/passwd")
            assert not allowed


class TestCreationTaskSkip:
    def test_should_skip_for_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)

            assert wrapper.should_skip_for_creation("write a new file")
            assert wrapper.should_skip_for_creation("create a program")

    def test_should_not_skip_for_reading(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            wrapper = create_safe_wrapper(tmpdir)

            assert not wrapper.should_skip_for_creation("read the file")
            assert not wrapper.should_skip_for_creation("show me the code")


class TestAbsolutePathHandling:
    def test_absolute_path_outside_cwd(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = ExecutionBoundary.from_cwd(tmpdir)

            # Absolute path outside cwd
            assert not boundary.is_path_allowed("/usr/bin/python")
            assert not boundary.is_path_allowed("/tmp/other")

    def test_relative_path_handling(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = ExecutionBoundary.from_cwd(tmpdir)

            # Relative path should be relative to cwd
            assert boundary.is_path_allowed("./file.txt")
            assert boundary.is_path_allowed("subdir/file.txt")


class TestBoundarySecurity:
    def test_parent_directory_escape(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = ExecutionBoundary.from_cwd(tmpdir)

            # Trying to escape with ../
            parent = Path(tmpdir).parent
            assert not boundary.is_path_allowed(str(parent))
            assert not boundary.is_path_allowed("../")

    def test_symlink_escape(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            boundary = ExecutionBoundary.from_cwd(tmpdir)

            # Create symlink inside tmpdir
            link = tmp_path / "link_to_parent"
            try:
                link.symlink_to(tmp_path.parent)
                # Symlink should still be blocked if it points outside
                assert not boundary.is_path_allowed(str(link))
            except OSError:
                # Skip if symlink creation fails
                pass
