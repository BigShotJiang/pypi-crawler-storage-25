"""Tests for architecture system - orchestrator."""

import tempfile
from pathlib import Path

import pytest

from openlaoke.core.architecture.orchestrator import (
    WorkflowStep,
    IncrementalWorkflow,
    IncrementalOrchestrator,
    create_orchestrator_for_model,
)
from openlaoke.core.architecture.decomposer import AtomicTask, TaskGraph
from openlaoke.core.architecture.interfaces import (
    CodeTemplate,
    ComponentSpec,
    ComponentType,
)
from openlaoke.core.model_assessment.types import ModelTier
from openlaoke.core.state import create_app_state


class TestWorkflowStep:
    def test_workflow_step_creation(self):
        spec = ComponentSpec(
            name="test_func",
            component_type=ComponentType.FUNCTION,
        )
        template = CodeTemplate(
            name="test",
            description="Test",
            template="def test(): pass",
        )
        task = AtomicTask(
            task_id="test_task",
            description="Test task",
            component_spec=spec,
            template=template,
        )
        step = WorkflowStep(
            step_id="step1",
            task=task,
        )
        assert step.step_id == "step1"
        assert step.status == "pending"
        assert step.attempts == 0

    def test_workflow_step_max_attempts(self):
        spec = ComponentSpec(
            name="test",
            component_type=ComponentType.FUNCTION,
        )
        template = CodeTemplate(
            name="test",
            description="Test",
            template="def test(): pass",
        )
        task = AtomicTask(
            task_id="test",
            description="Test",
            component_spec=spec,
            template=template,
        )
        step = WorkflowStep(
            step_id="test",
            task=task,
            max_attempts=5,
        )
        assert step.max_attempts == 5


class TestIncrementalWorkflow:
    def test_workflow_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            from openlaoke.core.architecture.decomposer import FineGrainedDecomposer
            from openlaoke.core.architecture.assembler import CodeAssembler, IntegrationValidator

            workflow = IncrementalWorkflow(
                workflow_id="test_workflow",
                project_spec={"name": "test"},
                model="gemma3:1b",
                model_tier=ModelTier.TIER_5_LIMITED,
                decomposer=FineGrainedDecomposer(ModelTier.TIER_5_LIMITED),
                assembler=CodeAssembler(Path(tmpdir)),
                validator=IntegrationValidator(Path(tmpdir)),
            )
            assert workflow.workflow_id == "test_workflow"
            assert workflow.model == "gemma3:1b"

    def test_workflow_progress(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            from openlaoke.core.architecture.decomposer import FineGrainedDecomposer
            from openlaoke.core.architecture.assembler import CodeAssembler, IntegrationValidator

            workflow = IncrementalWorkflow(
                workflow_id="test",
                project_spec={},
                model="test",
                model_tier=ModelTier.TIER_5_LIMITED,
                decomposer=FineGrainedDecomposer(ModelTier.TIER_5_LIMITED),
                assembler=CodeAssembler(Path(tmpdir)),
                validator=IntegrationValidator(Path(tmpdir)),
            )

            spec = ComponentSpec(
                name="test",
                component_type=ComponentType.FUNCTION,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def test(): pass",
            )
            task = AtomicTask(
                task_id="test",
                description="Test",
                component_spec=spec,
                template=template,
            )
            step = WorkflowStep(step_id="test", task=task)
            workflow.steps["test"] = step
            workflow.completed_steps.append("test")

            progress = workflow.get_progress()
            assert progress["completed"] == 1
            assert progress["total_steps"] == 1


class TestIncrementalOrchestrator:
    def test_orchestrator_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = IncrementalOrchestrator(
                app_state,
                "gemma3:1b",
                ModelTier.TIER_5_LIMITED,
            )
            assert orchestrator.model == "gemma3:1b"
            assert orchestrator.model_tier == ModelTier.TIER_5_LIMITED

    def test_create_workflow(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = IncrementalOrchestrator(
                app_state,
                "gemma3:1b",
                ModelTier.TIER_5_LIMITED,
            )

            project_spec = {
                "name": "test_project",
                "modules": [
                    {
                        "name": "test_module",
                        "dependencies": [],
                        "complexity": 2,
                    }
                ],
            }

            workflow = orchestrator.create_workflow(project_spec)
            assert workflow is not None
            assert workflow.workflow_id in orchestrator.workflows

    def test_get_workflow_status(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = IncrementalOrchestrator(
                app_state,
                "gemma3:1b",
                ModelTier.TIER_5_LIMITED,
            )

            project_spec = {"modules": [{"name": "test", "dependencies": [], "complexity": 2}]}

            workflow = orchestrator.create_workflow(project_spec)
            status = orchestrator.get_workflow_status(workflow.workflow_id)

            assert status is not None
            assert "progress_percentage" in status
            assert "steps" in status

    def test_execute_simple_workflow(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = IncrementalOrchestrator(
                app_state,
                "gemma3:1b",
                ModelTier.TIER_5_LIMITED,
            )

            project_spec = {
                "modules": [
                    {
                        "name": "simple_module",
                        "dependencies": [],
                        "complexity": 1,
                    }
                ]
            }

            workflow = orchestrator.create_workflow(project_spec)
            result = orchestrator.execute_workflow(workflow.workflow_id)

            assert result is not None
            assert isinstance(result.success, bool)

    def test_workflow_state_persistence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = IncrementalOrchestrator(
                app_state,
                "gemma3:1b",
                ModelTier.TIER_5_LIMITED,
            )

            project_spec = {"modules": [{"name": "test", "dependencies": [], "complexity": 1}]}

            workflow = orchestrator.create_workflow(project_spec)
            orchestrator.save_workflow_state(workflow.workflow_id)

            loaded = orchestrator.load_workflow_state(workflow.workflow_id)
            assert loaded is not None


class TestCreateOrchestratorForModel:
    def test_create_for_gemma3_1b(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = create_orchestrator_for_model(app_state, "gemma3:1b")
            assert orchestrator.model_tier == ModelTier.TIER_5_LIMITED

    def test_create_for_claude_opus(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = create_orchestrator_for_model(app_state, "claude-opus-4")
            assert orchestrator.model_tier == ModelTier.TIER_1_ADVANCED


class TestRetryMechanism:
    def test_max_attempts_for_different_tiers(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)

            orchestrator_t5 = IncrementalOrchestrator(
                app_state,
                "test",
                ModelTier.TIER_5_LIMITED,
            )

            spec = ComponentSpec(
                name="test",
                component_type=ComponentType.FUNCTION,
                complexity_score=1,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def test(): pass",
            )
            task = AtomicTask(
                task_id="test",
                description="Test",
                component_spec=spec,
                template=template,
            )

            max_attempts = orchestrator_t5._get_max_attempts_for_task(task)
            assert max_attempts >= 8

    def test_retry_for_complex_task(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = IncrementalOrchestrator(
                app_state,
                "test",
                ModelTier.TIER_5_LIMITED,
            )

            spec = ComponentSpec(
                name="complex",
                component_type=ComponentType.FUNCTION,
                complexity_score=10,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def test(): pass",
            )
            task = AtomicTask(
                task_id="complex",
                description="Complex",
                component_spec=spec,
                template=template,
            )

            max_attempts = orchestrator._get_max_attempts_for_task(task)
            assert max_attempts >= 8


class TestProgressTracking:
    def test_progress_calculation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            from openlaoke.core.architecture.decomposer import FineGrainedDecomposer
            from openlaoke.core.architecture.assembler import CodeAssembler, IntegrationValidator

            workflow = IncrementalWorkflow(
                workflow_id="test",
                project_spec={},
                model="test",
                model_tier=ModelTier.TIER_5_LIMITED,
                decomposer=FineGrainedDecomposer(ModelTier.TIER_5_LIMITED),
                assembler=CodeAssembler(Path(tmpdir)),
                validator=IntegrationValidator(Path(tmpdir)),
            )

            spec = ComponentSpec(
                name="test",
                component_type=ComponentType.FUNCTION,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def test(): pass",
            )

            for i in range(5):
                task = AtomicTask(
                    task_id=f"task{i}",
                    description=f"Task {i}",
                    component_spec=spec,
                    template=template,
                )
                step = WorkflowStep(step_id=f"task{i}", task=task)
                workflow.steps[f"task{i}"] = step

            workflow.completed_steps = ["task0", "task1", "task2"]

            progress = workflow.get_progress()
            assert progress["completed"] == 3
            assert progress["total_steps"] == 5
            assert progress["progress_percentage"] == 60.0


class TestStepExecution:
    def test_get_ready_steps(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            app_state = create_app_state(cwd=tmpdir)
            orchestrator = IncrementalOrchestrator(
                app_state,
                "test",
                ModelTier.TIER_5_LIMITED,
            )

            project_spec = {"modules": [{"name": "test", "dependencies": [], "complexity": 1}]}

            workflow = orchestrator.create_workflow(project_spec)

            ready_steps = orchestrator._get_ready_steps(workflow)
            assert isinstance(ready_steps, list)

    def test_step_dependencies_satisfied(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            from openlaoke.core.architecture.decomposer import FineGrainedDecomposer
            from openlaoke.core.architecture.assembler import CodeAssembler, IntegrationValidator

            workflow = IncrementalWorkflow(
                workflow_id="test",
                project_spec={},
                model="test",
                model_tier=ModelTier.TIER_5_LIMITED,
                decomposer=FineGrainedDecomposer(ModelTier.TIER_5_LIMITED),
                assembler=CodeAssembler(Path(tmpdir)),
                validator=IntegrationValidator(Path(tmpdir)),
            )

            spec = ComponentSpec(
                name="test",
                component_type=ComponentType.FUNCTION,
            )
            template = CodeTemplate(
                name="test",
                description="Test",
                template="def test(): pass",
            )

            task1 = AtomicTask(
                task_id="task1",
                description="Task 1",
                component_spec=spec,
                template=template,
            )
            task2 = AtomicTask(
                task_id="task2",
                description="Task 2",
                component_spec=spec,
                template=template,
                dependencies=["task1"],
            )

            step1 = WorkflowStep(step_id="task1", task=task1)
            step2 = WorkflowStep(step_id="task2", task=task2)

            workflow.steps["task1"] = step1
            workflow.steps["task2"] = step2

            assert step1.step_id not in workflow.completed_steps
