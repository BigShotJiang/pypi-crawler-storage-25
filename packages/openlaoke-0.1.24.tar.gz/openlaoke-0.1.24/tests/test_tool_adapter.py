"""Tests for tool adapter."""

import pytest

from openlaoke.core.tool_adapter import (
    ParsedToolCall,
    ToolCallAdapter,
    create_adapter,
)


class TestToolCallAdapter:
    def test_adapter_creation(self):
        adapter = ToolCallAdapter("gemma3:1b")
        assert adapter.model == "gemma3:1b"

    def test_supports_tools_with_tool_model(self):
        adapter = ToolCallAdapter("gemma4:e2b")
        assert adapter.supports_tools() is True

    def test_supports_tools_with_no_tool_model(self):
        adapter = ToolCallAdapter("gemma3:1b")
        assert adapter.supports_tools() is False

    def test_is_creation_request(self):
        adapter = ToolCallAdapter("gemma3:1b")

        assert adapter.is_creation_request("write a new file")
        assert adapter.is_creation_request("create a program")
        assert adapter.is_creation_request("写一个程序")

    def test_is_not_creation_request(self):
        adapter = ToolCallAdapter("gemma3:1b")

        assert not adapter.is_creation_request("read the file")
        assert not adapter.is_creation_request("list files")
        assert not adapter.is_creation_request("what is this")

    def test_should_skip_context_gathering(self):
        adapter = ToolCallAdapter("gemma3:1b")

        assert adapter.should_skip_context_gathering("write a new program")
        assert adapter.should_skip_context_gathering("create a single file")

    def test_should_not_skip_context_gathering(self):
        adapter = ToolCallAdapter("gemma3:1b")

        assert not adapter.should_skip_context_gathering("modify existing file")
        assert not adapter.should_skip_context_gathering("read the file")
        assert not adapter.should_skip_context_gathering("update the code")

    def test_parse_bash_tool_call(self):
        adapter = ToolCallAdapter("gemma3:1b")

        text = "I will run: `pip install requests`"
        calls = adapter.parse_tool_calls(text)

        assert len(calls) >= 1
        assert calls[0].name == "bash"
        assert "pip install requests" in calls[0].arguments.get("command", "")

    def test_parse_read_tool_call(self):
        adapter = ToolCallAdapter("gemma3:1b")

        text = "Let me read the file config.py"
        calls = adapter.parse_tool_calls(text)

        assert len(calls) >= 1
        assert calls[0].name == "read"
        assert "config.py" in calls[0].arguments.get("file_path", "")

    def test_format_tools_as_text(self):
        adapter = ToolCallAdapter("gemma3:1b")

        tools = [
            {
                "name": "read",
                "description": "Read a file",
                "input_schema": {
                    "type": "object",
                    "properties": {"file_path": {"type": "string", "description": "File path"}},
                    "required": ["file_path"],
                },
            }
        ]

        formatted = adapter.format_tools_as_text(tools)
        assert "read" in formatted.lower()
        assert "file" in formatted.lower()

    def test_format_tools_skipped_for_tool_models(self):
        adapter = ToolCallAdapter("gemma4:e2b")

        tools = [{"name": "test", "description": "Test", "input_schema": {}}]
        formatted = adapter.format_tools_as_text(tools)

        assert formatted == ""


class TestCreateAdapter:
    def test_create_adapter(self):
        adapter = create_adapter("gemma3:1b")
        assert isinstance(adapter, ToolCallAdapter)
        assert adapter.model == "gemma3:1b"


class TestCreationKeywords:
    def test_english_creation_keywords(self):
        adapter = ToolCallAdapter("test")

        for kw in ["write", "create", "make", "generate", "build", "implement"]:
            assert adapter.is_creation_request(f"{kw} something new")

    def test_chinese_creation_keywords(self):
        adapter = ToolCallAdapter("test")

        for kw in ["写", "创建", "生成", "实现", "编写"]:
            assert adapter.is_creation_request(f"{kw}一个程序")


class TestNewFileIndicators:
    def test_new_file_indicators(self):
        adapter = ToolCallAdapter("test")

        assert adapter.is_creation_request("create a new file")
        assert adapter.is_creation_request("write a single file program")
        assert adapter.is_creation_request("build a standalone application")


class TestParsedToolCall:
    def test_parsed_tool_call_creation(self):
        call = ParsedToolCall(
            name="bash",
            arguments={"command": "ls"},
            confidence=0.9,
            raw_text="run: `ls`",
        )
        assert call.name == "bash"
        assert call.arguments["command"] == "ls"
        assert call.confidence == 0.9
