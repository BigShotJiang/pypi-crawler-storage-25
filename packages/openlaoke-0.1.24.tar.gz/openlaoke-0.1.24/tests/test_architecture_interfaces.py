"""Tests for architecture system - interfaces."""

import pytest

from openlaoke.core.architecture.interfaces import (
    APISpec,
    CodeTemplate,
    ComponentSpec,
    ComponentType,
    TaskSize,
    STANDARD_TEMPLATES,
    STANDARD_API_SPECS,
    get_template_for_component,
    estimate_task_complexity,
    should_decompose_for_model,
)


class TestComponentType:
    def test_component_type_values(self):
        assert ComponentType.FUNCTION.value == "function"
        assert ComponentType.CLASS.value == "class"
        assert ComponentType.MODULE.value == "module"
        assert ComponentType.API_ENDPOINT.value == "api_endpoint"
        assert ComponentType.DATA_MODEL.value == "data_model"
        assert ComponentType.TEST.value == "test"


class TestTaskSize:
    def test_task_size_values(self):
        assert TaskSize.ATOMIC.value == "atomic"
        assert TaskSize.SMALL.value == "small"
        assert TaskSize.MEDIUM.value == "medium"
        assert TaskSize.LARGE.value == "large"


class TestCodeTemplate:
    def test_template_creation(self):
        template = CodeTemplate(
            name="test_template",
            description="Test template",
            template="def {name}(): pass",
            required_imports=["import os"],
            validation_rules=["Must have type hints"],
        )
        assert template.name == "test_template"
        assert template.description == "Test template"
        assert len(template.required_imports) == 1
        assert len(template.validation_rules) == 1


class TestAPISpec:
    def test_api_spec_creation(self):
        api = APISpec(
            name="test_api",
            description="Test API",
            input_schema={"type": "object", "properties": {"x": {"type": "int"}}},
            output_schema={"type": "object", "properties": {"result": {"type": "int"}}},
            error_codes={"E001": "Error 1"},
            version="1.0.0",
        )
        assert api.name == "test_api"
        assert api.version == "1.0.0"
        assert "E001" in api.error_codes

    def test_api_spec_with_examples(self):
        api = APISpec(
            name="test",
            description="Test",
            input_schema={},
            output_schema={},
            examples=[{"input": 1, "output": 2}],
        )
        assert len(api.examples) == 1


class TestComponentSpec:
    def test_component_spec_basic(self):
        spec = ComponentSpec(
            name="test_function",
            component_type=ComponentType.FUNCTION,
            complexity_score=3,
        )
        assert spec.name == "test_function"
        assert spec.component_type == ComponentType.FUNCTION
        assert spec.complexity_score == 3
        assert spec.test_requirements == []
        assert spec.dependencies == []

    def test_component_spec_with_requirements(self):
        spec = ComponentSpec(
            name="test_class",
            component_type=ComponentType.CLASS,
            test_requirements=["unit test", "integration test"],
            dependencies=["module_a", "module_b"],
        )
        assert len(spec.test_requirements) == 2
        assert len(spec.dependencies) == 2


class TestStandardTemplates:
    def test_standard_templates_exist(self):
        assert "function_basic" in STANDARD_TEMPLATES
        assert "class_basic" in STANDARD_TEMPLATES
        assert "api_endpoint" in STANDARD_TEMPLATES
        assert "data_model" in STANDARD_TEMPLATES
        assert "test_function" in STANDARD_TEMPLATES

    def test_function_template(self):
        template = STANDARD_TEMPLATES["function_basic"]
        assert "{function_name}" in template.template
        assert "{parameters}" in template.template
        assert "{return_type}" in template.template
        assert "from __future__ import annotations" in template.required_imports

    def test_class_template(self):
        template = STANDARD_TEMPLATES["class_basic"]
        assert "{class_name}" in template.template
        assert "__init__" in template.template

    def test_api_endpoint_template(self):
        template = STANDARD_TEMPLATES["api_endpoint"]
        assert "@router" in template.template
        assert "response_model" in template.template
        assert "fastapi" in " ".join(template.required_dependencies)


class TestStandardAPISpecs:
    def test_standard_api_specs_exist(self):
        assert "tool_call" in STANDARD_API_SPECS
        assert "state_update" in STANDARD_API_SPECS
        assert "component_assembly" in STANDARD_API_SPECS

    def test_tool_call_spec(self):
        spec = STANDARD_API_SPECS["tool_call"]
        assert spec.name == "tool_call"
        assert "name" in spec.input_schema["properties"]
        assert "arguments" in spec.input_schema["properties"]
        assert "success" in spec.output_schema["properties"]


class TestGetTemplateForComponent:
    def test_get_function_template(self):
        template = get_template_for_component(ComponentType.FUNCTION)
        assert template.name == "function_basic"

    def test_get_class_template(self):
        template = get_template_for_component(ComponentType.CLASS)
        assert template.name == "class_basic"

    def test_get_api_endpoint_template(self):
        template = get_template_for_component(ComponentType.API_ENDPOINT)
        assert template.name == "api_endpoint"

    def test_get_data_model_template(self):
        template = get_template_for_component(ComponentType.DATA_MODEL)
        assert template.name == "data_model"

    def test_get_test_template(self):
        template = get_template_for_component(ComponentType.TEST)
        assert template.name == "test_function"


class TestEstimateTaskComplexity:
    def test_simple_task(self):
        spec = ComponentSpec(
            name="simple_func",
            component_type=ComponentType.FUNCTION,
            complexity_score=1,
        )
        size = estimate_task_complexity(spec)
        assert size == TaskSize.ATOMIC

    def test_medium_task(self):
        spec = ComponentSpec(
            name="medium_func",
            component_type=ComponentType.FUNCTION,
            complexity_score=5,
            dependencies=["a", "b", "c", "d", "e", "f"],
        )
        size = estimate_task_complexity(spec)
        assert size in [TaskSize.SMALL, TaskSize.MEDIUM, TaskSize.LARGE]

    def test_complex_task_with_api(self):
        spec = ComponentSpec(
            name="complex_api",
            component_type=ComponentType.API_ENDPOINT,
            complexity_score=8,
            api_spec=APISpec(
                name="complex",
                description="Complex API",
                input_schema={"properties": {f"param_{i}": {"type": "int"} for i in range(8)}},
                output_schema={},
            ),
        )
        size = estimate_task_complexity(spec)
        assert size in [TaskSize.MEDIUM, TaskSize.LARGE]


class TestShouldDecomposeForModel:
    def test_tier5_needs_decomposition_for_medium(self):
        should = should_decompose_for_model(TaskSize.MEDIUM, "tier_5_limited")
        assert should is True

    def test_tier5_needs_decomposition_for_large(self):
        should = should_decompose_for_model(TaskSize.LARGE, "tier_5_limited")
        assert should is True

    def test_tier5_no_decomposition_for_atomic(self):
        should = should_decompose_for_model(TaskSize.ATOMIC, "tier_5_limited")
        assert should is False

    def test_tier5_no_decomposition_for_small(self):
        should = should_decompose_for_model(TaskSize.SMALL, "tier_5_limited")
        assert should is False

    def test_tier4_needs_decomposition_for_large(self):
        should = should_decompose_for_model(TaskSize.LARGE, "tier_4_basic")
        assert should is True

    def test_tier4_no_decomposition_for_medium(self):
        should = should_decompose_for_model(TaskSize.MEDIUM, "tier_4_basic")
        assert should is False

    def test_tier1_no_decomposition(self):
        should = should_decompose_for_model(TaskSize.LARGE, "tier_1_advanced")
        assert should is False


class TestComponentSpecValidation:
    def test_spec_with_all_fields(self):
        spec = ComponentSpec(
            name="complete_component",
            component_type=ComponentType.FUNCTION,
            api_spec=APISpec(
                name="api",
                description="API",
                input_schema={},
                output_schema={},
            ),
            dependencies=["dep1", "dep2"],
            test_requirements=["test1", "test2"],
            complexity_score=5,
        )
        assert spec.api_spec is not None
        assert len(spec.dependencies) == 2
        assert len(spec.test_requirements) == 2
