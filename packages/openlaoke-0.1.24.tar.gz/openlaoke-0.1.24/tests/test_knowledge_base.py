"""Tests for knowledge base system."""

import pytest

from openlaoke.core.knowledge_base import (
    KnowledgeBase,
    KnowledgeSnippet,
    create_knowledge_base,
)


class TestKnowledgeSnippet:
    def test_snippet_creation(self):
        snippet = KnowledgeSnippet(
            topic="Python",
            content="Python is a programming language",
            source="Docs",
            tags=["programming", "language"],
        )
        assert snippet.topic == "Python"
        assert snippet.tags == ["programming", "language"]


class TestKnowledgeBase:
    def test_knowledge_base_creation(self):
        kb = KnowledgeBase()
        assert kb is not None
        assert len(kb.knowledge_cache) > 0

    def test_builtin_knowledge_loaded(self):
        kb = KnowledgeBase()

        assert "cpu_benchmark" in kb.knowledge_cache
        assert "file_operations" in kb.knowledge_cache
        assert "python_syntax" in kb.knowledge_cache

    def test_search_cpu_benchmark(self):
        kb = KnowledgeBase()

        results = kb.search("write a CPU benchmark program")
        assert len(results) > 0
        assert any("cpu" in r.tags for r in results)

    def test_search_file_operations(self):
        kb = KnowledgeBase()

        results = kb.search("how to write a file")
        assert len(results) > 0

    def test_search_python_syntax(self):
        kb = KnowledgeBase()

        results = kb.search("python syntax error")
        assert len(results) > 0

    def test_search_no_results(self):
        kb = KnowledgeBase()

        results = kb.search("xyzabc123 nonexistent topic")
        assert len(results) == 0

    def test_enhance_prompt_with_knowledge(self):
        kb = KnowledgeBase()

        enhanced = kb.enhance_prompt("write CPU benchmark", "You are helpful.")

        assert "RELEVANT KNOWLEDGE BASE" in enhanced
        assert "CPU" in enhanced

    def test_enhance_prompt_no_knowledge(self):
        kb = KnowledgeBase()

        enhanced = kb.enhance_prompt("xyzabc123", "You are helpful.")

        assert enhanced == "You are helpful."

    def test_search_returns_max_results(self):
        kb = KnowledgeBase()

        results = kb.search("python", max_results=2)
        assert len(results) <= 2


class TestCreateKnowledgeBase:
    def test_create_knowledge_base(self):
        kb = create_knowledge_base()
        assert isinstance(kb, KnowledgeBase)


class TestKnowledgeRelevance:
    def test_relevance_scoring(self):
        kb = KnowledgeBase()

        results = kb.search("CPU performance benchmark calculation")

        assert len(results) > 0
        first = results[0]
        assert "cpu" in first.tags or "benchmark" in first.tags

    def test_multiple_keywords(self):
        kb = KnowledgeBase()

        results = kb.search("python file write error")

        assert len(results) > 0
        # Should return relevant snippets
        topics = [r.topic.lower() for r in results]
        has_file = any("file" in t for t in topics)
        has_syntax = any("syntax" in t or "error" in t for t in topics)
        assert has_file or has_syntax


class TestKnowledgeContent:
    def test_cpu_benchmark_has_example_code(self):
        kb = KnowledgeBase()
        snippet = kb.knowledge_cache["cpu_benchmark"]

        assert "```" in snippet.content
        assert "multiprocessing" in snippet.content

    def test_python_syntax_has_common_errors(self):
        kb = KnowledgeBase()
        snippet = kb.knowledge_cache["python_syntax"]

        assert "SyntaxError" in snippet.content
        assert "Wrong" in snippet.content
        assert "Correct" in snippet.content
