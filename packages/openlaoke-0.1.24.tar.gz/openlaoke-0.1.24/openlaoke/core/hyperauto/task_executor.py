"""Execute HyperAuto tasks with tool calling support."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from openlaoke.core.hyperauto.executor import ToolExecutor
from openlaoke.core.hyperauto.types import SubTask

if TYPE_CHECKING:
    from openlaoke.core.state import AppState


async def execute_task_with_tools(
    app_state: AppState,
    task: SubTask,
    original_request: str,
    max_iterations: int = 10,
    on_progress_callback: Any = None,
    workflow_context: Any = None,
) -> dict[str, Any]:
    """Execute a task using AI with tool calling capability."""
    from openlaoke.core.multi_provider_api import MultiProviderClient

    if app_state.multi_provider_config:
        api_client = MultiProviderClient(app_state.multi_provider_config)
        model = app_state.multi_provider_config.get_active_model()
    else:
        from openlaoke.types.providers import MultiProviderConfig

        config = MultiProviderConfig.defaults()
        api_client = MultiProviderClient(config)
        model = "gemma3:1b"

    executor = ToolExecutor(app_state)
    tool_schemas = await executor.get_tool_schemas()

    system_prompt = f"""You are an AI coding assistant executing a SPECIFIC sub-task.

Overall goal: {original_request}

Your current sub-task: {task.name}
Sub-task description: {task.description}

CRITICAL INSTRUCTIONS:
1. This sub-task is part of a larger workflow - you MUST complete THIS specific sub-task
2. If task.name contains a specific file/module name, you MUST create that exact file
3. Do NOT stop after creating just one example file - complete what THIS sub-task requires
4. Use Write tool to create complete, functional code files
5. Use Bash (mkdir) to create directories first if needed
6. If this is a translation task, read source files and write complete translated versions
7. Do NOT just create placeholders - create REAL, WORKING implementations

Available tools: {", ".join([t["name"] for t in tool_schemas[:10]])}

IMPORTANT: Your goal is to complete THIS specific sub-task fully, not partially. Do not stop early."""

    messages = [
        {
            "role": "user",
            "content": f"Execute this sub-task:\n\nSub-task: {task.name}\nDescription: {task.description}\nContext: {original_request}\n\nCreate the actual files/code required for this sub-task.",
        }
    ]

    iteration = 0
    total_tokens = 0
    all_results: list[dict[str, Any]] = []

    while iteration < max_iterations:
        iteration += 1

        try:
            response_msg, token_usage, _ = await api_client.send_message(
                system_prompt=system_prompt,
                messages=messages,
                tools=tool_schemas,
                model=model,
                max_tokens=4000,
            )

            if token_usage:
                total_tokens += token_usage.total_tokens
                if workflow_context:
                    workflow_context.total_tokens += token_usage.total_tokens
                if on_progress_callback:
                    on_progress_callback(workflow_context)

            tool_uses = []
            if hasattr(response_msg, "tool_uses") and response_msg.tool_uses:
                tool_uses = response_msg.tool_uses

            tool_calls = []
            for tool_use in tool_uses:
                tool_calls.append(
                    {"name": tool_use.name, "input": tool_use.input, "id": tool_use.id}
                )

            if not tool_calls:
                final_text = ""
                if hasattr(response_msg, "content"):
                    if isinstance(response_msg.content, str):
                        final_text = response_msg.content
                    elif hasattr(response_msg.content, "text"):
                        final_text = response_msg.content.text

                return {
                    "success": True,
                    "iterations": iteration,
                    "tokens": total_tokens,
                    "tool_results": all_results,
                    "final_response": final_text,
                }

            for tool_call in tool_calls:
                tool_name: str = ""
                tool_input_dict: dict[str, Any] = {}
                input_data: Any = {}
                if isinstance(tool_call, dict):
                    func_data = tool_call.get("function", {})
                    if isinstance(func_data, dict):
                        name_val = tool_call.get("name")
                        tool_name = str(name_val) if name_val else str(func_data.get("name", ""))
                        input_data = tool_call.get("input") or func_data.get("arguments", {})
                else:
                    tool_name = str(getattr(tool_call, "name", ""))
                    input_data = getattr(tool_call, "input", getattr(tool_call, "arguments", {}))

                if isinstance(input_data, str):
                    try:
                        tool_input_dict = json.loads(input_data)
                    except json.JSONDecodeError:
                        tool_input_dict = {}
                elif isinstance(input_data, dict):
                    tool_input_dict = input_data

                result = await executor.execute_tool(tool_name, tool_input_dict)

                result_text = (
                    result.content
                    if isinstance(result.content, str)
                    else json.dumps(result.content)
                )

                all_results.append(
                    {
                        "tool": tool_name,
                        "input": tool_input_dict,
                        "result": result_text[:1000],
                        "is_error": result.is_error,
                    }
                )

                messages.append(
                    {
                        "role": "assistant",
                        "content": "",
                        "tool_calls": json.dumps(
                            [
                                {
                                    "id": f"call_{iteration}_{tool_name}",
                                    "type": "function",
                                    "function": {
                                        "name": tool_name,
                                        "arguments": json.dumps(tool_input_dict),
                                    },
                                }
                            ]
                        ),
                    }
                )

                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": f"call_{iteration}_{tool_name}",
                        "content": result_text[:2000],
                    }
                )

        except Exception:
            break

    return {
        "success": True,
        "iterations": iteration,
        "tokens": total_tokens,
        "tool_results": all_results,
        "completed": iteration >= max_iterations,
    }
