"""Extended Web API implementations for various providers.

This module provides API clients for different web-based AI services
using browser authentication cookies.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any

import httpx
from rich.console import Console

console = Console()


class BaseWebProvider(ABC):
    """Base class for web-based AI providers."""
    
    @property
    @abstractmethod
    def provider_type(self) -> str:
        """Return provider type identifier."""
        pass
    
    @property
    @abstractmethod
    def base_url(self) -> str:
        """Return base URL."""
        pass
    
    @property
    @abstractmethod
    def api_endpoint(self) -> str:
        """Return API endpoint URL."""
        pass
    
    @abstractmethod
    def build_headers(self, cookie: str, user_agent: str) -> dict[str, str]:
        """Build HTTP headers for API requests."""
        pass
    
    @abstractmethod
    def build_payload(
        self,
        messages: list[dict[str, str]],
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> dict[str, Any]:
        """Build request payload."""
        pass
    
    @abstractmethod
    def parse_response(self, data: dict[str, Any]) -> dict[str, Any]:
        """Parse API response."""
        pass


class DeepSeekProvider(BaseWebProvider):
    """DeepSeek Web API provider."""
    
    @property
    def provider_type(self) -> str:
        return "deepseek-chat"
    
    @property
    def base_url(self) -> str:
        return "https://chat.deepseek.com"
    
    @property
    def api_endpoint(self) -> str:
        return f"{self.base_url}/api/v1/chat/completions"
    
    def build_headers(self, cookie: str, user_agent: str) -> dict[str, str]:
        return {
            "Cookie": cookie,
            "User-Agent": user_agent,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Referer": f"{self.base_url}/",
            "Origin": self.base_url,
            "x-client-platform": "web",
            "x-client-version": "1.7.0",
        }
    
    def build_payload(
        self,
        messages: list[dict[str, str]],
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> dict[str, Any]:
        return {
            "model": model or "deepseek-chat",
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
    
    def parse_response(self, data: dict[str, Any]) -> dict[str, Any]:
        choices = data.get("choices", [])
        if not choices:
            return {"content": "", "error": "No choices"}
        
        choice = choices[0]
        message = choice.get("message", {})
        content = message.get("content", "")
        
        return {
            "content": content,
            "model": data.get("model", "deepseek-chat"),
            "usage": data.get("usage", {}),
            "finish_reason": choice.get("finish_reason", "stop"),
        }


class QwenProvider(BaseWebProvider):
    """Qwen Web (通义千问) API provider."""
    
    @property
    def provider_type(self) -> str:
        return "qwen-web"
    
    @property
    def base_url(self) -> str:
        return "https://tongyi.aliyun.com"
    
    @property
    def api_endpoint(self) -> str:
        return f"{self.base_url}/api/chat"
    
    def build_headers(self, cookie: str, user_agent: str) -> dict[str, str]:
        return {
            "Cookie": cookie,
            "User-Agent": user_agent,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Referer": f"{self.base_url}/",
            "Origin": self.base_url,
        }
    
    def build_payload(
        self,
        messages: list[dict[str, str]],
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> dict[str, Any]:
        return {
            "model": model or "qwen-turbo",
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
    
    def parse_response(self, data: dict[str, Any]) -> dict[str, Any]:
        # Qwen response format
        content = data.get("content", "")
        if not content:
            content = data.get("data", {}).get("content", "")
        
        return {
            "content": content,
            "model": data.get("model", "qwen-turbo"),
            "usage": data.get("usage", {}),
            "finish_reason": data.get("finish_reason", "stop"),
        }


class KimiProvider(BaseWebProvider):
    """Kimi Web (月之暗面) API provider."""
    
    @property
    def provider_type(self) -> str:
        return "kimi-web"
    
    @property
    def base_url(self) -> str:
        return "https://kimi.moonshot.cn"
    
    @property
    def api_endpoint(self) -> str:
        return f"{self.base_url}/api/chat"
    
    def build_headers(self, cookie: str, user_agent: str) -> dict[str, str]:
        return {
            "Cookie": cookie,
            "User-Agent": user_agent,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Referer": f"{self.base_url}/",
            "Origin": self.base_url,
        }
    
    def build_payload(
        self,
        messages: list[dict[str, str]],
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> dict[str, Any]:
        return {
            "model": model or "kimi",
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
    
    def parse_response(self, data: dict[str, Any]) -> dict[str, Any]:
        content = data.get("content", "")
        return {
            "content": content,
            "model": data.get("model", "kimi"),
            "usage": data.get("usage", {}),
            "finish_reason": data.get("finish_reason", "stop"),
        }


# Provider registry
PROVIDERS: dict[str, BaseWebProvider] = {
    "deepseek-chat": DeepSeekProvider(),
    "deepseek-coder": DeepSeekProvider(),
    "qwen-web": QwenProvider(),
    "kimi-web": KimiProvider(),
}


class ExtendedWebClient:
    """Unified client for Extended Web providers."""
    
    def __init__(self, provider_type: str) -> None:
        """Initialize the client.
        
        Args:
            provider_type: Provider type (e.g., 'deepseek-chat')
        """
        self.provider_type = provider_type
        
        # Get provider implementation
        provider_impl = PROVIDERS.get(provider_type)
        if not provider_impl:
            # Use DeepSeek as default for unknown providers
            provider_impl = DeepSeekProvider()
        
        self.provider = provider_impl
        self._client: httpx.AsyncClient | None = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client with auth."""
        if self._client is None:
            from openlaoke.core.extended_web import BrowserAuthManager
            
            auth_manager = BrowserAuthManager()
            auth_data = auth_manager.load_auth(self.provider_type)
            
            if not auth_data:
                raise ValueError(
                    f"No authentication found for {self.provider_type}. "
                    f"Run: python3 quick_auth.py {self.provider_type}"
                )
            
            cookie = auth_data.get("cookie", "")
            user_agent = auth_data.get("user_agent", "")
            
            headers = self.provider.build_headers(cookie, user_agent)
            
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(300.0, connect=30.0),
                headers=headers,
            )
        
        return self._client
    
    async def close(self) -> None:
        """Close the client."""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    async def chat(
        self,
        messages: list[dict[str, str]],
        model: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict[str, Any]:
        """Send chat request.
        
        Args:
            messages: Chat messages
            model: Model to use
            temperature: Temperature
            max_tokens: Max tokens
            
        Returns:
            Response dict
        """
        client = await self._get_client()
        
        payload = self.provider.build_payload(
            messages, model, temperature, max_tokens
        )
        
        response = await client.post(
            self.provider.api_endpoint,
            json=payload,
        )
        
        if response.status_code >= 400:
            error_msg = response.text[:500]
            raise httpx.HTTPStatusError(
                f"{self.provider_type} API error: {response.status_code}\n{error_msg}",
                request=response.request,
                response=response,
            )
        
        data = response.json()
        return self.provider.parse_response(data)
