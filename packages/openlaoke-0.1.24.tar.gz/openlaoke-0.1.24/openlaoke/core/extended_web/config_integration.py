"""Integration of auto cookie extraction into config wizard."""

from __future__ import annotations

from rich.console import Console

from .auto_cookie_extractor import extract_cookie_with_playwright
from .firefox_cookie_reader import extract_firefox_cookies
from .browser_auth import BrowserAuthManager
from .types import WEB_PROVIDERS

console = Console()


async def extract_cookie_in_wizard(service: str) -> bool:
    """Extract cookie for a service within the config wizard.

    Args:
        service: Service type (e.g., 'deepseek-chat')

    Returns:
        True if successful
    """
    import asyncio

    config = WEB_PROVIDERS.get(service)
    if not config:
        console.print(f"[red]Unknown service: {service}[/red]")
        return False

    console.print()
    console.print("[bold cyan]════════════════════════════════════════[/bold cyan]")
    console.print(f"[bold cyan]  {config.name} Authentication[/bold cyan]")
    console.print("[bold cyan]════════════════════════════════════════[/bold cyan]")
    console.print()
    console.print(f"[dim]Login URL: [cyan]{config.login_url}[/cyan][/dim]")
    console.print()

    # First, try to read cookies directly from Firefox (if user is already logged in)
    console.print("[bold]Step 1: Checking Firefox for existing cookies...[/bold]")
    auth_data = await extract_firefox_cookies(service)

    if auth_data and auth_data.get("cookie"):
        auth_manager = BrowserAuthManager()
        auth_manager.save_auth(service, auth_data)
        console.print()
        console.print("[green]✓ Authentication successful! (from Firefox)[/green]")
        console.print(f"  Cookie saved to: ~/.openlaoke/extended_web/{service}.json")
        return True

    # If Firefox didn't have cookies, launch browser for manual login
    console.print()
    console.print("[bold]Step 2: Launching browser for login...[/bold]")
    console.print()
    console.print("  [dim]1. A browser window will open automatically[/dim]")
    console.print(
        f"  [dim]2. Navigate to: [cyan underline]{config.login_url}[/cyan underline][/dim]"
    )
    console.print("  [dim]3. Login with your account[/dim]")
    console.print("  [dim]4. Wait for the chat interface to load[/dim]")
    console.print("  [dim]5. Cookie will be extracted automatically[/dim]")
    console.print()

    # Run async extraction (browser launches automatically)
    auth_data = await extract_cookie_with_playwright(service, timeout=300)

    if auth_data:
        console.print()
        console.print("[green]✓ Authentication successful![/green]")
        console.print(f"  Cookie saved to: ~/.openlaoke/extended_web/{service}.json")
        return True
    else:
        console.print()
        console.print("[yellow]⚠ Authentication failed[/yellow]")
        console.print("[dim]You can try again later or use manual extraction[/dim]")
        return False
