"""Extended Web API client.

This client handles API calls for Extended Web providers using
saved browser authentication cookies.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
from rich.console import Console

console = Console()


class ExtendedWebAPIClient:
    """API client for Extended Web providers."""
    
    def __init__(self, provider_type: str) -> None:
        """Initialize the API client.
        
        Args:
            provider_type: Provider type (e.g., 'deepseek-chat')
        """
        self.provider_type = provider_type
        self._client: httpx.AsyncClient | None = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client with auth headers."""
        if self._client is None:
            from openlaoke.core.extended_web import BrowserAuthManager
            from openlaoke.core.extended_web.types import WEB_PROVIDERS
            
            auth_manager = BrowserAuthManager()
            auth_data = auth_manager.load_auth(self.provider_type)
            
            if not auth_data:
                raise ValueError(
                    f"No authentication found for {self.provider_type}. "
                    f"Run: openlaoke auth extended-web login {self.provider_type}"
                )
            
            web_config = WEB_PROVIDERS.get(self.provider_type)
            if not web_config:
                raise ValueError(f"Unknown provider: {self.provider_type}")
            
            # Build headers
            headers = {
                "Cookie": auth_data.get("cookie", ""),
                "User-Agent": auth_data.get("user_agent", ""),
                "Content-Type": "application/json",
                "Accept": "*/*",
                "Referer": web_config.base_url + "/",
                "Origin": web_config.base_url,
                **web_config.custom_headers,
            }
            
            if auth_data.get("bearer_token"):
                headers["Authorization"] = f"Bearer {auth_data['bearer_token']}"
            
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(300.0, connect=30.0),
                headers=headers,
            )
        
        return self._client
    
    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    async def chat_completions(
        self,
        messages: list[dict[str, str]],
        model: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stream: bool = False,
    ) -> dict[str, Any]:
        """Send chat completion request.
        
        Args:
            messages: List of chat messages
            model: Model to use
            temperature: Temperature for sampling
            max_tokens: Maximum tokens to generate
            stream: Whether to stream response
            
        Returns:
            Response dict with content and metadata
        """
        from openlaoke.core.extended_web.types import WEB_PROVIDERS
        
        web_config = WEB_PROVIDERS.get(self.provider_type)
        if not web_config:
            raise ValueError(f"Unknown provider: {self.provider_type}")
        
        client = await self._get_client()
        
        # Build request payload (OpenAI-compatible format)
        payload = {
            "model": model or self.provider_type,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        
        try:
            response = await client.post(
                web_config.api_endpoint,
                json=payload,
            )
            
            if response.status_code >= 400:
                error_detail = response.text[:500]
                raise httpx.HTTPStatusError(
                    f"{self.provider_type} API error: {response.status_code}\n{error_detail}",
                    request=response.request,
                    response=response,
                )
            
            # Parse response (OpenAI-compatible format)
            data = response.json()
            choices = data.get("choices", [])
            
            if not choices:
                return {"content": "", "error": "No choices in response"}
            
            choice = choices[0]
            message = choice.get("message", {})
            content = message.get("content", "")
            
            return {
                "content": content,
                "model": data.get("model", model or self.provider_type),
                "usage": data.get("usage", {}),
                "finish_reason": choice.get("finish_reason", "stop"),
            }
            
        except httpx.HTTPStatusError as e:
            console.print(f"[red]API Error:[/red] {e}")
            raise
        except Exception as e:
            console.print(f"[red]Request Error:[/red] {e}")
            raise
    
    async def chat_completions_stream(
        self,
        messages: list[dict[str, str]],
        model: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> Any:
        """Send streaming chat completion request.
        
        Yields:
            Text deltas from the stream
        """
        from openlaoke.core.extended_web.types import WEB_PROVIDERS
        
        web_config = WEB_PROVIDERS.get(self.provider_type)
        if not web_config:
            raise ValueError(f"Unknown provider: {self.provider_type}")
        
        client = await self._get_client()
        
        payload = {
            "model": model or self.provider_type,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
        }
        
        async with client.stream(
            "POST",
            web_config.api_endpoint,
            json=payload,
        ) as response:
            response.raise_for_status()
            
            async for line in response.aiter_lines():
                if not line:
                    continue
                
                if line.startswith("data: "):
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    
                    try:
                        data = json.loads(data_str)
                        choices = data.get("choices", [])
                        if choices:
                            delta = choices[0].get("delta", {})
                            content = delta.get("content", "")
                            if content:
                                yield content
                    except json.JSONDecodeError:
                        continue
