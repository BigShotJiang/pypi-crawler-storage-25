"""Extract cookies directly from Firefox browser database.

This module reads cookies from Firefox's SQLite database, eliminating the need
for users to log in again in a separate browser window.
"""

from __future__ import annotations

import os
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

from rich.console import Console

console = Console()


def get_firefox_profiles_dir() -> Path | None:
    """Get Firefox profiles directory based on OS."""
    if sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / "Firefox" / "Profiles"
    elif sys.platform == "win32":
        base = Path.home() / "AppData" / "Roaming" / "Mozilla" / "Firefox" / "Profiles"
    else:
        base = Path.home() / ".mozilla" / "firefox" / "Profiles"

    if not base.exists():
        return None
    return base


def get_firefox_profile() -> Path | None:
    """Get the default Firefox profile directory with the most cookies."""
    profiles_dir = get_firefox_profiles_dir()
    if not profiles_dir:
        return None

    profiles = list(profiles_dir.iterdir())
    if not profiles:
        return None

    # Prefer default-release profile, then any default profile
    best_profile = None
    best_count = 0

    for profile in profiles:
        if not profile.is_dir():
            continue

        cookie_db = profile / "cookies.sqlite"
        if not cookie_db.exists():
            continue

        # Try to count cookies by copying to temp file (avoid lock)
        try:
            with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as tmp:
                tmp_path = tmp.name
            shutil.copy2(str(cookie_db), tmp_path)

            conn = sqlite3.connect(tmp_path)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM moz_cookies")
            count = cursor.fetchone()[0]
            conn.close()
            os.unlink(tmp_path)

            if count > best_count:
                best_count = count
                best_profile = profile
        except Exception:
            pass

    return best_profile


def extract_cookies_from_firefox(domains: list[str]) -> dict[str, str]:
    """Extract cookies for domains from Firefox.

    Args:
        domains: List of domains to extract cookies for

    Returns:
        Dict of cookie names to values
    """
    profile = get_firefox_profile()
    if not profile:
        console.print("[yellow]No Firefox profile found[/yellow]")
        return {}

    cookie_db = profile / "cookies.sqlite"
    if not cookie_db.exists():
        console.print(f"[yellow]No cookies.sqlite found in {profile}[/yellow]")
        return {}

    cookies = {}

    # Copy to temp file to avoid database lock
    try:
        with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as tmp:
            tmp_path = tmp.name

        shutil.copy2(str(cookie_db), tmp_path)

        conn = sqlite3.connect(tmp_path)
        cursor = conn.cursor()

        for domain in domains:
            # Remove leading dot if present
            clean_domain = domain.lstrip(".")

            cursor.execute(
                """
                SELECT name, value
                FROM moz_cookies
                WHERE host LIKE ?
                """,
                (f"%{clean_domain}%",),
            )

            for name, value in cursor.fetchall():
                if value:  # Only include cookies with values
                    cookies[name] = value

        conn.close()
        os.unlink(tmp_path)

    except sqlite3.Error as e:
        console.print(f"[red]Error reading Firefox cookies: {e}[/red]")
        return {}
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        return {}

    return cookies


async def extract_firefox_cookies(service: str) -> dict | None:
    """Extract cookies from Firefox for a given service.

    Args:
        service: Service type (e.g., 'deepseek-chat', 'qwen-web', 'glm-web')

    Returns:
        Auth data dict or None
    """
    from .types import WEB_PROVIDERS

    config = WEB_PROVIDERS.get(service)
    if not config:
        console.print(f"[red]Unknown service: {service}[/red]")
        return None

    console.print(f"[cyan]Reading cookies from Firefox for {config.name}...[/cyan]")

    domains = config.cookie_domains
    console.print(f"[dim]Looking for cookies from: {domains}[/dim]")
    console.print(f"[dim]Required cookies: {config.required_cookies}[/dim]")

    cookies = extract_cookies_from_firefox(domains)

    if not cookies:
        console.print("[yellow]No cookies found in Firefox for this domain[/yellow]")
        console.print("[dim]Make sure you are logged into the website in Firefox[/dim]")
        return None

    console.print(f"[green]Found {len(cookies)} cookies[/green]")

    # Build cookie string with ALL cookies
    cookie_string = "; ".join(f"{name}={value}" for name, value in cookies.items())

    auth_data = {
        "provider_type": service,
        "cookie": cookie_string,
        "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "saved_at": "2026-04-08T00:00:00",
        "browser": "firefox-direct",
    }

    return auth_data


if __name__ == "__main__":
    import asyncio

    if len(sys.argv) < 2:
        print("Usage: python firefox_cookie_reader.py <service>")
        print("Services: deepseek-chat, qwen-web, glm-web, kimi-web")
        sys.exit(1)

    service = sys.argv[1]

    async def main():
        result = await extract_firefox_cookies(service)
        if result:
            print("\n[green]Success![/green]")
            print(f"Cookie length: {len(result['cookie'])}")
        else:
            print("\n[red]Failed to extract cookies[/red]")

    asyncio.run(main())
