"""Base class for Extended Web clients."""

from __future__ import annotations

from abc import ABC, abstractmethod


class BaseWebClient(ABC):
    """Base class for web-based AI service clients."""

    def __init__(
        self,
        cookie: str,
        user_agent: str = "",
        bearer_token: str = "",
    ) -> None:
        """Initialize the web client.

        Args:
            cookie: Browser cookies
            user_agent: User agent string
            bearer_token: Optional bearer token
        """
        self.cookie = cookie
        self.user_agent = user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        self.bearer_token = bearer_token
        self._initialized = False

    @property
    @abstractmethod
    def provider_type(self) -> str:
        """Return provider type identifier."""
        pass

    @property
    @abstractmethod
    def base_url(self) -> str:
        """Return base URL."""
        pass

    @property
    @abstractmethod
    def api_endpoint(self) -> str:
        """Return API endpoint URL."""
        pass

    @abstractmethod
    def build_headers(self) -> dict[str, str]:
        """Build HTTP headers for API requests."""
        pass

    async def init(self) -> None:
        """Initialize the client. Override if needed."""
        self._initialized = True

    def is_initialized(self) -> bool:
        """Check if client is initialized."""
        return self._initialized
