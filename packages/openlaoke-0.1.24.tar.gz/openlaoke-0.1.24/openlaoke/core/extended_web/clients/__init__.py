"""Extended Web clients for various AI services."""

from .base import BaseWebClient
from .deepseek_client import DeepSeekWebClient
from .glm_client import GLMWebClient
from .kimi_client import KimiWebClient
from .qwen_client import QwenWebClient

__all__ = [
    "BaseWebClient",
    "DeepSeekWebClient",
    "QwenWebClient",
    "KimiWebClient",
    "GLMWebClient",
]
