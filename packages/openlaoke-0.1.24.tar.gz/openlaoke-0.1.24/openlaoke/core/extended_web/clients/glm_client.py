"""GLM Web (智谱清言) API client."""

from __future__ import annotations

from typing import Any

import httpx


class GLMWebClient:
    """GLM Web API client."""

    _session_cache: dict[str, str] = {}

    def __init__(
        self,
        cookie: str,
        user_agent: str = "",
        bearer_token: str = "",
    ) -> None:
        self.cookie = cookie
        self.user_agent = user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        self.bearer_token = bearer_token
        self.base_url = "https://chatglm.cn"
        self.conversation_id: str | None = None
        self._client: httpx.AsyncClient | None = None

    async def init(self) -> None:
        """Initialize client."""
        pass

    def _build_headers(self) -> dict[str, str]:
        """Build HTTP headers."""
        headers = {
            "Cookie": self.cookie,
            "User-Agent": self.user_agent,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Referer": f"{self.base_url}/",
            "Origin": self.base_url,
        }

        if self.bearer_token:
            headers["Authorization"] = f"Bearer {self.bearer_token}"

        return headers

    async def _get_client(self) -> httpx.AsyncClient:
        """Get HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(300.0, connect=30.0),
            )
        return self._client

    async def close(self) -> None:
        """Close client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def create_chat_session(self) -> str:
        """Create new chat session."""
        client = await self._get_client()

        try:
            response = await client.post(
                f"{self.base_url}/api/chat/session",
                headers=self._build_headers(),
                json={},
            )

            if response.status_code >= 400:
                raise httpx.HTTPStatusError(
                    f"Failed to create session: {response.status_code}",
                    request=response.request,
                    response=response,
                )

            data = response.json()
            session_id = data.get("data", {}).get("id") or data.get("id") or ""

            if not session_id:
                raise ValueError("No session ID in response")

            self.conversation_id = session_id
            return session_id

        except Exception as e:
            raise RuntimeError(f"Failed to create GLM session: {e}")

    async def chat_completions(
        self,
        messages: list[dict[str, Any]],
        model: str = "glm-4",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stream: bool = False,
    ) -> dict[str, Any]:
        """Send chat completion request."""
        client = await self._get_client()

        if not self.conversation_id:
            self.conversation_id = await self.create_chat_session()

        # Build request body
        body = {
            "conversation_id": self.conversation_id,
            "messages": messages,
            "model": model,
            "stream": stream,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = await client.post(
                f"{self.base_url}/api/chat/completions",
                headers=self._build_headers(),
                json=body,
            )

            if response.status_code >= 400:
                error_text = response.text[:500]
                if response.status_code in (401, 403):
                    raise httpx.HTTPStatusError(
                        "GLM authentication expired. Please re-login.",
                        request=response.request,
                        response=response,
                    )
                raise httpx.HTTPStatusError(
                    f"GLM API error: {response.status_code}\n{error_text}",
                    request=response.request,
                    response=response,
                )

            data = response.json()

            # Parse response
            content = ""
            if "choices" in data:
                choices = data.get("choices", [])
                if choices:
                    choice = choices[0]
                    message = choice.get("message", {})
                    content = message.get("content", "")
            elif "data" in data:
                content = data.get("data", {}).get("content", "")
            elif "content" in data:
                content = data.get("content", "")

            return {
                "content": content,
                "model": data.get("model", model),
                "usage": data.get("usage", {}),
                "finish_reason": "stop",
                "session_id": self.conversation_id,
            }

        except httpx.HTTPStatusError:
            raise
        except Exception as e:
            raise RuntimeError(f"GLM API request failed: {e}")

    def clear_session(self) -> None:
        """Clear current conversation session."""
        self.conversation_id = None
