"""Kimi Web (月之暗面) API client.

Reference: ZeroToken/src/zero-token/streams/kimi-web-stream.ts
"""

from __future__ import annotations

import json
from typing import Any

import httpx

from .base import BaseWebClient


class KimiWebClient(BaseWebClient):
    """Client for Kimi Web API."""

    @property
    def provider_type(self) -> str:
        return "kimi-web"

    @property
    def base_url(self) -> str:
        return "https://kimi.moonshot.cn"

    @property
    def api_endpoint(self) -> str:
        return f"{self.base_url}/api/chat"

    def build_headers(self) -> dict[str, str]:
        return {
            "Cookie": self.cookie,
            "User-Agent": self.user_agent,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Referer": f"{self.base_url}/",
            "Origin": self.base_url,
        }

    async def chat_completions(
        self,
        messages: list[dict[str, Any]],
        model: str = "kimi",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stream: bool = False,
    ) -> dict[str, Any]:
        """Send chat completion request."""
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(300.0, connect=30.0),
            headers=self.build_headers(),
        ) as client:
            payload = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "stream": stream,
            }

            response = await client.post(self.api_endpoint, json=payload)

            if response.status_code >= 400:
                raise httpx.HTTPStatusError(
                    f"Kimi API error: {response.status_code}",
                    request=response.request,
                    response=response,
                )

            return response.json()

    async def close(self) -> None:
        """Close the client."""
        pass

    async def chat_completions_stream(
        self,
        messages: list[dict[str, Any]],
        model: str = "kimi",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> Any:
        """Send streaming chat completion request.

        Yields:
            Text deltas
        """
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(300.0, connect=30.0),
            headers=self.build_headers(),
        ) as client:
            payload = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "stream": True,
            }

            async with client.stream("POST", self.api_endpoint, json=payload) as response:
                response.raise_for_status()

                async for line in response.aiter_lines():
                    if not line:
                        continue

                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str == "[DONE]":
                            break

                        try:
                            data = json.loads(data_str)
                            content = data.get("content", "")
                            if content:
                                yield content
                        except json.JSONDecodeError:
                            continue
