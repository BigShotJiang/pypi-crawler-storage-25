"""Qwen Web API client - Full implementation reference ZeroToken."""

from __future__ import annotations

import time
import uuid
from typing import Any

import httpx


class QwenWebClient:
    """Qwen Web API client using browser context."""

    # Session cache to avoid creating new sessions every time
    _session_cache: dict[str, str] = {}

    def __init__(
        self,
        cookie: str,
        user_agent: str = "",
        bearer_token: str = "",
    ) -> None:
        self.cookie = cookie
        self.user_agent = user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        self.bearer_token = bearer_token
        self.base_url = "https://chat.qwen.ai"
        self.conversation_id: str | None = None
        self._client: httpx.AsyncClient | None = None

    async def init(self) -> None:
        """Initialize client."""
        pass

    def _build_headers(self) -> dict[str, str]:
        """Build HTTP headers."""
        headers = {
            "Cookie": self.cookie,
            "User-Agent": self.user_agent,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Referer": f"{self.base_url}/",
            "Origin": self.base_url,
        }

        if self.bearer_token:
            headers["Authorization"] = f"Bearer {self.bearer_token}"

        return headers

    async def _get_client(self) -> httpx.AsyncClient:
        """Get HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(300.0, connect=30.0),
            )
        return self._client

    async def close(self) -> None:
        """Close client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def create_chat_session(self) -> str:
        """Create new chat session."""
        client = await self._get_client()

        try:
            response = await client.post(
                f"{self.base_url}/api/v2/chats/new",
                headers=self._build_headers(),
                json={},
            )

            if response.status_code >= 400:
                error_text = response.text[:500]
                raise httpx.HTTPStatusError(
                    f"Failed to create chat session: {response.status_code}\n{error_text}",
                    request=response.request,
                    response=response,
                )

            data = response.json()
            if data is None:
                raise ValueError(
                    f"Empty response from Qwen API. Response text: {response.text[:200]}"
                )

            chat_id = data.get("data", {}).get("id") or data.get("chat_id") or data.get("id") or ""

            if not chat_id:
                raise ValueError(f"No chat ID in response. Response data: {str(data)[:200]}")

            self.conversation_id = chat_id
            return chat_id

        except Exception as e:
            raise RuntimeError(f"Failed to create Qwen chat session: {e}")

    async def chat_completions(
        self,
        messages: list[dict[str, Any]],
        model: str = "qwen3.5-plus",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stream: bool = False,
    ) -> dict[str, Any]:
        """Send chat completion request."""
        client = await self._get_client()

        # Create or get conversation ID
        if not self.conversation_id:
            self.conversation_id = await self.create_chat_session()

        # Build message with proper format
        fid = str(uuid.uuid4())
        timestamp = int(time.time())

        qwen_message = {
            "fid": fid,
            "parentId": None,
            "childrenIds": [],
            "role": "user",
            "content": messages[-1]["content"] if messages else "",
            "user_action": "chat",
            "files": [],
            "timestamp": timestamp,
            "models": [model],
            "chat_type": "t2t",
            "feature_config": {
                "thinking_enabled": True,
                "output_schema": "phase",
            },
        }

        # Build request body
        body = {
            "stream": stream,
            "version": "2.1",
            "incremental_output": True,
            "chat_id": self.conversation_id,
            "chat_mode": "normal",
            "model": model,
            "parent_id": None,
            "messages": [qwen_message],
        }

        try:
            response = await client.post(
                f"{self.base_url}/api/v2/chat/completions?chat_id={self.conversation_id}",
                headers=self._build_headers(),
                json=body,
            )

            if response.status_code >= 400:
                error_text = response.text[:500]
                if response.status_code in (401, 403):
                    raise httpx.HTTPStatusError(
                        "Qwen authentication expired. Please re-login.",
                        request=response.request,
                        response=response,
                    )
                raise httpx.HTTPStatusError(
                    f"Qwen API error: {response.status_code}\n{error_text}",
                    request=response.request,
                    response=response,
                )

            # Parse response
            if stream:
                # For streaming, return the response for further processing
                return {
                    "content": "",
                    "stream": True,
                    "response": response,
                    "session_id": self.conversation_id,
                }
            else:
                data = response.json()

                # Extract content from response
                content = ""
                if "choices" in data:
                    choices = data.get("choices", [])
                    if choices:
                        choice = choices[0]
                        message = choice.get("message", {})
                        content = message.get("content", "")
                elif "data" in data:
                    content = data.get("data", {}).get("content", "")
                elif "content" in data:
                    content = data.get("content", "")

                return {
                    "content": content,
                    "model": data.get("model", model),
                    "usage": data.get("usage", {}),
                    "finish_reason": "stop",
                    "session_id": self.conversation_id,
                }

        except httpx.HTTPStatusError:
            raise
        except Exception as e:
            raise RuntimeError(f"Qwen API request failed: {e}")

    async def chat_completions_stream(
        self,
        messages: list[dict[str, Any]],
        model: str = "qwen3.5-plus",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> Any:
        """Send streaming chat completion request."""
        result = await self.chat_completions(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
        )

        if result.get("stream"):
            response = result.get("response")
            if response:
                async for line in response.aiter_lines():
                    if not line:
                        continue

                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str == "[DONE]":
                            break

                        try:
                            data = __import__("json").loads(data_str)
                            # Qwen stream format may vary
                            if isinstance(data, dict):
                                content = data.get("content", "")
                                if content:
                                    yield content
                                elif "choices" in data:
                                    choices = data.get("choices", [])
                                    if choices:
                                        delta = choices[0].get("delta", {})
                                        content = delta.get("content", "")
                                        if content:
                                            yield content
                        except __import__("json").JSONDecodeError:
                            # Try to extract content directly
                            if line.strip():
                                yield line.strip()

    def clear_session(self) -> None:
        """Clear current conversation session."""
        self.conversation_id = None
