"""Stream factory functions for Extended Web providers.

Reference: ZeroToken/src/zero-token/streams/web-stream-factories.ts
"""

from __future__ import annotations

from typing import Any, AsyncGenerator

from .clients import DeepSeekWebClient, KimiWebClient, QwenWebClient


async def create_deepseek_stream(
    cookie: str,
    user_agent: str,
    messages: list[dict[str, Any]],
    model: str = "deepseek-chat",
    temperature: float = 1.0,
    max_tokens: int = 4096,
) -> AsyncGenerator[str, None]:
    """Create DeepSeek streaming response.
    
    Args:
        cookie: Browser cookie
        user_agent: User agent
        messages: Chat messages
        model: Model to use
        temperature: Temperature
        max_tokens: Max tokens
        
    Yields:
        Text deltas
    """
    client = DeepSeekWebClient(cookie=cookie, user_agent=user_agent)
    await client.init()
    
    async for delta in client.chat_completions_stream(
        messages=messages,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    ):
        yield delta
    
    await client.close()


async def create_qwen_stream(
    cookie: str,
    user_agent: str,
    messages: list[dict[str, Any]],
    model: str = "qwen-turbo",
    temperature: float = 0.7,
    max_tokens: int = 4096,
) -> AsyncGenerator[str, None]:
    """Create Qwen streaming response."""
    client = QwenWebClient(cookie=cookie, user_agent=user_agent)
    await client.init()
    
    async for delta in client.chat_completions_stream(
        messages=messages,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    ):
        yield delta
    
    await client.close()


async def create_kimi_stream(
    cookie: str,
    user_agent: str,
    messages: list[dict[str, Any]],
    model: str = "kimi",
    temperature: float = 0.7,
    max_tokens: int = 4096,
) -> AsyncGenerator[str, None]:
    """Create Kimi streaming response."""
    client = KimiWebClient(cookie=cookie, user_agent=user_agent)
    await client.init()
    
    async for delta in client.chat_completions_stream(
        messages=messages,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    ):
        yield delta
    
    await client.close()


# Stream factory registry
STREAM_FACTORIES = {
    "deepseek-chat": create_deepseek_stream,
    "deepseek-coder": create_deepseek_stream,
    "qwen-web": create_qwen_stream,
    "kimi-web": create_kimi_stream,
}


def get_stream_factory(provider_type: str):
    """Get stream factory function for a provider type.
    
    Args:
        provider_type: Provider type (e.g., 'deepseek-chat')
        
    Returns:
        Stream factory function or None
    """
    return STREAM_FACTORIES.get(provider_type)


def list_stream_providers() -> list[str]:
    """List all providers with stream support.
    
    Returns:
        List of provider types
    """
    return list(STREAM_FACTORIES.keys())
