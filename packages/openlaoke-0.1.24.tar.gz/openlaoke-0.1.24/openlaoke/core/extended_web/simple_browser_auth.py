"""Simple browser authentication using system default browser.

This module opens the system's default browser directly without Selenium,
making it more reliable and faster.
"""

from __future__ import annotations

import os
import platform
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from rich.console import Console

console = Console()


def open_system_browser(url: str) -> bool:
    """Open URL in system's default browser.

    Args:
        url: URL to open

    Returns:
        True if successful
    """
    system = platform.system()

    try:
        if system == "Darwin":  # macOS
            subprocess.run(["open", url], check=True)
        elif system == "Windows":
            subprocess.run(["start", url], shell=True, check=True)
        else:  # Linux
            subprocess.run(["xdg-open", url], check=True)

        return True
    except Exception as e:
        console.print(f"[red]Failed to open browser: {e}[/red]")
        return False


def authenticate_simple(
    provider_type: str,
    login_url: str,
    required_cookies: list[str],
) -> dict:
    """Simple authentication by opening browser and waiting for user.

    This function:
    1. Opens the system's default browser
    2. User logs in manually
    3. User copies cookies manually (for now)

    Args:
        provider_type: Provider type
        login_url: Login URL
        required_cookies: List of required cookie names

    Returns:
        Auth data dict
    """
    from openlaoke.core.extended_web import BrowserAuthManager

    auth_manager = BrowserAuthManager()

    console.print()
    console.print("[bold cyan]════════════════════════════════════════[/bold cyan]")
    console.print("[bold cyan]  Browser Authentication[/bold cyan]")
    console.print("[bold cyan]════════════════════════════════════════[/bold cyan]")
    console.print()
    console.print(f"[bold]Provider:[/bold] {provider_type}")
    console.print(f"[bold]Login URL:[/bold] [cyan underline]{login_url}[/cyan underline]")
    console.print()

    # Open browser
    console.print("[bold]Step 1: Opening browser...[/bold]")
    if open_system_browser(login_url):
        console.print("[green]✓ Browser opened![/green]")
        console.print("[dim]  Look for the browser window on your screen.[/dim]")
        console.print(
            f"[dim]  If not visible, manually open: [cyan underline]{login_url}[/cyan underline][/dim]"
        )
    else:
        console.print("[yellow]⚠ Failed to open browser automatically.[/yellow]")
        console.print("[dim]  Please open it manually and go to the URL above.[/dim]")

    console.print()
    console.print("[bold]Step 2: Login to your account[/bold]")
    console.print(f"[bold red]IMPORTANT:[/bold red]")
    console.print(f"  [dim]1. Browser will open automatically[/dim]")
    console.print(f"  [dim]2. Go to: [cyan underline]{login_url}[/cyan underline][/dim]")
    console.print(f"  [dim]3. Login with your account[/dim]")
    console.print(f"  [dim]4. Come back here and press Enter[/dim]")
    console.print()

    # Wait for user to login
    console.print("[bold]Step 3: Waiting for login...[/bold]")
    console.print()
    console.print("  [dim]Please login in the browser, then come back here.[/dim]")
    console.print("  [dim]Press Enter after you've logged in...[/dim]")
    console.print()

    input("  Press Enter when you've logged in: ")

    console.print()
    console.print("[bold green]✓ Login complete![/bold green]")
    console.print()

    # For now, create a placeholder auth
    # In a future version, we could extract cookies via browser extension
    auth_data = {
        "provider_type": provider_type,
        "cookie": "placeholder_need_manual_extraction",
        "bearer_token": "",
        "user_agent": "",
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "browser": "system_default",
        "manual": True,
    }

    console.print("[yellow]⚠ Note: Manual cookie extraction not yet implemented.[/yellow]")
    console.print("[dim]  For now, just keep the browser window open.[/dim]")
    console.print("[dim]  Future version will auto-extract cookies.[/dim]")
    console.print()

    return auth_data


if __name__ == "__main__":
    # Test
    authenticate_simple(
        "deepseek-chat",
        "https://chat.deepseek.com",
        ["d_id", "ds_session_id"],
    )
