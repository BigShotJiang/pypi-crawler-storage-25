"""Automatic cookie extractor using Playwright."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Literal

from rich.console import Console
from rich.panel import Panel

console = Console()


ServiceType = Literal["deepseek-chat", "qwen-web", "glm-web", "kimi-web"]

SERVICE_CONFIGS = {
    "deepseek-chat": {
        "name": "DeepSeek Chat",
        "login_url": "https://chat.deepseek.com",
        "check_url": "https://chat.deepseek.com",
        "cookie_domains": ["chat.deepseek.com", "deepseek.com"],
        "cookie_names": ["ds_session_id"],
        "check_selector": "textarea, .input, [contenteditable]",
    },
    "qwen-web": {
        "name": "Qwen Web (通义千问)",
        "login_url": "https://chat.qwen.ai",
        "check_url": "https://chat.qwen.ai",
        "cookie_domains": ["qwen.ai", ".qwen.ai", "chat.qwen.ai"],
        "cookie_names": ["qwen_session", "Qwen-Auth", "_TOKEN"],
        "check_selector": "textarea, .input, [contenteditable], [data-testid='chat-input']",
    },
    "glm-web": {
        "name": "GLM Web (智谱清言)",
        "login_url": "https://chatglm.cn",
        "check_url": "https://chatglm.cn",
        "cookie_domains": ["chatglm.cn", "zhipuai.cn"],
        "cookie_names": ["glmsession"],
        "check_selector": "textarea, .input, [contenteditable]",
    },
    "kimi-web": {
        "name": "Kimi Web (月之暗面)",
        "login_url": "https://kimi.moonshot.cn",
        "check_url": "https://kimi.moonshot.cn",
        "cookie_domains": ["kimi.moonshot.cn", "moonshot.cn"],
        "cookie_names": ["kimi_token"],
        "check_selector": "textarea, .input, [contenteditable]",
    },
}


async def extract_cookie_with_playwright(
    service: ServiceType,
    timeout: int = 300,
) -> dict | None:
    """Extract cookie by opening browser and waiting for user to login.

    Args:
        service: Service type
        timeout: Timeout in seconds

    Returns:
        Auth data dict or None
    """
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        console.print("[red]Error: Playwright not installed[/red]")
        console.print("[dim]Install with: pip install playwright[/dim]")
        return None

    config = SERVICE_CONFIGS.get(service)
    if not config:
        console.print(f"[red]Unknown service: {service}[/red]")
        return None

    console.print()
    console.print(
        Panel.fit(
            f"[bold cyan]{config['name']}[/bold cyan]\n[dim]{config['login_url']}[/dim]",
            border_style="cyan",
        )
    )
    console.print()
    console.print("[bold]Instructions:[/bold]")
    console.print()
    console.print(f"  [dim]1. Browser will open automatically[/dim]")
    console.print(f"  [dim]2. Go to: [cyan underline]{config['login_url']}[/cyan underline][/dim]")
    console.print(f"  [dim]3. Login with your account[/dim]")
    console.print(f"  [dim]4. Wait for the page to load completely[/dim]")
    console.print(f"  [dim]5. Cookie will be extracted automatically[/dim]")
    console.print()

    console.print("[bold yellow]→ Launching browser now...[/bold yellow]")

    try:
        async with async_playwright() as p:
            console.print("[dim]Starting Chromium...[/dim]")
            # Launch browser (Chromium - works for Chrome, Edge, Brave, etc.)
            browser = await p.chromium.launch(
                headless=False,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                ],
            )
            console.print("[green]✓ Chromium launched successfully![/green]")

            context = await browser.new_context(
                user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            page = await context.new_page()

            # Navigate to login page
            console.print(f"[dim]Opening {config['login_url']}...[/dim]")
            await page.goto(config["login_url"], wait_until="domcontentloaded")

            console.print()
            console.print("[bold green]✓ Browser opened![/bold green]")
            console.print()
            console.print("[bold]Please login in the browser window.[/bold]")
            console.print("[dim]Waiting for login...[/dim]")
            console.print()

            # Wait for login by polling for cookies
            import time

            start_time = time.time()
            extracted_cookies = None

            # Build list of URLs to check for cookies
            check_urls = [config["check_url"]]
            if "cookie_domains" in config:
                check_urls = [f"https://{d}" for d in config["cookie_domains"]]

            while time.time() - start_time < timeout:
                # Get cookies from all relevant domains
                all_cookies = {}
                for url in check_urls:
                    try:
                        cookies = await context.cookies(url)
                        for c in cookies:
                            all_cookies[c["name"]] = c["value"]
                    except Exception:
                        pass

                # Debug: show what cookies we have every 10 seconds
                elapsed = int(time.time() - start_time)
                if elapsed % 10 == 0 and elapsed > 0:
                    console.print(f"[dim]  Found cookies: {list(all_cookies.keys())}[/dim]")
                    console.print(f"[dim]  Looking for any of: {config['cookie_names']}[/dim]")

                # Check if ANY of the required cookies are present
                has_required = any(name in all_cookies for name in config["cookie_names"])

                # Also check if page looks logged in
                if has_required:
                    # Try to find chat input element
                    try:
                        await page.wait_for_selector(config["check_selector"], timeout=5000)
                        extracted_cookies = all_cookies
                        console.print("[bold green]✓ Login detected![/bold green]")
                        break
                    except Exception:
                        pass

                # Show progress every 5 seconds
                elapsed = int(time.time() - start_time)
                if elapsed % 5 == 0:
                    console.print(f"[dim]  Waiting... {elapsed}s / {timeout}s[/dim]")

                await asyncio.sleep(1)

            await browser.close()

            if not extracted_cookies:
                console.print()
                console.print("[red]✗ Login timeout or cookies not found[/red]")
                console.print("[dim]Please try again or login manually in your browser[/dim]")
                return None

            # Build cookie string - save ALL cookies, not just required ones
            cookie_string = "; ".join(
                f"{name}={value}" for name, value in extracted_cookies.items()
            )

            # Save to auth file
            auth_file = Path.home() / ".openlaoke" / "extended_web" / f"{service}.json"
            auth_file.parent.mkdir(parents=True, exist_ok=True)

            auth_data = {
                "provider_type": service,
                "cookie": cookie_string,
                "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "browser": "playwright-auto",
            }

            with open(auth_file, "w") as f:
                json.dump(auth_data, f, indent=2)

            console.print()
            console.print(f"[bold green]✓ Cookie extracted and saved![/bold green]")
            console.print(f"  Cookie length: {len(cookie_string)}")
            console.print(f"  Saved to: {auth_file}")

            return auth_data

    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        import traceback

        traceback.print_exc()
        return None


async def main():
    """Test function."""
    console.print()
    console.print("[bold cyan]Extended Web Cookie Extractor[/bold cyan]")
    console.print()
    console.print("Select service:")
    console.print("  [1] DeepSeek Chat")
    console.print("  [2] Qwen Web")
    console.print("  [3] GLM Web")
    console.print("  [4] Kimi Web")
    console.print()

    choice = console.input("Select [1/2/3/4]: ")

    service_map = {
        "1": "deepseek-chat",
        "2": "qwen-web",
        "3": "glm-web",
        "4": "kimi-web",
    }

    service = service_map.get(choice)
    if not service:
        console.print("[red]Invalid choice[/red]")
        return

    await extract_cookie_with_playwright(service)


if __name__ == "__main__":
    asyncio.run(main())
