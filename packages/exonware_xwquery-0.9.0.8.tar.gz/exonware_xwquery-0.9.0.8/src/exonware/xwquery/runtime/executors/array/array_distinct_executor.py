#!/usr/bin/env python3
"""
ARRAY_DISTINCT Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.8
"""

from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


class ArrayDistinctExecutor(AUniversalOperationExecutor):
    """ARRAY_DISTINCT - Remove duplicates while preserving original order."""
    OPERATION_NAME = "ARRAY_DISTINCT"
    OPERATION_TYPE = OperationType.ARRAY
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        result_data = self._execute_op(context.node, params, context)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _execute_op(self, node: Any, params: dict, context: ExecutionContext) -> dict:
        field: Optional[str] = params.get("field")
        as_field: str = params.get("as_field", field or "_array_distinct")
        items = extract_items(node)

        result_items = []
        for item in items:
            item_copy = item.copy() if isinstance(item, dict) else {"value": item}
            array_value = extract_field_value(item, field) if field else None
            if isinstance(array_value, list):
                item_copy[as_field] = self._dedupe_preserve_order(array_value)
            else:
                item_copy[as_field] = []
            result_items.append(item_copy)

        return {
            "items": result_items,
            "count": len(result_items),
            "total_items": len(items),
            "field": field,
            "as_field": as_field,
        }

    @staticmethod
    def _dedupe_preserve_order(values: list[Any]) -> list[Any]:
        try:
            return list(dict.fromkeys(values))
        except TypeError:
            seen: dict[str, bool] = {}
            unique_values: list[Any] = []
            for value in values:
                key = repr(value)
                if key in seen:
                    continue
                seen[key] = True
                unique_values.append(value)
            return unique_values


__all__ = ["ArrayDistinctExecutor"]
