#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-27
################################################################

import numpy as np
from dataclasses import dataclass, field
from typing import Any, Optional

from ..base import HexYocoBase, HexYocoBaseParams, HexYocoRobotParams, HexYocoCameraParams, HexYocoSimParams

from hex_driver_mujoco import HexMujocoE3Desktop, HexMujocoE3DesktopParams
from hex_driver_robot import HexRobotArcherY6, HexRobotArcherY6Params
from hex_driver_camera import HexCamUsb, HexCamUsbParams

# try to import realsense
try:
    from hex_driver_camera import HexCamRealsense, HexCamRealsenseParams
    HAS_REALSENSE = True
except ImportError:
    HexCamRealsense = HexCamRealsenseParams = None
    HAS_REALSENSE = False

# try to import berxel
try:
    from hex_driver_camera import HexCamBerxel, HexCamBerxelParams
    HAS_BERXEL = True
except ImportError:
    HexCamBerxel = HexCamBerxelParams = None
    HAS_BERXEL = False


@dataclass
class HexYocoE3DesktopParams(HexYocoBaseParams):
    # common parameters
    camera_type: dict[str, str] = field(default_factory=lambda: {
        "head": "empty",
        "left": "empty",
        "right": "empty",
    })

    # For real mode (optional, not fully supported)
    robot_params: dict[str, HexYocoRobotParams] = field(
        default_factory=lambda: {
            "left": HexYocoRobotParams(),
            "right": HexYocoRobotParams(),
        })
    camera_params: dict[str, HexYocoCameraParams] = field(
        default_factory=lambda: {
            "head": HexYocoCameraParams(),
            "left": HexYocoCameraParams(),
            "right": HexYocoCameraParams(),
        })

    # For sim mode
    sim_params: HexYocoSimParams = HexYocoSimParams()


class HexYocoE3Desktop(HexYocoBase):
    """Unified driver for E3 Desktop robot (dual-arm), supporting both simulation and real hardware."""

    def __init__(
            self,
            params: HexYocoE3DesktopParams = HexYocoE3DesktopParams(),
    ) -> None:
        HexYocoBase.__init__(self)
        self.__params = params
        self.__mode = params.mode

        self.__sim = None
        self.__robot = {
            "left": None,
            "right": None,
        }
        self.__camera = {
            "head": None,
            "left": None,
            "right": None,
        }

        if self.__mode == "sim":
            sim_params = HexMujocoE3DesktopParams(
                state_rate=self.__params.state_rate,
                cam_rate=self.__params.cam_rate,
                state_buffer_size=self.__params.state_buffer_size,
                cam_buffer_size=self.__params.cam_buffer_size,
                headless=self.__params.sim_params.headless,
                sens_ts=self.__params.sens_ts,
                cam_type=self.__params.camera_type,
            )
            self.__sim = HexMujocoE3Desktop(sim_params)
        elif self.__mode == "real":
            for side in self.__robot.keys():
                self.__init_real_robot(side)
            for side in self.__camera.keys():
                self.__init_real_camera(side)
        else:
            raise ValueError(f"Invalid mode: {self.__mode}")

    def __init_real_robot(self, side: str) -> None:
        if side not in self.__robot.keys():
            raise ValueError(f"Invalid side: {side}")

        robot_params = HexRobotArcherY6Params(
            host=self.__params.robot_params[side].host,
            port=self.__params.robot_params[side].port,
            grip_type=self.__params.robot_params[side].grip_type,
            ctrl_rate=self.__params.state_rate,
            state_buffer_size=self.__params.state_buffer_size,
            sens_ts=self.__params.sens_ts,
        )
        self.__robot[side] = HexRobotArcherY6(robot_params)

    def __init_real_camera(self, side: str) -> None:
        if side not in self.__camera.keys():
            raise ValueError(f"Invalid side: {side}")
        if self.__params.camera_type[side] == "empty":
            self.__camera[side] = None
        elif self.__params.camera_type[side] == "usb":
            camera_params = HexCamUsbParams(
                frame_rate=self.__params.cam_rate,
                height=self.__params.camera_params[side].height,
                width=self.__params.camera_params[side].width,
                cam_buffer_size=self.__params.cam_buffer_size,
                sens_ts=self.__params.sens_ts,
                cam_path=self.__params.camera_params[side].path,
                exposure=self.__params.camera_params[side].exposure,
                temperature=self.__params.camera_params[side].temperature,
            )
            self.__camera[side] = HexCamUsb(camera_params)
        elif self.__params.camera_type[side] == "realsense":
            if not HAS_REALSENSE:
                print("Realsense is not installed, using empty camera")
                self.__camera[side] = None
            else:
                camera_params = HexCamRealsenseParams(
                    frame_rate=self.__params.cam_rate,
                    height=self.__params.camera_params[side].height,
                    width=self.__params.camera_params[side].width,
                    cam_buffer_size=self.__params.cam_buffer_size,
                    sens_ts=self.__params.sens_ts,
                    serial_number=self.__params.camera_params[side].
                    serial_number,
                )
                self.__camera[side] = HexCamRealsense(camera_params)
        elif self.__params.camera_type[side] == "berxel":
            if not HAS_BERXEL:
                print("Berxel is not installed, using empty camera")
                self.__camera[side] = None
            else:
                camera_params = HexCamBerxelParams(
                    frame_rate=self.__params.cam_rate,
                    height=self.__params.camera_params[side].height,
                    width=self.__params.camera_params[side].width,
                    cam_buffer_size=self.__params.cam_buffer_size,
                    sens_ts=self.__params.sens_ts,
                    serial_number=self.__params.camera_params[side].
                    serial_number,
                    exposure=self.__params.camera_params[side].exposure,
                    gain=self.__params.camera_params[side].gain,
                )
                self.__camera[side] = HexCamBerxel(camera_params)
        else:
            raise ValueError(
                f"Invalid camera type: {self.__params.camera_type[side]}")

    def deinit_yoco(self):
        if self.__sim is not None:
            self.__sim.deinit_mujoco()
        for side in self.__robot.keys():
            if self.__robot[side] is not None:
                self.__robot[side].deinit_robot()
        for side in self.__camera.keys():
            if self.__camera[side] is not None:
                self.__camera[side].deinit_camera()

    # ==================== Override start/stop ====================
    def start(self, daemon: bool = True) -> None:
        if self.__sim is not None:
            self.__sim.start(daemon=daemon)
        for side in self.__robot.keys():
            if self.__robot[side] is not None:
                self.__robot[side].start(daemon=daemon)
        for side in self.__camera.keys():
            if self.__camera[side] is not None:
                self.__camera[side].start(daemon=daemon)

    def stop(self, timeout: Optional[float] = 5.0) -> None:
        if self.__sim is not None:
            self.__sim.stop(timeout=timeout)
        for side in self.__robot.keys():
            if self.__robot[side] is not None:
                self.__robot[side].stop(timeout=timeout)
        for side in self.__camera.keys():
            if self.__camera[side] is not None:
                self.__camera[side].stop(timeout=timeout)

    def is_working(self) -> bool:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.is_working()
        elif self.__mode == "real" and self.__robot is not None:
            working = True
            for side in self.__robot.keys():
                if self.__robot[side] is not None:
                    working &= self.__robot[side].is_working()
            for side in self.__camera.keys():
                if self.__camera[side] is not None:
                    working &= self.__camera[side].is_working()
            return working
        else:
            return False

    # ==================== Unified Robot API ====================
    def get_dofs(self) -> dict[str, int]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_dofs()
        elif self.__mode == "real" and self.__robot is not None:
            left_dofs = self.__robot["left"].get_dofs()
            right_dofs = self.__robot["right"].get_dofs()
            return {
                "left_arm": left_dofs["arm"],
                "left_grip": left_dofs["grip"],
                "right_arm": right_dofs["arm"],
                "right_grip": right_dofs["grip"],
            }
        else:
            return {}

    # Left arm
    def get_left_arm_motor(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_left_arm_motor(latest=latest)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            return self.__robot["left"].get_arm_motor(latest=latest)
        else:
            return None

    def get_left_grip_motor(self,
                            latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_left_grip_motor(latest=latest)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            return self.__robot["left"].get_grip_motor(latest=latest)
        else:
            return None

    def set_left_arm_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_left_arm_mit_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            self.__robot["left"].set_arm_mit_cmd(cmd_dict)

    def set_left_arm_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_left_arm_mit_comp_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            self.__robot["left"].set_arm_mit_comp_cmd(cmd_dict)

    def set_left_arm_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_left_arm_pos_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            self.__robot["left"].set_arm_pos_cmd(cmd_dict)

    def set_left_arm_pose_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_left_arm_pose_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            self.__robot["left"].set_arm_pose_cmd(cmd_dict)

    def set_left_grip_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_left_grip_mit_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            self.__robot["left"].set_grip_mit_cmd(cmd_dict)

    def set_left_grip_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_left_grip_mit_comp_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            self.__robot["left"].set_grip_mit_comp_cmd(cmd_dict)

    def set_left_grip_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_left_grip_pos_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["left"] is not None:
            self.__robot["left"].set_grip_pos_cmd(cmd_dict)

    # Right arm
    def get_right_arm_motor(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_right_arm_motor(latest=latest)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            return self.__robot["right"].get_arm_motor(latest=latest)
        else:
            return None

    def get_right_grip_motor(self,
                             latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_right_grip_motor(latest=latest)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            return self.__robot["right"].get_grip_motor(latest=latest)
        else:
            return None

    def set_right_arm_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_right_arm_mit_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            self.__robot["right"].set_arm_mit_cmd(cmd_dict)

    def set_right_arm_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_right_arm_mit_comp_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            self.__robot["right"].set_arm_mit_comp_cmd(cmd_dict)

    def set_right_arm_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_right_arm_pos_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            self.__robot["right"].set_arm_pos_cmd(cmd_dict)

    def set_right_arm_pose_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_right_arm_pose_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            self.__robot["right"].set_arm_pose_cmd(cmd_dict)

    def set_right_grip_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_right_grip_mit_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            self.__robot["right"].set_grip_mit_cmd(cmd_dict)

    def set_right_grip_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_right_grip_mit_comp_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            self.__robot["right"].set_grip_mit_comp_cmd(cmd_dict)

    def set_right_grip_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_right_grip_pos_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot["right"] is not None:
            self.__robot["right"].set_grip_pos_cmd(cmd_dict)

    # ==================== Unified Camera API ====================
    def get_head_color_img(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_head_color_img(latest=latest)
        elif self.__mode == "real" and self.__camera["head"] is not None:
            return self.__camera["head"].get_color_img(latest=latest)
        else:
            return None

    def get_head_depth_img(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_head_depth_img(latest=latest)
        elif self.__mode == "real" and self.__camera["head"] is not None:
            return self.__camera["head"].get_depth_img(
                latest=latest) if hasattr(self.__camera["head"],
                                          'get_depth_img') else None
        else:
            return None

    def get_head_intri(self) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_head_intri()
        elif self.__mode == "real" and self.__camera["head"] is not None:
            return self.__camera["head"].get_intri() if hasattr(
                self.__camera["head"], 'get_intri') else None
        else:
            return None

    def get_left_color_img(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_left_color_img(latest=latest)
        elif self.__mode == "real" and self.__camera["left"] is not None:
            return self.__camera["left"].get_color_img(latest=latest)
        else:
            return None

    def get_left_depth_img(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_left_depth_img(latest=latest)
        elif self.__mode == "real" and self.__camera["left"] is not None:
            return self.__camera["left"].get_depth_img(
                latest=latest) if hasattr(self.__camera["left"],
                                          'get_depth_img') else None
        else:
            return None

    def get_left_intri(self) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_left_intri()
        elif self.__mode == "real" and self.__camera["left"] is not None:
            return self.__camera["left"].get_intri() if hasattr(
                self.__camera["left"], 'get_intri') else None
        else:
            return None

    def get_right_color_img(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_right_color_img(latest=latest)
        elif self.__mode == "real" and self.__camera["right"] is not None:
            return self.__camera["right"].get_color_img(latest=latest)
        else:
            return None

    def get_right_depth_img(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_right_depth_img(latest=latest)
        elif self.__mode == "real" and self.__camera["right"] is not None:
            return self.__camera["right"].get_depth_img(
                latest=latest) if hasattr(self.__camera["right"],
                                          'get_depth_img') else None
        else:
            return None

    def get_right_intri(self) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_right_intri()
        elif self.__mode == "real" and self.__camera["right"] is not None:
            return self.__camera["right"].get_intri() if hasattr(
                self.__camera["right"], 'get_intri') else None
        else:
            return None

    # ==================== Simulation-only API (optional) ====================
    def reset(self):
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.reset()
        else:
            raise RuntimeError("reset() is only available in simulation mode.")

    def get_obj_pose(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_obj_pose(latest=latest)
        else:
            raise RuntimeError(
                "get_obj_pose() is only available in simulation mode.")
