#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-27
################################################################

import os
from dataclasses import dataclass
from abc import ABC, abstractmethod
from typing import Optional


@dataclass
class HexYocoBaseParams:
    """Base parameters for Yoco driver."""
    mode: str = "sim"
    state_rate: int = 1000
    cam_rate: int = 30

    state_buffer_size: int = 200
    cam_buffer_size: int = 30

    sens_ts: bool = True


@dataclass
class HexYocoRobotParams:
    host: str = "192.168.1.100"
    port: int = 8439
    grip_type: str = "gp80"


@dataclass
class HexYocoCameraParams:
    height: int = 480
    width: int = 640
    exposure: int = 0
    temperature: int = 0
    gain: int = 100
    serial_number: Optional[str] = None
    path: str = "/dev/video0"


@dataclass
class HexYocoSimParams:
    headless: bool = True


class HexYocoBase(ABC):
    """Abstract base class for Yoco drivers."""

    def __init__(self) -> None:
        os.environ["QT_QPA_FONTDIR"] = "/usr/share/fonts/truetype/dejavu/"

    def __del__(self):
        self.deinit_yoco()

    @abstractmethod
    def is_working(self) -> bool:
        pass

    @abstractmethod
    def start(self, *, daemon: bool = True) -> None:
        pass

    @abstractmethod
    def stop(self, timeout: Optional[float] = 5.0) -> None:
        pass

    @abstractmethod
    def deinit_yoco(self):
        raise NotImplementedError(
            "`deinit_yoco` should be implemented by the child class")
