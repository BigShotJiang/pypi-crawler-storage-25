#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-27
################################################################

import numpy as np
from dataclasses import dataclass, field
from typing import Any, Optional

from ..base import HexYocoBase, HexYocoBaseParams, HexYocoRobotParams, HexYocoCameraParams, HexYocoSimParams

from hex_driver_mujoco import HexMujocoArcherY6, HexMujocoArcherY6Params
from hex_driver_robot import HexRobotArcherY6, HexRobotArcherY6Params
from hex_driver_camera import HexCamUsb, HexCamUsbParams

# try to import realsense
try:
    from hex_driver_camera import HexCamRealsense, HexCamRealsenseParams
    HAS_REALSENSE = True
except ImportError:
    HexCamRealsense = HexCamRealsenseParams = None
    HAS_REALSENSE = False

# try to import berxel
try:
    from hex_driver_camera import HexCamBerxel, HexCamBerxelParams
    HAS_BERXEL = True
except ImportError:
    HexCamBerxel = HexCamBerxelParams = None
    HAS_BERXEL = False


@dataclass
class HexYocoArcherY6Params(HexYocoBaseParams):
    camera_type: str = "usb"

    # For real mode
    robot_params: HexYocoRobotParams = HexYocoRobotParams()
    camera_params: HexYocoCameraParams = HexYocoCameraParams()

    # For sim mode
    sim_params: HexYocoSimParams = HexYocoSimParams()


class HexYocoArcherY6(HexYocoBase):
    """Unified driver for Archer Y6 robot, supporting both simulation and real hardware."""

    def __init__(
            self,
            params: HexYocoArcherY6Params = HexYocoArcherY6Params(),
    ) -> None:
        HexYocoBase.__init__(self)
        self.__params = params
        self.__mode = params.mode

        self.__sim = None
        self.__robot = None
        self.__camera = None

        if self.__mode == "sim":
            sim_params = HexMujocoArcherY6Params(
                state_rate=self.__params.state_rate,
                cam_rate=self.__params.cam_rate,
                state_buffer_size=self.__params.state_buffer_size,
                cam_buffer_size=self.__params.cam_buffer_size,
                headless=self.__params.sim_params.headless,
                sens_ts=self.__params.sens_ts,
                camera_type=self.__params.camera_type,
            )
            self.__sim = HexMujocoArcherY6(sim_params)
        elif self.__mode == "real":
            robot_params = HexRobotArcherY6Params(
                host=self.__params.robot_params.host,
                port=self.__params.robot_params.port,
                grip_type=self.__params.robot_params.grip_type,
                ctrl_rate=self.__params.state_rate,
                state_buffer_size=self.__params.state_buffer_size,
                sens_ts=self.__params.sens_ts,
            )
            self.__robot = HexRobotArcherY6(robot_params)
            if self.__params.camera_type == "empty":
                self.__camera = None
            elif self.__params.camera_type == "usb":
                camera_params = HexCamUsbParams(
                    frame_rate=self.__params.cam_rate,
                    height=self.__params.camera_params.height,
                    width=self.__params.camera_params.width,
                    cam_buffer_size=self.__params.cam_buffer_size,
                    sens_ts=self.__params.sens_ts,
                    cam_path=self.__params.camera_params.path,
                    exposure=self.__params.camera_params.exposure,
                    temperature=self.__params.camera_params.temperature,
                )
                self.__camera = HexCamUsb(camera_params)
            elif self.__params.camera_type == "realsense":
                if not HAS_REALSENSE:
                    print("Realsense is not installed, using empty camera")
                    self.__camera = None
                else:
                    camera_params = HexCamRealsenseParams(
                        frame_rate=self.__params.cam_rate,
                        height=self.__params.camera_params.height,
                        width=self.__params.camera_params.width,
                        cam_buffer_size=self.__params.cam_buffer_size,
                        sens_ts=self.__params.sens_ts,
                        serial_number=self.__params.camera_params.
                        serial_number,
                    )
                    self.__camera = HexCamRealsense(camera_params)
            elif self.__params.camera_type == "berxel":
                if not HAS_BERXEL:
                    print("Berxel is not installed, using empty camera")
                    self.__camera = None
                else:
                    camera_params = HexCamBerxelParams(
                        frame_rate=self.__params.cam_rate,
                        height=self.__params.camera_params.height,
                        width=self.__params.camera_params.width,
                        cam_buffer_size=self.__params.cam_buffer_size,
                        sens_ts=self.__params.sens_ts,
                        serial_number=self.__params.camera_params.
                        serial_number,
                        exposure=self.__params.camera_params.exposure,
                        gain=self.__params.camera_params.gain,
                    )
                    self.__camera = HexCamBerxel(camera_params)
            else:
                raise ValueError(
                    f"Invalid camera type: {self.__params.camera_type}")
        else:
            raise ValueError(f"Invalid mode: {self.__mode}")

    def deinit_yoco(self):
        if self.__sim is not None:
            self.__sim.deinit_mujoco()
        if self.__robot is not None:
            self.__robot.deinit_robot()
        if self.__camera is not None:
            self.__camera.deinit_camera()

    # ==================== Override start/stop ====================
    def start(self, daemon: bool = True) -> None:
        if self.__sim is not None:
            self.__sim.start(daemon=daemon)
        if self.__robot is not None:
            self.__robot.start(daemon=daemon)
        if self.__camera is not None:
            self.__camera.start(daemon=daemon)

    def stop(self, timeout: Optional[float] = 5.0) -> None:
        if self.__sim is not None:
            self.__sim.stop(timeout=timeout)
        if self.__robot is not None:
            self.__robot.stop(timeout=timeout)
        if self.__camera is not None:
            self.__camera.stop(timeout=timeout)

    def is_working(self) -> bool:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.is_working()
        elif self.__mode == "real" and self.__robot is not None:
            robot_working = self.__robot.is_working()
            if self.__camera is not None:
                camera_working = self.__camera.is_working()
                return robot_working and camera_working
            else:
                return robot_working
        else:
            return False

    # ==================== Unified Robot API ====================
    def get_dofs(self) -> dict[str, int]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_dofs()
        elif self.__mode == "real" and self.__robot is not None:
            return self.__robot.get_dofs()
        else:
            return {}

    def get_arm_motor(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_arm_motor(latest=latest)
        elif self.__mode == "real" and self.__robot is not None:
            return self.__robot.get_arm_motor(latest=latest)
        else:
            return None

    def get_grip_motor(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_grip_motor(latest=latest)
        elif self.__mode == "real" and self.__robot is not None:
            return self.__robot.get_grip_motor(latest=latest)
        else:
            return None

    def set_arm_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_arm_mit_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot is not None:
            self.__robot.set_arm_mit_cmd(cmd_dict)

    def set_arm_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_arm_mit_comp_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot is not None:
            self.__robot.set_arm_mit_comp_cmd(cmd_dict)

    def set_arm_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_arm_pos_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot is not None:
            self.__robot.set_arm_pos_cmd(cmd_dict)

    def set_arm_pose_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_arm_pose_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot is not None:
            self.__robot.set_arm_pose_cmd(cmd_dict)

    def set_grip_mit_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_grip_mit_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot is not None:
            self.__robot.set_grip_mit_cmd(cmd_dict)

    def set_grip_mit_comp_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_grip_mit_comp_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot is not None:
            self.__robot.set_grip_mit_comp_cmd(cmd_dict)

    def set_grip_pos_cmd(self, cmd_dict: dict[str, Any]) -> None:
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.set_grip_pos_cmd(cmd_dict)
        elif self.__mode == "real" and self.__robot is not None:
            self.__robot.set_grip_pos_cmd(cmd_dict)

    # ==================== Unified Camera API ====================
    def get_color_img(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_color_img(latest=latest)
        elif self.__mode == "real" and self.__camera is not None:
            return self.__camera.get_color_img(latest=latest)
        else:
            return None

    def get_depth_img(self, latest: bool = True) -> Optional[np.ndarray]:
        """Read depth image."""
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_depth_img(latest=latest)
        elif self.__mode == "real" and self.__camera is not None:
            return self.__camera.get_depth_img(latest=latest) if hasattr(
                self.__camera, 'get_depth_img') else None
        else:
            return None

    def get_intri(self) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_intri()
        elif self.__mode == "real" and self.__camera is not None:
            return self.__camera.get_intri() if hasattr(
                self.__camera, 'get_intri') else None
        else:
            return None

    # ==================== Simulation-only API (optional) ====================
    def reset(self):
        if self.__mode == "sim" and self.__sim is not None:
            self.__sim.reset()
        else:
            raise RuntimeError("reset() is only available in simulation mode.")

    def get_obj_pose(self, latest: bool = True) -> Optional[np.ndarray]:
        if self.__mode == "sim" and self.__sim is not None:
            return self.__sim.get_obj_pose(latest=latest)
        else:
            raise RuntimeError(
                "get_obj_pose() is only available in simulation mode.")
