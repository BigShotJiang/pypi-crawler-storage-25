"""Tool loop system prompt builder — framework detection and prompt generation.

Now framework-aware: detects the target framework from the user's task description
and injects framework-specific development rules into the system prompt.
"""
from __future__ import annotations

import json
import re
from pathlib import Path


# ── Framework patterns for task-based detection ──────────────────────

_TASK_FRAMEWORK_PATTERNS: list[tuple[str, str, str]] = [
    ("laravel",    r"laravel",                     "PHP"),
    ("django",     r"django",                      "Python"),
    ("fastapi",    r"fastapi",                     "Python"),
    ("flask",      r"\bflask\b",                   "Python"),
    ("react",      r"\breact\b",                   "JavaScript"),
    ("nextjs",     r"next\.?js?\b",                "JavaScript"),
    ("vue",        r"\bvue\b",                     "JavaScript"),
    ("angular",    r"\bangular\b",                 "JavaScript"),
    ("svelte",     r"\bsvelte\b",                  "JavaScript"),
    ("express",    r"\bexpress\b",                 "JavaScript"),
    ("node",       r"\bnode(?:\.js)?\b",           "JavaScript"),
    ("spring",     r"\bspring\b",                  "Java"),
    ("rails",      r"\brails\b",                   "Ruby"),
    ("go",         r"\bgolang\b",                  "Go"),
    ("rust",       r"\brust\b",                    "Rust"),
    ("flutter",    r"\bflutter\b",                 "Dart"),
    ("wordpress",  r"\bwordpress\b",              "PHP"),
    ("symfony",    r"\bsymfony\b",                "PHP"),
]

_FRAMEWORK_RULES: dict[str, str] = {
    "laravel": (
        "## Laravel / PHP Development Rules\n"
        "- Use MVC pattern: Models in app/Models, Views in resources/views, Controllers in app/Http/Controllers\n"
        "- Use Eloquent ORM for database queries — not raw SQL\n"
        "- Use Blade templating for views: @extends, @section, @yield\n"
        "- Use Artisan CLI: php artisan make:model, php artisan migrate, php artisan serve\n"
        "- Routes in routes/web.php (web) and routes/api.php (API)\n"
        "- Validation in Form Requests or validate() method\n"
        "- Use dependency injection in controllers\n"
        "- Migrations for schema changes, Seeders for test data\n"
        "- Follow PSR-4 autoloading and PSR-12 coding style\n"
        "- Use Laravel's built-in authentication (Sanctum, Breeze, Jetstream)\n"
        "- Queue jobs for slow tasks, Schedule for cron\n"
        "- Use env() or config() for configuration, never hardcode secrets\n"
    ),
    "django": (
        "## Django / Python Development Rules\n"
        "- Use MTV pattern: Models define data, Templates define UI, Views define logic\n"
        "- Use Django ORM for queries: Model.objects.filter(), select_related(), prefetch_related()\n"
        "- URL dispatcher in urls.py, views in views.py\n"
        "- Use class-based views (ListView, DetailView, CreateView) where possible\n"
        "- Forms for input validation, ModelForm for model-backed forms\n"
        "- Migrations via python manage.py makemigrations && migrate\n"
        "- Admin interface via admin.py registration\n"
        "- Settings in settings.py, separate dev/prod settings for security\n"
        "- Use environment variables for secrets (python-decouple or django-environ)\n"
    ),
    "fastapi": (
        "## FastAPI / Python Development Rules\n"
        "- Use Pydantic models for request/response validation\n"
        "- Path operations: @app.get(), @app.post(), @app.put(), @app.delete()\n"
        "- Dependency injection with Depends() for auth, DB sessions\n"
        "- SQLAlchemy async for database, Alembic for migrations\n"
        "- Use HTTPException for error responses, status codes from fastapi.status\n"
        "- BackgroundTasks for post-response work\n"
        "- CORS middleware config in app startup\n"
        "- OpenAPI docs auto-generated at /docs and /redoc\n"
    ),
    "react": (
        "## React / JavaScript Development Rules\n"
        "- Functional components with hooks — no class components\n"
        "- Use TypeScript for type safety (interfaces for props, state)\n"
        "- State management: useState for local, useReducer for complex, Context for shared\n"
        "- Side effects via useEffect with proper cleanup\n"
        "- Fetch data with React Query / TanStack Query or SWR\n"
        "- Routing with React Router v6 (createBrowserRouter or <Routes>)\n"
        "- Styling: Tailwind CSS, CSS Modules, or styled-components\n"
        "- Component per file, named exports, index.ts barrel files\n"
    ),
    "nextjs": (
    "## Next.js / JavaScript Development Rules\n"
        "- App Router (app/) preferred over Pages Router\n"
        "- Server Components by default, 'use client' for interactivity\n"
        "- File-based routing: app/page.tsx for /, app/blog/[slug]/page.tsx for /blog/:slug\n"
        "- Data fetching: fetch() in Server Components, Route Handlers for APIs\n"
        "- Layouts via layout.tsx, loading states via loading.tsx, errors via error.tsx\n"
        "- Metadata API for SEO: export const metadata = { title, description }\n"
        "- Server Actions for form submissions and mutations\n"
    ),
}

_DEFAULT_FRAMEWORK_RULES: dict[str, str] = {
    "PHP": (
        "## PHP Development Rules\n"
        "- Use PSR-4 autoloading with Composer\n"
        "- Follow PSR-12 coding style\n"
        "- Use .php extension, <?php opening tag\n"
        "- Type hints for function parameters and return types\n"
    ),
    "Python": (
        "## Python Development Rules\n"
        "- Follow PEP 8 style: snake_case, 4-space indent\n"
        "- Type hints for all function signatures\n"
        "- Use virtual environments (venv) for dependencies\n"
        "- requirements.txt or pyproject.toml for packages\n"
    ),
    "JavaScript": (
        "## JavaScript/TypeScript Development Rules\n"
        "- Use ES modules (import/export) not CommonJS\n"
        "- Prefer const over let, never use var\n"
        "- Use async/await for promises\n"
        "- package.json for dependencies, scripts for automation\n"
    ),
}


def _detect_framework_from_task(task: str) -> tuple[str, str] | None:
    """Detect framework and language from the user's task description.

    Returns (framework_key, language) or None if no framework detected.
    """
    lowered = task.lower()
    for key, pattern, lang in _TASK_FRAMEWORK_PATTERNS:
        if re.search(pattern, lowered):
            return key, lang
    return None


def _framework_prompt_section(framework_key: str, language: str) -> str:
    """Return framework-specific rules for the system prompt."""
    rules = _FRAMEWORK_RULES.get(framework_key)
    if rules:
        return rules
    return _DEFAULT_FRAMEWORK_RULES.get(language, "")


def _detect_framework(self) -> str:
    """Detect project framework from config files."""
    cwd = Path.cwd()
    detectors = [
        ("Next.js", ["next.config.js", "next.config.ts", "next.config.mjs"]),
        ("React + Vite", ["vite.config.ts", "vite.config.js"]),
        ("Vue", ["vue.config.js"]),
        ("Svelte", ["svelte.config.js"]),
        ("Angular", ["angular.json"]),
        ("Django", ["manage.py"]),
        ("Flask", ["app.py", "wsgi.py"]),
        ("FastAPI", ["main.py"]),
        ("Express", ["app.js", "server.js"]),
        ("Go", ["go.mod"]),
        ("Rust", ["Cargo.toml"]),
        ("Flutter", ["pubspec.yaml"]),
    ]
    for fw, files in detectors:
        if any((cwd / f).exists() for f in files):
            if fw == "FastAPI":
                if _has_fastapi_dependency(cwd):
                    return fw
                continue
            if fw == "React + Vite":
                if (cwd / "vite.config.ts").exists() or (cwd / "vite.config.js").exists():
                    if (cwd / "src" / "App.vue").exists() or any((cwd / f).exists() for f in ["vue.config.js"]):
                        return "Vue + Vite"
                return fw
            return fw
    pkg_json = cwd / "package.json"
    if pkg_json.exists():
        try:
            pkg = json.loads(pkg_json.read_text())
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if "next" in deps: return "Next.js"
            if "react" in deps: return "React"
            if "vue" in deps: return "Vue"
            if "svelte" in deps: return "Svelte"
            if "express" in deps: return "Express"
        except json.JSONDecodeError:
            pass
    return "vanilla"


def _has_fastapi_dependency(cwd: Path) -> bool:
    """Return True if fastapi appears in pyproject.toml or requirements.txt."""
    for candidate in ["pyproject.toml", "requirements.txt", "requirements-dev.txt"]:
        path = cwd / candidate
        if path.exists():
            try:
                if "fastapi" in path.read_text(encoding="utf-8").lower():
                    return True
            except OSError:
                pass
    return False


def _detect_package_manager(self) -> str | None:
    cwd = Path.cwd()
    if (cwd / "package.json").exists():
        if (cwd / "pnpm-lock.yaml").exists(): return "pnpm"
        if (cwd / "yarn.lock").exists(): return "yarn"
        if (cwd / "bun.lockb").exists(): return "bun"
        return "npm"
    if (cwd / "pyproject.toml").exists(): return "pip"
    if (cwd / "Pipfile").exists(): return "pipenv"
    if (cwd / "go.mod").exists(): return "go"
    if (cwd / "Cargo.toml").exists(): return "cargo"
    return None


def _get_current_task(self) -> str:
    """Extract the current user task from conversation messages."""
    if self._messages:
        for msg in reversed(self._messages):
            content = msg.get("content")
            if msg.get("role") == "user" and isinstance(content, str):
                return content
    return ""


def _build_system_prompt(self) -> str:
    """Build a rich system prompt aware of the project stack and the user's current task."""
    fw = self._framework or self._detect_framework()
    pkg_mgr = self._detect_package_manager() or "auto"
    cwd = Path.cwd()
    cwd_name = cwd.name

    has_frontend = any(
        (cwd / d).is_dir()
        for d in ["frontend", "client", "web", "app", "src/app", "src/pages"]
    )
    has_backend = any(
        (cwd / d).is_dir()
        for d in ["backend", "server", "api", "src/api"]
    )
    has_docker = (cwd / "docker-compose.yml").exists() or (cwd / "docker-compose.yaml").exists()
    has_tests = any(
        (cwd / d).is_dir()
        for d in ["tests", "test", "__tests__", "spec"]
    )

    stack_parts: list[str] = []
    if has_frontend and has_backend:
        stack_parts.append("fullstack monorepo")
    if has_docker:
        stack_parts.append("Docker Compose")
    if has_tests:
        stack_parts.append("test suite present")
    stack_line = f"Stack: {', '.join(stack_parts)}" if stack_parts else ""

    # ── Detect framework from the current task ──────────────────
    current_task = _get_current_task(self)
    detected = _detect_framework_from_task(current_task)
    task_fw_key = detected[0] if detected else None
    task_lang = detected[1] if detected else None

    context = f"""You are WIDDX, an expert AI software engineer working in the terminal.

Project: {cwd_name}  |  Framework: {fw}  |  Package manager: {pkg_mgr}
{stack_line}

## Tools
- Read(file_path, offset?, limit?)          — read a file; always read before editing
- Write(file_path, content, overwrite?)     — create or overwrite a file
- Edit(file_path, old_string, new_string)   — precise string replacement (include 3+ lines of context)
- Grep(pattern, path?)                      — regex search across files
- Glob(pattern, path?)                      — find files by pattern
- ListDir(path)                             — explore directory structure
- Bash(command, timeout?)                   — run shell commands
- WebSearch(query)                          — search documentation or the web

## Rules
1. Always Read a file before editing — never guess its contents.
2. Use ListDir and Glob to explore unfamiliar directories first.
3. Write complete, working code — no placeholders, no TODOs, no "..." ellipsis.
4. After writing code, verify it with Bash (run it, lint it, or test it).
5. If a test suite exists, run it after any change.
6. For fullstack tasks: backend first → frontend → wire together.
7. Use Edit for targeted changes; use Write(overwrite=true) only for full rewrites.
8. When a command fails, read the error carefully before retrying.
9. Prefer small, focused changes over large rewrites.
10. Never truncate file content when writing — always write the complete file.
"""

    # ── Inject framework-specific rules ─────────────────────────
    if task_fw_key and task_lang:
        fw_section = _framework_prompt_section(task_fw_key, task_lang)
        if fw_section:
            context += "\n" + fw_section
    elif fw != "vanilla":
        context += f"\n## Framework\nThis project uses {fw}. Use the appropriate conventions for this framework.\n"

    context += f"""
## Project context
{self._project_context or "(run /index to scan project)"}
"""

    if self._project_md:
        context += f"\n## Project Memory (WIDDX.md)\n{self._project_md[:4000]}"

    skill_manager = getattr(self, "_skill_manager", None)
    if skill_manager:
        task = getattr(self, "_current_task", "") or ""
        active_skills = skill_manager.match_skills(task)
        if active_skills:
            context += "\n\n## Relevant Skills\n" + "\n\n".join(active_skills)

        missing = skill_manager.missing_domains(task)
        if missing:
            context += (
                "\n\n## Unfamiliar Technologies Detected\n"
                + ", ".join(missing)
                + f"\nSuggest: `/bootstrap {missing[0]}` to learn this technology."
            )

    return context.strip()
