"""Tool loop display — sci-fi terminal visual language.

Every tool call is a "system operation" with a glowing indicator,
a result sub-line, and an optional inline diff.

Visual grammar:
  ⏺  tool call header   (colored by operation type)
  ⎿  result / output    (dim, indented)
  │  diff line          (dim prefix)
  ◆  section / event    (brand cyan)
  ↳  footer metrics     (dim)
"""
from __future__ import annotations

import difflib

from ..ui.arabic import _d


def _get_console():
    from .. import ui
    return ui.get_console()


def _reshape_line(text: str) -> str:
    return _d(text)


def _short_path(path: str) -> str:
    """Last 2 path components — keeps display compact."""
    parts = path.replace("\\", "/").split("/")
    return "/".join(parts[-2:]) if len(parts) > 2 else path


# ── Tool → color mapping ─────────────────────────────────────────────
# Read / explore  → sky blue   (passive, safe)
# Write / create  → matrix green (constructive)
# Edit            → amber       (modifying)
# Bash            → amber       (executing)
# Web             → magenta     (external)

_TOOL_STYLE: dict[str, str] = {
    "Read":      "tool_read",
    "ListDir":   "tool_read",
    "Glob":      "tool_read",
    "Grep":      "tool_read",
    "WebSearch": "tool_web",
    "Write":     "tool_write",
    "Edit":      "tool_shell",
    "Bash":      "tool_shell",
}


def _tool_label(name: str, args: dict) -> str:
    """Compact argument string shown inside ToolName(…)."""
    if name == "Read":
        fp = args.get("file_path", "")
        offset = args.get("offset", 0)
        limit = args.get("limit", -1)
        suffix = f":{offset}" if offset else ""
        suffix += f"+{limit}" if (limit and limit != -1) else ""
        return f"{_short_path(fp)}{suffix}"
    if name in ("Write", "Edit"):
        return _short_path(args.get("file_path", ""))
    if name == "Grep":
        pat = args.get("pattern", "")
        path = args.get("path", ".")
        pp = f", {_short_path(path)}" if path and path != "." else ""
        return f'"{pat[:40]}{"…" if len(pat) > 40 else ""}"{pp}'
    if name == "Glob":
        return f'"{args.get("pattern", "")}"'
    if name == "Bash":
        cmd = args.get("command", "")
        return f'"{cmd[:65]}{"…" if len(cmd) > 65 else ""}"'
    if name == "WebSearch":
        q = args.get("query", "")
        return f'"{q[:55]}{"…" if len(q) > 55 else ""}"'
    if name == "ListDir":
        return _short_path(args.get("path", "."))
    if name.startswith("mcp__"):
        parts = name[5:].split("__", 1)
        return parts[1] if len(parts) > 1 else ""
    return ""


def print_tool_call(name: str, args: dict) -> None:
    """Print the tool call header.

    ⏺ Read(src/app.py)
    ⏺ Write(src/utils.py)
    """
    c = _get_console()
    style = _TOOL_STYLE.get(name, "brand")
    label = _tool_label(name, args)

    display_name = name
    if name.startswith("mcp__"):
        parts = name[5:].split("__", 1)
        display_name = f"mcp:{parts[0]}"
        label = parts[1] if len(parts) > 1 else ""

    c.print(f"\n[{style}]⏺[/] [bold]{display_name}[/][dim]({label})[/]")


def print_tool_result(name: str, output: dict) -> None:
    """Print the ⎿ result sub-line.

    ⎿  120 lines read
    ⎿  Error: file not found
    """
    c = _get_console()
    hint = _tool_hint(name, output)
    if not hint:
        return
    if "error" in output:
        c.print(f"  [dim]⎿[/]  [error]{hint}[/]")
    else:
        c.print(f"  [dim]⎿[/]  [dim]{hint}[/]")


def _tool_hint(name: str, output: dict) -> str:
    """One-line result summary."""
    if "error" in output:
        return f"Error: {output['error'][:100]}"
    if name == "Read":
        lines = output.get("total_lines", 0)
        return f"{lines} lines read" if lines else "read"
    if name == "Write":
        written = output.get("written", 0)
        v = output.get("verification") or {}
        base = f"Written ({_fmt_bytes(written)})"
        if v.get("verified"):
            return f"{base} · verified ✓"
        if "error" in v:
            return f"{base} · verification failed"
        return base
    if name == "Edit":
        n = output.get("replacements", 1)
        v = output.get("verification") or {}
        s = f"{n} replacement{'s' if n != 1 else ''}"
        if v.get("verified"):
            return f"{s} · verified ✓"
        if "error" in v:
            return f"{s} · verification failed"
        return s
    if name == "Grep":
        count = output.get("count", 0)
        return f"{count} match{'es' if count != 1 else ''}"
    if name == "Glob":
        count = output.get("count", 0)
        return f"{count} file{'s' if count != 1 else ''} found"
    if name == "Bash":
        code = output.get("exit_code", 0)
        stdout = (output.get("stdout") or "").strip()
        stderr = (output.get("stderr") or "").strip()
        first = (stdout or stderr).split("\n")[0][:80]
        if code == 0:
            return first if first else "ok"
        return f"exit {code}" + (f" · {first}" if first else "")
    if name == "WebSearch":
        count = output.get("count", 0)
        return f"{count} result{'s' if count != 1 else ''}"
    if name == "ListDir":
        count = output.get("count", 0)
        return f"{count} item{'s' if count != 1 else ''}"
    return ""


def _fmt_bytes(n: int) -> str:
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f}KB"
    return f"{n / (1024 * 1024):.1f}MB"


def _render_diff(old_content: str, new_content: str, file_path: str) -> None:
    """Compact inline diff — max 6 changed lines per side.

    │ - removed line
    │ + added line
    │   … N more lines
    """
    c = _get_console()
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    diff = list(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=file_path, tofile=file_path,
        n=1,
    ))
    if not diff:
        return

    removed = added = 0
    max_each = 6
    total_changes = sum(
        1 for ln in diff
        if ln.startswith(("+", "-")) and not ln.startswith(("---", "+++"))
    )

    for line in diff:
        if line.startswith(("---", "+++", "@@")):
            continue
        stripped = line[1:].rstrip()[:95]
        if line.startswith("-") and removed < max_each:
            c.print(f"  [dim]│[/] [red]- {stripped}[/]")
            removed += 1
        elif line.startswith("+") and added < max_each:
            c.print(f"  [dim]│[/] [green]+ {stripped}[/]")
            added += 1

    shown = removed + added
    if total_changes > shown:
        rest = total_changes - shown
        c.print(f"  [dim]│  … {rest} more line{'s' if rest != 1 else ''}[/]")


def _summarize_final(self) -> str:
    for m in reversed(self._messages):
        if m["role"] == "assistant" and isinstance(m.get("content"), str) and m["content"]:
            return str(m["content"])
    return "Task completed."


def _format_result(self, text: str, elapsed: float, steps: int,
                   *, use_markdown: bool = True) -> str:
    """Show the metrics footer after a completed response.

    When use_markdown=False the text was already rendered live during
    streaming — this function only prints the ↳ footer line.
    """
    c = _get_console()

    # Only re-render if the text was NOT already streamed to the terminal.
    if use_markdown and text:
        from .. import ui
        ui.render_markdown(_d(text))
    # use_markdown=False → text already on screen, skip entirely

    # ── Metrics footer ────────────────────────────────────────────
    tokens_in  = getattr(self._router, "_session_input_tokens", 0)
    tokens_out = getattr(self._router, "_session_output_tokens", 0)
    total_tok  = tokens_in + tokens_out
    cost       = getattr(self._router, "_session_cost", 0.0)
    elapsed_ms = int(elapsed * 1000)
    n_tools    = getattr(self, "_tool_calls_count", 0)

    parts: list[str] = []
    if total_tok > 0:
        tok_str = f"{total_tok / 1000:.1f}k" if total_tok >= 1000 else str(total_tok)
        parts.append(f"{tok_str} tokens")
    if cost > 0:
        parts.append(f"${cost:.4f}")
    if elapsed_ms > 0:
        if elapsed_ms < 1000:
            parts.append(f"{elapsed_ms}ms")
        elif elapsed_ms < 60_000:
            parts.append(f"{elapsed_ms / 1000:.1f}s")
        else:
            parts.append(f"{elapsed_ms / 60_000:.1f}m")
    if n_tools > 0:
        parts.append(f"{n_tools} tool call{'s' if n_tools != 1 else ''}")

    if parts:
        c.print(f"\n  [dim]↳  {' · '.join(parts)}[/]")

    return text
