"""Tool loop — tool definitions and execution logic."""
from __future__ import annotations

from typing import Any
import json
import subprocess
import sys
from pathlib import Path as _Path

# Each tool carries a ``schema`` key with a complete JSON Schema ``parameters``
# object.  This is used verbatim by ``_build_api_tools`` so DeepSeek always
# receives well-typed schemas — no guessing from description strings.
TOOL_DEFINITIONS = [
    {
        "name": "Read",
        "description": "Read file contents. Required before editing.",
        "schema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to read.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of lines to read (optional).",
                    "default": -1,
                },
                "offset": {
                    "type": "integer",
                    "description": "Line number to start reading from (0-indexed, optional).",
                    "default": 0,
                },
            },
            "required": ["file_path"],
        },
    },
    {
        "name": "Write",
        "description": "Create a new file. Use overwrite=true to replace an existing file completely.",
        "schema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Destination file path.",
                },
                "content": {
                    "type": "string",
                    "description": "Full content to write into the file.",
                },
                "overwrite": {
                    "type": "boolean",
                    "description": "Set to true to replace an existing file. Defaults to false.",
                    "default": False,
                },
            },
            "required": ["file_path", "content"],
        },
    },
    {
        "name": "Edit",
        "description": "Edit an existing file using exact string replacement. Include 3+ lines of context in old_string.",
        "schema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to edit.",
                },
                "old_string": {
                    "type": "string",
                    "description": "Exact text to find and replace (must be unique in the file).",
                },
                "new_string": {
                    "type": "string",
                    "description": "Replacement text.",
                },
            },
            "required": ["file_path", "old_string", "new_string"],
        },
    },
    {
        "name": "Grep",
        "description": "Search file contents with a regex pattern.",
        "schema": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern to search for.",
                },
                "path": {
                    "type": "string",
                    "description": "Directory or file path to search in. Defaults to '.'.",
                    "default": ".",
                },
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "Glob",
        "description": "Find files matching a glob pattern.",
        "schema": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern, e.g. '**/*.py'.",
                },
                "path": {
                    "type": "string",
                    "description": "Root directory to search from. Defaults to '.'.",
                    "default": ".",
                },
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "Bash",
        "description": "Execute a whitelisted shell command.",
        "schema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Shell command to execute.",
                },
                "working_dir": {
                    "type": "string",
                    "description": "Working directory for the command. Defaults to current project root.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds. Defaults to 60.",
                    "default": 60,
                },
            },
            "required": ["command"],
        },
    },
    {
        "name": "WebSearch",
        "description": "Search the web for current information.",
        "schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query string.",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "ListDir",
        "description": "List directory contents to understand project structure.",
        "schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory path to list.",
                },
            },
            "required": ["path"],
        },
    },
]


def _parse_args(self, raw_args: str) -> dict[Any, Any]:
    try:
        return dict(json.loads(raw_args)) if isinstance(raw_args, str) else raw_args
    except json.JSONDecodeError:
        return {}


def _execute_tool(self, name: str, raw_args: str) -> dict:
    from ..tools import file_ops, search, shell, web

    args = self._parse_args(raw_args)

    # ── PreToolUse hooks — a blocked result prevents tool execution ──
    hook_manager = getattr(self, "_hook_manager", None)
    if hook_manager is not None:
        pre_results = hook_manager.fire("PreToolUse", {"tool": name, "args": str(args)})
        if any(r.blocked for r in pre_results):
            return {"error": f"Hook blocked tool call: {name}"}

    # ── Tool dispatch ────────────────────────────────────────────────
    result: dict

    if name == "Read":
        result = file_ops.tool_read_file(
            file_path=args.get("file_path", ""),
            start_line=args.get("offset", 0),
            end_line=args.get("limit", -1),
        )

    elif name == "Write":
        fp = args.get("file_path", "")
        overwrite = bool(args.get("overwrite", False))
        if self._permissions.ask("write", fp, "file") != "allow":
            result = {"error": "Permission denied"}
        else:
            # Capture old content for diff display (only if overwriting)
            old_content: str | None = None
            if overwrite:
                try:
                    old_content = _Path(fp).expanduser().resolve().read_text(encoding="utf-8")
                except OSError:
                    old_content = None
            result = file_ops.tool_write_file(
                file_path=fp,
                content=args.get("content", ""),
                overwrite=overwrite,
            )
            if "error" not in result:
                if overwrite and fp in self._edited_files:
                    pass
                elif overwrite:
                    self._edited_files.append(fp)
                else:
                    self._created_files.append(fp)
                # Attach diff for display layer (overwrite only — new files have no diff)
                if overwrite and old_content is not None:
                    result["_diff_old"] = old_content
                    result["_diff_new"] = args.get("content", "")
                    result["_diff_path"] = fp
                # Verification: auto-fix loop (syntax check + test run + re-fix)
                verify_result = self._verifier.verify_step([fp], auto_fix=True)
                if not verify_result.passed:
                    result["verification"] = {
                        "error": "Verification failed",
                        "output": verify_result.output[:500],
                        "fix_attempts": verify_result.fix_attempts,
                    }
                else:
                    result["verification"] = {"verified": True}

    elif name == "Edit":
        fp = args.get("file_path", "")
        # Capture old content for diff display
        old_content_edit: str | None = None
        try:
            old_content_edit = _Path(fp).expanduser().resolve().read_text(encoding="utf-8")
        except OSError:
            old_content_edit = None
        result = file_ops.tool_edit_file(
            file_path=fp,
            old_string=args.get("old_string", ""),
            new_string=args.get("new_string", ""),
        )
        if "error" not in result:
            if fp not in self._edited_files:
                self._edited_files.append(fp)
            # Attach diff for display layer
            if old_content_edit is not None:
                try:
                    new_content_edit = _Path(fp).expanduser().resolve().read_text(encoding="utf-8")
                    result["_diff_old"] = old_content_edit
                    result["_diff_new"] = new_content_edit
                    result["_diff_path"] = fp
                except OSError:
                    pass
            # Verification: auto-fix loop (syntax check + test run + re-fix)
            verify_result = self._verifier.verify_step([fp], auto_fix=True)
            if not verify_result.passed:
                result["verification"] = {
                    "error": "Verification failed",
                    "output": verify_result.output[:500],
                    "fix_attempts": verify_result.fix_attempts,
                }
            else:
                result["verification"] = {"verified": True}

    elif name == "Grep":
        result = search.tool_grep(
            pattern=args.get("pattern", ""),
            directory=args.get("path", "."),
        )

    elif name == "Glob":
        result = search.tool_glob(
            pattern=args.get("pattern", ""),
            directory=args.get("path", "."),
        )

    elif name == "Bash":
        cmd = args.get("command", "")
        # Every shell command goes through the permission manager.
        # PermissionManager.ask() handles the decision tree:
        #   - safe read-only commands → allow silently
        #   - destructive commands → always confirm inline
        #   - first shell command of session → single Y/n prompt
        #   - session denied/approved → deny/allow
        # tool_shell() adds a second layer: FORBIDDEN set + chaining detection.
        if self._permissions.ask("shell", cmd, "shell") != "allow":
            result = {"error": "Permission denied"}
        else:
            result = shell.tool_shell(
                command=cmd,
                working_dir=args.get("working_dir", "."),
                session_approved=self._permissions._session_approved,
            )

    elif name == "WebSearch":
        result = web.tool_web_search(query=args.get("query", ""))

    elif name == "ListDir":
        result = _tool_list_dir(args.get("path", "."))

    elif name.startswith("mcp__"):
        # Route MCP tool calls to the MCPRegistry
        mcp_registry = getattr(self, "_mcp_registry", None)
        if mcp_registry is not None:
            result = mcp_registry.execute(name, args)
        else:
            result = {"error": f"MCP registry not available for tool: {name}"}

    else:
        result = {"error": f"Unknown tool: {name}"}

    # ── PostToolUse hooks — fire async (non-blocking) ────────────────
    if hook_manager is not None:
        hook_manager.fire_async("PostToolUse", {"tool": name, "result": str(result)[:200]})

    return result


def _find_tsconfig(file_path: _Path) -> _Path | None:
    """Walk up from file_path looking for a tsconfig.json."""
    for parent in file_path.parent.parents:
        tsconfig = parent / "tsconfig.json"
        if tsconfig.exists():
            return tsconfig
    return None


def _verify_file(file_path: str) -> dict | None:
    """Run a fast syntax/compile check on a file after it is written or edited.

    Returns ``{"verified": True}`` on success, ``{"error": "...", "output": "..."}``
    on failure, or ``None`` when no applicable checker exists for the file type.

    Checkers (in priority order):
      - Python  → python -m py_compile <file>
      - pytest  → python -m pytest <file> -x -q  (only for test_*.py files)
      - JS      → node --check <file>
    """
    path = _Path(file_path).expanduser().resolve()
    if not path.exists():
        return None

    suffix = path.suffix.lower()

    # ── Python syntax check ───────────────────────────────────────
    if suffix == ".py":
        result = subprocess.run(
            [sys.executable, "-m", "py_compile", str(path)],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            return {"error": "Python syntax error", "output": (result.stderr or result.stdout).strip()}

        return {"verified": True}

    # ── JavaScript / TypeScript syntax check ───────────────────────
    if suffix in (".js", ".jsx"):
        result = subprocess.run(
            ["node", "--check", str(path)],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            return {"error": "JavaScript syntax error", "output": (result.stderr or result.stdout).strip()}
        return {"verified": True}

    # TypeScript check via tsc --noEmit (only if a tsconfig.json exists nearby)
    if suffix in (".ts", ".tsx"):
        tsconfig = _find_tsconfig(path)
        if tsconfig is not None:
            result = subprocess.run(
                ["npx", "tsc", "--noEmit", "--project", str(tsconfig), str(path)],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                return {"error": "TypeScript error", "output": (result.stderr or result.stdout).strip()[:2000]}
            return {"verified": True}
        # No tsconfig found — skip type checking to avoid false positives
        return {"verified": True, "note": "TypeScript check skipped (no tsconfig.json found)"}

    return None


def _tool_list_dir(path: str) -> dict:
    """List directory contents, ignoring noise folders."""
    _IGNORE = {
        "node_modules", "__pycache__", ".git", ".venv", "venv",
        ".next", "dist", "build", ".cache", "*.egg-info",
    }
    root = _Path(path).expanduser().resolve()
    if not root.exists():
        return {"error": f"Path not found: {path}"}
    if not root.is_dir():
        return {"error": f"Not a directory: {path}"}
    entries = []
    try:
        for item in sorted(root.iterdir()):
            if item.name in _IGNORE or item.name.startswith("."):
                continue
            kind = "dir" if item.is_dir() else "file"
            size = item.stat().st_size if item.is_file() else 0
            entries.append({"name": item.name, "type": kind, "size": size})
    except PermissionError:
        return {"error": f"Permission denied: {path}"}
    return {"path": str(root), "entries": entries, "count": len(entries)}
