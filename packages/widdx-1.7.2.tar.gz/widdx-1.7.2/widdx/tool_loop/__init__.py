"""Tool loop — Claude Code pattern: model ↔ tools ↔ model via native Function Calling.

Experience:
  - Build-Test-Fix loop: generate → lint → test → fix → repeat
  - Multi-agent collaboration for complex tasks
  - Framework-aware prompts
  - Quality gates before task completion
  - Streaming output for real-time feedback
"""
from __future__ import annotations

import json
import sys
import time

from ..hooks import HookManager
from ..mcp import MCPRegistry
from ..permissions import PermissionManager
from ..repair_memory import RepairMemory
from ..skills import SkillManager
from ..verifier import ProjectVerifier
from .display import (
    _format_result,
    _get_console,
    _render_diff,
    _reshape_line,
    _short_path,
    _summarize_final,
    _tool_hint,
    _tool_label,
    print_tool_call,
    print_tool_result,
)
from .system_prompt import _build_system_prompt, _detect_framework, _detect_package_manager
from .tools import TOOL_DEFINITIONS, _execute_tool, _parse_args, _tool_list_dir, _verify_file


class ToolLoop:
    """World-class agent loop with Build-Test-Fix cycle.

    Claude Code pattern:
      user message → model decides: tool_call or text_response
      if tool_call → execute locally → feed result back → repeat
      if text_response → verify quality gates → return to user
    """

    # ── Injected methods from sub-modules ──────────────────────────
    _detect_framework = _detect_framework
    _detect_package_manager = _detect_package_manager
    _build_system_prompt = _build_system_prompt
    _parse_args = _parse_args
    _execute_tool = _execute_tool
    _verify_file = staticmethod(_verify_file)
    _summarize_final = _summarize_final
    _format_result = _format_result

    TOOL_DEFINITIONS = TOOL_DEFINITIONS

    def __init__(self, router, max_steps: int = 100) -> None:
        self._router = router
        self._max_steps = max_steps
        self._permissions = PermissionManager()
        self._messages: list[dict] = []
        self._project_context = ""
        self._framework: str | None = None
        self._created_files: list[str] = []
        self._edited_files: list[str] = []
        self._test_attempts = 0
        self._max_test_attempts = 3
        self._tool_calls_count = 0
        self._total_cost = 0
        self._backups: dict[str, str] = {}
        # Tracks consecutive identical errors per (tool, args) key for retry loop.
        self._tool_error_counts: dict[str, dict] = {}
        self._project_md: str = ""
        self._skill_manager = SkillManager()
        self._skill_manager.load()
        self._repair_memory = RepairMemory(
            self._router.memory,
            getattr(self._router, 'config', None),
        )
        self._verifier = ProjectVerifier(
            router=self._router, repair_memory=self._repair_memory,
        )
        self._hook_manager = HookManager(router=self._router)
        self._hook_manager.load()
        mcp_cfg_path = self._router.config.get("mcp", {}).get("config_path", "~/.widdx/mcp.json")
        self._mcp_registry = MCPRegistry(config_path=mcp_cfg_path)
        self._mcp_registry.load()

    def set_project_context(self, context: str) -> None:
        self._project_context = context

    def set_framework(self, framework: str) -> None:
        self._framework = framework

    def set_project_md(self, content: str) -> None:
        self._project_md = content

    def set_skill_manager(self, skill_manager: SkillManager) -> None:
        """Replace the default SkillManager — useful for dependency injection in tests."""
        self._skill_manager = skill_manager

    def set_hook_manager(self, hook_manager: HookManager) -> None:
        """Replace the default HookManager — useful for dependency injection in tests."""
        self._hook_manager = hook_manager

    def set_mcp_registry(self, mcp_registry: MCPRegistry) -> None:
        """Replace the default MCPRegistry — useful for dependency injection in tests."""
        self._mcp_registry = mcp_registry

    def clear_context(self) -> None:
        self._messages.clear()
        self._created_files.clear()
        self._edited_files.clear()
        self._backups.clear()
        self._tool_error_counts.clear()
        self._test_attempts = 0

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self, user_message: str, conversation_history: list[dict] | None = None) -> str:
        """Full agent loop with streaming output and persistent context."""
        if conversation_history:
            self._messages = list(conversation_history)
        else:
            self._messages = []
        self._messages.append({"role": "user", "content": user_message})

        self._created_files.clear()
        self._edited_files.clear()
        self._test_attempts = 0
        self._tool_calls_count = 0
        self._total_cost = 0
        self._tool_error_counts.clear()

        c = _get_console()
        start_time = time.time()

        for step in range(self._max_steps):
            system = self._build_system_prompt()

            # ── Context size warning ──────────────────────────────
            estimated = self._router._estimate_tokens(self._messages)
            system_est = len(system) // 4
            total_est = estimated + system_est
            if total_est > 55000:
                c.print(f"\n  [warning]⚠ Context ~{total_est//1000}K tokens — nearing limit. Use /compact.[/]")
            if total_est > 62000:
                return "Error: Context too large. Use /compact to free space, then retry."

            # ── Stream the LLM response ───────────────────────────
            all_tools = TOOL_DEFINITIONS + self._mcp_registry.tool_definitions()
            stream = self._router.call_with_tools_streaming(
                system, self._messages, all_tools
            )

            tool_calls = []
            full_text = ""
            first_token = True
            _line_buffer = ""
            _stream_renderer = None

            # ── Animated thinking indicator with Rich spinner ─────
            try:
                from rich.progress import Progress, SpinnerColumn, TextColumn
                _thinking_progress = Progress(
                    SpinnerColumn(spinner_name="dots12", style="brand"),
                    TextColumn("[dim]Thinking...[/]"),
                    console=c,
                    transient=True,
                )
                _thinking_task = _thinking_progress.add_task("thinking", total=None)
                _thinking_progress.start()
                _has_thinking_spinner = True
            except Exception:
                c.print("\n[brand]⏺[/]", end=" ")
                sys.stdout.flush()
                _has_thinking_spinner = False

            for event in stream:
                etype = event.get("type", "")

                if etype == "error":
                    if _has_thinking_spinner:
                        _thinking_progress.stop()
                    c.print(f"\n[error]✗ {event['content']}[/]")
                    return f"Error: {event['content']}"

                if etype == "text":
                    if first_token:
                        if _has_thinking_spinner:
                            _thinking_progress.stop()
                        from .. import ui
                        _stream_renderer = ui.LiveStreamRenderer()
                        _stream_renderer.start()
                        c.print()  # newline past the indicator
                        first_token = False
                    token = event["content"]
                    full_text += token
                    _line_buffer += token

                    if _stream_renderer is not None:
                        _stream_renderer.feed(token)
                    # No else — if renderer exists, it handles all output

                if etype == "tool_call":
                    if _stream_renderer is not None:
                        _stream_renderer.finish()
                        _stream_renderer = None
                    tool_calls.append(event)

                if etype == "done":
                    usage = event.get("usage", {})
                    if usage:
                        inp = usage.get("input", 0)
                        out = usage.get("output", 0)
                        pricing = self._router.PRICING.get(
                            self._router.executor_model,
                            {"input": 0.27, "output": 1.10}
                        )
                        self._total_cost += (
                            (inp / 1_000_000) * pricing["input"]
                            + (out / 1_000_000) * pricing["output"]
                        )
                    # Stop live renderer — content already on screen
                    if _stream_renderer is not None:
                        _stream_renderer.finish()
                        _stream_renderer = None
                    break

            # ── Stop thinking spinner if still running ───────────
            if _has_thinking_spinner:
                try:
                    _thinking_progress.stop()
                except Exception:
                    pass

            # ── No tool calls → return final text ────────────────
            if not tool_calls:
                if full_text:
                    self._messages.append({"role": "assistant", "content": full_text})
                    elapsed = time.time() - start_time
                    # Text already rendered by LiveStreamRenderer during streaming.
                    # _format_result must NOT re-print it — only show the footer.
                    return self._format_result(full_text, elapsed, step,
                                               use_markdown=False)
                return "Done."

            # ── Tool calls detected ───────────────────────────────
            self._tool_calls_count += len(tool_calls)

            assistant_msg: dict = {"role": "assistant", "content": full_text or None}
            assistant_msg["tool_calls"] = [
                {"id": tc.get("id", f"call_{i}"), "type": "function",
                 "function": {"name": tc["name"], "arguments": tc["arguments"]}}
                for i, tc in enumerate(tool_calls)
            ]
            self._messages.append(assistant_msg)

            for i, tc in enumerate(tool_calls):
                tool_name = tc["name"]
                raw_args = tc.get("arguments", "{}")
                args = self._parse_args(raw_args)

                # Claude Code style: ⏺ ToolName(arg)
                print_tool_call(tool_name, args)

                tool_output = self._execute_tool(tool_name, raw_args)

                # ── Smart retry: stop on repeated identical errors ──
                tool_key = f"{tool_name}:{raw_args}"
                if "error" in tool_output:
                    prev = self._tool_error_counts.get(tool_key, {"count": 0, "msg": ""})
                    same_error = prev["msg"] == tool_output["error"]
                    if same_error and prev["count"] >= 1:
                        c.print(
                            f"  [dim]⎿[/]  [error]Same error twice — stopping to avoid loop[/]\n"
                            f"  [dim]   {_reshape_line(tool_output['error'][:80])}[/]"
                        )
                        self._messages.append({
                            "role": "tool",
                            "tool_call_id": tc.get("id", f"call_{i}"),
                            "content": json.dumps({
                                "error": tool_output["error"],
                                "fatal": True,
                                "note": "This tool failed twice with the same error. Do NOT retry. Explain the problem to the user.",
                            }, ensure_ascii=False),
                        })
                        continue
                    self._tool_error_counts[tool_key] = {
                        "count": prev["count"] + 1,
                        "msg": tool_output["error"],
                    }
                else:
                    self._tool_error_counts.pop(tool_key, None)

                # ⎿ result line
                print_tool_result(tool_name, tool_output)

                # Inline diff for Write (overwrite) and Edit
                if isinstance(tool_output, dict) and "_diff_old" in tool_output:
                    _render_diff(
                        tool_output["_diff_old"],
                        tool_output["_diff_new"],
                        tool_output.get("_diff_path", ""),
                    )

                # Verification failure — surface immediately
                verification = tool_output.get("verification") if isinstance(tool_output, dict) else None
                if verification and "error" in verification:
                    c.print("  [dim]⎿[/]  [warning]Verification failed[/]")
                    if verification.get("output"):
                        for vline in verification["output"].splitlines()[:5]:
                            c.print(f"  [dim]   {_reshape_line(vline)}[/]")

                # Strip internal display keys before sending to LLM
                llm_output = {
                    k: v for k, v in tool_output.items()
                    if not k.startswith("_diff_")
                } if isinstance(tool_output, dict) else tool_output

                self._messages.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", f"call_{i}"),
                    "content": json.dumps(llm_output, ensure_ascii=False),
                })

        return self._summarize_final()

    # ------------------------------------------------------------------
    # Compaction
    # ------------------------------------------------------------------

    def compact(self) -> str:
        """Summarize conversation history to save context space."""
        if len(self._messages) <= 6:
            return "Conversation is already short — no compaction needed."

        keep = self._messages[-6:]
        to_summarize = self._messages[:-6]

        if not to_summarize:
            return "Nothing to compact."

        history_text = ""
        for msg in to_summarize:
            role = msg.get("role", "?")
            content = msg.get("content", "")
            if content and isinstance(content, str):
                history_text += f"[{role}] {content[:200]}\n"

        prompt = (
            "Summarize this coding conversation history in 3-5 bullet points. "
            "Include what was built, key decisions, and current state. "
            "Be concise — this will replace the full history to save context.\n\n"
            f"{history_text[:6000]}"
        )

        result = self._router.call_executor(
            "You are a conversation summarizer. Return only the summary, no preamble.",
            prompt,
            max_tokens=1024,
        )

        summary_text = result.get("text", "") if "text" in result else ""
        if not summary_text or "error" in result:
            return "Compaction failed — try again or use /clear."

        old_count = len(to_summarize)
        old_tokens = self._router._estimate_tokens(to_summarize)

        self._messages = [
            {"role": "user", "content": f"[Conversation summary from earlier]\n{summary_text}"},
            {"role": "assistant", "content": "Understood. I'll use this context for the rest of the session."},
        ] + keep

        new_tokens = self._router._estimate_tokens(self._messages)
        saved = old_tokens - new_tokens

        return f"Compacted {old_count} messages → ~{saved} tokens saved. Kept last {len(keep)} messages."
