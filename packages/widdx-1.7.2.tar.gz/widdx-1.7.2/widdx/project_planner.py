"""widdx/project_planner.py — Phased execution for large, complex projects.

Solves three problems identified in the code review:
  1. Context overflow   — splits big tasks into bounded phases
  2. Cross-session loss — persists progress + decisions in MemoryStore
  3. No resume logic   — can restart from the last completed phase

Typical flow:
    planner = ProjectPlanner(router, memory)
    plan    = planner.create_plan("Build a SaaS e-commerce platform")
    planner.execute_plan(plan, agent_factory)
"""
from __future__ import annotations

import contextlib
import json
import logging
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .agent_factory import AgentFactory
    from .memory import MemoryStore
    from .router import AIRouter

logger = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────

_MAX_PHASES = 7          # never split into more than 7 phases
_MIN_PHASES = 2          # always at least 2 phases for complex tasks
_COMPLEXITY_THRESHOLD = 3  # tasks with complexity >= this get phased
_MAX_PHASE_RETRIES = 2     # max retries per phase before escalation


# ── Data classes ─────────────────────────────────────────────────────────────

@dataclass
class Phase:
    """One bounded unit of work within a project plan."""
    id: str
    number: int          # 1-based
    title: str
    goal: str
    deliverables: list[str]
    depends_on: list[str] = field(default_factory=list)   # phase IDs
    status: str = "pending"   # pending | running | done | failed
    output_summary: str = ""
    files_created: list[str] = field(default_factory=list)
    files_edited: list[str] = field(default_factory=list)
    decisions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict) -> Phase:
        return cls(**d)


@dataclass
class ProjectPlan:
    """A full multi-phase execution plan."""
    id: str
    task: str
    phases: list[Phase]
    tech_stack: list[str] = field(default_factory=list)
    architecture_notes: str = ""
    created_at: str = ""
    status: str = "pending"   # pending | running | done | failed | partial

    def to_dict(self) -> dict:
        d = self.__dict__.copy()
        d["phases"] = [p.to_dict() for p in self.phases]
        return d

    @classmethod
    def from_dict(cls, d: dict) -> ProjectPlan:
        phases = [Phase.from_dict(p) for p in d.pop("phases", [])]
        return cls(phases=phases, **d)

    @property
    def completed_phases(self) -> list[Phase]:
        return [p for p in self.phases if p.status == "done"]

    @property
    def pending_phases(self) -> list[Phase]:
        return [p for p in self.phases if p.status == "pending"]

    @property
    def next_phase(self) -> Phase | None:
        """Return the next executable phase (all dependencies satisfied)."""
        done_ids = {p.id for p in self.completed_phases}
        for p in self.phases:
            if p.status == "pending" and all(dep in done_ids for dep in p.depends_on):
                return p
        return None

    def progress_pct(self) -> int:
        if not self.phases:
            return 0
        done = sum(1 for p in self.phases if p.status == "done")
        return int(done / len(self.phases) * 100)


# ── ProjectPlanner ────────────────────────────────────────────────────────────

class ProjectPlanner:
    """Phased execution for large, complex projects.

    Usage::

        planner = ProjectPlanner(router, memory)

        # Create (or resume) a plan
        plan = planner.create_plan("Build SaaS e-commerce in FastAPI + React")
        # Or resume an interrupted project:
        plan = planner.resume_plan("plan_abc123")

        # Execute phase by phase (can be called across sessions)
        planner.execute_plan(plan, agent_factory)
    """

    def __init__(self, router: AIRouter, memory: MemoryStore) -> None:
        self._router = router
        self._memory = memory

    # ── Requirements Analysis ─────────────────────────────────────────────

    def create_spec(self, task: str, agent_factory: object = None) -> str:
        """Analyse requirements and create a specification document.

        Saves the spec to .widdx/spec.md for reference during development.
        """
        from widdx import ui
        c = ui.get_console()

        # Ask clarifying questions
        c.print("  [warning]?[/] [text]Let's clarify the requirements:[/]")
        scope = ui.confirm_with_options(
            "Project scope?",
            ["Small (1-2 features, 1 developer week)",
             "Medium (3-5 features, 2-3 developer weeks)",
             "Large (5+ features, 1+ developer months)"],
            default="Medium (3-5 features, 2-3 developer weeks)",
        )
        users = ui.confirm_with_options(
            "Target users?",
            ["End users (public website/app)",
             "Admin/internal team",
             "API consumers",
             "Both (public + admin)"],
            default="Both (public + admin)",
        )
        auth = ui.confirm_with_options(
            "Authentication required?",
            ["Yes (user login/registration)",
             "Yes (API key based)",
             "No (public access)"],
            default="Yes (user login/registration)",
        )

        # Generate spec using LLM
        system = (
            "You are a senior product manager. Write a concise project specification. "
            "Cover: purpose, core features, user roles, data entities, key workflows. "
            "Be specific but not overly detailed — this is a living document."
        )
        user_msg = (
            f"Project: {task}\n"
            f"Scope: {scope}\n"
            f"Users: {users}\n"
            f"Auth: {auth}\n"
            f"Write a clear specification."
        )
        result = self._router.call_architect(system, user_msg, max_tokens=2048)
        spec_text = result.get("text", "") if not (isinstance(result, dict) and "error" in result) else (
            f"# Specification: {task}\n\n"
            f"## Scope\n{scope}\n\n## Users\n{users}\n\n## Auth\n{auth}\n"
        )

        # Save to .widdx/spec.md
        try:
            from .project_state import get_widdx_dir
            widdx_dir = get_widdx_dir()
            spec_path = widdx_dir / "spec.md"
            header = (
                f"# Specification: {task}\n\n"
                f"**Scope:** {scope}  \n"
                f"**Users:** {users}  \n"
                f"**Authentication:** {auth}  \n"
                f"---\n\n"
            )
            spec_path.write_text(header + spec_text, encoding="utf-8")
            c.print(f"  [success]✓[/] Specification saved to [text].widdx/spec.md[/]")
        except Exception:
            pass

        return spec_text

    # ── Architecture Design ──────────────────────────────────────────────

    def create_architecture(self, task: str, spec: str, agent_factory: object = None) -> str:
        """Design the architecture and save to .widdx/architecture.md."""
        from widdx import ui
        c = ui.get_console()

        system = (
            "You are a senior solutions architect. Design the architecture for this project. "
            "Cover: system context, data model (key entities and relationships), "
            "API design (endpoints), component tree, data flow, "
            "key architectural decisions with rationale. "
            "Be specific and practical."
        )
        user_msg = (
            f"Project: {task}\n\n"
            f"Specification:\n{spec[:2000]}\n\n"
            f"Design the architecture. Focus on concrete models, endpoints, and decisions."
        )
        result = self._router.call_architect(system, user_msg, max_tokens=3072)
        arch_text = result.get("text", "") if not (isinstance(result, dict) and "error" in result) else "Architecture details TBD."

        try:
            from .project_state import get_widdx_dir
            widdx_dir = get_widdx_dir()
            arch_path = widdx_dir / "architecture.md"
            arch_path.write_text(
                f"# Architecture: {task}\n\n---\n\n{arch_text}",
                encoding="utf-8",
            )
            c.print(f"  [success]✓[/] Architecture saved to [text].widdx/architecture.md[/]")
        except Exception:
            pass

        return arch_text

    # ── Code Review Gate ─────────────────────────────────────────────────

    def run_code_review(self, phase: Phase, plan: ProjectPlan) -> bool:
        """Review code after a phase completes. Returns True if review passed."""
        from widdx import ui
        c = ui.get_console()

        files = list(dict.fromkeys(phase.files_created + phase.files_edited))
        if not files:
            return True

        file_contents = ""
        for f in files[:5]:
            try:
                content = __import__("pathlib").Path(f).read_text(encoding="utf-8")
                file_contents += f"\n### {f}\n```\n{content[:2000]}\n```\n"
            except OSError:
                continue

        if not file_contents:
            return True

        system = (
            "You are a senior code reviewer. Review the following files for: "
            "1) Correctness — does the code work? "
            "2) Security — any vulnerabilities? "
            "3) Performance — any obvious bottlenecks? "
            "4) Style — follows framework conventions? "
            "5) Completeness — any missing error handling? "
            "Respond with either: APPROVED followed by brief feedback, "
            "or CHANGES_REQUESTED followed by what needs to change."
        )
        msg = f"Phase: {phase.title}\n\nFiles:\n{file_contents}"
        result = self._router.call_architect(system, msg, max_tokens=2048)
        review_text = result.get("text", "") if not (isinstance(result, dict) and "error" in result) else "APPROVED"

        c.print(f"  [dim]Code Review:[/]")
        passed = review_text.strip().upper().startswith("APPROVED")
        if passed:
            c.print(f"  [success]  ✓ Approved[/]")
        else:
            changes = review_text[:500].replace("CHANGES_REQUESTED", "").strip()
            c.print(f"  [warning]  ⚠ Changes requested:[/] {changes[:200]}")

        # Log the review outcome
        phase.decisions.append(f"Code review: {'PASS' if passed else 'CHANGES_REQUESTED'}")

        # Save review to .widdx/
        try:
            from .project_state import get_widdx_dir
            reviews_dir = get_widdx_dir() / "reviews"
            reviews_dir.mkdir(exist_ok=True)
            (reviews_dir / f"phase-{phase.number}-{phase.title[:20].replace(' ', '-')}.md").write_text(
                review_text, encoding="utf-8",
            )
        except Exception:
            pass

        return passed

    # ── Retrospective ────────────────────────────────────────────────────

    def run_retrospective(self, plan: ProjectPlan) -> None:
        """Save retrospective notes after each phase to .widdx/retrospectives.md."""
        try:
            from .project_state import get_widdx_dir
            widdx_dir = get_widdx_dir()
            retro_path = widdx_dir / "retrospectives.md"

            lines = ["# Project Retrospectives\n"]
            for phase in plan.phases:
                if phase.status != "done":
                    continue
                lines.append(f"\n## Phase {phase.number}: {phase.title}")
                lines.append(f"**Status:** {phase.status}")
                lines.append(f"**Files created:** {len(phase.files_created)}")
                lines.append(f"**Files edited:** {len(phase.files_edited)}")
                if phase.decisions:
                    lines.append("\n**Key decisions:**")
                    for d in phase.decisions[-5:]:
                        lines.append(f"- {d}")
                lines.append("")

            retro_path.write_text("\n".join(lines), encoding="utf-8")
        except Exception:
            pass

    # ── Progress Dashboard ──────────────────────────────────────────────

    def save_progress_dashboard(self, plan: ProjectPlan) -> None:
        """Save a live progress dashboard to .widdx/progress.md."""
        try:
            from .project_state import get_widdx_dir
            widdx_dir = get_widdx_dir()
            progress_path = widdx_dir / "progress.md"

            total = len(plan.phases)
            done = len(plan.completed_phases)
            pct = int(done / total * 100) if total > 0 else 0

            bar_length = 20
            filled = int(bar_length * pct / 100)
            bar = "█" * filled + "░" * (bar_length - filled)

            lines = [
                f"# Project Progress: {plan.task}",
                f"",
                f"**Overall:** {pct}% complete",
                f"**Phases:** {done}/{total} completed",
                f"",
                f"`{bar}`",
                f"",
                f"## Phase Status",
                f"",
            ]
            for phase in plan.phases:
                status_icon = {"done": "✅", "running": "🔄", "failed": "❌", "pending": "⏳"}
                icon = status_icon.get(phase.status, "⏳")
                lines.append(f"| {icon} | Phase {phase.number} | {phase.title} | {phase.status} |")
                if phase.files_created or phase.files_edited:
                    lines.append(f"  | Files: {len(phase.files_created)} created, {len(phase.files_edited)} edited")

            progress_path.write_text("\n".join(lines), encoding="utf-8")
        except Exception:
            pass

    # ── Live progress bar ────────────────────────────────────────────────

    @staticmethod
    def _print_progress_bar(
        done: int, total: int,
        elapsed_sec: float, phase_elapsed: float,
        task: str, current_phase: str,
    ) -> None:
        """Print a compact progress bar with timing."""
        from widdx import ui
        c = ui.get_console()
        pct = int(done / total * 100) if total > 0 else 0
        bar_len = 20
        filled = int(bar_len * pct / 100)
        bar = "█" * filled + "░" * (bar_len - filled)

        elapsed_str = f"{int(elapsed_sec // 60)}m{int(elapsed_sec % 60)}s" if elapsed_sec > 60 else f"{int(elapsed_sec)}s"
        phase_str = f" · +{int(phase_elapsed)}s" if phase_elapsed else ""

        c.print(
            f"  [brand]◆[/] [bold]{pct}%[/] "
            f"[dim]{bar}[/] "
            f"[dim]{done}/{total} phases[/] "
            f"[dim]⏱ {elapsed_str}{phase_str}[/]"
        )
        if current_phase:
            c.print(f"  [dim]  └─ {current_phase[:70]}[/]")

    # ── Plan creation ─────────────────────────────────────────────────────

    def create_plan(self, task: str, complexity: int | None = None,
                    spec: str = "", architecture: str = "") -> ProjectPlan:
        """Ask the architect model to design a phased project plan.

        If *complexity* is not provided it is estimated locally.
        Plans are immediately persisted to MemoryStore.
        Uses specification and architecture documents for context.
        """
        from widdx import ui

        if complexity is None:
            complexity = self._estimate_complexity(task)

        ui.get_console().print(
            f"  [brand]◆[/] [bold text]Planning project[/] "
            f"[dim](complexity {complexity}/5)[/]"
        )

        # ── Tech stack negotiation: ask user about key choices ────
        tech_prefs = self._negotiate_tech_stack(task)

        # ── Inject relevant skills into the planner prompt ────────
        skill_context = self._load_relevant_skills(task)

        system = self._planner_system_prompt(tech_prefs, skill_context)

        user_parts = [
            f"Project request: {task}",
            f"Estimated complexity: {complexity}/5",
        ]
        if spec:
            user_parts.append(f"\n## Specification\n{spec[:2000]}")
        if architecture:
            user_parts.append(f"\n## Architecture\n{architecture[:2000]}")
        if tech_prefs:
            user_parts.append(f"\n## Tech Preferences\n{json.dumps(tech_prefs, ensure_ascii=False)}")
        user_parts.append("\nDesign a phased execution plan with specific, actionable phases. Return valid JSON only.")
        user = "\n".join(user_parts)

        result = self._router.call_architect(system, user, max_tokens=4096)
        if "error" in result:
            logger.warning("Planner LLM call failed: %s", result["error"])
            return self._fallback_plan(task)

        plan = self._parse_plan(result.get("text", ""), task)
        self._save_plan(plan)

        ui.get_console().print(
            f"  [success]✓[/] Plan created — "
            f"[accent]{len(plan.phases)} phases[/]  "
            f"[dim](id: {plan.id})[/]"
        )
        return plan

    def resume_plan(self, plan_id: str) -> ProjectPlan | None:
        """Load a persisted plan from MemoryStore and return it.

        Returns None if not found.
        """
        raw = self._memory.get_knowledge(f"project_plan:{plan_id}")
        if not raw:
            return None
        try:
            return ProjectPlan.from_dict(json.loads(raw))
        except (json.JSONDecodeError, TypeError, KeyError) as exc:
            logger.warning("Failed to load plan %s: %s", plan_id, exc)
            return None

    def list_plans(self) -> list[dict]:
        """Return summary dicts for all saved plans."""
        index_raw = self._memory.get_knowledge("project_plans_index")
        if not index_raw:
            return []
        try:
            index: list[str] = json.loads(index_raw)
        except json.JSONDecodeError:
            return []
        plans = []
        for pid in index:
            raw = self._memory.get_knowledge(f"project_plan:{pid}")
            if not raw:
                continue
            try:
                d = json.loads(raw)
                plans.append({
                    "id": d["id"],
                    "task": d["task"][:70],
                    "status": d["status"],
                    "phases": len(d.get("phases", [])),
                    "done": sum(1 for p in d.get("phases", []) if p["status"] == "done"),
                })
            except (json.JSONDecodeError, KeyError):
                continue
        return plans

    # ── Plan execution ────────────────────────────────────────────────────

    def execute_plan(
        self,
        plan: ProjectPlan,
        agent_factory: AgentFactory,
        start_from: int = 0,
    ) -> ProjectPlan:
        """Execute all pending phases in dependency order.

        *start_from*: 1-based phase number to skip to (for partial reruns).
        After each phase the plan is persisted so it can be resumed.
        Shows a live progress dashboard during execution.
        """
        from widdx import ui
        import time as _time
        c = ui.get_console()

        plan.status = "running"
        self._save_plan(plan)

        total_phases = len(plan.phases)
        start_time = _time.time()
        phase_times: list[float] = []

        # ── Live progress header ──────────────────────────────────
        c.print()
        self._print_progress_bar(0, total_phases, 0, 0, plan.task[:60], "")
        c.print()

        # Accumulated architectural context passed forward between phases
        arch_context = plan.architecture_notes

        while True:
            phase = plan.next_phase
            if phase is None:
                break

            phase_start = _time.time()
            self._print_progress_bar(
                len(plan.completed_phases), total_phases,
                phase_start - start_time, 0,
                plan.task[:60],
                f"Phase {phase.number}: {phase.title}",
            )

            if start_from > 0 and phase.number < start_from:
                phase.status = "done"
                phase.output_summary = "(skipped — start_from override)"
                self._save_plan(plan)
                continue

            c.print()
            c.print(
                f"  [brand]◆ Phase {phase.number}/{len(plan.phases)}:[/] "
                f"[bold text]{phase.title}[/]"
            )
            c.print(f"  [dim]  Goal: {phase.goal[:100]}[/]")

            phase.status = "running"
            self._save_plan(plan)

            # ── Phase execution with retry + escalation ────────────
            phase_ok = False
            last_error = ""

            for attempt in range(_MAX_PHASE_RETRIES + 1):
                try:
                    # Use simplified approach on retry
                    if attempt == 0:
                        output = self._execute_phase(phase, plan, agent_factory, arch_context)
                    else:
                        c.print(f"  [dim]  Retry {attempt}/{_MAX_PHASE_RETRIES} — simplifying approach...[/]")
                        output = self._retry_phase_simplified(phase, plan, agent_factory, arch_context)

                    phase.status = "done"
                    phase.output_summary = output[:800]
                    phase_ok = True
                    break

                except Exception as exc:  # noqa: BLE001
                    last_error = str(exc)
                    logger.warning("Phase %d attempt %d failed: %s", phase.number, attempt + 1, exc)

                    if attempt < _MAX_PHASE_RETRIES:
                        from widdx import ui as _ui
                        err_msg = last_error[:80]
                        cont = _ui.confirm(
                            f"Phase {phase.number} failed: {err_msg}. Retry with simpler approach?",
                            default=True,
                        )
                        if not cont:
                            break
                    else:
                        # Offer user choices on final failure
                        from widdx import ui as _ui
                        c.print(f"  [error]✗ Phase {phase.number} failed after {_MAX_PHASE_RETRIES + 1} attempts[/]")
                        action = _ui.confirm_with_options(
                            f"How to proceed? Phase: {phase.title}",
                            ["Skip phase", "Abort project"],
                            default="Skip phase",
                        )
                        if action == "s" or action.lower().startswith("skip"):
                            phase.status = "done"
                            phase.output_summary = f"(skipped after failure: {last_error[:200]})"
                            self._save_plan(plan)
                            c.print(f"  [warning]⚠ Phase {phase.number} skipped[/]")
                            phase_ok = True
                            break
                        break

            if not phase_ok:
                phase.status = "failed"
                phase.output_summary = f"Error: {last_error[:500]}"
                self._save_plan(plan)
                c.print(f"  [error]✗ Phase {phase.number} failed — aborting[/]")
                break

            # Extract decisions and files from output
            phase.decisions = self._extract_decisions(phase.output_summary or "")
            phase.files_created, phase.files_edited = self._extract_files(phase.output_summary or "")

            # Accumulate architectural context for next phase
            arch_context = self._build_arch_context(plan, phase, arch_context)

            # Persist decisions for cross-session recall
            self._save_phase_decisions(plan.id, phase)

            c.print(
                f"  [success]✓ Phase {phase.number} complete[/]  "
                f"[dim]{len(phase.files_created)} created, "
                f"{len(phase.files_edited)} edited[/]"
            )

            # ── Code Review Gate after each successful phase ──────
            review_passed = self.run_code_review(phase, plan)
            if not review_passed:
                c.print(f"  [warning]  Code review requested changes — consider fixing before next phase[/]")

            # ── Git checkpoint: commit after each successful phase ──
            self._git_checkpoint(plan, phase)

            # ── Retrospective for this phase ──────────────────────
            self.run_retrospective(plan)

            # ── Progress dashboard update ─────────────────────────
            self.save_progress_dashboard(plan)

            # ── Live progress bar update ───────────────────────────
            import time as _time
            phase_elapsed = _time.time() - phase_start
            phase_times.append(phase_elapsed)
            avg = sum(phase_times) / len(phase_times)
            remaining = avg * (total_phases - len(plan.completed_phases))
            rem_str = f"~{int(remaining//60)}m remaining" if remaining > 60 else f"~{int(remaining)}s remaining"
            self._print_progress_bar(
                len(plan.completed_phases), total_phases,
                _time.time() - start_time, 0,
                plan.task[:60],
                f"✅ {phase.title} done · {rem_str}",
            )

            # ── Save progress to .widdx/ after EACH phase ──────────
            self._freeze_project_state(plan)

            self._save_plan(plan)

        # Final status
        all_done = all(p.status == "done" for p in plan.phases)
        any_failed = any(p.status == "failed" for p in plan.phases)
        plan.status = "done" if all_done else ("failed" if any_failed else "partial")
        self._save_plan(plan)

        # Final freeze to .widdx/ with latest status
        self._freeze_project_state(plan)

        c.print()
        icon = "✓" if plan.status == "done" else "⚠"
        style = "success" if plan.status == "done" else "warning"
        c.print(
            f"  [{style}]{icon} Project {plan.status}[/]  "
            f"[dim]{plan.progress_pct()}% complete[/]"
        )
        return plan

    # ── Phase execution ───────────────────────────────────────────────────

    def _execute_phase(
        self,
        phase: Phase,
        plan: ProjectPlan,
        agent_factory: AgentFactory,
        arch_context: str,
    ) -> str:
        """Execute one phase using the agent factory."""
        # Build a bounded task description for this phase
        task_desc = self._phase_task_description(phase, plan, arch_context)

        # Generate an appropriate agent team for this phase
        specs = agent_factory.generate_team(task_desc, complexity=min(phase.number + 1, 4))

        phase_task_id = f"{plan.id}_ph{phase.number}"

        return agent_factory.execute_team(
            specs=specs,
            task=task_desc,
            task_id=phase_task_id,
            memory=self._memory,
            project_context=arch_context,
        )

    def _retry_phase_simplified(
        self,
        phase: Phase,
        plan: ProjectPlan,
        agent_factory: AgentFactory,
        arch_context: str,
    ) -> str:
        """Execute a phase with a simpler, single-agent approach.

        Used as fallback when the multi-agent team fails.
        Reduces complexity by using one fullstack agent instead of a team.
        """
        task_desc = self._phase_task_description(phase, plan, arch_context)
        phase_task_id = f"{plan.id}_ph{phase.number}_retry"

        # Single fullstack agent — simpler than generating a team
        from .agent_factory import AgentSpec
        specs = [
            AgentSpec(
                role="Full-Stack Developer",
                goal=phase.goal,
                domain="fullstack",
                constraints=[
                    "Fix the errors from the previous attempt",
                    "Write clean, working code",
                    "No placeholders",
                    f"Previous error to avoid: {phase.output_summary[:200]}",
                ],
                depends_on=[],
            )
        ]
        return agent_factory.execute_team(
            specs=specs,
            task=task_desc,
            task_id=phase_task_id,
            memory=self._memory,
            project_context=arch_context,
        )

    def _phase_task_description(
        self, phase: Phase, plan: ProjectPlan, arch_context: str
    ) -> str:
        """Build the full task string passed to agents for this phase."""
        parts = [
            f"## Project: {plan.task}",
            f"## Current Phase: {phase.number}/{len(plan.phases)} — {phase.title}",
            "",
            f"**Goal:** {phase.goal}",
            "",
            "**Deliverables for this phase:**",
        ]
        for d in phase.deliverables:
            parts.append(f"- {d}")

        if plan.tech_stack:
            parts.append(f"\n**Tech stack:** {', '.join(plan.tech_stack)}")

        if arch_context:
            parts.append(f"\n**Architectural context from previous phases:**\n{arch_context[:1500]}")

        parts.append(
            "\n**Instructions:** Implement ONLY the deliverables for this phase. "
            "Do not skip ahead to future phases. Write complete, production-quality code."
        )
        return "\n".join(parts)

    # ── Git checkpoint ──────────────────────────────────────────────────

    def _git_checkpoint(self, plan: ProjectPlan, phase: Phase) -> None:
        """Create a git commit as a checkpoint after a successful phase.

        Enables rollback to any phase and cross-session project continuity.
        """
        import subprocess
        from pathlib import Path
        cwd = Path.cwd()
        if not (cwd / ".git").exists():
            return

        files_to_add = list(dict.fromkeys(phase.files_created + phase.files_edited))
        if not files_to_add:
            # Add all changes in the working tree
            try:
                subprocess.run(
                    ["git", "add", "-A"],
                    capture_output=True, text=True,
                    timeout=30, cwd=cwd,
                )
            except (subprocess.TimeoutExpired, OSError):
                return
        else:
            for f in files_to_add:
                with contextlib.suppress(subprocess.TimeoutExpired, OSError):
                    subprocess.run(
                        ["git", "add", "--", f],
                        capture_output=True, text=True,
                        timeout=15, cwd=cwd,
                    )

        commit_msg = (
            f"widdx checkpoint: Phase {phase.number}/{len(plan.phases)}"
            f" — {phase.title}"
        )
        with contextlib.suppress(subprocess.TimeoutExpired, OSError):
            subprocess.run(
                ["git", "commit", "-m", commit_msg, "--allow-empty"],
                capture_output=True, text=True,
                timeout=30, cwd=cwd,
            )

    # ── Architectural context management ─────────────────────────────────

    def _build_arch_context(
        self, plan: ProjectPlan, completed_phase: Phase, prev_context: str
    ) -> str:
        """Summarise completed work to pass as context to the next phase."""
        lines = [prev_context] if prev_context else []

        lines.append(f"\n### Phase {completed_phase.number}: {completed_phase.title} ✓")
        if completed_phase.files_created:
            lines.append(f"Created: {', '.join(completed_phase.files_created[:10])}")
        if completed_phase.files_edited:
            lines.append(f"Edited: {', '.join(completed_phase.files_edited[:10])}")
        if completed_phase.decisions:
            lines.append("Decisions:")
            for d in completed_phase.decisions[:5]:
                lines.append(f"  - {d}")

        combined = "\n".join(lines)
        # Cap at 3000 chars to avoid context overflow
        if len(combined) > 3000:
            combined = combined[-3000:]
        return combined

    def _save_phase_decisions(self, plan_id: str, phase: Phase) -> None:
        """Persist key decisions from a completed phase to MemoryStore."""
        if not phase.decisions:
            return
        key = f"project_decisions:{plan_id}:phase{phase.number}"
        value = json.dumps({
            "phase": phase.title,
            "decisions": phase.decisions,
            "files": phase.files_created + phase.files_edited,
        })
        self._memory.set_knowledge(key, value)

    def get_project_decisions(self, plan_id: str) -> list[dict]:
        """Retrieve all persisted decisions for a project (cross-session)."""
        results = []
        plan = self.resume_plan(plan_id)
        if not plan:
            return []
        for phase in plan.phases:
            raw = self._memory.get_knowledge(
                f"project_decisions:{plan_id}:phase{phase.number}"
            )
            if raw:
                with contextlib.suppress(json.JSONDecodeError):
                    results.append(json.loads(raw))
        return results

    # ── Project state (writes .widdx/project.json in target) ─────────────

    def _freeze_project_state(self, plan: ProjectPlan) -> None:
        """Save project state + design doc to .widdx/ in the target project."""
        try:
            from pathlib import Path
            from .project_state import ProjectState, save_state, get_widdx_dir

            all_files_created: list[str] = []
            all_files_edited: list[str] = []
            all_decisions: list[str] = []
            for phase in plan.phases:
                all_files_created.extend(phase.files_created)
                all_files_edited.extend(phase.files_edited)
                all_decisions.extend(phase.decisions)

            state = ProjectState(
                framework="",
                project_name=Path.cwd().name,
                phases_total=len(plan.phases),
                phases_completed=len(plan.completed_phases),
                decisions=list(dict.fromkeys(all_decisions)),
                files_created=list(dict.fromkeys(all_files_created)),
                files_edited=list(dict.fromkeys(all_files_edited)),
                last_phase_id=plan.phases[-1].id if plan.phases else "",
            )
            save_state(state)

            # Save a human-readable design doc in .widdx/
            widdx_dir = get_widdx_dir()
            design_path = widdx_dir / "plan.md"
            design_lines = [
                f"# Project Plan: {plan.task}",
                f"",
                f"**Status:** {plan.status}",
                f"**Phases:** {len(plan.phases)} total, {len(plan.completed_phases)} completed",
                f"",
            ]
            if plan.tech_stack:
                design_lines.append(f"**Tech Stack:** {', '.join(plan.tech_stack)}")
                design_lines.append("")
            if plan.architecture_notes:
                design_lines.append(f"## Architecture\n{plan.architecture_notes}\n")
            design_lines.append("## Phases")
            for phase in plan.phases:
                status_icon = {"done": "✓", "running": "▶", "failed": "✗", "pending": "○"}
                icon = status_icon.get(phase.status, "○")
                design_lines.append(f"\n### {icon} Phase {phase.number}: {phase.title}")
                design_lines.append(f"**Goal:** {phase.goal}")
                if phase.deliverables:
                    design_lines.append("**Deliverables:**")
                    for d in phase.deliverables:
                        design_lines.append(f"- {d}")
                if phase.files_created:
                    design_lines.append(f"**Created:** {', '.join(phase.files_created)}")
                if phase.files_edited:
                    design_lines.append(f"**Edited:** {', '.join(phase.files_edited)}")
                if phase.decisions:
                    design_lines.append("**Decisions:**")
                    for d in phase.decisions:
                        design_lines.append(f"- {d}")
            design_path.write_text("\n".join(design_lines), encoding="utf-8")
        except Exception as exc:
            logger.debug("Could not freeze project state: %s", exc)

    # ── Persistence ───────────────────────────────────────────────────────

    def _save_plan(self, plan: ProjectPlan) -> None:
        """Persist plan to MemoryStore."""
        self._memory.set_knowledge(
            f"project_plan:{plan.id}",
            json.dumps(plan.to_dict(), ensure_ascii=False),
        )
        # Update index
        index_raw = self._memory.get_knowledge("project_plans_index")
        index: list[str] = json.loads(index_raw) if index_raw else []
        if plan.id not in index:
            index.append(plan.id)
            self._memory.set_knowledge("project_plans_index", json.dumps(index))

    # ── LLM prompt ────────────────────────────────────────────────────────

    def _negotiate_tech_stack(self, task: str) -> dict[str, str]:
        """Ask the user about their tech stack preferences."""
        from widdx import ui
        from widdx.scaffolder import detect_framework

        prefs: dict[str, str] = {}
        detected = detect_framework(task)

        if detected is None:
            choices = ui.confirm_with_options(
                "No framework detected. What kind of project?",
                ["Web App (frontend+backend)", "API / Backend", "Frontend only", "CLI / Script"],
                default="Web App (frontend+backend)",
            )
            prefs["project_type"] = choices
            return prefs

        key, cfg = detected
        ui.get_console().print(f"  [dim]Detected: {cfg.label}[/]")

        want = ui.confirm(f"Build a {cfg.label} project?", default=True)
        if not want:
            prefs["framework"] = "other"
            return prefs

        prefs["framework"] = key

        # Ask database preference
        db = ui.confirm_with_options(
            "Which database?",
            ["SQLite", "PostgreSQL", "MySQL", "MongoDB"],
            default="SQLite",
        )
        prefs["database"] = db

        # Ask authentication preference for web projects
        if key in ("laravel", "django", "rails"):
            auth_choices = {"laravel": ["Sanctum", "JWT", "Session"],
                           "django": ["django-auth", "djoser", "JWT"],
                           "rails": ["Devise", "JWT"]}
            auth = ui.confirm_with_options(
                "Authentication?",
                auth_choices.get(key, ["Built-in", "None"]),
                default=auth_choices.get(key, ["Built-in"])[0],
            )
            prefs["auth"] = auth

        # Ask deployment target
        deploy = ui.confirm_with_options(
            "Deployment target?",
            ["Docker", "Shared hosting", "VPS", "Serverless"],
            default="Docker",
        )
        prefs["deployment"] = deploy

        return prefs

    def _load_relevant_skills(self, task: str) -> list[str]:
        """Load skills that match the task before planning begins."""
        try:
            from .skills import SkillManager
            mgr = SkillManager()
            mgr.load()
            return mgr.match_skills(task, max_skills=5)
        except Exception:
            return []

    def _planner_system_prompt(self, tech_prefs: dict | None = None,
                                skill_context: list[str] | None = None) -> str:
        parts = [
            "You are an expert software project planner. Break a complex project into sequential phases.\n",
            "\n",
            "Return a JSON object with this exact structure:\n",
            '{\n',
            '  "tech_stack": ["Python", "FastAPI", "React", ...],\n',
            '  "architecture_notes": "High-level architecture decision summary",\n',
            '  "phases": [\n',
            '    {\n',
            '      "number": 1,\n',
            '      "title": "Foundation & Data Models",\n',
            '      "goal": "Set up project structure and define all data models",\n',
            '      "deliverables": [\n',
            '        "Project directory structure",\n',
            '        "SQLAlchemy models for User, Product, Order",\n',
            '        "Database configuration and migrations"\n',
            '      ],\n',
            '      "depends_on": []\n',
            '    },\n',
            '    {\n',
            '      "number": 2,\n',
            '      "title": "Core Backend API",\n',
            '      "goal": "Implement all REST endpoints",\n',
            '      "deliverables": [\n',
            '        "Authentication endpoints (register, login, JWT)",\n',
            '        "Product CRUD endpoints",\n',
            '        "Order management endpoints"\n',
            '      ],\n',
            '      "depends_on": [1]\n',
            '    }\n',
            '  ]\n',
            '}\n',
            "\n",
            "Rules:\n",
            "- 2-7 phases max depending on complexity\n",
            "- Each phase MUST have clear, specific deliverables (not vague)\n",
            "- Each phase must be completable in one agent session (not too large)\n",
            "- depends_on contains phase numbers (integers), not IDs\n",
            "- Return ONLY valid JSON — no markdown, no explanation\n",
        ]

        if tech_prefs and tech_prefs.get("framework"):
            parts.append(f"\nUser chose: {tech_prefs.get('framework')}")
            parts.append(f"Database: {tech_prefs.get('database', 'SQLite')}")
            if tech_prefs.get("auth"):
                parts.append(f"Authentication: {tech_prefs.get('auth')}")
            parts.append(f"Deployment: {tech_prefs.get('deployment', 'Docker')}")
            parts.append("\n")

        if skill_context:
            parts.append("\n## Relevant expertise\n")
            for s in skill_context:
                lines = s.split("\n")
                title = lines[0] if lines else "skill"
                parts.append(f"- {title[:100]}\n")

        return "".join(parts)

    # ── Parsing helpers ───────────────────────────────────────────────────

    def _parse_plan(self, raw: str, task: str) -> ProjectPlan:
        raw = raw.strip()
        # Strip markdown fences
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
            if raw.endswith("```"):
                raw = raw[:-3].strip()
        start = raw.find("{")
        end = raw.rfind("}")
        if start == -1 or end == -1:
            return self._fallback_plan(task)
        try:
            data = json.loads(raw[start:end + 1])
        except json.JSONDecodeError:
            return self._fallback_plan(task)

        from datetime import datetime, timezone
        plan_id = uuid.uuid4().hex[:12]
        phases: list[Phase] = []
        for ph in data.get("phases", []):
            depends_on_nums = ph.get("depends_on", [])
            phase_id = f"ph{ph.get('number', len(phases) + 1)}"
            phases.append(Phase(
                id=phase_id,
                number=ph.get("number", len(phases) + 1),
                title=ph.get("title", f"Phase {len(phases) + 1}"),
                goal=ph.get("goal", ""),
                deliverables=ph.get("deliverables", []),
                depends_on=[f"ph{n}" for n in depends_on_nums],
            ))

        return ProjectPlan(
            id=plan_id,
            task=task,
            phases=phases,
            tech_stack=data.get("tech_stack", []),
            architecture_notes=data.get("architecture_notes", ""),
            created_at=datetime.now(timezone.utc).isoformat(),
        )

    def _fallback_plan(self, task: str) -> ProjectPlan:
        """Minimal 2-phase plan when LLM planning fails."""
        from datetime import datetime, timezone
        plan_id = uuid.uuid4().hex[:12]
        return ProjectPlan(
            id=plan_id,
            task=task,
            phases=[
                Phase(
                    id="ph1", number=1,
                    title="Foundation",
                    goal=f"Set up project structure for: {task}",
                    deliverables=["Project structure", "Core models", "Configuration"],
                    depends_on=[],
                ),
                Phase(
                    id="ph2", number=2,
                    title="Implementation",
                    goal=f"Implement core functionality for: {task}",
                    deliverables=["All main features", "Error handling", "Documentation"],
                    depends_on=["ph1"],
                ),
            ],
            created_at=datetime.now(timezone.utc).isoformat(),
        )

    # ── Output extraction ─────────────────────────────────────────────────

    @staticmethod
    def _extract_decisions(output: str) -> list[str]:
        """Extract key architectural decisions from agent output."""
        import re
        decisions = []
        for line in output.split("\n"):
            line = line.strip()
            if re.match(r"^[-*•]\s*(decision|chose|decided|using|architecture):", line, re.I):
                decisions.append(line[2:].strip()[:200])
            elif "## Decisions" in line:
                pass  # handled below
        # Also capture lines under ## Decisions section
        in_section = False
        for line in output.split("\n"):
            stripped = line.strip()
            if stripped.lower().startswith("## decision"):
                in_section = True
                continue
            elif stripped.startswith("## "):
                in_section = False
            if in_section and stripped.startswith("- "):
                decisions.append(stripped[2:].strip()[:200])
        return list(dict.fromkeys(decisions))[:10]

    @staticmethod
    def _extract_files(output: str) -> tuple[list[str], list[str]]:
        """Extract created/edited file paths from agent output."""
        import re
        created, edited = [], []
        for line in output.split("\n"):
            if "✚" in line or "(created)" in line.lower():
                m = re.search(r"`([^`]+\.[a-z]{1,6})`", line)
                if m:
                    created.append(m.group(1))
            elif "~" in line or "(edited)" in line.lower():
                m = re.search(r"`([^`]+\.[a-z]{1,6})`", line)
                if m:
                    edited.append(m.group(1))
        return list(dict.fromkeys(created)), list(dict.fromkeys(edited))

    @staticmethod
    def _estimate_complexity(task: str) -> int:
        """Quick local complexity estimate without LLM call."""
        lower = task.lower()
        if any(kw in lower for kw in ["saas", "platform", "fullstack", "complete", "entire system"]):
            return 5
        if any(kw in lower for kw in ["frontend", "backend", "api", "auth", "database", "payment"]):
            return 4
        if any(kw in lower for kw in ["build", "create", "implement", "app", "service"]):
            return 3
        return 2


__all__ = ["ProjectPlanner", "ProjectPlan", "Phase"]
