"""AI Router — OpenAI-compatible multi-provider routing."""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

import yaml

from .pricing import (
    PRICING,
    _estimate_tokens,
    _init_cost_tracking,
    _track_usage,
)
from .streaming import call_streaming, call_with_tools_streaming
from .tools_api import call_with_tools

logger = logging.getLogger(__name__)


class AIRouter:
    """Routes tasks to paid DeepSeek when available, then free providers."""

    # ── Injected methods from sub-modules ──────────────────────────
    call_streaming = call_streaming
    call_with_tools_streaming = call_with_tools_streaming
    call_with_tools = call_with_tools
    _estimate_tokens = _estimate_tokens
    _track_usage = _track_usage

    ARCHITECT_KEYWORDS = {
        "architecture", "design", "planning", "review", "validation",
        "architecture design", "system review", "refactoring plan",
        "security audit", "performance analysis", "code review",
    }

    EXECUTOR_KEYWORDS = {
        "code generation", "implementation", "boilerplate", "testing",
        "debugging", "fix", "build", "generate", "scaffold", "refactor",
    }

    ARCHITECT_PREFIX = (
        "You are a Senior Systems Architect and Principal Engineer.\n"
        "Your role is REASONING, PLANNING, and ARCHITECTURE DESIGN.\n"
        "Think step by step. Analyze deeply. Plan thoroughly.\n"
        "Output structured, clear plans — not implementation code.\n"
    )

    EXECUTOR_PREFIX = (
        "You are a Senior Software Engineer and Code Implementation Expert.\n"
        "Your role is IMPLEMENTATION and CODE GENERATION.\n"
        "Write clean, readable, production-ready code.\n"
        "Functions = verbs. Variables = nouns. Use guard clauses. Handle errors first.\n"
        "No trivial comments. No emojis. Focus on correctness and clarity.\n"
    )

    PRICING = PRICING
    FREE_PROVIDERS = (
        {
            "name": "opencode",
            "base_url": "https://opencode.ai/zen/v1",
            "api_key": "public",
            "models": [
                {"role": "architect", "model": "big-pickle"},
                {"role": "executor", "model": "deepseek-v4-flash-free"},
                {"role": "executor", "model": "nemotron-3-super-free"},
            ],
        },
        {
            "name": "kilo",
            "base_url": "https://api.kilo.ai/api/gateway",
            "api_key": "public",
            "models": [
                {"role": "executor", "model": "kilo-auto/free"},
                {"role": "executor", "model": "openrouter/owl-alpha"},
                {"role": "executor", "model": "stepfun/step-3.5-flash:free"},
            ],
        },
    )

    def __init__(self, config: dict[str, Any], memory) -> None:
        self._config = config
        self._memory = memory
        deepseek_key = config.get("__env__", {}).get("deepseek_key")
        models = config.get("models", {})
        self._architect_model = models.get("architect", {}).get("model", "deepseek-v4-pro")
        self._executor_model = models.get("executor", {}).get("model", "deepseek-v4-flash")
        self._architect_thinking = models.get("architect", {}).get("thinking", False)
        self._architect_thinking_mode = models.get("architect", {}).get("thinking_mode", "enabled")
        self._session_input_tokens = 0
        self._session_output_tokens = 0
        self._session_cost = 0.0
        self._last_provider = ""
        self._last_model = ""
        self._providers = self._build_providers(deepseek_key)
        self._client = self._providers[0]["client"] if self._providers else None
        _init_cost_tracking(self)

    @property
    def memory(self):
        """Public read-only access to the MemoryStore instance."""
        return self._memory

    @property
    def config(self):
        """Public read-only access to the configuration dict."""
        return self._config

    @property
    def executor_model(self):
        """Public read-only access to the current executor model name."""
        return self._executor_model

    def _build_providers(self, deepseek_key: str | None) -> list[dict[str, Any]]:
        from openai import OpenAI

        providers: list[dict[str, Any]] = []

        # Paid DeepSeek provider (always first when API key exists)
        if deepseek_key:
            providers.append({
                "name": "deepseek",
                "client": OpenAI(api_key=deepseek_key, base_url="https://api.deepseek.com"),
                "architect_model": self._architect_model,
                "executor_model": self._executor_model,
                "supports_thinking": True,
            })

        # Free providers — expand each provider's models into fallback entries
        free_config: dict[str, Any] = self._config.get("free_providers", {})
        for provider_def in self.FREE_PROVIDERS:
            name: str = str(provider_def["name"])
            configured: dict[str, Any] = free_config.get(name, {})
            base_url: str = str(configured.get("base_url", provider_def["base_url"]))
            api_key: str = str(provider_def["api_key"])
            client = OpenAI(api_key=api_key, base_url=base_url)
            models: list[dict[str, str]] = list(provider_def["models"])  # type: ignore[arg-type]
            first_arch = next((m["model"] for m in models if m["role"] == "architect"), models[0]["model"])
            first_exec = next((m["model"] for m in models if m["role"] == "executor"), models[0]["model"])
            seen: set[tuple[str, str]] = set()
            for model_entry in models:
                role = model_entry["role"]
                model = model_entry["model"]
                arch_m = model if role == "architect" else first_arch
                exec_m = model if role == "executor" else first_exec
                key = (arch_m, exec_m)
                if key in seen:
                    continue
                seen.add(key)
                providers.append({
                    "name": name,
                    "client": client,
                    "architect_model": arch_m,
                    "executor_model": exec_m,
                    "supports_thinking": False,
                })
        return providers

    def list_providers(self) -> list[dict]:
        """Return unique providers with their status and model count."""
        disabled = set(self._config.get("disabled_providers", []))
        seen: dict[str, dict] = {}
        for p in self._providers:
            name = p["name"]
            if name not in seen:
                seen[name] = {
                    "name": name,
                    "architect_model": p["architect_model"],
                    "executor_model": p["executor_model"],
                    "enabled": name not in disabled,
                    "supports_thinking": p.get("supports_thinking", False),
                    "last_used": self._last_provider == name,
                    "model_count": 1,
                }
            else:
                seen[name]["model_count"] += 1
        return list(seen.values())

    def toggle_provider(self, name: str) -> bool:
        """Enable or disable a provider by name. Returns the new state (True=enabled)."""
        disabled = set(self._config.get("disabled_providers", []))
        if name in disabled:
            disabled.discard(name)
            self._config["disabled_providers"] = list(disabled)
            self._save_provider_config()
            return True
        disabled.add(name)
        self._config["disabled_providers"] = list(disabled)
        self._save_provider_config()
        return False

    def enable_only(self, name: str) -> None:
        """Disable all providers except the named one."""
        all_names = [p["name"] for p in self._providers]
        disabled = [n for n in all_names if n != name]
        self._config["disabled_providers"] = disabled
        self._save_provider_config()

    def enable_all(self) -> None:
        """Re-enable all providers."""
        self._config.pop("disabled_providers", None)
        self._save_provider_config()

    def _save_provider_config(self) -> None:
        """Persist disabled_providers to ~/.widdx/config.yaml."""
        user_path = Path.home() / ".widdx" / "config.yaml"
        try:
            existing: dict[str, Any] = {}
            if user_path.exists():
                existing = yaml.safe_load(user_path.read_text(encoding="utf-8")) or {}
            disabled = self._config.get("disabled_providers", [])
            if disabled:
                existing["disabled_providers"] = disabled
            else:
                existing.pop("disabled_providers", None)
            user_path.parent.mkdir(parents=True, exist_ok=True)
            user_path.write_text(yaml.dump(existing, allow_unicode=True, default_flow_style=False), encoding="utf-8")
        except Exception:
            pass

    def _providers_for_role(self, role: str) -> list[dict[str, Any]]:
        forced_provider = self._config.get("provider")
        role_cfg = self._config.get("models", {}).get(role, {})
        forced_provider = role_cfg.get("provider", forced_provider)
        if forced_provider and forced_provider != "auto":
            selected = [p for p in self._providers if p["name"] == forced_provider]
            if selected:
                return selected
        disabled = set(self._config.get("disabled_providers", []))
        return [p for p in self._providers if p["name"] not in disabled]

    def _model_for_provider(self, provider: dict[str, Any], role: str) -> str:
        configured = self._config.get("models", {}).get(role, {}).get("model")
        if configured and provider["name"] == "deepseek":
            return str(configured)
        model = provider["architect_model"] if role == "architect" else provider["executor_model"]
        return str(model)

    def _remember_provider(self, provider_name: str, model: str) -> None:
        self._last_provider = provider_name
        self._last_model = model

    # ── Task classification ─────────────────────────────────────

    def classify(self, task_description: str) -> str:
        """Classify a task as 'architect' or 'executor' using a fast LLM call.

        Falls back to keyword scoring if the API is unavailable or the call fails.
        Cost: ~50 tokens per call. Accuracy: ~90% vs ~65% for keyword matching.
        """
        if self._providers:
            llm_result = self._classify_with_llm(task_description)
            if llm_result is not None:
                return llm_result

        # Keyword fallback (used when API is unavailable or call fails)
        return self._classify_with_keywords(task_description)

    def _classify_with_llm(self, task_description: str) -> str | None:
        """Single-shot LLM classification. Returns None on any failure."""
        for provider in self._providers_for_role("executor"):
            try:
                resp = provider["client"].chat.completions.create(
                    model=self._model_for_provider(provider, "executor"),
                    max_tokens=5,
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are a task classifier. Reply with exactly one word: "
                                "architect or executor.\n"
                                "architect = planning, design, review, analysis, architecture.\n"
                                "executor = coding, implementation, building, fixing, generating."
                            ),
                        },
                        {"role": "user", "content": task_description},
                    ],
                    temperature=0,
                )
                word = (resp.choices[0].message.content or "").strip().lower().split()[0]
                if word in ("architect", "executor"):
                    return word
            except Exception as e:
                logger.debug("LLM classification failed for provider %s: %s", provider['name'], e)
                continue
        return None

    def _classify_with_keywords(self, task_description: str) -> str:
        """Keyword-based fallback classifier."""
        lowered = task_description.lower()
        arch_score = sum(1 for kw in self.ARCHITECT_KEYWORDS if kw in lowered)
        exec_score = sum(1 for kw in self.EXECUTOR_KEYWORDS if kw in lowered)

        if arch_score > exec_score:
            return "architect"
        if exec_score > arch_score:
            return "executor"

        stats = self._memory.routing_stats(self.infer_task_type(task_description))
        if stats:
            best = max(stats, key=lambda s: s["avg_score"])
            return str(best.get("model_selected", "executor"))

        return "executor"

    def infer_task_type(self, task: str) -> str:
        lowered = task.lower()
        if any(kw in lowered for kw in ["build", "create", "generate", "implement"]):
            return "build"
        if any(kw in lowered for kw in ["fix", "debug", "resolve"]):
            return "fix"
        if any(kw in lowered for kw in ["improve", "optimize", "refactor"]):
            return "improve"
        if any(kw in lowered for kw in ["design", "architecture", "plan"]):
            return "design"
        return "general"

    # ── Unified provider call ───────────────────────────────────

    def _call_deepseek(self, system_prompt: str, user_message: str,
                       max_tokens: int = 8192, role: str = "executor") -> dict:
        if not self._providers:
            return {"error": "No AI provider available"}

        errors: list[str] = []
        for provider in self._providers_for_role(role):
            model = self._model_for_provider(provider, role)
            start = time.perf_counter()
            kwargs: dict = dict(
                model=model,
                max_tokens=max_tokens,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message},
                ],
            )
            if role == "architect" and self._architect_thinking and provider.get("supports_thinking"):
                thinking_type = (
                    self._architect_thinking_mode
                    if self._architect_thinking_mode in ("enabled", "thinking_max")
                    else "enabled"
                )
                kwargs["extra_body"] = {"thinking": {"type": thinking_type}}
            try:
                resp = provider["client"].chat.completions.create(**kwargs)
            except Exception as exc:
                errors.append(f"{provider['name']}: {exc}")
                continue

            elapsed_ms = int((time.perf_counter() - start) * 1000)
            choice = resp.choices[0]
            result: dict = {
                "text": choice.message.content or "",
                "model": model,
                "provider": provider["name"],
                "role": role,
                "latency_ms": elapsed_ms,
                "usage": {
                    "input": resp.usage.prompt_tokens if resp.usage else 0,
                    "output": resp.usage.completion_tokens if resp.usage else 0,
                },
            }
            self._remember_provider(provider["name"], model)
            self._track_usage(model, result["usage"]["input"], result["usage"]["output"])
            if hasattr(choice.message, "reasoning_content") and choice.message.reasoning_content:
                result["reasoning_content"] = choice.message.reasoning_content
            return result

        return {"error": "All AI providers failed: " + " | ".join(errors)}

    def call_architect(self, system_prompt: str, user_message: str,
                       max_tokens: int = 8192) -> dict:
        full_prompt = self.ARCHITECT_PREFIX + "\n" + system_prompt
        return self._call_deepseek(full_prompt, user_message, max_tokens, role="architect")

    def call_executor(self, system_prompt: str, user_message: str,
                      max_tokens: int = 32768) -> dict:
        full_prompt = self.EXECUTOR_PREFIX + "\n" + system_prompt
        return self._call_deepseek(full_prompt, user_message, max_tokens, role="executor")

    def route(self, task_description: str, system_prompt: str,
              user_message: str) -> dict:
        classification = self.classify(task_description)
        if classification == "architect":
            result = self.call_architect(system_prompt, user_message)
        else:
            result = self.call_executor(system_prompt, user_message)

        if "error" not in result:
            self._memory.log_routing(
                task_type=self.infer_task_type(task_description),
                model_selected=result.get("role", "executor"),
                success_score=1.0,
                latency_ms=result.get("latency_ms", 0),
                tokens_used=(result.get("usage", {}).get("input", 0)
                             + result.get("usage", {}).get("output", 0)),
            )
        return result

    def _is_error_dict(self, result: dict) -> bool:
        return "error" in result

    # ── Cost tracking properties ──────────────────────────────────

    @property
    def session_tokens(self) -> dict:
        return {"input": self._session_input_tokens,
                "output": self._session_output_tokens}

    @property
    def session_cost(self) -> float:
        return self._session_cost

    @property
    def is_ready(self) -> bool:
        return bool(self._providers)
