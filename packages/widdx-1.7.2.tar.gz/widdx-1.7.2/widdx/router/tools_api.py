"""Router tools API — Function Calling and tool definition builders."""
from __future__ import annotations


def call_with_tools(self, system_prompt: str, messages: list[dict],
                    tools: list[dict], max_tokens: int = 32768) -> dict:
    """Native Function Calling — model decides when to call tools."""
    import time

    api_tools = _build_api_tools(tools)
    full_messages = [{"role": "system", "content": system_prompt}] + messages
    errors: list[str] = []

    for provider in self._providers_for_role("executor"):
        model = self._model_for_provider(provider, "executor")
        start = time.perf_counter()
        kwargs: dict = dict(
            model=model,
            max_tokens=max_tokens,
            messages=full_messages,
            tools=api_tools,
            tool_choice="auto",
        )
        if provider.get("supports_thinking"):
            kwargs["extra_body"] = {"thinking": {"type": "disabled"}}
        try:
            resp = provider["client"].chat.completions.create(**kwargs)
        except Exception as exc:
            errors.append(f"{provider['name']}: {exc}")
            continue
        break
    else:
        return {"error": "All AI providers failed: " + " | ".join(errors)}

    elapsed_ms = int((time.perf_counter() - start) * 1000)
    choice = resp.choices[0]
    msg = choice.message

    result: dict = {
        "model": model,
        "provider": provider["name"],
        "role": "executor",
        "latency_ms": elapsed_ms,
        "usage": {
            "input": resp.usage.prompt_tokens if resp.usage else 0,
            "output": resp.usage.completion_tokens if resp.usage else 0,
        },
    }
    self._remember_provider(provider["name"], model)
    self._track_usage(model, result["usage"]["input"], result["usage"]["output"])

    if msg.tool_calls:
        result["tool_calls"] = [
            {"name": tc.function.name, "arguments": tc.function.arguments}
            for tc in msg.tool_calls
        ]
        result["text"] = msg.content or ""
    else:
        result["text"] = msg.content or ""
    if hasattr(msg, "reasoning_content") and msg.reasoning_content:
        result["reasoning_content"] = msg.reasoning_content
    return result


def _build_api_tools(tools: list[dict]) -> list[dict]:
    """Convert internal tool definitions to OpenAI/DeepSeek API format.

    Each tool entry may carry a ``schema`` key with a ready-made JSON Schema
    ``parameters`` object.  When present it is used verbatim; otherwise the
    legacy ``parameters`` dict (name → description string) is converted via
    ``_build_tool_properties``.
    """
    api_tools = []
    for t in tools:
        if "schema" in t:
            # Tool already ships a complete JSON Schema — use it directly.
            parameters = t["schema"]
        else:
            props, required = _build_tool_properties(t.get("parameters", {}))
            parameters = {
                "type": "object",
                "properties": props,
                "required": required,
            }
        api_tools.append({
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t["description"],
                "parameters": parameters,
            },
        })
    return api_tools


def _build_tool_properties(params: dict) -> tuple[dict, list[str]]:
    """Convert a {name: description_string} dict to (properties, required_list).

    Each description string may carry type hints and an ``(optional)`` marker:
      - ``"string (required) — file path"``  → type=string, required
      - ``"int (optional) — max lines"``      → type=integer, optional
      - ``"bool (optional, default false)"``  → type=boolean, optional

    Returns a tuple of (properties_dict, required_names_list) so callers can
    build a valid JSON Schema ``parameters`` object without guessing.
    """
    properties: dict = {}
    required: list[str] = []

    for name, desc in params.items():
        desc_str = str(desc)
        desc_lower = desc_str.lower()

        # ── Determine JSON Schema type ────────────────────────────────
        if "bool" in desc_lower or "boolean" in desc_lower:
            prop_type = "boolean"
        elif "int" in desc_lower or "integer" in desc_lower:
            prop_type = "integer"
        elif "array" in desc_lower or "list" in desc_lower:
            prop_type = "array"
        else:
            prop_type = "string"

        # ── Determine if required ─────────────────────────────────────
        is_optional = "optional" in desc_lower or "default" in desc_lower
        if not is_optional:
            required.append(name)

        # ── Build property object ─────────────────────────────────────
        prop: dict = {"type": prop_type, "description": desc_str}

        # Attach default value when explicitly stated
        if "default true" in desc_lower:
            prop["default"] = True
        elif "default false" in desc_lower:
            prop["default"] = False
        elif "default 0" in desc_lower:
            prop["default"] = 0

        properties[name] = prop

    return properties, required
