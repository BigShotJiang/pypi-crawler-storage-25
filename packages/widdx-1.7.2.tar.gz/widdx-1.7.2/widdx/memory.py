"""WIDDX CLI memory system — SQLite-backed persistent storage."""
from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .config import DEFAULT_MEMORY_DB_PATH

logger = logging.getLogger("widdx.memory")


class MemoryStore:
    """SQLite-backed memory with task, decision, agent, routing, and knowledge tables.

    Provides health checking and structured logging for all database operations.
    Errors are logged with full context rather than being silently swallowed.
    """

    def __init__(self, db_path: str = DEFAULT_MEMORY_DB_PATH) -> None:
        self._conn: sqlite3.Connection | None = None
        self._db_path: str = db_path
        self._error_count: int = 0
        resolved = Path(db_path).expanduser()
        try:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(resolved))
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._migrate()
            logger.info("MemoryStore initialized: %s", resolved)
        except sqlite3.Error as e:
            logger.error("Failed to initialize memory store at %s: %s", resolved, e)
            self._conn = None
            self._error_count += 1

    # ------------------------------------------------------------------
    # Health & Diagnostics
    # ------------------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        """Check if the database connection is alive."""
        if self._conn is None:
            return False
        try:
            self._conn.execute("SELECT 1")
            return True
        except sqlite3.Error:
            return False

    @property
    def error_count(self) -> int:
        """Number of errors encountered since initialization."""
        return self._error_count

    def health_check(self) -> dict:
        """Return a health report for diagnostics.

        Returns:
            dict with keys: connected, db_path, error_count, db_size_bytes
        """
        report: dict = {
            "connected": self.is_connected,
            "db_path": str(Path(self._db_path).expanduser()),
            "error_count": self._error_count,
            "db_size_bytes": 0,
        }
        if report["connected"]:
            try:
                path = Path(self._db_path).expanduser()
                if path.exists():
                    report["db_size_bytes"] = path.stat().st_size
            except OSError:
                pass
        return report

    def __enter__(self) -> MemoryStore:
        return self

    def __exit__(self, *args) -> None:
        self.close()

    def _execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor | None:
        """Execute SQL with error logging and tracking.

        Returns None on any error (connection lost, SQL error, etc.).
        Callers should handle None appropriately.
        """
        if self._conn is None:
            logger.warning("MemoryStore disconnected — skipping query: %s", sql[:80])
            return None
        try:
            return self._conn.execute(sql, params)
        except sqlite3.Error as e:
            self._error_count += 1
            logger.error("SQL error [%s]: %s", sql[:80], e)
            return None

    def _commit(self) -> None:
        """Commit with error logging."""
        if self._conn:
            try:
                self._conn.commit()
            except sqlite3.Error as e:
                self._error_count += 1
                logger.error("Commit failed: %s", e)

    def _migrate(self) -> None:
        """Create tables if they don't exist."""
        if self._conn is None:
            return
        try:
            self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                command TEXT NOT NULL,
                intent TEXT,
                complexity INTEGER DEFAULT 1,
                status TEXT DEFAULT 'pending',
                created_at TEXT NOT NULL,
                completed_at TEXT
            );
            CREATE TABLE IF NOT EXISTS decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL REFERENCES tasks(id),
                stage TEXT NOT NULL,
                decision_type TEXT NOT NULL,
                input_summary TEXT,
                output_summary TEXT,
                model_used TEXT,
                latency_ms INTEGER,
                tokens_used INTEGER,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS agent_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL REFERENCES tasks(id),
                agent_role TEXT NOT NULL,
                agent_goal TEXT,
                model_used TEXT,
                success INTEGER DEFAULT 0,
                output_summary TEXT,
                latency_ms INTEGER,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS routing_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_type TEXT NOT NULL,
                model_selected TEXT NOT NULL,
                success_score REAL DEFAULT 0.5,
                latency_ms INTEGER,
                tokens_used INTEGER,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS knowledge (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS fix_patterns (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint     TEXT NOT NULL UNIQUE,
                error_type      TEXT NOT NULL,
                error_message   TEXT NOT NULL,
                language        TEXT NOT NULL DEFAULT 'python',
                fix_template    TEXT NOT NULL,
                file_pattern    TEXT DEFAULT '',
                success_count   INTEGER DEFAULT 0,
                fail_count      INTEGER DEFAULT 0,
                confidence      REAL DEFAULT 0.5,
                first_seen      TEXT NOT NULL,
                last_used       TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS learning_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                task_text TEXT NOT NULL,
                task_type TEXT NOT NULL,
                provider TEXT,
                success INTEGER DEFAULT 0,
                complexity INTEGER DEFAULT 1,
                tool_calls INTEGER DEFAULT 0,
                files_touched TEXT DEFAULT '[]',
                domains TEXT DEFAULT '[]',
                result_summary TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS learning_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint TEXT NOT NULL UNIQUE,
                pattern_type TEXT NOT NULL,
                scope TEXT NOT NULL,
                summary TEXT NOT NULL,
                evidence_count INTEGER DEFAULT 1,
                confidence REAL DEFAULT 0.5,
                status TEXT DEFAULT 'observed',
                source_task_id TEXT,
                metadata_json TEXT DEFAULT '{}',
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS learning_assets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_type TEXT NOT NULL,
                name TEXT NOT NULL,
                summary TEXT NOT NULL,
                status TEXT DEFAULT 'draft',
                source_fingerprint TEXT,
                file_path TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                UNIQUE(asset_type, name)
            );
            CREATE INDEX IF NOT EXISTS idx_fix_patterns_fp ON fix_patterns(fingerprint);
            CREATE INDEX IF NOT EXISTS idx_fix_patterns_conf ON fix_patterns(confidence);
            CREATE INDEX IF NOT EXISTS idx_learning_events_task_type ON learning_events(task_type);
            CREATE INDEX IF NOT EXISTS idx_learning_patterns_fp ON learning_patterns(fingerprint);
            CREATE INDEX IF NOT EXISTS idx_learning_patterns_scope ON learning_patterns(scope);
        """)
            self._conn.commit()
        except sqlite3.Error as e:
            self._error_count += 1
            logger.error("Migration failed: %s", e)

    # ------------------------------------------------------------------
    # Tasks
    # ------------------------------------------------------------------

    def create_task(self, task_id: str, command: str, intent: str = "", complexity: int = 1) -> str:
        now = _utcnow()
        self._execute(
            "INSERT INTO tasks (id, command, intent, complexity, created_at) VALUES (?,?,?,?,?)",
            (task_id, command, intent, complexity, now),
        )
        self._commit()
        return task_id

    def complete_task(self, task_id: str, status: str = "completed") -> None:
        self._execute(
            "UPDATE tasks SET status=?, completed_at=? WHERE id=?",
            (status, _utcnow(), task_id),
        )
        self._commit()

    def get_task(self, task_id: str) -> dict | None:
        row = self._execute("SELECT * FROM tasks WHERE id=?", (task_id,))
        if row is None:
            return None
        r = row.fetchone()
        return dict(r) if r else None

    def recent_tasks(self, limit: int = 10) -> list[dict]:
        rows = self._execute(
            "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,)
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def log_decision(
        self, task_id: str, stage: str, decision_type: str,
        input_summary: str = "", output_summary: str = "",
        model_used: str = "", latency_ms: int = 0, tokens_used: int = 0,
    ) -> None:
        self._execute(
            """INSERT INTO decisions
               (task_id, stage, decision_type, input_summary, output_summary, model_used, latency_ms, tokens_used, created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (task_id, stage, decision_type, input_summary[:500], output_summary[:1000],
             model_used, latency_ms, tokens_used, _utcnow()),
        )
        self._commit()

    def task_decisions(self, task_id: str) -> list[dict]:
        rows = self._execute(
            "SELECT * FROM decisions WHERE task_id=? ORDER BY id", (task_id,)
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def log_agent_run(
        self, task_id: str, agent_role: str, agent_goal: str = "",
        model_used: str = "", success: bool = False,
        output_summary: str = "", latency_ms: int = 0,
    ) -> None:
        self._execute(
            """INSERT INTO agent_runs (task_id, agent_role, agent_goal, model_used, success, output_summary, latency_ms, created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (task_id, agent_role, agent_goal[:300], model_used, int(success), output_summary[:500], latency_ms, _utcnow()),
        )
        self._commit()

    def log_routing(self, task_type: str, model_selected: str, success_score: float = 0.5, latency_ms: int = 0, tokens_used: int = 0) -> None:
        self._execute(
            "INSERT INTO routing_history (task_type, model_selected, success_score, latency_ms, tokens_used, created_at) VALUES (?,?,?,?,?,?)",
            (task_type, model_selected, success_score, latency_ms, tokens_used, _utcnow()),
        )
        self._commit()

    def routing_stats(self, task_type: str) -> list[dict]:
        rows = self._execute(
            "SELECT model_selected, COUNT(*) as count, AVG(success_score) as avg_score, AVG(latency_ms) as avg_latency FROM routing_history WHERE task_type=? GROUP BY model_selected",
            (task_type,),
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def set_knowledge(self, key: str, value: str) -> None:
        self._execute(
            "INSERT OR REPLACE INTO knowledge (key, value, updated_at) VALUES (?,?,?)",
            (key, value, _utcnow()),
        )
        self._commit()

    def get_knowledge(self, key: str) -> str | None:
        row = self._execute("SELECT value FROM knowledge WHERE key=?", (key,))
        if row is None:
            return None
        r = row.fetchone()
        return r["value"] if r else None

    def list_knowledge(self, limit: int = 20) -> list[dict]:
        rows = self._execute(
            "SELECT * FROM knowledge ORDER BY updated_at DESC LIMIT ?", (limit,)
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def search_knowledge(self, query: str, limit: int = 20) -> list[dict]:
        """Search knowledge entries by key or value text."""
        pattern = f"%{query}%"
        rows = self._execute(
            "SELECT * FROM knowledge WHERE key LIKE ? OR value LIKE ? ORDER BY updated_at DESC LIMIT ?",
            (pattern, pattern, limit),
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def get_project_plans(self, limit: int = 10) -> list[dict]:
        """Retrieve all saved project plans as summary dicts."""
        rows = self._execute(
            "SELECT key, value, updated_at FROM knowledge WHERE key LIKE 'project_plan:%' ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        )
        if rows is None:
            return []
        results = []
        for r in rows.fetchall():
            try:
                val = json.loads(r["value"])
                results.append({
                    "id": val.get("id", r["key"]),
                    "task": val.get("task", "")[:80],
                    "status": val.get("status", "?"),
                    "phases": len(val.get("phases", [])),
                    "done": sum(1 for p in val.get("phases", []) if p["status"] == "done"),
                    "updated_at": r["updated_at"],
                })
            except (json.JSONDecodeError, TypeError):
                continue
        return results

    def count_decisions(self) -> int:
        row = self._execute("SELECT COUNT(*) as cnt FROM decisions")
        if row is None:
            return 0
        r = row.fetchone()
        return r["cnt"] if r else 0

    # ------------------------------------------------------------------
    # Fix Patterns (RepairMemory)
    # ------------------------------------------------------------------

    def add_fix_pattern(
        self, fingerprint: str, error_type: str, error_message: str,
        language: str, fix_template: str, file_pattern: str = "",
        max_patterns: int = 1000,
    ) -> str | None:
        """Insert a new fix pattern. Returns fingerprint or None on error.

        If the fingerprint already exists, it is not overwritten — first
        successful fix for a given error is canonical.
        """
        existing = self.get_fix_pattern(fingerprint)
        if existing:
            return fingerprint

        row = self._execute("SELECT COUNT(*) as cnt FROM fix_patterns")
        if row:
            r = row.fetchone()
            if r and r["cnt"] >= max_patterns:
                self.evict_lowest_confidence_pattern()

        now = _utcnow()
        confidence = (0 + 1) / (0 + 0 + 2)  # Laplace: 0.5 initial
        self._execute(
            "INSERT INTO fix_patterns "
            "(fingerprint, error_type, error_message, language, fix_template, "
            "file_pattern, success_count, fail_count, confidence, first_seen, last_used) "
            "VALUES (?,?,?,?,?,?,0,0,?,?,?)",
            (fingerprint, error_type, error_message[:500], language,
             fix_template[:2000], file_pattern, confidence, now, now),
        )
        self._commit()
        return fingerprint

    def get_fix_pattern(self, fingerprint: str) -> dict | None:
        """Get a single fix pattern by fingerprint."""
        row = self._execute(
            "SELECT * FROM fix_patterns WHERE fingerprint=?", (fingerprint,)
        )
        if row is None:
            return None
        r = row.fetchone()
        return dict(r) if r else None

    def find_fix_patterns(
        self, fingerprints: list[str], min_confidence: float = 0.0,
    ) -> list[dict]:
        """Find all fix patterns matching any of the given fingerprints.

        Results are ordered by confidence descending.
        """
        if not fingerprints:
            return []
        placeholders = ",".join("?" for _ in fingerprints)
        rows = self._execute(
            f"SELECT * FROM fix_patterns "
            f"WHERE fingerprint IN ({placeholders}) AND confidence >= ? "
            f"ORDER BY confidence DESC",
            tuple(fingerprints) + (min_confidence,),
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def update_fix_pattern_result(self, fingerprint: str, success: bool) -> None:
        """Update success/fail count and recalculate confidence."""
        now = _utcnow()
        if success:
            self._execute(
                "UPDATE fix_patterns SET success_count = success_count + 1, "
                "last_used = ? WHERE fingerprint = ?",
                (now, fingerprint),
            )
        else:
            self._execute(
                "UPDATE fix_patterns SET fail_count = fail_count + 1, "
                "last_used = ? WHERE fingerprint = ?",
                (now, fingerprint),
            )
        self._commit()

        row = self._execute(
            "SELECT success_count, fail_count FROM fix_patterns WHERE fingerprint = ?",
            (fingerprint,),
        )
        if row:
            r = row.fetchone()
            if r:
                s = r["success_count"]
                f = r["fail_count"]
                conf = (s + 1) / (s + f + 2)  # Laplace smoothing
                self._execute(
                    "UPDATE fix_patterns SET confidence = ? WHERE fingerprint = ?",
                    (conf, fingerprint),
                )
                self._commit()

    def evict_lowest_confidence_pattern(self) -> None:
        """Remove the pattern with the lowest confidence (oldest on tie)."""
        self._execute(
            "DELETE FROM fix_patterns WHERE id = ("
            "SELECT id FROM fix_patterns ORDER BY confidence ASC, last_used ASC LIMIT 1"
            ")"
        )
        self._commit()

    def fix_pattern_count(self) -> int:
        """Return total number of stored fix patterns."""
        row = self._execute("SELECT COUNT(*) as cnt FROM fix_patterns")
        if row is None:
            return 0
        r = row.fetchone()
        return r["cnt"] if r else 0

    def fix_pattern_high_confidence_count(self, min_confidence: float) -> int:
        """Return number of fix patterns with confidence >= min_confidence."""
        row = self._execute(
            "SELECT COUNT(*) as cnt FROM fix_patterns WHERE confidence >= ?",
            (min_confidence,),
        )
        if row is None:
            return 0
        r = row.fetchone()
        return r["cnt"] if r else 0

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    # ------------------------------------------------------------------
    # Self Learning
    # ------------------------------------------------------------------

    def log_learning_event(
        self,
        task_id: str,
        task_text: str,
        task_type: str,
        provider: str = "",
        success: bool = False,
        complexity: int = 1,
        tool_calls: int = 0,
        files_touched_json: str = "[]",
        domains_json: str = "[]",
        result_summary: str = "",
    ) -> None:
        self._execute(
            """INSERT INTO learning_events
               (task_id, task_text, task_type, provider, success, complexity, tool_calls,
                files_touched, domains, result_summary, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                task_id,
                task_text[:500],
                task_type[:80],
                provider[:80],
                int(success),
                complexity,
                tool_calls,
                files_touched_json,
                domains_json,
                result_summary[:1000],
                _utcnow(),
            ),
        )
        self._commit()

    def recent_learning_events(self, limit: int = 20) -> list[dict]:
        rows = self._execute(
            "SELECT * FROM learning_events ORDER BY id DESC LIMIT ?",
            (limit,),
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def upsert_learning_pattern(
        self,
        fingerprint: str,
        pattern_type: str,
        scope: str,
        summary: str,
        source_task_id: str = "",
        metadata_json: str = "{}",
    ) -> dict | None:
        existing = self.get_learning_pattern(fingerprint)
        now = _utcnow()
        if existing is None:
            self._execute(
                """INSERT INTO learning_patterns
                   (fingerprint, pattern_type, scope, summary, evidence_count, confidence, status,
                    source_task_id, metadata_json, first_seen, last_seen)
                   VALUES (?,?,?,?,1,0.5,'observed',?,?,?,?)""",
                (
                    fingerprint,
                    pattern_type[:80],
                    scope[:120],
                    summary[:500],
                    source_task_id,
                    metadata_json[:2000],
                    now,
                    now,
                ),
            )
            self._commit()
            return self.get_learning_pattern(fingerprint)

        evidence_count = int(existing.get("evidence_count", 0)) + 1
        confidence = min(0.95, 0.35 + evidence_count * 0.15)
        status = existing.get("status", "observed")
        if evidence_count >= 3 and status == "observed":
            status = "candidate"
        self._execute(
            """UPDATE learning_patterns
               SET summary=?, evidence_count=?, confidence=?, status=?, source_task_id=?,
                   metadata_json=?, last_seen=?
               WHERE fingerprint=?""",
            (
                summary[:500],
                evidence_count,
                confidence,
                status,
                source_task_id,
                metadata_json[:2000],
                now,
                fingerprint,
            ),
        )
        self._commit()
        return self.get_learning_pattern(fingerprint)

    def get_learning_pattern(self, fingerprint: str) -> dict | None:
        row = self._execute(
            "SELECT * FROM learning_patterns WHERE fingerprint=?",
            (fingerprint,),
        )
        if row is None:
            return None
        r = row.fetchone()
        return dict(r) if r else None

    def list_learning_patterns(self, limit: int = 20, min_evidence: int = 1) -> list[dict]:
        rows = self._execute(
            """SELECT * FROM learning_patterns
               WHERE evidence_count >= ?
               ORDER BY confidence DESC, evidence_count DESC, last_seen DESC
               LIMIT ?""",
            (min_evidence, limit),
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def create_learning_asset(
        self,
        asset_type: str,
        name: str,
        summary: str,
        status: str = "draft",
        source_fingerprint: str = "",
        file_path: str = "",
    ) -> dict | None:
        existing = self.get_learning_asset(asset_type, name)
        now = _utcnow()
        if existing is not None:
            self._execute(
                """UPDATE learning_assets
                   SET summary=?, status=?, source_fingerprint=?, file_path=?, updated_at=?
                   WHERE asset_type=? AND name=?""",
                (
                    summary[:500],
                    status[:40],
                    source_fingerprint[:120],
                    file_path[:500],
                    now,
                    asset_type,
                    name,
                ),
            )
            self._commit()
            return self.get_learning_asset(asset_type, name)

        self._execute(
            """INSERT INTO learning_assets
               (asset_type, name, summary, status, source_fingerprint, file_path, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                asset_type[:40],
                name[:120],
                summary[:500],
                status[:40],
                source_fingerprint[:120],
                file_path[:500],
                now,
                now,
            ),
        )
        self._commit()
        return self.get_learning_asset(asset_type, name)

    def get_learning_asset(self, asset_type: str, name: str) -> dict | None:
        row = self._execute(
            "SELECT * FROM learning_assets WHERE asset_type=? AND name=?",
            (asset_type, name),
        )
        if row is None:
            return None
        r = row.fetchone()
        return dict(r) if r else None

    def list_learning_assets(self, limit: int = 20, status: str | None = None) -> list[dict]:
        if status:
            rows = self._execute(
                """SELECT * FROM learning_assets
                   WHERE status=?
                   ORDER BY updated_at DESC, id DESC
                   LIMIT ?""",
                (status, limit),
            )
        else:
            rows = self._execute(
                "SELECT * FROM learning_assets ORDER BY updated_at DESC, id DESC LIMIT ?",
                (limit,),
            )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()
