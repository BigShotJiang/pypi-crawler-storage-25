"""REPL command handlers — /help, /search, /undo, /agents, etc."""
from __future__ import annotations

import os
import uuid
from pathlib import Path

from widdx import ui
from widdx.ui.arabic import _d


def _handle_command(self, cmd: str) -> bool:
    parts = cmd.split(maxsplit=1)
    command = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    if command == "/exit" or command == "/quit" or command == "/q":
        self._exit()
        return True

    if command == "/help" or command == "/h":
        _show_help(self)
    elif command == "/clear" or command == "/c":
        from widdx import ui
        if self._messages and not ui.confirm("Clear all conversation history?"):
            return False
        self._messages.clear()
        self._tool_loop.clear_context()
        ui.get_console().print("  [dim]Conversation cleared.[/]")
    elif command == "/compact":
        result = self._tool_loop.compact()
        self._messages = list(self._tool_loop._messages)
        from widdx import ui
        ui.get_console().print(f"  [success]{result}[/]")
    elif command == "/index":
        self._index_project()
    elif command == "/git":
        _show_git(self)
    elif command == "/search" or command == "/grep":
        _search(self, arg)
    elif command == "/undo":
        _undo(self)
    elif command == "/approve":
        self._tool_loop._permissions.approve_session()
        from widdx import ui
        ui.get_console().print("  [success]✓ Permissions approved for this session.[/]")
    elif command == "/deny":
        self._tool_loop._permissions.deny_session()
        from widdx import ui
        ui.get_console().print("  [warning]⚠ Shell commands blocked for this session.[/]")
    elif command == "/agents":
        _run_agents(self, arg)
    elif command == "/save":
        _save_session_cmd(self, arg)
    elif command == "/sessions":
        _list_sessions_cmd(self)
    elif command == "/resume":
        _resume(self, arg)
    elif command == "/plan":
        _plan_project(self, arg)
    elif command == "/plans":
        _list_plans(self)
    elif command == "/model":
        _show_model_info(self)
    elif command == "/tasks":
        _show_task_history(self)
    elif command == "/llm":
        _send_to_llm(self, arg)
    elif command == "/memory":
        _show_memory(self)
    elif command == "/learn":
        _show_learning(self)
    elif command == "/skills":
        _show_skills(self)
    elif command == "/hooks":
        _show_hooks(self)
    elif command == "/mcp":
        _show_mcp(self, arg)
    elif command == "/bootstrap":
        _bootstrap(self, arg)
    elif command == "/projects":
        _list_projects(self)
    elif command == "/knowledge":
        _search_knowledge(self, arg)
    elif command == "/providers":
        _show_providers(self, arg)
    elif command == "/provider":
        _set_active_provider(self, arg)
    elif command == "/key":
        _set_api_key(self, arg)
    else:
        from widdx import ui
        # Check if this is a skill command (/<skill-name>)
        skill_name = command[1:]  # strip the leading /
        skill_manager = getattr(self._tool_loop, '_skill_manager', None)
        if skill_manager:
            skill_content = skill_manager.get_skill(skill_name)
            if skill_content:
                self._execute_task(skill_content)
                return False
        ui.get_console().print(f"  [dim]Unknown command: {command}[/]")
        _show_help(self)

    return False


def _show_help(self) -> None:
    from rich import box as rich_box
    from rich.panel import Panel
    from rich.text import Text

    from widdx import ui

    c = ui.get_console()

    content = Text()

    # Session
    content.append("\n  SESSION\n", style="bold #00d4ff")
    content.append("  /clear    ", style="#38bdf8"); content.append("clear conversation\n", style="#6c7086")
    content.append("  /compact  ", style="#38bdf8"); content.append("summarize history to save tokens\n", style="#6c7086")
    content.append("  /save     ", style="#38bdf8"); content.append("/save <name>  — save session to disk\n", style="#6c7086")
    content.append("  /sessions ", style="#38bdf8"); content.append("list saved sessions\n", style="#6c7086")
    content.append("  /resume   ", style="#38bdf8"); content.append("/resume [name]  — restore session\n", style="#6c7086")
    content.append("  /exit     ", style="#38bdf8"); content.append("exit WIDDX\n", style="#6c7086")

    # Project
    content.append("\n  PROJECT\n", style="bold #00d4ff")
    content.append("  /index    ", style="#38bdf8"); content.append("re-scan project files\n", style="#6c7086")
    content.append("  /git      ", style="#38bdf8"); content.append("show git status\n", style="#6c7086")
    content.append("  /search   ", style="#38bdf8"); content.append("/search <pattern>  — regex search\n", style="#6c7086")
    content.append("  /undo     ", style="#38bdf8"); content.append("restore files from this session\n", style="#6c7086")
    content.append("  /memory   ", style="#38bdf8"); content.append("show WIDDX.md content\n", style="#6c7086")
    content.append("  /learn    ", style="#38bdf8"); content.append("show self-learning ledger and draft assets\n", style="#6c7086")

    # Agents
    content.append("\n  AGENTS & AI\n", style="bold #00d4ff")
    content.append("  /agents   ", style="#38bdf8"); content.append("/agents <task>  — multi-agent team\n", style="#6c7086")
    content.append("  /skills   ", style="#38bdf8"); content.append("list available skills\n", style="#6c7086")
    content.append("  /hooks    ", style="#38bdf8"); content.append("show loaded hooks\n", style="#6c7086")
    content.append("  /mcp      ", style="#38bdf8"); content.append("show MCP servers  ·  /mcp add <n> <cmd>\n", style="#6c7086")
    content.append("  /bootstrap", style="#38bdf8"); content.append(" <tech>  — generate skills for a technology\n", style="#6c7086")

    # Projects
    content.append("\n  PROJECTS\n", style="bold #00d4ff")
    content.append("  /plan     ", style="#38bdf8"); content.append("/plan <desc>  — create & run a phased project plan\n", style="#6c7086")
    content.append("  /plans    ", style="#38bdf8"); content.append("list all saved project plans\n", style="#6c7086")
    content.append("  /projects ", style="#38bdf8"); content.append("list all previous projects + phase status\n", style="#6c7086")
    content.append("  /knowledge", style="#38bdf8"); content.append("/knowledge <query>  — search past project memory\n", style="#6c7086")
    content.append("  /resume   ", style="#38bdf8"); content.append("/resume [name|plan_id]  — restore session or resume plan\n", style="#6c7086")

    # Info
    content.append("\n  INFO\n", style="bold #00d4ff")
    content.append("  /model    ", style="#38bdf8"); content.append("model info and session cost\n", style="#6c7086")
    content.append("  /tasks    ", style="#38bdf8"); content.append("task history\n", style="#6c7086")
    content.append("  /providers", style="#38bdf8"); content.append("list providers · /providers toggle <name>\n", style="#6c7086")
    content.append("  /provider ", style="#38bdf8"); content.append("/provider <name>  — use only one provider\n", style="#6c7086")
    content.append("  /key      ", style="#38bdf8"); content.append("/key <sk-...>  — set DeepSeek API key\n", style="#6c7086")
    content.append("  /approve  ", style="#38bdf8"); content.append("allow all shell commands this session\n", style="#6c7086")
    content.append("  /deny     ", style="#38bdf8"); content.append("block shell commands this session\n", style="#6c7086")
    content.append("  /llm      ", style="#38bdf8"); content.append("/llm <prompt>  — direct LLM call\n", style="#6c7086")

    content.append("\n  ", style="")
    content.append("@file.py", style="bold #00d4ff")
    content.append("  attaches file context to your task\n", style="#6c7086")

    c.print()
    c.print(Panel(
        content,
        title="[bold #00d4ff]◆  WIDDX  COMMAND REFERENCE[/]",
        border_style="#00d4ff",
        box=rich_box.DOUBLE,
        padding=(0, 1),
    ))
    c.print()


def _show_git(self) -> None:
    if not self._git.is_repo:
        from widdx import ui
        ui.get_console().print("  [dim]Not a git repository.[/]")
        return
    branch = self._git.current_branch()
    status = self._git.status()
    changes = status.get("changed", 0)
    files = status.get("files", [])

    from widdx import ui
    ui.get_console().print(f"\n  [dim]Branch:[/] [text]{_d(branch)}[/]")
    if changes > 0:
        ui.get_console().print(f"  [warning]Changes:[/] [text]{changes} files[/]")
        for f in files[:5]:
            ui.get_console().print(f"    [warning]{_d(f[:60])}[/]")
        if changes > 5:
            ui.get_console().print(f"    [dim]... and {changes - 5} more[/]")
    else:
        ui.get_console().print("  [success]Working tree clean[/]")
    ui.get_console().print()


def _search(self, query: str) -> None:
    if not query:
        from widdx import ui
        ui.get_console().print("  [dim]Usage: /search <pattern>[/]")
        return
    from widdx.tools import search
    result = search.tool_grep(query, directory=".")
    from widdx import ui
    ui.show_search(query, result.get("matches", []), result.get("count", 0))


def _undo(self) -> None:
    import shutil

    backups = self._tool_loop._backups
    created_files = self._tool_loop._created_files

    from widdx import ui
    if not backups and not created_files:
        ui.get_console().print("  [dim]Nothing to undo (no edits or creations found for this session).[/]")
        return

    ui.get_console().print("\n  [brand]Restoring previous state...[/]")

    cwd = Path.cwd().resolve()
    for original, backup in backups.items():
        orig_path = Path(original).resolve()
        backup_path = Path(backup).resolve()

        # Safety: only restore files within the project directory
        if not str(orig_path).startswith(str(cwd)):
            ui.get_console().print(f"    [dim]Skipped (outside project): {orig_path.name}[/]")
            continue

        if backup_path.exists():
            try:
                shutil.copy2(backup_path, orig_path)
                ui.get_console().print(f"    [success]✓[/] Restored [text]{orig_path.name}[/]")
            except Exception as e:
                ui.get_console().print(f"    [error]✗[/] Failed to restore [text]{orig_path.name}[/]: {e}")

    for created in created_files:
        cp = Path(created).resolve()
        # Safety: only delete files within the project directory
        if not str(cp).startswith(str(cwd)):
            continue
        if cp.exists():
            try:
                cp.unlink()
                ui.get_console().print(f"    [warning]⚠[/] Deleted created file [text]{cp.name}[/]")
            except Exception:
                pass

    self._tool_loop.clear_context()
    ui.get_console().print("  [success]Undo complete.[/]\n")


def _show_model_info(self) -> None:
    from rich import box as rich_box
    from rich.panel import Panel
    from rich.text import Text

    from widdx import ui

    models = self._config.get("models", {})
    arch  = models.get("architect", {}).get("model", "?")
    exec_ = models.get("executor",  {}).get("model", "?")
    tokens = self._router.session_tokens
    cost   = self._router.session_cost
    total  = tokens["input"] + tokens["output"]

    c = ui.get_console()

    t = Text()
    t.append("\n  MODELS\n", style="bold #00d4ff")
    t.append("  architect   ", style="#38bdf8"); t.append(f"{arch}\n", style="#cdd6f4")
    t.append("  executor    ", style="#38bdf8"); t.append(f"{exec_}\n", style="#cdd6f4")

    t.append("\n  SESSION USAGE\n", style="bold #00d4ff")
    t.append("  tokens in   ", style="#38bdf8"); t.append(f"{tokens['input']:,}\n", style="#cdd6f4")
    t.append("  tokens out  ", style="#38bdf8"); t.append(f"{tokens['output']:,}\n", style="#cdd6f4")
    t.append("  total       ", style="#38bdf8"); t.append(f"{total:,}\n", style="#cdd6f4")
    t.append("  cost        ", style="#38bdf8"); t.append(f"${cost:.4f}\n", style="#00ff88")

    c.print()
    c.print(Panel(t, title="[bold #00d4ff]◆  SYSTEM STATUS[/]",
                  border_style="#00d4ff", box=rich_box.DOUBLE, padding=(0, 1)))
    c.print()


def _show_task_history(self) -> None:
    from rich import box as rich_box
    from rich.panel import Panel
    from rich.text import Text

    from widdx import ui

    tasks = self._memory.recent_tasks(10)
    c = ui.get_console()

    if not tasks:
        c.print("  [dim]No tasks yet.[/]")
        return

    t = Text()
    t.append("\n")
    for task in tasks:
        if task["status"] == "completed":
            icon, col = "✓", "#00ff88"
        elif task["status"] == "failed":
            icon, col = "✗", "#ff3355"
        else:
            icon, col = "·", "#ffb300"

        ts  = task.get("created_at", "")[:16].replace("T", " ")
        cmd = _d(task["command"][:60])

        t.append(f"  {icon} ", style=f"bold {col}")
        t.append(f"{ts}  ", style="#45475a")
        t.append(f"{cmd}\n", style="#cdd6f4")

    c.print()
    c.print(Panel(t, title="[bold #00d4ff]◆  TASK HISTORY[/]",
                  border_style="#00d4ff", box=rich_box.DOUBLE, padding=(0, 1)))
    c.print()


def _send_to_llm(self, prompt: str) -> None:
    from widdx import ui
    if not prompt:
        ui.get_console().print("  [dim]Usage: /llm <prompt>[/]")
        return
    result = self._tool_loop.run(prompt, conversation_history=self._messages)
    ui.get_console().print()
    ui.get_console().print(f"  {result}")


def _save_session_cmd(self, name: str) -> None:
    """Save the current session to disk."""
    from widdx import ui
    c = ui.get_console()
    if not self._messages:
        c.print("  [dim]Nothing to save — empty session.[/]")
        return
    path = self._save_session(name if name else None)
    c.print(f"  [success]Session saved:[/] [text]{Path(path).name}[/]")


def _list_sessions_cmd(self) -> None:
    """List all saved sessions."""
    from widdx import ui
    c = ui.get_console()
    sessions = self._list_sessions()
    if not sessions:
        c.print()
        c.print("  [dim]No saved sessions found.[/]")
        c.print(f"  [dim]Sessions directory: {self._sessions_dir}[/]")
        c.print()
        return
    c.print()
    c.print("  [brand]Saved Sessions:[/]")
    c.print(f"  [dim]{'─' * 60}[/]")
    for s in sessions[:20]:
        saved = s["saved_at"][:19].replace("T", " ") if s["saved_at"] else "?"
        c.print(
            f"  [highlight]{_d(s['name'])}[/]  [dim]{saved}[/]  "
            f"[text]{s['msg_count']} msgs, {s['task_count']} tasks[/]"
        )
    if len(sessions) > 20:
        c.print(f"  [dim]... and {len(sessions) - 20} more[/]")
    c.print()


def _resume(self, name: str = "") -> None:
    """Resume: session file, project plan, or last incomplete task."""
    c = ui.get_console()

    if name:
        import re as _re
        # 12-char hex → project plan ID
        if _re.fullmatch(r"[0-9a-f]{12}", name):
            _resume_plan(self, name)
            return
        # Named session file
        if self._load_session(name):
            c.print()
            c.print(f"  [success]\u25c6 Loaded session:[/] [text]{_d(name)}[/]")
            c.print(f"  [dim]  Messages: {len(self._messages)} \u00b7 Tasks: {self._task_count}[/]")
            c.print()
            return
        c.print(f"  [warning]Not found:[/] [dim]'{_d(name)}'[/]")
        c.print("  [dim]Try: /sessions \u00b7 /plans[/]")
        return

    # No name \u2192 last incomplete task
    tasks = self._memory.recent_tasks(20)
    incomplete = [t for t in tasks if t.get("status") not in ("completed", "failed")]
    if not incomplete:
        c.print("  [dim]No incomplete tasks found.[/]")
        return

    task    = incomplete[0]
    command = task.get("command", "")
    tid     = task.get("id", "")[:8]
    created = task.get("created_at", "")[:19].replace("T", " ")

    c.print()
    c.print(f"  [brand]\u25c6 Resuming task[/] [dim]{tid}[/]  [muted]{created}[/]")
    c.print(f"  [dim]  {_d(command[:90])}[/]")
    c.print()

    decisions = self._memory.task_decisions(task.get("id", ""))
    if decisions:
        lines = ["Previous progress:"]
        for d in decisions[-5:]:
            s = d.get("output_summary", "")[:120]
            if s:
                lines.append(f"- [{d.get('stage','')}] {s}")
        ctx = "\n".join(lines)
        self._messages = [
            {"role": "user",      "content": command},
            {"role": "assistant", "content": ctx},
        ]
        self._tool_loop._messages = list(self._messages)

    self._execute_task(command)


def _resume_plan(self, plan_id: str) -> None:
    """Resume an interrupted ProjectPlanner plan by plan_id."""
    c = ui.get_console()
    from widdx.agent_factory import AgentFactory
    from widdx.project_planner import ProjectPlanner

    router = getattr(self._tool_loop, "_router", None)
    if not router:
        c.print("  [error]No router available.[/]")
        return

    planner = ProjectPlanner(router, self._memory)
    plan    = planner.resume_plan(plan_id)

    if plan is None:
        c.print(f"  [warning]Plan '{plan_id}' not found.[/]")
        c.print("  [dim]Use /plans to list saved plans.[/]")
        return

    done  = len(plan.completed_phases)
    total = len(plan.phases)
    c.print()
    c.print(f"  [brand]\u25c6 Resuming plan[/] [dim]{plan.id}[/]")
    c.print(f"  [text]{plan.task[:70]}[/]")
    c.print(f"  [dim]Progress: {done}/{total} phases  ({plan.progress_pct()}%)[/]")
    c.print()

    if plan.next_phase is None:
        c.print("  [success]\u2713 All phases already completed![/]")
        return

    planner.execute_plan(plan, AgentFactory(router))


def _plan_project(self, description: str) -> None:
    """/plan — Create and execute a phased ProjectPlanner plan.

    Usage: /plan Build a SaaS e-commerce platform with FastAPI and React
    """
    c = ui.get_console()

    if not description:
        c.print()
        c.print("  [dim]Usage: /plan <description>[/]")
        c.print("  [dim]Example: /plan Build a REST API with auth and a React frontend[/]")
        c.print()
        c.print("  [dim]Phases are executed sequentially with context passed between them.[/]")
        c.print("  [dim]Progress is saved \u2014 resume with: /resume <plan_id>[/]")
        c.print()
        return

    from widdx.agent_factory import AgentFactory
    from widdx.project_planner import ProjectPlanner

    router = getattr(self._tool_loop, "_router", None)
    if not router:
        c.print("  [error]No router available.[/]")
        return

    planner      = ProjectPlanner(router, self._memory)
    agent_factory = AgentFactory(router)

    c.print()
    plan = planner.create_plan(description)
    c.print()

    # Preview
    c.print(f"  [bold text]{plan.task[:75]}[/]")
    if plan.tech_stack:
        c.print(f"  [dim]Stack: {', '.join(plan.tech_stack)}[/]")
    c.print(f"  [dim]Plan ID: {plan.id}[/]")
    c.print()

    for ph in plan.phases:
        c.print(f"  [dim]\u25cb[/] [text]Phase {ph.number}:[/] {ph.title}")
        for d in ph.deliverables[:3]:
            c.print(f"       [dim]\u00b7 {d}[/]")
        if len(ph.deliverables) > 3:
            c.print(f"       [dim]\u2026 +{len(ph.deliverables) - 3} more[/]")
    c.print()

    if not ui.confirm(f"Execute this {len(plan.phases)}-phase plan?"):
        c.print(f"  [dim]Saved. Resume with: /resume {plan.id}[/]")
        return

    c.print()
    planner.execute_plan(plan, agent_factory)


def _list_plans(self) -> None:
    """/plans — List all saved ProjectPlanner plans."""
    c = ui.get_console()
    from widdx.project_planner import ProjectPlanner

    router = getattr(self._tool_loop, "_router", None)
    if not router:
        c.print("  [error]No router available.[/]")
        return

    plans = ProjectPlanner(router, self._memory).list_plans()

    if not plans:
        c.print()
        c.print("  [dim]No saved plans. Start one with: /plan <description>[/]")
        c.print()
        return

    c.print()
    ui.rule("Project Plans")
    c.print()

    status_style = {
        "done": "success", "running": "brand",
        "failed": "error",  "partial": "warning",
    }
    for p in plans:
        done  = p["done"]
        total = p["phases"]
        pct   = int(done / total * 100) if total else 0
        bar   = "\u2588" * (pct // 10) + "\u2591" * (10 - pct // 10)
        sty   = status_style.get(p["status"], "dim")
        c.print(f"  [{sty}]\u25cf[/] [text]{p['task'][:58]}[/]")
        c.print(f"     [dim]{bar} {pct}%  \u00b7  {done}/{total} phases  \u00b7  {p['status']}[/]")
        c.print(f"     [dim]/resume {p['id']}[/]")
        c.print()


def _run_agents(self, task: str) -> None:
    """Run a multi-agent team on a complex task."""
    from widdx import ui
    if not task:
        ui.get_console().print("  [dim]Usage: /agents <task description>[/]")
        ui.get_console().print("  [dim]Example: /agents build a REST API with authentication and a React frontend[/]")
        return

    from widdx.agent_factory import AgentFactory

    c = ui.get_console()
    c.print()
    c.print("  [brand]◆ Multi-Agent Mode[/]")
    c.print(f"  [dim]Task: {task}[/]")
    c.print()

    factory = AgentFactory(self._router)

    c.print("  [dim]Designing agent team...[/]")
    complexity = self._estimate_complexity(task)
    specs = factory.generate_team(task, complexity)

    c.print(f"  [success]Team:[/] {len(specs)} agent{'s' if len(specs) != 1 else ''}")
    for s in specs:
        deps = f" (after: {', '.join(s.depends_on)})" if s.depends_on else ""
        c.print(f"    [dim]•[/] [highlight]{s.role}[/] [dim]— {s.goal[:60]}{deps}[/]")
    c.print()

    task_id = uuid.uuid4().hex[:12]
    self._memory.create_task(task_id, task, task, complexity)

    project_context = self._tool_loop._project_context
    result = factory.execute_team(specs, task, task_id, self._memory, project_context)

    self._memory.complete_task(task_id)

    c.print()
    c.print(f"  [dim]{'─' * 60}[/]")
    try:
        ui.render_markdown(result)
    except Exception:
        c.print(f"  [text]{ui.reshape(result[:2000])}[/]")


def _show_memory(self) -> None:
    """Display the currently loaded WIDDX.md content."""
    from widdx import ui
    c = ui.get_console()

    content = getattr(self, "_project_md", "")
    if not content:
        c.print("  [dim]No WIDDX.md loaded. Create a WIDDX.md (or CLAUDE.md) in your project root.[/]")
        return

    c.print()
    c.print("  [brand]WIDDX.md — Project Memory[/]")
    c.print(f"  [dim]{'─' * 60}[/]")
    try:
        ui.render_markdown(content)
    except Exception:
        c.print(f"  [text]{content}[/]")
    c.print()


def _show_learning(self) -> None:
    """Display recent learning events, recurring patterns, and draft assets."""
    from widdx import ui
    c = ui.get_console()

    learner = getattr(self, "_self_learning", None)
    if learner is None or not learner.is_enabled:
        c.print("  [dim]Self-learning is not enabled.[/]")
        return

    dashboard = learner.dashboard(limit=8)
    events = dashboard.get("events", [])
    patterns = dashboard.get("patterns", [])
    assets = dashboard.get("assets", [])

    c.print()
    c.print("  [brand]Learning Ledger[/]")
    c.print(f"  [dim]{'─' * 60}[/]")

    if events:
        c.print("  [highlight]Recent Events[/]")
        for event in events[:5]:
            status = "success" if event.get("success") else "warning"
            provider = event.get("provider") or "unknown"
            c.print(
                f"    [{status}]•[/] [text]{event.get('task_type', 'general')}[/] "
                f"[dim]via {provider}[/]  "
                f"[dim]{str(event.get('task_text', ''))[:54]}[/]"
            )
    else:
        c.print("  [dim]No learning events recorded yet.[/]")

    c.print()
    if patterns:
        c.print("  [highlight]Recurring Patterns[/]")
        for pattern in patterns[:5]:
            c.print(
                f"    [dim]•[/] [text]{pattern.get('scope', '')}[/]  "
                f"[dim]evidence={pattern.get('evidence_count', 0)} "
                f"confidence={float(pattern.get('confidence', 0.0)):.2f}[/]"
            )
    else:
        c.print("  [dim]No recurring patterns yet.[/]")

    c.print()
    if assets:
        c.print("  [highlight]Draft Assets[/]")
        for asset in assets[:5]:
            c.print(
                f"    [dim]•[/] [text]{asset.get('asset_type', '')}:{asset.get('name', '')}[/]  "
                f"[dim]{asset.get('status', 'draft')}[/]"
            )
    else:
        c.print("  [dim]No draft skills/agents yet.[/]")
    c.print()


def _show_skills(self) -> None:
    """Display all available skills with their descriptions and invocation mode."""
    from widdx import ui
    c = ui.get_console()

    skill_manager = self._tool_loop._skill_manager
    skills = skill_manager.list_skills()

    if not skills:
        c.print()
        c.print("  [dim]No skills loaded.[/]")
        c.print("  [dim]Add skill files (*.md) to:[/]")
        c.print("  [dim]  ~/.widdx/skills/   (user-level)[/]")
        c.print("  [dim]  .widdx/skills/     (project-level)[/]")
        c.print()
        return

    c.print()
    c.print("  [brand]Available Skills:[/]")
    c.print(f"  [dim]{'─' * 60}[/]")

    # Determine auto_invoke status for each skill by checking the manager internals
    skill_meta = {s["name"]: s.get("auto_invoke", False) for s in skill_manager._skills}

    for name, description in skills:
        auto = skill_meta.get(name, False)
        mode = "[success]auto[/]" if auto else "[dim]manual[/]"
        c.print(f"  [highlight]{_d(name)}[/]  [{mode}]  [text]{_d(description)}[/]")

    c.print()


def _show_hooks(self) -> None:
    """Display all loaded hooks grouped by event name."""
    from widdx import ui
    c = ui.get_console()

    hook_manager = getattr(self._tool_loop, "_hook_manager", None)
    if hook_manager is None:
        c.print("  [dim]Hook manager not available.[/]")
        return

    hooks = hook_manager.all_hooks()

    if not hooks:
        c.print()
        c.print("  [dim]No hooks loaded.[/]")
        c.print("  [dim]Add a hooks.json to:[/]")
        c.print("  [dim]  ~/.widdx/hooks.json   (user-level)[/]")
        c.print("  [dim]  .widdx/hooks.json     (project-level)[/]")
        c.print()
        return

    c.print()
    c.print("  [brand]Loaded Hooks:[/]")
    c.print(f"  [dim]{'─' * 60}[/]")

    for event_name, hook_list in hooks.items():
        c.print(f"  [highlight]{event_name}[/]  [dim]({len(hook_list)} hook{'s' if len(hook_list) != 1 else ''})[/]")
        for hook in hook_list:
            hook_type = hook.get("type", "command")
            matcher = hook.get("matcher", "")
            is_async = hook.get("async", False)

            parts: list[str] = [f"[text]{hook_type}[/]"]
            if matcher:
                parts.append(f"[dim]matcher:[/] [text]{matcher}[/]")
            if is_async:
                parts.append("[dim]async[/]")

            c.print(f"    [dim]•[/] {' '.join(parts)}")

    c.print()


def _show_mcp(self, arg: str) -> None:
    """Display connected MCP servers and their tools, or add a new server.

    Usage:
      /mcp                     — list all connected servers and tools
      /mcp add <name> <cmd>    — add a new MCP server (stdio transport)
    """
    from widdx import ui
    c = ui.get_console()

    mcp_registry = getattr(self._tool_loop, "_mcp_registry", None)
    if mcp_registry is None:
        c.print("  [dim]MCP registry not available.[/]")
        return

    # Handle /mcp add <name> <command>
    if arg.startswith("add "):
        rest = arg[4:].strip()
        parts = rest.split(maxsplit=1)
        if len(parts) < 2:
            c.print("  [dim]Usage: /mcp add <name> <command>[/]")
            c.print("  [dim]Example: /mcp add github uvx mcp-server-github[/]")
            return
        server_name = parts[0]
        server_cmd = parts[1]
        try:
            mcp_registry.add_server(server_name, server_cmd)
            c.print(f"  [success]✓ MCP server '{server_name}' added and connected.[/]")
        except Exception as exc:
            c.print(f"  [error]✗ Failed to add MCP server '{server_name}': {exc}[/]")
        return

    # Handle /mcp remove <name>
    if arg.startswith("remove "):
        server_name = arg[7:].strip()
        if not server_name:
            c.print("  [dim]Usage: /mcp remove <name>[/]")
            return
        removed = mcp_registry.remove_server(server_name)
        if removed:
            c.print(f"  [success]✓ MCP server '{server_name}' removed.[/]")
        else:
            c.print(f"  [warning]No MCP server named '{server_name}' is connected.[/]")
        return

    # Default: list all servers
    servers = mcp_registry.all_servers()

    if not servers:
        c.print()
        c.print("  [dim]No MCP servers connected.[/]")
        c.print("  [dim]Add a server with: /mcp add <name> <command>[/]")
        c.print("  [dim]Or configure ~/.widdx/mcp.json[/]")
        c.print()
        return

    c.print()
    c.print("  [brand]Connected MCP Servers:[/]")
    c.print(f"  [dim]{'─' * 60}[/]")

    for name, info in servers.items():
        status = "[success]●[/]" if info.get("connected") else "[error]○[/]"
        tools = info.get("tools", [])
        c.print(f"  {status} [highlight]{name}[/]  [dim]({len(tools)} tool{'s' if len(tools) != 1 else ''})[/]")
        for tool in tools[:10]:
            c.print(f"    [dim]•[/] [text]{tool}[/]")
        if len(tools) > 10:
            c.print(f"    [dim]... and {len(tools) - 10} more[/]")

    c.print()


def _bootstrap(self, technology: str) -> None:
    """Research a technology and generate project-specific skills, agents, and hooks.

    Usage: /bootstrap laravel
    """
    from widdx import ui
    from widdx.bootstrap import BootstrapManager

    c = ui.get_console()

    if not technology:
        c.print("  [dim]Usage: /bootstrap <technology>[/]")
        c.print("  [dim]Example: /bootstrap laravel[/]")
        c.print("  [dim]Example: /bootstrap nextjs[/]")
        c.print()
        c.print("  [dim]This will:[/]")
        c.print("  [dim]  1. Research the technology documentation[/]")
        c.print("  [dim]  2. Generate a skill file with conventions & patterns[/]")
        c.print("  [dim]  3. Generate an agent for the technology[/]")
        c.print("  [dim]  4. Generate hooks if applicable[/]")
        c.print("  [dim]  5. Save to .widdx/ in your project[/]")
        return

    c.print()
    c.print(f"  [brand]Bootstrapping:[/] [highlight]{technology}[/]")
    c.print("  [dim]Researching best practices, conventions, and patterns...[/]")

    manager = BootstrapManager(self._router)

    try:
        result = manager.bootstrap(technology)
    except Exception as exc:
        c.print(f"  [error]Bootstrap failed: {exc}[/]")
        return

    if result.skills_created or result.agents_created or result.hooks_created:
        c.print("  [success]Done. Created:[/]")
        for s in result.skills_created:
            c.print(f"    [success]+[/] [text]{s}[/]")
        for a in result.agents_created:
            c.print(f"    [success]+[/] [text]{a}[/]")
        for h in result.hooks_created:
            c.print(f"    [success]+[/] [text]{h}[/]")
        c.print()
        c.print(f"  [dim]{result.summary}[/]")
        # Reload skills to include the new one
        self._tool_loop._skill_manager.load()
    else:
        c.print(f"  [warning]{result.summary}[/]")


def _list_projects(self) -> None:
    """List all previous projects with phase status from MemoryStore."""
    from widdx import ui

    c = ui.get_console()
    plans = self._memory.get_project_plans(limit=15)

    if not plans:
        c.print("  [dim]No previous projects found.[/]")
        return

    c.print()
    c.print("  [bold]PREVIOUS PROJECTS[/]")
    for p in plans:
        status_icon = {"done": "[success]✓[/]", "failed": "[error]✗[/]",
                       "partial": "[warning]⚠[/]", "running": "[brand]▶[/]"}
        icon = status_icon.get(p["status"], "[dim]?[/]")
        c.print(
            f"  {icon} [text]{p['task']}[/]"
            f"  [dim]·[/]  [dim]{p['done']}/{p['phases']} phases[/]"
            f"  [dim]·[/]  [dim]id: {p['id']}[/]"
        )
    c.print()


def _search_knowledge(self, query: str) -> None:
    """Search stored knowledge from previous tasks and projects."""
    from widdx import ui

    c = ui.get_console()
    if not query:
        c.print("  [dim]Usage: /knowledge <search query>[/]")
        return

    results = self._memory.search_knowledge(query, limit=10)
    if not results:
        c.print(f"  [dim]No knowledge found for: {query}[/]")
        return

    c.print()
    c.print(f"  [bold]KNOWLEDGE: {query}[/]")
    for r in results:
        key = r.get("key", "")
        value = r.get("value", "")[:120]
        updated = (r.get("updated_at") or "")[:16]
        c.print(f"  [brand]◆[/] [text]{key}[/]")
        c.print(f"    [dim]{value}[/]")
        c.print(f"    [dim]{updated}[/]")
    c.print()


def _show_providers(self, arg: str) -> None:
    """Interactive provider manager — select with ↑↓, toggle with Space, confirm with Enter."""
    from widdx import ui
    c = ui.get_console()
    router = getattr(self, "_router", None)
    if router is None:
        c.print("  [dim]Router not available[/]")
        return

    providers = router.list_providers()
    if not providers:
        c.print("  [dim]No providers configured[/]")
        return

    # Quick toggle mode: /providers toggle <name>
    parts = arg.strip().split()
    if len(parts) >= 2 and parts[0].lower() == "toggle":
        router.toggle_provider(parts[1])
        return

    try:
        _interactive_provider_manager(router, providers, c)
    except Exception:
        pass


def _interactive_provider_manager(router, providers: list[dict], console: object) -> None:
    """Full-screen interactive provider manager with arrow keys."""
    from prompt_toolkit import PromptSession as _Session
    from prompt_toolkit.formatted_text import HTML as _HTML
    from prompt_toolkit.key_binding import KeyBindings as _Bindings

    _enabled = {p["name"]: p["enabled"] for p in providers}
    _names = [p["name"] for p in providers]
    _idx = [0]

    _kb = _Bindings()

    @_kb.add("up")
    def _up(ev):
        _idx[0] = (_idx[0] - 1) % len(_names)

    @_kb.add("down")
    def _down(ev):
        _idx[0] = (_idx[0] + 1) % len(_names)

    @_kb.add("space")
    def _space(ev):
        _name = _names[_idx[0]]
        router.toggle_provider(_name)
        _enabled[_name] = _enabled[_name] if False else True

    @_kb.add("enter")
    def _enter(ev):
        ev.app.exit()

    @_kb.add("c-c")
    def _cancel(ev):
        ev.app.exit()

    @_kb.add("escape")
    def _esc(ev):
        ev.app.exit()

    _session: _Session = _Session(key_bindings=_kb)

    def _render():
        _lines = ["<ansiyellow> PROVIDER MANAGER</ansiyellow>\n\n"]
        for _i, _n in enumerate(_names):
            _on = _enabled.get(_n, True)
            _marker = "<ansibrightgreen>\u25b8</ansibrightgreen>" if _i == _idx[0] else " "
            _st = "<ansigreen>\u2713 enabled</ansigreen>" if _on else "<ansired>\u2717 disabled</ansired>"
            _arrow = "<ansired>\u2190</ansired>" if providers[_i].get("last_used") else ""
            _lines.append(f"  {_marker} <ansicyan>{_n:22}</ansicyan> {_st} {_arrow}\n")
        _lines.append(
            "\n<ansibrightblack>  \u2191\u2193 navigate</ansibrightblack>"
            "  \u00b7  <ansibrightblack>Space toggle</ansibrightblack>"
            "  \u00b7  <ansibrightblack>Enter done</ansibrightblack>"
        )
        return _HTML("".join(_lines))

    _session.prompt(_render)

    if hasattr(console, "print"):
        from widdx import ui
        c2 = ui.get_console()
        c2.print()
        active = sum(1 for p in router.list_providers() if p["enabled"])
        total = len(router.list_providers())
        c2.print(f"  [brand]◆[/] [text]{active}/{total}[/] providers active  [dim]·  use /provider <name> to switch[/]")
        if active == 1:
            c2.print(f"  [warning]⚠ Only one provider active — if it fails, no fallback available[/]")


def _set_active_provider(self, arg: str) -> None:
    """Interactive provider selector — choose one provider to use exclusively."""
    from widdx import ui
    c = ui.get_console()
    router = getattr(self, "_router", None)
    if router is None:
        c.print("  [dim]Router not available[/]")
        return

    providers = router.list_providers()
    if not providers:
        c.print("  [dim]No providers configured[/]")
        return

    from widdx.ui.professional import confirm_with_options

    names = [p["name"] for p in providers]
    c.print()
    choice = confirm_with_options("Choose active provider", names + ["All providers"], default="All providers")

    if choice == "All providers":
        router.enable_all()
        c.print("  [success]✓ All providers enabled[/]")
    else:
        router.enable_only(choice)
        c.print(f"  [success]✓ Active: [text]{choice}[/][/]")


def _set_api_key(self, arg: str) -> None:
    """Set DeepSeek API key — saves to ~/.widdx/config.yaml.

    Security: key input is hidden (password mode), never stored in REPL history,
    config file is set to 600 permissions.
    """
    from widdx import ui
    from widdx.config import save_config_key, load_config
    c = ui.get_console()

    current_config = load_config()
    current_key = current_config.get("deepseek_api_key") or current_config.get("__env__", {}).get("deepseek_key")

    if current_key:
        masked = current_key[:8] + "..." + current_key[-4:] if len(current_key) > 12 else "***"
        c.print(f"  [dim]Current key:[/] [text]{masked}[/]")

    key = arg.strip()
    if not key:
        c.print("  [dim]Usage: /key  (then paste your key when prompted)[/]")
        c.print("  [dim]Or: /key sk-...  (not recommended — stays in terminal scrollback)[/]")
        c.print("  [dim]Or set env: $env:DEEPSEEK_API_KEY = 'sk-...' (session only)[/]")

        # Hidden prompt — key not echoed to terminal
        try:
            from prompt_toolkit import prompt as pt_prompt
            from prompt_toolkit.formatted_text import HTML
            key = pt_prompt(HTML(
                '<ansiyellow>  Paste DeepSeek API key: </ansiyellow>'
            ), is_password=True)
        except Exception:
            try:
                key = input("  Paste DeepSeek API key: ").strip()
            except (KeyboardInterrupt, EOFError):
                return
        if not key:
            return
    else:
        # Key was passed as argument — strip from history immediately
        key = key.strip().strip("'\"")

    if not key.startswith("sk-"):
        c.print("  [warning]⚠ Key should start with 'sk-'. Use anyway?[/]", end=" ")
        try:
            confirm = input().strip().lower()
        except (KeyboardInterrupt, EOFError):
            return
        if not confirm.startswith("y"):
            return

    save_config_key("deepseek_api_key", key)
    self._config["deepseek_api_key"] = key
    self._config["__env__"]["deepseek_key"] = key

    # Secure the config file
    try:
        import os
        import stat
        config_path = os.path.expanduser("~/.widdx/config.yaml")
        os.chmod(config_path, stat.S_IRUSR | stat.S_IWUSR)  # 600
    except Exception:
        pass

    # Strip /key command from REPL history to prevent key leakage
    _strip_key_from_history()

    masked = key[:8] + "..." + key[-4:]
    c.print(f"  [success]✓ API key saved ({masked}). DeepSeek is now available.[/]")


def _strip_key_from_history() -> None:
    """Remove /key commands from the REPL history file."""
    try:
        history_path = os.path.expanduser("~/.widdx/history")
        if not os.path.exists(history_path):
            return
        with open(history_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        # Remove lines containing /key (case-insensitive)
        filtered = [l for l in lines if "/key" not in l.lower()]
        if len(filtered) < len(lines):
            with open(history_path, "w", encoding="utf-8") as f:
                f.writelines(filtered)
    except Exception:
        pass
