---
name: code-review
description: Systematic code review checklist
auto_invoke: false
---

When reviewing code, check:
1. Correctness — does it do what it claims?
2. Edge cases — null, empty, overflow, concurrent access
3. Security — injection, auth, secrets in code
4. Performance — N+1 queries, unnecessary loops
5. Readability — clear names, no magic numbers
6. Tests — are there tests? do they cover the important paths?
