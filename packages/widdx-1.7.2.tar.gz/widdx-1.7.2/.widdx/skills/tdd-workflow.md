---
name: tdd-workflow
description: تطبيق TDD — اكتب الاختبار أولاً ثم الكود
auto_invoke: true
---

عند تنفيذ أي مهمة برمجية:
1. اكتب الاختبار أولاً (test_*.py)
2. تأكد أنه يفشل (red)
3. اكتب أقل كود ممكن لإنجاحه (green)
4. أعد الهيكلة (refactor)
