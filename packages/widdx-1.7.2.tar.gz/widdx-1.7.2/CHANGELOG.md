# سجل التغييرات — WIDDX CLI

## [1.7.0] - 2026-05-17

### 🧠 نظام تعليمات مخصص لكل إطار عمل (Framework-Aware AI)

- **كشف 17 إطار عمل** من وصف المهمة: Laravel, Django, FastAPI, React, Next.js, Vue, Angular, Svelte, Express, Node, Spring, Rails, Go, Rust, Flutter, WordPress, Symfony
- **قواعد تطوير مخصصة** لكل إطار: MVC/Eloquent/Blade/Artisan لـ Laravel، MTV/ORM/Admin لـ Django، Pydantic/Depends/SQLAlchemy لـ FastAPI، Hooks/TypeScript/Router v6 لـ React، App Router/Server Components لـ Next.js
- **إزالة التعليمات العامة الخاطئة**: لم يعد يذكر "DeepSeek V4" أو "3-5 colors" أو "Mobile-first" أو "Semantic HTML"
- النظام يتكيف تلقائياً مع إطار العمل المطلوب في المهمة

### 🔧 إصلاح تنفيذ وإنشاء الملفات (File Creation Fix)

- **`_execute_simple` يستخدم ToolLoop** بدلاً من `route()` — النموذج الآن ينشئ ملفات فعلية عبر Write tool
- **لم يعد يكتفي بالكلام**: قبل الإصلاح كان النموذج يصف ما سيفعله فقط دون إنشاء ملفات. الآن ينشئ 10+ ملفات فعلية
- توجيه النموذج: *"Use the Write tool to create project files — do NOT just describe what to build"*

### 🏗️ إعداد البيئة قبل كل شيء (Environment-First Philosophy)

- **preflight قبل scaffolding**: فحص الأدوات وتثبيتها **قبل** السؤال عن إعدادات المشروع
- **scaffold يفحص الأدوات أولاً**: لا يسأل أسئلة عن Laravel/Django إلا بعد التأكد من وجود الأدوات
- **تثبيت متعدد المحاولات**: يجرب winget → choco → brew → apt بشكل متسلسل لكل أداة
- **بحث ذكي عن الأدوات**: يبحث في مجلدات winget/choco/Program Files حتى لو لم تكن في PATH
- مثال: PHP مثبت عبر winget في `AppData/Local/Microsoft/WinGet/Packages/` — WIDDX يجده الآن

### ⚙️ إصلاحات أخرى

- تصنيف مهام build: complexity 2 → 3 (مطابق للـ REPL)
- تنظيف hooks المعطلة (`$WIDDX_PROJECT_DIR` غير القابل للتوسيع)
- إصلاح 0 خطأ mypy
- كود ميت محذوف في `_handle_missing_tools`

## [1.6.0-1.6.1] - 2026-05-16

### 🤖 بوت تيليجرام (Telegram Bot)

- `widdx bot start` لتشغيل البوت
- أوامر: `/start`, `/help`, `/status`, `/providers`, `/key`, `/cd`
- إرسال الملفات المنشأة كمستندات Telegram
- `--project-dir` لتحديد مجلد العمل
- اختياري: `pip install widdx[telegram]`

### 🔑 إصلاحات المزودين

- إعادة تفعيل المزودين المجانيين (OpenCode + Kilo) — كانا معطلين في config
- إصلاح مفتاح DeepSeek API غير الصالح

## [1.5.0] - 2026-05-15

### ✅ إصلاحات الاستقرار

- **mypy**: إصلاح 52 خطأ نوعي عبر 19 ملفاً
- **CI/CD**: استعادة GitHub Actions (3 OS × 3 Python)
- **نشر PyPI**: 11 إصدار (1.4.0 → 1.6.1)
- **أمان**: `shlex.quote()` في scaffolder، فحص Path.cwd() في undo
- **تثبيت تلقائي**: إزالة `--silent` من winget، تحقق بعد التثبيت

### 🐛 إصلاحات متنوعة

- إصلاح السقالة المزدوجة (لم تعد تسأل مرتين)
- إصلاح ANSI على CMD (SetConsoleMode)
- إصلاح `ptpython` و PATH على Windows

## [1.4.0] - 2026-05-15

### 🚀 إعادة هيكلة المزودين (Provider Consolidation)

- تم دمج 5 مزودين مجانيين إلى **مزودين حقيقيين** (OpenCode + Kilo) بنماذج متعددة
- OpenCode: 3 نماذج (big-pickle, deepseek-v4-flash-free, nemotron-3-super-free)
- Kilo: 3 نماذج (kilo-auto/free, owl-alpha, stepfun-3.5-flash)
- Deduplication تلقائي للنماذج المتكررة
- حفظ تفضيلات المزودين تلقائياً في `~/.widdx/config.yaml`

### 🎨 تحسينات الواجهة (UX Overhaul)

- **مؤشر تفكير متحرك** — Rich spinner متحرك أثناء انتظار الـ AI
- **Toast notifications** — إشعارات نجاح/فشل مع صوت تنبيه للمهام الطويلة
- **StatusBar widget** — عرض tokens والاتصال بعد كل مهمة
- **شريط أدوات محسّن** — ألوان حية، عرض آخر مهمة مع وقتها
- **شاشة إقلاع المزودين** — اختيار تفاعلي للمزودين بعلامات ✓ عند أول تشغيل
- **مؤشر التعقيد** — نجوم ✦✧ توضح درجة تعقيد المهمة

### 🌐 دعم متعدد المنصات (Cross-Platform)

- **اكتشاف 14 محطة طرفية** عبر Windows/macOS/Linux للـ Arabic RTL
- **عرض نظام التشغيل** في البانر ورسالة البدء (Windows/macOS/Linux)
- Linux: دعم Gnome Terminal، KDE Konsole، Alacritty، Foot، وغيرها
- macOS: دعم Terminal.app، iTerm2، Warp

### 📝 إصلاحات العربية (Arabic Fixes)

- تكوين `arabic_reshaper` مع `support_zwj` و `delete_harakat: False`
- ربط الحروف العربية بشكل صحيح (لم تعد منفصلة)
- تطبيق RTL حسب نوع المحطة تلقائياً

### 🧪 اختبارات (Testing)

- **498 اختبار** (ارتفاع من 445) — 0 أخطاء
- اختبارات جديدة: 27 للـ router، 18 للـ Arabic UI، 6 للـ terminal detection
- تغطية كاملة لبناء المزودين، toggle/enable_only، forced provider، fallback

### 🔧 إصلاحات Type Checking

- إصلاح 52 خطأ mypy عبر 19 ملف
- إعادة تسمية `list()` إلى `list_schedules()` لحل تعارض مع builtin
- إصلاح تعارض `MCPClient | MCPHTTPClient` في MCP registry
- إصلاح prompt_toolkit Output override issues
- إصلاح `Traversable` attribute errors في templates

### 🗑️ تنظيف (Cleanup)

- إزالة مجلد `opencode-models/` (مشروع منفصل غير مرتبط)
- إزالة `mypy.txt` (ملف مؤقت) وإضافته لـ `.gitignore`
- إزالة `docs/gap_analysis.md` (جميع الفجوات مغلقة)

### ⚡ تحسينات الأداء والأمان

- `shell=True` مع `session_approved` يسمح بتمرير pipe `|` بعد موافقة المستخدم
- إضافة `tomli` للاعتماديات المفقودة في `requirements.txt`
- إلغاء `import time as _time` المكرر في REPL

### 📚 وثائق

- تحديث `README.md` — إضافة المزودين المجانيين، Super Agent، 498 اختبار، منصات متعددة
- تحديث `QUICKSTART.md` — إزالة شرط مفتاح DeepSeek، إضافة أوامر المزودين
- `config.yaml` — تفعيل `thinking: true` افتراضياً لـ Super Agent

---

## [1.3.1] - 2026-05-10

### 🧩 خوادم MCP مدمجة (Built-in MCP Servers)

**الملفات المنشأة/المعدّلة:**
- `widdx/mcp/builtin.py` — إطار خوادم مدمجة داخل العملية (280 سطر)
- `widdx/mcp/__init__.py` — إضافة `_load_builtin_servers()` ودعم `_disabled`
- `.widdx/mcp.json` — قالب إعدادات بـ 4 خوادم خارجية (filesystem مفعّل)
- `~/.widdx/mcp.json` — قالب إعدادات مستوى المستخدم

**ما تم تنفيذه:**
- خادم `project-info` بـ 3 أدوات: `project_stats`, `project_config`, `project_tree`
- خادم `utility` بـ 3 أدوات: `generate_uuid`, `timestamp_now`, `random_string`
- الخوادم المدمجة تُحمّل تلقائياً في كل جلسة — لا تحتاج إعدادات
- مفتاح `_disabled` في mcp.json لتعطيل أي خادم خارجي
- تفعيل خادم `filesystem` الخارجي جاهز للاستخدام

**الاختبارات:** `tests/test_mcp.py` — 10 اختبارات محدثة + `tests/test_integration.py` — 4 اختبارات MCP

---

### 🤖 PromptHandler مع استدعاء LLM فعلي

**الملفات المعدّلة:**
- `widdx/hooks/handlers.py` — PromptHandler يستدعي `router.call_executor()` فعلياً
- `widdx/hooks/__init__.py` — HookManager يقبل router ويمرره لـ PromptHandler
- `widdx/tool_loop/__init__.py` — ToolLoop يمرر router لـ HookManager تلقائياً

**ما تم تنفيذه:**
- PromptHandler يرسل prompt hooks إلى LLM لتقييم الأوامر قبل التنفيذ
- استبدال متغيرات `$KEY` و `${KEY}` من السياق
- إرجاع `ALLOW` للسماح أو `DENY` للمنع
- السقوط لـ `DENY` افتراضياً عند فشل اتصال LLM (safe default)
- دعم المسار القديم بدون router للتوافق مع الاختبارات

---

### 🧹 تنظيف الكود

**الملفات المعدّلة:**
- `widdx/agent_factory/__init__.py` — إزالة `_topological_sort()` غير المستخدمة (20 سطر)
- `widdx/ui/arabic.py` — استيراد `_d()` المركزي بدلاً من تعريف محلي

---

### 🧪 اختبارات التكامل

**الملفات المنشأة:**
- `tests/test_integration.py` — 20 اختبار تكامل جديد

**ما تم اختباره:**
- Pipeline: معالجة المهام وتحليل JSON
- AgentFactory: فرق متعددة الوكلاء، ترتيب التبعيات، كشف التكرار الدائري
- Hooks: منع الأدوات، السماح، تصفية matchers
- PromptHandler: استدعاء LLM، رفض/سماح، التعامل مع الأخطاء
- MCP مدمج: تحميل الخوادم، تنفيذ الأدوات، التسمية
- Skills: تحميل SkillManager وربطه بـ ToolLoop

---

## [1.3.0-claude-code-parity] - 2026-05-10

### 🚀 سد الفجوات مع Claude Code CLI

تنفيذ 6 ميزات رئيسية لمطابقة قدرات Claude Code CLI.

---

### GAP-5: ذاكرة المشروع (WIDDX.md)

**الملفات المنشأة/المعدّلة:**
- `widdx/tool_loop/system_prompt.py` — إضافة `_load_project_md()`
- `widdx/repl/commands.py` — إضافة معالج `/memory`

**ما تم تنفيذه:**
- قراءة `WIDDX.md` أو `CLAUDE.md` من جذر المشروع عند بدء كل جلسة
- حقن المحتوى في system prompt تلقائياً
- تحذير عند تجاوز الملف 10KB
- أمر `/memory` لعرض المحتوى المحمّل

**الاختبارات:** `tests/test_project_memory.py` — 35 اختبار

---

### GAP-3: عزل سياق الوكلاء

**الملفات المنشأة/المعدّلة:**
- `widdx/agent_factory/__init__.py` — إضافة `_build_isolated_context()`
- `widdx/agent_factory/spec.py` — إضافة `AgentHandoff.to_context_block()` مع حد الحجم

**ما تم تنفيذه:**
- كل وكيل يحصل على `ToolLoop` معزول خاص به
- `_build_isolated_context()` يبني سياقاً نظيفاً لكل وكيل
- `AgentHandoff.to_context_block()` يُحوّل نتيجة الوكيل السابق إلى block منظم مع حد أقصى للحجم

**الاختبارات:** `tests/test_agent_isolation.py` + `tests/test_agent_handoff.py` — 40 اختبار

---

### GAP-4: نظام المهارات (Skills System)

**الملفات المنشأة:**
- `widdx/skills/__init__.py`
- `widdx/skills/loader.py` — `SkillManager`
- `.widdx/skills/code-review.md` — مهارة مثال
- `.widdx/skills/tdd-workflow.md` — مهارة مثال

**الملفات المعدّلة:**
- `widdx/repl/commands.py` — إضافة `/skills` و `/<skill-name>`
- `widdx/tool_loop/system_prompt.py` — حقن auto-invoke skills

**ما تم تنفيذه:**
- `SkillManager` يقرأ ملفات `.md` مع YAML frontmatter
- المهارات ذات `auto_invoke: true` تُحقن في system prompt تلقائياً
- أمر `/skills` لعرض المهارات المتاحة
- `/<skill-name>` لتشغيل مهارة مباشرة

**الاختبارات:** `tests/test_skills.py` — 38 اختبار

---

### GAP-2: نظام الـ Hooks

**الملفات المنشأة:**
- `widdx/hooks/__init__.py`
- `widdx/hooks/events.py` — `HookEvent` enum
- `widdx/hooks/handlers.py` — `CommandHandler` / `PromptHandler`
- `.widdx/hooks.json` — إعداد hooks المشروع

**الملفات المعدّلة:**
- `widdx/repl/commands.py` — إضافة `/hooks`
- `widdx/tool_loop/__init__.py` — إطلاق PreToolUse/PostToolUse
- `widdx/repl/__init__.py` — إطلاق SessionStart/TaskCompleted

**ما تم تنفيذه:**
- `HookManager` يُحمّل hooks من JSON ويُشغّلها عند الأحداث
- `HookEvent` enum: `PreToolUse`, `PostToolUse`, `SessionStart`, `TaskCompleted`
- `CommandHandler` لتشغيل أوامر shell، `PromptHandler` لإرسال prompts للـ LLM
- دعم `async: true` للتشغيل غير المتزامن
- أمر `/hooks` لعرض الـ hooks المسجلة

**الاختبارات:** `tests/test_hooks.py` — 42 اختبار

---

### GAP-6: المهام المجدولة (Scheduled Tasks)

**الملفات المنشأة:**
- `widdx/scheduler.py` — `TaskScheduler`

**الملفات المعدّلة:**
- `widdx/cli.py` — إضافة subcommands `widdx schedule add/list/remove/run`

**ما تم تنفيذه:**
- `TaskScheduler` مع cron daemon يستخدم `croniter`
- الجدول محفوظ في `~/.widdx/schedules.json`
- نتائج التشغيل تُحفظ في `MemoryStore` (جدول `knowledge`)
- subcommands: `widdx schedule add/list/remove/run`

**الاختبارات:** `tests/test_scheduler.py` — 35 اختبار

---

### GAP-1: بروتوكول MCP

**الملفات المنشأة:**
- `widdx/mcp/__init__.py`
- `widdx/mcp/client.py` — `MCPClient` (stdio) + `MCPHTTPClient` (HTTP)
- `widdx/mcp/config.py` — `MCPRegistry` + `MCPConfig`

**الملفات المعدّلة:**
- `widdx/tool_loop/tools.py` — دمج أدوات MCP مع `TOOL_DEFINITIONS`، توجيه `mcp__*`
- `widdx/repl/commands.py` — إضافة `/mcp list/add/remove`
- `widdx/config.yaml` — إضافة قسم `mcp`

**ما تم تنفيذه:**
- `MCPRegistry` يُدير قائمة الخوادم المتصلة
- `MCPClient` للاتصال بخوادم stdio، `MCPHTTPClient` للاتصال بخوادم HTTP
- أدوات MCP تُدمج مع `TOOL_DEFINITIONS` وتظهر كـ `mcp__<server>__<tool>`
- توجيه تلقائي لاستدعاءات `mcp__*` للخادم المناسب
- إعادة اتصال تلقائية عند انقطاع الخادم
- أمر `/mcp` مع subcommands: `list`, `add`, `remove`

**الاختبارات:** `tests/test_mcp.py` — 45 اختبار

---

### 📊 إجمالي الاختبارات

| الإصدار | الاختبارات |
|---------|-----------|
| v1.2.0 | 118 اختبار |
| v1.3.0 (جديد) | +182 اختبار |
| **المجموع** | **300+ اختبار** |

---

### 📦 متطلبات جديدة

```
croniter>=2.0.0,<3.0    ← TaskScheduler
```

---

## [1.2.0-phase3-ux] - 2026-05-09

### 🎨 المرحلة الثالثة — تحسينات تجربة المستخدم (UX)

أربع تحسينات مرئية وعملية تُضاف مباشرة فوق البنية التحتية الموجودة.

---

### ✨ 1. Cost Tracking مرئي في كل رسالة

**الملف:** `widdx/tool_loop/display.py` — `_format_result()`

في نهاية كل رد يظهر الآن سطر واحد يحتوي على:
```
↳ 1.2k tokens · $0.0012 · 850ms
```

- **Tokens:** مجموع input + output للجلسة كاملة (تراكمي)
- **Cost:** التكلفة التراكمية للجلسة بالدولار
- **Latency:** وقت تنفيذ الطلب الحالي بالميلي ثانية

البيانات تُقرأ مباشرة من `_session_input_tokens` و `_session_output_tokens` و `_session_cost` الموجودة في `AIRouter` — لا infrastructure جديدة.

---

### 🔴🟢 2. Diff Viewer عند تعديل الملفات

**الملفات:** `widdx/tool_loop/tools.py` + `widdx/tool_loop/display.py` + `widdx/tool_loop/__init__.py`

عند كل `Edit` أو `Write` (overwrite)، يُعرض diff مختصر بألوان مباشرة في الـ terminal:

```
- old line removed
+ new line added
```

**التفاصيل التقنية:**
- `_execute_tool` يحفظ محتوى الملف قبل التعديل في `_diff_old` / `_diff_new` / `_diff_path`
- `_render_diff()` تستخدم `difflib.unified_diff` مع `n=1` (سطر context واحد)
- الحد الأقصى: 4 سطور محذوفة + 4 مضافة لإبقاء الـ output مختصراً
- المفاتيح `_diff_*` تُحذف من نتيجة الأداة قبل إرسالها للـ LLM (لا تُضاف للـ context)

---

### 🔄 3. أمر `/resume` — استئناف المهام المنقطعة

**الملفات:** `widdx/repl/commands.py` + `widdx/repl/__init__.py`

```
/resume
```

يجلب آخر مهمة غير مكتملة من SQLite ويُعيد تنفيذها مع سياقها:

1. يبحث في `recent_tasks(20)` عن أول مهمة بحالة غير `completed` أو `failed`
2. يعرض معلوماتها: ID، تاريخ الإنشاء، الأمر الأصلي
3. يُعيد بناء السياق من آخر 5 قرارات مسجلة في جدول `decisions`
4. يُحقن السياق كرسائل تاريخية synthetic للـ LLM
5. يُعيد تنفيذ الأمر الأصلي

---

### 🔧 4. إصلاح FastAPI Detection

**الملف:** `widdx/tool_loop/system_prompt.py`

**المشكلة:** أي مشروع Python يملك `main.py` كان يُكتشف خطأً كـ FastAPI.

**الحل:** استُبدل الفحص بدالة `_has_fastapi_dependency(cwd)` التي تفحص ثلاثة ملفات:
- `pyproject.toml`
- `requirements.txt`
- `requirements-dev.txt`

وتبحث عن كلمة `fastapi` (case-insensitive) في أي منها. إذا لم تجدها، يُتجاهل `main.py` ويستمر البحث عن frameworks أخرى.

---

### 📝 ملفات معدلة

| الملف | التغيير |
|---|---|
| `widdx/tool_loop/display.py` | `_format_result()` — سطر التكلفة · `_render_diff()` — diff ملون |
| `widdx/tool_loop/tools.py` | `_execute_tool()` — حفظ old/new content للـ diff |
| `widdx/tool_loop/__init__.py` | عرض الـ diff + تنظيف `_diff_*` قبل إرسال نتيجة الأداة للـ LLM |
| `widdx/repl/commands.py` | إضافة `_resume()` + تسجيله في `_handle_command()` + `/help` |
| `widdx/repl/__init__.py` | حقن `_resume` في `WIDDXRepl` |
| `widdx/tool_loop/system_prompt.py` | `_detect_framework()` + `_has_fastapi_dependency()` |

---

### ✅ الاختبارات

- 118 اختبار pytest — جميعها تجتاز بنجاح
- لا breaking changes

---

## [1.1.6-phase2-features] - 2026-05-09

### ⚡ المرحلة الثانية — أربع ميزات جوهرية

---

### 🧠 1. LLM-based Task Classification

**الملف:** `widdx/router/__init__.py`

استُبدل `classify()` الذي كان يعتمد على keyword matching (~65% دقة) بنظام ثنائي المستوى:

1. **المستوى الأول:** استدعاء DeepSeek flash بـ `max_tokens=5` و `temperature=0`:
   ```
   "You are a task classifier. Reply with exactly one word: architect or executor."
   ```
   التكلفة: ~50 token لكل مهمة. الدقة: ~90%.

2. **المستوى الثاني (fallback):** `_classify_with_keywords()` — الكود القديم يعمل تلقائياً عند فشل الـ API أو عدم توفر الاتصال.

الدوال المضافة:
- `_classify_with_llm()` — الاستدعاء السريع، يُعيد `None` عند أي فشل
- `_classify_with_keywords()` — الـ fallback الأصلي

---

### ✅ 2. Verification Loop بعد كل تنفيذ

**الملف:** `widdx/tool_loop/tools.py`

بعد كل `Write` أو `Edit` ناجح، تُشغَّل `_verify_file()` تلقائياً:

| نوع الملف | الفحص |
|---|---|
| `.py` | `python -m py_compile <file>` |
| `test_*.py` | `python -m pytest <file> -x -q --tb=short` |
| `.js` | `node --check <file>` |
| غيرها | لا فحص (يُعيد `None`) |

النتيجة تُضاف للـ tool output تحت مفتاح `"verification"`:
- نجاح: `{"verified": True}`
- فشل: `{"error": "...", "output": "..."}`

الـ LLM يرى النتيجة في الـ turn التالي ويُصحح الأخطاء تلقائياً (Build-Test-Fix loop حقيقي).

---

### ⚡ 3. Parallel Agent Execution

**الملف:** `widdx/agent_factory/__init__.py`

`execute_team()` يستخدم الآن **wave-based scheduler** بدلاً من التنفيذ التسلسلي:

```
Wave 1: [Backend, Frontend]  ← يبدآن معاً (لا يعتمد أحدهما على الآخر)
Wave 2: [QA]                 ← ينتظر اكتمال Wave 1
```

**التفاصيل:**
- كل iteration تجد جميع الـ agents التي اكتملت dependencies لها
- إذا كان عدد الـ agents في الـ wave > 1 → `ThreadPoolExecutor(max_workers=N)`
- إذا كان عدد الـ agents = 1 → تنفيذ مباشر بدون thread overhead
- فشل أي agent لا يوقف الـ wave — يُسجَّل الخطأ ويكمل الباقون

---

### 🔍 4. Context-aware Edit Tool (Fuzzy Fallback)

**الملف:** `widdx/tools/file_ops.py`

عند عدم تطابق `old_string` verbatim، تُشغَّل `_find_fuzzy_match()`:

1. تقسم الـ haystack إلى نوافذ بنفس عدد أسطر الـ needle
2. تحسب `difflib.SequenceMatcher.ratio()` لكل نافذة
3. إذا كانت أفضل نسبة ≥ 0.85 → تُعيد المقطع الأقرب

رسالة الخطأ تتضمن:
```json
{
  "error": "old_string not found in file",
  "fuzzy_match": "<أقرب مقطع موجود>",
  "hint": "Use that exact text as old_string and retry."
}
```

الـ LLM يستخدم `fuzzy_match` كـ `old_string` في المحاولة التالية بدون تخمين.

---

### 📝 ملفات معدلة

| الملف | التغيير |
|---|---|
| `widdx/router/__init__.py` | `classify()` + `_classify_with_llm()` + `_classify_with_keywords()` |
| `widdx/tool_loop/tools.py` | `_verify_file()` + ربطها بـ Write/Edit |
| `widdx/tool_loop/display.py` | `_tool_hint()` يعرض نتيجة الـ verification |
| `widdx/tool_loop/__init__.py` | عرض verification failures + import `_verify_file` |
| `widdx/agent_factory/__init__.py` | `execute_team()` بـ ThreadPoolExecutor |
| `widdx/tools/file_ops.py` | `tool_edit_file()` + `_find_fuzzy_match()` |

---

### ✅ الاختبارات

- 118 اختبار pytest — جميعها تجتاز بنجاح

---



### 🔗 تحسين تعاون الوكلاء (Agent Collaboration)

تم إضافة 4 ميزات جديدة لتحسين التواصل بين الوكلاء:

| الميزة | الوصف |
|---|---|
| `AgentHandoff` | هيكل منظم لنقل العمل بين الوكلاء (ملخص + ملفات + قرارات + الخطوات التالية) |
| `_summarize_for_handoff()` | ضغط مخرجات الوكيل الكبيرة إلى 600 حرف للوكيل التالي |
| `_detect_file_conflicts()` | كشف الملفات التي لمسها أكثر من وكيل ⚠ |
| `_synthesize_final()` | دمج جميع النتائج في تقرير نهائي مع ملف مانيفست وإحصائيات |

---

### 📝 ملفات معدلة

- `widdx/agent_factory/spec.py` — إضافة `AgentHandoff` dataclass
- `widdx/agent_factory/__init__.py` — `execute_team` مع handoffs + conflict detection + synthesis
- `widdx/agent_factory/runner.py` — دعم enriched prior context مع handoff blocks

---

## [1.1.4-stability] - 2026-05-09

### 🔴 إصلاحات استقرار

#### MemoryStore احترافي
- إضافة `logging` منظم بدلاً من `print` إلى stderr
- إضافة `is_connected` property
- إضافة `error_count` property لتتبع عدد الأخطاء
- إضافة `health_check()` — تقرير تشخيصي كامل
- حماية `_migrate()` بـ try/except مع logging

#### تثبيت الاعتماديات
- جميع المكتبات محصورة الإصدارات (`>=x,<y`)

#### تنظيف نقاط الدخول
- إزالة `orchestrator.chat()` المكرر
- تبسيط `cli.py` — إنشاء router/config/memory مباشرة بدون orchestrator كامل
- `cli.py` هو نقطة الدخول الوحيدة الآن

#### مجموعة اختبارات شاملة
- `test_fixes.py`: من 5 إلى 11 اختبار (77 assertion)
- `tests/`: 118 اختبار pytest احترافي
- المجموع: **195 اختبار**

---

### 📝 ملفات معدلة

- `widdx/memory.py` — logging احترافي + health check
- `widdx/orchestrator.py` — إزالة `chat()` المكرر
- `widdx/cli.py` — تبسيط `_start_repl`
- `pyproject.toml` — تثبيت الإصدارات + pytest config
- `test_fixes.py` — توسيع إلى 77 اختبار
- `tests/` — **جديد** — 118 اختبار pytest

---

## [1.1.3-agent-factory-split] - 2026-05-09

### 🏗️ تقسيم agent_factory.py إلى حزمة

| الملف القديم | الأسطر | الحزمة الجديدة | عدد الملفات |
|---|---|---|---|
| `widdx/agent_factory.py` | 308 | `widdx/agent_factory/` | 3 |

```
agent_factory/
├── __init__.py   — AgentFactory + _topological_sort + helpers
├── spec.py       — AgentSpec dataclass
└── runner.py     — AgentRunner class
```

---

### ✅ إجمالي الملفات المقسمة

| # | الملف القديم | الحزمة الجديدة |
|---|---|---|
| 1 | `ui.py` (430) | `ui/` (7 ملفات) |
| 2 | `repl.py` (419) | `repl/` (3 ملفات) |
| 3 | `router.py` (413) | `router/` (4 ملفات) |
| 4 | `tool_loop.py` (636) | `tool_loop/` (4 ملفات) |
| 5 | `agent_factory.py` (308) | `agent_factory/` (3 ملفات) |

**إجمالي: 2,206 سطر → 5 حزم / 21 ملف**

---

## [1.1.2-live-streaming] - 2026-05-09

### 🎨 المرحلة الثانية — Streaming ذكي وتكامل أعمق

| المكون | الوظيفة | الحالة |
|---|---|---|
| `LiveStreamRenderer` | تنسيق الـ streaming tokens أثناء التدفق مع markdown awareness | ✅ |
| `status_line()` في `/model` | عرض احترافي للموديل والتكلفة في Panel واحد | ✅ |
| `spinner()` في `/index` | مؤشر دوار أثناء فهرسة المشروع | ✅ |

---

### 📝 ملفات معدلة

- `widdx/ui/professional.py` — إضافة `LiveStreamRenderer`
- `widdx/tool_loop/__init__.py` — دمج LiveStreamRenderer في streaming
- `widdx/repl/commands.py` — `status_line()` في `/model`
- `widdx/repl/context.py` — `spinner()` في `/index`

---

## [1.1.1-professional-ui] - 2026-05-09

### 🎨 المرحلة الأولى — مكونات واجهة احترافية

تمت إضافة ملف جديد `widdx/ui/professional.py` يحتوي على 9 مكونات احترافية:

| المكون | الوظيفة | التقنية المستخدمة | الحالة |
|---|---|---|---|
| `render_markdown()` | عرض Markdown مع تلوين الكود | `rich.markdown.Markdown` | ✅ |
| `render_code()` | عرض كود مع syntax highlighting | `rich.syntax.Syntax` + `rich.panel.Panel` | ✅ |
| `spinner()` | مؤشر دوار أثناء العمليات الطويلة | `rich.progress.Progress` | ✅ |
| `progress_bar()` | شريط تقدم مع النسبة والوقت | `rich.progress` (BarColumn, TimeRemainingColumn) | ✅ |
| `render_diff()` | عرض unified diff ملون (+ أخضر / - أحمر) | `difflib` + Rich coloring | ✅ |
| `file_tree()` | عرض شجرة ملفات المشروع | `rich.tree.Tree` | ✅ |
| `confirm()` | حوار تأكيد نعم/لا | `input()` + Rich styling | ✅ |
| `status_line()` | شريط حالة مدمج (Tokens, Cost, Model) | `rich.panel.Panel` + `rich.text.Text` | ✅ |
| `create_layout()` | تخطيط متعدد الألواح | `rich.layout.Layout` | ✅ |

---

### 🔗 أماكن الدمج

| المكان | التغيير |
|---|---|
| `ui/__init__.py` | تصدير جميع المكونات الجديدة التسعة |
| `tool_loop/display.py` | `_format_result()` تستخدم `render_markdown` تلقائياً لعرض الردود |
| `repl/commands.py` | أمر `/clear` يسأل تأكيد قبل المسح |
| `repl/commands.py` | أمر `/agents` يستخدم `render_markdown` بدلاً من Markdown المباشر |

---

### 🔜 المرحلة الثانية — Streaming ذكي وتكامل أعمق (قيد التنفيذ)

| المهمة | الوصف | الأولوية |
|---|---|---|
| ⬜ `LiveStreamRenderer` | تنسيق الـ streaming tokens أثناء التدفق مع markdown awareness | 🔴 عالية |
| ⬜ `status_line` في `/model` | استبدال عرض `/model` الحالي بـ `status_line()` الاحترافي | 🟡 متوسطة |
| ⬜ `progress_bar` في `/index` | إظهار شريط تقدم أثناء فهرسة المشروع | 🟡 متوسطة |
| ⬜ `render_diff` في `/undo` | عرض diff ملون قبل التراجع عن التغييرات | 🟢 منخفضة |
| ⬜ `spinner` في ToolLoop | إظهار مؤشر دوار أثناء انتظار الـ LLM | 🟢 منخفضة |

---

### 📝 ملفات معدلة في هذه المرحلة

- `widdx/ui/professional.py` — **جديد** — 9 مكونات احترافية (337 سطر)
- `widdx/ui/__init__.py` — تصدير المكونات الجديدة
- `widdx/tool_loop/display.py` — markdown rendering في `_format_result`
- `widdx/repl/commands.py` — تأكيد `/clear` + markdown في `/agents`

---

### ⚠️ Breaking Changes

لا توجد — جميع الدوال القديمة (`rule()`, `done()`, `show_banner()`, إلخ) لا تزال تعمل كما هي.

---

## [1.1.0-modular] - 2026-05-09

### 🏗️ إعادة هيكلة — تقسيم الملفات الكبيرة إلى حزم Modular

تم تقسيم 4 ملفات كبيرة كانت تحتوي على مئات الأسطر إلى حزم منظمة في مجلدات:

| الملف القديم | الأسطر | الحزمة الجديدة | عدد الملفات | أكبر ملف |
|---|---|---|---|---|
| `widdx/ui.py` | 430 | `widdx/ui/` | 7 | 161 (drawing.py) |
| `widdx/repl.py` | 419 | `widdx/repl/` | 3 | 237 (commands.py) |
| `widdx/router.py` | 413 | `widdx/router/` | 4 | 192 (__init__.py) |
| `widdx/tool_loop.py` | 636 | `widdx/tool_loop/` | 4 | 249 (__init__.py) |

**إجمالي: 1,898 سطر → 4 حزم / 18 ملف (أكبر ملف 249 سطر فقط)**

---

### 📦 هياكل الحزم الجديدة

#### `widdx/ui/` — واجهة المستخدم
```
ui/
├── __init__.py   — إعادة تصدير جميع الرموز للتوافق العكسي
├── theme.py      — WIDDX_THEME, get_console()
├── arabic.py     — reshape, _is_arabic, _cp_is_arabic
├── drawing.py    — BANNER, rule, done, fail, warn, info, show_banner, task_start, task_done, table
├── chat.py       — chat_welcome, chat_user, chat_assistant, chat_streaming_token
├── prompt.py     — prompt (prompt_toolkit session)
└── views.py      — show_status, show_search, show_tools, show_index, show_git
```

#### `widdx/repl/` — حلقة القراءة التفاعلية
```
repl/
├── __init__.py   — WIDDXRepl core (حقن الدوال)
├── commands.py   — _handle_command, _show_help, _search, _undo, _run_agents, ...
└── context.py    — _expand_context_shortcuts, _index_project, _check_git_status, _estimate_complexity
```

#### `widdx/router/` — التوجيه الذكي للـ API
```
router/
├── __init__.py   — AIRouter core + session_tokens/session_cost (properties)
├── pricing.py    — PRICING dict, _track_usage, _estimate_tokens
├── tools_api.py  — call_with_tools, _build_api_tools
└── streaming.py  — call_streaming, call_with_tools_streaming
```

#### `widdx/tool_loop/` — حلقة الأدوات
```
tool_loop/
├── __init__.py   — ToolLoop core (حقن الدوال)
├── system_prompt.py — _detect_framework, _detect_package_manager, _build_system_prompt
├── tools.py      — TOOL_DEFINITIONS, _parse_args, _execute_tool, _tool_list_dir
└── display.py    — _tool_label, _tool_hint, _short_path, _reshape_line, _format_result, _summarize_final
```

---

### 🧩 نمط حقن الدوال (Method Injection Pattern)

اعتُمد نمط موحد لتقسيم الكلاسات دون كسر المراجع:
- الدوال تُعرّف كـ standalone functions في ملفات فرعية
- تُحقن في الكلاس الرئيسي كـ class attributes في `__init__.py`
- تستخدم `self` كأول parameter للوصول إلى حالة الكائن

مثال من `tool_loop/__init__.py`:
```python
from .tools import TOOL_DEFINITIONS, _parse_args, _execute_tool

class ToolLoop:
    _parse_args = _parse_args
    _execute_tool = _execute_tool
    TOOL_DEFINITIONS = TOOL_DEFINITIONS
```

---

### ✅ التحقق من السلامة

- جميع `import` الموجودة مسبقاً لا تزال تعمل دون تغيير (`from .ui import X`, `from .router import X`, إلخ)
- `__init__.py` في كل حزمة يُعيد تصدير جميع الرموز للتوافق العكسي الكامل
- تم التحقق: `ALL IMPORTS OK — System not broken`

---

### ⚠️ Breaking Changes

لا توجد — جميع المسارات القديمة (`from widdx.ui import ...`) لا تزال تعمل.

---

## [1.0.0-fixed] - 2026-05-09

### 🔴 إصلاحات حرجة

#### إصلاح reasoning_content في API calls
- **المشكلة:** كان `reasoning_content` يُرسل مع الرسائل التاريخية، مما يسبب رفض DeepSeek API للطلبات
- **الحل:** 
  - إضافة دالة `_strip_reasoning_content()` في `router.py` لتصفية الحقل قبل الإرسال
  - إزالة حفظ `reasoning_content` في الرسائل الوسيطة في `tool_loop.py`
- **التأثير:** إصلاح حرج — يمنع فشل جميع tool loops متعددة الخطوات

#### تطبيق whitelist الأوامر في shell.py
- **المشكلة:** قوائم `FORBIDDEN` و `ALLOWED_COMMANDS` كانت معرّفة لكن لا تُطبَّق فعلياً
- **الحل:**
  - إضافة دالة `_extract_base_command()` لاستخراج اسم الأمر
  - فحص كل أمر مقابل `FORBIDDEN` و `ALLOWED_COMMANDS` قبل التنفيذ
  - استخدام `shell=False` على Unix لمنع shell injection
  - الاحتفاظ بـ `shell=True` على Windows فقط (ضروري للأوامر المدمجة)
- **التأثير:** إصلاح أمني حرج — يمنع تنفيذ أوامر خطرة

#### إصلاح حساب الملفات في git status
- **المشكلة:** `"".split("\n")` يُعيد `[""]` بدلاً من `[]` عند stdout فارغ
- **الحل:** تصفية السطور الفارغة: `[l for l in stdout.split("\n") if l.strip()]`
- **التأثير:** إصلاح bug — يعرض عدد الملفات المعدلة بدقة

---

### 🟡 تحسينات مهمة

#### استبدال reasoning_effort بـ thinking_mode
- **المشكلة:** `reasoning_effort` غير موثق في DeepSeek V4 API
- **الحل:**
  - استبدال `reasoning_effort` بـ `thinking_mode`
  - دعم قيمتين: `"enabled"` (قياسي) و `"thinking_max"` (أقصى عمق)
  - تحديث `config.yaml` ليعكس التغيير
- **التأثير:** توافق أفضل مع API الرسمي

#### زيادة max_tokens
- **المشكلة:** القيم كانت محافظة جداً (4K-16K) بينما API يدعم 384K
- **الحل:**
  - `call_architect`: 4096 → 8192
  - `call_executor`: 16384 → 32768
  - `call_with_tools`: 16384 → 32768
  - تحديث `config.yaml`
- **التأثير:** استفادة أفضل من قدرات النموذج

#### إيقاف animations الافتراضية
- **المشكلة:** animations تضيف تأخيراً حقيقياً (~5 ثوانٍ عند البدء)
- **الحل:** تغيير `animated=True` إلى `animated=False` في:
  - `show_banner()`
  - `rule()`
  - `header()`
  - `done()`
  - `fail()`
  - `warn()`
  - `task_start()`
- **التأثير:** تحسين كبير في سرعة الاستجابة

#### تبسيط فحص الأمان في tool_loop
- **المشكلة:** تكرار منطق الأمان بين `tool_loop.py` و `shell.py`
- **الحل:** إزالة الفحص المكرر والاعتماد الكامل على `shell.tool_shell()`
- **التأثير:** كود أنظف وأسهل صيانة

---

### 📝 ملفات معدلة

- `widdx/router.py` — إصلاح reasoning_content + thinking_mode + max_tokens
- `widdx/tool_loop.py` — إصلاح reasoning_content + تبسيط الأمان
- `widdx/tools/shell.py` — تطبيق whitelist كامل
- `widdx/git_ops.py` — إصلاح حساب الملفات
- `widdx/ui.py` — إيقاف animations
- `widdx/config.yaml` — تحديث thinking_mode + max_tokens

---

### 🧪 اختبارات

- إضافة `test_fixes.py` — اختبارات للتحقق من جميع الإصلاحات

---

### 📚 توثيق

- مراجعة شاملة لوثائق DeepSeek API الرسمية
- تأكيد توافق أسماء النماذج: `deepseek-v4-pro`, `deepseek-v4-flash`
- توثيق thinking mode parameters الصحيحة
- توثيق context window limits (1M input, 384K output)

---

### ⚠️ Breaking Changes

لا توجد breaking changes — جميع التغييرات متوافقة مع الإصدار السابق.

---

### 🙏 شكر خاص

- DeepSeek Team على API ممتاز ووثائق واضحة
- المجتمع على feedback والمساهمات

---

## [1.0.0] - 2026-04-24

### الإصدار الأولي

- دعم DeepSeek V4 (Pro & Flash)
- REPL تفاعلي على طراز Claude Code
- Tool loop مع function calling
- Pipeline متعدد المراحل للمهام المعقدة
- Dynamic agent generation
- SQLite memory store
- Evolution engine للتحسين الذاتي
- دعم كامل للعربية/RTL
- Git integration
- Project indexing
- Web search

---

**للمزيد من المعلومات:** راجع [QUICKSTART.md](QUICKSTART.md)
