# OM Cluster Validation

Use this local-only skill when validating Observational Memory OM Cluster on Bryan's machines, especially after release, relay, join/approval, sync, or transport changes.

This skill intentionally contains private/local operator context. Do not commit it to the public repository.

## Local Topology Snapshot

Known dogfood nodes from the 0.6.0 validation run:

- Local Mac: `SponkMax.local`
- GCP project: `isi-autonomy-bots`
- Zone: `us-central1-a`
- Control VM: `agent-ops-control-vm`
- Agent VMs: `hermes-agent-vm`, `acibf-agent-vm`
- Control VM private IP observed during validation: `10.128.0.6`
- Control VM Tailscale IP observed during validation: `100.99.246.63`

Do not put these details in public docs or GitHub issues unless Bryan explicitly asks.

## Current Production Cluster From 0.6.0 Dogfood

Cluster name: `Bryan Personal Memory`

Cluster ID observed in validation: `omc_3347c348cc3778ae55d77ce48ff44d35`

Real install paths:

- Local Mac: `/Users/bryanyoung/.local/bin/om`
- Remote VMs: `/home/bryanyoung/.local/bin/om`

Local Mac cluster transport used an SSH tunnel:

- Local config transport: `relay:http://127.0.0.1:18765`
- Tunnel target: `agent-ops-control-vm:localhost:18765`
- PID file: `/Users/bryanyoung/.local/share/observational-memory/relay/tunnel.pid`
- Reliable restart pattern:

```bash
gcloud compute ssh agent-ops-control-vm \
  --zone=us-central1-a \
  --project=isi-autonomy-bots \
  -- -f -N -L 18765:localhost:18765
lsof -tiTCP:18765 -sTCP:LISTEN | head -1 > /Users/bryanyoung/.local/share/observational-memory/relay/tunnel.pid
```

Remote nodes used the private relay URL:

```text
relay:http://10.128.0.6:18765
```

## Access Checks

First verify GCP auth and VM state:

```bash
gcloud compute instances list \
  --project=isi-autonomy-bots \
  --format='table(name,zone.basename(),status,networkInterfaces[0].networkIP)'
```

Probe a remote install:

```bash
gcloud compute ssh agent-ops-control-vm \
  --zone=us-central1-a \
  --project=isi-autonomy-bots \
  --command='hostname && whoami && /home/bryanyoung/.local/bin/om --version'
```

If `gcloud compute ssh` reports reauthentication failure, Bryan needs to run `gcloud auth login` interactively. Plain SSH to Tailscale IPs timed out in the 0.6.0 validation session; prefer `gcloud compute ssh` for these VMs.

## Install Or Refresh OM On Remote VMs

Use user-local installs. Do not install globally or mutate agent services for validation.

Control VM already had `uv` during validation:

```bash
gcloud compute ssh agent-ops-control-vm \
  --zone=us-central1-a \
  --project=isi-autonomy-bots \
  --command='set -e; /usr/local/bin/uv tool install --reinstall --refresh --exclude-newer 2026-05-15T00:00:00Z observational-memory==0.6.0; ~/.local/bin/om --version'
```

Agent VMs did not have `pip`; bootstrap `uv` user-locally if needed:

```bash
gcloud compute ssh hermes-agent-vm \
  --zone=us-central1-a \
  --project=isi-autonomy-bots \
  --command='set -e; if ! command -v uv >/dev/null 2>&1 && [ ! -x ~/.local/bin/uv ]; then curl -LsSf https://astral.sh/uv/install.sh | sh; fi; ~/.local/bin/uv tool install --reinstall --refresh --exclude-newer 2026-05-15T00:00:00Z observational-memory==0.6.0; ~/.local/bin/om --version'
```

Repeat for `acibf-agent-vm`.

## Relay Validation Pattern

0.6.0 dogfood used a small file-backed relay on the control VM. That proved protocol behavior but is not production packaging. For future validation, prefer the packaged relay once issue #46 is implemented. Until then, keep any relay fixture local-only and do not commit private scripts.

Public-safe relay secrecy scan pattern:

```bash
gcloud compute ssh agent-ops-control-vm \
  --zone=us-central1-a \
  --project=isi-autonomy-bots \
  --command='set -euo pipefail; STORE="$HOME/.local/share/observational-memory/relay/store"; if grep -R -a -E "data_keys|request_secret_b64|signing_private_key_b64|encryption_private_key_b64|OPENAI_API_KEY|ANTHROPIC_API_KEY" "$STORE"; then echo relay_secret_scan_failed; exit 31; else echo relay_secret_scan_passed; fi; find "$STORE" -type f | wc -l'
```

When using validation override values, add the exact non-secret strings to the grep pattern and verify they do not appear in relay artifacts.

## Cluster Init And Join Lessons

For a real production init path:

1. Start/reach the relay first.
2. Initialize one trusted node with `--import-existing`.
3. Use request-mode invites.
4. Approve requests on the trusted node.
5. Run `om cluster sync --json` on every node.
6. Validate `om cluster status --json` on every node.
7. Write a tiny non-secret override from each node.
8. Sync and read every value from every node.
9. Remove validation overrides so generated `active.md`/`profile.md` do not keep noise.
10. Re-run local `om doctor --validate-key` and relay artifact scans.

Important gotcha: in one validation run, issue #47 was created because remote nodes showed `pending_peers: 2` after convergence even though membership and sync worked. Treat that as a diagnostic/UX bug, not failed convergence, if all peers and records are otherwise present.

## Focused Validation Commands

Local health:

```bash
om doctor --validate-key
qmd --index observational-memory embed
om cluster status --json | jq '{cluster, node, peers:(.peers|length), pending_peers:(.pending_peers|length), records, transports}'
```

Remote focused cluster status:

```bash
gcloud compute ssh hermes-agent-vm \
  --zone=us-central1-a \
  --project=isi-autonomy-bots \
  --command='PATH="$HOME/.local/bin:$PATH" om cluster status --json | jq "{cluster, node, join_request, peers:(.peers|length), pending_peers:(.pending_peers|length), records, transports}"'
```

Remote `om doctor` can fail non-cluster checks if provider env files or Codex/Claude hooks are intentionally absent. For cluster validation, focus on:

- `OM Cluster: enabled`
- key permissions pass
- local records and heads present
- status peers/records match expected convergence
- sync summaries have no transport errors or rejected records

## Cleanup Pattern For Validation Overrides

After writing validation overrides:

```bash
for section in cluster_validation_local cluster_validation_control cluster_validation_hermes cluster_validation_acibf; do
  om cluster override remove --target active --section "$section"
done
om cluster sync --json
```

Then sync remotes and confirm materialized views do not include validation text:

```bash
rg -n 'cluster_validation_|local-ok-|control-ok-|hermes-ok-|acibf-ok-' \
  ~/.local/share/observational-memory/active.md \
  ~/.local/share/observational-memory/profile.md || true
```
