# OM Cluster Unified Roadmap and Implementation Plan

**Project:** `intertwine/observational-memory`  
**Primary baseline:** PR #33, `[codex] Release 0.6.0 OM Cluster Sync`  
**Backlog covered:** Issues #34, #35, #36, #37, #38, #39, #40, #41, plus additional hardening and product-quality recommendations  
**Prepared for:** long-running Codex `/goal` execution  
**Date:** 2026-05-14

---

## 1. Executive summary

PR #33 gives Observational Memory a strong first OM Cluster implementation: signed and encrypted append-only records, filesystem transport, local Markdown materialization, tombstones, key-rotation records, source hints, and an `om cluster` CLI. The right next move is to merge and release this as an opt-in `0.6.0` clustering preview, then iteratively harden the trust model, platform behavior, memory semantics, key-epoch model, and transport reach.

The most important sequencing recommendation is:

1. **Ship the filesystem-based cluster core first.** It is enough to dogfood real multi-machine memory sync.
2. **Harden trust, IDs, paths, and Windows behavior before expanding network reach.** Relay and P2P increase exposure; they should build on a boringly safe substrate.
3. **Move issue #41 earlier than the issue numbering implies.** Reflection metadata, stale-state decay, and host-memory coexistence are not just polish. They are the semantic foundation needed for cluster-aware reflection merging.
4. **Treat issue #37 as a key-epoch redesign, not merely historical re-encryption.** True compromise recovery requires distributing new keys only to non-revoked nodes, not encrypting the new key under an old cluster-wide symmetric key.
5. **Keep generated Markdown as a local view.** The signed/encrypted record log remains the sync source of truth.

Recommended roadmap:

```text
0.6.0 preview release
  Merge PR #33 plus a small invariant-hardening pass.

0.6.1 trust/platform hardening
  Implement #34 interactive approval, #40 Windows cluster hardening, #38 feature-flag caching.
  Preserve #39 Windows compatibility as baseline.

0.6.2 memory semantics
  Implement #41 per-entry reflection metadata, stale-state pruning, host-memory coexistence, and cluster-aware semantic merge rules.
  Add namespace/source policy and manual override semantics.

0.6.3 key epochs and compromise recovery
  Implement #37 as per-node wrapped key epochs plus historical rewrap/purge semantics.

0.6.4 transport reach
  Implement #35 hosted relay.
  Then implement #36 optional direct P2P transport.

0.6.x stabilization
  Add record indexing, diagnostics, performance tests, release docs, and dogfood validation.
```

Issue milestone labels currently put relay/P2P before re-encryption and before #41. This plan intentionally changes that execution order. The issue numbers still matter, but the implementation order should optimize for safe foundations first.

---

## 2. Current baseline to preserve

PR #33 should be treated as the architectural baseline unless current code inspection shows it changed. Preserve these properties:

- OM Cluster is disabled unless local cluster config and keys exist and are enabled.
- The sync substrate is an append-only record log, not direct synchronization of generated Markdown files.
- Transports are untrusted. Records are signed and payloads are encrypted before leaving the local machine.
- `observations.md`, `reflections.md`, `profile.md`, and `active.md` are local materialized views.
- The filesystem transport works with shared-folder tools such as Syncthing, Dropbox, iCloud Drive, NAS, rsync, or USB transfer.
- Provider env files, private keys, `.cursor.json`, `.search-index`, `.scheduler-logs`, `.qmd-docs`, and generated Markdown are never copied to transport storage as sync sources.
- Unknown-node records are rejected unless they chain through trusted membership/invite state.
- Existing non-cluster OM behavior remains unchanged when cluster mode is absent or disabled.
- PR #39 Windows compatibility remains intact: Windows-native config/data paths, scheduler behavior, hook compatibility, and Windows tests are a baseline, not work to redo.

---

## 3. Non-negotiable implementation principles

### 3.1 Safety first

Do not weaken the security model to make networking easier. Relay and P2P transports must never be able to authorize unknown nodes or decrypt memory. They only move opaque records, heads, public metadata, and join/approval artifacts.

### 3.2 Transport agnostic, trust explicit

Transport presence is not membership. Discovery is not trust. Seeing a node ID, head file, join request, or public metadata in any transport must never authorize that node.

### 3.3 Local-first behavior must survive failure

A failed sync must not prevent local observe, reflect, context, search, doctor, or export from functioning. In hook-sensitive commands, especially `om context`, timeout behavior must be conservative and stdout must remain valid for the consuming agent/tool.

### 3.4 No destructive migration without explicit user intent

Do not delete existing memory, old encrypted blobs, or historical records by default. Any purge or destructive cleanup requires a clear CLI command, explicit confirmation or `--yes`, and docs explaining irreversibility and limits.

### 3.5 Tests use isolated homes

All tests must use temporary HOME/XDG/APPDATA/LOCALAPPDATA roots and temporary transport paths. Tests must never touch the developer’s real OM data.

### 3.6 Generated files are views

Do not line-merge `profile.md`, `active.md`, `observations.md`, or `reflections.md` across machines. Durable manual changes must become records: observations, reflection snapshots, metadata-bearing reflection entries, manual overrides, tombstones, or key/membership records.

---

## 4. Long-running Codex execution model

Codex should execute this plan as a sequence of small coherent changes. It may merge PR #33 if the environment and repository permissions allow it. If direct merge is not possible, it should prepare the branch, document readiness, and continue implementing follow-up work on top of the PR branch.

### 4.1 Working loop for each milestone

For each milestone:

1. Inspect the current code and relevant issue body.
2. Update or create `docs/om-cluster-roadmap-status.md` with:
   - milestone name,
   - goals,
   - completed work,
   - tests run,
   - known limitations,
   - next milestone.
3. Add tests first where practical.
4. Implement the smallest production-quality slice.
5. Update CLI help, README, docs, and release notes where user-facing behavior changes.
6. Run focused tests, then full test/lint suite.
7. Fix failures before proceeding.
8. Keep changes grouped by milestone; commit if the environment supports commits.

### 4.2 Stop-and-ask conditions

Codex should stop and ask before:

- deleting user data or old encrypted blobs by default,
- changing existing public CLI semantics incompatibly,
- adding a heavyweight required dependency,
- weakening signature, encryption, or membership validation,
- introducing a hosted service dependency into the base install,
- making a release/tag/publish action if credentials or publishing state are uncertain,
- replacing the Markdown materialization model with a non-inspectable format.

Otherwise, Codex should continue iteratively and document partial progress.

### 4.3 Default validation commands

Discover the exact commands from `pyproject.toml`, README, and current CI. At minimum:

```bash
uv run pytest -q
uv run ruff check
```

Focused suites should include, as they exist or are added:

```bash
uv run pytest tests/sync -q
uv run pytest tests/test_config.py tests/test_observe.py tests/test_reflect.py tests/test_cli_context.py -q
uv run pytest tests/test_windows.py tests/sync -q
```

If optional extras are added:

```bash
uv run pytest -q                      # base install, no optional extras
uv run pytest -q --with-relay-extra    # or project-specific equivalent
uv run pytest -q --with-p2p-extra      # or project-specific equivalent
```

---

## 5. Milestone 0 — Merge PR #33 and prepare 0.6.0 preview

### 5.1 Goal

Land OM Cluster as an opt-in filesystem-backed preview while closing a few invariant-level risks before the first public clustering release.

### 5.2 Inputs

- PR #33: `codex/om-cluster-sync` branch.
- PR review comments already addressed in the branch, including O(1) record lookup, pending peer cap/status, key-dir hardening, key-rotation propagation by HLC, invite warning, snapshot truncation, and additional edge-case tests.
- PR #39 as Windows compatibility baseline.

### 5.3 Work items

#### A. Reconfirm PR #33 state

- Fetch latest PR head.
- Confirm mergeability against `main`.
- Run full tests and ruff.
- Run the two-temp-install filesystem sync smoke test.
- Confirm shared transport contains no plaintext memory bodies, env files, generated Markdown as source, or private keys.

#### B. Harden identifier and path validation

Add strict validation before any filesystem path construction or path glob use for:

```text
cluster_id
node_id
record_id
key_id
head filenames
record path components
transport metadata filenames
join_request_id
invite_id
```

Recommended rules:

- Reject empty strings.
- Reject `/`, `\`, NUL, `..`, path separators, leading dot path tricks, and whitespace-only values.
- Prefer explicit regexes such as:

```text
cluster_id:       ^omc_[A-Za-z0-9_-]{16,}$ or existing generated format
node_id:          ^node_[A-Za-z0-9_-]{16,}$ or existing generated format
record_id:        ^sha256_[a-f0-9]{64}$ or existing generated format
key_id:           ^key_[A-Za-z0-9_-]+$
join_request_id:  ^join_[A-Za-z0-9_-]+$
invite_id:        ^invite_[A-Za-z0-9_-]+$
```

Adjust regexes to match actual current generated IDs. The important point is consistent allow-list validation.

Also require:

- head filename stem and JSON `node_id` agree,
- public node metadata filename and metadata `node_id` agree,
- record path directory and envelope `node_id` agree,
- membership payload `node_id` matches envelope `node_id` when adding that node,
- signing public key identity is consistent with node ID if node IDs are derived from keys.

#### C. Fix imported head update semantics

Ensure out-of-order imports cannot regress the head record pointer.

Correct rule:

```python
current = read_head(record.node_id)
if current is None or record.node_seq > current.seq:
    write_head(record.node_id, record.node_seq, record.record_id)
elif record.node_seq == current.seq:
    accept only if same record_id or resolve deterministically
else:
    store record but leave head unchanged
```

Test out-of-order delivery:

1. Node A creates records seq 1, 2, 3.
2. Node B imports seq 3 first.
3. Node B imports seq 2 later.
4. Node B head remains seq 3 with seq 3 record ID.

#### D. Fix reflection catch-up frontier computation

Materializer catch-up detection should compute observation coverage from observation records only:

```python
observation_frontier = frontier_from_records(store.list_records(kind="observation"))
```

Do not let later non-observation records such as membership, tombstone, override, key rotation, or snapshot make reflection catch-up look complete.

Test:

- Node has observation seq 3.
- Node has manual override seq 4.
- Selected reflection snapshot frontier covers only observation seq 2.
- Expected: `catchup_needed == True`.

#### E. Clarify 0.6.0 key-rotation docs

Update docs and release notes:

```text
In 0.6.0, key rotation is forward-looking key hygiene for currently trusted nodes. It does not provide full compromise recovery if a revoked or compromised node already has the old cluster key and can still read old transport blobs. Full compromise recovery requires per-node key wrapping / key epochs and historical rewrap or purge, planned under #37.
```

Avoid implying that `rotate-key` alone protects against a known compromised device.

#### F. Release framing

Label 0.6.0 as:

```text
opt-in OM Cluster preview
filesystem transport ready for dogfooding
secure local-first design
not yet full compromise-recovery or general networking
```

### 5.4 Acceptance criteria

- PR #33 is merged or prepared for merge with all tests passing.
- OM Cluster remains disabled by default.
- Identifier/path validation rejects malicious path traversal and malformed transport content.
- Out-of-order imports do not corrupt heads.
- Reflection catch-up is based on observations, not unrelated record kinds.
- 0.6.0 docs accurately describe key rotation limits.
- Two-temp-install filesystem sync converges and does not leak plaintext or secrets.

### 5.5 Validation rubric

| Area | Pass | Fail |
|---|---|---|
| Backward compatibility | Non-cluster tests pass and disabled mode is unchanged | Cluster config changes behavior when disabled |
| Security | Malformed IDs/paths rejected before disk writes | Transport content can write outside cluster dir or poison metadata |
| Sync correctness | Out-of-order records stored safely without head regression | Older imports replace newer head pointers |
| Materialization | Catch-up notes reflect uncovered observations | Non-observation records mask stale reflections |
| Docs | Key rotation caveat is explicit | Docs imply false compromise recovery |

---

## 6. Milestone 1 — Interactive approval for invite/join (#34)

### 6.1 Goal

Replace trusted direct invites as the recommended path with a production-safe request/approval flow. Keep trusted direct invite available as an explicit bootstrap mode.

### 6.2 Design intent

The 0.6.0 direct invite contains cluster key material. That is acceptable as a preview/bootstrap mechanism, but not ideal as the default user experience. The safer model is:

1. Existing trusted node creates an invite or pairing hint.
2. New node uses it to submit a signed join request.
3. Existing trusted node reviews and approves the request.
4. Approval creates a signed membership record and distributes cluster key material encrypted specifically to the approved node.
5. Until approval, the new node can sync only request/diagnostic artifacts, not accepted memory records.

### 6.3 Record/artifact model

Add these artifacts or record kinds. Names can be adjusted to current code style.

#### `join_request`

Stored in transport-visible request area or as a record-like artifact that does not require cluster data-key decryption.

Fields:

```json
{
  "version": 1,
  "cluster_id": "omc_...",
  "request_id": "join_...",
  "requested_at": "2026-05-14T...Z",
  "expires_at": "2026-05-14T...Z",
  "node": {
    "node_id": "node_...",
    "alias": "bryan-laptop",
    "signing_public_key_b64": "...",
    "encryption_public_key_b64": "..."
  },
  "requested_namespaces": ["personal"],
  "transport_hints": [],
  "invite_id": "invite_...",
  "fingerprint": "...",
  "signature": "signature by requester signing key over canonical request body"
}
```

The join request must not include cluster data keys.

#### `join_approval`

Created by a trusted node.

Fields:

```json
{
  "version": 1,
  "cluster_id": "omc_...",
  "request_id": "join_...",
  "approved_at": "...",
  "approved_by_node_id": "node_...",
  "approved_node_id": "node_...",
  "membership_record_id": "sha256_...",
  "wrapped_keys": [
    {
      "key_id": "key_...",
      "key_epoch": 1,
      "recipient_node_id": "node_...",
      "wrapped_data_key": "..."
    }
  ],
  "signature": "signature by approving trusted node"
}
```

Approval may either create a normal `node_membership` record plus a `key_grant` record, or a combined membership payload. Prefer separate concepts if #37 key epochs are being introduced soon.

### 6.4 CLI surface

Minimum CLI:

```bash
om cluster invite --mode request --expires 10m
om cluster invite --mode trusted-direct --expires 10m
om cluster join <invite-token>
om cluster requests
om cluster requests --json
om cluster approve <request-id>
om cluster reject <request-id> --reason "..."
om cluster status
```

Behavior:

- Default `om cluster invite` should eventually be `--mode request`.
- 0.6.0 direct invite remains available with explicit `--mode trusted-direct`.
- `om cluster join <token>` creates a pending request unless token is direct/trusted and the user explicitly uses that mode.
- `om cluster status` distinguishes pending, approved, rejected, expired, and trusted-direct states.
- The approving node displays fingerprint, alias, requested namespaces, request age, and signing-key fingerprint.

### 6.5 Security requirements

- Expired invites are rejected.
- Replayed join requests are rejected or idempotently ignored.
- Rejected requests cannot later become approved without a new request or explicit override.
- Unapproved nodes cannot inject accepted observations, snapshots, tombstones, overrides, membership records, or key-rotation records.
- Approval signs exactly what is approved: node ID, public keys, alias, namespaces, request ID, and expiration.
- Discovery and transport visibility do not imply trust.

### 6.6 Acceptance criteria

- A second machine can request membership without receiving cluster data keys first.
- Existing trusted node can inspect, approve, and reject requests.
- Approved node receives enough encrypted key material to sync.
- Pre-approval records from requester are rejected by existing nodes.
- Existing 0.6.0 direct-invite clusters remain compatible.
- CLI and docs clearly distinguish request approval vs trusted-direct invite.

### 6.7 Validation rubric

| Test | Expected result |
|---|---|
| Pending join request | Appears in `om cluster requests` and `status --json` |
| Approve request | Membership and key grants sync; new node converges |
| Reject request | New node remains unauthorized |
| Replay request | Ignored or rejected deterministically |
| Expired invite | Join fails with clear error |
| Unauthorized pre-approval observation | Rejected and logged diagnostically |
| Direct invite regression | Works only when explicit trusted-direct path is used |

---

## 7. Milestone 2 — Windows cluster hardening (#40) and feature-flag caching (#38)

### 7.1 Goal

Make OM Cluster first-class on Windows and reduce repeated cluster feature-gate overhead without changing behavior.

### 7.2 Preserve #39 baseline

PR #39 already added Windows 10/11 compatibility for core OM install/observe/reflect/search/status/doctor, Windows-native config/data roots, Task Scheduler integration, Windows Claude hooks, and Windows simulation tests. Do not regress any of that.

### 7.3 Windows work items (#40)

#### A. Windows key protection semantics

POSIX `0600`/`0700` is not a complete Windows ACL guarantee. Implement a platform abstraction:

```python
verify_private_path_owner_only(path: Path) -> PermissionCheckResult
harden_private_path(path: Path) -> PermissionCheckResult
```

On POSIX:

- directories should be owner-only where applicable,
- key files should be `0600`,
- diagnostics should fail on overly broad permissions.

On Windows:

- Prefer an actual owner-only ACL check if feasible.
- If robust ACL introspection is too large, use a conservative best-effort check and have `om doctor` report `WARN` rather than false `PASS`.
- Document what is and is not verified.

#### B. Windows path tests

Add tests with simulated Windows roots:

```text
%APPDATA%
%LOCALAPPDATA%
filesystem:C:\Users\Bryan\Sync\om-cluster
filesystem:C:/Users/Bryan/Sync/om-cluster
filesystem:%LOCALAPPDATA%\OM\cluster
```

Confirm `om cluster init`, `invite`, `join`, `sync`, `status`, `doctor`, and transport parsing behave correctly.

#### C. Filesystem transport on Windows

Validate:

- atomic writes with `os.replace`,
- directory fsync fallback behavior,
- `DirectoryLock` behavior,
- two-temp-install sync flow,
- OneDrive/Syncthing-style paths where possible.

If no real Windows runner is available, attach a manual validation transcript and keep simulated tests in CI.

#### D. Windows docs

Add a Windows section to `docs/om-cluster-sync.md`:

- recommended transport directory location,
- OneDrive/Syncthing notes,
- key directory expectations,
- doctor diagnostics,
- backup/recovery caveats.

### 7.4 Feature-flag caching work items (#38)

Implement a small cache for `cluster_feature_enabled(config)` that avoids repeated TOML/key parsing when inputs are unchanged.

Cache key should include:

```text
cluster_config_path exists + mtime + size
node key path exists + mtime + size
cluster key path exists + mtime + size
relevant env vars, especially OM_CLUSTER_ENABLED
config root identity / path
```

Requirements:

- `OM_CLUSTER_ENABLED` changes are reflected within the same process.
- File changes are reflected after file-signature changes or explicit cache invalidation.
- Tests can invalidate cache deterministically.
- Behavior remains identical for uninitialized, disabled, missing-key, enabled, env-overridden states.

### 7.5 Acceptance criteria

- Windows cluster CLI and path tests pass.
- `om doctor` reports key protection appropriately on Windows without POSIX false positives.
- Feature-gate caching reduces repeated parsing and passes mutation/env tests.
- Existing POSIX behavior is unchanged.
- Full test suite and ruff pass.

### 7.6 Validation rubric

| Area | Pass | Fail |
|---|---|---|
| Windows path parsing | Drive-letter filesystem transports parse correctly | `filesystem:C:\...` is misread or rejected |
| Windows key diagnostics | Warns or verifies accurately | Reports false safety from POSIX modes |
| Feature cache | Reflects env/file changes | Caches stale enabled/disabled state |
| Compatibility | #39 Windows tests still pass | Core Windows workflows regress |

---

## 8. Milestone 3 — Reflection metadata, stale-state decay, and host-memory coexistence (#41)

### 8.1 Goal

Give OM memories entry-level semantics so agents can distinguish evergreen rules from decaying snapshot facts, preserve manual edits, merge cluster reflections intelligently, and coexist cleanly with host-agent memory systems.

This milestone should happen before relay/P2P and before complex cluster merge behavior expands.

### 8.2 Metadata convention

Implement inline HTML metadata comments on reflection entries.

Recommended format:

```markdown
- Project uses git worktrees for branch isolation <!--om: id=ome_abc123 kind=evergreen last_seen=2026-05-14T12:00:00Z node=node_a scope=cluster-->
- PR #33 is open as clustering release candidate <!--om: id=ome_def456 kind=snapshot last_seen=2026-05-14T12:00:00Z node=node_a ttl_days=14-->
```

Minimum fields:

```text
id         stable entry ID, preserved across edits when possible
kind       evergreen | snapshot | identity | preference | task | decision
last_seen  ISO-8601 UTC timestamp
node       origin node or last confirming node
scope      cluster | local
```

Optional fields:

```text
source_agent
namespace
project_id
confidence
expires_at
ttl_days
supersedes
source_record_id
cluster=local
```

Keep the comment human-inspectable and robust to manual edits. Do not require a JSON sidecar for basic operation.

### 8.3 Parser/writer module

Add a dedicated module, for example:

```text
src/observational_memory/reflection_metadata.py
```

Responsibilities:

- parse bullets and metadata comments,
- preserve unknown fields,
- preserve manual text edits,
- generate IDs for legacy entries,
- infer kind for legacy entries,
- serialize metadata deterministically,
- expose filtering and aging helpers.

### 8.4 Legacy migration

Existing `reflections.md` without metadata must continue to work. On next reflect/prune:

- infer `kind` from section context and text heuristics,
- stamp `last_seen` from file mtime, not wall-clock now, to preserve age signal,
- assign stable IDs,
- write a one-time summary to stderr or logs if appropriate,
- do not require interactive confirmation.

Heuristic examples:

```text
snapshot: PR numbers, branch state, commit SHAs, "approved on", "pending", current sprint, ticket IDs
identity/preference: user identity, communication preferences, durable personal preferences
evergreen: stack choices, conventions, architecture decisions, long-term project rules
```

### 8.5 Aging/prune behavior

Add config:

```toml
[reflector]
snapshot_ttl_days = 14
snapshot_expiry_action = "stale-section"  # stale-section | drop | annotate
```

Add command:

```bash
om prune
om prune --dry-run
om prune --json
om prune --drop-stale
om prune --namespace personal
```

Behavior:

- Snapshot entries older than TTL are dropped, annotated, or moved to `## Stale snapshots` depending on config/flags.
- Evergreen entries are not removed by age alone.
- Evergreen `last_seen` is refreshed only when reinforced by new observations.
- `om prune` is idempotent.

### 8.6 Reflector prompt updates

Update the reflector prompt to:

- emit metadata comments on every entry,
- classify entries by kind,
- preserve IDs and metadata for retained entries,
- update `last_seen` only when an entry is reaffirmed,
- avoid turning stale snapshots into evergreen rules,
- respect `scope=local` / `cluster=local`,
- include source namespace/node when available.

### 8.7 Host-agent coexistence docs

Add `docs/coexistence.md` and a README pointer.

Recommended ownership boundary:

```text
Host auto-memory owns:
  host-local feedback,
  tool-specific behavior preferences,
  ephemeral conversation state,
  host-specific UI or workflow preferences.

OM owns:
  cross-agent project state,
  multi-host shared identity/preferences,
  durable workflow rules,
  long-form architectural/project memory,
  memory intended to sync across machines.
```

Add config to reduce overlap:

```toml
[profile]
generate = true
include_identity = true
```

Support disabling identity/profile generation if user wants host memory to own identity:

```toml
[profile]
include_identity = false
```

### 8.8 Cluster-aware semantic merge

When reflection entries carry metadata:

- Snapshot conflicts: last-writer-wins by `last_seen`, with deterministic tie by node ID and entry ID.
- Evergreen entries: union with text deduplication; conflicting but plausible entries are kept with node/source annotation until next reflect reconciles them.
- Identity/preference entries: prefer explicit manual override records, then latest confirmed entry, then keep conflict note if incompatible.
- `scope=local` or `cluster=local` entries do not sync or do not materialize into cluster-shared views.
- Entries should reference source record IDs where possible for provenance.

### 8.9 Acceptance criteria

- `om reflect` writes metadata comments for reflection entries.
- Legacy files migrate without breaking.
- `om prune` exists, is idempotent, and respects TTL/config.
- Manual edits survive reflect/prune cycles.
- Host-memory coexistence docs are clear and actionable.
- Cluster merge uses metadata for snapshot and evergreen conflicts.
- Tests cover metadata round-trip, legacy migration, TTL boundary, prune idempotency, manual edits, local-only scope, and cluster two-node merge behavior.

### 8.10 Validation rubric

| Area | Pass | Fail |
|---|---|---|
| Metadata | Every generated entry has parseable metadata | Metadata missing or malformed |
| Legacy migration | Old reflections remain usable and get inferred metadata | Old files are overwritten destructively |
| Aging | Snapshot TTL prunes/marks stale facts | Evergreen memory is accidentally pruned |
| Manual edits | User edits preserved and metadata repaired | Reflector discards user edits |
| Cluster merge | Snapshot conflicts resolve by timestamp; evergreen union works | Flat Markdown conflicts persist |
| Coexistence | Docs define ownership/tiebreakers | Agents still get contradictory guidance |

---

## 9. Milestone 4 — Namespace/source policy, override semantics, and record indexing

This milestone incorporates suggested improvements not fully captured by #34–#41.

### 9.1 Goal

Make cluster records easier to reason about, query, and scale by improving source/namespace policy, manual override behavior, and record lookup/indexing.

### 9.2 Namespace/source policy

Add explicit commands:

```bash
om cluster namespace list
om cluster namespace add personal
om cluster namespace add project:observational-memory
om cluster namespace remove <namespace>
om cluster source-policy list
om cluster source-policy add --agent codex --namespace project:observational-memory
om cluster source-policy add --git-remote <url-or-hash> --namespace project:observational-memory
om cluster source-policy add --path-contains /work/expel --namespace work:expel --local-only
```

Privacy modes:

```text
full     include readable project/source labels
hashed   hash paths/remotes/transcripts, include aliases
minimal  no project/path labels beyond namespace and node
```

Acceptance criteria:

- Users can inspect and modify namespace rules without editing TOML manually.
- Records carry enough source metadata for provenance without leaking raw paths by default.
- Local-only namespaces do not sync or are excluded from transport materialization.
- Docs explain namespaces, source policies, privacy modes, and examples.

### 9.3 Override semantics

Current manual overrides are append-friendly. Make them structured and conflict-aware.

CLI:

```bash
om cluster override set --target profile --section communication_style --body "..."
om cluster override get --target profile --section communication_style
om cluster override list --json
om cluster override remove --target profile --section communication_style
```

Rules:

- `(target, section, namespace)` is the logical key.
- Multiple records may exist, but materializer chooses the latest non-tombstoned value by HLC unless conflict policy says otherwise.
- Conflicting concurrent overrides are surfaced in `om cluster status` or a `Manual Override Conflicts` section.
- Remove creates a tombstone or an explicit override-delete record.

Acceptance criteria:

- Upsert behaves like upsert at materialization time.
- Conflicts are deterministic and visible.
- Existing override records still materialize.
- JSON output supports scripts.

### 9.4 Record index for scaling

Add a rebuildable local index so common operations do not repeatedly scan/parse every `.omr.json`.

Start simple:

```text
clusters/<cluster-id>/index/records.json
```

or SQLite if already justified. Prefer simple JSON first unless performance tests show a need.

Index fields:

```text
record_id
path
node_id
node_seq
hlc
kind
namespace
tombstoned
key_id
payload_hash
source summary
```

Requirements:

- Rebuildable from record files.
- Atomically updated after import/append/tombstone.
- Safe if missing or stale: detect and rebuild.
- Does not store plaintext payload unless explicitly designed and protected.

Acceptance criteria:

- `has_record(record_id)` is O(1)-ish without full parse.
- `list_records(kind=...)` can use index and fall back safely.
- Performance test with thousands of records remains acceptable.
- Index corruption does not corrupt source records.

### 9.5 Validation rubric

| Area | Pass | Fail |
|---|---|---|
| Namespaces | Policies route records correctly | Records leak raw sensitive path/source info |
| Overrides | Upsert/remove semantics deterministic | Duplicate override sections grow forever |
| Index | Rebuildable and non-authoritative | Index corruption breaks records |
| Performance | Large sync/materialize avoids repeated full scans | Moderate histories become slow |

---

## 10. Milestone 5 — Key epochs and historical re-encryption (#37)

### 10.1 Goal

Replace the preview key-rotation model with a true key-epoch model that can exclude revoked nodes from future key material and support historical rewrap/re-encryption without losing provenance.

### 10.2 Critical design clarification

The current 0.6.0 rotation model is forward-looking key hygiene, not full compromise recovery. If a compromised node has the old cluster-wide symmetric key and can still read old transport blobs or the rotation record encrypted under that key, it may be able to decrypt old or even newly distributed material.

To satisfy the #37 acceptance criterion that a revoked node with only old key material cannot decrypt newly re-encrypted historical payloads, OM needs:

- per-node encryption public keys,
- per-epoch data keys,
- new data keys wrapped separately to each non-revoked trusted node,
- records that declare their key epoch/key ID,
- rewrap/re-encryption records or replacement payload records,
- optional purge of old ciphertext if true transport-level recovery is desired.

### 10.3 Node key model

Extend node metadata:

```json
{
  "node_id": "node_...",
  "alias": "...",
  "signing_public_key_b64": "...",
  "encryption_public_key_b64": "...",
  "revoked": false,
  "revoked_after_hlc": null
}
```

Local key material:

```text
node signing private key
node encryption private key
known cluster data keys by epoch/key_id
```

Implementation options:

- Use X25519 + HKDF + AEAD wrapping from `cryptography`.
- Or use a conservative sealed-box-like helper if already present.
- Keep dependencies limited to existing `cryptography` unless there is a strong reason.

### 10.4 Key epoch records

Add `key_epoch` or `key_rotation` v2 records:

```json
{
  "kind": "key_epoch",
  "epoch": 2,
  "key_id": "key_nodeA_...",
  "created_by": "node_A",
  "created_at_hlc": "...",
  "recipients": [
    {
      "node_id": "node_A",
      "wrapped_key": "...",
      "wrapping_scheme": "x25519-hkdf-chacha20poly1305-v1"
    },
    {
      "node_id": "node_B",
      "wrapped_key": "..."
    }
  ],
  "excluded_nodes": ["node_revoked"],
  "reason": "manual-rotation"
}
```

Rules:

- Only trusted non-revoked nodes receive wrapped keys.
- Importing node can decrypt a data key only if it has a wrapped recipient entry.
- Latest valid epoch by HLC/epoch number becomes active.
- Concurrent rotations resolve deterministically or are surfaced as split-brain requiring reconciliation.

### 10.5 Historical rewrap model

Preserve append-only auditability while allowing new ciphertext.

Recommended approach: append `payload_rewrap` records.

```json
{
  "kind": "payload_rewrap",
  "target_record_id": "sha256_...",
  "target_envelope_hash": "sha256_...",
  "new_key_epoch": 2,
  "new_key_id": "key_...",
  "rewrapped_payload_ciphertext": "...",
  "rewrapped_payload_hash": "sha256_...",
  "rewrapped_by": "node_A",
  "reason": "historical-key-rotation"
}
```

Materializer logic:

- For a target record, prefer the latest valid rewrap under an active accessible key.
- Verify that decrypted rewrapped payload hash matches the target payload hash or expected canonical payload hash.
- Preserve original provenance: source node, source HLC, source record ID remain the logical origin.
- Tombstoned records remain excluded.

Optional purge command:

```bash
om cluster rotate-key --reencrypt-historical
om cluster reencrypt --from-epoch 1 --to-epoch 2 --dry-run
om cluster purge-old-ciphertext --epoch 1 --confirm
```

Do not purge by default. Warn that true compromise recovery requires ensuring old ciphertext is no longer accessible to the revoked node, including transport folders and backups.

### 10.6 Acceptance criteria

- Active nodes can rotate to a new epoch and receive wrapped keys.
- Revoked nodes do not receive new wrapped keys.
- Active nodes can decrypt and materialize intended records after historical rewrap.
- Revoked node with only old key material cannot decrypt newly rewrapped payloads in the test harness.
- Record provenance and frontier/snapshot semantics remain coherent.
- Rewrap is resumable and safely retryable.
- Tombstoned content is not resurrected.
- Docs clearly explain what re-encryption does and does not protect against.

### 10.7 Validation rubric

| Area | Pass | Fail |
|---|---|---|
| Key exclusion | Revoked nodes lack new wrapped keys | Revoked nodes receive or derive new keys |
| Rewrap correctness | Materialized Markdown unchanged for active nodes | Rewrap changes memory content unexpectedly |
| Provenance | Original source and record ID remain traceable | Rewrap obscures provenance |
| Recovery caveat | Docs warn about old blobs/backups | Docs promise impossible erasure |
| Resume | Interrupted rewrap can continue safely | Partial rewrap corrupts store |

---

## 11. Milestone 6 — Hosted relay transport (#35)

### 11.1 Goal

Add an optional relay transport that stores and serves encrypted/signed records, heads, public node metadata, and join/approval artifacts only.

### 11.2 Timing recommendation

Implement after #34 interactive approval and after key-epoch design is at least stable. A relay increases reach and therefore the importance of explicit trust and robust keying.

### 11.3 Relay contract

Minimal API:

```http
GET  /v1/clusters/<cluster_id>/heads
PUT  /v1/clusters/<cluster_id>/heads/<node_id>
GET  /v1/clusters/<cluster_id>/records/<record_id>
PUT  /v1/clusters/<cluster_id>/records/<record_id>
GET  /v1/clusters/<cluster_id>/nodes
PUT  /v1/clusters/<cluster_id>/nodes/<node_id>
GET  /v1/clusters/<cluster_id>/join-requests
PUT  /v1/clusters/<cluster_id>/join-requests/<request_id>
GET  /v1/clusters/<cluster_id>/approvals/<request_id>
PUT  /v1/clusters/<cluster_id>/approvals/<request_id>
```

Relay must not need:

```text
cluster data keys
node private keys
provider env files
plaintext memory
generated Markdown
trust decisions
```

Optional relay access tokens may be used to prevent abuse, but relay access tokens are not cluster trust.

### 11.4 Client behavior

- Add relay transport adapter implementing the same protocol as filesystem transport.
- Timeouts are short by default for hook-sensitive contexts.
- Relay failures do not block local memory capture.
- Local clients verify signatures, membership, revocation, tombstones, key epochs, and payload hashes exactly as with filesystem transport.

### 11.5 Packaging

Keep relay optional:

```text
base install: no relay server dependency
client-only relay may use stdlib or optional extra
server fixture can live under dev/test extras
```

If using `httpx`, `aiohttp`, FastAPI, or similar, put it behind an extra and justify the dependency.

### 11.6 Acceptance criteria

- Users can configure relay transport alongside filesystem transport.
- Two nodes converge via relay with no shared filesystem.
- Relay stores only encrypted/signed records and public metadata/artifacts.
- Tampered, unknown-node, revoked-node, expired, unsupported-version, and stale/partial relay data is rejected locally.
- Relay outages do not break local observe/reflect/context.
- Docs cover relay operator responsibilities, retention, metadata exposure, and failure modes.

### 11.7 Validation rubric

| Area | Pass | Fail |
|---|---|---|
| Security | Relay cannot decrypt or authorize | Relay has plaintext/trust role |
| Resilience | Outages are diagnostic only | Local hooks fail due to relay slowness |
| Packaging | Base install unaffected | Relay dependency required by default |
| Convergence | Two nodes converge via relay | Relay transport diverges from filesystem semantics |

---

## 12. Milestone 7 — Optional direct P2P transport (#36)

### 12.1 Goal

Add optional direct peer-to-peer transport for authorized nodes without requiring shared filesystem or hosted relay.

### 12.2 Timing recommendation

Implement after relay or after a transport evaluation note. P2P introduces NAT traversal, packaging, runtime, firewall, and dependency concerns. Do not make it a required dependency.

### 12.3 Evaluation note

Before implementation, commit `docs/om-cluster-p2p-evaluation.md` covering:

- local HTTP over LAN,
- mDNS/DNS-SD discovery,
- Tailscale-local assumptions,
- QUIC options,
- Iroh/libp2p bindings if Python-friendly,
- dependency footprint,
- supported platforms,
- security model,
- why selected approach was chosen.

### 12.4 Implementation options

#### Option A: Local HTTP LAN transport

Pros:

- smallest dependency footprint,
- easiest testability,
- works well with Tailscale or LAN.

Cons:

- not full NAT traversal,
- needs service lifecycle decisions.

#### Option B: Iroh/libp2p-like transport

Pros:

- better NAT traversal and P2P semantics if bindings are mature.

Cons:

- dependency and packaging risk,
- may be too heavy for OM base package.

### 12.5 Requirements

- P2P transport implements the existing transport protocol.
- Base install works without P2P dependencies.
- Discovery gives connection hints only, never trust.
- Unauthorized peers cannot inject accepted records.
- Revoked peers are rejected.
- Connection failures do not block local memory behavior.

### 12.6 CLI/config

```toml
[[transport]]
type = "p2p"
enabled = true
listen = "127.0.0.1:0"  # or chosen format
peers = ["..."]
discovery = "mdns"       # optional
```

Commands:

```bash
om cluster p2p serve
om cluster p2p status
om cluster p2p peers
```

Or integrate serving into scheduler if appropriate.

### 12.7 Acceptance criteria

- Two local nodes exchange records over loopback or LAN-safe fixture.
- Base tests pass without P2P extra installed.
- Optional P2P tests pass when extra is installed.
- Unauthorized/tampered/revoked peer tests pass.
- Docs explain supported network environments and limitations.

### 12.8 Validation rubric

| Area | Pass | Fail |
|---|---|---|
| Optionality | Base install unaffected | Base install imports P2P dependency |
| Trust | Discovery does not authorize | Discovered peer can inject accepted records |
| Runtime | Failure degrades gracefully | P2P failure blocks local OM |
| Scope | Docs state LAN/NAT limits | Users expect unsupported global P2P |

---

## 13. Milestone 8 — Final stabilization, docs, release packaging, and dogfood

### 13.1 Goal

Turn the implemented roadmap into a stable `0.6.x` cluster line with clear docs, diagnostics, performance behavior, and release confidence.

### 13.2 Work items

#### A. Documentation consolidation

Ensure docs cover:

- quick start,
- filesystem transport,
- interactive approval,
- trusted-direct invite caveat,
- relay transport,
- P2P transport,
- key epochs and rewrap,
- redaction caveats,
- Windows setup,
- namespaces/source policies,
- host-memory coexistence,
- troubleshooting,
- recovery and backup.

#### B. `om doctor` cluster checks

Add or verify checks for:

- initialized/enabled state,
- key permissions/ACLs,
- transport availability,
- pending peers/requests,
- record count and heads,
- rejected diagnostics,
- materializer state,
- stale snapshots,
- key epoch status,
- missing optional transport dependencies,
- Windows-specific warnings.

#### C. Dogfood scripts

Add a manual validation script or documented checklist:

```bash
# temp node A
om cluster init --transport filesystem:/tmp/om-shared --import-existing
om cluster invite --mode request --expires 10m

# temp node B
om cluster join <token>

# A approves
om cluster requests
om cluster approve <request-id>

# both sync
om cluster sync --json
om cluster status --json

# create observations/reflections/overrides/redactions/key rotations
# verify convergence and no plaintext/secrets in transport
```

#### D. Performance checks

Add a synthetic test or benchmark with thousands of records:

- import speed,
- sync speed,
- materialization speed,
- provenance lookup,
- status command latency,
- index rebuild time.

Do not make microbenchmarks brittle in CI; use broad thresholds or mark as manual/perf.

### 13.3 Acceptance criteria

- Full suite and ruff pass.
- Docs match actual CLI behavior.
- Dogfood two-node and, where possible, three-node flows pass.
- Windows validation is documented or automated.
- No transport leaks plaintext or keys.
- Users can understand current limitations.

---

## 14. Cross-cutting test matrix

Codex should add tests progressively and keep this matrix green.

| Category | Required coverage |
|---|---|
| Disabled mode | No cluster config, disabled config, missing keys, env override off/on |
| Crypto | canonicalization, signature verification, tamper rejection, AEAD AAD binding, key epoch unwrap |
| Paths/IDs | malformed IDs, traversal attempts, filename/body mismatch, unknown versions |
| Store | atomic append, idempotent import, duplicate ID different bytes rejection, out-of-order head update |
| Sync | two-node convergence, three-node convergence, partial transport data, deadline/timeout behavior |
| Membership | direct invite, request invite, approval, rejection, expiration, replay, revoked node future records |
| Materialization | observations, snapshots, catch-up, tombstones, overrides, local-only entries, metadata merge |
| Reflection metadata | parse/write, migrate legacy, TTL boundary, prune idempotency, manual edit preservation |
| Key epochs | rotate, grant, revoke, rewrap, purge warnings, revoked node negative tests |
| Transports | filesystem, relay, P2P optional; base install without optional deps |
| Windows | config roots, path parsing, key diagnostics, atomic writes, transport smoke |
| Docs/CLI | help text, JSON output shape, doctor diagnostics, release notes |

---

## 15. Suggested new issue breakdown

These are not currently separate issues, but this plan recommends implementing them as sub-issues or internal milestones.

### 15.1 Harden OM Cluster identifier validation and transport path safety

Scope:

- strict allow-list validation for IDs,
- filename/body consistency checks,
- malicious transport-content tests.

### 15.2 Add rebuildable OM Cluster record index for large histories

Scope:

- local non-authoritative index,
- O(1)-ish lookups,
- safe rebuild,
- performance tests.

### 15.3 Add explicit namespace/source policy commands and privacy modes

Scope:

- CLI for namespace and source policies,
- privacy modes,
- local-only namespace support,
- docs.

### 15.4 Make manual profile/active overrides structured and conflict-aware

Scope:

- set/get/list/remove,
- deterministic materialization,
- conflict reporting,
- backward compatibility.

---

## 16. Final release criteria for the completed roadmap

The roadmap is complete when:

- PR #33 is merged and 0.6.0 preview behavior is preserved.
- Issues #34–#38 and #40–#41 are implemented or explicitly superseded by a better documented design.
- PR #39 Windows compatibility remains green and cluster-specific Windows hardening is complete.
- Issue #37 is implemented as a key-epoch/rewrap model with honest compromise-recovery docs.
- Relay and P2P are optional and do not affect base install.
- All generated Markdown remains local materialization, not sync source of truth.
- Docs explain how to configure, operate, troubleshoot, and recover a cluster.
- Full test suite and ruff pass.
- A manual or automated multi-node validation proves convergence, redaction, approval, key rotation/epoch behavior, and transport secrecy.

---

## 17. Compact Codex `/goal` seed

Use the full document above as the detailed plan. The following is a compact goal seed that points Codex at this document without trying to encode every detail inline.

```text
/goal Destination: Observational Memory has a merged, hardened, fully iterated OM Cluster 0.6.x implementation covering PR #33 and issues #34-#41, plus the additional hardening and roadmap in om_cluster_unified_roadmap_implementation_plan.md. First read that document, PR #33, and issues #34-#41. Work milestone by milestone: merge/prepare PR #33 and harden 0.6.0 preview; implement strict ID/path validation, safe head updates, observation-only reflection catch-up, and honest key-rotation docs; implement #34 interactive approval; preserve #39 and implement #40 Windows cluster hardening; implement #38 feature-flag caching; implement #41 reflection metadata, stale-state pruning, host-memory coexistence, and cluster-aware semantic merge; add namespace/source policy, override semantics, and record indexing; implement #37 as key epochs plus historical rewrap/purge semantics; implement #35 relay and #36 optional P2P only after trust/key foundations are safe. Preserve disabled-mode behavior, local-first operation, generated Markdown as materialized views, untrusted transports, no secret/plaintext leakage, and base install without heavyweight optional transport dependencies. After each milestone update docs/om-cluster-roadmap-status.md, add focused tests, run pytest and ruff, and continue unless a change would delete user data, weaken security, require a large required dependency, or incompatibly change public CLI semantics. Success means full tests/lint pass, docs match behavior, and multi-node temp-install validation proves convergence, approval, redaction, key epoch behavior, Windows coverage, and transport secrecy.
```

---

## 18. Suggested first Codex task after loading this plan

Before attempting the full roadmap, give Codex this immediate subgoal if you want a safe first slice:

```text
/goal Prepare PR #33 for 0.6.0 opt-in preview release by hardening cluster invariants and release documentation. Implement strict validation for cluster_id/node_id/record_id/key_id and related filesystem path components; ensure transport head filenames and JSON node IDs agree; ensure membership node IDs/public keys are consistent; fix imported head updates so older out-of-order records never replace newer head record IDs; compute materializer observation catch-up frontiers from observation records only; update key-rotation docs to state 0.6.0 rotation is forward-looking key hygiene, not compromise recovery against revoked nodes with old keys; add focused tests for malformed IDs, path traversal, out-of-order imports, materializer catch-up, and key-rotation docs. Preserve disabled mode and existing APIs. Run pytest and ruff.
```
