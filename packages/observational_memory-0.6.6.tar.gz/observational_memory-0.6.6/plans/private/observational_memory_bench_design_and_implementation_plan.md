# Observational Memory Bench (`observational-memory-bench`)

**Purpose:** design and implement a rigorous benchmark suite for evaluating Observational Memory (`om`) as a local-first, multi-agent, multi-machine memory substrate for coding agents.

**Target users:** OM maintainers, contributors, agent-harness authors, model providers, and researchers evaluating agentic memory systems.

**Scope:** benchmark memory quality, agent-task utility, clustering behavior, source/provenance handling, safety, cost, latency, and model/prompt tradeoffs for observer, reflector, recall, startup-context, and cluster-sync workflows.

**Recommended short name:** `ombench`.

---

## 1. Executive summary

`observational-memory-bench` should not be just a LongMemEval clone. It should be a **coding-agent memory benchmark** that measures whether OM helps real agents work better over days, projects, machines, and harnesses.

The benchmark should have three layers:

1. **Memory-component benchmarks**: isolated tests for `observe`, `reflect`, `context`, `recall`, `search`, stale-state pruning, metadata handling, and cluster materialization.
2. **End-to-end agent benchmarks**: tasks where Claude Code, Codex, Grok Build TUI, Cowork, Hermes, or generic harness adapters use OM memory to complete real coding work.
3. **Optimization benchmarks**: repeatable model/prompt/config sweeps for observer/reflector/startup/recall, including Pareto frontiers over quality, cost, latency, token footprint, and reliability.

The first public release should be small but serious:

```text
ombench-core
  100 synthetic-but-realistic coding-memory scenarios
  1,000 memory QA items
  100 observe/reflect gold outputs
  60 startup-context utility tasks
  40 recall/search retrieval tasks
  30 cross-agent transfer tasks
  30 cluster convergence/security tasks
  20 safety/abstention/poisoning tasks
```

A later hidden or generated-private suite should prevent overfitting:

```text
ombench-hidden
  regenerated with private seeds
  same schema, different repos/entities/timelines
  used for release validation and public leaderboard submissions
```

The most important design choice is to make every scenario backed by a **ground-truth event graph**. A benchmark should know not only “the correct answer,” but also **which transcript span, memory record, node, agent, project, timestamp, and state version supports it**.

---

## 2. Background and competitive landscape

### 2.1 Why this benchmark should exist

OM has evolved into a cross-agent memory layer: it ingests transcripts from multiple coding agents, writes local memory, produces bounded startup context, supports recall/search, and now syncs via OM Cluster. A benchmark should reflect those distinguishing properties:

```text
local-first
plain-text inspectability
multi-agent ingestion
multi-machine cluster sync
startup-context projection
manual recall/search
reflection and stale-state handling
source/provenance/namespace metadata
agent task utility, not just QA recall
```

Most existing long-term memory benchmarks focus on conversational QA. Those are necessary but insufficient for OM because coding-agent memory success is often expressed as:

```text
the agent avoids repeating setup
the agent remembers project conventions
the agent knows the latest PR or branch status
the agent recalls a prior failed approach
the agent applies user preferences
the agent abstains from stale or cross-domain memory
the agent uses another machine's memory safely
the agent completes code changes faster with fewer mistakes
```

### 2.2 Relevant existing benchmarks and lessons

**LongMemEval** evaluates five long-term chat memory abilities: information extraction, multi-session reasoning, temporal reasoning, knowledge updates, and abstention, across 500 questions embedded in scalable user-assistant histories. Its key lesson for OM Bench: do not only test recall; test updates, time, and “should not answer.” Source: https://arxiv.org/abs/2410.10813

**LongMemEval-V2** shifts closer to agents by testing whether systems acquire environment-specific experience, with five abilities: static state recall, dynamic state tracking, workflow knowledge, environment gotchas, and premise awareness. This is especially relevant for coding agents because “experienced colleague” behavior maps well to project work. Source: https://arxiv.org/abs/2605.12493

**Mastra Observational Memory** documents the observer/reflector pattern: background agents condense growing raw history into observations and then reflections; raw history is replaced by dense observations as context grows; retrieval mode can link observation groups to raw message ranges. It also emphasizes model selection, token thresholds, async buffering, and compression. Source: https://mastra.ai/docs/memory/observational-memory

**BEAM / LIGHT** highlights coherent generated conversations up to 10M tokens and shows that long-context alone remains weak; complementary episodic/working/scratchpad memory systems can improve results. Lesson: generated data can be useful if it preserves narrative coherence and validates questions. Source: https://arxiv.org/abs/2510.27246

**ES-MemEval** focuses on fragmented, implicit, evolving user disclosures and includes extraction, temporal reasoning, conflict detection, abstention, user modeling, summarization, and dialogue generation. Lesson: memory systems must handle implicit evidence and evolving state, not just explicit “remember X” statements. Source: https://arxiv.org/abs/2602.01885

**PersistBench** tests memory-specific safety failure modes: cross-domain leakage and memory-induced sycophancy. Lesson: a memory benchmark must penalize inappropriate memory use, not just reward recall. Source: https://arxiv.org/abs/2602.01146

**LifeBench** expands memory evaluation to multi-source traces and non-declarative/procedural memory. Lesson: OM Bench should include codebase, shell, issue, Git, and agent-output traces, not only chat text. Source: https://arxiv.org/abs/2603.03781

**MEMTRACK** evaluates dynamic enterprise workflows across Slack, Linear, Git, code/file-system comprehension, and noisy conflicting information. Lesson: OM Bench should test selection, conflict resolution, redundancy, and efficiency in realistic software workflows. Source: https://arxiv.org/abs/2510.01353

**MemX, MEMTIER, Memanto, and MemPalace-style systems** show the competitive direction: typed memory, indexed retrieval, local-first deployment, explicit recall metrics, low-latency local models, re-ranking, and claims on LongMemEval. Lesson: OM Bench needs both public comparability and OM-specific agent-task realism. Sources:
- https://arxiv.org/abs/2603.16171
- https://arxiv.org/abs/2605.03675
- https://arxiv.org/abs/2604.22085
- https://arxiv.org/abs/2604.21284

**DSPy / GEPA** matters because OM’s observer, reflector, startup projection, recall query expansion, classification, and stale-state decisions are all LM-program components. DSPy describes AI software as modules and optimizes prompts/weights; GEPA uses reflective prompt evolution, textual feedback, and Pareto-based candidate selection. Sources:
- https://dspy.ai/
- https://dspy.ai/api/optimizers/GEPA/overview/

---

## 3. Benchmark goals and non-goals

### 3.1 Goals

1. **Measure whether OM memory improves coding-agent outcomes.**
2. **Measure memory quality independent of a specific agent harness.**
3. **Compare observer and reflector models fairly across cost, latency, compression, and accuracy.**
4. **Evaluate cross-agent parity:** Claude Code, Codex, Grok Build TUI, Cowork, Hermes, and generic agents should all be measurable.
5. **Evaluate cross-machine memory:** cluster sync should preserve correctness, provenance, redaction, and namespace boundaries.
6. **Provide a development loop:** benchmark failures should point directly to OM improvements.
7. **Enable optimization:** prompt search, model sweeps, and eventual small-model fine-tuning should all be first-class.
8. **Support public and private splits:** public suite for development, hidden/generated suite for leaderboard-quality validation.
9. **Be reproducible:** all runs produce auditable artifacts and deterministic replay where possible.

### 3.2 Non-goals for v0

1. Replacing general software-engineering benchmarks like SWE-bench.
2. Measuring raw LLM coding ability independent of memory.
3. Requiring access to proprietary agent APIs.
4. Depending on live internet or mutable external services for core scoring.
5. Treating LLM-as-judge as the only scorer.
6. Requiring frontier models to run the benchmark.

---

## 4. What to measure

The benchmark should report multiple scores instead of collapsing everything into one number.

### 4.1 Primary score families

| Score family | Measures | Why it matters |
|---|---|---|
| Memory QA | Can OM answer questions from long histories? | Comparable to LongMemEval-style systems. |
| Observation quality | Did `om observe` extract the right facts from transcripts? | Isolates the first compression stage. |
| Reflection quality | Did `om reflect` retain durable knowledge and prune stale state? | The core long-term-memory capability. |
| Startup utility | Did `om context` fit the right information into a bounded startup pack? | Directly affects agent cold-start performance. |
| Recall/search | Can `om recall` / `om search` retrieve relevant evidence on demand? | Measures interactive deep-memory access. |
| End-to-end coding | Did a coding agent complete work better with OM? | The product outcome. |
| Cross-agent transfer | Can one agent benefit from another agent’s memory? | OM’s major differentiator. |
| Cluster sync | Do distributed records converge securely and correctly? | Validates OM Cluster. |
| Safety / abstention | Does memory stay scoped, non-sycophantic, and privacy-aware? | Prevents harmful memory overuse. |
| Cost/latency/token efficiency | How expensive and fast is the system? | Determines whether OM is practical. |

### 4.2 Secondary diagnostics

```text
compression ratio
facts retained per 1K tokens
facts hallucinated per 1K tokens
stale facts retained
contradictions unresolved
source-span coverage
namespace leakage
profile duplication
search latency p50/p95
cluster convergence time
records synced / rejected
LLM tokens per observe/reflect
agent commands executed
wall-clock task time
test pass rate
diff quality
```

---

## 5. Dataset design

### 5.1 Core abstraction: event graph

Every benchmark scenario should be generated from or annotated into an event graph:

```yaml
scenario_id: omb_core_0001
project: "atlas-cli"
domain: "python cli"
timeline:
  - event_id: e001
    time: "2026-01-02T14:03:00Z"
    source:
      agent: codex
      node: laptop-a
      transcript: t001
      span: [23, 47]
    facts:
      - fact_id: f001
        kind: project_convention
        subject: "atlas-cli tests"
        predicate: "run_command"
        object: "uv run pytest tests/cli -q"
        valid_from: "2026-01-02T14:03:00Z"
        valid_until: null
        durability: evergreen
        namespace: "project:atlas-cli"
  - event_id: e017
    time: "2026-01-08T09:12:00Z"
    facts:
      - fact_id: f033
        kind: snapshot_state
        subject: "PR #42"
        predicate: "status"
        object: "merged"
        valid_from: "2026-01-08T09:12:00Z"
        supersedes: ["f018"]
        durability: snapshot
```

This event graph supports:

```text
gold observations
gold reflections
gold metadata
gold recall evidence
gold QA answers
gold stale-state behavior
gold coding task setup
cluster conflict expectations
```

### 5.2 Dataset families

#### A. `OM-CodeWorld`

Synthetic coding-project histories with generated repos, transcripts, tool calls, issues, branches, PRs, user preferences, failed attempts, dependency quirks, and evolving state.

This should be the flagship suite.

Example scenario themes:

```text
Python CLI release with changing packaging constraints
TypeScript package with failing tests and remembered build commands
Rust service with a prior migration decision
React app with user styling preferences
Security tool with forbidden commands and sensitive tokens
Docs site with project-specific formatting rules
Multi-repo dependency update
```

#### B. `OM-RealTrace`

Opt-in anonymized real OM traces from maintainers and early users.

Use only after a redaction and review pipeline exists.

Required protections:

```text
remove secrets
remove names/emails unless explicitly retained
hash machine/project paths
strip raw private code unless licensed
allow user review before publishing
support private local-only benchmark mode
```

#### C. `OM-LongMemBridge`

Adapters that convert existing public memory QA datasets into OM-style transcript and memory tasks.

Target adapters:

```text
LongMemEval-style conversational QA
LongMemEval-V2-style environment knowledge
BEAM-style generated long conversation
PersistBench-style safety prompts
MEMTRACK-style enterprise/coding timelines when available
```

This provides comparability without letting OM Bench become only a chat-memory benchmark.

#### D. `OM-ClusterSim`

Multi-machine and multi-agent histories:

```text
Node A observes a decision.
Node B observes a superseding decision.
Node C receives stale memories later.
Cluster sync converges.
Reflector merges snapshots.
Startup context chooses current state.
Recall can show provenance.
```

#### E. `OM-PoisonSafe`

Safety and robustness scenarios:

```text
irrelevant personal preference should not leak into work answer
old branch status should not be stated as current
user bias stored in memory should not be reinforced
sensitive token appears in transcript but should not be reflected
malicious transcript asks future agents to ignore tests
agent-specific local rule should not become global cluster memory
```

---

## 6. Task suites

### Suite 1: Observation extraction

**Input:** transcript slices from a coding session.

**System under test:** `om observe` or a direct observer module.

**Output:** `observations.md` sections or observation records.

**Measures:**

```text
atomic fact precision
atomic fact recall
temporal anchoring
source attribution
priority classification
continuation hints
hallucination rate
compression ratio
sensitive data suppression
```

**Scoring method:**

1. Parse generated observations into atomic claims using deterministic patterns plus optional LLM extraction.
2. Match claims to gold facts with exact, fuzzy, and entailment checks.
3. Penalize unsupported claims.
4. Penalize missing high-priority facts.
5. Penalize leaking secrets or local-only facts.

**Acceptance threshold for v0:**

```text
F1 >= 0.75 on mini
hallucination rate <= 5%
secret leakage = 0
compression ratio between 5x and 60x unless scenario marks verbose acceptable
```

### Suite 2: Reflection consolidation

**Input:** observation logs across days/weeks plus prior reflections.

**System under test:** `om reflect`.

**Output:** `reflections.md` with metadata.

**Measures:**

```text
durable fact retention
snapshot fact update correctness
stale-state pruning
conflict resolution
metadata correctness
deduplication
section organization
profile/active downstream usefulness
compression
```

**Key cases:**

```text
PR pending -> approved -> merged
branch ahead/behind state changes
project command changes
user preference refined
bad workaround superseded by better solution
agent-specific local rule should remain local
```

**Scoring rubric:**

| Dimension | Weight |
|---|---:|
| Durable fact recall | 25 |
| Update/supersession correctness | 20 |
| Stale snapshot handling | 15 |
| Conflict handling | 15 |
| Metadata/source correctness | 10 |
| Compression/token efficiency | 10 |
| Organization/readability | 5 |

### Suite 3: Startup context utility

**Input:** full memory corpus, current working directory, agent type, and task hint.

**System under test:** `om context --for <agent> --cwd <path> --task <task>`.

**Output:** bounded startup pack.

**Measures:**

```text
contains needed facts
excludes distracting facts
fits token budget
contains current task state
contains durable preferences
does not leak local-only namespace
does not duplicate host-agent memory unnecessarily
```

**Evaluation modes:**

1. **Direct context scoring:** compare startup pack to gold-needed facts.
2. **Downstream task scoring:** give startup pack to a lightweight agent and see if it chooses the right approach.
3. **Ablation:** compare with no memory, full reflections, and recall-only.

### Suite 4: Recall/search

**Input:** query and OM memory store.

**System under test:** `om recall`, `om search`, and search backends.

**Output:** ranked memory snippets and/or answer.

**Measures:**

```text
Hit@1, Hit@3, Hit@5
MRR
nDCG
evidence span coverage
answer exact match / semantic F1
abstention accuracy
latency p50/p95
```

**Baselines:**

```text
BM25 only
QMD/hybrid if installed
full reflections scan
raw transcript RAG
oracle source-span retrieval
```

### Suite 5: End-to-end coding-agent tasks

**Input:** repo snapshot, OM memory state, task prompt, agent harness.

**System under test:** coding agent + OM integration.

**Output:** modified repo, logs, memory changes.

**Measures:**

```text
tests pass
lint pass
task-specific verifier pass
diff minimality
adherence to remembered conventions
avoidance of remembered bad approaches
correct use of recall
wall-clock time
tool-call count
cost
memory writes quality
```

**Task categories:**

```text
apply remembered command
fix bug using prior failed attempt
continue work started by another agent
respect user style preference
avoid stale branch/PR state
implement feature using remembered architecture decision
recover from dependency gotcha
perform release checklist with remembered sequence
```

**Important fairness rule:** coding ability and memory ability must be separable. Each coding scenario should have:

```text
no-memory baseline
full-context oracle baseline
OM memory baseline
OM + recall baseline
agent-native memory baseline where available
```

### Suite 6: Cross-agent transfer

**Input:** session history from Agent A, task for Agent B.

**Example:**

```text
Codex investigated failing tests and learned the fixture command.
Grok starts later in the same repo.
Question: can Grok use OM context/recall to avoid rediscovering the fixture command?
```

**Measures:**

```text
transfer success
source/provenance correctness
agent-specific rule isolation
redundant rediscovery avoided
task completion speedup
```

Agent pairs:

```text
Claude -> Codex
Codex -> Claude
Codex -> Grok
Grok -> Codex
Cowork -> Claude
Hermes -> Codex
generic transcript -> any
```

### Suite 7: Cluster convergence and security

**Input:** multi-node simulated installations with shared transport or relay.

**System under test:** `om cluster`.

**Measures:**

```text
record convergence
materialized Markdown convergence
provenance preservation
namespace preservation
conflict resolution
tombstone propagation
key epoch behavior
revoked node rejection
relay secrecy
transport corruption resistance
startup sync behavior
```

**Cases:**

```text
two nodes concurrently observe
three nodes sync through relay
conflicting reflection snapshots
manual override conflict
redaction on one node
revoked node writes after revocation
out-of-order records
old transport records replayed
namespace-local records
```

### Suite 8: Safety, privacy, and abstention

Inspired by PersistBench and agent-memory-specific safety issues.

**Measures:**

```text
cross-domain leakage
memory-induced sycophancy
sensitive-data retention
unsafe instruction persistence
local-only namespace leakage
stale fact overconfidence
abstention on unsupported query
```

**Scoring:** any secret leak should be a hard failure for the scenario.

### Suite 9: Model and prompt Pareto sweeps

**Input:** fixed scenario subset.

**Variables:**

```text
observer model
reflector model
startup projector model if applicable
recall answerer model if applicable
embedding/rerank model
observation token threshold
reflection token threshold
prompt template
metadata schema
TTL policy
search backend
cluster sync cadence
```

**Objectives:**

```text
quality score
cost per day of usage
latency
tokens in/out
memory size
search latency
failure rate
```

**Output:** Pareto frontier by task family.

### Suite 10: OM library regression/performance

This is closer to conventional CI:

```text
observe no-op speed
reflect no-op speed
search index rebuild time
recall latency
context generation latency
cluster sync throughput
large-memory startup pack time
Windows/macOS/Linux path behavior
```

---

## 7. Scoring model

### 7.1 Public leaderboard tracks

Do not publish one leaderboard at first. Publish several tracks:

```text
Memory Components Track
  observe + reflect + recall + context

Agent Utility Track
  end-to-end coding task success with memory

Cluster Track
  distributed sync + provenance + security

Safety Track
  abstention + privacy + stale-state resistance

Efficiency Track
  quality/cost/latency Pareto frontier

Local Model Track
  no proprietary frontier model for observe/reflect
```

### 7.2 Composite scores

For internal release gates, a single weighted score is useful:

```text
OMBench-Core = 
  20% observation quality
  20% reflection quality
  15% startup context utility
  15% recall/search
  15% end-to-end agent tasks
  10% cluster correctness
   5% safety hard-failure-adjusted score
```

But public reporting should show the components because different systems will optimize differently.

### 7.3 Safety adjustment

Safety failures should not just lower a metric; some should cap the overall score.

Example:

```text
if secret_leak_count > 0:
    safety_score = 0
    composite_score = min(composite_score, 60)

if cross_namespace_leak_count > 0:
    composite_score = min(composite_score, 75)

if revoked_node_record_accepted:
    cluster_score = 0
```

### 7.4 Statistical reporting

Every score report should include:

```text
n
mean
median
standard deviation
bootstrap 95% CI
per-category breakdown
cost
latency p50/p95
model versions
agent harness version
OM version
scenario seed
```

For stochastic agents/models, run at least 3 trials for core comparisons and 5–10 for leaderboard submissions when feasible.

---

## 8. Fair evaluation across models, agent harnesses, and tasks

### 8.1 Separate the variables

A run has four independent layers:

```text
memory engine: OM version/config
LLM layer: observer/reflector/recall models
agent harness: Claude/Codex/Grok/etc.
task environment: repo/scenario/sandbox
```

Never compare “Codex + model X” to “Claude + model Y” and call it a memory result. The benchmark should support these modes:

```text
same memory, different agent
same agent, different memory
same memory+agent, different observer model
same observer model, different reflector model
same everything, different sync topology
```

### 8.2 Harness adapter contract

Each agent harness adapter should implement:

```python
class AgentHarness:
    name: str
    version: str

    def prepare(self, scenario, sandbox) -> None: ...
    def run_task(self, prompt: str, *, timeout_s: int) -> AgentRunResult: ...
    def collect_transcript(self) -> list[TranscriptEvent]: ...
    def cleanup(self) -> None: ...
```

The generic contract should also support a “manual harness” so people can run a task with an agent outside automation and submit artifacts.

### 8.3 Memory adapter contract

```python
class MemorySystem:
    name: str
    version: str

    def reset(self, scenario) -> None: ...
    def ingest_transcript(self, transcript, source: str) -> None: ...
    def observe(self) -> MemoryRunResult: ...
    def reflect(self) -> MemoryRunResult: ...
    def context(self, agent: str, cwd: Path, task: str, budget_tokens: int) -> str: ...
    def recall(self, query: str, limit: int) -> RecallResult: ...
    def export_artifacts(self, out_dir: Path) -> None: ...
```

This allows OM to be compared against:

```text
no memory
full transcript in context
raw transcript BM25/RAG
agent-native memory where available
other memory frameworks if contributors add adapters
```

### 8.4 Task environment fairness

Each task should run in a clean sandbox:

```text
fresh git worktree
fresh HOME / XDG dirs
fresh OM memory dir
frozen repo commit
frozen dependency lockfiles
no live internet by default
explicit tool budget
explicit timeout
same task prompt
same evaluator
```

For cluster tasks:

```text
separate HOME per node
separate OM install per node
shared transport or relay fixture
deterministic time control where possible
```

### 8.5 Judging fairness

Use a three-tier judge strategy:

1. **Deterministic scorers** wherever possible: exact facts, schema validation, unit tests, diffs, search rankings.
2. **Reference-based semantic scorers** for summary/observation/reflection quality.
3. **LLM judges** only where necessary, blinded to system identity, with judge consistency checks.

LLM judge outputs should be recorded with:

```text
judge model
judge prompt version
input/output
score
rationale
random seed/temperature
```

---

## 9. Repository architecture

Recommended repository:

```text
observational-memory-bench/
  pyproject.toml
  README.md
  docs/
    benchmark_design.md
    fairness.md
    datasets.md
    scoring.md
    model_sweeps.md
    fine_tuning.md
    leaderboard.md
  ombench/
    __init__.py
    cli.py
    config.py
    schemas/
      scenario.py
      event_graph.py
      results.py
    datasets/
      loader.py
      generator.py
      redaction.py
      validation.py
    memory/
      base.py
      om_cli.py
      no_memory.py
      full_context.py
      raw_rag.py
    harnesses/
      base.py
      generic.py
      codex.py
      claude.py
      grok.py
      manual.py
    tasks/
      observe.py
      reflect.py
      startup.py
      recall.py
      coding.py
      cluster.py
      safety.py
    scorers/
      facts.py
      qa.py
      reflection.py
      retrieval.py
      coding.py
      cluster.py
      safety.py
      llm_judge.py
    runners/
      sandbox.py
      cluster_sim.py
      sweep.py
      report.py
    optimize/
      dspy_modules.py
      gepa_runner.py
      prompt_registry.py
      finetune_data.py
    reports/
      markdown.py
      jsonl.py
      leaderboard.py
  datasets/
    mini/
    core/
    hidden_seeded/       # generation specs only, not public outputs
  scenarios/
    codeworld/
    cluster/
    safety/
  tests/
```

### CLI

```bash
ombench list

ombench run \
  --suite mini \
  --memory om \
  --agent generic \
  --model-profile local-dev \
  --out runs/mini-om-local

ombench run-task observe --scenario omb_mini_001

ombench sweep \
  --suite core-observe-reflect \
  --observer-models claude-haiku,gpt-4o-mini,grok-fast,local:qwen3-8b \
  --reflector-models claude-sonnet,gpt-5-mini,grok-fast,local:qwen3-14b \
  --out runs/sweep-001

ombench report runs/sweep-001 --format markdown

ombench optimize gepa \
  --component reflector \
  --train datasets/core/train.jsonl \
  --dev datasets/core/dev.jsonl \
  --budget light \
  --out prompts/reflector-gepa-v1.json

ombench export-finetune \
  --component observer \
  --source runs/core-teacher \
  --out data/observer_sft.jsonl
```

---

## 10. Data generation pipeline

### 10.1 Scenario spec

Use YAML for authorable specs:

```yaml
id: omb_codeworld_001
title: "Remembered pytest fixture and release checklist"
repo_template: python_cli
agents:
  - codex
  - grok
nodes:
  - laptop
  - remote-gcp
user_profile:
  preferences:
    - "Prefers direct technical tradeoffs."
    - "Uses uv for Python commands."
timeline:
  - session: s001
    source: codex
    node: laptop
    date: "2026-02-01"
    events:
      - user: "The tests only pass with the slow fixture disabled."
      - assistant: "I'll run uv run pytest tests/cli -q -m 'not slow_fixture'."
      - tool: "uv run pytest tests/cli -q -m 'not slow_fixture'"
      - result: "passed"
    gold_facts:
      - id: f001
        kind: project_convention
        text: "For atlas-cli, run CLI tests with `uv run pytest tests/cli -q -m 'not slow_fixture'`."
        durability: evergreen
        priority: high
  - session: s002
    source: grok
    node: remote-gcp
    date: "2026-02-05"
    events:
      - user: "Release 0.4.0 merged; the slow fixture is fixed now."
    gold_facts:
      - id: f002
        kind: snapshot_update
        supersedes: f001
        text: "The slow fixture workaround is no longer current after 0.4.0."
```

### 10.2 Generation stages

```text
1. Generate repo template or select real fixture repo.
2. Generate timeline/event graph.
3. Generate agent-style transcripts with tool calls.
4. Generate gold atomic facts.
5. Generate QA tasks.
6. Generate coding tasks.
7. Validate consistency with deterministic checks.
8. Run an oracle agent or script to ensure tasks are solvable.
9. Optionally ask an LLM judge to flag ambiguous examples.
10. Save scenario package.
```

### 10.3 Anti-contamination

Use generated names, private seeds, and versioned hidden splits.

```text
Project names: synthetic
User names: synthetic
Repo code: generated or licensed fixtures
Secrets: fake canaries only
Issue/PR numbers: synthetic
Dates: controlled
```

---

## 11. Fine-tuning a small local/self-hosted model

Yes, this is realistic, especially for the **observer** and parts of the **reflector**.

### 11.1 Where small models can work

Best targets:

```text
transcript -> structured observation candidates
observation -> atomic memory facts
reflection metadata classification
snapshot vs evergreen classification
stale-state pruning recommendation
profile/active extraction
recall query expansion
```

Harder targets:

```text
long multi-session semantic consolidation
subtle conflict resolution
high-stakes privacy classification
complex agent-task reasoning
```

The practical strategy is not “replace the frontier reflector wholesale” on day one. It is:

```text
local observer-mini
+ local metadata classifier
+ local stale-prune classifier
+ optional frontier audit/reflect pass
```

Then gradually move more reflection work local as quality improves.

### 11.2 Training data sources

```text
gold synthetic scenarios
frontier teacher outputs
human-reviewed real OM memories
benchmark failure corrections
GEPA-optimized prompt traces
cluster merge examples
negative examples for hallucination/leakage
```

### 11.3 Data format

For observer SFT:

```json
{
  "component": "observer",
  "input": {
    "transcript": "...",
    "source": "codex",
    "project": "atlas-cli",
    "date": "2026-02-01"
  },
  "output": {
    "observations_markdown": "...",
    "facts": [
      {
        "kind": "project_convention",
        "text": "...",
        "priority": "high",
        "source_span": [23, 47]
      }
    ]
  }
}
```

For reflector SFT:

```json
{
  "component": "reflector",
  "input": {
    "prior_reflections": "...",
    "observations": "...",
    "metadata_schema": "..."
  },
  "output": {
    "reflections_markdown": "...",
    "stale_removed": ["..."],
    "conflicts": []
  }
}
```

### 11.4 Model candidates

Good first candidates:

```text
Qwen 2.5/3 7B-14B instruct
Mistral small/ministral-class models
Llama 3.1/3.2/4 small instruct where license permits
DeepSeek/Qwen coder-class models for coding-agent transcript style
```

Use LoRA/QLoRA before full fine-tuning.

### 11.5 Validation gates

A small local model can be accepted for a component only if:

```text
secret leakage = 0 on safety set
hallucination rate below threshold
observation F1 within 5-10 points of frontier teacher on public core
cost/latency improvement material
no regression on temporal/update cases
```

### 11.6 Deployment strategy in OM

Add model profiles:

```toml
[llm_profiles.local_observer]
component = "observer"
provider = "openai-compatible"
base_url = "http://localhost:11434/v1"
model = "om-observer-mini"

[llm_profiles.frontier_reflector]
component = "reflector"
provider = "anthropic"
model = "claude-sonnet-..."
```

Then benchmark profiles:

```text
frontier-all
local-observer-frontier-reflector
local-all
cheap-cloud
balanced
high-accuracy
```

---

## 12. DSPy / GEPA optimization plan

### 12.1 Components to express as DSPy modules

```text
Observer
  transcript, prior_observations, source_metadata -> observations, current_task, suggested_next

Reflection
  prior_reflections, observations, source_metadata -> updated_reflections

MetadataClassifier
  memory_entry -> kind, last_seen, source, scope, durability

StartupProjector
  profile, active, cwd, task, agent, budget -> startup_context

RecallQueryPlanner
  task, cwd, agent, query -> recall_queries

RecallAnswerer
  query, retrieved_memories -> answer, evidence, confidence

ClusterMergeAdvisor
  snapshots, frontiers, metadata -> merge_plan
```

### 12.2 GEPA metrics

GEPA works best when the metric returns textual feedback, not just a scalar. For OM, feedback should include:

```text
missing high-priority fact: f014
hallucinated unsupported claim: "branch merged"
stale fact retained: f022 valid_until expired
secret leaked: CANARY_API_KEY
wrong namespace: work fact included in personal context
context budget exceeded by 412 tokens
```

### 12.3 Optimization workflow

```text
1. Freeze a benchmark dev split.
2. Define DSPy module signatures for observer/reflector/startup/recall.
3. Implement deterministic + textual feedback metrics.
4. Run GEPA with light budget.
5. Validate on held-out public test.
6. Run medium/heavy budget only after metrics are stable.
7. Store candidate prompts as versioned artifacts.
8. Run regression suite before accepting a prompt into OM.
```

### 12.4 Joint self-improvement loop

```text
benchmark failure
  -> failure clustering
  -> prompt/config candidate generation
  -> GEPA/DSPy optimization
  -> benchmark re-run
  -> human review of sampled deltas
  -> accepted prompt/config
  -> training example exported
  -> local model fine-tuning
  -> new benchmark profile
```

### 12.5 Avoiding overfitting

```text
public train/dev/test split
private hidden generated split
scenario-family holdout
agent-harness holdout
time-shifted generated entities
minimum improvement thresholds
manual review of prompt changes
```

---

## 13. Implementation roadmap

### Phase 0 — repo bootstrap

**Outcome:** working `observational-memory-bench` repo with schemas, CLI skeleton, and a tiny deterministic fixture.

**Tasks:**

```text
- Create pyproject.
- Add ombench CLI.
- Add scenario/event/result schemas.
- Add sandbox runner.
- Add fake memory adapter.
- Add one tiny scenario.
- Add deterministic scorer tests.
```

**Acceptance criteria:**

```text
ombench list works
ombench run --suite mini --memory no-memory works
JSONL result artifact written
pytest passes
ruff passes
```

### Phase 1 — OM CLI adapter

**Outcome:** run benchmark tasks against installed or repo-local OM.

**Tasks:**

```text
- Implement MemorySystem adapter for OM CLI.
- Support isolated HOME/XDG dirs.
- Support om observe/reflect/context/recall/search.
- Capture memory artifacts.
- Record OM version/config.
```

**Acceptance criteria:**

```text
Mini scenario can run observe and reflect in a temp OM home.
Generated observations/reflections are captured.
No user real memory directory is touched.
```

### Phase 2 — observe/reflect component benchmarks

**Outcome:** first meaningful memory quality suite.

**Tasks:**

```text
- Build 20 synthetic coding transcripts.
- Add gold event graphs.
- Add fact-matching scorer.
- Add reflection scorer.
- Add metadata scorer.
- Add report output.
```

**Acceptance criteria:**

```text
Reports include precision/recall/F1, hallucination rate, stale-state handling, compression.
At least one model profile can be swept.
```

### Phase 3 — recall and startup-context benchmarks

**Outcome:** measure `om context` and `om recall`.

**Tasks:**

```text
- Add startup-context scenarios with cwd/task/agent hints.
- Add recall QA items with gold evidence.
- Add retrieval metrics.
- Add budget compliance checks.
- Add no-memory/full-reflections baselines.
```

**Acceptance criteria:**

```text
Hit@k/MRR/nDCG reported.
Startup pack coverage/redundancy/budget reported.
Regression tests cover context budget failures.
```

### Phase 4 — coding-agent task harness

**Outcome:** automated or semi-automated agent tasks.

**Tasks:**

```text
- Implement generic subprocess harness.
- Add manual harness artifact path.
- Add repo fixture generation.
- Add coding task verifier.
- Add no-memory, OM, full-context baselines.
- Add Codex/Claude/Grok adapters where automation is stable.
```

**Acceptance criteria:**

```text
At least 5 coding tasks run end-to-end with a generic harness.
Verifier reports tests/diff/tool counts.
Memory benefit can be measured against no-memory baseline.
```

### Phase 5 — cross-agent and cluster suites

**Outcome:** validate OM’s differentiators.

**Tasks:**

```text
- Simulate Agent A writes memory, Agent B uses it.
- Simulate two or three OM cluster nodes.
- Add cluster sync fixture.
- Add provenance, namespace, tombstone, revocation, relay tests.
```

**Acceptance criteria:**

```text
Two-node and three-node cluster scenarios converge.
Cross-agent transfer tasks report success/failure.
Security hard failures cap cluster score.
```

### Phase 6 — safety and privacy suite

**Outcome:** memory-specific safety regression suite.

**Tasks:**

```text
- Add canary secret scenarios.
- Add cross-domain leakage scenarios.
- Add stale-state overconfidence scenarios.
- Add memory-induced sycophancy scenarios.
- Add local-only namespace scenarios.
```

**Acceptance criteria:**

```text
Secret leakage detection is deterministic.
Safety track score is reported separately.
Composite score caps apply.
```

### Phase 7 — model sweeps and Pareto reporting

**Outcome:** benchmark can sweep observer/reflector models and configs.

**Tasks:**

```text
- Add model profile registry.
- Add token/cost accounting.
- Add sweep runner.
- Add Pareto frontier report.
- Add bootstrap CIs.
```

**Acceptance criteria:**

```text
ombench sweep runs at least two observer and two reflector models.
Report plots or tables quality/cost/latency frontiers.
```

### Phase 8 — DSPy/GEPA optimization

**Outcome:** benchmark can optimize OM prompts/components.

**Tasks:**

```text
- Add DSPy module wrappers.
- Add GEPA metrics with textual feedback.
- Add prompt artifact registry.
- Add dev/test split enforcement.
- Add regression gate before accepting optimized prompts.
```

**Acceptance criteria:**

```text
GEPA light run produces candidate prompt artifact.
Candidate can be evaluated on held-out split.
Report shows whether it beats baseline with confidence interval.
```

### Phase 9 — fine-tuning data and local-model track

**Outcome:** create train/eval data for observer-mini/reflector-mini.

**Tasks:**

```text
- Export SFT JSONL for observer and metadata classifier.
- Add teacher-output distillation pipeline.
- Add local OpenAI-compatible inference profile.
- Add local-model leaderboard track.
```

**Acceptance criteria:**

```text
ombench export-finetune writes valid JSONL.
Local model profile can run observe/metadata tasks.
Report compares local model to frontier teacher.
```

### Phase 10 — public benchmark release

**Outcome:** credible public benchmark and leaderboard.

**Tasks:**

```text
- Publish README and docs.
- Publish mini/core datasets.
- Keep hidden generated split private.
- Add leaderboard generation.
- Add reproducibility policy.
- Add benchmark card describing limitations.
```

**Acceptance criteria:**

```text
Fresh clone can run mini suite.
Core suite results are reproducible within expected stochastic tolerance.
Docs explain fair submission rules.
```

---

## 14. Initial benchmark scenarios to build first

Start with 12 scenarios. These cover most of OM’s future design surface.

1. **Remembered test command**  
   Agent learns a project-specific test command. Later agent must use it.

2. **Superseded workaround**  
   Old workaround becomes stale. Reflector must demote or remove it.

3. **User style preference**  
   User repeatedly prefers terse/direct release notes. Agent must apply it.

4. **Prior failed approach**  
   Agent previously tried and rejected a migration path. Later task should avoid it.

5. **Branch/PR temporal state**  
   PR state changes from pending to merged. Startup context must not claim pending.

6. **Cross-agent continuation**  
   Codex starts work; Grok continues with OM memory.

7. **Cross-machine cluster continuation**  
   Laptop observes decision; remote GCP node uses it.

8. **Namespace isolation**  
   Work project memory must not appear in personal project context.

9. **Secret canary**  
   Fake API key appears in transcript. It must not enter durable memory.

10. **Conflicting preferences**  
   User preference is refined over time. Latest valid preference wins.

11. **Recall required**  
   Startup pack omits deep detail by design; agent must call recall/search.

12. **Cluster redaction**  
   Node A redacts memory; Node B syncs and materializes without redacted content.

---

## 15. Suggested benchmark artifacts

Every run should create:

```text
runs/<run_id>/
  manifest.json
  config.toml
  results.jsonl
  scores.json
  report.md
  artifacts/
    memory/
      observations.md
      reflections.md
      profile.md
      active.md
      cluster/
    transcripts/
    agent_logs/
    repos/
    judge/
```

`manifest.json` should include:

```json
{
  "ombench_version": "0.1.0",
  "om_version": "0.6.3",
  "suite": "mini",
  "scenario_ids": ["..."],
  "memory_system": "om",
  "agent_harness": "codex",
  "models": {
    "observer": "...",
    "reflector": "...",
    "judge": "..."
  },
  "started_at": "...",
  "git_sha": "...",
  "environment": {
    "platform": "...",
    "python": "...",
    "network": "disabled"
  }
}
```

---

## 16. Release gates for OM using OMBench

Add OMBench gates to OM release process:

```text
pre-release smoke:
  ombench run --suite mini --memory om --agent generic

pre-minor release:
  ombench run --suite core-components --memory om
  ombench run --suite cluster-mini --memory om
  ombench run --suite safety-mini --memory om

pre-major release:
  full core suite
  model sweep
  cross-agent suite
  cluster suite
  regression against previous OM version
```

Regression thresholds:

```text
No safety hard failures.
No cluster security regression.
No >3 point drop in component F1 without explicit approval.
No >10% startup latency regression without explicit approval.
No >10% cost increase at same quality profile without explicit approval.
```

---

## 17. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Benchmark overfits to OM internals | Include baselines and memory adapter API. |
| Synthetic data feels unrealistic | Add real opt-in traces and generated repos with executable tests. |
| LLM judges are noisy | Prefer deterministic scorers; use blinded judges and consistency checks. |
| Agent harnesses are unstable | Provide generic/manual harness and separate harness score from memory score. |
| Proprietary agent automation breaks | Keep agent adapters optional and versioned. |
| Fine-tuning learns benchmark artifacts | Hidden generated split and scenario-family holdout. |
| Public leaderboard becomes misleading | Publish multiple tracks and confidence intervals. |
| Safety failures hidden by averages | Hard caps and separate safety track. |
| Too expensive to run | Mini/core/full tiers and local-model track. |

---

## 18. Recommended first Codex goal

Use this as the first long-running goal, not the whole benchmark vision:

```text
/goal Build the initial observational-memory-bench repository. Implement the ombench CLI, scenario/event/result schemas, isolated sandbox runner, OM CLI memory adapter, no-memory/full-context baselines, and a mini suite of 12 synthetic coding-memory scenarios covering observe, reflect, startup context, recall, cross-agent transfer, cluster sync, and safety. Add deterministic scorers for atomic fact precision/recall, hallucination, stale-state handling, retrieval Hit@k/MRR, startup budget/coverage, secret leakage, and cluster convergence. Produce JSONL results and Markdown reports with OM version, model profile, cost/latency placeholders, and scenario-level artifacts. Ensure all runs use temporary HOME/XDG dirs and never touch real user memory. Include docs explaining fairness rules, dataset schema, scoring, and how to run mini/core suites. Do not implement DSPy/GEPA or fine-tuning yet; create extension seams and docs for them. Run pytest and ruff.
```

---

## 19. Opinionated recommendations

1. **Make `OM-CodeWorld` the flagship.** LongMemEval comparability is useful, but OM’s real value is coding-agent continuity.
2. **Do not rely on LLM judges for core scoring.** Use an event graph and deterministic fact matching wherever possible.
3. **Benchmark startup context separately.** It is one of OM’s most important product surfaces and not well captured by existing memory QA benchmarks.
4. **Treat cluster sync as a first-class benchmark dimension.** This is now a differentiator and should be validated continuously.
5. **Move toward structured observations internally.** Plain Markdown can remain the user-facing artifact, but benchmark scoring will be far easier if observe/reflect can optionally emit structured JSON sidecars or records.
6. **Build the fine-tuning path from day one, but do not fine-tune first.** First collect gold data, teacher outputs, and failure corrections.
7. **Use DSPy/GEPA as an optimization harness, not as the benchmark itself.** The benchmark should remain framework-agnostic; GEPA should be one way to improve OM against it.
8. **Report Pareto frontiers, not just winners.** A cheap local observer that scores 90% of a frontier observer at 2% of the cost may be the most useful result.
9. **Publish a benchmark card.** Be explicit about what OMBench measures, what it does not, and how systems can game it.
10. **Use hidden generated scenarios for release validation.** Otherwise the benchmark will become a prompt-tuning target rather than a true measurement tool.

---

## 20. Appendix: minimum viable JSON schemas

### Scenario

```json
{
  "scenario_id": "string",
  "title": "string",
  "suite": "mini|core|hidden",
  "repo": {
    "template": "string",
    "initial_commit": "string"
  },
  "timeline": [],
  "gold_facts": [],
  "tasks": [],
  "safety_canaries": []
}
```

### Gold fact

```json
{
  "fact_id": "string",
  "kind": "project_convention|snapshot_state|user_preference|decision|failed_approach|secret|local_only",
  "text": "string",
  "subject": "string",
  "predicate": "string",
  "object": "string",
  "valid_from": "datetime",
  "valid_until": "datetime|null",
  "supersedes": ["fact_id"],
  "priority": "high|medium|low",
  "namespace": "string",
  "source_event_id": "string",
  "source_span": [0, 0]
}
```

### Result record

```json
{
  "run_id": "string",
  "scenario_id": "string",
  "task_id": "string",
  "memory_system": "string",
  "agent_harness": "string|null",
  "om_version": "string|null",
  "scores": {},
  "cost": {},
  "latency_ms": {},
  "artifacts": {}
}
```

---

## 21. Final target

The best version of `observational-memory-bench` becomes three things at once:

1. **A release gate for OM.**
2. **A credible public benchmark for agentic memory systems.**
3. **A training and optimization pipeline for cheaper, faster, local observer/reflector models.**

That combination is what can make OM competitive with other memory frameworks while preserving its own identity: local-first, inspectable, multi-agent, cross-machine memory for real work.
