import json
import os

# interne Klasse für Speicherung
class _DataStore:
    def __init__(self, filename="data.json"):
        self.filename = filename
        if os.path.exists(self.filename):
            with open(self.filename, "r") as f:
                try:
                    self.data = json.load(f)
                except json.JSONDecodeError:
                    self.data = []
        else:
            self.data = []

    def save(self, **kwargs):
        self.data.append(kwargs)
        with open(self.filename, "w") as f:
            json.dump(self.data, f, indent=4)

    def load_all(self):
        return self.data

# Ein globales Objekt für direkten Zugriff
_store = _DataStore()

# Funktionen, die direkt aufgerufen werden können
def save(**kwargs):
    """Speichert beliebige Daten direkt."""
    _store.save(**kwargs)

def load_all():
    """Lädt alle gespeicherten Daten."""
    return _store.load_all()