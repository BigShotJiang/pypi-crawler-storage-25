from pathlib import Path

from single_source import get_version

from . import usb_devices
from .display_escpos_driver import DriverDisplayEscPos
from .routes_odoo import driver_routes_odoo
from .routes_website import driver_routes_website

__version__ = get_version(__name__, Path(__file__).parent.parent)
__package_name__ = __name__

DRIVER_FUNCTION = "display"
PLUGIN_NAME = "display_escpos"
DRIVER_CLASS = DriverDisplayEscPos
USB_DEVICES = usb_devices.USB_DEVICES
DRIVER_ROUTES_GROUPS = [driver_routes_odoo, driver_routes_website]
