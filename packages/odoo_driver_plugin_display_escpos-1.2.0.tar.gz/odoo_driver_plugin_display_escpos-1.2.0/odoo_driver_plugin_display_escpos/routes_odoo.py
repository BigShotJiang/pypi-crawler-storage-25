import simplejson
from flask import Blueprint, jsonify, request
from loguru import logger
from odoo_driver.tools.tools_interface import interface

driver_routes_odoo = Blueprint(
    "route_display_escpos_odoo", __name__, template_folder="templates"
)


@driver_routes_odoo.route("/hw_proxy/display_show", methods=["POST", "PUT"])
@logger.catch
def display_show():
    driver = interface.drivers.get("display")
    data = request.json.get("params", {}).get("data", {})
    interface.log_data(data, "display", "DEBUG")

    if type(data) is str:
        data = simplejson.loads(data)

    driver.add_task(data)
    return jsonify(jsonrpc="2.0", result=True)
