USB_DEVICES = {
    (0x0416, 0xF011): {"name": "Oxhoo - AF240", "image": "oxhoo__af240.png"},
    (0x0416, 0xF012): {"name": "Aures - OCD 300", "image": "aures__ocd_300.png"},
}
