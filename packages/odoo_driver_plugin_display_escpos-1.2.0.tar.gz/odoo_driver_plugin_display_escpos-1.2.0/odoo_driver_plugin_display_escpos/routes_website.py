from flask import Blueprint, jsonify, render_template
from loguru import logger
from odoo_driver.tools.tools_interface import interface

driver_routes_website = Blueprint(
    "route_display_escpos_website", __name__, template_folder="templates"
)


@driver_routes_website.route("/driver/display_escpos.html")
@logger.catch
def driver_display_escpos():
    driver = interface.drivers.get("display")
    return render_template("driver_display_escpos.html.jinja", driver=driver)


@driver_routes_website.route("/display_escpos/configure", methods=["POST", "PUT"])
@logger.catch
def display_escpos_configure():
    driver = interface.drivers.get("display")
    driver.configure()

    return jsonify(jsonrpc="2.0", result=True)
