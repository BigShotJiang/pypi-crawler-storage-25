# Odoo Driver Plugin - Display ESC/POS

![License: AGPL v3](https://img.shields.io/badge/License-AGPL_v3-blue.svg)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/odoo-driver-plugin-display-escpos)
![PyPI - Downloads](https://img.shields.io/pypi/dm/odoo-driver-plugin-display-escpos)
![GitLab last commit](https://img.shields.io/gitlab/last-commit/81585306)
![GitLab stars](https://img.shields.io/gitlab/stars/81585306?style=social)

This project provide a plugin for ``odoo-driver``
to communicate with LCD Display with ECS/POS protocol.

This plugin requires the following odoo module : [`pos_odoo_driver_display`](https://github.com/grap/odoo-addons-pos)

To install this plugin, refer to the main project page : https://gitlab.com/grap-rhone-alpes/odoo-driver/.

For developpers, refer to this page : https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-printer-escpos/-/blob/main/DEVELOP.md.

## Table of contents

1. [Compatible Devices](#compatible-devices)
2. [Credits](#credits)
3. [Develop](#develop)


<a name="compatible-devices"></a>

## Compatible Devices

<table style="width: 100%;">
    <tbody>
        <tr>
            <td>Aures - OCD 300</td>
            <td>
              <img src="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-display-escpos/-/raw/main/odoo_driver_plugin_display_escpos/static/img/aures__ocd_300.png" width="200" height="200" />
            </td>
        </tr>
        <tr>
            <td>Oxhoo - AF 240</td>
            <td>
              <img src="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-display-escpos/-/raw/main/odoo_driver_plugin_display_escpos/static/img/oxhoo__af240.png" width="200" height="200" />
            </td>
        </tr>
    </tbody>
</table>

<a name="credits"></a>

## Credits

### Authors

* GRAP <https://www.grap.coop>

### Contributors

* Sylvain LE GAL <https://www.grap.coop/>

### Extra authorship

Part of the code in this project comes from the following projects, including:

* [Pywebdriver](https://github.com/pywebdriver/pywebdriver) (AGPL-3.0).

* [pyposdisplay](https://github.com/akretion/pyposdisplay) (AGPL-3.0).

### Images

* [LCD Customer Display Icon](https://www.flaticon.com/fr/icone-gratuite/lcd_9622586), created by Iconic Panda (Flaticon).

<a name="develop"></a>

## Develop

### Local Installation

To install the odoo-driver library and some plugins, you can refer to this documentation:

https://gitlab.com/grap-rhone-alpes/odoo-driver-env

### Documentation

**Display Protocol**

* https://aures-support.com/DATA/Doc/VFD/OCD300_Manuel_Utilisateur_V1.0.pdf
  (or [permalink](https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-display-escpos/-/raw/main/doc/Aures-OCD300_Manuel-Utilisateur.pdf))
