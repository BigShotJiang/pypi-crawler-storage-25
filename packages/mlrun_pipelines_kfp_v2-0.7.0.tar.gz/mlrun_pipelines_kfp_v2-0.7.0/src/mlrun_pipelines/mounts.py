# Copyright 2024 Iguazio
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from mlrun.runtimes.mounts import (
    auto_mount,  # noqa: F401
    mount_configmap,  # noqa: F401
    mount_hostpath,  # noqa: F401
    mount_pvc,  # noqa: F401
    mount_s3,  # noqa: F401
    mount_secret,  # noqa: F401
    mount_v3io,  # noqa: F401
    set_env_variables,  # noqa: F401
    v3io_cred,  # noqa: F401
)
