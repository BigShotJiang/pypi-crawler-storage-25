# Copyright 2024 Iguazio
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import typing


def new_pipe_metadata(
    artifact_path: str | None = None,
    cleanup_ttl: int | None = None,
    op_transformers: list[typing.Callable] | None = None,
):
    # This function is not required on a KFP 2.0 setup
    # The definition is here for import compatibility reasons
    raise NotImplementedError
