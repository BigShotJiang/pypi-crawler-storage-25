"""
Unified CLI for QRStream.

Usage:
    qrstream -V | --version
    qrstream encode <file> [-o output.mp4] [--display] [--overhead 2.0]
                          [--fps 10] [--output-mode MODE]
    qrstream decode <video> -o output_file [-s sample_rate]
                          [--output-mode MODE]

``--output-mode`` selects how progress/status is rendered:

* ``auto``        — Rich interactive on TTY, ``log`` otherwise (default).
* ``interactive`` — Force Rich animated UI (thin bars + file block map).
* ``log``         — Append-only ``key=value`` lines; CI / ``tee`` safe.
* ``quiet``       — Only errors and the final success line.
* ``verbose``     — Verbose diagnostic output (Rich on TTY, log-verbose
                    otherwise).

The legacy ``-v / --verbose`` flag is accepted as a hidden alias for
``--output-mode verbose`` to keep existing scripts working.
"""

import sys
import os
import argparse

from .__init__ import __version__
from .ui import OutputMode, resolve_output_mode


def cmd_colors():
    """Display all colour palettes used by the qrstream UI."""
    try:
        from rich.console import Console
        from rich.text import Text
    except ImportError:
        print("Error: 'rich' is required for colour display. "
              "Install with: pip install rich")
        sys.exit(1)

    from .ui import (
        _DENSITY_CHAR_AND_STYLE,
        _density_cell,
        _density_cell_truecolor,
        _detect_rate_style,
        _detect_rate_markup,
        _DET_GRADIENT_ANCHORS,
    )

    console = Console(stderr=False, highlight=False, force_terminal=True)
    truecolor = (console.color_system == "truecolor")

    console.print(
        f"[bold]qrstream {__version__}[/bold] — UI colour palette\n"
    )
    console.print(f"  Terminal colour system: [bold]{console.color_system}[/bold]\n")

    # ── Detect-rate gradient ──────────────────────────────────────
    console.print("[bold underline]Detect-rate gradient[/bold underline]")
    console.print(
        "  Shown in the Scan/Recover stats column during decode.\n"
        "  Anchors: <50% red → 60% orange → 70% yellow → 80%+ green\n"
    )

    # Show a continuous band — 50 cells mapping 0%–100%.
    bar_width = 50
    band = Text("  ")
    for i in range(bar_width):
        hit = i / (bar_width - 1)
        style = _detect_rate_style(hit, truecolor=truecolor)
        band.append("█", style=style)
    console.print(band)
    # Scale labels aligned to the bar (2-space indent + positions).
    # Each cell = 2% → 50%=cell25, 60%=cell30, 70%=cell35, 80%=cell40
    scale = Text("  ")
    markers = [(0, "0%"), (25, "50%"), (30, "60%"), (35, "70%"),
               (40, "80%"), (49, "100%")]
    pos = 0
    for col, label in markers:
        if col > pos:
            scale.append(" " * (col - pos))
        scale.append(label)
        pos = col + len(label)
    console.print(scale)
    console.print()

    # Show discrete sample values
    console.print("  Sample values:")
    samples = [0, 10, 20, 30, 40, 50, 55, 60, 65, 70, 75, 80, 90, 100]
    line = Text("  ")
    for pct in samples:
        hit = pct / 100.0
        style = _detect_rate_style(hit, truecolor=truecolor)
        line.append(f" {pct:>3d}%", style=style)
    console.print(line)
    console.print()

    # Fallback (discrete) mode comparison
    if truecolor:
        console.print("  [dim]Discrete fallback (non-truecolor terminals):[/dim]")
        line_fb = Text("  ")
        for pct in samples:
            hit = pct / 100.0
            style = _detect_rate_style(hit, truecolor=False)
            line_fb.append(f" {pct:>3d}%", style=style)
        console.print(line_fb)
        console.print()

    # ── Block-map (File row) ──────────────────────────────────────
    console.print("[bold underline]Block-map density[/bold underline]")
    console.print(
        "  Shown in the File row during decode — each cell represents\n"
        "  a region of the output file coloured by recovery density.\n"
        "  Gamma curve (0.55) stretches early colours for visibility.\n"
    )

    # Show a simulated block-map bar filling from 0% to 100%
    console.print("  Truecolor gradient (0% → 100%):")
    bar = Text("  ")
    for i in range(50):
        density = i / 49.0
        ch, st = _density_cell_truecolor(density)
        bar.append(ch, style=st)
    console.print(bar)
    console.print()

    # Discrete fallback
    console.print("  [dim]Discrete fallback (non-truecolor terminals):[/dim]")
    bar_fb = Text("  ")
    for i in range(50):
        density = i / 49.0
        ch, st = _density_cell(density)
        bar_fb.append(ch, style=st)
    console.print(bar_fb)
    console.print()

    # Tier table
    console.print("  Discrete tiers:")
    console.print("  Density    Glyph   Style")
    prev_thresh = 0.0
    for thresh, char, style_name in _DENSITY_CHAR_AND_STYLE:
        label = f"  {prev_thresh*100:>5.1f}%–{thresh*100:>5.1f}%"
        sample = Text(f"   {char} {char} {char}", style=style_name)
        line = Text(f"{label}  ")
        line.append_text(sample)
        line.append(f"   {style_name}")
        console.print(line)
        prev_thresh = thresh
    console.print()

    # ── Phase label colours ───────────────────────────────────────
    console.print("[bold underline]Phase labels[/bold underline]\n")
    console.print("  [bold cyan]Probe[/bold cyan]   — probing video for QR detection rate")
    console.print("  [bold cyan]Scan[/bold cyan]    — main decode pass")
    console.print("  [bold yellow]Recover[/bold yellow] — targeted recovery of missing blocks")
    console.print("  [bold cyan]File[/bold cyan]    — block-map / output file progress")
    console.print("  [bold cyan]Plan[/bold cyan]    — decode plan parameters")
    console.print()

    # ── Status indicators ─────────────────────────────────────────
    console.print("[bold underline]Status indicators[/bold underline]\n")
    console.print("  [green]✓[/green] Success     [yellow]⚠[/yellow] Warning     [bold red]✗[/bold red] Error")
    console.print()


# Minimum overhead the default LT codec (SplitMix64 PRNG mixer,
# qrstream ≥ 0.8) needs to converge on sequential seeds across all
# K we've benchmarked (328..4096).  The empirical worst case is
# K=328 at 1.19×; we round up to 1.20× as the hard floor and
# recommend ≥1.50× for real captures where frame loss / detector
# misses eat into the margin.
#
# Anything below the floor indicates either a misunderstanding of
# the codec (LT can't converge below its PRNG-dependent threshold,
# period) or a test/benchmark use case — those can bypass via the
# LTEncoder API directly.
_MIN_OVERHEAD = 1.20
_RECOMMENDED_OVERHEAD = 1.50


def _resolve_mode(args) -> OutputMode:
    """Reconcile legacy ``-v`` with the new ``--output-mode`` flag.

    ``-v`` is kept as a hidden alias that upgrades ``auto`` to
    ``verbose``; users who explicitly pass ``--output-mode`` get
    their choice honoured verbatim.
    """
    raw = getattr(args, 'output_mode', None) or 'auto'
    mode = OutputMode(raw)
    if getattr(args, 'verbose', False) and mode is OutputMode.AUTO:
        return OutputMode.VERBOSE
    return mode


def _check_output_path_writable(output: str) -> str | None:
    """Validate an ``-o / --output`` path *before* the heavy job.

    encode / decode are long-running (often minutes for real
    videos).  If the destination turns out to be unreachable —
    parent directory missing, not writable, existing file
    read-only — the user should hear about it in the first second,
    not after they've waited through a probe + scan.

    Contract:
    * Parent directory must exist.  We deliberately do **not**
      ``mkdir -p`` here: a typo like ``/tmp/typo/out.bin``
      silently creating ``/tmp/typo/`` is worse than failing loud.
    * Parent directory must be writable by the current process.
    * If the output path already exists, it must be a regular
      file (not a directory) and writable — so we can truncate
      and overwrite it.

    Returns ``None`` on success or a user-facing error message on
    failure.  The caller is responsible for printing the message
    and exiting with the appropriate status code.
    """
    if not output:
        return "output path is empty"

    # Resolve the parent directory.  An empty ``dirname`` (e.g.
    # plain ``out.bin``) means "current working directory".
    parent = os.path.dirname(os.path.abspath(output))
    if not os.path.isdir(parent):
        return (
            f"output directory does not exist: {parent}\n"
            f"Create it first (e.g. `mkdir -p {parent}`) or pick "
            f"a different path with -o."
        )
    if not os.access(parent, os.W_OK):
        return (
            f"output directory is not writable: {parent}\n"
            f"Check permissions or pick a different path with -o."
        )

    # If the file already exists, make sure we'll actually be
    # able to truncate and overwrite it.
    if os.path.exists(output):
        if os.path.isdir(output):
            return (
                f"output path is an existing directory: {output}\n"
                f"Specify a file path with -o, not a directory."
            )
        if not os.access(output, os.W_OK):
            return (
                f"output file exists but is not writable: {output}\n"
                f"Remove it or adjust its permissions first."
            )
    return None


def _build_reporter(args) -> tuple[OutputMode, object]:
    """Resolve CLI output mode and build the matching reporter."""
    mode = _resolve_mode(args)
    try:
        reporter = resolve_output_mode(
            mode,
            explicit=(getattr(args, 'output_mode', 'auto') != 'auto'),
        )
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(2)
    return mode, reporter


def _close_reporter(reporter) -> None:
    try:
        reporter.close()
    except Exception:
        pass


def cmd_encode(args):
    """Handle the 'encode' subcommand."""
    from .encoder import encode_to_display, encode_to_video

    if not os.path.exists(args.file):
        print(f"Error: File not found: {args.file}")
        sys.exit(1)

    output = args.output
    output_requested = output is not None
    display = bool(getattr(args, 'display', False)) or not output_requested

    if output_requested:
        # Fail fast on unreachable output paths so the user doesn't
        # wait through a minutes-long encode before learning the
        # destination directory doesn't exist or isn't writable.
        err = _check_output_path_writable(output)
        if err is not None:
            print(f"Error: {err}", file=sys.stderr)
            sys.exit(1)

    if args.overhead < _MIN_OVERHEAD:
        print(
            f"Error: --overhead {args.overhead} is below the LT codec's "
            f"convergence floor ({_MIN_OVERHEAD}×). Decoding would fail "
            f"even on a perfect capture. Use --overhead {_RECOMMENDED_OVERHEAD} "
            f"or higher for reliable real-world recording."
        )
        sys.exit(2)
    if args.overhead < _RECOMMENDED_OVERHEAD:
        print(
            f"Warning: --overhead {args.overhead} is near the LT convergence "
            f"floor. Recommended: ≥{_RECOMMENDED_OVERHEAD} so camera frame "
            f"loss and QR detector misses don't push decoding below the "
            f"threshold."
        )

    if output_requested and os.path.abspath(args.file) == os.path.abspath(output):
        print(
            f"Error: output path is the same as the input file '{args.file}'.\n"
            f"Specify a different path with -o."
        )
        sys.exit(1)

    alphanumeric_qr = (args.qr_mode == 'alphanumeric')

    mode, reporter = _build_reporter(args)
    verbose = mode is OutputMode.VERBOSE

    try:
        common_kwargs = dict(
            input_path=args.file,
            overhead=args.overhead,
            fps=args.fps,
            ec_level=args.ec_level,
            qr_version=args.qr_version,
            border=args.border,
            lead_in_seconds=args.lead_in_seconds,
            compress=not args.no_compress,
            verbose=verbose,
            workers=args.workers,
            use_legacy_qr=args.legacy_qr,
            alphanumeric_qr=alphanumeric_qr,
            force_compress=args.force_compress,
            auto_mask=args.auto_mask,
            reporter=reporter,
        )
        if display:
            encode_to_display(
                output_path=output if output_requested else None,
                codec=args.codec,
                report_display_done=not output_requested,
                **common_kwargs,
            )
        else:
            encode_to_video(
                output_path=output,
                codec=args.codec,
                **common_kwargs,
            )
    except ImportError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(3)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        # Remove partial/corrupt output file on interrupt.
        try:
            if output and os.path.exists(output):
                os.unlink(output)
        except OSError:
            pass
        raise
    finally:
        _close_reporter(reporter)


def cmd_decode(args):
    """Handle the 'decode' subcommand."""
    from .decoder import extract_qr_from_video, decode_blocks_to_file

    if not os.path.exists(args.video):
        print(f"Error: File not found: {args.video}")
        sys.exit(1)

    # Fail fast on unreachable output paths so users don't wait
    # through a probe + scan before finding out the destination
    # directory doesn't exist or isn't writable.
    err = _check_output_path_writable(args.output)
    if err is not None:
        print(f"Error: {err}", file=sys.stderr)
        sys.exit(1)

    mode, reporter = _build_reporter(args)
    verbose = mode is OutputMode.VERBOSE

    output_path = args.output
    try:
        blocks, completed_decoder = extract_qr_from_video(
            args.video, args.sample_rate, verbose, args.workers,
            reporter=reporter,
            return_decoder=True,
        )

        if not blocks:
            print("No QR codes detected. Check that the video clearly shows QR codes.")
            sys.exit(1)

        written = decode_blocks_to_file(
            blocks, output_path, verbose, reporter=reporter,
            decoder=completed_decoder,
        )

        if written is None:
            sys.exit(1)
    except KeyboardInterrupt:
        # Remove partial output file on interrupt.
        try:
            if os.path.exists(output_path):
                os.unlink(output_path)
        except OSError:
            pass
        raise
    finally:
        _close_reporter(reporter)


def _add_output_mode_group(sub: argparse.ArgumentParser) -> None:
    """Attach the shared ``--output-mode`` option plus hidden ``-v``."""
    sub.add_argument(
        '--output-mode',
        dest='output_mode',
        choices=[m.value for m in OutputMode],
        default=OutputMode.AUTO.value,
        help='Control progress/status rendering. '
             '"auto" picks Rich interactive on TTY, "log" otherwise. '
             '"log" emits append-only key=value lines for CI. '
             '"quiet" prints only errors and the final path. '
             '"verbose" enables full diagnostic output.',
    )
    # Legacy alias kept hidden: ``-v`` → upgrade ``auto`` to ``verbose``.
    sub.add_argument('-v', '--verbose', action='store_true',
                     help=argparse.SUPPRESS)


def build_parser(prog: str = 'qrstream') -> argparse.ArgumentParser:
    """Build the top-level CLI parser."""
    parser = argparse.ArgumentParser(
        prog=prog,
        description='QRStream: Encode and decode files via QR code video streams')
    parser.add_argument('-V', '--version', action='version',
                        version=f'%(prog)s {__version__}')

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # ── encode ────────────────────────────────────────────────────
    enc = subparsers.add_parser(
        'encode', help='Encode a file into a QR code video')
    enc.add_argument('file', help='Path to the input file')
    enc.add_argument('-o', '--output', required=False,
                     help='Output video path (e.g. output.mp4). If omitted, '
                          'encode displays frames on screen.')
    enc.add_argument('--display', action='store_true',
                     help='Display encoded QR frames in the built-in GUI player. '
                          'When used with -o, the video is saved after display '
                          'rendering completes if needed.')
    enc.add_argument('--overhead', type=float, default=2.0,
                     help=f'Ratio of encoded blocks to source blocks '
                          f'(default: 2.0, minimum: {_MIN_OVERHEAD}, '
                          f'recommended: ≥{_RECOMMENDED_OVERHEAD})')
    enc.add_argument('--fps', type=int, default=10,
                     help='Frames per second in output video (default: 10)')
    # TODO(v0.10.0): remove ``--ec-level`` entirely.  QR-level error
    # correction is redundant in qrstream's pipeline because LT fountain
    # ``--overhead`` already handles frame-level loss (which is the
    # dominant failure mode on phone captures), and WeChatQRCode either
    # decodes a QR into its payload or fails outright — EC rarely
    # rescues a borderline frame that the detector would otherwise
    # return ``None`` for.  The option is kept hidden in v0.8/0.9 so
    # scripts built around the previous CLI continue to work, but users
    # should stop setting it.  See ``encoder.encode_to_video`` for the
    # corresponding API-level parameter which is retained for the same
    # deprecation window.
    enc.add_argument('--ec-level', type=int, default=1, choices=[0, 1, 2, 3],
                     help=argparse.SUPPRESS)
    enc.add_argument('--qr-version', type=int, default=25,
                     choices=range(1, 41), metavar='N',
                     help='QR code version 1-40, controls density (default: 25)')
    enc.add_argument('--border', type=float, default=None,
                     help='Quiet-zone width as a percentage of QR content width (default: standard 4-module quiet zone; use 0 to disable)')
    enc.add_argument('--lead-in-seconds', type=float, default=0.0,
                     dest='lead_in_seconds',
                     help='White lead-in duration before the first QR frame')
    enc.add_argument('--no-compress', action='store_true',
                     help='Disable zlib compression')
    enc.add_argument('--force-compress', action='store_true',
                     help='Force compression even for large V3 inputs (uses more memory)')
    enc.add_argument('--legacy-qr', action='store_true',
                     help='Accepted for backward compatibility; ignored.')
    enc.add_argument('--qr-mode', choices=['alphanumeric', 'base64'],
                     default='alphanumeric',
                     help='QR payload encoding: alphanumeric (default, base45 '
                          'into QR alphanumeric mode, ~29%% more capacity) '
                          'or base64 (standard, QR byte mode).')
    enc.add_argument('--codec', choices=['h264', 'mp4v', 'mjpeg'], default='h264',
                     help='Video codec: h264 (default), mp4v, or mjpeg (faster, larger)')
    enc.add_argument('-w', '--workers', type=int, default=None,
                     help='Parallel workers for QR generation (default: 1; higher values may not improve performance)')
    enc.add_argument('--auto-mask', action='store_true',
                     help='Accepted for backward compatibility; ignored. '
                          'zxing-cpp always evaluates all 8 ISO 18004 mask '
                          'patterns in native C++ at negligible cost.')
    _add_output_mode_group(enc)

    # ── decode ────────────────────────────────────────────────────
    dec = subparsers.add_parser(
        'decode', help='Decode a QR code video back to the original file')
    dec.add_argument('video', help='Path to the video file (MOV, MP4, etc.)')
    dec.add_argument('-o', '--output', required=True,
                     help='Output file path')
    dec.add_argument('-s', '--sample-rate', type=int, default=0,
                     help='Process every Nth frame (default: 0=auto-detect)')
    dec.add_argument('-w', '--workers', type=int, default=None,
                     help='Parallel workers (default: all CPU cores)')
    _add_output_mode_group(dec)

    # ── colors ───────────────────────────────────────────────────
    subparsers.add_parser(
        'colors',
        help='Display the colour palette used by the UI '
             '(detect-rate gradient, block-map, etc.)')

    return parser


def main(argv: list[str] | None = None):
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == 'encode':
            cmd_encode(args)
        elif args.command == 'decode':
            cmd_decode(args)
        elif args.command == 'colors':
            cmd_colors()
        else:
            parser.print_help()
            sys.exit(1)
    except KeyboardInterrupt:
        # Clean single-line message instead of a Python traceback.
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(130)


if __name__ == '__main__':
    main()
