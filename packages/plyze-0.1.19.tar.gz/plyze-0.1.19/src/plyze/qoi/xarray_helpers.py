import polars as pl
from datetime import datetime
import xarray as xr
import re
from plyze.utils import XArrayNames


def find_drn_in_name(space_name: str):
    pattern = re.compile("(NORTH)|(SOUTH)|(EAST)|(WEST)")
    res = pattern.search(space_name.upper())
    if res:
        return res.group()
    else:
        raise ValueError(
            f"External node name {space_name} does not contain a direction!"
        )


def get_data_by_space_name(arr: xr.DataArray, name: str):
    try:
        return arr.sel(space_names=name.upper())
    except KeyError:
        raise Exception(f"Could not find data for {name} in {arr}")


def select_time(arr: xr.DataArray, dt: datetime | list[datetime]):
    assert XArrayNames.DATETIME in arr.dims
    return arr.sel(datetimes=dt)


def convert_xarray_to_polars(data: xr.DataArray | xr.Dataset, name=""):
    if name:
        data.name = name
    return pl.from_pandas(data.to_dataframe(), include_index=True).with_columns(
        pl.col(XArrayNames.DATETIME).dt.cast_time_unit("us")
    )


def get_data(arr: xr.DataArray):
    return arr.to_dict()["data"]


def get_single_value(arr: xr.DataArray):
    assert arr.size == 1
    return float(arr.data)


def calc_median(arr: xr.DataArray):
    return arr.median()
