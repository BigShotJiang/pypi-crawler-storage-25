import os


def get_execution_folder_path() -> str | None:
    """Reads the agent's executing folder path from the runtime environment."""
    return os.environ.get("UIPATH_FOLDER_PATH")


def get_default_timeout() -> float:
    return float(os.getenv("UIPATH_TIMEOUT_SECONDS", "895"))
