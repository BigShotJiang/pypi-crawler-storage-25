// test_201_shuttle_rack_2453.rs
//
// 201 — Shuttle rack model 2453 vs SkyCiv comparison
//
// Tests the shuttle rack model (config 2453) against SkyCiv reference values.
// Stiffness curve on Rz depends on Vy (vertical reaction).
//
// Model characteristics:
//   - 27 member sets, ~196 members (uprights, bracing, beams, consoles, rails)
//   - 8 base support nodes with StiffnessCurve on rotation Z (depends on Vy)
//   - Stiffness range: 1,000 → 721,960,000 Nmm/rad (depends on Vy)
//   - P-Delta nonlinear, Newton-Raphson, tolerance 1e-6, max 30 iterations
//   - 25 load combinations (ULS/SLS)

use fers_calculations::analysis::calculate_from_json_internal_with_tier;
use fers_calculations::limits::LicenseTier;

fn load_variant(filename: &str) -> String {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join(filename);
    std::fs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("Failed to read {}: {e}", path.display()))
}

/// Run a variant and return (ok_count, fail_count, failures, elapsed_secs)
fn run_variant(json: &str) -> (u32, u32, Vec<String>, f64) {
    let t0 = std::time::Instant::now();
    let result = calculate_from_json_internal_with_tier(json, LicenseTier::Premium);
    let elapsed = t0.elapsed().as_secs_f64();

    let res_json = match &result {
        Ok(res_json) => res_json.clone(),
        Err(e) => {
            return (0, 1, vec![format!("Top-level error: {e}")], elapsed);
        }
    };

    let v: serde_json::Value = serde_json::from_str(&res_json).unwrap();
    let mut n_ok = 0u32;
    let mut n_fail = 0u32;
    let mut failures: Vec<String> = Vec::new();

    if let Some(cases) = v["results"]["loadcases"].as_object() {
        for (name, data) in cases {
            if let Some(err) = data.get("error") {
                n_fail += 1;
                failures.push(format!("LC '{}': {}", name, err));
            } else {
                n_ok += 1;
            }
        }
    }
    if let Some(combos) = v["results"]["loadcombinations"].as_object() {
        for (name, data) in combos {
            if let Some(err) = data.get("error") {
                n_fail += 1;
                failures.push(format!("Combo '{}': {}", name, err));
            } else {
                n_ok += 1;
            }
        }
    }

    (n_ok, n_fail, failures, elapsed)
}

/// Run the full model JSON and return parsed result JSON.
fn run_full_model(json: &str) -> serde_json::Value {
    let result = calculate_from_json_internal_with_tier(json, LicenseTier::Premium);
    let res_json = result.expect("Solver should succeed");
    serde_json::from_str(&res_json).expect("Valid JSON output")
}

/// Check vertical reaction (Fy) at support nodes.
/// `expected`: (node_id_str, expected_fy) pairs in N.
fn check_reactions_fy(
    result: &serde_json::Value,
    lc_name: &str,
    expected: &[(&str, f64)],
    tol_pct: f64,
    abs_tol: f64,
) -> Vec<String> {
    let reactions = &result["reaction_nodes"];
    let mut failures = Vec::new();

    for &(nid, exp_fy) in expected {
        let rn = &reactions[nid];
        if rn.is_null() {
            failures.push(format!("{lc_name} node {nid}: NOT FOUND in reactions"));
            continue;
        }
        let fers_fy = rn["nodal_forces"]["fy"].as_f64().unwrap_or(0.0);
        if fers_fy.abs() < abs_tol && exp_fy.abs() < abs_tol {
            continue;
        }
        let abs_diff = (fers_fy - exp_fy).abs();
        if abs_diff < abs_tol {
            continue;
        }
        let denom = exp_fy.abs().max(1.0);
        let pct = abs_diff / denom * 100.0;
        if pct > tol_pct {
            failures.push(format!(
                "{lc_name} node {nid} Fy: FERS={fers_fy:.2} SC={exp_fy:.2} Δ={pct:.1}%"
            ));
        }
    }
    failures
}

// ─────────────────────────────────────────────────────────────────────────────
// 201a — All 25 combos converge (no solver errors)
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_201a_all_combos_converge() {
    let json = load_variant("shuttle_rack_2453.json");
    let (n_ok, n_fail, failures, elapsed) = run_variant(&json);
    eprintln!("201a (all 25 combos): {n_ok} OK, {n_fail} FAIL in {elapsed:.2}s");
    for f in &failures {
        eprintln!("  - {f}");
    }
    assert_eq!(n_fail, 0, "Failures: {failures:?}");
}

// ─────────────────────────────────────────────────────────────────────────────
// 201b — Dead_load_shuttle reactions match SkyCiv
//        Rail members 92/93 loaded with 0.981 N/mm downward.
//        Tests force distribution through rail→console→beam→upright path.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_201b_dead_load_shuttle_reactions() {
    let json = load_variant("shuttle_rack_2453.json");
    let result = run_full_model(&json);
    let lc = &result["results"]["loadcases"]["Dead_load_shuttle"];
    assert!(!lc.is_null(), "Dead_load_shuttle not found in results");

    // SkyCiv reference reactions (Fy in N) — updated 2026-04-07
    let expected: &[(&str, f64)] = &[
        ("15",   442.417),
        ("23",   704.761),
        ("53",   -22.028),
        ("61",   -46.061),
        ("115",  442.417),
        ("123",  704.761),
        ("153",  -22.028),
        ("161",  -46.061),
    ];

    let failures = check_reactions_fy(lc, "Dead_load_shuttle", expected, 10.0, 20.0);
    for f in &failures {
        eprintln!("  {f}");
    }
    assert!(failures.is_empty(), "Dead_load_shuttle reaction mismatches:\n{}", failures.join("\n"));
}

// ─────────────────────────────────────────────────────────────────────────────
// 201c — Product_load reactions match SkyCiv
//        Distributed load on all 6 rail spans.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_201c_product_load_reactions() {
    let json = load_variant("shuttle_rack_2453.json");
    let result = run_full_model(&json);
    let lc = &result["results"]["loadcases"]["Product_load"];
    assert!(!lc.is_null(), "Product_load not found in results");

    // SkyCiv reference reactions (Fy in N) — updated 2026-04-07
    let expected: &[(&str, f64)] = &[
        ("15",  1180.563),
        ("23",  3182.406),
        ("53",  3184.986),
        ("61",  1179.866),
        ("115", 1180.563),
        ("123", 3182.406),
        ("153", 3184.986),
        ("161", 1179.866),
    ];

    let failures = check_reactions_fy(lc, "Product_load", expected, 10.0, 20.0);
    for f in &failures {
        eprintln!("  {f}");
    }
    assert!(failures.is_empty(), "Product_load reaction mismatches:\n{}", failures.join("\n"));
}

// ─────────────────────────────────────────────────────────────────────────────
// 201d — Dead_load_rack reactions match SkyCiv (self-weight)
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_201d_dead_load_rack_reactions() {
    let json = load_variant("shuttle_rack_2453.json");
    let result = run_full_model(&json);
    let lc = &result["results"]["loadcases"]["Dead_load_rack"];
    assert!(!lc.is_null(), "Dead_load_rack not found in results");

    // SkyCiv reference reactions (Fy in N) — updated 2026-04-07
    let expected: &[(&str, f64)] = &[
        ("15",   182.494),
        ("23",   261.070),
        ("53",   261.108),
        ("61",   182.484),
        ("115",  182.494),
        ("123",  261.070),
        ("153",  261.108),
        ("161",  182.484),
    ];

    let failures = check_reactions_fy(lc, "Dead_load_rack", expected, 10.0, 20.0);
    for f in &failures {
        eprintln!("  {f}");
    }
    assert!(failures.is_empty(), "Dead_load_rack reaction mismatches:\n{}", failures.join("\n"));
}

// ─────────────────────────────────────────────────────────────────────────────
// 201e — Empty load case (LC 11 / Pattern_load) doesn't crash the solver
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_201e_empty_lc_converges() {
    let json = load_variant("shuttle_rack_2453.json");
    let (_, n_fail, failures, _) = run_variant(&json);
    // All 25 combos + all LCs should converge (including the empty one)
    assert_eq!(n_fail, 0, "Expected zero failures: {failures:?}");
}

// ─────────────────────────────────────────────────────────────────────────────
// 201f/g — Removed: rot90 variant (experimental, fixture deleted)
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// 201h — Removed: MPC rigid strategy (crashes with sparse LU panic)
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// 201i — Removed: Linear analysis variant (blocked by StiffnessCurve requirement)
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// 201j — Compare variants: noSC vs SC to verify principal_axis_angle effect
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_201j_variant_comparison() {
    let variants: &[(&str, &str)] = &[
        ("PrincipalNoSC", "shuttle_rack_2453_nosc.json"),
        ("Principal+SC ", "shuttle_rack_2453.json"),
    ];
    let nodes = ["15", "23", "53", "61", "115", "123", "153", "161"];
    let skyciv: &[f64] = &[442.417, 704.761, -22.028, -46.061, 442.417, 704.761, -22.028, -46.061];

    for (vname, file) in variants {
        let json = load_variant(file);
        let result = run_full_model(&json);
        let lc = &result["results"]["loadcases"]["Dead_load_shuttle"];
        assert!(!lc.is_null());
        let reactions = &lc["reaction_nodes"];

        eprintln!("\n{vname}:");
        for (i, &nid) in nodes.iter().enumerate() {
            let fers = reactions[nid]["nodal_forces"]["fy"].as_f64().unwrap_or(f64::NAN);
            let pct = if skyciv[i].abs() > 1.0 { (fers - skyciv[i]) / skyciv[i].abs() * 100.0 } else { fers - skyciv[i] };
            eprintln!("  Node {nid}: FERS={fers:>8.1} SC={:>8.1} Δ={pct:>+6.1}%", skyciv[i]);
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 201k — Full reaction diagnostic for Dead_load_shuttle
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_201k_diagnostic_reactions() {
    let json = load_variant("shuttle_rack_2453.json");
    let result = run_full_model(&json);
    let nodes = ["15", "23", "53", "61", "115", "123", "153", "161"];
    let dofs = ["fx", "fy", "fz", "mx", "my", "mz"];

    for lc_name in &["Dead_load_shuttle", "Dead_load_rack", "Product_load"] {
        let lc = &result["results"]["loadcases"][*lc_name];
        if lc.is_null() { continue; }
        let reactions = &lc["reaction_nodes"];
        eprintln!("\n=== {lc_name} Reactions ===");
        for &nid in &nodes {
            let rn = &reactions[nid];
            let forces: Vec<f64> = dofs.iter()
                .map(|d| rn["nodal_forces"][*d].as_f64().unwrap_or(0.0))
                .collect();
            eprintln!("  Node {nid}: fx={:>10.2} fy={:>10.2} fz={:>10.2} mx={:>10.2} my={:>10.2} mz={:>10.2}",
                forces[0], forces[1], forces[2], forces[3], forces[4], forces[5]);
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 201l — Test without shear center to check if z_s causes the mismatch
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_201l_no_shear_center() {
    let json = load_variant("shuttle_rack_2453_nozs.json");
    let result = run_full_model(&json);
    let nodes = ["15", "23", "53", "61", "115", "123", "153", "161"];
    let skyciv: &[f64] = &[442.417, 704.761, -22.028, -46.061, 442.417, 704.761, -22.028, -46.061];
    let dofs = ["fx", "fy", "fz", "mx", "my", "mz"];

    let lc = &result["results"]["loadcases"]["Dead_load_shuttle"];
    assert!(!lc.is_null());
    let reactions = &lc["reaction_nodes"];

    eprintln!("\nNo-z_s variant (Dead_load_shuttle):");
    eprintln!("Full reactions:");
    for &nid in &nodes {
        let rn = &reactions[nid];
        let forces: Vec<f64> = dofs.iter()
            .map(|d| rn["nodal_forces"][*d].as_f64().unwrap_or(0.0))
            .collect();
        eprintln!("  Node {nid}: fx={:>10.2} fy={:>10.2} fz={:>10.2} mx={:>10.2} my={:>10.2} mz={:>10.2}",
            forces[0], forces[1], forces[2], forces[3], forces[4], forces[5]);
    }

    eprintln!("\nComparison with SkyCiv:");
    for (i, &nid) in nodes.iter().enumerate() {
        let fers = reactions[nid]["nodal_forces"]["fy"].as_f64().unwrap_or(f64::NAN);
        let pct = if skyciv[i].abs() > 1.0 { (fers - skyciv[i]) / skyciv[i].abs() * 100.0 } else { fers - skyciv[i] };
        eprintln!("  Node {nid}: FERS={fers:>8.1} SC={:>8.1} Δ={pct:>+6.1}%", skyciv[i]);
    }
}
