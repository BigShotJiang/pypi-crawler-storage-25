// test_200_shuttle_rack_perf.rs
// Performance test: real shuttle rack model (config 2445, single combo).
// Uses calculate_from_json_internal_with_tier(Premium) because the model
// has ~1058 members which exceeds Free tier limits.

use fers_calculations::analysis::calculate_from_json_internal_with_tier;
use fers_calculations::limits::LicenseTier;

/// Load the shuttle rack 2445 JSON fixture (single combo 4).
fn load_shuttle_json() -> String {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("shuttle_rack_2445_combo4.json");
    std::fs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("Failed to read {}: {e}", path.display()))
}

#[test]
fn test_200_shuttle_rack_combo4_converges() {
    let json = load_shuttle_json();
    let t0 = std::time::Instant::now();
    let result = calculate_from_json_internal_with_tier(&json, LicenseTier::Premium);
    let elapsed = t0.elapsed();

    let res_json = match &result {
        Ok(res_json) => {
            assert!(
                !res_json.contains("\"error\""),
                "Result JSON contains an error field"
            );
            eprintln!(
                "✅ Shuttle rack combo 4 solved in {:.1}s",
                elapsed.as_secs_f64()
            );
            res_json.clone()
        }
        Err(e) => {
            panic!(
                "❌ Shuttle rack combo 4 FAILED after {:.1}s: {e}",
                elapsed.as_secs_f64()
            );
        }
    };

    assert!(
        elapsed.as_secs_f64() < 30.0,
        "Shuttle rack took {:.1}s — expected < 30s",
        elapsed.as_secs_f64()
    );

    // Validate stiffness curve support reactions (Dead_load_shuttle)
    let v: serde_json::Value = serde_json::from_str(&res_json).unwrap();
    let lc = &v["results"]["loadcases"]["Dead_load_shuttle"];
    let reactions = lc["reaction_nodes"].as_object().unwrap();

    // All 36 support nodes should produce reactions
    assert_eq!(reactions.len(), 36);

    // Verify stiffness curve produces non-zero Mz (was ~0 before unit fix)
    let n11_mz = reactions["11"]["nodal_forces"]["mz"].as_f64().unwrap();
    assert!(
        n11_mz.abs() > 100.0,
        "Node 11 Mz={n11_mz:.1} N·mm should be significant (stiffness curve active)"
    );

    // Symmetry check: node 11 and 518 should have equal |fy| and opposite mz
    let n518_mz = reactions["518"]["nodal_forces"]["mz"].as_f64().unwrap();
    let n11_fy = reactions["11"]["nodal_forces"]["fy"].as_f64().unwrap();
    let n518_fy = reactions["518"]["nodal_forces"]["fy"].as_f64().unwrap();
    assert!(
        (n11_fy - n518_fy).abs() < 0.1,
        "Symmetric nodes 11/518 fy mismatch: {n11_fy:.1} vs {n518_fy:.1}"
    );
    assert!(
        (n11_mz + n518_mz).abs() < 0.1,
        "Symmetric nodes 11/518 mz should be opposite: {n11_mz:.1} vs {n518_mz:.1}"
    );

    // Global equilibrium: sum of all fy should equal total dead load
    let total_fy: f64 = reactions
        .values()
        .map(|r| r["nodal_forces"]["fy"].as_f64().unwrap_or(0.0))
        .sum();
    assert!(
        total_fy > 5000.0 && total_fy < 20000.0,
        "Total fy={total_fy:.1} N should be reasonable for rack dead load"
    );
}
