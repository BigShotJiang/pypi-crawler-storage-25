// src/functions/sparse.rs
//!
//! Sparse assembly helpers for the FEM global stiffness matrix.
//!
//! Element-level matrices (14×14) stay dense. This module collects COO
//! (coordinate / triplet) entries during assembly and converts them into
//! a `faer::sparse::SparseColMat` (CSC) for efficient sparse solving.

use faer::sparse::SparseColMat;
use faer::sparse::linalg::solvers as sp_solvers;
use faer::prelude::SpSolver;
use faer::Mat;

use crate::functions::geometry::DOFS_PER_NODE;

/// Re-usable sparse triplet (COO) assembler.
///
/// Usage:
///   1. `let mut asm = SparseAssembler::new(n_dofs);`
///   2. For each element: `asm.assemble_element(i0, j0, &ke_14x14);`
///   3. After all elements: `let csc = asm.to_csc();`
pub struct SparseAssembler {
    n: usize,
    triplets: Vec<(usize, usize, f64)>,
}

impl SparseAssembler {
    /// Create a new assembler for a system with `n` degrees of freedom.
    pub fn new(n: usize) -> Self {
        Self {
            n,
            triplets: Vec::new(),
        }
    }

    /// Pre-allocate capacity for the expected number of elements.
    /// Each beam element contributes 4 × 7×7 = 196 triplets.
    pub fn with_capacity(n: usize, n_elements: usize) -> Self {
        Self {
            n,
            triplets: Vec::with_capacity(n_elements * 196),
        }
    }

    /// Scatter a 14×14 element stiffness matrix (2 nodes × 7 DOFs) into the
    /// global assembler. `i0` and `j0` are the base DOF indices for the start
    /// and end nodes respectively.
    pub fn assemble_element(
        &mut self,
        i0: usize,
        j0: usize,
        ke: &nalgebra::DMatrix<f64>,
    ) {
        debug_assert_eq!(ke.nrows(), DOFS_PER_NODE * 2);
        debug_assert_eq!(ke.ncols(), DOFS_PER_NODE * 2);

        for i in 0..DOFS_PER_NODE {
            for j in 0..DOFS_PER_NODE {
                // Upper-left block: start–start
                let v = ke[(i, j)];
                if v != 0.0 {
                    self.triplets.push((i0 + i, i0 + j, v));
                }
                // Upper-right block: start–end
                let v = ke[(i, j + DOFS_PER_NODE)];
                if v != 0.0 {
                    self.triplets.push((i0 + i, j0 + j, v));
                }
                // Lower-left block: end–start
                let v = ke[(i + DOFS_PER_NODE, j)];
                if v != 0.0 {
                    self.triplets.push((j0 + i, i0 + j, v));
                }
                // Lower-right block: end–end
                let v = ke[(i + DOFS_PER_NODE, j + DOFS_PER_NODE)];
                if v != 0.0 {
                    self.triplets.push((j0 + i, j0 + j, v));
                }
            }
        }
    }

    /// Add a single triplet entry (row, col, value).
    /// Duplicate (row, col) entries are summed during CSC conversion.
    #[inline]
    pub fn add(&mut self, row: usize, col: usize, value: f64) {
        if value != 0.0 {
            self.triplets.push((row, col, value));
        }
    }

    /// Number of triplets currently stored.
    pub fn nnz(&self) -> usize {
        self.triplets.len()
    }

    /// Convert accumulated triplets to a faer CSC matrix.
    /// Duplicate entries at the same (row, col) are summed.
    pub fn to_csc(&self) -> SparseColMat<usize, f64> {
        SparseColMat::<usize, f64>::try_new_from_triplets(self.n, self.n, &self.triplets)
            .expect("SparseAssembler: failed to build CSC matrix from triplets")
    }

    /// Convert to a dense `nalgebra::DMatrix` (useful for debugging / testing).
    #[allow(dead_code)]
    pub fn to_dense(&self) -> nalgebra::DMatrix<f64> {
        let mut m = nalgebra::DMatrix::<f64>::zeros(self.n, self.n);
        for &(r, c, v) in &self.triplets {
            m[(r, c)] += v;
        }
        m
    }

    /// Clear all triplets, keeping allocated capacity.
    pub fn clear(&mut self) {
        self.triplets.clear();
    }
}

/// Convert a faer sparse CSC matrix to a dense nalgebra DMatrix.
/// Useful for the `reduce_system` path where the reduced matrix is small.
pub fn sparse_to_dense(sparse: &SparseColMat<usize, f64>) -> nalgebra::DMatrix<f64> {
    let nrows = sparse.nrows();
    let ncols = sparse.ncols();
    let mut dense = nalgebra::DMatrix::<f64>::zeros(nrows, ncols);
    // Iterate over columns
    let symbolic = sparse.symbolic();
    let col_ptrs = symbolic.col_ptrs();
    let row_indices = symbolic.row_indices();
    let values = sparse.values();
    for col in 0..ncols {
        let start = col_ptrs[col];
        let end = col_ptrs[col + 1];
        for idx in start..end {
            let row = row_indices[idx];
            dense[(row, col)] += values[idx];
        }
    }
    dense
}

/// Sparse matrix–dense matrix product: A_sparse * B_dense → C_dense.
/// Used for `K_full_sparse * S_dense` in `reduce_system`.
/// Column-oriented for cache-friendly access with column-major storage,
/// and parallelised across output columns with rayon.
pub fn spmm_sparse_dense(
    sparse: &SparseColMat<usize, f64>,
    dense: &nalgebra::DMatrix<f64>,
) -> nalgebra::DMatrix<f64> {
    use rayon::prelude::*;

    let m = sparse.nrows();
    let n = dense.ncols();
    debug_assert_eq!(sparse.ncols(), dense.nrows());

    let symbolic = sparse.symbolic();
    let col_ptrs = symbolic.col_ptrs();
    let row_indices = symbolic.row_indices();
    let values = sparse.values();

    // Compute each output column in parallel.
    // For column j: result[:,j] = A_sparse * dense[:,j]
    let columns: Vec<Vec<f64>> = (0..n)
        .into_par_iter()
        .map(|j| {
            let mut col = vec![0.0_f64; m];
            for k in 0..sparse.ncols() {
                let d_kj = dense[(k, j)];
                if d_kj == 0.0 {
                    continue;
                }
                let start = col_ptrs[k];
                let end = col_ptrs[k + 1];
                for idx in start..end {
                    col[row_indices[idx]] += values[idx] * d_kj;
                }
            }
            col
        })
        .collect();

    nalgebra::DMatrix::from_fn(m, n, |i, j| columns[j][i])
}

/// Compute S^T * K_sparse * S where K is sparse and S is dense.
/// Returns a dense reduced matrix.
/// Uses faer's optimized matmul for the S^T * KS step.
pub fn reduce_with_sparse_k(
    k_sparse: &SparseColMat<usize, f64>,
    s: &nalgebra::DMatrix<f64>,
) -> nalgebra::DMatrix<f64> {
    // KS = K_sparse * S  (sparse × dense → dense)
    let ks = spmm_sparse_dense(k_sparse, s);

    // S^T * KS using faer's optimized matmul (BLAS-like performance).
    // Zero-copy views: nalgebra and faer both use contiguous column-major storage.
    let n_red = s.ncols();
    let n_full = s.nrows();
    let s_faer = faer::mat::from_column_major_slice(s.as_slice(), n_full, n_red);
    let ks_faer = faer::mat::from_column_major_slice(ks.as_slice(), n_full, n_red);
    let mut result = Mat::<f64>::zeros(n_red, n_red);
    faer::linalg::matmul::matmul(
        result.as_mut(),
        s_faer.transpose(),
        ks_faer,
        None,
        1.0,
        faer::Parallelism::Rayon(0),
    );
    nalgebra::DMatrix::from_fn(n_red, n_red, |i, j| result.read(i, j))
}

/// Solve a dense linear system K * x = f using faer's optimized LU factorization.
/// Returns None if the system is singular.
///
/// Uses zero-copy views via `from_column_major_slice` to avoid copying the
/// stiffness matrix from nalgebra to faer.  Both libraries use column-major
/// layout so the raw storage is directly reinterpretable.
pub fn solve_dense_lu(
    k: &nalgebra::DMatrix<f64>,
    f: &nalgebra::DMatrix<f64>,
) -> Option<nalgebra::DMatrix<f64>> {
    let n = k.nrows();
    // Zero-copy views: nalgebra and faer both use contiguous column-major storage.
    // This avoids an O(n²) element-by-element copy for the stiffness matrix.
    let k_faer = faer::mat::from_column_major_slice(k.as_slice(), n, n);
    let f_faer = faer::mat::from_column_major_slice(f.as_slice(), f.nrows(), f.ncols());
    let lu = k_faer.partial_piv_lu();
    let x_faer = lu.solve(f_faer);
    Some(nalgebra::DMatrix::from_fn(n, 1, |i, _| x_faer.read(i, 0)))
}

/// Opaque wrapper around a cached LU factorisation.
/// Keeps the factorisation alive so it can solve multiple right-hand sides
/// without re-factorising. Reserved for future Modified Newton-Raphson.
#[allow(dead_code)]
pub struct CachedLu {
    lu: nalgebra::linalg::LU<f64, nalgebra::Dyn, nalgebra::Dyn>,
}

impl CachedLu {
    /// Factorise a dense nalgebra matrix.  Returns `None` when the matrix is
    /// empty (zero dimension).
    pub fn new(k: &nalgebra::DMatrix<f64>) -> Option<Self> {
        if k.nrows() == 0 {
            return None;
        }
        Some(Self { lu: k.clone().lu() })
    }

    /// Solve K x = rhs using the cached factorisation.
    /// Returns `None` if the original matrix was singular.
    pub fn solve(&self, rhs: &nalgebra::DMatrix<f64>) -> Option<nalgebra::DMatrix<f64>> {
        self.lu.solve(rhs)
    }
}

// ---------------------------------------------------------------------------
// Sparse direct solver path  (Cholesky → LU fallback)
// ---------------------------------------------------------------------------

/// Find the maximum absolute diagonal entry of a sparse CSC matrix.
pub fn sparse_max_abs_diagonal(k_sparse: &SparseColMat<usize, f64>) -> f64 {
    let n = k_sparse.nrows();
    let symbolic = k_sparse.symbolic();
    let col_ptrs = symbolic.col_ptrs();
    let row_indices = symbolic.row_indices();
    let values = k_sparse.values();
    let mut max_diag = 0.0_f64;
    for col in 0..n {
        for idx in col_ptrs[col]..col_ptrs[col + 1] {
            if row_indices[idx] == col {
                max_diag = max_diag.max(values[idx].abs());
            }
        }
    }
    max_diag
}

/// Solve a sparse symmetric positive-definite system **K x = f** using faer's
/// sparse Cholesky (supernodal LLT) factorisation.
///
/// Falls back to sparse LU with partial pivoting if Cholesky fails (e.g. the
/// matrix is indefinite or only semi-definite).
///
/// Complexity is approximately **O(n^{1.5}–2)** for typical FEM sparsity
/// patterns, compared with O(n³) for the dense LU path.
pub fn solve_sparse_cholesky(
    k_sparse: &SparseColMat<usize, f64>,
    f: &nalgebra::DMatrix<f64>,
) -> Option<nalgebra::DMatrix<f64>> {
    let n = k_sparse.nrows();
    debug_assert_eq!(n, f.nrows());

    // Zero-copy view: nalgebra and faer both use contiguous column-major storage.
    let f_faer = faer::mat::from_column_major_slice(f.as_slice(), f.nrows(), f.ncols());

    // Try sparse Cholesky first (FEM stiffness matrices are SPD after BCs).
    if let Ok(chol) = k_sparse.sp_cholesky(faer::Side::Lower) {
        let x_faer = chol.solve(f_faer);
        return Some(nalgebra::DMatrix::from_fn(n, f.ncols(), |i, j| {
            x_faer.read(i, j)
        }));
    }

    // Fall back to sparse LU (handles indefinite / non-SPD cases).
    solve_sparse_lu(k_sparse, f)
}

/// Solve a sparse system using LU factorisation with partial pivoting.
///
/// More robust than Cholesky for ill-conditioned systems (e.g. models with
/// rigid-member penalty stiffening that push the condition number beyond
/// what unpivoted Cholesky can handle accurately).
pub fn solve_sparse_lu(
    k_sparse: &SparseColMat<usize, f64>,
    f: &nalgebra::DMatrix<f64>,
) -> Option<nalgebra::DMatrix<f64>> {
    let n = k_sparse.nrows();
    debug_assert_eq!(n, f.nrows());

    let f_faer = faer::mat::from_column_major_slice(f.as_slice(), f.nrows(), f.ncols());

    if let Ok(lu) = k_sparse.sp_lu() {
        let x_faer = lu.solve(f_faer);
        return Some(nalgebra::DMatrix::from_fn(n, f.ncols(), |i, j| {
            x_faer.read(i, j)
        }));
    }

    None
}

/// Apply penalty boundary conditions to a sparse stiffness matrix.
///
/// For each constrained DOF, adds a large penalty (`1e10 × max_diagonal`) to
/// the diagonal entry and sets the corresponding RHS to zero.  This preserves
/// the sparse structure and symmetry while effectively constraining those DOFs.
///
/// Returns the modified sparse matrix.  Modifies `f` **in place**.
pub fn apply_penalty_bc_sparse(
    k_sparse: &SparseColMat<usize, f64>,
    f: &mut nalgebra::DMatrix<f64>,
    constrained_dofs: &[usize],
) -> SparseColMat<usize, f64> {
    if constrained_dofs.is_empty() {
        return k_sparse.clone();
    }

    let max_diag = sparse_max_abs_diagonal(k_sparse).max(1.0);
    let penalty = 1.0e10 * max_diag;

    let entries: Vec<(usize, f64)> = constrained_dofs
        .iter()
        .map(|&dof| {
            f[(dof, 0)] = 0.0;
            (dof, penalty)
        })
        .collect();

    sparse_add_diagonal(k_sparse, &entries)
}

/// Solve a constrained sparse linear system using the sparse Cholesky path.
///
/// 1. Applies penalty boundary conditions for the given `constrained_dofs`.
/// 2. Solves the penalised system with sparse Cholesky (≈ O(n^{1.5})).
/// 3. Returns the **full** displacement vector.
///
/// This replaces the dense `S^T K S` reduction + dense LU path for models
/// without rigid members, changing the solve complexity from O(n³) to
/// approximately O(n^{1.5}).
pub fn solve_sparse_system(
    k_sparse: &SparseColMat<usize, f64>,
    f: &nalgebra::DMatrix<f64>,
    constrained_dofs: &[usize],
) -> Option<nalgebra::DMatrix<f64>> {
    let mut f_mod = f.clone();
    let k_mod = apply_penalty_bc_sparse(k_sparse, &mut f_mod, constrained_dofs);
    solve_sparse_cholesky(&k_mod, &f_mod)
}

/// Apply **direct elimination** boundary conditions to a sparse stiffness
/// matrix (upper-triangle CSC).  For each constrained DOF, all off-diagonal
/// entries in its row and column are zeroed and the diagonal is set to 1.
/// The corresponding RHS entry is set to 0.
///
/// Unlike the penalty method this does NOT inflate the condition number
/// because it does not add large diagonal entries.  Condition number is
/// governed solely by the physical stiffness ratio, which allows the sparse
/// Cholesky to remain accurate even when the matrix contains very stiff
/// (e.g. rigid-member penalty) entries.
///
/// Returns a new sparse matrix; modifies `f` **in place**.
pub fn apply_direct_bc_sparse(
    k_sparse: &SparseColMat<usize, f64>,
    f: &mut nalgebra::DMatrix<f64>,
    constrained_dofs: &[usize],
) -> SparseColMat<usize, f64> {
    if constrained_dofs.is_empty() {
        return k_sparse.clone();
    }

    let n = k_sparse.nrows();

    // Build a fast lookup set for constrained DOFs.
    let mut is_constrained = vec![false; n];
    for &dof in constrained_dofs {
        is_constrained[dof] = true;
        f[(dof, 0)] = 0.0;
    }

    // Build the modified matrix by cloning and overwriting affected values.
    // Upper-triangle CSC: entry (row, col) with row <= col.
    // For a constrained DOF d:
    //   - Zero entries in column d where row != d  (column zeroing)
    //   - Zero entries where row == d and col != d  (row zeroing)
    //   - Set (d, d) = 1.0
    let mut k_mod = k_sparse.clone();
    {
        let vals = k_mod.values_mut();
        let symbolic = k_sparse.symbolic();
        let col_ptrs = symbolic.col_ptrs();
        let row_indices = symbolic.row_indices();
        for col in 0..n {
            for idx in col_ptrs[col]..col_ptrs[col + 1] {
                let row = row_indices[idx];
                if row == col && is_constrained[col] {
                    // Keep original diagonal (preserves condition number)
                    // Since f[constrained] = 0 → u[constrained] = 0/k_ii = 0
                } else if is_constrained[row] || is_constrained[col] {
                    vals[idx] = 0.0;
                }
            }
        }
    }
    k_mod
}

/// Solve a constrained sparse linear system with direct elimination BCs.
///
/// Uses direct row/column zeroing instead of penalty to avoid the condition
/// number blow-up that occurs when very stiff (e.g. rigid) elements coexist
/// with penalty BCs.  Ideal for models with rigid members on the sparse path.
pub fn solve_sparse_system_direct_bc(
    k_sparse: &SparseColMat<usize, f64>,
    f: &nalgebra::DMatrix<f64>,
    constrained_dofs: &[usize],
) -> Option<nalgebra::DMatrix<f64>> {
    let mut f_mod = f.clone();
    let k_mod = apply_direct_bc_sparse(k_sparse, &mut f_mod, constrained_dofs);
    // Try Cholesky first (SPD after direct BCs — no condition number inflation).
    // Fall back to sparse LU if Cholesky fails.
    solve_sparse_cholesky(&k_mod, &f_mod)
}

// ---------------------------------------------------------------------------
// Cached symbolic Cholesky factorisation & multi-RHS batch solving
// ---------------------------------------------------------------------------

/// Cached symbolic sparse Cholesky factorisation.
///
/// The **symbolic analysis** (fill-in ordering, elimination tree) depends only
/// on the sparsity pattern of the matrix and is computed once in
/// [`CachedSymbolicCholesky::new`].  Subsequent solves that share the same
/// sparsity pattern call [`factorize_numerical_and_solve`], which performs only
/// the O(nnz) numerical factorisation plus forward/backward substitution,
/// skipping the redundant O(n) symbolic work.
///
/// Typical use: solving multiple first-order load cases that share the same
/// global stiffness matrix K (same model, same boundary conditions, only the
/// load vector changes).
pub struct CachedSymbolicCholesky {
    symbolic: sp_solvers::SymbolicCholesky<usize>,
}

impl CachedSymbolicCholesky {
    /// Compute the symbolic Cholesky factorisation from the sparsity pattern
    /// of the given sparse matrix (lower triangle).
    ///
    /// This is the expensive part that analyses fill-in ordering and builds
    /// the elimination tree.  Call this **once**, then reuse the result for
    /// every numerical factorisation that shares the same sparsity pattern.
    pub fn new(k_sparse: &SparseColMat<usize, f64>) -> Result<Self, String> {
        let symbolic =
            sp_solvers::SymbolicCholesky::try_new(k_sparse.symbolic(), faer::Side::Lower)
                .map_err(|e| format!("Symbolic Cholesky analysis failed: {e:?}"))?;
        Ok(Self { symbolic })
    }

    /// Perform **only** the numerical factorisation (using the cached symbolic
    /// analysis) and solve K × X = F.
    ///
    /// `k_sparse` must have the **same sparsity pattern** as the matrix that
    /// was passed to [`CachedSymbolicCholesky::new`].  `f` may have one or
    /// multiple RHS columns.
    ///
    /// Falls back to a full sparse LU factorisation (without symbolic caching)
    /// if the numerical Cholesky factorisation fails (e.g. the matrix is not
    /// positive-definite).
    pub fn factorize_numerical_and_solve(
        &self,
        k_sparse: &SparseColMat<usize, f64>,
        f: &nalgebra::DMatrix<f64>,
    ) -> Option<nalgebra::DMatrix<f64>> {
        let n = k_sparse.nrows();
        debug_assert_eq!(n, f.nrows());

        let f_faer = faer::mat::from_column_major_slice(f.as_slice(), f.nrows(), f.ncols());

        // Try Cholesky with cached symbolic (skips symbolic analysis)
        if let Ok(chol) = sp_solvers::Cholesky::try_new_with_symbolic(
            self.symbolic.clone(),
            k_sparse.as_ref(),
            faer::Side::Lower,
        ) {
            let x_faer = chol.solve(f_faer);
            return Some(nalgebra::DMatrix::from_fn(n, f.ncols(), |i, j| {
                x_faer.read(i, j)
            }));
        }

        // Fall back to sparse LU (handles indefinite / non-SPD cases).
        if let Ok(lu) = k_sparse.sp_lu() {
            let x_faer = lu.solve(f_faer);
            return Some(nalgebra::DMatrix::from_fn(n, f.ncols(), |i, j| {
                x_faer.read(i, j)
            }));
        }

        None
    }
}

/// Apply penalty boundary conditions to the stiffness matrix only, without
/// modifying any right-hand-side vector.
///
/// Returns the modified sparse matrix with penalty values added to the
/// diagonal entries of the constrained DOFs.
fn apply_penalty_to_k(
    k_sparse: &SparseColMat<usize, f64>,
    constrained_dofs: &[usize],
) -> SparseColMat<usize, f64> {
    if constrained_dofs.is_empty() {
        return k_sparse.clone();
    }

    let max_diag = sparse_max_abs_diagonal(k_sparse).max(1.0);
    let penalty = 1.0e10 * max_diag;

    let entries: Vec<(usize, f64)> = constrained_dofs
        .iter()
        .map(|&dof| (dof, penalty))
        .collect();

    sparse_add_diagonal(k_sparse, &entries)
}

/// Public wrapper for [`apply_penalty_to_k`] used by the precomputed combo path.
pub fn apply_penalty_to_k_pub(
    k_sparse: &SparseColMat<usize, f64>,
    constrained_dofs: &[usize],
) -> SparseColMat<usize, f64> {
    apply_penalty_to_k(k_sparse, constrained_dofs)
}

/// Apply direct-elimination BCs to K only (without modifying a RHS vector).
///
/// Zeros off-diagonal entries in constrained rows/columns, keeps the
/// diagonal.  Ideal for the precomputed combo path where the RHS is
/// assembled per-combo.
pub fn apply_direct_bc_to_k_only(
    k_sparse: &SparseColMat<usize, f64>,
    constrained_dofs: &[usize],
) -> SparseColMat<usize, f64> {
    let mut dummy = nalgebra::DMatrix::zeros(k_sparse.nrows(), 1);
    apply_direct_bc_sparse(k_sparse, &mut dummy, constrained_dofs)
}

/// Solve a constrained sparse system **K x = F** for a multi-column right-hand
/// side in a single factorisation.
///
/// 1. Applies penalty boundary conditions to K (diagonal) **once**.
/// 2. Zeroes constrained DOF rows in **all** columns of `f_multi`.
/// 3. Factors the penalised K **once** (sparse Cholesky with cached symbolic,
///    LU fallback).
/// 4. Solves for all RHS columns simultaneously via forward/backward
///    substitution.
///
/// Returns an n × ncols displacement matrix, or `None` if factorisation fails.
pub fn solve_sparse_system_multi_rhs(
    k_sparse: &SparseColMat<usize, f64>,
    f_multi: &nalgebra::DMatrix<f64>,
    constrained_dofs: &[usize],
) -> Option<nalgebra::DMatrix<f64>> {
    // 1. Build penalised K (diagonal penalty on constrained DOFs)
    let k_pen = apply_penalty_to_k(k_sparse, constrained_dofs);

    // 2. Clone the RHS and zero constrained rows in all columns
    let mut f_mod = f_multi.clone();
    for &dof in constrained_dofs {
        for j in 0..f_mod.ncols() {
            f_mod[(dof, j)] = 0.0;
        }
    }

    // 3. Build cached symbolic analysis from the penalised matrix
    let cache = CachedSymbolicCholesky::new(&k_pen).ok()?;

    // 4. Numerical factorisation + multi-RHS solve
    cache.factorize_numerical_and_solve(&k_pen, &f_mod)
}

/// Compute S^T * f_full where S is dense and f_full is a dense column vector.
pub fn reduce_force(
    s: &nalgebra::DMatrix<f64>,
    f_full: &nalgebra::DMatrix<f64>,
) -> nalgebra::DMatrix<f64> {
    s.transpose() * f_full
}

/// Add two sparse CSC matrices with the same dimensions.
/// Returns a new sparse matrix with all entries summed.
pub fn sparse_add(
    a: &SparseColMat<usize, f64>,
    b: &SparseColMat<usize, f64>,
) -> SparseColMat<usize, f64> {
    debug_assert_eq!(a.nrows(), b.nrows());
    debug_assert_eq!(a.ncols(), b.ncols());

    let n = a.nrows();
    let mut asm = SparseAssembler::new(n);

    // Add all entries from a
    let sym_a = a.symbolic();
    let col_ptrs_a = sym_a.col_ptrs();
    let row_indices_a = sym_a.row_indices();
    let values_a = a.values();
    for col in 0..a.ncols() {
        for idx in col_ptrs_a[col]..col_ptrs_a[col + 1] {
            asm.add(row_indices_a[idx], col, values_a[idx]);
        }
    }

    // Add all entries from b
    let sym_b = b.symbolic();
    let col_ptrs_b = sym_b.col_ptrs();
    let row_indices_b = sym_b.row_indices();
    let values_b = b.values();
    for col in 0..b.ncols() {
        for idx in col_ptrs_b[col]..col_ptrs_b[col + 1] {
            asm.add(row_indices_b[idx], col, values_b[idx]);
        }
    }

    asm.to_csc()
}

/// Clone matrix `a` and add all values from `b` into it **in O(nnz)**.
///
/// Requires that every non-zero position in `b` also exists in `a`
/// (i.e. `a`'s sparsity pattern is a superset of `b`'s).  This is the
/// common case for K_total = K_e + K_g in FEM: both are assembled from the
/// same element connectivity, so K_e always has entries wherever K_g does.
///
/// Falls back to the triplet-based `sparse_add` when the superset condition
/// is not met.
pub fn sparse_clone_and_add(
    a: &SparseColMat<usize, f64>,
    b: &SparseColMat<usize, f64>,
) -> SparseColMat<usize, f64> {
    debug_assert_eq!(a.nrows(), b.nrows());
    debug_assert_eq!(a.ncols(), b.ncols());

    let sym_a = a.symbolic();
    let col_ptrs_a = sym_a.col_ptrs();
    let row_indices_a = sym_a.row_indices();

    let sym_b = b.symbolic();
    let col_ptrs_b = sym_b.col_ptrs();
    let row_indices_b = sym_b.row_indices();
    let values_b = b.values();

    let n = a.ncols();

    // Clone a's values — we'll add b's values into this clone.
    let mut result = a.clone();
    let vals = result.values_mut();

    // For each column, merge-scan b's row indices into a's row indices.
    // Since both are sorted (CSC invariant), this is O(nnz_a + nnz_b).
    for col in 0..n {
        let a_start = col_ptrs_a[col];
        let a_end = col_ptrs_a[col + 1];
        let b_start = col_ptrs_b[col];
        let b_end = col_ptrs_b[col + 1];

        if b_start == b_end {
            continue; // no entries in b for this column
        }

        let mut ai = a_start;
        for bi in b_start..b_end {
            let b_row = row_indices_b[bi];
            // Advance a's pointer to find the matching row
            while ai < a_end && row_indices_a[ai] < b_row {
                ai += 1;
            }
            if ai < a_end && row_indices_a[ai] == b_row {
                vals[ai] += values_b[bi];
            } else {
                // Fallback: b has an entry that a doesn't — use slow path
                return sparse_add(a, b);
            }
        }
    }

    result
}

/// Add diagonal entries to a sparse matrix **in place**.
///
/// Each diagonal position `(dof, dof)` must already exist in the sparsity
/// pattern (guaranteed for FEM stiffness matrices assembled from elements
/// that contribute to every connected DOF).  Falls back to the allocating
/// `sparse_add_diagonal` when a diagonal entry is missing.
pub fn sparse_add_diagonal_inplace(
    matrix: &mut SparseColMat<usize, f64>,
    entries: &[(usize, f64)],
) -> bool {
    if entries.is_empty() {
        return true;
    }

    let sym = matrix.symbolic();
    let col_ptrs = sym.col_ptrs();
    let row_indices = sym.row_indices();

    // Pre-check: find the value index of each diagonal entry.
    let mut diag_indices: Vec<usize> = Vec::with_capacity(entries.len());
    for &(dof, _) in entries {
        let col_start = col_ptrs[dof];
        let col_end = col_ptrs[dof + 1];
        let slice = &row_indices[col_start..col_end];
        if let Ok(offset) = slice.binary_search(&dof) {
            diag_indices.push(col_start + offset);
        } else {
            return false; // diagonal not in pattern
        }
    }

    // All found — add in place.
    let vals = matrix.values_mut();
    for (i, &(_, value)) in entries.iter().enumerate() {
        vals[diag_indices[i]] += value;
    }
    true
}

/// Apply penalty boundary conditions **in place** on a mutable sparse matrix.
///
/// Adds `penalty` (= 1e10 × max_diagonal) to each constrained DOF's diagonal.
/// Also zeros the corresponding entries in the RHS vector `f`.
///
/// Returns `true` if in-place application succeeded; `false` if the matrix
/// lacks a diagonal entry for some constrained DOF (caller should fall back
/// to `apply_penalty_bc_sparse`).
pub fn apply_penalty_bc_inplace(
    k_sparse: &mut SparseColMat<usize, f64>,
    f: &mut nalgebra::DMatrix<f64>,
    constrained_dofs: &[usize],
) -> bool {
    if constrained_dofs.is_empty() {
        return true;
    }

    let max_diag = sparse_max_abs_diagonal(k_sparse).max(1.0);
    let penalty = 1.0e10 * max_diag;

    // Zero RHS for constrained DOFs
    for &dof in constrained_dofs {
        f[(dof, 0)] = 0.0;
    }

    let entries: Vec<(usize, f64)> = constrained_dofs
        .iter()
        .map(|&dof| (dof, penalty))
        .collect();
    sparse_add_diagonal_inplace(k_sparse, &entries)
}

/// Add support springs (diagonal entries) to an existing sparse matrix.
/// Returns a new sparse matrix.
pub fn sparse_add_diagonal(
    matrix: &SparseColMat<usize, f64>,
    entries: &[(usize, f64)],
) -> SparseColMat<usize, f64> {
    let n = matrix.nrows();
    let mut asm = SparseAssembler::new(n);

    // Copy existing entries
    let sym = matrix.symbolic();
    let col_ptrs = sym.col_ptrs();
    let row_indices = sym.row_indices();
    let values = matrix.values();
    for col in 0..matrix.ncols() {
        for idx in col_ptrs[col]..col_ptrs[col + 1] {
            asm.add(row_indices[idx], col, values[idx]);
        }
    }

    // Add diagonal entries
    for &(dof, value) in entries {
        asm.add(dof, dof, value);
    }

    asm.to_csc()
}

/// Add a uniform value to every diagonal entry of a sparse matrix.
///
/// Used for Levenberg-Marquardt (LM) damping in the sparse NR path:
/// when sparse Cholesky fails (non-positive-definite tangent), we add
/// `damp × max_diag` to every diagonal to regularise the system.
pub fn sparse_add_uniform_diagonal(
    matrix: &SparseColMat<usize, f64>,
    value: f64,
) -> SparseColMat<usize, f64> {
    let n = matrix.nrows();
    let entries: Vec<(usize, f64)> = (0..n).map(|i| (i, value)).collect();
    sparse_add_diagonal(matrix, &entries)
}

/// Sparse matrix–vector multiply: y = K * x  (CSC upper-triangular storage).
///
/// The stiffness matrices produced by `SparseAssembler` store only the
/// upper triangle (row ≤ col).  This routine exploits symmetry so that
/// a single pass over the stored entries produces the full product.
pub fn sparse_matvec(
    k: &SparseColMat<usize, f64>,
    x: &nalgebra::DMatrix<f64>,
) -> nalgebra::DMatrix<f64> {
    let n = k.nrows();
    debug_assert_eq!(n, x.nrows());
    let mut y = nalgebra::DMatrix::<f64>::zeros(n, 1);

    let sym = k.symbolic();
    let col_ptrs = sym.col_ptrs();
    let row_indices = sym.row_indices();
    let values = k.values();

    for col in 0..n {
        for idx in col_ptrs[col]..col_ptrs[col + 1] {
            let row = row_indices[idx];
            let v = values[idx];
            y[(row, 0)] += v * x[(col, 0)];
            if row != col {
                y[(col, 0)] += v * x[(row, 0)];
            }
        }
    }
    y
}

/// Convert a symmetric sparse CSC matrix (upper-triangular storage) to a
/// full dense nalgebra matrix.
///
/// This is O(nnz) — vastly faster than `reduce_with_sparse_k(K, I)` which
/// is O(n³) for the dense matrix multiplication.  Use when the S elimination
/// matrix is identity (RigidMember strategy).
pub fn sparse_to_dense_symmetric(k: &SparseColMat<usize, f64>) -> nalgebra::DMatrix<f64> {
    let n = k.nrows();
    let mut m = nalgebra::DMatrix::<f64>::zeros(n, n);

    let sym = k.symbolic();
    let col_ptrs = sym.col_ptrs();
    let row_indices = sym.row_indices();
    let values = k.values();

    for col in 0..n {
        for idx in col_ptrs[col]..col_ptrs[col + 1] {
            let row = row_indices[idx];
            let v = values[idx];
            m[(row, col)] = v;
            if row != col {
                m[(col, row)] = v; // symmetrise
            }
        }
    }
    m
}

// ---------------------------------------------------------------------------
// Iterative-refinement sparse solver for ill-conditioned systems
// ---------------------------------------------------------------------------

/// Solve a constrained sparse system with **iterative refinement** and direct
/// BC elimination.
///
/// Designed for systems where very stiff elements (rigid-member penalty
/// stiffening, factor ≈ 1e4) coexist with very soft DOFs (warping, diagonal
/// ≈ 0.01), creating condition numbers ≈ 1e14 that cause ~2 digits of loss
/// in a single sparse LU solve.
///
/// Steps:
///  1. Apply direct BC elimination (zero rows/cols, keep diagonal)
///  2. Factor K with sparse LU (partial pivoting)
///  3. Initial solve: x₀ = LU⁻¹ f
///  4. Iterative refinement (3-4 steps):
///     a. Residual r = f - K x  (full-precision sparse matvec)
///     b. Correction δx = LU⁻¹ r  (reuses cached factorization)
///     c. x ← x + δx
///
/// Each refinement step recovers ~2 digits of accuracy.  With condition
/// ≈ 1e14 and 4 steps: 2 → 4 → 6 → 8 → 10 digits — plenty for FEM.
pub fn solve_sparse_system_refined(
    k_sparse: &SparseColMat<usize, f64>,
    f: &nalgebra::DMatrix<f64>,
    constrained_dofs: &[usize],
) -> Option<nalgebra::DMatrix<f64>> {
    let n = k_sparse.nrows();
    let ncols = f.ncols();
    debug_assert_eq!(n, f.nrows());

    // 1. Apply direct BC elimination
    let mut f_mod = f.clone();
    let k_bc = apply_direct_bc_sparse(k_sparse, &mut f_mod, constrained_dofs);

    // 2. Factor once with sparse LU
    let lu = k_bc.sp_lu().ok()?;

    // 3. Initial solve
    let f_faer = faer::mat::from_column_major_slice(f_mod.as_slice(), n, ncols);
    let x0_faer = lu.solve(f_faer);
    let mut x = nalgebra::DMatrix::from_fn(n, ncols, |i, j| x0_faer.read(i, j));

    // 4. Iterative refinement — 4 steps
    for _ in 0..4 {
        // Residual in full f64 precision (sparse symmetric matvec)
        let kx = sparse_matvec(&k_bc, &x);
        let r = &f_mod - &kx;

        // Check convergence: if residual is very small, stop early
        let r_norm = r.iter().map(|v| v.abs()).fold(0.0f64, f64::max);
        if r_norm < 1e-14 * f_mod.iter().map(|v| v.abs()).fold(1.0f64, f64::max) {
            break;
        }

        // Correction via cached LU factorization (no re-factoring)
        let r_faer = faer::mat::from_column_major_slice(r.as_slice(), n, ncols);
        let dx_faer = lu.solve(r_faer);
        for i in 0..n {
            for j in 0..ncols {
                x[(i, j)] += dx_faer.read(i, j);
            }
        }
    }

    Some(x)
}

#[cfg(test)]
mod tests {
    use super::*;
    use nalgebra::DMatrix;

    #[test]
    fn test_assembler_single_element() {
        // 2-node element with 7 DOFs per node = 14×14 element matrix
        let n_dofs = 14; // 2 nodes
        let mut asm = SparseAssembler::new(n_dofs);

        let mut ke = DMatrix::<f64>::zeros(14, 14);
        ke[(0, 0)] = 100.0;
        ke[(0, 7)] = -100.0;
        ke[(7, 0)] = -100.0;
        ke[(7, 7)] = 100.0;

        asm.assemble_element(0, 7, &ke);

        let dense = asm.to_dense();
        assert_eq!(dense[(0, 0)], 100.0);
        assert_eq!(dense[(0, 7)], -100.0);
        assert_eq!(dense[(7, 0)], -100.0);
        assert_eq!(dense[(7, 7)], 100.0);

        let csc = asm.to_csc();
        let csc_dense = sparse_to_dense(&csc);
        assert!((dense - csc_dense).norm() < 1e-12);
    }

    #[test]
    fn test_sparse_add() {
        let n = 4;
        let mut asm_a = SparseAssembler::new(n);
        asm_a.add(0, 0, 1.0);
        asm_a.add(1, 1, 2.0);
        let a = asm_a.to_csc();

        let mut asm_b = SparseAssembler::new(n);
        asm_b.add(0, 0, 3.0);
        asm_b.add(2, 2, 4.0);
        let b = asm_b.to_csc();

        let c = sparse_add(&a, &b);
        let dense_c = sparse_to_dense(&c);

        assert_eq!(dense_c[(0, 0)], 4.0);
        assert_eq!(dense_c[(1, 1)], 2.0);
        assert_eq!(dense_c[(2, 2)], 4.0);
    }

    #[test]
    fn test_reduce_with_sparse_k() {
        // Simple 4×4 K, reduce to 2×2 via S
        let mut asm = SparseAssembler::new(4);
        asm.add(0, 0, 10.0);
        asm.add(1, 1, 20.0);
        asm.add(2, 2, 30.0);
        asm.add(3, 3, 40.0);
        let k = asm.to_csc();

        // S selects DOFs 0 and 2 (identity columns)
        let mut s = DMatrix::<f64>::zeros(4, 2);
        s[(0, 0)] = 1.0;
        s[(2, 1)] = 1.0;

        let k_red = reduce_with_sparse_k(&k, &s);
        assert_eq!(k_red.nrows(), 2);
        assert_eq!(k_red.ncols(), 2);
        assert!((k_red[(0, 0)] - 10.0).abs() < 1e-12);
        assert!((k_red[(1, 1)] - 30.0).abs() < 1e-12);
        assert!((k_red[(0, 1)]).abs() < 1e-12);
    }

    #[test]
    fn test_spmm_sparse_dense() {
        let mut asm = SparseAssembler::new(3);
        asm.add(0, 0, 2.0);
        asm.add(0, 1, 1.0);
        asm.add(1, 1, 3.0);
        asm.add(2, 2, 4.0);
        let sparse = asm.to_csc();

        let dense = DMatrix::from_row_slice(3, 2, &[1.0, 0.0, 0.0, 1.0, 1.0, 1.0]);

        let result = spmm_sparse_dense(&sparse, &dense);

        // row 0: 2*1 + 1*0 = 2, 2*0 + 1*1 = 1
        // row 1: 0*1 + 3*0 = 0, 0*0 + 3*1 = 3
        // row 2: 0*1 + 0*0 + 4*1 = 4, 0*0 + 0*1 + 4*1 = 4
        assert!((result[(0, 0)] - 2.0).abs() < 1e-12);
        assert!((result[(0, 1)] - 1.0).abs() < 1e-12);
        assert!((result[(1, 0)] - 0.0).abs() < 1e-12);
        assert!((result[(1, 1)] - 3.0).abs() < 1e-12);
        assert!((result[(2, 0)] - 4.0).abs() < 1e-12);
        assert!((result[(2, 1)] - 4.0).abs() < 1e-12);
    }

    #[test]
    fn test_solve_sparse_cholesky_simple() {
        // Simple 3×3 SPD system
        let mut asm = SparseAssembler::new(3);
        asm.add(0, 0, 4.0);
        asm.add(0, 1, 1.0);
        asm.add(1, 0, 1.0);
        asm.add(1, 1, 3.0);
        asm.add(2, 2, 2.0);
        let k = asm.to_csc();

        let f = DMatrix::from_column_slice(3, 1, &[1.0, 2.0, 3.0]);

        let x = solve_sparse_cholesky(&k, &f).expect("solve should succeed");

        // Verify: K * x ≈ f
        let k_dense = sparse_to_dense(&k);
        let residual = &k_dense * &x - &f;
        assert!(residual.norm() < 1e-10);
    }

    #[test]
    fn test_solve_sparse_system_with_constraints() {
        // 4 DOF tridiagonal-like system, constrain DOF 0 to zero.
        let mut asm = SparseAssembler::new(4);
        asm.add(0, 0, 10.0);
        asm.add(0, 1, -5.0);
        asm.add(1, 0, -5.0);
        asm.add(1, 1, 10.0);
        asm.add(1, 2, -5.0);
        asm.add(2, 1, -5.0);
        asm.add(2, 2, 10.0);
        asm.add(2, 3, -5.0);
        asm.add(3, 2, -5.0);
        asm.add(3, 3, 10.0);
        let k = asm.to_csc();

        let f = DMatrix::from_column_slice(4, 1, &[0.0, 0.0, 0.0, 100.0]);

        let x = solve_sparse_system(&k, &f, &[0]).expect("solve should succeed");

        // DOF 0 should be approximately zero (penalised)
        assert!(x[(0, 0)].abs() < 1e-6);
        // Other DOFs should have positive, increasing displacement
        assert!(x[(1, 0)] > 0.0);
        assert!(x[(2, 0)] > x[(1, 0)]);
        assert!(x[(3, 0)] > x[(2, 0)]);
    }

    #[test]
    fn test_solve_sparse_matches_dense_lu() {
        // Compare sparse Cholesky vs dense LU on a small SPD system with BCs
        let mut asm = SparseAssembler::new(4);
        asm.add(0, 0, 20.0);
        asm.add(0, 1, -10.0);
        asm.add(1, 0, -10.0);
        asm.add(1, 1, 20.0);
        asm.add(1, 2, -10.0);
        asm.add(2, 1, -10.0);
        asm.add(2, 2, 20.0);
        asm.add(2, 3, -10.0);
        asm.add(3, 2, -10.0);
        asm.add(3, 3, 20.0);
        let k_sparse = asm.to_csc();
        let k_dense = sparse_to_dense(&k_sparse);

        let f = DMatrix::from_column_slice(4, 1, &[0.0, 10.0, 20.0, 0.0]);
        let constrained = vec![0usize, 3];

        // Sparse path
        let x_sparse = solve_sparse_system(&k_sparse, &f, &constrained)
            .expect("sparse solve should succeed");

        // Dense path: manually apply row/col elimination
        let mut k_bc = k_dense.clone();
        let mut f_bc = f.clone();
        for &dof in &constrained {
            for j in 0..4 {
                k_bc[(dof, j)] = 0.0;
                k_bc[(j, dof)] = 0.0;
            }
            k_bc[(dof, dof)] = 1.0;
            f_bc[(dof, 0)] = 0.0;
        }
        let x_dense = solve_dense_lu(&k_bc, &f_bc).expect("dense solve should succeed");

        // Compare: constrained DOFs should be ~0 in both
        assert!(x_sparse[(0, 0)].abs() < 1e-6);
        assert!(x_sparse[(3, 0)].abs() < 1e-6);
        assert!(x_dense[(0, 0)].abs() < 1e-12);
        assert!(x_dense[(3, 0)].abs() < 1e-12);

        // Free DOFs should match closely
        assert!((x_sparse[(1, 0)] - x_dense[(1, 0)]).abs() < 1e-6);
        assert!((x_sparse[(2, 0)] - x_dense[(2, 0)]).abs() < 1e-6);
    }
}
