use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::models::stiffness_curve::StiffnessCurveConfig;
use crate::models::supports::supportconditiontype::SupportConditionType;

#[derive(Debug, Serialize, Deserialize, ToSchema, Clone)]
pub struct SupportCondition {
    pub condition_type: SupportConditionType,
    pub stiffness: Option<f64>,
    /// Optional load-dependent stiffness curve.
    /// When present, the condition behaves as a spring whose stiffness is
    /// interpolated from the curve based on the specified force component
    /// at the owning support node.  Overrides `stiffness` when set.
    #[serde(default)]
    pub stiffness_curve: Option<StiffnessCurveConfig>,
}

impl SupportCondition {
    /// Returns `true` when this condition uses a load-dependent stiffness curve.
    pub fn has_curve(&self) -> bool {
        self.stiffness_curve.is_some()
    }

    pub fn normalize_translation_units(&mut self, f: f64, l: f64) {
        if let Some(k) = &mut self.stiffness {
            *k *= f / l;
        }
        if let Some(ref mut curve) = self.stiffness_curve {
            let force_factor = if curve.depends_on.is_force() { f } else { f * l };
            curve.normalize(force_factor, f / l); // translational stiffness: [F/L]
        }
    }

    pub fn normalize_rotation_units(&mut self, f: f64, l: f64) {
        if let Some(k) = &mut self.stiffness {
            *k *= f * l;
        }
        if let Some(ref mut curve) = self.stiffness_curve {
            let force_factor = if curve.depends_on.is_force() { f } else { f * l };
            curve.normalize(force_factor, f * l); // rotational stiffness: [F·L/rad]
        }
    }

    pub fn normalize_warping_units(&mut self, f: f64, l: f64) {
        if let Some(k) = &mut self.stiffness {
            *k *= f * l * l;
        }
        if let Some(ref mut curve) = self.stiffness_curve {
            let force_factor = if curve.depends_on.is_force() { f } else { f * l };
            curve.normalize(force_factor, f * l * l); // warping: [F·L²/rad]
        }
    }
}
