use serde::{Deserialize, Deserializer, Serialize};
use utoipa::ToSchema;

/// Which internal-force component a stiffness curve depends on.
///
/// Member-local variants (`N`, `Vy`, `Vz`, `Mx`, `My`, `Mz`) are appropriate
/// for **member-hinge** curves where forces are in the member's local axes.
///
/// Global-axis aliases (`Fx`, `Fy`, `Fz`) are provided for **support** stiffness
/// curves, where forces are always in the global coordinate system:
///   - `Fx` = global X reaction (same index as `N`)
///   - `Fy` = global Y reaction (same index as `Vy`)
///   - `Fz` = global Z reaction (same index as `Vz`)
#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq, Eq, ToSchema)]
pub enum ForceComponent {
    /// Axial force (member-local x)
    N,
    /// Shear force in member-local y
    Vy,
    /// Shear force in member-local z
    Vz,
    /// Torsion moment
    Mx,
    /// Bending moment about local-y
    My,
    /// Bending moment about local-z
    Mz,

    // ── Global-axis aliases (for support stiffness curves) ──────────
    /// Global X reaction force (alias for index 0, same as `N`)
    Fx,
    /// Global Y reaction force (alias for index 1, same as `Vy`)
    Fy,
    /// Global Z reaction force (alias for index 2, same as `Vz`)
    Fz,
}

impl ForceComponent {
    /// Index into a 6-element force array [Fx/N, Fy/Vy, Fz/Vz, Mx, My, Mz].
    pub fn index(self) -> usize {
        match self {
            ForceComponent::N | ForceComponent::Fx => 0,
            ForceComponent::Vy | ForceComponent::Fy => 1,
            ForceComponent::Vz | ForceComponent::Fz => 2,
            ForceComponent::Mx => 3,
            ForceComponent::My => 4,
            ForceComponent::Mz => 5,
        }
    }

    /// Returns `true` when this variant represents a force (not a moment).
    pub fn is_force(self) -> bool {
        matches!(
            self,
            ForceComponent::N
                | ForceComponent::Vy
                | ForceComponent::Vz
                | ForceComponent::Fx
                | ForceComponent::Fy
                | ForceComponent::Fz
        )
    }
}

/// A spring stiffness that varies with an internal-force component.
///
/// `points` is a sorted list of `[force_value, stiffness]` pairs.
/// `depends_on` specifies which force component at the owning location
/// (support node or member end) drives the interpolation.
///
/// Backward compatibility: a bare JSON array `[[0,100],[50000,1e7]]` is
/// accepted and treated as `{ depends_on: "Vz", points: [...] }`.
#[derive(Debug, Serialize, Clone, ToSchema)]
pub struct StiffnessCurveConfig {
    /// Which force component the stiffness depends on.
    pub depends_on: ForceComponent,
    /// Sorted `[force_value, stiffness]` pairs (≥ 2 points, positive stiffness).
    pub points: Vec<[f64; 2]>,
}

impl<'de> Deserialize<'de> for StiffnessCurveConfig {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        use serde::de;

        #[derive(Deserialize)]
        struct Full {
            depends_on: ForceComponent,
            points: Vec<[f64; 2]>,
        }

        // Accept either a full object or a bare array of points.
        let value = serde_json::Value::deserialize(deserializer)?;
        if value.is_array() {
            // Legacy: bare array → default to Vz
            let points: Vec<[f64; 2]> =
                serde_json::from_value(value).map_err(de::Error::custom)?;
            Ok(StiffnessCurveConfig {
                depends_on: ForceComponent::Vz,
                points,
            })
        } else {
            let full: Full = serde_json::from_value(value).map_err(de::Error::custom)?;
            Ok(StiffnessCurveConfig {
                depends_on: full.depends_on,
                points: full.points,
            })
        }
    }
}

impl StiffnessCurveConfig {
    /// Linearly interpolate the curve at `force_value`.
    /// Values outside the range are clamped to the nearest boundary stiffness.
    pub fn interpolate(&self, force_value: f64) -> f64 {
        interpolate_stiffness_curve(&self.points, force_value)
    }

    /// Validate the curve data, returning a descriptive error on failure.
    pub fn validate(&self, owner_label: &str, axis_label: &str) -> Result<(), String> {
        validate_stiffness_curve(owner_label, axis_label, &self.points)
    }

    /// Normalize the force-axis (points\[i\]\[0\]) and stiffness-axis (points\[i\]\[1\]).
    pub fn normalize(&mut self, force_factor: f64, stiffness_factor: f64) {
        for point in &mut self.points {
            point[0] *= force_factor;
            point[1] *= stiffness_factor;
        }
    }
}

// ── Free functions (usable without a StiffnessCurveConfig) ──────────────────

/// Linearly interpolate a stiffness curve at the given force value.
/// `points` must have ≥ 2 entries sorted by ascending column 0.
/// Values outside the range are clamped.
pub fn interpolate_stiffness_curve(points: &[[f64; 2]], force_value: f64) -> f64 {
    debug_assert!(points.len() >= 2, "StiffnessCurve must have ≥2 points");

    if force_value <= points[0][0] {
        return points[0][1];
    }
    if force_value >= points[points.len() - 1][0] {
        return points[points.len() - 1][1];
    }
    for i in 0..points.len() - 1 {
        let (x0, y0) = (points[i][0], points[i][1]);
        let (x1, y1) = (points[i + 1][0], points[i + 1][1]);
        if force_value >= x0 && force_value <= x1 {
            let t = (force_value - x0) / (x1 - x0);
            return y0 + t * (y1 - y0);
        }
    }
    points[points.len() - 1][1]
}

/// Validate stiffness curve points.
pub fn validate_stiffness_curve(
    owner_label: &str,
    axis_label: &str,
    points: &[[f64; 2]],
) -> Result<(), String> {
    if points.len() < 2 {
        return Err(format!(
            "{} {} StiffnessCurve must have at least 2 points (got {}).",
            owner_label, axis_label, points.len()
        ));
    }
    for (i, pt) in points.iter().enumerate() {
        if pt[1] <= 0.0 {
            return Err(format!(
                "{} {} StiffnessCurve point {} has non-positive stiffness ({}).",
                owner_label, axis_label, i, pt[1]
            ));
        }
    }
    for i in 1..points.len() {
        if points[i][0] < points[i - 1][0] {
            return Err(format!(
                "{} {} StiffnessCurve points must be sorted ascending \
                 (point {} value={} < point {} value={}).",
                owner_label, axis_label, i, points[i][0], i - 1, points[i - 1][0]
            ));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn deserialize_full_format() {
        let json = r#"{"depends_on":"Vz","points":[[0,1000],[50000,1000000]]}"#;
        let cfg: StiffnessCurveConfig = serde_json::from_str(json).unwrap();
        assert_eq!(cfg.depends_on, ForceComponent::Vz);
        assert_eq!(cfg.points.len(), 2);
    }

    #[test]
    fn deserialize_bare_array_legacy() {
        let json = r#"[[0,1000],[50000,1000000]]"#;
        let cfg: StiffnessCurveConfig = serde_json::from_str(json).unwrap();
        assert_eq!(cfg.depends_on, ForceComponent::Vz);
        assert_eq!(cfg.points.len(), 2);
        assert_eq!(cfg.points[0], [0.0, 1000.0]);
    }

    #[test]
    fn deserialize_support_condition_legacy_type() {
        let json = r#"{
            "condition_type": "StiffnessCurve",
            "stiffness": null,
            "stiffness_curve": [[0,7929],[2000,15775]]
        }"#;
        let cond: crate::models::supports::supportcondition::SupportCondition =
            serde_json::from_str(json).unwrap();
        assert!(matches!(
            cond.condition_type,
            crate::models::supports::supportconditiontype::SupportConditionType::Spring
        ));
        let curve = cond.stiffness_curve.unwrap();
        assert_eq!(curve.depends_on, ForceComponent::Vz);
        assert_eq!(curve.points.len(), 2);
    }

    #[test]
    fn deserialize_global_axis_fy() {
        let json = r#"{"depends_on":"Fy","points":[[0,1000],[50000,1000000]]}"#;
        let cfg: StiffnessCurveConfig = serde_json::from_str(json).unwrap();
        assert_eq!(cfg.depends_on, ForceComponent::Fy);
        assert_eq!(cfg.depends_on.index(), 1); // global Y
        assert_eq!(cfg.points.len(), 2);
    }

    #[test]
    fn global_axis_aliases_match_local() {
        assert_eq!(ForceComponent::Fx.index(), ForceComponent::N.index());
        assert_eq!(ForceComponent::Fy.index(), ForceComponent::Vy.index());
        assert_eq!(ForceComponent::Fz.index(), ForceComponent::Vz.index());
    }

    #[test]
    fn is_force_classification() {
        assert!(ForceComponent::N.is_force());
        assert!(ForceComponent::Fy.is_force());
        assert!(ForceComponent::Fz.is_force());
        assert!(!ForceComponent::Mx.is_force());
        assert!(!ForceComponent::My.is_force());
    }
}
