import sys
import os
from typing import Any, List, Dict, Optional, Iterator
from .base import PIServiceBase
from .config import AFSDKSettings

# Global PI Server object to maintain connection
_pi_server = None

def initialize_af_sdk(settings: AFSDKSettings):
    """Initializes the AF SDK library and connects to the PI Server."""
    global _pi_server
    if _pi_server is not None:
        return _pi_server

    sdk_path = settings.PI_SDK_PATH
    if not sdk_path:
        raise ValueError("PI_SDK_PATH must be provided in settings.")

    try:
        import clr
        if sdk_path not in sys.path:
            sys.path.append(sdk_path)
        
        clr.AddReference("OSIsoft.AFSDK")
        from OSIsoft.AF.PI import PIServers, PIAuthenticationMode
        from OSIsoft.AF import AFConnectionPreference
        from System.Net import NetworkCredential
        
        piServers = PIServers()
        server_name = settings.PI_SERVER_NAME
        
        if not any(s.Name == server_name for s in piServers):
            _pi_server = piServers.Add(server_name)
        else:
            _pi_server = piServers[server_name]
        
        if _pi_server is not None:
            if settings.PI_USERNAME and settings.PI_PASSWORD:
                credential = NetworkCredential(settings.PI_USERNAME, settings.PI_PASSWORD)
                try:
                    _pi_server.Connect(
                        credential,
                        AFConnectionPreference.Any,
                        PIAuthenticationMode.PIUserAuthentication
                    )
                except Exception:
                    # Fallback to Windows Auth
                    _pi_server.Connect(
                        credential,
                        AFConnectionPreference.Any,
                        PIAuthenticationMode.WindowsAuthentication
                    )
            else:
                _pi_server.Connect()
                
            return _pi_server
        else:
            raise Exception(f"PI Server '{server_name}' could not be initialized.")
                
    except Exception as e:
        raise Exception(f"PI SDK Initialization failed: {str(e)}")

class PIAFSDKService(PIServiceBase):
    """
    Implementation of PI Service using PI AF SDK (.NET via pythonnet).
    """

    def __init__(self, settings: AFSDKSettings):
        self.settings = settings
        self.pi_server = initialize_af_sdk(settings)

    def get_current_value(self, tag_name: str) -> Dict[str, Any]:
        """Fetch current value via AF SDK."""
        from OSIsoft.AF.PI import PIPoint
        point = PIPoint.FindPIPoint(self.pi_server, tag_name)
        last_value = point.CurrentValue()
        return {
            "tag": tag_name, 
            "value": last_value.Value, 
            "timestamp": str(last_value.Timestamp), 
            "provider": "AFSDK"
        }

    def get_recorded_values(self, tag_name: str, start_time: str, end_time: str) -> List[Dict[str, Any]]:
        """Fetch historical values via AF SDK."""
        from OSIsoft.AF.PI import PIPoint
        from OSIsoft.AF.Time import AFTimeRange
        from OSIsoft.AF.Data import AFBoundaryType
        
        point = PIPoint.FindPIPoint(self.pi_server, tag_name)
        timerange = AFTimeRange(start_time, end_time)
        values = point.RecordedValues(timerange, AFBoundaryType.Inside, "", False)
        
        return [{"timestamp": str(v.Timestamp), "value": v.Value} for v in values]

    def write_value(self, tag_name: str, value: Any, timestamp: Any = None) -> bool:
        """Write value via AF SDK."""
        from OSIsoft.AF.PI import PIPoint
        from OSIsoft.AF.Asset import AFValue
        from OSIsoft.AF.Time import AFTime
        from OSIsoft.AF.Data import AFUpdateOption

        point = PIPoint.FindPIPoint(self.pi_server, tag_name)
        val = AFValue(value, AFTime(timestamp or "*"))
        point.UpdateValue(val, AFUpdateOption.Replace)
        return True

    def search_tags(self, query: str) -> List[str]:
        """Search tags via AF SDK."""
        from OSIsoft.AF.PI import PIPoint
        points = PIPoint.FindPIPoints(self.pi_server, query, None, None)
        return [p.Name for p in points]

    def get_asset_servers(self) -> List[str]:
        """Fetch AF Asset Server names via AF SDK."""
        from OSIsoft.AF import PISystems
        systems = PISystems()
        return [s.Name for s in systems]

    def get_organizations(self, asset_server: str) -> List[str]:
        """Fetch AF Database names for a given Asset Server."""
        from OSIsoft.AF import PISystems
        from System.Net import NetworkCredential
        
        systems = PISystems()
        system = systems[asset_server]
        
        if system is None:
            return []

        if not system.ConnectionInfo.IsConnected:
            if self.settings.PI_USERNAME and self.settings.PI_PASSWORD:
                credential = NetworkCredential(self.settings.PI_USERNAME, self.settings.PI_PASSWORD)
                try:
                    system.Connect(credential)
                except:
                    system.Connect()
            else:
                system.Connect()

        return [db.Name for db in system.Databases]

    def test_connection(self) -> Dict[str, Any]:
        """Test AF SDK connection status."""
        try:
            self.pi_server.Connect()
            return {
                "status": "connected", 
                "type": "AFSDK", 
                "server": self.settings.PI_SERVER_NAME,
                "connected": True
            }
        except Exception as e:
            return {"status": "failed", "type": "AFSDK", "error": str(e)}

    def get_multiple_current_values(self, tag_names: List[str]) -> List[Dict[str, Any]]:
        """Fetch current values for multiple PI tags at once."""
        from OSIsoft.AF.PI import PIPoint, PIPointList
        
        point_list = PIPointList()
        found_tags = []
        for tag in tag_names:
            try:
                point = PIPoint.FindPIPoint(self.pi_server, tag)
                if point:
                    point_list.Add(point)
                    found_tags.append(tag)
            except:
                continue

        if not found_tags:
            return []

        af_values = point_list.CurrentValue()
        
        return [
            {
                "tag": found_tags[i], 
                "value": v.Value, 
                "timestamp": str(v.Timestamp), 
                "provider": "AFSDK"
            } 
            for i, v in enumerate(af_values)
        ]

    def get_live_data_stream(self, tag_names: List[str], frequency: float) -> Iterator[List[Dict[str, Any]]]:
        """Fetch live data stream for multiple PI tags at a given frequency."""
        import time
        while True:
            yield self.get_multiple_current_values(tag_names)
            time.sleep(frequency)

    def disconnect(self):
        """Disconnect from the PI Server."""
        if self.pi_server:
            self.pi_server.Disconnect()
