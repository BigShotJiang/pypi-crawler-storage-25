"""Persistent todo-list context injection (P1.6).

The agent loop injects the current todo list as a synthetic system message
on every iteration so the model can see and update it. The block sits
AFTER the cacheable system+tools prefix and BEFORE conversation history,
so DeepSeek's prefix cache (and Anthropic's `cache_control` later) still
hit on the prefix while the todo block consumes a small number of fresh
tokens per turn.

Sentinel: every injected block starts with `# Todos (current)`. Subsequent
turns detect that prefix in messages[1:N] and replace the prior block to
keep the messages list bounded.
"""
from __future__ import annotations

import re

from fred.tools.todo import TodoItem, get_todos

# Glyphs match Renderer.show_todos rendering (see render.py).
_GLYPH = {
    "pending": "☐",
    "in_progress": "◐",
    "completed": "☑",
}

# Sentinel: any system message whose content begins with this header is
# treated as a previously-injected todo block and replaced on re-injection.
TODO_BLOCK_HEADER = "# Todos (current)"

# Multi-step heuristics for the auto-seed nudge.
_FIRST_THEN_RE = re.compile(r"\bfirst\b.*?\bthen\b", re.IGNORECASE | re.DOTALL)
_STEP_N_RE = re.compile(r"\bstep\s+\d+\b", re.IGNORECASE)
_NUMBERED_LINE_RE = re.compile(r"(?m)^\s*1[\.\)]\s+\S")
_SENTENCE_SPLIT_RE = re.compile(r"[.!?](?:\s+|$)")


def render_todo_block(
    todos: list[TodoItem] | None = None,
    *,
    auto_seed_nudge: bool = False,
) -> str:
    """Build the markdown block injected as a system message each turn.

    `todos` is fetched from `fred.tools.todo.get_todos()` when None — passing
    it explicitly is for tests and headless callers.

    `auto_seed_nudge` adds a one-shot reminder at the top of an empty list
    when the user's first prompt looked multi-step. Gated by the caller
    (env `FRED_AUTO_SEED_TODOS=1`); off by default.
    """
    if todos is None:
        todos = get_todos()
    lines = [TODO_BLOCK_HEADER]
    if not todos:
        if auto_seed_nudge:
            lines.append(
                "_(this looks like a multi-step task — consider calling "
                "todo_write to outline the steps)_"
            )
        else:
            lines.append(
                "_(empty — seed with todo_write if this task has more than "
                "one step)_"
            )
    else:
        for t in todos:
            glyph = _GLYPH.get(t.status, _GLYPH["pending"])
            lines.append(f"{glyph} {t.content}")
    return "\n".join(lines)


def is_todo_block_message(message: dict) -> bool:
    """True if `message` is a previously-injected todo system message.

    Detection is by sentinel content prefix. Robust against multiple
    re-injections per turn — only the LAST injected block remains.
    """
    if message.get("role") != "system":
        return False
    content = message.get("content")
    if not isinstance(content, str):
        return False
    return content.startswith(TODO_BLOCK_HEADER)


def inject_todo_block(
    messages: list[dict],
    *,
    todos: list[TodoItem] | None = None,
    auto_seed_nudge: bool = False,
) -> tuple[list[dict], int]:
    """Return a new messages list with the todo block injected.

    Position: AFTER the leading cacheable prefix (system + any prior
    cacheable system messages) and BEFORE any user/assistant/tool history.
    In practice that means right after the FIRST contiguous run of system
    messages that are NOT prior todo-block injections.

    Behavior:
    - If a prior todo-block system message exists in `messages`, it is
      removed before the fresh one is inserted (no duplicates).
    - If `messages` has no leading system message, the todo block is
      inserted at index 0.
    - Returns `(new_messages, injected_chars)` where `injected_chars` is
      `len(block.encode("utf-8"))` for telemetry.

    Does NOT mutate the input list.
    """
    block = render_todo_block(todos=todos, auto_seed_nudge=auto_seed_nudge)
    injected_chars = len(block.encode("utf-8"))

    # Strip any prior injection(s) so the list stays bounded.
    cleaned = [m for m in messages if not is_todo_block_message(m)]

    # Find the index AFTER the leading run of system messages.
    insert_at = 0
    for i, m in enumerate(cleaned):
        if m.get("role") == "system":
            insert_at = i + 1
        else:
            break

    out = list(cleaned)
    out.insert(insert_at, {"role": "system", "content": block})
    return out, injected_chars


def _should_auto_seed(user_input: str) -> bool:
    """Heuristic: does the user prompt look like a multi-step task?

    Triggers on any of:
    - more than 3 sentences (terminal . ! ? followed by whitespace or EOS)
    - contains "first ... then" (case-insensitive, may span newlines)
    - contains "step N" (e.g. "step 1", "step 2")
    - contains a numbered list line beginning with "1." or "1)"

    Single-action requests fall through to False.
    """
    if not user_input or not user_input.strip():
        return False
    if _FIRST_THEN_RE.search(user_input):
        return True
    if _STEP_N_RE.search(user_input):
        return True
    if _NUMBERED_LINE_RE.search(user_input):
        return True
    # Sentence count: split on sentence terminators followed by whitespace
    # (or end-of-string). Filter out empty fragments.
    parts = [p for p in _SENTENCE_SPLIT_RE.split(user_input) if p.strip()]
    if len(parts) > 3:
        return True
    return False


def todos_state_payload(todos: list[TodoItem], injected_chars: int) -> dict:
    """Build the per-turn `todos_state` telemetry payload.

    Counts pending / in_progress / completed; includes the byte-length of
    the injected block so we can correlate context budget against todo
    presence. Schema is additive — `fred_events.payload` is JSONB, so new
    fields can join later without a migration.
    """
    pending = sum(1 for t in todos if t.status == "pending")
    in_progress = sum(1 for t in todos if t.status == "in_progress")
    completed = sum(1 for t in todos if t.status == "completed")
    return {
        "count_total": len(todos),
        "count_pending": pending,
        "count_in_progress": in_progress,
        "count_completed": completed,
        "injected_chars": injected_chars,
    }
