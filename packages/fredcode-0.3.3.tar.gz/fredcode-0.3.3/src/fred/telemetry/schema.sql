-- fred telemetry schema. Idempotent: safe to re-run.
-- Mirrored as a Python string in writer.py (`SCHEMA_DDL`); keep in sync.

CREATE TABLE IF NOT EXISTS fred_sessions (
  session_id           UUID PRIMARY KEY,
  started_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ended_at             TIMESTAMPTZ,
  end_reason           TEXT,
  fred_version          TEXT NOT NULL,
  python_version       TEXT NOT NULL,
  os                   TEXT NOT NULL,
  shell                TEXT,
  cwd                  TEXT NOT NULL,
  git_commit           TEXT,
  git_dirty            BOOLEAN,
  agents_md_sha256     TEXT,
  model                TEXT NOT NULL,
  base_url             TEXT NOT NULL,
  yolo_initial         BOOLEAN NOT NULL,
  one_shot             BOOLEAN NOT NULL,
  system_prompt_sha256 TEXT NOT NULL,
  system_prompt_text   TEXT,
  client_pid           INTEGER NOT NULL,
  hostname             TEXT,
  tool_catalog         JSONB NOT NULL,
  -- P0.1: parent/child session graph for subagents (P2.1) and plan mode (P2.2).
  -- `parent_session_id` is NULL for root sessions; `session_kind` is one of
  -- 'root' | 'subagent' | 'plan' (additive — new kinds can be appended).
  parent_session_id    UUID NULL REFERENCES fred_sessions(session_id) ON DELETE CASCADE,
  session_kind         TEXT NOT NULL DEFAULT 'root',
  -- P2.3: snapshot of the multi-model routing slots (`main_model`,
  -- `editor_model`, `weak_model`) plus any other start-time config
  -- (e.g. `run_mode`). NULL is allowed so older sessions remain valid.
  -- Lets analysis group iterations by which slot they used.
  config_snapshot      JSONB
);
-- Older deployments may have created `fred_sessions` before P0.1; add the
-- new columns idempotently. Postgres 9.6+ supports IF NOT EXISTS on ADD COLUMN.
ALTER TABLE fred_sessions ADD COLUMN IF NOT EXISTS parent_session_id UUID NULL
  REFERENCES fred_sessions(session_id) ON DELETE CASCADE;
ALTER TABLE fred_sessions ADD COLUMN IF NOT EXISTS session_kind TEXT NOT NULL DEFAULT 'root';
ALTER TABLE fred_sessions ADD COLUMN IF NOT EXISTS config_snapshot JSONB;
CREATE INDEX IF NOT EXISTS idx_sessions_started ON fred_sessions (started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_version ON fred_sessions (fred_version, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_model   ON fred_sessions (model, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_parent  ON fred_sessions (parent_session_id) WHERE parent_session_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS fred_turns (
  turn_id                  UUID PRIMARY KEY,
  session_id               UUID NOT NULL REFERENCES fred_sessions(session_id) ON DELETE CASCADE,
  turn_index               INTEGER NOT NULL,
  iteration_index          INTEGER NOT NULL,
  started_at               TIMESTAMPTZ NOT NULL,
  ended_at                 TIMESTAMPTZ,
  user_input               TEXT,
  user_input_truncated     BOOLEAN NOT NULL DEFAULT FALSE,
  assistant_text           TEXT,
  assistant_text_truncated BOOLEAN NOT NULL DEFAULT FALSE,
  finish_reason            TEXT,
  prompt_tokens            INTEGER,
  completion_tokens        INTEGER,
  cached_tokens            INTEGER,
  context_used_est         INTEGER,
  budget_status            TEXT,
  api_error_type           TEXT,
  api_error_message        TEXT,
  duration_ms              INTEGER,
  num_tool_calls           INTEGER NOT NULL DEFAULT 0,
  -- P2.2: plan vs act mode for this iteration. Additive; defaults to
  -- 'act' so legacy rows + paths keep working unchanged.
  mode                     TEXT NOT NULL DEFAULT 'act',
  -- Multi-model routing slot the iteration consumed. One of
  -- main|editor|weak|subagent_main. Subagents emit `subagent_main` so
  -- analytics can attribute child-agent spend separately. Pre-wireup
  -- rows backfill as 'main' (semantically correct).
  slot                     TEXT NOT NULL DEFAULT 'main',
  -- Concrete model name behind the slot at iteration time (denormalized
  -- so per-row cost reconstruction stays valid even after `/model`
  -- swaps mid-session). NULL for legacy rows / NullTracer paths.
  model                    TEXT,
  -- Billed cost in microcents, computed at write time from the active
  -- rate card. NULL when usage was unavailable (early API errors,
  -- NullTracer). Mirrors the `web_research_chain` event's convention.
  cost_billed_microcents   BIGINT
);
CREATE INDEX IF NOT EXISTS idx_turns_session ON fred_turns (session_id, turn_index, iteration_index);
CREATE INDEX IF NOT EXISTS idx_turns_errors  ON fred_turns (api_error_type) WHERE api_error_type IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_turns_finish  ON fred_turns (finish_reason);

CREATE TABLE IF NOT EXISTS fred_tool_calls (
  tool_call_id             UUID PRIMARY KEY,
  turn_id                  UUID NOT NULL REFERENCES fred_turns(turn_id) ON DELETE CASCADE,
  session_id               UUID NOT NULL,
  call_index               INTEGER NOT NULL,
  openai_call_id           TEXT NOT NULL,
  tool_name                TEXT NOT NULL,
  args                     JSONB,
  raw_arguments            TEXT,
  parse_error              TEXT,
  args_fingerprint         TEXT NOT NULL,
  permission_outcome       TEXT,
  permission_prompt_ms     INTEGER,
  outcome                  TEXT NOT NULL,
  handler_exception_type   TEXT,
  result_text              TEXT,
  result_truncated         BOOLEAN NOT NULL DEFAULT FALSE,
  result_full_bytes        INTEGER,
  result_starts_with_error BOOLEAN NOT NULL,
  duration_ms              INTEGER NOT NULL,
  started_at               TIMESTAMPTZ NOT NULL,
  ended_at                 TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tool_calls_session   ON fred_tool_calls (session_id, started_at);
CREATE INDEX IF NOT EXISTS idx_tool_calls_turn      ON fred_tool_calls (turn_id, call_index);
CREATE INDEX IF NOT EXISTS idx_tool_calls_failures  ON fred_tool_calls (tool_name, outcome) WHERE outcome <> 'ok';
CREATE INDEX IF NOT EXISTS idx_tool_calls_loops     ON fred_tool_calls (session_id, args_fingerprint);
CREATE INDEX IF NOT EXISTS idx_tool_calls_perm_deny ON fred_tool_calls (tool_name) WHERE permission_outcome = 'user_n';

CREATE TABLE IF NOT EXISTS fred_events (
  event_id   BIGSERIAL PRIMARY KEY,
  session_id UUID NOT NULL REFERENCES fred_sessions(session_id) ON DELETE CASCADE,
  turn_id    UUID,
  ts         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  kind       TEXT NOT NULL,
  payload    JSONB
);
CREATE INDEX IF NOT EXISTS idx_events_session ON fred_events (session_id, ts);
CREATE INDEX IF NOT EXISTS idx_events_kind    ON fred_events (kind, ts);

-- P0.1: recursive view from each root session down through its descendants.
-- Used by `/cost` aggregation and any cross-subagent rollup query (P2.1).
-- `depth = 0` rows pair a root with itself so a parent's own tokens roll
-- into its tree total without a separate UNION at query time.
CREATE OR REPLACE VIEW fred_session_tree AS
WITH RECURSIVE tree(root_session_id, descendant_session_id, depth) AS (
  SELECT session_id, session_id, 0
  FROM fred_sessions
  WHERE parent_session_id IS NULL
  UNION ALL
  SELECT t.root_session_id, s.session_id, t.depth + 1
  FROM fred_sessions s
  JOIN tree t ON s.parent_session_id = t.descendant_session_id
)
SELECT root_session_id, descendant_session_id, depth FROM tree;

-- P2.1: cost rollup that sums tokens across each root session's whole
-- subtree (root + every descendant subagent). Joins `fred_session_tree`
-- to `fred_turns` so iteration-level token counts (which already exist)
-- aggregate without double-counting the root's own iterations.
-- Selecting from this view gives one row per root session with the
-- whole-tree totals — used by `cost_summary()` to surface subagent
-- spend against the parent.
CREATE OR REPLACE VIEW fred_session_cost_rollup AS
SELECT
  st.root_session_id,
  COUNT(DISTINCT st.descendant_session_id) AS session_count,
  COALESCE(SUM(t.prompt_tokens), 0)         AS total_prompt_tokens,
  COALESCE(SUM(t.completion_tokens), 0)     AS total_completion_tokens,
  COALESCE(SUM(t.cached_tokens), 0)         AS total_cached_tokens,
  COALESCE(SUM(t.duration_ms), 0)           AS total_duration_ms
FROM fred_session_tree st
LEFT JOIN fred_turns t ON t.session_id = st.descendant_session_id
GROUP BY st.root_session_id;
