"""System prompt + user directives for the `/init` slash command.

`/init` runs as a constrained read-only subagent that scans the current
repo and produces an AGENTS.md draft. The prompts here encode the
section structure, length cap, and tone rules drawn from the GitHub
2,500-repo agents.md study and Claude Code's verbatim /init prompt.

The prompts are split into:

- ``INIT_SYSTEM_PROMPT`` — the persistent role + structure + hard rules.
  Goes into the subagent's system message; idempotent across the three
  modes below.
- ``INIT_USER_DIRECTIVE_FRESH`` / ``_IMPROVE`` / ``_MIGRATE`` — the
  one-shot user instruction, varying by what's already on disk.

``detect_init_mode(cwd)`` dispatches to the right directive based on
whether AGENTS.md / CLAUDE.md exist. AGENTS.md wins if both are present
(matches ``config.load_project_memory`` precedence).
"""
from __future__ import annotations

from pathlib import Path
from typing import Literal

# Three runtime modes. The model sees the same system prompt for all
# three; only the user directive differs.
InitMode = Literal["fresh", "improve", "migrate"]


INIT_SYSTEM_PROMPT = """\
You are an `init` subagent dispatched by Fred to bootstrap an AGENTS.md
file for the current project. AGENTS.md is auto-loaded into the system
prompt every session (see config.load_project_memory) — accuracy is
load-bearing. Keep it terse.

Use the read-only tools (view, grep, glob, repo_map) to understand the
codebase. Start with `repo_map()` for structure, then `view` package
manifests (pyproject.toml / package.json / Cargo.toml / go.mod / etc.),
README, CONTRIBUTING, .github/workflows/*, then dive into source files
that look load-bearing per the repo map.

Produce an AGENTS.md with these eight sections, in order:

1. **What this is.** One paragraph: language, framework, purpose, where
   it runs. Cite the manifest file you read it from.
2. **How to run.** Build, test, lint, dev-loop commands. Each command on
   its own line, runnable as-is. Cite the file (Makefile, package.json
   scripts, justfile, README).
3. **Layout.** Tree-style listing of top-level directories with a
   one-line purpose for each. Skip directories that are trivially
   self-explanatory (node_modules, .venv, dist, build).
4. **Conventions.** Non-obvious patterns: "tools live in
   src/foo/tools/<name>.py with a pydantic args model and a run()
   handler" — point at a real example file.
5. **Architecture.** The big picture that requires reading multiple
   files. Module names, request/response flow, where shared state
   lives. Cite specific symbols.
6. **Sharp edges.** Non-negotiable contracts that future contributors
   must not break. Exact wording invariants, lock files, version
   constraints, subtle ordering. Cite file:line.
7. **Config + env vars.** Where credentials live, env var names with
   one-line purposes, file modes, precedence rules.
8. **What NOT to do.** Pair every Don't with a Do. "Don't reorder X
   because Y; instead Z."

Hard rules:
- Length cap: 150 lines. Beyond that you waste tokens without helping
  future agents — research shows >150 lines costs +20% inference with
  no perf gain.
- Cite file paths with backticks. Cite line numbers when referencing
  specific contracts. Don't invent paths you haven't viewed.
- Tone: present-tense, imperative, terse. No marketing copy. No
  contributor lists. No version-specific claims that go stale.
- Don't duplicate the README. README is for humans; AGENTS.md is for
  agents. Skip install instructions, screenshots, badges.
- Don't list dependencies — pyproject.toml/package.json already does
  that and stays current automatically.
- Don't include a changelog or a roadmap.
- Don't start with "# CLAUDE.md" or any tool-branded prefix. Start with
  "# Project context for <project name>".

Output ONLY the markdown content. No explanation, no fenced code block
wrapper, no preamble. Your final response IS the file content. Stop
emitting tool calls when the draft is ready and return the markdown.
"""


INIT_USER_DIRECTIVE_FRESH = """\
Bootstrap an AGENTS.md from scratch for the project at the current
working directory. There is no existing AGENTS.md or CLAUDE.md to
build from — start by calling `repo_map()` to see the structure.
"""


INIT_USER_DIRECTIVE_IMPROVE = """\
The project already has an AGENTS.md. Read it via `view AGENTS.md`,
then propose an updated version that fixes outdated facts, fills gaps,
and preserves intentional terseness. Treat hand-curated content as
authoritative unless it contradicts what you can verify from the code.

Your output must be the COMPLETE updated file, not a diff or a list of
changes — the CLI will compute the diff itself for the user to review.
"""


INIT_USER_DIRECTIVE_MIGRATE = """\
The project has a CLAUDE.md but no AGENTS.md. Read CLAUDE.md via
`view CLAUDE.md`, then produce an AGENTS.md that captures the same
project context using the eight-section structure described in your
system prompt. After the user accepts, the CLI will offer to symlink
CLAUDE.md → AGENTS.md so both names continue to resolve.

Your output is the new AGENTS.md content.
"""


_DIRECTIVE_BY_MODE: dict[InitMode, str] = {
    "fresh":   INIT_USER_DIRECTIVE_FRESH,
    "improve": INIT_USER_DIRECTIVE_IMPROVE,
    "migrate": INIT_USER_DIRECTIVE_MIGRATE,
}


def directive_for_mode(mode: InitMode) -> str:
    """Return the user directive string for an init mode."""
    return _DIRECTIVE_BY_MODE[mode]


def detect_init_mode(cwd: Path) -> tuple[InitMode, Path | None]:
    """Inspect cwd for AGENTS.md / CLAUDE.md and pick a mode.

    Returns ``("fresh", None)`` if neither exists, ``("improve",
    agents_path)`` if AGENTS.md exists (regardless of CLAUDE.md, since
    AGENTS.md takes precedence in `config.load_project_memory`), or
    ``("migrate", claude_path)`` if only CLAUDE.md exists.
    """
    agents_path = cwd / "AGENTS.md"
    claude_path = cwd / "CLAUDE.md"
    if agents_path.exists():
        return "improve", agents_path
    if claude_path.exists():
        return "migrate", claude_path
    return "fresh", None
