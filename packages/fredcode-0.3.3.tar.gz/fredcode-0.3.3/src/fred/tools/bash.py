"""bash tool: stream a shell command, capture combined stdout+stderr.

Implementation notes:

* ``subprocess.Popen`` with ``stderr=STDOUT`` merges both streams onto a
  single pipe. ``selectors`` would let us read each stream separately, but
  for a tool whose only consumer is a model that wants merged interleaved
  output, the extra plumbing buys nothing. ``bufsize=1`` (line-buffered)
  is intentional: Aider's reference reads char-by-char with ``bufsize=0``
  to surface partial-line spinners; we trade that for cheaper drains and
  fewer syscalls. Failures still surface promptly because the daemon
  drain thread keeps reading and a final flush happens on close.
* ``start_new_session=True`` puts the child in its own process group so a
  timeout can ``killpg(SIGTERM)`` then escalate to ``SIGKILL`` cleanly.
* A daemon thread drains ``process.stdout`` line-by-line, calling an
  optional ``on_line`` callback (registered via a ContextVar by
  agent.py) and accumulating into a buffer for the final return.
* ANSI escapes are stripped from the model-facing return; ``rich``
  understands ANSI and the user's terminal preserves them via the
  separate result-card render path.
* Truncation uses head+tail (25k each by default) so that compile/test
  failure tails are never thrown away to keep the head.
* ``cwd`` is validated against the project root (``Path.cwd()`` of the
  fred process at module-import time) — defends against the model
  accidentally reading or writing outside the workspace.
* P4.1: ``_sandbox.wrap_command`` optionally wraps the cmd in
  ``/usr/bin/sandbox-exec -p <profile>`` on macOS. Two-axis design —
  sandbox enforces ground truth via OS, approval is the y/n/a/d Panel
  (lives in permissions.py). Linux falls through unchanged. The mode is
  read at run-time from ``current_sandbox_mode()`` (env / settings.json /
  CLI flag), so different sessions can run with different modes without
  reload.
"""
from __future__ import annotations

import contextvars
import os
import signal
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable

from pydantic import BaseModel, Field

from fred.tools._sandbox import (
    current_sandbox_mode,
    record_invocation_stats,
    wrap_command,
)
from fred.tools._text_utils import strip_ansi, truncate_head_tail
from fred.tools.base import Tool

# ---------------------------------------------------------------------------
# Streaming callback wiring (avoids changing Tool.handler's signature).
#
# agent.py sets this ContextVar before dispatching a bash call so that the
# drain thread can ping the renderer/tracer per N lines. The bash drain
# thread calls ``get()`` once at start and reuses the bound callable so
# the contextvar lookup overhead happens only once per invocation.
# ---------------------------------------------------------------------------
_BASH_ON_LINE: contextvars.ContextVar[Callable[[str], None] | None] = (
    contextvars.ContextVar("fred_bash_on_line", default=None)
)
# After-call telemetry hook. agent.py reads this immediately after the
# bash dispatch returns and ships it as a `bash_complete` tracer event.
# Keeps the handler signature unchanged (it still returns ``str``).
_LAST_STATS: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "fred_bash_last_stats", default=None
)


def set_on_line(cb: Callable[[str], None] | None) -> contextvars.Token:
    """Register a per-line callback for the next bash call.

    Returns a token that callers should pass back to ``reset_on_line`` in
    a try/finally so the contextvar is always cleared.
    """
    return _BASH_ON_LINE.set(cb)


def reset_on_line(token: contextvars.Token) -> None:
    _BASH_ON_LINE.reset(token)


def consume_last_stats() -> dict | None:
    """Return + clear the most-recent bash-call stats dict (if any)."""
    s = _LAST_STATS.get()
    if s is not None:
        _LAST_STATS.set(None)
    return s


# Project root captured once at module import. Re-resolve via Path so the
# absolute form is stable.
_PROJECT_ROOT: Path = Path.cwd().resolve()


def _project_root() -> Path:
    return _PROJECT_ROOT


def _is_under_root(p: Path, root: Path) -> bool:
    """Path-traversal-safe membership check."""
    try:
        p.resolve().relative_to(root)
        return True
    except (ValueError, OSError):
        return False


class BashArgs(BaseModel):
    command: str = Field(..., description="Shell command to execute (interpreted by /bin/sh -c).")
    timeout_sec: int = Field(60, ge=1, le=600, description="Kill the command after this many seconds.")
    cwd: str | None = Field(
        None,
        description=(
            "Optional working directory for the command. Must be inside the "
            "project root. Defaults to the fred process cwd."
        ),
    )


def _drain_stdout(
    proc: subprocess.Popen,
    on_line: Callable[[str], None] | None,
    sink: list[str],
) -> None:
    """Daemon-thread body. Read until EOF, append every line, fire on_line."""
    assert proc.stdout is not None  # bufsize=1 + text=True guarantees this
    try:
        for line in proc.stdout:
            sink.append(line)
            if on_line is not None:
                try:
                    on_line(line)
                except Exception:
                    # Streaming callback errors must never poison the drain
                    # thread (which would leave stdout's pipe-buffer to fill
                    # and deadlock the child).
                    pass
    finally:
        try:
            proc.stdout.close()
        except Exception:
            pass


def _kill_pg(pgid: int, sig: int) -> None:
    try:
        os.killpg(pgid, sig)
    except ProcessLookupError:
        pass
    except OSError:
        pass


def run(args: BashArgs) -> str:
    # cwd validation — reject paths outside the project root.
    cwd: str | None = None
    if args.cwd is not None:
        try:
            cand = Path(args.cwd).expanduser()
        except (RuntimeError, ValueError):
            return f"Error: invalid cwd {args.cwd!r}"
        if not cand.exists() or not cand.is_dir():
            return f"Error: cwd does not exist or is not a directory: {args.cwd}"
        if not _is_under_root(cand, _project_root()):
            return f"Error: cwd outside project root: {args.cwd}"
        cwd = str(cand.resolve())

    on_line = _BASH_ON_LINE.get()
    sink: list[str] = []
    started = time.perf_counter()
    timed_out = False

    # P4.1: optional Seatbelt wrap. Returns the original cmd on Linux /
    # when sandbox-exec is unavailable; the wrapped argv when wrapping
    # was applied. We keep ``shell=True`` for the un-wrapped path so the
    # legacy behavior is bit-identical; ``shell=False`` is required for
    # the wrapped path because we're invoking sandbox-exec directly.
    sandbox_mode = current_sandbox_mode()
    wrapped, profile = wrap_command(args.command, sandbox_mode, _project_root())
    record_invocation_stats({
        "mode": sandbox_mode,
        "wrapped": isinstance(wrapped, list),
        "command_chars": len(args.command),
    })

    try:
        if isinstance(wrapped, list):
            proc = subprocess.Popen(
                wrapped,
                shell=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
                cwd=cwd,
            )
        else:
            proc = subprocess.Popen(
                wrapped,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
                cwd=cwd,
            )
    except (OSError, ValueError) as e:
        return f"Error: failed to start command: {type(e).__name__}: {e}"

    drain = threading.Thread(
        target=_drain_stdout,
        args=(proc, on_line, sink),
        name="fred-bash-drain",
        daemon=True,
    )
    drain.start()

    try:
        proc.wait(timeout=args.timeout_sec)
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            pgid = os.getpgid(proc.pid)
        except ProcessLookupError:
            pgid = None
        if pgid is not None:
            _kill_pg(pgid, signal.SIGTERM)
        try:
            proc.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            if pgid is not None:
                _kill_pg(pgid, signal.SIGKILL)
            try:
                proc.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                pass

    # Wait briefly for the drain thread to finish surfacing any tail lines
    # the kernel had buffered. The daemon flag means we don't risk hanging
    # forever.
    drain.join(timeout=2.0)

    elapsed_ms = int((time.perf_counter() - started) * 1000)
    raw = "".join(sink)
    raw_chars = len(raw)
    stripped = strip_ansi(raw)
    ansi_stripped_chars = raw_chars - len(stripped)
    out = truncate_head_tail(stripped, head=25_000, tail=25_000)
    head_kept = min(25_000, len(stripped))
    tail_kept = min(25_000, max(0, len(stripped) - head_kept))
    lines_total = len(sink)
    code = proc.returncode

    # Stash bookkeeping for the dispatch path / agent.py to ship as a
    # tracer event. ContextVar avoids changing the handler return type.
    # P4.1 additively records the sandbox_mode so the fred_tool_calls
    # JSONB payload can be queried for "what fraction of bash calls ran
    # under workspace-write?" without a schema change.
    stats = {
        "ansi_stripped_chars": ansi_stripped_chars,
        "head_kept": head_kept,
        "tail_kept": tail_kept,
        "exit_code": code,
        "lines_total": lines_total,
        "duration_ms": elapsed_ms,
        "timed_out": timed_out,
        "sandbox_mode": sandbox_mode,
    }
    _LAST_STATS.set(stats)

    if timed_out:
        prefix = f"Error: command timed out after {args.timeout_sec}s\n"
        return prefix + (out or "[no output]")

    if code is None:
        # Process hadn't exited cleanly; treat as failure.
        body = out or "[no output]"
        return f"[exit ?]\n{body}"
    if code != 0:
        body = out or "[no output]"
        return f"[exit {code}]\n{body}"
    return out or "[no output]"


tool = Tool(
    name="bash",
    description=(
        "Run a shell command via /bin/sh -c and return combined stdout+stderr. "
        "Output is line-streamed and capped with head+tail truncation (~50KB) "
        "so failure output near the tail is preserved. ANSI escape codes are "
        "stripped from the captured output. "
        "Use the optional `cwd` parameter to run the command in a specific "
        "directory inside the project root; `cd` does NOT persist between "
        "calls. Default timeout is 60s, adjustable up to 600s."
    ),
    args_model=BashArgs,
    handler=run,
    requires_permission=True,
)
