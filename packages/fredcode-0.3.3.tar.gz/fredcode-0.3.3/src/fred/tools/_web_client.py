"""Session-scoped accessor for the active DSClient.

Web research tools (`web_search`, `web_fetch`) need to call the proxy at
`/v1/web/{search,extract}` but the existing tool-handler signature is
``(args: BaseModel) -> str`` — the handler doesn't receive the client.
We expose the running session's client via a ContextVar that ``run_session``
sets at entry and clears on exit.

Tests can override this directly with ``set_active_client(stub)``.
"""
from __future__ import annotations

import contextvars
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fred.client import DSClient

_ACTIVE_CLIENT: contextvars.ContextVar["DSClient | None"] = contextvars.ContextVar(
    "fred_active_client", default=None,
)


def set_active_client(client: "DSClient | None") -> contextvars.Token:
    return _ACTIVE_CLIENT.set(client)


def reset_active_client(token: contextvars.Token) -> None:
    _ACTIVE_CLIENT.reset(token)


def get_active_client() -> "DSClient | None":
    return _ACTIVE_CLIENT.get()
