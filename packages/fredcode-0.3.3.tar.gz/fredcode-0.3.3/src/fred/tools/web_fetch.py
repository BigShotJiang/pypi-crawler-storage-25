"""web_fetch tool: Tavily /extract via the FredWeb proxy.

Fetches up to 20 URLs at once and returns concatenated cleaned content.
Server-side billed; CLI-side capped at 100KB total to prevent context blowup.
"""
from __future__ import annotations

import contextvars
import time
from typing import Literal

import httpx
from pydantic import BaseModel, Field

from fred.tools._web_client import get_active_client
from fred.tools.base import Tool, truncate

HARD_BYTE_CAP = 100_000

_LAST_STATS: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "fred_web_fetch_last_stats", default=None,
)


def consume_last_stats() -> dict | None:
    s = _LAST_STATS.get()
    if s is not None:
        _LAST_STATS.set(None)
    return s


class WebFetchArgs(BaseModel):
    urls: list[str] = Field(..., min_length=1, max_length=20)
    extract_depth: Literal["basic", "advanced"] = "basic"
    format: Literal["markdown", "text"] = "markdown"
    include_images: bool = False


def _int_header(headers: dict, name: str) -> int | None:
    v = headers.get(name) or headers.get(name.lower())
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def run(args: WebFetchArgs) -> str:
    client = get_active_client()
    if client is None:
        return (
            "Error: web_fetch has no active client. This is a Fred bug — "
            "tool dispatch ran outside `run_session`."
        )

    body = args.model_dump(exclude_none=True)
    t0 = time.perf_counter()
    base_stats = {
        "urls_requested": len(args.urls),
        "extract_depth": args.extract_depth,
        "format": args.format,
        "include_images": args.include_images,
    }

    try:
        data, headers = client.web_call("extract", body)
    except Exception as e:
        from fred.auth import InsufficientCreditsError, WebResearchDisabledError

        if isinstance(e, WebResearchDisabledError):
            err_class = "web_research_disabled"
            wire = (
                f"Error: web research is disabled. "
                f"Enable it at {e.settings_url}"
            )
        elif isinstance(e, InsufficientCreditsError):
            err_class = "insufficient_credits"
            wire = f"Error: out of credits. Top up at {e.topup_url}"
        elif isinstance(e, httpx.HTTPStatusError):
            err_class = "HTTPStatusError"
            wire = (
                f"Error: web_fetch HTTP {e.response.status_code}: "
                f"{e.response.text[:300]}"
            )
        else:
            err_class = type(e).__name__
            wire = f"Error: web_fetch failed: {err_class}: {e}"
        http_status = (
            getattr(getattr(e, "response", None), "status_code", None)
        )
        _LAST_STATS.set({
            "ok": False,
            "http_status": http_status,
            "error_class": err_class,
            "success_count": 0,
            "failed_count": 0,
            "per_url_bytes": [],
            "total_bytes": 0,
            "truncated": False,
            "truncated_at_url": None,
            "bytes_returned": len(wire.encode("utf-8")),
            "tavily_response_time": None,
            "duration_ms": int((time.perf_counter() - t0) * 1000),
            "cost_billed_microcents": None,
            "credits_consumed": None,
            "balance_after_microcents": None,
            **base_stats,
        })
        return wire

    ok_results = data.get("results") or []
    failed = data.get("failed_results") or []

    parts = [f"[ok {len(ok_results)}/{len(args.urls)} URLs]"]
    per_url_bytes: list[int] = []
    running = sum(len(p.encode("utf-8")) for p in parts)
    truncated_at_url: int | None = None
    for i, r in enumerate(ok_results, 1):
        url = r.get("url", "")
        content = r.get("raw_content") or ""
        per_url_bytes.append(len(content.encode("utf-8")))
        block = f"\n--- [{i}] {url} ---\n{content}"
        if running + len(block.encode("utf-8")) > HARD_BYTE_CAP:
            truncated_at_url = i
            parts.append(
                f"\n[truncated at URL {i} — page byte cap "
                f"{HARD_BYTE_CAP} reached]"
            )
            break
        parts.append(block)
        running += len(block.encode("utf-8"))
    for f in failed:
        parts.append(f"\n[failed] {f.get('url', '?')}: {f.get('error', 'unknown')}")

    out = truncate("\n".join(parts), limit=HARD_BYTE_CAP)

    _LAST_STATS.set({
        "ok": True,
        "http_status": 200,
        "error_class": None,
        "success_count": len(ok_results),
        "failed_count": len(failed),
        "per_url_bytes": per_url_bytes,
        "total_bytes": sum(per_url_bytes),
        "truncated": truncated_at_url is not None,
        "truncated_at_url": truncated_at_url,
        "bytes_returned": len(out.encode("utf-8")),
        "tavily_response_time": data.get("response_time"),
        "duration_ms": int((time.perf_counter() - t0) * 1000),
        "cost_billed_microcents": _int_header(headers, "x-fred-web-cost-microcents"),
        "credits_consumed": _int_header(headers, "x-fred-web-credits"),
        "balance_after_microcents": _int_header(headers, "x-fred-balance-microcents"),
        **base_stats,
    })
    return out


tool = Tool(
    name="web_fetch",
    description=(
        "Fetch and clean the full content of up to 20 URLs via Tavily extract. "
        "Use after `web_search` (or when the user gives you a URL) to read pages "
        "in full. Returns concatenated content with `--- [N] <url> ---` separators "
        "and a byte cap (~100KB total). Costs ~$0.020 per 5 URLs basic, "
        "~$0.040 per 5 URLs advanced."
    ),
    args_model=WebFetchArgs,
    handler=run,
    requires_permission=True,
)
