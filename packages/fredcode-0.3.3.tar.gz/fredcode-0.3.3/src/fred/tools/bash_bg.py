"""Background bash family (P3.4): ``bash_bg`` / ``bash_read`` / ``bash_kill``.

Three tools that together cover long-running processes (dev servers, file
watchers, builds) without tying up the foreground ``bash`` tool. The model
spawns a process with ``bash_bg``, polls for new output via ``bash_read``
(delta semantics — only new lines since the last read), and terminates
with ``bash_kill``.

Design:

* Each spawned process detaches via ``subprocess.Popen(start_new_session=True)``
  so a kill takes the whole tree (matches P1.3's foreground bash). Output
  is drained on a daemon thread into a bounded ``deque`` (capped at 1MB
  worth of bytes); when the buffer is full, oldest lines are dropped.
* ``bash_read`` returns ONLY new lines since the previous read on the
  same handle (matches Claude Code's delta semantics). When the process
  has exited and there are no new lines, returns ``"[done] exit=N"``;
  when it's still alive with no new output, returns ``"[running]"``.
* ``bash_kill`` does SIGTERM then a 2s grace window then SIGKILL via
  ``os.killpg`` so the kill propagates to children of the spawned shell.
* All buffer + handle bookkeeping lives in a per-session ``dict`` held
  by a ``ContextVar`` so a REPL ``/clear`` (which forks a fresh
  ContextVar in a new task / subprocess flow, or simply re-installs an
  empty dict) doesn't see stale handles. Handle counter is also per-session.
* ``cleanup()`` kills any still-running processes for the current session
  and is registered with ``atexit`` — best-effort cleanup on Python exit.
  The Stop hook (P2.4) calls it explicitly on session shutdown so handles
  don't outlive the session.

Telemetry
---------

Three events emitted via the ``_BASH_BG_TRACER`` ContextVar (set by the
session loop, mirrors the foreground bash ``set_on_line`` precedent):

  - ``bash_bg_start``  ``{handle, cwd}``  — privacy: command is NOT shipped
  - ``bash_bg_read``   ``{handle, lines_returned, still_running}``
  - ``bash_bg_kill``   ``{handle, exit_code, signal_used}``

ANSI codes are stripped from output before it reaches the model;
``truncate_head_tail`` shapes ``bash_read`` returns when the delta is huge.
Both helpers are reused from P1.3's ``_text_utils``.
"""
from __future__ import annotations

import atexit
import contextvars
import os
import signal
import subprocess
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from pydantic import BaseModel, Field

from fred.tools._sandbox import (
    current_sandbox_mode,
    record_invocation_stats,
    wrap_command,
)
from fred.tools._text_utils import strip_ansi, truncate_head_tail
from fred.tools.base import Tool

# ---------------------------------------------------------------------------
# Constants

# Soft cap on per-handle buffer (in bytes). The ``deque`` stores lines
# (not bytes), so we approximate by tracking total length and popping
# oldest entries until we're back under the cap. 1MB is plenty for
# typical dev-server traffic between ``bash_read`` calls and bounds RAM.
_BUFFER_BYTES_CAP = 1_048_576  # 1 MiB

# Cap on bash_read return size. Reuses the foreground bash 50KB head+tail
# budget so the model never gets a tool result larger than the
# documented per-result cap.
_READ_HEAD = 25_000
_READ_TAIL = 25_000

# How long bash_kill waits for SIGTERM to take effect before escalating
# to SIGKILL. Matches the foreground bash timeout escalation in P1.3.
_KILL_GRACE_SEC = 2.0

# ---------------------------------------------------------------------------
# Per-handle state


@dataclass
class _BgProc:
    """All bookkeeping for one background process.

    The ``output_buffer`` deque stores raw (un-stripped) lines as written
    by the drain thread; ANSI is stripped on read so the user-facing
    rendering path could in theory still see colors. ``read_pos`` is the
    index in ``output_buffer`` of the first not-yet-returned line; on
    each ``bash_read`` we slice ``[read_pos:]`` and bump ``read_pos`` to
    ``len(buffer)``.

    Note: when the buffer is bounded and old entries are popped, ``read_pos``
    must be re-anchored. We track ``_dropped_count`` to compensate so
    delta semantics survive eviction.
    """

    popen: subprocess.Popen
    command: str
    cwd: str | None
    started_at: float  # time.perf_counter()
    output_buffer: deque = field(default_factory=deque)
    # Index into the *logical* line stream (counting evicted lines too).
    # output_buffer holds entries [_dropped_count .. _dropped_count + len(buffer)].
    read_pos: int = 0
    _dropped_count: int = 0
    _bytes_in_buffer: int = 0
    exit_code: int | None = None
    drain_thread: threading.Thread | None = None
    # Per-process lock guards buffer mutations from the drain thread vs
    # bash_read on the agent thread.
    lock: threading.Lock = field(default_factory=threading.Lock)


# ---------------------------------------------------------------------------
# Per-session state (ContextVar isolation)
#
# Handles never leak across REPL `/clear` (which re-installs the
# session-scoped state) or across distinct CLI invocations. The default
# is None; the foreground bash + agent tool ContextVar precedent is
# the same.


@dataclass
class _SessionState:
    procs: dict[str, _BgProc] = field(default_factory=dict)
    counter: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock)


_SESSION_STATE: contextvars.ContextVar[_SessionState | None] = contextvars.ContextVar(
    "fred_bash_bg_state", default=None,
)

# Module-level fallback state for callers that don't install one (one-shot
# tools tests, embedded harnesses). Mirrors the "no tracker = legacy
# behavior" pattern in `_session_files.tracking_active()`.
_FALLBACK_STATE = _SessionState()


def _state() -> _SessionState:
    """Return the active session state, falling back to the module-level one."""
    s = _SESSION_STATE.get()
    return s if s is not None else _FALLBACK_STATE


def set_session_state(state: _SessionState | None = None) -> contextvars.Token:
    """Install a fresh session-scoped state. Returns a reset token.

    Pair with ``reset_session_state(token)`` in a try/finally so the
    ContextVar is always restored. Pass ``None`` to use a freshly-built
    empty state.
    """
    return _SESSION_STATE.set(state if state is not None else _SessionState())


def reset_session_state(token: contextvars.Token) -> None:
    _SESSION_STATE.reset(token)


# ---------------------------------------------------------------------------
# Telemetry hook (set by the session loop; matches the bash on_line
# precedent in P1.3).

_BASH_BG_TRACER: contextvars.ContextVar[Callable[[str, dict], None] | None] = (
    contextvars.ContextVar("fred_bash_bg_tracer", default=None)
)


def set_event_emitter(cb: Callable[[str, dict], None] | None) -> contextvars.Token:
    """Register a `(kind, payload)` event emitter for bash_bg events.

    The tracer ``Tracer.event`` shape is ``event(kind, *, payload, turn)``
    — wrap it on the caller side and pass the bound callable here so the
    daemon-thread tracer call is fire-and-forget. Errors are swallowed.
    """
    return _BASH_BG_TRACER.set(cb)


def reset_event_emitter(token: contextvars.Token) -> None:
    _BASH_BG_TRACER.reset(token)


def _emit(kind: str, payload: dict) -> None:
    cb = _BASH_BG_TRACER.get()
    if cb is None:
        return
    try:
        cb(kind, payload)
    except Exception:
        # Tracer is non-blocking by contract; never let a telemetry
        # callback abort a tool result.
        pass


# ---------------------------------------------------------------------------
# Project-root validation (mirrors `bash._is_under_root`).
#
# Captured at module import time. Tests rebind ``_PROJECT_ROOT`` via
# monkeypatch. We re-resolve in the validator so symlinks collapse.

_PROJECT_ROOT: Path = Path.cwd().resolve()


def _project_root() -> Path:
    return _PROJECT_ROOT


def _is_under_root(p: Path, root: Path) -> bool:
    try:
        p.resolve().relative_to(root)
        return True
    except (ValueError, OSError):
        return False


# ---------------------------------------------------------------------------
# Drain thread


def _drain_stdout(proc: _BgProc) -> None:
    """Daemon-thread body. Read until EOF, accumulating into the buffer."""
    popen = proc.popen
    assert popen.stdout is not None  # bufsize=1 + text=True guarantees this
    try:
        for line in popen.stdout:
            with proc.lock:
                proc.output_buffer.append(line)
                proc._bytes_in_buffer += len(line)
                # Evict oldest entries until we're back under cap. Bump
                # the dropped counter so the read_pos re-anchors correctly.
                while (
                    proc._bytes_in_buffer > _BUFFER_BYTES_CAP
                    and len(proc.output_buffer) > 1
                ):
                    dropped = proc.output_buffer.popleft()
                    proc._bytes_in_buffer -= len(dropped)
                    proc._dropped_count += 1
    except Exception:
        # If readline raises (closed pipe, decode error), let the thread
        # exit; the wait() call below will pick up the exit code.
        pass
    finally:
        try:
            popen.stdout.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Handle bookkeeping


def _allocate_handle(state: _SessionState) -> str:
    with state.lock:
        state.counter += 1
        return f"bash_{state.counter}"


# ---------------------------------------------------------------------------
# bash_bg


class BashBgArgs(BaseModel):
    command: str = Field(
        ...,
        description="Shell command to run in the background (interpreted by /bin/sh -c).",
    )
    cwd: str | None = Field(
        None,
        description=(
            "Optional working directory for the command. Must be inside the "
            "project root. Defaults to the fred process cwd."
        ),
    )


def run_bg(args: BashBgArgs) -> str:
    """Spawn a background process and return its handle (e.g. ``bash_3``)."""
    cwd: str | None = None
    if args.cwd is not None:
        try:
            cand = Path(args.cwd).expanduser()
        except (RuntimeError, ValueError):
            return f"Error: invalid cwd {args.cwd!r}"
        if not cand.exists() or not cand.is_dir():
            return f"Error: cwd does not exist or is not a directory: {args.cwd}"
        if not _is_under_root(cand, _project_root()):
            return f"Error: cwd outside project root: {args.cwd}"
        cwd = str(cand.resolve())

    state = _state()
    handle = _allocate_handle(state)

    # P4.1: optional Seatbelt wrap. Identical wire shape to the foreground
    # bash tool — the wrapped argv goes to Popen(..., shell=False), the
    # un-wrapped str goes through Popen(..., shell=True). Linux falls
    # through to the legacy un-wrapped path.
    sandbox_mode = current_sandbox_mode()
    wrapped, _profile = wrap_command(args.command, sandbox_mode, _project_root())
    record_invocation_stats({
        "mode": sandbox_mode,
        "wrapped": isinstance(wrapped, list),
        "command_chars": len(args.command),
    })

    try:
        if isinstance(wrapped, list):
            popen = subprocess.Popen(
                wrapped,
                shell=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
                cwd=cwd,
            )
        else:
            popen = subprocess.Popen(
                wrapped,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
                cwd=cwd,
            )
    except (OSError, ValueError) as e:
        return f"Error: failed to start background command: {type(e).__name__}: {e}"

    proc = _BgProc(
        popen=popen,
        command=args.command,
        cwd=cwd,
        started_at=time.perf_counter(),
    )
    drain = threading.Thread(
        target=_drain_stdout,
        args=(proc,),
        name=f"fred-bash-bg-drain-{handle}",
        daemon=True,
    )
    proc.drain_thread = drain
    drain.start()

    with state.lock:
        state.procs[handle] = proc

    # Telemetry: emit handle + cwd + sandbox mode. Command is NOT shipped
    # (privacy / the redactor would have to walk the whole command line).
    _emit("bash_bg_start", {
        "handle": handle, "cwd": cwd, "sandbox_mode": sandbox_mode,
    })

    return handle


# ---------------------------------------------------------------------------
# bash_read


class BashReadArgs(BaseModel):
    handle: str = Field(..., description="Handle returned by bash_bg (e.g. bash_1).")
    max_lines: int = Field(
        100,
        ge=1,
        le=10_000,
        description="Maximum number of new lines to return. Defaults to 100.",
    )


def _refresh_exit_code(proc: _BgProc) -> None:
    """Non-blocking poll to update ``exit_code`` if the process has exited."""
    if proc.exit_code is not None:
        return
    rc = proc.popen.poll()
    if rc is not None:
        proc.exit_code = rc


def run_read(args: BashReadArgs) -> str:
    """Return new output since the last read on this handle, plus a status line."""
    state = _state()
    proc = state.procs.get(args.handle)
    if proc is None:
        return f"Error: unknown handle {args.handle!r}"

    _refresh_exit_code(proc)

    with proc.lock:
        # Re-anchor: the read position is in *logical* line indices; the
        # buffer holds [_dropped_count .. _dropped_count + len(buffer)].
        local_start = max(0, proc.read_pos - proc._dropped_count)
        new_lines = list(proc.output_buffer)[local_start : local_start + args.max_lines]
        # Number of lines actually consumed (including the cap). Advances
        # the logical read_pos by exactly that many.
        consumed = len(new_lines)
        proc.read_pos += consumed

    raw = "".join(new_lines)
    body = strip_ansi(raw)
    body = truncate_head_tail(body, head=_READ_HEAD, tail=_READ_TAIL)

    still_running = proc.exit_code is None
    _emit(
        "bash_bg_read",
        {
            "handle": args.handle,
            "lines_returned": consumed,
            "still_running": still_running,
        },
    )

    if not still_running:
        # Process has exited. Return any remaining tail + a trailer line
        # so the model knows it's done.
        trailer = f"[done] exit={proc.exit_code}"
        return f"{body}\n{trailer}" if body else trailer

    if consumed == 0:
        return "[running]"

    return f"{body}\n[running]"


# ---------------------------------------------------------------------------
# bash_kill


class BashKillArgs(BaseModel):
    handle: str = Field(..., description="Handle returned by bash_bg (e.g. bash_1).")


def _kill_pg(pgid: int, sig: int) -> None:
    try:
        os.killpg(pgid, sig)
    except ProcessLookupError:
        pass
    except OSError:
        pass


def _terminate(proc: _BgProc) -> tuple[int | None, int | None]:
    """SIGTERM, 2s grace, SIGKILL. Returns (exit_code, signal_used).

    ``signal_used`` is the last signal we sent (SIGTERM or SIGKILL); it's
    None if the process had already exited before we touched it.
    """
    if proc.exit_code is not None:
        return proc.exit_code, None

    rc = proc.popen.poll()
    if rc is not None:
        proc.exit_code = rc
        return rc, None

    try:
        pgid = os.getpgid(proc.popen.pid)
    except ProcessLookupError:
        pgid = None

    last_signal: int | None = None
    if pgid is not None:
        _kill_pg(pgid, signal.SIGTERM)
        last_signal = int(signal.SIGTERM)

    try:
        proc.popen.wait(timeout=_KILL_GRACE_SEC)
    except subprocess.TimeoutExpired:
        if pgid is not None:
            _kill_pg(pgid, signal.SIGKILL)
            last_signal = int(signal.SIGKILL)
        try:
            proc.popen.wait(timeout=1.0)
        except subprocess.TimeoutExpired:
            pass

    rc = proc.popen.poll()
    if rc is not None:
        proc.exit_code = rc
    return proc.exit_code, last_signal


def run_kill(args: BashKillArgs) -> str:
    state = _state()
    proc = state.procs.get(args.handle)
    if proc is None:
        return f"Error: unknown handle {args.handle!r}"

    exit_code, signal_used = _terminate(proc)

    # Wait briefly for the drain thread to flush any tail bytes the
    # kernel had buffered. Daemon flag bounds the join.
    if proc.drain_thread is not None:
        proc.drain_thread.join(timeout=1.0)

    _emit(
        "bash_bg_kill",
        {
            "handle": args.handle,
            "exit_code": exit_code,
            "signal_used": signal_used,
        },
    )

    if signal_used is None:
        return f"Killed {args.handle}: already exited (exit={exit_code})"
    sig_name = "SIGKILL" if signal_used == int(signal.SIGKILL) else "SIGTERM"
    return f"Killed {args.handle}: {sig_name} (exit={exit_code})"


# ---------------------------------------------------------------------------
# Cleanup (atexit + Stop hook integration)


def cleanup() -> list[str]:
    """Kill any still-running background procs in the current session.

    Returns the list of handles that were running and required termination
    (for the Stop hook caller to surface in telemetry). Best-effort:
    individual kill failures are swallowed; the caller cannot recover from
    them at session-shutdown time.
    """
    state = _state()
    killed: list[str] = []
    # Snapshot the handles to avoid mutating the dict mid-iteration if a
    # _terminate call somehow re-entered.
    with state.lock:
        items = list(state.procs.items())
    for handle, proc in items:
        if proc.exit_code is not None:
            continue
        if proc.popen.poll() is not None:
            proc.exit_code = proc.popen.poll()
            continue
        try:
            exit_code, signal_used = _terminate(proc)
        except Exception:
            continue
        killed.append(handle)
        # Emit a kill event so the Stop hook integration shows up in
        # telemetry the same way an explicit bash_kill does.
        _emit(
            "bash_bg_kill",
            {
                "handle": handle,
                "exit_code": exit_code,
                "signal_used": signal_used,
            },
        )
    return killed


def _cleanup_all_atexit() -> None:
    """Best-effort cleanup of fallback-state procs on Python exit.

    The session-scoped ContextVar state is gone by the time atexit fires
    (the REPL's finally block reset it long ago), so we only walk the
    module-level fallback state here. Production sessions go through the
    Stop hook path (P2.4) which calls ``cleanup()`` while the ContextVar
    is still installed.
    """
    state = _FALLBACK_STATE
    with state.lock:
        items = list(state.procs.items())
    for _handle, proc in items:
        if proc.exit_code is not None:
            continue
        if proc.popen.poll() is not None:
            continue
        try:
            _terminate(proc)
        except Exception:
            pass


atexit.register(_cleanup_all_atexit)


# ---------------------------------------------------------------------------
# Tool dataclasses


tool_bash_bg = Tool(
    name="bash_bg",
    description=(
        "Start a long-running shell command in the background and return a "
        "handle (e.g. `bash_1`). Use for dev servers, file watchers, or "
        "builds that should run alongside the agent. Poll output with "
        "`bash_read(handle)` and terminate with `bash_kill(handle)`. The "
        "process detaches into its own session group; a kill takes the "
        "whole tree. Use the optional `cwd` parameter to run in a specific "
        "directory inside the project root."
    ),
    args_model=BashBgArgs,
    handler=run_bg,
    requires_permission=True,
)

tool_bash_read = Tool(
    name="bash_read",
    description=(
        "Return new output produced since the last `bash_read` on the same "
        "handle (delta semantics). When the process is still running and "
        "no new output is available, returns `[running]`. When the process "
        "has exited, returns the final tail plus `[done] exit=N`. Optional "
        "`max_lines` (default 100) caps how many new lines this read returns."
    ),
    args_model=BashReadArgs,
    handler=run_read,
    requires_permission=False,
)

tool_bash_kill = Tool(
    name="bash_kill",
    description=(
        "Terminate the background process for `handle`. Sends SIGTERM, "
        "waits up to 2s, then escalates to SIGKILL on the whole process "
        "group. Returns a confirmation string with the final exit code."
    ),
    args_model=BashKillArgs,
    handler=run_kill,
    requires_permission=True,
)
