"""Token-budget tracking + context compaction for the message history.

We use tiktoken's cl100k_base as a cheap proxy — it's ~15% off vs DeepSeek's
actual tokenizer, but for a 1M-token context that's a 150K-token error band
and we trigger warnings/hard-stop well before the boundary.

P2.5 layers two compaction stages on top of the budget tracker:

  1. ``prune_messages`` — cheap, idempotent, runs before every model call.
     Walks the history oldest-to-newest and elides verbose tool-result
     content (>20k chars) older than the last 20k-token window with a
     short ``[elided: <tool_name> on <args>, <N> chars]`` marker. Keeps
     recent tool results raw so active reasoning context survives.

  2. ``compact_messages`` — the heavier weak-model summary pass, fired
     when the budget tracker reports ``"compact"`` (>=85% of context).
     Splits the history into older + recent halves (preserving more
     recent context), runs the older half through the weak model with
     a structured-summary prompt, and replaces it with a single synthetic
     system message tagged with the ``COMPACTED_HEADER`` sentinel.

Both functions preserve the cacheable prefix invariant from P1.2: the
leading system prompt at index 0 is never touched. Compacted summaries
are inserted at index 1+ so DeepSeek's prefix cache still hits.
"""
from __future__ import annotations

import json
import time

try:
    import tiktoken

    _ENC = tiktoken.get_encoding("cl100k_base")
except Exception:
    _ENC = None


CONTEXT_WINDOW = 1_000_000  # deepseek-v4-flash
WARN_RATIO = 0.70
COMPACT_RATIO = 0.85  # P2.5: trigger structured-summary compaction
HARD_RATIO = 0.95

# Per-message threshold: tool results with content above this many chars
# are eligible for elision during pruning. Smaller results are left raw —
# the marker overhead would dominate the savings.
_PRUNE_THRESHOLD = 20_000

# Default token budget the recent tail of history should keep raw during
# pruning. Tool results inside this trailing window are NOT elided.
_DEFAULT_RECENT_BUDGET = 20_000

# Sentinel: any system message whose content begins with this header is
# treated as a previously-injected compaction summary. Lets `/compact` and
# downstream callers distinguish synthetic summaries from real system
# prompts (which never start with this string).
COMPACTED_HEADER = "# Compacted history"

# Sentinel for elided tool-result content. Idempotent: a tool message whose
# content already starts with this prefix is skipped on re-prune (its
# size is already tiny, well below `_PRUNE_THRESHOLD`).
_ELIDED_PREFIX = "[elided:"


def count_tokens(text: str) -> int:
    if _ENC is None:
        return max(1, len(text) // 4)
    return len(_ENC.encode(text))


def estimate_messages(messages: list[dict]) -> int:
    total = 0
    for m in messages:
        c = m.get("content")
        if isinstance(c, str):
            total += count_tokens(c)
        elif isinstance(c, list):
            for part in c:
                total += count_tokens(json.dumps(part))
        for tc in m.get("tool_calls", []) or []:
            total += count_tokens(json.dumps(tc))
        total += 4  # rough per-message overhead
    return total


def budget_status(messages: list[dict]) -> tuple[int, str]:
    """Return ``(used_tokens, status)`` where status is one of
    ``"ok" | "warn" | "compact" | "hard"``.

    Thresholds (cumulative, so each one implies the lower ones):
      - ``WARN_RATIO``    (0.70) : surface a one-line warning to the user
      - ``COMPACT_RATIO`` (0.85) : trigger ``compact_messages`` for this turn
      - ``HARD_RATIO``    (0.95) : refuse to start the next iteration

    The ``"compact"`` value is new in P2.5 — callers from P0.1/P1.x only
    looked for ``"hard"`` / ``"warn"`` / ``"ok"``, and treat any unknown
    value as benign. Adding a new tier between warn and hard is therefore
    safe (existing callers ignore it; ``run_session`` does the new work).
    """
    used = estimate_messages(messages)
    pct = used / CONTEXT_WINDOW
    if pct >= HARD_RATIO:
        return used, "hard"
    if pct >= COMPACT_RATIO:
        return used, "compact"
    if pct >= WARN_RATIO:
        return used, "warn"
    return used, "ok"


# ---------- Pruning -------------------------------------------------------


def _tool_call_lookup(messages: list[dict]) -> dict[str, tuple[str, str]]:
    """Build a ``tool_call_id -> (tool_name, short_args_repr)`` map.

    Walks every assistant message's ``tool_calls`` once so the pruner can
    tag elided tool messages without re-parsing JSON for each candidate.

    The short-args repr is best-effort: we look for a ``path`` field
    first (covers ``view`` / ``str_replace`` / ``glob`` / ``grep``) and
    fall back to a truncated raw-args string. Pure-cosmetic; the elided
    marker tells the model "there used to be N chars here," not what
    they were.
    """
    out: dict[str, tuple[str, str]] = {}
    for m in messages:
        if m.get("role") != "assistant":
            continue
        for tc in m.get("tool_calls") or []:
            tcid = tc.get("id") or ""
            fn = tc.get("function") or {}
            name = fn.get("name") or ""
            raw = fn.get("arguments") or ""
            short = ""
            try:
                parsed = json.loads(raw) if isinstance(raw, str) else (raw or {})
            except (json.JSONDecodeError, TypeError):
                parsed = {}
            if isinstance(parsed, dict):
                # Prefer common identifying fields. Order matters: `path`
                # is the most informative; `command` and `pattern` cover
                # `bash` and `grep` respectively.
                for key in ("path", "command", "pattern", "url"):
                    val = parsed.get(key)
                    if isinstance(val, str) and val:
                        short = val
                        break
            if not short and raw:
                # Fallback: trim the raw args. Keep it small — the marker
                # itself shouldn't bloat the message we're trying to shrink.
                short = (raw if isinstance(raw, str) else json.dumps(raw))
            if len(short) > 80:
                short = short[:77] + "..."
            if tcid:
                out[tcid] = (name, short)
    return out


def _elision_marker(tool_name: str, short_args: str, original_chars: int) -> str:
    """Format the replacement content for an elided tool-result message.

    Falls back to a generic marker when ``tool_name`` is missing — covers
    the rare case where the assistant message that emitted the tool_call
    has been compacted away or the lookup misses for some reason.
    """
    if tool_name and short_args:
        return (
            f"{_ELIDED_PREFIX} {tool_name} on {short_args}, "
            f"{original_chars} chars]"
        )
    if tool_name:
        return f"{_ELIDED_PREFIX} {tool_name}, {original_chars} chars]"
    return f"{_ELIDED_PREFIX} tool result, {original_chars} chars]"


def prune_messages(
    messages: list[dict],
    recent_token_budget: int = _DEFAULT_RECENT_BUDGET,
) -> tuple[list[dict], int]:
    """Return a pruned copy of ``messages`` plus the count of chars elided.

    Walks the history oldest-to-newest. For every ``role: tool`` message
    OLDER than the last ``recent_token_budget`` tokens (i.e. not in the
    trailing active-reasoning window), if the content exceeds
    ``_PRUNE_THRESHOLD`` chars it is replaced with an elision marker that
    names the originating tool plus a short identifying argument.

    Idempotent: pruning twice gives the same result. Already-elided
    blocks fall well below the threshold, so the second pass is a no-op.

    The OUTER message shape (``role``, ``tool_call_id``, every other key)
    is preserved — only the ``content`` field is rewritten. Non-tool
    messages are passed through untouched.

    Does NOT mutate ``messages``.
    """
    if not messages:
        return list(messages), 0

    # Decide the recent boundary: walk newest-to-oldest, accumulating
    # token cost; once we're past `recent_token_budget`, every earlier
    # message is "old enough" to be a pruning candidate. Sticking to the
    # same `count_tokens` / `estimate_messages` helpers keeps this
    # consistent with `budget_status`.
    cumulative = 0
    boundary = 0  # messages[:boundary] are eligible for pruning
    for i in range(len(messages) - 1, -1, -1):
        m = messages[i]
        c = m.get("content")
        if isinstance(c, str):
            cumulative += count_tokens(c)
        elif isinstance(c, list):
            for part in c:
                cumulative += count_tokens(json.dumps(part))
        for tc in m.get("tool_calls", []) or []:
            cumulative += count_tokens(json.dumps(tc))
        cumulative += 4
        if cumulative >= recent_token_budget:
            boundary = i  # keep messages[i:] raw
            break

    if boundary == 0:
        # Whole history fits inside the recent budget — nothing to prune.
        return list(messages), 0

    lookup = _tool_call_lookup(messages)
    out: list[dict] = []
    chars_elided = 0
    for i, m in enumerate(messages):
        if i >= boundary:
            out.append(m)
            continue
        if m.get("role") != "tool":
            out.append(m)
            continue
        content = m.get("content")
        if not isinstance(content, str):
            out.append(m)
            continue
        if content.startswith(_ELIDED_PREFIX):
            # Already pruned — idempotency.
            out.append(m)
            continue
        if len(content) <= _PRUNE_THRESHOLD:
            out.append(m)
            continue
        original_chars = len(content)
        tool_name, short_args = lookup.get(m.get("tool_call_id", ""), ("", ""))
        marker = _elision_marker(tool_name, short_args, original_chars)
        replaced = dict(m)
        replaced["content"] = marker
        out.append(replaced)
        chars_elided += original_chars - len(marker)

    return out, chars_elided


# ---------- Compaction ----------------------------------------------------


_COMPACT_PROMPT_TEMPLATE = """\
Summarize the conversation so far in five sections:

## Accomplishments
## Current modifications (files touched, in flight)
## Affected files
## Next steps
## Constraints / technical decisions made

{focus_hint}

Conversation:
{serialized}
"""


def is_compacted_message(message: dict) -> bool:
    """True if ``message`` is a synthetic compaction-summary system message.

    Detection is by sentinel content prefix (``COMPACTED_HEADER``). Robust
    against multiple compactions per session — each new one strips the
    prior synthetic message before inserting the fresh summary so we
    don't accumulate stale ``# Compacted history`` blocks.
    """
    if message.get("role") != "system":
        return False
    content = message.get("content")
    if not isinstance(content, str):
        return False
    return content.startswith(COMPACTED_HEADER)


def _split_history_index(messages: list[dict]) -> int:
    """Return the index where the "older half" ends and the "recent" begins.

    Strategy: pick the more conservative (smaller older half / larger
    recent half) of two thresholds:

      - keep the last 10 user/assistant pairs raw, and
      - keep the last 30% of total tokens raw.

    Returns the boundary index `b` such that ``messages[:b]`` is older and
    ``messages[b:]`` is recent. The boundary is at least 1 (we never
    compact the leading system prompt) and at most ``len(messages)``.

    The leading run of system messages (cacheable prefix + any pre-existing
    compaction summaries) is excluded from BOTH halves — those messages
    are preserved as-is and live before the synthetic summary insertion
    point. The function returns the index INTO the "compactable region"
    that follows the leading system run.
    """
    # Find where the leading system run ends (we never split inside it).
    sys_end = 0
    for i, m in enumerate(messages):
        if m.get("role") == "system":
            sys_end = i + 1
        else:
            break
    if sys_end >= len(messages):
        return len(messages)  # nothing to compact

    compactable = messages[sys_end:]

    # Threshold 1: keep last 10 user/assistant pairs raw. If we don't
    # reach 10, EVERYTHING is recent (boundary stays at 0 → no
    # older-half to compact).
    pair_count = 0
    pair_boundary = 0
    found_pairs = False
    for i in range(len(compactable) - 1, -1, -1):
        role = compactable[i].get("role")
        if role == "user":
            pair_count += 1
            if pair_count >= 10:
                pair_boundary = i
                found_pairs = True
                break
    if not found_pairs:
        pair_boundary = 0  # not enough pairs → nothing to summarize

    # Threshold 2: keep last 30% of compactable tokens raw. Same default:
    # if total tokens are too small to bother, treat as "all recent."
    total_tokens = 0
    for m in compactable:
        c = m.get("content")
        if isinstance(c, str):
            total_tokens += count_tokens(c)
        elif isinstance(c, list):
            for part in c:
                total_tokens += count_tokens(json.dumps(part))
        for tc in m.get("tool_calls", []) or []:
            total_tokens += count_tokens(json.dumps(tc))
        total_tokens += 4
    target_tail = int(total_tokens * 0.30)
    cumulative = 0
    token_boundary = 0
    found_token_split = False
    for i in range(len(compactable) - 1, -1, -1):
        m = compactable[i]
        c = m.get("content")
        if isinstance(c, str):
            cumulative += count_tokens(c)
        elif isinstance(c, list):
            for part in c:
                cumulative += count_tokens(json.dumps(part))
        for tc in m.get("tool_calls", []) or []:
            cumulative += count_tokens(json.dumps(tc))
        cumulative += 4
        if cumulative >= target_tail:
            token_boundary = i
            found_token_split = True
            break
    if not found_token_split:
        token_boundary = 0

    # Pick the more conservative (preserves more recent context = SMALLER
    # older half = LARGER boundary inside the compactable region).
    # When neither threshold split the history, boundary_in_compactable
    # stays 0 → older half is empty → compact_messages no-ops.
    boundary_in_compactable = max(pair_boundary, token_boundary)
    return sys_end + boundary_in_compactable


def _serialize_history(messages: list[dict]) -> str:
    """Render messages as a compact text block for the summary prompt.

    Each message becomes one labeled segment; tool calls are flattened
    inline so the weak model sees the full action history without wading
    through OpenAI tool-call envelope JSON.
    """
    lines: list[str] = []
    for m in messages:
        role = m.get("role", "?")
        content = m.get("content")
        if isinstance(content, list):
            content = "".join(
                p.get("text", "") if isinstance(p, dict) else str(p)
                for p in content
            )
        text = content if isinstance(content, str) else ""
        if role == "assistant":
            tool_calls = m.get("tool_calls") or []
            if tool_calls:
                tc_descs = []
                for tc in tool_calls:
                    fn = tc.get("function") or {}
                    name = fn.get("name") or "?"
                    args = fn.get("arguments") or ""
                    if len(args) > 200:
                        args = args[:197] + "..."
                    tc_descs.append(f"{name}({args})")
                tc_blob = ", ".join(tc_descs)
                if text:
                    lines.append(f"[assistant] {text}\n  tool_calls: {tc_blob}")
                else:
                    lines.append(f"[assistant] tool_calls: {tc_blob}")
                continue
        if role == "tool":
            tcid = m.get("tool_call_id", "")
            lines.append(f"[tool {tcid}] {text}")
            continue
        lines.append(f"[{role}] {text}")
    return "\n\n".join(lines)


def compact_messages(
    messages: list[dict],
    weak_client,
    *,
    focus: str | None = None,
    tracer=None,
    turn: int = 0,
) -> tuple[list[dict], dict]:
    """Compact the older half of history using the weak model.

    Returns ``(new_messages, stats)`` where ``stats`` is a dict with
    ``before_tokens``, ``after_tokens``, ``summary_chars``, ``elapsed_ms``,
    plus (when the model actually fired) ``usage`` (the raw OpenAI-style
    usage dict from the weak stream) and ``cost_billed_microcents``.

    When ``tracer`` is provided we emit a ``model_routed`` event with
    ``slot="weak"`` immediately before invoking the model, mirroring
    the per-iteration emission for the main loop. The caller still
    fires its own ``compaction_run`` event with the full stats.

    Behavior:
      - Leading system run (cacheable prefix + any prior compaction
        summaries) is preserved untouched. ``messages[0]`` (the real
        system prompt — the cacheable prefix invariant from P1.2) is
        never modified.
      - Older half of the post-system region is summarized via
        ``weak_client.stream_chat`` with a structured five-section prompt.
        The summary is wrapped in a synthetic system message starting
        with ``COMPACTED_HEADER`` and inserted right after the leading
        system run. Any prior synthetic compaction message is stripped
        first so we don't accumulate.
      - Recent half is preserved raw.
      - When ``focus`` is non-empty it is folded into the prompt so the
        weak model knows what to emphasize ("billing module", "auth
        bug", etc.).

    Does NOT mutate ``messages``. The summary content passes through
    the standard tool-result redactor at the telemetry boundary; we
    don't redact in place here because the summary may legitimately
    contain paths and identifiers that the model needs to keep track
    of work in progress.
    """
    started = time.perf_counter()
    before_tokens = estimate_messages(messages)

    # Strip any prior compaction marker so we don't pile them up.
    cleaned = [m for m in messages if not is_compacted_message(m)]

    boundary = _split_history_index(cleaned)
    # Find sys_end again (mirrors logic in _split_history_index).
    sys_end = 0
    for i, m in enumerate(cleaned):
        if m.get("role") == "system":
            sys_end = i + 1
        else:
            break

    # Two no-op cases:
    #   1. Boundary lands at or before the leading system run — nothing
    #      to compact (true for very short histories).
    #   2. Compactable region is too small to bother summarizing. We
    #      gate on "fewer than 8 messages outside the system run" — this
    #      is well below the 10-pair threshold above and leaves cheap
    #      conversations alone.
    compactable_count = len(cleaned) - sys_end
    if boundary <= sys_end or compactable_count < 8:
        return list(cleaned), {
            "before_tokens": before_tokens,
            "after_tokens": before_tokens,
            "summary_chars": 0,
            "elapsed_ms": int((time.perf_counter() - started) * 1000),
            "usage": None,
            "cost_billed_microcents": 0,
        }

    older = cleaned[sys_end:boundary]
    recent = cleaned[boundary:]

    focus_hint = (
        f"Focus: {focus.strip()}\n" if (focus and focus.strip()) else ""
    )
    prompt = _COMPACT_PROMPT_TEMPLATE.format(
        focus_hint=focus_hint,
        serialized=_serialize_history(older),
    )

    weak_model_name = getattr(weak_client, "model", None) or "?"
    if tracer is not None:
        tracer.event("model_routed", payload={
            "slot": "weak",
            "model": weak_model_name,
            "reason": "compaction",
        }, turn=turn)

    summary_text = ""
    usage: dict | None = None
    try:
        stream = weak_client.stream_chat(
            [{"role": "user", "content": prompt}],
            tools=None,
        )
        # Drive the iterator to accumulate text. The weak client returns
        # either StreamSession or RetryingStreamSession; both expose the
        # same `.result()` shape.
        for _ev in stream:
            pass
        result = stream.result()
        summary_text = (result.text or "").strip()
        usage = result.usage
    except Exception:
        # If the weak model call fails for any reason, fall back to a
        # placeholder summary so the agent loop survives. The marker
        # tells downstream consumers (and the next compaction pass)
        # that something tried and failed.
        summary_text = "(compaction failed: weak model unavailable)"

    summary_message_content = f"{COMPACTED_HEADER}\n{summary_text}"
    summary_message = {"role": "system", "content": summary_message_content}

    leading = cleaned[:sys_end]
    new_messages = leading + [summary_message] + recent

    after_tokens = estimate_messages(new_messages)

    cost_billed_microcents = 0
    if usage is not None:
        cost_billed_microcents = _usage_to_microcents(usage, weak_model_name)

    return new_messages, {
        "before_tokens": before_tokens,
        "after_tokens": after_tokens,
        "summary_chars": len(summary_text),
        "elapsed_ms": int((time.perf_counter() - started) * 1000),
        "usage": usage,
        "cost_billed_microcents": cost_billed_microcents,
    }


def _usage_to_microcents(usage: dict, model: str) -> int:
    """Translate an OpenAI-style usage dict into billed microcents.

    Mirrors `Renderer.show_usage` math but returns the integer microcent
    figure that telemetry rows want, so callers can stash it in the
    `compaction_run` event payload.
    """
    from fred.rates import get_active_card

    in_tok = usage.get("prompt_tokens", 0) or 0
    out_tok = usage.get("completion_tokens", 0) or 0
    cached = (
        usage.get("prompt_cache_hit_tokens")
        or (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0)
        or 0
    )
    non_cached = max(0, in_tok - cached)
    card = get_active_card(model)
    # Card rates are microcents per 1M tokens. Result is microcents.
    raw = (
        non_cached * card.billed.input_uncached
        + cached * card.billed.input_cached
        + out_tok * card.billed.output
    )
    return int(raw // 1_000_000)
