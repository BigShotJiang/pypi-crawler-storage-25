import pytest
from juscraper.courts.tjdft.client import TJDFTScraper


@pytest.mark.integration
def test_cjsg_basico():
    scraper = TJDFTScraper()
    df = scraper.cjsg(
        pesquisa="direito penal",
        paginas=1,
    )
    print(df.head())
    assert not df.empty
    assert "ementa" in df.columns
    assert "processo" in df.columns
