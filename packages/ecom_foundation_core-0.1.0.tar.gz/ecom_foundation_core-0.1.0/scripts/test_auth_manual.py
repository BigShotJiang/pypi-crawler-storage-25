#!/usr/bin/env python3
"""
Manual test script for auth endpoints.

Run this after starting the server with:
    python run_test_app.py

Or use it standalone with the test app.
"""
from ecom_foundation_core.bootstrap import create_test_app
from fastapi.testclient import TestClient


def test_auth_flow():
    """Test the auth flow manually."""
    app = create_test_app()
    client = TestClient(app)

    print("=" * 60)
    print("Testing Auth Flow")
    print("=" * 60)

    # 1. Register a user
    print("\n1. Registering user...")
    register_response = client.post(
        "/auth/register",
        json={
            "email": "demo@example.com",
            "password": "password123",
            "password_confirm": "password123",
        },
    )
    print(f"   Status: {register_response.status_code}")
    if register_response.status_code == 200:
        data = register_response.json()
        print(f"   User: {data['user']['email']}")
        print(f"   Access Token: {data['tokens']['access_token'][:50]}...")
        token = data["tokens"]["access_token"]
    else:
        print(f"   Error: {register_response.text}")
        return

    # 2. Login
    print("\n2. Logging in...")
    login_response = client.post(
        "/auth/login",
        json={
            "email": "demo@example.com",
            "password": "password123",
        },
    )
    print(f"   Status: {login_response.status_code}")
    if login_response.status_code == 200:
        data = login_response.json()
        print(f"   User: {data['user']['email']}")
        print("   ✓ Login successful")
    else:
        print(f"   Error: {login_response.text}")

    # 3. Get current user
    print("\n3. Getting current user...")
    me_response = client.get("/auth/me", headers={"Authorization": f"Bearer {token}"})
    print(f"   Status: {me_response.status_code}")
    if me_response.status_code == 200:
        data = me_response.json()
        print(f"   User: {data['user']['email']}")
        print(f"   User ID: {data['user']['id']}")
        print("   ✓ Authentication successful")
    else:
        print(f"   Error: {me_response.text}")

    # 4. Test wrong password
    print("\n4. Testing wrong password...")
    wrong_pass_response = client.post(
        "/auth/login",
        json={
            "email": "demo@example.com",
            "password": "wrongpassword",
        },
    )
    print(f"   Status: {wrong_pass_response.status_code}")
    if wrong_pass_response.status_code == 401:
        print("   ✓ Correctly rejected wrong password")
    else:
        print(f"   Unexpected: {wrong_pass_response.text}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)


if __name__ == "__main__":
    test_auth_flow()
