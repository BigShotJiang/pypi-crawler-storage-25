#!/usr/bin/env python3
"""
Simple script to run the test app for manual testing.

Usage:
    python run_test_app.py

Then visit http://127.0.0.1:8000/docs to use the interactive API docs.
"""
import sys

try:
    import uvicorn
except ImportError:
    print("Error: uvicorn is not installed.")
    print("\nInstall it with:")
    print("  pip install 'uvicorn[standard]>=0.24.0'")
    print("\nOr use Python's built-in server:")
    print("  python -m http.server 8000 --directory .")
    print("\nOr run the manual test script:")
    print("  python scripts/test_auth_manual.py")
    sys.exit(1)

if __name__ == "__main__":
    uvicorn.run(
        "ecom_foundation_core.bootstrap:create_test_app",
        host="127.0.0.1",
        port=8000,
        reload=True,
        factory=True,  # Important: tells uvicorn to call the function
    )
