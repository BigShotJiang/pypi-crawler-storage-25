# Getting Started with E-Com Foundation Core

`ecom_foundation_core` is a modular foundation for building high-performance enterprise microservices. It is currently the primary foundation for the **International Regulatory Management System (IRMS)**.

## Installation

Currently, the package is managed as a shared library. You can install it in your environment using `pip`:

```bash
pip install ecom-foundation-core
```

For development and testing, install with dev dependencies:

```bash
pip install -e ".[dev]"
```

## Core Concepts

The foundation is built on the principle of **Inversion of Control**. It provides the modules (Auth, RBAC, Billing, etc.), but your application controls the initialization of the Database and Redis connections.

## Basic FastAPI Setup

To use the foundation, you initialize it using the `create_app` bootstrap function.

### 1. Minimal Application

Create a `main.py` in your project:

```python
from fastapi import FastAPI
from ecom_foundation_core.bootstrap import create_app, AppConfig
from ecom_foundation_core.modules.common.database import create_async_engine

# 1. Define your modules
config = AppConfig(
    enable_auth=True,
    enable_rbac=True,
    enable_audit=True,
    title="My Store Microservice",
    version="1.0.0"
)

# 2. Setup your Database (Foundation handles the session lifecycle)
db_engine = create_async_engine(
    "postgresql+asyncpg://user:pass@localhost/dbname",
    echo=True
)

# 3. Create the app
app = create_app(
    config=config,
    db_engine=db_engine
)

@app.get("/")
def root():
    return {"message": "Welcome to my shop!"}
```

## Module Overviews

- **Auth**: Secure JWT-based authentication with 2FA support.
- **RBAC**: Fine-grained role-based access control using dependencies.
- **Audit**: Automatic change tracking for your SQLAlchemy models.
- **Billing**: Multi-provider payment gateway (Stripe, Paystack).
- **Workflows**: Celery integration for background tasks.

Next: [Database and Migrations Guide](./database-and-migrations.md)
