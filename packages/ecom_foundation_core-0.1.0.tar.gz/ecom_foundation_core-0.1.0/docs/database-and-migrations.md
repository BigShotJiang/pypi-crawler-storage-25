# Database and Migrations Guide

The foundation uses SQLAlchemy 2.0 with the `asyncpg` driver for asynchronous database interactions.

## 1. Connecting to PostgreSQL

To connect to a PostgreSQL database, you must provide an `AsyncEngine` to the `create_app` function. We recommend using the foundation's built-in utility:

```python
from ecom_foundation_core.modules.common.database import create_async_engine

# Use the asyncpg driver
DATABASE_URL = "postgresql+asyncpg://user:password@localhost:5432/ecommerce"

engine = create_async_engine(
    DATABASE_URL,
    echo=False,
    pool_size=20,
    max_overflow=10
)
```

## 2. Setting up Alembic Migrations

Managing migrations in a microservice that uses this foundation requires including the foundation's models in your Alembic `env.py`.

### Step 1: Initialize Alembic

```bash
alembic init -t async migrations
```

### Step 2: Configure `migrations/env.py`

You need to import the `Base` from the foundation and your own models so Alembic can track both.

```python
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from ecom_foundation_core.modules.common.database import Base # Foundation Base
from my_app.models import * # Your application models

# This adds all models to the metadata for discovery
target_metadata = Base.metadata

# ... rest of env.py ...
```

### Step 3: Autogenerating Migrations

When you run `alembic revision --autogenerate`, Alembic will detect the foundation tables (like `users`, `audit_logs`, `transactions`) alongside your custom tables.

## 3. Recommended Production Settings

For production PostgreSQL deployments, we recommend these `create_async_engine` parameters:

- **pool_pre_ping=True**: Always verify the connection is alive before using it.
- **pool_recycle=3600**: Recycle connections every hour to avoid stale connections.
- **connect_args={"server_settings": {"jit": "off"}}**: Turning off JIT in Postgres can improve performance for short-lived web requests.

## 4. Multi-Tenant Support (Optional)

The `DatabaseManager` in the foundation includes built-in hooks for setting the `search_path` to specific schemas, which is useful for multi-tenant isolation.

> [!TIP]
> Always use `AsyncSession` for all DB operations to avoid blocking the FastAPI event loop. You can use the `get_async_session` dependency in your routes.

Next: [Customizing and Extending Models](./customizing-models.md)
