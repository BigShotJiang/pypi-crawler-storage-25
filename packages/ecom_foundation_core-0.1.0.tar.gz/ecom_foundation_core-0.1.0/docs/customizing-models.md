# Customizing and Extending Models

The foundation is designed for extensibility. You can create your own models that integrate seamlessly with the Audit and Auth systems.

## 1. Creating Custom Models

All models must inherit from the foundation's `Base` to ensure they share the same metadata and session management.

```python
from sqlalchemy import String, Integer
from sqlalchemy.orm import Mapped, mapped_column
from ecom_foundation_core.modules.common.database import Base
from ecom_foundation_core.modules.audit.mixins import AuditableMixin

class Product(Base, AuditableMixin):
    """A custom product model with automatic auditing."""
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    price: Mapped[int] = mapped_column(Integer, nullable=False)

    # AuditableMixin provides:
    # 1. Automatic change logging to 'audit_logs' table
    # 2. 'audit_enabled' toggle
```

## 2. Using the Audit System

The `AuditableMixin` automatically hooks into SQLAlchemy's event system. Any changes to a model inheriting from it will be recorded in the `audit_logs` table.

### Excluding Fields

If you have sensitive fields that should not be audited, override the `_audit_exempt` list:

```python
class SensitiveModel(Base, AuditableMixin):
    __tablename__ = "sensitive_data"

    _audit_exempt = ["internal_key", "secret_debug_info"]

    # ... fields ...
```

## 3. Extending the User Model

While the foundation provides a robust `User` model, you can extend your own application logic by linking to it via a Foreign Key or inheriting from the same base.

We recommend using **Composition** for application-specific user data:

```python
from sqlalchemy import ForeignKey
from ecom_foundation_core.modules.auth.models import User

class UserProfile(Base):
    __tablename__ = "user_profiles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), unique=True)
    bio: Mapped[str] = mapped_column(String(500))
```

## 4. Customizing Schemas

You can extend the Pydantic schemas (Request/Response) used by the modules:

```python
from ecom_foundation_core.modules.auth.schemas import UserResponse

class ExtendedUserResponse(UserResponse):
    loyalty_points: int = 0
    is_premium: bool = False
```

Next: [Example Application](../examples/fastapi_app.py)
