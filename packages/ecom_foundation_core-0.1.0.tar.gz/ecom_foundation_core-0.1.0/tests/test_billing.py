import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ecom_foundation_core.modules.billing.models import Transaction, TransactionStatus
from ecom_foundation_core.modules.billing.providers import (
    PaymentProvider,
    PaystackProvider,
)
from ecom_foundation_core.modules.billing.service import BillingService


class DummyProvider(PaymentProvider):
    async def initialize_transaction(self, amount, currency, user_email, **kwargs):
        return {"checkout_url": "https://dummy.checkout", "reference": "DUMMY123"}

    async def verify_transaction(self, reference):
        return reference == "DUMMY123"


@pytest.mark.asyncio
async def test_billing_service_create_checkout():
    session_mock = AsyncMock()
    provider = DummyProvider()

    service = BillingService(session_mock, provider, "dummy")

    uid = uuid.uuid4()
    url = await service.create_checkout(
        user_id=uid, email="test@test.com", amount=5000, currency="USD"
    )

    assert url == "https://dummy.checkout"
    assert session_mock.add.called
    added_tx = session_mock.add.call_args[0][0]

    assert isinstance(added_tx, Transaction)
    assert added_tx.provider_reference == "DUMMY123"
    assert added_tx.status == TransactionStatus.PENDING


@pytest.mark.asyncio
async def test_billing_service_webhook():
    session_mock = AsyncMock()
    provider = DummyProvider()

    service = BillingService(session_mock, provider, "dummy")

    # Mocking DB query return
    tx = Transaction(provider_reference="DUMMY123", status=TransactionStatus.PENDING)
    result_mock = MagicMock()
    result_mock.scalar_one_or_none.return_value = tx
    session_mock.execute.return_value = result_mock

    # Execution
    is_valid = await service.handle_webhook_verification("DUMMY123")

    assert is_valid is True
    assert tx.status == TransactionStatus.SUCCESS


@pytest.mark.asyncio
@patch("httpx.AsyncClient")
async def test_paystack_provider(mock_client):
    provider = PaystackProvider("secret")

    # Mock initialize response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "status": True,
        "data": {
            "authorization_url": "https://checkout.paystack.com/url",
            "reference": "PAYSTACK_REF",
        },
    }
    mock_client.return_value.__aenter__.return_value.post.return_value = mock_response

    res = await provider.initialize_transaction(100, "USD", "test@test.com")
    assert res["checkout_url"] == "https://checkout.paystack.com/url"
    assert res["reference"] == "PAYSTACK_REF"
