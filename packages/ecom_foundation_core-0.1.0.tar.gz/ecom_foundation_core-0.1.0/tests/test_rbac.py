import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import HTTPException

from ecom_foundation_core.modules.rbac.dependencies import require_permissions
from ecom_foundation_core.modules.rbac.service import RBACService


class MockPermission:
    def __init__(self, scope, action):
        self.scope = scope
        self.action = action


class MockRole:
    def __init__(self, permissions):
        self.permissions = permissions


class MockUser:
    def __init__(self, is_superuser=False, roles=None):
        self.id = uuid.uuid4()
        self.is_superuser = is_superuser
        self.roles = roles or []


@pytest.mark.asyncio
async def test_user_has_permission():
    # Setup mocks
    session_mock = AsyncMock()

    # Create test permission: scope='products', action='create'
    perm = MockPermission("products", "create")
    role = MockRole([perm])
    user = MockUser(roles=[role])

    # Mock session execution return
    result_mock = MagicMock()
    result_mock.unique.return_value.scalar_one_or_none.return_value = user
    session_mock.execute.return_value = result_mock

    service = RBACService(session_mock)

    # Should be True for 'products:create'
    assert await service.user_has_permission(user.id, "products", "create") is True

    # Should be False for 'products:delete'
    assert await service.user_has_permission(user.id, "products", "delete") is False


@pytest.mark.asyncio
async def test_require_permissions_dependency():
    dep_func = require_permissions("orders", "read")

    session_mock = AsyncMock()

    # Test failure case
    user = MockUser()  # No roles
    result_mock = MagicMock()
    result_mock.unique.return_value.scalar_one_or_none.return_value = user
    session_mock.execute.return_value = result_mock

    with pytest.raises(HTTPException) as exc:
        await dep_func(current_user=user, session=session_mock)

    assert exc.value.status_code == 403

    # Test success case
    user.is_superuser = True  # Superuser bypasses role checks
    assert await dep_func(current_user=user, session=session_mock) is True
