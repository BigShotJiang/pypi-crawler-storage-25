"""
Tests for the auth module.
"""

import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from ecom_foundation_core.bootstrap import create_test_app


@pytest.fixture(scope="module")
def app() -> FastAPI:
    """Create a test app."""
    return create_test_app()


@pytest_asyncio.fixture(scope="module")
async def client(app: FastAPI) -> AsyncClient:
    """Create a test client."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client


@pytest.mark.asyncio
async def test_register_user(client: AsyncClient):
    """Test user registration."""
    user_data = {
        "email": "test@example.com",
        "password": "password123",
        "password_confirm": "password123",
    }
    response = await client.post("/auth/register", json=user_data)
    assert response.status_code == 200
    data = response.json()
    assert data["user"]["email"] == user_data["email"]
    assert "access_token" in data["tokens"]


@pytest.mark.asyncio
async def test_login_user(client: AsyncClient):
    """Test user login."""
    # First, register a user
    user_data = {
        "email": "login@example.com",
        "password": "password123",
        "password_confirm": "password123",
    }
    await client.post("/auth/register", json=user_data)

    # Now, login
    login_data = {
        "email": "login@example.com",
        "password": "password123",
    }
    response = await client.post("/auth/login", json=login_data)
    assert response.status_code == 200
    data = response.json()
    assert data["user"]["email"] == login_data["email"]
    assert "access_token" in data["tokens"]


@pytest.mark.asyncio
async def test_login_user_wrong_password(client: AsyncClient):
    """Test user login with wrong password."""
    # First, register a user
    user_data = {
        "email": "wrongpass@example.com",
        "password": "password123",
        "password_confirm": "password123",
    }
    await client.post("/auth/register", json=user_data)

    # Now, login with wrong password
    login_data = {
        "email": "wrongpass@example.com",
        "password": "wrongpassword",
    }
    response = await client.post("/auth/login", json=login_data)
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_get_current_user(client: AsyncClient):
    """Test getting the current user."""
    # First, register and login
    user_data = {
        "email": "currentuser@example.com",
        "password": "password123",
        "password_confirm": "password123",
    }
    register_response = await client.post("/auth/register", json=user_data)
    token = register_response.json()["tokens"]["access_token"]

    # Get current user
    headers = {"Authorization": f"Bearer {token}"}
    response = await client.get("/auth/me", headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert data["user"]["email"] == user_data["email"]
