from unittest.mock import patch

import pytest
from sqlalchemy import Column, String

from ecom_foundation_core.modules.audit.listeners import (
    _dispatch_audit_task,
    setup_audit_listeners,
)
from ecom_foundation_core.modules.audit.mixins import AuditableMixin
from ecom_foundation_core.modules.common.database import Base


class DummyModel(AuditableMixin, Base):
    __tablename__ = "dummy_audit_table"
    id = Column(String(36), primary_key=True, default="test_id")
    name = Column(String(50))


@pytest.fixture(autouse=True)
def _setup_listeners():
    setup_audit_listeners(Base)


def test_auditable_mixin_attributes():
    instance = DummyModel(id="123", name="test_item")
    attrs = instance.get_audit_attributes()

    # Mixin default audit_enabled is True
    assert instance.audit_enabled is True
    assert "name" in attrs
    assert "id" in attrs


@patch("ecom_foundation_core.modules.audit.listeners.record_audit_change.delay")
def test_dispatch_audit_task(mock_delay):
    instance = DummyModel(id="123", name="test_item")
    instance._current_user_id = "USER_123"

    _dispatch_audit_task(instance, "INSERT", new_values={"name": "test_item"})

    assert mock_delay.called
    payload = mock_delay.call_args[0][0]

    assert payload["table_name"] == "dummy_audit_table"
    assert payload["action"] == "INSERT"
    assert payload["user_id"] == "USER_123"
    assert payload["new_values"]["name"] == "test_item"
