from ecom_foundation_core.modules.workflows.base import BaseTask
from ecom_foundation_core.modules.workflows.celery_app import celery_app


def test_celery_app_initialization():
    """Test that the Celery app is initialized and configured correctly."""
    assert celery_app is not None
    assert celery_app.main == "ecom_foundation_core_workflows"
    assert celery_app.conf.task_serializer == "json"
    assert celery_app.conf.worker_prefetch_multiplier == 1


def test_base_task_abstract():
    """Test that the BaseTask is marked as abstract."""
    assert BaseTask.abstract is True
