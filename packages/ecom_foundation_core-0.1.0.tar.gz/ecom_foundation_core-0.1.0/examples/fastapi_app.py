"""
Example FastAPI application using IRMS Foundation Core.
Shows how to initialize the app, define custom regulatory models with auditing,
and protect routes with RBAC.
"""

import asyncio

from fastapi import Depends
from sqlalchemy import Integer, String
from sqlalchemy.orm import Mapped, mapped_column

# 1. Foundation Imports
from ecom_foundation_core.bootstrap import AppConfig, create_app
from ecom_foundation_core.modules.audit.mixins import AuditableMixin
from ecom_foundation_core.modules.common.database import (
    Base,
    create_async_engine,
    get_async_session,
)
from ecom_foundation_core.modules.rbac.dependencies import require_permissions


# 2. Define Custom Models
class Regulation(Base, AuditableMixin):
    """A custom regulatory model that integrates with the Audit system."""

    __tablename__ = "regulations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    code: Mapped[str] = mapped_column(String(50), nullable=False)
    description: Mapped[str | None] = mapped_column(String(1000))


# 3. Setup Configuration
config = AppConfig(
    enable_auth=True,
    enable_rbac=True,
    enable_audit=True,
    title="IRMS Regulatory Management Service",
    version="1.0.0",
)

# 4. Initialize Database Engine
DATABASE_URL = "sqlite+aiosqlite:///example.db"
engine = create_async_engine(DATABASE_URL)

# 5. Create the Bootstrap App
app = create_app(config=config, db_engine=engine)


# 6. Define Routes with RBAC and Foundation Patterns
@app.get("/regulations", response_model=list[dict])
async def list_regulations(session=Depends(get_async_session)):
    """Public endpoint to list regulations."""
    from sqlalchemy.future import select

    result = await session.execute(select(Regulation))
    return [
        {"id": r.id, "title": r.title, "code": r.code} for r in result.scalars().all()
    ]


@app.post(
    "/regulations", dependencies=[Depends(require_permissions(["regulations.create"]))]
)
async def create_regulation(title: str, code: str, session=Depends(get_async_session)):
    """Protected endpoint (requires 'regulations.create' permission)."""
    regulation = Regulation(title=title, code=code)
    session.add(regulation)
    return {"status": "created", "regulation_title": title}


@app.get("/health-check")
async def imrs_health():
    return {"status": "online", "foundation": "stable"}


if __name__ == "__main__":
    import uvicorn

    async def init_demo():
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        print("IRMS Demo database initialized.")

    asyncio.run(init_demo())
    uvicorn.run(app, host="0.0.0.0", port=8000)
