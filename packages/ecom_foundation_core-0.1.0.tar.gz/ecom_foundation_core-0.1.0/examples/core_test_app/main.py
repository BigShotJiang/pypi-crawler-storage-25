import logging
import uuid
from contextlib import asynccontextmanager
from typing import Any

import uvicorn
from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.future import select

# Foundation Core Imports
from ecom_foundation_core.bootstrap import AppConfig, app_lifespan, create_app
from ecom_foundation_core.modules.audit.mixins import AuditableMixin
from ecom_foundation_core.modules.audit.models import AuditLog
from ecom_foundation_core.modules.auth.models import Role, User
from ecom_foundation_core.modules.auth.security import get_password_hash
from ecom_foundation_core.modules.billing.models import Transaction
from ecom_foundation_core.modules.billing.providers import PaymentProvider
from ecom_foundation_core.modules.billing.service import BillingService
from ecom_foundation_core.modules.common.config import get_config
from ecom_foundation_core.modules.common.database import Base, get_async_session
from ecom_foundation_core.modules.notifications.service import (
    LoggingNotificationService,
)
from ecom_foundation_core.modules.rbac.service import RBACService

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Mock Providers ---


class MockPaymentProvider(PaymentProvider):
    """A mock payment provider for testing billing without real API keys."""

    async def initialize_transaction(
        self, amount: int, currency: str, user_email: str, **kwargs: Any
    ) -> dict[str, Any]:
        ref = f"mock_ref_{uuid.uuid4().hex[:8]}"
        return {
            "checkout_url": f"https://mock-payment.com/pay/{ref}",
            "reference": ref,
            "status": "success",
        }

    async def verify_transaction(self, reference: str) -> bool:
        return True  # Always succeed in mock


# --- Models ---


class TestProduct(AuditableMixin, Base):
    """Sample auditable model to test automatic audit logging."""

    __tablename__ = "test_products"

    __table_args__ = {"extend_existing": True}

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), nullable=False)
    price = Column(Integer, default=0)
    description = Column(String(255))


# --- Schemas ---


class ProductCreate(BaseModel):
    name: str
    price: int
    description: str | None = None


class ProductResponse(ProductCreate):
    id: str

    class Config:
        from_attributes = True


class RoleCreate(BaseModel):
    name: str
    description: str | None = None


class CheckoutRequest(BaseModel):
    amount: int
    currency: str = "USD"
    email: str


class NotificationTestStep(BaseModel):
    email: str
    subject: str
    message: str


# --- Lifespan & Seeding ---


@asynccontextmanager
async def test_app_lifespan(app: FastAPI):
    """
    Custom lifespan for the test application.
    Wraps core initialization and performs data seeding.
    """
    async with app_lifespan(app):
        # 1. Create Tables
        logger.info("Initializing database tables...")
        engine = app.state.db_engine
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

        # 2. Seed Data
        async with AsyncSession(engine) as session:
            # Seed Roles
            logger.info("Seeding roles...")
            for role_name in ["admin", "user", "manager"]:
                result = await session.execute(
                    select(Role).where(Role.name == role_name)
                )
                if not result.scalar_one_or_none():
                    session.add(
                        Role(name=role_name, description=f"Standard {role_name} role")
                    )

            # Seed Admin User
            logger.info("Seeding admin user...")
            result = await session.execute(
                select(User).where(User.email == "admin@example.com")
            )
            if not result.scalar_one_or_none():
                admin_user = User(
                    email="admin@example.com",
                    password_hash=get_password_hash("admin123"),
                    is_active=True,
                    is_superuser=True,
                )
                session.add(admin_user)

            await session.commit()
            logger.info("Seeding completed.")

        yield


# --- Application Factory ---


def get_application() -> FastAPI:
    settings = get_config()

    app_config = AppConfig(
        title="Foundation Core - Full Feature Test",
        version="0.2.0",
        enable_auth=True,
        enable_rbac=True,
        enable_audit=True,
        enable_notifications=True,
        enable_billing=True,
    )

    # DB Engine
    db_url = (
        settings.DATABASE_URL or "postgresql+asyncpg://user:password@db:5432/testdb"
    )
    engine = create_async_engine(db_url)

    # Initialize Core Application
    app = create_app(
        config=app_config,
        db_engine=engine,
        lifespan=test_app_lifespan,
    )

    # --- Feature Endpoints ---

    # 1. Products (to test Auditing)
    @app.get("/products", tags=["Products"])
    async def list_products(db: AsyncSession = Depends(get_async_session)):
        result = await db.execute(select(TestProduct))
        return result.scalars().all()

    @app.post("/products", tags=["Products"], response_model=ProductResponse)
    async def create_product(
        product: ProductCreate, db: AsyncSession = Depends(get_async_session)
    ):
        new_product = TestProduct(**product.model_dump())
        db.add(new_product)
        await db.commit()
        await db.refresh(new_product)
        return new_product

    @app.patch(
        "/products/{product_id}", tags=["Products"], response_model=ProductResponse
    )
    async def update_product(
        product_id: str,
        update: ProductCreate,
        db: AsyncSession = Depends(get_async_session),
    ):
        result = await db.execute(
            select(TestProduct).where(TestProduct.id == product_id)
        )
        product = result.scalar_one_or_none()
        if not product:
            raise HTTPException(404, "Product not found")

        for key, value in update.model_dump(exclude_unset=True).items():
            setattr(product, key, value)

        await db.commit()
        await db.refresh(product)
        return product

    # 2. RBAC (to test Roles)
    @app.get("/admin/roles", tags=["Admin (RBAC)"])
    async def list_roles(db: AsyncSession = Depends(get_async_session)):
        result = await db.execute(select(Role))
        return result.scalars().all()

    @app.post("/admin/roles", tags=["Admin (RBAC)"])
    async def create_role(
        role_data: RoleCreate, db: AsyncSession = Depends(get_async_session)
    ):
        new_role = Role(name=role_data.name, description=role_data.description)
        db.add(new_role)
        await db.commit()
        return {"status": "success", "role": role_data.name}

    @app.post("/admin/users/{user_id}/assign-role/{role_name}", tags=["Admin (RBAC)"])
    async def assign_role(
        user_id: str, role_name: str, db: AsyncSession = Depends(get_async_session)
    ):
        rbac = RBACService(db)
        await rbac.assign_role_to_user(uuid.UUID(user_id), role_name)
        return {
            "status": "success",
            "message": f"Role {role_name} assigned to user {user_id}",
        }

    # 3. Audit Logs
    @app.get("/admin/audit-logs", tags=["Admin (Audit)"])
    async def get_audit_logs(
        limit: int = 50, db: AsyncSession = Depends(get_async_session)
    ):
        result = await db.execute(
            select(AuditLog).order_by(AuditLog.timestamp.desc()).limit(limit)
        )
        return result.scalars().all()

    # 4. Notifications (Test endpoints)
    @app.post("/test/notifications/email", tags=["Test (Notifications)"])
    async def test_email(data: NotificationTestStep):
        service = LoggingNotificationService()
        await service.send_email(
            to_email=data.email,
            subject=data.subject,
            template_name="test_template",
            context={"message": data.message},
        )
        return {"status": "success", "info": "Check console logs for email output"}

    # 5. Billing (Test endpoints)
    @app.post("/test/billing/checkout", tags=["Test (Billing)"])
    async def test_checkout(
        req: CheckoutRequest, db: AsyncSession = Depends(get_async_session)
    ):
        # Generate a random user ID for the mock checkout
        mock_user_id = uuid.uuid4()
        provider = MockPaymentProvider()
        billing = BillingService(db, provider, "mock_gateway")

        checkout_url = await billing.create_checkout(
            user_id=mock_user_id,
            email=req.email,
            amount=req.amount,
            currency=req.currency,
        )
        return {"checkout_url": checkout_url, "info": "Transaction saved as PENDING"}

    @app.get("/test/billing/transactions", tags=["Test (Billing)"])
    async def list_transactions(db: AsyncSession = Depends(get_async_session)):
        result = await db.execute(
            select(Transaction).order_by(Transaction.created_at.desc())
        )
        return result.scalars().all()

    return app


app = get_application()

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
