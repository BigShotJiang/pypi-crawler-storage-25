# E-Com Foundation Core

A production-ready foundation for high-performance enterprise microservices. Built with **FastAPI**, **Pydantic V2**, and **SQLAlchemy 2.0 (Async)**.

---

## 🚀 Overview

`ecom_foundation_core` provides a modular backbone for complex enterprise systems. It is an enterprise foundation platform with auth, billing, notifications, and workflows, modularizing Authentication, RBAC, Billing, and Auditing—allowing you to build new microservices in minutes instead of months. While originally designed for the Ordvel marketplace, it is currently the foundation for the **International Regulatory Management System (IRMS)**.

### Core Modules

- 🔑 **Auth**: JWT-based authentication, password hashing, and 2FA.
- 🛡️ **RBAC**: Multi-role support with fine-grained permission enforcement.
- 💳 **Billing**: Unified interface for Stripe and Paystack.
- 📜 **Audit**: Automatic logging of database changes (INSERT/UPDATE/DELETE).
- ⚙️ **Workflows**: Built-in Celery integration for asynchronous processing.

---

## 🛠️ Getting Started

### Installation

```bash
pip install ecom-foundation-core
```

### Quick Start Example

This is all you need to create a fully secure microservice using the foundation:

```python
from ecom_foundation_core.bootstrap import create_app, AppConfig
from ecom_foundation_core.modules.common.database import create_async_engine

# 1. Configuration
config = AppConfig(
    title="Order Service",
    enable_auth=True,
    enable_rbac=True
)

# 2. Initialize PostgreSQL
db_engine = create_async_engine("postgresql+asyncpg://user:pass@localhost/db")

# 3. Bootstrap
app = create_app(config=config, db_engine=db_engine)
```

---

## 📖 In-Depth Guides

We have provided step-by-step guides for every part of the system:

1.  **[Getting Started](./docs/getting-started.md)**: Standard installation and basic usage.
2.  **[Database & Migrations](./docs/database-and-migrations.md)**: Connecting to Postgres and managing migrations with Alembic.
3.  **[Customizing Models](./docs/customizing-models.md)**: How to add your own fields and models, and how to use the `AuditableMixin`.
4.  **[Example Application](./examples/fastapi_app.py)**: A standalone, runnable FastAPI application demonstrating all features.

---

## 🧬 Extending the System

The foundation is designed to be personalized. You can easily extend internal models by inheriting from `Base`:

```python
from ecom_foundation_core.modules.common.database import Base
from ecom_foundation_core.modules.audit.mixins import AuditableMixin

class Product(Base, AuditableMixin):
    __tablename__ = "products"
    name: Mapped[str] = mapped_column(String(255))
    price: Mapped[int] = mapped_column(Integer)
```

Adding this model to your application's `metadata` will automatically allow you to manage it via migrations and track it with the Audit system.

---

## 🧪 Testing

The foundation comes with a robust test suite in Docker for maximum reliability:

```bash
docker compose -f docker-compose.test.yml up --build
```

---

## 📄 License

e-com services limited. All rights reserved.
