# Changelog

## [0.1.0] - 2024-01-15

### Added

- Initial release with auth, notifications, and billing modules
- FastAPI application factory
- SQLAlchemy models and migrations
- SendGrid and Twilio integrations

### Changed

- N/A

### Deprecated

- N/A

### Removed

- N/A

### Fixed

- N/A
