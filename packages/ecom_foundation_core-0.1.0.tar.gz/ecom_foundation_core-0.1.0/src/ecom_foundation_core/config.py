"""
Top-level configuration exports.

Many modules import `Settings`/`get_settings` from `ecom_foundation_core.config`.
The canonical settings model lives in `ecom_foundation_core.modules.common.config`.
"""

from .modules.common.config import Settings, get_settings

__all__ = ["Settings", "get_settings"]
