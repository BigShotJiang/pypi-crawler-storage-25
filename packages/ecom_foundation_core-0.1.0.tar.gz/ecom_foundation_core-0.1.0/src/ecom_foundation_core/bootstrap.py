"""
FastAPI foundation platform.
"""

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .modules.auth import setup_auth
from .modules.common.audit_logging import (
    AuditLogMiddleware,
    close_audit_logging,
    get_audit_logger,
    init_audit_logging,
)
from .modules.common.config import get_config
from .modules.common.middleware import (
    CompressionMiddleware,
    LoggingMiddleware,
    RequestIDMiddleware,
    SecurityHeadersMiddleware,
    TimeoutMiddleware,
    setup_middleware,
)
from .modules.common.monitoring import metrics_collector, setup_structured_logging
from .modules.common.rate_limiting import RateLimitMiddleware


class AppConfig:
    """Application configuration for enabling/disabling modules."""

    def __init__(
        self,
        enable_auth: bool = True,
        enable_billing: bool = False,
        enable_notifications: bool = True,
        enable_audit: bool = True,
        enable_rbac: bool = True,
        enable_workflows: bool = False,
        enable_cors: bool = True,
        cors_origins: list[str] | None = None,
        title: str = "E-Com Foundation Platform",
        version: str = "1.0.0",
        docs_url: str = "/docs",
        redoc_url: str = "/redoc",
        openapi_url: str = "/openapi.json",
    ) -> None:
        self.enable_auth = enable_auth
        self.enable_billing = enable_billing
        self.enable_notifications = enable_notifications
        self.enable_audit = enable_audit
        self.enable_rbac = enable_rbac
        self.enable_workflows = enable_workflows
        self.enable_cors = enable_cors
        self.cors_origins = cors_origins
        self.title = title
        self.version = version
        self.docs_url = docs_url
        self.redoc_url = redoc_url
        self.openapi_url = openapi_url


@asynccontextmanager
async def app_lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Manage application lifespan events.

    Args:
        app: FastAPI application

    Yields:
        None
    """
    # Startup
    config = get_config()
    logger = structlog.get_logger(__name__)

    logger.info("Application starting up", environment=config.ENVIRONMENT)

    try:
        # Initialize audit logging
        # NOTE: DB/Redis init would now be handled by the consuming application
        # before this lifespan starts.
        await init_audit_logging()
        logger.info("Audit logging initialized")

        yield

    except Exception as e:
        logger.error("Failed to initialize application", error=str(e))
        raise

    finally:
        # Shutdown
        logger.info("Application shutting down")

        await close_audit_logging()  # Audit logging might still have its own lifecycle


def create_app(
    config: AppConfig | None = None,
    db_engine: Any | None = None,
    redis_client: Any | None = None,
    lifespan: Any | None = None,
) -> FastAPI:
    """
    Create and configure a FastAPI application with the specified modules.

    Args:
        config: Application configuration

    Returns:
        Configured FastAPI application
    """
    config = config or AppConfig()
    common_config = get_config()

    cors_origins = config.cors_origins or common_config.CORS_ORIGINS

    # Create FastAPI app with lifespan
    app = FastAPI(
        title=config.title,
        version=config.version,
        docs_url=config.docs_url,
        redoc_url=config.redoc_url,
        lifespan=lifespan or app_lifespan,
    )

    # Store settings and config in app state
    app.state.settings = common_config
    app.state.config = config

    # Store injected resources
    app.state.db_engine = db_engine
    app.state.redis_client = redis_client
    app.state.common_config = common_config

    # Setup all middleware
    setup_middleware(app)

    # Setup monitoring middleware early (it must be added before startup)
    setup_structured_logging()
    metrics_collector.setup_middleware(app)

    # Add middleware
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(LoggingMiddleware)
    app.add_middleware(TimeoutMiddleware, timeout=common_config.request_timeout)
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(CompressionMiddleware)

    # Add rate limiting middleware
    if common_config.RATE_LIMIT_ENABLED:
        app.add_middleware(
            RateLimitMiddleware,
            limit=100,  # 100 requests per minute per IP
            window=60,
            strategy="sliding_window",
        )

    # Add audit logging middleware
    if common_config.AUDIT_LOG_ENABLED:
        audit_logger = get_audit_logger()
        app.add_middleware(AuditLogMiddleware, audit_logger=audit_logger)

    if config.enable_cors:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins,
            allow_credentials=common_config.CORS_ALLOW_CREDENTIALS,
            allow_methods=common_config.CORS_ALLOW_METHODS,
            allow_headers=common_config.CORS_ALLOW_HEADERS,
        )

    # Setup modules
    if config.enable_auth:
        setup_auth(app)
        app.state.modules_enabled = {"auth": True}

    if config.enable_billing:
        try:
            from .modules.billing import setup_billing  # type: ignore
        except Exception:
            setup_billing = None
        if setup_billing:
            setup_billing(app)
        app.state.modules_enabled["billing"] = True

    if config.enable_notifications:
        try:
            from .modules.notifications import setup_notifications  # type: ignore
        except Exception:
            setup_notifications = None
        if setup_notifications:
            setup_notifications(app)
        app.state.modules_enabled["notifications"] = True

    if config.enable_audit:
        try:
            from .modules.audit import setup_audit  # type: ignore
        except Exception:
            setup_audit = None
        if setup_audit:
            setup_audit(app)
        app.state.modules_enabled["audit"] = True

    if config.enable_rbac:
        try:
            from .modules.rbac import setup_rbac  # type: ignore
        except Exception:
            setup_rbac = None
        if setup_rbac:
            setup_rbac(app)
        app.state.modules_enabled["rbac"] = True

    if config.enable_workflows:
        try:
            from .modules.workflows import setup_workflows  # type: ignore
        except Exception:
            setup_workflows = None
        if setup_workflows:
            setup_workflows(app)
        app.state.modules_enabled["workflows"] = True

    # Add basic health endpoint (overrides metrics health endpoint for simple check)
    @app.get("/health")
    async def health_check() -> dict[str, Any]:
        """Simple health check endpoint."""
        return {
            "status": "healthy",
            "service": config.title,
            "version": config.version,
            "environment": common_config.ENVIRONMENT,
        }

    # Add version endpoint
    @app.get("/version")
    async def version_info() -> dict[str, Any]:
        """Get version information."""
        return {
            "name": config.title,
            "version": config.version,
            "api_version": "v1",
            "environment": common_config.ENVIRONMENT,
        }

    return app


def create_test_app(config: AppConfig | None = None) -> FastAPI:
    """
    Create a test application with IRMS test configuration.

    Args:
        config: Application configuration

    Returns:
        Test FastAPI application
    """
    # Keep the test app self-contained (no external DB/Redis needed).
    from uuid import UUID, uuid4

    from fastapi import Depends, HTTPException, status
    from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

    from .modules.auth.security import (
        create_tokens,
        decode_token,
        get_password_hash,
        verify_password,
    )

    config = config or AppConfig(
        enable_auth=True,
        enable_rbac=True,
        enable_audit=True,
        title="IRMS Regulatory Service",
        version="1.0.0",
    )

    app = FastAPI(
        title=config.title,
        version=config.version,
        docs_url="/docs",
        redoc_url="/redoc",
    )
    security = HTTPBearer()

    # In-memory user store for tests
    users_by_email: dict[str, dict] = {}
    users_by_id: dict[str, dict] = {}

    def _user_public(user: dict) -> dict:
        return {"id": user["id"], "email": user["email"]}

    async def _current_user(
        creds: HTTPAuthorizationCredentials = Depends(security),
    ) -> dict:
        token = creds.credentials
        try:
            payload = decode_token(token)
        except ValueError as e:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(e))
        user_id = payload.get("sub")
        user = users_by_id.get(user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token"
            )
        return user

    @app.post("/auth/register")
    async def register(user_data: dict) -> dict[str, Any]:
        email = user_data.get("email")
        password = user_data.get("password")
        password_confirm = user_data.get("password_confirm")
        if not email or not password:
            raise HTTPException(
                status_code=422, detail="email and password are required"
            )
        if password != password_confirm:
            raise HTTPException(status_code=422, detail="passwords do not match")
        if email in users_by_email:
            raise HTTPException(status_code=400, detail="User already exists")

        user_id = str(uuid4())
        user = {
            "id": user_id,
            "email": email,
            "password_hash": get_password_hash(password),
        }
        users_by_email[email] = user
        users_by_id[user_id] = user

        tokens = create_tokens(UUID(user_id))
        return {"user": _user_public(user), "tokens": tokens.model_dump()}

    @app.post("/auth/login")
    async def login(login_data: dict) -> dict[str, Any]:
        email = login_data.get("email")
        password = login_data.get("password")
        user = users_by_email.get(email)
        if not user or not verify_password(password or "", user["password_hash"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials"
            )
        tokens = create_tokens(UUID(user["id"]))
        return {"user": _user_public(user), "tokens": tokens.model_dump()}

    @app.get("/auth/me")
    async def me(user: dict = Depends(_current_user)) -> dict[str, Any]:
        return {"user": _user_public(user)}

    return app
