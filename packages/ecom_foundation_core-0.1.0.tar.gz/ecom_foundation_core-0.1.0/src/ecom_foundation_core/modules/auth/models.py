"""
SQLAlchemy models for authentication.
"""

import uuid
from datetime import UTC, datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import relationship, validates

from ..common.database import Base
from .constants import (
    TOKEN_TYPE_ACCESS,
    TOKEN_TYPE_INVITATION,
    TOKEN_TYPE_REFRESH,
    TOKEN_TYPE_RESET,
    TOKEN_TYPE_VERIFICATION,
    USER_STATUS_PENDING,
)


class TimestampMixin:
    """Mixin for timestamp columns."""

    created_at = Column(
        DateTime(timezone=True), default=lambda: datetime.now(UTC), nullable=False
    )
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )


class User(Base, TimestampMixin):
    """User model."""

    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, index=True, nullable=False)
    email_verified = Column(Boolean, default=False, nullable=False)
    phone_number = Column(String(50), unique=True, index=True, nullable=True)
    phone_verified = Column(Boolean, default=False, nullable=False)
    username = Column(String(100), unique=True, index=True, nullable=True)

    # Password fields
    password_hash = Column(String(255), nullable=False)
    password_changed_at = Column(DateTime(timezone=True), nullable=True)

    # Personal information
    first_name = Column(String(100), nullable=True)
    last_name = Column(String(100), nullable=True)
    display_name = Column(String(200), nullable=True)
    avatar_url = Column(Text, nullable=True)
    timezone = Column(String(50), default="UTC", nullable=False)
    locale = Column(String(10), default="en-US", nullable=False)

    # Status and security
    status = Column(
        Enum(
            "active", "inactive", "pending", "suspended", "deleted", name="user_status"
        ),
        default=USER_STATUS_PENDING,
        nullable=False,
    )
    is_active = Column(Boolean, default=True, nullable=False)
    is_superuser = Column(Boolean, default=False, nullable=False)
    last_login_at = Column(DateTime(timezone=True), nullable=True)
    last_login_ip = Column(String(45), nullable=True)  # IPv6 compatible
    failed_login_attempts = Column(Integer, default=0, nullable=False)
    locked_until = Column(DateTime(timezone=True), nullable=True)

    # Two-factor authentication
    two_factor_enabled = Column(Boolean, default=False, nullable=False)
    two_factor_method = Column(
        String(20), nullable=True
    )  # 'sms', 'email', 'totp', 'app'
    two_factor_secret = Column(String(255), nullable=True)

    # Metadata
    metadata_ = Column("metadata", JSONB, default=dict, nullable=False)

    # Relationships
    roles = relationship(
        "Role",
        secondary="user_roles",
        primaryjoin="User.id == UserRole.user_id",
        secondaryjoin="Role.id == UserRole.role_id",
        back_populates="users",
    )
    sessions = relationship(
        "Session", back_populates="user", cascade="all, delete-orphan"
    )
    tokens = relationship("Token", back_populates="user", cascade="all, delete-orphan")
    oauth_accounts = relationship(
        "OAuthAccount", back_populates="user", cascade="all, delete-orphan"
    )
    backup_codes = relationship(
        "BackupCode", back_populates="user", cascade="all, delete-orphan"
    )

    # Indexes
    __table_args__ = (
        Index("idx_user_status", "status", "is_active"),
        Index("idx_user_email_verified", "email_verified"),
        Index("idx_user_last_login", "last_login_at"),
    )

    @property
    def full_name(self) -> str | None:
        """Get user's full name."""
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.first_name or self.last_name or self.username or self.email

    @validates("email")
    def validate_email(self, key: str, email: str | None) -> str | None:
        """Validate email format."""
        if email:
            # Simple email validation (product can add more complex validation)
            if "@" not in email:
                raise ValueError("Invalid email format")
            return email.lower()
        return email

    def __repr__(self) -> str:
        return f"<User(id={self.id}, email={self.email})>"


class Role(Base, TimestampMixin):
    """Role model for RBAC."""

    __tablename__ = "roles"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    is_system = Column(
        Boolean, default=False, nullable=False
    )  # If true, cannot be deleted
    is_default = Column(
        Boolean, default=False, nullable=False
    )  # If true, assigned to new users

    # Relationships
    permissions = relationship(
        "Permission",
        secondary="role_permissions",
        primaryjoin="Role.id == RolePermission.role_id",
        secondaryjoin="Permission.id == RolePermission.permission_id",
        back_populates="roles",
    )
    users = relationship(
        "User",
        secondary="user_roles",
        primaryjoin="Role.id == UserRole.role_id",
        secondaryjoin="User.id == UserRole.user_id",
        back_populates="roles",
    )

    def __repr__(self) -> str:
        return f"<Role(id={self.id}, name={self.name})>"


class Permission(Base, TimestampMixin):
    """Permission model for RBAC."""

    __tablename__ = "permissions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scope = Column(String(100), nullable=False)  # e.g., 'users', 'products', 'orders'
    action = Column(
        String(50), nullable=False
    )  # e.g., 'create', 'read', 'update', 'delete'
    resource = Column(String(100), nullable=True)  # Specific resource identifier
    description = Column(Text, nullable=True)

    # Relationships
    roles = relationship(
        "Role",
        secondary="role_permissions",
        primaryjoin="Permission.id == RolePermission.permission_id",
        secondaryjoin="Role.id == RolePermission.role_id",
        back_populates="permissions",
    )

    # Index
    __table_args__ = (
        Index("idx_permission_scope_action", "scope", "action"),
        Index("idx_permission_unique", "scope", "action", "resource", unique=True),
    )

    @property
    def codename(self) -> str:
        """Generate permission codename."""
        if self.resource:
            return f"{self.scope}.{self.action}:{self.resource}"
        return f"{self.scope}.{self.action}"

    def __repr__(self) -> str:
        return f"<Permission(id={self.id}, codename={self.codename})>"


class UserRole(Base):
    """Many-to-many relationship between users and roles."""

    __tablename__ = "user_roles"

    user_id = Column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    role_id = Column(
        UUID(as_uuid=True), ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True
    )
    assigned_at = Column(DateTime(timezone=True), default=lambda: datetime.now(UTC))
    assigned_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)

    # Index
    __table_args__ = (
        Index("idx_user_role_user", "user_id"),
        Index("idx_user_role_role", "role_id"),
    )


class RolePermission(Base):
    """Many-to-many relationship between roles and permissions."""

    __tablename__ = "role_permissions"

    role_id = Column(
        UUID(as_uuid=True), ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True
    )
    permission_id = Column(
        UUID(as_uuid=True),
        ForeignKey("permissions.id", ondelete="CASCADE"),
        primary_key=True,
    )
    granted_at = Column(DateTime(timezone=True), default=lambda: datetime.now(UTC))
    granted_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)


class Session(Base, TimestampMixin):
    """User session model."""

    __tablename__ = "sessions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    session_token = Column(Text, unique=True, nullable=False)
    refresh_token = Column(Text, unique=True, nullable=False)
    user_agent = Column(Text, nullable=True)
    ip_address = Column(String(45), nullable=True)  # IPv6 compatible
    device_info = Column(JSONB, nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    last_activity_at = Column(
        DateTime(timezone=True), default=lambda: datetime.now(UTC)
    )
    is_revoked = Column(Boolean, default=False, nullable=False)
    revoked_at = Column(DateTime(timezone=True), nullable=True)
    revoked_reason = Column(Text, nullable=True)

    # Relationships
    user = relationship("User", back_populates="sessions")

    # Indexes
    __table_args__ = (
        Index("idx_session_user", "user_id"),
        Index("idx_session_token", "session_token"),
        Index("idx_session_expires", "expires_at"),
        Index("idx_session_active", "user_id", "is_revoked", "expires_at"),
    )

    @property
    def is_active(self) -> bool:
        """Check if session is active."""
        now = datetime.now(UTC)
        return not self.is_revoked and self.expires_at > now

    def __repr__(self) -> str:
        return f"<Session(id={self.id}, user_id={self.user_id})>"


class Token(Base):
    """Token model for various purposes (reset, verification, invitation)."""

    __tablename__ = "tokens"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    token = Column(Text, nullable=False, index=True)
    token_type = Column(
        Enum(
            TOKEN_TYPE_ACCESS,
            TOKEN_TYPE_REFRESH,
            TOKEN_TYPE_RESET,
            TOKEN_TYPE_VERIFICATION,
            TOKEN_TYPE_INVITATION,
            name="token_type",
        ),
        nullable=False,
    )
    expires_at = Column(DateTime(timezone=True), nullable=False)
    used_at = Column(DateTime(timezone=True), nullable=True)
    # NOTE: `metadata` is a reserved attribute name in SQLAlchemy declarative models.
    token_metadata = Column("metadata", JSONB, default=dict, nullable=False)
    created_at = Column(
        DateTime(timezone=True), default=lambda: datetime.now(UTC), nullable=False
    )

    # Relationships
    user = relationship("User", back_populates="tokens")

    # Indexes
    __table_args__ = (
        Index("idx_token_user_type", "user_id", "token_type"),
        Index("idx_token_expires", "expires_at"),
        Index("idx_token_value", "token"),
    )

    @property
    def is_valid(self) -> bool:
        """Check if token is valid (not used and not expired)."""
        now = datetime.now(UTC)
        return not self.used_at and self.expires_at > now

    def __repr__(self) -> str:
        return f"<Token(id={self.id}, type={self.token_type}, user_id={self.user_id})>"


class OAuthAccount(Base, TimestampMixin):
    """OAuth account linking."""

    __tablename__ = "oauth_accounts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    provider = Column(
        String(50), nullable=False
    )  # 'google', 'facebook', 'github', etc.
    provider_user_id = Column(String(255), nullable=False)
    provider_email = Column(String(255), nullable=True)
    access_token = Column(Text, nullable=True)
    refresh_token = Column(Text, nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=True)
    profile_data = Column(JSONB, default=dict, nullable=False)

    # Relationships
    user = relationship("User", back_populates="oauth_accounts")

    # Unique constraint
    __table_args__ = (
        Index("idx_oauth_provider_user", "provider", "provider_user_id", unique=True),
        Index("idx_oauth_user", "user_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<OAuthAccount(id={self.id}, provider={self.provider}, "
            f"user_id={self.user_id})>"
        )


class BackupCode(Base, TimestampMixin):
    """Model for storing hashed 2FA backup codes."""

    __tablename__ = "backup_codes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    code_hash = Column(String(255), nullable=False)
    used_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", back_populates="backup_codes")

    __table_args__ = (Index("idx_backup_code_user", "user_id"),)

    def __repr__(self) -> str:
        return (
            f"<BackupCode(id={self.id}, user_id={self.user_id}, "
            f"used={self.used_at is not None})>"
        )
