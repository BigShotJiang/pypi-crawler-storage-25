"""
Pydantic schemas for authentication.
"""

import re
from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import (
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    ValidationInfo,
    field_validator,
)

from .constants import (
    PASSWORD_MAX_LENGTH,
    PASSWORD_MIN_LENGTH,
)


# Base schemas
class BaseUser(BaseModel):
    """Base user schema."""

    email: EmailStr
    username: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    phone_number: str | None = None
    timezone: str = "UTC"
    locale: str = "en-US"
    metadata: dict[str, Any] = Field(default_factory=dict, validation_alias="metadata_")

    model_config = ConfigDict(from_attributes=True)

    @field_validator("phone_number")
    def validate_phone_number(cls, v: str | None) -> str | None:
        if v:
            # Simple phone validation - products can override with
            # more complex validation
            v = v.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
            if not v.startswith("+"):
                v = f"+{v}"
            if not re.match(r"^\+\d{10,15}$", v):
                raise ValueError("Invalid phone number format")
        return v

    @field_validator("username")
    def validate_username(cls, v: str | None) -> str | None:
        if v:
            if len(v) < 3:
                raise ValueError("Username must be at least 3 characters")
            if len(v) > 50:
                raise ValueError("Username must be at most 50 characters")
            if not re.match(r"^[a-zA-Z0-9_.-]+$", v):
                raise ValueError(
                    "Username can only contain letters, numbers, dots, "
                    "hyphens, and underscores"
                )
        return v


# Request schemas
class UserCreate(BaseUser):
    """Schema for user creation."""

    password: str = Field(
        min_length=PASSWORD_MIN_LENGTH, max_length=PASSWORD_MAX_LENGTH
    )
    password_confirm: str = Field(
        min_length=PASSWORD_MIN_LENGTH, max_length=PASSWORD_MAX_LENGTH
    )

    @field_validator("password_confirm")
    def passwords_match(cls, v: str, info: ValidationInfo) -> str:
        if "password" in info.data and v != info.data["password"]:
            raise ValueError("Passwords do not match")
        return v

    @field_validator("password")
    def password_strength(cls, v: str) -> str:
        # Check for at least one digit
        if not re.search(r"\d", v):
            raise ValueError("Password must contain at least one digit")
        # Check for at least one uppercase letter
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter")
        # Check for at least one lowercase letter
        if not re.search(r"[a-z]", v):
            raise ValueError("Password must contain at least one lowercase letter")
        # Check for at least one special character
        if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", v):
            raise ValueError("Password must contain at least one special character")
        return v


class UserUpdate(BaseModel):
    """Schema for user updates."""

    username: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    phone_number: str | None = None
    timezone: str | None = None
    locale: str | None = None
    avatar_url: str | None = None
    metadata: dict[str, Any] | None = Field(default=None, validation_alias="metadata_")

    model_config = ConfigDict(from_attributes=True)

    @field_validator("phone_number")
    def validate_phone_number(cls, v: str | None) -> str | None:
        if v:
            v = v.replace(" ", "").replace("-", "").replace("(", "").replace(")")
            if not v.startswith("+"):
                v = f"+{v}"
            if not re.match(r"^\+\d{10,15}$", v):
                raise ValueError("Invalid phone number format")
        return v


class PasswordUpdate(BaseModel):
    """Schema for password updates."""

    current_password: str
    new_password: str = Field(
        min_length=PASSWORD_MIN_LENGTH, max_length=PASSWORD_MAX_LENGTH
    )
    new_password_confirm: str = Field(
        min_length=PASSWORD_MIN_LENGTH, max_length=PASSWORD_MAX_LENGTH
    )

    @field_validator("new_password_confirm")
    def passwords_match(cls, v: str, info: ValidationInfo) -> str:
        if "new_password" in info.data and v != info.data["new_password"]:
            raise ValueError("Passwords do not match")
        return v


class LoginRequest(BaseModel):
    """Schema for login requests."""

    email: EmailStr | None = None
    username: str | None = None
    password: str
    remember_me: bool = False
    device_info: dict[str, Any] | None = None

    @field_validator("email", mode="before")
    def normalize_email(cls, v: str | None) -> str | None:
        if v:
            return v.lower()
        return v


class TokenRequest(BaseModel):
    """Schema for token requests."""

    grant_type: str = "password"
    username: str | None = None
    email: EmailStr | None = None
    password: str | None = None
    refresh_token: str | None = None
    client_id: str | None = None
    client_secret: str | None = None

    model_config = ConfigDict(extra="forbid")


class RefreshTokenRequest(BaseModel):
    """Schema for refresh token requests."""

    refresh_token: str


class PasswordResetRequest(BaseModel):
    """Schema for password reset requests."""

    email: EmailStr


class PasswordResetConfirm(BaseModel):
    """Schema for password reset confirmation."""

    token: str
    new_password: str = Field(
        min_length=PASSWORD_MIN_LENGTH, max_length=PASSWORD_MAX_LENGTH
    )
    new_password_confirm: str = Field(
        min_length=PASSWORD_MIN_LENGTH, max_length=PASSWORD_MAX_LENGTH
    )

    @field_validator("new_password_confirm")
    def passwords_match(cls, v: str, info: ValidationInfo) -> str:
        if "new_password" in info.data and v != info.data["new_password"]:
            raise ValueError("Passwords do not match")
        return v


class EmailVerificationRequest(BaseModel):
    """Schema for email verification requests."""

    token: str


class InvitationCreate(BaseModel):
    """Schema for creating invitations."""

    email: EmailStr
    role_ids: list[UUID] | None = None
    expires_in_hours: int = 72
    metadata: dict[str, Any] = Field(default_factory=dict)


class TwoFactorRequest(BaseModel):
    """Schema for two-factor authentication."""

    method: str  # 'sms', 'email', 'totp', 'app'
    code: str | None = None
    phone_number: str | None = None  # Required for SMS method


class TwoFactorLoginRequest(BaseModel):
    """Schema for 2FA login verification."""

    user_id: UUID
    code: str


# Response schemas
class TokenResponse(BaseModel):
    """Schema for token responses."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"  # noqa: S105
    expires_in: int
    user_id: UUID


class UserResponse(BaseUser):
    """Schema for user responses."""

    id: UUID
    email_verified: bool
    phone_verified: bool
    status: str
    is_active: bool
    is_superuser: bool
    two_factor_enabled: bool
    last_login_at: datetime | None = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class UserWithRolesResponse(UserResponse):
    """Schema for user responses with roles."""

    roles: list["RoleResponse"] = Field(default_factory=list)


class RoleResponse(BaseModel):
    """Schema for role responses."""

    id: UUID
    name: str
    description: str | None = None
    is_default: bool
    is_system: bool
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class PermissionResponse(BaseModel):
    """Schema for permission responses."""

    id: UUID
    scope: str
    action: str
    resource: str | None = None
    description: str | None = None
    codename: str

    model_config = ConfigDict(from_attributes=True)


class SessionResponse(BaseModel):
    """Schema for session responses."""

    id: UUID
    user_agent: str | None = None
    ip_address: str | None = None
    device_info: dict[str, Any] | None = None
    created_at: datetime
    last_activity_at: datetime
    expires_at: datetime
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class OAuthAccountResponse(BaseModel):
    """Schema for OAuth account responses."""

    id: UUID
    provider: str
    provider_email: str | None = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Webhook schemas
class AuthWebhook(BaseModel):
    """Schema for authentication webhooks."""

    event: str  # 'user.created', 'user.updated', 'user.deleted', 'login', 'logout'
    data: dict[str, Any]
    timestamp: datetime = Field(default_factory=lambda: datetime.utcnow())
    webhook_id: str | None = None
