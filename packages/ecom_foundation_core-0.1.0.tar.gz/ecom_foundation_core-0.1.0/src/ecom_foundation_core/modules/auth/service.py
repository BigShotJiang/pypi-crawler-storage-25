"""
Authentication service layer.
"""

import logging
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID, uuid4

import pyotp
from sqlalchemy.ext.asyncio import AsyncSession

# from ..common. import audit_log, AuditAction
from ecom_foundation_core.modules.common import (
    AuditAction,
    audit_log,
)

from ..common.monitoring import metrics_collector, monitor_performance
from ..notifications.service import NotificationService
from .constants import (
    LOCKOUT_TIME,
    MAX_LOGIN_ATTEMPTS,
    TOKEN_TYPE_RESET,
    TOKEN_TYPE_VERIFICATION,
    USER_STATUS_ACTIVE,
    USER_STATUS_PENDING,
)
from .exceptions import (
    AccountLockedError,
    AuthError,
    InvalidCredentialsError,
    InvalidTokenError,
    UserAlreadyExistsError,
    UserNotFoundError,
)
from .repository import (
    BackupCodeRepository,
    SessionRepository,
    TokenRepository,
    UserRepository,
)
from .schemas import (
    EmailVerificationRequest,
    InvitationCreate,
    LoginRequest,
    PasswordResetConfirm,
    PasswordResetRequest,
    TokenResponse,
    TwoFactorRequest,
    UserCreate,
    UserUpdate,
)
from .security import (
    create_invitation_token,
    create_reset_token,
    create_tokens,
    create_verification_token,
    decode_token,
    generate_2fa_code,
    get_password_hash,
    validate_invitation_token,
    validate_reset_token,
    validate_verification_token,
    verify_2fa_code,
    verify_password,
)

logger = logging.getLogger(__name__)


class AuthService:
    """Authentication service."""

    def __init__(
        self,
        session: AsyncSession,
        notification_service: NotificationService,
        backup_code_repo: BackupCodeRepository,
    ) -> None:
        self.session = session
        self.notification_service = notification_service
        self.user_repo = UserRepository(session)
        self.session_repo = SessionRepository(session)
        self.token_repo = TokenRepository(session)
        self.backup_code_repo = backup_code_repo

    async def register(self, user_data: UserCreate) -> dict[str, Any]:
        """
        Register a new user.

        Args:
            user_data: User creation data

        Returns:
            Dictionary with user and tokens
        """
        # Check if user already exists
        existing_user = await self.user_repo.get_by_email(user_data.email)
        if existing_user:
            raise UserAlreadyExistsError(user_data.email)

        if user_data.username:
            existing_username = await self.user_repo.get_by_username(user_data.username)
            if existing_username:
                raise AuthError("Username already exists")

        # Hash password
        hashed_password = get_password_hash(user_data.password)

        # Create user
        user_dict = user_data.model_dump(exclude={"password", "password_confirm"})
        user_dict.update(
            {
                "password_hash": hashed_password,
                "status": USER_STATUS_PENDING,
                "is_active": True,
            }
        )

        # Create user
        try:
            user = await self.user_repo.create(user_dict)
        except Exception as e:
            # Check for unique constraint violations (IntegrityError)
            from sqlalchemy.exc import IntegrityError

            if isinstance(e, IntegrityError):
                # Attempt to determine which field failed
                error_msg = str(e.orig).lower()
                if "email" in error_msg:
                    raise UserAlreadyExistsError(user_data.email)
                if "username" in error_msg:
                    raise AuthError("Username already exists")
                if "phone_number" in error_msg:
                    raise AuthError("Phone number already exists")
            raise e

        # Create email verification token
        verification_token = create_verification_token(user.id)
        await self.token_repo.create(
            {
                "user_id": user.id,
                "token": verification_token,
                "token_type": TOKEN_TYPE_VERIFICATION,
                "expires_at": datetime.now(UTC) + timedelta(days=1),
            }
        )

        # Send verification email
        await self.notification_service.send_email(
            to_email=user.email,
            subject="Welcome! Please verify your email.",
            template_name="user_verification",
            context={
                "user_name": user.full_name,
                "verification_token": verification_token,
                # In a real app, you'd build a URL
                "verification_url": f"https://yourapp.com/verify-email?token={verification_token}",
            },
        )

        # Create tokens
        tokens = create_tokens(user.id)

        # Create session
        await self._create_session(user.id, tokens.refresh_token)

        return {
            "user": user,
            "tokens": tokens,
        }

    @audit_log(action=AuditAction.USER_LOGIN)
    @monitor_performance("login")
    async def login(
        self,
        login_data: LoginRequest,
        device_info: dict[str, Any] | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> dict[str, Any]:
        """
        Authenticate a user.

        Args:
            login_data: Login credentials
            device_info: Device information
            ip_address: Client IP address
            user_agent: User agent string

        Returns:
            Dictionary with user and tokens
        """
        # start_time = time.time()
        # Find user by email or username
        user = None
        if login_data.email:
            user = await self.user_repo.get_by_email(login_data.email)
        elif login_data.username:
            user = await self.user_repo.get_by_username(login_data.username)

        if not user:
            raise InvalidCredentialsError()

        # Check if account is locked
        if user.locked_until and user.locked_until > datetime.now(UTC):
            raise AccountLockedError(user.locked_until.isoformat())

        # Verify password
        if not verify_password(login_data.password, user.password_hash):
            # Increment failed attempts
            await self._handle_failed_login(user)
            raise InvalidCredentialsError()

        # Reset failed attempts on successful login
        if user.failed_login_attempts > 0:
            await self.user_repo.update(
                user.id,
                {
                    "failed_login_attempts": 0,
                    "locked_until": None,
                },
            )

        # Update last login
        await self.user_repo.update(
            user.id,
            {
                "last_login_at": datetime.now(UTC),
                "last_login_ip": ip_address,
            },
        )

        # Create tokens
        tokens = create_tokens(user.id)

        # Create session
        session = await self._create_session(
            user_id=user.id,
            refresh_token=tokens.refresh_token,
            device_info=device_info,
            ip_address=ip_address,
            user_agent=user_agent,
            remember_me=login_data.remember_me,
        )

        # Handle 2FA if enabled
        if user.two_factor_enabled:
            # If 2FA is enabled, we don't return tokens yet.
            # We first require the user to verify with their 2nd factor.
            if user.two_factor_method in ["sms", "email"]:
                code = generate_2fa_code()
                await self.user_repo.update(
                    user.id,
                    {
                        "metadata_": {
                            **user.metadata_,
                            "2fa_code": code,
                            "2fa_code_expires": (
                                datetime.now(UTC) + timedelta(minutes=10)
                            ).isoformat(),
                        }
                    },
                )
                if user.two_factor_method == "email":
                    await self.notification_service.send_email(
                        to_email=user.email,
                        subject="Your Login Verification Code",
                        template_name="2fa_login",
                        context={"code": code},
                    )
                elif user.two_factor_method == "sms" and user.phone_number:
                    await self.notification_service.send_sms(
                        to_phone=user.phone_number,
                        message=f"Your login verification code is: {code}",
                    )

            # For TOTP, we don't need to send anything.
            # The user will provide the code from their app.
            return {
                "user_id": user.id,  # Send user_id to be used in the /verify-2fa call
                "requires_2fa": True,
                "two_factor_method": user.two_factor_method,
            }

        metrics_collector.record_login("password", success=True)
        return {
            "user": user,
            "tokens": tokens,
            "session": session,
            "requires_2fa": False,
        }

    async def verify_2fa(
        self,
        user_id: UUID,
        two_factor_data: TwoFactorRequest,
    ) -> dict[str, Any]:
        """
        Verify two-factor authentication code.
        This is used both when enabling a new 2FA method and during login.
        """
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise UserNotFoundError()

        if not user.two_factor_method:
            raise AuthError("2FA is not set up for this user")

        is_valid = False
        if user.two_factor_method == "totp":
            if not user.two_factor_secret:
                raise AuthError("TOTP secret not found for user")
            totp = pyotp.TOTP(user.two_factor_secret)
            is_valid = totp.verify(two_factor_data.code)

        elif user.two_factor_method in ["sms", "email"]:
            stored_code = user.metadata_.get("2fa_code")
            expires_at_str = user.metadata_.get("2fa_code_expires")
            if not stored_code or not expires_at_str:
                raise AuthError("No 2FA code found for user.")

            expires_at = datetime.fromisoformat(expires_at_str)
            if datetime.now(UTC) > expires_at:
                raise AuthError("2FA code has expired.")

            is_valid = verify_2fa_code(stored_code, two_factor_data.code)

        if not is_valid:
            raise InvalidCredentialsError("Invalid 2FA code")

        # Clean up temporary code
        if user.two_factor_method in ["sms", "email"]:
            new_meta = user.metadata_.copy()
            new_meta.pop("2fa_code", None)
            new_meta.pop("2fa_code_expires", None)
            await self.user_repo.update(user.id, {"metadata_": new_meta})

        # If this was the first verification, mark 2FA as fully enabled
        if not user.two_factor_enabled:
            await self.user_repo.update(user.id, {"two_factor_enabled": True})

        # Create tokens after successful 2FA verification
        tokens = create_tokens(user.id)

        return {
            "user": user,
            "tokens": tokens,
        }

    async def refresh_token(self, refresh_token: str) -> TokenResponse:
        """
        Refresh access token using refresh token.

        Args:
            refresh_token: Refresh token

        Returns:
            New token response
        """
        # Validate refresh token
        try:
            payload = decode_token(refresh_token)
        except Exception:
            raise InvalidTokenError("refresh")

        if payload.get("type") != "refresh":
            raise InvalidTokenError("refresh")

        user_id = UUID(payload["sub"])

        # Check if session exists and is valid
        session = await self.session_repo.get_by_refresh_token(refresh_token)
        if not session or session.is_revoked or session.expires_at <= datetime.now(UTC):
            raise InvalidTokenError("refresh")

        # Update session last activity
        await self.session_repo.update_last_activity(session.id)

        # Create new tokens
        return create_tokens(user_id)

    async def logout(self, access_token: str, session_id: UUID | None = None) -> bool:
        """
        Logout user.

        Args:
            access_token: Access token
            session_id: Specific session to logout (optional)

        Returns:
            True if successful
        """
        try:
            payload = decode_token(access_token)
            user_id = UUID(payload["sub"])
        except Exception:
            return False

        if session_id:
            # Revoke specific session
            return await self.session_repo.revoke(session_id, reason="user_logout")
        else:
            # Revoke all sessions except current
            count = await self.session_repo.revoke_all_for_user(
                user_id,
                reason="user_logout",
            )
            return count > 0

    async def request_password_reset(
        self, reset_data: PasswordResetRequest
    ) -> dict[str, Any]:
        """
        Request password reset.

        Args:
            reset_data: Password reset request data

        Returns:
            Dictionary with reset token
        """
        user = await self.user_repo.get_by_email(reset_data.email)
        if not user:
            # Don't reveal that user doesn't exist
            return {"message": "If the email exists, a reset link has been sent"}

        # Create reset token
        reset_token = create_reset_token(user.id)

        # Store token in database
        await self.token_repo.create(
            {
                "user_id": user.id,
                "token": reset_token,
                "token_type": TOKEN_TYPE_RESET,
                "expires_at": datetime.now(UTC) + timedelta(hours=1),
            }
        )

        # Send reset email
        await self.notification_service.send_email(
            to_email=user.email,
            subject="Your Password Reset Request",
            template_name="password_reset",
            context={
                "user_name": user.full_name,
                "reset_token": reset_token,
                "reset_url": f"https://yourapp.com/reset-password?token={reset_token}",
            },
        )

        return {
            "message": "If the email exists, a reset link has been sent",
        }

    async def confirm_password_reset(self, reset_data: PasswordResetConfirm) -> bool:
        """
        Confirm password reset.

        Args:
            reset_data: Password reset confirmation data

        Returns:
            True if successful
        """
        # Validate token
        user_id = validate_reset_token(reset_data.token)
        if not user_id:
            raise InvalidTokenError("reset")

        # Check if token exists and is valid
        token = await self.token_repo.get_by_value(reset_data.token, TOKEN_TYPE_RESET)
        if not token or token.used_at or token.expires_at <= datetime.now(UTC):
            raise InvalidTokenError("reset")

        # Update password
        hashed_password = get_password_hash(reset_data.new_password)
        await self.user_repo.update(
            user_id,
            {
                "password_hash": hashed_password,
                "password_changed_at": datetime.now(UTC),
            },
        )

        # Mark token as used
        await self.token_repo.mark_as_used(token.id)

        # Revoke all sessions for security
        await self.session_repo.revoke_all_for_user(user_id, reason="password_reset")

        return True

    async def verify_email(self, verification_data: EmailVerificationRequest) -> bool:
        """
        Verify email address.

        Args:
            verification_data: Email verification request data

        Returns:
            True if successful
        """
        # Validate token
        user_id = validate_verification_token(verification_data.token)
        if not user_id:
            raise InvalidTokenError("verification")

        # Check if token exists and is valid
        token = await self.token_repo.get_by_value(
            verification_data.token, TOKEN_TYPE_VERIFICATION
        )
        if not token or token.used_at or token.expires_at <= datetime.now(UTC):
            raise InvalidTokenError("verification")

        # Update user
        await self.user_repo.update(
            user_id,
            {
                "email_verified": True,
                "status": USER_STATUS_ACTIVE,
            },
        )

        # Mark token as used
        await self.token_repo.mark_as_used(token.id)

        return True

    async def resend_verification(self, email: str) -> bool:
        """
        Resend email verification.

        Args:
            email: User email

        Returns:
            True if successful
        """
        user = await self.user_repo.get_by_email(email)
        if not user:
            # Don't reveal that user doesn't exist
            return True

        if user.email_verified:
            raise AuthError("Email is already verified")

        # Create new verification token
        verification_token = create_verification_token(user.id)

        # Store token in database
        await self.token_repo.create(
            {
                "user_id": user.id,
                "token": verification_token,
                "token_type": TOKEN_TYPE_VERIFICATION,
                "expires_at": datetime.now(UTC) + timedelta(days=1),
            }
        )

        # Send verification email again
        await self.notification_service.send_email(
            to_email=user.email,
            subject="Please verify your email.",
            template_name="user_verification",
            context={
                "user_name": user.full_name,
                "verification_token": verification_token,
                "verification_url": f"https://yourapp.com/verify-email?token={verification_token}",
            },
        )

        return True

    async def create_invitation(
        self, inviter_id: UUID, invitation_data: InvitationCreate
    ) -> dict[str, Any]:
        """
        Create an invitation.

        Args:
            inviter_id: ID of user creating the invitation
            invitation_data: Invitation data

        Returns:
            Dictionary with invitation token
        """
        # Check if user already exists
        existing_user = await self.user_repo.get_by_email(invitation_data.email)
        if existing_user:
            raise UserAlreadyExistsError(invitation_data.email)

        inviter = await self.user_repo.get_by_id(inviter_id)

        # Create invitation token
        invitation_token = create_invitation_token(
            email=invitation_data.email,
            inviter_id=inviter_id,
            role_ids=invitation_data.role_ids,
        )

        # Store token in database
        await self.token_repo.create(
            {
                "token": invitation_token,
                "token_type": "invitation",
                "expires_at": datetime.now(UTC)
                + timedelta(hours=invitation_data.expires_in_hours),
                "metadata": {
                    "email": invitation_data.email,
                    "inviter_id": str(inviter_id),
                    "role_ids": (
                        [str(rid) for rid in invitation_data.role_ids]
                        if invitation_data.role_ids
                        else []
                    ),
                    "metadata": invitation_data.metadata,
                },
            }
        )

        # Send invitation email
        await self.notification_service.send_email(
            to_email=invitation_data.email,
            subject=f"You have been invited to join by {inviter.full_name}",
            template_name="user_invitation",
            context={
                "inviter_name": inviter.full_name,
                "invitation_token": invitation_token,
                "invitation_url": f"https://yourapp.com/accept-invitation?token={invitation_token}",
                "expires_in_hours": invitation_data.expires_in_hours,
            },
        )

        return {
            "invitation_token": invitation_token,
            "expires_at": datetime.now(UTC)
            + timedelta(hours=invitation_data.expires_in_hours),
        }

    async def accept_invitation(
        self,
        invitation_token: str,
        user_data: UserCreate,
    ) -> dict[str, Any]:
        """
        Accept an invitation and create a user.

        Args:
            invitation_token: Invitation token
            user_data: User creation data

        Returns:
            Dictionary with user and tokens
        """
        # Validate invitation token
        invitation_data = validate_invitation_token(invitation_token)
        if not invitation_data:
            raise InvalidTokenError("invitation")

        # Check if email matches
        if user_data.email.lower() != invitation_data["email"].lower():
            raise AuthError("Email does not match invitation")

        # Check if token exists and is valid
        token = await self.token_repo.get_by_value(invitation_token, "invitation")
        if not token or token.used_at or token.expires_at <= datetime.now(UTC):
            raise InvalidTokenError("invitation")

        # Create user
        hashed_password = get_password_hash(user_data.password)

        user_dict = user_data.model_dump(exclude={"password", "password_confirm"})
        user_dict.update(
            {
                "password_hash": hashed_password,
                "status": USER_STATUS_ACTIVE,
                "email_verified": True,
                "is_active": True,
            }
        )

        user = await self.user_repo.create(user_dict)

        # Assign roles from invitation
        if invitation_data.get("role_ids"):
            for role_id in invitation_data["role_ids"]:
                await self.user_repo.add_role(user.id, role_id)

        # Mark token as used
        await self.token_repo.mark_as_used(token.id)

        # Create tokens
        tokens = create_tokens(user.id)

        # Create session
        await self._create_session(user.id, tokens.refresh_token)

        return {
            "user": user,
            "tokens": tokens,
        }

    async def get_current_user(self, access_token: str) -> dict[str, Any]:
        """
        Get current user from access token.

        Args:
            access_token: Access token

        Returns:
            Dictionary with user data
        """
        try:
            payload = decode_token(access_token)
            user_id = UUID(payload["sub"])
        except Exception:
            raise InvalidTokenError("access")

        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise UserNotFoundError()

        if not user.is_active:
            raise AuthError("User account is not active")

        # Get roles and permissions
        roles = await self.user_repo.get_roles(user_id)
        permissions = await self.user_repo.get_permissions(user_id)

        return {
            "user": user,
            "roles": roles,
            "permissions": permissions,
        }

    async def update_profile(
        self, user_id: UUID, update_data: UserUpdate
    ) -> dict[str, Any]:
        """
        Update user profile.

        Args:
            user_id: User ID
            update_data: Profile update data

        Returns:
            Updated user
        """
        # Check if username is taken
        if update_data.username:
            existing_user = await self.user_repo.get_by_username(update_data.username)
            if existing_user and existing_user.id != user_id:
                raise AuthError("Username already taken")

        # Update user
        user = await self.user_repo.update(
            user_id, update_data.model_dump(exclude_unset=True)
        )
        if not user:
            raise UserNotFoundError()

        return {"user": user}

    async def update_password(
        self, user_id: UUID, password_data: dict[str, Any]
    ) -> bool:
        """
        Update user password.

        Args:
            user_id: User ID
            password_data: Password update data

        Returns:
            True if successful
        """
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise UserNotFoundError()

        # Verify current password
        if not verify_password(password_data["current_password"], user.password_hash):
            raise InvalidCredentialsError()

        # Update password
        hashed_password = get_password_hash(password_data["new_password"])
        await self.user_repo.update(
            user_id,
            {
                "password_hash": hashed_password,
                "password_changed_at": datetime.now(UTC),
            },
        )

        # Revoke all sessions for security after a password change
        await self.session_repo.revoke_all_for_user(user_id, reason="password_reset")

        return True

    async def login_with_backup_code(self, user_id: UUID, code: str) -> dict[str, Any]:
        """
        Log in a user with a 2FA backup code.
        """
        user = await self.user_repo.get_by_id(user_id)
        if not user or not user.two_factor_enabled:
            raise AuthError("2FA is not enabled for this user")

        backup_codes = await self.backup_code_repo.get_user_codes(user.id)

        valid_code_found = None
        for backup_code in backup_codes:
            if backup_code.used_at is None and verify_password(
                code, backup_code.code_hash
            ):
                valid_code_found = backup_code
                break

        if not valid_code_found:
            raise InvalidCredentialsError("Invalid or used backup code")

        # Mark the code as used
        await self.backup_code_repo.mark_code_as_used(valid_code_found.id)

        # Create tokens and session
        tokens = create_tokens(user.id)
        session = await self._create_session(user.id, tokens.refresh_token)

        return {
            "user": user,
            "tokens": tokens,
            "session": session,
        }

    async def enable_2fa(self, user_id: UUID, method: str) -> dict[str, Any]:
        """
        Enable two-factor authentication.

        Args:
            user_id: User ID
            method: 2FA method ('sms', 'email', 'totp')

        Returns:
            Dictionary with 2FA data, e.g., TOTP provisioning URI
        """
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise UserNotFoundError()

        if method == "totp":
            # Generate a new secret for TOTP
            secret = pyotp.random_base32()

            # Generate and store hashed backup codes
            backup_codes_plain = [pyotp.random_base32(16) for _ in range(10)]
            hashed_backup_codes = [
                get_password_hash(code) for code in backup_codes_plain
            ]
            await self.backup_code_repo.create_codes(user.id, hashed_backup_codes)

            await self.user_repo.update(
                user.id,
                {
                    "two_factor_method": "totp",
                    "two_factor_secret": secret,
                    "two_factor_enabled": False,  # Enabled after first verification
                },
            )

            # Generate provisioning URI for QR code
            totp = pyotp.totp.TOTP(secret)
            provisioning_uri = totp.provisioning_uri(
                name=user.email,
                issuer_name="YourAppName",  # This should be configurable
            )

            return {
                "method": "totp",
                "provisioning_uri": provisioning_uri,
                # Return plain text codes only on setup
                "backup_codes": backup_codes_plain,
            }
        elif method in ["sms", "email"]:
            # Generate a numeric code
            code = generate_2fa_code()

            # Store the code temporarily
            await self.user_repo.update(
                user_id,
                {
                    "two_factor_method": method,
                    "two_factor_enabled": False,  # Enabled after first verification
                    "metadata_": {
                        **user.metadata_,
                        "2fa_code": code,
                        "2fa_code_expires": (
                            datetime.now(UTC) + timedelta(minutes=10)
                        ).isoformat(),
                    },
                },
            )

            if method == "email":
                await self.notification_service.send_email(
                    to_email=user.email,
                    subject="Your 2FA Verification Code",
                    template_name="2fa_verification",
                    context={"code": code},
                )
            elif method == "sms" and user.phone_number:
                await self.notification_service.send_sms(
                    to_phone=user.phone_number,
                    message=f"Your verification code is: {code}",
                )
            else:
                raise AuthError("Could not send 2FA code. No email or phone number.")

            return {"method": method, "message": "A verification code has been sent."}
        else:
            raise AuthError("Unsupported 2FA method")

    async def disable_2fa(self, user_id: UUID, code: str) -> bool:
        """
        Disable two-factor authentication.

        Args:
            user_id: User ID
            code: A valid 2FA code to authorize the action.

        Returns:
            True if successful
        """
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise UserNotFoundError()

        if not user.two_factor_enabled:
            raise AuthError("2FA is not enabled")

        is_valid = False
        if user.two_factor_method == "totp":
            if not user.two_factor_secret:
                raise AuthError("TOTP secret not found for user")
            totp = pyotp.TOTP(user.two_factor_secret)
            is_valid = totp.verify(code)
        else:
            # Disabling with email/sms code is less common.
            # A password re-authentication flow would be better here.
            # For now, we only support disabling via TOTP code.
            raise AuthError("Disabling 2FA is only supported via TOTP code.")

        if not is_valid:
            raise InvalidCredentialsError("Invalid 2FA code")

        # Update user
        await self.user_repo.update(
            user_id,
            {
                "two_factor_enabled": False,
                "two_factor_method": None,
                "two_factor_secret": None,
            },
        )

        return True

    async def get_sessions(self, user_id: UUID) -> list[dict[str, Any]]:
        """
        Get user's active sessions.

        Args:
            user_id: User ID

        Returns:
            List of sessions
        """
        sessions = await self.session_repo.list_active_sessions(user_id)
        return sessions

    async def revoke_session(self, user_id: UUID, session_id: UUID) -> bool:
        """
        Revoke a specific session.

        Args:
            user_id: User ID
            session_id: Session ID

        Returns:
            True if successful
        """
        session = await self.session_repo.get_by_id(session_id)
        if not session or session.user_id != user_id:
            return False

        return await self.session_repo.revoke(session_id, reason="user_revoked")

    # Private helper methods
    async def _create_session(
        self,
        user_id: UUID,
        refresh_token: str,
        device_info: dict[str, Any] | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
        remember_me: bool = False,
    ) -> dict[str, Any]:
        """Create a new session for the user."""
        # Calculate expiration
        expires_at = datetime.now(UTC) + timedelta(days=30 if remember_me else 7)

        # Create session
        session = await self.session_repo.create(
            {
                "user_id": user_id,
                "session_token": str(uuid4()),
                "refresh_token": refresh_token,
                "user_agent": user_agent,
                "ip_address": ip_address,
                "device_info": device_info or {},
                "expires_at": expires_at,
            }
        )

        # Clean up old sessions if user has too many
        sessions = await self.session_repo.list_active_sessions(user_id)
        if len(sessions) > 10:  # MAX_SESSIONS_PER_USER
            # Remove oldest sessions
            for old_session in sessions[10:]:
                await self.session_repo.revoke(
                    old_session.id, reason="too_many_sessions"
                )

        return session

    async def _handle_failed_login(self, user: Any) -> None:
        """Handle failed login attempt."""
        failed_attempts = user.failed_login_attempts + 1

        update_data = {
            "failed_login_attempts": failed_attempts,
        }

        # Lock account if too many failed attempts
        if failed_attempts >= MAX_LOGIN_ATTEMPTS:
            update_data["locked_until"] = datetime.now(UTC) + timedelta(
                seconds=LOCKOUT_TIME
            )

        await self.user_repo.update(user.id, update_data)
