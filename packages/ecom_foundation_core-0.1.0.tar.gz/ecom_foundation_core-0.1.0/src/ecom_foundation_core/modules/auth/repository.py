"""
Repository pattern for data access.
"""

import builtins
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import and_, delete, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .models import (
    BackupCode,
    OAuthAccount,
    Permission,
    Role,
    RolePermission,
    Session,
    Token,
    User,
    UserRole,
)


class BaseRepository:
    """Base repository with common operations."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session


class UserRepository(BaseRepository):
    """Repository for user operations."""

    async def get_by_id(self, user_id: UUID) -> User | None:
        """Get user by ID."""
        result = await self.session.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()

    async def get_by_email(self, email: str) -> User | None:
        """Get user by email."""
        result = await self.session.execute(
            select(User).where(User.email == email.lower())
        )
        return result.scalar_one_or_none()

    async def get_by_username(self, username: str) -> User | None:
        """Get user by username."""
        result = await self.session.execute(
            select(User).where(User.username == username)
        )
        return result.scalar_one_or_none()

    async def get_by_phone(self, phone_number: str) -> User | None:
        """Get user by phone number."""
        result = await self.session.execute(
            select(User).where(User.phone_number == phone_number)
        )
        return result.scalar_one_or_none()

    async def get_by_oauth(self, provider: str, provider_user_id: str) -> User | None:
        """Get user by OAuth provider and ID."""
        result = await self.session.execute(
            select(User)
            .join(OAuthAccount)
            .where(
                and_(
                    OAuthAccount.provider == provider,
                    OAuthAccount.provider_user_id == provider_user_id,
                )
            )
        )
        return result.scalar_one_or_none()

    async def create(self, user_data: dict[str, Any]) -> User:
        """Create a new user."""
        user = User(**user_data)
        self.session.add(user)
        await self.session.flush()
        return user

    async def update(self, user_id: UUID, update_data: dict[str, Any]) -> User | None:
        """Update user data."""
        result = await self.session.execute(
            update(User).where(User.id == user_id).values(**update_data).returning(User)
        )
        await self.session.flush()
        return result.scalar_one_or_none()

    async def delete(self, user_id: UUID) -> bool:
        """Delete a user."""
        result = await self.session.execute(delete(User).where(User.id == user_id))
        await self.session.flush()
        return result.rowcount > 0

    async def list(
        self,
        skip: int = 0,
        limit: int = 100,
        filters: dict[str, Any] | None = None,
    ) -> list[User]:
        """List users with pagination and filtering."""
        query = select(User)

        if filters:
            conditions = []
            if filters.get("email"):
                conditions.append(User.email.ilike(f"%{filters['email']}%"))
            if filters.get("username"):
                conditions.append(User.username.ilike(f"%{filters['username']}%"))
            if filters.get("status"):
                conditions.append(User.status == filters["status"])
            if filters.get("is_active") is not None:
                conditions.append(User.is_active == filters["is_active"])
            if conditions:
                query = query.where(and_(*conditions))

        query = query.offset(skip).limit(limit).order_by(User.created_at.desc())

        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def count(self, filters: dict[str, Any] | None = None) -> int:
        """Count users."""
        query = select(User)

        if filters:
            conditions = []
            if filters.get("status"):
                conditions.append(User.status == filters["status"])
            if filters.get("is_active") is not None:
                conditions.append(User.is_active == filters["is_active"])
            if conditions:
                query = query.where(and_(*conditions))

        from sqlalchemy import func

        result = await self.session.execute(
            select(func.count()).select_from(query.subquery())
        )
        return result.scalar_one()

    async def add_role(self, user_id: UUID, role_id: UUID) -> bool:
        """Add role to user."""
        user_role = UserRole(user_id=user_id, role_id=role_id)
        self.session.add(user_role)
        try:
            await self.session.flush()
            return True
        except Exception:
            await self.session.rollback()
            return False

    async def remove_role(self, user_id: UUID, role_id: UUID) -> bool:
        """Remove role from user."""
        result = await self.session.execute(
            delete(UserRole).where(
                and_(
                    UserRole.user_id == user_id,
                    UserRole.role_id == role_id,
                )
            )
        )
        await self.session.flush()
        return result.rowcount > 0

    async def get_roles(self, user_id: UUID) -> builtins.list[Role]:
        """Get user's roles."""
        result = await self.session.execute(
            select(Role).join(UserRole).where(UserRole.user_id == user_id)
        )
        return list(result.scalars().all())

    async def get_permissions(self, user_id: UUID) -> builtins.list[Permission]:
        """Get user's permissions (through roles)."""
        result = await self.session.execute(
            select(Permission)
            .join(RolePermission)
            .join(Role)
            .join(UserRole)
            .where(UserRole.user_id == user_id)
            .distinct()
        )
        return list(result.scalars().all())


class SessionRepository(BaseRepository):
    """Repository for session operations."""

    async def create(self, session_data: dict[str, Any]) -> Session:
        """Create a new session."""
        session = Session(**session_data)
        self.session.add(session)
        await self.session.flush()
        return session

    async def get_by_token(self, token: str) -> Session | None:
        """Get session by token."""
        result = await self.session.execute(
            select(Session).where(Session.session_token == token)
        )
        return result.scalar_one_or_none()

    async def get_by_refresh_token(self, refresh_token: str) -> Session | None:
        """Get session by refresh token."""
        result = await self.session.execute(
            select(Session).where(Session.refresh_token == refresh_token)
        )
        return result.scalar_one_or_none()

    async def revoke(self, session_id: UUID, reason: str | None = None) -> bool:
        """Revoke a session."""
        result = await self.session.execute(
            update(Session)
            .where(Session.id == session_id)
            .values(
                is_revoked=True,
                revoked_at=datetime.now(UTC),
                revoked_reason=reason,
            )
        )
        await self.session.flush()
        return result.rowcount > 0

    async def revoke_all_for_user(
        self,
        user_id: UUID,
        exclude_session_id: UUID | None = None,
        reason: str | None = None,
    ) -> int:
        """Revoke all sessions for a user."""
        query = update(Session).where(
            and_(
                Session.user_id == user_id,
                ~Session.is_revoked,
            )
        )

        if exclude_session_id:
            query = query.where(Session.id != exclude_session_id)

        result = await self.session.execute(
            query.values(
                is_revoked=True,
                revoked_at=datetime.now(UTC),
                revoked_reason=reason,
            )
        )
        await self.session.flush()
        return result.rowcount

    async def update_last_activity(self, session_id: UUID) -> bool:
        """Update session's last activity timestamp."""
        result = await self.session.execute(
            update(Session)
            .where(Session.id == session_id)
            .values(last_activity_at=datetime.now(UTC))
        )
        await self.session.flush()
        return result.rowcount > 0

    async def list_active_sessions(self, user_id: UUID) -> list[Session]:
        """List active sessions for a user."""
        result = await self.session.execute(
            select(Session)
            .where(
                and_(
                    Session.user_id == user_id,
                    ~Session.is_revoked,
                    Session.expires_at > datetime.now(UTC),
                )
            )
            .order_by(Session.created_at.desc())
        )
        return list(result.scalars().all())


class TokenRepository(BaseRepository):
    """Repository for token operations."""

    async def create(self, token_data: dict[str, Any]) -> Token:
        """Create a new token."""
        token = Token(**token_data)
        self.session.add(token)
        await self.session.flush()
        return token

    async def get_by_value(
        self, token: str, token_type: str | None = None
    ) -> Token | None:
        """Get token by value."""
        query = select(Token).where(Token.token == token)

        if token_type:
            query = query.where(Token.token_type == token_type)

        result = await self.session.execute(query)
        return result.scalar_one_or_none()

    async def mark_as_used(self, token_id: UUID) -> bool:
        """Mark token as used."""
        result = await self.session.execute(
            update(Token).where(Token.id == token_id).values(used_at=datetime.now(UTC))
        )
        await self.session.flush()
        return result.rowcount > 0

    async def revoke_all_for_user(
        self,
        user_id: UUID,
        token_type: str | None = None,
    ) -> int:
        """Revoke all tokens for a user."""
        query = delete(Token).where(
            and_(
                Token.user_id == user_id,
                Token.used_at.is_(None),
                Token.expires_at > datetime.now(UTC),
            )
        )

        if token_type:
            query = query.where(Token.token_type == token_type)

        result = await self.session.execute(query)
        await self.session.flush()
        return result.rowcount

    async def cleanup_expired(self) -> int:
        """Clean up expired tokens."""
        result = await self.session.execute(
            delete(Token).where(Token.expires_at <= datetime.now(UTC))
        )
        await self.session.flush()
        return result.rowcount


class BackupCodeRepository(BaseRepository):
    """Repository for 2FA backup code operations."""

    async def create_codes(
        self, user_id: UUID, hashed_codes: list[str]
    ) -> list[BackupCode]:
        """Create and store new backup codes for a user."""
        # First, delete any existing backup codes for this user
        await self.session.execute(
            delete(BackupCode).where(BackupCode.user_id == user_id)
        )

        codes = [
            BackupCode(user_id=user_id, code_hash=hashed_code)
            for hashed_code in hashed_codes
        ]
        self.session.add_all(codes)
        await self.session.flush()
        return codes

    async def get_user_codes(self, user_id: UUID) -> list[BackupCode]:
        """Retrieve all backup codes for a user."""
        result = await self.session.execute(
            select(BackupCode).where(BackupCode.user_id == user_id)
        )
        return list(result.scalars().all())

    async def find_code(self, user_id: UUID, code_hash: str) -> BackupCode | None:
        """Find a specific, unused backup code by its hash."""
        result = await self.session.execute(
            select(BackupCode).where(
                and_(
                    BackupCode.user_id == user_id,
                    BackupCode.code_hash == code_hash,
                    BackupCode.used_at.is_(None),
                )
            )
        )
        return result.scalar_one_or_none()

    async def mark_code_as_used(self, code_id: UUID) -> BackupCode | None:
        """Mark a backup code as used by setting the used_at timestamp."""
        result = await self.session.execute(
            update(BackupCode)
            .where(BackupCode.id == code_id)
            .values(used_at=datetime.now(UTC))
            .returning(BackupCode)
        )
        await self.session.flush()
        return result.scalar_one_or_none()
