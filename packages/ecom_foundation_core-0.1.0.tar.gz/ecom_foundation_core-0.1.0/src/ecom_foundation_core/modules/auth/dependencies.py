"""
FastAPI dependencies for authentication.
"""

from collections.abc import Callable

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from ..common.database import get_async_session
from ..notifications.dependencies import get_notification_service
from ..notifications.service import NotificationService
from .exceptions import raise_http_exception
from .repository import BackupCodeRepository
from .service import AuthService

# Security schemes
http_bearer = HTTPBearer(auto_error=False)


async def get_auth_service(
    session: AsyncSession = Depends(get_async_session),
    notification_service: NotificationService = Depends(get_notification_service),
) -> AuthService:
    """Get authentication service."""
    return AuthService(
        session=session,
        notification_service=notification_service,
        backup_code_repo=BackupCodeRepository(session),
    )


async def get_current_user(
    auth_service: AuthService = Depends(get_auth_service),
    credentials: HTTPAuthorizationCredentials | None = Depends(http_bearer),
) -> dict:
    """Get current authenticated user."""
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        user_data = await auth_service.get_current_user(credentials.credentials)
        return user_data
    except Exception as e:
        raise_http_exception(e)


async def get_current_active_user(
    current_user: dict = Depends(get_current_user),
) -> dict:
    """Get current active user."""
    if not current_user["user"].is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user",
        )
    return current_user


async def get_current_superuser(
    current_user: dict = Depends(get_current_active_user),
) -> dict:
    """Get current superuser."""
    if not current_user["user"].is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions",
        )
    return current_user


def has_permission(permission_codename: str) -> Callable[[dict], dict]:
    """
    Dependency to check if user has specific permission.

    Args:
        permission_codename: Permission codename to check

    Returns:
        Dependency function
    """

    async def permission_checker(
        current_user: dict = Depends(get_current_active_user),
    ) -> dict:
        """Check if user has required permission."""
        user_permissions = current_user.get("permissions", [])

        # Check if user has permission
        has_perm = any(
            perm.codename == permission_codename for perm in user_permissions
        )

        # Superusers have all permissions
        if not has_perm and not current_user["user"].is_superuser:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Missing permission: {permission_codename}",
            )

        return current_user

    return permission_checker


def has_role(role_name: str) -> Callable[[dict], dict]:
    """
    Dependency to check if user has specific role.

    Args:
        role_name: Role name to check

    Returns:
        Dependency function
    """

    async def role_checker(
        current_user: dict = Depends(get_current_active_user),
    ) -> dict:
        """Check if user has required role."""
        user_roles = current_user.get("roles", [])

        # Check if user has role
        has_role_perm = any(role.name == role_name for role in user_roles)

        # Superusers have all roles
        if not has_role_perm and not current_user["user"].is_superuser:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Missing role: {role_name}",
            )

        return current_user

    return role_checker
