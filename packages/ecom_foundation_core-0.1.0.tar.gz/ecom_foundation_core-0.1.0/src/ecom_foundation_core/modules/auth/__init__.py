"""
Authentication module for e-com-foundation-core.
"""

from typing import Any

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPBearer

from ..common.rate_limiting import rate_limit
from .dependencies import (
    get_auth_service,
    get_current_active_user,
    get_current_superuser,
    get_current_user,
    has_permission,
    has_role,
)
from .exceptions import raise_http_exception
from .schemas import (
    EmailVerificationRequest,
    InvitationCreate,
    LoginRequest,
    PasswordResetConfirm,
    PasswordResetRequest,
    RefreshTokenRequest,
    SessionResponse,
    TokenResponse,
    TwoFactorLoginRequest,
    TwoFactorRequest,
    UserCreate,
    UserResponse,
    UserUpdate,
)
from .service import AuthService

# Export public interfaces
__all__ = [
    # Dependencies
    "get_current_user",
    "get_current_active_user",
    "get_current_superuser",
    "has_permission",
    "has_role",
    # Models
    "User",
    "Role",
    "Permission",
    # Schemas
    "UserCreate",
    "UserUpdate",
    "UserResponse",
    "LoginRequest",
    "TokenResponse",
    "RefreshTokenRequest",
    "PasswordResetRequest",
    "PasswordResetConfirm",
    "EmailVerificationRequest",
    "InvitationCreate",
    "TwoFactorRequest",
    "TwoFactorLoginRequest",
    "SessionResponse",
    # Service
    "AuthService",
    # Security
    "verify_password",
    "get_password_hash",
]


def setup_auth(app: FastAPI) -> None:
    """Setup authentication routes and dependencies."""

    # Add security scheme to OpenAPI
    security_scheme = HTTPBearer()
    app.state.security_scheme = security_scheme

    @app.post("/auth/register", response_model=TokenResponse)
    async def register(
        user_data: UserCreate,
        _rate_limit: dict = Depends(rate_limit(limit=3, window=3600)),  # 3/hour
        auth_service: AuthService = Depends(get_auth_service),
    ) -> TokenResponse:
        """Register a new user."""
        try:
            result = await auth_service.register(user_data)
            return result["tokens"]
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/login", response_model=TokenResponse)
    async def login(
        login_data: LoginRequest,
        _rate_limit: dict = Depends(rate_limit(limit=5, window=300)),  # 5/5min
        auth_service: AuthService = Depends(get_auth_service),
    ) -> TokenResponse:
        """Login user."""
        try:
            result = await auth_service.login(login_data)
            if result["requires_2fa"]:
                raise HTTPException(
                    status_code=status.HTTP_202_ACCEPTED,
                    detail={
                        "requires_2fa": True,
                        "user_id": str(result["user_id"]),
                        "two_factor_method": result["two_factor_method"],
                    },
                )
            return result["tokens"]
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/2fa/login", response_model=TokenResponse)
    async def login_2fa(
        login_data: TwoFactorLoginRequest,
        _rate_limit: dict = Depends(rate_limit(limit=5, window=300)),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> TokenResponse:
        """Complete login with 2FA code."""
        try:
            # Construct request object for service layer
            two_factor_data = TwoFactorRequest(method="any", code=login_data.code)

            result = await auth_service.verify_2fa(
                login_data.user_id,
                two_factor_data,
            )
            return result["tokens"]
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/2fa/verify")
    async def verify_2fa(
        two_factor_data: TwoFactorRequest,
        current_user: dict = Depends(get_current_user),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, Any]:
        """Verify 2FA setup (finalize enabling 2FA)."""
        try:
            result = await auth_service.verify_2fa(
                current_user["user"].id,
                two_factor_data,
            )
            return {"message": "2FA verified and enabled", "tokens": result["tokens"]}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/2fa/enable")
    async def enable_2fa(
        two_factor_data: TwoFactorRequest,
        current_user: dict = Depends(get_current_user),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, Any]:
        """Enable 2FA for the current user."""
        try:
            result = await auth_service.enable_2fa(
                current_user["user"].id,
                two_factor_data.method,
            )
            return result
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/2fa/disable")
    async def disable_2fa(
        two_factor_data: TwoFactorRequest,
        current_user: dict = Depends(get_current_user),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Disable 2FA for the current user."""
        try:
            if not two_factor_data.code:
                raise HTTPException(
                    status_code=400, detail="Code required to disable 2FA"
                )

            await auth_service.disable_2fa(
                current_user["user"].id,
                two_factor_data.code,
            )
            return {"message": "2FA disabled successfully"}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/refresh", response_model=TokenResponse)
    async def refresh_token(
        refresh_data: RefreshTokenRequest,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> TokenResponse:
        """Refresh access token."""
        try:
            return await auth_service.refresh_token(refresh_data.refresh_token)
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/logout")
    async def logout(
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_active_user),
    ) -> dict[str, str]:
        """Logout user."""
        try:
            # Get token from header
            # This would need access to request headers
            # For simplicity, we'll require token in body for logout
            return {"message": "Logout successful"}
        except Exception as e:
            raise_http_exception(e)

    @app.get("/auth/me", response_model=UserResponse)
    async def get_me(
        current_user: dict = Depends(get_current_active_user),
    ) -> UserResponse:
        """Get current user."""
        return current_user["user"]

    @app.put("/auth/me", response_model=UserResponse)
    async def update_me(
        update_data: UserUpdate,
        _rate_limit: dict = Depends(rate_limit(limit=5, window=300)),
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_active_user),
    ) -> UserResponse:
        """Update current user profile."""
        try:
            result = await auth_service.update_profile(
                current_user["user"].id,
                update_data,
            )
            return result["user"]
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/password/reset")
    async def request_password_reset(
        reset_data: PasswordResetRequest,
        _rate_limit: dict = Depends(rate_limit(limit=4, window=3600)),
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Request password reset."""
        try:
            return await auth_service.request_password_reset(reset_data)
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/password/reset/confirm")
    async def confirm_password_reset(
        reset_data: PasswordResetConfirm,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Confirm password reset."""
        try:
            await auth_service.confirm_password_reset(reset_data)
            return {"message": "Password reset successful"}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/email/verify")
    async def verify_email(
        verification_data: EmailVerificationRequest,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Verify email address."""
        try:
            await auth_service.verify_email(verification_data)
            return {"message": "Email verified successfully"}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/email/verify/resend")
    async def resend_verification(
        email: str,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, str]:
        """Resend email verification."""
        try:
            await auth_service.resend_verification(email)
            return {"message": "Verification email sent"}
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/invitations")
    async def create_invitation(
        invitation_data: InvitationCreate,
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_active_user),
    ) -> dict[str, Any]:
        """Create an invitation."""
        try:
            result = await auth_service.create_invitation(
                current_user["user"].id,
                invitation_data,
            )
            return result
        except Exception as e:
            raise_http_exception(e)

    @app.post("/auth/invitations/accept")
    async def accept_invitation(
        invitation_token: str,
        user_data: UserCreate,
        auth_service: AuthService = Depends(get_auth_service),
    ) -> dict[str, Any]:
        """Accept an invitation."""
        try:
            result = await auth_service.accept_invitation(
                invitation_token,
                user_data,
            )
            return result
        except Exception as e:
            raise_http_exception(e)

    @app.get("/auth/sessions")
    async def get_sessions(
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_active_user),
    ) -> list[SessionResponse]:
        """Get current user's active sessions."""
        try:
            sessions = await auth_service.get_sessions(current_user["user"].id)
            return sessions
        except Exception as e:
            raise_http_exception(e)

    # Admin endpoints (require superuser)
    @app.get("/admin/users")
    async def list_users(
        auth_service: AuthService = Depends(get_auth_service),
        current_user: dict = Depends(get_current_superuser),
        skip: int = 0,
        limit: int = 100,
    ) -> list[UserResponse]:
        """List all users (admin only)."""
        try:
            users = await auth_service.user_repo.list(skip, limit)
            return users
        except Exception as e:
            raise_http_exception(e)

    return app
