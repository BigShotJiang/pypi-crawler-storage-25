"""
Module-level configuration exports.

Some modules under `ecom_foundation_core.modules.*` import `..config`.
Provide a stable re-export here.
"""

from ..config import Settings, get_settings

__all__ = ["Settings", "get_settings"]
