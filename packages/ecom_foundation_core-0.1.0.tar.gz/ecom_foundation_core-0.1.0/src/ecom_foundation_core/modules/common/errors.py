"""
Common error classes and error handling.
"""

import traceback
from typing import Any

import structlog
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse

logger = structlog.get_logger(__name__)


class AppError(Exception):
    """Base application error."""

    def __init__(
        self,
        message: str = "Application error",
        code: str = "app_error",
        status_code: int = 500,
        details: dict[str, Any] | None = None,
    ) -> None:
        self.message = message
        self.code = code
        self.status_code = status_code
        self.details = details or {}
        super().__init__(message)


class ValidationError(AppError):
    """Validation error."""

    def __init__(
        self,
        message: str = "Validation error",
        field: str | None = None,
        value: Any | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        details = details or {}
        if field:
            details["field"] = field
        if value is not None:
            details["value"] = value

        super().__init__(
            message=message,
            code="validation_error",
            status_code=400,
            details=details,
        )


class NotFoundError(AppError):
    """Resource not found error."""

    def __init__(
        self,
        resource: str = "resource",
        identifier: str | None = None,
        message: str | None = None,
    ) -> None:
        if not message:
            message = f"{resource} not found"
            if identifier:
                message = f"{resource} with ID {identifier} not found"

        details = {"resource": resource}
        if identifier:
            details["identifier"] = identifier

        super().__init__(
            message=message,
            code="not_found",
            status_code=404,
            details=details,
        )


class UnauthorizedError(AppError):
    """Authentication/authorization error."""

    def __init__(
        self,
        message: str = "Authentication required",
        scheme: str = "Bearer",
    ) -> None:
        super().__init__(
            message=message,
            code="unauthorized",
            status_code=401,
            details={"scheme": scheme},
        )


class ForbiddenError(AppError):
    """Permission denied error."""

    def __init__(
        self,
        message: str = "Permission denied",
        permission: str | None = None,
        resource: str | None = None,
    ) -> None:
        details = {}
        if permission:
            details["permission"] = permission
        if resource:
            details["resource"] = resource

        super().__init__(
            message=message,
            code="forbidden",
            status_code=403,
            details=details,
        )


class ConflictError(AppError):
    """Resource conflict error."""

    def __init__(
        self,
        message: str = "Resource conflict",
        resource: str | None = None,
        field: str | None = None,
        value: Any | None = None,
    ) -> None:
        details = {}
        if resource:
            details["resource"] = resource
        if field:
            details["field"] = field
        if value is not None:
            details["value"] = value

        super().__init__(
            message=message,
            code="conflict",
            status_code=409,
            details=details,
        )


class RateLimitError(AppError):
    """Rate limit exceeded error."""

    def __init__(
        self,
        limit: int,
        window: int,
        retry_after: int,
        message: str | None = None,
    ) -> None:
        if not message:
            message = f"Rate limit exceeded: {limit} requests per {window} seconds"

        super().__init__(
            message=message,
            code="rate_limit_exceeded",
            status_code=429,
            details={
                "limit": limit,
                "window": window,
                "retry_after": retry_after,
            },
        )


class ServiceUnavailableError(AppError):
    """Service unavailable error."""

    def __init__(
        self,
        service: str,
        message: str | None = None,
        retry_after: int | None = None,
    ) -> None:
        if not message:
            message = f"Service {service} is temporarily unavailable"

        details = {"service": service}
        if retry_after:
            details["retry_after"] = retry_after

        super().__init__(
            message=message,
            code="service_unavailable",
            status_code=503,
            details=details,
        )


# Error handler
async def error_handler(request: Request, exc: Exception) -> JSONResponse:
    """
    Global error handler for FastAPI.

    Args:
        request: FastAPI request
        exc: Exception

    Returns:
        JSON response with error details
    """
    # Get request ID
    from .middleware import get_request_id

    request_id = get_request_id()
    error_data: dict[str, Any]

    # Handle AppError
    if isinstance(exc, AppError):
        error_data = {
            "error": exc.code,
            "message": exc.message,
            "request_id": request_id,
            "details": exc.details,
        }

        logger.warning(
            "app_error",
            request_id=request_id,
            error_code=exc.code,
            message=exc.message,
            status_code=exc.status_code,
            details=exc.details,
        )

        return JSONResponse(
            status_code=exc.status_code,
            content=error_data,
        )

    # Handle HTTPException
    elif isinstance(exc, HTTPException):
        error_data = {
            "error": "http_error",
            "message": exc.detail,
            "request_id": request_id,
            "status_code": exc.status_code,
        }

        logger.warning(
            "http_error",
            request_id=request_id,
            status_code=exc.status_code,
            detail=exc.detail,
        )

        return JSONResponse(
            status_code=exc.status_code,
            content=error_data,
        )

    # Handle all other exceptions
    else:
        error_data = {
            "error": "internal_error",
            "message": "Internal server error",
            "request_id": request_id,
        }

        # Add debug info in development
        from .config import is_development

        if is_development():
            error_data["debug"] = {
                "type": type(exc).__name__,
                "message": str(exc),
                "traceback": traceback.format_exc(),
            }

        logger.error(
            "unhandled_exception",
            request_id=request_id,
            error_type=type(exc).__name__,
            error_message=str(exc),
            traceback=traceback.format_exc(),
            exc_info=True,
        )

        return JSONResponse(
            status_code=500,
            content=error_data,
        )


# FastAPI exception handlers setup
def handle_exceptions(app: FastAPI) -> None:
    """
    Setup exception handlers for FastAPI app.

    Args:
        app: FastAPI application
    """
    app.add_exception_handler(AppError, error_handler)
    app.add_exception_handler(HTTPException, error_handler)
    app.add_exception_handler(Exception, error_handler)
