"""
Common configuration utilities.
"""

import logging
import secrets
from typing import Any

from pydantic import Field, HttpUrl, RedisDsn, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)


class CommonConfig(BaseSettings):
    """Common configuration for all modules."""

    model_config = SettingsConfigDict(
        case_sensitive=True,
        env_ignore_empty=True,
    )

    def __getattr__(self, item: str) -> Any:
        """
        Backwards-compatible attribute access.

        A lot of the codebase expects snake_case settings (e.g. `settings.debug`)
        while this settings model uses UPPER_SNAKE_CASE fields (e.g. `DEBUG`).
        """
        upper = item.upper()
        if upper in getattr(self, "model_fields", {}):
            return getattr(self, upper)
        raise AttributeError(f"{type(self).__name__!s} has no attribute {item!r}")

    # Environment
    ENVIRONMENT: str = Field(default="development", validation_alias="ENVIRONMENT")
    DEBUG: bool = Field(default=False, validation_alias="DEBUG")
    LOG_LEVEL: str = Field(default="INFO", validation_alias="LOG_LEVEL")

    # Security
    SECRET_KEY: str = Field(
        default_factory=lambda: secrets.token_urlsafe(32), validation_alias="SECRET_KEY"
    )
    ALGORITHM: str = Field(default="HS256", validation_alias="ALGORITHM")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(
        default=30, validation_alias="ACCESS_TOKEN_EXPIRE_MINUTES"
    )
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(
        default=7, validation_alias="REFRESH_TOKEN_EXPIRE_DAYS"
    )

    # Database
    # Allow non-Postgres URLs in tests (e.g. sqlite+aiosqlite:///:memory:)
    DATABASE_URL: str | None = Field(None, validation_alias="DATABASE_URL")
    DATABASE_POOL_SIZE: int = Field(default=20, validation_alias="DATABASE_POOL_SIZE")
    DATABASE_MAX_OVERFLOW: int = Field(
        default=10, validation_alias="DATABASE_MAX_OVERFLOW"
    )
    DATABASE_ECHO: bool = Field(default=False, validation_alias="DATABASE_ECHO")

    # Redis
    REDIS_URL: RedisDsn | None = Field(None, validation_alias="REDIS_URL")
    REDIS_POOL_SIZE: int = Field(default=10, validation_alias="REDIS_POOL_SIZE")
    REDIS_DEFAULT_TTL: int = Field(
        default=3600, validation_alias="REDIS_DEFAULT_TTL"
    )  # 1 hour

    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = Field(
        default=True, validation_alias="RATE_LIMIT_ENABLED"
    )
    RATE_LIMIT_DEFAULT_LIMIT: int = Field(
        default=100, validation_alias="RATE_LIMIT_DEFAULT_LIMIT"
    )
    RATE_LIMIT_DEFAULT_WINDOW: int = Field(
        default=60, validation_alias="RATE_LIMIT_DEFAULT_WINDOW"
    )  # seconds
    RATE_LIMIT_STRATEGY: str = Field(
        default="sliding_window", validation_alias="RATE_LIMIT_STRATEGY"
    )

    # Audit Logging
    AUDIT_LOG_ENABLED: bool = Field(default=True, validation_alias="AUDIT_LOG_ENABLED")
    AUDIT_LOG_RETENTION_DAYS: int = Field(
        default=90, validation_alias="AUDIT_LOG_RETENTION_DAYS"
    )
    AUDIT_LOG_BATCH_SIZE: int = Field(
        default=100, validation_alias="AUDIT_LOG_BATCH_SIZE"
    )
    AUDIT_LOG_BATCH_INTERVAL: int = Field(
        default=5, validation_alias="AUDIT_LOG_BATCH_INTERVAL"
    )  # seconds

    # Monitoring
    METRICS_ENABLED: bool = Field(default=True, validation_alias="METRICS_ENABLED")
    HEALTH_CHECK_ENABLED: bool = Field(
        default=True, validation_alias="HEALTH_CHECK_ENABLED"
    )
    PROMETHEUS_PORT: int = Field(default=9090, validation_alias="PROMETHEUS_PORT")

    # CORS
    CORS_ORIGINS: list[str] = Field(default=["*"], validation_alias="CORS_ORIGINS")
    CORS_ALLOW_CREDENTIALS: bool = Field(
        default=True, validation_alias="CORS_ALLOW_CREDENTIALS"
    )
    CORS_ALLOW_METHODS: list[str] = Field(
        default=["*"], validation_alias="CORS_ALLOW_METHODS"
    )
    CORS_ALLOW_HEADERS: list[str] = Field(
        default=["*"], validation_alias="CORS_ALLOW_HEADERS"
    )

    # Security Headers
    SECURITY_HEADERS_ENABLED: bool = Field(
        default=True, validation_alias="SECURITY_HEADERS_ENABLED"
    )
    CONTENT_SECURITY_POLICY: str = Field(
        default=(
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; "
            "font-src 'self' data:;"
        ),
        validation_alias="CONTENT_SECURITY_POLICY",
    )
    HSTS_MAX_AGE: int = Field(
        default=31536000, validation_alias="HSTS_MAX_AGE"
    )  # 1 year
    HSTS_PRELOAD: bool = Field(default=False, validation_alias="HSTS_PRELOAD")
    HSTS_INCLUDE_SUBDOMAINS: bool = Field(
        default=False, validation_alias="HSTS_INCLUDE_SUBDOMAINS"
    )

    # Compression
    COMPRESSION_ENABLED: bool = Field(
        default=True, validation_alias="COMPRESSION_ENABLED"
    )
    COMPRESSION_MIN_SIZE: int = Field(
        default=500, validation_alias="COMPRESSION_MIN_SIZE"
    )  # bytes
    COMPRESSION_LEVEL: int = Field(
        default=6, validation_alias="COMPRESSION_LEVEL"
    )  # 0-9

    # Timeouts
    REQUEST_TIMEOUT: int = Field(
        default=30, validation_alias="REQUEST_TIMEOUT"
    )  # seconds
    DATABASE_TIMEOUT: int = Field(
        default=10, validation_alias="DATABASE_TIMEOUT"
    )  # seconds
    REDIS_TIMEOUT: int = Field(default=5, validation_alias="REDIS_TIMEOUT")  # seconds

    # External Services
    SENTRY_DSN: HttpUrl | None = Field(None, validation_alias="SENTRY_DSN")
    SENTRY_ENVIRONMENT: str = Field(
        default="development", validation_alias="SENTRY_ENVIRONMENT"
    )
    SENTRY_TRACES_SAMPLE_RATE: float = Field(
        default=0.1, validation_alias="SENTRY_TRACES_SAMPLE_RATE"
    )

    # Email (SendGrid)
    SENDGRID_API_KEY: str | None = Field(
        default=None, validation_alias="SENDGRID_API_KEY"
    )
    SENDGRID_FROM_EMAIL: str | None = Field(
        default=None, validation_alias="SENDGRID_FROM_EMAIL"
    )

    # Cache
    CACHE_ENABLED: bool = Field(default=True, validation_alias="CACHE_ENABLED")
    CACHE_DEFAULT_TTL: int = Field(
        default=300, validation_alias="CACHE_DEFAULT_TTL"
    )  # 5 minutes
    CACHE_MAX_SIZE: int = Field(default=1000, validation_alias="CACHE_MAX_SIZE")

    # Performance
    MAX_WORKERS: int = Field(default=4, validation_alias="MAX_WORKERS")
    MAX_REQUESTS_PER_WORKER: int = Field(
        default=1000, validation_alias="MAX_REQUESTS_PER_WORKER"
    )

    # File Uploads
    MAX_UPLOAD_SIZE: int = Field(
        default=10 * 1024 * 1024, validation_alias="MAX_UPLOAD_SIZE"
    )  # 10MB
    ALLOWED_UPLOAD_TYPES: list[str] = Field(
        default=["image/jpeg", "image/png", "image/gif", "application/pdf"],
        validation_alias="ALLOWED_UPLOAD_TYPES",
    )

    # Payment Gateways
    STRIPE_SECRET_KEY: str | None = Field(None, validation_alias="STRIPE_SECRET_KEY")
    PAYSTACK_SECRET_KEY: str | None = Field(
        None, validation_alias="PAYSTACK_SECRET_KEY"
    )
    DEFAULT_PAYMENT_PROVIDER: str = Field(
        default="stripe", validation_alias="DEFAULT_PAYMENT_PROVIDER"
    )

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors_origins(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",")]
        return v

    @field_validator("ALLOWED_UPLOAD_TYPES", mode="before")
    @classmethod
    def parse_upload_types(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [mime.strip() for mime in v.split(",")]
        return v

    @field_validator("ENVIRONMENT")
    @classmethod
    def validate_environment(cls, v: str) -> str:
        allowed = ["development", "staging", "production", "test"]
        if v not in allowed:
            logger.warning(
                f"Environment {v} not in {allowed}, defaulting to development"
            )
            return "development"
        return v

    @field_validator("LOG_LEVEL")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in allowed:
            logger.warning(f"Log level {v} not in {allowed}, defaulting to INFO")
            return "INFO"
        return v.upper()

    @field_validator("RATE_LIMIT_STRATEGY")
    @classmethod
    def validate_rate_limit_strategy(cls, v: str) -> str:
        allowed = ["fixed_window", "sliding_window", "token_bucket"]
        if v not in allowed:
            logger.warning(
                "Rate limit strategy %s not in %s, defaulting to sliding_window",
                v,
                allowed,
            )
            return "sliding_window"
        return v

    def get_rate_limit_config(self, endpoint: str | None = None) -> dict[str, Any]:
        """Get rate limit configuration for an endpoint."""
        # Default configuration
        config = {
            "enabled": self.RATE_LIMIT_ENABLED,
            "limit": self.RATE_LIMIT_DEFAULT_LIMIT,
            "window": self.RATE_LIMIT_DEFAULT_WINDOW,
            "strategy": self.RATE_LIMIT_STRATEGY,
        }

        # Endpoint-specific overrides
        if endpoint:
            # You can add endpoint-specific configurations here
            pass

        return config

    def get_cache_config(self) -> dict[str, Any]:
        """Get cache configuration."""
        return {
            "enabled": self.CACHE_ENABLED,
            "default_ttl": self.CACHE_DEFAULT_TTL,
            "max_size": self.CACHE_MAX_SIZE,
        }

    def get_database_config(self) -> dict[str, Any]:
        """Get database configuration."""
        return {
            "url": str(self.DATABASE_URL) if self.DATABASE_URL else None,
            "pool_size": self.DATABASE_POOL_SIZE,
            "max_overflow": self.DATABASE_MAX_OVERFLOW,
            "echo": self.DATABASE_ECHO,
            "timeout": self.DATABASE_TIMEOUT,
        }

    def get_redis_config(self) -> dict[str, Any]:
        """Get Redis configuration."""
        return {
            "url": str(self.REDIS_URL) if self.REDIS_URL else None,
            "pool_size": self.REDIS_POOL_SIZE,
            "default_ttl": self.REDIS_DEFAULT_TTL,
            "timeout": self.REDIS_TIMEOUT,
        }

    def get_security_headers_config(self) -> dict[str, Any]:
        """Get security headers configuration."""
        return {
            "enabled": self.SECURITY_HEADERS_ENABLED,
            "csp": self.CONTENT_SECURITY_POLICY,
            "hsts_max_age": self.HSTS_MAX_AGE,
            "hsts_preload": self.HSTS_PRELOAD,
            "hsts_include_subdomains": self.HSTS_INCLUDE_SUBDOMAINS,
        }

    def get_compression_config(self) -> dict[str, Any]:
        """Get compression configuration."""
        return {
            "enabled": self.COMPRESSION_ENABLED,
            "min_size": self.COMPRESSION_MIN_SIZE,
            "level": self.COMPRESSION_LEVEL,
        }

    def get_audit_log_config(self) -> dict[str, Any]:
        """Get audit log configuration."""
        return {
            "enabled": self.AUDIT_LOG_ENABLED,
            "retention_days": self.AUDIT_LOG_RETENTION_DAYS,
            "batch_size": self.AUDIT_LOG_BATCH_SIZE,
            "batch_interval": self.AUDIT_LOG_BATCH_INTERVAL,
        }


# Global configuration instance
_config_instance: CommonConfig | None = None


def get_config() -> CommonConfig:
    """Get the configuration instance."""
    global _config_instance

    if _config_instance is None:
        _config_instance = CommonConfig()
        logger.info(
            f"Configuration loaded for environment: {_config_instance.ENVIRONMENT}"
        )

    return _config_instance


# Compatibility exports expected by other modules
Settings = CommonConfig


def get_settings() -> CommonConfig:
    """Compatibility alias for `get_config()`."""
    return get_config()


def reload_config() -> CommonConfig:
    """Reload configuration from environment."""
    global _config_instance
    _config_instance = CommonConfig()
    logger.info(
        f"Configuration reloaded for environment: {_config_instance.ENVIRONMENT}"
    )
    return _config_instance


# Helper functions
def is_development() -> bool:
    """Check if running in development environment."""
    return get_config().ENVIRONMENT == "development"


def is_production() -> bool:
    """Check if running in production environment."""
    return get_config().ENVIRONMENT == "production"


def is_staging() -> bool:
    """Check if running in staging environment."""
    return get_config().ENVIRONMENT == "staging"


def is_test() -> bool:
    """Check if running in test environment."""
    return get_config().ENVIRONMENT == "test"


def get_log_level() -> str:
    """Get log level from configuration."""
    return get_config().LOG_LEVEL


def get_secret_key() -> str:
    """Get secret key from configuration."""
    return get_config().SECRET_KEY


def get_database_url() -> str | None:
    """Get database URL from configuration."""
    config = get_config()
    return str(config.DATABASE_URL) if config.DATABASE_URL else None


def get_redis_url() -> str | None:
    """Get Redis URL from configuration."""
    config = get_config()
    return str(config.REDIS_URL) if config.REDIS_URL else None
