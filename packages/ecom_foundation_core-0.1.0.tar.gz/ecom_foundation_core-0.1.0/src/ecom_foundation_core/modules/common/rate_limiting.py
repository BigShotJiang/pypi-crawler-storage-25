"""
Redis-based rate limiting implementation.
"""

import hashlib
import logging
import time
from collections.abc import Callable
from typing import Any

import redis.asyncio as redis
from fastapi import HTTPException, Request, Response, status
from starlette.middleware.base import BaseHTTPMiddleware

from ..config import get_settings
from .redis_client import get_redis_client, redis_manager

logger = logging.getLogger(__name__)
settings = get_settings()

# Rate limit strategies
RATE_LIMIT_STRATEGIES = {
    "fixed_window": "fixed_window",
    "sliding_window": "sliding_window",
    "token_bucket": "token_bucket",
}


class RateLimitExceeded(Exception):
    """Exception raised when rate limit is exceeded."""

    def __init__(
        self,
        limit: int,
        window: int,
        retry_after: int,
        identifier: str,
        endpoint: str,
    ) -> None:
        self.limit = limit
        self.window = window
        self.retry_after = retry_after
        self.identifier = identifier
        self.endpoint = endpoint
        super().__init__(f"Rate limit exceeded: {limit} requests per {window} seconds")


class RateLimiter:
    """Redis-based rate limiter with multiple strategies."""

    def __init__(
        self,
        redis_client: redis.Redis | None = None,
        namespace: str = "rate_limit",
    ) -> None:
        self.redis = redis_client or get_redis_client()
        self.namespace = namespace

    def is_available(self) -> bool:
        """Check if Redis is available for rate limiting."""
        return self.redis is not None and redis_manager.is_available()

    async def fixed_window(
        self,
        identifier: str,
        limit: int = 10,
        window: int = 60,
        cost: int = 1,
    ) -> dict[str, Any]:
        """
        Fixed window rate limiting.

        Args:
            identifier: Unique identifier (e.g., IP address, user ID)
            limit: Maximum number of requests
            window: Time window in seconds
            cost: Cost of the request (default: 1)

        Returns:
            Dictionary with rate limit info
        """
        if not self.is_available():
            # If Redis is not available, skip rate limiting
            return {
                "allowed": True,
                "limit": limit,
                "remaining": limit,
                "reset": int(time.time()) + window,
                "retry_after": 0,
            }

        # Create key based on identifier and window
        current_window = int(time.time() // window) * window
        key = f"{self.namespace}:fixed:{identifier}:{current_window}"

        async with self.redis.pipeline() as pipe:
            # Increment counter
            pipe.incrby(key, cost)
            # Set expiration if key is new
            pipe.expire(key, window + 1)  # Add 1 second buffer
            results = await pipe.execute()

        current_count = results[0]

        # Check if limit exceeded
        if current_count > limit:
            return {
                "allowed": False,
                "limit": limit,
                "remaining": 0,
                "reset": current_window + window,
                "retry_after": (current_window + window) - int(time.time()),
            }

        return {
            "allowed": True,
            "limit": limit,
            "remaining": max(0, limit - current_count),
            "reset": current_window + window,
            "retry_after": 0,
        }

    async def sliding_window(
        self,
        identifier: str,
        limit: int = 10,
        window: int = 60,
        cost: int = 1,
        precision: int = 1000,  # Number of sub-windows
    ) -> dict[str, Any]:
        """
        Sliding window rate limiting (more accurate than fixed window).

        Args:
            identifier: Unique identifier
            limit: Maximum number of requests
            window: Time window in seconds
            cost: Cost of the request
            precision: Number of sub-windows for sliding window

        Returns:
            Dictionary with rate limit info
        """
        if not self.is_available():
            return {
                "allowed": True,
                "limit": limit,
                "remaining": limit,
                "reset": int(time.time()) + window,
                "retry_after": 0,
            }

        # Use sorted sets for sliding window
        key = f"{self.namespace}:sliding:{identifier}"
        now = time.time()
        window_start = now - window

        async with self.redis.pipeline() as pipe:
            # Add current request
            member = f"{now}:{cost}"
            pipe.zadd(key, {member: now})
            # Remove old requests
            pipe.zremrangebyscore(key, 0, window_start)
            # Count requests in window
            pipe.zcard(key)
            # Set expiration
            pipe.expire(key, window + 1)
            results = await pipe.execute()

        current_count = results[2]

        # Check if limit exceeded
        if current_count > limit:
            # Get oldest request to calculate retry time
            oldest = await self.redis.zrange(key, 0, 0, withscores=True)
            if oldest:
                oldest_time = oldest[0][1]
                retry_after = int((oldest_time + window) - now)
            else:
                retry_after = window

            return {
                "allowed": False,
                "limit": limit,
                "remaining": 0,
                "reset": int(now + retry_after),
                "retry_after": retry_after,
            }

        return {
            "allowed": True,
            "limit": limit,
            "remaining": max(0, limit - current_count),
            "reset": int(now + window),
            "retry_after": 0,
        }

    async def token_bucket(
        self,
        identifier: str,
        capacity: int = 10,
        refill_rate: float = 1.0,
        cost: int = 1,
    ) -> dict[str, Any]:
        """
        Token bucket rate limiting.

        Args:
            identifier: Unique identifier
            capacity: Maximum tokens in bucket
            refill_rate: Tokens added per second
            cost: Cost of the request

        Returns:
            Dictionary with rate limit info
        """
        if not self.is_available():
            return {
                "allowed": True,
                "limit": capacity,
                "remaining": capacity,
                "reset": int(time.time()) + 1,
                "retry_after": 0,
            }

        key = f"{self.namespace}:token:{identifier}"
        now = time.time()

        async with self.redis.pipeline() as pipe:
            # Get current state
            pipe.hgetall(key)
            results = await pipe.execute()

        state = results[0]

        if not state:
            # Initialize bucket
            tokens = capacity - cost
            last_refill = now
            allowed = True
        else:
            tokens = float(state.get("tokens", capacity))
            last_refill = float(state.get("last_refill", now))

            # Refill tokens
            time_passed = now - last_refill
            refill_amount = time_passed * refill_rate
            tokens = min(capacity, tokens + refill_amount)

            # Check if enough tokens
            if tokens >= cost:
                tokens -= cost
                allowed = True
            else:
                allowed = False

        # Calculate retry time if not allowed
        if not allowed:
            needed = cost - tokens
            retry_after = needed / refill_rate

            return {
                "allowed": False,
                "limit": capacity,
                "remaining": int(tokens),
                "reset": int(now + retry_after),
                "retry_after": int(retry_after),
            }

        # Update bucket state
        async with self.redis.pipeline() as pipe:
            pipe.hset(key, "tokens", tokens)
            pipe.hset(key, "last_refill", now)
            pipe.expire(key, int(capacity / refill_rate) + 1)
            await pipe.execute()

        return {
            "allowed": True,
            "limit": capacity,
            "remaining": int(tokens),
            "reset": int(now + 1),  # Approximate
            "retry_after": 0,
        }

    async def check_rate_limit(
        self,
        identifier: str,
        limit: int = 10,
        window: int = 60,
        strategy: str = "sliding_window",
        cost: int = 1,
    ) -> dict[str, Any]:
        """
        Check rate limit using specified strategy.

        Args:
            identifier: Unique identifier
            limit: Maximum requests
            window: Time window in seconds
            strategy: Rate limiting strategy
            cost: Request cost

        Returns:
            Rate limit information
        """
        if strategy == "fixed_window":
            return await self.fixed_window(identifier, limit, window, cost)
        elif strategy == "sliding_window":
            return await self.sliding_window(identifier, limit, window, cost)
        elif strategy == "token_bucket":
            return await self.token_bucket(identifier, limit, limit / window, cost)
        else:
            raise ValueError(f"Unknown rate limit strategy: {strategy}")


# FastAPI middleware for rate limiting
class RateLimitMiddleware(BaseHTTPMiddleware):
    """FastAPI middleware for rate limiting."""

    def __init__(
        self,
        app: Any,
        limit: int = 100,
        window: int = 60,
        identifier_func: Callable[[Request], str] | None = None,
        strategy: str = "sliding_window",
        skip_paths: list[str] = None,
    ) -> None:
        super().__init__(app)
        self.limit = limit
        self.window = window
        self.strategy = strategy
        self.skip_paths = skip_paths or [
            "/health",
            "/metrics",
            "/docs",
            "/redoc",
            "/openapi.json",
        ]

        if identifier_func:
            self.identifier_func = identifier_func
        else:
            self.identifier_func = self.default_identifier

    @staticmethod
    def default_identifier(request: Request) -> str:
        """Default identifier function using IP address."""
        # Try to get real IP behind proxy
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            # Get the first IP in the chain
            ip = forwarded_for.split(",")[0].strip()
        else:
            ip = request.client.host if request.client else "unknown"

        # Add user agent for more granularity
        user_agent = request.headers.get("User-Agent", "unknown")

        # Create hash for privacy
        identifier = f"{ip}:{user_agent}"
        return hashlib.sha256(identifier.encode()).hexdigest()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Skip rate limiting for certain paths
        if request.url.path in self.skip_paths:
            return await call_next(request)

        # Get identifier
        identifier = self.identifier_func(request)

        # Get rate limiter
        rate_limiter = RateLimiter()

        try:
            # Check rate limit
            result = await rate_limiter.check_rate_limit(
                identifier=identifier,
                limit=self.limit,
                window=self.window,
                strategy=self.strategy,
            )

            if not result["allowed"]:
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail={
                        "error": "Rate limit exceeded",
                        "limit": result["limit"],
                        "window": self.window,
                        "retry_after": result["retry_after"],
                    },
                    headers={
                        "X-RateLimit-Limit": str(result["limit"]),
                        "X-RateLimit-Remaining": str(result["remaining"]),
                        "X-RateLimit-Reset": str(result["reset"]),
                        "Retry-After": str(result["retry_after"]),
                    },
                )

            # Add rate limit headers to response
            response = await call_next(request)

            response.headers["X-RateLimit-Limit"] = str(result["limit"])
            response.headers["X-RateLimit-Remaining"] = str(result["remaining"])
            response.headers["X-RateLimit-Reset"] = str(result["reset"])

            return response

        except HTTPException:
            raise
        except Exception as e:
            # If rate limiting fails, continue without it
            logger.error(f"Rate limiting error: {e}")
            return await call_next(request)


# FastAPI dependency for endpoint-specific rate limiting
def rate_limit(
    limit: int = 10,
    window: int = 60,
    identifier: str | None = None,
    strategy: str = "sliding_window",
    cost: int = 1,
) -> Callable:
    """
    Decorator/dependency for endpoint-specific rate limiting.

    Args:
        limit: Maximum requests
        window: Time window in seconds
        identifier: Custom identifier (defaults to user ID or IP)
        strategy: Rate limiting strategy
        cost: Request cost

    Returns:
        FastAPI dependency
    """

    async def rate_limit_dependency(
        request: Request,
        current_user: dict | None = None,  # From auth dependency
    ) -> dict[str, Any]:
        # Determine identifier
        if identifier:
            ident = identifier
        elif current_user:
            # Use user ID if authenticated
            ident = f"user:{current_user.get('user').id}"
        else:
            # Use IP address
            forwarded_for = request.headers.get("X-Forwarded-For")
            if forwarded_for:
                ip = forwarded_for.split(",")[0].strip()
            else:
                ip = request.client.host if request.client else "unknown"
            ident = f"ip:{ip}"

        # Check rate limit
        rate_limiter = RateLimiter()
        result = await rate_limiter.check_rate_limit(
            identifier=ident,
            limit=limit,
            window=window,
            strategy=strategy,
            cost=cost,
        )

        if not result["allowed"]:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "error": "Rate limit exceeded",
                    "limit": limit,
                    "window": window,
                    "retry_after": result["retry_after"],
                },
                headers={
                    "X-RateLimit-Limit": str(result["limit"]),
                    "X-RateLimit-Remaining": str(result["remaining"]),
                    "X-RateLimit-Reset": str(result["reset"]),
                    "Retry-After": str(result["retry_after"]),
                },
            )

        # Return rate limit info for logging
        return {
            "limit": result["limit"],
            "remaining": result["remaining"],
            "reset": result["reset"],
        }

    return rate_limit_dependency


# API key rate limiting
class APIKeyRateLimiter:
    """Rate limiter specifically for API keys."""

    def __init__(self, redis_client: redis.Redis | None = None) -> None:
        self.redis = redis_client or get_redis_client()
        self.namespace = "api_key_rate_limit"

    async def check_api_key_limit(
        self,
        api_key: str,
        tier: str = "free",
        endpoint: str | None = None,
    ) -> dict[str, Any]:
        """
        Check rate limit for API key.

        Args:
            api_key: API key identifier
            tier: API tier (free, basic, pro, enterprise)
            endpoint: Specific endpoint (optional)

        Returns:
            Rate limit information
        """
        # Define limits per tier
        tier_limits = {
            "free": {"limit": 100, "window": 3600},  # 100/hour
            "basic": {"limit": 1000, "window": 3600},  # 1000/hour
            "pro": {"limit": 10000, "window": 3600},  # 10000/hour
            "enterprise": {"limit": 100000, "window": 3600},  # 100000/hour
        }

        limit_info = tier_limits.get(tier, tier_limits["free"])

        # Create identifier
        if endpoint:
            identifier = f"api_key:{api_key}:{endpoint}"
        else:
            identifier = f"api_key:{api_key}"

        # Check rate limit
        rate_limiter = RateLimiter(self.redis, self.namespace)
        return await rate_limiter.check_rate_limit(
            identifier=identifier,
            limit=limit_info["limit"],
            window=limit_info["window"],
            strategy="sliding_window",
        )


# Global rate limiter instance
rate_limiter = RateLimiter()
