"""
Audit logging stubs.

The repository currently references audit logging middleware, but the full
implementation is not included. These lightweight stubs keep imports working
so the package can be imported and tests can be collected.
"""

from __future__ import annotations

from collections.abc import Callable
from enum import StrEnum
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request


class AuditAction(StrEnum):
    """Minimal set of audit actions."""

    UNKNOWN = "unknown"
    USER_LOGIN = "user_login"


def audit_log(*args: Any, **kwargs: Any) -> Callable:
    """
    No-op decorator used by services to annotate auditable operations.
    """

    def decorator(func: Callable) -> Callable:
        return func

    return decorator


def get_audit_logger() -> Any:
    """Return an audit logger instance (stubbed)."""
    return None


async def init_audit_logging() -> None:
    """Initialize audit logging (no-op)."""
    return None


async def close_audit_logging() -> None:
    """Shutdown audit logging (no-op)."""
    return None


class AuditLogMiddleware(BaseHTTPMiddleware):
    """No-op audit log middleware."""

    def __init__(self, app: Any, audit_logger: Any | None = None) -> None:
        super().__init__(app)
        self.audit_logger = audit_logger

    async def dispatch(self, request: Request, call_next: Callable) -> Any:
        return await call_next(request)


__all__ = [
    "AuditAction",
    "audit_log",
    "AuditLogMiddleware",
    "get_audit_logger",
    "init_audit_logging",
    "close_audit_logging",
]
