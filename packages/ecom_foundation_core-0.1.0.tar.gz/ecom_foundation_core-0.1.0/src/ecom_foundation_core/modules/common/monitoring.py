"""
Monitoring and metrics collection.
"""

import asyncio
import time
from collections.abc import AsyncGenerator, Callable
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from functools import wraps
from typing import Any

import structlog
from fastapi import FastAPI, Request, Response
from prometheus_client import (
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    Summary,
    make_asgi_app,
)
from prometheus_client.exposition import choose_encoder
from sqlalchemy import text

from ..config import get_settings
from .redis_client import redis_manager

logger = structlog.get_logger(__name__)
settings = get_settings()

# Prometheus metrics registry
metrics_registry = CollectorRegistry()

# Define metrics
# HTTP metrics
REQUEST_COUNT = Counter(
    "http_requests_total",
    "Total HTTP requests",
    ["method", "endpoint", "status"],
    registry=metrics_registry,
)

REQUEST_DURATION = Histogram(
    "http_request_duration_seconds",
    "HTTP request duration in seconds",
    ["method", "endpoint"],
    buckets=(0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10.0),
    registry=metrics_registry,
)

REQUEST_IN_PROGRESS = Gauge(
    "http_requests_in_progress",
    "HTTP requests currently in progress",
    ["method", "endpoint"],
    registry=metrics_registry,
)

# Business metrics
USER_REGISTRATION_COUNT = Counter(
    "user_registrations_total",
    "Total user registrations",
    ["source"],
    registry=metrics_registry,
)

LOGIN_COUNT = Counter(
    "user_logins_total",
    "Total user logins",
    ["method", "success"],
    registry=metrics_registry,
)

# System metrics
ACTIVE_SESSIONS = Gauge(
    "active_sessions_total",
    "Total active user sessions",
    registry=metrics_registry,
)

DATABASE_CONNECTIONS = Gauge(
    "database_connections",
    "Database connections",
    ["state"],
    registry=metrics_registry,
)

REDIS_CONNECTIONS = Gauge(
    "redis_connections",
    "Redis connections",
    ["state"],
    registry=metrics_registry,
)

# Error metrics
ERROR_COUNT = Counter(
    "errors_total",
    "Total errors",
    ["type", "endpoint"],
    registry=metrics_registry,
)

# Custom metrics for business logic
CUSTOM_METRICS = {}


class MetricsCollector:
    """Metrics collection and reporting."""

    def __init__(self, app: FastAPI | None = None) -> None:
        self.app = app
        self.middleware_installed = False

    def setup_middleware(self, app: FastAPI) -> None:
        """Setup monitoring middleware for FastAPI."""
        self.app = app
        if self.middleware_installed:
            return

        # Add Prometheus ASGI middleware
        prometheus_app = make_asgi_app(registry=metrics_registry)

        @app.middleware("http")
        async def prometheus_middleware(
            request: Request, call_next: Callable
        ) -> Response:
            # Skip metrics endpoint
            if request.url.path == "/metrics":
                return await prometheus_app(
                    request.scope, request.receive, request._send
                )

            # Record request start time
            start_time = time.time()

            # Record in-progress request
            REQUEST_IN_PROGRESS.labels(
                method=request.method,
                endpoint=self._get_endpoint_name(request),
            ).inc()

            try:
                response = await call_next(request)

                # Record metrics
                duration = time.time() - start_time
                REQUEST_DURATION.labels(
                    method=request.method,
                    endpoint=self._get_endpoint_name(request),
                ).observe(duration)

                REQUEST_COUNT.labels(
                    method=request.method,
                    endpoint=self._get_endpoint_name(request),
                    status=response.status_code,
                ).inc()

                return response

            except Exception as e:
                # Record error
                ERROR_COUNT.labels(
                    type=type(e).__name__,
                    endpoint=self._get_endpoint_name(request),
                ).inc()
                raise
            finally:
                # Decrement in-progress request
                REQUEST_IN_PROGRESS.labels(
                    method=request.method,
                    endpoint=self._get_endpoint_name(request),
                ).dec()

        # Add metrics endpoint
        @app.get("/metrics")
        async def metrics_endpoint(
            request: Request,
        ) -> Response:
            """Prometheus metrics endpoint."""
            encoder, content_type = choose_encoder(request.headers.get("Accept"))
            output = encoder(metrics_registry)
            return Response(content=output, media_type=content_type)

        # Add health check endpoint
        @app.get("/health")
        async def health_check() -> dict[str, Any]:
            """Health check endpoint with system status."""
            health_status = {
                "status": "healthy",
                "timestamp": datetime.now(UTC).isoformat(),
                "version": "1.0.0",
                "services": await self._check_services(),
            }

            # Check if all services are healthy
            all_healthy = all(
                service["status"] == "healthy"
                for service in health_status["services"].values()
            )

            health_status["status"] = "healthy" if all_healthy else "unhealthy"

            return health_status

        # Add readiness endpoint
        @app.get("/ready")
        async def readiness_check() -> dict[str, Any]:
            """Readiness check endpoint."""
            services = await self._check_services()

            # For readiness, we might accept some services being down
            critical_services = {k: v for k, v in services.items() if v["critical"]}
            all_ready = all(
                service["status"] == "healthy" for service in critical_services.values()
            )

            return {
                "status": "ready" if all_ready else "not_ready",
                "services": services,
                "timestamp": datetime.now(UTC).isoformat(),
            }

        # Add liveness endpoint
        @app.get("/live")
        async def liveness_check() -> dict[str, Any]:
            """Liveness check endpoint."""
            return {"status": "alive", "timestamp": datetime.now(UTC).isoformat()}

        self.middleware_installed = True
        logger.info("Monitoring middleware installed")

    @staticmethod
    def _get_endpoint_name(request: Request) -> str:
        """Get endpoint name from request."""
        if hasattr(request, "route"):
            return request.route.path
        return request.url.path

    async def _check_services(self) -> dict[str, dict[str, Any]]:
        """Check health of all services."""
        services = {}

        # Database health
        try:
            from .database import db_manager

            if db_manager.is_initialized:
                async with db_manager.engine.connect() as conn:
                    await conn.execute(text("SELECT 1"))
                services["database"] = {
                    "status": "healthy",
                    "critical": True,
                    "message": "Connected",
                }
            else:
                services["database"] = {
                    "status": "unhealthy",
                    "critical": True,
                    "message": "Not initialized",
                }
        except Exception as e:
            services["database"] = {
                "status": "unhealthy",
                "critical": True,
                "message": str(e),
            }

        # Redis health
        try:
            if redis_manager.is_available():
                await redis_manager.client.ping()
                services["redis"] = {
                    "status": "healthy",
                    "critical": False,
                    "message": "Connected",
                }
            else:
                services["redis"] = {
                    "status": "unhealthy",
                    "critical": False,
                    "message": "Not available",
                }
        except Exception as e:
            services["redis"] = {
                "status": "unhealthy",
                "critical": False,
                "message": str(e),
            }

        return services

    def record_user_registration(self, source: str = "web") -> None:
        """Record user registration metric."""
        USER_REGISTRATION_COUNT.labels(source=source).inc()

    def record_login(self, method: str, success: bool) -> None:
        """Record user login metric."""
        LOGIN_COUNT.labels(method=method, success=str(success)).inc()

    def record_active_sessions(self, count: int) -> None:
        """Record active sessions metric."""
        ACTIVE_SESSIONS.set(count)

    def record_error(self, error_type: str, endpoint: str = "unknown") -> None:
        """Record error metric."""
        ERROR_COUNT.labels(type=error_type, endpoint=endpoint).inc()

    def create_custom_metric(
        self,
        name: str,
        metric_type: str = "counter",
        description: str = "",
        labels: list | None = None,
    ) -> Any:
        """Create a custom metric."""
        if name in CUSTOM_METRICS:
            return CUSTOM_METRICS[name]

        labels = labels or []

        if metric_type == "counter":
            metric = Counter(name, description, labels, registry=metrics_registry)
        elif metric_type == "gauge":
            metric = Gauge(name, description, labels, registry=metrics_registry)
        elif metric_type == "histogram":
            metric = Histogram(name, description, labels, registry=metrics_registry)
        elif metric_type == "summary":
            metric = Summary(name, description, labels, registry=metrics_registry)
        else:
            raise ValueError(f"Unknown metric type: {metric_type}")

        CUSTOM_METRICS[name] = metric
        return metric

    def get_metric(self, name: str) -> Any:
        """Get a custom metric by name."""
        return CUSTOM_METRICS.get(name)


# Performance monitoring decorator
def monitor_performance(name: str) -> Callable:
    """
    Decorator to monitor function performance.

    Args:
        name: Metric name

    Returns:
        Decorator function
    """

    def decorator(func: Callable) -> Callable:
        if asyncio.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                start_time = time.time()
                try:
                    result = await func(*args, **kwargs)
                    duration = time.time() - start_time

                    # Record duration
                    metric_name = f"{name}_duration_seconds"
                    if metric_name not in CUSTOM_METRICS:
                        CUSTOM_METRICS[metric_name] = Histogram(
                            metric_name,
                            f"Duration of {name}",
                            registry=metrics_registry,
                        )
                    CUSTOM_METRICS[metric_name].observe(duration)

                    return result
                except Exception as e:
                    # Record error
                    ERROR_COUNT.labels(
                        type=type(e).__name__,
                        endpoint=name,
                    ).inc()
                    raise

            return async_wrapper
        else:

            @wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                start_time = time.time()
                try:
                    result = func(*args, **kwargs)
                    duration = time.time() - start_time

                    # Record duration
                    metric_name = f"{name}_duration_seconds"
                    if metric_name not in CUSTOM_METRICS:
                        CUSTOM_METRICS[metric_name] = Histogram(
                            metric_name,
                            f"Duration of {name}",
                            registry=metrics_registry,
                        )
                    CUSTOM_METRICS[metric_name].observe(duration)

                    return result
                except Exception as e:
                    # Record error
                    ERROR_COUNT.labels(
                        type=type(e).__name__,
                        endpoint=name,
                    ).inc()
                    raise

            return sync_wrapper

    return decorator


# Context manager for monitoring
@asynccontextmanager
async def monitor_operation(
    name: str, labels: dict[str, str] | None = None
) -> AsyncGenerator[None, None]:
    """
    Context manager for monitoring operations.

    Args:
        name: Operation name
        labels: Additional labels

    Yields:
        Operation context
    """
    start_time = time.time()
    in_progress_metric = None

    try:
        # Create in-progress metric if needed
        metric_name = f"{name}_in_progress"
        if metric_name not in CUSTOM_METRICS:
            CUSTOM_METRICS[metric_name] = Gauge(
                metric_name,
                f"{name} operations in progress",
                list(labels.keys()) if labels else [],
                registry=metrics_registry,
            )

        in_progress_metric = CUSTOM_METRICS[metric_name]

        # Increment in-progress counter
        if labels:
            in_progress_metric.labels(**labels).inc()
        else:
            in_progress_metric.inc()

        yield

    finally:
        # Decrement in-progress counter
        if in_progress_metric:
            if labels:
                in_progress_metric.labels(**labels).dec()
            else:
                in_progress_metric.dec()

        # Record duration
        duration = time.time() - start_time
        duration_metric_name = f"{name}_duration_seconds"

        if duration_metric_name not in CUSTOM_METRICS:
            CUSTOM_METRICS[duration_metric_name] = Histogram(
                duration_metric_name,
                f"Duration of {name} operations",
                list(labels.keys()) if labels else [],
                registry=metrics_registry,
            )

        duration_metric = CUSTOM_METRICS[duration_metric_name]

        if labels:
            duration_metric.labels(**labels).observe(duration)
        else:
            duration_metric.observe(duration)


# Structured logging setup
def setup_structured_logging() -> None:
    """Setup structured logging with structlog."""
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


# Global metrics collector instance
metrics_collector = MetricsCollector()


# FastAPI dependencies
async def get_metrics_collector() -> MetricsCollector:
    """FastAPI dependency for metrics collector."""
    return metrics_collector
