"""
Redis client with connection pooling and utilities.
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import timedelta
from typing import Any

import redis.asyncio as redis
from redis.asyncio.connection import ConnectionPool
from redis.exceptions import (
    AuthenticationError,
    ConnectionError,
    RedisError,
    TimeoutError,
)

from ..config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class RedisManager:
    """Redis connection manager with connection pooling."""

    def __init__(self) -> None:
        self.client: redis.Redis | None = None
        self.pool: ConnectionPool | None = None
        self.is_initialized = False

    async def initialize(self, redis_url: str | None = None) -> None:
        """Initialize Redis connection pool."""
        if self.is_initialized:
            return

        url = redis_url or settings.redis_url
        if not url:
            logger.warning("Redis URL not configured, Redis features will be disabled")
            return

        try:
            # Create connection pool
            self.pool = ConnectionPool.from_url(
                url,
                max_connections=settings.redis_pool_size,
                socket_connect_timeout=5,
                socket_timeout=5,
                socket_keepalive=True,
                retry_on_timeout=True,
                health_check_interval=30,
            )

            # Create Redis client
            self.client = redis.Redis(
                connection_pool=self.pool,
                decode_responses=True,  # Automatically decode responses to strings
                encoding="utf-8",
            )

            # Test connection
            await self.test_connection()

            self.is_initialized = True
            logger.info("Redis initialized successfully")

        except AuthenticationError as e:
            logger.error(f"Redis authentication failed: {e}")
            raise
        except (ConnectionError, TimeoutError) as e:
            logger.error(f"Failed to connect to Redis: {e}")
            # Don't raise - allow app to start without Redis
            self.is_initialized = False

    async def test_connection(
        self, retries: int = 3, delay: float = 1.0
    ) -> bool | None:
        """Test Redis connection with retries."""
        if not self.client:
            raise RuntimeError("Redis client not initialized")

        for attempt in range(retries):
            try:
                # Simple PING test
                pong = await self.client.ping()
                if pong:
                    logger.info("Redis connection test successful")
                    return True
            except RedisError as e:
                logger.warning(
                    "Redis connection test failed (attempt %s/%s): %s",
                    attempt + 1,
                    retries,
                    e,
                )
                if attempt < retries - 1:
                    await asyncio.sleep(delay)
                else:
                    logger.error("Failed to connect to Redis after all retries")
                    raise
        return False

    async def close(self) -> None:
        """Close Redis connections."""
        if self.client:
            await self.client.close()
        if self.pool:
            await self.pool.disconnect()

        self.client = None
        self.pool = None
        self.is_initialized = False
        logger.info("Redis connections closed")

    def is_available(self) -> bool:
        """Check if Redis is available."""
        return self.is_initialized and self.client is not None

    # Key operations
    async def get(self, key: str) -> str | None:
        """Get value from Redis."""
        if not self.is_available():
            return None

        try:
            value = await self.client.get(key)
            return value
        except RedisError as e:
            logger.error(f"Redis GET error for key {key}: {e}")
            return None

    async def set(
        self,
        key: str,
        value: Any,
        expire: int | timedelta | None = None,
        nx: bool = False,
        xx: bool = False,
    ) -> bool:
        """Set value in Redis with optional expiration."""
        if not self.is_available():
            return False

        try:
            # Convert value to string
            if not isinstance(value, str):
                if isinstance(value, (dict, list)):
                    value = json.dumps(value)
                else:
                    value = str(value)

            # Set with options
            if expire:
                if isinstance(expire, timedelta):
                    expire = int(expire.total_seconds())

                if nx:
                    return await self.client.set(key, value, ex=expire, nx=True)
                elif xx:
                    return await self.client.set(key, value, ex=expire, xx=True)
                else:
                    return await self.client.setex(key, expire, value)
            else:
                if nx:
                    return await self.client.set(key, value, nx=True)
                elif xx:
                    return await self.client.set(key, value, xx=True)
                else:
                    return await self.client.set(key, value)

        except RedisError as e:
            logger.error(f"Redis SET error for key {key}: {e}")
            return False

    async def delete(self, key: str) -> bool:
        """Delete key from Redis."""
        if not self.is_available():
            return False

        try:
            result = await self.client.delete(key)
            return result > 0
        except RedisError as e:
            logger.error(f"Redis DELETE error for key {key}: {e}")
            return False

    async def exists(self, key: str) -> bool:
        """Check if key exists in Redis."""
        if not self.is_available():
            return False

        try:
            result = await self.client.exists(key)
            return result > 0
        except RedisError as e:
            logger.error(f"Redis EXISTS error for key {key}: {e}")
            return False

    async def expire(self, key: str, seconds: int) -> bool:
        """Set expiration for key."""
        if not self.is_available():
            return False

        try:
            result = await self.client.expire(key, seconds)
            return result
        except RedisError as e:
            logger.error(f"Redis EXPIRE error for key {key}: {e}")
            return False

    async def ttl(self, key: str) -> int | None:
        """Get time to live for key."""
        if not self.is_available():
            return None

        try:
            ttl = await self.client.ttl(key)
            return ttl
        except RedisError as e:
            logger.error(f"Redis TTL error for key {key}: {e}")
            return None

    # Hash operations
    async def hget(self, key: str, field: str) -> str | None:
        """Get field from hash."""
        if not self.is_available():
            return None

        try:
            return await self.client.hget(key, field)
        except RedisError as e:
            logger.error(f"Redis HGET error for key {key}, field {field}: {e}")
            return None

    async def hset(self, key: str, field: str, value: Any) -> bool:
        """Set field in hash."""
        if not self.is_available():
            return False

        try:
            if not isinstance(value, str):
                if isinstance(value, (dict, list)):
                    value = json.dumps(value)
                else:
                    value = str(value)

            result = await self.client.hset(key, field, value)
            return result > 0
        except RedisError as e:
            logger.error(f"Redis HSET error for key {key}, field {field}: {e}")
            return False

    async def hgetall(self, key: str) -> dict[str, str] | None:
        """Get all fields from hash."""
        if not self.is_available():
            return None

        try:
            return await self.client.hgetall(key)
        except RedisError as e:
            logger.error(f"Redis HGETALL error for key {key}: {e}")
            return None

    # List operations
    async def lpush(self, key: str, value: Any) -> int | None:
        """Push value to list."""
        if not self.is_available():
            return None

        try:
            if not isinstance(value, str):
                if isinstance(value, (dict, list)):
                    value = json.dumps(value)
                else:
                    value = str(value)

            return await self.client.lpush(key, value)
        except RedisError as e:
            logger.error(f"Redis LPUSH error for key {key}: {e}")
            return None

    async def rpop(self, key: str) -> str | None:
        """Pop value from list."""
        if not self.is_available():
            return None

        try:
            return await self.client.rpop(key)
        except RedisError as e:
            logger.error(f"Redis RPOP error for key {key}: {e}")
            return None

    async def lrange(self, key: str, start: int = 0, end: int = -1) -> list[str] | None:
        """Get range from list."""
        if not self.is_available():
            return None

        try:
            return await self.client.lrange(key, start, end)
        except RedisError as e:
            logger.error(f"Redis LRANGE error for key {key}: {e}")
            return None

    # Set operations
    async def sadd(self, key: str, value: Any) -> int | None:
        """Add value to set."""
        if not self.is_available():
            return None

        try:
            if not isinstance(value, str):
                if isinstance(value, (dict, list)):
                    value = json.dumps(value)
                else:
                    value = str(value)

            return await self.client.sadd(key, value)
        except RedisError as e:
            logger.error(f"Redis SADD error for key {key}: {e}")
            return None

    async def smembers(self, key: str) -> set | None:
        """Get all members of set."""
        if not self.is_available():
            return None

        try:
            return await self.client.smembers(key)
        except RedisError as e:
            logger.error(f"Redis SMEMBERS error for key {key}: {e}")
            return None

    # Sorted set operations (for rate limiting)
    async def zadd(self, key: str, mapping: dict[str, float]) -> int | None:
        """Add members to sorted set with scores."""
        if not self.is_available():
            return None

        try:
            return await self.client.zadd(key, mapping)
        except RedisError as e:
            logger.error(f"Redis ZADD error for key {key}: {e}")
            return None

    async def zrangebyscore(
        self,
        key: str,
        min_score: float,
        max_score: float,
        withscores: bool = False,
    ) -> list | None:
        """Get members from sorted set by score range."""
        if not self.is_available():
            return None

        try:
            return await self.client.zrangebyscore(
                key, min_score, max_score, withscores=withscores
            )
        except RedisError as e:
            logger.error(f"Redis ZRANGEBYSCORE error for key {key}: {e}")
            return None

    async def zremrangebyscore(
        self, key: str, min_score: float, max_score: float
    ) -> int | None:
        """Remove members from sorted set by score range."""
        if not self.is_available():
            return None

        try:
            return await self.client.zremrangebyscore(key, min_score, max_score)
        except RedisError as e:
            logger.error(f"Redis ZREMRANGEBYSCORE error for key {key}: {e}")
            return None

    async def zcard(self, key: str) -> int | None:
        """Get number of members in sorted set."""
        if not self.is_available():
            return None

        try:
            return await self.client.zcard(key)
        except RedisError as e:
            logger.error(f"Redis ZCARD error for key {key}: {e}")
            return None

    # Pub/Sub operations
    async def publish(self, channel: str, message: Any) -> int | None:
        """Publish message to channel."""
        if not self.is_available():
            return None

        try:
            if not isinstance(message, str):
                if isinstance(message, (dict, list)):
                    message = json.dumps(message)
                else:
                    message = str(message)

            return await self.client.publish(channel, message)
        except RedisError as e:
            logger.error(f"Redis PUBLISH error for channel {channel}: {e}")
            return None

    # Pipeline operations
    @asynccontextmanager
    async def pipeline(self) -> AsyncGenerator[redis.client.Pipeline | None, None]:
        """Context manager for Redis pipeline."""
        if not self.is_available():
            yield None
            return

        pipe = self.client.pipeline()
        try:
            yield pipe
            await pipe.execute()
        except RedisError as e:
            logger.error(f"Redis pipeline error: {e}")
            await pipe.reset()
            raise
        finally:
            await pipe.reset()

    # Utility methods
    async def flushdb(self) -> None:
        """Flush all databases (use with caution!)."""
        if not self.is_available():
            return

        try:
            await self.client.flushdb()
            logger.warning("Redis database flushed")
        except RedisError as e:
            logger.error(f"Redis FLUSHDB error: {e}")

    async def info(self, section: str | None = None) -> dict | None:
        """Get Redis server information."""
        if not self.is_available():
            return None

        try:
            info = await self.client.info(section)
            return info
        except RedisError as e:
            logger.error(f"Redis INFO error: {e}")
            return None


# Global Redis manager instance
redis_manager = RedisManager()


# FastAPI dependencies
async def get_redis() -> RedisManager:
    """FastAPI dependency for Redis."""
    if not redis_manager.is_initialized:
        await redis_manager.initialize()
    return redis_manager


async def init_redis() -> None:
    """Initialize Redis on application startup."""
    await redis_manager.initialize()


async def close_redis() -> None:
    """Close Redis connections on application shutdown."""
    await redis_manager.close()


# Utility functions
def get_redis_client() -> redis.Redis | None:
    """Get the Redis client directly."""
    return redis_manager.client if redis_manager.is_available() else None
