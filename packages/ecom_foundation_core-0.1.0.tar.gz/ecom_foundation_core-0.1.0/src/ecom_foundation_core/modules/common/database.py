"""
Database configuration and session management.
"""

import asyncio
import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Request
from sqlalchemy import event, text
from sqlalchemy.exc import InterfaceError, OperationalError
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import declarative_base
from sqlalchemy.pool import AsyncAdaptedQueuePool

from .config import get_settings

logger = logging.getLogger(__name__)

Base = declarative_base()


class DatabaseManager:
    """Database connection manager."""

    def __init__(self) -> None:
        self.engine: AsyncEngine | None = None
        self.session_factory: async_sessionmaker | None = None
        self.is_initialized = False

    async def initialize(self, database_url: str | None = None) -> None:
        """Initialize database connection."""
        if self.is_initialized:
            return

        settings = get_settings()
        db_url = database_url or settings.database_url
        if not db_url:
            raise ValueError("Database URL is required")

        # Create async engine with connection pooling
        self.engine = create_async_engine(
            db_url,
            echo=settings.debug,
            poolclass=AsyncAdaptedQueuePool,
            pool_size=settings.database_pool_size,
            max_overflow=settings.database_max_overflow,
            pool_pre_ping=True,  # Verify connections before using
            pool_recycle=3600,  # Recycle connections every hour
            pool_timeout=30,  # Wait up to 30 seconds for connection
            connect_args={
                "server_settings": {
                    "application_name": "ecom_foundation_core",
                    "jit": "off",  # Disable JIT for better performance
                }
            },
        )

        # Add connection event listeners
        @event.listens_for(self.engine.sync_engine, "connect")
        def set_search_path(dbapi_connection: Any, connection_record: Any) -> None:
            """Set default search path for multi-tenant support."""
            cursor = dbapi_connection.cursor()
            cursor.execute("SET search_path TO public")
            cursor.close()

        # Create session factory
        self.session_factory = async_sessionmaker(
            self.engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
        )

        self.is_initialized = True
        logger.info("Database initialized successfully")

        # Test connection
        await self.test_connection()

    async def test_connection(self, retries: int = 3, delay: float = 1.0) -> bool:
        """Test database connection with retries."""
        for attempt in range(retries):
            try:
                async with self.engine.connect() as conn:
                    await conn.execute(text("SELECT 1"))
                logger.info("Database connection test successful")
                return True
            except (OperationalError, InterfaceError) as e:
                logger.warning(
                    "Database connection test failed (attempt %s/%s): %s",
                    attempt + 1,
                    retries,
                    e,
                )
                if attempt < retries - 1:
                    await asyncio.sleep(delay)
                else:
                    logger.error("Failed to connect to database after all retries")
                    raise
        return False

    async def dispose(self) -> None:
        """Close all database connections."""
        if self.engine:
            await self.engine.dispose()
            self.engine = None
            self.session_factory = None
            self.is_initialized = False
            logger.info("Database connections disposed")

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """Get a database session with automatic cleanup."""
        if not self.is_initialized:
            await self.initialize()

        session = self.session_factory()
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            await session.close()

    async def create_all(self) -> None:
        """Create all tables (for development/testing)."""
        if not self.is_initialized:
            await self.initialize()

        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("All database tables created")

    async def drop_all(self) -> None:
        """Drop all tables (for testing)."""
        if not self.is_initialized:
            await self.initialize()

        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
        logger.info("All database tables dropped")


# Global database manager instance
db_manager = DatabaseManager()


# FastAPI dependencies
async def get_async_session(request: Request) -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency for database session."""
    engine = request.app.state.db_engine
    if not engine:
        raise RuntimeError(
            "Database engine not configured. Pass `db_engine` to `create_app`."
        )

    session_factory = async_sessionmaker(
        engine, class_=AsyncSession, expire_on_commit=False
    )
    async with session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def init_db() -> None:
    """Initialize database on application startup."""
    # This is now the responsibility of the consuming application
    pass


async def close_db() -> None:
    """Close database connections on application shutdown."""
    # This is now the responsibility of the consuming application
    pass


# Utility functions
def get_session_factory() -> async_sessionmaker:
    """Get the session factory."""
    return db_manager.session_factory


def get_engine() -> AsyncEngine:
    """Get the database engine."""
    return db_manager.engine
