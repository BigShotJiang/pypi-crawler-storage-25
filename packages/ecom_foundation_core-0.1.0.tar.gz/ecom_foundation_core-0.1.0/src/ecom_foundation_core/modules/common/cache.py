"""
Caching layer with Redis backend.
"""

import asyncio
import hashlib
import json
import pickle
from collections.abc import Callable
from functools import wraps
from typing import Any

from .config import get_config
from .redis_client import redis_manager

config = get_config()


class CacheManager:
    """Cache manager with Redis backend."""

    def __init__(self, namespace: str = "cache", default_ttl: int = None) -> None:
        self.namespace = namespace
        self.default_ttl = default_ttl or config.CACHE_DEFAULT_TTL

    def _make_key(self, key: str) -> str:
        """Create namespaced cache key."""
        return f"{self.namespace}:{key}"

    async def get(self, key: str, default: Any = None) -> Any:
        """Get value from cache."""
        if not redis_manager.is_available():
            return default

        cache_key = self._make_key(key)
        value = await redis_manager.get(cache_key)

        if value is None:
            return default

        try:
            # Try to deserialize JSON
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            # Return as-is
            return value

    async def set(
        self,
        key: str,
        value: Any,
        ttl: int | None = None,
    ) -> bool:
        """Set value in cache."""
        if not redis_manager.is_available():
            return False

        cache_key = self._make_key(key)
        ttl = ttl or self.default_ttl

        # Serialize value
        if isinstance(value, (dict, list, tuple, int, float, bool, str, type(None))):
            serialized = json.dumps(value)
        else:
            # Use pickle for complex objects
            serialized = pickle.dumps(value)

        return await redis_manager.set(cache_key, serialized, expire=ttl)

    async def delete(self, key: str) -> bool:
        """Delete key from cache."""
        if not redis_manager.is_available():
            return False

        cache_key = self._make_key(key)
        return await redis_manager.delete(cache_key)

    async def exists(self, key: str) -> bool:
        """Check if key exists in cache."""
        if not redis_manager.is_available():
            return False

        cache_key = self._make_key(key)
        return await redis_manager.exists(cache_key)

    async def clear(self, pattern: str = "*") -> int:
        """Clear cache keys matching pattern."""
        if not redis_manager.is_available():
            return 0

        # Note: This is a simple implementation
        # In production, use SCAN for large datasets
        keys = await redis_manager.keys(f"{self.namespace}:{pattern}")
        if not keys:
            return 0

        deleted = 0
        for key in keys:
            if await redis_manager.delete(key):
                deleted += 1

        return deleted

    async def increment(self, key: str, amount: int = 1) -> int | None:
        """Increment cached value."""
        if not redis_manager.is_available():
            return None

        # Get current value
        current = await self.get(key, 0)
        if not isinstance(current, (int, float)):
            current = 0

        new_value = current + amount
        await self.set(key, new_value)

        return new_value

    async def decrement(self, key: str, amount: int = 1) -> int | None:
        """Decrement cached value."""
        return await self.increment(key, -amount)


# Global cache manager instance
cache_manager = CacheManager()


# FastAPI dependency
async def get_cache() -> CacheManager:
    """Get cache manager instance."""
    return cache_manager


# Decorator for caching function results
def cached(
    key: str | None = None,
    ttl: int | None = None,
    namespace: str = "func",
) -> Callable:
    """
    Decorator to cache function results.

    Args:
        key: Cache key (defaults to function signature)
        ttl: Time to live in seconds
        namespace: Cache namespace

    Returns:
        Decorated function
    """

    def decorator(func: Callable) -> Callable:
        cache = CacheManager(namespace=namespace)

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            # Generate cache key
            if key:
                cache_key = key
            else:
                # Create key from function name and arguments
                key_parts = [func.__module__, func.__name__]
                key_parts.extend(str(arg) for arg in args)
                key_parts.extend(f"{k}={v}" for k, v in sorted(kwargs.items()))
                key_str = ":".join(key_parts)
                cache_key = hashlib.sha256(key_str.encode()).hexdigest()

            # Try to get from cache
            cached_result = await cache.get(cache_key)
            if cached_result is not None:
                return cached_result

            # Execute function
            result = await func(*args, **kwargs)

            # Store in cache
            await cache.set(cache_key, result, ttl=ttl)

            return result

        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            # Similar logic for sync functions
            pass

        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

    return decorator


# Alias for async caching
async_cached = cached


# Cache invalidation helper
async def cache_invalidate(pattern: str, namespace: str = "func") -> int:
    """
    Invalidate cache entries matching pattern.

    Args:
        pattern: Pattern to match
        namespace: Cache namespace

    Returns:
        Number of invalidated entries
    """
    cache = CacheManager(namespace=namespace)
    return await cache.clear(pattern)


# Clear all cache
async def cache_clear() -> int:
    """Clear all cache entries."""
    total = 0
    for namespace in ["func", "data", "session"]:
        cache = CacheManager(namespace=namespace)
        total += await cache.clear("*")
    return total
