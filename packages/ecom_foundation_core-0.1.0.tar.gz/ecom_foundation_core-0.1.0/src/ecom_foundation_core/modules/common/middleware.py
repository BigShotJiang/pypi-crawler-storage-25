"""
Common middleware for FastAPI applications.
"""

import asyncio  # Added missing import
import gzip
import json
import time
import uuid
from collections.abc import Callable
from contextvars import ContextVar
from datetime import datetime

import structlog
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import Counter, Gauge, Histogram
from starlette.middleware.base import BaseHTTPMiddleware

from .config import get_config

logger = structlog.get_logger(__name__)
config = get_config()

# Context variables
request_id_var: ContextVar[str] | None = ContextVar("request_id", default=None)
start_time_var: ContextVar[float] | None = ContextVar("start_time", default=None)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Middleware to add request ID to all requests."""

    def __init__(self, app: FastAPI, header_name: str = "X-Request-ID") -> None:
        super().__init__(app)
        self.header_name = header_name

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Get request ID from header or generate new one
        request_id = request.headers.get(self.header_name)
        if not request_id:
            request_id = str(uuid.uuid4())

        # Set context variable
        token = request_id_var.set(request_id)

        try:
            # Process request
            response = await call_next(request)

            # Add request ID to response headers
            response.headers[self.header_name] = request_id

            return response
        finally:
            # Clean up context
            request_id_var.reset(token)


class LoggingMiddleware(BaseHTTPMiddleware):
    """Middleware for structured logging of all requests."""

    def __init__(self, app: FastAPI) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Get request ID
        request_id = request_id_var.get() or str(uuid.uuid4())

        # Set start time
        start_time = time.time()
        start_token = start_time_var.set(start_time)

        # Log request start
        await self._log_request_start(request, request_id, start_time)

        try:
            # Process request
            response = await call_next(request)

            # Calculate duration
            duration = time.time() - start_time

            # Log request completion
            await self._log_request_end(
                request, request_id, response, duration, start_time
            )

            return response

        except Exception as e:
            # Calculate duration even on error
            duration = time.time() - start_time

            # Log request error
            await self._log_request_error(request, request_id, e, duration, start_time)

            raise
        finally:
            # Clean up context
            start_time_var.reset(start_token)

    async def _log_request_start(
        self, request: Request, request_id: str, start_time: float
    ) -> None:
        """Log request start."""
        log_data = {
            "request_id": request_id,
            "method": request.method,
            "url": str(request.url),
            "client_ip": self._get_client_ip(request),
            "user_agent": request.headers.get("user-agent"),
            "start_time": datetime.fromtimestamp(start_time).isoformat(),
        }

        logger.info("request_started", **log_data)

    async def _log_request_end(
        self,
        request: Request,
        request_id: str,
        response: Response,
        duration: float,
        start_time: float,
    ) -> None:
        """Log request completion."""
        log_data = {
            "request_id": request_id,
            "method": request.method,
            "url": str(request.url),
            "status_code": response.status_code,
            "duration_ms": round(duration * 1000, 2),
            "client_ip": self._get_client_ip(request),
            "user_agent": request.headers.get("user-agent"),
            "start_time": datetime.fromtimestamp(start_time).isoformat(),
            "end_time": datetime.fromtimestamp(time.time()).isoformat(),
        }

        # Add content length if available
        if hasattr(response, "headers") and "content-length" in response.headers:
            log_data["content_length"] = response.headers["content-length"]

        # Log at appropriate level
        if response.status_code >= 500:
            logger.error("request_completed", **log_data)
        elif response.status_code >= 400:
            logger.warning("request_completed", **log_data)
        else:
            logger.info("request_completed", **log_data)

    async def _log_request_error(
        self,
        request: Request,
        request_id: str,
        error: Exception,
        duration: float,
        start_time: float,
    ) -> None:
        """Log request error."""
        log_data = {
            "request_id": request_id,
            "method": request.method,
            "url": str(request.url),
            "error_type": type(error).__name__,
            "error_message": str(error),
            "duration_ms": round(duration * 1000, 2),
            "client_ip": self._get_client_ip(request),
            "user_agent": request.headers.get("user-agent"),
            "start_time": datetime.fromtimestamp(start_time).isoformat(),
            "end_time": datetime.fromtimestamp(time.time()).isoformat(),
        }

        logger.error("request_failed", **log_data)

    @staticmethod
    def _get_client_ip(request: Request) -> str | None:
        """Get client IP address."""
        forwarded_for = request.headers.get("x-forwarded-for")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        elif request.client:
            return request.client.host
        return None


class TimeoutMiddleware(BaseHTTPMiddleware):
    """Middleware to add timeout to requests."""

    def __init__(self, app: FastAPI, timeout: int = 30) -> None:
        super().__init__(app)
        self.timeout = timeout

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        try:
            # Create timeout task
            task = asyncio.create_task(call_next(request))

            # Wait with timeout
            response = await asyncio.wait_for(task, timeout=self.timeout)

            return response

        except TimeoutError:
            # Log timeout
            logger.warning(
                "request_timeout",
                request_id=request_id_var.get(),
                method=request.method,
                url=str(request.url),
                timeout=self.timeout,
            )

            # Return timeout response
            return Response(
                content=json.dumps(
                    {
                        "error": "Request timeout",
                        "message": f"Request took longer than {self.timeout} seconds",
                    }
                ),
                status_code=504,
                media_type="application/json",
            )


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: FastAPI) -> None:
        super().__init__(app)
        self.config = config.get_security_headers_config()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)

        if self.config["enabled"]:
            # Add security headers
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["X-XSS-Protection"] = "1; mode=block"
            response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

            # Add Content Security Policy
            if self.config["csp"]:
                response.headers["Content-Security-Policy"] = self.config["csp"]

            # Add HSTS header for HTTPS
            if request.url.scheme == "https":
                hsts_value = f"max-age={self.config['hsts_max_age']}"
                if self.config["hsts_include_subdomains"]:
                    hsts_value += "; includeSubDomains"
                if self.config["hsts_preload"]:
                    hsts_value += "; preload"
                response.headers["Strict-Transport-Security"] = hsts_value

            # Add permissions policy
            response.headers["Permissions-Policy"] = (
                "geolocation=(), microphone=(), camera=(), "
                "payment=(), usb=(), fullscreen=self, interest-cohort=()"
            )

        return response


class CompressionMiddleware(BaseHTTPMiddleware):
    """Middleware to compress responses."""

    def __init__(self, app: FastAPI) -> None:
        super().__init__(app)
        self.config = config.get_compression_config()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Check if compression is enabled
        if not self.config["enabled"]:
            return await call_next(request)

        # Check if client accepts gzip
        accept_encoding = request.headers.get("accept-encoding", "")
        if "gzip" not in accept_encoding.lower():
            return await call_next(request)

        # Process request
        response = await call_next(request)

        # Check if response should be compressed
        if not self._should_compress(response):
            return response

        # Compress response body
        body = b""
        async for chunk in response.body_iterator:
            body += chunk

        # Compress
        compressed_body = gzip.compress(body, compresslevel=self.config["level"])

        # Create new response
        headers = dict(response.headers)
        headers["Content-Encoding"] = "gzip"
        headers["Content-Length"] = str(len(compressed_body))

        # Remove original content-length if exists
        if "content-length" in headers:
            del headers["content-length"]

        return Response(
            content=compressed_body,
            status_code=response.status_code,
            headers=headers,
            media_type=response.media_type,
        )

    def _should_compress(self, response: Response) -> bool:
        """Check if response should be compressed."""
        # Check content type
        content_type = response.headers.get("content-type", "")
        if not content_type:
            return False

        # Check if content type should be compressed
        compressible_types = [
            "text/",
            "application/json",
            "application/javascript",
            "application/xml",
            "application/xhtml+xml",
        ]

        if not any(content_type.startswith(ct) for ct in compressible_types):
            return False

        # Check minimum size
        content_length = response.headers.get("content-length")
        if content_length:
            try:
                size = int(content_length)
                if size < self.config["min_size"]:
                    return False
            except ValueError:
                pass

        # Check if already compressed
        if response.headers.get("content-encoding"):
            return False

        return True


class CORSHandler:
    """CORS configuration handler."""

    @staticmethod
    def setup(app: FastAPI) -> None:
        """Setup CORS middleware."""
        config = get_config()

        app.add_middleware(
            CORSMiddleware,
            allow_origins=config.CORS_ORIGINS,
            allow_credentials=config.CORS_ALLOW_CREDENTIALS,
            allow_methods=config.CORS_ALLOW_METHODS,
            allow_headers=config.CORS_ALLOW_HEADERS,
        )


class MetricsMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: FastAPI) -> None:
        super().__init__(app)

        # Define metrics
        self.request_counter = Counter(
            "http_requests_total",
            "Total HTTP requests",
            ["method", "endpoint", "status"],
        )

        self.request_duration = Histogram(
            "http_request_duration_seconds",
            "HTTP request duration in seconds",
            ["method", "endpoint"],
            buckets=(0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10.0, 30.0),
        )

        self.request_in_progress = Gauge(
            "http_requests_in_progress",
            "HTTP requests currently in progress",
            ["method", "endpoint"],
        )

        self.request_size = Histogram(
            "http_request_size_bytes",
            "HTTP request size in bytes",
            ["method", "endpoint"],
            buckets=(100, 1000, 10000, 100000, 1000000),
        )

        self.response_size = Histogram(
            "http_response_size_bytes",
            "HTTP response size in bytes",
            ["method", "endpoint"],
            buckets=(100, 1000, 10000, 100000, 1000000),
        )

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Skip metrics for metrics endpoint
        if request.url.path == "/metrics":
            return await call_next(request)

        # Get endpoint name
        endpoint = self._get_endpoint_name(request)

        # Increment in-progress gauge
        self.request_in_progress.labels(method=request.method, endpoint=endpoint).inc()

        # Record request size
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                size = int(content_length)
                self.request_size.labels(
                    method=request.method, endpoint=endpoint
                ).observe(size)
            except ValueError:
                pass

        start_time = time.time()

        try:
            response = await call_next(request)

            # Calculate duration
            duration = time.time() - start_time

            # Record metrics
            self.request_duration.labels(
                method=request.method, endpoint=endpoint
            ).observe(duration)

            self.request_counter.labels(
                method=request.method, endpoint=endpoint, status=response.status_code
            ).inc()

            # Record response size
            content_length = response.headers.get("content-length")
            if content_length:
                try:
                    size = int(content_length)
                    self.response_size.labels(
                        method=request.method, endpoint=endpoint
                    ).observe(size)
                except ValueError:
                    pass

            return response

        finally:
            # Decrement in-progress gauge
            self.request_in_progress.labels(
                method=request.method, endpoint=endpoint
            ).dec()

    @staticmethod
    def _get_endpoint_name(request: Request) -> str:
        """Get endpoint name from request."""
        # Try to get route path
        if hasattr(request, "route") and hasattr(request.route, "path"):
            return request.route.path

        # Fall back to URL path
        return request.url.path


class SessionMiddleware(BaseHTTPMiddleware):
    """Middleware for session management."""

    def __init__(self, app: FastAPI, session_cookie_name: str = "session_id") -> None:
        super().__init__(app)
        self.session_cookie_name = session_cookie_name

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Get session ID from cookie
        session_id = request.cookies.get(self.session_cookie_name)

        if session_id:
            # Validate session (this would check Redis/database)
            # For now, just set it in request state
            request.state.session_id = session_id
            request.state.is_authenticated = True
        else:
            request.state.session_id = None
            request.state.is_authenticated = False

        response = await call_next(request)

        # You could set/update session cookie here if needed

        return response


class CacheControlMiddleware(BaseHTTPMiddleware):
    """Middleware to add cache control headers."""

    def __init__(self, app: FastAPI) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)

        # Add cache control headers for specific content types
        content_type = response.headers.get("content-type", "")

        if "application/json" in content_type:
            # API responses should not be cached by default
            response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
        elif "text/html" in content_type:
            # HTML pages can be cached for a short time
            response.headers["Cache-Control"] = "public, max-age=300"
        elif any(
            ct in content_type
            for ct in ["image/", "font/", "application/javascript", "text/css"]
        ):
            # Static assets can be cached longer
            response.headers["Cache-Control"] = "public, max-age=31536000"  # 1 year

        return response


class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware for consistent error handling."""

    def __init__(self, app: FastAPI) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        try:
            return await call_next(request)

        except Exception as e:
            # Log the error
            logger.error(
                "unhandled_exception",
                request_id=request_id_var.get(),
                method=request.method,
                url=str(request.url),
                error_type=type(e).__name__,
                error_message=str(e),
                exc_info=True,
            )

            # Return consistent error response
            error_data = {
                "error": "Internal server error",
                "message": "An unexpected error occurred",
                "request_id": request_id_var.get(),
                "timestamp": datetime.utcnow().isoformat(),
            }

            # Include error details in development
            if config.DEBUG:
                error_data["detail"] = str(e)
                error_data["type"] = type(e).__name__

            return Response(
                content=json.dumps(error_data),
                status_code=500,
                media_type="application/json",
            )


# Utility functions
def get_request_id() -> str | None:
    """Get current request ID from context."""
    return request_id_var.get()


def get_request_start_time() -> float | None:
    """Get request start time from context."""
    return start_time_var.get()


# FastAPI exception handlers setup
def setup_middleware(app: FastAPI) -> None:
    """
    Setup all middleware for FastAPI application.

    Args:
        app: FastAPI application instance
    """
    config = get_config()

    # Add middleware in order (first added, last executed)

    # 1. Request ID (first to run, last to cleanup)
    app.add_middleware(RequestIDMiddleware)

    # 2. Error handling (catch errors early)
    app.add_middleware(ErrorHandlingMiddleware)

    # 3. Logging
    app.add_middleware(LoggingMiddleware)

    # 4. Metrics
    if config.METRICS_ENABLED:
        app.add_middleware(MetricsMiddleware)

    # 5. Timeout
    app.add_middleware(TimeoutMiddleware, timeout=config.REQUEST_TIMEOUT)

    # 6. Compression
    if config.COMPRESSION_ENABLED:
        app.add_middleware(CompressionMiddleware)

    # 7. Security headers
    if config.SECURITY_HEADERS_ENABLED:
        app.add_middleware(SecurityHeadersMiddleware)

    # 8. Cache control
    app.add_middleware(CacheControlMiddleware)

    # 9. Session management (if needed)
    # app.add_middleware(SessionMiddleware)

    # 10. Rate limiting
    if config.RATE_LIMIT_ENABLED:
        from .rate_limiting import RateLimitMiddleware

        app.add_middleware(
            RateLimitMiddleware,
            limit=config.RATE_LIMIT_DEFAULT_LIMIT,
            window=config.RATE_LIMIT_DEFAULT_WINDOW,
            strategy=config.RATE_LIMIT_STRATEGY,
        )

    # 11. Audit logging
    if config.AUDIT_LOG_ENABLED:
        from .audit_logging import AuditLogMiddleware, get_audit_logger

        audit_logger = get_audit_logger()
        app.add_middleware(AuditLogMiddleware, audit_logger=audit_logger)

    # 12. CORS (should be one of the last middleware)
    CORSHandler.setup(app)

    logger.info("All middleware setup complete")
