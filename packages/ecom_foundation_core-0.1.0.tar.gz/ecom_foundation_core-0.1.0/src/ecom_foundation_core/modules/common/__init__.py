"""
Common utilities for e-com-foundation-core.

Keep this module lightweight: avoid importing optional/non-existent submodules at
import time (important for library use and test collection).
"""

from .audit_logging import AuditAction, audit_log
from .cache import CacheManager, async_cached, cache_manager, cached, get_cache
from .config import (
    CommonConfig,
    Settings,
    get_config,
    get_database_url,
    get_log_level,
    get_redis_url,
    get_secret_key,
    get_settings,
    is_development,
    is_production,
    is_staging,
    is_test,
    reload_config,
)
from .database import (
    Base,
    close_db,
    db_manager,
    get_async_session,
    get_engine,
    get_session_factory,
    init_db,
)
from .errors import AppError
from .middleware import setup_middleware
from .monitoring import monitor_operation, monitor_performance, setup_structured_logging
from .rate_limiting import RateLimiter, RateLimitExceeded, rate_limit, rate_limiter
from .redis_client import (
    RedisManager,
    close_redis,
    get_redis_client,
    init_redis,
    redis_manager,
)

__all__ = [
    "CommonConfig",
    "Settings",
    "get_config",
    "get_settings",
    "reload_config",
    "is_development",
    "is_production",
    "is_staging",
    "is_test",
    "get_log_level",
    "get_secret_key",
    "get_database_url",
    "get_redis_url",
    "Base",
    "get_async_session",
    "init_db",
    "close_db",
    "get_session_factory",
    "get_engine",
    "db_manager",
    "RedisManager",
    "get_redis_client",
    "init_redis",
    "close_redis",
    "redis_manager",
    "RateLimiter",
    "rate_limit",
    "RateLimitExceeded",
    "rate_limiter",
    "monitor_performance",
    "monitor_operation",
    "setup_structured_logging",
    "setup_middleware",
    "CacheManager",
    "get_cache",
    "cached",
    "async_cached",
    "cache_manager",
    "AppError",
    "AuditAction",
    "audit_log",
]

__version__ = "0.1.0"
