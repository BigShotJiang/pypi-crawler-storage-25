"""
Role-based access control (RBAC) schemas, services, and middlewares.
Models (Role, Permission, UserRole, RolePermission) live in auth.models.
"""

from .dependencies import require_permissions
from .schemas import PermissionBase, PermissionResponse, RoleBase, RoleResponse
from .service import RBACService

__all__ = [
    "RoleBase",
    "RoleResponse",
    "PermissionBase",
    "PermissionResponse",
    "RBACService",
    "require_permissions",
]
