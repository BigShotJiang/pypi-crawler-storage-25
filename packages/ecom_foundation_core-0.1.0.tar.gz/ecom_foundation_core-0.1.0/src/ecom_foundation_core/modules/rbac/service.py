import uuid

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from ecom_foundation_core.modules.auth.models import Role, User, UserRole


class RBACService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def user_has_permission(
        self, user_id: uuid.UUID, required_scope: str, required_action: str
    ) -> bool:
        """
        Verify if a user holds a permission directly or through a role.
        """
        result = await self.session.execute(
            select(User)
            .options(selectinload(User.roles).selectinload(Role.permissions))
            .where(User.id == user_id)
        )
        user = result.unique().scalar_one_or_none()
        if not user:
            return False

        if user.is_superuser:
            return True

        for role in user.roles:
            for permission in role.permissions:
                if (permission.scope == required_scope or permission.scope == "*") and (
                    permission.action == required_action or permission.action == "*"
                ):
                    return True
        return False

    async def assign_role_to_user(self, user_id: uuid.UUID, role_name: str) -> bool:
        """
        Assign a role to a user by name.
        """
        result = await self.session.execute(select(Role).where(Role.name == role_name))
        role = result.scalar_one_or_none()
        if not role:
            raise ValueError(f"Role {role_name} not found.")

        # Check if already assigned
        exists = await self.session.execute(
            select(UserRole).where(
                UserRole.user_id == user_id, UserRole.role_id == role.id
            )
        )
        if exists.scalar_one_or_none():
            return True  # already assigned

        user_role = UserRole(user_id=user_id, role_id=role.id)
        self.session.add(user_role)
        await self.session.commit()
        return True
