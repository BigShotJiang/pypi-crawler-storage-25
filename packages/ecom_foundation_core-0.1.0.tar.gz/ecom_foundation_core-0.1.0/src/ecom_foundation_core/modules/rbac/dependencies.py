from collections.abc import Callable

from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

# Depending on exact implementation of auth, we mock standard import
# usually something like get_current_user
from ecom_foundation_core.modules.auth.dependencies import get_current_active_user
from ecom_foundation_core.modules.auth.models import User
from ecom_foundation_core.modules.common.database import get_async_session

from .service import RBACService


def require_permissions(scope: str, action: str) -> Callable:
    """
    FastAPI dependency injection to lock down endpoints based on Role Permissions.
    Usage:
        @app.get("/items", dependencies=[Depends(require_permissions("items", "read"))])
    """

    async def permission_checker(
        current_user: User = Depends(get_current_active_user),
        session: AsyncSession = Depends(get_async_session),
    ) -> bool:
        rbac_service = RBACService(session)
        has_perm = await rbac_service.user_has_permission(
            user_id=current_user.id, required_scope=scope, required_action=action
        )

        if not has_perm:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have enough privileges to access this resource",
            )
        return True

    return permission_checker
