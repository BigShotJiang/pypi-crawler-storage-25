import uuid

from pydantic import BaseModel, ConfigDict


class PermissionBase(BaseModel):
    scope: str
    action: str
    resource: str | None = None
    description: str | None = None


class PermissionResponse(PermissionBase):
    id: uuid.UUID
    codename: str

    model_config = ConfigDict(from_attributes=True)


class RoleBase(BaseModel):
    name: str
    description: str | None = None
    is_default: bool = False


class RoleResponse(RoleBase):
    id: uuid.UUID
    is_system: bool
    permissions: list[PermissionResponse] = []

    model_config = ConfigDict(from_attributes=True)
