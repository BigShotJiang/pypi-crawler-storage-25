"""
Notification service layer.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any

import httpx

from ..common.config import get_settings

logger = logging.getLogger(__name__)


class NotificationService(ABC):
    """Abstract base class for notification services."""

    @abstractmethod
    async def send_email(
        self,
        to_email: str,
        subject: str,
        template_name: str,
        context: dict[str, Any],
    ) -> bool:
        """
        Send an email.

        Args:
            to_email: Recipient's email address.
            subject: Email subject.
            template_name: Name of the email template to use.
            context: Dictionary with context data for the template.

        Returns:
            True if the email was sent successfully, False otherwise.
        """
        raise NotImplementedError

    @abstractmethod
    async def send_sms(self, to_phone: str, message: str) -> bool:
        """
        Send an SMS.

        Args:
            to_phone: Recipient's phone number.
            message: The SMS message content.

        Returns:
            True if the SMS was sent successfully, False otherwise.
        """
        raise NotImplementedError


class LoggingNotificationService(NotificationService):
    """
    A concrete implementation of NotificationService that logs notifications
    to the console instead of sending them. Useful for development and testing.
    """

    async def send_email(
        self,
        to_email: str,
        subject: str,
        template_name: str,
        context: dict[str, Any],
    ) -> bool:
        """Logs the email content instead of sending it."""
        logger.info(
            "--- Sending Email ---"
            f"To: {to_email}"
            f"Subject: {subject}"
            f"Template: {template_name}"
            "--- Context ---"
            f"{context}"
            "---------------------"
        )
        return True

    async def send_sms(self, to_phone: str, message: str) -> bool:
        """Logs the SMS content instead of sending it."""
        logger.info(
            f"--- Sending SMS ---To: {to_phone}Message: {message}-------------------"
        )
        return True


class SendGridNotificationService(NotificationService):
    """Send emails via SendGrid Web API v3."""

    SENDGRID_URL = "https://api.sendgrid.com/v3/mail/send"

    def __init__(
        self,
        api_key: str,
        from_email: str,
        timeout_seconds: float = 10.0,
    ) -> None:
        self.api_key = api_key
        self.from_email = from_email
        self.timeout_seconds = timeout_seconds

    async def send_email(
        self,
        to_email: str,
        subject: str,
        template_name: str,
        context: dict[str, Any],
    ) -> bool:
        # Minimal implementation: send JSON as plaintext (no template rendering yet).
        # You can later map `template_name` to a SendGrid dynamic template id.
        content_value = f"template={template_name}\n\n{context}"

        payload = {
            "personalizations": [{"to": [{"email": to_email}], "subject": subject}],
            "from": {"email": self.from_email},
            "content": [{"type": "text/plain", "value": content_value}],
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            resp = await client.post(self.SENDGRID_URL, json=payload, headers=headers)

        # SendGrid returns 202 Accepted on success
        if resp.status_code == 202:
            return True

        logger.error(
            "SendGrid send_email failed",
            extra={
                "status_code": resp.status_code,
                "response_text": resp.text,
                "to_email": to_email,
                "template_name": template_name,
            },
        )
        return False

    async def send_sms(self, to_phone: str, message: str) -> bool:
        # Not supported by SendGrid.
        logger.warning("SendGridNotificationService.send_sms not implemented")
        return False


def build_sendgrid_service_from_settings() -> SendGridNotificationService | None:
    """Build SendGrid service if settings are present, else None."""
    s = get_settings()
    if not s.sendgrid_api_key or not s.sendgrid_from_email:
        return None
    return SendGridNotificationService(
        api_key=s.sendgrid_api_key, from_email=s.sendgrid_from_email
    )
