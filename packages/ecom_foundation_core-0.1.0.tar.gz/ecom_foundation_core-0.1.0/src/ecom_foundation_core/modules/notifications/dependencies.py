"""
Dependencies for the notification module.
"""

from typing import Annotated

from fastapi import Depends

from .service import (
    LoggingNotificationService,
    NotificationService,
    build_sendgrid_service_from_settings,
)


# In a real application, this could be more sophisticated,
# allowing the product application to register its own provider.
# For now, we use the logging service as the default.
def get_notification_service() -> NotificationService:
    """
    Dependency provider for the notification service.

    Returns:
        An instance of a NotificationService.
    """
    service = build_sendgrid_service_from_settings()
    if service:
        return service
    return LoggingNotificationService()


NotificationServiceDep = Annotated[
    NotificationService, Depends(get_notification_service)
]
