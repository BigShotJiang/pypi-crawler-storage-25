"""
Notifications module.
"""

from fastapi import FastAPI

from .dependencies import NotificationServiceDep, get_notification_service
from .service import NotificationService


def setup_notifications(app: FastAPI) -> None:
    """
    Setup for the notifications module.
    This function can be used to add notification-related routes,
    event listeners, etc.
    """
    # For example, you could add a test route:
    # from . import routes
    # app.include_router(routes.router, prefix="/notifications", tags=["notifications"])
    pass
