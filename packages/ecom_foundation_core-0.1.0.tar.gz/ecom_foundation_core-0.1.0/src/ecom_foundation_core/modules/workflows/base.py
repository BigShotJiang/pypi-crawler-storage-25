import logging
from typing import Any

from celery import Task

logger = logging.getLogger(__name__)


class BaseTask(Task):
    """
    Base Celery Task that provides database session lifecycle management
    and robust error handling.

    Inherit from this base class to ensure your tasks correctly manage
    async database operations.
    """

    abstract = True

    def on_failure(
        self, exc: Exception, task_id: str, args: Any, kwargs: Any, einfo: Any
    ) -> None:
        """Called when a task fails."""
        logger.error(
            f"Task {self.name} failed. Task ID: {task_id}. "
            f"Exception: {exc!r}. Args: {args}. Kwargs: {kwargs}",
            exc_info=exc,
        )
        super().on_failure(exc, task_id, args, kwargs, einfo)

    def on_success(self, retval: Any, task_id: str, args: Any, kwargs: Any) -> None:
        """Called upon successful execution."""
        logger.info(f"Task {self.name} completed successfully. Task ID: {task_id}.")
        super().on_success(retval, task_id, args, kwargs)
