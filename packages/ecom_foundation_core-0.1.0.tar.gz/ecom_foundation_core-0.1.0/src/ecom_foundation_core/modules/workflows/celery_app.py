import logging

from celery import Celery

from ecom_foundation_core.modules.common.config import get_settings

logger = logging.getLogger(__name__)

settings = get_settings()

celery_app = Celery(
    "ecom_foundation_core_workflows",
    broker=(
        str(settings.REDIS_URL) if settings.REDIS_URL else "redis://localhost:6379/0"
    ),
    backend=(
        str(settings.REDIS_URL) if settings.REDIS_URL else "redis://localhost:6379/0"
    ),
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    worker_prefetch_multiplier=1,  # Good for long-running tasks
    broker_connection_retry_on_startup=True,
)

logger.info("Workflows Celery app initialized.")
