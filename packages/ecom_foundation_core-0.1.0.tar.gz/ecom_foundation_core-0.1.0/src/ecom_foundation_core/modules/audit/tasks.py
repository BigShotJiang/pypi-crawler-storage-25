import asyncio
import logging
from typing import Any

from ecom_foundation_core.modules.common.database import db_manager, get_session_factory
from ecom_foundation_core.modules.workflows.base import BaseTask
from ecom_foundation_core.modules.workflows.celery_app import celery_app

from .models import AuditLog

logger = logging.getLogger(__name__)


async def _insert_audit_log(payload: dict[str, Any]) -> None:
    if not db_manager.is_initialized:
        await db_manager.initialize()

    session_factory = get_session_factory()
    async with session_factory() as session:
        audit_entry = AuditLog(**payload)
        session.add(audit_entry)
        try:
            await session.commit()
            logger.debug(
                f"Successfully recorded audit log for {payload.get('table_name')} "
                f"action {payload.get('action')}"
            )
        except Exception as e:
            await session.rollback()
            logger.error(f"Failed to record audit log: {e}")
            raise e


@celery_app.task(base=BaseTask, name="audit.record_change", bind=True, max_retries=3)
def record_audit_change(self: Any, payload: dict[str, Any]) -> None:
    """
    Celery background task to insert an audit log into the database without
    blocking the main event loops.
    """
    try:
        # Run the async DB insertion synchronously within the celery worker
        asyncio.run(_insert_audit_log(payload))
    except Exception as exc:
        logger.error(f"Audit tracking failed. Retrying... {exc}")
        self.retry(exc=exc, countdown=2**self.request.retries)
