from typing import Any

from sqlalchemy import Boolean
from sqlalchemy.orm import Mapped, mapped_column


class AuditableMixin:
    """
    Mixin for SQLAlchemy models that require deep audit trailing.
    Any model subclassing this will have its `_audit_exempt` attributes ignored,
    but everything else will be automatically relayed to `AuditLog`.
    """

    _audit_exempt = ["created_at", "updated_at"]

    # Optional marker to disable auditing dynamically
    audit_enabled: Mapped[bool] = mapped_column(
        Boolean, default=True, doc="Toggle auditing per record"
    )

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if "audit_enabled" not in kwargs:
            kwargs["audit_enabled"] = True
        super().__init__(*args, **kwargs)

    def get_audit_attributes(self) -> dict[str, Any]:
        """Returns a dict of auditable fields."""
        return {
            c.key: getattr(self, c.key)
            for c in self.__table__.columns
            if c.key not in self._audit_exempt
        }
