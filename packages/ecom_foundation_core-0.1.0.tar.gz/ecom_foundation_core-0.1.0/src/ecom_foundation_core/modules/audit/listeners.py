import logging
from typing import Any

from sqlalchemy import event
from sqlalchemy.orm import Mapper

from .tasks import record_audit_change

logger = logging.getLogger(__name__)


def _get_identity(target: Any) -> str:
    """Retrieve primary key safely."""
    for c in target.__table__.primary_key.columns:
        return str(getattr(target, c.key))
    return "UNKNOWN"


def _dispatch_audit_task(
    target: Any,
    action: str,
    old_values: dict[str, Any] | None = None,
    new_values: dict[str, Any] | None = None,
) -> None:
    if not getattr(target, "audit_enabled", True):
        return

    # In a real API context, you would inject the current user's ID via
    # thread-locals or context variables. Defaulting to SYSTEM for now.
    user_id = getattr(target, "_current_user_id", "SYSTEM")

    payload = {
        "table_name": target.__tablename__,
        "record_id": _get_identity(target),
        "action": action,
        "old_values": old_values,
        "new_values": new_values,
        "user_id": user_id,
    }

    try:
        record_audit_change.delay(payload)
    except Exception as e:
        logger.warning(f"Failed to push audit task to Celery: {e}")


def after_insert(mapper: Mapper, connection: Any, target: Any) -> None:
    new_values = (
        target.get_audit_attributes() if hasattr(target, "get_audit_attributes") else {}
    )
    _dispatch_audit_task(target, "INSERT", old_values=None, new_values=new_values)


def after_update(mapper: Mapper, connection: Any, target: Any) -> None:
    state = target._sa_instance_state

    old_values = {}
    new_values = {}

    for hist in state.unmodified:
        pass  # unmodified

    for attr in state.dict:
        if attr in getattr(target, "_audit_exempt", []):
            continue

        history = state.attrs[attr].history
        if history.has_changes():
            old_values[attr] = history.deleted[0] if history.deleted else None
            new_values[attr] = history.added[0] if history.added else None

    if old_values or new_values:
        _dispatch_audit_task(
            target, "UPDATE", old_values=old_values, new_values=new_values
        )


def after_delete(mapper: Mapper, connection: Any, target: Any) -> None:
    old_values = (
        target.get_audit_attributes() if hasattr(target, "get_audit_attributes") else {}
    )
    _dispatch_audit_task(target, "DELETE", old_values=old_values, new_values=None)


def setup_audit_listeners(BaseModel: Any) -> None:
    """
    Call this with your SQLAlchemy Base to attach the audit listeners
    to all models inherited from AuditableMixin.
    """
    from .mixins import AuditableMixin

    for mapper in BaseModel.registry.mappers:
        target_class = mapper.class_
        if issubclass(target_class, AuditableMixin):
            event.listen(target_class, "after_insert", after_insert)
            event.listen(target_class, "after_update", after_update)
            event.listen(target_class, "after_delete", after_delete)
