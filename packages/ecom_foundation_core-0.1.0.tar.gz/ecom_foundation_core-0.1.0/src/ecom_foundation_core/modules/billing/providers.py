from typing import Any

import httpx
import stripe


class PaymentProvider:
    """Abstract interface for payment gateways."""

    async def initialize_transaction(
        self, amount: int, currency: str, user_email: str, **kwargs: Any
    ) -> dict[str, Any]:
        """Should return dict containing 'checkout_url' and 'reference'"""
        raise NotImplementedError

    async def verify_transaction(self, reference: str) -> bool:
        """Should return True if payment was successful."""
        raise NotImplementedError


class PaystackProvider(PaymentProvider):
    def __init__(self, secret_key: str) -> None:
        self.secret_key = secret_key
        self.base_url = "https://api.paystack.co"

    async def initialize_transaction(
        self, amount: int, currency: str, user_email: str, **kwargs: Any
    ) -> dict[str, Any]:
        async with httpx.AsyncClient() as client:
            headers = {"Authorization": f"Bearer {self.secret_key}"}
            payload = {"email": user_email, "amount": amount, "currency": currency}
            # Add any additional optional args like callback_url
            payload.update(kwargs)

            response = await client.post(
                f"{self.base_url}/transaction/initialize", json=payload, headers=headers
            )
            response.raise_for_status()
            data = response.json()["data"]

            return {
                "checkout_url": data["authorization_url"],
                "reference": data["reference"],
            }

    async def verify_transaction(self, reference: str) -> bool:
        async with httpx.AsyncClient() as client:
            headers = {"Authorization": f"Bearer {self.secret_key}"}
            response = await client.get(
                f"{self.base_url}/transaction/verify/{reference}", headers=headers
            )
            if response.status_code != 200:
                return False

            data = response.json()["data"]
            return data["status"] == "success"


class StripeProvider(PaymentProvider):
    def __init__(self, secret_key: str) -> None:
        stripe.api_key = secret_key

    async def initialize_transaction(
        self, amount: int, currency: str, user_email: str, **kwargs: Any
    ) -> dict[str, Any]:
        # Stripe expects smallest currency unit, just like Paystack
        session = await stripe.checkout.Session.create_async(
            payment_method_types=["card"],
            customer_email=user_email,
            line_items=[
                {
                    "price_data": {
                        "currency": currency,
                        "product_data": {
                            "name": kwargs.get("product_name", "Service Payment"),
                        },
                        "unit_amount": amount,
                    },
                    "quantity": 1,
                }
            ],
            mode="payment",
            success_url=kwargs.get("success_url", "https://example.com/success"),
            cancel_url=kwargs.get("cancel_url", "https://example.com/cancel"),
        )

        return {"checkout_url": session.url, "reference": session.id}

    async def verify_transaction(self, reference: str) -> bool:
        session = await stripe.checkout.Session.retrieve_async(reference)
        return session.payment_status == "paid"
