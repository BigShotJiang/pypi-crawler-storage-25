import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from .models import Transaction, TransactionStatus
from .providers import PaymentProvider


class BillingService:
    def __init__(
        self, session: AsyncSession, provider: PaymentProvider, provider_name: str
    ) -> None:
        self.session = session
        self.provider = provider
        self.provider_name = provider_name

    async def create_checkout(
        self,
        user_id: uuid.UUID,
        email: str,
        amount: int,
        currency: str = "USD",
        **kwargs: Any,
    ) -> str:
        """
        Initializes a transaction with the payment provider, saves the pending
        status mapping, and returns the checkout URL.
        """
        result = await self.provider.initialize_transaction(
            amount, currency, email, **kwargs
        )

        tx = Transaction(
            user_id=user_id,
            amount=amount,
            currency=currency,
            provider=self.provider_name,
            provider_reference=result["reference"],
            status=TransactionStatus.PENDING,
        )
        self.session.add(tx)
        await self.session.commit()

        return result["checkout_url"]

    async def handle_webhook_verification(self, reference: str) -> bool:
        """
        Verifies the transaction via API once a webhook triggers.
        Returns True if successful and updates DB accordingly.
        """
        tx_result = await self.session.execute(
            select(Transaction).where(Transaction.provider_reference == reference)
        )
        tx = tx_result.scalar_one_or_none()

        if not tx:
            return False  # Security check: ignore ghost references

        is_success = await self.provider.verify_transaction(reference)

        if is_success:
            tx.status = TransactionStatus.SUCCESS
        else:
            tx.status = TransactionStatus.FAILED

        await self.session.commit()
        return is_success
