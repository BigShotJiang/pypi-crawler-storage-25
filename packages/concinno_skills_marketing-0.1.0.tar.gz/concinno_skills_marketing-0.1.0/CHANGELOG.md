# Changelog

All notable changes to `concinno-skills-marketing` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and the project adheres to Semantic Versioning.

## [0.1.0] - 2026-04-23

### Added

- Initial release. Marketing / email / form agent skills for the
  Concinno ecosystem. All three platforms are reached via `httpx`
  REST directly — zero vendor SDK dependencies, MIT-licensed.
- `MailchimpCampaign` tool — `list_campaigns` / `get_campaign` /
  `list_members` / `add_member` via Mailchimp Marketing API v3
  (`https://{dc}.api.mailchimp.com/3.0/`), HTTP Basic auth
  (`anystring:<api_key>`). Data-center prefix auto-parsed from the
  `-us21` / `-us1` style suffix on the API key when
  `mailchimp_dc` isn't set explicitly.
- `TypeformForm` tool — `get_form` / `list_responses` / `export_csv`
  via Typeform API (`https://api.typeform.com/`), Bearer-token auth.
  `export_csv` streams a CSV string capped at 1 MB of output.
- `SendGridSend` tool — `send` via SendGrid v3 Mail Send API
  (`POST https://api.sendgrid.com/v3/mail/send`), Bearer-token auth.
  Supports plain-text and HTML bodies, optional base64 attachments,
  and returns the `X-Message-Id` header verbatim.
- Credential helpers in `_auth.py` — `get_mailchimp_credentials()`
  returns `{api_key, dc}` (auto-parsing dc from the key suffix when
  needed), `get_typeform_token()` returns the Typeform personal
  access token, `get_sendgrid_api_key()` returns the SendGrid API
  key. Keys read from Concinno `CredentialStore`
  (`mailchimp_api_key` / `mailchimp_dc` / `typeform_token` /
  `sendgrid_api_key`) with env-var + disk JSON fallback. When the
  installed Concinno wheel omits `concinno.core.credentials`, a
  local env + disk store with identical semantics is used.
- Zero new runtime dependencies beyond `httpx>=0.27` and Concinno
  itself. MIT licence throughout — deliberately avoids the heavy
  transitive closure of the official Mailchimp / SendGrid SDKs.
