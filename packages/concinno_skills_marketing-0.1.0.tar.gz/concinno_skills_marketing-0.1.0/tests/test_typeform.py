"""Unit tests for concinno_skills_marketing.typeform.TypeformForm.

All tests mock ``httpx.Client`` — no network, no real Typeform token.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from concinno_skills_marketing import TypeformForm


class _FakeResponse:
    def __init__(
        self,
        *,
        status_code: int = 200,
        payload: Any = None,
        text: str = "",
    ) -> None:
        self.status_code = status_code
        self._payload = payload
        self.text = text

    def json(self) -> Any:
        return self._payload

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            import httpx

            raise httpx.HTTPStatusError(
                f"HTTP {self.status_code}",
                request=MagicMock(),
                response=self,  # type: ignore[arg-type]
            )


class _FakeClient:
    def __init__(
        self,
        *,
        get_return: _FakeResponse | None = None,
        get_raises: Exception | None = None,
    ) -> None:
        self.get_return = get_return or _FakeResponse(payload={})
        self.get_raises = get_raises
        self.calls: list[tuple[str, str, dict[str, Any]]] = []
        self.closed = False

    def get(self, url: str, **kw: Any) -> _FakeResponse:
        self.calls.append(("GET", url, kw))
        if self.get_raises is not None:
            raise self.get_raises
        return self.get_return

    def close(self) -> None:
        self.closed = True


def _patch_client(
    monkeypatch: pytest.MonkeyPatch, client: _FakeClient
) -> None:
    monkeypatch.setattr(
        "concinno_skills_marketing.typeform._build_client",
        lambda token: client,
    )


def _patch_token(
    monkeypatch: pytest.MonkeyPatch, token: str | None
) -> None:
    monkeypatch.setattr(
        "concinno_skills_marketing.typeform.get_typeform_token",
        lambda: token,
    )


# ── Protocol surface ───────────────────────────────────────────────────


def test_typeform_protocol_surface() -> None:
    assert TypeformForm.name == "typeform_form"
    assert TypeformForm.is_concurrency_safe is False
    assert "typeform" in TypeformForm.description.lower()


def test_invalid_action() -> None:
    out = TypeformForm().call(action="nope")
    assert "error" in out
    assert "get_form" in out["error"]


# ── No credentials ────────────────────────────────────────────────────


def test_no_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_token(monkeypatch, None)
    out = TypeformForm().call(action="get_form", form_id="abc")
    assert "error" in out
    assert "no Typeform credentials" in out["error"]


# ── get_form ──────────────────────────────────────────────────────────


def test_get_form_success(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_token(monkeypatch, "tok-123")
    client = _FakeClient(
        get_return=_FakeResponse(
            payload={
                "id": "u6nXL7",
                "title": "Customer survey",
                "fields": [
                    {"id": "q1", "type": "short_text", "ref": "name"},
                    {"id": "q2", "type": "email", "ref": "email"},
                ],
            }
        )
    )
    _patch_client(monkeypatch, client)
    out = TypeformForm().call(action="get_form", form_id="u6nXL7")
    assert out["ok"] is True
    assert out["data"]["id"] == "u6nXL7"
    assert out["data"]["title"] == "Customer survey"
    assert len(out["data"]["fields"]) == 2
    assert client.calls[0][0] == "GET"
    assert client.calls[0][1] == "/forms/u6nXL7"
    assert client.closed is True


def test_get_form_missing_id(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_token(monkeypatch, "tok-123")
    out = TypeformForm().call(action="get_form")
    assert "error" in out
    assert "form_id" in out["error"]


def test_get_form_api_error(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_token(monkeypatch, "tok-123")
    client = _FakeClient(
        get_return=_FakeResponse(
            status_code=404,
            payload={
                "code": "NOT_FOUND",
                "description": "Form not found",
            },
        )
    )
    _patch_client(monkeypatch, client)
    out = TypeformForm().call(action="get_form", form_id="missing")
    assert "error" in out
    assert "Typeform error 404" in out["error"]
    assert "Form not found" in out["error"]


# ── list_responses ────────────────────────────────────────────────────


def test_list_responses_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_token(monkeypatch, "tok-123")
    client = _FakeClient(
        get_return=_FakeResponse(
            payload={
                "total_items": 2,
                "page_count": 1,
                "items": [
                    {
                        "response_id": "r1",
                        "landed_at": "2026-01-01T00:00:00Z",
                        "submitted_at": "2026-01-01T00:01:00Z",
                        "answers": [
                            {
                                "field": {"ref": "name"},
                                "type": "text",
                                "text": "Alice",
                            }
                        ],
                    },
                    {
                        "response_id": "r2",
                        "landed_at": "2026-01-02T00:00:00Z",
                        "submitted_at": "2026-01-02T00:01:00Z",
                        "answers": [],
                    },
                ],
            }
        )
    )
    _patch_client(monkeypatch, client)
    out = TypeformForm().call(
        action="list_responses", form_id="u6nXL7", page_size=50
    )
    assert out["ok"] is True
    assert out["total"] == 2
    assert len(out["responses"]) == 2
    assert out["responses"][0]["response_id"] == "r1"
    assert client.calls[0][1] == "/forms/u6nXL7/responses"
    assert client.calls[0][2]["params"]["page_size"] == 50


def test_list_responses_page_size_clamped(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_token(monkeypatch, "tok-123")
    client = _FakeClient(
        get_return=_FakeResponse(payload={"items": [], "total_items": 0})
    )
    _patch_client(monkeypatch, client)
    TypeformForm().call(
        action="list_responses", form_id="u6nXL7", page_size=9999
    )
    assert client.calls[0][2]["params"]["page_size"] == 1000


def test_list_responses_missing_form_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_token(monkeypatch, "tok-123")
    out = TypeformForm().call(action="list_responses")
    assert "error" in out
    assert "form_id" in out["error"]


# ── export_csv ────────────────────────────────────────────────────────


def test_export_csv_success(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_token(monkeypatch, "tok-123")
    client = _FakeClient(
        get_return=_FakeResponse(
            payload={
                "total_items": 1,
                "items": [
                    {
                        "response_id": "r1",
                        "landed_at": "2026-01-01T00:00:00Z",
                        "submitted_at": "2026-01-01T00:01:00Z",
                        "answers": [
                            {
                                "field": {"ref": "name"},
                                "type": "text",
                                "text": "Alice",
                            },
                            {
                                "field": {"ref": "email"},
                                "type": "email",
                                "email": "alice@x.com",
                            },
                        ],
                    }
                ],
            }
        )
    )
    _patch_client(monkeypatch, client)
    out = TypeformForm().call(
        action="export_csv", form_id="u6nXL7", page_size=100
    )
    assert out["ok"] is True
    assert out["total"] == 1
    assert "response_id" in out["csv"]
    assert "name" in out["csv"]
    assert "email" in out["csv"]
    assert "Alice" in out["csv"]
    assert "alice@x.com" in out["csv"]


def test_export_csv_missing_form_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_token(monkeypatch, "tok-123")
    out = TypeformForm().call(action="export_csv")
    assert "error" in out
    assert "form_id" in out["error"]


def test_export_csv_empty_items(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_token(monkeypatch, "tok-123")
    client = _FakeClient(
        get_return=_FakeResponse(
            payload={"items": [], "total_items": 0}
        )
    )
    _patch_client(monkeypatch, client)
    out = TypeformForm().call(action="export_csv", form_id="u6nXL7")
    assert out["ok"] is True
    # Header row still emitted even on empty.
    assert "response_id" in out["csv"]


def test_export_csv_api_error(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_token(monkeypatch, "tok-123")
    client = _FakeClient(
        get_return=_FakeResponse(
            status_code=401,
            payload={
                "code": "AUTHENTICATION_FAILED",
                "description": "Token is invalid",
            },
        )
    )
    _patch_client(monkeypatch, client)
    out = TypeformForm().call(action="export_csv", form_id="u6nXL7")
    assert "error" in out
    assert "Typeform error 401" in out["error"]
    assert "Token is invalid" in out["error"]


def test_list_responses_generic_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_token(monkeypatch, "tok-123")
    client = _FakeClient(get_raises=RuntimeError("dns down"))
    _patch_client(monkeypatch, client)
    out = TypeformForm().call(
        action="list_responses", form_id="u6nXL7"
    )
    assert "error" in out
    assert "dns down" in out["error"]
