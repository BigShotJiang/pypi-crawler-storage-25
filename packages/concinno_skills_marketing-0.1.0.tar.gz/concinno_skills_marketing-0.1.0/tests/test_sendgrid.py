"""Unit tests for concinno_skills_marketing.sendgrid_tool.SendGridSend.

All tests mock ``httpx.Client`` — no network, no real SendGrid key.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from concinno_skills_marketing import SendGridSend


class _FakeHeaders:
    """Minimal case-insensitive headers stand-in."""

    def __init__(self, data: dict[str, str]) -> None:
        # Store lowercase for cheap .get lookups.
        self._data = {k.lower(): v for k, v in data.items()}

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key.lower(), default)

    def items(self) -> list[tuple[str, str]]:
        return list(self._data.items())


class _FakeResponse:
    def __init__(
        self,
        *,
        status_code: int = 202,
        payload: Any = None,
        text: str = "",
        headers: dict[str, str] | None = None,
    ) -> None:
        self.status_code = status_code
        self._payload = payload
        self.text = text
        self.headers = _FakeHeaders(headers or {})

    def json(self) -> Any:
        return self._payload

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            import httpx

            raise httpx.HTTPStatusError(
                f"HTTP {self.status_code}",
                request=MagicMock(),
                response=self,  # type: ignore[arg-type]
            )


class _FakeClient:
    def __init__(
        self,
        *,
        post_return: _FakeResponse | None = None,
        post_raises: Exception | None = None,
    ) -> None:
        self.post_return = post_return or _FakeResponse(
            payload={}, headers={"X-Message-Id": "msg-default"}
        )
        self.post_raises = post_raises
        self.calls: list[tuple[str, str, dict[str, Any]]] = []
        self.closed = False

    def post(self, url: str, **kw: Any) -> _FakeResponse:
        self.calls.append(("POST", url, kw))
        if self.post_raises is not None:
            raise self.post_raises
        return self.post_return

    def close(self) -> None:
        self.closed = True


def _patch_client(
    monkeypatch: pytest.MonkeyPatch, client: _FakeClient
) -> None:
    monkeypatch.setattr(
        "concinno_skills_marketing.sendgrid_tool._build_client",
        lambda api_key: client,
    )


def _patch_key(
    monkeypatch: pytest.MonkeyPatch, api_key: str | None
) -> None:
    monkeypatch.setattr(
        "concinno_skills_marketing.sendgrid_tool.get_sendgrid_api_key",
        lambda: api_key,
    )


# ── Protocol surface ───────────────────────────────────────────────────


def test_sendgrid_protocol_surface() -> None:
    assert SendGridSend.name == "sendgrid_send"
    assert SendGridSend.is_concurrency_safe is False
    assert "sendgrid" in SendGridSend.description.lower()


def test_invalid_action() -> None:
    out = SendGridSend().call(action="nope")
    assert "error" in out
    assert "send" in out["error"]


# ── No credentials ────────────────────────────────────────────────────


def test_no_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_key(monkeypatch, None)
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
        body="hi",
    )
    assert "error" in out
    assert "no SendGrid credentials" in out["error"]


# ── send happy paths ──────────────────────────────────────────────────


def test_send_success_simple(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    client = _FakeClient(
        post_return=_FakeResponse(
            status_code=202,
            payload=None,
            headers={"X-Message-Id": "abc-123-xyz"},
        )
    )
    _patch_client(monkeypatch, client)
    out = SendGridSend().call(
        action="send",
        to="user@example.com",
        from_email="noreply@acme.com",
        subject="Welcome!",
        body="Thanks for signing up.",
    )
    assert out == {"ok": True, "message_id": "abc-123-xyz"}
    call = client.calls[0]
    assert call[0] == "POST"
    assert call[1] == "https://api.sendgrid.com/v3/mail/send"
    body = call[2]["json"]
    assert body["personalizations"][0]["to"] == [
        {"email": "user@example.com"}
    ]
    assert body["from"]["email"] == "noreply@acme.com"
    assert body["subject"] == "Welcome!"
    assert body["content"][0]["type"] == "text/plain"
    assert body["content"][0]["value"] == "Thanks for signing up."
    assert client.closed is True


def test_send_multiple_recipients(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    client = _FakeClient(
        post_return=_FakeResponse(
            status_code=202,
            headers={"X-Message-Id": "multi-1"},
        )
    )
    _patch_client(monkeypatch, client)
    out = SendGridSend().call(
        action="send",
        to=["a@x.com", "b@x.com"],
        from_email="me@x.com",
        subject="hi",
        body="hi",
    )
    assert out["ok"] is True
    to_list = client.calls[0][2]["json"]["personalizations"][0]["to"]
    assert to_list == [{"email": "a@x.com"}, {"email": "b@x.com"}]


def test_send_html_body(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    client = _FakeClient(
        post_return=_FakeResponse(
            status_code=202, headers={"X-Message-Id": "html-1"}
        )
    )
    _patch_client(monkeypatch, client)
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
        body="<b>hi</b>",
        is_html=True,
    )
    assert out["ok"] is True
    content = client.calls[0][2]["json"]["content"][0]
    assert content["type"] == "text/html"
    assert content["value"] == "<b>hi</b>"


def test_send_with_named_recipient_dict(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    client = _FakeClient(
        post_return=_FakeResponse(
            status_code=202, headers={"X-Message-Id": "named-1"}
        )
    )
    _patch_client(monkeypatch, client)
    out = SendGridSend().call(
        action="send",
        to=[{"email": "a@x.com", "name": "Alice"}],
        from_email="me@x.com",
        subject="hi",
        body="hi",
    )
    assert out["ok"] is True
    to_entry = client.calls[0][2]["json"]["personalizations"][0]["to"][0]
    assert to_entry == {"email": "a@x.com", "name": "Alice"}


def test_send_with_attachment(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    client = _FakeClient(
        post_return=_FakeResponse(
            status_code=202, headers={"X-Message-Id": "att-1"}
        )
    )
    _patch_client(monkeypatch, client)
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
        body="hi",
        attachments=[
            {
                "content": "dGVzdA==",
                "filename": "note.txt",
                "type": "text/plain",
            }
        ],
    )
    assert out["ok"] is True
    atts = client.calls[0][2]["json"]["attachments"]
    assert atts[0]["filename"] == "note.txt"


# ── validation errors ─────────────────────────────────────────────────


def test_send_bad_to(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    out = SendGridSend().call(
        action="send",
        to="not-an-email",
        from_email="me@x.com",
        subject="hi",
        body="hi",
    )
    assert "error" in out
    assert "to=" in out["error"]


def test_send_bad_from(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="not-an-email",
        subject="hi",
        body="hi",
    )
    assert "error" in out
    assert "from_email" in out["error"]


def test_send_missing_subject(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        body="hi",
    )
    assert "error" in out
    assert "subject" in out["error"]


def test_send_missing_body(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
    )
    assert "error" in out
    assert "body" in out["error"]


def test_send_body_cap(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
        body="x" * 1_000_001,
    )
    assert "error" in out
    assert "1000000-char cap" in out["error"]


def test_send_bad_attachment_shape(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
        body="hi",
        attachments=[{"content": "xyz"}],  # missing filename
    )
    assert "error" in out
    assert "attachment" in out["error"]


def test_send_api_error_wrapped(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    client = _FakeClient(
        post_return=_FakeResponse(
            status_code=401,
            payload={
                "errors": [
                    {
                        "message": "Permission denied",
                        "field": None,
                    }
                ]
            },
        )
    )
    _patch_client(monkeypatch, client)
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
        body="hi",
    )
    assert "error" in out
    assert "SendGrid error 401" in out["error"]
    assert "Permission denied" in out["error"]


def test_send_generic_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_key(monkeypatch, "SG.testkey")
    client = _FakeClient(post_raises=RuntimeError("socket dead"))
    _patch_client(monkeypatch, client)
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
        body="hi",
    )
    assert "error" in out
    assert "socket dead" in out["error"]


def test_send_empty_message_id_header(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``X-Message-Id`` absent → still OK, empty string."""
    _patch_key(monkeypatch, "SG.testkey")
    client = _FakeClient(
        post_return=_FakeResponse(status_code=202, headers={})
    )
    _patch_client(monkeypatch, client)
    out = SendGridSend().call(
        action="send",
        to="u@x.com",
        from_email="me@x.com",
        subject="hi",
        body="hi",
    )
    assert out == {"ok": True, "message_id": ""}
