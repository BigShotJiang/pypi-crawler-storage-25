"""Unit tests for concinno_skills_marketing.mailchimp.MailchimpCampaign.

All tests mock ``httpx.Client`` — no network, no real Mailchimp keys.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from concinno_skills_marketing import MailchimpCampaign


class _FakeResponse:
    def __init__(
        self,
        *,
        status_code: int = 200,
        payload: Any = None,
        text: str = "",
    ) -> None:
        self.status_code = status_code
        self._payload = payload
        self.text = text

    def json(self) -> Any:
        return self._payload

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            import httpx

            raise httpx.HTTPStatusError(
                f"HTTP {self.status_code}",
                request=MagicMock(),
                response=self,  # type: ignore[arg-type]
            )


class _FakeClient:
    def __init__(
        self,
        *,
        get_return: _FakeResponse | None = None,
        put_return: _FakeResponse | None = None,
        get_raises: Exception | None = None,
        put_raises: Exception | None = None,
    ) -> None:
        self.get_return = get_return or _FakeResponse(payload={})
        self.put_return = put_return or _FakeResponse(payload={})
        self.get_raises = get_raises
        self.put_raises = put_raises
        self.calls: list[tuple[str, str, dict[str, Any]]] = []
        self.closed = False

    def get(self, url: str, **kw: Any) -> _FakeResponse:
        self.calls.append(("GET", url, kw))
        if self.get_raises is not None:
            raise self.get_raises
        return self.get_return

    def put(self, url: str, **kw: Any) -> _FakeResponse:
        self.calls.append(("PUT", url, kw))
        if self.put_raises is not None:
            raise self.put_raises
        return self.put_return

    def close(self) -> None:
        self.closed = True


def _patch_client(
    monkeypatch: pytest.MonkeyPatch, client: _FakeClient
) -> None:
    monkeypatch.setattr(
        "concinno_skills_marketing.mailchimp._build_client",
        lambda creds: client,
    )


def _patch_creds(
    monkeypatch: pytest.MonkeyPatch, creds: dict[str, str] | None
) -> None:
    monkeypatch.setattr(
        "concinno_skills_marketing.mailchimp.get_mailchimp_credentials",
        lambda: creds,
    )


# ── Protocol surface ───────────────────────────────────────────────────


def test_mailchimp_protocol_surface() -> None:
    assert MailchimpCampaign.name == "mailchimp_campaign"
    assert MailchimpCampaign.is_concurrency_safe is False
    assert "mailchimp" in MailchimpCampaign.description.lower()


def test_invalid_action() -> None:
    out = MailchimpCampaign().call(action="nope")
    assert "error" in out
    assert "list_campaigns" in out["error"]


def test_missing_action() -> None:
    out = MailchimpCampaign().call()
    assert "error" in out
    assert "list_campaigns" in out["error"]


# ── No credentials ────────────────────────────────────────────────────


def test_no_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_creds(monkeypatch, None)
    out = MailchimpCampaign().call(action="list_campaigns")
    assert "error" in out
    assert "no Mailchimp credentials" in out["error"]
    assert "mailchimp_api_key" in out["error"]


# ── list_campaigns ────────────────────────────────────────────────────


def test_list_campaigns_success(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    client = _FakeClient(
        get_return=_FakeResponse(
            payload={
                "campaigns": [
                    {
                        "id": "c1",
                        "web_id": 1,
                        "status": "sent",
                        "settings": {"title": "Welcome"},
                    },
                    {
                        "id": "c2",
                        "web_id": 2,
                        "status": "draft",
                        "settings": {"title": "Promo"},
                    },
                ],
                "total_items": 2,
            }
        )
    )
    _patch_client(monkeypatch, client)

    out = MailchimpCampaign().call(action="list_campaigns", limit=50)
    assert out["ok"] is True
    assert out["data"]["total_items"] == 2
    titles = [c["title"] for c in out["data"]["campaigns"]]
    assert titles == ["Welcome", "Promo"]
    assert client.calls[0][0] == "GET"
    assert client.calls[0][1] == "/campaigns"
    assert client.calls[0][2]["params"]["count"] == 50
    assert client.closed is True


def test_list_campaigns_limit_clamped(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us1", "dc": "us1"})
    client = _FakeClient(
        get_return=_FakeResponse(
            payload={"campaigns": [], "total_items": 0}
        )
    )
    _patch_client(monkeypatch, client)
    MailchimpCampaign().call(action="list_campaigns", limit=9999)
    assert client.calls[0][2]["params"]["count"] == 1000


def test_list_campaigns_api_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us2", "dc": "us2"})
    client = _FakeClient(
        get_return=_FakeResponse(
            status_code=401,
            payload={
                "type": "about:blank",
                "title": "API Key Invalid",
                "status": 401,
                "detail": "Your API key may be invalid",
            },
        )
    )
    _patch_client(monkeypatch, client)
    out = MailchimpCampaign().call(action="list_campaigns")
    assert "error" in out
    assert "Mailchimp error 401" in out["error"]
    assert "Your API key may be invalid" in out["error"]


# ── get_campaign ──────────────────────────────────────────────────────


def test_get_campaign_success(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    client = _FakeClient(
        get_return=_FakeResponse(
            payload={
                "id": "abc",
                "status": "sent",
                "type": "regular",
                "settings": {"title": "Newsletter", "subject_line": "Hi"},
            }
        )
    )
    _patch_client(monkeypatch, client)
    out = MailchimpCampaign().call(action="get_campaign", campaign_id="abc")
    assert out["ok"] is True
    assert out["data"]["id"] == "abc"
    assert out["data"]["settings"]["title"] == "Newsletter"
    assert client.calls[0][1] == "/campaigns/abc"


def test_get_campaign_missing_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    out = MailchimpCampaign().call(action="get_campaign")
    assert "error" in out
    assert "campaign_id" in out["error"]


# ── list_members ──────────────────────────────────────────────────────


def test_list_members_success(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    client = _FakeClient(
        get_return=_FakeResponse(
            payload={
                "members": [
                    {
                        "id": "m1",
                        "email_address": "a@x.com",
                        "status": "subscribed",
                    },
                    {
                        "id": "m2",
                        "email_address": "b@x.com",
                        "status": "unsubscribed",
                    },
                ],
                "total_items": 2,
            }
        )
    )
    _patch_client(monkeypatch, client)
    out = MailchimpCampaign().call(
        action="list_members", list_id="list-abc", limit=10
    )
    assert out["ok"] is True
    assert out["data"]["list_id"] == "list-abc"
    assert len(out["data"]["members"]) == 2
    assert client.calls[0][1] == "/lists/list-abc/members"
    assert client.calls[0][2]["params"]["count"] == 10


def test_list_members_missing_list_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    out = MailchimpCampaign().call(action="list_members")
    assert "error" in out
    assert "list_id" in out["error"]


# ── add_member ────────────────────────────────────────────────────────


def test_add_member_success(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    client = _FakeClient(
        put_return=_FakeResponse(
            payload={
                "id": "hash123",
                "email_address": "new@x.com",
                "status": "subscribed",
            }
        )
    )
    _patch_client(monkeypatch, client)
    out = MailchimpCampaign().call(
        action="add_member",
        list_id="list-abc",
        email_address="new@x.com",
        status="subscribed",
    )
    assert out["ok"] is True
    assert out["data"]["email_address"] == "new@x.com"
    # PUT = idempotent upsert at /lists/{id}/members/{subscriber_hash}.
    call = client.calls[0]
    assert call[0] == "PUT"
    assert call[1].startswith("/lists/list-abc/members/")
    assert call[2]["json"]["email_address"] == "new@x.com"
    assert call[2]["json"]["status"] == "subscribed"


def test_add_member_bad_status(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    out = MailchimpCampaign().call(
        action="add_member",
        list_id="list-abc",
        email_address="user@x.com",
        status="maybe",
    )
    assert "error" in out
    assert "status" in out["error"]


def test_add_member_bad_email(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    out = MailchimpCampaign().call(
        action="add_member",
        list_id="list-abc",
        email_address="not-an-email",
    )
    assert "error" in out
    assert "email_address" in out["error"]


def test_add_member_missing_list_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    out = MailchimpCampaign().call(
        action="add_member", email_address="user@x.com"
    )
    assert "error" in out
    assert "list_id" in out["error"]


def test_add_member_generic_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_creds(monkeypatch, {"api_key": "k-us21", "dc": "us21"})
    client = _FakeClient(put_raises=RuntimeError("network boom"))
    _patch_client(monkeypatch, client)
    out = MailchimpCampaign().call(
        action="add_member",
        list_id="list-abc",
        email_address="user@x.com",
    )
    assert "error" in out
    assert "network boom" in out["error"]


# ── _auth dc auto-parse ───────────────────────────────────────────────


def test_auth_parses_dc_from_key_suffix(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``mailchimp_api_key`` ending in ``-us21`` auto-resolves dc."""
    from concinno_skills_marketing import _auth as auth_mod

    class _StubStore:
        def __init__(self, data: dict[str, Any]) -> None:
            self.data = data

        def get(self, key: str, default: Any = None) -> Any:
            return self.data.get(key, default)

    store = _StubStore({"mailchimp_api_key": "abcdef1234567890-us21"})
    creds = auth_mod.get_mailchimp_credentials(store=store)  # type: ignore[arg-type]
    assert creds == {"api_key": "abcdef1234567890-us21", "dc": "us21"}


def test_auth_missing_dc_no_suffix_returns_none() -> None:
    """A key without a ``-<dc>`` tail + no explicit dc → None."""
    from concinno_skills_marketing import _auth as auth_mod

    class _StubStore:
        def __init__(self, data: dict[str, Any]) -> None:
            self.data = data

        def get(self, key: str, default: Any = None) -> Any:
            return self.data.get(key, default)

    store = _StubStore({"mailchimp_api_key": "opaque-oauth-token"})
    creds = auth_mod.get_mailchimp_credentials(store=store)  # type: ignore[arg-type]
    assert creds is None


def test_auth_explicit_dc_overrides_suffix() -> None:
    from concinno_skills_marketing import _auth as auth_mod

    class _StubStore:
        def __init__(self, data: dict[str, Any]) -> None:
            self.data = data

        def get(self, key: str, default: Any = None) -> Any:
            return self.data.get(key, default)

    store = _StubStore(
        {
            "mailchimp_api_key": "abcdef-us21",
            "mailchimp_dc": "eu1",
        }
    )
    creds = auth_mod.get_mailchimp_credentials(store=store)  # type: ignore[arg-type]
    assert creds == {"api_key": "abcdef-us21", "dc": "eu1"}
