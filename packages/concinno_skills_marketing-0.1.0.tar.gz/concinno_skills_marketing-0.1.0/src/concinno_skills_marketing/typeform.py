"""concinno_skills_marketing.typeform — TypeformForm Concinno Tool.

@module typeform
@responsibility Implement the Concinno Tool protocol for Typeform's
    public REST surface at ``https://api.typeform.com/``. Supports
    reading a form definition, listing responses, and exporting
    responses as CSV.
@dependencies httpx (declared dep), concinno_skills_marketing._auth
@exports TypeformForm

Concurrency note
----------------
``is_concurrency_safe = False``. Typeform applies tenant-scoped rate
limits on the Responses API and CSV export can amplify bandwidth
pressure; serial execution is the safe default.
"""

from __future__ import annotations

import contextlib
import csv
import io
import json
import logging
from typing import Any

from concinno_skills_marketing._auth import get_typeform_token

logger = logging.getLogger("concinno_skills_marketing.typeform")

_VALID_ACTIONS = frozenset({"get_form", "list_responses", "export_csv"})
# Typeform documents page_size max 1000; default 25.
_PAGE_CAP = 1000
# Cap export_csv output at 1 MB to avoid runaway payloads.
_CSV_OUTPUT_CAP = 1_000_000
# Return only the first 20 responses' full payload on list_responses to
# keep tool output small; full pagination is left to callers.
_LIST_RESPONSE_CAP = 20
_TYPEFORM_BASE = "https://api.typeform.com"
_SETUP_HINT = (
    "no Typeform credentials — set via CredentialStore "
    "(key: typeform_token) or env CONCINNO_CRED_TYPEFORM_TOKEN"
)


def _http_error_to_dict(exc: Exception) -> dict[str, Any]:
    """Wrap an :class:`httpx.HTTPStatusError` into a stable dict."""
    status = "?"
    body: Any = ""
    response = getattr(exc, "response", None)
    if response is not None:
        status = str(getattr(response, "status_code", "?"))
        try:
            body = response.json()
        except Exception:  # noqa: BLE001
            try:
                body = response.text
            except Exception:  # noqa: BLE001
                body = ""
    # Typeform errors: {"code": "...", "description": "..."}.
    msg = ""
    if isinstance(body, dict):
        msg = str(
            body.get("description")
            or body.get("message")
            or body.get("code")
            or ""
        )
        if not msg:
            msg = json.dumps(body)[:400]
    else:
        msg = str(body)[:400] if body else str(exc)
    return {"error": f"Typeform error {status}: {msg}"}


def _build_client(token: str) -> Any:
    """Return a configured ``httpx.Client`` for Typeform REST."""
    import httpx

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }
    return httpx.Client(
        base_url=_TYPEFORM_BASE, headers=headers, timeout=30.0
    )


def _clamp_limit(raw: Any, default: int, hi: int) -> int:
    try:
        val = int(raw)
    except (TypeError, ValueError):
        return default
    return max(1, min(val, hi))


def _trim_response(r: dict[str, Any]) -> dict[str, Any]:
    """Project a Typeform response record to a small stable shape."""
    return {
        "response_id": r.get("response_id"),
        "landed_at": r.get("landed_at", ""),
        "submitted_at": r.get("submitted_at", ""),
        "answers": r.get("answers", []),
    }


def _answer_ref(ans: dict[str, Any]) -> str | None:
    """Return the ``field.ref`` for a Typeform answer record."""
    field = ans.get("field") or {}
    ref = field.get("ref") if isinstance(field, dict) else None
    return ref if isinstance(ref, str) and ref else None


def _answer_value(ans: dict[str, Any]) -> str:
    """Flatten a Typeform answer record to a scalar string."""
    for key in (
        "text", "email", "phone_number", "number",
        "boolean", "url", "date",
    ):
        v = ans.get(key)
        if v is not None:
            return str(v)
    choice = ans.get("choice")
    if isinstance(choice, dict):
        label = choice.get("label", "")
        return str(label) if label is not None else ""
    if isinstance(choice, str):
        return choice
    return ""


def _collect_dynamic_cols(items: list[Any]) -> list[str]:
    """Discover the union of answer ``field.ref`` across items."""
    cols: list[str] = []
    seen: set[str] = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        for ans in item.get("answers", []) or []:
            if not isinstance(ans, dict):
                continue
            ref = _answer_ref(ans)
            if ref is not None and ref not in seen:
                seen.add(ref)
                cols.append(ref)
    return cols


def _build_csv(items: list[Any]) -> tuple[str, bool]:
    """Render ``items`` as a CSV string.

    Returns ``(csv_str, truncated)``. The result is truncated at
    ``_CSV_OUTPUT_CAP`` bytes to avoid runaway payloads.
    """
    core_cols = ["response_id", "landed_at", "submitted_at"]
    dynamic_cols = _collect_dynamic_cols(items)

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(core_cols + dynamic_cols)

    for item in items:
        if not isinstance(item, dict):
            continue
        row = [
            str(item.get("response_id", "")),
            str(item.get("landed_at", "")),
            str(item.get("submitted_at", "")),
        ]
        ans_by_ref: dict[str, str] = {}
        for ans in item.get("answers", []) or []:
            if not isinstance(ans, dict):
                continue
            ref = _answer_ref(ans)
            if ref is None:
                continue
            ans_by_ref[ref] = _answer_value(ans)
        for col in dynamic_cols:
            row.append(ans_by_ref.get(col, ""))
        writer.writerow(row)
        if buf.tell() >= _CSV_OUTPUT_CAP:
            break

    csv_str = buf.getvalue()
    truncated = False
    if len(csv_str) > _CSV_OUTPUT_CAP:
        csv_str = csv_str[:_CSV_OUTPUT_CAP]
        truncated = True
    return csv_str, truncated


class TypeformForm:
    """Read a form definition, list responses, or export responses as CSV.

    Params accepted via ``call(**kwargs)``:
        action (str):     ``"get_form"`` | ``"list_responses"`` |
                          ``"export_csv"``.
        form_id (str):    Typeform form id (the short token you see in
                          the form URL, e.g. ``u6nXL7``). Required for
                          all three actions.
        page_size (int):  for list / export — Typeform per-page cap;
                          default 25, max 1000.

    Returns:
        - ``get_form`` → ``{"ok": True, "data":
          {"id","title","fields": [...]}}``
        - ``list_responses`` → ``{"ok": True, "total": N,
          "responses": [<=20 trimmed records]}``
        - ``export_csv`` → ``{"ok": True, "total": N,
          "csv": "<csv-string truncated at 1MB>"}``
        - on failure → ``{"error": "..."}``
    """

    name: str = "typeform_form"
    description: str = (
        "Typeform form + responses read via REST. Params: action "
        "(get_form|list_responses|export_csv); "
        "all actions: form_id; "
        "list_responses/export_csv: page_size (default 25, max 1000). "
        "Returns {'ok': True, 'data'|'responses'|'csv': ...} "
        "or {'error': ...}."
    )
    # Tenant-scoped rate limits + CSV bandwidth → serial.
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {
                "error": (
                    "action must be get_form|list_responses|export_csv, "
                    f"got {action!r}"
                )
            }

        token = get_typeform_token()
        if token is None:
            return {"error": _SETUP_HINT}

        try:
            import httpx  # noqa: F401 — surfaced below if missing
        except ImportError as exc:
            return {
                "error": (
                    f"httpx not installed: {exc}. "
                    "Run: pip install concinno-skills-marketing"
                )
            }

        try:
            client = _build_client(token)
        except Exception as exc:  # noqa: BLE001
            logger.warning("typeform: client build failed: %s", exc)
            return {"error": f"Typeform client init failed: {exc}"}

        try:
            if action == "get_form":
                return self._get_form(client, **kwargs)
            if action == "list_responses":
                return self._list_responses(client, **kwargs)
            # action == "export_csv" — guarded above.
            return self._export_csv(client, **kwargs)
        finally:
            # Defensive: some mocked httpx clients may raise on close.
            with contextlib.suppress(Exception):
                client.close()

    # ── get_form ──────────────────────────────────────────────────────

    def _get_form(self, client: Any, **kwargs: Any) -> Any:
        form_id = kwargs.get("form_id")
        if not isinstance(form_id, str) or not form_id:
            return {
                "error": "get_form requires form_id=str (non-empty)"
            }

        import httpx

        try:
            resp = client.get(f"/forms/{form_id}")
            if resp.status_code >= 400:
                return _http_error_to_dict(
                    httpx.HTTPStatusError(
                        f"HTTP {resp.status_code}",
                        request=None,  # type: ignore[arg-type]
                        response=resp,
                    )
                )
            raw = resp.json()
        except httpx.HTTPStatusError as exc:
            return _http_error_to_dict(exc)
        except Exception as exc:  # noqa: BLE001
            logger.warning("typeform.get_form: %s", exc)
            return {"error": f"Typeform get_form failed: {exc}"}

        if not isinstance(raw, dict):
            return {"error": "Typeform get_form: non-dict payload"}
        return {
            "ok": True,
            "data": {
                "id": raw.get("id", form_id),
                "title": raw.get("title", ""),
                "fields": raw.get("fields", []),
            },
        }

    # ── list_responses ────────────────────────────────────────────────

    def _list_responses(self, client: Any, **kwargs: Any) -> Any:
        form_id = kwargs.get("form_id")
        if not isinstance(form_id, str) or not form_id:
            return {
                "error": (
                    "list_responses requires form_id=str (non-empty)"
                )
            }
        page_size = _clamp_limit(
            kwargs.get("page_size", 25), 25, _PAGE_CAP
        )

        import httpx

        try:
            resp = client.get(
                f"/forms/{form_id}/responses",
                params={"page_size": page_size},
            )
            if resp.status_code >= 400:
                return _http_error_to_dict(
                    httpx.HTTPStatusError(
                        f"HTTP {resp.status_code}",
                        request=None,  # type: ignore[arg-type]
                        response=resp,
                    )
                )
            raw = resp.json()
        except httpx.HTTPStatusError as exc:
            return _http_error_to_dict(exc)
        except Exception as exc:  # noqa: BLE001
            logger.warning("typeform.list_responses: %s", exc)
            return {"error": f"Typeform list_responses failed: {exc}"}

        if not isinstance(raw, dict):
            return {
                "error": "Typeform list_responses: non-dict payload"
            }
        items_src = raw.get("items", [])
        trimmed: list[dict[str, Any]] = []
        if isinstance(items_src, list):
            for r in items_src[:_LIST_RESPONSE_CAP]:
                if isinstance(r, dict):
                    trimmed.append(_trim_response(r))
        total = raw.get("total_items", len(trimmed))
        return {"ok": True, "total": total, "responses": trimmed}

    # ── export_csv ────────────────────────────────────────────────────

    def _export_csv(self, client: Any, **kwargs: Any) -> Any:
        form_id = kwargs.get("form_id")
        if not isinstance(form_id, str) or not form_id:
            return {
                "error": "export_csv requires form_id=str (non-empty)"
            }
        page_size = _clamp_limit(
            kwargs.get("page_size", 25), 25, _PAGE_CAP
        )

        raw = self._fetch_responses(client, form_id, page_size)
        if isinstance(raw, dict) and "error" in raw:
            return raw

        items = raw.get("items", []) if isinstance(raw, dict) else []
        if not isinstance(items, list):
            items = []

        csv_str, truncated = _build_csv(items)

        total = (
            raw.get("total_items", len(items))
            if isinstance(raw, dict)
            else len(items)
        )
        result: dict[str, Any] = {
            "ok": True,
            "total": total,
            "csv": csv_str,
        }
        if truncated:
            result["truncated"] = True
        return result

    def _fetch_responses(
        self, client: Any, form_id: str, page_size: int
    ) -> dict[str, Any]:
        """GET ``/forms/{form_id}/responses`` — shared by list/export."""
        import httpx

        try:
            resp = client.get(
                f"/forms/{form_id}/responses",
                params={"page_size": page_size},
            )
            if resp.status_code >= 400:
                return _http_error_to_dict(
                    httpx.HTTPStatusError(
                        f"HTTP {resp.status_code}",
                        request=None,  # type: ignore[arg-type]
                        response=resp,
                    )
                )
            raw = resp.json()
        except httpx.HTTPStatusError as exc:
            return _http_error_to_dict(exc)
        except Exception as exc:  # noqa: BLE001
            logger.warning("typeform.export_csv: %s", exc)
            return {"error": f"Typeform export_csv failed: {exc}"}

        if not isinstance(raw, dict):
            return {"error": "Typeform export_csv: non-dict payload"}
        return raw


__all__ = ["TypeformForm"]
