"""concinno_skills_marketing._auth — Marketing platform credential loading.

@module _auth
@responsibility Read each marketing platform's credentials from the
    Concinno :class:`CredentialStore` with env-var + disk JSON fallback.
    Returns ``None`` when nothing is configured so callers can render a
    friendly setup hint rather than crashing.

Keys
----
- ``mailchimp_api_key``  — Mailchimp Marketing API key. Keys end in a
  data-center suffix (e.g. ``abcdef-us21``) which we auto-parse when
  ``mailchimp_dc`` isn't set explicitly.
- ``mailchimp_dc``       — Optional explicit data-center override
  (e.g. ``us21``). Required only when the API key lacks a suffix
  (some legacy OAuth-scoped tokens).
- ``typeform_token``     — Typeform personal access token.
- ``sendgrid_api_key``   — SendGrid API key (``SG.xxxxxxxxxxxxxxxx``).

Precedence (inherited from ``concinno.core.credentials``):
    1. Runtime override via :meth:`CredentialStore.set`
    2. Env var ``CONCINNO_CRED_<UPPER_KEY>`` (e.g.
       ``CONCINNO_CRED_MAILCHIMP_API_KEY``)
    3. ``~/.concinno/credentials.json``
    4. ``None``

Concinno 2.15.1+ ships ``concinno.core.credentials`` in the wheel; when
the module is not importable (older wheels) we fall back to a local
env + disk store with identical semantics.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

# ── Optional CredentialStore bridge ──────────────────────────────────

try:  # pragma: no cover — binding depends on the installed concinno build
    from concinno.core.credentials import (
        CredentialStore,
        get_default_store,
    )

    _HAS_UPSTREAM_STORE = True
except ImportError:
    _HAS_UPSTREAM_STORE = False

    class CredentialStore:  # type: ignore[no-redef]
        """Fallback store: env + disk JSON, in-process override."""

        def __init__(self, config_path: Path | None = None) -> None:
            self._config_path = (
                config_path
                if config_path is not None
                else Path.home() / ".concinno" / "credentials.json"
            )
            self._runtime: dict[str, Any] = {}
            self._file_cache: dict[str, Any] | None = None

        def _load_file(self) -> dict[str, Any]:
            if self._file_cache is not None:
                return self._file_cache
            if not self._config_path.exists():
                self._file_cache = {}
                return self._file_cache
            try:
                data = json.loads(
                    self._config_path.read_text(encoding="utf-8")
                )
                self._file_cache = data if isinstance(data, dict) else {}
            except (OSError, ValueError):
                self._file_cache = {}
            return self._file_cache

        @staticmethod
        def _env_key_for(key: str) -> str:
            sanitized = "".join(
                c if c.isalnum() else "_" for c in key
            ).upper()
            return f"CONCINNO_CRED_{sanitized}"

        def get(self, key: str, default: Any = None) -> Any:
            if key in self._runtime:
                return self._runtime[key]
            env_val = os.environ.get(self._env_key_for(key))
            if env_val is not None:
                return env_val
            file_data = self._load_file()
            if key in file_data:
                val = file_data[key]
                if (
                    isinstance(val, dict)
                    and isinstance(val.get("$ref"), str)
                    and val["$ref"].startswith("env:")
                ):
                    return os.environ.get(val["$ref"][4:])
                return val
            return default

        def set(self, key: str, value: Any) -> None:
            self._runtime[key] = value

        def reload(self) -> None:
            self._file_cache = None

    _default_store_singleton: CredentialStore | None = None

    def get_default_store() -> CredentialStore:
        global _default_store_singleton
        if _default_store_singleton is None:
            _default_store_singleton = CredentialStore()
        return _default_store_singleton


logger = logging.getLogger("concinno_skills_marketing.auth")


_MAILCHIMP_API_KEY = "mailchimp_api_key"
_MAILCHIMP_DC = "mailchimp_dc"
_TYPEFORM_TOKEN_KEY = "typeform_token"
_SENDGRID_API_KEY = "sendgrid_api_key"


def _get_str(
    key: str,
    *,
    store: CredentialStore | None = None,
) -> str | None:
    """Return ``key``'s value if present and non-empty, else ``None``."""
    store = store if store is not None else get_default_store()
    val = store.get(key)
    if isinstance(val, str) and val.strip():
        return val
    return None


def _parse_dc_from_key(api_key: str) -> str | None:
    """Extract the trailing ``-usN`` / ``-us21`` suffix as the DC prefix.

    Mailchimp API keys conventionally embed their data-center as a
    trailing ``-<dc>`` suffix (e.g. ``abcdef123-us21``). This is the
    official quick-start documented mechanism for routing requests.

    Returns ``None`` when the key lacks a ``-<dc>`` tail (some legacy
    or OAuth-scoped tokens), in which case callers should require an
    explicit ``mailchimp_dc`` credential.
    """
    if "-" not in api_key:
        return None
    tail = api_key.rsplit("-", 1)[1].strip()
    # DC prefixes look like ``us21`` / ``us1`` / ``eu2``: 2 letters +
    # 1–3 digits. Defensive bounds on length to avoid matching noise.
    if 3 <= len(tail) <= 6 and tail[:2].isalpha() and tail[2:].isdigit():
        return tail.lower()
    return None


def get_mailchimp_credentials(
    *, store: CredentialStore | None = None
) -> dict[str, str] | None:
    """Return ``{api_key, dc}`` or ``None`` when creds are missing.

    Resolution order for the data-center prefix:
        1. Explicit ``mailchimp_dc`` credential.
        2. Trailing ``-<dc>`` segment on the API key.
        3. ``None`` (signals missing creds — caller renders setup hint).
    """
    api_key = _get_str(_MAILCHIMP_API_KEY, store=store)
    if api_key is None:
        return None

    dc = _get_str(_MAILCHIMP_DC, store=store)
    if dc is None:
        dc = _parse_dc_from_key(api_key)
    if dc is None:
        return None
    return {"api_key": api_key, "dc": dc}


def get_typeform_token(
    *, store: CredentialStore | None = None
) -> str | None:
    """Typeform personal access token or ``None``."""
    return _get_str(_TYPEFORM_TOKEN_KEY, store=store)


def get_sendgrid_api_key(
    *, store: CredentialStore | None = None
) -> str | None:
    """SendGrid API key or ``None``."""
    return _get_str(_SENDGRID_API_KEY, store=store)


__all__ = [
    "get_mailchimp_credentials",
    "get_sendgrid_api_key",
    "get_typeform_token",
]
