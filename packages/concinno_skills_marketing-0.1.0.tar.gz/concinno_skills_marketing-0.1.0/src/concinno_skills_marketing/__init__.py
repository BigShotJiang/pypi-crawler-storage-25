"""concinno-skills-marketing — Marketing / email / form agent skills.

Opt-in plugin package. When installed alongside ``concinno>=2.15.1`` and the
consumer env sets ``CONCINNO_LOAD_PLUGINS=1``, the tools here auto-mount
into :class:`concinno.tools.registry.ToolRegistry` via the
``[project.entry-points."concinno.tools"]`` table in ``pyproject.toml``.

Positioning
-----------
Marketing automation is the most common reason agents integrate with
third-party SaaS after customer-support. This package targets three of
the most common stacks: **Mailchimp** (newsletters), **Typeform**
(surveys / lead capture), **SendGrid** (transactional email).

MVP surface
-----------
- :class:`MailchimpCampaign` — list / get campaigns, list / add list
  members via Mailchimp Marketing API v3.
- :class:`TypeformForm` — get form, list responses, export CSV via
  Typeform API.
- :class:`SendGridSend` — send transactional email via SendGrid v3
  Mail Send API.

Licence note
------------
All three platforms are reached via ``httpx`` directly — no vendor SDK
dependencies. The package is MIT-licensed and adds zero additional
runtime dependencies beyond ``httpx>=0.27`` and Concinno itself.
"""
from __future__ import annotations

from concinno_skills_marketing.mailchimp import MailchimpCampaign
from concinno_skills_marketing.sendgrid_tool import SendGridSend
from concinno_skills_marketing.typeform import TypeformForm

__version__ = "0.1.0"
__all__ = [
    "MailchimpCampaign",
    "SendGridSend",
    "TypeformForm",
    "__version__",
]
