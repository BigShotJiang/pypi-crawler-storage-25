"""concinno_skills_marketing.mailchimp — MailchimpCampaign Concinno Tool.

@module mailchimp
@responsibility Implement the Concinno Tool protocol for Mailchimp
    Marketing API v3 campaign / list-member operations via the public
    REST surface at ``https://{dc}.api.mailchimp.com/3.0/``.
@dependencies httpx (declared dep), concinno_skills_marketing._auth
@exports MailchimpCampaign

Concurrency note
----------------
``is_concurrency_safe = False``. Mailchimp enforces a per-account
concurrent-connection cap (typically 10) and member add/update calls
are order-sensitive when keyed on the same ``subscriber_hash``. Serial
execution is the safe default.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import logging
from typing import Any

from concinno_skills_marketing._auth import get_mailchimp_credentials

logger = logging.getLogger("concinno_skills_marketing.mailchimp")

_VALID_ACTIONS = frozenset(
    {"list_campaigns", "get_campaign", "list_members", "add_member"}
)
_VALID_MEMBER_STATUSES = frozenset(
    {"subscribed", "unsubscribed", "cleaned", "pending", "transactional"}
)
# Mailchimp per_page ceiling is 1000 for the campaigns and members
# endpoints per the public schema.
_PAGE_CAP = 1000
_SETUP_HINT = (
    "no Mailchimp credentials — set via CredentialStore "
    "(keys: mailchimp_api_key [plus mailchimp_dc when the key has no "
    "-dc suffix]) or env CONCINNO_CRED_MAILCHIMP_API_KEY "
    "[/ CONCINNO_CRED_MAILCHIMP_DC]"
)


def _http_error_to_dict(exc: Exception) -> dict[str, Any]:
    """Wrap an :class:`httpx.HTTPStatusError` into a stable dict.

    Falls back to str(exc) when the response body isn't JSON / isn't
    attached (e.g. transport errors).
    """
    status = "?"
    body: Any = ""
    response = getattr(exc, "response", None)
    if response is not None:
        status = str(getattr(response, "status_code", "?"))
        try:
            body = response.json()
        except Exception:  # noqa: BLE001 — defensive
            try:
                body = response.text
            except Exception:  # noqa: BLE001
                body = ""
    # Mailchimp errors look like
    # {"type":"...","title":"...","status":N,"detail":"...","instance":"..."}.
    msg = ""
    if isinstance(body, dict):
        msg = str(
            body.get("detail")
            or body.get("title")
            or body.get("type")
            or ""
        )
        if not msg:
            msg = json.dumps(body)[:400]
    else:
        msg = str(body)[:400] if body else str(exc)
    return {"error": f"Mailchimp error {status}: {msg}"}


def _build_client(creds: dict[str, str]) -> Any:
    """Return a configured ``httpx.Client`` for Mailchimp REST v3.

    Uses HTTP Basic auth with ``anystring:<api_key>`` per the official
    Mailchimp quick-start.
    """
    import httpx

    base_url = f"https://{creds['dc']}.api.mailchimp.com/3.0"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    # Any literal string works as the Basic-auth username per
    # Mailchimp's documented scheme; we use ``anystring``.
    auth = httpx.BasicAuth("anystring", creds["api_key"])
    return httpx.Client(
        base_url=base_url, auth=auth, headers=headers, timeout=30.0
    )


def _clamp_limit(raw: Any, default: int, hi: int) -> int:
    try:
        val = int(raw)
    except (TypeError, ValueError):
        return default
    return max(1, min(val, hi))


def _subscriber_hash(email: str) -> str:
    """Mailchimp's ``subscriber_hash`` = lowercase MD5 of the email."""
    return hashlib.md5(email.strip().lower().encode("utf-8")).hexdigest()  # noqa: S324 — API requirement


class MailchimpCampaign:
    """List / get campaigns and list / add list members.

    Params accepted via ``call(**kwargs)``:
        action (str):            ``"list_campaigns"`` |
                                 ``"get_campaign"`` |
                                 ``"list_members"`` |
                                 ``"add_member"``.
        limit (int):             for ``list_campaigns`` / ``list_members``
                                 — page size; default 25, max 1000
                                 (Mailchimp ``count`` cap).
        campaign_id (str):       for ``get_campaign`` — Mailchimp
                                 campaign id (``web_id``-adjacent
                                 opaque string).
        list_id (str):           for ``list_members`` / ``add_member``.
        email_address (str):     for ``add_member``.
        status (str):            for ``add_member``; one of
                                 subscribed / unsubscribed / cleaned /
                                 pending / transactional.
        merge_fields (dict):     for ``add_member`` — optional per the
                                 Mailchimp schema.

    Returns:
        - ``list_campaigns`` → ``{"ok": True, "data":
          {"total_items": N, "campaigns": [{"id","web_id",
          "status","settings.title"}, …]}}``
        - ``get_campaign`` → ``{"ok": True, "data":
          {"id","status","type","settings": {...}}}``
        - ``list_members`` → ``{"ok": True, "data":
          {"list_id": "...", "total_items": N,
          "members": [{"id","email_address","status"}, …]}}``
        - ``add_member`` → ``{"ok": True, "data":
          {"id": "...", "email_address": "...", "status": "..."}}``
        - on failure → ``{"error": "..."}``
    """

    name: str = "mailchimp_campaign"
    description: str = (
        "Mailchimp Marketing API v3 campaign + list-member ops via "
        "REST. Params: action (list_campaigns|get_campaign|"
        "list_members|add_member); "
        "list_campaigns/list_members: limit (default 25, max 1000); "
        "get_campaign: campaign_id; "
        "list_members: list_id; "
        "add_member: list_id, email_address, "
        "status (subscribed|unsubscribed|cleaned|pending|"
        "transactional), merge_fields (optional dict). "
        "Returns {'ok': True, 'data': {...}} or {'error': ...}."
    )
    # Shared tenant mutation + per-account concurrency caps → serial.
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {
                "error": (
                    "action must be list_campaigns|get_campaign|"
                    f"list_members|add_member, got {action!r}"
                )
            }

        creds = get_mailchimp_credentials()
        if creds is None:
            return {"error": _SETUP_HINT}

        try:
            import httpx  # noqa: F401 — surfaced below if missing
        except ImportError as exc:
            return {
                "error": (
                    f"httpx not installed: {exc}. "
                    "Run: pip install concinno-skills-marketing"
                )
            }

        try:
            client = _build_client(creds)
        except Exception as exc:  # noqa: BLE001 — defensive
            logger.warning("mailchimp: client build failed: %s", exc)
            return {"error": f"Mailchimp client init failed: {exc}"}

        try:
            if action == "list_campaigns":
                return self._list_campaigns(client, **kwargs)
            if action == "get_campaign":
                return self._get_campaign(client, **kwargs)
            if action == "list_members":
                return self._list_members(client, **kwargs)
            # action == "add_member" — guarded above.
            return self._add_member(client, **kwargs)
        finally:
            # Defensive: some mocked httpx clients may raise on close.
            with contextlib.suppress(Exception):
                client.close()

    # ── list_campaigns ────────────────────────────────────────────────

    def _list_campaigns(self, client: Any, **kwargs: Any) -> Any:
        count = _clamp_limit(kwargs.get("limit", 25), 25, _PAGE_CAP)

        import httpx

        try:
            resp = client.get(
                "/campaigns",
                params={"count": count},
            )
            if resp.status_code >= 400:
                return _http_error_to_dict(
                    httpx.HTTPStatusError(
                        f"HTTP {resp.status_code}",
                        request=None,  # type: ignore[arg-type]
                        response=resp,
                    )
                )
            raw = resp.json()
        except httpx.HTTPStatusError as exc:
            return _http_error_to_dict(exc)
        except Exception as exc:  # noqa: BLE001 — network / unknown
            logger.warning("mailchimp.list_campaigns: %s", exc)
            return {"error": f"Mailchimp list_campaigns failed: {exc}"}

        if not isinstance(raw, dict):
            return {"error": "Mailchimp list_campaigns: non-dict payload"}

        campaigns_src = raw.get("campaigns", [])
        campaigns: list[dict[str, Any]] = []
        for c in campaigns_src[:count] if isinstance(campaigns_src, list) else []:
            if not isinstance(c, dict):
                continue
            settings = c.get("settings") if isinstance(c.get("settings"), dict) else {}
            campaigns.append(
                {
                    "id": c.get("id"),
                    "web_id": c.get("web_id"),
                    "status": c.get("status", ""),
                    "title": settings.get("title", ""),
                }
            )
        return {
            "ok": True,
            "data": {
                "total_items": raw.get("total_items", len(campaigns)),
                "campaigns": campaigns,
            },
        }

    # ── get_campaign ──────────────────────────────────────────────────

    def _get_campaign(self, client: Any, **kwargs: Any) -> Any:
        campaign_id = kwargs.get("campaign_id")
        if not isinstance(campaign_id, str) or not campaign_id:
            return {"error": "get_campaign requires campaign_id=str (non-empty)"}

        import httpx

        try:
            resp = client.get(f"/campaigns/{campaign_id}")
            if resp.status_code >= 400:
                return _http_error_to_dict(
                    httpx.HTTPStatusError(
                        f"HTTP {resp.status_code}",
                        request=None,  # type: ignore[arg-type]
                        response=resp,
                    )
                )
            raw = resp.json()
        except httpx.HTTPStatusError as exc:
            return _http_error_to_dict(exc)
        except Exception as exc:  # noqa: BLE001
            logger.warning("mailchimp.get_campaign: %s", exc)
            return {"error": f"Mailchimp get_campaign failed: {exc}"}

        if not isinstance(raw, dict):
            return {"error": "Mailchimp get_campaign: non-dict payload"}
        return {
            "ok": True,
            "data": {
                "id": raw.get("id"),
                "status": raw.get("status", ""),
                "type": raw.get("type", ""),
                "settings": raw.get("settings", {}),
            },
        }

    # ── list_members ──────────────────────────────────────────────────

    def _list_members(self, client: Any, **kwargs: Any) -> Any:
        list_id = kwargs.get("list_id")
        if not isinstance(list_id, str) or not list_id:
            return {"error": "list_members requires list_id=str (non-empty)"}
        count = _clamp_limit(kwargs.get("limit", 25), 25, _PAGE_CAP)

        import httpx

        try:
            resp = client.get(
                f"/lists/{list_id}/members",
                params={"count": count},
            )
            if resp.status_code >= 400:
                return _http_error_to_dict(
                    httpx.HTTPStatusError(
                        f"HTTP {resp.status_code}",
                        request=None,  # type: ignore[arg-type]
                        response=resp,
                    )
                )
            raw = resp.json()
        except httpx.HTTPStatusError as exc:
            return _http_error_to_dict(exc)
        except Exception as exc:  # noqa: BLE001
            logger.warning("mailchimp.list_members: %s", exc)
            return {"error": f"Mailchimp list_members failed: {exc}"}

        if not isinstance(raw, dict):
            return {"error": "Mailchimp list_members: non-dict payload"}

        members_src = raw.get("members", [])
        members: list[dict[str, Any]] = []
        for m in members_src[:count] if isinstance(members_src, list) else []:
            if not isinstance(m, dict):
                continue
            members.append(
                {
                    "id": m.get("id"),
                    "email_address": m.get("email_address", ""),
                    "status": m.get("status", ""),
                }
            )
        return {
            "ok": True,
            "data": {
                "list_id": list_id,
                "total_items": raw.get("total_items", len(members)),
                "members": members,
            },
        }

    # ── add_member ────────────────────────────────────────────────────

    def _add_member(self, client: Any, **kwargs: Any) -> Any:
        list_id = kwargs.get("list_id")
        email_address = kwargs.get("email_address")
        status = kwargs.get("status", "subscribed")
        merge_fields = kwargs.get("merge_fields")

        if not isinstance(list_id, str) or not list_id:
            return {"error": "add_member requires list_id=str (non-empty)"}
        if not isinstance(email_address, str) or not email_address:
            return {"error": "add_member requires email_address=str (non-empty)"}
        if "@" not in email_address:
            return {"error": f"email_address must be a valid email, got {email_address!r}"}
        if status not in _VALID_MEMBER_STATUSES:
            return {
                "error": (
                    "status must be one of "
                    "subscribed|unsubscribed|cleaned|pending|transactional, "
                    f"got {status!r}"
                )
            }

        payload: dict[str, Any] = {
            "email_address": email_address,
            "status": status,
        }
        if isinstance(merge_fields, dict) and merge_fields:
            payload["merge_fields"] = merge_fields

        # Use PUT to ``/members/{subscriber_hash}`` so that retrying an
        # add for an existing subscriber is idempotent (standard
        # Mailchimp-documented upsert pattern).
        subscriber_hash = _subscriber_hash(email_address)

        import httpx

        try:
            resp = client.put(
                f"/lists/{list_id}/members/{subscriber_hash}",
                json=payload,
            )
            if resp.status_code >= 400:
                return _http_error_to_dict(
                    httpx.HTTPStatusError(
                        f"HTTP {resp.status_code}",
                        request=None,  # type: ignore[arg-type]
                        response=resp,
                    )
                )
            raw = resp.json()
        except httpx.HTTPStatusError as exc:
            return _http_error_to_dict(exc)
        except Exception as exc:  # noqa: BLE001
            logger.warning("mailchimp.add_member: %s", exc)
            return {"error": f"Mailchimp add_member failed: {exc}"}

        if not isinstance(raw, dict):
            return {"error": "Mailchimp add_member: non-dict payload"}
        return {
            "ok": True,
            "data": {
                "id": raw.get("id"),
                "email_address": raw.get("email_address", email_address),
                "status": raw.get("status", status),
            },
        }


__all__ = ["MailchimpCampaign"]
