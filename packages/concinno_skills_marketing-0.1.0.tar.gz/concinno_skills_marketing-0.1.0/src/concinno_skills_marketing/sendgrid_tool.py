"""concinno_skills_marketing.sendgrid_tool — SendGridSend Concinno Tool.

@module sendgrid_tool
@responsibility Implement the Concinno Tool protocol for SendGrid's
    v3 Mail Send API (``POST https://api.sendgrid.com/v3/mail/send``).
    Module is named ``sendgrid_tool`` (not ``sendgrid``) to avoid
    shadowing the official ``sendgrid`` SDK namespace should a
    consumer install both — same defensive pattern as
    ``concinno-skills-vector/weaviate_tool.py``.
@dependencies httpx (declared dep), concinno_skills_marketing._auth
@exports SendGridSend

Concurrency note
----------------
``is_concurrency_safe = False``. SendGrid orders message sends per API
key and enforces tenant-scoped rate limits; serial execution is the
safe default.
"""

from __future__ import annotations

import contextlib
import json
import logging
from typing import Any

from concinno_skills_marketing._auth import get_sendgrid_api_key

logger = logging.getLogger("concinno_skills_marketing.sendgrid_tool")

_VALID_ACTIONS = frozenset({"send"})
_BODY_CAP = 1_000_000  # 1 MB — SendGrid hard-caps at 30 MB total
_SENDGRID_URL = "https://api.sendgrid.com/v3/mail/send"
_SETUP_HINT = (
    "no SendGrid credentials — set via CredentialStore "
    "(key: sendgrid_api_key) or env CONCINNO_CRED_SENDGRID_API_KEY"
)


def _http_error_to_dict(exc: Exception) -> dict[str, Any]:
    """Wrap an :class:`httpx.HTTPStatusError` into a stable dict."""
    status = "?"
    body: Any = ""
    response = getattr(exc, "response", None)
    if response is not None:
        status = str(getattr(response, "status_code", "?"))
        try:
            body = response.json()
        except Exception:  # noqa: BLE001
            try:
                body = response.text
            except Exception:  # noqa: BLE001
                body = ""
    # SendGrid errors: {"errors": [{"message": "...", "field": "..."}]}.
    msg = ""
    if isinstance(body, dict):
        errors = body.get("errors")
        if isinstance(errors, list) and errors:
            first = errors[0]
            if isinstance(first, dict):
                msg = str(first.get("message") or first.get("field") or "")
        if not msg:
            msg = json.dumps(body)[:400]
    else:
        msg = str(body)[:400] if body else str(exc)
    return {"error": f"SendGrid error {status}: {msg}"}


def _build_client(api_key: str) -> Any:
    """Return a configured ``httpx.Client`` for SendGrid."""
    import httpx

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    return httpx.Client(headers=headers, timeout=30.0)


def _extract_message_id(resp: Any) -> str:
    """Pull the ``X-Message-Id`` response header, case-insensitive.

    httpx's ``Response.headers`` is already case-insensitive (derived
    from starlette's multidict), but some test doubles aren't — we
    fall back to a linear scan so the tool keeps working either way.
    """
    headers = getattr(resp, "headers", None)
    if headers is None:
        return ""
    # Try the canonical cases first.
    for key in ("X-Message-Id", "x-message-id", "X-Message-ID"):
        try:
            val = headers.get(key)
        except Exception:  # noqa: BLE001
            val = None
        if val:
            return str(val)
    # Fallback: iterate (handles plain-dict doubles).
    try:
        items = headers.items() if hasattr(headers, "items") else []
    except Exception:  # noqa: BLE001
        items = []
    for k, v in items:
        if isinstance(k, str) and k.lower() == "x-message-id":
            return str(v) if v is not None else ""
    return ""


def _normalize_recipients(to: Any) -> list[dict[str, str]] | None:
    """Accept ``str`` / ``list[str]`` / ``list[dict]`` → SendGrid schema.

    Returns ``None`` when the input is invalid.
    """
    if isinstance(to, str):
        if not to or "@" not in to:
            return None
        return [{"email": to}]
    if isinstance(to, list):
        out: list[dict[str, str]] = []
        for entry in to:
            if isinstance(entry, str) and "@" in entry:
                out.append({"email": entry})
            elif (
                isinstance(entry, dict)
                and isinstance(entry.get("email"), str)
                and "@" in entry["email"]
            ):
                normalized: dict[str, str] = {"email": entry["email"]}
                name = entry.get("name")
                if isinstance(name, str) and name:
                    normalized["name"] = name
                out.append(normalized)
            else:
                return None
        return out if out else None
    return None


class SendGridSend:
    """Send transactional email via SendGrid v3 Mail Send API.

    Params accepted via ``call(**kwargs)``:
        action (str):          ``"send"``.
        to (str|list):         Recipient email(s). Accepts a single
                               string, a list of strings, or a list of
                               ``{"email", "name"}`` dicts.
        from_email (str):      Sender email. Required.
        subject (str):         Subject line. Required.
        body (str):            Message body, plain-text by default.
        is_html (bool):        Set True to send ``text/html`` instead
                               of ``text/plain``. Default False.
        attachments (list):    Optional list of
                               ``{"content": "<base64>", "filename":
                               "...", "type": "application/pdf"}``
                               dicts. Caller must base64-encode.

    Returns:
        - ``send`` → ``{"ok": True, "message_id": "<x-message-id>"}``
        - on failure → ``{"error": "..."}``
    """

    name: str = "sendgrid_send"
    description: str = (
        "Send transactional email via SendGrid v3 Mail Send API. "
        "Params: action (send); "
        "send: to (str|list), from_email, subject, body "
        "(≤1000000 chars), is_html (optional bool, default False), "
        "attachments (optional list of "
        "{'content': base64, 'filename', 'type'}). "
        "Returns {'ok': True, 'message_id': ...} or {'error': ...}."
    )
    # Per-API-key ordering + tenant rate limits → serial.
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {
                "error": f"action must be send, got {action!r}"
            }

        api_key = get_sendgrid_api_key()
        if api_key is None:
            return {"error": _SETUP_HINT}

        try:
            import httpx  # noqa: F401
        except ImportError as exc:
            return {
                "error": (
                    f"httpx not installed: {exc}. "
                    "Run: pip install concinno-skills-marketing"
                )
            }

        # Validate params before opening a client — cheap fail fast.
        to_raw = kwargs.get("to")
        from_email = kwargs.get("from_email")
        subject = kwargs.get("subject")
        body = kwargs.get("body")
        is_html = bool(kwargs.get("is_html", False))
        attachments = kwargs.get("attachments")

        recipients = _normalize_recipients(to_raw)
        if recipients is None:
            return {
                "error": (
                    "send requires to=str|list[str]|list[dict] "
                    "with at least one valid email"
                )
            }
        if (
            not isinstance(from_email, str)
            or "@" not in from_email
            or not from_email.strip()
        ):
            return {
                "error": "send requires from_email=str (valid email)"
            }
        if not isinstance(subject, str) or not subject:
            return {"error": "send requires subject=str (non-empty)"}
        if not isinstance(body, str) or not body:
            return {"error": "send requires body=str (non-empty)"}
        if len(body) > _BODY_CAP:
            return {
                "error": (
                    f"body exceeds {_BODY_CAP}-char cap "
                    f"(got {len(body)})"
                )
            }
        if attachments is not None:
            if not isinstance(attachments, list):
                return {"error": "attachments must be a list of dicts"}
            for a in attachments:
                if not (
                    isinstance(a, dict)
                    and isinstance(a.get("content"), str)
                    and isinstance(a.get("filename"), str)
                ):
                    return {
                        "error": (
                            "each attachment needs content=str "
                            "(base64) + filename=str"
                        )
                    }

        try:
            client = _build_client(api_key)
        except Exception as exc:  # noqa: BLE001
            logger.warning("sendgrid: client build failed: %s", exc)
            return {"error": f"SendGrid client init failed: {exc}"}

        mime_type = "text/html" if is_html else "text/plain"
        payload: dict[str, Any] = {
            "personalizations": [{"to": recipients}],
            "from": {"email": from_email},
            "subject": subject,
            "content": [{"type": mime_type, "value": body}],
        }
        if isinstance(attachments, list) and attachments:
            payload["attachments"] = attachments

        import httpx

        try:
            resp = client.post(_SENDGRID_URL, json=payload)
            if resp.status_code >= 400:
                return _http_error_to_dict(
                    httpx.HTTPStatusError(
                        f"HTTP {resp.status_code}",
                        request=None,  # type: ignore[arg-type]
                        response=resp,
                    )
                )
        except httpx.HTTPStatusError as exc:
            return _http_error_to_dict(exc)
        except Exception as exc:  # noqa: BLE001
            logger.warning("sendgrid.send: %s", exc)
            return {"error": f"SendGrid send failed: {exc}"}
        finally:
            with contextlib.suppress(Exception):
                client.close()

        return {"ok": True, "message_id": _extract_message_id(resp)}


__all__ = ["SendGridSend"]
