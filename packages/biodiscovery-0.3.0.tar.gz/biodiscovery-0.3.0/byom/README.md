# Nodes Bio Pathway Scoring Module — BYOM Spec

**For Amazon Bio Discovery "Bring Your Own Model" (BYOM) beta.**

This module scores antibody targets by their position and connectivity
within biological pathways, helping researchers prioritize which targets
to design against.

## Module Specification

```json
{
  "moduleType": "SCORE",
  "inputs": {
    "target_sequences": {
      "displayName": "Target Protein Sequences",
      "description": "Protein sequences (FASTA) to score for pathway relevance.",
      "type": "file",
      "extensions": [".fasta", ".fa"],
      "required": true
    },
    "pathway": {
      "displayName": "Pathway Context",
      "description": "Disease or biological pathway to score against. Examples: 'neuroinflammation', 'TNF signaling', 'apoptosis'.",
      "type": "string",
      "required": true
    },
    "organism": {
      "displayName": "Organism",
      "description": "Target organism for pathway lookup.",
      "type": "enum",
      "values": ["human", "mouse", "rat"],
      "required": false
    }
  },
  "outputs": {
    "pathway_scores": {
      "displayName": "Pathway Relevance Scores",
      "description": "Per-sequence pathway centrality, druggability, and consensus scores.",
      "type": "scoreResults",
      "filename": "pathway_scores.csv",
      "columns": [
        {"name": "sequence_id", "type": "string"},
        {"name": "gene_symbol", "type": "string"},
        {"name": "pathway_centrality", "type": "float"},
        {"name": "druggability_score", "type": "float"},
        {"name": "literature_mentions", "type": "int"},
        {"name": "consensus_score", "type": "float"},
        {"name": "rationale", "type": "string"}
      ]
    }
  }
}
```

## Docker Container

```dockerfile
FROM python:3.12-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY score.py .

ENTRYPOINT ["python", "score.py"]
```

### requirements.txt

```
httpx>=0.25
biopython>=1.83
```

### score.py

```python
"""Nodes Bio Pathway Scoring Module for Amazon Bio Discovery BYOM."""

import csv
import json
import os
import sys
from pathlib import Path

import httpx
from Bio import SeqIO


def blast_to_gene(sequence: str) -> str | None:
    """Map a protein sequence to a gene symbol via NCBI BLAST."""
    # Simplified: use UniProt ID mapping for speed
    resp = httpx.post(
        "https://rest.uniprot.org/idmapping/run",
        data={"from": "UniProtKB_AC-ID", "to": "Gene_Name", "ids": sequence[:50]},
        timeout=30,
    )
    return None  # Placeholder — real impl uses sequence search


def score_pathway_relevance(gene: str, pathway: str) -> dict:
    """Score a gene's relevance to a pathway using public APIs."""
    # Query STRING-DB for network centrality
    string_url = "https://string-db.org/api/json/interaction_partners"
    resp = httpx.get(string_url, params={
        "identifiers": gene, "species": 9606, "limit": 10,
    }, timeout=15)
    interactions = resp.json() if resp.status_code == 200 else []
    centrality = min(len(interactions) / 20.0, 1.0)

    # Query OpenTargets for druggability
    ot_query = """
    query($gene: String!) {
      search(queryString: $gene, entityNames: ["target"]) {
        hits { id score }
      }
    }
    """
    ot_resp = httpx.post(
        "https://api.platform.opentargets.org/api/v4/graphql",
        json={"query": ot_query, "variables": {"gene": gene}},
        timeout=15,
    )
    druggability = 0.0
    if ot_resp.status_code == 200:
        hits = ot_resp.json().get("data", {}).get("search", {}).get("hits", [])
        druggability = hits[0]["score"] if hits else 0.0

    # Literature count via Europe PMC
    pmc_resp = httpx.get(
        "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
        params={"query": f"{gene} AND {pathway}", "format": "json", "pageSize": 1},
        timeout=15,
    )
    lit_count = 0
    if pmc_resp.status_code == 200:
        lit_count = pmc_resp.json().get("hitCount", 0)

    consensus = (centrality * 0.3 + druggability * 0.4 + min(lit_count / 100, 1.0) * 0.3)

    return {
        "pathway_centrality": round(centrality, 3),
        "druggability_score": round(druggability, 3),
        "literature_mentions": lit_count,
        "consensus_score": round(consensus, 3),
        "rationale": f"{gene}: centrality={centrality:.2f}, druggability={druggability:.2f}, {lit_count} papers on '{pathway}'",
    }


def main():
    input_dir = os.environ.get("INPUT_DIR", "/input")
    output_dir = os.environ.get("OUTPUT_DIR", "/output")
    params_file = os.environ.get("PARAMS_FILE", "/input/params.json")

    # Read parameters
    with open(params_file) as f:
        params = json.load(f)
    pathway = params.get("pathway", "inflammation")
    organism = params.get("organism", "human")

    # Read input sequences
    fasta_files = list(Path(input_dir).glob("*.fasta")) + list(Path(input_dir).glob("*.fa"))
    sequences = []
    for fasta in fasta_files:
        for record in SeqIO.parse(str(fasta), "fasta"):
            sequences.append(record)

    # Score each sequence
    results = []
    for seq in sequences:
        gene = seq.id.split("|")[0] if "|" in seq.id else seq.id
        scores = score_pathway_relevance(gene, pathway)
        results.append({
            "sequence_id": seq.id,
            "gene_symbol": gene,
            **scores,
        })

    # Write output CSV
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    output_path = Path(output_dir) / "pathway_scores.csv"
    with open(output_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "sequence_id", "gene_symbol", "pathway_centrality",
            "druggability_score", "literature_mentions",
            "consensus_score", "rationale",
        ])
        writer.writeheader()
        writer.writerows(results)

    print(f"Scored {len(results)} sequences for pathway '{pathway}'")
    print(f"Output: {output_path}")


if __name__ == "__main__":
    main()
```

## Pipeline Integration

This module slots into a Bio Discovery recipe as a scoring step:

```json
{
  "modulesGraph": [
    {
      "stepName": "rfantibody",
      "moduleId": "rfantibody",
      "moduleVersion": "1.0",
      "dependencies": []
    },
    {
      "stepName": "pathway_scoring",
      "moduleId": "nodesbio-pathway-score",
      "moduleVersion": "1.0",
      "dependencies": [
        {
          "pipeFrom": {"output": "rf2_pdbs", "stepName": "rfantibody"},
          "pipeTo": "target_sequences"
        }
      ]
    },
    {
      "stepName": "boltz2",
      "moduleId": "boltz2",
      "moduleVersion": "1.0",
      "dependencies": [
        {
          "pipeFrom": {"output": "rf2_pdbs", "stepName": "rfantibody"},
          "pipeTo": "inputPath"
        }
      ]
    }
  ]
}
```

## BYOM Application Status

- **Submitted:** April 15, 2026
- **Format:** Docker container
- **Review timeline:** ~5 business days (expect by April 22)
- **Module name:** `nodesbio-pathway-score`
- **Module type:** SCORE

## Data Flow

```
MedMap pathway → identify target genes
                        ↓
              bridge.pathway_to_design()
                        ↓
              Bio Discovery experiment
                        ↓
         RFantibody → [pathway_scoring] → Boltz2
                        ↓
              Ranked candidates with pathway context
                        ↓
              Send to wet lab (Ginkgo / Twist)
```

---

Built by **Nodes Bio, Inc.** — AI Synthesis for Science and Medicine
