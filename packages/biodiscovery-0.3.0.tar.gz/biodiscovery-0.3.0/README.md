# biodiscovery-python

**The unofficial Python SDK for [Amazon Bio Discovery](https://aws.amazon.com/biodiscovery/).**

Design antibodies with AI. Programmatically.

```bash
pip install biodiscovery
```

> **⚠️ Unofficial.** This package is not affiliated with or endorsed by Amazon Web Services.
> Built by [Nodes Bio, Inc.](https://nodes.bio) — AI Synthesis for Science and Medicine.

---

## Quick Start

```python
from biodiscovery import BioDiscoveryClient

client = BioDiscoveryClient(
    application_id="your-app-id",
    access_key_id="AKIA...",
    secret_access_key="...",
    session_token="...",
)

# Get a project
project = client.get_project("f29a1f5a33504ca885d0bea53d3570ba")
print(project.name, project.status)

# Get experiment results
experiment = client.get_experiment(
    project_id=project.project_id,
    experiment_id="f4ef6a1e01c84f4ea6bf29bf2028e5e5",
)
print(f"Cost: {experiment.estimated_experiment_units} EU")
print(f"Status: {experiment.status}")

# Inspect a module's IO spec
module = client.get_module("rfantibody")
print(module.description)
print(module.io_spec.inputs)

# Get a recipe DAG
recipe = client.get_recipe("8f2e9b3c7d154aa6b2c8f1e9d0a3b5c4")
for step in recipe.steps:
    print(f"  {step.step_name} → {step.module_id}")

# List wet lab orders
orders = client.list_wetlab_orders(project.project_id, experiment.experiment_id)
```

## Authentication

Amazon Bio Discovery uses AWS SigV4 signing with temporary credentials obtained via Identity Center SSO. The SDK handles signing automatically — you provide the credentials from your Bio Discovery session.

To get your credentials:
1. Log in to [biodiscovery.aws.com](https://biodiscovery.aws.com)
2. Open browser DevTools → Network tab
3. Find the `/getcredentials` response
4. Copy `applicationId`, `credentials.accessKeyId`, `credentials.secretAccessKey`, `credentials.sessionToken`

## API Coverage (v0.2.0 — 55 methods)

### Projects
`list_projects` · `get_project` · `create_project` · `update_project` · `delete_project`

### Experiments
`list_experiments` · `get_experiment` · `create_experiment` · `update_experiment` · `delete_experiment` · `start_experiment` · `predict_experiment_configuration`

### Results
`list_results` · `get_result_data` · `get_result_metadata`

### Jobs
`list_jobs` · `get_job` · `create_job` · `start_job` · `update_job` · `delete_job`

### Modules & Recipes
`list_hosted_modules` · `get_module` · `list_hosted_recipes` · `get_recipe` · `list_custom_recipes` · `get_custom_recipe` · `create_custom_recipe` · `update_custom_recipe` · `delete_custom_recipe` · `start_custom_recipe_publish`

### Wet Lab (CRO Integration)
`list_wetlab_providers` · `list_wetlab_orders` · `get_wetlab_order` · `get_wetlab_order_estimates` · `create_wetlab_order` · `cancel_wetlab_order` · `delete_wetlab_order` · `export_wetlab_order_results`

### Datasets & Files
`list_datasets` · `get_dataset_metadata` · `import_dataset` · `export_dataset` · `update_dataset` · `start_dataset_multipart_upload` · `resume_dataset_multipart_upload` · `complete_dataset_multipart_upload` · `get_file_metadata` · `export_file` · `delete_file`

### Sharing & Permissions
`list_resource_permissions` · `create_resource_permission` · `update_resource_permission` · `delete_resource_permission` · `update_principal_permissions` · `list_principals`

### Identity Center
`list_idc_users` · `list_idc_groups` · `associate_idc_principal` · `disassociate_idc_principal`

### Account
`get_user_details` · `list_feature_flags` · `get_usage`

## Module Catalog

The SDK includes a reference catalog of known Bio Discovery modules:

```python
from biodiscovery.catalog import MODULES, RECIPES, CRO_PARTNERS

# All 40+ hosted bioFMs
for module_id, description in MODULES.items():
    print(f"{module_id}: {description}")

# Known recipe IDs
print(RECIPES["de_novo_design"])

# CRO partners
for partner, info in CRO_PARTNERS.items():
    print(f"{partner}: {info}")
```

## Models

All API responses are parsed into typed [Pydantic](https://docs.pydantic.dev/) models:

- `Project` — project metadata and status
- `Experiment` — experiment config, parameters, EU cost, timing
- `Module` — bioFM module with parsed IO specification
- `Recipe` — workflow DAG with steps and dependency piping
- `WetLabOrder` — CRO order status and assay details

## Before You Design: Understand the Biology

Amazon Bio Discovery designs antibodies. But *which* target should you design against?

**[Jarvis](https://nodes.bio/jarvis)** sends your biology question to five AI models simultaneously and returns a consensus answer with a confidence score. Use it to evaluate targets, review literature, and build confidence before you spend Experiment Units.

**[MedMap](https://nodes.bio)** turns plain-English biology questions into interactive pathway maps. Visualize the disease mechanism, identify druggable nodes, then take those targets into Bio Discovery.

*Research → Visualize → Design → Test. That's the workflow.*

## Contributing

Contributions welcome:

- Async client (`httpx.AsyncClient`)
- CLI tool
- Better credential management (browser cookie extraction, SSO flow)
- Response model coverage for newer endpoints
- Integration examples and notebooks

## License

Apache 2.0 — see [LICENSE](LICENSE).

---

Built by **[Nodes Bio, Inc.](https://nodes.bio)** — AI Synthesis for Science and Medicine.
