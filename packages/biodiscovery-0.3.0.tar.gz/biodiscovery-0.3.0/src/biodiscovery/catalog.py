"""Typed helpers for well-known Bio Discovery modules."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class DeNovoDesignParams:
    """Parameters for the RFantibody de novo design module."""

    target_pdb: str
    framework_pdb: str = "h-NbBCII10"
    hotspot_residues: str = "[T12,T49]"
    design_loops: str = "[L1:, L2:, L3:, H1:, H2:, H3:]"
    loop_string: str = "H1,H2,H3,L1,L2,L3"
    num_designs: int = 1
    plm_model: str = "esm"


# Well-known module IDs from the Bio Discovery catalog
MODULES = {
    "rfantibody": "De novo diffusion-based antibody/nanobody backbone design",
    "temstapro": "Protein thermostability prediction",
    "esm2pseudo_log_likelihood": "PLM pseudo-perplexity (protein fitness)",
    "fastdpe": "Antibody developability scoring (5 metrics)",
    "boltz2": "3D complex structure + binding affinity prediction",
    "boltz1": "3D complex structure prediction",
    "boltzgen": "De novo nanobody design via diffusion",
    "abodybuilder3": "Template-free antibody structure prediction",
    "abnumber": "Antibody numbering and alignment (ANARCI)",
    "biophi": "Antibody humanization + OASis humanness scoring",
    "aggrescan3d": "Protein aggregation propensity prediction",
    "ablang2_perplexity": "AbLang2 pseudo-perplexity scoring",
}

# Well-known hosted recipe IDs
RECIPES = {
    "de_novo_design": "8f2e9b3c7d154aa6b2c8f1e9d0a3b5c4",
}

# CRO partners
CRO_PARTNERS = {
    "twist": "Twist Bioscience — IgG, scFv — SPR, ELISA",
    "ginkgo": "Ginkgo Bioworks — IgG, nanobody, VHH — BLI, ELISA, thermal stability",
    "a_alpha_bio": "A-Alpha Bio — protein interaction profiling",
}
