"""BioDiscoveryClient — full API coverage for Amazon Bio Discovery."""

from __future__ import annotations

import json
from typing import Any, Optional

import httpx

from biodiscovery.auth import sign_request
from biodiscovery.models import (
    Experiment,
    Module,
    ModuleIO,
    Project,
    Recipe,
    RecipeStep,
    WetLabOrder,
)

_API_HOST = "researchstudio.us-east-1.api.aws"
_BASE_URL = f"https://{_API_HOST}"


class BioDiscoveryClient:
    """Unofficial Python client for the Amazon Bio Discovery API.

    Covers the full API surface: projects, experiments, jobs, modules,
    recipes, wet lab orders, datasets, files, usage, and sharing.

    Args:
        application_id: Your Bio Discovery application ID.
        access_key_id: AWS access key from ``/getcredentials``.
        secret_access_key: AWS secret key from ``/getcredentials``.
        session_token: AWS session token from ``/getcredentials``.
        region: AWS region (default ``us-east-1``).
    """

    def __init__(
        self,
        application_id: str,
        access_key_id: str,
        secret_access_key: str,
        session_token: Optional[str] = None,
        region: str = "us-east-1",
    ) -> None:
        self.application_id = application_id
        self._access_key = access_key_id
        self._secret_key = secret_access_key
        self._session_token = session_token
        self._region = region
        self._http = httpx.Client(timeout=120)

    # ── low-level ────────────────────────────────────────────────

    def _post(self, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        payload = payload or {}
        payload.setdefault("applicationId", self.application_id)
        body = json.dumps(payload)
        url = f"{_BASE_URL}{path}"
        headers = sign_request(
            method="POST", url=url,
            headers={"content-type": "application/json"},
            body=body,
            access_key=self._access_key,
            secret_key=self._secret_key,
            session_token=self._session_token,
            region=self._region,
        )
        resp = self._http.post(url, content=body, headers=headers)
        resp.raise_for_status()
        return resp.json()

    # ── projects ─────────────────────────────────────────────────

    def list_projects(self, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listprojects", payload)

    def get_project(self, project_id: str) -> Project:
        data = self._post("/getproject", {"projectId": project_id})
        return Project.model_validate(data)

    def create_project(self, name: str, description: str = "", objective: str = "") -> dict[str, Any]:
        return self._post("/createproject", {
            "name": name, "description": description, "objective": objective,
        })

    def update_project(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/updateproject", {"projectId": project_id, **kwargs})

    def delete_project(self, project_id: str) -> dict[str, Any]:
        return self._post("/deleteproject", {"projectId": project_id})

    # ── experiments ──────────────────────────────────────────────

    def list_experiments(self, project_id: str, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"projectId": project_id}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listexperiments", payload)

    def get_experiment(self, project_id: str, experiment_id: str) -> Experiment:
        data = self._post("/getexperiment", {
            "projectId": project_id, "experimentId": experiment_id,
        })
        return Experiment.model_validate(data)

    def create_experiment(self, project_id: str, name: str, recipe_id: str,
                          recipe_version: str = "1.0", description: str = "",
                          parameters: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "projectId": project_id, "name": name,
            "recipeId": recipe_id, "recipeVersion": recipe_version,
            "description": description,
        }
        if parameters:
            payload["experimentParametersMetadata"] = parameters
        return self._post("/createexperiment", payload)

    def update_experiment(self, project_id: str, experiment_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/updateexperiment", {
            "projectId": project_id, "experimentId": experiment_id, **kwargs,
        })

    def delete_experiment(self, project_id: str, experiment_id: str) -> dict[str, Any]:
        return self._post("/deleteexperiment", {
            "projectId": project_id, "experimentId": experiment_id,
        })

    def start_experiment(self, project_id: str, experiment_id: str) -> dict[str, Any]:
        return self._post("/startexperiment", {
            "projectId": project_id, "experimentId": experiment_id,
        })

    def predict_experiment_configuration(self, project_id: str, experiment_id: str,
                                          **kwargs: Any) -> dict[str, Any]:
        return self._post("/predictexperimentconfiguration", {
            "projectId": project_id, "experimentId": experiment_id, **kwargs,
        })

    # ── results ──────────────────────────────────────────────────

    def list_results(self, project_id: str, experiment_id: str,
                     next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"projectId": project_id, "experimentId": experiment_id}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listresults", payload)

    def get_result_data(self, project_id: str, experiment_id: str,
                        result_id: str) -> dict[str, Any]:
        return self._post("/getresultdata", {
            "projectId": project_id, "experimentId": experiment_id,
            "resultId": result_id,
        })

    def get_result_metadata(self, project_id: str, experiment_id: str,
                            result_id: str) -> dict[str, Any]:
        return self._post("/getresultmetadata", {
            "projectId": project_id, "experimentId": experiment_id,
            "resultId": result_id,
        })

    # ── jobs ─────────────────────────────────────────────────────

    def list_jobs(self, project_id: str, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"projectId": project_id}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listjobs", payload)

    def get_job(self, project_id: str, job_id: str) -> dict[str, Any]:
        return self._post("/getjob", {"projectId": project_id, "jobId": job_id})

    def create_job(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/createjob", {"projectId": project_id, **kwargs})

    def start_job(self, project_id: str, job_id: str) -> dict[str, Any]:
        return self._post("/startjob", {"projectId": project_id, "jobId": job_id})

    def update_job(self, project_id: str, job_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/updatejob", {"projectId": project_id, "jobId": job_id, **kwargs})

    def delete_job(self, project_id: str, job_id: str) -> dict[str, Any]:
        return self._post("/deletejob", {"projectId": project_id, "jobId": job_id})

    # ── modules ──────────────────────────────────────────────────

    def list_hosted_modules(self, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listhostedmodules", payload)

    def get_module(self, module_id: str, module_version: Optional[str] = None) -> Module:
        payload: dict[str, Any] = {"moduleId": module_id}
        if module_version:
            payload["moduleVersion"] = module_version
        data = self._post("/gethostedmodule", payload)
        mod = Module.model_validate(data)
        io_raw = data.get("ioSpecification")
        if isinstance(io_raw, str):
            mod.io_spec = ModuleIO.model_validate(json.loads(io_raw))
        return mod

    # ── recipes ──────────────────────────────────────────────────

    def list_hosted_recipes(self, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listhostedrecipes", payload)

    def get_recipe(self, recipe_id: str, recipe_version: str = "1.0") -> Recipe:
        data = self._post("/gethostedrecipe", {
            "recipeId": recipe_id, "recipeVersion": recipe_version,
        })
        recipe = Recipe.model_validate(data)
        defn_raw = data.get("recipeDefinition")
        if isinstance(defn_raw, str):
            defn = json.loads(defn_raw)
            recipe.steps = [RecipeStep.model_validate(s) for s in defn.get("modulesGraph", [])]
        return recipe

    def list_custom_recipes(self, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listcustomrecipes", payload)

    def get_custom_recipe(self, recipe_id: str) -> dict[str, Any]:
        return self._post("/getcustomrecipe", {"recipeId": recipe_id})

    def create_custom_recipe(self, name: str, description: str = "",
                              recipe_definition: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": name, "description": description}
        if recipe_definition:
            payload["recipeDefinition"] = json.dumps(recipe_definition)
        return self._post("/createcustomrecipe", payload)

    def update_custom_recipe(self, recipe_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/updatecustomrecipe", {"recipeId": recipe_id, **kwargs})

    def delete_custom_recipe(self, recipe_id: str) -> dict[str, Any]:
        return self._post("/deletecustomrecipe", {"recipeId": recipe_id})

    def start_custom_recipe_publish(self, recipe_id: str) -> dict[str, Any]:
        return self._post("/startcustomrecipepublish", {"recipeId": recipe_id})

    # ── wet lab ──────────────────────────────────────────────────

    def list_wetlab_providers(self) -> dict[str, Any]:
        return self._post("/listwetlabproviders")

    def list_wetlab_orders(self, project_id: str, experiment_id: str,
                           next_token: Optional[str] = None) -> list[WetLabOrder]:
        payload: dict[str, Any] = {"projectId": project_id, "experimentId": experiment_id}
        if next_token:
            payload["nextToken"] = next_token
        data = self._post("/listwetlaborders", payload)
        return [WetLabOrder.model_validate(o) for o in data.get("wetlabOrders", [])]

    def get_wetlab_order(self, project_id: str, experiment_id: str,
                         order_id: str) -> dict[str, Any]:
        return self._post("/getwetlaborder", {
            "projectId": project_id, "experimentId": experiment_id, "orderId": order_id,
        })

    def get_wetlab_order_estimates(self, project_id: str, experiment_id: str,
                                   **kwargs: Any) -> dict[str, Any]:
        return self._post("/getwetlaborderestimates", {
            "projectId": project_id, "experimentId": experiment_id, **kwargs,
        })

    def create_wetlab_order(self, project_id: str, experiment_id: str,
                            **kwargs: Any) -> dict[str, Any]:
        return self._post("/createwetlaborder", {
            "projectId": project_id, "experimentId": experiment_id, **kwargs,
        })

    def cancel_wetlab_order(self, project_id: str, experiment_id: str,
                            order_id: str) -> dict[str, Any]:
        return self._post("/cancelwetlaborder", {
            "projectId": project_id, "experimentId": experiment_id, "orderId": order_id,
        })

    def delete_wetlab_order(self, project_id: str, experiment_id: str,
                            order_id: str) -> dict[str, Any]:
        return self._post("/deletewetlaborder", {
            "projectId": project_id, "experimentId": experiment_id, "orderId": order_id,
        })

    def export_wetlab_order_results(self, project_id: str, experiment_id: str,
                                     order_id: str) -> dict[str, Any]:
        return self._post("/exportwetlaborderresults", {
            "projectId": project_id, "experimentId": experiment_id, "orderId": order_id,
        })

    # ── datasets & files ─────────────────────────────────────────

    def list_datasets(self, project_id: str, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"projectId": project_id}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listdatasets", payload)

    def get_dataset_metadata(self, project_id: str, dataset_id: str) -> dict[str, Any]:
        return self._post("/getdatasetmetadata", {
            "projectId": project_id, "datasetId": dataset_id,
        })

    def import_dataset(self, project_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/importdataset", {"projectId": project_id, **kwargs})

    def export_dataset(self, project_id: str, dataset_id: str) -> dict[str, Any]:
        return self._post("/exportdataset", {
            "projectId": project_id, "datasetId": dataset_id,
        })

    def update_dataset(self, project_id: str, dataset_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/updatedataset", {
            "projectId": project_id, "datasetId": dataset_id, **kwargs,
        })

    def start_dataset_multipart_upload(self, project_id: str, filename: str,
                                        **kwargs: Any) -> dict[str, Any]:
        return self._post("/startdatasetmultipartupload", {
            "projectId": project_id, "filename": filename, **kwargs,
        })

    def resume_dataset_multipart_upload(self, project_id: str,
                                         upload_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/resumedatasetmultipartupload", {
            "projectId": project_id, "uploadId": upload_id, **kwargs,
        })

    def complete_dataset_multipart_upload(self, project_id: str,
                                           upload_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/completedatasetmultipartupload", {
            "projectId": project_id, "uploadId": upload_id, **kwargs,
        })

    def get_file_metadata(self, project_id: str, file_id: str) -> dict[str, Any]:
        return self._post("/getfilemetadata", {
            "projectId": project_id, "fileId": file_id,
        })

    def export_file(self, project_id: str, file_id: str) -> dict[str, Any]:
        return self._post("/exportfile", {"projectId": project_id, "fileId": file_id})

    def delete_file(self, project_id: str, file_id: str) -> dict[str, Any]:
        return self._post("/deletefile", {"projectId": project_id, "fileId": file_id})

    # ── components ───────────────────────────────────────────────

    def list_components(self, project_id: str, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"projectId": project_id}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listcomponents", payload)

    def get_component(self, project_id: str, component_id: str) -> dict[str, Any]:
        return self._post("/getcomponent", {
            "projectId": project_id, "componentId": component_id,
        })

    def update_component_metadata(self, project_id: str, component_id: str,
                                   **kwargs: Any) -> dict[str, Any]:
        return self._post("/updatecomponentmetadata", {
            "projectId": project_id, "componentId": component_id, **kwargs,
        })

    def delete_component(self, project_id: str, component_id: str) -> dict[str, Any]:
        return self._post("/deletecomponent", {
            "projectId": project_id, "componentId": component_id,
        })

    # ── analysis ─────────────────────────────────────────────────

    def get_analysis(self, project_id: str, experiment_id: str,
                     analysis_id: str) -> dict[str, Any]:
        return self._post("/getanalysis", {
            "projectId": project_id, "experimentId": experiment_id,
            "analysisId": analysis_id,
        })

    # ── usage ────────────────────────────────────────────────────

    def get_usage(self) -> dict[str, Any]:
        return self._post("/getusage")

    # ── sharing & permissions ────────────────────────────────────

    def list_resource_permissions(self, resource_id: str) -> dict[str, Any]:
        return self._post("/listresourcepermissions", {"resourceId": resource_id})

    def create_resource_permission(self, resource_id: str, principal_id: str,
                                    **kwargs: Any) -> dict[str, Any]:
        return self._post("/createresourcepermission", {
            "resourceId": resource_id, "principalId": principal_id, **kwargs,
        })

    def update_resource_permission(self, resource_id: str, principal_id: str,
                                    **kwargs: Any) -> dict[str, Any]:
        return self._post("/updateresourcepermission", {
            "resourceId": resource_id, "principalId": principal_id, **kwargs,
        })

    def delete_resource_permission(self, resource_id: str, principal_id: str) -> dict[str, Any]:
        return self._post("/deleteresourcepermission", {
            "resourceId": resource_id, "principalId": principal_id,
        })

    def update_principal_permissions(self, principal_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/updateprincipalpermissions", {
            "principalId": principal_id, **kwargs,
        })

    def list_principals(self, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listprincipals", payload)

    # ── Identity Center ──────────────────────────────────────────

    def list_idc_users(self, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listidcusers", payload)

    def list_idc_groups(self, next_token: Optional[str] = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if next_token:
            payload["nextToken"] = next_token
        return self._post("/listidcgroups", payload)

    def associate_idc_principal(self, principal_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._post("/associateidcprincipal", {"principalId": principal_id, **kwargs})

    def disassociate_idc_principal(self, principal_id: str) -> dict[str, Any]:
        return self._post("/disassociateidcprincipal", {"principalId": principal_id})

    # ── user & session ───────────────────────────────────────────

    def get_user_details(self) -> dict[str, Any]:
        return self._post("/getuserdetails")

    def list_feature_flags(self) -> list[str]:
        data = self._post("/listfrontendfeatures")
        return data.get("featureFlags", [])

    # ── context manager ──────────────────────────────────────────

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> BioDiscoveryClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
