"""MedMap → Bio Discovery bridge.

Connects Nodes Bio's pathway visualization (MedMap) to Amazon Bio Discovery's
antibody design pipeline. The workflow:

    1. MedMap visualizes a disease pathway
    2. User identifies antibody-targetable protein nodes
    3. Bridge resolves protein → PDB structure → epitope hotspots
    4. Output is ready to feed into Bio Discovery's RFantibody module

This is the "before the button" layer — understand the biology before you
spend Experiment Units.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx


# ── Data models ──────────────────────────────────────────────────

@dataclass
class PathwayTarget:
    """A druggable protein node identified from a MedMap pathway."""

    gene_symbol: str
    uniprot_id: Optional[str] = None
    protein_name: Optional[str] = None
    pdb_ids: list[str] = field(default_factory=list)
    rationale: str = ""


@dataclass
class DesignReady:
    """A target fully resolved and ready for Bio Discovery input."""

    gene_symbol: str
    uniprot_id: str
    pdb_id: str
    pdb_path: Optional[str] = None
    hotspot_residues: list[str] = field(default_factory=list)
    hotspot_string: str = ""
    epitope_source: str = ""
    rationale: str = ""

    def to_rfantibody_params(self, framework: str = "h-NbBCII10",
                              num_designs: int = 10) -> dict[str, Any]:
        """Generate experiment parameters for Bio Discovery's RFantibody module."""
        return {
            "rfantibody_input_target_pdb": {
                "dataLabel": [f"{self.pdb_id}.pdb"],
                "dataType": "FILE",
                "parameterConfiguration": "FIXED",
            },
            "rfantibody_input_framework_pdb": {
                "data": [framework],
                "dataType": "HOSTED_FILE",
                "parameterConfiguration": "FIXED",
            },
            "rfantibody_input_hotspot_res": {
                "data": [self.hotspot_string],
                "dataType": "STRING",
                "parameterConfiguration": "FIXED",
            },
            "rfantibody_input_num_designs": {
                "data": [str(num_designs)],
                "dataType": "INTEGER",
                "parameterConfiguration": "FIXED",
            },
            "rfantibody_input_design_loops": {
                "data": ["[L1:, L2:, L3:, H1:, H2:, H3:]"],
                "dataType": "STRING",
                "parameterConfiguration": "FIXED",
            },
            "rfantibody_input_loop_string": {
                "data": ["H1,H2,H3,L1,L2,L3"],
                "dataType": "STRING",
                "parameterConfiguration": "FIXED",
            },
            "esm2pseudo_log_likelihood_input_model_type": {
                "data": ["esm"],
                "dataType": "STRING",
                "parameterConfiguration": "FIXED",
            },
        }


# ── UniProt resolver ─────────────────────────────────────────────

def resolve_uniprot(gene_symbol: str, organism: str = "human") -> Optional[str]:
    """Resolve a gene symbol to a UniProt accession via the UniProt API."""
    taxon = "9606" if organism == "human" else organism
    url = "https://rest.uniprot.org/uniprotkb/search"
    params = {
        "query": f"gene_exact:{gene_symbol} AND organism_id:{taxon} AND reviewed:true",
        "format": "json",
        "size": "1",
    }
    resp = httpx.get(url, params=params, timeout=15)
    resp.raise_for_status()
    results = resp.json().get("results", [])
    return results[0]["primaryAccession"] if results else None


# ── PDB resolver ─────────────────────────────────────────────────

def resolve_pdb_ids(uniprot_id: str) -> list[str]:
    """Get PDB IDs for a UniProt accession via the PDBe API."""
    url = f"https://www.ebi.ac.uk/pdbe/api/mappings/uniprot/{uniprot_id}"
    resp = httpx.get(url, timeout=15)
    if resp.status_code == 404:
        return []
    resp.raise_for_status()
    data = resp.json()
    return list(data.get(uniprot_id, {}).get("PDB", {}).keys())


def download_pdb(pdb_id: str, output_dir: str = ".") -> str:
    """Download a PDB file from RCSB."""
    url = f"https://files.rcsb.org/download/{pdb_id.upper()}.pdb"
    resp = httpx.get(url, timeout=30)
    resp.raise_for_status()
    path = f"{output_dir}/{pdb_id.upper()}.pdb"
    with open(path, "w") as f:
        f.write(resp.text)
    return path


# ── Epitope / hotspot resolution ─────────────────────────────────

def resolve_epitopes_iedb(uniprot_id: str, limit: int = 20) -> list[dict[str, Any]]:
    """Query IEDB for known epitopes on a protein."""
    url = "https://query-api.iedb.org/epitope_search"
    params = {
        "source_antigen_accession": uniprot_id,
        "linear_sequence_length_min": 5,
        "linear_sequence_length_max": 30,
        "limit": limit,
    }
    resp = httpx.get(url, params=params, timeout=15)
    if resp.status_code != 200:
        return []
    return resp.json()


def epitopes_to_hotspot_string(epitopes: list[dict[str, Any]],
                                max_residues: int = 10) -> str:
    """Convert IEDB epitope data to Bio Discovery hotspot residue format.

    Returns format like: [T12,T30,T73]
    """
    positions: set[int] = set()
    for ep in epitopes:
        start = ep.get("starting_position") or ep.get("e_start")
        end = ep.get("ending_position") or ep.get("e_end")
        if start and end:
            mid = (int(start) + int(end)) // 2
            positions.add(mid)
    # Take the most spread-out residues up to max
    sorted_pos = sorted(positions)[:max_residues]
    if not sorted_pos:
        return "[]"
    return "[" + ",".join(f"T{p}" for p in sorted_pos) + "]"


# ── Main bridge function ─────────────────────────────────────────

def pathway_to_design(
    gene_symbol: str,
    rationale: str = "",
    organism: str = "human",
    output_dir: str = ".",
) -> DesignReady:
    """Full bridge: gene symbol → UniProt → PDB → epitopes → Bio Discovery params.

    Args:
        gene_symbol: Target protein gene symbol (e.g., "TNF", "IL6", "CD28").
        rationale: Why this target was selected from the pathway.
        organism: Target organism (default "human").
        output_dir: Directory to save downloaded PDB file.

    Returns:
        DesignReady object with everything needed for Bio Discovery.

    Example::

        target = pathway_to_design("TNF", rationale="Key node in neuroinflammatory cascade")
        params = target.to_rfantibody_params(num_designs=50)
        client.create_experiment(project_id, "tnf-denovo", recipe_id, parameters=params)
    """
    # Step 1: Gene → UniProt
    uniprot_id = resolve_uniprot(gene_symbol, organism)
    if not uniprot_id:
        raise ValueError(f"Could not resolve {gene_symbol} to UniProt accession")

    # Step 2: UniProt → PDB structures
    pdb_ids = resolve_pdb_ids(uniprot_id)
    if not pdb_ids:
        raise ValueError(f"No PDB structures found for {uniprot_id} ({gene_symbol})")
    pdb_id = pdb_ids[0]  # Best/first structure

    # Step 3: Download PDB
    pdb_path = download_pdb(pdb_id, output_dir)

    # Step 4: Get epitope data → hotspot residues
    epitopes = resolve_epitopes_iedb(uniprot_id)
    hotspot_str = epitopes_to_hotspot_string(epitopes)
    hotspot_residues = [r.strip() for r in hotspot_str.strip("[]").split(",") if r.strip()]
    source = f"IEDB ({len(epitopes)} epitopes)" if epitopes else "none (manual selection needed)"

    return DesignReady(
        gene_symbol=gene_symbol,
        uniprot_id=uniprot_id,
        pdb_id=pdb_id,
        pdb_path=pdb_path,
        hotspot_residues=hotspot_residues,
        hotspot_string=hotspot_str,
        epitope_source=source,
        rationale=rationale,
    )


def batch_pathway_to_design(
    targets: list[dict[str, str]],
    output_dir: str = ".",
) -> list[DesignReady]:
    """Resolve multiple pathway targets in batch.

    Args:
        targets: List of dicts with 'gene_symbol' and optional 'rationale'.

    Example::

        targets = [
            {"gene_symbol": "TNF", "rationale": "Pro-inflammatory cytokine"},
            {"gene_symbol": "IL6", "rationale": "Acute phase response mediator"},
            {"gene_symbol": "GFAP", "rationale": "Astrocyte activation marker"},
        ]
        ready = batch_pathway_to_design(targets)
    """
    results = []
    for t in targets:
        try:
            r = pathway_to_design(
                gene_symbol=t["gene_symbol"],
                rationale=t.get("rationale", ""),
                output_dir=output_dir,
            )
            results.append(r)
            print(f"  ✅ {t['gene_symbol']} → {r.pdb_id} ({r.epitope_source})")
        except ValueError as e:
            print(f"  ❌ {t['gene_symbol']}: {e}")
    return results
