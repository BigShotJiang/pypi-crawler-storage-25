"""Pydantic models for Amazon Bio Discovery API objects."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class Project(BaseModel):
    project_id: str = Field(alias="projectId")
    name: str
    description: Optional[str] = None
    objective: Optional[str] = None
    author: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    last_updated_at: Optional[datetime] = Field(None, alias="lastUpdatedAt")

    model_config = {"populate_by_name": True}


class RecipeDetails(BaseModel):
    recipe_id: str = Field(alias="recipeId")
    recipe_version: Optional[str] = Field(None, alias="recipeVersion")
    name: Optional[str] = None

    model_config = {"populate_by_name": True}


class Experiment(BaseModel):
    experiment_id: str = Field(alias="experimentId")
    project_id: str = Field(alias="projectId")
    name: Optional[str] = None
    description: Optional[str] = None
    author: Optional[str] = None
    status: Optional[str] = None
    estimated_experiment_units: Optional[float] = Field(None, alias="estimatedExperimentUnits")
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    ended_at: Optional[datetime] = Field(None, alias="endedAt")
    last_updated_at: Optional[datetime] = Field(None, alias="lastUpdatedAt")
    recipe_details: Optional[RecipeDetails] = Field(None, alias="recipeDetails")
    parameters: Optional[dict[str, Any]] = Field(None, alias="experimentParametersMetadata")
    configured_count: Optional[int] = Field(None, alias="configuredExperimentsCount")
    failed_count: Optional[int] = Field(None, alias="failedExperimentsCount")
    message: Optional[str] = None

    model_config = {"populate_by_name": True}


class ModuleIO(BaseModel):
    module_type: Optional[str] = Field(None, alias="moduleType")
    inputs: Optional[dict[str, Any]] = None
    outputs: Optional[dict[str, Any]] = None

    model_config = {"populate_by_name": True}


class Module(BaseModel):
    module_id: str = Field(alias="moduleId")
    name: Optional[str] = None
    description: Optional[str] = None
    module_version: Optional[str] = Field(None, alias="moduleVersion")
    module_type: Optional[str] = Field(None, alias="type")
    status: Optional[str] = None
    io_spec: Optional[ModuleIO] = None
    licensing: Optional[dict[str, Any]] = None
    created_at: Optional[datetime] = Field(None, alias="createdAt")
    last_updated_at: Optional[datetime] = Field(None, alias="lastUpdatedAt")

    model_config = {"populate_by_name": True}


class RecipeStep(BaseModel):
    step_name: str = Field(alias="stepName")
    module_id: str = Field(alias="moduleId")
    module_version: Optional[str] = Field(None, alias="moduleVersion")
    dependencies: list[dict[str, Any]] = Field(default_factory=list)

    model_config = {"populate_by_name": True}


class Recipe(BaseModel):
    recipe_id: str = Field(alias="recipeId")
    recipe_version: Optional[str] = Field(None, alias="recipeVersion")
    name: Optional[str] = None
    description: Optional[str] = None
    author: Optional[str] = None
    publisher: Optional[str] = None
    steps: list[RecipeStep] = Field(default_factory=list)
    last_updated_at: Optional[datetime] = Field(None, alias="lastUpdatedAt")

    model_config = {"populate_by_name": True}


class WetLabOrder(BaseModel):
    order_id: Optional[str] = Field(None, alias="orderId")
    status: Optional[str] = None
    cro_partner: Optional[str] = Field(None, alias="croPartner")
    assays: list[str] = Field(default_factory=list)
    created_at: Optional[datetime] = Field(None, alias="createdAt")

    model_config = {"populate_by_name": True}
