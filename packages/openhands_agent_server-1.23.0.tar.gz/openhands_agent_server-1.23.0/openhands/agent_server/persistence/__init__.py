"""Persistence module for settings and secrets storage.

Note: API request/response models (SecretCreateRequest, SecretItemResponse,
SecretsListResponse, SettingsResponse, SettingsUpdateRequest) are defined
in the SDK to enable sharing between SDK clients and agent-server.
See: openhands.sdk.settings.api_models
"""

from openhands.agent_server.persistence.models import (
    PERSISTED_SETTINGS_SCHEMA_VERSION,
    SECRET_NAME_PATTERN,
    WORKSPACES_SCHEMA_VERSION,
    CustomSecret,
    PersistedSettings,
    PersistedWorkspaces,
    Secrets,
    SettingsUpdatePayload,
    WorkspaceItem,
    WorkspaceParentItem,
)
from openhands.agent_server.persistence.store import (
    FileSecretsStore,
    FileSettingsStore,
    FileWorkspacesStore,
    SecretsStore,
    SettingsStore,
    WorkspacesStore,
    get_secrets_store,
    get_settings_store,
    get_workspaces_store,
    reset_stores,
)


__all__ = [
    # Constants
    "PERSISTED_SETTINGS_SCHEMA_VERSION",
    "SECRET_NAME_PATTERN",
    "WORKSPACES_SCHEMA_VERSION",
    # Models
    "CustomSecret",
    "PersistedSettings",
    "PersistedWorkspaces",
    "Secrets",
    "SettingsUpdatePayload",
    "WorkspaceItem",
    "WorkspaceParentItem",
    # Stores
    "FileSecretsStore",
    "FileSettingsStore",
    "FileWorkspacesStore",
    "SecretsStore",
    "SettingsStore",
    "WorkspacesStore",
    "get_secrets_store",
    "get_settings_store",
    "get_workspaces_store",
    "reset_stores",
]
