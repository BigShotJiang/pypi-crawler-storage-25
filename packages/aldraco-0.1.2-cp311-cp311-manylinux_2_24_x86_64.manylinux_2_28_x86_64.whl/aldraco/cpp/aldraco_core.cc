#include "aldraco_core.h"

#include <array>
#include <memory>
#include <string>

#include "draco/attributes/geometry_attribute.h"
#include "draco/compression/decode.h"
#include "draco/compression/encode.h"
#include "draco/core/decoder_buffer.h"
#include "draco/core/encoder_buffer.h"
#include "draco/core/status_or.h"
#include "draco/mesh/mesh.h"
#include "draco/mesh/mesh_utils.h"
#include "draco/metadata/geometry_metadata.h"
#include "draco/point_cloud/point_cloud.h"
#include "draco/point_cloud/point_cloud_builder.h"

#include "zlib.h"

namespace AldracoCore {

static bool GetAttributeTypeTag(const draco::PointCloud &pc, int att_id,
                                std::string *out) {
  const auto *md = pc.GetAttributeMetadataByAttributeId(att_id);
  if (!md) return false;
  std::string v;
  if (!md->GetEntryString("i3s-attribute-type", &v)) return false;
  *out = v;
  return true;
}

static bool GetFeatureIdsFromMetadata(const draco::PointCloud &pc, int att_id,
                                      std::vector<int32_t> *out) {
  const auto *md = pc.GetAttributeMetadataByAttributeId(att_id);
  if (!md) return false;
  return md->GetEntryIntArray("i3s-feature-ids", out);
}

static std::string GetAttributeName(const draco::PointCloud &pc, int att_id) {
  const auto *md = pc.GetAttributeMetadataByAttributeId(att_id);
  if (!md) return {};
  std::string name;
  if (md->GetEntryString("name", &name)) return name;
  if (md->GetEntryString("i3s-attribute-type", &name)) return name;
  return {};
}

static void AppendAttributeData(const draco::PointCloud &pc,
                                const draco::PointAttribute &att, int att_id,
                                AttributeObject *out) {
  out->unique_id = att.unique_id();
  out->num_components = att.num_components();
  out->data_type = static_cast<int>(att.data_type());
  out->attribute_type = static_cast<int>(att.attribute_type());
  out->name = GetAttributeName(pc, att_id);

  const int nc = att.num_components();
  const int npts = pc.num_points();

  // Store in a type-appropriate vector, using ConvertValue so quantized types
  // are converted to requested scalar type.
  switch (att.data_type()) {
    case draco::DT_FLOAT32:
    case draco::DT_FLOAT64: {
      out->float_data.reserve(static_cast<size_t>(nc) * npts);
      std::vector<float> tmp(nc);
      for (draco::PointIndex p(0); p < npts; ++p) {
        if (!att.ConvertValue<float>(att.mapped_index(p), nc, tmp.data())) break;
        out->float_data.insert(out->float_data.end(), tmp.begin(), tmp.end());
      }
      return;
    }
    case draco::DT_UINT8:
    case draco::DT_INT8:
    case draco::DT_BOOL: {
      out->byte_data.reserve(static_cast<size_t>(nc) * npts);
      std::vector<uint8_t> tmp(nc);
      for (draco::PointIndex p(0); p < npts; ++p) {
        if (!att.ConvertValue<uint8_t>(att.mapped_index(p), nc, tmp.data()))
          break;
        out->byte_data.insert(out->byte_data.end(), tmp.begin(), tmp.end());
      }
      return;
    }
    case draco::DT_UINT16:
    case draco::DT_INT16: {
      out->uint16_data.reserve(static_cast<size_t>(nc) * npts);
      std::vector<uint16_t> tmp(nc);
      for (draco::PointIndex p(0); p < npts; ++p) {
        if (!att.ConvertValue<uint16_t>(att.mapped_index(p), nc, tmp.data()))
          break;
        out->uint16_data.insert(out->uint16_data.end(), tmp.begin(), tmp.end());
      }
      return;
    }
    default: {
      // Fall back to uint32 for integer-ish attributes.
      out->uint_data.reserve(static_cast<size_t>(nc) * npts);
      std::vector<uint32_t> tmp(nc);
      for (draco::PointIndex p(0); p < npts; ++p) {
        if (!att.ConvertValue<uint32_t>(att.mapped_index(p), nc, tmp.data()))
          break;
        out->uint_data.insert(out->uint_data.end(), tmp.begin(), tmp.end());
      }
      return;
    }
  }
}

MeshObject decode_buffer_ex(const char *buffer, std::size_t buffer_len, bool collect_attributes) {
  MeshObject out;

  draco::DecoderBuffer dbuf;
  dbuf.Init(buffer, buffer_len);

  auto type_or = draco::Decoder::GetEncodedGeometryType(&dbuf);
  if (!type_or.ok()) {
    out.decode_status = not_draco_encoded;
    return out;
  }
  const auto geotype = type_or.value();
  if (geotype == draco::EncodedGeometryType::INVALID_GEOMETRY_TYPE) {
    out.decode_status = not_draco_encoded;
    return out;
  }

  draco::Decoder decoder;
  std::unique_ptr<draco::Mesh> mesh_owner;
  std::unique_ptr<draco::PointCloud> pc_owner;
  draco::PointCloud *pc = nullptr;
  draco::Mesh *mesh = nullptr;

  if (geotype == draco::EncodedGeometryType::TRIANGULAR_MESH) {
    auto status_or = decoder.DecodeMeshFromBuffer(&dbuf);
    if (!status_or.ok()) {
      out.decode_status = failed_during_decoding;
      return out;
    }
    mesh_owner = std::move(status_or).value();
    mesh = mesh_owner.get();
    pc = mesh;
  } else if (geotype == draco::EncodedGeometryType::POINT_CLOUD) {
    auto status_or = decoder.DecodePointCloudFromBuffer(&dbuf);
    if (!status_or.ok()) {
      out.decode_status = failed_during_decoding;
      return out;
    }
    pc_owner = std::move(status_or).value();
    pc = pc_owner.get();
    mesh = static_cast<draco::Mesh *>(pc);
  } else {
    out.decode_status = failed_during_decoding;
    return out;
  }

  // POSITION is required to expose points.
  const int pos_att_id = pc->GetNamedAttributeId(draco::GeometryAttribute::POSITION);
  if (pos_att_id < 0) {
    out.decode_status = no_position_attribute;
    return out;
  }

  // i3s position scaling: metadata stored on POSITION attribute.
  double scale_x = 1.0, scale_y = 1.0;
  if (const auto *pos_md = pc->GetAttributeMetadataByAttributeId(pos_att_id)) {
    pos_md->GetEntryDouble("i3s-scale_x", &scale_x);
    pos_md->GetEntryDouble("i3s-scale_y", &scale_y);
  }

  const auto *pos_att = pc->attribute(pos_att_id);
  out.points.reserve(static_cast<size_t>(pc->num_points()) * 3);
  std::array<float, 3> pv{};
  for (draco::PointIndex p(0); p < pc->num_points(); ++p) {
    if (!pos_att->ConvertValue<float, 3>(pos_att->mapped_index(p), pv.data())) {
      out.decode_status = failed_during_decoding;
      return out;
    }
    out.points.push_back(static_cast<float>(pv[0] * scale_x));
    out.points.push_back(static_cast<float>(pv[1] * scale_y));
    out.points.push_back(pv[2]);
  }

  // Collect all attributes (including GENERIC). This can be very memory heavy for
  // large datasets, so it is optional.
  if (collect_attributes) {
    out.attributes.reserve(pc->num_attributes());
    for (int att_id = 0; att_id < pc->num_attributes(); ++att_id) {
      const auto *att = pc->attribute(att_id);
      if (!att) continue;
      AttributeObject ao;
      AppendAttributeData(*pc, *att, att_id, &ao);
      out.attributes.push_back(std::move(ao));
    }
  }

  // Standard attributes: COLOR, NORMAL, TEX_COORD (first set).
  const int color_att_id = pc->GetNamedAttributeId(draco::GeometryAttribute::COLOR);
  if (color_att_id >= 0) {
    const auto *att = pc->attribute(color_att_id);
    out.colors_channel = att->num_components();
    out.colors.reserve(static_cast<size_t>(out.colors_channel) * pc->num_points());
    std::vector<uint8_t> tmp(out.colors_channel);
    for (draco::PointIndex p(0); p < pc->num_points(); ++p) {
      if (!att->ConvertValue<uint8_t>(att->mapped_index(p), out.colors_channel,
                                      tmp.data()))
        break;
      out.colors.insert(out.colors.end(), tmp.begin(), tmp.end());
    }
  }

  const int tex_att_id = pc->GetNamedAttributeId(draco::GeometryAttribute::TEX_COORD);
  if (tex_att_id >= 0) {
    const auto *att = pc->attribute(tex_att_id);
    const int nc = att->num_components();
    out.tex_coord.reserve(static_cast<size_t>(nc) * pc->num_points());
    std::vector<float> tmp(nc);
    for (draco::PointIndex p(0); p < pc->num_points(); ++p) {
      if (!att->ConvertValue<float>(att->mapped_index(p), nc, tmp.data())) break;
      out.tex_coord.insert(out.tex_coord.end(), tmp.begin(), tmp.end());
    }
  }

  const int normal_att_id = pc->GetNamedAttributeId(draco::GeometryAttribute::NORMAL);
  if (normal_att_id >= 0) {
    const auto *att = pc->attribute(normal_att_id);
    out.normals.reserve(static_cast<size_t>(3) * pc->num_points());
    std::array<float, 3> tmp{};
    for (draco::PointIndex p(0); p < pc->num_points(); ++p) {
      if (!att->ConvertValue<float, 3>(att->mapped_index(p), tmp.data())) break;
      out.normals.push_back(tmp[0]);
      out.normals.push_back(tmp[1]);
      out.normals.push_back(tmp[2]);
    }
  }

  // i3s: identify uv-region / feature-index via attribute metadata key
  // "i3s-attribute-type" (per spec), instead of num_components guessing.
  const int generic_count = pc->NumNamedAttributes(draco::GeometryAttribute::GENERIC);
  for (int i = 0; i < generic_count; ++i) {
    const int att_id = pc->GetNamedAttributeId(draco::GeometryAttribute::GENERIC, i);
    if (att_id < 0) continue;
    std::string tag;
    if (!GetAttributeTypeTag(*pc, att_id, &tag)) continue;
    const auto *att = pc->attribute(att_id);
    if (!att) continue;

    if (tag == "uv-region") {
      // Spec: 4xUINT16 (normalized). We still decode via ConvertValue<uint16_t>.
      if (att->num_components() != 4) continue;
      out.uvr_components = 4;
      out.uvr.clear();
      out.uvr.reserve(static_cast<size_t>(out.uvr_components) * pc->num_points());
      std::vector<uint16_t> tmp(out.uvr_components);
      for (draco::PointIndex p(0); p < pc->num_points(); ++p) {
        if (!att->ConvertValue<uint16_t>(att->mapped_index(p), out.uvr_components,
                                         tmp.data()))
          { out.uvr.clear(); out.uvr_components = 0; break; }
        out.uvr.insert(out.uvr.end(), tmp.begin(), tmp.end());
      }
    } else if (tag == "feature-index") {
      // Spec: 1xUINT32
      if (att->num_components() != 1) continue;
      out.feature_index_components = 1;
      out.feature_index.clear();
      out.feature_index.reserve(static_cast<size_t>(out.feature_index_components) *
                                pc->num_points());
      std::vector<uint32_t> tmp(out.feature_index_components);
      for (draco::PointIndex p(0); p < pc->num_points(); ++p) {
        if (!att->ConvertValue<uint32_t>(att->mapped_index(p),
                                         out.feature_index_components, tmp.data()))
          { out.feature_index.clear(); out.feature_index_components = 0; break; }
        out.feature_index.insert(out.feature_index.end(), tmp.begin(), tmp.end());
      }

      // feature-ids are stored in attribute metadata (int32 array)
      out.feature_ids.clear();
      GetFeatureIdsFromMetadata(*pc, att_id, &out.feature_ids);
    }
  }

  // Geometry metadata: quantization info (compatible with DracoPy behavior).
  if (const auto *md = pc->GetMetadata()) {
    md->GetEntryInt("quantization_bits", &(out.quantization_bits));
    if (md->GetEntryDouble("quantization_range", &(out.quantization_range)) &&
        md->GetEntryDoubleArray("quantization_origin", &(out.quantization_origin))) {
      out.encoding_options_set = true;
    }
  }

  // Faces only for meshes.
  if (geotype == draco::EncodedGeometryType::TRIANGULAR_MESH && mesh) {
    out.faces.reserve(static_cast<size_t>(mesh->num_faces()) * 3);
    for (draco::FaceIndex f(0); f < mesh->num_faces(); ++f) {
      const auto &face = mesh->face(f);
      out.faces.push_back(face[0].value());
      out.faces.push_back(face[1].value());
      out.faces.push_back(face[2].value());
    }
  }

  out.decode_status = successful;
  return out;
}

MeshObject decode_buffer(const char *buffer, std::size_t buffer_len) {
  return decode_buffer_ex(buffer, buffer_len, true);
}

static void SetupEncoderMetadata(draco::PointCloud *pc, draco::Encoder &enc,
                                 int compression_level, int quantization_bits,
                                 float quantization_range,
                                 const float *quantization_origin,
                                 bool create_metadata) {
  const int speed = 10 - compression_level;
  enc.SetSpeedOptions(speed, speed);

  if (!create_metadata) {
    if (!quantization_origin || quantization_range <= 0.f) {
      enc.SetAttributeQuantization(draco::GeometryAttribute::POSITION, quantization_bits);
    } else {
      enc.SetAttributeExplicitQuantization(draco::GeometryAttribute::POSITION, quantization_bits, 3,
                                           quantization_origin, quantization_range);
    }
    return;
  }

  auto md = std::make_unique<draco::GeometryMetadata>();
  if (!quantization_origin || quantization_range <= 0.f) {
    enc.SetAttributeQuantization(draco::GeometryAttribute::POSITION, quantization_bits);
  } else {
    enc.SetAttributeExplicitQuantization(draco::GeometryAttribute::POSITION, quantization_bits, 3,
                                         quantization_origin, quantization_range);
    md->AddEntryDouble("quantization_range", quantization_range);
    std::vector<double> origin;
    origin.reserve(3);
    for (int i = 0; i < 3; ++i) origin.push_back(quantization_origin[i]);
    md->AddEntryDoubleArray("quantization_origin", origin);
  }
  md->AddEntryInt("quantization_bits", quantization_bits);
  pc->AddMetadata(std::move(md));
}

EncodedObject encode_point_cloud(const std::vector<float> &points,
                                 int quantization_bits, int compression_level,
                                 float quantization_range,
                                 const float *quantization_origin,
                                 bool preserve_order, bool create_metadata,
                                 const std::vector<std::uint8_t> &colors,
                                 std::uint8_t colors_channel,
                                 const std::vector<GenericAttributeInput> &generic_attributes,
                                 bool write_i3s_scale_xy, double i3s_scale_x,
                                 double i3s_scale_y) {
  EncodedObject out;
  const int num_points = static_cast<int>(points.size() / 3);
  draco::PointCloudBuilder pcb;
  pcb.Start(num_points);
  const int pos_att_id =
      pcb.AddAttribute(draco::GeometryAttribute::POSITION, 3, draco::DT_FLOAT32);

  int col_att_id = -1;
  if (colors_channel) {
    col_att_id =
        pcb.AddAttribute(draco::GeometryAttribute::COLOR, colors_channel, draco::DT_UINT8);
  }

  for (draco::PointIndex p(0); p < num_points; ++p) {
    pcb.SetAttributeValueForPoint(pos_att_id, p, points.data() + 3 * p.value());
    if (col_att_id >= 0) {
      pcb.SetAttributeValueForPoint(col_att_id, p,
                                    colors.data() + colors_channel * p.value());
    }
  }

  if (write_i3s_scale_xy) {
    auto md = std::make_unique<draco::AttributeMetadata>();
    md->AddEntryDouble("i3s-scale_x", i3s_scale_x);
    md->AddEntryDouble("i3s-scale_y", i3s_scale_y);
    pcb.AddAttributeMetadata(pos_att_id, std::move(md));
  }

  // Generic attributes (DracoPy-compatible)
  for (size_t gidx = 0; gidx < generic_attributes.size(); ++gidx) {
    const auto &ga = generic_attributes[gidx];
    const auto dtype = static_cast<draco::DataType>(ga.data_type);
    const int att_id = pcb.AddAttribute(draco::GeometryAttribute::GENERIC,
                                        static_cast<int8_t>(ga.num_components),
                                        dtype, ga.normalized);
    if (att_id < 0) continue;
    if (ga.has_unique_id) pcb.SetAttributeUniqueId(att_id, ga.unique_id);

    // Fill attribute values
    const int stride = 0;  // let builder compute
    switch (dtype) {
      case draco::DT_FLOAT32:
      case draco::DT_FLOAT64:
        pcb.SetAttributeValuesForAllPoints(att_id, ga.float_data.data(), stride);
        break;
      case draco::DT_UINT8:
        pcb.SetAttributeValuesForAllPoints(att_id, ga.uint8_data.data(), stride);
        break;
      case draco::DT_UINT16:
        pcb.SetAttributeValuesForAllPoints(att_id, ga.uint16_data.data(), stride);
        break;
      default:
        pcb.SetAttributeValuesForAllPoints(att_id, ga.uint_data.data(), stride);
        break;
    }

    if (!ga.name.empty()) {
      auto md = std::make_unique<draco::AttributeMetadata>();
      md->AddEntryString("name", ga.name);
      pcb.AddAttributeMetadata(att_id, std::move(md));
    }
  }

  std::unique_ptr<draco::PointCloud> pc = pcb.Finalize(!preserve_order);
  draco::Encoder enc;
  SetupEncoderMetadata(pc.get(), enc, compression_level, quantization_bits,
                       quantization_range, quantization_origin, create_metadata);
  if (preserve_order) enc.SetEncodingMethod(draco::POINT_CLOUD_SEQUENTIAL_ENCODING);

  draco::EncoderBuffer buf;
  const draco::Status st = enc.EncodePointCloudToBuffer(*pc, &buf);
  if (!st.ok()) {
    out.encode_status = failed_during_encoding;
    return out;
  }
  out.buffer.assign(reinterpret_cast<const std::uint8_t *>(buf.data()),
                    reinterpret_cast<const std::uint8_t *>(buf.data()) + buf.size());
  out.encode_status = successful_encoding;
  return out;
}

EncodedObject encode_mesh(const std::vector<float> &points,
                          const std::vector<std::uint32_t> &faces,
                          int quantization_bits, int compression_level,
                          float quantization_range,
                          const float *quantization_origin,
                          bool preserve_order, bool create_metadata,
                          const std::vector<std::uint8_t> &colors,
                          std::uint8_t colors_channel,
                          const std::vector<float> &tex_coord,
                          std::uint8_t tex_coord_channel,
                          const std::vector<float> &normals,
                          const std::vector<std::uint16_t> &uvr,
                          int uvr_components,
                          const std::vector<std::uint32_t> &feature_index,
                          int feature_index_components,
                          const std::vector<std::int32_t> &feature_ids,
                          const std::vector<GenericAttributeInput> &generic_attributes,
                          bool write_i3s_scale_xy, double i3s_scale_x,
                          double i3s_scale_y) {
  EncodedObject out;

  draco::Mesh mesh;
  const int num_points = static_cast<int>(points.size() / 3);
  mesh.set_num_points(num_points);

  // POSITION
  draco::GeometryAttribute pos;
  pos.Init(draco::GeometryAttribute::POSITION, nullptr, 3, draco::DT_FLOAT32, false,
           sizeof(float) * 3, 0);
  const int pos_att_id = mesh.AddAttribute(pos, true, num_points);

  // Optional attributes
  int col_att_id = -1;
  if (colors_channel) {
    draco::GeometryAttribute col;
    col.Init(draco::GeometryAttribute::COLOR, nullptr, colors_channel, draco::DT_UINT8,
             true, sizeof(uint8_t) * colors_channel, 0);
    col_att_id = mesh.AddAttribute(col, true, num_points);
  }

  int tex_att_id = -1;
  if (tex_coord_channel) {
    draco::GeometryAttribute tc;
    tc.Init(draco::GeometryAttribute::TEX_COORD, nullptr, tex_coord_channel,
            draco::DT_FLOAT32, true, sizeof(float) * tex_coord_channel, 0);
    tex_att_id = mesh.AddAttribute(tc, true, num_points);
  }

  int nrm_att_id = -1;
  if (!normals.empty()) {
    draco::GeometryAttribute nm;
    nm.Init(draco::GeometryAttribute::NORMAL, nullptr, 3, draco::DT_FLOAT32, true,
            sizeof(float) * 3, 0);
    nrm_att_id = mesh.AddAttribute(nm, true, num_points);
  }

  // I3S generics (optional): uv-region, feature-index (+ feature-ids metadata)
  int uvr_att_id = -1;
  if (!uvr.empty() && uvr_components > 0) {
    draco::GeometryAttribute ga;
    ga.Init(draco::GeometryAttribute::GENERIC, nullptr, uvr_components, draco::DT_UINT16,
            true, sizeof(uint16_t) * uvr_components, 0);
    uvr_att_id = mesh.AddAttribute(ga, true, num_points);
  }

  int fi_att_id = -1;
  if (!feature_index.empty() && feature_index_components > 0) {
    draco::GeometryAttribute ga;
    ga.Init(draco::GeometryAttribute::GENERIC, nullptr, feature_index_components,
            draco::DT_UINT32, false, sizeof(uint32_t) * feature_index_components, 0);
    fi_att_id = mesh.AddAttribute(ga, true, num_points);
  }

  // Generic attributes (DracoPy-compatible)
  std::vector<int> generic_att_ids;
  std::vector<size_t> generic_src_idx;
  generic_att_ids.reserve(generic_attributes.size());
  generic_src_idx.reserve(generic_attributes.size());
  for (size_t gidx = 0; gidx < generic_attributes.size(); ++gidx) {
    const auto &ga = generic_attributes[gidx];
    const auto dtype = static_cast<draco::DataType>(ga.data_type);
    draco::GeometryAttribute gattr;
    int elem_size = 4;
    switch (dtype) {
      case draco::DT_UINT8:
      case draco::DT_INT8:
      case draco::DT_BOOL:
        elem_size = 1;
        break;
      case draco::DT_UINT16:
      case draco::DT_INT16:
        elem_size = 2;
        break;
      case draco::DT_FLOAT32:
      case draco::DT_INT32:
      case draco::DT_UINT32:
        elem_size = 4;
        break;
      case draco::DT_FLOAT64:
      case draco::DT_INT64:
      case draco::DT_UINT64:
        elem_size = 8;
        break;
      default:
        elem_size = 4;
        break;
    }
    gattr.Init(draco::GeometryAttribute::GENERIC, nullptr, ga.num_components, dtype,
               ga.normalized, elem_size * ga.num_components, 0);
    const int att_id = mesh.AddAttribute(gattr, true, num_points);
    if (att_id < 0) continue;
    if (ga.has_unique_id) {
      mesh.attribute(att_id)->set_unique_id(ga.unique_id);
    }
    generic_att_ids.push_back(att_id);
    generic_src_idx.push_back(gidx);
  }

  for (int i = 0; i < num_points; ++i) {
    mesh.attribute(pos_att_id)->SetAttributeValue(draco::AttributeValueIndex(i),
                                                  points.data() + 3 * i);
    if (col_att_id >= 0) {
      mesh.attribute(col_att_id)->SetAttributeValue(draco::AttributeValueIndex(i),
                                                    colors.data() + colors_channel * i);
    }
    if (tex_att_id >= 0) {
      mesh.attribute(tex_att_id)->SetAttributeValue(draco::AttributeValueIndex(i),
                                                    tex_coord.data() + tex_coord_channel * i);
    }
    if (nrm_att_id >= 0) {
      mesh.attribute(nrm_att_id)->SetAttributeValue(draco::AttributeValueIndex(i),
                                                    normals.data() + 3 * i);
    }
    if (uvr_att_id >= 0) {
      mesh.attribute(uvr_att_id)->SetAttributeValue(
          draco::AttributeValueIndex(i), uvr.data() + uvr_components * i);
    }
    if (fi_att_id >= 0) {
      mesh.attribute(fi_att_id)->SetAttributeValue(
          draco::AttributeValueIndex(i),
          feature_index.data() + feature_index_components * i);
    }

    // Write generic attributes
    for (size_t gi = 0; gi < generic_att_ids.size(); ++gi) {
      const int att_id = generic_att_ids[gi];
      const auto &ga = generic_attributes[generic_src_idx[gi]];
      const auto dtype = static_cast<draco::DataType>(ga.data_type);
      const int base = ga.num_components * i;
      switch (dtype) {
        case draco::DT_FLOAT32:
        case draco::DT_FLOAT64:
          mesh.attribute(att_id)->SetAttributeValue(draco::AttributeValueIndex(i),
                                                    ga.float_data.data() + base);
          break;
        case draco::DT_UINT8:
          mesh.attribute(att_id)->SetAttributeValue(draco::AttributeValueIndex(i),
                                                    ga.uint8_data.data() + base);
          break;
        case draco::DT_UINT16:
          mesh.attribute(att_id)->SetAttributeValue(draco::AttributeValueIndex(i),
                                                    ga.uint16_data.data() + base);
          break;
        default:
          mesh.attribute(att_id)->SetAttributeValue(draco::AttributeValueIndex(i),
                                                    ga.uint_data.data() + base);
          break;
      }
    }
  }

  const int num_faces = static_cast<int>(faces.size() / 3);
  for (int i = 0; i < num_faces; ++i) {
    mesh.AddFace(draco::Mesh::Face{draco::PointIndex(faces[3 * i]),
                                   draco::PointIndex(faces[3 * i + 1]),
                                   draco::PointIndex(faces[3 * i + 2])});
  }

  if (!preserve_order && mesh.DeduplicateAttributeValues()) {
    mesh.DeduplicatePointIds();
  }

  if (write_i3s_scale_xy) {
    auto md = std::make_unique<draco::AttributeMetadata>();
    md->AddEntryDouble("i3s-scale_x", i3s_scale_x);
    md->AddEntryDouble("i3s-scale_y", i3s_scale_y);
    mesh.AddAttributeMetadata(pos_att_id, std::move(md));
  }

  // Attach I3S attribute metadata AFTER potential deduplication so that
  // unique_id mappings remain valid.
  if (uvr_att_id >= 0) {
    auto md = std::make_unique<draco::AttributeMetadata>();
    md->AddEntryString("i3s-attribute-type", "uv-region");
    mesh.AddAttributeMetadata(uvr_att_id, std::move(md));
  }

  if (fi_att_id >= 0) {
    auto md = std::make_unique<draco::AttributeMetadata>();
    md->AddEntryString("i3s-attribute-type", "feature-index");
    if (!feature_ids.empty()) {
      std::vector<int32_t> fids(feature_ids.begin(), feature_ids.end());
      md->AddEntryIntArray("i3s-feature-ids", fids);
    }
    mesh.AddAttributeMetadata(fi_att_id, std::move(md));
  }

  // Attach generic attribute names after potential deduplication.
  for (size_t gi = 0; gi < generic_att_ids.size(); ++gi) {
    const int att_id = generic_att_ids[gi];
    const auto &ga = generic_attributes[generic_src_idx[gi]];
    if (ga.name.empty()) continue;
    auto md = std::make_unique<draco::AttributeMetadata>();
    md->AddEntryString("name", ga.name);
    mesh.AddAttributeMetadata(att_id, std::move(md));
  }

  draco::Encoder enc;
  SetupEncoderMetadata(&mesh, enc, compression_level, quantization_bits,
                       quantization_range, quantization_origin, create_metadata);
  if (preserve_order) enc.SetEncodingMethod(draco::MESH_SEQUENTIAL_ENCODING);

  draco::EncoderBuffer buf;
  const draco::Status st = enc.EncodeMeshToBuffer(mesh, &buf);
  if (!st.ok()) {
    out.encode_status = failed_during_encoding;
    return out;
  }
  out.buffer.assign(reinterpret_cast<const std::uint8_t *>(buf.data()),
                    reinterpret_cast<const std::uint8_t *>(buf.data()) + buf.size());
  out.encode_status = successful_encoding;
  return out;
}

static EncodedObject ZlibResultToEncoded(int zret, std::vector<std::uint8_t> &&buf) {
  EncodedObject out;
  if (zret != Z_OK && zret != Z_STREAM_END) {
    out.encode_status = failed_during_encoding;
    return out;
  }
  out.buffer = std::move(buf);
  out.encode_status = successful_encoding;
  return out;
}

EncodedObject gzip_decompress(const std::vector<std::uint8_t> &data) {
  z_stream strm{};
  strm.next_in = const_cast<Bytef *>(reinterpret_cast<const Bytef *>(data.data()));
  strm.avail_in = static_cast<uInt>(data.size());

  // 16 + MAX_WBITS enables gzip decoding.
  if (inflateInit2(&strm, 16 + MAX_WBITS) != Z_OK) {
    EncodedObject out;
    out.encode_status = failed_during_encoding;
    return out;
  }

  std::vector<std::uint8_t> outbuf;
  outbuf.reserve(data.size() * 4);
  std::array<std::uint8_t, 64 * 1024> chunk{};

  int ret = Z_OK;
  while (ret == Z_OK) {
    strm.next_out = chunk.data();
    strm.avail_out = static_cast<uInt>(chunk.size());
    ret = inflate(&strm, Z_NO_FLUSH);
    const size_t produced = chunk.size() - strm.avail_out;
    outbuf.insert(outbuf.end(), chunk.data(), chunk.data() + produced);
  }

  inflateEnd(&strm);
  if (ret != Z_STREAM_END) {
    EncodedObject out;
    out.encode_status = failed_during_encoding;
    return out;
  }
  EncodedObject out;
  out.buffer = std::move(outbuf);
  out.encode_status = successful_encoding;
  return out;
}

EncodedObject gzip_compress(const std::vector<std::uint8_t> &data, int level) {
  z_stream strm{};
  strm.next_in = const_cast<Bytef *>(reinterpret_cast<const Bytef *>(data.data()));
  strm.avail_in = static_cast<uInt>(data.size());

  // 16 + MAX_WBITS enables gzip encoding.
  if (deflateInit2(&strm, level, Z_DEFLATED, 16 + MAX_WBITS, 8, Z_DEFAULT_STRATEGY) != Z_OK) {
    EncodedObject out;
    out.encode_status = failed_during_encoding;
    return out;
  }

  std::vector<std::uint8_t> outbuf;
  outbuf.reserve(data.size() / 2);
  std::array<std::uint8_t, 64 * 1024> chunk{};

  int ret = Z_OK;
  while (ret == Z_OK) {
    strm.next_out = chunk.data();
    strm.avail_out = static_cast<uInt>(chunk.size());
    ret = deflate(&strm, strm.avail_in ? Z_NO_FLUSH : Z_FINISH);
    const size_t produced = chunk.size() - strm.avail_out;
    outbuf.insert(outbuf.end(), chunk.data(), chunk.data() + produced);
  }

  deflateEnd(&strm);
  if (ret != Z_STREAM_END) {
    EncodedObject out;
    out.encode_status = failed_during_encoding;
    return out;
  }
  EncodedObject out;
  out.buffer = std::move(outbuf);
  out.encode_status = successful_encoding;
  return out;
}

}  // namespace AldracoCore

