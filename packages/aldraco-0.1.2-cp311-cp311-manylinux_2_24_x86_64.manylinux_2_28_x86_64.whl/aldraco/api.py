from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Mapping, Optional

import numpy as np

from ._core import decode_buffer as _decode_buffer
from ._core import decode_buffer_ex as _decode_buffer_ex
from ._core import encode_mesh as _encode_mesh
from ._core import encode_point_cloud as _encode_point_cloud
from ._core import gzip_compress as _gzip_compress
from ._core import gzip_decompress as _gzip_decompress


@dataclass(frozen=True)
class DecodeResult:
    points: np.ndarray | None
    faces: np.ndarray | None
    normals: np.ndarray | None
    tex_coord: np.ndarray | None
    colors: np.ndarray | None
    attributes: list[dict[str, Any]]

    # i3s-friendly convenience fields (may be absent)
    uvr: np.ndarray | None
    feature_index: np.ndarray | None
    feature_ids: np.ndarray | None


def _is_gzip_magic(data: bytes) -> bool:
    return len(data) >= 2 and data[0] == 0x1F and data[1] == 0x8B


def _resolve_is_gzip(*, data: bytes, is_gzip: bool | None, validate_magic: bool) -> bool:
    magic = _is_gzip_magic(data)
    if is_gzip is None:
        return magic
    if validate_magic and magic != is_gzip:
        raise ValueError(
            f"is_gzip={is_gzip} conflicts with gzip magic={magic}. "
            "Pass validate_magic=False to trust the parameter."
        )
    return is_gzip


def gzip_decompress_bytes(
    data: bytes,
    *,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
) -> bytes:
    """
    Bytes-only gzip decompress.

    - If `is_gzip` is None: detect gzip by magic header.
    - If gzip: return decompressed bytes.
    - If not gzip: return input bytes unchanged.
    """
    gz = _resolve_is_gzip(data=data, is_gzip=is_gzip, validate_magic=validate_magic)
    return _gzip_decompress(data) if gz else data


def gzip_compress_bytes(
    data: bytes,
    *,
    level: int = 6,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
) -> bytes:
    """
    Bytes-only gzip compress.

    - If `is_gzip` is None: detect gzip by magic header.
    - If already gzip: return input bytes unchanged.
    - If not gzip: return gzip-compressed bytes.
    """
    gz = _resolve_is_gzip(data=data, is_gzip=is_gzip, validate_magic=validate_magic)
    return data if gz else _gzip_compress(data, level=level)


def gzip_decompress_file(
    input_path: str | Path,
    output_path: str | Path,
    *,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
) -> bytes:
    """
    File-only gzip decompress. Always writes to `output_path` (overwrites if exists).
    Returns the output bytes.
    """
    in_b = Path(input_path).read_bytes()
    out_b = gzip_decompress_bytes(in_b, is_gzip=is_gzip, validate_magic=validate_magic)
    Path(output_path).write_bytes(out_b)
    return out_b


def gzip_compress_file(
    input_path: str | Path,
    output_path: str | Path,
    *,
    level: int = 6,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
) -> bytes:
    """
    File-only gzip compress. Always writes to `output_path` (overwrites if exists).
    Returns the output bytes.
    """
    in_b = Path(input_path).read_bytes()
    out_b = gzip_compress_bytes(
        in_b, level=level, is_gzip=is_gzip, validate_magic=validate_magic
    )
    Path(output_path).write_bytes(out_b)
    return out_b


def decode_bytes(
    data: bytes,
    *,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
    collect_attributes: bool = True,
    schema: Optional[Mapping[str, Any]] = None,
) -> DecodeResult:
    """
    Bytes-only Draco decode, with optional gzip auto-detection/preprocessing.

    For I3S, this will identify `uv-region` and `feature-index` using attribute
    metadata key `i3s-attribute-type` when present.

    `schema` is reserved for future extensions (custom post-processing rules).
    """
    raw = gzip_decompress_bytes(data, is_gzip=is_gzip, validate_magic=validate_magic)
    ds = _decode_buffer_ex(raw, collect_attributes=collect_attributes)
    _ = schema
    return DecodeResult(
        points=ds.get("points"),
        faces=ds.get("faces"),
        normals=ds.get("normals"),
        tex_coord=ds.get("tex_coord"),
        colors=ds.get("colors"),
        attributes=ds.get("attributes", []),
        uvr=ds.get("uvr"),
        feature_index=ds.get("feature_index"),
        feature_ids=ds.get("feature_ids"),
    )


def decode_file(
    input_path: str | Path,
    output_path: str | Path,
    *,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
    schema: Optional[Mapping[str, Any]] = None,
) -> DecodeResult:
    """
    File-only Draco decode. Always writes the Draco raw bytes (after optional gzip
    preprocessing) to `output_path` (overwrites if exists).
    """
    in_b = Path(input_path).read_bytes()
    raw = gzip_decompress_bytes(in_b, is_gzip=is_gzip, validate_magic=validate_magic)
    Path(output_path).write_bytes(raw)
    return decode_bytes(raw, is_gzip=False, validate_magic=False, schema=schema)


def decode(data: bytes, *, schema: Optional[Mapping[str, Any]] = None) -> DecodeResult:
    # Backward-compatible alias (strict bytes-only, no gzip auto).
    return decode_bytes(data, is_gzip=False, validate_magic=False, schema=schema)


def _ensure_suffix(p: Path, suffix: str) -> Path:
    if p.suffix.lower() == suffix.lower():
        return p
    if p.suffix == "":
        return p.with_suffix(suffix)
    return p


# -----------------------------------------------------------------------------
# "to_bytes / to_file" convenience I/O APIs (draco bytes + optional gzip wrapper)
# -----------------------------------------------------------------------------


def encode_to_bytes(*args: Any, **kwargs: Any) -> bytes:
    """
    Encode to Draco raw bytes (non-gzip). Thin wrapper around `encode(...)`.
    """
    return encode(*args, **kwargs)


def encode_to_file(output_path: str | Path, *args: Any, **kwargs: Any) -> bytes:
    """
    Encode to Draco raw bytes and write to `output_path` (overwrites if exists).

    If `output_path` has no suffix, `.drc` will be appended.
    """
    out_p = _ensure_suffix(Path(output_path), ".drc")
    b = encode_to_bytes(*args, **kwargs)
    out_p.write_bytes(b)
    return b


def decode_to_bytes(
    data: bytes,
    *,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
) -> bytes:
    """
    Normalize input to Draco raw bytes.

    - If `is_gzip` is None: detect gzip by magic header.
    - If gzip: return gunzipped bytes (assumed to be Draco buffer).
    - If not gzip: return input unchanged.
    """
    return gzip_decompress_bytes(data, is_gzip=is_gzip, validate_magic=validate_magic)


def decode_to_file(
    input_path: str | Path,
    output_path: str | Path,
    *,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
) -> bytes:
    """
    Read from file, normalize to Draco raw bytes, write to `output_path`.

    If `output_path` has no suffix, `.drc` will be appended.
    """
    in_b = Path(input_path).read_bytes()
    out_b = decode_to_bytes(in_b, is_gzip=is_gzip, validate_magic=validate_magic)
    out_p = _ensure_suffix(Path(output_path), ".drc")
    out_p.write_bytes(out_b)
    return out_b


def encode_to_gzip_bytes(*args: Any, level: int = 6, **kwargs: Any) -> bytes:
    """
    Encode to Draco bytes then gzip-compress (always returns gzip bytes).
    """
    b = encode_to_bytes(*args, **kwargs)
    return gzip_compress_bytes(b, level=level, is_gzip=False, validate_magic=False)


def encode_to_gzip_file(
    output_path: str | Path,
    *args: Any,
    level: int = 6,
    **kwargs: Any,
) -> bytes:
    """
    Encode to Draco bytes then gzip-compress and write to file.

    If `output_path` is not suffixed with `.gz`, `.gz` will be appended.
    """
    out_p = _ensure_suffix(Path(output_path), ".gz")
    b = encode_to_gzip_bytes(*args, level=level, **kwargs)
    out_p.write_bytes(b)
    return b


def decode_to_gzip_bytes(
    data: bytes,
    *,
    level: int = 6,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
) -> bytes:
    """
    Normalize input to Draco raw bytes, then gzip-compress it.
    """
    raw = decode_to_bytes(data, is_gzip=is_gzip, validate_magic=validate_magic)
    return gzip_compress_bytes(raw, level=level, is_gzip=False, validate_magic=False)


def decode_to_gzip_file(
    input_path: str | Path,
    output_path: str | Path,
    *,
    level: int = 6,
    is_gzip: bool | None = None,
    validate_magic: bool = True,
) -> bytes:
    """
    Normalize input to Draco raw bytes, gzip-compress it, and write to file.

    If `output_path` is not suffixed with `.gz`, `.gz` will be appended.
    """
    in_b = Path(input_path).read_bytes()
    out_b = decode_to_gzip_bytes(
        in_b, level=level, is_gzip=is_gzip, validate_magic=validate_magic
    )
    out_p = _ensure_suffix(Path(output_path), ".gz")
    out_p.write_bytes(out_b)
    return out_b


def encode(
    points: np.ndarray,
    *,
    faces: np.ndarray | None = None,
    colors: np.ndarray | None = None,
    tex_coord: np.ndarray | None = None,
    normals: np.ndarray | None = None,
    generic_attributes: dict[str | int, np.ndarray] | None = None,
    uvr: np.ndarray | None = None,
    feature_index: np.ndarray | None = None,
    feature_ids: np.ndarray | None = None,
    i3s_scale_xy: Literal["auto"] | tuple[float, float] | None = None,
    quantization_bits: int = 14,
    compression_level: int = 1,
    quantization_range: float = -1.0,
    quantization_origin: np.ndarray | None = None,
    create_metadata: bool = False,
    preserve_order: bool = False,
) -> bytes:
    """
    Encode mesh or point cloud.

    This is a thin wrapper; currently supports the common DracoPy parameter set.
    """
    points_arr = np.asarray(points, dtype=np.float32).reshape((-1, 3))

    write_scale = i3s_scale_xy is not None
    sx = 1.0
    sy = 1.0
    if i3s_scale_xy == "auto":
        mins = points_arr.min(axis=0)
        maxs = points_arr.max(axis=0)
        rx, ry, rz = (maxs - mins).astype(np.float64)
        target = max(rx, ry, rz, 1e-12)
        sx = float(rx / target) if rx > 0 else 1.0
        sy = float(ry / target) if ry > 0 else 1.0
    elif isinstance(i3s_scale_xy, tuple):
        sx, sy = float(i3s_scale_xy[0]), float(i3s_scale_xy[1])
    elif i3s_scale_xy is None:
        pass
    else:
        raise TypeError("i3s_scale_xy must be None, 'auto', or (scale_x, scale_y)")

    if write_scale:
        # Pre-scale XY by 1/scale so that decode can multiply by scale to restore.
        # i3s-spec requires storing scale in POSITION attribute metadata.
        pre_sx = 1.0 / sx if sx not in (0.0,) else 1.0
        pre_sy = 1.0 / sy if sy not in (0.0,) else 1.0
        pts = points_arr.copy()
        pts[:, 0] *= pre_sx
        pts[:, 1] *= pre_sy
    else:
        pts = points_arr

    if faces is None:
        return _encode_point_cloud(
            pts,
            quantization_bits=quantization_bits,
            compression_level=compression_level,
            quantization_range=quantization_range,
            quantization_origin=quantization_origin,
            create_metadata=create_metadata,
            preserve_order=preserve_order,
            colors=colors,
            generic_attributes=generic_attributes,
            i3s_scale_x=(sx if write_scale else None),
            i3s_scale_y=(sy if write_scale else None),
        )

    return _encode_mesh(
        pts,
        faces,
        quantization_bits=quantization_bits,
        compression_level=compression_level,
        quantization_range=quantization_range,
        quantization_origin=quantization_origin,
        create_metadata=create_metadata,
        preserve_order=preserve_order,
        colors=colors,
        tex_coord=tex_coord,
        normals=normals,
        uvr=uvr,
        feature_index=feature_index,
        feature_ids=feature_ids,
        generic_attributes=generic_attributes,
        i3s_scale_x=(sx if write_scale else None),
        i3s_scale_y=(sy if write_scale else None),
    )


def gzip_decompress(data: bytes) -> bytes:
    return _gzip_decompress(data)


def gzip_compress(data: bytes, *, level: int = 6) -> bytes:
    return _gzip_compress(data, level=level)

