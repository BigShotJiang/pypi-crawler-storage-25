# cython: language_level=3

from libcpp.vector cimport vector
from libcpp.string cimport string
from libc.stdint cimport int32_t, uint8_t, uint16_t, uint32_t, uint64_t
from libcpp cimport bool

cdef extern from "aldraco_core.h" namespace "AldracoCore":
    cdef enum decoding_status:
        successful, not_draco_encoded, no_position_attribute, failed_during_decoding

    cdef enum encoding_status:
        successful_encoding, failed_during_encoding

    cdef struct AttributeObject:
        int unique_id
        int num_components
        int data_type
        int attribute_type
        string name
        vector[float] float_data
        vector[uint32_t] uint_data
        vector[uint16_t] uint16_data
        vector[uint8_t] byte_data

    cdef struct MeshObject:
        vector[float] points
        vector[uint32_t] faces
        vector[float] normals
        vector[float] tex_coord
        vector[uint8_t] colors
        int colors_channel

        vector[uint16_t] uvr
        int uvr_components
        vector[uint32_t] feature_index
        int feature_index_components
        vector[int32_t] feature_ids

        vector[AttributeObject] attributes

        bool encoding_options_set
        int quantization_bits
        double quantization_range
        vector[double] quantization_origin

        decoding_status decode_status

    cdef struct EncodedObject:
        vector[uint8_t] buffer
        encoding_status encode_status

    cdef struct GenericAttributeInput:
        bool has_unique_id
        uint32_t unique_id
        string name
        int num_components
        int data_type
        bool normalized
        vector[float] float_data
        vector[uint32_t] uint_data
        vector[uint16_t] uint16_data
        vector[uint8_t] uint8_data

    MeshObject decode_buffer(const char *buffer, size_t buffer_len) except +
    MeshObject decode_buffer_ex(const char *buffer, size_t buffer_len, const bool collect_attributes) except +

    EncodedObject encode_mesh(
        const vector[float] points,
        const vector[uint32_t] faces,
        const int quantization_bits,
        const int compression_level,
        const float quantization_range,
        const float *quantization_origin,
        const bool preserve_order,
        const bool create_metadata,
        const vector[uint8_t] colors,
        const uint8_t colors_channel,
        const vector[float] tex_coord,
        const uint8_t tex_coord_channel,
        const vector[float] normals,
        const vector[uint16_t] uvr,
        const int uvr_components,
        const vector[uint32_t] feature_index,
        const int feature_index_components,
        const vector[int32_t] feature_ids,
        const vector[GenericAttributeInput] generic_attributes,
        const bool write_i3s_scale_xy,
        const double i3s_scale_x,
        const double i3s_scale_y
    ) except +

    EncodedObject encode_point_cloud(
        const vector[float] points,
        const int quantization_bits,
        const int compression_level,
        const float quantization_range,
        const float *quantization_origin,
        const bool preserve_order,
        const bool create_metadata,
        const vector[uint8_t] colors,
        const uint8_t colors_channel,
        const vector[GenericAttributeInput] generic_attributes,
        const bool write_i3s_scale_xy,
        const double i3s_scale_x,
        const double i3s_scale_y
    ) except +

    EncodedObject gzip_compress(const vector[uint8_t] data, const int level) except +
    EncodedObject gzip_decompress(const vector[uint8_t] data) except +

