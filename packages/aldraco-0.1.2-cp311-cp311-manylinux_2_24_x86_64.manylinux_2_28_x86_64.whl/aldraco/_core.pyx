# distutils: language = c++
# cython: language_level=3

from __future__ import annotations

from typing import Any

cimport numpy as cnp
cnp.import_array()

import numpy as np

from libcpp.vector cimport vector
from libc.stdint cimport uint8_t, uint16_t, uint32_t
from libc.stdint cimport int32_t

cimport aldraco._corelib as _c


class FileTypeException(Exception):
    pass


class DecodingFailedException(Exception):
    pass


class EncodingFailedException(Exception):
    pass


cdef _raise_decoding_error(_c.decoding_status status):
    if status == _c.decoding_status.not_draco_encoded:
        raise FileTypeException("Input is not Draco encoded")
    if status == _c.decoding_status.no_position_attribute:
        raise ValueError("POSITION attribute missing")
    raise DecodingFailedException("Failed to decode input (corrupted or unsupported)")


def decode_buffer(bytes data) -> dict[str, Any]:
    cdef _c.MeshObject mo = _c.decode_buffer(<const char*>data, len(data))
    if mo.decode_status != _c.decoding_status.successful:
        _raise_decoding_error(mo.decode_status)

    out: dict[str, Any] = {}

    # points
    if mo.points.size() > 0:
        pts = np.asarray(mo.points, dtype=np.float32)
        out["points"] = pts.reshape((-1, 3))
    else:
        out["points"] = None

    # faces (mesh only)
    if mo.faces.size() > 0:
        fc = np.asarray(mo.faces, dtype=np.uint32)
        out["faces"] = fc.reshape((-1, 3))
    else:
        out["faces"] = None

    # normals
    out["normals"] = None
    if mo.normals.size() > 0:
        n = np.asarray(mo.normals, dtype=np.float32)
        out["normals"] = n.reshape((-1, 3))

    # tex coord
    out["tex_coord"] = None
    if mo.tex_coord.size() > 0:
        tc = np.asarray(mo.tex_coord, dtype=np.float32)
        # components may vary; infer by N
        N = (mo.points.size() // 3) if mo.points.size() else 0
        if N:
            out["tex_coord"] = tc.reshape((N, -1))

    # colors
    out["colors"] = None
    if mo.colors.size() > 0 and mo.colors_channel > 0:
        c = np.asarray(mo.colors, dtype=np.uint8)
        N = (mo.points.size() // 3) if mo.points.size() else 0
        if N:
            out["colors"] = c.reshape((N, mo.colors_channel))

    # i3s uvr / feature_index
    out["uvr"] = None
    if mo.uvr.size() > 0 and mo.uvr_components > 0:
        u = np.asarray(mo.uvr, dtype=np.uint16)
        N = (mo.points.size() // 3) if mo.points.size() else 0
        if N:
            out["uvr"] = u.reshape((N, mo.uvr_components))

    out["feature_index"] = None
    if mo.feature_index.size() > 0 and mo.feature_index_components > 0:
        fi = np.asarray(mo.feature_index, dtype=np.uint32)
        N = (mo.points.size() // 3) if mo.points.size() else 0
        if N:
            out["feature_index"] = fi.reshape((N, mo.feature_index_components))

    out["feature_ids"] = None
    if mo.feature_ids.size() > 0:
        out["feature_ids"] = np.asarray(mo.feature_ids, dtype=np.int32)

    # attributes (generic + standard)
    attrs = []
    cdef size_t i
    for i in range(mo.attributes.size()):
        a = mo.attributes[i]
        d: dict[str, Any] = {
            "unique_id": a.unique_id,
            "num_components": a.num_components,
            "data_type": a.data_type,
            "attribute_type": a.attribute_type,
            "name": (<bytes>a.name).decode("utf-8") if a.name.size() else None,
        }
        if a.float_data.size() > 0:
            arr = np.asarray(a.float_data, dtype=np.float32).reshape((-1, a.num_components))
            d["data"] = arr
        elif a.uint_data.size() > 0:
            arr = np.asarray(a.uint_data, dtype=np.uint32).reshape((-1, a.num_components))
            d["data"] = arr
        elif a.uint16_data.size() > 0:
            arr = np.asarray(a.uint16_data, dtype=np.uint16).reshape((-1, a.num_components))
            d["data"] = arr
        elif a.byte_data.size() > 0:
            arr = np.asarray(a.byte_data, dtype=np.uint8).reshape((-1, a.num_components))
            d["data"] = arr
        else:
            d["data"] = None
        attrs.append(d)
    out["attributes"] = attrs

    return out


def decode_buffer_ex(bytes data, *, collect_attributes: bool = True) -> dict[str, Any]:
    cdef _c.MeshObject mo = _c.decode_buffer_ex(<const char*>data, len(data), <bint>collect_attributes)
    if mo.decode_status != _c.decoding_status.successful:
        _raise_decoding_error(mo.decode_status)

    out: dict[str, Any] = {}
    cdef size_t i

    # points
    if mo.points.size() > 0:
        pts = np.asarray(mo.points, dtype=np.float32)
        out["points"] = pts.reshape((-1, 3))
    else:
        out["points"] = None

    # faces (mesh only)
    if mo.faces.size() > 0:
        fc = np.asarray(mo.faces, dtype=np.uint32)
        out["faces"] = fc.reshape((-1, 3))
    else:
        out["faces"] = None

    # normals
    out["normals"] = None
    if mo.normals.size() > 0:
        n = np.asarray(mo.normals, dtype=np.float32)
        out["normals"] = n.reshape((-1, 3))

    # tex coord
    out["tex_coord"] = None
    if mo.tex_coord.size() > 0:
        tc = np.asarray(mo.tex_coord, dtype=np.float32)
        N = (mo.points.size() // 3) if mo.points.size() else 0
        if N:
            out["tex_coord"] = tc.reshape((N, -1))

    # colors
    out["colors"] = None
    if mo.colors.size() > 0 and mo.colors_channel > 0:
        c = np.asarray(mo.colors, dtype=np.uint8)
        N = (mo.points.size() // 3) if mo.points.size() else 0
        if N:
            out["colors"] = c.reshape((N, mo.colors_channel))

    # i3s uvr / feature_index
    out["uvr"] = None
    if mo.uvr.size() > 0 and mo.uvr_components > 0:
        u = np.asarray(mo.uvr, dtype=np.uint16)
        N = (mo.points.size() // 3) if mo.points.size() else 0
        if N:
            out["uvr"] = u.reshape((N, mo.uvr_components))

    out["feature_index"] = None
    if mo.feature_index.size() > 0 and mo.feature_index_components > 0:
        fi = np.asarray(mo.feature_index, dtype=np.uint32)
        N = (mo.points.size() // 3) if mo.points.size() else 0
        if N:
            out["feature_index"] = fi.reshape((N, mo.feature_index_components))

    out["feature_ids"] = None
    if mo.feature_ids.size() > 0:
        out["feature_ids"] = np.asarray(mo.feature_ids, dtype=np.int32)

    # attributes (generic + standard)
    attrs = []
    if collect_attributes:
        for i in range(mo.attributes.size()):
            a = mo.attributes[i]
            d: dict[str, Any] = {
                "unique_id": a.unique_id,
                "num_components": a.num_components,
                "data_type": a.data_type,
                "attribute_type": a.attribute_type,
                "name": (<bytes>a.name).decode("utf-8") if a.name.size() else None,
            }
            if a.float_data.size() > 0:
                arr = np.asarray(a.float_data, dtype=np.float32).reshape((-1, a.num_components))
                d["data"] = arr
            elif a.uint_data.size() > 0:
                arr = np.asarray(a.uint_data, dtype=np.uint32).reshape((-1, a.num_components))
                d["data"] = arr
            elif a.uint16_data.size() > 0:
                arr = np.asarray(a.uint16_data, dtype=np.uint16).reshape((-1, a.num_components))
                d["data"] = arr
            elif a.byte_data.size() > 0:
                arr = np.asarray(a.byte_data, dtype=np.uint8).reshape((-1, a.num_components))
                d["data"] = arr
            else:
                d["data"] = None
            attrs.append(d)
    out["attributes"] = attrs

    return out


def encode_point_cloud(
    points,
    *,
    quantization_bits=14,
    compression_level=1,
    quantization_range=-1.0,
    quantization_origin=None,
    create_metadata=False,
    preserve_order=False,
    colors=None,
    generic_attributes=None,
    i3s_scale_x=None,
    i3s_scale_y=None,
) -> bytes:
    points = np.asarray(points, dtype=np.float32).reshape((-1, 3))
    cdef vector[float] pts = points.reshape((points.size,))

    cdef vector[uint8_t] cols
    cdef uint8_t cols_channel = 0
    if colors is not None:
        c_np = np.asarray(colors, dtype=np.uint8)
        c_np = c_np.reshape((points.shape[0], -1))
        cols_channel = <uint8_t>c_np.shape[1]
        cols = c_np.reshape((c_np.size,))

    cdef cnp.ndarray[cnp.float32_t, ndim=1] qorigin = np.zeros((3,), dtype=np.float32)
    if quantization_origin is not None:
        qorigin[:] = np.asarray(quantization_origin, dtype=np.float32).reshape((3,))

    cdef vector[_c.GenericAttributeInput] generics
    if generic_attributes is not None:
        generics = _build_generic_attributes(points.shape[0], generic_attributes)

    cdef bint write_scale = False
    cdef double sx = 1.0
    cdef double sy = 1.0
    if i3s_scale_x is not None or i3s_scale_y is not None:
        write_scale = True
        sx = float(i3s_scale_x if i3s_scale_x is not None else 1.0)
        sy = float(i3s_scale_y if i3s_scale_y is not None else 1.0)

    cdef _c.EncodedObject eo = _c.encode_point_cloud(
        pts,
        <int>quantization_bits,
        <int>compression_level,
        <float>quantization_range,
        <float*>&qorigin[0] if quantization_origin is not None else <float*>NULL,
        <bint>preserve_order,
        <bint>create_metadata,
        cols,
        cols_channel,
        generics,
        write_scale,
        sx,
        sy,
    )
    if eo.encode_status != _c.encoding_status.successful_encoding:
        raise EncodingFailedException("Encoding failed")
    return bytes(eo.buffer)


def encode_mesh(
    points,
    faces,
    *,
    quantization_bits=14,
    compression_level=1,
    quantization_range=-1.0,
    quantization_origin=None,
    create_metadata=False,
    preserve_order=False,
    colors=None,
    tex_coord=None,
    normals=None,
    uvr=None,
    feature_index=None,
    feature_ids=None,
    generic_attributes=None,
    i3s_scale_x=None,
    i3s_scale_y=None,
) -> bytes:
    points = np.asarray(points, dtype=np.float32).reshape((-1, 3))
    faces = np.asarray(faces, dtype=np.uint32).reshape((-1, 3))
    cdef vector[float] pts = points.reshape((points.size,))
    cdef vector[uint32_t] fcs = faces.reshape((faces.size,))

    cdef vector[uint8_t] cols
    cdef uint8_t cols_channel = 0
    if colors is not None:
        c_np = np.asarray(colors, dtype=np.uint8).reshape((points.shape[0], -1))
        cols_channel = <uint8_t>c_np.shape[1]
        cols = c_np.reshape((c_np.size,))

    cdef vector[float] tc
    cdef uint8_t tc_channel = 0
    if tex_coord is not None:
        t_np = np.asarray(tex_coord, dtype=np.float32).reshape((points.shape[0], -1))
        tc_channel = <uint8_t>t_np.shape[1]
        tc = t_np.reshape((t_np.size,))

    cdef vector[float] nrm
    if normals is not None:
        n_np = np.asarray(normals, dtype=np.float32).reshape((points.shape[0], 3))
        nrm = n_np.reshape((n_np.size,))

    cdef vector[uint16_t] uvr_vec
    cdef int uvr_components = 0
    if uvr is not None:
        u_np = np.asarray(uvr, dtype=np.uint16).reshape((points.shape[0], -1))
        uvr_components = <int>u_np.shape[1]
        uvr_vec = u_np.reshape((u_np.size,))

    cdef vector[uint32_t] fi_vec
    cdef int fi_components = 0
    if feature_index is not None:
        fi_np = np.asarray(feature_index, dtype=np.uint32).reshape((points.shape[0], -1))
        fi_components = <int>fi_np.shape[1]
        fi_vec = fi_np.reshape((fi_np.size,))

    cdef vector[int32_t] fids_vec
    if feature_ids is not None:
        fids_np = np.asarray(feature_ids, dtype=np.int32).reshape((-1,))
        fids_vec = fids_np

    cdef vector[_c.GenericAttributeInput] generics
    if generic_attributes is not None:
        generics = _build_generic_attributes(points.shape[0], generic_attributes)

    cdef cnp.ndarray[cnp.float32_t, ndim=1] qorigin = np.zeros((3,), dtype=np.float32)
    if quantization_origin is not None:
        qorigin[:] = np.asarray(quantization_origin, dtype=np.float32).reshape((3,))

    cdef bint write_scale = False
    cdef double sx = 1.0
    cdef double sy = 1.0
    if i3s_scale_x is not None or i3s_scale_y is not None:
        write_scale = True
        sx = float(i3s_scale_x if i3s_scale_x is not None else 1.0)
        sy = float(i3s_scale_y if i3s_scale_y is not None else 1.0)

    cdef _c.EncodedObject eo = _c.encode_mesh(
        pts,
        fcs,
        <int>quantization_bits,
        <int>compression_level,
        <float>quantization_range,
        <float*>&qorigin[0] if quantization_origin is not None else <float*>NULL,
        <bint>preserve_order,
        <bint>create_metadata,
        cols,
        cols_channel,
        tc,
        tc_channel,
        nrm,
        uvr_vec,
        uvr_components,
        fi_vec,
        fi_components,
        fids_vec,
        generics,
        write_scale,
        sx,
        sy,
    )
    if eo.encode_status != _c.encoding_status.successful_encoding:
        raise EncodingFailedException("Encoding failed")
    return bytes(eo.buffer)


cdef vector[_c.GenericAttributeInput] _build_generic_attributes(int n_points, object generic_attributes):
    """
    Builds GenericAttributeInput vector compatible with DracoPy:
    - key: int unique_id or str name (stored in attribute metadata as 'name')
    - value: ndarray shape (N, K)
    - supported dtypes: float32/float64 -> float32, uint8, uint16, uint32
    """
    cdef vector[_c.GenericAttributeInput] out
    if generic_attributes is None:
        return out
    if not isinstance(generic_attributes, dict):
        raise TypeError("generic_attributes must be a dict[str|int, np.ndarray]")

    cdef _c.GenericAttributeInput ga
    for k, v in generic_attributes.items():
        arr = np.asarray(v)
        if arr.ndim != 2:
            raise ValueError("generic attribute arrays must be 2D (N, K)")
        if arr.shape[0] != n_points:
            raise ValueError("generic attribute vertex count mismatch")

        ga.has_unique_id = False
        ga.unique_id = 0
        ga.name = b""
        ga.num_components = 0
        ga.data_type = 0
        ga.normalized = False
        ga.num_components = <int>arr.shape[1]

        if isinstance(k, (int, np.integer)):
            if int(k) < 0:
                raise ValueError("generic attribute unique_id must be non-negative")
            ga.has_unique_id = True
            ga.unique_id = <uint32_t>int(k)
        elif isinstance(k, str):
            ga.has_unique_id = False
            ga.name = k.encode("utf-8")
        else:
            raise TypeError("generic attribute key must be int or str")

        # dtype mapping
        if np.issubdtype(arr.dtype, np.floating):
            arr = arr.astype(np.float32, copy=False)
            ga.data_type = 9  # DT_FLOAT32
            ga.float_data = arr.reshape((arr.size,))
        elif arr.dtype == np.uint8:
            ga.data_type = 2  # DT_UINT8
            ga.uint8_data = arr.reshape((arr.size,))
        elif arr.dtype == np.uint16:
            ga.data_type = 4  # DT_UINT16
            ga.uint16_data = arr.reshape((arr.size,))
        elif arr.dtype == np.uint32:
            ga.data_type = 6  # DT_UINT32
            ga.uint_data = arr.reshape((arr.size,))
        else:
            raise TypeError("unsupported generic attribute dtype (use float/uint8/uint16/uint32)")

        out.push_back(ga)
    return out


def gzip_decompress(data: bytes) -> bytes:
    cdef vector[uint8_t] inbuf = np.frombuffer(data, dtype=np.uint8)
    cdef _c.EncodedObject eo = _c.gzip_decompress(inbuf)
    if eo.encode_status != _c.encoding_status.successful_encoding:
        raise DecodingFailedException("gzip decompress failed")
    return bytes(eo.buffer)


def gzip_compress(data: bytes, *, level: int = 6) -> bytes:
    if level < -1 or level > 9:
        raise ValueError("gzip level must be in [-1, 9]")
    cdef vector[uint8_t] inbuf = np.frombuffer(data, dtype=np.uint8)
    cdef _c.EncodedObject eo = _c.gzip_compress(inbuf, <int>level)
    if eo.encode_status != _c.encoding_status.successful_encoding:
        raise EncodingFailedException("gzip compress failed")
    return bytes(eo.buffer)

