# cython: language_level=3
#
# Kept for compatibility with some Cython tooling that expects `_core.pxd`.
# The actual C++ ABI declarations for this extension live in `_corelib.pxd`.

