"""Agentic Memory context engine plugin for Hermes Agent.

Hermes context engines replace the built-in context compressor. This engine
keeps Hermes' required token counters while using Agentic Memory's backend to
resolve durable context blocks before returning a valid OpenAI-format message
sequence.

The module imports cleanly outside Hermes by falling back to a small ABC shim,
which lets this repository test the plugin without vendoring Hermes.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

try:  # pragma: no cover - exercised only inside Hermes.
    from agent.context_engine import ContextEngine
except Exception:  # pragma: no cover - repository tests use this shim.

    class ContextEngine:  # type: ignore[no-redef]
        """Small compatibility shim for tests outside Hermes Agent."""

        def update_model(self, model: str | None = None, context_length: int | None = None, **_: Any) -> None:
            if context_length is not None:
                self.context_length = context_length


PLUGIN_NAME = "agentic-memory"
DEFAULT_BACKEND_URL = "https://backend.agentmemorylabs.com"
CONFIG_FILENAME = "agentic-memory.json"
CLIENT_USER_AGENT = "agentic-memory-hermes/0.1.4"


def _format_http_error(code: int, details: str) -> str:
    """Return a compact operator-facing error for failed context requests."""

    normalized = " ".join(details.split())
    if "error code: 1010" in normalized.lower():
        return (
            "Agentic Memory request failed: HTTP 403 (Cloudflare error 1010). "
            "The backend edge rejected the Hermes request before it reached Agentic Memory. "
            "Verify AGENTIC_MEMORY_BACKEND_URL and AGENTIC_MEMORY_DATA_PLANE_URL, then allow "
            f"the {CLIENT_USER_AGENT} user agent on the backend edge."
        )
    if normalized:
        return f"Agentic Memory request failed: HTTP {code} {normalized[:500]}"
    return f"Agentic Memory request failed: HTTP {code}"


class AgenticMemoryClient:
    """Minimal standard-library client for backend context resolution.

    ``backend_url`` remains the control-plane URL saved during setup.
    ``data_plane_url`` is the optional branded account runtime URL used for
    normal context traffic once provisioning has completed.
    """

    def __init__(
        self,
        backend_url: str,
        api_key: str | None = None,
        data_plane_url: str | None = None,
    ) -> None:
        self.backend_url = backend_url.rstrip("/") or DEFAULT_BACKEND_URL
        self.data_plane_url = (data_plane_url or "").rstrip("/")
        self.api_key = api_key or ""

    def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Send one JSON POST request and return the decoded response."""

        base_url = self.data_plane_url or self.backend_url
        request = urllib.request.Request(
            f"{base_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            method="POST",
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": CLIENT_USER_AGENT,
                "X-Agentic-Memory-Client": "hermes",
                **({"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}),
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            details = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(_format_http_error(exc.code, details)) from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Agentic Memory request failed: {exc.reason}") from exc
        return json.loads(raw) if raw else {}


def _read_config(hermes_home: str) -> dict[str, Any]:
    """Read profile-scoped non-secret config written by the memory provider."""

    path = Path(hermes_home).expanduser() / CONFIG_FILENAME
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _looks_like_managed_runtime_url(url: str) -> bool:
    """Return whether a URL is an account runtime rather than control plane."""

    normalized = url.rstrip("/")
    return normalized != DEFAULT_BACKEND_URL and normalized.endswith(".agentmemorylabs.app")


def _resolve_backend_urls(config: dict[str, Any]) -> tuple[str, str | None]:
    """Resolve control-plane and data-plane URLs from env plus saved config.

    Early Hermes dogfood builds saved the managed runtime route under
    ``backend_url``. Current builds keep ``backend_url`` as the stable control
    plane and store the runtime in ``data_plane_url``. This compatibility path
    lets older WSL installs keep working after a fresh code copy.
    """

    configured_backend = str(config.get("backend_url") or DEFAULT_BACKEND_URL)
    configured_data_plane = config.get("data_plane_url")
    backend_url = os.environ.get("AGENTIC_MEMORY_BACKEND_URL") or configured_backend
    data_plane_url = os.environ.get("AGENTIC_MEMORY_DATA_PLANE_URL") or configured_data_plane
    if not data_plane_url and _looks_like_managed_runtime_url(backend_url):
        return DEFAULT_BACKEND_URL, backend_url
    return backend_url, str(data_plane_url) if data_plane_url else None


def _identity(config: dict[str, Any], session_id: str) -> dict[str, Any]:
    """Build the backend identity payload used for Hermes context requests."""

    project_id = os.environ.get("AGENTIC_MEMORY_PROJECT_ID") or config.get("project_id")
    workspace_id = os.environ.get("AGENTIC_MEMORY_WORKSPACE_ID") or config.get("workspace_id")
    return {
        "workspace_id": workspace_id or "hermes",
        "device_id": (
            os.environ.get("AGENTIC_MEMORY_DEVICE_ID")
            or config.get("device_id")
            or "hermes-local"
        ),
        "agent_id": (
            os.environ.get("AGENTIC_MEMORY_AGENT_ID")
            or config.get("agent_id")
            or "hermes-agent"
        ),
        "session_id": session_id,
        "project_id": project_id or None,
        "metadata": {"plugin": PLUGIN_NAME, "host": "hermes-agent"},
    }


def _message_text(message: dict[str, Any]) -> str:
    """Extract searchable text from one OpenAI-format message."""

    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(
            item["text"]
            for item in content
            if isinstance(item, dict) and isinstance(item.get("text"), str)
        )
    return "" if content is None else str(content)


class AgenticMemoryContextEngine(ContextEngine):
    """Hermes context engine backed by Agentic Memory retrieval.

    The engine does not pretend Agentic Memory can shrink arbitrary transcripts
    losslessly yet. Instead, it preserves the recent message tail and injects a
    compact memory summary as a system message, which satisfies Hermes' valid
    message-sequence contract while keeping durable context in the backend.
    """

    last_prompt_tokens: int = 0
    last_completion_tokens: int = 0
    last_total_tokens: int = 0
    threshold_tokens: int = 0
    context_length: int = 0
    compression_count: int = 0

    def __init__(self, context_length: int = 128000) -> None:
        self.context_length = context_length
        self.threshold_tokens = int(context_length * 0.75)
        self._session_id = "hermes-session"
        self._hermes_home = str(Path.home() / ".hermes")
        self._config: dict[str, Any] = {}
        self._client = AgenticMemoryClient(DEFAULT_BACKEND_URL)
        self._last_error = ""

    @property
    def name(self) -> str:
        """Return the config value used by `context.engine`."""

        return PLUGIN_NAME

    def on_session_start(self, session_id: str, **kwargs: Any) -> None:
        """Load profile config and register the Hermes session."""

        self._session_id = session_id
        self._hermes_home = str(kwargs.get("hermes_home") or self._hermes_home)
        self._config = _read_config(self._hermes_home)
        backend_url, data_plane_url = _resolve_backend_urls(self._config)
        self._client = AgenticMemoryClient(
            backend_url,
            os.environ.get("AGENTIC_MEMORY_API_KEY"),
            data_plane_url,
        )
        try:
            self._client.post(
                "/openclaw/session/register",
                {
                    **_identity(self._config, self._session_id),
                    "context_engine": PLUGIN_NAME,
                    "mode": "augment_context",
                },
            )
        except RuntimeError as exc:
            self._last_error = str(exc)

    def update_from_response(self, usage: dict[str, Any]) -> None:
        """Update Hermes-visible token counters from a model usage payload."""

        self.last_prompt_tokens = int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0)
        self.last_completion_tokens = int(
            usage.get("completion_tokens") or usage.get("output_tokens") or 0
        )
        self.last_total_tokens = int(
            usage.get("total_tokens") or self.last_prompt_tokens + self.last_completion_tokens
        )

    def update_model(self, model: str | None = None, context_length: int | None = None, **kwargs: Any) -> None:
        """Refresh token budgets after Hermes changes models."""

        if context_length is not None:
            self.context_length = int(context_length)
            self.threshold_tokens = int(self.context_length * 0.75)

    def should_compress(self, prompt_tokens: int | None = None) -> bool:
        """Return whether Hermes should call `compress()` this turn."""

        current = prompt_tokens if prompt_tokens is not None else self.last_prompt_tokens
        return bool(current and current >= self.threshold_tokens)

    def should_compress_preflight(self, messages: list[dict[str, Any]]) -> bool:
        """Cheaply estimate whether the message list is near the threshold."""

        estimated_tokens = sum(max(1, len(_message_text(message)) // 4) for message in messages)
        return estimated_tokens >= self.threshold_tokens

    def compress(
        self,
        messages: list[dict[str, Any]],
        current_tokens: int | None = None,
        focus_topic: str | None = None,
    ) -> list[dict[str, Any]]:
        """Return a valid compacted OpenAI-format message list.

        Args:
            messages: Current Hermes transcript.
            current_tokens: Optional token count supplied by Hermes.
            focus_topic: Optional `/compress <focus>` topic.

        The result keeps the latest conversation tail and prepends a system
        message assembled from Agentic Memory context resolution.
        """

        self.compression_count += 1
        query = focus_topic or self._latest_user_text(messages) or "Recall relevant Hermes session context."
        try:
            resolved = self._resolve_context(query, current_tokens)
        except RuntimeError as exc:
            self._last_error = str(exc)
            return messages[-12:] if len(messages) > 12 else list(messages)
        system_text = resolved.get("system_prompt_addition") or self._format_blocks(
            resolved.get("context_blocks") or []
        )
        tail = messages[-12:] if len(messages) > 12 else list(messages)
        if not system_text:
            return tail
        return [{"role": "system", "content": system_text}, *tail]

    def get_tool_schemas(self) -> list[dict[str, Any]]:
        """Expose a context-specific recall tool to Hermes."""

        return [
            {
                "name": "agentic_memory_context",
                "description": (
                    "Resolve compact Agentic Memory context for the current task. This can "
                    "return no blocks for narrow queries and is not a project inventory; use "
                    "agentic_memory_projects for known project/repo lists."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "limit": {"type": "integer", "default": 5},
                    },
                    "required": ["query"],
                },
            }
        ]

    def handle_tool_call(self, name: str, args: dict[str, Any], **kwargs: Any) -> str:
        """Handle context-engine-owned tools."""

        if name != "agentic_memory_context":
            return json.dumps({"error": f"Unknown Agentic Memory context tool: {name}"})
        try:
            result = self._resolve_context(str(args.get("query", "")), None, int(args.get("limit") or 5))
        except RuntimeError as exc:
            self._last_error = str(exc)
            return json.dumps({"error": self._last_error})
        return json.dumps(result)

    def get_status(self) -> dict[str, Any]:
        """Return Hermes-visible engine metrics and backend identity."""

        return {
            "name": self.name,
            "last_prompt_tokens": self.last_prompt_tokens,
            "last_completion_tokens": self.last_completion_tokens,
            "last_total_tokens": self.last_total_tokens,
            "threshold_tokens": self.threshold_tokens,
            "context_length": self.context_length,
            "compression_count": self.compression_count,
            "backend_url": self._client.backend_url,
            "data_plane_url": self._client.data_plane_url,
            "last_error": self._last_error,
        }

    def on_session_reset(self) -> None:
        """Clear per-session counters without dropping loaded config."""

        self.last_prompt_tokens = 0
        self.last_completion_tokens = 0
        self.last_total_tokens = 0

    def on_session_end(self, session_id: str, messages: list[dict[str, Any]]) -> None:
        """Accept Hermes' session-end hook.

        Turn persistence is owned by the memory provider, so the context engine
        only needs this no-op for lifecycle completeness.
        """

        return None

    def _latest_user_text(self, messages: list[dict[str, Any]]) -> str:
        """Return the latest user message text for query construction."""

        for message in reversed(messages):
            if message.get("role") == "user":
                return _message_text(message)
        return _message_text(messages[-1]) if messages else ""

    def _resolve_context(
        self,
        query: str,
        current_tokens: int | None,
        limit: int = 6,
    ) -> dict[str, Any]:
        """Call Agentic Memory's context-resolution route."""

        return self._client.post(
            "/openclaw/context/resolve",
            {
                **_identity(self._config, self._session_id),
                "query": query,
                "limit": max(1, min(limit, 20)),
                "context_budget_tokens": current_tokens or 8000,
                "include_system_prompt": True,
                "context_engine": PLUGIN_NAME,
            },
        )

    def _format_blocks(self, blocks: list[dict[str, Any]]) -> str:
        """Convert backend context blocks into a compact system message."""

        if not blocks:
            return ""
        lines = ["Agentic Memory context:"]
        for index, block in enumerate(blocks, start=1):
            title = block.get("title") or f"Memory block {index}"
            source = block.get("source") or "memory"
            content = block.get("content") or ""
            lines.append(f"[{index}] {title} ({source})\n{content}")
        return "\n\n".join(lines)


def register(ctx: Any) -> None:
    """Register this engine through Hermes' general plugin context."""

    ctx.register_context_engine(AgenticMemoryContextEngine())
