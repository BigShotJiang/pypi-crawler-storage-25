"""Hermes CLI commands for the Agentic Memory provider.

Hermes discovers this module only when `agentic-memory` is the active memory
provider. The commands intentionally stay small: they inspect local plugin
configuration and never perform background mutations outside an explicit user
command.
"""

from __future__ import annotations

import json
import os
from pathlib import Path


def _config_path() -> Path:
    """Return the active Hermes profile config path for this plugin."""

    hermes_home = os.environ.get("HERMES_HOME") or str(Path.home() / ".hermes")
    return Path(hermes_home).expanduser() / "agentic-memory.json"


def _read_config() -> dict:
    """Read the non-secret Agentic Memory config written by memory setup."""

    path = _config_path()
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _looks_like_managed_runtime_url(url: str) -> bool:
    """Return whether a saved URL is an account runtime route."""

    normalized = url.rstrip("/")
    return normalized != "https://backend.agentmemorylabs.com" and normalized.endswith(
        ".agentmemorylabs.app"
    )


def agentic_memory_command(args) -> None:
    """Dispatch `hermes agentic-memory <subcommand>` CLI requests."""

    subcommand = getattr(args, "agentic_memory_command", None)
    if subcommand == "status":
        config = _read_config()
        backend_url = config.get("backend_url") or os.environ.get("AGENTIC_MEMORY_BACKEND_URL")
        data_plane_url = config.get("data_plane_url") or os.environ.get(
            "AGENTIC_MEMORY_DATA_PLANE_URL"
        )
        migrated_runtime_url = None
        if backend_url and not data_plane_url and _looks_like_managed_runtime_url(str(backend_url)):
            migrated_runtime_url = str(backend_url).rstrip("/")
            backend_url = "https://backend.agentmemorylabs.com"
        payload = {
            "configured": bool(config),
            "config_path": str(_config_path()),
            "backend_url": backend_url,
            "data_plane_url": data_plane_url or migrated_runtime_url,
            "workspace_id": config.get("workspace_id") or os.environ.get("AGENTIC_MEMORY_WORKSPACE_ID"),
            "agent_id": config.get("agent_id") or os.environ.get("AGENTIC_MEMORY_AGENT_ID"),
            "has_api_key": bool(os.environ.get("AGENTIC_MEMORY_API_KEY")),
        }
        print(json.dumps(payload, indent=2))
        return

    print("Usage: hermes agentic-memory status")


def register_cli(subparser) -> None:
    """Build the `hermes agentic-memory` subcommand tree."""

    subcommands = subparser.add_subparsers(dest="agentic_memory_command")
    subcommands.add_parser("status", help="Show Agentic Memory provider configuration")
    subparser.set_defaults(func=agentic_memory_command)
