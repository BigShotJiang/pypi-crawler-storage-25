"""Agentic Memory provider plugin for Hermes Agent.

This module implements Hermes' `MemoryProvider` contract and adapts it to the
Agentic Memory backend. It is intentionally backend-first: Hermes supplies
session lifecycle events, while Agentic Memory remains the system of record for
storage, search, and project scoping.

The code is also importable outside a Hermes checkout. When Hermes' ABC is not
available, a tiny local shim is used so repository tests can verify behavior
without vendoring Hermes.
"""

from __future__ import annotations

import json
import os
import threading
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

try:  # pragma: no cover - exercised only inside Hermes.
    from agent.memory_provider import MemoryProvider
except Exception:  # pragma: no cover - repository tests use this shim.

    class MemoryProvider:  # type: ignore[no-redef]
        """Small compatibility shim for tests outside Hermes Agent."""

        pass


PLUGIN_NAME = "agentic-memory"
DEFAULT_BACKEND_URL = "https://backend.agentmemorylabs.com"
CONFIG_FILENAME = "agentic-memory.json"
CLIENT_USER_AGENT = "agentic-memory-hermes/0.1.4"


def _format_http_error(code: int, details: str) -> str:
    """Return a compact operator-facing error for failed backend requests."""

    normalized = " ".join(details.split())
    if "error code: 1010" in normalized.lower():
        return (
            "Agentic Memory request failed: HTTP 403 (Cloudflare error 1010). "
            "The backend edge rejected the Hermes request before it reached Agentic Memory. "
            "Verify AGENTIC_MEMORY_BACKEND_URL and AGENTIC_MEMORY_DATA_PLANE_URL, then allow "
            f"the {CLIENT_USER_AGENT} user agent on the backend edge."
        )
    if normalized:
        return f"Agentic Memory request failed: HTTP {code} {normalized[:500]}"
    return f"Agentic Memory request failed: HTTP {code}"


class AgenticMemoryClient:
    """Minimal JSON HTTP client for the Agentic Memory backend.

    Args:
        backend_url: Control-plane URL for hosted setup/resync, or the
            self-hosted backend URL.
        api_key: Optional bearer token. Hosted and authenticated self-hosted
            deployments require it.
        data_plane_url: Optional branded runtime URL returned by the hosted
            control plane. Normal memory calls use this URL when present.

    The plugin uses Python's standard library so it can run inside Hermes
    without forcing additional dependency installation.
    """

    def __init__(
        self,
        backend_url: str,
        api_key: str | None = None,
        data_plane_url: str | None = None,
    ) -> None:
        self.backend_url = backend_url.rstrip("/") or DEFAULT_BACKEND_URL
        self.data_plane_url = (data_plane_url or "").rstrip("/")
        self.api_key = api_key or ""

    def _headers(self) -> dict[str, str]:
        """Return JSON headers with optional bearer authentication.

        Hermes runs this client from WSL with Python's standard urllib stack.
        Sending an explicit product User-Agent keeps hosted edge rules from
        treating the request as an anonymous Python script and gives operators a
        stable marker to allowlist or inspect in Cloudflare logs.
        """

        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": CLIENT_USER_AGENT,
            "X-Agentic-Memory-Client": "hermes",
            **({"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}),
        }

    def get_control(self, path: str) -> dict[str, Any]:
        """Send one GET request to the control plane.

        Hosted route manifests come from the stable control-plane URL, not from
        an account runtime that may not be provisioned yet.
        """

        request = urllib.request.Request(
            f"{self.backend_url}{path}",
            method="GET",
            headers=self._headers(),
        )
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            details = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(_format_http_error(exc.code, details)) from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Agentic Memory request failed: {exc.reason}") from exc
        return json.loads(raw) if raw else {}

    def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Send one JSON POST request to the runtime/backend."""

        body = json.dumps(payload).encode("utf-8")
        base_url = self.data_plane_url or self.backend_url
        request = urllib.request.Request(
            f"{base_url}{path}",
            data=body,
            method="POST",
            headers=self._headers(),
        )
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            details = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(_format_http_error(exc.code, details)) from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Agentic Memory request failed: {exc.reason}") from exc

        return json.loads(raw) if raw else {}


def _config_path(hermes_home: str) -> Path:
    """Return the profile-scoped plugin config path."""

    return Path(hermes_home).expanduser() / CONFIG_FILENAME


def _read_config(hermes_home: str) -> dict[str, Any]:
    """Read non-secret plugin configuration from the active Hermes profile."""

    path = _config_path(hermes_home)
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _looks_like_managed_runtime_url(url: str) -> bool:
    """Return whether a URL is an account runtime rather than control plane."""

    normalized = url.rstrip("/")
    return normalized != DEFAULT_BACKEND_URL and normalized.endswith(".agentmemorylabs.app")


def _resolve_backend_urls(config: dict[str, Any]) -> tuple[str, str | None]:
    """Resolve control-plane and data-plane URLs from env plus saved config.

    Early Hermes dogfood builds saved the account runtime route under
    ``backend_url``. Current builds save the stable control plane as
    ``backend_url`` and the owned runtime as ``data_plane_url``. This migration
    keeps installed WSL profiles from sending control-plane calls to a runtime
    URL that Cloudflare may reject with error 1010.
    """

    configured_backend = str(config.get("backend_url") or DEFAULT_BACKEND_URL)
    configured_data_plane = config.get("data_plane_url")
    backend_url = os.environ.get("AGENTIC_MEMORY_BACKEND_URL") or configured_backend
    data_plane_url = os.environ.get("AGENTIC_MEMORY_DATA_PLANE_URL") or configured_data_plane
    if not data_plane_url and _looks_like_managed_runtime_url(backend_url):
        return DEFAULT_BACKEND_URL, backend_url
    return backend_url, str(data_plane_url) if data_plane_url else None


def _refresh_runtime_route(
    backend_url: str,
    api_key: str | None,
    config: dict[str, Any],
) -> dict[str, Any]:
    """Return config augmented with a hosted runtime route when available.

    This best-effort call is intentionally non-fatal. A brand-new account may
    not have a provisioned runtime yet, in which case Hermes can still save the
    control-plane URL and retry on the next setup/session start.
    """

    if not api_key:
        return config
    client = AgenticMemoryClient(backend_url, api_key)
    try:
        response = client.get_control("/product/account/runtime-route")
    except RuntimeError:
        return config
    route = response.get("runtime_route")
    if not isinstance(route, dict) or not route.get("data_plane_url"):
        return config
    return {
        **config,
        "data_plane_url": str(route["data_plane_url"]).rstrip("/"),
        "runtime_route": route,
    }


def _identity_from_config(config: dict[str, Any], session_id: str) -> dict[str, Any]:
    """Build the stable Agentic Memory identity payload for Hermes calls."""

    project_id = os.environ.get("AGENTIC_MEMORY_PROJECT_ID") or config.get("project_id")
    workspace_id = os.environ.get("AGENTIC_MEMORY_WORKSPACE_ID") or config.get("workspace_id")
    return {
        "workspace_id": workspace_id or "hermes",
        "device_id": (
            os.environ.get("AGENTIC_MEMORY_DEVICE_ID")
            or config.get("device_id")
            or "hermes-local"
        ),
        "agent_id": (
            os.environ.get("AGENTIC_MEMORY_AGENT_ID")
            or config.get("agent_id")
            or "hermes-agent"
        ),
        "session_id": session_id,
        "project_id": project_id or None,
        "metadata": {"plugin": PLUGIN_NAME, "host": "hermes-agent"},
    }


def _message_text(value: Any) -> str:
    """Normalize Hermes message content into a backend-safe text string."""

    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, dict) and isinstance(item.get("text"), str):
                parts.append(item["text"])
            elif isinstance(item, str):
                parts.append(item)
        return "\n".join(parts)
    return str(value)


class AgenticMemoryProvider(MemoryProvider):
    """Hermes memory provider backed by Agentic Memory.

    The provider does three jobs:

    - recalls relevant memory through `prefetch()`
    - exposes explicit search/read tools through `get_tool_schemas()`
    - persists completed turns through non-blocking `sync_turn()`
    """

    def __init__(self) -> None:
        self._session_id = "hermes-session"
        self._hermes_home = str(Path.home() / ".hermes")
        self._config: dict[str, Any] = {}
        self._client = AgenticMemoryClient(DEFAULT_BACKEND_URL)
        self._sync_thread: threading.Thread | None = None
        self._turn_index = 0
        self._last_error = ""

    @property
    def name(self) -> str:
        """Return the provider id used by `memory.provider`."""

        return PLUGIN_NAME

    def is_available(self) -> bool:
        """Return whether the provider has enough local config to activate.

        Hermes calls this before activation, so it must not perform network I/O.
        """

        return bool(os.environ.get("AGENTIC_MEMORY_API_KEY"))

    def initialize(self, session_id: str, **kwargs: Any) -> None:
        """Initialize the provider for one Hermes session.

        Args:
            session_id: Hermes-owned session identifier.
            **kwargs: Hermes runtime metadata. `hermes_home` is used as the
                profile-scoped storage root.
        """

        self._session_id = session_id
        self._hermes_home = str(kwargs.get("hermes_home") or self._hermes_home)
        self._config = _read_config(self._hermes_home)
        backend_url, data_plane_url = _resolve_backend_urls(self._config)
        self._client = AgenticMemoryClient(
            backend_url,
            os.environ.get("AGENTIC_MEMORY_API_KEY"),
            data_plane_url,
        )
        self._register_session()

    def get_config_schema(self) -> list[dict[str, Any]]:
        """Declare setup fields for `hermes memory setup`."""

        return [
            {
                "key": "api_key",
                "description": "Agentic Memory API key",
                "secret": True,
                "required": True,
                "env_var": "AGENTIC_MEMORY_API_KEY",
                "url": "https://backend.agentmemorylabs.com/account/auth/google/start?connector_source=hermes",
            },
            {
                "key": "backend_url",
                "description": "Agentic Memory backend URL",
                "default": DEFAULT_BACKEND_URL,
            },
            {
                "key": "workspace_id",
                "description": "Agentic Memory workspace id for Hermes sessions",
                "default": "hermes",
            },
        ]

    def save_config(self, values: dict[str, Any], hermes_home: str) -> None:
        """Persist non-secret setup values under the active Hermes profile."""

        safe_values = {key: value for key, value in values.items() if key != "api_key"}
        backend_url = str(safe_values.get("backend_url") or DEFAULT_BACKEND_URL)
        safe_values = _refresh_runtime_route(
            backend_url,
            str(values.get("api_key") or os.environ.get("AGENTIC_MEMORY_API_KEY") or ""),
            safe_values,
        )
        path = _config_path(hermes_home)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(safe_values, indent=2), encoding="utf-8")

    def system_prompt_block(self) -> str:
        """Return static prompt guidance for Hermes prompt assembly."""

        return (
            "Agentic Memory is available for durable cross-session recall. "
            "Use agentic_memory_projects before answering questions about which projects "
            "or repositories are known. Use agentic_memory_search for matching prior work, "
            "decisions, research, and code context; search is relevance retrieval, not a "
            "complete project inventory."
        )

    def get_tool_schemas(self) -> list[dict[str, Any]]:
        """Expose Agentic Memory tools to Hermes."""

        return [
            {
                "name": "agentic_memory_search",
                "description": (
                    "Search matching Agentic Memory records across conversations, research, "
                    "reports, and code. This is relevance retrieval, not an exhaustive "
                    "project inventory."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "limit": {"type": "integer", "default": 5},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "agentic_memory_projects",
                "description": (
                    "List known Agentic Memory project_id and repo_id values. Use this for "
                    "questions about what projects or repositories are available instead of "
                    "inferring inventory from search results."
                ),
                "parameters": {"type": "object", "properties": {}},
            },
            {
                "name": "agentic_memory_read",
                "description": "Read a canonical memory result returned by Agentic Memory search.",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
            },
        ]

    def handle_tool_call(self, name: str, args: dict[str, Any]) -> str:
        """Dispatch Hermes tool calls to Agentic Memory backend routes."""

        try:
            if name == "agentic_memory_search":
                return json.dumps(self._search(args.get("query", ""), int(args.get("limit") or 5)))
            if name == "agentic_memory_projects":
                return json.dumps(self._projects())
            if name == "agentic_memory_read":
                payload = {
                    **_identity_from_config(self._config, self._session_id),
                    "rel_path": str(args.get("path", "")),
                }
                return json.dumps(self._client.post("/openclaw/memory/read", payload))
        except RuntimeError as exc:
            self._last_error = str(exc)
            return json.dumps({"error": self._last_error})
        return json.dumps({"error": f"Unknown Agentic Memory tool: {name}"})

    def prefetch(self, query: str, *, session_id: str = "") -> str:
        """Recall relevant Agentic Memory context before a Hermes model call."""

        try:
            result = self._search(query, limit=5)
        except RuntimeError as exc:
            self._last_error = str(exc)
            return ""
        hits = result.get("results") or []
        if not hits:
            return ""
        lines = ["Agentic Memory recall:"]
        for index, hit in enumerate(hits[:5], start=1):
            title = hit.get("title") or hit.get("path") or f"Result {index}"
            snippet = hit.get("snippet") or hit.get("content") or hit.get("text") or ""
            lines.append(f"[{index}] {title}\n{snippet}")
        return "\n\n".join(lines)

    def queue_prefetch(self, query: str, *, session_id: str = "") -> None:
        """Accept Hermes' pre-warm hook without blocking the next turn."""

        return None

    def sync_turn(self, user_content: Any, assistant_content: Any, *, session_id: str = "") -> None:
        """Persist a completed Hermes turn without blocking the chat loop."""

        target_session_id = session_id or self._session_id

        def _sync() -> None:
            try:
                for role, content in (("user", user_content), ("assistant", assistant_content)):
                    text = _message_text(content).strip()
                    if not text:
                        continue
                    payload = {
                        **_identity_from_config(self._config, target_session_id),
                        "role": role,
                        "content": text,
                        "turn_index": self._turn_index,
                        "source_key": "chat_hermes",
                        "source_agent": "hermes",
                        "ingestion_mode": "active",
                    }
                    self._turn_index += 1
                    self._client.post("/openclaw/memory/ingest-turn", payload)
            except RuntimeError as exc:
                self._last_error = str(exc)

        if self._sync_thread and self._sync_thread.is_alive():
            self._sync_thread.join(timeout=5.0)
        self._sync_thread = threading.Thread(target=_sync, daemon=True)
        self._sync_thread.start()

    def on_session_end(self, messages: list[dict[str, Any]]) -> None:
        """Flush any outstanding background turn writes at session end."""

        if self._sync_thread and self._sync_thread.is_alive():
            self._sync_thread.join(timeout=10.0)

    def on_pre_compress(self, messages: list[dict[str, Any]]) -> None:
        """Let Agentic Memory keep recent turns before Hermes drops context."""

        try:
            for message in messages[-8:]:
                role = str(message.get("role") or "user")
                content = _message_text(message.get("content")).strip()
                if not content:
                    continue
                payload = {
                    **_identity_from_config(self._config, self._session_id),
                    "role": role,
                    "content": content,
                    "turn_index": self._turn_index,
                    "source_key": "chat_hermes_pre_compress",
                    "source_agent": "hermes",
                    "ingestion_mode": "pre_compress",
                }
                self._turn_index += 1
                self._client.post("/openclaw/memory/ingest-turn", payload)
        except RuntimeError as exc:
            self._last_error = str(exc)

    def shutdown(self) -> None:
        """Flush background work before Hermes exits."""

        self.on_session_end([])

    def _register_session(self) -> None:
        """Tell Agentic Memory that a Hermes session is active."""

        try:
            self._client.post(
                "/openclaw/session/register",
                {
                    **_identity_from_config(self._config, self._session_id),
                    "context_engine": PLUGIN_NAME,
                    "mode": "augment_context",
                },
            )
        except RuntimeError as exc:
            self._last_error = str(exc)

    def _search(self, query: Any, limit: int) -> dict[str, Any]:
        """Run Agentic Memory search with Hermes identity attached."""

        return self._client.post(
            "/openclaw/memory/search",
            {
                **_identity_from_config(self._config, self._session_id),
                "query": str(query),
                "limit": max(1, min(limit, 20)),
            },
        )

    def _projects(self) -> dict[str, Any]:
        """Return authoritative project/repo inventory for Hermes project questions."""

        return self._client.post(
            "/openclaw/tools/list-project-and-repo-ids",
            _identity_from_config(self._config, self._session_id),
        )


def register(ctx: Any) -> None:
    """Register the provider with Hermes' memory plugin discovery context."""

    ctx.register_memory_provider(AgenticMemoryProvider())
