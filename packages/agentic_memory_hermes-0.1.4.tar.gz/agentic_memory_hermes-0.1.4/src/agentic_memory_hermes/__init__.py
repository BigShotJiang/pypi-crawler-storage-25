"""Installer package for the Agentic Memory Hermes Agent plugins.

The package does not implement the Hermes memory provider directly. Instead it
ships the two Hermes plugin directories as package data and exposes a small CLI
that copies them into the active Hermes profile.
"""

__version__ = "0.1.4"
