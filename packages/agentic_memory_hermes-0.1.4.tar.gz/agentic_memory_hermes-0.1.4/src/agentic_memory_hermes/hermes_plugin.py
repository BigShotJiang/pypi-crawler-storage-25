"""Hermes entry-point wrapper for Agentic Memory plugins.

Hermes can discover Python packages that expose the `hermes_agent.plugins`
entry-point group, but the existing Hermes memory provider and context engine
live in file-based plugin directories because Hermes also supports direct
profile installs. This wrapper lets both distribution styles share the same
runtime code by loading those bundled plugin modules and forwarding Hermes'
registration context to each one.
"""

from __future__ import annotations

import importlib.util
import sys
from importlib import resources
from pathlib import Path
from types import ModuleType
from typing import Any

PACKAGE_NAME = "agentic_memory_hermes"


def _bundled_plugins_root() -> Path:
    """Return the bundled plugin directory from a wheel or source checkout."""

    source_root = Path(__file__).resolve().parents[2] / "plugins"
    if source_root.is_dir():
        return source_root

    packaged_root = resources.files(PACKAGE_NAME).joinpath("plugins")
    if packaged_root.is_dir():
        return Path(str(packaged_root))

    raise FileNotFoundError("Could not locate bundled Hermes plugin files.")


def _load_plugin_module(relative_init: str, module_name: str) -> ModuleType:
    """Load one bundled Hermes plugin module from its `__init__.py` file."""

    init_path = _bundled_plugins_root() / relative_init
    spec = importlib.util.spec_from_file_location(module_name, init_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec for {init_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def register(ctx: Any) -> None:
    """Register both Agentic Memory Hermes plugin surfaces.

    Args:
        ctx: Hermes' plugin registration context. It is expected to expose
            `register_memory_provider` and `register_context_engine`.
    """

    memory_module = _load_plugin_module(
        "memory/agentic-memory/__init__.py",
        "agentic_memory_hermes._memory_plugin",
    )
    context_module = _load_plugin_module(
        "context_engine/agentic-memory/__init__.py",
        "agentic_memory_hermes._context_engine_plugin",
    )

    memory_module.register(ctx)
    context_module.register(ctx)

