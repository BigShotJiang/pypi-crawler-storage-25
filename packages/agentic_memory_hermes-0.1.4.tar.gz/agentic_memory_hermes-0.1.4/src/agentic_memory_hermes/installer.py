"""Install Agentic Memory's Hermes Agent plugins into a Hermes profile.

Hermes discovers memory providers and context engines from two different
directories. That makes a raw Python package insufficient by itself: after the
package is downloaded by `uvx` or `pipx`, the plugin files still need to be
placed under the user's Hermes home. This module is the bridge from package
manager install to Hermes' file-based plugin discovery.

Hermes' specialized memory-provider and context-engine loaders read from the
installed Hermes Agent plugin tree under
`$HERMES_HOME/hermes-agent/plugins/<category>/<name>`. The installer writes
there directly so the files land beside Hermes' bundled providers.
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from importlib import resources
from pathlib import Path

PACKAGE_NAME = "agentic_memory_hermes"
PLUGIN_NAME = "agentic-memory"


def _default_hermes_home() -> Path:
    """Return the Hermes profile home used by Hermes Agent.

    Hermes honors `HERMES_HOME` for profile isolation. When that variable is
    absent, Hermes defaults to `~/.hermes`.
    """

    return Path(os.environ.get("HERMES_HOME", "~/.hermes")).expanduser()


def _bundled_plugins_root() -> Path:
    """Locate bundled plugin files in a wheel or in the source checkout.

    Wheels include `agentic_memory_hermes/plugins` through Hatch's
    `force-include` setting. During repo-local tests, the files live beside the
    packaging metadata under `packages/am-hermes/plugins`, so the fallback keeps
    the installer runnable before the wheel is built.
    """

    source_root = Path(__file__).resolve().parents[2] / "plugins"
    if source_root.is_dir():
        return source_root

    packaged_root = resources.files(PACKAGE_NAME).joinpath("plugins")
    if packaged_root.is_dir():
        return Path(str(packaged_root))

    raise FileNotFoundError("Could not locate bundled Hermes plugin files.")


def _copy_tree(source: Path, target: Path, *, force: bool, dry_run: bool) -> None:
    """Copy one Hermes plugin directory to its discovery target.

    Args:
        source: Bundled plugin directory inside this package.
        target: Hermes discovery directory to create.
        force: Remove an existing target before copying.
        dry_run: Print intended actions without touching the filesystem.

    Raises:
        FileExistsError: If the target exists and `force` is false.
    """

    if target.exists() and not force:
        raise FileExistsError(
            f"{target} already exists. Re-run with --force to replace the installed plugin."
        )

    print(f"{'Would install' if dry_run else 'Installing'} {source} -> {target}")
    if dry_run:
        return

    if target.exists():
        shutil.rmtree(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    ignore = shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo")
    shutil.copytree(source, target, ignore=ignore)


def _remove_old_profile_copies(hermes_home: Path, *, dry_run: bool) -> None:
    """Remove paths used by earlier broken installer builds.

    Versions 0.1.1 and 0.1.2 wrote the memory provider into profile plugin
    directories. Hermes' provider loader for this install shape expects the
    installed-agent plugin tree instead, so `--force` cleans those stale copies
    to avoid future agents reading the wrong directory and thinking it is the
    active install.
    """

    stale_targets = [
        hermes_home / "plugins" / PLUGIN_NAME,
        hermes_home / "plugins" / "memory" / PLUGIN_NAME,
    ]
    for target in stale_targets:
        if not target.exists():
            continue
        print(f"{'Would remove stale' if dry_run else 'Removing stale'} {target}")
        if not dry_run:
            shutil.rmtree(target)


def _run_hermes_config(key: str, value: str, *, dry_run: bool) -> bool:
    """Set one Hermes config key through Hermes' own CLI when available.

    Returns:
        True when the command was run successfully, or False when Hermes is not
        on PATH or rejected the setting.
    """

    command = ["hermes", "config", "set", key, value]
    print(f"{'Would run' if dry_run else 'Running'}: {' '.join(command)}")
    if dry_run:
        return True

    try:
        subprocess.run(command, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError) as exc:
        print(f"Warning: could not run {' '.join(command)} ({exc}).", file=sys.stderr)
        return False
    return True


def install(args: argparse.Namespace) -> int:
    """Install the memory provider and context engine into Hermes."""

    hermes_home = Path(args.hermes_home).expanduser()
    plugins_root = _bundled_plugins_root()

    memory_source = plugins_root / "memory" / PLUGIN_NAME
    context_source = plugins_root / "context_engine" / PLUGIN_NAME
    memory_target = hermes_home / "hermes-agent" / "plugins" / "memory" / PLUGIN_NAME
    context_target = hermes_home / "hermes-agent" / "plugins" / "context_engine" / PLUGIN_NAME

    if args.force:
        _remove_old_profile_copies(hermes_home, dry_run=args.dry_run)

    _copy_tree(memory_source, memory_target, force=args.force, dry_run=args.dry_run)
    _copy_tree(context_source, context_target, force=args.force, dry_run=args.dry_run)

    if args.configure:
        _run_hermes_config("memory.provider", PLUGIN_NAME, dry_run=args.dry_run)
        _run_hermes_config("context.engine", PLUGIN_NAME, dry_run=args.dry_run)

    print("Agentic Memory Hermes plugin install complete.")
    print(f"Hermes home: {hermes_home}")
    print(f"Memory provider: {memory_target}")
    print(f"Context engine: {context_target}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    """Build the command-line parser for the installer."""

    parser = argparse.ArgumentParser(
        prog="agentic-memory-hermes",
        description="Install Agentic Memory's Hermes Agent plugins.",
    )
    subparsers = parser.add_subparsers(dest="command")

    install_parser = subparsers.add_parser(
        "install",
        help="Copy Agentic Memory's Hermes plugins into the active Hermes profile.",
    )
    install_parser.add_argument(
        "--hermes-home",
        default=str(_default_hermes_home()),
        help="Hermes profile home. Defaults to HERMES_HOME or ~/.hermes.",
    )
    install_parser.add_argument(
        "--force",
        action="store_true",
        help="Replace existing Agentic Memory Hermes plugin directories.",
    )
    install_parser.add_argument(
        "--no-configure",
        dest="configure",
        action="store_false",
        help="Copy files only; do not run `hermes config set`.",
    )
    install_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show intended file copies and config commands without changing anything.",
    )
    install_parser.set_defaults(func=install, configure=True)

    return parser


def main(argv: list[str] | None = None) -> int:
    """Entry point used by `uvx agentic-memory-hermes` and `pipx run`."""

    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        parser.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
