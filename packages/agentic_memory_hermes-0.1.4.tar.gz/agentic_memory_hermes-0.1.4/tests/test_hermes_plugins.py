"""Tests for the Agentic Memory Hermes plugin showcase.

The real Hermes ABCs are intentionally not required here. The plugin modules
provide local import shims so this repository can verify core behavior and file
layout without cloning Hermes Agent into the test environment.
"""

from __future__ import annotations

import importlib.util
import json
import subprocess
import threading
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _load_module(path: Path, name: str):
    """Load a plugin module from its file path like Hermes discovery does."""

    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_memory_provider_contract_and_config(tmp_path, monkeypatch):
    """The memory plugin should expose Hermes provider hooks and save config."""

    monkeypatch.setenv("AGENTIC_MEMORY_API_KEY", "test-key")
    module = _load_module(
        ROOT / "plugins" / "memory" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_memory_test",
    )

    provider = module.AgenticMemoryProvider()
    assert provider.name == "agentic-memory"
    assert provider.is_available() is True

    schema = provider.get_config_schema()
    assert any(field["env_var"] == "AGENTIC_MEMORY_API_KEY" for field in schema)
    assert any(field["key"] == "backend_url" for field in schema)

    provider.save_config(
        {
            "api_key": "should-not-be-written",
            "backend_url": "http://127.0.0.1:8765",
            "workspace_id": "hermes-test",
        },
        str(tmp_path),
    )
    saved = json.loads((tmp_path / "agentic-memory.json").read_text(encoding="utf-8"))
    assert saved == {
        "backend_url": "http://127.0.0.1:8765",
        "workspace_id": "hermes-test",
    }

    tools = provider.get_tool_schemas()
    tool_names = {tool["name"] for tool in tools}
    assert {"agentic_memory_search", "agentic_memory_projects", "agentic_memory_read"} <= tool_names
    search_tool = next(tool for tool in tools if tool["name"] == "agentic_memory_search")
    projects_tool = next(tool for tool in tools if tool["name"] == "agentic_memory_projects")
    assert "semantic" not in search_tool["description"].lower()
    assert "not an exhaustive project inventory" in search_tool["description"]
    assert "known Agentic Memory project_id and repo_id values" in projects_tool["description"]


def test_memory_provider_projects_tool_uses_inventory_route():
    """Hermes should not infer project inventory from relevance search results."""

    module = _load_module(
        ROOT / "plugins" / "memory" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_memory_projects_tool_test",
    )
    calls = []

    class Client:
        def post(self, path, payload):
            calls.append((path, payload))
            return {
                "status": "ok",
                "payload": {
                    "project_ids": ["ladybug"],
                    "repo_ids": ["jarmen423/agentic-memory", "jarmen423/m26pipeline"],
                },
            }

    provider = module.AgenticMemoryProvider()
    provider._client = Client()
    provider._config = {"workspace_id": "hermes-test"}
    provider._session_id = "session-1"

    result = json.loads(provider.handle_tool_call("agentic_memory_projects", {}))

    assert result["payload"]["repo_ids"] == ["jarmen423/agentic-memory", "jarmen423/m26pipeline"]
    assert calls == [
        (
            "/openclaw/tools/list-project-and-repo-ids",
            {
                "workspace_id": "hermes-test",
                "device_id": "hermes-local",
                "agent_id": "hermes-agent",
                "session_id": "session-1",
                "project_id": None,
                "metadata": {"plugin": "agentic-memory", "host": "hermes-agent"},
            },
        )
    ]


def test_memory_provider_registers_with_context():
    """Hermes discovery should be able to call register(ctx)."""

    module = _load_module(
        ROOT / "plugins" / "memory" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_memory_register_test",
    )

    class Context:
        def __init__(self) -> None:
            self.provider = None

        def register_memory_provider(self, provider) -> None:
            self.provider = provider

    ctx = Context()
    module.register(ctx)
    assert ctx.provider.name == "agentic-memory"


def test_memory_client_sends_hermes_identity_headers(monkeypatch):
    """Hosted edge rules should see Hermes as a named Agentic Memory client."""

    module = _load_module(
        ROOT / "plugins" / "memory" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_memory_headers_test",
    )
    captured = {}

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *_):
            return None

        def read(self):
            return b"{}"

    def fake_urlopen(request, timeout):
        captured["headers"] = {key.lower(): value for key, value in request.header_items()}
        return Response()

    monkeypatch.setattr(module.urllib.request, "urlopen", fake_urlopen)
    module.AgenticMemoryClient("https://backend.example", "secret").post("/route", {"ok": True})

    assert captured["headers"]["user-agent"] == module.CLIENT_USER_AGENT
    assert captured["headers"]["x-agentic-memory-client"] == "hermes"
    assert captured["headers"]["accept"] == "application/json"


def test_memory_provider_migrates_runtime_backend_url(monkeypatch, tmp_path):
    """Older Hermes configs saved runtime routes under backend_url."""

    monkeypatch.setenv("AGENTIC_MEMORY_API_KEY", "test-key")
    module = _load_module(
        ROOT / "plugins" / "memory" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_memory_url_migration_test",
    )
    (tmp_path / "agentic-memory.json").write_text(
        json.dumps(
            {
                "backend_url": "https://rt-c84ba9f0f933f9bb.agentmemorylabs.app",
                "workspace_id": "hermes",
            }
        ),
        encoding="utf-8",
    )

    provider = module.AgenticMemoryProvider()
    provider._register_session = lambda: None
    provider.initialize("session-1", hermes_home=str(tmp_path))

    assert provider._client.backend_url == module.DEFAULT_BACKEND_URL
    assert provider._client.data_plane_url == "https://rt-c84ba9f0f933f9bb.agentmemorylabs.app"


def test_memory_background_sync_records_errors_without_thread_traceback():
    """Failed async turn ingest should not leak an uncaught exception into Hermes."""

    module = _load_module(
        ROOT / "plugins" / "memory" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_memory_sync_error_test",
    )

    class FailingClient:
        def post(self, *_args, **_kwargs):
            raise RuntimeError("backend blocked")

    provider = module.AgenticMemoryProvider()
    provider._client = FailingClient()

    original_excepthook = threading.excepthook
    uncaught = []

    def capture_excepthook(args):
        uncaught.append(args)

    threading.excepthook = capture_excepthook
    try:
        provider.sync_turn("hello", "world")
        provider.shutdown()
    finally:
        threading.excepthook = original_excepthook

    assert uncaught == []
    assert provider._last_error == "backend blocked"


def test_context_engine_contract_and_compression(monkeypatch):
    """The context engine should satisfy Hermes' core compression contract."""

    module = _load_module(
        ROOT / "plugins" / "context_engine" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_context_test",
    )

    engine = module.AgenticMemoryContextEngine(context_length=100)
    assert engine.name == "agentic-memory"
    assert engine.threshold_tokens == 75
    [context_tool] = engine.get_tool_schemas()
    assert "not a project inventory" in context_tool["description"]

    engine.update_from_response(
        {"prompt_tokens": 80, "completion_tokens": 10, "total_tokens": 90}
    )
    assert engine.should_compress() is True

    def fake_resolve(query, current_tokens, limit=6):
        return {"system_prompt_addition": f"Memory for {query}"}

    engine._resolve_context = fake_resolve
    messages = [{"role": "user", "content": "what did we decide?"}]
    compacted = engine.compress(messages, current_tokens=90)
    assert compacted[0] == {
        "role": "system",
        "content": "Memory for what did we decide?",
    }
    assert compacted[1:] == messages


def test_context_engine_handles_backend_failure_during_compression():
    """Compression should preserve the recent transcript if context lookup fails."""

    module = _load_module(
        ROOT / "plugins" / "context_engine" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_context_failure_test",
    )

    engine = module.AgenticMemoryContextEngine(context_length=100)

    def fail_resolve(*_args, **_kwargs):
        raise RuntimeError("context route blocked")

    engine._resolve_context = fail_resolve
    messages = [{"role": "user", "content": f"message {index}"} for index in range(15)]
    compacted = engine.compress(messages, current_tokens=90)

    assert compacted == messages[-12:]
    assert engine._last_error == "context route blocked"


def test_context_client_sends_hermes_identity_headers(monkeypatch):
    """The context engine should use the same edge-visible client headers."""

    module = _load_module(
        ROOT / "plugins" / "context_engine" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_context_headers_test",
    )
    captured = {}

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *_):
            return None

        def read(self):
            return b"{}"

    def fake_urlopen(request, timeout):
        captured["headers"] = {key.lower(): value for key, value in request.header_items()}
        return Response()

    monkeypatch.setattr(module.urllib.request, "urlopen", fake_urlopen)
    module.AgenticMemoryClient("https://backend.example", "secret").post("/context", {"ok": True})

    assert captured["headers"]["user-agent"] == module.CLIENT_USER_AGENT
    assert captured["headers"]["x-agentic-memory-client"] == "hermes"
    assert captured["headers"]["accept"] == "application/json"


def test_context_engine_migrates_runtime_backend_url(monkeypatch, tmp_path):
    """The context plugin should share the memory provider's URL migration."""

    monkeypatch.setenv("AGENTIC_MEMORY_API_KEY", "test-key")
    module = _load_module(
        ROOT / "plugins" / "context_engine" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_context_url_migration_test",
    )
    (tmp_path / "agentic-memory.json").write_text(
        json.dumps(
            {
                "backend_url": "https://rt-c84ba9f0f933f9bb.agentmemorylabs.app",
                "workspace_id": "hermes",
            }
        ),
        encoding="utf-8",
    )

    class RegisterOnlyClient(module.AgenticMemoryClient):
        def post(self, *_args, **_kwargs):
            return {}

    original_client = module.AgenticMemoryClient
    created = {}

    def capture_client(*args, **kwargs):
        client = RegisterOnlyClient(*args, **kwargs)
        created["client"] = client
        return client

    module.AgenticMemoryClient = capture_client
    try:
        module.AgenticMemoryContextEngine().on_session_start("session-1", hermes_home=str(tmp_path))
    finally:
        module.AgenticMemoryClient = original_client

    assert created["client"].backend_url == module.DEFAULT_BACKEND_URL
    assert created["client"].data_plane_url == "https://rt-c84ba9f0f933f9bb.agentmemorylabs.app"


def test_context_engine_registers_with_context():
    """Hermes general plugin registration should receive the context engine."""

    module = _load_module(
        ROOT / "plugins" / "context_engine" / "agentic-memory" / "__init__.py",
        "agentic_memory_hermes_context_register_test",
    )

    class Context:
        def __init__(self) -> None:
            self.engine = None

        def register_context_engine(self, engine) -> None:
            self.engine = engine

    ctx = Context()
    module.register(ctx)
    assert ctx.engine.name == "agentic-memory"


def test_installer_copies_both_hermes_plugin_slots(tmp_path, monkeypatch):
    """The PyPI/uv installer should install both Hermes discovery directories."""

    module = _load_module(
        ROOT / "src" / "agentic_memory_hermes" / "installer.py",
        "agentic_memory_hermes_installer_copy_test",
    )
    commands = []

    def fake_run(command, check):
        commands.append((command, check))
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(module.subprocess, "run", fake_run)

    exit_code = module.main(["install", "--hermes-home", str(tmp_path), "--force"])

    memory_manifest = (
        tmp_path
        / "hermes-agent"
        / "plugins"
        / "memory"
        / "agentic-memory"
        / "plugin.yaml"
    )
    context_manifest = (
        tmp_path
        / "hermes-agent"
        / "plugins"
        / "context_engine"
        / "agentic-memory"
        / "plugin.yaml"
    )
    assert exit_code == 0
    assert memory_manifest.read_text(encoding="utf-8").startswith("name: agentic-memory")
    assert context_manifest.read_text(encoding="utf-8").startswith("name: agentic-memory")
    assert not (tmp_path / "plugins" / "agentic-memory").exists()
    assert not (tmp_path / "plugins" / "memory" / "agentic-memory").exists()
    assert not list(tmp_path.rglob("__pycache__"))
    assert commands == [
        (["hermes", "config", "set", "memory.provider", "agentic-memory"], True),
        (["hermes", "config", "set", "context.engine", "agentic-memory"], True),
    ]


def test_installer_dry_run_does_not_touch_filesystem(tmp_path):
    """Dry runs should be useful for docs and support without mutating profiles."""

    module = _load_module(
        ROOT / "src" / "agentic_memory_hermes" / "installer.py",
        "agentic_memory_hermes_installer_dry_run_test",
    )

    exit_code = module.main(["install", "--hermes-home", str(tmp_path), "--dry-run"])

    assert exit_code == 0
    assert not (tmp_path / "plugins").exists()


def test_installer_force_removes_stale_profile_memory_copies(tmp_path, monkeypatch):
    """Force installs should clean the profile paths written by older builds."""

    module = _load_module(
        ROOT / "src" / "agentic_memory_hermes" / "installer.py",
        "agentic_memory_hermes_installer_no_legacy_test",
    )

    monkeypatch.setattr(module.subprocess, "run", lambda *_args, **_kwargs: None)

    stale_flat = tmp_path / "plugins" / "agentic-memory"
    stale_category = tmp_path / "plugins" / "memory" / "agentic-memory"
    stale_flat.mkdir(parents=True)
    stale_category.mkdir(parents=True)
    (stale_flat / "plugin.yaml").write_text("name: stale\n", encoding="utf-8")
    (stale_category / "plugin.yaml").write_text("name: stale\n", encoding="utf-8")

    exit_code = module.main(["install", "--hermes-home", str(tmp_path), "--force"])

    assert exit_code == 0
    assert not (tmp_path / "plugins" / "agentic-memory").exists()
    assert not (tmp_path / "plugins" / "memory" / "agentic-memory").exists()
    assert (
        tmp_path
        / "hermes-agent"
        / "plugins"
        / "memory"
        / "agentic-memory"
        / "plugin.yaml"
    ).exists()


def test_entrypoint_wrapper_registers_memory_and_context_plugins():
    """Pip installs into Hermes' own venv should work through entry points."""

    module = _load_module(
        ROOT / "src" / "agentic_memory_hermes" / "hermes_plugin.py",
        "agentic_memory_hermes_entrypoint_test",
    )

    class Context:
        def __init__(self) -> None:
            self.provider = None
            self.engine = None

        def register_memory_provider(self, provider) -> None:
            self.provider = provider

        def register_context_engine(self, engine) -> None:
            self.engine = engine

    ctx = Context()
    module.register(ctx)

    assert ctx.provider.name == "agentic-memory"
    assert ctx.engine.name == "agentic-memory"
