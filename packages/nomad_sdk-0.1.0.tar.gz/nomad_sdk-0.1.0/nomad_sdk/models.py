"""Data models for Nomad responses."""

import dataclasses
from typing import Optional

from .protocol import _decode_u64, _decode_u32, _decode_u8, _decode_str


@dataclasses.dataclass
class Entity:
    """A single DOM element extracted by Nomad."""
    id: int
    tag: str = ""
    text: str = ""
    role: str = ""
    href: str = ""
    classes: str = ""
    intent: str = ""
    is_interactive: bool = False
    parent_id: int = 0

    @classmethod
    def from_dict(cls, d):
        return cls(
            id=d.get("id", 0),
            tag=d.get("tag", d.get("t", "")),
            text=d.get("text", d.get("x", "")),
            role=d.get("role", d.get("r", "")),
            href=d.get("href", d.get("h", "")),
            classes=d.get("classes", ""),
            intent=d.get("intent", d.get("i", "")),
            is_interactive=d.get("is_interactive", d.get("interactive", False))
                == 1 or d.get("is_interactive", False),
            parent_id=d.get("parentId", d.get("p", 0)),
        )

    @classmethod
    def from_bincode(cls, data, pos=0):
        """Decode EntitySummary from bincode at position pos."""
        eid, pos = _decode_u64(data, pos)
        tag, pos = _decode_str(data, pos)
        text, pos = _decode_str(data, pos)
        role, pos = _decode_str(data, pos)
        href, pos = _decode_str(data, pos)
        classes, pos = _decode_str(data, pos)
        intent, pos = _decode_str(data, pos)
        interactive_val, pos = _decode_u8(data, pos)
        parent_id, pos = _decode_u64(data, pos)
        return cls(
            id=eid, tag=tag, text=text, role=role, href=href,
            classes=classes, intent=intent,
            is_interactive=bool(interactive_val),
            parent_id=parent_id,
        ), pos


@dataclasses.dataclass
class Page:
    """A rendered web page with its entities."""
    tab_id: int
    url: str = ""
    title: str = ""
    entities: list[Entity] = dataclasses.field(default_factory=list)
    viewport: tuple[int, int] = (800, 600)

    def find_one(self, role=None, tag=None, text=None, intent=None) -> Optional[Entity]:
        for e in self.entities:
            if role and e.role != role:
                continue
            if tag and e.tag != tag:
                continue
            if text and text not in e.text:
                continue
            if intent and e.intent != intent:
                continue
            return e
        return None

    def find_all(self, role=None, tag=None, text=None, intent=None) -> list[Entity]:
        out = []
        for e in self.entities:
            if role and e.role != role:
                continue
            if tag and e.tag != tag:
                continue
            if text and text not in e.text:
                continue
            if intent and e.intent != intent:
                continue
            out.append(e)
        return out
