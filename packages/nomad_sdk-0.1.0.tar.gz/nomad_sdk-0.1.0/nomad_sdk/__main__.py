"""CLI entry point for nomad-sdk.

Usage:
    python -m nomad_sdk [url] [format]
"""

import sys
import asyncio

from .client import NomadClient


def main():
    url = sys.argv[1] if len(sys.argv) > 1 else "https://example.com"
    fmt = int(sys.argv[2]) if len(sys.argv) > 2 else 3

    async def run():
        async with NomadClient() as client:
            page = client.navigate(url, fmt=fmt)
            print(f"URL: {page.url}")
            print(f"Title: {page.title}")
            print(f"Entities: {len(page.entities)}")
            for e in page.entities[:10]:
                print(
                    f"  [{e.id}] <{e.tag}>"
                    f" role={e.role}"
                    f" intent={e.intent}"
                    f" text={e.text[:60]}"
                )

    if sys.platform == "win32":
        asyncio.set_event_loop_policy(
            asyncio.WindowsSelectorEventLoopPolicy()
        )
    asyncio.run(run())


if __name__ == "__main__":
    main()
