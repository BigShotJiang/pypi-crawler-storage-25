"""High-level async client for Nomad headless browser daemon."""

import socket
import struct
from typing import Optional

from .protocol import (
    SOCKET_PATH,
    _recv, _recv_exact, _send,
    _encode_u8, _encode_u32, _encode_u64, _encode_f32, _encode_str,
    _encode_option_str, _encode_entity_query,
    _decode_u64, _decode_u32, _decode_str, _decode_ecs_frame,
    NAVIGATE, SCROLL, RESIZE, NEWTAB, CLOSETAB, GO_BACK, GO_FORWARD,
    EVALUATE, FIND_ENTITIES, ENTITY_SNAPSHOT, CLICK_ENTITY, INPUT_ENTITY,
    CLICK_SELECTOR, GET_ACTION_LOG, COMPARE_TABS, TRANSFER_TAB, HEALTH,
    FRAME, FRAME_DELTA, METADATA, ERROR, EVALUATE_RESULT,
    FOUND_ENTITIES, ACTION_LOG_RESP, TAB_COMPARISON, HEALTH_RESULT,
    NAVIGATE_RESULT,
)
from .models import Page, Entity


class NomadClient:
    """Async client for Nomad headless browser daemon.

    Connects to a running Nomad daemon over a Unix Domain Socket.
    All methods are synchronous I/O (blocking socket calls).

    Usage:
        async with NomadClient() as client:
            page = client.navigate("https://example.com")
            print(page.title, len(page.entities))
            btn = page.find_one(role="button", text="Sign In")
            if btn:
                client.click(btn.id)
    """

    def __init__(self, socket_path: str = SOCKET_PATH):
        self.socket_path = socket_path
        self._stream: Optional[socket.socket] = None
        self.tab_id: int = 1

    async def __aenter__(self):
        self._stream = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._stream.settimeout(30)
        self._stream.connect(self.socket_path)
        return self

    async def __aexit__(self, *args):
        if self._stream:
            self._stream.close()

    def _check_connected(self):
        if not self._stream:
            raise RuntimeError(
                "not connected (use 'async with NomadClient() as client:')"
            )

    # ── Core transport ──

    def _recv_one(self):
        """Read one response, return (variant, payload)."""
        return _recv(self._stream)

    def _send_msg(self, msg_type: int, payload: bytes):
        _send(self._stream, msg_type, payload)

    # ── Navigation ──

    def navigate(self, url: str, fmt: int = 3) -> Page:
        """Navigate to a URL and return the page state.

        Args:
            url: The URL to navigate to
            fmt: Output format. Use 3 (Agent JSON) for rich entities,
                 4 (Summary) for interactive only.
        Returns:
            Page with entities, title, url, viewport
        """
        self._check_connected()
        tab_id = self.tab_id
        self._send_msg(
            NAVIGATE,
            _encode_u64(tab_id) + _encode_str(url) + _encode_u8(fmt),
        )

        # Read response: single NavigateResult (variant 30)
        lb = _recv_exact(self._stream, 4)
        msglen = struct.unpack("<I", lb)[0]
        payload = _recv_exact(self._stream, msglen)
        if len(payload) < 4:
            raise RuntimeError("Empty response from daemon")

        variant = struct.unpack("<I", payload[:4])[0]
        rest = payload[4:]

        if variant == ERROR:
            tid, pos = _decode_u64(rest, 0)
            desc, _ = _decode_str(rest, pos)
            raise RuntimeError(f"Navigation error: {desc}")

        if variant != NAVIGATE_RESULT:
            raise RuntimeError(f"Expected NavigateResult (30), got variant {variant}")

        # NavigateResult: tab_id(u64) + title(str) + url(str) + frame(EcsFrame) + format(u8)
        pos = 0
        tid, pos = _decode_u64(rest, pos)
        title, pos = _decode_str(rest, pos)
        url_out, pos = _decode_str(rest, pos)
        frame, pos = _decode_ecs_frame(rest, pos)

        entities = [Entity.from_dict(e) for e in frame.get("entities", [])]
        vp = frame.get("viewport", (0.0, 0.0, 800.0, 600.0))
        return Page(
            tab_id=tid,
            url=url_out or url,
            title=title,
            entities=entities,
            viewport=(int(vp[2]), int(vp[3])),
        )

    # ── Snapshot ──

    def snapshot(self, tab_id: Optional[int] = None) -> Page:
        """Get current page state without re-fetching (format=3)."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(ENTITY_SNAPSHOT, _encode_u64(tid))
        variant, payload = self._recv_one()
        if variant == ERROR:
            _, desc = _decode_str(payload, 8)
            raise RuntimeError(f"Snapshot error: {desc}")
        try:
            text = payload.decode("utf-8")
            parsed = json.loads(text)
            entities = [Entity.from_dict(e) for e in parsed.get("entities", [])]
            vp = parsed.get("viewport", [800, 600])
            return Page(
                tab_id=tid,
                url=parsed.get("url", ""),
                title=parsed.get("title", ""),
                entities=entities,
                viewport=(vp[0], vp[1]),
            )
        except (UnicodeDecodeError, json.JSONDecodeError):
            return Page(tab_id=tid)

    # ── Interactive actions ──

    def click(self, entity_id: int, tab_id: Optional[int] = None) -> str:
        """Click an entity by ID."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(
            CLICK_ENTITY, _encode_u64(tid) + _encode_u64(entity_id)
        )
        variant, payload = self._recv_one()
        if variant == EVALUATE_RESULT:
            s, _ = _decode_str(payload, 8)
            return s
        return f"error: {payload}"

    def input_text(
        self, entity_id: int, value: str, tab_id: Optional[int] = None
    ) -> str:
        """Input text into an entity by ID."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(
            INPUT_ENTITY,
            _encode_u64(tid) + _encode_u64(entity_id) + _encode_str(value),
        )
        variant, payload = self._recv_one()
        if variant == EVALUATE_RESULT:
            s, _ = _decode_str(payload, 8)
            return s
        return f"error: {payload}"

    def click_selector(self, query: dict, tab_id: Optional[int] = None) -> str:
        """Click the first entity matching a semantic query."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(
            CLICK_SELECTOR, _encode_u64(tid) + _encode_entity_query(query)
        )
        variant, payload = self._recv_one()
        if variant == EVALUATE_RESULT:
            s, _ = _decode_str(payload, 8)
            return s
        return f"error: {payload}"

    # ── Find entities ──

    def find(
        self, query: dict, tab_id: Optional[int] = None
    ) -> list[Entity]:
        """Find entities matching a semantic query.

        Query keys: role, tag, intent, text_contains, label, limit.
        """
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(
            FIND_ENTITIES, _encode_u64(tid) + _encode_entity_query(query)
        )
        variant, payload = self._recv_one()

        if variant == ERROR:
            _, desc = _decode_str(payload, 8)
            raise RuntimeError(f"Find error: {desc}")
        if variant != FOUND_ENTITIES:
            return []

        # FoundEntities: tab_id(u64) + vec_len(u64) + [EntitySummary × N]
        _, pos = _decode_u64(payload, 0)
        count, pos = _decode_u64(payload, pos)
        entities = []
        for _ in range(count):
            ent, pos = Entity.from_bincode(payload, pos)
            entities.append(ent)
        return entities

    # ── JavaScript evaluation ──

    def evaluate(
        self, js: str, timeout_ms: int = 5000, tab_id: Optional[int] = None
    ) -> str:
        """Execute JavaScript in the tab and return the result."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(
            EVALUATE,
            _encode_u64(tid) + _encode_str(js) + _encode_u32(timeout_ms),
        )
        variant, payload = self._recv_one()
        if variant == EVALUATE_RESULT:
            s, _ = _decode_str(payload, 8)
            return s
        if variant == ERROR:
            _, desc = _decode_str(payload, 8)
            return f"error: {desc}"
        return ""

    # ── Action history ──

    def get_action_log(self, tab_id: Optional[int] = None) -> list[dict]:
        """Get action history for a tab."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(GET_ACTION_LOG, _encode_u64(tid))
        variant, payload = self._recv_one()

        if variant == ERROR:
            _, desc = _decode_str(payload, 8)
            raise RuntimeError(f"ActionLog error: {desc}")
        if variant != ACTION_LOG_RESP:
            return []

        _, pos = _decode_u64(payload, 0)
        count, pos = _decode_u64(payload, pos)
        entries = []
        for _ in range(count):
            seq, pos = _decode_u64(payload, pos)
            action, pos = _decode_str(payload, pos)
            target_id, pos = _decode_u64(payload, pos)
            value, pos = _decode_str(payload, pos)
            timestamp, pos = _decode_u64(payload, pos)
            entity_count, pos = _decode_u32(payload, pos)
            entries.append({
                "sequence": seq,
                "action": action,
                "target_id": target_id,
                "value": value,
                "timestamp": timestamp,
                "entity_count": entity_count,
            })
        return entries

    # ── Multi-tab operations ──

    def compare_tabs(self, tab_a: int, tab_b: int) -> str:
        """Compare two tabs' page states."""
        self._check_connected()
        self._send_msg(
            COMPARE_TABS, _encode_u64(tab_a) + _encode_u64(tab_b)
        )
        variant, payload = self._recv_one()
        if variant == TAB_COMPARISON:
            _, pos = _decode_u64(payload, 0)
            _, pos = _decode_u64(payload, pos)
            summary, _ = _decode_str(payload, pos)
            return summary
        return ""

    def transfer_tab(self, from_tab: int, to_tab: int) -> str:
        """Transfer entities from one tab to another."""
        self._check_connected()
        self._send_msg(
            TRANSFER_TAB, _encode_u64(from_tab) + _encode_u64(to_tab)
        )
        variant, payload = self._recv_one()
        if variant == METADATA:
            return "ok"
        return f"error: {payload}"

    # ── Health ──

    def health(self) -> dict:
        """Get daemon health/status info."""
        self._check_connected()
        self._send_msg(HEALTH, b"")
        variant, payload = self._recv_one()
        if variant == HEALTH_RESULT:
            pid = struct.unpack("<I", payload[:4])[0]
            uptime = struct.unpack("<Q", payload[4:12])[0]
            rss = struct.unpack("<Q", payload[12:20])[0]
            conns = struct.unpack("<I", payload[20:24])[0]
            vlen = struct.unpack("<Q", payload[24:32])[0]
            version = payload[32:32 + vlen].decode("utf-8", errors="replace")
            return {
                "pid": pid,
                "uptime_secs": uptime,
                "rss_kb": rss,
                "connections": conns,
                "version": version,
            }
        return {}

    # ── Tab management ──

    def close_tab(self, tab_id: Optional[int] = None) -> None:
        """Close a tab."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(CLOSETAB, _encode_u64(tid))

    def new_tab(self, url: Optional[str] = None) -> int:
        """Create a new tab. Returns the assigned tab_id if url provided."""
        self._check_connected()
        self._send_msg(NEWTAB, _encode_option_str(url))
        if url:
            variant, payload = self._recv_one()
            if variant == FRAME:
                tid = struct.unpack("<Q", payload[:8])[0]
                return tid
        return 0

    def go_back(self, tab_id: Optional[int] = None) -> None:
        """Navigate back in tab history."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(GO_BACK, _encode_u64(tid))
        self._recv_one()

    def go_forward(self, tab_id: Optional[int] = None) -> None:
        """Navigate forward in tab history."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(GO_FORWARD, _encode_u64(tid))
        self._recv_one()

    # ── Scroll / Resize ──

    def scroll(
        self, dx: float = 0.0, dy: float = 10.0,
        tab_id: Optional[int] = None,
    ) -> dict:
        """Scroll the page by (dx, dy) pixels."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(
            SCROLL,
            _encode_u64(tid) + _encode_f32(dx) + _encode_f32(dy),
        )
        variant, payload = self._recv_one()
        if variant == FRAME_DELTA:
            seq = struct.unpack("<Q", payload[8:16])[0]
            sx, sy = struct.unpack_from("<ff", payload, 16)
            vx, vy = struct.unpack_from("<ff", payload, 24)
            return {
                "sequence_number": seq,
                "scroll_offset": (sx, sy),
                "viewport": (vx, vy),
            }
        return {}

    def resize(
        self, width: int = 1920, height: int = 1080,
        tab_id: Optional[int] = None,
    ) -> dict:
        """Resize the viewport."""
        self._check_connected()
        tid = tab_id or self.tab_id
        self._send_msg(
            RESIZE,
            _encode_u64(tid)
            + struct.pack("<I", width)
            + struct.pack("<I", height),
        )
        variant, payload = self._recv_one()
        if variant == FRAME_DELTA:
            seq = struct.unpack("<Q", payload[8:16])[0]
            sx, sy = struct.unpack_from("<ff", payload, 16)
            vx, vy = struct.unpack_from("<ff", payload, 24)
            return {
                "sequence_number": seq,
                "scroll_offset": (sx, sy),
                "viewport": (vx, vy),
            }
        return {}
