"""Low-level wire protocol: bincode encode/decode, length-prefixed framing."""

import socket
import struct
from typing import Optional

__all__ = [
    "_recv_exact", "_recv", "_send", "_send_direct",
    "_encode_u8", "_encode_u32", "_encode_u64", "_encode_f32",
    "_encode_str", "_encode_option_str",
    "_decode_u8", "_decode_u32", "_decode_u64", "_decode_str", "_decode_option_str",
    "_encode_entity_query",
    # Message variants
    "NAVIGATE", "SCROLL", "CLICK_COORD", "INPUT_TEXT_COORD", "RESIZE",
    "NEWTAB", "CLOSETAB", "GO_BACK", "GO_FORWARD", "EVALUATE",
    "FIND_ENTITIES", "ENTITY_SNAPSHOT", "CLICK_ENTITY", "INPUT_ENTITY",
    "ACTION_LOG", "CLICK_SELECTOR", "GET_ACTION_LOG", "COMPARE_TABS",
    "TRANSFER_TAB", "HEALTH",
    # Response variants
    "FRAME", "FRAME_DELTA", "METADATA", "ERROR", "EVALUATE_RESULT",
    "FOUND_ENTITIES", "ACTION_LOG_RESP", "TAB_COMPARISON", "HEALTH_RESULT",
]

SOCKET_PATH = "/tmp/nomad-daemon.sock"

# ── Safe recv: handles partial reads ──

def _recv_exact(stream, size: int) -> bytes:
    buf = b""
    while len(buf) < size:
        chunk = stream.recv(size - len(buf))
        if not chunk:
            raise ConnectionError("connection closed")
        buf += chunk
    return buf

def _recv(stream):
    """Read a length-prefixed bincode or formatted message.
    Returns (variant, payload) where variant is the bincode u32
    discriminant (for bincode messages) or None (for text/JSON).
    payload is everything after the discriminant.
    """
    lb = _recv_exact(stream, 4)
    l = struct.unpack("<I", lb)[0]
    payload = _recv_exact(stream, l)
    if len(payload) < 4:
        return None, payload
    variant = struct.unpack("<I", payload[:4])[0]
    rest = payload[4:]
    return variant, rest

def _send(stream, msg_type: int, payload: bytes):
    data = struct.pack("<I", msg_type) + payload
    stream.sendall(struct.pack("<I", len(data)) + data)

def _send_direct(stream, msg_type: int, payload: bytes):
    """Send without bincode wrapper (for plain text/formatted)."""
    stream.sendall(struct.pack("<I", len(payload)) + payload)

# ── Bincode encoding helpers ──

def _encode_u8(v): return struct.pack("<B", v)
def _encode_u32(v): return struct.pack("<I", v)
def _encode_u64(v): return struct.pack("<Q", v)
def _encode_f32(v): return struct.pack("<f", v)

def _encode_str(s):
    b = s.encode() if isinstance(s, str) else s
    return struct.pack("<Q", len(b)) + b

def _encode_option_str(s):
    if s is None:
        return b"\x00"
    return b"\x01" + _encode_str(s)

def _encode_entity_query(q) -> bytes:
    data = _encode_option_str(q.get("role"))
    data += _encode_option_str(q.get("tag"))
    data += _encode_option_str(q.get("intent"))
    data += _encode_option_str(q.get("text_contains"))
    data += _encode_option_str(q.get("label"))
    if "limit" in q and q["limit"] is not None:
        data += b"\x01" + struct.pack("<H", q["limit"])
    else:
        data += b"\x00"
    return data

# ── Bincode decoding helpers ──

def _decode_u64(data, pos=0):
    return struct.unpack("<Q", data[pos:pos+8])[0], pos + 8

def _decode_u32(data, pos=0):
    return struct.unpack("<I", data[pos:pos+4])[0], pos + 4

def _decode_u8(data, pos=0):
    return data[pos], pos + 1

def _decode_str(data, pos=0):
    slen = struct.unpack("<Q", data[pos:pos+8])[0]
    pos += 8
    s = data[pos:pos+slen].decode("utf-8", errors="replace")
    return s, pos + slen

def _decode_option_str(data, pos=0):
    present = struct.unpack("<I", data[pos:pos+4])[0]
    pos += 4
    if present == 0:
        return None, pos
    return _decode_str(data, pos)

# ── Message variants (Client → Daemon) ──
NAVIGATE = 6
SCROLL = 7
CLICK_COORD = 8
INPUT_TEXT_COORD = 9
RESIZE = 10
NEWTAB = 11
CLOSETAB = 12
GO_BACK = 13
GO_FORWARD = 14
EVALUATE = 15
FIND_ENTITIES = 16
ENTITY_SNAPSHOT = 17
CLICK_ENTITY = 18
INPUT_ENTITY = 19
ACTION_LOG = 20
CLICK_SELECTOR = 21
GET_ACTION_LOG = 22
COMPARE_TABS = 23
TRANSFER_TAB = 24
HEALTH = 26

# ── Response variants (Daemon → Client) ──
FRAME = 0
FRAME_DELTA = 1
METADATA = 2
ERROR = 3
EVALUATE_RESULT = 4
FOUND_ENTITIES = 5
ACTION_LOG_RESP = 20
TAB_COMPARISON = 24
HEALTH_RESULT = 27
NAVIGATE_RESULT = 30


def _decode_f32(data, pos=0):
    return struct.unpack("<f", data[pos:pos+4])[0], pos + 4


def _decode_u16(data, pos=0):
    return struct.unpack("<H", data[pos:pos+2])[0], pos + 2


def _decode_viewport(data, pos=0):
    x, pos = _decode_f32(data, pos)
    y, pos = _decode_f32(data, pos)
    w, pos = _decode_f32(data, pos)
    h, pos = _decode_f32(data, pos)
    return (x, y, w, h), pos


def _decode_entity_array(data, pos=0):
    """Decode EntityArray from bincode.
    Returns (entities_list, pos) where entities_list is
    [{id, tag, text, role, href, classes, intent, is_interactive, parent_id}, ...]
    """
    ids_len, pos = _decode_u64(data, pos)
    ids = []
    for _ in range(ids_len):
        v, pos = _decode_u64(data, pos)
        ids.append(v)

    # Skip xs, ys, widths, heights (f32 vectors)
    for _ in range(4):
        vlen, pos = _decode_u64(data, pos)
        pos += vlen * 4

    # Skip z_indices (u16 vector)
    vlen, pos = _decode_u64(data, pos)
    pos += vlen * 2

    # Skip styles (u64 vector) — bitfield, not needed for text extraction
    vlen, pos = _decode_u64(data, pos)
    pos += vlen * 8

    # Skip state_tags (u8 vector)
    vlen, pos = _decode_u64(data, pos)
    pos += vlen * 1

    # Skip content_hashes (u64 vector)
    vlen, pos = _decode_u64(data, pos)
    pos += vlen * 8

    # content_offsets (u32 vector)
    offsets_len, pos = _decode_u64(data, pos)
    offsets = []
    for _ in range(offsets_len):
        v, pos = _decode_u32(data, pos)
        offsets.append(v)

    # contents (u8 vector) — packed: \0tag\0classes\0id\0href\0role\0text\0intent\0
    contents_len, pos = _decode_u64(data, pos)
    contents = data[pos:pos + contents_len]
    pos += contents_len

    # Build entities from packed content using offsets
    entities = []
    for i in range(min(len(ids), len(offsets))):
        start = offsets[i]
        end = offsets[i + 1] if i + 1 < len(offsets) else len(contents)
        blob = contents[start:end]

        # Packed: \0tag\0classes\0id\0href\0role\0text\0intent\0
        try:
            fields = blob.split(b'\x00')
            # First field is empty (leading \0), then tag, classes, id, href, role, text, intent
            tag = fields[1].decode('utf-8', errors='replace') if len(fields) > 1 else ''
            classes = fields[2].decode('utf-8', errors='replace') if len(fields) > 2 else ''
            html_id = fields[3].decode('utf-8', errors='replace') if len(fields) > 3 else ''
            href = fields[4].decode('utf-8', errors='replace') if len(fields) > 4 else ''
            role = fields[5].decode('utf-8', errors='replace') if len(fields) > 5 else ''
            text = fields[6].decode('utf-8', errors='replace') if len(fields) > 6 else ''
            intent = fields[7].decode('utf-8', errors='replace') if len(fields) > 7 else ''
        except Exception:
            tag = text = href = role = classes = intent = ''
            html_id = ''

        entities.append({
            'id': ids[i],
            't': tag,
            'x': text,
            'h': href,
            'r': role,
            'classes': classes,
            'i': intent,
        })

    return entities, pos


def _decode_form_entries(data, pos=0):
    """Decode Vec<FormEntry> from bincode."""
    count, pos = _decode_u64(data, pos)
    entries = []
    for _ in range(count):
        entity_id, pos = _decode_u64(data, pos)
        name, pos = _decode_str(data, pos)
        input_type, pos = _decode_str(data, pos)
        value, pos = _decode_str(data, pos)
        placeholder, pos = _decode_str(data, pos)
        required, pos = data[pos], pos + 1
        entries.append({
            'entity_id': entity_id, 'name': name,
            'input_type': input_type, 'value': value,
            'placeholder': placeholder, 'required': bool(required),
        })
    return entries, pos


def _decode_ecs_frame(data, pos=0):
    """Decode EcsFrame from bincode."""
    tab_id, pos = _decode_u64(data, pos)
    viewport, pos = _decode_viewport(data, pos)
    sx, pos = _decode_f32(data, pos)
    sy, pos = _decode_f32(data, pos)
    tx, pos = _decode_f32(data, pos)
    ty, pos = _decode_f32(data, pos)
    entities, pos = _decode_entity_array(data, pos)
    content_flags, pos = _decode_u16(data, pos)
    form_entries, pos = _decode_form_entries(data, pos)
    return {
        'tab_id': tab_id,
        'viewport': viewport,
        'scroll_offset': (sx, sy),
        'total_extent': (tx, ty),
        'entities': entities,
        'content_flags': content_flags,
        'form_entries': form_entries,
    }, pos
