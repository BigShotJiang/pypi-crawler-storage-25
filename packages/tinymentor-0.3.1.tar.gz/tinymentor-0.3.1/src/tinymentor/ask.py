from .memory import remember
from .retrieval import search_notes
from .errors import solve_error
from .model import generate_response

def ask(question: str, traceback: str = None):
    """
    Main Ask Workflow:
    Question -> Memory -> Retrieve top 5 notes -> Error detection -> 
    Qwen model -> Generate response -> Return answer
    """
    print(f"Analyzing: {question}")
    
    # 1. Retrieve top 5 notes
    notes = search_notes(question)
    context_str = ""
    if notes:
        context_str = "\n\nRelevant Notes:\n" + "\n---\n".join(notes)
        
    # 2. Error detection
    error_context = solve_error(traceback)
    if error_context:
        error_context = f"\n\nContext from traceback:\n{error_context}"
        
    # 3. Formulate Prompt
    # Emphasize explanation, debugging, code, dry run
    prompt = f"""You are tinymentor, a local GenAI coding copilot.
Provide: explanation, debugging, code, and dry run if applicable.
{context_str}
{error_context}

Q: {question}
A:"""
    
    # 4. Qwen model -> Generate response
    try:
        answer = generate_response(prompt)
    except Exception as e:
        answer = f"Error during generation: {e}"
        print(answer)
        return
        
    # 5. Memory
    remember(question, answer)
    
    # 6. Return answer
    print("\n" + answer)
    return answer
