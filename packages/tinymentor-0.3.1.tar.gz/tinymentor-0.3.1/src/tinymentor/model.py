import os
import sys

def assemble_model():
    """
    Find all tinymentor_model_part* packages,
    merge them in order, and generate models/qwen.gguf
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    model_dir = os.path.join(base_dir, "models")
    os.makedirs(model_dir, exist_ok=True)
    
    qwen_path = os.path.join(model_dir, "qwen.gguf")
    if os.path.exists(qwen_path):
        # We assume if it exists, it's already built.
        return qwen_path
        
    print("Assembling model from parts...")
    
    parts = []
    i = 1
    while True:
        try:
            mod_name = f"tinymentor_model_part{i}"
            mod = __import__(mod_name)
            part_path = mod.get_part_path()
            parts.append(part_path)
            i += 1
        except ImportError:
            break
            
    if not parts:
        raise RuntimeError("No tinymentor-model-part packages found. Please install them.")
        
    with open(qwen_path, "wb") as outfile:
        for part_path in parts:
            with open(part_path, "rb") as infile:
                outfile.write(infile.read())
                
    print("Model assembly complete.")
    return qwen_path

def load_model():
    model_path = assemble_model()
    from llama_cpp import Llama  # type: ignore
    # Initialize the model
    llm = Llama(model_path=model_path, verbose=True, n_ctx=2048)
    return llm

def generate_response(prompt: str) -> str:
    """
    Load the model using llama-cpp-python and generate a response.
    """
    llm = load_model()
    output = llm(
        prompt,
        max_tokens=512,
        stop=["Q:", "\n\n\n"],
        echo=False
    )
    return output["choices"][0]["text"].strip()
