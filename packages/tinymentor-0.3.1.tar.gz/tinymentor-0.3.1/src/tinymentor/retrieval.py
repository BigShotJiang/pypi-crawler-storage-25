import os

def search_notes(question: str) -> list:
    """
    Recursively search markdown files in the md/ directory.
    Uses TF-IDF and cosine similarity to return the top 5 matches.
    """
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
    except ImportError:
        # Fallback if scikit-learn is not installed somehow
        return []

    base_dir = os.path.join(os.path.dirname(__file__), "md")
    if not os.path.exists(base_dir):
        return []
        
    documents = []
    file_paths = []
    
    # Collect all md files
    for root, _, files in os.walk(base_dir):
        for file in files:
            if file.endswith(".md"):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        # Include filename in the document text for scoring
                        documents.append(f"{file} {content}")
                        file_paths.append(file_path)
                except Exception:
                    pass
                    
    if not documents:
        return []
        
    documents.append(question)
    
    vectorizer = TfidfVectorizer(stop_words='english')
    try:
        tfidf_matrix = vectorizer.fit_transform(documents)
    except ValueError:
        # e.g., empty vocabulary
        return []
        
    # Last row is the question
    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1]).flatten()
    
    # Get top 5 indices sorted by similarity score
    related_docs_indices = cosine_similarities.argsort()[:-6:-1]
    
    top_5 = []
    for idx in related_docs_indices:
        if cosine_similarities[idx] > 0.0:  # Only include if there's some similarity
            path = file_paths[idx]
            with open(path, "r", encoding="utf-8") as f:
                top_5.append(f.read())
                
    return top_5
