from datetime import datetime, timedelta, timezone
from typing import Literal, List, Tuple
import math

import polyline as pl
from airportsdata import load
from astral import Observer
from astral.sun import sun, azimuth, elevation
from geographiclib.geodesic import Geodesic

from .models import PredictIn, PredictOut, TimelinePoint

AIRPORTS = load("iata")


class SeatsideError(ValueError):
    pass


def ensure_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def find_event_time_during_window(
    lat: float, lon: float, dep_utc: datetime, arr_utc: datetime, event: str
) -> datetime:
    dep_utc = ensure_utc(dep_utc)
    arr_utc = ensure_utc(arr_utc)
    observer = Observer(latitude=lat, longitude=lon)

    days_span = (arr_utc.date() - dep_utc.date()).days
    dates = [dep_utc.date() + timedelta(days=d) for d in range(-1, days_span + 2)]

    candidates = []
    for d in dates:
        try:
            s = sun(observer, date=d)
            evt = s[event]
        except Exception:
            continue
        evt_utc = evt.replace(tzinfo=timezone.utc) if evt.tzinfo is None else evt.astimezone(timezone.utc)
        candidates.append(evt_utc)
        if dep_utc <= evt_utc <= arr_utc:
            return evt_utc

    if candidates:
        nearest = min(candidates, key=lambda e: min(abs((e - dep_utc).total_seconds()), abs((e - arr_utc).total_seconds())))
        raise SeatsideError(
            f"{event.capitalize()} does not occur during the flight window "
            f"({dep_utc.isoformat()} to {arr_utc.isoformat()}). "
            f"Nearest {event} at this location: {nearest.isoformat()} (UTC)."
        )
    raise SeatsideError(f"Could not compute {event} times for the location ({lat},{lon}).")


def great_circle_samples(o: Tuple[float, float], d: Tuple[float, float], n: int):
    line = Geodesic.WGS84.InverseLine(o[0], o[1], d[0], d[1])
    total = line.s13
    return [
        (lambda p: (p["lat2"], p["lon2"], p["azi2"] % 360))(line.Position(total * i / (n - 1), Geodesic.STANDARD))
        for i in range(n)
    ]


def solar_az_el(lat: float, lon: float, when_utc: datetime) -> Tuple[float, float]:
    obs = Observer(latitude=lat, longitude=lon)
    return azimuth(obs, when_utc) % 360, elevation(obs, when_utc)


def side_scores(samples, t0: datetime, dt_sec: int) -> Tuple[float, float, List[TimelinePoint]]:
    left = right = 0.0
    timeline = []
    hmin = 5.0
    for i, (lat, lon, track) in enumerate(samples):
        t = t0 + timedelta(seconds=i * dt_sec)
        az, el = solar_az_el(lat, lon, t)
        if el < hmin:
            timeline.append(TimelinePoint(t=t, elev_left=0.0, elev_right=0.0))
            continue
        R = (az - track) % 360.0
        w = max(0.0, el - hmin)

        def taper(center, R=R):
            d = min((R - center) % 360, (center - R) % 360)
            return max(0.0, math.cos(math.radians(min(d, 45)) * (90 / 45)))

        r_add = taper(90) * w if 45 <= R <= 135 else 0.0
        l_add = taper(270) * w if 225 <= R <= 315 else 0.0
        right += r_add
        left += l_add
        timeline.append(TimelinePoint(t=t, elev_left=l_add, elev_right=r_add))
    return left, right, timeline


def seat_row_bands(aircraft_type: str | None, side: str, event: str) -> List[str]:
    if aircraft_type and any(k in aircraft_type for k in ["A320", "737"]):
        return ["15–22", "5–9"] if event == "sunset" else ["5–9", "10–14"]
    return ["mid-aft", "forward"]


def predict(inp: PredictIn) -> PredictOut:
    """Return the best window seat side and row bands for a given flight and solar event."""
    origin_code = inp.origin.upper()
    dest_code = inp.destination.upper()

    if origin_code not in AIRPORTS or dest_code not in AIRPORTS:
        raise SeatsideError("Unknown origin or destination IATA code.")

    o = (AIRPORTS[origin_code]["lat"], AIRPORTS[origin_code]["lon"])
    d = (AIRPORTS[dest_code]["lat"], AIRPORTS[dest_code]["lon"])

    dep_utc = ensure_utc(inp.dep_utc)
    arr_utc = dep_utc + timedelta(minutes=inp.block_time_min)

    find_event_time_during_window(o[0], o[1], dep_utc, arr_utc, inp.event)

    dt = 90
    steps = max(5, int((inp.block_time_min * 60) / dt) + 1)
    samples = great_circle_samples(o, d, steps)

    left, right, timeline = side_scores(samples, dep_utc, dt)

    side = "F" if right > left else "A"
    total = max(left + right, 1e-6)
    conf = float(max(left, right) / total)

    return PredictOut(
        side=side,
        confidence=round(conf, 2),
        rowBands=seat_row_bands(inp.aircraft_type, side, inp.event),
        timeline=timeline,
        polyline=pl.encode([(lat, lon) for lat, lon, _ in samples], 5),
    )
