from datetime import datetime
from typing import Literal, List
from pydantic import BaseModel, Field


class PredictIn(BaseModel):
    origin: str
    destination: str
    dep_utc: datetime
    block_time_min: int = Field(gt=0)
    event: Literal["sunrise", "sunset"]
    aircraft_type: str | None = None


class TimelinePoint(BaseModel):
    t: datetime
    elev_left: float
    elev_right: float


class PredictOut(BaseModel):
    side: Literal["A", "F"]
    confidence: float
    rowBands: List[str]
    timeline: List[TimelinePoint]
    polyline: str
