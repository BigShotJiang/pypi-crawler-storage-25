from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .models import PredictIn, PredictOut
from .core import predict, SeatsideError

app = FastAPI(title="SeatSide API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/api/predict", response_model=PredictOut)
def predict_endpoint(inp: PredictIn):
    try:
        return predict(inp)
    except SeatsideError as e:
        raise HTTPException(status_code=400, detail=str(e))
