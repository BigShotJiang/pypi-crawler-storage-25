# seatside

Find the best window seat side to watch a **sunrise** or **sunset** on any flight.

## Install

```bash
pip install seatside
```

To also run the API server:

```bash
pip install "seatside[server]"
```

## Library usage

```python
from datetime import datetime, timezone
from seatside import predict, PredictIn

result = predict(PredictIn(
    origin="JFK",
    destination="LHR",
    dep_utc=datetime(2025, 6, 21, 22, 0, tzinfo=timezone.utc),
    block_time_min=420,
    event="sunrise",
    aircraft_type="B777",
))

print(result.side)        # "A" (left/window) or "F" (right/window)
print(result.confidence)  # 0.0 – 1.0
print(result.rowBands)    # e.g. ["mid-aft", "forward"]
```

### Error handling

```python
from seatside import SeatsideError

try:
    result = predict(inp)
except SeatsideError as e:
    print(f"Could not compute: {e}")
```

## API server

```bash
uvicorn seatside.server:app --reload
# POST http://localhost:8000/api/predict
```

### Request body

```json
{
  "origin": "JFK",
  "destination": "LHR",
  "dep_utc": "2025-06-21T22:00:00Z",
  "block_time_min": 420,
  "event": "sunrise",
  "aircraft_type": "B777"
}
```

### Response

```json
{
  "side": "A",
  "confidence": 0.83,
  "rowBands": ["mid-aft", "forward"],
  "timeline": [...],
  "polyline": "..."
}
```
