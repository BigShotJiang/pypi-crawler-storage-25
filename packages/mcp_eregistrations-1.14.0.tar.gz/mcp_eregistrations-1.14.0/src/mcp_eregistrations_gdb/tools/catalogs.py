"""GDB catalog tools — list, delete, move."""

from __future__ import annotations

from typing import Any

from mcp.types import ToolAnnotations

from mcp_eregistrations_gdb.gdb_client import GDBClient, GDBClientError, translate_error
from mcp_eregistrations_gdb.server import mcp


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_catalog_list(
    name_contains: str | None = None,
    code_contains: str | None = None,
    page: int = 1,
    page_size: int = 50,
    include_databases: bool = True,
    instance: str | None = None,
) -> dict[str, Any]:
    """List database catalogs with optional filtering and pagination.

    Args:
        name_contains: Filter catalogs whose name contains this (case-insensitive).
        code_contains: Filter catalogs whose code contains this (case-insensitive).
        page: Page number (default: 1).
        page_size: Results per page (default: 50, max: 200).
        include_databases: Include nested databases array (default: True).
        instance: Instance name (default: auto-select).

    Returns:
        dict with total_count, page, page_size, has_next, catalogs.
    """
    page_size = min(page_size, 200)
    try:
        async with GDBClient.for_instance(instance) as client:
            data = await client.get("/databases")
            if not isinstance(data, list):
                data = data.get("catalogs", [])

            # Client-side filtering
            filtered = data
            if name_contains:
                needle = name_contains.lower()
                filtered = [
                    c for c in filtered if needle in (c.get("name") or "").lower()
                ]
            if code_contains:
                needle = code_contains.lower()
                filtered = [
                    c for c in filtered if needle in (c.get("code") or "").lower()
                ]

            total_count = len(filtered)

            # Client-side pagination
            start = (page - 1) * page_size
            page_items = filtered[start : start + page_size]
            has_next = (start + page_size) < total_count

            catalogs = []
            for cat in page_items:
                entry: dict[str, Any] = {
                    "id": cat.get("id"),
                    "code": cat.get("code"),
                    "name": cat.get("name"),
                    "order": cat.get("order"),
                    "group_id": cat.get("group_id"),
                    "database_count": len(cat.get("databases", [])),
                }
                if include_databases:
                    entry["databases"] = [
                        {
                            "id": db.get("id"),
                            "version": db.get("version"),
                            "is_draft": db.get("is_draft"),
                        }
                        for db in cat.get("databases", [])
                    ]
                catalogs.append(entry)
            return {
                "total_count": total_count,
                "page": page,
                "page_size": page_size,
                "has_next": has_next,
                "catalogs": catalogs,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="catalog") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_catalog_delete(
    catalog_id: int,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a database catalog by ID.

    Args:
        catalog_id: Integer ID of the catalog to delete.
        instance: Instance name (default: auto-select).

    Returns:
        dict with deleted (bool), catalog_id.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            await client.delete(f"/api/v1/database-catalog/{catalog_id}")
            return {"deleted": True, "catalog_id": catalog_id}
    except GDBClientError as e:
        raise translate_error(e, resource_type="catalog", resource_id=catalog_id) from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_catalog_move(
    catalog_id: int,
    index: int,
    group_id: int | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Move a catalog to a new position (and optionally into a group).

    Args:
        catalog_id: Integer ID of the catalog to move.
        index: Target position index.
        group_id: Target group ID, or null for ungrouped (default: None).
        instance: Instance name (default: auto-select).

    Returns:
        dict with moved (bool), catalog_id, index, group_id.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            body: dict[str, Any] = {"index": index, "group_id": group_id}
            await client.post(f"/api/v1/database-catalog/{catalog_id}/move", data=body)
            return {
                "moved": True,
                "catalog_id": catalog_id,
                "index": index,
                "group_id": group_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="catalog", resource_id=catalog_id) from e
