"""Base class for figure composers with shared functionality."""

from abc import ABC, abstractmethod
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import NamedTuple

import fitz

from .errors import FigQuiltError
from .grid import resolve_layout
from .layout import LabelStyle, Layout, Panel
from .units import calculate_fit, to_pt


class SourceInfo(NamedTuple):
    """Information about a source file."""

    doc: fitz.Document
    aspect_ratio: float


class CellRect(NamedTuple):
    """Panel cell rectangle in page coordinates."""

    x: float
    y: float
    width: float
    height: float


class ContentRect(NamedTuple):
    """Computed content rectangle within a cell."""

    x: float
    y: float
    width: float
    height: float
    offset_x: float
    offset_y: float


class PanelGeometry(NamedTuple):
    """Resolved panel cell and fitted content geometry."""

    cell: CellRect
    content: ContentRect


class ResolvedPanelSource(NamedTuple):
    """Opened panel source plus its derived page geometry."""

    source: SourceInfo
    geometry: PanelGeometry


class LabelDrawInfo(NamedTuple):
    """Resolved label content, style, and draw coordinates."""

    text: str
    style: LabelStyle
    x: float
    y: float


def open_panel_source(panel: Panel) -> SourceInfo:
    """
    Open a panel source file and return its document plus aspect ratio.

    Raises:
        FigQuiltError: If the source cannot be opened or has invalid geometry.
    """
    try:
        src_doc = fitz.open(panel.file)
    except Exception as e:
        raise FigQuiltError(f"Failed to open panel file {panel.file}: {e}") from e

    try:
        if src_doc.page_count < 1:
            raise FigQuiltError(f"Panel '{panel.id}' source has no pages: {panel.file}")

        src_page = src_doc[0]
        src_rect = src_page.rect
        if src_rect.width <= 0 or src_rect.height <= 0:
            raise FigQuiltError(
                "Panel "
                f"'{panel.id}' source has non-positive size "
                f"({src_rect.width}x{src_rect.height}): {panel.file}"
            )

        aspect_ratio = src_rect.height / src_rect.width
        return SourceInfo(doc=src_doc, aspect_ratio=aspect_ratio)
    except Exception:
        src_doc.close()
        raise


def validate_panel_sources(panels: list[Panel]) -> None:
    """Open and close each resolved panel source to verify readability."""
    for panel in panels:
        source_info = open_panel_source(panel)
        source_info.doc.close()


class BaseComposer(ABC):
    """Base class for PDF and SVG composers with shared initialization and helpers."""

    def __init__(self, layout: Layout, panels: list[Panel] | None = None):
        self.layout = layout
        self.units = layout.page.units
        self.width_pt = to_pt(layout.page.width, self.units)
        self.height_pt = to_pt(layout.page.height, self.units)
        self.margin_pt = to_pt(layout.page.margin, self.units)
        self._panels = panels

    @abstractmethod
    def compose(self, output_path: Path) -> None:
        """Compose the layout and write to output file."""
        pass

    def get_panels(self) -> list[Panel]:
        """Resolve and return the list of panels from the layout."""
        if self._panels is None:
            self._panels = resolve_layout(self.layout)
        return self._panels

    def open_source(self, panel: Panel) -> SourceInfo:
        """
        Open a source file and return its document and aspect ratio.

        Args:
            panel: Panel containing the file path

        Returns:
            SourceInfo with the opened document and aspect ratio

        Raises:
            FigQuiltError: If the file cannot be opened
        """
        return open_panel_source(panel)

    @contextmanager
    def resolved_panel_source(self, panel: Panel) -> Iterator[ResolvedPanelSource]:
        """Yield an opened panel source together with its resolved geometry."""
        source_info = self.open_source(panel)
        try:
            geometry = self.calculate_panel_geometry(panel, source_info.aspect_ratio)
            yield ResolvedPanelSource(source=source_info, geometry=geometry)
        finally:
            source_info.doc.close()

    def calculate_content_rect(self, panel: Panel, src_aspect: float) -> ContentRect:
        """
        Calculate the content rectangle for a panel.

        Args:
            panel: Panel with position and size
            src_aspect: Source aspect ratio (height / width)

        Returns:
            ContentRect with position, dimensions, and offsets
        """
        return self.calculate_panel_geometry(panel, src_aspect).content

    def calculate_cell_rect(self, panel: Panel, src_aspect: float) -> CellRect:
        """Calculate the panel cell rectangle in page coordinates."""
        x = to_pt(panel.x, self.units) + self.margin_pt
        y = to_pt(panel.y, self.units) + self.margin_pt
        w = to_pt(panel.width, self.units)
        h = self._panel_height_pt(panel, src_aspect, width_pt=w)

        return CellRect(x=x, y=y, width=w, height=h)

    def calculate_panel_geometry(
        self, panel: Panel, src_aspect: float
    ) -> PanelGeometry:
        """Calculate panel cell geometry and fitted content placement."""
        cell = self.calculate_cell_rect(panel, src_aspect)

        fit = calculate_fit(src_aspect, cell.width, cell.height, panel.fit, panel.align)

        return PanelGeometry(
            cell=cell,
            content=ContentRect(
                x=cell.x,
                y=cell.y,
                width=fit.width,
                height=fit.height,
                offset_x=fit.offset_x,
                offset_y=fit.offset_y,
            ),
        )

    def _panel_height_pt(
        self, panel: Panel, src_aspect: float, *, width_pt: float
    ) -> float:
        """Return the panel cell height in points."""
        if panel.height is not None:
            return to_pt(panel.height, self.units)
        return width_pt * src_aspect

    def get_label_text(self, panel: Panel, index: int) -> str | None:
        """
        Get the label text for a panel.

        Args:
            panel: Panel with optional label override
            index: Panel index for auto-sequencing

        Returns:
            Label text or None if labels are disabled
        """
        style = self.get_label_style(panel)

        if not style.enabled:
            return None

        text = panel.label
        if text is None and style.auto_sequence:
            text = self._index_to_label(index)

        if not text:
            return None

        if style.uppercase:
            text = text.upper()

        return text

    def get_label_style(self, panel: Panel) -> LabelStyle:
        """Resolve a panel label style by inheriting unspecified page defaults."""
        base_style = self.layout.page.label
        if panel.label_style is None:
            return base_style

        override = panel.label_style.model_dump(exclude_unset=True)
        return base_style.model_copy(update=override)

    def resolve_label_draw_info(
        self,
        panel: Panel,
        index: int,
        *,
        origin_x: float = 0.0,
        origin_y: float = 0.0,
        use_font_baseline: bool = False,
    ) -> LabelDrawInfo | None:
        """Return resolved label text, style, and draw coordinates for a panel."""
        text = self.get_label_text(panel, index)
        if not text:
            return None

        style = self.get_label_style(panel)
        x = origin_x + to_pt(style.offset_x, self.units)
        y = origin_y + to_pt(style.offset_y, self.units)
        if use_font_baseline:
            y += style.font_size_pt

        return LabelDrawInfo(text=text, style=style, x=x, y=y)

    @staticmethod
    def _index_to_label(index: int) -> str:
        """Convert zero-based index to spreadsheet-like labels (A..Z, AA..)."""
        if index < 0:
            raise ValueError("index must be non-negative")
        chars: list[str] = []
        value = index
        while True:
            value, remainder = divmod(value, 26)
            chars.append(chr(65 + remainder))
            if value == 0:
                break
            value -= 1
        return "".join(reversed(chars))

    @staticmethod
    def _normalize_rgb_channels(
        channels: tuple[int, ...],
    ) -> tuple[float, float, float] | None:
        """Normalize opaque RGB(A) channels to 0-1 floats."""
        if len(channels) == 4:
            red, green, blue, alpha = channels
            if alpha != 255:
                return None
            channels = (red, green, blue)

        if len(channels) != 3:
            return None

        red, green, blue = channels
        return (red / 255.0, green / 255.0, blue / 255.0)

    def parse_color(self, color_str: str) -> tuple[float, float, float] | None:
        """
        Parse a color string to RGB tuple (0-1 range).

        Supports hex colors (#rrggbb) and CSS color names via PIL.

        Args:
            color_str: Color string (e.g., "#f0f0f0", "white")

        Returns:
            RGB tuple with values 0-1, or None if parsing fails
        """
        if color_str.startswith("#"):
            h = color_str.lstrip("#")
            if len(h) == 3:
                h = "".join(ch * 2 for ch in h)
            elif len(h) != 6:
                return None
            try:
                channels = tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))
                return self._normalize_rgb_channels(channels)
            except (ValueError, IndexError):
                return None

        try:
            from PIL import ImageColor

            return self._normalize_rgb_channels(ImageColor.getrgb(color_str))
        except (ValueError, ImportError):
            return None
