from __future__ import annotations

import argparse
import os
import shlex
import sys
from pathlib import Path
from typing import List, Optional

from . import __version__
from .api import DEFAULT_MOUNT_API_URL, MountApiError, normalize_api_url
from .explore_agent import run_exploration


def main(argv: Optional[List[str]] = None) -> int:
    values = list(sys.argv[1:] if argv is None else argv)
    if values and values[0] == "explore":
        return run_explore(parse_explore_args(values[1:]))

    parser = build_parser()
    args = parser.parse_args(values)

    if args.command == "doctor":
        return run_doctor()
    if args.command == "version":
        print(__version__)
        return 0

    parser.print_help()
    return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mountctl",
        description="Mount connector setup CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("explore", description="Run read-only agent discovery and upload the profile to Mount.")

    subparsers.add_parser("doctor", description="Print local environment diagnostics.")
    subparsers.add_parser("version", description="Print mountctl version.")
    return parser


def parse_explore_args(argv: List[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="mountctl explore",
        description="Run read-only agent discovery and upload the profile to Mount.",
    )
    parser.add_argument("key", help="Mount dashboard setup key")
    parser.add_argument(
        "entry_command",
        nargs=argparse.REMAINDER,
        help='Agent entry command, for example: "opencode run"',
    )
    return parser.parse_args(argv)


def run_explore(args: argparse.Namespace) -> int:
    project_dir = Path.cwd().resolve()
    if not project_dir.exists() or not project_dir.is_dir():
        print(f"error: project directory does not exist: {project_dir}", file=sys.stderr)
        return 2

    entry_command = normalize_entry_command(args.entry_command)
    if not entry_command:
        print(
            'error: missing entry command. Use: mountctl explore <KEY> "<ENTRY_COMMAND>"',
            file=sys.stderr,
        )
        return 2
    print(f"Mount explore: running read-only discovery in {project_dir}")
    try:
        response = run_exploration(key=args.key, project_dir=project_dir, entry_command=entry_command)
    except MountApiError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    status = response.get("status", "completed")
    print(f"Mount exploration {status}.")
    print("Return to the Mount dashboard to continue.")
    return 0


def run_doctor() -> int:
    print(f"mountctl {__version__}")
    print(f"python {sys.version.split()[0]}")
    print(f"cwd {Path.cwd()}")
    print(f"api {normalize_api_url(None) or DEFAULT_MOUNT_API_URL}")
    return 0


def normalize_entry_command(parts: List[str]) -> str:
    values = list(parts)
    if not values:
        return ""
    if len(values) == 1:
        return values[0].strip()
    return " ".join(shlex.quote(part) for part in values).strip()
