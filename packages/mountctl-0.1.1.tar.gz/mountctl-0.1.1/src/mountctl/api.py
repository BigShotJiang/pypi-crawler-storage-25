from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any, Dict, Optional, Tuple

from . import __version__


DEFAULT_MOUNT_API_URL = "https://mount-backend-production.up.railway.app"


class MountApiError(RuntimeError):
    pass


def normalize_api_url(api_url: Optional[str]) -> Optional[str]:
    value = api_url or os.environ.get("MOUNT_API_URL") or DEFAULT_MOUNT_API_URL
    if not value:
        return None
    return value.rstrip("/")


def upload_agent_info(
    key: str,
    *,
    agent_info: Dict[str, Any],
    timeout_seconds: int = 20,
) -> Optional[Dict[str, Any]]:
    base_url = normalize_api_url(None)
    if not base_url:
        return None
    status, data = _post_json(
        f"{base_url}/v1/connectors/agent-info",
        key=key,
        payload={"agent_info": agent_info},
        timeout_seconds=timeout_seconds,
    )
    if status < 200 or status >= 300:
        raise MountApiError(f"agent info upload failed with HTTP {status}: {data}")
    return data


def start_exploration(
    key: str,
    *,
    payload: Dict[str, Any],
    timeout_seconds: int = 30,
) -> Dict[str, Any]:
    base_url = normalize_api_url(None)
    if not base_url:
        raise MountApiError("no Mount API URL configured. Set MOUNT_API_URL")
    status, data = _post_json(
        f"{base_url}/v1/connectors/explore/start",
        key=key,
        payload=payload,
        timeout_seconds=timeout_seconds,
    )
    if status < 200 or status >= 300:
        raise MountApiError(f"exploration start failed with HTTP {status}: {data}")
    return data


def submit_tool_results(
    key: str,
    *,
    session_id: str,
    tool_results: Any,
    timeout_seconds: int = 30,
) -> Dict[str, Any]:
    base_url = normalize_api_url(None)
    if not base_url:
        raise MountApiError("no Mount API URL configured. Set MOUNT_API_URL")
    status, data = _post_json(
        f"{base_url}/v1/connectors/explore/tool-results",
        key=key,
        payload={"session_id": session_id, "tool_results": tool_results},
        timeout_seconds=timeout_seconds,
    )
    if status < 200 or status >= 300:
        raise MountApiError(f"tool result submission failed with HTTP {status}: {data}")
    return data


def _post_json(
    url: str,
    *,
    key: str,
    payload: Dict[str, Any],
    timeout_seconds: int,
) -> Tuple[int, Dict[str, Any]]:
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": f"mountctl/{__version__}",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            raw = response.read().decode("utf-8")
            return response.status, _decode_json(raw)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        return exc.code, _decode_json(raw)
    except urllib.error.URLError as exc:
        raise MountApiError(f"could not reach Mount API: {exc.reason}") from exc


def _decode_json(raw: str) -> Dict[str, Any]:
    if not raw:
        return {}
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        return {"raw": raw}
    if isinstance(value, dict):
        return value
    return {"value": value}
