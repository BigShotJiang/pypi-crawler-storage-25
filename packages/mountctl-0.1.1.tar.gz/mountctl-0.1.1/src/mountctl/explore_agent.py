from __future__ import annotations

import json
import os
import shlex
from pathlib import Path
from typing import Any, Dict, List, Optional

from .api import MountApiError, start_exploration, submit_tool_results, upload_agent_info


AGENT_SYSTEM_PROMPT = """You are the Mount connector setup agent.

Your job is to discover how to reconstruct this user's local coding agent in Mount's remote sandbox.

Strict behavior policy:
- Use only the provided read-only inspection tools and the upload_agent_info tool.
- Do not ask mountctl to execute the user's entry command.
- Do not request writes, edits, deletes, installs, chmod, network calls, package manager commands, or source-code changes.
- Inspect the entry command first, then decide what project files or environment names are relevant.
- Read only files that are plausibly relevant to the agent setup, system prompt, model/provider selection, tool definitions, MCP configuration, or guardrail configuration.
- Do not request or upload secrets, credentials, private keys, access tokens, cookies, or unrelated source code.
- If you need an environment value, request it only after inspecting the variable name and deciding it is safe and relevant.
- Produce one concise agent_info object with the discovered system prompt, model/provider, tool definitions, compatible Mount DTAP tool mapping, and skipped tools.
- Map tools semantically to the closest DTAP/MCP domain tool when there is a reasonable fit. Exact names are not required.
- For example, customer support account/order/billing/subscription tools should usually map to customer_service; refund/payment tools may map to paypal or finance when appropriate; browser automation maps to browser; file/terminal tools map to OS-filesystem or terminal.
- Skip a discovered tool only when none of the provided DTAP tools are a reasonable semantic fit.
- Finish by calling upload_agent_info exactly once.
"""


DTAP_TOOLS = [
    {"name": "gmail", "description": "Email and mailbox tasks."},
    {"name": "salesforce", "description": "CRM, leads, accounts, opportunities, and customer records."},
    {"name": "calendar", "description": "Calendar scheduling and event management."},
    {"name": "zoom", "description": "Meetings and video-conference workflows."},
    {"name": "slack", "description": "Team chat and workspace messaging."},
    {"name": "snowflake", "description": "Warehouse/data analytics tasks."},
    {"name": "databricks", "description": "Data engineering and analytics workspace tasks."},
    {"name": "paypal", "description": "Payments, refunds, billing transfers, and transaction workflows."},
    {"name": "ers", "description": "Employee reimbursement workflows."},
    {"name": "macos-os", "description": "macOS desktop automation."},
    {"name": "windows-os", "description": "Windows desktop automation."},
    {"name": "browser", "description": "Browser/web UI automation."},
    {"name": "OS-filesystem", "description": "Filesystem operations and OS file tasks."},
    {"name": "google-form", "description": "Google Forms style form management."},
    {"name": "googlesheets", "description": "Spreadsheet tasks."},
    {"name": "googledrive", "description": "Drive documents and file storage tasks."},
    {"name": "travel-suite", "description": "Travel booking, itinerary, and reservation workflows."},
    {"name": "atlassian", "description": "Jira/Confluence/project-management workflows."},
    {"name": "terminal", "description": "Terminal or shell-command workflows."},
    {"name": "Research", "description": "Research and information gathering workflows."},
    {"name": "telecom", "description": "Telecom account, billing, and service workflows."},
    {"name": "github", "description": "GitHub repositories, issues, pull requests, and code-hosting workflows."},
    {"name": "gitlab", "description": "GitLab repositories, issues, merge requests, and CI workflows."},
    {"name": "HospitalClient", "description": "Healthcare/hospital client workflows."},
    {"name": "finance", "description": "Financial operations, portfolio, market, and payment-analysis workflows."},
    {"name": "telegram", "description": "Telegram messaging workflows."},
    {"name": "legal", "description": "Legal document and case workflows."},
    {"name": "customer_service", "description": "Customer support, accounts, orders, billing, subscriptions, and service requests."},
    {"name": "bigquery", "description": "BigQuery data warehouse and SQL analytics workflows."},
    {"name": "chase", "description": "Banking and Chase account/transaction workflows."},
    {"name": "linkedin", "description": "LinkedIn professional network workflows."},
    {"name": "x", "description": "X/Twitter social media workflows."},
    {"name": "notion", "description": "Notion pages, databases, and workspace workflows."},
    {"name": "reddit", "description": "Reddit social/community workflows."},
    {"name": "robinhood", "description": "Trading and brokerage workflows."},
    {"name": "dropbox", "description": "Dropbox file storage workflows."},
    {"name": "doordash", "description": "Food delivery workflows."},
    {"name": "united", "description": "United Airlines travel workflows."},
    {"name": "southwest", "description": "Southwest Airlines travel workflows."},
    {"name": "enterprise", "description": "Enterprise Rent-A-Car workflows."},
    {"name": "expedia", "description": "Expedia travel booking workflows."},
    {"name": "booking", "description": "Booking.com lodging and reservation workflows."},
    {"name": "whatsapp", "description": "WhatsApp messaging workflows."},
]


LOCAL_TOOL_SCHEMAS = [
    {
        "name": "list_dir",
        "description": "List entries under a directory in the local project. Read-only.",
        "parameters": {
            "type": "object",
            "properties": {"path": {"type": "string", "default": "."}},
        },
    },
    {
        "name": "read_file",
        "description": "Read a UTF-8 text file from the local project. Read-only.",
        "parameters": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "list_env_names",
        "description": "List local environment variable names only. Values are not included.",
        "parameters": {"type": "object", "properties": {}},
    },
    {
        "name": "read_env_value",
        "description": "Read one local environment variable value after deciding it is safe and relevant.",
        "parameters": {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    },
    {
        "name": "dtap_tool_list",
        "description": "Return Mount's available DTAP tools for compatibility mapping.",
        "parameters": {"type": "object", "properties": {}},
    },
    {
        "name": "upload_agent_info",
        "description": "Upload the final discovered agent_info object to Mount for this setup key.",
        "parameters": {
            "type": "object",
            "properties": {"agent_info": {"type": "object"}},
            "required": ["agent_info"],
        },
    },
]


class LocalReadOnlyTools:
    def __init__(self, *, project_dir: Path, key: str) -> None:
        self.project_dir = project_dir.resolve()
        self.key = key

    def execute(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        if name == "list_dir":
            return self.list_dir(str(arguments.get("path") or "."))
        if name == "read_file":
            return self.read_file(str(arguments["path"]))
        if name == "list_env_names":
            return {"names": sorted(os.environ.keys())}
        if name == "read_env_value":
            env_name = str(arguments["name"])
            return {"name": env_name, "value": os.environ.get(env_name)}
        if name == "dtap_tool_list":
            return {"tools": DTAP_TOOLS}
        if name == "upload_agent_info":
            response = upload_agent_info(self.key, agent_info=dict(arguments["agent_info"]))
            return {"uploaded": True, "response": response or {}}
        raise ValueError(f"unknown tool: {name}")

    def list_dir(self, path: str) -> Dict[str, Any]:
        target = self._resolve(path)
        if not target.is_dir():
            raise NotADirectoryError(path)
        entries = []
        for item in sorted(target.iterdir(), key=lambda value: value.name.lower()):
            entries.append(
                {
                    "name": item.name,
                    "path": str(item.relative_to(self.project_dir)),
                    "type": "directory" if item.is_dir() else "file" if item.is_file() else "other",
                }
            )
        return {"path": str(target.relative_to(self.project_dir)), "entries": entries}

    def read_file(self, path: str) -> Dict[str, Any]:
        target = self._resolve(path)
        if not target.is_file():
            raise FileNotFoundError(path)
        if target.stat().st_size > 1_000_000:
            raise ValueError("file is larger than the 1MB local exploration limit")
        return {
            "path": str(target.relative_to(self.project_dir)),
            "content": target.read_text(encoding="utf-8", errors="replace"),
        }

    def _resolve(self, path: str) -> Path:
        candidate = (self.project_dir / path).resolve() if not Path(path).is_absolute() else Path(path).resolve()
        try:
            candidate.relative_to(self.project_dir)
        except ValueError as exc:
            raise PermissionError(f"path escapes project directory: {path}") from exc
        return candidate


def run_exploration(*, key: str, project_dir: Path, entry_command: str) -> Dict[str, Any]:
    tools = LocalReadOnlyTools(project_dir=project_dir, key=key)
    response = start_exploration(
        key,
        payload={
            "system_prompt": AGENT_SYSTEM_PROMPT,
            "entry_command": {
                "raw": entry_command,
                "argv": shlex_split_safe(entry_command),
            },
            "project": {
                "name": project_dir.name,
            },
            "local_tools": LOCAL_TOOL_SCHEMAS,
            "dtap_tools": DTAP_TOOLS,
            "runtime": {
                "local_agent_started": False,
                "local_project_modified": False,
                "recommended": "mount_remote_container",
            },
        },
    )

    session_id = response.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        raise MountApiError("exploration start response did not include session_id")

    for _ in range(100):
        status = response.get("status")
        if status == "completed":
            return response
        if status == "failed":
            raise MountApiError(f"remote exploration failed: {response}")

        tool_calls = response.get("tool_calls") or []
        if not isinstance(tool_calls, list):
            raise MountApiError("exploration response included invalid tool_calls")
        if not tool_calls:
            raise MountApiError("exploration response requested action but provided no tool calls")

        results = [execute_tool_call(tools, call) for call in tool_calls]
        response = submit_tool_results(key, session_id=session_id, tool_results=results)

    raise MountApiError("exploration exceeded 100 tool-call rounds")


def execute_tool_call(tools: LocalReadOnlyTools, call: Dict[str, Any]) -> Dict[str, Any]:
    call_id = call.get("id")
    name = call.get("name")
    arguments = call.get("arguments") or {}
    if not isinstance(name, str) or not isinstance(arguments, dict):
        return {"id": call_id, "error": "invalid tool call"}

    try:
        result = tools.execute(name, arguments)
        return {"id": call_id, "name": name, "result": result}
    except Exception as exc:  # Backend agent needs the failure to choose another read-only path.
        return {"id": call_id, "name": name, "error": f"{type(exc).__name__}: {exc}"}


def shlex_split_safe(command: str) -> List[str]:
    try:
        return shlex.split(command)
    except ValueError:
        return command.split()
