# mountctl

`mountctl` is the Mount local exploration CLI.

```bash
pipx run mountctl explore <KEY> "<ENTRY_COMMAND>"
```
