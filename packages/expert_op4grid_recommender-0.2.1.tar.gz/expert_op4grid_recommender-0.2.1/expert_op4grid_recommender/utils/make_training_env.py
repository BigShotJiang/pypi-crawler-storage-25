"""Factory for the *training* flavour of the Grid2Op environment.

Uses :class:`LightSimBackend` for speed during training pipelines and falls
back gracefully when the backend rejects ``gen_slack_id`` (older
``lightsim2grid`` versions).
"""

from typing import Any
import os

from expert_op4grid_recommender.utils.make_env_utils import (make_backend_kwargs_data,
                                                             make_default_params)

try:
    import lightsim2grid
    from lightsim2grid import LightSimBackend
    import grid2op
    from grid2op.Environment import Environment
    from grid2op.Chronics import ChangeNothing
    _HAS_GRID2OP = True
except (ImportError, Exception):
    _HAS_GRID2OP = False

    
def make_grid2op_training_env(
    path_env: str,
    nm_env: str,
    *,
    allow_detachment: bool = True,
    params: Any = None,
    backend_loader_kwargs: dict | None = None,
    **bk_kwargs: Any,
) -> Any:
    """Build the training Grid2Op environment rooted at ``path_env/nm_env``.

    If ``lightsim2grid`` raises a ``gen_slack_id``-related error, the slack
    key is stripped from ``backend_loader_kwargs`` and the backend is
    reconstructed once; any other error is re-raised untouched.
    """
    if not _HAS_GRID2OP:
        raise ImportError("grid2op and lightsim2grid are required for make_grid2op_training_env()")
    backend_kwargs_data = make_backend_kwargs_data(loader_kwargs=backend_loader_kwargs, **bk_kwargs)
    try:
        backend = LightSimBackend(**backend_kwargs_data)
    except RuntimeError as e:
        if "gen_slack_id" in str(e) and "loader_kwargs" in str(e):
            print(f"Warning: gen_slack_id is invalid for this backend. Retrying without it. Original error: {e}")
            if "loader_kwargs" in backend_kwargs_data:
                backend_kwargs_data["loader_kwargs"].pop("gen_slack_id", None)
            backend = LightSimBackend(**backend_kwargs_data)
        else:
            raise e
    path = os.path.join(path_env, nm_env)

    if params is None:
        params = make_default_params()

    backend._prevent_automatic_disconnection = False

    if os.path.isdir(os.path.join(path,"chronics")):
        env = grid2op.make(path,
                           backend=backend,
                           allow_detachment=allow_detachment,
                           n_busbar=backend_kwargs_data["loader_kwargs"]["n_busbar_per_sub"],
                           param=params
                           )
    else:
        print("Warning: this is a bare environment with no chronics")
        env = grid2op.make(path,
                   backend=backend,
                   allow_detachment=allow_detachment,
                   n_busbar=backend_kwargs_data["loader_kwargs"]["n_busbar_per_sub"],
                   param=params
                   )
    return env


if __name__ == "__main__":
    path_env = '.'
    nm_env = "env_dijon_v2_training"
    env = make_grid2op_training_env(path_env, nm_env)
    print(env.name_line)
    print([el.slack_weight for el in env.backend._grid.get_generators()])
