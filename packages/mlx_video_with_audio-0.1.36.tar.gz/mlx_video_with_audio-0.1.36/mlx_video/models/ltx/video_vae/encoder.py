"""Video VAE Encoder for LTX-2 Image-to-Video.

The encoder compresses input images/videos to latent representations.
Used for I2V (image-to-video) conditioning by encoding the input image
to latent space, which can then be used to condition video generation.
"""

from pathlib import Path
from typing import List, Tuple, Any, Optional
import json

import mlx.core as mx
import mlx.nn as nn

from mlx_video.models.ltx.video_vae.video_vae import (
    VideoEncoder,
    LogVarianceType,
    NormLayerType,
    PaddingModeType,
)


def load_vae_encoder(model_path: str, use_unified: bool = False) -> VideoEncoder:
    """Load VAE encoder from safetensors file.

    Args:
        model_path: Path to the model weights (safetensors file or directory)
        use_unified: If True, load from unified model.safetensors with vae_encoder. prefix

    Returns:
        Loaded VideoEncoder instance
    """
    from safetensors import safe_open

    model_path = Path(model_path)

    # Unified MLX format: single model.safetensors or split vae_encoder.safetensors
    unified_prefix = None
    is_mlx_layout = False
    weights_path = None
    if use_unified:
        if (model_path / "model.safetensors").exists():
            weights_path = model_path / "model.safetensors"
            unified_prefix = "vae_encoder."
            is_mlx_layout = True
        elif (model_path / "vae_encoder.safetensors").exists():
            weights_path = model_path / "vae_encoder.safetensors"
            is_mlx_layout = True

    if weights_path is None:
        # Try to find the weights file
        if model_path.is_file() and model_path.suffix == ".safetensors":
            weights_path = model_path
        elif (model_path / "ltx-2-19b-distilled.safetensors").exists():
            weights_path = model_path / "ltx-2-19b-distilled.safetensors"
        elif (model_path / "vae" / "diffusion_pytorch_model.safetensors").exists():
            weights_path = model_path / "vae" / "diffusion_pytorch_model.safetensors"
        else:
            raise FileNotFoundError(f"VAE weights not found at {model_path}")

    print(f"Loading VAE encoder from {weights_path}...")

    # Read config from embedded_config.json first (2.3 models), then safetensors metadata
    encoder_blocks = []
    norm_layer = NormLayerType.PIXEL_NORM
    latent_log_var = LogVarianceType.UNIFORM
    patch_size = 4
    spatial_padding_mode = PaddingModeType.ZEROS

    cfg_dir = model_path.parent if model_path.is_file() else model_path
    embedded_cfg_path = cfg_dir / "embedded_config.json"
    if embedded_cfg_path.exists():
        try:
            with open(embedded_cfg_path, "r") as f:
                vae_cfg = json.load(f).get("vae", {})
            raw_blocks = vae_cfg.get("encoder_blocks", [])
            for block in raw_blocks:
                if isinstance(block, (list, tuple)) and len(block) == 2:
                    encoder_blocks.append((block[0], block[1]))
            patch_size = vae_cfg.get("patch_size", patch_size)
            padding_name = str(vae_cfg.get("spatial_padding_mode", "zeros")).lower()
            if padding_name == "zeros":
                spatial_padding_mode = PaddingModeType.ZEROS
            elif padding_name == "replicate":
                spatial_padding_mode = PaddingModeType.REPLICATE
            elif padding_name == "reflect":
                spatial_padding_mode = PaddingModeType.REFLECT
            if encoder_blocks:
                print(
                    f"  Loaded encoder config from embedded_config.json: {len(encoder_blocks)} blocks, patch_size={patch_size}"
                )
        except (json.JSONDecodeError, OSError):
            pass

    if not encoder_blocks:
        try:
            with safe_open(str(weights_path), framework="numpy") as f:
                metadata = f.metadata()
                if metadata and "config" in metadata:
                    configs = json.loads(metadata["config"])
                    vae_config = configs.get("vae", {})

                    raw_blocks = vae_config.get("encoder_blocks", [])
                    for block in raw_blocks:
                        if isinstance(block, list) and len(block) == 2:
                            name, params = block
                            encoder_blocks.append((name, params))

                    norm_str = vae_config.get("norm_layer", "pixel_norm")
                    norm_layer = (
                        NormLayerType.PIXEL_NORM
                        if norm_str == "pixel_norm"
                        else NormLayerType.GROUP_NORM
                    )

                    var_str = vae_config.get("latent_log_var", "uniform")
                    if var_str == "uniform":
                        latent_log_var = LogVarianceType.UNIFORM
                    elif var_str == "per_channel":
                        latent_log_var = LogVarianceType.PER_CHANNEL
                    elif var_str == "constant":
                        latent_log_var = LogVarianceType.CONSTANT
                    else:
                        latent_log_var = LogVarianceType.NONE

                    patch_size = vae_config.get("patch_size", 4)

                    print(
                        f"  Loaded config from metadata: {len(encoder_blocks)} encoder blocks, norm={norm_str}, patch_size={patch_size}"
                    )
        except Exception as e:
            print(f"  Could not read config from metadata: {e}")

    if not encoder_blocks:
        encoder_blocks = [
            ("res_x", {"num_layers": 4}),
            ("compress_space_res", {"multiplier": 2}),
            ("res_x", {"num_layers": 6}),
            ("compress_time_res", {"multiplier": 2}),
            ("res_x", {"num_layers": 6}),
            ("compress_all_res", {"multiplier": 2}),
            ("res_x", {"num_layers": 2}),
            ("compress_all_res", {"multiplier": 2}),
            ("res_x", {"num_layers": 2}),
        ]
        print(f"  Using default encoder config with {len(encoder_blocks)} blocks")

    # Create encoder
    encoder = VideoEncoder(
        convolution_dimensions=3,
        in_channels=3,
        out_channels=128,
        encoder_blocks=encoder_blocks,
        patch_size=patch_size,
        norm_layer=norm_layer,
        latent_log_var=latent_log_var,
        encoder_spatial_padding_mode=spatial_padding_mode,
    )

    # Load weights
    weights = mx.load(str(weights_path))

    # Filter by unified prefix if loading from unified model
    if unified_prefix:
        weights = {k: v for k, v in weights.items() if k.startswith(unified_prefix)}

    # Determine prefix based on weight keys
    has_vae_prefix = any(k.startswith("vae.") for k in weights.keys())
    has_vae_encoder_prefix = any(k.startswith("vae_encoder.") for k in weights.keys())
    has_encoder_prefix = any(k.startswith("encoder.") for k in weights.keys())
    has_bare_keys = any(
        k.startswith(("conv_in.", "conv_out.", "down_blocks.")) for k in weights.keys()
    )

    if has_vae_encoder_prefix:
        prefix = "vae_encoder."
    elif has_vae_prefix:
        prefix = "vae.encoder."
    elif has_bare_keys:
        prefix = ""
    else:
        prefix = "encoder."

    # Load per-channel statistics for normalization.
    # Keys vary by format: underscore (_mean_of_means) in split unified shards,
    # hyphen (mean-of-means) in HF/legacy checkpoints.
    mean_val = None
    std_val = None
    mean_candidates = [
        "vae_encoder.per_channel_statistics._mean_of_means",
        "per_channel_statistics._mean_of_means",
        "per_channel_statistics.mean-of-means",
        "vae.per_channel_statistics.mean-of-means",
    ]
    std_candidates = [
        "vae_encoder.per_channel_statistics._std_of_means",
        "per_channel_statistics._std_of_means",
        "per_channel_statistics.std-of-means",
        "vae.per_channel_statistics.std-of-means",
    ]
    for cand in mean_candidates:
        if cand in weights:
            mean_val = weights[cand]
            break
    for cand in std_candidates:
        if cand in weights:
            std_val = weights[cand]
            break
    if mean_val is not None:
        encoder.per_channel_statistics.mean = mean_val
        print(f"  Loaded latent mean: shape {mean_val.shape}")
    if std_val is not None:
        encoder.per_channel_statistics.std = std_val
        print(f"  Loaded latent std: shape {std_val.shape}")

    # Build encoder weights dict with key remapping
    encoder_weights = {}
    for key, value in weights.items():
        if prefix and not key.startswith(prefix):
            continue
        if not prefix and key.startswith("per_channel_statistics"):
            continue

        new_key = key[len(prefix) :] if prefix else key

        # Conv3d weight transpose: (O, I, D, H, W) -> (O, D, H, W, I)
        # Skip for MLX-layout weights (unified single file or split shards).
        if ".weight" in key and value.ndim == 5 and not is_mlx_layout:
            value = mx.transpose(value, (0, 2, 3, 4, 1))

        encoder_weights[new_key] = value

    print(f"  Found {len(encoder_weights)} encoder weights")

    # Load weights
    encoder.load_weights(list(encoder_weights.items()), strict=False)

    print("VAE encoder loaded successfully")
    return encoder


def encode_image(
    image: mx.array,
    encoder: VideoEncoder,
) -> mx.array:
    """Encode a single image to latent space.

    Args:
        image: Image tensor of shape (H, W, 3) in range [0, 1] or (B, H, W, 3)
        encoder: Loaded VAE encoder

    Returns:
        Latent tensor of shape (1, 128, 1, H//32, W//32)
    """
    # Add batch dimension if needed
    if image.ndim == 3:
        image = mx.expand_dims(image, axis=0)  # (1, H, W, 3)

    # Convert from (B, H, W, C) to (B, C, H, W)
    image = mx.transpose(image, (0, 3, 1, 2))  # (B, 3, H, W)

    # Normalize to [-1, 1]
    if image.max() > 1.0:
        image = image / 255.0
    image = image * 2.0 - 1.0

    # Add temporal dimension: (B, C, H, W) -> (B, C, 1, H, W)
    image = mx.expand_dims(image, axis=2)  # (B, 3, 1, H, W)

    # Encode
    latent = encoder(image)

    return latent
