"""Minimal runops fixture."""

