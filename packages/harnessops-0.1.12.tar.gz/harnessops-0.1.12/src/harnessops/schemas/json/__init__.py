"""Bundled JSON schemas."""

