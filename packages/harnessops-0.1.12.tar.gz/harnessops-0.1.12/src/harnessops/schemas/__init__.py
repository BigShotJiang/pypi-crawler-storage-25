"""JSON schema resources."""

