"""Bundled HarnessOps profiles."""

