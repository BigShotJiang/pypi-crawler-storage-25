"""Built-in adapters."""

