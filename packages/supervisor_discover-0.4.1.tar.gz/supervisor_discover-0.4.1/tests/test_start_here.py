"""Tests for the StartHere data structure + renderers.

Validates the four-question contract from docs/SCAN_COMMUNICATION_RULES.md:
  1. Where do I add the first wrapper?  (top_wrap_targets)
  2. What can this repo do?              (repo_capabilities)
  3. Highest-risk things to watch?       (top_risks)
  4. What to ignore?                     (hidden_counter)

Plus the rendering contracts (markdown sections, CLI line count, plain language).
"""
from __future__ import annotations

from pathlib import Path

from supervisor_discover.classifier import validate
from supervisor_discover.findings import Finding
from supervisor_discover.scanners import apply_default_hidden, scan_all
from supervisor_discover.start_here import (
    Risk,
    StartHere,
    WrapTarget,
    build_start_here,
    render_cli_start_here,
    render_start_here_md,
)
from supervisor_discover.summary import AgentChokepoint, RepoSummary, build_summary

FLASK_FIXTURE = Path(__file__).parent / "fixtures/fake_flask_app"


def _build_for_fixture(fixture: Path) -> tuple[RepoSummary, list[Finding], StartHere]:
    all_findings = validate(scan_all(fixture))
    visible, hidden = apply_default_hidden(all_findings, fixture)
    summary = build_summary(visible, hidden_counts=hidden)
    sh = build_start_here(summary, visible)
    return summary, visible, sh


# 1. Selection rules

def test_top_wrap_targets_capped_at_three():
    cps = [
        AgentChokepoint(file=f"a{i}.py", line=10 + i, kind="agent-class", label=f"Cls{i}")
        for i in range(7)
    ]
    summary = RepoSummary(agent_chokepoints=cps)
    sh = build_start_here(summary, [])
    assert len(sh.top_wrap_targets) == 3


def test_top_wrap_targets_uses_chokepoint_rank_priority():
    """A factory-file agent-class (tier 0) must sort before a non-factory one (tier 2)."""
    cps = [
        AgentChokepoint(file="src/random.py",       line=99, kind="agent-class", label="OtherCls"),
        AgentChokepoint(file="src/orchestrator.py", line=15, kind="agent-class", label="Orch"),
    ]
    summary = RepoSummary(agent_chokepoints=cps)
    sh = build_start_here(summary, [])
    assert sh.top_wrap_targets[0].label == "Orch"


def test_capabilities_use_plain_english_phrases():
    _summary, _findings, sh = _build_for_fixture(FLASK_FIXTURE)
    # Flask fixture has stripe + LLM SDKs — should produce these plain phrases.
    assert "move money" in sh.repo_capabilities
    # Phrasing should be plain — no jargon words in capability strings.
    for cap in sh.repo_capabilities:
        for forbidden in ("OWASP", "CVSS", "RCE", "exfiltration"):
            assert forbidden not in cap, f"jargon {forbidden!r} leaked into capability {cap!r}"


def test_top_risks_only_when_capability_confirmed_high():
    """A finding with confidence='medium' must NOT generate a Risk card."""
    f = Finding(
        scanner="fs-shell", file="x.py", line=1, snippet="subprocess.run(",
        suggested_action_type="tool_use", confidence="medium", rationale="...",
        extra={"family": "shell-exec"},
    )
    summary = RepoSummary()
    sh = build_start_here(summary, [f])
    assert len(sh.top_risks) == 0


def test_top_risks_ordered_by_severity_payment_before_llm():
    """payment-calls (severity 100) must precede llm-calls (severity 30)."""
    payment = Finding(
        scanner="payment-calls", file="p.py", line=10, snippet="stripe.Charge.create(",
        suggested_action_type="payment", confidence="high", rationale="...", extra={},
    )
    llm = Finding(
        scanner="llm-calls", file="l.py", line=20, snippet="openai.ChatCompletion.create(",
        suggested_action_type="tool_use", confidence="high", rationale="...", extra={},
    )
    # agent_path_present=True so non-self-contained risks aren't dropped.
    sh = build_start_here(
        RepoSummary(agent_path_present=True, llm_providers=["openai"]),
        [llm, payment],
    )
    assert sh.top_risks[0].family == "payment-calls"
    assert sh.top_risks[1].family == "llm-calls"


def test_top_risks_capped_at_three():
    findings = [
        Finding(scanner=s, file=f"{s}.py", line=1, snippet=f"{s}_call(",
                suggested_action_type="tool_use", confidence="high", rationale="...",
                extra={"family": "shell-exec"} if s == "fs-shell" else {})
        for s in ("payment-calls", "fs-shell", "email-sends", "messaging", "llm-calls")
    ]
    sh = build_start_here(
        RepoSummary(agent_path_present=True, llm_providers=["openai"]),
        findings,
    )
    assert len(sh.top_risks) == 3


def test_do_this_now_includes_supervised_snippet():
    summary = RepoSummary(agent_chokepoints=[
        AgentChokepoint(file="src/orchestrator.py", line=42, kind="agent-class", label="Orch"),
    ])
    sh = build_start_here(summary, [])
    assert "@supervised" in sh.do_this_now
    assert "supervisor_guards" in sh.do_this_now
    # Python file → Python fence + decorator syntax (no TS-only `import { ... }`).
    assert "```python" in sh.do_this_now
    assert "import {" not in sh.do_this_now


def test_do_this_now_uses_typescript_snippet_for_ts_file():
    """When the wrap target lives in a .ts file, the snippet must use the TS
    SDK (`@runtime-supervisor/guards`) and arrow-function syntax — not Python.

    Uses an `agent-class` chokepoint (in an orchestrator file so it's tier 0 and
    survives the wrap-target filter) — `framework-import` chokepoints no longer
    reach `do_this_now` because they're treated as loop signals, not wrap points.
    """
    summary = RepoSummary(agent_chokepoints=[
        AgentChokepoint(file="packages/mcp/src/orchestrator.ts", line=230,
                        kind="agent-class", label="McpDispatcher"),
    ])
    sh = build_start_here(summary, [])
    assert "```ts" in sh.do_this_now
    assert "@runtime-supervisor/guards" in sh.do_this_now
    # Must NOT leak Python idioms into a TS snippet.
    assert "supervisor_guards" not in sh.do_this_now
    assert "@supervised(" in sh.do_this_now or "supervised(" in sh.do_this_now


def test_hidden_counter_carries_through_from_summary():
    summary = RepoSummary(hidden_findings={"tests": 12, "legacy": 4})
    sh = build_start_here(summary, [])
    assert sh.hidden_counter == {"tests": 12, "legacy": 4}


# 2. Rendering contracts

def test_render_start_here_md_has_required_sections():
    _summary, _findings, sh = _build_for_fixture(FLASK_FIXTURE)
    md = render_start_here_md(sh)
    # Spec mandates these section headers, in this order.
    expected = [
        "## Best place to wrap first",
        "## What this repo can already do",
        "## Highest-risk things to care about now",
        "## Do this now",
        "## Ignore this for now",
    ]
    last = -1
    for header in expected:
        idx = md.find(header)
        assert idx > last, f"section {header!r} missing or out of order"
        last = idx


def test_render_cli_start_here_under_20_lines():
    _summary, _findings, sh = _build_for_fixture(FLASK_FIXTURE)
    lines = render_cli_start_here(sh, elapsed_s=1.2, root="fake_flask_app")
    assert 5 <= len(lines) <= 20, f"expected 5-20 CLI lines, got {len(lines)}"


def test_empty_findings_shows_no_obvious_wrap_target():
    sh = build_start_here(RepoSummary(), [])
    md = render_start_here_md(sh)
    # Empty scan: no agent class, no framework signal, no high-confidence
    # findings. The fallback no longer assumes "agent loop" — it tells the
    # dev to re-scan once they wire in the first SDK call.
    assert "No agent class" in md
    assert "re-scan once you add the first SDK call" in md
    # Capabilities section also shows the empty-state copy.
    assert "No high-stakes capabilities" in md
    # The "Heads up" banner fires whenever no agent loop is reachable, and
    # replaces the four-times-restated "no agent loop" jargon scattered
    # through the body.
    assert "**Heads up:**" in md


def test_no_agent_with_hotspot_renders_single_voice():
    """The buky shape: real capabilities + a hotspot, but no agent loop yet.

    Before this test existed, START_HERE.md restated "no agent loop" four
    times in jargon ("highest-density capability hotspot, not an immediate
    wrap instruction" / "No agent or LLM is reachable in this scan" /
    "Capability inventory" / "No agent loop is reachable in this scan"),
    which read as self-contradicting to a vibe-coder. The contract here:
    say it once, up front, then keep the rest of the report concrete.
    """
    sh = StartHere(
        repo_capabilities=["call messaging tools", "write to the database"],
        capability_hotspot=WrapTarget(
            label="messaging",
            file="infra/notifications/TelegramTransport.ts",
            line=94,
            why="1 high-confidence call concentrates in this file (messaging).",
        ),
        agent_path_present=False,
        do_this_now=(
            "1. Make sure only your code can reach "
            "`infra/notifications/TelegramTransport.ts:94` — handler-level "
            "auth check + signed webhook secret.\n"
            "2. Spot-check the medium-confidence DB writes in "
            "`FULL_REPORT.md` for a `WHERE` clause and a row cap.\n"
            "3. Re-scan after the first model SDK call (Stripe / OpenAI / "
            "Anthropic / sgMail / langchain) lands — that's when concrete "
            "`@supervised(...)` wraps apply."
        ),
        hidden_counter={"tests": 13, "migrations": 21},
    )
    md = render_start_here_md(sh)

    # Banner appears exactly once — that's the whole point of the rewrite.
    assert md.count("**Heads up:**") == 1

    # New positive heading replaces the old "Capability inventory" framing.
    assert "## If you add an AI step, gate these first" in md
    assert "## Capability inventory" not in md

    # Deny-list jargon and self-cancelling phrases that the old branch
    # emitted. Each one is what a vibe-coder failed to parse — they must
    # not reappear in the rendered output.
    forbidden = [
        "highest-density capability hotspot",
        "not an immediate wrap instruction",
        "webhook idempotency",
        "## Capability inventory",
        "No agent or LLM is reachable in this scan",
        "No high-confidence risk patterns matched",
    ]
    for phrase in forbidden:
        assert phrase not in md, f"jargon leaked back into START_HERE: {phrase!r}"

    # The "no agent loop" message lives in the banner only; subsections
    # don't restate it. Allow the banner phrase to appear, count the
    # noisier restatements separately.
    noisy = ["No agent loop", "No agent class"]
    total_noisy = sum(md.count(p) for p in noisy)
    assert total_noisy <= 1, (
        f"expected the banner to absorb the 'no agent loop' message, "
        f"but {total_noisy} restatements remain in the body"
    )

    # Hotspot path is anchored once under "Best place to wrap first".
    assert md.count("infra/notifications/TelegramTransport.ts:94") >= 1


def test_render_md_includes_hidden_counter_when_present():
    sh = StartHere(hidden_counter={"tests": 7, "legacy": 3})
    md = render_start_here_md(sh)
    assert "10 findings hidden" in md
    assert "7 tests" in md and "3 legacy" in md


# 3. Framework-import handling — must NOT pollute "Best place to wrap first".
#
# A framework import (e.g. `from langchain.agents import initialize_agent`) is
# a loop *signal*, not a wrappable call-site. Including it under "Best place
# to wrap first" produced a self-contradicting bullet ("framework entrypoint —
# signals the loop, not the wrap point itself") — the section now lives in its
# own block ("Agent frameworks detected"), and `top_wrap_targets` only carries
# actually-wrappable chokepoints.

def test_framework_imports_excluded_from_wrap_targets():
    """Solo framework-import → wrap targets vacío, framework signals presentes."""
    cps = [AgentChokepoint(file="src/agents.py", line=5,
                           kind="framework-import", label="langchain")]
    summary = RepoSummary(agent_chokepoints=cps)
    sh = build_start_here(summary, [Finding(
        scanner="agent-orchestrators", file="src/agents.py", line=5,
        snippet="from langchain.agents import initialize_agent",
        suggested_action_type="tool_use", confidence="high", rationale="...",
        extra={"kind": "framework-import", "framework": "langchain"},
    )])
    assert sh.top_wrap_targets == []
    assert len(sh.framework_signals) == 1
    assert sh.framework_signals[0].framework == "langchain"
    assert sh.framework_signals[0].file == "src/agents.py"
    assert sh.framework_signals[0].line == 5


def test_mixed_chokepoints_split_correctly():
    """agent-class + framework-import → wrap targets has only the class,
    framework signals has only the import."""
    cps = [
        AgentChokepoint(file="src/orchestrator.py", line=42,
                        kind="agent-class", label="Orch"),
        AgentChokepoint(file="src/imports.py", line=3,
                        kind="framework-import", label="langchain"),
    ]
    summary = RepoSummary(agent_chokepoints=cps)
    findings = [Finding(
        scanner="agent-orchestrators", file="src/imports.py", line=3,
        snippet="from langchain.agents import AgentExecutor",
        suggested_action_type="tool_use", confidence="high", rationale="...",
        extra={"kind": "framework-import", "framework": "langchain"},
    )]
    sh = build_start_here(summary, findings)
    assert len(sh.top_wrap_targets) == 1
    assert sh.top_wrap_targets[0].label == "Orch"
    assert len(sh.framework_signals) == 1
    assert sh.framework_signals[0].framework == "langchain"


def test_framework_signals_section_rendered_in_md():
    """Markdown contains '## Agent frameworks detected' iff framework_signals
    is non-empty."""
    cps = [AgentChokepoint(file="src/x.py", line=1,
                           kind="framework-import", label="langchain")]
    summary = RepoSummary(agent_chokepoints=cps)
    findings = [Finding(
        scanner="agent-orchestrators", file="src/x.py", line=1,
        snippet="from langchain import …",
        suggested_action_type="tool_use", confidence="high", rationale="...",
        extra={"kind": "framework-import", "framework": "langchain"},
    )]
    md_with = render_start_here_md(build_start_here(summary, findings))
    assert "## Agent frameworks detected" in md_with
    assert "**langchain**" in md_with

    md_without = render_start_here_md(build_start_here(RepoSummary(), []))
    assert "## Agent frameworks detected" not in md_without


def test_wrap_first_falls_back_with_framework_signals_no_contradiction():
    """When only framework imports exist, the 'Best place to wrap first' section
    must NOT carry the contradictory copy and must NAME the framework so the
    dev knows where the loop lives."""
    cps = [AgentChokepoint(file="repo/setup.py", line=11,
                           kind="framework-import", label="langchain")]
    summary = RepoSummary(agent_chokepoints=cps)
    findings = [Finding(
        scanner="agent-orchestrators", file="repo/setup.py", line=11,
        snippet="initialize_agent(tools, llm)",
        suggested_action_type="tool_use", confidence="high", rationale="...",
        extra={"kind": "framework-import", "framework": "langchain"},
    )]
    md = render_start_here_md(build_start_here(summary, findings))

    # Slice the "Best place to wrap first" section out so we only assert on it.
    start = md.find("## Best place to wrap first")
    end = md.find("\n## ", start + 1)
    section = md[start:end]

    assert "signals the loop, not the wrap point itself" not in section, (
        "Regression: contradictory copy leaked back into 'Best place to wrap first'."
    )
    assert "langchain" in section
    assert "agent.run" in section or "AgentExecutor.invoke" in section


def test_no_wrap_no_signals_keeps_existing_empty_copy():
    """No agent class, no framework signals, no findings: render the explicit
    'no high-confidence supervised-worthy calls' copy instead of telling the
    dev to look for an 'agent loop' that doesn't exist."""
    md = render_start_here_md(build_start_here(RepoSummary(), []))
    assert "No agent class" in md
    assert "re-scan once you add the first SDK call" in md
    assert "## Agent frameworks detected" not in md


def test_render_md_section_order_with_frameworks():
    """When framework signals are present, the new section sits between
    'What this repo can already do' and 'Highest-risk things to care about now'."""
    cps = [AgentChokepoint(file="src/a.py", line=1,
                           kind="framework-import", label="langchain")]
    # Framework signal counts as agent path — keep the risk header.
    summary = RepoSummary(agent_chokepoints=cps, agent_path_present=True,
                          llm_providers=["openai"])
    findings = [Finding(
        scanner="agent-orchestrators", file="src/a.py", line=1,
        snippet="from langchain import …",
        suggested_action_type="tool_use", confidence="high", rationale="...",
        extra={"kind": "framework-import", "framework": "langchain"},
    )]
    md = render_start_here_md(build_start_here(summary, findings))
    expected_order = [
        "## Best place to wrap first",
        "## What this repo can already do",
        "## Agent frameworks detected",
        "## Highest-risk things to care about now",
        "## Do this now",
        "## Ignore this for now",
    ]
    last = -1
    for header in expected_order:
        idx = md.find(header)
        assert idx > last, f"section {header!r} missing or out of order"
        last = idx


def test_do_this_now_points_at_framework_when_no_wrap_targets():
    """When the only chokepoint is a framework-import, `do_this_now` must point
    at that framework + file:line and explicitly say 'not the import line'.

    Note the file is `repo/setup.py` — `setup.py` is a low-reachability path,
    but framework signals fall back to "show whatever we have" so the loop
    can still be communicated to the dev.
    """
    cps = [AgentChokepoint(file="repo/setup.py", line=11,
                           kind="framework-import", label="langchain")]
    summary = RepoSummary(agent_chokepoints=cps)
    findings = [Finding(
        scanner="agent-orchestrators", file="repo/setup.py", line=11,
        snippet="initialize_agent(tools, llm)",
        suggested_action_type="tool_use", confidence="high", rationale="...",
        extra={"kind": "framework-import", "framework": "langchain"},
    )]
    sh = build_start_here(summary, findings)
    assert "langchain" in sh.do_this_now
    assert "setup.py:11" in sh.do_this_now
    assert "Tool(func" in sh.do_this_now or "agent.run" in sh.do_this_now


# 4. Reachability filter — low-reachability paths must not occupy the top
# of "Best place to wrap first" or "Highest-risk" sections.

def test_low_reachability_chokepoint_excluded_from_wrap_targets():
    """A chokepoint under `tests/`, `setup.py`, `scripts/`, `legacy/`, or
    `test-setup-*` must not be the FIRST place we point the dev at — the
    GiftedAgentV2 scenario where `langchain_NR_setup.py` headlined the wrap
    targets is the bug we're guarding against."""
    cps = [
        AgentChokepoint(file="src/agents/orchestrator.py", line=42,
                        kind="agent-class", label="ProdOrch"),
        AgentChokepoint(file="test-setup-newrelic/langchain_NR_setup.py",
                        line=11, kind="agent-class", label="TestOrch"),
    ]
    summary = RepoSummary(agent_chokepoints=cps)
    sh = build_start_here(summary, [])
    labels = [t.label for t in sh.top_wrap_targets]
    assert "ProdOrch" in labels
    assert "TestOrch" not in labels, (
        "test-setup-* path leaked into wrap targets — reachability filter broke."
    )


def test_low_reachability_finding_excluded_from_top_risks():
    """A `subprocess.run` in `setup.py` is real code but not the agent's
    runtime path. The supervincent scenario (build script flagged as
    'Shell execution present') is the regression to prevent."""
    findings = [Finding(
        scanner="fs-shell", file="setup.py", line=58,
        snippet="subprocess.check_call([sys.executable, '-m', 'pip', 'install'])",
        suggested_action_type="tool_use", confidence="high", rationale="...",
        extra={"family": "shell-exec"},
    )]
    sh = build_start_here(RepoSummary(), findings)
    families = [r.family for r in sh.top_risks]
    assert "fs-shell-shell-exec" not in families


def test_already_gated_finding_excluded_from_top_risks():
    """When gate_coverage marked a finding as `already_gated`, the START_HERE
    risks section must not tell the dev to 'do this now: wrap it'. Mirrors
    the supervincent post-onboarding scenario where the wrap was already
    applied but the report kept asking for it."""
    findings = [Finding(
        scanner="payment-calls", file="src/api/routes/payments.py", line=155,
        snippet="stripe.checkout.Session.create(",
        suggested_action_type="payment", confidence="high", rationale="...",
        extra={"already_gated": True, "gated_by": "guarded(...)"},
    )]
    sh = build_start_here(RepoSummary(), findings)
    assert sh.top_risks == []


# 5. Multi-method dispatcher — wrap copy must reflect that one decorator
# does NOT cover every public entry point.

def test_multi_method_dispatcher_changes_wrap_target_why():
    """When the chokepoint's class has ≥2 peer dispatch methods, the 'why'
    string explicitly says 'wrap each one' — the AlertDispatcher scenario
    where 5 dispatch_*_alert methods were collapsed into 'one wrapper covers
    all' (false claim)."""
    cp = AgentChokepoint(
        file="src/orchestrator.py", line=42,
        kind="agent-class", label="AlertDispatcher",
        parallel_methods=("dispatch_anomaly_alert", "dispatch_deadline_alert",
                          "dispatch_sla_alert"),
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [])
    assert len(sh.top_wrap_targets) == 1
    why = sh.top_wrap_targets[0].why
    assert "3 peer dispatch methods" in why
    assert "wrap each" in why
    assert "one wrapper" not in why  # the false claim must be gone


# 6. Step 0 — Bootstrap section
#
# Without this block, the very first paste of a wrap snippet fails with
# `ModuleNotFoundError: supervisor_guards`. Every test here guards against
# regressing to that state for at least one realistic repo shape.

def _write(tmp: Path, name: str, body: str) -> Path:
    p = tmp / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body)
    return p


def test_step_0_section_rendered_when_bootstrap_detected(tmp_path: Path):
    _write(tmp_path, "requirements.txt", "fastapi\n")
    _write(tmp_path, "src/api/app.py", "from fastapi import FastAPI\napp = FastAPI()\n")
    cp = AgentChokepoint(
        file=str(tmp_path / "src/api/app.py"),
        line=1, kind="agent-class", label="App",
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [], repo_root=tmp_path)
    md = render_start_here_md(sh)
    assert "## Step 0 — install the SDK" in md
    assert "pip install" in md
    assert "supervisor-guards" in md


def test_step_0_omitted_when_nothing_to_wrap(tmp_path: Path):
    """Empty findings + empty summary → Step 0 must NOT render. Anchors the
    `_has_anything_to_wrap` guard added so a clean repo (e.g. fastapi-
    realworld) doesn't lead with a `poetry add supervisor-guards` banner
    before any actionable finding."""
    _write(tmp_path, "requirements.txt", "fastapi\n")
    sh = build_start_here(RepoSummary(), [], repo_root=tmp_path)
    md = render_start_here_md(sh)
    assert "## Step 0" not in md
    # Bootstrap data is still computed (the schema doesn't change) — the
    # renderer just chose not to surface it here.
    assert sh.bootstrap is not None


def test_step_0_section_omitted_when_repo_root_not_passed():
    """Backwards compatibility: callers that don't provide `repo_root` get
    the previous output exactly — no Step 0 section."""
    sh = build_start_here(RepoSummary(), [])
    md = render_start_here_md(sh)
    assert "## Step 0" not in md
    assert sh.bootstrap is None


def test_step_0_section_omitted_when_no_manifest(tmp_path: Path):
    """Empty repo (no manifest) but with a wrap target → BootstrapInfo with
    manager=None → renderer emits a softer block. Specifically must not
    crash and must mention how to proceed."""
    cp = AgentChokepoint(
        file=str(tmp_path / "agent.py"), line=1, kind="agent-class", label="A",
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [], repo_root=tmp_path)
    md = render_start_here_md(sh)
    assert "## Step 0 — install the SDK" in md
    # Generic copy when no manager is detected.
    assert "couldn't classify" in md.lower() or "your usual package manager" in md.lower()


def test_step_0_skips_configure_block_when_already_called(tmp_path: Path):
    """Mirrors supervincent — the entry point already calls
    `configure_supervisor()`. The Step 0 block must NOT show the wiring
    paste; instead it acknowledges the existing call."""
    _write(tmp_path, "requirements.txt", "fastapi\n")
    _write(tmp_path, "src/api/app.py", """
from fastapi import FastAPI
from supervisor_guards import configure_supervisor

configure_supervisor()
app = FastAPI()
""")
    cp = AgentChokepoint(
        file=str(tmp_path / "src/api/app.py"),
        line=1, kind="agent-class", label="App",
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [], repo_root=tmp_path)
    md = render_start_here_md(sh)
    assert "already called near the FastAPI" in md
    # Must NOT emit the configure_supervisor() paste (with the import line).
    assert "from supervisor_guards import configure_supervisor" not in md


def test_step_0_picks_ts_when_top_wrap_target_is_typescript(tmp_path: Path):
    """Top wrap target is a `.ts` file → Step 0 block targets the JS manager,
    not Python, even when both are present in the repo."""
    _write(tmp_path, "backend/requirements.txt", "fastapi\n")
    _write(tmp_path, "frontend/package.json", '{"name":"web"}')
    _write(tmp_path, "frontend/pnpm-lock.yaml", "")
    cp = AgentChokepoint(
        file=str(tmp_path / "frontend/orchestrator.ts"),
        line=10, kind="agent-class", label="OrchestratorTS",
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [], repo_root=tmp_path)
    md = render_start_here_md(sh)
    assert "pnpm add @runtime-supervisor/guards" in md
    assert "pip install" not in md


def test_render_md_section_order_with_bootstrap(tmp_path: Path):
    """Step 0 must come BEFORE 'Best place to wrap first'."""
    _write(tmp_path, "requirements.txt", "fastapi\n")
    cp = AgentChokepoint(
        file=str(tmp_path / "agent.py"), line=1, kind="agent-class", label="A",
    )
    summary = RepoSummary(agent_chokepoints=[cp], agent_path_present=True)
    sh = build_start_here(summary, [], repo_root=tmp_path)
    md = render_start_here_md(sh)
    expected_order = [
        "## Step 0 — install the SDK",
        "## Best place to wrap first",
        "## What this repo can already do",
        "## Highest-risk things to care about now",
        "## Do this now",
        "## Ignore this for now",
    ]
    last = -1
    for header in expected_order:
        idx = md.find(header)
        assert idx > last, f"section {header!r} missing or out of order"
        last = idx


def test_cli_render_includes_step_0_line(tmp_path: Path):
    _write(tmp_path, "requirements.txt", "fastapi\n")
    cp = AgentChokepoint(
        file=str(tmp_path / "agent.py"), line=1, kind="agent-class", label="A",
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [], repo_root=tmp_path)
    lines = render_cli_start_here(sh, elapsed_s=1.0, root="x")
    joined = "\n".join(lines)
    assert "Step 0:" in joined
    # Must still fit inside the documented 5-20 line budget.
    assert 5 <= len(lines) <= 20


# 7. Decision-branching dispatcher picker
#
# When a class has methods named `handle()` / `execute()` (the names we'd
# preferred before) AND another method whose body actually branches on
# `if action == X` / `match action: case ...`, the AST-based picker should
# choose the branching method — that's the real dispatcher. The reviewer
# flagged on castor-1 that the snippet was pointing at a fictional `handle()`
# instead of the real `_execute_action(self, decision)`.

def test_dispatcher_method_with_decision_branching_beats_handle(tmp_path: Path):
    """Class has both `handle()` (no dispatch) and `_execute_action()` (real
    dispatch with `if action == ...`). Picker must prefer the branching one.
    Verified end-to-end via the rendered Python snippet."""
    _write(tmp_path, "src/agents/electoral.py", '''
from enum import Enum

class AgentAction(Enum):
    CREATE_INCIDENT = "create_incident"
    ESCALATE = "escalate"

class Decision:
    pass

class ElectoralIntelligenceAgent:
    def handle(self, payload):
        """Public entrypoint that just delegates."""
        return self._execute_action(payload)

    def _execute_action(self, decision: Decision):
        action = decision.action
        if action == AgentAction.CREATE_INCIDENT:
            return self._create()
        elif action == AgentAction.ESCALATE:
            return self._escalate()
        return None

    def _create(self): return 1
    def _escalate(self): return 2
''')
    cp = AgentChokepoint(
        file=str(tmp_path / "src/agents/electoral.py"),
        line=10, kind="agent-class", label="ElectoralIntelligenceAgent",
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [])
    # The "Do this now" snippet must point at the dispatcher method, not handle.
    assert "_execute_action" in sh.do_this_now
    assert "decision: Decision" in sh.do_this_now or "decision:" in sh.do_this_now
    # And it must NOT recommend the dummy handle() that just delegates.
    assert "def handle" not in sh.do_this_now


def test_match_statement_dispatcher_picked(tmp_path: Path):
    """Python 3.10+ structural match on a decision key — same signal as
    `if action == X` chains."""
    _write(tmp_path, "src/agents/router.py", '''
class RoutingAgent:
    def handle(self, payload):
        return None

    def route(self, intent):
        match intent:
            case "create": return 1
            case "delete": return 2
            case _: return None
''')
    cp = AgentChokepoint(
        file=str(tmp_path / "src/agents/router.py"),
        line=2, kind="agent-class", label="RoutingAgent",
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [])
    assert "def route" in sh.do_this_now
    assert "intent" in sh.do_this_now


def test_no_decision_branching_falls_back_to_name_preference(tmp_path: Path):
    """When no method has decision branching, the picker falls back to the
    existing name-based preference (handle wins over arbitrary names)."""
    _write(tmp_path, "src/agents/plain.py", '''
class PlainAgent:
    def utility(self): return 1
    def handle(self, payload): return self.utility()
    def helper(self): return 2
''')
    cp = AgentChokepoint(
        file=str(tmp_path / "src/agents/plain.py"),
        line=2, kind="agent-class", label="PlainAgent",
    )
    summary = RepoSummary(agent_chokepoints=[cp])
    sh = build_start_here(summary, [])
    assert "def handle" in sh.do_this_now


# 8. Cross-file agent call-graph — children covered by parent fall out
# of "Best place to wrap first" so the report stops giving the dev two
# contradictory recommendations.

def test_child_agent_with_parent_in_chokepoints_falls_out_of_top(tmp_path: Path):
    """The supervincent shape: BudgetSupervisor instantiates BudgetExtractor.
    Both are agent-class chokepoints. Without the call-graph, both compete
    for top-3. With it, the child drops because the parent covers it
    transitively."""
    cps = [
        AgentChokepoint(
            file="src/agents/budget_supervisor_agent.py", line=17,
            kind="agent-class", label="BudgetSupervisorAgent",
        ),
        AgentChokepoint(
            file="src/agents/budget_extractor_agent.py", line=33,
            kind="agent-class", label="BudgetExtractorAgent",
        ),
        AgentChokepoint(
            file="src/agents/ingestion/agent.py", line=14,
            kind="agent-class", label="IngestionAgent",
        ),
    ]
    summary = RepoSummary(agent_chokepoints=cps)
    # Synthetic finding that carries the `parent_agent` annotation produced
    # by `agent_graph.annotate_findings` at scan time.
    findings = [
        Finding(
            scanner="agent-orchestrators",
            file="src/agents/budget_extractor_agent.py", line=33,
            snippet="class BudgetExtractorAgent",
            suggested_action_type="tool_use", confidence="high",
            rationale="...",
            extra={
                "kind": "agent-class",
                "class_name": "BudgetExtractorAgent",
                "parent_agent": "BudgetSupervisorAgent",
            },
        ),
    ]
    sh = build_start_here(summary, findings)
    labels = [t.label for t in sh.top_wrap_targets]
    assert "BudgetSupervisorAgent" in labels
    assert "IngestionAgent" in labels
    assert "BudgetExtractorAgent" not in labels, (
        "Child agent must drop out of the top — its parent covers it transitively."
    )


def test_child_without_parent_in_chokepoints_stays(tmp_path: Path):
    """Edge case: a child is annotated with `parent_agent`, but the parent
    isn't itself in the chokepoint set (low confidence / suppressed / etc).
    The child should NOT be demoted — wrapping the parent isn't an option."""
    cps = [
        AgentChokepoint(
            file="src/agents/orphan_extractor.py", line=1,
            kind="agent-class", label="OrphanExtractor",
        ),
    ]
    summary = RepoSummary(agent_chokepoints=cps)
    findings = [
        Finding(
            scanner="agent-orchestrators",
            file="src/agents/orphan_extractor.py", line=1,
            snippet="class OrphanExtractor",
            suggested_action_type="tool_use", confidence="high",
            rationale="...",
            extra={
                "kind": "agent-class",
                "class_name": "OrphanExtractor",
                "parent_agent": "MissingParent",  # not in chokepoints
            },
        ),
    ]
    sh = build_start_here(summary, findings)
    labels = [t.label for t in sh.top_wrap_targets]
    assert "OrphanExtractor" in labels


# 8. Capability hotspot picker (10-repo benchmark regressions)
#
# The hotspot fallback fires when there's no agent class and no framework
# signal. Before the benchmark fix it picked the file with the most
# high-confidence calls — even when that file lived under tests/, examples/,
# or CI scaffolding. cal-diy chose `features.repository.integration-test.ts`,
# chatwoot chose CI SQL files, supabase chose example directories. The
# hotspot must filter by `is_low_reachability_path`.

def test_hotspot_ignores_integration_test_file():
    """cal-diy regression: a `features.repository.integration-test.ts` had
    more high-confidence findings than any production handler. The picker
    used to land on it; now reachability filtering rejects it."""
    from supervisor_discover.start_here import _pick_capability_hotspot

    test_file = "src/features/users.repository.integration-test.ts"
    real_handler = "src/api/routes/checkout.ts"
    findings = [
        # 3 hits in the test file — would win on count alone.
        Finding(scanner="payment-calls", file=test_file, line=10,
                snippet="stripe.charges.create(", suggested_action_type="payment",
                confidence="high", rationale="x", extra={}),
        Finding(scanner="payment-calls", file=test_file, line=20,
                snippet="stripe.refunds.create(", suggested_action_type="refund",
                confidence="high", rationale="x", extra={}),
        Finding(scanner="db-mutations", file=test_file, line=30,
                snippet="DELETE FROM", suggested_action_type="data_access",
                confidence="high", rationale="x", extra={"verb": "DELETE"}),
        # 1 hit in the real handler — wins after the test file is filtered.
        Finding(scanner="payment-calls", file=real_handler, line=42,
                snippet="stripe.charges.create(", suggested_action_type="payment",
                confidence="high", rationale="x", extra={}),
    ]
    hotspot = _pick_capability_hotspot(findings)
    assert hotspot is not None
    assert hotspot.file == real_handler


def test_hotspot_ignores_circleci_directory():
    """chatwoot regression: CI setup SQL was the highest-density file."""
    from supervisor_discover.start_here import _pick_capability_hotspot

    findings = [
        Finding(scanner="db-mutations", file=".circleci/db-bootstrap.py",
                line=10, snippet="INSERT INTO users", suggested_action_type="account_change",
                confidence="high", rationale="x", extra={"verb": "INSERT", "table": "users"}),
        Finding(scanner="db-mutations", file=".circleci/db-bootstrap.py",
                line=20, snippet="UPDATE users SET", suggested_action_type="account_change",
                confidence="high", rationale="x", extra={"verb": "UPDATE", "table": "users"}),
    ]
    hotspot = _pick_capability_hotspot(findings)
    assert hotspot is None, (
        "all candidates are low-reachability — picker must yield None "
        "instead of choosing the least-bad noise file"
    )


def test_no_agent_path_demotes_non_self_contained_risks():
    """When `agent_path_present is False`, only self-contained risks
    (eval / pickle / verify=False / JWT bypass) make it to top_risks.
    Stripe, email, etc. become inventory because no agent reaches them.
    fastapi-realworld and chatwoot were misframed as urgent agent risk
    in the 10-repo benchmark despite having no agent path."""
    summary = RepoSummary(agent_path_present=False)
    findings = [
        # Stripe — would normally be top_risk, but no agent path → drops.
        Finding(scanner="payment-calls", file="api/checkout.py", line=10,
                snippet="stripe.charges.create(", suggested_action_type="payment",
                confidence="high", rationale="...", extra={}),
        # eval — self-contained RCE primitive, stays in top_risks even
        # without an agent (a direct user-input handler can hit it).
        Finding(scanner="fs-shell", file="api/admin.py", line=20,
                snippet="eval(payload)", suggested_action_type="tool_use",
                confidence="high", rationale="...",
                extra={"family": "code-eval"}),
    ]
    sh = build_start_here(summary, findings)
    titles = [r.title for r in sh.top_risks]
    assert any("eval" in t.lower() or "exec" in t.lower() for t in titles), (
        f"self-contained RCE risk must survive — got titles {titles}"
    )
    assert not any("money" in t.lower() for t in titles), (
        f"Stripe risk must drop when no agent path — got titles {titles}"
    )


def test_agent_path_present_keeps_normal_priority_ladder():
    """When `agent_path_present is True`, top_risks behave as before —
    Stripe + eval both surface, ordered by severity."""
    summary = RepoSummary(
        agent_path_present=True,
        llm_providers=["openai"],
    )
    findings = [
        Finding(scanner="payment-calls", file="api/checkout.py", line=10,
                snippet="stripe.charges.create(", suggested_action_type="payment",
                confidence="high", rationale="...", extra={}),
        Finding(scanner="fs-shell", file="api/admin.py", line=20,
                snippet="eval(payload)", suggested_action_type="tool_use",
                confidence="high", rationale="...",
                extra={"family": "code-eval"}),
    ]
    sh = build_start_here(summary, findings)
    titles = [r.title for r in sh.top_risks]
    assert any("money" in t.lower() for t in titles)
    assert any("eval" in t.lower() or "exec" in t.lower() for t in titles)


def test_renderer_uses_capability_inventory_header_without_agent_path():
    """The 10-repo benchmark caught fastapi-realworld being framed as
    urgent agent risk despite having no agent path. The renderer must
    swap the urgent risk header for an "if you add an AI step" framing
    when agent_path_present is False, so the report tells the dev the
    truth: nothing to gate today, here's the day-one list when there is.
    """
    summary = RepoSummary(agent_path_present=False)
    sh = build_start_here(summary, [])
    md = render_start_here_md(sh)
    assert "## If you add an AI step, gate these first" in md
    assert "## Highest-risk things to care about now" not in md


def test_renderer_uses_risk_header_with_agent_path():
    """With an agent path present, the original risk header stays."""
    summary = RepoSummary(agent_path_present=True, llm_providers=["openai"])
    sh = build_start_here(summary, [])
    md = render_start_here_md(sh)
    assert "## Highest-risk things to care about now" in md
    assert "## Capability inventory" not in md


def test_hotspot_returns_none_when_all_candidates_demoted():
    """When every high-confidence finding is in a demoted path, return
    None. The renderer already handles None by falling back to the
    'no obvious wrap target' copy."""
    from supervisor_discover.start_here import _pick_capability_hotspot

    findings = [
        Finding(scanner="payment-calls", file="examples/checkout.ts", line=1,
                snippet="stripe.charges.create(", suggested_action_type="payment",
                confidence="high", rationale="x", extra={}),
        Finding(scanner="db-mutations", file="docs/sample.py", line=1,
                snippet="INSERT INTO users", suggested_action_type="account_change",
                confidence="high", rationale="x", extra={"verb": "INSERT", "table": "users"}),
        Finding(scanner="payment-calls", file="src/__generated__/types.ts",
                line=1, snippet="stripe.refunds.create(", suggested_action_type="refund",
                confidence="high", rationale="x", extra={}),
    ]
    assert _pick_capability_hotspot(findings) is None


def test_hotspot_does_not_choose_http_route_inventory():
    """nextjs-subscription-payments regression: auth helper route inventory
    outnumbered Stripe calls and became the suggested wrap target. Route
    inventory should not drive the hotspot fallback."""
    from supervisor_discover.start_here import _pick_capability_hotspot

    findings = [
        Finding(scanner="http-routes", file="utils/auth-helpers/server.ts",
                line=i, snippet="export async function GET(",
                suggested_action_type="other", confidence="high",
                rationale="x", extra={})
        for i in range(1, 10)
    ]
    findings.append(
        Finding(scanner="payment-calls", file="utils/stripe/server.ts",
                line=89, snippet="stripe.checkout.sessions.create",
                suggested_action_type="payment", confidence="high",
                rationale="x", extra={})
    )
    hotspot = _pick_capability_hotspot(findings)
    assert hotspot is not None
    assert hotspot.file == "utils/stripe/server.ts"


def test_no_agent_hotspot_copy_is_inventory_not_wrap_instruction():
    """Plain SaaS repos can have Stripe/DB capabilities without an agent path.
    START_HERE should tell the user to harden the handler today and reserve
    the `@supervised(...)` wrap for the day a model can actually reach it
    — never frame it as an immediate wrap instruction.
    """
    summary = RepoSummary(agent_path_present=False)
    findings = [
        Finding(scanner="payment-calls", file="utils/stripe/server.ts",
                line=89, snippet="stripe.checkout.sessions.create",
                suggested_action_type="payment", confidence="high",
                rationale="x", extra={})
    ]
    sh = build_start_here(summary, findings)
    md = render_start_here_md(sh)
    # Banner up front owns the "no AI loop" message.
    assert "**Heads up:**" in md
    # Wrap framing is conditional on a future AI step, not "do it now".
    assert "If you add an AI step later" in md
    # "Open that file and wrap …" is the agent-path-present copy and must
    # not leak into the no-agent branch.
    assert "Open that file and wrap the exported handler" not in md
    # Self-cancelling jargon from the old branch must not reappear.
    assert "highest-density capability hotspot" not in md
    assert "not an immediate wrap instruction" not in md
