"""Rule-based repo summary.

Aggregates scanner signals into a plain-language briefing for the top of
the report. No LLM — every fact comes from what the scanners already
observed, so the summary is reproducible and cheap.

The LLM refine pass (--refine against Claude) is deferred; this module
is the deterministic baseline that ships every scan.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass, field
from typing import TYPE_CHECKING, Any

from pathlib import Path

from .findings import Finding
from .repo_kind import detect_repo_kind

if TYPE_CHECKING:
    from .start_here import StartHere

# Table names that usually mean PII or money — flagged so the summary can
# tell the reader "your repo touches sensitive tables" even if policies
# haven't been written for the app's specific schema yet.
_SENSITIVE_TABLE_HINTS = {
    "users", "user", "customers", "customer", "accounts", "account",
    "orders", "order", "payments", "payment", "invoices", "invoice",
    "subscriptions", "subscription", "transactions", "transaction",
    "profiles", "profile", "wallets", "wallet", "cards", "card",
    "sessions", "session", "auth_tokens", "api_keys",
}

# Stripe method families → human-readable capability labels.
_STRIPE_CAPABILITY = {
    "refund": "refunds",
    "refunds": "refunds",
    "charge": "charges",
    "paymentintent": "payments",
    "payout": "payouts",
    "transfer": "transfers",
    "subscription": "subscriptions",
    "subscriptionitem": "subscriptions",
    "checkout": "checkout",
    "invoice": "invoices",
    "customer": "customer-mgmt",
}

# LLM root module → brand. `.get()` covers aliases resolved by _imports.
_LLM_BRAND = {
    "anthropic": "Anthropic Claude",
    "openai": "OpenAI",
    "langchain": "LangChain",
    "langchain_core": "LangChain",
    "langchain_community": "LangChain",
    "llama_index": "LlamaIndex",
    "llama_cpp": "llama.cpp (local)",
}

# Real-world actions — the `scanner` name → human-readable capability label.
# Used for the top-of-report summary so the reader sees at a glance what the
# agent can DO (beyond just reading and computing).
_REAL_WORLD_CAPABILITY: dict[str, str] = {
    "voice-actions": "voice / telephony",
    "messaging": "messaging (slack / discord / sms)",
    "email-sends": "email sends",
    "calendar-actions": "calendar events",
    "fs-shell": "filesystem / shell exec",
    "media-gen": "generative media",
}

# Plain-English capability phrases for the "What this repo can already do"
# section. Keyed by `<scanner>` or `<scanner>-<family>` so fs-shell can split
# into delete/write/exec. Loaded by start_here.py via policy_loader so users
# tune in YAML; this dict is the deterministic fallback used by tests + when
# a scanner reports a family the YAML doesn't cover.
_PLAIN_ENGLISH_CAPABILITY: dict[str, str] = {
    "payment-calls": "move money",
    "email-sends": "send emails",
    "messaging": "call messaging tools",
    "voice-actions": "place phone or voice calls",
    "calendar-actions": "create calendar events",
    "fs-shell-shell-exec": "run shell commands",
    "fs-shell-fs-delete": "delete files",
    "fs-shell-fs-write": "write files",
    "fs-shell-code-eval": "run arbitrary code via eval / exec",
    "fs-shell-unsafe-deserialize": "deserialize untrusted bytes (pickle / dill)",
    "auth-bypass-tls-bypass": "skip TLS certificate checks",
    "auth-bypass-jwt-bypass": "accept unsigned JWTs",
    "db-mutations-redis-flush": "wipe redis keyspaces",
    "llm-calls": "call LLMs",
    "db-mutations-write": "write to the database",
    "db-mutations-delete": "delete database rows",
    "media-gen": "generate images / audio / video",
    "agent-orchestrators": "run an agent loop",
}


@dataclass(frozen=True)
class AgentChokepoint:
    """A single point where wrapping with @supervised gives total agent
    coverage — a `Controller.handle()`, a `Dispatcher.dispatch()`, or
    the entry-point of an agent framework executor."""
    file: str
    line: int
    kind: str           # "agent-class" | "tool-registration" | "framework-import"
    label: str          # class/tool/framework name
    # When the class has ≥2 peer dispatch methods (`dispatch_sla_alert`,
    # `dispatch_deadline_alert`, …), wrapping the class is NOT enough — each
    # method is a separate public entry point. We surface the names so the
    # renderer can warn the user. Empty tuple = single chokepoint, normal case.
    parallel_methods: tuple[str, ...] = ()


@dataclass(frozen=True)
class RepoSummary:
    frameworks: list[str] = field(default_factory=list)
    http_routes: int = 0
    payment_integrations: dict[str, list[str]] = field(default_factory=dict)
    llm_providers: list[str] = field(default_factory=list)
    # capability label → list of unique providers. e.g.:
    #   {"voice / telephony": ["twilio", "elevenlabs"],
    #    "calendar events": ["google"]}
    real_world_actions: dict[str, list[str]] = field(default_factory=dict)
    # Adjacent web-app security findings tagged `extra.scope=="non-agent-security"`
    # at the scanner. Keyed by family (`rls-missing`, `rls-no-policy`) → list
    # of `file:line` strings. These are real, accurate findings — but they're
    # outside the "what your LLM can fire" charter, so the renderer presents
    # them in a separate "Database hygiene" section instead of letting them
    # compete with agent wrap-points for headline real estate. The tph
    # benchmark surfaced this gap: 3 RLS findings dominated the `high` slot
    # on a repo with no agent at all.
    database_hygiene: dict[str, list[str]] = field(default_factory=dict)
    # Agent orchestration chokepoints — wrap ONE of these for total coverage.
    agent_chokepoints: list[AgentChokepoint] = field(default_factory=list)
    # Tool names the agent exposes (from dispatcher.register etc). Order-preserving.
    agent_tools: list[str] = field(default_factory=list)
    # MCP-specific tool names exposed via @modelcontextprotocol/sdk. Reported
    # separately from agent_tools because the wrap pattern differs (wrap the
    # CallTool dispatcher, not a langchain executor).
    mcp_tools: list[str] = field(default_factory=list)
    db_tables_touched: list[str] = field(default_factory=list)
    sensitive_tables: list[str] = field(default_factory=list)
    scheduled_jobs: int = 0
    total_findings: int = 0
    one_liner: str = ""
    # High-level repo classification for the UI to specialize the headline:
    #   "mcp-server"           — exposes MCP tools via @modelcontextprotocol/sdk
    #   "langchain-agent"      — uses langchain AgentExecutor / langgraph
    #   "mcp-server+langchain" — both
    #   None                   — generic agent code
    repo_type: str | None = None
    # Framework vs app classification. "framework" → this repo is a
    # distributable SDK; the chokepoints below are *consumer integration
    # surfaces*, not deployed wrap targets. The renderers in start_here.py
    # use this to switch the lead copy from "wrap here" to "wrap when you
    # adopt this in your app". "app" → standard runtime, normal copy.
    # "unknown" → heuristic was inconclusive; default to standard copy.
    repo_kind: str = "unknown"
    # True when at least one agent/LLM signal was detected — an LLM SDK
    # provider, an agent-class chokepoint, or a registered agent tool.
    # When False, findings represent **capability inventory** (what an
    # attacker reaching the code-path could do), not **agent risk** (what
    # an LLM in a loop could trigger). The renderer flips its priority
    # ladder copy on this flag — fastapi-realworld, nextjs-subscription-
    # payments and chatwoot all came back agent-pathless on the 10-repo
    # benchmark and were being misframed as urgent agent risk.
    agent_path_present: bool = False
    # Counts of findings hidden from START_HERE / public output, by category:
    #   "tests"           — files in tests/, __tests__/, etc.
    #   "legacy"          — files in legacy/, archive/, deprecated/
    #   "migrations"      — files in migrations/
    #   "generated"       — files in generated/, gen/
    #   "medium_priority" — priority-tier findings with confidence != "high"
    # Used by the UI to render "+ N hidden — open Builder for full set".
    hidden_findings: dict[str, int] = field(default_factory=dict)
    # Vibe-coder entry view derived from this summary + findings. Quoted forward-
    # ref because StartHere lives in start_here.py which imports RepoSummary.
    start_here: "StartHere | None" = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _stripe_capability_from_method(method: str) -> str | None:
    """E.g. `stripe.Subscription.modify` → "subscriptions"."""
    parts = method.lower().split(".")
    if len(parts) < 2 or parts[0] != "stripe":
        return None
    return _STRIPE_CAPABILITY.get(parts[1])


# Filename hints that mean "this is an assembly point" — the class defined
# here is almost certainly the entry-point that orchestrates the agent.
# Matches lowercased basenames (including extension).
_FACTORY_FILE_HINTS = (
    "crew_factory", "crewfactory", "crew.py",
    "orchestrator", "dispatcher", "router",
    "controller", "supervisor",
    "main.py", "app.py", "graph.py", "workflow.py",
)

# Path fragments that mean "this code is not on the agent's runtime path":
# benchmarks, build/dev scripts, legacy directories, test setup/instrumentation,
# evaluation harnesses. Findings here are real but recommending them as the
# FIRST thing to wrap mis-prioritizes the dev's effort — they go fix dead code
# while the live orchestrator stays unguarded. Lowercased, matched as substring
# on the relative path.
_LOW_REACHABILITY_HINTS = (
    "/legacy/", "/deprecated/", "/archive/", "/archived/", "/old/",
    "/scripts/", "/script/", "/tools/", "/devtools/",
    "/benchmarks/", "/benchmark/", "/bench/",
    "/examples/", "/example/", "/demo/", "/demos/", "/samples/", "/sample/",
    "/research/", "/experiments/", "/notebooks/",
    "/tests/", "/__tests__/", "/test/", "/spec/", "/specs/",
    "/fixtures/", "/fixture/", "/mocks/", "/__mocks__/",
    "/test-setup-", "/test_setup_",
    # Added after the 10-repo benchmark — supabase, chatwoot, cal-diy,
    # medusa, erpnext all leaked findings from these path buckets that the
    # filter didn't recognize. The list is mechanically derived from the
    # benchmark misclassifications documented in
    # `.vibefixing-benchmark/ANALYSIS.md`.
    "/.circleci/", "/.github/workflows/", "/ci/",
    "/docs/", "/doc/", "/website/", "/site/",
    "/storybook/", "/.storybook/",
    "/playground/", "/playgrounds/",
    "/integration-tests/", "/integration_tests/", "/e2e/",
    "/template/", "/templates/", "/registry/", "/registries/",
    "/generated/", "/.generated/", "/__generated__/", "/codegen/",
    "/vendor/", "/third_party/", "/third-party/",
    # Migrations: behavior is gated by --include-migrations elsewhere; the
    # path hint here is the scaffolding fallback so a finding inside an
    # alembic / db migration file never lands as a wrap target.
    "/migrations/", "/migration/",
)

_LOW_REACHABILITY_FILENAME_HINTS = (
    "setup.py", "setup_", "_setup.py", "install.py", "_install.py",
    "_test.py", "_test.ts", "_tests.py", "_spec.py",
    ".test.", ".spec.", ".stories.",
    "conftest.py",
    # Benchmark additions:
    # - cal-diy used `*.integration-test.ts` for repository-layer tests; the
    #   wrap-target picker chose them over real handlers.
    # - chatwoot's CI SQL setup files leaked into the priority surface.
    # - Monaco editor bundles ship as `monaco.*.js` and aren't source.
    # - Vercel templates use `*.template.tsx` / `*.registry.tsx`.
    # - `.d.ts` declarations are types, not runtime code.
    ".integration-test.", ".integration_test.",
    ".e2e.", "_e2e.",
    ".template.", ".registry.",
    "monaco.", ".monaco.",
    ".d.ts",
)


def is_low_reachability_path(file: str) -> bool:
    """True when `file` lives on a path that doesn't run in production.

    Used to demote chokepoints, framework signals, and risks from the START_HERE
    "do this now" sections — without dropping the underlying findings, which
    remain available in FULL_REPORT.md for completeness. The classifier is
    conservative: ambiguous paths default to reachable.
    """
    path = "/" + file.lower().replace("\\", "/").lstrip("/")
    if any(hint in path for hint in _LOW_REACHABILITY_HINTS):
        return True
    name = path.rsplit("/", 1)[-1]
    return any(tok in name for tok in _LOW_REACHABILITY_FILENAME_HINTS)


def chokepoint_rank(cp: "AgentChokepoint") -> tuple[int, int, str]:
    """Lower rank = better wrap point.

    Ranking:
      0. Agent-class definitions in factory/orchestrator files — the actual
         class whose method the user will wrap.
      1. Tool registrations — each registration names a concrete tool.
      2. Agent-class definitions elsewhere.
      3. Framework imports — signal that a framework is in use, but the
         import line itself is not wrappable. Informational, not actionable.

    Chokepoints on low-reachability paths (test/setup/scripts/legacy) get +10
    on their tier so they sort below every reachable chokepoint without being
    dropped — they still appear in FULL_REPORT, just never as the FIRST place
    the dev should look.

    Tie-break by line then file so output is deterministic.
    """
    file_lower = cp.file.lower()
    is_factory = any(hint in file_lower for hint in _FACTORY_FILE_HINTS)
    if cp.kind == "agent-class" and is_factory:
        tier = 0
    elif cp.kind == "tool-registration":
        tier = 1
    elif cp.kind == "agent-class":
        tier = 2
    else:  # framework-import — signal, not a wrap point
        tier = 3
    if is_low_reachability_path(cp.file):
        tier += 10
    return (tier, cp.line, cp.file)


# Backward-compat alias — keep `_chokepoint_rank` for any internal caller that
# imported the underscore name. Public `chokepoint_rank` is the canonical one.
_chokepoint_rank = chokepoint_rank


def finding_wrap_rank(f: Finding) -> tuple[int, int, str]:
    """Wrap-priority ordering applied to a raw `Finding` (not a chokepoint
    derived in `build_summary`). Lets renderers that operate directly on
    findings (narrator's priority list) use the SAME ordering as the START_HERE
    chokepoint list — without that, START_HERE could recommend class A first
    while SUMMARY/FULL_REPORT recommend class B for the same repo.

    Mirrors `chokepoint_rank`'s tier system: factory-file agent-classes win,
    tool-registrations next, plain agent-classes after, framework-imports last.
    Adds +10 for low-reachability paths so test/setup/script chokepoints sort
    below every reachable one.
    """
    extra = f.extra or {}
    kind = str(extra.get("kind") or "")
    file_lower = f.file.lower()
    is_factory = any(hint in file_lower for hint in _FACTORY_FILE_HINTS)
    if kind == "agent-class" and is_factory:
        tier = 0
    elif kind == "tool-registration":
        tier = 1
    elif kind == "agent-class":
        tier = 2
    elif kind == "framework-import":
        tier = 3
    else:
        # `agent-method` and other kinds bucket between agent-class (2) and
        # framework-import (3) so methods-without-an-anchored-class don't
        # outrank class definitions.
        tier = 2
    if is_low_reachability_path(f.file):
        tier += 10
    return (tier, f.line, f.file)


def build_summary(
    findings: list[Finding],
    hidden_counts: dict[str, int] | None = None,
    root: Path | None = None,
) -> RepoSummary:
    frameworks_seen: Counter[str] = Counter()
    http_count = 0
    payments: dict[str, set[str]] = {}
    llms: set[str] = set()
    tables: Counter[str] = Counter()
    scheduled = 0
    # capability label → set of providers detected for that capability
    rwa: dict[str, set[str]] = {}
    # family (e.g. "rls-missing") → ordered list of "file:line" strings.
    # Filled from findings whose scanner tagged `extra.scope = "non-agent-security"`.
    db_hygiene: dict[str, list[str]] = {}
    db_hygiene_seen: set[tuple[str, str, int]] = set()
    chokepoints: list[AgentChokepoint] = []
    tools: list[str] = []
    tools_seen: set[str] = set()
    mcp_tools_list: list[str] = []
    mcp_tools_seen: set[str] = set()
    has_mcp_dispatcher = False
    has_langchain_framework = False
    skill_artifacts: list[tuple[str, str]] = []  # (kind, name)
    has_claude_md = False

    for f in findings:
        scanner = f.scanner
        extra = f.extra or {}

        # Adjacent web-app security (e.g. RLS missing on Supabase tables) —
        # routed to a separate bucket so it doesn't compete with agent
        # wrap-points for the headline. Scanner-agnostic: any finding can
        # opt in by tagging `extra["scope"] = "non-agent-security"`.
        if extra.get("scope") == "non-agent-security":
            family = str(extra.get("family") or scanner)
            key = (family, f.file, f.line)
            if key not in db_hygiene_seen:
                db_hygiene_seen.add(key)
                db_hygiene.setdefault(family, []).append(f"{f.file}:{f.line}")
            # Continue the loop — these findings still feed `tables` count
            # via the db-mutations branch below, which is fine; they just
            # don't drive any of the agent-supervision tiers.

        if scanner == "http-routes":
            http_count += 1
            fw = extra.get("framework")
            # Skip "unknown" — the http-routes scanner emits it when its
            # heuristics can't classify; it's noise in the summary.
            if isinstance(fw, str) and fw and fw.lower() != "unknown":
                frameworks_seen[fw] += 1

        elif scanner == "payment-calls":
            vendor = (extra.get("vendor") or "").lower()
            method = extra.get("method") or f.snippet
            if not vendor:
                continue
            cap = _stripe_capability_from_method(method) if vendor == "stripe" else None
            payments.setdefault(vendor, set())
            if cap:
                payments[vendor].add(cap)

        elif scanner == "llm-calls":
            method = (extra.get("method") or f.snippet or "").lower()
            sdk = extra.get("sdk") or method.split(".")[0] if method else None
            brand = _LLM_BRAND.get(str(sdk).lower()) if sdk else None
            if brand:
                llms.add(brand)

        elif scanner == "db-mutations":
            t = extra.get("table") or extra.get("model")
            if isinstance(t, str) and t:
                tables[t.lower()] += 1

        elif scanner == "cron-schedules":
            scheduled += 1

        elif scanner == "agent-orchestrators":
            kind = extra.get("kind", "")
            # Tool-registration findings carry the tool name in extra. Collect
            # them separately so the report can show "agent exposes N tools".
            if kind == "tool-registration":
                name = extra.get("tool_name") or ""
                if name and name not in tools_seen:
                    tools.append(name)
                    tools_seen.add(name)
            # Every HIGH-confidence agent-class finding is a candidate
            # chokepoint. Framework-import findings flow through at any
            # confidence — they're informational signals consumed by the
            # FrameworkSignal panel, not wrap targets. They were rated
            # `high` historically, which inflated the "real-world actions"
            # count and pushed pure-import lines onto the public landing.
            # The agent-class branch keeps the high-confidence-only filter
            # so generic shim/test classes don't sneak into wrap targets.
            is_chokepoint_candidate = (
                (f.confidence == "high" and kind == "agent-class")
                or kind == "framework-import"
            )
            if is_chokepoint_candidate:
                label = (
                    extra.get("class_name")
                    or extra.get("framework")
                    or extra.get("tool_name")
                    or "agent"
                )
                pmethods_raw = extra.get("parallel_methods") or ()
                pmethods = tuple(str(m) for m in pmethods_raw) if pmethods_raw else ()
                chokepoints.append(AgentChokepoint(
                    file=f.file, line=f.line, kind=kind, label=str(label),
                    parallel_methods=pmethods,
                ))
            if kind == "framework-import":
                fw_name = str(extra.get("framework", "")).lower()
                if "langchain" in fw_name or "langgraph" in fw_name:
                    has_langchain_framework = True

        elif scanner == "skills":
            kind = str(extra.get("kind") or "")
            name = str(extra.get("skill_name") or "")
            if kind:
                skill_artifacts.append((kind, name))
            if kind == "claude-md":
                has_claude_md = True

        elif scanner == "mcp-tools":
            kind = extra.get("kind", "")
            if kind == "mcp-tool":
                name = extra.get("tool_name") or ""
                if name and name != "?" and name not in mcp_tools_seen:
                    mcp_tools_list.append(name)
                    mcp_tools_seen.add(name)
            # The MCP dispatcher is the highest-leverage chokepoint for an MCP
            # server — wrapping it gates every tool. Promote it to chokepoint.
            if kind in ("mcp-dispatcher", "mcp-server-instance") and f.confidence == "high":
                chokepoints.append(AgentChokepoint(
                    file=f.file, line=f.line, kind=kind, label="mcp-dispatcher",
                ))
            if kind == "mcp-dispatcher":
                has_mcp_dispatcher = True

        elif scanner in _REAL_WORLD_CAPABILITY:
            capability = _REAL_WORLD_CAPABILITY[scanner]
            # `provider` for SDK-based scanners; `family` for fs-shell (fs-delete/
            # fs-write/shell-exec) so the summary reflects what kind of OS access.
            provider = extra.get("provider") or extra.get("family") or scanner
            rwa.setdefault(capability, set()).add(str(provider).lower())

    sensitive = sorted(t for t in tables if t in _SENSITIVE_TABLE_HINTS)
    all_tables = sorted(tables)
    payment_integrations = {k: sorted(v) for k, v in payments.items()}
    real_world_actions = {k: sorted(v) for k, v in rwa.items()}
    database_hygiene = {k: sorted(v) for k, v in db_hygiene.items()}

    # Pick the most common framework as primary; keep others as extras.
    primary_fw = [fw for fw, _ in frameworks_seen.most_common()]

    # Dedup chokepoints by (file, label) — Controller often matches both a
    # plain `class` regex and `export class` regex at the same line.
    seen_cp: set[tuple[str, str]] = set()
    unique_chokepoints: list[AgentChokepoint] = []
    for cp in chokepoints:
        key = (cp.file, cp.label)
        if key not in seen_cp:
            unique_chokepoints.append(cp)
            seen_cp.add(key)

    # Rank by wrap-value, not scan order: an actual Crew/Controller class in
    # a factory/orchestrator file is wrappable; a plain `from crewai import X`
    # in an agent definition file is signal but not a wrap-point. Put the
    # wrappable ones first so the report's "wrap one of these" list leads
    # with call-sites the reader can actually decorate.
    unique_chokepoints.sort(key=_chokepoint_rank)

    # Repo type is inferred from what the scanner actually saw. The UI uses
    # this to specialize the headline + remediation copy ("This is an MCP
    # server: wrap your tool registrations" beats the generic "we found
    # filesystem actions").
    #
    # `claude-skill` wins over MCP/langchain when the repo is dominated by
    # skill artifacts and has no significant code surface — that's a prompt
    # package, not an app, and the guidance is to audit content not to wrap
    # call-sites. Repos with BOTH skill files and a real backend (LLM calls,
    # payments, DB writes) keep their app-style classification.
    is_mcp = bool(mcp_tools_list) or has_mcp_dispatcher
    has_app_surface = bool(
        payment_integrations
        or all_tables
        or llms
        or http_count
        or unique_chokepoints
        or real_world_actions  # fs-shell, voice, email, messaging, calendar, media-gen
        or scheduled  # cron jobs imply a runtime, not a skill package
    )
    is_skill_repo = bool(skill_artifacts) and not has_app_surface and not is_mcp

    # A "chatbot-rag" is the shape we missed in v1: an HTTP server that calls
    # an LLM SDK directly and returns the model output to the user, without an
    # agent loop / tool dispatcher in between. cliocsbot is the canonical case
    # — Express + anthropic.messages.create, no LangChain, no MCP. The risk
    # there is conversational (LLM hallucinates an entity → user trusts it),
    # not action-shaped, so the priority ladder needs to invert vs. the
    # default agent-scanner one. Detection is structural: LLM provider seen,
    # no agent chokepoint class, and at least one HTTP route (rules out
    # CLI/script repos that happen to call OpenAI).
    is_chatbot_rag = (
        bool(llms)
        and not unique_chokepoints
        and http_count > 0
    )

    if is_skill_repo:
        repo_type: str | None = "claude-skill"
    elif is_mcp and has_langchain_framework:
        repo_type = "mcp-server+langchain"
    elif is_mcp:
        repo_type = "mcp-server"
    elif has_langchain_framework:
        repo_type = "langchain-agent"
    elif is_chatbot_rag:
        repo_type = "chatbot-rag"
    else:
        repo_type = None

    # Framework-vs-app — only computed when caller passed a root path.
    # Pure-findings callers (tests, in-memory pipelines) get "unknown".
    if root is not None:
        # Count chokepoints whose file path lives in /agents/ or similar —
        # langchain has 60+ of these and zero deployed runtime, the
        # ratio that flips the heuristic to framework.
        chokepoints_in_agent_path = sum(
            1 for cp in unique_chokepoints
            if any(h in cp.file.lower() for h in ("/agents/", "/agent/", "/orchestrator/"))
        )
        repo_kind = detect_repo_kind(
            root,
            http_routes=http_count,
            chokepoints_in_agent_path=chokepoints_in_agent_path,
        )
    else:
        repo_kind = "unknown"

    return RepoSummary(
        frameworks=primary_fw,
        http_routes=http_count,
        payment_integrations=payment_integrations,
        llm_providers=sorted(llms),
        real_world_actions=real_world_actions,
        database_hygiene=database_hygiene,
        agent_chokepoints=unique_chokepoints,
        agent_tools=tools,
        mcp_tools=mcp_tools_list,
        db_tables_touched=all_tables,
        sensitive_tables=sensitive,
        scheduled_jobs=scheduled,
        total_findings=len(findings),
        one_liner=_one_liner(
            primary_fw, payment_integrations, llms, real_world_actions, sensitive,
            has_agent=bool(unique_chokepoints or tools),
            repo_type=repo_type,
            mcp_tool_count=len(mcp_tools_list),
            skill_count=len(skill_artifacts),
            has_claude_md=has_claude_md,
        ),
        repo_type=repo_type,
        repo_kind=repo_kind,
        # An LLM provider, an agent-class chokepoint, or a registered agent
        # tool counts as an active agent path. The renderer uses this to
        # decide whether priority cards apply or the report is just a
        # capability inventory.
        agent_path_present=bool(
            llms
            or any(cp.kind == "agent-class" for cp in unique_chokepoints)
            or tools
        ),
        hidden_findings=dict(hidden_counts or {}),
    )


# Scanner-emitted framework keys → canonical brand casing. Produces
# prose-readable names in the headline ("Next.js" not "next-app-router").
_FRAMEWORK_LABELS = {
    "fastapi": "FastAPI", "flask": "Flask", "django": "Django",
    "starlette": "Starlette", "aiohttp": "aiohttp", "quart": "Quart",
    "tornado": "Tornado", "sanic": "Sanic", "bottle": "Bottle",
    "pyramid": "Pyramid",
    "express": "Express", "nest": "NestJS", "nestjs": "NestJS",
    "koa": "Koa", "hono": "Hono", "fastify": "Fastify",
    "next": "Next.js", "next-app-router": "Next.js", "next-pages": "Next.js",
    "remix": "Remix", "sveltekit": "SvelteKit", "astro": "Astro",
}

_RWA_PRIORITY = [
    "voice / telephony",
    "email sends",
    "messaging (slack / discord / sms)",
    "filesystem / shell exec",
    "generative media",
    "calendar events",
]


def _en_join(items: list[str]) -> str:
    """Natural English join: ['a','b','c'] → 'a, b and c'."""
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return f"{items[0]} and {items[1]}"
    return f"{', '.join(items[:-1])} and {items[-1]}"


def _one_liner(
    frameworks: list[str],
    payments: dict[str, list[str]],
    llms: set[str],
    real_world_actions: dict[str, list[str]],
    sensitive_tables: list[str],
    *,
    has_agent: bool = False,
    repo_type: str | None = None,
    mcp_tool_count: int = 0,
    skill_count: int = 0,
    has_claude_md: bool = False,
) -> str:
    """Human-readable headline, derived — not LLM-written."""
    fw_label: str | None = None
    if frameworks:
        key = frameworks[0].lower()
        fw_label = _FRAMEWORK_LABELS.get(key, frameworks[0].capitalize())

    # Specialized headlines per repo_type — these are the cases where the
    # generic "a repo with X and Y" framing buries what actually matters.
    if repo_type == "claude-skill":
        if skill_count > 1:
            return (
                f"a **Claude Code skill / plugin** distributing "
                f"**{skill_count}** instruction file(s) Claude reads at runtime"
            )
        if has_claude_md:
            return "a **Claude Code skill / plugin** with a repo-wide CLAUDE.md"
        return "a **Claude Code skill / plugin** distributing instructions Claude reads at runtime"

    if repo_type == "mcp-server" or repo_type == "mcp-server+langchain":
        tools_part = (
            f"exposing **{mcp_tool_count} tools** to the LLM client"
            if mcp_tool_count > 0
            else "exposing tools to the LLM client"
        )
        if real_world_actions:
            caps = sorted(real_world_actions.keys())
            ordered = [c for c in _RWA_PRIORITY if c in caps] + [c for c in caps if c not in _RWA_PRIORITY]
            extra = f" with {ordered[0]}"
        else:
            extra = ""
        return f"an **MCP server** {tools_part}{extra}"

    if repo_type == "langchain-agent":
        feature_extra = ""
        if real_world_actions:
            caps = sorted(real_world_actions.keys())
            ordered = [c for c in _RWA_PRIORITY if c in caps] + [c for c in caps if c not in _RWA_PRIORITY]
            feature_extra = f" with {ordered[0]}"
        return f"a **langchain agent**{feature_extra}"

    if repo_type == "chatbot-rag":
        # The framing has to make the *conversation* the headline, not the
        # framework or the side-channel actions. A reader who sees "an Express
        # app with email sends" reaches for SPF/DKIM thinking; a reader who
        # sees "a chatbot answering through Claude" reaches for what the model
        # might say. That switch is the entire point of the repo_type.
        provider = sorted(llms)[0] if llms else "an LLM"
        base = f"a **{fw_label}** chatbot" if fw_label else "a chatbot"
        if sensitive_tables:
            return f"{base} answering from your customer data via {provider}"
        return f"{base} answering through {provider}"

    features: list[str] = []

    # Agent orchestration is the most important feature when present —
    # calling it out changes the reader's whole interpretation of the rest
    # of the surface.
    if has_agent:
        features.append("agent orchestrator")

    if real_world_actions:
        caps = sorted(real_world_actions.keys())
        ordered = [c for c in _RWA_PRIORITY if c in caps] + [c for c in caps if c not in _RWA_PRIORITY]
        features.append(f"real-world actions ({', '.join(ordered[:2])})")

    if payments:
        vendors = sorted(v.capitalize() for v in payments.keys())
        features.append(f"payments via {_en_join(vendors)}")

    if llms and not has_agent:  # "LLM" is implied if we already said "agent"
        features.append("LLM agents")
    elif llms:
        features.append("explicit LLM calls")

    if sensitive_tables:
        features.append("customer data writes")

    if not fw_label and not features:
        return "no critical integrations detected"
    if fw_label and features:
        return f"a **{fw_label}** app with {_en_join(features)}"
    if fw_label:
        return f"a **{fw_label}** app"
    return f"a repo with {_en_join(features)}"


def render_markdown(summary: RepoSummary) -> str:
    """Markdown block that goes at the top of report.md."""
    lines: list[str] = ["## What this repo is", ""]

    if summary.frameworks:
        fw_str = " + ".join(f"**{fw}**" for fw in summary.frameworks)
        lines.append(f"Stack: {fw_str} ({summary.http_routes} HTTP routes).")
    elif summary.http_routes:
        lines.append(f"HTTP surface: {summary.http_routes} routes (framework not recognized).")
    else:
        lines.append("No HTTP endpoints detected.")
    lines.append("")

    if summary.payment_integrations:
        parts: list[str] = []
        for vendor, caps in summary.payment_integrations.items():
            v = vendor.capitalize()
            if caps:
                parts.append(f"**{v}** ({', '.join(caps)})")
            else:
                parts.append(f"**{v}**")
        lines.append(f"Payment integrations: {', '.join(parts)}.")
    else:
        lines.append("No payment SDKs detected.")

    if summary.llm_providers:
        lines.append(f"LLM providers: {', '.join(f'**{p}**' for p in summary.llm_providers)}.")
    else:
        lines.append("No LLM SDKs detected.")

    if summary.real_world_actions:
        parts: list[str] = []
        for capability, providers in summary.real_world_actions.items():
            providers_str = ", ".join(providers)
            parts.append(f"**{capability}** ({providers_str})")
        lines.append(f"Real-world actions the agent can take: {'; '.join(parts)}.")

    if summary.agent_chokepoints or summary.agent_tools:
        lines.append("")
        lines.append("### 🎯 Agent orchestration detected")
        lines.append("")

        # Split by kind: wrappable call-sites (classes in factory files,
        # tool registrations) vs. pure signal (framework imports).
        wrappable = [cp for cp in summary.agent_chokepoints
                     if cp.kind in ("agent-class", "tool-registration")]
        imports = [cp for cp in summary.agent_chokepoints if cp.kind == "framework-import"]

        if wrappable:
            lines.append("**Wrap here** — a single `@supervised('tool_use')` at one of these points covers every tool the agent uses (current and future):")
            for cp in wrappable[:5]:
                file_short = cp.file.rsplit("/", 2)
                file_display = "/".join(file_short[-2:]) if len(file_short) > 1 else cp.file
                kind_label = "class" if cp.kind == "agent-class" else "tool"
                lines.append(f"- `{file_display}:{cp.line}` — {kind_label} `{cp.label}`")
            if len(wrappable) > 5:
                lines.append(f"- _+{len(wrappable) - 5} more_")
            lines.append("")

        if imports:
            frameworks_seen = sorted({cp.label for cp in imports})
            fw_str = ", ".join(f"`{f}`" for f in frameworks_seen)
            lines.append(
                f"**Framework detected:** {fw_str} — imports in {len(imports)} file(s). "
                "Imports alone aren't wrap points; look for the `Crew()` / `AgentExecutor()` / "
                "`StateGraph()` that uses them (that's the one you wrap)."
            )
            lines.append("")

        if summary.agent_tools:
            tools_str = ", ".join(f"`{t}`" for t in summary.agent_tools[:10])
            more = f" _+{len(summary.agent_tools) - 10} more_" if len(summary.agent_tools) > 10 else ""
            lines.append(f"**Tools the agent exposes:** {tools_str}{more}.")
            lines.append("")
        lines.append(
            "> _The supervisor receives the tool name on every decision → you can "
            "write per-tool policies without touching the agent code. "
            "See `runtime-supervisor/combos/agent-orchestrator.md` for the playbook._"
        )

    if summary.scheduled_jobs:
        lines.append(f"Scheduled jobs: {summary.scheduled_jobs} crons / scheduled tasks.")

    lines.append("")
    if summary.sensitive_tables:
        lines.append(
            "Tables with sensitive naming (users/orders/customers/...): "
            + ", ".join(f"`{t}`" for t in summary.sensitive_tables)
            + "."
        )
    elif summary.db_tables_touched:
        lines.append(f"Tables touched: {len(summary.db_tables_touched)}.")

    lines.append("")
    lines.append(f"In one line: {summary.one_liner}.")
    lines.append("")
    return "\n".join(lines)


def render_cli_stdout(summary: RepoSummary) -> list[str]:
    """Short lines for the CLI, printed before the tier summary. Extra lines
    when the repo has real-world actions or an agent orchestrator — always
    surface the agentic signal before the tier counts so the reader sees
    the headline before scrolling."""
    out: list[str] = []
    fw = " + ".join(summary.frameworks) if summary.frameworks else "framework no reconocido"
    pay = (
        ", ".join(f"{k} ({', '.join(v)})" if v else k for k, v in summary.payment_integrations.items())
        if summary.payment_integrations else "—"
    )
    llm = ", ".join(summary.llm_providers) if summary.llm_providers else "—"
    out.append(f"  stack: {fw}  ·  HTTP routes: {summary.http_routes}")
    out.append(f"  payments: {pay}")
    out.append(f"  LLM: {llm}  ·  crons: {summary.scheduled_jobs}")
    if summary.real_world_actions:
        # Collapsed one-liner: "voice (twilio, elevenlabs), calendar (google)"
        parts = [
            f"{cap.split(' ')[0]} ({', '.join(providers)})"
            for cap, providers in summary.real_world_actions.items()
        ]
        out.append(f"  actions: {' · '.join(parts)}")
    if summary.agent_tools or summary.agent_chokepoints:
        # 🎯 headline — agent orchestration is the highest-leverage signal.
        # Distinguish "wrap here" points from "framework import" signal so the
        # CLI reader doesn't think a `from crewai import X` is a wrap point.
        bits: list[str] = []
        wrappable = [cp for cp in summary.agent_chokepoints
                     if cp.kind in ("agent-class", "tool-registration")]
        imports = [cp for cp in summary.agent_chokepoints if cp.kind == "framework-import"]
        if wrappable:
            bits.append(f"wrap: {wrappable[0].label}")
        if imports:
            frameworks_seen = sorted({cp.label for cp in imports})
            bits.append(f"framework: {', '.join(frameworks_seen)}")
        if summary.agent_tools:
            tools_preview = ", ".join(summary.agent_tools[:4])
            more = f" +{len(summary.agent_tools) - 4}" if len(summary.agent_tools) > 4 else ""
            bits.append(f"{len(summary.agent_tools)} tools ({tools_preview}{more})")
        out.append(f"  🎯 agent: {' · '.join(bits)}")
    return out
