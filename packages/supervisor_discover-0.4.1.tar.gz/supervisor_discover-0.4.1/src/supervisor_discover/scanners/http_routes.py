"""Find HTTP route handlers.

Python: ast walker looking for Flask (`@app.route`), FastAPI (`@router.post/get/put/delete`),
Django (`urls.py` patterns with path() calls).

TS/JS: regex for Next.js API routes (files under `app/**/route.ts` or `pages/api/**`), Express
app.get/post handlers.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

from ..findings import Finding
from ._utils import parse_python, python_files, safe_read, ts_js_files

_PY_HTTP_DECORATORS = {"route", "get", "post", "put", "patch", "delete"}
_TS_EXPRESS_PATTERN = re.compile(r"\b(?:app|router)\.(?:get|post|put|patch|delete)\s*\(", re.IGNORECASE)
_TS_NEXT_API_PATH = re.compile(r"(?:app/.*?/route\.(?:ts|js)|pages/api/.+\.(?:ts|js))$")

# Next.js Server Actions: a file whose first non-blank, non-comment line is
# `'use server'` (or "use server"), with optional trailing semicolon. Every
# `export (async )?function` underneath becomes an HTTP-callable server action
# the framework wires up on its own — no `route.ts`, no decorator. The
# directive turns plain functions into a public POST surface.
_TS_USE_SERVER_DIRECTIVE = re.compile(
    r"""^[\s]*['"]use\s+server['"]\s*;?\s*$""",
)
_TS_EXPORTED_FUNCTION = re.compile(
    r"""^export\s+(?:async\s+)?function\s+(\w+)\s*\(""",
    re.MULTILINE,
)


def _scan_python(root: Path) -> list[Finding]:
    findings: list[Finding] = []
    for path in python_files(root):
        text = safe_read(path)
        if text is None:
            continue
        tree = parse_python(text)
        if tree is None:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for deco in node.decorator_list:
                name = _decorator_name(deco)
                if not name:
                    continue
                last = name.rsplit(".", 1)[-1]
                if last in _PY_HTTP_DECORATORS and ("route" in name or "." in name):
                    # Point at the decorator line so file:line highlights `@app.get(...)`,
                    # not the function body below it. Reading the route without its
                    # decorator is useless for review.
                    findings.append(Finding(
                        scanner="http-routes",
                        file=str(path),
                        line=deco.lineno,
                        snippet=f"@{name}  # {node.name}",
                        suggested_action_type="other",
                        confidence="medium",
                        rationale=f"Python HTTP handler `{node.name}` decorated with `@{name}`. "
                                  "The supervisor should gate this route if it performs state-changing operations.",
                        extra={"function": node.name, "framework": _guess_framework(name)},
                    ))
                    break
    return findings


def _decorator_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Call):
        node = node.func
    if isinstance(node, ast.Attribute):
        parts: list[str] = []
        cur: ast.AST | None = node
        while isinstance(cur, ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        if isinstance(cur, ast.Name):
            parts.append(cur.id)
            return ".".join(reversed(parts))
    if isinstance(node, ast.Name):
        return node.id
    return None


def _guess_framework(name: str) -> str:
    if "app.route" in name:
        return "flask"
    if "router." in name or "app.get" in name or "app.post" in name:
        return "fastapi"
    return "unknown"


def _is_use_server_module(text: str) -> bool:
    """True when the first significant line of `text` is `'use server'`.

    Skips blank lines and `//` line comments at the top of the file. Block
    comments (`/* */`) are deliberately ignored — Next.js itself treats the
    directive the same way, so we shouldn't be stricter than the framework.
    """
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("//"):
            continue
        return bool(_TS_USE_SERVER_DIRECTIVE.match(raw))
    return False


def _scan_ts_js(root: Path) -> list[Finding]:
    findings: list[Finding] = []
    for path in ts_js_files(root):
        rel = str(path).replace(str(root) + "/", "")
        is_next_api = bool(_TS_NEXT_API_PATH.search(rel))
        text = safe_read(path)
        if text is None:
            continue

        # Next.js Server Actions: each exported function under a `'use server'`
        # module is its own POST endpoint. We tag the directive line plus each
        # exported function so the wrap-target ranker can point at concrete
        # handlers instead of just "this file".
        if _is_use_server_module(text):
            for m in _TS_EXPORTED_FUNCTION.finditer(text):
                line = text[: m.start()].count("\n") + 1
                fn = m.group(1)
                findings.append(Finding(
                    scanner="http-routes",
                    file=str(path),
                    line=line,
                    snippet=m.group(0).rstrip("("),
                    suggested_action_type="other",
                    confidence="high",
                    rationale=(
                        f"Next.js server action `{fn}` — the `'use server'` "
                        "directive at the top of the file makes every export "
                        "a public POST endpoint. Wrap with @supervised(...) "
                        "matching what the function actually does (account_change "
                        "for profile mutations, payment for Stripe calls)."
                    ),
                    extra={"function": fn, "framework": "next-server-action"},
                ))

        if is_next_api:
            # Next.js app router: export async function GET/POST/... at top level
            for m in re.finditer(r"export\s+(?:async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE)\b", text):
                line = text[: m.start()].count("\n") + 1
                findings.append(Finding(
                    scanner="http-routes",
                    file=str(path),
                    line=line,
                    snippet=m.group(0),
                    suggested_action_type="other",
                    confidence="high",
                    rationale=f"Next.js API route handler {m.group(1)} at `{rel}`. "
                              "If this route mutates state or calls external services, it needs supervision.",
                    extra={"method": m.group(1), "framework": "next-app-router"},
                ))

        for m in _TS_EXPRESS_PATTERN.finditer(text):
            line = text[: m.start()].count("\n") + 1
            findings.append(Finding(
                scanner="http-routes",
                file=str(path),
                line=line,
                snippet=m.group(0).rstrip("("),
                suggested_action_type="other",
                confidence="medium",
                rationale="Express/Fastify-style HTTP handler — verify whether it does a mutation that needs a guard.",
                extra={"framework": "express"},
            ))
    return findings


def scan(root: Path) -> list[Finding]:
    return _scan_python(root) + _scan_ts_js(root)
