"""Emit the runtime-supervisor/ output directory."""
from __future__ import annotations

import json
import re
import shutil
from collections import Counter
from dataclasses import replace
from pathlib import Path
from typing import Any

import yaml

from .classifier import TIER_ORDER, Tier, group_by_action_type, group_by_risk_tier, tier_of
from .combo_playbooks import render_index as render_combos_index, render_playbook
from .combo_state import (
    filter_reported as filter_resolved_combos,
    load as load_combo_state,
    state_path_for,
)
from .combos import detect_combos, render_markdown as render_combos_md
from .findings import Finding
from .narrator import render_summary as render_summary_email
from .prompts import prompt_for, repo_relative_path
from .rollout import render_rollout_md
from .start_here import build_start_here, render_start_here_md
from .summary import build_summary, render_markdown as render_summary_md
from .templates import (
    CHATBOT_SCOPE_GUARD_EXAMPLE,
    CI_WORKFLOW,
    ENV_EXAMPLE,
    PY_STUB,
    REPORT_HEADER,
    TIER_COPY,
    TS_STUB,
    py_payload_body_for,
    ts_payload_body_for,
)

# Where the supervisor's own seed policies live — the generator copies them
# verbatim so the customer starts with the same baseline the supervisor
# ships with.
_POLICY_SOURCE_DIR = Path(__file__).resolve().parents[4] / "packages" / "policies"


def _safe_filename(path: str) -> str:
    rel = path.rsplit("/", 1)[-1]
    return re.sub(r"[^a-zA-Z0-9._-]", "_", rel)


_STABLE_ID_RE = re.compile(r"stable_id:\s*([a-f0-9]+|\(legacy\))")


def _read_embedded_stable_id(stub: Path) -> str | None:
    """Parse the `stable_id: <hash>` line from a stub's docstring/header.

    Returns None when the stub doesn't carry an id (older format) or
    can't be read. Legacy stubs without an id pass through unchanged —
    they're invisible to staleness detection but the user can still
    delete them by hand.
    """
    try:
        text = stub.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None
    m = _STABLE_ID_RE.search(text[:1000])  # only scan the header
    if m is None:
        return None
    return m.group(1)


def _rename_stale_stubs(stubs_py: Path, stubs_ts: Path, findings: list[Finding]) -> int:
    """Walk pre-existing stubs in `stubs_py` / `stubs_ts`, rename ones whose
    embedded `stable_id` no longer matches a current finding to
    `*.stale.stub.{py,ts}`. Already-stale stubs are left alone (idempotent).

    Returns the number of stubs renamed in this pass.
    """
    current_ids = {f.id for f in findings if f.id}
    stale = 0
    for stubs_dir, ext in ((stubs_py, ".stub.py"), (stubs_ts, ".stub.ts")):
        if not stubs_dir.is_dir():
            continue
        for stub in stubs_dir.glob(f"*{ext}"):
            # Skip already-renamed stale stubs.
            if stub.name.endswith(f".stale{ext}"):
                continue
            embedded = _read_embedded_stable_id(stub)
            if embedded is None or embedded == "(legacy)":
                continue
            if embedded in current_ids:
                continue
            stale_path = stub.parent / stub.name.replace(ext, f".stale{ext}")
            try:
                stub.rename(stale_path)
                stale += 1
            except OSError:
                continue
    return stale


def _py_payload_for_finding(f: Finding) -> tuple[str, str]:
    """Return `(payload_args, payload_body)` for `f`.

    For agent-class findings on Python files we can do better than the
    generic per-scanner template: open the AST, find the dispatcher
    method, and write a payload extractor with the method's actual
    parameter names — both in the lambda's arg list AND in the body —
    so the dev doesn't have to translate `raw_kwargs['amount']` from a
    generic shape to the real signature.

    Falls back to `(*args, **kwargs)` + the existing per-scanner template
    when we can't resolve a dispatcher (non-Python file, missing class,
    etc.).
    """
    extra = f.extra or {}
    if (
        f.scanner == "agent-orchestrators"
        and extra.get("kind") == "agent-class"
        and f.file.endswith((".py", ".ipynb"))
    ):
        from .wrap_signature import (
            extract_dispatcher_signature,
            render_lambda_args,
            render_payload_body_from_signature,
        )

        class_name = str(extra.get("class_name") or "")
        if class_name:
            parallel = tuple(extra.get("parallel_methods") or ())
            sig = extract_dispatcher_signature(
                f.file, class_name,
                target_line=f.line,
                parallel_methods=parallel,
            )
            if sig is not None:
                body = render_payload_body_from_signature(sig)
                if body:
                    return render_lambda_args(sig), body
    return "*args, **kwargs", py_payload_body_for(f.scanner)


def generate(
    findings: list[Finding],
    out_dir: Path,
    repo_root: Path | None = None,
    *,
    include_resolved: bool = False,
    hidden_counts: dict[str, int] | None = None,
) -> None:
    """Emit the runtime-supervisor/ output directory.

    `repo_root`, when provided, becomes the basename of the FULL_REPORT title.
    `include_resolved=True` bypasses the Nivel 3 state filter (so the scan
    shows combos even after they were marked `resolved`). Useful for audit
    or when reviewing what was previously fixed. `hidden_counts`, when
    provided, is folded into RepoSummary.hidden_findings so the per-category
    counter (tests/legacy/migrations/generated) reaches the artifacts.
    """
    out_dir.mkdir(parents=True, exist_ok=True)

    summary = build_summary(findings, hidden_counts=hidden_counts, root=repo_root)
    start_here = build_start_here(summary, findings, repo_root=repo_root)
    # Stitch start_here back into the summary so the API + JSON dump carry it.
    summary = replace(summary, start_here=start_here)
    repo_name = repo_root.name if repo_root else None

    # findings.json — wrapped now: top-level "findings" + "repo_summary".
    # CI consumers that diff findings[] keep working; new consumers can read
    # repo_summary for the briefing data.
    #
    # Each serialized finding gets a `tier` field derived via classifier.tier_of,
    # so direct artifact consumers (UI, exports, tooling) don't have to recompute
    # it from `scanner` + `extra.table` themselves. Without this, the 10-repo
    # benchmark surfaced consumers reading `findings.json` and reporting
    # `priority=0` because the tier was never embedded.
    sorted_findings = sorted(
        [{**f.to_dict(), "tier": tier_of(f)} for f in findings],
        key=lambda d: (d["file"], d["line"], d["scanner"]),
    )
    payload: dict[str, Any] = {
        # Schema version: increment when the on-disk shape changes. CI
        # consumers (the future `supervisor-discover diff` command) read it
        # to know whether their parser still applies. 1.1 adds `tier` per
        # finding (was 1.0, computed post-hoc by the API).
        "schema_version": "1.1",
        "repo_summary": summary.to_dict(),
        "findings": sorted_findings,
    }
    (out_dir / "findings.json").write_text(json.dumps(payload, indent=2) + "\n")

    # FULL_REPORT.md (was report.md) — the deeper read. Mandable security
    # review goes first (the curated wrap/prod/confirm/discard buckets that
    # used to live in SUMMARY.md), then critical combos, then guardrails,
    # then the tier-by-risk table.
    by_type = Counter(f.suggested_action_type for f in findings)
    tier_summary_table, headline_note = _tier_summary(findings)
    # Nivel 3: si hay state file con combos resueltos, se suprimen del output
    # a menos que el caller pase include_resolved=True (flag --show-resolved).
    # Pass `repo_root` so combos get refined with import-graph
    # reachability — combos whose two findings live in modules without
    # any import path between them get downgraded to `low`. Without
    # `repo_root` (legacy callers) the behaviour is unchanged.
    raw_combos = detect_combos(findings, root=repo_root)
    combo_states = load_combo_state(state_path_for(out_dir))
    combos = filter_resolved_combos(
        raw_combos, combo_states, include_resolved=include_resolved
    )
    full_report = render_summary_email(summary, findings, combos, repo_name=repo_name)
    full_report += "\n---\n\n"
    full_report += render_summary_md(summary)
    if combos:
        full_report += "\n---\n\n"
        full_report += render_combos_md(combos)
    full_report += _render_applicable_guardrails(findings)
    suppression_block = _render_suppressed_section(findings, repo_root)
    if suppression_block:
        full_report += "\n---\n\n"
        full_report += suppression_block
    full_report += "\n---\n\n"
    full_report += REPORT_HEADER.format(
        total=len(findings),
        tier_summary_table=tier_summary_table,
        headline_note=headline_note,
    )
    full_report += _render_by_risk_tier(
        findings,
        agent_path_present=summary.agent_path_present,
    )
    (out_dir / "FULL_REPORT.md").write_text(full_report)

    # ROLLOUT.md — tailored to the repo's stack + surface + tier counts.
    (out_dir / "ROLLOUT.md").write_text(render_rollout_md(summary, findings))

    # START_HERE.md — vibe-coder entry point, replaces SUMMARY.md.
    # Answers: where to wrap first / what this repo can do / top risks /
    # what to ignore. The rich review lives in FULL_REPORT.md.
    (out_dir / "START_HERE.md").write_text(render_start_here_md(start_here))

    # policies — copy from supervisor's source dir for live action types
    policies_dir = out_dir / "policies"
    policies_dir.mkdir(exist_ok=True)
    for action_type in sorted(set(by_type.keys()) - {"other"}):
        src = _POLICY_SOURCE_DIR / f"{action_type}.base.v1.yaml"
        dst = policies_dir / f"{action_type}.base.v1.yaml"
        if src.exists():
            shutil.copyfile(src, dst)
        else:
            dst.write_text(_policy_template(action_type))

    # scope_guard policy ships with chatbot-rag repos — the dominant risk
    # there is the LLM mentioning entities outside the user's scope, which
    # the action_type policies don't cover. Customers wire the helper at
    # `supervisor_guards.scope.assert_entities_in_scope` into their wrapper
    # to populate `entities_mentioned` + `allowed_entities` in the payload.
    if summary.repo_type == "chatbot-rag":
        scope_src = _POLICY_SOURCE_DIR / "scope_guard.base.v1.yaml"
        if scope_src.exists():
            shutil.copyfile(scope_src, policies_dir / "scope_guard.base.v1.yaml")

    # Repo-specific tool_use policy seeded from the repo's action enums.
    # The reviewer flagged on castor-1 that the generic policy referenced
    # `'system.exec'` / `'fs.delete'` — names that never matched because
    # the repo uses `class AgentAction(str, Enum)` with values like
    # `CREATE_INCIDENT`, `DISPATCH_SLA_ALERT`. Now we extract those values
    # and emit `tool_use.<repo>.v1.yaml` with them pre-populated.
    if repo_root is not None:
        from .policy_extractors import extract_action_enums, render_repo_action_policy

        action_enums = extract_action_enums(repo_root)
        if action_enums:
            repo_policy = render_repo_action_policy(action_enums, repo_root.name)
            if repo_policy is not None:
                (policies_dir / f"tool_use.{repo_root.name}.v1.yaml").write_text(repo_policy)

    # combos/ — Nivel 1 remediation playbooks per detected combo.
    # Writes one markdown per combo + an index README. Combo-specific
    # policies also land in policies/ (created above) so the user can
    # copy-paste them into the supervisor without extra ceremony.
    if combos:
        combos_dir = out_dir / "combos"
        combos_dir.mkdir(exist_ok=True)
        for combo in combos:
            pb = render_playbook(combo, findings, summary)
            (combos_dir / f"{combo.id}.md").write_text(pb.markdown)
            if pb.policy_yaml:
                (policies_dir / f"tool_use.{combo.id}.v1.yaml").write_text(pb.policy_yaml)
        (combos_dir / "README.md").write_text(render_combos_index(combos))

    # stubs (one per call-site of high-confidence payment/LLM findings)
    stubs_py = out_dir / "stubs" / "py"
    stubs_ts = out_dir / "stubs" / "ts"
    stubs_py.mkdir(parents=True, exist_ok=True)
    stubs_ts.mkdir(parents=True, exist_ok=True)
    orphan_count = 0
    already_gated_count = 0
    # Stale stub detection: walk pre-existing stubs in the output dir,
    # parse their embedded `stable_id`, and rename ones whose id is no
    # longer in the current findings list. The reviewer flagged on
    # supervincent that 19 stubs were marked `D` in git status because
    # the dev applied changes manually and the source files moved — we
    # never told them which old stubs were now pointing at moved code.
    stale_count = _rename_stale_stubs(stubs_py, stubs_ts, findings)
    for f in findings:
        if f.confidence == "low" or f.suggested_action_type == "other":
            continue
        # Skip stubs for findings whose source file has been deleted between
        # scans — emitting a stub referencing a dead path is just orphan
        # state that drifts away from reality. Symptom in real repos:
        # `stubs/py/payments_L131.stub.py` after the original `payments.py:131`
        # was removed in a refactor, scanner re-run never cleaned it up.
        try:
            if not Path(f.file).exists():
                orphan_count += 1
                continue
        except OSError:
            orphan_count += 1
            continue
        # Skip stubs for findings already wrapped by @supervised / guarded(...)
        # — gate_coverage marked them, no need to ship a stub recommending
        # the wrap a second time.
        if (f.extra or {}).get("already_gated"):
            already_gated_count += 1
            continue
        stub_name = f"{_safe_filename(f.file)}_L{f.line}"
        if f.file.endswith(".py"):
            payload_args, payload_body = _py_payload_for_finding(f)
            (stubs_py / f"{stub_name}.stub.py").write_text(
                PY_STUB.format(
                    original_file=f.file, line=f.line, snippet=f.snippet,
                    action_type=f.suggested_action_type, rationale=f.rationale,
                    payload_args=payload_args,
                    payload_body=payload_body,
                    stable_id=f.id or "(legacy)",
                )
            )
        else:
            (stubs_ts / f"{stub_name}.stub.ts").write_text(
                TS_STUB.format(
                    original_file=f.file, line=f.line, snippet=f.snippet,
                    action_type=f.suggested_action_type, rationale=f.rationale,
                    ts_payload_body=ts_payload_body_for(f.scanner),
                    stable_id=f.id or "(legacy)",
                )
            )
    # Chatbot-rag repos get a one-time scope-guard example alongside the
    # per-call-site stubs. The per-call stubs cover the LLM-call wrapper;
    # this file shows the response-side check using assert_entities_in_scope.
    # Together they're the two halves of the Andrea-class regression.
    if summary.repo_type == "chatbot-rag":
        (stubs_py / "chatbot_scope_guard_example.stub.py").write_text(
            CHATBOT_SCOPE_GUARD_EXAMPLE
        )

    # Drop a one-line README in stubs/ to record the housekeeping counts.
    if orphan_count or already_gated_count or stale_count:
        readme_lines = ["# stubs/", ""]
        if orphan_count:
            readme_lines.append(
                f"_Skipped {orphan_count} stub(s): the source file no longer "
                "exists (orphan finding from a stale scan)._"
            )
        if already_gated_count:
            readme_lines.append(
                f"_Skipped {already_gated_count} stub(s): the call-site is "
                "already wrapped by `@supervised` / `guarded(...)`._"
            )
        if stale_count:
            readme_lines.append(
                f"_Renamed {stale_count} stub(s) to `*.stale.stub.{{py,ts}}`: "
                "the underlying call moved or was deleted between scans. "
                "Review and remove if no longer relevant._"
            )
        readme_lines.append("")
        readme_lines.append("Open `runtime-supervisor/FULL_REPORT.md` for the full set.")
        (out_dir / "stubs" / "README.md").write_text("\n".join(readme_lines) + "\n")

    # .env.example
    (out_dir / ".env.example").write_text(ENV_EXAMPLE)

    # CI workflow
    ci_dir = out_dir / ".github" / "workflows"
    ci_dir.mkdir(parents=True, exist_ok=True)
    (ci_dir / "runtime-supervisor.yml").write_text(CI_WORKFLOW)


# OWASP LLM Top 10 coverage per action_type. The supervisor's threat
# pipeline runs these detectors on every evaluate() call regardless of
# action_type, but this table says which are MOST relevant — what the
# reader should care about for each kind of action.
_OWASP_PER_ACTION_TYPE: dict[str, list[tuple[str, str]]] = {
    "refund": [
        ("LLM01", "Prompt injection — amount or reason can be attacker-controlled"),
        ("LLM02", "Sensitive info disclosure — customer_id and reason can leak PII"),
    ],
    "payment": [
        ("LLM01", "Prompt injection — amount/destination can be attacker-controlled"),
        ("LLM10", "Unbounded consumption — bursts of payments = fraud or DoS"),
    ],
    "account_change": [
        ("LLM01", "Prompt injection — the new email/password can come from the attacker"),
        ("LLM02", "Sensitive info disclosure — email/phone are PII"),
    ],
    "data_access": [
        ("LLM02", "Sensitive info disclosure — the query's goal can be data exfiltration"),
        ("LLM10", "Unbounded consumption — queries without limits drain the DB"),
    ],
    "tool_use": [
        ("LLM01", "Prompt injection — the prompt is the primary attack surface"),
        ("LLM06", "Jailbreak — evading the model's guardrails"),
        ("LLM10", "Unbounded consumption — huge prompts / infinite loops"),
    ],
    "compliance": [
        ("LLM09", "Overreliance — don't delegate compliance decisions to the agent alone"),
    ],
}


def _load_policy_rules(action_type: str) -> list[dict[str, Any]] | None:
    """Read the policy YAML for an action_type and return its rules list.
    Returns None when no policy is shipped — caller renders a placeholder."""
    src = _POLICY_SOURCE_DIR / f"{action_type}.base.v1.yaml"
    if not src.exists():
        return None
    try:
        data = yaml.safe_load(src.read_text())
        return data.get("rules") or []
    except (yaml.YAMLError, OSError):
        return None


def _render_suppressed_section(findings: list[Finding], repo_root: Path | None) -> str:
    """Render the `## Suppressed` block for FULL_REPORT.md.

    Lists every finding tagged `suppressed: True` (by `.supervisor-ignore`)
    grouped by suppression rule, plus a footer pointing the dev at the
    ignore file. Returns the empty string when nothing is suppressed — the
    common case, so we don't add an empty section to clean reports.

    The intent is honesty + auditability: the dev sees exactly what was
    hidden and why, without surfacing it as a "do this now" item again.
    """
    suppressed = [f for f in findings if (f.extra or {}).get("suppressed")]
    if not suppressed:
        return ""

    by_rule: dict[str, list[Finding]] = {}
    for f in suppressed:
        rule = str((f.extra or {}).get("suppressed_by") or "(unknown rule)")
        by_rule.setdefault(rule, []).append(f)

    ignore_path = (
        f"`{(repo_root / '.supervisor-ignore').name}`"
        if repo_root is not None
        else "`.supervisor-ignore`"
    )
    lines: list[str] = [
        f"## Suppressed ({len(suppressed)})",
        "",
        f"These findings matched a rule in {ignore_path} and are not in the "
        "priority list. Review periodically — a rule that no longer matches "
        "anything probably means the call moved or was deleted.",
        "",
    ]
    for rule_text in sorted(by_rule):
        items = by_rule[rule_text]
        lines.append(f"### Rule: `{rule_text}`")
        reason = (items[0].extra or {}).get("suppression_reason") or "(no reason)"
        lines.append(f"_{len(items)} finding(s) — reason: **{reason}**_")
        lines.append("")
        for f in items[:8]:
            short = f.file
            if repo_root is not None:
                try:
                    short = str(Path(f.file).resolve().relative_to(repo_root.resolve()))
                except (OSError, ValueError):
                    pass
            lines.append(f"- `{short}:{f.line}` · `{f.snippet[:60]}` ({f.scanner})")
        if len(items) > 8:
            lines.append(f"- … +{len(items) - 8} more")
        lines.append("")
    return "\n".join(lines)


def _render_applicable_guardrails(findings: list[Finding]) -> str:
    """For each action_type present in findings, describe which policy applies,
    what its rules do, and which OWASP threats the supervisor catches."""
    buckets = group_by_action_type(findings)
    if not buckets:
        return ""

    lines: list[str] = ["\n## Guardrails the supervisor would apply", ""]
    lines.append(
        "What happens when an agent tries to run each action: the supervisor "
        "runs the listed policy plus the OWASP LLM Top 10 threat pipeline. "
        "If the policy or a threat detector matches, the action is blocked "
        "or sent to review."
    )
    lines.append("")

    for action_type in sorted(buckets.keys()):
        items = buckets[action_type]
        if action_type == "other":
            continue

        rules = _load_policy_rules(action_type)
        owasp = _OWASP_PER_ACTION_TYPE.get(action_type, [])

        # Show the scanners that emitted this action_type so the reader
        # knows whether "tool_use" here means LLM calls, email/shell, or
        # agent-orchestrator — the policy name alone is ambiguous.
        scanners_used = sorted({f.scanner for f in items})
        scanners_str = f" — via {', '.join(scanners_used)}" if scanners_used else ""
        lines.append(f"### Policy `{action_type}.base.v1` — {len(items)} call-site(s){scanners_str}")
        lines.append("")

        # Policy rules block
        if rules is None:
            lines.append(
                f"**Policy:** `{action_type}.base.v1` (no YAML yet). "
                "The scanner generated a placeholder template at "
                f"`runtime-supervisor/policies/{action_type}.base.v1.yaml` — edit it "
                "with the real rules and promote it via `POST /v1/policies`."
            )
        else:
            lines.append(f"**Policy:** `{action_type}.base.v1` ({len(rules)} rules)")
            for rule in rules:
                rule_id = rule.get("id", "?")
                action = str(rule.get("action", "?")).upper()
                reason = rule.get("reason", "?")
                explanation = rule.get("explanation", "").strip()
                lines.append(f"  - **{action}** · `{rule_id}` — {reason}")
                if explanation:
                    # Collapse multiline YAML folded explanations into one paragraph.
                    collapsed = " ".join(explanation.split())
                    lines.append(f"    _{collapsed}_")
        lines.append("")

        # OWASP threats block
        if owasp:
            lines.append("**OWASP LLM threats covered by the threat pipeline:**")
            for ref, desc in owasp:
                lines.append(f"  - **{ref}** — {desc}")
            lines.append("")

        # Call-sites
        lines.append("**Detected call-sites:**")
        for f in items[:10]:
            conf_badge = f" [{f.confidence}]" if f.confidence != "low" else ""
            lines.append(f"  {f.file.split('/')[-1]}:{f.line} — `{f.snippet}`{conf_badge}")
        if len(items) > 10:
            lines.append(f"  … and {len(items) - 10} more (see the full table below).")
        lines.append("")

    return "\n".join(lines) + "\n"


# Findings that represent an actual call-site that runs at the moment the
# agent processes a request — subprocess.run, shutil.rmtree, fs.writeFile,
# eval, sendMail, charge(), and anything else with a runtime side effect.
# These are the wrap targets the operator has to gate.
_EXEC_FAMILIES = frozenset({
    "shell-exec", "fs-delete", "fs-write", "code-eval",
})

# Findings that point at *where the agent shape lives* without themselves
# being the call-site that runs the action: framework imports, class defs,
# tool registrations, method-name pings. Useful context but they're not
# what the user wraps with `@supervised`.
_STRUCTURAL_KINDS = frozenset({
    "framework-import", "agent-class", "agent-method", "tool-registration",
})


def _is_exec_finding(f: Finding) -> bool:
    extra = f.extra or {}
    if extra.get("family") in _EXEC_FAMILIES:
        return True
    return f.scanner in {"messaging", "email-sends", "voice-actions",
                         "calendar-actions", "media-gen", "mcp-tools"}


def _is_structural_finding(f: Finding) -> bool:
    extra = f.extra or {}
    return extra.get("kind") in _STRUCTURAL_KINDS


def _tier_summary(findings: list[Finding]) -> tuple[str, str]:
    """Returns (markdown table, headline note). The table goes at the top of
    the report so the reader sees counts per tier before scrolling into
    details.

    The `real_world_actions` row carries a follow-up split when both shapes
    are present: actual exec call-sites (subprocess / shutil / fs writes)
    vs. structural references (framework imports, agent-class declarations).
    Mixing the two inflates the headline — reading langchain's scan as "71
    real-world actions" when only 3 are exec call-sites is the bug we're
    correcting here.
    """
    buckets = group_by_risk_tier(findings)
    rows: list[str] = []
    headline_high = 0
    for tier in TIER_ORDER:
        items = buckets[tier]
        high = sum(1 for f in items if f.confidence == "high")
        med = sum(1 for f in items if f.confidence == "medium")
        low = sum(1 for f in items if f.confidence == "low")
        total = len(items)
        title = TIER_COPY[tier]["title"]
        if tier == "real_world_actions" and total:
            exec_n = sum(1 for f in items if _is_exec_finding(f))
            ref_n = sum(1 for f in items if _is_structural_finding(f))
            if exec_n and ref_n:
                title = f"{title} (exec: {exec_n} · refs: {ref_n})"
            elif ref_n and not exec_n:
                title = f"{title} (refs only — no exec call-sites)"
        rows.append(f"| **{title}** | {high} | {med} | {low} | {total} |")
        if tier in ("money", "customer_data", "llm"):
            headline_high += high
    if headline_high == 0:
        note = (
            "_No high-confidence findings in the critical tiers. Usually that means "
            "(a) your repo doesn't use the SDKs our scanners recognize, (b) the "
            "imports are indirect and need a re-scan after wrapping, or (c) there "
            "really isn't a critical unsupervised surface. Check the tiers below to confirm._"
        )
    else:
        note = (
            f"**{headline_high} high-confidence call-site(s) are waiting for a stub.** Work "
            "through the tiers below in order (the ones at the top move money or touch "
            "critical data)."
        )
    return "\n".join(rows), note


def _render_by_risk_tier(
    findings: list[Finding],
    agent_path_present: bool = True,
) -> str:
    if not findings:
        return "_No findings — either nothing to supervise, or the scanners didn't recognize anything._\n"
    buckets = group_by_risk_tier(findings)
    lines: list[str] = []

    for tier in TIER_ORDER:
        items = buckets[tier]
        if not items:
            continue
        # The headline tiers (money, customer_data, llm) get the full
        # Problem / In your repo / Fix block and an expanded findings table.
        # `general` is demoted to a collapsed footer at the end.
        if tier == "general":
            continue
        lines.extend(_render_tier_block(
            tier,
            items,
            collapse=False,
            agent_path_present=agent_path_present,
        ))

    # General / informational goes at the bottom, collapsed.
    general = buckets["general"]
    if general:
        lines.extend(_render_tier_block(
            "general",
            general,
            collapse=True,
            agent_path_present=agent_path_present,
        ))

    return "\n".join(lines) + "\n"


def _top_files_evidence(items: list[Finding], limit: int = 3) -> str:
    """Render the top-N findings (by confidence desc) as backticked
    `short-path:line` references joined with ` · `. Used in tier blocks'
    '📍 In your repo' line so the reader sees exactly which files matter."""
    order = {"high": 0, "medium": 1, "low": 2}
    sorted_items = sorted(items, key=lambda f: (order.get(f.confidence, 3), f.file))
    top = sorted_items[:limit]
    shorts = []
    for f in top:
        parts = f.file.rsplit("/", 2)
        short = "/".join(parts[-2:]) if len(parts) > 1 else f.file
        shorts.append(f"`{short}:{f.line}`")
    rendered = " · ".join(shorts)
    if len(items) > limit:
        rendered += f" _+{len(items) - limit} more_"
    return rendered


def _tier_problem(copy: dict[str, str], tier: Tier, agent_path_present: bool) -> str:
    if agent_path_present:
        return copy["problem"]
    if tier == "customer_data":
        return (
            "This code can modify customer tables directly (users, accounts, "
            "customers, orders). A `DELETE FROM users` without `WHERE`, an "
            "`UPDATE` that changes email + phone + password all at once — both "
            "are irreversible actions if this path is reachable from untrusted input."
        )
    if tier == "business_data":
        return (
            "This code can modify business-state tables — trades, positions, "
            "inventory, products, events, logs. These aren't PII, but a "
            "malformed SQL mutation can corrupt your books, log phantom "
            "inventory, or fire trades nobody approved. Irreversible in most cases."
        )
    return copy["problem"]


def _tier_runtime_behavior(copy: dict[str, str], tier: Tier, agent_path_present: bool) -> str:
    if agent_path_present:
        return copy.get("runtime_behavior", "")
    if tier == "business_data":
        return (
            "when wrapped, blocks bulk mutations without `WHERE` and escalates "
            "any write that touches more than the row limit per query. Shadow "
            "mode logs which tables this path actually touches before you enforce."
        )
    return copy.get("runtime_behavior", "")


def _render_per_finding_prompts(items: list[Finding]) -> list[str]:
    """Per-call-site copy-paste LLM prompts, collapsed under one <details>.

    Each prompt names the specific file:line so the user's coding agent
    (Cursor / Claude Code / Codex) can apply the wrap without re-grepping.
    Skips findings whose `suggested_action_type` is `other` — those don't
    have a meaningful policy mapping yet.
    """
    eligible = [f for f in items if f.suggested_action_type and f.suggested_action_type != "other"]
    if not eligible:
        return []
    lines: list[str] = [
        "<details>",
        "<summary>💬 <strong>Per-call-site fix prompts</strong> "
        f"({len(eligible)} prompts — paste into Cursor / Claude Code)</summary>",
        "",
    ]
    for f in eligible:
        lines.append(f"**`{repo_relative_path(f.file)}:{f.line}`** — `{f.scanner}`")
        lines.append("")
        # 4-backtick outer fence so the inner ```python / ```ts blocks
        # the prompt embeds don't close the outer fence prematurely.
        lines.append("````")
        lines.append(prompt_for(f))
        lines.append("````")
        lines.append("")
    lines.append("</details>")
    lines.append("")
    return lines


def _render_tier_block(
    tier: Tier,
    items: list[Finding],
    *,
    collapse: bool,
    agent_path_present: bool = True,
) -> list[str]:
    copy = TIER_COPY[tier]
    high = [f for f in items if f.confidence == "high"]
    medium = [f for f in items if f.confidence == "medium"]
    low = [f for f in items if f.confidence == "low"]

    lines: list[str] = []
    if collapse:
        lines.append(f"<details>\n<summary><strong>{copy['title']}</strong> ({len(items)} informational findings — click to expand)</summary>\n")
    else:
        headline = f"## {copy['title']} — {len(high)} high / {len(medium)} medium / {len(low)} low"
        lines.append(headline)
        lines.append("")
        # Tri-part block: 🔴 Problem · 📍 In your repo · ✅ Fix · (footnote)
        lines.append(f"🔴 **Problem:** {_tier_problem(copy, tier, agent_path_present)}")
        lines.append("")
        top_files = _top_files_evidence(items, limit=3)
        in_repo_prefix = copy["in_your_repo_prefix"].format(total=len(items))
        lines.append(f"📍 **In your repo:** {in_repo_prefix}")
        if top_files:
            lines.append(f"    Top call-sites: {top_files}.")
        lines.append("")
        lines.append(f"✅ **Fix:** {copy['solution']}")
        lines.append("")
        # Optional 💡 runtime behavior — what the supervisor does at call time.
        # Kept so the reader understands block vs review vs shadow semantics,
        # not just the wrap pattern.
        runtime = _tier_runtime_behavior(copy, tier, agent_path_present)
        if runtime:
            lines.append(f"💡 **Runtime behavior:** {runtime}")
            lines.append("")
        footnote = copy.get("technical_footnote", "")
        if footnote:
            lines.append(footnote)
            lines.append("")

    if collapse:
        # General tier: one simple table inside the <details>, no duplication.
        lines.append("| Scanner | File:Line | Snippet |")
        lines.append("|---|---|---|")
        for f in items:
            lines.append(f"| `{f.scanner}` | `{f.file}`:{f.line} | `{f.snippet}` |")
        lines.append("")
        lines.append("</details>\n")
        return lines

    # Headline tiers: high+medium in a rich table, low in a nested <details>.
    if high or medium:
        lines.append("| Confidence | Scanner | File:Line | Snippet | Rationale |")
        lines.append("|---|---|---|---|---|")
        for f in high + medium:
            lines.append(
                f"| {f.confidence} | `{f.scanner}` | `{f.file}`:{f.line} | `{f.snippet}` | {f.rationale} |"
            )
        lines.append("")

        # 💬 Per-call-site prompts — collapsed under one <details> so the
        # table stays scannable, but every high+medium finding has a paste-
        # ready prompt one click away. Skipped for `general` tier and other
        # tiers that don't get a dedicated prompt structure (informational).
        prompt_block = _render_per_finding_prompts(high + medium)
        if prompt_block:
            lines.extend(prompt_block)

    if low:
        lines.append(f"<details>\n<summary>{len(low)} low-confidence findings</summary>\n")
        lines.append("| Scanner | File:Line | Snippet | Rationale |")
        lines.append("|---|---|---|---|")
        for f in low:
            lines.append(f"| `{f.scanner}` | `{f.file}`:{f.line} | `{f.snippet}` | {f.rationale} |")
        lines.append("")
        lines.append("</details>\n")

    return lines


def _policy_template(action_type: str) -> str:
    return f"""# Starter policy for {action_type} — this action_type isn't one the
# supervisor ships with out of the box. Edit and promote via
# POST /v1/policies.
name: {action_type}.base
version: 1
rules:
  - id: hard-cap
    when: "False"  # TODO: replace with real expression
    action: deny
    reason: placeholder
"""
