"""Functions that instantiate IO tools from configuration blocks."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any
from warnings import warn

from spine.utils.conditional import TORCH_AVAILABLE
from spine.utils.factory import instantiate, module_dict

from . import read, write

READER_DICT = module_dict(read)
WRITER_DICT = module_dict(write)

__all__ = [
    "reader_factory",
    "writer_factory",
    "loader_factory",
    "dataset_factory",
    "sampler_factory",
    "collate_factory",
]


def reader_factory(reader_cfg: Mapping[str, Any] | str) -> Any:
    """Instantiate a reader from a configuration block.

    The configured ``name`` must match a reader class exported from
    :mod:`spine.io.read`.

    Parameters
    ----------
    reader_cfg : Mapping[str, Any] or str
        Reader configuration dictionary or the short reader name.

    Returns
    -------
    object
        Instantiated reader object.
    """
    # Initialize reader
    return instantiate(READER_DICT, reader_cfg)


def writer_factory(
    writer_cfg: Mapping[str, Any] | str,
    prefix: str | list[str] | None = None,
    split: bool = False,
) -> Any:
    """Instantiate a writer from a configuration block.

    The configured ``name`` must match a writer class exported from
    :mod:`spine.io.write`.

    Parameters
    ----------
    writer_cfg : Mapping[str, Any] or str
        Writer configuration dictionary or the short writer name.
    prefix : str or list[str], optional
        Input file prefix or per-file list of prefixes used to derive output
        names when the writer supports prefix-based naming.
    split : bool, default False
        Request one output file per input file. Writers that do not support
        unsplit output may reject ``split=False`` explicitly.

    Returns
    -------
    object
        Instantiated writer object.
    """
    # Initialize writer
    extra_kwargs = {}
    if prefix is not None:
        extra_kwargs["prefix"] = prefix
    if split:
        extra_kwargs["split"] = split

    return instantiate(WRITER_DICT, writer_cfg, **extra_kwargs)


def loader_factory(
    dataset: Mapping[str, Any] | str,
    dtype: str,
    geo: Mapping[str, Any] | None = None,
    batch_size: int | None = None,
    minibatch_size: int | None = None,
    shuffle: bool = True,
    sampler: Mapping[str, Any] | str | None = None,
    num_workers: int = 0,
    collate_fn: Mapping[str, Any] | str | None = None,
    entry_list: list[int] | None = None,
    distributed: bool = False,
    world_size: int = 0,
    rank: int = 0,
    **kwargs: Any,
) -> Any:
    """Instantiates a PyTorch DataLoader based on configuration."""
    if not TORCH_AVAILABLE:
        raise ImportError("PyTorch is required to use loader_factory.")

    from torch.utils.data import DataLoader

    # Process the batch size, make sure it is sensible
    assert (batch_size is not None) ^ (
        minibatch_size is not None
    ), "Provide either `batch_size` or `minibatch_size`, not both."

    if batch_size is not None:
        assert (
            world_size == 0 or (batch_size % world_size) == 0
        ), "The batch_size must be a multiple of the number of GPUs."
        minibatch_size = batch_size // max(world_size, 1)
    elif minibatch_size is not None:
        batch_size = minibatch_size * max(world_size, 1)

    # Initialize the dataset
    torch_dataset = dataset_factory(dataset, entry_list, dtype, geo=geo)

    # Initialize the sampler
    if sampler is not None:
        sampler = sampler_factory(
            sampler, torch_dataset, batch_size, distributed, world_size, rank
        )

    # Initialize the collate function
    if collate_fn is not None:
        collate_fn = collate_factory(
            collate_fn, torch_dataset.data_types, torch_dataset.overlay_methods
        )

    # Initialize the loader
    return DataLoader(
        torch_dataset,
        batch_size=minibatch_size,
        shuffle=shuffle,
        sampler=sampler,
        num_workers=num_workers,
        collate_fn=collate_fn,
        **kwargs,
    )


def dataset_factory(
    dataset_cfg: Mapping[str, Any] | str,
    entry_list: list[int] | None = None,
    dtype: str | None = None,
    geo: Mapping[str, Any] | None = None,
) -> Any:
    """Instantiates a Dataset based on a configuration."""
    from . import dataset

    dataset_dict = module_dict(dataset)

    # Append the entry_list if it is provided independently
    if entry_list is not None:
        warn(
            "You are manually overwriting the existing `entry_list` "
            "argument provided in the configuration file."
        )
        dataset_cfg = dict(dataset_cfg)
        dataset_cfg["entry_list"] = entry_list

    # Initialize dataset
    extra_kwargs = {"dtype": dtype}
    if geo is not None:
        extra_kwargs["geo"] = geo

    return instantiate(dataset_dict, dataset_cfg, **extra_kwargs)


def sampler_factory(
    sampler_cfg: Mapping[str, Any] | str,
    dataset: Any,
    minibatch_size: int,
    distributed: bool = False,
    num_replicas: int = 1,
    rank: int = 0,
) -> Any:
    """Instantiates sampler based on configuration."""
    if not TORCH_AVAILABLE:
        raise ImportError("PyTorch is required to use sampler_factory.")

    from . import sample

    sampler_dict = module_dict(sample)

    # Initialize sampler
    sampler_obj = instantiate(
        sampler_dict, sampler_cfg, dataset=dataset, batch_size=minibatch_size
    )

    # If we are working a distributed environment, wrap the sampler
    if distributed:
        sampler_obj = sample.DistributedProxySampler(sampler_obj, num_replicas, rank)

    return sampler_obj


def collate_factory(
    collate_cfg: Mapping[str, Any] | str,
    data_types: Mapping[str, str],
    overlay_methods: Mapping[str, str],
) -> Any:
    """Instantiates collate function based on configuration."""
    from . import collate

    collate_dict = module_dict(collate)

    return instantiate(
        collate_dict,
        collate_cfg,
        "collate_fn",
        data_types=data_types,
        overlay_methods=overlay_methods,
    )
