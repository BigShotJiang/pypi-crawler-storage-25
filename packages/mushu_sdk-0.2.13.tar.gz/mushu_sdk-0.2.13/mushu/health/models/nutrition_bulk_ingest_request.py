from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.nutrition_ingest_request import NutritionIngestRequest


T = TypeVar("T", bound="NutritionBulkIngestRequest")


@_attrs_define
class NutritionBulkIngestRequest:
    """Bulk ingest — array of meals (e.g. App Clip post-install sync).

    Attributes:
        meals (list[NutritionIngestRequest]):
    """

    meals: list[NutritionIngestRequest]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        meals = []
        for meals_item_data in self.meals:
            meals_item = meals_item_data.to_dict()
            meals.append(meals_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "meals": meals,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.nutrition_ingest_request import NutritionIngestRequest

        d = dict(src_dict)
        meals = []
        _meals = d.pop("meals")
        for meals_item_data in _meals:
            meals_item = NutritionIngestRequest.from_dict(meals_item_data)

            meals.append(meals_item)

        nutrition_bulk_ingest_request = cls(
            meals=meals,
        )

        nutrition_bulk_ingest_request.additional_properties = d
        return nutrition_bulk_ingest_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
