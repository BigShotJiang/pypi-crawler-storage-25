from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.nutrition_ingest_request import NutritionIngestRequest


T = TypeVar("T", bound="NutritionEstimateResponse")


@_attrs_define
class NutritionEstimateResponse:
    """AI-estimated nutrient breakdown. All values are estimates with uncertainty.

    Attributes:
        meal_name (str):
        calories_low (float):
        calories_high (float):
        calories (float):
        protein_g (float | Unset):  Default: 0.0.
        carbs_g (float | Unset):  Default: 0.0.
        fat_g (float | Unset):  Default: 0.0.
        fiber_g (float | Unset):  Default: 0.0.
        nutrients (None | NutritionIngestRequest | Unset):
        local_date (str | Unset):  Default: ''.
    """

    meal_name: str
    calories_low: float
    calories_high: float
    calories: float
    protein_g: float | Unset = 0.0
    carbs_g: float | Unset = 0.0
    fat_g: float | Unset = 0.0
    fiber_g: float | Unset = 0.0
    nutrients: None | NutritionIngestRequest | Unset = UNSET
    local_date: str | Unset = ""
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.nutrition_ingest_request import NutritionIngestRequest

        meal_name = self.meal_name

        calories_low = self.calories_low

        calories_high = self.calories_high

        calories = self.calories

        protein_g = self.protein_g

        carbs_g = self.carbs_g

        fat_g = self.fat_g

        fiber_g = self.fiber_g

        nutrients: dict[str, Any] | None | Unset
        if isinstance(self.nutrients, Unset):
            nutrients = UNSET
        elif isinstance(self.nutrients, NutritionIngestRequest):
            nutrients = self.nutrients.to_dict()
        else:
            nutrients = self.nutrients

        local_date = self.local_date

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "meal_name": meal_name,
                "calories_low": calories_low,
                "calories_high": calories_high,
                "calories": calories,
            }
        )
        if protein_g is not UNSET:
            field_dict["protein_g"] = protein_g
        if carbs_g is not UNSET:
            field_dict["carbs_g"] = carbs_g
        if fat_g is not UNSET:
            field_dict["fat_g"] = fat_g
        if fiber_g is not UNSET:
            field_dict["fiber_g"] = fiber_g
        if nutrients is not UNSET:
            field_dict["nutrients"] = nutrients
        if local_date is not UNSET:
            field_dict["local_date"] = local_date

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.nutrition_ingest_request import NutritionIngestRequest

        d = dict(src_dict)
        meal_name = d.pop("meal_name")

        calories_low = d.pop("calories_low")

        calories_high = d.pop("calories_high")

        calories = d.pop("calories")

        protein_g = d.pop("protein_g", UNSET)

        carbs_g = d.pop("carbs_g", UNSET)

        fat_g = d.pop("fat_g", UNSET)

        fiber_g = d.pop("fiber_g", UNSET)

        def _parse_nutrients(data: object) -> None | NutritionIngestRequest | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                nutrients_type_0 = NutritionIngestRequest.from_dict(data)

                return nutrients_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NutritionIngestRequest | Unset, data)

        nutrients = _parse_nutrients(d.pop("nutrients", UNSET))

        local_date = d.pop("local_date", UNSET)

        nutrition_estimate_response = cls(
            meal_name=meal_name,
            calories_low=calories_low,
            calories_high=calories_high,
            calories=calories,
            protein_g=protein_g,
            carbs_g=carbs_g,
            fat_g=fat_g,
            fiber_g=fiber_g,
            nutrients=nutrients,
            local_date=local_date,
        )

        nutrition_estimate_response.additional_properties = d
        return nutrition_estimate_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
