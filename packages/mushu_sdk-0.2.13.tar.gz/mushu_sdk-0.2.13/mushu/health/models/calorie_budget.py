from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CalorieBudget")


@_attrs_define
class CalorieBudget:
    """Server-computed calorie budget for a given date.

    Attributes:
        local_date (str):
        base_goal (float):
        consumed (float):
        active_burned (float):
        remaining (float):
        displacement_factor (float | Unset):  Default: 0.5.
    """

    local_date: str
    base_goal: float
    consumed: float
    active_burned: float
    remaining: float
    displacement_factor: float | Unset = 0.5
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        local_date = self.local_date

        base_goal = self.base_goal

        consumed = self.consumed

        active_burned = self.active_burned

        remaining = self.remaining

        displacement_factor = self.displacement_factor

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "local_date": local_date,
                "base_goal": base_goal,
                "consumed": consumed,
                "active_burned": active_burned,
                "remaining": remaining,
            }
        )
        if displacement_factor is not UNSET:
            field_dict["displacement_factor"] = displacement_factor

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        local_date = d.pop("local_date")

        base_goal = d.pop("base_goal")

        consumed = d.pop("consumed")

        active_burned = d.pop("active_burned")

        remaining = d.pop("remaining")

        displacement_factor = d.pop("displacement_factor", UNSET)

        calorie_budget = cls(
            local_date=local_date,
            base_goal=base_goal,
            consumed=consumed,
            active_burned=active_burned,
            remaining=remaining,
            displacement_factor=displacement_factor,
        )

        calorie_budget.additional_properties = d
        return calorie_budget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
