"""
Unit tests for gitlab_evaluate/lib/utils.py

Covers: threshold check functions, check_size routing, string/case conversion,
Excel formula helpers, sizeof_fmt, strtobool, SSL verification helpers,
workbook write helpers, get_date_run, URL builders, and get_package_version.
"""
import unittest
import os
import sys
import tempfile
import sqlite3
from unittest.mock import MagicMock, patch, mock_open
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gitlab_evaluate.migration_readiness.gitlab import limits


def _utils():
    """Lazy import to avoid circular import at module level."""
    from gitlab_evaluate.lib import utils
    return utils


# ---------------------------------------------------------------------------
# Threshold check functions
# ---------------------------------------------------------------------------
class TestCheckThresholdFunctions(unittest.TestCase):
    """Each check_* function should return False at/below its limit and True above."""

    def _assert_threshold(self, func, limit):
        self.assertFalse(func(0))
        self.assertFalse(func(limit - 1))
        self.assertFalse(func(limit))
        self.assertTrue(func(limit + 1))

    def test_check_num_pl(self):
        self._assert_threshold(_utils().check_num_pl, limits.PIPELINES_COUNT)

    def test_check_num_br(self):
        self._assert_threshold(_utils().check_num_br, limits.BRANCHES_COUNT)

    def test_check_num_commits(self):
        self._assert_threshold(_utils().check_num_commits, limits.COMMITS_COUNT)

    def test_check_num_snippets(self):
        self._assert_threshold(_utils().check_num_snippets, limits.SNIPPETS_COUNT)

    def test_check_num_issues(self):
        self._assert_threshold(_utils().check_num_issues, limits.ISSUES_COUNT)

    def test_check_num_mr(self):
        self._assert_threshold(_utils().check_num_mr, limits.MERGE_REQUESTS_COUNT)

    def test_check_num_tags(self):
        self._assert_threshold(_utils().check_num_tags, limits.TAGS_COUNT)

    def test_check_repository_size(self):
        self._assert_threshold(_utils().check_repository_size, limits.REPOSITORY_SIZE)

    def test_check_storage_size(self):
        self._assert_threshold(_utils().check_storage_size, limits.STORAGE_SIZE)

    def test_check_uploads_size(self):
        self._assert_threshold(_utils().check_uploads_size, limits.UPLOADS_SIZE)

    def test_check_packages_size(self):
        self._assert_threshold(_utils().check_packages_size, limits.PACKAGES_SIZE)

    def test_check_registry_size(self):
        self._assert_threshold(_utils().check_registry_size, limits.CONTAINERS_SIZE)

    def test_check_file_size(self):
        self._assert_threshold(_utils().check_file_size, limits.FILE_SIZE)

    def test_check_export_size_5(self):
        self._assert_threshold(_utils().check_export_size_5, limits.IMPORT_SIZE)

    def test_check_export_size_10(self):
        self._assert_threshold(_utils().check_export_size_10, limits.IMPORT_SIZE_S3)

    def test_check_proj_type_returns_value_as_is(self):
        utils = _utils()
        self.assertTrue(utils.check_proj_type(True))
        self.assertFalse(utils.check_proj_type(False))
        self.assertEqual(utils.check_proj_type("something"), "something")


# ---------------------------------------------------------------------------
# check_size routing
# ---------------------------------------------------------------------------
class TestCheckSizeRouting(unittest.TestCase):
    """check_size should dispatch to the correct threshold function per key."""

    def test_uploads_size_uses_uploads_threshold(self):
        """5500 MB exceeds 5000 MB uploads limit but not 20 GB storage limit."""
        self.assertTrue(_utils().check_size("uploads_size", 5500000000))

    def test_uploads_size_below_threshold(self):
        self.assertFalse(_utils().check_size("uploads_size", 4500000000))

    def test_storage_size_uses_storage_threshold(self):
        self.assertFalse(_utils().check_size("storage_size", 600000000))
        self.assertTrue(_utils().check_size("storage_size", limits.STORAGE_SIZE + 1))

    def test_lfs_objects_size_uses_storage_threshold(self):
        self.assertTrue(_utils().check_size("lfs_objects_size", limits.STORAGE_SIZE + 1))
        self.assertFalse(_utils().check_size("lfs_objects_size", limits.STORAGE_SIZE))

    def test_build_artifacts_size_uses_storage_threshold(self):
        self.assertTrue(_utils().check_size("build_artifacts_size", limits.STORAGE_SIZE + 1))

    def test_wiki_size_uses_storage_threshold(self):
        self.assertTrue(_utils().check_size("wiki_size", limits.STORAGE_SIZE + 1))

    def test_snippets_size_uses_snippets_threshold(self):
        self.assertTrue(_utils().check_size("snippets_size", limits.SNIPPETS_COUNT + 1))
        self.assertFalse(_utils().check_size("snippets_size", limits.SNIPPETS_COUNT))

    def test_commit_count_uses_commits_threshold(self):
        self.assertTrue(_utils().check_size("commit_count", limits.COMMITS_COUNT + 1))
        self.assertFalse(_utils().check_size("commit_count", limits.COMMITS_COUNT))

    def test_repository_size_uses_file_size_threshold(self):
        self.assertTrue(_utils().check_size("repository_size", limits.FILE_SIZE + 1))
        self.assertFalse(_utils().check_size("repository_size", limits.FILE_SIZE))

    def test_estimated_export_size_uses_import_threshold(self):
        self.assertTrue(_utils().check_size("estimated_export_size", limits.IMPORT_SIZE + 1))
        self.assertFalse(_utils().check_size("estimated_export_size", limits.IMPORT_SIZE))

    def test_estimated_export_size_s3_uses_s3_threshold(self):
        self.assertTrue(_utils().check_size("estimated_export_size_s3", limits.IMPORT_SIZE_S3 + 1))
        self.assertFalse(_utils().check_size("estimated_export_size_s3", limits.IMPORT_SIZE_S3))

    def test_unknown_key_returns_none(self):
        self.assertIsNone(_utils().check_size("nonexistent_key", 999))

    def test_all_expected_keys_are_mapped(self):
        """Every key in _SIZE_CHECK_FUNCTIONS should produce a non-None result."""
        utils = _utils()
        for key in utils._SIZE_CHECK_FUNCTIONS:
            result = utils.check_size(key, 0)
            self.assertIsNotNone(result, f"check_size('{key}', 0) returned None")


# ---------------------------------------------------------------------------
# sizeof_fmt
# ---------------------------------------------------------------------------
class TestSizeofFmt(unittest.TestCase):
    """Human-readable byte formatting."""

    def test_bytes(self):
        self.assertEqual(_utils().sizeof_fmt(100), "100.0B")

    def test_kibibytes(self):
        self.assertEqual(_utils().sizeof_fmt(1024), "1.0KiB")

    def test_mebibytes(self):
        self.assertEqual(_utils().sizeof_fmt(1024 ** 2), "1.0MiB")

    def test_gibibytes(self):
        self.assertEqual(_utils().sizeof_fmt(1024 ** 3), "1.0GiB")

    def test_tebibytes(self):
        self.assertEqual(_utils().sizeof_fmt(1024 ** 4), "1.0TiB")

    def test_zero(self):
        self.assertEqual(_utils().sizeof_fmt(0), "0.0B")

    def test_negative(self):
        self.assertEqual(_utils().sizeof_fmt(-1024), "-1.0KiB")

    def test_yobibytes_overflow(self):
        result = _utils().sizeof_fmt(1024 ** 8)
        self.assertIn("Yi", result)

    def test_custom_suffix(self):
        self.assertEqual(_utils().sizeof_fmt(0, suffix="b"), "0.0b")


# ---------------------------------------------------------------------------
# to_camel_case / to_snake_case
# ---------------------------------------------------------------------------
class TestCaseConversion(unittest.TestCase):

    def test_to_camel_case_snake_input(self):
        self.assertEqual(_utils().to_camel_case("hello_world"), "helloWorld")

    def test_to_camel_case_hyphen_input(self):
        self.assertEqual(_utils().to_camel_case("hello-world"), "helloWorld")

    def test_to_camel_case_single_word(self):
        self.assertEqual(_utils().to_camel_case("hello"), "hello")

    def test_to_camel_case_multiple_underscores(self):
        self.assertEqual(_utils().to_camel_case("one_two_three"), "oneTwoThree")

    def test_to_snake_case_camel_input(self):
        self.assertEqual(_utils().to_snake_case("helloWorld"), "hello_world")

    def test_to_snake_case_pascal_input(self):
        self.assertEqual(_utils().to_snake_case("HelloWorld"), "hello_world")

    def test_to_snake_case_already_snake(self):
        self.assertEqual(_utils().to_snake_case("hello_world"), "hello_world")

    def test_to_snake_case_consecutive_caps(self):
        result = _utils().to_snake_case("getHTTPResponse")
        self.assertIn("http", result.lower())

    def test_to_snake_case_hyphenated(self):
        result = _utils().to_snake_case("my-variable")
        self.assertEqual(result, "my_variable")


# ---------------------------------------------------------------------------
# nested_snake_case
# ---------------------------------------------------------------------------
class TestNestedSnakeCase(unittest.TestCase):

    def test_flat_dict(self):
        result = _utils().nested_snake_case({"firstName": "John", "lastName": "Doe"})
        self.assertEqual(result, {"first_name": "John", "last_name": "Doe"})

    def test_nested_dict(self):
        result = _utils().nested_snake_case({"outerKey": {"innerKey": "value"}})
        self.assertIn("outer_key", result)
        self.assertIn("inner_key", result["outer_key"])

    def test_list_with_dicts(self):
        result = _utils().nested_snake_case({"myList": [{"itemKey": 1}, {"itemKey": 2}]})
        self.assertIn("my_list", result)
        self.assertEqual(result["my_list"][0]["item_key"], 1)

    def test_list_with_non_dicts(self):
        result = _utils().nested_snake_case({"myList": [1, "two", 3]})
        self.assertEqual(result["my_list"], [1, "two", 3])

    def test_non_dict_passthrough(self):
        self.assertEqual(_utils().nested_snake_case("not a dict"), "not a dict")
        self.assertEqual(_utils().nested_snake_case(42), 42)
        self.assertIsNone(_utils().nested_snake_case(None))

    def test_empty_dict(self):
        self.assertEqual(_utils().nested_snake_case({}), {})


# ---------------------------------------------------------------------------
# strtobool
# ---------------------------------------------------------------------------
class TestStrtobool(unittest.TestCase):

    def test_true_values(self):
        utils = _utils()
        for val in ('y', 'yes', 't', 'true', 'on', '1', 'YES', 'True', 'ON'):
            self.assertTrue(utils.strtobool(val), f"Expected True for '{val}'")

    def test_false_values(self):
        utils = _utils()
        for val in ('n', 'no', 'f', 'false', 'off', '0', 'NO', 'False', 'OFF'):
            self.assertFalse(utils.strtobool(val), f"Expected False for '{val}'")

    def test_invalid_value_raises(self):
        with self.assertRaises(ValueError):
            _utils().strtobool("maybe")

    def test_invalid_empty_raises(self):
        with self.assertRaises((ValueError, AttributeError)):
            _utils().strtobool("")


# ---------------------------------------------------------------------------
# SSL verification helpers
# ---------------------------------------------------------------------------
class TestSSLVerification(unittest.TestCase):

    def setUp(self):
        self._cleanup()

    def tearDown(self):
        self._cleanup()

    def _cleanup(self):
        if os.path.exists('SSL_VERIFICATION'):
            os.remove('SSL_VERIFICATION')

    def test_set_and_get_true(self):
        utils = _utils()
        utils.set_ssl_verification(True)
        self.assertTrue(utils.get_ssl_verification())

    def test_set_and_get_false(self):
        utils = _utils()
        utils.set_ssl_verification(False)
        self.assertFalse(utils.get_ssl_verification())

    def test_get_default_when_file_missing(self):
        self.assertTrue(_utils().get_ssl_verification())


# ---------------------------------------------------------------------------
# sqlite_connection
# ---------------------------------------------------------------------------
class TestSqliteConnection(unittest.TestCase):

    def test_returns_connection_and_cursor(self):
        utils = _utils()
        con, cur = utils.sqlite_connection(":memory:")
        self.assertIsNotNone(con)
        self.assertIsNotNone(cur)
        con.close()

    def test_rows_as_dicts(self):
        utils = _utils()
        con, cur = utils.sqlite_connection(":memory:", rows_as_dicts=True)
        self.assertEqual(con.row_factory, sqlite3.Row)
        con.close()

    def test_rows_not_dicts_by_default(self):
        utils = _utils()
        con, cur = utils.sqlite_connection(":memory:")
        self.assertIsNone(con.row_factory)
        con.close()


# ---------------------------------------------------------------------------
# get_date_run
# ---------------------------------------------------------------------------
class TestGetDateRun(unittest.TestCase):

    def test_returns_today(self):
        result = _utils().get_date_run()
        self.assertEqual(result, date.today().strftime("%Y-%m-%d"))

    def test_format_is_iso(self):
        result = _utils().get_date_run()
        # YYYY-MM-DD
        self.assertRegex(result, r'^\d{4}-\d{2}-\d{2}$')


# ---------------------------------------------------------------------------
# Excel formula helpers
# ---------------------------------------------------------------------------
class TestExcelFormulaHelpers(unittest.TestCase):

    def test_get_countif(self):
        result = _utils().get_countif("Sheet1", "True", "A")
        self.assertEqual(result, "COUNTIF('Sheet1'!A:A, \"True\")")

    def test_get_countifs(self):
        result = _utils().get_countifs("Sheet1", "True", "A", "False", "B")
        self.assertEqual(result, "COUNTIFS('Sheet1'!A:A, \"True\", 'Sheet1'!B:B, \"False\")")

    def test_get_counta(self):
        result = _utils().get_counta("Sheet1", "C")
        self.assertEqual(result, "COUNTA('Sheet1'!C:C)")

    def test_get_if(self):
        result = _utils().get_if("A1>5", "\"big\"", "\"small\"")
        self.assertEqual(result, 'IF(A1>5, "big", "small")')

    def test_get_sum(self):
        result = _utils().get_sum("Data", "D")
        self.assertEqual(result, "SUM('Data'!D:D)")

    def test_get_sumif(self):
        result = _utils().get_sumif("Data", "A", "B", "yes")
        self.assertEqual(result, "SUMIF('Data'!A:A, \"yes\", 'Data'!B:B)")

    def test_sheet_name_with_spaces(self):
        result = _utils().get_countif("My Sheet", "x", "A")
        self.assertIn("'My Sheet'", result)


# ---------------------------------------------------------------------------
# URL builders
# ---------------------------------------------------------------------------
class TestURLBuilders(unittest.TestCase):

    def test_get_reading_the_output_link(self):
        result = _utils().get_reading_the_output_link()
        self.assertIn("reading-the-output.md", result)
        self.assertTrue(result.startswith("https://"))

    def test_get_upgrade_path(self):
        result = _utils().get_upgrade_path("16.8.2")
        self.assertIn("16.8.2", result)
        self.assertIn("upgrade-path", result)

    def test_get_whats_changed_standard_version(self):
        result = _utils().get_whats_changed("16.8.2-ee")
        self.assertIn("minVersion=16_08", result)

    def test_get_whats_changed_single_digit_minor(self):
        result = _utils().get_whats_changed("16.1.0")
        self.assertIn("minVersion=16_01", result)

    def test_get_whats_changed_double_digit(self):
        result = _utils().get_whats_changed("17.12.0")
        self.assertIn("minVersion=17_12", result)


# ---------------------------------------------------------------------------
# get_package_version
# ---------------------------------------------------------------------------
class TestGetPackageVersion(unittest.TestCase):

    def test_reads_from_pyproject_when_present(self):
        """When pyproject.toml exists and is for gitlab_evaluate, return its version."""
        result = _utils().get_package_version()
        self.assertIsInstance(result, str)
        self.assertGreater(len(result), 0)

    @patch('gitlab_evaluate.lib.utils.exists', return_value=False)
    def test_falls_back_to_importlib(self, mock_exists):
        """When pyproject.toml is absent, fall back to importlib.metadata."""
        result = _utils().get_package_version()
        self.assertIsInstance(result, str)


# ---------------------------------------------------------------------------
# Workbook write helpers
# ---------------------------------------------------------------------------
class TestWriteToWorksheet(unittest.TestCase):

    def test_writes_bool_as_string(self):
        ws = MagicMock()
        _utils().write_to_worksheet(ws, 0, 0, True)
        ws.write.assert_called_once_with(0, 0, "True")

    def test_writes_false_as_string(self):
        ws = MagicMock()
        _utils().write_to_worksheet(ws, 0, 0, False)
        ws.write.assert_called_once_with(0, 0, "False")

    def test_writes_string(self):
        ws = MagicMock()
        _utils().write_to_worksheet(ws, 1, 2, "hello")
        ws.write.assert_called_once_with(1, 2, "hello")

    def test_writes_int_as_number(self):
        ws = MagicMock()
        _utils().write_to_worksheet(ws, 0, 0, 42)
        ws.write_number.assert_called_once_with(0, 0, 42)

    def test_writes_float_as_number(self):
        ws = MagicMock()
        _utils().write_to_worksheet(ws, 0, 0, 3.14)
        ws.write_number.assert_called_once_with(0, 0, 3.14)

    def test_ignores_none(self):
        ws = MagicMock()
        _utils().write_to_worksheet(ws, 0, 0, None)
        ws.write.assert_not_called()
        ws.write_number.assert_not_called()

    def test_ignores_list(self):
        ws = MagicMock()
        _utils().write_to_worksheet(ws, 0, 0, [1, 2, 3])
        ws.write.assert_not_called()
        ws.write_number.assert_not_called()


class TestWriteHeaders(unittest.TestCase):

    def test_writes_all_headers(self):
        ws = MagicMock()
        fmt = MagicMock()
        headers = ["A", "B", "C"]
        _utils().write_headers(0, ws, headers, fmt)
        self.assertEqual(ws.write.call_count, 3)
        ws.write.assert_any_call(0, 0, "A", fmt)
        ws.write.assert_any_call(0, 1, "B", fmt)
        ws.write.assert_any_call(0, 2, "C", fmt)

    def test_writes_at_given_row(self):
        ws = MagicMock()
        fmt = MagicMock()
        _utils().write_headers(5, ws, ["X"], fmt)
        ws.write.assert_called_once_with(5, 0, "X", fmt)

    def test_empty_headers(self):
        ws = MagicMock()
        _utils().write_headers(0, ws, [], MagicMock())
        ws.write.assert_not_called()


class TestWriteToWorkbook(unittest.TestCase):

    def test_writes_data_rows_starting_at_row_1(self):
        ws = MagicMock()
        data = [{"Name": "Alice", "Age": "30"}, {"Name": "Bob", "Age": "25"}]
        headers = ["Name", "Age"]
        _utils().write_to_workbook(ws, data, headers)
        # Row 1: Alice, 30; Row 2: Bob, 25
        self.assertEqual(ws.write.call_count, 4)
        ws.write.assert_any_call(1, 0, "Alice")
        ws.write.assert_any_call(1, 1, "30")
        ws.write.assert_any_call(2, 0, "Bob")

    def test_missing_key_writes_empty_string(self):
        ws = MagicMock()
        data = [{"Name": "Alice"}]
        headers = ["Name", "Missing"]
        _utils().write_to_workbook(ws, data, headers)
        ws.write.assert_any_call(1, 1, "")


class TestAppendToWorkbook(unittest.TestCase):

    def test_appends_after_existing_rows(self):
        ws = MagicMock()
        ws.table = {0: {}, 1: {}, 2: {}}  # 3 existing rows
        data = [{"Col": "value"}]
        headers = ["Col"]
        _utils().append_to_workbook(ws, data, headers)
        # Should write at row 3 (len of table)
        ws.write.assert_called_once_with(3, 0, "value")

    def test_case_insensitive_key_fallback(self):
        ws = MagicMock()
        ws.table = {}
        data = [{"name": "test"}]
        headers = ["Name"]
        _utils().append_to_workbook(ws, data, headers)
        ws.write.assert_called_once_with(0, 0, "test")


if __name__ == '__main__':
    unittest.main()
