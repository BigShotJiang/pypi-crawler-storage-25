"""
Test that all report generators disable xlsxwriter's automatic URL-to-hyperlink
conversion by setting strings_to_urls=False.

Excel has a hard limit of 65,530 hyperlinks per worksheet. xlsxwriter's
worksheet.write() auto-converts strings starting with http(s):// into
hyperlinks by default. For large instances (130K+ projects), this causes
URLs beyond the limit to be silently dropped with a UserWarning.

The fix disables this by passing {'strings_to_urls': False} to Workbook().
"""
import unittest
import os
import sys
import tempfile
import warnings

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import xlsxwriter


class TestStringsToUrlsDisabled(unittest.TestCase):
    """Verify all report generators instantiate Workbook with strings_to_urls=False."""

    def test_gitlab_workbook_disables_strings_to_urls_custom_filename(self):
        """GitLab: Workbook with custom filename has strings_to_urls=False."""
        wb = xlsxwriter.Workbook('/dev/null', {'strings_to_urls': False})
        self.assertFalse(wb.strings_to_urls)
        wb.close()

    def test_gitlab_workbook_disables_strings_to_urls_default_filename(self):
        """GitLab: Workbook with default filename has strings_to_urls=False."""
        wb = xlsxwriter.Workbook('/dev/null', {'strings_to_urls': False})
        self.assertFalse(wb.strings_to_urls)
        wb.close()

    def test_default_workbook_has_strings_to_urls_enabled(self):
        """Baseline: default Workbook has strings_to_urls=True."""
        wb = xlsxwriter.Workbook('/dev/null')
        self.assertTrue(wb.strings_to_urls)
        wb.close()


class TestUrlsWrittenAsPlainText(unittest.TestCase):
    """Verify URLs are written as plain text when strings_to_urls=False."""

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.test_dir, 'test_report.xlsx')

    def tearDown(self):
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
        os.rmdir(self.test_dir)

    def test_url_not_converted_to_hyperlink(self):
        """A URL string written with strings_to_urls=False must not become a hyperlink."""
        wb = xlsxwriter.Workbook(self.test_file, {'strings_to_urls': False})
        ws = wb.add_worksheet()
        url = 'https://gitlab.example.com/group/project'

        ws.write(0, 0, url)

        self.assertEqual(ws.hlink_count, 0, "URL should not be counted as a hyperlink")
        wb.close()

    def test_url_converted_with_default_settings(self):
        """Baseline: URL written with default settings becomes a hyperlink."""
        wb = xlsxwriter.Workbook(self.test_file)
        ws = wb.add_worksheet()
        url = 'https://gitlab.example.com/group/project'

        ws.write(0, 0, url)

        self.assertGreater(ws.hlink_count, 0, "URL should be counted as a hyperlink by default")
        wb.close()

    def test_many_urls_no_warnings(self):
        """Writing 100+ URLs with strings_to_urls=False must produce no warnings."""
        wb = xlsxwriter.Workbook(self.test_file, {'strings_to_urls': False})
        ws = wb.add_worksheet()

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            for i in range(200):
                ws.write(i, 0, f'https://gitlab.example.com/project-{i}')

            url_warnings = [x for x in w if '65,530' in str(x.message)]
            self.assertEqual(len(url_warnings), 0, "No URL limit warnings should be raised")

        self.assertEqual(ws.hlink_count, 0, "No hyperlinks should be created")
        wb.close()

    def test_non_url_strings_unaffected(self):
        """Regular strings must still be written normally."""
        wb = xlsxwriter.Workbook(self.test_file, {'strings_to_urls': False})
        ws = wb.add_worksheet()

        ws.write(0, 0, 'regular text')
        ws.write(1, 0, 'project-name')
        ws.write(2, 0, 42)
        ws.write(3, 0, True)

        self.assertEqual(ws.hlink_count, 0)
        wb.close()


class TestSourceCodeWorkbookOptions(unittest.TestCase):
    """
    Verify that the actual source code of all 6 report generators
    contains strings_to_urls: False in every Workbook instantiation.
    """

    def _check_file_workbook_calls(self, filepath):
        """Check that every Workbook() call in a file includes strings_to_urls."""
        with open(filepath) as f:
            lines = f.readlines()

        workbook_lines = [
            (i + 1, line.strip())
            for i, line in enumerate(lines)
            if 'xlsxwriter.Workbook(' in line
        ]

        self.assertGreater(len(workbook_lines), 0,
                           f"No Workbook() calls found in {filepath}")

        for line_num, line in workbook_lines:
            self.assertIn("'strings_to_urls': False", line,
                          f"Workbook() at {filepath}:{line_num} is missing "
                          f"strings_to_urls=False: {line}")

    def test_gitlab_report_generator(self):
        path = os.path.join(os.path.dirname(__file__), '..', 'migration_readiness', 'gitlab', 'report_generator.py')
        self._check_file_workbook_calls(os.path.normpath(path))

    def test_jenkins_report_generator(self):
        path = os.path.join(os.path.dirname(__file__), '..', 'migration_readiness', 'jenkins', 'report_generator.py')
        self._check_file_workbook_calls(os.path.normpath(path))

    def test_ado_report_generator(self):
        path = os.path.join(os.path.dirname(__file__), '..', 'migration_readiness', 'ado', 'report_generator.py')
        self._check_file_workbook_calls(os.path.normpath(path))

    def test_bitbucket_report_generator(self):
        path = os.path.join(os.path.dirname(__file__), '..', 'migration_readiness', 'bitbucket', 'report_generator.py')
        self._check_file_workbook_calls(os.path.normpath(path))

    def test_bitbucket_cloud_report_generator(self):
        path = os.path.join(os.path.dirname(__file__), '..', 'migration_readiness', 'bitbucket_cloud', 'report_generator.py')
        self._check_file_workbook_calls(os.path.normpath(path))

    def test_github_enterprise_report_generator(self):
        path = os.path.join(os.path.dirname(__file__), '..', 'migration_readiness', 'github_enterprise', 'report_generator.py')
        self._check_file_workbook_calls(os.path.normpath(path))


if __name__ == '__main__':
    unittest.main()
