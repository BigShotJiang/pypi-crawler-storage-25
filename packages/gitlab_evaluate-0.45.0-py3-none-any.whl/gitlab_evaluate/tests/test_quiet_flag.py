"""
Test for --quiet/-q flag: Verify that the quiet flag reduces log output
by setting the logging level to WARNING, suppressing INFO and DEBUG messages.

This is important for large GitLab instances (65k+ projects) where per-project
INFO log lines can cause CI/CD job failures due to exceeding the GitLab trace
size limit (~200MB).
"""
import unittest
import logging
from io import StringIO
from unittest.mock import patch
from click.testing import CliRunner

from gitlab_evaluate.lib.log_utils import set_log_level, get_log_level


class TestQuietFlagLogLevel(unittest.TestCase):
    """Test that --quiet properly sets log level to WARNING."""

    def setUp(self):
        """Reset log level before each test."""
        set_log_level('INFO')

    def tearDown(self):
        """Clean up log level file after each test."""
        import os
        if os.path.exists('LOGGING_LEVEL'):
            os.remove('LOGGING_LEVEL')

    def test_set_log_level_warning(self):
        """set_log_level('WARNING') should persist and be retrievable."""
        set_log_level('WARNING')
        self.assertEqual(get_log_level(), 'WARNING')

    def test_default_log_level_is_info(self):
        """Default log level should be INFO."""
        import os
        if os.path.exists('LOGGING_LEVEL'):
            os.remove('LOGGING_LEVEL')
        self.assertEqual(get_log_level(), 'INFO')

    def test_set_all_loggers_level_validates_string(self):
        """set_all_loggers_level should reject invalid level strings."""
        from gitlab_evaluate.lib.log_utils import set_all_loggers_level
        with self.assertRaises(ValueError) as cm:
            set_all_loggers_level('INVALID')
        self.assertIn('Invalid logging level', str(cm.exception))

    def test_set_all_loggers_level_validates_type(self):
        """set_all_loggers_level should reject invalid types."""
        from gitlab_evaluate.lib.log_utils import set_all_loggers_level
        with self.assertRaises(TypeError) as cm:
            set_all_loggers_level(None)
        self.assertIn('must be str or int', str(cm.exception))

    def test_set_all_loggers_level_accepts_int(self):
        """set_all_loggers_level should accept numeric levels."""
        from gitlab_evaluate.lib.log_utils import set_all_loggers_level
        # Should not raise
        set_all_loggers_level(logging.WARNING)

    def test_warning_level_suppresses_info(self):
        """WARNING level should suppress INFO messages (the main source of trace bloat)."""
        log = logging.getLogger('test_quiet_suppression')
        log.handlers.clear()
        buffer = StringIO()
        handler = logging.StreamHandler(buffer)
        log.addHandler(handler)

        # Simulate default behavior (INFO)
        log.setLevel('INFO')
        log.info("project/foo - merge_requests retrieved count: 42")
        info_output = buffer.getvalue()
        self.assertIn("merge_requests", info_output)

        # Simulate --quiet behavior (WARNING)
        buffer.truncate(0)
        buffer.seek(0)
        log.setLevel('WARNING')
        log.info("project/bar - issues retrieved count: 100")
        log.debug("Detailed debug info")
        quiet_output = buffer.getvalue()
        self.assertEqual(quiet_output, "", "INFO and DEBUG messages should be suppressed at WARNING level")

        # Warnings and errors should still show
        log.warning("Something notable happened")
        log.error("Something broke")
        quiet_output = buffer.getvalue()
        self.assertIn("Something notable", quiet_output)
        self.assertIn("Something broke", quiet_output)

    def test_quiet_suppresses_per_project_lines(self):
        """
        Simulate the per-project log lines from evaluate.py that cause trace bloat.
        With 65k+ projects and multiple metrics, these INFO lines generate 200MB+ of output.
        """
        log = logging.getLogger('test_per_project')
        log.handlers.clear()
        buffer = StringIO()
        handler = logging.StreamHandler(buffer)
        log.addHandler(handler)

        log.setLevel('WARNING')

        # These are the exact patterns from gitlab_evaluate/migration_readiness/gitlab/evaluate.py
        for i in range(100):
            log.info(f"group/subgroup/project-{i} - merge_requests retrieved count: {i}")
            log.info(f"group/subgroup/project-{i} - issues retrieved count: {i * 2}")
            log.info(f"Retrieving group/subgroup/project-{i} registry repos")
            log.info(f"group/subgroup/project-{i} - container_tag_count retrieved count: {i}")
            log.debug(f"No packages found for project {i}. Skipping")

        output = buffer.getvalue()
        self.assertEqual(output, "", "All per-project INFO/DEBUG lines should be suppressed with --quiet")


class TestQuietFlagCLI(unittest.TestCase):
    """Test that --quiet flag is properly wired into CLI commands."""

    def test_evaluate_gitlab_has_quiet_option(self):
        """evaluate_gitlab command should accept --quiet flag."""
        from gitlab_evaluate.main import evaluate_gitlab
        param_names = [p.name for p in evaluate_gitlab.params]
        self.assertIn('quiet', param_names)

    def test_evaluate_ado_has_quiet_option(self):
        """evaluate_ado command should accept --quiet flag."""
        from gitlab_evaluate.main import evaluate_ado
        param_names = [p.name for p in evaluate_ado.params]
        self.assertIn('quiet', param_names)

    def test_evaluate_jenkins_has_quiet_option(self):
        """evaluate_jenkins command should accept --quiet flag."""
        from gitlab_evaluate.main import evaluate_jenkins
        param_names = [p.name for p in evaluate_jenkins.params]
        self.assertIn('quiet', param_names)

    def test_evaluate_bitbucket_has_quiet_option(self):
        """evaluate_bitbucket command should accept --quiet flag."""
        from gitlab_evaluate.main import evaluate_bitbucket
        param_names = [p.name for p in evaluate_bitbucket.params]
        self.assertIn('quiet', param_names)

    def test_evaluate_bitbucket_cloud_has_quiet_option(self):
        """evaluate_bitbucket_cloud command should accept --quiet flag."""
        from gitlab_evaluate.main import evaluate_bitbucket_cloud
        param_names = [p.name for p in evaluate_bitbucket_cloud.params]
        self.assertIn('quiet', param_names)

    def test_evaluate_github_enterprise_has_quiet_option(self):
        """evaluate_github_enterprise command should accept --quiet flag."""
        from gitlab_evaluate.main import evaluate_github_enterprise
        param_names = [p.name for p in evaluate_github_enterprise.params]
        self.assertIn('quiet', param_names)

    def test_quiet_flag_short_option(self):
        """All commands should support -q as short option for --quiet."""
        from gitlab_evaluate.main import evaluate_gitlab
        quiet_param = next(p for p in evaluate_gitlab.params if p.name == 'quiet')
        self.assertIn('-q', quiet_param.opts)

    @patch('gitlab_evaluate.main.GLReportGenerator')
    @patch('gitlab_evaluate.main.evaluate_api.EvaluateApi')
    def test_evaluate_gitlab_quiet_sets_warning_level(self, mock_api, mock_rg):
        """Running evaluate_gitlab with --quiet should set log level to WARNING."""
        from gitlab_evaluate.main import evaluate_gitlab
        runner = CliRunner()
        result = runner.invoke(evaluate_gitlab, ['-s', 'https://example.com', '-t', 'fake', '-q'])
        self.assertEqual(get_log_level(), 'WARNING')

    @patch('gitlab_evaluate.main.GLReportGenerator')
    @patch('gitlab_evaluate.main.evaluate_api.EvaluateApi')
    def test_evaluate_gitlab_default_sets_info_level(self, mock_api, mock_rg):
        """Running evaluate_gitlab without --quiet should set log level to INFO."""
        from gitlab_evaluate.main import evaluate_gitlab
        runner = CliRunner()
        result = runner.invoke(evaluate_gitlab, ['-s', 'https://example.com', '-t', 'fake'])
        self.assertEqual(get_log_level(), 'INFO')


if __name__ == '__main__':
    unittest.main()
