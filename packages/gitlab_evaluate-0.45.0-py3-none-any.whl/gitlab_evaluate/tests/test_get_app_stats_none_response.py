"""
Test for issue #169: Handle None response in get_app_stats

This test verifies that when the /api/v4/application/statistics endpoint
returns None (due to timeouts, rate limiting, or permission issues),
the get_app_stats method handles it gracefully instead of crashing with:
    TypeError: argument of type 'NoneType' is not iterable
"""
import unittest
from unittest.mock import MagicMock, patch, mock_open
import sys
import os

# Add the parent directory to sys.path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class TestGetAppStatsNoneResponse(unittest.TestCase):
    """Test that get_app_stats handles None API responses gracefully."""

    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.xlsxwriter')
    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.utils')
    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.is_error_message_present')
    def test_get_app_stats_handles_none_response(self, mock_is_error, mock_utils, mock_xlsxwriter):
        """
        Simulates the scenario from issue #169 where a large GitLab instance
        (65,530+ projects) returns None from the application/statistics endpoint.
        
        The fix adds 'resp is not None' check to prevent TypeError when
        from_dict() receives None instead of a dict.
        """
        from gitlab_evaluate.migration_readiness.gitlab.report_generator import ReportGenerator
        
        # Mock workbook and worksheets
        mock_workbook = MagicMock()
        mock_worksheet = MagicMock()
        mock_workbook.add_worksheet.return_value = mock_worksheet
        mock_workbook.add_format.return_value = MagicMock()
        mock_xlsxwriter.Workbook.return_value = mock_workbook
        
        # Mock EvaluateApi
        mock_evaluate_api = MagicMock()
        mock_evaluate_api.get_token_owner.return_value = {'id': 1, 'username': 'test'}
        mock_evaluate_api.get_user_data.return_value = MagicMock(is_admin=True)
        
        # KEY TEST SCENARIO: API returns None (simulating timeout/rate limit on large instance)
        mock_evaluate_api.getApplicationInfo.return_value = None
        mock_is_error.return_value = (False, None)  # No error flag, but response is None
        
        # Mock version endpoint
        mock_evaluate_api.getVersion.return_value = {'version': '16.0.0'}
        
        # Create ReportGenerator instance
        rg = ReportGenerator(
            host='https://gitlab.example.com',
            token='test-token',
            filename='test_report',
            evaluate_api=mock_evaluate_api
        )
        
        # This should NOT raise TypeError: argument of type 'NoneType' is not iterable
        # Before the fix, this would crash. After the fix, it logs a warning and continues.
        try:
            rg.get_app_stats(
                source='https://gitlab.example.com',
                token='test-token',
                group_id=None,
                admin=True
            )
            # If we get here without exception, the fix is working
            test_passed = True
        except TypeError as e:
            if "NoneType" in str(e):
                self.fail(
                    f"get_app_stats crashed with TypeError when API returned None. "
                    f"This is the bug from issue #169. Error: {e}"
                )
            raise
        
        self.assertTrue(test_passed, "get_app_stats should handle None response gracefully")

    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.xlsxwriter')
    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.utils')
    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.is_error_message_present')
    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.from_dict')
    def test_from_dict_not_called_when_response_is_none(self, mock_from_dict, mock_is_error, mock_utils, mock_xlsxwriter):
        """
        Verify that from_dict is NOT called when the API response is None.
        This prevents the TypeError crash.
        """
        from gitlab_evaluate.migration_readiness.gitlab.report_generator import ReportGenerator
        
        # Mock workbook and worksheets
        mock_workbook = MagicMock()
        mock_worksheet = MagicMock()
        mock_workbook.add_worksheet.return_value = mock_worksheet
        mock_workbook.add_format.return_value = MagicMock()
        mock_xlsxwriter.Workbook.return_value = mock_workbook
        
        # Mock EvaluateApi
        mock_evaluate_api = MagicMock()
        mock_evaluate_api.get_token_owner.return_value = {'id': 1, 'username': 'test'}
        mock_evaluate_api.get_user_data.return_value = MagicMock(is_admin=True)
        mock_evaluate_api.getApplicationInfo.return_value = None
        mock_evaluate_api.getVersion.return_value = {'version': '16.0.0'}
        
        # API returns no error but None response
        mock_is_error.return_value = (False, None)
        
        rg = ReportGenerator(
            host='https://gitlab.example.com',
            token='test-token',
            filename='test_report',
            evaluate_api=mock_evaluate_api
        )
        
        rg.get_app_stats(
            source='https://gitlab.example.com',
            token='test-token',
            group_id=None,
            admin=True
        )
        
        # from_dict should NOT be called when response is None
        mock_from_dict.assert_not_called()


class TestNoneResponseLogicDirect(unittest.TestCase):
    """
    Direct logic test that doesn't require external dependencies.
    This validates the fix logic independently.
    """
    
    def test_fix_logic_prevents_from_dict_with_none(self):
        """
        Test the exact conditional logic from the fix.
        
        BEFORE fix: if not error:
        AFTER fix:  if not error and resp is not None:
        
        This test verifies the fix prevents from_dict from being called with None.
        """
        # Simulate the scenario: error=False, resp=None
        error = False
        resp = None
        
        # OLD logic (would call from_dict with None -> TypeError)
        old_logic_would_call_from_dict = not error  # True - BUG!
        
        # NEW logic (prevents from_dict call when resp is None)
        new_logic_would_call_from_dict = not error and resp is not None  # False - FIXED!
        
        self.assertTrue(old_logic_would_call_from_dict, 
            "Old logic incorrectly allows from_dict call with None")
        self.assertFalse(new_logic_would_call_from_dict, 
            "New logic correctly prevents from_dict call with None")
    
    def test_fix_logic_allows_valid_response(self):
        """
        Verify the fix doesn't break normal operation with valid responses.
        """
        error = False
        resp = {'projects': '1000', 'users': '500'}  # Valid response
        
        new_logic_would_call_from_dict = not error and resp is not None
        
        self.assertTrue(new_logic_would_call_from_dict,
            "Fix should still allow from_dict for valid responses")
    
    def test_fix_logic_handles_error_case(self):
        """
        Verify the fix preserves existing error handling behavior.
        """
        error = True
        resp = None
        
        new_logic_would_call_from_dict = not error and resp is not None
        
        self.assertFalse(new_logic_would_call_from_dict,
            "Fix should not call from_dict when error is True")


if __name__ == '__main__':
    unittest.main()
