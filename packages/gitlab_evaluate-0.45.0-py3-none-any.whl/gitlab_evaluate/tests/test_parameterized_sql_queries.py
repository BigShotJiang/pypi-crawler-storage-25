"""
Test for parameterized SQL queries in evaluate insert methods.

Verifies that all database insert functions use parameterized queries
instead of string formatting, preventing SQL injection and syntax errors
when data contains special characters (quotes, apostrophes, etc.).
"""
import unittest
import sqlite3
import os
import sys
import tempfile
from unittest.mock import patch, MagicMock
from dataclasses import asdict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gitlab_evaluate.lib.api_models.user import User
from gitlab_evaluate.lib import db_utils
from gitlab_evaluate.migration_readiness.gitlab.data_classes.project import Project
from gitlab_evaluate.migration_readiness.gitlab import constants


def create_test_db(db_path):
    """Create a test database with the same schema as production."""
    con = sqlite3.connect(db_path, check_same_thread=False)
    cur = con.cursor()
    cur.execute(f"CREATE TABLE users({db_utils.schema_from_dataclass(User, primary_key='username')})")
    cur.execute(f"CREATE TABLE projects({db_utils.schema_from_dataclass(Project, primary_key='id')})")
    cur.execute(f"CREATE TABLE flagged_projects({db_utils.schema_from_dataclass(Project, primary_key='id')})")
    cur.execute(f"CREATE TABLE reports({db_utils.schema_from_list(constants.REPORT_HEADERS, primary_key='project')})")
    con.commit()
    con.close()


def make_project_dict(**overrides):
    """Create a minimal valid project dict for insertion."""
    base = {
        'project': 'test-project',
        'id': '1',
        'url': 'https://gitlab.example.com/test',
        'namespace': 'test-namespace',
        'last_activity_at': '2025-01-01',
    }
    base.update(overrides)
    return base


class TestInsertReportData(unittest.TestCase):
    """Test insert_report_data handles special characters safely."""

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.test_dir, 'gitlab.db')
        create_test_db(self.db_path)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.test_dir)

    def _make_evaluate_api(self):
        from gitlab_evaluate.migration_readiness.gitlab.evaluate import EvaluateApi
        api = EvaluateApi.__new__(EvaluateApi)
        return api

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_report_with_double_quotes(self, mock_sqlite):
        """Reason text containing double quotes must not cause syntax error."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        api.insert_report_data('my-project', 'This has "double quotes" in it')

        rows = con.execute("SELECT * FROM reports").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], 'my-project')
        self.assertIn('"double quotes"', rows[0][1])
        con.close()

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_report_with_single_quotes(self, mock_sqlite):
        """Project names with apostrophes must not cause syntax error."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        api.insert_report_data("project's-name", "Clean up user's data")

        rows = con.execute("SELECT * FROM reports").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], "project's-name")
        con.close()

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_report_with_sql_injection_attempt(self, mock_sqlite):
        """SQL injection payloads must be stored as literal strings."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        malicious_project = "'; DROP TABLE reports; --"
        api.insert_report_data(malicious_project, "normal reason")

        # Table should still exist and contain the literal injection string
        rows = con.execute("SELECT * FROM reports").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], malicious_project)
        con.close()

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_report_with_mixed_special_characters(self, mock_sqlite):
        """Strings with backslashes, newlines, and unicode must be stored safely."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        reason = "Line1\nLine2\tTabbed \"quoted\" and 'apostrophed' with \\backslash and émojis 🚀"
        api.insert_report_data('special-proj', reason)

        rows = con.execute("SELECT * FROM reports").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][1], reason)
        con.close()

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_report_with_word_clean(self, mock_sqlite):
        """Reproduce the exact 'near Clean: syntax error' from production."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        # Simulates text that would break unquoted SQL: the word "Clean" after a quote boundary
        reason = 'Project flagged: Clean up "old artifacts" before migration'
        api.insert_report_data('prod-project', reason)

        rows = con.execute("SELECT * FROM reports").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertIn('Clean', rows[0][1])
        con.close()


class TestInsertProjectData(unittest.TestCase):
    """Test insert_project_data handles special characters safely."""

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.test_dir, 'gitlab.db')
        create_test_db(self.db_path)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.test_dir)

    def _make_evaluate_api(self):
        from gitlab_evaluate.migration_readiness.gitlab.evaluate import EvaluateApi
        return EvaluateApi.__new__(EvaluateApi)

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_project_with_special_characters_in_name(self, mock_sqlite):
        """Project names with quotes and special chars must insert safely."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        project = make_project_dict(
            project="team's \"best\" project",
            id='42',
            namespace="org/team's-space"
        )
        api.insert_project_data(project)

        rows = con.execute("SELECT * FROM projects").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], "team's \"best\" project")
        con.close()

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_project_with_sql_injection_in_url(self, mock_sqlite):
        """SQL injection in URL field must be stored as literal text."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        project = make_project_dict(
            url="https://example.com'); DROP TABLE projects; --",
            id='99'
        )
        api.insert_project_data(project)

        rows = con.execute("SELECT * FROM projects").fetchall()
        self.assertEqual(len(rows), 1)
        con.close()


class TestInsertFlaggedProjectData(unittest.TestCase):
    """Test insert_flagged_project_data handles special characters safely."""

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.test_dir, 'gitlab.db')
        create_test_db(self.db_path)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.test_dir)

    def _make_evaluate_api(self):
        from gitlab_evaluate.migration_readiness.gitlab.evaluate import EvaluateApi
        return EvaluateApi.__new__(EvaluateApi)

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_flagged_project_with_quotes(self, mock_sqlite):
        """Flagged project with special characters inserts without error."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        project = make_project_dict(
            project="project \"flagged\" for review",
            id='77'
        )
        api.insert_flagged_project_data(project)

        rows = con.execute("SELECT * FROM flagged_projects").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], 'project "flagged" for review')
        con.close()


class TestInsertUserData(unittest.TestCase):
    """Test insert_user_data handles special characters safely."""

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.test_dir, 'gitlab.db')
        create_test_db(self.db_path)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.test_dir)

    def _make_evaluate_api(self):
        from gitlab_evaluate.migration_readiness.gitlab.evaluate import EvaluateApi
        return EvaluateApi.__new__(EvaluateApi)

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_user_with_apostrophe_in_username(self, mock_sqlite):
        """Usernames with apostrophes must insert without error."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        user = User(
            username="o'brien",
            email="obrien@example.com",
            state="active",
            using_license_seat=True,
            is_admin=False
        )
        api.insert_user_data(user)

        rows = con.execute("SELECT * FROM users").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], "o'brien")
        con.close()

    @patch('gitlab_evaluate.migration_readiness.gitlab.evaluate.utils.sqlite_connection')
    def test_user_with_special_email(self, mock_sqlite):
        """Emails with special characters must insert without error."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        api = self._make_evaluate_api()
        user = User(
            username='testuser',
            email="user+tag'special@example.com",
            state="active",
            using_license_seat=True,
            is_admin=False
        )
        api.insert_user_data(user)

        rows = con.execute("SELECT * FROM users").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertIn("special", rows[0][1])
        con.close()


class TestGetProjectCountFromDb(unittest.TestCase):
    """Test get_project_count_from_db uses parameterized queries."""

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.test_dir, 'gitlab.db')
        create_test_db(self.db_path)
        # Insert test data
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        p = Project(project='p1', id='1', url='u', namespace='n', last_activity_at='d', kind='user')
        values = tuple(p.to_dict().values())
        placeholders = ','.join(['?'] * len(values))
        cur.execute(f"INSERT INTO projects VALUES ({placeholders})", values)
        p2 = Project(project='p2', id='2', url='u', namespace='n', last_activity_at='d', kind='group')
        values2 = tuple(p2.to_dict().values())
        cur.execute(f"INSERT INTO projects VALUES ({placeholders})", values2)
        con.commit()
        con.close()

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        os.rmdir(self.test_dir)

    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.utils.sqlite_connection')
    def test_count_all_projects(self, mock_sqlite):
        """Count all projects when no type filter is given."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        from gitlab_evaluate.migration_readiness.gitlab.report_generator import ReportGenerator
        rg = ReportGenerator.__new__(ReportGenerator)
        count = rg.get_project_count_from_db()
        self.assertEqual(count, 2)
        con.close()

    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.utils.sqlite_connection')
    def test_count_filtered_projects(self, mock_sqlite):
        """Count projects filtered by type."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        from gitlab_evaluate.migration_readiness.gitlab.report_generator import ReportGenerator
        rg = ReportGenerator.__new__(ReportGenerator)
        count = rg.get_project_count_from_db(project_type='user')
        self.assertEqual(count, 1)
        con.close()

    @patch('gitlab_evaluate.migration_readiness.gitlab.report_generator.utils.sqlite_connection')
    def test_count_with_sql_injection_attempt(self, mock_sqlite):
        """SQL injection in project_type must not execute."""
        con = sqlite3.connect(self.db_path)
        mock_sqlite.return_value = (con, con.cursor())

        from gitlab_evaluate.migration_readiness.gitlab.report_generator import ReportGenerator
        rg = ReportGenerator.__new__(ReportGenerator)
        count = rg.get_project_count_from_db(project_type="' OR '1'='1")
        self.assertEqual(count, 0)
        con.close()


if __name__ == '__main__':
    unittest.main()
