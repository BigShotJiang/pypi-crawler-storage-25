"""
Unit tests for report_generator column alignment.

The report generator references COLUMNS by hardcoded Excel column letters
(A, B, ... Z, AA, AB, ...). When columns are added, removed, or reordered
in constants.COLUMNS, every letter reference in the report must be updated
in lockstep. These tests catch any drift.
"""
import re
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gitlab_evaluate.migration_readiness.gitlab import constants
from gitlab_evaluate.migration_readiness.gitlab.data_classes.project import Project


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _idx_to_col(idx):
    """Convert a 0-based column index to an Excel column letter (A, B, ... Z, AA, AB, ...)."""
    if idx < 26:
        return chr(65 + idx)
    return chr(65 + idx // 26 - 1) + chr(65 + idx % 26)


def _build_column_map():
    """Return {column_name: excel_letter} from constants.COLUMNS."""
    return {name: _idx_to_col(i) for i, name in enumerate(constants.COLUMNS)}


# ---------------------------------------------------------------------------
# COLUMNS <-> Project dataclass consistency
# ---------------------------------------------------------------------------
class TestColumnsMatchProjectDataclass(unittest.TestCase):
    """constants.COLUMNS must list exactly the fields in Project, in the same order."""

    def test_columns_match_project_fields_and_order(self):
        project_fields = list(Project.__dataclass_fields__.keys())
        self.assertEqual(
            constants.COLUMNS, project_fields,
            "constants.COLUMNS and Project dataclass fields are out of sync "
            "(check both names and ordering)"
        )

    def test_column_count(self):
        self.assertEqual(
            len(constants.COLUMNS),
            len(Project.__dataclass_fields__),
            "COLUMNS length differs from Project field count"
        )

    def test_no_duplicate_columns(self):
        self.assertEqual(
            len(constants.COLUMNS),
            len(set(constants.COLUMNS)),
            "constants.COLUMNS contains duplicate entries"
        )


# ---------------------------------------------------------------------------
# Column ordering sanity checks
# ---------------------------------------------------------------------------
class TestColumnOrdering(unittest.TestCase):
    """Verify key columns appear at the expected positions."""

    def setUp(self):
        self.col_map = _build_column_map()

    def _assert_col(self, field_name, expected_letter):
        actual = self.col_map.get(field_name)
        self.assertIsNotNone(actual, f"'{field_name}' not found in COLUMNS")
        self.assertEqual(
            actual, expected_letter,
            f"'{field_name}' expected at column {expected_letter}, got {actual}"
        )

    # Fixed anchor columns that should never move
    def test_project_at_A(self):
        self._assert_col('project', 'A')

    def test_id_at_B(self):
        self._assert_col('id', 'B')

    def test_kind_at_D(self):
        self._assert_col('kind', 'D')

    # Value / _over pairs must be adjacent
    def test_value_over_pairs_adjacent(self):
        """Every *_over column must immediately follow its value column."""
        for i, name in enumerate(constants.COLUMNS):
            if name.endswith('_over'):
                base = name[:-5]  # strip '_over'
                # Find the base column; it may have a different suffix pattern
                # e.g. 'pipelines' -> 'pipelines_over'
                if base in constants.COLUMNS:
                    base_idx = constants.COLUMNS.index(base)
                    self.assertEqual(
                        base_idx + 1, i,
                        f"'{name}' (idx {i}) should immediately follow '{base}' (idx {base_idx})"
                    )

    # Package-related columns in correct order
    def test_package_columns_order(self):
        pkg_cols = ['package_count', 'package_types_in_use', 'packages_size', 'packages_size_over']
        indices = [constants.COLUMNS.index(c) for c in pkg_cols]
        self.assertEqual(indices, sorted(indices), "Package columns are not in order")
        # They must be consecutive
        for pos, (a, b) in enumerate(zip(indices, indices[1:])):
            self.assertEqual(a + 1, b, f"Gap between {pkg_cols[pos]} and {pkg_cols[pos + 1]}")

    # Container-related columns in correct order
    def test_container_columns_order(self):
        ctr_cols = ['container_tag_count', 'container_registry_size', 'container_registry_size_over']
        indices = [constants.COLUMNS.index(c) for c in ctr_cols]
        self.assertEqual(indices, sorted(indices), "Container columns are not in order")
        for pos, (a, b) in enumerate(zip(indices, indices[1:])):
            self.assertEqual(a + 1, b, f"Gap between {ctr_cols[pos]} and {ctr_cols[pos + 1]}")


# ---------------------------------------------------------------------------
# Report generator column references
# ---------------------------------------------------------------------------
class TestReportGeneratorColumnReferences(unittest.TestCase):
    """
    Parse report_generator.py and verify every hardcoded column letter
    matches the field it is supposed to reference in constants.COLUMNS.

    This is the core guard against column-shift bugs.
    """

    @classmethod
    def setUpClass(cls):
        report_path = os.path.join(
            os.path.dirname(__file__), '..', 'migration_readiness', 'gitlab', 'report_generator.py')
        with open(os.path.normpath(report_path)) as f:
            cls.source = f.read()
        cls.col_map = _build_column_map()
        cls.reverse_map = {v: k for k, v in cls.col_map.items()}

    def test_projects_to_review_over_columns(self):
        """
        Each 'projects to review' row checks a *_over column for 'Tru*'.
        Verify the column letter points to an _over field.
        """
        # Pattern: ('Label text', utils.get_countif(..., 'Tru*', 'XX'),
        matches = re.findall(
            r"\('([^']+)',\s*utils\.get_countif\(self\.raw_output\.get_name\(\),\s*'Tru\*',\s*'([A-Z]+)'\)",
            self.source
        )
        self.assertGreater(len(matches), 0, "No projects_to_review Tru* references found")

        for label, col_letter in matches:
            field = self.reverse_map.get(col_letter)
            self.assertIsNotNone(
                field,
                f"'{label}' references column {col_letter} which is beyond COLUMNS range"
            )
            self.assertTrue(
                field.endswith('_over'),
                f"'{label}' references column {col_letter} = '{field}', expected an _over column"
            )

    def test_metrics_sum_columns(self):
        """
        Each metrics SUM row should reference a numeric value column (not _over, not _types).
        """
        matches = re.findall(
            r"\('([^']+)',\s*utils\.get_sum\(self\.raw_output\.get_name\(\),\s*'([A-Z]+)'\)",
            self.source
        )
        self.assertGreater(len(matches), 0, "No metrics SUM references found")

        for label, col_letter in matches:
            field = self.reverse_map.get(col_letter)
            self.assertIsNotNone(
                field,
                f"Metric '{label}' references column {col_letter} which is beyond COLUMNS range"
            )
            self.assertFalse(
                field.endswith('_over'),
                f"Metric '{label}' SUM references _over column {col_letter} = '{field}'"
            )

    def test_metrics_countif_package_type_columns(self):
        """
        Package type COUNTIF rows (generic, maven, npm, ...) must all reference
        the 'package_types_in_use' column.
        """
        expected_col = self.col_map['package_types_in_use']
        matches = re.findall(
            r"\('[^']*Packages',\s*utils\.get_countif\(self\.raw_output\.get_name\(\),\s*'\*[a-z_]+\*',\s*'([A-Z]+)'\)",
            self.source
        )
        self.assertGreater(len(matches), 0, "No package type COUNTIF references found")

        for col_letter in matches:
            self.assertEqual(
                col_letter, expected_col,
                f"Package type COUNTIF references column {col_letter}, "
                f"expected {expected_col} (package_types_in_use)"
            )

    def test_specific_metric_column_mappings(self):
        """Verify specific well-known metric labels point to the correct columns."""
        expected = {
            'Pipelines': 'pipelines',
            'Issues': 'issues',
            'Branches': 'branches',
            'Commits': 'commit_count',
            'Merge Requests': 'merge_requests',
            'Storage Size': 'storage_size',
            'Repos Size': 'repository_size',
            'Wiki Size': 'wiki_size',
            'LFS Objects Size': 'lfs_objects_size',
            'Build Artifacts Size': 'build_artifacts_size',
            'Snippets': 'snippets_size',
            'Uploads Size': 'uploads_size',
            'Tags': 'tags',
            'Packages Count': 'package_count',
            'Packages Size': 'packages_size',
            'Container Tags': 'container_tag_count',
            'Containers Size': 'container_registry_size',
            'Exports Size': 'estimated_export_size',
        }
        matches = re.findall(
            r"\('([^']+)',\s*utils\.get_sum\(self\.raw_output\.get_name\(\),\s*'([A-Z]+)'\)",
            self.source
        )
        found = {label: col for label, col in matches}

        for label, field_name in expected.items():
            col_letter = found.get(label)
            self.assertIsNotNone(col_letter, f"Metric '{label}' not found in report_generator.py")
            expected_letter = self.col_map[field_name]
            self.assertEqual(
                col_letter, expected_letter,
                f"Metric '{label}' references column {col_letter}, "
                f"expected {expected_letter} ({field_name})"
            )

    def test_specific_review_column_mappings(self):
        """Verify specific projects-to-review labels point to the correct _over columns."""
        expected = {
            'Pipelines > 5,000': 'pipelines_over',
            'Issues > 5,000': 'issues_over',
            'Branches > 1,000': 'branches_over',
            'Commits > 50,000': 'commit_count_over',
            'Merge Requests > 5,000': 'merge_requests_over',
            'Storage Size > 20 GB': 'storage_size_over',
            'Repo Size > 5 GB': 'repository_size_over',
            'LFS Objects Size > 5GB': 'lfs_objects_size_over',
            'Build Artifacts Size > 5GB': 'build_artifacts_size_over',
            'Snippets > 1000': 'snippets_size_over',
            'Uploads Size > 5GB': 'uploads_size_over',
            'Tags > 5000': 'tags_over',
            'Packages Size > 20 GB': 'packages_size_over',
            'Containers Size > 20 GB': 'container_registry_size_over',
            'Export Size > 5 GB': 'estimated_export_size_over',
            'Export Size > 10 GB': 'estimated_export_size_s3_over',
        }
        matches = re.findall(
            r"\('([^']+)',\s*utils\.get_countif\(self\.raw_output\.get_name\(\),\s*'Tru\*',\s*'([A-Z]+)'\)",
            self.source
        )
        found = {label: col for label, col in matches}

        for label, field_name in expected.items():
            col_letter = found.get(label)
            self.assertIsNotNone(col_letter, f"Review row '{label}' not found in report_generator.py")
            expected_letter = self.col_map[field_name]
            self.assertEqual(
                col_letter, expected_letter,
                f"Review row '{label}' references column {col_letter}, "
                f"expected {expected_letter} ({field_name})"
            )


# ---------------------------------------------------------------------------
# GraphQL query consistency
# ---------------------------------------------------------------------------
class TestGraphQLQueryConsistency(unittest.TestCase):
    """Verify the GraphQL queries include required fields."""

    @classmethod
    def setUpClass(cls):
        queries_path = os.path.join(
            os.path.dirname(__file__), '..', 'migration_readiness', 'gitlab', 'queries.py')
        with open(os.path.normpath(queries_path)) as f:
            cls.source = f.read()

    def test_container_registry_tag_count_accepts_after_param(self):
        """generate_container_registry_tag_count must accept (full_path, after)."""
        self.assertRegex(
            self.source,
            r'def generate_container_registry_tag_count\(full_path,\s*after\)',
            "generate_container_registry_tag_count is missing the 'after' parameter"
        )

    def test_container_registry_query_has_pagination(self):
        """The container registry query must include pageInfo with endCursor and hasNextPage."""
        # Find the function body
        match = re.search(
            r'def generate_container_registry_tag_count.*?(?=\ndef |\Z)',
            self.source, re.DOTALL)
        self.assertIsNotNone(match)
        body = match.group()
        self.assertIn('pageInfo', body)
        self.assertIn('endCursor', body)
        self.assertIn('hasNextPage', body)

    def test_project_queries_include_container_registry_enabled(self):
        """All project-listing queries should include containerRegistryEnabled."""
        for func_name in ['generate_group_project_query',
                          'generate_all_projects_query',
                          'generate_personal_projects_query']:
            match = re.search(
                rf'def {func_name}.*?(?=\ndef |\Z)',
                self.source, re.DOTALL)
            self.assertIsNotNone(match, f"{func_name} not found")
            self.assertIn(
                'containerRegistryEnabled', match.group(),
                f"{func_name} is missing containerRegistryEnabled"
            )

    def test_project_queries_include_packages_count(self):
        """All project-listing queries should request packages { count ... }."""
        for func_name in ['generate_group_project_query',
                          'generate_all_projects_query',
                          'generate_personal_projects_query']:
            match = re.search(
                rf'def {func_name}.*?(?=\ndef |\Z)',
                self.source, re.DOTALL)
            self.assertIsNotNone(match, f"{func_name} not found")
            body = match.group()
            # Find the packages block and verify it contains 'count'
            pkg_match = re.search(r'packages\s*\{([^}]+)\}', body)
            self.assertIsNotNone(pkg_match, f"{func_name} missing packages block")
            self.assertIn('count', pkg_match.group(1),
                          f"{func_name} packages block is missing 'count'")


if __name__ == '__main__':
    unittest.main()
