"""
Tests for personal namespace project discovery.

The GraphQL `projects` root query may not return personal namespace projects
(projects under a user's namespace like `username/my-project`). These tests
verify that:
1. The `generate_personal_projects_query` produces the correct GraphQL query
2. `get_all_projects_by_graphql` yields personal projects via a second pass
3. Personal projects already seen in the first pass are deduplicated
4. Failures in the personal projects query are handled gracefully
5. The personal projects pass is skipped when scanning a specific group
"""
import unittest
from unittest.mock import MagicMock, patch

from gitlab_evaluate.migration_readiness.gitlab.queries import (
    generate_all_projects_query,
    generate_personal_projects_query,
)


# ---------------------------------------------------------------------------
# Query generation
# ---------------------------------------------------------------------------
class TestGeneratePersonalProjectsQuery(unittest.TestCase):
    """Verify the personal projects GraphQL query structure."""

    def test_query_includes_personal_true_filter(self):
        query = generate_personal_projects_query("")
        self.assertIn("personal:true", query["query"])

    def test_query_includes_pagination_cursor(self):
        cursor = "abc123cursor"
        query = generate_personal_projects_query(cursor)
        self.assertIn(cursor, query["query"])

    def test_query_requests_same_fields_as_all_projects(self):
        """Personal query must request the same node fields as the main query."""
        all_q = generate_all_projects_query("")["query"]
        personal_q = generate_personal_projects_query("")["query"]

        expected_fields = [
            "id", "name", "fullPath", "archived", "lastActivityAt",
            "webUrl", "namespace", "statistics", "packages", "issues",
            "mergeRequests", "pipelines", "pageInfo",
        ]
        for field in expected_fields:
            self.assertIn(field, personal_q,
                          f"Personal query missing field: {field}")
            self.assertIn(field, all_q,
                          f"All-projects query missing field: {field}")

    def test_query_includes_statistics_subfields(self):
        query = generate_personal_projects_query("")["query"]
        for subfield in ["packagesSize", "repositorySize", "storageSize",
                         "commitCount", "containerRegistrySize"]:
            self.assertIn(subfield, query)

    def test_empty_cursor_produces_valid_query(self):
        query = generate_personal_projects_query("")
        self.assertIn('projects(after:""', query["query"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _make_project(pid, full_path, archived=False):
    """Create a minimal GraphQL-style project dict."""
    return {
        "id": f"gid://gitlab/Project/{pid}",
        "name": full_path.split("/")[-1],
        "fullPath": full_path,
        "archived": archived,
        "lastActivityAt": "2025-01-01T00:00:00Z",
        "webUrl": f"https://gitlab.example.com/{full_path}",
        "namespace": {"fullPath": "/".join(full_path.split("/")[:-1])},
        "statistics": {
            "packagesSize": 0, "containerRegistrySize": 0,
            "repositorySize": 100, "wikiSize": 0,
            "lfsObjectsSize": 0, "snippetsSize": 0,
            "uploadsSize": 0, "commitCount": 10,
            "buildArtifactsSize": 0, "storageSize": 100,
        },
        "packages": {"nodes": []},
        "issues": {"count": 5},
        "mergeRequests": {"count": 3},
        "pipelines": {"count": 2},
    }


def _gql_response(projects, has_next=False, end_cursor=""):
    """Wrap project list in a GraphQL-shaped response."""
    return {
        "data": {
            "projects": {
                "nodes": projects,
                "pageInfo": {
                    "endCursor": end_cursor,
                    "hasNextPage": has_next,
                },
            }
        }
    }


def _make_evaluate_api():
    """Create an EvaluateApi instance without hitting __init__."""
    from gitlab_evaluate.migration_readiness.gitlab.evaluate import EvaluateApi
    api = EvaluateApi.__new__(EvaluateApi)
    api.gitlab_api = MagicMock()
    return api


# ---------------------------------------------------------------------------
# get_all_projects_by_graphql integration
# ---------------------------------------------------------------------------
class TestGetAllProjectsIncludesPersonal(unittest.TestCase):
    """Verify the full generator yields both group and personal projects."""

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_yields_group_and_personal_projects(self, mock_safe_json):
        """Both group and personal projects should be yielded."""
        group_proj = _make_project(1, "group/project-a")
        personal_proj = _make_project(2, "alice/my-project")

        main_resp = _gql_response([group_proj])
        personal_resp = _gql_response([personal_proj])
        mock_safe_json.side_effect = [main_resp, personal_resp]

        api = _make_evaluate_api()
        results = list(api.get_all_projects_by_graphql(
            "https://gitlab.example.com", "fake-token"))

        self.assertEqual(len(results), 2)
        paths = {p["fullPath"] for p in results}
        self.assertIn("group/project-a", paths)
        self.assertIn("alice/my-project", paths)

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_deduplicates_projects_seen_in_main_query(self, mock_safe_json):
        """A project returned by both queries should only appear once."""
        shared_proj = _make_project(1, "alice/shared-project")

        main_resp = _gql_response([shared_proj])
        personal_resp = _gql_response([shared_proj])
        mock_safe_json.side_effect = [main_resp, personal_resp]

        api = _make_evaluate_api()
        results = list(api.get_all_projects_by_graphql(
            "https://gitlab.example.com", "fake-token"))

        self.assertEqual(len(results), 1)

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_skips_personal_pass_for_group_scan(self, mock_safe_json):
        """When scanning a specific group, personal projects pass is skipped."""
        group_proj = _make_project(1, "mygroup/project-a")
        group_resp = {
            "data": {
                "group": {
                    "projects": {
                        "nodes": [group_proj],
                        "pageInfo": {
                            "endCursor": "",
                            "hasNextPage": False,
                        },
                    }
                }
            }
        }
        mock_safe_json.side_effect = [group_resp]

        api = _make_evaluate_api()
        results = list(api.get_all_projects_by_graphql(
            "https://gitlab.example.com", "fake-token",
            full_path="mygroup"))

        # Should only call GraphQL once (no personal projects pass)
        self.assertEqual(mock_safe_json.call_count, 1)
        self.assertEqual(len(results), 1)

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_handles_empty_personal_projects(self, mock_safe_json):
        """No personal projects should not cause errors."""
        group_proj = _make_project(1, "group/project-a")

        main_resp = _gql_response([group_proj])
        personal_resp = _gql_response([])
        mock_safe_json.side_effect = [main_resp, personal_resp]

        api = _make_evaluate_api()
        results = list(api.get_all_projects_by_graphql(
            "https://gitlab.example.com", "fake-token"))

        self.assertEqual(len(results), 1)

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_handles_none_response_for_personal_query(self, mock_safe_json):
        """If the personal query returns None, it should log and stop."""
        group_proj = _make_project(1, "group/project-a")

        main_resp = _gql_response([group_proj])
        mock_safe_json.side_effect = [main_resp, None]

        api = _make_evaluate_api()
        results = list(api.get_all_projects_by_graphql(
            "https://gitlab.example.com", "fake-token"))

        # Should still have the group project
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["fullPath"], "group/project-a")

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_handles_exception_in_personal_query(self, mock_safe_json):
        """An exception during personal query should not lose main results."""
        group_proj = _make_project(1, "group/project-a")

        main_resp = _gql_response([group_proj])
        mock_safe_json.side_effect = [main_resp, Exception("GraphQL error")]

        api = _make_evaluate_api()
        results = list(api.get_all_projects_by_graphql(
            "https://gitlab.example.com", "fake-token"))

        # Group project from main query should still be yielded
        self.assertEqual(len(results), 1)


# ---------------------------------------------------------------------------
# _get_personal_projects_by_graphql pagination
# ---------------------------------------------------------------------------
class TestPersonalProjectsPagination(unittest.TestCase):
    """Verify pagination works for the personal projects query."""

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_paginates_through_multiple_pages(self, mock_safe_json):
        """Should follow pagination cursors until hasNextPage is False."""
        proj_page1 = _make_project(10, "alice/proj-1")
        proj_page2 = _make_project(11, "bob/proj-2")

        page1_resp = _gql_response(
            [proj_page1], has_next=True, end_cursor="cursor_page2")
        page2_resp = _gql_response([proj_page2])

        mock_safe_json.side_effect = [page1_resp, page2_resp]

        api = _make_evaluate_api()
        seen = set()
        results = list(
            api._get_personal_projects_by_graphql(
                "https://gitlab.example.com", "fake-token", seen))

        self.assertEqual(len(results), 2)
        self.assertEqual(mock_safe_json.call_count, 2)

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_deduplicates_against_seen_ids(self, mock_safe_json):
        """Projects already in seen_ids should be skipped."""
        proj = _make_project(99, "alice/already-seen")

        personal_resp = _gql_response([proj])
        mock_safe_json.side_effect = [personal_resp]

        api = _make_evaluate_api()
        seen = {"gid://gitlab/Project/99"}
        results = list(
            api._get_personal_projects_by_graphql(
                "https://gitlab.example.com", "fake-token", seen))

        self.assertEqual(len(results), 0)

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_adds_new_ids_to_seen_set(self, mock_safe_json):
        """Newly discovered project IDs should be added to the seen set."""
        proj = _make_project(42, "alice/new-project")

        personal_resp = _gql_response([proj])
        mock_safe_json.side_effect = [personal_resp]

        api = _make_evaluate_api()
        seen = set()
        list(api._get_personal_projects_by_graphql(
            "https://gitlab.example.com", "fake-token", seen))

        self.assertIn("gid://gitlab/Project/42", seen)


# ---------------------------------------------------------------------------
# End-to-end: main query empty, only personal projects exist
# ---------------------------------------------------------------------------
class TestOnlyPersonalProjects(unittest.TestCase):
    """Edge case: instance has zero group projects, only personal ones."""

    @patch("gitlab_evaluate.migration_readiness.gitlab.evaluate.safe_json_response")
    def test_yields_only_personal_when_main_is_empty(self, mock_safe_json):
        personal_proj = _make_project(1, "alice/solo-project")

        main_resp = _gql_response([])
        personal_resp = _gql_response([personal_proj])
        mock_safe_json.side_effect = [main_resp, personal_resp]

        api = _make_evaluate_api()
        results = list(api.get_all_projects_by_graphql(
            "https://gitlab.example.com", "fake-token"))

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["fullPath"], "alice/solo-project")


if __name__ == "__main__":
    unittest.main()
