from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests.auth import HTTPBasicAuth
import requests
import json


class BitbucketCloudEvaluateClient():
    def __init__(self, workspace, token, username=None):
        self.workspace = workspace
        self.base_url = "https://api.bitbucket.org/2.0"

        # Support both authentication methods:
        # - API tokens: Use Basic auth with username:token
        # - OAuth tokens: Use Bearer token
        if username:
            # API token with Basic auth
            self.auth = HTTPBasicAuth(username, token)
            self.headers = {}
        else:
            # OAuth token with Bearer auth
            self.auth = None
            self.headers = {'Authorization': f'Bearer {token}'}

        self.session = self._create_session()

    def _create_session(self):
        """Create requests session with retry logic for resilience."""
        session = requests.Session()
        retries = Retry(total=5,
                        backoff_factor=1,
                        status_forcelist=[500, 502, 503, 504, 429])
        session.mount('http://', HTTPAdapter(max_retries=retries))
        session.mount('https://', HTTPAdapter(max_retries=retries))
        return session

    def _paginate(self, url, params=None):
        """
        Generic pagination handler for Bitbucket Cloud API.
        Follows 'next' URL in response until exhausted.
        Returns list of all 'values' from all pages.
        """
        all_values = []
        while url:
            response = self.session.get(url, headers=self.headers, params=params, auth=self.auth)
            if response.status_code != 200:
                return response  # Return error response

            data = response.json()
            all_values.extend(data.get('values', []))

            # Get next page URL (None if no more pages)
            url = data.get('next')
            params = None  # Clear params after first request

        # Create mock response with aggregated data
        mock_response = requests.Response()
        mock_response.status_code = 200
        mock_response._content = json.dumps({'values': all_values}).encode('utf-8')
        return mock_response

    def get_workspace(self):
        """Get workspace information."""
        url = f"{self.base_url}/workspaces/{self.workspace}"
        return self.session.get(url, headers=self.headers, auth=self.auth)

    def get_repositories(self, params=None):
        """List all repositories in workspace with pagination."""
        url = f"{self.base_url}/repositories/{self.workspace}"
        if params is None:
            params = {'pagelen': 100}
        return self._paginate(url, params)

    def get_projects(self, params=None):
        """List all projects in workspace with pagination."""
        url = f"{self.base_url}/workspaces/{self.workspace}/projects"
        if params is None:
            params = {'pagelen': 100}
        return self._paginate(url, params)

    def get_workspace_members(self, params=None):
        """List workspace members with pagination."""
        url = f"{self.base_url}/workspaces/{self.workspace}/members"
        if params is None:
            params = {'pagelen': 100}
        return self._paginate(url, params)

    def get_pull_requests(self, repo_slug, params=None):
        """Get all pull requests for a repository with pagination."""
        url = f"{self.base_url}/repositories/{self.workspace}/{repo_slug}/pullrequests"
        if params is None:
            params = {'pagelen': 100, 'state': 'ALL'}
        return self._paginate(url, params)

    def get_branches(self, repo_slug, params=None):
        """Get all branches for a repository with pagination."""
        url = f"{self.base_url}/repositories/{self.workspace}/{repo_slug}/refs/branches"
        if params is None:
            params = {'pagelen': 100}
        return self._paginate(url, params)

    def get_commits(self, repo_slug, params=None):
        """Get commits for a repository (first page only for performance)."""
        url = f"{self.base_url}/repositories/{self.workspace}/{repo_slug}/commits"
        if params is None:
            params = {'pagelen': 1}  # Only need the most recent commit
        return self.session.get(url, headers=self.headers, params=params, auth=self.auth)

    def get_issues(self, repo_slug, params=None):
        """Get all issues for a repository with pagination."""
        url = f"{self.base_url}/repositories/{self.workspace}/{repo_slug}/issues"
        if params is None:
            params = {'pagelen': 100}
        return self._paginate(url, params)

    def check_pipeline_file(self, repo_slug, branch='main'):
        """
        Check if bitbucket-pipelines.yml exists in repository.
        Uses HEAD request for efficiency (no content transfer).
        Tries main branch, then master as fallback.

        Returns: Boolean
        """
        url = f"{self.base_url}/repositories/{self.workspace}/{repo_slug}/src/{branch}/bitbucket-pipelines.yml"

        response = self.session.head(url, headers=self.headers, auth=self.auth)

        if response.status_code == 200:
            return True

        # Try master branch as fallback if main failed
        if branch == 'main':
            return self.check_pipeline_file(repo_slug, branch='master')

        return False
