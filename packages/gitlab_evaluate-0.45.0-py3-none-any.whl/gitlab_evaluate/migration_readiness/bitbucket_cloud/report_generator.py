from sys import exit as sys_exit
import datetime
import xlsxwriter
from gitlab_evaluate.lib import utils
from gitlab_evaluate.migration_readiness.bitbucket_cloud.evaluate import BitbucketCloudEvaluateClient


class BitbucketCloudReportGenerator:

    def __init__(self, workspace, token, username=None, filename=None, output_to_screen=False):
        self.workspace = workspace
        self.client = BitbucketCloudEvaluateClient(workspace, token, username=username)
        self.validate_token()

        # Excel workbook setup
        if filename:
            self.workbook = xlsxwriter.Workbook(f'{filename}.xlsx', {'strings_to_urls': False})
        else:
            self.workbook = xlsxwriter.Workbook('bitbucket_cloud_evaluate_report.xlsx', {'strings_to_urls': False})

        self.app_stats = self.workbook.add_worksheet('App Stats')
        self.repositories_sheet = self.workbook.add_worksheet('Repository Details')
        self.users_sheet = self.workbook.add_worksheet('Users')

        # Formats
        self.align_left = self.workbook.add_format({'align': 'left'})
        self.header_format = self.workbook.add_format({
            'bg_color': 'black',
            'font_color': 'white',
            'bold': True,
            'font_size': 10
        })

        # Column definitions
        self.repo_columns = [
            'Repository Name',
            'Clone URL',
            'Size (MB)',
            'Pull Requests',
            'Issues',
            'CI/CD Pipeline',
            'Branches',
            'Last Activity',
            'Project',
            'Is Private'
        ]

        self.user_columns = [
            'Username',
            'Display Name',
            'Account ID'
        ]

        # Write headers
        utils.write_headers(0, self.repositories_sheet, self.repo_columns, self.header_format)
        utils.write_headers(0, self.users_sheet, self.user_columns, self.header_format)

        self.output_to_screen = output_to_screen
        self.using_admin_token = self.is_admin_token()

    def write_workbook(self):
        """Finalize and close workbook."""
        self.app_stats.autofit()
        self.repositories_sheet.autofit()
        self.users_sheet.autofit()
        self.workbook.close()

    def validate_token(self):
        """Verify token is valid before proceeding."""
        response = self.client.get_workspace()
        if response.status_code == 401:
            print("ERROR: Authentication failed.")
            print("For API tokens: Use -u/--username with your Bitbucket username")
            print("For OAuth tokens: Do not provide a username")
            sys_exit(1)
        elif response.status_code == 404:
            print(f"ERROR: Workspace '{self.workspace}' not found.")
            sys_exit(1)
        elif response.status_code != 200:
            print(f"ERROR: Failed to connect: {response.status_code} - {response.text}")
            sys_exit(1)

    def is_admin_token(self):
        """Check if token has admin/workspace permissions."""
        # For Bitbucket Cloud, if we can access workspace members, we have sufficient permissions
        response = self.client.get_workspace_members()
        return response.status_code == 200

    def get_app_stats(self):
        """Fetch and write workspace-level statistics."""
        print("Fetching workspace statistics...")

        # Get workspace info
        workspace_response = self.client.get_workspace()
        workspace_data = workspace_response.json() if workspace_response.status_code == 200 else {}

        # Get counts
        repos_response = self.client.get_repositories()
        repos = repos_response.json().get('values', []) if repos_response.status_code == 200 else []

        projects_response = self.client.get_projects()
        projects = projects_response.json().get('values', []) if projects_response.status_code == 200 else []

        users_response = self.client.get_workspace_members()
        users = users_response.json().get('values', []) if users_response.status_code == 200 else []

        report_stats = [
            ('Basic information from source', workspace_data.get('name', self.workspace)),
            ('Customer', '<CUSTOMERNAME>'),
            ('Date Run', utils.get_date_run()),
            ('Source', 'Bitbucket Cloud'),
            ('Workspace', self.workspace),
            ('Total Repositories', len(repos)),
            ('Total Users', len(users)),
            ('Total Projects', len(projects))
        ]

        for row, stat in enumerate(report_stats):
            self.app_stats.write(row, 0, stat[0])
            self.app_stats.write(row, 1, stat[1])

        return report_stats

    def handle_getting_data(self):
        """Orchestrate main repository data collection."""
        print("Fetching repository data...")

        repos_response = self.client.get_repositories()

        if repos_response.status_code != 200:
            print(f"ERROR: Failed to fetch repositories: {repos_response.status_code}")
            return

        repos = repos_response.json().get('values', [])
        total_repos = len(repos)

        print(f"Found {total_repos} repositories. Processing...")

        for idx, repo in enumerate(repos, 1):
            repo_slug = repo.get('slug', '')
            print(f"Processing repository {idx}/{total_repos}: {repo.get('name', repo_slug)}")
            self.write_repository_data(repo)

    def write_repository_data(self, repo):
        """Collect repository data and write to Excel with error handling."""
        repo_slug = repo.get('slug', '')

        # Initialize default values
        pr_count = 0
        issue_count = 0
        branch_count = 0
        last_activity = 'N/A'
        has_pipeline = 'No'
        repo_size_mb = 0.0

        # Get repository size
        try:
            repo_size_bytes = repo.get('size', 0)
            if repo_size_bytes:
                repo_size_mb = round(repo_size_bytes / (1024 * 1024), 2)
        except (TypeError, ValueError) as e:
            print(f"  Warning: Could not determine size for {repo_slug}: {str(e)}")

        # Get pull requests count
        try:
            prs_response = self.client.get_pull_requests(repo_slug)
            if prs_response.status_code == 200:
                prs = prs_response.json().get('values', [])
                pr_count = len(prs)
        except Exception as e:
            print(f"  Warning: Failed to fetch PRs for {repo_slug}: {str(e)}")

        # Get issues count
        try:
            issues_response = self.client.get_issues(repo_slug)
            if issues_response.status_code == 200:
                issues = issues_response.json().get('values', [])
                issue_count = len(issues)
        except Exception as e:
            print(f"  Warning: Failed to fetch issues for {repo_slug}: {str(e)}")

        # Get branches count
        try:
            branches_response = self.client.get_branches(repo_slug)
            if branches_response.status_code == 200:
                branches = branches_response.json().get('values', [])
                branch_count = len(branches)
        except Exception as e:
            print(f"  Warning: Failed to fetch branches for {repo_slug}: {str(e)}")

        # Get last activity from commits
        try:
            commits_response = self.client.get_commits(repo_slug)
            if commits_response.status_code == 200:
                commits = commits_response.json().get('values', [])
                if commits:
                    # Get the most recent commit date
                    commit_date = commits[0].get('date', '')
                    if commit_date:
                        # Parse ISO date and format it
                        try:
                            dt = datetime.datetime.fromisoformat(commit_date.replace('Z', '+00:00'))
                            last_activity = dt.strftime('%Y-%m-%d %H:%M:%S')
                        except (ValueError, AttributeError):
                            last_activity = commit_date
        except Exception as e:
            print(f"  Warning: Failed to fetch commits for {repo_slug}: {str(e)}")

        # Check for CI/CD pipeline file
        try:
            # Get the main branch name from repo metadata
            main_branch = repo.get('mainbranch', {}).get('name', 'main')
            if self.client.check_pipeline_file(repo_slug, main_branch):
                has_pipeline = 'Yes'
        except Exception as e:
            print(f"  Warning: Failed to check pipeline file for {repo_slug}: {str(e)}")

        # Extract project name
        project_name = 'N/A'
        if 'project' in repo and repo['project']:
            project_name = repo['project'].get('name', 'N/A')

        # Extract clone URL (prefer HTTPS)
        clone_url = 'N/A'
        if 'links' in repo and 'clone' in repo['links']:
            for clone_link in repo['links']['clone']:
                if clone_link.get('name') == 'https':
                    clone_url = clone_link.get('href', 'N/A')
                    break

        # Compile repository data
        repo_data = {
            'Repository Name': repo.get('name', ''),
            'Clone URL': clone_url,
            'Size (MB)': repo_size_mb,
            'Pull Requests': pr_count,
            'Issues': issue_count,
            'CI/CD Pipeline': has_pipeline,
            'Branches': branch_count,
            'Last Activity': last_activity,
            'Project': project_name,
            'Is Private': 'Yes' if repo.get('is_private', False) else 'No'
        }

        try:
            # Write data to workbook
            utils.append_to_workbook(self.repositories_sheet, [repo_data], self.repo_columns)
            if self.output_to_screen:
                print(f"  Repository Data: {repo_data}")
        except Exception as e:
            print(f"  ERROR: Failed to write data for {repo_slug}: {str(e)}")

    def handle_getting_user_data(self):
        """Collect user information."""
        if not self.using_admin_token:
            print("Skipping user data collection (insufficient permissions)")
            return

        print("Fetching user data...")

        users_response = self.client.get_workspace_members()

        if users_response.status_code != 200:
            print(f"Warning: Failed to fetch users: {users_response.status_code}")
            return

        users = users_response.json().get('values', [])

        for user in users:
            # Extract user data from member object
            user_obj = user.get('user', {})

            user_data = {
                'Username': user_obj.get('nickname', user_obj.get('username', 'N/A')),
                'Display Name': user_obj.get('display_name', 'N/A'),
                'Account ID': user_obj.get('account_id', 'N/A')
            }

            utils.append_to_workbook(self.users_sheet, [user_data], self.user_columns)

        print(f"Retrieved {len(users)} users")
