import logging


def set_log_level(level):
    with open('LOGGING_LEVEL', 'w') as f:
        f.write(level)

def get_log_level():
    try:
        with open('LOGGING_LEVEL', 'r') as f:
            return f.read()
    except FileNotFoundError:
        return 'INFO'

def set_all_loggers_level(level):
    """
    Set log level on all gitlab_ps_utils loggers.
    
    This function targets loggers created by the gitlab_ps_utils library, which includes:
    - gitlab_ps_utils.api: The main GitLab API client logger
    - gitlab_ps_utils.api_audit: Audit logger that logs all API requests (e.g., "Generating POST request")
    - gitlab_ps_utils.decorators: Logger for decorator utilities
    - gitlab_ps_utils.processes: Logger for multiprocessing utilities
    
    This is necessary because:
    1. These loggers are created with their own handlers and default levels
    2. The audit logger in particular generates high-volume output (one line per API request)
    3. With multiprocessing (spawn mode), child processes re-import modules and recreate loggers,
       so they need to read the log level from LOGGING_LEVEL file (set by set_log_level)
    
    Args:
        level: Logging level as string (e.g., 'WARNING') or int (e.g., logging.WARNING)
    
    Raises:
        ValueError: If level string is not a valid logging level name
        TypeError: If level is not a string or integer
    """
    # Validate level is a valid logging level
    if isinstance(level, str):
        level_upper = level.upper()
        numeric_level = getattr(logging, level_upper, None)
        if numeric_level is None:
            raise ValueError(f"Invalid logging level: '{level}'. Valid levels: DEBUG, INFO, WARNING, ERROR, CRITICAL")
        level = numeric_level
    elif not isinstance(level, int):
        raise TypeError(f"Logging level must be str or int, got {type(level).__name__}")
    
    # Create a snapshot to avoid RuntimeError if loggers are created during iteration
    for name, logger in list(logging.Logger.manager.loggerDict.items()):
        if isinstance(logger, logging.Logger) and name.startswith('gitlab_ps_utils'):
            logger.setLevel(level)
