"""
Utilities for checking optional dependencies.
"""
from contextlib import contextmanager
from typing import Generator


@contextmanager
def jenkins_imports() -> Generator[None, None, None]:
    """
    Context manager for importing Jenkins optional dependencies with helpful error messages.

    Usage:
        with jenkins_imports():
            from sklearn.cluster import KMeans
            import torch
            import jenkins

    Raises:
        ImportError: If any Jenkins dependencies are missing, with installation instructions.
    """
    try:
        yield
    except ImportError as e:
        missing_module = e.name if hasattr(e, 'name') else 'unknown'
        raise ImportError(
            f"Jenkins dependencies are not installed. "
            f"Install with: pip install 'gitlab-evaluate[jenkins]' or poetry install --extras jenkins. "
            f"Missing: {missing_module}"
        ) from e
