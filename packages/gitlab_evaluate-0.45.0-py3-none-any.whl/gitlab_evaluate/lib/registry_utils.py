from urllib.parse import urlparse
from gitlab_ps_utils.registries import RegistryClient
from gitlab_ps_utils.misc_utils import strip_netloc
from gitlab_evaluate import log

def get_total_size(location, username, token) -> int:
    total_size = 0
    if not location.startswith(('http://', 'https://')):
        location = f"https://{location}"
    registry = strip_netloc(location)
    repo_path = urlparse(location).path.lstrip('/')
    try:
        with RegistryClient(registry, repo=repo_path, concurrency=10, username=username, password=token) as client:
            summary = client.repo_summary()
            for image in summary:
                total_size += image.get('total_size',0)
    except Exception as e:
        log.error(f"Unable to retrieve container size for {location} due to {e}. Returning any data retrieved so far.")

    return total_size

