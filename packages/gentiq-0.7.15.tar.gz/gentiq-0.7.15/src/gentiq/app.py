from __future__ import annotations

from contextlib import asynccontextmanager
from enum import Enum
from typing import Any, TypeVar, overload

import logfire
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic_ai import Agent

from .agent_deps import AgentDeps
from .api.router import api_router
from .auth.base import AuthAdapter
from .engines import DBEngine, StorageEngine
from .env import LOGFIRE_API_KEY, LOGFIRE_TOKEN
from .errors import ErrorCode, GentiqError
from .schemas import User
from .stores import AdminStore, ChatStore, UserStore


T_Context = TypeVar("T_Context")


class GentiqApp[T_Context]:
    """The core application class for the Gentiq framework.

    GentiqApp serves as the central orchestration point, integrating FastAPI,
    PydanticAI, and persistence stores into a cohesive environment for
    building advanced AI-driven applications.

    It automates the setup of:
    - **FastAPI**: A high-performance web API with automatic documentation.
    - **Stores**: High-level abstractions for managing users (`UserStore`), chat history (`ChatStore`), and administration (`AdminStore`).
    - **Engines**: Pluggable persistence backends (SQLite, MongoDB for DB; FileSystem, MinIO for Storage).
    - **Agent Orchestration**: Seamless integration of PydanticAI agents with shared dependencies.
    - **Observability**: Integrated monitoring and tracing with Logfire.

    Example:
        Basic usage with a simple agent:
        ```python
        from gentiq import GentiqApp
        from pydantic_ai import Agent

        agent = Agent('openai:gpt-4o')
        app = GentiqApp(agent, app_name="MyAI")

        # The FastAPI app is available at app.api
        # Run with: uvicorn main:app.api --reload
        ```

        Advanced usage with custom context and dependencies:
        ```python
        from dataclasses import dataclass
        from gentiq import GentiqApp, AgentDeps
        from pydantic_ai import Agent, RunContext

        @dataclass
        class MyContext:
            api_key: str

        agent = Agent[AgentDeps[MyContext]]('openai:gpt-4o')

        @agent.tool
        async def my_tool(ctx: RunContext[AgentDeps[MyContext]]) -> str:
            # Access custom context, stores, and engines via ctx.deps
            return f"Using key: {ctx.deps.context.api_key}"

        app = GentiqApp(
            agent,
            context=MyContext(api_key="secret"),
            db_engine="mongodb",
            storage_engine="minio"
        )
        ```

    Args:
        agent: The primary Agent instance. It must be typed to accept `AgentDeps[T_Context]`
            as its dependencies.
        context: An optional user-defined context object (e.g., config, services).
            This context is injected into agent dependencies and accessible in tools via `deps.context`.
        app_name: An optional name for the application. Used as the FastAPI title and for
            naming default database files. Defaults to "gentiq".
        db_engine: The database backend to use.
            Accepts a string identifier ('sqlite', 'mongodb') or a pre-configured `DBEngine` instance.
            Defaults to "sqlite".
        storage_engine: The storage backend to use.
            Accepts a string ('filesystem', 'minio') or a pre-configured `StorageEngine` instance.
            Defaults to "filesystem".
        use_title_agent: Whether to enable automatic title generation for new conversations.
        title_agent: An optional custom Agent for title generation. If omitted and
            title generation is enabled, a default implementation is used.
        logfire_token: Optional Logfire token for telemetry and monitoring.
        send_to_logfire: Whether to enable Logfire telemetry. Defaults to False.
        auth: The authentication adapter to use. Accepts a string ('jwt') or a
            pre-configured `AuthAdapter` instance. Defaults to "jwt".
    """

    @overload
    def __init__(
        self,
        agent: Agent[AgentDeps[T_Context]],
        context: T_Context,
        app_name: str | None = None,
        db_engine: str | DBEngine = "sqlite",
        storage_engine: str | StorageEngine = "filesystem",
        use_title_agent: bool | None = None,
        title_agent: Agent[Any, str] | None = None,
        logfire_token: str | None = None,
        send_to_logfire: bool = False,
        auth: str | AuthAdapter | None = None,
        extra_admin_permissions: list[str] | None = None,
    ) -> None: ...

    @overload
    def __init__(
        self: GentiqApp[None],
        agent: Agent[AgentDeps[None]],
        context: None = None,
        app_name: str | None = None,
        db_engine: str | DBEngine = "sqlite",
        storage_engine: str | StorageEngine = "filesystem",
        use_title_agent: bool = True,
        title_agent: Agent[Any, str] | None = None,
        logfire_token: str | None = None,
        send_to_logfire: bool = False,
        auth: str | AuthAdapter | None = None,
        extra_admin_permissions: list[str] | None = None,
    ) -> None: ...

    def __init__(
        self,
        agent: Agent[AgentDeps[T_Context]],
        context: Any = None,
        app_name: str | None = None,
        db_engine: str | DBEngine = "sqlite",
        storage_engine: str | StorageEngine = "filesystem",
        title_agent: Agent[Any, str] | None = None,
        logfire_token: str | None = None,
        send_to_logfire: bool = False,
        auth: str | AuthAdapter = "jwt",
        extra_admin_permissions: list[str] | None = None,
    ):
        self.app_name = app_name or "Gentiq App"
        self.api = FastAPI(title=self.app_name, lifespan=self.lifespan)

        self.agent = agent

        self.title_agent = title_agent

        self.context = context
        self.extra_admin_permissions = extra_admin_permissions or []

        # Initialize core components
        db_engine_instance = self._init_db_engine(db_engine)
        storage_engine_instance = self._init_storage_engine(storage_engine)

        self.user_store = UserStore(engine=db_engine_instance)
        self.admin_store = AdminStore(engine=db_engine_instance)
        self.chat_store = ChatStore(
            engine=db_engine_instance, user_store=self.user_store, files_store=storage_engine_instance
        )

        self.auth = self._init_auth(auth)

        self._setup_default_middleware()
        self._setup_default_routes()
        self._setup_exception_handlers()
        self._setup_monitoring(logfire_token, send_to_logfire)

    def _init_db_engine(self, db_engine: str | DBEngine) -> DBEngine:
        """Initialize the database engine."""
        if isinstance(db_engine, DBEngine):
            return db_engine

        from .engines.registry import EngineRegistry

        engine = EngineRegistry.get_db_engine(db_engine, app_name=self.app_name)
        return engine

    def _init_storage_engine(self, storage: str | StorageEngine) -> StorageEngine:
        """Initialize the storage engine."""
        if isinstance(storage, StorageEngine):
            return storage

        from .engines.registry import EngineRegistry

        engine = EngineRegistry.get_storage_engine(storage)
        return engine

    def _init_auth(self, auth: str | AuthAdapter) -> AuthAdapter:
        """Initialize the authentication adapter."""
        if isinstance(auth, AuthAdapter):
            return auth

        if auth == "jwt":
            from .auth.jwt_auth import JWTAuth

            return JWTAuth()
        else:
            raise ValueError(f"Unsupported authentication type: {auth}. Expected 'jwt' or an AuthAdapter instance.")

    def add_middleware(self, middleware_class: type, **options: Any):
        """Add a middleware to the FastAPI application."""
        self.api.add_middleware(middleware_class, **options)

    def add_router(
        self,
        router: Any,
        prefix: str = "",
        tags: list[str | Enum] | None = None,
        dependencies: list[Any] | None = None,
    ):
        """Include an external router into the application."""
        self.api.include_router(router, prefix=prefix, tags=tags, dependencies=dependencies)

    def create_agent_deps(self, user: User) -> AgentDeps[T_Context]:
        """Create a new instance of Agent dependencies for a specific user."""

        return AgentDeps[T_Context](
            user_store=self.user_store,
            chat_store=self.chat_store,
            user=user,
            context=self.context,
        )

    @asynccontextmanager
    async def lifespan(self, app: FastAPI):
        """Manage the FastAPI application lifecycle."""
        app.state.user_store = self.user_store
        app.state.admin_store = self.admin_store
        app.state.chat_store = self.chat_store
        app.state.agent = self.agent
        app.state.title_agent = self.title_agent
        app.state.create_agent_deps = self.create_agent_deps
        app.state.app_name = self.app_name
        app.state.auth = self.auth
        app.state.context = self.context
        app.state.extra_admin_permissions = self.extra_admin_permissions
        yield

    def _setup_default_middleware(self):
        """Configure default middleware."""
        self.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_default_routes(self):
        """Initialize core framework routes."""
        self.add_router(api_router, prefix="/api")

        @self.api.get("/health", tags=["System"])
        async def health_check() -> dict[str, str]:
            return {"status": "healthy"}

    def _setup_exception_handlers(self):
        """Register global exception handlers for the application."""
        from fastapi import Request
        from fastapi.responses import JSONResponse
        from pydantic import ValidationError

        @self.api.exception_handler(GentiqError)
        async def gentiq_error_handler(request: Request, exc: GentiqError):
            return JSONResponse(
                status_code=exc.status_code,
                content={
                    "error": {
                        "code": exc.code,
                        "message": exc.message,
                        "details": exc.details,
                    }
                },
            )

        @self.api.exception_handler(ValidationError)
        async def validation_error_handler(request: Request, exc: ValidationError):
            return JSONResponse(
                status_code=422,
                content={
                    "error": {
                        "code": ErrorCode.VALIDATION_ERROR,
                        "message": "Encountered a validation error with the provided data.",
                        "details": exc.errors(),
                    }
                },
            )

        @self.api.exception_handler(Exception)
        async def general_exception_handler(request: Request, exc: Exception):
            # For unhandled exceptions, we return a generic internal error
            # to avoid leaking sensitive information to the client.
            # LOGFIRE will still capture the full traceback.
            return JSONResponse(
                status_code=500,
                content={
                    "error": {
                        "code": ErrorCode.INTERNAL_ERROR,
                        "message": "An unexpected server error occurred.",
                    }
                },
            )

    def _setup_monitoring(self, logfire_token: str | None = None, send_to_logfire: bool = False):
        """Configure observability and monitoring."""

        if logfire_token or send_to_logfire:
            logfire.configure(
                send_to_logfire="if-token-present",
                api_key=LOGFIRE_API_KEY,
                token=logfire_token or LOGFIRE_TOKEN,
            )
            logfire.instrument_pydantic_ai()
