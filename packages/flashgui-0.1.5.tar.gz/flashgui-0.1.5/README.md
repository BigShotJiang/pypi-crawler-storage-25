# FlashGui ⚡

[📖 Leggi la documentazione](https://flashguilib-debug.github.io/FlushGui/)

**Build Python desktop applications quickly – without the boilerplate.**

FlashGui is a high‑level wrapper around `wxPython` that lets you create professional‑looking windows, text editors, drawing tools, calculators, calendars, clocks, and more with just a few lines of code.  
It uses a simple **proportional layout system** and provides built‑in applications you can use instantly or customise to fit your needs.

---

## 📦 Current version: **0.1.5** (Alpha)

The API is stable and ready for everyday prototyping and small projects. Future updates will add features without breaking existing code.

---

## ✨ Features

- **Rapid development** – a working GUI in 3 lines of code.
- **Ready‑to‑use applications** – `WINDOW`, `NOTEPAD`, `PAINT`, `CALCULATOR`, `CALENDAR`, `CLOCK`.
- **Proportional layout** – widgets resize automatically with the window.
- **Two‑phase customisation** – `Edit()` for visual changes, `Logic()` for callbacks, 'Modify' for modify widgets.
- **Beginner‑friendly** – no complex event loops or deep inheritance trees.
- **Cross‑platform** – runs on Windows, macOS, and Linux.


## 🚀 Quick start

### Installation
pip install FlashGui
Your first window
python

```bash
```python
from FlashGUI import WINDOW

win = WINDOW(title="FlashGUI Demo", size=(2, 2))
win.AddLabel("Hello, FlashGUI!")
win.run()
#A fully working calculator in 6 lines
python
from FlashGUI import CALCULATOR

calc = CALCULATOR(title="My Calculator")
calc.run()
```

📚 Documentation
Complete documentation – including all parameters, customisation options, and examples – is available in the official docs (included with the package or online).

📄 License
FlashGUI is released under the MIT License.
When you distribute your application, you must also include the license texts of its dependencies: wxPython (wxWindows Library Licence) and charset_normalizer (MIT).