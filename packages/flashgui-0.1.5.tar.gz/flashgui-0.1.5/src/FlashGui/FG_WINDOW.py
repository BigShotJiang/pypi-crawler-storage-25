import wx
import wx.adv
import os

_WX_APP = None

def _get_wx_app():
    global _WX_APP
    if _WX_APP is None:
        _WX_APP = wx.App(False)
    return _WX_APP

class _CanvasPanel(wx.Panel):
    def __init__(self, parent, bg=wx.WHITE):
        super().__init__(parent, style=wx.BORDER_NONE)
        self.SetBackgroundColour(bg)
        self.bg = bg
        self.buffer = None
        self.pen_color = wx.BLACK
        self.pen_width = 2
        self.drawing = False
        self.last_pos = None

        self.Bind(wx.EVT_SIZE, self._on_size)
        self.Bind(wx.EVT_LEFT_DOWN, self._on_left_down)
        self.Bind(wx.EVT_LEFT_UP, self._on_left_up)
        self.Bind(wx.EVT_MOTION, self._on_motion)
        self.Bind(wx.EVT_PAINT, self._on_paint)

    def _on_size(self, event):
        size = self.GetClientSize()
        if size.width > 0 and size.height > 0:
            new_bmp = wx.Bitmap(size.width, size.height)
            mdc = wx.MemoryDC(new_bmp)
            mdc.SetBackground(wx.Brush(self.bg))
            mdc.Clear()
            if self.buffer:
                old_dc = wx.MemoryDC(self.buffer)
                mdc.Blit(0, 0, min(size.width, self.buffer.GetWidth()),
                        min(size.height, self.buffer.GetHeight()), old_dc, 0, 0)
                old_dc.SelectObject(wx.NullBitmap)
            self.buffer = new_bmp
        event.Skip()

    def _on_left_down(self, event):
        self.drawing = True
        self.last_pos = event.GetPosition()
        event.Skip()

    def _on_left_up(self, event):
        self.drawing = False
        self.last_pos = None
        event.Skip()

    def _on_motion(self, event):
        if event.Dragging() and event.LeftIsDown() and self.drawing and self.last_pos and self.buffer:
            pos = event.GetPosition()
            dc = wx.MemoryDC(self.buffer)
            dc.SetPen(wx.Pen(self.pen_color, self.pen_width))
            dc.DrawLine(self.last_pos.x, self.last_pos.y, pos.x, pos.y)
            del dc
            self.last_pos = pos
            self.Refresh()
        event.Skip()

    def _on_paint(self, event):
        if self.buffer:
            wx.BufferedPaintDC(self, self.buffer)

    def SetPen(self, color=None, width=None):
        if color is not None:
            if isinstance(color, (tuple, list)):
                self.pen_color = wx.Colour(*color[:3])
            else:
                self.pen_color = color
        if width is not None:
            self.pen_width = int(width)

    def Clear(self, color=None):
        if color is not None:
            if isinstance(color, (tuple, list)):
                self.bg = wx.Colour(*color[:3])
            else:
                self.bg = color
        self.SetBackgroundColour(self.bg)
        if self.buffer:
            dc = wx.MemoryDC(self.buffer)
            dc.SetBackground(wx.Brush(self.bg))
            dc.Clear()
            del dc
            self.Refresh()

class _WidgetHandle:
    def __init__(self, window, widget):
        object.__setattr__(self, "_window", window)
        object.__setattr__(self, "_widget", widget)

    def __getattr__(self, name):
        return getattr(self._widget, name)

    def __setattr__(self, name, value):
        if name in {"_window", "_widget"}:
            object.__setattr__(self, name, value)
        else:
            setattr(self._widget, name, value)

    def __repr__(self):
        return repr(self._widget)

    def Modify(self, *args, **kwargs):
        if hasattr(self._widget, "Modify"):
            return self._widget.Modify(*args, **kwargs)

    def SetText(self, text):
        if hasattr(self._widget, "SetLabel"):
            return self._widget.SetLabel(str(text))
        elif hasattr(self._widget, "SetValue"):
            return self._widget.SetValue(str(text))
        elif hasattr(self._widget, "Modify"):
            return self._widget.Modify(text=text)

    @property
    def widget(self):
        return self._widget

class _CustomTabs(wx.Panel):
    def __init__(self, parent, bg_color, window_ref):
        super().__init__(parent)
        self.window_ref = window_ref
        self.SetBackgroundColour(bg_color)
        self.main_sizer = wx.BoxSizer(wx.VERTICAL)

        self.nav_panel = wx.Panel(self)
        self.nav_panel.SetBackgroundColour(bg_color)
        self.nav_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.nav_panel.SetSizer(self.nav_sizer)

        self.content_container = wx.Panel(self)
        self.content_container.SetBackgroundColour(bg_color)
        self.content_sizer = wx.BoxSizer(wx.VERTICAL)
        self.content_container.SetSizer(self.content_sizer)

        self.main_sizer.Add(self.nav_panel, 0, wx.EXPAND)
        self.main_sizer.Add(self.content_container, 1, wx.EXPAND)
        self.SetSizer(self.main_sizer)

        self._pages_list = []
        self._buttons_list = []

    def AddPage(self, title, color, bg, active_fg, size_text):
        inactive_c = self.window_ref._to_colour(color)
        active_c = self.window_ref._to_colour(active_fg)
        page_bg = self.window_ref._to_colour(bg)

        btn = wx.Button(self.nav_panel, label=str(title), style=wx.BORDER_NONE)
        btn.SetForegroundColour(inactive_c)
        btn.SetBackgroundColour(self.nav_panel.GetBackgroundColour())
        
        btn._base_font_size = size_text if size_text else 1.0
        btn._active_fg = active_c
        btn._inactive_fg = inactive_c

        page = wx.Panel(self.content_container)
        page.SetBackgroundColour(page_bg)

        self.nav_sizer.Add(btn, 1, wx.EXPAND | wx.ALL, 2)
        self.content_sizer.Add(page, 1, wx.EXPAND)

        self._pages_list.append(page)
        self._buttons_list.append(btn)

        index = len(self._pages_list) - 1
        btn.Bind(wx.EVT_BUTTON, lambda e, idx=index: self._switch_page(idx))

        if index > 0:
            page.Hide()
        else:
            btn.SetForegroundColour(active_c)

        main_w, _ = self.window_ref.panel.GetClientSize()
        base = max(8, int(main_w * 0.02))
        self._update_button_fonts(base)
        self.Layout()
        return page
    
    def _update_button_fonts(self, base_font_size=10):
        for btn in self._buttons_list:
            font = btn.GetFont()
            new_size = max(6, int(base_font_size * btn._base_font_size))
            font.SetPointSize(new_size)
            btn.SetFont(font)
        self.nav_panel.Layout()

    def _switch_page(self, index):
        for i, page in enumerate(self._pages_list):
            btn = self._buttons_list[i]
            if i == index:
                page.Show()
                btn.SetForegroundColour(btn._active_fg)
            else:
                page.Hide()
                btn.SetForegroundColour(btn._inactive_fg)
        self.content_container.Layout()
        self.window_ref._request_layout()

class WINDOW:
    _CURSORS = {
        "default": wx.CURSOR_DEFAULT,
        "hand": wx.CURSOR_HAND,
        "ibeam": wx.CURSOR_IBEAM,
        "cross": wx.CURSOR_CROSS,
        "wait": wx.CURSOR_WAIT,
        "sizenesw": wx.CURSOR_SIZENESW,
        "sizenwse": wx.CURSOR_SIZENWSE,
        "sizens": wx.CURSOR_SIZENS,
        "sizewe": wx.CURSOR_SIZEWE,
        "no": wx.CURSOR_NO_ENTRY,
    }

    _ALIGNMENTS = {
        "left": wx.ALIGN_LEFT,
        "center": wx.ALIGN_CENTER,
        "right": wx.ALIGN_RIGHT,
    }

    def __init__(self, title="Window", size=(2,2), color=(240,240,240),
             icon=None, maximized=False, min_size=(5,4), max_size=(1,1), style="light"):

        self.app = _get_wx_app()
        self.title = title
        self.style = style.lower()
        if self.style == "dark":
            color = "#242424"
        self.base_color = self._get_default_color('bg', color)
        self.widgets = []
        self._pending_resize = None
        self._resize_delay_ms = 80
        self._accelerators = []
        self._timers = []
        self._rb_group_open = False

        screen_w, screen_h = wx.GetDisplaySize()
        w = self._calc_size(size[0], screen_w)
        h = self._calc_size(size[1], screen_h)

        self.frame = wx.Frame(None, title=title, size=(w, h))
        self.frame.SetBackgroundColour(self.base_color)

        self._resize_timer = wx.Timer(self.frame)
        self.frame.Bind(wx.EVT_TIMER, self._on_resize_timer, self._resize_timer)

        min_w = self._calc_size(min_size[0], screen_w, as_divisor=True)
        min_h = self._calc_size(min_size[1], screen_h, as_divisor=True)
        max_w = self._calc_size(max_size[0], screen_w, as_divisor=True)
        max_h = self._calc_size(max_size[1], screen_h, as_divisor=True)
        self.frame.SetMinSize((min_w, min_h))
        self.frame.SetMaxSize((max_w, max_h))

        if maximized:
            self.frame.Maximize(True)

        if icon and os.path.exists(icon):
            ext = os.path.splitext(icon)[1].lower()
            icon_type = wx.BITMAP_TYPE_PNG if ext == '.png' else wx.BITMAP_TYPE_ICO
            self.frame.SetIcon(wx.Icon(icon, icon_type))

        self.panel = wx.Panel(self.frame)
        self.panel.SetBackgroundColour(self.base_color)
        self.panel.SetDoubleBuffered(True)

        self.frame.Bind(wx.EVT_SIZE, self._on_frame_size)
        self.frame.Bind(wx.EVT_CLOSE, self._on_close)
        self.frame.Centre()
        self.frame.Show()
        self.frame.Bind(wx.EVT_MAXIMIZE, self._on_maximize)

    def _get_default_color(self, color_type, user_value=None):
        if user_value is not None:
            return self._to_colour(user_value)
        if self.style == "dark":
            dark_colors = {
                'bg': (50, 50, 50),
                'fg': (240, 240, 240),
                'btn_bg': (70, 70, 70),
                'btn_fg': (240, 240, 240),
                'input_bg': (60, 60, 60),
                'input_fg': (240, 240, 240),
                'tabs_bg': (45, 45, 45),
                'tabs_inactive_fg': (160, 160, 160),
                'tabs_active_fg': (100, 180, 255),
                'page_bg': (50, 50, 50),
                'canvas_bg': (30, 30, 30),
                'status_bg': (40, 40, 40),
                'status_fg': (220, 220, 220),
                'status_highlight': (40, 40, 40),
            }
            return wx.Colour(*dark_colors.get(color_type, (50,50,50)))
        return None

    def _calc_size(self, value, screen_dim, as_divisor=False):
        try:
            v = float(value)
        except:
            v = 1.0
        if v <= 0:
            v = 1.0
        if as_divisor or v <= 20:
            return int(screen_dim / v)
        else:
            return int(v)

    def _to_colour(self, val):
        if isinstance(val, wx.Colour):
            return val
        if isinstance(val, (tuple, list)) and len(val) >= 3:
            return wx.Colour(*val[:3])
        if isinstance(val, str):
            try:
                return wx.Colour(val)
            except:
                pass
        return wx.Colour(240, 240, 240)

    def _unwrap_widget(self, widget):
        return widget.widget if isinstance(widget, _WidgetHandle) else widget

    def _apply_common_props(self, widget, tooltip, enabled, visible, cursor):
        if tooltip:
            widget.SetToolTip(tooltip)
        if not enabled:
            widget.Enable(False)
        if not visible:
            widget.Hide()
        if cursor:
            widget.SetCursor(self._get_cursor(cursor) if not isinstance(cursor, wx.Cursor) else cursor)

    def _infer_widget_kind(self, widget):
        if isinstance(widget, wx.StaticText):
            return "label"
        if isinstance(widget, wx.Button):
            return "button"
        if isinstance(widget, wx.TextCtrl):
            if widget.HasFlag(wx.TE_MULTILINE):
                return "textarea"
            return "input"
        if isinstance(widget, wx.SpinCtrl):
            return "counter"
        if isinstance(widget, wx.adv.CalendarCtrl):
            return "calendar"
        if isinstance(widget, wx.Slider):
            return "slider"
        if isinstance(widget, wx.ColourPickerCtrl):
            return "colorpicker"
        if isinstance(widget, wx.CheckBox):
            return "checkbox"
        if isinstance(widget, wx.RadioButton):
            return "radiobutton"
        if isinstance(widget, wx.ComboBox):
            return "combobox"
        if isinstance(widget, wx.ListBox):
            return "listbox"
        if isinstance(widget, _CanvasPanel):
            return "canvas"
        if isinstance(widget, _CustomTabs):
            return "tabs"
        if isinstance(widget, wx.Panel):
            return "page"
        return "generic"

    def _refresh_widget(self, widget):
        if hasattr(widget, "Refresh"):
            widget.Refresh()
        if hasattr(widget, "Update"):
            widget.Update()

    def _set_widget_text(self, widget, text):
        if hasattr(widget, "SetLabel"):
            widget.SetLabel(str(text))
        elif hasattr(widget, "SetValue"):
            widget.SetValue(str(text))

    def _set_widget_colour(self, widget, attr, value):
        if value is None:
            return
        colour = self._to_colour(value)
        if attr == "bg" and hasattr(widget, "SetBackgroundColour"):
            widget.SetBackgroundColour(colour)
        elif attr == "fg" and hasattr(widget, "SetForegroundColour"):
            widget.SetForegroundColour(colour)

    def _update_layout_item(self, item, relx=None, rely=None, relwidth=None, relheight=None, font_scale=None):
        if item is None:
            return
        if relx is not None:
            item["relx"] = relx
        if rely is not None:
            item["rely"] = rely
        if relwidth is not None:
            item["relwidth"] = relwidth
        if relheight is not None:
            item["relheight"] = relheight
        if font_scale is not None:
            item["font_scale"] = font_scale

    def _attach_modify(self, widget, item=None, kind=None):
        kind = kind or self._infer_widget_kind(widget)

        def apply_common(relx=None, rely=None, relwidth=None, relheight=None, font_scale=None, tooltip=None, enabled=None, visible=None, cursor=None, bg=None, fg=None):
            changed_layout = False
            if item is not None:
                if relx is not None:
                    item["relx"] = relx
                    changed_layout = True
                if rely is not None:
                    item["rely"] = rely
                    changed_layout = True
                if relwidth is not None:
                    item["relwidth"] = relwidth
                    changed_layout = True
                if relheight is not None:
                    item["relheight"] = relheight
                    changed_layout = True
                if font_scale is not None:
                    item["font_scale"] = font_scale
                    changed_layout = True
            if tooltip is not None:
                widget.SetToolTip(tooltip)
            if enabled is not None:
                widget.Enable(bool(enabled))
            if visible is not None:
                widget.Show(bool(visible))
            if cursor is not None:
                widget.SetCursor(self._get_cursor(cursor) if not isinstance(cursor, wx.Cursor) else cursor)
            if bg is not None and hasattr(widget, "SetBackgroundColour"):
                widget.SetBackgroundColour(self._to_colour(bg))
            if fg is not None and hasattr(widget, "SetForegroundColour"):
                widget.SetForegroundColour(self._to_colour(fg))
            if changed_layout:
                self._request_layout()
            else:
                self._refresh_widget(widget)

        if kind == "label":
            def Modify(text=None, color=None, bg=None, font_scale=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if text is not None:
                    self._set_widget_text(widget, text)
                apply_common(relx, rely, relwidth, relheight, font_scale, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind == "button":
            def Modify(text=None, color=None, bg=None, bold=None, font_scale=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if text is not None:
                    self._set_widget_text(widget, text)
                if bold is not None and hasattr(widget, "GetFont") and hasattr(widget, "SetFont"):
                    f = widget.GetFont()
                    f.SetWeight(wx.FONTWEIGHT_BOLD if bold else wx.FONTWEIGHT_NORMAL)
                    widget.SetFont(f)
                apply_common(relx, rely, relwidth, relheight, font_scale, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind in ("input", "textarea"):
            def Modify(text=None, hint=None, readonly=None, color=None, bg=None, font_scale=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if text is not None:
                    widget.SetValue(str(text))
                if hint is not None and hasattr(widget, "SetHint"):
                    widget.SetHint(str(hint))
                if readonly is not None:
                    widget.SetEditable(not bool(readonly))
                apply_common(relx, rely, relwidth, relheight, font_scale, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind == "counter":
            def Modify(value=None, min_val=None, max_val=None, step=None, color=None, bg=None, font_scale=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if min_val is not None or max_val is not None:
                    current_min = min_val if min_val is not None else widget.GetMin()
                    current_max = max_val if max_val is not None else widget.GetMax()
                    widget.SetRange(int(current_min), int(current_max))
                if step is not None and hasattr(widget, "SetIncrement"):
                    widget.SetIncrement(step)
                if value is not None:
                    widget.SetValue(int(value))
                apply_common(relx, rely, relwidth, relheight, font_scale, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind == "calendar":
            def Modify(date=None, color=None, bg=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if date is not None and hasattr(widget, "SetDate"):
                    if isinstance(date, wx.DateTime):
                        widget.SetDate(date)
                apply_common(relx, rely, relwidth, relheight, 1.0, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind == "slider":
            def Modify(value=None, min_val=None, max_val=None, color=None, bg=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if min_val is not None or max_val is not None:
                    current_min = min_val if min_val is not None else widget.GetMin()
                    current_max = max_val if max_val is not None else widget.GetMax()
                    widget.SetRange(int(current_min), int(current_max))
                if value is not None:
                    widget.SetValue(int(value))
                apply_common(relx, rely, relwidth, relheight, 1.0, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind == "colorpicker":
            def Modify(color=None, bg=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if color is not None:
                    widget.SetColour(self._to_colour(color))
                apply_common(relx, rely, relwidth, relheight, 1.0, tooltip, enabled, visible, cursor, bg, None)
            widget.Modify = Modify
            return widget

        if kind in ("checkbox", "radiobutton"):
            def Modify(text=None, checked=None, color=None, bg=None, font_scale=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if text is not None:
                    widget.SetLabel(str(text))
                if checked is not None:
                    widget.SetValue(bool(checked))
                apply_common(relx, rely, relwidth, relheight, font_scale, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind == "combobox":
            def Modify(value=None, choices=None, color=None, bg=None, font_scale=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if choices is not None and hasattr(widget, "SetItems"):
                    widget.SetItems([str(x) for x in choices])
                if value is not None:
                    widget.SetValue(str(value))
                apply_common(relx, rely, relwidth, relheight, font_scale, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind == "listbox":
            def Modify(choices=None, selection=None, color=None, bg=None, font_scale=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None):
                if choices is not None and hasattr(widget, "SetItems"):
                    widget.SetItems([str(x) for x in choices])

                if selection is not None:
                    if isinstance(selection, (list, tuple, set)) and hasattr(widget, "SetSelections"):
                        idxs = []
                        for sel in selection:
                            if isinstance(sel, int):
                                idxs.append(sel)
                            else:
                                try:
                                    idxs.append(widget.FindString(str(sel)))
                                except:
                                    pass
                        if idxs:
                            widget.SetSelections(idxs)
                    else:
                        if isinstance(selection, int):
                            widget.SetSelection(selection)
                        else:
                            try:
                                widget.SetStringSelection(str(selection))
                            except:
                                pass

                apply_common(relx, rely, relwidth, relheight, font_scale, tooltip, enabled, visible, cursor, bg, color)
            widget.Modify = Modify
            return widget

        if kind in ("canvas", "page", "tabs", "generic"):
            def Modify(bg=None, fg=None, tooltip=None, enabled=None, visible=None, cursor=None, relx=None, rely=None, relwidth=None, relheight=None, font_scale=None):
                apply_common(relx, rely, relwidth, relheight, font_scale, tooltip, enabled, visible, cursor, bg, fg)
            widget.Modify = Modify
            return widget

        def Modify(**kwargs):
            apply_common(kwargs.get("relx"), kwargs.get("rely"), kwargs.get("relwidth"), kwargs.get("relheight"), kwargs.get("font_scale"), kwargs.get("tooltip"), kwargs.get("enabled"), kwargs.get("visible"), kwargs.get("cursor"), kwargs.get("bg"), kwargs.get("fg"))
        widget.Modify = Modify
        return widget

    def _force_layout_update(self):
        self.frame.Layout()
        self.panel.Layout()
        self.panel.SendSizeEvent()

        for item in self.widgets:
            widget = item['widget']
            if isinstance(widget, wx.Notebook):
                widget.Layout()
                for page_idx in range(widget.GetPageCount()):
                    page = widget.GetPage(page_idx)
                    page.Layout()
                    page.SetSize(page.GetSize())
                    page.Refresh()
            elif isinstance(widget, _CustomTabs):
                widget.Layout()
                for page in widget._pages_list:
                    page.Layout()
                    page.SetSize(page.GetSize())
                    page.Refresh()
            elif hasattr(widget, 'Layout'):
                widget.Layout()

        self._apply_proportional_layout()
        self.panel.Refresh()

    def _request_layout(self):
        wx.CallAfter(self._force_layout_update)

    def _on_frame_size(self, event):
        event.Skip()
        wx.CallAfter(self._apply_proportional_layout)

    def _on_maximize(self, event):
        event.Skip()
        if self._resize_timer.IsRunning():
            self._resize_timer.Stop()
        self._resize_timer.StartOnce(self._resize_delay_ms)

    def _on_resize_timer(self, event):
        if self.widgets:
            self._apply_proportional_layout()


    def _apply_proportional_layout(self):
        main_w, main_h = self.panel.GetClientSize()
        if main_w <= 0 or main_h <= 0:
            return

        base_font_size = max(8, min(18, int(main_w * 0.015)))

        if hasattr(self, "status_bar") and self.status_bar:
            label = getattr(self, "_status_label", None)
            h_scale = getattr(self.status_bar, "_height_scale", 1.0)

            min_status_h = 22
            max_status_h = max(28, int(main_h * 0.08))
            preferred_h = int(main_h * 0.032 * max(0.5, h_scale))

            text_h = 0
            text_w = 0

            if label:
                text_ratio = getattr(label, "_text_size_ratio", 0.5)
                font_scale = getattr(label, "_font_scale", 1.0)
                font_pixel_height = max(8, int(main_h * 0.018 * text_ratio * font_scale))

                font = label.GetFont()
                try:
                    font.SetPixelSize((0, font_pixel_height))
                except Exception:
                    font.SetPointSize(max(6, int(font_pixel_height * 0.75)))
                label.SetFont(font)

                try:
                    text_w, text_h = label.GetTextExtent(label.GetLabel())
                except Exception:
                    text_w, text_h = 0, font_pixel_height

            status_h = max(min_status_h, preferred_h, text_h + max(8, int(main_h * 0.006)) * 2)
            status_h = min(status_h, max_status_h)

            self.status_bar.SetMinSize((-1, status_h))
            self.status_bar.Layout()
            self.frame.Layout()

            if label:
                sb_w, sb_h = self.status_bar.GetClientSize()
                if sb_w > 0 and sb_h > 0:
                    relw = getattr(label, "_relwidth", None)
                    if relw is not None:
                        desired_w = max(1, int(sb_w * relw))
                        label.SetMinSize((desired_w, -1))
                        try:
                            label.SetSize(desired_w, -1)
                        except Exception:
                            pass
                        try:
                            text_w, text_h = label.GetTextExtent(label.GetLabel())
                        except Exception:
                            pass
                        text_w = min(text_w, desired_w)
                    else:
                        label.SetMinSize((-1, -1))
                        try:
                            text_w, text_h = label.GetTextExtent(label.GetLabel())
                        except Exception:
                            pass

                    rx = getattr(label, "_relx", 0.5)
                    ry = getattr(label, "_rely", 0.5)

                    pos_x = max(0, int((sb_w - text_w) * rx))
                    pos_y = max(0, int((sb_h - text_h) * ry))

                    label.SetPosition((pos_x, pos_y))
                    label.Refresh()

        for item in self.widgets:
            widget = item["widget"]
            if isinstance(widget, _CustomTabs):
                widget._update_button_fonts(base_font_size)

            parent = widget.GetParent()
            if not parent:
                continue

            pw, ph = parent.GetClientSize()
            if pw <= 0 or ph <= 0:
                continue

            relx = item.get("relx", 0.0)
            rely = item.get("rely", 0.0)
            relw = item.get("relwidth", 0.1)
            relh = item.get("relheight", 0.1)

            x = int(relx * pw)
            y = int(rely * ph)
            width = int(relw * pw)
            height = int(relh * ph)

            width = max(width, 10)
            height = max(height, 10)

            widget.SetSize(x, y, width, height)

            if hasattr(widget, "SetFont"):
                font = widget.GetFont()
                factor = item.get("font_scale", 1.0)
                new_size = int(base_font_size * factor)
                font.SetPointSize(max(6, new_size))
                widget.SetFont(font)

        self.panel.Refresh()
        self.panel.Layout()

    def _add_widget(self, widget, relx, rely, relwidth, relheight, font_scale=1.0,
                tooltip=None, enabled=True, visible=True, cursor=None,
                fg=None, bg=None, font=None, border=None, parent=None):

        target = self._unwrap_widget(parent) if parent else self.panel
        if target is None:
            target = self.panel

        widget.Reparent(target)

        default_fg = self._get_default_color('fg') if self.style == "dark" else None
        default_bg = self._get_default_color('bg') if self.style == "dark" else None
        if fg is None and default_fg and hasattr(widget, 'SetForegroundColour'):
            widget.SetForegroundColour(default_fg)
        elif fg and hasattr(widget, 'SetForegroundColour'):
            widget.SetForegroundColour(self._to_colour(fg))
        if bg is None and default_bg and hasattr(widget, 'SetBackgroundColour'):
            widget.SetBackgroundColour(default_bg)
        elif bg and hasattr(widget, 'SetBackgroundColour'):
            widget.SetBackgroundColour(self._to_colour(bg))

        if font and hasattr(widget, 'SetFont'):
            if isinstance(font, wx.Font):
                widget.SetFont(font)
            elif isinstance(font, dict):
                f = widget.GetFont()
                if 'family' in font: f.SetFamily(font['family'])
                if 'size' in font: f.SetPointSize(font['size'])
                if 'weight' in font: f.SetWeight(font['weight'])
                if 'style' in font: f.SetStyle(font['style'])
                if 'underline' in font: f.SetUnderlined(font['underline'])
                widget.SetFont(f)

        if border is not None and hasattr(widget, 'SetWindowStyleFlag'):
            style = widget.GetWindowStyleFlag()
            if border > 0:
                style |= wx.BORDER_SIMPLE
            else:
                style &= ~wx.BORDER_SIMPLE
            widget.SetWindowStyleFlag(style)

        self._apply_common_props(widget, tooltip, enabled, visible, cursor)

        item = {
            'widget': widget,
            'relx': relx,
            'rely': rely,
            'relwidth': relwidth,
            'relheight': relheight,
            'font_scale': font_scale
        }
        self.widgets.append(item)
        self._attach_modify(widget, item=item)
        self._request_layout()
        return _WidgetHandle(self, widget)

    def _get_cursor(self, name):
        if name is None:
            return None
        if isinstance(name, wx.Cursor):
            return name
        if isinstance(name, str):
            name_lower = name.lower()
            if name_lower in self._CURSORS:
                return wx.Cursor(self._CURSORS[name_lower])
        return wx.Cursor(wx.CURSOR_DEFAULT)

    def _get_alignment(self, align):
        if align is None:
            return wx.ALIGN_LEFT
        if isinstance(align, str):
            return self._ALIGNMENTS.get(align.lower(), wx.ALIGN_LEFT)
        return align
    
    def _get_listbox_values(self, lb):
        selections = lb.GetSelections()
        return [lb.GetString(i) for i in selections]

    def AddLabel(self, text="Label", relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                 font_scale=1.0, bold=False, color=None, bg=None, alignment="left",
                 tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        style = self._get_alignment(alignment)
        lbl = wx.StaticText(self.panel, label=str(text), style=style)
        if bold:
            f = lbl.GetFont()
            f.SetWeight(wx.FONTWEIGHT_BOLD)
            lbl.SetFont(f)
        final_color = color if color is not None else self._get_default_color('fg')
        final_bg = bg if bg is not None else self._get_default_color('bg')
        lbl = self._add_widget(lbl, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), final_color, final_bg, parent=parent)
        return lbl

    def AddButton(self, text="Button", relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                  command=None, font_scale=1.0, bold=False, color=None, bg=None,
                  tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        btn = wx.Button(self.panel, label=str(text))
        if bold:
            f = btn.GetFont()
            f.SetWeight(wx.FONTWEIGHT_BOLD)
            btn.SetFont(f)
        if command:
            btn.Bind(wx.EVT_BUTTON, lambda e: command())
        final_color = color if color is not None else self._get_default_color('btn_fg')
        final_bg = bg if bg is not None else self._get_default_color('btn_bg')
        return self._add_widget(btn, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), final_color, final_bg, parent=parent)

    def AddInput(self, relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                 text="", hint="", password=False, readonly=False, font_scale=1.0,
                 color=None, bg=None, tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        style = wx.TE_PROCESS_ENTER
        if password:
            style |= wx.TE_PASSWORD
        if readonly:
            style |= wx.TE_READONLY
        inp = wx.TextCtrl(self.panel, value=str(text), style=style)
        if hint:
            inp.SetHint(hint)
        final_color = color if color is not None else self._get_default_color('input_fg')
        final_bg = bg if bg is not None else self._get_default_color('input_bg')
        return self._add_widget(inp, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), final_color, final_bg, parent=parent)

    def AddTextArea(self, relx=0.0, rely=0.0, relwidth=0.3, relheight=0.2,
                    text="", readonly=False, font_scale=1.0, color=None, bg=None,
                    tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        style = wx.TE_MULTILINE | wx.HSCROLL
        if readonly:
            style |= wx.TE_READONLY
        area = wx.TextCtrl(self.panel, value=str(text), style=style)
        final_color = color if color is not None else self._get_default_color('input_fg')
        final_bg = bg if bg is not None else self._get_default_color('input_bg')
        return self._add_widget(area, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), final_color, final_bg, parent=parent)

    def AddCounter(self, relx=0.0, rely=0.0, relwidth=0.15, relheight=0.1,
                   min_val=0, max_val=100, start=0, step=1, font_scale=1.0,
                   tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        sc = wx.SpinCtrl(self.panel, min=min_val, max=max_val, initial=start)
        sc.SetIncrement(step)
        return self._add_widget(sc, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), parent=parent)

    def AddCalendar(self, relx=0.0, rely=0.0, relwidth=0.4, relheight=0.3,
                    command=None, tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        cal = wx.adv.CalendarCtrl(self.panel)
        if command:
            cal.Bind(wx.adv.EVT_CALENDAR_SEL_CHANGED, lambda e: command(cal.GetDate()))
        return self._add_widget(cal, relx, rely, relwidth, relheight, 1.0,
                                tooltip, enabled, visible,
                                self._get_cursor(cursor), parent=parent)

    def AddSlider(self, relx=0.0, rely=0.0, relwidth=0.3, relheight=0.1,
                  min_val=1, max_val=50, start=2, command=None,
                  orientation="horizontal", tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        orient = wx.HORIZONTAL if orientation.lower() == "horizontal" else wx.VERTICAL
        sld = wx.Slider(self.panel, minValue=min_val, maxValue=max_val, value=start,
                        style=orient | wx.SL_LABELS)
        if command:
            sld.Bind(wx.EVT_SLIDER, lambda e: command(sld.GetValue()))
        return self._add_widget(sld, relx, rely, relwidth, relheight, 1.0,
                                tooltip, enabled, visible,
                                self._get_cursor(cursor), parent=parent)

    def AddColorPicker(self, relx=0.0, rely=0.0, relwidth=0.1, relheight=0.1,
                       color="#000000", command=None, tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        cp = wx.ColourPickerCtrl(self.panel, colour=self._to_colour(color))
        if command:
            cp.Bind(wx.EVT_COLOURPICKER_CHANGED,
                    lambda e: command(cp.GetColour().GetAsString(wx.C2S_HTML_SYNTAX)))
        return self._add_widget(cp, relx, rely, relwidth, relheight, 1.0,
                                tooltip, enabled, visible,
                                self._get_cursor(cursor), parent=parent)

    def AddCheckBox(self, label="Option", relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                    checked=False, command=None, font_scale=1.0,
                    tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        cb = wx.CheckBox(self.panel, label=str(label))
        cb.SetValue(checked)
        if command:
            cb.Bind(wx.EVT_CHECKBOX, lambda e: command(cb.GetValue()))
        final_color = None
        final_bg = self._get_default_color('bg')
        return self._add_widget(cb, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), final_color, final_bg, parent=parent)

    def AddRadioButton(self, label="Choice", relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                   checked=False, command=None, font_scale=1.0,
                   tooltip=None, enabled=True, visible=True, cursor=None, parent=None,
                   group_start=False):
        start_new_group = group_start or not getattr(self, "_rb_group_open", False)
        style = wx.RB_GROUP if start_new_group else 0

        rb = wx.RadioButton(self.panel, label=str(label), style=style)
        rb.SetValue(checked)

        self._rb_group_open = True

        if command:
            rb.Bind(wx.EVT_RADIOBUTTON, lambda e: command(rb.GetValue()))

        final_color = None
        final_bg = self._get_default_color('bg')
        return self._add_widget(rb, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), final_color, final_bg, parent=parent)

    def AddComboBox(self, choices=None, relx=0.0, rely=0.0, relwidth=0.2, relheight=0.1,
                value="", command=None, font_scale=1.0,
                tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        choices = choices or []
        cb = wx.ComboBox(self.panel, choices=choices, value=str(value), style=wx.CB_DROPDOWN)
        if command:
            cb.Bind(wx.EVT_COMBOBOX, lambda e: command(cb.GetValue()))
        final_color = None
        final_bg = self._get_default_color('input_bg')
        return self._add_widget(cb, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), final_color, final_bg, parent=parent)

    def AddListBox(self, choices=None, relx=0.0, rely=0.0, relwidth=0.2, relheight=0.2,
               command=None, multiple=False, font_scale=1.0,
               tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        choices = choices or []
        style = wx.LB_SINGLE if not multiple else wx.LB_MULTIPLE
        lb = wx.ListBox(self.panel, choices=choices, style=style)

        if command:
            if multiple:
                lb.Bind(wx.EVT_LISTBOX, lambda e: command(self._get_listbox_values(lb)))
            else:
                lb.Bind(wx.EVT_LISTBOX, lambda e: command(lb.GetStringSelection()))

        final_color = None
        final_bg = self._get_default_color('input_bg')
        return self._add_widget(lb, relx, rely, relwidth, relheight,
                                font_scale, tooltip, enabled, visible,
                                self._get_cursor(cursor), final_color, final_bg, parent=parent)

    def AddCanvas(self, relx=0.0, rely=0.0, relwidth=0.5, relheight=0.5,
                  bg="white", tooltip=None, enabled=True, visible=True, cursor=None, parent=None):
        canvas_bg = bg if bg != "white" else self._get_default_color('canvas_bg') or "white"
        canvas = _CanvasPanel(self.panel, bg=self._to_colour(canvas_bg))
        return self._add_widget(canvas, relx, rely, relwidth, relheight,
                                1.0, tooltip, enabled, visible,
                                self._get_cursor(cursor), parent=parent)

    def AddTabs(self, relx=0.0, rely=0.0, relwidth=0.5, relheight=0.5,
            tooltip=None, enabled=True, bg=None, visible=True, cursor=None, parent=None):
        tabs_bg = bg if bg is not None else self._get_default_color('tabs_bg')
        bg_color = self._to_colour(tabs_bg) if tabs_bg else self._to_colour((245,245,247))
        tabs_parent = self._unwrap_widget(parent) if parent else self.panel
        tabs_ctrl = _CustomTabs(tabs_parent, bg_color, self)
        return self._add_widget(tabs_ctrl, relx, rely, relwidth, relheight,
                                1.0, tooltip, enabled, visible,
                                self._get_cursor(cursor), parent=parent)

    def AddPage(self, notebook, title="Page", color="#8E8E93", bg="#F5F5F7", active_fg="#007AFF", size_text=1.0):
        notebook = self._unwrap_widget(notebook)
        if isinstance(notebook, _CustomTabs):
            page_color = color if color != "#8E8E93" else self._get_default_color('tabs_inactive_fg') or "#8E8E93"
            page_bg = bg if bg != "#F5F5F7" else self._get_default_color('page_bg') or "#F5F5F7"
            page_active_fg = active_fg if active_fg != "#007AFF" else self._get_default_color('tabs_active_fg') or "#007AFF"
            page = notebook.AddPage(title, page_color, page_bg, page_active_fg, size_text)
            page.Bind(wx.EVT_SIZE, lambda e: wx.CallAfter(self._apply_proportional_layout))
            self._attach_modify(page, kind="page")
            self._apply_proportional_layout()
            return _WidgetHandle(self, page)
        return None

    def CanvasSetPen(self, canvas, color=None, width=None):
        canvas = self._unwrap_widget(canvas)
        if isinstance(canvas, _CanvasPanel):
            canvas.SetPen(color, width)

    def CanvasClear(self, canvas, bg=None):
        canvas = self._unwrap_widget(canvas)
        if isinstance(canvas, _CanvasPanel):
            canvas.Clear(bg)

    def AddMenuBar(self):
        self.menu_bar = wx.MenuBar()
        self.frame.SetMenuBar(self.menu_bar)

    def AddMenu(self, title="File"):
        if not hasattr(self, 'menu_bar') or self.menu_bar is None:
            self.AddMenuBar()
        menu = wx.Menu()
        self.menu_bar.Append(menu, title)
        return menu

    def AddMenuItem(self, menu, label="Item", command=None, shortcut=""):
        item_id = int(wx.NewIdRef())
        item = menu.Append(item_id, label + (f"\t{shortcut}" if shortcut else ""))

        if command:
            self.frame.Bind(wx.EVT_MENU, lambda e: command(), id=item_id)

        if shortcut:
            entry = self._make_accelerator(shortcut, item_id)
            if entry:
                self._accelerators.append(entry)
                self.frame.SetAcceleratorTable(wx.AcceleratorTable(list(self._accelerators)))

        return item

    def _make_accelerator(self, shortcut, item_id):
        parts = [p.strip().upper() for p in shortcut.replace("-", "+").split("+") if p.strip()]
        flags = 0
        key = None

        special_keys = {
            "ENTER": "RETURN",
            "RETURN": "RETURN",
            "ESC": "ESCAPE",
            "ESCAPE": "ESCAPE",
            "DEL": "DELETE",
            "DELETE": "DELETE",
            "BACKSPACE": "BACK",
            "SPACE": "SPACE",
            "TAB": "TAB",
            "HOME": "HOME",
            "END": "END",
            "PAGEUP": "PAGEUP",
            "PAGEDOWN": "PAGEDOWN",
            "UP": "UP",
            "DOWN": "DOWN",
            "LEFT": "LEFT",
            "RIGHT": "RIGHT",
            "INSERT": "INSERT",
        }

        for p in parts:
            if p == "CTRL":
                flags |= wx.ACCEL_CTRL
            elif p == "ALT":
                flags |= wx.ACCEL_ALT
            elif p == "SHIFT":
                flags |= wx.ACCEL_SHIFT
            else:
                mapped = special_keys.get(p, p)
                if len(mapped) == 1:
                    key = ord(mapped)
                else:
                    const_name = f"WXK_{mapped}"
                    if hasattr(wx, const_name):
                        key = getattr(wx, const_name)

        if key is not None:
            return wx.AcceleratorEntry(flags, key, int(item_id))
        return None

    def AddStatusBar(self, text="Ready", color="black", bg=None, highlight=None,
                 text_size=0.5, height_scale=1.0,
                 relx=0.01, rely=0.5, relwidth=None, relheight=None,
                 font_scale=2):
        self.status_bar = self.frame.CreateStatusBar()
        self.status_bar._height_scale = height_scale

        status_bg = bg if bg is not None else self._get_default_color('status_bg')
        if status_bg:
            self.status_bar.SetBackgroundColour(self._to_colour(status_bg))

        style = wx.ST_ELLIPSIZE_END if relwidth is not None else 0
        self._status_label = wx.StaticText(self.status_bar, label=str(text), style=style)
        self._status_label._text_size_ratio = text_size
        self._status_label._relx = relx
        self._status_label._rely = rely
        self._status_label._relwidth = relwidth
        self._status_label._relheight = relheight
        self._status_label._font_scale = font_scale

        status_fg = color if color != "black" else self._get_default_color('status_fg') or "black"
        if status_fg:
            self._status_label.SetForegroundColour(self._to_colour(status_fg))
        if highlight:
            self._status_label.SetBackgroundColour(self._to_colour(highlight))
        elif self.style == "dark":
            hl = self._get_default_color('status_highlight')
            if hl:
                self._status_label.SetBackgroundColour(hl)

        self._apply_proportional_layout()

    def AddTimer(self, ms=1000, command=None, one_shot=False):
        t = wx.Timer(self.frame)
        if command:
            self.frame.Bind(wx.EVT_TIMER, lambda e: command(), t)
        t.Start(ms, one_shot)
        self._timers.append(t)
        return t

    def StopTimer(self, timer):
        if timer in self._timers:
            if timer.IsRunning():
                timer.Stop()
            self._timers.remove(timer)

    def Message(self, text, title="Message"):
        wx.MessageBox(str(text), str(title), wx.OK | wx.ICON_INFORMATION)

    def AskSave(self, wildcard="All files (*.*)|*.*", default_dir=""):
        with wx.FileDialog(self.frame, "Save as...", default_dir,
                           wildcard=wildcard, style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                return dlg.GetPath()
        return None

    def AskOpen(self, wildcard="All files (*.*)|*.*", default_dir=""):
        with wx.FileDialog(self.frame, "Open file", default_dir,
                           wildcard=wildcard, style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                return dlg.GetPath()
        return None

    def EnableWidget(self, widget, enable=True):
        widget = self._unwrap_widget(widget)
        if widget:
            widget.Enable(enable)

    def ShowWidget(self, widget, show=True):
        widget = self._unwrap_widget(widget)
        if widget:
            widget.Show(show)
            self._apply_proportional_layout()

    def run(self):
        self.app.MainLoop()

    def exit(self):
        self.frame.Close()

    def _on_close(self, event):
        for t in getattr(self, "_timers", []):
            if t and t.IsRunning():
                t.Stop()
        self._timers.clear()

        if hasattr(self, "_resize_timer") and self._resize_timer.IsRunning():
            self._resize_timer.Stop()

        self.frame.Destroy()