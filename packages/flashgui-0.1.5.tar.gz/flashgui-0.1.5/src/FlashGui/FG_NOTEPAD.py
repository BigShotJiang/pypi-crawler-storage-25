# FlashGUI - Copyright (c) 2026 Robert Opris - Standard License
import wx
import os
import charset_normalizer

class Theme:
    style = "light"

class CustomMenuItem:
    def __init__(self, item_id, text, is_separator=False):
        self.id = item_id
        self.text = text
        self.is_separator = is_separator
        self.enabled = True

    def Enable(self, state=True):
        self.enabled = state

    def SetItemLabel(self, text):
        self.text = text

class CustomMenu:
    def __init__(self):
        self.items = []

    def Append(self, item_id, text):
        item = CustomMenuItem(item_id, text)
        self.items.append(item)
        return item

    def AppendSeparator(self):
        item = CustomMenuItem(wx.ID_SEPARATOR, "", is_separator=True)
        self.items.append(item)

class CustomMenuPopup(wx.PopupTransientWindow):
    def __init__(self, parent, custom_menu, bg_color=(250,250,250), text_color=(0,0,0), hover_color=(200,220,240), radius=5):
        super().__init__(parent)
        
        self.menu = custom_menu
        self.bg_color = wx.Colour(*bg_color)
        self.text_color = wx.Colour(*text_color)
        self.hover_color = wx.Colour(*hover_color)
        self.radius = radius
        self.hovered_index = -1

        if Theme.style == "dark":
            self.bg_color = wx.Colour(28, 28, 32)
            self.text_color = wx.Colour(235, 235, 235)
            self.hover_color = wx.Colour(55, 55, 65)
        
        self.panel = wx.Panel(self, style=wx.BORDER_NONE)
        self.panel.SetBackgroundStyle(wx.BG_STYLE_PAINT)
        self.panel.SetBackgroundColour(self.bg_color) 

        self.panel.Bind(wx.EVT_PAINT, self.on_paint)
        self.panel.Bind(wx.EVT_MOTION, self.on_motion)
        self.panel.Bind(wx.EVT_LEFT_UP, self.on_click)
        self.panel.Bind(wx.EVT_LEAVE_WINDOW, self.on_leave)

        self.calculate_size()

    def calculate_size(self):
        dc = wx.ScreenDC()
        font = wx.SystemSettings.GetFont(wx.SYS_DEFAULT_GUI_FONT)
        dc.SetFont(font)
        
        max_w = 150
        total_h = 5
        self.item_rects = []
        
        for item in self.menu.items:
            if item.is_separator:
                self.item_rects.append(wx.Rect(0, total_h, 0, 10))
                total_h += 10
            else:
                parts = item.text.split('\t')
                label = parts[0].replace('&', '')
                shortcut = parts[1] if len(parts) > 1 else ""
                
                w1, h1 = dc.GetTextExtent(label)
                w2, h2 = dc.GetTextExtent(shortcut)
                
                row_w = 15 + w1 + 40 + w2 + 15
                if row_w > max_w: max_w = row_w
                    
                self.item_rects.append(wx.Rect(0, total_h, 0, 28))
                total_h += 28
                
        total_h += 5
        for r in self.item_rects: r.width = max_w
            
        self.SetSize((max_w, total_h))
        self.panel.SetSize((max_w, total_h))

    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self.panel)
        dc.SetBackground(wx.Brush(self.bg_color))
        dc.Clear()
        
        gc = wx.GraphicsContext.Create(dc)
        if not gc: return
        
        w, h = self.panel.GetSize()
        
        gc.SetBrush(wx.Brush(self.bg_color))
        gc.SetPen(wx.TRANSPARENT_PEN) 
        gc.DrawRoundedRectangle(0, 0, w, h, self.radius)
        
        for i, item in enumerate(self.menu.items):
            rect = self.item_rects[i]
            if item.is_separator:
                gc.SetPen(wx.Pen(wx.Colour(180, 180, 180), 1))
                gc.StrokeLine(10, rect.y + 5, w - 10, rect.y + 5)
            else:
                if i == self.hovered_index and item.enabled:
                    gc.SetBrush(wx.Brush(self.hover_color))
                    gc.SetPen(wx.TRANSPARENT_PEN)
                    gc.DrawRoundedRectangle(5, rect.y, rect.width - 10, rect.height, max(0, self.radius - 2))
                
                parts = item.text.split('\t')
                label = parts[0].replace('&', '')
                shortcut = parts[1] if len(parts) > 1 else ""
                
                color = self.text_color if item.enabled else wx.Colour(160, 160, 160)
                gc.SetFont(self.panel.GetFont(), color)
                
                _, th = dc.GetTextExtent(label)
                ty = rect.y + (rect.height - th) / 2
                
                gc.DrawText(label, 15, ty)
                if shortcut:
                    sw, _ = dc.GetTextExtent(shortcut)
                    gc.DrawText(shortcut, rect.width - sw - 15, ty)

    def on_motion(self, event):
        pos = event.GetPosition()
        old_hover = self.hovered_index
        self.hovered_index = -1
        for i, rect in enumerate(self.item_rects):
            if rect.Contains(pos):
                if not self.menu.items[i].is_separator:
                    self.hovered_index = i
                break
        if old_hover != self.hovered_index:
            self.panel.Refresh()

    def on_leave(self, event):
        self.hovered_index = -1
        self.panel.Refresh()

    def on_click(self, event):
        if self.hovered_index != -1:
            item = self.menu.items[self.hovered_index]
            if item.enabled:
                self.Dismiss()
                evt = wx.CommandEvent(wx.wxEVT_MENU, item.id)
                wx.PostEvent(self.GetParent(), evt)

class CustomMenuBar(wx.Panel):
    def __init__(self, parent, bg_color=(235, 235, 235), text_color=(0, 0, 0), hover_color=(200, 220, 240), radius=5):
        super().__init__(parent, size=(-1, 30))
        self.SetBackgroundStyle(wx.BG_STYLE_PAINT)
        self.bg_color = wx.Colour(*bg_color)
        self.text_color = wx.Colour(*text_color)
        self.hover_color = wx.Colour(*hover_color)
        self.radius = radius
        self.menus = []
        self.hovered_index = -1

        self.Bind(wx.EVT_PAINT, self.on_paint)
        self.Bind(wx.EVT_MOTION, self.on_mouse_motion)
        self.Bind(wx.EVT_LEAVE_WINDOW, self.on_mouse_leave)
        self.Bind(wx.EVT_LEFT_DOWN, self.on_left_down)
        self.Bind(wx.EVT_SIZE, self.on_size)

    def Append(self, menu, label):
        self.menus.append({'label': label, 'menu': menu, 'rect': wx.Rect()})
        self.update_layout()

    def SetMenuLabel(self, index, label):
        if 0 <= index < len(self.menus):
            self.menus[index]['label'] = label
            self.update_layout()

    def update_layout(self):
        dc = wx.ScreenDC()
        dc.SetFont(self.GetFont())
        x_offset = 5
        for item in self.menus:
            w, h = dc.GetTextExtent(item['label'].replace('&', ''))
            w += 20
            item['rect'] = wx.Rect(x_offset, 2, w, 26)
            x_offset += w
        self.Refresh()

    def on_size(self, event):
        self.update_layout()
        event.Skip()

    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self)
        gc = wx.GraphicsContext.Create(dc)
        w, h = self.GetSize()
        
        gc.SetBrush(wx.Brush(self.bg_color))
        gc.SetPen(wx.TRANSPARENT_PEN) 
        gc.DrawRectangle(0, 0, w, h)

        for i, item in enumerate(self.menus):
            rect = item['rect']
            if i == self.hovered_index:
                gc.SetBrush(wx.Brush(self.hover_color))
                gc.DrawRoundedRectangle(rect.x, rect.y, rect.width, rect.height, self.radius)

            label = item['label'].replace('&', '')
            tw, th = dc.GetTextExtent(label)
            gc.SetFont(self.GetFont(), self.text_color)
            gc.DrawText(label, rect.x + (rect.width - tw) / 2, rect.y + (rect.height - th) / 2)

    def on_mouse_motion(self, event):
        pos = event.GetPosition()
        old = self.hovered_index
        self.hovered_index = -1
        for i, item in enumerate(self.menus):
            if item['rect'].Contains(pos):
                self.hovered_index = i
                break
        if old != self.hovered_index: self.Refresh()

    def on_mouse_leave(self, event):
        self.hovered_index = -1
        self.Refresh()

    def on_left_down(self, event):
        if self.hovered_index != -1:
            item = self.menus[self.hovered_index]
            pos = self.ClientToScreen((item['rect'].x, item['rect'].bottom))
            parent_notepad = self.GetParent()
            popup = CustomMenuPopup(parent_notepad, item['menu'], 
                                    bg_color=parent_notepad.menu_bg_color, 
                                    text_color=parent_notepad.menu_text_color, 
                                    hover_color=parent_notepad.menu_hover_color, 
                                    radius=parent_notepad.menu_radius)
            popup.SetPosition(pos)
            popup.Popup()

class CustomStatusBar(wx.Panel):
    def __init__(self, parent, bg_color=(240, 240, 240), text_color=(0, 0, 0), sep_color=(200, 200, 200)):
        super().__init__(parent, size=(-1, 25))
        self.SetBackgroundStyle(wx.BG_STYLE_PAINT)
        self.bg_color = wx.Colour(*bg_color)
        self.text_color = wx.Colour(*text_color)
        self.sep_color = wx.Colour(*sep_color)
        
        self.widths = [-2, -1, -1, -1]
        self.texts = ["", "", "", ""]
        
        self.Bind(wx.EVT_PAINT, self.on_paint)
        self.Bind(wx.EVT_SIZE, self.on_size)
        
    def SetStatusWidths(self, widths):
        self.widths = widths
        self.Refresh()
        
    def SetStatusText(self, text, index=0):
        if 0 <= index < len(self.texts):
            self.texts[index] = text
            self.Refresh()
            
    def on_size(self, event):
        self.Refresh()
        event.Skip()
        
    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self)
        w, h = self.GetSize()
        
        dc.SetBrush(wx.Brush(self.bg_color))
        dc.SetPen(wx.TRANSPARENT_PEN)
        dc.DrawRectangle(0, 0, w, h)
        
        total_prop = sum([abs(x) for x in self.widths])
        if total_prop == 0: return
        
        unit_width = w / total_prop
        
        dc.SetFont(self.GetFont())
        dc.SetTextForeground(self.text_color)
        
        x_offset = 0
        for i, prop in enumerate(self.widths):
            segment_width = abs(prop) * unit_width
            
            if i > 0:
                dc.SetPen(wx.Pen(self.sep_color, 1))
                dc.DrawLine(int(x_offset), 4, int(x_offset), h - 4)
            
            text = self.texts[i]
            if text:
                tw, th = dc.GetTextExtent(text)
                dc.DrawText(text, int(x_offset + 5), int((h - th) / 2))
            
            x_offset += segment_width

class NOTEPAD(wx.Frame):
    def __init__(self, title="Notepad", size=(2,2), color=(240,240,240),
                 icon=None, maximized=False, min_size=(5,4), max_size=(1,1), style = "light"):

        self.app = wx.App(False)
        self.title = title
        self.size = size
        self.color = color
        
        self.menu_bg_color = (250, 250, 250)
        self.menu_text_color = (0, 0, 0)
        self.menu_hover_color = (200, 220, 240)
        self.menu_radius = 5

        self.current_file = None
        self.current_encoding = "UTF-8"
        
        self.open_dialog_title = "Open Text file"
        self.open_dialog_file_type = ("Text Files (*.txt)", "All files (*.*)")
        self.save_as_dialog_title = "Save Text file"
        self.save_as_dialog_file_type = ("Text Files (*.txt)", "All files (*.*)")
        self.messagebox_about_title = "About Notepad"
        self.messagebox_about_text = "Notepad created with FastGui.\nVersion 1.0"
        self.maybe_save_dialog_title = "Save changes"
        self.maybe_save_dialog_text = "There are unsaved changes. Do you want to save them?"
        self.popup_cut_text = "Cut"
        self.popup_copy_text = "Copy"
        self.popup_paste_text = "Paste"
        self.popup_select_all_text = "Select All"
        self.ln_text = "Ln"
        self.col_text = "Col"
        self.words_text = "Words"
        self.chars_text = "Chars"
        self.untitled_text = "Untitled"
        self.menu_new_command = self.on_new
        self.menu_open_command = self.on_open
        self.menu_save_command = self.on_save
        self.menu_save_as_command = self.on_save_as
        self.menu_exit_command = self.on_exit
        self.menu_about_command = self.on_about
        self.menu_undo_command = self.on_undo
        self.menu_redo_command = self.on_redo
        self.menu_cut_command = self.on_cut
        self.menu_copy_command = self.on_copy
        self.menu_paste_command = self.on_paste
        self.menu_select_all_command = self.on_select_all
        self.popup_cut_command = self.on_cut
        self.popup_copy_command = self.on_copy
        self.popup_paste_command = self.on_paste
        self.popup_select_all_command = self.on_select_all


        screen_width, screen_height = wx.GetDisplaySize()
        w = int(screen_width / float(size[0]))
        h = int(screen_height / float(size[1]))

        super().__init__(None, title=title, size=(w,h))


        if style == "dark":
            Theme.style = "dark"
        elif style == "light":
            Theme.style = "light"

        self.CUT_POPUP_ID = wx.NewIdRef()
        self.COPY_POPUP_ID = wx.NewIdRef()
        self.PASTE_POPUP_ID = wx.NewIdRef()
        self.SELECTALL_POPUP_ID = wx.NewIdRef()

        self.Bind(wx.EVT_MENU, self.menu_new_command, id=wx.ID_NEW)
        self.Bind(wx.EVT_MENU, self.menu_open_command, id=wx.ID_OPEN)
        self.Bind(wx.EVT_MENU, self.menu_save_command, id=wx.ID_SAVE)
        self.Bind(wx.EVT_MENU, self.menu_save_as_command, id=wx.ID_SAVEAS)
        self.Bind(wx.EVT_MENU, self.menu_exit_command, id=wx.ID_EXIT)
        self.Bind(wx.EVT_MENU, self.menu_about_command, id=wx.ID_ABOUT)
        self.Bind(wx.EVT_MENU, self.menu_undo_command, id=wx.ID_UNDO)
        self.Bind(wx.EVT_MENU, self.menu_redo_command, id=wx.ID_REDO)
        self.Bind(wx.EVT_MENU, self.menu_cut_command, id=wx.ID_CUT)
        self.Bind(wx.EVT_MENU, self.menu_copy_command, id=wx.ID_COPY)
        self.Bind(wx.EVT_MENU, self.menu_paste_command, id=wx.ID_PASTE)
        self.Bind(wx.EVT_MENU, self.menu_select_all_command, id=wx.ID_SELECTALL)
        self.Bind(wx.EVT_MENU, self.popup_cut_command, id=self.CUT_POPUP_ID)
        self.Bind(wx.EVT_MENU, self.popup_copy_command, id=self.COPY_POPUP_ID)
        self.Bind(wx.EVT_MENU, self.popup_paste_command, id=self.PASTE_POPUP_ID)
        self.Bind(wx.EVT_MENU, self.popup_select_all_command, id=self.SELECTALL_POPUP_ID)

        self.SetBackgroundColour(wx.Colour(*self.color))
        self.SetMinSize((int(screen_width//min_size[0]), int(screen_height//min_size[1])))
        self.SetMaxSize((int(screen_width//max_size[0]), int(screen_height//max_size[1])))
        
        if maximized: self.Maximize(True)
        if icon:
            ext = icon.split('.')[-1].lower()
            icon_type = wx.BITMAP_TYPE_PNG if ext == "png" else wx.BITMAP_TYPE_ICO
            self.SetIcon(wx.Icon(icon, icon_type))

        self.text_ctrl = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.HSCROLL | wx.VSCROLL | wx.TE_PROCESS_ENTER)
        self.font_family = wx.FONTFAMILY_TELETYPE
        self.font_size = 12
        self.update_font()

        self.create_menu()
        self.create_status_bar()

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.custom_menubar, 0, wx.EXPAND)
        sizer.Add(self.text_ctrl, 1, wx.EXPAND)
        sizer.Add(self.custom_statusbar, 0, wx.EXPAND)
        self.SetSizer(sizer)

        self.Bind(wx.EVT_CLOSE, self.on_close)
        self.Bind(wx.EVT_SIZE, self.on_resize)
        self.text_ctrl.Bind(wx.EVT_TEXT, self.on_text_change)
        self.text_ctrl.Bind(wx.EVT_CONTEXT_MENU, self.on_context_menu)

        self.Centre()
        self.Show()
        self.text_ctrl.SetFocus()
        self.update_status()

    def AddTimer(self, ms=1000, command=None):
        t = wx.Timer(self.frame)
        if command:
            self.frame.Bind(wx.EVT_TIMER, lambda e: command(), t)
        t.Start(ms)
        return t

    def GetMenuBar(self):
        return getattr(self, 'custom_menubar', None)

    def Edit(self, 
             new_text="New", open_text="Open...", save_text="Save", saveas_text="Save As...", exit_text="Exit",
             undo_text="Undo", redo_text="Redo", cut_text="Cut", copy_text="Copy", paste_text="Paste", selectall_text="Select All",
             about_text="About", file_menu_text="File", edit_menu_text="Edit", help_menu_text="Help",
             bg_color=None, text_ctrl_bg=(255,255,255), text_ctrl_fg=(0,0,0),
             menubar_bg=(235, 235, 235), menubar_fg=(0, 0, 0), menubar_hover=(200, 220, 240),
             menu_bg=(250, 250, 250), menu_fg=(0, 0, 0), menu_hover=(200, 220, 240), menu_radius=6,
             statusbar_bg=(240, 240, 240), statusbar_fg=(0, 0, 0), statusbar_separator_color=(200, 200, 200),
             open_dialog_title="Open Text file", open_dialog_file_type=("Text Files (*.txt)", "All files (*.*)"),
             save_as_dialog_title="Save Text file", save_as_dialog_file_type=("Text Files (*.txt)", "All files (*.*)"),
             messagebox_about_title="About Notepad", messagebox_about_text="Notepad created with FastGui.\nVersion 1.0",
             maybe_save_dialog_title="Save changes", maybe_save_dialog_text="There are unsaved changes. Do you want to save them?",
             popup_cut_text="Cut", popup_copy_text="Copy", popup_paste_text="Paste", popup_select_all_text="Select All",
             ln_text="Ln", col_text="Col", words_text="Words", chars_text="Chars", untitled_text="Untitled"):
    
        self.custom_menubar.SetMenuLabel(0, f"&{file_menu_text}")
        self.custom_menubar.SetMenuLabel(1, f"&{edit_menu_text}")
        self.custom_menubar.SetMenuLabel(2, f"&{help_menu_text}")
        self.custom_menubar.bg_color = wx.Colour(*menubar_bg)
        self.custom_menubar.text_color = wx.Colour(*menubar_fg)
        self.custom_menubar.hover_color = wx.Colour(*menubar_hover)

        self.new_item.SetItemLabel(f"&{new_text}\tCtrl+N")
        self.open_item.SetItemLabel(f"&{open_text}\tCtrl+O")
        self.save_item.SetItemLabel(f"&{save_text}\tCtrl+S")
        self.saveas_item.SetItemLabel(f"{saveas_text}\tCtrl+Shift+S")
        self.exit_item.SetItemLabel(f"&{exit_text}\tCtrl+Q")
        self.undo_item.SetItemLabel(f"&{undo_text}\tCtrl+Z")
        self.redo_item.SetItemLabel(f"&{redo_text}\tCtrl+Y")
        self.cut_item.SetItemLabel(f"&{cut_text}\tCtrl+X")
        self.copy_item.SetItemLabel(f"&{copy_text}\tCtrl+C")
        self.paste_item.SetItemLabel(f"&{paste_text}\tCtrl+V")
        self.selectall_item.SetItemLabel(f"{selectall_text}\tCtrl+A")
        self.about_item.SetItemLabel(f"&{about_text}\tCtrl+I")

        if bg_color: self.SetBackgroundColour(wx.Colour(*bg_color))
        self.text_ctrl.SetBackgroundColour(wx.Colour(*text_ctrl_bg))
        self.text_ctrl.SetForegroundColour(wx.Colour(*text_ctrl_fg))

        self.custom_statusbar.bg_color = wx.Colour(*statusbar_bg)
        self.custom_statusbar.text_color = wx.Colour(*statusbar_fg)
        self.custom_statusbar.sep_color = wx.Colour(*statusbar_separator_color)

        self.menu_bg_color, self.menu_text_color = menu_bg, menu_fg
        self.menu_hover_color, self.menu_radius = menu_hover, menu_radius

        self.open_dialog_title, self.open_dialog_file_type = open_dialog_title, open_dialog_file_type
        self.save_as_dialog_title, self.save_as_dialog_file_type = save_as_dialog_title, save_as_dialog_file_type
        self.messagebox_about_title, self.messagebox_about_text = messagebox_about_title, messagebox_about_text
        self.maybe_save_dialog_title, self.maybe_save_dialog_text = maybe_save_dialog_title, maybe_save_dialog_text
        self.popup_cut_text, self.popup_copy_text = popup_cut_text, popup_copy_text
        self.popup_paste_text, self.popup_select_all_text = popup_paste_text, popup_select_all_text
        self.ln_text, self.col_text, self.words_text, self.chars_text, self.untitled_text = ln_text, col_text, words_text, chars_text, untitled_text

        self.custom_menubar.Refresh()
        self.custom_statusbar.Refresh()
        self.Refresh()
        self.update_status()

    def Logic(self, menu_new_command=None, menu_open_command=None,
          menu_save_command=None, menu_save_as_command=None, menu_exit_command=None, menu_about_command=None,
          menu_undo_command=None, menu_redo_command=None, menu_cut_command=None, menu_copy_command=None,
          menu_paste_command=None, menu_select_all_command=None, popup_cut_command=None, popup_copy_command=None,
          popup_paste_command=None, popup_select_all_command=None):

        if menu_new_command: self.menu_new_command = menu_new_command
        if menu_open_command: self.menu_open_command = menu_open_command
        if menu_save_command: self.menu_save_command = menu_save_command
        if menu_save_as_command: self.menu_save_as_command = menu_save_as_command
        if menu_exit_command: self.menu_exit_command = menu_exit_command
        if menu_about_command: self.menu_about_command = menu_about_command
        if menu_undo_command: self.menu_undo_command = menu_undo_command
        if menu_redo_command: self.menu_redo_command = menu_redo_command
        if menu_cut_command: self.menu_cut_command = menu_cut_command
        if menu_copy_command: self.menu_copy_command = menu_copy_command
        if menu_paste_command: self.menu_paste_command = menu_paste_command
        if menu_select_all_command: self.menu_select_all_command = menu_select_all_command
        if popup_cut_command: self.popup_cut_command = popup_cut_command
        if popup_copy_command: self.popup_copy_command = popup_copy_command
        if popup_paste_command: self.popup_paste_command = popup_paste_command
        if popup_select_all_command: self.popup_select_all_command = popup_select_all_command

        self.Bind(wx.EVT_MENU, self.menu_new_command, id=wx.ID_NEW)
        self.Bind(wx.EVT_MENU, self.menu_open_command, id=wx.ID_OPEN)
        self.Bind(wx.EVT_MENU, self.menu_save_command, id=wx.ID_SAVE)
        self.Bind(wx.EVT_MENU, self.menu_save_as_command, id=wx.ID_SAVEAS)
        self.Bind(wx.EVT_MENU, self.menu_exit_command, id=wx.ID_EXIT)
        self.Bind(wx.EVT_MENU, self.menu_about_command, id=wx.ID_ABOUT)
        self.Bind(wx.EVT_MENU, self.menu_undo_command, id=wx.ID_UNDO)
        self.Bind(wx.EVT_MENU, self.menu_redo_command, id=wx.ID_REDO)
        self.Bind(wx.EVT_MENU, self.menu_cut_command, id=wx.ID_CUT)
        self.Bind(wx.EVT_MENU, self.menu_copy_command, id=wx.ID_COPY)
        self.Bind(wx.EVT_MENU, self.menu_paste_command, id=wx.ID_PASTE)
        self.Bind(wx.EVT_MENU, self.menu_select_all_command, id=wx.ID_SELECTALL)
        self.Bind(wx.EVT_MENU, self.popup_cut_command, id=self.CUT_POPUP_ID)
        self.Bind(wx.EVT_MENU, self.popup_copy_command, id=self.COPY_POPUP_ID)
        self.Bind(wx.EVT_MENU, self.popup_paste_command, id=self.PASTE_POPUP_ID)
        self.Bind(wx.EVT_MENU, self.popup_select_all_command, id=self.SELECTALL_POPUP_ID)


    def run(self):
        self.app.MainLoop()

    def _parse_accel(self, text, item_id):
        if '\t' not in text: return None
        parts = text.split('\t')
        shortcut = parts[1].upper()
        flags = wx.ACCEL_NORMAL
        if 'CTRL' in shortcut: flags |= wx.ACCEL_CTRL
        if 'ALT' in shortcut: flags |= wx.ACCEL_ALT
        if 'SHIFT' in shortcut: flags |= wx.ACCEL_SHIFT
        
        key_str = shortcut.split('+')[-1].strip()
        key = ord(key_str) if len(key_str) == 1 else 0
        if key: return wx.AcceleratorEntry(flags, key, item_id)
        return None

    def create_menu(self):
        if Theme.style == "light":
            self.custom_menubar = CustomMenuBar(self, bg_color=(235, 235, 235), 
                                                text_color=(0, 0, 0), hover_color=(200, 220, 240), radius=6)
        elif Theme.style == "dark":
            self.custom_menubar = CustomMenuBar(self,
                bg_color=(32, 32, 36),
                text_color=(235, 235, 235),
                hover_color=(55, 55, 65),
                radius=6
                )
        
        file_menu = CustomMenu()
        self.new_item = file_menu.Append(wx.ID_NEW, "&New\tCtrl+N")
        self.open_item = file_menu.Append(wx.ID_OPEN, "&Open...\tCtrl+O")
        self.save_item = file_menu.Append(wx.ID_SAVE, "&Save\tCtrl+S")
        self.saveas_item = file_menu.Append(wx.ID_SAVEAS, "&Save As...\tCtrl+Shift+S")
        file_menu.AppendSeparator()
        self.exit_item = file_menu.Append(wx.ID_EXIT, "&Exit\tCtrl+Q")
        
        edit_menu = CustomMenu()
        self.undo_item = edit_menu.Append(wx.ID_UNDO, "&Undo\tCtrl+Z")
        self.redo_item = edit_menu.Append(wx.ID_REDO, "&Redo\tCtrl+Y")
        edit_menu.AppendSeparator()
        self.cut_item = edit_menu.Append(wx.ID_CUT, "&Cut\tCtrl+X")
        self.copy_item = edit_menu.Append(wx.ID_COPY, "&Copy\tCtrl+C")
        self.paste_item = edit_menu.Append(wx.ID_PASTE, "&Paste\tCtrl+V")
        edit_menu.AppendSeparator()
        self.selectall_item = edit_menu.Append(wx.ID_SELECTALL, "&Select All\tCtrl+A")
        
        help_menu = CustomMenu()
        self.about_item = help_menu.Append(wx.ID_ABOUT, "&About\tCtrl+I")
        
        self.custom_menubar.Append(file_menu, "&File")
        self.custom_menubar.Append(edit_menu, "&Edit")
        self.custom_menubar.Append(help_menu, "&Help")

        entries = []
        for menu in [file_menu, edit_menu, help_menu]:
            for item in menu.items:
                if item.is_separator: continue
                accel = self._parse_accel(item.text, item.id)
                if accel: entries.append(accel)
        self.SetAcceleratorTable(wx.AcceleratorTable(entries))

    def on_redo(self, event):
        if self.text_ctrl.CanRedo(): self.text_ctrl.Redo()

    def on_new(self, event):
        if not self.maybe_save(): return
        self.text_ctrl.SetValue("")
        self.current_file = None
        self.current_encoding = "UTF-8"
        self.text_ctrl.DiscardEdits()
        self.update_status()

    def on_open(self, event):
        if not self.maybe_save(): return
        with wx.FileDialog(self, str(self.open_dialog_title),
                           wildcard=f"{self.open_dialog_file_type[0]}|*.txt|{self.open_dialog_file_type[1]}|*.*",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dlg:
            if dlg.ShowModal() == wx.ID_CANCEL: return
            path = dlg.GetPath()
            with open(path, 'rb') as f:
                raw = f.read()
                result = charset_normalizer.from_bytes(raw).best()
                if result:
                    content = result.string
                    self.current_encoding = result.encoding
                else:
                    content = raw.decode('utf-8', errors='replace')
                    self.current_encoding = "UTF-8"
            self.text_ctrl.SetValue(content)
            self.current_file = path
            self.text_ctrl.DiscardEdits()
            self.update_status()

    def on_save(self, event):
        if self.current_file: return self.save_to_path(self.current_file)
        else: return self.on_save_as(event)

    def on_save_as(self, event):
        with wx.FileDialog(self, str(self.save_as_dialog_title),
                           wildcard=f"{self.save_as_dialog_file_type[0]}|*.txt|{self.save_as_dialog_file_type[1]}|*.*",
                           style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as dlg:
            if dlg.ShowModal() == wx.ID_CANCEL: return False
            path = dlg.GetPath()
            return self.save_to_path(path)

    def save_to_path(self, path):
        try: 
            with open(path, 'w', encoding=self.current_encoding) as f:
                f.write(self.text_ctrl.GetValue())
        except Exception:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(self.text_ctrl.GetValue())
            self.current_encoding = "UTF-8"
        self.current_file = path
        self.text_ctrl.DiscardEdits()
        self.update_status()
        return True

    def on_undo(self, event):
        if self.text_ctrl.CanUndo(): self.text_ctrl.Undo()

    def on_cut(self, event):
        if self.text_ctrl.CanCut(): self.text_ctrl.Cut()

    def on_copy(self, event):
        if self.text_ctrl.CanCopy(): self.text_ctrl.Copy()

    def on_paste(self, event):
        if self.text_ctrl.CanPaste(): self.text_ctrl.Paste()

    def on_select_all(self, event):
        self.text_ctrl.SelectAll()

    def on_exit(self, event):
        if self.maybe_save(): self.Close()

    def on_about(self, event):
        wx.MessageBox(str(self.messagebox_about_text), str(self.messagebox_about_title), wx.OK | wx.ICON_INFORMATION)

    def maybe_save(self):
        if self.text_ctrl.IsModified():
            dlg = wx.MessageDialog(self, str(self.maybe_save_dialog_text), str(self.maybe_save_dialog_title),
                                   wx.YES_NO | wx.CANCEL | wx.ICON_QUESTION)
            res = dlg.ShowModal()
            if res == wx.ID_CANCEL: return False
            if res == wx.ID_YES: return bool(self.on_save(None))
        return True

    def on_close(self, event):
        if not self.maybe_save(): event.Veto(); return
        event.Skip()

    def on_text_change(self, event):
        self.update_status()
        event.Skip()

    def update_font(self):
        font = wx.Font(self.font_size, self.font_family, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL)
        self.text_ctrl.SetFont(font)

    def on_resize(self, event):
        self.Layout()
        event.Skip()

    def on_context_menu(self, event):
        menu = CustomMenu()
        cut_item = menu.Append(self.CUT_POPUP_ID, str(self.popup_cut_text))
        copy_item = menu.Append(self.COPY_POPUP_ID, str(self.popup_copy_text))
        paste_item = menu.Append(self.PASTE_POPUP_ID, str(self.popup_paste_text))
        menu.AppendSeparator()
        select_item = menu.Append(self.SELECTALL_POPUP_ID, str(self.popup_select_all_text))

        

        cut_item.Enable(self.text_ctrl.CanCut())
        copy_item.Enable(self.text_ctrl.CanCopy())
        paste_item.Enable(self.text_ctrl.CanPaste())
        select_item.Enable(bool(self.text_ctrl.GetValue()))

        pos = wx.GetMousePosition()
        popup = CustomMenuPopup(self, menu, 
                                bg_color=self.menu_bg_color, 
                                text_color=self.menu_text_color, 
                                hover_color=self.menu_hover_color, 
                                radius=self.menu_radius)
        popup.SetPosition(pos)
        popup.Popup()

    def create_status_bar(self):
        if Theme.style == "dark":
            self.custom_statusbar = CustomStatusBar(
                self,
                bg_color=(28, 28, 32),
                text_color=(235, 235, 235),
                sep_color=(60, 60, 70)
            )
        elif Theme.style == "light":
            self.custom_statusbar = CustomStatusBar(self, bg_color=(240, 240, 240), text_color=(0, 0, 0), sep_color=(200, 200, 200))
        self.custom_statusbar.SetStatusWidths([-2, -1, -1, -1])

    def update_status(self):
        pos = self.text_ctrl.GetInsertionPoint()
        text = self.text_ctrl.GetValue() or ""
        line = text.count('\n', 0, pos) + 1
        last_nl = text.rfind('\n', 0, pos)
        col = pos - last_nl if last_nl != -1 else pos + 1

        base = os.path.basename(self.current_file) if self.current_file else str(self.untitled_text)
        modified = "*" if self.text_ctrl.IsModified() else ""
        self.SetTitle(f"{self.title} - {base}{modified}")

        self.custom_statusbar.SetStatusText(f"{self.ln_text} {line}, {self.col_text} {col}", 0)
        self.custom_statusbar.SetStatusText(f"{len(text.split())} {self.words_text}", 1)
        self.custom_statusbar.SetStatusText(f"{self.chars_text}: {len(text)}", 2)