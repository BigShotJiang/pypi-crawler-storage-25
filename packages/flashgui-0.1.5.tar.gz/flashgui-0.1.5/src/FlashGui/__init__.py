from .FG_CALCULATOR import CALCULATOR
from .FG_NOTEPAD import NOTEPAD
from .FG_PAINT import PAINT
from .FG_CLOCK import CLOCK
from .FG_CALENDARY import CALENDAR
from .FG_WINDOW import WINDOW

__all__ = ["CALCULATOR", "NOTEPAD", "PAINT", "CLOCK", "CALENDAR", "WINDOW"]