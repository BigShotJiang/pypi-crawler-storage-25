# FlashGUI - Copyright (c) 2026 Robert Opris - Standard License
import wx
import time
from datetime import timedelta

class Theme:
    style = "light"

def make_colour(value):
    if value is None:
        return None
    if isinstance(value, wx.Colour):
        return value
    if isinstance(value, tuple):
        return wx.Colour(*value)
    return wx.Colour(value)


def apply_colour(widget, bg=None, fg=None):
    if bg is not None:
        widget.SetBackgroundColour(make_colour(bg))
    if fg is not None:
        widget.SetForegroundColour(make_colour(fg))


def set_text(widget, text):
    if widget is None or text is None:
        return
    text = str(text)
    try:
        if hasattr(widget, "SetLabel"):
            widget.SetLabel(text)
            return
    except Exception:
        pass
    try:
        if hasattr(widget, "SetValue"):
            widget.SetValue(text)
            return
    except Exception:
        pass


class FlickerFreeLabel(wx.Control):
    def __init__(self, parent, label="", fg_color="#1D1D1F", bg_color="#FFFFFF"):
        super().__init__(parent, style=wx.NO_BORDER)
        self.SetBackgroundStyle(wx.BG_STYLE_PAINT)

        self.label = str(label)
        self.font = self.GetFont()
        self.fg_color = make_colour(fg_color)
        self.bg_color = make_colour(bg_color)

        self.Bind(wx.EVT_PAINT, self.on_paint)
        self.Bind(wx.EVT_SIZE, self.on_size)

    def SetLabel(self, label):
        label = str(label)
        if self.label != label:
            self.label = label
            self.InvalidateBestSize()
            self.Refresh()

    def GetLabel(self):
        return self.label

    def SetFont(self, font):
        self.font = font
        self.InvalidateBestSize()
        self.Refresh()

    def SetForegroundColour(self, color):
        self.fg_color = make_colour(color)
        self.Refresh()

    def SetBackgroundColour(self, color):
        self.bg_color = make_colour(color)
        self.Refresh()

    def DoGetBestSize(self):
        dc = wx.ScreenDC()
        if self.font:
            dc.SetFont(self.font)
        tw, th = dc.GetTextExtent(self.label if self.label else "00:00:00")
        return wx.Size(tw, th)

    def on_size(self, event):
        self.Refresh()
        event.Skip()

    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self)
        dc.SetBackground(wx.Brush(self.bg_color))
        dc.Clear()

        if self.font:
            dc.SetFont(self.font)

        dc.SetTextForeground(self.fg_color)

        w, h = self.GetClientSize()
        tw, th = dc.GetTextExtent(self.label)
        x = max(0, (w - tw) // 2)
        y = max(0, (h - th) // 2)

        dc.DrawText(self.label, x, y)


class ScalablePanel(wx.Panel):
    def __init__(self, parent, bg_color="#FFFFFF"):
        super().__init__(parent)
        self.bg_color = make_colour(bg_color)
        self.SetBackgroundColour(self.bg_color)
        self.SetDoubleBuffered(True)
        self._resize_timer = None
        self._last_size = (-1, -1)
        self.Bind(wx.EVT_SIZE, self.on_resize)

    def on_resize(self, event):
        event.Skip()
        size = self.GetClientSize()
        if size == self._last_size:
            return
        self._last_size = size

        if self._resize_timer:
            self._resize_timer.Stop()
        else:
            self._resize_timer = wx.Timer(self)
            self.Bind(wx.EVT_TIMER, self.on_resize_timer, self._resize_timer)

        self._resize_timer.Start(50, oneShot=True)

    def on_resize_timer(self, event):
        self.Freeze()
        try:
            self.update_ui_scaling()
            self.Layout()
        finally:
            self.Thaw()

    def update_ui_scaling(self):
        pass


class ClockPanel(ScalablePanel):
    def __init__(
        self,
        parent,
        bg_color="#FFFFFF",
        time_color="#1D1D1F",
        date_color="#007AFF",
        time_text="00:00:00",
        date_text="DATE",
    ):
        super().__init__(parent, bg_color=bg_color)

        self.time_color = make_colour(time_color)
        self.date_color = make_colour(date_color)

        self.time_text = str(time_text)
        self.date_text = str(date_text)

        sizer = wx.BoxSizer(wx.VERTICAL)

        self.lbl_time = FlickerFreeLabel(self, label=self.time_text, fg_color=self.time_color, bg_color=bg_color)
        self.lbl_date = FlickerFreeLabel(self, label=self.date_text, fg_color=self.date_color, bg_color=bg_color)

        sizer.AddStretchSpacer(1)
        sizer.Add(self.lbl_time, 0, wx.EXPAND)
        sizer.Add(self.lbl_date, 0, wx.EXPAND | wx.TOP, 10)
        sizer.AddStretchSpacer(1)
        self.SetSizer(sizer)

        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.on_clock_timer, self.timer)
        self.timer.Start(100)

    def on_clock_timer(self, event):
        self.update_time()

    def update_time(self):
        new_time = time.strftime("%H:%M:%S")
        new_date = time.strftime("%A, %B %d, %Y").upper()

        if self.lbl_time.GetLabel() != new_time:
            self.lbl_time.SetLabel(new_time)
        if self.lbl_date.GetLabel() != new_date:
            self.lbl_date.SetLabel(new_date)

    def update_ui_scaling(self):
        w, _ = self.GetClientSize()
        self.lbl_time.SetFont(
            wx.Font(
                max(18, int(w * 0.10)),
                wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_BOLD,
            )
        )
        self.lbl_date.SetFont(
            wx.Font(
                max(10, int(w * 0.03)),
                wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_LIGHT,
            )
        )

    def Edit(
        self,
        bg_color=None,
        time_bg_color=None,
        time_fg_color=None,
        date_bg_color=None,
        date_fg_color=None,
        time_text=None,
        date_text=None,
    ):
        if bg_color is not None:
            self.bg_color = make_colour(bg_color)
            self.SetBackgroundColour(self.bg_color)

        if time_bg_color is not None:
            self.lbl_time.SetBackgroundColour(time_bg_color)
        else:
            self.lbl_time.SetBackgroundColour(self.bg_color)

        if time_fg_color is not None:
            self.lbl_time.SetForegroundColour(time_fg_color)

        if date_bg_color is not None:
            self.lbl_date.SetBackgroundColour(date_bg_color)
        else:
            self.lbl_date.SetBackgroundColour(self.bg_color)

        if date_fg_color is not None:
            self.lbl_date.SetForegroundColour(date_fg_color)

        if time_text is not None:
            self.time_text = str(time_text)
            self.lbl_time.SetLabel(self.time_text)

        if date_text is not None:
            self.date_text = str(date_text)
            self.lbl_date.SetLabel(self.date_text)

        self.Refresh()
        self.Layout()


class TimerPanel(ScalablePanel):
    def __init__(
        self,
        parent,
        bg_color="#FFFFFF",
        display_color="#1D1D1F",
        label_color="#8E8E93",
        spin_bg_color="#FFFFFF",
        spin_fg_color="#1D1D1F",
        button_start_bg="#1D1D1F",
        button_start_fg="#FFFFFF",
        button_reset_bg="#1D1D1F",
        button_reset_fg="#FFFFFF",
        display_text="00:00:00",
        lbl_h_text="h",
        lbl_m_text="m",
        lbl_s_text="s",
        btn_start_text="START",
        btn_pause_text="PAUSE",
        btn_reset_text="RESET",
    ):
        super().__init__(parent, bg_color=bg_color)

        self.time_left = 0
        self.running = False

        self.display_color = make_colour(display_color)
        self.label_color = make_colour(label_color)
        self.spin_bg_color = make_colour(spin_bg_color)
        self.spin_fg_color = make_colour(spin_fg_color)
        self.button_start_bg = make_colour(button_start_bg) if button_start_bg is not None else None
        self.button_start_fg = make_colour(button_start_fg)
        self.button_reset_bg = make_colour(button_reset_bg) if button_reset_bg is not None else None
        self.button_reset_fg = make_colour(button_reset_fg)

        self.display_text = str(display_text)
        self.lbl_h_text = str(lbl_h_text)
        self.lbl_m_text = str(lbl_m_text)
        self.lbl_s_text = str(lbl_s_text)
        self.btn_start_text = str(btn_start_text)
        self.btn_pause_text = str(btn_pause_text)
        self.btn_reset_text = str(btn_reset_text)

        self._btn_start_command = None
        self._btn_reset_command = None

        sizer = wx.BoxSizer(wx.VERTICAL)

        self.display = FlickerFreeLabel(self, label=self.display_text, fg_color=self.display_color, bg_color=bg_color)

        self.ctrl_sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.spin_h = wx.SpinCtrl(self, value="0", min=0, max=99)
        self.lbl_h = wx.StaticText(self, label=self.lbl_h_text)
        self.spin_m = wx.SpinCtrl(self, value="5", min=0, max=59)
        self.lbl_m = wx.StaticText(self, label=self.lbl_m_text)
        self.spin_s = wx.SpinCtrl(self, value="0", min=0, max=59)
        self.lbl_s = wx.StaticText(self, label=self.lbl_s_text)

        self.btn_start = wx.Button(self, label=self.btn_start_text)
        self.btn_reset = wx.Button(self, label=self.btn_reset_text)

        self._apply_small_label_style(self.lbl_h)
        self._apply_small_label_style(self.lbl_m)
        self._apply_small_label_style(self.lbl_s)

        self._apply_button_style(self.btn_start, self.button_start_bg, self.button_start_fg)
        self._apply_button_style(self.btn_reset, self.button_reset_bg, self.button_reset_fg)

        self._apply_spin_style(self.spin_h)
        self._apply_spin_style(self.spin_m)
        self._apply_spin_style(self.spin_s)

        self.ctrl_sizer.Add(self.spin_h, 0, wx.ALIGN_CENTER | wx.RIGHT, 2)
        self.ctrl_sizer.Add(self.lbl_h, 0, wx.ALIGN_CENTER | wx.RIGHT, 8)
        self.ctrl_sizer.Add(self.spin_m, 0, wx.ALIGN_CENTER | wx.RIGHT, 2)
        self.ctrl_sizer.Add(self.lbl_m, 0, wx.ALIGN_CENTER | wx.RIGHT, 8)
        self.ctrl_sizer.Add(self.spin_s, 0, wx.ALIGN_CENTER | wx.RIGHT, 2)
        self.ctrl_sizer.Add(self.lbl_s, 0, wx.ALIGN_CENTER | wx.RIGHT, 15)
        self.ctrl_sizer.Add(self.btn_start, 0, wx.ALIGN_CENTER | wx.RIGHT, 10)
        self.ctrl_sizer.Add(self.btn_reset, 0, wx.ALIGN_CENTER)

        sizer.AddStretchSpacer(1)
        sizer.Add(self.display, 0, wx.EXPAND)
        sizer.Add(self.ctrl_sizer, 0, wx.ALIGN_CENTER | wx.TOP, 30)
        sizer.AddStretchSpacer(1)
        self.SetSizer(sizer)

        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.on_tick, self.timer)
        self.btn_start.Bind(wx.EVT_BUTTON, self.toggle)
        self.btn_reset.Bind(wx.EVT_BUTTON, self.reset)

    def _apply_small_label_style(self, ctrl):
        ctrl.SetForegroundColour(self.label_color)
        ctrl.SetBackgroundColour(self.bg_color)

    def _apply_button_style(self, btn, bg_color, fg_color):
        if bg_color is not None:
            btn.SetBackgroundColour(bg_color)
        else:
            btn.SetBackgroundColour(self.bg_color)
        btn.SetForegroundColour(fg_color)

    def _apply_spin_style(self, spin):
        spin.SetBackgroundColour(self.spin_bg_color)
        spin.SetForegroundColour(self.spin_fg_color)

    def update_ui_scaling(self):
        w, h = self.GetClientSize()
        self.display.SetFont(
            wx.Font(
                max(18, int(w * 0.10)),
                wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_LIGHT,
            )
        )

        spin_w, ctrl_h = int(w * 0.10), int(h * 0.10)
        btn_w = int(w * 0.18)
        btn_font = max(9, int(h * 0.03))

        for ctrl in [
            self.spin_h, self.spin_m, self.spin_s,
            self.lbl_h, self.lbl_m, self.lbl_s,
            self.btn_start, self.btn_reset
        ]:
            ctrl.SetFont(
                wx.Font(
                    btn_font,
                    wx.FONTFAMILY_DEFAULT,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
            )

        for spin in [self.spin_h, self.spin_m, self.spin_s]:
            spin.SetMinSize((spin_w, ctrl_h))
            self._apply_spin_style(spin)

        for btn in [self.btn_start, self.btn_reset]:
            btn.SetMinSize((btn_w, ctrl_h))

    def toggle(self, event):
        if self._btn_start_command:
            self._btn_start_command()
            return

        if not self.running:
            if self.time_left <= 0:
                h = self.spin_h.GetValue()
                m = self.spin_m.GetValue()
                s = self.spin_s.GetValue()
                self.time_left = (h * 3600) + (m * 60) + s
                if self.time_left <= 0:
                    return

            self.timer.Start(1000)
            self.btn_start.SetLabel(self.btn_pause_text)
            self.running = True
        else:
            self.timer.Stop()
            self.btn_start.SetLabel(self.btn_start_text)
            self.running = False

    def on_tick(self, event):
        if self.time_left > 0:
            self.time_left -= 1
            h = self.time_left // 3600
            m = (self.time_left % 3600) // 60
            s = self.time_left % 60
            new_label = f"{h:02d}:{m:02d}:{s:02d}"

            if self.display.GetLabel() != new_label:
                self.display.SetLabel(new_label)
        else:
            self.timer.Stop()
            wx.MessageBox("Time's up!", "Notification")
            self.reset(None)

    def reset(self, event):
        if self._btn_reset_command:
            self._btn_reset_command()
            return

        self.timer.Stop()
        self.time_left = 0
        self.display.SetLabel(self.display_text)
        self.btn_start.SetLabel(self.btn_start_text)
        self.running = False

    def Edit(
        self,
        bg_color=None,
        display_bg_color=None,
        display_fg_color=None,

        spin_h_bg_color=None,
        spin_h_fg_color=None,
        spin_m_bg_color=None,
        spin_m_fg_color=None,
        spin_s_bg_color=None,
        spin_s_fg_color=None,

        lbl_h_bg_color=None,
        lbl_h_fg_color=None,
        lbl_m_bg_color=None,
        lbl_m_fg_color=None,
        lbl_s_bg_color=None,
        lbl_s_fg_color=None,

        btn_start_bg_color=None,
        btn_start_fg_color=None,
        btn_reset_bg_color=None,
        btn_reset_fg_color=None,

        display_text=None,
        lbl_h_text=None,
        lbl_m_text=None,
        lbl_s_text=None,
        btn_start_text=None,
        btn_pause_text=None,
        btn_reset_text=None,
    ):
        if bg_color is not None:
            self.bg_color = make_colour(bg_color)
            self.SetBackgroundColour(self.bg_color)
            self.display.SetBackgroundColour(self.bg_color)
            self.lbl_h.SetBackgroundColour(self.bg_color)
            self.lbl_m.SetBackgroundColour(self.bg_color)
            self.lbl_s.SetBackgroundColour(self.bg_color)

        if display_bg_color is not None:
            self.display.SetBackgroundColour(display_bg_color)
        else:
            self.display.SetBackgroundColour(self.bg_color)

        if display_fg_color is not None:
            self.display.SetForegroundColour(display_fg_color)

        if spin_h_bg_color is not None:
            self.spin_h.SetBackgroundColour(spin_h_bg_color)
        else:
            self.spin_h.SetBackgroundColour(self.spin_bg_color)
        if spin_h_fg_color is not None:
            self.spin_h.SetForegroundColour(spin_h_fg_color)
        else:
            self.spin_h.SetForegroundColour(self.spin_fg_color)

        if spin_m_bg_color is not None:
            self.spin_m.SetBackgroundColour(spin_m_bg_color)
        else:
            self.spin_m.SetBackgroundColour(self.spin_bg_color)
        if spin_m_fg_color is not None:
            self.spin_m.SetForegroundColour(spin_m_fg_color)
        else:
            self.spin_m.SetForegroundColour(self.spin_fg_color)

        if spin_s_bg_color is not None:
            self.spin_s.SetBackgroundColour(spin_s_bg_color)
        else:
            self.spin_s.SetBackgroundColour(self.spin_bg_color)
        if spin_s_fg_color is not None:
            self.spin_s.SetForegroundColour(spin_s_fg_color)
        else:
            self.spin_s.SetForegroundColour(self.spin_fg_color)

        if lbl_h_bg_color is not None:
            self.lbl_h.SetBackgroundColour(lbl_h_bg_color)
        else:
            self.lbl_h.SetBackgroundColour(self.bg_color)
        if lbl_h_fg_color is not None:
            self.lbl_h.SetForegroundColour(lbl_h_fg_color)
        else:
            self.lbl_h.SetForegroundColour(self.label_color)

        if lbl_m_bg_color is not None:
            self.lbl_m.SetBackgroundColour(lbl_m_bg_color)
        else:
            self.lbl_m.SetBackgroundColour(self.bg_color)
        if lbl_m_fg_color is not None:
            self.lbl_m.SetForegroundColour(lbl_m_fg_color)
        else:
            self.lbl_m.SetForegroundColour(self.label_color)

        if lbl_s_bg_color is not None:
            self.lbl_s.SetBackgroundColour(lbl_s_bg_color)
        else:
            self.lbl_s.SetBackgroundColour(self.bg_color)
        if lbl_s_fg_color is not None:
            self.lbl_s.SetForegroundColour(lbl_s_fg_color)
        else:
            self.lbl_s.SetForegroundColour(self.label_color)

        if btn_start_bg_color is not None:
            self.btn_start.SetBackgroundColour(btn_start_bg_color)
        else:
            self.btn_start.SetBackgroundColour(self.button_start_bg if self.button_start_bg is not None else self.bg_color)
        if btn_start_fg_color is not None:
            self.btn_start.SetForegroundColour(btn_start_fg_color)
        else:
            self.btn_start.SetForegroundColour(self.button_start_fg)

        if btn_reset_bg_color is not None:
            self.btn_reset.SetBackgroundColour(btn_reset_bg_color)
        else:
            self.btn_reset.SetBackgroundColour(self.button_reset_bg if self.button_reset_bg is not None else self.bg_color)
        if btn_reset_fg_color is not None:
            self.btn_reset.SetForegroundColour(btn_reset_fg_color)
        else:
            self.btn_reset.SetForegroundColour(self.button_reset_fg)

        if display_text is not None:
            self.display_text = str(display_text)
            self.display.SetLabel(self.display_text)

        if lbl_h_text is not None:
            self.lbl_h_text = str(lbl_h_text)
            self.lbl_h.SetLabel(self.lbl_h_text)

        if lbl_m_text is not None:
            self.lbl_m_text = str(lbl_m_text)
            self.lbl_m.SetLabel(self.lbl_m_text)

        if lbl_s_text is not None:
            self.lbl_s_text = str(lbl_s_text)
            self.lbl_s.SetLabel(self.lbl_s_text)

        if btn_start_text is not None:
            self.btn_start_text = str(btn_start_text)
            if not self.running:
                self.btn_start.SetLabel(self.btn_start_text)

        if btn_pause_text is not None:
            self.btn_pause_text = str(btn_pause_text)
            if self.running:
                self.btn_start.SetLabel(self.btn_pause_text)

        if btn_reset_text is not None:
            self.btn_reset_text = str(btn_reset_text)
            self.btn_reset.SetLabel(self.btn_reset_text)

        self.Refresh()
        self.Layout()


class StopwatchPanel(ScalablePanel):
    def __init__(
        self,
        parent,
        bg_color="#FFFFFF",
        display_color="#007AFF",
        button_start_bg="#1D1D1F",
        button_start_fg="#FFFFFF",
        button_reset_bg="#1D1D1F",
        button_reset_fg="#FFFFFF",
        display_text="00:00.0",
        btn_start_text="START",
        btn_stop_text="STOP",
        btn_reset_text="RESET",
    ):
        super().__init__(parent, bg_color=bg_color)

        self.elapsed = timedelta()
        self.running = False
        self.last_time = None

        self.display_color = make_colour(display_color)
        self.button_start_bg = make_colour(button_start_bg) if button_start_bg is not None else None
        self.button_start_fg = make_colour(button_start_fg)
        self.button_reset_bg = make_colour(button_reset_bg) if button_reset_bg is not None else None
        self.button_reset_fg = make_colour(button_reset_fg)

        self.display_text = str(display_text)
        self.btn_start_text = str(btn_start_text)
        self.btn_stop_text = str(btn_stop_text)
        self.btn_reset_text = str(btn_reset_text)

        self._btn_start_command = None
        self._btn_reset_command = None

        sizer = wx.BoxSizer(wx.VERTICAL)

        self.display = FlickerFreeLabel(self, label=self.display_text, fg_color=self.display_color, bg_color=bg_color)

        self.btn_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.btn_start = wx.Button(self, label=self.btn_start_text)
        self.btn_reset = wx.Button(self, label=self.btn_reset_text)

        self._apply_button_style(self.btn_start, self.button_start_bg, self.button_start_fg)
        self._apply_button_style(self.btn_reset, self.button_reset_bg, self.button_reset_fg)

        self.btn_sizer.Add(self.btn_start, 0, wx.RIGHT, 15)
        self.btn_sizer.Add(self.btn_reset, 0)

        sizer.AddStretchSpacer(1)
        sizer.Add(self.display, 0, wx.EXPAND)
        sizer.Add(self.btn_sizer, 0, wx.ALIGN_CENTER | wx.TOP, 40)
        sizer.AddStretchSpacer(1)
        self.SetSizer(sizer)

        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.on_tick, self.timer)
        self.btn_start.Bind(wx.EVT_BUTTON, self.toggle)
        self.btn_reset.Bind(wx.EVT_BUTTON, self.reset)

    def _apply_button_style(self, btn, bg_color, fg_color):
        if bg_color is not None:
            btn.SetBackgroundColour(bg_color)
        else:
            btn.SetBackgroundColour(self.bg_color)
        btn.SetForegroundColour(fg_color)

    def update_ui_scaling(self):
        w, h = self.GetClientSize()
        self.display.SetFont(
            wx.Font(
                max(18, int(w * 0.10)),
                wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_BOLD,
            )
        )

        btn_w, btn_h = int(w * 0.28), int(h * 0.14)
        btn_font = max(9, int(h * 0.035))

        for btn in [self.btn_start, self.btn_reset]:
            btn.SetMinSize((btn_w, btn_h))
            btn.SetFont(
                wx.Font(
                    btn_font,
                    wx.FONTFAMILY_DEFAULT,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
            )

    def toggle(self, event):
        if self._btn_start_command:
            self._btn_start_command()
            return

        if not self.running:
            self.last_time = time.time()
            self.timer.Start(50)
            self.btn_start.SetLabel(self.btn_stop_text)
            self.running = True
        else:
            self.timer.Stop()
            self.btn_start.SetLabel(self.btn_start_text)
            self.running = False

    def on_tick(self, event):
        if self.last_time is None:
            self.last_time = time.time()
            return

        now = time.time()
        self.elapsed += timedelta(seconds=now - self.last_time)
        self.last_time = now

        total_seconds = self.elapsed.total_seconds()
        m = int(total_seconds // 60)
        s = int(total_seconds % 60)
        tenths = int((total_seconds - int(total_seconds)) * 10)

        new_label = f"{m:02d}:{s:02d}.{tenths}"
        if self.display.GetLabel() != new_label:
            self.display.SetLabel(new_label)

    def reset(self, event):
        if self._btn_reset_command:
            self._btn_reset_command()
            return

        self.timer.Stop()
        self.elapsed = timedelta()
        self.last_time = None
        self.display.SetLabel(self.display_text)
        self.btn_start.SetLabel(self.btn_start_text)
        self.running = False

    def Edit(
        self,
        bg_color=None,
        display_bg_color=None,
        display_fg_color=None,
        btn_start_bg_color=None,
        btn_start_fg_color=None,
        btn_reset_bg_color=None,
        btn_reset_fg_color=None,
        display_text=None,
        btn_start_text=None,
        btn_stop_text=None,
        btn_reset_text=None,
    ):
        if bg_color is not None:
            self.bg_color = make_colour(bg_color)
            self.SetBackgroundColour(self.bg_color)

        if display_bg_color is not None:
            self.display.SetBackgroundColour(display_bg_color)
        else:
            self.display.SetBackgroundColour(self.bg_color)

        if display_fg_color is not None:
            self.display.SetForegroundColour(display_fg_color)

        if btn_start_bg_color is not None:
            self.btn_start.SetBackgroundColour(btn_start_bg_color)
        else:
            self.btn_start.SetBackgroundColour(self.button_start_bg if self.button_start_bg is not None else self.bg_color)

        if btn_start_fg_color is not None:
            self.btn_start.SetForegroundColour(btn_start_fg_color)
        else:
            self.btn_start.SetForegroundColour(self.button_start_fg)

        if btn_reset_bg_color is not None:
            self.btn_reset.SetBackgroundColour(btn_reset_bg_color)
        else:
            self.btn_reset.SetBackgroundColour(self.button_reset_bg if self.button_reset_bg is not None else self.bg_color)

        if btn_reset_fg_color is not None:
            self.btn_reset.SetForegroundColour(btn_reset_fg_color)
        else:
            self.btn_reset.SetForegroundColour(self.button_reset_fg)

        if display_text is not None:
            self.display_text = str(display_text)
            self.display.SetLabel(self.display_text)

        if btn_start_text is not None:
            self.btn_start_text = str(btn_start_text)
            if not self.running:
                self.btn_start.SetLabel(self.btn_start_text)

        if btn_stop_text is not None:
            self.btn_stop_text = str(btn_stop_text)
            if self.running:
                self.btn_start.SetLabel(self.btn_stop_text)

        if btn_reset_text is not None:
            self.btn_reset_text = str(btn_reset_text)
            self.btn_reset.SetLabel(self.btn_reset_text)

        self.Refresh()
        self.Layout()


class CLOCK:
    def __init__(
        self,
        title="Clock",
        size=(1.8, 2),
        color=(255, 255, 255),
        icon=None,
        maximized=False,
        min_size = (4, 3), 
        max_size = (1, 1), 
        style = "light"
    ):
        nav_clock_text="CLOCK"
        nav_timer_text="TIMER"
        nav_stopwatch_text="STOPWATCH"
        clock_time_text="00:00:00"
        clock_date_text="DATE"
        timer_display_text="00:00:00"
        timer_lbl_h_text="h"
        timer_lbl_m_text="m"
        timer_lbl_s_text="s"
        timer_btn_start_text="START"
        timer_btn_pause_text="PAUSE"
        timer_btn_reset_text="RESET"
        stopwatch_display_text="00:00.0"
        stopwatch_btn_start_text="START"
        stopwatch_btn_stop_text="STOP"
        stopwatch_btn_reset_text="RESET"

        if style == "dark":
            Theme.style = "dark"
        elif style == "light":
            Theme.style = "light"
        
        self.app = wx.App(False)

        self.frame_bg_color = make_colour(color)

        self.screen_width, self.screen_height = wx.GetDisplaySize()
        w = int(self.screen_width / float(size[0]))
        h = int(self.screen_height / float(size[1]))

        self.frame = wx.Frame(None, title=title, size=(w, h))
        self.frame.SetMinSize((int(self.screen_width//min_size[0]), int(self.screen_height//min_size[1])))
        self.frame.SetMaxSize((int(self.screen_width//max_size[0]), int(self.screen_height//max_size[1])))
        self.frame.SetBackgroundColour(self.frame_bg_color)
        self.frame.SetDoubleBuffered(True)

        if maximized:
            self.frame.Maximize(True)

        if icon:
            ext = icon.split('.')[-1].lower()
            if ext == "png":
                icon_type = wx.BITMAP_TYPE_PNG
            elif ext == "ico":
                icon_type = wx.BITMAP_TYPE_ICO
            else:
                icon_type = wx.BITMAP_TYPE_ANY
            self.frame.SetIcon(wx.Icon(icon, icon_type))

        self.main_sizer = wx.BoxSizer(wx.VERTICAL)

        self.nav_panel = wx.Panel(self.frame)
        self.nav_bg_color = make_colour("#F5F5F7")
        if Theme.style == "dark":
            self.nav_bg_color = make_colour("#242424")
        self.nav_panel.SetBackgroundColour(self.nav_bg_color)
        nav_sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.nav_active_fg = make_colour("#007AFF")
        self.nav_inactive_fg = make_colour("#8E8E93")
        self.nav_button_bg = make_colour("#F5F5F7")
        if Theme.style == "dark":
            self.nav_active_fg = make_colour("cyan")
            self.nav_inactive_fg = make_colour("red")
            self.nav_button_bg = make_colour("#242424")

        self.nav_clock_text = str(nav_clock_text)
        self.nav_timer_text = str(nav_timer_text)
        self.nav_stopwatch_text = str(nav_stopwatch_text)

        self.btn_clock = wx.Button(self.nav_panel, label=self.nav_clock_text, style=wx.BORDER_NONE)
        self.btn_timer = wx.Button(self.nav_panel, label=self.nav_timer_text, style=wx.BORDER_NONE)
        self.btn_stopwatch = wx.Button(self.nav_panel, label=self.nav_stopwatch_text, style=wx.BORDER_NONE)

        for btn in [self.btn_clock, self.btn_timer, self.btn_stopwatch]:
            btn.SetBackgroundColour(self.nav_button_bg)
            btn.SetForegroundColour(self.nav_inactive_fg)

        self._nav_clock_command = None
        self._nav_timer_command = None
        self._nav_stopwatch_command = None

        self.btn_clock.Bind(wx.EVT_BUTTON, self._on_nav_clock)
        self.btn_timer.Bind(wx.EVT_BUTTON, self._on_nav_timer)
        self.btn_stopwatch.Bind(wx.EVT_BUTTON, self._on_nav_stopwatch)

        nav_sizer.Add(self.btn_clock, 1, wx.EXPAND | wx.ALL, 10)
        nav_sizer.Add(self.btn_timer, 1, wx.EXPAND | wx.ALL, 10)
        nav_sizer.Add(self.btn_stopwatch, 1, wx.EXPAND | wx.ALL, 10)

        self.nav_panel.SetSizer(nav_sizer)
        self.main_sizer.Add(self.nav_panel, 0, wx.EXPAND)

        self.container = wx.Panel(self.frame)
        self.container.SetBackgroundColour(self.frame_bg_color)
        self.container_sizer = wx.BoxSizer(wx.VERTICAL)

        if Theme.style == "dark":
            self.pages = {
                "c": ClockPanel(
                    self.container,
                    bg_color="#1E1E1E",
                    time_color="#FFFFFF",
                    date_color="#4DA3FF",
                    time_text=clock_time_text,
                    date_text=clock_date_text,
                ),

                "t": TimerPanel(
                    self.container,
                    bg_color="#1E1E1E",
                    display_color="white",
                    label_color="#A0A0A0",
                    spin_bg_color="#2A2A2A",
                    spin_fg_color="#FFFFFF",
                    button_start_bg="#2A2A2A",
                    button_start_fg="#FFFFFF",
                    button_reset_bg="#2A2A2A",
                    button_reset_fg="#FFFFFF",
                    display_text=timer_display_text,
                    lbl_h_text=timer_lbl_h_text,
                    lbl_m_text=timer_lbl_m_text,
                    lbl_s_text=timer_lbl_s_text,
                    btn_start_text=timer_btn_start_text,
                    btn_pause_text=timer_btn_pause_text,
                    btn_reset_text=timer_btn_reset_text,
                ),

                "s": StopwatchPanel(
                    self.container,
                    bg_color="#1E1E1E",
                    display_color="white",
                    button_start_bg="#2A2A2A",
                    button_start_fg="#FFFFFF",
                    button_reset_bg="#2A2A2A",
                    button_reset_fg="#FFFFFF",
                    display_text=stopwatch_display_text,
                    btn_start_text=stopwatch_btn_start_text,
                    btn_stop_text=stopwatch_btn_stop_text,
                    btn_reset_text=stopwatch_btn_reset_text,
                ),
            }
        elif Theme.style == "light":
            self.pages = {
                "c": ClockPanel(
                    self.container,
                    bg_color="#FFFFFF",
                    time_color="#1D1D1F",
                    date_color="#007AFF",
                    time_text=clock_time_text,
                    date_text=clock_date_text,
                ),
                "t": TimerPanel(
                    self.container,
                    bg_color="#FFFFFF",
                    display_color="#007AFF",
                    label_color="#8E8E93",
                    spin_bg_color="#FFFFFF",
                    spin_fg_color="#1D1D1F",
                    button_start_bg=None,
                    button_start_fg="#1D1D1F",
                    button_reset_bg=None,
                    button_reset_fg="#1D1D1F",
                    display_text=timer_display_text,
                    lbl_h_text=timer_lbl_h_text,
                    lbl_m_text=timer_lbl_m_text,
                    lbl_s_text=timer_lbl_s_text,
                    btn_start_text=timer_btn_start_text,
                    btn_pause_text=timer_btn_pause_text,
                    btn_reset_text=timer_btn_reset_text,
                ),
                "s": StopwatchPanel(
                    self.container,
                    bg_color="#FFFFFF",
                    display_color="#007AFF",
                    button_start_bg=None,
                    button_start_fg="#1D1D1F",
                    button_reset_bg=None,
                    button_reset_fg="#1D1D1F",
                    display_text=stopwatch_display_text,
                    btn_start_text=stopwatch_btn_start_text,
                    btn_stop_text=stopwatch_btn_stop_text,
                    btn_reset_text=stopwatch_btn_reset_text,
                ),
            }

        for p in self.pages.values():
            self.container_sizer.Add(p, 1, wx.EXPAND)
            p.Hide()

        self.container.SetSizer(self.container_sizer)
        self.main_sizer.Add(self.container, 1, wx.EXPAND)

        self.frame.SetSizer(self.main_sizer)
        self.current_page = "c"
        self.show_page("c")
        self.frame.Center()
        self.frame.Bind(wx.EVT_SIZE, self.on_main_resize)
        self.frame.Show()

    def AddTimer(self, ms=1000, command=None):
        t = wx.Timer(self.frame)
        if command:
            self.frame.Bind(wx.EVT_TIMER, lambda e: command(), t)
        t.Start(ms)
        return t

    def _on_nav_clock(self, event):
        if self._nav_clock_command:
            self._nav_clock_command()
        else:
            self.show_page("c")

    def _on_nav_timer(self, event):
        if self._nav_timer_command:
            self._nav_timer_command()
        else:
            self.show_page("t")

    def _on_nav_stopwatch(self, event):
        if self._nav_stopwatch_command:
            self._nav_stopwatch_command()
        else:
            self.show_page("s")

    def on_main_resize(self, event):
        w, _ = self.frame.GetClientSize()
        nav_f = max(9, int(w * 0.022))

        for btn in [self.btn_clock, self.btn_timer, self.btn_stopwatch]:
            btn.SetFont(
                wx.Font(
                    nav_f,
                    wx.FONTFAMILY_DEFAULT,
                    wx.FONTSTYLE_NORMAL,
                    wx.FONTWEIGHT_BOLD,
                )
            )

        self.frame.Layout()
        event.Skip()

    def show_page(self, name):
        self.current_page = name

        for k, p in self.pages.items():
            if k == name:
                p.Show()
            else:
                p.Hide()

        self.btn_clock.SetForegroundColour(self.nav_active_fg if name == "c" else self.nav_inactive_fg)
        self.btn_timer.SetForegroundColour(self.nav_active_fg if name == "t" else self.nav_inactive_fg)
        self.btn_stopwatch.SetForegroundColour(self.nav_active_fg if name == "s" else self.nav_inactive_fg)

        self.frame.Layout()
        self.pages[name].update_ui_scaling()

    def Logic(
        self,
        nav_clock_command=None,
        nav_timer_command=None,
        nav_stopwatch_command=None,
        timer_start_command=None,
        timer_reset_command=None,
        stopwatch_start_command=None,
        stopwatch_reset_command=None,
        timer_base_h=None,
        timer_base_m=None,
        timer_base_s=None,
    ):
        self._nav_clock_command = nav_clock_command
        self._nav_timer_command = nav_timer_command
        self._nav_stopwatch_command = nav_stopwatch_command

        self.pages["t"]._btn_start_command = timer_start_command
        self.pages["t"]._btn_reset_command = timer_reset_command

        self.pages["s"]._btn_start_command = stopwatch_start_command
        self.pages["s"]._btn_reset_command = stopwatch_reset_command

        if timer_base_h is not None:
            self.pages["t"].spin_h.SetValue(int(timer_base_h))
        if timer_base_m is not None:
            self.pages["t"].spin_m.SetValue(int(timer_base_m))
        if timer_base_s is not None:
            self.pages["t"].spin_s.SetValue(int(timer_base_s))

    def Edit(
        self,
        title=None,
        nav_bg_color=None,
        nav_button_bg_color=None,
        nav_clock_fg_color=None,
        nav_timer_fg_color=None,
        nav_stopwatch_fg_color=None,
        nav_clock_text=None,
        nav_timer_text=None,
        nav_stopwatch_text=None,

        clock_bg_color=None,
        clock_time_bg_color=None,
        clock_time_fg_color=None,
        clock_date_bg_color=None,
        clock_date_fg_color=None,
        clock_time_text=None,
        clock_date_text=None,

        timer_bg_color=None,
        timer_display_bg_color=None,
        timer_display_fg_color=None,
        timer_spin_h_bg_color=None,
        timer_spin_h_fg_color=None,
        timer_spin_m_bg_color=None,
        timer_spin_m_fg_color=None,
        timer_spin_s_bg_color=None,
        timer_spin_s_fg_color=None,
        timer_lbl_h_bg_color=None,
        timer_lbl_h_fg_color=None,
        timer_lbl_m_bg_color=None,
        timer_lbl_m_fg_color=None,
        timer_lbl_s_bg_color=None,
        timer_lbl_s_fg_color=None,
        timer_btn_start_bg_color=None,
        timer_btn_start_fg_color=None,
        timer_btn_reset_bg_color=None,
        timer_btn_reset_fg_color=None,
        timer_display_text=None,
        timer_lbl_h_text=None,
        timer_lbl_m_text=None,
        timer_lbl_s_text=None,
        timer_btn_start_text=None,
        timer_btn_pause_text=None,
        timer_btn_reset_text=None,

        stopwatch_bg_color=None,
        stopwatch_display_bg_color=None,
        stopwatch_display_fg_color=None,
        stopwatch_btn_start_bg_color=None,
        stopwatch_btn_start_fg_color=None,
        stopwatch_btn_reset_bg_color=None,
        stopwatch_btn_reset_fg_color=None,
        stopwatch_display_text=None,
        stopwatch_btn_start_text=None,
        stopwatch_btn_stop_text=None,
        stopwatch_btn_reset_text=None,
    ):
        if title is not None:
            self.frame.SetTitle(str(title))

        if nav_bg_color is not None:
            self.nav_bg_color = make_colour(nav_bg_color)
            self.nav_panel.SetBackgroundColour(self.nav_bg_color)

        if nav_button_bg_color is not None:
            self.nav_button_bg = make_colour(nav_button_bg_color)
            for btn in [self.btn_clock, self.btn_timer, self.btn_stopwatch]:
                btn.SetBackgroundColour(self.nav_button_bg)

        if nav_clock_fg_color is not None:
            self.btn_clock.SetForegroundColour(nav_clock_fg_color)
        if nav_timer_fg_color is not None:
            self.btn_timer.SetForegroundColour(nav_timer_fg_color)
        if nav_stopwatch_fg_color is not None:
            self.btn_stopwatch.SetForegroundColour(nav_stopwatch_fg_color)

        if nav_clock_text is not None:
            self.nav_clock_text = str(nav_clock_text)
            self.btn_clock.SetLabel(self.nav_clock_text)
        if nav_timer_text is not None:
            self.nav_timer_text = str(nav_timer_text)
            self.btn_timer.SetLabel(self.nav_timer_text)
        if nav_stopwatch_text is not None:
            self.nav_stopwatch_text = str(nav_stopwatch_text)
            self.btn_stopwatch.SetLabel(self.nav_stopwatch_text)

        self.pages["c"].Edit(
            bg_color=clock_bg_color,
            time_bg_color=clock_time_bg_color,
            time_fg_color=clock_time_fg_color,
            date_bg_color=clock_date_bg_color,
            date_fg_color=clock_date_fg_color,
            time_text=clock_time_text,
            date_text=clock_date_text,
        )

        self.pages["t"].Edit(
            bg_color=timer_bg_color,
            display_bg_color=timer_display_bg_color,
            display_fg_color=timer_display_fg_color,
            spin_h_bg_color=timer_spin_h_bg_color,
            spin_h_fg_color=timer_spin_h_fg_color,
            spin_m_bg_color=timer_spin_m_bg_color,
            spin_m_fg_color=timer_spin_m_fg_color,
            spin_s_bg_color=timer_spin_s_bg_color,
            spin_s_fg_color=timer_spin_s_fg_color,
            lbl_h_bg_color=timer_lbl_h_bg_color,
            lbl_h_fg_color=timer_lbl_h_fg_color,
            lbl_m_bg_color=timer_lbl_m_bg_color,
            lbl_m_fg_color=timer_lbl_m_fg_color,
            lbl_s_bg_color=timer_lbl_s_bg_color,
            lbl_s_fg_color=timer_lbl_s_fg_color,
            btn_start_bg_color=timer_btn_start_bg_color,
            btn_start_fg_color=timer_btn_start_fg_color,
            btn_reset_bg_color=timer_btn_reset_bg_color,
            btn_reset_fg_color=timer_btn_reset_fg_color,
            display_text=timer_display_text,
            lbl_h_text=timer_lbl_h_text,
            lbl_m_text=timer_lbl_m_text,
            lbl_s_text=timer_lbl_s_text,
            btn_start_text=timer_btn_start_text,
            btn_pause_text=timer_btn_pause_text,
            btn_reset_text=timer_btn_reset_text,
        )

        self.pages["s"].Edit(
            bg_color=stopwatch_bg_color,
            display_bg_color=stopwatch_display_bg_color,
            display_fg_color=stopwatch_display_fg_color,
            btn_start_bg_color=stopwatch_btn_start_bg_color,
            btn_start_fg_color=stopwatch_btn_start_fg_color,
            btn_reset_bg_color=stopwatch_btn_reset_bg_color,
            btn_reset_fg_color=stopwatch_btn_reset_fg_color,
            display_text=stopwatch_display_text,
            btn_start_text=stopwatch_btn_start_text,
            btn_stop_text=stopwatch_btn_stop_text,
            btn_reset_text=stopwatch_btn_reset_text,
        )

        self.show_page(self.current_page)
        self.frame.Refresh()
        self.frame.Layout()

    def run(self):
        self.app.MainLoop()