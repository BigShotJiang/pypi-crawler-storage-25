# FlashGUI - Copyright (c) 2026 Robert Opris - Standard License
import wx
import calendar as pycal
from datetime import date

class Theme:
    style = "light"

def make_colour(value):
    if value is None:
        return None
    if isinstance(value, wx.Colour):
        return value
    if isinstance(value, tuple):
        return wx.Colour(*value)
    return wx.Colour(value)

def set_text(widget, text):
    if widget is None or text is None:
        return
    text = str(text)
    try:
        if hasattr(widget, "SetLabel"):
            widget.SetLabel(text)
            return
    except Exception:
        pass
    try:
        if hasattr(widget, "SetValue"):
            widget.SetValue(text)
            return
    except Exception:
        pass

class FlickerFreeLabel(wx.Control):
    def __init__(self, parent, label="", fg_color="#1D1D1F", bg_color="#FFFFFF"):
        super().__init__(parent, style=wx.NO_BORDER)
        self.SetBackgroundStyle(wx.BG_STYLE_PAINT)

        self.label = str(label)
        self.font = self.GetFont()
        self.fg_color = make_colour(fg_color)
        self.bg_color = make_colour(bg_color)
        print(Theme.style)
        if Theme.style == "dark":
            self.fg_color = make_colour("#FFFFFF")
            self.bg_color = make_colour("#1D1D1F")

        self.Bind(wx.EVT_PAINT, self.on_paint)
        self.Bind(wx.EVT_SIZE, self.on_size)

    def SetLabel(self, label):
        label = str(label)
        if self.label != label:
            self.label = label
            self.InvalidateBestSize()
            self.Refresh()

    def GetLabel(self):
        return self.label

    def SetFont(self, font):
        self.font = font
        self.InvalidateBestSize()
        self.Refresh()

    def SetForegroundColour(self, color):
        self.fg_color = make_colour(color)
        self.Refresh()

    def SetBackgroundColour(self, color):
        self.bg_color = make_colour(color)
        self.Refresh()

    def DoGetBestSize(self):
        dc = wx.ScreenDC()
        if self.font:
            dc.SetFont(self.font)
        tw, th = dc.GetTextExtent(self.label if self.label else "00:00")
        return wx.Size(tw, th)

    def on_size(self, event):
        self.Refresh()
        event.Skip()

    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self)
        dc.SetBackground(wx.Brush(self.bg_color))
        dc.Clear()

        if self.font:
            dc.SetFont(self.font)

        dc.SetTextForeground(self.fg_color)

        w, h = self.GetClientSize()
        tw, th = dc.GetTextExtent(self.label)
        x = max(0, (w - tw) // 2)
        y = max(0, (h - th) // 2)

        dc.DrawText(self.label, x, y)

class ScalablePanel(wx.Panel):
    def __init__(self, parent, bg_color="#FFFFFF"):
        super().__init__(parent)
        self.bg_color = make_colour(bg_color)
        self.SetBackgroundColour(self.bg_color)
        self.SetDoubleBuffered(True)
        self._resize_timer = None
        self._last_size = (-1, -1)
        self.Bind(wx.EVT_SIZE, self.on_resize)
        if Theme.style == "dark":
            self.bg_color = make_colour("#242424")

    def on_resize(self, event):
        event.Skip()
        size = self.GetClientSize()
        if size == self._last_size:
            return
        self._last_size = size

        if self._resize_timer:
            self._resize_timer.Stop()
        else:
            self._resize_timer = wx.Timer(self)
            self.Bind(wx.EVT_TIMER, self.on_resize_timer, self._resize_timer)

        self._resize_timer.Start(50, oneShot=True)

    def on_resize_timer(self, event):
        self.Freeze()
        try:
            self.update_ui_scaling()
            self.Layout()
        finally:
            self.Thaw()

    def update_ui_scaling(self):
        pass

class CalendarPanel(ScalablePanel):
    def __init__(
        self,
        parent,
        bg_color="#FFFFFF",
        title_fg_color="#1D1D1F",
        nav_bg_color="#F5F5F7",
        nav_button_bg_color="#F5F5F7",
        nav_button_fg_color="#007AFF",
        weekday_bg_color="#FFFFFF",
        weekday_fg_color="#8E8E93",
        day_bg_color="#FFFFFF",
        day_fg_color="#1D1D1F",
        day_disabled_bg_color="#FFFFFF",
        day_disabled_fg_color="#C7C7CC",
        day_today_bg_color="#007AFF",
        day_today_fg_color="#FFFFFF",
        day_selected_bg_color="#1D1D1F",
        day_selected_fg_color="#FFFFFF",
        footer_bg_color="#FFFFFF",
        footer_fg_color="#8E8E93",
        prev_text="‹",
        today_text="TODAY",
        next_text="›",
        week_start_monday=True,
        show_footer=True,
        info_text="Calendar created by FastGUI",
        january_text="JANUARY",
        february_text="FEBRUARY",
        march_text="MARCH",
        april_text="APRIL",
        may_text="MAY",
        june_text="JUNE",
        july_text="JULY",
        august_text="AUGUST",
        september_text="SEPTEMBER",
        october_text="OCTOBER",
        november_text="NOVEMBER",
        december_text="DECEMBER",
        monday_text="MON",
        tuesday_text="TUE",
        wednesday_text="WED",
        thursday_text="THU",
        friday_text="FRI",
        saturday_text="SAT",
        sunday_text="SUN",
    ):
        super().__init__(parent, bg_color=bg_color)

        if Theme.style == "dark":
            bg_color = "#1E1E1E"

            title_fg_color = "#FFFFFF"

            nav_bg_color = "#2A2A2A"
            nav_button_bg_color = "#2A2A2A"
            nav_button_fg_color = "#4DA3FF"

            weekday_bg_color = "#1E1E1E"
            weekday_fg_color = "#A0A0A0"

            day_bg_color = "#1E1E1E"
            day_fg_color = "#FFFFFF"

            day_disabled_bg_color = "#1E1E1E"
            day_disabled_fg_color = "#555555"

            day_today_bg_color = "#4DA3FF"
            day_today_fg_color = "#FFFFFF"

            day_selected_bg_color = "#FFFFFF"
            day_selected_fg_color = "#000000"

            footer_bg_color = "#1E1E1E"
            footer_fg_color = "#A0A0A0"

        today = date.today()
        self.selected_date = today
        self.view_year = today.year
        self.view_month = today.month

        self.week_start_monday = bool(week_start_monday)
        self.show_footer = bool(show_footer)

        self.january_text = str(january_text)
        self.february_text = str(february_text)
        self.march_text = str(march_text)
        self.april_text = str(april_text)
        self.may_text = str(may_text)
        self.june_text = str(june_text)
        self.july_text = str(july_text)
        self.august_text = str(august_text)
        self.september_text = str(september_text)
        self.october_text = str(october_text)
        self.november_text = str(november_text)
        self.december_text = str(december_text)

        self.monday_text = str(monday_text)
        self.tuesday_text = str(tuesday_text)
        self.wednesday_text = str(wednesday_text)
        self.thursday_text = str(thursday_text)
        self.friday_text = str(friday_text)
        self.saturday_text = str(saturday_text)
        self.sunday_text = str(sunday_text)

        self.title_fg_color = make_colour(title_fg_color)
        self.nav_bg_color = make_colour(nav_bg_color)
        self.nav_button_bg_color = make_colour(nav_button_bg_color)
        self.nav_button_fg_color = make_colour(nav_button_fg_color)
        self.weekday_bg_color = make_colour(weekday_bg_color)
        self.weekday_fg_color = make_colour(weekday_fg_color)
        self.day_bg_color = make_colour(day_bg_color)
        self.day_fg_color = make_colour(day_fg_color)
        self.day_disabled_bg_color = make_colour(day_disabled_bg_color)
        self.day_disabled_fg_color = make_colour(day_disabled_fg_color)
        self.day_today_bg_color = make_colour(day_today_bg_color)
        self.day_today_fg_color = make_colour(day_today_fg_color)
        self.day_selected_bg_color = make_colour(day_selected_bg_color)
        self.day_selected_fg_color = make_colour(day_selected_fg_color)
        self.footer_bg_color = make_colour(footer_bg_color)
        self.footer_fg_color = make_colour(footer_fg_color)

        self.prev_text = str(prev_text)
        self.today_text = str(today_text)
        self.next_text = str(next_text)
        self.info_text = str(info_text)

        self._prev_command = None
        self._next_command = None
        self._today_command = None
        self._day_command = None
        self._month_change_command = None

        main = wx.BoxSizer(wx.VERTICAL)

        self.top_panel = wx.Panel(self)
        self.top_panel.SetBackgroundColour(self.nav_bg_color)
        top_sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.btn_prev = wx.Button(self.top_panel, label=self.prev_text, style=wx.BORDER_NONE)
        self.btn_today = wx.Button(self.top_panel, label=self.today_text, style=wx.BORDER_NONE)
        self.btn_next = wx.Button(self.top_panel, label=self.next_text, style=wx.BORDER_NONE)

        self.nav_buttons = [self.btn_prev, self.btn_today, self.btn_next]
        for btn in self.nav_buttons:
            btn.SetBackgroundColour(self.nav_button_bg_color)
            btn.SetForegroundColour(self.nav_button_fg_color)

        self.lbl_month = FlickerFreeLabel(
            self.top_panel,
            label="MONTH",
            fg_color=self.title_fg_color,
            bg_color=self.nav_bg_color,
        )

        self.btn_prev.Bind(wx.EVT_BUTTON, self._on_prev)
        self.btn_today.Bind(wx.EVT_BUTTON, self._on_today)
        self.btn_next.Bind(wx.EVT_BUTTON, self._on_next)

        top_sizer.Add(self.btn_prev, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 8)
        top_sizer.Add(self.lbl_month, 1, wx.ALL | wx.EXPAND, 8)
        top_sizer.Add(self.btn_today, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 8)
        top_sizer.Add(self.btn_next, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 8)

        self.top_panel.SetSizer(top_sizer)
        main.Add(self.top_panel, 0, wx.EXPAND)

        self.weekday_panel = wx.Panel(self)
        self.weekday_panel.SetBackgroundColour(self.bg_color)
        weekday_sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.weekday_labels = []
        for _ in range(7):
            lbl = FlickerFreeLabel(self.weekday_panel, label="", fg_color=self.weekday_fg_color, bg_color=self.weekday_bg_color)
            self.weekday_labels.append(lbl)
            weekday_sizer.Add(lbl, 1, wx.EXPAND | wx.ALL, 2)

        self.weekday_panel.SetSizer(weekday_sizer)
        main.Add(self.weekday_panel, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 10)

        self.grid_panel = wx.Panel(self)
        self.grid_panel.SetBackgroundColour(self.bg_color)
        grid_sizer = wx.GridSizer(6, 7, 4, 4)

        self.day_buttons = []
        self.day_dates = [None] * 42

        for _ in range(42):
            btn = wx.Button(self.grid_panel, label="", style=wx.BORDER_NONE)
            btn.Bind(wx.EVT_BUTTON, self._on_day)
            self.day_buttons.append(btn)
            grid_sizer.Add(btn, 1, wx.EXPAND)

        self.grid_panel.SetSizer(grid_sizer)
        main.Add(self.grid_panel, 1, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 10)

        self.footer_panel = wx.Panel(self)
        self.footer_panel.SetBackgroundColour(self.footer_bg_color)
        footer_sizer = wx.BoxSizer(wx.VERTICAL)

        self.lbl_selected = FlickerFreeLabel(
            self.footer_panel,
            label="",
            fg_color=self.footer_fg_color,
            bg_color=self.footer_bg_color,
        )
        self.lbl_info = FlickerFreeLabel(
            self.footer_panel,
            label=self.info_text,
            fg_color=self.footer_fg_color,
            bg_color=self.footer_bg_color,
        )

        footer_sizer.Add(self.lbl_selected, 0, wx.EXPAND | wx.ALL, 8)
        footer_sizer.Add(self.lbl_info, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)
        self.footer_panel.SetSizer(footer_sizer)
        main.Add(self.footer_panel, 0, wx.EXPAND | wx.TOP, 10)

        self.SetSizer(main)

        self._sync_weekday_headers()
        self._apply_static_styles()
        self.refresh_calendar()
        self._update_footer()

        if not self.show_footer:
            self.footer_panel.Hide()

    def _weekday_names(self):
        names = [
            self.monday_text, self.tuesday_text, self.wednesday_text,
            self.thursday_text, self.friday_text, self.saturday_text, self.sunday_text
        ]
        if not self.week_start_monday:
            names = [names[-1]] + names[:-1]
        return names

    def _month_names(self):
        return [
            self.january_text, self.february_text, self.march_text, self.april_text,
            self.may_text, self.june_text, self.july_text, self.august_text,
            self.september_text, self.october_text, self.november_text, self.december_text
        ]

    def _calendar_firstweekday(self):
        return 0 if self.week_start_monday else 6

    def _sync_weekday_headers(self):
        for lbl, txt in zip(self.weekday_labels, self._weekday_names()):
            lbl.SetLabel(txt)

    def _apply_static_styles(self):
        self.SetBackgroundColour(self.bg_color)
        self.top_panel.SetBackgroundColour(self.nav_bg_color)
        self.weekday_panel.SetBackgroundColour(self.bg_color)
        self.grid_panel.SetBackgroundColour(self.bg_color)
        self.footer_panel.SetBackgroundColour(self.footer_bg_color)

        self.lbl_month.SetForegroundColour(self.title_fg_color)
        self.lbl_month.SetBackgroundColour(self.nav_bg_color)

        self.lbl_selected.SetForegroundColour(self.footer_fg_color)
        self.lbl_selected.SetBackgroundColour(self.footer_bg_color)

        self.lbl_info.SetForegroundColour(self.footer_fg_color)
        self.lbl_info.SetBackgroundColour(self.footer_bg_color)

        for btn in self.nav_buttons:
            btn.SetBackgroundColour(self.nav_button_bg_color)
            btn.SetForegroundColour(self.nav_button_fg_color)

        for lbl in self.weekday_labels:
            lbl.SetBackgroundColour(self.weekday_bg_color)
            lbl.SetForegroundColour(self.weekday_fg_color)

    def _apply_day_button_style(self, btn, d):
        if d is None:
            btn.SetBackgroundColour(self.day_disabled_bg_color)
            btn.SetForegroundColour(self.day_disabled_fg_color)
            btn.Disable()
            btn.SetLabel(" ")
            return

        btn.Enable()
        btn.SetLabel(str(d.day))

        if d == self.selected_date:
            btn.SetBackgroundColour(self.day_selected_bg_color)
            btn.SetForegroundColour(self.day_selected_fg_color)
        elif d == date.today():
            btn.SetBackgroundColour(self.day_today_bg_color)
            btn.SetForegroundColour(self.day_today_fg_color)
        else:
            btn.SetBackgroundColour(self.day_bg_color)
            btn.SetForegroundColour(self.day_fg_color)

    def _format_month_title(self):
        months = self._month_names()
        month_name = str(months[self.view_month - 1]).upper()
        return f"{month_name} {self.view_year}"

    def _format_selected(self):
        d = self.selected_date
        weekdays = [
            self.monday_text, self.tuesday_text, self.wednesday_text,
            self.thursday_text, self.friday_text, self.saturday_text, self.sunday_text
        ]
        months = self._month_names()
        weekday = weekdays[d.weekday()]
        month = months[d.month - 1]
        return f"{weekday}, {d.day} {month} {d.year}".upper()

    def _update_footer(self):
        self.lbl_selected.SetLabel(self._format_selected())
        self.lbl_info.SetLabel(self.info_text)

    def _emit_info(self, result):
        if isinstance(result, str) and result.strip():
            self.set_info_text(result)

    def _notify_month_change(self):
        if self._month_change_command:
            result = self._month_change_command(self.view_year, self.view_month)
            self._emit_info(result)

    def _notify_day_change(self, d):
        if self._day_command:
            result = self._day_command(d)
            self._emit_info(result)

    def _notify_today(self, d):
        if self._today_command:
            result = self._today_command(d)
            self._emit_info(result)

    def set_info_text(self, text):
        if text is None:
            return
        self.info_text = str(text)
        self.lbl_info.SetLabel(self.info_text)
        self.Layout()

    def get_selected_date(self):
        return self.selected_date

    def get_view_date(self):
        return date(self.view_year, self.view_month, 1)

    def set_selected_date(self, d, refresh=True):
        if not isinstance(d, date):
            return
        self.selected_date = d
        self.view_year = d.year
        self.view_month = d.month
        if refresh:
            self.refresh_calendar()

    def go_to_date(self, d):
        self.set_selected_date(d, refresh=True)

    def _shift_month(self, delta):
        month = self.view_month + delta
        year = self.view_year

        while month < 1:
            month += 12
            year -= 1
        while month > 12:
            month -= 12
            year += 1

        self.view_month = month
        self.view_year = year
        self.refresh_calendar()
        self._notify_month_change()

    def _on_prev(self, event):
        if self._prev_command:
            result = self._prev_command()
            self._emit_info(result)
            return
        self._shift_month(-1)

    def _on_next(self, event):
        if self._next_command:
            result = self._next_command()
            self._emit_info(result)
            return
        self._shift_month(1)

    def _on_today(self, event):
        if self._today_command:
            result = self._today_command(date.today())
            self._emit_info(result)
            return

        today = date.today()
        self.selected_date = today
        self.view_year = today.year
        self.view_month = today.month
        self.refresh_calendar()
        self._notify_month_change()

    def _on_day(self, event):
        btn = event.GetEventObject()
        try:
            idx = self.day_buttons.index(btn)
        except ValueError:
            return

        d = self.day_dates[idx]
        if d is None:
            return

        self.selected_date = d
        self.view_year = d.year
        self.view_month = d.month
        self.refresh_calendar()
        self._notify_day_change(d)

    def refresh_calendar(self):
        self.lbl_month.SetLabel(self._format_month_title())
        self.lbl_selected.SetLabel(self._format_selected())

        cal = pycal.Calendar(firstweekday=self._calendar_firstweekday())
        weeks = cal.monthdayscalendar(self.view_year, self.view_month)
        while len(weeks) < 6:
            weeks.append([0, 0, 0, 0, 0, 0, 0])

        idx = 0
        for week in weeks[:6]:
            for day_num in week:
                btn = self.day_buttons[idx]
                if day_num == 0:
                    self.day_dates[idx] = None
                    self._apply_day_button_style(btn, None)
                else:
                    d = date(self.view_year, self.view_month, day_num)
                    self.day_dates[idx] = d
                    self._apply_day_button_style(btn, d)
                idx += 1

        self.update_ui_scaling()
        self.Layout()
        self._update_footer()

    def update_ui_scaling(self):
        w, h = self.GetClientSize()

        # Titolo mese
        self.lbl_month.SetFont(
            wx.Font(
                max(18, int(w * 0.050)),
                wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_BOLD,
            )
        )

        # Testo footer
        self.lbl_selected.SetFont(
            wx.Font(
                max(10, int(w * 0.022)),
                wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_NORMAL,
            )
        )

        self.lbl_info.SetFont(
            wx.Font(
                max(9, int(w * 0.018)),
                wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_NORMAL,
            )
        )

        # Giorni settimana
        weekday_font = wx.Font(
            max(8, int(h * 0.018)),
            wx.FONTFAMILY_DEFAULT,
            wx.FONTSTYLE_NORMAL,
            wx.FONTWEIGHT_BOLD,
        )

        for lbl in self.weekday_labels:
            lbl.SetFont(weekday_font)
            lbl.SetBackgroundColour(self.weekday_bg_color)
            lbl.SetForegroundColour(self.weekday_fg_color)

        # Frecce più grandi
        arrow_font = wx.Font(
            max(16, int(h * 0.045)),
            wx.FONTFAMILY_DEFAULT,
            wx.FONTSTYLE_NORMAL,
            wx.FONTWEIGHT_BOLD,
        )

        # TODAY più piccolo e pulito
        text_font = wx.Font(
            max(9, int(h * 0.03)),
            wx.FONTFAMILY_DEFAULT,
            wx.FONTSTYLE_NORMAL,
            wx.FONTWEIGHT_BOLD,
        )

        self.btn_prev.SetFont(arrow_font)
        self.btn_next.SetFont(arrow_font)
        self.btn_today.SetFont(text_font)

        self.btn_prev.SetMinSize((max(56, int(w * 0.10)), max(38, int(h * 0.06))))
        self.btn_today.SetMinSize((max(90, int(w * 0.16)), max(38, int(h * 0.06))))
        self.btn_next.SetMinSize((max(56, int(w * 0.10)), max(38, int(h * 0.06))))

        for btn in self.nav_buttons:
            btn.SetBackgroundColour(self.nav_button_bg_color)
            btn.SetForegroundColour(self.nav_button_fg_color)

        # Bottoni giorni
        cell_w = max(34, int((w - 40) / 7))
        cell_h = max(30, int((h - 220) / 6))
        cell_size = min(cell_w, cell_h)

        day_font = wx.Font(
            max(9, int(cell_size * 0.35)),
            wx.FONTFAMILY_DEFAULT,
            wx.FONTSTYLE_NORMAL,
            wx.FONTWEIGHT_BOLD,
        )

        for btn in self.day_buttons:
            btn.SetFont(day_font)
            btn.SetMinSize((cell_size, cell_size))

        self.Layout()

    def Edit(
        self,
        bg_color=None,
        title_fg_color=None,
        nav_bg_color=None,
        nav_button_bg_color=None,
        nav_button_fg_color=None,
        prev_text=None,
        today_text=None,
        next_text=None,
        info_text=None,
        january_text=None,
        february_text=None,
        march_text=None,
        april_text=None,
        may_text=None,
        june_text=None,
        july_text=None,
        august_text=None,
        september_text=None,
        october_text=None,
        november_text=None,
        december_text=None,
        monday_text=None,
        tuesday_text=None,
        wednesday_text=None,
        thursday_text=None,
        friday_text=None,
        saturday_text=None,
        sunday_text=None,
        prev_button_bg_color=None,
        prev_button_fg_color=None,
        today_button_bg_color=None,
        today_button_fg_color=None,
        next_button_bg_color=None,
        next_button_fg_color=None,
        weekday_bg_color=None,
        weekday_fg_color=None,
        day_bg_color=None,
        day_fg_color=None,
        day_disabled_bg_color=None,
        day_disabled_fg_color=None,
        day_today_bg_color=None,
        day_today_fg_color=None,
        day_selected_bg_color=None,
        day_selected_fg_color=None,
        footer_bg_color=None,
        footer_fg_color=None,
        show_footer=None,
        week_start_monday=None,
    ):
        if bg_color is not None:
            self.bg_color = make_colour(bg_color)
            self.SetBackgroundColour(self.bg_color)
            self.weekday_panel.SetBackgroundColour(self.bg_color)
            self.grid_panel.SetBackgroundColour(self.bg_color)

        if title_fg_color is not None:
            self.title_fg_color = make_colour(title_fg_color)
            self.lbl_month.SetForegroundColour(self.title_fg_color)

        if nav_bg_color is not None:
            self.nav_bg_color = make_colour(nav_bg_color)
            self.top_panel.SetBackgroundColour(self.nav_bg_color)
            self.lbl_month.SetBackgroundColour(self.nav_bg_color)

        if nav_button_bg_color is not None:
            self.nav_button_bg_color = make_colour(nav_button_bg_color)

        if nav_button_fg_color is not None:
            self.nav_button_fg_color = make_colour(nav_button_fg_color)

        if prev_text is not None:
            self.prev_text = str(prev_text)
            self.btn_prev.SetLabel(self.prev_text)
        if today_text is not None:
            self.today_text = str(today_text)
            self.btn_today.SetLabel(self.today_text)
        if next_text is not None:
            self.next_text = str(next_text)
            self.btn_next.SetLabel(self.next_text)

        if january_text is not None:
            self.january_text = str(january_text)
        if february_text is not None:
            self.february_text = str(february_text)
        if march_text is not None:
            self.march_text = str(march_text)
        if april_text is not None:
            self.april_text = str(april_text)
        if may_text is not None:
            self.may_text = str(may_text)
        if june_text is not None:
            self.june_text = str(june_text)
        if july_text is not None:
            self.july_text = str(july_text)
        if august_text is not None:
            self.august_text = str(august_text)
        if september_text is not None:
            self.september_text = str(september_text)
        if october_text is not None:
            self.october_text = str(october_text)
        if november_text is not None:
            self.november_text = str(november_text)
        if december_text is not None:
            self.december_text = str(december_text)

        if monday_text is not None:
            self.monday_text = str(monday_text)
        if tuesday_text is not None:
            self.tuesday_text = str(tuesday_text)
        if wednesday_text is not None:
            self.wednesday_text = str(wednesday_text)
        if thursday_text is not None:
            self.thursday_text = str(thursday_text)
        if friday_text is not None:
            self.friday_text = str(friday_text)
        if saturday_text is not None:
            self.saturday_text = str(saturday_text)
        if sunday_text is not None:
            self.sunday_text = str(sunday_text)

        if prev_button_bg_color is not None:
            self.btn_prev.SetBackgroundColour(prev_button_bg_color)
        elif nav_button_bg_color is not None:
            self.btn_prev.SetBackgroundColour(self.nav_button_bg_color)

        if prev_button_fg_color is not None:
            self.btn_prev.SetForegroundColour(prev_button_fg_color)
        elif nav_button_fg_color is not None:
            self.btn_prev.SetForegroundColour(self.nav_button_fg_color)

        if today_button_bg_color is not None:
            self.btn_today.SetBackgroundColour(today_button_bg_color)
        elif nav_button_bg_color is not None:
            self.btn_today.SetBackgroundColour(self.nav_button_bg_color)

        if today_button_fg_color is not None:
            self.btn_today.SetForegroundColour(today_button_fg_color)
        elif nav_button_fg_color is not None:
            self.btn_today.SetForegroundColour(self.nav_button_fg_color)

        if next_button_bg_color is not None:
            self.btn_next.SetBackgroundColour(next_button_bg_color)
        elif nav_button_bg_color is not None:
            self.btn_next.SetBackgroundColour(self.nav_button_bg_color)

        if next_button_fg_color is not None:
            self.btn_next.SetForegroundColour(next_button_fg_color)
        elif nav_button_fg_color is not None:
            self.btn_next.SetForegroundColour(self.nav_button_fg_color)

        if weekday_bg_color is not None:
            self.weekday_bg_color = make_colour(weekday_bg_color)
        if weekday_fg_color is not None:
            self.weekday_fg_color = make_colour(weekday_fg_color)

        if day_bg_color is not None:
            self.day_bg_color = make_colour(day_bg_color)
        if day_fg_color is not None:
            self.day_fg_color = make_colour(day_fg_color)

        if day_disabled_bg_color is not None:
            self.day_disabled_bg_color = make_colour(day_disabled_bg_color)
        if day_disabled_fg_color is not None:
            self.day_disabled_fg_color = make_colour(day_disabled_fg_color)

        if day_today_bg_color is not None:
            self.day_today_bg_color = make_colour(day_today_bg_color)
        if day_today_fg_color is not None:
            self.day_today_fg_color = make_colour(day_today_fg_color)

        if day_selected_bg_color is not None:
            self.day_selected_bg_color = make_colour(day_selected_bg_color)
        if day_selected_fg_color is not None:
            self.day_selected_fg_color = make_colour(day_selected_fg_color)

        if footer_bg_color is not None:
            self.footer_bg_color = make_colour(footer_bg_color)
            self.footer_panel.SetBackgroundColour(self.footer_bg_color)
            self.lbl_selected.SetBackgroundColour(self.footer_bg_color)
            self.lbl_info.SetBackgroundColour(self.footer_bg_color)

        if footer_fg_color is not None:
            self.footer_fg_color = make_colour(footer_fg_color)
            self.lbl_selected.SetForegroundColour(self.footer_fg_color)
            self.lbl_info.SetForegroundColour(self.footer_fg_color)

        if info_text is not None:
            self.set_info_text(info_text)

        if week_start_monday is not None:
            self.week_start_monday = bool(week_start_monday)
            
        self._sync_weekday_headers()

        if show_footer is not None:
            self.show_footer = bool(show_footer)
            if self.show_footer:
                self.footer_panel.Show()
            else:
                self.footer_panel.Hide()

        self._apply_static_styles()
        self.refresh_calendar()
        self.Refresh()
        self.Layout()

class CALENDAR:
    def __init__(
        self,
        title="Calendar",
        size=(1.8, 2),
        color=(255, 255, 255),
        icon=None,
        maximized=False,
        min_size=(4, 3),
        max_size=None,
        style = "light"
    ):
        self.style = style
        self.app = wx.App(False)
        if self.style == "dark":
            self.frame_bg_color = make_colour((15,15,15))
            Theme.style = "dark"
        elif self.style == "light":
            self.frame_bg_color = make_colour(color)
            Theme.style = "light"

        self.screen_width, self.screen_height = wx.GetDisplaySize()
        w = int(self.screen_width / float(size[0]))
        h = int(self.screen_height / float(size[1]))

        self.frame = wx.Frame(None, title=title, size=(w, h), )
        self.frame.SetMinSize((int(self.screen_width // min_size[0]), int(self.screen_height // min_size[1])))

        if max_size is not None:
            self.frame.SetMaxSize((int(self.screen_width // max_size[0]), int(self.screen_height // max_size[1])))

        self.frame.SetBackgroundColour(self.frame_bg_color)
        self.frame.SetDoubleBuffered(True)

        if maximized:
            self.frame.Maximize(True)

        if icon:
            ext = icon.split(".")[-1].lower()
            if ext == "png":
                icon_type = wx.BITMAP_TYPE_PNG
            elif ext == "ico":
                icon_type = wx.BITMAP_TYPE_ICO
            else:
                icon_type = wx.BITMAP_TYPE_ANY
            self.frame.SetIcon(wx.Icon(icon, icon_type))

        if self.style == "dark":
            self.panel = CalendarPanel(
                self.frame,
                bg_color="#242424",
                week_start_monday=False,
                show_footer=True,
            )
        elif self.style == "light":
            self.panel = CalendarPanel(
                self.frame,
                bg_color="#FFFFFF",
                week_start_monday=False,
                show_footer=True,
            )

        root = wx.BoxSizer(wx.VERTICAL)
        root.Add(self.panel, 1, wx.EXPAND)
        self.frame.SetSizer(root)

        self.frame.Center()
        self.frame.Bind(wx.EVT_SIZE, self.on_resize)
        self.frame.Show()

    def on_resize(self, event):
        self.frame.Layout()
        event.Skip()

    def Logic(
        self,
        prev_command=False,
        next_command=False,
        today_command=False,
        day_command=False,
        month_change_command=False,
        week_start_monday=None,
        show_footer=None,
    ):
        if prev_command is not False:
            self.panel._prev_command = prev_command
        if next_command is not False:
            self.panel._next_command = next_command
        if today_command is not False:
            self.panel._today_command = today_command
        if day_command is not False:
            self.panel._day_command = day_command
        if month_change_command is not False:
            self.panel._month_change_command = month_change_command
            
        self.panel.Edit(week_start_monday=week_start_monday, show_footer=show_footer)

    def Edit(
        self,
        title=None,
        frame_bg_color=None,
        bg_color=None,
        title_fg_color=None,
        nav_bg_color=None,
        nav_button_bg_color=None,
        nav_button_fg_color=None,
        prev_text=None,
        today_text=None,
        next_text=None,
        info_text=None,
        january_text=None,
        february_text=None,
        march_text=None,
        april_text=None,
        may_text=None,
        june_text=None,
        july_text=None,
        august_text=None,
        september_text=None,
        october_text=None,
        november_text=None,
        december_text=None,
        monday_text=None,
        tuesday_text=None,
        wednesday_text=None,
        thursday_text=None,
        friday_text=None,
        saturday_text=None,
        sunday_text=None,
        prev_button_bg_color=None,
        prev_button_fg_color=None,
        today_button_bg_color=None,
        today_button_fg_color=None,
        next_button_bg_color=None,
        next_button_fg_color=None,
        weekday_bg_color=None,
        weekday_fg_color=None,
        day_bg_color=None,
        day_fg_color=None,
        day_disabled_bg_color=None,
        day_disabled_fg_color=None,
        day_today_bg_color=None,
        day_today_fg_color=None,
        day_selected_bg_color=None,
        day_selected_fg_color=None,
        footer_bg_color=None,
        footer_fg_color=None,
        show_footer=None,
        week_start_monday=None,
    ):
        if title is not None:
            self.frame.SetTitle(str(title))

        if frame_bg_color is not None:
            self.frame_bg_color = make_colour(frame_bg_color)
            self.frame.SetBackgroundColour(self.frame_bg_color)

        self.panel.Edit(
            bg_color=bg_color,
            title_fg_color=title_fg_color,
            nav_bg_color=nav_bg_color,
            nav_button_bg_color=nav_button_bg_color,
            nav_button_fg_color=nav_button_fg_color,
            prev_text=prev_text,
            today_text=today_text,
            next_text=next_text,
            info_text=info_text,
            january_text=january_text,
            february_text=february_text,
            march_text=march_text,
            april_text=april_text,
            may_text=may_text,
            june_text=june_text,
            july_text=july_text,
            august_text=august_text,
            september_text=september_text,
            october_text=october_text,
            november_text=november_text,
            december_text=december_text,
            monday_text=monday_text,
            tuesday_text=tuesday_text,
            wednesday_text=wednesday_text,
            thursday_text=thursday_text,
            friday_text=friday_text,
            saturday_text=saturday_text,
            sunday_text=sunday_text,
            prev_button_bg_color=prev_button_bg_color,
            prev_button_fg_color=prev_button_fg_color,
            today_button_bg_color=today_button_bg_color,
            today_button_fg_color=today_button_fg_color,
            next_button_bg_color=next_button_bg_color,
            next_button_fg_color=next_button_fg_color,
            weekday_bg_color=weekday_bg_color,
            weekday_fg_color=weekday_fg_color,
            day_bg_color=day_bg_color,
            day_fg_color=day_bg_color,
            day_disabled_bg_color=day_disabled_bg_color,
            day_disabled_fg_color=day_disabled_fg_color,
            day_today_bg_color=day_today_bg_color,
            day_today_fg_color=day_today_fg_color,
            day_selected_bg_color=day_selected_bg_color,
            day_selected_fg_color=day_selected_fg_color,
            footer_bg_color=footer_bg_color,
            footer_fg_color=footer_fg_color,
            show_footer=show_footer,
            week_start_monday=week_start_monday,
        )

        self.frame.Refresh()
        self.frame.Layout()

    def AddTimer(self, ms=1000, command=None):
        t = wx.Timer(self.frame)
        if command:
            self.frame.Bind(wx.EVT_TIMER, lambda e: command(), t)
        t.Start(ms)
        return t

    def get_selected_date(self):
        return self.panel.get_selected_date()

    def go_to_date(self, d):
        self.panel.go_to_date(d)

    def set_info_text(self, text):
        self.panel.set_info_text(text)

    def run(self):
        self.app.MainLoop()