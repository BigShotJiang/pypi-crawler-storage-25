FlashGUI - Copyright (c) 2026 [Robert Opris] - Licensed under FlashGUI Standard License

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to use, copy, integrate, and build end-user applications with the Software, including for commercial purposes, subject to the following strict conditions:

1. ATTRIBUTION AND COPYRIGHT
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. You must clearly acknowledge the original authorship of this library.

2. ANTI-IMPERSONATION AND BRAND PROTECTION
You may not distribute modified or unmodified versions of this Software and claim it as your own original work. Furthermore, you may not use the name "FlashGUI", or any confusingly similar name, for modified versions, forks, or derived libraries without explicit prior written permission from the original author. This prevents third parties from tarnishing the reputation of the original Software.

3. NO STANDALONE RESALE
You may not sell, sub-license, or otherwise monetize this Software (or trivially modified versions of it) as a standalone library, framework, or development tool. You are, however, fully permitted to monetize and sell end-user applications (e.g., complete commercial desktop software, tools, or games) that incorporate or depend on this Software.

4. NON-ENDORSEMENT
The name of the author may not be used to endorse or promote products derived from this Software without specific prior written permission.

5. THIRD-PARTY COMPONENTS
This Software is built utilizing third-party open-source libraries, including but not limited to charset_normalizer (MIT License) and wxPython (GNU LGPL). Their respective licenses and copyrights remain intact, and users of this Software must comply with those upstream licenses where applicable.

DISCLAIMER OF WARRANTY
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.