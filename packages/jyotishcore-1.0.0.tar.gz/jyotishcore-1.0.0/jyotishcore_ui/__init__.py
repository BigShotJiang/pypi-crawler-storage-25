"""
JyotishCore Interactive UI Module
"""
