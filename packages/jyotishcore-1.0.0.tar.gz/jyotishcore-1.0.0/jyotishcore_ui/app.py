import streamlit as st
import sys
import os
from streamlit.web import cli as stcli

def main():
    if not hasattr(st, "runtime") or not st.runtime.exists():
        sys.argv = ["streamlit", "run", __file__, "--server.headless=true"]
        sys.exit(stcli.main())

    st.set_page_config(page_title="JyotishCore API Explorer", layout="wide", page_icon="✨")

    # Local imports to avoid requiring jyotishcore if they don't have the engine built yet
    try:
        from jyotishcore import Chart, get_panchanga, GeoLocation, JyotishTime, Ayanamsa
        from jyotishcore.helpers import find_time_windows
    except ImportError:
        st.error("JyotishCore is not installed or built in this environment.")
        st.stop()

    st.title("✨ JyotishCore Developer Dashboard")
    st.markdown("Interactive playground for the world's most accurate Vedic astrology engine.")

    tab1, tab2, tab3 = st.tabs(["Chart Calculation", "Regional Panchanga", "Muhurta Finder"])

    with st.sidebar:
        st.header("Settings")
        st.write("Configure the global calculation parameters here.")
        lat = st.number_input("Latitude", value=27.7172)
        lon = st.number_input("Longitude", value=85.3240)
        ayanamsa = st.selectbox("Ayanamsa", [a.value for a in Ayanamsa], index=0)
        locale = st.selectbox("Locale", ["en", "hi", "ne"], index=0)
        
        st.divider()
        st.write("Date & Time (UTC)")
        year = st.number_input("Year", value=2024)
        month = st.number_input("Month", value=5, min_value=1, max_value=12)
        day = st.number_input("Day", value=15, min_value=1, max_value=31)
        hour = st.number_input("Hour", value=12, min_value=0, max_value=23)
        minute = st.number_input("Minute", value=0, min_value=0, max_value=59)

        geo = GeoLocation(latitude=lat, longitude=lon)
        time = JyotishTime(year=year, month=month, day=day, hour=hour, minute=minute)
        aya = Ayanamsa(ayanamsa)

    with tab1:
        st.header("Natal Chart")
        with st.spinner("Calculating chart..."):
            chart = Chart.compute(time=time, location=geo, ayanamsa_obj=aya, locale=locale)
            
            lagna = chart.ascendant()
            st.metric("Ascendant (Lagna) Longitude", f"{lagna:.2f}°")
            
            st.subheader("Planetary Positions")
            planets = chart.planets()
            st.write([{
                "Planet": p.planet,
                "Longitude": f"{p.longitude:.2f}°",
                "Sign": p.sign,
                "Nakshatra": p.nakshatra,
                "House": p.house,
                "Retrograde": "Yes" if p.is_retrograde else "No"
            } for p in planets.values()])

    with tab2:
        st.header("Daily Panchanga")
        with st.spinner("Fetching Panchanga..."):
            p = get_panchanga(
                year=year, month=month, day=day, hour=hour, minute=minute, second=0,
                latitude=lat, longitude=lon,
                ayanamsa=ayanamsa, locale=locale
            )
            
            col1, col2, col3 = st.columns(3)
            col1.metric("Tithi", f'{p.tithi.get("name", "")} ({p.tithi.get("paksha", "")})')
            col2.metric("Nakshatra", p.nakshatra.get("name", ""))
            col3.metric("Yoga", p.yoga.get("name", ""))
            
            col4, col5, col6 = st.columns(3)
            col4.metric("Karana", p.karana.get("name", ""))
            col5.metric("Vara (Day)", p.vara.get("name", ""))

    with tab3:
        st.header("Muhurta Finder")
        st.write("Find specific Varga (Divisional) ascendants within a time window.")
        
        target = st.selectbox("Target Sign", [
            "aries", "taurus", "gemini", "cancer", "leo", "virgo", 
            "libra", "scorpio", "sagittarius", "capricorn", "aquarius", "pisces"
        ], index=1)
        varga = st.number_input("Divisional Chart (Varga)", value=9, min_value=1, max_value=144)
        window = st.number_input("Search Window (minutes)", value=1440, min_value=60)
        
        if st.button("Search Time Windows"):
            with st.spinner("Searching..."):
                dt_str = f"{year:04d}-{month:02d}-{day:02d}T{hour:02d}:{minute:02d}:00Z"
                windows = find_time_windows(
                    base_date=dt_str, window_minutes=window, varga=varga, 
                    target_sign=target, lat=lat, lon=lon, ayanamsa=ayanamsa
                )
                
                st.success(f"Found {len(windows)} windows!")
                for i, (start, end) in enumerate(windows):
                    st.write(f"**Window {i+1}:** {start} ➡️ {end}")

if __name__ == "__main__":
    main()
