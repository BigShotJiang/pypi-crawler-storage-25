# Contributing to JyotishCore

First off, thank you for considering contributing to JyotishCore!

## Development Setup

1. Install Rust (`curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`)
2. Install Python 3.9+
3. Create a virtual environment: `python -m venv .venv && source .venv/bin/activate`
4. Install Matruin: `pip install maturin`
5. Build the Python extension: `maturin develop --release --features python`

## Testing

- Rust tests: `cargo test`
- Python tests: `pip install pytest && pytest tests/`

## Pull Request Process

1. Ensure all tests pass.
2. Update the README.md with details of changes to the interface.
3. You may merge the Pull Request in once you have the sign-off of two other developers, or if you do not have permission to do that, you may request the second reviewer to merge it for you.
