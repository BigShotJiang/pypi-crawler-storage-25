# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

Please report security issues to sakshyambanjade@gmail.com rather than creating a public issue. We will respond within 48 hours.
