# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0-beta] - 2026-05-16

### Added
- **Panchanga.from_local**: timezone-aware civil_day and sunrise_day modes with UTC/local start and end times.
- **VargaPosition**: divisional charts expose `source_longitude`, `varga_sign`, `varga_index`, and optional `display_longitude` (drawing only).
- **Chart.settings()**: alias for calculation metadata.
- Split `requirements-dev.txt` and `requirements-api.txt`.

### Changed
- **compute_bs** and **get_transits**: strict ayanamsa/house-system validation (no silent fallback).
- Panchanga vara derived from local civil date or sunrise day, not raw UTC weekday.
- Removed tracked `seasnam.txt` and `list.zip` ephemeris bulk files from the repository.

### Added (0.2.0b0 continued)
- **Jaimini Karakas**: Native support for 7-Karaka system (Atmakaraka through Darakaraka).
- **Causal Explanation Engine**: Integrated a live AI-powered knowledge graph for chart interpretations.
- **Divisional Charts (Vargas)**: Corrected mathematical starting signs for high-index vargas (D-16 to D-60).
- **Panchanga Enhancements**: Added `Vara` (weekday) and fixed Karana cycle logic.
- **Benchmarking**: Performance metrics added to documentation.

### Changed
- **Native Python Bindings**: Refactored PyO3 bridge to return native `PyClass` objects instead of JSON strings.
- **API Modernization**: Updated FastAPI server to leverage native types, reducing serialization overhead.
- **Project Structure**: Aligned directory structure for `maturin` and `pip` compatibility.

### Fixed
- **Swiss Ephemeris Stability**: Fixed `NaN` errors by configuring auto-selection of ephemeris models.
- **Test Suite**: Resolved panics in calculation closures and enforced sequential test execution.
- **Documentation**: Fixed `minute=61` typos and updated examples.

## [0.1.0] - 2024-05-15

### Added
- Initial release with core Swiss Ephemeris bindings.
- Basic Chart, Dasha, and Panchanga calculations.
- FastAPI server scaffold.
