import time
import statistics
from jyotishcore import Chart, get_panchanga

def benchmark_chart(iterations=1000):
    print(f"Benchmarking {iterations} Chart.compute() calls...")
    times = []
    for _ in range(iterations):
        start = time.perf_counter()
        Chart.compute(
            year=1990, month=5, day=15,
            hour=12, minute=0, second=0,
            latitude=28.6139, longitude=77.2090, altitude=0,
            ayanamsa="lahiri"
        )
        times.append((time.perf_counter() - start) * 1000) # ms
    
    print(f"  Mean: {statistics.mean(times):.3f} ms")
    print(f"  Median: {statistics.median(times):.3f} ms")
    print(f"  Min: {min(times):.3f} ms")
    print(f"  Max: {max(times):.3f} ms")

def benchmark_panchanga(iterations=1000):
    print(f"Benchmarking {iterations} get_panchanga() calls...")
    times = []
    for _ in range(iterations):
        start = time.perf_counter()
        get_panchanga(
            year=2026, month=5, day=15,
            hour=12, minute=0, second=0,
            latitude=27.7172, longitude=85.3240, altitude=0
        )
        times.append((time.perf_counter() - start) * 1000) # ms
    
    print(f"  Mean: {statistics.mean(times):.3f} ms")
    print(f"  Median: {statistics.median(times):.3f} ms")
    print(f"  Min: {min(times):.3f} ms")
    print(f"  Max: {max(times):.3f} ms")

if __name__ == "__main__":
    benchmark_chart(100)
    benchmark_panchanga(100)
