use chrono::{TimeZone, Utc};
use jyotishcore::*;

fn main() {
    let birth = Utc.with_ymd_and_hms(2000, 1, 1, 4, 30, 0).unwrap();
    let geo = GeoPosition {
        latitude: 13.0827,
        longitude: 80.2707,
        altitude: 0.0,
    };

    println!("--- Calculating Full Chart ---");
    let chart =
        calc::chart::calculate_chart(birth, geo, AyanamsaMode::Lahiri, HouseSystem::Equal, true)
            .unwrap();

    println!("Ascendant: {:.2}°", chart.ascendant);
    println!("\nPlanets:");
    for p in &chart.planets {
        println!(
            "{:?}: {:.2}° in {:?} (nakshatra {:?}, house {})",
            p.planet,
            p.longitude,
            p.sign.unwrap(),
            p.nakshatra.unwrap(),
            p.house.unwrap()
        );
    }

    println!("\n--- Divisional Chart (D-9 Navamsa) ---");
    let d9 = chart.divisional_charts.get(&9).unwrap();
    for p in d9 {
        println!("{:?}: {:?}", p.planet, p.varga_sign);
    }

    println!("\nVimshottari Dasha:");
    let dasha = chart
        .dasha
        .get("vimshottari")
        .expect("vimshottari dasha should be present");
    for maha in dasha.iter().take(3) {
        println!(
            "{:?} mahadasha: {} - {}",
            maha.lord_name,
            maha.start.format("%Y-%m-%d"),
            maha.end.format("%Y-%m-%d")
        );
        for antar in maha.sub_periods.iter().take(3) {
            println!(
                "   {:?} antardasha: {} - {}",
                antar.lord_name,
                antar.start.format("%Y-%m-%d"),
                antar.end.format("%Y-%m-%d")
            );
        }
    }
}
