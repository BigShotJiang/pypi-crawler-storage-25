use chrono::{TimeZone, Utc};
use jyotishcore::*;

fn main() {
    // A sample birth with Moon and Jupiter in Kendras
    // Jan 1 2000 has Jupiter in Aries (H2 approx) and Moon in Libra (H9 approx)
    // Wait, let's find a date with Gaja Kesari.
    // If Moon is in H1 and Jupiter is in H4, that's a kendra.

    let birth = Utc.with_ymd_and_hms(2024, 5, 15, 12, 0, 0).unwrap();
    let geo = GeoPosition {
        latitude: 27.7172,
        longitude: 85.3240,
        altitude: 0.0,
    };
    let chart =
        calc::chart::calculate_chart(birth, geo, AyanamsaMode::Lahiri, HouseSystem::Equal, true)
            .unwrap();

    println!("--- Analyzing Yogas (Explainable AI) ---");
    let explanation = knowledge::get_explanation(&chart);

    if explanation.nodes.is_empty() {
        println!("No yogas detected for this chart.");
    } else {
        println!("{}", knowledge::graph_to_json(&explanation));
    }
}
