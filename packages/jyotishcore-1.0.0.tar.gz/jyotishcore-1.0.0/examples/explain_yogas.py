import jyotishcore
import json

def main():
    # Chart for a significant yoga combination
    # May 15, 1990 at 10:30 AM (UTC)
    chart = jyotishcore.Chart.compute(
        year=1990, month=5, day=15,
        hour=10, minute=30, second=0,
        latitude=28.6139, longitude=77.2090,
        altitude=0,
        ayanamsa="lahiri",
        house_system="equal"
    )

    print("--- Detected Astrological Yogas ---")
    graph = chart.explain()
    
    nodes = graph["nodes"]
    edges = graph["edges"]
    
    # Filter for Rule nodes (which represent Yogas)
    rules = [
        (node_id, node) for node_id, node in nodes.items()
        if node.get("type") == "Rule"
    ]
    
    if not rules:
        print("No specific yogas detected for this chart configuration.")
        return

    for node_id, rule in rules:
        print(f"\n[Yoga] {rule['name']}")
        print(f"Description: {rule['description']}")
        
        # Find classical citations for this rule
        citations = []
        for edge in edges:
            if edge["from"] == node_id and edge["relation"] == "Cites":
                target_node = nodes.get(edge["to"])
                if target_node:
                    citations.append(target_node)
        
        if citations:
            print("Citations:")
            for cite in citations:
                print(f"  - {cite['title']} ({cite['chapter']}, {cite['verse']})")
                print(f"    Snippet: \"{cite['snippet']}\"")

if __name__ == "__main__":
    main()
