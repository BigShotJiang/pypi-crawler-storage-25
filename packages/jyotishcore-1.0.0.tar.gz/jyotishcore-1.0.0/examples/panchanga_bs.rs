use chrono::NaiveDate;
use jyotishcore::calendars::bikram_sambat::BsDate;
use jyotishcore::*;

fn main() {
    println!("--- Bikram Sambat Conversion Test ---");

    // Test 1: Today (2024-05-15) -> BS
    // Note: BS 2081 Baisakh 1 = April 13/14, 2024
    let ad = NaiveDate::from_ymd_opt(2024, 4, 13).unwrap();
    if let Some(bs) = BsDate::from_gregorian(ad) {
        println!("AD {} -> BS {} {} {}", ad, bs.year, bs.month_name(), bs.day);
    }

    // Test 2: BS -> AD
    let bs = BsDate::new(2081, 1, 1);
    if let Some(ad_back) = bs.to_gregorian() {
        println!(
            "BS {} {} {} -> AD {}",
            bs.year,
            bs.month_name(),
            bs.day,
            ad_back
        );
    }

    println!("\n--- Panchanga for BS 2081-01-01 ---");
    let ephe = Ephemeris::new(AyanamsaMode::Lahiri, false);
    let geo = GeoPosition {
        latitude: 27.7172,
        longitude: 85.3240,
        altitude: 1400.0,
    };

    let nepali = locale::get_locale("ne_NP").unwrap();

    if let Some(ad_date) = bs.to_gregorian() {
        let dt = ad_date.and_hms_opt(6, 0, 0).unwrap().and_utc();
        let jd = ephe.julian_day(&dt);

        let tithi = calc::panchanga::tithi(jd, &ephe, &geo).unwrap();
        let nak = calc::panchanga::nakshatra(jd, &ephe, &geo).unwrap();

        println!("Date: {} (AD {})", bs.month_name(), ad_date);
        println!(
            "Tithi: {} / {} (ends at {})",
            tithi.name,
            nepali.tithi_names[(tithi.index - 1) as usize],
            tithi.end_time_utc
        );
        println!(
            "Nakshatra: {} / {} (pada {})",
            nak.name,
            nepali.nakshatra_names[(nak.index - 1) as usize],
            nak.pada
        );

        // Calculate full chart from BS date
        let chart = calc::chart::calculate_chart_bs(
            bs,
            chrono::NaiveTime::from_hms_opt(6, 0, 0).unwrap(),
            geo.clone(),
            AyanamsaMode::Lahiri,
            HouseSystem::Equal,
            false,
        )
        .unwrap();
        println!("Chart Ascendant: {:.2}°", chart.ascendant);
        println!("Sun Position: {:.2}°", chart.planets[0].longitude);
    }

    println!("\n--- Festivals for BS 2081 ---");
    let registry = calendars::festival::FestivalRegistry::new();
    let festivals = registry.calculate_for_year(&ephe, &geo, 2081);
    for fest in festivals {
        let local_name = nepali.festivals.get(&fest.name).unwrap_or(&fest.name);
        println!(
            "{} ({}) -> BS {}-{}-{}",
            fest.name, local_name, fest.date.year, fest.date.month, fest.date.day
        );
    }
}
