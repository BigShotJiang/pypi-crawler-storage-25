use chrono::{TimeZone, Utc};
use jyotishcore::*;

fn main() {
    let dt = Utc.with_ymd_and_hms(1990, 5, 15, 12, 0, 0).unwrap();
    let geo = GeoPosition {
        latitude: 27.7172,
        longitude: 85.3240,
        altitude: 1400.0,
    }; // Kathmandu

    println!("--- Calculating Chart with Dasha and Divisional Charts ---");
    let chart =
        calc::chart::calculate_chart(dt, geo, AyanamsaMode::Lahiri, HouseSystem::Equal, true)
            .unwrap();

    println!("Ascendant: {:.2}°", chart.ascendant);

    println!("\n--- Planet Positions in Divisional Charts ---");
    for planet_pos in &chart.planets {
        let d9 = planet_pos.divisional_signs.get(&9).unwrap();
        let d10 = planet_pos.divisional_signs.get(&10).unwrap();
        println!(
            "{:?}: Rashi={:?}, D-9={:?}, D-10={:?}",
            planet_pos.planet,
            planet_pos.sign.unwrap(),
            d9,
            d10
        );
    }

    println!("\n--- Vimshottari Mahadasha Timeline ---");
    let vimshottari = chart
        .dasha
        .get("vimshottari")
        .expect("vimshottari dasha should be present");
    for (i, maha) in vimshottari.iter().enumerate() {
        if i > 4 {
            break;
        } // Show first 5 for brevity
        println!(
            "Mahadasha of {:?}: {} to {}",
            maha.lord_name,
            maha.start.format("%Y-%m-%d"),
            maha.end.format("%Y-%m-%d")
        );
        // Show first 3 Antardashas
        for (j, ad) in maha.sub_periods.iter().enumerate() {
            if j > 1 {
                break;
            }
            println!(
                "  - AD {:?}: {} to {}",
                ad.lord_name,
                ad.start.format("%Y-%m-%d"),
                ad.end.format("%Y-%m-%d")
            );
            // Show first 2 Pratyantar Dashas
            for (k, pd) in ad.sub_periods.iter().enumerate() {
                if k > 1 {
                    break;
                }
                println!(
                    "    * PD {:?}: {} to {}",
                    pd.lord_name,
                    pd.start.format("%Y-%m-%d"),
                    pd.end.format("%Y-%m-%d")
                );
            }
        }
    }
}
