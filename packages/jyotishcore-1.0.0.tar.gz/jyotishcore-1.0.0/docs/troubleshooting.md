# Troubleshooting

## `ImportError: No module named 'jyotishcore'`

The Rust extension was not compiled. Solutions:

1. Try reinstalling with `--no-cache-dir`: `pip install --no-cache-dir jyotishcore`
1. Check Python version: `python --version` (3.9–3.12 required)
1. If on an unsupported platform, build from source (see README Option B)

## `ValueError: Swiss Ephemeris: NaN encountered`

The ephemeris data file is missing or corrupted. Run:

```bash
pip install --force-reinstall jyotishcore
```

## Build fails with `linker 'cc' not found`

Install C build tools:

- **Ubuntu/Debian**: `sudo apt install build-essential`
- **macOS**: `xcode-select --install`
- **Windows**: Install [Visual C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)
