# JyotishCore

**High-performance, research-backed Vedic Astrology Engine.**

JyotishCore is the #1 library for professional Vedic astrology calculations. Built with Rust for microsecond speed and Python for ease of use, it provides everything you need to build the next generation of astrology apps.

```python
import jyotishcore
# Compute a chart in 4 lines
chart = jyotishcore.Chart.compute(1990, 5, 15, 10, 30, 0, 28.6, 77.2)
print(f"Lagna: {chart.ascendant()}°")
```

## Choose your path

- **[For Developers](quickstart.md)** — Integrate the library into your Python or Rust project.
- **[For Astrologers](astrologers_guide.md)** — Understand the parameters and accuracy.
- **[For API Users](api/server.md)** — Use the high-performance REST API.
