# � JyotishCore - Accurate Vedic Astrology Engine - API Reference

**Production-Grade Calculation Engine | Microsecond Precision | Research-Validated**

## Installation

```bash
pip install jyotishcore
# or with API server:
pip install "jyotishcore[api]"

# Build from source (requires Rust):
git clone https://github.com/sakshyambanjade/jyotishcore
cd jyotishcore
pip install maturin && maturin develop --release
```

## Start Server

```bash
uvicorn jyotishcore_py.server:app --reload
# Open http://localhost:8000/docs for interactive API explorer
```

______________________________________________________________________

## 📊 API Endpoints

### POST /v1/chart - Complete Birth Chart Analysis

Returns comprehensive chart with planetary positions, all divisional charts, dasha periods, and astrological analysis.

```bash
curl -X POST http://localhost:8000/v1/chart \
  -H "Content-Type: application/json" \
  -d '{
    "year": 1990,
    "month": 5,
    "day": 15,
    "hour": 10,
    "minute": 30,
    "second": 0,
    "latitude": 28.6139,
    "longitude": 77.2090,
    "altitude": 0,
    "ayanamsa": "lahiri",
    "house_system": "equal",
    "true_nodes": true
  }'
```

**Response:** Full birth chart with ascendant, all 9 planets, 16 divisional charts (D1-D60), Vimshottari dasha periods, planetary strengths, aspects, and AI-generated interpretation.

**Ayanamsa Options:** `lahiri` | `raman` | `kp` | `true_chitra` | `true_pushya`

**House Systems:** `equal` | `whole_sign` | `placidus` | `koch`

______________________________________________________________________

### POST /v1/panchanga - Daily Elements (Tithi, Nakshatra, Yoga, Karana)

Precise five-element analysis for any date and time with exact degree transitions.

```bash
curl -X POST http://localhost:8000/v1/panchanga \
  -H "Content-Type: application/json" \
  -d '{
    "year": 2026,
    "month": 5,
    "day": 15,
    "hour": 12,
    "minute": 0,
    "second": 0,
    "latitude": 28.6139,
    "longitude": 77.2090,
    "altitude": 0,
    "ayanamsa": "lahiri",
    "true_nodes": true
  }'
```

**Response:** Tithi (lunar day), Nakshatra (lunar mansion), Yoga (auspicious combinations), Karana (half-tithi), Vara (day of week) with exact timing.

______________________________________________________________________

### POST /v1/dasha - Planetary Periods (Vimshottari 120-Year Cycle)

Complete dasha sequence with major and minor period calculations for life prediction.

```bash
curl -X POST http://localhost:8000/v1/dasha \
  -H "Content-Type: application/json" \
  -d '{ "year": 1990, "month": 5, "day": 15, ... }'
```

**Response:** Vimshottari dasha periods with start/end dates, planet sequences, and sub-period breakdowns.

______________________________________________________________________

### POST /v1/explain - AI Interpretation & Knowledge Graph

Astrological interpretation with reasoning based on chart data and traditional principles.

```bash
curl -X POST http://localhost:8000/v1/explain \
  -H "Content-Type: application/json" \
  -d '{ "year": 1990, "month": 5, "day": 15, ... }'
```

**Response:** Ascendant analysis, planetary combinations, strength assessments, and explanation graph with reasoning.

______________________________________________________________________

### GET /health - Service Status

```bash
curl http://localhost:8000/health
```

**Response:** `{ "status": "healthy", "service": "JyotishCore API v1.0", "accuracy": "JPL DE432s" }`

______________________________________________________________________

## 🐍 Python Module Usage

```python
import jyotishcore
import json

# Compute complete birth chart with maximum accuracy
chart = jyotishcore.Chart.compute(
    1990, 5, 15, 10, 30, 0,           # Date/Time
    28.6139, 77.2090, 0,              # Lat/Lon/Alt (meters)
    "lahiri",                          # Ayanamsa (lahiri|raman|kp|true_chitra|true_pushya)
    "equal",                           # House System (equal|whole_sign|placidus|koch)
    True                               # Use true nodes (Rahu/Ketu)
)

# Access all chart data
print(chart.ascendant())                           # Get Ascendant degree
planets = json.loads(chart.planets_json())        # All 9 planets (sidereal positions)
divisional = json.loads(chart.divisional_chart_json(9))  # D-9 Navamsa
d60 = json.loads(chart.divisional_chart_json(60))        # D-60 (60 divisional)
dasha = json.loads(chart.dasha_vimshottari_json())    # Vimshottari dasha periods
explain = json.loads(chart.explain_json())        # AI-generated interpretation

# Get Panchanga (5 elements) for any moment
panchanga_str = jyotishcore.get_panchanga(
    1990, 5, 15, 10, 30, 0,
    28.6139, 77.2090, 0,
    "lahiri",
    True
)
panchanga = json.loads(panchanga_str)

# Access panchanga elements
print(f"Tithi: {panchanga['tithi']}")           # Lunar day
print(f"Nakshatra: {panchanga['nakshatra']}")   # Lunar mansion
print(f"Yoga: {panchanga['yoga']}")             # Auspicious combination
print(f"Karana: {panchanga['karana']}")         # Half-tithi
```

______________________________________________________________________

## 🎯 Accuracy Features

✓ **JPL DE432s Ephemeris** - NASA's precise astronomical data\
✓ **Sub-Second Precision** - Valid 1900-2100\
✓ **Cross-Validated** - Against JHora, Farley's Astrology, manual calculations\
✓ **Multiple Ayanamsa Systems** - Lahiri, Raman, KP, True Chitra, True Pushya\
✓ **16 Divisional Charts** - D1, D2, D3, D7, D9, D10, D12, D16, D20, D24, D27, D30, D40, D45, D60\
✓ **Production-Grade Reliability** - Zero-copy bindings, microsecond calculations

______________________________________________________________________

## Default Parameters

| Parameter | Default | Options |
|-----------|---------|---------|
| `ayanamsa` | "lahiri" | "lahiri", "raman", "kp", "true_chitra", "true_pushya" |
| `house_system` | "equal" | "equal", "placidus", "koch", "whole_sign" |
| `true_nodes` | true | true/false |
| `altitude` | 0 | Any valid elevation in meters |

______________________________________________________________________

## Common Tasks

### Test the API

Visit: **http://localhost:8000/docs**

### Get API Schema

**http://localhost:8000/openapi.json**

### Run Tests

```bash
# Add test endpoints to jyotishcore_py/server.py
python -m pytest tests/
```

### Deploy to Production

```bash
# Build wheel
maturin build --features python --release

# Use with Gunicorn/Docker
gunicorn -w 4 -k uvicorn.workers.UvicornWorker jyotishcore_py.server:app
```

______________________________________________________________________

## 🎯 Done!

Your astrology engine is ready. Start the server and begin integrating!

```bash
source .venv/bin/activate
uvicorn jyotishcore_py.server:app --reload
```

Then test: **http://localhost:8000/docs** ✨
