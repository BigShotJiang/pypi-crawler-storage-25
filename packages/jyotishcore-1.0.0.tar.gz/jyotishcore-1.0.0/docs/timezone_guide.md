# Timezone Guide

JyotishCore's core calculation functions (`Chart.compute` and `get_panchanga`) expect birth time in **UTC**. Passing local time without conversion is the most common cause of incorrect ascendants and planetary positions.

## Common Timezone Offsets

| Region | City | Standard Offset | DST Offset |
|--------|------|-----------------|------------|
| India | New Delhi | UTC+5:30 | N/A |
| Nepal | Kathmandu | UTC+5:45 | N/A |
| Sri Lanka | Colombo | UTC+5:30 | N/A |
| USA (Eastern) | New York | UTC-5:00 | UTC-4:00 |
| UK | London | UTC+0:00 | UTC+1:00 |
| Japan | Tokyo | UTC+9:00 | N/A |

## Example: Converting to UTC

If someone was born at **12:00 PM** on **May 15, 2024** in **Kathmandu, Nepal**:

1. **Local Time**: 2024-05-15 12:00:00
2. **Kathmandu Offset**: UTC+5:45 (5.75 hours)
3. **UTC Calculation**: 12:00 - 5:45 = **06:15 AM**
4. **API Input**: `hour=6, minute=15, second=0`

## Using the Helper

To avoid manual math, use the `compute_chart_local` helper:

```python
from jyotishcore import compute_chart_local

# Nepal (UTC+5:45 = 5.75)
chart = compute_chart_local(
    year=2024, month=5, day=15,
    hour=12, minute=0, second=0,
    latitude=27.7172, longitude=85.3240,
    timezone_offset_hours=5.75
)

# India (UTC+5:30 = 5.5)
chart = compute_chart_local(
    year=1990, month=5, day=15,
    hour=10, minute=30, second=0,
    latitude=28.6139, longitude=77.2090,
    timezone_offset_hours=5.5
)
```
