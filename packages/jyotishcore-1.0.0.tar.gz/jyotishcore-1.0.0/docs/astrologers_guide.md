# Getting Started for Astrologers

JyotishCore is designed to be as accurate as the software professional Vedic astrologers use daily. This guide explains how to use the library if you are familiar with Jyotish but new to programming.

## 1. What Each Parameter Means

- **Year/Month/Day**: The birth date.
- **Hour/Minute/Second**: The birth time. **IMPORTANT**: This must be in **UTC**. If you have a birth time in local time (e.g., IST for India or NPT for Nepal), you must convert it to UTC first.
- **Latitude/Longitude**: The geographical coordinates of the birth place. You can find these by searching for the city on Google Maps.
- **Altitude**: The height above sea level. This is important for high-accuracy calculations as it affects the horizon (ascendant).

## 2. Choosing an Ayanamsa

The Ayanamsa is the longitudinal difference between the tropical and sidereal zodiacs.

- **Lahiri (`lahiri`)**: The most common ayanamsa used in India (Chitra Paksha). Default for most Vedic astrology.
- **Raman (`raman`)**: Used by followers of B.V. Raman.
- **KP (`kp`)**: Krishnamurti Paddhati ayanamsa.
- **True Chitra (`true_chitra`)**: A precise astronomical variant of Lahiri.

**Recommendation**: If you are unsure, use `lahiri`.

## 3. Choosing a House System

- **Whole Sign (`whole_sign`)**: Each sign is treated as one house. This is the oldest system in Jyotish.
- **Equal House (`equal`)**: Houses are 30 degrees each, starting from the exact degree of the ascendant. Common in South Indian traditions.
- **Placidus / Koch**: Western house systems. Rarely used in traditional Vedic astrology.

## 4. Verifying Results Against JHora

If you want to verify JyotishCore's accuracy:

1. Open Jagannatha Hora (JHora).
1. Set the Ayanamsa to "Chitra Paksha (Lahiri)".
1. Compute a chart and compare the Ascendant and planetary degrees. They should match within seconds of an arc.

## 5. Glossary for Developers

If you are working with a developer, here are the terms they might use:

- **Lagna**: The Ascendant (1st House).
- **Panchanga**: The five elements of the day (Tithi, Nakshatra, Yoga, Karana, Vara).
- **Vimshottari Dasha**: The most widely used system of planetary periods.
- **Varga**: A divisional chart (like Navamsa D9).

## Example: Computing Diwali 2026 Panchanga

```python
import jyotishcore

# Diwali 2026 is on Nov 8, 2026.
# Let's get the panchanga for New Delhi at sunrise.
panchanga = jyotishcore.get_panchanga(
    year=2026, month=11, day=8,
    hour=1, minute=10, second=0, # Approx sunrise in UTC
    latitude=28.6139, longitude=77.2090
)

print(f"Tithi on Diwali: {panchanga.tithi.name}")
print(f"Nakshatra: {panchanga.nakshatra.name}")
```
