# Chart API

The `Chart` class is the main entry point for birth chart calculations.

## Methods

### `compute(...)`

Static method to calculate a new chart.

### `ascendant()`

Returns the ascendant longitude in degrees.

### `planets()`

Returns a dictionary of planet positions.

### `dasha()`

Returns the dasha periods.

### `explain()`

Returns the knowledge graph for the chart.
