# Feature Matrix

Date: 2026-05-16

| Area | Status | Notes |
| --- | --- | --- |
| Planetary sidereal longitude | Stable candidate | Randomized checks matched `pyswisseph` for tested bodies/settings. |
| Ayanamsa selection | Stable candidate | Lahiri, Raman, KP, True Chitra, and True Pushya are exposed. |
| Local timezone conversion | Stable candidate | Uses IANA timezone names; randomized civil-time checks passed. |
| Python chart API | Beta, usable | `Chart.from_local`, `Chart.compute`, metadata, planets, ascendant, and vargas are usable. |
| Ascendant and houses | Beta | Needs a broader external corpus across house systems and latitudes. |
| Panchanga names | Beta | Tithi, nakshatra, yoga, karana, and vara are exposed. |
| Panchanga boundaries | Beta after fix | Intervals are now tested to contain query time; still needs trusted golden boundary cases. |
| Vimshottari dasha | Beta | Needs source/version-backed fixture expansion. |
| REST API | Experimental | Endpoint smoke tests now pass, but API schema stability is not guaranteed. |
| Chara Dasha | Experimental/hidden | Not part of the default stable API. |
| Yogini Dasha | Experimental/hidden | Not part of the default stable API. |
| Shadbala | Experimental/hidden | Needs independent validation. |
| Ashtakavarga | Experimental/hidden | Needs independent validation. |
| Interpretive/knowledge output | Experimental/hidden | Symbolic only; not suitable for sensitive decisions. |

## Promotion Criteria

A feature can move toward stable only after it has:

- documented reference source/version
- enough golden fixtures to cover normal and edge cases
- explicit tolerances
- automated regression tests
- clear API shape and examples
- safety wording when outputs may be misinterpreted

## Current Public Wording

Use conservative wording:

- Planetary positions: stable candidate
- Timezone conversion: stable candidate
- Chart Python API: beta but usable
- Panchanga: beta
- REST API: experimental
- Interpretive modules: experimental or hidden
