# Repository Audit

Date: 2026-05-16

This repository is a Rust-first Jyotish calculation engine with Python bindings. The strongest validated surface is astronomical calculation through Swiss Ephemeris; higher-level Jyotish features need explicit reference data before they should be described as stable.

## Current Strengths

- Planetary longitude calculation is backed by Swiss Ephemeris and has passed randomized comparison against `pyswisseph` for Lahiri sidereal longitude and true nodes.
- Local civil time entry uses IANA timezones through `Chart.from_local`, `Panchanga.from_local`, and `local_to_utc`.
- Python chart APIs expose calculation metadata, resolved UTC time, and warnings.
- Default outputs are calculation data rather than deterministic life advice.

## Recent Release Blockers Addressed

- Panchanga boundary intervals now use corrected Julian Day reverse conversion and are tested to contain the query instant.
- REST API chart serialization now handles `VargaPosition` separately from `PlanetPosition`.
- REST API panchanga serialization now reads typed `Panchanga` models without dict-only `.get(...)` calls.

## Remaining Risks

- Golden fixtures are still too small for broad public reliability claims.
- Some verified fixture files use a structured schema that is not yet exercised by the legacy baseline test.
- Packaging needs complete wheel coverage plus source distribution checks before main PyPI release.
- Experimental modules such as Chara, Yogini, Shadbala, Ashtakavarga, and interpretation need their own validation standards before promotion.

## Recommended Validation Standard

Every golden case should include:

- input local time and resolved UTC time
- IANA timezone
- ayanamsa
- house system
- true or mean node setting
- reference source and version
- expected values
- tolerance
- validation status
- reviewer/date

## Recommended Local Checks

```bash
maturin develop --features python
cargo test --lib --features python
pytest -q
```

On macOS, full `cargo test --features python` may fail when non-library targets link against PyO3 extension-module symbols. Treat `cargo test --lib --features python` as the supported Rust check unless CI is configured for Python embedding.
