# PyPI Readiness

Date: 2026-05-16

JyotishCore should not be promoted to a serious public beta on main PyPI until install artifacts, validation evidence, and API smoke tests are repeatable in clean environments.

## Required Artifacts

- source distribution (`sdist`)
- Linux x86_64 wheel
- Linux aarch64 wheel, if supported
- macOS x86_64 wheel
- macOS arm64 wheel
- Windows AMD64 wheel, if supported

The TestPyPI `0.2.0b0` audit found only a macOS arm64 ABI3 wheel. That is not enough for a public beta that advertises broad Python support.

## Pre-Publish Checklist

```bash
rm -rf dist
python -m pip install -U build maturin twine
maturin sdist
maturin build --release --features python
twine check dist/*
```

Then install the generated artifacts in fresh virtual environments:

```bash
python -m venv /tmp/jyotishcore-check
source /tmp/jyotishcore-check/bin/activate
python -m pip install dist/*.whl
python - <<'PY'
from jyotishcore import Chart, Panchanga

chart = Chart.from_local(
    date="2024-05-15",
    time="12:00:00",
    timezone="Asia/Kathmandu",
    latitude=27.7172,
    longitude=85.3240,
)
print(chart.planets()["moon"].longitude)

panchanga = Panchanga.from_local(
    date="2026-05-16",
    time="12:00:00",
    timezone="Asia/Kathmandu",
    latitude=27.7172,
    longitude=85.3240,
)
print(panchanga.tithi.name, panchanga.tithi.start_time_utc, panchanga.tithi.end_time_utc)
PY
```

## API Extra Check

```bash
python -m pip install "jyotishcore[api]"
python -m pytest tests/test_server.py -q
```

The optional REST API should be described as experimental until endpoint tests pass for every published artifact.

## Release Gate

Before main PyPI:

- all required artifacts are present
- `twine check` passes
- wheel install smoke tests pass
- `cargo test --lib --features python` passes
- `pytest -q` passes after `maturin develop --features python`
- audit docs and feature status match the actual release behavior
- Swiss Ephemeris license obligations are reviewed for the distribution mode
