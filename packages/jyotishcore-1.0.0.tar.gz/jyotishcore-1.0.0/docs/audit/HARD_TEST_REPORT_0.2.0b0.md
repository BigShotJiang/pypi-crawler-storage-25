# JyotishCore 0.2.0b0 Hard Test Report

Date: 2026-05-16  
Package tested: `jyotishcore==0.2.0b0` from TestPyPI  
Install command:

```bash
pip install -i https://test.pypi.org/simple/ jyotishcore==0.2.0b0
```

## Executive Opinion

JyotishCore has a strong astronomical core, but it is not yet a fully reliable Jyotish engine.

The strongest part is planetary longitude calculation. In a hard randomized test of 1000 UTC charts across 1900-2050, JyotishCore matched `pyswisseph` exactly for Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu, and Ketu using Lahiri sidereal longitude and true node.

The weakest parts are panchanga timing, the optional REST API, validation evidence, and release packaging. These should be fixed before calling panchanga/API stable or before publishing as a serious public beta on main PyPI.

## Hard Test Results

### 1. Planetary Longitudes vs Swiss Ephemeris

Result: PASS

Test:

- 1000 random UTC datetimes from 1900-01-01 through 2050-12-31.
- Random latitude/longitude values.
- Compared JyotishCore planet longitudes against `pyswisseph`.
- Settings: Lahiri ayanamsa, sidereal longitude, true node.
- Bodies checked: Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu, Ketu.

Observed result:

```text
PASS maxdiff_deg=0.0
```

Opinion:

This is the best sign in the whole audit. The core Swiss Ephemeris binding and sidereal planetary longitude pipeline appear solid for modern and historical chart calculations.

### 2. Local Timezone Conversion

Result: PASS

Test:

- 240 random local civil times.
- Timezones tested: `Asia/Kathmandu`, `Asia/Kolkata`, `America/New_York`, `Europe/London`, `Australia/Sydney`, `Pacific/Auckland`, `America/Los_Angeles`.
- Compared `jyotishcore.local_to_utc(...)` with Python `zoneinfo`.
- DST-unstable local times were excluded from the comparison.

Observed result:

```text
PASS checked=240 skipped=0 failures=[]
```

Opinion:

The local civil time API is one of the project’s good design decisions. Requiring IANA timezones is correct, and the conversion behaved well in this test.

### 3. Panchanga Temporal Sanity

Result: FAIL

Test:

- 120 random local panchanga calculations.
- Checked each returned tithi, nakshatra, yoga, and karana interval.
- Expected invariant: `start_time_utc <= query_time_utc <= end_time_utc`.
- Expected duration: positive and plausibly below 80 hours.

Observed result:

```text
FAIL bad_count=120
```

Example bad output:

```text
Input: 2025-06-15T09:03:00 Asia/Kathmandu
Query UTC: 2025-06-15T03:18:00+00:00
Tithi: Chaturthi
Returned start: 2025-06-24T06:54:00+00:00
Returned end:   2025-06-25T08:42:30+00:00
```

Another example:

```text
Input: 2025-09-08T01:57:00 Asia/Kathmandu
Query UTC: 2025-09-07T20:12:00+00:00
Tithi: Pratipada
Returned start: 2025-09-25T03:32:57+00:00
Returned end:   2025-09-23T16:56:07+00:00
Duration: -34.61 hours
```

Manual smoke example:

```text
Input: 2026-05-16 12:00:00 Asia/Kathmandu
Tithi: Purnima
Returned start: 2026-06-07T16:39:06+00:00
Returned end:   2026-06-05T00:25:33+00:00
```

Opinion:

The panchanga element names may often be plausible, but the start/end time computation is currently not trustworthy. This is a blocker for calling panchanga stable. Users of panchanga care deeply about boundaries; wrong boundaries are worse than missing boundaries.

Likely area to inspect:

- `src/calc/panchanga.rs`
- `find_next_moment_result(...)`
- `find_start_moment(...)`
- Any logic that searches for boundary moments by comparing element index.

The algorithm should bracket the current element around the query time, then refine boundaries locally. It currently appears to jump to unrelated future transitions and can return `start > end`.

### 4. REST API Smoke Test

Result: FAIL

Test:

- Installed package from TestPyPI.
- Created `fastapi.testclient.TestClient`.
- Posted a valid payload to `/v1/chart`.
- Posted a valid payload to `/v1/panchanga`.

Observed result:

```text
chart_status=500
panchanga_status=500
```

Chart endpoint error:

```text
AttributeError: 'builtins.VargaPosition' object has no attribute 'longitude'
```

Panchanga endpoint error:

```text
AttributeError: 'Tithi' object has no attribute 'get'
```

Opinion:

The REST API is not compatible with the current Python object model. It should either be fixed immediately or removed from the advertised stable surface. The core Python API works; the API extra does not.

Likely area to inspect:

- `jyotishcore_py/jyotishcore/server.py`
- `planet_to_dict(...)`
- `/v1/chart` handling of `chart.vargas(9)`
- `/v1/panchanga` handling of typed `Panchanga` models

## What Is Working

### Planetary positions

The core planetary longitude engine is working very well. The randomized Swiss Ephemeris cross-check found zero difference for the tested bodies/settings.

### Python chart API

This works:

```python
from jyotishcore import Chart

chart = Chart.from_local(
    date="2024-05-15",
    time="12:00:00",
    timezone="Asia/Kathmandu",
    latitude=27.7172,
    longitude=85.3240,
    altitude=1350,
    ayanamsa="lahiri",
    house_system="equal",
    true_nodes=True,
)

print(chart.ascendant())
print(chart.planets()["moon"].longitude)
print(chart.metadata()["utc_datetime"])
```

Observed:

```text
Ascendant: 122.827457
Moon: 118.157557 Cancer Ashlesha
UTC: 2024-05-15T06:15:00+00:00
```

### Timezone handling

The public `from_local(...)` API and `local_to_utc(...)` behavior are conceptually right and performed well in randomized checks.

### Safety posture

The README’s framing is good: calculation data, not life decisions. The default chart warnings are also a good choice.

## What Is Not Working

### Panchanga boundary times

This is the biggest correctness bug found. Returned start/end times are not anchored around the query time and can be in the wrong order.

### REST API

The advertised optional API extra is broken in the installed wheel. Valid endpoint calls return HTTP 500.

### Validation docs are missing

The README links to:

- `docs/audit/REPOSITORY_AUDIT.md`
- `docs/audit/FEATURE_MATRIX.md`
- `docs/audit/PYPI_READINESS.md`

Those files were not present before this audit folder was created. This weakens release credibility.

### Golden fixtures are not enough yet

Current fixture status:

```text
kathmandu_modern_001.json: verified
delhi_modern_002.json: verified
newyork_dst_003.json: pending
london_dst_004.json: pending
historical_005.json: pending
```

Several fixture files do not include an explicit external reference source/version. These are useful regression fixtures, but not enough to prove correctness.

### Packaging is too narrow

TestPyPI currently has only one wheel:

```text
jyotishcore-0.2.0b0-cp38-abi3-macosx_11_0_arm64.whl
```

There is no source distribution uploaded. The package metadata advertises Python 3.8-3.12, but the release artifact only serves macOS ARM64 users unless they build locally from the repo.

### Local developer workflow is incomplete

Running `pytest -q` directly in the repo failed before building/installing the extension:

```text
ModuleNotFoundError: No module named 'jyotishcore'
```

The docs should tell contributors to run `maturin develop --features python` before `pytest`, or the project should provide a single reliable local command.

### Full `cargo test --features python` failed

Observed:

```text
error: linking with `cc` failed
Undefined symbols for architecture arm64: _PyBaseObject_Type, _PyBool_Type, ...
```

But this passed:

```bash
cargo test --lib --features python
```

Opinion:

This should be clarified/fixed in CI. If the correct Rust check is `cargo test --lib --features python`, document that. If full `cargo test` is expected to pass, fix PyO3 linking/test configuration.

## Priority Fix List

### P0: Fix panchanga boundary search

Required invariants:

- `start_time_utc <= query_utc <= end_time_utc`
- `end_time_utc > start_time_utc`
- tithi duration should usually be around 19-26 hours
- nakshatra duration should usually be around 20-28 hours
- yoga/karana durations should be plausible
- start/end local times must correspond exactly to start/end UTC in the provided timezone

Recommended tests:

- Add randomized property tests for 1000 panchanga inputs.
- Add fixed golden panchanga boundary cases from a trusted source.
- Test boundary moments just before, at, and just after transition.

### P0: Fix REST API object serialization

For chart API:

- Do not pass `VargaPosition` into a serializer that expects `PlanetPosition.longitude`.
- Serialize varga fields as `source_longitude`, `varga`, `varga_sign`, `varga_index`, and `display_longitude`.

For panchanga API:

- Decide whether endpoint internals use typed `Panchanga` objects or dicts.
- Do not call `.get(...)` on typed objects like `Tithi`.

### P1: Build real validation corpus

For each golden case, store:

- input local time
- resolved UTC time
- timezone database version if possible
- ayanamsa
- house system
- true/mean node
- reference software/source
- reference software version
- exact values
- tolerance
- verification status
- reviewer/date

Target corpus:

- 100+ planetary longitude cases
- 50+ ascendant/house cases
- 100+ panchanga boundary cases
- DST edge cases
- polar/high latitude cases
- historical cases before 1950
- future cases after 2050 if supported

### P1: Publish complete wheels and sdist

Before main PyPI:

- Upload sdist.
- Build wheels for Linux x86_64/aarch64.
- Build wheels for macOS x86_64/arm64.
- Build wheels for Windows AMD64 if supported.
- Test install in fresh environments.

### P1: Align docs with actual stability

Recommended wording:

- Planetary positions: stable candidate.
- Timezone conversion: stable candidate.
- Chart Python API: beta but usable.
- Panchanga names: beta.
- Panchanga boundary times: unstable until fixed.
- REST API: experimental until endpoint tests pass.
- Chara/Yogini/Shadbala/Ashtakavarga/interpretation: experimental/hidden.

### P2: Fix missing audit docs

Either create these files or remove the links:

- `docs/audit/REPOSITORY_AUDIT.md`
- `docs/audit/FEATURE_MATRIX.md`
- `docs/audit/PYPI_READINESS.md`

This report can be used as a starting point.

### P2: Improve developer commands

Recommended:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip maturin pytest
maturin develop --features python
pytest -q
cargo test --lib --features python
```

Add a `Makefile`, `justfile`, `tox.ini`, or `noxfile.py` so contributors run one command instead of guessing.

## Bottom Line

If JyotishCore were only a sidereal planetary position library, I would be optimistic. The Rust/Swiss Ephemeris core looks genuinely strong.

If JyotishCore is meant to be the world’s most reliable Jyotish calculation engine, the next milestone must be boring, strict validation:

1. Fix panchanga boundary times.
2. Fix the REST API.
3. Build a serious golden corpus with source/version/tolerance.
4. Publish complete wheels plus sdist.
5. Keep interpretive modules out of the default stable API until they have their own validation standard.

The project has a real foundation. It is not fake. But the reliability claim should currently be limited to the planetary longitude core, not the entire engine.
