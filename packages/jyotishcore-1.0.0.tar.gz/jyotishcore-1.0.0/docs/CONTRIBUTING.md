# Contributing to JyotishCore

Thank you for your interest in contributing to JyotishCore! We welcome contributions from astrologers, astronomers, and software engineers.

## Development Setup

### Prerequisites

- **Rust Toolchain**: [Install Rust](https://rustup.rs/) (1.70+)
- **Python**: 3.8+
- **Maturin**: `pip install maturin`

### Local Setup

1. Fork and clone the repository.
1. Create a virtual environment:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```
1. Install development dependencies:
   ```bash
   pip install -r requirements.txt
   pip install pytest black ruff mypy
   ```
1. Build the project in editable mode:
   ```bash
   maturin develop --release
   ```

## Coding Standards

### Rust

- Use `cargo fmt` to format your code.
- Run `cargo clippy` to check for common issues.
- Ensure all new public functions in `src/python.rs` use `PyResult` for error handling.

### Python

- We use `black` for formatting and `ruff` for linting.
- Use type hints for all public API methods.
- Ensure all FastAPI models are defined in `server.py` using Pydantic V2.

## Testing

### Rust Tests

Run Rust unit and integration tests:

```bash
cargo test -- --test-threads=1
```

*Note: We use `--test-threads=1` because the underlying Swiss Ephemeris C library uses global state and is not thread-safe.*

### Python Tests

Run server and API tests:

```bash
pytest tests/
```

## Accuracy Validation

When modifying calculation logic, you MUST verify the results against an authoritative source (e.g., JHora, Swiss Ephemeris CLI, or NASA JPL Horizons). Add a "Golden Master" test case in `tests/` if you add a new calculation element.

## Pull Request Process

1. Create a feature branch.
1. Ensure all tests pass.
1. Update the `README.md` and `CHANGELOG.md` if applicable.
1. Open a PR with a clear description of the changes and the validation steps taken.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
