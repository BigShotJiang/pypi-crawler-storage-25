# The Explain API — Knowledge Graph Reference

`chart.explain()` returns a Python dictionary representing a **causal knowledge graph** of astrological rules that apply to this chart.

## Schema

```python
{
  "nodes": {
    "<node_id>": {
      "type": "Planet" | "House" | "Rule" | "Condition" | "TextSource",
      # type-specific fields below
    }
  },
  "edges": [
    { "from": "<node_id>", "to": "<node_id>", "relation": "LocatedIn" | "DependsOn" | "Cites" }
  ]
}
```

## Node Types

### Planet node

```python
{ "type": "Planet", "name": "Jupiter", "id": "planet_jupiter" }
```

### House node

```python
{ "type": "House", "number": 10 }
```

### Rule node (a Yoga or Astrological Combination)

```python
{
  "type": "Rule",
  "name": "Gaja Kesari Yoga",
  "description": "Jupiter in a kendra from the Moon gives wisdom and prosperity."
}
```

### Condition node (the specific arrangement that triggered the rule)

```python
{
  "type": "Condition",
  "expression": "House of Jupiter (10) is in kendra from House of Moon (7)"
}
```

### TextSource node (classical reference)

```python
{
  "type": "TextSource",
  "title": "Brihat Parashara Hora Shastra",
  "chapter": "Ch. 36",
  "verse": "36.3-4",
  "snippet": "If Jupiter is in a kendra from the Moon..."
}
```

## Edge Types

| Relation | Meaning |
|----------|---------|
| `LocatedIn` | A planet occupies a house |
| `DependsOn` | A rule or condition depends on another node |
| `Cites` | A rule cites a classical text source |

## Complete worked example

```python
import jyotishcore, json

chart = jyotishcore.Chart.compute(1990, 5, 15, 10, 30, 0, 28.6139, 77.2090, 0)
graph = chart.explain()

# List all active Yogas (rules)
rules = [
    n for n in graph["nodes"].values()
    if n["type"] == "Rule"
]
for rule in rules:
    print(f"✓ {rule['name']}: {rule['description']}")

# Find the classical source for a rule
rule_id = "rule_gaja_kesari"
if rule_id in graph["nodes"]:
    cites_edges = [e for e in graph["edges"]
                   if e["from"] == rule_id and e["relation"] == "Cites"]
    for edge in cites_edges:
        src = graph["nodes"][edge["to"]]
        print(f"  Source: {src['title']} {src['verse']}")
```

## Currently implemented rules

- **Gaja Kesari Yoga** — Jupiter in kendra from Moon (wisdom, prosperity)
- **Vargottama** — Planet in same sign in D1 and D9
- **Neecha Bhanga** — Cancellation of debilitation
