# Divisional Charts (Vargas)

JyotishCore computes 15 divisional charts: D1 (Rasi), D2 (Hora), D3 (Drekkana),
D7, D9 (Navamsa), D10 (Dasamsa), D12, D16, D20, D24, D27, D30, D40, D45, D60.

## Usage

```python
import jyotishcore

chart = jyotishcore.Chart.compute(1990, 5, 15, 10, 30, 0, 28.6139, 77.2090, 0)

# Get all planets in the D9 (Navamsa) chart
navamsa = chart.divisional_chart(9)

if navamsa:
    for planet in navamsa:
        print(f"{planet.planet}: {planet.sign}")  # Use .sign, not .longitude

# Important: planet.longitude in divisional charts is a placeholder.
# Only planet.sign and planet.planet are meaningful.
```

## Supported divisional numbers

2, 3, 4, 7, 9, 10, 12, 16, 20, 24, 27, 30, 40, 45, 60

Passing any other number returns `None`.
