# Quick Start

Get up and running with JyotishCore in under 2 minutes.

## 1. Compute a Birth Chart

```python
from jyotishcore import Chart

# Example: Birth in New Delhi
chart = Chart.compute(
    year=1990, month=5, day=15,
    hour=10, minute=30, second=0,  # UTC
    latitude=28.6139, longitude=77.2090
)

print(f"Ascendant: {chart.ascendant()}°")
```

## 2. Get Today's Panchanga

```python
import jyotishcore
from datetime import datetime

now = datetime.utcnow()
panchanga = jyotishcore.get_panchanga(
    now.year, now.month, now.day,
    now.hour, now.minute, now.second,
    27.7172, 85.3240  # Kathmandu
)

print(f"Tithi: {panchanga.tithi.name}")
```

## 3. List Vimshottari Dasha Periods

```python
chart = Chart.compute(1990, 5, 15, 10, 30, 0, 28.6, 77.2)
dashas = chart.dasha()
for period in dashas["vimshottari"][:5]:
    print(f"{period.lord}: {period.start} to {period.end}")
```

## 4. Detect Yogas with `explain()`

```python
graph = chart.explain()
for node in graph["nodes"].values():
    if node["type"] == "Rule":
        print(f"Yoga Found: {node['name']}")
```
