# Validation & Accuracy Guide

## Overview

This document explains how JyotishCore calculations compare to reference implementations and how to validate outputs.

## Calculation Correctness Principles

Every calculation in JyotishCore must answer:

1. **What is the input?** - Date, time, location, ayanamsa, house system
1. **Is input local time or UTC?** - Clearly indicated
1. **What timezone was used?** - IANA timezone string
1. **What ephemeris was used?** - Swiss Ephemeris version
1. **What ayanamsa was used?** - Lahiri, Raman, KP, True Chitra, True Pushya
1. **Is longitude tropical or sidereal?** - Always sidereal in outputs
1. **Is house system explicit?** - Equal, Placidus, Koch, Whole Sign
1. **Is result normalized 0 \<= x < 360?** - Yes
1. **What happens at exact boundaries?** - Documented in each module
1. **What is the source for this formula?** - Classical references cited
1. **Is there a golden test?** - Yes, or marked as experimental
1. **Is there a warning if birth-time sensitive?** - Yes (D60, etc.)
1. **Is this stable, beta, or experimental?** - Clearly marked

## Reference Software Comparison

### Established Tools

- **Swiss Ephemeris CLI** - Authoritative for planetary positions
- **PySwisseph** - Python wrapper for Swiss Ephemeris
- **JHora** - Jyotish software by Jagannatha Rao
- **Parashara Light** - Comprehensive Jyotish engine
- **VedicTime** - Modern astrology software
- **Kundli** - Traditional Indian software

### Validation Workflow

```
1. Run chart in JyotishCore
2. Run same chart in reference tool
3. Compare outputs
4. Document tolerance / differences
5. Investigate if > tolerance
6. Add to golden test suite if validated
```

## Required Metadata on All Calculations

Every chart must include:

- input mode: local civil time, UTC, or Julian Day UT
- IANA timezone for local civil input
- UTC datetime used internally
- latitude, longitude, altitude
- ayanamsa name and value
- house system
- true or mean node mode
- tropical or sidereal longitude
- ephemeris source/version/path
- reference tool/version
- tolerance

## Module-Specific Validation

### Planetary Positions

**Reference**: Swiss Ephemeris exact_values

**Test cases**:

- Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn
- Rahu, Ketu (nodes)
- Retrograde status
- Birth time sensitivity

**Tolerance**: ±0.1° (standard deviation across date ranges)

### Rāśi / Sign

**Formula**: longitude / 30

**Test cases**:

- Boundary at 0.0°, 30.0°, 60.0°, etc.
- All 12 signs covered
- Wrap-around at 360°

### Nakshatra & Pada

**Formula**: 27 nakshatras × 13°20' each, 4 padas per nakshatra

**Test cases**:

```
Ashwini: 0°0' - 13°20'
  Pada 1: 0°0' - 3°20' (Aries)
  Pada 2: 3°20' - 6°40' (Taurus)
  Pada 3: 6°40' - 10°0' (Gemini)
  Pada 4: 10°0' - 13°20' (Cancer)
```

### Divisional Charts (Vargas)

Required golden-test areas:

- D1 (Rashi): planetary rāśi
- D2 (Hora): 15° Sun/Moon lords
- D3 (Drekkana): 10° segments
- D4 (Chaturthamsa): 7°30' segments
- D7 (Saptamsa): 4°17'8" segments
- D9 (Navamsa): 3°20' segments - **critical for predictions**
- D10 (Dasamsa): 3° segments - career
- D12 (Dvadasamsa): 2°30' segments
- D16+ (higher): ±1 sign tolerance
- D60 (Shashtiamsa): ⚠️ **EXTREMELY BIRTH-TIME SENSITIVE** - warning required

### Panchanga

**Components**:

1. Tithi - lunar day (1-30)
1. Nakshatra - Moon's nakshatra (1-27)
1. Yoga - combined Sun-Moon (1-27)
1. Karana - half-tithi (1-60, repeating)
1. Vara - day of week (1-7)

**Validation**:

- tithi/yoga/karana transitions: start_time and end_time must bracket event
- No gaps or overlaps within lunar month
- Vara matches calendar day-of-week
- tithi transitions tested at 12+ points throughout lunar month

### Vimshottari Dasha

**Period years**: Ketu(7), Venus(20), Sun(6), Moon(10), Mars(7), Rahu(18), Jupiter(16), Saturn(19), Mercury(17) = 120 years total

**Balance calculation**:

```
Moon nakshatra lord determines starting lord
Balance = Years × (1 - Moon_degree_in_nakshatra / 13.33)
```

**Golden tests**: 3+ known charts with verified:

- First dasha start date
- First dasha balance
- Antardasha sequence
- Full 120-year cycle

**Tolerance**: ±1 day for dasha start/end, ±1 hour for antardasha

### Chara & Yogini Dasha

**Status**: 🔴 EXPERIMENTAL - Do not use for production decisions

**Action**: Require explicit opt-in, mark experimental

## Comparison Process

### Create Test Case

File: `tests/data/jhora_baseline/test_name.json`

```json
{
  "input": {
    "date": "2024-05-15",
    "time": "12:00:00",
    "timezone": "Asia/Kathmandu",
    "latitude": 27.7172,
    "longitude": 85.3240,
    "altitude": 1350,
    "ayanamsa": "lahiri",
    "house_system": "equal",
    "true_nodes": true
  },
  "expected": {
    "ascendant": 28.55,
    "tolerance_deg": 0.1,
    "planets": {
      "sun": {"longitude": 107.33},
      "moon": {"longitude": 8.95}
    }
  },
  "reference": "JHora 12.0",
  "validation_status": "verified"
}
```

### Run Test

```bash
pytest tests/test_validation.py::test_baseline -v
```

## Known Tolerances

| Calculation | Tolerance | Reason |
|---|---|---|
| Planetary longitude | ±0.1° | Ephemeris precision + rounding |
| Rāśi | exact | Mathematical formula |
| Nakshatra | exact | 13°20' segments |
| Pada | exact | 3°20' per pada |
| Tithi | ±1 minute | Transition search precision |
| Yoga | ±2 minutes | Combined Sun-Moon precision |
| Lagna | ±0.05° | Swiss Ephemeris precision |
| D1-D12 | exact | Mathematical formulas |
| D20+ | ±1 minute arc | Fine-grained sensitivity |
| D60 | ⚠️ ±10 minutes | EXTREMELY SENSITIVE TO BIRTH TIME |
| Vimshottari balance | ±1 day | Calculation rounding |

## Reporting Issues

If you find discrepancies:

1. Create minimal test case with exact inputs
1. Test in reference software with same settings
1. Document difference (actual vs. expected)
1. Open GitHub issue with:
   - JyotishCore version
   - Input (date/time/location/settings)
   - Expected vs. actual
   - Reference software & version

Golden cases without provenance should be skipped or marked unverified; they must not be used as proof of accuracy.
