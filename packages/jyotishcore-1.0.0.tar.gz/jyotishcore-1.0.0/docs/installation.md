# Installation

## Option A — Pre-built wheel (Recommended)

```bash
pip install jyotishcore
```

## Option B — Build from source

Requires Rust 1.70+.

```bash
pip install maturin
git clone https://github.com/sakshyambanjade/jyotishcore
cd jyotishcore
maturin develop --release
```
