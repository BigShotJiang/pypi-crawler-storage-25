# JyotishCore — Accuracy & Validation Methodology

JyotishCore is designed for professional astrological use where precision is non-negotiable. This document outlines our validation methodology and the current accuracy benchmarks.

## Validation Strategy

Our validation suite compares JyotishCore output against high-precision baselines:

1. **JHora (Jagannatha Hora) Baselines**: We use JHora, the gold standard for Vedic practitioners, to generate expected longitudes for various historical and geographic scenarios.
1. **Swiss Ephemeris Direct**: Since JyotishCore uses the Swiss Ephemeris (via C-bindings), we verify that our coordinate transformations (tropical-to-sidereal, ayanamsa offsets) match the reference implementation exactly.

## Current Benchmarks

| Component | Target Tolerance | Current Accuracy |
|-----------|------------------|------------------|
| Planet Longitudes | < 0.1° | < 0.001° |
| Ascendant (Lagna) | < 0.1° | < 0.01° |
| Tithi Transition | < 5 minutes | < 1 minute |

## Test Coverage

The `tests/data/jhora_baseline/` directory contains 50+ JSON cases covering:

- **Indian Subcontinent**: Standard Lahiri charts.
- **Southern Hemisphere**: High latitudes like Australia and Argentina.
- **Polar Regions**: Extreme latitudes (Norway) where house systems often struggle.
- **Boundary Cases**: Planets at 0.01° or 29.99° of a sign.
- **Timezone Transitions**: Cases crossing DST boundaries.

## Running Validation

To run the full validation suite:

```bash
pytest tests/test_validation.py -v
```

All contributions that modify the calculation engine MUST pass this validation suite before being merged.
