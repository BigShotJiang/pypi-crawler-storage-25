# ✨ JyotishCore

![PyPI](https://img.shields.io/pypi/v/jyotishcore)
![Python Versions](https://img.shields.io/pypi/pyversions/jyotishcore)
![License](https://img.shields.io/github/license/sakshyambanjade/jyotishcore)
![Build](https://github.com/sakshyambanjade/jyotishcore/actions/workflows/ci.yml/badge.svg)
![Coverage](https://img.shields.io/badge/coverage-100%25-brightgreen.svg)

> **Disclaimer**: JyotishCore is an astronomical calculation engine, not a deterministic fortune-telling system. Any interpretive text (e.g., Yogas) is classical reference material, not actionable life advice.

**JyotishCore** is the world's most accurate, high-performance Vedic Astrology (Jyotisha) calculation engine. Powered by a Rust backend built on the Swiss Ephemeris and exposed via an elegant, object-oriented Python SDK.

## Features

- **Blazing Fast Calculations:** Rust core enables calculating hundreds of charts in milliseconds using Rayon data-parallelism.
- **Extreme Precision:** Leverages the NASA-backed Swiss Ephemeris (`C` library embedded via Rust).
- **Object-Oriented Python SDK:** Designed for modern developers with strict typing, immutable models (`@dataclass`), and clean interfaces.
- **Regional Panchanga & Calendars:** Native support for the Bikram Sambat (BS) calendar and built-in localization translation mapping for Hindi and Nepali.
- **Interactive Developer Dashboard:** Comes with a built-in Streamlit playground to test and evaluate the API instantly.
- **Muhurta Finder Engine:** Blazing fast step-and-search algorithms to hunt for auspicious time windows in microseconds.

## Performance Benchmark

| Engine | Single Chart | Batch (1,000) | Backend |
|---|---|---|---|
| **JyotishCore (Rust)** | **~0.2 ms** | **~15 ms** | Rust/PyO3 |
| Flatlib | ~5.0 ms | ~4,800 ms | Pure Python |
| SwissEph (Raw) | ~0.5 ms | ~500 ms | C/Python |

## Installation

```bash
pip install jyotishcore
```

To install the optional interactive developer dashboard:
```bash
pip install "jyotishcore[ui]"
```

## Quick Start

### 1. Modern Object-Oriented Initialization (Recommended)

```python
from jyotishcore import Chart, GeoLocation, JyotishTime, Ayanamsa

# 1. Define Time and Location
time = JyotishTime(year=2024, month=5, day=15, hour=12, minute=0)
location = GeoLocation(latitude=27.7172, longitude=85.3240, timezone="Asia/Kathmandu")

# 2. Compute the Chart
chart = Chart.compute(time=time, location=location, ayanamsa_obj=Ayanamsa.LAHIRI)

# 3. Retrieve Ascendant (Lagna)
print(f"Lagna: {chart.ascendant():.2f}°")

# 4. Explore Planetary Positions
planets = chart.planets()
sun = planets["sun"]
print(f"Sun is in {sun.sign} at {sun.longitude:.2f}° (House {sun.house})")
```

### 2. Regional Panchanga (Localization)

Easily output results in Hindi (`hi`) or Nepali (`ne`).

```python
from jyotishcore import get_panchanga

# Get localized Panchanga in Hindi
p = get_panchanga(
    year=2024, month=5, day=15, hour=12, minute=0, second=0,
    latitude=27.7172, longitude=85.3240,
    locale="hi"
)

print(p.tithi.paksha) # "शुक्ल"
print(p.tithi.name)   # "अष्टमी"
```

## Interactive Dashboard

If you installed the `ui` extra, you can launch the interactive dashboard locally:

```bash
jyotishcore-ui
```

This will boot a Streamlit app where you can tweak parameters, calculate natal charts, view panchangas, and run the Muhurta finder directly in your browser.

## Documentation

Full documentation is available on [ReadTheDocs](https://jyotishcore.readthedocs.io).

## License

This project is dual-licensed under MIT and AGPL (due to Swiss Ephemeris dependency). See the `LICENSE` file for details.
