from typing import Callable, Any

def tool(func: Callable[..., Any]) -> Callable[..., Any]:
    """Simple pass‑through decorator used to mimic `langchain_core.tools.tool`.
    It returns the original function unchanged, satisfying type‑checkers.
    """
    return func

__all__ = ["tool"]
