// Build script for JyotishCore
//
// LICENSING NOTE:
// This script compiles vendored Swiss Ephemeris (AGPL-3.0 / Commercial License).
// See vendor/swisseph/LICENSE and vendor/swisseph/agpl-3.0.txt for details.
//
// For open-source/non-commercial use: AGPL-3.0 applies (source must be available)
// For proprietary use: obtain a commercial license from Astrodienst
// https://www.astro.com/swisseph/

fn main() {
    cc::Build::new()
        .files(&[
            "vendor/swisseph/src/sweph.c",
            "vendor/swisseph/src/swephlib.c",
            "vendor/swisseph/src/swedate.c",
            "vendor/swisseph/src/swehouse.c",
            "vendor/swisseph/src/swejpl.c",
            "vendor/swisseph/src/swemmoon.c",
            "vendor/swisseph/src/swemplan.c",
            "vendor/swisseph/src/swecl.c",
        ])
        .include("vendor/swisseph/src")
        .compile("swisseph");
    println!("cargo:rustc-link-lib=static=swisseph");
}
