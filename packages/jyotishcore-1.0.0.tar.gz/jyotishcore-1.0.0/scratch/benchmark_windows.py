import time
from jyotishcore import find_time_windows

start = time.time()
# Search 1 day (1440 mins), for D9 (varga=9) Taurus (Taurus is sign index 2, but wait, target_sign="taurus")
# Actually, the signature is base_date, window_minutes, varga, target_sign, lat, lon
windows = find_time_windows("2024-05-15T12:00:00Z", 1440, 9, "taurus", 27.7172, 85.3240)
end = time.time()

print(f"Found {len(windows)} windows in {end-start:.4f} seconds")
print(windows)
