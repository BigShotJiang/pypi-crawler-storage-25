import random
from datetime import datetime, timedelta, timezone

import pytest

from jyotishcore import Panchanga


@pytest.mark.parametrize("_", range(200))
def test_panchanga_boundary_invariant(_):
    """Tithi, nakshatra, yoga, karana intervals must contain query time."""
    year = random.randint(2000, 2030)
    month = random.randint(1, 12)
    # limit day to 28 to avoid month length issues
    day = random.randint(1, 28)
    hour = random.randint(0, 23)
    minute = random.randint(0, 59)

    p = Panchanga.from_local(
        date=f"{year}-{month:02d}-{day:02d}",
        time=f"{hour:02d}:{minute:02d}:00",
        timezone="Asia/Kolkata",
        latitude=28.6,
        longitude=77.2,
    )

    # We need timezone-aware datetime for comparisons
    query_utc = datetime.fromisoformat(
        p.metadata["utc_datetime"].replace("Z", "+00:00")
    )

    for element_name in ["tithi", "nakshatra", "yoga", "karana"]:
        el = getattr(p, element_name)
        if hasattr(el, "start_time_utc"):
            start_utc_str = el.start_time_utc
            end_utc_str = el.end_time_utc
        else:
            start_utc_str = el["start_time_utc"]
            end_utc_str = el["end_time_utc"]

        start_utc = datetime.fromisoformat(start_utc_str.replace("Z", "+00:00"))
        end_utc = datetime.fromisoformat(end_utc_str.replace("Z", "+00:00"))

        # Ensure query is inside the interval, allowing a 1-second float tolerance
        assert start_utc <= query_utc + timedelta(
            seconds=1
        ), f"{element_name} start is after query time"
        assert (
            query_utc - timedelta(seconds=1) <= end_utc
        ), f"{element_name} end is before query time"

        duration_hours = (end_utc - start_utc).total_seconds() / 3600
        # Tithi/Nakshatra max ~ 28h, Yoga max ~ 28h, Karana ~ 14h. Give 80 as a safe upper bound.
        assert (
            0 < duration_hours < 80
        ), f"{element_name} duration implausible: {duration_hours}h"
