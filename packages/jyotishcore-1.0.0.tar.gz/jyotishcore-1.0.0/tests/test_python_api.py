import pytest

import jyotishcore
from jyotishcore import Chart, Panchanga


def test_chart_from_local_metadata_and_warnings():
    chart = Chart.from_local(
        date="2024-05-15",
        time="12:00:00",
        timezone="Asia/Kathmandu",
        latitude=27.7172,
        longitude=85.3240,
        altitude=1350,
        ayanamsa="lahiri",
        house_system="equal",
    )

    metadata = chart.metadata()
    assert metadata["input_mode"] == "local_civil"
    assert metadata["timezone"] == "Asia/Kathmandu"
    assert metadata["latitude"] == 27.7172
    assert metadata["longitude"] == 85.3240
    assert metadata["longitude_type"] == "sidereal"
    assert chart.warnings()


def test_chart_from_utc_and_julian_day_have_metadata():
    chart = Chart.from_utc(2024, 5, 15, 6, 15, 0, 27.7172, 85.3240)
    assert chart.metadata()["input_mode"] == "utc"

    jd_chart = Chart.from_julian_day(2460445.7604, 27.7172, 85.3240)
    assert jd_chart.metadata()["input_mode"] == "julian_day_ut"


def test_chart_accessors_are_python_native():
    chart = Chart.from_utc(2024, 5, 15, 6, 15, 0, 27.7172, 85.3240)
    assert isinstance(chart.planets(), dict)
    assert isinstance(chart.houses(), list)
    assert chart.vargas(9) is not None
    assert "vimshottari" in chart.dasha()
    assert isinstance(chart.to_dict(), dict)
    assert isinstance(chart.to_json(), str)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"latitude": 91.0, "longitude": 85.3240},
        {"latitude": 27.7172, "longitude": 181.0},
    ],
)
def test_invalid_location_raises_value_error(kwargs):
    with pytest.raises(ValueError):
        Chart.from_utc(
            2024,
            5,
            15,
            6,
            15,
            0,
            kwargs["latitude"],
            kwargs["longitude"],
        )


def test_dst_ambiguity_raises_value_error():
    with pytest.raises(ValueError):
        jyotishcore.local_to_utc(2024, 11, 3, 1, 30, 0, "America/New_York")


def test_panchanga_from_local():
    panchanga = Panchanga.from_local(
        date="2026-05-16",
        time="12:00:00",
        timezone="Asia/Kathmandu",
        latitude=27.7172,
        longitude=85.3240,
    )
    assert panchanga.tithi.name
    assert panchanga.nakshatra.pada in {1, 2, 3, 4}
    assert panchanga.metadata.timezone == "Asia/Kathmandu"
    assert panchanga.tithi.end_time_utc
    assert panchanga.tithi.end_time_local


def test_pythonic_houses_and_lagna():
    chart = Chart.from_utc(2024, 5, 15, 6, 15, 0, 27.7172, 85.3240)

    # Test Lagna properties
    lagna = chart.lagna
    assert lagna.longitude == chart.ascendant()
    assert lagna.sign == "Leo"
    assert lagna.nakshatra == "Magha"
    assert lagna.pada in {1, 2, 3, 4}

    # Lagna dict emulation
    assert lagna["sign"] == "Leo"

    # Test House properties
    houses = chart.houses()
    assert len(houses) == 12

    house1 = houses[0]
    assert house1.house == 1
    assert house1.cusp == chart.ascendant()
    assert house1.ruling_sign == "Leo"
    assert house1.lord == "Sun"
    assert isinstance(house1.resident_planets, list)

    # House dict emulation
    assert house1["house"] == 1
    assert house1["cusp"] == chart.ascendant()
    assert house1["ruling_sign"] == "Leo"


def test_divisional_chart_oop():
    chart = Chart.from_utc(2024, 5, 15, 6, 15, 0, 27.7172, 85.3240)

    # D9 Navamsa
    d9 = chart.divisional_chart(9)
    assert d9 is not None
    assert d9.varga == 9
    assert d9.varga_lagna.sign == "Aries"

    # Planets mapping
    d9_planets = d9.planets()
    assert "sun" in d9_planets
    sun_pos = d9_planets["sun"]
    assert sun_pos.planet == "Sun"
    assert sun_pos.sign == "Capricorn"

    assert sun_pos.house in range(1, 13)

    # Divisional houses
    d9_houses = d9.houses()
    assert len(d9_houses) == 12
    assert d9_houses[0].house == 1
    assert d9_houses[0].ruling_sign == "Aries"

    # Aspects inside division
    d9_aspects = d9.aspects()
    assert isinstance(d9_aspects, list)
    for asp in d9_aspects:
        assert "from_planet" in asp
        assert "to_planet" in asp
        assert "aspect_type" in asp


def test_premium_svg_renderer():
    chart = Chart.from_utc(2024, 5, 15, 6, 15, 0, 27.7172, 85.3240)

    # Test D1 SVG styles
    svg_north = chart.to_svg(style="north")
    assert "<svg" in svg_north
    assert "D1 RASHI" in svg_north

    svg_south = chart.to_svg(style="south")
    assert "<svg" in svg_south
    assert "ASC" in svg_south

    svg_circular = chart.to_svg(style="circular")
    assert "<svg" in svg_circular
    assert "circle" in svg_circular

    # Test Varga SVG styles
    d9 = chart.divisional_chart(9)
    d9_svg = d9.to_svg(style="circular")
    assert "<svg" in d9_svg
    assert "circle" in d9_svg
