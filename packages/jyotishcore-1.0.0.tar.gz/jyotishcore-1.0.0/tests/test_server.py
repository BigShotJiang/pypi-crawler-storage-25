# mypy: ignore-errors
"""
Comprehensive test suite for JyotishCore API server.
Run with: pytest tests/test_server.py -v
"""

import json

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from jyotishcore.server import ChartRequest, JyotishCoreError, app

client = TestClient(app)

# ============ Fixtures ============


@pytest.fixture
def valid_chart_data():
    """Valid chart request data."""
    return {
        "year": 1990,
        "month": 5,
        "day": 15,
        "hour": 10,
        "minute": 30,
        "second": 0,
        "latitude": 28.6139,
        "longitude": 77.2090,
        "altitude": 0,
        "ayanamsa": "lahiri",
        "house_system": "equal",
        "true_nodes": True,
    }


# ============ Tests: Health & Root Endpoints ============


def test_health_check():
    """Test health check endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "JyotishCore API"
    assert "version" in data


def test_root_endpoint():
    """Test root endpoint."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "name" in data
    assert "version" in data
    assert "endpoints" in data


# ============ Tests: Request Validation ============


def test_chart_request_valid(valid_chart_data):
    """Test valid chart request."""
    request = ChartRequest(**valid_chart_data)
    assert request.year == 1990
    assert request.latitude == 28.6139


def test_chart_request_invalid_year():
    """Test invalid year."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1850,
            month=5,
            day=15,
            hour=10,
            minute=30,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            altitude=0,
        )


def test_chart_request_invalid_month():
    """Test invalid month."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=13,
            day=15,
            hour=10,
            minute=30,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            altitude=0,
        )


def test_chart_request_invalid_day():
    """Test invalid day."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=5,
            day=32,
            hour=10,
            minute=30,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            altitude=0,
        )


def test_chart_request_invalid_hour():
    """Test invalid hour."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=5,
            day=15,
            hour=24,
            minute=30,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            altitude=0,
        )


def test_chart_request_invalid_minute():
    """Test invalid minute."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=5,
            day=15,
            hour=10,
            minute=60,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            altitude=0,
        )


def test_chart_request_invalid_latitude():
    """Test invalid latitude."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=5,
            day=15,
            hour=10,
            minute=30,
            second=0,
            latitude=91.0,
            longitude=77.2090,
            altitude=0,
        )


def test_chart_request_invalid_longitude():
    """Test invalid longitude."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=5,
            day=15,
            hour=10,
            minute=30,
            second=0,
            latitude=28.6139,
            longitude=181.0,
            altitude=0,
        )


def test_chart_request_invalid_altitude():
    """Test invalid altitude."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=5,
            day=15,
            hour=10,
            minute=30,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            altitude=15000,
        )


def test_chart_request_invalid_ayanamsa():
    """Test invalid ayanamsa."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=5,
            day=15,
            hour=10,
            minute=30,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            altitude=0,
            ayanamsa="invalid",
        )


def test_chart_request_invalid_house_system():
    """Test invalid house system."""
    with pytest.raises(ValidationError):
        ChartRequest(
            year=1990,
            month=5,
            day=15,
            hour=10,
            minute=30,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            altitude=0,
            house_system="invalid",
        )


# ============ Tests: API Endpoints ============


@pytest.mark.slow
def test_chart_endpoint(valid_chart_data):
    """Test chart computation endpoint."""
    response = client.post("/v1/chart", json=valid_chart_data)
    assert response.status_code == 200
    data = response.json()
    assert "ascendant" in data
    assert "planets" in data
    assert "dashas" in data
    assert "vimshottari" in data["dashas"]
    assert "warnings" in data
    assert "navamsa" in data
    assert data["navamsa"]
    assert "source_longitude" in data["navamsa"][0]
    assert "display_longitude" in data["navamsa"][0]
    assert "longitude" not in data["navamsa"][0]


@pytest.mark.slow
def test_chart_endpoint_with_different_ayanamsa(valid_chart_data):
    """Test chart with different ayanamsa."""
    for ayanamsa in ["lahiri", "raman", "kp"]:
        valid_chart_data["ayanamsa"] = ayanamsa
        response = client.post("/v1/chart", json=valid_chart_data)
        assert response.status_code == 200


@pytest.mark.slow
def test_chart_endpoint_with_different_house_system(valid_chart_data):
    """Test chart with different house systems."""
    for house_system in ["equal", "placidus", "koch", "whole_sign"]:
        valid_chart_data["house_system"] = house_system
        response = client.post("/v1/chart", json=valid_chart_data)
        assert response.status_code == 200


@pytest.mark.slow
def test_panchanga_endpoint(valid_chart_data):
    """Test panchanga endpoint."""
    response = client.post("/v1/panchanga", json=valid_chart_data)
    assert response.status_code == 200
    data = response.json()
    assert "tithi" in data
    assert "nakshatra" in data
    assert "yoga" in data
    assert data["tithi_ends"]
    assert data["nakshatra_ends"]


@pytest.mark.slow
def test_dasha_endpoint(valid_chart_data):
    """Test dasha endpoint."""
    response = client.post("/v1/dasha", json=valid_chart_data)
    assert response.status_code == 200
    data = response.json()
    assert "dashas" in data
    assert "vimshottari" in data["dashas"]
    assert isinstance(data["dashas"]["vimshottari"], list)


@pytest.mark.slow
def test_explain_endpoint(valid_chart_data):
    """Test explanation endpoint."""
    response = client.post("/v1/explain", json=valid_chart_data)
    assert response.status_code == 200
    data = response.json()
    assert "ascendant" in data
    assert "explanation_graph" in data


# ============ Tests: Error Handling ============


def test_chart_endpoint_invalid_data():
    """Test chart endpoint with invalid data."""
    response = client.post("/v1/chart", json={"year": "invalid"})
    assert response.status_code == 422  # Validation error


def test_chart_endpoint_missing_required_fields():
    """Test chart endpoint with missing required fields."""
    response = client.post("/v1/chart", json={"year": 1990})
    assert response.status_code == 422


# ============ Tests: Response Models ============


@pytest.mark.slow
def test_chart_response_model(valid_chart_data):
    """Test chart response matches model."""
    response = client.post("/v1/chart", json=valid_chart_data)
    assert response.status_code == 200
    data = response.json()
    # Verify response structure
    assert isinstance(data["ascendant"], (int, float))
    assert isinstance(data["planets"], list)
    assert "dashas" in data
    assert "vimshottari" in data["dashas"]
    assert "yogini" not in data["dashas"]
    assert "chara" not in data["dashas"]
    assert isinstance(data["dashas"]["vimshottari"], list)
    assert isinstance(data["warnings"], list)


@pytest.mark.slow
def test_panchanga_response_model(valid_chart_data):
    """Test panchanga response matches model."""
    response = client.post("/v1/panchanga", json=valid_chart_data)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data["tithi"], str)
    assert isinstance(data["nakshatra"], str)
    assert isinstance(data["yoga"], str)


# ============ Tests: Default Values ============


def test_chart_defaults():
    """Test default values for optional fields."""
    response = client.post(
        "/v1/chart",
        json={
            "year": 1990,
            "month": 5,
            "day": 15,
            "latitude": 28.6139,
            "longitude": 77.2090,
        },
    )
    # If defaults work, this should succeed (or fail gracefully with defaults)
    assert response.status_code in [200, 500]  # Either success or internal error


# ============ Tests: Edge Cases ============


@pytest.mark.slow
def test_chart_at_equator():
    """Test chart computation at equator."""
    response = client.post(
        "/v1/chart",
        json={
            "year": 2000,
            "month": 1,
            "day": 1,
            "hour": 12,
            "minute": 0,
            "second": 0,
            "latitude": 0.0,
            "longitude": 0.0,
            "altitude": 0,
        },
    )
    assert response.status_code == 200


@pytest.mark.slow
def test_chart_at_poles():
    """Test chart computation at high latitude."""
    response = client.post(
        "/v1/chart",
        json={
            "year": 2000,
            "month": 1,
            "day": 1,
            "hour": 12,
            "minute": 0,
            "second": 0,
            "latitude": 85.0,
            "longitude": 0.0,
            "altitude": 0,
        },
    )
    assert response.status_code == 200


@pytest.mark.slow
def test_chart_high_altitude():
    """Test chart at high altitude."""
    response = client.post(
        "/v1/chart",
        json={
            "year": 2000,
            "month": 1,
            "day": 1,
            "hour": 12,
            "minute": 0,
            "second": 0,
            "latitude": 28.6139,
            "longitude": 77.2090,
            "altitude": 8848,  # Mt. Everest
        },
    )
    assert response.status_code == 200


# ============ Parametrized Tests ============


@pytest.mark.parametrize("year", [1900, 1950, 2000, 2050])
@pytest.mark.slow
def test_chart_various_years(year):
    """Test chart for various years."""
    response = client.post(
        "/v1/chart",
        json={
            "year": year,
            "month": 1,
            "day": 1,
            "hour": 12,
            "minute": 0,
            "second": 0,
            "latitude": 28.6139,
            "longitude": 77.2090,
            "altitude": 0,
        },
    )
    assert response.status_code == 200


@pytest.mark.parametrize(
    "ayanamsa", ["lahiri", "raman", "kp", "true_chitra", "true_pushya"]
)
@pytest.mark.slow
def test_all_ayanamsas(ayanamsa):
    """Test all ayanamsa options."""
    response = client.post(
        "/v1/chart",
        json={
            "year": 1990,
            "month": 5,
            "day": 15,
            "hour": 10,
            "minute": 30,
            "second": 0,
            "latitude": 28.6139,
            "longitude": 77.2090,
            "altitude": 0,
            "ayanamsa": ayanamsa,
        },
    )
    assert response.status_code == 200


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-m", "not slow"])
