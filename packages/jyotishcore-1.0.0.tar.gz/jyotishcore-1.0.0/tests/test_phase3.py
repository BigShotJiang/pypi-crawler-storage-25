import asyncio
import json
from typing import List

import pytest
from fastapi.testclient import TestClient

from jyotishcore.models import Chart
from jyotishcore.server import BatchChartRequest, app
from jyotishcore.tools import (
    calculate_birth_chart,
    check_relationship_compatibility,
    get_langchain_tools,
)

client = TestClient(app)


def test_batch_computation_python():
    # Test identical to sequential computation
    inputs = [
        (1990, 5, 15, 10, 30, 0, 28.6139, 77.2090, 0.0),
        (1992, 8, 20, 14, 45, 0, 19.0760, 72.8777, 0.0),
    ]

    batch_charts = Chart.compute_batch(inputs, "lahiri", "equal", True)

    c1_seq = Chart.compute(*inputs[0])
    c2_seq = Chart.compute(*inputs[1])

    assert len(batch_charts) == 2
    assert batch_charts[0].ascendant() == c1_seq.ascendant()
    assert batch_charts[1].ascendant() == c2_seq.ascendant()


def test_batch_computation_api():
    inputs = [
        [1990, 5, 15, 10, 30, 0, 28.6139, 77.2090, 0.0],
        [1992, 8, 20, 14, 45, 0, 19.0760, 72.8777, 0.0],
    ]

    response = client.post("/v1/chart/batch", json={"inputs": inputs})
    assert response.status_code == 200

    data = response.json()
    assert len(data) == 2
    assert "ascendant" in data[0]
    assert "ascendant" in data[1]
    assert data[0]["ascendant"] != data[1]["ascendant"]


def test_langchain_tools():
    tools = get_langchain_tools()
    assert len(tools) == 2

    # Check tool schemas
    assert tools[0].name == "calculate_birth_chart"
    assert tools[1].name == "check_relationship_compatibility"

    # Test invoke (synchronous)
    res1_str = tools[0].invoke(
        {
            "year": 1990,
            "month": 5,
            "day": 15,
            "hour": 10,
            "minute": 30,
            "second": 0,
            "latitude": 28.6139,
            "longitude": 77.2090,
        }
    )

    res1 = json.loads(res1_str)
    assert "ascendant" in res1
    assert res1["ascendant"]["sign"] == "Virgo"

    res2_str = tools[1].invoke(
        {
            "boy_year": 1990,
            "boy_month": 5,
            "boy_day": 15,
            "boy_hour": 10,
            "boy_min": 30,
            "boy_sec": 0,
            "boy_lat": 28.6139,
            "boy_lon": 77.2090,
            "girl_year": 1992,
            "girl_month": 8,
            "girl_day": 20,
            "girl_hour": 14,
            "girl_min": 45,
            "girl_sec": 0,
            "girl_lat": 19.0760,
            "girl_lon": 72.8777,
        }
    )

    res2 = json.loads(res2_str)
    assert "total_score" in res2
    assert res2["total_score"] == 27.0
