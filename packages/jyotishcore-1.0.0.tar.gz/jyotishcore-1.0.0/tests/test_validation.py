import glob
import json
import os

import pytest

# Check if jyotishcore is installed/built
try:
    import jyotishcore
except ImportError:
    # Fallback for local development
    import sys

    sys.path.append("jyotishcore_py")
    import jyotishcore

TOLERANCE = 0.1  # degrees


@pytest.mark.parametrize("case_file", glob.glob("tests/data/jhora_baseline/*.json"))
def test_baseline(case_file):
    with open(case_file) as f:
        case = json.load(f)

    if "input" not in case or "expected" not in case:
        pytest.skip(f"{case_file} uses legacy golden-data schema")

    if case.get("validation_status") != "verified":
        pytest.skip(f"{case_file} is not marked as verified golden data")

    inp = case["input"]
    exp = case["expected"]

    if "planets" not in exp:
        pytest.skip(f"{case_file} uses structured golden-data schema")

    # Map input keys to Chart.compute arguments
    chart = jyotishcore.Chart.compute(
        year=inp["year"],
        month=inp["month"],
        day=inp["day"],
        hour=inp["hour"],
        minute=inp["minute"],
        second=inp["second"],
        latitude=inp["latitude"],
        longitude=inp["longitude"],
        altitude=inp.get("altitude", 0.0),
        ayanamsa=inp.get("ayanamsa", "lahiri"),
        house_system=inp.get("house_system", "equal"),
        true_nodes=inp.get("true_nodes", True),
    )

    tolerance = exp.get("tolerance_deg", TOLERANCE)

    # Check Ascendant
    actual_asc = chart.ascendant()
    asc_diff = abs(actual_asc - exp["ascendant"])
    # Handle 360 wrap around
    if asc_diff > 180:
        asc_diff = 360 - asc_diff
    assert asc_diff <= tolerance, f"Ascendant off by {asc_diff:.4f}° in {case_file}"

    # Check Planets
    planets = chart.planets()
    for planet_name, planet_exp in exp["planets"].items():
        actual = planets[planet_name.lower()]
        lon_diff = abs(actual.longitude - planet_exp["longitude"])
        # Handle 360 wrap around
        if lon_diff > 180:
            lon_diff = 360 - lon_diff

        assert (
            lon_diff <= tolerance
        ), f"{planet_name} longitude off by {lon_diff:.4f}° in {case_file}"

        # Optionally check house
        if "house" in planet_exp:
            assert (
                actual.house == planet_exp["house"]
            ), f"{planet_name} house mismatch in {case_file}"


# ============================================================================
# BOUNDARY TESTS FOR PANCHANGA ELEMENTS
# ============================================================================


class TestTithiBoundary:
    """Test tithi transitions and boundaries."""

    def test_tithi_index_range(self):
        """Tithi index should always be 1-30."""
        chart = jyotishcore.Chart.compute(
            year=2020,
            month=1,
            day=1,
            hour=12,
            minute=0,
            second=0,
            latitude=0.0,
            longitude=0.0,
        )
        panchanga = jyotishcore.get_panchanga(
            year=2020,
            month=1,
            day=1,
            hour=12,
            minute=0,
            second=0,
            latitude=0.0,
            longitude=0.0,
        )
        tithi = panchanga["tithi"]
        assert 1 <= tithi["index"] <= 30, f"Tithi index {tithi['index']} out of range"
        assert tithi["paksha"] in [
            "Shukla",
            "Krishna",
        ], f"Invalid paksha: {tithi['paksha']}"

    def test_tithi_lunar_day_consistency(self):
        """Tithi 1-15 should be Shukla Paksha, 16-30 Krishna Paksha."""
        for day in range(1, 31):
            hour = day % 24
            chart = jyotishcore.Chart.compute(
                year=2020,
                month=3,
                day=15,
                hour=hour,
                minute=0,
                second=0,
                latitude=0.0,
                longitude=0.0,
            )
            panchanga = jyotishcore.get_panchanga(
                year=2020,
                month=3,
                day=15,
                hour=hour,
                minute=0,
                second=0,
                latitude=0.0,
                longitude=0.0,
            )
            tithi = panchanga["tithi"]
            if tithi["index"] <= 15:
                assert (
                    tithi["paksha"] == "Shukla"
                ), f"Tithi {tithi['index']} should be Shukla, got {tithi['paksha']}"
            else:
                assert (
                    tithi["paksha"] == "Krishna"
                ), f"Tithi {tithi['index']} should be Krishna, got {tithi['paksha']}"


class TestNakshatraBoundary:
    """Test nakshatra transitions and pada."""

    def test_nakshatra_index_range(self):
        """Nakshatra index should always be 1-27."""
        panchanga = jyotishcore.get_panchanga(
            year=2020,
            month=6,
            day=15,
            hour=12,
            minute=0,
            second=0,
            latitude=0.0,
            longitude=0.0,
        )
        nak = panchanga["nakshatra"]
        assert 1 <= nak["index"] <= 27, f"Nakshatra index {nak['index']} out of range"
        assert 1 <= nak["pada"] <= 4, f"Pada {nak['pada']} out of range"

    def test_nakshatra_all_27(self):
        """Test that all 27 nakshatras can be found."""
        found_nakshatras = set()
        # Sample 27 different days to increase likelihood of hitting all nakshatras
        for day in range(1, 28):
            panchanga = jyotishcore.get_panchanga(
                year=2020,
                month=6,
                day=day,
                hour=12,
                minute=0,
                second=0,
                latitude=0.0,
                longitude=0.0,
            )
            nak = panchanga["nakshatra"]
            found_nakshatras.add(nak["index"])

        # Should have found at least 20+ different nakshatras in 27 days
        assert (
            len(found_nakshatras) >= 20
        ), f"Only found {len(found_nakshatras)} unique nakshatras in 27 days"


class TestYogaBoundary:
    """Test yoga transitions and sequence."""

    def test_yoga_index_range(self):
        """Yoga index should always be 1-27."""
        panchanga = jyotishcore.get_panchanga(
            year=2020,
            month=9,
            day=15,
            hour=12,
            minute=0,
            second=0,
            latitude=0.0,
            longitude=0.0,
        )
        yoga = panchanga["yoga"]
        assert 1 <= yoga["index"] <= 27, f"Yoga index {yoga['index']} out of range"


class TestVargaBoundaries:
    """Test divisional chart formulas."""

    def test_d2_hora_formula(self):
        """Test D2 (Hora) formula: 15° segments."""
        # Create a chart with known positions
        chart = jyotishcore.Chart.compute(
            year=2020,
            month=6,
            day=15,
            hour=12,
            minute=0,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
            ayanamsa="lahiri",
        )

        # Get vargas for varga 2 (Hora)
        vargas = chart.vargas(2)
        assert vargas is not None, "Hora chart (D2) should exist"
        assert len(vargas) == 9, f"Expected 9 planets in D2, got {len(vargas)}"

    def test_d9_navamsa_formula(self):
        """Test D9 (Navamsa) formula: 3°20' segments."""
        chart = jyotishcore.Chart.compute(
            year=2024,
            month=5,
            day=15,
            hour=6,
            minute=15,
            second=0,
            latitude=27.7172,
            longitude=85.3240,
            ayanamsa="lahiri",
        )

        vargas = chart.vargas(9)
        assert vargas is not None, "Navamsa chart (D9) should exist"
        assert len(vargas) == 9, f"Expected 9 planets in D9, got {len(vargas)}"

    def test_d60_shashtiamsa_sensitivity_warning(self):
        """D60 should produce a sensitivity warning."""
        chart = jyotishcore.Chart.compute(
            year=2020,
            month=6,
            day=15,
            hour=12,
            minute=0,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
        )

        warnings = chart.warnings()
        assert any(
            "D60" in w or "high divisional" in w for w in warnings
        ), "Chart should include D60/sensitivity warning"

    def test_d9_varga_sign_matches_divisional_signs(self):
        """D9 varga_sign should match the D9 entry in planet divisional_signs."""
        chart = jyotishcore.Chart.compute(
            year=2020,
            month=6,
            day=15,
            hour=12,
            minute=0,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
        )

        planets = chart.planets()
        d9 = chart.vargas(9)
        assert d9 is not None
        sun_d9 = next(p for p in d9 if p.planet.lower() == "sun")
        assert sun_d9.varga_sign == planets["sun"].divisional_signs[9]
        assert sun_d9.source_longitude == pytest.approx(
            planets["sun"].longitude, abs=0.001
        )


class TestMetadataAndWarnings:
    """Test that metadata and warnings are properly included."""

    def test_chart_has_metadata(self):
        """Chart should include calculation metadata."""
        chart = jyotishcore.Chart.compute(
            year=2020,
            month=6,
            day=15,
            hour=12,
            minute=0,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
        )

        metadata = chart.metadata()
        assert "ayanamsa" in metadata, "Metadata should include ayanamsa"
        assert "house_system" in metadata, "Metadata should include house_system"
        assert "utc_datetime" in metadata, "Metadata should include UTC datetime"

    def test_chart_has_warnings(self):
        """Chart should include warnings."""
        chart = jyotishcore.Chart.compute(
            year=2020,
            month=6,
            day=15,
            hour=12,
            minute=0,
            second=0,
            latitude=28.6139,
            longitude=77.2090,
        )

        warnings = chart.warnings()
        assert len(warnings) > 0, "Chart should include at least one warning"
        assert any(
            "calculation" in w.lower() or "not life decision" in w.lower()
            for w in warnings
        ), "Should include safety warning about calculations"
