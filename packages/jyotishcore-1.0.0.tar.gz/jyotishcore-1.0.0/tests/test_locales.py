import pytest

from jyotishcore import Chart, get_panchanga


def test_hindi_locale_panchanga():
    panchanga = get_panchanga(
        year=2024,
        month=5,
        day=15,
        hour=12,
        minute=0,
        second=0,
        latitude=27.7172,
        longitude=85.3240,
        locale="hi",
    )
    # 2024-05-15 is Ashtami Shukla
    assert panchanga.tithi.paksha == "शुक्ल"


def test_nepali_locale_chart():
    chart = Chart.compute(
        year=2024,
        month=5,
        day=15,
        hour=12,
        minute=0,
        second=0,
        latitude=27.7172,
        longitude=85.3240,
        locale="ne",
    )

    sun_pos = chart.planets()["sun"]
    assert sun_pos.planet == "सूर्य"
    assert sun_pos.sign == "वृष"  # Taurus
