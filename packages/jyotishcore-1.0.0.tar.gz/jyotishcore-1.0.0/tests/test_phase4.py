from datetime import datetime, timezone

import pytest

import jyotishcore
from jyotishcore import find_time_windows


def test_sanskrit_names():
    chart = jyotishcore.Chart.compute(1990, 5, 15, 10, 30, 0, 28.6, 77.2, 0)

    # Test planet sanskrit names
    sun = chart.planets()["sun"]
    assert sun.sanskrit_name == "Surya"

    # Test house sanskrit names
    h1 = chart.houses()[0]
    assert h1.sanskrit_name == "Bhava 1"

    # Test lagna sanskrit name
    assert chart.lagna.sanskrit_name == "Lagna"


def test_aspects():
    chart = jyotishcore.Chart.compute(1990, 5, 15, 10, 30, 0, 28.6, 77.2, 0)

    planets = list(chart.planets().values())

    # Get Jupiter
    jupiter = next(p for p in planets if p.planet == "Jupiter")

    # Check aspects
    aspected = jupiter.aspects(planets)
    assert isinstance(aspected, list)

    # Check is_aspecting method manually
    moon = next(p for p in planets if p.planet == "Moon")
    # In 1990-05-15, verify aspect boolean logic (Jupiter aspects 5, 7, 9)
    # Just asserting method runs without crash
    assert isinstance(jupiter.is_aspecting(moon), bool)


def test_divisional_chart_wrapper():
    chart = jyotishcore.Chart.compute(1990, 5, 15, 10, 30, 0, 28.6, 77.2, 0)
    d9 = chart.divisional_chart(9)
    assert d9.varga == 9
    assert hasattr(d9, "varga_lagna")
    assert hasattr(d9, "planets")

    # Test D9 aspects
    aspects = d9.aspects()
    assert isinstance(aspects, list)
    assert len(aspects) > 0


def test_svg_rendering():
    chart = jyotishcore.Chart.compute(1990, 5, 15, 10, 30, 0, 28.6, 77.2, 0)

    # Test North Indian
    svg_north = chart.to_svg(style="north")
    assert "<svg" in svg_north
    assert 'class="house-group"' in svg_north
    assert 'id="graha-sun"' in svg_north

    # Test South Indian
    svg_south = chart.to_svg(style="south")
    assert "<svg" in svg_south
    assert 'class="sign-group"' in svg_south
    assert 'id="graha-sun"' in svg_south


def test_btr_iterators():
    windows = find_time_windows(
        base_date="1990-05-15T10:30:00Z",
        window_minutes=10,
        varga=9,
        target_sign="Pisces",
        lat=28.6,
        lon=77.2,
    )
    assert isinstance(windows, list)
