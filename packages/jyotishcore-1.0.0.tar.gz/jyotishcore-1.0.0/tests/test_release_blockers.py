"""Tests for release-blocker fixes (strict validation, panchanga, vargas)."""

import pytest

import jyotishcore
from jyotishcore import Chart, Panchanga


def test_compute_bs_rejects_invalid_ayanamsa():
    with pytest.raises(ValueError, match="Unknown ayanamsa"):
        Chart.compute_bs(
            bs_year=2081,
            bs_month=1,
            bs_day=1,
            hour=12,
            minute=0,
            second=0,
            latitude=27.7172,
            longitude=85.3240,
            ayanamsa="invalid_ayanamsa",
        )


def test_compute_bs_rejects_invalid_house_system():
    with pytest.raises(ValueError, match="Unknown house_system"):
        Chart.compute_bs(
            bs_year=2081,
            bs_month=1,
            bs_day=1,
            hour=12,
            minute=0,
            second=0,
            latitude=27.7172,
            longitude=85.3240,
            house_system="regiomontanus",
        )


def test_varga_position_has_source_longitude_not_fake_planet_longitude():
    chart = Chart.from_local(
        date="2024-05-15",
        time="12:00:00",
        timezone="Asia/Kathmandu",
        latitude=27.7172,
        longitude=85.3240,
    )
    d9 = chart.vargas(9)
    assert d9 is not None
    moon = chart.planets()["moon"]
    moon_d9 = next(p for p in d9 if p.planet.lower() == "moon")
    assert moon_d9.source_longitude == pytest.approx(moon.longitude, abs=0.001)
    assert moon_d9.varga == 9
    assert moon_d9.varga_sign
    assert moon_d9.display_longitude is not None
    with pytest.raises(AttributeError):
        _ = moon_d9.longitude


@pytest.mark.parametrize(
    "timezone,expected_weekday",
    [
        ("Asia/Kathmandu", "Saturday"),
        ("Asia/Kolkata", "Saturday"),
        ("America/New_York", "Saturday"),
        ("Europe/London", "Saturday"),
    ],
)
def test_panchanga_civil_day_vara_by_timezone(timezone, expected_weekday):
    p = Panchanga.from_local(
        date="2026-05-16",
        time="12:00:00",
        timezone=timezone,
        latitude=27.7172,
        longitude=85.3240,
    )
    assert p.vara.name == expected_weekday
    assert p.metadata.timezone == timezone
    assert p.metadata.mode == "civil_day"
    assert p.tithi.start_time_utc
    assert p.tithi.end_time_utc
    assert p.tithi.start_time_local
    assert p.tithi.end_time_local


def test_panchanga_sunrise_day_mode():
    p = Panchanga.from_local(
        date="2026-05-16",
        time="12:00:00",
        timezone="Asia/Kathmandu",
        latitude=27.7172,
        longitude=85.3240,
        mode="sunrise_day",
    )
    assert p.metadata.mode == "sunrise_day"


def test_panchanga_invalid_mode_raises():
    with pytest.raises(ValueError, match="Unknown panchanga mode"):
        Panchanga.from_local(
            date="2026-05-16",
            time="12:00:00",
            timezone="Asia/Kathmandu",
            latitude=27.7172,
            longitude=85.3240,
            mode="lunar_day",
        )


def test_chart_settings_matches_metadata():
    chart = Chart.from_local(
        date="2024-05-15",
        time="12:00:00",
        timezone="Asia/Kathmandu",
        latitude=27.7172,
        longitude=85.3240,
    )
    assert chart.settings() == chart.metadata()


def test_get_transits_rejects_invalid_ayanamsa():
    with pytest.raises(ValueError, match="Unknown ayanamsa"):
        from jyotishcore.jyotishcore import get_transits

        get_transits(
            "2024-01-01T00:00:00Z",
            "2024-02-01T00:00:00Z",
            ayanamsa="bogus",
        )
