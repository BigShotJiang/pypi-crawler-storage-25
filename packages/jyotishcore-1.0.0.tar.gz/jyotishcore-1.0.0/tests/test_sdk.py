import pytest

from jyotishcore import Ayanamsa, Chart, GeoLocation, JyotishTime, calc_planet_longitude


def test_geolocation_and_time():
    # Test that compute() with kwargs vs objects yields identical charts

    # Using old kwargs
    chart1 = Chart.compute(
        year=2024,
        month=5,
        day=15,
        hour=12,
        minute=0,
        second=0,
        latitude=27.7172,
        longitude=85.3240,
        altitude=1300.0,
        ayanamsa="lahiri",
    )

    # Using new objects
    time = JyotishTime(year=2024, month=5, day=15, hour=12, minute=0, second=0)
    loc = GeoLocation(
        latitude=27.7172, longitude=85.3240, altitude=1300.0, timezone="UTC"
    )

    chart2 = Chart.compute(time=time, location=loc, ayanamsa_obj=Ayanamsa.LAHIRI)

    assert chart1.ascendant() == chart2.ascendant()
    assert chart1.planets()["sun"].longitude == chart2.planets()["sun"].longitude


def test_calc_planet_longitude():
    # Compute using Chart
    chart = Chart.compute(
        year=2024,
        month=5,
        day=15,
        hour=12,
        minute=0,
        second=0,
        latitude=27.7172,
        longitude=85.3240,
    )

    # The Chart.compute internally computes Julian Day.
    # For 2024-05-15 12:00:00 UTC, JD is exactly 2460446.0
    jd = 2460446.0

    # Calculate directly via raw ephemeris
    lon = calc_planet_longitude(jd, "sun", ayanamsa=Ayanamsa.LAHIRI)

    # Should exactly match
    chart_sun = chart.planets()["sun"].longitude
    assert abs(lon - chart_sun) < 0.000001
