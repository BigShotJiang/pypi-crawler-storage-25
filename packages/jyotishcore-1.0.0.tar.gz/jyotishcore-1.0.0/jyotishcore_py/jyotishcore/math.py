# mypy: ignore-errors
from typing import Union

from .constants import Ayanamsa
from .jyotishcore import calc_planet_longitude as _calc_planet_raw


def calc_planet_longitude(
    jd: float, planet: str, ayanamsa: Union[str, Ayanamsa] = "lahiri"
) -> float:
    """
    Calculate the sidereal longitude of a planet for a given Julian Day UT, bypassing
    the Chart object.

    Parameters:
    - jd (float): Julian Day Universal Time.
    - planet (str): The name of the planet (e.g., 'sun', 'moon', 'jupiter').
    - ayanamsa (Union[str, Ayanamsa]): The Ayanamsa system to use.

    Returns:
    - float: The sidereal longitude in degrees (0.0 to 360.0).

    Raises:
    - ValueError: If the planet name is unknown.
    """
    if isinstance(ayanamsa, Ayanamsa):
        ayanamsa_val = ayanamsa.value
    else:
        ayanamsa_val = ayanamsa

    return _calc_planet_raw(jd, planet, ayanamsa_val)
