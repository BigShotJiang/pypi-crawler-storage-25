from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("jyotishcore")
except PackageNotFoundError:
    __version__ = "0.0.0+dev"

from .constants import Ayanamsa
from .helpers import compute_chart_local, current_dasha, find_time_windows
from .inputs import GeoLocation, JyotishTime
from .jyotishcore import VargaPosition
from .jyotishcore import compute_chart_bs as _compute_chart_bs_raw
from .jyotishcore import get_panchanga as _get_panchanga_raw
from .jyotishcore import get_transits, local_to_utc
from .math import calc_planet_longitude
from .models import Chart, Panchanga

__all__ = [
    "Chart",
    "Panchanga",
    "GeoLocation",
    "JyotishTime",
    "Ayanamsa",
    "calc_planet_longitude",
    "compute_chart_bs",
    "compute_chart_local",
    "current_dasha",
    "find_time_windows",
    "get_panchanga",
    "get_transits",
    "local_to_utc",
    "VargaPosition",
    "__version__",
]


def compute_chart_bs(
    bs_year: int,
    bs_month: int,
    bs_day: int,
    hour: int,
    minute: int,
    second: int,
    latitude: float,
    longitude: float,
    altitude: float = 0.0,
    ayanamsa: str = "lahiri",
    house_system: str = "equal",
    true_nodes: bool = True,
) -> Chart:
    """
    Computes a chart using the Bikram Sambat (BS) date calendar,
    returning a wrapped, fully-typed Chart object.
    """
    native = _compute_chart_bs_raw(
        bs_year,
        bs_month,
        bs_day,
        hour,
        minute,
        second,
        latitude,
        longitude,
        altitude,
        ayanamsa,
        house_system,
        true_nodes,
    )
    return Chart(native)


def get_panchanga(
    year: int,
    month: int,
    day: int,
    hour: int,
    minute: int,
    second: int,
    latitude: float,
    longitude: float,
    altitude: float = 0,
    ayanamsa: str = "lahiri",
    true_nodes: bool = True,
    locale: str = "en",
) -> Panchanga:
    """
    Computes the daily Panchanga (five elements of Vedic time) for a given location and time.

    Args:
        year (int): Gregorian year.
        month (int): Gregorian month.
        day (int): Gregorian day.
        hour (int): Hour of the day (0-23).
        minute (int): Minute of the hour.
        second (int): Second of the minute.
        latitude (float): Latitude of the location.
        longitude (float): Longitude of the location.
        altitude (float, optional): Altitude in meters. Defaults to 0.
        ayanamsa (str, optional): Ayanamsa system. Defaults to "lahiri".
        true_nodes (bool, optional): Use true nodes for Rahu/Ketu. Defaults to True.
        locale (str, optional): The language for localized string names. Defaults to "en".

    Returns:
        Panchanga: A typed Panchanga object.
    """
    raw = _get_panchanga_raw(
        year,
        month,
        day,
        hour,
        minute,
        second,
        latitude,
        longitude,
        altitude,
        ayanamsa,
        true_nodes,
        locale,
    )
    return Panchanga.from_dict(raw, locale=locale)
