from dataclasses import dataclass


@dataclass(frozen=True)
class GeoLocation:
    """
    Represents the geographic location for astrological calculations.

    Attributes:
        latitude (float): Latitude of the location in degrees. Positive for North.
        longitude (float): Longitude of the location in degrees. Positive for East.
        timezone (str, optional): The timezone identifier (e.g., 'UTC', 'Asia/Kathmandu'). Defaults to 'UTC'.
        altitude (float, optional): Altitude above sea level in meters. Defaults to 0.0.
    """

    latitude: float
    longitude: float
    timezone: str = "UTC"
    altitude: float = 0.0

    def __post_init__(self):
        if not -90 <= self.latitude <= 90:
            raise ValueError(f"latitude {self.latitude} out of range [-90, 90]")
        if not -180 <= self.longitude <= 180:
            raise ValueError(f"longitude {self.longitude} out of range [-180, 180]")

        try:
            import zoneinfo

            zoneinfo.ZoneInfo(self.timezone)
        except Exception:
            raise ValueError(f"Invalid timezone: {self.timezone}")


@dataclass(frozen=True)
class JyotishTime:
    """
    Represents the exact temporal moment for a calculation.

    Attributes:
        year (int): Gregorian year.
        month (int): Gregorian month (1-12).
        day (int): Gregorian day (1-31).
        hour (int): Hour of the day (0-23).
        minute (int): Minute of the hour (0-59).
        second (int, optional): Second of the minute (0-59). Defaults to 0.
    """

    year: int
    month: int
    day: int
    hour: int
    minute: int
    second: int = 0

    def __post_init__(self):
        if not 1 <= self.month <= 12:
            raise ValueError(f"month {self.month} out of range [1, 12]")
        if not 1 <= self.day <= 31:
            raise ValueError(f"day {self.day} out of range [1, 31]")
        if not 0 <= self.hour <= 23:
            raise ValueError(f"hour {self.hour} out of range [0, 23]")
        if not 0 <= self.minute <= 59:
            raise ValueError(f"minute {self.minute} out of range [0, 59]")
        if not 0 <= self.second <= 59:
            raise ValueError(f"second {self.second} out of range [0, 59]")
