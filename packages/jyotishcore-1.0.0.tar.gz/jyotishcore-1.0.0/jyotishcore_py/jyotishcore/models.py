# mypy: ignore-errors
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# Standard Signs list
SIGNS = [
    "Aries",
    "Taurus",
    "Gemini",
    "Cancer",
    "Leo",
    "Virgo",
    "Libra",
    "Scorpio",
    "Sagittarius",
    "Capricorn",
    "Aquarius",
    "Pisces",
]

# Standard Nakshatras list
NAKSHATRAS = [
    "Ashwini",
    "Bharani",
    "Krittika",
    "Rohini",
    "Mrigashira",
    "Ardra",
    "Punarvasu",
    "Pushya",
    "Ashlesha",
    "Magha",
    "Purva Phalguni",
    "Uttara Phalguni",
    "Hasta",
    "Chitra",
    "Swati",
    "Vishakha",
    "Anuradha",
    "Jyeshtha",
    "Mula",
    "Purva Ashadha",
    "Uttara Ashadha",
    "Shravana",
    "Dhanishta",
    "Shatabhisha",
    "Purva Bhadrapada",
    "Uttara Bhadrapada",
    "Revati",
]

from .jyotishcore import get_divisional_longitude, get_divisional_sign


def get_nakshatra_info(longitude: float) -> tuple:
    """Helper to calculate Nakshatra name and pada from absolute longitude."""
    longitude = longitude % 360.0
    span = 360.0 / 27.0  # 13.333333333333334
    idx = int(longitude / span)
    if idx >= 27:
        idx = 0
    pada = int((longitude % span) / (span / 4.0)) + 1
    return NAKSHATRAS[idx], pada


class DictCompat:
    def __getitem__(self, key: str) -> Any:
        try:
            return getattr(self, key)
        except AttributeError:
            raise KeyError(key)

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def keys(self):
        return self.__dict__.keys()

    def values(self):
        return self.__dict__.values()

    def items(self):
        return self.__dict__.items()

    def __contains__(self, key: str) -> bool:
        return hasattr(self, key)


@dataclass(frozen=True)
class Tithi(DictCompat):
    index: int
    name: str
    paksha: str
    start_time_utc: str = ""
    end_time_utc: str = ""
    start_time_local: str = ""
    end_time_local: str = ""
    end_time: str = ""

    def __post_init__(self) -> None:
        if not self.end_time and self.end_time_utc:
            object.__setattr__(self, "end_time", self.end_time_utc)


@dataclass(frozen=True)
class Nakshatra(DictCompat):
    index: int
    name: str
    pada: int
    start_time_utc: str = ""
    end_time_utc: str = ""
    start_time_local: str = ""
    end_time_local: str = ""
    end_time: str = ""

    def __post_init__(self) -> None:
        if not self.end_time and self.end_time_utc:
            object.__setattr__(self, "end_time", self.end_time_utc)


@dataclass(frozen=True)
class Yoga(DictCompat):
    index: int
    name: str
    start_time_utc: str = ""
    end_time_utc: str = ""
    start_time_local: str = ""
    end_time_local: str = ""
    end_time: str = ""

    def __post_init__(self) -> None:
        if not self.end_time and self.end_time_utc:
            object.__setattr__(self, "end_time", self.end_time_utc)


@dataclass(frozen=True)
class Karana(DictCompat):
    index: int
    name: str
    start_time_utc: str = ""
    end_time_utc: str = ""
    start_time_local: str = ""
    end_time_local: str = ""
    end_time: str = ""

    def __post_init__(self) -> None:
        if not self.end_time and self.end_time_utc:
            object.__setattr__(self, "end_time", self.end_time_utc)


@dataclass(frozen=True)
class Vara(DictCompat):
    index: int
    name: str


@dataclass(frozen=True)
class PanchangaMetadata(DictCompat):
    timezone: str = "UTC"
    mode: str = "civil_day"
    local_datetime: str = ""
    utc_datetime: str = ""
    ayanamsa: str = "Lahiri"
    true_nodes: bool = True
    calculation_version: str = ""


@dataclass(frozen=True)
class Panchanga(DictCompat):
    """
    Represents the five elements of Vedic time (Panchanga).

    The Panchanga consists of Tithi (lunar day), Nakshatra (lunar mansion),
    Yoga (luni-solar combination), Karana (half lunar day), and Vara (weekday).

    Attributes:
        tithi (Tithi): The lunar day info.
        nakshatra (Nakshatra): The lunar mansion info.
        yoga (Yoga): The luni-solar combination info.
        karana (Karana): The half lunar day info.
        vara (Vara): The weekday info.
        metadata (PanchangaMetadata): Calculation parameters used.
        warnings (List[str]): Any warnings emitted during calculation.
    """

    tithi: Tithi
    nakshatra: Nakshatra
    yoga: Yoga
    karana: Karana
    vara: Vara
    metadata: PanchangaMetadata = field(default_factory=PanchangaMetadata)
    warnings: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: Dict[str, Any], locale: str = "en") -> "Panchanga":
        meta = d.get("metadata") or {}
        from .translator import get_translator

        t = get_translator(locale)

        tithi_data = dict(d["tithi"])
        tithi_data["name"] = t("tithi", tithi_data.get("name", ""))
        tithi_data["paksha"] = t("paksha", tithi_data.get("paksha", ""))

        nakshatra_data = dict(d["nakshatra"])
        nakshatra_data["name"] = t("nakshatra", nakshatra_data.get("name", ""))

        yoga_data = dict(d["yoga"])
        yoga_data["name"] = t("yoga", yoga_data.get("name", ""))

        karana_data = dict(d["karana"])
        karana_data["name"] = t("karana", karana_data.get("name", ""))

        vara_data = dict(d["vara"])
        vara_data["name"] = t("vara", vara_data.get("name", ""))

        return cls(
            tithi=Tithi(**tithi_data),
            nakshatra=Nakshatra(**nakshatra_data),
            yoga=Yoga(**yoga_data),
            karana=Karana(**karana_data),
            vara=Vara(**vara_data),
            metadata=PanchangaMetadata(**meta),
            warnings=list(d.get("warnings") or []),
        )

    @classmethod
    def from_local(
        cls,
        *,
        date: str,
        time: str,
        timezone: str,
        latitude: float,
        longitude: float,
        altitude: float = 0.0,
        ayanamsa: str = "lahiri",
        true_nodes: bool = True,
        mode: str = "civil_day",
        locale: str = "en",
    ) -> "Panchanga":
        from .jyotishcore import Panchanga as NativePanchanga

        native = NativePanchanga.from_local(
            date=date,
            time=time,
            timezone=timezone,
            latitude=latitude,
            longitude=longitude,
            altitude=altitude,
            ayanamsa=ayanamsa,
            true_nodes=true_nodes,
            mode=mode,
        )
        return cls.from_dict(native.to_dict(), locale=locale)


@dataclass(frozen=True)
class House(DictCompat):
    house: int
    cusp: float
    start_degree: float
    end_degree: float
    ruling_sign: str
    resident_planets: List[str] = field(default_factory=list)

    @property
    def sanskrit_name(self) -> str:
        return f"Bhava {self.house}"

    @property
    def lord(self) -> str:
        SIGN_LORDS = {
            "Aries": "Mars",
            "Scorpio": "Mars",
            "Taurus": "Venus",
            "Libra": "Venus",
            "Gemini": "Mercury",
            "Virgo": "Mercury",
            "Cancer": "Moon",
            "Leo": "Sun",
            "Sagittarius": "Jupiter",
            "Pisces": "Jupiter",
            "Capricorn": "Saturn",
            "Aquarius": "Saturn",
        }
        return SIGN_LORDS.get(self.ruling_sign, "")


@dataclass(frozen=True)
class Lagna(DictCompat):
    longitude: float
    sign: str
    degree_in_sign: float
    nakshatra: str
    pada: int

    @property
    def sanskrit_name(self) -> str:
        return "Lagna"


@dataclass(frozen=True)
class DivisionalPlanetPosition(DictCompat):
    planet: str
    source_longitude: float
    varga: int
    varga_sign: str
    varga_index: int
    display_longitude: float
    warnings: List[str]
    sign: str
    degree_in_sign: float
    nakshatra: str
    pada: int
    house: int
    is_vargottama: bool


class DivisionalChart(list):
    def __init__(
        self,
        varga: int,
        planets: Dict[str, DivisionalPlanetPosition],
        varga_lagna: Lagna,
    ):
        super().__init__(planets.values())
        self.varga = varga
        self._planets = planets
        self.varga_lagna = varga_lagna

    def planets(self) -> Dict[str, DivisionalPlanetPosition]:
        return self._planets

    def houses(self) -> List[House]:
        res = []
        try:
            lagna_sign_idx = SIGNS.index(self.varga_lagna.sign)
        except ValueError:
            lagna_sign_idx = 0

        for i in range(1, 13):
            sign_idx = (lagna_sign_idx + (i - 1)) % 12
            ruling_sign = SIGNS[sign_idx]
            start_degree = sign_idx * 30.0
            end_degree = (start_degree + 30.0) % 360.0

            resident = []
            for name, p in self._planets.items():
                if p.sign == ruling_sign:
                    resident.append(p.planet)

            res.append(
                House(
                    house=i,
                    cusp=start_degree,
                    start_degree=start_degree,
                    end_degree=end_degree,
                    ruling_sign=ruling_sign,
                    resident_planets=resident,
                )
            )
        return res

    def aspects(self) -> List[Dict[str, Any]]:
        res = []
        planets_list = list(self._planets.values())
        for p1 in planets_list:
            h1 = p1.house
            for p2 in planets_list:
                if p1.planet == p2.planet:
                    continue
                h2 = p2.house
                offset = (h2 - h1) % 12 + 1

                aspected = False
                aspect_type = ""

                if offset == 7:
                    aspected = True
                    aspect_type = "7th"
                elif p1.planet == "Mars" and offset in (4, 8):
                    aspected = True
                    aspect_type = f"{offset}th (Special)"
                elif p1.planet == "Jupiter" and offset in (5, 9):
                    aspected = True
                    aspect_type = f"{offset}th (Special)"
                elif p1.planet == "Saturn" and offset in (3, 10):
                    aspected = True
                    aspect_type = f"{offset}th (Special)"
                elif p1.planet in ("Rahu", "Ketu") and offset in (5, 9):
                    aspected = True
                    aspect_type = f"{offset}th (Special)"

                if aspected:
                    res.append(
                        {
                            "from_planet": p1.planet,
                            "to_planet": p2.planet,
                            "to_house": h2,
                            "aspect_type": aspect_type,
                            "strength": 1.0,
                            "is_special": "Special" in aspect_type,
                        }
                    )
        return res

    def to_svg(self, style: str = "north") -> str:
        planets_list = []
        for name, p in self._planets.items():
            planets_list.append(
                {
                    "planet": p.planet,
                    "longitude": p.display_longitude,
                    "sign": p.sign,
                    "house": p.house,
                }
            )

        asc_sign_idx = SIGNS.index(self.varga_lagna.sign)
        sub = f"D{self.varga} DIVISIONAL CHART"

        if style == "south":
            from .svg_renderer import render_south_indian

            return render_south_indian(
                f"D{self.varga} VARGA", asc_sign_idx, planets_list, subtitle=sub
            )
        elif style == "circular":
            from .svg_renderer import render_circular

            return render_circular(
                f"D{self.varga} VARGA",
                self.varga_lagna.longitude,
                planets_list,
                subtitle=sub,
            )
        else:
            from .svg_renderer import render_north_indian

            return render_north_indian(
                f"D{self.varga} VARGA", asc_sign_idx, planets_list, subtitle=sub
            )


@dataclass(frozen=True)
class Ashtakavarga(DictCompat):
    binna: Dict[str, List[int]]
    sarva: List[int]


@dataclass(frozen=True)
class PlanetPosition(DictCompat):
    planet: str
    longitude: float
    latitude: float
    speed: float
    is_retrograde: bool
    is_exalted: bool
    is_debilitated: bool
    is_own_sign: bool
    is_vargottama: bool
    is_moolatrikona: bool
    sign: Optional[str]
    nakshatra: Optional[str]
    nakshatra_index: int
    pada: int
    house: Optional[int]
    divisional_signs: Dict[int, str]
    shadbala: Optional[Dict[str, float]]

    @property
    def sanskrit_name(self) -> str:
        SANSKRIT_PLANETS = {
            "Sun": "Surya",
            "Moon": "Chandra",
            "Mars": "Mangala",
            "Mercury": "Budha",
            "Jupiter": "Guru",
            "Venus": "Shukra",
            "Saturn": "Shani",
            "Rahu": "Rahu",
            "Ketu": "Ketu",
        }
        return SANSKRIT_PLANETS.get(self.planet, self.planet)

    @property
    def sign_sanskrit(self) -> str:
        SANSKRIT_SIGNS = {
            "Aries": "Mesha",
            "Taurus": "Vrishabha",
            "Gemini": "Mithuna",
            "Cancer": "Karka",
            "Leo": "Simha",
            "Virgo": "Kanya",
            "Libra": "Tula",
            "Scorpio": "Vrishchika",
            "Sagittarius": "Dhanus",
            "Capricorn": "Makara",
            "Aquarius": "Kumbha",
            "Pisces": "Meena",
        }
        return SANSKRIT_SIGNS.get(self.sign, "") if self.sign else ""

    def is_aspecting(self, other: "PlanetPosition") -> bool:
        """Returns True if this planet aspects the other planet."""
        if not self.house or not other.house:
            return False
        if self.planet == other.planet:
            return False

        offset = (other.house - self.house) % 12 + 1
        if offset == 7:
            return True
        elif self.planet == "Mars" and offset in (4, 8):
            return True
        elif self.planet == "Jupiter" and offset in (5, 9):
            return True
        elif self.planet == "Saturn" and offset in (3, 10):
            return True
        elif self.planet in ("Rahu", "Ketu") and offset in (5, 9):
            return True
        return False

    def aspects(self, all_planets: List["PlanetPosition"]) -> List["PlanetPosition"]:
        """Returns a list of planets that this planet aspects."""
        return [p for p in all_planets if self.is_aspecting(p)]


@dataclass(frozen=True)
class YogaResult(DictCompat):
    name: str
    category: str
    description: str
    is_present: bool
    planets_involved: List[str]


class Chart:
    """
    Represents a full Vedic Astrology birth chart.

    This object encapsulates the native Rust calculation instance and provides
    a Pythonic interface for retrieving lagna, planets, houses, yogas, and divisional charts.
    """

    def __init__(self, native_chart, locale: str = "en"):
        self._inner = native_chart
        self._locale = locale
        from .translator import get_translator

        self._t = get_translator(locale)

    @classmethod
    def from_utc(cls, *args, **kwargs):
        from .jyotishcore import Chart as NativeChart

        locale = kwargs.pop("locale", "en")
        return cls(NativeChart.from_utc(*args, **kwargs), locale=locale)

    @classmethod
    def from_local(cls, *args, **kwargs):
        from .jyotishcore import Chart as NativeChart

        locale = kwargs.pop("locale", "en")
        return cls(NativeChart.from_local(*args, **kwargs), locale=locale)

    @classmethod
    def from_julian_day(cls, *args, **kwargs):
        from .jyotishcore import Chart as NativeChart

        locale = kwargs.pop("locale", "en")
        return cls(NativeChart.from_julian_day(*args, **kwargs), locale=locale)

    @classmethod
    def compute(
        cls, *args, time=None, location=None, ayanamsa_obj=None, locale="en", **kwargs
    ):
        """
        Computes a complete astrological chart.

        This can be called with legacy keyword arguments (`year`, `month`, `latitude`, etc.)
        or with the modern object-oriented models (`time` and `location`).

        Args:
            time (JyotishTime, optional): The time of the event.
            location (GeoLocation, optional): The geographic location of the event.
            ayanamsa_obj (Ayanamsa, optional): The ayanamsa mode enum.
            locale (str, optional): The localization language (e.g., 'en', 'hi', 'ne').
            **kwargs: Fallback scalar arguments (e.g. year, month, day, hour, minute, second, latitude, longitude, altitude).

        Returns:
            Chart: A fully populated Chart object.
        """
        from .constants import Ayanamsa
        from .inputs import GeoLocation, JyotishTime
        from .jyotishcore import Chart as NativeChart

        # Merge object inputs into kwargs if provided
        if time is not None and isinstance(time, JyotishTime):
            kwargs["year"] = time.year
            kwargs["month"] = time.month
            kwargs["day"] = time.day
            kwargs["hour"] = time.hour
            kwargs["minute"] = time.minute
            kwargs["second"] = time.second

        if location is not None and isinstance(location, GeoLocation):
            kwargs["latitude"] = location.latitude
            kwargs["longitude"] = location.longitude
            kwargs["altitude"] = location.altitude
            # Timezone processing will map back to local_to_utc if not UTC
            if location.timezone and location.timezone.upper() != "UTC":
                import datetime

                from .jyotishcore import local_to_utc

                y = kwargs.get("year", 0)
                m = kwargs.get("month", 1)
                d = kwargs.get("day", 1)
                hr = kwargs.get("hour", 0)
                min = kwargs.get("minute", 0)
                sec = kwargs.get("second", 0)
                utc_iso = local_to_utc(y, m, d, hr, min, sec, location.timezone)
                dt = datetime.datetime.fromisoformat(utc_iso)
                kwargs["year"] = dt.year
                kwargs["month"] = dt.month
                kwargs["day"] = dt.day
                kwargs["hour"] = dt.hour
                kwargs["minute"] = dt.minute
                kwargs["second"] = dt.second

        if ayanamsa_obj is not None and isinstance(ayanamsa_obj, Ayanamsa):
            kwargs["ayanamsa"] = ayanamsa_obj.value

        return cls(NativeChart.compute(*args, **kwargs), locale=locale)

    @classmethod
    def compute_bs(cls, *args, **kwargs):
        from .jyotishcore import Chart as NativeChart

        locale = kwargs.pop("locale", "en")
        return cls(NativeChart.compute_bs(*args, **kwargs), locale=locale)

    @classmethod
    def compute_batch(
        cls,
        inputs: List[tuple],
        ayanamsa: str = "lahiri",
        house_system: str = "equal",
        true_nodes: bool = True,
        locale: str = "en",
    ) -> List["Chart"]:
        """
        Computes multiple charts natively in Rust using data parallelism (Rayon).
        inputs must be a list of tuples: (year, month, day, hour, minute, second, lat, lon, alt)
        """
        from .jyotishcore import compute_chart_batch

        natives = compute_chart_batch(inputs, ayanamsa, house_system, true_nodes)
        return [cls(native, locale=locale) for native in natives]

    def ascendant(self) -> float:
        return self._inner.ascendant()

    @property
    def lagna(self) -> Lagna:
        asc_deg = self.ascendant()
        sign_idx = int((asc_deg % 360.0) / 30.0)
        sign = SIGNS[sign_idx]
        deg_in_sign = asc_deg % 30.0
        nak, pada = get_nakshatra_info(asc_deg)
        return Lagna(
            longitude=asc_deg,
            sign=self._t("signs", sign),
            degree_in_sign=deg_in_sign,
            nakshatra=self._t("nakshatra", nak),
            pada=pada,
        )

    def planets(self) -> Dict[str, PlanetPosition]:
        res = {}
        for name, p in self._inner.planets().items():
            res[name] = PlanetPosition(
                planet=self._t("planets", p.planet),
                longitude=p.longitude,
                latitude=p.latitude,
                speed=p.speed,
                is_retrograde=p.is_retrograde,
                is_exalted=p.is_exalted,
                is_debilitated=p.is_debilitated,
                is_own_sign=p.is_own_sign,
                is_vargottama=p.is_vargottama,
                is_moolatrikona=p.is_moolatrikona,
                sign=self._t("signs", p.sign) if p.sign else None,
                nakshatra=self._t("nakshatra", p.nakshatra) if p.nakshatra else None,
                nakshatra_index=p.nakshatra_index,
                pada=p.pada,
                house=p.house,
                divisional_signs=dict(p.divisional_signs),
                shadbala=dict(p.shadbala) if p.shadbala else None,
            )
        return res

    def houses(self) -> List[House]:
        native_houses = self._inner.houses()
        cusps = [0.0] * 13
        for h in native_houses:
            cusps[int(h["house"])] = h["cusp"]

        planets_dict = self.planets()

        res = []
        for i in range(1, 13):
            start = cusps[i]
            end = cusps[i + 1] if i < 12 else cusps[1]
            ruling = SIGNS[int((start % 360.0) / 30.0)]

            resident = []
            for name, p in planets_dict.items():
                if p.house == i:
                    resident.append(p.planet)

            res.append(
                House(
                    house=i,
                    cusp=start,
                    start_degree=start,
                    end_degree=end,
                    ruling_sign=self._t("signs", ruling),
                    resident_planets=resident,
                )
            )
        return res

    def dasha(self) -> Dict[str, Any]:
        return self._inner.dasha()

    def karakas(self) -> Dict[str, str]:
        return self._inner.karakas()

    def yogas(self) -> List[YogaResult]:
        return [
            YogaResult(
                name=self._t("yoga", y.name),
                category=self._t("yoga_category", y.category),
                description=y.description,
                is_present=y.is_present,
                planets_involved=[self._t("planets", p) for p in y.planets_involved],
            )
            for y in self._inner.yogas()
        ]

    def divisional_chart(self, varga: int) -> Optional[DivisionalChart]:
        native_varga = self._inner.divisional_chart(varga)
        if not native_varga:
            return None

        # Calculate Varga Lagna
        asc_deg = self.ascendant()
        div_asc_lon = get_divisional_longitude(asc_deg, varga)
        div_asc_sign = get_divisional_sign(asc_deg, varga)
        div_asc_deg_in_sign = div_asc_lon % 30.0
        div_asc_nak, div_asc_pada = get_nakshatra_info(div_asc_lon)
        varga_lagna = Lagna(
            longitude=div_asc_lon,
            sign=self._t("signs", div_asc_sign),
            degree_in_sign=div_asc_deg_in_sign,
            nakshatra=self._t("nakshatra", div_asc_nak),
            pada=div_asc_pada,
        )

        lagna_sign_idx = SIGNS.index(div_asc_sign)
        planets_dict = {}
        for v in native_varga:
            pname = v.planet
            div_lon = get_divisional_longitude(v.source_longitude, varga)
            div_sign = v.varga_sign
            div_deg_in_sign = div_lon % 30.0
            div_nak, div_pada = get_nakshatra_info(div_lon)

            p_sign_idx = SIGNS.index(div_sign)
            house = (p_sign_idx - lagna_sign_idx) % 12 + 1

            birth_sign = self._inner.planets()[pname.lower()].sign
            is_varg = div_sign == birth_sign

            py_p = DivisionalPlanetPosition(
                planet=self._t("planets", pname),
                source_longitude=v.source_longitude,
                varga=v.varga,
                varga_sign=self._t("signs", v.varga_sign),
                varga_index=v.varga_index,
                display_longitude=div_lon,
                warnings=list(v.warnings),
                sign=div_sign,
                degree_in_sign=div_deg_in_sign,
                nakshatra=div_nak,
                pada=div_pada,
                house=house,
                is_vargottama=is_varg,
            )
            planets_dict[pname.lower()] = py_p

        return DivisionalChart(
            varga=varga, planets=planets_dict, varga_lagna=varga_lagna
        )

    def vargas(self, varga: int) -> Optional[DivisionalChart]:
        return self.divisional_chart(varga)

    def metadata(self) -> dict:
        return self._inner.metadata()

    def settings(self) -> dict:
        return self._inner.settings()

    def warnings(self) -> List[str]:
        return self._inner.warnings()

    def explain(self) -> dict:
        return self._inner.explain()

    def ashtakavarga(self) -> Optional[Ashtakavarga]:
        native_av = self._inner.ashtakavarga()
        if not native_av:
            return None
        return Ashtakavarga(
            binna=dict(native_av.get("binna") or {}),
            sarva=list(native_av.get("sarva") or []),
        )

    def compatibility(self, other: "Chart") -> Any:
        return self._inner.compatibility(other._inner)

    def to_dict(self) -> dict:
        return self._inner.to_dict()

    def to_llm_context(self) -> dict:
        meta = self.metadata()
        asc_deg = self.ascendant()
        asc_sign = SIGNS[int(asc_deg / 30.0)]
        asc_nak, _ = get_nakshatra_info(asc_deg)

        planets = {}
        for p in self.planets().values():
            planets[p.planet] = {
                "degree": round(p.longitude, 2),
                "sign": p.sign,
                "house": p.house,
                "nakshatra": p.nakshatra,
                "retrograde": p.is_retrograde,
            }

        return {
            "datetime_utc": meta.get("utc_datetime"),
            "location": {"lat": meta.get("latitude"), "lon": meta.get("longitude")},
            "ayanamsa": meta.get("ayanamsa"),
            "ascendant": {
                "degree": round(asc_deg, 2),
                "sign": asc_sign,
                "nakshatra": asc_nak,
            },
            "planets": planets,
            "yogas": [f"{y.name} ({y.category})" for y in self.yogas()],
            "calculation_version": meta.get("calculation_version"),
        }

    def to_json(self) -> str:
        return self._inner.to_json()

    def to_svg(self, style: str = "north") -> str:
        meta = self.metadata()
        time_str = meta.get("local_datetime") or meta.get("utc_datetime") or ""
        sub = f"{time_str} | Ayanamsa: {meta.get('ayanamsa', 'Lahiri').upper()}"

        planets_list = []
        for name, p in self.planets().items():
            planets_list.append(
                {
                    "planet": p.planet,
                    "longitude": p.longitude,
                    "sign": p.sign,
                    "house": p.house,
                }
            )

        asc_sign_idx = SIGNS.index(self.lagna.sign)

        if style == "south":
            from .svg_renderer import render_south_indian

            return render_south_indian(
                "D1 RASHI", asc_sign_idx, planets_list, subtitle=sub
            )
        elif style == "circular":
            from .svg_renderer import render_circular

            return render_circular(
                "D1 RASHI", self.ascendant(), planets_list, subtitle=sub
            )
        else:
            from .svg_renderer import render_north_indian

            return render_north_indian(
                "D1 RASHI", asc_sign_idx, planets_list, subtitle=sub
            )

    def __repr__(self) -> str:
        return f"Chart(ascendant={self.ascendant():.4f}, planets={list(self.planets().keys())})"

    def __str__(self) -> str:
        return self.__repr__()
