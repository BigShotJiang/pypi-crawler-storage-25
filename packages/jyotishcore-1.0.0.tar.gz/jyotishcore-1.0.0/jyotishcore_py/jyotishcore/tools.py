# mypy: ignore-errors
import json
from typing import Any, Dict, List, Optional

try:
    from langchain_core.tools import tool
except ImportError:
    tool = None


def _calculate_chart_internal(
    year: int,
    month: int,
    day: int,
    hour: int,
    minute: int,
    second: int,
    latitude: float,
    longitude: float,
    altitude: float = 0.0,
) -> str:
    """Internal synchronous function to compute and serialize a chart."""
    from .models import Chart

    chart = Chart.compute(
        year, month, day, hour, minute, second, latitude, longitude, altitude
    )
    return json.dumps(chart.to_llm_context(), indent=2)


if tool is not None:

    @tool
    def calculate_birth_chart(
        year: int,
        month: int,
        day: int,
        hour: int,
        minute: int,
        second: int,
        latitude: float,
        longitude: float,
        altitude: float = 0.0,
    ) -> str:
        """
        Calculates a complete Vedic Astrology birth chart (Kundli) for a given date, time, and location.
        Returns a structured JSON document containing planetary longitudes, signs, houses, nakshatras, and identified yogas.
        All times must be provided in UTC.
        """
        return _calculate_chart_internal(
            year, month, day, hour, minute, second, latitude, longitude, altitude
        )

    @tool
    def check_relationship_compatibility(
        boy_year: int,
        boy_month: int,
        boy_day: int,
        boy_hour: int,
        boy_min: int,
        boy_sec: int,
        boy_lat: float,
        boy_lon: float,
        girl_year: int,
        girl_month: int,
        girl_day: int,
        girl_hour: int,
        girl_min: int,
        girl_sec: int,
        girl_lat: float,
        girl_lon: float,
    ) -> str:
        """
        Calculates Ashtakoota Milan (Vedic relationship compatibility) between two individuals based on their birth details.
        Returns a JSON document with the score out of 36 and individual Kuta points.
        All times must be provided in UTC.
        """
        from .models import Chart

        boy = Chart.compute(
            boy_year,
            boy_month,
            boy_day,
            boy_hour,
            boy_min,
            boy_sec,
            boy_lat,
            boy_lon,
            0.0,
        )
        girl = Chart.compute(
            girl_year,
            girl_month,
            girl_day,
            girl_hour,
            girl_min,
            girl_sec,
            girl_lat,
            girl_lon,
            0.0,
        )

        comp = boy.compatibility(girl)
        return json.dumps(
            {
                "total_score": comp.total_score,
                "max_score": 36.0,
                "is_compatible": comp.is_compatible,
                "breakdown": {
                    "varna": comp.varna,
                    "vasya": comp.vasya,
                    "tara": comp.tara,
                    "yoni": comp.yoni,
                    "graha_maitri": comp.graha_maitri,
                    "gana": comp.gana,
                    "bhakut": comp.bhakut,
                    "nadi": comp.nadi,
                },
            },
            indent=2,
        )


def get_langchain_tools() -> List[Any]:
    """
    Returns a list of LangChain BaseTool objects for JyotishCore.
    Requires `langchain-core` to be installed.
    """
    if tool is None:
        raise ImportError(
            "langchain-core is not installed. Install it with `pip install jyotishcore[langchain]`"
        )
    return [calculate_birth_chart, check_relationship_compatibility]
