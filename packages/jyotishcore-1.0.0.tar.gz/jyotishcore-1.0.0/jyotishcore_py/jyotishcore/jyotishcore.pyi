from __future__ import annotations

from typing import Any, Dict, List, Optional, TypedDict

from .constants import Ayanamsa
from .inputs import GeoLocation, JyotishTime

# mypy: ignore-errors

class TithiInfo(TypedDict):
    name: str
    number: int
    paksha: str
    start_time_utc: str
    end_time_utc: str
    elapsed_percent: float

class NakshatraInfo(TypedDict):
    name: str
    number: int
    pada: int
    start_time_utc: str
    end_time_utc: str
    elapsed_percent: float
    ruler: str

class YogaInfo(TypedDict):
    name: str
    number: int
    start_time_utc: str
    end_time_utc: str

class KaranaInfo(TypedDict):
    name: str
    number: int
    start_time_utc: str
    end_time_utc: str

class VaraInfo(TypedDict):
    name: str
    ruler: str

class AshtakavargaInfo(TypedDict):
    binna: Dict[str, List[int]]
    sarva: List[int]

class ChartExplanation(TypedDict):
    method: str
    julian_day: float
    ayanamsa: float
    ascendant_degree: float

class PlanetPosition:
    planet: str
    longitude: float
    latitude: float
    speed: float
    is_retrograde: bool
    is_exalted: bool
    is_debilitated: bool
    is_own_sign: bool
    is_vargottama: bool
    is_moolatrikona: bool
    sign: Optional[str]
    nakshatra: Optional[str]
    house: Optional[int]
    divisional_signs: Dict[int, str]
    shadbala: Optional[Dict[str, float]]
    def __repr__(self) -> str: ...

class VargaPosition:
    planet: str
    source_longitude: float
    varga: int
    varga_sign: str
    varga_index: int
    display_longitude: Optional[float]
    warnings: List[str]
    def __repr__(self) -> str: ...

class DashaPeriod:
    lord: str
    start: str
    end: str
    sub_periods: List[DashaPeriod]

class Chart:
    @staticmethod
    def from_utc(
        year: int,
        month: int,
        day: int,
        hour: int,
        minute: int,
        second: int,
        latitude: float,
        longitude: float,
        altitude: float = 0.0,
        ayanamsa: str = "lahiri",
        house_system: str = "equal",
        true_nodes: bool = True,
    ) -> Chart: ...
    @staticmethod
    def from_local(
        date: str,
        time: str,
        timezone: str,
        latitude: float,
        longitude: float,
        altitude: float = 0.0,
        ayanamsa: str = "lahiri",
        house_system: str = "equal",
        true_nodes: bool = True,
    ) -> Chart: ...
    @staticmethod
    def from_julian_day(
        jd_ut: float,
        latitude: float,
        longitude: float,
        altitude: float = 0.0,
        ayanamsa: str = "lahiri",
        house_system: str = "equal",
        true_nodes: bool = True,
    ) -> Chart: ...
    @staticmethod
    def compute(
        year: int = 0,
        month: int = 0,
        day: int = 0,
        hour: int = 0,
        minute: int = 0,
        second: int = 0,
        latitude: float = 0.0,
        longitude: float = 0.0,
        altitude: float = 0.0,
        ayanamsa: str = "lahiri",
        house_system: str = "equal",
        true_nodes: bool = True,
        time: Optional[JyotishTime] = None,
        location: Optional[GeoLocation] = None,
        ayanamsa_obj: Optional[Ayanamsa] = None,
        locale: str = "en",
    ) -> Chart: ...
    @staticmethod
    def compute_bs(
        bs_year: int,
        bs_month: int,
        bs_day: int,
        hour: int,
        minute: int,
        second: int,
        latitude: float,
        longitude: float,
        altitude: float = 0.0,
        ayanamsa: str = "lahiri",
        house_system: str = "equal",
        true_nodes: bool = True,
    ) -> Chart: ...
    def ascendant(self) -> float: ...
    def planets(self) -> Dict[str, PlanetPosition]: ...
    def houses(self) -> List[Dict[str, float]]: ...
    def dasha(self) -> Dict[str, List[DashaPeriod]]: ...
    def karakas(self) -> Dict[str, str]: ...
    def divisional_chart(self, varga: int) -> Optional[List[VargaPosition]]: ...
    def vargas(self, varga: int) -> Optional[List[VargaPosition]]: ...
    def metadata(self) -> dict: ...
    def settings(self) -> dict: ...
    def warnings(self) -> List[str]: ...
    def explain(self) -> ChartExplanation: ...
    def ashtakavarga(self) -> AshtakavargaInfo: ...
    def to_dict(self) -> dict: ...
    def to_json(self) -> str: ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class Panchanga:
    @staticmethod
    def from_local(
        date: str,
        time: str,
        timezone: str,
        latitude: float,
        longitude: float,
        altitude: float = 0.0,
        ayanamsa: str = "lahiri",
        true_nodes: bool = True,
        mode: str = "civil_day",
    ) -> Panchanga: ...
    def to_dict(self) -> dict: ...
    def metadata(self) -> dict: ...
    def warnings(self) -> List[str]: ...
    @property
    def tithi(self) -> TithiInfo: ...
    @property
    def nakshatra(self) -> NakshatraInfo: ...
    @property
    def yoga(self) -> YogaInfo: ...
    @property
    def karana(self) -> KaranaInfo: ...
    @property
    def vara(self) -> VaraInfo: ...

def get_panchanga(
    year: int,
    month: int,
    day: int,
    hour: int = 0,
    minute: int = 0,
    second: int = 0,
    latitude: float = 0.0,
    longitude: float = 0.0,
    altitude: float = 0.0,
    ayanamsa: str = "lahiri",
    true_nodes: bool = True,
    locale: str = "en",
) -> dict: ...
def compute_chart_bs(
    bs_year: int,
    bs_month: int,
    bs_day: int,
    hour: int,
    minute: int,
    second: int,
    latitude: float,
    longitude: float,
    altitude: float = 0.0,
    ayanamsa: str = "lahiri",
    house_system: str = "equal",
    true_nodes: bool = True,
) -> Chart: ...
def local_to_utc(
    year: int,
    month: int,
    day: int,
    hour: int,
    minute: int,
    second: int,
    tz_str: str,
) -> str: ...
def get_transits(
    from_date: str,
    to_date: str,
    ayanamsa: str = "lahiri",
    true_nodes: bool = True,
) -> list: ...
def get_divisional_longitude(longitude: float, varga: int) -> float: ...
def get_divisional_sign(longitude: float, varga: int) -> str: ...
def compute_chart_batch(
    inputs: List[tuple], ayanamsa: str, house_system: str, true_nodes: bool
) -> List["Chart"]: ...
def calc_planet_longitude(*args, **kwargs) -> float: ...
def find_time_windows(*args, **kwargs) -> Any: ...
