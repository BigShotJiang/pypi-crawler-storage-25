from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import jyotishcore


def compute_chart_local(
    year,
    month,
    day,
    hour,
    minute,
    second,
    latitude,
    longitude,
    altitude=0,
    timezone_offset_hours=0.0,
    ayanamsa="lahiri",
    house_system="equal",
    true_nodes=True,
):
    """
    Compute a chart using LOCAL birth time instead of UTC.

    Args:
        timezone_offset_hours: UTC offset in decimal hours.
            Examples: India = 5.5, Nepal = 5.75, US Eastern = -5.0, Japan = 9.0

    Example (birth in Kathmandu at 12:00 PM):
        chart = compute_chart_local(
            2024, 5, 15, 12, 0, 0,
            27.7172, 85.3240, 1350,
            timezone_offset_hours=5.75   # Nepal is UTC+5:45
        )
    """
    local_dt = datetime(
        year,
        month,
        day,
        hour,
        minute,
        second,
        tzinfo=timezone(timedelta(hours=timezone_offset_hours)),
    )
    utc_dt = local_dt.astimezone(timezone.utc)
    return jyotishcore.Chart.compute(
        utc_dt.year,
        utc_dt.month,
        utc_dt.day,
        utc_dt.hour,
        utc_dt.minute,
        utc_dt.second,
        latitude,
        longitude,
        altitude,
        ayanamsa,
        house_system,
        true_nodes,
    )


def current_dasha(chart: Any, as_of: Optional[datetime] = None) -> Dict[str, Any]:
    """
    Returns the active Vimshottari dasha periods at a given moment.

    Returns a dict with keys:
      maha_dasha    — the active major period (e.g. "Jupiter")
      antar_dasha   — the active sub-period  (e.g. "Saturn")
      pratyantar    — the active sub-sub-period (e.g. "Mercury")
      maha_end      — ISO8601 UTC end of the major period
      antar_end     — ISO8601 UTC end of the sub-period

    Example:
        chart = jyotishcore.Chart.compute(1990, 5, 15, 10, 30, 0, 28.6, 77.2, 0)
        active = current_dasha(chart)
        print(f"{active['maha_dasha']} / {active['antar_dasha']}")
    """
    from datetime import datetime, timezone

    if as_of is None:
        as_of = datetime.now(timezone.utc)
    as_of_str = as_of.isoformat()

    # Handle both object-style and dict-style access
    dasha_data = chart.dasha() if callable(chart.dasha) else chart.dasha
    vimshottari = dasha_data.get("vimshottari", [])

    for maha in vimshottari:
        if maha.start <= as_of_str <= maha.end:
            result = {"maha_dasha": maha.lord, "maha_end": maha.end}
            for antar in maha.sub_periods:
                if antar.start <= as_of_str <= antar.end:
                    result["antar_dasha"] = antar.lord
                    result["antar_end"] = antar.end
                    for pratyantar in antar.sub_periods:
                        if pratyantar.start <= as_of_str <= pratyantar.end:
                            result["pratyantar"] = pratyantar.lord
                            break
                    break
            return result
    return {}


def find_time_windows(
    base_date: str,
    window_minutes: int,
    varga: int,
    target_sign: str,
    lat: float,
    lon: float,
    alt: float = 0.0,
    ayanamsa: str = "lahiri",
    true_nodes: bool = True,
) -> List[Any]:
    """
    Find contiguous time windows where a specific ascendant condition is met.
    This iterates every second natively in Rust for extremely high performance.

    Args:
        base_date: ISO 8601 string (e.g. "1990-05-15T10:30:00Z")
        window_minutes: Total minutes to search (e.g. 30 = search 15m before and 15m after)
        varga: The divisional chart number (e.g. 9 for Navamsha)
        target_sign: The name of the sign you are looking for (e.g. "Pisces")
        lat: Latitude of birth
        lon: Longitude of birth

    Returns:
        List of tuples (start_time, end_time) representing the exact windows.
    """
    import jyotishcore.jyotishcore as native

    return native.find_time_windows(  # type: ignore[no-any-return]
        base_date,
        window_minutes,
        varga,
        target_sign,
        lat,
        lon,
        alt,
        ayanamsa,
        true_nodes,
    )
