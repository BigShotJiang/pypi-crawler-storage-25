import math
from typing import Any, Dict, List, Optional

# Harmonious planet colors (Premium HSL-tailored palette)
PLANET_COLORS = {
    "Sun": "#FFD700",  # Gold
    "Moon": "#F0F8FF",  # Silver/AliceBlue
    "Mars": "#FF4500",  # OrangeRed/Crimson
    "Mercury": "#00FA9A",  # Mint/MediumSpringGreen
    "Jupiter": "#FF8C00",  # DarkOrange/Topaz
    "Venus": "#FF69B4",  # HotPink/Rose
    "Saturn": "#1E90FF",  # DodgerBlue
    "Rahu": "#BA55D3",  # MediumOrchid
    "Ketu": "#9370DB",  # MediumPurple
    "Lagna": "#CD7F32",  # Bronze/Copper
    "Ascendant": "#CD7F32",
}

# Sign order
SIGNS = [
    "Aries",
    "Taurus",
    "Gemini",
    "Cancer",
    "Leo",
    "Virgo",
    "Libra",
    "Scorpio",
    "Sagittarius",
    "Capricorn",
    "Aquarius",
    "Pisces",
]


def get_style_header() -> str:
    """Returns the CSS styling header for all SVGs, importing modern Inter font."""
    return """<defs>
    <style type="text/css">
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&amp;display=swap');
        text {
            font-family: 'Inter', -apple-system, sans-serif;
            user-select: none;
        }
        .grid-line {
            stroke: #333333;
            stroke-width: 1.5;
            stroke-linecap: round;
        }
        .outer-border {
            stroke: #444444;
            stroke-width: 2.5;
            fill: none;
        }
        .house-number {
            font-size: 10px;
            fill: #555555;
            font-weight: 600;
        }
        .sign-number {
            font-size: 12px;
            fill: #888888;
            font-weight: 600;
        }
        .title {
            font-size: 16px;
            fill: #E0E0E0;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .subtitle {
            font-size: 10px;
            fill: #888888;
            font-weight: 400;
        }
    </style>
</defs>"""


def render_north_indian(
    title: str, asc_sign_idx: int, planets: List[Dict[str, Any]], subtitle: str = ""
) -> str:
    """Renders a beautiful North Indian diamond chart in dark mode."""
    width = 500
    height = 500

    svg = []
    svg.append(
        f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">'
    )
    svg.append(get_style_header())

    # Background
    svg.append('<rect width="100%" height="100%" fill="#121212" rx="16" />')

    # Outer frame
    svg.append(
        '<rect x="25" y="25" width="450" height="450" rx="8" class="outer-border" />'
    )

    # Diagonals
    svg.append('<line x1="25" y1="25" x2="475" y2="475" class="grid-line" />')
    svg.append('<line x1="475" y1="25" x2="25" y2="475" class="grid-line" />')

    # Diamond
    svg.append(
        '<polygon points="250,25 475,250 250,475 25,250" stroke="#333333" fill="none" stroke-width="1.5" />'
    )

    # Center points of the 12 houses (triangles/diamonds)
    house_centers = [
        (250, 140),  # House 1
        (145, 90),  # House 2
        (90, 145),  # House 3
        (140, 250),  # House 4
        (90, 355),  # House 5
        (145, 410),  # House 6
        (250, 360),  # House 7
        (355, 410),  # House 8
        (410, 355),  # House 9
        (360, 250),  # House 10
        (410, 145),  # House 11
        (355, 90),  # House 12
    ]

    # Group planets by house
    planets_by_house: Dict[int, List[Dict[str, Any]]] = {i: [] for i in range(1, 13)}
    for p in planets:
        h = p.get("house")
        if h and 1 <= h <= 12:
            planets_by_house[h].append(p)

    # Draw houses (sign numbers & planets)
    for i, (cx, cy) in enumerate(house_centers):
        house_num = i + 1
        sign_num = (asc_sign_idx + i) % 12 + 1

        svg.append(f'<g id="house-{house_num}" class="house-group">')

        # Sign number
        svg.append(
            f'<text id="sign-num-{house_num}" x="{cx}" y="{cy - 25}" class="sign-number" text-anchor="middle">{sign_num}</text>'
        )

        # House number (very subtle)
        svg.append(
            f'<text x="{cx}" y="{cy - 38}" class="house-number" text-anchor="middle">H{house_num}</text>'
        )

        # Resident planets
        h_planets = planets_by_house[house_num]

        # Stack planets vertically
        py = cy - 5
        for p_idx, p in enumerate(h_planets):
            name = p["planet"]
            short_name = name[:2]
            color = PLANET_COLORS.get(name, "#00CCFF")

            # Print planet
            svg.append(
                f'<text id="graha-{name.lower()}" x="{cx}" y="{py}" fill="{color}" font-size="13" font-weight="600" text-anchor="middle">{short_name}</text>'
            )
            py += 15

        svg.append("</g>")

    # Chart titles (rendered in bottom/top corners or floating cleanly)
    svg.append(
        f'<text x="250" y="244" class="title" text-anchor="middle">{title}</text>'
    )
    if subtitle:
        svg.append(
            f'<text x="250" y="262" class="subtitle" text-anchor="middle">{subtitle}</text>'
        )

    svg.append("</svg>")
    return "\n".join(svg)


def render_south_indian(
    title: str, asc_sign_idx: int, planets: List[Dict[str, Any]], subtitle: str = ""
) -> str:
    """Renders a beautiful South Indian square chart in dark mode."""
    width = 500
    height = 500
    box_size = width / 4

    svg = []
    svg.append(
        f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">'
    )
    svg.append(get_style_header())

    # Background
    svg.append('<rect width="100%" height="100%" fill="#121212" rx="16" />')

    # Grid boxes coordinates (4x4)
    # The 12 signs map to boxes in clockwise order starting from Pisces at (0,0)
    # 0: Pisces (0,0)
    # 1: Aries (0,1)
    # 2: Taurus (0,2)
    # 3: Gemini (0,3)
    # 4: Cancer (1,3)
    # 5: Leo (2,3)
    # 6: Virgo (3,3)
    # 7: Libra (3,2)
    # 8: Scorpio (3,1)
    # 9: Sagittarius (3,0)
    # 10: Capricorn (2,0)
    # 11: Aquarius (1,0)

    sign_boxes = [
        (0, 1),  # Aries (1)
        (0, 2),  # Taurus (2)
        (0, 3),  # Gemini (3)
        (1, 3),  # Cancer (4)
        (2, 3),  # Leo (5)
        (3, 3),  # Virgo (6)
        (3, 2),  # Libra (7)
        (3, 1),  # Scorpio (8)
        (3, 0),  # Sagittarius (9)
        (2, 0),  # Capricorn (10)
        (1, 0),  # Aquarius (11)
        (0, 0),  # Pisces (12)
    ]

    # Draw all 16 grid lines/rects
    for r in range(4):
        for c in range(4):
            # Skip middle 2x2
            if 1 <= r <= 2 and 1 <= c <= 2:
                continue
            x = c * box_size
            y = r * box_size
            svg.append(
                f'<rect x="{x}" y="{y}" width="{box_size}" height="{box_size}" stroke="#333333" fill="none" stroke-width="1.5" />'
            )

    # Draw center merged area border
    svg.append(
        f'<rect x="{box_size}" y="{box_size}" width="{box_size*2}" height="{box_size*2}" stroke="#444444" fill="none" stroke-width="2" />'
    )

    # Draw title inside the center area
    cx = width / 2
    cy = height / 2
    svg.append(
        f'<text x="{cx}" y="{cy - 10}" class="title" text-anchor="middle">{title}</text>'
    )
    if subtitle:
        svg.append(
            f'<text x="{cx}" y="{cy + 15}" class="subtitle" text-anchor="middle">{subtitle}</text>'
        )

    # Group planets by their SIGN index (0..11)
    planets_by_sign: Dict[int, List[Dict[str, Any]]] = {i: [] for i in range(12)}
    for p in planets:
        # Find which sign the planet is in
        sign_name = p.get("sign")
        if sign_name in SIGNS:
            s_idx = SIGNS.index(sign_name)
            planets_by_sign[s_idx].append(p)

    # Render each of the 12 boxes
    for s_idx, (r, c) in enumerate(sign_boxes):
        x = c * box_size
        y = r * box_size

        sign_name = SIGNS[s_idx]
        svg.append(f'<g id="sign-box-{sign_name.lower()}" class="sign-group">')

        # Sign label (top left of the box)
        sign_name_short = sign_name[:3]
        svg.append(
            f'<text id="sign-label-{sign_name.lower()}" x="{x + 8}" y="{y + 18}" fill="#555555" font-size="10" font-weight="600">{sign_name_short}</text>'
        )

        # Check if Ascendant is in this sign
        is_asc = s_idx == asc_sign_idx
        if is_asc:
            # Highlight with diagonal gold strip or corner tag
            svg.append(
                f'<polygon id="asc-highlight" points="{x},{y} {x+25},{y} {x},{y+25}" fill="#CD7F32" opacity="0.3" />'
            )
            svg.append(
                f'<text id="graha-ascendant" x="{x + box_size - 8}" y="{y + 18}" fill="#CD7F32" font-size="10" font-weight="700" text-anchor="end">ASC</text>'
            )

        # Draw planets in this box
        box_planets = planets_by_sign[s_idx]
        px = x + box_size / 2
        py = y + 42

        # Draw them staggered or listed
        for p in box_planets:
            name = p["planet"]
            short_name = name[:2]
            color = PLANET_COLORS.get(name, "#00CCFF")
            svg.append(
                f'<text id="graha-{name.lower()}" x="{px}" y="{py}" fill="{color}" font-size="13" font-weight="600" text-anchor="middle">{short_name}</text>'
            )
            py += 16

        svg.append("</g>")

    svg.append("</svg>")
    return "\n".join(svg)


def render_circular(
    title: str, asc_deg: float, planets: List[Dict[str, Any]], subtitle: str = ""
) -> str:
    """Renders an extremely premium circular wheel chart."""
    width = 500
    height = 500
    cx = 250
    cy = 250

    r_inner = 100
    r_mid = 190
    r_outer = 220

    svg = []
    svg.append(
        f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">'
    )
    svg.append(get_style_header())

    # Background
    svg.append('<rect width="100%" height="100%" fill="#121212" rx="16" />')

    # Concentric Circles
    svg.append(
        f'<circle cx="{cx}" cy="{cy}" r="{r_inner}" stroke="#333" fill="none" stroke-width="1.5" />'
    )
    svg.append(
        f'<circle cx="{cx}" cy="{cy}" r="{r_mid}" stroke="#333" fill="none" stroke-width="1.5" />'
    )
    svg.append(
        f'<circle cx="{cx}" cy="{cy}" r="{r_outer}" stroke="#444" fill="none" stroke-width="2.5" />'
    )

    # Write Title & Subtitle inside the center circle
    svg.append(
        f'<text x="{cx}" y="{cy - 8}" class="title" text-anchor="middle" font-size="14">{title}</text>'
    )
    if subtitle:
        svg.append(
            f'<text x="{cx}" y="{cy + 12}" class="subtitle" text-anchor="middle" font-size="9">{subtitle}</text>'
        )

    # Standard western wheel has Ascendant at 180 degrees (left)
    # Higher longitudes progress counterclockwise (so we ADD the difference to 180)
    # Angle theta = 180 + (planet_deg - asc_deg)
    def get_coords(deg: float, r: float) -> tuple[float, float]:
        rad = math.radians(180.0 + (deg - asc_deg))
        px = cx + r * math.cos(rad)
        py = cy - r * math.sin(rad)  # Inverted Y for SVG
        return px, py

    # Draw 12 House Sectors (equal 30-degree divisions starting from left/Ascendant)
    for i in range(12):
        house_deg = i * 30.0
        # Draw radial divider
        hx1, hy1 = get_coords(house_deg, r_inner)
        hx2, hy2 = get_coords(house_deg, r_mid)
        svg.append(
            f'<line x1="{hx1}" y1="{hy1}" x2="{hx2}" y2="{hy2}" stroke="#2d2d2d" stroke-width="1" />'
        )

        # House Number inside the sector
        mid_deg = house_deg + 15.0
        hx_num, hy_num = get_coords(mid_deg, r_inner + 15.0)
        svg.append(
            f'<text x="{hx_num}" y="{hy_num + 3}" class="house-number" text-anchor="middle">H{i+1}</text>'
        )

    # Draw 12 Signs in the Outer Ring
    for s_idx in range(12):
        sign_deg = s_idx * 30.0
        # Draw boundary line in outer ring
        # Wait, the signs are aligned to absolute zodiac degrees!
        # Absolute Aries is 0°, Taurus 30°, etc.
        # Draw absolute sign dividers
        sx1, sy1 = get_coords(sign_deg, r_mid)
        sx2, sy2 = get_coords(sign_deg, r_outer)
        svg.append(
            f'<line x1="{sx1}" y1="{sy1}" x2="{sx2}" y2="{sy2}" stroke="#333333" stroke-width="1.5" />'
        )

        # Sign label in the middle of outer ring
        smid = sign_deg + 15.0
        sx_lbl, sy_lbl = get_coords(smid, r_mid + 15)
        sign_lbl = SIGNS[s_idx][:3].upper()

        # Rotate text to align along the circle
        rot_angle = 90.0 - (180.0 + (smid - asc_deg))
        # Keep text readable (no upside down)
        if rot_angle > 90:
            rot_angle -= 180
        if rot_angle < -90:
            rot_angle += 180

        svg.append(
            f'<text x="{sx_lbl}" y="{sy_lbl + 4}" fill="#777" font-size="9" font-weight="700" text-anchor="middle" transform="rotate({rot_angle}, {sx_lbl}, {sy_lbl})">{sign_lbl}</text>'
        )

    # Draw Ascendant Arrow on the left
    ax1, ay1 = get_coords(0.0, r_mid + 30)
    ax2, ay2 = get_coords(0.0, r_mid)
    svg.append(
        f'<line x1="{ax1}" y1="{ay1}" x2="{ax2}" y2="{ay2}" stroke="#CD7F32" stroke-width="3" />'
    )
    svg.append(
        f'<text x="{ax1 - 6}" y="{ay1 + 4}" fill="#CD7F32" font-size="10" font-weight="700" text-anchor="end">ASC</text>'
    )

    # Place Planets!
    # To prevent overlapping, we group planets by proximity in angle
    # If they are within 8 degrees, we stagger their radius
    sorted_planets = sorted(planets, key=lambda x: x.get("longitude", 0.0))
    stagger_levels: List[float] = [125.0, 150.0, 172.0]

    # Basic staggering logic
    for idx, p in enumerate(sorted_planets):
        name = p["planet"]
        lon = p.get("longitude", 0.0)

        # Check proximity to neighbors
        level_idx = 0
        if idx > 0:
            prev_lon = sorted_planets[idx - 1].get("longitude", 0.0)
            if abs(lon - prev_lon) < 8.0:
                level_idx = 1
                if idx > 1:
                    prev2_lon = sorted_planets[idx - 2].get("longitude", 0.0)
                    if abs(lon - prev2_lon) < 14.0:
                        level_idx = 2

        r = stagger_levels[level_idx]
        px, py = get_coords(lon, r)

        color = PLANET_COLORS.get(name, "#00CCFF")
        short_name = name[:2]

        # Small indicator dot
        dot_x, dot_y = get_coords(lon, r_mid)
        svg.append(
            f'<circle cx="{dot_x}" cy="{dot_y}" r="2.5" fill="{color}" opacity="0.6" />'
        )
        # Line connecting dot to label
        lbl_x, lbl_y = get_coords(lon, r)
        svg.append(
            f'<line x1="{dot_x}" y1="{dot_y}" x2="{lbl_x}" y2="{lbl_y}" stroke="{color}" stroke-dasharray="2,2" stroke-width="0.8" opacity="0.4" />'
        )

        # Draw Planet Text
        deg_in_sign = lon % 30.0
        lbl_text = f"{short_name} {int(deg_in_sign)}°"
        svg.append(
            f'<text x="{px}" y="{py + 3}" fill="{color}" font-size="11" font-weight="600" text-anchor="middle">{lbl_text}</text>'
        )

    svg.append("</svg>")
    return "\n".join(svg)
