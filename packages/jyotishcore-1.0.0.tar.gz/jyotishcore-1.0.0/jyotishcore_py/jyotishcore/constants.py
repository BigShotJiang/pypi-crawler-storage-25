from enum import Enum


class Ayanamsa(str, Enum):
    LAHIRI = "lahiri"
    RAMAN = "raman"
    FAGAN_BRADLEY = "fagan_bradley"
    TROPICAL = "tropical"
    SAYANA = "tropical"  # alias for TROPICAL
    TRUE_CHITRA = "true_chitra"
    SURYASIDDHANTA = "suryasiddhanta"
    KP = "kp"
    TRUE_PUSHYA = "true_pushya"
    YUKTESHWAR = "yukteshwar"


VALID_AYANAMSAS = frozenset(a.value for a in Ayanamsa)
VALID_HOUSE_SYSTEMS = frozenset(
    [
        "placidus",
        "koch",
        "porphyry",
        "campanus",
        "equal",
        "vehlow_equal",
        "whole_sign",
        "meridian",
        "azimuthal",
        "topocentric",
        "alcabitius",
        "krusinski",
    ]
)
