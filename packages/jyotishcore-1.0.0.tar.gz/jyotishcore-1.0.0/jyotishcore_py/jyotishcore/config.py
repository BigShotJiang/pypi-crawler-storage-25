"""
Configuration management for JyotishCore API server.
Load settings from environment variables with sensible defaults.
"""

# mypy: ignore-errors

import os
from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Server Configuration
    server_host: str = "0.0.0.0"
    server_port: int = 8000
    server_log_level: str = "info"
    debug_mode: bool = False

    # API Configuration
    api_title: str = "JyotishCore API"
    api_version: str = "1.0"
    api_description: str = (
        "Vedic Astrology Engine - Birth Charts, Dasha, Panchanga, and AI Explanations"
    )

    # CORS Configuration
    cors_origins: List[str] = ["http://localhost:3000", "http://localhost:8080"]
    cors_allow_credentials: bool = True
    cors_allow_methods: List[str] = ["*"]
    cors_allow_headers: List[str] = ["*"]

    # Computation Defaults
    default_ayanamsa: str = "lahiri"
    default_house_system: str = "equal"
    default_true_nodes: bool = True

    # Cache Configuration
    enable_cache: bool = False
    cache_ttl_seconds: int = 3600
    max_cache_size: int = 1000

    # Rate Limiting
    enable_rate_limiting: bool = False
    rate_limit_requests: int = 100
    rate_limit_window_seconds: int = 60

    # Logging
    log_file: str = "jyotishcore_api.log"
    log_max_bytes: int = 10485760  # 10MB
    log_backup_count: int = 5

    # Performance Tuning
    max_workers: int = 4
    timeout_seconds: int = 30
    max_chart_computations_parallel: int = 10

    class Config:
        """Pydantic settings configuration."""

        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

    def __init__(self, **data):
        """Initialize settings, creating .env from .env.example if needed."""
        # Auto-create .env from .env.example if .env doesn't exist
        env_file = Path(".env")
        env_example = Path(".env.example")

        if not env_file.exists() and env_example.exists():
            import shutil

            shutil.copy(env_example, env_file)
            print(f"Created .env from .env.example. Please customize as needed.")

        super().__init__(**data)


# Global settings instance
settings = Settings()


def get_settings() -> Settings:
    """Get the global settings instance."""
    return settings


def print_config():
    """Print current configuration (excluding secrets)."""
    excluded_fields = {"secret_key"}
    for key, value in settings.dict().items():
        if key not in excluded_fields:
            print(f"{key}: {value}")
