import asyncio
import json
import logging
import sys
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field, field_validator

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    import jyotishcore  # our native Rust module
except ImportError:
    logger.error(
        "jyotishcore module not found. Run 'maturin develop --features python' to install."
    )
    raise ImportError("jyotishcore not installed. Cannot start server.")

# Rate limiting
import os

from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

limiter = Limiter(
    key_func=get_remote_address,
    enabled=os.getenv("TESTING") is None and "pytest" not in sys.modules,
)
app = FastAPI(
    title="JyotishCore API",
    version="1.0",
    description="Jyotish calculation API for birth charts, dashas, and panchanga. Interpretive outputs are experimental.",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)  # type: ignore

# ============ Request Models ============


class ChartRequest(BaseModel):
    """Birth chart computation request with date, time, and location."""

    year: int = Field(..., ge=1900, le=2100, description="Birth year")
    month: int = Field(..., ge=1, le=12, description="Birth month (1-12)")
    day: int = Field(..., ge=1, le=31, description="Birth day (1-31)")
    hour: int = Field(
        0,
        ge=0,
        le=23,
        description="Birth hour in UTC (not local time). Convert from local timezone first.",
    )
    minute: int = Field(0, ge=0, le=59, description="Birth minute in UTC.")
    second: int = Field(0, ge=0, le=59, description="Birth second in UTC.")
    latitude: float = Field(..., ge=-90, le=90, description="Latitude (-90 to 90)")
    longitude: float = Field(
        ..., ge=-180, le=180, description="Longitude (-180 to 180)"
    )
    altitude: float = Field(0, ge=-500, le=10000, description="Altitude in meters")
    ayanamsa: str = Field(
        "lahiri",
        description="Ayanamsa system (lahiri, raman, kp, true_chitra, true_pushya)",
    )
    house_system: str = Field(
        "equal", description="House system (equal, placidus, koch, whole_sign)"
    )
    true_nodes: bool = Field(True, description="Use true nodes vs mean nodes")
    timezone: Optional[str] = Field(
        None,
        description="IANA timezone string e.g. 'Asia/Kathmandu'. "
        "If provided, hour/minute/second are treated as local time. "
        "If omitted, UTC is assumed.",
    )

    @field_validator("latitude")
    @classmethod
    def validate_latitude(cls, v):
        if not (-90 <= v <= 90):
            raise ValueError(f"latitude {v} out of range [-90, 90]")
        return v

    @field_validator("longitude")
    @classmethod
    def validate_longitude(cls, v):
        if not (-180 <= v <= 180):
            raise ValueError(f"longitude {v} out of range [-180, 180]")
        return v

    @field_validator("ayanamsa")
    @classmethod
    def validate_ayanamsa(cls, v):
        valid = {"lahiri", "raman", "kp", "true_chitra", "true_pushya", "yukteshwar"}
        if v.lower() not in valid:
            raise ValueError(f"ayanamsa must be one of {valid}")
        return v.lower()

    @field_validator("house_system")
    @classmethod
    def validate_house_system(cls, v):
        valid = {"equal", "placidus", "koch", "whole_sign"}
        if v.lower() not in valid:
            raise ValueError(f"house_system must be one of {valid}")
        return v.lower()

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "year": 1990,
                "month": 5,
                "day": 15,
                "hour": 10,
                "minute": 30,
                "second": 0,
                "latitude": 28.6139,
                "longitude": 77.2090,
                "altitude": 0,
                "ayanamsa": "lahiri",
                "house_system": "equal",
                "true_nodes": True,
                "timezone": "Asia/Kathmandu",
            }
        }
    )


class LocalChartRequest(ChartRequest):
    """Birth chart computation request with mandatory timezone."""

    timezone: str = Field(
        ..., description="IANA timezone string e.g. 'Asia/Kathmandu'."
    )
    hour: int = Field(0, ge=0, le=23, description="Birth hour in local time.")
    minute: int = Field(0, ge=0, le=59, description="Birth minute in local time.")
    second: int = Field(0, ge=0, le=59, description="Birth second in local time.")


class CompatibilityRequest(BaseModel):
    """Compatibility request with two birth charts."""

    boy_chart: ChartRequest = Field(..., description="First person (boy) birth details")
    girl_chart: ChartRequest = Field(
        ..., description="Second person (girl) birth details"
    )


class BatchChartRequest(BaseModel):
    """Batch calculation request for true parallelism."""

    inputs: List[List[float]] = Field(
        ...,
        description="List of exact inputs: [year, month, day, hour, minute, second, lat, lon, alt]",
    )
    ayanamsa: str = Field("lahiri", description="Ayanamsa system")
    house_system: str = Field("equal", description="House system")
    true_nodes: bool = Field(True, description="Use true nodes vs mean nodes")


# ============ Response Models ============


class PlanetData(BaseModel):
    """Individual planet position."""

    name: str
    longitude: float
    latitude: float
    speed: float
    retrograde: bool


class YogaResponse(BaseModel):
    """Vedic Yoga result."""

    name: str = Field(..., description="Name of the Yoga")
    category: str = Field(..., description="Category of the Yoga")
    description: str = Field(..., description="Classical definition and description")
    is_present: bool = Field(
        ..., description="Whether the Yoga is present in the chart"
    )
    planets_involved: List[str] = Field(
        ..., description="Planets participating in this Yoga"
    )


class ChartResponse(BaseModel):
    """Complete birth chart response."""

    ascendant: float = Field(..., description="Ascendant degree")
    planets: List[Dict[str, Any]] = Field(..., description="Planet positions and data")
    navamsa: Optional[List[Dict[str, Any]]] = Field(
        None, description="D-9 divisional chart"
    )
    dashas: Dict[str, List[Dict[str, Any]]] = Field(
        ..., description="Dasha systems (Vimshottari, Yogini, etc.)"
    )
    karakas: Dict[str, str] = Field(
        ..., description="Jaimini Karakas (Atmakaraka, etc.)"
    )
    yogas: List[YogaResponse] = Field(
        default_factory=list, description="Classical Yogas identified in the chart"
    )
    warnings: List[str] = Field(
        default_factory=list, description="Calculation and safety warnings"
    )


class CompatibilityResponse(BaseModel):
    """Kuta Milan compatibility result."""

    varna: float
    vasya: float
    tara: float
    yoni: float
    graha_maitri: float
    gana: float
    bhakut: float
    nadi: float
    total_score: float
    max_score: float
    is_compatible: bool


class PanchangaResponse(BaseModel):
    """Panchanga (5-element) response."""

    tithi: str = Field(..., description="Current Tithi (lunar day)")
    tithi_ends: str = Field(..., description="UTC ISO8601 time when current tithi ends")
    nakshatra: str = Field(..., description="Current Nakshatra (lunar mansion)")
    nakshatra_ends: str = Field(
        ..., description="UTC ISO8601 time when current nakshatra ends"
    )
    yoga: str = Field(..., description="Current Yoga (auspicious combination)")
    yoga_ends: str = Field(..., description="UTC ISO8601 time when current yoga ends")
    karana: Optional[str] = Field(None, description="Current Karana (half-tithi)")
    karana_ends: Optional[str] = Field(
        None, description="UTC ISO8601 time when current karana ends"
    )
    vara: Optional[str] = Field(None, description="Day of week")


class DashaResponse(BaseModel):
    """Dasha periods response."""

    dashas: Dict[str, List[Dict[str, Any]]] = Field(
        ..., description="Dasha systems (Vimshottari, Yogini, etc.)"
    )


class ExplainResponse(BaseModel):
    """Experimental symbolic explanation response."""

    ascendant: float = Field(..., description="Ascendant degree")
    explanation_graph: Dict[str, Any] = Field(
        ..., description="Experimental symbolic knowledge graph"
    )
    warnings: List[str] = Field(default_factory=list)


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    service: str
    version: str


class ErrorResponse(BaseModel):
    """Error response."""

    error: str
    detail: str
    status_code: int


# ============ Error Handlers ============


class JyotishCoreError(Exception):
    """Base exception for JyotishCore errors."""

    def __init__(self, message: str, status_code: int = 400):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


@app.exception_handler(JyotishCoreError)
async def jyotishcore_error_handler(
    request: Request, exc: JyotishCoreError
) -> Dict[str, Any]:
    return {
        "error": "JyotishCore Error",
        "detail": exc.message,
        "status_code": exc.status_code,
    }


def convert_to_utc_if_needed(req: ChartRequest) -> tuple[int, int, int, int, int, int]:
    """Helper to convert local time to UTC if timezone is provided."""
    year, month, day, hour, minute, second = (
        req.year,
        req.month,
        req.day,
        req.hour,
        req.minute,
        req.second,
    )
    if req.timezone:
        try:
            utc_iso = jyotishcore.local_to_utc(
                year, month, day, hour, minute, second, req.timezone
            )
            from datetime import datetime

            dt_utc = datetime.fromisoformat(utc_iso)
            return (
                dt_utc.year,
                dt_utc.month,
                dt_utc.day,
                dt_utc.hour,
                dt_utc.minute,
                dt_utc.second,
            )
        except ValueError as e:
            raise JyotishCoreError(str(e), status_code=422)
    return year, month, day, hour, minute, second


# ============ Helper Functions ============


def validate_date_time(
    year: int, month: int, day: int, hour: int, minute: int, second: int
) -> None:
    """Validate date/time components."""
    try:
        from datetime import datetime

        datetime(year, month, day, hour, minute, second)
    except ValueError as e:
        raise JyotishCoreError(f"Invalid date/time: {str(e)}", status_code=400)


@app.post("/v1/compatibility", response_model=CompatibilityResponse)
@limiter.limit("5/minute")
async def get_compatibility(
    request: Request, body: CompatibilityRequest
) -> CompatibilityResponse:
    """Calculate Ashtakoota compatibility between two individuals."""
    from datetime import datetime

    try:
        boy_req = body.boy_chart
        girl_req = body.girl_chart

        # Boy
        if boy_req.timezone:
            boy_utc_iso = jyotishcore.local_to_utc(
                boy_req.year,
                boy_req.month,
                boy_req.day,
                boy_req.hour,
                boy_req.minute,
                boy_req.second,
                boy_req.timezone,
            )
            bdt = datetime.fromisoformat(boy_utc_iso.replace("Z", "+00:00"))
        else:
            bdt = datetime(
                boy_req.year,
                boy_req.month,
                boy_req.day,
                boy_req.hour,
                boy_req.minute,
                boy_req.second,
            )

        # Girl
        if girl_req.timezone:
            girl_utc_iso = jyotishcore.local_to_utc(
                girl_req.year,
                girl_req.month,
                girl_req.day,
                girl_req.hour,
                girl_req.minute,
                girl_req.second,
                girl_req.timezone,
            )
            gdt = datetime.fromisoformat(girl_utc_iso.replace("Z", "+00:00"))
        else:
            gdt = datetime(
                girl_req.year,
                girl_req.month,
                girl_req.day,
                girl_req.hour,
                girl_req.minute,
                girl_req.second,
            )

        boy_c = await asyncio.to_thread(
            jyotishcore.Chart.compute,
            bdt.year,
            bdt.month,
            bdt.day,
            bdt.hour,
            bdt.minute,
            bdt.second,
            boy_req.latitude,
            boy_req.longitude,
            boy_req.altitude,
            boy_req.ayanamsa,
            boy_req.house_system,
            boy_req.true_nodes,
        )
        girl_c = await asyncio.to_thread(
            jyotishcore.Chart.compute,
            gdt.year,
            gdt.month,
            gdt.day,
            gdt.hour,
            gdt.minute,
            gdt.second,
            girl_req.latitude,
            girl_req.longitude,
            girl_req.altitude,
            girl_req.ayanamsa,
            girl_req.house_system,
            girl_req.true_nodes,
        )

        res = await asyncio.to_thread(boy_c.compatibility, girl_c)
        return CompatibilityResponse(
            varna=res.varna,
            vasya=res.vasya,
            tara=res.tara,
            yoni=res.yoni,
            graha_maitri=res.graha_maitri,
            gana=res.gana,
            bhakut=res.bhakut,
            nadi=res.nadi,
            total_score=res.total_score,
            max_score=res.max_score,
            is_compatible=res.is_compatible,
        )
    except Exception as e:
        logger.exception("Error computing compatibility")
        raise HTTPException(status_code=500, detail=str(e))


@app.post(
    "/v1/chart/local",
    response_model=ChartResponse,
    summary="Compute Birth Chart (Local Time)",
    description="Calculate chart data using local time and IANA timezone",
)
@limiter.limit("5/minute")
async def compute_chart_local(
    req: LocalChartRequest, request: Request
) -> ChartResponse:
    """
    Compute a complete Vedic astrology birth chart using local time.
    """
    return await compute_chart(req, request)  # type: ignore[no-any-return]


@app.post(
    "/v1/chart/batch",
    response_model=List[ChartResponse],
    summary="Compute Multiple Charts Natively (Batch)",
    description="Vectorized chart computation processed in parallel by Rust Rayon.",
)
@limiter.limit("10/minute")
async def compute_chart_batch(
    req: BatchChartRequest, request: Request
) -> List[ChartResponse]:
    try:
        formatted_inputs = []
        for inp in req.inputs:
            if len(inp) != 9:
                raise HTTPException(
                    status_code=400,
                    detail="Each input must have exactly 9 elements: [y, m, d, h, min, s, lat, lon, alt]",
                )
            formatted_inputs.append(
                (
                    int(inp[0]),
                    int(inp[1]),
                    int(inp[2]),
                    int(inp[3]),
                    int(inp[4]),
                    int(inp[5]),
                    float(inp[6]),
                    float(inp[7]),
                    float(inp[8]),
                )
            )

        charts = await asyncio.to_thread(
            jyotishcore.models.Chart.compute_batch,
            formatted_inputs,
            req.ayanamsa,
            req.house_system,
            req.true_nodes,
        )

        responses = []
        for chart in charts:
            planets = [planet_to_dict(p) for p in chart.planets().values()]
            d9_raw = chart.divisional_chart(9)
            navamsa = (
                [varga_to_dict(p) for p in d9_raw.planets().values()]
                if d9_raw
                else None
            )

            dashas = {}
            for dasha_name, periods in chart.dasha().items():
                if dasha_name.lower() == "vimshottari":
                    dashas[dasha_name] = [dasha_to_dict(p) for p in periods]

            yogas_data = []
            for y in chart.yogas():
                yogas_data.append(
                    YogaResponse(
                        name=y.name,
                        category=y.category,
                        description=y.description,
                        is_present=y.is_present,
                        planets_involved=list(y.planets_involved),
                    )
                )

            responses.append(
                ChartResponse(
                    ascendant=chart.ascendant(),
                    planets=planets,
                    navamsa=navamsa,
                    dashas=dashas,
                    karakas=chart.karakas(),
                    yogas=yogas_data,
                    warnings=chart.warnings(),
                )
            )
        return responses
    except Exception as e:
        logger.exception("Error computing batch")
        raise HTTPException(status_code=500, detail=str(e))


def validate_location(latitude: float, longitude: float, altitude: float) -> None:
    """Validate geographic coordinates."""
    if not (-90 <= latitude <= 90):
        raise JyotishCoreError(
            f"Invalid latitude: {latitude} (must be -90 to 90)", status_code=400
        )
    if not (-180 <= longitude <= 180):
        raise JyotishCoreError(
            f"Invalid longitude: {longitude} (must be -180 to 180)", status_code=400
        )
    if not (-500 <= altitude <= 10000):
        raise JyotishCoreError(
            f"Invalid altitude: {altitude} (must be -500 to 10000 meters)",
            status_code=400,
        )


def planet_to_dict(p: Any) -> Dict[str, Any]:
    """Convert PyPlanetPosition to a dictionary."""
    return {
        "name": p.planet,
        "longitude": p.longitude,
        "latitude": p.latitude,
        "speed": p.speed,
        "retrograde": p.is_retrograde,
        "sign": p.sign,
        "nakshatra": p.nakshatra,
        "house": p.house,
    }


def varga_to_dict(p: Any) -> Dict[str, Any]:
    """Convert PyVargaPosition to a dictionary."""
    return {
        "name": getattr(p, "planet", None),
        "source_longitude": getattr(p, "source_longitude", None),
        "varga": getattr(p, "varga", None),
        "varga_sign": getattr(p, "varga_sign", None),
        "varga_index": getattr(p, "varga_index", None),
        "display_longitude": getattr(p, "display_longitude", None),
        "warnings": getattr(p, "warnings", []),
        "sign": getattr(p, "sign", None),
        "degree_in_sign": getattr(p, "degree_in_sign", None),
        "nakshatra": getattr(p, "nakshatra", None),
        "pada": getattr(p, "pada", None),
        "house": getattr(p, "house", None),
        "is_vargottama": getattr(p, "is_vargottama", False),
    }


def field_value(obj: Any, name: str, default: Any = None) -> Any:
    """Read a field from either a typed model or a dict."""
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def dasha_to_dict(d: Any) -> Dict[str, Any]:
    """Convert PyDashaPeriod to a dictionary."""
    return {
        "lord": d.lord,
        "start": d.start,
        "end": d.end,
        "sub_periods": [dasha_to_dict(sp) for sp in d.sub_periods],
    }


# ============ API Endpoints ============


@app.post(
    "/v1/chart",
    response_model=ChartResponse,
    summary="Compute Birth Chart",
    description="Calculate chart data with planets, houses, divisional charts, and dasha periods",
)
@limiter.limit("5/minute")
async def compute_chart(req: ChartRequest, request: Request) -> ChartResponse:
    """
    Compute a complete Vedic astrology birth chart.

    Returns planet positions, houses, divisional charts (Navamsa), and dasha periods.
    """
    try:
        year, month, day, hour, minute, second = convert_to_utc_if_needed(req)
        validate_date_time(year, month, day, hour, minute, second)
        validate_location(req.latitude, req.longitude, req.altitude)

        logger.info(
            f"Computing chart for {year}-{month}-{day} {hour}:{minute}:{second}"
        )

        chart = await asyncio.to_thread(
            jyotishcore.Chart.compute,
            year=year,
            month=month,
            day=day,
            hour=hour,
            minute=minute,
            second=second,
            latitude=req.latitude,
            longitude=req.longitude,
            altitude=req.altitude,
            ayanamsa=req.ayanamsa,
            house_system=req.house_system,
            true_nodes=req.true_nodes,
        )

        # Convert objects to dicts for JSON response
        planets = [planet_to_dict(p) for p in chart.planets().values()]
        d9_raw = chart.divisional_chart(9)
        navamsa = (
            [varga_to_dict(p) for p in d9_raw.planets().values()] if d9_raw else None
        )

        # Convert dasha periods to dicts
        dashas = {}
        for dasha_name, periods in chart.dasha().items():
            if dasha_name.lower() == "vimshottari":
                dashas[dasha_name] = [dasha_to_dict(p) for p in periods]

        # Convert yogas
        yogas = []
        for y in chart.yogas():
            yogas.append(
                YogaResponse(
                    name=y.name,
                    category=y.category,
                    description=y.description,
                    is_present=y.is_present,
                    planets_involved=y.planets_involved,
                )
            )

        return ChartResponse(
            ascendant=chart.ascendant(),
            planets=planets,
            navamsa=navamsa,
            dashas=dashas,
            karakas=chart.karakas(),
            yogas=yogas,
            warnings=[
                "Chara, Yogini, Ashtakavarga, Shadbala, and interpretive outputs are experimental and are not included in the default stable API.",
                "This library provides calculations, not life decisions.",
            ],
        )
    except JyotishCoreError:
        raise
    except Exception as e:
        logger.exception(f"Error computing chart: {e}")
        raise HTTPException(
            status_code=500, detail=f"Chart computation failed: {str(e)}"
        )


@app.post(
    "/v1/panchanga",
    response_model=PanchangaResponse,
    summary="Get Panchanga",
    description="Calculate Panchanga (5 elements): Tithi, Nakshatra, Yoga, Karana, Vara",
)
@limiter.limit("10/minute")
async def get_panchanga(req: ChartRequest, request: Request) -> PanchangaResponse:
    """
    Get the Panchanga (5 elements) for a specific date, time, and location.

    Panchanga includes: Tithi, Nakshatra, Yoga, Karana, and Vara (day of week).
    """
    try:
        year, month, day, hour, minute, second = convert_to_utc_if_needed(req)
        validate_date_time(year, month, day, hour, minute, second)
        validate_location(req.latitude, req.longitude, req.altitude)

        logger.info(f"Computing panchanga for {year}-{month}-{day}")

        data = await asyncio.to_thread(
            jyotishcore.get_panchanga,
            year=year,
            month=month,
            day=day,
            hour=hour,
            minute=minute,
            second=second,
            latitude=req.latitude,
            longitude=req.longitude,
            altitude=req.altitude,
            ayanamsa=req.ayanamsa,
            true_nodes=req.true_nodes,
        )

        return PanchangaResponse(
            tithi=field_value(data.tithi, "name"),
            tithi_ends=field_value(data.tithi, "end_time_utc")
            or field_value(data.tithi, "end_time"),
            nakshatra=field_value(data.nakshatra, "name"),
            nakshatra_ends=field_value(data.nakshatra, "end_time_utc")
            or field_value(data.nakshatra, "end_time"),
            yoga=field_value(data.yoga, "name"),
            yoga_ends=field_value(data.yoga, "end_time_utc")
            or field_value(data.yoga, "end_time"),
            karana=field_value(data.karana, "name"),
            karana_ends=field_value(data.karana, "end_time_utc")
            or field_value(data.karana, "end_time"),
            vara=field_value(data.vara, "name"),
        )
    except JyotishCoreError:
        raise
    except Exception as e:
        logger.exception(f"Error computing panchanga: {e}")
        raise HTTPException(
            status_code=500, detail=f"Panchanga computation failed: {str(e)}"
        )


@app.post(
    "/v1/dasha",
    response_model=DashaResponse,
    summary="Get Dasha Periods",
    description="Calculate Vimshottari Dasha periods for a birth chart",
)
async def get_dasha(req: ChartRequest) -> DashaResponse:
    """
    Compute Vimshottari Dasha (planetary periods) for a birth chart.

    Returns the sequence of major and sub-period lords with dates.
    """
    try:
        year, month, day, hour, minute, second = convert_to_utc_if_needed(req)
        validate_date_time(year, month, day, hour, minute, second)
        validate_location(req.latitude, req.longitude, req.altitude)

        logger.info(f"Computing dasha for {year}-{month}-{day}")

        chart = jyotishcore.Chart.compute(
            year=year,
            month=month,
            day=day,
            hour=hour,
            minute=minute,
            second=second,
            latitude=req.latitude,
            longitude=req.longitude,
            altitude=req.altitude,
            ayanamsa=req.ayanamsa,
            house_system=req.house_system,
            true_nodes=req.true_nodes,
        )

        dashas = {}
        for dasha_name, periods in chart.dasha().items():
            dashas[dasha_name] = [dasha_to_dict(p) for p in periods]

        return DashaResponse(dashas=dashas)
    except JyotishCoreError:
        raise
    except Exception as e:
        logger.exception(f"Error computing dasha: {e}")
        raise HTTPException(
            status_code=500, detail=f"Dasha computation failed: {str(e)}"
        )


@app.post(
    "/v1/explain",
    response_model=ExplainResponse,
    summary="Get Experimental Explanation",
    description="Get experimental symbolic interpretation of a birth chart",
)
async def get_explanation(req: ChartRequest) -> ExplainResponse:
    """
    Get an experimental symbolic interpretation of a birth chart.

    Returns a knowledge graph with reasoning about character, career, relationships, and life events.
    """
    try:
        year, month, day, hour, minute, second = convert_to_utc_if_needed(req)
        validate_date_time(year, month, day, hour, minute, second)
        validate_location(req.latitude, req.longitude, req.altitude)

        logger.info(f"Computing explanation for {year}-{month}-{day}")

        chart = jyotishcore.Chart.compute(
            year=year,
            month=month,
            day=day,
            hour=hour,
            minute=minute,
            second=second,
            latitude=req.latitude,
            longitude=req.longitude,
            altitude=req.altitude,
            ayanamsa=req.ayanamsa,
            house_system=req.house_system,
            true_nodes=req.true_nodes,
        )

        return ExplainResponse(
            ascendant=chart.ascendant(),
            explanation_graph=chart.explain(),
            warnings=[
                "Interpretive outputs are symbolic and experimental; do not use for medical, legal, financial, mental-health, marriage, or other life decisions."
            ],
        )
    except JyotishCoreError:
        raise
    except Exception as e:
        logger.exception(f"Error generating explanation: {e}")
        raise HTTPException(
            status_code=500, detail=f"Explanation generation failed: {str(e)}"
        )


@app.get(
    "/health",
    response_model=HealthResponse,
    summary="Health Check",
    description="Check if the API is running and healthy",
)
async def health_check() -> HealthResponse:
    """
    Health check endpoint.

    Returns the service status and version.
    """
    return HealthResponse(status="healthy", service="JyotishCore API", version="1.0")


@app.get(
    "/", summary="API Root", description="JyotishCore API information and documentation"
)
async def root():
    """Root endpoint with API information."""
    return {
        "name": "JyotishCore API",
        "version": "1.0",
        "description": "Jyotish calculation API. Experimental interpretation endpoints are separated from core calculations.",
        "documentation": "/docs",
        "endpoints": {
            "chart": "/v1/chart",
            "panchanga": "/v1/panchanga",
            "dasha": "/v1/dasha",
            "explain": "/v1/explain",
            "health": "/health",
        },
    }


@app.get(
    "/v1/transits",
    summary="Get Planetary Transits",
    description="Find sign ingress events for planets within a date range",
)
async def get_transits(
    from_date: str,
    to_date: str,
    ayanamsa: str = "lahiri",
    true_nodes: bool = True,
) -> Dict[str, Any]:
    """
    Get planetary sign ingress events between two dates.
    Dates should be ISO8601 strings.
    """
    try:
        events = jyotishcore.get_transits(
            from_date=from_date,
            to_date=to_date,
            ayanamsa=ayanamsa,
            true_nodes=true_nodes,
        )
        return {"transits": events}
    except Exception as e:
        logger.exception(f"Error fetching transits: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
