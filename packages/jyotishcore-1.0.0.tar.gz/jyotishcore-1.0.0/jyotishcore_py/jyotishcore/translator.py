import json
import os
from typing import Any, Callable, Dict

_locales_cache: Dict[str, Any] = {}


def get_translator(locale: str = "en") -> Callable[[str, str], str]:
    """
    Returns a translation function for the given locale.
    """
    if locale not in _locales_cache:
        dir_path = os.path.dirname(os.path.realpath(__file__))
        file_path = os.path.join(dir_path, "locales", f"{locale}.json")
        if not os.path.exists(file_path):
            import warnings

            warnings.warn(
                f"Locale '{locale}' not found, falling back to 'en'. "
                f"Available: en, hi, ne",
                UserWarning,
                stacklevel=2,
            )
            file_path = os.path.join(dir_path, "locales", "en.json")

        with open(file_path, "r", encoding="utf-8") as f:
            _locales_cache[locale] = json.load(f)

    mapping = _locales_cache[locale]

    def translate(category: str, key: str) -> str:
        if not key:
            return key
        cat_map = mapping.get(category, {})
        # try to translate exactly, or capitalize first
        if key in cat_map:
            return str(cat_map[key])
        cap_key = key.capitalize()
        if cap_key in cat_map:
            return str(cat_map[cap_key])
        return key

    return translate
