use crate::calendars::bikram_sambat::BsDate;
use crate::data::types::*;
use crate::ephemeris::service::Ephemeris;
use crate::error::JyotishError;

pub fn calculate_chart_bs(
    bs_date: BsDate,
    time: chrono::NaiveTime,
    location: GeoPosition,
    ayanamsa: AyanamsaMode,
    house_system: HouseSystem,
    true_nodes: bool,
) -> Result<Chart, JyotishError> {
    let ad_date = bs_date.to_gregorian().ok_or(JyotishError::DateTimeError)?;
    let dt = ad_date.and_time(time).and_utc();
    calculate_chart(dt, location, ayanamsa, house_system, true_nodes)
}

pub fn calculate_chart(
    datetime: chrono::DateTime<chrono::Utc>,
    location: GeoPosition,
    ayanamsa: AyanamsaMode,
    house_system: HouseSystem,
    true_nodes: bool,
) -> Result<Chart, JyotishError> {
    validate_location(&location)?;
    let ephe = Ephemeris::new(ayanamsa, true_nodes);
    let jd = ephe.julian_day(&datetime);

    let ascendant = ephe.get_ascendant(jd, &location)?;
    let houses = ephe.get_houses(jd, &location, house_system)?;

    let planet_list = vec![
        Planet::Sun,
        Planet::Moon,
        Planet::Mars,
        Planet::Mercury,
        Planet::Jupiter,
        Planet::Venus,
        Planet::Saturn,
        Planet::Rahu,
        Planet::Ketu,
    ];

    let mut planets: Vec<PlanetPosition> = Vec::new();

    for planet in planet_list {
        let mut pos = ephe.calc_ut(jd, planet)?;
        pos.sign = Some(crate::zodiac::sign_from_longitude(pos.longitude));
        pos.nakshatra = Some(crate::zodiac::nakshatra_from_longitude(pos.longitude));

        // Calculate Divisional Signs (Planet-centric)
        let mut div_signs = std::collections::HashMap::new();
        for &varga in &[2, 3, 4, 7, 9, 10, 12, 16, 20, 24, 27, 30, 40, 45, 60] {
            div_signs.insert(
                varga,
                crate::charts::divisional::divisional_sign(pos.longitude, varga),
            );
        }
        pos.divisional_signs = div_signs;

        // Calculate Dignities
        let dignities = compute_dignities(pos.planet, pos.sign.unwrap(), pos.longitude);
        pos.is_exalted = dignities.is_exalted;
        pos.is_debilitated = dignities.is_debilitated;
        pos.is_own_sign = dignities.is_own_sign;
        pos.is_moolatrikona = dignities.is_moolatrikona;
        pos.is_vargottama = pos.sign == pos.divisional_signs.get(&9).copied();

        // Assign house
        pos.house = Some(assign_house(pos.longitude, ascendant, &houses));
        planets.push(pos);
    }

    // Divisional charts (Varga-centric; display_longitude is for drawing only)
    let vargas = [2, 3, 4, 7, 9, 10, 12, 16, 20, 24, 27, 30, 40, 45, 60];
    let mut divisional_charts = std::collections::HashMap::new();
    for &varga in &vargas {
        let div_planets: Vec<VargaPosition> = planets
            .iter()
            .map(|p| {
                let div_sign = crate::charts::divisional::divisional_sign(p.longitude, varga);
                let varga_index = crate::charts::divisional::divisional_index(p.longitude, varga);
                let display_longitude = Some(div_sign as u32 as f64 * 30.0 - 15.0);
                let mut warnings = Vec::new();
                if varga == 60 {
                    warnings.push(
                        "D60 (Shashtiamsa) is highly sensitive to birth-time accuracy.".into(),
                    );
                }
                VargaPosition {
                    planet: p.planet,
                    source_longitude: p.longitude,
                    varga,
                    varga_sign: div_sign,
                    varga_index,
                    display_longitude,
                    warnings,
                }
            })
            .collect();
        divisional_charts.insert(varga, div_planets);
    }

    // Calculate Karakas (7-karaka system: Sun-Saturn)
    let mut karaka_planets: Vec<&PlanetPosition> = planets
        .iter()
        .filter(|p| !matches!(p.planet, Planet::Rahu | Planet::Ketu))
        .collect();

    // Sort by degree within sign (descending)
    karaka_planets.sort_by(|a, b| {
        let deg_a = a.longitude % 30.0;
        let deg_b = b.longitude % 30.0;
        deg_b
            .partial_cmp(&deg_a)
            .unwrap_or(std::cmp::Ordering::Equal)
    });

    let mut karakas = std::collections::HashMap::new();
    let karaka_types = [
        Karaka::Atmakaraka,
        Karaka::Amatyakaraka,
        Karaka::Bhratrikaraka,
        Karaka::Matrikaraka,
        Karaka::Putrakaraka,
        Karaka::Jnatikaraka,
        Karaka::Darakaraka,
    ];

    for (i, p) in karaka_planets.iter().enumerate().take(7) {
        karakas.insert(p.planet, karaka_types[i]);
    }

    let mut chart = Chart {
        datetime,
        location: location.clone(),
        ayanamsa,
        planets,
        ascendant,
        houses,
        dasha: std::collections::HashMap::new(),
        divisional_charts,
        karakas,
        aspects: Vec::new(),
        ashtakavarga: None,
        yogas: Vec::new(),
        metadata: CalculationMetadata {
            input_mode: "utc".to_string(),
            utc_datetime: datetime.to_rfc3339(),
            timezone: Some("UTC".to_string()),
            latitude: location.latitude,
            longitude: location.longitude,
            altitude: location.altitude,
            ayanamsa: format!("{:?}", ayanamsa),
            house_system: format!("{:?}", house_system),
            true_nodes,
            ephemeris: "Swiss Ephemeris".to_string(),
            longitude_type: "sidereal".to_string(),
            calculation_version: env!("CARGO_PKG_VERSION").to_string(),
        },
        warnings: vec![
            "D60 and other high divisional charts (D27, D40, D45) require highly accurate birth time (within 1–2 minutes).".to_string(),
            "Kala Bala (Shadbala sub-component) implements Nathonnatha, Hora, and Paksha Bala; Tribhaga/Masa/Abda use simplified values.".to_string(),
            "Chara and Yogini Dasha systems are experimental — verify results against a classical reference before use.".to_string(),
            "This software provides calculations only. All astrological interpretations require a qualified astrologer.".to_string(),
        ],
    };

    // Calculate Aspects
    chart.aspects = crate::calc::aspects::compute_aspects(&chart);

    // Ashtakavarga: Bhinnashtakavarga + Sarvashtakavarga per Brihat Parashara Hora Shastra.
    // Tables are sourced from classical texts. Lagna is treated as house 1.
    chart.ashtakavarga = Some(crate::calc::ashtakavarga::compute_ashtakavarga(&chart));

    // Shadbala: 6-component planetary strength system.
    // Kala Bala implements Nathonnatha + Hora + Paksha Bala sub-components.
    // Tribhaga, Masa, and Abda Bala use simplified values (see shadbala.rs comments).
    // Drik Bala is computed from aspect relationships.
    crate::strength::shadbala::compute_all_shadbala(&mut chart);

    // Yoga identification: classical planetary combinations from BPHS and Jaimini Sutras.
    // Only yogas with unambiguous classical definitions and cited sources are included.
    chart.yogas = crate::charts::yoga_engine::identify_yogas(&chart);

    // Calculate Dashas
    chart.dasha = crate::dasha::compute_all_dashas(&chart);

    Ok(chart)
}

pub fn validate_location(location: &GeoPosition) -> Result<(), JyotishError> {
    if !(-90.0..=90.0).contains(&location.latitude) {
        return Err(JyotishError::InvalidParameter(format!(
            "Invalid latitude {}: expected -90..90",
            location.latitude
        )));
    }
    if !(-180.0..=180.0).contains(&location.longitude) {
        return Err(JyotishError::InvalidParameter(format!(
            "Invalid longitude {}: expected -180..180",
            location.longitude
        )));
    }
    if !(-500.0..=10000.0).contains(&location.altitude) {
        return Err(JyotishError::InvalidParameter(format!(
            "Invalid altitude {}: expected -500..10000 meters",
            location.altitude
        )));
    }
    Ok(())
}

fn assign_house(lon: f64, _asc: f64, houses: &[HouseCusp]) -> u8 {
    for i in 0..12 {
        let cusp_current = houses[i].cusp;
        let cusp_next = houses[(i + 1) % 12].cusp;

        if cusp_next > cusp_current {
            if lon >= cusp_current && lon < cusp_next {
                return (i + 1) as u8;
            }
        } else {
            // Cusp wraps around 360/0
            if lon >= cusp_current || lon < cusp_next {
                return (i + 1) as u8;
            }
        }
    }
    1
}

pub struct PlanetDignities {
    pub is_exalted: bool,
    pub is_debilitated: bool,
    pub is_own_sign: bool,
    pub is_moolatrikona: bool,
}

pub fn compute_dignities(planet: Planet, sign: Sign, longitude: f64) -> PlanetDignities {
    let is_exalted = match planet {
        Planet::Sun => sign == Sign::Aries,
        Planet::Moon => sign == Sign::Taurus,
        Planet::Mars => sign == Sign::Capricorn,
        Planet::Mercury => sign == Sign::Virgo,
        Planet::Jupiter => sign == Sign::Cancer,
        Planet::Venus => sign == Sign::Pisces,
        Planet::Saturn => sign == Sign::Libra,
        _ => false,
    };
    let is_debilitated = match planet {
        Planet::Sun => sign == Sign::Libra,
        Planet::Moon => sign == Sign::Scorpio,
        Planet::Mars => sign == Sign::Cancer,
        Planet::Mercury => sign == Sign::Pisces,
        Planet::Jupiter => sign == Sign::Capricorn,
        Planet::Venus => sign == Sign::Virgo,
        Planet::Saturn => sign == Sign::Aries,
        _ => false,
    };
    let is_own_sign = match sign {
        Sign::Aries | Sign::Scorpio => planet == Planet::Mars,
        Sign::Taurus | Sign::Libra => planet == Planet::Venus,
        Sign::Gemini | Sign::Virgo => planet == Planet::Mercury,
        Sign::Cancer => planet == Planet::Moon,
        Sign::Leo => planet == Planet::Sun,
        Sign::Sagittarius | Sign::Pisces => planet == Planet::Jupiter,
        Sign::Capricorn | Sign::Aquarius => planet == Planet::Saturn,
    };
    let deg_in_sign = longitude % 30.0;
    let is_moolatrikona =
        crate::data::constants::MOOLATRIKONA_RANGES
            .iter()
            .any(|(p, s, start, end)| {
                *p == planet && *s == sign && deg_in_sign >= *start && deg_in_sign < *end
            });

    PlanetDignities {
        is_exalted,
        is_debilitated,
        is_own_sign,
        is_moolatrikona,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_moolatrikona_ranges() {
        // Sun in Leo: 0-20 deg is Moolatrikona
        // 130.0 long = 10.0 deg in Leo (5th sign)
        let sun_10_leo = PlanetPosition {
            planet: Planet::Sun,
            longitude: 130.0,
            sign: Some(Sign::Leo),
            ..Default::default()
        };

        let is_mt = |pos: &PlanetPosition| {
            let deg_in_sign = pos.longitude % 30.0;
            let sign = pos.sign.unwrap();
            crate::data::constants::MOOLATRIKONA_RANGES
                .iter()
                .any(|(p, s, start, end)| {
                    *p == pos.planet && *s == sign && deg_in_sign >= *start && deg_in_sign < *end
                })
        };

        assert!(is_mt(&sun_10_leo));

        let sun_25_leo = PlanetPosition {
            planet: Planet::Sun,
            longitude: 145.0,
            sign: Some(Sign::Leo),
            ..Default::default()
        };
        assert!(!is_mt(&sun_25_leo));

        // Mercury in Virgo: 16-20 deg is Moolatrikona
        let merc_17_virgo = PlanetPosition {
            planet: Planet::Mercury,
            longitude: 167.0,
            sign: Some(Sign::Virgo),
            ..Default::default()
        };
        assert!(is_mt(&merc_17_virgo));

        let merc_25_virgo = PlanetPosition {
            planet: Planet::Mercury,
            longitude: 175.0,
            sign: Some(Sign::Virgo),
            ..Default::default()
        };
        assert!(!is_mt(&merc_25_virgo));
    }

    #[test]
    fn test_divisional_dignities() {
        // Sun at 1deg Aries (D1) -> Exalted
        // In D9 (Navamsa), 1deg Aries is also Aries -> Exalted
        let pos = PlanetPosition {
            planet: Planet::Sun,
            longitude: 1.0,
            sign: Some(Sign::Aries),
            ..Default::default()
        };
        let d1_dignity = compute_dignities(pos.planet, pos.sign.unwrap(), pos.longitude);
        assert!(d1_dignity.is_exalted);

        let d9_sign = crate::charts::divisional::divisional_sign(pos.longitude, 9);
        assert_eq!(d9_sign, Sign::Aries);
        let d9_long = d9_sign as u32 as f64 * 30.0 - 15.0;
        let d9_dignity = compute_dignities(pos.planet, d9_sign, d9_long);
        assert!(d9_dignity.is_exalted);
    }
}
