use crate::data::types::{Ashtakavarga, Chart, Planet};
use std::collections::HashMap;

pub fn compute_ashtakavarga(chart: &Chart) -> Ashtakavarga {
    let mut binna = HashMap::new();
    let mut sarva = [0u8; 12];

    let planets = [
        Planet::Sun,
        Planet::Moon,
        Planet::Mars,
        Planet::Mercury,
        Planet::Jupiter,
        Planet::Venus,
        Planet::Saturn,
    ];

    // Helper to get house of a source
    let get_house = |p: Planet| {
        chart
            .planets
            .iter()
            .find(|pos| pos.planet == p)
            .and_then(|pos| pos.house)
            .unwrap_or(1)
    };

    let asc_house = 1; // Relative to houses[0] which is house 1

    for &target_planet in &planets {
        let mut p_points = [0u8; 12];
        let rules = get_rules(target_planet);

        for (source, points) in rules {
            let source_house = if source == "Asc" {
                asc_house
            } else {
                let p_source = match source {
                    "Sun" => Planet::Sun,
                    "Moon" => Planet::Moon,
                    "Mars" => Planet::Mars,
                    "Merc" => Planet::Mercury,
                    "Jup" => Planet::Jupiter,
                    "Ven" => Planet::Venus,
                    "Sat" => Planet::Saturn,
                    _ => Planet::Sun,
                };
                get_house(p_source)
            };

            for &relative_house in points {
                let target_house = (source_house as i32 + relative_house as i32 - 2) % 12 + 1;
                p_points[target_house as usize - 1] += 1;
            }
        }

        for i in 0..12 {
            sarva[i] += p_points[i];
        }
        binna.insert(format!("{:?}", target_planet).to_lowercase(), p_points);
    }

    Ashtakavarga { binna, sarva }
}

fn get_rules(planet: Planet) -> Vec<(&'static str, &'static [u8])> {
    match planet {
        Planet::Sun => vec![
            ("Sun", &[1, 2, 4, 7, 8, 9, 10, 11]),
            ("Moon", &[3, 6, 10, 11]),
            ("Mars", &[1, 2, 4, 7, 8, 9, 10, 11]),
            ("Merc", &[3, 5, 6, 9, 10, 11, 12]),
            ("Jup", &[5, 6, 9, 11]),
            ("Ven", &[6, 7, 12]),
            ("Sat", &[1, 2, 4, 7, 8, 9, 10, 11]),
            ("Asc", &[3, 4, 6, 10, 11, 12]),
        ],
        Planet::Moon => vec![
            ("Sun", &[3, 6, 7, 8, 10, 11]),
            ("Moon", &[1, 3, 6, 7, 10, 11]),
            ("Mars", &[2, 3, 5, 6, 9, 10, 11]),
            ("Merc", &[1, 3, 4, 5, 7, 8, 10, 11]),
            ("Jup", &[1, 4, 7, 8, 10, 11, 12]),
            ("Ven", &[3, 4, 5, 7, 9, 10, 11]),
            ("Sat", &[3, 5, 6, 11]),
            ("Asc", &[3, 6, 10, 11]),
        ],
        Planet::Mars => vec![
            ("Sun", &[3, 5, 6, 10, 11]),
            ("Moon", &[3, 6, 11]),
            ("Mars", &[1, 2, 4, 7, 8, 10, 11]),
            ("Merc", &[3, 5, 6, 11]),
            ("Jup", &[6, 10, 11, 12]),
            ("Ven", &[6, 8, 11, 12]),
            ("Sat", &[1, 4, 7, 8, 9, 10, 11]),
            ("Asc", &[1, 3, 6, 10, 11]),
        ],
        Planet::Mercury => vec![
            ("Sun", &[5, 6, 9, 11, 12]),
            ("Moon", &[2, 4, 6, 8, 10, 11]),
            ("Mars", &[1, 2, 4, 7, 8, 9, 10, 11]),
            ("Merc", &[1, 3, 5, 6, 9, 10, 11, 12]),
            ("Jup", &[6, 8, 11, 12]),
            ("Ven", &[1, 2, 3, 4, 5, 8, 9, 11]),
            ("Sat", &[1, 2, 4, 7, 8, 9, 10, 11]),
            ("Asc", &[1, 2, 4, 6, 8, 10, 11]),
        ],
        Planet::Jupiter => vec![
            ("Sun", &[1, 2, 3, 4, 7, 8, 9, 10, 11]),
            ("Moon", &[2, 5, 7, 9, 11]),
            ("Mars", &[1, 2, 4, 7, 8, 10, 11]),
            ("Merc", &[1, 2, 4, 5, 6, 9, 10, 11]),
            ("Jup", &[1, 2, 3, 4, 7, 8, 10, 11]),
            ("Ven", &[2, 5, 6, 9, 10, 11]),
            ("Sat", &[3, 5, 6, 12]),
            ("Asc", &[1, 2, 4, 5, 6, 7, 9, 10, 11]),
        ],
        Planet::Venus => vec![
            ("Sun", &[8, 11, 12]),
            ("Moon", &[1, 2, 3, 4, 5, 8, 9, 11, 12]),
            ("Mars", &[3, 5, 6, 9, 11, 12]),
            ("Merc", &[3, 5, 6, 9, 11]),
            ("Jup", &[5, 8, 9, 10, 11]),
            ("Ven", &[1, 2, 3, 4, 5, 8, 9, 10, 11]),
            ("Sat", &[3, 4, 5, 8, 9, 10, 11]),
            ("Asc", &[1, 2, 3, 4, 5, 8, 9, 11]),
        ],
        Planet::Saturn => vec![
            ("Sun", &[1, 2, 4, 7, 8, 10, 11]),
            ("Moon", &[3, 6, 11]),
            ("Mars", &[3, 5, 6, 10, 11, 12]),
            ("Merc", &[6, 8, 9, 10, 11, 12]),
            ("Jup", &[5, 6, 11, 12]),
            ("Ven", &[6, 11, 12]),
            ("Sat", &[3, 5, 6, 11]),
            ("Asc", &[1, 3, 4, 6, 10, 11]),
        ],
        _ => vec![],
    }
}
