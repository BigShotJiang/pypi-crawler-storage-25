use crate::ephemeris::swe_bindings::Ephemeris;
use crate::error::{JyotishError, JyotishResult};
use crate::data::types::{GeoPosition, HouseCusp};
use crate::ephemeris::swe_bindings::swe_houses_ex;

pub fn calculate_houses(jd: f64, geo: &GeoPosition, hsys: char, flags: i32) -> JyotishResult<(f64, Vec<HouseCusp>)> {
    let mut cusps = [0.0; 13];
    let mut ascmc = [0.0; 10];
    
    unsafe {
        let res = swe_houses_ex(jd, flags, geo.latitude, geo.longitude, hsys as i32, cusps.as_mut_ptr(), ascmc.as_mut_ptr());
        if res < 0 {
            return Err(JyotishError::EphemerisError("House calculation failed".to_string()));
        }
    }
    
    let ascendant = ascmc[0];
    let mut house_cusps = Vec::new();
    for i in 1..13 {
        house_cusps.push(HouseCusp {
            house: i as u8,
            cusp: cusps[i],
        });
    }
    
    Ok((ascendant, house_cusps))
}
