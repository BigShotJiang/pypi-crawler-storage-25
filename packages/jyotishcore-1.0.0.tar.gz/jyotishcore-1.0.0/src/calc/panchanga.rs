use crate::data::types::*;
use crate::ephemeris::service::Ephemeris;
use crate::error::JyotishError;
use chrono::{DateTime, Datelike, TimeZone, Utc};
use chrono_tz::Tz;

fn format_local(dt_utc: DateTime<Utc>, tz: &Tz) -> String {
    dt_utc
        .with_timezone(tz)
        .format("%Y-%m-%dT%H:%M:%S%:z")
        .to_string()
}

fn vara_from_local_date(year: i32, month: u32, day: u32) -> VaraInfo {
    let date = chrono::NaiveDate::from_ymd_opt(year, month, day)
        .unwrap_or_else(|| chrono::NaiveDate::from_ymd_opt(2000, 1, 1).unwrap());
    let idx = date.weekday().num_days_from_sunday() as i32;
    VaraInfo {
        index: idx,
        name: vara_name(idx),
    }
}

/// Reference JD for panchanga day boundary (civil midnight or last sunrise).
fn panchanga_reference_jd(
    jd: f64,
    mode: PanchangaMode,
    ephe: &Ephemeris,
    geo: &GeoPosition,
    tz: &Tz,
) -> Result<(f64, VaraInfo), JyotishError> {
    let utc = ephe.from_julian_day(jd);
    let local = utc.with_timezone(tz);

    match mode {
        PanchangaMode::CivilDay => {
            let naive = local
                .date_naive()
                .and_hms_opt(0, 0, 0)
                .ok_or(JyotishError::DateTimeError)?;
            let day_start = tz
                .from_local_datetime(&naive)
                .single()
                .ok_or(JyotishError::DateTimeError)?;
            let vara = vara_from_local_date(local.year(), local.month(), local.day());
            Ok((ephe.julian_day(&day_start.with_timezone(&Utc)), vara))
        }
        PanchangaMode::SunriseDay => {
            let search_jd = jd - 1.0;
            let mut sunrise = ephe.sunrise(search_jd, geo)?;
            if sunrise > jd {
                sunrise = ephe.sunrise(search_jd - 1.0, geo)?;
            }
            let sunrise_utc = ephe.from_julian_day(sunrise);
            let sunrise_local = sunrise_utc.with_timezone(tz);
            let vara = vara_from_local_date(
                sunrise_local.year(),
                sunrise_local.month(),
                sunrise_local.day(),
            );
            Ok((sunrise, vara))
        }
    }
}

pub fn compute_panchanga_local(
    utc_dt: DateTime<Utc>,
    geo: &GeoPosition,
    tz_str: &str,
    mode: PanchangaMode,
    ayanamsa: AyanamsaMode,
    true_nodes: bool,
) -> Result<Panchanga, JyotishError> {
    crate::calc::chart::validate_location(geo)?;
    let tz: Tz = tz_str
        .parse()
        .map_err(|_| JyotishError::InvalidParameter(format!("Unknown timezone: {}", tz_str)))?;

    let ephe = Ephemeris::new(ayanamsa, true_nodes);
    let jd = ephe.julian_day(&utc_dt);
    let local = utc_dt.with_timezone(&tz);
    let local_datetime = local.format("%Y-%m-%dT%H:%M:%S").to_string();

    let vara = match mode {
        PanchangaMode::CivilDay => vara_from_local_date(local.year(), local.month(), local.day()),
        PanchangaMode::SunriseDay => {
            let (_, v) = panchanga_reference_jd(jd, mode, &ephe, geo, &tz)?;
            v
        }
    };

    let tithi = tithi_at(jd, &ephe, geo, &tz)?;
    let nakshatra = nakshatra_at(jd, &ephe, geo, &tz)?;
    let yoga = yoga_at(jd, &ephe, geo, &tz)?;
    let karana = karana_at(jd, &ephe, geo, &tz)?;

    let mode_str = match mode {
        PanchangaMode::CivilDay => "civil_day",
        PanchangaMode::SunriseDay => "sunrise_day",
    };

    Ok(Panchanga {
        tithi,
        nakshatra,
        yoga,
        karana,
        vara,
        metadata: PanchangaMetadata {
            timezone: tz_str.to_string(),
            mode: mode_str.to_string(),
            local_datetime,
            utc_datetime: utc_dt.to_rfc3339(),
            ayanamsa: format!("{:?}", ayanamsa),
            true_nodes,
            calculation_version: env!("CARGO_PKG_VERSION").to_string(),
        },
        warnings: vec![
            "Panchanga end times are computed in UT; local times follow the provided IANA timezone.".to_string(),
        ],
    })
}

/// UTC panchanga element helpers (used by festival calendar code).
pub fn tithi(jd: f64, ephe: &Ephemeris, geo: &GeoPosition) -> Result<TithiInfo, JyotishError> {
    tithi_at(jd, ephe, geo, &Tz::UTC)
}

pub fn nakshatra(
    jd: f64,
    ephe: &Ephemeris,
    geo: &GeoPosition,
) -> Result<NakshatraInfo, JyotishError> {
    nakshatra_at(jd, ephe, geo, &Tz::UTC)
}

pub fn yoga(jd: f64, ephe: &Ephemeris, geo: &GeoPosition) -> Result<YogaInfo, JyotishError> {
    yoga_at(jd, ephe, geo, &Tz::UTC)
}

pub fn karana(jd: f64, ephe: &Ephemeris, geo: &GeoPosition) -> Result<KaranaInfo, JyotishError> {
    karana_at(jd, ephe, geo, &Tz::UTC)
}

pub fn get_all_panchanga(
    jd: f64,
    ephe: &Ephemeris,
    geo: &GeoPosition,
) -> Result<Panchanga, JyotishError> {
    let utc = ephe.from_julian_day(jd);
    compute_panchanga_local(
        utc,
        geo,
        "UTC",
        PanchangaMode::CivilDay,
        ephe.ayanamsa,
        ephe.true_nodes,
    )
}

fn tithi_at(
    jd: f64,
    ephe: &Ephemeris,
    _geo: &GeoPosition,
    tz: &Tz,
) -> Result<TithiInfo, JyotishError> {
    let moon = ephe.calc_ut(jd, Planet::Moon)?.longitude;
    let sun = ephe.calc_ut(jd, Planet::Sun)?.longitude;
    let tithi_index = crate::zodiac::tithi_index(moon, sun) as i32 + 1;
    let paksha = if tithi_index <= 15 {
        "Shukla"
    } else {
        "Krishna"
    };

    let (start_jd, end_jd) = find_element_interval(jd, |jd_test| {
        let m = ephe.calc_ut(jd_test, Planet::Moon)?.longitude;
        let s = ephe.calc_ut(jd_test, Planet::Sun)?.longitude;
        Ok(crate::zodiac::tithi_index(m, s) as i32 + 1)
    })?;

    let start_utc = ephe.from_julian_day(start_jd);
    let end_utc = ephe.from_julian_day(end_jd);

    Ok(TithiInfo {
        index: tithi_index,
        name: tithi_name(tithi_index),
        paksha: paksha.to_string(),
        start_jd,
        start_time_utc: start_utc,
        start_time_local: format_local(start_utc, tz),
        end_jd,
        end_time_utc: end_utc,
        end_time_local: format_local(end_utc, tz),
    })
}

fn nakshatra_at(
    jd: f64,
    ephe: &Ephemeris,
    geo: &GeoPosition,
    tz: &Tz,
) -> Result<NakshatraInfo, JyotishError> {
    let _ = geo;
    let moon = ephe.calc_ut(jd, Planet::Moon)?.longitude;
    let nakshatra_index = crate::zodiac::nakshatra_index(moon) as i32 + 1;
    let pada = crate::zodiac::pada_index(moon) as i32 + 1;

    let (start_jd, end_jd) = find_element_interval(jd, |jd_test| {
        let m = ephe.calc_ut(jd_test, Planet::Moon)?.longitude;
        Ok(crate::zodiac::nakshatra_index(m) as i32 + 1)
    })?;

    let start_utc = ephe.from_julian_day(start_jd);
    let end_utc = ephe.from_julian_day(end_jd);

    Ok(NakshatraInfo {
        index: nakshatra_index,
        name: nakshatra_name(nakshatra_index),
        pada,
        start_jd,
        start_time_utc: start_utc,
        start_time_local: format_local(start_utc, tz),
        end_jd,
        end_time_utc: end_utc,
        end_time_local: format_local(end_utc, tz),
    })
}

fn yoga_at(
    jd: f64,
    ephe: &Ephemeris,
    geo: &GeoPosition,
    tz: &Tz,
) -> Result<YogaInfo, JyotishError> {
    let _ = geo;
    let sun = ephe.calc_ut(jd, Planet::Sun)?.longitude;
    let moon = ephe.calc_ut(jd, Planet::Moon)?.longitude;
    let yoga_index = crate::zodiac::yoga_index(moon, sun) as i32 + 1;

    let (start_jd, end_jd) = find_element_interval(jd, |jd_test| {
        let m = ephe.calc_ut(jd_test, Planet::Moon)?.longitude;
        let s = ephe.calc_ut(jd_test, Planet::Sun)?.longitude;
        Ok(crate::zodiac::yoga_index(m, s) as i32 + 1)
    })?;

    let start_utc = ephe.from_julian_day(start_jd);
    let end_utc = ephe.from_julian_day(end_jd);

    Ok(YogaInfo {
        index: yoga_index,
        name: yoga_name(yoga_index),
        start_jd,
        start_time_utc: start_utc,
        start_time_local: format_local(start_utc, tz),
        end_jd,
        end_time_utc: end_utc,
        end_time_local: format_local(end_utc, tz),
    })
}

fn karana_at(
    jd: f64,
    ephe: &Ephemeris,
    geo: &GeoPosition,
    tz: &Tz,
) -> Result<KaranaInfo, JyotishError> {
    let _ = geo;
    let moon = ephe.calc_ut(jd, Planet::Moon)?.longitude;
    let sun = ephe.calc_ut(jd, Planet::Sun)?.longitude;
    let karana_index = crate::zodiac::karana_index(moon, sun) as i32 + 1;

    let (start_jd, end_jd) = find_element_interval(jd, |jd_test| {
        let m = ephe.calc_ut(jd_test, Planet::Moon)?.longitude;
        let s = ephe.calc_ut(jd_test, Planet::Sun)?.longitude;
        Ok(crate::zodiac::karana_index(m, s) as i32 + 1)
    })?;

    let start_utc = ephe.from_julian_day(start_jd);
    let end_utc = ephe.from_julian_day(end_jd);

    Ok(KaranaInfo {
        index: karana_index,
        name: karana_name(karana_index),
        start_jd,
        start_time_utc: start_utc,
        start_time_local: format_local(start_utc, tz),
        end_jd,
        end_time_utc: end_utc,
        end_time_local: format_local(end_utc, tz),
    })
}

/// Legacy UTC-only vara (weekday from JD). Prefer `compute_panchanga_local`.
pub fn vara(jd: f64) -> VaraInfo {
    let idx = ((jd + 1.5) % 7.0) as i32;
    VaraInfo {
        index: idx,
        name: vara_name(idx),
    }
}

fn find_element_interval<F>(query_jd: f64, mut element_fn: F) -> Result<(f64, f64), JyotishError>
where
    F: FnMut(f64) -> Result<i32, JyotishError>,
{
    let current_value = element_fn(query_jd)?;

    // Walk BACKWARD to find when current value started
    // Tithi/Nakshatra/Yoga duration is ~20-30 hours, safe to step back 3.0 days.
    let mut lo = query_jd - 3.0;
    let mut hi = query_jd;
    while element_fn(lo)? == current_value {
        lo -= 3.0;
        if query_jd - lo > 100.0 {
            return Err(JyotishError::ComputationError(
                "find_element_interval: failed to find start boundary (exceeded max backwards search)".into(),
            ));
        }
    }

    // Bisect lo..hi for exact start
    for _ in 0..40 {
        let mid = (lo + hi) / 2.0;
        if element_fn(mid)? == current_value {
            hi = mid;
        } else {
            lo = mid;
        }
    }
    let start = (lo + hi) / 2.0;

    // Walk FORWARD to find when current value ends
    let mut lo2 = query_jd;
    let mut hi2 = query_jd + 3.0;
    while element_fn(hi2)? == current_value {
        hi2 += 3.0;
        if hi2 - query_jd > 100.0 {
            return Err(JyotishError::ComputationError(
                "find_element_interval: failed to find end boundary (exceeded max forwards search)"
                    .into(),
            ));
        }
    }

    // Bisect lo2..hi2 for exact end
    for _ in 0..40 {
        let mid = (lo2 + hi2) / 2.0;
        if element_fn(mid)? == current_value {
            lo2 = mid;
        } else {
            hi2 = mid;
        }
    }
    let end = (lo2 + hi2) / 2.0;

    Ok((start, end))
}

fn tithi_name(index: i32) -> String {
    let names = [
        "Pratipada",
        "Dwitiya",
        "Tritiya",
        "Chaturthi",
        "Panchami",
        "Shashthi",
        "Saptami",
        "Ashtami",
        "Navami",
        "Dashami",
        "Ekadashi",
        "Dwadashi",
        "Trayodashi",
        "Chaturdashi",
        "Purnima",
        "Amavasya",
    ];
    let idx = if index == 30 {
        15
    } else if index <= 15 {
        index - 1
    } else {
        index - 16
    };
    names[idx as usize].to_string()
}

fn nakshatra_name(index: i32) -> String {
    let names = [
        "Ashwini",
        "Bharani",
        "Krittika",
        "Rohini",
        "Mrigashirsha",
        "Ardra",
        "Punarvasu",
        "Pushya",
        "Ashlesha",
        "Magha",
        "Purva Phalguni",
        "Uttara Phalguni",
        "Hasta",
        "Chitra",
        "Swati",
        "Vishakha",
        "Anuradha",
        "Jyeshtha",
        "Mula",
        "Purva Ashadha",
        "Uttara Ashadha",
        "Shravana",
        "Dhanishta",
        "Shatabhisha",
        "Purva Bhadrapada",
        "Uttara Bhadrapada",
        "Revati",
    ];
    names[(index - 1) as usize].to_string()
}

fn yoga_name(index: i32) -> String {
    let names = [
        "Vishkambha",
        "Preeti",
        "Ayushman",
        "Saubhagya",
        "Shobhana",
        "Atiganda",
        "Sukarma",
        "Dhruti",
        "Shoola",
        "Ganda",
        "Vriddhi",
        "Dhruva",
        "Vyaghata",
        "Harshana",
        "Vajra",
        "Siddhi",
        "Vyatipata",
        "Variyana",
        "Parigha",
        "Shiva",
        "Siddha",
        "Sadhya",
        "Shubha",
        "Shukla",
        "Brahma",
        "Indra",
        "Vaidhriti",
    ];
    names[(index - 1) as usize].to_string()
}

fn karana_name(index: i32) -> String {
    let names = [
        "Bava",
        "Balava",
        "Kaulava",
        "Taitila",
        "Gara",
        "Vanija",
        "Vishti",
        "Shakuni",
        "Chatushpada",
        "Naga",
        "Kimstughna",
    ];

    if index == 1 {
        return "Kimstughna".to_string();
    }
    if index >= 58 {
        let fixed_idx = match index {
            58 => 7,
            59 => 8,
            60 => 9,
            _ => 7,
        };
        return names[fixed_idx].to_string();
    }

    let rep_idx = (index - 2) % 7;
    names[rep_idx as usize].to_string()
}

fn vara_name(index: i32) -> String {
    let names = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
    ];
    names[index as usize].to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::{TimeZone, Utc};

    #[test]
    fn test_vara_from_local_date_sunday() {
        let v = vara_from_local_date(2026, 5, 17);
        assert_eq!(v.index, 0);
        assert_eq!(v.name, "Sunday");
    }

    #[test]
    fn test_civil_day_vara_from_local_date() {
        let v = vara_from_local_date(2026, 5, 16);
        assert_eq!(v.index, 6);
        assert_eq!(v.name, "Saturday");
    }

    #[test]
    fn amavasya_uses_distinct_tithi_name() {
        assert_eq!(tithi_name(15), "Purnima");
        assert_eq!(tithi_name(30), "Amavasya");
    }

    #[test]
    fn panchanga_intervals_contain_query_time() {
        let geo = GeoPosition {
            latitude: 27.7172,
            longitude: 85.3240,
            altitude: 1350.0,
        };
        let cases = [
            Utc.with_ymd_and_hms(2026, 5, 16, 6, 15, 0).unwrap(),
            Utc.with_ymd_and_hms(2025, 6, 15, 3, 18, 0).unwrap(),
            Utc.with_ymd_and_hms(2025, 9, 7, 20, 12, 0).unwrap(),
        ];

        for utc_dt in cases {
            let p = compute_panchanga_local(
                utc_dt,
                &geo,
                "Asia/Kathmandu",
                PanchangaMode::CivilDay,
                AyanamsaMode::Lahiri,
                true,
            )
            .unwrap();

            assert!(
                p.tithi.start_time_utc <= utc_dt && utc_dt <= p.tithi.end_time_utc,
                "tithi interval did not contain {utc_dt}: {:?}",
                p.tithi
            );
            assert!(
                p.nakshatra.start_time_utc <= utc_dt && utc_dt <= p.nakshatra.end_time_utc,
                "nakshatra interval did not contain {utc_dt}: {:?}",
                p.nakshatra
            );
            assert!(
                p.yoga.start_time_utc <= utc_dt && utc_dt <= p.yoga.end_time_utc,
                "yoga interval did not contain {utc_dt}: {:?}",
                p.yoga
            );
            assert!(
                p.karana.start_time_utc <= utc_dt && utc_dt <= p.karana.end_time_utc,
                "karana interval did not contain {utc_dt}: {:?}",
                p.karana
            );
        }
    }
}
