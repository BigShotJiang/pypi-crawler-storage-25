use crate::data::types::{Planet, PlanetPosition};
use crate::ephemeris::swe_bindings::Ephemeris;
use crate::error::JyotishResult;
use crate::data::constants::SE_SIDBIT;

pub fn calculate_planet_position(jd: f64, planet: Planet, ayanamsa_flags: i32) -> JyotishResult<PlanetPosition> {
    let planet_id = planet as i32;
    // Flags for sidereal calculation usually include SE_SIDBIT
    let flags = ayanamsa_flags | SE_SIDBIT;
    
    let res = Ephemeris::calc_ut(jd, planet_id, flags)?;
    
    Ok(PlanetPosition {
        planet,
        longitude: res[0],
        latitude: res[1],
        speed: res[3],
        is_retrograde: res[3] < 0.0,
        sign: None,      // To be filled by chart logic
        nakshatra: None,
        house: None,
    })
}
