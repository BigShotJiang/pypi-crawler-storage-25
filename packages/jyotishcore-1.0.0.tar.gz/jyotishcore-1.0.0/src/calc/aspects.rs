use crate::data::types::{AspectRelation, Chart, Planet};

pub fn compute_aspects(chart: &Chart) -> Vec<AspectRelation> {
    let mut aspects = Vec::new();

    for planet_pos in &chart.planets {
        let from_house = match planet_pos.house {
            Some(h) => h,
            None => continue,
        };

        // Every planet fully aspects 7th from itself
        let house_7 = ((from_house + 5) % 12) + 1;
        aspects.push(aspect_to_house(
            planet_pos.planet,
            from_house,
            house_7,
            1.0,
            false,
            chart,
        ));

        // Special aspects
        let special = match planet_pos.planet {
            Planet::Mars => vec![(4u8, 1.0), (8u8, 1.0)], // Note: Standard Parashara is full strength for these
            Planet::Jupiter => vec![(5u8, 1.0), (9u8, 1.0)],
            Planet::Saturn => vec![(3u8, 1.0), (10u8, 1.0)],
            _ => vec![],
        };

        for (nth, strength) in special {
            let target = ((from_house + nth - 2) % 12) + 1;
            aspects.push(aspect_to_house(
                planet_pos.planet,
                from_house,
                target,
                strength,
                true,
                chart,
            ));
        }
    }
    aspects
}

fn aspect_to_house(
    from_planet: Planet,
    _from_house: u8,
    to_house: u8,
    strength: f64,
    is_special: bool,
    chart: &Chart,
) -> AspectRelation {
    let to_planet = chart
        .planets
        .iter()
        .find(|p| p.house == Some(to_house))
        .map(|p| p.planet);

    AspectRelation {
        from_planet,
        to_house,
        to_planet,
        strength,
        is_special,
    }
}
