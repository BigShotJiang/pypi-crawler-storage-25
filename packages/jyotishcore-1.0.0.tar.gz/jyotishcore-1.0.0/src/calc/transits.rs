use crate::data::types::{AyanamsaMode, Planet, Sign};
use crate::ephemeris::service::Ephemeris;
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, serde::Serialize)]
pub struct TransitEvent {
    pub planet: Planet,
    pub from_sign: Sign,
    pub to_sign: Sign,
    pub ingress_time: DateTime<Utc>,
    pub is_retrograde: bool,
}

pub fn find_sign_ingresses(
    from_jd: f64,
    to_jd: f64,
    ayanamsa: AyanamsaMode,
    true_nodes: bool,
) -> Vec<TransitEvent> {
    let ephe = Ephemeris::new(ayanamsa, true_nodes);
    let mut events = Vec::new();

    let planets = [
        Planet::Sun,
        Planet::Moon,
        Planet::Mars,
        Planet::Mercury,
        Planet::Jupiter,
        Planet::Venus,
        Planet::Saturn,
        Planet::Rahu,
        Planet::Ketu,
    ];

    for &p in &planets {
        let mut current_jd = from_jd;
        let step = 1.0; // 1 day step

        let mut last_sign = get_planet_sign(p, current_jd, &ephe);

        while current_jd < to_jd {
            current_jd += step;
            if current_jd > to_jd {
                current_jd = to_jd;
            }

            let new_sign = get_planet_sign(p, current_jd, &ephe);
            if new_sign != last_sign {
                // Pinpoint with bisection
                let mut lo = current_jd - step;
                let mut hi = current_jd;
                for _ in 0..20 {
                    let mid = (lo + hi) / 2.0;
                    if get_planet_sign(p, mid, &ephe) == new_sign {
                        hi = mid;
                    } else {
                        lo = mid;
                    }
                }

                let exact_jd = (lo + hi) / 2.0;
                let dt = ephe.from_julian_day(exact_jd);
                let info = ephe.calc_ut(exact_jd, p).unwrap_or_default();

                events.push(TransitEvent {
                    planet: p,
                    from_sign: last_sign,
                    to_sign: new_sign,
                    ingress_time: dt,
                    is_retrograde: info.speed < 0.0,
                });
                last_sign = new_sign;
            }
        }
    }

    events.sort_by_key(|event| event.ingress_time);
    events
}

fn get_planet_sign(p: Planet, jd: f64, ephe: &Ephemeris) -> Sign {
    let pos = ephe.calc_ut(jd, p).unwrap_or_default();
    crate::zodiac::sign_from_longitude(pos.longitude)
}
