use thiserror::Error;

#[derive(Error, Debug)]
pub enum JyotishError {
    #[error("Swiss Ephemeris calculation failed for planet {planet}: {msg}")]
    SweCalculation { planet: String, msg: String },
    #[error("Invalid parameter: {0}")]
    InvalidParameter(String),
    #[error("Date/time conversion error")]
    DateTimeError,
    #[error("Computation error: {0}")]
    ComputationError(String),
}
