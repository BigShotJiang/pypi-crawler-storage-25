use crate::dasha::base::{DashaPeriod, DashaSystem};
use crate::data::dasha_constants::*;
use chrono::{DateTime, Duration, Utc};

pub struct VimshottariDasha;

impl VimshottariDasha {
    fn get_years(lord: crate::data::types::Planet) -> f64 {
        VIMSHOTTARI_PERIODS
            .iter()
            .find(|(p, _)| *p == lord)
            .unwrap()
            .1
    }

    fn compute_sub_periods(
        maha_lord: crate::data::types::Planet,
        maha_start: DateTime<Utc>,
        maha_end: DateTime<Utc>,
        maha_total_years: f64,
    ) -> Vec<DashaPeriod> {
        let total_cycle_years: f64 = 120.0;
        let maha_duration_seconds = (maha_end - maha_start).num_seconds() as f64;
        let mut ad_start = maha_start;
        let ad_seq_start_idx = VIMSHOTTARI_ORDER
            .iter()
            .position(|&p| p == maha_lord)
            .unwrap();
        let mut sub_periods = Vec::new();

        for i in 0..9 {
            let ad_idx = (ad_seq_start_idx + i) % 9;
            let ad_lord = VIMSHOTTARI_ORDER[ad_idx];
            let ad_years = Self::get_years(ad_lord);

            // AD Duration = (Maha Years * AD Years) / 120
            // Use seconds for higher precision than days
            let ad_nominal_seconds =
                (ad_years * maha_total_years / total_cycle_years) * 365.2425 * 86400.0;
            // Adjust for partial first MD
            let adj_ad_seconds = (ad_nominal_seconds / (maha_total_years * 365.2425 * 86400.0))
                * maha_duration_seconds;
            let ad_end = ad_start + Duration::seconds(adj_ad_seconds as i64);

            let mut ad_period = DashaPeriod {
                lord_name: format!("{:?}", ad_lord),
                start: ad_start,
                end: ad_end,
                sub_periods: Vec::new(),
            };

            // Compute PD
            let mut pd_start = ad_start;
            let pd_seq_start_idx = VIMSHOTTARI_ORDER
                .iter()
                .position(|&p| p == ad_lord)
                .unwrap();
            let ad_duration_seconds = (ad_end - ad_start).num_seconds() as f64;

            for j in 0..9 {
                let pd_idx = (pd_seq_start_idx + j) % 9;
                let pd_lord = VIMSHOTTARI_ORDER[pd_idx];
                let pd_years = Self::get_years(pd_lord);

                let pd_nominal_seconds =
                    (pd_years * ad_years / total_cycle_years) * 365.2425 * 86400.0;
                let adj_pd_seconds =
                    (pd_nominal_seconds / (ad_years * 365.2425 * 86400.0)) * ad_duration_seconds;

                let pd_end = pd_start + Duration::seconds(adj_pd_seconds as i64);
                ad_period.sub_periods.push(DashaPeriod {
                    lord_name: format!("{:?}", pd_lord),
                    start: pd_start,
                    end: pd_end,
                    sub_periods: Vec::new(),
                });
                pd_start = pd_end;
            }

            sub_periods.push(ad_period);
            ad_start = ad_end;
        }
        sub_periods
    }
}

impl DashaSystem for VimshottariDasha {
    fn compute(
        birth: DateTime<Utc>,
        moon_nakshatra: usize,
        moon_longitude_in_nak: f64,
        _sign_index: Option<usize>,
    ) -> Vec<DashaPeriod> {
        let moon_lord = NAKSHATRA_LORDS[moon_nakshatra];
        let total_dasha_years = Self::get_years(moon_lord);

        let nak_length = 360.0 / 27.0;
        let fraction_elapsed = moon_longitude_in_nak / nak_length;
        let remaining_first_dasha_years = total_dasha_years * (1.0 - fraction_elapsed);

        // Use seconds precision instead of day truncation
        let remaining_first_seconds = remaining_first_dasha_years * 365.2425 * 86400.0;

        let mut periods = Vec::new();
        let start_idx = VIMSHOTTARI_ORDER
            .iter()
            .position(|&p| p == moon_lord)
            .unwrap();

        // First period
        let first_lord = VIMSHOTTARI_ORDER[start_idx];
        let first_end = birth + Duration::seconds(remaining_first_seconds as i64);
        periods.push(DashaPeriod {
            lord_name: format!("{:?}", first_lord),
            start: birth,
            end: first_end,
            sub_periods: Self::compute_sub_periods(
                first_lord,
                birth,
                first_end,
                remaining_first_dasha_years,
            ),
        });

        let mut current_time = first_end;
        for i in 1..9 {
            let idx = (start_idx + i) % 9;
            let lord = VIMSHOTTARI_ORDER[idx];
            let years = Self::get_years(lord);
            let seconds = years * 365.2425 * 86400.0;
            let end = current_time + Duration::seconds(seconds as i64);
            periods.push(DashaPeriod {
                lord_name: format!("{:?}", lord),
                start: current_time,
                end,
                sub_periods: Self::compute_sub_periods(lord, current_time, end, years),
            });
            current_time = end;
        }

        periods
    }
}
