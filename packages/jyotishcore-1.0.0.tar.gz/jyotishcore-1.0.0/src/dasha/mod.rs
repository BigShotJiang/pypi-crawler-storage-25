pub mod base;
pub mod vimshottari;

#[cfg(feature = "experimental")]
pub mod chara;
#[cfg(feature = "experimental")]
pub mod yogini;

use crate::dasha::base::{DashaPeriod, DashaSystem};
use crate::dasha::vimshottari::VimshottariDasha;
use crate::data::types::{Chart, Planet};

pub fn compute_all_dashas(chart: &Chart) -> std::collections::HashMap<String, Vec<DashaPeriod>> {
    let mut map = std::collections::HashMap::new();

    // Find Moon
    if let Some(moon) = chart.planets.iter().find(|p| p.planet == Planet::Moon) {
        let moon_lon = moon.longitude;
        let nakshatra_index = (moon_lon / (360.0 / 27.0)) as usize;
        let nak_long_in = moon_lon % (360.0 / 27.0);

        map.insert(
            "vimshottari".to_string(),
            VimshottariDasha::compute(chart.datetime, nakshatra_index, nak_long_in, None),
        );

        #[cfg(feature = "experimental")]
        {
            use crate::dasha::yogini::YoginiDasha;
            map.insert(
                "yogini".to_string(),
                YoginiDasha::compute(chart.datetime, nakshatra_index, nak_long_in, None),
            );
        }
    }

    #[cfg(feature = "experimental")]
    {
        use crate::dasha::chara::compute_chara;
        map.insert("chara".to_string(), compute_chara(chart));
    }

    map
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg(not(feature = "experimental"))]
    fn default_dashas_exclude_experimental_systems() {
        let chart = Chart {
            datetime: chrono::Utc::now(),
            ascendant: 0.0, // Aries
            planets: vec![
                crate::data::types::PlanetPosition {
                    planet: Planet::Sun,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Moon,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Mars,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Mercury,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Jupiter,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Venus,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Saturn,
                    longitude: 0.0,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let dashas = compute_all_dashas(&chart);
        assert!(dashas.contains_key("vimshottari"));
        assert!(!dashas.contains_key("chara"));
        assert!(!dashas.contains_key("yogini"));
    }

    #[test]
    #[cfg(feature = "experimental")]
    fn experimental_dashas_are_included_when_feature_enabled() {
        let chart = Chart {
            datetime: chrono::Utc::now(),
            ascendant: 0.0, // Aries
            planets: vec![
                crate::data::types::PlanetPosition {
                    planet: Planet::Sun,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Moon,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Mars,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Mercury,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Jupiter,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Venus,
                    longitude: 0.0,
                    ..Default::default()
                },
                crate::data::types::PlanetPosition {
                    planet: Planet::Saturn,
                    longitude: 0.0,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let dashas = compute_all_dashas(&chart);
        assert!(dashas.contains_key("vimshottari"));
        assert!(dashas.contains_key("chara"));
        assert!(dashas.contains_key("yogini"));
    }
}
