use crate::dasha::base::{DashaPeriod, DashaSystem};
use crate::data::types::{Chart, Planet};
use chrono::{DateTime, Duration, Utc};

/// Chara Dasha — Sign-based dasha system from Jaimini astrology.
///
/// # Algorithm (Brihat Parashara Hora Shastra / Jaimini Sutras)
/// 1. Start from the Ascendant sign.
/// 2. For each sign (12 total), the Mahadasha duration in years = number of signs
///    between the sign and its lord (inclusive or exclusive based on direction),
///    with 0 difference = 12 years.
/// 3. The sequence proceeds forward or backward depending on the sign:
///    - Forward (movable/dual signs: Aries, Cancer, Libra, Capricorn, Gemini, Virgo,
///      Sagittarius, Pisces) — counted forward (Aries→Taurus→...)
///    - Backward (fixed signs: Taurus, Leo, Scorpio, Aquarius) — counted backward
/// 4. Antardashas (sub-periods) follow the same 12-sign cycle within the Mahadasha,
///    proportionally subdivided, starting from the same sign as the Mahadasha.
///
/// # Known limitation
/// Multiple Jaimini commentators (K.N. Rao, P.S. Sastri, Iranganti Rangacharya) differ
/// on exact counting rules and which signs are forward vs backward.
/// This implementation follows the most widely-used (K.N. Rao) interpretation.
/// Results should be cross-verified with a qualified astrologer or JHora.
///
/// # Reference
/// - Jaimini Sutras, Adhyaya 2, Pada 3
/// - K.N. Rao, "Predicting Through Jaimini's Chara Dasha"
pub struct CharaDasha;

impl CharaDasha {
    fn sign_to_str(s: usize) -> &'static str {
        match s {
            0 => "Aries",
            1 => "Taurus",
            2 => "Gemini",
            3 => "Cancer",
            4 => "Leo",
            5 => "Virgo",
            6 => "Libra",
            7 => "Scorpio",
            8 => "Sagittarius",
            9 => "Capricorn",
            10 => "Aquarius",
            11 => "Pisces",
            _ => "Unknown",
        }
    }

    /// Returns the zodiac sign index (0–11) where the lord of `sign_idx` resides.
    fn get_lord_sign(sign_idx: usize, chart: &Chart) -> usize {
        let lord = match sign_idx {
            0 | 7 => Planet::Mars,     // Aries, Scorpio
            1 | 6 => Planet::Venus,    // Taurus, Libra
            2 | 5 => Planet::Mercury,  // Gemini, Virgo
            3 => Planet::Moon,         // Cancer
            4 => Planet::Sun,          // Leo
            8 | 11 => Planet::Jupiter, // Sagittarius, Pisces
            9 | 10 => Planet::Saturn,  // Capricorn, Aquarius
            _ => Planet::Sun,
        };

        chart
            .planets
            .iter()
            .find(|p| p.planet == lord)
            .map(|p| (p.longitude / 30.0) as usize % 12)
            .unwrap_or(0)
    }

    /// True if the sign counts forward (movable + dual signs per K.N. Rao):
    /// Aries(0), Gemini(2), Cancer(3), Virgo(5), Libra(6), Sagittarius(8),
    /// Capricorn(9), Pisces(11)
    /// Fixed signs (Taurus=1, Leo=4, Scorpio=7, Aquarius=10) count backward.
    fn is_forward(sign_idx: usize) -> bool {
        !matches!(sign_idx, 1 | 4 | 7 | 10)
    }

    /// Compute the Chara Dasha duration in years for a given sign.
    fn dasha_years(sign_idx: usize, chart: &Chart) -> usize {
        let lord_sign = Self::get_lord_sign(sign_idx, chart);

        let raw_diff = if Self::is_forward(sign_idx) {
            // Count signs from sign_idx forward to lord_sign (inclusive of both)
            if lord_sign >= sign_idx {
                lord_sign - sign_idx
            } else {
                lord_sign + 12 - sign_idx
            }
        } else {
            // Count signs from lord_sign forward to sign_idx (backward direction)
            if sign_idx >= lord_sign {
                sign_idx - lord_sign
            } else {
                sign_idx + 12 - lord_sign
            }
        };

        if raw_diff == 0 {
            12
        } else {
            raw_diff
        }
    }
}

impl DashaSystem for CharaDasha {
    fn compute(
        _birth: DateTime<Utc>,
        _moon_nakshatra: usize,
        _moon_longitude_in_nak: f64,
        _sign_index: Option<usize>,
    ) -> Vec<DashaPeriod> {
        // Chara Dasha cannot be computed from Moon nakshatra alone — it requires the full chart.
        // Use compute_with_chart() instead.
        Vec::new()
    }

    fn compute_with_chart(chart: &Chart) -> Vec<DashaPeriod> {
        compute_chara(chart)
    }
}

/// Compute Chara Dasha and Antardashas for the given chart.
pub fn compute_chara(chart: &Chart) -> Vec<DashaPeriod> {
    let asc_sign = (chart.ascendant / 30.0) as usize % 12;
    let mut current_start = chart.datetime;
    let mut periods = Vec::new();

    for i in 0..12 {
        let sign_idx = (asc_sign + i) % 12;
        let years = CharaDasha::dasha_years(sign_idx, chart);
        let total_seconds = (years as f64 * 365.25 * 86400.0) as i64;
        let end = current_start + Duration::seconds(total_seconds);

        // ── Antardashas ──────────────────────────────────────────────────────
        // Each Antardasha covers 1/12 of the Mahadasha, distributed proportionally
        // using the same Chara formula for each sub-sign.
        //
        // The Antardasha sequence starts from the same sign as the Mahadasha and
        // proceeds in the same direction (forward or backward) for 12 signs.
        //
        // The duration of each Antardasha = (sub_sign years / total mahadasha years)
        // × Mahadasha total duration.
        //
        // Reference: K.N. Rao, "Predicting Through Jaimini's Chara Dasha", Ch. 3
        let mut sub_periods = Vec::new();
        let mut sub_start = current_start;

        // Collect sub-sign years first to get total for proportional division
        let mut sub_sign_years: Vec<(usize, usize)> = Vec::with_capacity(12);
        let mut sub_total_years = 0usize;
        for j in 0..12 {
            let sub_sign_idx = if CharaDasha::is_forward(sign_idx) {
                (sign_idx + j) % 12
            } else {
                (sign_idx + 12 - j) % 12
            };
            let sy = CharaDasha::dasha_years(sub_sign_idx, chart);
            sub_sign_years.push((sub_sign_idx, sy));
            sub_total_years += sy;
        }

        for (j, &(sub_sign_idx, sy)) in sub_sign_years.iter().enumerate() {
            // Proportional duration: (sub_years / sum_of_all_sub_years) × mahadasha_seconds
            let sub_seconds = if sub_total_years > 0 {
                (sy as f64 / sub_total_years as f64 * total_seconds as f64) as i64
            } else {
                total_seconds / 12
            };

            let sub_end = if j == 11 {
                end // Snap last sub-period to exact Mahadasha end to avoid drift
            } else {
                sub_start + Duration::seconds(sub_seconds)
            };

            sub_periods.push(DashaPeriod {
                lord_name: CharaDasha::sign_to_str(sub_sign_idx).to_string(),
                start: sub_start,
                end: sub_end,
                sub_periods: Vec::new(),
            });
            sub_start = sub_end;
        }

        periods.push(DashaPeriod {
            lord_name: CharaDasha::sign_to_str(sign_idx).to_string(),
            start: current_start,
            end,
            sub_periods,
        });
        current_start = end;
    }
    periods
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::data::types::{Planet, PlanetPosition};
    use chrono::TimeZone;

    fn make_test_chart(ascendant: f64, planet_lons: Vec<(Planet, f64)>) -> Chart {
        let planets = planet_lons
            .into_iter()
            .map(|(planet, longitude)| PlanetPosition {
                planet,
                longitude,
                ..Default::default()
            })
            .collect();
        Chart {
            datetime: chrono::Utc.with_ymd_and_hms(2000, 1, 1, 0, 0, 0).unwrap(),
            ascendant,
            planets,
            ..Default::default()
        }
    }

    #[test]
    fn test_chara_produces_12_mahadashas() {
        // Chart: Aries ascendant, Mars in Aries (lord of Aries is in Aries → 12 years)
        let chart = make_test_chart(
            5.0, // Aries lagna
            vec![
                (Planet::Mars, 10.0),     // Mars in Aries (lord of Aries, Scorpio)
                (Planet::Venus, 40.0),    // Venus in Taurus
                (Planet::Mercury, 70.0),  // Mercury in Gemini
                (Planet::Moon, 100.0),    // Moon in Cancer
                (Planet::Sun, 130.0),     // Sun in Leo
                (Planet::Jupiter, 250.0), // Jupiter in Sagittarius
                (Planet::Saturn, 310.0),  // Saturn in Capricorn
            ],
        );
        let dashas = compute_chara(&chart);
        assert_eq!(
            dashas.len(),
            12,
            "Chara Dasha must have exactly 12 Mahadashas"
        );
    }

    #[test]
    fn test_chara_first_dasha_is_lagna_sign() {
        // Lagna in Aries (0–30°), first Mahadasha should be Aries
        let chart = make_test_chart(
            15.0, // Aries lagna
            vec![
                (Planet::Mars, 45.0), // Mars in Taurus
                (Planet::Venus, 40.0),
                (Planet::Mercury, 70.0),
                (Planet::Moon, 100.0),
                (Planet::Sun, 130.0),
                (Planet::Jupiter, 250.0),
                (Planet::Saturn, 310.0),
            ],
        );
        let dashas = compute_chara(&chart);
        assert_eq!(dashas[0].lord_name, "Aries");
    }

    #[test]
    fn test_chara_each_mahadasha_has_12_antardashas() {
        let chart = make_test_chart(
            15.0,
            vec![
                (Planet::Mars, 45.0),
                (Planet::Venus, 40.0),
                (Planet::Mercury, 70.0),
                (Planet::Moon, 100.0),
                (Planet::Sun, 130.0),
                (Planet::Jupiter, 250.0),
                (Planet::Saturn, 310.0),
            ],
        );
        let dashas = compute_chara(&chart);
        for dasha in &dashas {
            assert_eq!(
                dasha.sub_periods.len(),
                12,
                "Each Mahadasha must have exactly 12 Antardashas, got {} for {}",
                dasha.sub_periods.len(),
                dasha.lord_name
            );
        }
    }

    #[test]
    fn test_chara_antardasha_sum_equals_mahadasha() {
        let chart = make_test_chart(
            15.0,
            vec![
                (Planet::Mars, 45.0),
                (Planet::Venus, 40.0),
                (Planet::Mercury, 70.0),
                (Planet::Moon, 100.0),
                (Planet::Sun, 130.0),
                (Planet::Jupiter, 250.0),
                (Planet::Saturn, 310.0),
            ],
        );
        let dashas = compute_chara(&chart);
        for dasha in &dashas {
            let maha_duration = (dasha.end - dasha.start).num_seconds();
            let sub_sum: i64 = dasha
                .sub_periods
                .iter()
                .map(|sp| (sp.end - sp.start).num_seconds())
                .sum();
            assert_eq!(
                maha_duration, sub_sum,
                "Antardasha sum ({}) must equal Mahadasha duration ({}) for {}",
                sub_sum, maha_duration, dasha.lord_name
            );
        }
    }

    #[test]
    fn test_dasha_years_zero_diff_gives_twelve() {
        // When lord is in same sign as the sign itself, duration = 12 years
        let chart = make_test_chart(
            5.0, // Aries lagna
            vec![
                (Planet::Mars, 10.0), // Mars in Aries — lord of Aries is in Aries → diff=0 → 12 years
                (Planet::Venus, 40.0),
                (Planet::Mercury, 70.0),
                (Planet::Moon, 100.0),
                (Planet::Sun, 130.0),
                (Planet::Jupiter, 250.0),
                (Planet::Saturn, 310.0),
            ],
        );
        // Aries (sign_idx=0), Mars (lord) is in Aries (lord_sign=0)
        // is_forward(0)=true, lord_sign(0)==sign_idx(0) → raw_diff=0 → years=12
        let years = CharaDasha::dasha_years(0, &chart);
        assert_eq!(years, 12);
    }
}
