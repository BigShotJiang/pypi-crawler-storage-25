use crate::dasha::base::{DashaPeriod, DashaSystem};
use chrono::{DateTime, Duration, Utc};

pub struct YoginiDasha;

impl DashaSystem for YoginiDasha {
    fn compute(
        birth: DateTime<Utc>,
        moon_nakshatra: usize, // 0..26
        moon_longitude_in_nak: f64,
        _sign_index: Option<usize>,
    ) -> Vec<DashaPeriod> {
        let nak_1_indexed = moon_nakshatra + 1;
        let initial_idx = (nak_1_indexed + 3) % 8;
        // Rem 1=Mangala, 2=Pingala, 3=Dhanya, 4=Bhramari, 5=Bhadrika, 6=Ulka, 7=Siddha, 0=Sankata

        let yogini_names = [
            "Sankata (Rahu)",
            "Mangala (Moon)",
            "Pingala (Sun)",
            "Dhanya (Jupiter)",
            "Bhramari (Mars)",
            "Bhadrika (Mercury)",
            "Ulka (Saturn)",
            "Siddha (Venus)",
        ];

        let durations_years = [8, 1, 2, 3, 4, 5, 6, 7];

        let mut periods = Vec::new();
        let mut current_start = birth;

        // Total cycle is 36 years. We'll compute 2 cycles (72 years) for a standard life
        let mut sequence = Vec::new();
        let mut idx = initial_idx;
        for _ in 0..16 {
            // 2 full rounds
            sequence.push(idx);
            idx = (idx + 1) % 8;
        }

        for (i, &s_idx) in sequence.iter().enumerate() {
            let lord_name = yogini_names[s_idx].to_string();
            let duration_yrs = durations_years[s_idx];

            let duration_days = (duration_yrs as f64 * 365.25) as i64;

            if i == 0 {
                // Calculate balance
                let nak_length = 360.0 / 27.0;
                let elapsed_ratio = moon_longitude_in_nak / nak_length;
                let elapsed_days = (duration_days as f64 * elapsed_ratio) as i64;

                let remaining_days = duration_days - elapsed_days;
                let end = current_start + Duration::days(remaining_days);

                periods.push(DashaPeriod {
                    lord_name,
                    start: current_start,
                    end,
                    sub_periods: Vec::new(),
                });
                current_start = end;
            } else {
                let end = current_start + Duration::days(duration_days);
                periods.push(DashaPeriod {
                    lord_name,
                    start: current_start,
                    end,
                    sub_periods: Vec::new(),
                });
                current_start = end;
            }
        }

        periods
    }
}
