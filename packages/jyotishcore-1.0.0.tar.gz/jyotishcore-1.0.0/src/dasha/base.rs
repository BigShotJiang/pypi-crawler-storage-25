use chrono::{DateTime, Utc};

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct DashaPeriod {
    pub lord_name: String,
    pub start: DateTime<Utc>,
    pub end: DateTime<Utc>,
    pub sub_periods: Vec<DashaPeriod>,
}

pub trait DashaSystem {
    /// Compute the full sequence of mahadasha periods from birth.
    fn compute(
        birth: DateTime<Utc>,
        moon_nakshatra: usize,      // index 0..26
        moon_longitude_in_nak: f64, // degree 0..13.333
        sign_index: Option<usize>,  // index 0..11 (optional for sign-based dashas)
    ) -> Vec<DashaPeriod>;

    // New optional override for systems that need full chart access
    fn compute_with_chart(chart: &crate::data::types::Chart) -> Vec<DashaPeriod> {
        // Default: delegate to compute() using moon data
        let moon = chart
            .planets
            .iter()
            .find(|p| p.planet == crate::data::types::Planet::Moon)
            .expect("Moon must be present");
        let nak_idx = ((moon.longitude / (360.0 / 27.0)) as usize).min(26);
        let nak_length = 360.0 / 27.0;
        let lon_in_nak = moon.longitude % nak_length;
        let asc_sign = (chart.ascendant / 30.0) as usize % 12;
        Self::compute(chart.datetime, nak_idx, lon_in_nak, Some(asc_sign))
    }
}
