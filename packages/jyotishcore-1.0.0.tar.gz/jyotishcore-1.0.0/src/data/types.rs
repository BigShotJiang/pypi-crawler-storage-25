use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Default)]
pub enum Planet {
    #[default]
    Sun,
    Moon,
    Mars,
    Mercury,
    Jupiter,
    Venus,
    Saturn,
    Rahu,
    Ketu,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Karaka {
    Atmakaraka,
    Amatyakaraka,
    Bhratrikaraka,
    Matrikaraka,
    Putrakaraka,
    Jnatikaraka,
    Darakaraka,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Default)]
pub enum Sign {
    #[default]
    Aries = 1,
    Taurus = 2,
    Gemini = 3,
    Cancer = 4,
    Leo = 5,
    Virgo = 6,
    Libra = 7,
    Scorpio = 8,
    Sagittarius = 9,
    Capricorn = 10,
    Aquarius = 11,
    Pisces = 12,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Default)]
pub enum Nakshatra {
    #[default]
    Ashwini = 1,
    Bharani = 2,
    Krittika = 3,
    Rohini = 4,
    Mrigashirsha = 5,
    Ardra = 6,
    Punarvasu = 7,
    Pushya = 8,
    Ashlesha = 9,
    Magha = 10,
    PurvaPhalguni = 11,
    UttaraPhalguni = 12,
    Hasta = 13,
    Chitra = 14,
    Swati = 15,
    Vishakha = 16,
    Anuradha = 17,
    Jyeshtha = 18,
    Mula = 19,
    PurvaAshadha = 20,
    UttaraAshadha = 21,
    Shravana = 22,
    Dhanishta = 23,
    Shatabhisha = 24,
    PurvaBhadrapada = 25,
    UttaraBhadrapada = 26,
    Revati = 27,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct GeoPosition {
    pub latitude: f64,
    pub longitude: f64,
    pub altitude: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CalculationMetadata {
    pub input_mode: String,
    pub utc_datetime: String,
    pub timezone: Option<String>,
    pub latitude: f64,
    pub longitude: f64,
    pub altitude: f64,
    pub ayanamsa: String,
    pub house_system: String,
    pub true_nodes: bool,
    pub ephemeris: String,
    pub longitude_type: String,
    pub calculation_version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PlanetPosition {
    pub planet: Planet,
    pub longitude: f64,
    pub latitude: f64,
    pub speed: f64,
    pub is_retrograde: bool,
    pub sign: Option<Sign>,
    pub nakshatra: Option<Nakshatra>,
    pub house: Option<u8>,
    pub divisional_signs: std::collections::HashMap<u32, Sign>,
    pub is_exalted: bool,
    pub is_debilitated: bool,
    pub is_own_sign: bool,
    pub is_moolatrikona: bool,
    pub is_vargottama: bool,
    pub shadbala: Option<Shadbala>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct HouseCusp {
    pub house: u8,
    pub cusp: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YogaResult {
    /// Classical name of the yoga (e.g. "Gajakesari Yoga").
    pub name: String,
    /// Sanskrit category: "Raja", "Dhana", "Mahapurusha", "Nabhasa", "Other".
    pub category: String,
    /// Classical description with source text citation.
    pub description: String,
    /// Planets directly forming the yoga.
    pub planets_involved: Vec<Planet>,
    /// Whether the yoga is present. Always true when returned by identify_yogas().
    pub is_present: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct KutaResult {
    pub varna: f64,
    pub vasya: f64,
    pub tara: f64,
    pub yoni: f64,
    pub graha_maitri: f64,
    pub gana: f64,
    pub bhakut: f64,
    pub nadi: f64,
    pub total_score: f64,
    pub max_score: f64,
    pub is_compatible: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Chart {
    pub datetime: DateTime<Utc>,
    pub location: GeoPosition,
    pub ayanamsa: AyanamsaMode,
    pub planets: Vec<PlanetPosition>,
    pub ascendant: f64,
    pub houses: Vec<HouseCusp>,
    pub dasha: std::collections::HashMap<String, Vec<crate::dasha::base::DashaPeriod>>,
    pub divisional_charts: std::collections::HashMap<u32, Vec<VargaPosition>>,
    pub karakas: std::collections::HashMap<Planet, Karaka>,
    pub aspects: Vec<AspectRelation>,
    pub ashtakavarga: Option<Ashtakavarga>,
    pub yogas: Vec<YogaResult>,
    pub metadata: CalculationMetadata,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Shadbala {
    pub sthana_bala: f64,
    pub dik_bala: f64,
    pub kala_bala: f64,
    pub chesta_bala: f64,
    pub naisargika_bala: f64,
    pub drik_bala: f64,
    pub total: f64,    // sum of all 6
    pub required: f64, // minimum required (planet-dependent)
    pub is_sufficient: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct AspectRelation {
    pub from_planet: Planet,
    pub to_house: u8,
    pub to_planet: Option<Planet>, // if a planet occupies the aspected house
    pub strength: f64,             // 1.0 = full, 0.75 = 3/4, 0.5 = half
    pub is_special: bool,          // true for Mars/Jupiter/Saturn special aspects
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Ashtakavarga {
    /// Bhinnashtakavarga: points per planet per house [planet][house 1..12]
    pub binna: std::collections::HashMap<String, [u8; 12]>,
    /// Sarvashtakavarga: total points per house [house 1..12]
    pub sarva: [u8; 12],
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize, Default)]
pub enum AyanamsaMode {
    #[default]
    Lahiri,
    Raman,
    Krishnamurti,
    TrueChitra,
    TruePushya,
    Custom(f64),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum HouseSystem {
    Equal,
    Placidus,
    Koch,
    WholeSign,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VargaPosition {
    pub planet: Planet,
    pub source_longitude: f64,
    pub varga: u32,
    pub varga_sign: Sign,
    pub varga_index: u32,
    /// Midpoint of varga sign for chart drawing only — not a true planetary longitude.
    pub display_longitude: Option<f64>,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PanchangaMode {
    CivilDay,
    SunriseDay,
}

// Panchanga output structs
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TithiInfo {
    pub index: i32, // 1..30
    pub name: String,
    pub paksha: String, // Shukla or Krishna
    pub start_jd: f64,
    pub start_time_utc: DateTime<Utc>,
    pub start_time_local: String,
    pub end_jd: f64,
    pub end_time_utc: DateTime<Utc>,
    pub end_time_local: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NakshatraInfo {
    pub index: i32,
    pub name: String,
    pub pada: i32,
    pub start_jd: f64,
    pub start_time_utc: DateTime<Utc>,
    pub start_time_local: String,
    pub end_jd: f64,
    pub end_time_utc: DateTime<Utc>,
    pub end_time_local: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YogaInfo {
    pub index: i32, // 1..27
    pub name: String,
    pub start_jd: f64,
    pub start_time_utc: DateTime<Utc>,
    pub start_time_local: String,
    pub end_jd: f64,
    pub end_time_utc: DateTime<Utc>,
    pub end_time_local: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KaranaInfo {
    pub index: i32,
    pub name: String,
    pub start_jd: f64,
    pub start_time_utc: DateTime<Utc>,
    pub start_time_local: String,
    pub end_jd: f64,
    pub end_time_utc: DateTime<Utc>,
    pub end_time_local: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VaraInfo {
    pub index: i32, // 0..6
    pub name: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PanchangaMetadata {
    pub timezone: String,
    pub mode: String,
    pub local_datetime: String,
    pub utc_datetime: String,
    pub ayanamsa: String,
    pub true_nodes: bool,
    pub calculation_version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Panchanga {
    pub tithi: TithiInfo,
    pub nakshatra: NakshatraInfo,
    pub yoga: YogaInfo,
    pub karana: KaranaInfo,
    pub vara: VaraInfo,
    pub metadata: PanchangaMetadata,
    pub warnings: Vec<String>,
}
