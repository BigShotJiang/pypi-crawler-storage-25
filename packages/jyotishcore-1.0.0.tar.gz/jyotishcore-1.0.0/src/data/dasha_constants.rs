use crate::data::types::Planet;

/// Vimshottari Dasha periods (in years) for each planet.
pub const VIMSHOTTARI_PERIODS: [(Planet, f64); 9] = [
    (Planet::Sun, 6.0),
    (Planet::Moon, 10.0),
    (Planet::Mars, 7.0),
    (Planet::Rahu, 18.0),
    (Planet::Jupiter, 16.0),
    (Planet::Saturn, 19.0),
    (Planet::Mercury, 17.0),
    (Planet::Ketu, 7.0),
    (Planet::Venus, 20.0),
];

/// The order of planets in Vimshottari Dasha (starting from Sun).
pub const VIMSHOTTARI_ORDER: [Planet; 9] = [
    Planet::Sun,
    Planet::Moon,
    Planet::Mars,
    Planet::Rahu,
    Planet::Jupiter,
    Planet::Saturn,
    Planet::Mercury,
    Planet::Ketu,
    Planet::Venus,
];

/// Nakshatra lords in order (Ashwini to Revati).
pub const NAKSHATRA_LORDS: [Planet; 27] = [
    Planet::Ketu,
    Planet::Venus,
    Planet::Sun,
    Planet::Moon,
    Planet::Mars,
    Planet::Rahu,
    Planet::Jupiter,
    Planet::Saturn,
    Planet::Mercury,
    Planet::Ketu,
    Planet::Venus,
    Planet::Sun,
    Planet::Moon,
    Planet::Mars,
    Planet::Rahu,
    Planet::Jupiter,
    Planet::Saturn,
    Planet::Mercury,
    Planet::Ketu,
    Planet::Venus,
    Planet::Sun,
    Planet::Moon,
    Planet::Mars,
    Planet::Rahu,
    Planet::Jupiter,
    Planet::Saturn,
    Planet::Mercury,
];
