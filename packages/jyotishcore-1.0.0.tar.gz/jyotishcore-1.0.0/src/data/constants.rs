// Swiss Ephemeris planet IDs
pub const SE_SUN: i32 = 0;
pub const SE_MOON: i32 = 1;
pub const SE_MERCURY: i32 = 2;
pub const SE_VENUS: i32 = 3;
pub const SE_MARS: i32 = 4;
pub const SE_JUPITER: i32 = 5;
pub const SE_SATURN: i32 = 6;
pub const SE_MEAN_NODE: i32 = 10; // Rahu/Ketu mean
pub const SE_TRUE_NODE: i32 = 11;

// Ayanamsa flags
pub const SIDM_LAHIRI: i32 = 1;
pub const SIDM_RAMAN: i32 = 3;
pub const SIDM_KRISHNAMURTI: i32 = 5;
pub const SIDM_TRUE_CITRA: i32 = 7;
pub const SIDM_TRUE_PUSHYA: i32 = 8;
pub const SIDM_USER: i32 = 255;

// Ephemeris flags
pub const FLG_SWIEPH: i32 = 0; // Auto-select (prefer files, fallback to analytical)
pub const FLG_SIDEREAL: i32 = 64 * 1024;
pub const FLG_SPEED: i32 = 256;
pub const FLG_TOPOCTR: i32 = 32 * 1024;

/// (planet, moolatrikona_sign, degree_start, degree_end)
pub const MOOLATRIKONA_RANGES: &[(
    crate::data::types::Planet,
    crate::data::types::Sign,
    f64,
    f64,
)] = &[
    (
        crate::data::types::Planet::Sun,
        crate::data::types::Sign::Leo,
        0.0,
        20.0,
    ),
    (
        crate::data::types::Planet::Moon,
        crate::data::types::Sign::Taurus,
        4.0,
        30.0,
    ),
    (
        crate::data::types::Planet::Mars,
        crate::data::types::Sign::Aries,
        0.0,
        12.0,
    ),
    (
        crate::data::types::Planet::Mercury,
        crate::data::types::Sign::Virgo,
        16.0,
        20.0,
    ),
    (
        crate::data::types::Planet::Jupiter,
        crate::data::types::Sign::Sagittarius,
        0.0,
        10.0,
    ),
    (
        crate::data::types::Planet::Venus,
        crate::data::types::Sign::Libra,
        0.0,
        15.0,
    ),
    (
        crate::data::types::Planet::Saturn,
        crate::data::types::Sign::Aquarius,
        0.0,
        20.0,
    ),
];

/// Naisargika Bala (natural strength in Shashtiamsas)
pub const NAISARGIKA_BALA: &[(crate::data::types::Planet, f64)] = &[
    (crate::data::types::Planet::Sun, 60.0),
    (crate::data::types::Planet::Moon, 51.43),
    (crate::data::types::Planet::Venus, 42.86),
    (crate::data::types::Planet::Jupiter, 34.29),
    (crate::data::types::Planet::Mercury, 25.71),
    (crate::data::types::Planet::Mars, 17.14),
    (crate::data::types::Planet::Saturn, 8.57),
];

/// Dik Bala — full strength house for each planet
pub const DIK_BALA_HOUSE: &[(crate::data::types::Planet, u8)] = &[
    (crate::data::types::Planet::Sun, 1),
    (crate::data::types::Planet::Jupiter, 1),
    (crate::data::types::Planet::Mercury, 1),
    (crate::data::types::Planet::Moon, 4),
    (crate::data::types::Planet::Venus, 4),
    (crate::data::types::Planet::Mars, 10),
    (crate::data::types::Planet::Saturn, 7),
];

/// Minimum required Shadbala (Shashtiamsas)
pub const MIN_SHADBALA: &[(crate::data::types::Planet, f64)] = &[
    (crate::data::types::Planet::Sun, 390.0),
    (crate::data::types::Planet::Moon, 360.0),
    (crate::data::types::Planet::Mars, 300.0),
    (crate::data::types::Planet::Mercury, 420.0),
    (crate::data::types::Planet::Jupiter, 390.0),
    (crate::data::types::Planet::Venus, 330.0),
    (crate::data::types::Planet::Saturn, 300.0),
];
