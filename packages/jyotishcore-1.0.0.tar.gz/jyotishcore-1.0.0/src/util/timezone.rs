use chrono::{DateTime, NaiveDateTime, TimeZone, Utc};
use chrono_tz::Tz;

pub fn local_to_utc(
    year: i32,
    month: u32,
    day: u32,
    hour: u32,
    minute: u32,
    second: u32,
    tz_str: &str,
) -> Result<DateTime<Utc>, String> {
    let tz: Tz = tz_str
        .parse()
        .map_err(|_| format!("Unknown timezone: {}", tz_str))?;
    let naive = NaiveDateTime::new(
        chrono::NaiveDate::from_ymd_opt(year, month, day).ok_or("Invalid date")?,
        chrono::NaiveTime::from_hms_opt(hour, minute, second).ok_or("Invalid time")?,
    );

    match tz.from_local_datetime(&naive) {
        chrono::LocalResult::Single(dt) => Ok(dt.with_timezone(&Utc)),
        chrono::LocalResult::Ambiguous(_, _) => Err(format!(
            "Ambiguous local time in {}. Provide UTC or an explicit DST fold policy.",
            tz_str
        )),
        chrono::LocalResult::None => Err(format!("Invalid local time in {} (DST gap)", tz_str)),
    }
}
