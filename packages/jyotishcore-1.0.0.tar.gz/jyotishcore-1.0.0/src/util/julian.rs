use crate::ephemeris::swe_bindings::Ephemeris;
use chrono::{DateTime, Datelike, Timelike, Utc};

pub fn date_to_julian_day(dt: DateTime<Utc>) -> f64 {
    let year = dt.year();
    let month = dt.month() as i32;
    let day = dt.day() as i32;
    let hour = dt.hour() as f64 + (dt.minute() as f64 / 60.0) + (dt.second() as f64 / 3600.0);
    
    Ephemeris::get_julian_day(year, month, day, hour)
}
