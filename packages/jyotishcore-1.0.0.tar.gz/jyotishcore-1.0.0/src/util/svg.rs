use crate::data::types::{Chart, Planet};

pub fn render_north_indian_svg(chart: &Chart) -> String {
    let width = 500;
    let height = 500;
    let mut svg = format!(
        r#"<svg width="{}" height="{}" viewBox="0 0 {} {}" xmlns="http://www.w3.org/2000/svg">"#,
        width, height, width, height
    );

    // Background
    svg.push_str(r##"<rect width="100%" height="100%" fill="#1a1a1a" />"##);

    // Grid Lines (Main Square)
    svg.push_str(r##"<rect x="50" y="50" width="400" height="400" stroke="#444" fill="none" stroke-width="2" />"##);

    // Diagonal Lines
    svg.push_str(r##"<line x1="50" y1="50" x2="450" y2="450" stroke="#444" stroke-width="2" />"##);
    svg.push_str(r##"<line x1="450" y1="50" x2="50" y2="450" stroke="#444" stroke-width="2" />"##);

    // Inner Diamond
    svg.push_str(r##"<polygon points="250,50 450,250 250,450 50,250" stroke="#444" fill="none" stroke-width="2" />"##);

    // House Coordinates (Center of each house triangle/diamond)
    let house_centers = [
        (250, 150), // 1
        (150, 100), // 2
        (100, 150), // 3
        (150, 250), // 4
        (100, 350), // 5
        (150, 400), // 6
        (250, 350), // 7
        (350, 400), // 8
        (400, 350), // 9
        (350, 250), // 10
        (400, 150), // 11
        (350, 100), // 12
    ];

    // Render Signs and Planets
    for (i, &(cx, cy)) in house_centers.iter().enumerate() {
        let house_num = (i + 1) as u8;

        // Find sign for this house
        if let Some(h_data) = chart.houses.iter().find(|h| h.house == house_num) {
            let sign_num = crate::zodiac::sign_index(h_data.cusp) + 1;
            svg.push_str(&format!(
                r##"<text x="{}" y="{}" fill="#888" font-size="12" text-anchor="middle">{}</text>"##,
                cx, cy - 30, sign_num
            ));
        }

        // Find planets in this house
        let house_planets: Vec<_> = chart
            .planets
            .iter()
            .filter(|p| p.house == Some(house_num))
            .collect();

        let mut py = cy - 10;
        for p in house_planets {
            let p_name = format!("{:?}", p.planet);
            let p_color = match p.planet {
                Planet::Sun => "#ffcc00",
                Planet::Moon => "#ffffff",
                Planet::Mars => "#ff4444",
                Planet::Jupiter => "#ffff44",
                _ => "#00ccff",
            };
            svg.push_str(&format!(
                r#"<text x="{}" y="{}" fill="{}" font-size="14" font-weight="bold" text-anchor="middle">{}</text>"#,
                cx, py, p_color, &p_name[0..2]
            ));
            py += 18;
        }
    }

    svg.push_str("</svg>");
    svg
}
