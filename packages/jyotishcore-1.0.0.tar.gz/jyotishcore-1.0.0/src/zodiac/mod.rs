use crate::data::types::{Nakshatra, Planet, Sign};

pub const NAKSHATRA_SPAN_DEG: f64 = 360.0 / 27.0;
pub const PADA_SPAN_DEG: f64 = NAKSHATRA_SPAN_DEG / 4.0;

pub fn normalize_deg(longitude: f64) -> f64 {
    longitude.rem_euclid(360.0)
}

pub fn sign_index(longitude: f64) -> u8 {
    (normalize_deg(longitude) / 30.0).floor() as u8
}

pub fn degree_in_sign(longitude: f64) -> f64 {
    normalize_deg(longitude) % 30.0
}

pub fn sign_from_longitude(longitude: f64) -> Sign {
    match sign_index(longitude) {
        0 => Sign::Aries,
        1 => Sign::Taurus,
        2 => Sign::Gemini,
        3 => Sign::Cancer,
        4 => Sign::Leo,
        5 => Sign::Virgo,
        6 => Sign::Libra,
        7 => Sign::Scorpio,
        8 => Sign::Sagittarius,
        9 => Sign::Capricorn,
        10 => Sign::Aquarius,
        _ => Sign::Pisces,
    }
}

pub fn nakshatra_index(longitude: f64) -> u8 {
    (normalize_deg(longitude) / NAKSHATRA_SPAN_DEG).floor() as u8
}

pub fn nakshatra_from_longitude(longitude: f64) -> Nakshatra {
    match nakshatra_index(longitude) {
        0 => Nakshatra::Ashwini,
        1 => Nakshatra::Bharani,
        2 => Nakshatra::Krittika,
        3 => Nakshatra::Rohini,
        4 => Nakshatra::Mrigashirsha,
        5 => Nakshatra::Ardra,
        6 => Nakshatra::Punarvasu,
        7 => Nakshatra::Pushya,
        8 => Nakshatra::Ashlesha,
        9 => Nakshatra::Magha,
        10 => Nakshatra::PurvaPhalguni,
        11 => Nakshatra::UttaraPhalguni,
        12 => Nakshatra::Hasta,
        13 => Nakshatra::Chitra,
        14 => Nakshatra::Swati,
        15 => Nakshatra::Vishakha,
        16 => Nakshatra::Anuradha,
        17 => Nakshatra::Jyeshtha,
        18 => Nakshatra::Mula,
        19 => Nakshatra::PurvaAshadha,
        20 => Nakshatra::UttaraAshadha,
        21 => Nakshatra::Shravana,
        22 => Nakshatra::Dhanishta,
        23 => Nakshatra::Shatabhisha,
        24 => Nakshatra::PurvaBhadrapada,
        25 => Nakshatra::UttaraBhadrapada,
        _ => Nakshatra::Revati,
    }
}

pub fn pada_index(longitude: f64) -> u8 {
    ((normalize_deg(longitude) % NAKSHATRA_SPAN_DEG) / PADA_SPAN_DEG).floor() as u8
}

pub fn degree_in_nakshatra(longitude: f64) -> f64 {
    normalize_deg(longitude) % NAKSHATRA_SPAN_DEG
}

pub fn nakshatra_lord(index: u8) -> Planet {
    const LORDS: [Planet; 9] = [
        Planet::Ketu,
        Planet::Venus,
        Planet::Sun,
        Planet::Moon,
        Planet::Mars,
        Planet::Rahu,
        Planet::Jupiter,
        Planet::Saturn,
        Planet::Mercury,
    ];
    LORDS[index as usize % LORDS.len()]
}

pub fn tithi_index(moon_longitude: f64, sun_longitude: f64) -> u8 {
    let diff = normalize_deg(moon_longitude - sun_longitude);
    (diff / 12.0).floor() as u8
}

pub fn yoga_index(moon_longitude: f64, sun_longitude: f64) -> u8 {
    (normalize_deg(moon_longitude + sun_longitude) / NAKSHATRA_SPAN_DEG).floor() as u8
}

pub fn karana_index(moon_longitude: f64, sun_longitude: f64) -> u8 {
    let diff = normalize_deg(moon_longitude - sun_longitude);
    (diff / 6.0).floor() as u8
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sign_boundaries_are_exact() {
        assert_eq!(sign_from_longitude(0.0), Sign::Aries);
        assert_eq!(sign_from_longitude(29.999_999), Sign::Aries);
        assert_eq!(sign_from_longitude(30.0), Sign::Taurus);
        assert_eq!(sign_from_longitude(359.999_999), Sign::Pisces);
        assert_eq!(sign_from_longitude(360.0), Sign::Aries);
        assert_eq!(sign_from_longitude(-0.1), Sign::Pisces);
    }

    #[test]
    fn nakshatra_and_pada_boundaries_are_exact() {
        assert_eq!(nakshatra_from_longitude(0.0), Nakshatra::Ashwini);
        assert_eq!(
            nakshatra_from_longitude(NAKSHATRA_SPAN_DEG),
            Nakshatra::Bharani
        );
        assert_eq!(pada_index(0.0), 0);
        assert_eq!(pada_index(PADA_SPAN_DEG), 1);
        assert_eq!(nakshatra_from_longitude(360.0), Nakshatra::Ashwini);
    }
}
