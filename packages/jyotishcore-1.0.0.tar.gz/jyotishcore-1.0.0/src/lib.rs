#![doc = include_str!("../README.md")]

pub mod calc;
pub mod calendars;
pub mod charts;
pub mod dasha;
pub mod data;
pub mod ephemeris;
pub mod error;
pub mod knowledge;
pub mod locale;
pub mod strength;
pub mod util;
pub mod zodiac;

#[cfg(feature = "python")]
pub mod python;

// Re-export key types for easy use
pub use data::types::*;
pub use ephemeris::service::Ephemeris;
pub use error::JyotishError;
