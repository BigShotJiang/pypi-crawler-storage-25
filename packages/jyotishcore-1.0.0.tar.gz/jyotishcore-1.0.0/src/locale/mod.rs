use serde_json::Value;
use std::collections::HashMap;
use std::sync::OnceLock;

#[derive(Debug, Clone)]
pub struct LocaleData {
    pub tithi_names: Vec<String>,
    pub nakshatra_names: Vec<String>,
    pub month_names: Vec<String>,
    pub festivals: HashMap<String, String>,
}

static LOCALES: OnceLock<HashMap<String, LocaleData>> = OnceLock::new();

pub fn get_locale(lang: &str) -> Option<&'static LocaleData> {
    let map = LOCALES.get_or_init(|| {
        let mut m = HashMap::new();
        m.insert("ne_NP".to_string(), load_locale("ne_NP"));
        m.insert("hi_IN".to_string(), load_locale("hi_IN"));
        m
    });
    map.get(lang)
}

fn load_locale(lang: &str) -> LocaleData {
    let json_str = match lang {
        "ne_NP" => include_str!("../../data/locale/ne_NP.json"),
        "hi_IN" => include_str!("../../data/locale/hi_IN.json"),
        _ => panic!("Locale not supported"),
    };

    let v: Value = serde_json::from_str(json_str).expect("Failed to parse locale");
    LocaleData {
        tithi_names: v["tithi_names"]
            .as_array()
            .unwrap()
            .iter()
            .map(|x| x.as_str().unwrap().to_string())
            .collect(),
        nakshatra_names: v["nakshatra_names"]
            .as_array()
            .unwrap()
            .iter()
            .map(|x| x.as_str().unwrap().to_string())
            .collect(),
        month_names: v["month_names"]
            .as_array()
            .unwrap()
            .iter()
            .map(|x| x.as_str().unwrap().to_string())
            .collect(),
        festivals: v["festivals"]
            .as_object()
            .unwrap()
            .iter()
            .map(|(k, v)| (k.clone(), v.as_str().unwrap().to_string()))
            .collect(),
    }
}
