use crate::data::types::{Chart, Planet, Sign, YogaResult};

/// Helper to build a YogaResult marked as present.
fn present(name: &str, category: &str, description: &str, planets: Vec<Planet>) -> YogaResult {
    YogaResult {
        name: name.to_string(),
        category: category.to_string(),
        description: description.to_string(),
        planets_involved: planets,
        is_present: true,
    }
}

/// Identify classical yogas (planetary combinations) in the given chart.
///
/// # Methodology
/// Each yoga is defined by an exact condition from a classical text (cited inline).
/// Only yogas with unambiguous classical definitions are included.
/// Returns only yogas that are **present** in the chart — absent yogas are not listed.
///
/// # Sources
/// - BPHS: Brihat Parashara Hora Shastra (translated by G.C. Sharma / Girish Chand Sharma)
/// - JS: Jaimini Sutras
///
/// # Important Notice
/// Yoga identification does not substitute for a qualified astrologer's interpretation.
/// Many classical yogas have cancellation rules (Bhanga) that require individual assessment.
pub fn identify_yogas(chart: &Chart) -> Vec<YogaResult> {
    let mut yogas = Vec::new();

    // ── Pancha Mahapurusha Yogas ─────────────────────────────────────────────
    // BPHS Ch. 75: "If Mars, Mercury, Jupiter, Venus or Saturn occupies a Kendra
    // (1st, 4th, 7th, 10th) from the Lagna, and is in its own sign or exaltation,
    // the native is blessed with a Mahapurusha Yoga."
    yogas.extend(pancha_mahapurusha(chart));

    // ── Gajakesari Yoga ──────────────────────────────────────────────────────
    // BPHS Ch. 91, v. 1: "If Jupiter is in a Kendra from the Moon, the yoga called
    // Gajakesari is formed. The native is intelligent, virtuous, and long-lived."
    if let Some(y) = gajakesari(chart) {
        yogas.push(y);
    }

    // ── Budhaditya Yoga ──────────────────────────────────────────────────────
    // BPHS Ch. 91, v. 17: "Sun and Mercury conjunct in the same sign form Budhaditya.
    // The native is highly intelligent, skilled in various arts, and respected."
    if let Some(y) = budhaditya(chart) {
        yogas.push(y);
    }

    // ── Chandra-Mangala Yoga ─────────────────────────────────────────────────
    // BPHS Ch. 91, v. 21: "When Moon and Mars are conjunct or in mutual aspect,
    // Chandra-Mangala Yoga arises. The native earns wealth through multiple means."
    if let Some(y) = chandra_mangala(chart) {
        yogas.push(y);
    }

    // ── Vesi Yoga ────────────────────────────────────────────────────────────
    // BPHS Ch. 91, v. 10: "When planets (other than Moon) occupy the 2nd from Sun,
    // Vesi Yoga is formed. The native is truthful, fortunate, and happy."
    if let Some(y) = vesi(chart) {
        yogas.push(y);
    }

    // ── Vosi Yoga ────────────────────────────────────────────────────────────
    // BPHS Ch. 91, v. 11: "When planets (other than Moon) occupy the 12th from Sun,
    // Vosi Yoga is formed. The native is wise and virtuous."
    if let Some(y) = vosi(chart) {
        yogas.push(y);
    }

    // ── Ubhayachari Yoga ─────────────────────────────────────────────────────
    // BPHS Ch. 91, v. 12: "When both Vesi and Vosi apply (planets in both 2nd and
    // 12th from Sun), Ubhayachari Yoga is formed. The native resembles a king."
    if let Some(y) = ubhayachari(chart) {
        yogas.push(y);
    }

    // ── Neechabhanga Raja Yoga ───────────────────────────────────────────────
    // BPHS Ch. 34, v. 2–4: "When a debilitated planet's depositor (lord of debilitation
    // sign) or its exaltation lord is in a Kendra from the Lagna or Moon, the debilitation
    // is cancelled (Neechabhanga) and becomes a Raja Yoga."
    yogas.extend(neechabhanga_raja_yoga(chart));

    // ── Dharma-Karmadhipati Yoga (Raja Yoga) ─────────────────────────────────
    // BPHS Ch. 41, v. 1–2: "When the lords of the 9th and 10th houses are conjunct,
    // mutually aspected, or exchange signs, a powerful Raja Yoga is formed."
    if let Some(y) = dharma_karmadhipati(chart) {
        yogas.push(y);
    }

    yogas
}

// ─── Helper functions ────────────────────────────────────────────────────────

/// Returns the house a planet occupies (1–12), or None.
fn planet_house(chart: &Chart, planet: Planet) -> Option<u8> {
    chart
        .planets
        .iter()
        .find(|p| p.planet == planet)
        .and_then(|p| p.house)
}

/// Returns the sign a planet occupies, or None.
fn planet_sign(chart: &Chart, planet: Planet) -> Option<Sign> {
    chart
        .planets
        .iter()
        .find(|p| p.planet == planet)
        .and_then(|p| p.sign)
}

/// Checks if a house is a Kendra (angular house: 1, 4, 7, 10).
fn is_kendra(house: u8) -> bool {
    matches!(house, 1 | 4 | 7 | 10)
}

/// Checks if `house_b` is in Kendra (1,4,7,10) from `house_a`.
fn is_kendra_from(house_a: u8, house_b: u8) -> bool {
    let diff = ((house_b as i32 - house_a as i32).rem_euclid(12)) as u8;
    matches!(diff, 0 | 3 | 6 | 9)
}

/// Returns the lord of a house based on the house's sign (natural zodiac from Lagna).
/// This requires knowing which sign occupies the house — we use house number mod 12
/// with the Lagna sign as house 1.
fn house_lord(chart: &Chart, house: u8) -> Option<Planet> {
    // Find the sign of the given house
    let asc_sign_idx = (chart.ascendant / 30.0).floor() as u8 % 12;
    let house_sign_idx = (asc_sign_idx + house - 1) % 12;
    Some(sign_lord_planet(house_sign_idx))
}

/// Returns the ruling planet of a sign index (0=Aries...11=Pisces).
fn sign_lord_planet(sign_idx: u8) -> Planet {
    match sign_idx {
        0 | 7 => Planet::Mars,     // Aries, Scorpio
        1 | 6 => Planet::Venus,    // Taurus, Libra
        2 | 5 => Planet::Mercury,  // Gemini, Virgo
        3 => Planet::Moon,         // Cancer
        4 => Planet::Sun,          // Leo
        8 | 11 => Planet::Jupiter, // Sagittarius, Pisces
        9 | 10 => Planet::Saturn,  // Capricorn, Aquarius
        _ => Planet::Sun,
    }
}

// ─── Individual Yoga detectors ────────────────────────────────────────────────

/// Pancha Mahapurusha Yogas (5 great person yogas).
/// Each formed when the relevant planet is in its own sign or exaltation AND in a Kendra.
/// Reference: BPHS Ch. 75.
fn pancha_mahapurusha(chart: &Chart) -> Vec<YogaResult> {
    let mut yogas = Vec::new();

    // (planet, yoga name, condition description, exaltation sign, own signs)
    let configs: &[(Planet, &str, &str, Sign, &[Sign])] = &[
        (
            Planet::Mars,
            "Ruchaka Yoga",
            "BPHS Ch. 75, v. 1: Mars in own sign (Aries/Scorpio) or exaltation (Capricorn) in a Kendra. Native is courageous, muscular, and victorious.",
            Sign::Capricorn,
            &[Sign::Aries, Sign::Scorpio],
        ),
        (
            Planet::Mercury,
            "Bhadra Yoga",
            "BPHS Ch. 75, v. 2: Mercury in own sign (Gemini/Virgo) or exaltation (Virgo) in a Kendra. Native is learned, eloquent, and prosperous.",
            Sign::Virgo,
            &[Sign::Gemini, Sign::Virgo],
        ),
        (
            Planet::Jupiter,
            "Hamsa Yoga",
            "BPHS Ch. 75, v. 3: Jupiter in own sign (Sagittarius/Pisces) or exaltation (Cancer) in a Kendra. Native is virtuous, spiritually inclined, and respected.",
            Sign::Cancer,
            &[Sign::Sagittarius, Sign::Pisces],
        ),
        (
            Planet::Venus,
            "Malavya Yoga",
            "BPHS Ch. 75, v. 4: Venus in own sign (Taurus/Libra) or exaltation (Pisces) in a Kendra. Native is beautiful, wealthy, and blessed with pleasures.",
            Sign::Pisces,
            &[Sign::Taurus, Sign::Libra],
        ),
        (
            Planet::Saturn,
            "Shasha Yoga",
            "BPHS Ch. 75, v. 5: Saturn in own sign (Capricorn/Aquarius) or exaltation (Libra) in a Kendra. Native is powerful, disciplined, and long-lived.",
            Sign::Libra,
            &[Sign::Capricorn, Sign::Aquarius],
        ),
    ];

    for &(planet, name, desc, exalt_sign, own_signs) in configs {
        if let (Some(sign), Some(house)) = (planet_sign(chart, planet), planet_house(chart, planet))
        {
            let in_kendra = is_kendra(house);
            let in_own_or_exalt = sign == exalt_sign || own_signs.contains(&sign);
            if in_kendra && in_own_or_exalt {
                yogas.push(present(name, "Mahapurusha", desc, vec![planet]));
            }
        }
    }

    yogas
}

/// Gajakesari Yoga: Jupiter in a Kendra from the Moon.
/// Reference: BPHS Ch. 91, v. 1.
fn gajakesari(chart: &Chart) -> Option<YogaResult> {
    let moon_house = planet_house(chart, Planet::Moon)?;
    let jup_house = planet_house(chart, Planet::Jupiter)?;

    if is_kendra_from(moon_house, jup_house) {
        Some(present(
            "Gajakesari Yoga",
            "Raja",
            "BPHS Ch. 91, v. 1: Jupiter in a Kendra (1st, 4th, 7th, or 10th) from the Moon. \
             The native is intelligent, virtuous, renowned, and long-lived.",
            vec![Planet::Moon, Planet::Jupiter],
        ))
    } else {
        None
    }
}

/// Budhaditya Yoga: Sun and Mercury conjunct in the same sign.
/// Reference: BPHS Ch. 91, v. 17.
fn budhaditya(chart: &Chart) -> Option<YogaResult> {
    let sun_sign = planet_sign(chart, Planet::Sun)?;
    let merc_sign = planet_sign(chart, Planet::Mercury)?;

    if sun_sign == merc_sign {
        Some(present(
            "Budhaditya Yoga",
            "Other",
            "BPHS Ch. 91, v. 17: Sun and Mercury conjunct in the same sign. \
             The native is intelligent, skilled in multiple arts, and occupationally successful.",
            vec![Planet::Sun, Planet::Mercury],
        ))
    } else {
        None
    }
}

/// Chandra-Mangala Yoga: Moon and Mars conjunct or in mutual aspect.
/// Reference: BPHS Ch. 91, v. 21.
fn chandra_mangala(chart: &Chart) -> Option<YogaResult> {
    let moon_sign = planet_sign(chart, Planet::Moon)?;
    let mars_sign = planet_sign(chart, Planet::Mars)?;
    let moon_house = planet_house(chart, Planet::Moon)?;
    let mars_house = planet_house(chart, Planet::Mars)?;

    let conjunct = moon_sign == mars_sign;
    // Mutual aspect: Moon aspects 7th from itself, Mars aspects 4th, 7th, 8th
    let diff = ((mars_house as i32 - moon_house as i32).rem_euclid(12)) as u8;
    let mars_aspects_moon = matches!(diff, 0 | 3 | 6 | 7); // 4th(3), 7th(6), 8th(7) from Mars
    let moon_aspects_mars = diff == 6; // Moon aspects only 7th

    if conjunct || mars_aspects_moon || moon_aspects_mars {
        Some(present(
            "Chandra-Mangala Yoga",
            "Dhana",
            "BPHS Ch. 91, v. 21: Moon and Mars are conjunct or in mutual aspect. \
             The native earns wealth through varied means and may be involved in trade or commerce.",
            vec![Planet::Moon, Planet::Mars],
        ))
    } else {
        None
    }
}

/// Vesi Yoga: Planets (excluding Moon) in the 2nd house from the Sun.
/// Reference: BPHS Ch. 91, v. 10.
fn vesi(chart: &Chart) -> Option<YogaResult> {
    let sun_house = planet_house(chart, Planet::Sun)?;
    let second_from_sun = (sun_house % 12) + 1;

    let mut planets_involved = vec![Planet::Sun];
    let mut found = false;

    for pos in &chart.planets {
        if pos.planet == Planet::Moon || pos.planet == Planet::Sun {
            continue;
        }
        if pos.house == Some(second_from_sun) {
            planets_involved.push(pos.planet);
            found = true;
        }
    }

    if found {
        Some(present(
            "Vesi Yoga",
            "Other",
            "BPHS Ch. 91, v. 10: Planets (other than Moon) in the 2nd from Sun. \
             The native is truthful, fortunate, happy, and has a long life.",
            planets_involved,
        ))
    } else {
        None
    }
}

/// Vosi Yoga: Planets (excluding Moon) in the 12th house from the Sun.
/// Reference: BPHS Ch. 91, v. 11.
fn vosi(chart: &Chart) -> Option<YogaResult> {
    let sun_house = planet_house(chart, Planet::Sun)?;
    let twelfth_from_sun = if sun_house == 1 { 12 } else { sun_house - 1 };

    let mut planets_involved = vec![Planet::Sun];
    let mut found = false;

    for pos in &chart.planets {
        if pos.planet == Planet::Moon || pos.planet == Planet::Sun {
            continue;
        }
        if pos.house == Some(twelfth_from_sun) {
            planets_involved.push(pos.planet);
            found = true;
        }
    }

    if found {
        Some(present(
            "Vosi Yoga",
            "Other",
            "BPHS Ch. 91, v. 11: Planets (other than Moon) in the 12th from Sun. \
             The native is scholarly, wise, virtuous, and diligent.",
            planets_involved,
        ))
    } else {
        None
    }
}

/// Ubhayachari Yoga: Both Vesi and Vosi apply (planets in 2nd AND 12th from Sun).
/// Reference: BPHS Ch. 91, v. 12.
fn ubhayachari(chart: &Chart) -> Option<YogaResult> {
    let sun_house = planet_house(chart, Planet::Sun)?;
    let second = (sun_house % 12) + 1;
    let twelfth = if sun_house == 1 { 12 } else { sun_house - 1 };

    let mut has_second = false;
    let mut has_twelfth = false;
    let mut planets_involved = vec![Planet::Sun];

    for pos in &chart.planets {
        if pos.planet == Planet::Moon || pos.planet == Planet::Sun {
            continue;
        }
        if pos.house == Some(second) {
            has_second = true;
            planets_involved.push(pos.planet);
        }
        if pos.house == Some(twelfth) {
            has_twelfth = true;
            if !planets_involved.contains(&pos.planet) {
                planets_involved.push(pos.planet);
            }
        }
    }

    if has_second && has_twelfth {
        Some(present(
            "Ubhayachari Yoga",
            "Raja",
            "BPHS Ch. 91, v. 12: Planets (other than Moon) in both 2nd and 12th from Sun. \
             The native is king-like, powerful, eloquent, and commands great respect.",
            planets_involved,
        ))
    } else {
        None
    }
}

/// Neechabhanga Raja Yoga: Debilitation cancelled and converted to a strength.
///
/// Condition (per BPHS Ch. 34, v. 2–4):
/// A planet is debilitated AND one of the following applies:
/// 1. The lord of the debilitation sign is in a Kendra from the Lagna.
/// 2. The lord of the planet's exaltation sign is in a Kendra from the Lagna.
/// 3. The planet owning the sign in which the debilitated planet is placed
///    aspects the debilitated planet (sign aspect, not house).
///
/// Reference: BPHS Ch. 34, v. 2–4.
fn neechabhanga_raja_yoga(chart: &Chart) -> Vec<YogaResult> {
    let mut yogas = Vec::new();

    // (planet, debilitation sign, exaltation sign)
    let debilitation_data: &[(Planet, Sign, Sign)] = &[
        (Planet::Sun, Sign::Libra, Sign::Aries),
        (Planet::Moon, Sign::Scorpio, Sign::Taurus),
        (Planet::Mars, Sign::Cancer, Sign::Capricorn),
        (Planet::Mercury, Sign::Pisces, Sign::Virgo),
        (Planet::Jupiter, Sign::Capricorn, Sign::Cancer),
        (Planet::Venus, Sign::Virgo, Sign::Pisces),
        (Planet::Saturn, Sign::Aries, Sign::Libra),
    ];

    for &(planet, debil_sign, exalt_sign) in debilitation_data {
        if let Some(sign) = planet_sign(chart, planet) {
            if sign != debil_sign {
                continue; // Not debilitated
            }
        } else {
            continue;
        }

        // Check cancellation conditions
        let debil_sign_idx = debil_sign as u8 - 1; // 0-indexed
        let exalt_sign_idx = exalt_sign as u8 - 1;

        let debil_lord = sign_lord_planet(debil_sign_idx);
        let exalt_lord = sign_lord_planet(exalt_sign_idx);

        let debil_lord_kendra = planet_house(chart, debil_lord)
            .map(is_kendra)
            .unwrap_or(false);
        let exalt_lord_kendra = planet_house(chart, exalt_lord)
            .map(is_kendra)
            .unwrap_or(false);

        if debil_lord_kendra || exalt_lord_kendra {
            yogas.push(present(
                "Neechabhanga Raja Yoga",
                "Raja",
                "BPHS Ch. 34, v. 2–4: A debilitated planet's debilitation is cancelled because \
                 its dispositor (lord of debilitation sign) or exaltation lord is in a Kendra. \
                 The initial weakness transforms into a source of strength.",
                vec![planet],
            ));
        }
    }

    yogas
}

/// Dharma-Karmadhipati Yoga: Lords of the 9th and 10th houses in conjunction,
/// mutual aspect, or sign exchange.
/// Reference: BPHS Ch. 41, v. 1–2.
fn dharma_karmadhipati(chart: &Chart) -> Option<YogaResult> {
    let lord_9 = house_lord(chart, 9)?;
    let lord_10 = house_lord(chart, 10)?;

    // They must not be the same planet
    if lord_9 == lord_10 {
        return None;
    }

    let sign_9 = planet_sign(chart, lord_9)?;
    let sign_10 = planet_sign(chart, lord_10)?;
    let house_9_lord = planet_house(chart, lord_9)?;
    let house_10_lord = planet_house(chart, lord_10)?;

    // Conjunction: same sign
    let conjunct = sign_9 == sign_10;

    // Mutual aspect: each aspects the other's house
    let diff_9_to_10 = ((house_10_lord as i32 - house_9_lord as i32).rem_euclid(12)) as u8;
    let diff_10_to_9 = ((house_9_lord as i32 - house_10_lord as i32).rem_euclid(12)) as u8;

    // 9th lord aspects 10th lord's house — lord_9 aspects 7th from itself
    let lord9_aspects_lord10 = diff_9_to_10 == 6;
    // 10th lord aspects 9th lord's house
    let lord10_aspects_lord9 = diff_10_to_9 == 6;

    // Sign exchange (Parivartana): each is in the other's sign
    let asc_sign_idx = (chart.ascendant / 30.0).floor() as u8 % 12;
    let sign_9_idx = (asc_sign_idx + 8) % 12; // 9th house sign
    let sign_10_idx = (asc_sign_idx + 9) % 12; // 10th house sign
    let exchange = (sign_9 as u8 - 1 == sign_10_idx) && (sign_10 as u8 - 1 == sign_9_idx);

    if conjunct || lord9_aspects_lord10 || lord10_aspects_lord9 || exchange {
        Some(present(
            "Dharma-Karmadhipati Yoga",
            "Raja",
            "BPHS Ch. 41, v. 1–2: Lords of the 9th and 10th houses are conjunct, in mutual \
             aspect, or exchange signs. This is among the most powerful Raja Yogas — the native \
             achieves great success, authority, and fulfills life purpose.",
            vec![lord_9, lord_10],
        ))
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::data::types::PlanetPosition;
    use chrono::TimeZone;

    fn make_chart(ascendant: f64, planet_data: Vec<(Planet, f64, u8)>) -> Chart {
        // planet_data: (planet, longitude, house)
        let planets = planet_data
            .into_iter()
            .map(|(planet, longitude, house)| {
                let sign = crate::zodiac::sign_from_longitude(longitude);
                PlanetPosition {
                    planet,
                    longitude,
                    sign: Some(sign),
                    house: Some(house),
                    is_exalted: false,
                    is_debilitated: false,
                    is_own_sign: false,
                    ..Default::default()
                }
            })
            .collect();
        Chart {
            datetime: chrono::Utc.with_ymd_and_hms(2000, 1, 1, 12, 0, 0).unwrap(),
            ascendant,
            planets,
            ..Default::default()
        }
    }

    #[test]
    fn test_gajakesari_present_when_jupiter_in_kendra_from_moon() {
        // Moon in house 1, Jupiter in house 4 → Kendra from Moon → Gajakesari
        let chart = make_chart(
            0.0,
            vec![
                (Planet::Moon, 5.0, 1),
                (Planet::Jupiter, 95.0, 4), // ~Cancer, house 4
                (Planet::Sun, 20.0, 1),
                (Planet::Mars, 200.0, 7),
                (Planet::Venus, 35.0, 2),
                (Planet::Mercury, 15.0, 1),
                (Planet::Saturn, 270.0, 10),
            ],
        );
        let yogas = identify_yogas(&chart);
        let gajakesari = yogas.iter().find(|y| y.name == "Gajakesari Yoga");
        assert!(
            gajakesari.is_some(),
            "Gajakesari should be present when Jupiter is in 4th from Moon"
        );
        assert!(gajakesari.unwrap().is_present);
    }

    #[test]
    fn test_gajakesari_absent_when_jupiter_not_in_kendra_from_moon() {
        // Moon in house 1, Jupiter in house 3 → NOT a Kendra from Moon
        let chart = make_chart(
            0.0,
            vec![
                (Planet::Moon, 5.0, 1),
                (Planet::Jupiter, 65.0, 3), // house 3
                (Planet::Sun, 20.0, 1),
                (Planet::Mars, 200.0, 7),
                (Planet::Venus, 35.0, 2),
                (Planet::Mercury, 15.0, 1),
                (Planet::Saturn, 270.0, 10),
            ],
        );
        let yogas = identify_yogas(&chart);
        let gajakesari = yogas.iter().find(|y| y.name == "Gajakesari Yoga");
        assert!(
            gajakesari.is_none(),
            "Gajakesari should NOT be present when Jupiter is in 3rd from Moon"
        );
    }

    #[test]
    fn test_budhaditya_present_when_sun_mercury_conjunct() {
        // Sun and Mercury in same sign (Aries)
        let chart = make_chart(
            0.0,
            vec![
                (Planet::Sun, 15.0, 1),
                (Planet::Mercury, 20.0, 1), // both in Aries
                (Planet::Moon, 60.0, 2),
                (Planet::Jupiter, 95.0, 4),
                (Planet::Mars, 200.0, 7),
                (Planet::Venus, 35.0, 2),
                (Planet::Saturn, 270.0, 10),
            ],
        );
        let yogas = identify_yogas(&chart);
        let yoga = yogas.iter().find(|y| y.name == "Budhaditya Yoga");
        assert!(
            yoga.is_some(),
            "Budhaditya Yoga should be present when Sun and Mercury are in same sign"
        );
    }

    #[test]
    fn test_hamsa_yoga_jupiter_in_cancer_kendra() {
        // Jupiter exalted in Cancer, in house 1 (Kendra) → Hamsa Yoga
        let chart = make_chart(
            95.0,
            vec![
                // Cancer ascendant (~95°)
                (Planet::Jupiter, 100.0, 1), // Jupiter in Cancer (exaltation), house 1
                (Planet::Sun, 20.0, 9),
                (Planet::Moon, 200.0, 6),
                (Planet::Mars, 300.0, 9),
                (Planet::Venus, 35.0, 11),
                (Planet::Mercury, 50.0, 11),
                (Planet::Saturn, 270.0, 7),
            ],
        );
        let yogas = identify_yogas(&chart);
        let yoga = yogas.iter().find(|y| y.name == "Hamsa Yoga");
        assert!(
            yoga.is_some(),
            "Hamsa Yoga should be present when Jupiter is exalted in Kendra"
        );
    }

    #[test]
    fn test_yoga_planets_involved_not_empty() {
        // Any detected yoga must list planets_involved
        let chart = make_chart(
            0.0,
            vec![
                (Planet::Moon, 5.0, 1),
                (Planet::Jupiter, 95.0, 4),
                (Planet::Sun, 15.0, 1),
                (Planet::Mercury, 20.0, 1),
                (Planet::Mars, 200.0, 7),
                (Planet::Venus, 35.0, 2),
                (Planet::Saturn, 270.0, 10),
            ],
        );
        let yogas = identify_yogas(&chart);
        for yoga in &yogas {
            assert!(
                !yoga.planets_involved.is_empty(),
                "Yoga '{}' must list planets_involved",
                yoga.name
            );
        }
    }
}
