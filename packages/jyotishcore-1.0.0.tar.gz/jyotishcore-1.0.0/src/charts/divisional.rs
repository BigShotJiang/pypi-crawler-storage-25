use crate::data::types::Sign;

/// Index (0-based) of the planet within its rashi for the given varga division.
pub fn divisional_index(lon: f64, varga: u32) -> u32 {
    let remainder = lon % 30.0;
    let part = 30.0 / varga as f64;
    (remainder / part) as u32
}

/// Returns the sign of the planet in a given divisional chart.
/// lon = sidereal longitude of the planet (0–360°).
/// varga = division number (2,3,4,7,9,10,12,16,20,24,27,30,40,45,60)
pub fn divisional_sign(lon: f64, varga: u32) -> Sign {
    let sign_num = ((lon / 30.0) as u32) + 1; // 1..12 (Rashi index)
    let remainder = lon % 30.0;
    let part = 30.0 / varga as f64;
    let div_index = (remainder / part) as u32; // 0..(varga-1)

    let mapped = match varga {
        1 => sign_num, // Rashi
        2 => {
            // Hora: 15° segments
            // 1st half: Sun (Leo=5) or Moon (Cancer=4)
            if sign_num % 2 == 1 {
                // odd signs
                if div_index == 0 {
                    5
                } else {
                    4
                }
            } else {
                // even signs
                if div_index == 0 {
                    4
                } else {
                    5
                }
            }
        }
        3 => {
            // Drekkana: 10° segments
            // 1st = same, 2nd = +4 signs, 3rd = +8 signs
            ((sign_num - 1 + (div_index * 4)) % 12) + 1
        }
        4 => {
            // Chaturthamsa: 7°30'
            // 1st = same, 2nd = +3, 3rd = +6, 4th = +9
            ((sign_num - 1 + (div_index * 3)) % 12) + 1
        }
        7 => {
            // Saptamsa: 4°17'
            // Odd signs start from same, Even start from +6 (opposite)
            let start = if sign_num % 2 == 1 {
                sign_num
            } else {
                ((sign_num + 6 - 1) % 12) + 1
            };
            ((start - 1 + div_index) % 12) + 1
        }
        9 => {
            // Navamsa: 3°20'
            // Parashara:
            // Aries, Leo, Sag (Fire) -> Aries (1)
            // Taurus, Virgo, Cap (Earth) -> Capricorn (10)
            // Gemini, Libra, Aqua (Air) -> Libra (7)
            // Cancer, Scorpio, Pisces (Water) -> Cancer (4)
            let start_sign = if [1, 5, 9].contains(&sign_num) {
                1
            } else if [2, 6, 10].contains(&sign_num) {
                10
            } else if [3, 7, 11].contains(&sign_num) {
                7
            } else {
                4
            };
            ((start_sign - 1 + div_index) % 12) + 1
        }
        10 => {
            // Dasamsa: 3°
            // Odd signs start from same, Even signs start from 9th from same
            let start = if sign_num % 2 == 1 {
                sign_num
            } else {
                ((sign_num + 9 - 1) % 12) + 1
            };
            ((start - 1 + div_index) % 12) + 1
        }
        12 => {
            // Dwadasamsa: 2°30'
            // Starts from the sign itself
            ((sign_num - 1 + div_index) % 12) + 1
        }
        30 => {
            // Trimsamsa: 1°
            // Odd: 0-5 Mars(Ari), 5-10 Sat(Aqu), 10-18 Jup(Sag), 18-25 Mer(Gem), 25-30 Ven(Lib)
            // Even: 0-5 Ven(Tau), 5-12 Mer(Vir), 12-20 Jup(Pis), 20-25 Sat(Cap), 25-30 Mars(Sco)
            if sign_num % 2 == 1 {
                if remainder < 5.0 {
                    1
                } else if remainder < 10.0 {
                    11
                } else if remainder < 18.0 {
                    9
                } else if remainder < 25.0 {
                    3
                } else {
                    7
                }
            } else {
                if remainder < 5.0 {
                    2
                } else if remainder < 12.0 {
                    6
                } else if remainder < 20.0 {
                    12
                } else if remainder < 25.0 {
                    10
                } else {
                    8
                }
            }
        }
        16 => {
            // Shodashamsa: 1°52'30"
            // Movable (1,4,7,10) -> Aries (1)
            // Fixed (2,5,8,11) -> Leo (5)
            // Dual (3,6,9,12) -> Sagittarius (9)
            let start = if [1, 4, 7, 10].contains(&sign_num) {
                1
            } else if [2, 5, 8, 11].contains(&sign_num) {
                5
            } else {
                9
            };
            ((start - 1 + div_index) % 12) + 1
        }
        20 => {
            // Vimsamsa: 1°30'
            // Movable -> Aries (1)
            // Fixed -> Sagittarius (9)
            // Dual -> Leo (5)
            let start = if [1, 4, 7, 10].contains(&sign_num) {
                1
            } else if [2, 5, 8, 11].contains(&sign_num) {
                9
            } else {
                5
            };
            ((start - 1 + div_index) % 12) + 1
        }
        24 => {
            // Chaturvimsamsa: 1°15'
            // Odd signs -> Leo (5)
            // Even signs -> Cancer (4)
            let start = if sign_num % 2 == 1 { 5 } else { 4 };
            ((start - 1 + div_index) % 12) + 1
        }
        27 => {
            // Saptavimsamsa: 1°06'40"
            // Fire (1,5,9) -> Aries (1)
            // Earth (2,6,10) -> Cancer (4)
            // Air (3,7,11) -> Libra (7)
            // Water (4,8,12) -> Capricorn (10)
            let start = if [1, 5, 9].contains(&sign_num) {
                1
            } else if [2, 6, 10].contains(&sign_num) {
                4
            } else if [3, 7, 11].contains(&sign_num) {
                7
            } else {
                10
            };
            ((start - 1 + div_index) % 12) + 1
        }
        40 => {
            // Khavedamsa: 45'
            // Odd signs -> Aries (1)
            // Even signs -> Libra (7)
            let start = if sign_num % 2 == 1 { 1 } else { 7 };
            ((start - 1 + div_index) % 12) + 1
        }
        45 => {
            // Akshavedamsa: 40'
            // Movable -> Aries (1)
            // Fixed -> Leo (5)
            // Dual -> Sagittarius (9)
            let start = if [1, 4, 7, 10].contains(&sign_num) {
                1
            } else if [2, 5, 8, 11].contains(&sign_num) {
                5
            } else {
                9
            };
            ((start - 1 + div_index) % 12) + 1
        }
        60 => {
            // Shashtiamsa: 30'
            // Starts from sign itself
            ((sign_num - 1 + div_index) % 12) + 1
        }
        _ => {
            // Default cyclic
            ((sign_num - 1 + div_index) % 12) + 1
        }
    };

    match mapped {
        1 => Sign::Aries,
        2 => Sign::Taurus,
        3 => Sign::Gemini,
        4 => Sign::Cancer,
        5 => Sign::Leo,
        6 => Sign::Virgo,
        7 => Sign::Libra,
        8 => Sign::Scorpio,
        9 => Sign::Sagittarius,
        10 => Sign::Capricorn,
        11 => Sign::Aquarius,
        12 => Sign::Pisces,
        _ => Sign::Aries,
    }
}
