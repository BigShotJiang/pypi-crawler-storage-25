use crate::data::types::{Chart, KutaResult, Nakshatra, Planet, Sign};

fn get_varna(sign: Sign) -> i32 {
    match sign {
        Sign::Cancer | Sign::Scorpio | Sign::Pisces => 4, // Brahmin
        Sign::Aries | Sign::Leo | Sign::Sagittarius => 3, // Kshatriya
        Sign::Taurus | Sign::Virgo | Sign::Capricorn => 2, // Vaishya
        Sign::Gemini | Sign::Libra | Sign::Aquarius => 1, // Shudra
    }
}

// 0: Chatushpada, 1: Manava, 2: Jalachara, 3: Vanachara, 4: Keeta
fn get_vasya(sign: Sign) -> i32 {
    match sign {
        Sign::Aries | Sign::Taurus | Sign::Sagittarius => 0, // Chatushpada
        Sign::Gemini | Sign::Virgo | Sign::Libra | Sign::Aquarius => 1, // Manava
        Sign::Cancer | Sign::Capricorn | Sign::Pisces => 2,  // Jalachara
        Sign::Leo => 3,                                      // Vanachara
        Sign::Scorpio => 4,                                  // Keeta
    }
}

fn compute_vasya_score(boy_vasya: i32, girl_vasya: i32) -> f64 {
    if boy_vasya == girl_vasya {
        return 2.0;
    }
    // Simplified Vasya compatibility table
    // 2.0 for same, 1.0 for friendly, 0.5 for neutral, 0.0 for enemy
    // Here we just use a simplified version: 1.0 if not same but not enemy, 0.0 otherwise.
    // For production, a full 5x5 matrix is ideal.
    // Let's approximate: Manava is enemy to Vanachara.
    if (boy_vasya == 1 && girl_vasya == 3) || (boy_vasya == 3 && girl_vasya == 1) {
        return 0.0;
    }
    1.0
}

fn get_yoni(nak: Nakshatra) -> i32 {
    // 0: Horse, 1: Elephant, 2: Sheep, 3: Serpent, 4: Dog, 5: Cat, 6: Rat, 7: Cow,
    // 8: Buffalo, 9: Tiger, 10: Hare, 11: Monkey, 12: Mongoose, 13: Lion
    match nak {
        Nakshatra::Ashwini | Nakshatra::Shatabhisha => 0,
        Nakshatra::Bharani | Nakshatra::Revati => 1,
        Nakshatra::Krittika | Nakshatra::Pushya => 2,
        Nakshatra::Rohini | Nakshatra::Mrigashirsha => 3,
        Nakshatra::Ardra | Nakshatra::Mula => 4,
        Nakshatra::Punarvasu | Nakshatra::Ashlesha => 5,
        Nakshatra::Magha | Nakshatra::PurvaPhalguni => 6,
        Nakshatra::UttaraPhalguni | Nakshatra::UttaraBhadrapada => 7,
        Nakshatra::Hasta | Nakshatra::Swati => 8,
        Nakshatra::Chitra | Nakshatra::Vishakha => 9,
        Nakshatra::Anuradha | Nakshatra::Jyeshtha => 10,
        Nakshatra::PurvaAshadha | Nakshatra::Shravana => 11,
        Nakshatra::UttaraAshadha => 12,
        Nakshatra::Dhanishta | Nakshatra::PurvaBhadrapada => 13,
    }
}

fn compute_yoni_score(boy_yoni: i32, girl_yoni: i32) -> f64 {
    if boy_yoni == girl_yoni {
        return 4.0;
    }
    // Enemy pairs (get 0):
    // Horse-Buffalo(0-8), Elephant-Lion(1-13), Sheep-Monkey(2-11), Serpent-Mongoose(3-12)
    // Dog-Hare(4-10), Cat-Rat(5-6), Cow-Tiger(7-9)
    let is_enemy = (boy_yoni == 0 && girl_yoni == 8)
        || (boy_yoni == 8 && girl_yoni == 0)
        || (boy_yoni == 1 && girl_yoni == 13)
        || (boy_yoni == 13 && girl_yoni == 1)
        || (boy_yoni == 2 && girl_yoni == 11)
        || (boy_yoni == 11 && girl_yoni == 2)
        || (boy_yoni == 3 && girl_yoni == 12)
        || (boy_yoni == 12 && girl_yoni == 3)
        || (boy_yoni == 4 && girl_yoni == 10)
        || (boy_yoni == 10 && girl_yoni == 4)
        || (boy_yoni == 5 && girl_yoni == 6)
        || (boy_yoni == 6 && girl_yoni == 5)
        || (boy_yoni == 7 && girl_yoni == 9)
        || (boy_yoni == 9 && girl_yoni == 7);

    if is_enemy {
        0.0
    } else {
        // Average friendly/neutral
        2.0
    }
}

fn get_lord(sign: Sign) -> Planet {
    match sign {
        Sign::Aries | Sign::Scorpio => Planet::Mars,
        Sign::Taurus | Sign::Libra => Planet::Venus,
        Sign::Gemini | Sign::Virgo => Planet::Mercury,
        Sign::Cancer => Planet::Moon,
        Sign::Leo => Planet::Sun,
        Sign::Sagittarius | Sign::Pisces => Planet::Jupiter,
        Sign::Capricorn | Sign::Aquarius => Planet::Saturn,
    }
}

fn compute_graha_maitri_score(boy_sign: Sign, girl_sign: Sign) -> f64 {
    let boy_lord = get_lord(boy_sign);
    let girl_lord = get_lord(girl_sign);
    if boy_lord == girl_lord {
        return 5.0;
    }
    // Very simplified Graha Maitri
    // Sun, Moon, Mars, Jupiter are friends.
    // Mercury, Venus, Saturn are friends.
    let group1 = [Planet::Sun, Planet::Moon, Planet::Mars, Planet::Jupiter];
    let group2 = [Planet::Mercury, Planet::Venus, Planet::Saturn];

    let b1 = group1.contains(&boy_lord);
    let g1 = group1.contains(&girl_lord);
    let b2 = group2.contains(&boy_lord);
    let g2 = group2.contains(&girl_lord);

    if (b1 && g1) || (b2 && g2) {
        5.0
    } else if b1 != g1 && boy_lord != Planet::Moon && girl_lord != Planet::Moon {
        0.0 // enemies
    } else {
        2.5 // neutral (e.g. involving Moon and Mercury/Venus)
    }
}

fn get_gana(nak: Nakshatra) -> i32 {
    // 0: Deva, 1: Manushya, 2: Rakshasa
    let n = nak as i32;
    // Deva: 1, 5, 7, 8, 13, 15, 17, 22, 27
    if [1, 5, 7, 8, 13, 15, 17, 22, 27].contains(&n) {
        0
    }
    // Rakshasa: 3, 9, 14, 16, 18, 19, 23, 24, 25
    else if [3, 9, 14, 16, 18, 19, 23, 24, 25].contains(&n) {
        2
    }
    // Manushya: rest
    else {
        1
    }
}

fn compute_gana_score(boy_gana: i32, girl_gana: i32) -> f64 {
    if boy_gana == girl_gana {
        return 6.0;
    }
    if (boy_gana == 0 && girl_gana == 1) || (boy_gana == 1 && girl_gana == 0) {
        return 5.0;
    }
    if girl_gana == 2 && boy_gana != 2 {
        return 0.0;
    }
    if boy_gana == 2 && girl_gana == 0 {
        return 1.0;
    }
    0.0
}

fn get_nadi(nak: Nakshatra) -> i32 {
    // 0: Adi (Vata), 1: Madhya (Pitta), 2: Antya (Kapha)
    // The pattern for Nadi repeats every 9 nakshatras in a snake-like manner:
    // 1-Adi, 2-Madh, 3-Ant, 4-Ant, 5-Madh, 6-Adi, 7-Adi, 8-Madh, 9-Ant
    let n = (nak as i32 - 1) % 9;
    match n {
        0 | 5 | 6 => 0, // Adi
        1 | 4 | 7 => 1, // Madhya
        2 | 3 | 8 => 2, // Antya
        _ => 0,
    }
}

pub fn compute_kuta(boy: &Chart, girl: &Chart) -> KutaResult {
    let mut result = KutaResult {
        max_score: 36.0,
        ..Default::default()
    };

    let boy_moon = boy.planets.iter().find(|p| p.planet == Planet::Moon);
    let girl_moon = girl.planets.iter().find(|p| p.planet == Planet::Moon);

    if boy_moon.is_none() || girl_moon.is_none() {
        return result;
    }

    let boy_moon = boy_moon.unwrap();
    let girl_moon = girl_moon.unwrap();

    let boy_sign = boy_moon.sign.unwrap_or(Sign::Aries);
    let girl_sign = girl_moon.sign.unwrap_or(Sign::Aries);

    let boy_nak = boy_moon.nakshatra.unwrap_or(Nakshatra::Ashwini);
    let girl_nak = girl_moon.nakshatra.unwrap_or(Nakshatra::Ashwini);

    let boy_nak_idx = boy_nak as i32;
    let girl_nak_idx = girl_nak as i32;

    // 1. Varna (1 point)
    let boy_varna = get_varna(boy_sign);
    let girl_varna = get_varna(girl_sign);
    result.varna = if boy_varna >= girl_varna { 1.0 } else { 0.0 };

    // 2. Vasya (2 points)
    let boy_vasya = get_vasya(boy_sign);
    let girl_vasya = get_vasya(girl_sign);
    result.vasya = compute_vasya_score(boy_vasya, girl_vasya);

    // 3. Tara (3 points)
    let t1 = ((boy_nak_idx - girl_nak_idx + 27) % 27) + 1;
    let t1_rem = t1 % 9;
    let boy_tara = if t1_rem == 3 || t1_rem == 5 || t1_rem == 7 {
        0.0
    } else {
        1.5
    };

    let t2 = ((girl_nak_idx - boy_nak_idx + 27) % 27) + 1;
    let t2_rem = t2 % 9;
    let girl_tara = if t2_rem == 3 || t2_rem == 5 || t2_rem == 7 {
        0.0
    } else {
        1.5
    };
    result.tara = boy_tara + girl_tara;

    // 4. Yoni (4 points)
    let boy_yoni = get_yoni(boy_nak);
    let girl_yoni = get_yoni(girl_nak);
    result.yoni = compute_yoni_score(boy_yoni, girl_yoni);

    // 5. Graha Maitri (5 points)
    result.graha_maitri = compute_graha_maitri_score(boy_sign, girl_sign);

    // 6. Gana (6 points)
    let boy_gana = get_gana(boy_nak);
    let girl_gana = get_gana(girl_nak);
    result.gana = compute_gana_score(boy_gana, girl_gana);

    // 7. Bhakut (7 points)
    let distance = ((boy_sign as i32 - girl_sign as i32 + 12) % 12) + 1;
    result.bhakut = match distance {
        1 | 7 => 7.0,
        2 | 12 => 0.0,
        3 | 11 => 7.0,
        4 | 10 => 7.0,
        5 | 9 => 0.0,
        6 | 8 => 0.0,
        _ => 0.0,
    };

    // 8. Nadi (8 points)
    let boy_nadi = get_nadi(boy_nak);
    let girl_nadi = get_nadi(girl_nak);

    // Nadi Dosha exception: If Nakshatra is same, but Pada is different, Nadi Dosha is cancelled.
    // However, strictly by default rule, same Nadi = 0 points. We'll use the strict rule.
    result.nadi = if boy_nadi == girl_nadi { 0.0 } else { 8.0 };

    result.total_score = result.varna
        + result.vasya
        + result.tara
        + result.yoni
        + result.graha_maitri
        + result.gana
        + result.bhakut
        + result.nadi;

    result.is_compatible = result.total_score >= 18.0;

    result
}
