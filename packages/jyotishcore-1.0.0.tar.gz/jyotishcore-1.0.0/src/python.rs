use crate::calc::chart::{calculate_chart, calculate_chart_bs};
use crate::calc::panchanga;
use crate::calendars::bikram_sambat::BsDate;
use crate::data::types::*;
use crate::ephemeris::service::Ephemeris;
use chrono::{DateTime, Datelike, TimeZone, Timelike, Utc};
use pyo3::prelude::*;
use pyo3::types::PyDict;
use std::collections::HashMap;

/// Helper to convert Planet enum to string
fn planet_to_str(p: Planet) -> &'static str {
    match p {
        Planet::Sun => "Sun",
        Planet::Moon => "Moon",
        Planet::Mars => "Mars",
        Planet::Mercury => "Mercury",
        Planet::Jupiter => "Jupiter",
        Planet::Venus => "Venus",
        Planet::Saturn => "Saturn",
        Planet::Rahu => "Rahu",
        Planet::Ketu => "Ketu",
    }
}

/// Helper to convert Sign enum to string
fn sign_to_str(s: Sign) -> &'static str {
    match s {
        Sign::Aries => "Aries",
        Sign::Taurus => "Taurus",
        Sign::Gemini => "Gemini",
        Sign::Cancer => "Cancer",
        Sign::Leo => "Leo",
        Sign::Virgo => "Virgo",
        Sign::Libra => "Libra",
        Sign::Scorpio => "Scorpio",
        Sign::Sagittarius => "Sagittarius",
        Sign::Capricorn => "Capricorn",
        Sign::Aquarius => "Aquarius",
        Sign::Pisces => "Pisces",
    }
}

fn parse_planet(s: &str) -> PyResult<Planet> {
    match s.to_lowercase().as_str() {
        "sun" => Ok(Planet::Sun),
        "moon" => Ok(Planet::Moon),
        "mars" => Ok(Planet::Mars),
        "mercury" => Ok(Planet::Mercury),
        "jupiter" => Ok(Planet::Jupiter),
        "venus" => Ok(Planet::Venus),
        "saturn" => Ok(Planet::Saturn),
        "rahu" => Ok(Planet::Rahu),
        "ketu" => Ok(Planet::Ketu),
        _ => Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
            "Invalid planet name",
        )),
    }
}

fn parse_ayanamsa(ayanamsa: &str) -> PyResult<AyanamsaMode> {
    let lower = ayanamsa.to_lowercase();
    if let Some(val_str) = lower.strip_prefix("custom:") {
        match val_str.parse::<f64>() {
            Ok(val) => return Ok(AyanamsaMode::Custom(val)),
            Err(_) => {
                return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    "Invalid custom ayanamsa format. Use 'custom:23.5'",
                ))
            }
        }
    }
    match lower.as_str() {
        "lahiri" => Ok(AyanamsaMode::Lahiri),
        "raman" => Ok(AyanamsaMode::Raman),
        "kp" | "krishnamurti" => Ok(AyanamsaMode::Krishnamurti),
        "true_chitra" => Ok(AyanamsaMode::TrueChitra),
        "true_pushya" => Ok(AyanamsaMode::TruePushya),
        other => Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(format!(
            "Unknown ayanamsa '{}'. Valid options: lahiri, raman, kp, true_chitra, true_pushya, custom:<offset>",
            other
        ))),
    }
}

fn parse_house_system(house_system: &str) -> PyResult<HouseSystem> {
    match house_system.to_lowercase().as_str() {
        "equal" => Ok(HouseSystem::Equal),
        "placidus" => Ok(HouseSystem::Placidus),
        "koch" => Ok(HouseSystem::Koch),
        "whole_sign" => Ok(HouseSystem::WholeSign),
        other => Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(format!(
            "Unknown house_system '{}'. Valid options: equal, placidus, koch, whole_sign",
            other
        ))),
    }
}

fn parse_panchanga_mode(mode: &str) -> PyResult<PanchangaMode> {
    match mode.to_lowercase().as_str() {
        "civil_day" => Ok(PanchangaMode::CivilDay),
        "sunrise_day" => Ok(PanchangaMode::SunriseDay),
        other => Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(format!(
            "Unknown panchanga mode '{}'. Valid options: civil_day, sunrise_day",
            other
        ))),
    }
}

fn validate_geo(latitude: f64, longitude: f64, altitude: f64) -> PyResult<()> {
    let geo = GeoPosition {
        latitude,
        longitude,
        altitude,
    };
    crate::calc::chart::validate_location(&geo)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
}

#[allow(clippy::too_many_arguments)]
fn build_chart_from_utc(
    dt: chrono::DateTime<Utc>,
    latitude: f64,
    longitude: f64,
    altitude: f64,
    ayanamsa: &str,
    house_system: &str,
    true_nodes: bool,
    input_mode: &str,
    timezone: Option<String>,
) -> PyResult<PyChart> {
    validate_geo(latitude, longitude, altitude)?;
    let aya = parse_ayanamsa(ayanamsa)?;
    let hsys = parse_house_system(house_system)?;
    let geo = GeoPosition {
        latitude,
        longitude,
        altitude,
    };
    let mut chart = calculate_chart(dt, geo, aya, hsys, true_nodes)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    chart.metadata.input_mode = input_mode.to_string();
    chart.metadata.timezone = timezone;
    Ok(PyChart { inner: chart })
}

/// Python wrapper for PlanetPosition
#[pyclass(name = "PlanetPosition")]
#[derive(Clone)]
pub struct PyPlanetPosition {
    #[pyo3(get)]
    pub planet: String,
    #[pyo3(get)]
    pub longitude: f64,
    #[pyo3(get)]
    pub latitude: f64,
    #[pyo3(get)]
    pub speed: f64,
    #[pyo3(get)]
    pub is_retrograde: bool,
    #[pyo3(get)]
    pub is_exalted: bool,
    #[pyo3(get)]
    pub is_debilitated: bool,
    #[pyo3(get)]
    pub is_own_sign: bool,
    #[pyo3(get)]
    pub is_vargottama: bool,
    #[pyo3(get)]
    pub sign: Option<String>,
    #[pyo3(get)]
    pub nakshatra: Option<String>,
    #[pyo3(get)]
    pub nakshatra_index: u8,
    #[pyo3(get)]
    pub pada: u8,
    #[pyo3(get)]
    pub house: Option<u8>,
    #[pyo3(get)]
    pub divisional_signs: HashMap<u32, String>,
    #[pyo3(get)]
    pub is_moolatrikona: bool,
    #[pyo3(get)]
    pub shadbala: Option<HashMap<String, f64>>,
}

#[pymethods]
impl PyPlanetPosition {
    fn __repr__(&self) -> String {
        let sign_str = self.sign.as_deref().unwrap_or("Unknown Sign");
        format!(
            "<PlanetPosition {}: {} at {:.2}°>",
            self.planet, sign_str, self.longitude
        )
    }
}

/// Divisional (varga) position — `display_longitude` is for chart drawing only.
#[pyclass(name = "VargaPosition")]
#[derive(Clone)]
pub struct PyVargaPosition {
    #[pyo3(get)]
    pub planet: String,
    #[pyo3(get)]
    pub source_longitude: f64,
    #[pyo3(get)]
    pub varga: u32,
    #[pyo3(get)]
    pub varga_sign: String,
    #[pyo3(get)]
    pub varga_index: u32,
    #[pyo3(get)]
    pub display_longitude: Option<f64>,
    #[pyo3(get)]
    pub warnings: Vec<String>,
}

#[pymethods]
impl PyVargaPosition {
    fn __repr__(&self) -> String {
        format!(
            "<VargaPosition {} D{} in {} (source {:.2}°)>",
            self.planet, self.varga, self.varga_sign, self.source_longitude
        )
    }
}

/// Python wrapper for DashaPeriod
#[pyclass(name = "DashaPeriod")]
#[derive(Clone)]
pub struct PyDashaPeriod {
    #[pyo3(get)]
    pub lord: String,
    #[pyo3(get)]
    pub start: String,
    #[pyo3(get)]
    pub end: String,
    #[pyo3(get)]
    pub sub_periods: Vec<PyDashaPeriod>,
}

/// Python wrapper for YogaResult.
/// Each yoga has a name, category, BPHS-cited description, and the planets involved.
#[pyclass(name = "YogaResult")]
#[derive(Clone)]
pub struct PyYogaResult {
    #[pyo3(get)]
    pub name: String,
    #[pyo3(get)]
    pub category: String,
    #[pyo3(get)]
    pub description: String,
    #[pyo3(get)]
    pub planets_involved: Vec<String>,
    #[pyo3(get)]
    pub is_present: bool,
}

#[pymethods]
impl PyYogaResult {
    fn __repr__(&self) -> String {
        format!(
            "<YogaResult '{}' [{}] planets={:?}>",
            self.name, self.category, self.planets_involved
        )
    }
}

/// Python wrapper for KutaResult (Ashtakoota compatibility).
#[pyclass(name = "KutaResult")]
#[derive(Clone)]
pub struct PyKutaResult {
    #[pyo3(get)]
    pub varna: f64,
    #[pyo3(get)]
    pub vasya: f64,
    #[pyo3(get)]
    pub tara: f64,
    #[pyo3(get)]
    pub yoni: f64,
    #[pyo3(get)]
    pub graha_maitri: f64,
    #[pyo3(get)]
    pub gana: f64,
    #[pyo3(get)]
    pub bhakut: f64,
    #[pyo3(get)]
    pub nadi: f64,
    #[pyo3(get)]
    pub total_score: f64,
    #[pyo3(get)]
    pub max_score: f64,
    #[pyo3(get)]
    pub is_compatible: bool,
}

#[pymethods]
impl PyKutaResult {
    fn __repr__(&self) -> String {
        format!(
            "<KutaResult score={:.1}/36.0 compatible={}>",
            self.total_score, self.is_compatible
        )
    }
}

/// Python wrapper for Chart
#[pyclass(name = "Chart")]
#[derive(Clone)]
pub struct PyChart {
    inner: Chart,
}

#[pymethods]
impl PyChart {
    #[staticmethod]
    #[pyo3(signature = (year, month, day, hour, minute, second, latitude, longitude, altitude=0.0, ayanamsa="lahiri", house_system="equal", true_nodes=true))]
    #[allow(clippy::too_many_arguments)]
    fn from_utc(
        year: i32,
        month: u32,
        day: u32,
        hour: u32,
        minute: u32,
        second: u32,
        latitude: f64,
        longitude: f64,
        altitude: f64,
        ayanamsa: &str,
        house_system: &str,
        true_nodes: bool,
    ) -> PyResult<Self> {
        let dt = Utc
            .with_ymd_and_hms(year, month, day, hour, minute, second)
            .single()
            .ok_or_else(|| {
                PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid UTC date/time")
            })?;
        build_chart_from_utc(
            dt,
            latitude,
            longitude,
            altitude,
            ayanamsa,
            house_system,
            true_nodes,
            "utc",
            Some("UTC".to_string()),
        )
    }

    #[staticmethod]
    #[pyo3(signature = (date, time, timezone, latitude, longitude, altitude=0.0, ayanamsa="lahiri", house_system="equal", true_nodes=true))]
    #[allow(clippy::too_many_arguments)]
    fn from_local(
        date: &str,
        time: &str,
        timezone: &str,
        latitude: f64,
        longitude: f64,
        altitude: f64,
        ayanamsa: &str,
        house_system: &str,
        true_nodes: bool,
    ) -> PyResult<Self> {
        let date = chrono::NaiveDate::parse_from_str(date, "%Y-%m-%d").map_err(|_| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid date; expected YYYY-MM-DD")
        })?;
        let time = chrono::NaiveTime::parse_from_str(time, "%H:%M:%S").map_err(|_| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid time; expected HH:MM:SS")
        })?;
        let dt = crate::util::timezone::local_to_utc(
            date.year(),
            date.month(),
            date.day(),
            time.hour(),
            time.minute(),
            time.second(),
            timezone,
        )
        .map_err(PyErr::new::<pyo3::exceptions::PyValueError, _>)?;
        build_chart_from_utc(
            dt,
            latitude,
            longitude,
            altitude,
            ayanamsa,
            house_system,
            true_nodes,
            "local_civil",
            Some(timezone.to_string()),
        )
    }

    #[staticmethod]
    #[pyo3(signature = (jd_ut, latitude, longitude, altitude=0.0, ayanamsa="lahiri", house_system="equal", true_nodes=true))]
    #[allow(clippy::too_many_arguments)]
    fn from_julian_day(
        jd_ut: f64,
        latitude: f64,
        longitude: f64,
        altitude: f64,
        ayanamsa: &str,
        house_system: &str,
        true_nodes: bool,
    ) -> PyResult<Self> {
        let aya = parse_ayanamsa(ayanamsa)?;
        let ephe = Ephemeris::new(aya, true_nodes);
        let dt = ephe.from_julian_day(jd_ut);
        build_chart_from_utc(
            dt,
            latitude,
            longitude,
            altitude,
            ayanamsa,
            house_system,
            true_nodes,
            "julian_day_ut",
            Some("UTC".to_string()),
        )
    }

    #[staticmethod]
    #[pyo3(signature = (year, month, day, hour, minute, second, latitude, longitude, altitude=0.0, ayanamsa="lahiri", house_system="equal", true_nodes=true))]
    #[allow(clippy::too_many_arguments)]
    fn compute(
        year: i32,
        month: u32,
        day: u32,
        hour: u32,
        minute: u32,
        second: u32,
        latitude: f64,
        longitude: f64,
        altitude: f64,
        ayanamsa: &str,
        house_system: &str,
        true_nodes: bool,
    ) -> PyResult<Self> {
        Self::from_utc(
            year,
            month,
            day,
            hour,
            minute,
            second,
            latitude,
            longitude,
            altitude,
            ayanamsa,
            house_system,
            true_nodes,
        )
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (bs_year, bs_month, bs_day, hour, minute, second,
                        latitude, longitude, altitude=0.0,
                        ayanamsa="lahiri", house_system="equal", true_nodes=true))]
    #[staticmethod]
    fn compute_bs(
        bs_year: i32,
        bs_month: u32,
        bs_day: u32,
        hour: u32,
        minute: u32,
        second: u32,
        latitude: f64,
        longitude: f64,
        altitude: f64,
        ayanamsa: &str,
        house_system: &str,
        true_nodes: bool,
    ) -> PyResult<PyChart> {
        let bs = BsDate::new(bs_year, bs_month, bs_day);
        let time = chrono::NaiveTime::from_hms_opt(hour, minute, second)
            .ok_or_else(|| PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid time"))?;

        validate_geo(latitude, longitude, altitude)?;
        let aya = parse_ayanamsa(ayanamsa)?;
        let hsys = parse_house_system(house_system)?;

        let geo = GeoPosition {
            latitude,
            longitude,
            altitude,
        };

        let chart = calculate_chart_bs(bs, time, geo, aya, hsys, true_nodes)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        Ok(PyChart { inner: chart })
    }

    fn ascendant(&self) -> f64 {
        self.inner.ascendant
    }

    fn houses(&self) -> Vec<HashMap<String, f64>> {
        self.inner
            .houses
            .iter()
            .map(|h| {
                let mut map = HashMap::new();
                map.insert("house".to_string(), h.house as f64);
                map.insert("cusp".to_string(), h.cusp);
                map
            })
            .collect()
    }

    fn planets(&self) -> HashMap<String, PyPlanetPosition> {
        let mut map = HashMap::new();
        for p in &self.inner.planets {
            let py_p = PyPlanetPosition {
                planet: planet_to_str(p.planet).to_string(),
                longitude: p.longitude,
                latitude: p.latitude,
                speed: p.speed,
                is_retrograde: p.is_retrograde,
                is_exalted: p.is_exalted,
                is_debilitated: p.is_debilitated,
                is_own_sign: p.is_own_sign,
                is_vargottama: p.is_vargottama,
                sign: p.sign.map(|s| sign_to_str(s).to_string()),
                nakshatra: p.nakshatra.map(|n| format!("{:?}", n)),
                nakshatra_index: crate::zodiac::nakshatra_index(p.longitude) + 1,
                pada: crate::zodiac::pada_index(p.longitude) + 1,
                house: p.house,
                divisional_signs: p
                    .divisional_signs
                    .iter()
                    .map(|(&k, &v)| (k, sign_to_str(v).to_string()))
                    .collect(),
                is_moolatrikona: p.is_moolatrikona,
                shadbala: p.shadbala.as_ref().map(|s| {
                    let mut m = HashMap::new();
                    m.insert("sthana".to_string(), s.sthana_bala);
                    m.insert("dik".to_string(), s.dik_bala);
                    m.insert("kala".to_string(), s.kala_bala);
                    m.insert("chesta".to_string(), s.chesta_bala);
                    m.insert("naisargika".to_string(), s.naisargika_bala);
                    m.insert("drik".to_string(), s.drik_bala);
                    m.insert("total".to_string(), s.total);
                    m
                }),
            };
            map.insert(planet_to_str(p.planet).to_lowercase(), py_p);
        }
        map
    }

    #[allow(deprecated)]
    fn aspects(&self, py: Python) -> Vec<HashMap<String, PyObject>> {
        self.inner
            .aspects
            .iter()
            .map(|a| {
                let mut m = HashMap::new();
                m.insert(
                    "from_planet".to_string(),
                    planet_to_str(a.from_planet).to_object(py),
                );
                m.insert("to_house".to_string(), a.to_house.to_object(py));
                m.insert(
                    "to_planet".to_string(),
                    a.to_planet.map(planet_to_str).to_object(py),
                );
                m.insert("strength".to_string(), a.strength.to_object(py));
                m.insert("is_special".to_string(), a.is_special.to_object(py));
                m
            })
            .collect()
    }

    fn dasha(&self) -> HashMap<String, Vec<PyDashaPeriod>> {
        self.inner
            .dasha
            .iter()
            .map(|(name, periods)| (name.clone(), periods.iter().map(convert_dasha).collect()))
            .collect()
    }

    fn vargas(&self, varga: u32) -> Option<Vec<PyVargaPosition>> {
        self.divisional_chart(varga)
    }

    fn settings(&self, py: Python) -> PyResult<PyObject> {
        self.metadata(py)
    }

    fn metadata(&self, py: Python) -> PyResult<PyObject> {
        let json = serde_json::to_string(&self.inner.metadata)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let json_module = py.import("json")?;
        let dict = json_module.call_method1("loads", (json,))?;
        #[allow(deprecated)]
        Ok(dict.to_object(py))
    }

    fn warnings(&self) -> Vec<String> {
        self.inner.warnings.clone()
    }

    fn karakas(&self) -> HashMap<String, String> {
        self.inner
            .karakas
            .iter()
            .map(|(&p, &k)| (planet_to_str(p).to_string(), format!("{:?}", k)))
            .collect()
    }

    fn divisional_chart(&self, varga: u32) -> Option<Vec<PyVargaPosition>> {
        self.inner.divisional_charts.get(&varga).map(|planets| {
            planets
                .iter()
                .map(|p| PyVargaPosition {
                    planet: planet_to_str(p.planet).to_string(),
                    source_longitude: p.source_longitude,
                    varga: p.varga,
                    varga_sign: sign_to_str(p.varga_sign).to_string(),
                    varga_index: p.varga_index,
                    display_longitude: p.display_longitude,
                    warnings: p.warnings.clone(),
                })
                .collect()
        })
    }

    /// Compatibility score using Ashtakoota Milan (36 Guna) against another chart.
    /// Uses traditional Nakshatra and Sign matching.
    pub fn compatibility(&self, other: &PyChart) -> PyResult<PyKutaResult> {
        let result = crate::charts::compatibility::compute_kuta(&self.inner, &other.inner);
        Ok(PyKutaResult {
            varna: result.varna,
            vasya: result.vasya,
            tara: result.tara,
            yoni: result.yoni,
            graha_maitri: result.graha_maitri,
            gana: result.gana,
            bhakut: result.bhakut,
            nadi: result.nadi,
            total_score: result.total_score,
            max_score: result.max_score,
            is_compatible: result.is_compatible,
        })
    }

    fn __repr__(&self) -> String {
        let moon = self.inner.planets.iter().find(|p| p.planet == Planet::Moon);
        let moon_str = moon
            .map(|m| format!("Moon {:.1}°", m.longitude))
            .unwrap_or_default();
        format!(
            "<Chart asc={:.2}° {} ayanamsa={:?}>",
            self.inner.ascendant, moon_str, self.inner.ayanamsa
        )
    }

    fn __str__(&self) -> String {
        // Human-readable summary
        let planets: Vec<String> = self
            .inner
            .planets
            .iter()
            .map(|p| {
                format!(
                    "{:?}: {:.1}° {:?}",
                    p.planet,
                    p.longitude,
                    p.sign.unwrap_or(Sign::Aries)
                )
            })
            .collect();
        format!(
            "JyotishCore Chart\nAscendant: {:.2}°\nPlanets:\n  {}",
            self.inner.ascendant,
            planets.join("\n  ")
        )
    }

    fn explain(&self, py: Python) -> PyResult<PyObject> {
        let graph = crate::knowledge::get_explanation(&self.inner);
        // Simplest way for now: serialize to JSON and back to PyDict
        let json = serde_json::to_string(&graph)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;

        let json_module = py.import("json")?;
        let dict = json_module.call_method1("loads", (json,))?;
        #[allow(deprecated)]
        Ok(dict.to_object(py))
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
    }

    fn to_dict(&self, py: Python) -> PyResult<PyObject> {
        let json = self.to_json()?;
        let json_module = py.import("json")?;
        let dict = json_module.call_method1("loads", (json,))?;
        #[allow(deprecated)]
        Ok(dict.to_object(py))
    }

    #[allow(deprecated)]
    fn ashtakavarga(&self, py: Python) -> PyResult<PyObject> {
        if let Some(av) = &self.inner.ashtakavarga {
            let dict = PyDict::new(py);
            dict.set_item("binna", av.binna.clone().to_object(py))?;
            dict.set_item("sarva", av.sarva.to_vec().to_object(py))?;
            #[allow(deprecated)]
            Ok(dict.to_object(py))
        } else {
            Ok(py.None())
        }
    }

    fn to_svg(&self) -> String {
        crate::util::svg::render_north_indian_svg(&self.inner)
    }

    /// Returns a list of classical yogas (planetary combinations) identified in this chart.
    ///
    /// Each YogaResult includes:
    /// - `name`: Classical yoga name (e.g. "Gajakesari Yoga")
    /// - `category`: "Raja", "Dhana", "Mahapurusha", or "Other"
    /// - `description`: Classical definition with BPHS chapter/verse citation
    /// - `planets_involved`: Which planets form this yoga
    /// - `is_present`: Always True (absent yogas are not returned)
    ///
    /// Only yogas with unambiguous classical definitions are included.
    /// This does NOT include cancellation rules (Bhanga) — consult a qualified astrologer.
    fn yogas(&self) -> Vec<PyYogaResult> {
        self.inner
            .yogas
            .iter()
            .map(|y| PyYogaResult {
                name: y.name.clone(),
                category: y.category.clone(),
                description: y.description.clone(),
                planets_involved: y
                    .planets_involved
                    .iter()
                    .map(|p| planet_to_str(*p).to_string())
                    .collect(),
                is_present: y.is_present,
            })
            .collect()
    }
}

fn convert_dasha(p: &crate::dasha::base::DashaPeriod) -> PyDashaPeriod {
    PyDashaPeriod {
        lord: p.lord_name.clone(),
        start: p.start.to_rfc3339(),
        end: p.end.to_rfc3339(),
        sub_periods: p.sub_periods.iter().map(convert_dasha).collect(),
    }
}

fn panchanga_to_dict(py: Python, p: &Panchanga, locale: &str) -> PyResult<PyObject> {
    let tithi_name = localized_tithi_name(&p.tithi, locale);
    let nak_name = localized_nakshatra_name(&p.nakshatra, locale);

    let dict = PyDict::new(py);

    let tithi = PyDict::new(py);
    tithi.set_item("index", p.tithi.index)?;
    tithi.set_item("name", tithi_name)?;
    tithi.set_item("paksha", p.tithi.paksha.clone())?;
    tithi.set_item("start_time_utc", p.tithi.start_time_utc.to_rfc3339())?;
    tithi.set_item("end_time_utc", p.tithi.end_time_utc.to_rfc3339())?;
    tithi.set_item("start_time_local", p.tithi.start_time_local.clone())?;
    tithi.set_item("end_time_local", p.tithi.end_time_local.clone())?;
    dict.set_item("tithi", tithi)?;

    let nak = PyDict::new(py);
    nak.set_item("index", p.nakshatra.index)?;
    nak.set_item("name", nak_name)?;
    nak.set_item("pada", p.nakshatra.pada)?;
    nak.set_item("start_time_utc", p.nakshatra.start_time_utc.to_rfc3339())?;
    nak.set_item("end_time_utc", p.nakshatra.end_time_utc.to_rfc3339())?;
    nak.set_item("start_time_local", p.nakshatra.start_time_local.clone())?;
    nak.set_item("end_time_local", p.nakshatra.end_time_local.clone())?;
    dict.set_item("nakshatra", nak)?;

    let yoga = PyDict::new(py);
    yoga.set_item("index", p.yoga.index)?;
    yoga.set_item("name", p.yoga.name.clone())?;
    yoga.set_item("start_time_utc", p.yoga.start_time_utc.to_rfc3339())?;
    yoga.set_item("end_time_utc", p.yoga.end_time_utc.to_rfc3339())?;
    yoga.set_item("start_time_local", p.yoga.start_time_local.clone())?;
    yoga.set_item("end_time_local", p.yoga.end_time_local.clone())?;
    dict.set_item("yoga", yoga)?;

    let karana = PyDict::new(py);
    karana.set_item("index", p.karana.index)?;
    karana.set_item("name", p.karana.name.clone())?;
    karana.set_item("start_time_utc", p.karana.start_time_utc.to_rfc3339())?;
    karana.set_item("end_time_utc", p.karana.end_time_utc.to_rfc3339())?;
    karana.set_item("start_time_local", p.karana.start_time_local.clone())?;
    karana.set_item("end_time_local", p.karana.end_time_local.clone())?;
    dict.set_item("karana", karana)?;

    let vara = PyDict::new(py);
    vara.set_item("index", p.vara.index)?;
    vara.set_item("name", p.vara.name.clone())?;
    dict.set_item("vara", vara)?;

    let metadata = PyDict::new(py);
    metadata.set_item("timezone", p.metadata.timezone.clone())?;
    metadata.set_item("mode", p.metadata.mode.clone())?;
    metadata.set_item("local_datetime", p.metadata.local_datetime.clone())?;
    metadata.set_item("utc_datetime", p.metadata.utc_datetime.clone())?;
    metadata.set_item("ayanamsa", p.metadata.ayanamsa.clone())?;
    metadata.set_item("true_nodes", p.metadata.true_nodes)?;
    metadata.set_item(
        "calculation_version",
        p.metadata.calculation_version.clone(),
    )?;
    dict.set_item("metadata", metadata)?;

    dict.set_item("warnings", p.warnings.clone())?;

    Ok(dict.into())
}

fn localized_tithi_name(tithi: &TithiInfo, locale: &str) -> String {
    if locale == "en" {
        return tithi.name.clone();
    }
    crate::locale::get_locale(locale)
        .and_then(|l| l.tithi_names.get((tithi.index - 1) as usize).cloned())
        .unwrap_or_else(|| tithi.name.clone())
}

fn localized_nakshatra_name(nak: &NakshatraInfo, locale: &str) -> String {
    if locale == "en" {
        return nak.name.clone();
    }
    crate::locale::get_locale(locale)
        .and_then(|l| l.nakshatra_names.get((nak.index - 1) as usize).cloned())
        .unwrap_or_else(|| nak.name.clone())
}

#[pyclass(name = "Panchanga")]
pub struct PyPanchanga {
    inner: Panchanga,
}

#[pymethods]
impl PyPanchanga {
    #[staticmethod]
    #[pyo3(signature = (date, time, timezone, latitude, longitude, altitude=0.0,
                        ayanamsa="lahiri", true_nodes=true, mode="civil_day"))]
    #[allow(clippy::too_many_arguments)]
    fn from_local(
        date: &str,
        time: &str,
        timezone: &str,
        latitude: f64,
        longitude: f64,
        altitude: f64,
        ayanamsa: &str,
        true_nodes: bool,
        mode: &str,
    ) -> PyResult<Self> {
        validate_geo(latitude, longitude, altitude)?;
        let date = chrono::NaiveDate::parse_from_str(date, "%Y-%m-%d").map_err(|_| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid date; expected YYYY-MM-DD")
        })?;
        let time = chrono::NaiveTime::parse_from_str(time, "%H:%M:%S").map_err(|_| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid time; expected HH:MM:SS")
        })?;
        let dt = crate::util::timezone::local_to_utc(
            date.year(),
            date.month(),
            date.day(),
            time.hour(),
            time.minute(),
            time.second(),
            timezone,
        )
        .map_err(PyErr::new::<pyo3::exceptions::PyValueError, _>)?;

        let aya = parse_ayanamsa(ayanamsa)?;
        let pmode = parse_panchanga_mode(mode)?;
        let geo = GeoPosition {
            latitude,
            longitude,
            altitude,
        };

        let p = panchanga::compute_panchanga_local(dt, &geo, timezone, pmode, aya, true_nodes)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        Ok(Self { inner: p })
    }

    fn to_dict(&self, py: Python) -> PyResult<PyObject> {
        panchanga_to_dict(py, &self.inner, "en")
    }

    fn metadata(&self, py: Python) -> PyResult<PyObject> {
        let dict = PyDict::new(py);
        dict.set_item("timezone", self.inner.metadata.timezone.clone())?;
        dict.set_item("mode", self.inner.metadata.mode.clone())?;
        dict.set_item("local_datetime", self.inner.metadata.local_datetime.clone())?;
        dict.set_item("utc_datetime", self.inner.metadata.utc_datetime.clone())?;
        dict.set_item("ayanamsa", self.inner.metadata.ayanamsa.clone())?;
        dict.set_item("true_nodes", self.inner.metadata.true_nodes)?;
        dict.set_item(
            "calculation_version",
            self.inner.metadata.calculation_version.clone(),
        )?;
        Ok(dict.into())
    }

    fn warnings(&self) -> Vec<String> {
        self.inner.warnings.clone()
    }

    #[getter]
    fn tithi(&self, py: Python) -> PyResult<PyObject> {
        let d = PyDict::new(py);
        d.set_item("index", self.inner.tithi.index)?;
        d.set_item("name", self.inner.tithi.name.clone())?;
        d.set_item("paksha", self.inner.tithi.paksha.clone())?;
        d.set_item(
            "start_time_utc",
            self.inner.tithi.start_time_utc.to_rfc3339(),
        )?;
        d.set_item("end_time_utc", self.inner.tithi.end_time_utc.to_rfc3339())?;
        d.set_item(
            "start_time_local",
            self.inner.tithi.start_time_local.clone(),
        )?;
        d.set_item("end_time_local", self.inner.tithi.end_time_local.clone())?;
        Ok(d.into())
    }

    #[getter]
    fn nakshatra(&self, py: Python) -> PyResult<PyObject> {
        let d = PyDict::new(py);
        d.set_item("index", self.inner.nakshatra.index)?;
        d.set_item("name", self.inner.nakshatra.name.clone())?;
        d.set_item("pada", self.inner.nakshatra.pada)?;
        d.set_item(
            "start_time_utc",
            self.inner.nakshatra.start_time_utc.to_rfc3339(),
        )?;
        d.set_item(
            "end_time_utc",
            self.inner.nakshatra.end_time_utc.to_rfc3339(),
        )?;
        d.set_item(
            "start_time_local",
            self.inner.nakshatra.start_time_local.clone(),
        )?;
        d.set_item(
            "end_time_local",
            self.inner.nakshatra.end_time_local.clone(),
        )?;
        Ok(d.into())
    }

    #[getter]
    fn yoga(&self, py: Python) -> PyResult<PyObject> {
        let d = PyDict::new(py);
        d.set_item("index", self.inner.yoga.index)?;
        d.set_item("name", self.inner.yoga.name.clone())?;
        d.set_item(
            "start_time_utc",
            self.inner.yoga.start_time_utc.to_rfc3339(),
        )?;
        d.set_item("end_time_utc", self.inner.yoga.end_time_utc.to_rfc3339())?;
        d.set_item("start_time_local", self.inner.yoga.start_time_local.clone())?;
        d.set_item("end_time_local", self.inner.yoga.end_time_local.clone())?;
        Ok(d.into())
    }

    #[getter]
    fn karana(&self, py: Python) -> PyResult<PyObject> {
        let d = PyDict::new(py);
        d.set_item("index", self.inner.karana.index)?;
        d.set_item("name", self.inner.karana.name.clone())?;
        d.set_item(
            "start_time_utc",
            self.inner.karana.start_time_utc.to_rfc3339(),
        )?;
        d.set_item("end_time_utc", self.inner.karana.end_time_utc.to_rfc3339())?;
        d.set_item(
            "start_time_local",
            self.inner.karana.start_time_local.clone(),
        )?;
        d.set_item("end_time_local", self.inner.karana.end_time_local.clone())?;
        Ok(d.into())
    }

    #[getter]
    fn vara(&self, py: Python) -> PyResult<PyObject> {
        let d = PyDict::new(py);
        d.set_item("index", self.inner.vara.index)?;
        d.set_item("name", self.inner.vara.name.clone())?;
        Ok(d.into())
    }
}

#[pyfunction]
#[pyo3(signature = (year, month, day, hour, minute, second, latitude, longitude, altitude=0.0, ayanamsa="lahiri", true_nodes=true, locale="en"))]
#[allow(clippy::too_many_arguments)]
fn get_panchanga(
    py: Python,
    year: i32,
    month: u32,
    day: u32,
    hour: u32,
    minute: u32,
    second: u32,
    latitude: f64,
    longitude: f64,
    altitude: f64,
    ayanamsa: &str,
    true_nodes: bool,
    locale: &str,
) -> PyResult<PyObject> {
    validate_geo(latitude, longitude, altitude)?;
    let aya = parse_ayanamsa(ayanamsa)?;
    let dt = Utc
        .with_ymd_and_hms(year, month, day, hour, minute, second)
        .single()
        .ok_or_else(|| PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid date/time"))?;

    let geo = GeoPosition {
        latitude,
        longitude,
        altitude,
    };

    let p = panchanga::compute_panchanga_local(
        dt,
        &geo,
        "UTC",
        PanchangaMode::CivilDay,
        aya,
        true_nodes,
    )
    .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;

    panchanga_to_dict(py, &p, locale)
}

#[allow(clippy::too_many_arguments)]
#[pyfunction]
#[pyo3(signature = (bs_year, bs_month, bs_day, hour, minute, second,
                    latitude, longitude, altitude=0.0,
                    ayanamsa="lahiri", house_system="equal", true_nodes=true))]
fn compute_chart_bs(
    bs_year: i32,
    bs_month: u32,
    bs_day: u32,
    hour: u32,
    minute: u32,
    second: u32,
    latitude: f64,
    longitude: f64,
    altitude: f64,
    ayanamsa: &str,
    house_system: &str,
    true_nodes: bool,
) -> PyResult<PyChart> {
    PyChart::compute_bs(
        bs_year,
        bs_month,
        bs_day,
        hour,
        minute,
        second,
        latitude,
        longitude,
        altitude,
        ayanamsa,
        house_system,
        true_nodes,
    )
}

#[pymodule]
fn jyotishcore(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyChart>()?;
    m.add_class::<PyPlanetPosition>()?;
    m.add_class::<PyVargaPosition>()?;
    m.add_class::<PyPanchanga>()?;
    m.add_class::<PyDashaPeriod>()?;
    m.add_class::<PyYogaResult>()?;
    m.add_class::<PyKutaResult>()?;
    m.add_function(wrap_pyfunction!(get_panchanga, m)?)?;
    m.add_function(wrap_pyfunction!(compute_chart_bs, m)?)?;
    m.add_function(wrap_pyfunction!(compute_chart_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_local_to_utc, m)?)?;
    m.add_function(wrap_pyfunction!(py_compute_dignities, m)?)?;
    m.add_function(wrap_pyfunction!(get_transits, m)?)?;
    m.add_function(wrap_pyfunction!(find_time_windows, m)?)?;
    m.add_function(wrap_pyfunction!(get_divisional_sign, m)?)?;
    m.add_function(wrap_pyfunction!(get_divisional_longitude, m)?)?;
    m.add_function(wrap_pyfunction!(calc_planet_longitude, m)?)?;
    Ok(())
}

#[pyfunction]
#[pyo3(signature = (jd, planet, ayanamsa="lahiri"))]
fn calc_planet_longitude(jd: f64, planet: &str, ayanamsa: &str) -> PyResult<f64> {
    let p = parse_planet(planet)?;
    let aya = parse_ayanamsa(ayanamsa)?;
    let ephemeris = crate::ephemeris::service::Ephemeris::new(aya, true);
    let pos = ephemeris
        .calc_ut(jd, p)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    Ok(pos.longitude)
}

#[pyfunction]
fn get_divisional_sign(lon: f64, varga: u32) -> String {
    format!(
        "{:?}",
        crate::charts::divisional::divisional_sign(lon, varga)
    )
}

#[pyfunction]
fn get_divisional_longitude(lon: f64, varga: u32) -> f64 {
    let div_sign = crate::charts::divisional::divisional_sign(lon, varga);
    let sign_idx = div_sign as u32; // 1 to 12
    if varga == 30 {
        return (sign_idx - 1) as f64 * 30.0 + 15.0;
    }
    let remainder = lon % 30.0;
    let part = 30.0 / varga as f64;
    let part_remainder = remainder % part;
    let proportional_deg = part_remainder * varga as f64;
    ((sign_idx - 1) as f64 * 30.0) + proportional_deg
}

#[pyfunction]
#[allow(clippy::too_many_arguments)]
#[pyo3(signature = (base_date, window_minutes, varga, target_sign, lat, lon, alt=0.0, ayanamsa="lahiri", true_nodes=true))]
fn find_time_windows(
    base_date: &str,
    window_minutes: i32,
    varga: u32,
    target_sign: &str,
    lat: f64,
    lon: f64,
    alt: f64,
    ayanamsa: &str,
    true_nodes: bool,
) -> PyResult<Vec<(String, String)>> {
    let aya = parse_ayanamsa(ayanamsa)?;
    validate_geo(lat, lon, alt)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;

    let base_dt = DateTime::parse_from_rfc3339(base_date)
        .or_else(|_| DateTime::parse_from_str(base_date, "%Y-%m-%d %H:%M:%S%z"))
        .or_else(|_| {
            DateTime::parse_from_str(
                &(base_date.to_owned() + "T00:00:00Z"),
                "%Y-%m-%dT%H:%M:%S%z",
            )
        })
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?
        .with_timezone(&Utc);

    let start_dt = base_dt - chrono::Duration::minutes(window_minutes as i64 / 2);
    let end_dt = base_dt + chrono::Duration::minutes(window_minutes as i64 / 2);

    let geo = GeoPosition {
        latitude: lat,
        longitude: lon,
        altitude: alt,
    };
    let target = target_sign.to_lowercase();
    let mut windows: Vec<(String, String)> = Vec::new();
    let mut current_window_start: Option<DateTime<Utc>> = None;

    let step_seconds = 300; // 5 minutes step
    let mut current_dt = start_dt;
    let mut last_matched: Option<bool> = None;

    let evaluate_sign = |dt: DateTime<Utc>| -> bool {
        if let Ok(c) = crate::calc::chart::calculate_chart(
            dt,
            geo.clone(),
            aya,
            crate::data::types::HouseSystem::Equal,
            true_nodes,
        ) {
            let div_sign = crate::charts::divisional::divisional_sign(c.ascendant, varga);
            format!("{:?}", div_sign).to_lowercase() == target
        } else {
            false
        }
    };

    while current_dt <= end_dt {
        let is_match = evaluate_sign(current_dt);

        if let Some(prev) = last_matched {
            if prev != is_match {
                // Boundary crossed, binary search for the exact transition second
                let mut left = current_dt - chrono::Duration::seconds(step_seconds);
                let mut right = current_dt;

                while (right - left).num_seconds() > 1 {
                    let mid = left + chrono::Duration::seconds((right - left).num_seconds() / 2);
                    let mid_match = evaluate_sign(mid);

                    if mid_match == prev {
                        left = mid;
                    } else {
                        right = mid;
                    }
                }

                // 'right' is the first second of the new state
                if is_match {
                    // Transitioned into the target sign
                    current_window_start = Some(right);
                } else {
                    // Transitioned out of the target sign
                    if let Some(start) = current_window_start {
                        windows.push((
                            start.format("%Y-%m-%dT%H:%M:%SZ").to_string(),
                            right.format("%Y-%m-%dT%H:%M:%SZ").to_string(),
                        ));
                        current_window_start = None;
                    }
                }
            }
        } else if is_match {
            // First evaluation is a match
            current_window_start = Some(current_dt);
        }

        last_matched = Some(is_match);
        current_dt += chrono::Duration::seconds(step_seconds);
    }

    if let Some(start) = current_window_start {
        windows.push((
            start.format("%Y-%m-%dT%H:%M:%SZ").to_string(),
            end_dt.format("%Y-%m-%dT%H:%M:%SZ").to_string(),
        ));
    }

    Ok(windows)
}

#[pyfunction]
#[allow(clippy::type_complexity)]
#[pyo3(signature = (inputs, ayanamsa="lahiri", house_system="equal", true_nodes=true))]
fn compute_chart_batch(
    inputs: Vec<(i32, u32, u32, u32, u32, u32, f64, f64, f64)>,
    ayanamsa: &str,
    house_system: &str,
    true_nodes: bool,
) -> PyResult<Vec<PyChart>> {
    let aya = parse_ayanamsa(ayanamsa)?;
    let hs = parse_house_system(house_system)?;

    let results: Result<Vec<PyChart>, String> = inputs
        .into_iter()
        .map(|(y, m, d, h, min, s, lat, lon, alt)| {
            validate_geo(lat, lon, alt).map_err(|e| e.to_string())?;

            let dt = Utc
                .with_ymd_and_hms(y, m, d, h, min, s)
                .single()
                .ok_or_else(|| "Invalid date/time".to_string())?;

            let geo = GeoPosition {
                latitude: lat,
                longitude: lon,
                altitude: alt,
            };

            let c = crate::calc::chart::calculate_chart(dt, geo, aya, hs, true_nodes)
                .map_err(|e| format!("{:?}", e))?;

            Ok(PyChart { inner: c })
        })
        .collect();

    results.map_err(PyErr::new::<pyo3::exceptions::PyValueError, _>)
}

#[pyfunction]
#[pyo3(signature = (from_date, to_date, ayanamsa="lahiri", true_nodes=true))]
fn get_transits(
    py: Python,
    from_date: &str,
    to_date: &str,
    ayanamsa: &str,
    true_nodes: bool,
) -> PyResult<PyObject> {
    let aya = parse_ayanamsa(ayanamsa)?;

    let from_dt = DateTime::parse_from_rfc3339(from_date)
        .or_else(|_| DateTime::parse_from_str(from_date, "%Y-%m-%d %H:%M:%S%z"))
        .or_else(|_| {
            DateTime::parse_from_str(
                &(from_date.to_owned() + "T00:00:00Z"),
                "%Y-%m-%dT%H:%M:%S%z",
            )
        })
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?
        .with_timezone(&Utc);

    let to_dt = DateTime::parse_from_rfc3339(to_date)
        .or_else(|_| DateTime::parse_from_str(to_date, "%Y-%m-%d %H:%M:%S%z"))
        .or_else(|_| {
            DateTime::parse_from_str(&(to_date.to_owned() + "T00:00:00Z"), "%Y-%m-%dT%H:%M:%S%z")
        })
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?
        .with_timezone(&Utc);

    let ephe = Ephemeris::new(aya, true_nodes);
    let from_jd = ephe.julian_day(&from_dt);
    let to_jd = ephe.julian_day(&to_dt);

    let events = crate::calc::transits::find_sign_ingresses(from_jd, to_jd, aya, true_nodes);

    let list = pyo3::types::PyList::empty(py);
    for e in events {
        let dict = PyDict::new(py);
        dict.set_item("planet", planet_to_str(e.planet))?;
        dict.set_item("from_sign", sign_to_str(e.from_sign))?;
        dict.set_item("to_sign", sign_to_str(e.to_sign))?;
        dict.set_item("ingress_time", e.ingress_time.to_rfc3339())?;
        dict.set_item("is_retrograde", e.is_retrograde)?;
        list.append(dict)?;
    }

    Ok(list.into())
}

#[pyfunction(name = "local_to_utc")]
fn py_local_to_utc(
    year: i32,
    month: u32,
    day: u32,
    hour: u32,
    minute: u32,
    second: u32,
    tz_str: &str,
) -> PyResult<String> {
    crate::util::timezone::local_to_utc(year, month, day, hour, minute, second, tz_str)
        .map(|dt| dt.to_rfc3339())
        .map_err(PyErr::new::<pyo3::exceptions::PyValueError, _>)
}

#[pyfunction(name = "compute_dignities")]
fn py_compute_dignities(
    py: Python,
    planet_str: &str,
    sign_str: &str,
    longitude: f64,
) -> PyResult<PyObject> {
    let planet = match planet_str.to_lowercase().as_str() {
        "sun" => Planet::Sun,
        "moon" => Planet::Moon,
        "mars" => Planet::Mars,
        "mercury" => Planet::Mercury,
        "jupiter" => Planet::Jupiter,
        "venus" => Planet::Venus,
        "saturn" => Planet::Saturn,
        _ => {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "Invalid planet",
            ))
        }
    };
    let sign = match sign_str.to_lowercase().as_str() {
        "aries" => Sign::Aries,
        "taurus" => Sign::Taurus,
        "gemini" => Sign::Gemini,
        "cancer" => Sign::Cancer,
        "leo" => Sign::Leo,
        "virgo" => Sign::Virgo,
        "libra" => Sign::Libra,
        "scorpio" => Sign::Scorpio,
        "sagittarius" => Sign::Sagittarius,
        "capricorn" => Sign::Capricorn,
        "aquarius" => Sign::Aquarius,
        "pisces" => Sign::Pisces,
        _ => {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "Invalid sign",
            ))
        }
    };
    let d = crate::calc::chart::compute_dignities(planet, sign, longitude);
    let dict = PyDict::new(py);
    dict.set_item("is_exalted", d.is_exalted)?;
    dict.set_item("is_debilitated", d.is_debilitated)?;
    dict.set_item("is_own_sign", d.is_own_sign)?;
    dict.set_item("is_moolatrikona", d.is_moolatrikona)?;
    Ok(dict.into())
}
