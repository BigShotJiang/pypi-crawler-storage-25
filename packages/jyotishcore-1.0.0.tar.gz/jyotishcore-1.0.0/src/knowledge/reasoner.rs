use crate::data::types::Chart;
use crate::knowledge::graph::Graph;
use crate::knowledge::rules::AstroRule;

pub struct Reasoner {
    rules: Vec<Box<dyn AstroRule>>,
}

impl Default for Reasoner {
    fn default() -> Self {
        Self::new()
    }
}

impl Reasoner {
    pub fn new() -> Self {
        Reasoner { rules: Vec::new() }
    }

    pub fn add_rule(&mut self, rule: Box<dyn AstroRule>) {
        self.rules.push(rule);
    }

    /// Evaluate all rules against a chart and return a merged explanation graph.
    pub fn explain(&self, chart: &Chart) -> Graph {
        let mut full_graph = Graph::new();
        for rule in &self.rules {
            if let Some(subgraph) = rule.evaluate(chart) {
                full_graph.merge(subgraph);
            }
        }
        full_graph
    }
}
