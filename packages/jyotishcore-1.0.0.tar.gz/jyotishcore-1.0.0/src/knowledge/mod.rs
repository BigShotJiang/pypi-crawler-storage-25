pub mod graph;
pub mod reasoner;
pub mod rules;
pub mod text_source;

use crate::data::types::{Chart, Planet};
use crate::knowledge::graph::Graph;
use crate::knowledge::reasoner::Reasoner;

/// Convenience function: get a graph explanation for a chart using a default set of rules.
pub fn get_explanation(chart: &Chart) -> Graph {
    let mut reasoner = Reasoner::new();
    for rule in all_rules() {
        reasoner.add_rule(rule);
    }
    reasoner.explain(chart)
}

pub fn all_rules() -> Vec<Box<dyn crate::knowledge::rules::AstroRule>> {
    use crate::knowledge::rules::*;
    vec![
        Box::new(GajaKesariYoga),
        Box::new(PanchaMahapurushaYoga::new(
            Planet::Mars,
            "Ruchaka Yoga",
            "Mars in Kendra and Own/Exalted sign.",
        )),
        Box::new(PanchaMahapurushaYoga::new(
            Planet::Mercury,
            "Bhadra Yoga",
            "Mercury in Kendra and Own/Exalted sign.",
        )),
        Box::new(PanchaMahapurushaYoga::new(
            Planet::Jupiter,
            "Hamsa Yoga",
            "Jupiter in Kendra and Own/Exalted sign.",
        )),
        Box::new(PanchaMahapurushaYoga::new(
            Planet::Venus,
            "Malavya Yoga",
            "Venus in Kendra and Own/Exalted sign.",
        )),
        Box::new(PanchaMahapurushaYoga::new(
            Planet::Saturn,
            "Sasa Yoga",
            "Saturn in Kendra and Own/Exalted sign.",
        )),
        Box::new(DharmaKarmadhipatiYoga),
        Box::new(BudhaAdityaYoga),
        Box::new(LakshmiYoga),
        Box::new(SunaphaYoga),
        Box::new(AnaphaYoga),
        Box::new(VeshiYoga),
        Box::new(VoshiYoga),
        Box::new(AmalaYoga),
        Box::new(DhanaYoga),
        Box::new(SaraswatiYoga),
        Box::new(KemadrumaYoga),
    ]
}

/// Serialize graph to JSON.
pub fn graph_to_json(graph: &Graph) -> String {
    serde_json::to_string_pretty(graph).unwrap_or_default()
}
