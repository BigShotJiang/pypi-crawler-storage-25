use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Node {
    Planet(PlanetNode),
    Sign(SignNode),
    House(HouseNode),
    Rule(RuleNode),
    Condition(ConditionNode),
    TextSource(TextSourceNode),
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct PlanetNode {
    pub name: String,
    pub id: String, // e.g., "planet_sun"
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct SignNode {
    pub name: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct HouseNode {
    pub number: u8,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct RuleNode {
    pub name: String,
    pub description: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ConditionNode {
    pub expression: String, // human-readable condition
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct TextSourceNode {
    pub title: String,
    pub chapter: String,
    pub verse: String,
    pub snippet: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Edge {
    LocatedIn,
    HasSign,
    InHouse,
    TriggersRule,
    ProvesCondition,
    DependsOn,
    Cites,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Graph {
    pub nodes: HashMap<String, Node>,
    pub edges: Vec<(String, String, Edge)>, // (source_id, target_id, edge_type)
}

impl Default for Graph {
    fn default() -> Self {
        Self::new()
    }
}

impl Graph {
    pub fn new() -> Self {
        Graph {
            nodes: HashMap::new(),
            edges: Vec::new(),
        }
    }

    pub fn add_node(&mut self, id: &str, node: Node) {
        self.nodes.insert(id.to_string(), node);
    }

    pub fn add_edge(&mut self, from: &str, to: &str, edge: Edge) {
        self.edges.push((from.to_string(), to.to_string(), edge));
    }

    /// Merge another graph into this one.
    pub fn merge(&mut self, other: Graph) {
        for (id, node) in other.nodes {
            self.nodes.entry(id).or_insert(node);
        }
        self.edges.extend(other.edges);
    }
}
