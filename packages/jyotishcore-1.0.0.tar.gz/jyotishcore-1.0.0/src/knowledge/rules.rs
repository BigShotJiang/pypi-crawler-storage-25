use crate::data::types::*;
use crate::knowledge::graph::*;

/// Trait for an explainable rule.
pub trait AstroRule {
    fn name(&self) -> &str;
    fn description(&self) -> &str;
    /// Evaluate the rule against a chart and return a causal subgraph if present.
    fn evaluate(&self, chart: &Chart) -> Option<Graph>;
}

/// Gaja Kesari Yoga: Jupiter is in a kendra (1,4,7,10) from the Moon.
pub struct GajaKesariYoga;

impl AstroRule for GajaKesariYoga {
    fn name(&self) -> &str {
        "Gaja Kesari Yoga"
    }
    fn description(&self) -> &str {
        "Jupiter in a kendra from the Moon gives wisdom and prosperity."
    }

    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let jupiter = chart.planets.iter().find(|p| p.planet == Planet::Jupiter)?;
        let moon = chart.planets.iter().find(|p| p.planet == Planet::Moon)?;

        let jup_house = jupiter.house?;
        let moon_house = moon.house?;

        // Kendra houses relative to Moon (Vedic counting is inclusive)
        let kendras = [
            moon_house,
            (moon_house + 4 - 2) % 12 + 1,
            (moon_house + 7 - 2) % 12 + 1,
            (moon_house + 10 - 2) % 12 + 1,
        ];

        if !kendras.contains(&jup_house) {
            return None;
        }

        // Build explanation graph
        let mut g = Graph::new();

        // Nodes for planets and houses
        let jup_id = "planet_jupiter";
        let moon_id = "planet_moon";
        let jup_node = PlanetNode {
            name: "Jupiter".into(),
            id: jup_id.into(),
        };
        let moon_node = PlanetNode {
            name: "Moon".into(),
            id: moon_id.into(),
        };
        g.add_node(jup_id, Node::Planet(jup_node));
        g.add_node(moon_id, Node::Planet(moon_node));

        let house_jup_id = format!("house_{}", jup_house);
        let house_moon_id = format!("house_{}", moon_house);
        g.add_node(&house_jup_id, Node::House(HouseNode { number: jup_house }));
        g.add_node(
            &house_moon_id,
            Node::House(HouseNode { number: moon_house }),
        );

        // Edges: planet located in house
        g.add_edge(jup_id, &house_jup_id, Edge::LocatedIn);
        g.add_edge(moon_id, &house_moon_id, Edge::LocatedIn);

        // Rule node
        let rule_id = "rule_gaja_kesari";
        g.add_node(
            rule_id,
            Node::Rule(RuleNode {
                name: self.name().into(),
                description: self.description().into(),
            }),
        );

        // Condition: "Jupiter's house is a kendra from Moon's house"
        let cond_id = "condition_jup_kendra_moon";
        g.add_node(
            cond_id,
            Node::Condition(ConditionNode {
                expression: format!(
                    "House of Jupiter ({}) is in kendra from House of Moon ({})",
                    jup_house, moon_house
                ),
            }),
        );

        // Links
        g.add_edge(rule_id, cond_id, Edge::DependsOn);
        g.add_edge(cond_id, jup_id, Edge::DependsOn);
        g.add_edge(cond_id, moon_id, Edge::DependsOn);

        // Textual source
        let text_id = "source_bphs_36";
        g.add_node(
            text_id,
            Node::TextSource(TextSourceNode {
                title: "Brihat Parashara Hora Shastra".into(),
                chapter: "Ch. 36".into(),
                verse: "36.3-4".into(),
                snippet: "If Jupiter is in a kendra from the Moon, Gaja Kesari Yoga is formed..."
                    .into(),
            }),
        );
        g.add_edge(rule_id, text_id, Edge::Cites);

        Some(g)
    }
}
fn is_own_or_exalted(planet: Planet, sign: Sign) -> bool {
    match planet {
        Planet::Mars => matches!(sign, Sign::Aries | Sign::Scorpio | Sign::Capricorn),
        Planet::Mercury => matches!(sign, Sign::Gemini | Sign::Virgo),
        Planet::Jupiter => matches!(sign, Sign::Sagittarius | Sign::Pisces | Sign::Cancer),
        Planet::Venus => matches!(sign, Sign::Taurus | Sign::Libra | Sign::Pisces),
        Planet::Saturn => matches!(sign, Sign::Capricorn | Sign::Aquarius | Sign::Libra),
        _ => false,
    }
}

fn is_kendra(house: u8) -> bool {
    matches!(house, 1 | 4 | 7 | 10)
}

/// Pancha Mahapurusha Yogas (Mars, Mercury, Jupiter, Venus, Saturn in Kendra and Own/Exalted sign)
pub struct PanchaMahapurushaYoga {
    pub planet: Planet,
    pub name: String,
    pub description: String,
}

impl PanchaMahapurushaYoga {
    pub fn new(planet: Planet, name: &str, description: &str) -> Self {
        Self {
            planet,
            name: name.to_string(),
            description: description.to_string(),
        }
    }
}

impl AstroRule for PanchaMahapurushaYoga {
    fn name(&self) -> &str {
        &self.name
    }
    fn description(&self) -> &str {
        &self.description
    }

    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let pos = chart.planets.iter().find(|p| p.planet == self.planet)?;
        let house = pos.house?;
        let sign = pos.sign?;

        if is_kendra(house) && is_own_or_exalted(self.planet, sign) {
            let mut g = Graph::new();
            let planet_id = format!("planet_{:?}", self.planet).to_lowercase();
            g.add_node(
                &planet_id,
                Node::Planet(PlanetNode {
                    name: format!("{:?}", self.planet),
                    id: planet_id.clone(),
                }),
            );

            let house_id = format!("house_{}", house);
            g.add_node(&house_id, Node::House(HouseNode { number: house }));
            g.add_edge(&planet_id, &house_id, Edge::LocatedIn);

            let rule_id = format!("rule_{}", self.name.to_lowercase().replace(' ', "_"));
            g.add_node(
                &rule_id,
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );

            let cond_id = format!("cond_{}", rule_id);
            g.add_node(
                &cond_id,
                Node::Condition(ConditionNode {
                    expression: format!(
                        "{:?} is in Kendra (house {}) and in own/exalted sign ({:?})",
                        self.planet, house, sign
                    ),
                }),
            );

            g.add_edge(&rule_id, &cond_id, Edge::DependsOn);
            g.add_edge(&cond_id, &planet_id, Edge::DependsOn);

            return Some(g);
        }
        None
    }
}

/// Kemadruma Yoga: Moon has no planets (excluding Sun/Rahu/Ketu) in 2nd or 12th from it.
pub struct KemadrumaYoga;

impl AstroRule for KemadrumaYoga {
    fn name(&self) -> &str {
        "Kemadruma Yoga"
    }
    fn description(&self) -> &str {
        "Moon with no planets in 2nd or 12th from it indicates struggle and isolation."
    }

    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let moon = chart.planets.iter().find(|p| p.planet == Planet::Moon)?;
        let moon_house = moon.house?;

        let house_2 = (moon_house % 12) + 1;
        let house_12 = if moon_house == 1 { 12 } else { moon_house - 1 };

        let occupants = chart
            .planets
            .iter()
            .filter(|p| {
                p.planet != Planet::Moon
                    && p.planet != Planet::Sun
                    && p.planet != Planet::Rahu
                    && p.planet != Planet::Ketu
                    && p.house.is_some()
                    && (p.house.unwrap() == house_2
                        || p.house.unwrap() == house_12
                        || p.house.unwrap() == moon_house)
            })
            .count();

        if occupants == 0 {
            let mut g = Graph::new();
            let rule_id = "rule_kemadruma";
            g.add_node(
                rule_id,
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            let cond_id = "cond_kemadruma";
            g.add_node(
                cond_id,
                Node::Condition(ConditionNode {
                    expression: format!(
                        "No planets in house {} or {} from Moon (house {})",
                        house_2, house_12, moon_house
                    ),
                }),
            );
            g.add_edge(rule_id, cond_id, Edge::DependsOn);
            return Some(g);
        }
        None
    }
}

/// Helper to get lord of a house
pub fn get_house_lord(house_num: u8, chart: &Chart) -> Option<Planet> {
    let cusp = chart.houses.iter().find(|h| h.house == house_num)?.cusp;
    let sign_on_cusp = crate::zodiac::sign_from_longitude(cusp);
    Some(match sign_on_cusp {
        Sign::Aries | Sign::Scorpio => Planet::Mars,
        Sign::Taurus | Sign::Libra => Planet::Venus,
        Sign::Gemini | Sign::Virgo => Planet::Mercury,
        Sign::Cancer => Planet::Moon,
        Sign::Leo => Planet::Sun,
        Sign::Sagittarius | Sign::Pisces => Planet::Jupiter,
        Sign::Capricorn | Sign::Aquarius => Planet::Saturn,
    })
}

/// Helper to check if two planets are related (conjunct or mutual aspect)
pub fn are_related(p1: Planet, p2: Planet, chart: &Chart) -> bool {
    let pos1 = match chart.planets.iter().find(|p| p.planet == p1) {
        Some(p) => p,
        None => return false,
    };
    let pos2 = match chart.planets.iter().find(|p| p.planet == p2) {
        Some(p) => p,
        None => return false,
    };

    if pos1.house == pos2.house {
        return true;
    }

    // Mutual aspect
    let a1 = chart
        .aspects
        .iter()
        .any(|a| a.from_planet == p1 && a.to_planet == Some(p2));
    let a2 = chart
        .aspects
        .iter()
        .any(|a| a.from_planet == p2 && a.to_planet == Some(p1));
    a1 && a2
}

/// Dharma-Karmadhipati Yoga: Lords of 9th and 10th houses in conjunction or mutual aspect.
pub struct DharmaKarmadhipatiYoga;

impl AstroRule for DharmaKarmadhipatiYoga {
    fn name(&self) -> &str {
        "Dharma Karmadhipati Yoga"
    }
    fn description(&self) -> &str {
        "Relationship between 9th and 10th lords gives great success and authority."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let l9 = get_house_lord(9, chart)?;
        let l10 = get_house_lord(10, chart)?;
        if are_related(l9, l10, chart) {
            let mut g = Graph::new();
            let rule_id = "rule_dharma_karmadhipati";
            g.add_node(
                rule_id,
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            let cond_id = "cond_l9_l10_related";
            g.add_node(
                cond_id,
                Node::Condition(ConditionNode {
                    expression: format!(
                        "Lord of 9H ({:?}) and Lord of 10H ({:?}) are related",
                        l9, l10
                    ),
                }),
            );
            g.add_edge(rule_id, cond_id, Edge::DependsOn);
            return Some(g);
        }
        None
    }
}

/// Budha-Aditya Yoga: Sun and Mercury conjunct.
pub struct BudhaAdityaYoga;

impl AstroRule for BudhaAdityaYoga {
    fn name(&self) -> &str {
        "Budha Aditya Yoga"
    }
    fn description(&self) -> &str {
        "Sun and Mercury conjunction gives intelligence and communication skills."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let sun = chart.planets.iter().find(|p| p.planet == Planet::Sun)?;
        let merc = chart.planets.iter().find(|p| p.planet == Planet::Mercury)?;
        if sun.house == merc.house {
            let mut g = Graph::new();
            let rule_id = "rule_budha_aditya";
            g.add_node(
                rule_id,
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            let cond_id = "cond_sun_merc_conjunct";
            g.add_node(
                cond_id,
                Node::Condition(ConditionNode {
                    expression: "Sun and Mercury are in the same house".into(),
                }),
            );
            g.add_edge(rule_id, cond_id, Edge::DependsOn);
            return Some(g);
        }
        None
    }
}

/// Lakshmi Yoga: Lord of 9th house and Venus in a relationship, or 9th lord in Kendra.
pub struct LakshmiYoga;

impl AstroRule for LakshmiYoga {
    fn name(&self) -> &str {
        "Lakshmi Yoga"
    }
    fn description(&self) -> &str {
        "Strong 9th lord or its relation with Venus gives wealth and grace."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let l9 = get_house_lord(9, chart)?;
        let l9_pos = chart.planets.iter().find(|p| p.planet == l9)?;
        if is_kendra(l9_pos.house?) && is_own_or_exalted(l9, l9_pos.sign?) {
            let mut g = Graph::new();
            let rule_id = "rule_lakshmi";
            g.add_node(
                rule_id,
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            return Some(g);
        }
        None
    }
}

/// Sunapha Yoga: Planets (other than Sun/Rahu/Ketu) in 2nd from Moon.
pub struct SunaphaYoga;

impl AstroRule for SunaphaYoga {
    fn name(&self) -> &str {
        "Sunapha Yoga"
    }
    fn description(&self) -> &str {
        "Planets in 2nd from Moon indicate self-acquired wealth."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let moon_house = chart
            .planets
            .iter()
            .find(|p| p.planet == Planet::Moon)?
            .house?;
        let house_2 = (moon_house % 12) + 1;
        let has_planet = chart.planets.iter().any(|p| {
            p.house == Some(house_2)
                && !matches!(
                    p.planet,
                    Planet::Sun | Planet::Moon | Planet::Rahu | Planet::Ketu
                )
        });
        if has_planet {
            let mut g = Graph::new();
            g.add_node(
                "rule_sunapha",
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            return Some(g);
        }
        None
    }
}

/// Anapha Yoga: Planets (other than Sun/Rahu/Ketu) in 12th from Moon.
pub struct AnaphaYoga;

impl AstroRule for AnaphaYoga {
    fn name(&self) -> &str {
        "Anapha Yoga"
    }
    fn description(&self) -> &str {
        "Planets in 12th from Moon indicate spirituality or luxury."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let moon_house = chart
            .planets
            .iter()
            .find(|p| p.planet == Planet::Moon)?
            .house?;
        let house_12 = if moon_house == 1 { 12 } else { moon_house - 1 };
        let has_planet = chart.planets.iter().any(|p| {
            p.house == Some(house_12)
                && !matches!(
                    p.planet,
                    Planet::Sun | Planet::Moon | Planet::Rahu | Planet::Ketu
                )
        });
        if has_planet {
            let mut g = Graph::new();
            g.add_node(
                "rule_anapha",
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            return Some(g);
        }
        None
    }
}

/// Veshi Yoga: Planets (other than Moon/Rahu/Ketu) in 2nd from Sun.
pub struct VeshiYoga;

impl AstroRule for VeshiYoga {
    fn name(&self) -> &str {
        "Veshi Yoga"
    }
    fn description(&self) -> &str {
        "Planets in 2nd from Sun give good name and fame."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let sun_house = chart
            .planets
            .iter()
            .find(|p| p.planet == Planet::Sun)?
            .house?;
        let house_2 = (sun_house % 12) + 1;
        let has_planet = chart.planets.iter().any(|p| {
            p.house == Some(house_2)
                && !matches!(
                    p.planet,
                    Planet::Sun | Planet::Moon | Planet::Rahu | Planet::Ketu
                )
        });
        if has_planet {
            let mut g = Graph::new();
            g.add_node(
                "rule_veshi",
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            return Some(g);
        }
        None
    }
}

/// Voshi Yoga: Planets (other than Moon/Rahu/Ketu) in 12th from Sun.
pub struct VoshiYoga;

impl AstroRule for VoshiYoga {
    fn name(&self) -> &str {
        "Voshi Yoga"
    }
    fn description(&self) -> &str {
        "Planets in 12th from Sun give learning and knowledge."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let sun_house = chart
            .planets
            .iter()
            .find(|p| p.planet == Planet::Sun)?
            .house?;
        let house_12 = if sun_house == 1 { 12 } else { sun_house - 1 };
        let has_planet = chart.planets.iter().any(|p| {
            p.house == Some(house_12)
                && !matches!(
                    p.planet,
                    Planet::Sun | Planet::Moon | Planet::Rahu | Planet::Ketu
                )
        });
        if has_planet {
            let mut g = Graph::new();
            g.add_node(
                "rule_voshi",
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            return Some(g);
        }
        None
    }
}

/// Amala Yoga: Benefic (Mercury, Jupiter, Venus) in 10th from Lagna or Moon.
pub struct AmalaYoga;

impl AstroRule for AmalaYoga {
    fn name(&self) -> &str {
        "Amala Yoga"
    }
    fn description(&self) -> &str {
        "Benefic in 10th house gives pure character and success."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let is_benefic = |p: Planet| matches!(p, Planet::Mercury | Planet::Jupiter | Planet::Venus);
        let check_from = |base_house: u8| -> bool {
            let h10 = (base_house + 10 - 2) % 12 + 1;
            chart
                .planets
                .iter()
                .any(|p| p.house == Some(h10) && is_benefic(p.planet))
        };

        let moon_house = chart
            .planets
            .iter()
            .find(|p| p.planet == Planet::Moon)
            .and_then(|p| p.house)
            .unwrap_or(1);
        if check_from(1) || check_from(moon_house) {
            let mut g = Graph::new();
            g.add_node(
                "rule_amala",
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            return Some(g);
        }
        None
    }
}

/// Dhana Yoga: Relationship between 2nd lord and 11th lord.
pub struct DhanaYoga;

impl AstroRule for DhanaYoga {
    fn name(&self) -> &str {
        "Dhana Yoga"
    }
    fn description(&self) -> &str {
        "Relationship between wealth lords (2H and 11H) indicates great riches."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let l2 = get_house_lord(2, chart)?;
        let l11 = get_house_lord(11, chart)?;
        if are_related(l2, l11, chart) {
            let mut g = Graph::new();
            g.add_node(
                "rule_dhana",
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            return Some(g);
        }
        None
    }
}

/// Saraswati Yoga: Jupiter, Venus, and Mercury in Kendra/Trikona in Own/Exalted.
pub struct SaraswatiYoga;

impl AstroRule for SaraswatiYoga {
    fn name(&self) -> &str {
        "Saraswati Yoga"
    }
    fn description(&self) -> &str {
        "Jupiter, Venus, and Mercury strong in auspicious houses give learning."
    }
    fn evaluate(&self, chart: &Chart) -> Option<Graph> {
        let planets = [Planet::Jupiter, Planet::Venus, Planet::Mercury];
        let mut strong_count = 0;
        for p_type in planets {
            if let Some(p) = chart.planets.iter().find(|pos| pos.planet == p_type) {
                let h = p.house.unwrap_or(0);
                let is_auspicious = is_kendra(h) || matches!(h, 5 | 9);
                if is_auspicious && is_own_or_exalted(p_type, p.sign.unwrap_or(Sign::Aries)) {
                    strong_count += 1;
                }
            }
        }
        if strong_count == 3 {
            let mut g = Graph::new();
            g.add_node(
                "rule_saraswati",
                Node::Rule(RuleNode {
                    name: self.name().into(),
                    description: self.description().into(),
                }),
            );
            return Some(g);
        }
        None
    }
}
