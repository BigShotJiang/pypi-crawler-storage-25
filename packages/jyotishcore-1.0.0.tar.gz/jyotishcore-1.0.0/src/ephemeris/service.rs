use crate::data::constants::*;
use crate::data::types::*;
use crate::ephemeris::swe_bindings::*;
use crate::error::JyotishError;
use chrono::{DateTime, Datelike, Timelike, Utc};
use std::ffi::CString;

pub struct Ephemeris {
    pub ayanamsa: AyanamsaMode,
    pub true_nodes: bool,
}

impl Ephemeris {
    pub fn new(ayanamsa: AyanamsaMode, true_nodes: bool) -> Self {
        unsafe {
            match ayanamsa {
                AyanamsaMode::Custom(offset) => {
                    swe_set_sid_mode(SIDM_USER, offset, 0.0);
                }
                _ => {
                    let sid = match ayanamsa {
                        AyanamsaMode::Lahiri => SIDM_LAHIRI,
                        AyanamsaMode::Raman => SIDM_RAMAN,
                        AyanamsaMode::Krishnamurti => SIDM_KRISHNAMURTI,
                        AyanamsaMode::TrueChitra => SIDM_TRUE_CITRA,
                        AyanamsaMode::TruePushya => SIDM_TRUE_PUSHYA,
                        _ => unreachable!(),
                    };
                    swe_set_sid_mode(sid, 0.0, 0.0);
                }
            }
        }
        Self {
            ayanamsa,
            true_nodes,
        }
    }

    /// Convert UTC datetime to Julian Day UT (Universal Time).
    ///
    /// This returns the Julian Day Number for use with Swiss Ephemeris `swe_calc_ut()`
    /// and other UT-based ephemeris calculations. It is NOT Ephemeris Time (ET/TT),
    /// which requires additional leap-second adjustments.
    ///
    /// # Parameters
    /// - `dt`: DateTime<Utc> representing the UTC moment
    ///
    /// # Returns
    /// Julian Day UT number (JD) for use in ephemeris calculations
    pub fn julian_day(&self, dt: &DateTime<Utc>) -> f64 {
        let year = dt.year();
        let month = dt.month() as i32;
        let day = dt.day() as i32;
        let hour = dt.hour() as f64 + dt.minute() as f64 / 60.0 + dt.second() as f64 / 3600.0;
        unsafe { swe_julday(year, month, day, hour, 1) } // Gregorian flag = 1
    }

    /// Convert Julian Day UT back to UTC DateTime.
    ///
    /// Inverse of `julian_day()`. Takes a Julian Day UT value (as returned by
    /// Swiss Ephemeris or other UT-based calculations) and converts it back to
    /// a standard UTC DateTime.
    ///
    /// # Parameters
    /// - `jd`: Julian Day UT number
    ///
    /// # Returns
    /// DateTime<Utc> representing the equivalent UTC moment
    pub fn from_julian_day(&self, jd: f64) -> DateTime<Utc> {
        let mut year = 0i32;
        let mut month = 0i32;
        let mut day = 0i32;
        let mut hour_frac = 0.0f64;
        unsafe { swe_revjul(jd, 1, &mut year, &mut month, &mut day, &mut hour_frac) };

        let date = chrono::NaiveDate::from_ymd_opt(year, month as u32, day as u32)
            .expect("swe_revjul returned invalid date");
        let seconds = (hour_frac * 3600.0).round() as i64;
        let naive =
            date.and_hms_opt(0, 0, 0).expect("midnight") + chrono::Duration::seconds(seconds);
        DateTime::from_naive_utc_and_offset(naive, Utc)
    }

    /// Compute a planet's position. Returns a PlanetPosition with sidereal longitude, latitude, speed, etc.
    pub fn calc_ut(&self, jd: f64, planet: Planet) -> Result<PlanetPosition, JyotishError> {
        let pid = match planet {
            Planet::Sun => SE_SUN,
            Planet::Moon => SE_MOON,
            Planet::Mercury => SE_MERCURY,
            Planet::Venus => SE_VENUS,
            Planet::Mars => SE_MARS,
            Planet::Jupiter => SE_JUPITER,
            Planet::Saturn => SE_SATURN,
            // For Rahu/Ketu, we compute the node position first, then adjust for Ketu.
            Planet::Rahu => {
                if self.true_nodes {
                    SE_TRUE_NODE
                } else {
                    SE_MEAN_NODE
                }
            }
            Planet::Ketu => {
                if self.true_nodes {
                    SE_TRUE_NODE
                } else {
                    SE_MEAN_NODE
                }
            }
        };

        let iflag = FLG_SWIEPH | FLG_SIDEREAL | FLG_SPEED; // sidereal + speed
        let mut xx = [0.0f64; 6];
        let mut serr = [0i8; 256];

        let res = unsafe { swe_calc_ut(jd, pid, iflag, xx.as_mut_ptr(), serr.as_mut_ptr()) };

        if res < 0 {
            let err_msg = unsafe {
                std::ffi::CStr::from_ptr(serr.as_ptr())
                    .to_string_lossy()
                    .into_owned()
            };
            return Err(JyotishError::SweCalculation {
                planet: format!("{:?}", planet),
                msg: err_msg,
            });
        }

        let mut longitude = xx[0];
        if longitude.is_nan() {
            return Err(JyotishError::SweCalculation {
                planet: format!("{:?}", planet),
                msg: "NaN returned".into(),
            });
        }

        // For Ketu, add 180° to Rahu's position and normalize.
        if matches!(planet, Planet::Ketu) {
            longitude = (longitude + 180.0) % 360.0;
        }

        Ok(PlanetPosition {
            planet,
            longitude,
            latitude: xx[1],
            speed: xx[3],
            is_retrograde: xx[3] < 0.0,
            sign: None,
            nakshatra: None,
            house: None,
            divisional_signs: std::collections::HashMap::new(),
            is_exalted: false,
            is_debilitated: false,
            is_own_sign: false,
            is_moolatrikona: false,
            is_vargottama: false,
            shadbala: None,
        })
    }

    /// Sidereal ascendant longitude.
    pub fn get_ascendant(&self, jd: f64, geo: &GeoPosition) -> Result<f64, JyotishError> {
        let iflag = FLG_SWIEPH | FLG_SIDEREAL;
        let mut cusps = [0.0f64; 13];
        let mut ascmc = [0.0f64; 10];
        let res = unsafe {
            swe_houses_ex(
                jd,
                iflag,
                geo.latitude,
                geo.longitude,
                b'E' as i32,
                cusps.as_mut_ptr(),
                ascmc.as_mut_ptr(),
            )
        };
        if res < 0 {
            return Err(JyotishError::SweCalculation {
                planet: "Ascendant".into(),
                msg: "swe_houses_ex failed to compute ascendant".into(),
            });
        }
        Ok(ascmc[0])
    }

    /// Get house cusps for a given house system.
    pub fn get_houses(
        &self,
        jd: f64,
        geo: &GeoPosition,
        system: HouseSystem,
    ) -> Result<Vec<HouseCusp>, JyotishError> {
        let iflag = FLG_SWIEPH | FLG_SIDEREAL;
        let hsys = match system {
            HouseSystem::Equal => b'E' as i32,
            HouseSystem::Placidus => b'P' as i32,
            HouseSystem::Koch => b'K' as i32,
            HouseSystem::WholeSign => b'W' as i32,
        };
        let mut cusps = [0.0f64; 13];
        let mut ascmc = [0.0f64; 10];
        let res = unsafe {
            swe_houses_ex(
                jd,
                iflag,
                geo.latitude,
                geo.longitude,
                hsys,
                cusps.as_mut_ptr(),
                ascmc.as_mut_ptr(),
            )
        };
        if res < 0 {
            return Err(JyotishError::SweCalculation {
                planet: "Houses".into(),
                msg: format!("swe_houses_ex failed for house system {:?}", system),
            });
        }
        let mut houses = Vec::with_capacity(12);
        for (i, &cusp) in cusps.iter().enumerate().skip(1).take(12) {
            houses.push(HouseCusp {
                house: i as u8,
                cusp,
            });
        }
        Ok(houses)
    }

    /// Sunrise time (Julian Day) for the given date and location.
    pub fn sunrise(&self, jd: f64, geo: &GeoPosition) -> Result<f64, JyotishError> {
        let star = CString::new("").unwrap();
        let mut tret = [0.0f64; 2];
        let mut serr = [0i8; 256];
        let mut geopos = [geo.longitude, geo.latitude, geo.altitude];

        let res = unsafe {
            swe_rise_trans(
                jd,
                SE_SUN,
                star.as_ptr(),
                0,
                1, // 1 = rise
                geopos.as_mut_ptr(),
                0.0,
                0.0,
                tret.as_mut_ptr(),
                serr.as_mut_ptr(),
            )
        };

        if res < 0 {
            Err(JyotishError::InvalidParameter("Sun always up?".into()))
        } else {
            Ok(tret[0])
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::TimeZone;

    #[test]
    fn julian_day_round_trip_preserves_time_of_day() {
        let ephe = Ephemeris::new(AyanamsaMode::Lahiri, true);
        let dt = Utc.with_ymd_and_hms(2026, 5, 16, 6, 15, 0).unwrap();
        let jd = ephe.julian_day(&dt);

        assert_eq!(ephe.from_julian_day(jd), dt);
    }
}
