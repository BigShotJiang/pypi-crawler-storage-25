#![allow(non_camel_case_types)]
use std::ffi::c_char;

extern "C" {
    pub fn swe_julday(year: i32, month: i32, day: i32, hour: f64, gregflag: i32) -> f64;

    pub fn swe_revjul(
        jd: f64,
        gregflag: i32,
        year: *mut i32,
        month: *mut i32,
        day: *mut i32,
        hour: *mut f64,
    );

    pub fn swe_calc_ut(jd_ut: f64, planet: i32, iflag: i32, xx: *mut f64, serr: *mut i8) -> i32;

    pub fn swe_houses_ex(
        jd_ut: f64,
        iflag: i32,
        geolat: f64,
        geolon: f64,
        hsys: i32,
        cusps: *mut f64,
        ascmc: *mut f64,
    ) -> i32;

    pub fn swe_set_sid_mode(sid_mode: i32, t0: f64, ayan_t0: f64);

    pub fn swe_rise_trans(
        jd_ut: f64,
        ipl: i32,
        starname: *const c_char,
        epheflag: i32,
        rsmi: i32,
        geopos: *mut f64,
        atpress: f64,
        attemp: f64,
        tret: *mut f64,
        serr: *mut i8,
    ) -> i32;

    pub fn swe_close();
}
