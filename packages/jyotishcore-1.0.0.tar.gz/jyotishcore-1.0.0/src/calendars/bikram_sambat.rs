use chrono::{Duration, NaiveDate};
use serde_json::Value;
use std::collections::HashMap;
use std::sync::OnceLock;

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct BsDate {
    pub year: i32,
    pub month: u32, // 1 = Baishakh, 12 = Chaitra
    pub day: u32,
}

static CALENDAR_DATA: OnceLock<HashMap<i32, Vec<u32>>> = OnceLock::new();

fn get_calendar_data() -> &'static HashMap<i32, Vec<u32>> {
    CALENDAR_DATA.get_or_init(|| {
        let json_str = include_str!("../../data/calendar_data.json");
        let v: Value = serde_json::from_str(json_str).expect("Failed to parse calendar data");
        let mut map = HashMap::new();
        if let Some(obj) = v.as_object() {
            for (key, val) in obj {
                if let Ok(year) = key.parse::<i32>() {
                    if let Some(arr) = val.as_array() {
                        let lengths: Vec<u32> = arr
                            .iter()
                            .filter_map(|x| x.as_u64().map(|v| v as u32))
                            .collect();
                        if lengths.len() == 12 {
                            map.insert(year, lengths);
                        }
                    }
                }
            }
        }
        map
    })
}

impl BsDate {
    pub fn new(year: i32, month: u32, day: u32) -> Self {
        Self { year, month, day }
    }

    /// Convert a Gregorian date to BS.
    pub fn from_gregorian(ad: NaiveDate) -> Option<BsDate> {
        let epoch_ad = NaiveDate::from_ymd_opt(1943, 4, 14).expect("Invalid epoch");
        if ad < epoch_ad {
            return None;
        }

        let mut diff_days = (ad - epoch_ad).num_days();
        let data = get_calendar_data();

        let mut curr_year = 2000;
        loop {
            let year_days: u32 = data.get(&curr_year)?.iter().sum();
            if diff_days < year_days as i64 {
                break;
            }
            diff_days -= year_days as i64;
            curr_year += 1;
            if curr_year > 2100 {
                return None;
            }
        }

        let mut curr_month = 1;
        let month_lengths = data.get(&curr_year)?;
        for &len in month_lengths {
            if diff_days < len as i64 {
                break;
            }
            diff_days -= len as i64;
            curr_month += 1;
        }

        Some(BsDate {
            year: curr_year,
            month: curr_month as u32,
            day: (diff_days + 1) as u32,
        })
    }

    pub fn to_gregorian(&self) -> Option<NaiveDate> {
        let epoch_ad = NaiveDate::from_ymd_opt(1943, 4, 14).expect("Invalid epoch");
        let data = get_calendar_data();

        if self.year < 2000 || self.year > 2100 {
            return None;
        }

        let mut total_days: i64 = 0;
        for y in 2000..self.year {
            let year_days: u32 = data.get(&y)?.iter().sum();
            total_days += year_days as i64;
        }

        let month_lengths = data.get(&self.year)?;
        for m in 1..self.month {
            total_days += month_lengths[(m - 1) as usize] as i64;
        }

        total_days += (self.day - 1) as i64;

        epoch_ad.checked_add_signed(Duration::days(total_days))
    }

    pub fn month_name(&self) -> &'static str {
        match self.month {
            1 => "Baishakh",
            2 => "Jestha",
            3 => "Ashar",
            4 => "Shrawan",
            5 => "Bhadra",
            6 => "Ashwin",
            7 => "Kartik",
            8 => "Mangsir",
            9 => "Poush",
            10 => "Magh",
            11 => "Falgun",
            12 => "Chaitra",
            _ => "Unknown",
        }
    }

    /// Returns the number of days in a given BS month/year.
    pub fn month_length(year: i32, month: u32) -> Option<u32> {
        let data = get_calendar_data();
        let year_data = data.get(&year)?;
        year_data.get((month - 1) as usize).copied()
    }

    /// Check if a BS year has an adhik (leap) month.
    /// Note: In this static dataset, adhik mas is reflected in the month lengths
    /// but usually we check for 13 months. Our current dataset is fixed to 12.
    /// We'll return None for now as it needs a more complex dataset.
    pub fn has_adhik_mas(_year: i32) -> Option<u32> {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    #[test]
    fn test_conversion() {
        // BS 2081 Baishakh 1 = 2024-04-13
        let ad = NaiveDate::from_ymd_opt(2024, 4, 13).unwrap();
        let bs = BsDate::from_gregorian(ad).unwrap();
        assert_eq!(bs.year, 2081);
        assert_eq!(bs.month, 1);
        assert_eq!(bs.day, 1);

        let ad_back = bs.to_gregorian().unwrap();
        assert_eq!(ad_back, ad);
    }
}
