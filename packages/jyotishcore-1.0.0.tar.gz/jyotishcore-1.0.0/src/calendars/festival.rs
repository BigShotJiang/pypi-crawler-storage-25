use crate::calc::panchanga;
use crate::calendars::bikram_sambat::BsDate;
use crate::data::types::*;
use crate::ephemeris::service::Ephemeris;
use chrono::{DateTime, Utc};

pub struct FestivalOccurrence {
    pub name: String,
    pub date: BsDate,
    pub time_utc: DateTime<Utc>,
    pub description: String,
}

pub trait FestivalRule: Send + Sync {
    fn name(&self) -> &str;
    fn evaluate(
        &self,
        ephe: &Ephemeris,
        geo: &GeoPosition,
        bs_year: i32,
    ) -> Option<FestivalOccurrence>;
}

pub struct DashainGhatasthapana;

impl FestivalRule for DashainGhatasthapana {
    fn name(&self) -> &str {
        "Dashain Ghatasthapana"
    }

    fn evaluate(
        &self,
        ephe: &Ephemeris,
        geo: &GeoPosition,
        bs_year: i32,
    ) -> Option<FestivalOccurrence> {
        // Dashain Ghatasthapana: Ashwin Shukla Pratipada
        // Ashwin is month 6
        for day in 1..=32 {
            let bs_date = BsDate::new(bs_year, 6, day);
            let ad_date = bs_date.to_gregorian()?;
            let jd = ephe
                .sunrise(
                    ephe.julian_day(&ad_date.and_hms_opt(6, 0, 0).unwrap().and_utc()),
                    geo,
                )
                .ok()?;
            let tithi_info = panchanga::tithi(jd, ephe, geo).ok()?;
            if tithi_info.index == 1 && tithi_info.paksha == "Shukla" {
                return Some(FestivalOccurrence {
                    name: self.name().to_string(),
                    date: bs_date,
                    time_utc: tithi_info.end_time_utc,
                    description: "Dashain Ghatasthapana - First day of Dashain".to_string(),
                });
            }
        }
        None
    }
}

pub struct VijayaDashami;

impl FestivalRule for VijayaDashami {
    fn name(&self) -> &str {
        "Vijaya Dashami"
    }

    fn evaluate(
        &self,
        ephe: &Ephemeris,
        geo: &GeoPosition,
        bs_year: i32,
    ) -> Option<FestivalOccurrence> {
        // Vijaya Dashami: Ashwin Shukla Dashami (Month 6)
        for day in 1..=32 {
            let bs_date = BsDate::new(bs_year, 6, day);
            let ad_date = bs_date.to_gregorian()?;
            let jd = ephe
                .sunrise(
                    ephe.julian_day(&ad_date.and_hms_opt(6, 0, 0).unwrap().and_utc()),
                    geo,
                )
                .ok()?;
            let tithi = panchanga::tithi(jd, ephe, geo).ok()?;
            if tithi.index == 10 && tithi.paksha == "Shukla" {
                return Some(FestivalOccurrence {
                    name: self.name().to_string(),
                    date: bs_date,
                    time_utc: tithi.end_time_utc,
                    description: "Main day of Dashain".to_string(),
                });
            }
        }
        None
    }
}

pub struct NepaliNewYear;

impl FestivalRule for NepaliNewYear {
    fn name(&self) -> &str {
        "Nepali New Year"
    }

    fn evaluate(
        &self,
        _ephe: &Ephemeris,
        _geo: &GeoPosition,
        bs_year: i32,
    ) -> Option<FestivalOccurrence> {
        let bs_date = BsDate::new(bs_year, 1, 1);
        let ad_date = bs_date.to_gregorian()?;
        Some(FestivalOccurrence {
            name: self.name().to_string(),
            date: bs_date,
            time_utc: ad_date.and_hms_opt(0, 0, 0).unwrap().and_utc(),
            description: "Baisakh 1 - Nepali New Year".to_string(),
        })
    }
}

pub struct LaxmiPuja;

impl FestivalRule for LaxmiPuja {
    fn name(&self) -> &str {
        "Laxmi Puja"
    }

    fn evaluate(
        &self,
        ephe: &Ephemeris,
        geo: &GeoPosition,
        bs_year: i32,
    ) -> Option<FestivalOccurrence> {
        // Kartik Krishna Amavasya (Month 7)
        for day in 1..=32 {
            let bs_date = BsDate::new(bs_year, 7, day);
            let ad_date = bs_date.to_gregorian()?;
            let jd = ephe
                .sunrise(
                    ephe.julian_day(&ad_date.and_hms_opt(6, 0, 0).unwrap().and_utc()),
                    geo,
                )
                .ok()?;
            let tithi = panchanga::tithi(jd, ephe, geo).ok()?;
            if tithi.index == 30 {
                // Amavasya
                return Some(FestivalOccurrence {
                    name: self.name().to_string(),
                    date: bs_date,
                    time_utc: tithi.end_time_utc,
                    description: "Festival of Lights - Tihar".to_string(),
                });
            }
        }
        None
    }
}

pub struct Holi;

impl FestivalRule for Holi {
    fn name(&self) -> &str {
        "Holi"
    }

    fn evaluate(
        &self,
        ephe: &Ephemeris,
        geo: &GeoPosition,
        bs_year: i32,
    ) -> Option<FestivalOccurrence> {
        // Falgun Shukla Purnima (Month 11)
        for day in 1..=32 {
            let bs_date = BsDate::new(bs_year, 11, day);
            let ad_date = bs_date.to_gregorian()?;
            let jd = ephe
                .sunrise(
                    ephe.julian_day(&ad_date.and_hms_opt(6, 0, 0).unwrap().and_utc()),
                    geo,
                )
                .ok()?;
            let tithi = panchanga::tithi(jd, ephe, geo).ok()?;
            if tithi.index == 15 && tithi.paksha == "Shukla" {
                return Some(FestivalOccurrence {
                    name: self.name().to_string(),
                    date: bs_date,
                    time_utc: tithi.end_time_utc,
                    description: "Festival of Colors".to_string(),
                });
            }
        }
        None
    }
}

pub struct MahaShivaratri;

impl FestivalRule for MahaShivaratri {
    fn name(&self) -> &str {
        "Maha Shivaratri"
    }

    fn evaluate(
        &self,
        ephe: &Ephemeris,
        geo: &GeoPosition,
        bs_year: i32,
    ) -> Option<FestivalOccurrence> {
        // Magh Krishna Chaturdashi (Month 10)
        for day in 1..=32 {
            let bs_date = BsDate::new(bs_year, 10, day);
            let ad_date = bs_date.to_gregorian()?;
            let jd = ephe
                .sunrise(
                    ephe.julian_day(&ad_date.and_hms_opt(6, 0, 0).unwrap().and_utc()),
                    geo,
                )
                .ok()?;
            let tithi = panchanga::tithi(jd, ephe, geo).ok()?;
            if tithi.index == 29 {
                // Chaturdashi in Krishna Paksha (15 Shukla + 14 Krishna = 29)
                return Some(FestivalOccurrence {
                    name: self.name().to_string(),
                    date: bs_date,
                    time_utc: tithi.end_time_utc,
                    description: "The Great Night of Shiva".to_string(),
                });
            }
        }
        None
    }
}

pub struct FestivalRegistry {
    rules: Vec<Box<dyn FestivalRule>>,
}

impl Default for FestivalRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl FestivalRegistry {
    pub fn new() -> Self {
        Self {
            rules: vec![
                Box::new(DashainGhatasthapana),
                Box::new(VijayaDashami),
                Box::new(NepaliNewYear),
                Box::new(LaxmiPuja),
                Box::new(Holi),
                Box::new(MahaShivaratri),
            ],
        }
    }

    pub fn calculate_for_year(
        &self,
        ephe: &Ephemeris,
        geo: &GeoPosition,
        bs_year: i32,
    ) -> Vec<FestivalOccurrence> {
        self.rules
            .iter()
            .filter_map(|rule| rule.evaluate(ephe, geo, bs_year))
            .collect()
    }
}
