#!/bin/bash
set -e

echo "=== RUST CHECKS ==="
cargo fmt -- --check
cargo clippy --features python -- -D warnings
RUSTFLAGS="-C link-arg=-undefined -C link-arg=dynamic_lookup" cargo test --features python --lib --verbose

echo "=== PYTHON CHECKS ==="
./.venv/bin/black --check jyotishcore_py/jyotishcore/ tests/
./.venv/bin/isort --check-only jyotishcore_py/jyotishcore/ tests/
./.venv/bin/flake8 jyotishcore_py/jyotishcore/ tests/ --count --select=E9,F63,F7,F82 --show-source --statistics
./.venv/bin/mypy jyotishcore_py/jyotishcore/ --ignore-missing-imports --no-error-summary

echo "=== TESTS ==="
TESTING=1 PYTHONPATH=jyotishcore_py ./.venv/bin/pytest tests/ -v -m "not slow" --tb=short

echo "=== DOCS CHECK ==="
./.venv/bin/mdformat --check docs/ jyotishcore_py/ || true
./.venv/bin/mkdocs build --strict

echo "ALL CHECKS PASSED!"
