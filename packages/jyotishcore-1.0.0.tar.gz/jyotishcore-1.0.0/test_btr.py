import datetime
from jyotishcore import find_time_windows

base_time = "1990-05-15T10:30:00Z"
lat = 28.6
lon = 77.2

print(f"Finding time windows around {base_time}...")
windows = find_time_windows(
    base_date=base_time,
    window_minutes=120, # Search a 2-hour window (+/- 1 hr)
    varga=9, # Navamsha
    target_sign="Pisces",
    lat=lat,
    lon=lon
)

print(f"Found {len(windows)} matching windows for D9 Pisces Lagna:")
for w in windows:
    print(f"  Start: {w[0]}")
    print(f"  End:   {w[1]}")
