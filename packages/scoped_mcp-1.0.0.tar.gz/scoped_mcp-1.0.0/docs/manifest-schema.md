# Manifest Schema Reference

Manifests are YAML or JSON files passed to scoped-mcp via `--manifest`.

## Top-level fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `agent_type` | string | yes | Role identifier (e.g. "research", "build", "monitor") |
| `description` | string | no | Human-readable description of this agent role |
| `modules` | object | yes | Map of module name → module config (at least one required) |
| `credentials` | object | no | Credential source config (defaults to `source: env`) |

## Module config

Each key under `modules` is a module name. The value is:

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `mode` | `"read"` or `"write"` | `null` | Tool mode. `read` = read-only tools; `write` = read + write tools; `null` = all tools (write-only modules like ntfy) |
| `type` | string | `null` | Module class name. Set when multiple instances of the same module class are needed (e.g. two `mcp_proxy` entries for separate upstream servers). When absent, the manifest key is used as the class name. |
| `config` | object | `{}` | Module-specific configuration |

### mcp_proxy config

Proxy any existing MCP server (HTTP streamable-http or stdio) through scoped-mcp without
writing a custom module. Because multiple independent upstream servers can be proxied, use
`type: mcp_proxy` with a unique manifest key per server.

```yaml
modules:
  task-queue:
    type: mcp_proxy
    config:
      url: http://127.0.0.1:8485/mcp   # streamable-http server
      tool_allowlist: []               # empty = all tools exposed
      tool_denylist: []

  # stdio example — opens a persistent subprocess for the server's lifetime.
  # Discovery uses a short-lived subprocess; tool calls reuse the persistent one.
  agent-bus:
    type: mcp_proxy
    config:
      command: /path/to/python3
      args: [/path/to/mcp_server.py]
```

| Config key | Type | Default | Description |
|------------|------|---------|-------------|
| `url` | string | — | URL of an HTTP streamable-http MCP server (mutually exclusive with `command`) |
| `command` | string | — | Executable for a stdio MCP server (mutually exclusive with `url`) |
| `args` | list[str] | `[]` | Arguments passed to `command` |
| `tool_allowlist` | list[str] | `[]` | If non-empty, only these upstream tools are exposed |
| `tool_denylist` | list[str] | `[]` | These upstream tools are always hidden (applied after allowlist) |
| `discovery_timeout_seconds` | float | `10.0` | Timeout for connecting to the upstream server at startup |

> **stdio transport lifecycle:** Two subprocess spawns occur per module lifetime. A short-lived
> subprocess runs during startup for tool discovery (`tools/list`). A persistent subprocess is
> then opened when the server starts and reused for all tool calls. It is closed cleanly on
> server shutdown. HTTP transport reconnects per-call (no persistent connection).

> **Note:** The `mode:` field has no effect for `mcp_proxy`. Use `tool_allowlist` or
> `tool_denylist` to restrict which upstream tools are exposed. If no filter is set, all
> upstream tools are registered regardless of the `mode:` value.

## Credential source config

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `source` | `"env"` or `"file"` | `"env"` | Where to read credentials from |
| `path` | string | — | Path to a YAML secrets file (required when `source: file`) |

## Secrets file format

When `source: file`, the file must be a YAML mapping of key names to values:

```yaml
NTFY_TOKEN: your-token-here
SMTP_PASSWORD: your-password-here
GRAFANA_SERVICE_ACCOUNT_TOKEN: glsa_abc123
```

## Complete example

```yaml
agent_type: ops
description: "Operations agent with infrastructure access"

credentials:
  source: file
  path: /run/secrets/ops-agent.yml

modules:
  filesystem:
    mode: write
    config:
      base_path: /data/agents

  sqlite:
    mode: write
    config:
      db_dir: /data/sqlite       # each agent gets /data/sqlite/agent_{agent_id}.db

  influxdb:
    mode: write
    config:
      org: "homelab"
      buckets:
        - "metrics"
        - "alerts"

  grafana:
    mode: write

  ntfy:
    config:
      topic: "ops-{agent_id}"
      max_priority: urgent

  http_proxy:
    mode: read
    config:
      allowed_services:
        - name: "status_api"
          base_url: "https://status.internal"
          credential_key: "STATUS_API_TOKEN"
```
