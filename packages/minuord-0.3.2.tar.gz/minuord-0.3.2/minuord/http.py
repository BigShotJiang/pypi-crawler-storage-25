from __future__ import annotations

import logging
from typing import Any

import aiohttp

from .constants import API_BASE_URL
from .errors import HTTPRequestError

_log = logging.getLogger("minuord.http")


class DiscordHTTPClient:
    def __init__(self, token: str, session: aiohttp.ClientSession):
        self._token = token
        self._session = session

    @property
    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bot {self._token}",
            "Content-Type": "application/json",
        }

    async def request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"{API_BASE_URL}{path}"
        async with self._session.request(
            method=method,
            url=url,
            headers=self._headers,
            json=json,
        ) as response:
            text = await response.text()
            if response.status >= 400:
                _log.error("REST request failed: %s %s -> %s", method, path, response.status)
                raise HTTPRequestError(response.status, text)
            if not text:
                return {}
            return await response.json()

    async def send_message(self, channel_id: str, content: str) -> dict[str, Any]:
        return await self.send_message_payload(channel_id, {"content": content})

    async def send_message_payload(
        self,
        channel_id: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request(
            "POST",
            f"/channels/{channel_id}/messages",
            json=payload,
        )

    async def send_embed(
        self,
        channel_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        color: int = 0x5865F2,
        reply_to_message_id: str | None = None,
    ) -> dict[str, Any]:
        embed: dict[str, Any] = {"color": color}
        if title is not None:
            embed["title"] = title
        if description is not None:
            embed["description"] = description
        payload: dict[str, Any] = {"embeds": [embed]}
        if reply_to_message_id:
            payload["message_reference"] = {"message_id": reply_to_message_id}
        return await self.request(
            "POST",
            f"/channels/{channel_id}/messages",
            json=payload,
        )

    async def get_gateway_bot(self) -> dict[str, Any]:
        return await self.request("GET", "/gateway/bot")

    async def create_global_application_command(
        self,
        application_id: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request(
            "POST",
            f"/applications/{application_id}/commands",
            json=payload,
        )

    async def bulk_overwrite_global_application_commands(
        self,
        application_id: str,
        payload: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return await self.request(
            "PUT",
            f"/applications/{application_id}/commands",
            json=payload,
        )

    async def bulk_overwrite_guild_application_commands(
        self,
        application_id: str,
        guild_id: str,
        payload: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return await self.request(
            "PUT",
            f"/applications/{application_id}/guilds/{guild_id}/commands",
            json=payload,
        )

    async def respond_interaction(
        self,
        interaction_id: str,
        interaction_token: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request(
            "POST",
            f"/interactions/{interaction_id}/{interaction_token}/callback",
            json=payload,
        )

    async def ban_member(
        self,
        guild_id: str,
        user_id: str,
        delete_message_seconds: int = 0,
        reason: str | None = None,
    ) -> dict[str, Any]:
        payload = {"delete_message_seconds": delete_message_seconds}
        if reason:
            payload["reason"] = reason
        return await self.request(
            "PUT",
            f"/guilds/{guild_id}/bans/{user_id}",
            json=payload,
        )

    async def unban_member(self, guild_id: str, user_id: str) -> dict[str, Any]:
        return await self.request("DELETE", f"/guilds/{guild_id}/bans/{user_id}")

    async def kick_member(self, guild_id: str, user_id: str) -> dict[str, Any]:
        return await self.request("DELETE", f"/guilds/{guild_id}/members/{user_id}")

    async def timeout_member(
        self,
        guild_id: str,
        user_id: str,
        until_iso: str | None,
    ) -> dict[str, Any]:
        return await self.request(
            "PATCH",
            f"/guilds/{guild_id}/members/{user_id}",
            json={"communication_disabled_until": until_iso},
        )

    async def add_member_role(self, guild_id: str, user_id: str, role_id: str) -> dict[str, Any]:
        return await self.request("PUT", f"/guilds/{guild_id}/members/{user_id}/roles/{role_id}")

    async def remove_member_role(self, guild_id: str, user_id: str, role_id: str) -> dict[str, Any]:
        return await self.request("DELETE", f"/guilds/{guild_id}/members/{user_id}/roles/{role_id}")

    async def edit_member(self, guild_id: str, user_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("PATCH", f"/guilds/{guild_id}/members/{user_id}", json=payload)

    async def create_dm(self, recipient_id: str) -> dict[str, Any]:
        return await self.request("POST", "/users/@me/channels", json={"recipient_id": recipient_id})
