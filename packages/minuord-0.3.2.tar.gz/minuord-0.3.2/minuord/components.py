from __future__ import annotations

from typing import Any, List

from .enums import ComponentType, ButtonStyle, TextInputStyle

class Component:
    def to_dict(self) -> dict[str, Any]:
        raise NotImplementedError

class Button(Component):
    def __init__(
        self,
        style: int = ButtonStyle.PRIMARY,
        label: str | None = None,
        custom_id: str | None = None,
        url: str | None = None,
        disabled: bool = False
    ):
        self.style = style
        self.label = label
        self.custom_id = custom_id
        self.url = url
        self.disabled = disabled

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"type": ComponentType.BUTTON, "style": self.style, "disabled": self.disabled}
        if self.label:
            payload["label"] = self.label
        if self.custom_id:
            payload["custom_id"] = self.custom_id
        if self.url:
            payload["url"] = self.url
        return payload

class SelectOption:
    def __init__(
        self,
        label: str,
        value: str,
        description: str | None = None,
        emoji: dict[str, Any] | None = None,
        default: bool = False
    ):
        self.label = label
        self.value = value
        self.description = description
        self.emoji = emoji
        self.default = default

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"label": self.label, "value": self.value, "default": self.default}
        if self.description:
            payload["description"] = self.description
        if self.emoji:
            payload["emoji"] = self.emoji
        return payload

class SelectMenu(Component):
    def __init__(
        self,
        custom_id: str,
        options: List[SelectOption],
        placeholder: str | None = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False
    ):
        self.custom_id = custom_id
        self.options = options
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.disabled = disabled

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "type": ComponentType.STRING_SELECT,
            "custom_id": self.custom_id,
            "options": [opt.to_dict() for opt in self.options],
            "min_values": self.min_values,
            "max_values": self.max_values,
            "disabled": self.disabled
        }
        if self.placeholder:
            payload["placeholder"] = self.placeholder
        return payload

class TextInput(Component):
    def __init__(
        self,
        custom_id: str,
        label: str,
        style: int = TextInputStyle.SHORT,
        min_length: int = 0,
        max_length: int = 4000,
        required: bool = True,
        value: str | None = None,
        placeholder: str | None = None
    ):
        self.custom_id = custom_id
        self.label = label
        self.style = style
        self.min_length = min_length
        self.max_length = max_length
        self.required = required
        self.value = value
        self.placeholder = placeholder

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "type": ComponentType.TEXT_INPUT,
            "custom_id": self.custom_id,
            "label": self.label,
            "style": self.style,
            "min_length": self.min_length,
            "max_length": self.max_length,
            "required": self.required
        }
        if self.value:
            payload["value"] = self.value
        if self.placeholder:
            payload["placeholder"] = self.placeholder
        return payload

class ActionRow(Component):
    def __init__(self, *components: Component):
        self.components = list(components)

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": ComponentType.ACTION_ROW,
            "components": [c.to_dict() for c in self.components]
        }

class Modal:
    def __init__(self, custom_id: str, title: str, components: List[ActionRow]):
        self.custom_id = custom_id
        self.title = title
        self.components = components

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "custom_id": self.custom_id,
            "components": [c.to_dict() for c in self.components]
        }
