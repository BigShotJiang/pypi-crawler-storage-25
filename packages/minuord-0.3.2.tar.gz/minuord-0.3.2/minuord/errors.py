import json

class MinuordError(Exception):
    """Base exception for minuord."""

class HTTPRequestError(MinuordError):
    """Raised when Discord REST API returns an error."""

    def __init__(self, status: int, message: str):
        self.status = status
        self.raw_message = message
        self.code = 0
        self.text = message
        
        try:
            data = json.loads(message)
            self.code = data.get("code", 0)
            self.text = data.get("message", message)
        except (ValueError, TypeError):
            pass

        if status == 403:
            super().__init__(f"HTTP 403 Forbidden: У бота нет прав для выполнения этого действия. (Code {self.code}: {self.text})")
        elif status == 404 and self.code == 10062:
            super().__init__(f"HTTP 404 Not Found: Взаимодействие (Interaction) истекло или неизвестно. Возможно, ответ отправлялся дольше 3 секунд. (Code {self.code}: {self.text})")
        elif status == 400:
            super().__init__(f"HTTP 400 Bad Request: Неверные данные запроса. (Code {self.code}: {self.text})")
        elif status == 429:
            super().__init__(f"HTTP 429 Too Many Requests: Превышен лимит запросов (Rate Limit). (Code {self.code}: {self.text})")
        elif status >= 500:
            super().__init__(f"HTTP {status} Server Error: Проблема на стороне серверов Discord. ({self.text})")
        else:
            super().__init__(f"HTTP {status}: {self.text}")


class GatewayError(MinuordError):
    """Raised for unrecoverable Gateway issues."""


class CommandError(MinuordError):
    """Raised for command execution flow errors."""


class CheckFailure(CommandError):
    """Raised when command checks fail."""


class CommandOnCooldown(CommandError):
    """Raised when command is on cooldown."""
