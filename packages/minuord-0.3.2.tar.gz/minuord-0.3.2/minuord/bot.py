from __future__ import annotations

import asyncio
import inspect
import logging
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any, Awaitable, Callable

import aiohttp

from .constants import INTENTS
from .errors import CheckFailure, CommandOnCooldown
from .gateway import GatewayClient
from .http import DiscordHTTPClient
from .models import Color, Context, Embed, Message, SlashContext

EventHandler = Callable[..., Awaitable[None]]
CommandHandler = Callable[..., Any]

_log = logging.getLogger("minuord.bot")


@dataclass(slots=True)
class RegisteredCommand:
    name: str
    handler: CommandHandler
    description: str | None = None
    aliases: list[str] | None = None
    cooldown_seconds: int = 0
    checks: list[Callable[[Context], bool | Awaitable[bool]]] | None = None


@dataclass(slots=True)
class RegisteredSlashCommand:
    name: str
    description: str
    handler: CommandHandler
    options: list[dict[str, Any]]
    guild_ids: list[str] | None = None


class Bot:
    def __init__(
        self,
        token: str,
        command_prefix: str = "!",
        intents: int | None = None,
        status: str = "online",
        status_text: str | None = None,
        activity_type: int = 0,
        enable_default_help: bool = True,
        enable_moderation_commands: bool = True,
        slash_guild_ids: list[str] | None = None,
    ) -> None:
        self.token = token
        self.command_prefix = command_prefix
        self.intents = intents if intents is not None else (
            INTENTS["GUILDS"]
            | INTENTS["GUILD_MEMBERS"]
            | INTENTS["GUILD_MODERATION"]
            | INTENTS["GUILD_MESSAGES"]
            | INTENTS["MESSAGE_CONTENT"]
        )
        self.status = status
        self.status_text = status_text
        self.activity_type = activity_type
        self._validate_status(status)

        self._event_handlers: dict[str, list[EventHandler]] = defaultdict(list)
        self._commands: dict[str, RegisteredCommand] = {}
        self._slash_commands: dict[str, RegisteredSlashCommand] = {}
        self._session: aiohttp.ClientSession | None = None
        self._http: DiscordHTTPClient | None = None
        self._gateway: GatewayClient | None = None
        self.user: dict[str, Any] | None = None
        self.application_id: str | None = None
        self._ready_event = asyncio.Event()
        self._started_at = time.perf_counter()
        self._cooldowns: dict[tuple[str, str], float] = {}
        self._before_invoke_hooks: list[Callable[[Context], Any]] = []
        self._after_invoke_hooks: list[Callable[[Context], Any]] = []
        self._command_error_handler: Callable[[Context, Exception], Any] | None = None
        self._default_slash_guild_ids = slash_guild_ids or []

        if enable_default_help:
            self._register_default_help()
        if enable_moderation_commands:
            self._register_default_moderation_commands()

    def event(self, name: str | None = None) -> Callable[[EventHandler], EventHandler]:
        def decorator(coro: EventHandler) -> EventHandler:
            event_name = name or coro.__name__
            if event_name.startswith("on_"):
                event_name = event_name[3:]
            self._event_handlers[event_name.upper()].append(coro)
            return coro

        return decorator

    def on_ready(self) -> Callable[[EventHandler], EventHandler]:
        return self.event("READY")

    def on_message_create(self) -> Callable[[EventHandler], EventHandler]:
        return self.event("MESSAGE_CREATE")

    def command(
        self,
        name: str | None = None,
        *,
        aliases: list[str] | None = None,
        description: str | None = None,
    ) -> Callable[[CommandHandler], CommandHandler]:
        def decorator(coro: CommandHandler) -> CommandHandler:
            command_name = (name or coro.__name__).lower()
            registered = RegisteredCommand(
                name=command_name,
                handler=coro,
                description=description,
                aliases=aliases or [],
                cooldown_seconds=getattr(coro, "__minuord_cooldown__", 0),
                checks=getattr(coro, "__minuord_checks__", []),
            )
            self._commands[command_name] = registered
            for alias in aliases or []:
                self._commands[alias.lower()] = registered
            return coro

        return decorator

    def slash_command(
        self,
        name: str,
        description: str,
        *,
        options: list[dict[str, Any]] | None = None,
        guild_ids: list[str] | None = None,
    ) -> Callable[[CommandHandler], CommandHandler]:
        def decorator(coro: CommandHandler) -> CommandHandler:
            self._slash_commands[name] = RegisteredSlashCommand(
                name=name,
                description=description,
                handler=coro,
                options=options or [],
                guild_ids=guild_ids or self._default_slash_guild_ids,
            )
            return coro

        return decorator

    def check(
        self,
        predicate: Callable[[Context], bool | Awaitable[bool]],
    ) -> Callable[[CommandHandler], CommandHandler]:
        def decorator(coro: CommandHandler) -> CommandHandler:
            checks = list(getattr(coro, "__minuord_checks__", []))
            checks.append(predicate)
            setattr(coro, "__minuord_checks__", checks)
            return coro

        return decorator

    def cooldown(self, seconds: int) -> Callable[[CommandHandler], CommandHandler]:
        def decorator(coro: CommandHandler) -> CommandHandler:
            setattr(coro, "__minuord_cooldown__", max(0, int(seconds)))
            return coro

        return decorator

    def before_invoke(
        self,
        hook: Callable[[Context], Any],
    ) -> Callable[[Context], Any]:
        self._before_invoke_hooks.append(hook)
        return hook

    def after_invoke(
        self,
        hook: Callable[[Context], Any],
    ) -> Callable[[Context], Any]:
        self._after_invoke_hooks.append(hook)
        return hook

    def on_command_error(
        self,
    ) -> Callable[[Callable[[Context, Exception], Any]], Callable[[Context, Exception], Any]]:
        def decorator(
            handler: Callable[[Context, Exception], Any],
        ) -> Callable[[Context, Exception], Any]:
            self._command_error_handler = handler
            return handler

        return decorator

    async def send_message(
        self,
        channel_id: str,
        content: str,
        *,
        reply_to_message_id: str | None = None,
    ) -> dict[str, Any]:
        if not self._http:
            raise RuntimeError("HTTP client is not initialized.")
        payload: dict[str, Any] = {"content": content}
        if reply_to_message_id:
            payload["message_reference"] = {"message_id": reply_to_message_id}
        return await self._http.send_message_payload(channel_id, payload)

    async def send_embed(
        self,
        channel_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        color: int = 0x5865F2,
        embed: Embed | None = None,
        reply_to_message_id: str | None = None,
    ) -> dict[str, Any]:
        if not self._http:
            raise RuntimeError("HTTP client is not initialized.")
        if embed is not None:
            payload: dict[str, Any] = {"embeds": [embed.to_dict()]}
            if reply_to_message_id:
                payload["message_reference"] = {"message_id": reply_to_message_id}
            return await self._http.send_message_payload(channel_id, payload)
        return await self._http.send_embed(
            channel_id,
            title=title,
            description=description,
            color=color,
            reply_to_message_id=reply_to_message_id,
        )

    async def _dispatch_event(self, event_name: str, data: dict[str, Any]) -> None:
        if event_name == "READY":
            self.user = data.get("user")
            self.application_id = data.get("application", {}).get("id")
            self._ready_event.set()
            await self.sync_slash_commands()
        handlers = self._event_handlers.get(event_name, [])
        for handler in handlers:
            try:
                result = handler(data)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                _log.exception("Unhandled exception in %s handler", event_name)

        if event_name == "MESSAGE_CREATE":
            await self._process_commands(data)
        if event_name == "INTERACTION_CREATE":
            await self._process_interaction(data)

    async def _process_commands(self, data: dict[str, Any]) -> None:
        message = Message.from_payload(data, bot=self)
        if message.author.bot:
            return
        if not message.content.startswith(self.command_prefix):
            return

        raw = message.content[len(self.command_prefix):].strip()
        if not raw:
            return

        parts = raw.split()
        command_name = parts[0].lower()
        args = parts[1:]

        command = self._commands.get(command_name)
        if not command:
            return

        ctx = Context(bot=self, message=message, command=command_name, args=args)
        try:
            await self._run_checks(command, ctx)
            await self._run_cooldown(command, ctx)
            await self._run_before_hooks(ctx)
            result = self._invoke_command_handler(command.handler, ctx)
            if inspect.isawaitable(result):
                await result
            await self._run_after_hooks(ctx)
        except Exception as exc:
            _log.exception("Unhandled exception in command '%s'", command_name)
            await self._handle_command_error(ctx, command_name, exc)

    def _invoke_command_handler(self, handler: Callable[..., Any], ctx: Context) -> Any:
        signature = inspect.signature(handler)
        if len(signature.parameters) == 0:
            return handler()
        return handler(ctx)

    def _invoke_slash_handler(self, handler: Callable[..., Any], ctx: SlashContext) -> Any:
        signature = inspect.signature(handler)
        if len(signature.parameters) == 0:
            return handler()
        return handler(ctx)

    @staticmethod
    def _validate_status(status: str) -> None:
        allowed = {"online", "idle", "dnd"}
        if status not in allowed:
            raise ValueError(f"Invalid status '{status}'. Allowed: {', '.join(sorted(allowed))}")

    def _register_default_help(self) -> None:
        async def default_help(ctx: Context) -> None:
            unique_commands: dict[str, RegisteredCommand] = {}
            for command in self._commands.values():
                unique_commands[command.name] = command
            lines = []
            for command_name in sorted(unique_commands):
                description = unique_commands[command_name].description or "No description"
                lines.append(f"{self.command_prefix}{command_name} - {description}")
            await ctx.send("\n".join(lines) if lines else "No commands registered.")

        self._commands["help"] = RegisteredCommand(
            name="help",
            handler=default_help,
            description="Show available commands",
        )

    def _register_default_moderation_commands(self) -> None:
        @self.command(name="ping", description="Gateway latency in ms")
        async def ping_cmd(ctx: Context) -> None:
            latency = self.latency_ms
            await ctx.reply(f"Pong: {latency} ms")

        @self.slash_command(name="ping", description="Показать задержку бота")
        async def slash_ping(ctx: SlashContext) -> None:
            await ctx.send(f"Pong: {self.latency_ms} ms", ephemeral=True)

        @self.command(name="ban", description="!ban <user_id> [reason]")
        async def ban_cmd(ctx: Context) -> None:
            await self._moderate_from_message(ctx, action="ban")

        @self.command(name="unban", description="!unban <user_id>")
        async def unban_cmd(ctx: Context) -> None:
            await self._moderate_from_message(ctx, action="unban")

        @self.command(name="kick", description="!kick <user_id>")
        async def kick_cmd(ctx: Context) -> None:
            await self._moderate_from_message(ctx, action="kick")

        @self.command(name="mute", description="!mute <user_id> [minutes]")
        async def mute_cmd(ctx: Context) -> None:
            await self._moderate_from_message(ctx, action="mute")

        @self.command(name="unmute", description="!unmute <user_id>")
        async def unmute_cmd(ctx: Context) -> None:
            await self._moderate_from_message(ctx, action="unmute")

        user_option = {
            "type": 3,
            "name": "user_id",
            "description": "ID пользователя",
            "required": True,
        }
        minutes_option = {
            "type": 4,
            "name": "minutes",
            "description": "Минуты таймаута",
            "required": False,
        }

        @self.slash_command(name="ban", description="Забанить пользователя", options=[user_option])
        async def slash_ban(ctx: SlashContext) -> None:
            await self._moderate_from_slash(ctx, "ban")

        @self.slash_command(name="unban", description="Разбанить пользователя", options=[user_option])
        async def slash_unban(ctx: SlashContext) -> None:
            await self._moderate_from_slash(ctx, "unban")

        @self.slash_command(name="kick", description="Кикнуть пользователя", options=[user_option])
        async def slash_kick(ctx: SlashContext) -> None:
            await self._moderate_from_slash(ctx, "kick")

        @self.slash_command(
            name="mute",
            description="Выдать timeout",
            options=[user_option, minutes_option],
        )
        async def slash_mute(ctx: SlashContext) -> None:
            await self._moderate_from_slash(ctx, "mute")

        @self.slash_command(name="unmute", description="Снять timeout", options=[user_option])
        async def slash_unmute(ctx: SlashContext) -> None:
            await self._moderate_from_slash(ctx, "unmute")

    async def wait_until_ready(self) -> None:
        await self._ready_event.wait()

    @property
    def latency_ms(self) -> int:
        if self._gateway is None:
            return 0
        return self._gateway.latency_ms

    @property
    def uptime_ms(self) -> int:
        return int((time.perf_counter() - self._started_at) * 1000)

    async def respond_interaction(
        self,
        interaction_id: str,
        interaction_token: str,
        *,
        content: str | None = None,
        embed: Embed | None = None,
        ephemeral: bool = False,
    ) -> dict[str, Any]:
        if not self._http:
            raise RuntimeError("HTTP client is not initialized.")

        data: dict[str, Any] = {}
        if content is not None:
            data["content"] = content
        if embed is not None:
            data["embeds"] = [embed.to_dict()]
        if ephemeral:
            data["flags"] = 64
        return await self._http.respond_interaction(
            interaction_id,
            interaction_token,
            {"type": 4, "data": data},
        )

    async def sync_slash_commands(self) -> None:
        if not self._http or not self.application_id:
            return
        global_payload: list[dict[str, Any]] = []
        guild_payloads: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for cmd in self._slash_commands.values():
            payload = {"name": cmd.name, "description": cmd.description, "type": 1, "options": cmd.options}
            if cmd.guild_ids:
                for guild_id in cmd.guild_ids:
                    guild_payloads[guild_id].append(payload)
            else:
                global_payload.append(payload)

        try:
            await self._http.bulk_overwrite_global_application_commands(self.application_id, global_payload)
        except Exception:
            _log.exception("Failed to sync global slash commands")
        for guild_id, payload in guild_payloads.items():
            try:
                await self._http.bulk_overwrite_guild_application_commands(
                    self.application_id,
                    guild_id,
                    payload,
                )
            except Exception:
                _log.exception("Failed to sync slash commands for guild %s", guild_id)

    async def _process_interaction(self, data: dict[str, Any]) -> None:
        if data.get("type") != 2:
            return
        command_name = data.get("data", {}).get("name")
        command = self._slash_commands.get(command_name)
        if not command:
            return
        options_array = data.get("data", {}).get("options", [])
        options = {item.get("name"): item.get("value") for item in options_array}
        member = data.get("member", {})
        user = member.get("user") or data.get("user", {})
        guild_id = data.get("guild_id")
        
        ctx = SlashContext(
            bot=self,
            interaction_id=data["id"],
            interaction_token=data["token"],
            guild_id=guild_id,
            channel_id=data.get("channel_id"),
            user_id=user.get("id", ""),
            command=command_name,
            options=options,
        )
        
        from .models import Member, User
        if member and guild_id:
            member["user"] = user
            ctx.author = Member(member, guild_id, bot=self)
        else:
            ctx.author = User(user, bot=self)
        try:
            result = self._invoke_slash_handler(command.handler, ctx)
            if inspect.isawaitable(result):
                await result
        except HTTPRequestError as e:
            if e.status == 404 and e.code == 10062:
                _log.warning("Interaction '%s' expired or unknown.", command_name)
            else:
                _log.error("HTTP error in slash command '%s': %s", command_name, e)
        except Exception:
            _log.exception("Unhandled exception in slash command '%s'", command_name)
            try:
                await ctx.send("Ошибка во время выполнения команды.", ephemeral=True)
            except HTTPRequestError:
                pass

    async def _run_checks(self, command: RegisteredCommand, ctx: Context) -> None:
        for check in command.checks or []:
            result = check(ctx)
            if inspect.isawaitable(result):
                result = await result
            if not result:
                raise CheckFailure("Command check failed.")

    async def _run_cooldown(self, command: RegisteredCommand, ctx: Context) -> None:
        if command.cooldown_seconds <= 0:
            return
        now = time.time()
        key = (command.name, ctx.message.author.id)
        expires_at = self._cooldowns.get(key, 0)
        if expires_at > now:
            remaining = int(expires_at - now)
            raise CommandOnCooldown(f"Команда на кулдауне: {remaining} сек.")
        self._cooldowns[key] = now + command.cooldown_seconds

    async def _run_before_hooks(self, ctx: Context) -> None:
        for hook in self._before_invoke_hooks:
            result = hook(ctx)
            if inspect.isawaitable(result):
                await result

    async def _run_after_hooks(self, ctx: Context) -> None:
        for hook in self._after_invoke_hooks:
            result = hook(ctx)
            if inspect.isawaitable(result):
                await result

    async def _handle_command_error(self, ctx: Context, command_name: str, exc: Exception) -> None:
        if self._command_error_handler:
            result = self._command_error_handler(ctx, exc)
            if inspect.isawaitable(result):
                await result
            return
        if isinstance(exc, (CheckFailure, CommandOnCooldown)):
            await ctx.reply(str(exc))
            return
        await ctx.reply(f"Ошибка выполнения команды: {command_name}")

    async def _moderate_from_message(self, ctx: Context, action: str) -> None:
        guild_id = getattr(ctx.message, "guild_id", None)
        if not guild_id:
            await ctx.reply("Эта команда доступна только на сервере.")
            return
        if not ctx.args:
            await ctx.reply("Нужен user_id или mention.")
            return

        user_id = self._extract_user_id(ctx.args[0])
        minutes = int(ctx.args[1]) if action == "mute" and len(ctx.args) > 1 else 10
        reason = " ".join(ctx.args[1:]).strip() if action == "ban" and len(ctx.args) > 1 else None
        result = await self._moderate_action(guild_id, user_id, action, minutes, reason)
        await ctx.send_embed(embed=result)

    async def _moderate_from_slash(self, ctx: SlashContext, action: str) -> None:
        if not ctx.guild_id:
            await ctx.send("Команда доступна только на сервере.", ephemeral=True)
            return
        user_id = self._extract_user_id(str(ctx.options.get("user_id", "")))
        minutes = int(ctx.options.get("minutes", 10))
        result = await self._moderate_action(ctx.guild_id, user_id, action, minutes, None)
        await ctx.send_embed(result, ephemeral=True)

    async def _moderate_action(
        self,
        guild_id: str,
        user_id: str,
        action: str,
        minutes: int,
        reason: str | None,
    ) -> Embed:
        if not self._http:
            raise RuntimeError("HTTP client is not initialized.")
        if not user_id:
            return Embed(title="Ошибка", description="Не удалось определить user_id", color=Color.RED)

        try:
            if action == "ban":
                await self._http.ban_member(guild_id, user_id, reason=reason)
                text = f"Пользователь `{user_id}` забанен."
            elif action == "unban":
                await self._http.unban_member(guild_id, user_id)
                text = f"Пользователь `{user_id}` разбанен."
            elif action == "kick":
                await self._http.kick_member(guild_id, user_id)
                text = f"Пользователь `{user_id}` кикнут."
            elif action == "mute":
                until = datetime.now(tz=UTC) + timedelta(minutes=minutes)
                await self._http.timeout_member(guild_id, user_id, until.isoformat())
                text = f"Пользователь `{user_id}` замьючен на {minutes} мин."
            elif action == "unmute":
                await self._http.timeout_member(guild_id, user_id, None)
                text = f"Пользователь `{user_id}` размьючен."
            else:
                text = "Неизвестное действие."
            return Embed(title="Модерация", description=text, color=Color.GREEN).add_field(
                "Действие",
                action,
                inline=True,
            )
        except Exception as exc:
            return Embed(title="Ошибка", description=str(exc), color=Color.RED)

    @staticmethod
    def _extract_user_id(raw: str) -> str:
        value = raw.strip()
        if value.startswith("<@") and value.endswith(">"):
            value = value[2:-1]
        if value.startswith("!"):
            value = value[1:]
        return "".join(ch for ch in value if ch.isdigit())

    async def start(self) -> None:
        self._session = aiohttp.ClientSession()
        self._http = DiscordHTTPClient(self.token, self._session)

        self._gateway = GatewayClient(
            token=self.token,
            intents=self.intents,
            session=self._session,
            dispatch_handler=self._dispatch_event,
            status=self.status,
            activity_text=self.status_text,
            activity_type=self.activity_type,
        )
        await self._gateway.connect_forever()

    async def close(self) -> None:
        if self._gateway:
            await self._gateway.close()
        if self._session and not self._session.closed:
            await self._session.close()

    def run(self) -> None:
        try:
            asyncio.run(self.start())
        except KeyboardInterrupt:
            _log.info("Bot stopped by user.")
