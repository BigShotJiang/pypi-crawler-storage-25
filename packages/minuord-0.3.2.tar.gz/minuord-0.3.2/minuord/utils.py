from __future__ import annotations

from datetime import datetime, timezone

def snowflake_time(id: int) -> datetime:
    """Конвертирует Discord Snowflake ID в объект datetime."""
    timestamp = ((id >> 22) + 1420070400000) / 1000.0
    return datetime.fromtimestamp(timestamp, tz=timezone.utc)

def escape_markdown(text: str) -> str:
    """Экранирует специальные символы Markdown в строке."""
    escape_chars = r"\*_`~|"
    return "".join(f"\\{char}" if char in escape_chars else char for char in text)
