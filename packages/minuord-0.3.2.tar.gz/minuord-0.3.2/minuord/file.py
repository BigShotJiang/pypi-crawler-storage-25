from __future__ import annotations

import os
from typing import Any

class File:
    def __init__(self, fp: str | bytes, filename: str | None = None):
        self.fp = fp
        self.filename = filename or (os.path.basename(fp) if isinstance(fp, str) else "file.bin")

    def read(self) -> bytes:
        if isinstance(self.fp, str):
            with open(self.fp, "rb") as f:
                return f.read()
        return self.fp
