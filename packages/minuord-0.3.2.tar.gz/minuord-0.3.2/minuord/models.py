from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import Any, List, Tuple, Optional

class Asset:
    def __init__(self, url: str):
        self.url = url

    def __str__(self):
        return self.url

class Color:
    RED = 0xED4245
    GREEN = 0x57F287
    BLUE = 0x3498DB
    YELLOW = 0xFEE75C
    ORANGE = 0xE67E22
    PURPLE = 0x9B59B6
    BLURPLE = 0x5865F2
    WHITE = 0xFFFFFF
    BLACK = 0x000000

    def __init__(self, value: int):
        self.value = value

    @staticmethod
    def from_hex(hex_value: str) -> int:
        value = hex_value.strip().lower().replace("#", "")
        if len(value) != 6:
            raise ValueError("hex color must be 6 characters, e.g. #FFAA00")
        return int(value, 16)

    @staticmethod
    def from_rgb(r: int, g: int, b: int) -> int:
        for ch in (r, g, b):
            if ch < 0 or ch > 255:
                raise ValueError("RGB values must be in range 0..255")
        return (r << 16) + (g << 8) + b

Colour = Color

class PublicUserFlags:
    def __init__(self, value: int):
        self.value = value

class DMChannel:
    def __init__(self, id: str):
        self.id = id

class Guild:
    def __init__(self, id: str):
        self.id = id

class Permissions:
    def __init__(self, value: int):
        self.value = value

class Role:
    def __init__(self, payload: dict[str, Any]):
        self.id = payload.get("id", "")
        self.name = payload.get("name", "")
        self.color = Color(payload.get("color", 0))
        self.permissions = Permissions(int(payload.get("permissions", 0)))
        self.managed = payload.get("managed", False)
        self.hoist = payload.get("hoist", False)
        self.mentionable = payload.get("mentionable", False)

class VoiceState:
    def __init__(self, payload: dict[str, Any]):
        self.channel_id = payload.get("channel_id")

class Activity:
    def __init__(self, payload: dict[str, Any]):
        self.name = payload.get("name")
        self.type = payload.get("type")

class Status:
    def __init__(self, value: str):
        self.value = value
    def __str__(self):
        return self.value

@dataclass(slots=True)
class EmbedField:
    name: str
    value: str
    inline: bool = False

@dataclass(slots=True)
class Embed:
    title: str | None = None
    description: str | None = None
    color: int = Color.BLURPLE
    url: str | None = None
    image_url: str | None = None
    thumbnail_url: str | None = None
    footer_text: str | None = None
    timestamp: str | None = None
    fields: list[EmbedField] | None = None

    def add_field(self, name: str, value: str, inline: bool = False) -> "Embed":
        if self.fields is None:
            self.fields = []
        self.fields.append(EmbedField(name=name, value=value, inline=inline))
        return self

    def set_image(self, url: str) -> "Embed":
        self.image_url = url
        return self

    def set_thumbnail(self, url: str) -> "Embed":
        self.thumbnail_url = url
        return self

    def set_footer(self, text: str) -> "Embed":
        self.footer_text = text
        return self

    def set_timestamp_now(self) -> "Embed":
        self.timestamp = datetime.datetime.now(tz=datetime.timezone.utc).isoformat()
        return self

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"color": self.color}
        if self.title is not None:
            payload["title"] = self.title
        if self.description is not None:
            payload["description"] = self.description
        if self.url is not None:
            payload["url"] = self.url
        if self.image_url is not None:
            payload["image"] = {"url": self.image_url}
        if self.thumbnail_url is not None:
            payload["thumbnail"] = {"url": self.thumbnail_url}
        if self.footer_text is not None:
            payload["footer"] = {"text": self.footer_text}
        if self.timestamp is not None:
            payload["timestamp"] = self.timestamp
        if self.fields:
            payload["fields"] = [
                {"name": field.name, "value": field.value, "inline": field.inline}
                for field in self.fields
            ]
        return payload

class User:
    def __init__(self, payload: dict[str, Any], bot: Any = None):
        self._bot = bot
        self._payload = payload
        self.id = int(payload.get("id", 0))
        self.name = payload.get("username", "unknown")
        self.discriminator = payload.get("discriminator", "0")
        self.global_name = payload.get("global_name")
        self.display_name = self.global_name or self.name
        self.mention = f"<@{self.id}>"
        self.bot = payload.get("bot", False)
        self.system = payload.get("system", False)
        
        # Snowflake to datetime
        self.created_at = datetime.datetime.fromtimestamp(((self.id >> 22) + 1420070400000) / 1000.0, tz=datetime.timezone.utc) if self.id else datetime.datetime.now(datetime.timezone.utc)
        
        self.default_avatar = Asset(f"https://cdn.discordapp.com/embed/avatars/{int(self.discriminator) % 5 if self.discriminator != '0' else (self.id >> 22) % 6}.png")
        
        av = payload.get("avatar")
        self.avatar = Asset(f"https://cdn.discordapp.com/avatars/{self.id}/{av}.png") if av else None
        self.display_avatar = self.avatar or self.default_avatar
        
        banner = payload.get("banner")
        self.banner = Asset(f"https://cdn.discordapp.com/banners/{self.id}/{banner}.png") if banner else None
        
        ac = payload.get("accent_color")
        self.accent_color = Color(ac) if ac is not None else None
        self.accent_colour = self.accent_color
        
        self.color = self.accent_color or Color(0)
        self.colour = self.color
        
        self.public_flags = PublicUserFlags(payload.get("public_flags", 0))
        self.dm_channel: DMChannel | None = None
        self.mutual_guilds: List[Guild] = []
        
        # Activity attributes
        self.status = Status("offline")
        self.activity: Activity | None = None
        self.activities: Tuple[Activity, ...] = ()
        self.mobile_status = Status("offline")
        self.desktop_status = Status("offline")
        self.web_status = Status("offline")
        self.raw_status = "offline"

    def __str__(self):
        if self.discriminator and self.discriminator != "0":
            return f"{self.name}#{self.discriminator}"
        return self.name

    def mentioned_in(self, message: Any) -> bool:
        return f"<@{self.id}>" in message.content or f"<@!{self.id}>" in message.content

    async def send(self, text: str):
        if not self._bot:
            return None
        dm = await self._bot._http.create_dm(str(self.id))
        return await self._bot._http.send_message(dm["id"], text)

class Member(User):
    def __init__(self, payload: dict[str, Any], guild_id: str, bot: Any = None):
        user_payload = payload.get("user", payload)
        super().__init__(user_payload, bot)
        self._member_payload = payload
        self.guild = Guild(guild_id)
        self._guild_id = guild_id
        
        self.nick = payload.get("nick")
        self.display_name = self.nick or self.global_name or self.name
        
        joined_at_str = payload.get("joined_at")
        self.joined_at = datetime.datetime.fromisoformat(joined_at_str) if joined_at_str else datetime.datetime.now(datetime.timezone.utc)
        
        premium_since_str = payload.get("premium_since")
        self.premium_since = datetime.datetime.fromisoformat(premium_since_str) if premium_since_str else None
        
        self.roles = [Role({"id": r}) for r in payload.get("roles", [])]
        self.top_role = self.roles[0] if self.roles else Role({"id": guild_id})
        
        self.guild_permissions = Permissions(int(payload.get("permissions", 0)))
        self.voice: VoiceState | None = None
        self.pending = payload.get("pending", False)
        
        tout = payload.get("communication_disabled_until")
        self.timed_out_until = datetime.datetime.fromisoformat(tout) if tout else None

    async def add_roles(self, role: Role | str):
        if not self._bot: return
        role_id = role.id if isinstance(role, Role) else role
        await self._bot._http.add_member_role(self._guild_id, str(self.id), str(role_id))

    async def remove_roles(self, role: Role | str):
        if not self._bot: return
        role_id = role.id if isinstance(role, Role) else role
        await self._bot._http.remove_member_role(self._guild_id, str(self.id), str(role_id))

    async def edit(self, nick: str | None = None):
        if not self._bot: return
        payload = {}
        if nick is not None:
            payload["nick"] = nick
        await self._bot._http.edit_member(self._guild_id, str(self.id), payload)

    async def move_to(self, voice_channel: Any):
        if not self._bot: return
        channel_id = getattr(voice_channel, "id", voice_channel)
        await self._bot._http.edit_member(self._guild_id, str(self.id), {"channel_id": str(channel_id)})

    async def kick(self, reason: str | None = None):
        if not self._bot: return
        await self._bot._http.kick_member(self._guild_id, str(self.id))

    async def ban(self, reason: str | None = None):
        if not self._bot: return
        await self._bot._http.ban_member(self._guild_id, str(self.id), reason=reason)

    async def unban(self):
        if not self._bot: return
        await self._bot._http.unban_member(self._guild_id, str(self.id))

    async def timeout(self, duration: datetime.timedelta):
        if not self._bot: return
        until = datetime.datetime.now(datetime.timezone.utc) + duration
        await self._bot._http.timeout_member(self._guild_id, str(self.id), until.isoformat())

    async def remove_timeout(self):
        if not self._bot: return
        await self._bot._http.timeout_member(self._guild_id, str(self.id), None)

@dataclass(slots=True)
class Message:
    id: str
    channel_id: str
    guild_id: str | None
    content: str
    author: User | Member

    @classmethod
    def from_payload(cls, payload: dict[str, Any], bot: Any = None) -> "Message":
        guild_id = payload.get("guild_id")
        if "member" in payload and guild_id:
            member_payload = payload["member"]
            member_payload["user"] = payload["author"]
            author = Member(member_payload, guild_id, bot=bot)
        else:
            author = User(payload["author"], bot=bot)
            
        return cls(
            id=payload["id"],
            channel_id=payload["channel_id"],
            guild_id=guild_id,
            content=payload.get("content", ""),
            author=author,
        )

@dataclass(slots=True)
class SlashContext:
    bot: Any
    interaction_id: str
    interaction_token: str
    guild_id: str | None
    channel_id: str | None
    user_id: str
    command: str
    options: dict[str, Any]
    author: User | Member = None

    async def send(
        self,
        content: str,
        *,
        ephemeral: bool = False,
    ) -> dict[str, Any]:
        return await self.bot.respond_interaction(
            self.interaction_id,
            self.interaction_token,
            content=content,
            ephemeral=ephemeral,
        )

    async def send_embed(
        self,
        embed: Embed,
        *,
        ephemeral: bool = False,
    ) -> dict[str, Any]:
        return await self.bot.respond_interaction(
            self.interaction_id,
            self.interaction_token,
            embed=embed,
            ephemeral=ephemeral,
        )

@dataclass(slots=True)
class Context:
    bot: Any
    message: Message
    command: str
    args: list[str]

    @property
    def author(self) -> User | Member:
        return self.message.author

    async def send(self, content: str) -> dict[str, Any]:
        return await self.bot.send_message(self.message.channel_id, content)

    async def reply(self, content: str) -> dict[str, Any]:
        return await self.bot.send_message(
            self.message.channel_id,
            content,
            reply_to_message_id=self.message.id,
        )

    async def send_embed(
        self,
        *,
        embed: Embed | None = None,
        title: str | None = None,
        description: str | None = None,
        color: int = Color.BLURPLE,
    ) -> dict[str, Any]:
        return await self.bot.send_embed(
            self.message.channel_id,
            embed=embed,
            title=title,
            description=description,
            color=color,
        )
