# minuord

[![PyPI version](https://img.shields.io/pypi/v/minuord.svg)](https://pypi.org/project/minuord/)
[![Python versions](https://img.shields.io/pypi/pyversions/minuord.svg)](https://pypi.org/project/minuord/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

`minuord` — это минималистичная, легковесная и современная Python-библиотека для создания Discord-ботов. Написана полностью с нуля поверх Discord REST API и Gateway.

Отлично подходит для тех, кому нужен легковесный, быстрый и понятный инструмент для создания ботов без лишнего overhead'а.

## Особенности

- 🚀 **Нативный `asyncio` + `aiohttp`** для максимальной производительности
- 🔌 **Стабильный Gateway**: heartbeat, reconnect, resume "из коробки"
- 💬 **Префиксные и Slash-команды** с простой регистрацией
- 👥 **Продвинутая работа с пользователями**: `User`, `Member`, роли, права, статусы и активности
- 🎨 **Rich Embeds** и **UI Компоненты** (кнопки, ActionRow, SelectMenu, Modal, TextInput)
- 🛡️ **Встроенная модерация**: `ban`, `kick`, `mute` (timeout), `unban`, `unmute` доступны сразу
- ⚙️ **Hooks & Checks**: `before_invoke`, `after_invoke`, `cooldown`, кастомные проверки (`checks`)

## Установка

```bash
pip install minuord
```

---

# 📚 Подробный гайд

## 1. Базовая инициализация и события

Запуск бота происходит с помощью класса `Bot`. Вы можете подписываться на любые события Gateway с помощью декораторов.

```python
from minuord import Bot

bot = Bot(
    token="YOUR_TOKEN",
    command_prefix="!",
    status="online",   # online | idle | dnd
    status_text="minuord version 0.3.1",
)

@bot.on_ready()
async def ready(payload):
    print(f"Бот {bot.user['username']} успешно запущен!")

# Подписка на произвольные события Gateway
@bot.event("MESSAGE_CREATE")
async def on_new_message(payload):
    # Этот код сработает при каждом новом сообщении (не блокируя команды)
    pass

if __name__ == "__main__":
    bot.run()
```

## 2. Префиксные команды и контекст

Объект `Context` предоставляет удобный доступ к автору, аргументам и отправке сообщений.

```python
from minuord import Context

@bot.command(name="hello", aliases=["hi", "привет"], description="Простое приветствие")
async def hello_command(ctx: Context):
    user = ctx.author
    
    # user.mention -> <@123456789>
    # user.created_at -> datetime объект (UTC)
    await ctx.reply(f"Привет, {user.mention}! Твой аккаунт создан: {user.created_at.strftime('%Y-%m-%d')}")

@bot.command(name="echo")
async def echo_command(ctx: Context):
    # Все аргументы после команды доступны в виде списка строк:
    text = " ".join(ctx.args)
    if text:
        await ctx.send(text)
    else:
        await ctx.reply("Вы ничего не написали.")
```

## 3. Slash-команды

Для создания Slash-команд используется `@bot.slash_command`. Библиотека сама зарегистрирует команду в Discord API.

```python
from minuord import SlashContext

@bot.slash_command(name="ping", description="Проверить задержку бота")
async def ping_slash(ctx: SlashContext):
    # Отправляем сообщение, видимое только автору (ephemeral=True)
    await ctx.send(f"Понг! Задержка: {bot.latency_ms} мс", ephemeral=True)
```

## 4. UI Компоненты (Кнопки, Select Menu, Modals)

`minuord` имеет встроенные классы для создания UI-компонентов из модуля `minuord.components` и `minuord.enums`.

### Кнопки
```python
from minuord import Embed, Color, ActionRow, Button, ButtonStyle

@bot.command(name="buttons")
async def buttons_command(ctx):
    embed = Embed(title="Кнопки", description="Выберите действие", color=Color.BLURPLE)
    
    row = ActionRow(
        Button(style=ButtonStyle.PRIMARY, label="Подтвердить", custom_id="btn_confirm"),
        Button(style=ButtonStyle.DANGER, label="Отменить", custom_id="btn_cancel"),
        Button(style=ButtonStyle.LINK, label="GitHub", url="https://github.com/")
    )
    
    await ctx.send_embed(embed=embed) # Библиотека может потребовать прямого REST вызова для компонентов
```

### Выпадающие списки (Select Menu)
```python
from minuord import ActionRow, SelectMenu, SelectOption

@bot.command(name="select")
async def select_command(ctx):
    menu = SelectMenu(
        custom_id="color_select",
        placeholder="Выберите любимый цвет",
        options=[
            SelectOption(label="Красный", value="red", description="Цвет страсти"),
            SelectOption(label="Синий", value="blue", description="Цвет спокойствия"),
        ],
        min_values=1,
        max_values=1
    )
    
    row = ActionRow(menu)
    # Отправка аналогична кнопкам (потребует передачи `components` в payload)
```

### Модальные окна (Modal) и TextInput
Модальные окна — это всплывающие формы, которые отправляются в ответ на взаимодействие (Interaction).

```python
from minuord import Modal, TextInput, TextInputStyle, ActionRow

def create_feedback_modal():
    return Modal(
        custom_id="feedback_modal",
        title="Оставьте отзыв",
        components=[
            ActionRow(
                TextInput(
                    custom_id="feedback_text",
                    label="Ваш отзыв",
                    style=TextInputStyle.PARAGRAPH,
                    placeholder="Напишите всё, что думаете...",
                    required=True,
                    max_length=1000
                )
            )
        ]
    )
```

## 5. Управление участниками (Members) и Модерация

Если команда вызвана на сервере, `ctx.author` будет объектом `Member` (наследник `User`), который предоставляет множество асинхронных методов модерации:

```python
import datetime

@bot.command(name="punish")
async def punish(ctx):
    member = ctx.author
    
    # Выдать роль
    # await member.add_roles("ROLE_ID")
    
    # Снять роль
    # await member.remove_roles("ROLE_ID")
    
    # Изменить никнейм
    # await member.edit(nick="Новый Ник")
    
    # Переместить в другой голосовой канал
    # await member.move_to("VOICE_CHANNEL_ID")
    
    # Выдать таймаут (мут) на 10 минут
    if hasattr(member, "timeout"):
        duration = datetime.timedelta(minutes=10)
        await member.timeout(duration)
        await ctx.send(f"{member.mention} замучен на 10 минут.")
```

Библиотека также содержит встроенные команды модерации: `!ban`, `!kick`, `!mute`, `!unmute`, `!unban`.

## 6. Утилиты и Константы

`minuord` предоставляет полезные инструменты "из коробки":

```python
from minuord import snowflake_time, escape_markdown, Color, ChannelType

# Конвертация Snowflake ID в datetime
time_obj = snowflake_time(123456789012345678)

# Экранирование markdown (чтобы никто не сломал разметку бота)
safe_text = escape_markdown("Текст с *жирным* и _курсивом_")

# Удобная работа с цветами (RGB, HEX, Константы)
my_color1 = Color.from_hex("#FFAA00")
my_color2 = Color.from_rgb(255, 170, 0)
my_color3 = Color.BLURPLE
```

## 7. Checks, Cooldowns, Hooks (Хуки и Проверки)

Вы можете гибко управлять тем, кто и как часто может вызывать команды:

```python
# Централизованный обработчик ошибок
@bot.on_command_error()
async def on_error(ctx, exc):
    await ctx.reply(f"Произошла ошибка: {exc}")

# Кастомная проверка (только для админов)
def is_admin(ctx):
    if not hasattr(ctx.author, "guild_permissions"):
        return False
    # Administrator = 1 << 3
    return bool(ctx.author.guild_permissions.value & 8)

@bot.command(name="secret")
@bot.cooldown(10) # Вызов команды не чаще 1 раза в 10 секунд
@bot.check(is_admin) # Проверка прав
async def secure_command(ctx):
    await ctx.reply("Секретные данные...")
```

---

## Лицензия

Проект распространяется под лицензией MIT. Подробнее см. в файле `LICENSE`.
