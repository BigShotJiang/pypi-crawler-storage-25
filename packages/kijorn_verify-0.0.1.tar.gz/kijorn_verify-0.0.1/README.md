# `kijorn-verify`

> **Reserved for the KIJORN-RECEIPT-1.0 verifier ecosystem.**
> Full implementation lands in `1.0.0`.

This package is the future home of the canonical Python verifier for
the [KIJORN-RECEIPT-1.0](https://kijorn.com/spec/kijorn-receipt/1.0)
constitutional specification — an open, auditable wire format for
cryptographically verifiable AI work product.

The `0.0.1` release exposes no functional verifier. Its sole purpose is
to secure the `kijorn-verify` PyPI distribution name before the
constitutional spec is published, so that the standard cannot be
squatted, forked, or diluted at the moment of publication.

## Install (placeholder)

```bash
pip install kijorn-verify==0.0.1
```

```python
import kijorn_verify

print(kijorn_verify.KIJORN_RECEIPT_SPEC_URL)
# https://kijorn.com/spec/kijorn-receipt/1.0
```

## What lands in `1.0.0`

- A pure-stdlib (no third-party runtime dependencies) verifier for any
  conformant KIJORN-RECEIPT-1.0 wire artifact (the `Receipt`).
- Verification of:
  - RFC 6962 daily-audit-root reconstruction;
  - Sigstore Rekor anchor inclusion-proof and signed-entry-timestamp;
  - Ed25519 brief signature under the pinned platform key;
  - Cross-block bindings (the chain-of-custody invariant).
- Deterministic, byte-stable verdicts that must agree, byte-for-byte,
  with the JavaScript reference verifier at
  [`@kijorn/verify`](https://www.npmjs.com/package/@kijorn/verify) —
  enforced by Kijorn's cross-language conformance gate in CI.

## Until `1.0.0`

The in-tree reference implementation lives at
[`tools/verify/bundle_py/`](https://github.com/kijorn/kijorn/tree/main/tools/verify/bundle_py)
in the canonical Kijorn monorepo. It already verifies live Kijorn
receipts and is what `kijorn-verify==1.0.0` will ship to PyPI.

## License

MIT — by design. The verifier is **protocol infrastructure**. It must be
embeddable in any product (open-source, commercial, regulated, or
otherwise) without friction. The Kijorn platform itself and the official
[`kijorn`](https://pypi.org/project/kijorn/) Python SDK remain under
Apache-2.0; the verifier is intentionally more permissive.

## Constitutional governance

The format and verifier evolve under
[ADR-085 — Receipt Sovereignty](https://github.com/kijorn/kijorn/blob/main/docs/ADR-085-receipt-sovereignty.md).
Breaking changes to the wire format require a new major version of the
spec, a public RFC, and a 90-day review window. The verifier in this
package will always honor that contract.

## Links

- Spec: <https://kijorn.com/spec/kijorn-receipt/1.0>
- Reference JavaScript verifier: <https://www.npmjs.com/package/@kijorn/verify>
- Repository: <https://github.com/kijorn/kijorn>
- Trust page: <https://kijorn.com/trust>
