"""Smoke tests for the kijorn-verify@0.0.1 reserved placeholder.

These tests guarantee the placeholder advertises its reserved status
clearly, points at the constitutional spec URL, and refuses to silently
no-op when called -- so an embedder who picks up 0.0.1 by mistake gets
an immediate, directing error instead of a false sense of verification.
"""

from __future__ import annotations

import pytest

import kijorn_verify


def test_placeholder_advertises_reserved_status() -> None:
    assert kijorn_verify.KIJORN_RECEIPT_VERIFIER_RESERVED is True


def test_placeholder_points_at_constitutional_spec_url() -> None:
    assert (
        kijorn_verify.KIJORN_RECEIPT_SPEC_URL
        == "https://kijorn.com/spec/kijorn-receipt/1.0"
    )


def test_version_is_reserved_zero_zero_one() -> None:
    assert kijorn_verify.__version__ == "0.0.1"


def test_verify_receipt_raises_with_directing_message() -> None:
    with pytest.raises(NotImplementedError) as exc_info:
        kijorn_verify.verify_receipt()
    msg = str(exc_info.value)
    assert "0.0.1" in msg
    assert "placeholder" in msg
    assert kijorn_verify.KIJORN_RECEIPT_SPEC_URL in msg
