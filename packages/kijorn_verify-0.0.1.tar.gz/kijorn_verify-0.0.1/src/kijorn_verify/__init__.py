"""kijorn-verify — placeholder.

This package name is reserved for the KIJORN-RECEIPT-1.0 verifier
ecosystem. The 0.0.1 release intentionally exports no functionality;
its only purpose is to secure the ``kijorn-verify`` PyPI distribution
name before the constitutional spec is published.

The full verifier lands in 1.0.0 alongside the publication of
KIJORN-RECEIPT-1.0 at https://kijorn.com/spec/kijorn-receipt/1.0 .

Until then, please use the in-tree reference implementation at
https://github.com/kijorn/kijorn/tree/main/tools/verify/bundle_py .
"""

from __future__ import annotations

__all__ = [
    "KIJORN_RECEIPT_VERIFIER_RESERVED",
    "KIJORN_RECEIPT_SPEC_URL",
    "verify_receipt",
]

__version__ = "0.0.1"

KIJORN_RECEIPT_VERIFIER_RESERVED: bool = True

KIJORN_RECEIPT_SPEC_URL: str = "https://kijorn.com/spec/kijorn-receipt/1.0"


def verify_receipt(*_args: object, **_kwargs: object) -> None:
    """Reserved entrypoint. Always raises until 1.0.0.

    Raises:
        NotImplementedError: 0.0.1 is a reserved namespace placeholder;
            the verifier ships in 1.0.0 alongside KIJORN-RECEIPT-1.0.
    """
    raise NotImplementedError(
        "kijorn-verify==0.0.1 is a reserved placeholder. The verifier "
        "ships in 1.0.0. See "
        f"{KIJORN_RECEIPT_SPEC_URL} for the constitutional specification."
    )
