# figma - process_frame_to_toon_data

**Toolkit**: `figma`
**Method**: `process_frame_to_toon_data`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def process_frame_to_toon_data(frame_node: Dict) -> Dict:
    """
    Process a Figma frame node into TOON-ready data structure.

    Returns structured data that can be serialized to TOON format.
    """
    name = frame_node.get('name', 'Untitled')

    # Extract position and size
    bounds = frame_node.get('absoluteBoundingBox', {})
    position = {'x': bounds.get('x', 0), 'y': bounds.get('y', 0)}
    size = {'w': bounds.get('width', 0), 'h': bounds.get('height', 0)}

    # Extract text by role
    text_data = extract_text_by_role(frame_node)

    # Extract components
    components = extract_components(frame_node)

    # Extract input fields
    inputs = extract_inputs(frame_node)
    # Dedupe inputs by name
    seen_inputs = set()
    unique_inputs = []
    for inp in inputs:
        if inp['name'] not in seen_inputs:
            seen_inputs.add(inp['name'])
            unique_inputs.append(inp)

    # Build frame data with deduplication
    frame_data = {
        'id': frame_node.get('id', ''),
        'name': name,
        'position': position,
        'size': size,
        # Deduplicate and limit text fields
        'headings': dedupe_and_clean_text(text_data['headings'], max_items=5),
        'labels': dedupe_and_clean_text(text_data['labels'], max_items=15),
        'buttons': dedupe_and_clean_text(text_data['buttons'], max_items=10),
        'inputs': unique_inputs[:10],  # Limit to 10 inputs
        'body': dedupe_and_clean_text(text_data['body'], max_items=10),
        'errors': dedupe_and_clean_text(text_data['errors'], max_items=5),
        'placeholders': dedupe_and_clean_text(text_data.get('placeholders', []), max_items=5),
        'components': list(dict.fromkeys(components))[:15],  # Dedupe components too
    }

    # Infer type and state
    frame_data['type'] = infer_screen_type(frame_data)
    frame_data['state'] = infer_state_from_name(name)

    # Check if variant
    base_name = extract_base_name(name)
    if base_name != name:
        frame_data['variant_of'] = base_name

    return frame_data
```

## Helper Methods

```python
Helper: extract_components
def extract_components(node: Dict, depth: int = 0, max_depth: int = 10) -> List[str]:
    """
    Recursively extract component/instance names.
    """
    if depth > max_depth:
        return []

    components = []
    node_type = node.get('type', '').upper()

    if node_type in ['COMPONENT', 'INSTANCE', 'COMPONENT_SET']:
        name = node.get('name', '')
        if name:
            components.append(name)

    for child in node.get('children', []):
        components.extend(extract_components(child, depth + 1, max_depth))

    return components
```

```python
Helper: extract_text_by_role
def extract_text_by_role(
    node: Dict,
    depth: int = 0,
    max_depth: int = 10,
    parent_context: str = ''
) -> Dict[str, List[str]]:
    """
    Recursively extract text content categorized by likely role.

    Improved categorization:
    - Uses font size, weight, and style for heading detection
    - Considers parent container names for context
    - Deduplicates and cleans text
    - Filters out placeholder/system text

    Returns:
        {
            'headings': [...],  # Large/bold text, titles
            'labels': [...],    # Form labels, field names, small descriptive text
            'buttons': [...],   # Text inside interactive elements
            'body': [...],      # Regular body/paragraph text
            'errors': [...],    # Error messages (red text, error containers)
            'placeholders': [...],  # Placeholder/hint text (gray, placeholder in name)
        }
    """
    if depth > max_depth:
        return {'headings': [], 'labels': [], 'buttons': [], 'body': [], 'errors': [], 'placeholders': []}

    result = {'headings': [], 'labels': [], 'buttons': [], 'body': [], 'errors': [], 'placeholders': []}

    node_type = node.get('type', '').upper()
    node_name = node.get('name', '').lower()

    # Build context path for children
    current_context = f"{parent_context}/{node_name}" if parent_context else node_name

    if node_type == 'TEXT':
        text = node.get('characters', '').strip()
        if not text:
            return result

        # Skip very short text that's likely icons or separators
        if len(text) <= 1 and text not in ['?', '!']:
            return result

        # Skip obvious system/template text
        skip_patterns = ['lorem ipsum', 'placeholder', '{{', '}}', 'xxx', '000']
        if any(p in text.lower() for p in skip_patterns):
            return result

        # Get text style info
        style = node.get('style', {})
        font_size = style.get('fontSize', 14)
        font_weight = style.get('fontWeight', 400)
        text_decoration = style.get('textDecoration', '')

        # Check fills for color-based categorization
        fills = node.get('fills', [])
        is_red = any(
            f.get('type') == 'SOLID' and
            f.get('color', {}).get('r', 0) > 0.7 and
            f.get('color', {}).get('g', 0) < 0.3 and
            f.get('color', {}).get('b', 0) < 0.3
            for f in fills if isinstance(f, dict)
        )
        is_gray = any(
            f.get('type') == 'SOLID' and
            abs(f.get('color', {}).get('r', 0) - f.get('color', {}).get('g', 0)) < 0.1 and
            f.get('color', {}).get('r', 0) > 0.4 and
            f.get('color', {}).get('r', 0) < 0.7
            for f in fills if isinstance(f, dict)
        )

        # Categorize based on multiple signals
        # Priority: error > placeholder > heading > label > body

        # Error detection
        if is_red or 'error' in node_name or 'error' in current_context:
            result['errors'].append(text)
        # Placeholder detection
        elif is_gray or 'placeholder' in node_name or 'hint' in node_name:
            result['placeholders'].append(text)
        # Heading detection (large, bold, or semantically marked)
        elif (font_size >= 18 or
              font_weight >= 600 or
              any(h in node_name for h in ['heading', 'title', 'header', 'h1', 'h2', 'h3'])):
            result['headings'].append(text)
        # Label detection (small text, form context, specific naming)
        elif (font_size <= 12 or
              'label' in node_name or
              'caption' in node_name or
              any(ctx in current_context for ctx in ['form', 'input', 'field'])):
            result['labels'].append(text)
        # Everything else is body text
        else:
            result['body'].append(text)

    # Check if this is an interactive element
    is_button = (
        node_type in ['INSTANCE', 'COMPONENT', 'FRAME'] and
        any(kw in node_name for kw in ['button', 'btn', 'cta', 'action', 'link', 'tab', 'chip'])
    )
    is_input = (
        node_type in ['INSTANCE', 'COMPONENT', 'FRAME'] and
        any(kw in node_name for kw in ['input', 'textfield', 'textarea', 'dropdown', 'select'])
    )

    # Recurse into children
    for child in node.get('children', []):
        child_result = extract_text_by_role(child, depth + 1, max_depth, current_context)

        if is_button:
            # All text inside buttons goes to buttons category
            for texts in child_result.values():
                result['buttons'].extend(texts)
        elif is_input:
            # Input text goes to placeholders if gray, otherwise labels
            result['placeholders'].extend(child_result.get('placeholders', []))
            # Other text becomes labels (field values shown)
            for key in ['headings', 'labels', 'body']:
                result['labels'].extend(child_result.get(key, []))
            result['errors'].extend(child_result.get('errors', []))
        else:
            for key in result:
                result[key].extend(child_result.get(key, []))

    return result
```

```python
Helper: infer_screen_type
def infer_screen_type(frame_data: Dict) -> str:
    """
    Infer screen type from content.

    Returns: form, list, detail, dashboard, modal, menu, settings, chat, etc.
    """
    name_lower = frame_data.get('name', '').lower()
    components = frame_data.get('components', [])
    buttons = frame_data.get('buttons', [])
    labels = frame_data.get('labels', [])

    components_lower = [c.lower() for c in components]
    buttons_lower = [b.lower() for b in buttons]

    # Check name hints
    type_hints = {
        'form': ['login', 'signup', 'register', 'checkout', 'payment', 'form', 'input'],
        'list': ['list', 'feed', 'timeline', 'results', 'search results'],
        'detail': ['detail', 'profile', 'item', 'product', 'article'],
        'dashboard': ['dashboard', 'home', 'overview', 'summary'],
        'modal': ['modal', 'dialog', 'popup', 'overlay', 'alert'],
        'menu': ['menu', 'navigation', 'sidebar', 'drawer'],
        'settings': ['settings', 'preferences', 'config', 'options'],
        'chat': ['chat', 'message', 'conversation', 'inbox'],
        'onboarding': ['onboarding', 'welcome', 'intro', 'tutorial'],
    }

    for screen_type, keywords in type_hints.items():
        if any(kw in name_lower for kw in keywords):
            return screen_type

    # Check components
    if any('input' in c or 'textfield' in c or 'form' in c for c in components_lower):
        return 'form'
    if any('card' in c or 'listitem' in c for c in components_lower):
        return 'list'
    if any('modal' in c or 'dialog' in c for c in components_lower):
        return 'modal'

    # Check buttons for form indicators
    form_buttons = ['submit', 'save', 'sign in', 'log in', 'register', 'next', 'continue']
    if any(any(fb in b for fb in form_buttons) for b in buttons_lower):
        return 'form'

    return 'screen'  # Generic fallback
```
