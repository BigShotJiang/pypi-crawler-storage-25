# Product Requirements: Vega

**Product:** Vega — Trust Infrastructure for Agentic AI
**Owner:** Benjamin Booth
**IP Owner:** The University of Texas at Austin (proposed exclusive commercial license to Axiom Labs)
**Status:** Draft — Phase 1 extraction scoped; full GTM deferred to post-Prague
**Last Updated:** 2026-04-21

---

## 1) Elevator Pitch

Vega is the trust, governance, and federation layer for agentic AI systems. It makes it possible for agents to operate safely across institutional boundaries — enforcing identity, classification, authorization, and audit without requiring every harness, platform, or consumer to reinvent trust infrastructure.

Install Vega and any agent platform — Axiom, LangChain, CrewAI, Hermes, OpenClaw deployments — gains enterprise-grade governance. Install it as an Axiom deployment profile and you get a dedicated federation and trust node. Plug it into your existing IAM, Envoy, and DNSSEC stack, and agents inherit governance from infrastructure you already trust.

---

## 2) Problem / Opportunity

### The governance gap

Every major agentic AI harness — LangChain, CrewAI, Hermes Agent (95K+ stars), OpenClaw (250K+ stars before ClawHavoc), Claude Code, Cursor, OpenAI Agents SDK, Vercel AI SDK, Mastra, Google ADK — has weak or ad-hoc governance. ClawHavoc (800+ malicious skills, 20% of OpenClaw's registry) and OpenClaw's CVE-2026-25253 demonstrated what happens when governance is deferred: enterprises can't adopt, governments ban, and users pay the price.

NemoClaw (NVIDIA, March 2026) validated the market: enterprises want governance as a named line item, not a buried feature. But NemoClaw is a wrapper on OpenClaw specifically. There's no architectural-first, standards-compliant, institution-ready trust infrastructure that works across harnesses.

### What doesn't exist today

A trust layer for agentic AI that:
- Works across multiple harnesses (not tied to one platform)
- Integrates with enterprise IAM (AWS IAM, Azure AD, Okta, InCommon)
- Supports multi-institutional federation without centralizing data
- Enforces classification boundaries (public / restricted / export-controlled / classified)
- Provides cryptographic identity for cross-org agent interactions
- Uses open standards (OIDC, Envoy ExtAuthz, DNSSEC, A2A) rather than proprietary replacements
- Ships as embedded library, bundled platform, gateway daemon, federation peer, or attestation verifier — consumer's choice

### The opportunity

If Vega exists as a named category and widely-adopted standard, it becomes the default governance layer for agentic AI the way IAM became the default for cloud. The market window for category definition is open in 2026; by 2027 it will be closed. Vega has a 9-12 month head start on any competitor who isn't already building.

UT Austin has the institutional credibility, classification-boundary research, and TRIGA-consortium seed federation to anchor the category. Axiom Labs (B-Tree Ventures DBA, proposed exclusive commercial licensee) has the execution velocity to ship open-source and commercial products on the required timeline.

---

## 3) Goals & Success Metrics

### Primary goals

- **Establish the category.** Vega becomes the reference product for "trust infrastructure for agentic AI." Industry conversations adopt Vega-derived terminology.
- **Achieve multi-harness adoption.** Vega is deployed in at least three non-Axiom harness ecosystems by end of 2027.
- **Seed institutional federation.** TRIGA consortium (UT, INL, OSU) runs production Vega federation; 3+ additional institutions adopt by end of 2027.
- **Enable Axiom Labs revenue.** Vega commercial tier produces first paid enterprise customers within 6 months of public launch.

### Success metrics

- **Open-source traction:** 5K GitHub stars on `vega-trust` repo by end of 2027; 50K+ PyPI downloads/month.
- **Harness integrations:** Vega adapters or integrations published for LangChain, CrewAI, Hermes, OpenClaw, and at least one more.
- **Institutional federation:** 5+ institutions actively federated; 3+ publishing research citing Vega.
- **Enterprise revenue:** 3+ commercial licensing deals closed by end of 2027 (target ACV $50K-$250K range).
- **Research publications:** Vega federation architecture published in a top venue (USENIX Security, ACM CCS, NDSS, or similar) by mid-2027.
- **Standards contributions:** Vega patterns contributed to at least one industry working group (Linux Foundation AI, CNCF, OASIS) by end of 2027.

---

## 4) Key Users / Personas

- **Enterprise CISO / platform security lead.** Evaluating agentic AI for their organization. Blocked by governance and audit concerns. Procures Vega as a discrete security product. Values: classification boundary enforcement, SSO integration, audit trail, FedRAMP/SOC2 certification path.

- **Institutional IT / research computing staff.** Running Axiom, LangChain, or other harnesses for researchers. Needs multi-institutional federation that respects IP, export control, and access tiers. Values: DNSSEC-compatible discovery, InCommon federation, local data sovereignty.

- **Platform engineer at agent-tooling company.** Building on LangChain or CrewAI; wants to offer enterprise-grade governance without building it. Integrates Vega via embedded library or gateway. Values: minimal integration burden, predictable semantics, OPA-compatible API.

- **Academic researcher.** Publishing on federated agentic systems, classification-aware RAG, multi-party trust. Values: open-source, standards-compliant, citable, institutionally-backed.

- **Federation operator.** Running a Vega peer at a participating institution. Values: simple operation, transparent policy, forensic audit capability, graceful degradation.

---

## 5) Scope — Key Capabilities

### 5.1 Five Deployment Shapes

Vega ships in five consumer-facing shapes. Each shape is a configured subset of the same underlying codebase; consumers choose based on their integration depth.

1. **Embedded library** (`pip install vega-trust`): Python primitives for use inside LangChain, CrewAI, LlamaIndex, or custom agent code. Trust profiles, RACI gates, classification stamps, identity. No federation required.

2. **Bundled with Axiom** (default for Axiom deployments): Vega is automatically included as a dependency of Axiom. No separate install step.

3. **Gateway / sidecar daemon** (Docker container, OPA-compatible API): language-agnostic policy decision point. Other harnesses (Go, Rust, Node, Java) call Vega over HTTP/gRPC for enforcement. Integrates with Envoy ExtAuthz, Istio, or any HTTP proxy.

4. **Attestation-only** (lightweight verification library): verifies signatures on Vyzier-published extensions, Dendra models, and other signed artifacts. Pure addition, no runtime integration.

5. **Federation peer** (vega-server process): runs at a participating institution. Handles cryptographic identity, manifest channel sync, capability advertisement, cross-node trust negotiation. Enables multi-institutional federation.

### 5.2 Identity and Principals

- Ed25519 keypairs for nodes, agents, and organizations (multi-authority signatures per ADR-026)
- Matrix-style principal naming: `@name:context` (e.g., `@alice:ut-austin`, `@ben-curio:research-reactor`)
- OIDC integration: accept tokens from AWS IAM, Azure AD, Okta, InCommon, PIV/CAC; map to Vega principals
- Multi-institutional anchoring per ADR-022
- Cryptographic attestation chain: institutional signature → role assignment → session delegation

### 5.3 Trust Profiles

- Named bundles of per-category RACI slider positions
- Deterministic policy application; LLM advisory only (per `spec-security.md §2`)
- Federation-shareable and signed
- Built-in profiles: `dev-permissive`, `classroom-default`, `classroom-exam`, `research-institutional`, `gov-conservative`
- Custom profiles definable per deployment
- Change history auditable

### 5.4 Classification Stamps and Enforcement

- Per spec-classification-boundary.md §2: content classification (level + compartments + export + proprietary + provenance)
- Principal clearance with TTL
- Federation domain (max level federation can handle)
- Filter-at-boundary enforcement: server-side redaction; unauthorized content never leaves the node

### 5.5 RACI Gate Enforcement

- Every action request passes through a Vega RACI gate
- Gate applies trust-profile policy + classification stamps + principal clearance
- Auto-approve, auto-approve-with-audit, prompt-human, or refuse
- Human-in-the-loop integrations: CLI prompts, LMS notifications, email, Slack, webhook

### 5.6 Federation Protocol (A2A)

- Agent-to-Agent protocol v0.3+ (Linux Foundation)
- Well-known HTTP endpoints for agent discovery (`/.well-known/agent-card.json`)
- Manifest channel for cross-node state propagation
- Invitation-based trust bootstrap with bidirectional approval
- DNSSEC-validated DNS SRV for discovery at scale

### 5.7 Integration with Existing Standards

- **OIDC** — accept tokens from any OIDC IdP
- **Envoy ExtAuthz** — Vega implements the contract; existing Envoy/Istio deployments add Vega as a PDP
- **OPA-compatible API** — Rego-style policy queries for DevOps teams familiar with OPA
- **DNS-SD + DNSSEC** — discovery via standard DNS, authenticated via DNSSEC signatures
- **Sigstore** — artifact signing uses Sigstore's OIDC-to-cert flow; Vega does not require a separate PKI
- **OpenTelemetry** — all Vega operations emit OTel spans

### 5.8 WARDEN Federation Agent

Vega includes a dedicated federation agent, following the Axiom agent-naming convention. WARDEN:
- Monitors federation health (peer availability, manifest freshness, identity validity)
- Applies validated classification pattern (re-validates trust profiles based on observed behavior)
- Initiates quarantine and recovery ceremonies for compromised peers
- Cross-validates findings with peer nodes per Federated Quality Gate design
- Responds to human RACI escalations with contextual information
- Acts autonomously within its trust profile; escalates outside of it

WARDEN is bundled with Vega deployments running in federation-peer shape (Shape 5). Not required for embedded-library use.

### 5.9 CLI and Administration

- `vega identity` — principal and keypair management
- `vega trust profile` — create, edit, share, import trust profiles
- `vega federation peer` — federation membership (join, leave, suspend, approve)
- `vega classification stamp` — classify content, validate stamps
- `vega audit` — query audit trail; export for compliance
- `vega verify` — signature verification for artifacts
- `vega server` — run Vega in server mode (for Shapes 3 and 5)

---

## 6) Non-Functional Requirements

- **Latency:** Authorization decisions < 10ms median, < 50ms p99 (embedded library); < 25ms median, < 100ms p99 (gateway over localhost). Federation resolution < 500ms median.
- **Throughput:** Single Vega gateway instance handles 10K authz/sec on commodity hardware.
- **Availability:** Federation peer operations tolerate 24h offline without service degradation (cached manifests).
- **Security:** Defense in depth per ADR-025 threat model. No authorization decision made by LLM output (deterministic gates).
- **Compliance path:** FedRAMP Moderate, SOC 2 Type II, HIPAA, FERPA achievable as commercial add-ons.
- **Offline operation:** All Shape 1, 2, 4, 5 operations work air-gapped. Shape 3 requires network for federation but not for local policy.

---

## 7) Timeline

### Phase 1 — Architectural Extraction (Apr-May 2026, pre-Prague)

- Extract `vega-trust` Python package from `axiom/src/axiom/federation/` and `axiom/src/axiom/security/`
- Preserve contributor history via git-filter-repo
- Axiom consumes Vega as a pinned dependency
- Phase 1 PyPI release (0.1.x) — embedded library shape only
- Basic landing page claims the category
- Vega bundled with Axiom for Prague deployment

### Phase 2 — Public Positioning (Jul-Sep 2026, post-Prague)

- Prague results published; research paper draft referencing Vega
- `vega-trust` 0.5 — federation primitives exposed
- Gateway shape (`vega-server`) initial release as Docker image
- Documentation site launch at `vega-trust.dev` or similar
- LangChain and CrewAI adapter libraries published (shipped `pip install vega-langchain`, `pip install vega-crewai`)
- WARDEN agent shipped with server shape

### Phase 3 — Commercial Launch (Q4 2026 - Q1 2027)

- Vega 1.0 OSS release
- Commercial tier (open-core): FROST threshold signing, multi-org cross-bridge federation, advanced classification, SOC2 audit reporting, managed cloud
- TRIGA consortium as flagship federation reference
- Target: 3 paid enterprise customers by end of Q1 2027
- Research paper submitted to top-tier venue

### Phase 4 — Standards and Ecosystem (2027+)

- Standards-body engagement (LF AI, CNCF, OASIS)
- Non-Axiom harness integrations: OpenClaw bridge, Hermes bridge
- Multi-language SDKs (Rust, TypeScript, Go, Java) — matches Dendra's multi-language roadmap
- Federated Dendra training rides on Vega federation

---

## 8) Risks & Open Questions

### Risks

- **OTC timeline.** UT Office of Technology Commercialization approval for Vega as a commercial product may take 6-12 months. Phase 1 extraction proceeds regardless (Apache 2.0 open-source is within existing UT guidelines); commercial Vega tiers gated on OTC.
- **Category window closing.** NemoClaw or another competitor defines the category first. Mitigation: Phase 1 public positioning in April-May 2026 claims the category early.
- **Cross-entity licensing friction.** Every Axiom commercial deal touches Vega (UT-owned). Licensing complexity could slow sales. Mitigation: pre-negotiate standard commercial license terms with UT OTC during Phase 1.
- **Small team capacity.** Vega + Dendra + Axiom + Keplo + Vyzier + NeutronOS is aggressive for a small team. Mitigation: staged launches (Dendra first, Vega second); each product has bounded launch window.
- **Architectural complexity of five shapes.** Supporting embedded library + bundled + gateway + verification-only + federation peer is complex. Mitigation: single codebase with configuration profiles; shapes 1, 2, 4 are all one Python package; only shapes 3 and 5 require runtime services.

### Open questions

- WARDEN naming — confirm or propose alternative
- Final domain (`vega-trust.dev`, `vega-trust.io`, `vegaprotocol.org`, or other — `.ai` premium, `.com` unavailable)
- Non-profit foundation for Vega: worth pursuing LF AI membership or CNCF sandbox status for long-term category defensibility?
- Commercial operator for UT IP: exclusive license to Axiom Labs vs. foundation stewardship
- Initial research paper venue and author affiliation (UT faculty, Axiom Labs, or joint)
- Resolution of AXI / Keplo workflow-coupling ADR before Keplo extraction

---

## 9) Acceptance & Rollout

### Phase 1 acceptance (pre-Prague)

- `vega-trust` package imports cleanly without Axiom
- Axiom test suite passes against extracted Vega
- Federation integration test (two Axiom nodes via Vega) passes
- Landing page published at claimed domain
- Vega contributes zero breaking changes to Axiom's existing API surface

### Phase 2 acceptance (post-Prague)

- At least one non-Axiom harness (LangChain or CrewAI) demonstrably integrates with Vega
- Gateway shape operational in a test federation
- WARDEN running autonomously in Prague-successor deployment
- Documentation site covers all five deployment shapes

### Phase 3 acceptance (commercial launch)

- 3+ paid customers or LOIs signed
- TRIGA consortium federation operational in production
- SOC 2 Type II audit initiated

---

## 10) Related Documents

- `docs/specs/spec-vega.md` — technical specification (this PRD's companion)
- `docs/working/plan-vega-extraction.md` — execution plan
- `docs/working/design-resolution-protocol.md` — resolution layer design informing Vega federation
- `docs/working/brand-product-strategy.md` — portfolio context
- `docs/specs/spec-classification-boundary.md` — classification model
- `docs/specs/spec-security.md §2` — deterministic/model-mediated boundary
- `docs/prds/prd-learned-switch.md` — Dendra PRD (sibling product, also Axiom Labs-owned)
- ADR-020 — federation identity layers
- ADR-022 — federation identity roots
- ADR-025 — federation threat model
- ADR-026 — ownership model
