# WALL-E / Pixar IP Remediation — Proposal

> **Status:** Draft for Ben's review. **No code changes have been made.**
> Implementation of any rename / asset-replacement work is **post-Prague**;
> this doc is the planning artifact so we know what we owe and how to scope
> it the moment the freeze lifts.
>
> **Date:** 2026-05-04 · **Owner:** Ben (R/A) · **Drafter:** research agent.

---

## 0. TL;DR

The Axiom + NeutronOS portfolio currently borrows heavily from Pixar's *WALL-E*
(2008) — character names (WALL-E, EVE, M-O, BURN-E), the `WALL•E` typeset
with the iconic red bullet, the ASCII silhouette evoking the trash-compactor
character (binocular eye housings, yellow hull, treads, claw clamps), the
"Directive: assist." catchphrase, and **explicit attribution prose** in two
public PRDs that names *"Pixar's WALL-E"* as the source. The exposure is
cohesive enough that an enforcement reviewer would read it as a deliberate
homage, not coincidence.

- **TIER A (public-facing) surfaces:** ~9 distinct files including PyPI
  console-script aliases, README, and 3 PRDs.
- **TIER B (open-source code identifiers):** ~70 files — agent class names,
  module names (`wall_e/`, `eve/`, `m_o/`, `burn_e/`, `pr_t/`,
  `d_fib/`), persona files, registry keys.
- **TIER C (internal docs / never shipped):** ~280 files — ADRs, working/,
  papers/, tests, glossaries.

**Lead candidate replacement set** (one coherent narrative, not picked yet —
Ben decides): **NOVA** (chat orchestrator) · **SCAN** (signal/read) ·
**TIDY** (steward/hygiene) · **FORGE** (releases) · **MEDIC** (diagnostics) ·
**PRESS** (publisher) · **SAGE** (research). All are common-vocabulary
short caps, none are Pixar/Disney/major-studio characters, all carry a
function-y vibe; CHALK-E and CURI-O remain to be re-evaluated since they're
phonetic-style coinages but not direct Pixar names.

---

## 1. AUDIT — Exposure Inventory

### 1.1 Methodology + scope

- **Repos scanned:** `axiom/`, `Neutron_OS/`, `dendra/`. Skipped: `.venv/`,
  `node_modules/`, `__pycache__/`, `*.egg-info/`, `dist/`, `out/`,
  `archive/`, `provenance-2026/`, the `axiom-aeos-tests/` worktree
  (verified via `.git` to be a worktree of `axiom`, so its files mirror
  `axiom/`'s — counted once).
- **Searches:** ALL-CAPS hyphenated names (WALL-E, EVE, M-O, BURN-E, D-FIB,
  PR-T, CHALK-E, CURI-O, V-EGA), snake-case dir tokens (`wall_e`, `eve`,
  `m_o`, `burn_e`, `pr_t`, `d_fib`, `chalke`, `curi_o`, `v_ega`),
  pyproject console-scripts, `Pixar*` attribution strings, "Directive:
  assist", "starliner", "trash-compactor", "binocular".
- **Dendra:** clean — zero hits across all searches. Its agents/branding are
  IP-independent and need no remediation.

### 1.2 Asset inventory by Pixar-derivation risk

Each row shows: the asset, what it is, what tier of surface it lives on, an
aggregate file count, and a risk rating. (See §1.3 for the verbatim-quote
spot-checks.)

| # | Asset | Type | TIER A files | TIER B files | TIER C files | Risk |
|---|---|---|---|---|---|---|
| 1 | **WALL-E** name (agent) | Direct Pixar character (registered Disney TM in many classes) | 5 | ~25 | ~65 | **HIGH** |
| 2 | **EVE** name (agent) | Direct Pixar character | 4 | ~20 | ~55 | **HIGH** |
| 3 | **M-O** name (agent) | Direct Pixar character (cleaning bot) | 4 | ~22 | ~50 | **HIGH** |
| 4 | **BURN-E** name (agent) | Direct Pixar character (eponymous Pixar short, 2008 DVD release) | 3 | ~12 | ~28 | **HIGH** |
| 5 | **AUTO** (no character agent) | Generic enum — *not* the Pixar autopilot | 0 | 6 (enum value) | a few | **NONE** (false positive — confirmed all `AUTO` uses are programmatic enums like `PlanStepGate.AUTO`, `ProposalDecision.AUTO`, `SearchMode.AUTO`) |
| 6 | **PR-T** name (agent) | Pixar-style coinage (Pixar character is "M-O Beauty bot", but the spec calls it "Purty / PR-T"). Not directly a Pixar character name; styled to match the Pixar phonetic family. The PR-T → "Beauty bot" mapping in PRDs claims Pixar lineage explicitly. | 3 | ~10 | ~20 | **MEDIUM-HIGH** (Pixar lineage explicitly claimed in PRD §The Agent Team) |
| 7 | **D-FIB** / **DFIB** name | Original coinage (defibrillator pun) but visually styled to fit the Pixar family + the PRD calls it "Defib / Medical bot" mapping to Pixar's medical bot | 3 | ~10 | ~22 | **MEDIUM** (no direct character name match, but family-resemblance + explicit Pixar attribution) |
| 8 | **CURI-O** name | Original coinage (curio = collector's curiosity). Persona explicitly cites "WALL-E's curiosity" as inspiration. | 1 | ~6 | ~15 | **MEDIUM-LOW** (name itself is original; the cross-reference to WALL-E in the persona is the only liability) |
| 9 | **CHALK-E** name | Original coinage (chalkboard + Pixar phonetic). Persona explicitly cites "WALL-E-family animated co-worker". | 0 | ~12 | ~35 | **MEDIUM-LOW** (name original; tied to Pixar in persona prose) |
| 10 | **V-EGA** name | Acronym for Vega's federation agent (Verifier/Enforcer/Gatekeeper/Arbiter). Coined to overlap product brand "Vega". No Pixar tie. | 0 | ~5 | ~15 | **LOW** (safe; verify no third-party "VEGA" software-agent TM) |
| 11 | **`WALL•E` typeset** (with red `•` bullet between LL and E) | Pixar's iconic logotype. Reproduced in the rich-rendered banner. | 1 (axiom_cli.py) | 2 (chat fullscreen + setup renderer) | several PRDs | **HIGH** (typography is one of the most distinctive trademark-like elements) |
| 12 | **ASCII WALL-E mascot** (binocular eyes + yellow hull + treads + claw clamps + label placard) | Stylized character silhouette evoking the Pixar character. Three rendering variants: rich-color in `axiom_cli._print_welcome_banner`, plain-ANSI in `setup/renderer._AXI_ART_LINES`, mini in `chat/fullscreen.py:_render_welcome` | 3 (banner + chat + setup) | — | — | **HIGH** (the visual is the most recognizable element; comments self-describe it as "Pixar WALL-E anatomy — designed against the reference photo") |
| 13 | **"Directive: assist."** dialog | Direct quote-pattern from the film ("Directive: ___" is WALL-E/EVE's catchphrase). | 1 (axiom_cli.py) | — | a few PRD echoes | **HIGH** (verbatim dialog mirroring) |
| 14 | **"Axiom luxury starliner"** prose / "Axiom mothership" framing | The product *is* named after the starship in the film. The codebase calls it out explicitly: `setup/renderer.py:123` — "Axi is the Axiom ship's voice — named for the WALL-E Axiom luxury starliner." Banner docstring: "Render WALL-E aboard the Axiom mothership — the first-touch banner." | 1 (axiom_cli docstring) | 1 (renderer.py comment) | — | **MEDIUM-HIGH** (the *product name* "Axiom" is a real-world word, but the codebase's own attribution to *Pixar's* Axiom is the smoking gun) |
| 15 | **Pixar yellow** (`#FFC107`) + **cyan-glow** (`#00BCD4`) palette | Color codes themselves aren't ownable, but combined with the silhouette + name they reinforce the Pixar reading. | 1 | 1 | — | **LOW** (color alone isn't actionable; it's a contributing signal) |
| 16 | **Explicit Pixar attribution prose** ("agents are named after robots from Pixar's WALL-E") | Three docs commit to the lineage in writing. This *is* the strongest evidence for "deliberate use of Disney IP." | 2 PRDs (axiom + neutron) | — | a few working/ docs | **HIGHEST** — converts inadvertent-influence defense into admitted derivation |
| 17 | **`walle` and `wall-e` PyPI console-script aliases** | `pyproject.toml` registers both as binary names. Anyone running `pip show axi-platform` sees `wall-e` as a top-level command. | 1 | — | — | **HIGH** (binary-name registration in a public package) |

#### Distribution by tier (rough totals, deduplicated)

| Tier | Distinct files | Notes |
|---|---|---|
| **TIER A — public/customer-facing** | ~9 | `axiom/README.md`, `axiom/pyproject.toml`, `axiom/AGENTS.md`, `axiom/MANUAL_TEST.md`, `axiom/src/axiom/axiom_cli.py` (banner), `axiom/src/axiom/setup/renderer.py` (setup wizard mascot), `axiom/src/axiom/extensions/builtins/chat/fullscreen.py` (chat welcome), `Neutron_OS/README.md`, `Neutron_OS/CLAUDE.md`. PyPI metadata is the highest-leverage of these. |
| **TIER B — open-source code identifiers** | ~70 | Persona files (`agents/*/persona.md`), agent module dirs (`wall_e/`, `eve/`, `m_o/`, `burn_e/`, `pr_t/`, `d_fib/`, `chalke/`, `curi_o/`, `v_ega/`), `axiom-extension.toml` manifests, agent-CLI registrations (`axi mo`, `axi burn-e`, `axi d-fib`, `axi pub`, `axi signal`, `axi research`), test files validating the personas/registrations, internal AGENT.md / SKILLS.md files. Visible to anyone reading the source on GitHub. |
| **TIER C — internal docs only** | ~280 | ADRs, working/ session docs, papers/, glossaries, requirements PRDs in `Neutron_OS/docs/requirements/`, fixture tests, working agent-framework analyses. Important caveat: **all `docs/` material in `axiom/` is public** because the GitHub repo hosts the docs tree. So practically only ADRs+specs+working that we keep in `axiom-aeos-tests/` worktree (private?) and `.claude/` are truly internal. The PRD set in `axiom/docs/prds/` is in the public repo. |

> **Caveat on the TIER C count.** Many of the docs I've classified as TIER C
> (`axiom/docs/prds/*.md`, `axiom/docs/working/*.md`) are committed to a public
> GitHub repository. They aren't on PyPI / not in the README, but anyone
> browsing the repo sees them. If `axiom` is fully open-source, all 280 of
> those become TIER A-adjacent. **Open question for Ben: which `docs/` paths
> are private vs public?** Adjust the audit accordingly.

### 1.3 Spot-checked verbatim strings (the "smoking guns")

These are the strings I'd quote if I were writing an enforcement letter. Each
is exact-text from the current source.

**A. Explicit Pixar attribution — `axiom/docs/prds/prd-axi-cli.md:424`** (public PRD):

> Axiom agents are named after robots from Pixar's WALL-E — a film about a
> world made uninhabitable by environmental neglect. The irony is intentional:
> Axiom is in service of clean systems, sustainable practice, and durable
> knowledge.

**B. Explicit Pixar attribution — `axiom/docs/prds/prd-agents.md:15`** (public PRD):

> Axiom agents are named after robots from Pixar's WALL-E — a film about a
> world made uninhabitable by environmental neglect. … Our agents work
> tirelessly to keep operations facilities running safely, just as WALL-E's
> robots maintain the Axiom.

**C. Explicit Pixar attribution — `Neutron_OS/docs/requirements/prd-executive.md:97`** (NeutronOS PRD):

> NeutronOS agents are named after robots from Pixar's WALL-E — a film about
> a world made uninhabitable by environmental neglect…

**D. Pixar character mapping — `Neutron_OS/docs/requirements/prd-neut-cli.md:51-57`** (a literal table mapping our agent names to Pixar character types):

> | Neut (WALL-E) | WALL-E | … |
> | EVE | Probe droid | … |
> | M-O | Cleaning robot | … |
> | PR-T | Beauty bot | … |
> | D-FIB | Medical bot | … |
> | BURN-E | Welder bot | … |

**E. PyPI binary aliases — `axiom/pyproject.toml:107-113`**:

```toml
walle = "axiom.axiom_cli:main"
"wall-e" = "axiom.axiom_cli:main"
# WALL-E aliases — humans address the orchestrator agent by character
# name as well as the tool name.  `walle` is the canonical hyphenless
# form (no shell-quoting needed); `wall-e` matches the Pixar spelling.
```

**F. Banner code self-describing the visual derivation — `axiom/src/axiom/axiom_cli.py:885-895`**:

> WALL-E character — give him his actual anatomy: 1. Two SEPARATE binocular
> eye-housings (Pixar's most iconic detail …). … "Pixar WALL-E anatomy —
> designed against the reference photo."

**G. Verbatim dialog — `axiom/src/axiom/axiom_cli.py:976`**:

> ```python
> l2.append("Directive: ", style="italic bright_yellow")
> l2.append("assist.", style="bold bright_green")
> ```

**H. The iconic `WALL•E` red-bullet logotype — `axiom/src/axiom/axiom_cli.py:962-968`**:

> ```python
> def _walle_word() -> Text:
>     """The Pixar-canon "WALL•E" with the iconic red bullet."""
>     t = Text()
>     t.append("WALL", style="bold #FFC107")  # Pixar yellow
>     t.append("•", style="bold red")          # red bullet
>     t.append("E", style="bold #FFC107")
> ```

**I. Starliner attribution — `axiom/src/axiom/setup/renderer.py:123`**:

> Axi is the Axiom ship's voice — the default orchestrator when no domain
> agent is registered. She is named for the WALL-E Axiom luxury starliner.

**J. README public agent listing — `axiom/README.md:33`**:

> `Agents: EVE (signals) | M-O (steward) | PR-T (publisher) | BURN-E (releases) | DFIB (diagnostics)`

### 1.4 Risk-summary diagram

```mermaid
flowchart TD
    classDef tierA fill:#FCD9CD,color:#7A1F0E,stroke:#7A1F0E,stroke-width:2px
    classDef tierB fill:#FFE9B0,color:#5C4500,stroke:#5C4500,stroke-width:2px
    classDef tierC fill:#D9E8FB,color:#0D2A55,stroke:#0D2A55,stroke-width:1px
    classDef root fill:#1F2937,color:#F9FAFB,stroke:#F9FAFB,stroke-width:2px

    R[Pixar IP exposure surface]:::root

    A[TIER A · public-facing]:::tierA
    B[TIER B · OSS code identifiers]:::tierB
    C[TIER C · internal docs]:::tierC

    R --> A
    R --> B
    R --> C

    A --> A1[PyPI walle / wall-e console scripts]:::tierA
    A --> A2[axi --help banner ASCII + WALL•E logotype + Directive line]:::tierA
    A --> A3[axi chat welcome mascot]:::tierA
    A --> A4[axi config / setup wizard mascot]:::tierA
    A --> A5[README Agents line · PRDs with explicit Pixar attribution]:::tierA

    B --> B1[Agent module dirs · wall_e/ eve/ m_o/ burn_e/ pr_t/ d_fib/]:::tierB
    B --> B2[Persona.md files · explicit film analogies]:::tierB
    B --> B3[CLI nouns · axi mo · axi burn-e · axi d-fib · axi pub · axi signal]:::tierB
    B --> B4[Extension manifests · name=eve · name=chalke]:::tierB
    B --> B5[Test files asserting persona content]:::tierB

    C --> C1[ADRs · specs · working session docs]:::tierC
    C --> C2[NeutronOS docs/requirements/*.md]:::tierC
    C --> C3[Glossaries · papers · CLAUDE.md memory]:::tierC
```

### 1.5 Disney's enforcement posture (general-knowledge framing, not legal advice)

For the user's situational awareness, Disney is generally regarded as one of
the more aggressive enforcers in entertainment IP. Common patterns:

- They do go after software / dev-tool projects that use distinctive
  character names, logotypes, or visuals (e.g. historic actions against
  fan-projects, schools, daycares with murals, etc.). Costuming, naming, and
  *explicit attribution* tend to weigh against the user.
- Trademark, copyright, and trade-dress claims are layered: WALL-E itself is
  a registered trademark (USPTO TESS, multiple classes including Class 9 –
  software/electronics, per public records); the *character design* is
  copyrighted; the **logotype** (`WALL•E` with red bullet) is itself part of
  registered marks.
- In practice, the open-source / non-commercial argument has limited weight
  when the project (a) is distributed via a registered package index,
  (b) explicitly attributes to Pixar in committed prose, and (c) reproduces
  the logotype/character silhouette.
- Counter-mitigation has historically been: rename, replace assets, take
  down the artifacts, post a brief acknowledgment, and don't fight it.
  Most projects never receive a takedown and quietly migrate; some do.

**Implication for our risk model:** the calculus is less "are we likely to
be sued" and more "if Disney noticed and sent a polite request, would we
swap it inside 30 days?" — and the answer is yes, so the work is to make
that swap pre-staged and low-pain.

---

## 2. RENAMING PROPOSAL

### 2.1 Constraints recap (Ben's conventions)

- ALL-CAPS-HYPHEN, short, two-syllable rhythm preferred.
- Function-conveying.
- Not a Pixar/Disney/major-studio mascot.
- Avoid obvious other-company-agent collisions (no "JARVIS" — Marvel/Disney;
  no "ALEXA" — Amazon; no "CORTANA" — Microsoft / Halo; no "FRIDAY" — Marvel;
  no "ULTRON" — Marvel; no "BAYMAX" — Disney; no "EVA" too close to EVE).
- Coexist with product names in prose (the casing distinction is the tell).

### 2.2 Per-agent candidates

For each, I give 2–3 options with one-line rationale + one-line "why-not".
Numbers in parentheses are subjective vibe scores (mine, not Ben's). Final
pick is Ben's.

#### Loop / orchestrator (currently **WALL-E**) — *the protagonist*

| Candidate | Rationale | Why-not |
|---|---|---|
| **NOVA** | Latin "new"; bright, optimistic, evokes a guide-star; common-vocabulary so no single-owner TM. Matches "Axiom" cosmic theme. | Used as a brand element in many places (Vivaldi browser themes, Nova Launcher, Cosmos, plus a NASA NOVA mission). Generic enough to share, but check trademark in software-agent class. |
| **NEMO** | Short, ALL-CAPS, easy to address as `@nemo`. Latin "no-one", evokes the small + curious + observant character. | **REJECT** — Pixar's *Finding Nemo* is one of their best-known properties. Same problem we're solving. |
| **HELM** | Function-y: a helm steers; the orchestrator steers the agent fleet. Short, single-syllable, distinctive. | Helm is a well-known Kubernetes CLI; could confuse infrastructure-savvy users. |
| **PILOT** | Same metaphor — pilots a fleet. Direct functional read. | Generic enough to be dilutive; "pilot project / pilot mode" is everyday vocab. |

#### Read / signal (currently **EVE**)

| Candidate | Rationale | Why-not |
|---|---|---|
| **SCAN** | Direct functional verb — what the agent does is scan event streams. Clean ALL-CAPS read. | Maybe too literal / not enough character; "scan" is plain noun. |
| **WATCH** | "Watcher" is canonical for event-detection systems (Kubernetes watchers, Apache Watch, etc). | Possibly trademark-collision-prone (Apple Watch, Watch OS). Avoid. |
| **HARK** | Old-English "to listen carefully" — short, distinctive, ALL-CAPS works. | Obscure, may not parse for non-English-native operators. |
| **PULSE** | Evokes heartbeat/event detection; warmer than SCAN. | "Pulse" already names a few products (LinkedIn Pulse, Audi Pulse, etc.) but never as an agent — usable. |

#### Steward / hygiene (currently **M-O**)

| Candidate | Rationale | Why-not |
|---|---|---|
| **TIDY** | "Tidy up" maps directly to the agent's compulsive-cleaning function. ALL-CAPS-TIDY reads as a name. | Sounds slightly cute; less serious than M-O's defibrillator-cousin gravitas. |
| **STEW** | "Steward" abbreviation; clean ALL-CAPS. | "STEW" reads as the food. Probably no. |
| **SWEEP** | Functional verb, evokes a janitor agent. | Sweep is also a cryptocurrency project and a common verb in many tools. |
| **CURATE** | Steward-sense, hygiene-sense, plus "curate the corpus" overlaps with M-O's cohort-pack distribution. | Long for ALL-CAPS naming; less crisp than TIDY. |

#### Releases / CI/CD (currently **BURN-E**)

| Candidate | Rationale | Why-not |
|---|---|---|
| **FORGE** | Welder/ironworker metaphor preserved; short, distinctive, ALL-CAPS-friendly. | "Forge" is everywhere in dev tooling (SourceForge, Forge mod loader, GitForge, etc.); generic. |
| **WELDR** | Direct welder reference, single syllable. | Awkward orthography. |
| **TAGGER** | What BURN-E literally does — tags and ships. | Too generic / verb-y. |
| **SMITH** | Blacksmith metaphor; clean ALL-CAPS. | Common surname, common library name. |

#### Diagnostics / security (currently **D-FIB**)

| Candidate | Rationale | Why-not |
|---|---|---|
| **MEDIC** | Healthcare metaphor preserved without the defibrillator pun. ALL-CAPS-MEDIC parses cleanly. | Common-vocabulary; could collide with TF2 Medic class. |
| **VITAL** | Health-monitoring vibe; works as agent name. | Slightly generic, also a common medical-software brand. |
| **SCOPE** | "Stethoscope" + "scope of audit"; dual-meaning fits diagnostics + security. | Many existing tools called Scope (Chronosphere, observability vendors). |
| **PROBE** | Health-probe + security-probe (Kubernetes vocabulary already). | "Probe" is the Pixar word for EVE's role in PRDs ("Probe droid"); irony on irony. |

#### Publisher / content gate (currently **PR-T**)

| Candidate | Rationale | Why-not |
|---|---|---|
| **PRESS** | Printing-press metaphor; literal "press a button to publish". | "PRESS" as ALL-CAPS could read as a verb in chat ("PRESS published the doc"). |
| **PRINT** | Even more literal, maps to the REPL "Print" role exactly. | Too generic / collides with Python `print()` semantics in dev contexts. |
| **TYPE** | Typesetter metaphor; short and clean. | Conflicts with `type` keyword & verb. Avoid. |
| **HERALD** | Old-fashioned "messenger who announces". Short, distinctive. | Slightly archaic. |

#### Research / eval (currently **CURI-O**)

| Candidate | Rationale | Why-not |
|---|---|---|
| **SAGE** | Wisdom + research; ALL-CAPS-SAGE reads beautifully; common-vocabulary, no Pixar tie. | "Sage" is a well-known accounting-software brand. Check TM in software-agent class. |
| **LORE** | Knowledge-keeper metaphor, four letters. | "LORE" is the name of Star Trek TNG's evil android — minor-but-real conflict. |
| **DELVE** | Deep-research verb — what CURI-O does. | Possibly cliché ("delve into"). |
| **KEEP CURI-O** | Original coinage; only liability is the persona's "WALL-E's curiosity" prose. **Rewrite the persona** to drop the WALL-E reference and CURI-O is probably retainable. | The Pixar-style phonetic structure (CURI-O echoes M-O / WALL-E) keeps it visually in the family. Trade-off: cheap to keep but doesn't fully de-Pixar the brand. |

#### Classroom orchestrator (currently **CHALK-E**)

| Candidate | Rationale | Why-not |
|---|---|---|
| **TUTOR** | Direct functional read; ALL-CAPS-TUTOR works. | Generic; many products are called Tutor. |
| **SCHOLA** | Latin "school"; short, distinctive, compatible with the Keplo/cosmic theme. | Less crisp than TUTOR. |
| **LECT** | "Lecture" abbrev; very short. | Sounds like "elect / select". Avoid. |
| **KEEP CHALK-E** | Original coinage; only liability is the persona's "WALL-E-family animated co-worker" line. **Rewrite the persona** and CHALK-E is probably retainable. | Same trade-off as CURI-O — cheap to keep, doesn't fully de-Pixar. |

#### Federation / governance (currently **V-EGA**)

V-EGA is named after the Vega product (UT-owned, federation/governance
layer). **Recommendation: keep as-is.** No Pixar tie. The only thing to
verify is no third-party "VEGA" software-agent trademark collides — TESS
search recommended pre-launch.

### 2.3 "Lead" candidate set (one coherent reading)

A naming set is more than the sum of its agents: the team-name vibe should
feel cohesive. Here is a candidate **set** — *not* a recommendation, just
one self-consistent reading for Ben to react to.

| Role | Today | Lead candidate | Alt |
|---|---|---|---|
| Loop / orchestrator | WALL-E | **NOVA** | HELM, PILOT |
| Read / signal | EVE | **SCAN** | PULSE, HARK |
| Steward / hygiene | M-O | **TIDY** | SWEEP, CURATE |
| Releases / CI | BURN-E | **FORGE** | SMITH, TAGGER |
| Diagnostics / security | D-FIB | **MEDIC** | VITAL, SCOPE |
| Publisher | PR-T | **PRESS** | HERALD |
| Research / eval | CURI-O | **SAGE** *or keep* | DELVE |
| Classroom | CHALK-E | **TUTOR** *or keep* | SCHOLA |
| Federation | V-EGA | **keep** | — |

**Coherence read:** NOVA (orchestrator) routes work to a fleet of common-noun
function agents (SCAN, TIDY, FORGE, MEDIC, PRESS) — a "function-named team"
pattern, which is closer to AWS service naming than Pixar character naming.
Cosmic / classical accents (NOVA, SAGE) replace the Pixar vibe with a
"observatory + scribes" theme that overlaps better with **Vega** (star),
**Keplo** (Kepler), **Axiom** (math/space) than the current set does.

The trade-off is loss of *character*: the current names are loved because
they *are* characters. NOVA / SCAN / TIDY are *functions*. If keeping a
character feel matters, the alts list (HELM, PULSE, SWEEP, SMITH, SCOPE,
HERALD, DELVE) leans more name-like.

### 2.4 Trademark sanity (NOT legal advice)

Before committing any of the above, run a USPTO TESS search for each
candidate in software / agent / cloud-services classes (typically Class 9,
42). Quick rule of thumb based on common knowledge:

- **NOVA** — many uses; verify nothing in autonomous-agent-software class.
- **SCAN, TIDY, FORGE, MEDIC, PRESS** — generic-vocabulary; widespread uses
  but rarely as character-style agent names. Likely clear in agent-class.
- **SAGE** — well-known accounting-software brand. **Higher collision
  risk** than the others.
- **HELM** — already a CNCF/Kubernetes project. Avoid for an agent name even
  if not TM-blocked.
- **HERALD** — relatively underused in software, likely clear.

**Recommendation:** when Ben picks the final set, run formal TESS searches
+ DuckDuckGo / GitHub / PyPI pre-existing-name searches before committing.
This is a one-day task, not blocking the proposal.

---

## 3. VISUAL REDESIGN OPTIONS

The current ASCII art is `_AXI_ART_LINES` in `setup/renderer.py` (13 rows ×
19 cols, pure-ASCII variant) and `art_lines` in `axiom_cli.py` (14 rows × 19
cols, Unicode box-drawing variant). All three replacements below sit in the
same envelope and use the existing color slots (head/body/accent/tread).

### Option A — Geometric-modular robot ("the engineer")

Generic boxy robot, antenna instead of binocular eye stalks, no claws — a
"PCB-and-drawing" feel rather than a tracked trash compactor. Reads as
"AI agent" without any film-derivation cues.

```
   ┌─/\─┐    ┌─/\─┐
   │ ◆  │    │  ◆ │
   └────┘    └────┘
        \    /
       ┌─┴──┴─┐
       │      │
       │ ★◆★  │
       │      │
       └──┬┬──┘
          ││
       ▭══╧╧══▭
```

- Eyes → diamond/square sensors (no binoculars).
- Antenna stalks → engineer/IoT vibe.
- Body → square frame, optional brand glyph (`★◆★`).
- Base → wheels (`▭`) instead of tank treads.
- Color slots map directly: frame → bright_white, body → brand color (e.g.
  burnt-orange `#BF5700` per axiom-labs-brand if Ben wants a UT-color nod, or
  brand-blue `#00CFFF` per `_Colors.ACCENT_BLUE`).

**Pros:** clean, trademark-free, easy to re-color per brand.
**Cons:** less character-y; harder to fall in love with.

### Option B — Federation-node silhouette ("the constellation")

Lean into Axiom's federation theme — the mascot *is* the network. A central
node with peer links rendered as a small constellation. Pure-abstract,
zero-character-likeness exposure.

```
       ◆
      /|\
     / | \
    ◇  |  ◇
    |  ●  |
    ◇  |  ◇
     \ | /
      \|/
       ◆
       │
   ═══╧═══
```

- Central `●` is the home node, `◇` and `◆` are peers (4-corner topology).
- Lines are A2A protocol edges.
- Base is a single platform bar (`═══╧═══`) — anchors to the terminal
  baseline.
- Color: home node = brand-accent; peers = grey70; lines = bright_white.

**Pros:** literally communicates Axiom's value proposition (federation /
trust graph). Brand-aligned. Total zero IP exposure.
**Cons:** doesn't read as "AI assistant" — reads as "network diagram." The
`Hi, I'm <name>` welcome line feels weirder addressed to a constellation.

### Option C — Owl-or-fox steward ("the night librarian")

Animal-ish minimal silhouette — owl or fox. Conveys watchfulness +
intelligence without robot-character cues. Used by GitHub (octocat),
Mozilla, GitLab (tanuki), Mastodon (elephant) — the "company animal mascot"
pattern is well-trodden and IP-safe.

```
      _,---,_
     /( @ @)\
    (  >|||<  )
     \  ---  /
      \\___//
       |   |
       /   \
      /     \
   __/       \__
```

- Two `@` glyphs as bright eyes (cyan accent OK).
- Beak `>|||<` as accent stripe.
- Body silhouette in body-color slot.
- Optional: ear tufts `_,---,_` keep the owl read; remove to make it
  more cat/fox.

**Pros:** warm, character-y, easy to talk to; total IP independence; could
become a real mascot the team could illustrate later (poster art, swag).
**Cons:** anthropomorphism level shifts (people relate to animals
differently than robots — some find it cute, some find it twee).
Unicode `@` may render with variable width on some terminals — needs a
sub-test.

### Visual-direction tradeoff diagram

```mermaid
flowchart TD
    classDef pick fill:#FFE9B0,color:#5C4500,stroke:#5C4500,stroke-width:2px
    classDef option fill:#D9E8FB,color:#0D2A55,stroke:#0D2A55,stroke-width:1px
    classDef axis fill:#F1E6FF,color:#3D1A6B,stroke:#3D1A6B,stroke-width:1px
    classDef root fill:#1F2937,color:#F9FAFB,stroke:#F9FAFB,stroke-width:2px

    R[Mascot direction]:::root
    R --> X1[Axis: character warmth]:::axis
    R --> X2[Axis: brand alignment]:::axis
    R --> X3[Axis: IP independence]:::axis

    X1 --> A[Option A · geometric robot]:::option
    X1 --> B[Option B · federation node]:::option
    X1 --> C[Option C · animal steward]:::option

    A -.character: medium.-> P[Pick by Ben]:::pick
    B -.character: low.-> P
    C -.character: high.-> P

    A -.brand: medium - generic.-> P
    B -.brand: high - on-thesis.-> P
    C -.brand: medium - illustration potential.-> P

    A -.IP: clear.-> P
    B -.IP: clear.-> P
    C -.IP: clear.-> P
```

### Notes on banner copy (independent of mascot pick)

- **"Directive: assist."** must come out (verbatim film dialog). Replace with
  e.g. "Ready when you are." / "How can I help?" / "I'm at your service." /
  "Ask me anything." — pick a tone matching the agent's new persona.
- **"Welcome aboard the Axiom"** — `Axiom` is fine as a product name (it's a
  real-word noun); but the *"aboard the"* phrasing reads as the spaceship
  framing. Soften to "Welcome to Axiom." or just the mascot-name line.
- **"I'm <name>. Directive: assist."** — keep the introduction pattern, drop
  the directive verbatim.

---

## 4. PHASING + SCOPE

### 4.1 Foundation-during-delivery freeze

Per `feedback_freeze_foundation_during_delivery.md`, no
repo/CI/brand restructuring lands while Ben is shipping toward Prague. This
proposal **respects that freeze**: implementation is post-Prague. The
freeze does *not* cover root-cause fixes for live incidents
(`feedback_no_prague_as_delay_excuse.md`), but a Pixar-IP rename is *not* a
live incident — it's planned hygiene.

**One exception worth flagging:** if Ben wants to ship the *attribution
removal* alone (drop the "named after robots from Pixar's WALL-E" prose
and the `Pixar-canon` source comments) without renaming anything, that is
a near-zero-risk doc-only diff that closes the strongest single piece of
evidence. ~1 hour of work, no test impact, no UX impact. Ben may want
that even pre-Prague.

### 4.2 Three-phase plan

```mermaid
flowchart TD
    classDef pre fill:#D9F1D9,color:#1A5A1A,stroke:#1A5A1A,stroke-width:2px
    classDef now fill:#FFE9B0,color:#5C4500,stroke:#5C4500,stroke-width:2px
    classDef post fill:#FCD9CD,color:#7A1F0E,stroke:#7A1F0E,stroke-width:2px
    classDef gate fill:#1F2937,color:#F9FAFB,stroke:#F9FAFB,stroke-width:2px

    P0[Phase 0 · pre-Prague non-blocking]:::pre
    P0 --> P0a[This proposal · Ben review]:::pre
    P0 --> P0b[Optional: drop explicit Pixar-attribution prose · 1 hour]:::pre
    P0 --> P0c[Reserve replacement names · TESS check]:::pre

    G1{Prague go-live · 2026-06}:::gate
    P0 --> G1
    G1 --> P1[Phase 1 · post-Prague rename PR]:::now

    P1 --> P1a[Land replacement names · single big PR]:::now
    P1 --> P1b[Replace ASCII mascot · banner · chat · setup]:::now
    P1 --> P1c[Update README · PRDs · personas]:::now
    P1 --> P1d[Drop walle / wall-e console-script aliases]:::now
    P1 --> P1e[Add deprecation aliases · old name warns and redirects]:::now

    P1 --> P2[Phase 2 · alias sunset]:::post
    P2 --> P2a[Two minor versions later · remove deprecation aliases]:::post
    P2 --> P2b[Scrub TIER C internal docs · gradual]:::post
    P2 --> P2c[Memory files · separate decision · §5]:::post
```

### 4.3 Rip-the-band-aid vs gradual

| Option | Description | Effort | Risk |
|---|---|---|---|
| **Rip the band-aid** | One PR renames every TIER A + TIER B surface, replaces the mascot, drops the PyPI aliases, ships in v0.11 (or whatever post-Prague major). Old names hard-fail with a "migrated" message pointing to the new name. | ~3–5 days of focused work (most is mechanical sed-and-test; ~70 files but mostly straightforward). Plus 1 day of mascot-art iteration. | Low risk. The CI suite should catch breakage; tests reference the persona content directly so they'll need updating. |
| **Gradual deprecation** | New names ship alongside old in v0.11; both work; old names emit a `DeprecationWarning`. Old names removed in v0.13 (~2 minor versions later). | ~3–5 days for the alias work + ~1 day each subsequent version to track removal. | Lower-immediate-risk because nothing breaks; **higher cumulative risk** because Disney-attribution prose and the PyPI `wall-e` binary stay in the public package for ~2 release cycles. |
| **Hybrid (recommended)** | Rip-band-aid the **public surfaces** (banner, mascot, README, PyPI aliases, attribution prose, PRDs) all at once. Allow **internal-API aliases** (Python class names, registry keys) to deprecate gracefully so extension authors can migrate. | ~3–4 days. | Closes the public IP exposure fast while not breaking downstream extensions. |

**My recommendation (for Ben to approve/reject):** Hybrid. The PyPI binary
aliases + banner + attribution prose are the highest-leverage surfaces; they
should die in one PR. Internal class-name aliases (`WallEAgent → NovaAgent`)
can deprecate cleanly per Python's normal alias pattern.

### 4.4 Effort estimates

| Workstream | Days | Notes |
|---|---|---|
| Drop attribution prose only (pre-Prague optional) | 0.25 | Find/replace in 5–6 files; no test impact |
| Decide candidate names + run TESS searches | 1 | Manual TESS + DuckDuckGo + PyPI search |
| Single rename PR (TIER A + most of TIER B) | 3 | Includes test fixture updates, persona rewrites, banner, mascot replacement, console-script changes |
| Mascot ASCII iteration to taste | 1 | Likely takes 2–3 rounds with Ben |
| NeutronOS-side mirror update | 0.5 | Smaller surface; same approach |
| Memory / `.claude` / TIER C scrub (deferred) | 1–2 | Optional cleanup later |
| **Total to fully de-Pixar publicly** | **~5–6 days** | |

### 4.5 What CAN ship at any time (non-blocking)

- This proposal doc itself (no code change).
- ADR draft documenting the rename rationale, kept in `docs/working/` until
  approved.
- Optional: a single-commit "drop explicit Pixar attribution prose" PR. ~1
  hour. Closes the most damning evidence without touching naming.

### 4.6 What waits for post-Prague

- Console-script renames (would surprise Prague users mid-cohort).
- README rewrite (ditto).
- Mascot replacement (ditto).
- All persona file rewrites.
- PRD rewrites.

### 4.7 What is "fix immediately" only if escalated

- If Disney/Pixar IP counsel reaches out, all of Phase 1 collapses into "do
  it this week." Ben should have the candidate names + TESS results staged
  before that hypothetical so we're not scrambling.

---

## 5. OPEN QUESTIONS for Ben

1. **Scope of brand vs scope of agents:**
   "Axiom" is a real-world word and the codebase's product brand. Do we
   keep the **product name** "Axiom" (which has its own *separate* trademark
   considerations as a common-vocabulary word) and only rename the *agents*?
   Or does Ben want a fuller brand re-look while we're at it?
   The codebase currently *attributes* "Axiom" to "the WALL-E luxury
   starliner" in `setup/renderer.py:123` — at minimum, that comment has
   to go regardless of the product-name decision.

2. **Memory / `.claude` / internal docs scrub:**
   The auto-memory directory (`/Users/ben/.claude/projects/...`) and
   `axiom-aeos-tests/` worktree contain hundreds of WALL-E references in
   private context. Three options:
     (a) leave them (they're not shipped),
     (b) scrub for consistency,
     (c) scrub only the things that might leak (e.g. anything copied into
       commit messages or AI-generated PR bodies).
   Recommendation: (c) — scrub *outputs* that might leak; leave private
   notes alone.

3. **Backwards-compat alias behavior on `axi`:**
   When a user types `axi mo health` after rename to `axi tidy health`, do
   they get:
     (a) a 404 "no such command" with a "did you mean tidy?" hint?
     (b) the command runs with a deprecation warning routed to stderr?
     (c) full silent transparent alias for N versions?
   Pre-public-launch we have `feedback_no_backward_compat_shims.md`
   (no shims, refactor cleanly). This argues for (a) — but (a) breaks
   any cohort docs, course materials, AI-generated transcripts already
   using the old verbs. **Lean (b) for two minor versions, then (a).**

4. **Prague pitch / instructor-facing materials:**
   Ben has been pitching Keplo + Axiom to Prague stakeholders. Is the
   current naming in the pitch deck (slides, syllabus, classroom
   onboarding email)? If so, we either (a) ship rename before the cohort
   starts (probably won't fit), or (b) accept that early-cohort docs use
   names that will change in v0.11+; confirmation deprecations protect
   continuity. **Need from Ben:** a list of Prague-bound materials
   currently using the names so the cohort transition can be smoothed.

5. **IP counsel engagement:**
   Does Ben want a formal trademark clearance check on the candidate
   replacement names before committing? (i.e., engage UT's general
   counsel or a B-Tree-Labs-retained attorney for a USPTO TESS sweep
   of the final set.) Cost: typically a few hundred to a thousand
   dollars for a screening; non-blocking but de-risks the v0.11 PR.

6. **Public announcement framing:**
   When the rename ships, do we (a) say nothing in the changelog (just
   "renamed agents X→Y"), (b) acknowledge the IP-hygiene reason candidly,
   or (c) frame it as a positive rebrand around function-named agents?
   Recommendation: (c). It's the truthful framing if the new naming is
   genuinely better, and avoids inviting more scrutiny.

7. **CHALK-E and CURI-O specifically — keep or replace?**
   These are *original coinages*, not direct Pixar character names. Their
   Pixar-derivation liability is in the **persona prose** ("WALL-E-family
   animated co-worker", "embodies WALL-E's curiosity"). If we rewrite the
   persona files to drop those references, the names themselves are
   probably retainable. **Keeping them costs a persona rewrite (~1 hour
   each); replacing them costs full rename overhead.** Ben's call.

8. **V-EGA stays — but worth one TESS sanity check.**
   No Pixar tie. Only verify there is no third-party "VEGA" software-agent
   trademark in Class 9 / 42 before any external launch.

9. **Branding on Apple Developer ID + macOS code-signing:**
   Per `feedback_must_codesign_macos_binaries.md`, post-Prague we will
   sign macOS binaries with an Apple Developer ID. The binary names
   (`axi`, `axiom`, `walle`, `wall-e`) appear in the signed manifest. The
   `walle` and `wall-e` aliases should drop *before* the first signed
   release, or they end up in the Apple-attestation chain.

10. **NeutronOS coordination:**
    NeutronOS has its own copy of these PRDs in `Neutron_OS/docs/requirements/`.
    Per `project_neutronos_tracks_latest_axiom_in_dev.md`, NeutronOS
    auto-bumps Axiom pin per release. Either (a) the rename PR ships in
    Axiom and NeutronOS picks it up automatically + we hand-update its
    own PRDs, or (b) we land both repos in lock-step. (a) is simpler.

---

## 6. Appendix — Inventory artifacts

### 6.1 Top-priority files for the rename PR (TIER A first, then TIER B)

```
TIER A (must change in the rename PR):
  axiom/pyproject.toml                                 console-scripts walle, wall-e
  axiom/README.md                                      agent listings, banner narrative
  axiom/AGENTS.md                                      naming-convention paragraph
  axiom/MANUAL_TEST.md                                 example agent IDs
  axiom/src/axiom/axiom_cli.py                         banner art + WALL•E logotype + Directive line
  axiom/src/axiom/setup/renderer.py                    setup-wizard mascot + starliner attribution
  axiom/src/axiom/extensions/builtins/chat/fullscreen.py mini-mascot in chat welcome
  axiom/docs/prds/prd-axi-cli.md                       §The Agent Team — explicit Pixar attribution
  axiom/docs/prds/prd-agents.md                        §Agent Names — explicit Pixar attribution
  axiom/docs/prds/prd-executive.md                     §Agent Names — explicit Pixar attribution
  Neutron_OS/README.md                                 agent dir listing
  Neutron_OS/docs/requirements/prd-executive.md        explicit Pixar attribution
  Neutron_OS/docs/requirements/prd-neut-cli.md         table mapping agents to Pixar character types
  Neutron_OS/docs/requirements/prd-agents.md           agent table
  Neutron_OS/docs/glossary.md                          REPL definition citing WALL-E

TIER B (rename together, agent-by-agent):
  axiom/src/axiom/extensions/builtins/chat/agents/wall_e/         persona + tests + agent regn
  axiom/src/axiom/extensions/builtins/signals/agents/eve/         persona, AGENT.md, manifest name
  axiom/src/axiom/extensions/builtins/hygiene/agents/m_o/         persona + repo_hygiene + AGENT.md
  axiom/src/axiom/extensions/builtins/release/agents/burn_e/      persona + agent_cli (axi burn-e)
  axiom/src/axiom/extensions/builtins/diagnostics/agents/d_fib/   persona + AGENT.md
  axiom/src/axiom/extensions/builtins/publishing/agents/pr_t/     persona + AGENT.md + axi pub
  axiom/src/axiom/extensions/builtins/research/agents/curi_o/     persona (decision: keep name?)
  axiom/src/axiom/extensions/builtins/classroom/agents/chalke/    persona (decision: keep name?)
  axiom/src/axiom/extensions/builtins/federation/agents/v_ega/    safe — only verify TM
  axiom/src/axiom/agents/base_agent.py                            ALL_KNOWN_AGENTS registry
  axiom/src/axiom/agents/learning.py                              agent reference list
  axiom/src/axiom/agents/skills_runtime.py                        registered-agent enum
  axiom/src/axiom/policy/engine.py                                agent allow/deny set
  axiom/src/axiom/policy/__init__.py                              ALL_AGENTS constant
  axiom/src/axiom/extensions/builtins/{*/AGENT.md, */SKILLS.md}   ~12 files reference agent names
  Neutron_OS/src/.../{eve,mo,prt,dfib,burn_e}_agent/              if mirrored

TIER C (post-Prague gradual; not blocking the rename PR):
  axiom/docs/working/* (~30 files)
  axiom/docs/specs/* (~20 files)
  axiom/docs/adrs/adr-034, adr-035, adr-037 (~6 files)
  axiom/docs/papers/* (occasional refs)
  axiom/tests/* (~15 files reference the agent names)
  Neutron_OS/docs/working/* (~5 files)
  axiom-aeos-tests/* worktree mirror — auto-syncs from axiom/
```

### 6.2 Files NOT touched (verified clean)

- `dendra/` — entire repo: zero hits. No remediation needed.
- `axiom/src/axiom/memory/`, `identity/`, `vega/`, `infra/`, `rag/`,
  `medallion/`, `graph/`, `findings/`, `evals/` — only incidental
  string-fixture refs (test data); not load-bearing.

### 6.3 Suggested ADR-template for Phase 1

When the freeze lifts, file `docs/adrs/adr-NNN-agent-rename.md`:

- **Context:** Pixar-IP exposure audit + Disney enforcement risk.
- **Decision:** Rename to `<final set>`; replace mascot per Option `<X>`;
  drop PyPI aliases; rewrite personas; remove explicit attribution.
- **Consequences:** v0.11 ships rename PR; old names deprecated for two
  minors then removed; downstream `Neutron_OS` adapts in next pin-bump;
  no functional or API changes beyond identifiers.

---

_Drafted 2026-05-04 by research agent for Ben's review. **No code or commits
made.** Feedback expected; revise per Ben's annotations before any
implementation work begins post-Prague._
