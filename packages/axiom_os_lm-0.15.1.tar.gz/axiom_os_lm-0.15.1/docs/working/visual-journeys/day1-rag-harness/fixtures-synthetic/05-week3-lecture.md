# NE-101 Prague — Week 3 Lecture Notes (Reactivity & Kinetics)

## Delayed neutrons in TRIGA designs

> *Ondrej's emphasis (recorded from Week 3 lecture):*
>
> "What students often miss about delayed neutrons is that the **effective
> delayed-neutron fraction β_eff in TRIGA designs is dominated by the
> in-fuel scattering geometry, not just the bulk yield**. The UZrH fuel
> matrix slows down the precursor decay paths in a way that's
> non-obvious — and that's what gives TRIGA its forgiving prompt response.
> When you go to a faster-spectrum design, that prompt-jump margin
> contracts; you can't carry over the intuition. Every time we teach
> kinetics I lead with this point, because if the student's mental model
> assumes 'all delayed-neutron physics looks like a thermal LWR,' they
> will mis-design when they hit a fast-spectrum problem."

## Reactivity coefficients

- **Doppler coefficient (α_D)**: prompt response to fuel temperature
  rise; negative in U-238-bearing fuels (resonance broadening increases
  capture, reduces reactivity).
- **Moderator temperature coefficient (α_M)**: response to moderator
  density change; sign depends on hardness of the spectrum.
- **Void coefficient (α_V)**: response to coolant boiling; design-
  dependent and can be positive in some BWR fuel arrangements (which is
  why we pay attention to it).

The combined sign at operating conditions determines stability — see
Lamarsh §7.3 for the formal treatment we'll work through Thursday.
