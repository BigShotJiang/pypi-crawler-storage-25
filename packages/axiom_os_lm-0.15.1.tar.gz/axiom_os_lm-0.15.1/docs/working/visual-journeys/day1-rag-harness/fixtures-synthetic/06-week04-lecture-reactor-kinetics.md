# NE-101 Prague — Week 4 Lecture: Reactor Kinetics

> *Lecture transcript, recorded by Ondrej Chvala, 2026-06-09. Edited
> for clarity by TA assistance (initials KS).*

## 4.1 Why kinetics matters operationally

Steady-state diffusion theory tells you the configuration at criticality.
**Kinetics** tells you what happens between two configurations — when a
control rod moves, when xenon builds in or burns out, when fuel
temperature rises and the Doppler coefficient kicks in. Operators don't
care about steady-state in the abstract; they care about the dynamic
response to every control action they take. This week we develop the
mathematical tools and the operational intuition together.

Recommended reading for this week: **Lamarsh, *Introduction to Nuclear
Engineering*, Chapter 7.6–7.8** for the formal treatment of point
kinetics and reactivity feedback. Duderstadt & Hamilton §6.1–6.4 covers
the same material with different notation; either is fine.

## 4.2 The point-kinetics equations

The point-kinetics equations describe a single-point reactor as if the
spatial flux distribution doesn't change shape over time:

```
dn(t)/dt = (ρ(t) − β)/Λ · n(t) + Σᵢ λᵢ · Cᵢ(t)
dCᵢ(t)/dt = (βᵢ/Λ) · n(t) − λᵢ · Cᵢ(t),     i = 1..6
```

Where:
- `n(t)` is the neutron population (or flux, suitably normalized)
- `ρ(t)` is the dynamic reactivity in dollars: ρ = (k − 1)/k, often
  expressed as ρ/β (in dollars or pcm)
- `β` = total delayed-neutron fraction; `βᵢ` per group
- `Λ` = mean neutron generation time
- `Cᵢ(t)` = precursor concentration in delayed group i
- `λᵢ` = decay constant for delayed group i (six standard groups)

For the operational regime where `|ρ| << β`, the prompt-jump
approximation gives a closed-form for the immediate-response neutron
amplitude, then the precursor terms dominate the longer-time-scale
asymptotic behavior.

## 4.3 Why TRIGA designs are forgiving

I want to underline a point that students often miss: **the effective
delayed-neutron fraction β_eff in TRIGA designs is dominated by the
in-fuel scattering geometry, not just the bulk yield.** The UZrH fuel
matrix slows down precursor decay paths in a way that's non-obvious —
and that's what gives TRIGA its forgiving prompt response.

When you go to a faster-spectrum design, that prompt-jump margin
contracts; you can't carry over the intuition. Every time we teach
kinetics I lead with this point because if the student's mental model
assumes "all delayed-neutron physics looks like a thermal LWR," they
will mis-design when they hit a fast-spectrum problem.

## 4.4 Worked example — step reactivity insertion of $0.50

Consider a TRIGA-style reactor at steady-state, with `ρ` instantaneously
stepped to +$0.50 (i.e., +0.50 β). Take β = 0.0070 and Λ = 4.0×10⁻⁵ s.

**Prompt jump:** The neutron amplitude jumps from `n₀` to
`n₀ · β/(β − ρ) = n₀ / (1 − 0.50) = 2 n₀`. So the neutron population
doubles essentially instantly (within Λ-scale times).

**Asymptotic period:** The post-jump period is governed by precursor
decay; for $0.50 reactivity in U-235-fueled systems, the asymptotic
period is on the order of **~30 s** for the first-group dominant mode.

This is the kind of step where a slow-acting alarm (period > 25 s
trip) gives the operator time to reverse the insertion. **This is also
where we transition from theory to procedure: see the PRL operations
manual §8.3 for the formal step-insertion limits and the operator
response sequence.**

## 4.5 Reading-list tie-in

| Topic | Lamarsh | Duderstadt & Hamilton |
|---|---|---|
| Point kinetics derivation | §7.6 | §6.1 |
| Six-group delayed-neutron data | §7.5 (Table 7.1) | §6.1 (Table 6-1) |
| Prompt-jump approximation | §7.7 | §6.2 |
| Reactivity feedback (next week) | §7.3 | §6.3 |

## 4.6 Office-hours focus this week

This week's office hours will heavily emphasize the **derivation step
that drops from the multigroup transport equation to the point
kinetics equations**, since past cohorts have consistently struggled
there. If you can do the derivation cleanly on the whiteboard you are
ready for the Friday checkpoint; if you can't, please come to office
hours.

— Ondrej
