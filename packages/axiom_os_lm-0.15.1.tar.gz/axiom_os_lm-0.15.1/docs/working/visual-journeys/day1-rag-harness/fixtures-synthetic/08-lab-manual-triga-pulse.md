# PRL Lab Manual — TRIGA Pulse Experiment

**Manual revision:** 2026-05-30 • **Approver:** Ondrej Chvala (course
instructor) • **Safety officer of record:** P. Stanford (RA-15M
console operator)

## L4.1 Purpose

The pulse experiment demonstrates the **prompt-jump response** of a
TRIGA-style reactor under controlled positive-reactivity insertion.
Students observe the neutron-flux time history, fuel-temperature
response, and the characteristic self-limiting behavior driven by the
prompt negative temperature coefficient of the UZrH fuel matrix.

## L4.2 Prerequisites

- Current safety briefing on file (within 12 months) — see
  **PRL-SOP-001 §3.4** for the briefing curriculum.
- Dosimetry assignment from **Console-7** (the dosimetry assignment
  station; not to be confused with **Console-3**, which is the
  reactor-bay environmental monitor).
- Successful completion of the steady-state operations module (Week 3)
  — refer to **PRL-SOP-014** for the steady-state pre-test.
- Reading: Lamarsh §7.7 and the NE-101 Week 4 lecture notes on
  point kinetics.

## L4.3 Equipment list

| Item | Identifier | Location |
|---|---|---|
| Reactor console | RA-15M | Control room |
| Pulse rod | TR-04 (transient rod) | Mounted in core position D-7 |
| Linear-power channel | LIN-A | Control-room rack 2 |
| Log-power channel | LOG-B | Control-room rack 2 |
| Period meter | PER-2 | Control-room rack 2 |
| Fuel-element thermocouple | TC-FE-22 | Instrumented element, position C-5 |
| Pulse data-acquisition module | DAQ-PRL-3 | Equipment cabinet 4 |

> *Caution: TC-FE-22 is the dedicated instrumented fuel element. Do
> not request relocation of TC-FE-22 without coordinator approval.
> The pulse data set from prior cohorts is keyed to its core-position
> C-5; relocating it invalidates cross-cohort comparison.*

## L4.4 Procedure summary

1. Verify all prerequisites in §L4.2. **The experiment will not
   commence if any prerequisite is unmet.**
2. Operator at RA-15M brings reactor to steady-state critical at 100 W
   (low-power steady-state).
3. Withdraw transient rod TR-04 to the pre-positioned bank (per the
   day's pulse-magnitude target).
4. Verify pulse target: typically $1.50 to $2.50 reactivity insertion.
   The instructor MUST approve any pulse > $2.00.
5. Initiate pulse via the "FIRE" command on RA-15M. The transient rod
   ejects pneumatically; reactivity insertion is complete in
   approximately 100 ms.
6. Pulse peak power, fuel temperature, and full time history are
   captured by DAQ-PRL-3 over a 30-second window.
7. After pulse, the reactor returns to a low-power asymptotic state
   driven by the negative temperature coefficient feedback.
8. Operator scrams from the asymptotic state; data acquisition
   continues for 5 minutes post-scram for decay analysis.

## L4.5 Expected observations (calibration target)

For a $1.50 pulse:
- Peak power: approximately **600 MW** thermal
- Pulse FWHM: **~30 ms**
- Peak fuel temperature: **~410°C** (approaching but below the
  steady-state operational max of 425°C)
- Asymptotic post-pulse power: < 1 kW within 200 ms

These values come from prior-cohort calibration runs; deviations of
> 15% on any of these should be flagged to the instructor immediately.

## L4.6 Safety violations specific to this experiment

A **three-strike policy** applies to all PRL lab work in general (see
**PRL course policies §1.2**), but for the pulse experiment specifically,
the following are **immediate Strike 3** regardless of prior history:

1. Initiating pulse without instructor present at RA-15M
2. Unauthorized request to override the $2.00 reactivity-insertion limit
3. Tampering with TC-FE-22 or relocating it without coordinator approval
4. Working without a current safety briefing on file (cross-references
   **PRL-SOP-001 §3.4** and the academic-integrity policies)

## L4.7 Cross-references

- **PRL-SOP-001** — Site Safety Operating Procedure (general)
- **PRL-SOP-014** — Steady-State Operations module pre-test
- **NE-101 Week 4** — Point-kinetics lecture (this corpus, file 06)
- **Lamarsh Ch. 7.6–7.8** — formal kinetics treatment
- **10 CFR §50.36(c)(2)** — Limiting Conditions for Operation; relevant
  to the in-experiment scram criteria

— Ondrej (instructor) and the PRL operations team
