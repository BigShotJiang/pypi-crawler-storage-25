# Prague Lab Reactor (PRL) — Overview

The Prague Lab Reactor (PRL) is a 250 kW pool-type research reactor used
for the Prague summer cohort's lab exercises. Operating parameters used
in Week 3 problem sets:

- **Maximum operating temperature**: 425°C (cladding surface)
- **Coolant**: light water, natural convection
- **Fuel**: 19.75% LEU UZrH₁.₆ TRIGA-style elements
- **Steady-state power**: 250 kW thermal
- **Pulse mode**: up to 1.2 GW peak, 30 ms FWHM
- **Reflector**: graphite

This is a teaching abstraction — actual research-reactor specifications
are governed by the institutional license and not in this public corpus.
