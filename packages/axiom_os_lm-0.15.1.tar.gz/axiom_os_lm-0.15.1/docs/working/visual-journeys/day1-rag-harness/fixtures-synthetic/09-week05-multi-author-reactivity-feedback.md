# NE-101 Prague — Week 5 Lecture: Reactivity Feedback

**Primary lecturer:** Ondrej Chvala
**Guest section §5.4:** Khiloni Shah (postdoctoral fellow, UT Austin
Walker Department of Mechanical Engineering — Nuclear and Radiation
Engineering)
**Lecture-notes editor:** James Terry (PRL operations)

## 5.1 Reactivity coefficients — the operational vocabulary

Last week we built the kinetics equations and saw how a step-reactivity
insertion produces a prompt jump followed by an asymptotic response
governed by precursor decay. This week we ask: **what changes ρ during
operation?** The answer is the suite of reactivity coefficients that
encode the feedback from temperature, density, and isotopic
composition back onto the neutron multiplication.

The three you will use most often:

| Coefficient | Symbol | Driven by | Sign in TRIGA / LWR |
|---|---|---|---|
| Doppler | α_D | Fuel temperature → resonance broadening | **Negative** (U-238 capture broadens; reactivity drops) |
| Moderator temperature | α_M | Moderator density change | **Negative** in undermoderated, positive if over-moderated |
| Void | α_V | Coolant boiling / phase change | Design-dependent; can be positive in some BWR fuel arrangements |

## 5.2 Doppler — Ondrej's key derivation

The Doppler coefficient is the most pedagogically important because
it is **prompt** — the response time is set by the fuel-temperature
heat capacity and the resonance broadening, both of which respond on
millisecond timescales. The mathematical treatment follows the
broadening of the U-238 6.7 eV resonance under thermal motion of the
target nuclei.

Formally:

```
α_D(T) ≈ ∂ρ/∂T_fuel
```

For U-238 the broadening produces a *capture* enhancement (roughly
proportional to √T near the resonance peak), which removes neutrons
from the fission chain and reduces ρ. Under operational conditions
this gives α_D < 0 unambiguously; **this is the physics that makes
LWR and TRIGA designs intrinsically self-stabilizing against
fuel-temperature excursions.**

For the formal treatment refer to **Lamarsh §7.3** (introductory
treatment) and **Duderstadt & Hamilton §6.3** (more rigorous,
including the resonance integral derivation).

## 5.3 Moderator temperature — sign depends on spectrum

The moderator-temperature coefficient α_M depends on whether the
reactor is **undermoderated** or **overmoderated** at operating
conditions. An undermoderated lattice (typical LWR design point) has
a *negative* α_M because increased moderator temperature reduces water
density, hardens the spectrum, and reduces thermal-neutron utilization.
An overmoderated lattice would have positive α_M and is generally
avoided because of stability concerns.

This is one of the design constraints baked into 10 CFR §50.46 and
related §50.34 application requirements: licensees demonstrate
adequate negative-feedback margin at all operational states.

## 5.4 Stability analysis — guest section by Khiloni Shah

> *The following section is contributed by Khiloni Shah (postdoctoral
> fellow, UT-Austin Walker Department of Mechanical Engineering —
> Nuclear and Radiation Engineering). Khiloni's research focuses on
> light-water reactor stability margins under accident conditions.*

The combined sign of α_D + α_M + α_V at operating conditions
determines whether a reactor is **statically stable** to small
perturbations. The standard tool for assessing dynamic stability is
the **Nyquist criterion** applied to the closed-loop transfer
function constructed from the point-kinetics equations augmented with
thermal-feedback coupling.

For LWR stability work I particularly recommend **Hetrick, *Dynamics
of Nuclear Reactors* (American Nuclear Society reprint, 1993)** as
the canonical text. It treats both the small-signal linearization
(which is what you'll do in this course) and the full nonlinear
treatment relevant to power-oscillation analysis in BWRs.

The practical implication for the Friday checkpoint: when asked
"is this reactor stable at this operating point," the diagnostic is
*not* whether each individual coefficient is negative — it is whether
the *closed-loop* response (with the thermal-feedback time constant
included) crosses the unit circle in the Nyquist plot. Single-
coefficient sign is necessary but not sufficient.

— *K. Shah*

## 5.5 Bringing it back — Ondrej's wrap

Khiloni's stability framing is the cleanest way to think about the
question that operators face in practice: *"is this state safe?"* The
single-coefficient analysis you'll do in homework is a building block
toward that closed-loop view.

For your Week 5 problem set: derive the small-signal stability margin
for a TRIGA-style configuration with `α_D = −1.5×10⁻⁴ Δk/k/°C` and
`α_M = −2.0×10⁻⁵ Δk/k/°C` at a steady-state fuel temperature of
300°C. Use the data from **Lamarsh §7.3 Table 7.2** for the
delayed-neutron parameters.

Office hours will focus on the Nyquist construction this week.

— Ondrej
