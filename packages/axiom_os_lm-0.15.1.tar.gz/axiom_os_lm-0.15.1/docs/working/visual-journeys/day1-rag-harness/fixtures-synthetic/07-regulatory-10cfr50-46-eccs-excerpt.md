# Regulatory Excerpt — 10 CFR §50.46, ECCS Performance Criteria

> *Curated excerpt for NE-101 Week 5 reading. Source: 10 CFR §50.46,
> Acceptance criteria for emergency core cooling systems for
> light-water nuclear power reactors. This is a reading-list excerpt,
> not the authoritative regulatory text — students must consult the
> current NRC publication for compliance work.*

## §50.46(a) — Applicability

The acceptance criteria of this section apply to **emergency core
cooling systems (ECCS)** that are part of a light-water nuclear power
reactor licensed pursuant to 10 CFR Part 50 or 10 CFR Part 52. The
criteria address postulated loss-of-coolant accidents (LOCAs) of the
sizes and breaks specified in **10 CFR §50.34**, with reference to the
analytical methods of **Appendix K to 10 CFR Part 50**.

## §50.46(b) — Acceptance criteria

The calculated maximum fuel-element cladding temperature shall not
exceed **2200°F (1204°C)**. The calculated total oxidation of the
cladding shall nowhere exceed 0.17 times the total cladding thickness
before oxidation. The calculated total amount of hydrogen generated
from the chemical reaction of the cladding with water or steam shall
not exceed 0.01 times the hypothetical amount that would be generated
if all of the metal in the cladding cylinders surrounding the fuel,
excluding the cladding surrounding the plenum volume, were to react.

The calculated changes in core geometry shall be such that the core
remains amenable to cooling. **Long-term core cooling** shall be
maintained after any successful initial operation of the ECCS, such
that the calculated core temperature shall be maintained at an
acceptably low value, and decay heat shall be removed for the extended
period of time required by the long-lived radioactivity remaining in
the core.

## §50.46(c) — Reporting requirements

A licensee shall estimate the effect of any change to or error in an
acceptable evaluation model or in the application of such a model to
determine if the change or error is significant. For this purpose, a
significant change or error is one which results in a calculated peak
fuel-cladding temperature different by more than 50°F from the
temperature calculated previously for a limiting transient using the
acceptable evaluation model, or is a cumulation of changes and errors
such that the sum of their absolute values exceeds 50°F.

For each change to or error discovered in an acceptable evaluation
model that affects the temperature calculation, the licensee shall
report the nature of the change or error and its estimated effect on
the limiting ECCS analysis to the **NRC at least annually** as
specified in **10 CFR §50.4**. If the change or error is significant,
the licensee shall provide this report within 30 days and include
with the report a proposed schedule for providing a reanalysis or
taking other action as may be needed to show compliance with §50.46
requirements. This schedule may be developed using an integrated
**schedule** as provided in **10 CFR §50.71**.

## Cross-references in this excerpt

- **10 CFR §50.34** — Contents of applications; technical information.
  Defines the LOCA spectrum that ECCS must protect against.
- **Appendix K to 10 CFR Part 50** — ECCS Evaluation Models. Defines
  the analytical methods acceptable for demonstrating §50.46 compliance.
- **10 CFR §50.4** — Written communications. Defines the reporting
  channel.
- **10 CFR §50.71** — Maintenance of records, making of reports.
- **NRC Regulatory Guide 1.157** provides additional acceptable
  best-estimate methods for §50.46 compliance.
- **NRC Regulatory Guide 1.183** provides alternative source-term
  methodology relevant to ECCS-failure dose-consequence analysis.

## Course annotation (Ondrej, 2026-06-16)

For NE-101, you are responsible for **knowing the four acceptance
criteria of §50.46(b)** (peak temperature, oxidation limit, hydrogen
generation, coolable geometry + long-term cooling). You are *not*
responsible for the §50.46(c) reporting machinery — that is regulatory
practice, not introductory reactor engineering. The 2200°F number is
worth memorizing because it appears throughout your career in
LWR-related reading.
