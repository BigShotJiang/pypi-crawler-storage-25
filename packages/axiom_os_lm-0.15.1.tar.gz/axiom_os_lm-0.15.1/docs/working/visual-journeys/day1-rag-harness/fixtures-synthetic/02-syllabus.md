# NE-101 Prague — Syllabus (excerpt)

## Reading list

- Lamarsh, *Introduction to Nuclear Engineering* — primary text
  - Ch. 7 cited for **thermal feedback mechanisms** (Doppler broadening,
    moderator temperature coefficient, void coefficient)
  - Ch. 4 cited for **diffusion theory and one-group reactor equation**
- Duderstadt & Hamilton, *Nuclear Reactor Analysis* — supplementary

## Grading

| Component | Weight |
|---|---|
| Weekly problem sets | 30% |
| Lab reports | 25% |
| Midterm | 20% |
| Final project | 25% |

## Late submission policy

Late assignments are accepted with a **10% penalty per day**, up to a
maximum of 5 days. After 5 days, late work receives a zero unless the
instructor has granted a written extension prior to the deadline.

## Office hours

- Tuesdays 14:00–15:30 in Room 304
- Thursdays 10:00–11:00 (online)
