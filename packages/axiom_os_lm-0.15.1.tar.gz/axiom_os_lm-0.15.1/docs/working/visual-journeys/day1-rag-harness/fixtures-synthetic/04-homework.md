# NE-101 Prague — Week 3 Problem Set

## Problem 4 — One-group diffusion in a bare slab reactor

Solve the one-group diffusion equation for a bare homogeneous slab
reactor of half-thickness *a*, with the **boundary condition specified
as reflective at r = R** (i.e. dφ/dr = 0 at r = R) and zero flux at the
extrapolated boundary.

Find:

- (a) The flux distribution φ(r)
- (b) The geometric buckling B²_g
- (c) The critical condition (k = 1) in terms of B²_g, ν, σ_f, σ_a, and D

Report all results in cgs units. State any assumptions about energy
self-shielding.

## Problem 5 — Doppler broadening

Sketch how the U-238 capture cross-section near the 6.7 eV resonance
broadens with temperature. Reference Lamarsh Ch. 7 for the formal
treatment.
