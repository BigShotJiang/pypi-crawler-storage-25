# NE-101 Prague — Course Policies

## Lab safety violations

A **three-strike policy** applies to all lab work:

1. **Strike 1**: Verbal warning + mandatory re-read of the safety briefing
   before next session.
2. **Strike 2**: Written incident report co-signed by the instructor and
   facility safety officer; access to lab work suspended for one session.
3. **Strike 3**: Course-level disciplinary review; possible removal from
   lab portion of the course (with corresponding grade impact).

Egregious violations (deliberate dosimeter falsification, working without
a current safety briefing on file, knowingly entering a posted exclusion
zone) are immediate Strike 3 regardless of prior history.

## Academic integrity

- Use of AI tutors (including the course-provided one) is permitted for
  conceptual understanding and worked examples.
- Submitting AI-generated text as your own assignment work is a Code of
  Honor violation.
- The course-provided tutor logs all interactions to a per-student session
  visible to the instructor; this is disclosed and consent is part of the
  enrollment agreement.
