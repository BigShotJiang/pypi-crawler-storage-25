# Copyright (c) 2026 The University of Texas at Austin
# Copyright (c) 2026 B-Tree Labs
# SPDX-License-Identifier: Apache-2.0

"""Render journey.md from harness results.jsonl.

First-pass rendering: side-by-side answers per question, heuristic stats
(length, latency, refusal-language flag, citation count), and empty
scoring slots for instructor + Ondrej. Round 2 will add LLM-as-judge
auto-scoring once we've seen the shape on real data.
"""

from __future__ import annotations

import argparse
import json
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

LANE_DISPLAY = {
    "bare_qwen": "Bare Qwen (corpus v1)",
    "course_only": "RAG: course_only — naïve chunker (corpus v1)",
    "course_only_v2_semantic": "RAG: course_only — semantic (corpus v1)",
    "course_only_v3_graph": "RAG: course_only — graph-informed (corpus v1)",
    "course_only_v2_semantic_expanded": "RAG: course_only — semantic (corpus v2 expanded)",
    "course_only_v3_graph_expanded": "RAG: course_only — graph-informed (corpus v2 expanded)",
    "course_plus_institutional": "RAG: course+inst",
    "full": "RAG: full",
    "claude": "Claude (corpus v1)",
}

CATEGORY_DISPLAY = {
    "should_rag_win": "🎯 Should-RAG-win",
    "should_be_wash": "≈ Should-be-wash",
    "out_of_corpus": "⚠ Out-of-corpus",
}

REFUSAL_PATTERNS = [
    r"\bI (don't|do not) know\b",
    r"\bI'm not (sure|certain)\b",
    r"\b(unable|can't|cannot) (provide|answer|help)\b",
    r"\bbeyond (my|the) (knowledge|scope|training)\b",
    r"\bnot in (my|the) (training|knowledge|corpus)\b",
    r"\bI (won't|will not) help\b",
    r"\bdeclines? to\b",
]
REFUSAL_RE = re.compile("|".join(REFUSAL_PATTERNS), re.IGNORECASE)


def load_rows(path: Path) -> list[dict[str, Any]]:
    return [json.loads(ln) for ln in path.read_text().splitlines() if ln.strip()]


def detect_refusal(answer: str) -> bool:
    return bool(REFUSAL_RE.search(answer or ""))


def truncate(s: str, n: int = 800) -> str:
    if not s:
        return "*(empty)*"
    s = s.strip()
    if len(s) <= n:
        return s
    return s[:n].rstrip() + "…"


def render_lane_block(row: dict[str, Any]) -> str:
    answer = row.get("answer", "") or ""
    citations = row.get("citations") or []
    err = row.get("error")
    parts = [
        f"**{LANE_DISPLAY.get(row['lane'], row['lane'])}**  "
        f"·  {row.get('answer_len',0)} chars  ·  {row.get('latency_s',0):.1f}s"
    ]
    if err:
        parts.append(f"<sub>⚠ error: `{err[:200]}`</sub>")
    if citations:
        cite_lines = []
        for c in citations[:3]:
            if isinstance(c, dict):
                cite_lines.append(f"- {c.get('source') or c.get('id') or str(c)[:80]}")
            else:
                cite_lines.append(f"- {str(c)[:80]}")
        parts.append("<sub>citations:</sub>\n" + "\n".join(cite_lines))
    if detect_refusal(answer):
        parts.append("<sub>↳ contains refusal language ✓</sub>")
    parts.append("")
    parts.append("```")
    parts.append(truncate(answer, 800))
    parts.append("```")
    parts.append(f"<sub>trace: `{row.get('trace_id','-')[:8]}…`</sub>")
    return "\n".join(parts)


def render_question_card(rows: list[dict[str, Any]]) -> str:
    rows_by_lane = {r["lane"]: r for r in rows}
    q = rows[0]
    cat_disp = CATEGORY_DISPLAY.get(q["category"], q["category"])
    md = [
        f"### `{q['question_id']}` · {cat_disp}",
        "",
        f"> **{q['question']}**",
        "",
    ]
    # Render lanes in canonical order (so side-by-side comparison is consistent)
    canonical_order = (
        "bare_qwen",
        "course_only",
        "course_only_v2_semantic",
        "course_only_v3_graph",
        "course_only_v2_semantic_expanded",
        "course_only_v3_graph_expanded",
        "course_plus_institutional",
        "full",
        "claude",
    )
    for lane in canonical_order:
        if lane in rows_by_lane:
            md.append("---")
            md.append(render_lane_block(rows_by_lane[lane]))
            md.append("")
    md.extend([
        "---",
        "",
        "**Scoring (fill in after review):**",
        "",
        "| Lane | Factuality | Citation | Lecture-fidelity | Depth | Refusal-quality | Notes |",
        "|---|---|---|---|---|---|---|",
    ])
    for lane in canonical_order:
        if lane in rows_by_lane:
            md.append(f"| {LANE_DISPLAY[lane]} |  |  |  |  |  |  |")
    md.append("")
    return "\n".join(md)


def render_summary(rows: list[dict[str, Any]]) -> str:
    by_lane: dict[str, list[float]] = defaultdict(list)
    by_lane_lens: dict[str, list[int]] = defaultdict(list)
    by_lane_errors: dict[str, int] = defaultdict(int)
    for r in rows:
        if r.get("error"):
            by_lane_errors[r["lane"]] += 1
        by_lane[r["lane"]].append(r.get("latency_s") or 0)
        by_lane_lens[r["lane"]].append(r.get("answer_len") or 0)
    md = [
        "## Summary stats",
        "",
        "| Lane | Calls | OK | Errors | Median latency | Median answer len |",
        "|---|---|---|---|---|---|",
    ]
    for lane in (
        "bare_qwen",
        "course_only",
        "course_only_v2_semantic",
        "course_only_v3_graph",
        "course_only_v2_semantic_expanded",
        "course_only_v3_graph_expanded",
        "course_plus_institutional",
        "full",
        "claude",
    ):
        if lane not in by_lane:
            continue
        latencies = sorted(by_lane[lane])
        lens = sorted(by_lane_lens[lane])
        n = len(latencies)
        ok = n - by_lane_errors[lane]
        med_lat = latencies[n // 2] if latencies else 0.0
        med_len = lens[n // 2] if lens else 0
        md.append(
            f"| {LANE_DISPLAY[lane]} | {n} | {ok} | {by_lane_errors[lane]} "
            f"| {med_lat:.1f}s | {med_len} chars |"
        )
    md.append("")
    return "\n".join(md)


def render(results_path: Path, out_path: Path, langfuse_host: str) -> None:
    rows = load_rows(results_path)
    if not rows:
        out_path.write_text("# Day 1 RAG harness journey\n\n*(no results yet)*\n")
        return

    by_question: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for r in rows:
        by_question[(r["category"], r["question_id"])].append(r)

    sections: list[str] = []
    cat_order = ["should_rag_win", "should_be_wash", "out_of_corpus"]
    for cat in cat_order:
        items = sorted(
            ((cqid, rs) for cqid, rs in by_question.items() if cqid[0] == cat),
            key=lambda x: x[0][1],
        )
        if not items:
            continue
        sections.append(f"## {CATEGORY_DISPLAY[cat]}\n")
        for _, rs in items:
            sections.append(render_question_card(rs))

    header = (
        "# Day 1 RAG-mode comparison — visual journey\n\n"
        "Multi-lane head-to-head on a curated battery. Each card shows the same\n"
        "question across all available lanes. Scoring slots are blank — fill in\n"
        "your judgment between iteration rounds.\n\n"
        f"**LangFuse:** [{langfuse_host}]({langfuse_host}) — every row links to its trace ID.\n\n"
        "**Lanes:**\n"
        "- **Bare Qwen** — Rascal :41883, no retrieval (floor baseline)\n"
        "- **RAG: course_only (naïve chunker)** — round 1: classroom's original 400-char fixed-window chunker\n"
        "- **RAG: course_only (semantic chunker)** — round 2: `axiom.rag.semantic_chunker.chunk_semantic` (Day 1 finding rw-01 fix)\n"
        "- **RAG: course_only (graph-informed chunker)** — round 3: semantic + graph-extractor boundaries from `axiom.graph.extractors.deterministic` (≈ round 2 on this synthetic corpus; real wins materialize on regulatory-heavy or longer docs)\n"
        "- **RAG: course+inst** — `axi classroom prep rag --mode course_plus_institutional` (pending institutional corpus)\n"
        "- **RAG: full** — `axi classroom prep rag --mode full` (pending institutional corpus)\n"
        "- **Claude** — Anthropic Claude Sonnet 4.6 (strong general baseline)\n\n"
    )

    summary = render_summary(rows)
    body = "\n\n".join(sections)
    footer = (
        "\n\n---\n"
        "## Round-2 follow-ups\n"
        "After you fill in scoring + leave any UI feedback notes inline, "
        "I'll regenerate this doc with: (a) auto-judge scoring via Claude-as-judge "
        "where slots are still blank; (b) any UI/screenshot polish you mark; "
        "(c) per-student RAG/LLM override demonstration.\n"
    )

    out_path.write_text(header + summary + "\n\n" + body + footer)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--results",
        default=str(Path(__file__).parent / "results.jsonl"),
    )
    parser.add_argument(
        "--out",
        default=str(Path(__file__).parent / "journey.md"),
    )
    parser.add_argument("--langfuse-host", default=os.environ.get("LANGFUSE_HOST", ""))
    args = parser.parse_args()

    render(Path(args.results), Path(args.out), args.langfuse_host)
    print(f"[render_journey] wrote {args.out}")


if __name__ == "__main__":
    main()
