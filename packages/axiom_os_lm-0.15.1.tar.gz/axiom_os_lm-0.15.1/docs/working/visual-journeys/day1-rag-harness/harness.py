# Copyright (c) 2026 The University of Texas at Austin
# Copyright (c) 2026 B-Tree Labs
# SPDX-License-Identifier: Apache-2.0

"""Day 1 RAG-mode comparison harness.

Runs each question through 5 lanes:
  1. bare_qwen                  — bare Qwen on Rascal :41883, no retrieval
  2. course_only                — axi classroom ask with cohort-curated RAG
  3. course_plus_institutional  — axi classroom ask with hybrid RAG
  4. full                       — axi classroom ask with org-wide RAG
  5. claude                     — Anthropic Claude as the strong general baseline

Each invocation produces one LangFuse trace with shared metadata so all five
lanes for one question are filterable side-by-side. Results write to
`results.jsonl` for the journey doc renderer to pick up.

Required env (auto-loaded via direnv from workspace .envrc):
  LANGFUSE_PUBLIC_KEY / LANGFUSE_SECRET_KEY / LANGFUSE_HOST  — auto-tagged trace destination
  QWEN_API_KEY        — Rascal Qwen :41883
  ANTHROPIC_API_KEY   — Claude lane
"""

from __future__ import annotations

import argparse
import json
import os
import ssl
import subprocess
import sys
import time
import urllib.request
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

# Make axiom importable when running from workspace root.
sys.path.insert(0, str(Path(__file__).resolve().parents[4] / "src"))
from axiom.infra.tracing.langfuse_provider import LangfuseTraceProvider  # noqa: E402

# ─── Config ─────────────────────────────────────────────────────────────────

QWEN_URL = "https://10.159.142.118:41883/v1/chat/completions"
QWEN_MODEL = "unsloth/Qwen3.5-122B-A10B-GGUF:Q4_K_M"
CLAUDE_MODEL = "claude-sonnet-4-6"

# Tutor-style system prompt — same shape we'd use in classroom ask.
TUTOR_SYSTEM = (
    "You are a nuclear-engineering tutor for an introductory NE-101 course. "
    "Be concise and concrete. If you do not know the answer or it is outside "
    "the scope of the course material you have access to, say so directly "
    "rather than inventing details. When citing course material, be specific."
)

LANES = ["bare_qwen", "course_only", "course_plus_institutional", "full", "claude"]


def now_iso() -> str:
    return datetime.now(UTC).isoformat()


# ─── Lane: bare Qwen ────────────────────────────────────────────────────────


def call_qwen_bare(question: str) -> dict[str, Any]:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    payload = json.dumps(
        {
            "model": QWEN_MODEL,
            "messages": [
                {"role": "system", "content": TUTOR_SYSTEM},
                {"role": "user", "content": question},
            ],
            # Qwen 3.5 reasoning model — large budget so the chain-of-thought
            # has room AND the final answer can land. Round 0 used 1500 and 12/18
            # questions returned empty content because Qwen used the entire budget
            # on reasoning before producing the answer. 4000 fixed it in spot tests.
            "max_tokens": 4000,
            "temperature": 0.3,
        }
    ).encode()
    req = urllib.request.Request(
        QWEN_URL,
        data=payload,
        headers={
            "Authorization": f"Bearer {os.environ['QWEN_API_KEY']}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120, context=ctx) as resp:
            body = json.loads(resp.read())
    except Exception as e:  # noqa: BLE001
        return {"answer": "", "error": str(e)[:300], "latency_s": time.perf_counter() - t0}
    elapsed = time.perf_counter() - t0
    msg = body["choices"][0]["message"]
    return {
        "answer": msg.get("content") or "",
        "reasoning_chars": len(msg.get("reasoning_content") or ""),
        "tokens_in": body.get("usage", {}).get("prompt_tokens"),
        "tokens_out": body.get("usage", {}).get("completion_tokens"),
        "latency_s": elapsed,
    }


# ─── Lane: axi classroom ask (one of three RAG modes set externally) ───────


def _retrieve_via_classroom(classroom_id: str, question: str, k: int = 3) -> tuple[list[dict[str, Any]], float]:
    """Call `axi classroom ask --json` purely to extract citations.

    The classroom's own LLM gateway has separate gaps (bonsai-local isn't
    running, EC routing for qwen-rascal isn't fully wired). We bypass that
    here — but the retrieval that runs against the student's local index
    IS production-shape, and that's what we want to compare across RAG
    modes. The prompt-with-citations is then run through Qwen directly.
    """
    venv_axi = Path(sys.executable).parent / "axi"
    cmd = [
        str(venv_axi), "classroom", "ask", classroom_id, question,
        "-k", str(k), "--json",
    ]
    t0 = time.perf_counter()
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    elapsed = time.perf_counter() - t0
    if proc.returncode != 0:
        return [], elapsed
    # The CLI emits warning lines on stderr/stdout above the JSON; find
    # the JSON object boundary and parse.
    out = proc.stdout
    start = out.find("{")
    if start < 0:
        return [], elapsed
    try:
        data = json.loads(out[start:])
    except json.JSONDecodeError:
        return [], elapsed
    return list(data.get("citations") or []), elapsed


def call_classroom_lane(classroom_id: str, question: str, k: int = 3) -> dict[str, Any]:
    """Real RAG comparison: retrieval through the student's local index +
    Qwen call with citations as grounding context. The active RAG mode is
    set externally via `axi classroom prep rag --mode <mode>` before this
    is called — same retrieval path; different policy."""
    citations, retrieval_latency = _retrieve_via_classroom(classroom_id, question, k)

    # Build a prompt that grounds the model in retrieved chunks. Mirror the
    # shape the production gateway will use once it's wired through.
    if citations:
        ctx_blocks = []
        for i, c in enumerate(citations[:k], 1):
            title = c.get("title") or c.get("file_id") or "source"
            text = (c.get("text") or "").strip()
            ctx_blocks.append(f"[Source {i}: {title}]\n{text}")
        context = "\n\n".join(ctx_blocks)
        user_msg = (
            f"Use the following course material to answer. Cite sources by their "
            f"[Source N: filename] tag when you reference them. If the material "
            f"does not cover the question, say so directly.\n\n"
            f"---\n{context}\n---\n\nQuestion: {question}"
        )
    else:
        user_msg = (
            f"No course material was retrieved for this question. Answer only if "
            f"you can do so based on widely-known general knowledge; otherwise "
            f"say so directly. Do not invent course-specific details.\n\n"
            f"Question: {question}"
        )

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    payload = json.dumps({
        "model": QWEN_MODEL,
        "messages": [
            {"role": "system", "content": TUTOR_SYSTEM},
            {"role": "user", "content": user_msg},
        ],
        "max_tokens": 4000,
        "temperature": 0.3,
    }).encode()
    req = urllib.request.Request(
        QWEN_URL, data=payload,
        headers={
            "Authorization": f"Bearer {os.environ['QWEN_API_KEY']}",
            "Content-Type": "application/json",
        }, method="POST",
    )
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=120, context=ctx) as resp:
            body = json.loads(resp.read())
    except Exception as e:  # noqa: BLE001
        return {
            "answer": "", "error": str(e)[:300],
            "latency_s": time.perf_counter() - t0,
            "citations": citations,
            "retrieval_latency_s": retrieval_latency,
        }
    elapsed = time.perf_counter() - t0
    msg = body["choices"][0]["message"]
    return {
        "answer": msg.get("content") or "",
        "reasoning_chars": len(msg.get("reasoning_content") or ""),
        "tokens_in": body.get("usage", {}).get("prompt_tokens"),
        "tokens_out": body.get("usage", {}).get("completion_tokens"),
        "latency_s": elapsed,
        "retrieval_latency_s": retrieval_latency,
        "citations": citations,
    }


def set_classroom_rag_mode(classroom_id: str, mode: str) -> None:
    venv_axi = Path(sys.executable).parent / "axi"
    cmd = [str(venv_axi), "classroom", "prep", "rag", "--mode", mode, classroom_id]
    subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=30)


# ─── Lane: Claude ──────────────────────────────────────────────────────────


def call_claude(question: str) -> dict[str, Any]:
    from anthropic import Anthropic

    client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    t0 = time.perf_counter()
    try:
        msg = client.messages.create(
            model=CLAUDE_MODEL,
            max_tokens=600,
            system=TUTOR_SYSTEM,
            messages=[{"role": "user", "content": question}],
        )
    except Exception as e:  # noqa: BLE001
        return {"answer": "", "error": str(e)[:300], "latency_s": time.perf_counter() - t0}
    elapsed = time.perf_counter() - t0
    text = msg.content[0].text if msg.content else ""
    return {
        "answer": text,
        "tokens_in": msg.usage.input_tokens,
        "tokens_out": msg.usage.output_tokens,
        "latency_s": elapsed,
    }


# ─── Trace helper ──────────────────────────────────────────────────────────


def trace_one(
    provider: LangfuseTraceProvider,
    *,
    question_id: str,
    category: str,
    question: str,
    lane: str,
    classroom_id: str,
    cohort: str,
    result: dict[str, Any],
) -> str:
    """One LangFuse trace per (question, lane). Shared metadata across lanes
    for the same question makes them side-by-side filterable."""
    tid = provider.start_trace(
        f"harness.{category}.{question_id}.{lane}",
        question_id=question_id,
        category=category,
        lane=lane,
        cohort=cohort,
        classroom_id=classroom_id,
        harness="day1-rag-comparison",
    )
    if "citations" in result and result["citations"]:
        provider.log_retrieval(
            tid,
            query=question,
            results=result["citations"],
            k=len(result["citations"]),
        )
    elif lane in {"course_only", "course_plus_institutional", "full"}:
        # Empty retrieval span — visible in trace tree as "no hits"
        provider.log_retrieval(tid, query=question, results=[], retrieval_empty=True)
    provider.log_generation(
        tid,
        model=QWEN_MODEL if lane != "claude" else CLAUDE_MODEL,
        prompt=question,
        output=result.get("answer", ""),
        latency_ms=int(result.get("latency_s", 0) * 1000),
        tokens_in=result.get("tokens_in"),
        tokens_out=result.get("tokens_out"),
        reasoning_chars=result.get("reasoning_chars", 0),
        error=result.get("error"),
    )
    return tid


# ─── Main ──────────────────────────────────────────────────────────────────


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--classroom-id", default="NE-PRAGUE-DAY1")
    parser.add_argument("--cohort", default="prague-summer-2026")
    parser.add_argument(
        "--questions",
        default=str(Path(__file__).parent / "questions.yaml"),
    )
    parser.add_argument(
        "--results",
        default=str(Path(__file__).parent / "results.jsonl"),
    )
    parser.add_argument("--lanes", nargs="+", default=LANES)
    parser.add_argument(
        "--skip-classroom",
        action="store_true",
        help="Skip the three classroom lanes (useful for smoke-testing claude+bare lanes only)",
    )
    args = parser.parse_args()

    qs_data = yaml.safe_load(Path(args.questions).read_text())
    flat: list[dict[str, Any]] = []
    for cat in qs_data["categories"]:
        for q in cat["questions"]:
            flat.append({"category": cat["name"], **q})

    print(f"[harness] loaded {len(flat)} questions across {len(qs_data['categories'])} categories")
    print(f"[harness] lanes: {args.lanes}")
    print(f"[harness] classroom: {args.classroom_id}")
    print()

    provider = LangfuseTraceProvider(
        public_key=os.environ["LANGFUSE_PUBLIC_KEY"],
        secret_key=os.environ["LANGFUSE_SECRET_KEY"],
        host=os.environ["LANGFUSE_HOST"],
    )

    results: list[dict[str, Any]] = []

    def record(lane: str, q: dict[str, Any], r: dict[str, Any]) -> None:
        tid = trace_one(
            provider,
            question_id=q["id"],
            category=q["category"],
            question=q["question"],
            lane=lane,
            classroom_id=args.classroom_id,
            cohort=args.cohort,
            result=r,
        )
        row = {
            "ts": now_iso(),
            "lane": lane,
            "question_id": q["id"],
            "category": q["category"],
            "question": q["question"],
            "answer": r.get("answer", ""),
            "answer_len": len(r.get("answer", "") or ""),
            "latency_s": r.get("latency_s", 0),
            "trace_id": tid,
            "error": r.get("error"),
            "tokens_in": r.get("tokens_in"),
            "tokens_out": r.get("tokens_out"),
            "citations": r.get("citations", []),
        }
        results.append(row)
        ans_len = row["answer_len"]
        latency = row["latency_s"]
        marker = "✓" if ans_len > 20 else "✗" if ans_len == 0 else "·"
        print(f"  {marker} {q['id']:8s} {lane:30s} {ans_len:5d} chars  {latency:5.1f}s")

    # Lane: bare_qwen
    if "bare_qwen" in args.lanes:
        print("=== bare_qwen ===")
        for q in flat:
            record("bare_qwen", q, call_qwen_bare(q["question"]))
        print()

    # Lanes: classroom (3 RAG modes)
    if not args.skip_classroom:
        for mode in ("course_only", "course_plus_institutional", "full"):
            if mode not in args.lanes:
                continue
            print(f"=== {mode} ===")
            try:
                set_classroom_rag_mode(args.classroom_id, mode)
            except subprocess.CalledProcessError as e:
                print(f"  ! could not set RAG mode {mode}: {e.stderr[:300]}")
                continue
            for q in flat:
                record(mode, q, call_classroom_lane(args.classroom_id, q["question"]))
            print()

    # Lane: claude
    if "claude" in args.lanes:
        print("=== claude ===")
        for q in flat:
            record("claude", q, call_claude(q["question"]))
        print()

    provider.flush()

    Path(args.results).write_text(
        "\n".join(json.dumps(r) for r in results) + "\n"
    )
    print(f"[harness] wrote {len(results)} rows to {args.results}")
    print(f"[harness] open LangFuse to inspect: {os.environ['LANGFUSE_HOST']}")


if __name__ == "__main__":
    main()
