#!/usr/bin/env python3
# Copyright (c) 2026 The University of Texas at Austin
# Copyright (c) 2026 B-Tree Labs
# SPDX-License-Identifier: Apache-2.0
"""Memory benchmarks baseline harness.

Per `working/memory-benchmarks.md` §6 — produces reproducible numbers
for the Stage 1 baseline: write throughput, projection latency at
1k and 11k fragments, replay determinism check.

Run:
    source ../.venv/bin/activate     # or wherever your venv is
    python3 docs/working/memory-benchmarks-baseline.py

Output goes to stdout. Capture with redirection to pin a baseline:
    python3 docs/working/memory-benchmarks-baseline.py \
        > docs/working/memory-benchmarks-baseline-$(date +%Y-%m-%d).txt
"""

from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path


def _make_service(*, sqlite_path: Path | None = None):
    """Build a CompositionService matching prod shape."""
    from axiom.artifacts.registry import (
        ArtifactRegistry,
        InMemoryBackend,
        SQLiteBackend,
    )
    from axiom.memory.access import AccessGraphs
    from axiom.memory.attest import AuditLog
    from axiom.memory.composition import CompositionService
    from axiom.memory.policy import PolicyCoord
    from axiom.memory.trust import TrustGraph

    backend = (
        SQLiteBackend(sqlite_path)
        if sqlite_path is not None
        else InMemoryBackend()
    )
    audit_path = (sqlite_path.parent if sqlite_path is not None else Path(tempfile.mkdtemp())) / "audit.jsonl"
    return CompositionService(
        artifact_registry=ArtifactRegistry(backend=backend),
        audit_log=AuditLog(audit_path, signing_keypair=None),
        signing_keypair=None,
        policy_coord=PolicyCoord(global_policy={"write": "private"}),
        access_graphs=AccessGraphs(),
        trust_graph=TrustGraph(),
    )


def _bench_writes(cs, n: int, *, base_index: int = 0) -> float:
    """Returns elapsed wall-clock ms for n writes."""
    t0 = time.perf_counter()
    for i in range(base_index, base_index + n):
        cs.write(
            content={
                "event_time": f"2026-04-26T1{i % 10}:{(i // 10) % 60:02d}:00+00:00",
                "classroom_id": "NE101",
                "question": f"Q{i}",
                "mode": "ask",
                "had_answer": True,
                "citations_count": 1,
            },
            cognitive_type="episodic",
            principal_id=f"s{i % 30}",
            agents=set(),
            resources=set(),
        )
    return (time.perf_counter() - t0) * 1000.0


def _bench_projection(registry, *, principal_id: str = "s0", window: int = 5) -> float:
    from axiom.memory.projections import RecentActivityProjection, TaskSpec

    proj = RecentActivityProjection(registry, window_n=window)
    t0 = time.perf_counter()
    proj.project(
        TaskSpec(task_type="recent_activity", scope="NE101"),
        principal_id=principal_id,
    )
    return (time.perf_counter() - t0) * 1000.0


def _check_replay_determinism(registry, *, runs: int = 5) -> bool:
    from axiom.memory.projections import RecentActivityProjection, TaskSpec

    proj = RecentActivityProjection(registry, window_n=5)
    task = TaskSpec(task_type="recent_activity", scope="NE101")
    canonical = None
    for _ in range(runs):
        result = proj.project(task, principal_id="s0")
        ids = tuple(f.id for f in result.fragments)
        if canonical is None:
            canonical = ids
        elif ids != canonical:
            return False
    return True


def main() -> int:
    results: dict = {"baseline_run_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}

    # ----- InMemory backend -----
    cs_mem = _make_service()
    n1 = 1000
    write_mem = _bench_writes(cs_mem, n1)
    proj_mem = _bench_projection(cs_mem.artifact_registry)
    results["inmemory"] = {
        "write_ms_total": round(write_mem, 1),
        "write_ms_per_fragment": round(write_mem / n1, 3),
        "projection_ms_at_1k": round(proj_mem, 1),
    }

    # ----- SQLite backend -----
    tmp = Path(tempfile.mkdtemp())
    cs_sql = _make_service(sqlite_path=tmp / "artifacts.db")
    write_sql_1k = _bench_writes(cs_sql, n1)
    proj_sql_1k = _bench_projection(cs_sql.artifact_registry)
    n2 = 10000
    write_sql_10k = _bench_writes(cs_sql, n2, base_index=n1)
    proj_sql_11k = _bench_projection(cs_sql.artifact_registry)
    determinism = _check_replay_determinism(cs_sql.artifact_registry)

    results["sqlite"] = {
        "write_1k_ms_total": round(write_sql_1k, 1),
        "write_1k_ms_per_fragment": round(write_sql_1k / n1, 3),
        "projection_ms_at_1k": round(proj_sql_1k, 1),
        "write_+10k_ms_total": round(write_sql_10k, 1),
        "write_+10k_ms_per_fragment": round(write_sql_10k / n2, 3),
        "projection_ms_at_11k": round(proj_sql_11k, 1),
        "replay_determinism_pass": determinism,
    }

    # ----- Compliance markers (binary) -----
    results["compliance"] = {
        "C1_replay_determinism": determinism,
    }

    print(json.dumps(results, indent=2))
    return 0 if determinism else 2


if __name__ == "__main__":
    sys.exit(main())
