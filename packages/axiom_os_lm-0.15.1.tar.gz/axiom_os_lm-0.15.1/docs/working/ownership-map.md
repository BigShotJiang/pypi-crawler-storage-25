# IP Ownership Map

**Status:** Authoritative
**Owner:** Benjamin Booth
**Last updated:** 2026-05-02
**Parent:** [brand-product-strategy.md](brand-product-strategy.md), [/NOTICE](/NOTICE)

This document is the authoritative source of truth for copyright
attribution in this repository.

---

## The rule

**The entire `axiom-os` repository is jointly copyrighted by The
University of Texas at Austin and B-Tree Labs.** Every source file
carries both copyright lines.

This is the consequence of the funding pattern: the sole author has
contributed to every product (Axiom platform, Vega federation, Keplo
classroom, NeutronOS support code, scidisplay, etc.) in two
overlapping capacities — as a UT-Austin researcher under federal
grants, and as principal of B-Tree Labs on personal time. There is
no clean per-file or per-product split that would accurately carry
either name alone.

*B-Tree Labs is the operating name of B-Tree Ventures, LLC.*

## Scope

The joint posture covers the entire repository:

- The Axiom platform — agent harness, memory model, identity layer,
  RAG retrieval, RPE, ArtifactRegistry, evals, research loop
- All extensions in `src/axiom/extensions/builtins/` — chat, signal,
  publishing, classroom, scidisplay, release, hygiene, mcp, memory,
  federation, etc.
- Vega-pre-extraction code (federation, security, identity)
- Keplo-pre-extraction code (classroom)
- All tests, docs, scripts, schema, and tooling

NeutronOS as deployed at UT lives in a separate repository
(https://github.com/b-tree-labs/neutron-os) and is jointly
copyrighted on the same terms as this repo.

## Substrate lineage

Files directly ported from Substrate
(https://github.com/b-tree-labs/substrate, Apache-2.0, B-Tree Labs)
retain Substrate's original copyright line. Modifications performed
within `axiom-os` add the joint UT + B-Tree Labs lines below it, in
modification-date order.

## File-header form

```
# Copyright (c) <YEAR> The University of Texas at Austin
# Copyright (c) <YEAR> B-Tree Labs
# SPDX-License-Identifier: Apache-2.0
```

For Substrate-derived files only:

```
# Copyright (c) 2025 B-Tree Labs                       # original (Substrate)
# Copyright (c) <YEAR> The University of Texas at Austin
# Copyright (c) <YEAR> B-Tree Labs
# SPDX-License-Identifier: Apache-2.0
```

The year on the joint lines is the year the file was first
introduced into `axiom-os` (preserved across modifications).

## What this map does NOT govern

- **Trademark rights** — see /NOTICE §"Trademarks"
- **Patent rights** — see Apache-2.0 §3 for the cross-license terms
- **Future contributions from third parties** — they add their own
  copyright lines per Apache-2.0 §4(b)
- **Sponsored research IP agreements** — those operate alongside this
  map, not within it; consult OTC and the principal's attorney for
  any project that touches a sponsor's pre-existing IP

## Migration history

The previous version of this document maintained a granular
per-product table assigning Axiom to B-Tree alone and Vega/Keplo to
UT alone. On review (2026-05-02), that table did not match how the
work actually accumulated — both contribution streams touch every
product. The simpler joint posture above replaces it.

The header-rewrite sweep recorded in commit `chore(license):
apply joint UT + B-Tree Labs copyright headers` updated every
source-file header to match this rule.
