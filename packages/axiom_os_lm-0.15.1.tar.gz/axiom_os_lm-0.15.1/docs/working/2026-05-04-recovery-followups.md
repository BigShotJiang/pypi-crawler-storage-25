# Recovery follow-ups — 2026-05-04 stash loss

**Context:** During the cleanup that collapsed 12 axiom worktrees down to 2, four stashes were lost (see `feedback_never_remove_worktree_with_stashes` memory). This file tracks the items that were *not* immediately reconstructed in PR-of-the-day so they don't drift.

## High-priority unreconstructed items

### 1. `cohort_model.py` — compute decomposition coordination

- **Where it goes:** `src/axiom/compute_decomposition/coordination/cohort_model.py` (the directory exists on main, empty)
- **What it models:** the *third* concept of "cohort" in the codebase — neither `memory.cohort_registry` (signed federation membership group, persistent) nor `classroom.coordinator_cohort_store` (leader-follower learning group, persistent). A **compute cohort** is the *transient* runtime subset of federation peers that participates in one compute job, scoped by trait + classification + liveness.
- **Ground:** ADR-040 (compute-decomposition primitive vocabulary), `spec-compute-decomposition.md`, the two existing cohort precedents above.
- **Approach:** TDD. Write `tests/coordination/test_cohort_model.py` first against shape:
  - `ComputeCohort(peers: set[PeerId], traits: dict[PeerId, Traits])`
  - `ChunkAssignment(peer: PeerId, chunk: Chunk, claim_ts: datetime, deadline: datetime)`
  - liveness/timeout protocol (chunks reassigned on peer silence)
  - trait-routing predicate (e.g. "GPU available + classification ≥ chunk.required")
- **Priority:** lower than the ADR-040 primitive itself (proof-of-concept; the consumer extensions can carry their own coordination until this lands).

### 2. `memory/cli.py` edits — memory-testing thread

- **Where it was:** modifications to `src/axiom/extensions/builtins/memory/cli.py`
- **Context Ben recalls:** "we were doing Memory testing and need to get back to it" — open thread in the memory CLI, no specific intent captured.
- **Approach:** revisit when memory testing resumes. `git log` on `src/axiom/extensions/builtins/memory/cli.py` will surface the most recent thread direction; the lost edits were on top of that.

### 3. `demo-three-approaches-scientist.py` + `scidisplay/compute.py` + `scidisplay/tests/` edits — **vision captured**

- **Where they were:** `scripts/demo-three-approaches-scientist.py` (~648-line modification), `src/axiom/extensions/builtins/scidisplay/compute.py` (~212-line modification), `src/axiom/extensions/builtins/scidisplay/tests/` (untracked tests dir).
- **Context:** Stashed on `feat/coordinated-workloads`. The lost iteration was *moving toward* a full progression-problem v1 demo — start simple/local, layer complexity, scale up to federated decomposition across local + Rascal + TACC tiers, instrumented through a unified twin view that supports live-and-post-facto queries.
- **Direction document:** **`docs/working/progression-problem-v1-trajectory.md`** captures the v1 vision, the four-rung ladder (single-node → local-federation → cross-tier → full progression with twin instrumentation), the dependency sequence, and the gap analysis (data platform extension and twin extension are the critical missing pieces).
- **Approach:** rebuild as the *Rung 2 → Rung 3* progression on top of the now-on-main coordinated-workloads + compute-decomposition primitives, not as a recreation of the lost edits. The trajectory doc is the spec.

## Lower-priority loss

### 4. "chat-surface-improvements bleed-through" (×2 stashes)

- **Status: probably no action required.** The substantive work — slash commands, multi-modal image input, retry-on-5xx, persistent tasks, diff-review UI, per-tool permissions, prompt-library fragments, tool-failure taxonomy — is committed on `feat/chat-surface-improvements` (15+ commits, 19,696 insertions). The bleed-through stashes were likely small iterations on top of that committed work; their loss does not regress the branch's content.

## Reconstructed in this commit

- ✅ ADR-043 (RACI evolution / graduated autonomy) — `docs/adrs/adr-043-raci-evolution.md`
- ✅ Paper working draft "Above the Job Scheduler" — `docs/papers/working/2026-above-the-job-scheduler-draft.md`
- ✅ REV-U PRD expansion (phases 2–7 detail) — edited `docs/prds/prd-rev-u-pr-review.md`
