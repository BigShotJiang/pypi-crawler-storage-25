# `docs/working/archive/`

Point-in-time working documents whose live value has been captured elsewhere (memory, ADR, PRD, spec, code) or whose subject has shipped/been superseded.

Files here are **not deleted** — they're preserved for forensic reference and history. They should NOT be cited as load-bearing context in current work.

## Promotion-out criteria

A doc gets archived when **any** of:

- It's a **session checkpoint** with a date in the filename (`*-2026-04-25.md`) and the session is over.
- It's a **plan** that has been superseded by a newer plan elsewhere.
- It's a **lessons-captured** doc whose lessons are now in feedback memory.
- It's a **point-in-time review/audit/walkthrough** that informed work since shipped.
- It's a **decision study** whose decision is now in an ADR or memory.
- It's a **dated data artifact** (benchmark JSON, etc.) whose successor has been generated.

If you're unsure whether to archive: it's better to leave it in `working/` and let it accumulate than to archive a load-bearing live doc by mistake. Archive in batches with a triage commit message naming each file's reason for moving.

## Convention

When archiving:

```
git mv docs/working/<file> docs/working/archive/<file>
```

Keep the filename intact so existing references (in commit messages, memory, papers) still resolve via grep.

## Index of current archived files (2026-05-04 batch)

| File | Reason |
|---|---|
| `classroom-memory-end-to-end-review-2026-04-25.md` | Point-in-time review; classroom-memory work has progressed. |
| `classroom-smoke-2026-04-25.md` | Point-in-time smoke test. |
| `founder-walkthrough-2026-04-27.md` | Point-in-time walkthrough. |
| `ci-hygiene-plan-2026-04-28.md` | Captured 2026-04-28; lessons folded into operational pre-push hook + memory. |
| `lessons-rascal-slm-dependency-2026-04-28.md` | Captured; improvements landed; lesson lives in feedback memory. |
| `merged-execution-plan-2026-04-20.md` | Superseded by `project_prague_runway_plan_2026_04_29` memory + later plans. |
| `tier-a-federation-ceremony-roadmap.md` | "Draft for tomorrow's session" 2026-04-22; tomorrow was 2 weeks ago. |
| `cognee-vs-build-study.md` | Decision captured in `project_cognee_assessment` memory; study is historical. |
| `note-ondrej-soha-classroom.md` | One-off note from 2026-04-13; relevant context now lives in classroom design docs. |
| `memory-benchmarks-baseline-2026-04-26-stage3.json` | Dated benchmark snapshot. |
| `memory-benchmarks-baseline-2026-04-26.json` | Dated benchmark snapshot. |
| `memory-benchmarks-integrated-2026-04-26-stage2.json` | Dated benchmark snapshot. |
| `memory-benchmarks-integrated-2026-04-27-stage3of2.json` | Dated benchmark snapshot. |
| `memory-benchmarks-long-2026-04-28.json` | Dated benchmark snapshot. |
