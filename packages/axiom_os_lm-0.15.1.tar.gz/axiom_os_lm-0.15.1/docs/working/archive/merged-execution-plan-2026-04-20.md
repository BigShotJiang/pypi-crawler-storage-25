# Merged Execution Plan — Secondary Priorities (2026-04-20)

**Document type:** Execution Plan (Working Doc)
**Author:** Benjamin Booth  •  **Status:** Draft  •  **Last updated:** 2026-04-20

> **Primary focus right now is Dendra** (standalone `/dendra/` repo, Phases 1–5 + zero-dep mode + telemetry + research instrumentation). This doc captures **SECONDARY** priorities that queue behind Dendra. Nothing here should pre-empt Dendra work; the point is to have an ordered, dependency-aware backlog ready to pick up when Dendra reaches a natural checkpoint.

---

## Summary of Source Scope

This plan merges three working docs: (1) `axiom-repl-agent-framework.md` defines the REPL agent architecture (AXI/SCAN/CURIO/PRESS primaries plus TIDY/TRIAGE/RIVET services) with per-agent skill profiles and runtime profiles; (2) `curio-research-loop.md` specifies CURIO's Karpathy-style iterative research loop (formulate → search → evaluate → refine → promote), loop state, convergence, federated coordination across nodes, and proactive cross-node intelligence with `@name-agent` addressing; (3) `natural-language-policy-broadcasting.md` specifies conversational RACI governance where an authorized human speaks a directive that AXI interprets into a structured policy change propagated across an agent swarm through federation heartbeats, scoped and expiring by default. The three converge on a shared need for named agent identity, federation-aware messaging, and RACI enforcement — making the agent framework's identity/addressing layer the critical unblocking piece.

---

## Section 1 — REPL Agent Framework (`axiom-repl-agent-framework.md`)

### Already Built (brief)
- Some form of extension mechanism in `src/axiom/extensions/builtins/` with at least `chat/` (chat loop, RAG context) present per CLAUDE.md
- Core identity, federation primitives, RAG, policy engine modules scaffolded per repo structure
- `axi`/`neut` CLI surface exists
- Content filter / Mirror role retirement already reflected in architecture (PRESS absorbs; TRIAGE absorbs security)

### To-Be-Built (grouped by agent/module)

**Agent framework primitives (shared infrastructure)**
- [ ] Agent extension manifest schema `kind = "agent"` with `startup`, `heartbeat_interval`, `cli_noun`, `brandable` fields (`src/axiom/extensions/` — manifest parser + loader)
- [ ] Agent runtime loop / heartbeat scheduler (`src/axiom/agents/runtime/` — daemon + lazy startup modes)
- [ ] Agent identity + brandability layer (consumer layers rebrand AXI as "Neut" etc.)
- [ ] Named agent addressing primitive (`@name-agent`, `@owner-agent`) — Axiom-level primitive consumed by classroom + federation
- [ ] Agent invitation rules enforcement (namespaced, invitation-required, agent-proposes-human-approves, RACI exceptions) — Axiom-level primitive
- [ ] Direct-invocation routing (User → CURIO, User → SCAN, User → PRESS bypass of AXI)

**AXI (Loop) — `src/axiom/extensions/builtins/wall_e_agent/`**
- [ ] AXI agent scaffold (`wall_e_agent` extension; lazy startup, 600s heartbeat, `chat` CLI noun)
- [ ] Conversational chat skill (mode switch Ask/Plan/Agent; session persistence) — likely an evolution of `chat/`
- [ ] User relationship/profile state store
- [ ] Lifecycle orchestration (onboarding → struggling → remediation → recovery arcs)
- [ ] Briefing synthesis skill (SCAN signals + CURIO knowledge + user state)
- [ ] Check-in scheduling skill
- [ ] Help request routing + remediation planning
- [ ] Progress reporting (per-user + cohort)
- [ ] Adaptive context injection (system prompt tuned to demonstrated level)
- [ ] Workflow state machine (submissions, assessments, reviews)
- [ ] Grading queue coordination
- [ ] Course review orchestration

**SCAN (Read) — `src/axiom/extensions/builtins/signals/`**
- [ ] SCAN agent scaffold (lazy startup, 30s heartbeat, `signal` CLI noun)
- [ ] Signal extraction pipeline (voice, Teams, GitHub, GitLab, calendar, OneDrive, transcripts, feedback)
- [ ] Entity correlation (signals → people + initiatives)
- [ ] Signal RAG (lightweight ephemeral recent-events index)
- [ ] Pattern detection (engagement anomalies, stuck students, misconceptions)
- [ ] Classroom monitoring hooks
- [ ] Endpoint watchers (OneDrive, inbox, chat)

**CURIO (Eval) — `src/axiom/extensions/builtins/curio_agent/`**
- [ ] CURIO agent scaffold (lazy startup, 3600s heartbeat, `research` CLI noun)
- [ ] Autoresearch primitives: discover / read / synthesize / validate / promote
- [ ] Long-term knowledge corpus management (chunking opt, quality gating, confidence gating, generational blue/green)
- [ ] Knowledge pack lifecycle (`.axiompack` create/version/distribute/install)
- [ ] LLM-as-judge eval intelligence (grounding, faithfulness, accuracy scorers)
- [ ] Corpus-readiness analysis (coverage vs learning objectives)
- [ ] Gap research (autonomous trigger from SCAN signals / AXI requests)
- [ ] Compound knowledge loop (autonomous background promotion)
- [ ] Federated knowledge sharing hooks

**PRESS (Print) — `src/axiom/extensions/builtins/publishing/`**
- [ ] PRESS agent scaffold (daemon, 10s heartbeat, `pub` CLI noun)
- [ ] Document generation (markdown → DOCX/PDF/LaTeX/slides via Pandoc + Mermaid)
- [ ] Publish-to-endpoints (OneDrive, Box, shared spaces)
- [ ] Pull-and-reconcile (3-way merge from published docs)
- [ ] `@neut` comment handling in Word docs
- [ ] Content gate (sensitive/PII/institutional scan) — absorbs former Mirror role
- [ ] Classroom presentation publishing (WF-11)
- [ ] Report scaffolding (research paper templates)
- [ ] Submission formatting (WF-10)

**TIDY (Infra Steward) — `src/axiom/extensions/builtins/hygiene/`**
- [ ] TIDY agent scaffold (daemon, 300s heartbeat, `tidy` CLI noun)
- [ ] Vitals monitoring (CPU/mem/GPU/disk/net/power)
- [ ] Scratch retention + orphan cleanup
- [ ] Terraform + Helm infra provisioning
- [ ] K3D/container lifecycle
- [ ] Federation peer-liveness heartbeat
- [ ] LLM server lifecycle (start/stop/swap)
- [ ] Bare-metal / systemd mode (pre-K3D)

**TRIAGE (Diagnostics & Security) — `src/axiom/extensions/builtins/diagnostics/`**
- [ ] TRIAGE agent scaffold (daemon, 60s heartbeat, `doctor` CLI noun)
- [ ] LLM-powered diagnosis engine
- [ ] Security scanning (EC content in public stores, injection patterns, audit log integrity)
- [ ] Connection-health checks
- [ ] Configuration-drift audit
- [ ] Red-team validation harness for EC classifier
- [ ] `axi doctor --classroom` health check

**RIVET (CI/CD) — `src/axiom/extensions/builtins/release/`**
- [ ] RIVET agent scaffold (lazy, 300s heartbeat, `release` CLI noun)
- [ ] Pipeline monitoring (GitHub Actions + GitLab CI)
- [ ] Failure-pattern matching + suggestion engine
- [ ] Wheel build + PyPI publish
- [ ] Pre-push checks (Py 3.11 compat, naming, lint)
- [ ] Tag suggestion on green pipelines
- [ ] `axi course validate` and `axi eval run` CI gates

### Dependencies (within this doc)
- All agents depend on the shared agent framework primitives (manifest schema, runtime loop, addressing, invitation rules)
- AXI's compound cycles depend on SCAN + CURIO + PRESS being callable
- AXI is the user-facing dispatch point but direct-invocation means SCAN/CURIO/PRESS must also expose their own CLI/chat entrypoints
- PRESS's content gate depends on TRIAGE's security-scan primitives (PRESS → TRIAGE call)
- TIDY → TRIAGE anomaly escalation is a cross-agent call

### Explicit Phasing / Priority in the Doc
No explicit numbered phases. Implicit priority order from the REPL framing: AXI (protagonist, face of system) → SCAN + CURIO + PRESS (primaries) → TIDY + TRIAGE + RIVET (services). Mirror is retired; SECUR-T was never built and stays unbuilt.

---

## Section 2 — CURIO Research Loop (`curio-research-loop.md`)

### Already Built (brief)
- Some RAG store + hybrid search under `src/axiom/rag/`
- Federation primitives (cohort registry, A2A, trust graph) per CLAUDE.md ADR-026..029
- Langfuse self-host is deployed (per memory) so tracing endpoints exist

### To-Be-Built (grouped by module)

**Research Loop Engine — `axiom/src/axiom/agents/curio/loop_engine.py`**
- [ ] `ResearchLoopState` dataclass (serializable, resumable, shareable)
- [ ] `SubQuestion` dataclass with status state-machine (pending/investigating/resolved/stuck/out_of_scope)
- [ ] `ConvergenceState` dataclass (novelty_trend, confidence_trend, unresolved_contradictions, unaddressed_gaps)
- [ ] `ResearchLoopEngine.run()` main loop with convergence check
- [ ] `ResearchLoopEngine.iterate()` per-iteration pipeline
- [ ] `formulate()` phase — hypothesis + search queries + expected evidence + sub-questions
- [ ] `search()` phase — tiered source retrieval (internal → federation → external → web) with deep read/extract
- [ ] `evaluate()` phase — support score, contradiction inventory, gap inventory, confidence distribution, novelty signal
- [ ] `refine()` phase — narrow/pivot/decompose/escalate/confirm operations
- [ ] `promote()` phase — validated findings → corpus with citation chains + maturity layer bump + generation increment
- [ ] `should_converge()` decision function with hard limits (iteration/cost) + soft convergence (novelty + contradictions)
- [ ] Partial convergence handling (promote resolved sub-questions immediately)
- [ ] Loop state serialization / resume-from-disk
- [ ] Iteration budget + cost budget enforcement
- [ ] Priority queue (user-triggered > active loops > local autonomous > cross-node synthesis)

**Federation Research Protocol — `axiom/src/axiom/federation/research_protocol.py`**
- [ ] `FederatedResearchCoordinator` class scaffold
- [ ] `initiate()` — broadcast research topic + scope; returns coordination_id
- [ ] `distribute_sub_questions()` with peer-coverage analysis + optimal assignment
- [ ] `exchange_findings()` with access-tier filtering
- [ ] `merge()` — cross-node finding merge + conflict resolution + global hypothesis update
- [ ] `check_global_convergence()` — local convergence + no unresolved cross-node contradictions
- [ ] Coordination modes: Mode 1 (loose/independent sharing), Mode 2 (coordinated distribution), Mode 3 (lockstep)
- [ ] Access-tier enforcement in research messages (public flows freely; restricted honours trust; EC signals existence only)
- [ ] `federation_research_message` schema (research_finding, research_suggestion, research_proposal, contradiction_alert)

**Research Digests (P2P awareness) — `axiom/src/axiom/federation/research_digest.py`**
- [ ] `research_digest` message format (active_loops, validated_findings, corpus_coverage)
- [ ] Digest exchange on federation heartbeat
- [ ] Local view of federation research landscape per node
- [ ] Gossip-style transitive awareness (two-hop summaries with permission)
- [ ] Access-tier-aware digest redaction (see topic exists, not details)

**Proactive Cross-Node Intelligence**
- [ ] Mode A: "I know something relevant" — idle CURIO scans peer loop metadata, suggests sources (`research_suggestion` message)
- [ ] Mode B: "Your findings + my findings = a new question" — cross-node synthesis generates `research_proposal`
- [ ] Mode C: "I see a contradiction" — cross-node tension detection → `contradiction_alert`
- [ ] Named CURIO conversational addressing (`@ben-curio`, `@ondrej-curio`) — human-observable agent-to-agent dialogue
- [ ] Rate-limited background scanner for proactive modes (lowest priority on the queue)

**Langfuse Integration**
- [ ] Per-iteration trace emission (spans: formulate/search/evaluate/refine; generations per LLM call)
- [ ] Scores: novelty_score, confidence, source_count, contradiction_count
- [ ] Metadata: loop_id, iteration, sub_questions resolved this iteration

**Eval Integration**
- [ ] `research-loop-quality` eval suite (convergence quality, contradiction handling, source diversity, confidence targets)
- [ ] `federated-research-quality` eval suite (cross-pollination count, combined-sources>any-single, convergence-faster-than-single)
- [ ] LLM-judge rubric for research-loop quality
- [ ] Planted-contradiction test cases

**Classroom / Instructor-Facing Surfaces**
- [ ] Per-student loop state visibility for instructors
- [ ] Cross-pollination graph visualization
- [ ] Collective coverage map
- [ ] Contradiction inventory for class discussion
- [ ] Classroom-scoped Mode-1 federation (loose coupling, student nodes)

**Autonomous Daemon Mode**
- [ ] Always-on CURIO background scanner (checks maturity, signals, external updates, peer promotions)
- [ ] Cost-budget rate limiting (daily/weekly caps)
- [ ] Priority queue between user research, active loops, autonomous, cross-node

**RACI Autonomy Defaults (from the doc)**
- [ ] Default RACI policy for each autonomy behavior (receive/suggest/propose/flag/auto-start/invite/accept) with user-configurable override

### Dependencies
- Loop engine depends on RAG retrieval (existing) + LLM gateway (existing)
- Federation protocol depends on A2A + cohort registry + trust graph (existing per CLAUDE.md)
- Research digests depend on federation heartbeat infrastructure
- Proactive cross-node intelligence depends on digests + named-agent addressing (pulled from Section 1)
- Eval suites depend on eval framework + loop engine
- Classroom visibility depends on loop state serialization + federation Mode 1

### Explicit Phasing / Priority in the Doc
Doc frames the single-node loop as foundational, then federated coordination, then proactive cross-node intelligence as "the multiplier." Classroom is positioned as the "proving ground." Implicit order: single-node engine → Langfuse integration → Mode-1 classroom federation → Mode-2 multi-institutional coordination → proactive cross-node (Modes A/B/C) → autonomous daemon mode.

---

## Section 3 — Natural-Language Policy Broadcasting (`natural-language-policy-broadcasting.md`)

### Already Built (brief)
- RACI model exists (per the doc's explicit "exists" note)
- Federation and policy-engine scaffolds exist per repo structure

### To-Be-Built (grouped by module)

**Addressing & Scope**
- [ ] `@agent` addressing resolution (own instance)
- [ ] `@name-agent` resolution to specific named instance (shared with Section 1's named-agent primitive)
- [ ] `@all-<agent-type>` scope resolution (every instance of type in current scope)
- [ ] `@all-agents` scope resolution
- [ ] Authorization layer — only authorized roles (instructor/PI/admin) can invoke `@all-*`

**AXI Interpretation Capability**
- [ ] Natural-language → structured-RACI-update interpreter in AXI
- [ ] Scope inference from context (classroom / federation / 1:1)
- [ ] Expiry inference + explicit-override ("for the next hour", "until I say otherwise", "for this assignment")
- [ ] Confirmation UX (show interpreted policy diff, require y/N before propagation)
- [ ] Revocation handling (`return to default permissions` → reset to Course/project manifest defaults)

**Propagation via Federation Heartbeat**
- [ ] Policy-change message type on the federation heartbeat channel
- [ ] Near-instant direct-peer propagation
- [ ] Gossip-cycle propagation to transitive peers
- [ ] Per-agent RACI-state updater that applies incoming policy changes

**Period / Scope Boundaries**
- [ ] Period boundaries (classroom period, session, explicit time window)
- [ ] Automatic expiry — grants die when scope ends (no permission creep)
- [ ] Classroom-scope vs global-scope distinction (cohort grants don't leak to student's global node)

**Audit**
- [ ] Audit log for every policy broadcast: who said it, AXI's interpretation, what changed, when it expires
- [ ] Queryable audit trail ("why could agents do X during that period?")

**Open-Question Resolutions (flagged in doc)**
- [ ] Confirmation policy: tightening vs loosening asymmetry
- [ ] Conflict resolution between two authorized humans (last-write-wins vs role precedence)
- [ ] Delegation (instructor → TA with scoped delegation)

### Dependencies
The doc is explicit about prerequisites:
- RACI model (exists)
- `@agent` addressing (designed, not yet implemented) — **shared with Sections 1 & 2**
- Federation heartbeat with digest exchange (designed, not yet implemented) — **shared with Section 2**
- Period/scope boundaries (designed, not yet implemented)
- AXI natural-language → structured-policy interpretation (new capability) — **requires AXI from Section 1**

### Explicit Phasing / Priority in the Doc
Explicitly labeled "Advanced feature" and "post-MVP." Classroom MVP (Prague summer 2026) uses static RACI defaults from the Course manifest. Natural-language broadcasting replaces manual configuration with conversational governance *after* the MVP proves out.

---

## Integration Seams (where two or three source docs converge)

**Seam 1: Named-agent addressing** (`@name-agent`) — required by all three docs.
- Section 1 names it as an Axiom-level primitive (agent invitation rules).
- Section 2 needs it for `@ben-curio`/`@ondrej-curio` conversational federation and for `@all-curios` cohort broadcasts.
- Section 3 builds its entire addressing table on it.
- **Implication:** build this primitive once, in the agent framework, and have the other two consume it. Do not re-implement in classroom or federation layers.

**Seam 2: Federation heartbeat + research digest exchange**
- Section 2 introduces the digest format for research awareness.
- Section 3 reuses the same heartbeat channel for policy-change propagation.
- **Implication:** the heartbeat subsystem should expose a pluggable message-type registry so research digests and policy broadcasts ride the same transport.

**Seam 3: AXI is the interpreter**
- Section 1 defines AXI's identity and runtime profile.
- Section 3 depends on AXI's natural-language-to-RACI interpretation.
- Section 2 routes through AXI for user-facing orchestration (though direct invocation to CURIO is also allowed).
- **Implication:** AXI must ship before natural-language policy broadcasting can. It does not need to ship before CURIO's core loop (direct invocation path).

**Seam 4: RACI + period/scope boundaries**
- Section 2 defines RACI defaults for autonomy behaviors.
- Section 3 depends on RACI + scope boundaries for scoped/temporary grants.
- Classroom consumes both.
- **Implication:** the RACI engine needs a first-class notion of scope (classroom/federation/session/global) and expiry. Build this as a platform primitive, not inside any single extension.

**Seam 5: CURIO's eval intelligence and the eval framework**
- Section 1 lists "Eval intelligence" as a CURIO skill.
- Section 2 defines concrete eval suites (research-loop-quality, federated-research-quality) that need CURIO as the judge.
- **Implication:** wire CURIO's `validate` primitive to the eval framework early; it is required to score its own research loops.

**Seam 6: PRESS content gate ↔ TRIAGE security scan**
- Section 1 explicitly routes PRESS → TRIAGE before publish.
- Also relevant when CURIO (Section 2) publishes federated research reports that may contain restricted/EC citations.
- **Implication:** the content-gate / security-scan interface must be stable before CURIO's federated report output is wired up.

---

## Proposed Build Order (queues behind Dendra)

Dendra (Phases 1–5 + zero-dep mode + telemetry + research instrumentation) takes priority over everything below. Items marked *parallelizable with Dendra* have low-enough shared surface area to run concurrently if capacity allows.

### Stage 0 — Platform primitives (unblocks everything else)
1. **Named-agent addressing primitive** (`@name-agent`, `@all-<type>`, `@all-agents`) in the agent framework. Seam 1. *Parallelizable with Dendra* — pure Axiom platform work, doesn't touch Dendra surface.
2. **Agent extension manifest schema + runtime loop** (heartbeat scheduler, lazy/daemon modes). Prerequisite for every agent. *Parallelizable with Dendra.*
3. **RACI scope + expiry layer** — period/scope boundaries, automatic-expiry semantics, classroom-scope vs global-scope. Seam 4. *Blocks Section 3 entirely.*
4. **Federation heartbeat message-type registry** — pluggable so digests and policy broadcasts ride the same transport. Seam 2. *Blocks the federated parts of Sections 2 & 3.*

### Stage 1 — AXI first (protagonist)
5. AXI scaffold + conversational chat skill (evolve `chat` into `wall_e_agent`) + user relationship store + direct-invocation router. Dispatch targets (SCAN/CURIO/PRESS) can be stubs that return "not yet built" — AXI still works as a chat surface.
6. AXI lifecycle orchestration + briefing synthesis scaffolds (call-sites open even if SCAN/CURIO not yet built).

### Stage 2 — CURIO single-node loop (the flywheel starts here)
7. Research Loop Engine: state + iterate() + formulate/search/evaluate/refine/promote single-node. No federation yet.
8. Convergence decision function + partial convergence + loop state serialize/resume.
9. Langfuse integration for per-iteration traces.
10. Research-loop-quality eval suite (single-node scope). Seam 5.
11. CURIO agent scaffold + `research` CLI + autoresearch primitives wrapper around the engine.

*At this point, a single-node CURIO produces auditable iterative research. This is the "flywheel starts spinning" milestone.*

### Stage 3 — SCAN + PRESS (round out the REPL)
12. SCAN scaffold + signal extraction + signal RAG + classroom monitoring. (Enables AXI compound cycles.)
13. PRESS scaffold + document generation + publish-to-endpoints + content gate.
14. TRIAGE scaffold (security scan primitives needed by PRESS content gate). Seam 6.

### Stage 4 — Federated research (Mode 1 loose coupling first)
15. Research-digest format + digest exchange on heartbeat.
16. Federation Research Protocol Mode 1 (independent-with-sharing). Classroom-first proving ground.
17. Cross-pollination visibility for instructors (loop-state inspection, coverage map, contradiction inventory).
18. Federated-research-quality eval suite. Seam 5.

### Stage 5 — Proactive cross-node intelligence
19. Mode A: "I know something relevant" (source suggestion).
20. Mode B: "Your findings + mine = new question" (research proposal).
21. Mode C: "I see a contradiction" (contradiction alert).
22. Named CURIO conversational dialogue UX (`@ben-curio` visible to user).
23. Priority queue + rate limiting for proactive modes.

### Stage 6 — Mode 2/3 federation + autonomous daemon
24. Federation Research Protocol Mode 2 (coordinated sub-question distribution).
25. Federation Research Protocol Mode 3 (lockstep).
26. CURIO always-on autonomous daemon + cost-budget caps.

### Stage 7 — Natural-language policy broadcasting (explicitly post-MVP)
27. AXI natural-language → structured-RACI interpreter.
28. Scope inference + expiry inference + confirmation UX.
29. Policy-change propagation on heartbeat (reuses Stage 0 #4).
30. Audit log for policy broadcasts.
31. Resolutions for the doc's open questions (confirmation asymmetry, conflict resolution, delegation).

### Stage 8 — Supporting agents (can slot in opportunistically)
- TIDY scaffold + vitals + scratch + infra provisioning + bare-metal mode.
- RIVET scaffold + pipeline monitoring + wheel build + tag suggestion.
- TRIAGE extensions beyond security scan (diagnosis, config audit, red-team validation, classroom health check).

### What's Blocked on Dendra
- **Research instrumentation integration** — Dendra's telemetry / research instrumentation is the immediate proving ground for CURIO's Langfuse integration and eval suites; aligning the schemas once Dendra stabilizes avoids double work. Hold Stage 2 items #9–#10 on final wiring until Dendra telemetry format is frozen.
- **Zero-dep-mode ergonomics** — If Dendra establishes a zero-dep pattern, Stage 1 AXI scaffold should adopt the same ergonomics (no new pattern divergence).
- **Classroom Prague proving ground timing** — Stage 4 federated research and Stage 7 natural-language broadcasting both target classroom use. Classroom MVP currently plans static RACI defaults; Stage 7 explicitly waits on post-MVP per Section 3.

### What Can Run in Parallel with Dendra
- Stage 0 platform primitives (items 1–4) are pure Axiom work with minimal Dendra surface.
- Stage 1 AXI scaffold can start once named-agent addressing lands, with dispatch targets stubbed.
- Documentation ADRs for the seams (named-agent addressing; RACI scope/expiry; heartbeat message-type registry) can be drafted concurrently.

---

_Copyright (c) 2026 The University of Texas at Austin and B-Tree Labs. Apache-2.0 licensed._
