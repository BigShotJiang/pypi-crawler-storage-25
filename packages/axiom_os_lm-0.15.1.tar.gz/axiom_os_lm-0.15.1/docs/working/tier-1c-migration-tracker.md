# Tier 1c Migration Tracker — Extensions → AEOS + Axiomatic Way

**Status:** In flight  •  **Owner:** Benjamin Booth  •  **Last updated:** 2026-04-23

Source of truth for the Tier 1c extension-migration sweep. Every current `src/axiom/extensions/builtins/*` directory is accounted for here — rename, layout-migrate, delete, or defer — with rationale. Update as each PR lands.

Decisions locked in the 2026-04-22 → 2026-04-23 sessions:

- **Naming stance 1 (strict purpose-named).** Extensions named for what they DO, not for the agent they house. Agents stay canonical under ALL-CAPS-HYPHEN.
- **Memory workstream is its own track** — `memory_cmd/` narrow-renames to `memory-ops/` to reserve the canonical `memory/` slot for the Cognee-informed memory extension design.
- **Consumer-layer rebranding is architecture, not docs.** AXI / Neut lives here; Neut-specific code goes to `Neutron_OS/`.
- **Skills loop is closed** (commit `167b55f`). Each migration must split the existing `SKILLS.md` into agent `persona.md` (internal) + standalone `skills/<name>/SKILL.md` where appropriate.
- **No force-push. Local commits only.**

---

## Purpose-rename + layout-migrate

Extensions that rename to a purpose-name AND restructure to AEOS §5.1 compound layout (`<ext>/<ext>/` package + `docs/`, `tests/`, `agents/<name>/persona.md`, `skills/<name>/SKILL.md` where applicable).

| Current | Target | Agent(s) inside | Rationale | Status |
|---|---|---|---|---|
| `dfib_agent/` | `diagnostics/` | TRIAGE | "Diagnostics + security" is the purpose; TRIAGE is the agent that does it | [x] landed 2026-04-24 |
| `eve_agent/` | `signals/` | SCAN | SCAN reads signals; `signals/` names the Read role's purpose | [x] landed 2026-04-24 |
| `curio/` (under `src/axiom/agents/`) | `research/` | CURIO | Research / knowledge engine; CURIO is the Eval agent in the REPL | [x] landed 2026-04-24 |
| `prt_agent/` | `publishing/` | PRESS | Document lifecycle + content gate; PRESS is the Print agent | [x] landed 2026-04-24 |
| `mo_agent/` | `hygiene/` | TIDY | Resource stewardship, retention, infra cleanup — naming tentative | [x] landed 2026-04-24 |
| `burn_e_agent/` | `release/` | RIVET | CI/CD, build, publish, tagging; RIVET is the agent (needs real implementation) | [x] landed 2026-04-24 (rename + conformance only; pipeline-monitoring loop pending — TODO in persona) |

**Open naming questions** (proposed, may rename during migration):

- `mo_agent/` → `hygiene/` or `operations/` or `stewardship/`? TIDY's scope is vitals + retention + infra provisioning + peer liveness. "Hygiene" matches the agent's original framing but may be too narrow; "operations" overlaps with system ops log.
- `eve_agent/` → `signals/` vs `observation/` vs `intake/`? All three describe the Read role; `signals/` is the shortest and matches the existing CLI noun (`axi signal`).

---

## Layout-only migrate (no rename)

Extensions with AEOS-clean names that still need the compound layout (`<ext>/<ext>/` nesting, co-located docs/tests, manifest normalization).

| Extension | Notes | Status |
|---|---|---|
| `agents/` | Legacy singular dir under builtins/; retained as the always-on agents service-lifecycle extension | [x] landed 2026-04-24 |
| `classroom/` | Keplo's home; stays; CHALKE persona at `classroom/agents/chalke/persona.md`; eventual extraction to own repo | [x] landed 2026-04-24 |
| `connect/` | Connection framework (OneDrive, Teams, etc.) | [x] landed 2026-04-24 |
| `db/` | Database primitives | [x] landed 2026-04-24 |
| `directive/` | Directive handling — verify current scope | [x] landed 2026-04-24 |
| `federation/` | Vega pre-extraction. Core primitives moved to `src/axiom/vega/{federation,identity}/` via ADR-031 Phase 3 in commit `06ebed3`; the `sys.modules` aliasing shims at `axiom.{federation,identity}` were removed and every importer rewritten to the canonical `axiom.vega.{federation,identity}.*` paths (per the no-shim rule, since we have no external users). The built-in extension at `src/axiom/extensions/builtins/federation/` itself is a CLI-wrapper consumer; its AEOS-conformance pass is pending the sister session per `prompt-classroom-federation-migration.md`. | [~] partial — primitives consolidated, shims removed; extension AEOS-pass pending |
| `ide/` | `axi ide` — IDE setup across VS Code/Cursor/PyCharm/nvim | [x] landed 2026-04-24 |
| `install/` | Install primitives | [x] landed 2026-04-24 |
| `log/` | Logging primitives | [x] landed 2026-04-24 |
| `note/` | Note-taking | [x] landed 2026-04-24 |
| `rag/` | Core RAG — check whether it stays as extension or promotes to core module | [x] landed 2026-04-24 (stays as extension; still has a Box `[[connections]]` bridge entry) |
| `repo/` | Repository management | [x] landed 2026-04-24 (added a `tool` provides since it has no CLI noun) |
| `settings/` | Settings primitives | [x] landed 2026-04-24 |
| `status/` | Status reporting | [x] landed 2026-04-24 |
| `test/` | Testing primitives — verify scope | [x] landed 2026-04-24 |
| `update/` | Update lifecycle | [x] landed 2026-04-24 |

---

## Narrow rename (reserve canonical name)

| Current | Target | Rationale | Status |
|---|---|---|---|
| `memory_cmd/` | `memory/` | Drops the `_cmd` directory suffix; the extension is the durable home for the memory concept and grows as Cognee-inspired work lands | [x] landed 2026-04-24 |
| `web_api/` | (merged into `http/`) | The Keplo session shipped `http/` first with FastAPI library scope; web_api/ had a stdlib chat HTTP API + federation-RAG endpoint. Decision: merge — `web_api/server.py` → `http/chat_server.py`, `web_api/federation_endpoint.py` → `http/federation_endpoint.py`, `web_api/cli.py` → `http/serve_cli.py`, `web_api/static/` → `http/static/`. `web_api/` deleted. `axi serve` cmd noun is now declared on `http/`. | [x] landed 2026-04-24 |

**`http/` is load-bearing:** once it exists, `axi classroom serve` migrates off its baked-in HTTP server onto the shared `http/` extension. `http/` is also the natural home for the eventual mature-OSS-server swap (`project_http_capability_refactor.md`).

---

## Delete

Extensions to remove rather than migrate.

| Extension | Rationale | Status |
|---|---|---|
| `mirror_agent/` | Retired per `axiom-repl-agent-framework.md`. Content gate absorbed into PRESS; security scanning into TRIAGE. | [x] landed 2026-04-24 |
| `neut_agent/` | Dissolve per 2026-04-23 decision. Generic chat functionality absorbs into the new `chat/` extension hosting AXI; NeutronOS-specific branding / behavior lives in `Neutron_OS/`. | [x] landed 2026-04-24 (renamed to chat/, manifest already used `name = "chat"`; consumer-layer rebranding tracked separately) |

---

## New — create (not migrations proper)

| New extension | Reason | Notes | Status |
|---|---|---|---|
| `chat/` | Primary conversational agent home — AXI lives here | Absorbs generic functionality from the dissolving `neut_agent/`; consumer layers rebrand (Neut in NeutronOS) | [x] landed 2026-04-24 (became chat/ via the neut_agent rename — same row in practice) |
| `http/` | Shared HTTP capability per Axiomatic Way #6 | Provides server, middleware, TLS, health endpoints; classroom's `serve` migrates onto it; evaluate OSS replacement for the custom server | [ ] |
| `memory/` (eventual) | Cognee-informed memory extension with tier profiles (Edge/Workstation/Server/Platform) | Separate track; NodeSet + memify principles now, KG-layer swap post-Prague — `project_cognee_assessment.md` | [ ] |

---

## Execution order (proposed)

Least risky first. Pick up, migrate, run `axi ext lint` + `axi ext validate` + `axi ext test` + `axi ext scan` on each result, commit, next.

1. **`dfib_agent/` → `diagnostics/`** — smallest, self-contained, exercises the full migration tool stack first.
2. **`mirror_agent/` DELETE** — one-line decision, proves the delete path is clean.
3. **`neut_agent/` DELETE + `chat/` CREATE** — coupled step; absorbing generic functionality into AXI's new home.
4. **`memory_cmd/` → `memory-ops/`** — narrow rename, reserves canonical slot.
5. **`web_api/` → `http/`** (create + migrate `axi classroom serve`) — establishes the shared-primitive pattern for the rest.
6. **`mo_agent/`, `prt_agent/`, `eve_agent/`** — purpose-renames with persona/skill split.
7. **`burn_e_agent/` → `release/`** — includes the real-implementation push; RIVET currently doesn't run.
8. **`curio/` → `research/`** — verify current location under `src/axiom/agents/` before moving.
9. **Layout-only batch** — `connect/`, `db/`, `directive/`, `ide/`, `install/`, `log/`, `note/`, `repo/`, `settings/`, `status/`, `test/`, `update/`, `agents/`, `rag/` — smaller individual touches, may batch by type.
10. **`classroom/`** — coordinate with Keplo extraction planning; largest and most entangled.
11. **`federation/` → `src/axiom/vega/`** — Vega pre-extraction per ADR-031; separate ticket, not part of this sweep.

---

## Discipline per migration

For every row that moves:

1. Land the migration on a short-lived branch off `main` (name: `feat/migrate-<ext>`).
2. Use `axi ext migrate --to-aeos-layout` as the starting point; `git mv` for the rename to preserve history.
3. Split the current `SKILLS.md` into `agents/<agent>/persona.md` (internal identity) + `skills/<skill>/SKILL.md` (standalone procedural) per the Axiomatic Way #5. Where the current SKILLS.md is role description only, it becomes `persona.md`; where it describes reusable procedural steps, factor those out.
4. Wire `weave_agent_skills()` into the agent's `_build_system_prompt()` (pattern from `src/axiom/agents/skills_runtime.py`).
5. Verify: `axi ext lint`, `axi ext validate`, `axi ext test`, `axi ext scan`.
6. One commit (or tight series) per migration. Commit message calls out what was split, what was absorbed, what was deleted.
7. Update this tracker in the same commit — check the box, note any discovered gaps.
8. Merge to `main` via fast-forward when clean. No push.

---

## Discovered gaps (filled as we go)

*Each migration may surface gaps in the CLI tooling, the AEOS spec, or the Axiomatic Way doctrine. Capture them here with a date and a pointer so we don't lose them.*

- 2026-04-23 — HTTP shared primitive is load-bearing and not yet built. `http/` creation is a prerequisite for `axi classroom serve` migration. (`project_http_capability_refactor.md`)
  - **2026-04-24 update**: parallel session built `http/` with FastAPI (flat layout, `builtin=true` in manifest). Functional but not AEOS-conformance-tested. Integration with `axi classroom serve` still pending.
- 2026-04-23 — Skills runtime loop closed (`167b55f`) but agents have no real SKILL.md files yet. Each migration creates at least one standalone skill as a forcing function.
- 2026-04-23 — RIVET's spec exists but the agent doesn't run. `release/` creation must ship a working RIVET, not just a migration.
- 2026-04-24 — **Compound-nest vs flat-layout conflict surfaced by triage migration.** AEOS spec §5.1 + conformance tools (`axi ext lint`, `axi ext scan`, `ExtensionStandardTests`) expect the double-nested layout: `<ext>/<ext>/__init__.py`. But every existing built-in (including the just-created `http/`) uses flat: `<ext>/__init__.py`. Resolution needed before further migrations: either (a) refactor all built-ins to the double-nest and accept the long-form imports like `axiom.extensions.builtins.diagnostics.diagnostics.agent:DoctorAgent`, or (b) update the conformance tools to recognize flat-layout built-ins by their location under `extensions/builtins/`. **Diagnostics migration landed in flat layout per http/ precedent**; lint/scan/test-standard fail on compound-layout checks but the code is functional and all non-conformance tests pass.
- 2026-04-24 — **AEOS manifest schema rejects `builtin = true`** (`additionalProperties: false`). Existing discovery code expected the field; updated `test_all_builtins_parse_successfully` to not require it. If "builtin" remains a useful concept, either add it to the schema or infer it from directory location.
- 2026-04-24 — **`axi ext migrate --to-aeos-layout` tool needs work.** Strips `_agent` suffix mechanically (produces `triage/`, not the purpose-name `diagnostics/`); generates the compound double-nest that doesn't match built-in layout; doesn't split SKILLS.md into persona.md + standalone skills; reports "N unmapped files" without saying which. First migration was done manually; tool upgrades should land before the remaining renames to keep them cheap.
- 2026-04-24 — **`docs/`, `README.md`, `CHANGELOG.md`, `LICENSE` required by AEOS but absent in built-ins.** Diagnostics added them minimally; pattern-for-built-ins needs codifying.
- 2026-04-24 — **AEOS schema's strict root `additionalProperties: false` blocked the eve_agent → signals migration** because SCAN's manifest contains `[[cli.commands]]`, `[agent]`, `[[agent.watchers]]`, `[[connections]]` blocks at root that the runtime CLI/agent/connection registries still consume. Resolution: relaxed root `additionalProperties` to `true` in `aeos-manifest-0.1.json`, with a `$comment` describing transitional intent. Bridge in `contracts.py::parse_manifest` translates `[[extension.provides]] kind = "cmd"` blocks to legacy `CLICommandDef` so future migrations can drop the `[[cli.commands]]` block once their nouns are migrated everywhere they're consumed. The legacy `[agent]`/`[[connections]]` blocks remain a parity gap.
_Copyright (c) 2026 The University of Texas at Austin and B-Tree Labs. Apache-2.0 licensed._
