# Execution Plan: Vega Extraction

**Plan:** Extract Vega from Axiom as a standalone product with its own repo, package, branding, and commercial terms
**Owner:** Benjamin Booth
**Status:** Ready to execute — starts after Dendra extraction completion
**Last Updated:** 2026-04-21
**Parent Docs:** [prd-vega.md](../prds/prd-vega.md), [spec-vega.md](../specs/spec-vega.md)

---

## 1) Sequencing Context

Vega extraction follows Dendra extraction. Dendra is simpler (already standalone; Axiom Labs-owned; no OTC dependency). Vega is more complex (cross-entity IP, architectural coupling, larger surface area). Lessons from Dendra inform Vega.

**Prerequisites:**
- Dendra extraction completed and shipping on PyPI
- B-Tree Ventures DBA "Axiom Labs" filed
- UT Office of Technology Commercialization (OTC) engagement initiated (Phase A.2 of repo-split plan)
- Contributor attribution audit complete for `axiom/src/axiom/federation/`, `security/`, `identity/`
- Architectural boundaries enforced via import-linter (prevents coupling regression)
- AXI / Keplo workflow dependency ADR drafted (resolution can follow Vega extraction but tracking is needed)

---

## 2) Extraction Phases

### Phase V1: Pre-extraction preparation (1-2 weeks)

Goal: make extraction mechanical when it happens.

#### V1.1 Contributor attribution audit

Run `git log --pretty=format:"%an %ae %s" -- src/axiom/federation src/axiom/security src/axiom/identity` in the Axiom repo. For each contributor:

- Identify as UT employee on UT time (→ UT-owned contribution)
- Identify as B-Tree Ventures work outside UT (→ Axiom Labs contribution)
- Flag ambiguous cases for OTC resolution

Document results in a private file (not committed to any repo yet). This file becomes evidence for OTC licensing negotiations.

#### V1.2 API surface hardening

Identify the public API surface Axiom will consume from Vega post-extraction. For each symbol, decide:

- Public (semver-committed, documented, stable)
- Semi-public (internal but exposed; targeted for stabilization)
- Private (renamed with `_` prefix before extraction)

Run `ast`-based analysis to find every external import of Vega-destined modules. Stabilize signatures; add type stubs where missing; document each public API in its module docstring.

#### V1.3 Import boundary enforcement

Add to `axiom/.importlinter`:

```ini
[importlinter:contract:vega-cannot-import-axiom-internals]
name = Vega-destined code must not import Axiom internals
type = forbidden
source_modules = axiom.federation, axiom.security, axiom.identity
forbidden_modules = 
    axiom._private
    axiom.extensions
    axiom.infra.prompt_composer
    axiom.rag
    axiom.memory._internal
```

Vega-destined code can only import from `axiom`'s public APIs (Config, CompositionService, Storage interfaces). Violations block CI. This forces architectural cleanup before extraction.

#### V1.4 AXI / Keplo coupling ADR

Draft an ADR documenting the workflow-coupling architectural debt:

**ADR number:** TBD (next available)
**Title:** Separation of AXI (generic orchestration) from Keplo workflows
**Status:** Proposed
**Context:** AXI currently handles classroom workflow execution (WF-1 through WF-11), which creates a latent dependency on Keplo being installed. Keplo is an optional extension; this coupling is architecturally incorrect.
**Decision:** AXI provides generic workflow primitives; Keplo owns classroom-specific workflow definitions; optional Keplo sub-agent handles classroom orchestration using AXI's primitives.
**Consequences:** Keplo extraction requires workflow refactor. Deferred until after Vega extraction (don't block Vega on Keplo debt).

This ADR does not block Vega. It flags the debt for the Keplo extraction phase.

#### V1.5 License header audit

Ensure every file in `federation/`, `security/`, `identity/` has the correct copyright:

```python
# Copyright (c) 2026 The University of Texas at Austin.
# Apache-2.0 licensed.
# 
# This file is part of Vega, an open-source trust infrastructure for
# agentic AI. Vega is owned by The University of Texas at Austin.
# Commercial support available through Axiom Labs (B-Tree Ventures, LLC).
```

Apply via script, verify each file, commit.

#### V1.6 GitHub org creation

UT-managed org exists or is created (coordinate with UT IT — they may have existing orgs like `ut-austin-ne` or require a new one specifically for commercialized research software).

Axiom Labs org exists as `axiom-labs` on GitHub.

Configure org-level:
- Two-factor auth required
- Dependabot, CodeQL enabled by default
- Branch protection templates
- SSO if UT requires

#### V1.7 OTC engagement memo

Submit memo to UT OTC with:

- Portfolio structure (six products, IP split per `brand-product-strategy.md`)
- Vega-specific positioning, timeline, commercial projection
- Proposed commercial terms: exclusive license to Axiom Labs for commercial-tier features; Apache 2.0 OSS remains UT property
- Royalty structure proposal: percentage of Axiom Labs' Vega-derived revenue

Expected response: 6-12 weeks. Extraction Phase V2 proceeds for open-source-only work; commercial-tier features gated on OTC.

---

### Phase V2: Repository extraction (1-2 weeks)

Goal: physical code move.

#### V2.1 Create Vega repository

```bash
gh repo create ut-austin-ne/vega \
  --public \
  --description "Vega — trust infrastructure for agentic AI" \
  --license apache-2.0
```

#### V2.2 Extract code history via git-filter-repo

```bash
cd /tmp
git clone /Users/ben/Projects/UT_Computational_NE/axiom vega-extraction
cd vega-extraction

# Extract only the paths destined for Vega, with path renaming
git filter-repo \
  --path src/axiom/federation/ \
  --path src/axiom/security/ \
  --path src/axiom/identity/ \
  --path-rename src/axiom/federation/:src/vega/federation/ \
  --path-rename src/axiom/security/:src/vega/trust/ \
  --path-rename src/axiom/identity/:src/vega/identity/ \
  --path tests/federation/ \
  --path tests/security/ \
  --path tests/identity/ \
  --path-rename tests/federation/:tests/federation/ \
  --path-rename tests/security/:tests/trust/ \
  --path-rename tests/identity/:tests/identity/

git remote add origin git@github.com:ut-austin-ne/vega.git
git push -u origin main
```

Preserves contributor history and commit messages for attribution.

#### V2.3 Bootstrap Vega package

Create `vega-trust/pyproject.toml`:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "vega-trust"
version = "0.1.0"
description = "Trust infrastructure for agentic AI"
readme = "README.md"
license = "Apache-2.0"
requires-python = ">=3.11"
authors = [
    {name = "The University of Texas at Austin"},
]
maintainers = [
    {name = "Benjamin Booth", email = "bbooth@utexas.edu"},
]
keywords = ["agents", "trust", "federation", "governance", "security"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: Apache Software License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Programming Language :: Python :: 3.14",
    "Topic :: Security",
    "Topic :: System :: Distributed Computing",
]
dependencies = [
    "cryptography>=42",
    "pynacl>=1.5",
    "httpx>=0.27",
    "pydantic>=2.7",
    "authlib>=1.3",        # OIDC
]

[project.optional-dependencies]
server = [
    "fastapi>=0.110",
    "uvicorn>=0.27",
    "grpcio>=1.60",
]
dev = [
    "pytest>=8",
    "pytest-cov>=5",
    "pytest-asyncio>=0.23",
    "ruff>=0.4",
    "mypy>=1.10",
]
verify = []  # minimal; just cryptography

[project.urls]
Homepage = "https://vega-trust.dev"
Documentation = "https://docs.vega-trust.dev"
Repository = "https://github.com/ut-austin-ne/vega"

[project.scripts]
vega = "vega.cli.main:main"

[tool.hatch.build.targets.wheel]
packages = ["src/vega"]
```

Adjust `src/vega/__init__.py` to expose the public API:

```python
"""Vega — trust infrastructure for agentic AI."""

from vega.identity import Keypair, Principal, OIDCValidator
from vega.trust import TrustProfile, RaciGate, RaciDecision
from vega.classification import ClassificationStamp, filter_by_ceiling
from vega.verify import verify_signature

__version__ = "0.1.0"

__all__ = [
    "Keypair",
    "Principal",
    "OIDCValidator",
    "TrustProfile",
    "RaciGate",
    "RaciDecision",
    "ClassificationStamp",
    "filter_by_ceiling",
    "verify_signature",
]
```

Federation imports are lazy (expensive; require server extras).

#### V2.4 PyPI name reservation

Reserve `vega-trust` on PyPI immediately:

```bash
cd vega-extraction
python -m build
twine upload --repository-url https://upload.pypi.org/legacy/ dist/*
```

If `vega-trust` is taken, fallback to `vegatrust` or `vega-infra`. Check pypi.org/project/{name} first.

#### V2.5 Axiom consumes Vega

In `axiom/pyproject.toml`:

```toml
dependencies = [
    ...
    "vega-trust>=0.1.0,<0.2.0",
]
```

Remove `src/axiom/federation/`, `src/axiom/security/`, `src/axiom/identity/` from Axiom repo:

```bash
cd /Users/ben/Projects/UT_Computational_NE/axiom
git rm -r src/axiom/federation/ src/axiom/security/ src/axiom/identity/ tests/federation/ tests/security/ tests/identity/
git commit -m "refactor: extract federation/security/identity to vega-trust package

Vega now ships as a standalone package (vega-trust). Axiom consumes it
as a dependency.

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>"
```

Add compatibility shims for one minor version:

```python
# axiom/src/axiom/federation/__init__.py
import warnings
warnings.warn(
    "axiom.federation has moved to vega.federation. "
    "Import from vega directly; this shim will be removed in axiom 0.16.",
    DeprecationWarning,
    stacklevel=2,
)
from vega.federation import *  # noqa: F401, F403
```

Same for `axiom.security` → `vega.trust` and `axiom.identity` → `vega.identity`.

#### V2.6 Verify Axiom tests pass

```bash
cd axiom
pip install -e ".[dev]"
pytest tests/ src/axiom/extensions/
```

If anything breaks, debug import paths. Typical issue: some internal import wasn't updated. Fix and iterate.

---

### Phase V3: CI/CD setup (1 week, parallel with V2)

Goal: professional release engineering from day 1.

#### V3.1 Vega CI workflow

Create `vega/.github/workflows/ci.yml`:

```yaml
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.11', '3.12', '3.13', '3.14']
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - run: pip install -e ".[dev]"
      - run: pytest -v --cov=vega --cov-report=xml
      - run: ruff check src/
      - run: mypy src/
      - uses: codecov/codecov-action@v4

  integration:
    runs-on: ubuntu-latest
    needs: test
    steps:
      - uses: actions/checkout@v4
      - uses: docker/setup-buildx-action@v3
      - run: docker compose -f tests/integration/docker-compose.yml up -d
      - run: sleep 15  # wait for services
      - run: pytest tests/integration/ -v
      - run: docker compose -f tests/integration/docker-compose.yml down
```

#### V3.2 Release workflow

Create `vega/.github/workflows/release.yml`:

```yaml
name: Release
on:
  push:
    tags: ['v*']
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: pip install build
      - run: python -m build
      - uses: actions/upload-artifact@v4
        with:
          name: dist
          path: dist/

  publish-pypi:
    needs: build
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
    steps:
      - uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/
      - uses: pypa/gh-action-pypi-publish@release/v1

  sign:
    needs: build
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: write
    steps:
      - uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/
      - uses: sigstore/gh-action-sigstore-python@v2
        with:
          inputs: dist/*
```

#### V3.3 Trusted publisher configuration

In PyPI account for `vega-trust`, configure Trusted Publisher linked to `ut-austin-ne/vega` → workflow `release.yml` → environment `pypi`. Eliminates long-lived API tokens.

#### V3.4 Cross-repo integration testing

In `axiom` repo, add nightly workflow testing against Vega main branch:

```yaml
name: Vega Compatibility
on:
  schedule:
    - cron: '0 6 * * *'
jobs:
  test-against-vega-main:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          repository: ut-austin-ne/vega
          path: vega
      - uses: actions/checkout@v4
        with:
          path: axiom
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: pip install -e ./vega
      - run: pip install -e "./axiom[dev]"
      - run: pytest ./axiom/tests/ -v
```

Failure is informational, not blocking. Alerts Vega team to pending breakage.

---

### Phase V4: Documentation and domain (1 week, parallel with V3)

Goal: public-facing presence by end of Phase 1 extraction.

#### V4.1 Documentation site

Set up `vega/docs/` with MkDocs Material:

```
vega/docs/
├── index.md                  # Landing
├── concepts/
│   ├── trust-profiles.md
│   ├── classification.md
│   ├── federation.md
│   └── deployment-shapes.md
├── getting-started/
│   ├── embedded-library.md   # Shape 1
│   ├── axiom-bundled.md      # Shape 2
│   ├── gateway.md            # Shape 3
│   ├── verify-only.md        # Shape 4
│   └── federation-peer.md    # Shape 5
├── integrations/
│   ├── oidc.md
│   ├── envoy.md
│   ├── dnssec.md
│   ├── sigstore.md
│   └── opentelemetry.md
├── harness-guides/
│   ├── langchain.md
│   ├── crewai.md
│   ├── llamaindex.md
│   └── hermes.md
├── api/                       # auto-generated
├── architecture/              # ADRs, spec excerpts
└── changelog.md
```

Deploy on GitHub Pages via `.github/workflows/docs.yml`. Hosted also on ReadTheDocs as redundancy.

#### V4.2 Domain acquisition

Priority order (check availability, purchase):
1. `vega-trust.dev` — $15/year, preferred primary
2. `vega-trust.io` — $50/year
3. `vegaprotocol.org` — $10/year, protective
4. `usevega.com` — $15/year, protective

Purchase 3-4 of these. Point primary at docs site.

#### V4.3 Landing page

Minimum viable landing at `vega-trust.dev`:

- Headline: "Trust infrastructure for agentic AI"
- Subheadline: "Federation, classification, and governance for AI agents. Works with any harness."
- Three-bullet value prop
- "Get Started" CTA to docs
- "Install" section with `pip install vega-trust` one-liner
- "Powered by UT Austin. Commercial support via Axiom Labs."
- Link to GitHub repo
- No marketing elaborate — just clear positioning. One page total.

#### V4.4 README

Vega's README covers:
- What Vega is (one paragraph)
- Quick-start (10 lines of Python)
- Five deployment shapes (brief descriptions)
- Integration with existing standards (bullet list)
- License (Apache 2.0)
- Institutional ownership (UT Austin) and commercial support (Axiom Labs)
- Link to docs
- Contribution guidelines (CLA required)

---

### Phase V5: Release to PyPI (1-2 days, after V2-V4)

Goal: shipped.

#### V5.1 Version tagging and release

```bash
cd vega-trust
git tag -s v0.1.0 -m "Vega 0.1.0 — initial extraction from Axiom"
git push origin v0.1.0
```

Release workflow fires, builds wheels, signs via Sigstore, publishes to PyPI.

#### V5.2 Axiom release consuming Vega

In `axiom`:

```bash
git tag -s v0.14.0 -m "Axiom 0.14.0 — now consumes vega-trust as external dependency"
git push origin v0.14.0
```

Release notes: "Vega (federation + trust + classification) has been extracted to its own package. Axiom now depends on `vega-trust>=0.1.0,<0.2.0`. Existing users upgrading from 0.13.x: no action required; dependency is pulled automatically. Direct imports of `axiom.federation`, `axiom.security`, `axiom.identity` continue to work with a deprecation warning until Axiom 0.16. Please migrate to `vega.*` imports."

#### V5.3 Announcement

- Blog post on vega-trust.dev explaining the extraction rationale
- Announcement on Axiom Labs blog (wherever that lives)
- Twitter / LinkedIn / HN post — "We've extracted Vega, the trust layer from Axiom, into its own open-source project..."
- Mention Prague deployment as first production use
- Link to research paper outline (or full draft if ready)

---

### Phase V6: Post-extraction stabilization (2-4 weeks)

Goal: make sure nothing's broken for Prague.

#### V6.1 Prague deployment uses pinned combination

For Prague summer 2026:
- `axiom==0.14.x`
- `vega-trust==0.1.x`
- `keplo` (pre-extraction; still in axiom/)
- `dendra==0.3.x` (hypothetical post-Phase-3)
- `neutronos==0.13.x`

Document the combination. Any patches during Prague target this combination specifically.

#### V6.2 Field bug reports

Set up GitHub issue templates for Vega. Monitor early. Respond fast. Early community experience shapes reputation.

#### V6.3 Security disclosure policy

Create `vega/SECURITY.md` with:
- How to report vulnerabilities (email, GPG key)
- Response SLA (24 hours acknowledgment, 90 days to fix)
- Coordinated disclosure policy
- CVE registration process

Get ahead of the "we had a vulnerability disclosure but no process" problem that plagued OpenClaw.

#### V6.4 First external contributor onboarding

Set up CLA bot (cla-assistant.io). First external PR tests the process end-to-end. Document lessons.

---

## 3) Timeline

Weeks counted from Vega extraction start (after Dendra completion):

| Week | Milestones |
|---|---|
| 1 | V1.1, V1.2, V1.3 (audit, API hardening, import boundaries) |
| 2 | V1.4-V1.7 (ADR, license headers, GitHub orgs, OTC memo) — OTC memo submitted, continues in background |
| 3 | V2.1-V2.4 (repo creation, git-filter-repo, PyPI reservation) |
| 4 | V2.5-V2.6 (Axiom consumes Vega, tests pass) + V3.1-V3.3 (CI/CD) |
| 5 | V3.4 (cross-repo testing), V4.1-V4.2 (docs site, domains) |
| 6 | V4.3-V4.4 (landing page, README), V5 (release) |
| 7-8 | V6 (post-extraction stabilization) |

Total: 7-8 weeks from start. Parallels ongoing OTC conversation (which takes longer but doesn't block OSS work).

---

## 4) Success Criteria

Phase 1 extraction is complete when:

- [ ] `pip install vega-trust` works and imports cleanly
- [ ] `pip install axiom` pulls in `vega-trust` transitively
- [ ] Axiom test suite passes without any code in `axiom/src/axiom/federation/`, `security/`, `identity/`
- [ ] Integration test: two Axiom nodes federate via Vega (Docker Compose)
- [ ] Landing page live at `vega-trust.dev` (or fallback)
- [ ] Docs site covers all five deployment shapes with working examples
- [ ] README positions Vega independently of Axiom
- [ ] Vega v0.1.0 tagged and published with Sigstore signatures
- [ ] Axiom v0.14.0 released with compatibility shims
- [ ] Prague deployment combination (axiom + vega-trust + keplo + ...) documented
- [ ] OTC memo submitted; commercial license conversation initiated

---

## 5) Risks and Mitigations

### R1: OTC approval delays commercial license

**Likelihood:** High (OTC processes take months)
**Impact:** Medium (blocks commercial tier; doesn't block OSS)
**Mitigation:** Phase 1 is OSS-only. Commercial tier launches in Phase 3 (Q4 2026 / Q1 2027). OTC timeline fits that window.

### R2: Circular imports between Axiom and Vega

**Likelihood:** Medium (deeply coupled code being split)
**Impact:** High (breaks builds)
**Mitigation:** Phase V1.2 (API surface hardening) identifies coupling before extraction. V1.3 (import boundaries) enforces it. V2.6 catches residual issues.

### R3: Prague deployment regresses during extraction

**Likelihood:** Medium
**Impact:** High (Prague is the flagship 2026 deployment)
**Mitigation:** Extraction completes 6-8 weeks before Prague start. Integration tests validate the deployment combination. V6.1 documents the exact version pins.

### R4: PyPI name `vega-trust` unavailable

**Likelihood:** Low (searched, appears available)
**Impact:** Low (have fallback names)
**Mitigation:** Reserve immediately in V2.4. Fallback: `vegatrust`, `vega-infra`, `vegaprotocol-trust`.

### R5: Contributor attribution ambiguous

**Likelihood:** Medium (some code may have mixed UT / B-Tree contribution)
**Impact:** Medium (slows OTC process, doesn't block extraction)
**Mitigation:** V1.1 audit early. Flag ambiguous cases before memo submission. OTC can resolve via attribution affidavits.

### R6: Category window closes (NemoClaw or similar claims "governance infrastructure")

**Likelihood:** Medium (market moving quickly)
**Impact:** High (reduces Vega's defensibility)
**Mitigation:** V4.3 (landing page) goes live early; claims category. V5.3 announcement positions Vega as first-mover. Even if NemoClaw generalizes beyond OpenClaw, Vega's architectural positioning (open, standards-compliant, multi-harness) differentiates.

### R7: Architectural coupling deeper than anticipated

**Likelihood:** Low-medium
**Impact:** Medium (extends V2 timeline)
**Mitigation:** V1.2 + V1.3 surface coupling early. If extraction takes 3+ weeks instead of 1-2, the overall timeline slips proportionally but doesn't fail.

---

## 6) Decision Points Requiring Ben's Input

- [ ] Confirm WARDEN as the Vega federation agent name (alternatives: WAR-DEN, SEN-TRI)
- [ ] Confirm `vega-trust` as PyPI package name (check availability first)
- [ ] Confirm primary domain (`vega-trust.dev` recommended)
- [ ] Confirm UT org name (`ut-austin-ne`, or existing UT org, or new org)
- [ ] Approve OTC memo draft before submission
- [ ] Approve Axiom 0.14.0 release notes
- [ ] Approve public extraction announcement copy
- [ ] Decide: foundation stewardship (CNCF sandbox, LF AI) in Phase 2 or Phase 3

---

## 7) Related Documents

- [prd-vega.md](../prds/prd-vega.md) — product requirements
- [spec-vega.md](../specs/spec-vega.md) — technical specification
- [brand-product-strategy.md](brand-product-strategy.md) — portfolio context
- [design-resolution-protocol.md](design-resolution-protocol.md) — resolution design informing federation
- ADR-020, ADR-022, ADR-025, ADR-026 — underlying architectural decisions
- Dendra extraction plan (sibling; can be referenced for lessons)
