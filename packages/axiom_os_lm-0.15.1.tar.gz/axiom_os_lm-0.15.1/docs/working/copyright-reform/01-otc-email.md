# Email to UT OTC — copyright/attribution for Axiom

**To:** UT Office of Technology Commercialization (otc@otc.utexas.edu)
**From:** Benjamin Booth (bbooth@utexas.edu / bdb3732@eid.utexas.edu)
**Subject:** Joint-attribution guidance for Apache-2.0 platform with mixed funding (Axiom)

---

Dear OTC team,

I'm reaching out for guidance on copyright attribution for an open-source
software platform called **Axiom**, currently hosted at
[github.com/b-tree-labs/axiom-os](https://github.com/b-tree-labs/axiom-os).
The repository is licensed under Apache-2.0 and is being actively
developed in support of an UT teaching deployment in early June.

## The situation

Axiom is a domain-agnostic agent platform that several UT-led projects
build on top of. I am the sole author to date.

Authorship has spanned three funding contexts:

1. **UT-funded work**: substantial development performed in my role as
   a UT-Austin researcher, supported by federal grants. (Specific grant
   identifiers are listed in the attached NOTICE draft and can be
   confirmed if needed.)
2. **Personal-time work**: portions developed on personal time using
   personal resources, in my capacity as principal of B-Tree Ventures,
   LLC (DBA B-Tree Labs).
3. **Substrate lineage**: design ideas and some code patterns were
   adapted from an earlier Apache-2.0 project I authored under B-Tree
   Ventures called Substrate
   ([github.com/b-tree-labs/substrate](https://github.com/b-tree-labs/substrate)).

The two contribution streams (UT-funded and personal-time) are
interleaved across the codebase. There is no clean per-file split.

## What's currently in the repo

The current `NOTICE` and `docs/working/ownership-map.md` declare a
granular per-path attribution table:

- **Axiom platform** → Copyright B-Tree Ventures, LLC (sole)
- **Vega, Keplo, NeutronOS** → Copyright UT-Austin

On review, that per-path split doesn't match how the work
accumulated. I have contributed to every product (Axiom, Vega,
Keplo, NeutronOS, scidisplay, etc.) in both capacities — as a UT
researcher under grant funding, and on personal time as principal
of B-Tree Ventures. **There is no clean per-file or per-product
split that would accurately carry either name alone.** The only exception is Dendra, which lives in a separate
repo (`b-tree-labs/dendra`), is patent-pending, and is wholly
B-Tree-owned — that line is clean.

The `ownership-map.md` document is annotated *"Authoritative
(pending UT OTC formalization)"* — so the lever to revise the
in-repo model is explicitly there. We have not had any user
adoption of the published 0.x releases yet, so we are pulling them
all and resetting before any user-visible state ossifies under the
wrong attribution.

## The model I'd like to propose

I recommend collapsing the per-path table and treating **the entire
`axiom-os` repository as jointly copyrighted by UT-Austin and B-Tree
Ventures, LLC**, with both names on every file header and the NOTICE
file documenting the funding split at the project level rather than
file-by-file. Dendra (separate repo) remains B-Tree-owned. The
license stays Apache-2.0 (per grant public-good requirements).

A draft of the proposed `NOTICE` and `ownership-map.md` updates is
attached. Specifically:

- **File headers** become:
  ```
  # Copyright (c) 2026 The University of Texas at Austin
  # Copyright (c) 2026 B-Tree Ventures, LLC (DBA B-Tree Labs)
  # SPDX-License-Identifier: Apache-2.0
  ```
- **NOTICE** explains the joint ownership, names the grants funding
  the UT portion, and documents the Substrate lineage.
- **No per-file audit** — the project-level joint attribution covers
  the interleaved funding pattern accurately. The earlier per-path
  table was an attempt to be precise that has now had time to age
  and, on review, doesn't match how the work was actually done.

## Questions for OTC

1. Does the proposed joint-copyright model on Axiom satisfy UT
   policy for the grant-funded portion of the work?
2. Is there a preferred phrasing for the file headers and NOTICE
   that we should adopt instead?
3. Are there grants we need to disclose by award number in the NOTICE?
   (I can provide the list once you confirm whether it's required.)
4. Substrate is also Apache-2.0 and B-Tree-owned. Standard practice is
   to keep its copyright line on any directly-ported file plus a
   NOTICE entry. Confirm this is acceptable to UT?
5. Should we also be discussing a sponsored research IP agreement, or
   does this fall under the Bayh-Dole / open-source carve-out for
   federally-funded code?

I'd appreciate guidance before we tag a release. The work is on a
roughly six-week runway to a UT-Austin teaching deployment, so
clarity in the next 2-3 weeks would be ideal but not strictly
blocking.

Happy to meet in person or over Zoom if that's easier.

Thank you for your time,

Benjamin Booth
Researcher, UT-Austin
Principal, B-Tree Ventures, LLC
bbooth@utexas.edu
