# Proposed NOTICE — replaces repo-root NOTICE on OTC formalization

**Status:** Draft. Replaces `/NOTICE` if OTC blesses the joint-copyright model.

The text below the `---` is the literal proposed NOTICE content.

---

```
Axiom — domain-agnostic agentic platform
=========================================

Copyright (c) 2026 The University of Texas at Austin
Copyright (c) 2026 B-Tree Ventures, LLC (DBA B-Tree Labs)

Licensed under the Apache License, Version 2.0 (the "License"); you
may not use this work except in compliance with the License. You may
obtain a copy of the License at:

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
implied. See the License for the specific language governing
permissions and limitations under the License.


Joint copyright (Axiom platform)
--------------------------------

This repository hosts code owned by multiple copyright holders. The
Axiom platform itself — the agent harness, memory model, identity
layer, RAG retrieval, RPE, ArtifactRegistry, evals, research loop, and
the chat / signal / publishing / classroom / scidisplay / release /
hygiene / mcp extensions — is jointly copyrighted by:

  * The University of Texas at Austin
  * B-Tree Ventures, LLC (DBA B-Tree Labs)

Authorship spans:

  * Work performed by Benjamin Booth as a UT-Austin researcher under
    federally-funded research grants (enumerated below). UT-Austin
    holds the UT-portion of the joint copyright on this work.

  * Work performed by Benjamin Booth on personal time using personal
    resources, as principal of B-Tree Ventures, LLC. B-Tree Ventures
    holds the B-Tree-portion of the joint copyright on this work.

The two contribution streams are interleaved across the codebase.
Per UT Office of Technology Commercialization guidance, the platform
is released as a single jointly-copyrighted work under Apache-2.0
rather than via per-file attribution.


Scope
-----

The joint UT + B-Tree copyright applies to **the entire `axiom-os`
repository**. Vega, Keplo, scidisplay, signals, publishing, classroom
support, NeutronOS support code in this repo, and the chat platform
are all jointly copyrighted under the rule above; there is no
per-product carve-out within the repo.

Outside this repo:

  * **Dendra** is wholly copyrighted by B-Tree Ventures, LLC.
    It lives in a separate repository:
    https://github.com/b-tree-labs/dendra
    Dendra is patent-pending and not part of the joint scope.

  * **NeutronOS** as deployed at UT lives in a separate repository
    (https://github.com/b-tree-labs/neutron-os) and is jointly
    copyrighted on the same terms as this repo, since the same
    funding pattern produced it.

The `docs/working/ownership-map.md` document records this rule in
authoritative form.


Substrate lineage
-----------------

Portions of Axiom's design and code were adapted from Substrate
(https://github.com/b-tree-labs/substrate), Copyright (c) 2025 B-Tree
Ventures, LLC, also licensed under Apache-2.0. Files that are direct
ports retain Substrate's original copyright line above any new
copyright lines added during adaptation.

Substrate is preserved as a historical reference; active development
of the platform that grew out of it lives in this repository.


Funding
-------

The UT-portion of work on Axiom (and the wholly-UT-owned products
above) was supported in part by:

  * <GRANT TITLE> — <SPONSOR / NSF / DOE / etc.> — <AWARD NUMBER>
  * <ADDITIONAL GRANTS as applicable>

(Specific awards to be filled in by the principal author and
confirmed with UT OTC before the next tagged release.)

Per the grant terms and the federal Bayh-Dole framework as applied
by UT, the resulting software is released under an OSI-approved
license (Apache-2.0) for the public good.


Trademarks
----------

"Axiom", "Neut", "NeutronOS", "Vega", "Keplo", "Dendra", "Vyzier",
"AXI", "SCAN", "PRESS", "RIVET", "TIDY", "TRIAGE", "CURIO",
"CHALKE", "WARDEN", and the B-Tree Labs origin-glyph mark are
trademarks of B-Tree Ventures, LLC. The Apache-2.0 license does not
grant rights to use these marks; see Apache-2.0 §6.

Use of "The University of Texas at Austin" and associated UT marks
is governed by UT brand policy and is not granted by this license.


Contributing
------------

Contributors agree to license their contributions under Apache-2.0.
Each commit must carry a `Signed-off-by:` trailer (DCO sign-off).
Per-file copyright lines may be extended to name additional
contributors as work accumulates; existing UT and B-Tree Ventures
lines remain.

This product includes software developed by:
  - The University of Texas at Austin (https://www.utexas.edu)
  - B-Tree Ventures, LLC (https://b-tree-labs.com)
```
