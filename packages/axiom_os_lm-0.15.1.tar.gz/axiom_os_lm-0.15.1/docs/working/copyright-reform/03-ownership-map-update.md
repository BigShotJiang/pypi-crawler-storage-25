# Proposed `ownership-map.md` — full replacement

**Status:** Draft. Replaces `docs/working/ownership-map.md` once OTC formalizes.

The current `ownership-map.md` has a granular per-path table assigning
products to either B-Tree or UT. On review, that table doesn't match
how the work actually accumulated: **the only clean per-product
ownership line in our portfolio is Dendra, which lives in a separate
repo anyway**. Inside `axiom-os`, Axiom and the products that ride on
it (Vega, Keplo, scidisplay, etc.) all reflect interleaved UT-funded
and personal-time work by the same author.

The proposed replacement collapses the per-path table to one rule:

---

```markdown
# IP Ownership Map

**Status:** Authoritative (UT OTC-formalized YYYY-MM-DD)
**Owner:** Benjamin Booth
**Last updated:** YYYY-MM-DD
**Parent:** [brand-product-strategy.md](brand-product-strategy.md),
            [/NOTICE](/NOTICE)

This document is the authoritative source of truth for copyright
attribution in this repository.

---

## The rule

**The entire `axiom-os` repository is jointly copyrighted by
The University of Texas at Austin and B-Tree Ventures, LLC (DBA
B-Tree Labs).** Every source file carries both copyright lines.

This is the consequence of the funding pattern: the sole author has
contributed to every product (Axiom platform, Vega federation, Keplo
classroom, NeutronOS support code, scidisplay, etc.) in two
overlapping capacities — as a UT-Austin researcher under federal
grants, and as principal of B-Tree Ventures on personal time. There
is no clean per-file or per-product split that would accurately
carry either name alone.

## The exception

**Dendra** is wholly owned by B-Tree Ventures, LLC. It lives in a
separate repository at https://github.com/b-tree-labs/dendra and is
**not part of the joint-copyright scope of this repo**.

If any code from Dendra is later imported into this repo, that
specific file or directory will carry only the B-Tree Ventures
copyright line plus a Substrate-style lineage notice; the rest of
the repo's joint posture is unaffected.

## Substrate lineage

Files directly ported from Substrate
(https://github.com/b-tree-labs/substrate, Apache-2.0, B-Tree
Ventures) retain Substrate's original copyright line. Modifications
performed within `axiom-os` add the joint UT + B-Tree lines below it,
in modification-date order.

## File-header form

```
# Copyright (c) <YEAR> The University of Texas at Austin
# Copyright (c) <YEAR> B-Tree Ventures, LLC (DBA B-Tree Labs)
# SPDX-License-Identifier: Apache-2.0
```

For Substrate-derived files only:

```
# Copyright (c) 2025 B-Tree Ventures, LLC          # original (Substrate)
# Copyright (c) <YEAR> The University of Texas at Austin
# Copyright (c) <YEAR> B-Tree Ventures, LLC (DBA B-Tree Labs)
# SPDX-License-Identifier: Apache-2.0
```

## What this map does NOT govern

- Trademark rights — see /NOTICE §"Trademarks"
- Patent rights — see Apache-2.0 §3 for the cross-license terms
- Future contributions from third parties — they add their own
  copyright lines per Apache-2.0 §4(b)
- Sponsored research IP agreements — those operate alongside this
  map, not within it; consult OTC and the principal's attorney for
  any project that touches a sponsor's pre-existing IP
```
