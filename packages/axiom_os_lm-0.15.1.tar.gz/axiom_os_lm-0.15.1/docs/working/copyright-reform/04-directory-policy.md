# `.copyright-policy` mechanism — lighter alternative

**Status:** Draft. Decision pending OTC formalization.

If OTC blesses the joint-copyright-on-the-whole-repo model, this
artifact is **not needed** — the rule is uniform and an in-repo
machine-readable file isn't required.

If OTC instead asks for per-directory granularity (unlikely given
their typical guidance, but possible), the mechanism below is the
lightest implementation.

---

## Concept

Drop a `.copyright-policy` file in any directory whose copyright
posture differs from the repo default. The file contains a single
line: the canonical header form to apply to all source files in that
directory and below (until overridden by a deeper `.copyright-policy`).

Example layout:

```
axiom-os/
  .copyright-policy           # repo default (joint UT + B-Tree)
  src/axiom/
    extensions/builtins/
      classroom/
        .copyright-policy     # if Keplo were UT-sole — not the proposed model
      ...
```

## Format

A `.copyright-policy` is a plain-text file with two sections:

```ini
[header]
Copyright (c) {YEAR} The University of Texas at Austin
Copyright (c) {YEAR} B-Tree Ventures, LLC (DBA B-Tree Labs)
SPDX-License-Identifier: Apache-2.0

[notes]
This directory follows the repo-default joint-copyright posture.
See /NOTICE and docs/working/ownership-map.md.
```

`{YEAR}` is interpolated at apply-time using `git log --diff-filter=A`
on the file (year of original creation) — keeps existing 2025 / 2026
years correct without requiring everyone to remember.

## Tooling that consumes it

- The header-update script (artifact 05) walks `.copyright-policy`
  files and applies the right header to each file.
- A pre-commit hook can verify that a file's existing header matches
  its directory's policy; otherwise it reformats.
- CI can assert that no source file lacks a copyright header
  matching its directory policy.

## Why this is the *fallback*, not the default

Mechanism without need is harness, not architecture. The proposed
joint-copyright-on-the-whole-repo model needs zero per-directory
files. We only adopt this mechanism if OTC requests per-directory
granularity for a specific, articulated reason (e.g., a sponsored
research clause requires strict-UT marking on a particular module).
