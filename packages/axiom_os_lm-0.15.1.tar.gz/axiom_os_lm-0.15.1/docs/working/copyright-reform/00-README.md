# Copyright reform — drafts pending OTC formalization

**Status:** Drafts only. Not authoritative. Not landed.
**Owner:** Benjamin Booth
**Created:** 2026-05-02
**Parent:** [`../brand-product-strategy.md`](../brand-product-strategy.md), [`../ownership-map.md`](../ownership-map.md)

---

## What this directory is

The repo's current `NOTICE` and `docs/working/ownership-map.md` declare
**Axiom as B-Tree-Ventures-only**. That model conflicts with the actual
funding pattern: a substantial share of Axiom development was performed
by Benjamin Booth as a UT-Austin researcher under federal grant funding.
The current model also makes no formal accommodation for the portions
of work performed on personal time using personal resources.

UT-Austin's standard guidance for grant-funded open-source software
treats it as **jointly owned** between UT and the principal's company
when both contribute. The "pending OTC formalization" status line on
`ownership-map.md` was placed precisely so that the model could be
revised before being treated as final.

This directory holds the proposed revision **as drafts** for review
with UT's Office of Technology Commercialization (OTC). When OTC
formalizes, these drafts (or revisions of them) replace the
authoritative documents.

## What's here

- [`01-otc-email.md`](01-otc-email.md) — proposed email to UT OTC
  framing the question and presenting our recommended model
- [`02-NOTICE-proposed.md`](02-NOTICE-proposed.md) — proposed
  replacement for the repo-root `NOTICE` file
- [`03-ownership-map-update.md`](03-ownership-map-update.md) —
  proposed updates to `docs/working/ownership-map.md` introducing a
  joint-ownership row for Axiom and a Substrate-lineage entry
- [`04-directory-policy.md`](04-directory-policy.md) — lighter
  alternative: a `.copyright-policy` mechanism that avoids per-file
  audit work
- [`05-header-update-script.md`](05-header-update-script.md) — a
  one-shot Python script that rewrites all `# Copyright (c)` lines
  to the agreed form once OTC blesses one

## Sequencing

1. OTC email goes out, OTC replies with their preferred model.
2. If OTC says "joint copyright on Axiom" — apply 02, 03, 05.
3. If OTC says "current model is fine, just attribute Substrate" —
   apply a much lighter touch (NOTICE addendum + Substrate lineage).
4. If OTC asks for a different shape entirely — these drafts get
   revised before landing.

## What we are NOT doing right now

- Modifying the live `NOTICE` or `LICENSE` files
- Modifying the authoritative `ownership-map.md`
- Mass-rewriting copyright headers in source files
- Tagging or releasing under either model

All four are gated on OTC's response.
