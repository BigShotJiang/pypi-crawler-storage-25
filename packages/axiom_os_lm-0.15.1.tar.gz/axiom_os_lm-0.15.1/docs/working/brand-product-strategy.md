# Brand & Product Strategy

**Owner:** Benjamin Booth
**Status:** Working draft — decisions locked, execution pending
**Last Updated:** 2026-04-21 (Agent naming convention formalized; Keplo replaces Keplo as product name; WARDEN confirmed as Vega federation agent; CHALKE expanded to own all classroom orchestration)

---

## Executive Summary

The portfolio ships as **six distinct products** under an open-core business model, with IP split between **B-Tree Ventures LLC** (commercial operator, DBA: **Axiom Labs**) and **UT Austin** (institutional owner). This structure maximizes adoption surface, defensibility, and monetization clarity while preserving strategic coherence through shared infrastructure.

The operating theses are:
- **Polyglot packaging:** extensions publish from one source to every major harness (Axiom native, MCP, SKILL.md, LangChain, CrewAI, A2A). Vyzier is the registry and build pipeline.
- **Dual-mode governance:** Vega enforces trust at the boundary regardless of which harness consumes the resource. Strongest guarantees in Axiom native mode; server-side enforcement holds in governance-layer (MCP) mode.
- **Federation as moat:** institutional trust networks cannot be replicated by cloud-only competitors (OpenAI, Anthropic, Google).

---

## The Six Products

| Product | Owner | Tagline | Category |
|---|---|---|---|
| **Axiom** | B-Tree Ventures (Axiom Labs) | The open agent platform that federates | Agent harness + platform |
| **Vega** | UT Austin | Trust infrastructure for agentic AI | Federation + governance layer |
| **Keplo** | UT Austin | Discovery through observation | Classroom + learning analytics |
| **Dendra** | B-Tree Ventures (Axiom Labs) | The classifier that learns from outcomes | ML primitive library |
| **Vyzier** | B-Tree Ventures (Axiom Labs) | Publish once. Run anywhere. | Polyglot extension marketplace + registry |
| **NeutronOS** | UT Austin | AI for nuclear engineering | Domain application |

### Portfolio-Adjacent Projects

- **SoilMetrix** (separate entity) — future consumer. Planned refactor to build on Axiom + Vega, with agricultural extensions distributed via Vyzier. Not a portfolio product in the licensing sense; a downstream application that validates the stack across a second vertical.

---

## Naming Conventions (Portfolio-Wide)

The portfolio uses two visually distinct naming conventions, each reserved for a single purpose. The visual casing of a name unambiguously indicates whether it refers to a product or an agent.

### Products use normal-case names

Products in the portfolio are written in **normal case**:

- **Axiom**, **Vega**, **Keplo**, **Dendra**, **Vyzier**, **NeutronOS**

This applies in all contexts: documentation, marketing, code (package names use lowercase: `axiom`, `vega`, `keplo`, `dendra`, `vyzier`, `neutronos`), file paths, and URLs. Never all-caps, never hyphenated.

### Agents use ALL-CAPS-WITH-HYPHEN styling

Agents within the portfolio use an **ALL-CAPS-HYPHEN** convention: ALL CAPS, often hyphenated, two-syllable rhythm:

| Agent | Product | Role |
|---|---|---|
| **SCAN** | Axiom | Signal ingestion and extraction |
| **TIDY** | Axiom | Resource steward and hygiene |
| **PRESS** | Axiom | Publisher / document lifecycle |
| **TRIAGE** | Axiom | Diagnostics / platform health |
| **CURIO** | Axiom | Research / interactive chat |
| **AXI** | Axiom | Generic workflow orchestration primitive (domain-agnostic) |
| **CHALKE** | Keplo | Classroom domain agent (workflow orchestration + instructor brief) |
| **WARDEN** | Vega | Federation agent (Verifier, Enforcer, Gatekeeper, Arbiter) |

Typography variants for visual / prose / process contexts:
- Logo / hero: **V·EGA**, **CHALK·E** (interpunct for formal/visual use)
- Documentation: **WARDEN**, **CHALKE** (hyphen for prose, headers, URLs in text)
- Process identifiers: `vega-agent`, `chalke-agent` (lowercase with simple hyphenation for service names, log fields, config)

### Reason for the split convention

The split is enforced because a single glance should communicate whether a name refers to:
- A product you can install, license, or brand (normal case: `pip install keplo`, "the Vega platform", "join the Axiom community")
- An agent within a product (ALL-CAPS: "CHALKE will notify the instructor", "WARDEN quarantined peer X", "SCAN ingested a signal from Teams")

Products and agents coexist in the same sentences all the time ("Keplo's CHALKE sends the instructor brief"). The visual distinction prevents reader confusion.

### The Vega / WARDEN Relationship

Vega is the product; WARDEN is its federation agent. The agent acronym — **V**erifier, **E**nforcer, **G**atekeeper, **A**rbiter — maps to its four operational roles:

- **V**erifier: cryptographic identity, attestation chains, DNSSEC validation
- **E**nforcer: RACI gates, classification stamp enforcement, trust profile application
- **G**atekeeper: federation admission, quarantine initiation, revocation propagation
- **A**rbiter: human-escalation context, cross-peer finding validation, policy exception review

WARDEN is bundled with Vega's federation-peer deployments (Shape 5) and optionally available in gateway deployments (Shape 3). It is not included in embedded-library or verification-only deployments (Shapes 1, 4).

---

## Corporate Structure

### B-Tree Ventures, LLC dba Axiom Labs

B-Tree Ventures operates commercially as **Axiom Labs**. The DBA signals category (AI infrastructure / agentic systems) and aligns the company brand with the flagship product. "Axiom ships from Axiom Labs" reads naturally in press, docs, and partnership contexts.

**DBA rationale:**
- Matches customer mental model (vendor identity = flagship product identity)
- Preserves legal entity (B-Tree Ventures LLC) for contracts and banking continuity
- Avoids "Substrate Labs" (active AI-infrastructure company, Lightspeed-backed, direct category conflict)
- Works across multiple products (Axiom, Dendra, Vyzier all published under the Axiom Labs umbrella)

**Brand hierarchy:**

```
B-Tree Ventures, LLC (legal entity)
  └── dba Axiom Labs (commercial identity)
        ├── Axiom (flagship product, agent platform)
        ├── Dendra (ML primitive library)
        └── Vyzier (extension marketplace + registry)

UT Austin (institutional owner)
  ├── Vega (licensed to Axiom Labs for commercialization — terms TBD)
  ├── Keplo (licensed to Axiom Labs for commercialization — terms TBD)
  └── NeutronOS (integrated "powered by Axiom" for now)

SoilMetrix-Inc (separate entity, founder-adjacent)
  └── SoilMetrix (future consumer of Axiom + Vega + Vyzier-distributed extensions)
```

### Predecessor Projects

**Substrate** (github.com/Substrate-App/substrate, Go codebase, 2025) and **Vyzier** (marketplace concept) were earlier explorations of this same problem space. Lessons carried forward into Axiom:
- What to adopt from TAP (CPAC, CBAC, DADP concepts) — already captured in `docs/working/design-resolution-protocol.md`
- What to skip (MASR, MAMA, BAAT, VITAL blockchain, OASIS, SubCert) — also captured
- The **Vyzier brand** — repurposed as the polyglot extension marketplace (see product positioning below)

**Substrate Go codebase:** retired. Python is the operational language. Go code is not carried forward. Conceptual contributions are documented and preserved; implementation is discarded to avoid multi-language maintenance burden.

---

## Portfolio Rationale

### Why six products, not one

A monolithic Axiom maximizes defensibility but minimizes adoption. Every potential buyer hits at least one dimension of the platform that doesn't fit their needs — a university doesn't want nuclear features, a nuclear lab doesn't want classroom features, an enterprise wants governance without a full harness, an ML team wants classifier infrastructure without the rest, an extension author wants distribution reach without a platform commitment. The all-or-nothing proposition repels most of the potential market.

Unbundling creates multiple clean wedges. Each product has a clear buyer, a clear pitch, and a clear monetization path. The bundle still exists conceptually (products interoperate), but buyers can enter through whichever door fits their needs.

### Why Vega (federation) is extracted, not bundled

The federation + governance layer is Axiom's single most defensible IP. Extracting it as a standalone product accomplishes three strategic goals:

1. **Multiplies adoption surface.** Any agent harness (LangChain, CrewAI, Hermes Agent, OpenClaw deployments, Claude Code installations) becomes a potential Vega consumer. The addressable market is every enterprise deploying agentic AI, not just Axiom users.

2. **Elevates from feature to category.** A feature is copyable; a category is harder to displace. Extracting Vega positions it as a category definition — the "trust layer for agentic AI" — which is more defensible than any single feature.

3. **Defangs imitation.** OpenAI, Anthropic, and Google can build better chat experiences than Axiom. They cannot build self-hosted multi-institutional federation because it contradicts their cloud business model. Vega is the part of the portfolio that major cloud providers structurally cannot copy.

NemoClaw (NVIDIA's governance wrapper around OpenClaw, launched March 2026) validates the market: enterprises want governance separately from agent runtimes. Vega meets that demand with a cleaner architecture than a post-hoc wrapper.

### Why Keplo (classroom) is extracted

Universities, K-12 districts, and professional training organizations are a clear buyer segment that shouldn't have to engage with "Axiom" or "Vega" as concepts. Keplo becomes the product they buy. It's built on Axiom + Vega internally, but those are implementation details. Canvas integration, curriculum features, and education-specific UX live in Keplo.

### Why Dendra is standalone

The LearnedSwitch primitive (now called Dendra) serves every classification decision in every agentic system. Keeping it inside Axiom limits its adoption to Axiom users. As a standalone Apache 2.0 library (multi-language), Dendra can be adopted by teams that will never become Axiom customers — and that adoption creates an ecosystem of trained developers who become natural Axiom prospects later.

### Why Vyzier (marketplace) is a standalone product

The polyglot extension pipeline is the flywheel that makes every other product more valuable. Extracting Vyzier as its own product accomplishes three things:

1. **Positions the marketplace independently.** An extension author doesn't need to commit to Axiom to reach Claude Code, Cursor, OpenClaw, CrewAI users — they publish to Vyzier, and Vyzier distributes everywhere. Vyzier becomes the entry point for developers who may later adopt Axiom for deeper features.

2. **Directly answers ClawHub.** OpenClaw's marketplace has a catastrophic security record (ClawHavoc: 800+ malicious skills, 20% of registry). Vyzier's security-first positioning — signed provenance, static analysis, trust tiers, Vega-aware classification — is a concrete differentiator.

3. **Creates the primary monetization flywheel for Axiom Labs.** Free for open-source extensions, paid tiers for private distribution, SLAs, team features, build pipeline compute. Vyzier revenue compounds across the developer ecosystem.

### Why NeutronOS stays integrated (for now)

NeutronOS has a small, high-value buyer segment (nuclear facilities, national labs). Its value proposition is deep domain integration with Axiom + Vega, not brand independence. Separating it into its own brand adds operational overhead without proportional upside at current scale.

**Revisit after:** first commercial deployment + Prague classroom completion. If NeutronOS develops its own buyer pipeline independent of Axiom, extract to standalone brand. Until then, "powered by Axiom" positioning is sufficient.

### Why SoilMetrix is a consumer, not a product

SoilMetrix is a separately-owned agricultural AI company (github.com/SoilMetrix-Inc). It is not part of the Axiom Labs or UT portfolio. However, strategic direction is to refactor SoilMetrix onto the Axiom stack — consuming Axiom as runtime, Vega as trust layer, and distributing agricultural domain extensions via Vyzier.

This serves multiple purposes:
- Validates the stack across a second vertical beyond nuclear (NeutronOS)
- Exercises the polyglot extension pipeline with real external consumption
- Provides SoilMetrix with production-grade governance it couldn't build alone
- Demonstrates Axiom's domain-agnostic positioning to prospective customers

SoilMetrix's refactor timeline tracks with Axiom's public launch readiness, not the reverse.

---

## Product Positioning

### Axiom (Axiom Labs / B-Tree Ventures)

**Tagline:** The open agent platform that federates.

**What it is:** A full-stack agent harness for building, running, and evolving agentic systems. Includes memory, RAG, prompts, gateway, CLI, extension system, web chat, signal pipeline primitives.

**Operating modes:**
- **Standalone harness:** Axiom IS the agent platform. Users interact via CLI, web chat, or messaging channels. Built-in agents (CURIO, SCAN, TIDY, PRESS, AXI) handle research, signals, stewardship, publishing, orchestration.
- **Governance-paired:** When deployed alongside external harnesses (Claude Code, OpenClaw, Hermes, Cursor) via MCP, Axiom provides the capability layer those harnesses lack. Vega (federation) is typically deployed with Axiom in this mode.

**Primary buyer:** Developers building agentic systems, platform teams at mid-market to enterprise companies.

**License:** Apache 2.0 (open source), with optional commercial features for SaaS hosting, priority support, and enterprise extensions.

**Monetization:**
- SaaS hosting (cloud-managed Axiom)
- Enterprise support contracts
- Training and services
- Custom extension development

**Positioning against competitors:**
- vs. LangChain/LangGraph: Axiom is more opinionated, with built-in governance primitives
- vs. CrewAI: Axiom is more infrastructure-focused and offline-first
- vs. Hermes Agent: Axiom is institutionally-oriented rather than personal-assistant-oriented
- vs. OpenClaw: Axiom has architectural security (deterministic authorization boundary) that OpenClaw lacks by design

### Vega (UT Austin)

**Tagline:** Trust infrastructure for agentic AI.

**What it is:** The federation + governance + classification layer that lets agents operate safely across institutional boundaries. Ed25519 identity, A2A protocol, trust profiles, RACI gates, classification-aware data flow, manifest channels, multi-sector anchoring (InCommon, PIV/CAC).

**Primary buyer:** Enterprise IT, institutional research computing, government/defense, healthcare, any organization with multi-party data sharing or compliance requirements.

**License:** Open-core.
- **Open (Apache 2.0):** Base identity (Ed25519), A2A protocol, basic trust profiles, RACI primitives, two-tier classification (public/restricted), self-hosted single-org federation.
- **Commercial license:** FROST threshold signing, multi-org cross-bridge federation, advanced classification (export-controlled, classified), SOC2 audit reporting, managed cloud, SLA-backed support.
- **Enterprise add-ons:** PIV/CAC integration, custom compliance frameworks, dedicated cloud regions.

**Monetization:**
- Commercial licenses for enterprise features
- Managed Vega cloud service
- Compliance certifications and attestations
- Institutional deployment support

**Positioning against competitors:**
- vs. NemoClaw: Vega is architecturally trust-first, not a wrapper bolted onto an ungoverned runtime
- vs. AWS IAM / Azure AD: Vega is agent-native, not retrofitted from human-identity systems
- vs. custom enterprise compliance layers: Vega is open-source and portable across clouds

**Consumable by:** Axiom (primary), LangChain, CrewAI, Hermes Agent, Claude Code installations, OpenClaw deployments, any MCP-compatible agent harness.

### Keplo (UT Austin)

**Styling:** KEP·LO (logo) / Keplo (print) / Keplo (casual, domains, packages).

**Expansion:** Kepler Education Platform — Learning Observatory.

**Tagline:** Discovery through observation. (Inspired by Johannes Kepler's scientific method.)

**What it is:** Educational AI platform. Course manifests, student learning ledgers, structured Q&A, interaction classification, LMS integration, instructor dashboards, grade sync, curriculum management. Built on Axiom + Vega.

**Character positioning:** Keplo is the only product in the portfolio with character-style branding (like AXI). This reflects its role as the instructor's AI companion — a presence that lives alongside teaching, observes with patience, and illuminates patterns. The other products are infrastructure; Keplo is a companion.

**Primary buyer:** Universities, K-12 districts, professional training organizations, corporate learning departments.

**License:** Open-core.
- **Open (Apache 2.0):** Course manifest, basic enrollment, structured Q&A, basic dashboards, single-cohort management.
- **Commercial license / SaaS:** LMS integration (Canvas, Moodle, Blackboard, Schoology), multi-cohort management, instructor analytics, parent/admin reporting, hosted infrastructure, curriculum marketplace.
- **Enterprise add-ons:** SSO, FERPA/GDPR compliance reporting, dedicated tenancy, SLA support.

**Monetization:**
- SaaS (per-seat or per-institution pricing)
- Self-hosted commercial licenses
- LMS marketplace revenue share
- Professional services for custom curriculum integration

**Positioning:**
- Domain-grounded AI > generic ChatGPT for education
- Observable and measurable > instructor has no visibility into student AI use
- Research-grade data collection for education research papers
- Interoperable with existing LMS, not a replacement

**Consumes:** Axiom (runtime) + Vega (trust layer) + optionally Dendra (classification).

### Dendra (Axiom Labs / B-Tree Ventures)

**Tagline:** The classifier that learns from outcomes.

**What it is:** A multi-language library implementing the LearnedSwitch primitive — a drop-in replacement for deterministic case/switch classification that graduates to an ML classifier trained on accumulated outcome data, with LLM-as-teacher intermediate phases and rule fallback on low confidence.

**Primary buyer:** ML engineers, platform engineers, developers building systems with classification decisions.

**License:** Apache 2.0 (open source), with optional paid services.

**Monetization:**
- Managed training service (users send outcome logs, receive trained ONNX models)
- Consulting for complex deployments
- Enterprise support contracts
- Federated Dendra coordination service (Phase 3)

**Positioning:**
- vs. rolling your own ML: Dendra provides the full lifecycle (rule → LLM → ML) with safety guarantees
- vs. AutoML: Dendra targets classification specifically, with operational integration
- vs. scikit-learn: Dendra is at a higher abstraction — "graduating a function to ML" rather than "training a model"

**First external adoption targets:** Any team with classification decisions that feel "hardcoded but could be smarter" — support ticket triage, content moderation, retrieval routing, quality assessment.

### Vyzier (Axiom Labs / B-Tree Ventures)

**Tagline:** Publish once. Run anywhere.

**What it is:** The polyglot extension marketplace and registry. Authors publish one canonical extension source; Vyzier builds and distributes to every major harness ecosystem (MCP, SKILL.md, LangChain, CrewAI, A2A, native Axiom). Signed provenance, static analysis, trust tiers, Vega-aware classification enforcement.

**Primary buyer:**
- Extension authors (individual developers, teams, ISVs) who want distribution reach without building for every ecosystem separately
- Enterprise teams who want a safe, audited source of AI extensions (direct answer to ClawHub's security failures)
- Institutional IT who want classification-aware distribution (extensions tagged by sensitivity, filtered at install)

**License:** Hybrid.
- **Open (Apache 2.0):** Core build pipeline tools (`axi ext build`, format converters), extension manifest schemas, basic public registry access.
- **Paid tiers:** Private extension hosting, team features (SSO, access controls), SLA-backed build infrastructure, enterprise trust tier certifications, custom registry deployments.

**Monetization:**
- Freemium model: free for public/open-source extensions; tiered paid plans for private distribution
- Enterprise registry deployments (on-prem Vyzier)
- Build pipeline compute credits
- Trust tier certifications (premium validation for enterprise-grade extensions)
- Ecosystem revenue share (optional marketplace monetization for extension authors)

**Positioning:**
- vs. ClawHub (OpenClaw): security-first. Signed, audited, static-analyzed, trust-tiered. ClawHub has no equivalent.
- vs. LangChain Hub: multi-harness reach. LangChain Hub distributes to LangChain only.
- vs. MCP Registry / Claude Code marketplace: multi-format output. Vyzier-published extensions run as MCP servers AND SKILL.md AND pip packages, from one source.
- vs. PyPI: agent-native metadata. Vyzier extensions carry classification tags, capability declarations, trust attestations — not just package metadata.

**The flywheel:** more harness ecosystems consume Vyzier → more reach for authors → more authors publish → more valuable catalog → more enterprises adopt → repeat. Vyzier is the ecosystem-building product in the portfolio.

**Consumes:** Axiom's build tooling + optionally Vega (for signed provenance) + optionally Dendra (for static analysis classification).

### NeutronOS (UT Austin)

**Tagline:** AI for nuclear engineering.

**What it is:** Nuclear domain application. Model corral (physics simulation models), facility packs, nuclear-specific SCAN extractors, NRC compliance reporting, regulatory data management, federated research infrastructure.

**Primary buyer:** Nuclear facilities (research reactors, national labs), nuclear engineering academic programs, regulatory bodies.

**License:** Open-core.
- **Open (Apache 2.0):** Model corral, basic facility management, federation participation.
- **Commercial license:** Facility-specific extensions, regulatory reporting modules (NRC, DOE), dedicated support, on-site deployment.

**Monetization:**
- Enterprise contracts with facilities
- Regulatory compliance modules
- Federated research consortium membership fees

**Positioning (for now):** "Powered by Axiom" — NeutronOS is a specialized deployment of the stack, not a separately marketed brand. Revisit standalone branding after first commercial deployment.

**Consumes:** Axiom (runtime) + Vega (federation for consortium) + Dendra (nuclear classification).

---

## IP Ownership & Legal Structure

### Ownership Matrix

| Product | Owner | Commercial Operator | License Structure |
|---|---|---|---|
| **Axiom** | B-Tree Ventures LLC (dba Axiom Labs) | B-Tree Ventures LLC | Apache 2.0 + commercial |
| **Vega** | UT Austin | Axiom Labs (proposed exclusive licensee) | Apache 2.0 + commercial |
| **Keplo** | UT Austin | Axiom Labs (proposed exclusive licensee) | Apache 2.0 + commercial |
| **Dendra** | B-Tree Ventures LLC (dba Axiom Labs) | B-Tree Ventures LLC | Apache 2.0 + managed service |
| **Vyzier** | B-Tree Ventures LLC (dba Axiom Labs) | B-Tree Ventures LLC | Open core + paid tiers |
| **NeutronOS** | UT Austin | UT-direct or Axiom Labs licensee (TBD) | Apache 2.0 + commercial |

### Cross-Entity Licensing Requirements

The products must interoperate despite different ownership. This requires formal bidirectional licensing:

1. **Axiom Labs → UT:** Axiom, Dendra, and Vyzier licensed to UT for use in Vega, Keplo, and NeutronOS development and operations.

2. **UT → Axiom Labs:** Vega licensed to Axiom Labs for inclusion in Axiom distributions that bundle federation capabilities. Keplo and NeutronOS remain UT-exclusive at the product level, though they consume Axiom.

3. **Commercial sale paths:** UT-owned products require a commercial operator for enterprise licensing. Proposed structure:
   - Vega: exclusive license to Axiom Labs (commercial operator)
   - Keplo: exclusive license to Axiom Labs (commercial operator) OR non-profit foundation model if TRIGA / education-consortium governance is preferred
   - NeutronOS: either UT-direct or Axiom Labs licensee depending on OTC guidance

### UT Office of Technology Commercialization (OTC) Engagement

All UT-owned products require OTC approval for commercialization. Expected timeline: 6-12 months for formal agreements. Start this week with a portfolio memo to OTC describing:

- The six-product structure and IP split (B-Tree Ventures dba Axiom Labs + UT)
- The open-core business model
- The proposed commercial operator structure (Axiom Labs as exclusive licensee for UT products)
- Expected royalty or licensing terms

Engaging OTC early prevents rework later. Their standard templates should accommodate most scenarios.

### Contributor Discipline

Every code contribution must be attributed to the correct entity:
- **UT employee on UT time:** UT-owned. Should go into Vega, Keplo, or NeutronOS repos.
- **B-Tree / Axiom Labs work outside UT employment:** B-Tree-owned. Should go into Axiom, Dendra, or Vyzier repos.
- **External contributors (students, partners):** Require Contributor License Agreements (CLAs) before any non-trivial contribution.

A code contribution ledger should be maintained per repository until a formal CLA framework is in place.

---

## Polyglot Packaging Pipeline

**Operating thesis:** Every Axiom-ecosystem extension is a *source artifact* that builds to *multiple consumption formats*. Authors write once; Vyzier's build pipeline distributes to every major agent harness. This is the ecosystem flywheel.

### Distribution Targets (Priority-Ordered)

| Format | Consumed By | Priority | Notes |
|---|---|---|---|
| **Native axiom-extension.toml** | Axiom | P0 | Canonical source format. Full feature surface. |
| **MCP server** | Claude Code, Cursor, OpenAI Agents SDK, Vercel AI SDK, Mastra, Google ADK, Anthropic Managed Agents | P0 | Highest single-format reach (60%+ of modern agentic dev). |
| **SKILL.md with YAML frontmatter** | OpenClaw, Hermes Agent, their forks | P1 | Cheap to build (metadata transformation). Large installed base. |
| **pip package — LangChain Tool** | LangChain, LangGraph | P2 | Pydantic-schema tooling. |
| **pip package — CrewAI Tool** | CrewAI | P2 | Pydantic-schema tooling. |
| **A2A Agent Card + endpoint** | Microsoft Agent Framework, Mastra, emerging A2A systems | P2 | Low-medium build cost. |
| **OpenAPI spec** | Enterprise integration platforms | P3 | Auto-generated from tool schemas. |

### Build Pipeline Architecture

Canonical source: `axiom-extension.toml` + Python/TypeScript code + SKILLS.md natural-language descriptions + capability declarations.

Build pipeline (`axi ext build` + `axi ext publish`):
1. Reads the canonical source
2. Transforms to each target format (with graceful feature-degradation warnings where formats lose capabilities)
3. Signs each artifact (Ed25519, via Vega identity primitives)
4. Runs static analysis (Dendra-classified — is this extension safe?)
5. Publishes to Vyzier registry
6. Vyzier redistributes to ecosystem-specific channels (PyPI, npm, MCP registries, SKILL.md bundles)

### The Feature-Surface Matrix (Honest About Degradation)

Not every format supports every feature. The build pipeline is transparent about this:

- **Federation awareness:** Native Axiom + MCP (in governance-paired mode). SKILL.md and LangChain/CrewAI tools lose federation features.
- **Classification enforcement:** Native (full), MCP (server-side enforced), pip packages (best-effort client-side), SKILL.md (no enforcement — purely advisory).
- **RACI approval flows:** Native Axiom (full UI), MCP (async approval responses), other formats (no approval flows).
- **Vega trust profile integration:** Native only. Other formats get the extension's raw capabilities, not the trust-profile-governed version.

Build output labels each target with a feature-surface badge: **Full** (native), **Governed** (MCP with Axiom runtime), **Standalone** (no governance features available in this format). Consumers see clearly what they're getting.

### Tooling Investment Commitment

The polyglot pipeline is a deliberate commitment despite added complexity. The benefits outweigh the costs:
- Ecosystem reach multiplies without per-extension engineering
- Creates a category the competition cannot match — no one else is building format-agnostic agent extensions
- The tooling itself is a competitive moat (Vyzier's build pipeline becomes harder to replicate over time)
- Answers the "why not just use [competitor]?" question with "our extensions run on [competitor] too"

---

## Dual-Mode Governance Enforcement

**Operating thesis:** Vega enforces trust at the server boundary, not the client. Whether the consumer is Axiom native or an external harness via MCP, authorization decisions happen server-side and cannot be bypassed by the client.

### Two Operating Modes

**Axiom Native Mode (strongest guarantees):**
- All operations governed end-to-end within Axiom runtime
- RACI approval in-UI; trust profiles fully applied; classification boundaries enforced at every step
- Recommended for: classified deployments, export-controlled content, regulated environments, high-trust institutional use
- Value prop: "Vega controls what can happen, not just who can see what."

**Governance-Layer Mode (via MCP to external harnesses):**
- External harness (Claude Code, OpenClaw, Cursor, etc.) makes MCP tool calls to Axiom
- Axiom's tool handlers are the enforcement point
- Server-side enforcement: classification filtering, access-tier-scoped responses, principal authorization, audit trail
- Client-side behavior after authorized delivery is outside Axiom's control (but audit trail exists)
- Recommended for: general agent work, teams already invested in another harness, faster adoption paths
- Value prop: "Your favorite harness gets access to what its principal is allowed to see — no more, no less — whether it behaves well or not."

### What MCP Governance Enforces (Server-Side, Uncircumventable)

- Classification ceiling filtering on all responses
- Access-tier-scoped results (restricted content invisible to public-tier principals)
- Principal resolution and authorization on every call
- Full audit trail (forensic record exists even if client misbehaves)
- Rate limiting per principal
- Credential revocation (instant access removal)
- Cryptographic federation identity (no spoofing)
- Trust-profile-controlled operation gating (tools appear/disappear by principal)

### What MCP Governance Cannot Enforce (Mitigations)

- **What the external harness does with authorized data after delivery** — mitigated by careful exposure: don't expose operations whose misuse is catastrophic
- **Side-channel leakage** (screenshots, copy-paste) — mitigated by anomaly detection on access patterns and forensic audit trail
- **Runtime behavior of the harness** (prompt injection, misuse) — mitigated by trust tiers for harnesses; certified harnesses get broader permissions than uncertified
- **RACI approval UX** works but is worse than native — mitigated by reserving RACI-heavy operations for native mode

### Positioning Implication

This duality is a strategic strength, not a weakness. It mirrors how enterprises already think about cloud services: AWS enforces IAM on API calls but does not control what happens with downloaded data on a customer's laptop. That model works because the trust boundary is drawn at the API, and everyone understands it.

Vega draws the same boundary. General agent work over MCP gets strong server-side guarantees. Most-sensitive operations stay in native runtime. The positioning is clean:

> "Use your favorite harness for everyday agent work — Vega enforces at the boundary. For classified or export-controlled work, run Axiom native. You choose the mode; Vega ensures you can't accidentally leak what you can't see."

---

## Domain & Trademark Strategy

### Immediate Actions (This Week)

1. **Trademark clearance searches** in USPTO TESS for:
   - Vega (in AI/software class)
   - Keplo and Keplo (global search — stylized form + alias; coined names should be clean)
   - Dendra (in AI/software class)
   - Vyzier (AI marketplace / developer tools class; appeared clean in initial search)
   - Axiom Labs DBA (confirm clearance vs. existing "Axiom" rights; active "Substrate Labs" is taken — do NOT use as DBA)
   - NeutronOS (confirm existing rights; low conflict risk due to specific domain)

2. **Domain acquisitions** (budget: $2-8K total for strategic domains across six products):
   - `vega.dev`, `vega.network`, `usevega.com`, `vegafederation.org`, `vega.foundation`
   - `keplo.com`, `keplo.ai`, `keplo.io`, `keplo.edu` (if available), `getkeplo.com`, `kep-lo.com`
   - `dendra.dev`, `dendra.ai`, `dendra.io`, `usedendra.com`
   - `vyzier.com`, `vyzier.dev`, `vyzier.ai`, `vyzier.io`, `getvyzier.com`
   - `axiomlabs.dev`, `axiom-labs.com`, `axiomlabs.ai` (for Axiom Labs DBA)
   - Protective registrations for obvious variations

3. **GitHub organization availability:**
   - `vega-protocol` (taken), `vega-federation`, `getvega`, `vega-project`
   - `keplo`, `keplo-platform`, `kep-lo`
   - `dendra`, `dendra-ml`
   - `vyzier`, `vyzier-registry`
   - `axiom-labs`, `axiomlabs`

### Naming Rationale Recap

- **Axiom Labs (DBA):** Brand-aligned with flagship product. Alternative to "Substrate Labs" (conflict: Lightspeed-backed AI-infrastructure company founded 2023). Axiom Labs signals category (AI infrastructure) without reuse conflict.

- **Vega:** Bright star in Lyra constellation. The star that was Earth's pole star 12,000 years ago (and will be again in 14,000 years). Associated with navigation, reference points, and Carl Sagan's *Contact* (communication across civilizations). Positive, sci-fi, semantically aligned with federation (each institution orients by a shared reference).

- **Keplo / Keplo:** Acura-style coinage from Kepler (Johannes Kepler, the astronomer who discovered planetary motion laws through careful observation). Keplo preserves the "Kep-" phonetic root without trademark conflict with Kepler's many other uses. Character-styled (AXI convention) because it's the instructor's companion agent. Canonical expansion: **K**epler **E**ducation **P**latform — **L**earning **O**bservatory.

- **Dendra:** From Greek *dendra* (trees) and related to *dendrite* (neural branching structure). Evokes branching decisions, neural networks, growth through connection. Reads naturally as an ML library name.

- **Vyzier:** Coined brand name; short, phonetically distinctive ("VIZ-ier"), no existing AI-marketplace conflict found. Connotes "vizier" (wise advisor in historical Islamic governance — a helpful counselor who guides decisions), which aligns with the role of an extension marketplace: a trusted advisor recommending what to install.

### Domain Backup Options

If trademark conflicts emerge:
- **Axiom Labs DBA fallback:** B-Tree Labs (keep entity-name thematic), Keplo Labs (align to character brand), Vyzier Labs (align to marketplace)
- **Vega fallback:** Canopus (navigation star, obscure enough for clean trademark)
- **Keplo fallback:** KEP-NA or Orba (similar coinage style, preserving AXI convention)
- **Dendra fallback:** Dendri or Dendron (related Greek-root variants)
- **Vyzier fallback:** Polyglot, Cartridge, Coracle (niche options)

---

## Go-To-Market Strategy

### Phased Release

**Phase 1 (Now → Prague, summer 2026):**
- Axiom and Keplo ship together for Prague classroom deployment
- NeutronOS ships integrated for UT/INL/OSU research use
- Vega primitives are internal (extracted as a product Phase 3)
- Dendra has spec only; implementation begins Phase 2
- Vyzier: MVP scope. Polyglot build pipeline (`axi ext build`) targets native + MCP + SKILL.md. Registry can be a simple signed-artifact store backed by object storage. Public launch deferred.

**Phase 2 (Prague deployment → Q4 2026):**
- Prague results inform Keplo public launch
- Dendra library publishes on PyPI (Python first, other languages follow)
- Axiom open-source launch with Vega primitives included
- NeutronOS continues integrated
- Vyzier public launch (Axiom Labs free tier) with polyglot publishing of Axiom ecosystem extensions

**Phase 3 (Q1 2027 onward):**
- Vega extracts as standalone product with commercial licensing
- Keplo public launch with SaaS offering
- NeutronOS commercial deployments begin
- Dendra research paper published (transition curves, scale thresholds, federated training)
- Vyzier paid tiers launch (private extensions, team features, enterprise registries)
- SoilMetrix refactor onto Axiom stack begins

### Channel Strategy by Product

| Product | Primary Channel | Secondary Channel |
|---|---|---|
| **Axiom** | Developer marketing (HN, Reddit, GitHub stars), open-source conferences | Enterprise sales for hosted version |
| **Vega** | Enterprise sales + industry analyst engagement | Open-source community for base primitives |
| **Keplo** | Education conferences (ISTE, SXSW EDU), university IT relationships | Direct-to-institution sales |
| **Dendra** | Developer marketing, ML conferences, research paper | Managed service sales |
| **Vyzier** | Developer marketing (ecosystem events, Claude Code community, MCP registry visibility), security content marketing (ClawHub contrast) | Enterprise registry sales |
| **NeutronOS** | Institutional sales, nuclear industry conferences, DOE programs | Research partnerships |

### Unified Portfolio Narrative

When the portfolio is presented together (keynotes, partnership conversations, investor pitches), the narrative structure:

> "Axiom is the platform for building agentic systems. Vega is the trust infrastructure that lets them federate. Keplo brings it to education. Dendra makes any classifier learn from outcomes. Vyzier distributes extensions to every major harness. NeutronOS applies it all to nuclear engineering. Each product stands alone. Together, they're a stack."

This is the "X stack" framing — used as umbrella messaging but not as a primary brand. The individual products carry their own market presence.

---

## Success Metrics Per Product

### Axiom
- GitHub stars: 10K by end of 2026
- Monthly active instances (telemetry opt-in): 500 by Q4 2026
- Paid customers (hosted or support): 5 by end of 2026
- Ecosystem extensions: 20 by end of 2026

### Vega
- Partner institutions federated: 5 by end of 2026 (TRIGA consortium as seed)
- Commercial pilots: 3 by Q1 2027
- Non-Axiom harness integrations: 2 by Q2 2027 (Hermes, LangChain, or similar)

### Keplo
- Prague deployment: completes with published research paper
- Institutions piloting: 3 by fall 2026 semester
- Students served: 500 by end of 2027 academic year
- LMS integrations: 2 (Canvas + Moodle) by Q2 2027

### Dendra
- PyPI downloads: 10K/month by end of 2026
- External adopters (non-Axiom projects): 5 by Q2 2027
- Research paper: submitted to NeurIPS or similar by summer 2027
- Multi-language implementations: 3 (Python, Rust, TypeScript) by end of 2026

### Vyzier
- Extensions published: 50 by end of 2026 (Axiom ecosystem + initial external contributors)
- Polyglot target formats supported: 4 (native, MCP, SKILL.md, LangChain) by Q4 2026; 6 by Q2 2027 (add CrewAI + A2A)
- Paid tier customers: 10 by end of 2027
- Enterprise registry deployments: 2 by end of 2027

### NeutronOS
- Founding consortium members: UT, INL, OSU active by summer 2026
- Commercial facility deployments: 1 by end of 2027
- Regulatory modules: 2 (NRC reporting, DOE data management) by Q2 2027

---

## Open Questions

1. **UT OTC terms for commercial operation of Vega, Keplo, and NeutronOS** — pending engagement
2. **Nonprofit foundation for Vega?** — consider if TRIGA consortium wants joint governance
3. **Axiom public launch timing** — coordinate with Prague results or launch earlier?
4. **Dendra multi-language implementation priority** — Rust second or TypeScript second?
5. **Keplo SaaS infrastructure** — hosted by Axiom Labs? By UT? By a third party?
6. **Vyzier registry backing store** — object storage (S3 / compatible) MVP, or purpose-built registry from day one?
7. **Axiom Labs DBA filing** — which state (Texas for B-Tree Ventures home)? Timing — before or after first OTC conversation?
8. **SoilMetrix refactor timeline** — aligned with Axiom public launch, or independent?

These decisions are time-sensitive but not blocking. Current execution proceeds under placeholder assumptions, with formal decisions layered in as conversations complete.

---

## Architectural Implications for Implementation

As the codebase evolves toward this product structure, code placement must anticipate extraction:

### What lives where

**Axiom (B-Tree-owned, at `axiom/src/axiom/`):**
- Core agent runtime (gateway, prompts, memory primitives, session management, extension system)
- RAG retriever, RPE (retrieval policy engine), citation
- SCAN base signal pipeline (extractors, synthesizer — the generic parts)
- PRESS publication lifecycle
- TIDY resource stewardship
- TRIAGE diagnostics
- CLI framework and `axi` commands
- MCP server base + `axi` MCP server

**Vega (UT-owned, destined for separate repo):**
- Federation identity (Ed25519, A2A protocol)
- Trust profiles and RACI primitives
- Classification stamps and content-tier enforcement
- Manifest channel for cross-node propagation
- Federation bootstrap and invitation tokens
- Resource selection across federation
- Currently in `axiom/src/axiom/federation/` and `axiom/src/axiom/security/` — extraction boundary

**Keplo (UT-owned, destined for separate repo):**
- Course manifest and syllabus extraction
- Student learning ledger
- Structured Q&A engine
- Interaction classification
- CHALKE instructor brief
- Canvas/LMS integration
- Classroom-specific signal registrations
- Currently in `axiom/src/axiom/extensions/builtins/classroom/` — extraction boundary

**Dendra (Axiom Labs / B-Tree-owned, destined for separate repo):**
- LearnedSwitch primitive implementation
- Multi-language library (Python first)
- ONNX export
- Decorator API
- Currently: zero code (spec only in `axiom/docs/specs/spec-learned-switch.md`)

**Vyzier (Axiom Labs / B-Tree-owned, destined for separate repo):**
- Polyglot extension build pipeline (`axi ext build`, format transformers)
- Extension manifest schema (canonical source format)
- Registry service (signed artifact store, metadata catalog)
- Build infrastructure (CI pipeline generating all target formats from one source)
- Publish tooling (`axi ext publish`, version management, deprecation)
- Static analysis integration (Dendra-classified safety scanning)
- Signed provenance (Ed25519 via Vega identity primitives)
- Currently: no code. Build pipeline tools will emerge in `axiom/src/axiom/extensions/` as extraction preparation, then move to the Vyzier repo.

**NeutronOS (UT-owned, stays in `Neutron_OS/`):**
- Model corral
- Facility packs
- Nuclear-specific SCAN extractors
- NRC compliance modules
- Nuclear domain classification rules

### Extraction Discipline

Until the products formally extract to separate repos, code placement should minimize the extraction delta:

- Federation code should not import from classroom code (and vice versa)
- Classroom code should only import from Axiom public APIs, not internals
- Generic primitives belong in Axiom base; domain behavior in extensions
- When in doubt, ask: "If this had to live in a different repo with only public APIs, what would break?" Architect to minimize that breakage.

The repo split is deferred but the architectural discipline is not.
_Copyright (c) 2026 The University of Texas at Austin and B-Tree Labs. Apache-2.0 licensed._
