# Changelog

All notable changes to Axiom are documented in this file.

## [0.15.1] — 2026-05-08 — Re-release of 0.15.0 content (PyPI 0.15.0 was a phantom)

PyPI's `axiom-os-lm 0.15.0` (published 2026-05-06) was an accidental release built from an orphan version-bump commit (`dba60dd1`) that never reached `main`. It contained essentially only the version number change. The real 0.15.0 content — cross-tool memory MCP foundation, post-Prague hardening, and the agent rename — landed on `main` in PR #171 (2026-05-08) and ships as **0.15.1**.

The PyPI 0.15.0 release stays in place (immutable, can't be replaced); 0.15.1 is the canonical version users should install. Same surface as the [0.15.0] section below; treat that section as the change-log for 0.15.1's content.

## [0.15.0] — 2026-05-08 (PyPI release built from PR #171 — phantom on PyPI; superseded by 0.15.1) — Cross-tool memory MCP foundation + post-Prague tight-cut hardening

### Added — axiom-memory MCP server (per-extension topology)

The shared cross-tool, cross-session memory substrate. Every LLM tool the user
touches (Claude Code, Codex, Gemini, OpenCode, axi chat, future tools) writes
to and reads from the same per-principal ledger via a common path.

- New `axiom-memory` MCP server at `axiom.extensions.builtins.memory.mcp_server`
  exposing read tools (`axiom_memory_show`, `_recent`, `_search`) and write
  tools (`axiom_memory_append`). Server `instructions` field carries the
  cross-vendor model-discipline prompt for tools without on-disk session logs.
- New `axiom.memory.session_capture.record_session_turn()` — the common write
  path the MCP, CLI, and (eventual) `axi chat` all converge on. Provenance
  encodes originating tool + model in the agents set so cross-tool queries can
  scope by origin.
- `axi memory record [--principal] [--tool] [--user-input] [--assistant-output]`
  for shell-driven writes. `--json-stdin` reads a JSON event for hooks /
  automation.
- `axi memory ingest <path>` folds Claude Code session JSONL transcripts into
  the ledger via the common path. Idempotent on `content.extra.source_uuid`.
  `--watch` polling mode supports incremental ingest as the transcript grows.
- `axi memory ingest --tool <name>` dispatches by parser. claude-code is
  canonical; opencode / gemini / chatgpt-desktop are stubs raising
  NotImplementedError with a contributor pointer.
- Memory extension manifest declares the MCP via `[mcp_servers.axiom-memory]`
  so `axi ext mcp --target claude_code` aggregates it alongside other
  extensions.

### Added — post-Prague memory hardening (tight cut)

Items pulled forward from `project_axi_memory_failure_modes_and_selfheal` to
close the highest-leverage silent-dysfunction classes before Prague:

- **Default principal pin** via `memory.default_principal` setting. CLI and
  MCP fall back to the pin when callers omit `--principal` / `principal_id`,
  closing the cross-identity footgun (e.g. canonical UT email vs harness-
  provided account email).
- **Per-tool registrar protocol** in `axiom.extensions.builtins.memory.register_mcp`.
  `TOOL_REGISTRARS` maps tool name → `ToolRegistrar` (detect + register +
  is_registered). `axi memory register-mcp --all` walks every detected tool;
  `--tool <name>` for a single tool. New Codex registrar (writes
  `~/.codex/config.toml` via tomlkit, idempotent). Gemini and OpenCode are
  stubs.
- **Heartbeat fragment + freshness check.** `axi memory heartbeat` writes a
  periodic `fact_kind=heartbeat` fragment via the common path. `axi memory
  heartbeat-install` lays down a launchd plist
  (`~/Library/LaunchAgents/com.axiom.memory.heartbeat.plist`) for hourly
  cadence; `heartbeat-uninstall` reverses it. `axi dr` flags missing/stale
  heartbeats: ≤60min OK, 60–120min WARN, >120min ERROR.
- **`axi dr` principal-pin reconciliation.** Samples the 25 most-recent
  fragments and WARNs when recent writes used a principal other than the
  pinned default — catches drift before users wonder why memory is "empty."
- **`axi dr` MCP-registration check** (resolves symlinks so `python` ≡
  `python3.14` in the same venv don't false-positive as stale).

### Renamed — agents (IP remediation, was Unreleased before 0.15.0)

Renamed agents to remove Pixar/WALL-E derivation:
- WALL-E → AXI (the chat/orchestrator agent)
- EVE → SCAN
- M-O → TIDY
- BURN-E → RIVET
- D-FIB → TRIAGE
- PR-T → PRESS
- CURI-O → CURIO (dash dropped)
- CHALK-E → CHALKE (dash dropped)
- V-EGA → WARDEN

CLI nouns updated where they matched old agent names. PyPI script entry points
`walle` and `wall-e` removed (agent identity unified with the `axi` binary).
No backwards aliases — pre-public, no external users to deprecate.

### Notes

- Tests: 423 passed / 4 skipped in the targeted memory + cli + classroom sweep.
- 49 new tests across the post-Prague tight-cut items.
- Out of scope (still post-Prague queue): per-tool MCP liveness probe, file-
  watch on tool configs, audit-log → SQLite replay, RACI escalation surface,
  privacy knobs, opt-in install wizard, onboarding seed fragment, Linux
  systemd-timer install.

---

## [Pre-0.15.0 history — previously labeled Unreleased] — 2026-05-04 — Agent rename (IP remediation)

Renamed agents to remove Pixar/WALL-E derivation:
- WALL-E → AXI (the chat/orchestrator agent)
- EVE → SCAN
- M-O → TIDY
- BURN-E → RIVET
- D-FIB → TRIAGE
- PR-T → PRESS
- CURI-O → CURIO (dash dropped)
- CHALK-E → CHALKE (dash dropped)
- V-EGA → WARDEN

CLI nouns updated where they matched old agent names. PyPI script entry points `walle`
and `wall-e` removed (agent identity unified with the `axi` binary). No backwards
aliases — pre-public, no external users to deprecate.
