"""Synchronous client for the TonWise Security API."""

from typing import Any, Dict, List, Optional

import requests

from ._version import __version__
from .exceptions import APIError, AuthError, RateLimitError, TierError
from .models import ScanResult, ThreatIntelResult


def _handle_response(resp: requests.Response) -> Dict[str, Any]:
    """Map HTTP status codes to typed exceptions; return parsed JSON on success.

    403 routing: tier-gate responses include ``current_tier`` in body and raise
    :class:`TierError`; other 403s (e.g. invalid key) raise :class:`APIError`.
    """
    if resp.status_code == 401:
        raise AuthError("Invalid API key")
    if resp.status_code == 429:
        raise RateLimitError(
            "Rate limit exceeded",
            retry_after=int(resp.headers.get("Retry-After", 60)),
        )
    if resp.status_code == 403:
        try:
            data = resp.json()
        except (ValueError, requests.exceptions.JSONDecodeError):
            data = None
        if isinstance(data, dict) and "current_tier" in data:
            raise TierError(
                data.get("error") or "Tier upgrade required",
                current_tier=data.get("current_tier"),
            )
        # fall through to APIError for non-tier 403s (e.g. invalid key)
    if not resp.ok:
        raise APIError(
            f"API request failed: HTTP {resp.status_code}",
            status_code=resp.status_code,
            body=resp.text[:500],
        )
    return resp.json()


class TonWiseClient:
    """Synchronous client for the TonWise Security API.

    Example:
        >>> from tonwise import TonWiseClient
        >>> with TonWiseClient(api_key="tg_live_xxx") as client:
        ...     result = client.scan("EQA1234...")
        ...     print(result.is_safe, result.dump_probability)
    """

    BASE_URL = "https://tonguard.app"

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: float = 10.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")

        self.api_key = api_key
        self.base_url = (base_url or self.BASE_URL).rstrip("/")
        self.timeout = timeout

        self.session = requests.Session()
        self.session.headers.update(
            {
                "X-API-Key": api_key,
                "User-Agent": f"tonwise-python/{__version__}",
                "Accept": "application/json",
            }
        )

    # ─────────────────────────── public API ────────────────────────

    def scan(self, contract: str) -> ScanResult:
        """Scan a TON contract for security risks.

        Args:
            contract: Raw TON contract address (e.g., ``"EQA1234..."``).

        Returns:
            :class:`ScanResult` with dump probability, sybil clusters, etc.

        Raises:
            AuthError: invalid API key.
            RateLimitError: rate limit hit; check ``.retry_after``.
            APIError: other 4xx/5xx responses.
        """
        url = f"{self.base_url}/api/v1/shield"
        resp = self.session.get(
            url,
            params={"contract": contract},
            timeout=self.timeout,
        )
        return ScanResult(**_handle_response(resp))

    def threat_intel(self, address: str) -> ThreatIntelResult:
        """Get aggregated threat intelligence for a TON address.

        Available on **Scale tier and above**. Performs BFS traversal on the
        Lazarus graph around the address (depth=3, cap 5000 nodes) and
        returns linked scams, threat score, cluster membership, and any
        cross-chain exit history available.

        Args:
            address: TON address. Server currently expects raw ``0:hex``
                format; ``EQ.../UQ...`` user-friendly format may not match
                graph entries until server-side canonicalization lands.

        Returns:
            :class:`ThreatIntelResult` — threat_score (0-100), linked_scams,
            labels, cluster_id, etc.

        Raises:
            AuthError: invalid API key.
            TierError: API key tier is below Scale; check ``.current_tier``
                for caller's current tier (``"free"``, ``"pro"``).
            RateLimitError: rate limit hit; check ``.retry_after``.
            APIError: other 4xx/5xx responses.

        Example:
            >>> with TonWiseClient(api_key="tg_scale_xxx") as client:
            ...     try:
            ...         intel = client.threat_intel("0:dae153...")
            ...         print(f"Score: {intel.threat_score}")
            ...         for scam in intel.linked_scams:
            ...             print(f"  Linked: {scam.contract} ({scam.symbol})")
            ...     except TierError as e:
            ...         print(f"Need Scale tier, you have: {e.current_tier}")
        """
        url = f"{self.base_url}/api/v1/threat-intel/{address}"
        resp = self.session.get(url, timeout=self.timeout)
        return ThreatIntelResult(**_handle_response(resp))

    def register_webhook(
        self,
        url: str,
        events: List[str],
        secret: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Register a webhook subscription.

        Args:
            url: Public HTTPS endpoint to receive callbacks.
            events: List of event types to subscribe to. Use ``["*"]`` for all.
            secret: Optional HMAC-SHA256 secret. If omitted, the server
                generates one and returns it in the response.

        Returns:
            Server response with ``webhook_id``, ``secret``, ``created_at``.
        """
        endpoint = f"{self.base_url}/api/v1/webhook/register"
        payload: Dict[str, Any] = {"url": url, "events": events}
        if secret is not None:
            payload["secret"] = secret
        resp = self.session.post(endpoint, json=payload, timeout=self.timeout)
        return _handle_response(resp)

    def list_webhooks(self, active_only: bool = True) -> List[Dict[str, Any]]:
        """List webhooks attached to the current API key."""
        endpoint = f"{self.base_url}/api/v1/webhook/list"
        params = {"active_only": "true" if active_only else "false"}
        resp = self.session.get(endpoint, params=params, timeout=self.timeout)
        data = _handle_response(resp)
        return data.get("webhooks", [])

    def delete_webhook(self, webhook_id: int) -> bool:
        """Soft-delete a webhook by ID. Returns True if deleted, False if 404."""
        endpoint = f"{self.base_url}/api/v1/webhook/{webhook_id}"
        resp = self.session.delete(endpoint, timeout=self.timeout)
        if resp.status_code == 404:
            return False
        _handle_response(resp)
        return True

    # ─────────────────────────── lifecycle ─────────────────────────

    def close(self) -> None:
        self.session.close()

    def __enter__(self) -> "TonWiseClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()