"""Pydantic v2 response models for the TonWise API."""

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


class ScanResult(BaseModel):
    """Result of GET /api/v1/shield."""

    model_config = ConfigDict(extra="ignore")

    contract: str
    is_safe: bool
    dump_probability: int = Field(ge=0, le=100)
    reason: str
    sybil_clusters: int = 0
    stake_concentration: Optional[float] = None
    total_sybils: Optional[int] = None


class BadgeResult(BaseModel):
    """Result of GET /api/badge."""

    model_config = ConfigDict(extra="ignore")

    score: int = Field(ge=0, le=100)
    label: str  # 'SAFE' | 'WARNING' | 'DANGER' | 'UNKNOWN'
    color: str  # 'green' | 'yellow' | 'red' | 'gray'


# ─────────────────────────────────────────────────────────────────────────────
# Threat Intel API (added in 0.2.0)
# ─────────────────────────────────────────────────────────────────────────────

class LinkedScam(BaseModel):
    """A scam-flagged address linked to the queried address in the graph.

    ``symbol`` carries the Lazarus threat label (e.g. ``"SYBIL"``,
    ``"Scam/Risk"``) — not necessarily a jetton symbol; semantics will be
    clarified in API docs.
    """

    model_config = ConfigDict(extra="ignore")

    contract: str
    symbol: str
    first_seen: Optional[str] = None
    labels: List[str] = Field(default_factory=list)


class CrossChainExit(BaseModel):
    """Cross-chain exit event detected for the queried address.

    Currently always empty — populated when ``KNOWN_INFRASTRUCTURE`` mapping
    is wired up server-side (Sprint 3+).
    """

    model_config = ConfigDict(extra="ignore")

    bridge: str
    timestamp: str


class ThreatIntelResult(BaseModel):
    """Result of GET /api/v1/threat-intel/{address}.

    Available on Scale tier and above. Aggregates threat intelligence around
    a TON address by traversing the Lazarus graph (BFS depth=3, capped at
    5000 visited nodes for predictable latency).

    Note on empty responses: if ``threat_score == 0`` and
    ``associated_addresses == 0``, the address is not yet in the graph
    (different from "in the graph but clean"). Common for fresh wallet
    addresses or when sending the address in a format the server doesn't
    canonicalize yet.
    """

    model_config = ConfigDict(extra="ignore")

    address: str
    threat_score: int = Field(ge=0, le=100)
    first_seen: Optional[str] = None
    last_activity: Optional[str] = None
    associated_addresses: int = 0
    linked_scams: List[LinkedScam] = Field(default_factory=list)
    puppet_master_cluster_id: Optional[str] = None
    labels: List[str] = Field(default_factory=list)
    cross_chain_exits: List[CrossChainExit] = Field(default_factory=list)
    graph_depth: int = 0
    computed_at: str