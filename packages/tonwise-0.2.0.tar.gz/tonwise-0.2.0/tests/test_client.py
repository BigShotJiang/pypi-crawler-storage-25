"""Smoke tests for the TonWise SDK.

Covers:
  - Successful scan (sync + async)
  - 401 → AuthError
  - 429 → RateLimitError with retry_after
  - Empty api_key → ValueError
  - Webhook register/list/delete (sync)
"""
import re

import pytest
import responses
from aioresponses import aioresponses

from tonwise import (
    APIError,
    AsyncTonWiseClient,
    AuthError,
    RateLimitError,
    ScanResult,
    TonWiseClient,
    __version__,
)

BASE = "https://tonguard.app"
KEY = "tg_test_key"


# ─────────────────────────── version sanity ────────────────────────


def test_version_string() -> None:
    assert isinstance(__version__, str)
    assert __version__.count(".") >= 2  # SemVer X.Y.Z


# ─────────────────────────── sync client ───────────────────────────


@responses.activate
def test_sync_scan_ok() -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/shield",
        json={
            "contract": "EQA123",
            "is_safe": True,
            "dump_probability": 12,
            "reason": "no risk indicators",
            "sybil_clusters": 0,
        },
        status=200,
    )
    with TonWiseClient(api_key=KEY) as c:
        result = c.scan("EQA123")

    assert isinstance(result, ScanResult)
    assert result.is_safe is True
    assert result.dump_probability == 12
    # Verify our headers were sent
    assert responses.calls[0].request.headers["X-API-Key"] == KEY
    assert "tonwise-python" in responses.calls[0].request.headers["User-Agent"]


@responses.activate
def test_sync_auth_error() -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/shield",
        json={"error": "Invalid API key"},
        status=401,
    )
    with TonWiseClient(api_key="bad") as c:
        with pytest.raises(AuthError):
            c.scan("EQA123")


@responses.activate
def test_sync_rate_limit_with_retry_after() -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/shield",
        json={"error": "rate limit"},
        status=429,
        headers={"Retry-After": "30"},
    )
    with TonWiseClient(api_key=KEY) as c:
        with pytest.raises(RateLimitError) as exc:
            c.scan("EQA123")
    assert exc.value.retry_after == 30


@responses.activate
def test_sync_api_error_carries_body() -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/shield",
        body="Internal Server Error",
        status=500,
    )
    with TonWiseClient(api_key=KEY) as c:
        with pytest.raises(APIError) as exc:
            c.scan("EQA123")
    assert exc.value.status_code == 500
    assert "Internal" in (exc.value.body or "")


def test_sync_api_key_required() -> None:
    with pytest.raises(ValueError):
        TonWiseClient(api_key="")


@responses.activate
def test_sync_register_webhook() -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/webhook/register",
        json={
            "webhook_id": 42,
            "url": "https://example.com/cb",
            "events": ["scam", "spoof"],
            "secret": "abc123",
            "client_name": "test",
            "created_at": "2026-05-06T12:00:00Z",
        },
        status=201,
    )
    with TonWiseClient(api_key=KEY) as c:
        result = c.register_webhook(
            url="https://example.com/cb",
            events=["scam", "spoof"],
        )
    assert result["webhook_id"] == 42
    assert result["secret"] == "abc123"


@responses.activate
def test_sync_list_webhooks() -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/webhook/list",
        json={
            "client": "test",
            "total": 1,
            "webhooks": [
                {
                    "webhook_id": 1,
                    "url": "https://example.com/cb",
                    "events": ["scam"],
                    "is_active": True,
                    "trigger_count": 5,
                    "last_triggered": None,
                    "created_at": "2026-05-06T12:00:00Z",
                }
            ],
        },
        status=200,
    )
    with TonWiseClient(api_key=KEY) as c:
        hooks = c.list_webhooks()
    assert len(hooks) == 1
    assert hooks[0]["webhook_id"] == 1


@responses.activate
def test_sync_delete_webhook_ok_and_404() -> None:
    responses.add(
        responses.DELETE,
        f"{BASE}/api/v1/webhook/1",
        json={"webhook_id": 1, "is_active": False},
        status=200,
    )
    responses.add(
        responses.DELETE,
        f"{BASE}/api/v1/webhook/999",
        json={"error": "Not found"},
        status=404,
    )
    with TonWiseClient(api_key=KEY) as c:
        assert c.delete_webhook(1) is True
        assert c.delete_webhook(999) is False


# ─────────────────────────── async client ──────────────────────────


# aioresponses matches the full URL including query string. We use a
# regex matcher so tests don't have to know aiohttp's exact query encoding.
SHIELD_RE = re.compile(rf"^{re.escape(BASE)}/api/v1/shield(\?.*)?$")
WEBHOOK_REGISTER_RE = re.compile(rf"^{re.escape(BASE)}/api/v1/webhook/register$")
WEBHOOK_LIST_RE = re.compile(rf"^{re.escape(BASE)}/api/v1/webhook/list(\?.*)?$")


@pytest.mark.asyncio
async def test_async_scan_ok() -> None:
    with aioresponses() as m:
        m.get(
            SHIELD_RE,
            payload={
                "contract": "EQA123",
                "is_safe": False,
                "dump_probability": 91,
                "reason": "high stake concentration",
                "sybil_clusters": 7,
            },
            status=200,
        )
        async with AsyncTonWiseClient(api_key=KEY) as c:
            result = await c.scan("EQA123")
    assert result.is_safe is False
    assert result.sybil_clusters == 7


@pytest.mark.asyncio
async def test_async_auth_error() -> None:
    with aioresponses() as m:
        m.get(SHIELD_RE, status=401, payload={"error": "Invalid API key"})
        async with AsyncTonWiseClient(api_key="bad") as c:
            with pytest.raises(AuthError):
                await c.scan("EQA123")


@pytest.mark.asyncio
async def test_async_rate_limit_with_retry_after() -> None:
    with aioresponses() as m:
        m.get(
            SHIELD_RE,
            status=429,
            payload={"error": "rate limit"},
            headers={"Retry-After": "15"},
        )
        async with AsyncTonWiseClient(api_key=KEY) as c:
            with pytest.raises(RateLimitError) as exc:
                await c.scan("EQA123")
    assert exc.value.retry_after == 15


@pytest.mark.asyncio
async def test_async_register_webhook() -> None:
    with aioresponses() as m:
        m.post(
            WEBHOOK_REGISTER_RE,
            payload={
                "webhook_id": 7,
                "url": "https://example.com/cb",
                "events": ["*"],
                "secret": "topsecret",
                "client_name": "test",
                "created_at": "2026-05-06T12:00:00Z",
            },
            status=201,
        )
        async with AsyncTonWiseClient(api_key=KEY) as c:
            result = await c.register_webhook(
                url="https://example.com/cb",
                events=["*"],
            )
    assert result["webhook_id"] == 7


@pytest.mark.asyncio
async def test_async_session_required() -> None:
    """Calling scan() without entering the context manager must raise."""
    c = AsyncTonWiseClient(api_key=KEY)
    with pytest.raises(RuntimeError):
        await c.scan("EQA123")


def test_async_api_key_required() -> None:
    with pytest.raises(ValueError):
        AsyncTonWiseClient(api_key="")
