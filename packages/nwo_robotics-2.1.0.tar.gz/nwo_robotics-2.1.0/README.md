# NWO Robotics CLI

[![PyPI version](https://badge.fury.io/py/nwo-robotics.svg)](https://badge.fury.io/py/nwo-robotics)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Apache%202.0-green.svg)](LICENSE)

Command-line interface for the NWO Robotics API - control robots, manage swarms, and orchestrate intelligent automation with natural language.

## Features

- 🤖 **Robot Control** - Natural language commands for any supported robot
- 🌐 **Swarm Management** - Coordinate multi-robot teams
- 🧠 **AI Models** - Access VLA (Vision-Language-Action) models
- 📡 **IoT Integration** - Sensor fusion with robot commands
- 📶 **WiFi Sensing** - WiROS integration for CSI/RSSI sensing
- 👤 **Human Detection** - RuView WiFi-based pose and vital signs
- 🔒 **Safety Systems** - Built-in collision avoidance and ethics engine
- 📊 **Online Learning** - Continuous RL from telemetry

## Installation

```bash
pip install nwo-robotics
```

## Quick Start

```bash
# Authenticate
nwo auth login

# Control a robot with natural language
nwo robot "pick up the box and place it on the table"

# List available AI models
nwo models list

# Create a robot swarm
nwo swarm create "Warehouse Team"

# Enable WiFi sensing
nwo sensor wiros enable --interface wlan0
```

## Commands

| Command | Description |
|---------|-------------|
| `nwo auth` | Authentication and API key management |
| `nwo robot` | Send commands to robots |
| `nwo swarm` | Multi-robot swarm management |
| `nwo models` | AI model management |
| `nwo iot` | IoT sensor integration |
| `nwo sensor` | WiFi sensing (WiROS, RuView) |
| `nwo tasks` | Task queue management |
| `nwo learning` | Online RL and fine-tuning |
| `nwo safety` | Safety and ethics controls |
| `nwo monitor` | Real-time telemetry |
| `nwo config` | CLI configuration |

## WiFi Sensing

The NWO CLI integrates with WiROS for WiFi-based sensing:

```bash
# Enable WiROS CSI sensing
nwo sensor wiros enable --interface wlan0 --mode csi

# View available topics
nwo sensor wiros topics

# Stream CSI data
nwo sensor wiros stream /nwo/wiros/csi --to-topic /nwo/sensors/wifi_csi

# Extract bearing information
nwo sensor wiros bearing --algorithm music

# Multi-sensor fusion
nwo sensor fusion --sensors wiros --sensors ruview
```

See [WIROS-INTEGRATION.md](WIROS-INTEGRATION.md) for detailed documentation.

## API Documentation

- API Base: `https://nwo.capital/webapp`
- Documentation: `https://nwo.capital/docs`
- Dashboard: `https://nwo.capital/webapp/api-key.php`

## Requirements

- Python 3.8+
- API key from [NWO Capital](https://nwo.capital/webapp/api-key.php)

## License

Apache 2.0 - See [LICENSE](LICENSE) for details.

## Support

- Website: https://nwo.capital
- Email: ciprian.pater@publicae.org
- Issues: https://github.com/RedCiprianPater/nwo-robotics-cli/issues
