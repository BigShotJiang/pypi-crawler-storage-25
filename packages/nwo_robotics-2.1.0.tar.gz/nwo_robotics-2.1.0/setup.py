"""
NWO Robotics CLI
A command-line interface for the NWO Robotics API v2.0
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="nwo-robotics",
    version="2.1.0",
    author="NWO Robotics",
    author_email="ciprian.pater@publicae.org",
    description="CLI tool for NWO Robotics API v2.0",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://nwo.capital",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "click>=8.0.0",
        "requests>=2.25.0",
        "rich>=10.0.0",
        "pydantic>=1.8.0",
        "pyyaml>=5.4.0",
        "websockets>=10.0",
    ],
    entry_points={
        "console_scripts": [
            "nwo=nwo_cli.main:cli",
        ],
    },
)
