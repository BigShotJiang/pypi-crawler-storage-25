# Commands package
from . import (
    auth, config, iot, learning, models, monitor, 
    robot, safety, sensor, swarm, tasks, templates
)
