"""
Monitor commands for NWO CLI
"""

import click
from rich.console import Console

console = Console()


@click.group(name="monitor")
def monitor():
    """
    Monitor robots and swarms in real-time.
    
    Examples:
        nwo monitor --agent bot_001
        nwo monitor --swarm swarm_abc123
    """
    pass


@monitor.command(name="start")
@click.option("--agent", "agent_id", help="Agent to monitor")
@click.option("--swarm", "swarm_id", help="Swarm to monitor")
def start_monitor(agent_id, swarm_id):
    """Start real-time monitoring."""
    console.print("[yellow]Real-time monitoring requires WebSocket support (v2.1)[/yellow]")
    console.print("[dim]Feature coming soon with live telemetry streaming.[/dim]")
    
    if agent_id:
        console.print(f"\nTo monitor {agent_id}:")
        console.print(f"  wss://nwo.capital/ws/agent/{agent_id}")
    elif swarm_id:
        console.print(f"\nTo monitor swarm {swarm_id}:")
        console.print(f"  wss://nwo.capital/ws/swarm/{swarm_id}")


@monitor.command(name="logs")
@click.option("--agent", "agent_id", required=True, help="Agent ID")
@click.option("--lines", "-n", default=50, help="Number of log lines")
def get_logs(agent_id, lines):
    """Get robot logs."""
    console.print(f"[yellow]Log retrieval for {agent_id} (last {lines} lines)[/yellow]")
    console.print("[dim]Feature coming in v2.1[/dim]")
