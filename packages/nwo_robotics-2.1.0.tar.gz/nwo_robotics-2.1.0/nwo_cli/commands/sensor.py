"""
WiROS sensor commands for NWO CLI
WiFi CSI sensing via WiROS ROS2 toolbox
"""

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
import json
import subprocess
import os

console = Console()


@click.group(name="sensor")
def sensor():
    """
    Manage WiFi sensing sensors (WiROS, RuView).
    
    WiROS: ROS2 toolbox for WiFi CSI (Channel State Information)
    RuView: WiFi-based human pose and vital sign detection
    
    Examples:
        nwo sensor enable wiros --interface wlan0
        nwo sensor stream /rf_msgs/CSI --to-topic /nwo/sensors/wifi_csi
        nwo sensor status
        nwo sensor calibrate --sensor wiros
    """
    pass


# =============================================================================
# WiROS Commands
# =============================================================================

@sensor.group(name="wiros")
def wiros():
    """
    WiROS WiFi sensing toolbox integration.
    
    Provides access to WiFi Channel State Information (CSI), RSSI,
    and MAC-layer data as native ROS2 topics.
    
    Requires: WiFi NIC with monitor mode support (e.g., Intel AX200, Raspberry Pi)
    """
    pass


@wiros.command(name="enable")
@click.option("--interface", "-i", default="wlan0", help="WiFi interface (default: wlan0)")
@click.option("--mode", "-m", type=click.Choice(["csi", "rssi", "both"]), default="csi",
              help="Sensing mode: csi (fine-grained), rssi (coarse), both")
@click.option("--channel", "-c", type=int, default=36, help="WiFi channel (default: 36/5GHz)")
@click.option("--bandwidth", "-b", type=click.Choice(["20", "40", "80"]), default="80",
              help="Channel bandwidth in MHz")
@click.option("--docker", is_flag=True, help="Run WiROS in Docker container")
@click.option("--namespace", "-n", default="/nwo/wiros", help="ROS2 topic namespace")
def enable_wiros(interface, mode, channel, bandwidth, docker, namespace):
    """
    Enable WiROS WiFi sensing on specified interface.
    
    This configures the WiFi NIC in monitor mode and starts the WiROS
    CSI node to publish WiFi measurements as ROS2 topics.
    
    Examples:
        nwo sensor wiros enable --interface wlan0 --mode csi
        nwo sensor wiros enable -i wlan1 -m both --channel 6 --docker
    """
    console.print(Panel(
        f"[bold green]Enabling WiROS WiFi Sensing[/bold green]\n\n"
        f"[cyan]Interface:[/cyan] {interface}\n"
        f"[cyan]Mode:[/cyan] {mode}\n"
        f"[cyan]Channel:[/cyan] {channel}\n"
        f"[cyan]Bandwidth:[/cyan] {bandwidth}MHz\n"
        f"[cyan]Namespace:[/cyan] {namespace}\n"
        f"[cyan]Docker:[/cyan] {'Yes' if docker else 'No'}",
        title="WiROS Configuration",
        border_style="green"
    ))
    
    with console.status("[bold green]Starting WiROS..."):
        if docker:
            # Run WiROS in Docker
            cmd = [
                "docker", "run", "-d", "--name", "nwo-wiros",
                "--privileged", "--network", "host",
                "-e", f"WIFI_INTERFACE={interface}",
                "-e", f"WIFI_CHANNEL={channel}",
                "-e", f"WIFI_BANDWIDTH={bandwidth}",
                "-e", f"ROS_NAMESPACE={namespace}",
                "nworobotics/wiros:latest"
            ]
        else:
            # Run natively via ros2 launch
            cmd = [
                "ros2", "launch", "wiros_csi_node", "csi_node.launch.py",
                f"interface:={interface}",
                f"channel:={channel}",
                f"bandwidth:={bandwidth}",
                f"namespace:={namespace}"
            ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                console.print(f"[green]✓ WiROS started successfully[/green]")
                if docker:
                    console.print(f"[dim]Container ID: {result.stdout.strip()[:12]}[/dim]")
            else:
                console.print(f"[red]✗ Failed to start WiROS[/red]")
                console.print(f"[red]{result.stderr}[/red]")
        except subprocess.TimeoutExpired:
            console.print("[yellow]⚠ WiROS startup timed out (may still be running)[/yellow]")
        except FileNotFoundError as e:
            console.print(f"[red]✗ Command not found: {e}[/red]")
            console.print("[dim]Ensure ROS2 and WiROS are installed, or use --docker[/dim]")


@wiros.command(name="disable")
@click.option("--docker", is_flag=True, help="Stop Docker container")
def disable_wiros(docker):
    """Disable WiROS and restore WiFi interface to managed mode."""
    with console.status("[bold yellow]Stopping WiROS..."):
        if docker:
            subprocess.run(["docker", "stop", "nwo-wiros"], capture_output=True)
            subprocess.run(["docker", "rm", "nwo-wiros"], capture_output=True)
        else:
            # Find and kill WiROS processes
            subprocess.run(["pkill", "-f", "wiros_csi_node"], capture_output=True)
        
        # Restore WiFi interface
        subprocess.run(["sudo", "ip", "link", "set", "wlan0", "down"], capture_output=True)
        subprocess.run(["sudo", "iw", "dev", "wlan0", "set", "type", "managed"], capture_output=True)
        subprocess.run(["sudo", "ip", "link", "set", "wlan0", "up"], capture_output=True)
    
    console.print("[green]✓ WiROS disabled, WiFi restored to managed mode[/green]")


@wiros.command(name="topics")
def list_wiros_topics():
    """List available WiROS ROS2 topics."""
    table = Table(title="WiROS ROS2 Topics")
    table.add_column("Topic", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Description", style="white")
    
    topics = [
        ("/nwo/wiros/csi", "rf_msgs/CSI", "Channel State Information (CSI)"),
        ("/nwo/wiros/rssi", "rf_msgs/RSSI", "Received Signal Strength Indicator"),
        ("/nwo/wiros/mac", "rf_msgs/Mac", "MAC-layer information"),
        ("/nwo/wiros/aoa", "rf_msgs/AoA", "Angle of Arrival (bearing)"),
        ("/nwo/wiros/aod", "rf_msgs/AoD", "Angle of Departure"),
        ("/nwo/wiros/compass", "sensor_msgs/Imu", "WiFi compass orientation"),
    ]
    
    for topic, msg_type, desc in topics:
        table.add_row(topic, msg_type, desc)
    
    console.print(table)
    
    console.print("\n[dim]To echo a topic:[/dim]")
    console.print("  ros2 topic echo /nwo/wiros/csi")


@wiros.command(name="stream")
@click.argument("topic")
@click.option("--to-topic", "-t", default="/nwo/sensors/wifi_csi", 
              help="Destination topic (default: /nwo/sensors/wifi_csi)")
@click.option("--rate", "-r", type=int, help="Publish rate limit (Hz)")
@click.option("--filter", "-f", help="Filter expression (e.g., 'rssi > -50')")
def stream_wiros(topic, to_topic, rate, filter):
    """
    Stream WiROS data to NWO sensor topic.
    
    TOPIC: Source WiROS topic (e.g., /nwo/wiros/csi)
    
    Examples:
        nwo sensor wiros stream /nwo/wiros/csi --to-topic /nwo/sensors/wifi_csi
        nwo sensor wiros stream /nwo/wiros/rssi -r 10 --filter "rssi > -60"
    """
    console.print(Panel(
        f"[bold green]Streaming WiROS Data[/bold green]\n\n"
        f"[cyan]Source:[/cyan] {topic}\n"
        f"[cyan]Destination:[/cyan] {to_topic}\n"
        f"[cyan]Rate:[/cyan] {rate or 'unlimited'} Hz\n"
        f"[cyan]Filter:[/cyan] {filter or 'none'}",
        title="WiROS Stream",
        border_style="green"
    ))
    
    # This would typically launch a ROS2 node that subscribes to WiROS
    # and republishes to the NWO namespace
    console.print("[dim]Launching WiROS-NWO bridge node...[/dim]")


@wiros.command(name="calibrate")
@click.option("--method", type=click.Choice(["static", "dynamic", "auto"]), 
              default="auto", help="Calibration method")
@click.option("--duration", "-d", type=int, default=30, 
              help="Calibration duration in seconds")
@click.option("--save", "-s", default="~/.nwo/wiros_calib.yaml", 
              help="Calibration file path")
def calibrate_wiros(method, duration, save):
    """
    Calibrate WiROS sensors for accurate bearing extraction.
    
    Calibration compensates for hardware-specific phase offsets
    and antenna characteristics.
    
    Examples:
        nwo sensor wiros calibrate --method auto --duration 60
        nwo sensor wiros calibrate --method static -d 30
    """
    console.print(Panel(
        f"[bold yellow]WiROS Calibration[/bold yellow]\n\n"
        f"[cyan]Method:[/cyan] {method}\n"
        f"[cyan]Duration:[/cyan] {duration}s\n"
        f"[cyan]Save to:[/cyan] {save}",
        title="Calibration",
        border_style="yellow"
    ))
    
    with console.status(f"[bold yellow]Running {method} calibration..."):
        # Simulate calibration progress
        import time
        for i in range(duration):
            time.sleep(0.1)
            if i % 5 == 0:
                console.print(f"[dim]Calibrating... {i}/{duration}s[/dim]")
    
    console.print("[green]✓ Calibration complete[/green]")
    console.print(f"[dim]Saved to: {save}[/dim]")


@wiros.command(name="bearing")
@click.option("--algorithm", "-a", 
              type=click.Choice(["music", "beamformer", "sps", "spotfi"]),
              default="music", help="Bearing extraction algorithm")
@click.option("--output", "-o", default="/nwo/wiros/bearing",
              help="Output topic for bearing data")
def extract_bearing(algorithm, output):
    """
    Extract bearing (AoA/AoD) from WiFi CSI data.
    
    Algorithms:
        music: MUSIC algorithm (high accuracy, more compute)
        beamformer: Beamforming (fast, less accurate)
        sps: Sparse Bayesian Learning
        spotfi: SpotFi super-resolution
    
    Example:
        nwo sensor wiros bearing --algorithm music --output /nwo/sensors/bearing
    """
    console.print(Panel(
        f"[bold green]Bearing Extraction[/bold green]\n\n"
        f"[cyan]Algorithm:[/cyan] {algorithm.upper()}\n"
        f"[cyan]Output:[/cyan] {output}",
        title="WiROS Processing",
        border_style="green"
    ))
    
    algorithms = {
        "music": "MUSIC (Multiple Signal Classification)",
        "beamformer": "Beamformer (fast, real-time)",
        "sps": "Sparse Bayesian Learning",
        "spotfi": "SpotFi (super-resolution)"
    }
    
    console.print(f"\n[dim]Starting {algorithms[algorithm]}...[/dim]")
    console.print(f"[dim]Subscribe to: ros2 topic echo {output}[/dim]")


# =============================================================================
# RuView Commands (already exists, adding to sensor group)
# =============================================================================

@sensor.group(name="ruview")
def ruview():
    """
    RuView WiFi human sensing integration.
    
    Detects human pose, presence, breathing rate, and heart rate
    using WiFi signal perturbations.
    
    Requires: ESP32-S3 mesh or Docker simulation
    """
    pass


@ruview.command(name="enable")
@click.option("--mode", type=click.Choice(["docker", "hardware"]), default="docker",
              help="Run mode: docker (simulated) or hardware (ESP32)")
@click.option("--server", default="ws://localhost:5006", help="RuView server URL")
@click.option("--namespace", "-n", default="/nwo/ruview", help="ROS2 topic namespace")
def enable_ruview(mode, server, namespace):
    """Enable RuView WiFi human sensing."""
    console.print(Panel(
        f"[bold green]Enabling RuView[/bold green]\n\n"
        f"[cyan]Mode:[/cyan] {mode}\n"
        f"[cyan]Server:[/cyan] {server}\n"
        f"[cyan]Namespace:[/cyan] {namespace}",
        title="RuView Configuration",
        border_style="green"
    ))
    
    if mode == "docker":
        console.print("[dim]Starting RuView Docker container...[/dim]")
        cmd = [
            "docker", "run", "-d", "--name", "nwo-ruview",
            "-p", "3000:3000", "-p", "5006:5006",
            "ruvnet/wifi-densepose:latest"
        ]
        try:
            subprocess.run(cmd, capture_output=True, timeout=30)
            console.print("[green]✓ RuView Docker started[/green]")
        except Exception as e:
            console.print(f"[red]✗ Failed: {e}[/red]")
    else:
        console.print("[yellow]Hardware mode: Ensure ESP32 mesh is deployed[/yellow]")


@ruview.command(name="topics")
def list_ruview_topics():
    """List RuView ROS2 topics."""
    table = Table(title="RuView ROS2 Topics")
    table.add_column("Topic", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Description", style="white")
    
    topics = [
        ("/nwo/ruview/pose", "geometry_msgs/PoseArray", "Human skeleton (17 keypoints)"),
        ("/nwo/ruview/presence", "std_msgs/Bool", "Human presence detection"),
        ("/nwo/ruview/breathing_rate", "std_msgs/Float32", "Breaths per minute"),
        ("/nwo/ruview/heart_rate", "std_msgs/Float32", "Heart rate BPM"),
        ("/nwo/ruview/activity", "std_msgs/String", "Activity classification"),
    ]
    
    for topic, msg_type, desc in topics:
        table.add_row(topic, msg_type, desc)
    
    console.print(table)


# =============================================================================
# General Sensor Commands
# =============================================================================

@sensor.command(name="status")
def sensor_status():
    """Show status of all sensor modules."""
    table = Table(title="Sensor Module Status")
    table.add_column("Module", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Topics", style="white")
    
    # Check WiROS
    wiros_running = False
    try:
        result = subprocess.run(["pgrep", "-f", "wiros"], capture_output=True)
        wiros_running = result.returncode == 0
    except:
        pass
    
    # Check RuView
    ruview_running = False
    try:
        result = subprocess.run(["docker", "ps", "-q", "-f", "name=nwo-ruview"], 
                               capture_output=True, text=True)
        ruview_running = len(result.stdout.strip()) > 0
    except:
        pass
    
    table.add_row(
        "WiROS (CSI)",
        "[green]● Running[/green]" if wiros_running else "[red]● Stopped[/red]",
        "/nwo/wiros/csi, /nwo/wiros/rssi"
    )
    table.add_row(
        "RuView (Human)",
        "[green]● Running[/green]" if ruview_running else "[red]● Stopped[/red]",
        "/nwo/ruview/pose, /nwo/ruview/presence"
    )
    
    console.print(table)


@sensor.command(name="list")
def list_sensors():
    """List all available sensor types."""
    console.print(Panel(
        "[bold]Available WiFi Sensors:[/bold]\n\n"
        "[cyan]WiROS[/cyan] - WiFi CSI/RSSI sensing\n"
        "  • Channel State Information (fine-grained)\n"
        "  • RSSI (coarse signal strength)\n"
        "  • AoA/AoD bearing extraction\n"
        "  • Requires: WiFi NIC with monitor mode\n\n"
        "[cyan]RuView[/cyan] - WiFi human sensing\n"
        "  • Human pose detection (17 keypoints)\n"
        "  • Presence detection\n"
        "  • Breathing/heart rate estimation\n"
        "  • Requires: ESP32-S3 mesh or Docker",
        title="WiFi Sensors",
        border_style="cyan"
    ))


@sensor.command(name="fusion")
@click.option("--sensors", "-s", multiple=True, 
              type=click.Choice(["wiros", "ruview", "lidar", "camera"]),
              default=["wiros", "ruview"], help="Sensors to fuse")
@click.option("--output", "-o", default="/nwo/sensors/fused",
              help="Output topic for fused data")
def sensor_fusion(sensors, output):
    """
    Enable multi-sensor fusion.
    
    Combines WiFi sensing with other sensors for robust perception.
    
    Example:
        nwo sensor fusion --sensors wiros --sensors ruview --output /nwo/fused
    """
    console.print(Panel(
        f"[bold green]Multi-Sensor Fusion[/bold green]\n\n"
        f"[cyan]Sensors:[/cyan] {', '.join(sensors)}\n"
        f"[cyan]Output:[/cyan] {output}",
        title="Sensor Fusion",
        border_style="green"
    ))
    
    console.print("\n[dim]Starting sensor fusion node...[/dim]")
    console.print("[dim]This combines WiFi CSI with other modalities for robust SLAM.[/dim]")
