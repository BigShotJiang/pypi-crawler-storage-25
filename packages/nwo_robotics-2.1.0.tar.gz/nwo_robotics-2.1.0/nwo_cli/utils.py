"""
Utility functions for NWO CLI
"""

import json
from rich.console import Console
from rich.syntax import Syntax

console = Console()


def format_json(data: dict) -> str:
    """Format JSON with syntax highlighting"""
    json_str = json.dumps(data, indent=2)
    return json_str


def handle_error(error):
    """Display error message"""
    from ..client import NWOAPIError
    
    if isinstance(error, NWOAPIError):
        console.print(f"[bold red]Error:[/bold red] {error}")
        
        if error.status_code == 401:
            console.print("\n[dim]Authentication failed. Run:[/dim]")
            console.print("  nwo auth login")
        elif error.status_code == 403:
            console.print("\n[dim]Access denied. Check your API key permissions.[/dim]")
        elif error.status_code == 429:
            console.print("\n[dim]Rate limit exceeded. Please wait before retrying.[/dim]")
        elif error.status_code is None:
            console.print("\n[dim]Check your internet connection and API status.[/dim]")
    else:
        console.print(f"[bold red]Unexpected error:[/bold red] {error}")
