"""
NWO Robotics CLI - Main Entry Point
"""

import click
from .commands import (
    robot, swarm, models, iot, tasks, learning, 
    safety, config, auth, monitor, templates, sensor
)


@click.group()
@click.version_option(version="2.1.0", prog_name="nwo")
@click.pass_context
def cli(ctx):
    """
    NWO Robotics CLI v2.0
    
    Command-line interface for the NWO Robotics API.
    Control robots, manage swarms, and orchestrate intelligent automation.
    
    Quick Start:
        nwo auth login                    # Authenticate with your API key
        nwo robot "pick up the box"       # Send a command to a robot
        nwo models list                   # View available AI models
        nwo swarm create "My Team"        # Create a robot swarm
        nwo sensor enable wiros           # Enable WiFi CSI sensing
    
    Documentation: https://nwo.capital/docs
    API Dashboard: https://nwo.capital/webapp/api-key.php
    """
    ctx.ensure_object(dict)


# Add command groups
cli.add_command(robot.robot)
cli.add_command(swarm.swarm)
cli.add_command(models.models)
cli.add_command(iot.iot)
cli.add_command(tasks.tasks)
cli.add_command(learning.learning)
cli.add_command(safety.safety)
cli.add_command(config.config)
cli.add_command(auth.auth)
cli.add_command(monitor.monitor)
cli.add_command(templates.templates)
cli.add_command(sensor.sensor)


if __name__ == "__main__":
    cli()
