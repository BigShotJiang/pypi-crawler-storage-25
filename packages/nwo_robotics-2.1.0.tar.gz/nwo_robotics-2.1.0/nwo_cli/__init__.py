"""NWO Robotics CLI v2.1"""

__version__ = "2.1.0"
__author__ = "NWO Robotics"
