USB_DEVICES = {
    (0x0EB8, 0x2200): {
        "name": "Mettler Toledo - Ariva S",
        "image": "mettler_toledo__ariva_s.png",
    },
}
