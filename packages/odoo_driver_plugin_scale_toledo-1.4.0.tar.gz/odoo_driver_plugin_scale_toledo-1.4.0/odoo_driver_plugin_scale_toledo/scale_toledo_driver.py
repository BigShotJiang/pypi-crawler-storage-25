import re

from flask_babel import gettext as _
from loguru import logger
from odoo_driver.drivers.driver_abstract import DriverAbstract
from odoo_driver.tools.tools_enum import UomWeight, WeightType
from odoo_driver.tools.tools_serial_code import CR, NUL, STX

request_weight = ["W"]

regex__gross_weight_pound = re.compile(rf"{STX}(?P<weight>\d\d\.\d\d){CR}")
regex__gross_weight_kg = re.compile(rf"{STX}(?P<weight>\d\d\.\d\d\d){CR}")
regex__net_weight_pound = re.compile(rf"{STX}(?P<weight>\d\d\.\d\d)N{CR}")
regex__net_weight_kg = re.compile(rf"{STX}(?P<weight>\d\d\.\d\d\d)N{CR}")

regex__status = re.compile(rf"{STX}?(?P<status>.){CR}")


class DriverScaleToledo(DriverAbstract):
    _use_serial = True
    _driver_function = "scale"
    _plugin_name = "scale_toledo"

    @property
    def name(self):
        return _("Scale")

    def __init__(self):
        """Initialize a new Driver with a Queue"""
        DriverAbstract.__init__(self)
        self._last_weight = False
        self._last_unit = False
        self._last_weight_type = False

    def get_weight_info(self):
        with self._get_serial() as serial_connection:
            if not serial_connection:
                return "no_scale", False
            self._serial_send_message(
                serial_connection, request_weight, "Request Weight"
            )
            raw_result = self._serial_read_message(serial_connection)
            status, weight, unit, weight_type, extra_info = self._parse_scale_message(
                raw_result
            )
            if status == "same_weight":
                weight = self._last_weight
                unit = self._last_unit
                weight_type = self._last_weight_type
            else:
                self._last_weight = weight
                self._last_unit = unit
                self._last_weight_type = weight_type
        return status, weight, unit, weight_type, extra_info

    def _parse_scale_message(self, raw_result):
        message = raw_result.decode("utf-8")
        if regex__gross_weight_pound.search(message):
            result = (
                "ok",
                float(regex__gross_weight_pound.search(message).group("weight")),
                UomWeight.UOM_POUND,
                WeightType.GROSS,
                [],
            )
        elif regex__gross_weight_kg.search(message):
            result = (
                "ok",
                float(regex__gross_weight_kg.search(message).group("weight")),
                UomWeight.UOM_KILOGRAM,
                WeightType.GROSS,
                [],
            )
        elif regex__net_weight_pound.search(message):
            result = (
                "ok",
                float(regex__net_weight_pound.search(message).group("weight")),
                UomWeight.UOM_POUND,
                WeightType.NET,
                [],
            )
        elif regex__net_weight_kg.search(message):
            result = (
                "ok",
                float(regex__net_weight_kg.search(message).group("weight")),
                UomWeight.UOM_KILOGRAM,
                WeightType.NET,
                [],
            )
        elif regex__status.search(message):
            status = regex__status.search(message).group("status")
            if status == NUL:
                result = "same_weight", False, False, False, []
            else:
                status_byte = int.from_bytes(status.encode("utf-8"), byteorder="big")
                extra_info = []
                if status_byte & 1:
                    extra_info.append("moving")
                if status_byte & 1 << 1:
                    extra_info.append("over_capacity")
                if status_byte & 1 << 2:
                    extra_info.append("under_zero")
                if status_byte & 1 << 3:
                    extra_info.append("outside_zero_capture_range")
                if status_byte & 1 << 4:
                    extra_info.append("center_of_zero")
                if status_byte & 1 << 5:
                    extra_info.append("net_weight")
                if status_byte & 1 << 6:
                    extra_info.append("bad_command_from_host")
                result = "no_value", False, False, False, extra_info
        else:
            logger.error(f"{self.name}: Unable to parse the message {raw_result}")
            result = "not_implemented", False, False, False, []
        logger.debug(f"{self.name}: Parsing result {result}")
        return result
