from flask import Blueprint, jsonify
from loguru import logger
from odoo_driver.tools.tools_enum import UomWeight, WeightType
from odoo_driver.tools.tools_interface import interface

driver_routes_odoo = Blueprint(
    "route_scale_toledo_odoo", __name__, template_folder="templates"
)


@driver_routes_odoo.route("/hw_proxy/scale_read", methods=["POST"])
@logger.catch
def scale_read():
    driver = interface.drivers.get("scale")

    status, weight, unit, weight_type, extra_info = driver.get_weight_info()

    if unit == UomWeight.UOM_KILOGRAM:
        unit_text = "Kg"
    elif unit == UomWeight.UOM_POUND:
        unit_text = "Lbs"
    else:
        unit_text = False

    if weight_type == WeightType.NET:
        weight_type_text = "Net"
    elif weight_type == WeightType.GROSS:
        weight_type_text = "Gross"
    else:
        weight_type_text = False

    result = {
        "weight": weight,
        "unit": unit_text,
        "weight_type": weight_type_text,
        "info": status,
        "extra_info": extra_info,
    }

    return jsonify(jsonrpc="2.0", result=result)
