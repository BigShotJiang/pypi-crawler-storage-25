from pathlib import Path

from single_source import get_version

from . import usb_devices
from .routes_odoo import driver_routes_odoo
from .routes_website import driver_routes_website
from .scale_toledo_driver import DriverScaleToledo

__version__ = get_version(__name__, Path(__file__).parent.parent)
__package_name__ = __name__

DRIVER_FUNCTION = "scale"
PLUGIN_NAME = "scale_toledo"
DRIVER_CLASS = DriverScaleToledo
USB_DEVICES = usb_devices.USB_DEVICES
DRIVER_ROUTES_GROUPS = [driver_routes_odoo, driver_routes_website]
