from flask import Blueprint, render_template
from loguru import logger
from odoo_driver.tools.tools_interface import interface

driver_routes_website = Blueprint(
    "route_scale_toledo_website", __name__, template_folder="templates"
)


@driver_routes_website.route("/driver/scale_toledo.html")
@logger.catch
def driver_scale_toledo():
    driver = interface.drivers.get("scale")
    return render_template("scale_toledo_driver.html.jinja", driver=driver)
