# Odoo Driver Plugin - Payment Terminal - Ingenico

![License: AGPL v3](https://img.shields.io/badge/License-AGPL_v3-blue.svg)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/odoo-driver-plugin-payment-terminal)
![PyPI - Downloads](https://img.shields.io/pypi/dm/odoo-driver-plugin-payment-terminal)
![GitLab last commit](https://img.shields.io/gitlab/last-commit/81577360)
![GitLab stars](https://img.shields.io/gitlab/stars/81577360?style=social)


This project provide a plugin for ``odoo-driver``
to communicate with scales with Toledo protocol.

This plugin requires the following odoo module : `point_of_sale` (Odoo CE / EE).

To install this plugin, refer to the main project page : https://gitlab.com/grap-rhone-alpes/odoo-driver/.

For developpers, refer to this page : https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-scale-toledo/-/blob/main/DEVELOP.md.

## Table of contents

1. [Compatible Devices](#compatible-devices)
2. [Credits](#credits)
3. [Develop](#develop)

<a name="compatible-devices"></a>

## Compatible Devices

<table style="width: 100%;">
    <tbody>
        <tr>
            <td>Metler Toledo - Ariva S</td>
            <td>
              <img src="https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-scale-toledo/-/raw/main/odoo_driver_plugin_scale_toledo/static/img/mettler_toledo__ariva_s.png" width="200" height="200" />
            </td>
        </tr>
    </tbody>
</table>

<a name="credits"></a>

## Credits

### Authors

* GRAP <https://www.grap.coop>

### Contributors

* Sylvain LE GAL <https://www.grap.coop/>

### Extra authorship

Part of the code in this project comes from the following projects, including:

* [Pywebdriver](https://github.com/pywebdriver/pywebdriver) (AGPL-3.0).

### Images

* [Scale Icon](https://www.flaticon.com/fr/icone-gratuite/pesee_1104592), created by itim2101 (Flaticon).

<a name="develop"></a>

## Develop

### Local Installation

To install the odoo-driver library and some plugins, you can refer to this documentation:

https://gitlab.com/grap-rhone-alpes/odoo-driver-env

### Documentation

**8217 Mettler Toledo Protocol**

* https://s1p.manualzz.com/store/data/001420312.pdf?key=b0b0ead0a34c3e27763e4a92084d6260&r=1&fn=1420312.pdf&t=1778166125993&p=86400

  (or [permalink of pages 25 to 31](https://gitlab.com/grap-rhone-alpes/odoo-driver-plugin-scale-toledo/-/raw/main/doc/extract_Mettler-Toledo_XRV-Checkout-Scale_operation-and-service-manual.pdf))
