"""Sprint 1F.4 phase 2.5 — JS bundle injected on every new Chrome
document for Layer 2 of the Studio security stack.

This module exports `build_page_guard_script(permissions)` which
returns a JavaScript string. The agent calls
`Page.addScriptToEvaluateOnNewDocument` (CDP) with the returned
string; Chrome runs it BEFORE any other page script in every new
document (top-level + iframes).

Communication back to the agent process: the agent installs a CDP
binding named `haonAuditEmit` via `Runtime.addBinding`. The injected
JS calls `window.haonAuditEmit(JSON.stringify({...}))` which fires
a `Runtime.bindingCalled` event the agent listens to.

LIMITATIONS — be honest about what JS can't do:
  - F12, Ctrl+T, Ctrl+W, Ctrl+N: browser-level shortcuts. JS keydown
    listeners receive them but `preventDefault()` does NOT cancel
    the browser action. Defense is Layer 0 (Chrome --app mode)
    which eliminates the tabs/menu surface.
  - Right-click → Inspect Element: CAN be blocked via contextmenu
    preventDefault (browser context menu actually respects JS).
  - DevTools opened via menu: --app mode removes the menu, killing
    this vector.
  - Ctrl+Shift+I (DevTools shortcut): browser-level. JS only catches
    it best-effort; --app mode is the real defense.

The JS is built dynamically with the permissions baked in (string
substitution at build time) so toggle flags don't require a CDP
round-trip mid-session to enforce.
"""

from __future__ import annotations

import json
from typing import Any


# CSS injected into the head of every document. Selectors target
# common account-management UI elements across major LLM providers
# + generic patterns. NOT comprehensive — best-effort + UX polish.
# Real defense is Layer 1 (URL block at network level).
_GUARD_CSS = """
/* Generic account/profile/sign-out UI hiding. Catches the common
   cases across Gemini, ChatGPT, Claude, and generic webapps. */
[aria-label*="Sign out" i],
[aria-label*="Log out" i],
[aria-label*="Logout" i],
[aria-label*="Sair" i],
[aria-label*="Account" i][role="button"],
[aria-label*="Conta" i][role="button"],
[data-action="logout"],
[data-action="signout"],
[data-action="sign-out"],
a[href*="signout"],
a[href*="logout"],
a[href*="sign_out"],
a[href*="myaccount.google.com"],
a[href*="accounts.google.com/SignOutOptions"],
button[aria-label*="profile" i][aria-label*="menu" i],
/* Gemini-specific */
[data-test-id="account-switcher-button"],
/* ChatGPT-specific */
button[data-testid="profile-button"],
[data-testid="logout-button"],
/* Claude-specific */
button[aria-label*="User menu" i],
[data-testid="settings-button"][data-testid*="account"] {
    display: none !important;
    visibility: hidden !important;
    pointer-events: none !important;
}

/* Toast container — single fixed element at top-right that the
   injected JS shows on blocked actions. */
#haon-studio-toast {
    position: fixed;
    top: 16px;
    right: 16px;
    background: rgba(220, 38, 38, 0.95);
    color: white;
    padding: 12px 16px;
    border-radius: 6px;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 14px;
    z-index: 2147483647;
    max-width: 360px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    opacity: 0;
    transition: opacity 200ms ease-in-out;
    pointer-events: none;
}
#haon-studio-toast.visible {
    opacity: 1;
}
"""


def build_page_guard_script(permissions: dict[str, Any]) -> str:
    """Build the JS bundle to inject on every new document.

    `permissions` is a dict with keys matching the Permissions
    dataclass fields (the AGENT's sanitised view — HARDCODED-FALSE
    already enforced before this is called).

    We bake the permission flags into the JS as JSON constants at
    build time so the runtime check is a single `if (PERMS.foo)`
    instead of a postMessage round-trip per event.
    """
    # Sanitise — only allow expected scalar fields through to the JS
    # context, no arbitrary callable or object refs.
    safe_perms = {
        "can_download": bool(permissions.get("can_download", False)),
        "can_open_new_tab": bool(permissions.get("can_open_new_tab", False)),
        "can_screen_record": bool(permissions.get("can_screen_record", False)),
        # The 5 other HARDCODED-FALSE invariants — exposed for JS
        # checks even though they're never True (parse_permissions
        # strips them). Useful for the audit emit shape.
        "can_modify_account": False,
        "can_view_browser_history": False,
        "can_access_chrome_internals": False,
        "can_use_devtools": False,
        "can_end_session": False,
    }
    perms_json = json.dumps(safe_perms, separators=(",", ":"))
    css_str = json.dumps(_GUARD_CSS)

    # The JS template. Triple-quoted Python string; %s placeholders
    # substituted ONCE at build time, not at runtime. Comments inline
    # to explain each guard.
    return _PAGE_GUARD_JS_TEMPLATE % (perms_json, css_str)


# Triple-quoted JS template. %s substitution: (perms_json, css_str).
# Linted via mental check — single-quote strings inside, no JSX/TS.
_PAGE_GUARD_JS_TEMPLATE = r"""
(function () {
    // Run only once per document. addScriptToEvaluateOnNewDocument
    // is supposed to be per-document but defensive against frames.
    if (window.__haonStudioGuardInstalled) return;
    window.__haonStudioGuardInstalled = true;

    var PERMS = %s;

    function audit(eventType, eventData) {
        // CDP binding installed by the agent via Runtime.addBinding
        // before this script runs. If it's somehow missing (e.g.
        // injected too early), log + drop — better than a crash.
        try {
            if (typeof window.haonAuditEmit === 'function') {
                window.haonAuditEmit(JSON.stringify({
                    event_type: eventType,
                    event_data: eventData || {},
                }));
            }
        } catch (e) { /* swallow */ }
    }

    function showToast(message) {
        try {
            var t = document.getElementById('haon-studio-toast');
            if (!t) {
                t = document.createElement('div');
                t.id = 'haon-studio-toast';
                (document.body || document.documentElement).appendChild(t);
            }
            t.textContent = message;
            t.classList.add('visible');
            setTimeout(function () {
                t.classList.remove('visible');
            }, 2500);
        } catch (e) { /* swallow */ }
    }

    // ── Inject CSS ────────────────────────────────────────────
    try {
        var style = document.createElement('style');
        style.setAttribute('data-haon-guard', '1');
        style.textContent = %s;
        (document.head || document.documentElement).appendChild(style);
    } catch (e) { /* swallow */ }

    // ── window.close override ─────────────────────────────────
    // Override BEFORE the page can capture a reference to it. The
    // override is non-configurable so the page can't `delete` it.
    try {
        Object.defineProperty(window, 'close', {
            value: function () {
                audit('blocked_action', {kind: 'window_close'});
                showToast('Esta ação não é permitida durante a sessão compartilhada.');
                return undefined;
            },
            writable: false,
            configurable: false,
        });
    } catch (e) { /* swallow */ }

    // ── window.open override ──────────────────────────────────
    // Block new tabs unless permission says otherwise. Same
    // non-configurable trick.
    try {
        var originalOpen = window.open;
        Object.defineProperty(window, 'open', {
            value: function () {
                if (PERMS.can_open_new_tab) {
                    return originalOpen.apply(window, arguments);
                }
                audit('blocked_action', {
                    kind: 'window_open',
                    target: String(arguments[0] || ''),
                });
                showToast('Abrir nova aba não é permitido durante a sessão.');
                return null;
            },
            writable: false,
            configurable: false,
        });
    } catch (e) { /* swallow */ }

    // ── navigator.mediaDevices.getDisplayMedia override ───────
    // can_screen_record: FALSE (HARDCODED) — coworker shouldn't
    // be able to use MediaRecorder via getDisplayMedia to capture
    // the owner's screen and exfiltrate.
    try {
        if (navigator.mediaDevices) {
            var origGDM = navigator.mediaDevices.getDisplayMedia;
            navigator.mediaDevices.getDisplayMedia = function () {
                if (PERMS.can_screen_record) {
                    return origGDM.apply(navigator.mediaDevices, arguments);
                }
                audit('blocked_action', {kind: 'getDisplayMedia'});
                showToast('Captura de tela não é permitida.');
                return Promise.reject(new DOMException(
                    'getDisplayMedia denied by HAON Studio guard',
                    'NotAllowedError'
                ));
            };
        }
    } catch (e) { /* swallow */ }

    // MediaRecorder lock-down: even if getDisplayMedia was somehow
    // bypassed, MediaRecorder construction is also guarded.
    try {
        if (typeof MediaRecorder !== 'undefined' && !PERMS.can_screen_record) {
            var OrigMR = window.MediaRecorder;
            window.MediaRecorder = function () {
                audit('blocked_action', {kind: 'MediaRecorder'});
                showToast('Gravação não é permitida.');
                throw new DOMException(
                    'MediaRecorder denied by HAON Studio guard',
                    'NotSupportedError'
                );
            };
            window.MediaRecorder.isTypeSupported =
                OrigMR.isTypeSupported.bind(OrigMR);
        }
    } catch (e) { /* swallow */ }

    // ── contextmenu (right-click) ─────────────────────────────
    // JS CAN suppress this — Chrome respects preventDefault on
    // contextmenu events. Right-click → Inspect Element is killed.
    document.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        audit('blocked_action', {kind: 'contextmenu'});
    }, true);

    // ── keyboard shortcuts (best-effort) ──────────────────────
    // Browser-level shortcuts (F12, Ctrl+T, Ctrl+W, Ctrl+S) are
    // NOT actually suppressed by JS preventDefault — the browser
    // intercepts them first. We still call preventDefault for
    // belt+suspenders + audit-emit on attempts.
    // Real defense for these is Layer 0 (Chrome --app mode) which
    // removes tabs/menu so most of these are moot anyway.
    document.addEventListener('keydown', function (e) {
        var key = e.key || '';
        var ctrl = e.ctrlKey || e.metaKey;
        var shift = e.shiftKey;
        var blocked = false;
        var kind = null;

        if (key === 'F12') { blocked = true; kind = 'F12'; }
        else if (ctrl && shift && (key === 'I' || key === 'i' || key === 'J' || key === 'j')) {
            blocked = true; kind = 'devtools_shortcut';
        }
        else if (ctrl && (key === 'u' || key === 'U')) {
            blocked = true; kind = 'view_source';
        }
        else if (ctrl && (key === 's' || key === 'S') && !PERMS.can_download) {
            blocked = true; kind = 'save_page';
        }
        else if (ctrl && (key === 'p' || key === 'P') && !PERMS.can_download) {
            blocked = true; kind = 'print';
        }
        else if (ctrl && (key === 't' || key === 'T') && !PERMS.can_open_new_tab) {
            blocked = true; kind = 'new_tab';
        }
        else if (ctrl && (key === 'n' || key === 'N') && !PERMS.can_open_new_tab) {
            blocked = true; kind = 'new_window';
        }

        if (blocked) {
            e.preventDefault();
            e.stopPropagation();
            audit('blocked_action', {kind: 'keyboard_' + kind});
            // No toast on every keystroke — too noisy. Toast only
            // on right-click / window-level events.
        }
    }, true);

    // ── <a download> click block ──────────────────────────────
    // If can_download is False, intercept download-link clicks.
    // Note: Chrome menu "Save As" can't be JS-blocked, but --app
    // mode hides the menu.
    document.addEventListener('click', function (e) {
        if (PERMS.can_download) return;
        var target = e.target;
        while (target && target !== document.body) {
            if (target.tagName === 'A' && target.hasAttribute('download')) {
                e.preventDefault();
                e.stopPropagation();
                audit('blocked_action', {
                    kind: 'a_download',
                    href: target.href || '',
                });
                showToast('Download não é permitido durante a sessão.');
                return;
            }
            target = target.parentElement;
        }
    }, true);

    // ── beforeunload ─────────────────────────────────────────
    // Don't let in-page JS try to nuke the session via
    // window.location.replace or similar; allow normal navigation
    // (Layer 1 URL block catches dangerous ones). Just audit.
    window.addEventListener('beforeunload', function () {
        audit('navigation_unload', {url: window.location.href});
    });
})();
"""
