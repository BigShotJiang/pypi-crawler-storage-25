"""Sprint 1F.4 phase 4 — BrowserSession orchestrator.

One BrowserSession per Studio session_offer received on the agent's
main /v1/byoc/connect WSS. Costuras tudo:

  1. parse permissions (HARDCODED-FALSE stripped)
  2. launch Chrome --app=<resource_url>
  3. connect CDP
  4. apply url_guard (Layer 1)
  5. apply page_guard (Layer 2 JS/CSS inject)
  6. start SessionMonitor (Layer 3 idle+counter)
  7. start BrowserWebRTCPeer
  8. open signaling WSS to broker
  9. drive SDP/ICE handshake offer→answer
  10. relay ICE candidates both directions
  11. on monitor disconnect / signaling close / WSS drop → tear down
      everything cleanly

Lifecycle:
    session = BrowserSession(offer, main_ws_send, resource_resolver)
    await session.start()       # raises on bring-up failure
    await session.wait()        # blocks until the session ends
    # (or explicit close)
    await session.close()       # idempotent
"""

from __future__ import annotations

import asyncio
from dataclasses import asdict
from typing import Any, Awaitable, Callable

import structlog

from haon_agent.byoc.runtime.browser import (
    launcher,
    page_guard,
    permissions as _permissions,
    url_guard,
    webrtc_peer,
)
from haon_agent.byoc.runtime.browser.cdp import CDPClient
from haon_agent.byoc.runtime.browser.audit import AuditEmitter
from haon_agent.byoc.runtime.browser.monitor import (
    DisconnectReason,
    SessionMonitor,
)
from haon_agent.byoc.runtime.browser.signal_client import SignalClient


log = structlog.get_logger("agent.browser.session")


# Sender of frames over the agent's main /v1/byoc/connect WSS. Used
# for audit emission relay (broker forwards audit_event frames to
# haonhub /audit/broker).
MainWSSFrameSender = Callable[[dict[str, Any]], Awaitable[None]]

# Maps resource_id (from session_offer) → URL Chrome opens in --app
# mode. Caller (transport.py) supplies the resolver so the agent
# could swap implementations (static dict, lookup-from-disk, etc).
ResourceResolver = Callable[[str], str]


# Default mapping of resource_id → launchable URL. Phase 4 ships a
# fixed table for known providers; phase 5 can replace with a
# user-config file.
DEFAULT_RESOURCE_URL_MAP: dict[str, str] = {
    "gemini-ultra": "https://gemini.google.com/",
    "gemini": "https://gemini.google.com/",
    "chatgpt-pro": "https://chat.openai.com/",
    "chatgpt": "https://chat.openai.com/",
    "claude-pro": "https://claude.ai/",
    "claude": "https://claude.ai/",
    "veo": "https://gemini.google.com/",     # Veo lives inside Gemini today
    "kling": "https://klingai.com/",
}


def resolve_resource_url(resource_id: str) -> str:
    """Default resolver. Returns the mapped URL or — fallback — treats
    resource_id as a URL itself if it looks like one. Otherwise raises
    so the caller knows to abort the session.
    """
    if resource_id in DEFAULT_RESOURCE_URL_MAP:
        return DEFAULT_RESOURCE_URL_MAP[resource_id]
    if resource_id.startswith(("https://", "http://")):
        return resource_id
    raise ValueError(
        f"Unknown resource_id {resource_id!r} — no URL mapping. "
        "Add to DEFAULT_RESOURCE_URL_MAP or pass a full URL."
    )


class BrowserSession:
    """One Studio session lifecycle. Concurrency-safe within itself
    via the asyncio single-thread guarantee + the various subcomponent
    locks (CDP send, signal send, etc)."""

    def __init__(
        self,
        offer: dict[str, Any],
        *,
        main_ws_send: MainWSSFrameSender,
        resource_resolver: ResourceResolver | None = None,
    ) -> None:
        self._offer = offer
        self._main_ws_send = main_ws_send
        self._resolve = resource_resolver or resolve_resource_url
        self.session_id: str = offer.get("session_id") or "unknown"
        self._audit = AuditEmitter(
            session_id=self.session_id,
            send_frame=main_ws_send,
        )
        # Subcomponents — populated by start()
        self._chrome: Any = None       # launcher.LaunchedChrome
        self._cdp: Any = None          # CDP client (browser-level WS)
        self._cdp_session_id: str | None = None  # Page-level CDP session
        self._monitor: SessionMonitor | None = None
        self._peer: webrtc_peer.BrowserWebRTCPeer | None = None
        self._signal: SignalClient | None = None
        self._page_guard_listener: asyncio.Task | None = None
        # Lifecycle
        self._done = asyncio.Event()
        self._closed = False
        self._close_lock = asyncio.Lock()

    # ── Public API ──────────────────────────────────────────────────

    async def start(self) -> None:
        """Bring up the full session. Raises on any setup failure;
        caller (transport handler) should then call close() to clean
        up any partial state.
        """
        # Phase 1: parse permissions + bump audit for any HARDCODED
        # bypass attempts haonhub may have sent
        raw_perms = self._offer.get("permissions") or {}
        perms = _permissions.parse_permissions(
            raw_perms,
            on_locked_attempted=self._on_locked_perm_attempt,
        )
        perms_dict = asdict(perms)

        # Phase 2: launch Chrome
        start_url = self._resolve(self._offer.get("resource_id", ""))
        self._chrome = await launcher.launch_chrome(
            profile_name=self._offer["resource_id"],
            start_url=start_url,
            app_mode=True,
        )
        log.info(
            "browser_session_chrome_launched",
            session_id=self.session_id,
            start_url=start_url,
        )

        # Phase 3: connect CDP. LaunchedChrome already has the WS URL
        # discovered from Chrome's /json/version endpoint after the
        # remote-debugging port came up. That's the BROWSER-level
        # CDP endpoint — only Browser.*, Target.*, Storage.* work
        # there.
        self._cdp = await CDPClient.connect(self._chrome.devtools_ws_url)
        log.info("browser_session_cdp_connected", session_id=self.session_id)

        # Phase 3.5 (added 2026-05-22): attach a page-level CDP session.
        # Network.*, Page.*, Input.*, DOM.*, Runtime.* require a session
        # context — without this, every phase below crashed in 0.5.1.1
        # with `-32601: Network.enable wasn't found`.
        #
        # In --app mode Chrome opens exactly one page target on launch.
        # We pick the first "page" type target and attach with flatten
        # mode so the CDP read-loop demuxes session events by sessionId.
        targets_result = await self._cdp.send("Target.getTargets")
        page_target_id: str | None = None
        for t in targets_result.get("targetInfos", []) or []:
            if t.get("type") == "page":
                page_target_id = t.get("targetId")
                break
        if not page_target_id:
            raise RuntimeError(
                "BrowserSession.start: no 'page' target found on Chrome "
                "/json/list. Chrome may not have opened the app window."
            )
        self._cdp_session_id = await self._cdp.attach_session(page_target_id)
        log.info(
            "browser_session_cdp_session_attached",
            session_id=self.session_id,
            cdp_session_id=self._cdp_session_id,
            target_id=page_target_id,
        )

        # Phase 4: apply url_guard (Layer 1)
        blocklist = url_guard.build_blocklist(
            extra_blocklist=perms.url_blocklist,
            allowlist=perms.url_allowlist,
        )
        await url_guard.apply_url_blocklist(
            self._cdp,
            blocklist=blocklist,
            session_id=self._cdp_session_id,
        )

        # Phase 5: apply page_guard (Layer 2 JS/CSS inject)
        self._page_guard_listener = await page_guard.apply_page_guards(
            self._cdp,
            permissions=perms_dict,
            on_audit_event=self._audit.emit,
            session_id=self._cdp_session_id,
        )

        # Phase 6: start session monitor (Layer 3 idle + counter)
        self._monitor = SessionMonitor(
            session_id=self.session_id,
            idle_timeout_seconds=perms.idle_timeout_min * 60,
            max_blocked_warnings=perms.max_warnings_before_disconnect,
            audit_emit=self._audit.emit,
            on_disconnect=self._on_monitor_disconnect,
        )
        await self._monitor.start()

        # Phase 7: start WebRTC peer
        turn_servers = self._offer.get("turn_creds") or {}
        ice_servers: list[dict[str, Any]] = []
        urls = turn_servers.get("urls") or []
        if urls:
            ice_servers.append({
                "urls": urls,
                "username": turn_servers.get("username"),
                "credential": turn_servers.get("credential"),
            })
        self._peer = webrtc_peer.BrowserWebRTCPeer(
            cdp=self._cdp,
            cdp_session_id=self._cdp_session_id,
            permissions=perms_dict,
            ice_servers=ice_servers,
            audit_emit=self._audit.emit,
            on_state_change=self._on_peer_state_change,
        )
        await self._peer.start()

        # Hook ICE candidate generation → relay via signal WSS.
        # aiortc fires an `icecandidate` event-equivalent through the
        # RTCPC's onicecandidate setter (rare in aiortc; ICE info is
        # typically embedded in the SDP). For aiortc the default flow
        # is "ICE in SDP" — we don't usually trickle. Leaving the
        # trickle path explicit anyway in case future aiortc bumps
        # support it OR the coworker side trickles to us.

        # Phase 8: open signaling WSS
        signaling_url = self._offer["signaling_url"]
        session_token = self._offer["session_token"]
        self._signal = SignalClient(
            url=signaling_url,
            token=session_token,
            on_message=self._on_signal_message,
            on_close=self._on_signal_close,
        )
        await self._signal.connect()

        # Phase 9: agent is OFFERER per haonhub viewer wire (phase 4.5
        # alignment 2026-05-19). Coworker viewer waits for our offer
        # then sends answer. Generate + send offer NOW so handshake
        # starts immediately on coworker side opening the WSS.
        offer_sdp = await self._peer.create_offer()
        await self._signal.send({"type": "offer", "sdp": offer_sdp})
        log.info(
            "browser_session_offer_sent",
            session_id=self.session_id,
        )

        log.info(
            "browser_session_ready",
            session_id=self.session_id,
        )

    async def wait(self) -> None:
        """Block until the session ends (monitor disconnect, signaling
        WSS drop, or explicit close())."""
        await self._done.wait()

    async def close(self) -> None:
        """Tear down the session. Idempotent — safe to call from
        multiple paths (monitor disconnect, signaling close, agent
        shutdown).
        """
        async with self._close_lock:
            if self._closed:
                return
            self._closed = True

        log.info("browser_session_closing", session_id=self.session_id)

        # Order matters minimally — signal close first so we don't
        # try to relay frames mid-teardown; monitor next to stop the
        # watchdog; peer; CDP; Chrome.
        await self._safe(self._signal_close())
        await self._safe(self._monitor_shutdown())
        await self._safe(self._peer_close())
        await self._safe(self._page_guard_cancel())
        await self._safe(self._cdp_close())
        await self._safe(self._chrome_close())

        self._done.set()
        log.info("browser_session_closed", session_id=self.session_id)

    # ── Signal handlers ─────────────────────────────────────────────

    async def _on_signal_message(self, frame: dict[str, Any]) -> None:
        """Handle one frame received from broker (relayed from coworker).

        Wire alignment with haonhub viewer (phase 4.5, 2026-05-19):
          - Discriminator field is `type` (matches haonhub's
            studio-session.js + standard WebRTC RTCSessionDescription
            convention). Legacy `msg` accepted as fallback for
            forward-compat with any older callers.
          - Agent is OFFERER → coworker sends `answer`, not `offer`
          - Ping/pong heartbeat: coworker sends `{type:"ping"}` every
            ~25s; we respond `{type:"pong"}` so viewer doesn't think
            the connection is dead.
        """
        kind = frame.get("type") or frame.get("msg")
        if kind == "answer":
            sdp = frame.get("sdp")
            if not isinstance(sdp, str) or self._peer is None:
                log.warning("browser_session_answer_missing_sdp")
                return
            try:
                await self._peer.apply_remote_answer(sdp)
                log.info(
                    "browser_session_answer_applied",
                    session_id=self.session_id,
                )
            except Exception:  # noqa: BLE001
                log.exception("browser_session_answer_apply_failed")
            return
        if kind == "offer":
            # Legacy answerer path — accepted for symmetric negotiation
            # use cases (perfect negotiation, future flow changes).
            # Production wire today has agent as offerer.
            sdp = frame.get("sdp")
            if not isinstance(sdp, str) or self._peer is None:
                log.warning("browser_session_offer_missing_sdp")
                return
            answer_sdp = await self._peer.apply_remote_offer(sdp)
            await self._signal.send({"type": "answer", "sdp": answer_sdp})
            return
        if kind == "ice":
            candidate = frame.get("candidate")
            if not isinstance(candidate, dict) or self._peer is None:
                return
            try:
                await self._peer.add_ice_candidate(candidate)
            except Exception:  # noqa: BLE001
                log.exception("browser_session_ice_add_failed")
            return
        if kind == "ping":
            # Coworker heartbeat — respond so viewer keeps the WSS
            # alive. Best-effort; send may silently fail on a dying
            # signal channel, but the on_close path handles teardown.
            await self._signal.send({"type": "pong"})
            return
        if kind == "ready":
            # Coworker greeted us on connect. Optional ack.
            log.info(
                "browser_session_coworker_ready",
                session_id=self.session_id,
                role=frame.get("role"),
            )
            return
        if kind == "bye":
            log.info(
                "browser_session_bye_received",
                session_id=self.session_id,
                reason=frame.get("reason"),
            )
            asyncio.create_task(self.close(), name="session-close-on-bye")
            return
        # Unknown discriminator — log + drop. Broker is dumb pipe;
        # new msg types may come from haonhub-side viewer at any time.
        log.info(
            "browser_session_unknown_signal_kind",
            session_id=self.session_id,
            kind=kind,
        )

    async def _on_signal_close(self, reason: str) -> None:
        """Signal WSS dropped — tear down the whole session."""
        log.info(
            "browser_session_signal_closed",
            session_id=self.session_id,
            reason=reason,
        )
        asyncio.create_task(self.close(), name="session-close-on-signal-close")

    # ── Monitor handler ─────────────────────────────────────────────

    async def _on_monitor_disconnect(
        self,
        reason: str,
        context: dict[str, Any],
    ) -> None:
        """SessionMonitor exceeded a threshold (idle, blocked counter,
        rapid clicks) → close the session and signal bye to coworker."""
        log.warning(
            "browser_session_monitor_disconnect",
            session_id=self.session_id,
            reason=reason,
            context=context,
        )
        # Notify coworker (best-effort — signal may already be gone)
        if self._signal is not None and not self._closed:
            try:
                await self._signal.send({
                    "type": "bye",
                    "reason": reason,
                })
            except Exception:  # noqa: BLE001
                pass
        asyncio.create_task(self.close(), name="session-close-on-monitor")

    # ── WebRTC state handler ────────────────────────────────────────

    async def _on_peer_state_change(
        self,
        state: str,
        context: dict[str, Any],
    ) -> None:
        """RTCPeerConnection state changed. We care about 'failed' and
        'closed' for tear-down; other transitions are just logged via
        the peer's own audit emit path."""
        if state in ("failed", "closed"):
            log.info(
                "browser_session_peer_terminal",
                session_id=self.session_id,
                state=state,
            )
            asyncio.create_task(self.close(), name="session-close-on-peer-state")

    # ── Permissions bypass audit ────────────────────────────────────

    def _on_locked_perm_attempt(self, key: str) -> None:
        """Called by parse_permissions when haonhub sent a HARDCODED
        key with True value. We emit an audit event so haonhub UI
        misconfiguration surfaces."""
        # Fire-and-forget — parse_permissions is sync, the audit emit
        # is async. Schedule on the loop.
        try:
            asyncio.get_event_loop().create_task(
                self._audit.emit(
                    "blocked_action",
                    {
                        "kind": "permission_bypass_attempt",
                        "permission_key": key,
                    },
                ),
                name=f"audit-perm-bypass-{key}",
            )
        except RuntimeError:
            # No running loop yet (shouldn't happen in our flow since
            # start() runs inside the loop). Drop silently.
            pass

    # ── Teardown helpers ────────────────────────────────────────────

    async def _safe(self, awaitable: Any) -> None:
        try:
            await awaitable
        except Exception:  # noqa: BLE001
            log.exception("browser_session_teardown_step_failed")

    async def _signal_close(self) -> None:
        if self._signal is not None:
            await self._signal.close()

    async def _monitor_shutdown(self) -> None:
        if self._monitor is not None:
            await self._monitor.shutdown()

    async def _peer_close(self) -> None:
        if self._peer is not None:
            await self._peer.close()

    async def _page_guard_cancel(self) -> None:
        if self._page_guard_listener is not None:
            self._page_guard_listener.cancel()
            try:
                await self._page_guard_listener
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass

    async def _cdp_close(self) -> None:
        if self._cdp is not None and hasattr(self._cdp, "close"):
            maybe_coro = self._cdp.close()
            if asyncio.iscoroutine(maybe_coro):
                await maybe_coro

    async def _chrome_close(self) -> None:
        if self._chrome is not None and hasattr(self._chrome, "terminate"):
            self._chrome.terminate()


# ── Module-level registry of active sessions ────────────────────────


class BrowserSessionRegistry:
    """Tracks active BrowserSessions across the agent process. Used by
    transport.py to clean up all sessions on agent shutdown OR main
    WSS reconnect (sessions tied to a specific WSS lifetime).

    Single-replica posture — one registry per agent process. The
    broker tracks multi-session counts independently via SISMEMBER
    on the agents set.
    """

    def __init__(self) -> None:
        self._by_session_id: dict[str, BrowserSession] = {}
        self._lock = asyncio.Lock()

    async def register(self, session: BrowserSession) -> None:
        async with self._lock:
            self._by_session_id[session.session_id] = session

    async def unregister(self, session_id: str) -> None:
        async with self._lock:
            self._by_session_id.pop(session_id, None)

    async def close_all(self) -> None:
        """Close every active session. Called on agent shutdown OR
        main WSS reconnect (existing sessions are dead anyway since
        the audit channel goes through main WSS)."""
        async with self._lock:
            sessions = list(self._by_session_id.values())
            self._by_session_id.clear()
        # Close concurrently with bounded wait
        if not sessions:
            return
        await asyncio.gather(
            *(s.close() for s in sessions),
            return_exceptions=True,
        )

    async def count(self) -> int:
        async with self._lock:
            return len(self._by_session_id)
