"""Sprint 1F.4 phase 3 — apply coworker input events to Chrome via CDP.

The coworker's browser viewer captures mouse + keyboard events from
its `<video>` canvas, packages them as JSON, and sends over the
WebRTC DataChannel established with the agent. The agent's WebRTC
peer receives each message and calls `apply_input_event` here, which
translates to CDP Input.dispatch* calls.

Wire format (agreed contract with haonhub viewer):

    Mouse:
      { type: "mouse",
        action: "down" | "up" | "move" | "wheel",
        x: int, y: int,
        button: "left" | "right" | "middle" | "none",
        deltaX: int, deltaY: int      # only when action=wheel
      }

    Keyboard:
      { type: "key",
        action: "down" | "up",
        key: string,                  # e.g. "a", "Enter", "ArrowDown"
        code: string,                 # e.g. "KeyA", "Enter"
        modifiers: int                # bitmask: alt=1, ctrl=2, meta=4, shift=8
      }

Defense layer notes:
  - HARDCODED hotkeys (F12, Ctrl+T, Ctrl+W) are blocked at the JS
    layer (page_guard) IN THE PAGE — they never reach this dispatcher
    because the coworker's viewer JS would have to construct them
    fake-side AFTER receiving them, which it doesn't do
  - This module DOES validate the event SHAPE. Garbage events
    (missing fields, wrong types) are silently dropped + logged
  - Permissions check: when can_open_new_tab/can_download is False,
    we drop the corresponding hotkey events here too (belt+suspenders;
    page_guard JS already blocks but we defense-in-depth)
"""

from __future__ import annotations

from typing import Any

import structlog


log = structlog.get_logger("agent.browser.input_replay")


# CDP Input.dispatchMouseEvent button mapping. Coworker viewer sends
# lowercase strings; CDP wants exact casing.
_MOUSE_BUTTON_MAP = {
    "left": "left",
    "right": "right",
    "middle": "middle",
    "none": "none",
}

# Mouse action → CDP type
_MOUSE_ACTION_MAP = {
    "down": "mousePressed",
    "up": "mouseReleased",
    "move": "mouseMoved",
    "wheel": "mouseWheel",
}

# Keyboard action → CDP type.
_KEY_ACTION_MAP = {
    "down": "keyDown",
    "up": "keyUp",
}

# Windows virtual key codes for non-printable / special keys. CDP
# REQUIRES windowsVirtualKeyCode for these to actually function —
# without it, Backspace doesn't delete, Enter doesn't submit, arrows
# don't move (bug 2026-05-22: keyDown with only key/code was a no-op
# for special keys). Printable chars derive their vk from the char
# itself (uppercase ASCII) so they're not listed here.
_VK_CODES = {
    "Backspace": 8, "Tab": 9, "Enter": 13, "NumpadEnter": 13,
    "ShiftLeft": 16, "ShiftRight": 16, "ControlLeft": 17,
    "ControlRight": 17, "AltLeft": 18, "AltRight": 18,
    "Pause": 19, "CapsLock": 20, "Escape": 27, "Space": 32,
    "PageUp": 33, "PageDown": 34, "End": 35, "Home": 36,
    "ArrowLeft": 37, "ArrowUp": 38, "ArrowRight": 39, "ArrowDown": 40,
    "Insert": 45, "Delete": 46,
    "MetaLeft": 91, "MetaRight": 92,
    "F1": 112, "F2": 113, "F3": 114, "F4": 115, "F5": 116, "F6": 117,
    "F7": 118, "F8": 119, "F9": 120, "F10": 121, "F11": 122, "F12": 123,
}


def _virtual_key_code(key: str, code: str) -> int:
    """Resolve the Windows virtual key code CDP needs.

    Special keys come from _VK_CODES (by `code` then `key`). Printable
    single chars use the uppercase ASCII of the char (e.g. 'a'→65, the
    'A' keycode — the OS keymap, not the shifted char). Digits map to
    their ASCII. Returns 0 when unknown (CDP tolerates 0 for chars that
    don't need a synthetic key event)."""
    if code in _VK_CODES:
        return _VK_CODES[code]
    if key in _VK_CODES:
        return _VK_CODES[key]
    if len(key) == 1:
        ch = key.upper()
        if "A" <= ch <= "Z" or "0" <= ch <= "9":
            return ord(ch)
    return 0


async def apply_input_event(
    cdp: Any,
    event: dict[str, Any],
    *,
    can_open_new_tab: bool = False,
    can_download: bool = False,
    session_id: str | None = None,
) -> bool:
    """Translate one input event dict to a CDP Input.dispatch* call.

    Returns True if dispatched, False if dropped (invalid shape or
    permission denied). Caller may use the return value to count
    dropped events for audit / debug.

    Permissions enforced HERE in addition to page_guard JS:
      - Ctrl/Cmd+T → drop unless can_open_new_tab (belt+suspenders;
        page_guard.js already preventDefaults but defense-in-depth
        catches if JS was somehow bypassed)
      - Ctrl/Cmd+S, Ctrl/Cmd+P → drop unless can_download
      - F12, Ctrl+Shift+I → always drop (HARDCODED can_use_devtools=False)

    session_id MUST be provided for real Chrome (Input.* is session-
    level — Phase 2 fix 2026-05-22). Optional for unit-test doubles.

    Returns False on any failure — never raises, so a malicious
    payload from coworker DataChannel can't bring down the input task.
    """
    if not isinstance(event, dict):
        log.warning("input_replay_event_not_dict")
        return False

    etype = event.get("type")

    if etype == "mouse":
        return await _apply_mouse(cdp, event, session_id=session_id)
    if etype == "key":
        return await _apply_key(
            cdp,
            event,
            can_open_new_tab=can_open_new_tab,
            can_download=can_download,
            session_id=session_id,
        )
    log.info("input_replay_unknown_type", type=etype)
    return False


async def _apply_mouse(
    cdp: Any, event: dict[str, Any], *, session_id: str | None = None
) -> bool:
    action = event.get("action")
    cdp_type = _MOUSE_ACTION_MAP.get(action)
    if cdp_type is None:
        log.info("input_replay_unknown_mouse_action", action=action)
        return False

    x = event.get("x")
    y = event.get("y")
    if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
        log.info("input_replay_mouse_missing_coords")
        return False

    button = _MOUSE_BUTTON_MAP.get(event.get("button", "none"), "none")
    params: dict[str, Any] = {
        "type": cdp_type,
        "x": int(x),
        "y": int(y),
        "button": button,
        "clickCount": int(event.get("clickCount", 1)) if cdp_type == "mousePressed" else 0,
        # CDP modifier bitmask (Alt=1, Ctrl=2, Meta=4, Shift=8) so
        # ctrl/cmd/shift+click work. Defaults 0 when absent.
        "modifiers": int(event.get("modifiers", 0)),
    }
    # Wheel events need deltaX/deltaY in addition to the position
    if cdp_type == "mouseWheel":
        params["deltaX"] = int(event.get("deltaX", 0))
        params["deltaY"] = int(event.get("deltaY", 0))

    try:
        await cdp.send("Input.dispatchMouseEvent", params, session_id=session_id)
        return True
    except Exception:  # noqa: BLE001
        log.exception("input_replay_mouse_dispatch_failed")
        return False


async def _apply_key(
    cdp: Any,
    event: dict[str, Any],
    *,
    can_open_new_tab: bool,
    can_download: bool,
    session_id: str | None = None,
) -> bool:
    action = event.get("action")
    cdp_type = _KEY_ACTION_MAP.get(action)
    if cdp_type is None:
        log.info("input_replay_unknown_key_action", action=action)
        return False

    key = event.get("key")
    code = event.get("code")
    if not isinstance(key, str) or not isinstance(code, str):
        log.info("input_replay_key_missing_fields")
        return False
    modifiers = int(event.get("modifiers", 0))

    # Permissions enforcement at the dispatcher level (defense-in-depth
    # alongside page_guard.js). Coworker viewer SHOULDN'T send these
    # blocked combos, but if a malicious viewer does, we drop here.
    if _is_blocked_hotkey(
        key=key, code=code, modifiers=modifiers,
        can_open_new_tab=can_open_new_tab,
        can_download=can_download,
    ):
        log.info("input_replay_hotkey_blocked", key=key, code=code)
        return False

    # Printable single char (not "Enter"/"Shift"/"ArrowLeft"/...). For
    # these we set `text` on keyDown so Chrome INSERTS the character —
    # CDP's keyDown-with-text generates the keypress + char in one shot.
    #
    # IMPORTANT (bug 2026-05-22): do NOT also send a separate `char`
    # event. keyDown-with-text already inserts; an extra char event
    # double-types every key ("teste" → "tteessttee"). One event only.
    non_text_mods = modifiers & ~8  # mask Shift (8); keep Alt/Ctrl/Meta
    is_printable_char = len(key) == 1 and non_text_mods == 0
    text = ""
    if is_printable_char:
        text = event.get("text") or key

    vk = _virtual_key_code(key, code)
    params: dict[str, Any] = {
        "type": cdp_type,
        "key": key,
        "code": code,
        "modifiers": modifiers,
        "text": text,
        # Special keys (Backspace/Enter/arrows) are no-ops without the
        # virtual key code; printable chars get their ASCII keycode.
        "windowsVirtualKeyCode": vk,
        "nativeVirtualKeyCode": vk,
    }

    try:
        await cdp.send("Input.dispatchKeyEvent", params, session_id=session_id)
        return True
    except Exception:  # noqa: BLE001
        log.exception("input_replay_key_dispatch_failed")
        return False


def _is_blocked_hotkey(
    *,
    key: str,
    code: str,
    modifiers: int,
    can_open_new_tab: bool,
    can_download: bool,
) -> bool:
    """Return True if this key event matches a blocked combination.
    HARDCODED-blocked (regardless of permissions): F12, devtools combos.
    Permission-gated: Ctrl+T/N (new tab/window), Ctrl+S/P (save/print).
    """
    # CDP modifier bitmask: alt=1, ctrl=2, meta=4 (Cmd on Mac), shift=8
    ctrl_or_meta = bool(modifiers & (2 | 4))
    shift = bool(modifiers & 8)

    # F12 — HARDCODED
    if key == "F12" or code == "F12":
        return True
    # Ctrl+Shift+I / Ctrl+Shift+J → DevTools — HARDCODED
    if ctrl_or_meta and shift and code in ("KeyI", "KeyJ"):
        return True
    # Ctrl+U → view-source — HARDCODED
    if ctrl_or_meta and code == "KeyU":
        return True
    # Permission-gated
    if not can_open_new_tab and ctrl_or_meta and code in ("KeyT", "KeyN"):
        return True
    if not can_download and ctrl_or_meta and code in ("KeyS", "KeyP"):
        return True
    return False
