"""Local-runtime detection for the BYOC hello frame (Sprint 1F.1).

The agent declares which runtime_kinds it can host LOCALLY — the
intersection with the JWS token's `capabilities` claim (what the
tenant is authorized for) tells haonhub which Studio features are
actually usable for this specific machine.

Detection runs once per `byoc connect` cycle. Capabilities don't
change mid-session by design — install Chrome → restart `haon-agent`
→ next reconnect declares `browser`. This matches operator
expectations and keeps detection out of the hot path.

The set of kinds is open-ended (broker regex: ^[a-z][a-z0-9_]{0,31}$).
Adding a new runtime kind:

  1. Add a detector here that returns True/False
  2. Append to the `_DETECTORS` tuple
  3. Broker auto-accepts via the schema; no broker deploy needed

Sprint 1F.1 ships with `ollama` (always — the agent has the runtime
even when the daemon isn't started) and best-effort probes for
`ffmpeg` + `whisper`. The Studio kinds (`browser`, `adb`) ship in
the parallel haonhub-side agent extension Caio is building.
"""

from __future__ import annotations

import shutil
from typing import Callable


def _has_ollama() -> bool:
    """Always True — the agent ships with the Ollama runtime adapter
    regardless of whether the local daemon is running. The runtime
    starts ollama-serve on dispatch; presence-here means "this agent
    knows how to dispatch ollama workflows", not "ollama is up."""
    return True


def _has_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None


def _has_whisper() -> bool:
    """Whisper can ship as either a standalone CLI or a Python module.
    We accept either — workflow dispatch picks the available path."""
    if shutil.which("whisper") is not None:
        return True
    try:
        import importlib.util
        return importlib.util.find_spec("whisper") is not None
    except (ImportError, ValueError):
        return False


def _has_browser() -> bool:
    """Sprint 1F.4 — browser runtime needs Chrome installed locally.
    We only check binary presence here; capabilities.detect MUST stay
    light (called on every hello frame). The full Chrome+CDP launch
    happens lazily when the user runs `haon-agent browser launch`.

    Localised import: launcher.py pulls httpx (already a dep) but is
    OPTIONAL — `pip install haon-agent` users without Studio interest
    shouldn't pay the import cost of the launcher module just for the
    has-Chrome probe.
    """
    try:
        from haon_agent.byoc.runtime.browser.launcher import has_chrome_installed
    except ImportError:
        # Browser subpackage missing entirely — older agent install,
        # or stripped wheel. Treat as no-browser-support.
        return False
    return has_chrome_installed()


# Order doesn't matter for correctness — broker dedupes nothing, but
# the list ends up alphabetised by convention so haonhub UI rendering
# is stable across agent restarts.
_DETECTORS: tuple[tuple[str, Callable[[], bool]], ...] = (
    ("ollama", _has_ollama),
    ("ffmpeg", _has_ffmpeg),
    ("whisper", _has_whisper),
    ("browser", _has_browser),  # Sprint 1F.4 — Chrome present
)


# Default slot capacity per runtime kind. Owner can override via env
# HAON_BYOC_SLOTS=browser:3,adb:1 if their hardware can handle more.
# Sprint 1F.4 phase 5 — multi-coworker support advertisement.
_DEFAULT_SLOTS: dict[str, int] = {
    "browser": 2,  # 2 concurrent coworkers per agent — reasonable for
    #               an RTX 3060+ class GPU @ 720p WebRTC
    "adb": 1,
    "ollama": 1,
    "whisper": 1,
    "ffmpeg": 1,
}


def detect_slots(env_override: str | None = None) -> dict[str, int]:
    """Return the per-runtime-kind slot capacity declared by this
    agent in the hello frame. The broker stores this in
    `caps:<agent_id>` so /v1/byoc/agents/<id>/status can return
    available slots to haonhub UI.

    Env override format: `HAON_BYOC_SLOTS=browser:3,adb:1` — overrides
    the matching default; missing kinds keep their default. Malformed
    entries silently drop + log.

    Capacity is ADVERTISED; the actual capacity-check enforcement
    happens in the agent's session_offer handler (transport.py)
    against the BrowserSessionRegistry's count_by_kind().
    """
    import os
    slots = dict(_DEFAULT_SLOTS)
    raw = env_override if env_override is not None else os.environ.get(
        "HAON_BYOC_SLOTS", ""
    )
    if not raw:
        return slots
    for entry in raw.split(","):
        entry = entry.strip()
        if not entry or ":" not in entry:
            continue
        kind, _, value = entry.partition(":")
        kind = kind.strip()
        try:
            n = int(value.strip())
        except (ValueError, TypeError):
            continue
        if n < 1 or n > 32:
            # Sanity bounds — 32+ concurrent sessions on a single
            # agent is almost certainly a config typo
            continue
        slots[kind] = n
    return slots


def detect_runtime_kinds() -> list[str]:
    """Return the sorted list of runtime kinds the local machine can
    host. Safe to call from non-async context — only filesystem +
    importlib probes, no network.

    Caller (transport._read_loop on `ready`) wraps in try/except so a
    crash here never breaks the connect flow.
    """
    return sorted(name for name, detector in _DETECTORS if detector())


# ── Hotfix 0.5.1: rich hello frame capabilities ──────────────────────


def probe_ollama() -> dict[str, object]:
    """Best-effort probe of the local Ollama daemon at 127.0.0.1:11434.

    Returns:
      {
        "installed":       True if `ollama` CLI is on PATH,
        "daemon_running":  True if /api/version responded,
        "version":         "0.4.2" (None if daemon down),
        "models":          ["qwen2.5:14b", "llama3.2:3b"] (empty if daemon down)
      }

    Network call is timeboxed to 2s so a hung daemon doesn't stall
    every hello frame. All exceptions swallowed — degrade gracefully.
    """
    import shutil

    out: dict[str, object] = {
        "installed": shutil.which("ollama") is not None,
        "daemon_running": False,
        "version": None,
        "models": [],
    }

    # Use httpx if already imported (it is via byoc.ops.ollama),
    # fall back to urllib stdlib so this stays import-cheap.
    try:
        import urllib.error
        import urllib.request
        import json as _json

        req = urllib.request.Request(
            "http://127.0.0.1:11434/api/version",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
            out["daemon_running"] = True
            out["version"] = data.get("version") or None
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return out
    except Exception:  # noqa: BLE001 — never break hello frame
        return out

    # Daemon up — also fetch model list.
    try:
        req = urllib.request.Request(
            "http://127.0.0.1:11434/api/tags",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
            tags = data.get("models") or []
            # Each entry: {"name":"qwen2.5:14b","modified_at":..., ...}
            # Cap at 50 model names to keep hello frame bounded.
            names: list[str] = []
            for entry in tags[:50]:
                if isinstance(entry, dict):
                    name = entry.get("name")
                    if isinstance(name, str) and name:
                        names.append(name)
            out["models"] = names
    except Exception:  # noqa: BLE001
        pass

    return out


def probe_gpu() -> dict[str, object]:
    """Best-effort GPU detection via the existing `haon_agent.hardware`
    module (which already does nvidia-smi parsing).

    Returns:
      {
        "detected":  True if at least one GPU was found,
        "vendor":    "nvidia" | "amd" | "intel" | None,
        "model":     "RTX 5070" (None if no GPU),
        "vram_mb":   12288 (None if no GPU)
      }

    Reuses hardware.detect() — that path is already proven on the
    miner-side flow + has fallbacks for non-NVIDIA hardware (CPU-only
    machines report gpu_count=0).
    """
    out: dict[str, object] = {
        "detected": False,
        "vendor": None,
        "model": None,
        "vram_mb": None,
    }
    try:
        from haon_agent import hardware

        report = hardware.detect()
        if report.gpu_count > 0:
            out["detected"] = True
            out["model"] = report.gpu_model
            if report.gpu_vram_gb:
                out["vram_mb"] = report.gpu_vram_gb * 1024
            # Vendor inference from model string. Best-effort.
            model_lower = (report.gpu_model or "").lower()
            if "rtx" in model_lower or "gtx" in model_lower or "nvidia" in model_lower:
                out["vendor"] = "nvidia"
            elif "radeon" in model_lower or "amd" in model_lower:
                out["vendor"] = "amd"
            elif "intel" in model_lower or "iris" in model_lower or "arc" in model_lower:
                out["vendor"] = "intel"
    except Exception:  # noqa: BLE001 — never break hello frame
        pass
    return out


def detect_full_capabilities() -> dict[str, object]:
    """Aggregate detector for the hotfix 0.5.1 expanded hello frame.

    Bundles:
      - `runtime_kinds`   (legacy field — kept for backward compat)
      - `slots`           (legacy field — kept for backward compat)
      - `ollama`          (probe_ollama() result)
      - `gpu`             (probe_gpu() result)
      - `runtimes_active` (kinds that are CURRENTLY usable, not just
                           "could-be-installed" — e.g. ollama is in
                           runtime_kinds always but only in
                           runtimes_active when the daemon is up)

    The broker's MetricsSink.sanitise_hello_payload accepts unknown
    fields (caps:<agent_id> stores the whole dict), so adding to this
    function doesn't require broker schema updates.
    """
    kinds = detect_runtime_kinds()
    slots = detect_slots()
    ollama_info = probe_ollama()
    gpu_info = probe_gpu()

    # `runtimes_active`: subset of `runtime_kinds` that are CURRENTLY
    # usable. Ollama requires daemon_running; ffmpeg/whisper are
    # binary-checks already so they're identical to runtime_kinds.
    active: list[str] = []
    for kind in kinds:
        if kind == "ollama":
            if ollama_info.get("daemon_running"):
                active.append("ollama")
        else:
            active.append(kind)

    return {
        "runtime_kinds": kinds,
        "slots": slots,
        "ollama": ollama_info,
        "gpu": gpu_info,
        "runtimes_active": sorted(active),
    }
