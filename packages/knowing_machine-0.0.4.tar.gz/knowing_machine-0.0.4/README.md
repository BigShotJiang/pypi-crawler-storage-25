# Knowing-Machine
A Machine that knows.

In order to launch it from command line or as a subprocess:
```bash
  echo "Theodotos-Alexandreus: Do you know, machine?" \
    | uvx knowing-machine \
        --provider-api-key=sk-proj-... \
        --github-token=ghp_... \
        < dialogue.txt
```

Or:
```bash
  pip install knowing-machine
```
Then:
```Python
  # Python
  import knowing_machine
```
