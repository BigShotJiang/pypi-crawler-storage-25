"""
Comprehensive tests for the SkillDepot Python SDK client.

Tests cover:
- Client initialization (default/custom base_url, api_key in headers)
- All public methods on the synchronous SkillDepot client
- Pagination via iter_skills()
- Error handling (401, 403, 404, 429, 500)
"""

import pytest
from unittest.mock import patch, MagicMock

from skilldepot.client import (
    SkillDepot,
    SkillDepotError,
    AuthenticationError,
    AccessDeniedError,
    NotFoundError,
    RateLimitError,
)
from skilldepot.models import (
    SkillListResponse,
    SkillDetailResponse,
    ReviewResponse,
    PackageResponse,
    APIKeyResponse,
    RunResponse,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_response(status_code: int = 200, json_data: dict | None = None, reason: str = "OK"):
    """Build a fake httpx.Response-like object."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.reason_phrase = reason
    resp.json.return_value = json_data if json_data is not None else {}
    return resp


SKILL_PAYLOAD = {
    "id": "skill-1",
    "slug": "hello-world",
    "name": "Hello World",
    "description": "A demo skill",
    "category": "NLP",
    "tags": ["demo"],
    "price": 0.0,
    "pricing_model": "free",
    "rating": 4.5,
    "downloads_count": 100,
    "api_calls_count": 50,
    "reviews_count": 10,
    "version": "1.0.0",
    "content": "# Hello World\nThis is demo content.",
}

REVIEW_PAYLOAD = {
    "id": "review-1",
    "skill_id": "skill-1",
    "user_id": "user-1",
    "rating": 5,
    "comment": "Great skill!",
}

PACKAGE_PAYLOAD = {
    "id": "pkg-1",
    "name": "Starter Pack",
    "description": "A starter package",
    "slug": "starter-pack",
    "is_public": True,
    "price": 0.0,
    "skill_count": 3,
    "skills": [],
}

API_KEY_PAYLOAD = {
    "id": "key-1",
    "name": "My Key",
    "key_prefix": "sk_live_abc",
    "is_active": True,
    "full_key": "sk_live_abc123xyz",
}


# ===========================================================================
# 1. Client initialisation
# ===========================================================================

class TestClientInitialisation:
    def test_default_base_url(self):
        client = SkillDepot()
        assert client.base_url == "https://api.skilldepot.dev"

    def test_custom_base_url(self):
        client = SkillDepot(base_url="https://custom.example.com/")
        assert client.base_url == "https://custom.example.com"

    def test_trailing_slash_stripped(self):
        client = SkillDepot(base_url="https://api.skilldepot.dev/")
        assert client.base_url == "https://api.skilldepot.dev"

    def test_api_key_in_headers(self):
        client = SkillDepot(api_key="sk_live_test123")
        assert client._headers["Authorization"] == "Bearer sk_live_test123"

    def test_no_api_key_no_auth_header(self):
        client = SkillDepot()
        assert "Authorization" not in client._headers

    def test_default_timeout(self):
        client = SkillDepot()
        assert client.timeout == 30.0

    def test_custom_timeout(self):
        client = SkillDepot(timeout=60.0)
        assert client.timeout == 60.0

    def test_user_agent_header(self):
        client = SkillDepot()
        assert "skilldepot-python" in client._headers["User-Agent"]


# ===========================================================================
# 2. list_skills
# ===========================================================================

class TestListSkills:
    @patch("httpx.Client.request")
    def test_returns_skill_list_response(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": [SKILL_PAYLOAD],
            "total": 1,
            "limit": 20,
            "offset": 0,
        })

        client = SkillDepot(api_key="sk_live_test")
        result = client.list_skills()

        assert isinstance(result, SkillListResponse)
        assert result.success is True
        assert len(result.data) == 1
        assert result.data[0].slug == "hello-world"
        assert result.total == 1

    @patch("httpx.Client.request")
    def test_builds_correct_params(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True, "data": [], "total": 0, "limit": 10, "offset": 5,
        })

        client = SkillDepot()
        client.list_skills(category="NLP", q="hello", free=True, locale="en", limit=10, offset=5)

        call_kwargs = mock_request.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["category"] == "NLP"
        assert params["q"] == "hello"
        assert params["free"] == "true"
        assert params["locale"] == "en"
        assert params["limit"] == 10
        assert params["offset"] == 5

    @patch("httpx.Client.request")
    def test_omits_none_params(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True, "data": [], "total": 0, "limit": 20, "offset": 0,
        })

        client = SkillDepot()
        client.list_skills()

        call_kwargs = mock_request.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert "category" not in params
        assert "q" not in params
        assert "free" not in params
        assert "locale" not in params


# ===========================================================================
# 3. get_skill
# ===========================================================================

class TestGetSkill:
    @patch("httpx.Client.request")
    def test_get_skill_basic(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": SKILL_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        result = client.get_skill("hello-world")

        assert isinstance(result, SkillDetailResponse)
        assert result.data.slug == "hello-world"

        url = mock_request.call_args.args[1] if len(mock_request.call_args.args) > 1 else mock_request.call_args[0][1]
        assert "/api/v1/skills/hello-world" in url

    @patch("httpx.Client.request")
    def test_get_skill_with_content(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": SKILL_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.get_skill("hello-world", include_content=True)

        call_kwargs = mock_request.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params.get("content") == "true"

    @patch("httpx.Client.request")
    def test_get_skill_without_content(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": SKILL_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.get_skill("hello-world", include_content=False)

        call_kwargs = mock_request.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert "content" not in params


# ===========================================================================
# 4. download_skill
# ===========================================================================

class TestDownloadSkill:
    @patch("httpx.Client.request")
    def test_returns_content_string(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": SKILL_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        content = client.download_skill("hello-world")

        assert isinstance(content, str)
        assert content == "# Hello World\nThis is demo content."

    @patch("httpx.Client.request")
    def test_returns_empty_string_when_no_content(self, mock_request):
        skill = {**SKILL_PAYLOAD, "content": None}
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": skill,
        })

        client = SkillDepot(api_key="sk_live_test")
        content = client.download_skill("hello-world")

        assert content == ""


# ===========================================================================
# 5. get_package
# ===========================================================================

class TestGetPackage:
    @patch("httpx.Client.request")
    def test_get_package_basic(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": PACKAGE_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        result = client.get_package("pkg-1")

        assert isinstance(result, PackageResponse)
        assert result.data.name == "Starter Pack"

    @patch("httpx.Client.request")
    def test_get_package_with_content(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": PACKAGE_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.get_package("pkg-1", include_content=True)

        call_kwargs = mock_request.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params.get("content") == "true"

    @patch("httpx.Client.request")
    def test_get_package_without_content(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": PACKAGE_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.get_package("pkg-1", include_content=False)

        call_kwargs = mock_request.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert "content" not in params


# ===========================================================================
# 6. create_review
# ===========================================================================

class TestCreateReview:
    @patch("httpx.Client.request")
    def test_create_review_valid(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": REVIEW_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        result = client.create_review("skill-1", rating=5, comment="Great skill!")

        assert isinstance(result, ReviewResponse)
        assert result.data.rating == 5
        assert result.data.comment == "Great skill!"

    @patch("httpx.Client.request")
    def test_create_review_sends_correct_payload(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": REVIEW_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.create_review("skill-1", rating=5, comment="Great skill!")

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert json_body["skill_id"] == "skill-1"
        assert json_body["rating"] == 5
        assert json_body["comment"] == "Great skill!"

    @patch("httpx.Client.request")
    def test_create_review_without_comment(self, mock_request):
        review = {**REVIEW_PAYLOAD, "comment": None}
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": review,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.create_review("skill-1", rating=3)

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert "comment" not in json_body

    def test_create_review_invalid_rating_zero(self):
        client = SkillDepot(api_key="sk_live_test")
        with pytest.raises(ValueError, match="Rating must be between 1 and 5"):
            client.create_review("skill-1", rating=0)

    def test_create_review_invalid_rating_six(self):
        client = SkillDepot(api_key="sk_live_test")
        with pytest.raises(ValueError, match="Rating must be between 1 and 5"):
            client.create_review("skill-1", rating=6)

    def test_create_review_invalid_rating_negative(self):
        client = SkillDepot(api_key="sk_live_test")
        with pytest.raises(ValueError, match="Rating must be between 1 and 5"):
            client.create_review("skill-1", rating=-1)


# ===========================================================================
# 7. create_api_key
# ===========================================================================

class TestCreateApiKey:
    @patch("httpx.Client.request")
    def test_create_api_key_valid(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": API_KEY_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        result = client.create_api_key("My Key")

        assert isinstance(result, APIKeyResponse)
        assert result.data.name == "My Key"
        assert result.data.full_key == "sk_live_abc123xyz"

    @patch("httpx.Client.request")
    def test_create_api_key_strips_whitespace(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": API_KEY_PAYLOAD,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.create_api_key("  My Key  ")

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert json_body["name"] == "My Key"

    def test_create_api_key_empty_name(self):
        client = SkillDepot(api_key="sk_live_test")
        with pytest.raises(ValueError, match="Key name is required"):
            client.create_api_key("")

    def test_create_api_key_whitespace_only(self):
        client = SkillDepot(api_key="sk_live_test")
        with pytest.raises(ValueError, match="Key name is required"):
            client.create_api_key("   ")


# ===========================================================================
# 8. revoke_api_key
# ===========================================================================

class TestRevokeApiKey:
    @patch("httpx.Client.request")
    def test_revoke_returns_true(self, mock_request):
        mock_request.return_value = _mock_response(200, {"success": True})

        client = SkillDepot(api_key="sk_live_test")
        result = client.revoke_api_key("key-1")

        assert result is True

    @patch("httpx.Client.request")
    def test_revoke_returns_false_when_not_success(self, mock_request):
        mock_request.return_value = _mock_response(200, {"success": False})

        client = SkillDepot(api_key="sk_live_test")
        result = client.revoke_api_key("key-1")

        assert result is False

    @patch("httpx.Client.request")
    def test_revoke_sends_delete_request(self, mock_request):
        mock_request.return_value = _mock_response(200, {"success": True})

        client = SkillDepot(api_key="sk_live_test")
        client.revoke_api_key("key-1")

        args = mock_request.call_args.args if mock_request.call_args.args else mock_request.call_args[0]
        assert args[0] == "DELETE"
        assert "api-keys?id=key-1" in args[1]


# ===========================================================================
# 9. run
# ===========================================================================

class TestRun:
    @patch("httpx.Client.request")
    def test_run_returns_run_response(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": {"run_id": "run-1", "content": "# Hello"},
            "output": "Generated output",
        })

        client = SkillDepot(api_key="sk_live_test")
        result = client.run("hello-world", input_data={"prompt": "Hi"})

        assert isinstance(result, RunResponse)
        assert result.success is True
        assert result.data["run_id"] == "run-1"

    @patch("httpx.Client.request")
    def test_run_sends_correct_payload(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True, "data": {}, "output": None,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.run("hello-world", input_data={"prompt": "Hi"})

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert json_body == {"input": {"prompt": "Hi"}}

    @patch("httpx.Client.request")
    def test_run_default_empty_input(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True, "data": {}, "output": None,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.run("hello-world")

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert json_body == {"input": {}}

    @patch("httpx.Client.request")
    def test_run_url_contains_slug(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True, "data": {}, "output": None,
        })

        client = SkillDepot(api_key="sk_live_test")
        client.run("my-skill")

        url = mock_request.call_args.args[1] if len(mock_request.call_args.args) > 1 else mock_request.call_args[0][1]
        assert "/api/v1/run/my-skill" in url


# ===========================================================================
# 10. get_stats
# ===========================================================================

class TestGetStats:
    @patch("httpx.Client.request")
    def test_returns_dict(self, mock_request):
        stats = {
            "totalSkills": 150,
            "totalDevelopers": 42,
            "totalApiCalls": 10000,
            "totalDownloads": 5000,
        }
        mock_request.return_value = _mock_response(200, stats)

        client = SkillDepot()
        result = client.get_stats()

        assert isinstance(result, dict)
        assert result["totalSkills"] == 150
        assert result["totalDevelopers"] == 42


# ===========================================================================
# 11. health
# ===========================================================================

class TestHealth:
    @patch("httpx.Client.request")
    def test_returns_dict(self, mock_request):
        health_data = {
            "status": "healthy",
            "timestamp": "2026-01-01T00:00:00Z",
            "version": "1.0.0",
            "checks": {"database": "ok", "cache": "ok"},
        }
        mock_request.return_value = _mock_response(200, health_data)

        client = SkillDepot()
        result = client.health()

        assert isinstance(result, dict)
        assert result["status"] == "healthy"

    @patch("httpx.Client.request")
    def test_health_calls_correct_endpoint(self, mock_request):
        mock_request.return_value = _mock_response(200, {"status": "healthy"})

        client = SkillDepot()
        client.health()

        url = mock_request.call_args.args[1] if len(mock_request.call_args.args) > 1 else mock_request.call_args[0][1]
        assert url.endswith("/api/health")


# ===========================================================================
# 12. iter_skills (pagination)
# ===========================================================================

class TestIterSkills:
    @patch("httpx.Client.request")
    def test_single_page(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True,
            "data": [SKILL_PAYLOAD],
            "total": 1,
            "limit": 20,
            "offset": 0,
        })

        client = SkillDepot()
        skills = list(client.iter_skills())

        assert len(skills) == 1
        assert skills[0].slug == "hello-world"
        assert mock_request.call_count == 1

    @patch("httpx.Client.request")
    def test_multiple_pages(self, mock_request):
        skill_a = {**SKILL_PAYLOAD, "id": "s1", "slug": "skill-a"}
        skill_b = {**SKILL_PAYLOAD, "id": "s2", "slug": "skill-b"}
        skill_c = {**SKILL_PAYLOAD, "id": "s3", "slug": "skill-c"}

        page1 = _mock_response(200, {
            "success": True, "data": [skill_a, skill_b], "total": 3, "limit": 2, "offset": 0,
        })
        page2 = _mock_response(200, {
            "success": True, "data": [skill_c], "total": 3, "limit": 2, "offset": 2,
        })
        mock_request.side_effect = [page1, page2]

        client = SkillDepot()
        skills = list(client.iter_skills(page_size=2))

        assert len(skills) == 3
        assert skills[0].slug == "skill-a"
        assert skills[1].slug == "skill-b"
        assert skills[2].slug == "skill-c"
        assert mock_request.call_count == 2

    @patch("httpx.Client.request")
    def test_stops_when_offset_exceeds_total(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True, "data": [], "total": 0, "limit": 20, "offset": 0,
        })

        client = SkillDepot()
        skills = list(client.iter_skills())

        assert len(skills) == 0
        assert mock_request.call_count == 1

    @patch("httpx.Client.request")
    def test_passes_filters(self, mock_request):
        mock_request.return_value = _mock_response(200, {
            "success": True, "data": [], "total": 0, "limit": 10, "offset": 0,
        })

        client = SkillDepot()
        list(client.iter_skills(category="NLP", q="test", free=True, locale="pt", page_size=10))

        call_kwargs = mock_request.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["category"] == "NLP"
        assert params["q"] == "test"
        assert params["free"] == "true"
        assert params["locale"] == "pt"
        assert params["limit"] == 10


# ===========================================================================
# 13. Error handling
# ===========================================================================

class TestErrorHandling:
    @patch("httpx.Client.request")
    def test_401_raises_authentication_error(self, mock_request):
        mock_request.return_value = _mock_response(
            401, {"error": "Invalid API key"}, reason="Unauthorized",
        )

        client = SkillDepot(api_key="bad_key")
        with pytest.raises(AuthenticationError) as exc_info:
            client.list_skills()

        assert exc_info.value.status_code == 401
        assert "Invalid API key" in exc_info.value.message

    @patch("httpx.Client.request")
    def test_403_raises_access_denied_error(self, mock_request):
        mock_request.return_value = _mock_response(
            403, {"error": "Access denied"}, reason="Forbidden",
        )

        client = SkillDepot(api_key="sk_live_test")
        with pytest.raises(AccessDeniedError) as exc_info:
            client.download_skill("paid-skill")

        assert exc_info.value.status_code == 403

    @patch("httpx.Client.request")
    def test_404_raises_not_found_error(self, mock_request):
        mock_request.return_value = _mock_response(
            404, {"error": "Skill not found"}, reason="Not Found",
        )

        client = SkillDepot()
        with pytest.raises(NotFoundError) as exc_info:
            client.get_skill("nonexistent-skill")

        assert exc_info.value.status_code == 404
        assert "not found" in exc_info.value.message.lower()

    @patch("httpx.Client.request")
    def test_429_raises_rate_limit_error(self, mock_request):
        mock_request.return_value = _mock_response(
            429, {"error": "Rate limit exceeded"}, reason="Too Many Requests",
        )

        client = SkillDepot(api_key="sk_live_test")
        with pytest.raises(RateLimitError) as exc_info:
            client.list_skills()

        assert exc_info.value.status_code == 429

    @patch("httpx.Client.request")
    def test_500_raises_skilldepot_error(self, mock_request):
        mock_request.return_value = _mock_response(
            500, {"error": "Internal server error"}, reason="Internal Server Error",
        )

        client = SkillDepot()
        with pytest.raises(SkillDepotError) as exc_info:
            client.get_stats()

        assert exc_info.value.status_code == 500

    @patch("httpx.Client.request")
    def test_error_with_unparseable_body(self, mock_request):
        resp = MagicMock()
        resp.status_code = 502
        resp.reason_phrase = "Bad Gateway"
        resp.json.side_effect = ValueError("No JSON")

        mock_request.return_value = resp

        client = SkillDepot()
        with pytest.raises(SkillDepotError) as exc_info:
            client.health()

        assert exc_info.value.status_code == 502
        assert "Bad Gateway" in exc_info.value.message

    @patch("httpx.Client.request")
    def test_error_is_base_class_of_specific_errors(self, mock_request):
        mock_request.return_value = _mock_response(
            401, {"error": "Unauthorized"}, reason="Unauthorized",
        )

        client = SkillDepot()
        with pytest.raises(SkillDepotError):
            client.list_skills()
