# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [3.2.0] — 2026-04-26

Infrastructure Overhaul & Exotic Platform Stability

*   **🚀 Exotic Platform Support:** Full integration with the `exotic-wheels` index, enabling seamless installation on `musllinux` (armv7l, aarch64, ppc64le, s390x).
*   **🛠️ C-Extension Hardening:** Resolved critical 32-bit pointer truncation warnings on `armv7l` and `i686` targets to ensure memory safety across architectures.
*   **📦 Binary Distribution:** Introduced `abi3` wheels for atomic extensions, allowing a single wheel to work across multiple Python 3.x versions.
*   **⚙️ Build Pipeline Refactor:** Massive overhaul of `publish2.yml` and `conda_build` workflows, reducing build failures and optimizing the `cibuildwheel` environment.
*   **🧹 Codebase Hygiene:** Removed ~10k lines of stale locale data and applied wide-scale refactoring for better maintainability.

---

**📝 Code Changes:**
- UPDATE: src/omnipkg/commands/run.py (33 lines changed)

**⚙️ Configuration:**
- pyproject.toml (6 lines)

**Additional Changes:**
- Update configuration
- fix: fix import in conda forge mapping logic
- fix: update locales path and resolve manifest warnings

**New Features:**
- feat: abi3 wheel for atomic ext, exotic platform hint on musl builds

**Bug Fixes:**
- fix: exotic-wheels index url, add build/ to gitignore
- fix: use /simple/ path for exotic-wheels index url
- fix: resolve 32-bit pointer truncation warnings on armv7l/i686
- fix: remove merge conflict markers from publish2.yml
- fix: safe march flags, remove build fallback, add ref input to workflow
- fix: add locale.getencoding shim to setup.py to fix C dispatcher in manylinux
- fix: remove auditwheel silent fallback to prevent bare linux_aarch64 tags

**Updates:**
- Update pip install command to use only-binary option
- Update project title and description in README
- Update build environment and before build commands
- Update CIBW_BEFORE_BUILD to include setuptools version
- Update workflow ID in homebrew-update.yml

_42 files changed, 984 insertions(+), 10319 deletions(-)_

## [3.1.2] — 2026-04-26

Infrastructure Overhaul & Exotic Platform Stability

*   **🚀 Exotic Platform Support:** Full integration with the `exotic-wheels` index, enabling seamless installation on `musllinux` (armv7l, aarch64, ppc64le, s390x).
*   **🛠️ C-Extension Hardening:** Resolved critical 32-bit pointer truncation warnings on `armv7l` and `i686` targets to ensure memory safety across architectures.
*   **📦 Binary Distribution:** Introduced `abi3` wheels for atomic extensions, allowing a single wheel to work across multiple Python 3.x versions.
*   **⚙️ Build Pipeline Refactor:** Massive overhaul of `publish2.yml` and `conda_build` workflows, reducing build failures and optimizing the `cibuildwheel` environment.
*   **🧹 Codebase Hygiene:** Removed ~10k lines of stale locale data and applied wide-scale refactoring for better maintainability.

---

**📝 Code Changes:**
- UPDATE: src/omnipkg/commands/run.py (33 lines changed)

**⚙️ Configuration:**
- pyproject.toml (6 lines)

**Additional Changes:**
- fix: fix import in conda forge mapping logic
- fix: update locales path and resolve manifest warnings

**New Features:**
- feat: abi3 wheel for atomic ext, exotic platform hint on musl builds

**Bug Fixes:**
- fix: exotic-wheels index url, add build/ to gitignore
- fix: use /simple/ path for exotic-wheels index url
- fix: resolve 32-bit pointer truncation warnings on armv7l/i686
- fix: remove merge conflict markers from publish2.yml
- fix: safe march flags, remove build fallback, add ref input to workflow
- fix: add locale.getencoding shim to setup.py to fix C dispatcher in manylinux
- fix: remove auditwheel silent fallback to prevent bare linux_aarch64 tags

**Updates:**
- Update pip install command to use only-binary option
- Update project title and description in README
- Update build environment and before build commands
- Update CIBW_BEFORE_BUILD to include setuptools version
- Update workflow ID in homebrew-update.yml

_41 files changed, 941 insertions(+), 10319 deletions(-)_

## [3.1.1] — 2026-04-24

Filesystem Resilience & CI Hardening

Bug Fixes
	•	Fixed locale.getencoding() crash when building on manylinux/musllinux containers — added packaging>=21.3 to [build-system].requires so pip’s isolated build env always gets a modern packaging library regardless of what’s baked into the Docker image
	•	Fixed filesystem watcher falsely flagging our own FFI installs as “External Culprits” due to PEP 503 name normalization mismatches (e.g. mkdocs-minify-plugin vs mkdocs_minify_plugin) — injected a regex normalizer so hyphens, underscores, and dots match uniformly
	•	Replaced eval with ast.literal_eval (security hardening, caught by DeepSource)
CI/CD
	•	Pinned musllinux images to 2025.02.28-1 tag instead of latest for reproducible builds
	•	Added retry logic for checkout and Python setup steps to improve flaky runner reliability
	•	Added full backfill workflow — retroactively push wheels to GitHub Releases and regenerate the GitHub Pages wheel index, with dry-run support
	•	Overhauled Pages deployment workflow — cleaner triggers, manual dispatch support
	•	Docker CI now runs as root for both amd64 and arm64 test images
	•	Updated uv-ffi submodule to v0.10.8.post11 (piwheels OOM fix for Python 3.13 aarch64)

---

**Bug Fixes:**
- fix: add packaging>=21.3 to build-system requires to fix locale.getencoding() in manylinux/musllinux containers

**Updates:**
- Update publish2.yml
- Update GitHub Actions workflow for Pages deployment

_10 files changed, 772 insertions(+), 172 deletions(-)_

## [3.1.0] — 2026-04-24

The Unified Daemon & IPC Synchronization Release

**The Unified Daemon & IPC Synchronization Release**

This release resolves critical synchronization bugs between the master daemon and managed worker subprocesses, ensuring perfect cache coherency and file system tracking across all supported Python versions (3.7 - 3.15).

* **Per-Interpreter Native Extensions:** Removed the static FFI import fallback. Omnipkg now dynamically searches the running interpreter's `site-packages` and natively loads the correct `uv_ffi.abi3.so` wheel for that specific Python version. This guarantees the FFI engine operates on the correct memory space and layout for the target environment, rather than blindly defaulting to the daemon's native extension.

* **Unified Socket Routing:** Fixed a bug where managed worker subprocesses would attempt to compute their own isolated daemon hash (which didn't exist) instead of communicating with the master daemon. All managed workers now inherit `OMNIPKG_ENV_ID_OVERRIDE`, ensuring they route their `start_omnipkg_op` and `end_omnipkg_op` signals directly to the native master daemon.
* **Microsecond Filesystem Snapshots:** Overhauled the `MtimeFallbackWatcher`. It now takes a high-precision snapshot of the environment *immediately* upon receiving the `START` signal. At the `END` signal, it diffs this baseline against the post-op state and unions the result with the official FFI changelog. This guarantees zero dropped events and completely eliminates false-positive "External Culprit" warnings during ultra-fast (<100ms) FFI installs.
* **Surgical Cache Patching:** The Python wrapper now sends precise, name+version parsed deltas to the daemon for `patch_site_packages_cache`, avoiding expensive full-cache invalidations whenever possible.

* **Submodule Versioning:** Bumped the `uv-ffi` floor requirement to `v0.10.8.post7`. The Python wrapper has been cleaned up and strictly expects the modern 4-tuple return signature (`rc, inst, rem, err`).

---

**📝 Code Changes:**
- UPDATE: src/omnipkg/_vendor/uv_ffi/__init__.py (92 lines changed)
- UPDATE: src/omnipkg/core.py (134 lines changed)
- UPDATE: src/omnipkg/isolation/fs_watcher.py (257 lines changed)
- UPDATE: src/omnipkg/isolation/worker_daemon.py (1 lines changed)

**⚙️ Configuration:**
- pyproject.toml (2 lines)

**Additional Changes:**
- chore: update toml to prepare for release
- feat: fix uv-ffi per-interpreter .so loading and daemon IPC for managed workers

**Bug Fixes:**
- fix: resolve daemon interactivity and stream fileno crashes
- fix: rename locale -> locales to prevent stdlib shadowing on py3.11
- fix: prevent setup-miniconda from nuking host shell profiles on self-hosted runner

**Updates:**
- Update macOS runners and Python versions in workflow
- Update build requirements in meta-platforms.yaml
- Update cibuildwheel version to v2.23.0
- Update publish2.yml
- Update GitHub Actions workflow for wheel building
- Update Python versions and improve wheel build process
- Update ARM32 verification workflow with permissions

_72 files changed, 926 insertions(+), 801 deletions(-)_

## [3.0.0] — 2026-04-16

The Reproducible State Engine & Native C-Dispatcher Update

Welcome to Omnipkg 3.0! This release (258 commits) marks a fundamental architectural shift — replacing Python-based routing with a native C-dispatcher, introducing true reproducible environment lockfiles, upgrading the bubble isolation engine to Schema 2.0, and massively hardening Windows and macOS support.

## ⚠️ Breaking Changes
- **Manifest Schema 2.0** — Bubble manifests auto-migrate on first run. Downgrading to 2.5.x after upgrading is not recommended.
- **Native C-Dispatcher** — Entry points (`8pkg`, `omnipkg`) are now compiled C binaries. Set `OMNIPKG_FORCE_PYTHON_DISPATCH=1` to bypass if needed.
- **Daemon IPC Protocol** — Updated length-prefixed protocol and FS Watcher integration. Old daemon instances will not be compatible.

## ✨ Major Features

- Snapshot any multi-interpreter environment into a canonical TOML lockfile (`omnipkg.lock`).
- Two-tier lock architecture: local context (paths, env origin) stays private; canonical State SHA (package hashes, ABI tags, arch) is zero-PII and safe to share.
- SHA comparison detects environment drift before executing destructive rebuilds.
- Interactive lock picker (`8pkg sync --pick`) lists all known states grouped by environment.
- "Phase 0" metadata repair pass safely recovers corrupted or partially-broken environments before syncing.

- Sub-2ms command routing — eliminates Python startup overhead on every CLI invocation.
- Auto-compiles from bundled `dispatcher.c` on first run (Linux/macOS/Windows).
- Auto-discovers MSVC (`cl.exe`) and reconstructs the build environment on Windows without requiring a Developer Command Prompt.
- Eagerly creates versioned shims (`8pkg37`–`8pkg315`) at compile time on all platforms.
- Graceful fallback to the Python dispatcher for complex edge cases (like auto-adopting a missing interpreter).

- Bubble manifests upgraded to Schema 2.0 with `record_hash`, `wheel_abi_tag`, and `symlink_targets` for byte-level ABI-safe deduplication.
- Non-destructive lazy migration — existing 1.0 manifests upgrade silently in the background.
- **Bulletproof Target Installs:** Forced `--link-mode copy` globally for all target (bubble) installs. This prevents catastrophic environment corruption if the global `uv` cache is ever cleared, ensuring isolated bubbles remain completely independent on all OSes.
- Force rebuild via `8pkg doctor --rebuild` or `8pkg reset -y`.

- Cross-platform filesystem watcher (`inotify` / `FSEvents` / `ReadDirectoryChangesW`) monitors the environment for external changes.
- If a rogue tool (`pip`, `conda`) modifies the environment, the daemon's in-memory cache is immediately marked dirty, triggering a safe rescan.
- Operation lock (`.omnipkg_op.lock`) suppresses false positives during active, Omnipkg-managed installs.

## 🪟 Windows Hardening
- Fixed fatal hang in non-interactive execution — replaced blocking `stdin` reads with timeout-bounded threaded reads.
- Fixed drive-letter colon splitting bug during hash comparisons.
- Fixed `Scripts/` vs `bin/` path detection logic for managed interpreters.
- Fixed `__editable__` dist-info detection during sync conflict resolution.

## 🍎 macOS Hardening
- Fixed `venv` escape bug where `resolve()` caused daemon workers to accidentally spawn under the global Apple Framework Python.
- Restored `__PYVENV_LAUNCHER__` injections to maintain strict environment bounds.
- Added `.dylib` fallbacks for `libpython` preloads.

---

**📝 Code Changes:**
- UPDATE: build_hooks.py (23 lines changed)
- UPDATE: setup.py (105 lines changed)
- UPDATE: setup_atomic.py (12 lines changed)
- UPDATE: src/omnipkg/_vendor/uv_ffi/__init__.py (44 lines changed)
- UPDATE: src/omnipkg/cli.py (277 lines changed)
- UPDATE: src/omnipkg/commands/run.py (59 lines changed)
- UPDATE: src/omnipkg/common_utils.py (197 lines changed)
- UPDATE: src/omnipkg/core.py (2663 lines changed)
- NEW: src/omnipkg/dispatcher.c (2133 lines changed)
- UPDATE: src/omnipkg/dispatcher.py (828 lines changed)
- UPDATE: src/omnipkg/i18n.py (128 lines changed)
- UPDATE: src/omnipkg/installation/verification_strategy.py (140 lines changed)
- NEW: src/omnipkg/integration/reproducible.py (2444 lines changed)
- UPDATE: src/omnipkg/isolation/fs_watcher.py (1171 lines changed)
- UPDATE: src/omnipkg/isolation/resource_monitor.py (163 lines changed)
- UPDATE: src/omnipkg/isolation/worker_daemon.py (1955 lines changed)
- UPDATE: src/omnipkg/package_meta_builder.py (715 lines changed)
- UPDATE: src/omnipkg/utils/flask_port_finder.py (78 lines changed)
- UPDATE: tools/dispatcher_bin/_post_install.py (41 lines changed)
- NEW: tools/dispatcher_bin/dispatcher.c (428 lines changed)

**🧪 Tests:**
- UPDATE: pytest.ini (5 lines)
- UPDATE: src/tests/test_concurrent_install.py (138 lines)
- UPDATE: src/tests/test_multiverse_healing.py (498 lines)
- UPDATE: src/tests/test_old_flask.py (10 lines)
- UPDATE: src/tests/test_rich_switching.py (43 lines)
- UPDATE: src/tests/test_uv_switching.py (87 lines)
- UPDATE: src/tests/test_version_combos.py (4 lines)
- NEW: tests/
- NEW: tests/debug_flask.py
- UPDATE: tests/test_flask_port_finder.py (894 lines)
- NEW: tests/test_verify_bubble_deps.py (193 lines)
- NEW: tests/test_verify_bubble_deps2.py (127 lines)

**📚 Documentation:**
- README.md (182 lines)
- THIRD_PARTY_NOTICES.txt (250 lines)
- requirements-trace.txt (57 lines)
- requirements.txt (134 lines)

**⚙️ Configuration:**
- .github/dependabot.yml (17 lines)
- pyproject.toml (19 lines)

**Additional Changes:**
- Update configuration
- docs: update readme and licenses file
- Update 1 code files
- Update 2 code files
- Update tests
- fix(fs-watcher): prevent watchdog threads from blocking process exit on Windows and daemon shutdown
- fix(win): stabilize non-interactive execution and prevent CLI hangs
- test(win): stop fs_watcher on daemon shutdown to prevent CI hang
- test(win): debug windows hanging on concurrent install test
- test(win): fix windows hanging on concurrent install test
- feat(core): introduce global cache metadata and upgrade bubble manifests to schema 2.0
- test(win): allow daemon spawned shell to exit on windows
- test(win): debug test failure on windows
- test(win): spawn daemon in concurrent install test safely on windows
- fix(time-machine): isolate historical builds and fix py38 metadata access
- fix(dispatcher): deterministic shim creation + reliable subprocess execution
- fix(win): fix windows sync: native exe detection and stale dist-info check
- fix: windows path logic for healing interpreters
- fix(win): fix binary check for windows
- fix(win): fix debug print for hash matching
- fix: hash matching on windows
- fix(win): marker detection
- fix: windows shim detection
- fix: debug windows shim logic
- fix: fix windows shim detection
- fix(win): add #include <stdlib.h> inside the _WIN32 block early
- fix(win32): resolve POSIX popen/pclose compatibility in C-dispatcher
- fix: fix heredoc escaping in dispatcher.c
- feat(dispatcher): auto-reconstruct MSVC build environment for cl.exe
- fix: correct corrupted MSVC glob paths in dispatcher
- fix: Windows MSVC detection + managed interpreter Lib/ path
- test: add utf8 to numpy combo test for windows
- test: fix binary detection for windows on the uv test
- test: fix logical bug where the test could ttest for the wrong version
- chore: bump req.txts for Pygments
- fix: allow lower Pygments for pythons 3.7-3.8, pending LTS patches
- chore: bump req.txts
- feat: uv_ffi version enforcement + worker daemon hardening
- chore(deps): bump dependencies, lock ffi submodule, and expose uv_ffi version
- feat: stabilize multi-env sync, bubble verification, and FFI cache observability
- perf: Replace slow pip freeze with fast SHA caching and direct FS scanning
- chore: bump aiohttp in toml
- chore(deps): bump deps in req.txts
- chore: tell dependabot to ignore dockerfiles
- fix(cache): derive sqlite db suffix from python_executable path, not python_version config field
- fix: harden uv daemon cache sync, target safety, and fs watcher stability
- feat: add reproducible env state engine, lock sync, and self-healing rebuilds
- fix(windows): normalize path case for relative_to comparisons
- feat(daemon): add subprocess fallback for worker startup timeouts
- fix: fix bootstrap logic and optimize concurrent test sequence
- fix(windows): get python paths from registry vs info python command
- fix(ffi): catch uv-ffi panics
- fix: fixing dispatcher install for windows
- fix: fix dispatcher for windows support
- feat: add Windows support and POSIX abstractions to C dispatcher
- fix(dispatcher): guard Unix-only headers behind #else block
- feat(daemon): add support for pinned workers to survive eviction
- feat: add conda-forge name mapping for robust PyPI package resolution
- feat(dispatcher): embed C source and auto-install on first run
- fix: Update 1 code files
- perf(c++): improving c++ support cross platform
- refactor(c++): making c++ supported cross-platform
- fix(dispatcher): Update 1 code files
- feat(dispatcher): adding support for python calls before adoption occurs
- feat(dispatcher): adding auto adopt if missing for installs
- fix(dispatcher): ensure system pythons aren't used for python existence validation
- fix(dispatcher): improving zsh handling and adding validation and adoption of python if missing
- fix(windows): restoring working windows daemon swap logic
- fix: register adopted pythons consistently
- fix: ensure reset-config deletes global as well
- fix(mac): removing resolve from native python identification on rescans
- fix(daemon): ensure venv python is used on mac
- fix(daemon): use __PYVENV_LAUNCHER__ to correctly spawn macOS venv workers
- chore(daemon): improve monitor python identification
- fix(daemon): preserve venv paths by avoiding symlink resolution on macOS/Linux
- fix(mac): stop resolving paths in sync context to runtime
- fix: stop symlinking system pythons
- fix(mac): removing resolve from venv path logic for mac
- fix: reset configuration will also remove setup complete flag now
- fix(mac): fixing resolved path display in info python for mac
- fix: reset-config now deletes per-python config alongside legacy global conf
- fix(mac): python path resolution logic fixed for mac
- fix: prevent pip uninstall failure on macOS/Windows due to uppercase entrypoints
- fix: heal missing 8pkg entrypoint after editable install
- fix(config): reenable config writing
- fix(mac): fix missing config logic
- fix(mac): config resolution on mac with symlinks fixed
- fix(mac): fixing flask port finder for mac to resolve paths
- fix: flask port finder functional for windows and linux
- fix(windows): debug windows flask port finder
- fix(windows): flask port finder debugging on windows
- fix(windows): fixing windows subprocess pipe issues for flask port finder
- fix(windows): fixing encoding error on windows flask port finder
- fix(windows): fixing windows specific bugs in the flask port finder
- chore: remove excessive dehug prints on i18n
- perf(windows): improve windows config detection logic
- perf(conda): improve conda python version detection
- fix(config): stale config detection logic
- feat(hi): Complete Hindi translation from 15% to 94%
- test: add contract tests for dispatcher, flask_port_finder, and omnipkg loader

**New Features:**
- feat: pin uv_ffi>=0.10.8.post2 and add version heal in concurrent sync
- feat: bring over rewritten test_version_combos.py with C-extension ABI documentation
- feat: bring over package_meta_builder O(1) lookup and improved stress test
- feat: bring over resource_monitor interactive kill menu and package_index O(1) lookup
- feat: bring over daemon worker safe_input relay and isatty override from developer-port
- feat: pre-create .bat shims on Windows for all Python versions to enable auto-adopt
- feat: bring over i18n caching and cli parser caching + daemon preload sentinels
- feat: add uv_ffi as a dependency
- feat: bring over new standalone modules, translations, and test files
- feat: bring over dispatcher bin tools and uv_ffi build script
- feat: bring over setup.py with versioned shim install and uv-ffi build hook
- feat: C dispatcher creates versioned shims 3.7-3.15 on compile, Python fallback does same on first run

**Bug Fixes:**
- fix: restore loader.py to 7041a0de state
- fix: parse Windows interpreter paths correctly in test_concurrent_install
- fix: sterile verification subprocess, copy link-mode for --target installs
- fix: skip pre-creating versioned shims on Windows, use lazy .bat creation after adoption
- fix: use .exe extension for Windows C dispatcher binary
- fix: skip -ldl on Windows, use ASCII codes for path separators in dispatcher.c
- fix: add Windows POSIX compat shims to dispatcher.c (stat, dirname, basename, execv)
- fix: add Windows realpath compat shim to dispatcher.c
- fix: add --python to global_parser so it's consumed before command detection
- fix: sentinel path fires for all unregistered versions not just minor mismatches
- fix: remove shadowed _ import in main(), gate uv_ffi to py3.8-3.14
- fix: language-keyed parser cache and recompile corrupted ko/de .mo files
- fix: resolve_python_path returns sentinel path for unregistered versions to trigger auto-adopt
- fix: add -ldl linker flag and daemon socket fast-path to dispatcher
- fix: remove overly broad /omnipkg/ gitignore rule

**Updates:**
- Update cleanup command in demo-matrix-test.yml
- Update dispatcher.py - fix native Python config handling
- Update cross_interpreter_installs.yml
- Update gitignore.
- Update requirements-science.txt

_87 files changed, 27748 insertions(+), 7635 deletions(-)_

## [2.6.0] — 2026-04-16

The Reproducible State Engine & Native C-Dispatcher Update

Welcome to Omnipkg 3.0! This release (258 commits) marks a fundamental architectural shift — replacing Python-based routing with a native C-dispatcher, introducing true reproducible environment lockfiles, upgrading the bubble isolation engine to Schema 2.0, and massively hardening Windows and macOS support.

## ⚠️ Breaking Changes
- **Manifest Schema 2.0** — Bubble manifests auto-migrate on first run. Downgrading to 2.5.x after upgrading is not recommended.
- **Native C-Dispatcher** — Entry points (`8pkg`, `omnipkg`) are now compiled C binaries. Set `OMNIPKG_FORCE_PYTHON_DISPATCH=1` to bypass if needed.
- **Daemon IPC Protocol** — Updated length-prefixed protocol and FS Watcher integration. Old daemon instances will not be compatible.

## ✨ Major Features

- Snapshot any multi-interpreter environment into a canonical TOML lockfile (`omnipkg.lock`).
- Two-tier lock architecture: local context (paths, env origin) stays private; canonical State SHA (package hashes, ABI tags, arch) is zero-PII and safe to share.
- SHA comparison detects environment drift before executing destructive rebuilds.
- Interactive lock picker (`8pkg sync --pick`) lists all known states grouped by environment.
- "Phase 0" metadata repair pass safely recovers corrupted or partially-broken environments before syncing.

- Sub-2ms command routing — eliminates Python startup overhead on every CLI invocation.
- Auto-compiles from bundled `dispatcher.c` on first run (Linux/macOS/Windows).
- Auto-discovers MSVC (`cl.exe`) and reconstructs the build environment on Windows without requiring a Developer Command Prompt.
- Eagerly creates versioned shims (`8pkg37`–`8pkg315`) at compile time on all platforms.
- Graceful fallback to the Python dispatcher for complex edge cases (like auto-adopting a missing interpreter).

- Bubble manifests upgraded to Schema 2.0 with `record_hash`, `wheel_abi_tag`, and `symlink_targets` for byte-level ABI-safe deduplication.
- Non-destructive lazy migration — existing 1.0 manifests upgrade silently in the background.
- **Bulletproof Target Installs:** Forced `--link-mode copy` globally for all target (bubble) installs. This prevents catastrophic environment corruption if the global `uv` cache is ever cleared, ensuring isolated bubbles remain completely independent on all OSes.
- Force rebuild via `8pkg doctor --rebuild` or `8pkg reset -y`.

- Cross-platform filesystem watcher (`inotify` / `FSEvents` / `ReadDirectoryChangesW`) monitors the environment for external changes.
- If a rogue tool (`pip`, `conda`) modifies the environment, the daemon's in-memory cache is immediately marked dirty, triggering a safe rescan.
- Operation lock (`.omnipkg_op.lock`) suppresses false positives during active, Omnipkg-managed installs.

## 🪟 Windows Hardening
- Fixed fatal hang in non-interactive execution — replaced blocking `stdin` reads with timeout-bounded threaded reads.
- Fixed drive-letter colon splitting bug during hash comparisons.
- Fixed `Scripts/` vs `bin/` path detection logic for managed interpreters.
- Fixed `__editable__` dist-info detection during sync conflict resolution.

## 🍎 macOS Hardening
- Fixed `venv` escape bug where `resolve()` caused daemon workers to accidentally spawn under the global Apple Framework Python.
- Restored `__PYVENV_LAUNCHER__` injections to maintain strict environment bounds.
- Added `.dylib` fallbacks for `libpython` preloads.

## 🌍 i18n (Internationalization)
- **Hindi:** Translation coverage

---

**📝 Code Changes:**
- UPDATE: build_hooks.py (23 lines changed)
- UPDATE: setup.py (105 lines changed)
- UPDATE: setup_atomic.py (12 lines changed)
- UPDATE: src/omnipkg/_vendor/uv_ffi/__init__.py (44 lines changed)
- UPDATE: src/omnipkg/cli.py (277 lines changed)
- UPDATE: src/omnipkg/commands/run.py (59 lines changed)
- UPDATE: src/omnipkg/common_utils.py (197 lines changed)
- UPDATE: src/omnipkg/core.py (2663 lines changed)
- NEW: src/omnipkg/dispatcher.c (2133 lines changed)
- UPDATE: src/omnipkg/dispatcher.py (828 lines changed)
- UPDATE: src/omnipkg/i18n.py (128 lines changed)
- UPDATE: src/omnipkg/installation/verification_strategy.py (140 lines changed)
- NEW: src/omnipkg/integration/reproducible.py (2444 lines changed)
- UPDATE: src/omnipkg/isolation/fs_watcher.py (1171 lines changed)
- UPDATE: src/omnipkg/isolation/resource_monitor.py (163 lines changed)
- UPDATE: src/omnipkg/isolation/worker_daemon.py (1955 lines changed)
- UPDATE: src/omnipkg/package_meta_builder.py (715 lines changed)
- UPDATE: src/omnipkg/utils/flask_port_finder.py (78 lines changed)
- UPDATE: tools/dispatcher_bin/_post_install.py (41 lines changed)
- NEW: tools/dispatcher_bin/dispatcher.c (428 lines changed)

**🧪 Tests:**
- UPDATE: pytest.ini (5 lines)
- UPDATE: src/tests/test_concurrent_install.py (138 lines)
- UPDATE: src/tests/test_multiverse_healing.py (498 lines)
- UPDATE: src/tests/test_old_flask.py (10 lines)
- UPDATE: src/tests/test_rich_switching.py (43 lines)
- UPDATE: src/tests/test_uv_switching.py (87 lines)
- UPDATE: src/tests/test_version_combos.py (4 lines)
- NEW: tests/
- NEW: tests/debug_flask.py
- UPDATE: tests/test_flask_port_finder.py (894 lines)
- NEW: tests/test_verify_bubble_deps.py (193 lines)
- NEW: tests/test_verify_bubble_deps2.py (127 lines)

**📚 Documentation:**
- README.md (182 lines)
- THIRD_PARTY_NOTICES.txt (250 lines)
- requirements-trace.txt (57 lines)
- requirements.txt (134 lines)

**⚙️ Configuration:**
- .github/dependabot.yml (17 lines)
- pyproject.toml (21 lines)

**Additional Changes:**
- docs: update readme and licenses file
- Update 1 code files
- Update 2 code files
- Update tests
- fix(fs-watcher): prevent watchdog threads from blocking process exit on Windows and daemon shutdown
- fix(win): stabilize non-interactive execution and prevent CLI hangs
- test(win): stop fs_watcher on daemon shutdown to prevent CI hang
- test(win): debug windows hanging on concurrent install test
- test(win): fix windows hanging on concurrent install test
- feat(core): introduce global cache metadata and upgrade bubble manifests to schema 2.0
- test(win): allow daemon spawned shell to exit on windows
- test(win): debug test failure on windows
- test(win): spawn daemon in concurrent install test safely on windows
- fix(time-machine): isolate historical builds and fix py38 metadata access
- fix(dispatcher): deterministic shim creation + reliable subprocess execution
- fix(win): fix windows sync: native exe detection and stale dist-info check
- fix: windows path logic for healing interpreters
- fix(win): fix binary check for windows
- fix(win): fix debug print for hash matching
- fix: hash matching on windows
- fix(win): marker detection
- fix: windows shim detection
- fix: debug windows shim logic
- fix: fix windows shim detection
- fix(win): add #include <stdlib.h> inside the _WIN32 block early
- fix(win32): resolve POSIX popen/pclose compatibility in C-dispatcher
- fix: fix heredoc escaping in dispatcher.c
- feat(dispatcher): auto-reconstruct MSVC build environment for cl.exe
- fix: correct corrupted MSVC glob paths in dispatcher
- fix: Windows MSVC detection + managed interpreter Lib/ path
- test: add utf8 to numpy combo test for windows
- test: fix binary detection for windows on the uv test
- test: fix logical bug where the test could ttest for the wrong version
- chore: bump req.txts for Pygments
- fix: allow lower Pygments for pythons 3.7-3.8, pending LTS patches
- chore: bump req.txts
- feat: uv_ffi version enforcement + worker daemon hardening
- chore(deps): bump dependencies, lock ffi submodule, and expose uv_ffi version
- feat: stabilize multi-env sync, bubble verification, and FFI cache observability
- perf: Replace slow pip freeze with fast SHA caching and direct FS scanning
- chore: bump aiohttp in toml
- chore(deps): bump deps in req.txts
- chore: tell dependabot to ignore dockerfiles
- fix(cache): derive sqlite db suffix from python_executable path, not python_version config field
- fix: harden uv daemon cache sync, target safety, and fs watcher stability
- feat: add reproducible env state engine, lock sync, and self-healing rebuilds
- fix(windows): normalize path case for relative_to comparisons
- feat(daemon): add subprocess fallback for worker startup timeouts
- fix: fix bootstrap logic and optimize concurrent test sequence
- fix(windows): get python paths from registry vs info python command
- fix(ffi): catch uv-ffi panics
- fix: fixing dispatcher install for windows
- fix: fix dispatcher for windows support
- feat: add Windows support and POSIX abstractions to C dispatcher
- fix(dispatcher): guard Unix-only headers behind #else block
- feat(daemon): add support for pinned workers to survive eviction
- feat: add conda-forge name mapping for robust PyPI package resolution
- feat(dispatcher): embed C source and auto-install on first run
- fix: Update 1 code files
- perf(c++): improving c++ support cross platform
- refactor(c++): making c++ supported cross-platform
- fix(dispatcher): Update 1 code files
- feat(dispatcher): adding support for python calls before adoption occurs
- feat(dispatcher): adding auto adopt if missing for installs
- fix(dispatcher): ensure system pythons aren't used for python existence validation
- fix(dispatcher): improving zsh handling and adding validation and adoption of python if missing
- fix(windows): restoring working windows daemon swap logic
- fix: register adopted pythons consistently
- fix: ensure reset-config deletes global as well
- fix(mac): removing resolve from native python identification on rescans
- fix(daemon): ensure venv python is used on mac
- fix(daemon): use __PYVENV_LAUNCHER__ to correctly spawn macOS venv workers
- chore(daemon): improve monitor python identification
- fix(daemon): preserve venv paths by avoiding symlink resolution on macOS/Linux
- fix(mac): stop resolving paths in sync context to runtime
- fix: stop symlinking system pythons
- fix(mac): removing resolve from venv path logic for mac
- fix: reset configuration will also remove setup complete flag now
- fix(mac): fixing resolved path display in info python for mac
- fix: reset-config now deletes per-python config alongside legacy global conf
- fix(mac): python path resolution logic fixed for mac
- fix: prevent pip uninstall failure on macOS/Windows due to uppercase entrypoints
- fix: heal missing 8pkg entrypoint after editable install
- fix(config): reenable config writing
- fix(mac): fix missing config logic
- fix(mac): config resolution on mac with symlinks fixed
- fix(mac): fixing flask port finder for mac to resolve paths
- fix: flask port finder functional for windows and linux
- fix(windows): debug windows flask port finder
- fix(windows): flask port finder debugging on windows
- fix(windows): fixing windows subprocess pipe issues for flask port finder
- fix(windows): fixing encoding error on windows flask port finder
- fix(windows): fixing windows specific bugs in the flask port finder
- chore: remove excessive dehug prints on i18n
- perf(windows): improve windows config detection logic
- perf(conda): improve conda python version detection
- fix(config): stale config detection logic
- feat(hi): Complete Hindi translation from 15% to 94%
- test: add contract tests for dispatcher, flask_port_finder, and omnipkg loader

**New Features:**
- feat: pin uv_ffi>=0.10.8.post2 and add version heal in concurrent sync
- feat: bring over rewritten test_version_combos.py with C-extension ABI documentation
- feat: bring over package_meta_builder O(1) lookup and improved stress test
- feat: bring over resource_monitor interactive kill menu and package_index O(1) lookup
- feat: bring over daemon worker safe_input relay and isatty override from developer-port
- feat: pre-create .bat shims on Windows for all Python versions to enable auto-adopt
- feat: bring over i18n caching and cli parser caching + daemon preload sentinels
- feat: add uv_ffi as a dependency
- feat: bring over new standalone modules, translations, and test files
- feat: bring over dispatcher bin tools and uv_ffi build script
- feat: bring over setup.py with versioned shim install and uv-ffi build hook
- feat: C dispatcher creates versioned shims 3.7-3.15 on compile, Python fallback does same on first run

**Bug Fixes:**
- fix: restore loader.py to 7041a0de state
- fix: parse Windows interpreter paths correctly in test_concurrent_install
- fix: sterile verification subprocess, copy link-mode for --target installs
- fix: skip pre-creating versioned shims on Windows, use lazy .bat creation after adoption
- fix: use .exe extension for Windows C dispatcher binary
- fix: skip -ldl on Windows, use ASCII codes for path separators in dispatcher.c
- fix: add Windows POSIX compat shims to dispatcher.c (stat, dirname, basename, execv)
- fix: add Windows realpath compat shim to dispatcher.c
- fix: add --python to global_parser so it's consumed before command detection
- fix: sentinel path fires for all unregistered versions not just minor mismatches
- fix: remove shadowed _ import in main(), gate uv_ffi to py3.8-3.14
- fix: language-keyed parser cache and recompile corrupted ko/de .mo files
- fix: resolve_python_path returns sentinel path for unregistered versions to trigger auto-adopt
- fix: add -ldl linker flag and daemon socket fast-path to dispatcher
- fix: remove overly broad /omnipkg/ gitignore rule

**Updates:**
- Update cleanup command in demo-matrix-test.yml
- Update dispatcher.py - fix native Python config handling
- Update cross_interpreter_installs.yml
- Update gitignore.
- Update requirements-science.txt

_86 files changed, 27512 insertions(+), 7636 deletions(-)_

## [2.5.0] — 2026-02-27

Smart Worker Isolation, Active Memory Control, and Multi-Version ML/Science Docker Images

## Overview

v2.5.0 introduces process-level worker isolation, enforceable memory budgets, and officially supported multi-version ML/Science Docker environments.

This release upgrades how OmniPkg handles large AI workloads, persistent state management, and container reproducibility.

---

## 🚀 Worker Tags: Process-Level Isolation

The daemon now supports `worker_tag` in `execute_smart`, enabling explicit routing to dedicated, persistent worker processes.

Previously, heavy models loaded under the same package spec shared a single interpreter process. Loading multiple large models (e.g., translation + speech recognition) could cause uncontrolled RAM growth due to shared residency.

```python
execute_smart(..., worker_tag="nllb")
execute_smart(..., worker_tag="whisper")
```

Each tag creates (or reuses) a distinct persistent process.

- No cross-model memory stacking
- Warm model reuse with deterministic isolation
- Predictable system resource behavior
- Clean horizontal scaling patterns

---

## 🧠 Active Memory Management

Workers now support `max_memory_mb`. If a worker exceeds its configured memory budget:

- It is recycled cleanly
- A fresh process is spawned
- The daemon remains stable

This eliminates long-lived memory bloat and "zombie" accumulation scenarios.

---

Internal state now distinguishes:

- **Persistent globals** (e.g., cached model weights)
- **Transient task data** (e.g., input tensors)

Transient keys are explicitly cleaned post-execution, preventing input-size-dependent memory growth while keeping heavy models hot in memory.

---

## 🐳 Official Multi-Version Docker Images

OmniPkg now ships production-ready Docker images demonstrating true multi-version coexistence.

Preconfigured AI environment with:

- Torch 2.1 / 2.2 / 2.9
- TensorFlow 2.13 / 2.20
- Multiple NumPy versions
- CUDA-enabled variants
- Hardened non-root runtime

This container demonstrates conflicting ML stacks coexisting cleanly without downgrades or environment duplication.

---

A reproducible scientific stack including:

- NumPy 1.x and 2.x
- Multiple SciPy versions
- Pandas
- Scikit-Learn

Designed for regression testing and scientific reproducibility across dependency boundaries.

---

## 🛠 Developer Experience Improvements

- Short-form Python resolution (`"3.11"`, `"py39"`)
- Improved worker health checks (busy vs hung distinction)
- Unified interpreter resolution via `_resolve_python_exe`
- Alpine builds pinned to 3.12 to avoid musl + Python 3.13 locale regressions

---

## 🧪 Testing & Stability

- Added `test_daemon_tags.py`
  - Validates tag isolation
  - Validates warm reuse behavior
  - Benchmarks persistence characteristics
- Explicit cleanup of transient `_worker_globals` keys
- Improved daemon lifecycle handling

---

## 🌍 Internationalization

- Updated Hindi, Russian, and Japanese translations
- Regenerated compiled catalogs
- Placeholder consistency corrections

---

**📝 Code Changes:**
- UPDATE: src/omnipkg/isolation/worker_daemon.py (532 lines changed)

**🧪 Tests:**
- NEW: src/tests/test_daemon_tags.py (212 lines)

**Additional Changes:**
- chore(i18n): update Hindi, Japanese, and Russian translations
- feat(daemon): implement worker isolation tags, memory caps, and persistent globals

**Updates:**
- Update requirements-science.txt
- Update Dockerfile.ml
- Update build-docker-images.yml
- Update Dockerfile.science
- Update Dockerfile.cuda
- Update Dockerfile.alpine

_14 files changed, 5216 insertions(+), 1380 deletions(-)_

## [2.4.2] — 2026-02-25

Fix missing native versioned shims and implement Windows .bat shim factory

**Core Fixes:**
*   **Dispatcher Self-Healing:** Added `_ensure_native_shims()` to the dispatcher startup. This ensures that the native/primary Python interpreter receives versioned shims (e.g., `8pkg311`) even when the standard adoption path short-circuits.
*   **Windows Shim Factory:** Overhauled `install_versioned_entrypoints` to create functional `.bat` wrappers on Windows. Previously, it attempted to create Unix-style symlinks which are unsupported/unrecognized as commands in Windows CMD/PowerShell.
*   **Version Injection:** Windows shims now explicitly inject the `--python X.Y` flag to ensure the dispatcher correctly routes commands even when the calling process name is ambiguous.

**CI & Testing:**
*   **New Workflow:** Added `debug_dispatcher_installs.yml` to verify versioned command routing in clean environments.
*   **Concurrency Stress Test:** Updated `test_concurrent_install.py` with "Phase 0" to validate that versioned dispatchers correctly target independent interpreters simultaneously.

**Maintenance:**
*   **Dockerfile:** Reverted Alpine base to `3.13` (stable) to avoid alpha-build bugs in `3.14`, while ensuring `pip >= 25.0` to mitigate CVE-2025-8869.
*   **Docs:** Updated support matrix for Python 3.15 and added installation instructions for `pixi` and `prefix.dev`.

---

**📝 Code Changes:**
- UPDATE: src/omnipkg/dispatcher.py (462 lines changed)

**🧪 Tests:**
- UPDATE: src/tests/test_concurrent_install.py (146 lines)

**⚙️ Configuration:**
- .github/workflows/debug_dispatcher_installs.yml (67 lines)
- pyproject.toml (2 lines)

**Additional Changes:**
- fix(ci): Update 1 code files
- fix(windows): ensure .bat exists for windows native pythons
- Update tests; Update configuration
- fix(dispatcher): Update 1 code files
- Update 1 code files
- Update configuration
- fix: Update configuration
- Update tests
- test: Update tests

**Updates:**
- Update debug_dispatcher_installs.yml
- Update README.md
- Update Dockerfile.alpine

_6 files changed, 463 insertions(+), 267 deletions(-)_

## [2.4.1] — 2026-02-25

Faster Startup, GPU IPC Fixes, and Architecture Updates

* **Architecture & Performance**: Added a dedicated section documenting the Worker Daemon, deep dive into its internals, and benchmarking against Docker, Conda, and traditional process spawn models.
* **C-Dispatcher Integration**: Native C binary now replaces slow pip wrappers for `8pkg`, improving startup speed and daemon performance.
* **Lazy Imports & GPU IPC Fixes**: Heavy modules (requests, redis, asyncio, i18n) now lazily imported. Universal GPU IPC fixed for cross-process tensor sharing (~2.4ms latency).
* **NumPy ABI Compatibility**: Automatic injection of `numpy==1.26.4` in daemon workers for PyTorch/TensorFlow tasks to bridge NumPy 2.x ABI breakages.

* Fixed core import issues and missing lazy imports in `core.py` and `dispatcher.py`.
* Corrected Python version detection and `pyproject.toml` path resolution.
* CI & Windows: Added .bat support for concurrent install tests; smart install command fixes.
* Requests and omnipkgMetadataGatherer missing imports added for fresh interpreter contexts.

* Overhauled `test_concurrent_install.py` and `test_tensorflow_switching.py` to benchmark cold vs. hot daemon executions and demonstrate C-extension swap limitations.
* Removed obsolete `test_swap_install.py`.

* Updated `upload_anaconda.yml` workflow for automated builds and uploads to Anaconda.org.
* Minor fixes in `build_hooks.py` and `dispatcher.c` compilation flow.

---

✅ This release focuses on **performance, correctness, and cross-platform stability** while documenting omnipkg’s architecture for developers and power users.

---

**📝 Code Changes:**
- NEW: build_hooks.py (52 lines changed)
- UPDATE: setup.py (85 lines changed)
- UPDATE: src/omnipkg/cli.py (54 lines changed)
- UPDATE: src/omnipkg/core.py (273 lines changed)
- UPDATE: src/omnipkg/dispatcher.py (413 lines changed)
- UPDATE: src/omnipkg/isolation/worker_daemon.py (281 lines changed)

**🧪 Tests:**
- UPDATE: src/tests/test_concurrent_install.py (2 lines)
- UPDATE: src/tests/test_tensorflow_switching.py (953 lines)

**📚 Documentation:**
- docs/architecture_performance/
- docs/demos/demos_concurrent_multiverse.md (2 lines)
- mkdocs.yml (6 lines)

**⚙️ Configuration:**
- .github/workflows/upload_anaconda.yml (326 lines)
- pyproject.toml (3 lines)

**Additional Changes:**
- ci(windows): Update 1 code files
- ci: Update tests
- Update tests
- fix(windows): ci
- fix(test): correct smart install command construction
- fix(imports): core import in concurrent test fixed
- fix(windows): add .bat support for concurrent install test for windows
- fix: add missing requests imports
- fix: missing import for requests added to pip compat check
- fix: Update 1 code files; Update tests
- fix: fix missing imports in dispatcher
- docs(architecture): add Architecture & Performance section with daemon deep dive and benchmarking
- fix(resolve pyproject.toml path depth and Python 3.7 version detection): - Fix parent.parent → parent.parent.parent in core.py and cli.py so
- perf: reduce ConfigManager instantiations during install
- perf(C-dispatcher integration, lazy imports, and GPU IPC fixes): This commit introduces massive performance improvements to the startup
- fix(ci): correct token name for anaconda
- ci: add Anaconda.org upload workflow for minds3t channel

**Bug Fixes:**
- fix: add missing omnipkgMetadataGatherer imports in core.py

**Updates:**
- Update upload_anaconda.yml

_21 files changed, 2774 insertions(+), 1049 deletions(-)_

## [2.4.0] — 2026-02-23

Multi-Package Activation, Windows Stability & CLI Overhaul

**Massive Architectural Update**
**Base:** `v2.3.1` | **Patch Level:** `2.4.0`

This major release brings deep architectural improvements to the omnipkg core engine, complete stabilization of the Windows concurrent daemon, a completely overhauled CLI experience, and critical CVE dependency backports.

*   **Multi-Package Activation:** The `omnipkgLoader` and `8pkg run` now support activating multiple packages simultaneously (via lists, dicts, or comma-separated strings).
*   **CLI & UX Overhaul:** Completely rewrote the CLI utilizing `RawTextHelpFormatter` for detailed, real-world examples.
*   **Interactive Config Wizard:** Added `8pkg config` interactive menu for setting system language, overriding install strategies, and diagnosing environment paths.
*   **In-Process WorkerPool Fallback:** Removed the fake Windows daemon compatibility layer. The system now features a robust, native, in-process `WorkerPool` fallback if the background daemon socket is unreachable.
*   **Automated Stdlib Injection:** The `8pkg run` command now heuristically injects forgotten standard library imports (e.g., `sys`, `json`, `pathlib`) when running inline `-c` code or piping from `stdin`.

*   **Windows Path Case Resolution:** Fixed deep Windows `pip` bugs where lowercased `site-packages` paths caused `ModuleNotFoundError` during installation.
*   **Stricter Runner Isolation:** The `8pkg run` wrapper no longer leaks the parent `PYTHONPATH` to child environments, preventing interpreter pollution when using versioned aliases (e.g., `8pkg38`).
*   **"Dirty" Spec Detection:** Large, side-effect-heavy libraries (like `torch` and `tensorflow`) are now pinned to specific workers to prevent `sys.modules` cross-contamination.

*   **Deadlock Prevention:** Fixed a 3-process handle inheritance deadlock on Windows that caused `8pkg run` to hang indefinitely in non-interactive CI environments.
*   **Safety Scanner Deadlock:** Replaced `subprocess.run` with `Popen.communicate()` to prevent buffer-fill deadlocks during vulnerability scans.
*   **Py3.7 Compatibility:** Restored and hardened Python 3.7 support within the package metadata builder (`importlib_metadata` fallbacks, `.egg-info` scanning).
*   **I18n Normalization:** Fixed case-sensitivity bugs in the language detection engine (e.g., `zh-CN` vs `zh_cn` vs `ZH_CN`).

*   **Dependency CVE Floors:** Enforced strict minimum versions in requirements to resolve upstream vulnerabilities (CVE-2026-22701, CVE-2026-27205, CVE-2026-27199, CVE-2026-21860).
*   **LTS Backports:** Integrated updated CVE-safe backports for `urllib3-lts` and `filelock-lts` on Python versions < 3.10.

---
*Generated via `gitship release`.*

---

**📝 Code Changes:**
- UPDATE: src/omnipkg/apis/local_bridge.py (106 lines changed)
- UPDATE: src/omnipkg/cli.py (1384 lines changed)
- UPDATE: src/omnipkg/commands/run.py (302 lines changed)
- UPDATE: src/omnipkg/common_utils.py (1 lines changed)
- UPDATE: src/omnipkg/core.py (979 lines changed)
- UPDATE: src/omnipkg/dispatcher.py (252 lines changed)
- UPDATE: src/omnipkg/i18n.py (53 lines changed)
- UPDATE: src/omnipkg/installation/dependency_constraints.py (76 lines changed)
- UPDATE: src/omnipkg/isolation/worker_daemon.py (536 lines changed)
- UPDATE: src/omnipkg/loader.py (137 lines changed)
- UPDATE: src/omnipkg/package_meta_builder.py (38 lines changed)
- UPDATE: src/omnipkg/utils/flask_port_finder.py

**🧪 Tests:**
- NEW: conftest.py (25 lines)
- NEW: pytest.ini (3 lines)
- NEW: src/tests/conftest.py (33 lines)
- UPDATE: src/tests/test_concurrent_install.py (444 lines)
- UPDATE: src/tests/test_old_rich.py (70 lines)
- UPDATE: src/tests/test_rich_switching.py (6 lines)

**📚 Documentation:**
- requirements-trace.txt (196 lines)
- requirements.txt (137 lines)

**⚙️ Configuration:**
- .github/workflows/mac_daemon_debug.yml (162 lines)
- pyproject.toml (31 lines)

**Additional Changes:**
- fix(toml): apply correct flask per python in deps
- fix(toml): correctly assign werkzeug deps based on python
- fix: add missing import
- Update 1 code files
- fix(i18n): normalize language codes consistently everywhere
- fix: correct dep version in toml
- docs(cli): expand run command help with real-world examples
- fix(deps): enforce secure dependency floors for CVE compliance
- refactor(core): streamline package info display and fix dependencies
- fix(toml): correct toml dependencies
- i18n: Update translations [ja]
- fix: revert changes to flask port finder.
- feat(core): add multi-package activation and harden execution isolation
- test: improve concurrent benchmark with fair cold-start measurement
- fix(isolation): resolve Windows path casing and worker config fallback
- fix: fixing concurrent windows ci test
- fix: fix concurrent test for windows
- fix: fix concurrent install test
- test: add debug output to concurrent install test to expose Windows daemon behavior
- feat: add non-interactive support and direct selection flags to info command
- fix: improving daemon startup in ci concurrent test on windows
- fix(test): delegate daemon startup to CLI command to prevent first-run hang
- fix: restore exceptions for ensure_daemon_running
- fix: consume daemon output to prevent Windows pipe buffer hang on first run
- fix: force early exit after successful demo in non‑interactive mode
- fix: force early exit after successful script in non‑interactive mode
- debug concurrent demo for windows ci
- revert to 16804f5
- fix: attempt to fix windows ci non-interactive run commmand returning on execution completion
- fix: attempt #2 to fix windows non-interactive run command
- fix: attempting to fix windows ci non-interactive for the run command
- fix(runner): resolve Windows pipe handle inheritance deadlock in CI
- feat: improve dependency resolution with ruamel mapping and PyPI lookup
- fix: prevent process hangs in non-interactive/CI execution
- fix: add missing interactive_session import
- fix: use DEVNULL for stdin in non-interactive run sessions
- fix: skip interactive prompts in non-interactive sessions
- Restoring 3.7 support for package metadata building.
- fix: fix Windows parallel import deadlock and exclude demo crash from pytest
- fix: prevent subprocess deadlock in safety scan
- feat(cli): overhaul CLI UX, add config wizard and web permission fix
- fix: resolve Py3.7 ModuleNotFoundError and improve KB rebuild reliability
- fix: enable .egg-info detection to support Python 3.7 and legacy installs
- fix: fix importlib.metadata compatibility in rich switching test
- fix: add retries to python download to handle transient HTTP 502/503 errors
- fix: Fixing python cache init order.
- feat: remove fake Windows daemon and add in-process WorkerPool fallback
- chore: sync dev changes (core refactor, CI fixes, dispatcher logic)
- fix: fix scoping of SUPPORTED_IMPLEMENTATIONS and add macOS debug workflow
- refactor: remove dead hotswap config and cleanup setup logic
- refactor: remove legacy Python 3.11 hotswap code and fix non-interactive info prompt
- fix: Python 3.7-3.9 compatibility for importlib.resources + omnipkgXY symlinks
- fix: Fix daemon log file creation.

**Bug Fixes:**
- fix: revert regression hunks to state at c7b7924a
- fix: revert regression hunks to state at c33c39ff

**Updates:**
- Update demo-matrix-test.yml
- Update README.md
- Update publish.yml
- Update windows-concurrency-test.yml
- Update worker_daemon.py
- Update test_concurrent_install.py
- Update Redis key usage in knowledge_base_check.yml
- Update rich version retrieval method in workflow
- Update Docker CI workflow for PyPI integration

_37 files changed, 5216 insertions(+), 3832 deletions(-)_

## [2.3.1] — 2026-02-20

Security Mitigation (CVE-2025-14009) & Context Isolation Fixes

This release addresses a critical upstream vulnerability and improves the reliability of the `swap` command.

- **NLTK Vulnerability (CVE-2025-14009):** Removed `safety` from the default dependencies. This tool pulled in `nltk`, which contains a critical Remote Code Execution (RCE) vulnerability.
- **New Default Scanner:** `pip-audit` is now the primary security scanner for all Python versions.
- **Opt-in:** If you specifically require `safety`, you can now install it via the optional extra: `pip install omnipkg[audit]`.

- **Swap Context Leaks:** Fixed a critical issue where `omnipkg swap` environments would leak into parent shells. This was caused by user-defined `exit` functions (common in Conda users' `.bashrc`) intercepting the shell termination signal.
- **Shim Generation:** Fixed an issue where versioned shims were not being generated correctly on Unix systems.
- **Dispatcher:** Resolved `UnboundLocalError` in the shim execution logic.

- **Russian (ru):** Comprehensive update to Russian translations, resolving fuzzy entries and missing placeholders.

---

**⚙️ Configuration:**
- pyproject.toml (15 lines)

**Additional Changes:**
- fix: security: make 'safety' optional to mitigate NLTK CVE-2025-14009
- chore(locale): update Russian translations

_6 files changed, 968 insertions(+), 735 deletions(-)_

## [2.3.0] — 2026-02-18

Windows Daemon Stability, Strict Python Isolation & Swap Refactor

🚀 Major Improvements

🪟 Windows Daemon — Reliable Headless Operation

The daemon now runs correctly in headless Windows environments (SSH, CI, non-interactive shells).

Key fixes:
	•	Corrected detached process stdio handling
	•	Eliminated silent spawn failures
	•	Stabilized restart sequencing to avoid half-initialized daemon states

8pkg daemon restart now performs deterministic stop/start behavior without race conditions.

⸻

🐍 Strict Cross-Interpreter Isolation

Resolved a critical edge case where workers spawned for one Python interpreter could resolve packages from another interpreter’s site-packages.

Isolation is now strictly enforced:
	•	Worker path resolution is interpreter-pinned
	•	PID → Python version detection improved
	•	Interpreter version extraction hardened
	•	Shim validation ensures environment authenticity

This guarantees:
	•	No cross-version leakage
	•	Correct ABI boundaries for C-extensions
	•	Deterministic dependency resolution

⸻

🔀 Swap System Refactor — Single Source of Truth

All interactive swap logic has been consolidated into dispatcher.py.

Previously split across CLI and dispatcher layers, swap handling now:
	•	Centralizes PATH injection
	•	Manages shim creation consistently
	•	Handles Windows .bat generation
	•	Uses --rcfile strategy on Unix
	•	Strips stale .omnipkg shims cleanly
	•	Preserves user aliases correctly

This eliminates duplication and improves maintainability.

⸻

🧠 Interpreter Adoption & Shim Improvements

Interpreter adoption flow significantly hardened:
	•	Dependency checks before adoption
	•	Automatic shim creation for adopted interpreters
	•	Live output streaming during adoption
	•	Registry polling for confirmation
	•	Unified subprocess execution via _run_info_python

This improves transparency and reliability when integrating external interpreters.

⸻

📊 Resource Monitor Enhancements

Resource monitor was refactored for clarity and efficiency:
	•	Improved PID → Python version detection
	•	Better GPU usage reporting
	•	Streamlined psutil-based process collection
	•	Idle worker replenishment logic refined
	•	Cleaner performance metric calculations

Worker accounting and version reporting are now more robust.

⸻

🔐 Knowledge Base Lock Handling

Refactored rebuild logic to properly handle stale locks and prevent deadlock conditions during concurrent operations.

⸻

🌍 Internationalization Surge

Massive expansion of Arabic (Egyptian) localization:
	•	Coverage increased from ~10% to 95%+
	•	Automated translation pipeline with validation and formatting repair
	•	.mo binaries regenerated
	•	Significant improvements to Standard Arabic and Japanese

⸻

🔧 Internal Quality Improvements
	•	Refactored _extract_python_version for more reliable version detection
	•	Improved PATH hygiene logic
	•	Consolidated subprocess execution patterns
	•	Reduced architectural duplication between CLI and dispatcher layers

⸻

📈 Commit Summary

15 commits since v2.2.3
Major themes:
	•	Daemon lifecycle stabilization
	•	Strict interpreter isolation
	•	Swap system architecture cleanup
	•	Resource monitor modernization
	•	Internationalization expansion

⸻

What This Release Represents

v2.3.0 is a stability and architecture hardening release.

It moves omnipkg from “feature-rich” to “operationally reliable,” particularly on Windows — the most hostile environment for process orchestration and path manipulation.

---

**📝 Code Changes:**
- UPDATE: src/omnipkg/cli.py (198 lines changed)
- UPDATE: src/omnipkg/dispatcher.py (392 lines changed)

**Additional Changes:**
- fix: Print debug to shell for users on swaps.
- refactor(core): consolidate swap shell logic into dispatcher
- i18n(ar_eg): massive translation surge from ~10% to 95%+ via global chain + .mo compile

**Bug Fixes:**
- fix: daemon restart uses stop/start directly, clean up restart logic

**Updates:**
- Update dispatcher.py

_28 files changed, 3402 insertions(+), 2391 deletions(-)_

## [2.2.3] — 2026-02-17

Windows Stability, Daemon Overhaul & Concurrency Fixes

Release Notes — omnipkg v2.2.3

This release focuses on major Windows reliability improvements, daemon lifecycle fixes, concurrency stability, and cross-platform process management. After extensive debugging and refactoring, daemon behavior and subprocess handling are now stable under heavy parallel workloads.

⸻

🪟 Windows Compatibility & Stability

Daemon & Worker Execution
	•	Fixed parallel subprocess deadlocks during metadata parsing and package operations.
	•	Hardened Windows daemon launch logic to prevent hangs and zombie workers.
	•	Added compatibility layer for Windows daemon execution.
	•	Eliminated visible console popups when spawning background workers.
	•	Improved worker lifecycle handling to prevent orphaned processes.

Console & Encoding Fixes
	•	Resolved Windows console Unicode and mojibake issues.
	•	All subprocess calls now explicitly use UTF-8 encoding.
	•	Enabled proper ANSI escape sequence support on Windows consoles.

Path & Process Handling
	•	Removed hardcoded /tmp usage in favor of platform-correct temp paths.
	•	Subprocess execution now consistently uses interpreter-safe invocation patterns.
	•	Improved interpreter configuration handling across parallel executions.

⸻

⚡ Core Improvements

Worker & Daemon Lifecycle
	•	Improved daemon start/stop/restart handling.
	•	Added CLI daemon restart support.
	•	Idle worker detection and cleanup logic improved.
	•	Worker reuse and shutdown behavior stabilized.

Output & CI Stability
	•	Forced unbuffered output in daemon workers.
	•	Fixed delayed logging during CI/CD runs.
	•	Reduced buffering issues during concurrent installs.

Dispatcher & Core Execution
	•	Dispatcher logic simplified and stabilized.
	•	Reduced race conditions in worker dispatch logic.
	•	Improved concurrency handling in metadata processing.

⸻

🌍 Internationalization
	•	Major Japanese translation updates and catalog cleanup.
	•	Improved message consistency.
	•	Locale handling fixes across CLI and daemon components.

⸻

🛡️ Maintenance & Infrastructure
	•	Added missing third-party license files.
	•	Updated THIRD_PARTY_NOTICES.
	•	Fixed concurrent metadata builder race conditions.
	•	Cleanup of misplaced test files and legacy code.
	•	Removed duplicate module imports and dead code.

⸻

🧪 Test & CI Improvements
	•	Improved concurrency testing workflows for Windows.
	•	Updated rich switching and interpreter switching tests.
	•	Stability improvements in stress and concurrency test suites.

⸻

📦 Summary

55+ files changed
~6900 insertions / ~4500 deletions

This release significantly improves reliability for:
	•	Windows environments
	•	Concurrent installs
	•	Metadata processing
	•	Worker reuse
	•	Long-running daemon sessions

⸻

#
#
#
#

---

**New Features:**
- feat: daemon idle worker management and i18n updates

**Bug Fixes:**
- fix: add encoding='utf-8' to all subprocess calls to fix Windows Unicode issues

**Updates:**
- Update dispatcher.py
- Update worker_daemon.py
- Update test_rich_switching.py
- Update loader.py
- Update test_uv_switching.py
- Update package_meta_builder.py
- Update cli.py
- Update run.py
- Update workers.py
- Update common_utils.py
- ...and 2 more updates

**Other Changes:**
- ﻿fix(windows): resolve parallel subprocess deadlocks and interpreter config
- Remove misplaced test files from root directory
- fix windows subprocess calls
- Create windows_daemon_compat.py
- Revert "pyproject.toml", "requirements-trace.txt" to state before ef66efa4 (parent: ce646557)
- ...and 4 more changes

_55 files changed, 7106 insertions(+), 4488 deletions(-)_

## [2.2.2] - 2026-02-13

Implements comprehensive daemon management and i18n improvements:

**Daemon & Worker Management:**
- Add 'daemon idle' command for Python version-specific worker pool config
- Group idle workers by Python version in resource monitor
- Add stale worker detection (>24h) with interactive cleanup
- Add daemon restart command (stop + start)
- Make Windows daemon opt-in (OMNIPKG_ENABLE_DAEMON_WINDOWS) with UTF-8/unbuffered I/O
- Remove implicit auto-start for explicit control

**Internationalization (i18n):**
- Complete Japanese translation (ja/LC_MESSAGES/omnipkg.po)
- Hoist i18n imports to global scope, fix UnboundLocalError
- Add OMNIPKG_LANG env var for language priority
- Propagate lang setting to all subprocesses and shims
- Replace print() with safe_print() for encoding safety

**Testing & CI:**
- Windows concurrency test workflow improvements
- Stress test CLI args for specific test selection
- Non-blocking daemon startup in concurrent tests

Files changed: 78 files changed, 9304 insertions(+), 6573 deletions(-)

**Features:**
- feat(i18n): Integrate and propagate i18n across core components

**Fixes:**
- fix(i18n): finalize Japanese translation
- fix(cli): hoist i18n imports to global scope to prevent UnboundLocalError

**Refactoring:**
- refactor: remove undefined name from `__all__`
- refactor: remove reimported module
- refactor: remove unnecessary return statement

**Configuration Updates:**
- Update windows-concurrency-test.yml
- Update README.md
- Update publish.yml
- Update conda_build.yml
- Update meta-platforms.yaml
- Update meta-noarch.yaml

**Other Changes:**
- restore: recover deleted changelog

---

## [2.2.0] - 2026-02-09

### 🔥 BREAKING CHANGES

**Global Interpreter State Removed - Per-Process Isolation Architecture**

This is the most fundamental architectural change in omnipkg history. The entire global state mutation system (symlinks + single config) has been replaced with per-process isolation via shims.

**What Changed:**
- **OLD:** `omnipkg swap python 3.10` modified global symlinks, affecting ALL terminal sessions
- **NEW:** `omnipkg swap python 3.10` spawns an isolated subshell with shims, affecting ONLY that shell/process
- **Migration Required:** Update workflows to use `omnipkg swap python <version>` for interactive shells or version aliases (`8pkg311`, `8pkg310`) for one-shot commands

### 🚀 Major Features

#### Per-Process Python Isolation
Complete architectural redesign eliminating global state pollution:
- **Version-Aware Dispatcher:** CLI now uses `omnipkg.dispatcher:main` for intelligent routing
- **Per-Interpreter Configs:** Each Python stores its own `.omnipkg_config.json` in its bin/ directory
- **Shim-Based Routing:** Shims intercept python calls, read `OMNIPKG_PYTHON` env var, route to correct interpreter
- **Isolated Subshells:** `omnipkg swap python` spawns isolated subshell with shim PATH prefix
- **Version Aliases:** New `8pkg311`, `8pkg310`, etc. commands inject `--python` flag for one-shot operations
- **Smart Cleanup:** Logic ignores leaked `OMNIPKG_PYTHON` when shell/conda env changes

**Shell Isolation Example:**
```bash
$ python --version → 3.11
$ 8pkg swap python 3.10 → new shell
$ python --version → 3.10
$ exit
$ python --version → 3.11
$ 8pkg311 info python → one-shot in 3.11
```

#### Quantum Healing - Finally Fixed!
The quantum healing system now actually works:
- **Proper Activation:** Now triggers during install validation on incompatible Python versions
- **Auto-Swap Example:** Installing TF 2.20 on Python 3.11 → auto-swap to 3.13 → install → swap back
- **Healing Flag:** Uses `_OMNIPKG_QUANTUM_HEALING` to distinguish automated vs user-initiated swaps
- **Context Preservation:** Shell context fully preserved — returns to original Python after healing

#### High-Performance Worker Daemon
Replaced on-demand workers with persistent `WorkerPoolDaemon`:
- **Sub-millisecond Latency:** Eliminates cold-start overhead for package execution
- **Per-Python Pools:** Daemon idle pools now per-python version → prevents version mismatch races
- **Environment Isolation:** `PersistentWorker` scrubs `LD_LIBRARY_PATH`/`PYTHONPATH` → fixes torch import contamination
- **Improved Lifecycle:** Better process isolation and resource management

#### Hardware-Accelerated Atomic Operations
Optional C extension (`omnipkg_atomic`) for HFT-grade concurrency:
- **Native CPU Atomics:** Compare-and-swap (CAS) operations using native CPU atomic instructions
- **Lock-Free Data Structures:** Zero-overhead abstraction
- **Graceful Degradation:** Automatic fallback to pure-Python implementation when compilation unavailable

#### Fully Automated Conda-Forge Pipeline
End-to-end automation for conda-forge distribution:
1. Monitors PyPI publication
2. Computes package SHA256 checksums
3. Generates conda-forge feedstock pull requests
4. Validates CI/CD test results
5. Auto-merges upon successful validation
6. Manages multi-platform build orchestration

### ✨ Key Improvements

#### System Compatibility & Stability
- **Non-Interactive Detection:** Auto-detects TTY/CI/Docker/first-setup → no subshell in pipelines
- **ABI Fixes:** Dependency constraints, numpy dtype size errors resolved
- **Python 3.15 Support:** Full Python 3.15.0a5 support + safety skipping on 3.15+
- **Dependency Constraints:** New `dependency_constraints.py` module for ABI compatibility

#### Testing & Quality Assurance
- **Modernized Test Suite:** DaemonProxy everywhere, warmup phase, tensor math in circular switching
- **Production Benchmarks:** Focused on real-world performance validation
- **Refactored Architecture:** Aligned with new daemon architecture
- **Removed Obsolete Tests:** Cleaned up `quantum_chaos.py`, `test_multiverse_analysis.py`, `test_native_ipc_proper.py`, and 6 other deprecated test files

#### Internationalization (i18n)
- **Massive Translation Expansion:** ~2k Arabic/Amharic strings via AI consensus chain
- **26 Languages Updated:** All locale files regenerated with new strings
- **Binary Size Reduction:** .mo files optimized (e.g., zh_CN: 21KB → 15KB)

#### CI/CD Enhancements
- **Windows Daemon Hardening:** Polling fixes, deadlock resolution
- **New Workflows:** `no-paid-scanners.yml`, `windows_daemon_debug.yml` (269 lines)
- **Cross-Interpreter Testing:** Enhanced validation across Python versions

#### Intelligent Resource Monitoring
- **Daemon-Aware Monitoring:** `omnipkg daemon monitor` queries API for real-time worker pool status
- **Accurate Process Tracking:** Reliable PID-to-package mapping

#### Dependency-Aware Verification
- **Transitive Dependency Support:** Verification includes dependency bubbles (e.g., providing TensorFlow when verifying Keras)
- **Smarter Import Tests:** `verification_strategy.py` enhanced with 294 line changes

#### Integrated Historical Package Support
- **Consolidated Time-Machine:** Functionality integrated directly into core installation logic
- **Removed Separate Module:** Deleted `deptimemachine.py` (346 lines)

### 🗑️ Code Quality & Cleanup

#### Architectural Simplification
- **Removed Deprecated Modules:**
  - `worker_controller.py` (340 lines) → Replaced by centralized daemon
  - `deptimemachine.py` (346 lines) → Integrated into core
  - `lockmanager.py` (49 lines) → Replaced by atomic operations
- **Consolidated Logic:** Daemon logic centralized in `worker_daemon.py`
- **Removed Obsolete Tests:** 9 test files deleted (1,167 lines total)

#### Statistics (v2.1.2 → v2.2.0)
**Excluding locale files:**
- Files changed: 75
- Insertions: +7,255
- Deletions: -5,145
- **Net: +2,110 lines of production code**

**Including locale files:**
- Files changed: 125
- Insertions: +184,067
- Deletions: -85,770
- **Net: +98,297 lines total** (~96k from i18n updates across 26 languages)

### 🐛 Bug Fixes & Resolved Issues

**Closes:**
- Global state pollution across terminal sessions
- Quantum healing activation failures
- ABI/worker contamination issues
- CI deadlocks on Windows
- Interactive CI hangs in non-TTY environments
- Version mismatch races in daemon pools
- Torch import contamination from environment variables

### 📝 Upgrade Instructions
```bash
# Standard upgrade
pip install --upgrade omnipkg
# or
conda install -c conda-forge omnipkg

# Restart daemon (recommended for daemon users)
omnipkg daemon stop && omnipkg daemon start
```

**Migration Notes:**
1. **Global Switching Removed:** If you relied on global Python switching, update to use:
   - `omnipkg swap python <version>` for interactive shells
   - Version aliases (`8pkg311`, `8pkg310`) for scripts/one-shot commands
2. **Subshell Behavior:** `swap` now spawns isolated subshells; use `exit` to return to original context
3. **Config Location:** Configs now per-interpreter in `<python>/bin/.omnipkg_config.json`

### 🎯 What's Next

The per-process isolation architecture is the foundation for:
- **True Process Sandboxing:** Each package runs in completely isolated context
- **Parallel Multi-Version:** Run Python 3.8, 3.11, 3.13 simultaneously without interference
- **Enhanced Security:** No global state = no cross-contamination

### 🙏 Acknowledgments

This release represents months of architectural redesign and over 75 files touched. Special thanks to the CI infrastructure for catching edge cases across 70+ platform builds.

**All CI green ✅**

---
## [2.1.1] - 2026-01-07

### 🔥 Critical Fix
- **Fixed streaming output for interactive documentation console**
  - Changed `/execute` endpoint from buffered `subprocess.run()` to streaming `subprocess.Popen()`
  - Implemented Server-Sent Events (SSE) for real-time line-by-line output delivery
  - Prevents timeout/hanging issues during command execution in web-based docs
  - Essential for demo functionality and user experience in interactive console

### Added
- **Interactive Documentation Structure**
  - New CLI Commands section with detailed command reference
  - Platform Support section documenting 70+ CI builds
  - Interactive Demos section with 4 live examples:
    - C Extension Version Switching
    - Rich Module Styling Demonstration
    - TensorFlow Dependency Management
    - UV Binary Hot-Swapping
  - All docs include YAML front matter with metadata
  - Embedded terminal with real-time command execution

- **Bridge API Improvements**
  - Added health check telemetry logging to SQLite database
  - Cloudflare Worker telemetry forwarding (fire-and-forget pattern)
  - DEV_MODE now allows missing Origin header for curl/testing
  - Expanded CORS origins to support local development:
    - `http://localhost:5000` (MkDocs dev server)
    - `http://127.0.0.1:8085` (Bridge local testing)
    - `https://omnipkg.workers.dev` (Cloudflare Worker)

- **Enhanced MkDocs Configuration**
  - Fixed `site_url` for Cloudflare Pages deployment
  - Added modern navigation features:
    - `navigation.instant` - SPA-like feel
    - `navigation.tracking` - URL updates on scroll
    - `navigation.sections` - Better sidebar grouping
    - `navigation.expand` - Auto-expand details
    - `navigation.indexes` - Clickable section headers
    - `toc.follow` - TOC highlights during scroll
  - New plugins: mkdocs-awesome-pages, mkdocs-macros, mkdocs-minify, mkdocs-redirects
  - Added `meta` extension for YAML front matter parsing
  - Mermaid diagram support via pymdownx.superfences

### Changed
- **execute_omnipkg_command()** now yields output as generator instead of returning complete string
- **/execute** endpoint returns SSE stream instead of JSON response
- Updated package description to include interactive documentation links
- Documentation URLs changed from readthedocs.io to omnipkg.pages.dev
- Improved error handling with streaming context in bridge API
- Updated aiohttp dependency constraint to `>=3.13.3`

### Fixed
- Interactive docs console no longer hangs waiting for command completion
- Real-time output now displays progressively instead of all-at-once
- CORS validation logic improved for production vs development modes
- Streaming responses properly handle errors and timeouts

### Documentation
- Added 15 new markdown files with interactive content
- Reorganized docs into logical sections with `.pages.yml` navigation
- All documentation pages include builder metadata headers
- Comprehensive platform support matrix with live CI links
- Step-by-step demo walkthroughs with copy-paste commands

### Package Metadata
- Version bump: 2.1.0 → 2.1.1
- Updated conda recipes with new PyPI SHA256 hash
- Added `flask` and `flask-cors` to dependencies
- Updated package URLs to point to new documentation site

---

## [v2.1.0] - 2026-01-05

### 🚀 Release v2.1.0 — Executable Documentation & Hybrid Local Cloud

**OmniPkg is no longer just a package manager. It is now an execution platform.**

This release introduces **Executable Documentation**: a secure hybrid architecture that allows users to run real OmniPkg commands directly from the documentation website — with execution happening on their own machine, not in the cloud.

Static docs are dead. Your environment is now the runtime.

### ✨ New Features

#### Executable Documentation
Documentation pages now include live “Run” buttons that execute the exact command being shown and stream real output back to the browser.
*   No copy/paste
*   No terminal switching
*   No “works on my machine”

#### OmniPkg Web Bridge
A new local service that securely connects your browser to your machine:
*   Runs as a local Flask service (`omnipkg web start`)
*   Executes commands in a constrained subprocess
*   Streams stdout/stderr live
*   Enforces strict CORS + allowlisting
*   Requires no open ports

#### Hybrid Cloud–Local Architecture
OmniPkg now spans three layers — without centralizing compute:
1.  **Cloudflare Pages:** Static docs, UI, WASM, zero trust
2.  **Cloudflare Worker:** Edge proxy + routing
3.  **Local Bridge:** Actual execution on your machine

#### Tailscale Remote Execution
If the user is on the same Tailnet, commands can be executed from any device (Phone → Browser → Edge → Tailscale → Local machine). Fully end-to-end encrypted via WireGuard.

#### Privacy-First Telemetry (Local-Only)
Telemetry has been redesigned from the ground up:
*   Stored locally in `~/.omnipkg/telemetry.db`
*   Tracks command names and UI interactions only
*   No IP addresses, no environment data, no cloud persistence.

### 🧰 New CLI Commands

*   `omnipkg web start`: Start the local web bridge
*   `omnipkg web stop`: Stop it cleanly
*   `omnipkg web status`: Health, PID, uptime, URL
*   `omnipkg web logs -f`: Follow live execution + telemetry

### 🔒 Security Model
*   Strict CORS enforcement
*   Command allowlisting
*   No arbitrary shell execution
*   Local-only execution by default
*   Tailscale required for remote access

### 📊 Stats
*   Files changed: 25
*   Insertions: 2,131
*   Deletions: 333

## [2.0.0] - 2025-12-08 - "The Singularity"

**The "Hypervisor" Update.**
This release marks a fundamental paradigm shift from "Package Loader" to "Distributed Runtime Architecture." OmniPkg 2.0 introduces a persistent daemon kernel, universal GPU IPC, and hardware-level isolation, effectively functioning as an Operating System for Python environments.

### 🚀 Major Architectural Breakthroughs
*   **Universal GPU IPC (Pure Python/ctypes):**
    *   Implemented a custom, framework-agnostic CUDA IPC protocol (`UniversalGpuIpc`) using raw `ctypes`.
    *   **Performance:** Achieved **~1.5ms latency** for tensor handoffs, beating PyTorch's native IPC by ~30% and Hybrid SHM by **800%**.
    *   Enables true zero-copy data transfer between isolated processes without relying on framework-specific hooks.
*   **Persistent Worker Daemon ("The Kernel"):**
    *   Replaced ad-hoc subprocess spawning with a persistent, self-healing worker pool (`WorkerPoolDaemon`).
    *   Reduces environment context switching time from **~2000ms** (process spawn) to **~60ms** (warm activation).
    *   Implements an "Elastic Lung" architecture: Workers morph into required environments on-demand and purge themselves back to a clean slate.
*   **Selective Hardware Virtualization (CUDA Hotswapping):**
    *   Implemented dynamic `LD_LIBRARY_PATH` injection at the worker level.
    *   The daemon now scans active bubbles to inject the **exact** CUDA runtime libraries required by the specific framework version (e.g., loading CUDA 11 libs for TF 2.13 while the host runs CUDA 12).
    *   **Result:** Successfully ran TensorFlow 2.12 (CPU), TF 2.13 (CPU), and TF 2.20 (GPU) **simultaneously** in a single orchestration flow without crashing.

### ⚡ Core Enhancements
*   **Fail-Safe Cloaking:** Added `_force_restore_owned_cloaks()` to guarantee filesystem restoration even during catastrophic process failures or OOM events.
*   **Global Shutdown Silencer:** Implemented an `atexit` hook that synchronizes CUDA contexts and silences the C++ "driver shutting down" noise, ensuring clean exit codes for CI/CD.
*   **Composite Bubble Injection:** The loader now automatically constructs "Meta-Bubbles" at runtime, merging the requested package bubble with its binary dependencies (NVIDIA libs, Triton) on the fly.

### 🐛 Critical Fixes
*   **PyTorch 1.13+ Compatibility:** Patched the worker daemon to handle `TypedStorage` serialization changes in newer PyTorch versions, preventing crashes during native IPC.
*   **Deadlock Prevention:** Implemented `ThreadPoolExecutor` in the daemon manager to allow recursive worker calls (Worker A calling Worker B) without deadlocking the socket.
*   **Lazy Loading:** Made `psutil` and `torch` imports lazy within the daemon to prevent "poisoning" the process with default environment versions before isolation takes effect.

### 📊 Benchmarks (vs v1.x)
*   **IPC Speed:** 14ms (v1 Hybrid) → **1.5ms** (v2 Universal).
*   **Context Switch:** 2.5s (v1 Cold) → **0.06s** (v2 Warm).
*   **Concurrency:** Validated "Framework Battle Royale" (NumPy 1.x + 2.x + Torch + TF running concurrently).

---

## [1.6.0]

# omnipkg v1.6.0: The Quantum Lock & Concurrency Release

After a monumentally productive weekend and over **70 developer commits**, this release transforms omnipkg from a powerful tool into a battle-hardened, production-grade orchestrator. This isn't just an update; it's a foundational rewrite of the core engine, focused on eliminating race conditions, conquering state corruption, and achieving true, safe concurrency on all platforms, including Windows.

With over **6,000 lines of code changed**, this release introduces an entirely new level of intelligence, compatibility, and resilience to the system.

## 🚀 New Features & Major Architectural Victories

### True, Multi-Platform Concurrency: The "Impossible" Achieved

Omnipkg now fully supports simultaneous, parallel operations without corrupting its own state. The "Quantum Multiverse" is no longer just a concept—it's a reality. Our Windows CI now proves that **three concurrent threads can simultaneously swap to different Python versions, install different package versions, and operate in the same environment without a single failure.**

This was made possible by a ground-up re-architecture of state management:
- **Atomic Registry Operations:** All writes to the interpreter `registry.json` are now protected by file locks and atomic move operations.
- **The "Admin vs. Worker" Firewall:** A critical safety rule has been implemented. The "native" interpreter is a protected "admin" context, and "worker" contexts (e.g., a thread on Python 3.9) are forbidden from modifying the native environment, solving the primary source of self-syncing bugs and race conditions.

### Intelligent, Trustworthy Self-Healing

The "zombie state"—where an interpreter exists on disk but is unknown to the registry—has been eradicated. The core commands are now self-aware and capable of healing the system.
- **Smart `swap` Command:** Now features a multi-tiered fallback that will **automatically trigger a full filesystem rescan** to find and register "zombie" interpreters before proceeding.
- **Hardened `adopt` & `remove`:** These commands are now fully transactional, performing a final rescan to verify the ground truth before reporting success. The system will never lie to you again.

### Full Python 3.7+ Compatibility & Next-Gen Resolution

- **Legacy Project Support:** Omnipkg now fully supports managing projects running on Python 3.7. The entire dependency chain has been updated, and omnipkg can now download and manage standalone Python 3.7 interpreters.
- **Smarter Dependency Resolution:** Omnipkg now intelligently calculates the correct intersection of version requirements (e.g., `numpy<2.0` vs. `numpy>=1.26`).

### Platform-Aware Intelligence & User Experience

- **Platform-Aware Wheel Selection:** Omnipkg now inspects all available package files, parsing wheel tags to select the best binary wheel for your specific OS, CPU architecture, and Python version.
  > *Pip may still be a reckless time traveler, but with omnipkg, it's now carrying the right passport.*
- **"Return to Origin" Install Guarantee:** The `install` command now automatically returns you to your original Python context after a "Quantum Healing" event.
- **Blazing Fast Startup (204x Faster Self-Heal):** The startup self-heal check has been optimized with a multi-tiered caching strategy, reducing its execution time from **138ms down to a mere 0.677ms** on a cache hit.

## 📝 Important Notes & Known Issues

- **Native Interpreter Sync:** To ensure maximum safety and respect for the user's environment, the self-healing mechanism will sync all *managed* interpreters automatically, but it will **not** automatically upgrade the *native* `omipkg` installation. This is intentional. To upgrade the native installation, please use the explicit `omnipkg upgrade omnipkg` command, or `pip install -e .` for developers.
- **Python 3.7 Self-Heal:** While Python 3.7 is now fully supported for adoption, installation, and swapping, the self-healing logic for identifying it as a "native" interpreter is still under development. This is a known issue that will be resolved in an upcoming patch release.

## 🔮 What's Next: Activating "Quantum Installation"

The individual pieces of our next great leap are already here. This release doesn't just promise future features; it ships the proven, foundational technology for them.

The `install` command's **"Quantum Healing"** engine can already perform fully autonomous, cross-interpreter installations—detecting Python version incompatibilities, adopting the correct Python version, installing the package, and seamlessly returning to the original context. The `run` command's **auto-healing loader** can already activate version "bubbles" at runtime.

The next major step is to **integrate these two proven technologies.**

In a near-future release, the `omnipkg run` loader will be wired directly into the Quantum Healing engine. When a script `import`s a package that requires a completely different version of Python, the loader won't just fail—it will trigger the full, cross-dimensional installation workflow that `omnipkg install` uses today.

The architecture is built. The engine is battle-tested. The final integration is the next logical step. The multiverse is not just expanding; it's becoming fully interactive.

## [1.5.8] - 2025-10-26

### 🌟 Major New Features

#### 🌌 Quantum Healing for Python Versions
The most groundbreaking feature in `omnipkg` history: **automatic Python version conflict resolution**. When a package is incompatible with your current Python version, `omnipkg` now:
- Automatically detects the version incompatibility
- Finds a compatible Python version
- Adopts or downloads the required interpreter
- Switches the environment context seamlessly
- Retries the installation—all in a single command with **zero user intervention**

No more cryptic "requires Python <3.11" errors. Just install and go.

#### 🤖 AI Import Healer
A revolutionary pre-script utility that automatically detects and removes AI-generated "hallucinated" placeholder imports like `from your_file import ...`. This prevents an entire class of frustrating runtime errors caused by AI code assistants suggesting non-existent modules.

#### ⚡️ Ultra-Fast Preflight Checks
Installation is now **dramatically faster** for already-satisfied packages:
- Sub-millisecond satisfaction checks before initializing the full dependency resolver
- Runs with already-installed packages are now nearly instantaneous
- Massive performance improvement for CI/CD pipelines and repeated installs

### ✨ New Features & Enhancements

- **Flask Port Finder & Auto-Healing**: New advanced demo utility that finds open ports for Flask applications and automatically heals missing dependencies during test runs
- **Comprehensive `upgrade` Command**: Fully implemented `omnipkg upgrade` for both self-upgrades and upgrading any managed package
- **Enhanced `run` Command**: 
  - Added `--verbose` flag for detailed execution logging
  - Clearer AI-facing status messages for success, test failures, and healing attempts
  - Better integration with automated workflows
- **Concurrency Optimization**: Test suite now runs concurrent tests in under 500ms by eliminating unnecessary subprocess calls

### 🐛 Bug Fixes

- **Critical Windows Socket Fix**: Resolved socket handling issues in the `run` command on Windows platforms
- **First-Time Setup**: Fixed `AttributeError` that could occur during initial environment setup
- **Uninstall Reliability**: Fixed edge cases where the `uninstall` command could fail
- **Self-Upgrade Logic**: Improved to work correctly for both standard and editable developer installs
- **Dependency Resolver**: Added fallbacks and better error handling for PyPI queries
- **Path Integrity**: Fixed path handling to preserve native Python environment integrity during context swaps
- **Loader TypeError**: Resolved loader issues and prevented recursive `omnipkg` calls within bubbles

### 🔧 CI/CD & Development Experience

#### 🚀 Massive CI Expansion
Added **10+ new GitHub Actions workflows** for comprehensive automated testing:
- Package upgrade testing across multiple scenarios
- Cross-interpreter installation tests (Quantum Healing validation)
- `omnipkg` self-upgrade verification
- Flask port finder and auto-healing demos
- Windows concurrency stress tests
- Automatic Docker image builds and pushes to Docker Hub and GHCR on release
- **Parallel Python Priming on Windows**: Environments now prime in parallel, dramatically speeding up CI runs

#### 🤖 Automation Improvements
- **Auto-Update `requirements.txt`**: CI automatically updates `requirements.txt` via `pip-compile` when `pyproject.toml` changes
- **Enhanced Test Suite**: Complete refactor for better robustness, debugging capabilities, and performance
- **Better Error Reporting**: More actionable error messages and clearer failure indicators

### 🏗️ Architecture & Refactoring

- **Core Installation Overhaul**: Completely redesigned installation logic for better performance and reliability
- **Unified Run/Loader Logic**: Synced and refactored from the `developer-port` branch for consistency
- **Security Scanning**: Improved with `pip-audit` fallback for better vulnerability detection
- **Code Organization**: Improved project structure, documentation, and file organization
- **Cleaned Up Repo**: Removed obsolete files and consolidated commit identities

### 📊 Statistics

- **100+ commits** merged since v1.5.7
- **28 files changed**
- **5,096 insertions**, 1,340 deletions (net +3,756 lines)
- **10+ new CI/CD workflows**
- Test suite performance improved by **>90%** for concurrent operations

### 🎯 Breaking Changes

None! This release maintains full backward compatibility with v1.5.7.

### 📝 Notes

This is the largest single release in `omnipkg` history, representing months of development across performance, reliability, and developer experience. The Quantum Healing feature alone represents a paradigm shift in how Python package managers handle version conflicts.

Special thanks to everyone who tested the development branches and provided feedback on the new features.

---

## [1.3.0] - 2025-09-06

### Added
- **`omnipkg run` Command:** A powerful new way to execute scripts. Features automatic detection of runtime `AssertionError`s for package versions and "auto-heals" the script by re-running it inside a temporary bubble.
- **Automatic Python Provisioning:** Scripts can now ensure required Python interpreters are available, with `omnipkg` automatically running `python adopt` if a version is missing.
- **Performance Timers:** The `multiverse_analysis` test script now instruments and reports on the speed of dimension swaps and package preparation.

### Changed
- **Major Performance Boost:** The knowledge base sync and package satisfaction checks are now dramatically faster, using single subprocess calls to validate the entire environment, reducing checks from many seconds to milliseconds.
- **Quieter Logging:** The bubble creation process is now significantly less verbose during large, multi-dependency installations, providing clean, high-level summaries instead.
- **CLI Refactoring:** Command logic for `run` has been moved to the new `omnipkg/commands/` directory for better structure.

### Fixed
- **Critical Context Bug:** The knowledge base is now always updated by the correct Python interpreter context, especially after a `swap` or during scripted installs, ensuring data for different Python versions is stored correctly.

## v.1.2.1

omnipkg v1.2.1: The Phoenix Release — True Multi-Interpreter Freedom

omnipkg v1.2.1: The Phoenix Release 🚀
This is the release we've been fighting for.

In a previous version (v1.0.8), we introduced a groundbreaking but ultimately unstable feature: Python interpreter hot-swapping. The immense complexity of managing multiple live contexts led to critical bugs, forcing a difficult but necessary rollback. We promised to return to this challenge once the architecture was right.

Today, the architecture is right. Version 1.2.1 delivers on that promise, rising from the ashes of that challenge.

This release introduces a completely re-imagined and bulletproof architecture for multi-interpreter management. It solves the core problems of state, context, and user experience that make this feature so difficult. The impossible is now a stable, intuitive reality.

🔥 Your Environment, Your Rules. Finally.
omnipkg now provides a seamless and robust experience for managing and switching between multiple Python versions within a single environment, starting from the very first command.

1. Zero-Friction First Run: Native Python is Now a First-Class Citizen
The single biggest point of friction for new users has been eliminated. On its very first run, omnipkg now automatically adopts the user's native Python interpreter, making it a fully managed and swappable version from the moment you start.

Start in Python 3.12? omnipkg recognizes it, registers it, and you can always omnipkg swap python 3.12 right back to it.
No more getting "stuck" after a version switch.
No more being forced to re-download a Python version you already have.
2. The Python 3.11 "Control Plane": A Guarantee of Stability
Behind the scenes, omnipkg establishes a managed Python 3.11 environment to act as its "Control Plane." This is our guarantee of stability. All sensitive operations, especially the creation of package bubbles, are now executed within this known-good context.

Solves Real-World Problems: This fixes critical failures where a user on a newer Python (e.g., 3.12) couldn't create bubbles for packages that only supported older versions (e.g., tensorflow==2.13.0).
Predictable & Reliable: Bubble creation is now 100% reliable, regardless of your shell's active Python version.
3. Smart, Safe Architecture
omnipkg runs in your active context, as you'd expect.
Tools that require a specific context (like our test suite) now explicitly and safely request it, making operations transparent and reliable.
What This Means
The journey to this release was a battle against one of the hardest problems in environment management. By solving it, we have created a tool that is not only more powerful but fundamentally more stable and intuitive. You can now step into any Python environment and omnipkg will instantly augment it with the power of multi-version support, without ever getting in your way.

This is the foundation for the future. Thank you for pushing the boundaries with us.

Upgrade now:

pip install -U omnipkg

## v1.1.0
2025-8-21
Localization support for 24 additional languages.

## v1.0.13 - 2025-08-17
### Features
- **Pip in Jail Easter Egg**: Added fun status messages like "Pip is in jail, crying silently. 😭🔒" to `omnipkg status` for a delightful user experience.
- **AGPL License**: Adopted GNU Affero General Public License v3 or later for full open-source compliance.
- **Commercial License Option**: Added `COMMERCIAL_LICENSE.md` for proprietary use cases, with contact at omnipkg@proton.me.
- **Improved License Handling**: Updated `THIRD_PARTY_NOTICES.txt` to list only direct dependencies, with license texts in `licenses/`.

### Bug Fixes
- Reduced deduplication to properly handle binaries, as well as ensuring python modules are kept safe. 

### Improvements
- Added AGPL notice to `omnipkg/__init__.py` with dynamic version and dependency loading.
- Enhanced `generate_licenses.py` to preserve existing license files and moved it to `scripts/`.
- Removed `examples/testflask.py` and `requirements.txt` for a leaner package.
- Updated `MANIFEST.in` to include only necessary files and exclude `examples/`, `scripts/`, and `tests/`.

### Notes
- Direct dependencies: `redis==6.4.0`, `packaging==25.0`, `requests==2.32.4`, `python-magic==0.4.27`, `aiohttp==3.12.15`, `tqdm==4.67.1`.
- Transitive dependency licenses available in `licenses/` for transparency.

## v1.0.9 - 2025-08-11
### Notes
- Restored stable foundation of v1.0.7.
- Removed experimental features from v1.0.8 for maximum stability.
- Recommended for production use.

## [1.3.0] - 2025-09-06

### Added
- **`omnipkg run` Command:** A powerful new way to execute scripts. Features automatic detection of runtime `AssertionError`s for package versions and "auto-heals" the script by re-running it inside a temporary bubble.
- **Automatic Python Provisioning:** Scripts can now ensure required Python interpreters are available, with `omnipkg` automatically running `python adopt` if a version is missing.
- **Performance Timers:** The `multiverse_analysis` test script now instruments and reports on the speed of dimension swaps and package preparation.

### Changed
- **Major Performance Boost:** The knowledge base sync and package satisfaction checks are now dramatically faster, using single subprocess calls to validate the entire environment, reducing checks from many seconds to milliseconds.
- **Quieter Logging:** The bubble creation process is now significantly less verbose during large, multi-dependency installations, providing clean, high-level summaries instead.
- **CLI Refactoring:** Command logic for `run` has been moved to the new `omnipkg/commands/` directory for better structure.

### Fixed
- **Critical Context Bug:** The knowledge base is now always updated by the correct Python interpreter context, especially after a `swap` or during scripted installs, ensuring data for different Python versions is stored correctly.

## v.1.2.1

omnipkg v1.2.1: The Phoenix Release — True Multi-Interpreter Freedom

omnipkg v1.2.1: The Phoenix Release 🚀
This is the release we've been fighting for.

In a previous version (v1.0.8), we introduced a groundbreaking but ultimately unstable feature: Python interpreter hot-swapping. The immense complexity of managing multiple live contexts led to critical bugs, forcing a difficult but necessary rollback. We promised to return to this challenge once the architecture was right.

Today, the architecture is right. Version 1.2.1 delivers on that promise, rising from the ashes of that challenge.

This release introduces a completely re-imagined and bulletproof architecture for multi-interpreter management. It solves the core problems of state, context, and user experience that make this feature so difficult. The impossible is now a stable, intuitive reality.

🔥 Your Environment, Your Rules. Finally.
omnipkg now provides a seamless and robust experience for managing and switching between multiple Python versions within a single environment, starting from the very first command.

1. Zero-Friction First Run: Native Python is Now a First-Class Citizen
The single biggest point of friction for new users has been eliminated. On its very first run, omnipkg now automatically adopts the user's native Python interpreter, making it a fully managed and swappable version from the moment you start.

Start in Python 3.12? omnipkg recognizes it, registers it, and you can always omnipkg swap python 3.12 right back to it.
No more getting "stuck" after a version switch.
No more being forced to re-download a Python version you already have.
2. The Python 3.11 "Control Plane": A Guarantee of Stability
Behind the scenes, omnipkg establishes a managed Python 3.11 environment to act as its "Control Plane." This is our guarantee of stability. All sensitive operations, especially the creation of package bubbles, are now executed within this known-good context.

Solves Real-World Problems: This fixes critical failures where a user on a newer Python (e.g., 3.12) couldn't create bubbles for packages that only supported older versions (e.g., tensorflow==2.13.0).
Predictable & Reliable: Bubble creation is now 100% reliable, regardless of your shell's active Python version.
3. Smart, Safe Architecture
omnipkg runs in your active context, as you'd expect.
Tools that require a specific context (like our test suite) now explicitly and safely request it, making operations transparent and reliable.
What This Means
The journey to this release was a battle against one of the hardest problems in environment management. By solving it, we have created a tool that is not only more powerful but fundamentally more stable and intuitive. You can now step into any Python environment and omnipkg will instantly augment it with the power of multi-version support, without ever getting in your way.

This is the foundation for the future. Thank you for pushing the boundaries with us.

Upgrade now:

pip install -U omnipkg

## v1.1.0
2025-8-21
Localization support for 24 additional languages.

## v1.0.13 - 2025-08-17
### Features
- **Pip in Jail Easter Egg**: Added fun status messages like “Pip is in jail, crying silently. 😭🔒” to `omnipkg status` for a delightful user experience.
- **AGPL License**: Adopted GNU Affero General Public License v3 or later for full open-source compliance.
- **Commercial License Option**: Added `COMMERCIAL_LICENSE.md` for proprietary use cases, with contact at omnipkg@proton.me.
- **Improved License Handling**: Updated `THIRD_PARTY_NOTICES.txt` to list only direct dependencies, with license texts in `licenses/`.

### Bug Fixes
- Reduced deduplication to properly handle binaries, as well as ensuring python modules are kept safe. 

### Improvements
- Added AGPL notice to `omnipkg/__init__.py` with dynamic version and dependency loading.
- Enhanced `generate_licenses.py` to preserve existing license files and moved it to `scripts/`.
- Removed `examples/testflask.py` and `requirements.txt` for a leaner package.
- Updated `MANIFEST.in` to include only necessary files and exclude `examples/`, `scripts/`, and `tests/`.

### Notes
- Direct dependencies: `redis==6.4.0`, `packaging==25.0`, `requests==2.32.4`, `python-magic==0.4.27`, `aiohttp==3.12.15`, `tqdm==4.67.1`.
- Transitive dependency licenses available in `licenses/` for transparency.

## v1.0.9 - 2025-08-11
### Notes
- Restored stable foundation of v1.0.7.
- Removed experimental features from v1.0.8 for maximum stability.
